/* Meu Assistente · Impostos e DAS */
/* ---------- catálogo público ---------- */
/* ---------- impostos e DAS ---------- */
const MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
const ym=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0');
function dasValor(F){const inss=F.sm*(F.atividade==='caminhoneiro'?.12:.05);const icms=['comercio','ambos','caminhoneiro'].includes(F.atividade)?1:0;const iss=['servicos','ambos'].includes(F.atividade)?5:0;return{inss,icms,iss,total:inss+icms+iss}}
function competencias(){const out=[],hoje=new Date(),y=hoje.getFullYear();const ini=S.fiscal.abertura&&S.fiscal.abertura.startsWith(String(y))?parseInt(S.fiscal.abertura.slice(5),10)-1:0;
 for(let m=ini;m<=hoje.getMonth();m++){const comp=new Date(y,m,1),venc=new Date(y,m+1,20);out.push({k:ym(comp),nome:MES[m]+'/'+y,venc})}return out}
function initPagos(){const F=S.fiscal;if(F.init)return;const hoje=new Date();competencias().forEach(c=>{if(c.venc<hoje)F.pagos[c.k]=true});F.init=true;save()}
function proxDAS(){initPagos();const c=competencias().find(x=>!S.fiscal.pagos[x.k]);return c}
function limiteAno(){const F=S.fiscal,y=new Date().getFullYear();if(F.abertura&&F.abertura.startsWith(String(y))){const meses=12-parseInt(F.abertura.slice(5),10)+1;return F.limite/12*meses}return F.limite}
function faturadoAno(){const y=String(new Date().getFullYear());return Object.entries(S.fiscal.receitas).filter(([k])=>k.startsWith(y)).reduce((a,[,v])=>a+Number(v||0),0)}
const ATV={comercio:'Comércio ou indústria',servicos:'Serviços',ambos:'Comércio e serviços',caminhoneiro:'Transportador autônomo de cargas'};
function shell(title,sub,body){return `<div class="relative z-10 h-dvh overflow-y-auto scroll-thin"><header class="sticky top-0 z-20 px-3 pt-[calc(env(safe-area-inset-top)+0.6rem)] md:px-6"><div class="glass-bar mx-auto flex max-w-3xl items-center gap-3 rounded-full px-3 py-2 md:px-4"><span class="nx-brand inline-block shrink-0" data-variant="principal" style="width:34px;height:24px"><img src="${IMG.principal}" alt="" class="block h-full w-full select-none object-contain"></span><div class="min-w-0 flex-1 leading-tight"><p class="truncate text-[15px] font-semibold">${title}</p><p class="text-[11.5px] text-ink-3">${sub}</p></div><a href="#app" class="inline-flex h-10 items-center rounded-full border border-line-strong px-4 text-sm font-semibold text-ink transition hover:bg-surface-2">Voltar ao chat</a></div></header><main class="mx-auto max-w-3xl px-4 pb-[calc(env(safe-area-inset-bottom)+3rem)] md:px-6">${body}</main></div>`}
function viewFiscal(){
 const scr=$('#screen'),F=S.fiscal;
 if(!S.modules.fiscal){scr.innerHTML=shell('Impostos e DAS','Módulo desligado',`<section class="py-16 text-center"><p class="font-display text-[1.7rem] leading-tight">Módulo desligado</p><p class="mt-2 text-sm text-ink-2">Ative “Impostos e DAS” em Administração → Módulos.</p></section>`);return}
 const d=dasValor(F),hoje=new Date(),comps=competencias(),prox=proxDAS(),lim=limiteAno(),fat=faturadoAno(),pc=lim?Math.min(100,fat*100/lim):0;
 const limMsg=fat>lim*1.2?'Você passou mais de 20% do limite. O desenquadramento vale desde janeiro: procure um contador.':fat>lim?'Você passou do limite. Até 20% acima, paga a diferença em guia própria e vira microempresa no ano que vem.':pc>=80?'Atenção: você já usou mais de 80% do limite do ano.':'Dentro do limite do MEI.';
 const y=hoje.getFullYear(),mesesAno=Array.from({length:hoje.getMonth()+1},(_,m)=>ym(new Date(y,m,1)));
 const dasnAno=hoje>new Date(y,4,31)?y+1:y;
 scr.innerHTML=shell('Impostos e DAS','MEI · '+ATV[F.atividade],`
 <section class="pb-6 pt-10"><h2 class="mb-2 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3">Próximo DAS</h2>
 ${prox?`<p class="font-display text-[2.3rem] leading-[1.03] tabular">${brl(d.total)}</p><p class="mt-2 text-[15px] text-ink-2">Competência ${prox.nome} · vence em ${fdate(prox.venc)}${prox.venc<hoje?' · <span class="text-danger">em atraso</span>':''}</p>
 <div class="mt-4 flex flex-wrap gap-2"><button type="button" id="f_pago" class="${PRI}">Marcar como pago</button><a href="#fiscal" data-soon="pgmei" class="${GHO}">Gerar guia no PGMEI</a></div>`:`<p class="font-display text-[1.7rem] leading-tight">Tudo pago até agora.</p>`}
 <p class="mt-3 text-xs text-ink-3">INSS ${brl(d.inss)}${d.icms?' + ICMS '+brl(d.icms):''}${d.iss?' + ISS '+brl(d.iss):''} · salário mínimo ${brl(F.sm)}</p></section>
 <h2 class="${H2}">Usar meus dados</h2>
 ${card(row('Permitir que o assistente use meus dados','Receitas que você contar no chat (“recebi 500 de um cliente”) entram no faturamento e no cálculo.',sw('consent',F.consent,'Permitir uso dos dados'))+`<div class="px-5 py-3 text-xs text-ink-3">${F.consent?'Ligado. Você pode desligar quando quiser; os valores já lançados continuam editáveis abaixo.':'Desligado. O assistente só usa o que você digitar nesta tela.'}</div>`)}
 <h2 class="${H2} mt-8">Faturamento ${y}</h2>
 <div class="glass rounded-[1.6rem] p-5"><div class="flex items-end justify-between gap-3"><div><p class="text-[1.6rem] font-bold tabular">${brl(fat)}</p><p class="text-xs text-ink-3">de ${brl(lim)} permitidos${lim!==F.limite?' (proporcional à abertura)':''}</p></div><p class="text-[15px] font-semibold tabular ${pc>=80?'text-danger':'text-accent'}">${pc.toFixed(0)}%</p></div>
 <div class="ma-bar mt-3"><span style="width:${pc}%" class="${pc>=80?'ma-bar-bad':''}"></span></div><p class="mt-2 text-xs ${pc>=80?'text-danger':'text-ink-3'}">${limMsg}</p>
 <div class="mt-4 grid grid-cols-3 gap-2">${mesesAno.map(k=>`<label class="block"><span class="text-[11px] text-ink-3">${MES[parseInt(k.slice(5),10)-1]}</span><input data-rec="${k}" inputmode="decimal" class="${INP} mt-0.5" value="${F.receitas[k]?String(F.receitas[k]).replace('.',','):''}" placeholder="0"></label>`).join('')}</div>
 <div class="mt-3"><button type="button" id="f_rsave" class="${GHO} h-10">Salvar faturamento</button></div></div>
 <h2 class="${H2} mt-8">Guias do ano</h2>
 ${card(comps.slice().reverse().map(c=>{const pago=!!F.pagos[c.k],atr=!pago&&c.venc<hoje;return row('DAS '+c.nome+' · '+brl(d.total),'Vence '+fdate(c.venc),`${pill(pago?'Pago':atr?'Em atraso':'A pagar',pago?'ok':atr?'bad':'warn')}<button type="button" data-pg="${c.k}" class="text-[13px] font-semibold text-ink-2 hover:text-ink">${pago?'Desfazer':'Pago'}</button>`)}).join(''))}
 <p class="mt-2 px-1 text-xs text-ink-3">Guia em atraso: gere de novo no PGMEI, que já calcula multa e juros.</p>
 <h2 class="${H2} mt-8">Avisos e declarações</h2>
 ${card(row('Lembrar do DAS',`Aviso ${F.avisos.dias} dia(s) antes do dia 20.`,sw('a_das',F.avisos.das,'Lembrar do DAS'))+row('Declaração anual do MEI (DASN-SIMEI)','Entrega até 31/05/'+dasnAno+', com o faturamento de '+(dasnAno-1)+'.',sw('a_dasn',F.avisos.dasn,'Lembrar da DASN'))+row('Imposto de Renda (pessoa física)','Aviso quando a Receita abrir o prazo de entrega.',sw('a_irpf',F.avisos.irpf,'Lembrar do IR')))}
 <h2 class="${H2} mt-8">Seu MEI</h2>
 <div class="glass rounded-[1.6rem] p-5 grid gap-3 md:grid-cols-2">
  <label class="block"><span class="text-xs text-ink-3">Atividade</span><select id="f_atv" class="${INP} mt-1">${Object.entries(ATV).map(([k,l])=>`<option value="${k}" ${F.atividade===k?'selected':''}>${l}</option>`).join('')}</select></label>
  <label class="block"><span class="text-xs text-ink-3">Abriu o MEI neste ano? Mês de abertura</span><input id="f_ab" type="month" class="${INP} mt-1" value="${esc(F.abertura)}"></label>
  <label class="block"><span class="text-xs text-ink-3">Avisar quantos dias antes do DAS</span><input id="f_dias" inputmode="numeric" class="${INP} mt-1" value="${F.avisos.dias}"></label>
  <div class="md:col-span-2"><button type="button" id="f_save" class="${PRI} h-10">Salvar</button></div></div>
 <p class="mt-4 px-1 text-xs leading-relaxed text-ink-3">Valores de ${y}: salário mínimo ${brl(F.sm)}, INSS de 5% (12% para transportador de cargas), limite anual ${brl(F.limite)}. São ajustáveis pelo administrador quando mudarem. É uma estimativa para organização: confirme sempre no Portal do Empreendedor ou com um contador.</p>`);
 $$('img[data-img]',scr).forEach(i=>i.src=IMG[i.dataset.img]);
 const re=()=>viewFiscal();
 if($('#f_pago',scr))$('#f_pago',scr).onclick=()=>{F.pagos[prox.k]=true;log('DAS '+prox.nome+' marcado como pago');save();re();toast('DAS marcado como pago')};
 $$('[data-pg]',scr).forEach(b=>b.onclick=()=>{const k=b.dataset.pg;F.pagos[k]=!F.pagos[k];save();re()});
 $$('[data-sw]',scr).forEach(b=>b.onclick=()=>{const k=b.dataset.sw;if(k==='consent'){F.consent=!F.consent;log('Uso dos dados para impostos '+(F.consent?'permitido':'revogado'))}else{const m={a_das:'das',a_dasn:'dasn',a_irpf:'irpf'}[k];F.avisos[m]=!F.avisos[m]}save();re()});
 $('#f_rsave',scr).onclick=()=>{$$('[data-rec]',scr).forEach(i=>{const v=parseFloat(i.value.replace(/\./g,'').replace(',','.'));if(isNaN(v)||v<=0)delete F.receitas[i.dataset.rec];else F.receitas[i.dataset.rec]=v});log('Faturamento atualizado');save();re();toast('Faturamento salvo')};
 $('#f_save',scr).onclick=()=>{F.atividade=$('#f_atv',scr).value;F.abertura=$('#f_ab',scr).value;const dd=parseInt($('#f_dias',scr).value,10);if(dd>=0&&dd<=15)F.avisos.dias=dd;save();re();toast('Salvo')};
}

