/* Meu Assistente · Montagem das telas, rotas e apresentação */
/* ---------- montagem de telas ---------- */
function mount(name){
 const scr=$('#screen');scr.innerHTML=TPL[name]||'';
 $$('img[data-img]',scr).forEach(i=>i.src=IMG[i.dataset.img]);
 wireCommon(scr);
 return scr;
}
function wireCommon(scr){
 $$('[aria-label="Abrir menu"]',scr).forEach(b=>b.addEventListener('click',openMenu));
 $$('[aria-label="Fechar menu"]',scr).forEach(b=>b.addEventListener('click',closeMenu));
}
function openMenu(){const n=$('nav.nx-menu');if(!n)return;const w=n.parentElement;w.setAttribute('data-open','');w.classList.remove('pointer-events-none');w.setAttribute('aria-hidden','false');n.removeAttribute('inert')}
function closeMenu(){const n=$('nav.nx-menu');if(!n)return;const w=n.parentElement;w.removeAttribute('data-open');w.classList.add('pointer-events-none');w.setAttribute('aria-hidden','true');n.setAttribute('inert','')}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
document.addEventListener('click',e=>{
 const a=e.target.closest('a');if(!a)return;
 if(a.dataset.anchor){e.preventDefault();const el=document.getElementById(a.dataset.anchor);if(el)el.scrollIntoView({behavior:'smooth',block:'start'});return}
 if(a.dataset.soon){e.preventDefault();closeMenu();toast('Esta tela existe no app original. Neste teste estão: chat, apresentação, anúncios, catálogo e painel.');return}
 closeMenu();
});
function addMenuLinks(scr){
 const adm=$$('nav.nx-menu a',scr).find(a=>a.getAttribute('href')==='#admin');if(!adm)return;
 const items=[['#sua-empresa','Sua empresa','bag',minhas().length>0],['#fiscal','Impostos e DAS','receipt',S.modules.fiscal],['#mercado','Mercado','chart',S.modules.mercado],['#conheca','Conheça o Meu Assistente','spark',true],['#anunciar','Anunciar','mega',S.modules.anuncios],['#empresas','Empresas perto de você','store',true]];
 items.forEach(([h,t,ic,show])=>{if(!show)return;const c=adm.cloneNode(true);c.setAttribute('href',h);$('.truncate',c).textContent=t;const old=$('svg',c);old.outerHTML=svg(ic,20,'shrink-0 transition text-ink-3 group-hover:text-ink');adm.parentElement.insertBefore(c,adm)});
 // Contas some quando Finanças estiver desligado
 if(!S.modules.financas)$$('nav.nx-menu a',scr).filter(a=>/financeiro/.test(a.dataset.soon||'')||a.textContent.trim()==='Contas').forEach(a=>a.style.display='none');
}

/* ---------- roteamento ---------- */
const ROUTES_DEF=()=>({app:viewApp,conheca:viewConheca,anunciar:viewAnunciar,admin:viewAdmin,loja:viewEmpresas,empresas:viewEmpresas,fiscal:viewFiscal,mercado:viewMercado});
function route(){closeSheet&&closeSheet();const r=(location.hash||'#conheca').slice(1);if(r.startsWith('empresa-'))return viewEmpresa(r.slice(8));if(r.startsWith('painel-'))return viewPainel(r.slice(7));if(r==='sua-empresa')return viewSuaEmpresa();const R=ROUTES_DEF();(R[r]||viewConheca)();}
addEventListener('hashchange',route);

/* ---------- apresentação (/conheca) ---------- */
function viewConheca(){
 const scr=mount('conheca');
 // a demonstração do original roda no navegador; aqui os exemplos abrem o assistente com o pedido
 $$('button',scr).forEach(b=>{const q=b.textContent.match(/“(.+)”/);if(q||/^(Agendar compromisso|Criar lembrete|Lista do mercado|Registrar gasto)$/.test(b.textContent.trim())){b.addEventListener('click',()=>{const map={'Agendar compromisso':'Marque consulta no dentista amanhã às 15h','Criar lembrete':'Me lembre de pagar a conta de luz sexta às 9h','Lista do mercado':'Adicione arroz, feijão, batata, leite e café na lista do mercado','Registrar gasto':'Gastei 45,90 no mercado hoje'};const t=q?q[1]:map[b.textContent.trim()];sessionStorage.setItem('ma-pedido',t);location.hash='#app'})}});
 if(!S.modules.anuncios){}
}

