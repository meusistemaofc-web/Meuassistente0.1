/* Meu Assistente · Fontes de dados do mercado (troca automática) */
/* ---------- dados ---------- */
const MKT_DEF=[
 ['coingecko','CoinGecko','cripto',false,'Sem chave (opcional: chave Demo grátis em coingecko.com/api)','https://api.coingecko.com/api/v3/simple/price?ids={id}&vs_currencies=brl&include_24hr_change=true'],
 ['coinpaprika','CoinPaprika','cripto',false,'Sem chave · 20 mil chamadas por mês','https://api.coinpaprika.com/v1/tickers/{id}?quotes=BRL'],
 ['binance','Binance (dados públicos)','cripto',false,'Sem chave · preço em USDT convertido para real','https://api.binance.com/api/v3/ticker/24hr?symbol={SIMBOLO}USDT'],
 ['coincap','CoinCap','cripto',true,'Chave grátis em coincap.io','https://rest.coincap.io/v3/assets/{id}'],
 ['brapi','brapi.dev (B3)','bolsa',true,'Token grátis em brapi.dev','https://brapi.dev/api/quote/{SIMBOLO}?token={chave}'],
 ['yahoo','Yahoo Finance','bolsa',false,'Sem chave · não oficial, pode mudar sem aviso','https://query1.finance.yahoo.com/v8/finance/chart/{SIMBOLO}.SA'],
 ['alphavantage','Alpha Vantage','bolsa',true,'Chave grátis · 25 consultas por dia','https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={SIMBOLO}.SA&apikey={chave}'],
 ['twelvedata','Twelve Data','bolsa',true,'Chave grátis · 800 consultas por dia','https://api.twelvedata.com/quote?symbol={SIMBOLO}&exchange=BVMF&apikey={chave}']
];
function mkMkt(){return MKT_DEF.map(([id,nome,cat,precisaChave,info,url])=>({id,nome,cat,precisaChave,info,url,campo:'',key:'',ativo:true,status:'ok',ate:0,erro:'',usos:0,falhas:0,simular:'',custom:false}))}
function mktUsable(p,cat){return p.ativo&&p.cat===cat&&(!p.precisaChave||!!p.key)&&p.status!=='expirada'&&!(p.ate>Date.now())}
function fonte(cat){const tried=[];for(const p of S.mkt){if(!mktUsable(p,cat))continue;if(p.simular){const f=p.simular;p.simular='';p.falhas++;if(f==='limite'){p.status='limite';p.ate=Date.now()+60000;p.erro='Limite de consultas atingido (429).'}else if(f==='expirada'){p.status='expirada';p.erro='Chave inválida (401).'}else{p.status='erro';p.ate=Date.now()+30000;p.erro='Serviço fora do ar (500).'}tried.push(p.nome);log('Mercado: '+p.nome+' falhou ('+p.erro+') · troca automática');save();continue}p.usos++;if(p.status!=='expirada'){p.status='ok';p.erro=''}return{p,tried}}return{p:null,tried}}
const catDe=sym=>ATIVOS.cripto.some(a=>a[0]===sym)?'cripto':'bolsa';

