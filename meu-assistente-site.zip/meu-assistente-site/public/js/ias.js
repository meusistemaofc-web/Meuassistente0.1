/* Meu Assistente · Provedores de IA */
const PROV_DEF=[
 ['gemini','Google Gemini','gemini-flash-latest',true,true,'Chave grátis em aistudio.google.com'],
 ['groq','Groq','',true,false,'Chave grátis em console.groq.com'],
 ['openrouter','OpenRouter','',true,false,'Chave em openrouter.ai, use modelos com “:free”'],
 ['mistral','Mistral','',true,false,'Plano gratuito em console.mistral.ai'],
 ['cerebras','Cerebras','',true,false,'Chave grátis em cloud.cerebras.ai'],
 ['github','GitHub Models','',true,false,'Token da sua conta GitHub'],
 ['custom','Outra IA compatível com OpenAI','',true,false,'Qualquer serviço no formato OpenAI (endereço + chave)'],
 ['ollama','Ollama da sua VPS','qwen2.5:1.5b',true,false,'Roda no seu servidor: sem chave e sem limite']
];
function mkProvs(){return PROV_DEF.map(([id,nome,modelo,texto,imagem,onde])=>({id,nome,modelo,texto,imagem,onde,key:'',url:'',ativo:true,status:id==='ollama'?'ok':'sem_chave',ate:0,erro:'',usos:0,falhas:0,simular:''}))}

