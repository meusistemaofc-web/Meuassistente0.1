/* Meu Assistente · Início */
/* ---------- início ---------- */
document.addEventListener('click',e=>{if(e.target.id!=='ma-reset')return;dlg('Apagar todos os dados de teste e recomeçar?',{ok:'Apagar tudo',danger:true}).then(ok=>{if(!ok)return;try{localStorage.removeItem(KEY)}catch(e){}S=defaults();usersHTML='';tab='usuarios';route();toast('Tudo recomeçado')})});
route();

