/* Meu Assistente · Página Anunciar */
/* ---------- anunciar (/anunciar) ---------- */
function viewAnunciar(){
 const scr=mount('anunciar');
 const sec=$('#proposta',scr), err=sec&&$('p.text-danger',sec);
 if(!S.modules.anuncios){if(err)err.innerHTML='A contratação de anúncios está pausada no momento.';return}
 if(err)err.outerHTML=`<form id="ma-form" class="glass grid gap-4 rounded-[2rem] p-5 md:grid-cols-2 md:p-6" novalidate>
  ${fld('empresa','Nome da empresa')}${fld('contato','Seu nome')}${fld('email','E-mail','email')}${fld('whatsapp','WhatsApp','tel','+55 11 98765-4321')}
  <div class="md:col-span-2"><span class="${LBL2}">Plano</span><div class="grid gap-2 md:grid-cols-2">${S.pacotes.slice().sort((a,b)=>(a.nivel||1)-(b.nivel||1)).map((p,i)=>`<label class="ma-plan flex cursor-pointer gap-3 rounded-2xl border border-line p-4"><input type="radio" name="pacote" value="${p.id}" ${i===0?'checked':''} class="mt-1"><span class="min-w-0"><span class="block text-[15px] font-semibold">${esc(p.nome)} · ${brl(p.preco)}</span><span class="mt-0.5 block text-[12.5px] leading-snug text-ink-3">${p.dias} dias. ${NIVEL_DESC[p.nivel||1]}</span></span></label>`).join('')}</div></div>
  <div id="ma-prev" class="contents"></div>
  ${fld('categoria','Ramo (aparece na busca do chat)','text','Ex.: Pizzaria')}${fld('tags','Palavras de busca','text','pizza, delivery, massas')}
  <div class="md:col-span-2 rounded-2xl border border-line p-4"><span class="${LBL2}">Localização e alcance</span><p class="text-[12.5px] text-ink-3">Para aparecer na busca do chat de quem está perto.</p><div class="mt-3 flex flex-wrap items-center gap-2"><button type="button" id="ma-gps" class="${GHO} h-10">Usar a localização atual</button><span id="ma-gpsst" class="text-[12.5px] text-ink-3">Opcional: sem ela, a equipe define pelo endereço.</span></div>
   <label class="mt-3 block"><span class="${LBL2}">Ser encontrada até</span><select name="raioVisivel" class="${INP2}">${[2,5,10,20,50].map(k=>`<option value="${k}" ${k===5?'selected':''}>${k} km da empresa</option>`).join('')}</select></label></div>
  <div class="ma-n2 contents">${fld('zap','WhatsApp da empresa (com 55)','tel','5511987654321')}${fld('insta','Instagram (sem @)','text','suaempresa')}</div>
  <div class="ma-n3 contents">${fld('endereco','Endereço','text','Rua, número, bairro',160,true)}${fld('horario','Horário de funcionamento','text','Seg a sáb, 9h às 18h',80,true)}<label class="block md:col-span-2"><span class="${LBL2}">Sobre a empresa</span><textarea name="sobre" maxlength="500" rows="3" class="${INP2} ma-ta"></textarea></label></div>
  <p class="ma-n4 md:col-span-2 text-[12.5px] text-ink-3">No plano Loja completa, depois da aprovação você cadastra capa, produtos, variações, entrega e pagamento no painel da empresa.</p>
  ${fld('titulo','Título do anúncio','text','',60,true)}
  <label class="block md:col-span-2"><span class="${LBL2}">Texto <span class="text-ink-3">até 160 caracteres</span></span><textarea name="texto" maxlength="160" rows="3" class="${INP2} ma-ta"></textarea></label>
  ${fld('link','Link da sua página','url','https://',200,true)}
  <label class="block md:col-span-2"><span class="${LBL2}">Logotipo <span class="text-ink-3">opcional</span></span><input name="logo" type="file" accept="image/*" class="${INP2} ma-file"></label>
  <p class="ma-err md:col-span-2" id="ma-ferr"></p>
  <div class="md:col-span-2"><button type="submit" class="btn-send inline-flex h-12 items-center justify-center gap-2 rounded-full px-6 text-[15px] font-semibold">Enviar para aprovação</button></div>
 </form>`;
 const f=$('#ma-form',scr);
 const lvl=()=>{const id=(f&&f.querySelector('[name=pacote]:checked')||{}).value;return(pack(id)||{}).nivel||1};
 const prev=()=>{if(!f)return;const d=Object.fromEntries(new FormData(f));delete d.logo;$('#ma-prev',f).innerHTML=previewHTML(d,(f.querySelector('[name=pacote]:checked')||{}).value)};
 const vis=()=>{if(!f)return;prev();const n=lvl();[2,3,4].forEach(k=>$$('.ma-n'+k,f).forEach(x=>x.style.display=n>=k?'':'none'));$$('.ma-plan',f).forEach(l=>l.classList.toggle('border-accent/60',l.querySelector('input').checked))};
 let gps=null;if(f)$('#ma-gps',f).onclick=()=>{if(!navigator.geolocation)return toast('Este navegador não informa localização.');$('#ma-gpsst',f).textContent='Aguardando permissão…';navigator.geolocation.getCurrentPosition(pos=>{gps={lat:pos.coords.latitude,lng:pos.coords.longitude};$('#ma-gpsst',f).textContent='Localização capturada.'},()=>{$('#ma-gpsst',f).textContent='Não foi possível obter a localização. Informe o endereço.'},{enableHighAccuracy:true,timeout:12000})};
 if(f){f.addEventListener('change',vis);f.addEventListener('input',e=>{if(e.target.type!=='file')prev()});vis();f.querySelector('[name=logo]').addEventListener('change',async ev=>{try{prevLogo=await resizeImage(ev.target.files[0],240);prev()}catch(x){}})}
 if(f)f.addEventListener('submit',async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(f));const fe=$('#ma-ferr',scr);
  if(!d.empresa.trim()||!d.contato.trim()||!/^\S+@\S+\.\S+$/.test(d.email)||!d.titulo.trim()||!(d.categoria||'').trim()){fe.textContent='Preencha empresa, seu nome, e-mail válido, ramo e título.';return}
  if(lvl()>=2&&!(d.zap||'').replace(/\D/g,'')&&!(d.insta||'').trim()){fe.textContent='Informe WhatsApp ou Instagram para este plano.';return}
  if(d.link&&d.link!=='https://'&&!/^https?:\/\/\S+\.\S+/.test(d.link)){fe.textContent='O link precisa começar com https://';return}
  let logo='';const lf=f.querySelector('[name=logo]').files[0];if(lf){try{logo=await resizeImage(lf,240)}catch(x){fe.textContent=x.message;return}}
  const protocolo='AN-'+new Date().toISOString().slice(0,10).replace(/-/g,'')+'-'+uid();
  S.propostas.unshift({protocolo,empresa:d.empresa.trim(),contato:d.contato.trim(),email:d.email.trim().toLowerCase(),whatsapp:d.whatsapp.trim(),dono:'me',registros:[{t:'Proposta enviada para aprovação',q:Date.now()}],pacoteId:d.pacote,raioVisivel:parseFloat(d.raioVisivel)||5,...(gps||{}),categoria:(d.categoria||'').trim(),tags:(d.tags||'').trim(),zap:(d.zap||'').replace(/\D/g,''),insta:(d.insta||'').replace(/^@/,'').trim(),endereco:(d.endereco||'').trim(),horario:(d.horario||'').trim(),sobre:(d.sobre||'').trim(),cor:['#d9480f','#1c7ed6','#2b8a3e','#c2255c','#5f3dc4'][Math.floor(Math.random()*5)],titulo:d.titulo.trim(),texto:(d.texto||'').trim(),link:d.link==='https://'?'':d.link.trim(),logo,status:'analise',criado:Date.now(),vence:0,motivo:''});
  initLoja(S.propostas[0]);log('Nova proposta de anúncio: '+d.empresa.trim());save();
  f.outerHTML=`<div class="glass rounded-[2rem] p-5 md:p-6"><p class="text-[15px] font-semibold">Proposta enviada.</p><p class="mt-1 text-sm text-ink-2">Guarde seu protocolo: <b class="tabular text-ink">${protocolo}</b>. Acompanhe o status abaixo com ele e o e-mail usado.</p><p class="mt-3"><a href="#sua-empresa" class="btn-send inline-flex h-11 items-center rounded-full px-5 text-sm font-semibold">Abrir Sua empresa no meu assistente</a></p></div>`;
  const pi=$('#status input',scr);if(pi){pi.value=protocolo;$$('#status input',scr)[1].value=d.email.trim();$('#status button[type=submit]',scr).disabled=false}
 });
 // consulta de protocolo
 const sf=$('#status form',scr);if(sf){const [pi,ei]=$$('input',sf),bt=$('button[type=submit]',sf);const chk=()=>bt.disabled=!(pi.value.trim()&&ei.value.trim());pi.oninput=ei.oninput=chk;
  sf.addEventListener('submit',e=>{e.preventDefault();$('#ma-st',scr)?.remove();const p=S.propostas.find(x=>x.protocolo===pi.value.trim().toUpperCase()&&x.email===ei.value.trim().toLowerCase());
   const box=document.createElement('div');box.id='ma-st';box.className='glass mt-4 rounded-[2rem] p-5 md:p-6';
   if(!p){box.innerHTML='<p class="text-sm text-danger">Não encontramos uma proposta com esse protocolo e e-mail.</p>'}
   else{const pk=pack(p.pacoteId);const st={analise:'Em análise pela equipe',ajustes:'Ajustes solicitados',recusado:'Recusada',aprovado:'Aprovada · aguardando pagamento',ativo:'No ar até '+fdate(p.vence)}[p.status];
    box.innerHTML=`<p class="text-[15px] font-semibold">${esc(p.empresa)} · ${esc(st)}</p>${p.motivo?`<p class="mt-1 text-sm text-ink-2">${esc(p.motivo)}</p>`:''}${p.status==='aprovado'?`<p class="mt-1 text-sm text-ink-2">Valor: ${brl(pk?pk.preco:0)} (${pk?pk.dias:0} dias). O pagamento é feito pelo Mercado Pago${S.mp[S.mp.modo].tok?'':' (as chaves ainda não foram salvas no painel; aqui é só simulação)'}.</p><button type="button" id="ma-pay" class="btn-send mt-4 inline-flex h-12 items-center justify-center gap-2 rounded-full px-6 text-[15px] font-semibold">Pagar com Pix (simulação)</button>`:''}`;
   }
   sf.after(box);const pay=$('#ma-pay',scr);if(pay)pay.onclick=()=>{p.status='ativo';p.vence=Date.now()+(pack(p.pacoteId)?.dias||7)*DAY;ativar(p);reg(p,'Pagamento confirmado · anúncio no ar até '+fdate(p.vence));log('Pagamento confirmado (simulação): '+p.empresa);save();sf.requestSubmit()};
  })}
}
function fld(n,l,t='text',ph='',max=120,wide=false){return `<label class="block${wide?' md:col-span-2':''}"><span class="${LBL2}">${l}</span><input name="${n}" type="${t}" maxlength="${max}" placeholder="${esc(ph)}" class="${INP2}"${t==='url'?' value="https://"':''}></label>`}

