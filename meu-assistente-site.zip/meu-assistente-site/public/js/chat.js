/* Meu Assistente · Chat e interpretação das mensagens */
/* ---------- chat (/) ---------- */
const CARD=PARTS.card, ADCARD=PARTS.ad;
function userBubble(m){return `<div class="msg-swipe rise"><div class="msg-track flex flex-col items-end gap-1"><div class="flex w-full items-center justify-end gap-1"><div class="msg-bubble bubble-user max-w-[82%] rounded-[1.4rem] rounded-br-[0.5rem] px-4 pb-2 pt-2.5 text-[16px] leading-snug md:max-w-[70%]">${m.img?`<img src="${m.img}" alt="Imagem enviada" class="ma-img">`:''}${m.t?`<p class="whitespace-pre-wrap break-words">${esc(m.t)}</p>`:''}<p class="mt-0.5 flex items-center justify-end gap-1 text-[11.5px] leading-none text-white/65">${m.h}</p></div></div></div></div>`}
function botBubble(m){
 let extra='';
 if(m.card)extra=`<div class="flex w-full flex-col items-start gap-2.5">${fill(CARD,{titulo:esc(m.card.titulo),desc:esc(m.card.desc),valor:brl(m.card.valor),cat:esc(m.card.cat)})}</div>`;
 if(m.askLoc&&!m.askLoc.done)extra+=`<div class="flex w-full flex-col items-start gap-2.5" data-askloc="${m.id}">${locCard()}</div>`;
 if(m.link)extra+=`<div class="flex w-full flex-col items-start"><a href="${esc(m.link.href)}" class="btn-send inline-flex h-10 items-center rounded-full px-5 text-sm font-semibold">${esc(m.link.label)}</a></div>`;
 if(m.biz)extra+=bizBlock(m);
 if(m.chart&&S.modules.mercado)extra+=chatChart(m);
 if(m.market&&S.modules.mercado)extra+=chatMarket(m.market);
 if(m.ad){const a=S.propostas.find(p=>p.protocolo===m.ad);if(a&&S.modules.anuncios)extra+=`<div class="flex w-full flex-col items-start gap-2.5">${adHTML(a)}</div>`}
 return `<div class="msg-swipe rise"><div class="msg-track flex items-start"><div class="flex min-w-0 flex-1 flex-col items-start gap-2.5"><div class="flex w-full items-center gap-1"><div class="msg-bubble glass max-w-[90%] rounded-[1.4rem] rounded-tl-[0.5rem] px-4 pb-2 pt-3 md:max-w-[78%]"><p class="whitespace-pre-wrap break-words text-[16px] leading-[1.42] text-ink">${esc(m.t)}</p><p class="mt-1 flex items-center justify-end gap-3 text-[11.5px] leading-none text-ink-3">${m.via?esc(m.via)+' · ':''}${m.h}</p></div></div>${extra}</div></div></div>`}
function adHTML(a){let dom='';try{dom=new URL(a.link).hostname.replace(/^www\./,'')}catch(e){dom=a.link||''}
 return fill(ADCARD,{empresa:esc(a.empresa),titulo:esc(a.titulo),texto:esc(a.texto),dominio:esc(dom),link:esc(a.link||'#'),logo:a.logo?`<img src="${a.logo}" alt="" class="ma-adlogo">`:''})}
const norm=t=>String(t||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
const words=t=>new Set(norm(t).split(' ').filter(w=>w.length>2));
function sim(a,b){const A=words(a),B=words(b);if(!A.size||!B.size)return 0;let i=0;A.forEach(w=>{if(B.has(w))i++});return i/(A.size+B.size-i)}
function bestMatch(text){let best=null,sc=0;for(const r of S.brain.respostas){if(r.nota<0)continue;const v=r.norm===norm(text)?1:sim(text,r.pergunta);if(v>sc){sc=v;best=r}}return sc>=.75?best:null}
const isQuestion=t=>!/quanto gastei/i.test(t)&&(/\?\s*$/.test(t)||/^(o que|oque|como|qual|quais|quando|onde|por que|porque|quanto|quem|me explica|explique|me da uma dica|dica)/i.test(norm(t)));
function provState(p){if(!p.ativo)return['Desligada',''];if(p.id!=='ollama'&&!p.key)return['Sem chave',''];if(p.status==='expirada')return['Chave expirada','bad'];if(p.ate>Date.now())return[(p.status==='limite'?'No limite · volta em ':'Com erro · tenta em ')+Math.ceil((p.ate-Date.now())/1000)+'s','warn'];return['Pronta','ok']}
function usable(p,kind){return p.ativo&&(p.id==='ollama'||!!p.key)&&p.status!=='expirada'&&!(p.ate>Date.now())&&(kind==='imagem'?p.imagem:p.texto)}
function callChain(kind){const tried=[];for(const p of S.provs){if(!usable(p,kind))continue;if(p.simular){const f=p.simular;p.simular='';p.falhas++;
  if(f==='limite'){p.status='limite';p.ate=Date.now()+60000;p.erro='Limite gratuito atingido (erro 429).'}
  else if(f==='expirada'){p.status='expirada';p.erro='Chave inválida ou expirada (erro 401). Troque a chave para voltar.'}
  else{p.status='erro';p.ate=Date.now()+30000;p.erro='O serviço falhou (erro 500).'}
  tried.push(p.nome);log(p.nome+': '+p.erro+' Troca automática para a próxima IA.');continue}
 p.usos++;if(p.status!=='expirada'){p.status='ok';p.erro=''}return{p,tried}}return{p:null,tried}}
function localReply(t,img,p){
 const s=t.toLowerCase();
 if(img)return{t:'Simulação: o '+p.nome+' leu a imagem. No sistema real ele descreve o conteúdo e registra valores de comprovantes.'};
 const m=s.match(/(\d+(?:[.,]\d{1,2})?)/);
 if(/gastei|paguei|comprei/.test(s)&&m){if(!S.modules.financas)return{t:'O módulo Finanças está desligado no painel.'};const v=parseFloat(m[1].replace(',','.'));let d=(s.split(/ (?:de|com|no|na|em) /)[1]||'Outros').replace(/\b(hoje|ontem)\b/,'').trim();d=d.charAt(0).toUpperCase()+d.slice(1);const cats={mercado:'Mercado',gasolina:'Transporte',uber:'Transporte',almoço:'Alimentação',jantar:'Alimentação',lanche:'Alimentação',farmácia:'Saúde'};const cat=Object.entries(cats).find(([k])=>s.includes(k));return{t:'Pronto, registrei para você.',card:{titulo:'Gasto registrado!',desc:d||'Outros',valor:v,cat:cat?cat[1]:'Outros'}}}
 if(/lembr|marque|agend|reunião/.test(s)){if(!S.modules.lembretes)return{t:'O módulo Lembretes está desligado no painel.'};return{t:'Pronto, criei o lembrete. Vou te avisar no horário combinado.'}}
 if(/vence/.test(s)){if(!S.modules.financas)return{t:'O módulo Finanças está desligado no painel.'};return{t:'Conta registrada. Te aviso um dia antes do vencimento.'}}
 if(/lista|comprar|adicione/.test(s))return{t:'Adicionei os itens na sua lista de compras.'};
 if(/organizar|meu dia/.test(s))return{t:'Vamos lá. Me diga as três coisas mais importantes de hoje e eu monto a ordem para você.'};
 if(/quanto gastei/.test(s))return{t:'Neste teste não há gastos reais salvos. No sistema real eu somo os gastos do mês por categoria.'};
 if(isQuestion(t))return{t:'Resposta simulada do '+p.nome+' para “'+t.trim()+'”. No sistema real aqui vem a explicação completa da IA.'};
 return{t:'Entendi. Neste teste as respostas são simuladas.'};
}
function think(text,img){
 const B=S.brain;
 if(!img&&text){
  const fm=text.match(/^(?:lembre(?:-se)?|guarde|anote)\s+(?:que|de que)\s+(.+)/i)||(/(^|\s)(meu nome (é|e)|me chamo|eu gosto|eu prefiro|eu moro|eu trabalho|sou alérgic|sou alergic)/i.test(text)?[null,text]:null);
  if(fm&&B.fatos&&B.aprender){const f=fm[1].trim().replace(/[.!]+$/,'');if(!B.memorias.some(x=>norm(x.texto)===norm(f))){B.memorias.unshift({id:uid(),texto:f,origem:'chat',q:Date.now()});log('Cérebro guardou: '+f)}B.stats.cerebro++;return{t:'Guardei na memória: “'+f+'”. Vou levar isso em conta nas próximas conversas.',via:'Cérebro próprio'}}
  if(/qual (e |é )?(o )?meu nome|o que (voce|você) sabe (sobre|de) mim|do que eu gosto|o que eu gosto/i.test(text)){B.stats.cerebro++;return B.memorias.length?{t:'Isto é o que guardei sobre você:\n• '+B.memorias.slice(0,8).map(x=>x.texto).join('\n• '),via:'Cérebro próprio'}:{t:'Ainda não guardei nada sobre você. Me conte, por exemplo: “meu nome é…” ou “lembre que…”.',via:'Cérebro próprio'}}
  const loc=localIntent(text);if(loc)return loc;
  if(B.cerebroPrimeiro){const hit=bestMatch(text);if(hit){hit.usos++;B.stats.cerebro++;return{t:hit.resposta,via:'Cérebro próprio · '+(hit.revisada?'revisado por você':'aprendido com '+hit.via)}}}
 }
 const kind=img?'imagem':'texto', r0=callChain(kind);
 if(!r0.p)return{err:(r0.tried.length?'Todas as IAs falharam ('+r0.tried.join(', ')+'). ':'')+(img?'Nenhuma IA que lê imagens está pronta. Veja Administração → IA.':'Nenhuma IA está pronta agora. Veja Administração → IA.')};
 const r=localReply(text,img,r0.p);B.stats.ia++;
 if(!img&&B.aprender&&isQuestion(text)&&!r.card&&!bestMatch(text))B.respostas.unshift({id:uid(),pergunta:text.trim(),norm:norm(text),resposta:r.t,via:r0.p.nome,usos:0,nota:0,revisada:false,q:Date.now()});
 return{...r,via:r0.p.nome+(r0.tried.length?' · trocou após falha em '+r0.tried.join(', '):'')};
}
function viewApp(){
 const scr=mount('home');addMenuLinks(scr);
 if(!S.modules.voz)$$('[aria-label="Modo Voz"],[aria-label="Gravar mensagem de voz"]',scr).forEach(b=>b.style.display='none');
 if(!S.modules.imagens)$$('[aria-label^="Anexar"]',scr).forEach(b=>b.style.display='none');
 const inner=$('.chat-scroll > div',scr), welcome=inner&&inner.firstElementChild;
 const ta=$('textarea[data-composer-input]',scr), file=$('input[type=file]',scr);
 const composer=ta.closest('form')||ta.parentElement.parentElement;
 let errEl=document.createElement('p');errEl.className='ma-err';composer.parentElement.insertBefore(errEl,composer);
 function render(){
  if(!S.chat.length){if(welcome&&!welcome.isConnected)inner.replaceChildren(welcome);return}
  inner.innerHTML=`<div class="mt-auto flex flex-col gap-5 pb-2 pt-2">${S.chat.map(m=>m.r==='u'?userBubble(m):botBubble(m)).join('')}</div>`;
  const sc=$('.chat-scroll',scr);sc.scrollTop=sc.scrollHeight;
  $$('[data-crng]',inner).forEach(b=>b.onclick=()=>{const box=b.closest('[data-cc]'),m=S.chat.find(x=>x.id===box.dataset.cc);if(m){m.chart.range=b.dataset.crng;save();const top=sc.scrollTop;render();sc.scrollTop=top}});
  $$('[data-asset]',inner).forEach(b=>b.onclick=()=>openAtivo(b.dataset.asset));
  $$('[data-askloc]',inner).forEach(box=>{const m=S.chat.find(x=>x.id===box.dataset.askloc);$$('[data-loc]',box).forEach(b=>b.onclick=()=>{const go=()=>{m.askLoc.done=true;const rs=buscarEmpresas(m.askLoc.q,S.local.raio);S.chat.push(rs.length?{r:'a',id:uid(),t:'Pronto! Encontrei '+(rs.length===1?'esta opção':'estas opções')+' perto de você:',biz:{ids:rs.slice(0,6).map(r=>r.e.protocolo),raio:S.local.raio},via:'Busca de empresas',h:now()}:{r:'a',id:uid(),t:'Não encontrei empresas desse ramo perto de você.',via:'Busca de empresas',h:now()});save();render()};
   if(b.dataset.loc==='test'){usarLocalTeste();go();return}
   b.textContent='Aguardando permissão…';pedirLocal((ok,msg)=>{if(ok)go();else{S.chat.push({r:'a',id:uid(),t:msg+' Para ativar depois, libere a localização nas configurações do navegador. Por enquanto, você pode usar o local de teste.',askLoc:{q:m.askLoc.q},via:'Busca de empresas',h:now()});m.askLoc.done=true;save();render()}})})});
  $$('[data-cc]',inner).forEach(box=>{const m=S.chat.find(x=>x.id===box.dataset.cc);if(m){const pts=serieRange(m.chart.sym,m.chart.range||'24h');const lb=$('p.text-ink-3',box);const orig=lb.textContent;scrub(box,pts,m.chart.range||'24h',m.chart.sym,t=>lb.textContent=t||orig)}});
 }
 function send(text,img){
  text=(text||'').trim();if(!text&&!img)return;errEl.textContent='';
  if(img&&!S.modules.imagens){errEl.textContent='O envio de fotos está desligado no painel.';return}
  const rp=think(text,img);
  if(rp.err){errEl.textContent=rp.err;return}
  S.chat.push({r:'u',t:text,img:img||'',h:now()});
  const bots=S.chat.filter(m=>m.r==='a').length, ads=activeAds();
  if(S.modules.anuncios&&ads.length&&bots===1)rp.ad=ads[Math.floor(Math.random()*ads.length)].protocolo;
  S.chat.push({r:'a',...rp,id:uid(),h:now()});save();ta.value='';ta.classList.add('is-empty');const sb2=$('[aria-label="Enviar"]',scr);if(sb2)sb2.disabled=true;render();
 }
 $$('.chat-scroll button',scr).forEach(b=>{if(b.closest('.mt-7'))b.addEventListener('click',()=>send(b.textContent))});
 const sbtn=$('[aria-label="Enviar"]',scr);const syncBtn=()=>{ta.classList.toggle('is-empty',!ta.value);if(sbtn)sbtn.disabled=!ta.value.trim()};
 ta.addEventListener('input',syncBtn);syncBtn();
 ta.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send(ta.value)}});
 const sb=$('[aria-label="Enviar"]',scr);if(sb)sb.addEventListener('click',e=>{e.preventDefault();send(ta.value)});
 if(composer.tagName==='FORM')composer.addEventListener('submit',e=>{e.preventDefault();send(ta.value)});
 const at=$('[aria-label^="Anexar"]',scr);if(at&&file)at.addEventListener('click',e=>{e.preventDefault();file.click()});
 if(file){file.multiple=false;file.accept='image/*';file.addEventListener('change',async()=>{try{const img=await resizeImage(file.files[0],700);send(ta.value,img)}catch(err){errEl.textContent=err.message}file.value=''})}
 $$('[aria-label="Modo Voz"],[aria-label="Gravar mensagem de voz"]',scr).forEach(b=>b.addEventListener('click',e=>{e.preventDefault();toast('Simulação: no sistema real o áudio é gravado e transcrito.')}));
 $$('[aria-label="Opções"]',scr).forEach(b=>b.addEventListener('click',async()=>{if(S.chat.length&&await dlg('Limpar esta conversa de teste?',{ok:'Limpar',danger:true})){S.chat=[];save();render()}}));
 $$('[aria-label="Compartilhar aplicativo"]',scr).forEach(b=>b.addEventListener('click',()=>toast('Simulação: abriria o compartilhamento do app.')));
 render();
 const ped=sessionStorage.getItem('ma-pedido');if(ped){sessionStorage.removeItem('ma-pedido');send(ped)}
}

