/* Meu Assistente · Dados salvos no navegador */
function defaults(){return{
 modules:{catalogo:true,anuncios:true,financas:true,lembretes:true,imagens:true,voz:true,fiscal:true,mercado:true},
 mp:{modo:'teste',teste:{pub:'',tok:'',seg:''},producao:{pub:'',tok:'',seg:''},ok:{teste:false,producao:false}},
 ia:{geminiKey:'',imagens:'gemini',texto:'ollama',reserva:true},
 produtos:[{id:uid(),nome:'Agenda planner 2027',preco:49.9,categoria:'Papelaria',descricao:'Capa dura, 200 páginas, com metas mensais.',foto:''},{id:uid(),nome:'Consultoria de organização',preco:120,categoria:'Serviços',descricao:'1 hora por videochamada para montar sua rotina.',foto:''}],
 pacotes:[{id:'n1',nivel:1,nome:'Anúncio',dias:30,preco:29.9},{id:'n2',nivel:2,nome:'Anúncio + contato',dias:30,preco:49.9},{id:'n3',nivel:3,nome:'Página da empresa',dias:30,preco:79.9},{id:'n4',nivel:4,nome:'Loja completa',dias:30,preco:129.9}],
 propostas:[{protocolo:'AN-'+new Date().toISOString().slice(0,10).replace(/-/g,'')+'-'+uid(),empresa:'Barbearia Central',contato:'Carlos Lima',email:'contato@barbeariacentral.com.br',whatsapp:'+55 11 98888-7777',pacoteId:'n3',categoria:'Barbearia',tags:'barbearia cabelo',titulo:'Corte + barba por R$ 45',texto:'Agende pelo WhatsApp e ganhe 10% na primeira visita.',link:'https://barbeariacentral.com.br',logo:'',status:'analise',criado:Date.now(),vence:0,motivo:'',zap:'5511988887777',insta:'barbeariacentral',endereco:'Rua Direita, 45',horario:'Seg a sáb',sobre:'Proposta de exemplo aguardando aprovação.',cor:'#495057'},...seedEmpresas()],
 chat:[], atividades:[], pedidos:[], seqPedido:100, carrinho:null, local:{lat:CENTRO.lat,lng:CENTRO.lng,label:CENTRO.label,raio:15,consent:'ask'},
 provs:mkProvs(),
 mkt:mkMkt(),
 fiscal:{consent:false,atividade:'comercio',abertura:'',limite:81000,sm:1621,pagos:{},receitas:{},avisos:{das:true,dias:3,dasn:true,irpf:true}},
 mercado:{aba:'cripto',alertas:[]},
 brain:{aprender:true,cerebroPrimeiro:true,fatos:true,memorias:[],respostas:[],stats:{cerebro:0,ia:0}}
}}
function load(){try{const s=JSON.parse(localStorage.getItem(KEY));if(s&&s.modules){const d=defaults();const o={...d,...s,modules:{...d.modules,...s.modules},mp:{...d.mp,...s.mp},ia:{...d.ia,...s.ia},brain:{...d.brain,...(s.brain||{}),stats:{...d.brain.stats,...((s.brain||{}).stats||{})}},fiscal:{...d.fiscal,...(s.fiscal||{}),avisos:{...d.fiscal.avisos,...((s.fiscal||{}).avisos||{})}},mercado:{...d.mercado,...(s.mercado||{})},mkt:Array.isArray(s.mkt)?s.mkt:mkMkt()};
 if(!Array.isArray(s.provs)){o.provs=mkProvs();if(o.ia.geminiKey){const g=o.provs.find(p=>p.id==='gemini');g.key=o.ia.geminiKey;g.status='ok'}}
 else{const ids=o.provs.map(p=>p.id);mkProvs().forEach(p=>{if(!ids.includes(p.id))o.provs.push(p)})}
 return o}}catch(e){}return defaults()}
let S=load();
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('O navegador ficou sem espaço. Use imagens menores.')}}
function log(t){S.atividades.unshift({t,q:Date.now()});S.atividades=S.atividades.slice(0,60);save()}
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3200)}
const mask=k=>k?k.slice(0,9)+'••••••'+k.slice(-4):'';
const MP_RE=/^(APP_USR|TEST)-[\w-]{20,}$/;
const activeAds=()=>S.propostas.filter(p=>p.status==='ativo'&&p.vence>Date.now());
const pack=id=>S.pacotes.find(p=>p.id===id);
function resizeImage(file,max=600){return new Promise((res,rej)=>{if(!file||!file.type.startsWith('image/'))return rej(new Error('Escolha uma imagem.'));const r=new FileReader();r.onerror=()=>rej(new Error('Não consegui abrir a imagem.'));r.onload=()=>{const im=new Image();im.onload=()=>{const sc=Math.min(1,max/Math.max(im.width,im.height));const c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.82))};im.onerror=()=>rej(new Error('Imagem inválida.'));im.src=r.result};r.readAsDataURL(file)})}
const fill=(tpl,o)=>tpl.replace(/\{\{(\w+)\}\}/g,(m,k)=>o[k]??'');
function setAppH(){document.documentElement.style.setProperty('--nx-app-h',window.innerHeight+'px')}
addEventListener('resize',setAppH);setAppH();

