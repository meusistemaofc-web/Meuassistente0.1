/* Meu Assistente · Painel de administração */
/* ---------- administração ---------- */
let tab='usuarios', usersHTML='';
const TABS=[['usuarios','Usuários'],['atividades','Atividades'],['modulos','Módulos'],['pagamentos','Mercado Pago'],['ia','IA'],['fontes','Fontes de mercado'],['cerebro','Cérebro do Chat'],['empresas','Empresas'],['anuncios','Anúncios']];
function viewAdmin(){
 const scr=mount('admin');addMenuLinks(scr);
 const bar=$$('div.glass.no-scrollbar',scr).find(d=>/Usuários/.test(d.textContent));
 const sec=bar&&bar.nextElementSibling; if(!sec)return;
 if(!usersHTML)usersHTML=sec.outerHTML;
 const pend=S.propostas.filter(p=>p.status==='analise').length;
 bar.innerHTML=TABS.map(([k,l])=>`<button type="button" data-t="${k}" class="flex h-9 shrink-0 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold transition ${tab===k?'btn-send':'text-ink-2 hover:text-ink'}">${l}${k==='anuncios'&&pend?`<span class="rounded-full px-1.5 text-[10px] tabular ${tab===k?'bg-white/20':'bg-surface-2'}">${pend}</span>`:''}</button>`).join('');
 $$('[data-t]',bar).forEach(b=>b.onclick=()=>{tab=b.dataset.t;viewAdmin()});
 const pane=document.createElement('section');pane.className='grid gap-4';pane.id='ma-pane';
 if(tab==='usuarios'){sec.outerHTML=usersHTML;$$('#screen section.grid.gap-4 button.flex.w-full').forEach(b=>b.onclick=()=>toast('No teste, a edição de usuários fica no sistema real.'));const nv=$$('#screen section.grid.gap-4 button').find(b=>/Novo/.test(b.textContent));if(nv)nv.onclick=()=>toast('No teste, a criação de usuários fica no sistema real.');return}
 sec.replaceWith(pane);
 ({atividades:pAtiv,modulos:pMod,pagamentos:pPag,ia:pIA,fontes:pFontes,cerebro:pBrain,empresas:pEmp,anuncios:pAds})[tab](pane);
}
const card=inner=>`<div class="glass rounded-[1.6rem] overflow-hidden"><div class="divide-y divide-line">${inner}</div></div>`;
const row=(t,d,right)=>`<div class="flex items-center gap-4 px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${t}</p>${d?`<p class="mt-0.5 text-xs text-ink-3">${d}</p>`:''}</div>${right||''}</div>`;
const sw=(id,on,l)=>`<button type="button" role="switch" aria-checked="${on}" aria-label="${esc(l)}" data-sw="${id}" class="nx-switch"><span class="nx-switch-knob"></span></button>`;
const pill=(t,k)=>`<span class="ma-pill ma-${k} shrink-0 rounded-full border px-3 py-1 text-xs font-semibold">${t}</span>`;
function pAtiv(p){p.innerHTML=`<div class="flex justify-end"><button type="button" id="ma-reset" class="${DAN} h-10">Apagar dados de teste</button></div>`+card(S.atividades.length?S.atividades.map(a=>row(esc(a.t),new Date(a.q).toLocaleString('pt-BR'))).join(''):`<div class="px-5 py-6 text-sm text-ink-3">As ações feitas neste teste aparecem aqui.</div>`)}
const MODS=[['catalogo','Lojas e pedidos','Catálogo e pedidos das empresas com plano Loja completa.'],['anuncios','Anúncios','Cartões patrocinados no chat e página Anunciar.'],['financas','Finanças','Gastos, contas e vencimentos.'],['lembretes','Lembretes','Avisos e compromissos.'],['imagens','Fotos e arquivos','Envio de imagens e comprovantes no chat.'],['voz','Voz','Mensagens de voz e Modo Voz.'],['fiscal','Impostos e DAS','DAS do MEI, limite de faturamento e declarações.'],['mercado','Mercado','Cotações de criptomoedas e da bolsa, com alertas.']];
function pMod(p){
 p.innerHTML=`<div><h2 class="${H2}">Módulos globais</h2>${card(MODS.map(([k,n,d])=>row(n,d,sw(k,S.modules[k],n))).join(''))}<p class="mt-3 px-1 text-xs text-ink-3">Um módulo desligado some para todos os usuários. Desligue e abra o chat para conferir.</p></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const k=b.dataset.sw;S.modules[k]=!S.modules[k];b.setAttribute('aria-checked',S.modules[k]);log('Módulo '+MODS.find(m=>m[0]===k)[1]+(S.modules[k]?' ligado':' desligado'));save()});
}
function pPag(p){
 const m=S.mp.modo,c=S.mp[m],ok=S.mp.ok[m];
 const st=!c.tok?pill('Não configurado','warn'):ok?pill('Conectado','ok'):pill('Não testado','warn');
 p.innerHTML=`<div><h2 class="${H2}">Mercado Pago</h2>
 <div class="glass no-scrollbar mb-4 flex w-fit gap-1 rounded-full p-1">${[['teste','Modo teste'],['producao','Produção']].map(([k,l])=>`<button type="button" data-m="${k}" class="flex h-9 shrink-0 items-center rounded-full px-4 text-[13px] font-semibold transition ${m===k?'btn-send':'text-ink-2 hover:text-ink'}">${l}</button>`).join('')}</div>
 <div class="glass rounded-[1.6rem] overflow-hidden"><div class="flex items-center gap-3 border-b border-line px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">Status da conexão · ${m==='teste'?'Teste':'Produção'}</p><p class="mt-0.5 text-xs text-ink-3">${c.tok?'Credenciais salvas.':'Salve o Access Token e teste a conexão.'}</p></div>${st}</div>
 <div class="grid gap-1 px-5 py-4 text-sm">${kv('Access Token',c.tok?mask(c.tok):'Nenhum')}${kv('Chave pública',c.pub?mask(c.pub):'Nenhuma')}${kv('Segredo dos Webhooks',c.seg?'••••••'+c.seg.slice(-4):'Nenhum')}</div>
 <div class="grid gap-3 border-t border-line px-5 py-4">
  <label class="block"><span class="text-xs text-ink-3">Access Token</span><input id="mp_tok" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${c.tok?'Cole outro para trocar':(m==='teste'?'TEST-…':'APP_USR-…')}"></label>
  <label class="block"><span class="text-xs text-ink-3">Chave pública (Public Key)</span><input id="mp_pub" autocomplete="off" class="${INP} mt-1" value="${esc(c.pub)}" placeholder="${m==='teste'?'TEST-…':'APP_USR-…'}"></label>
  <label class="block"><span class="text-xs text-ink-3">Segredo dos Webhooks</span><input id="mp_seg" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${c.seg?'Cole outro para trocar':'Opcional'}"></label>
  <p class="ma-err" id="mp_msg"></p>
  <div class="flex flex-wrap gap-2"><button type="button" id="mp_save" class="${PRI}">Salvar</button><button type="button" id="mp_test" class="${GHO}">Testar conexão</button>${c.tok||c.pub?`<button type="button" id="mp_clear" class="${DAN}">Remover</button>`:''}</div>
 </div></div>
 <div class="glass mt-4 rounded-[1.6rem] p-5"><p class="text-[15px] font-medium">URL de notificação (webhook)</p><p class="mt-0.5 text-xs text-ink-3">Cole no painel do Mercado Pago em Suas integrações → Webhooks.</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">https://meuassistente.ivaslovck.tech/api/mercadopago/webhook</code></div>
 <p class="mt-3 px-1 text-xs text-ink-3">No sistema real o Access Token fica só no servidor e nunca volta inteiro para a tela.</p></div>`;
 $$('[data-m]',p).forEach(b=>b.onclick=()=>{S.mp.modo=b.dataset.m;save();pPag(p)});
 const msg=(t,good)=>{const e=$('#mp_msg',p);e.textContent=t;e.className=good?'ma-ok':'ma-err'};
 $('#mp_save',p).onclick=()=>{const tok=$('#mp_tok',p).value.trim(),pub=$('#mp_pub',p).value.trim(),seg=$('#mp_seg',p).value.trim();
  if(tok&&!MP_RE.test(tok))return msg('O Access Token começa com TEST- (teste) ou APP_USR- (produção).');
  if(pub&&!MP_RE.test(pub))return msg('A chave pública começa com TEST- ou APP_USR-.');
  if(!tok&&!c.tok)return msg('Cole o Access Token.');
  if(tok)c.tok=tok;c.pub=pub;if(seg)c.seg=seg;S.mp.ok[m]=false;log('Credenciais do Mercado Pago salvas ('+(m==='teste'?'teste':'produção')+')');save();pPag(p);toast('Credenciais salvas')};
 $('#mp_test',p).onclick=()=>{if(!c.tok)return msg('Salve o Access Token antes de testar.');const good=MP_RE.test(c.tok)&&(m!=='teste'||c.tok.startsWith('TEST-')||c.tok.startsWith('APP_USR-'));S.mp.ok[m]=good;save();pPag(p);toast(good?'Formato válido. No sistema real o servidor confirma com o Mercado Pago.':'Credencial inválida.')};
 if($('#mp_clear',p))$('#mp_clear',p).onclick=async()=>{if(await dlg('Remover as credenciais deste modo?',{ok:'Remover',danger:true})){S.mp[m]={pub:'',tok:'',seg:''};S.mp.ok[m]=false;log('Credenciais do Mercado Pago removidas');save();pPag(p)}};
}
const kv=(l,v)=>`<p class="flex justify-between gap-3"><span class="text-ink-3">${l}</span><span class="text-right tabular text-ink-2">${esc(v)}</span></p>`;
let openProv='';
function pIA(p){
 const minis=(pv,k,l)=>`<button type="button" data-cap="${pv.id}:${k}" class="flex h-8 shrink-0 items-center rounded-full px-3 text-[12.5px] font-semibold transition ${pv[k]?'btn-send':'border border-line-strong text-ink-2 hover:text-ink'}">${l}</button>`;
 const list=S.provs.map((pv,i)=>{const [st,k]=provState(pv),open=openProv===pv.id;
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-pv="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium"><span class="tabular text-ink-3">${i+1}.</span> ${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${pv.texto?'Texto':''}${pv.texto&&pv.imagem?' e ':''}${pv.imagem?'imagens':''}${!pv.texto&&!pv.imagem?'Sem uso':''} · ${pv.usos} respostas · ${pv.falhas} falhas</p></button>${pill(st,k)}${sw('pv:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${open?`<div class="mt-3 grid gap-3">
   <p class="text-xs text-ink-3">${esc(pv.onde)}</p>
   ${pv.id!=='ollama'?`<label class="block"><span class="text-xs text-ink-3">Chave ${pv.key?'(salva: '+esc(mask(pv.key))+')':''}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.key?'Cole outra para trocar':'Cole a chave aqui'}"></label>`:''}
   ${pv.id==='custom'?`<label class="block"><span class="text-xs text-ink-3">Endereço da API</span><input data-f="url" class="${INP} mt-1" value="${esc(pv.url)}" placeholder="https://…/v1"></label>`:''}
   <label class="block"><span class="text-xs text-ink-3">Modelo</span><input data-f="modelo" class="${INP} mt-1" value="${esc(pv.modelo)}" placeholder="Nome do modelo no serviço"></label>
   <div><p class="mb-1.5 text-xs text-ink-3">Usar para</p><div class="flex flex-wrap gap-2">${minis(pv,'texto','Texto')}${minis(pv,'imagem','Ler imagens')}</div></div>
   ${pv.erro?`<p class="text-xs text-danger">Último erro: ${esc(pv.erro)}</p>`:''}
   <div class="flex flex-wrap gap-2"><button type="button" data-save="${pv.id}" class="${PRI} h-10">Salvar</button><button type="button" data-up="${pv.id}" class="${GHO} h-10" ${i===0?'disabled':''}>Subir</button><button type="button" data-down="${pv.id}" class="${GHO} h-10" ${i===S.provs.length-1?'disabled':''}>Descer</button>${pv.status!=='ok'&&(pv.id==='ollama'||pv.key)?`<button type="button" data-reset="${pv.id}" class="${GHO} h-10">Reativar</button>`:''}${pv.id!=='ollama'&&pv.key?`<button type="button" data-del="${pv.id}" class="${DAN} h-10">Remover chave</button>`:''}</div>
   <label class="block"><span class="text-xs text-ink-3">Teste de troca automática</span><select data-sim="${pv.id}" class="${INP} mt-1"><option value="">Funcionar normalmente</option><option value="limite" ${pv.simular==='limite'?'selected':''}>Na próxima mensagem: atingir o limite</option><option value="expirada" ${pv.simular==='expirada'?'selected':''}>Na próxima mensagem: chave expirada</option><option value="erro" ${pv.simular==='erro'?'selected':''}>Na próxima mensagem: erro no serviço</option></select></label>
  </div>`:''}</div>`}).join('');
 p.innerHTML=`<div><h2 class="${H2}">Inteligências artificiais</h2>
 <div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira IA <b class="text-ink">pronta</b> da lista responde. Se ela atingir o limite, a chave expirar ou der erro, a próxima assume na hora, sem o usuário perceber. Limite e erro voltam sozinhos depois de um tempo; chave expirada fica parada até você colar uma nova. Deixe o Ollama da VPS por último: ele nunca para.</div>
 ${card(list)}<p class="mt-3 px-1 text-xs text-ink-3">Toque no nome de uma IA para colar a chave, escolher o modelo e mudar a ordem.</p></div>`;
 $$('[data-pv]',p).forEach(b=>b.onclick=()=>{openProv=openProv===b.dataset.pv?'':b.dataset.pv;pIA(p)});
 const pv=id=>S.provs.find(x=>x.id===id);
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.sw.slice(3));x.ativo=!x.ativo;log(x.nome+(x.ativo?' ligada':' desligada'));save();pIA(p)});
 $$('[data-cap]',p).forEach(b=>b.onclick=()=>{const [id,k]=b.dataset.cap.split(':');const x=pv(id);x[k]=!x[k];save();pIA(p)});
 $$('[data-save]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.save),box=b.closest('.grid');const key=$('[data-f=key]',box),url=$('[data-f=url]',box),mod=$('[data-f=modelo]',box);
  if(key&&key.value.trim()){if(key.value.trim().length<10)return toast('A chave parece incompleta.');x.key=key.value.trim();x.status='ok';x.ate=0;x.erro=''}
  if(url){if(url.value.trim()&&!/^https?:\/\/\S+/.test(url.value.trim()))return toast('O endereço precisa começar com https://');x.url=url.value.trim()}
  x.modelo=mod.value.trim();log(x.nome+': configuração salva');save();pIA(p);toast(x.nome+' salva')});
 const mv=(id,d)=>{const i=S.provs.findIndex(x=>x.id===id),j=i+d;if(j<0||j>=S.provs.length)return;[S.provs[i],S.provs[j]]=[S.provs[j],S.provs[i]];log('Ordem das IAs alterada');save();pIA(p)};
 $$('[data-up]',p).forEach(b=>b.onclick=()=>mv(b.dataset.up,-1));$$('[data-down]',p).forEach(b=>b.onclick=()=>mv(b.dataset.down,1));
 $$('[data-reset]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.reset);x.status='ok';x.ate=0;x.erro='';save();pIA(p)});
 $$('[data-del]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.del);x.key='';x.status='sem_chave';log(x.nome+': chave removida');save();pIA(p)});
 $$('[data-sim]',p).forEach(sl=>sl.onchange=()=>{pv(sl.dataset.sim).simular=sl.value;save();if(sl.value)toast('Agora mande uma mensagem no chat para ver a troca automática.')});
}
let openMkt='';
function pFontes(p){
 const bloco=cat=>card(S.mkt.filter(x=>x.cat===cat).map(pv=>{const st=!pv.ativo?['Desligada','']:pv.precisaChave&&!pv.key?['Sem chave','']:pv.status==='expirada'?['Chave inválida','bad']:pv.ate>Date.now()?[(pv.status==='limite'?'No limite · volta em ':'Com erro · tenta em ')+Math.ceil((pv.ate-Date.now())/1000)+'s','warn']:['Pronta','ok'];const op=openMkt===pv.id,idx=S.mkt.filter(x=>x.cat===cat).indexOf(pv);
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-mo="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium"><span class="tabular text-ink-3">${idx+1}.</span> ${esc(pv.nome)}${pv.custom?' · personalizada':''}</p><p class="mt-0.5 text-xs text-ink-3">${esc(pv.info)} · ${pv.usos} consultas · ${pv.falhas} falhas</p></button>${pill(st[0],st[1])}${sw('mk:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${op?`<div class="mt-3 grid gap-3">${pv.precisaChave||pv.custom?`<label class="block"><span class="text-xs text-ink-3">Chave ${pv.key?'(salva: '+esc(mask(pv.key))+')':pv.precisaChave?'':'(opcional)'}</span><input data-mf="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.key?'Cole outra para trocar':'Cole a chave'}"></label>`:`<label class="block"><span class="text-xs text-ink-3">Chave opcional ${pv.key?'(salva)':''}</span><input data-mf="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="Deixe em branco para usar sem chave"></label>`}
   <label class="block"><span class="text-xs text-ink-3">Endereço da consulta</span><input data-mf="url" class="${INP} mt-1" value="${esc(pv.url)}" ${pv.custom?'':'readonly'}></label>
   ${pv.custom?`<label class="block"><span class="text-xs text-ink-3">Onde está o preço na resposta (caminho JSON)</span><input data-mf="campo" class="${INP} mt-1" value="${esc(pv.campo)}" placeholder="Ex.: data.price ou results.0.regularMarketPrice"></label>`:''}
   ${pv.erro?`<p class="text-xs text-danger">Último erro: ${esc(pv.erro)}</p>`:''}
   <div class="flex flex-wrap gap-2"><button type="button" data-ms="${pv.id}" class="${PRI} h-10">Salvar</button><button type="button" data-mu="${pv.id}" class="${GHO} h-10" ${idx===0?'disabled':''}>Subir</button><button type="button" data-md="${pv.id}" class="${GHO} h-10">Descer</button>${pv.status!=='ok'?`<button type="button" data-mr="${pv.id}" class="${GHO} h-10">Reativar</button>`:''}${pv.custom?`<button type="button" data-mx="${pv.id}" class="${DAN} h-10">Excluir</button>`:''}</div>
   <label class="block"><span class="text-xs text-ink-3">Teste de troca automática</span><select data-msim="${pv.id}" class="${INP} mt-1"><option value="">Funcionar normalmente</option><option value="limite" ${pv.simular==='limite'?'selected':''}>Na próxima consulta: atingir o limite</option><option value="expirada" ${pv.simular==='expirada'?'selected':''}>Na próxima consulta: chave inválida</option><option value="erro" ${pv.simular==='erro'?'selected':''}>Na próxima consulta: serviço fora do ar</option></select></label></div>`:''}</div>`}).join(''));
 p.innerHTML=`<div><h2 class="${H2}">Fontes de mercado</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira fonte <b class="text-ink">pronta</b> de cada lista é usada. Se ela atingir o limite, a chave falhar ou sair do ar, a próxima assume na hora. Todas as fontes abaixo têm uso gratuito.</div>
 <h2 class="${H2}">Criptomoedas</h2>${bloco('cripto')}<h2 class="${H2} mt-8">Ações da B3</h2>${bloco('bolsa')}
 <h2 class="${H2} mt-8">Cadastrar nova fonte</h2><div class="glass rounded-[1.6rem] p-5 grid gap-3 md:grid-cols-2">
 <label class="block"><span class="text-xs text-ink-3">Nome</span><input id="nf_n" class="${INP} mt-1" placeholder="Ex.: Minha API de cotações"></label>
 <label class="block"><span class="text-xs text-ink-3">Tipo</span><select id="nf_c" class="${INP} mt-1"><option value="cripto">Criptomoedas</option><option value="bolsa">Ações da B3</option></select></label>
 <label class="block md:col-span-2"><span class="text-xs text-ink-3">Endereço (use {SIMBOLO}, {id} e {chave} onde precisar)</span><input id="nf_u" class="${INP} mt-1" placeholder="https://api.exemplo.com/quote/{SIMBOLO}?key={chave}"></label>
 <label class="block"><span class="text-xs text-ink-3">Caminho do preço na resposta</span><input id="nf_f" class="${INP} mt-1" placeholder="data.price"></label>
 <label class="block"><span class="text-xs text-ink-3">Chave (se precisar)</span><input id="nf_k" type="password" class="${INP} mt-1"></label>
 <p class="ma-err md:col-span-2" id="nf_err"></p><div class="md:col-span-2"><button type="button" id="nf_add" class="${PRI} h-10">Cadastrar fonte</button></div></div>
 <p class="mt-3 px-1 text-xs text-ink-3">No teste os preços são ilustrativos e as consultas são simuladas. No sistema real, o servidor consulta essas fontes, guarda o resultado por alguns minutos para não gastar o limite e troca de fonte automaticamente.</p></div>`;
 const pv=id=>S.mkt.find(x=>x.id===id);
 $$('[data-mo]',p).forEach(b=>b.onclick=()=>{openMkt=openMkt===b.dataset.mo?'':b.dataset.mo;pFontes(p)});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.sw.slice(3));x.ativo=!x.ativo;log('Fonte '+x.nome+(x.ativo?' ligada':' desligada'));save();pFontes(p)});
 $$('[data-ms]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.ms),box=b.closest('.grid');const k=$('[data-mf=key]',box),u=$('[data-mf=url]',box),c=$('[data-mf=campo]',box);if(k&&k.value.trim()){x.key=k.value.trim();x.status='ok';x.ate=0;x.erro=''}if(x.custom){if(!/^https:\/\/\S+/.test(u.value.trim()))return toast('O endereço precisa começar com https://');x.url=u.value.trim();if(c)x.campo=c.value.trim()}log('Fonte '+x.nome+' salva');save();pFontes(p);toast('Salvo')});
 const mv=(id,d)=>{const x=pv(id),same=S.mkt.filter(y=>y.cat===x.cat),i=same.indexOf(x),j=i+d;if(j<0||j>=same.length)return;const a=S.mkt.indexOf(same[i]),b2=S.mkt.indexOf(same[j]);[S.mkt[a],S.mkt[b2]]=[S.mkt[b2],S.mkt[a]];save();pFontes(p)};
 $$('[data-mu]',p).forEach(b=>b.onclick=()=>mv(b.dataset.mu,-1));$$('[data-md]',p).forEach(b=>b.onclick=()=>mv(b.dataset.md,1));
 $$('[data-mr]',p).forEach(b=>b.onclick=()=>{const x=pv(b.dataset.mr);x.status='ok';x.ate=0;x.erro='';save();pFontes(p)});
 $$('[data-mx]',p).forEach(b=>b.onclick=async()=>{if(await dlg('Excluir esta fonte?',{ok:'Excluir',danger:true})){S.mkt=S.mkt.filter(x=>x.id!==b.dataset.mx);save();pFontes(p)}});
 $$('[data-msim]',p).forEach(sl=>sl.onchange=()=>{pv(sl.dataset.msim).simular=sl.value;save();if(sl.value)toast('Agora abra Mercado ou pergunte uma cotação no chat.')});
 $('#nf_add',p).onclick=()=>{const n=$('#nf_n',p).value.trim(),u=$('#nf_u',p).value.trim(),f=$('#nf_f',p).value.trim();if(!n||!/^https:\/\/\S+/.test(u)||!f)return $('#nf_err',p).textContent='Preencha nome, endereço com https:// e o caminho do preço.';S.mkt.push({id:'c'+uid(),nome:n,cat:$('#nf_c',p).value,precisaChave:false,info:'Fonte cadastrada por você',url:u,campo:f,key:$('#nf_k',p).value.trim(),ativo:true,status:'ok',ate:0,erro:'',usos:0,falhas:0,simular:'',custom:true});log('Nova fonte de mercado: '+n);save();pFontes(p);toast('Fonte cadastrada')};
}
let editAns='';
function pBrain(p){
 const B=S.brain,st=B.stats,tot=st.cerebro+st.ia,pc=tot?Math.round(st.cerebro*100/tot):0;
 const ans=B.respostas.map(r=>`<div class="px-5 py-4"><p class="text-[15px] font-medium">${esc(r.pergunta)}</p>
  ${editAns===r.id?`<textarea data-ed="${r.id}" rows="3" class="${INP} ma-ta mt-2">${esc(r.resposta)}</textarea><div class="mt-2 flex gap-2"><button type="button" data-sv="${r.id}" class="${PRI} h-10">Salvar correção</button><button type="button" data-cx class="${GHO} h-10">Cancelar</button></div>`:`<p class="mt-1 text-[13.5px] leading-snug text-ink-2">${esc(r.resposta)}</p>`}
  <p class="mt-1.5 text-xs text-ink-3">${r.revisada?'Revisada por você':'Aprendida com '+esc(r.via)} · usada ${r.usos}x${r.nota<0?' · desativada':''}</p>
  <div class="mt-2 flex flex-wrap gap-3 text-[13px] font-semibold"><button type="button" data-up="${r.id}" class="${r.nota>0?'text-accent':'text-ink-2'}">Boa resposta</button><button type="button" data-dn="${r.id}" class="${r.nota<0?'text-danger':'text-ink-2'}">Ruim, não usar</button><button type="button" data-eda="${r.id}" class="text-ink-2">Corrigir</button><button type="button" data-rm="${r.id}" class="text-danger">Excluir</button></div></div>`).join('');
 p.innerHTML=`<div><h2 class="${H2}">Cérebro do Chat</h2>
 <div class="glass rounded-[1.6rem] p-5"><div class="grid grid-cols-3 gap-3 text-center"><div><p class="text-[1.6rem] font-bold tabular">${st.cerebro}</p><p class="text-xs text-ink-3">pelo cérebro</p></div><div><p class="text-[1.6rem] font-bold tabular">${st.ia}</p><p class="text-xs text-ink-3">pelas IAs</p></div><div><p class="text-[1.6rem] font-bold tabular text-accent">${pc}%</p><p class="text-xs text-ink-3">sem gastar IA</p></div></div>
 <p class="mt-3 text-xs leading-relaxed text-ink-3">Quanto mais o assistente conversa, mais ele responde sozinho com o que já aprendeu, e menos depende dos limites das IAs grátis.</p></div>
 <div class="mt-4">${card(row('Aprender com as conversas','Guarda as boas respostas das IAs para reutilizar.',sw('aprender',B.aprender,'Aprender'))+row('Responder pelo cérebro primeiro','Se já sabe a resposta, não chama nenhuma IA.',sw('cerebroPrimeiro',B.cerebroPrimeiro,'Cérebro primeiro'))+row('Guardar fatos sobre o usuário','“Meu nome é…”, “lembre que…”, preferências.',sw('fatos',B.fatos,'Guardar fatos')))}</div>
 <h2 class="${H2} mt-8">Motores do chat</h2>
 ${card(motores().map(([n,on,info,ex])=>row(n,info+' · '+ex,pill(on?'Ativo':'Desligado',on?'ok':''))).join(''))}
 <p class="mt-2 px-1 text-xs text-ink-3">Cada coisa cadastrada no painel vira um motor: o chat tenta primeiro os motores do próprio app e só chama uma IA quando nenhum resolve. Liga e desliga em Módulos.</p>
 <h2 class="${H2} mt-8">Memória sobre você</h2>
 ${card((B.memorias.map(m=>row(esc(m.texto),(m.origem==='chat'?'Aprendido no chat':'Adicionado por você')+' · '+fdate(m.q),`<button type="button" data-mr="${m.id}" class="text-[13px] font-semibold text-danger">Excluir</button>`)).join('')||`<div class="px-5 py-5 text-sm text-ink-3">Nada guardado ainda. No chat, diga “meu nome é…” ou “lembre que…”.</div>`)+`<div class="flex gap-2 px-5 py-4"><input id="b_mem" class="${INP}" placeholder="Ex.: Prefere respostas curtas"><button type="button" id="b_madd" class="${PRI} h-10 shrink-0">Adicionar</button></div>`)}
 <h2 class="${H2} mt-8">Conhecimento aprendido</h2>
 ${card(ans||`<div class="px-5 py-5 text-sm text-ink-3">Faça uma pergunta no chat (ex.: “como economizar no mercado?”). Na segunda vez que perguntar algo parecido, o cérebro responde sozinho.</div>`)}
 <div class="glass mt-4 rounded-[1.6rem] p-5"><p class="text-[15px] font-medium">Ensinar o cérebro</p><p class="mt-0.5 text-xs text-ink-3">Escreva uma pergunta e a resposta certa. Ela passa a valer na hora.</p>
 <input id="b_q" class="${INP} mt-3" placeholder="Pergunta, ex.: Qual o horário de atendimento?"><textarea id="b_a" rows="3" class="${INP} ma-ta mt-2" placeholder="Resposta"></textarea><div class="mt-3"><button type="button" id="b_teach" class="${PRI} h-10">Ensinar</button></div></div></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const k=b.dataset.sw;B[k]=!B[k];b.setAttribute('aria-checked',B[k]);save()});
 const R=id=>B.respostas.find(x=>x.id===id);
 $$('[data-up]',p).forEach(b=>b.onclick=()=>{R(b.dataset.up).nota=1;save();pBrain(p)});
 $$('[data-dn]',p).forEach(b=>b.onclick=()=>{R(b.dataset.dn).nota=-1;log('Cérebro: resposta desativada');save();pBrain(p)});
 $$('[data-eda]',p).forEach(b=>b.onclick=()=>{editAns=b.dataset.eda;pBrain(p)});
 $$('[data-cx]',p).forEach(b=>b.onclick=()=>{editAns='';pBrain(p)});
 $$('[data-sv]',p).forEach(b=>b.onclick=()=>{const r=R(b.dataset.sv),v=$('[data-ed]',p).value.trim();if(!v)return;r.resposta=v;r.revisada=true;r.nota=1;editAns='';log('Cérebro: resposta corrigida');save();pBrain(p)});
 $$('[data-rm]',p).forEach(b=>b.onclick=()=>{B.respostas=B.respostas.filter(x=>x.id!==b.dataset.rm);save();pBrain(p)});
 $$('[data-mr]',p).forEach(b=>b.onclick=()=>{B.memorias=B.memorias.filter(x=>x.id!==b.dataset.mr);save();pBrain(p)});
 $('#b_madd',p).onclick=()=>{const v=$('#b_mem',p).value.trim();if(!v)return;B.memorias.unshift({id:uid(),texto:v,origem:'admin',q:Date.now()});save();pBrain(p)};
 $('#b_teach',p).onclick=()=>{const q=$('#b_q',p).value.trim(),a=$('#b_a',p).value.trim();if(!q||!a)return toast('Preencha a pergunta e a resposta.');B.respostas.unshift({id:uid(),pergunta:q,norm:norm(q),resposta:a,via:'você',usos:0,nota:1,revisada:true,q:Date.now()});log('Cérebro aprendeu: '+q);save();pBrain(p);toast('Aprendido')};
}
function pAds(p){
 const ST={analise:['Em análise','warn'],ajustes:['Ajustes pedidos','warn'],recusado:['Recusada','bad'],aprovado:['Aguardando pagamento','info'],ativo:['No ar','ok'],vencido:['Encerrado','']};
 const list=S.propostas.map(a=>{const k=a.status==='ativo'&&a.vence<=Date.now()?'vencido':a.status;const pk=pack(a.pacoteId);
  return `<div class="px-5 py-4"><div class="flex items-start gap-3"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${esc(a.empresa)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(a.protocolo)} · ${pk?esc(pk.nome)+' · '+brl(pk.preco):'Período removido'}${k==='ativo'?' · até '+fdate(a.vence):''}</p></div>${pill(ST[k][0],ST[k][1])}</div>
  <div class="mt-3">${adHTML(a)}</div>
  ${a.status==='analise'||a.status==='ajustes'?`<div class="mt-3 flex flex-wrap gap-2"><button type="button" data-ap="${a.protocolo}" class="${PRI} h-10">Aprovar</button><button type="button" data-aj="${a.protocolo}" class="${GHO} h-10">Pedir ajustes</button><button type="button" data-rc="${a.protocolo}" class="${DAN} h-10">Recusar</button></div>`:''}
  ${a.status==='aprovado'?`<div class="mt-3 flex flex-wrap gap-2"><button type="button" data-pg="${a.protocolo}" class="${GHO} h-10">Marcar como pago (simulação)</button></div>`:''}</div>`}).join('');
 p.innerHTML=`<div><div class="mb-3 flex items-center justify-between gap-3 px-1"><h2 class="text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3">Propostas de anúncio</h2><a href="#anunciar" class="text-[13px] font-semibold text-accent">Abrir página Anunciar</a></div>
 ${card(list||`<div class="px-5 py-6 text-sm text-ink-3">Nenhuma proposta ainda. Envie uma pela página Anunciar.</div>`)}
 <h2 class="${H2} mt-8">Planos e preços</h2>
 ${card(S.pacotes.map(k=>row(esc(k.nome)+' · '+brl(k.preco),k.dias+' dias · libera: '+NIVEL[k.nivel||1],`<button type="button" data-pd="${k.id}" class="text-[13px] font-semibold text-danger">Remover</button>`)).join('')+`<div class="grid gap-3 px-5 py-4 ma-kgrid md:items-end"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="k_n" class="${INP} mt-1" placeholder="Ex.: Fim de semana"></label><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input id="k_p" inputmode="decimal" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input id="k_d" inputmode="numeric" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Libera</span><select id="k_l" class="${INP} mt-1">${[1,2,3,4].map(n=>`<option value="${n}">${NIVEL[n]}</option>`).join('')}</select></label><button type="button" id="k_add" class="${PRI} h-10">Adicionar</button></div>`)}
 <p class="ma-err px-1" id="k_msg"></p><p class="mt-1 px-1 text-xs text-ink-3">Os valores iniciais são só exemplos. Fluxo igual ao original: a empresa envia a proposta, a equipe aprova e só então há cobrança.</p></div>`;
 const act=(sel,fn)=>$$(sel,p).forEach(b=>b.onclick=async()=>{const a=S.propostas.find(x=>x.protocolo===b.dataset[Object.keys(b.dataset)[0]]);await fn(a);save();viewAdmin()});
 act('[data-ap]',a=>{a.status='aprovado';a.motivo='';reg(a,'Anúncio aprovado pela equipe · aguardando pagamento');log('Anúncio aprovado: '+a.empresa);toast('Aprovado. Consulte o protocolo na página Anunciar para simular o pagamento.')});
 act('[data-aj]',async a=>{const m=await dlg('Quais ajustes a empresa deve fazer?',{input:true,def:'Envie um logotipo com fundo transparente.',ok:'Pedir ajustes'});if(m===null)return;a.status='ajustes';a.motivo=m;reg(a,'Equipe pediu ajustes: '+m);log('Ajustes pedidos: '+a.empresa)});
 act('[data-rc]',async a=>{const m=await dlg('Motivo da recusa (a empresa vê na consulta)',{input:true,def:'O conteúdo não segue a política de anúncios.',ok:'Recusar',danger:true});if(m===null)return;a.status='recusado';a.motivo=m;reg(a,'Anúncio recusado: '+m);log('Anúncio recusado: '+a.empresa)});
 act('[data-pg]',a=>{a.status='ativo';a.vence=Date.now()+(pack(a.pacoteId)?.dias||7)*DAY;ativar(a);reg(a,'Pagamento confirmado · anúncio no ar até '+fdate(a.vence));log('Anúncio no ar: '+a.empresa);toast('No ar. Abra o chat e envie uma mensagem para ver o cartão.')});
 $$('[data-pd]',p).forEach(b=>b.onclick=()=>{if(S.pacotes.length<=1)return toast('Mantenha pelo menos um período.');S.pacotes=S.pacotes.filter(k=>k.id!==b.dataset.pd);save();pAds(p)});
 $('#k_add',p).onclick=()=>{const n=$('#k_n',p).value.trim(),pr=parseFloat($('#k_p',p).value.replace(',','.')),d=parseInt($('#k_d',p).value,10);if(!n||isNaN(pr)||!(d>0)){$('#k_msg',p).textContent='Preencha nome, preço e dias.';return}S.pacotes.push({id:'p'+uid(),nome:n,preco:pr,dias:d,nivel:+$('#k_l',p).value});log('Período de anúncio criado: '+n);save();pAds(p)};
}

