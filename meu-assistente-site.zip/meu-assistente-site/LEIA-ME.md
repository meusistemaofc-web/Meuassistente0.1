# Meu Assistente · Site de demonstração

Versão navegável de demonstração do Meu Assistente, com a interface idêntica ao app original e todos os módulos novos
(chat, empresas, lojas e pedidos, Sua empresa, mercado com gráficos, impostos/DAS, anúncios e painel de administração).

**Importante:** é uma demonstração. Tudo roda no navegador de quem acessa: os dados ficam salvos só naquele aparelho,
e IAs, cotações e pagamentos são simulados. O sistema real (com login, banco e IAs de verdade) é o projeto `meu-assistente`.

## Estrutura
```
meu-assistente-site/
├── public/                 ← o site (é isto que vai para o ar)
│   ├── index.html          ← página única do site
│   ├── css/original.css    ← estilo do app original
│   ├── css/site.css        ← estilos próprios
│   ├── img/                ← logotipos
│   └── js/                 ← código, um arquivo por módulo
│       ├── telas-originais.js   telas copiadas do app original
│       ├── base.js · dados.js   utilidades e dados salvos no navegador
│       ├── chat.js              chat e interpretação das mensagens
│       ├── empresas.js          empresas, lojas, pedidos, Sua empresa
│       ├── anunciar.js          página Anunciar
│       ├── mercado.js · graficos.js · mercado-fontes.js
│       ├── impostos.js          impostos e DAS
│       ├── localizacao.js       permissão de localização
│       ├── ias.js · previa-motores.js
│       ├── admin.js             painel de administração
│       └── telas.js · inicio.js rotas e início
├── nginx.conf              ← configuração do servidor do site
├── docker-compose.yml      ← sobe o site na porta 3040 (só local)
└── install.sh              ← instala e liga ao Nginx Proxy Manager
```
A ordem dos arquivos em `index.html` importa: mantenha-a ao adicionar novos scripts.

## Colocar no ar na VPS
1. Copie a pasta para `/opt/meu-assistente-site` e rode `sh install.sh`.
2. No Nginx Proxy Manager, crie um Proxy Host com o domínio desejado (ex.: `demo.ivt.business`),
   **Forward Hostname** `meu-assistente-site`, **Port** `80`, e ative o SSL (Let's Encrypt).

## Atualizar
Troque os arquivos de `public/` e recarregue a página — não precisa reiniciar nada.
