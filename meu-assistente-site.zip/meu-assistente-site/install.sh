#!/bin/sh
# Instala/atualiza o site de demonstração do Meu Assistente na VPS.
# Seguro para rodar várias vezes. Não mexe em nenhum outro sistema.
set -e
cd "$(dirname "$0")"
echo "== Meu Assistente · site de demonstração =="
command -v docker >/dev/null || { echo "ERRO: Docker não está instalado."; exit 1; }
[ -f public/index.html ] || { echo "ERRO: pasta public/ incompleta. Extraia o ZIP inteiro."; exit 1; }
# porta 3040 livre (ou já usada por este próprio site)
if ss -ltn 2>/dev/null | grep -q '127.0.0.1:3040 ' && ! docker ps --format '{{.Names}}' | grep -qx meu-assistente-site; then
  echo "ERRO: a porta 3040 já está em uso por outro serviço. Troque a porta em docker-compose.yml (ex.: 3041)."; exit 1
fi
NET=$(docker inspect nginx-proxy-manager --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}}{{"\n"}}{{end}}' 2>/dev/null | grep -v '^bridge$' | grep -v '^$' | head -1 || true)
if [ -n "$NET" ] && [ ! -f docker-compose.override.yml ]; then
  printf 'services:\n  site:\n    networks:\n      - default\n      - npm\nnetworks:\n  npm:\n    external: true\n    name: %s\n' "$NET" > docker-compose.override.yml
fi
docker compose up -d --remove-orphans
sleep 3
CODE=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3040/ || echo 000)
JS=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3040/js/chat.js || echo 000)
echo "Página inicial: $CODE | Scripts: $JS   (os dois precisam dar 200)"
if [ -n "$NET" ]; then
  P=$(docker exec nginx-proxy-manager curl -s -o /dev/null -w '%{http_code}' http://meu-assistente-site/ 2>/dev/null || echo "?")
  echo "Proxy enxerga o site: $P (rede $NET)"
  echo "No Nginx Proxy Manager use: Forward Hostname = meu-assistente-site · Port = 80"
else
  echo "Nginx Proxy Manager não encontrado: use Forward Hostname = IP da VPS · Port = 3040"
fi
[ "$CODE" = "200" ] && [ "$JS" = "200" ] && echo "OK: site instalado." || { echo "FALHOU: veja 'docker logs meu-assistente-site'."; exit 1; }
