# Instruções para o agente (instalação na VPS)

Objetivo: colocar no ar o **site de demonstração do Meu Assistente** (site estático servido por Nginx em Docker).

## Regras
- **Não altere nenhum arquivo** de `public/`. O site já está pronto e testado.
- **Não mexa em outros containers ou sistemas** (meuassistente-app-1, meuassistente10-app-1, ivaslovck, mymusic, nginx-proxy-manager).
- Use somente a pasta `/opt/meu-assistente-site` e a porta local `3040`.

## Passos
1. Baixar e extrair (o ZIP contém a pasta `meu-assistente-site/`):
   ```
   rm -rf /tmp/site-novo && mkdir /tmp/site-novo && cd /tmp/site-novo
   curl -fL "URL_DO_ZIP" -o site.zip && unzip -q site.zip
   mkdir -p /opt/meu-assistente-site
   rsync -a --delete --exclude=docker-compose.override.yml ./meu-assistente-site/ /opt/meu-assistente-site/
   ```
2. Instalar:
   ```
   cd /opt/meu-assistente-site && sh install.sh
   ```
3. Conferir a saída: precisa terminar com **"OK: site instalado."**, com "Página inicial: 200 | Scripts: 200".
   Se aparecer "Proxy enxerga o site: 200", o Nginx Proxy Manager já alcança o container.
4. Informar ao usuário o resultado e lembrar que ele precisa criar o Proxy Host no Nginx Proxy Manager:
   Domain = (o domínio escolhido) · Forward Hostname = `meu-assistente-site` · Port = `80` · SSL Let's Encrypt.

## Se der erro
- "porta 3040 já está em uso": trocar `3040` por `3041` em `docker-compose.yml` e no `install.sh`, e rodar de novo.
- Ver registros: `docker logs --tail 50 meu-assistente-site`.
- Desfazer tudo: `cd /opt/meu-assistente-site && docker compose down`.
