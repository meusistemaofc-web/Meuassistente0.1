# Conhecimento comercial integrado: Atendimento, Marketing, Vendas e CRM

Código: `server/src/ai/commercial.ts` (ligado em `ai/assistant.ts` e no agente de `routes/businesses.ts`). Nenhuma migração.

## O que o chat sabe
- **Playbook por tema** (atendimento, marketing, vendas, relacionamento/CRM e o processo integrado). Entra no texto de sistema **somente** quando a conversa é comercial (clientes, campanha, promoção, vendas, inativos, push, pós-venda…), sem pesar nas demais conversas.
- **Estado real dos recursos**, lido na hora:
  - **Marketing**: ativo ou não (administrador, plano e empresa do usuário), campanhas e notificações usadas/limite, se há segmentação e agendamento. Se não estiver disponível, o chat não promete campanhas.
  - **CRM**: o módulo de CRM completo (funil e negociações) **ainda não existe** no app; o chat diz isso e não finge registrar nada nele. Se o recurso `crm` for ligado no futuro, o chat passa a tratá-lo como ativo.
- **Visão de clientes calculada** dos dados reais da empresa (pedidos e agendamentos, autorizações de comunicação e cliques de campanhas): clientes **novos** (primeira compra nos últimos 30 dias), **ativos/recorrentes**, **inativos** (mais de 60 dias sem comprar) e **potenciais** (autorizaram contato ou clicaram em campanha e ainda não compraram), com primeiros nomes e o resultado das últimas campanhas (envios e cliques). Os resultados de campanhas alimentam essa visão e orientam a próxima ação.

## Marketing e CRM trabalhando juntos
O chat usa a visão de clientes para sugerir **quem** deve receber **qual** campanha (por exemplo, reencontro com inativos, boas-vindas aos novos, estímulo ao primeiro passo dos potenciais), propõe texto, público e melhor momento, e indica a Central de Marketing para disparar. Quem recebe continua sendo só quem autorizou; a plataforma já impõe horário comercial (8h às 21h), intervalo mínimo de 20 h por cliente e os limites do plano.

## Honestidade sobre ações externas
- O assistente **não envia** campanhas, push, e-mails ou mensagens. Uma regra fixa no texto de sistema proíbe afirmar o contrário.
- Trava no código: se a resposta da IA disser que enviou, disparou, programou ou notificou clientes, a frase é removida e substituída por um aviso claro com atalho para a Central de Marketing (`guardExternalClaims`).
- O **agente de atendimento da empresa** (que fala com clientes) recebeu orientação de atendimento e vendas, com a proibição de prometer desconto, brinde, prazo ou ação que não esteja cadastrada.

## Limitações
- Não há tela de CRM nem funil de negociações; a "visão de clientes" é uma leitura calculada, não um cadastro editável.
- Clientes que compram como convidados (sem conta) não entram na visão, pois não têm identificação própria.
- O chat sugere e prepara campanhas, mas o disparo é sempre feito pela Central de Marketing.

## Testes
`npm test` (156 testes), incluindo: detecção de tema, playbook, estado real (ativo / desligado pelo administrador / usuário sem empresa), visão de clientes e a trava contra afirmar envios.
