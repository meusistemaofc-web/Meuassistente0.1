# Botões padrão do agente, cards do catálogo e descrição da empresa

## 1. Botões padrão do Chat do Agente

**Padrão (empresas novas e empresas que nunca personalizaram):** só 5 botões ligados.

| Botão | Padrão | Aparece quando |
|---|---|---|
| Agendar um horário | ligado | a empresa tem serviços |
| Ver nossos serviços | ligado | a empresa tem serviços |
| Localização | ligado | há endereço ou localização cadastrados |
| Horário de funcionamento | ligado | há dias de funcionamento ativos **ou** texto de horário cadastrados *(novo)* |
| WhatsApp | ligado | o WhatsApp está cadastrado |
| Pagamento e entrega | **desligado** | a empresa tem loja e o dono ligar o botão |

- **Ligar e desligar um a um** continua em *Sua empresa → Agente → Personalizar Agente de Atendimento*, com a prévia real ao lado.
- **Cada empresa tem a sua configuração** (`agenteOpcoes` nos dados da própria empresa).
- **Botão desligado não aparece.** O recurso continua respondendo se o cliente perguntar no chat.
- **Empresas que já personalizaram:** o que está gravado é respeitado, nada é sobrescrito. Por exemplo, quem já tinha ligado o Pagamento continua com ele. Uma chave que nunca foi gravada segue o padrão novo.
- **Sem informação, sem botão:** o Horário some quando não há horário cadastrado. Antes, aparecia mesmo assim e mostrava "Consulte a empresa".
- **Não mudou:** "Ver nossos produtos" (lojas com produtos) e "Carrinho" (quando há itens) seguem as regras de antes. Eles não fazem parte da personalização.

## 2. Cards de produtos e serviços

**O card mostra só imagem, nome e preço.** O preço aparece só quando está cadastrado. A descrição saiu dos cards em todos os lugares:
- catálogo público em lista e em grade;
- carrossel do chat do agente.

**Ao tocar no card (foto ou nome)**, abre a visualização detalhada:
- imagem em destaque (desliza entre as fotos, quando há várias);
- nome completo;
- preço, com duração para serviços;
- etiquetas e categoria;
- **descrição completa** (só aqui);
- variações;
- o botão de ação de sempre: **Adicionar** para produtos, **Agendar** para serviços.

**Fechar:** pelo ×, tocando fora, com a tecla Esc ou com o voltar do celular (no chat do agente).

**Mantido:**
- O botão do próprio card (**Agendar** / **+** / **Adicionar**) faz exatamente o que fazia.
- Visual escuro, *mobile-first*.

## 3. Descrição da empresa ("Sobre a empresa")

- **Limite:** 200 caracteres (antes, 300).
- **Contador:** mostra "150/200" em tempo real. Fica amarelo a partir de 180.
- **Validação:** no campo (`maxlength`) e no servidor. O servidor recusa mais de 200 com a mensagem "A descrição da empresa pode ter até 200 caracteres.".
- **Descrições antigas maiores:** não dão erro. Continuam salvas e aparecem como estavam (o cabeçalho do catálogo corta em 200 com "…"). Salvar outros campos funciona normalmente. O limite só vale quando a própria descrição for alterada.
- A descrição de **produtos e serviços** não mudou.

## Arquivos

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/routes/businesses.ts` | Padrão dos botões (`AG_PADRAO`: Pagamento desligado). Valores já gravados prevalecem |
| `server/src/routes/ads.ts` | `SOBRE_MAX = 200` na criação e na edição, sem quebrar descrições antigas |
| `frontend/public/agente.html` | Horário só com informação cadastrada; cards do carrossel sem descrição; visualização detalhada |
| `frontend/public/modules-addon.js` | Cards sem descrição; detalhes de serviço (novo) e de produto (com preço, etiquetas e categoria); contador de 200; dicas no painel |
| `server/src/app.ts` | `modules-addon.js?v=135` |
| `server/test/run.ts` | Testes atualizados e 2 novos: botões padrão/preservação/isolamento e limite de 200 |
| `server/test/browser/personalizacao.py` | Ajustado ao padrão novo |
| `server/test/browser/atalhos_agente.py` | Ajustado ao padrão novo |
| `server/test/browser/carrossel_catalogo.py` | Ajustado ao padrão novo |
| `server/test/browser/descricoes_expansiveis.py` | Ajustado ao padrão novo |
| `server/test/browser/catalogo_cabecalho.py` | Ajustado ao padrão novo |

**Novos:**
- `server/test/browser/cards_detalhes.py`
- `docs/AGENTE_CARDS_DESCRICAO.md`

**Sem alteração:** banco de dados (nenhuma migração), agendamentos, pedidos, carrinho, Página de Links, comprovantes e as demais áreas.

## Publicação

Suba no GitHub e rode o `update.sh` de sempre.
