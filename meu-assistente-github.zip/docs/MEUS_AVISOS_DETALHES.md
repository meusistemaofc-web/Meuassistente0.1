# Meus Avisos: detalhes de cada notificação

## Causa da tela preta (auditoria)

Ao tocar num aviso, a lista **não abria nada dela mesma**. Ela marcava o aviso como lido e mandava o roteador do app direto para o `link` gravado. Esse roteador só conhece as telas principais (Início, Agenda, Financeiro, Perfil…). Os avisos, porém, apontam também para:

| Destino | Exemplos | Resultado antes |
|---|---|---|
| Telas extras `/x/...` | Sua empresa, Meus pedidos, Carteira, Cupons, Impostos, Mercado, Planos, Chamados | "Not Found" atrás da tela |
| Páginas próprias | `/execucoes`, `/previsoes`, `/admin/laboratorio` | "Not Found" em fundo preto |
| `/` ou sem link | Avisos antigos, importação de cardápio | Voltava ao início sem mostrar o aviso |

Nos três casos o conteúdo do aviso nunca aparecia. Isso foi reproduzido no navegador antes da correção.

## O que mudou

### Tocar num aviso abre os detalhes na própria tela de avisos

- **Aviso:**
  - categoria;
  - título;
  - data e hora de recebimento (ex.: "Recebido em 16/11/2026 às 09:00");
  - mensagem completa, sem cortes.
- **Registro relacionado**, quando o aviso aponta para algo que ainda existe e é do próprio usuário:

  | Registro | Dados mostrados |
  |---|---|
  | Lembrete | quando, situação, repetição |
  | Compromisso | data, horário, local, com quem, observações |
  | Conta a pagar | valor, vencimento, situação, categoria |
  | Pedido ou agendamento | situação, total, itens ou serviço e data; o nome do cliente aparece só para o dono da empresa |
  | Acompanhamento | dados do acompanhamento |
  | Tarefa do CRM | dados da tarefa |
  | Chamado de suporte | protocolo e situação |
  | Empresa | situação do anúncio |

- **Ação do aviso** (quando houver link): "Abrir lembretes", "Ver meus pedidos", "Abrir carteira", "Abrir Sua empresa", etc. Cada destino abre pelo caminho certo:
  - telas do app pelo roteador;
  - telas `/x/` pelo navegador das telas extras;
  - páginas próprias com carregamento normal.
- **Voltar:** "Voltar aos avisos" ou o voltar do celular retornam à lista. Voltar da tela aberta pela ação também retorna à lista.
- **Marcado como lido ao abrir.** Só o "lido" muda: título, mensagem e link ficam como estavam, e nada é apagado. O contador do sino se atualiza.
- **Exibição imediata:** título e mensagem aparecem na hora com os dados que já estão na lista, e o restante completa em seguida.
- **Avisos antigos ou sem complemento** (sem mensagem, link ou registro) abrem com título, categoria e data.
- **Registro apagado:** o aviso continua abrindo, só sem o bloco do registro.
- **Link direto:** `/notificacoes?aviso=ID` abre um aviso específico.

### Funcionamento

- Tudo vem do banco: nenhuma IA e nenhum dado fictício.
- Cada usuário só abre os próprios avisos. Outra pessoa recebe "não encontrado".
- No celular, os textos longos quebram linha, sem rolagem lateral nem sobreposição.

**Mantido:**
- lista;
- botão "Marcar como lida";
- "Marcar todas como lidas";
- ativação de notificações;
- ofertas com "Saiba mais" / "Não quero receber".

## Arquivos

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/routes/notifications.ts` | Nova rota `GET /api/notifications/:id` (detalhes, registro relacionado e marcação de lido). A lista passa a incluir `ref` |
| `server/src/app.ts` | Registro da rota nova |
| `frontend/public/assets/index-MUcZwl3l.js` | Aponta para a nova versão da tela de avisos |
| `server/test/run.ts` | Teste novo dos detalhes (lembrete e conta reais, aviso antigo, registro apagado, isolamento e validação) e detalhes do pedido para o cliente e para o dono |

**Novos:**
- `frontend/public/assets/notificacoes-13577c9cbn.js`: tela de avisos com os detalhes. O arquivo anterior continua no lugar, para aparelhos com versão antiga em cache.
- `server/test/browser/notificacoes_detalhes.py`
- `docs/MEUS_AVISOS_DETALHES.md`

**Sem alteração:** banco de dados (nenhuma migração), envio de notificações e push, e as demais áreas.

## Publicação

Suba no GitHub e rode o `update.sh` de sempre.
