# Analista de dados e movimentações da empresa (Chat Principal)

O dono conversa com o Meu Assistente e recebe números **reais** da própria empresa, sem abrir o painel. Tudo é **somente leitura**: nada altera pedidos, saldos, lançamentos ou cadastros, e nenhum banco paralelo foi criado (sem migração nova).

## Perguntas atendidas (exemplos)
"Quanto vendi hoje?", "Qual meu faturamento neste mês?", "Quantos pedidos estão pendentes?", "Qual produto vendeu mais?", "Compare esta semana com a passada", "Qual foi meu melhor dia?", "Quantos clientes novos chegaram este mês?", "Como estão meus agendamentos?", "Como está o desempenho da minha empresa?".

## Como funciona
| Camada | Arquivo | Papel |
|---|---|---|
| Serviços | `server/src/lib/bi.ts` | Períodos, vendas, pedidos, agendamentos, clientes, acessos, produtos, incentivos, Finanças, CRM, comparativo e tendências |
| Ferramentas da IA | `server/src/ai/negocio-ia.ts` | `negocio_resumo`, `negocio_comparar`, `negocio_analise` + contexto de regras |
| API do cartão | `server/src/routes/bi.ts` | `GET /api/v2/businesses/:id/bi?tipo=resumo|comparar|analise&periodo=…&de=…&ate=…` |
| Cartão no chat | `frontend/public/modules-addon.js` (`⟦neg:…⟧`) | KPIs, gráfico de barras do faturamento, comparativo e tendências |

O servidor anexa o cartão `⟦neg:empresa|tipo|periodo|de|ate⟧` à resposta quando a IA usou uma ferramenta; o cartão busca os números na API (sempre atuais, com a permissão validada de novo).

## Fontes oficiais (nada duplicado)
- **Pedidos e agendamentos:** `orders` (agendamento = `data.tipo`; convidados unidos por telefone).
- **Acessos:** `business_stats` (visitas, impressões, contatos, conversas do agente; dia de Brasília).
- **Finanças:** `items` do módulo Finanças do dono (receitas e despesas lançadas; não separado por empresa).
- **Cupons e MCoins:** dados gravados no pedido (`cupom`, `moedas`).
- **CRM:** `CommercialIntelligenceService.indicadores` (somente leitura, quando o CRM está disponível).

## Definições (também devolvidas pela API)
- **Faturamento** = vendas pagas/concluídas (mesma regra do relatório da empresa e do MEI), inclui agendamentos.
- **Pendente** = em aberto e ainda não concluído nem pago online. **Bruto** = faturamento + pendente. **Cancelado** = cancelado ou recusado.
- **Cliente novo** = primeira compra válida no período; **recorrente** = 2+ compras válidas. O dono comprando na própria loja não conta como cliente.
- **Períodos:** hoje, ontem, semana (segunda até hoje), semana_passada, mes, mes_passado, ultimos_7_dias, ultimos_30_dias, ano, personalizado (de/ate). Pelo fuso do usuário. O comparativo corta o período anterior no mesmo número de dias (e avisa quando o atual está em andamento).

## Integridade
- Sem fonte ≠ zero: acessos sem nenhum registro, Finanças sem lançamentos e visualizações por produto vêm como `disponivel:false` com o motivo; o chat diz que o dado não existe.
- Nada é estimado. "Mais procurados" = mais pedidos/agendados (o sistema ainda não registra visualização por produto).
- **Tendências e sugestões** vêm com `criterio` e `base` (números usados): alta/queda ≥ 10%, cancelamentos ≥ 20% (mín. 5), pedidos abertos há mais de 2 dias, poucas conversões por visita, horário de pico, item com ≥ 50% das vendas, baixa recorrência, agendamentos pendentes.

## Permissões e isolamento
Somente o **dono** da empresa (não existem contas de equipe). Validado no servidor em toda consulta: outra empresa, outro usuário ou administrador comum recebe 404, anônimo 401. Usuário sem empresa não recebe as ferramentas e a chamada direta é recusada. A IA só enxerga as empresas do próprio usuário.

## Limitações
- Sem visualizações por produto/serviço (precisaria de coleta nova).
- Acessos: o "visitante único por dia" vem da coleta existente (memória do servidor; reiniciar o servidor pode contar de novo).
- Funcionário/administrador de empresa com permissões próprias depende de contas de equipe, que ainda não existem.
- Receitas e despesas são as do módulo Finanças do dono, não de uma conta empresarial separada.

## Testes
`server/test/run.ts` (4 testes: indicadores, comparativo e tendências, permissões/isolamento, chat) e `server/test/browser/analista_negocio.py` (cartões no chat, celular).
