# Central de controle, comercialização e identificação das MCoins

Camada administrativa sobre as MCoins existentes (mesmas tabelas `coins`, `coin_balances`, `coin_ledger`): **nenhuma carteira é duplicada, nenhum saldo ou movimento anterior é alterado** e **tudo nasce DESLIGADO**.
Código: `server/src/lib/coin-central.ts`, `server/src/lib/coin-code.ts`, rotas em `server/src/routes/coins.ts`, migração `server/migrations/027_mcoins_central.sql`. Interface: aba **Central MCoins** (administração) e botões na **Carteira** do usuário.

## 1. Controle global
Chaves independentes (configuração `coins_central`): compra, venda, transferência entre usuários e compartilhamento entre contas. Desligar uma modalidade **não bloqueia** carteiras, saldos, recebimentos autorizados nem históricos. Toda alteração é auditada com antes/depois (`coins.central.config`).

## 2. Controle de acesso
Modo: **todos**, **somente usuários selecionados** ou **somente empresas/grupos selecionados**. Permissões por usuário, empresa (dono) ou grupo, para uma moeda ou todas: comprar, vender, receber, transferir, compartilhar (permitir / bloquear / herdar).
Ordem de avaliação no servidor: usuário ativo → chave global → política da moeda (só restringe) → bloqueio/permissão individual → empresa/grupo → modo. **Bloqueio explícito sempre vence.** A lista administrativa pesquisa por nome, e-mail ou identificador e mostra a permissão explícita e a efetiva.

## 3. Código único
`MC-MA-000001` (Meu Assistente) ou `MC-EM-000002` (empresa). Gerado na criação (moedas antigas recebem código por retropreenchimento, em ordem de id), único, imutável e registrado em `coin_codes`, que nunca é apagado: um código não é reutilizado nem após exclusão/desativação. Pesquisa administrativa por código, nome ou símbolo (`GET /api/panel/coins/codigo?q=`) retorna emissor, moeda e empresas vinculadas. **O código é só identificador — nunca credencial.**

## 4. Circulação entre usuários
`POST /api/v2/coins/transferir`: moeda, origem (sempre a conta autenticada), destino, quantidade, confirmação (prévia → confirmar), código único `MCX-…`, histórico completo (`coin_transfers` + dois lançamentos no livro-razão: `transf_saida` e `transf_entrada`). Taxa opcional (volta à emissão). Exige a chave global ligada, permissão de transferir na origem e de receber no destino.

## 5. Compra e venda
`POST /api/v2/coins/comprar` e `/vender`: prévia (preço, taxa, total) → confirmação com chave de idempotência. Preço, taxas, mínimo/máximo por operação e limite diário configuráveis por modalidade. **Não se presume dinheiro real**; a liquidação é escolhida pelo administrador:
- **manual**: o pedido fica *pendente*; o administrador confirma (liquidação feita fora do sistema) ou recusa. Venda pendente reserva as moedas (debita) e as devolve se recusada/cancelada.
- **interna**: efeito imediato nas MCoins, sem qualquer cobrança/pagamento pelo aplicativo.
Nenhum meio de pagamento é acionado por esta camada.

## 6. Segurança e auditoria
Permissões, limites, preço, taxa, saldo e identidade são decididos no servidor; o cliente só envia a intenção. Operações atômicas (transação sob trava da moeda), idempotentes (chave única por usuário), saldo nunca negativo, estoque da emissão protegido. Auditoria: `coins.compra|venda|transferir` (+`.falha`, `.confirmar`, `.recusar`, `.cancelar`), `coins.central.config|politica|permissao|grupo.*`. Usuários só veem os próprios pedidos/transferências; o destino aparece só com o primeiro nome.

## 7. Preservação e reversão
Migração aditiva (colunas/tabelas novas, `IF NOT EXISTS`); fluxos de distribuição, adesão, resgate e estorno ficam intactos. Reversão manual: ver o cabeçalho de `027_mcoins_central.sql`.

## API
Admin: `GET/POST /api/panel/coins/central` (ações `config`, `politica`, `permissao`, `grupo_criar`, `grupo_membros`, `grupo_excluir`, `pedido`), `GET …/central/permissoes`, `…/central/grupos/:id`, `…/central/pedidos`, `GET /api/panel/coins/codigo`.
Usuário: `GET /api/v2/coins/capacidades`, `GET /api/v2/coins/pedidos`, `POST /api/v2/coins/comprar|vender|transferir`, `POST /api/v2/coins/pedidos/:id/cancelar`; `GET /api/v2/coins/wallet` inclui `central`.

## Limitações / dependem de decisão
- Liquidação em dinheiro real **não** está implementada (manual = confirmação do administrador fora do sistema). Avalie requisitos legais/regulatórios antes de ligar compra, venda ou transferência.
- Compartilhamento entre contas é apenas chave + permissão (sem regra de negócio).
- Grupos são listas definidas pelo administrador; "empresa" = dono do negócio.
- Venda manual pendente mantém as moedas reservadas fora do saldo até a resolução.

## Testes
`server/test/run.ts` (7 testes: padrões/auditoria, código, desligado, compra manual, interna/venda, permissões, transferência) e `server/test/browser/mcoins_central.py`.
