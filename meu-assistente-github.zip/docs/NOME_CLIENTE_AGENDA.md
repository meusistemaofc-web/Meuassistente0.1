# Nome do cliente nos cartões de compromisso (app)

Os cartões de compromisso do app (Agenda, Meu Dia, Financeiro) mostravam só o campo antigo "com quem" (`person`).
Compromissos que têm apenas o **nome do cliente** (`clienteNome`) apareciam sem nome.

## Alteração (arquivos do app em `frontend/public/assets/`)
- `items-619e4b59c.js` (novo, a partir de `items-0dXv04MI.js`): o cartão mostra `clienteNome` e, se vazio, `person`.
- `agenda-aee45dc2c.js`, `financeiro-5c1d8117c.js`, `meu-dia-adb36644c.js` (novos): iguais aos anteriores, apontando para o `items` novo.
- `index-MUcZwl3l.js`: aponta para os quatro arquivos novos. Os arquivos antigos foram mantidos (aparelhos com a versão anterior em cache continuam funcionando).

Conferência (SHA-256): items 619e4b59…, agenda aee45dc2…, financeiro 5c1d8117…, meu-dia adb36644…, index 3735a53b….

## Service worker (`frontend/public/sw.js`, v11)
O `index-MUcZwl3l.js` mantém o nome quando é ajustado, e o service worker guardava todo `/assets/` com "cache primeiro":
apps já instalados (Tela de Início) continuavam com a versão antiga. Agora esse arquivo é buscado **sempre no servidor**,
e a cópia local fica só para uso sem internet. A versão do service worker subiu para v11 para os aparelhos receberem a regra.

## Atualização automática dos aparelhos (sw.js v11)
Aparelhos que já tinham o app (service worker v10 ou anterior) continuavam com o arquivo principal antigo — e, com ele,
o **campo de digitação antigo** (`index-MaCmp02`), mesmo depois de publicar a versão nova. O aviso "Atualizar" só aparecia
com o sw.js novo, e só resolvia se a pessoa tocasse nele.

Agora, ao substituir um service worker anterior à v11, o novo assume na hora e o app recarrega sozinho uma vez,
já com os arquivos novos. Nas versões seguintes volta o comportamento normal (esperar o "Atualizar").

Simulação (mesmo navegador: versão antiga aberta → servidor atualizado → app reaberto):
- 17/11 sem correção: campo antigo para sempre;
- sw v11 sem ativação automática: campo antigo até tocar em "Atualizar";
- versão atual: campo novo na primeira reabertura.
