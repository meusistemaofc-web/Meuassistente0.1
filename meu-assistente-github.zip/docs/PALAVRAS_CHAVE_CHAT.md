# Palavras-chave no chat: encontrar empresas pelo que elas cadastraram

## Onde estão as palavras-chave (o cadastro já existente)
- **No anúncio da empresa:** o campo "Palavras-chave", separadas por vírgula.
- **Em cada produto ou serviço:** o campo "Palavras-chave (ajudam o chat a encontrar este item)". Só contam os itens da modalidade atual da empresa.
- **Também entram na busca:** o ramo (categoria), as tags, o nome e o título da empresa, além do nome e da categoria dos itens.

Não existe um cadastro paralelo: a busca lê esses dados direto do banco a cada mensagem, então qualquer alteração vale na hora.

## Reconhecimento (`routes/businesses.ts` › `termosEmpresa` / `relevancia` / `reconhecerBusca`)
Uma única função é usada pela página "Empresas parceiras", pelo chat e pela atualização depois de autorizar a localização.

**Comparação:**
- sem diferença entre maiúsculas e minúsculas;
- sem acentos ("ração" = "racao");
- espaços extras e pontuação são ignorados;
- singular e plural equivalem, e "pizza" encontra "pizzaria";
- **sempre palavra inteira:** "pier" não encontra "piercing".

**Expressões compostas:** a expressão inteira, na ordem, conta mais ("banho e tosa"). Uma parte significativa da expressão também encontra a empresa ("tosa" → "banho e tosa"; "Pierre" → "Pierre Modas").

**Relevância:**
- palavra-chave cadastrada vale 3;
- ramo, tags e itens valem 2;
- nome e título valem 1.

Os resultados vêm da mais relevante para a menos relevante e, depois, do mais perto para o mais longe.

## Quando o chat busca empresas (gatilho, sem frase obrigatória)
- **Palavra ou expressão quase sozinha** ("Piercing", "PIERCING", "banho e tosa", "tosa para meu cachorro").
- **Frase com intenção clara de procurar** ("quero", "onde", "perto", "preciso", "indica", "procuro", "contratar"…) que contenha uma palavra-chave cadastrada ou o ramo. Vale para frases de até 20 palavras.
- **Comandos de outros recursos não viram busca:** mudar, remarcar ou cancelar compromisso, agendar, lembrar, anotar, lista, gastos e receitas, análises e relatórios.
  - Exemplo: "muda o horário da tatuagem para 16:30" continua sendo uma edição de compromisso.
  - Mensagens como "sim" e "Não era isso que eu queria", que a regra antiga (por prefixo) desviava para empresas, agora seguem para a IA.

## Resposta
| Situação | Resposta |
|---|---|
| Empresas encontradas | "Encontrei empresas que trabalham com **piercing** para você!" (ou "uma empresa que trabalha…") + cards reais (até 12) |
| Encontrada pelo nome da empresa | "Encontrei esta opção para você!" + card |
| Sem localização autorizada | "Para mostrar empresas que trabalham com piercing perto de você, preciso da sua localização." + botão. Ao autorizar, a mesma mensagem vira os cards (`docs/LOCALIZACAO_CHAT.md`) |
| Com localização, mas fora do raio | "Não encontrei empresas disponíveis que trabalham com … perto de você…" + "Ampliar o raio" / "Informar outra cidade" |
| Palavra-chave só de empresas indisponíveis (pendente, reprovada, suspensa ou vencida) | "Ainda não há empresas parceiras disponíveis que trabalham com …", sem cards nem botões |

**Só aparecem empresas disponíveis:** anúncio aprovado, no ar e dentro da validade, apresentadas no card **original** do chat (`sponsorCard`): logo, nome, descrição, avaliações reais, distância, situação e o botão "Saiba mais" conforme o plano.

## Testes
- **Servidor** (`test/run.ts`, "Palavras-chave no chat"):
  - **variações da mensagem:** palavra sozinha e em frases (inclusive longa), maiúsculas, espaços, com e sem acento, expressão composta e parte dela;
  - **várias empresas:** ordenadas por relevância (quem tem a palavra só no nome vem por último), e nunca por pedaço de palavra;
  - **disponibilidade e localização:** pendente, reprovada e suspensa ficam de fora; sem localização, pede a localização; com localização, mostra os cards;
  - **coerência e atualização:** mesma busca e mesma ordem da página "Empresas parceiras"; cadastro alterado (palavra nova e palavra removida) vale na hora;
  - **comandos não desviados.**
- **Tela** (`test/browser/palavras_chave_chat.py`, 19 verificações em celular e computador): "Piercing" pede a localização, e ao autorizar voltam os cards com o texto pedido, sem reenviar a palavra; maiúsculas; frase; expressão composta; pedaço de palavra não busca; pendente não aparece.

## Como reverter
1. Em `routes/businesses.ts`, voltar `matches`/`searchBusinesses`/`respostaEmpresas` da versão anterior e remover `termosEmpresa`, `relevancia`, `reconhecerBusca` e `itensPorEmpresa`.
2. Em `ai/intents.ts`, voltar o bloco "empresas perto do usuário".

Nada no banco foi alterado.
