# Estabilização — TypeScript estrito, PostgreSQL e validação do deploy

## O que motivou

O build Docker (`npm run build` = `tsc -p tsconfig.json`) parava em **30 erros de TypeScript** espalhados por 7 arquivos.
Além disso, a validação contra um **PostgreSQL 16 real** (antes os testes só rodavam em SQLite) revelou duas migrações que
**impediam o app de subir** e uma condição de corrida no vínculo de pedidos com o CRM.

## Configuração final do TypeScript (`server/tsconfig.json`)

```json
{
  "compilerOptions": {
    "target": "ES2022", "module": "NodeNext", "moduleResolution": "NodeNext",
    "outDir": "dist", "rootDir": "src",
    "strict": true, "strictNullChecks": true, "noImplicitAny": true,
    "esModuleInterop": true, "resolveJsonModule": true,
    "types": ["node"], "sourceMap": false
  },
  "include": ["src/**/*.ts"]
}
```

- `strict`, `strictNullChecks` e `noImplicitAny` estão **explícitos**.
- `skipLibCheck` foi **removido**: o projeto compila sem erros também conferindo os arquivos `.d.ts`.
- Nenhuma regra do compilador foi desligada.

Compilação conferida com TypeScript 6.0.3 e com o compilador nativo 7.0.2. Nos dois casos foram usados `@types/node` 22.x
(a mesma linha travada no `package-lock.json`) e 26.x. Resultado: **0 erros**, com e sem `skipLibCheck`. O build com
emissão gera 151 arquivos `.js`, um para cada `.ts`.

## Causa raiz dos erros de nulidade

`fail()` (em `lib/http.ts`) era uma *arrow function* atribuída a `const`. Nessa forma, o TypeScript **não** entende o
retorno `never`. Por isso, `if (!b) fail(404, …)` não garantia que `b` existia nas linhas seguintes, e o código acumulou
`b!` para silenciar o compilador.

Agora `fail` é uma **declaração de função**. Depois de `if (!x) fail(...)`, o compilador já sabe que `x` existe, e os
`!` deixaram de ser necessários.

## Arquivos corrigidos (os 7 do pedido)

| Arquivo | Correção |
|---|---|
| `lib/crm.ts` | Datas possivelmente nulas tratadas com `msDe()`. A ordenação da linha do tempo aceita data ausente. Contagens `COUNT(*)` lidas com `?.n` (sem linha = 0). O filtro por etiqueta não perde o estreitamento dentro do callback. O `reduce` de itens foi tipado. 15 `!` removidos. |
| `routes/ads.ts` | 61 `!` removidos: a nulidade já é garantida por `fail`. Foram retirados `as any` em `impactoTroca`, `(u as any).name`, `null as any` e `ctx as any` (rota de planos). |
| `routes/learning.ts` | `getConfig<Record<string, unknown>>` no lugar de `any`. 1 `!` removido. |
| `ai/adaptive.ts` | Interface `Aprendizado` completada com os campos reais da tabela (`revisao`, `revisadoEm`, `notaRevisao`, `regraOriginal`). Novos tipos: `LearningRow`, `HistoricoEvento`, `Revisao` (com o guard `ehRevisao`), `AdaptiveCfg` e `ApptData`. Consultas tipadas com `q<LearningRow>`. Registro inexistente responde 404 em `relerAprendizado`. **0 `any`**, nenhum `!`. |
| `ai/agentes-dominio.ts` | Tipos de linha para cada tabela consultada (`ItemRow`, `PedidoRow`, `TarefaRow`…). Novos tipos `F10Cfg`, `F10Salvo`, `F10Patch`, `LimitesF10`, `EmpresaF10`, `EtapaTarefa`, `DecisaoTarefa` e `AcaoRegistrada`. Validadores reescritos com `unknown` mais estreitamento (`ehObj`, `mapaAgentes`, `escoposDe`, `ehLimite`), com as **mesmas mensagens e regras**. `catch (e)` passa por `campoErro()` e `msgErro()`. `reduce<number>` explícito. `EP.aposCriar` tipado; o tipo `Montado` passou a ser exportado de `execucao-planos.ts`. **0 `any`, 0 `!`.** |
| `ai/feedback.ts` | Tipos `FeedbackRow`, `Snapshot`, `Exemplo`, `Grupo` e `FeedbackBody`. Removidos `as any[]`, `(snapshot as any)` e os callbacks `any` de `sort`/`map`. **0 `any`.** 2 `!` removidos. |
| `lib/coin-central.ts` | A criação do grupo usa `INSERT … RETURNING id` em vez de uma segunda consulta que poderia vir vazia. Contagens com `?.n ?? 0`. `flat()` tipado com `reduce<Record<string, unknown>>`. 6 `!` removidos. |

Dentro desses 7 arquivos não sobrou **nenhum** `!` de não nulidade. Ainda há `any` herdados do código anterior, todos em
corpos de requisição e consultas: `crm.ts` 62 ocorrências, `ads.ts` 40, `coin-central.ts` 45. Eles não silenciam nenhum erro do
compilador. Os que haviam sido criados para contornar erros, em `learning.ts`, `adaptive.ts` e `agentes-dominio.ts`,
foram todos removidos.

## Correções de compatibilidade com PostgreSQL (encontradas rodando contra PostgreSQL 16 real)

1. **`migrations/021_laboratorio_ia.sql`**: a coluna `similar` é palavra reservada no PostgreSQL (`SIMILAR TO`), e a
   migração falhava com `syntax error at or near "similar"`. Como o app aplica as migrações ao subir, **o app não subia**
   num banco em que a 021 ainda não estava aplicada. A coluna agora é `"similar"` (entre aspas). É o mesmo nome de coluna,
   então nada muda se a 021 já foi aplicada. `ai/lab.ts` também usa `"similar"` no `UPDATE`.
2. **`migrations/039_modalidade_empresa.sql`**: agora usa `ADD COLUMN IF NOT EXISTS`. A migração **não é executada de
   novo** quando já consta em `schema_migrations`, e isso não mudou. A alteração evita que o app trave se a coluna foi
   criada à mão sem o registro. Antes disso, essa situação dava `column "modalidade" already exists`. O SQLite dos testes
   recebe a forma simples (`db/sqlite.ts`).
3. **`routes/businesses.ts`**: o vínculo do pedido com o CRM passou a ser feito **depois** que cupom, moedas e Pix são
   confirmados. Antes, se um deles falhasse, o pedido era desfeito, mas o vínculo em segundo plano podia chegar depois.
   Isso deixava no CRM um pedido que não existia mais. Só aparecia com o PostgreSQL de verdade, que tem conexões
   paralelas.

## Validação feita neste ambiente

| Verificação | Resultado |
|---|---|
| `tsc` estrito (TS 6.0.3 e 7.0.2, `@types/node` 22 e 26, com e sem `skipLibCheck`) | 0 erros |
| Suíte do servidor (SQLite) | 291/291. Inclui um teste novo da validação tipada da configuração multiagente. |
| Mesma suíte contra **PostgreSQL 16 real** | 291/291. A cópia temporária do roteiro ajusta só as leituras do próprio teste que supunham JSON em texto (SQLite). |
| Migrações 001→039 aplicadas do zero no PostgreSQL 16 | OK (antes parava na 021) |
| Build de **imagem Docker** (réplica do Dockerfile com base local) | Compilou dentro da imagem, contêiner `healthy` |
| Contêiner: logs, `/api/health`, smoke test, conta real (login, sessão, módulos, chat com IA, histórico, logout) | 7/7 e 17/17 |
| Reinício do contêiner | `[migrate] banco já está atualizado` (nada é reaplicado) |
| Regressão no navegador (47 roteiros) | Ver o relatório da entrega |

**Limite:** este ambiente não tem acesso à internet. Por isso, a imagem oficial `node:22-alpine` não pôde ser baixada,
nem o `npm install` executado. O build Docker foi feito com uma **réplica** do Dockerfile, igual em tudo exceto em dois
pontos:

- a imagem base é local, também com Node 22;
- os pacotes já presentes no ambiente substituem o `npm install`.

A IA usada foi um dublê local. O build oficial e o teste com a IA real devem ser feitos no servidor, com o script abaixo.

## Todos os arquivos alterados

- **Configuração:** `server/tsconfig.json`.
- **Base:** `src/lib/http.ts` (`fail` como declaração de função).
- **Os 7 arquivos:** `src/lib/crm.ts`, `src/routes/ads.ts`, `src/routes/learning.ts`, `src/ai/adaptive.ts`,
  `src/ai/agentes-dominio.ts`, `src/ai/feedback.ts`, `src/lib/coin-central.ts`.
- **Apoio:** `src/ai/execucao-planos.ts` (exporta o tipo `Montado`), `src/ai/lab.ts` (`"similar"`),
  `src/routes/businesses.ts` (vínculo com o CRM depois do pedido definitivo), `src/db/sqlite.ts` (forma idempotente do
  `ADD COLUMN`).
- **Migrações:** `021_laboratorio_ia.sql` e `039_modalidade_empresa.sql`.
- **Testes:** `test/run.ts`. Ganhou o teste novo e passou a aceitar `TEST_PG_URL` para rodar contra PostgreSQL. As
  leituras de JSON funcionam nos dois bancos.
- **Deploy:** `deploy/scripts/validar-estabilizacao.sh` e `deploy/scripts/validar-funcional.mjs` (novos).
- **Documentação:** este documento e o `README.md`.

## Testes contra PostgreSQL (desenvolvimento)

```bash
cd server && npm install
TEST_PG_URL=postgres://usuario@localhost/banco_de_teste_vazio npm test
```

Use **sempre um banco vazio, criado só para isso**. A suíte cria e altera dados. Nunca aponte para o banco de produção.

## Como validar no servidor

```bash
MA_EMAIL=voce@exemplo.com MA_SENHA='sua-senha' bash deploy/scripts/validar-estabilizacao.sh
```

O script segue estas etapas:

1. Confere a configuração do Docker Compose.
2. Faz o build da imagem. Se falhar, para e o contêiner atual continua no ar.
3. Mostra quais migrações já estão registradas, como a 021 e a 039, e se a coluna `modalidade` existe.
4. Faz um **backup novo**. Os backups anteriores não são tocados.
5. Sobe **só o app**; o banco continua o mesmo.
6. Espera o estado `healthy`.
7. Filtra os logs e roda o `smoke-test.sh`.
8. Roda `validar-funcional.mjs` dentro do contêiner, com a sua conta.

O script não altera o `.env`. O `docker-compose.override.yml` é preservado e aplicado normalmente pelo Compose.

Também é possível rodar só o teste funcional: `MA_EMAIL=… MA_SENHA=… node deploy/scripts/validar-funcional.mjs`. Ele
confere o **conteúdo** das respostas, e não só o status HTTP. Cria uma conversa de teste, que pode ser apagada com
`MA_LIMPAR=1`.

## Como reverter

- Código: volte à versão anterior do ZIP ou do repositório e faça `docker compose up -d --build app`.
- As alterações nas migrações 021 e 039 não mudam a estrutura de quem já as aplicou, então não há nada a desfazer no
  banco.
- Se precisar recuperar dados, use `deploy/scripts/restore.sh` com o backup gerado na etapa 4. Os backups antigos em
  `backups/` continuam lá.
