# MCoins em Sua empresa → Ajustes

## Auditoria (antes)

- A opção "MCoins do Meu Assistente" aparecia em Ajustes para **toda empresa do plano 4**, mesmo sem nenhuma moeda vinculada. O ícone era uma estrela.
- A tela só listava os vínculos (aceitar, recusar, pausar). Não mostrava números, cotação, histórico nem a moeda própria da empresa.
- A empresa pode ter moedas de duas formas, as duas criadas **só pelo administrador**:
  1. **Moeda própria:** `coins.business_id` = a empresa.
  2. **Moeda vinculada** (ex.: MCoin do Meu Assistente): uma linha em `coin_links` com a situação pendente, ativo, pausado, recusado ou revogado.
- Os números vêm do livro-razão `coin_ledger`, que tem a emissora e a vinculada de cada movimentação.
- O Mercado já tem a aba de MCoins com as informações gerais. Ela não mudou.

## Regras implementadas

| Situação | Ajustes |
|---|---|
| Sem moeda própria e sem vínculo | **Sem** a opção MCoins (informações gerais só no Mercado) |
| Vínculo pendente, ativo, pausado ou recusado | **Com** a opção MCoins |
| Moeda própria criada pelo administrador | **Com** a opção MCoins |
| Vínculo removido (revogado) e sem outra moeda | **Sem** a opção. O histórico continua no banco |

**Atualização automática:** a lista de Ajustes vem de `GET /api/v2/ads/mine`, que agora informa `temMcoins` para cada empresa do próprio dono. Basta abrir Ajustes de novo para a opção aparecer ou sumir, sem nenhuma configuração extra.

**Ícone:** estrela → **moeda** (desenho de moedas, no mesmo traço e cor dos outros ícones). O registro de ícones continua sem repetição.

## Painel (somente consulta e acompanhamento)

`GET /api/v2/ads/:id/mcoins/painel`, só para o **proprietário** da empresa. Outro usuário recebe 404 e quem não está logado recebe 401.

Para cada moeda:
- **Identificação:**
  - nome e símbolo;
  - código (`MC-MA-…` / `MC-EM-…`);
  - desenho da moeda, com logotipo quando houver;
  - emissora.
- **Situação da moeda** (ativa, em preparação, suspensa) e **situação do vínculo** (aguardando, aceita, pausada, recusada).
- **Cotação:** desconto por moeda e valor de referência ("Não configurado" quando for zero).
- **Números**, que mudam conforme o tipo de moeda:

  | Moeda | Números mostrados |
  |---|---|
  | Própria | emitidas, distribuídas aos clientes, utilizadas em pedidos, disponíveis para distribuir, em circulação, clientes com saldo, desconto concedido |
  | Vinculada | recebidas em pedidos da empresa, devolvidas (estornos), saldo recebido, pedidos com MCoins, desconto concedido, em circulação com clientes |

- **Distribuição e resgates** (moeda própria): distribuições do administrador, moedas ganhas em compras, resgates e estornos.
- **Regras de utilização e benefícios:**
  - desconto por moeda;
  - % máximo e compra mínima;
  - regras do vínculo;
  - regra de adesão quando estiver ligada.
- **Histórico de movimentações**: tipo, quantidade, pedido, desconto e data. **Sem** nome, e-mail ou saldo dos clientes.
- As ações que já existiam (**Aceitar, Recusar, Pausar uso, Retomar**) continuam iguais.

Criar, editar, distribuir e vincular moedas continua **exclusivamente** no painel administrativo. Nenhum saldo é criado ou recalculado: tudo é lido de `coins`, `coin_links` e `coin_ledger`.

## Arquivos

| Arquivo | Mudança |
|---|---|
| `server/src/routes/coins.ts` | `empresaTemMcoins()` e `businessMcoinsPainelGet()` |
| `server/src/routes/ads.ts` | `temMcoins` em `GET /api/v2/ads/mine` |
| `server/src/app.ts` | Rota `GET /api/v2/ads/:id/mcoins/painel` |
| `frontend/public/modules-addon.js` | Ícone de moeda; opção condicionada a `temMcoins`; novo painel (`lojaMcoins`). Versão 136 |
| `server/test/run.ts` | Ciclo completo no teste da integradora (sem vínculo → vínculo → revogado → recusado), números, privacidade e acesso; ícone esperado `coin` |
| `server/test/browser/mcoins_integradora.py` | Teste pela tela |
| `server/test/browser/icones_ajustes.py` | Ajustado ao ícone de moeda |

**Sem alteração:**
- banco (nenhuma migração);
- regras de uso no checkout;
- carteira;
- Mercado;
- painel administrativo de MCoins.

## Publicação

Suba no GitHub e rode o `update.sh` de sempre.
