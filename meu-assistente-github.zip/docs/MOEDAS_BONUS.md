# Moedas digitais de bônus

Crédito promocional **fechado** de cada empresa (sem negociação, saque ou transferência), usado para fidelizar e dar desconto na empresa emissora. Código: `server/src/lib/coins.ts`, `server/src/routes/coins.ts`, migração `019_moedas_bonus.sql`, desenho em `frontend/public/coin-art.js`.

## Onde fica
- **Painel → Moedas de bônus** (administrador): ligar/desligar o sistema, biblioteca de modelos, criar/editar/publicar/suspender, distribuir, histórico, saldos, alterações, adesão por compra.
- **Mercado** → 3ª categoria "Moedas de bônus" (só aparece com o sistema ligado e ao menos uma moeda publicada). Toque na moeda: página com totais, gráfico, saldo e regras.
- **Carteira do cliente**: `/x/carteira` (saldos por empresa, histórico, valor em desconto, regras). Atalho "Minha carteira" no Mercado.
- **Checkout** da loja: bloco "Moedas de bônus" (− / + / usar o máximo) com total recalculado.

## Biblioteca (10 modelos reais, com pré-visualização, ampliar e selecionar)
Dourada premium · Prateada · Azul tecnológica · Verde de recompensas · Preta sofisticada · Roxa futurista · Efeito metálico · Minimalista · Símbolo personalizado · Identidade corporativa.
Fluxo: escolher modelo → personalizar (nome, sigla, descrição, finalidade, quantidade, valor de referência, desconto por moeda, cores, logotipo, empresa) → ver a prévia no Mercado e na carteira → salvar ou salvar e publicar. Trocar o modelo depois não altera saldos, histórico ou movimentações (a troca fica registrada). Empresas diferentes podem usar o mesmo modelo; cada empresa tem **uma** moeda e saldos próprios.

## Regras e segurança
- Saldo nunca negativo: débito condicional (`balance >= n`) + `CHECK` no banco.
- Sem duplicidade: toda movimentação tem chave de idempotência única por moeda (`coin_ledger(coin_id, idem)`); repetir a operação devolve a original.
- Estoque: distribuir só até a quantidade total criada; reduzir o total abaixo do já distribuído é recusado.
- Desconto só na empresa emissora; máximo = valor dos itens (não inclui entrega). Moeda suspensa ou sistema desligado: não distribui nem desconta; saldos preservados.
- Pedido recusado/cancelado (ou Pix que não pôde ser gerado): moedas devolvidas **uma vez** (estorno).
- Corrida de dois pedidos gastando o mesmo saldo: só um passa.
- Alterações de valor, quantidade, modelo, cores e situação ficam em `coin_changes`; toda movimentação em `coin_ledger`; ações do painel na auditoria geral. Sem transferência entre clientes: não existe rota para isso.

## Valorização e gráficos
O **valor de referência é fixo**, definido pelo administrador, e não há valorização fictícia. O gráfico mostra a evolução acumulada da **distribuição** e da **utilização em descontos** (adesão dos clientes), claramente separada de preço.

## Adesão por compra (nasce desativada)
Painel → Moedas de bônus → Adesão por compra: regra "a cada R$ X, N moedas" ou quantidade fixa, compra mínima, limite por cliente e empresas participantes. Concede depois da confirmação do pagamento (online confirmado ou pedido concluído e pago), uma vez por pedido, sobre o valor dos itens já sem o desconto das moedas; respeita o estoque.

## Integrações
Mercado, painel, cadastro de empresas (moeda por empresa), clientes (carteira), financeiro/pedidos (desconto no total; receita lançada pelo valor efetivamente pago), marketing (a adesão usa a mesma confirmação de pagamento) e Cérebro (capacidades "Moedas de bônus" e "Adesão por compra" com status real).

## Limitações
- Desconto só em **pedidos de produtos** na loja do app; agendamentos de serviços e o agente (visitante sem login) ainda não usam moedas.
- Quantidades inteiras de moedas.
- O CRM completo ainda não existe; a visão de clientes calculada não lê moedas.
- O chat não distribui moedas nem promete: só o painel e a adesão por compra.

Testes: `server/test/run.ts` (3 testes de moedas) e `server/test/browser/moedas_bonus.py`.
