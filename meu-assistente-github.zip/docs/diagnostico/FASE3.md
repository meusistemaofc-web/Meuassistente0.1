# Fase 3 — Diagnóstico, estabilidade e excelência inteligente

Esta fase avalia o desempenho real do Núcleo de Inteligência (Nível 1 + Nível 2) com medições reproduzíveis, aplica **correções pontuais** só onde a medição apontou falha e deixa indicadores contínuos para acompanhar a evolução. O núcleo **não foi reconstruído**: nenhuma capacidade foi duplicada e nenhum modelo ou integração foi trocado.

## Método
1. **Corpus sintético de conversas reais** (`server/src/ai/diagnostico/corpus.ts`): 126 mensagens e 29 respostas escritas à mão. Elas cobrem formal, informal, gíria, texto sem acento, ditado por voz sem pontuação, erros de digitação e emoji. **Nenhuma conversa de usuário foi usada.** Cada caso traz o comportamento correto (o que uma pessoa atenta faria), não o que o código fazia.
2. **Conjunto de validação separado** (49 verificações): escrito depois das correções e rodado uma vez sem ajustes, para medir se a melhora **generaliza** em vez de só decorar o corpus.
3. **Executor** (`server/src/ai/diagnostico/executar.ts`): roda o corpus contra os componentes reais (intenção, lacunas, ambiguidade, contradição, emoção, registro, especialistas, planejamento, fio da conversa, linguagem, memória, confiabilidade, naturalidade, avaliação e autoverificação), mede o acerto por área, lista cada falha com o esperado e o obtido e mede a latência de cada função.
4. **Desempenho de ponta a ponta:** a telemetria do chat que já existia (`lib/timing.ts`) passou a separar a etapa "ia" em **preparo, modelo, ferramentas e conclusão** e a contar as **consultas ao banco por mensagem**. A contagem é exata por requisição, pelo contexto assíncrono, e não mistura requisições simultâneas. `DIAG_CONSULTAS=1` registra no log quais consultas se repetem.

Linha de comando: `npx tsx test/diagnostico/diagnostico.ts <rótulo>` e `--comparar antes depois`. Os resultados ficam em `docs/diagnostico/`.

## Resultados — antes × depois
| Indicador | Antes | Depois |
|---|---|---|
| Acerto no corpus (165 verificações) | **86,1%** | **100%** |
| Validação com casos novos (49 verificações) | 91,8% na primeira medição, já com as correções do corpus | 100% (depois de generalizar 3 regras) |
| Consultas ao banco por mensagem com IA | **72** (p95 78) | **34** (p95 39) |
| Consultas ao banco por mensagem interna | 29 | 16 |
| Custo das etapas determinísticas por mensagem | 43 µs | 54 µs (desprezível) |

O detalhe por área e a lista de falhas corrigidas estão em `COMPARACAO.md`. Os números brutos estão em `fase3-antes.json`, `fase3-depois.json`, `desempenho-antes.json` e `desempenho-depois.json`.

Por área, antes → depois:
- planejamento 58% → 100%;
- naturalidade 55% → 100%;
- confiabilidade 75% → 100%;
- contradição 75% → 100%;
- especialistas 82% → 100%;
- avaliação 80% → 100%;
- linguagem 86% → 100%;
- intenção 93% → 100%.

As demais áreas já estavam em 100%.

## Problemas encontrados e correções pontuais
| Problema medido | Exemplo real do corpus | Correção (componente) |
|---|---|---|
| Ditado por voz sem pontuação virava 2 etapas em vez de 3 | "marca o dentista amanha as 10 cria uma tarefa… e me lembra de pagar a luz" | Divisão antes de cada verbo de ação, aceita só quando todos os pedaços são ações (`planejador.ts`) |
| "uma tarefa de X e outra de Y", ", agora marca…", "o que tenho e quanto gastei?" não viravam plano | — | "e outra/mais uma" herda a ação; ", agora" separa e cria dependência; perguntas vêm antes de registros (`planejador.ts`) |
| Dependência "depois" nunca era registrada | "agenda… e depois registra…" | O conectivo é lido entre as partes (antes era apagado na divisão) (`planejador.ts`) |
| Afirmações nominais passavam sem conferência | "Lembrete criado para as 18h!", "Já deixei tudo certinho na sua agenda" | Conferência de afirmações nominais; vale só quando nenhuma consulta foi feita, para não confundir com descrever dados existentes (`cognition.ts`) |
| Fórmulas prontas | "Ótima pergunta!", "Fico à disposição…", "Espero que isso ajude!", "Qualquer coisa, é só me chamar" | Removidas no início e no fim; se a resposta era só fórmula, fica uma frase curta. Também sinalizadas na avaliação (`cognition.ts`) |
| Falsa contradição entre assuntos diferentes | dentista sexta 10h × reunião amanhã 14h ("agenda" em comum) | Verbos de comando e palavras de tempo deixam de contar como assunto (`cognition.ts`) |
| Intenção | "não, o valor certo é 45" (lia como negação), "manda ver" (lia como comando) | Formas de correção e de confirmação fixas (`cognition.ts`) |
| Especialistas com vocabulário informal | "quanto entrou", "30 conto", "bota… na lista", "guarda que…", "fecha a agenda da empresa" | Vocabulário ampliado; a agenda da empresa vence a pessoal quando a mensagem fala da empresa (`especialistas.ts`) |
| Referência por contração | "quanto falta pagar **dessa** conta?" | "dessa/desta/nessa…" reconhecidas (`nucleo.ts`) |
| Formato pedido | "resume pra mim…" | Forma informal do imperativo (`nucleo.ts`) |
| **Gargalo de velocidade:** 30 das 72 consultas eram leituras repetidas da mesma configuração, mais 7 de módulos do usuário e 4 conferências da base de conhecimento | `app_config` lida 30× numa mensagem | **Memória por requisição:** cada configuração é lida uma vez por mensagem; as chaves que o chat sempre usa vêm numa só consulta. Nada é compartilhado entre requisições, então não há dado desatualizado nem conflito entre processos. Gravação na própria requisição vale na hora (`db/index.ts`, `lib/settings.ts`, `lib/usermod.ts`, `ai/knowledge.ts`, `ai/proativo.ts`, `routes/chat.ts`) |

Nenhuma funcionalidade que estava funcionando foi alterada. As 229 verificações da suíte do servidor e os 30 scripts de navegador continuam passando.

## Indicadores contínuos
Ficam em **Painel → Cérebro e busca → Inteligência avançada → Diagnóstico e desempenho**:
- acerto do diagnóstico, incluindo os casos novos, com a lista de falhas;
- tempo médio e p95 das respostas com IA e das internas;
- consultas por mensagem;
- tempo de cada etapa da IA.

O **monitor** (a cada 6 h, já existente) agora também roda o diagnóstico, guarda uma fotografia do desempenho em `intel_runs` e avisa os administradores quando:
- alguma verificação do diagnóstico falha ou o acerto cai;
- a média passa de 60 consultas por mensagem com IA;
- o p95 do tempo de resposta sobe mais de 50% (e mais de 1,5 s) em relação à fotografia anterior.

O botão "Rodar diagnóstico agora" fica no painel, e a rota é `POST /api/panel/inteligencia/diagnostico`.

## Regressão automatizada
- **Diagnóstico:** a suíte do servidor exige 100% no corpus e na validação. Qualquer mudança que piore a compreensão quebra o teste.
- **Desempenho:** a suíte exige no máximo 45 consultas por mensagem com IA (eram 72).
- **Memória por requisição:** testes garantem que a releitura não volta ao banco, que a gravação vale na hora e que alterar o retorno não altera a memória.

## Reversão
- **Memória por requisição:** `MEMO_REQUISICAO=0` volta a ler tudo direto do banco (o contador continua funcionando).
- **Regras corrigidas:** cada correção é uma mudança pequena e isolada no módulo citado. As chaves do painel (Nível 1 e Nível 2) continuam desligando cada capacidade.
- **Banco:** a fase não criou tabelas, só registros novos em `intel_runs` (tipos `diagnostico` e `desempenho`).

## Privacidade
O corpus é 100% sintético. Os indicadores guardam só números, áreas e ids de casos do corpus, nunca texto de conversa. Nenhuma conversa de usuário é usada para treinar ou ajustar regras sem autorização (o feedback compartilhado do Nível 2 continua exigindo consentimento explícito).

## Limites (honestos)
- 100% no corpus e na validação mede **as situações escritas**, não toda conversa possível. O corpus deve crescer com novos casos quando o feedback dos usuários (Nível 2) apontar falhas.
- Os testes usam IA simulada, então o tempo do **modelo** real (de longe a maior parte da espera) não é medido aqui. Em produção, ele aparece no painel como "Etapas da IA".
- O ganho de velocidade das consultas foi medido em SQLite local, onde cada consulta custa pouco. No PostgreSQL, cada consulta tem ida e volta de rede, então cortar 38 consultas por mensagem pesa mais. O valor exato depende do servidor.
- A contagem de consultas cobre o chat principal. Outras rotas não são medidas.
