# Imagens dos itens nos pedidos

Cada item de um pedido (produto ou serviço) mostra a imagem do **próprio cadastro**, ao lado das informações. A lógica de criação, recebimento e processamento dos pedidos não mudou, e nenhuma imagem é copiada.

## Onde aparece
- **Sua empresa → Pedidos.**
  - **Lista:** cada item com miniatura (44 px), nome, variação, observação, **quantidade × preço unitário** e o **total do item** à direita. Os agendamentos também mostram a imagem do serviço.
  - **Detalhes (botão novo):** os mesmos itens com imagem maior (56 px), mais:
    - subtotal, entrega, cupom e moedas, quando existem;
    - total;
    - entrega ou retirada, pagamento, cliente, WhatsApp, data e observação.
- **Solicitações de agendamento:** imagem do serviço na lista e em Detalhes.
- **Central de Lojas Conectadas:** itens dos pedidos com imagem; agendamentos com a imagem do serviço.

**Sem imagem:** o item cadastrado sem foto, apagado ou cuja imagem falha ao carregar mostra um **espaço reservado discreto**, do mesmo tamanho. O layout não muda.

**Correção (20/11):** cada item volta a mostrar **todas** as escolhas (variação + opções/adicionais, como "Cor: Branca, Tamanho: M · Borda: Catupiry"), como antes desta mudança. Por um momento só o rótulo curto da variação aparecia.

## Como a imagem é encontrada
1. Ao criar o pedido, cada item passa a guardar só uma **referência estável** da foto usada naquele momento: `fotoRef`, uma impressão digital de 16 caracteres. Os agendamentos guardam `servicoFotoRef`. A imagem em si não é copiada.
2. Para mostrar, o servidor busca o item pelo relacionamento que já existia:
   - `pid` do item e `varianteId` da variação escolhida;
   - `servicoId` nos agendamentos;
   - sempre da **mesma empresa** do pedido.

   Entre as fotos desse item, usa a que tem a mesma impressão digital.
3. **Edições depois do pedido:**
   - o lojista reordena as fotos ou põe outra foto principal: o pedido antigo continua com a foto da compra;
   - a foto da compra foi **removida** do cadastro: usa a foto atual do **mesmo** item (nunca a de outro);
   - o item foi **apagado**: espaço reservado (ou a miniatura que pedidos de variação já guardavam).
4. **Pedidos antigos** (feitos antes desta versão, sem referência): mostram a miniatura da variação que já guardavam ou a foto atual do item.

**Acesso:** a imagem chega por um endereço **assinado**, `/api/v2/pedidos/:id/itens/:i/foto?s=…`. O servidor só o entrega junto com a lista de pedidos para quem já pode ver aquele pedido (dono, aprovadores e central conectada). A assinatura vale só para aquele pedido e aquele item.

## Testes
- **Servidor** (`run.ts`), 1 teste novo:
  - pedido de 1 item;
  - pedido de vários itens, cada um com a sua foto, incluindo a foto da variação;
  - item sem foto: `null`;
  - quantidade e preço unitário;
  - referência sem cópia de imagem;
  - assinatura;
  - trocar a foto principal não muda o pedido antigo;
  - pedido novo com a foto nova;
  - foto removida → foto atual do mesmo item;
  - item apagado → espaço reservado;
  - agendamento e solicitação com a foto do serviço;
  - total do pedido inalterado.

  Resultado: **341/341**.
- **Navegador** (`test/browser/pedidos_imagens.py`): **20/20**, no celular e no computador. A cor de cada imagem exibida é conferida contra a foto do item. Cobre:
  - lista;
  - Detalhes;
  - espaço reservado;
  - valores;
  - sem sobreposição e sem rolagem lateral;
  - Solicitações (lista e Detalhes);
  - central de Lojas Conectadas;
  - pedido antigo × pedido novo depois da edição.
- **Regressão:**
  - `lojas_conectadas.py` 28/28;
  - `permissoes_agendamento.py` 42/42;
  - `contadores_sincronizados.py` 15/15;
  - `checkout_organizado.py` 17/17.

## Arquivos
| Arquivo | Mudança |
|---|---|
| `server/src/lib/catalogo.ts` | `refFoto`, `fotoAtual`, busca da foto do item (`fotosDosItens`, `fotoDoItem`); `fotoRef` nos itens |
| `server/src/routes/businesses.ts` | `servicoFotoRef` nos agendamentos; `comFotos` na lista de pedidos da loja; rota da imagem assinada |
| `server/src/routes/perm-agenda.ts` | Imagem do serviço nas solicitações |
| `server/src/routes/lojas.ts` | Imagens nos pedidos da central |
| `server/src/app.ts` | Rota `/api/v2/pedidos/:id/itens/:i/foto`; `modules-addon.js?v=145` |
| `frontend/public/modules-addon.js` | Linha do item com imagem, Detalhes do pedido, Solicitações e central |
| `server/test/run.ts`, `server/test/browser/pedidos_imagens.py` | Testes |

Não há migração de banco.
