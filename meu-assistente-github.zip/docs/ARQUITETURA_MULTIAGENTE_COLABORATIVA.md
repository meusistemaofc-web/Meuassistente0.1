# Fase 10 — Arquitetura multiagente e inteligência colaborativa

A Fase 10 **evolui** a coordenação multiagente da Fase 4. Nada foi substituído:
- **Assistente principal:** continua sendo a única voz com o usuário.
- **Coordenador central (`orquestrar`):** continua sendo o orquestrador e passou a contar com **7 agentes especializados de domínio** como colaboradores internos.
- **O que entrou:** validação (debate) para decisões complexas, memória compartilhada entre execuções, execução coordenada com dependências, autonomia de 1 a 4 e a **Central de Agentes** no painel.

Não se trata de treinar o modelo, mas de arquitetura e serviços.

**Código:**
- `server/src/ai/agentes-dominio.ts`: agentes de domínio, seleção, memória, validação, autonomia e registro.
- `server/src/ai/agentes.ts`: orquestrador evoluído.
- `server/src/routes/agentes.ts`: rotas da Central.
- `frontend/public/agentes.html`: página da Central.
- **Migração 038:** só a tabela `agent_tasks`.

## Como uma solicitação passa pelo orquestrador

```
Mensagem → caminhos determinísticos que já existiam (agenda, finanças, execução da Fase 8…) → IA principal
  Análise (Nível 1) + especialistas e plano (Nível 2) → ORQUESTRADOR
  1. Interpreta e mede a complexidade (simples | moderada | complexa)
  2. Seleciona os agentes de domínio citados no pedido (só pedidos de análise/situação ou complexos)
  3. Coleta em paralelo — agentes de domínio, SEM IA, cada um com prazo próprio
  4. Raciocínio (só pedidos complexos) — agentes de IA da Fase 4, em ondas, cada um com a sua fatia dos achados
  5. Divergências + VALIDAÇÃO (só decisões complexas, uma rodada): proposta → crítica → verificação de números → avaliação
  6. Consolidação — a IA principal escreve UMA resposta e executa o que o usuário pediu com as ferramentas
  7. Ações dos agentes conforme a autonomia (1 a 4), sempre pelo motor de execução da Fase 8
  Cada etapa fica registrada com dependências, situação e tempo (agent_tasks)
```

## Os 7 agentes especializados

Eles reúnem e analisam os dados reais do **próprio usuário e das empresas dele**, usando os serviços que já existem, **sem chamada de IA**. Só leem, nunca gravam.

| Agente | Usa (já existia) | Analisa | Ações que pode propor (Fase 8) |
|---|---|---|---|
| Comercial | BI (`bi.resumo`) | faturamento, vendas pagas, ticket, pendente e cancelado, pedidos, mais pedidos | — (raciocínio com IA: Vendas) |
| Agendamentos | Agenda, pedidos de agendamento, Permissões de Agendamento | compromissos da semana, sem lembrete, conflitos de horário, passados em aberto, confirmados, solicitações aguardando aprovação (e há quanto tempo), sugestões aguardando o cliente | lembretes para os compromissos; concluir os passados |
| CRM | `CommercialIntelligenceService` | leads sem acompanhamento, clientes pedindo retorno, oportunidades paradas, recorrentes | tarefas de acompanhamento no CRM |
| Financeiro | Finanças pessoais, contas a pagar, BI | receitas, despesas e saldo do mês, contas vencidas e da semana, a receber, Pix online pendentes | relatório financeiro do mês |
| Administrativo | Pedidos, tarefas, execuções (Fase 8) | pedidos sem decisão, aceitos parados há mais de 2 dias, agendamentos passados não concluídos, solicitações antigas, tarefas atrasadas, execuções pendentes ou com falha | organizar a semana |
| Marketing | Consentimentos, campanhas, cupons | quem autorizou ofertas, campanhas de 30 dias (envios, cliques, taxa), cupons ativos e usos | — (raciocínio com IA: Escrita) |
| Análise e Inteligência | Inteligência preditiva (Fase 7) | sinais de fato e de estimativa (com confiança e base); cruza as áreas quando há 2 ou mais | — (raciocínio com IA: Análise) |

Os 5 agentes de raciocínio da Fase 4 continuam iguais (pesquisa, análise, vendas, planejamento e escrita). Eles entram só em pedidos complexos e recebem **apenas a fatia necessária** dos achados:

| Agente de raciocínio | Achados que recebe |
|---|---|
| Análise | todos |
| Vendas | Comercial, Financeiro, CRM, Marketing e Inteligência |
| Planejamento | Agendamentos, Administrativo, CRM, Financeiro e Inteligência |
| Escrita | Marketing, Agendamentos e CRM (nunca valores financeiros) |
| Pesquisa | nenhum (nunca vê dados do usuário) |

### Exemplo: "analise as vendas, os pagamentos e os clientes da loja e monte uma estratégia"

1. O Comercial reúne vendas e pedidos.
2. O Financeiro analisa valores e pagamentos.
3. O CRM identifica padrões de clientes.
4. A Inteligência entra para cruzar as áreas.
5. Os agentes de Análise, Vendas e Planejamento recebem cada um a sua fatia e contribuem.
6. O orquestrador detecta divergências e a IA principal entrega um relatório único.

## Validação (debate)

- **Quando roda:** só em pedidos **complexos e decisórios** ("vale a pena", "devo", investir, contratar, riscos…) ou quando há divergência entre contribuições. Tarefas simples nunca passam por debate.
- **Etapas:**
  1. **Proposta:** as contribuições dos agentes.
  2. **Crítica:** o agente "Revisão crítica" aponta falhas, riscos e premissas frágeis, ou responde "SEM RESSALVAS".
  3. **Verificação de dados (determinística):** confere os números das contribuições contra os dados e os achados. Os sem base são marcados.
  4. **Avaliação:** o orquestrador entrega à IA principal os pontos a corrigir.
- **Rodada única:** os agentes nunca chamam o orquestrador, o que impede ciclos.
- **Registro:** a decisão fica gravada na tarefa.

## Memória compartilhada

- **O que guarda:** cada tarefa grava em `agent_tasks` os achados (estruturados) e as decisões.
- **Continuidade entre execuções:** uma tarefa nova do **mesmo usuário**, com domínios em comum nos últimos 14 dias, recebe as tarefas anteriores. Cada agente vê só os achados das áreas a que tem acesso.
- **Contexto próprio:** cada agente mantém o seu contexto especializado, sem duplicar a memória global da Fase 5. As experiências e os aprendizados (Fases 5 e 6) continuam sendo usados como antes.
- **Isolamento:** a memória de um usuário ou empresa nunca chega a outro.

## Execução coordenada

| Mecanismo | Como funciona |
|---|---|
| Dependências | coleta → raciocínio → validação → consolidação, registradas em cada etapa |
| Paralelo | coletas em paralelo; agentes de IA em ondas paralelas |
| Tempo | prazo por coleta (padrão 2,5 s) e o orçamento da Fase 4 (no máximo ~35% do prazo da mensagem) |
| Falhas | um agente que falha não derruba os outros nem desfaz o que foi concluído. Sem raciocínio, a resposta sai com os dados coletados (tarefa "parcial"). O disjuntor da Fase 4 continua valendo |
| Duplicidade | o mesmo pedido, na mesma conversa, em até 90 s, reaproveita o resultado, sem novas chamadas. As ações têm a proteção de 10 minutos da Fase 8 |
| Interrupção | pela Central: nenhuma etapa nova começa e a tarefa fica "interrompida" |
| Custo | limite de chamadas de IA por tarefa (padrão 4) e de tarefas com IA por usuário por dia (padrão 40). Acima disso, só agentes de domínio |

## Níveis de autonomia

| Nível | O agente… | Como acontece |
|---|---|---|
| 1 (padrão) | analisa e recomenda | a recomendação vai para a resposta; nada é preparado ou executado |
| 2 | prepara ações para aprovação | cria a execução na Fase 8 **exigindo confirmação**, mesmo para operações automáticas; o usuário responde "sim" |
| 3 | executa ações autorizadas | executa só as operações automáticas da Fase 8 (reversíveis). As que pedem confirmação ou autorização, e as operações completas, ficam preparadas |
| 4 | coordena operações completas | também operações de várias etapas ou em segundo plano (ex.: organizar a semana), até o limite de etapas (padrão 20); acima disso, volta para aprovação |

- **Ações por mensagem:** no máximo uma.
- **Teto por empresa:** a empresa pode ter uma autonomia máxima própria.
- **Pagamentos, exclusões e movimentações financeiras:** nenhum agente propõe. Continuam exigindo **autorização explícita com o código** da Fase 8, sem exceção.
- **Reversão:** as ações podem ser revertidas pela Central (desfaz pela Fase 8) ou pelo próprio usuário em Minhas execuções.

## Central de Agentes (`/admin/agentes`)

O acesso é exclusivo do Administrador Principal e de administradores com a permissão nova **"Central de Agentes"** (`agents.manage`) ou com `panel.manage`. Há atalhos no painel (Cérebro → Inteligência avançada) e no Laboratório de IA.

| Seção | O que mostra e permite |
|---|---|
| Visão geral | estado operacional, agentes ativos, tarefas e chamadas de IA hoje, tarefas sem custo de IA, tempo médio, consumo por dia, tarefas em andamento (com interromper) |
| Agentes | os 7 especializados (especialidade, responsabilidades, estado, liga/desliga, autonomia, ações possíveis, permissões de leitura, métricas), os 5 de raciocínio, a validação, as etapas do fluxo e os especialistas do Laboratório |
| Tarefas | histórico com filtros por situação e por agente; detalhe com etapas, dependências, achados por agente (só a quantidade), decisões, ações, interromper e reverter |
| Empresas | por empresa: quais agentes atuam com os dados dela e a autonomia máxima |
| Limites e controle | chave geral, validação, agentes e tempo por mensagem, chamadas por tarefa, limite diário, agentes de domínio por tarefa, prazo da coleta, etapas no nível 4 |
| Falhas | etapas com falha (30 dias) e agentes pausados |

- **Privacidade:** a Central mostra **só metadados e números**, nunca os dados nem o texto das conversas (testado).
- **Auditoria:** `agentes.config`, `agentes.empresa`, `agentes.tarefa.interromper` e `agentes.tarefa.reverter`.
- **Configuração existente:** a chave `multiagente` da Fase 4 continua valendo, e o quadro do painel continua funcionando.

## Integração com as fases anteriores

| Fase | Como entra |
|---|---|
| Fase 4 | agentes de raciocínio, ondas, disjuntor e unificação da resposta, reaproveitados |
| Fase 5 e 6 | memória, experiências e política aprendida (agentes evitados por área), sem duplicar |
| Fase 7 | previsões alimentam o Agente de Análise e Inteligência e os agentes de raciocínio |
| Fase 8 | todas as ações dos agentes saem pelo motor de execução (níveis, confirmação, autorização, verificação, reversão). Houve só um acréscimo: o "nível mínimo", para preparar uma ação |
| Fase 9 | especialistas do Laboratório aparecem na Central; os testes de agentes do Laboratório continuam iguais |

## Ajuste em um fluxo existente

Pedidos de **análise ou consulta** da agenda ("faça uma análise de como está minha agenda") deixaram de iniciar por engano o fluxo de **criar** compromisso ("Qual é o compromisso?"). Agora vão para a consulta da agenda. Pedidos com verbo de criar ou marcar ("agenda dentista amanhã às 10h") continuam iguais.

## Testes

- **Servidor:** 6 testes novos.
  - **Agentes de domínio:** catálogo e seleção econômica (mensagens simples sem agentes), coleta sem IA com dados reais, isolamento entre empresas, permissões por empresa e por agente.
  - **Colaboração:** fatias por agente de IA, Escrita sem financeiro, Pesquisa sem dados, dependências registradas.
  - **Validação:** só em decisões, crítica única, números sem base marcados, desligável.
  - **Autonomia 1 a 4:** recomenda, prepara com confirmação, executa, operação completa no nível 4, teto da empresa, reversão pela Central.
  - **Execução coordenada:** reaproveitamento sem novas chamadas, falha isolada com alternativa, limites por tarefa e diário, interrupção, sem ciclos.
  - **Central:** acesso, lista, validação, auditoria, histórico sem conteúdo, consumo, empresas; desligado volta à Fase 3.
- **Regressão:** os testes das Fases 4, 8 e 9 seguem passando; o teste de consultas por mensagem segue dentro do limite.
- **Navegador:** `server/test/browser/central_agentes.py`, com 30 verificações no celular e no computador.

## Como reverter

| O quê | Como |
|---|---|
| Desligar tudo | Central → Limites → chave geral (o assistente volta à Fase 3, sem agentes) |
| Um agente | Central → Agentes → desligar |
| Uma empresa | Central → Empresas → desmarcar os agentes ou reduzir a autonomia |
| Ações de uma tarefa | Central → Tarefas → Reverter |
| Código | retirar as chamadas a `agentes-dominio.js` em `agentes.ts` e `assistant.ts`; `DROP TABLE agent_tasks;` |

## Limites

- **Seleção por regras:** a seleção dos agentes de domínio é feita por regras sobre o português (termos da área). Pedidos escritos de forma muito incomum podem não acionar o agente certo.
- **Caminhos determinísticos primeiro:** consultas simples de agenda, finanças e negócios continuam sendo respondidas pelos caminhos determinísticos que já existiam, sem agentes. Os agentes entram nos pedidos de análise e nos complexos.
- **Custo:** os agentes de raciocínio e a revisão crítica fazem chamadas de IA, só em pedidos complexos e dentro dos limites. Os testes usam IA simulada.
