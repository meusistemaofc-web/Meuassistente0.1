# Fase 9 — Laboratório de Inteligência

O Laboratório de Inteligência é o centro administrativo de pesquisa, experimentação, avaliação e evolução controlada do assistente.

- **Endereço:** `/admin/laboratorio`. Também há um atalho "Laboratório de Inteligência →" na aba **Laboratório de IA** do painel.
- **Ambiente isolado:** todos os testes rodam com um usuário sintético, dados fictícios e ferramentas simuladas.
- **Produção:** nada chega aos usuários sem aprovação explícita de um administrador.

A migração **036** só acrescenta tabelas (`lab_challenges`, `lab_runs`, `lab_agents`, `lab_improvements` e `lab_schedules`). Nenhuma tabela existente foi alterada.

## O que foi reaproveitado (sem duplicar)

| Já existia | Como o laboratório usa |
|---|---|
| Modo simulação do assistente (Laboratório de IA) | Base de todas as execuções. Foi estendido com memórias e consultas fictícias, especialistas da variante e o registro da coordenação dos agentes |
| Laboratório de IA (regras) | Instruções testadas num experimento viram proposta de regra lá, com análise de conflitos, simulação, aprovação e publicação próprias |
| Aprendizado contínuo (Fase 6) | Política em lista fechada, versões, teste isolado, liberação gradual, vigilância e reversão. Os ajustes de parâmetro dos experimentos e do diagnóstico viram propostas desse fluxo |
| Avaliação contínua (bateria, corpus, monitor) | Indicadores experimentais da visão geral e entradas do diagnóstico |
| Notas cognitivas por resposta, avaliações 👍/👎, tempos, execuções (Fase 8), multiagente (Fase 4) e saúde dos provedores | Métricas da visão geral e do diagnóstico, sempre só números agregados |
| Coordenação multiagente | Agora aceita especialistas extras. Em produção entram só os publicados; no laboratório, os da variante em teste |

## Seções

### 1. Visão geral

- **Estado do núcleo:** operacional, atenção ou desligado, com cada componente.
- **Métricas reais**, medidas no uso:
  - avaliações positivas;
  - tempo médio de resposta;
  - sucesso das tarefas executadas;
  - sucesso dos agentes.
- **Estimativas**, notas automáticas internas:
  - precisão;
  - naturalidade;
  - qualidade geral;
  - sucesso ponderado.
- **Indicadores experimentais**, em cenários sintéticos: Arena, bateria e corpus.
- **Também mostra:** desempenho dos agentes e especialistas, falhas identificadas e evolução semanal com a linha da Arena.
- **Chaves:** ligar ou desligar o laboratório e os desafios contínuos.

### 2. Arena de desafios

- **Catálogo padrão:** 30 desafios fictícios em 10 categorias. São elas: raciocínio lógico, interpretação contextual, memória, planejamento, resolução de problemas, matemática, interpretação financeira, comunicação profissional, identificação de contradições e execução de tarefas.
- **Avaliação objetiva:** cada desafio tem critérios verificados no texto e nas ações que a IA *tentaria* fazer:
  - menciona / não menciona;
  - usa a ferramenta X, inclusive com dados como `amount=42.9`;
  - não grava nada;
  - faz uma pergunta;
  - apresenta o número;
  - organiza em N itens;
  - limite de palavras;
  - naturalidade mínima (estimativa).
- **Contas:** passam pelo motor matemático, como no chat real.
- **Desafios personalizados:** podem ter conversa anterior, memórias e consultas fictícias. E-mails, telefones, CPF e cartões reais são recusados. Editar um desafio padrão cria uma cópia que o substitui, e um desafio pode ser desativado sem apagar resultados.
- **Rodadas:** rodam em segundo plano, com progresso, até 3 repetições e opção de interromper. Os resultados ficam guardados com nota geral, nota por categoria e o detalhe de cada desafio.

### 3. Simulador de conversas

Conversa de várias mensagens como um usuário fictício. Pode ter memórias e consultas fictícias e instruções experimentais. Cada resposta vem avaliada em:

| Aspecto | Como é avaliado |
|---|---|
| Interpretação | tipo, completude, operações e referência à mensagem anterior |
| Ambiguidades | o que falta ou é contraditório, e se a IA perguntou antes de agir |
| Memória | quais memórias fictícias foram usadas |
| Especialistas e agentes | consultados, com sucesso e divergências |
| Ferramentas | o que a IA tentaria executar (nada é executado) |
| Precisão | valores sem fonte, ação afirmada sem execução e valor dito pelo usuário que não aparece na ação |
| Qualidade | notas internas (estimativa) |

Cada simulação pertence ao administrador que a criou.

### 4. Laboratório de agentes

- **Agentes existentes:** papel, o que podem ler, uso em produção e instruções.
- **Teste individual e comparação:** de 1 a 4 agentes lado a lado, com verificação de valores sem fonte, tamanho e se falou como se fosse com o usuário.
- **Colaboração:** o assistente completo em simulação, com os agentes escolhidos. Mostra cada contribuição, as divergências e se a resposta final saiu única.
- **Especialistas novos:** nome, papel, instruções, palavras que acionam e o que podem ler, numa lista fechada. São recusadas instruções que mandam ignorar regras, contornar segurança ou usar dados de outras pessoas. Nascem em **experimentação** e não chegam à produção.
- **Cópia experimental de um agente existente:** ajustar instruções e acesso e comparar com o original. Se aprovada, substitui só a instrução daquele agente.
- **Ciclo de vida:**
  1. Testar a versão atual.
  2. Enviar para aprovação. Com teste com problemas, é preciso confirmar.
  3. Aprovar gradualmente (5% a 90% dos usuários, estável por usuário) ou para todos.
  4. Promover para todos.
  5. Reverter, que tira da produção.
- **Versões:** editar cria uma nova versão, e em produção continua a versão aprovada até a nova ser testada e aprovada. Uma versão anterior pode ser restaurada como rascunho. Edição com versão desatualizada é recusada (controle de concorrência).
- **Vigilância:** se um especialista em liberação gradual tiver menos de 50% de sucesso em 10 ou mais acionamentos, a liberação é encerrada automaticamente e os administradores são avisados. É o sentido seguro.

### 5. Centro de diagnóstico

Identifica automaticamente, nos últimos 30 dias:

- **respostas inconsistentes:** valores sem fonte, agentes que discordam;
- **falhas de interpretação;**
- **erros recorrentes:** vários usuários, várias semanas;
- **problemas de memória:** perguntar o que já sabia, falhas do corpus;
- **falhas de execução:** por causa e por objetivo;
- **gargalos de desempenho:** etapas lentas, consultas por mensagem, provedores falhando;
- **agentes com baixo desempenho**, inclusive categorias fracas na Arena.

Cada achado traz gravidade, tipo (real, estimativa ou experimental), evidência, causa provável, sugestão técnica e, quando houver, o ajuste de parâmetro sugerido. O botão "Gerar propostas de melhoria" cria as propostas na Central, sem repetir as que já existem.

### 6. Central de melhorias

Reúne num só lugar as propostas de evolução:

- do diagnóstico;
- do aprendizado contínuo (política);
- do Laboratório de IA (regras);
- dos especialistas aguardando aprovação.

Cada proposta mostra **problema, causa provável, solução sugerida, benefícios esperados, riscos, testes necessários e resultado dos testes**.

| Ação | Como funciona |
|---|---|
| Aprovar, rejeitar, testar, promover e reverter | Delegadas ao módulo de origem, com as mesmas regras de lá. Exemplo: uma proposta de política só é aprovada depois do teste isolado da Fase 6 |
| Editar | Ajusta o texto exibido sem alterar o registro de origem. O texto de uma regra é editado no próprio Laboratório de IA e volta a precisar de testes |
| Arquivar | Proposta em produção não pode ser arquivada: é preciso reverter antes |
| Proposta do diagnóstico com ajuste de parâmetro | "Testar" cria a proposta de política e roda o teste isolado |
| Correção técnica | Aprovada para implementação pela equipe. Nada muda sozinho |

### 7. Ambiente de experimentação

Compara a **versão atual** com uma **versão experimental** nos mesmos desafios da Arena, com repetições opcionais para reduzir a variação natural da IA. Pode testar:

- novas instruções;
- novos agentes (especialistas do laboratório);
- estratégias de raciocínio: revisar ou planejar sempre numa área;
- mecanismos de memória: número de memórias e limite de caracteres;
- fluxos de execução: orientação de uso de uma ferramenta;
- estilo das respostas.

A versão experimental vale **só dentro da rodada**. O resultado mostra:

- nota de cada versão e a diferença;
- conclusão (melhor, pior ou equivalente);
- tabela por categoria;
- regressões e melhorias;
- cada desafio lado a lado.

**"Transformar em proposta"** leva o resultado para o fluxo de aprovação existente: parâmetro para o aprendizado contínuo, instruções para o Laboratório de IA, especialista para o próprio ciclo de aprovação.

### 8. Controle de evolução global

Um único fluxo: proposta → teste isolado → aprovação → versão → liberação gradual → monitoramento → promoção ou reversão. A tela mostra:

- versão ativa da política e liberação gradual;
- versões, com restaurar;
- resultado real por versão;
- especialistas em produção (promover e reverter);
- regras publicadas;
- tendência dos desafios contínuos;
- regressões detectadas;
- linha do tempo de todas as mudanças.

**Nenhuma alteração experimental muda o comportamento dos usuários sozinha.** A vigilância automática só age no sentido seguro: encerrar uma liberação gradual com regressão.

### 9. Desafios contínuos

- **Programação:** avaliações periódicas (a cada 6 h, 12 h, 24 h, 48 h ou semanal), com todas as categorias ou só algumas.
- **Execução:** o servidor confere as vencidas a cada 10 minutos e nunca roda duas da mesma avaliação ao mesmo tempo.
- **Comparação:** cada rodada é comparada com a anterior. Queda de 10 pontos na nota, ou de 20 numa categoria, avisa os administradores.
- **Relatório comparativo** em texto, com o histórico de pontuações por categoria e a tendência (melhorando, estável ou piorando).

### 10. Segurança e permissões

- **Acesso:** exclusivo do Administrador Principal e de administradores com a permissão nova **"Laboratório de Inteligência"** (`lab.manage`), ou com "Configurar módulos, IAs…" (`panel.manage`), que já gerenciava o Laboratório de IA.
- **Recusas:** usuário comum e administrador sem permissão recebem 403, e a página mostra "Acesso restrito".
- **Isolamento:**
  - usuário sintético (id 0, sem dados);
  - memórias e consultas fictícias do cenário;
  - ferramentas nunca executam;
  - política e instruções experimentais só dentro da rodada (contexto isolado por execução);
  - especialistas experimentais só no laboratório.
- **Dados sintéticos:** e-mails, telefones, CPF e cartões reais são recusados em desafios, simulações, instruções e especialistas.
- **Auditoria:** toda ação fica em `audit_log` (ações `laboratorio.*`) e aparece na seção Auditoria, junto com as do Laboratório de IA e do aprendizado contínuo.
- **Custo controlado:** até 40 desafios por rodada e 2 rodadas ao mesmo tempo (configurável) e 20 mensagens por simulação.

## Testes

- **Servidor:** 8 testes novos.
  - **Permissões:** 4 perfis × 10 rotas e escrita protegida.
  - **Arena:** catálogo, critérios, personalizados, dado pessoal, cópia editada, desativar e histórico.
  - **Isolamento:** contagem de 15 tabelas de usuários antes e depois de arena, simulação, experimento e colaboração; nenhum dado real nos prompts; instruções experimentais ausentes no chat dos usuários.
  - **Simulador:** várias mensagens, valor ignorado, ambiguidade e simulação de outro administrador.
  - **Experimentos:** mesmos cenários, produção intocada e proposta pelos fluxos existentes sem duplicar.
  - **Agentes:** validação; teste, comparação e colaboração; gradual ~40% por usuário; versão nova sem afetar a produção; concorrência; promoção; participação real no chat; reversão; cópia; restauração; vigilância automática.
  - **Diagnóstico e melhorias:** achados, propostas sem duplicar, testar, editar sem tocar a origem, aprovar, rejeitar e arquivar.
  - **Evolução e contínuos:** comparativo, regressão, relatório, agenda vencida roda uma vez, desligar, auditoria e desempenho.
- **Navegador:** `test/browser/laboratorio_inteligencia.py`, com 28 verificações (390 px e 1280 px).
- **Regressão:** a suíte completa e os demais scripts de navegador continuam passando. O teste de consultas por mensagem segue dentro do limite, porque os especialistas publicados ficam em cache por 1 minuto.

## Como reverter

| O quê | Como |
|---|---|
| Um especialista | Laboratório → Agentes (ou Evolução) → **Reverter**: sai da produção na hora |
| Uma melhoria de política ou regra | Central de melhorias → Reverter / Desativar, ou Evolução → Restaurar versão |
| Pausar o laboratório | Visão geral → desligar "Laboratório ligado" (nada começa) e "Desafios contínuos" |
| Tudo | Reverter os especialistas publicados e então `DROP TABLE lab_challenges, lab_runs, lab_agents, lab_improvements, lab_schedules;`. Sem a tabela `lab_agents`, a coordenação de agentes volta a usar só os agentes existentes |

## Limites

- **Avaliação da Arena:** é objetiva (critérios), sem uma IA "juíza". Naturalidade e qualidade são estimativas internas.
- **Variação da IA:** as respostas variam de uma execução para outra. Use repetições e diferenças de 5 pontos ou mais para decidir.
- **Caminho testado:** a Arena testa o cérebro (IA e motor matemático). Os fluxos determinísticos que gravam dados de verdade (agendamento em partes, lançamento rápido de finanças) continuam cobertos pela suíte de testes do servidor, e não pela Arena.
- **Correções técnicas** (código e infraestrutura) apontadas pelo diagnóstico não são aplicadas automaticamente: são aprovadas para implementação pela equipe.
