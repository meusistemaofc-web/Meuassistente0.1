# Central de Processamento de Arquivos e Mídias (etapa 1)

Um serviço **independente**, criado do zero dentro do projeto, que lê documentos, imagens e mídias **sem depender de IA**. A IA é um segundo nível opcional.

Nesta etapa:

- a central **não está conectada** a nenhum fluxo do Meu Assistente;
- ela **não sobe sozinha** na VPS;
- nada do que existe foi alterado.

## 1. Auditoria da arquitetura atual

| Item | Situação encontrada |
|---|---|
| Linguagem/estrutura | Backend Node.js 22 + TypeScript (`server/`, sem framework, roteador próprio). Frontend PWA estático (`frontend/public`). |
| Banco | PostgreSQL 16 (contêiner `db`, volume `pgdata`). Nos testes, SQLite por uma camada de tradução. |
| Implantação | `Dockerfile` único (app + frontend). `docker-compose.yml` com `db`, `app` (só em `127.0.0.1:3000`) e `whisper` (sem porta publicada). Nginx no servidor faz o HTTPS. `deploy/scripts/update.sh` roda `docker compose up -d --build`. |
| Outros serviços na VPS (documentados) | IA Gateway em `172.17.0.1:8790` (`tools/ia-gateway`) e Ollama em `172.17.0.1:11434`. |
| Recursos da VPS | Hostinger KVM1: 4 GB de RAM e 50 GB de disco, já com PostgreSQL, app, Whisper e Ollama. **Memória é o recurso crítico.** |
| Dependências do app | Só `pg` e `web-push`. Nenhuma biblioteca de PDF, Office, imagem ou OCR. |
| Processamento de arquivos que já existe (preservado) | - `server/src/ai/docs.ts`: comprovantes lidos por IA com visão; extrator simples de texto de PDF (`pdfText`); OCR pelo **OCR.space (serviço externo)**; transcrição pelo Whisper local.<br>- `server/src/lib/menu-import.ts`: importador de cardápio por IA. |
| Portas | Ocupadas: 80/443 (Nginx), 127.0.0.1:3000 (app), 172.17.0.1:8790 (gateway), 11434 (Ollama). Internas: 5432 e 9000.<br>A central usa a **8095 só na rede interna** do Compose, **sem publicar porta no servidor**, então não há conflito. |

Riscos encontrados e como foram tratados:

1. **Memória da VPS.** O contêiner tem limite de 1 GB e de 1 CPU, processa um arquivo por vez (`MIDIA_CONCORRENCIA=1`) e cada arquivo roda num processo com limite de memória próprio.
2. **`update.sh` sobe tudo com `docker compose up`.** A central fica no **perfil `midia`**, que o `up` comum ignora. Foi conferido com `docker compose config`: sem o perfil, a configuração efetiva ficou idêntica à anterior.
3. **O OCR atual envia fotos a um serviço externo (OCR.space).** Não foi alterado. A central faz OCR local e pode substituí-lo numa próxima etapa, se você autorizar.
4. **Este ambiente de desenvolvimento não tem Docker nem internet.**
   - Os testes rodaram com as mesmas ferramentas e versões da imagem: Python 3.13, Tesseract 5, Poppler, FFmpeg e OpenCV 5.
   - O build da imagem deve ser conferido na VPS com `central-midia.sh testar`, que **só constrói e testa**, sem subir nada.

## 2. Proposta técnica

- **Serviço próprio em Python** (`services/central-midia`), com imagem e contêiner próprios.
  - Python tem as bibliotecas locais mais maduras para essas tarefas (OpenCV, openpyxl, python-docx) e convive bem com Tesseract, Poppler e FFmpeg.
  - O app Node não ganhou nenhuma dependência nova.
- **Dois níveis:**
  - **Nível 1** (sempre): extração convencional, sem IA.
  - **Nível 2** (opcional): interpretação com o Ollama da VPS ou com uma API compatível com OpenAI.
    - Só roda quando pedida: `interpretar=1`, ou `interpretar=auto` quando o nível 1 não achou o essencial de um comprovante.
    - Vem **desligada por padrão**.
    - A IA recebe **só o texto** extraído; o arquivo nunca sai da VPS.
- **Ferramentas escolhidas**, só as necessárias:

| Necessidade | Escolhida | Por quê | Avaliadas e não usadas |
|---|---|---|---|
| PDF | Poppler (`pdftotext`, `pdfinfo`, `pdftoppm`) | Rápido, leve, texto com layout, metadados e renderização para OCR | PDF.js/pdf-parse (mais pesados; o Poppler já cobre) |
| OCR | Tesseract 5 (por + eng), por linha de comando | Local, gratuito, baixo consumo, 1 thread | tesseract.js (baixa modelos da internet, mais lento) |
| DOCX | python-docx | Texto, títulos, tabelas, cabeçalhos e propriedades | Mammoth (equivalente em Node; o serviço é Python) |
| XLSX | openpyxl (somente leitura, valores calculados) | Abas, datas e números, sem executar macros | ExcelJS (equivalente em Node) |
| CSV/TXT | Biblioteca padrão + detecção de codificação | Sem dependência | — |
| Imagens | Pillow | Validação, EXIF, proteção contra imagem-bomba, pré-processamento do OCR | Sharp (Node) |
| QR Code e código de barras | OpenCV (headless) | QR (também Pix) e EAN/UPC/Code128 locais | ZXing/ZBar (mais uma dependência sem ganho nesta etapa) |
| Áudio/vídeo | FFmpeg/FFprobe | Metadados e extração de áudio | — |
| Transcrição | **Reaproveita o Whisper que já existe** (`http://whisper:9000`) | Não instala outro modelo | — |

## 3. Estrutura de diretórios

```
services/central-midia/
  Dockerfile               imagem própria (estágios: base, teste, final)
  requirements.txt         dependências fixadas (versões testadas)
  requirements-teste.txt   + pytest
  app/
    main.py                API interna (Starlette/uvicorn), autenticação, fila, limites, registro
    config.py              variáveis de ambiente (padrões seguros)
    identificar.py         identificação pelo conteúdo (assinatura binária)
    seguranca.py           recusas: executáveis, zip-bomba, PDF ativo, nomes, tamanhos
    executor.py            processo isolado com limites de memória/CPU e tempo
    trabalhador.py         processa um arquivo e devolve JSON
    comprovante.py         extração de comprovantes/boletos/NFC-e sem IA
    ia.py                  nível 2 opcional (Ollama ou API compatível)
    registro.py            registro de operações (sem conteúdo)
    processadores/         pdf, office (docx/xlsx), texto (txt/csv), imagem (OCR), codigos (QR/barras/Pix), midia
  tests/                   pytest: conftest (sobe a central real), gerar (arquivos de teste), test_central
server/src/lib/central-midia.ts   cliente opcional do app (usado só pela leitura local de comprovantes)
server/test/central-midia-e2e.ts  ponta a ponta: cliente do app → central real
deploy/scripts/central-midia.sh   verificar, testar, instalar, estado, desativar, remover
```

## 4. API interna

Só a rede interna do Compose alcança `http://central-midia:8095`. As rotas `/v1/*` exigem `Authorization: Bearer <MIDIA_TOKEN>`, conferido em tempo constante. Sem token configurado, a central recusa tudo.

- **`GET /saude`**: sem autenticação, só `{ok, versao, ativa}` (usado pelo healthcheck).
- **`GET /v1/capacidades`**: formatos, versões das ferramentas instaladas, limites e situação do nível 2.
- **`GET /v1/estatisticas`**: contadores e últimas operações, sem conteúdo.
- **`POST /v1/processar`**: corpo = bytes do arquivo. Cabeçalhos opcionais `X-Arquivo-Nome` (URL-encoded), `Content-Type` e `X-Cliente`. Parâmetros:
  - `ocr=auto|sempre|nunca`
  - `codigos=1|0`
  - `comprovante=auto|nunca`
  - `transcrever=0|1`
  - `interpretar=0|1|auto`
  - `idioma=por+eng`

Resposta normalizada (os mesmos campos para todos os formatos):

```json
{ "ok": true, "id": "…", "nivel": 1,
  "arquivo": { "nome", "tamanho", "sha256", "familia", "formato", "mime" },
  "texto": "…", "paginas": [{ "numero", "texto", "ocr" }], "tabelas": [{ "nome", "linhas", "total_linhas" }],
  "metadados": { … }, "codigos": [{ "tipo": "qrcode", "conteudo", "uso": "pix_copia_e_cola", "pix": { "chave", "valor", "crc_valido" } }],
  "comprovante": { "tipo", "direcao", "valor", "data", "hora", "pix", "boleto", "nfce", "documentos", "confianca" },
  "ocr": { "usado", "confianca" }, "avisos": [], "tempo_ms": 0 }
```

Erros: `{ "ok": false, "erro": { "codigo", "mensagem" } }`.

| Situação | Status | Códigos |
|---|---|---|
| Arquivo inválido | 400 | `vazio` |
| Formato recusado | 415 | `executavel`, `formato_nao_suportado`, `formato_antigo_nao_suportado`, `pdf_conteudo_ativo` |
| Arquivo ilegível | 422 | `arquivo_corrompido`, `documento_protegido` |
| Arquivo grande demais | 413 | `arquivo_grande_demais`, `zip_bomba`, `imagem_grande_demais`, `memoria_excedida` |
| Central ocupada | 429 | `central_ocupada` |
| Tempo excedido | 504 | `tempo_excedido` |
| Central indisponível | 503 | `central_desativada`, `token_nao_configurado` |

### Extração de comprovantes sem IA (nível 1)

- **Valores:** prioriza o rotulado ("Valor", "Total"); senão, o maior com R$.
- **Datas e hora.**
- **Tipo:** Pix, boleto, transferência, nota fiscal, cartão ou recibo.
- **Direção:** saída, entrada ou incerta.
- **Pix:** ID da transação (E2E), chave e, pelo QR, o **BR Code completo** (recebedor, valor, txid) com **verificação do CRC**.
- **Boleto:** linha digitável **validada pelos dígitos verificadores**, mais banco, valor e vencimento (já com o novo fator de vencimento de 2025). Também contas de arrecadação.
- **NFC-e:** chave de acesso validada.
- **CPF/CNPJ:** válidos pelo dígito; o CPF sai mascarado.

## 5. Segurança

- **Identificação pelo conteúdo**, nunca só pelo nome.
  - Recusa executáveis (Windows, Linux, macOS) e scripts, mesmo renomeados.
  - Recusa SVG, formatos antigos do Office e arquivos compactados.
  - Extensão divergente gera aviso.
- **DOCX/XLSX:** limite de partes internas, de tamanho descompactado e de taxa de compressão (zip-bomba). Também recusa caminhos internos inválidos e documento com senha. Macros nunca são executadas. Entidades externas (XXE) não são resolvidas: há um teste com `/etc/passwd`.
- **PDF:** JavaScript, ações de abrir programa e anexos são sinalizados e nunca executados. `MIDIA_PDF_BLOQUEAR_ATIVO=true` passa a recusar esses PDFs.
- **Imagens:** limite de pixels antes de decodificar (imagem-bomba). O GPS do EXIF **nunca é devolvido**, só sinalizado.
- **Isolamento:** cada arquivo roda num processo separado, com limite de memória (RLIMIT_AS), CPU e tamanho de gravação. No tempo excedido, o grupo inteiro é encerrado (inclusive Tesseract/FFmpeg).
- **Arquivo temporário:** é gravado com permissão 0600 num nome interno (o nome enviado nunca vira caminho) e apagado ao terminar, mesmo em erro ou tempo excedido.
- **Contêiner:**
  - somente leitura, `/tmp` em memória, sem capacidades (`cap_drop: ALL`) e `no-new-privileges`;
  - usuário sem privilégios;
  - limite de memória, CPU e processos;
  - logs com rotação.
- **Registro de operações:** cliente, família, formato, tamanho, SHA-256, tempo e resultado. **Nunca** registra conteúdo, texto extraído nem nome do arquivo.
- **Segredos:** o token e a chave de IA não são repassados ao processo que lê o arquivo.

## 6. Testes

| Suíte | Resultado | Cobertura |
|---|---|---|
| Central (`services/central-midia`): `python3 -m pytest -q tests` | **48 aprovados** | Abaixo |
| Cliente no app (`server/test/run.ts`) | Teste "central de mídias: opcional e independente" | Desligada, fora do ar, recusas, resultado normalizado e garantia de que nenhum fluxo atual depende da central |
| Ponta a ponta (`npx tsx server/test/central-midia-e2e.ts`) | **5/5** | Cliente do app → central real → central parada |
| Suíte completa do Meu Assistente | Sem regressões | — |

O que a suíte da central cobre:

- **Documentos:**
  - texto de PDF digital, e PDF escaneado com OCR;
  - DOCX (títulos, tabelas, propriedades);
  - XLSX (abas, datas, números);
  - CSV em Windows-1252 com `;`, e TXT.
- **Imagens:** OCR de comprovante fotografado (JPG/PNG/WEBP).
- **Códigos:** QR Code de Pix (CRC válido e adulterado), QR de link, EAN-13.
- **Boleto:** válido e com dígito errado.
- **Áudio e vídeo:** metadados; transcrição sem Whisper avisa sem quebrar.
- **Arquivos inválidos:** executáveis disfarçados, script, vazio, .doc antigo, SVG, ZIP quebrado, PDF e imagem corrompidos.
- **Ataques:** XXE, zip-bomba, imagem-bomba, PDF com JavaScript (aviso e bloqueio pela política), nome com `../`.
- **Limites:** nada sobra no disco; limite geral e por tipo; tempo limite (e a API segue viva); fila cheia (429).
- **Acesso e registro:** token ausente ou errado, saúde, capacidades, registro sem conteúdo.
- **Nível 2:** só quando pedido, só com o texto, e falha da IA mantém o nível 1.
- **Independência:** central desativada (503) e token curto.

## 7. Instalação na Hostinger (rotina GitHub → VPS)

Depois de atualizar os arquivos na VPS (como de costume), **nesta primeira etapa rode só os dois primeiros comandos**. Eles não iniciam nada:

```bash
cd /caminho/do/meu-assistente
sudo bash deploy/scripts/central-midia.sh verificar   # confere Docker, memória, disco, contêineres e configuração
sudo bash deploy/scripts/central-midia.sh testar      # constrói a imagem de teste e roda os testes dentro dela
```

`update.sh` continua igual: ele **não** sobe a central, porque ela está no perfil `midia`.

Quando você autorizar a ativação (próxima etapa):

```bash
sudo bash deploy/scripts/central-midia.sh instalar    # gera MIDIA_TOKEN/MIDIA_URL no .env (com cópia de segurança) e sobe SÓ a central
sudo bash deploy/scripts/central-midia.sh estado      # saúde, memória e CPU
```

Para incluir a central nas próximas atualizações do `update.sh`, acrescente `COMPOSE_PROFILES=midia` ao `.env`.

Variáveis opcionais (no `.env`):

| Variável | Padrão |
|---|---|
| `MIDIA_CONCORRENCIA` | 1 |
| `MIDIA_FILA` | 6 |
| `MIDIA_MAX_BYTES` | 25 MB |
| `MIDIA_TEMPO_LIMITE_S` | 60 |
| `MIDIA_MEMORIA_TRABALHO_MB` | 768 |
| `MIDIA_PDF_BLOQUEAR_ATIVO` | false |
| `MIDIA_ATIVA` | true |
| `MIDIA_NIVEL2_ATIVO` | false |
| `MIDIA_OLLAMA_URL` | — (ex.: `http://172.17.0.1:11434`) |
| `MIDIA_OLLAMA_MODELO` | `llama3.2:3b` |

Para usar uma API externa compatível com OpenAI no nível 2: `MIDIA_IA_URL`, `MIDIA_IA_CHAVE` e `MIDIA_IA_MODELO`.

## 8. Reversão (rollback)

Do mais leve ao completo. Nenhum passo apaga dados.

1. **Desligar sem parar o contêiner:** `MIDIA_ATIVA=false` no `.env`, depois `docker compose --profile midia up -d --no-deps central-midia`. A API responde 503 e o app segue normal.
2. **Parar:** `sudo bash deploy/scripts/central-midia.sh desativar`.
3. **Remover tudo:** `sudo bash deploy/scripts/central-midia.sh remover` (contêiner e imagem).
   - Opcional: apague as linhas `MIDIA_TOKEN` e `MIDIA_URL` do `.env`. Há uma cópia `.env.antes-central-*` feita na instalação.
4. **Voltar o código:** os arquivos novos estão listados na seção 3. As únicas alterações em arquivos existentes são aditivas:
   - o bloco do serviço no `docker-compose.yml` (perfil `midia`);
   - as linhas comentadas no `.env.example`;
   - um teste no `server/test/run.ts`;
   - uma linha no `README.md`.

## 9. Próximas etapas sugeridas (dependem da sua autorização)

1. Ativar na VPS e acompanhar memória e CPU com o `estado`.
2. ✅ Feito na etapa 2: a central é a **primeira opção** na leitura de comprovantes, com o caminho antigo como reserva. Ver `docs/LEITURA_LOCAL_COMPROVANTES.md`.
3. Ler cardápios em PDF/DOCX/XLSX pela central antes da IA, no importador de cardápio.
4. Novos processadores: correção de perspectiva de fotos (OpenCV), PDF com várias colunas, extração de áudio de vídeos para transcrição.
