# Mercado Pago: conexão automática (OAuth) das empresas

## Diagnóstico: por que a conexão automática falhava

A auditoria do fluxo anterior foi feita com um dublê que segue o contrato oficial do Mercado Pago (`server/test/browser/mercadopago_fake.py`).

1. **O retorno dependia do cookie da sessão.** No celular, a autorização costuma abrir no app do Mercado Pago (ou no navegador interno de outro app) e voltar ao Meu Assistente em outro navegador, sem a sessão.
   - O `state` ficava guardado na sessão do usuário. Sem o cookie, o retorno era recusado (`motivo=state`).
   - O dono ainda era jogado para `/entrar?next=/financeiro…`, a tela errada (a de finanças pessoais), sem saber o motivo.
   - O mesmo acontecia quando o endereço do site no navegador era diferente do domínio público (por exemplo, `www.` ou outro endereço), porque o cookie não é enviado para o outro host.
2. **Sem suporte a PKCE.** Quando a aplicação no Mercado Pago tem PKCE ligado (opção em *Detalhes da aplicação*), o Mercado Pago exige `code_challenge` na autorização. Sem ele, a autorização era recusada no próprio Mercado Pago e o dono nem voltava.
3. **O ambiente de teste não era respeitado.** O painel tinha a opção "Ambiente: Teste", mas o código não enviava `test_token=true` na troca do código. A homologação com usuários de teste não gerava credenciais de teste.
4. **Os erros eram silenciosos.** Qualquer falha virava "Não foi possível conectar". Além disso, a mensagem de retorno se perdia quando o app recarregava a página logo após abrir.
5. **A renovação era frágil:**
   - só acontecia na hora de cobrar um Pix, nos últimos 7 dias de validade;
   - se o Mercado Pago recusasse, a empresa continuava "Conectada" e seguia oferecendo Pix automático que falharia.

## Como funciona agora

1. **Painel do administrador → Mercado Pago → "Aplicação Mercado Pago"**: Client ID, Client Secret, ambiente (Teste/Produção), PKCE e os planos com acesso.
   - Essa aplicação fica separada das credenciais manuais da conta do sistema, que ficam no mesmo menu, mais acima. Uma configuração não altera a outra.
   - "Testar credenciais" valida a aplicação no Mercado Pago e mostra a URL de redirecionamento a cadastrar.
2. **O dono da empresa** vai em *Sua empresa → Ajustes → Entrega e pagamento → Pagamento automático (Mercado Pago)* e toca em **Conectar minha conta Mercado Pago**.
3. **Autorização oficial**:
   - `https://auth.mercadopago.com/authorization?client_id&response_type=code&platform_id=mp&state&redirect_uri`
   - com PKCE ligado, também `code_challenge` (S256).
4. **Retorno** em `https://meuassistente.chat/api/mercadopago/oauth/callback`:
   - o servidor reconhece o pedido pelo `state` guardado no banco (`mp_oauth_estados`: uso único, 15 minutos), sem depender do cookie;
   - recusa se o navegador estiver logado em outra conta do Meu Assistente.
5. **Troca do código** no servidor (`POST /oauth/token`): `grant_type=authorization_code`, `code`, `redirect_uri` idêntico, `code_verifier` (PKCE) e `test_token=true` no ambiente de teste.
   - Em seguida, a conta é conferida em `/users/me`.
6. **A conexão fica só na empresa dona**:
   - access token e refresh token criptografados no servidor;
   - ID, apelido, nome e e-mail mascarado da conta;
   - status e datas.
   - A mesma conta Mercado Pago não pode receber por empresas de donos diferentes.
7. **Status exibido**: **Conectado**, **Desconectado** ou **Erro na conexão** (com o motivo e o botão "Reconectar"). Com erro, a loja deixa de oferecer Pix automático até reconectar.
8. **Ações**: **Verificar conexão** (API oficial), **Conectar outra conta** e **Desconectar** (apaga os tokens desta empresa e de nenhuma outra).
9. **Renovação automática**: a cada 6 horas, o agendador renova pelo `refresh_token` as conexões com menos de 30 dias de validade. O refresh token é de uso único e é trocado a cada renovação.
   - Também renova antes de cobrar, e quando o Mercado Pago responde 401 (uma tentativa).
   - Se o Mercado Pago recusar o refresh (autorização revogada ou expirada), o status vira "Erro na conexão".
10. **Configuração manual** (Access Token colado): continua existindo para quem já usa. Só aparece quando a conexão automática não está configurada, para que o dono nunca precise copiar tokens.

## Homologação real (contas de teste do Mercado Pago)

O ambiente de desenvolvimento não acessa a internet. Por isso, os testes automáticos usam o dublê, que segue as mesmas regras do serviço real: `redirect_uri` exato, código de uso único, PKCE, `test_token` e refresh de uso único. Para homologar com o Mercado Pago de verdade:

1. Em **mercadopago.com.br/developers → Suas integrações**, crie (ou abra) a aplicação.
   - Em **URLs de redirecionamento**, cadastre exatamente `https://meuassistente.chat/api/mercadopago/oauth/callback`.
   - Veja se **PKCE** está ligado.
2. Em **Contas de teste**, crie um *vendedor* de teste.
3. No **Painel → Mercado Pago → Aplicação Mercado Pago**:
   - informe o Client ID e o Client Secret;
   - escolha o Ambiente **Teste**;
   - marque **PKCE** se estiver ligado na aplicação;
   - toque em **Testar credenciais**.
4. Entre no Meu Assistente com o dono de uma empresa de plano com acesso.
   - Vá em **Entrega e pagamento** e toque em **Conectar minha conta Mercado Pago**.
   - No Mercado Pago, entre com o **vendedor de teste** e autorize.
5. O app volta para a tela com **Conectado**, os dados da conta de teste e o selo "ambiente de teste". **Verificar conexão** confirma na API.
6. Para produção:
   - troque o Ambiente para **Produção**;
   - os donos conectam as próprias contas reais (as conexões de teste devem ser desconectadas e refeitas).

## Arquivos

- `server/migrations/044_mp_oauth_estados.sql`: pedidos de autorização (state, PKCE). Só acrescenta.
- `server/src/routes/mpuser.ts`: autorização, retorno, troca de tokens, renovação, verificação e status.
- `server/src/routes/businesses.ts`:
  - `storeToken` passa a usar a renovação centralizada;
  - `mpOk` (Pix automático só com conexão sem erro);
  - ações `verificar` e `remove`, e o status completo.
- `server/src/routes/panel.ts`: opção PKCE na aplicação.
- `server/src/scheduler.ts`: renovação automática.
- `frontend/public/modules-addon.js`: cartão do Mercado Pago na empresa e aviso de retorno resistente à recarga da página.
- `frontend/public/panel-addon.js`: PKCE e explicação do ambiente no painel.
- Testes:
  - `server/test/run.ts`: teste "Mercado Pago OAuth de ponta a ponta";
  - `server/test/browser/mercadopago_oauth.py` com o dublê `mercadopago_fake.py`.
