# Fase 5 — Memória evolutiva e inteligência contextual

Esta fase evolui a memória que já existia. Não há uma memória paralela:

- a tabela `memories` continua sendo a única fonte de fatos e preferências;
- a ferramenta `save_memory` continua sendo o único caminho de gravação pelo chat;
- a página Perfil → Memória do assistente continua igual, só ganhou um atalho.

Migração **032** (somente acréscimos): novas colunas em `memories` e a tabela `experiences`.

## Diagnóstico (antes)

| Achado | Efeito | Correção |
|---|---|---|
| Atualizar uma memória sobrescrevia o texto | **perda do valor anterior** (sem origem nem data) | histórico de versões em `memories.versions` (últimas 20, com de/até/motivo/conversa de origem) e restauração |
| "Não gosto de café" × "gosto de café" era tratada como **duplicata** | a informação nova era descartada | contradição detectada pela polaridade: a mais nova vale e a antiga vira versão |
| A recuperação usava sobreposição literal de palavras | "pet" não achava "cachorro"; erro de digitação não achava nada | recuperação semântica local (abaixo) |
| A comparação só olhava as 200 memórias mais novas | duplicata antiga passava | compara até 1000 |
| Sem memória de experiências | o assistente repetia o que já tinha falhado | camada de experiências, individual |
| Sem exportação, retenção nem busca para o usuário | controle incompleto dos próprios dados | página **Minha memória** |

## Camadas

| Camada | Onde fica | Quem decide |
|---|---|---|
| Curto prazo | a mensagem atual e o fio da conversa (já existia: `convctx`) | automático, some com a conversa |
| Conversação | conversas anteriores do **mesmo** usuário; só o título e a data são associados | chave "Relacionar informações" |
| Longo prazo | fatos e pessoas em `memories` | o usuário pede para guardar, edita ou apaga |
| Preferências | `memories` do tipo preferência | idem; preferências de comunicação sempre entram |
| Experiências | `experiences`: tarefas, planos, correções e avaliações (resultado: deu certo, falhou, corrigido…) | chave "Aprender com as experiências"; retenção de 30 a 365 dias |

O sistema **não grava todas as conversas** como memória:

- fatos só entram quando o usuário pede;
- experiências guardam apenas um resumo curto da ação e o resultado (até 220 caracteres);
- dados protegidos são removidos antes de gravar: senha, CPF, cartão e similares;
- leituras não viram experiência;
- a área de testes não grava nada.

## Recuperação semântica (`server/src/ai/semantica.ts`)

É local, sem chamada externa e sem custo:

- **radicais do português** (RSLP leve): "viajar"/"viagens" → mesmo radical;
- **conceitos**: 13 grupos de sinônimos (pet, veículo, saúde, alimentação, trabalho, família, dinheiro, moradia, viagem, estudo, lazer, comunicação, rotina);
- **erros de digitação** por trigramas ("cachoro" acha "cachorro");
- **BM25** para ordenar;
- **nomes próprios** com peso alto.

Cada resultado traz o **motivo**, por exemplo "mesmo assunto (pet)" ou "nome em comum". O motivo aparece na busca da página Minha memória.

> Limite honesto: não são *embeddings* neurais. Um sinônimo fora dos grupos de conceitos e sem radical em comum não é achado. Os grupos podem ser ampliados em `CONCEITOS_TXT`, e um provedor de embeddings pode substituir a função `buscar` sem mudar o restante.

## Memória associativa

Quando uma memória relevante cita um nome próprio, outras memórias **do mesmo usuário** com o mesmo nome vêm junto, marcadas "(relacionada)". Exemplo: "Thor" → "o veterinário do Thor é o Dr. Silva".

A ligação fraca, por assunto, só acontece quando o assunto está na própria pergunta. Conversas anteriores entram pelo título quando há:

- 2 ou mais termos em comum;
- o mesmo assunto;
- ou o mesmo nome próprio.

## Contextualização (`memoria-evolutiva.ts → contextualizar`)

Só o relevante vai para a IA e para os agentes:

- com **até 12 memórias**, todas entram, como antes, para manter a compatibilidade;
- acima disso entram:
  - até 4 preferências (as relevantes mais as de comunicação),
  - 8 fatos,
  - 3 associadas,
  - 3 experiências,
  - 2 conversas,
- teto total de **1800 caracteres**.

O índice de cada usuário fica em cache (LRU de 300 usuários). Ele é invalidado pela assinatura `COUNT|MAX(updated_at)|MAX(id)`, então uma edição nunca é servida desatualizada.

Medido: **~0,7 ms** de busca com 1000 memórias e índice em cache.

Integração sem duplicação:

- `nucleo.prepararTurno` chama `contextualizar` no lugar da antiga `relevantes`;
- os agentes de análise, vendas e planejamento recebem as experiências pelo quadro compartilhado;
- o agente de pesquisa **não** recebe as experiências, porque o acesso é controlado por agente.

## Controle de atualização

- **Duplicata**: não grava de novo. "Unir duplicatas" funde as existentes e guarda o texto eliminado como versão, sem perda.
- **Informação única que mudou** (nome, cidade, profissão, parente): atualiza e guarda a versão anterior.
- **Contradição**: a mais nova vale e a anterior fica no histórico com o motivo "contradição".
- **Antiga**: memórias sem uso há 180 dias são marcadas como "antiga" e voltam ao normal quando usadas. Nada é apagado por isso.
- Cada memória guarda a **conversa de origem** e as datas.

## Privacidade

- Toda consulta filtra pelo `user_id` da sessão. Nenhuma memória, experiência ou conversa de um usuário entra no contexto de outro (há teste para isso).
- **Consentimento**: o usuário liga ou desliga a memória, as experiências e a associação.
- **Retenção configurável**:
  - memórias sem uso: nunca (padrão), 90, 180, 365 ou 730 dias;
  - experiências: 30, 90, 180 (padrão) ou 365 dias;
  - um job diário aplica a retenção.
- **Consultar, corrigir e excluir**: página **/minha-memoria**, com atalho em Perfil → Memória do assistente. Ela oferece:
  - camadas, busca com motivo e edição com histórico e restauração;
  - ativar e desativar, excluir item, apagar experiências;
  - **exportar tudo (JSON)**;
  - **apagar toda a memória** (pede confirmação dupla).
- O painel do administrador mostra **somente números**: totais por camada, recuperações, acerto de cache e tempo. Nunca mostra conteúdo.
- Os dados de memória não são usados em treinamento.

## Validação

- Suíte do servidor: 6 testes da Fase 5 cobrindo:
  - recuperação (sinônimos, erros de digitação, nomes, 1000 memórias);
  - contextualização e limites;
  - versões, contradição e duplicatas;
  - experiências individuais;
  - associação e agentes;
  - privacidade e isolamento.
- Corpus de diagnóstico: área "Recuperação semântica" (18/18).
- Navegador: `test/browser/memoria_evolutiva.py` (17 verificações).
- Regressão completa sem falhas.

## Como reverter

| Nível | Como |
|---|---|
| Usuário | Minha memória → desligar "Aprender com as experiências" / "Relacionar informações" |
| Plataforma | Painel → Cérebro e busca → Inteligência avançada → chave "Memória inteligente" (desliga a contextualização em camadas; o assistente volta à lista de memórias de antes, sem perder nada) |
| Código | reverter `nucleo.ts` para chamar a versão anterior e remover `memoria-evolutiva.ts`/`semantica.ts` |
| Banco | migração 032 é aditiva; `DROP TABLE experiences` e as colunas novas podem ficar (são ignoradas). Nenhum dado existente foi alterado pela migração. |
