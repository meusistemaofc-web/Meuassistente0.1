# Organizar módulos ⇄ menu lateral (auditoria e correção)

## Problema
Os módulos adicionados em "No menu" na tela **Organizar módulos** eram salvos, mas não apareciam no menu lateral.

## Auditoria: o que foi verificado
| Camada | Situação encontrada |
|---|---|
| Tela "Organizar módulos" (app) | Correta: grava `settings.menuLayout` (`{ main, projects }`) por `PATCH /api/me` e atualiza o estado na hora. |
| Menu lateral (app) | Correto: desenha os módulos a partir do mesmo `settings.menuLayout`. |
| Banco e persistência | Gravava no usuário autenticado (`users.settings`). |
| **Addon do menu (`modules-addon.js` › `applyMenu`)** | **Causa raiz.** Aplicava por cima uma segunda regra de organização: o layout "menu/pasta" do painel mais os "fixados" da tela antiga `/x/modulos`. Com ela escondia (`display:none`) os módulos que o usuário adicionou e não estavam "fixados" nessa outra lista. Quando o admin tinha um menu personalizado, ainda reordenava os itens (`order`) por cima da ordem do usuário. |
| Addon (injeção de módulos) | Podia criar uma cópia de um módulo do app no menu principal, pela regra paralela. Risco de duplicado. |
| Servidor (`PATCH /api/me`) | Aceitava qualquer objeto em `menuLayout` (duplicados, módulos inexistentes, sem limite). |
| Servidor, concorrência | Mesclava as configurações a partir do usuário lido no início da requisição. Duas gravações ao mesmo tempo podiam apagar uma à outra, por exemplo o fuso horário enviado ao abrir o app e a organização do menu. |
| Tela admin oculta × organização | Um módulo desligado pelo administrador continuava sendo oferecido em "Disponíveis para adicionar". Adicionado, não aparecia no menu: era outra divergência. |
| Cache e autenticação | Sem problema. O app guarda uma cópia local do perfil, mas sempre recarrega `/api/me` ao abrir, ao voltar para a aba e a cada 60 s, e a sessão é por cookie. |

## Correções (na causa, sem duplicar funcionalidade)
1. **Fonte única:** `settings.menuLayout` do usuário.
   - **Links do app no menu lateral:** o addon só aplica as regras do **administrador**, ou seja, módulo desligado, indisponível ou "oculto" e item escondido no menu do painel. Visibilidade e ordem são as do usuário.
   - **Atalhos do próprio addon** (Empresas, Mercado, Impostos…): continuam com as regras de antes.
   - **Sem cópias:** a injeção de módulos não cria mais cópia de módulos que o app já desenha.
2. **Tela "Organizar módulos":** não oferece nem lista módulos ocultados pelo administrador, e a contagem acompanha. Quando o admin libera o módulo, ele volta exatamente na posição que o usuário escolheu, porque a escolha não é apagada.
3. **Tela antiga `/x/modulos`** ("Fixar"):
   - **Módulos do app:** lê e grava o mesmo `menuLayout` e avisa o app pelo evento que ele já usa (`nexa:modes-changed`), então o menu muda na hora.
   - **Atalhos do addon:** continuam com os "fixados" de antes.
4. **Integridade no servidor** (`lib/menu-layout.ts`): só módulos conhecidos, sem duplicados (cada módulo fica em um lugar só) e com tamanho limitado. Um valor inválido vira a organização padrão.
5. **Sem perda de configuração:** as configurações são mescladas sobre o valor atual do banco, sob trava por usuário.

## Comportamento final
- **Adicionar:** o módulo aparece no menu lateral na hora.
- **Remover:** o módulo some do menu e vai para a pasta "Módulos", sem ser apagado.
- **Subir e descer:** o menu fica exatamente na ordem da tela.
- **Persistência:** recarregar, sair e entrar de novo ou trocar de aparelho mostram a última configuração salva no banco.
- **Celular e computador:** o comportamento é o mesmo.

**Mudança de regra para o administrador:** o layout "menu/pasta" do painel continua valendo para os atalhos do addon. Para os módulos que o próprio usuário organiza, a escolha do usuário prevalece. "Oculto" continua escondendo de todos.

## Testes
- **Servidor** (`test/run.ts`, "Organizar módulos"): limpeza de duplicados e inválidos, valor inválido vira padrão, isolamento por usuário, três gravações simultâneas sem perda e nova sessão com a mesma organização.
- **Tela** (`test/browser/modulos_menu.py`, 32 verificações em celular e computador): o roteiro de aceitação completo (adicionar → aparece; subir/descer → mesma ordem; remover → some; recarregar; novo login), mais admin oculta/libera, `/x/modulos` com a mesma fonte, integridade e concorrência.

## Como reverter
1. Restaurar `applyMenu` e a injeção de módulos de `modules-addon.js` da versão anterior; remover `RMOD`, `RLBL`, `admOculto`, `orgSync`, `appModId`, `appMenuToggle` e `LAYOUT`. Voltar `?v=108` para `?v=107`.
2. Em `routes/me.ts`, voltar a mesclagem simples, sem trava, e o tratamento antigo de `menuLayout`.
3. Opcionalmente, apagar `lib/menu-layout.ts`.

Os dados salvos são compatíveis com as duas versões.
