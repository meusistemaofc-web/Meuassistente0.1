# Teclado aberto, ofertas no topo, categorias, duplicar, fotos, lixeira de empresas, logo e capa

## 1. Telas com o teclado aberto (Mercado Pago, cupom do anúncio…)
**Problema:** com o teclado aberto no celular, o menu inferior fixo (Início · Pedidos · Produtos · Ajustes) e a barra "Ver pedido" ficavam por cima do fim da tela. No iPhone, o teclado também cobria a parte de baixo sem a tela poder rolar até ela. Por isso não dava para alcançar os últimos campos e botões, como:
- Entrega e pagamento;
- Mercado Pago;
- Salvar;
- "Tenho um cupom" e "Continuar para o pagamento".

**Correção** (vale para todas as telas do app):
- **Detecção:** o app percebe quando o teclado abre (área visível encolhe com um campo em foco). Funciona no **Android** (a janela encolhe) e no **iPhone** (o teclado cobre a janela).
- **Barras fixas:** com o teclado aberto, o menu inferior e a barra "Ver pedido" **saem da frente**. Voltam quando o teclado fecha.
- **Espaço no fim (iPhone):** a tela ganha no fim o espaço do teclado, então tudo pode ser rolado até ficar visível.
- **Campo em foco:** é trazido para o meio da área visível quando ficaria escondido.

## 2. Produtos em oferta no topo do catálogo
- **Loja** (`/x/empresa/:id`):
  - em "Todos", os produtos em oferta vêm **primeiro**;
  - dentro de cada categoria, também.

  Depois deles vêm os marcados como "Destaque" e então a ordem de sempre.
- **Agente de atendimento:**
  - o catálogo abre no grupo **"Em oferta"** (só quando há ofertas);
  - em cada categoria, as ofertas vêm antes.
- Só contam ofertas válidas e disponíveis: as mesmas regras de preço e estoque de antes.

## 3. Categorias como lista no cadastro
- **Lista:** o campo Categoria do produto é uma **lista** com:
  - as categorias criadas em *Categorias do catálogo*, na ordem;
  - as já usadas nos produtos;
  - **"Outra…"** para digitar uma nova.
- **Salvar na hora:** em *Categorias do catálogo*, **Adicionar, subir e remover salvam na hora**. Antes era preciso tocar em "Salvar categorias", e a categoria podia sumir. Enter no campo também adiciona.
- **Categoria nova pelo produto:** uma categoria digitada em "Outra…" entra automaticamente nas categorias do catálogo e passa a aparecer na lista.

## 4. Duplicar produto
- Cada item da lista de produtos tem **Duplicar**.
- O cadastro abre **preenchido com tudo**:
  - fotos;
  - preço, oferta e estoque;
  - categoria, descrição, opções;
  - **variações com as fotos**.

  O título é "Duplicar produto" e o nome vem com "(cópia)".
- **Salvar cria um novo produto.** O original não muda.
- **Fotos das variações:** já salvas, não são reenviadas (vão por referência, inclusive a miniatura). O servidor só aceita referências de fotos da **mesma empresa**.

## 5. Duas fotos de uma vez
- **Produto:** o seletor de foto aceita **várias**, e as duas fotos podem ser escolhidas juntas. Se vierem mais do que cabe, usa as primeiras e avisa.
- **Variações:** o seletor também aceita várias (até 4 por variação).

## 6. Excluir empresa e Lixeira (30 dias)
**Excluir empresa** fica em Ajustes, com confirmação ("Entendi…"). A empresa:
- **sai do ar na hora:**
  - catálogo público;
  - busca e marketplace;
  - agente de atendimento;
  - painel, Lojas Conectadas e IA;
- vai para a **Lixeira**, com a situação anterior guardada;
- **nada é apagado** nesse momento.

**Lixeira** (`/x/lixeira`, em Ajustes, ou pelo atalho que aparece em Sua empresa quando não há outra empresa ativa):
- mostra a data da exclusão e quantos dias faltam para a exclusão definitiva;
- **Restaurar:** volta **exatamente como estava**, com a mesma situação, produtos, pedidos, clientes e configurações;
- **Excluir definitivamente:** apaga na hora, com confirmação.

**Depois de 30 dias,** a exclusão é **definitiva e automática**:
- uma tarefa roda a cada hora e logo após o servidor iniciar;
- apaga a empresa e tudo dela, como a exclusão de anúncio que já existia;
- uma reserva de cupom de anúncio em aberto, se houver, é liberada.

**Regras:**
- só o dono exclui ou restaura;
- outra pessoa não vê nem mexe na lixeira de ninguém;
- a validade do anúncio continua correndo enquanto a empresa está na lixeira;
- tudo vai para a auditoria (`empresa.lixeira.excluir/restaurar/excluir_definitivo`).

## 7. Logo e capa direto no topo
- **Em Ajustes** (Sua empresa), a **capa** e a **logo** do topo agora são tocáveis. Ícone de câmera:
  - tocar na capa troca a capa;
  - tocar na logo troca a logo;
  - **×** remove a capa.

  Salva na hora; se der erro, a imagem atual continua.
- **O item "Logo e capa" saiu da lista de Ajustes.**

## Banco
Migração `049_lixeira_empresas.sql`, só aditiva: `businesses.deleted_at` e um índice. A empresa na lixeira fica com a situação `lixeira`.

## APIs novas
| Rota | Função |
|---|---|
| `POST /api/v2/ads/:id/excluir` `{confirmar:true}` | Mover para a lixeira (dono) |
| `GET /api/v2/lixeira/empresas` | Itens da lixeira com o prazo |
| `POST /api/v2/lixeira/empresas/:id/restaurar` | Restaurar |
| `POST /api/v2/lixeira/empresas/:id/excluir-definitivo` `{confirmar:true}` | Excluir agora |

## Testes
**Servidor** (`server/test/run.ts`), 2 testes novos:
1. **Lixeira:**
   - só o dono, com confirmação, uma vez;
   - fora do ar no catálogo, em Sua empresa, no painel, no agente e na busca;
   - nada apagado antes;
   - prazo de 30 dias;
   - outra pessoa não vê nem restaura;
   - restaurar volta igual;
   - não apaga antes de 30 dias e apaga depois;
   - não restaura depois do prazo;
   - excluir definitivamente pelo dono;
   - auditoria.
2. **Duplicar e categorias:**
   - cópia com as fotos e miniaturas das variações;
   - original intacto;
   - foto de outra empresa recusada;
   - categoria nova vai para a lista.

**Navegador** (`server/test/browser/ajustes_lixeira_teclado.py`), 27/27, no celular:
- **teclado:**
  - menu sai da frente;
  - campo visível;
  - "Salvar entrega e pagamento" alcançável;
  - cupom do anúncio e "Continuar para o pagamento" alcançáveis;
  - menu volta;
- ofertas no topo (loja e agente);
- categoria salva na hora e listada;
- "Outra…";
- 2 fotos de uma vez;
- duplicar;
- Ajustes sem "Logo e capa";
- trocar capa e logo e remover capa;
- excluir → Lixeira (prazo de 30 dias) → restaurar;
- sem erros de JS.

## Arquivos
| Arquivo | Mudança |
|---|---|
| `frontend/public/modules-addon.js` | Teclado, ofertas no topo, lista de categorias, duplicar, fotos múltiplas, excluir/Lixeira, logo e capa no topo |
| `frontend/public/agente.html` | Grupo "Em oferta" e ofertas primeiro |
| `server/src/lib/lixeira-empresas.ts` (novo) | Lixeira e limpeza automática |
| `server/src/lib/catalogo.ts` | Fotos de variações reaproveitadas ao duplicar |
| `server/src/routes/businesses.ts` | Categoria nova vira categoria do catálogo; painel e agente fecham para empresa na lixeira |
| `server/src/routes/ads.ts`, `lib/painel-empresa.ts`, `lib/lojas-conectadas.ts`, `modos/marketing.ts`, `ai/agenda-ia.ts` | Empresa na lixeira fora das listas |
| `server/src/app.ts` | Rotas; `modules-addon.js?v=142` |
| `server/src/index.ts` | Tarefa de limpeza da lixeira |
| `server/migrations/049_lixeira_empresas.sql` | Coluna `deleted_at` |
