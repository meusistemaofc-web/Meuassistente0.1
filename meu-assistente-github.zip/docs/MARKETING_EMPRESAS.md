# Central de Marketing das empresas (17/11)

## Três níveis de permissão (conferidos no servidor em toda operação)
1. **Administrador:** em Painel → Marketing → "Central de Marketing para as empresas" (`mkt_global`).
   - Ligada: a opção aparece em Sua empresa → Ajustes, para empresas com anúncio aprovado.
   - Desligada: a opção some. Criar, editar, programar e ativar retornam 403 `mkt_off`.
   - Ao desligar, campanhas programadas ou em envio viram **suspensas** (`suspensa_por = administrador`). Nada é apagado.
2. **Proprietário:** em Sua empresa → Central de Marketing → "Ativar campanhas de marketing para meus clientes".
   - Tabela `mkt_empresa`, uma linha por empresa. Começa desligada.
   - As empresas que já tinham campanhas antes desta versão entram ligadas pela migração.
   - Desligar suspende as campanhas futuras (`suspensa_por = empresa`).
3. **Sistema:** antes de programar e antes de cada envio, confere:
   - administrador, plano (`mkt_plans`) e empresa;
   - autorização do cliente (`marketing_consents` ativo, nunca derivado de lembrete ou notificação);
   - preferências de notificação e limites do plano.
   - Se algum nível caiu, suspende a campanha em vez de enviar.

**Reativar não retoma sozinho:** campanhas suspensas só voltam com "Validar e retomar" (ação `validar`), feito pelo proprietário. Se a data já passou, a campanha sai assim que validada, ou ele escolhe uma nova data. Se a data de encerramento já passou, ela vira `expirada`.

## Campanha
- **Campos:** nome, título, conteúdo, imagem (PNG/JPG/WebP até ~350 KB, servida assinada em `/api/v2/marketing/img/:id.sig`), link, público, data de início + horário (no fuso do proprietário) e data de encerramento.
- **Situações:** `rascunho` → `agendada` → `enviando` → `concluida`, além de `cancelada`, `suspensa` e `expirada`.
- **Rascunho:** não conta no limite do plano e não envia.
- **Edição e cancelamento:** possíveis enquanto a campanha está `rascunho`, `agendada` ou `suspensa`.

## Público (só a base da própria empresa)
`todos` (autorizados), `compradores` (já fizeram pedido), `recentes` (autorizaram nos últimos N dias), `sem_compras` (sem pedido há N dias) e `personalizado` (origem da autorização + só compradores + recência + sem compras). Cada empresa só lê os próprios consentimentos e pedidos.

## Execução (`runCampaigns`, a cada minuto pelo agendador)
- **Trava atômica:** `trava_ate` impede que duas instâncias executem a mesma campanha.
- **Reserva do envio:** antes de entregar, grava em `mkt_sends`, que tem índice único campanha+cliente. Com isso, nunca entrega duas vezes.
- **Janela de envio:** 8h–21h no fuso da campanha.
- **Falha de entrega:** fica `falha` e tem nova tentativa automática a cada 5 min, até 3 vezes.
- **Registro:** cada execução vai para `mkt_execucoes`. Criação, edição, programação, cancelamento, validação, suspensão, execução e liga/desliga vão para `mkt_auditoria`.
- **Identificação e saída:** a notificação sai como "Empresa: título". Ao tocar, o cliente vê o cartão da oferta com a empresa remetente, a validade e "Não quero mais receber ofertas de …". Também pode cancelar no perfil.

## Arquivos
- `server/migrations/040_marketing_empresas.sql`: só acrescenta tabelas e colunas.
- `server/src/lib/marketing.ts`, `server/src/routes/marketing.ts`, `routes/panel.ts` (chave `mkt_empresas` pública + suspensão imediata), `ai/commercial.ts`.
- `frontend/public/modules-addon.js` (v=119): `viewMarketing`, opção em Sua empresa, cartão da oferta.
- `frontend/public/panel-addon.js` (v=147): texto da chave do administrador.

## Testes
- `npm test`: "Central de Marketing das empresas" cobre os 12 cenários pedidos, além de encerramento, cancelamento e segmentação. Resultado: 292/292.
- `server/test/browser/marketing_empresas.py`: 48/48, celular e computador.
