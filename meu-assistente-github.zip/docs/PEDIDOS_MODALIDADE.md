# Pedidos conforme a modalidade (retirada × entrega)

O fluxo do pedido se adapta ao que o cliente escolhe em "Como receber". Cada modalidade mostra só o que serve para ela, sempre com os dados atuais do cadastro da empresa.

## Retirada no local

- **Finalização do pedido:** o cartão **Retire em** mostra o endereço completo da empresa, o horário de funcionamento (quando há dias configurados), **Ver no mapa** (pela localização da empresa ou, sem ela, pelo endereço) e **Falar no WhatsApp**, que abre a conversa com a loja já com uma mensagem pronta sobre a retirada.
- **Meus pedidos:** enquanto o pedido está em andamento aparece **Retire seu pedido em**, com endereço, horário, mapa e WhatsApp (a mensagem já cita o número do pedido). Depois de concluído, fica só "Retirada no local".
- Nada sobre entrega aparece: nem campo de endereço do cliente, nem aviso de contato para entrega.

## Entrega

- **Finalização do pedido:** campo de endereço (o texto digitado não se perde ao trocar o pagamento ou outra opção) e o aviso: o cliente acompanha o andamento em **Meus pedidos**, e se for preciso combinar algum detalhe da entrega, a empresa fala com ele pelo WhatsApp ou por ligação.
- **Meus pedidos:** acompanhamento por etapas, **Pedido enviado → Aceito pela loja → Em preparo → Saiu para entrega → Entregue**, com data e hora de cada mudança. A etapa atual fica destacada. A tela **se atualiza sozinha** a cada 20 segundos enquanto está aberta e há pedido em andamento, e o cliente continua recebendo a notificação de cada mudança. Pedido recusado ou cancelado mostra até onde chegou e o motivo.
- Nada sobre retirada aparece: nem endereço da loja, nem mapa.

## Painel da empresa e Lojas Conectadas

As etapas seguem a modalidade. Em preparo, um pedido de entrega só oferece **Saiu para entrega** e um de retirada só **Pronto para retirar** (mais Cancelar). O servidor recusa a etapa trocada com uma mensagem clara, e a central de Lojas Conectadas usa a mesma regra (`transicoes`).

## Regras e dados

- Cada mudança de situação grava `orders.data.andamento = [{status, em}]`, e o pedido nasce com a primeira etapa. Pedidos antigos, sem esse registro, continuam funcionando: a primeira etapa usa a data do pedido.
- `GET /api/v2/orders/mine` devolve em cada pedido de produtos o campo `loja`, com os dados **atuais** da empresa conforme a modalidade:
  - retirada: `{empresa, zap, endereco, horario, mapa}`;
  - entrega: só `{empresa, zap}`.
- O horário só aparece quando há dias configurados (o texto "Fechado" de lojas abertas pelo botão não é mostrado).
- **Não há migração** (tudo no JSON do pedido). Criação, pagamento, cupom, MCoins, estoque e notificações continuam iguais.

## Arquivos

- `server/src/routes/businesses.ts`: `transicoes` (por modalidade), `comAndamento`, `mudarStatusPedido`, `orderPost` (primeira etapa), `myOrdersGet` e `lojaDoPedido`.
- `frontend/public/modules-addon.js` (v=154): `retiradaBox`, `entregaAviso`, `trilhaEntrega` e `pedModo`; checkout (`d3`); Meus pedidos (`viewPedidos`, com atualização automática); painel de pedidos (ações por modalidade).

## Testes

- Servidor: "pedidos por modalidade: …". Cobre dados da loja por modalidade, transições trocadas recusadas, andamento com data e hora, avisos e pedido antigo sem andamento.
- Navegador: `test/browser/pedidos_modalidade.py`, 30 verificações em celular 390 px e computador. Cobre o checkout nas duas modalidades (sem mistura), o WhatsApp com mensagem pronta e o mapa, a criação dos dois pedidos, Meus pedidos com as etapas, a atualização ao vivo quando a loja muda a situação e as ações do painel por modalidade.
