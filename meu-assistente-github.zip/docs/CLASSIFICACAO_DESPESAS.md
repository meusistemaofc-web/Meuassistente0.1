# Classificação inteligente de despesas, correção pelo chat e aprendizado

Melhorias na interpretação dos comprovantes. A leitura em si (Central de Mídias, OCR, IA) **não mudou**: muda só o que é
feito com o que foi lido e o que é mostrado ao usuário.

## 1. Experiência natural (sem revelar o método de leitura)

- O resumo do comprovante começa com **"Li o comprovante:"**, em qualquer método de leitura. Saíram:
  - "no servidor (leitura local, sem IA)";
  - "com complemento da IA".
- A observação gravada no lançamento passou a ser só "Lido de comprovante". Antes era "Lido de comprovante no servidor (leitura local)".
- Falhas inesperadas de leitura mostram uma mensagem simples, sem detalhes técnicos: "Não consegui ler o comprovante agora…". Nada é registrado.
- O indicador "Lendo a foto" continua o mesmo.

## 2. Classificação por evidências (`server/src/ai/classificar.ts`)

Só usa categorias que já existem no financeiro, com as subcategorias delas. Por exemplo, **Mercado** é *Alimentação › Mercado* e **Farmácia** é *Saúde › Farmácia*.

| Ordem | Evidência | Exemplos |
|---|---|---|
| 1 | **Produtos e serviços** escritos no comprovante (itens da nota, descrição) | arroz, feijão, verduras, carne → Alimentação › Mercado · gasolina, etanol, diesel → Combustível · dipirona, comprimidos → Saúde › Farmácia · refeição, marmita → Alimentação › Restaurante e lanches · ingresso, sessão → Lazer |
| 2 | **Correção anterior do próprio usuário** para o mesmo estabelecimento | "MIX CONVIVER" corrigido para Mercado → próximas compras lá já vêm como Mercado |
| 3 | **Estabelecimento e atividade** | supermercado, mercearia, atacadão → Mercado · auto posto → Combustível · drogaria → Farmácia · restaurante, lanchonete → Alimentação · cinema → Lazer |
| 4 | **Contexto** da transação (dicionário do financeiro e sugestão de outra leitura, quando houver) | boleto de "energia" → Casa |
| 5 | Sem segurança | **Outros (não identificada)** |

**Exemplo de prioridade dos produtos:** um "AUTO POSTO" com arroz, feijão e leite na nota fica em **Mercado**, não em Combustível.

**Evidência fraca:** quando só um indício aponta a categoria, ela aparece como "(sugerida — revise)".

**Com IA disponível:** a sugestão da IA só complementa quando não há evidência local. A IA nunca é obrigatória, e tudo funciona com o modo **Sem IA (teste)**.

**Confirmação mantida:** nada é registrado antes do "sim, registrar". O lançamento inicial sempre passa pela confirmação.

## 3. Correção de categoria pelo chat

O chat entende frases naturais como:
- "A categoria dessa compra é mercado."
- "Isso foi uma compra de mercado."
- "Classifique essa despesa como alimentação."
- "Essa compra é combustível."
- "Mude a categoria para saúde."
- "categoria lazer"

**Comprovante ainda não confirmado:** a categoria do resumo é trocada e o chat pede a confirmação de novo. Nada é registrado sozinho.

**Lançamento já registrado:**
- A categoria do **mesmo lançamento** é atualizada, usando o mecanismo de correção que já existia.
- Valor, data, descrição e forma de pagamento são preservados, e nenhum lançamento novo é criado.
- A resposta confirma o que mudou, por exemplo: "Corrigido: categoria Outros → Mercado. Valor R$ 29,98 mantido."
- O alvo é o último lançamento da conversa, inclusive um comprovante que acabou de ser importado.

**Ambiguidade:** quando há vários lançamentos possíveis e nada na conversa indica qual, o chat **pergunta** ("Qual lançamento devo corrigir? 1) … 2) …") antes de alterar.

**O que não vira correção:**
- frases com valores, como "comprei 50 no mercado", que continuam sendo lançamentos novos;
- perguntas;
- frases longas, como "essa é a casa da minha mãe".

## 4. Aprendizado com as correções

**Armazenamento:**
- Fica em `cat_aprendizado`, nos dados de módulo do **próprio usuário** (`user_modules`, que já existia, sem migração).
- **Isolado por conta**: nada é compartilhado.
- Guarda até 300 associações, das mais recentes.

**Funcionamento:**
- **Chave = estabelecimento normalizado**, sem LTDA/ME/números e sem prefixos como "Transferência para".
- Pequenas variações do mesmo nome são reconhecidas.
- **Uma nova correção substitui** a associação anterior.
- **Nada antigo é alterado**: o aprendizado vale só para novos comprovantes.

**Correções que não viram regra:** descrições genéricas como "Pix enviado", "Pagamento", "Compra" e "não identificado" são ambíguas e não são memorizadas.

## Arquivos

**Novos:**
- `server/src/ai/classificar.ts`: classificação por evidências, aprendizado por usuário e compreensão dos pedidos de categoria.
- `docs/CLASSIFICACAO_DESPESAS.md`: este documento.

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/ai/finchat.ts` | Resumo sem o método de leitura; classificação nos dois caminhos de leitura (local e IA); subcategoria no resumo (ex.: "Alimentação › Mercado"); pedido de categoria antes de confirmar e depois de registrar (mesmo lançamento, com pergunta quando ambíguo); aprendizado quando a categoria é corrigida; mensagem simples para falhas de leitura |
| `server/src/ai/capabilities.ts` | A capacidade "Lançamentos financeiros" do Cérebro cita a classificação e a correção de categoria |
| `server/src/ai/leitura-local.ts` | Guarda o texto lido (itens da nota) para classificar. Não é mostrado ao usuário |
| `server/test/run.ts` | Teste novo de classificação, correção e aprendizado (detalhes abaixo). Testes de comprovante ajustados ao resumo sem o método e à classificação "Mercado Bom Dia" → Alimentação › Mercado |
| `server/test/browser/comprovante_sem_ia.py` | Confere o resumo sem o método e a correção "Essa compra é lazer." pela tela |

**Cenários do teste novo (IAs desligadas):**
- produtos de mercado;
- combustível;
- conveniência dentro do posto;
- farmácia, restaurante e cinema;
- Outros quando não há evidência;
- 5 frases de correção e 7 frases que não são correção;
- mesmo lançamento corrigido, sem duplicar e sem alterar os antigos;
- aprendizado e substituição;
- isolamento entre contas;
- regra genérica não aprendida;
- pergunta quando é ambíguo.

**Sem alteração:**
- Central de Mídias;
- leitura de comprovantes (OCR, IA, OCR.space);
- regras financeiras e categorias;
- banco de dados (nenhuma migração);
- autenticação e usuários.

## Publicação

Suba no GitHub e rode o `update.sh` de sempre. A central **não** precisa ser reconstruída.
