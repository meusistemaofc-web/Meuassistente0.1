# CRM de "Sua empresa"

CRM real (persistência, validações, permissões, auditoria e integração com o chat) sobre as estruturas que já existiam. **Não há um segundo cadastro de clientes** e pedidos/agendamentos **não são copiados**.

## Onde fica
Sua empresa → Ajustes → **CRM** (planos com loja, nível ≥ 4). Abas: Visão geral · Clientes e leads · Funil · Oportunidades · Tarefas · Inteligência · Configurações.

## O que foi reutilizado e o que é novo
| Tema | Reutilizado | Novo (migração `025_crm.sql`, aditiva) |
|---|---|---|
| Clientes | `users` + `orders` (inclui convidados do agente) | `crm_contacts` (relacionamento; `user_id` aponta para o usuário existente) |
| Pedidos/agendamentos | `orders` (agendamento = `data.tipo`) | `crm_order_links` (apenas liga o pedido ao contato) |
| Pagamentos | `orders.data.pago` | consultado na linha do tempo |
| Permissões/isolamento | dono da empresa (`businesses.owner_id`), plano (`plans()`), módulo `crm` | `acesso()` em toda rota |
| Notificações | `notify()` + agendador | lembrete de tarefa (uma vez por prazo) |
| Auditoria | `audit_log` | ações `crm.*` com canal (painel/chat) |
| IA | padrão do `agenda-ia` (ferramentas + contexto) | `ai/crm-ia.ts` (9 ferramentas `crm_*`) |

## Serviços (`server/src/lib/crm.ts`)
`CustomerRelationshipService` (contatos, histórico, linha do tempo), `LeadManagementService` (vínculo de pedidos/agendamentos e promoção a cliente), `SalesPipelineService` (etapas e funil), `OpportunityService`, `CRMTaskService`, `CommercialIntelligenceService`, `CRMService` (visão geral, categorias, etiquetas, responsáveis).

## Regras importantes
- **Sem duplicidade**: o contato é localizado por usuário do app, e-mail e telefone normalizado (`+55`, máscara e 9º dígito não criam outro cadastro). Cadastro repetido (painel ou chat) reaproveita e só completa campos vazios. Editar para um telefone/e-mail já usado dá 409.
- **Novo pedido/agendamento** é ligado automaticamente ao contato (logada ou convidado); quem compra vira "cliente". O dono comprando na própria loja não é cliente.
- **Funil**: 8 etapas padrão por empresa (nome, cor, ordem, probabilidade e "conta como em negociação" editáveis; etapas novas; remoção com destino das oportunidades; sempre ao menos uma etapa "ganha" e uma "perdida"). Perda exige motivo; venda concluída torna o contato cliente; voltar a etapa aberta reabre.
- **Indicadores** (visão geral): totais reais de clientes, leads novos (30 dias), leads em negociação, oportunidades abertas/concluídas/perdidas, conversão = ganhas ÷ (ganhas + perdidas), valor em aberto (e ponderado) e próximos acompanhamentos (7 dias).
- **Inteligência comercial** com critério e origem em cada item: leads sem acompanhamento (padrão 7 dias), oportunidades paradas (14), próximas do fechamento (≤ 7 dias ou prob. ≥ 75%), clientes para retorno (30 dias), maior probabilidade, recorrentes (≥ 2 compras), motivos de perda e desempenho por período/responsável. Limites ajustáveis em Configurações.
- **Tarefas** com tipo, responsável, prazo, prioridade, situação e histórico; lembrete pelas notificações quando o prazo chega.
- **Chat**: a IA usa só os serviços do CRM (mesmas validações). Ferramentas: buscar cliente, histórico, oportunidades, inteligência, registrar observação, criar lead, criar oportunidade, atualizar etapa e criar tarefa. O dono pode desligar "criar leads" e "mover etapas" pelo chat em Configurações. A IA não envia mensagens a clientes.
- **Isolamento**: todas as consultas filtram por `business_id` da empresa do usuário; outra empresa/usuário recebe 404.

## API (`/api/v2/businesses/:id/crm/...`)
`overview` · `contacts` (GET/POST), `contacts/:cid` (GET/PUT), `contacts/:cid/events` (POST) · `pipeline`, `stages` (POST/PUT/DELETE) · `opps` (GET/POST), `opps/:oid` (GET/PUT/DELETE), `opps/:oid/move` · `tasks` (GET/POST), `tasks/:tid` (PUT), `tasks/:tid/status` · `insights` · `config` (GET/PUT).

## Limitações / dependências
- Não existem contas de equipe: o acesso é do **dono**; "responsáveis" são nomes para organizar o trabalho (não logins).
- As conversas do cliente com o agente da loja não são guardadas por contato; o histórico traz interações registradas, pedidos, agendamentos, pagamentos e mudanças. Interações feitas pelo dono pelo chat entram marcadas "via chat".
- O administrador pode desligar o CRM com a chave de módulo `crm = false` (a API de módulos aceita a chave; ainda não há botão dedicado no painel).
- Lembretes usam as notificações do app (push depende da configuração já existente).

## Testes
`server/test/run.ts` (8 testes de CRM: acesso e isolamento, duplicidade, pedidos/agendamentos, funil/oportunidades, tarefas e lembrete, inteligência, chat, módulos preservados) e `server/test/browser/crm.py` (24 verificações, incluindo celular).
