# Identidade visual da empresa (tema único)

**Fonte única:** `businesses.data.tema` = `{ preset, cor, fundo: escuro|claro|colorido, layout, cantos }`, normalizado no servidor por `server/src/lib/theme.ts` (tema antigo/incompleto vira tema válido) e resolvido no navegador por **um só módulo**, `frontend/public/ma-theme.js` (`window.MaTheme`).

## Onde vale (sem configuração duplicada)
- Página do catálogo (`/x/empresa/:id`) e seus botões, cartões, abas, imagens e informações.
- Janelas/cards (produto, carrinho, agendamento…): são "camadas" (`MaTheme.layer`) que herdam o tema enquanto a página da empresa está aberta. A causa do card preto era anexar a janela em `document.body`, fora do contêiner que recebia as cores.
- Chat do agente (`/g-…` e o chat aberto dentro do catálogo): header, mensagens, cards de produto, observação, quantidade, botão de adicionar, carrinho, Pix.
- Fora do catálogo o app volta ao tema normal (nada vaza).

## Sincronização
Ao salvar o tema no painel (`Salvar tema`), `MaTheme.broadcast` atualiza na hora outras abas/iframes (BroadcastChannel + `storage`). Em outros aparelhos, as telas conferem a rota leve `GET /api/v2/theme/:id` (não conta visita) ao voltar para a tela e a cada 30 s. O último tema fica em cache local para não piscar na abertura.

## Ícones de contato
Localização, WhatsApp e Instagram são ícones compactos (36 × 36 no catálogo e nos cartões de busca; 38 × 38 nos chips do agente) com `aria-label`/`title`; links e funções iguais.

Testes: `server/test/browser/tema_catalogo_agente.py` (63 verificações) e `npm test`.
