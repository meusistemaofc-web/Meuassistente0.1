# Página de Links (exclusiva do Anúncio Completo)

Central de links pública de cada empresa, no endereço **`meuassistente.chat/<endereço-da-empresa>/links`**.

O endereço reaproveita o identificador exclusivo que a empresa já tem: o mesmo do agente, que pode ser personalizado pelo dono. Endereços antigos continuam funcionando.

## O que reaproveita

- **Endereço exclusivo**: `ensureSlug` / `idOfSlug` (`routes/businesses.ts`). Não há endereço novo para controlar.
- **Identidade visual do catálogo**:
  - o tema da empresa (`businesses.data.tema`), aplicado por `ma-theme.js` (MaTheme), com cor, fundo claro/escuro/colorido e cantos;
  - os mesmos elementos do cabeçalho do catálogo: capa de 1,6rem, logo, nome, categoria e situação;
  - cartões `.glass`, botão principal `.btn-send` e a mesma tipografia.
- **Logo e capa**: os do anúncio, que a página pode substituir.
- **Contratação do agente**: o plano pago e dentro da validade, o agente ligado e o módulo ligado pelo administrador.
- **Planos do anúncio**: o anúncio completo é o plano de nível 4, a mesma regra do Consultor de Marketing.

## Regras de acesso (todas conferidas no servidor)

- **Editar** (`/api/v2/ads/:id/links`):
  - só o dono da empresa (`ownBusiness`); outra empresa recebe 404;
  - plano de nível 4; nos outros planos, o servidor responde 403 `links_plano` e a opção nem aparece em *Sua empresa*.
- **Página pública** (`/api/v2/links/:endereço`): abre só quando a página está publicada, o anúncio está no ar (ativo, dentro da validade, sem suspensão) e no plano completo.
  - Se o anúncio vencer, for suspenso ou mudar para um plano inferior, a página sai do ar sozinha.
  - Quando a situação volta ao normal, ela reabre.
- **Catálogo**: botão padrão, sempre presente e ativo. Dá para mudar o título, a descrição e a posição.
- **Agente de Atendimento**: entra sozinho na configuração, mas só aparece na página enquanto o agente está contratado e ativo. Isso é conferido a cada visita, então segue as contratações e os vencimentos automaticamente.
  - O botão leva ao atendimento: `/<endereço>`.

## Funcionalidades

- **Apresentação**:
  - título;
  - descrição de até 300 caracteres;
  - logotipo e capa (próprios ou os do catálogo).
- **Cores**: por padrão, as do catálogo. Com "Usar as cores do catálogo" desligado, dá para escolher a cor principal e o fundo (escuro, claro ou colorido).
- **Botões personalizados**: Link, Site, WhatsApp, Instagram, Facebook, TikTok, YouTube, LinkedIn, Telegram e E-mail.
  - Cada um tem título, descrição opcional, ativar/desativar, excluir e mudar de posição (↑ ↓).
  - Máximo de 30 botões.
- **Validação dos links**:
  - links só `http`/`https` (um `javascript:` é recusado);
  - WhatsApp com DDD, que vira `wa.me/55…`;
  - usuário com `@` para Instagram, TikTok e Telegram;
  - e-mail válido.
- **Prévia em tempo real**: a própria página roda dentro de um quadro de celular e recebe o rascunho a cada alteração.
  - No celular, alterna entre as abas Editar e Prévia.
  - No computador, a prévia fica ao lado do editor.
- **Rascunho e publicação**:
  - "Salvar rascunho" não muda a página pública;
  - "Publicar página / Publicar alterações" atualiza a página pública;
  - "Descartar alterações" volta ao que está publicado;
  - "Despublicar" tira a página do ar.
- **Resultados**: visitas (uma por visitante por dia) e cliques por botão.
- **Compartilhar**: botão na página pública e "Copiar link" no gerenciamento.

## Onde fica

- **Dono**: *Sua empresa → Ajustes → Página de Links*.
- **Público**: `/<endereço>/links`.

## Arquivos

- `server/migrations/043_pagina_links.sql`: tabela `link_pages`, com rascunho, versão publicada, visitas e cliques. Só acrescenta.
- `server/src/lib/linkpage.ts`: regras, validação e montagem da página.
- `server/src/routes/linkpage.ts`: gerenciamento e página pública.
- `server/src/app.ts`: rotas da API e o endereço `/<endereço>/links`.
- `frontend/public/links.html`: página pública e prévia.
- `frontend/public/modules-addon.js`: gerenciamento em *Sua empresa* (`lojaLinks`) e o ícone exclusivo da opção.
- Testes:
  - `server/test/run.ts`: 2 testes;
  - `server/test/browser/pagina_links.py`: 20 verificações.

Nenhuma regra de anúncio, contratação ou pagamento foi alterada.
