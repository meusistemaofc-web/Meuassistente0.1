# Fase 7 — Inteligência preditiva e antecipação de necessidades

Esta fase acrescenta uma camada de **leitura e sugestão** sobre o que já existia:

- compromissos, tarefas, lembretes, contas, lançamentos e compras (`items`);
- planos em andamento e notas de cada resposta (pedidos recorrentes);
- inteligência comercial do CRM;
- sugestões proativas do chat (Nível 2);
- notificações (push e e-mail);
- aprendizado contínuo (Fase 6).

**Nenhum registro é criado, alterado ou cancelado por causa de uma previsão.**

A migração **034** só acrescenta duas tabelas (`predictions`, `predictive_alerts`) e a coluna `user_intel_prefs.predictive`.

## Arquitetura (`server/src/ai/preditivo.ts`)

Analistas especializados são **funções puras** sobre os dados do próprio usuário. A mesma lógica roda nos dados reais, no retroteste e nos cenários simulados. Os analistas trabalham **em paralelo e isolados**: a falha de um não derruba os outros. O **núcleo** consolida os resultados:

- um mesmo registro apontado por vários analistas vira **um** aviso, que cita os outros aspectos (ex.: "sem telefone" + "confirmar com o cliente");
- prioriza por urgência, por natureza (fato pesa mais que estimativa) e pelas categorias que o usuário marcou como importantes.

| Analista | O que antecipa |
|---|---|
| Agenda | **conflitos de horário** (pela duração; sem duração, assume 60 min e marca como estimativa), compromissos próximos, **sem telefone do cliente**, sem horário, **confirmar com o cliente**, **risco de esquecimento** (estimativa com critério explícito), **pós-atendimento**, saldo a receber |
| Tarefas | tarefas atrasadas, lembretes vencidos, **próxima etapa** de um plano em andamento, **compras recorrentes** |
| Finanças | contas vencendo e atrasadas, conta sem valor, **contas que se repetem todo mês** mas não estão cadastradas, **ritmo de gastos do mês** por categoria |
| Clientes / comercial | **clientes recorrentes**, **retorno previsto**, **clientes sem atendimento recente**, **padrões de procura** por dia da semana e serviço, **oportunidade de campanha** no dia mais vazio; para o **dono** de empresa, os itens da inteligência comercial do CRM (leads sem acompanhamento, oportunidades paradas, clientes para retorno, perto do fechamento) |
| Problemas | **possível duplicidade**, compromissos passados com situação desatualizada |
| Hábitos | **pedidos recorrentes** no chat (mesma área, dia da semana e período, em semanas diferentes) |

## Confiabilidade (item 7)

- **Fato**: lido diretamente de um registro. É mostrado como fato e não leva porcentagem.
- **Estimativa**: um padrão do histórico. Sempre traz:
  - **% de confiança**, calculada pela regularidade do padrão: quanto mais regular o intervalo e maior o número de ocorrências, maior a confiança;
  - a **base** verificável (por exemplo, "4 atendimentos · intervalo médio 30 dias (±0)");
  - a **janela** prevista.
- **Mínimos de dados**, abaixo dos quais nada é estimado:

  | Previsão | Mínimo |
  |---|---|
  | Recorrência e retorno | 3 ocorrências |
  | Conta do mês | 2 dos últimos 3 meses |
  | Ritmo de gastos | 2 meses de histórico |
  | Padrões de procura | 20 atendimentos em 8 semanas |

  Abaixo disso, a página mostra **"Onde ainda faltam dados"** e o assistente não inventa previsões.
- A ferramenta da IA (`get_previsoes`, só leitura) devolve a natureza, a confiança e a base de cada item, com a instrução de não tratar estimativa como fato e de não inventar além do que foi encontrado.

## Previsões conferidas e validação (item 12)

- As estimativas verificáveis entram em `predictions`: conta recorrente, retorno de cliente, compra recorrente e gasto do mês.
- Uma rotina diária confere cada uma com o que aconteceu de fato: **acertou** ou **errou**. O painel mostra a precisão real por tipo, ao lado da confiança média.
- **Cenários simulados** (verdade conhecida) medem:
  - cobertura e precisão;
  - falsos alertas e itens que não deveriam aparecer;
  - honestidade: sem dados, nenhum sinal; histórico curto, nenhuma estimativa;
  - velocidade.
  
  O resultado é 100% em datas diferentes (início, meio e fim de mês e virada de ano), em cerca de 1 ms.
- **Retroteste com o histórico**: volta 30 dias (só o que existia até lá), prevê e confere com o que aconteceu depois.

## Proatividade controlada (item 8)

O usuário controla tudo em **Previsões e sugestões → Como e quando avisar** (`/previsoes`, com atalho em Configurações):

- ligar ou desligar as sugestões preditivas;
- canais: chat e notificação;
- **frequência**: 1, 3 ou 5 avisos por dia;
- **horário de silêncio**, que pode atravessar a meia-noite;
- categorias e prioridades.

Regras contra excesso:

- no chat, no máximo **uma** sugestão por resposta, mantendo as regras já existentes (nada em desabafo ou pressa, intervalo de 2 h, "pare de sugerir");
- notificações só para o que é urgente ou importante;
- o mesmo aviso não se repete por 3 dias no chat e 7 dias por notificação;
- o que foi marcado como útil, dispensado ou "não faz sentido" não volta.

As reações (aceitar, dispensar, falso alerta, lembrar depois) alimentam os indicadores. No chat, um "sim" ou "não" logo depois da sugestão conta como aceite ou dispensa. "Pedir no chat" só preenche a caixa de mensagem; o usuário revisa e envia.

## Coordenação multiagente (item 9)

- Dentro do motor, os analistas trabalham em paralelo e o núcleo consolida.
- No chat, quando um pedido complexo aciona os agentes da Fase 4, os agentes de **análise, planejamento e vendas** recebem as previsões do usuário no quadro compartilhado, marcadas como fato ou estimativa. O agente de **pesquisa não** recebe (acesso controlado).

## Aprendizado (integração com a Fase 6)

- A política aprendida ganhou o parâmetro `preditivo.silenciar`, restrito a uma lista fechada de tipos.
- Quando **vários usuários** (3 ou mais) marcam mais da metade dos alertas de um tipo como "não faz sentido", a análise gera a proposta **"Silenciar alertas de X"**.
- A proposta passa pelo ambiente isolado, que mede os sinais preditivos antes e depois no cenário simulado. Ela só vale depois de aprovada pelo administrador e pode ser revertida.

## Painel do administrador (item 10)

O painel fica em Cérebro e busca → **Inteligência preditiva** e mostra só números:

- alertas apresentados, por canal e urgência;
- recomendações aceitas, falsos alertas e dispensas;
- previsões realizadas, avaliadas e a **precisão** real por tipo, com a confiança média;
- padrões por tipo;
- usuários que desligaram;
- a última validação (cenários e retroteste).

Ações disponíveis:

- ligar e desligar o recurso e os avisos;
- limite diário por usuário;
- desligar um tipo de sinal para todos;
- "Validar agora" e "Conferir previsões".

## Segurança (item 11)

| Regra | Como é garantida |
|---|---|
| Dados privados só com autorização | Só os dados do próprio usuário, que ele mesmo cadastrou. O CRM só entra para o **dono** da empresa, depois da checagem de acesso do próprio CRM. |
| Não misturar usuários | Toda leitura é filtrada por `user_id`, com teste dedicado. O painel mostra só contagens. |
| Sem ações sensíveis automáticas | O motor só lê. As ações aparecem como sugestão: "Quer que eu ajude a…?" ou "pedir no chat". |
| Não modificar registros | Teste compara todos os itens do usuário antes e depois. |
| Preservar o que existia | As sugestões proativas antigas continuam primeiro. A nova entra como a última opção, com os mesmos limites. |
| Testes e reversão | Ver abaixo. |

## Como reverter

| Nível | Como |
|---|---|
| Usuário | `/previsoes` → desligar "Sugestões preditivas", uma categoria ou um canal |
| Um tipo de alerta | Painel → Inteligência preditiva → Tipos de sinal |
| Tudo | Painel → desligar "Inteligência preditiva" (página, chat e avisos) |
| Banco | `DROP TABLE predictions, predictive_alerts;` (a coluna `predictive` pode ficar) |

## Limites

- **Sem sinais externos:** as estimativas são estatísticas simples, baseadas em regularidade e projeção linear do mês. Não há modelo de aprendizado de máquina nem sinais externos (clima, feriados nas estimativas de procura).
- **Duração assumida:** o conflito de horário assume 60 min quando o compromisso não tem duração e, por isso, aparece como estimativa.
- **Pedidos recorrentes:** usam só área, dia e período das notas das respostas, nunca o texto das conversas.
