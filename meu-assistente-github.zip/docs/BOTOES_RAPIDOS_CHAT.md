# Botões rápidos do Chat Principal

- **Exibição:** só em conversa nova e vazia (o app desenha a caixa apenas sem mensagens). Nomes, ordem, ícones e ligar/desligar continuam vindo do painel (`quick_buttons`); a ação do botão segue sendo enviar o texto cadastrado. Nada disso foi alterado.
- **Desaparecimento imediato:** ao clicar num botão rápido, ao pressionar Enter com texto ou ao clicar em Enviar com texto, a caixa é ocultada no mesmo instante (`qbGone`, em `modules-addon.js`), em fase de captura e sem interromper nem atrasar o envio. Menu de atalhos "/" aberto não conta como envio.
- **Por conversa, sem estado global:** a ocultação vale para a caixa daquele chat. Conversa nova monta caixa nova (botões de volta, com a configuração atual do painel); conversas com mensagens nunca exibem a caixa, inclusive ao voltar pelo histórico, alternar entre conversas ou atualizar a página.
- **Visual:** fundo e lista transparentes, sem sombra nem blocos brancos; borda discreta derivada da cor do texto (`color-mix`), texto `--nx-ink` e ícone `--nx-accent` (seguem tema claro/escuro); hover e toque com fundo translúcido sutil e leve escala (sem animação com "reduzir movimento"). Layout vertical, rolagem própria e responsividade iguais aos de antes. O Agente das empresas mantém o próprio visual.
- **Testes:** `server/test/browser/botoes_rapidos_conversa.py` (30 verificações: aparecer, sumir imediato por botão e por envio manual, restaurar em nova conversa, ocultos ao voltar/atualizar/alternar, painel) e `botoes_rapidos_chat.py` (visual transparente, ordem, ícones, envio).

## Visual minimalista e "Ver mais" no fim da lista

Vale para o **Chat Principal** (`.ma-qb-item`, em `modules-addon.js`) e para os **atalhos do Agente** (`#acts`, em `agente.html`), que continuam com a mesma identidade visual.

- **Formato:** só o ícone à esquerda (18 px, discreto, na cor `--nx-ink-3`) e o texto à direita (15 px, peso 500, `--nx-ink`).
- **O que saiu:** cápsula, contorno, fundo e efeito de escala.
- **Alinhamento:** todos os botões à esquerda, com espaçamento vertical uniforme (2 px entre itens de 44 px).
- **Área de toque:** 44 px de altura, mesmo sem bordas visíveis.
- **Interação:** ao passar o cursor, o ícone ganha a cor de destaque; ao tocar, o botão fica levemente translúcido. Navegando pelo teclado, aparece um contorno de foco. Com "reduzir movimento", não há transição.
- **"Ver mais" (Agente):**
  - **Fechado:** as opções principais e o "Ver mais" logo abaixo da última delas.
  - **Aberto:** todas as opções e, depois de todas, "Ver menos", que nunca fica no meio da lista. A lista aberta pode usar até 52% da altura da tela, para o botão final ficar visível.
  - **Sem opções extras:** o botão não aparece.
  - **Destaque e estado:** o texto do botão é um pouco mais claro que o das opções e indica o estado com `aria-expanded`.
- **Inalterados:** as regras de aparecer ao abrir uma conversa nova, sumir ao escolher uma opção ou enviar uma mensagem e não voltar durante a conversa. As ações, a ordem e a configuração do painel também não mudaram.
- **Testes:**
  - `atalhos_agente.py`, com 8 verificações novas: posição do "Ver mais" fechado e aberto, sem contorno, ícone e texto alinhados, área de toque, espaçamento uniforme, "Ver menos" visível e botão ausente sem opções extras.
  - `botoes_rapidos_chat.py` continua garantindo o mesmo visual do Agente.
- **Como reverter:** restaurar `agente.html` e o bloco CSS `.ma-qb-*` de `modules-addon.js` da versão anterior.

## Posição perto do campo de digitação e "Ver mais" no Chat Principal

Ajuste somente de aparência e posicionamento. Os botões, os textos, os ícones, a ordem do painel, as ações, as regras de exibição e o sumiço após escolher ou enviar não mudaram. O campo de digitação, o cabeçalho, o Agente e o backend não foram tocados.

- **Posição:** a lista (`.ma-qb-list`) fica na parte de baixo da área inicial do chat (`margin-top:auto` dentro da área de apresentação). Um espaçamento pequeno a separa do campo de digitação, e a saudação continua no alto.
- **Sem sobreposição:** a lista continua dentro da área rolável do chat. Por isso nunca cobre o campo de digitação nem o teclado virtual: com pouco espaço, quem rola é a área do chat.
- **Fim do corte:** o limite antigo de altura (38vh) foi retirado. Ele escondia a última opção no computador e o "Ver menos" no celular.
- **"Ver mais" (celular):**
  - **Onde fica:** é um botão (`.ma-qb-tg`) dentro da MESMA lista, com o mesmo visual, sempre por último. Não é um componente novo.
  - **Fechado:** mostra as 4 primeiras opções e o "Ver mais".
  - **Aberto:** mostra todas as opções e o "Ver menos" no fim, rolando até ele quando necessário.
  - **Sem efeito no envio:** não envia mensagem e não oculta a lista.
  - **Quais opções ficam recolhidas:** as que o app já escondia no celular (`max-sm:hidden`); nos botões personalizados do painel, as que vêm depois da 4ª.
  - **Quando não aparece:** sem opções extras, e também no computador, onde todas as opções ficam visíveis.
- **Sumiço:** escolher uma opção ou enviar uma mensagem oculta a lista inteira, com o "Ver mais", como antes.
- **Testes:**
  - `server/test/browser/botoes_rapidos_posicao.py` (31 verificações em celular, celular pequeno e computador): distância até o campo sem sobrepor, também com o campo em foco; ícones cinza uniformes e texto claro; sem borda, fundo ou sombra; alinhamento, espaçamento e centralização; "Ver mais"/"Ver menos" por último; sumiço após escolher.
  - `botoes_rapidos_chat.py`: deixou de comparar a altura máxima com a do Agente, que era justamente o corte removido.
- **Como reverter:** em `modules-addon.js`, tirar `margin-top:auto`, a regra `div:has(>.ma-qb-list)` e as funções `qbToggle`/`qbTgTxt`, e voltar `max-height:38vh;padding:0 0 8px`. Depois, voltar `?v=105` para `?v=104` em `server/src/app.ts`.
