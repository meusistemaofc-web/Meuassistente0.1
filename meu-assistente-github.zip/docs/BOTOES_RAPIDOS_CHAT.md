# Botões rápidos do Chat Principal

- **Exibição:** só em conversa nova e vazia (o app desenha a caixa apenas sem mensagens). Nomes, ordem, ícones e ligar/desligar continuam vindo do painel (`quick_buttons`); a ação do botão segue sendo enviar o texto cadastrado. Nada disso foi alterado.
- **Desaparecimento imediato:** ao clicar num botão rápido, ao pressionar Enter com texto ou ao clicar em Enviar com texto, a caixa é ocultada no mesmo instante (`qbGone`, em `modules-addon.js`), em fase de captura e sem interromper nem atrasar o envio. Menu de atalhos "/" aberto não conta como envio.
- **Por conversa, sem estado global:** a ocultação vale para a caixa daquele chat. Conversa nova monta caixa nova (botões de volta, com a configuração atual do painel); conversas com mensagens nunca exibem a caixa, inclusive ao voltar pelo histórico, alternar entre conversas ou atualizar a página.
- **Visual:** fundo e lista transparentes, sem sombra nem blocos brancos; borda discreta derivada da cor do texto (`color-mix`), texto `--nx-ink` e ícone `--nx-accent` (seguem tema claro/escuro); hover e toque com fundo translúcido sutil e leve escala (sem animação com "reduzir movimento"). Layout vertical, rolagem própria e responsividade iguais aos de antes. O Agente das empresas mantém o próprio visual.
- **Testes:** `server/test/browser/botoes_rapidos_conversa.py` (30 verificações: aparecer, sumir imediato por botão e por envio manual, restaurar em nova conversa, ocultos ao voltar/atualizar/alternar, painel) e `botoes_rapidos_chat.py` (visual transparente, ordem, ícones, envio).

## Visual minimalista e "Ver mais" no fim da lista

Vale para o **Chat Principal** (`.ma-qb-item`, em `modules-addon.js`) e para os **atalhos do Agente** (`#acts`, em `agente.html`), que continuam com a mesma identidade visual.

- **Formato:** só o ícone à esquerda (18 px, discreto, na cor `--nx-ink-3`) e o texto à direita (15 px, peso 500, `--nx-ink`).
- **O que saiu:** cápsula, contorno, fundo e efeito de escala.
- **Alinhamento:** todos os botões à esquerda, com espaçamento vertical uniforme (2 px entre itens de 44 px).
- **Área de toque:** 44 px de altura, mesmo sem bordas visíveis.
- **Interação:** ao passar o cursor, o ícone ganha a cor de destaque; ao tocar, o botão fica levemente translúcido. Navegando pelo teclado, aparece um contorno de foco. Com "reduzir movimento", não há transição.
- **"Ver mais" (Agente):**
  - **Fechado:** as opções principais e o "Ver mais" logo abaixo da última delas.
  - **Aberto:** todas as opções e, depois de todas, "Ver menos", que nunca fica no meio da lista. A lista aberta pode usar até 52% da altura da tela, para o botão final ficar visível.
  - **Sem opções extras:** o botão não aparece.
  - **Destaque e estado:** o texto do botão é um pouco mais claro que o das opções e indica o estado com `aria-expanded`.
- **Inalterados:** as regras de aparecer ao abrir uma conversa nova, sumir ao escolher uma opção ou enviar uma mensagem e não voltar durante a conversa. As ações, a ordem e a configuração do painel também não mudaram.
- **Testes:**
  - `atalhos_agente.py`, com 8 verificações novas: posição do "Ver mais" fechado e aberto, sem contorno, ícone e texto alinhados, área de toque, espaçamento uniforme, "Ver menos" visível e botão ausente sem opções extras.
  - `botoes_rapidos_chat.py` continua garantindo o mesmo visual do Agente.
- **Como reverter:** restaurar `agente.html` e o bloco CSS `.ma-qb-*` de `modules-addon.js` da versão anterior.
