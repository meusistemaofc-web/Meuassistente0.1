# Inteligência de Agenda e Funcionamento Empresarial

Capacidade registrada em **Painel admin → Cérebro e busca → Capacidades da inteligência** (id `agenda-ia`, categoria "Agendamentos e gestão de serviços"). Não cria painel, cérebro, tabela nem memória novos.

## Onde fica cada coisa
- `server/src/lib/calendar.ts` — funções puras: feriados nacionais (fixos + Carnaval, Sexta-feira Santa, Corpus Christi), dia efetivo, cálculo de horários.
- `server/src/routes/businesses.ts` — o motor de agendamento existente (`freeSlots`, `openState`) passou a usar o calendário; sem calendário o comportamento é idêntico ao anterior.
- `server/src/ai/agenda-ia.ts` — alertas proativos, ferramentas da IA, contexto do chat, aviso ao dono (scheduler a cada ≥6 h).
- `server/src/routes/agenda-ia.ts` — `GET/PUT /api/v2/ads/:id/calendar` (dono) e `GET/PUT /api/panel/agenda_ia` (admin liga/desliga).
- Dados: `businesses.data.calendario` (fonte oficial persistida; **sem migração**).
- Telas: dono em *Sua empresa → Ajustes → Calendário e funcionamento*; admin liga/desliga no cartão da capacidade.

## Modos (escolhidos pelo dono)
| Modo | Comportamento |
|---|---|
| Manual | A IA só consulta e sugere. Nunca altera. |
| Inteligente | Avisa de feriados/conflitos e altera **somente** quando o dono pedir no chat (com confirmação). |
| Automático | Também aplica regras recorrentes ("todo ano") que o dono autorizou. |

Prioridade do dia: exceção manual > decisão da data > decisão recorrente (só automático) > horário semanal. Intervalos e bloqueios removem faixas; reservas existentes nunca são canceladas.

## Cálculo de disponibilidade
Nunca passa do fechamento, não atravessa intervalos/bloqueios nem conflita com reservas. Grade padrão = legado (passo `min(duração,30)`); opção "de duração em duração" dá 09–12: 60 min → 09h, 10h, 11h; 120 min → 09h.

## IA
Ferramentas: `agenda_empresa_consultar`, `agenda_empresa_alertas` (leitura livre), `agenda_empresa_decidir`, `agenda_empresa_intervalo` (só dono, respeitam o modo, pedem confirmação e listam reservas afetadas). Disponíveis no chat principal/assistente; o atendimento ao cliente recebe o calendário no contexto (e agenda via o mesmo motor). Desligar a capacidade remove as ferramentas; o calendário continua valendo para reservas.

## Aprendizado
Decisões anteriores (histórico) só geram **sugestões**; nunca viram regra sem autorização do dono.

## Limitações
- Feriados estaduais/municipais precisam ser cadastrados pelo dono.
- Alertas de capacidade e sugestões de reorganização são heurísticos e informativos.
- O verificador de notificações varre as empresas ativas a cada ≥6 h.
