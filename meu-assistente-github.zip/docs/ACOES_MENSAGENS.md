# Ações das mensagens do Chat Principal

## Respostas da IA

- **Uma linha, logo abaixo da resposta, nesta ordem:** **Copiar → Curtir → Não curtir**.
- **Sem a opção de editar.** O "Editar texto" do app fica oculto só nas respostas da IA.
- **Visual:** só ícones, cinza (`--nx-ink-3`), todos de 16 px com área de toque de 32 px, sem círculo, borda, fundo ou texto.
- **Avaliação escolhida:** fica na cor de destaque, com um preenchimento leve.
- **Acessibilidade:** a confirmação ("Obrigado!") continua sendo anunciada aos leitores de tela, mas não aparece na tela.

## O que cada ação faz

| Ação | Comportamento |
|---|---|
| Copiar | o botão que já existia no app; copia a resposta inteira |
| Curtir | registra avaliação positiva; tocar de novo desfaz |
| Não curtir | registra avaliação negativa **na hora**; o painel de motivos e comentário (já existente) abre em seguida, como opcional; tocar de novo desfaz |

Uma avaliação por resposta: o registro é atualizado, nunca duplicado (`response_feedback`, por usuário e mensagem). O mecanismo de avaliação e as preferências pessoais (Nível 2) continuam iguais.

## Mensagens do usuário

Sem mudança: Copiar e **Editar mensagem** continuam como antes.

## Implementação

O ajuste foi feito no componente que já cuidava das avaliações, `frontend/public/feedback-addon.js`:
- **Posição:** a barra de 👍/👎 passou a ser encaixada na barra de ações que o app já desenha (`.msg-tools`), logo depois de Copiar.
- **Edição:** o botão de editar das respostas da IA fica oculto.
- **Estilo:** é igual para os três botões.

Não há componente nem evento novo, e o conteúdo das mensagens e o funcionamento do chat não mudaram.

## Testes

- **Novo:** `server/test/browser/acoes_mensagens.py`, com 29 verificações no celular e no computador. Cobre a ordem, uma única linha, a posição, apenas ícones, sem fundo ou borda, a mesma cor e o mesmo tamanho, a cópia integral, Curtir e Não curtir, a ausência de duplicidade, o Editar do usuário preservado e funcionando, e a ausência de erros de JavaScript.
- **Atualizado:** `inteligencia_n2.py` agora espera botões sem borda.

## Como reverter

Restaurar o `feedback-addon.js` da versão anterior.
