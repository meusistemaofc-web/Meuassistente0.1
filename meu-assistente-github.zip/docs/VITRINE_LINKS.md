# Vitrine inteligente de links (comandos de barra "/")

Módulo **independente dos anúncios**: o administrador cadastra links no painel (**Vitrine de Links**) e os usuários os encontram digitando `/` nos chats.

## Painel (administrador)
Campos obrigatórios: imagem/capa, título (2–80), descrição (3–300), URL de destino (http/https) e palavra-chave iniciada por `/`.
Também: ativar/desativar, editar (inclusive palavra-chave e imagem), excluir, ordem de exibição (↑ ↓ ou campo), onde aparece (chat do assistente e/ou agentes das empresas), público (todos, donos de empresa, administradores) e limitação a empresas específicas. A lista mostra **cards abertos** e **cliques** de cada link.
Somente administradores (escrita exige `panel.manage`) cadastram, editam e excluem; tudo é auditado (`showcase.*`).

## Nos chats
- Digitar só `/` abre um menu flutuante com todos os atalhos ativos permitidos ao usuário; `/mus` filtra em tempo real (prefixo primeiro, depois trecho da palavra ou do título); `/musica` deixa a correspondência exata marcada.
- Setas, Enter/Tab, toque ou clique selecionam; Esc fecha. A seleção abre o **card** (imagem, título, descrição e botão **Acessar**) dentro da conversa, sem enviar nada para a IA.
- O link abre em nova aba com `noopener,noreferrer`; o clique é contado.
- Onde funciona: chat do assistente (usuário logado) e agente de atendimento de cada empresa (visitante, sem login).

## Regras determinísticas
- O menu só aparece se o campo contém **apenas** `/` + letras, números, `-` ou `_`. URLs (`http://…`), caminhos (`/usr/bin`), `oi /musica`, `1/2` e `//` nunca disparam.
- Sem resultados ou com Shift+Enter, nada é interceptado: a mensagem segue o fluxo normal. Não há IA na busca (mesma regra no servidor, `?q=`, e no navegador).
- Palavras-chave são únicas (minúsculas, sem acento): duplicadas retornam 409.

## Segurança
URL validada no servidor (apenas http/https, sem usuário/senha, sem espaços); imagem só PNG/JPG/WebP (≤ ~250 KB, reduzida no painel) ou link https. A lista enviada ao chat **não inclui URL nem imagem**: ficam no card, que o servidor só entrega se o atalho está ativo e visível para aquele usuário/empresa (senão 404, mesmo sabendo o id). O atalho nunca executa comando administrativo ou financeiro: só abre um card com link. Consultas e cliques têm limite de taxa.

## Dados
Migração aditiva `022_vitrine_links.sql` (tabela `showcase_links`; não toca nos anúncios). API: `GET/POST /api/panel/showcase`, `GET /api/v2/showcase?canal=chat|agentes&b=<empresa>[&q=/mus]`, `GET /api/v2/showcase/:id`, `POST /api/v2/showcase/:id/click`.

## Limitações
- No chat do assistente o card é gravado no histórico (ver abaixo). Nos agentes públicos (visitante sem login) continua apenas da sessão, pois não há conversa salva.
- "Acessos" conta cards abertos (não visitantes únicos).
- O chat do assistente é um app compilado: a integração é feita por script complementar (`vitrine-addon.js`) que reconhece o campo de mensagem; se o app mudar a estrutura desse campo, o seletor precisa ser ajustado.

## Acessos temporários (menu "/" e cards)

- **Menu:** aparece só quando o usuário digita `/`; abre e fecha com animação suave (0,16 s, respeita "reduzir movimento"); some ao selecionar uma opção, ao perder o foco, com Esc e ao abrir um novo chat. É uma camada flutuante, então não deixa espaço vazio. Pode ser aberto de novo a qualquer momento digitando `/`.
- **Cards abertos no chat** pertencem à conversa em que foram abertos: ao iniciar um **novo chat** ou abrir **outra conversa** eles são removidos (antes ficavam fixos na tela). A primeira mensagem de um chat novo não apaga o card aberto antes dela.
- Nenhuma opção, permissão ou configuração mudou; o Agente usa o mesmo script e não tem troca de conversa.
- Teste: `server/test/browser/vitrine_temporaria.py` (27 verificações, celular e computador).

## Cards como mensagens do histórico (`link_card`)

Ao escolher um atalho no chat do assistente, o card passa a ser uma **mensagem estruturada do usuário** na tabela oficial `messages` (sem novas tabelas nem migração):
- `role = user`, `content = ⟦lc:<id do atalho>:<opId>⟧` (identificador único contra duplicação), `cards = [{ kind: "link_card", linkId, palavra, titulo, descricao, imagem, url, opId }]` (snapshot: o card continua funcional mesmo se o atalho for desativado depois) e `conversation_id` da conversa. `GET /api/chat?c=` devolve `type: "link_card"` nessas mensagens.
- `POST /api/v2/showcase/:id/message` `{ conversationId, opId }` (só usuário logado; o servidor revalida a visibilidade do atalho; repetir o mesmo `opId` não duplica; conversa de outro usuário → 404).
- Ordem cronológica por id: card → pergunta → resposta. Em chat novo (ainda sem id) o card fica pendente e é gravado imediatamente **antes** do 1º envio; o título da conversa vem da primeira pergunta real.
- O marcador nunca entra no contexto da IA (`history()` o ignora) e a IA não é chamada ao escolher um atalho.

**Causa do defeito anterior:** o card era um elemento DOM anexado ao contêiner de rolagem, *fora* da lista de mensagens do app e sem registro no servidor; por isso as respostas novas apareciam acima dele e ele sumia ao voltar/atualizar. Agora o card entra **dentro** da lista (`.mt-auto`), é gravado no servidor e, ao reabrir a conversa, o `vitrine-addon.js` troca a mensagem `link_card` pelo card no lugar exato (sem piscar). Como o app mantém em memória as conversas já abertas, cards gravados na sessão são recolocados na posição certa (pelo id da mensagem) ao voltar à conversa.

Testes: `server/test/run.ts` ("Cartões \"/\" …") e `server/test/browser/vitrine_historico.py` (cenários A–F, celular e computador); `vitrine_temporaria.py` atualizado (o card agora pertence ao histórico da própria conversa).
