# Vitrine inteligente de links (comandos de barra "/")

Módulo **independente dos anúncios**: o administrador cadastra links no painel (**Vitrine de Links**) e os usuários os encontram digitando `/` nos chats.

## Painel (administrador)
Campos obrigatórios: imagem/capa, título (2–80), descrição (3–300), URL de destino (http/https) e palavra-chave iniciada por `/`.
Também: ativar/desativar, editar (inclusive palavra-chave e imagem), excluir, ordem de exibição (↑ ↓ ou campo), onde aparece (chat do assistente e/ou agentes das empresas), público (todos, donos de empresa, administradores) e limitação a empresas específicas. A lista mostra **cards abertos** e **cliques** de cada link.
Somente administradores (escrita exige `panel.manage`) cadastram, editam e excluem; tudo é auditado (`showcase.*`).

## Nos chats
- Digitar só `/` abre um menu flutuante com todos os atalhos ativos permitidos ao usuário; `/mus` filtra em tempo real (prefixo primeiro, depois trecho da palavra ou do título); `/musica` deixa a correspondência exata marcada.
- Setas, Enter/Tab, toque ou clique selecionam; Esc fecha. A seleção abre o **card** (imagem, título, descrição e botão **Acessar**) dentro da conversa, sem enviar nada para a IA.
- O link abre em nova aba com `noopener,noreferrer`; o clique é contado.
- Onde funciona: chat do assistente (usuário logado) e agente de atendimento de cada empresa (visitante, sem login).

## Regras determinísticas
- O menu só aparece se o campo contém **apenas** `/` + letras, números, `-` ou `_`. URLs (`http://…`), caminhos (`/usr/bin`), `oi /musica`, `1/2` e `//` nunca disparam.
- Sem resultados ou com Shift+Enter, nada é interceptado: a mensagem segue o fluxo normal. Não há IA na busca (mesma regra no servidor, `?q=`, e no navegador).
- Palavras-chave são únicas (minúsculas, sem acento): duplicadas retornam 409.

## Segurança
URL validada no servidor (apenas http/https, sem usuário/senha, sem espaços); imagem só PNG/JPG/WebP (≤ ~250 KB, reduzida no painel) ou link https. A lista enviada ao chat **não inclui URL nem imagem**: ficam no card, que o servidor só entrega se o atalho está ativo e visível para aquele usuário/empresa (senão 404, mesmo sabendo o id). O atalho nunca executa comando administrativo ou financeiro: só abre um card com link. Consultas e cliques têm limite de taxa.

## Dados
Migração aditiva `022_vitrine_links.sql` (tabela `showcase_links`; não toca nos anúncios). API: `GET/POST /api/panel/showcase`, `GET /api/v2/showcase?canal=chat|agentes&b=<empresa>[&q=/mus]`, `GET /api/v2/showcase/:id`, `POST /api/v2/showcase/:id/click`.

## Limitações
- O card é local à conversa aberta (não é gravado no histórico; some ao recarregar).
- "Acessos" conta cards abertos (não visitantes únicos).
- O chat do assistente é um app compilado: a integração é feita por script complementar (`vitrine-addon.js`) que reconhece o campo de mensagem; se o app mudar a estrutura desse campo, o seletor precisa ser ajustado.

## Acessos temporários (menu "/" e cards)

- **Menu:** aparece só quando o usuário digita `/`; abre e fecha com animação suave (0,16 s, respeita "reduzir movimento"); some ao selecionar uma opção, ao perder o foco, com Esc e ao abrir um novo chat. É uma camada flutuante, então não deixa espaço vazio. Pode ser aberto de novo a qualquer momento digitando `/`.
- **Cards abertos no chat** pertencem à conversa em que foram abertos: ao iniciar um **novo chat** ou abrir **outra conversa** eles são removidos (antes ficavam fixos na tela). A primeira mensagem de um chat novo não apaga o card aberto antes dela.
- Nenhuma opção, permissão ou configuração mudou; o Agente usa o mesmo script e não tem troca de conversa.
- Teste: `server/test/browser/vitrine_temporaria.py` (27 verificações, celular e computador).
