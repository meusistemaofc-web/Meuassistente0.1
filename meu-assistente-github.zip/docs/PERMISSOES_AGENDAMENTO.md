# Permissões de Agendamento

Controle, configurado pelo proprietário da empresa, de quem pode **agendar pedidos** e **solicitar serviços**. São duas operações distintas, com permissões e fluxos independentes:

| Opção | Ligada | Desligada (padrão) |
|---|---|---|
| **Agendamento de pedidos** | O cliente escolhe o dia e o horário para receber ou retirar o pedido | Pedidos só "para agora", como sempre foi |
| **Agendamento de serviços com aprovação** | O cliente envia uma **solicitação**, que fica **Aguardando aprovação** até o dono ou um aprovador decidir. Nunca há confirmação automática | O agendamento de serviços continua exatamente como antes |

Empresas que nunca configuraram ficam com as duas opções desligadas, sem mudança alguma no comportamento.

## Onde fica

- **Configuração:** Sua empresa › Ajustes › **Permissões de Agendamento**. Só o proprietário vê e altera.
- **Painel de aprovação:** `/x/solicitacoes`. O caminho muda conforme quem acessa:
  - **Dono:** botão "Responder solicitação" na aba Pedidos, botão "Ver solicitações" nas permissões e a notificação.
  - **Aprovador:** atalho "Solicitações para aprovar" em Meus pedidos e a notificação.
- **Cliente no app:** página da empresa (agendar serviço e checkout) e Meus pedidos.
- **Visitante no atendimento automático (`/a/:id`):** agendamento de serviço, carrinho e cartão de acompanhamento da solicitação.

## Configuração (somente o dono)

**Agendamento de pedidos**
- **Quem pode:** todos os clientes (inclui visitantes do atendimento automático), só quem tem conta, ou clientes selecionados pelo e-mail ou WhatsApp da conta.
- **Antecedência mínima:** de 0 a 1 dia.
- **Limite:** até quantos dias à frente.
- **Horários:** os mesmos do funcionamento real do dia (horário semanal, calendário, feriados, exceções e intervalos), de 30 em 30 minutos. Com a loja fechada agora, o cliente ainda pode agendar para um horário em que ela estará aberta. O pedido para agora continua bloqueado.

**Agendamento de serviços com aprovação**
- **Quem pode:** as mesmas três opções.
- **Reserva temporária:** por padrão, o horário fica livre até a aprovação. A empresa pode reservar por 30 minutos, 1, 2 ou 24 horas.

**Aprovadores**
- O dono pode delegar a aprovação a funcionários (contas existentes, pelo e-mail ou WhatsApp).
- Aprovadores aprovam, recusam e sugerem horários, mas não alteram a configuração nem adicionam pessoas.

## Fluxo da solicitação de serviço

1. O cliente escolhe o serviço, a data e o horário pretendidos e preenche as informações. No atendimento automático, nome e WhatsApp são obrigatórios.
2. O sistema registra a solicitação com o status **Aguardando aprovação** (`aguardando_aprovacao`):
   - ela não entra na Agenda do dono;
   - não cobra sinal;
   - não bloqueia o horário, salvo reserva temporária configurada.
   O mesmo pedido enviado duas vezes não é duplicado.
3. O dono e os aprovadores recebem uma notificação.
4. O painel mostra o nome do cliente, o serviço, a data e o horário pretendidos, as informações adicionais, quando foi enviada, o canal e o status atual. As ações são **Aprovar**, **Recusar** (com motivo, que o cliente vê), **Sugerir outro horário** e **Detalhes** (WhatsApp, sinal e histórico).

### Decisões e retorno ao cliente

| Decisão | O que acontece |
|---|---|
| **Aprovar** | O horário é **verificado de novo** no momento da aprovação. Se ainda estiver livre, o status vira **Confirmado**, o agendamento entra na Agenda do dono e o cliente é avisado. Se o serviço tem sinal e a loja usa Pix automático, o Pix é gerado só agora. Se o horário foi ocupado, a aprovação é recusada (409) e o painel orienta a sugerir outro |
| **Recusar** | O status vira **Não aprovado**. O cliente recebe a notificação com o motivo |
| **Sugerir outro horário** | Só é aceito um horário livre e diferente do pedido. O status vira **Novo horário sugerido**, e o cliente recebe a proposta com a mensagem. **A sugestão não confirma nada** |
| **O cliente aceita a sugestão** | Nova verificação do horário. Se ainda está livre, o agendamento fica **Confirmado** e o horário original é guardado. Se foi ocupado, volta para **Aguardando aprovação** e a empresa é avisada |
| **O cliente recusa a sugestão** | A solicitação é encerrada e a empresa é avisada |

### Proteção contra conflito

- **Mesmo horário:** aprovação, sugestão e resposta do cliente rodam sob a mesma trava por empresa usada nos agendamentos existentes. Dois aprovadores (ou duas abas) nunca confirmam o mesmo horário: o teste aprova duas solicitações iguais ao mesmo tempo e só uma é confirmada.
- **Decisão já tomada:** uma solicitação já decidida não pode ser decidida de novo.

## Segurança e isolamento

- **Configuração:** só o proprietário liga, desliga ou altera as permissões. Para os outros, a empresa nem aparece (404).
- **Painel de aprovação:** só o dono e os aprovadores daquela empresa. Clientes, funcionários de outras empresas e aprovadores removidos recebem 403.
- **Sugestão:** só o próprio cliente responde. Um visitante do agente responde com a chave do pedido, guardada no próprio aparelho.
- **Isolamento:** tudo é consultado por empresa. Contatos de aprovadores e clientes aparecem mascarados.
- **Auditoria** (`audit_log`):
  - `empresa.permissoes.config`, com antes e depois;
  - `empresa.permissoes.adicionar` e `empresa.permissoes.remover`;
  - `empresa.agendamento.solicitado`, `aprovado`, `recusado` e `sugerido`;
  - `empresa.agendamento.cliente_aceitou_sugestao` e `cliente_recusou_sugestao`;
  - `empresa.pedido.agendado`.

  Cada solicitação também guarda seu próprio histórico: quem, quando e o quê.

## Integração (sem módulos duplicados)

| Já existia | Como é usado |
|---|---|
| Pedidos (`orders`) | Solicitações e pedidos agendados continuam sendo pedidos. Os status novos `aguardando_aprovacao` e `sugestao` só aparecem com a opção ligada |
| Horários livres e trava por empresa | A mesma regra de horários do agendamento atual, agora com exclusão do próprio pedido na revalidação |
| Agenda do dono | Recebe o agendamento só quando ele é confirmado |
| Pix automático da loja | Sinal gerado só depois da aprovação; o pagamento é bloqueado antes disso |
| CRM | O cliente da solicitação é vinculado como nos demais pedidos |
| Notificações e contadores | Solicitações pendentes contam como novas para o dono e como em andamento para o cliente |
| Agente de atendimento | As ferramentas `agendar_servico` e `criar_pedido` (com `agendar_para`) seguem as mesmas permissões |

A migração **037** só acrescenta a tabela `business_permissions`, com os aprovadores e os clientes selecionados. A configuração fica em `businesses.data.permAgenda`.

## Testes

- **Servidor:** 5 testes novos.
  - **Permissões:** padrão desligado preserva o fluxo antigo; isolamento; validação e auditoria.
  - **Solicitação:** status, sem bloqueio de horário, sem duplicar, aviso aos responsáveis, aprovação com revalidação, recusa e auditoria.
  - **Sugestão:** sugestão com aceite e recusa, aprovações simultâneas e horário sugerido ocupado.
  - **Delegação e público:** aprovação delegada, reserva temporária (válida e vencida) e clientes selecionados.
  - **Pedido agendado:** no app e no agente, com antecedência, limite de dias e loja fechada.
- **Navegador:** `test/browser/permissoes_agendamento.py`, com 42 verificações. Cobre dono, cliente, aprovador e visitante do agente, no celular e no computador.

## Como reverter

| O quê | Como |
|---|---|
| Uma empresa | Desligar as duas opções em Permissões de Agendamento. Os fluxos antigos voltam na hora, e as solicitações já enviadas continuam no painel para serem decididas |
| Tudo | Desligar as opções nas empresas e `DROP TABLE business_permissions;`. O campo `permAgenda` pode ficar no JSON da empresa, porque é ignorado quando desligado |
