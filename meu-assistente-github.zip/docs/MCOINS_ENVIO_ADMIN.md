# MCoins: animações e "Enviar MCoins" (distribuição administrativa)

## Animações (frontend, `coin-art.js`)
- **Moeda 3D contínua:** toda moeda desenhada por `MaCoin.svg` (Mercado, carteira, checkout, painel) ganha inclinação suave (`mc-tilt`), brilho metálico que passa pela moeda (`mc-sweep`) e variação de iluminação (`mc-light`). Só `transform`/`opacity`; `MaCoin.svg(..., {static:true})` desliga em um caso específico.
- **Recebimento:** aviso destacado com a moeda, "+N SÍMBOLO", motivo, anel de pulso e 18 partículas (Web Animations API, removidas ao fim).
- **Saldo:** `MaCoin.countTo` anima o número (`data-mc-saldo`) quando o saldo muda; a carteira recarrega saldo e histórico sozinha.
- **Acessibilidade/desempenho:** `prefers-reduced-motion` (e a classe `ma-reduce-motion`) desliga moeda parada, partículas e contagem (valores aparecem direto). O vigia consulta `/api/v2/coins/novas` (consulta leve) ao abrir, a cada 40 s com a aba visível e ao voltar à aba; não roda nas telas de entrada.

## Enviar MCoins (Administração → "Enviar MCoins")
1. Escolha a moeda (publicada) e **pesquise** por nome, e-mail ou identificador; marque vários ou use **"Selecionar todos os filtrados"** (máx. 2000 por operação).
2. Informe **MCoins por usuário** (inteiro, 1 a 100.000) e o **motivo** (3 a 200 caracteres; aparece para o usuário).
3. **Revisar envio** mostra destinatários, total, motivo e o que resta da emissão. **Confirmar** ou **Cancelar** (cancelar não grava nada).

## Processamento e segurança
- Reaproveita a carteira (`coin_balances`) e o livro-razão (`coin_ledger`, tipo `distribuicao`, motivo em `note`, administrador em `actor`). Nenhuma carteira, moeda ou saldo é recriado ou zerado.
- **Atômico:** emissão (`distributed`), operação, créditos e livro-razão numa transação sob trava da moeda: ou todos entram ou nenhum (estoque insuficiente ou destinatário inválido não deixa resíduo).
- **Idempotente:** `idem` único por moeda (`coin_distributions`) + chave por crédito (`lote:<operação>:<usuário>`). Repetir (inclusive em paralelo) devolve a operação original sem creditar de novo. A chave é gerada na revisão, então duplo clique não duplica.
- **Servidor decide tudo:** só administradores com permissão de alterar o painel; o cliente não envia saldo, quem credita nem o administrador. Para seleção por filtro o servidor refaz a lista e confere `esperado` (a lista mudou ⇒ 409).
- **Rastreabilidade:** `coin_distributions` (código `MCD-…`, administrador, data/hora, quantidade, total, motivo, seleção, status), `coin_distribution_items` (usuário, quantidade, linha do livro-razão) e auditoria (`coins.enviar` / `coins.enviar.falha`).

## API (administração)
`POST /api/panel/coins` com `action: enviar_previa | enviar` · `GET /api/panel/coins/send/users?q=` · `GET /api/panel/coins/distributions` · `GET /api/panel/coins/distributions/:id`.
Usuário: `GET /api/v2/coins/novas` (créditos ainda não comemorados) · `POST /api/v2/coins/novas/vistas`.

## Migração 026 (aditiva e reversível)
Cria `coin_distributions`, `coin_distribution_items` e a coluna opcional `coin_ledger.seen_at` (histórico existente já nasce "visto": nada é reanimado). Reversão manual: `DROP TABLE coin_distribution_items; DROP TABLE coin_distributions;` (o livro-razão e os saldos ficam intactos).

## Limitações
- Não há estorno da distribuição pelo painel (créditos são promocionais e fechados); correções são feitas por nova operação/ajuste existente.
- Status da operação: `concluida` (operações que falham não gravam nada; ficam só na auditoria).
- A comemoração depende de o usuário abrir o app/aba; o aviso e o push seguem as preferências de notificação dele.

## Testes
`server/test/run.ts` (4 testes: prévia/crédito/histórico, idempotência e filtro, tudo-ou-nada e permissões, lado do usuário) e `server/test/browser/mcoins_envio.py` (25 verificações: tela, confirmação, cancelamento, crédito, animações, movimento reduzido, celular).

## Indicador de distribuição em porcentagem

Na administração das MCoins o indicador principal de distribuição é **percentual**: `(distribuídas ÷ emitidas) × 100`, com 1 casa decimal, limitado a 0–100 e `0%` quando não há emissão (sem divisão por zero). O símbolo `%` aparece em destaque (cor de destaque do tema). Cálculo no servidor (`pctDistribuido` em `lib/coins.ts`) sobre os dados reais, exposto como `percentualDistribuido` em cada moeda e no `resumo` (`GET /api/panel/coins`), e recalculado a cada leitura — portanto acompanha qualquer distribuição, adesão, ajuste, compra ou venda. A quantidade absoluta continua no detalhe da moeda ("Total emitido" e "Qtd. distribuída (detalhe)"), no histórico e no Enviar MCoins. Somente leitura: nenhum saldo, carteira ou movimento é alterado. Testes: `run.ts` e `test/browser/mcoins_percentual.py`.
