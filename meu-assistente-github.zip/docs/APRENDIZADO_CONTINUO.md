# Fase 6 — Aprendizado contínuo e evolução controlada

O aprendizado contínuo funciona sobre o que já existia:

- as notas de cada resposta (`cognition_evals`);
- as avaliações 👍/👎 (`response_feedback`);
- as experiências individuais (Fase 5);
- o Laboratório de IA (regras);
- o monitor de regressão.

A migração **033** só acrescenta duas tabelas (`learning_policy_versions`, `learning_proposals`) e a coluna `user_intel_prefs.contribute`.

## Princípio de segurança: a "política aprendida"

O aprendizado **não altera código, modelo, provedor, prompt livre nem permissões**. Só altera parâmetros de uma lista fechada (`server/src/ai/politica.ts`), sempre com limites:

| Área | Parâmetro | Valores |
|---|---|---|
| Qualidade das respostas | `qualidade.estilo.<área>` | curta, detalhada ou passos |
| Qualidade das respostas | `qualidade.perguntarAntes` | áreas onde dados ambíguos são confirmados antes de agir |
| Estratégia de raciocínio | `raciocinio.revisarSempre` | áreas com revisão automática em toda resposta |
| Estratégia de raciocínio | `raciocinio.planejarSempre` | áreas com organização em etapas |
| Recuperação de memória | `memoria.maxFatos` | 3 a 16 |
| Recuperação de memória | `memoria.limiteChars` | 800 a 4000 |
| Coordenação de agentes | `agentes.evitar.<área>` | agentes que ficam de fora naquela área |
| Uso de ferramentas | `ferramentas.dicas.<ferramenta>` | uma orientação de um **catálogo fixo** (5 textos) |
| Regras de comportamento | — | seguem para o Laboratório de IA, que tem simulação e aprovação próprias |

O texto que chega à IA vem sempre do catálogo fixo. O feedback do usuário nunca vira texto de prompt, o que impede injeção.

A política padrão (sem nenhuma versão aprovada) reproduz exatamente o comportamento anterior à Fase 6.

## Os 10 itens

1. **Coleta**:
   - O que entra:
     - avaliações 👍/👎 com motivo;
     - correções;
     - **reclamações em texto** ("você errou", "não era isso"), que marcam a resposta anterior;
     - falhas de ferramenta, com o nome e o resultado;
     - resultado do plano e da revisão;
     - versão da política usada em cada resposta.
   - Só entram notas e rótulos. O texto das conversas não é guardado.
2. **Análise de experiências** (`aprendizado.ts → padroes`):
   - padrões de erro e de sucesso por área e problema;
   - recorrência por semana;
   - taxa **ponderada por usuário**: cada usuário pesa 1, não importa quantas mensagens mandou.
3. **Aprendizado por resultados**:
   - compara estratégias reais com o mesmo critério: com e sem agentes, plano, revisão e memória;
   - compara também o resultado de cada **versão** da política;
   - só conclui algo com amostra e número de usuários mínimos.
4. **Autodiagnóstico**:
   - ferramentas que falham;
   - dificuldade de interpretação;
   - pedidos de ação sem execução;
   - notas baixas de naturalidade e clareza;
   - satisfação baixa por área;
   - lentidão (p95);
   - agentes pausados pelo disjuntor;
   - falhas no diagnóstico automático do núcleo.
5. **Geração de melhorias**:
   - cada padrão global vira uma proposta, com justificativa e evidência (só contagens);
   - cobre as seis áreas pedidas: regras, raciocínio, memória, agentes, ferramentas e qualidade;
   - propostas iguais não se repetem, e uma proposta rejeitada não volta por 30 dias.
6. **Ambiente de experimentação**:
   - a mesma bateria roda com a política atual e com a candidata, isolada por `AsyncLocalStorage`;
   - a bateria tem:
     - cenários sintéticos por área;
     - o corpus de diagnóstico (205 verificações e 49 casos novos);
     - a bateria do núcleo;
     - a recuperação nas memórias fictícias;
   - nenhum usuário é afetado.
7. **Avaliação comparativa** (antes × depois):
   - métricas:
     - **precisão**: corpus e validação;
     - **resolução de tarefas**: bateria;
     - **naturalidade**;
     - **consistência**: a mesma entrada duas vezes dá o mesmo resultado;
     - **velocidade**: tempo de preparo;
     - tamanho do contexto e acerto de memória;
   - reprova quando:
     - alguma métrica piora;
     - a mudança afeta outra área;
     - a mudança não tem efeito observável.
8. **Aprovação administrativa** (Painel → Cérebro e busca → Aprendizado contínuo):
   - só propostas aprovadas nos testes podem ser aprovadas;
   - na aprovação, a mudança pode ser:
     - **liberada gradualmente** para 10 a 50% dos usuários (grupo estável por usuário);
     - **liberada para todos**;
   - depois é possível **promover**, **reverter** ou **restaurar qualquer versão**;
   - cada passo fica no histórico da proposta e na auditoria.
9. **Aprendizado global controlado**:
   - só entra quem não desligou "Ajudar a melhorar o assistente" (Minha memória);
   - um padrão só vira proposta com **3 ou mais usuários distintos** (ajustável);
   - contas com padrão suspeito ficam fora da análise:
     - avalanche de negativos no mesmo dia;
     - 100% de negativos;
     - conta nova com muitos negativos;
   - as experiências e memórias individuais **nunca** entram no global.
10. **Monitoramento contínuo**:
    - evolução semanal (8 semanas): sucesso, correções, reclamações, nota, tempo e falhas de ferramentas;
    - resultado real por versão;
    - histórico de versões e alertas;
    - a liberação gradual **para sozinha** quando o grupo da melhoria fica claramente pior (10 pontos ou mais), e todos voltam à versão estável;
    - depois de uma ativação total, a regressão gera alerta e a reversão fica a cargo do administrador;
    - relatório em Markdown para baixar.

## Regras de segurança do pedido

| Regra | Como é garantida |
|---|---|
| Sem alterações autônomas no código | Só parâmetros da lista fechada e um catálogo fixo de textos. Toda ativação exige um administrador. |
| Sem mudar modelos ou parâmetros de produção sem validação | Modelo e provedor ficam fora da política. Toda mudança passa pelo experimento isolado antes da aprovação. |
| Sem aprender com informação privada | Usa só notas e rótulos, de quem consentiu. Memórias e experiências individuais não entram. |
| Feedback malicioso não contamina | Peso por usuário, mínimo de usuários distintos e exclusão de contas suspeitas. Texto do feedback nunca vira prompt. |
| Preservar as funcionalidades | A política padrão é idêntica à de antes. A chave geral desliga tudo. |
| Versionamento, testes e reversão | Versões encadeadas, experimento obrigatório, reversão por proposta e restauração de qualquer versão. |

## Validação

- **Servidor** (`server/test/run.ts`), 6 testes:
  - lista fechada e limites;
  - coleta e consentimento;
  - análise anti-contaminação;
  - experimento, aprovação gradual, efeito só no grupo, promoção e reversão;
  - reprovação no experimento e encaminhamento de regras ao Laboratório;
  - estratégias, autodiagnóstico, parada automática por regressão e relatório.
- **Navegador**: `server/test/browser/aprendizado_continuo.py`, com 19 verificações.

## Como reverter

| Nível | Como |
|---|---|
| Uma melhoria | Painel → Aprendizado contínuo → Reverter |
| Uma versão | Painel → Versões → Restaurar, ou "Voltar ao padrão" |
| Tudo | Desligar a chave "Aprendizado contínuo": o assistente volta ao comportamento padrão |
| Banco | `DROP TABLE learning_policy_versions, learning_proposals;` (a coluna `contribute` pode ficar) |
