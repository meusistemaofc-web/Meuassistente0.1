# Modalidade exclusiva do catálogo: PRODUTOS ou SERVIÇOS

Cada empresa trabalha com **uma** modalidade: produtos (loja: catálogo, estoque, carrinho e pedidos) **ou** serviços (atendimentos: horários, duração, agendamentos e sinal). A opção "Produtos e serviços" deixou de existir.

## Banco e servidor
- **Campo único:** coluna `businesses.modalidade`, com os valores `products` ou `services` e uma regra no banco (`CHECK`) que recusa qualquer outro valor (migração `039_modalidade_empresa.sql`).
- **Espelho:** o campo `data.tipo` (`produtos` | `servicos`) é gravado sempre na mesma operação, porque o restante do sistema já o lê. A coluna é a fonte de verdade: ao iniciar, o servidor corrige qualquer divergência a favor dela.
- **Validação no servidor**, não só na tela:
  - criar empresa com "ambos" → `400 modalidade_exclusiva`;
  - trocar a modalidade pela edição comum do anúncio (`PUT`) → `409 modalidade_confirmacao`;
  - cadastrar **ou editar** item da outra modalidade → `400`;
  - pedido em empresa de serviços, ou agendamento e horários em empresa de produtos → recusados;
  - as ferramentas do agente seguem a modalidade (empresa de produtos não agenda; empresa de serviços não cria pedido).
- **Isolamento:** a troca só vale para a empresa do próprio dono. Outra pessoa recebe `404`, e uma empresa não interfere em outra.

## Empresas existentes (migração sem perda)
Ao iniciar, o servidor dá a cada empresa sem modalidade a mais coerente com o que ela já tem (`lib/modalidade.ts` › `backfillModalidades`). Os critérios são aplicados nesta ordem:
1. a escolha já feita pela empresa (produtos ou serviços);
2. os itens ativos: só de um tipo, ou a maioria;
3. em caso de empate, o histórico (pedidos × agendamentos);
4. por último, o ramo da empresa (o mesmo critério já usado pelo sistema).

Nada é apagado nem convertido. Os itens da outra modalidade ficam salvos e ocultos, e o motivo e a quantidade ficam registrados em `data.modalidadeMigrada`. A migração é idempotente.

## Troca de modalidade (dono da empresa)
**Onde:** Sua empresa › Ajustes › Tipo de catálogo. A tela tem só as duas opções, com a atual marcada. Ao escolher a outra e tocar em "Continuar", o servidor (`GET/POST /api/v2/ads/:id/modalidade`) verifica e mostra as consequências.

**O que o aviso informa:**
- o que deixa de aparecer;
- quantos itens ficarão ocultos;
- quantos itens voltam a aparecer;
- os **pedidos e agendamentos em andamento**: continuam no painel para serem concluídos, mas novos deixam de ser aceitos;
- que o histórico é preservado.

**Ao confirmar ou cancelar:**
- **Confirmar alteração:** só então a modalidade muda, com registro no histórico e na auditoria (`empresa.modalidade`).
- **Cancelar:** nada muda.

## Onde a modalidade se reflete
- **Cadastro e edição de itens:** o formulário oferece só o tipo da modalidade.
- **Categorias do catálogo:** para o cliente, as categorias vêm dos itens visíveis, então só aparecem as da modalidade. A lista de nomes cadastrada em Ajustes › Categorias continua igual.
- **Página pública, anúncios, cards e busca:** mostram só os itens da modalidade.
- **Chat do agente:** catálogo, botões rápidos ("Ver produtos" ou "Agendar") e ferramentas seguem a modalidade.
- **Pedidos ou agendamentos:** validados no servidor. A aba do dono se chama "Pedidos" ou "Agenda", e o contador da aba soma tudo o que está em aberto, inclusive o que restou da modalidade anterior.
- **Relatórios e indicadores:** o início de Sua empresa mostra "Pedidos" ou "Agendamentos/Atendimentos" conforme a modalidade.
- **Painel administrativo:** a lista de anúncios mostra a modalidade de cada empresa.

## Testes
**Servidor** (`test/run.ts`):
- **"tipo de catálogo EXCLUSIVO":** tudo o que é bloqueado (interface, API e banco), a troca sem confirmação recusada, o aviso com pedidos em andamento, o isolamento, a troca confirmada sem apagar nem converter, o histórico preservado, a auditoria e a volta.
- **"modalidade: empresas existentes…":** os 4 critérios da migração, nenhum item ou pedido apagado, toda empresa com exatamente uma modalidade, idempotência e o espelho alinhado à coluna.

**Tela** (`tipo_catalogo_sinal.py`, em celular e computador): só duas opções, aviso, cancelar, confirmar, cadastro só da modalidade, itens ocultos preservados, `PUT` recusado e modalidade visível no painel do administrador.

**Testes antigos que montavam empresas "ambos":** foram ajustados para a regra nova. Usam uma modalidade, ou trocam com confirmação quando o teste precisa dos dois fluxos.

## Como reverter
1. Restaurar `routes/businesses.ts`, `routes/ads.ts`, `db/migrate.ts` e `modules-addon.js`/`panel-addon.js` da versão anterior. Voltar `?v=109` para `?v=108` e `?v=145` para `?v=144`.
2. Opcionalmente, rodar `ALTER TABLE businesses DROP COLUMN modalidade`. O `data.tipo` continua válido, e os itens nunca foram alterados.
