# Cupons de desconto por empresa

Módulo para a empresa (e o administrador) criar, distribuir e acompanhar cupons promocionais. Migração aditiva `020_cupons.sql`;
regras em `server/src/lib/coupons.ts`; rotas em `server/src/routes/coupons.ts`; integração com o pedido em `routes/businesses.ts`.

## Onde fica
| Quem | Onde | O que faz |
|---|---|---|
| Empresa (plano Loja completa) | Ajustes → **Cupons de desconto** | Cria, edita, pausa, exclui, distribui e vê resultados **só dos próprios cupons** |
| Administrador | Painel → **Cupons de desconto** | Vê o resumo e os cupons de **todas as empresas**, filtra por empresa, cria/edita/pausa/exclui e consulta histórico |
| Cliente | `/x/cupons` (também pela Carteira), vitrine da loja e checkout | Vê cupons recebidos e públicos, copia o código, aplica no pedido |

## Campos do cupom
Nome da campanha, código (3–24 letras/números/-/_, único **por empresa**, sempre maiúsculo), descrição, finalidade, tipo (**percentual** ou **valor fixo**),
valor, teto do desconto (opcional), compra mínima, início e fim (dia inteiro, horário de Brasília), quantidade total (0 = ilimitado), usos por cliente
(0 = sem limite), produtos participantes (vazio = todos), público (**todos** ou **exclusivo** para clientes selecionados), onde aparece (**vitrine** ou **só por código/envio**),
se pode somar com moedas de bônus e a empresa responsável.

**Situação:** guardada só `ativo`/`pausado`; `expirado`, `esgotado` e `agendado` são calculados na hora (nunca ficam desatualizados).

## Validação no pedido (todas obrigatórias)
Cupom existe **nesta empresa** (um código de outra empresa responde “inválido”, sem revelar que existe) · não está pausado · já começou · não expirou · não esgotou ·
cliente autorizado (se exclusivo) · ainda tem usos pessoais · algum item do pedido participa · compra mínima atingida · gera desconto maior que zero.
Desconto = % ou valor fixo **sobre os itens participantes**, limitado ao teto e ao valor desses itens (nunca passa do valor dos produtos; a entrega não recebe desconto).
O checkout mostra o desconto antes de enviar (`POST /api/v2/businesses/:id/coupons/validate`, não grava nada) e o servidor **revalida** ao criar o pedido.

## Registro e proteção contra reuso
* O resgate é gravado dentro de um bloqueio por cupom, **depois de revalidar** estoque e limite por cliente: dois pedidos ao mesmo tempo disputando o último cupom → só um passa.
* `UNIQUE(coupon_id, order_id)`: um pedido nunca consome o mesmo cupom duas vezes; reenviar o mesmo pedido (toque duplo, `idem`) devolve o pedido existente sem gastar outro cupom.
* Pedido pago por Pix online: cupom fica **reservado** até o pagamento ser aprovado (vira **usado**). Reserva de Pix não pago volta ao estoque após 30 minutos.
* Pedido **recusado ou cancelado**, ou falha ao gerar o Pix: o cupom é **estornado uma única vez** (volta ao estoque e ao cliente).
* Cupom já usado não pode ser excluído nem mudar de código (pause-o); a quantidade total não pode ficar abaixo dos usos.

## Combinação com moedas de bônus
Cada cupom define `combinaMoedas`. Se **sim**, as moedas descontam apenas o que sobrou depois do cupom (nunca duplicam desconto nem passam do valor dos itens);
se **não**, o servidor recusa o pedido que tente usar os dois e o checkout esconde as moedas quando esse cupom está aplicado.

## Distribuição, Marketing e CRM
* **CRM:** `crmSegmentos` classifica os clientes da empresa pelo histórico real de pedidos — *novos* (30 dias), *recorrentes*, *inativos* (60+ dias sem comprar),
  *potenciais* (autorizaram contato e ainda não compraram), *quem comprou os produtos do cupom* e *clientes específicos*. Cupom exclusivo só chega a quem está autorizado.
* **Canais:** `push` (notificação + área de cupons), `area` (somente a área de cupons do cliente) e `crm` (área de cupons, para acompanhar a campanha).
* **Push respeita:** autorização de comunicação do cliente (quem não autorizou **não** recebe notificação, mas vê o cupom na própria área), preferências de notificação do cliente,
  Central de Marketing ligada e plano com acesso, e o limite de notificações do período do plano. Cada cliente recebe o push de um cupom **uma única vez**.
* **Registro (`coupon_grants`):** quem recebeu, canal, enviado/entregue/falhou, se abriu a área de cupons e se resgatou.
* **Resultados:** criados, ativos/pausados/expirados/esgotados, distribuídos, usados, disponíveis, clientes alcançados, push enviados/entregues, aberturas,
  vendas com cupom, valor vendido, desconto concedido (e o desconto em moedas nos mesmos pedidos) e **conversão = alcançados que usaram ÷ alcançados**.

## Isolamento, histórico e auditoria
Toda rota da empresa filtra por `business_id` do dono logado; alterar/pausar/ler cupom de outra empresa devolve 404. O administrador age informando a empresa.
`coupon_changes` guarda criação, edição (com “de/para”), pausa/reativação, distribuição, resgate e estorno; ações de empresa e de administrador também vão para `audit_log` (`cupons.*`).
O cliente nunca vê números internos (usos, estoque, conversão).

## API
| Rota | Quem | Uso |
|---|---|---|
| `GET/POST /api/panel/coupons` | administrador | resumo geral (`?empresa=`), ações com `businessId` |
| `GET/POST /api/v2/businesses/:id/coupons` | dono da empresa | resumo e ações: `create`, `update`, `status`, `delete`, `preview`, `distribuir`, `detalhe` |
| `GET /api/v2/businesses/:id/coupons/public` | cliente | vitrine da loja (públicos e exclusivos autorizados) |
| `POST /api/v2/businesses/:id/coupons/validate` | cliente | desconto do cupom antes de finalizar |
| `GET /api/v2/coupons/mine` | cliente | cupons recebidos/da vitrine e histórico de uso |
| `POST /api/v2/businesses/:id/orders` | cliente | aceita `cupom` (código) junto de `moedas` |

## Limitações conhecidas
* Vale em **pedidos de produtos**; agendamentos de serviços ainda não aceitam cupom.
* “Interesses” do cliente são inferidos só pelo histórico de compras (segmento “quem comprou os produtos do cupom”); não há cadastro de interesses.
* A seleção de produtos participantes e a distribuição são feitas no ambiente da empresa; o painel do administrador mostra, cria, edita, pausa, exclui e audita, mas não envia distribuições.
* Push depende do plano de Marketing da empresa e do cliente ter autorizado; sem isso o cupom fica disponível só na área de cupons.
* O chat não cria, envia nem promete cupons (está registrado em Cérebro → Capacidades).
