# Correções: agenda, financeiro, endereço, imagens, nome do atendente e variações

Nenhuma migração de banco foi necessária (tudo usa as tabelas e campos JSON existentes), então os dados atuais ficam intactos.

## 1. Agendamento pelo chat → Agenda do dono (sem reservas duplicadas)
- Todo agendamento (chat do agente ou catálogo) cria um compromisso na **Agenda** do dono da empresa (`items`, tipo `appointment`), com serviço, cliente, data, hora, duração e ligação ao pedido. Código: `server/src/lib/business-sync.ts`.
- O horário fica bloqueado na hora: a verificação e a gravação ocorrem sob um **bloqueio por empresa** (`withLock`), então duas conversas simultâneas no mesmo horário resultam em uma reserva só (a outra recebe 409 / mensagem para escolher outro horário).
- Compromissos próprios do dono na Agenda também bloqueiam horários de serviço.
- Agendamento com Pix pendente segura o horário por 30 minutos e só entra na Agenda após o pagamento.
- Recusar/cancelar remove o item da Agenda e libera o horário; concluir marca como feito.

## 2. Endereço manual ou localização automática
- No cadastro e na edição da empresa: digitar o endereço **ou** usar “Usar a localização atual” (preenche o campo, que continua editável).
- `POST /api/v2/geocode` converte coordenadas em endereço e endereço em coordenadas. Ao salvar um endereço digitado, as coordenadas são buscadas automaticamente; se o serviço de mapas falhar, o endereço é salvo do mesmo jeito.
- Variável opcional `GEOCODER_URL` (padrão: OpenStreetMap Nominatim).

## 3. Pagamentos → Financeiro (sem duplicidade)
- Pagamento online (Mercado Pago) aprovado → uma entrada no Financeiro. Pagamento no balcão/Pix/cartão/dinheiro → uma entrada quando o pedido/serviço é **concluído**.
- Idempotente (`finItemId` no pedido + bloqueio por pedido): webhook repetido, consulta de status e conclusão não duplicam. Pagamento recusado não lança.
- Serviço → categoria “Serviços”; produto → “Vendas”.

## 4. Imagens do catálogo
- Corrigido o erro que fazia o salvamento falhar (`const` reatribuída). Mensagens de sucesso (“Produto salvo com sucesso (N fotos)”, “Logo e capa salvos com sucesso”).
- Imagens grandes agora geram erro claro em vez de serem descartadas em silêncio.

## 5. Nome padrão do atendente
- Padrão **Meu Assistente**; a empresa pode trocar na aba do agente. O nome antigo “Atendente” (padrão anterior) passa a exibir “Meu Assistente”.

## 6. Variações opcionais
- Campo rotulado “opcional”; vazio, ausente ou com linhas inválidas não gera erro. Corrigido “Assignment to constant variable.”.

## 7. Ajustes de interface (agente e página da empresa)
- **Ícone do WhatsApp:** agora é só o balão de conversa, sem o telefone dentro (catálogo e agente).
- **Agente dentro do catálogo:** removida a barra extra; um único cabeçalho no topo com a seta de voltar à esquerda da logo, o nome da empresa uma vez só e o nome do atendente embaixo. A janela acompanha a área visível, então o campo de digitar não fica escondido atrás do teclado.
- **Logo e capa:** sem campos/botões separados. Toque na capa ou na logo (ícone de câmera discreto, áreas de toque ≥ 44 px): a imagem é enviada e salva na hora, a prévia atualiza, e aparece “Capa/Logo atualizada com sucesso”. Se o salvamento falhar, a imagem anterior é mantida. “Remover capa” continua disponível.

## 8. Agendamento com sinal antecipado no chat
- Frase única, ex.: “agendar corte amanhã às 14h com João, o serviço custa R$ 100 e o cliente já pagou 50% de sinal”. O chat cria o compromisso na Agenda **e** lança o sinal como **entrada** no Financeiro (categoria Serviços), sem exigir dois comandos.
- Entende valor em R$, porcentagem (“50%”), “metade” e “pagou R$ 200 de sinal”. Calcula total, sinal recebido e **saldo pendente**, guardado como valor a receber: depois, “o cliente pagou o restante” quita sem duplicar.
- Se o total não for informado, registra o sinal e avisa que o saldo não foi calculado. Sinal “que vai pagar depois” só agenda (não lança receita). Repetir a mesma frase em poucos minutos não duplica nada.
- Código: `parseSinalAgendamento` (`ai/fin.ts`) e `appointmentWithDeposit` (`ai/finchat.ts`), reaproveitando o motor de recebimentos parciais já existente.

## 9. Tipo de catálogo: Produtos, Serviços ou Produtos e serviços
- Escolha no cadastro da empresa (já existia) e em **Ajustes → Tipo de catálogo**, alterável a qualquer momento. É o mesmo campo `tipo` do anúncio (sem tabelas novas).
- Respeitado em: cadastro/edição (só os tipos permitidos), página pública do catálogo, agente de atendimento (ferramentas e instruções), pedidos (recusa se for só serviços), horários e agendamentos (recusa se for só produtos) e Financeiro (venda → “Vendas”, serviço → “Serviços”).
- Mudar o tipo **nunca apaga** nada: itens do outro tipo ficam salvos, marcados como “oculto aos clientes” na lista, e reaparecem ao voltar para “Produtos e serviços”.
- Empresas antigas, sem escolha explícita, continuam com tudo liberado (equivale a “Produtos e serviços”) até escolherem.

## Limitações conhecidas
- Receita não é estornada automaticamente se um pedido já pago for cancelado depois (ajuste manual no Financeiro).
- Em serviços sob orçamento com sinal, só o sinal pago online é lançado; o restante deve ser lançado ao concluir manualmente.
- A localização automática depende do GPS/permissão do aparelho e do serviço de mapas (Nominatim tem limite de uso).

## Testes
`npm test` (155 testes) e os roteiros de navegador em `server/test/browser/` (`produtos_endereco.py`, `imagens_cabecalho_agente.py`, `tipo_catalogo_sinal.py`).


## 10. Atalhos rápidos do agente em lista vertical

Arquivo: `frontend/public/agente.html` (somente front-end; nenhuma mudança no atendimento automático, cabeçalho ou campo de digitação).

- Os atalhos viraram uma **lista vertical, alinhada à esquerda, logo acima do campo de digitação**: botões brancos arredondados, ícone e texto centralizados verticalmente, todos os ícones na mesma cor azul-marinho.
- Ordem: **Agendar um horário** → **Ver nossos serviços** → **Ver mais**. "Ver mais" expande, na vertical e com o mesmo alinhamento, os demais atalhos (Ver nossos produtos, Carrinho, Localização, Horário de funcionamento, Pagamento e entrega, WhatsApp) e vira "Ver menos" para recolher.
- Ações preservadas: serviços e produtos abrem o catálogo correspondente; "Agendar um horário" abre direto o agendamento quando a empresa tem um único serviço, ou a lista de serviços quando tem vários; os demais usam as mesmas funções de antes. Empresas só de produtos mostram "Ver nossos produtos" como atalho principal; sem catálogo, "Horário de funcionamento".
- **Comportamento:** só aparecem quando o usuário ainda não enviou mensagem. No primeiro envio somem todos (inclusive os expandidos) e não voltam durante a conversa; uma nova conversa vazia os mostra de novo. A lista tem altura máxima (38% da tela) com rolagem própria, preservando o espaço das mensagens.
- Os botões "Continuar escolhendo / Ver carrinho" dentro das mensagens continuam com o formato anterior.
- Testes: `server/test/browser/atalhos_agente.py` (39 verificações, celular e computador); `tema_catalogo_agente.py` atualizado para o novo formato.


## 11. Botões rápidos do Chat Principal no padrão do Agente

Arquivo: `frontend/public/modules-addon.js` (somente front-end; mensagens, painel e Agente intactos).

- Os botões rápidos do Chat Principal agora têm **o mesmo visual dos atalhos do Agente** (`#acts` em `agente.html`): lista vertical alinhada à esquerda, botão branco de 44 px com bordas arredondadas, sombra leve, ícone azul-marinho de 20 px, texto 15/500, espaçamento de 8 px e rolagem própria (máx. 38% da tela). O teste compara as propriedades de estilo calculadas dos dois ambientes (celular e computador).
- Continuam vindo do painel "Botões rápidos do chat": ligar/desligar, lista personalizada e ordem. Desligados, somem; ao alterar no painel, valem na próxima abertura/recarga do chat. A ação segue sendo a de antes: enviar o texto do botão (mecanismo de envio inalterado). Itens padrão ocultos no celular continuam ocultos.
- Limitação: o painel guarda só o texto de cada botão (não há ícone, descrição ou ação por botão), então todos usam o mesmo ícone de conversa. O Agente não foi alterado: seus atalhos vêm da empresa, não do painel; o estilo foi replicado por regras CSS no `modules-addon.js` (o teste garante a igualdade).
- Teste: `server/test/browser/botoes_rapidos_chat.py` (47 verificações).


## 12. Descrições expansíveis no catálogo

Arquivo: `frontend/public/modules-addon.js` (somente front-end; cadastro, dados, preços, imagens e carregamento do catálogo inalterados).

- Na página da empresa (`/x/empresa/:id`), a **descrição da empresa** mostra só **3 linhas** e cada **produto/serviço** mostra **2 linhas**, com leve esmaecimento no fim. Uma **seta discreta (16 px)** aparece apenas quando há mais texto; ao tocar, o texto expande com animação suave (0,28 s) e a seta gira; tocar de novo recolhe. Textos curtos não mostram seta.
- O texto cadastrado não é alterado nem cortado (antes a prévia do produto era cortada em 90 caracteres, sem como ler o resto na lista). A expansão é **independente por item** e o estado (aberto/fechado) é **preservado** ao trocar de categoria, buscar ou voltar à página. A medição refaz ao redimensionar a tela e respeita "reduzir movimento".
- A seta não abre o produto nem interfere em Agendar / + (carrinho) / abrir detalhes.
- Limitação: no layout em grade do catálogo não há descrição na lista (já era assim), então nada muda ali.
- Teste: `server/test/browser/descricoes_expansiveis.py` (29 verificações, celular e computador).


## 13. Botões rápidos do Chat Principal: só no início de cada conversa

Nenhuma alteração de código foi necessária: o Chat Principal já monta a tela de boas-vindas (com os botões) **somente quando a conversa aberta não tem mensagens**, então o estado é naturalmente **por conversa** (não há variável global). A primeira mensagem desmonta o bloco inteiro (sem espaço vazio); abrir uma conversa antiga pelo histórico não mostra botões; "Chat" (nova conversa) os traz de volta já com a configuração atual do painel (ligado/desligado, itens e ordem), reaplicando o visual padronizado do Agente (item 11).

- Teste que comprova o comportamento: `server/test/browser/botoes_rapidos_conversa.py` (24 verificações, celular e computador): novo chat com botões; oculto após a 1ª mensagem; continua oculto na continuação e ao recarregar; sem contêiner/altura residual; novo chat restaura; configuração do painel atualizada vale no chat novo; conversa antiga não mostra botões e não afeta o chat novo; painel desligado não mostra nada.
