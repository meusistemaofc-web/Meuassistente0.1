# Pedido organizado, textos de exemplo e topo sem desfoque (17/11)

## "Seu pedido" (checkout do catálogo) — `modules-addon.js` v=126
- **Itens:** ficam num cartão, com um × discreto para remover cada item.
- **Escolhas em botões compactos:** "Como receber", "Quando" e "Pagamento" viraram botões lado a lado, com o detalhe pequeno embaixo (grátis, taxa, chave da loja). O escolhido fica em destaque.
- **WhatsApp:** fica num campo só.
- **Mais opções:** cupom, MCoins e observação ficam num bloco que abre e fecha.
  - Ele vem recolhido quando a loja não tem cupons nem a pessoa tem MCoins.
  - Ele já vem aberto quando há cupom disponível, MCoins ou algo preenchido.
  - O estado aberto/fechado se mantém ao trocar as opções.
- **Ofertas:** a autorização de ofertas virou uma linha discreta.
- **Rodapé fixo:** total e "Enviar pedido · R$ total" ficam fixos embaixo, sempre visíveis. A linha "Produtos" só aparece quando há desconto ou taxa.
- **O que não mudou:** ids e regras (`#czap`, `#cobs`, `#cpcode`, `data-pg`, `data-mo`, `data-qd`, `#cgo` etc.), validações e o envio.

## Textos de exemplo (placeholder) em todo o sistema
- **Cor:** cinza com opacidade baixa (`rgba(142,142,150,.55)`; no tema claro `rgba(80,90,110,.45)`).
- **Também no iPhone:** a regra inclui `-webkit-text-fill-color`, porque é ele que deixava o "Ex.: …" branco dentro das janelas.
- **Onde vale:** no app inteiro (`modules-addon.js`) e nas páginas avulsas (agente, compromisso, memória, previsões, laboratório, execuções, agentes, offline). O campo do chat continua com o estilo próprio.

## Topo sem desfoque
- **O que é:** uma faixa sólida (`#ma-topo`) cobre a área da barra de status. Ela tem a cor do fundo da tela aberta, inclusive catálogos com tema claro, e não bloqueia toques. No iPhone, isso evita o efeito de desfoque do conteúdo que passa por baixo do topo.
- **Páginas avulsas:** recebem o mesmo efeito com `html::before`.
- **Validação:** o efeito do iOS não dá para simular aqui; confirmar no aparelho depois de publicar.

## Cadastro de produtos/serviços
- O grupo "Cadastro manual · ✨ Importar cardápio com IA · Histórico de importações" virou um retângulo com cantos levemente arredondados (18px), com os botões dentro (cantos de 12px) ocupando a largura (`menu-import-addon.js` v=3).

## Testes
- `checkout_organizado.py` 17/17, `importar_cardapio.py` 33/33, `composer_novo.py` 109/109;
- `cupons.py` 22/22, `moedas_bonus.py` 30/30, `mcoins_integradora.py` 21/21, `permissoes_agendamento.py` 42/42;
- `npm test` 294/294.
