# Leitura local de comprovantes (Central de Mídias → Financeiro)

Etapa 2 da Central de Processamento de Arquivos e Mídias. O usuário envia um comprovante (foto, print ou PDF) e a
central extrai os dados no próprio servidor, **sem IA**. O chat mostra o que foi lido para o usuário confirmar, e só
então o lançamento vai para o financeiro. Funciona com **todas as IAs desligadas** (modo "sem IA").

## Como funciona

```
foto/PDF ─► app (chat) ─► Central de Mídias (OCR Tesseract + regras, sem IA) ─► app monta o lançamento
                │                                                                 │
                │ central desligada/fora do ar                                    ├─ faltou valor/data/direção → pergunta, uma coisa por vez
                └─► caminho ANTIGO (IA com visão → texto/OCR.space → IA)          ├─ campos incertos → marcados "⚠️ revise"
                                                                                  └─ resumo + [Registrar] [É entrada/saída] [Cancelar]
```

Regras:

1. **A direção vem do texto do comprovante.** Exemplos: "Pix enviado", "você recebeu", "valor pago", seções Origem/Destino.
   - O nome do titular **nunca decide sozinho**. Ele só confirma a direção ou acusa conflito.
   - Se o texto diz "recebido" mas o titular aparece como pagador, a direção vira incerta e o usuário é perguntado.
   - Sem pista no texto, o nome do titular aparece apenas como sugestão na pergunta "entrou ou saiu?".
2. **Nada é registrado sem confirmação.** Responder "saiu"/"entrou" só troca a direção e mostra o resumo de novo. Só "sim, registrar" (o botão Registrar) grava.
3. **Campos com confiança média ou baixa** (conforme a central) aparecem com "⚠️ revise" e são listados em "Confira com atenção".
   - Uma data no futuro também é marcada, e nunca é trocada sozinha.
4. **Nada é inventado.**
   - Valor, data ou direção ausentes são perguntados.
   - Sem estabelecimento, aparece "não identificado" e a descrição fica genérica ("Pix enviado").
   - Sem categoria, fica "Outros (não identificada)". A categoria por palavra-chave aparece como "(sugerida — revise)".
   - Correções antes de confirmar: `valor 150,00`, `data 12/11`, `categoria alimentação`, `descrição Padaria do Zé`.
5. **Processamento local primeiro.** Se a leitura local estiver completa, nenhuma IA é chamada.
   - Se faltar algo e houver IA ligada, ela só completa os campos vazios. Esses campos entram marcados para revisão ("com complemento da IA").
   - Com o modo "sem IA", nenhuma IA nem o OCR.space é chamado.
6. **Não bloqueia o chat.** A leitura roda no job de chat do servidor, que já existia. Enquanto lê, a tela mostra o indicador "Lendo a foto". Outras requisições seguem normais (há teste com central lenta).
7. **Isolamento por usuário.**
   - O estado pendente fica no módulo do próprio usuário (`doc_pending`). Outro usuário que responda "sim" não registra nada.
   - A central recebe só o arquivo e um identificador interno (`u<id>`), nunca nome, e-mail ou titular.
   - Na central, cada arquivo é processado num diretório temporário próprio, apagado ao final (etapa 1).
8. **Integração antiga mantida como reserva.**
   - Sem `MIDIA_URL`/`MIDIA_TOKEN`, com a central parada ou recusando, tudo segue exatamente como antes.
   - Com a central fora e nenhuma IA ligada, o chat responde com uma mensagem amigável ("me diga o valor e o que foi") em vez do erro 503.
9. **Duplicados continuam bloqueados** (mesmo hash do arquivo).
10. **OCR.space e as demais integrações não foram removidos.**

### Política (Painel → IA → "Leitura de comprovantes")

| Opção | Comportamento |
|---|---|
| **Leitura local primeiro** (padrão) | Central → (se faltar algo e houver IA) a IA completa → caminho antigo só se a central estiver fora. |
| Somente leitura local | Nunca usa IA para comprovantes. O que faltar é perguntado ao usuário. |
| IA primeiro (como antes) | Caminho antigo. A leitura local entra só se a IA falhar. |

A caixa mostra o estado da central: "No ar", "Fora do ar" ou "Não instalada neste servidor". A política **não liga nem desliga** a central; isso depende do servidor.

## Melhorias na central (leitura de fotos)

- **Fotos tortas e de lado:**
  - endireita a inclinação de −6° a 6°;
  - corrige a perspectiva do papel;
  - detecta texto na vertical e testa 90° e 270°, ficando com a melhor leitura.
- **Tela escura** (tema escuro de bancos): a imagem é invertida antes do OCR.
- **Segunda leitura** (outro modo do Tesseract) quando não acha o valor ou quando a linha de "Total" vem sem número. Resolve, por exemplo, os preços em coluna nos cupons.
- **Linhas reconstruídas** pela posição das palavras, para manter "rótulo … valor" na mesma linha.
- **Correções de OCR** em valores (RS/R5 → R$; O/l/I → dígitos) e **confiança por campo**: valor, data, hora, tipo, direção, estabelecimento e categoria.
- Uma confiança baixa do OCR (< 0,75) rebaixa todos os campos para revisão.

## Testes (todos com IA desligada onde indicado)

| Suíte | Comando | O que prova |
|---|---|---|
| API completa | `cd server && npx tsx test/run.ts` | Novo teste com 14 cenários, IA desligada (detalhes abaixo), e a suíte inteira sem regressões |
| Central (Python) | `cd services/central-midia && python3 -m pytest -q tests` | Inclui 7 modelos de comprovante × foto / foto de lado / print, gerados com perspectiva, rotação, sombra, desfoque, ruído e JPEG; "nada inventado quando falta"; confiança por campo; regras de direção |
| Central real ↔ cliente | `cd server && npx tsx test/central-midia-e2e.ts` | Cliente do app falando com a central Python real |
| **Ponta a ponta no navegador** | `cd server && python3 test/browser/comprovante_sem_ia.py` | Central REAL + servidor + modo "sem IA" + **comprovantes fotografados** enviados pela tela do chat (detalhes abaixo) |
| Tipos | `cd server && npx tsc -p tsconfig.json --noEmit` | Sem erros |

**Cenários do novo teste da API (IA desligada):**
- confirmação antes de gravar, correção de valor e registro;
- duplicado bloqueado;
- perguntas de data, de valor e de entrada/saída;
- titular sozinho não decide, e conflito texto × titular gera pergunta;
- estabelecimento ausente, data futura e arquivo que não é comprovante;
- nenhuma chamada de IA nem de OCR.space;
- isolamento entre usuários e central lenta sem travar;
- central fora com IA desligada (mensagem amigável) e com IA ligada (caminho antigo);
- leitura completa sem IA e leitura parcial completada pela IA;
- painel e política "IA primeiro".

**Passos do teste no navegador:**
- foto torta de Pix → Registrar → saída no financeiro;
- cupom fotografado de lado;
- print de Pix recebido → entrada;
- foto sem data → "Ontem" → Registrar;
- foto sem direção → "Saiu" → Cancelar (nada gravado);
- duplicado bloqueado;
- painel;
- ao final, verifica no registro do servidor que nenhuma IA foi chamada.

As telas ficam em `/tmp/e2e/leitura_local_*.png`.

## Arquivos

**Novos:**

| Arquivo | Conteúdo |
|---|---|
| `server/src/ai/leitura-local.ts` | Converte o resultado da central em lançamento: direção (texto × titular), o que falta, o que revisar e a combinação com a IA |
| `server/src/routes/leitura-local.ts` | `GET/PUT /api/panel/leitura-local` (política + estado da central; só administradores) |
| `server/test/browser/comprovante_sem_ia.py` | Teste de ponta a ponta no navegador |
| `services/central-midia/tests/fotos.py` | Gerador de comprovantes "fotografados" para os testes |
| `docs/LEITURA_LOCAL_COMPROVANTES.md` | Este documento |

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/ai/docs.ts` | Nova `lerDocumento()` (local primeiro → IA completa → caminho antigo). `analyzeDocument`, `pdfText` e `ocrImage` (OCR.space) intactos |
| `server/src/ai/finchat.ts` | `documentReply` usa `lerDocumento`. Leitura local → novo fluxo de revisão/confirmação (`revisaoLocal`, `proximoPasso`, `continuarLocal`). Leitura por IA → fluxo antigo sem mudança. Sem central e sem IA → mensagem amigável |
| `server/src/routes/chat.ts` | Sem alteração (o aviso extra "🔎 Lendo o comprovante…" foi retirado; fica só o indicador "Lendo a foto" do chat) |
| `server/src/routes/panel.ts` | `requirePanel` exportada (sem mudança de regra) |
| `server/src/app.ts` | 2 rotas novas; `panel-addon.js?v=152` |
| `server/src/ai/capabilities.ts` | Capacidade "Leitura de comprovantes" cita a leitura local |
| `server/src/lib/central-midia.ts` | Só o comentário do topo |
| `frontend/public/panel-addon.js` | Caixa "Leitura de comprovantes" na aba IA |
| `server/test/run.ts` | Novo teste (14 cenários). O teste da central agora permite apenas os 2 arquivos da leitura local como usuários da central |
| `server/test/browser/README.md` | Linha do novo teste |
| `services/central-midia/app/comprovante.py` | Extração reescrita: rótulos, seções Origem/Destino, direção por pesos, confiança por campo, `faltando`/`revisar`, correções de OCR |
| `services/central-midia/app/processadores/imagem.py` | Endireitar, perspectiva, foto de lado, tema escuro, segunda leitura, linhas por posição |
| `services/central-midia/app/trabalhador.py` | Repassa a confiança do OCR para a extração |
| `services/central-midia/tests/test_central.py` | Testes de fotos, "nada inventado", confiança e direção |
| `deploy/scripts/central-midia.sh` | Só a mensagem final do `instalar` |
| `docs/CENTRAL_MIDIA.md` | Referências à etapa 2 |

**Sem alteração:**
- banco de dados: nenhuma migração;
- autenticação;
- regras do financeiro: o `save()` e as categorias são os mesmos;
- OCR.space, Gemini e demais integrações;
- `docker-compose.yml`, `update.sh` e `.env.example`.

## Ativação na VPS (quando você autorizar)

O código novo é seguro mesmo **sem** a central: sem `MIDIA_URL`/`MIDIA_TOKEN`, o app segue pelo caminho antigo.

1. Atualize como de costume (GitHub → VPS → `update.sh`). O app sobe com o código novo e continua igual.
2. Teste a central sem subir nada: `sudo bash deploy/scripts/central-midia.sh verificar` e depois `sudo bash deploy/scripts/central-midia.sh testar`.
3. Instale e suba **só** a central: `sudo bash deploy/scripts/central-midia.sh instalar`.
   - Isso grava `MIDIA_TOKEN`/`MIDIA_URL` no `.env`, guardando uma cópia do anterior.
4. Faça o app ler o `.env` novo: `docker compose up -d --no-deps app`.
5. Verifique:
   - `sudo bash deploy/scripts/central-midia.sh estado`;
   - no Painel → IA → "Leitura de comprovantes", deve aparecer **No ar**.
6. Teste real:
   - envie um comprovante pelo chat e confirme;
   - depois, em Painel → Cérebro e busca → "Modo das IAs", escolha "Sem IA (teste)" e envie outro;
   - deve aparecer "leitura local, sem IA".

### Reversão

- **Só voltar ao comportamento anterior, sem parar nada:** Painel → IA → "IA primeiro (como antes)".
- **Parar a central:** `sudo bash deploy/scripts/central-midia.sh desativar`. O app volta sozinho ao caminho antigo.
- **Remover:**
  - `sudo bash deploy/scripts/central-midia.sh remover`;
  - apague `MIDIA_TOKEN`/`MIDIA_URL` do `.env`;
  - rode `docker compose up -d --no-deps app`.
- Nenhum passo apaga dados.
