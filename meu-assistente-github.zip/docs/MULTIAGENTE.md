# Fase 4 — Arquitetura multiagente

> **Evoluída na Fase 10:** agentes especializados de domínio, validação, memória compartilhada, autonomia de 1 a 4 e a Central de Agentes. Ver `ARQUITETURA_MULTIAGENTE_COLABORATIVA.md`. Tudo o que está descrito abaixo continua valendo.

O Núcleo de Inteligência Central (Nível 1, Nível 2 e Fase 3) ganhou um **coordenador central** que, só quando o pedido é complexo, mobiliza **agentes internos** que colaboram na mesma solicitação. O usuário continua conversando com **um único assistente**: os agentes produzem contribuições internas, e a IA principal (que também é quem executa as ações com as ferramentas) consolida tudo numa resposta só.

Código: `server/src/ai/agentes.ts`. A integração fica em `ai/assistant.ts`, com o leitor `lerDados`, a coordenação antes da IA principal e a unificação depois. A configuração e os indicadores ficam em `routes/inteligencia.ts`, e o painel em `panel-addon.js`. Não há migração nova.

## O que foi reaproveitado e o que foi criado
| Papel pedido | Como ficou | Situação |
|---|---|---|
| Coordenador central | `orquestrar()`: interpreta (análise do Nível 1), mede a complexidade, seleciona agentes, distribui em ondas, compartilha o quadro, detecta divergências e entrega o contexto de consolidação | **Criado** |
| Pesquisa e investigação | Agente da 1ª onda; usa a rota de pesquisa com busca **que já existia** no motor | Criado sobre o existente |
| Análise e raciocínio | Agente da 2ª onda; usa a rota de tarefa "analise" do motor, escolhida pelo administrador no roteador de IA | Criado sobre o existente |
| Escrita e comunicação | Agente da 2ª onda | Criado |
| Vendas e negócios | Agente da 2ª onda; recebe o contexto comercial **existente** (`commercial.ts`) e os dados de negócio/CRM | Criado sobre o existente |
| Planejamento e organização | Agente da 2ª onda para planos estratégicos. O **planejador de ações** do Nível 2 continua cuidando das etapas com ferramentas | Criado + reaproveitado |
| Execução de tarefas | A IA principal com as ferramentas autorizadas. É a **única que grava**, sempre com as confirmações existentes; os agentes só **leem** (`lerDados` recusa ferramentas de escrita) | Reaproveitado |
| Auditoria e verificação | A conferência do Nível 1 e a autoverificação do Nível 2 (que agora também conferem os números das contribuições), mais a detecção de divergências entre agentes e de resposta fragmentada | Reaproveitado + ampliado |
| Especialistas de domínio | Os do Nível 2 (agenda, finanças, CRM…) definem que dados os agentes recebem | Reaproveitado |

## Como uma mensagem passa pelo coordenador
```
Análise (Nível 1) → especialistas de domínio + plano (Nível 2) → COORDENADOR
  complexidade: simples | moderada | complexa   (só "complexa" mobiliza agentes; no máximo N, padrão 3)
  1ª onda (paralelo): Pesquisa           + leitura dos dados do usuário (somente leitura, só ferramentas que ele já tem)
  2ª onda (paralelo): Análise · Vendas · Planejamento · Escrita   ← recebem as contribuições da 1ª onda
  divergências entre contribuições (valores diferentes para a mesma coisa; recomendações opostas) → enviadas ao coordenador
IA PRINCIPAL: consolida numa resposta única e executa as ações com as ferramentas
Auditoria: Nível 1 + Nível 2 + unificação (remove qualquer menção a agentes internos)
```

## Regras de cada requisito
- **Seleção inteligente:** mensagens simples e moderadas, que são a maioria, não fazem nenhuma chamada extra (testado). Um pedido é complexo quando pede duas ou mais competências, como pesquisar e comparar, ou analisar e montar uma estratégia de vendas, ou quando soma vários sinais de complexidade. Agentes desligados ou pausados ficam de fora.
- **Colaboração:** a 2ª onda recebe as contribuições da 1ª. Valores divergentes ("faturamento R$ 10.000 × R$ 12.000") e recomendações opostas ("vale a pena × não vale a pena") são detectados e entregues ao coordenador com a instrução de resolver, preferindo os dados das ferramentas.
- **Resposta unificada:** a IA principal é instruída a não mencionar o processo. Mesmo assim, a auditoria remove frases como "segundo o especialista interno…" ou "o agente de vendas sugere…" e registra a correção.
- **Memória compartilhada com acesso controlado:** cada agente vê só a sua fatia do quadro.

  | Agente | O que vê |
  |---|---|
  | Pesquisa | Só o pedido, já sem e-mails, telefones, CPF e cartões. Nunca vê memórias nem dados |
  | Análise e Vendas | Os dados do próprio usuário |
  | Escrita | Memórias e contribuições, sem os dados financeiros |

  Os dados vêm só das ferramentas que o usuário já pode usar (permissões preservadas). Testes garantem que dados de um usuário nunca chegam ao quadro de outro.
- **Controle de qualidade e limites:**
  - Os agentes usam no máximo cerca de 35% do prazo da mensagem, com um teto configurável (padrão 9 s).
  - Cada agente tem o próprio prazo; o lento é cortado e a resposta sai com o que existe.
  - Um erro num agente não derruba a resposta.
  - Um **disjuntor** pausa por 10 minutos o agente que falhar 3 vezes.
  - Sem tempo suficiente, a mensagem segue sem agentes.
  - Os números das contribuições passam pela autoverificação.

## Painel
Em **Cérebro e busca → Inteligência avançada → Coordenação multiagente** ficam:
- a chave geral e uma chave por agente;
- o máximo de agentes por mensagem (1 a 5) e o tempo máximo (4 a 15 s pelo painel, 2 a 20 s pela API);
- por agente: acionamentos, taxa de sucesso, tempo médio, falhas e se está pausado;
- a distribuição simples/moderada/complexa, a taxa de mensagens com agentes, as divergências tratadas e as respostas unificadas;
- as etapas do fluxo que já existiam (execução, auditoria, planejador).

A rota é `PUT /api/panel/inteligencia/multiagente`: exige `panel.manage`, valida os valores e registra na auditoria como `inteligencia.multiagente`. A capacidade `multiagente` aparece no catálogo do Cérebro.

## Testes
| Tipo | O que cobre |
|---|---|
| Individuais | Seleção, máximo e chaves; fatia do quadro de cada agente; pesquisa sem dados pessoais; agentes não gravam |
| Colaboração | A 2ª onda recebe a 1ª; consolidação na IA principal; divergências; unificação |
| Limites e falhas | Agente lento cortado; erro isolado; disjuntor; falta de tempo |
| Desempenho | Mensagens comuns sem chamada extra; agentes em paralelo (tempo total próximo ao do mais lento, não a soma) |
| Isolamento | Entre usuários |
| Painel | Validação, indicadores, auditoria; desligado volta à Fase 3 |
| Diagnóstico | 12 casos de coordenação no corpus da Fase 3 (o diagnóstico contínuo também vigia o coordenador) |
| Navegador | Quadro do painel e resposta única no chat |

## Reversão
- No painel: a chave geral desliga tudo, e o assistente volta exatamente à Fase 3, sem nenhuma chamada de agente (testado). Cada agente também pode ser desligado sozinho.
- No código: retirar as chamadas a `agentes.js` em `assistant.ts`. Não há tabela nova.

## Limites (honestos)
- Cada agente acionado é uma chamada extra de IA. Elas rodam em paralelo e dentro do prazo, mas custam tokens; por isso só pedidos complexos as usam.
- A pesquisa na web depende de uma IA com busca configurada. Sem ela, o agente avisa que não pôde pesquisar e a resposta não inventa fatos atuais.
- A seleção é feita por regras sobre o português. Pedidos complexos escritos de forma muito incomum podem ser tratados como moderados e respondidos só pela IA principal, como antes.
- Os testes usam IA simulada. A qualidade real das contribuições depende dos modelos configurados.
