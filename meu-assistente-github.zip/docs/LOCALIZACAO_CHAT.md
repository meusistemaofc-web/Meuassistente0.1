# Localização ⇄ chat: empresas próximas direto na conversa

## Fluxo
1. **O usuário pede empresas próximas** (ex.: "pizzaria"). A resposta vem de `respostaEmpresas` (`server/src/routes/businesses.ts`), que é a mesma usada em toda atualização:
   - **sem localização válida:** "preciso da sua localização" + o botão **"Permitir localização e ver empresas"** (`⟦loc:…⟧`);
   - **com localização:** os cards direto (`⟦emp:ids⟧⟦q:consulta⟧`) ou "nenhuma empresa" com opções (`⟦locopt:consulta|próximo raio⟧`).
2. **O botão abre a tela própria de localização**, com as duas alternativas: "Permitir localização" (GPS) ou digitar o bairro ou a cidade e tocar em "Usar". Antes de navegar, o app guarda de qual conversa e de qual mensagem o usuário veio.
3. **A localização é obtida**, por GPS ou digitada. Então:
   - o servidor refaz a busca e **reescreve a mesma mensagem** (`POST /api/v2/chat/empresas`);
   - o app **volta sozinho para a conversa**, onde o botão é substituído pelos cards.
   - Não há nova pergunta, recarga manual, mensagem duplicada nem componente antigo.
4. **Persistência:** a mensagem fica gravada já resolvida no banco, então recarregar ou reabrir a conversa mostra o resultado.

## Estados (atributo `data-loc-estado` no chat)
| Estado | Quando |
|---|---|
| `aguardando_autorizacao` | Ainda sem localização: aparece o botão |
| `pesquisando` | O servidor está refazendo a busca |
| `empresas_encontradas` | Cards das empresas |
| `nenhuma_empresa` | "Não encontrei empresas disponíveis…", com "Ampliar o raio para X km" (quando o limite do admin permite) e "Informar outra cidade". O botão de autorização não volta a aparecer |
| `negada` | O usuário negou a permissão: avisa e mostra um campo de bairro ou cidade no próprio chat. O chat continua funcionando |

"Localização autorizada" e "localização informada manualmente" são o estado da localização no servidor: `localizacao.manual` na resposta do endpoint.

## Uma fonte só: chat e "Empresas parceiras"
- **Mesma busca:** o chat e a página usam `searchBusinesses`, com o mesmo raio (o menor entre o do usuário, o limite do admin e o raio da empresa) e a mesma cidade ou localização.
- **Regras de publicação:** só entram anúncios `ativo` dentro da validade. Proposta não aprovada, empresa suspensa ou revogada e anúncio vencido não aparecem.
- **Cards do chat:** são o mesmo `bizCard` da página. Mostram logo ou iniciais, nome, descrição, distância, categoria, situação (Aberto ou Fechado, quando há horário), "Patrocinado" e os botões do plano:
  - catálogo ou pedido;
  - página;
  - WhatsApp;
  - Instagram;
  - **Conversar** (novo, só quando o agente da empresa está ativo: pago, no prazo e com o módulo ligado);
  - os dados vêm sempre do cadastro atual (`/api/v2/businesses/cards`).
- **Mudanças de raio ou cidade:** feitas na página, nas opções do chat ou na tela de localização, atualizam as respostas da conversa aberta ao voltar para ela (`refazer`). A consulta original fica guardada no próprio texto (`⟦q:…⟧`).

## Segurança
- **Isolamento:** o endpoint só lê e reescreve mensagens da conversa do próprio usuário; conversa alheia dá `404`.
- **Escopo da reescrita:** só respostas de busca de empresas (`⟦loc⟧`, `⟦locopt⟧` ou `⟦emp⟧` com `⟦q⟧`). Nenhuma outra mensagem é alterada.

## Correções incluídas
- **Geocodificação:** a localização digitada (`PUT /api/v2/me/location`) agora usa o mesmo geocodificador do restante do sistema (`lib/geocode.ts`, configurável por `GEOCODER_URL`), em vez de uma chamada duplicada.
- **Texto da resposta:** "perto de você" com GPS, ou "perto de <bairro/cidade>" quando digitado.

## Testes
- **Servidor** (`test/run.ts`, "Localização ⇄ chat"):
  - **pedido e resolução:** pedido de localização, isolamento (404), resolução que reescreve a mesma mensagem, idempotência, a mesma fonte da página e a reabertura via `/api/chat`;
  - **mudanças:** resposta direta com localização, refazer (longe dá "nenhuma empresa" com opção de raio; perto de novo mostra as empresas) e empresa revogada que some;
  - **acesso:** sem login (401).
- **Tela** (`test/browser/localizacao_chat.py`, 24 verificações): os 10 cenários pedidos, mais regras de publicação, padrão do card, ações por plano, persistência e isolamento.
  - **Geocodificador de teste:** precisa do servidor iniciado com `GEOCODER_URL` apontando para `test/browser/geocoder_fake.py`, porque a rede externa é bloqueada no ambiente de teste. Exemplo: `python3 test/browser/geocoder_fake.py 4399 & GEOCODER_URL=http://127.0.0.1:4399 …`.

## Como reverter
1. **Frontend** (`modules-addon.js`): restaurar as funções `loc*`, a linha do interceptador de links `/x/`, os tokens `locopt`/`q` no `TOK`, os ramos `loc`/`locopt`/`q`/`emp` do `enhanceChat` e as chamadas `locMudou`/`locDepois` na tela de localização. Voltar `?v=107` para `?v=106`.
2. **Servidor:**
   - em `routes/businesses.ts`, remover `respostaEmpresas`, `chatEmpresasPost`, `comAgente` e `locInfo`;
   - em `app.ts`, remover a rota `/api/v2/chat/empresas`;
   - em `intents.ts`, voltar o trecho "empresas perto do usuário".

Mensagens já reescritas continuam válidas, porque são textos com os mesmos códigos de cards.
