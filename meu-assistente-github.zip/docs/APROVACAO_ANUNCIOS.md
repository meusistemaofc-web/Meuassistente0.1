# Modo de aprovação de anúncios (manual ou automático)

## Onde fica
Administração › **Anúncios** › seção **"Modo de aprovação de anúncios"**, com o texto "Escolha como os anúncios enviados pelas empresas serão aprovados antes da publicação."

A seção tem:
- **Seletor:** Aprovação manual × Aprovação automática, com a modalidade ativa marcada ("Modalidade ativa: …").
- **Confirmação:** ao escolher a outra modalidade, aparece um quadro explicando o efeito, com "Confirmar alteração" e "Cancelar". Nada muda sem confirmar.
- **Última alteração:** quem alterou, quando e qual modalidade.
- **Origem em cada anúncio:** "Aprovado manualmente pelo administrador", "Aprovado automaticamente", "Publicado pelo administrador" ou "Validação automática não passou: … — aprovar manualmente".

## Como funciona (fluxo único)
O fluxo é o mesmo de antes: anúncio → Pix → pagamento confirmado → `paidSendReview` → publicação por `activate`. Não há um segundo fluxo de aprovação.

- **Manual (padrão):** depois do pagamento, o anúncio fica **pendente** (`analise`, "Pago · aprovar"). Ele só é publicado quando o administrador aprova, e o administrador também pode pedir ajustes ou reprovar. Enquanto está pendente, não aparece nas buscas nem nos cards de empresas parceiras, que só listam anúncios no ar.
- **Automático:** depois do pagamento, o servidor roda as validações (`lib/aprovacao-anuncios.ts`):
  1. plano válido;
  2. dados obrigatórios;
  3. contato exigido pelo plano;
  4. pagamento confirmado pela API do Mercado Pago;
  5. modalidade do catálogo definida;
  6. link seguro (https);
  7. conta do dono ativa;
  8. sem suspensão anterior;
  9. dono sem anúncio reprovado.

  Se todas passam, o anúncio é publicado na hora, com o registro `aprovacao = { origem: 'automatica', em, validacoes }` e auditoria `ads.approve.auto`. Se alguma falha, ele **não** é publicado: vai para a análise manual, com o motivo visível para o administrador.

## Regras garantidas
- **Só novos envios:** o modo é gravado no anúncio no momento do envio (`modoAprovacao`). Trocar o modo depois não aprova, não reprova nem suspende nada:
  - aprovados continuam aprovados;
  - pendentes continuam pendentes, mesmo que paguem depois de o administrador ativar o automático;
  - reprovados e suspensos continuam como estão.
- **Origem registrada:** em cada anúncio fica `manual` (com quem aprovou), `automatica` (com as validações) ou `administrador` (publicado pelo próprio administrador).
- **Permissões:**
  - só administradores com a permissão `ads.manage` leem ou alteram o modo (`GET/PUT /api/v2/admin/ads-approval`); usuário comum recebe 403 e anônimo, 401;
  - a troca exige `confirmar: true` no servidor (sem isso, 409);
  - quem alterou, quando e o modo escolhido ficam salvos na configuração (com histórico) e na auditoria (`ads.modo_aprovacao`).
- **Botão "Sua empresa":** continua usando a mesma regra do servidor (`/api/v2/ads/painel`). No manual, aparece só depois da aprovação do administrador. No automático, aparece quando a publicação automática é confirmada pelo servidor. Anúncio pendente, reprovado ou suspenso não libera. O botão atualiza sozinho (em até 30 s), sem precisar entrar de novo.

## Testes
- **Servidor** (`test/run.ts`, "Modo de aprovação de anúncios"), com o Pix simulado de verdade (Pix e webhook):
  - **padrão e permissões:** modo manual por padrão; usuário comum e anônimo bloqueados; modo inválido recusado.
  - **modo manual:** pendente, fora da busca e sem botão; depois o admin aprova (origem manual).
  - **troca de modo:** sem confirmação é recusada; com confirmação fica registrada e auditada.
  - **anúncios já existentes:** aprovado, pendente, reprovado e suspenso não mudam; o enviado no manual e pago depois da troca continua pendente.
  - **modo automático:** publica e libera o botão (origem automática, com validações e auditoria); se uma validação falha, vai para análise manual.
  - **volta ao manual:** nada muda nos anúncios existentes.
- **Tela** (`test/browser/aprovacao_anuncios.py`, 17 verificações): os 8 cenários pedidos pela tela real do painel, incluindo confirmar e cancelar, o botão "Sua empresa" surgindo sozinho e a seção no celular. Precisa do servidor com `MP_API_BASE` apontando para `test/browser/mp_fake.py`.

## Como reverter
1. Remover `lib/aprovacao-anuncios.ts`.
2. Em `routes/ads.ts`, remover o bloco `modoAprovacao === 'automatico'` de `paidSendReview`, o parâmetro `aprovacao` de `activate` e as rotas `adsApproval*`; em `app.ts`, remover as duas rotas.
3. Remover a seção `apSec`/`apBind`/`apOrigem` de `panel-addon.js` e voltar `?v=146` para `?v=145`.

Os campos gravados nos anúncios (`modoAprovacao` e `aprovacao`) são inofensivos e podem ficar.
