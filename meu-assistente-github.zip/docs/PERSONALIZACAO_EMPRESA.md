# Personalização da empresa: Agente de Atendimento e Página de Links

Painéis para o dono da empresa escolher o que os clientes veem no atendimento virtual e na Página de Links.
Reaproveita as telas que já existem em **Sua empresa** (Agente de atendimento e Página de Links), sem mudar o layout geral.

## 1. Personalizar Agente de Atendimento

**Onde:** Sua empresa → Ajustes → Agente de atendimento → "Personalizar Agente de Atendimento".

- Tem um interruptor para cada botão: **Agendar um horário**, **Ver nossos serviços**, **Localização**, **Horário de funcionamento**, **Pagamento e entrega** e **WhatsApp**.
- **Salva na hora**, sem botão Salvar. A alteração é gravada no banco, em `businesses.data.agenteOpcoes` (separado da configuração do agente).
- Ao lado fica a **prévia real do atendimento** (o próprio chat da empresa, que só o dono vê enquanto não estiver no ar). Ela recarrega a cada alteração.
- A página pública do agente esconde os botões desligados.
- **O agente respeita a escolha ao responder.** Ele recebe a instrução de não sugerir nem listar as opções ocultas. Com o WhatsApp oculto, ele deixa de oferecer o WhatsApp.
- **O recurso não é desativado.** Se o cliente perguntar diretamente ("onde fica?", "que horas abre?", "quero agendar"), o agente responde normalmente: mapa, horário, agendamento, pagamento.
- **Itens que continuam como estão (obrigatórios):**
  - Ver nossos produtos;
  - Carrinho;
  - Ver mais / Ver menos;
  - fluxo de pedido, Pix e agendamento.
- **Regras do plano mantidas.** Ligar um botão nunca libera o que o plano não permite. Por exemplo, Agendar e Serviços só aparecem com serviços no catálogo do anúncio completo.
- O interruptor geral "Mostrar botões rápidos no chat" continua valendo. Desligado, nenhum botão aparece, e a seção avisa isso.

## 2. Personalizar Página de Links

**Onde:** Sua empresa → Ajustes → Página de Links → "Personalizar Página de Links".

- **Interruptores de exibição:** imagem de capa, logotipo, título da empresa, descrição e botões (todos).
- **Cada botão tem o próprio interruptor**, inclusive Catálogo e Agente de Atendimento.
  - Os botões do sistema podem ser **ocultados**, mas nunca excluídos: continuam na configuração.
  - Ocultar o botão Catálogo **não desliga o catálogo**, que segue abrindo pelo endereço normal.
- **Posição do logotipo:** à esquerda (padrão, igual ao layout atual), centralizado em cima ou à direita.
- **Tamanho do logotipo:**
  - de 48 a 120 px, padrão 64 px;
  - sempre quadrado, sem distorcer;
  - no celular, nunca passa de 30% da largura da tela (40% quando centralizado).
- Usa o fluxo que já existia: **prévia em tempo real antes de publicar** → Publicar. A página pública só muda depois de publicar.
- **Ocultar não apaga nada:** capa, logotipo, descrição e botões continuam salvos para quando você ligar de novo.
- **Páginas publicadas antes desta versão** continuam iguais (tudo visível, logotipo à esquerda, 64 px) e não aparecem como "alterações não publicadas".

## Segurança e regras

- Só o **dono da empresa** altera, pela regra `ownBusiness` que já existia. Outra pessoa recebe 404, e quem não está logado recebe 401.
- Cada empresa tem a própria configuração. Os testes conferem que nada vaza entre empresas.
- O servidor valida tudo:
  - opção desconhecida ou valor não booleano é recusado;
  - posição inválida volta ao padrão;
  - tamanho fora da faixa é limitado.
- A Página de Links continua exclusiva do anúncio completo. O agente continua dependendo da contratação.
- Sem migração de banco: os dados ficam no JSON da empresa (`businesses.data`) e na tabela `link_pages`, que já existiam.

## Arquivos

| Arquivo | Mudança |
|---|---|
| `server/src/routes/businesses.ts` | `AG_OPCOES`, `agentOpcoes`, `agentOpcoesPut` (PUT `/api/v2/ads/:id/agent/opcoes`); `opcoes` nas respostas do agente; instrução ao agente sobre opções ocultas; WhatsApp só é oferecido se estiver visível |
| `server/src/app.ts` | Rota nova; `modules-addon.js?v=133` |
| `server/src/lib/linkpage.ts` | `exibir`, `logoPos`, `logoTam` (padrão, validação e montagem); botões do sistema podem ser ocultados |
| `server/src/routes/linkpage.ts` | Página publicada antes da mudança não aparece como pendente |
| `frontend/public/agente.html` | Botões rápidos respeitam as opções (o resto do chat fica igual) |
| `frontend/public/links.html` | Exibição dos elementos, posição e tamanho do logotipo (proporcional no celular) |
| `frontend/public/modules-addon.js` | Seções "Personalizar Agente de Atendimento" (com prévia) e "Personalizar Página de Links"; interruptor em todos os botões da página |
| `server/test/run.ts` | 2 testes novos; o teste antigo agora espera que os botões do sistema possam ser ocultados (e continua garantindo que não são excluídos) |
| `server/test/browser/personalizacao.py`, `server/test/browser/README.md` | Teste de navegador novo |

## Publicação

1. Suba no GitHub.
2. Na VPS, rode o `update.sh` de sempre. Não há migração nem variável nova.
