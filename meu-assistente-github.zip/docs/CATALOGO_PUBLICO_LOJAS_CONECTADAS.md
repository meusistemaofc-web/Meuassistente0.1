# Catálogo público, mensagem pronta e Lojas Conectadas

## 1. Catálogo público (sem conta)
- **Sem login:** o visitante abre `/x/empresa/:id` e navega normalmente. Ele vê:
  - produtos, serviços, imagens, descrições, preços e categorias;
  - busca e detalhes;
  - variações e ofertas;
  - horários disponíveis.

  Ele também pode montar o carrinho ou escolher dia e horário.
- **Correção técnica:** antes, qualquer resposta "não autorizado" de uma chamada de fundo levava o visitante para `/entrar`. O catálogo público agora fica fora desse redirecionamento, tanto no app quanto nas telas da loja.
- **Servidor:** as rotas de leitura da loja já eram públicas (verificado em teste). Criar pedido ou agendamento continua exigindo conta (401 sem login).

## 2. Entrar só na hora de finalizar
- **Quando aparece:** ao tocar em **Enviar pedido** ou **Confirmar agendamento** sem estar logado.
- **O que aparece:** **"Falta só entrar para finalizar"** (ou "para agendar"), com:
  - **Entrar na minha conta**;
  - **Criar minha conta gratuitamente**;
  - "Continuar olhando".
- **O que fica guardado:**
  - carrinho com variações, opções, observações e quantidades;
  - dia, horário e observação do agendamento.

  Elas ficam guardadas **neste aparelho**.
- **Depois de entrar ou criar a conta:** o visitante volta **direto à etapa de finalização** (`?retomar=checkout` / `?retomar=agendar`), com tudo preenchido. Testado nos dois caminhos.

## 3. Mensagem pronta (por empresa)
**Onde fica:** Sua empresa → Ajustes → **Mensagem pronta**.

**O que dá para configurar:**
- **Mostrar no catálogo** (ativar/desativar; começa desativada);
- **texto do botão** (até 40 caracteres);
- **mensagem** (até 700 caracteres), com contador.

**Variáveis** (tocar insere no ponto do cursor):

| Variável | Conteúdo |
|---|---|
| `{produto}` | Nome do produto ou serviço |
| `{preco}` | Preço (o de oferta, quando houver) |
| `{empresa}` | Nome da empresa |
| `{link}` | Link do catálogo |
| `{cliente}` | Primeiro nome de quem está logado |

**Trechos opcionais:** um trecho entre `[colchetes]` some quando falta a informação. Exemplo: `[Tenho interesse em {produto} ({preco}). ]` some no botão geral do catálogo e para o visitante sem conta. Assim o texto fica natural.

**Prévia ao vivo:** mostra a mensagem do botão geral, a mensagem com produto e o botão.

**Restaurar mensagem padrão:** volta o texto e o botão originais.

**No catálogo:**
- o botão aparece no topo da loja e no detalhe de cada produto/serviço;
- abre o **WhatsApp da empresa** com a mensagem já escrita. O visitante só confirma o envio; nada é enviado sozinho;
- só aparece quando a função está ativa **e** a empresa tem WhatsApp.

**Validação no servidor:** campos obrigatórios, limites e variáveis desconhecidas (ex.: `{nome}` → "Variável desconhecida"). Cada empresa tem a sua configuração.

## 4. Lojas Conectadas (uma conta, várias lojas)
**Onde fica:** **Sua empresa → Ajustes → Lojas Conectadas** (ou `/x/lojas-conectadas`). A área tem quatro abas: **Visão geral · Pedidos e agendamentos · Avisos · Conexões**.

**Lojas próprias:** se a conta já é dona de mais de uma loja, todas aparecem na central automaticamente (como **Proprietário**), sem chave.

### 4.1 Chave de conexão
1. **Gerar a chave:** a conta central gera a chave em **Conexões → Gerar chave de conexão**:
   - validade: 1 h, 24 h, 3 dias, 7 dias ou 30 dias;
   - usos: 1 a 10;
   - formato: `MA-XXXX-XXXX-XXXX-XXXX`, com botões **Copiar** e **Compartilhar**.
2. **Segurança da chave:**
   - é **mostrada uma única vez**; o banco guarda só o **SHA-256** e o início, para identificar;
   - a lista mostra cada chave como válida, usada, expirada ou revogada, com opção de **revogar**;
   - no máximo 10 chaves válidas ao mesmo tempo;
   - o uso é **atômico**: a última vaga não é usada duas vezes;
   - 5 chaves erradas em 15 minutos bloqueiam novas tentativas.
3. **Usar a chave:** o **proprietário da outra loja** digita a chave em **"Recebi uma chave"**, escolhe a loja e o **nível de acesso** que a central terá:
   - **Operador:** vê e avança pedidos e agendamentos;
   - **Administrador:** também recusa, cancela e responde solicitações.
4. **Aprovar:** a central recebe o aviso e **aceita ou recusa**. Os dois lados autorizam.
5. **Depois de conectada:**
   - qualquer um dos lados pode **desvincular**;
   - o dono pode **mudar o nível** a qualquer momento;
   - cada conexão mostra o **histórico** (solicitada, aceita, nível alterado, desvinculada).
6. **Regras:**
   - só o **proprietário** da loja conecta (outra pessoa recebe 403);
   - quem não tem loja com painel liberado não usa o recurso;
   - não dá para usar a própria chave nem conectar a mesma loja duas vezes (índice único).

### 4.2 Central (Visão geral)
- **Totais:** pedidos pendentes, agendamentos pendentes, pedidos recebidos e agendamentos.
- **Cartão de cada loja:**
  - nome, logo, número e nível (Proprietário/Administrador/Operador);
  - situação ("No ar · aberta agora", "fechada agora", "Anúncio vencido", "Fora do ar");
  - pedidos, agendamentos e pendentes;
  - 3 avisos recentes e quantos são novos.
- **Botões do cartão:**
  - **Abrir:** pedidos daquela loja;
  - **Gerenciar loja:** painel completo, só nas lojas próprias;
  - **Catálogo:** a vitrine pública da loja.
- **Atualização:** a cada 60 s e ao voltar para a tela. Alternar entre lojas não exige sair nem entrar de novo.

### 4.3 Pedidos e agendamentos centralizados
- **Lista:** tudo de todas as lojas (ou de uma), com filtros: em aberto, pendentes, todos; pedidos ou agendamentos.
- **Cada item mostra a loja de origem.**
- **Ações conforme o nível:**
  - aceitar, preparar, concluir…;
  - recusar e cancelar só para proprietário e administrador (o servidor também bloqueia o operador).
- **A mudança vale na loja de origem,** pelo mesmo caminho do painel da loja (mesmas regras de cupom, estoque, avisos ao cliente e e-mail). O registro mostra quem alterou ("Ana (operador, Lojas Conectadas)").

### 4.4 Avisos centralizados
- **Loja no título:** cada aviso de pedido ou agendamento traz a loja de origem, ex.: "Novo pedido #12 · R$ 44,00 — Mercadinho do Beto". O nome aparece para quem acompanha mais de uma loja.
- **Quem recebe:** o dono recebe como sempre, e as centrais conectadas recebem uma cópia. São **uma por evento**: a referência é única por usuário e evento, então **não há duplicados**.
- **Atualizações** (aceito, cancelado, novo horário…): vão para o dono e para as centrais, **menos para quem fez a mudança**.
- **Tocar no aviso:** abre o **registro na loja de origem**, destacado.
- **Aba Avisos:** histórico, contador de não lidas, "marcar como lida" (uma, por loja ou todas) e filtro por loja.
- **Configuração por loja:** liga e desliga Novos pedidos, Agendamentos e solicitações, e Atualizações e cancelamentos.
- **Tempo real:** os avisos usam a central de notificações, o push e o e-mail que já existem (onde o aparelho permite push).

### 4.5 Segurança e independência
- **Só gerenciamento:** a conexão é uma **camada de acesso e de avisos**. Nada é copiado, misturado nem transferido. Cada loja segue com o próprio:
  - dono e cadastro;
  - catálogo, endereço e visual;
  - configurações e canais;
  - produtos e serviços;
  - clientes, pedidos e agendamentos.
- **A posse nunca muda.** A central não altera configurações, produtos nem o cadastro de lojas que não são dela.
- **Desvincular:** só tira o acesso da central. Testado: pedidos, agendamentos e dados continuam intactos e nada é cancelado.
- **Lojas que não usam o recurso:** funcionam exatamente como antes.
- **Registro:**
  - `store_link_events`: histórico da conexão;
  - `audit_log`: `lojas.chave.criar/revogar`, `lojas.conexao.solicitar/aceitar/recusar/desvincular/papel`, `lojas.notificacoes.preferencias`, `empresa.mensagem_pronta`.

## Banco: migração `048_lojas_conectadas.sql` (só aditiva)
| Tabela/coluna | Conteúdo |
|---|---|
| `store_link_keys` | Chaves (hash, validade, usos, revogação) |
| `store_links` | Conexões (central, loja, dono no momento, nível, situação); índice único para uma conexão aberta por par |
| `store_link_events` | Histórico de cada conexão |
| `store_notif_prefs` | Avisos por loja e usuário |
| `notifications.business_id` | Loja de origem do aviso |

A mensagem pronta fica nos dados da própria empresa (`mensagemPronta`).

## APIs
| Rota | Função |
|---|---|
| `GET /api/v2/lojas/central` | Lojas, contadores, avisos recentes, conexões e chaves |
| `POST /api/v2/lojas/chaves` · `/chaves/:id/revogar` | Gerar / revogar chave |
| `POST /api/v2/lojas/conectar` | Dono da loja usa a chave |
| `POST /api/v2/lojas/conexoes/:id` | `aceitar`, `recusar`, `desvincular`, `papel` |
| `GET /api/v2/lojas/pedidos` · `POST /api/v2/lojas/:bid/pedidos/:oid` | Lista consolidada / mudar situação |
| `GET /api/v2/lojas/notificacoes` · `POST …/lidas` · `PUT /api/v2/lojas/:bid/preferencias` | Avisos |
| `GET/PUT /api/v2/ads/:id/mensagem-pronta` | Configuração da mensagem pronta (dono) |

## Testes
**Servidor** (`server/test/run.ts`), 4 testes novos:
1. **Catálogo público para o visitante:** loja, cupons públicos e permissões abertos; pedido e agendamento pedem conta.
2. **Mensagem pronta:**
   - por empresa;
   - validação;
   - variáveis e trechos opcionais;
   - restaurar;
   - só aparece ativa e com WhatsApp.
3. **Chaves e conexões:**
   - validade, usos, revogação e tentativas;
   - solicitar, aceitar e recusar;
   - só o dono conecta;
   - mudar nível;
   - desvincular sem apagar nada;
   - histórico e auditoria.
4. **Central:**
   - totais e situação;
   - lista consolidada com a loja de origem;
   - operador não recusa nem cancela, administrador sim;
   - isolamento (quem não está conectado não vê nada);
   - avisos com o nome da loja e sem duplicar;
   - preferências por loja;
   - marcar como lidas.

**Navegador** (`server/test/browser/lojas_conectadas.py`), 28/28, no celular:
- mensagem pronta (variável no cursor, prévia, trecho opcional);
- visitante sem conta navega;
- botão do WhatsApp sem produto e com produto e preço;
- pedir conta na finalização;
- entrar e voltar ao carrinho;
- **criar conta e voltar ao carrinho**;
- agendamento retomado com dia, horário e observação;
- gerar chave;
- chave errada;
- solicitar e aceitar;
- visão geral com 3 lojas;
- pedido da loja conectada aceito pela central;
- aviso com a loja de origem abrindo o registro;
- dono avisado da mudança;
- sem rolagem lateral e sem erros de JS.

## Arquivos
**Novos:**
- `server/migrations/048_lojas_conectadas.sql`
- `server/src/lib/lojas-conectadas.ts`
- `server/src/lib/mensagem-pronta.ts`
- `server/src/routes/lojas.ts`
- `server/test/browser/lojas_conectadas.py`
- este documento

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/lib/notify.ts` | Loja de origem, repasse às centrais, preferências por loja |
| `server/src/routes/businesses.ts` | Mudança de situação reutilizável (com quem alterou), avisos de atualização, link do catálogo |
| `server/src/routes/perm-agenda.ts` | Respostas de solicitações também avisam as centrais |
| `server/src/routes/coupons.ts` | Cupons públicos da loja para o visitante |
| `server/src/app.ts` | Rotas; `modules-addon.js?v=140` |
| `frontend/public/modules-addon.js` | Catálogo sem login, pedir conta e retomar, mensagem pronta, Lojas Conectadas, itens em Ajustes |
| `frontend/public/assets/index-MUcZwl3l.js` | Catálogo público fora do redirecionamento para `/entrar` |
| `server/test/run.ts` | 4 testes novos |

## Publicação
Suba no GitHub e rode o `update.sh` de sempre. A migração 048 roda sozinha.
