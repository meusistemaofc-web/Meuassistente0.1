# Calendário de compromissos (Agenda → Compromissos)

O calendário é uma **visualização extra** dos mesmos compromissos. A lista continua sendo a tela padrão.

## Como funciona

- **Ícone discreto** ao lado de "+ Compromisso": um círculo de 36 px com o desenho de um calendário, sem texto.
- **Abertura em tela cheia escura**, adaptada ao celular. Mostra:
  - o mês, com navegação ‹ › (no celular também deslizando o dedo para os lados);
  - o botão **Hoje**;
  - o dia atual com destaque discreto;
  - **pontinhos** nos dias com compromissos (até 3).
- **Ao tocar num dia**, aparecem os compromissos daquela data em ordem de horário: hora, título, cliente, local e situação (os cancelados aparecem riscados).
- **Ao tocar num compromisso**, abre o **mesmo painel de detalhes e edição** que já existe no app.
- **Fechar:** pelo **×**, pelo **voltar** do celular ou pela tecla **Esc**.

## Integração

| Ponto | Como funciona |
|---|---|
| **Dados** | Os compromissos que já estão no banco (`items` do tipo `appointment`), sem segundo cadastro. A rota de listagem que já existia (`GET /api/v2/compromissos`) ganhou os parâmetros **opcionais** `de` e `ate` (até ~3 meses por consulta). Sem eles, a resposta é exatamente a de antes |
| **Datas e fuso horário** | Usa a data já gravada de cada compromisso e o "hoje" calculado pelo servidor no fuso do usuário |
| **Atualização automática** | O calendário recarrega ao abrir, ao trocar de mês, ao voltar para o app e quando outra tela avisa que algo mudou. Inclusões, edições e exclusões aparecem sozinhas |
| **Lista** | Ao fechar o calendário depois de uma edição, a lista também se atualiza |
| **Isolamento** | A consulta usa só o usuário logado. Outra pessoa nunca vê compromissos alheios. Sem login, a consulta é recusada |

**O que não mudou:** criação, edição e exclusão de compromissos, lembretes, notificações, banco de dados (nenhuma migração) e as outras áreas do app.

## Arquivos

**Novos:**
- `frontend/public/calendario-addon.js`: ícone e calendário.
- `server/test/browser/calendario.py`: teste no celular e no computador.
- `docs/CALENDARIO_COMPROMISSOS.md`: este documento.

**Alterados:**
- `server/src/routes/items.ts`: parâmetros opcionais `de`/`ate` em `compromissosGet` (só leitura).
- `server/src/app.ts`: inclusão do `calendario-addon.js?v=2`.
- `server/test/run.ts`: teste da consulta por intervalo (cobre ordem, isolamento, edição e exclusão, parâmetros inválidos e a listagem antiga).

## Publicação

Suba no GitHub e rode o `update.sh` de sempre. Não há migração nem configuração nova.
