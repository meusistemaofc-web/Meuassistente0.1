# Configurações sem a seção Compromissos

Foi uma mudança só de organização da tela: a seção **Compromissos** não aparece mais em Configurações.

## Auditoria

Em Configurações, o único item de Compromissos era a seção "Compromissos" (lista, busca, filtros e "Editar"). Ela era colocada na tela pelo arquivo `compromissos-addon.js`. Não havia outro atalho nem menu duplicado para Compromissos nessa área.

O resto de Configurações continua igual. Isso inclui, em Notificações, a preferência **"Compromissos · Antes de reuniões e eventos"**: ela liga e desliga os **avisos** de compromissos (não é o módulo) e foi mantida para preservar as notificações e os lembretes.

## O que mudou

| Antes | Agora |
|---|---|
| Configurações → seção Compromissos | Removida |
| `/perfil#compromissos` | Abre Configurações normalmente, sem a seção |
| Calendário, caso o painel de detalhes não carregue | Leva para **Agenda → Compromissos** (antes levava para Configurações) |

"Previsões e sugestões" e "Minhas execuções" continuam logo depois de "Memória do assistente", na mesma ordem de antes.

## O que não mudou

- **Agenda → Compromissos:** lista, "+ Compromisso", calendário, painel de detalhes e edição.
- **Pelo chat:** criação e edição de compromissos.
- **Dados:** nenhum compromisso apagado, nenhuma migração. A API `GET /api/v2/compromissos` continua disponível.
- **Avisos:** lembretes, notificações e push de compromissos funcionam como antes, assim como a preferência de aviso em Configurações → Notificações.
- **Demais seções de Configurações:** sem alteração.

## Arquivos

| Arquivo | Mudança |
|---|---|
| `server/src/app.ts` | O app não carrega mais `compromissos-addon.js`. `calendario-addon.js` foi para `?v=3` |
| `frontend/public/compromissos-addon.js` | Desativado: fica sem efeito caso alguma página antiga em cache ainda o carregue |
| `frontend/public/calendario-addon.js` | O caminho de reserva aponta para a Agenda |
| `server/test/run.ts` | Atualizado para conferir que Configurações não carrega mais a seção |
| `server/test/browser/compromissos.py` | Edição pela Agenda e verificação de que Configurações não tem mais a seção |

## Publicação

Suba no GitHub e rode o `update.sh` de sempre.
