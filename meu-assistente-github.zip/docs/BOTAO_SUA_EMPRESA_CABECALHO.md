# Botão "Sua empresa" no cabeçalho do chat

## O que é
Botão em formato de pílula, só com o texto "Sua empresa" e sem ícone, com borda discreta e fundo escuro translúcido.

- **Posição:** fica logo à direita do menu sanduíche. O menu sanduíche e os três pontinhos não foram movidos nem alterados; o botão ocupa só o espaço central do cabeçalho, antes do indicador de conexão.
- **Altura:** acompanha a dos botões redondos do cabeçalho em celular pequeno, celular e computador, com alinhamento vertical igual ao deles.
- **Ação:** abre direto o painel de gestão da empresa aprovada do usuário (`/x/sua-empresa`, com essa empresa selecionada). Não abre o menu lateral nem a criação de anúncio.

## Quando aparece (regra real, no servidor)
`GET /api/v2/ads/painel` responde `{ liberado, empresaId, empresas }` a partir do banco. Considera só as empresas do usuário autenticado (`owner_id`), e a regra fica em `server/src/lib/painel-empresa.ts`.

| Situação do anúncio | Status no banco | Botão |
|---|---|---|
| Em elaboração ou aguardando pagamento | `pagamento` | oculto |
| Enviado para aprovação (pendente) | `analise` | oculto |
| Ajustes pedidos pelo admin (pendente) | `ajustes` | oculto |
| Reprovado | `recusado` | oculto, e o painel fica bloqueado no backend |
| **Aprovado pelo administrador** | `aprovado` (aguardando pagamento) ou `ativo` dentro da validade | **exibido** |
| Aprovação revogada ou suspensa pelo admin ("Encerrar") | `encerrado` + `data.revogado` | oculto, e o painel fica bloqueado no backend |
| Vencido | `ativo` vencido ou `encerrado` | oculto |
| Módulo de anúncios desligado | — | oculto |

- **Atualização automática:** sem sair, entrar ou recarregar. O botão é consultado ao abrir o app, ao voltar para ele (foco ou aba visível), ao reconectar e a cada 30 segundos com o app visível. A aprovação e a revogação aparecem sozinhas.
- **Depois de recarregar:** o estado vem sempre do banco.

## Bloqueio no backend
`ownBusiness`, usado por todas as rotas de gestão da empresa (produtos, pedidos, relatórios, agente, CRM, cupons, importador e outras), passou a responder `403 painel_bloqueado` nestes casos:
- anúncio reprovado;
- aprovação revogada pelo administrador, até uma nova aprovação ou ativação.

**Isolamento:** a consulta continua sendo `id + owner_id do usuário autenticado`. Trocar o ID na URL ou nos parâmetros dá `404` para a empresa de outra pessoa.

### Fluxos existentes que continuam iguais
A suíte de testes mostrou que estes fluxos já existiam e dependem do acesso, por isso foram mantidos:
- **Preparação antes da aprovação:** com a proposta em pagamento ou análise, o dono pode configurar o agente em modo teste, importar o cardápio e montar o catálogo. Ele não tem o botão do cabeçalho, mas a preparação continua.
- **Empresa já aprovada, vencida ou em renovação:** continua com os dados e com o agente, que tem validade própria. O botão some até uma nova aprovação.
- **Ciclo do anúncio:** criar, editar a proposta, pagar, renovar e excluir anúncio reprovado continuam nas rotas de `ads.ts`, sem a nova trava. O "Anúncios e Parceiros" do menu lateral continua levando a esse acompanhamento.

## O que mudou no código
- `server/src/lib/painel-empresa.ts` (novo): `painelLiberado`, que decide o botão, `gestaoLiberada`, que decide o bloqueio, e `painelAcesso`.
- `server/src/routes/ads.ts`:
  - nova rota `adsPainelGet`;
  - a ação "Encerrar" do admin agora grava `data.revogado` e registra auditoria (`ads.end`);
  - a ativação limpa `data.revogado`.
  - O processo de aprovação não mudou.
- `server/src/routes/businesses.ts`: a trava em `ownBusiness`.
- `server/src/app.ts`: a rota `GET /api/v2/ads/painel` e `modules-addon.js?v=106`.
- `frontend/public/modules-addon.js`: o botão, com estilo próprio, e `window.__maGo` exposto para a navegação interna.

## Testes
- **Servidor:** `test/run.ts`, teste "Botão Sua empresa". Cobre sem login (401), sem anúncio, pagamento, pendente, ajustes, reprovado (bloqueado, mas ainda pode ser excluído), aprovação pelo admin, isolamento (404), revogação (bloqueado e auditado), reativação, vencido, nenhuma empresa duplicada e módulo desligado.
- **Tela:** `test/browser/sua_empresa_cabecalho.py`, com 31 verificações:
  - os estados do anúncio, e a aprovação real pelo painel administrativo fazendo o botão surgir sozinho;
  - o layout em celular pequeno, celular e computador: pílula só com texto, posição, alinhamento, sem sobreposição e três pontinhos no extremo direito;
  - o menu sanduíche e os três pontinhos funcionando;
  - a abertura do painel, a persistência ao recarregar, o isolamento, a revogação fazendo o botão sumir sozinho, a reativação e o vencimento;
  - nenhum erro de JavaScript.

## Como reverter
1. Remover o bloco "Botão Sua empresa no cabeçalho" do fim de `modules-addon.js` e voltar `?v=106` para `?v=105`.
2. Tirar a linha `if (!gestaoLiberada(b)) …` de `ownBusiness`, junto com o import.
3. Tirar a rota `/api/v2/ads/painel` e `adsPainelGet`.
4. Opcionalmente, apagar `lib/painel-empresa.ts`.

O campo `data.revogado` gravado pela ação "Encerrar" é inofensivo e pode ficar.
