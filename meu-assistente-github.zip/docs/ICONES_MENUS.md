# Ícones exclusivos nos menus de Sua empresa

Cada opção dos menus de Ajustes de **Sua empresa** tem um ícone próprio, sem repetição e ligado à sua finalidade. Os textos, as descrições, a navegação e as funções não mudaram.

## Distribuição

| Opção | Ícone (antes → agora) |
|---|---|
| Tema do catálogo | imagem → **paleta de cores** |
| Tipo de catálogo | sacola → **grade de aplicativos** |
| Categorias do catálogo | sacola → **pasta** |
| Etiquetas | estrela → **etiqueta** |
| Cupons de desconto | estrela → **selo de porcentagem** |
| MCoins do Meu Assistente | **estrela** (mantido) |
| Entrega e pagamento | caminhão → **cartão** |
| Logo e capa | **imagem** (mantido) |
| Horário e abrir/fechar | **relógio** (mantido) |
| Calendário e funcionamento | relógio → **calendário** |
| Permissões de Agendamento | relógio → **escudo com marca de verificação** |
| CRM | balão de conversa → **pessoas** |
| Agente de atendimento | balão de conversa → **robô** |
| Relatórios e acessos | **gráfico** (mantido) |
| Central de Marketing | gráfico → **megafone** |
| Editar, Ver prévia, Ver loja pública, Compartilhar, Criar anúncio, Excluir | lápis, olho, globo, link, mais e lixeira (mantidos, já eram únicos) |

Todos os ícones seguem o mesmo padrão: 20 px, traço 1,7, cantos arredondados e a cor azul de destaque do tema (`text-accent`).

## Validação automática

- **Registro único:** os ícones das opções ficam em `MENU_AJUSTES`, em `frontend/public/modules-addon.js`. Os dois menus usam esse registro: a lista de Ajustes e a aba Ajustes dentro de Pedidos ou Catálogo.
- **Recusa:** `menuIcones()` recusa ícone repetido ou inexistente. A checagem roda ao carregar a página: o erro vai para o console e para `window.__maIconErros`.
- **Testes:** a suíte do servidor falha se uma opção nova repetir um ícone ou usar um ícone escrito à mão fora do registro. Para adicionar uma opção, basta incluí-la no registro com um ícone livre.

## Demais menus verificados

| Menu | Resultado |
|---|---|
| Menu lateral do app | Sem repetições |
| Início de Sua empresa | Sem repetições |
| Barra inferior | Sem repetições |
| Painel administrativo | As abas não têm ícones |

Os botões rápidos do chat usam o mesmo ícone de propósito: são sugestões de mensagem, não opções de menu.

## Testes

- **Servidor:** "Ícones exclusivos nos menus de Sua empresa".
- **Navegador:** `server/test/browser/icones_ajustes.py`, com 17 verificações no celular e no computador.

## Como reverter

Restaurar o `modules-addon.js` da versão anterior.
