# Motor de Aprendizagem Adaptativa e Memória Evolutiva

O assistente aprende **a trabalhar com cada usuário** — sem treinar modelo, sem fine-tuning e sem depender só do prompt. A aprendizagem é estrutural: detecção, gravação, recuperação e prevenção são determinísticas (funcionam até com a IA desligada) e ficam em `server/src/ai/adaptive.ts` (`AdaptiveLearningEngine`).

## Comportamento percebido (silencioso e natural)
- Usuário: "Não faça o agendamento antes de verificar a disponibilidade." → Chat: "Entendi! Vou conferir a disponibilidade antes de seguir."
- Em outra conversa, dias depois: "Agende um atendimento amanhã." → Chat: "Claro! Vou conferir os horários disponíveis primeiro. …"
- O chat **nunca** diz que aprendeu, registrou, consultou memória ou que o usuário já corrigiu isso antes (instrução ao modelo + filtro `silenciar` na resposta final).
- Frase ambígua ("Você esqueceu de considerar o intervalo") → uma pergunta natural: "…sempre daqui para frente ou só desta vez?". Frases vagas ("Não era isso que eu queria") não viram aprendizado.

## Fluxo no orquestrador existente (sem segundo orquestrador)
`routes/chat.ts`: regras executáveis do Cérebro → **`observar`** (identifica correção/preferência e grava) → motores de matemática, contexto da conversa, finanças, agenda, agendamento rápido (com **prevenção**) → `runAssistant`, que recebe só os aprendizados **relevantes** (`contextoIA`) e protege `create_appointment` com a mesma prevenção → resposta (`silenciar`) → `observarUso` (padrões de uso).

## Três camadas de memória (nada duplicado)
| Camada | Onde | Observação |
|---|---|---|
| 1 — Contextual | `conversation_context.correcoes` (`ai/convctx.ts`) | vale só na conversa atual |
| 2 — Individual | tabela `learnings` (migração `023_aprendizagem_adaptativa.sql`) | por usuário (e empresa, quando citada); sobrevive a conversas e novos chats |
| 3 — Global | Cérebro / Laboratório de IA (já existentes) | **nunca** alterada por uma correção individual. O motor só **sugere** ao administrador regras repetidas por ≥ 2 usuários (anônimas e agregadas); "Promover" cria apenas um **rascunho** no Laboratório, que exige testes e aprovação |

A tabela `memories` (fatos que o usuário declara) permanece como está.

## Registro de cada aprendizado
usuário, empresa, contexto, ação executada, problema, correção original, preferência, regra, escopo (`permanente` / `pontual` / `candidato`), confiança, frequência, usos, estado (`ativo` / `pausado` / `substituido`), histórico de alterações, datas.

## Força do aprendizado
- Correção explícita e clara: gravada na hora (confiança 0,90). Repetida: frequência e confiança sobem (sem duplicar).
- Ambígua: `candidato` (0,40) até o usuário responder; "só desta vez" → `pontual` (vale só naquela conversa).
- Inferida (ex.: horário recorrente): começa em 0,35, cresce a cada repetição (máx. 0,85) e só é recuperada quando passa de 0,5; vale como sugestão.
- Contradição: a orientação explícita **mais recente** vence; a anterior vira `substituido` (com histórico).

## Recuperação contextual
Só entram no prompt aprendizados do usuário, ativos, da operação da mensagem atual (agendamento, exclusão, financeiro, lembrete, tarefa, compra) e de estilo, ordenados por confiança, atualidade e frequência (máx. 5). Nada irrelevante é carregado.

## Prevenção (orienta, não bloqueia)
- "Consultar antes": confere a agenda do usuário; horário livre → segue ("Conferi a disponibilidade e está livre."); conflito → oferece alternativas e **não grava**.
- "Considerar intervalo": não oferece/grava horários no almoço.
- "Confirmar antes": pede o "sim" antes de executar.
- Regras de negócio, permissões e validações continuam controlando a execução.

## Segurança e controle
- Instruções para ignorar segurança/permissões/validações, aprovar pagamentos automaticamente, aplicar a todos os usuários ou guardar senha/cartão são **recusadas** com naturalidade e não são gravadas (nem por edição manual).
- Dispensar conferência de **exclusão** ou **financeiro** é recusado.
- Isolamento total por usuário; empresas separadas quando a empresa é citada; sem acesso cruzado.
- Usuário: tela **Aprendizados** (`/x/aprendizados`, menu lateral) — rever, editar, pausar/ativar, excluir um ou todos, ligar/desligar "Aprender com minhas correções" (reaproveita `users.memory_settings`; também respeita a chave "memória ligada").
- Administrador: cartão **Aprendizagem adaptativa** em Painel → Cérebro e busca → Capacidades (liga/desliga a chave global, `PUT /api/panel/aprendizagem`), contagens agregadas, sugestões globais e promoção para rascunho. Alterações são auditadas (`aprendizado.*`, `aprendizagem.chave`).

## API
`GET /api/learning`, `POST /api/learning` (`update`, `delete`, `delete_all`, `settings`), `GET/PUT /api/panel/aprendizagem` (admin).

## Testes
`server/test/run.ts` — 9 testes "Aprendizagem adaptativa" cobrindo os 14 itens obrigatórios (correção explícita, registro persistente, recuperação em nova conversa, sem anunciar memória, preferências recorrentes, pontual × permanente, prevenção, contradição, isolamento, individual × global, recuperação contextual, persistência, conversas simultâneas, segurança/permissões) e `server/test/browser/aprendizagem_adaptativa.py` (fluxo completo no navegador).

## Limitações
- A detecção de correções é por padrões em português (cobre os exemplos e variações comuns); frases muito fora do padrão não viram aprendizado — o assistente simplesmente segue normalmente.
- A prevenção ativa hoje cobre agendamento (consultar, intervalo, confirmar); para as demais operações a preferência orienta a IA pelo contexto, e as validações existentes seguem valendo.
