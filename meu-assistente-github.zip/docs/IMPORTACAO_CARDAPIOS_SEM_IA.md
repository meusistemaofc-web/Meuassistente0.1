# Importação inteligente de cardápios SEM IA (Central de Mídias)

A importação de cardápios do Meu Assistente (Sua empresa → Produtos → **Importar cardápio**) passa a ler fotos e PDFs
**no próprio servidor**, sem nenhuma API de IA. A leitura usa OCR local (Tesseract) e um interpretador de cardápio por
regras. Ela funciona com todas as IAs desligadas (modo **Sem IA (teste)**).

O fluxo que já existia foi mantido inteiro:
- envio de várias fotos ou páginas;
- fila em segundo plano com progresso;
- **tela de conferência** (editar, excluir, confirmar item a item);
- detecção de duplicidade com o catálogo;
- cadastro só depois da confirmação, pelo mesmo serviço de produtos;
- histórico e "Desfazer importação".

Só a etapa de **leitura** ganhou o caminho local.

## Como funciona

```
foto / PDF ─► app (fila do importador) ─► Central de Mídias  ─► OCR com 2 leituras combinadas ─► interpretador por regras
                     │                     (mesma MIDIA_URL/      (endireita, gira, contraste)      (categorias, preços, tamanhos,
                     │                      MIDIA_TOKEN)                                              adicionais, observações)
                     │ central fora / sem itens e com IA ligada
                     └─► caminho com IA (o de antes, inalterado)
                                                       ▼
                         tela de conferência ─► confirmação do dono ─► cadastro atual de produtos
```

### Leitura local (na central)

- **Formatos:** JPG, JPEG, PNG, PDF digital e PDF escaneado, além de DOCX. Até 12 arquivos por importação, ou seja, várias fotos e várias páginas do mesmo cardápio.
- **Correção da imagem:**
  - corrige a perspectiva do papel;
  - endireita a inclinação;
  - detecta a foto de lado e gira;
  - inverte o cardápio escuro;
  - amplia e realça o contraste.
- **Duas leituras do OCR combinadas pela posição** (segmentação automática e bloco único):
  - um preço que só uma das leituras achou entra;
  - um preço que as duas leituras leram **diferente** fica marcado como pouco legível e vai para revisão. O sistema nunca escolhe no chute.
- **Colunas:** cardápios em 2 ou 3 colunas são separados. A coluna de preços à direita não conta como coluna. Títulos que atravessam a página ficam no lugar.

### Interpretação por regras (`services/central-midia/app/cardapio.py`)

- **Categorias:**
  - títulos em maiúsculas;
  - vocabulário de cardápio (Lanches, Pizzas, Bebidas…);
  - linhas terminadas em ":".
- **Preço associado ao produto**, em três arranjos:
  - na mesma linha ("X-Burguer ...... R$ 22,90");
  - no fim da linha, com pontilhado;
  - na linha de baixo, quando o nome e a descrição vêm antes.
- **Formatos de preço:** vírgula decimal (`12,90`), ponto (`12.90`), `R$ 15` e milhar (`1.250,00`).
- **Correções clássicas de OCR**, sempre marcadas para revisão: `l5,9O` → `15,90`, `RS` → `R$`, `300 mi` → `300 ml`.
- **Tamanhos e variações:**
  - cabeçalho "Broto Média Grande" ou "300ml 500ml";
  - rótulos na linha ("P 10,00 G 14,00");
  - linhas de tamanho abaixo do produto ("300 ml ..... 14,00").
- **Adicionais separados dos produtos:**
  - a seção "Adicionais/Complementos/Extras" vale para os produtos da categoria a que se refere;
  - linhas "+ Bacon 4,00" valem para o produto anterior.
- **Descrição original**: os ingredientes escritos. Nenhuma descrição é sugerida sem IA.
- **Observações:** "Obs:", "*", "(serve 2 pessoas)". **Indisponível:** "(esgotado)".
- **Ignorados:** taxa de entrega, WhatsApp, Instagram, endereço, horário, formas de pagamento.
- **Ordem original** preservada. Em várias fotos, os itens do topo de uma página sem título continuam a categoria da página anterior, com aviso.

### Nada é inventado

| Situação | O que acontece |
|---|---|
| Preço coberto ou ilegível | O item aparece **sem preço**, marcado "Preço não identificado" e desmarcado |
| Nome coberto | O item **não** aparece com nome inventado, e o preço solto não vai para outro produto |
| Preço que as duas leituras leram diferente, ou com correção de OCR | Mostra o valor lido, marcado **"Dúvida na leitura"**, e exige "Conferi este item" |
| Vários preços sem tamanho identificado | Não inventa rótulos: fica o 1º preço, marcado para revisão |
| Categoria não identificada | "Outros" (editável) |

Itens marcados ficam **desmarcados** e só são cadastrados se o dono conferir e confirmar. Isso já era regra do importador.

### Política e modo Sem IA

A importação respeita a mesma política do Painel → IA → "Leitura de comprovantes":

| Opção | Comportamento |
|---|---|
| Leitura local primeiro (padrão) | Lê na central. Se não achar nenhum item e houver IA ligada, usa a IA (como antes). Com a central fora do ar, usa o caminho antigo |
| Somente leitura local | Nunca usa IA |
| IA primeiro | Caminho antigo. A leitura local entra se a IA falhar |

Com o modo **Sem IA (teste)**, ou com nenhuma IA configurada, a leitura é **somente local**. Se a central estiver fora do ar, a importação mostra uma mensagem clara ("A leitura de cardápios no servidor está indisponível no momento"). Nada é inventado e nada é cadastrado.

### Segurança e dados

- **Sem token novo:** usa o mesmo `MIDIA_URL`/`MIDIA_TOKEN` dos comprovantes.
- **Sem dependência externa:** nenhuma API de IA nem serviço externo. O OCR roda na central.
- **Arquivos:** a central recebe só o arquivo e o número interno da empresa (`b<id>`), e o arquivo é apagado ao fim da leitura. No app, os arquivos seguem as regras de retenção que já existiam.
- **Separação entre empresas:** importações, rascunhos e produtos ficam presos à empresa do dono. Outra pessoa recebe 404.
- **Duplicidade:** o mesmo conjunto de arquivos já importado é barrado ("Este cardápio já foi importado").
- **Comprovantes:** a leitura funciona como antes. A central só interpreta cardápio quando o app pede `cardapio=1`, e a resposta dos comprovantes não muda.

## Testes

| Suíte | Comando | O que cobre |
|---|---|---|
| Central (Python) | `cd services/central-midia && python3 -m pytest -q tests` | **34 testes novos de cardápio**:<br>• PDF digital (5 modelos) e PDF de várias páginas;<br>• 5 modelos × foto inclinada, 2ª foto, foto de lado e cardápio escuro (20);<br>• PDF escaneado de várias páginas;<br>• foto parcialmente ilegível (4 variações, nada inventado);<br>• regras (vírgula decimal, R$ inteiro, correções de OCR, tamanhos, adicionais, observações, esgotado, linhas ignoradas, vários preços sem tamanho);<br>• adicionais na categoria certa;<br>• comprovante inalterado.<br>Mais **todos os 72 testes anteriores**, inclusive os comprovantes fotografados |
| API completa | `cd server && npx tsx test/run.ts` | Novo teste "Importador de cardápio SEM IA" (detalhes abaixo). Os testes antigos do importador com IA e todos os de comprovantes continuam |
| **Ponta a ponta no navegador** | `cd server && python3 test/browser/cardapio_sem_ia.py` | Central REAL + servidor + modo Sem IA, pela tela (detalhes abaixo) |
| Importador (regressão) | `cd server && python3 test/browser/importar_cardapio.py` (servidor na 4311) | O fluxo antigo com IA, intacto |
| Comprovantes (regressão) | `cd server && python3 test/browser/comprovante_sem_ia.py` | Leitura de comprovantes sem IA, intacta |

**Novo teste da API ("Importador de cardápio SEM IA"):**
- leitura local, sem chamada de IA;
- conferência e confirmação;
- categoria entre páginas;
- dúvidas para revisão e sem preço inventado;
- duplicidade e isolamento;
- política "somente local";
- IA ligada com leitura local completa não chama IA;
- central fora do ar.

**Teste de ponta a ponta no navegador:**
- 3 fotos do mesmo cardápio (inclinada, de lado, outra página);
- PDF digital de 2 páginas com colunas;
- importação duplicada;
- PDF escaneado com foto parcialmente ilegível;
- editar, excluir e confirmar;
- cadastro só após confirmar;
- separação entre empresas;
- confere que nenhuma IA foi chamada.

## Arquivos

**Novos:**
- `services/central-midia/app/cardapio.py`: interpretador de cardápios por regras e separação de colunas.
- `services/central-midia/tests/cardapios.py`: gerador de cardápios de teste (fotos, PDFs digitais e escaneados, foto ilegível) e conferência.
- `server/test/browser/cardapio_sem_ia.py`: teste de ponta a ponta.
- `docs/IMPORTACAO_CARDAPIOS_SEM_IA.md`: este documento.

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `services/central-midia/app/processadores/imagem.py` | `ocr_cardapio` (2 leituras combinadas, texto por posição, marca palavras duvidosas) e `layout` no `ocr_arquivo`. Só entra com `cardapio=1`; o caminho dos comprovantes é o mesmo |
| `services/central-midia/app/processadores/pdf.py` | Páginas escaneadas de cardápio passam por `preparar_ocr` + `ocr_cardapio` (só com `cardapio=1`) |
| `services/central-midia/app/trabalhador.py` | Com `cardapio=1`, separa colunas, interpreta e devolve `cardapio` (texto sem marcas) |
| `services/central-midia/app/main.py` | Parâmetro `cardapio=0\|1` e chave `cardapio` na resposta (só quando pedida) |
| `services/central-midia/tests/test_central.py` | 34 testes novos |
| `server/src/lib/central-midia.ts` | Opção `cardapio` e o tipo da resposta |
| `server/src/lib/menu-import.ts` | `lerCardapioLocal` e a nova ordem de leitura (local → IA → reserva). Leitura com IA movida para `lerArquivoIA`, sem mudança. Continuidade de categoria entre páginas e origem da leitura por arquivo |
| `frontend/public/menu-import-addon.js` | Aba "Importar cardápio" (era "com IA"), texto de apresentação, selo "Lido no servidor · sem IA", campo de observações e selo "Indisponível no cardápio" |
| `server/src/app.ts` | `menu-import-addon.js?v=4` |
| `server/test/run.ts` | Teste novo. O teste da central passa a aceitar `lib/menu-import.ts` como usuário da central |
| `server/test/browser/importar_cardapio.py` | Só o novo nome da aba |

**Sem alteração:**
- banco: nenhuma migração, a tabela `menu_imports` já guardava tudo;
- autenticação e usuários;
- financeiro;
- leitura de comprovantes;
- cadastro de produtos (`salvarProduto`);
- Docker, Compose e `.env`.

## Publicação (quando você autorizar)

1. Suba no GitHub e rode o `update.sh` de sempre. O app atualiza; sem a central, a importação segue com IA, como antes.
2. **A central precisa ser reconstruída** para ganhar a leitura de cardápios:
   - `sudo bash deploy/scripts/central-midia.sh testar`: roda a suíte, incluindo os testes de cardápio, sem subir nada;
   - depois, `sudo bash deploy/scripts/central-midia.sh instalar`: reconstrói e sobe **só** a central. O token existente é mantido.
3. Teste: Sua empresa → Produtos → Importar cardápio. Envie uma foto ou PDF e veja o selo "Lido no servidor · sem IA" na conferência.

Para voltar atrás, use o Painel → IA → "IA primeiro (como antes)". Os comprovantes não são afetados.
