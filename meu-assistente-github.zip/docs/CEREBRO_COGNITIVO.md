# Cérebro cognitivo — inteligência conversacional avançada

Camada **aditiva** que envolve o pipeline de resposta que já existe. Ela não troca modelos, serviços, integrações nem fluxos: lê a mensagem **antes** de a IA responder, orienta a IA com o que importa e confere a resposta **depois**, antes de entregá-la. Tudo é determinístico (regras e análise do texto): **não gasta IA extra**, é individual por usuário e **só guarda notas — nunca o texto das conversas**.

Código: `server/src/ai/cognition.ts` · integração em `ai/assistant.ts` e `routes/chat.ts` · painel em `routes/cognition.ts` e `frontend/public/panel-addon.js` · migração `030_cerebro_cognitivo.sql` · testes em `server/test/run.ts` (7 testes "Cérebro cognitivo") e `server/test/browser/cerebro_cognitivo.py`.

## Onde entra no que já existia
```
mensagem → regras do Cérebro → aprendizagem adaptativa → motores internos (conta, agenda, finanças…)
         → atalhos → Cérebro (conhecimento) → IA (runAssistant)
                                               ├─ ANTES: analisar() + contextoCognitivo()  → texto de sistema da IA
                                               ├─ DURANTE: ferramentas (portaoSensivel() nas sensíveis)
                                               └─ DEPOIS: revisarResposta() → resposta entregue
resposta entregue (qualquer caminho) → avaliar() → cognition_evals (só notas)
```
Reaproveitado sem alteração de comportamento: `engineInstructions` (persona/naturalidade/precisão do administrador), `HONESTIDADE` e `guardExternalClaims` (comercial), memória por conversa (`convctx`), memória do usuário (`memories`), aprendizagem adaptativa, Cérebro/conhecimento, ferramentas e `once` (execução única). A camada só **soma** um bloco ao texto de sistema e confere a saída.

## Mapa dos 9 requisitos
| # | Requisito | Como foi implementado |
|---|-----------|----------------------|
| 1 | Inteligência conversacional | `analisar()` identifica o tipo (comando, pergunta, correção, continuação, confirmação, desabafo…), informalidade/formalidade, emoção (frustrado, urgente, ansioso), mensagem incompleta ou elíptica ("e amanhã?" → continuação da última pergunta) e extensão ideal da resposta. O tom acompanha o jeito de cada usuário (`perfilDe`, calculado só das próprias mensagens). |
| 2 | Raciocínio e compreensão | Lacunas por tipo de pedido (gasto sem valor, agendamento sem dia/horário, lembrete sem quando, conta sem vencimento) **descontando o que já foi dito**; ambiguidades ("isso" sem antecedente, "às 5" sem período); contradições/trocas ("14h" → "15h" sobre o mesmo assunto); pedidos em várias etapas. A IA recebe a instrução de fazer **uma** pergunta curta e só executar depois. |
| 3 | Memória contextual | Reaproveita `convctx`; resume o que o usuário disse **fora da janela** de histórico enviada à IA (`fatosDaConversa`, sem documentos/senhas); separa contexto passageiro ("hoje…") de fatos duradouros (nome, cidade, profissão, família, preferências, rotina) — **nada é guardado sozinho**: a IA só oferece guardar, e dados sensíveis (saúde, CPF, cartão, senha) nunca. |
| 4 | Comunicação profissional e natural | Instruções de estilo (sem "Como assistente de IA…", sem "Espero ter ajudado", sem repetir a pergunta) e limpeza determinística (`revisarResposta`): tira fórmulas prontas e aberturas repetidas ("Claro!" duas vezes seguidas). Pergunta simples → resposta curta; assunto complexo → poucos passos. |
| 5 | Inteligência adaptativa | Reconhece **recorrência** (pedido parecido em outras conversas do mesmo usuário → oferece automatizar), **correções** do usuário (marcam a avaliação da resposta anterior; quem corrige mais recebe mais conferência antes de agir) — tudo individual; a aprendizagem adaptativa existente continua cuidando de regras/preferências. Nada altera o comportamento global. |
| 6 | Precisão e confiabilidade | Bloco CONFIABILIDADE (fato × hipótese × sugestão; nunca inventar dados, links, fontes, números ou funcionalidades); **capacidades reais** montadas das ferramentas disponíveis agora; conferência pós-resposta: ação afirmada sem confirmação da ferramenta (`acao_nao_confirmada`), falha parcial omitida, **links que não vieram do usuário nem de ferramentas são removidos**, afirmações "estudos mostram…" sem fonte são sinalizadas. |
| 7 | Inteligência operacional | Intenção → ferramentas já existentes (nenhuma foi substituída); planejamento de pedidos em etapas com conferência do resultado de cada uma; `portaoSensivel`: ferramenta sensível/irreversível (nome com cancelar, excluir, apagar, remover, disparar, enviar_, pagar_, transferir…) só roda após um "sim" explícito do usuário para **aquela** ação, uma única vez. `agenda_empresa_decidir` e `crm_atualizar_etapa` já têm confirmação própria e não são duplicadas. |
| 8 | Controle de qualidade | `avaliar()` dá nota 0–100 em precisão, coerência, naturalidade, clareza, contexto e resolução + nota geral, com sinalizações (resposta repetida, tom robótico, perguntou o que já sabia, comando sem ação, resposta longa demais, bloco único…). Fica em `cognition_evals` **sem texto**; o administrador vê médias, sinalizações, caminhos e tendência. |
| 9 | Preservação do sistema | Aditivo e modular; desligável (chave geral + 3 ajustes); desligado = comportamento anterior idêntico (testado); regressão da suíte completa e dos testes de navegador. |

## Painel do administrador (Cérebro e busca → Inteligência cognitiva)
Chave geral e três ajustes (conferir ações afirmadas · tom natural · confirmar ações sensíveis), nota geral e por dimensão, sinalizações mais frequentes, notas por caminho de resposta, ajustes automáticos e respostas corrigidas pelo usuário. Também aparece em **Capacidades** (`cerebro-cognitivo`). `GET/PUT /api/panel/cognicao` (PUT exige `panel.manage`; toda mudança vai para a auditoria como `cognicao.config`).

## Privacidade e segurança
- `cognition_evals` guarda apenas: usuário, conversa, mensagem, caminho, tipo da intenção, notas, sinalizações, ajustes e se foi corrigida. **Nenhum texto.**
- O perfil de comunicação, a recorrência e as correções são calculados por usuário, a partir das mensagens dele; um usuário nunca influencia outro.
- Documentos (CPF), cartões, senhas e dados de saúde nunca entram no resumo da conversa nem na oferta de memória.
- A camada nunca contorna autenticação, permissões, validações financeiras nem as regras do administrador (as ferramentas continuam validando tudo).

## Limites (honestos)
- Funciona por regras e análise do texto em português; **não substitui o modelo** — orienta e confere. Frases muito incomuns podem passar sem leitura de intenção (a IA continua respondendo normalmente).
- As notas são estimativas internas, não substituem avaliação humana.
- Hoje só o chat principal usa a camada (o Laboratório de IA recebe a orientação no texto de sistema, mas não registra notas). O agente público de empresas não foi alterado.
- A conferência de "ação afirmada" cobre os verbos mais comuns em 1ª pessoa (agendei, registrei, criei, salvei…); outras formulações não são reescritas.
- Os testes usam IA simulada; o ganho de naturalidade com um modelo real depende do modelo configurado.

## Reversão
Desligar em Painel → Cérebro → Inteligência cognitiva (efeito imediato, sem perder dados). Para remover de vez: `DROP TABLE cognition_evals;` e retirar as chamadas a `cognition.js` em `assistant.ts` e `chat.ts`.
