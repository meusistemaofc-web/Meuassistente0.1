# Motor de Notificações Comerciais

Ofertas automáticas de serviços do Meu Assistente para quem ainda não os contratou. A primeira campanha é a do **Agente de Atendimento**, que começa quando o anúncio de uma empresa é publicado.

## Como funciona (Agente de Atendimento)

1. O agendador do servidor roda a cada 30 s. A cada rodada, ele procura anúncios **efetivamente publicados**: status `ativo`, dentro da validade, sem suspensão do administrador e de dono com conta comum (não administrador).
   - Só entram anúncios publicados **depois** de a campanha ser ligada. Os anteriores podem ser incluídos pelo botão “Incluir anúncios já publicados”; nesse caso, a sequência começa agora.
2. Se o dono **não tem o Agente contratado** (plano pago e dentro da validade, em qualquer empresa dele), começa a sequência:

   | Etapa          | Quando (padrão)       | Botão             |
   |----------------|-----------------------|-------------------|
   | Na publicação  | 0 h                   | Conhecer o agente |
   | 24 horas depois| 24 h                  | Ativar meu agente |
   | 3 dias depois  | 72 h                  | Contratar o agente|
   | 7 dias depois  | 168 h                 | Ativar agora      |

3. Cada mensagem vai pela central de notificações existente e por push. O botão leva a `/x/sua-empresa?nc=<código>`. O app registra o clique e abre direto a tela **Agente de atendimento** da empresa, que tem o botão de contratação já existente.

## Regras

- **Interrompe na hora da contratação.** Antes de cada envio e a cada rodada, o motor confere se o agente foi contratado. Se foi, a sequência termina e é registrada uma conversão, indicando se veio depois de um clique.
  - Contratado antes de receber qualquer mensagem: a sequência é encerrada como “já tinha o serviço”, sem contar conversão.
- **Não inicia** para anúncios recusados, ainda não publicados, cancelados ou vencidos.
- **Interrompe** se o anúncio sai do ar (vence, é encerrado, suspenso ou removido).
- **Sem repetição.** Cada dono tem uma única sequência por campanha (o agente é um por dono). Ela nunca recomeça, nem em renovações.
- **Sem excesso:**
  - O envio só acontece no horário permitido, no fuso de cada dono (padrão das 8h às 21h).
  - Há no máximo uma oferta comercial por intervalo mínimo (padrão 20 h), somando todas as campanhas.
  - Etapas atrasadas não se acumulam: vai só a mais recente, e as anteriores ficam registradas como “pulada”.
- **Personalização.** Quando o anúncio já tem visualizações, o motor usa a “mensagem com dados”. Os números vêm de `business_stats`:
  - visualizações: `impressao` + `visita`;
  - contatos: WhatsApp, Instagram, link e mapa;
  - pedidos.
- **Respeita o perfil.** Quem desligou as notificações não recebe; o envio fica registrado como “bloqueado”. O dono também pode tocar em **Não quero receber**.
- **Isolamento.** O código do botão é assinado (HMAC) e só funciona para o dono da sequência. Cada dono só vê as próprias ofertas.

## Registros (tabela `com_eventos`)

Os tipos de evento são:

- `envio`
- `visualizacao`: notificação aberta ou marcada como lida, ou clique
- `clique`
- `conversao`
- `pulada`
- `bloqueado`
- `interrupcao`, com o motivo

Há um registro por etapa e por tipo.

## Painel administrativo → “Notificações comerciais”

- Chave geral, horário permitido e intervalo mínimo.
- Por campanha:
  - liga/desliga;
  - resultados: na sequência, enviadas, visualizadas, cliques, contrataram e taxa de conversão, por etapa;
  - motivos de interrupção e empresas recentes;
  - edição de cada etapa: ativa, horas depois da publicação, título, mensagem, mensagem com dados e texto do botão.
- Variáveis das mensagens: `{empresa}`, `{nome}`, `{visualizacoes}`, `{contatos}`, `{pedidos}`, `{preco}`, `{dias}`. Preço e dias vêm do plano do agente configurado no painel.
- Botões “Incluir anúncios já publicados” e “Processar agora”.
- Desligar a campanha não apaga nada. Ao religar, quem estava na sequência continua de onde parou, e anúncios novos entram a partir desse momento.
- As alterações ficam no `audit_log` (`comercial.*`).

## Nova campanha (estrutura expansível)

1. Implemente `CampanhaComercial` (`server/src/comercial/tipos.ts`) em um arquivo próprio, com:
   - `candidatos`
   - `situacao`
   - `variaveis`
   - `destino`
   - `padrao` (etapas)
2. Acrescente a campanha em `CAMPANHAS` (`server/src/comercial/campanhas.ts`).

O motor, o painel, os registros e os resultados passam a valer para ela sem outra mudança.

## Arquivos

- `server/migrations/042_notificacoes_comerciais.sql`: tabelas `com_campanhas`, `com_inscricoes` e `com_eventos`. Só acrescenta.
- `server/src/comercial/{tipos,campanhas,motor}.ts`
- `server/src/routes/comercial.ts`: rotas `/api/panel/comercial` (administrador) e `/api/v2/comercial` (dono).
- `server/src/scheduler.ts`: chama o motor.
- `frontend/public/modules-addon.js`: botão na central de notificações e abertura da tela do agente.
- `frontend/public/panel-addon.js`: aba do painel.
- Testes:
  - `server/test/run.ts`: 4 testes;
  - `server/test/browser/notificacoes_comerciais.py`.

Nenhuma regra comercial existente foi alterada. Preço, contratação e pagamento do agente continuam os mesmos.
