# Contadores de pedidos e agendamentos (BusinessActivityCounters)

Fonte única: `GET /api/v2/counters` (`server/src/routes/counters.ts`, objeto `BusinessActivityCounters`). Lê os registros oficiais da tabela `orders` (agendamento = `data.tipo === 'agendamento'`); não há valores fixos nem contadores independentes.

## Critério (preservado do menu lateral)
- **Novos** (empresa do usuário): status `novo` aguardando decisão do dono; pedidos com pagamento online só contam depois de pagos. Só empresas ativas do próprio dono com plano de loja (nível ≥ 4). Separado em `pedidos` e `agendamentos`; `total` = soma — é o número que o menu lateral já mostrava em "Sua empresa".
- **Meus em andamento** (como cliente): `novo, aceito, preparo, saiu, pronto`, sem pedidos de convidado — é o número de "Meus pedidos" no menu lateral.
- Não mistura com total histórico nem com notificações não lidas.

## Onde aparece
- Menu lateral do Chat: "Sua empresa" (total de novos) e "Meus pedidos" (em andamento) — mesmo estilo (`.ma-badge`).
- Sua empresa > barra inferior: **Pedidos** (empresa de produtos), **Agenda** (empresa de serviços: só agendamentos) ou **Pedidos** (empresa "ambos": pedidos + agendamentos, pois a aba lista os dois). Badge pequeno no ícone, mesmo padrão visual.
- Some quando zero.

## Atualização
Um único armazenamento no front (`counters()` em `modules-addon.js`): consulta deduplicada (4 s), atualização a cada 20 s com a página visível, ao voltar para a aba e logo após qualquer ação de pedido/agendamento (aceitar, recusar, cancelar, concluir, novo pedido/agendamento). Menu lateral e "Sua empresa" são pintados com o mesmo resultado, por isso sempre coincidem; sem recarregar a página.

## Segurança
Rota exige login; cada pessoa só recebe os números das próprias empresas e dos próprios pedidos.

## Testes
`server/test/run.ts` ("Contadores: fonte única…") e `server/test/browser/contadores_sincronizados.py` (celular e computador, tempo real, igualdade entre menus).

## Limitação
A atualização é por consulta periódica (20 s) e por ações do próprio usuário; não há push em tempo real do servidor para o navegador.
