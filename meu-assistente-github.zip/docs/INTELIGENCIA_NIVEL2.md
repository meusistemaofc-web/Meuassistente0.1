# Inteligência avançada — Nível 2

Evolução do núcleo de inteligência **sobre** o Cérebro cognitivo (Nível 1, `docs/CEREBRO_COGNITIVO.md`), feita de forma modular e incremental. Ela não substitui modelos, integrações, ferramentas nem fluxos. Cada capacidade tem chave própria em **Painel → Cérebro e busca → Inteligência avançada**. Com a chave geral desligada, o chat volta **exatamente** ao Nível 1 (isso é testado).

## Diagnóstico (antes de implementar)
| Situação | Componente | Decisão |
|---|---|---|
| Reaproveitado sem mudança | Motor de IA e fallbacks (`provider/engine`), todas as ferramentas, domínios `agenda-ia`, `crm-ia`, `negocio-ia`, `finchat`, `commercial`, aprendizagem adaptativa + fila de revisão, `convctx`, `once`, notificações, **Laboratório de IA** (proposta → testes → aprovação → publicação) | Os domínios viram os *especialistas*; o Laboratório é o caminho obrigatório para mudanças de comportamento vindas de feedback |
| Aprimorado | Memória (`routes/memory.ts` + `save_memory`): antes, as 50 memórias mais novas entravam inteiras em toda resposta e repetições viravam duplicatas | Recuperação por relevância, atualização em vez de duplicata e anti-repetição (`ai/memoria.ts`) |
| Aprimorado | Cérebro cognitivo (`ai/cognition.ts`) | Avaliações passam a registrar especialistas, dados do Nível 2 e a nota do usuário |
| Criado | `ai/nucleo.ts` | Coordenação central (antes e depois da IA), fio da conversa e adaptação de linguagem |
| Criado | `ai/planejador.ts` · `ai/especialistas.ts` · `ai/autoverificacao.ts` · `ai/proativo.ts` · `ai/feedback.ts` · `ai/avaliacao.ts` | Uma capacidade por módulo |
| Criado | `routes/inteligencia.ts` · `frontend/public/feedback-addon.js` · quadro no `panel-addon.js` · migração `031_inteligencia_nivel2.sql` | Interface e dados (tudo aditivo) |

## Como funciona em cada mensagem que chega à IA
```
ANTES  (nucleo.prepararTurno)
  fio da conversa → especialistas (até 3) → plano (novo ou em andamento) → memórias relevantes → linguagem/formato
  ⇒ bloco "NÚCLEO DE INTELIGÊNCIA (nível 2)" no texto de sistema + ferramentas na ordem dos especialistas (nenhuma removida)
IA com ferramentas (igual a antes)
DEPOIS (nucleo.concluirTurno)
  Nível 1 (ação sem confirmação, links, tom) → execução verificada no banco → plano marcado pelo retorno real
  → autoverificação (revisão pela IA uma única vez, se for necessário e houver prazo) → sugestão proativa (no máximo 1)
```

## As 10 capacidades
1. **Raciocínio contextual:** o fio da conversa diz a quem "ele/ela" se refere (pessoa citada há pouco), aponta "essa conta" ou "esse compromisso" para o item mencionado antes e percebe mudança de assunto. Também liga o pedido ao plano em andamento e às memórias.
2. **Planejamento:** pedidos com várias ações viram etapas, cada uma com ferramenta, prioridade (urgente primeiro) e dependência ("depois"). Cada etapa é marcada como feita, falhou ou aguardando confirmação, **pelo que a ferramenta realmente retornou**. Se o pedido fica parcial, o usuário vê o andamento (✓ ✗ … ○). No turno seguinte, o plano é retomado só com o que falta (vale por 6 horas). "Esquece" abandona o plano.
3. **Especialistas dinâmicos:** agenda pessoal, finanças, tarefas e lembretes, compras, memória, agenda da empresa, CRM, análise do negócio, acolhimento e conhecimento geral. O coordenador escolhe até 3 e responde "como uma só voz". Ele mantém o especialista anterior em continuações e só aciona um especialista quando o usuário tem as ferramentas dele, o que preserva as permissões.
4. **Memória inteligente:** entram até 12 memórias relevantes (todas, se houver 12 ou menos), escolhidas por assunto, uso e recência. Nome, cidade, trabalho, aniversário e nome de parentes são informações únicas: quando mudam, a memória é **atualizada**. Duplicatas não são gravadas. O uso de cada memória é registrado.
5. **Autoverificação** (só em respostas importantes: ações, finanças, negócio, CRM, planos, várias perguntas, respostas longas):
   - O que é conferido: perguntas sem resposta, valores em R$ que não aparecem nos dados (somas e diferenças são aceitas), etapas que falharam e não foram ditas, clareza e repetição.
   - Repetição é corrigida localmente.
   - Problemas de conteúdo pedem **uma** revisão à IA, sem ferramentas e dentro do prazo. A nova versão só é aceita se tiver menos problemas e passa de novo pela conferência do Nível 1.
6. **Aprendizado por feedback:** cada resposta do chat recebe 👍/👎, com motivo, comentário e a opção, desligada por padrão, de compartilhar a conversa.
   - "Longa demais" ou "curta demais" ajustam o tamanho **só para quem avaliou**. O usuário pode desfazer: `PUT /api/me/inteligencia {zerarEstilo:true}`.
   - As avaliações negativas viram **oportunidades** agrupadas por motivo, especialista e intenção.
   - O administrador envia cada oportunidade ao **Laboratório de IA** como proposta em **rascunho**. Nada muda o comportamento geral sem testes e aprovação.
7. **Proatividade:** no máximo 1 sugestão por resposta.
   - O que é sugerido: lembrete depois de agendar (se ainda não houver lembrete), conta vencendo em até 3 dias (uma vez por conta) e tarefas paradas há mais de 7 dias (no máximo a cada 3 dias).
   - Limites: intervalo mínimo de 2 horas e nada em desabafo, frustração, pressa ou quando a resposta já termina com uma pergunta.
   - "Pare de me dar sugestões" desliga e "pode voltar a sugerir" religa (também em `PUT /api/me/inteligencia`). Aceites e recusas são medidos.
8. **Execução verificada:** cada registro que uma ferramenta diz ter criado é conferido na tabela `items`. Se algo não for encontrado, o usuário é avisado. As ferramentas sensíveis continuam passando pelo portão de confirmação do Nível 1.
9. **Adaptação de linguagem:** atende a pedidos de formato ("resuma", "em tópicos", "explica como se eu fosse leigo", "em uma frase", "formal para o cliente") e à preferência pessoal vinda das avaliações. Isso se soma ao tom e ao registro do Nível 1.
10. **Avaliação contínua:**
    - Bateria automática de 28 cenários em 8 áreas.
    - Indicadores:
      - nota da semana contra a semana anterior, no geral e por dimensão;
      - taxa de avaliações positivas;
      - planos concluídos;
      - autoverificações e revisões;
      - aceite de sugestões;
      - nota por especialista.
    - Monitor que roda 90 s após o servidor subir e depois a cada 6 h e notifica os administradores (uma vez por dia) quando a nota cai 5 pontos ou mais, uma dimensão cai 8 ou mais, as avaliações positivas caem 10 pontos percentuais ou mais, ou a bateria falha.

## API
- Usuário:
  - `POST /api/chat/feedback` `{messageId, nota: 1|-1|0, motivos?, comentario?, compartilhar?}`
  - `GET /api/chat/feedback?ids=…`
  - `GET/PUT /api/me/inteligencia` `{sugestoesProativas?, zerarEstilo?}`
- Administrador (escrita exige `panel.manage` e tudo vai para a auditoria como `inteligencia.*`):
  - `GET/PUT /api/panel/inteligencia`
  - `POST /api/panel/inteligencia/bateria`
  - `POST /api/panel/inteligencia/monitor`
  - `POST /api/panel/inteligencia/oportunidades/laboratorio` `{chave, nota?}`
  - `POST /api/panel/inteligencia/oportunidades/descartar` `{chave}`

## Privacidade, permissões e segurança
- O texto das conversas só é guardado no feedback quando o usuário marca "compartilhar". O painel nunca mostra e-mails.
- Planos, preferências, sugestões e feedback são por usuário. Ninguém avalia, vê ou influencia a resposta de outra pessoa.
- Especialistas de empresa (CRM, agenda da empresa, negócio) só atuam para quem já tinha essas ferramentas.
- Nenhuma ferramenta é removida nem criada, e as validações de cada ferramenta continuam valendo.

## Reversão
- **Imediata:** chave geral ou chave de cada capacidade no painel (sem perder dados).
- **Banco:** a migração 031 é só aditiva. Para remover: `DROP TABLE assistant_plans, response_feedback, user_intel_prefs, proactive_log, intel_runs;`. As colunas novas de `cognition_evals` são opcionais.
- **Código:** retirar as chamadas a `nucleo.js` em `assistant.ts` e o bloco `save_memory` inteligente. Os módulos novos são independentes.

## Limites (honestos)
- A leitura de contexto, planos e especialistas é feita por regras sobre o português. Ela orienta e confere a IA, mas não a substitui.
- A revisão pela IA custa uma chamada extra e só acontece em respostas importantes com problema detectado e com prazo disponível.
- A proatividade cobre três situações. Outras podem ser acrescentadas no mesmo módulo.
- O monitor precisa de volume (20 respostas por semana) para comparar semanas.
- Os testes usam IA simulada. O ganho real depende do modelo configurado.
- O Nível 2 atua no chat principal. O Laboratório recebe a orientação no texto de sistema, sem gravar planos nem sugestões. O agente público de empresas não foi alterado.
