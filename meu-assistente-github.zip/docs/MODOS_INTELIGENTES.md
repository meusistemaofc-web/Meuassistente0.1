# Modos Inteligentes e Consultor de Marketing (17/11)

## Campo de digitação
- O botão ⚡ fica logo à direita do + (desde 17/11 22h52: círculo de 40px no campo em estilo caixa; ver CAMPO_DIGITACAO.md).
  - Celular: cápsula de 28px só com o raio.
  - Telas a partir de 480px: "⚡ Modos".
  - Visual: fundo azul-marinho `#071123` e ícone azul `#417CF7`.
  - O botão é injetado por `modules-addon.js` (v=120) como mais um item da linha. A altura do campo, o +, o microfone e o enviar não mudam: o teste compara com o mesmo campo sem o botão.
- **Espaço:** só o texto anda para a direita. O recuo esquerdo do texto passa de 10px para 5px apenas quando o botão está presente.
- **Limitação no celular:** num iPhone de 390pt, "Pergunte qualquer coisa" fica quase no limite. Em telas de 375pt ou menos, o final do placeholder é cortado, porque não há espaço físico para mais um botão sem mexer nos demais.
- **Campo aberto:** com texto longo, o ⚡ continua ao lado do +, na linha de baixo.

## Arquitetura (`server/src/modos/`)
- `tipos.ts` define a interface `Modo`. Cada modo tem:
  - id, nome, descrição e ícone;
  - `exclusivo` e `ferramentas`;
  - `acesso(u)`, `iniciar()` e `responder()`.
- `index.ts` concentra:
  - o registro `MODOS`;
  - o estado por conversa (`conversa_modos`);
  - o motor `processar()`, que o chat chama antes dos motores comuns.
- **Como o modo chega ao servidor:**
  - O app envia `modo` em cada mensagem: o id ativa ou mantém, `''` volta ao chat normal.
  - Sem o campo, vale o modo salvo da conversa.
  - Texto como "voltar ao chat normal" sai do modo.
- **Acesso:** conferido a cada mensagem. Se a contratação vencer, o modo é desligado e o servidor responde com o aviso de bloqueio.
- **Novo modo:** basta um arquivo com a interface e uma linha em `MODOS`. Só entram modos com capacidade real; nenhum futuro aparece como disponível.

## Consultor de Marketing (`modos/marketing.ts`)
- **Acesso:**
  - Liberado: anúncio da empresa `ativo`, não vencido, em plano de nível ≥ 4 (Loja completa).
  - Bloqueado: sem empresa, plano básico, vencido, pendente, cancelado ou suspenso.
  - Renovar ou fazer upgrade libera na hora, porque a consulta é feita direto no banco.
- **Primeira interação:** apresenta o que já conhece do cadastro e pergunta o objetivo, com 9 objetivos como respostas rápidas (`⟦opc:…⟧`). Se houver trabalho anterior, oferece continuar.
- **Coleta:**
  - Uma pergunta por vez, entre: perfil dos clientes, diferenciais, dificuldades, metas, orçamento e canais. Cada objetivo usa só as relevantes.
  - Respostas "pular" são aceitas.
  - Respostas e briefing ficam em `modo_memoria`, por empresa, e valem 120 dias, então não se repetem.
  - O público-alvo cadastrado dispensa a pergunta de perfil.
- **Consultoria:** a IA recebe:
  - dados da empresa, catálogo com preços e canais;
  - o briefing;
  - resultados reais da Central (ferramenta `central_marketing_resultados`);
  - entregas anteriores e o objetivo;
  - regras: não inventar números e honestidade sobre envios.
- **Sem IA disponível:** gera um plano básico com os dados reais.
- **Conteúdos:** legendas, textos, calendário, vídeos e datas especiais vão direto à consultoria.
- **Central de Marketing:**
  - Blocos `campanha` da resposta viram `modo_propostas` e o cartão `⟦mkprop:id⟧`.
  - "Levar para a Central (rascunho)" chama `salvarCampanha(rascunho)`, com todas as permissões da Central.
  - Nada é programado ou enviado sem o responsável fazer isso na Central.

## APIs
- `GET /api/v2/modos?c=` lista os modos com o acesso calculado e diz qual está ativo na conversa (só as do próprio usuário).
- `POST /api/v2/modos` aceita `{action:'desativar'|'verificar'}`.
- `GET|POST /api/v2/modos/propostas/:id` funciona só para o dono da proposta e com acesso válido.

## Banco
`041_modos_inteligentes.sql` (`conversa_modos`, `modo_memoria`, `modo_propostas`): só acrescenta tabelas.

## Testes
- `npm test`, teste "Modos Inteligentes…": acesso por contratação (básico, vencido, suspenso, renovado), segurança das APIs, ativação, coleta, não repetição, dados reais no contexto, proposta → rascunho sem duplicar, chat comum intacto, saída e vencimento no meio da conversa. Resultado: 293/293.
- `server/test/browser/modos_inteligentes.py`: 36/36, celular e computador.
- `composer_novo.py`: 112/112.

## Chave no painel (17/11, 23h34)
- **Onde fica:** Painel administrativo → Motor do chat → "Modos inteligentes do chat (botão ⚡)", gravada na configuração `modos_chat`. Começa ligada.
- **Desligada:**
  - O botão ⚡ some do campo de digitação para todos os usuários. O app lê o `habilitado` em `/api/v2/modos` ao abrir, ao voltar para o app e a cada minuto.
  - O servidor ignora qualquer `modo` enviado e encerra o modo das conversas, que voltam ao chat normal.
  - Planejamentos e propostas continuam guardados.
- **Religada:** o botão volta.
- **Testes:**
  - `npm test`: teste "chave no painel"; resultado 294/294.
  - `modos_inteligentes.py`: 41/41.
