# Laboratório de IA (modo administrador)

Aba **Laboratório de IA** no painel administrativo (`/admin`). Exclusiva de administradores: usuários comuns recebem 403 e anônimos 401; para escrever é preciso a permissão `panel.manage`.
Implementação **incremental**: reaproveita o Cérebro (`brain_answers`, versões, conflitos, uso) e o assistente operacional. Nenhuma tabela existente foi alterada (só a migração aditiva `021_laboratorio_ia.sql`).

## Fluxo da correção
1. No **Chat do laboratório** o administrador explica o erro e o comportamento esperado (ex.: sinal pago que não foi registrado).
2. A IA identifica a falha, interpreta a correção (IA com JSON; se indisponível, interpretação local) e monta uma **regra estruturada** (categoria, quando, então, restrições).
3. **Análise:** procura regras parecidas/duplicadas no Cérebro e conflitos (`detectConflicts`). A proposta cria um item *pendente* no Cérebro (não afeta ninguém).
4. **Testes:** o comando de cenário roda no **simulador** com a regra em teste. As ferramentas ficam desligadas: o sistema só registra o que a IA *tentaria* fazer.
5. **Enviar para aprovação → Aprovar → Publicar.** Só ao publicar o item vira diretriz **ativa** no Cérebro, e passa a orientar o chat operacional (`brainContext`).

Estados: Rascunho → Em análise → Em testes → Aguardando aprovação → Aprovada → Publicada (ou Rejeitada / Desativada). Não é possível pular etapas (a API responde 409).

## Categorias
Agendamentos, Financeiro, Pagamentos, Clientes, Serviços, Produtos, Estoque, Empresas, Agenda, Lembretes, Automação, Atendimento. A regra publicada guarda a categoria no texto e na fonte (`laboratorio:<id>:<categoria>`).

## Simulador e detecção de falhas
- Nada é gravado: nem itens, financeiro, agendamentos ou clientes (o teste do servidor confere a contagem de `items`).
- Falhas detectadas: execução **parcial**, operação **incompleta** (a regra manda registrar e a IA não chamou a ferramenta), **informação ignorada** (valor dito e ausente nas ações), **resultado diferente** (a IA diz que fez, mas não fez) e **conflito** com outra regra. Cada uma vem com sugestão de melhoria.

## Segurança
- Regra é **orientação para a IA**; nunca executa ação financeira/administrativa sozinha. O texto publicado inclui salvaguardas fixas.
- Bloqueio de riscos: contornar permissões/segurança, credenciais, apagar dados, mexer em dados de outros usuários, transferir dinheiro automaticamente. Proposta com risco não é testada nem publicada.
- Editar uma regra publicada cria rascunho: **a produção continua com a versão anterior** até nova aprovação e publicação.
- Desativar/reativar/reverter: ação do administrador; reverter cria nova versão com o texto anterior (nada é apagado).
- Auditoria: `audit_log` (`lab.*`), eventos (`lab_events`) e versões (`lab_versions`) com administrador, data/hora, testes, aprovação, versão anterior e atual.

## API (somente admin)
`GET /api/panel/lab` · `GET /api/panel/lab/:id` · `POST /api/panel/lab` com `action`: `chat`, `simular`, `criar`, `editar`, `analisar`, `testar`, `enviar`, `aprovar`, `rejeitar`, `publicar`, `desativar`, `reativar`, `reverter`.

## Limitações
- As diretrizes do Cérebro são **globais** (escopo chat / agentes / todos), não por empresa; a regra respeita as permissões porque só orienta a IA, que continua usando as ferramentas e permissões de cada usuário.
- A qualidade do teste depende da IA configurada: sem IA disponível o simulador avisa e o resto do fluxo continua funcionando.
- A avaliação de falhas é heurística (ferramentas esperadas pelo texto da regra); serve como alerta, não como prova.
- Aprovar a regra diretamente no painel do Cérebro também a publica; o Laboratório sincroniza o estado.
