# Fase 8 — Autonomia operacional e execução inteligente

O assistente agora entende objetivos do dia a dia, monta um plano em etapas, executa com os serviços que já existem, confere cada resultado no sistema e relata o que foi realmente feito. A autonomia é controlada por níveis.

A migração **035** só acrescenta a tabela `executions` e a coluna `user_intel_prefs.autonomy`. Nenhum dado existente foi migrado.

## Arquitetura

| Peça | Arquivo | Papel |
|---|---|---|
| Motor de execução | `ai/execucao.ts` | Catálogo de operações, níveis, execuções (estado, progresso, histórico, controle de versão), autorrecuperação, verificação, reversão, fila em segundo plano e indicadores |
| Planejamento autônomo | `ai/execucao-planos.ts` | Objetivos em linguagem natural viram planos com etapas, dependências e nível; conversa no chat (aprovar, autorizar, andamento, cancelar, desfazer); documentos gerados com os dados reais |
| Ferramentas da IA | `ai/execucao-ia.ts` | As ferramentas que a IA já usava passam pelos mesmos níveis e cada turno com ações vira uma execução registrada e verificada |
| Rotas | `routes/execucao.ts` | Página do usuário e painel do administrador |

### Catálogo de operações

Nada foi duplicado: toda operação chama o serviço que já existia.

| Operação | Serviço reaproveitado | Nível mínimo | Reversível | Repetível |
|---|---|---|---|---|
| Ativar lembrete de compromisso | `appointment_update` (com histórico) | 1 | sim | sim |
| Criar lembrete (alternativa segura) | `createItem` | 1 | sim | não* |
| Alterar situação de compromisso | `appointment_update` | 2 | sim | sim |
| Excluir compromisso | `itemAction delete` | **3** | recria o registro | sim |
| Criar tarefa | `createItem` (com cota do plano) | 1 | sim | não* |
| Concluir tarefa | `task_status` | 1 | sim | sim |
| Excluir tarefa | `itemAction delete` | **3** | recria o registro | sim |
| Criar ou gerar documento (nota) | `createItem note` | 1 | sim | não* |
| Marcar conta como paga | `pay_bill` / `unpay_bill` | **3** | sim | sim |
| Criar tarefa no CRM | `CRMTaskService.criar` (acesso do dono) | 1 | sim (cancela) | não* |
| Consultar dados | leituras existentes | 1 | — | sim |

\* As operações não repetíveis sabem **localizar** o próprio resultado. Depois de uma queda, o motor confere se a operação já aconteceu antes de decidir repetir.

### Objetivos reconhecidos (linguagem do dia a dia)

Os objetivos são reconhecidos pelo chat e também pela IA, por meio da ferramenta `executar_objetivo`:

- "crie lembretes para os compromissos de amanhã / de hoje / da semana";
- "marque como concluídos os compromissos que já passaram";
- "organize minha semana": lê a agenda e as previsões, gera o documento "Plano da semana" e cria tarefas para os alertas urgentes;
- "faça um relatório financeiro do mês";
- "apague as tarefas concluídas" e "apague os compromissos cancelados";
- "marque as contas de luz e água como pagas";
- "crie tarefas de acompanhamento para os leads/clientes" (CRM, só para o dono).

## Níveis de autonomia (item 5)

| Nível | O que é | Como o usuário aprova |
|---|---|---|
| 1 — automação autorizada | consultas, análises e operações reversíveis | executa direto |
| 2 — confirmação | alterações relevantes (mudar situação, remarcar, cancelar pela IA) | "sim" no chat ou o botão "Confirmar" |
| 3 — autorização explícita | exclusões, pagamentos e valor recebido | **"autorizo EX-XXXXXX"** no chat ou o código digitado na página. Um "sim" não basta. |

- O **administrador** pode exigir mais controle numa operação, mas nunca reduzir o mínimo dela. Exclusões e pagamentos ficam sempre no nível 3.
- O **usuário** pode escolher o modo **cauteloso**, em que toda alteração pede confirmação.
- **Permissões existentes** continuam valendo: módulos desligados no painel, acesso do dono ao CRM e cotas do plano.
- As **ferramentas da IA** seguem a mesma tabela. `update_appointment` com cancelamento ou nova data fica no nível 2; com valor recebido, no nível 3. As ferramentas que já tinham confirmação própria (decisões de agenda da empresa, etapa do CRM) não perguntam duas vezes.

## Execução segura (itens 6, 9 e 10)

- **Identificação:** cada execução recebe um **identificador único** (`EX-XXXXXX`), mostrado ao usuário.
- **Pedido repetido:** o mesmo pedido em menos de 10 minutos devolve a mesma execução, em vez de criar outra.
- **Concorrência:**
  - toda troca de estado só acontece se a versão não mudou (controle de versão);
  - a mesma execução nunca roda em paralelo no mesmo processo;
  - cada usuário tem um limite de execuções simultâneas.
- **Validação** antes de executar: o registro existe, os dados estão completos e o registro não mudou desde o planejamento (senão, conflito).
- **Registro:** cada evento fica no histórico da execução e as decisões ficam na auditoria.
- **Memória operacional:** plano, estado de cada etapa, resultados e pendências ficam guardados. Uma execução interrompida (queda do processo) é **retomada** de onde parou.
- **Verificação:** cada etapa é conferida no estado real do sistema. Sem confirmação, a etapa **não** conta como feita, e a execução não é dada como "concluída".
- **Reversão:** desfaz na ordem inversa o que for tecnicamente reversível. Exclusões são desfeitas recriando o registro, que ganha um novo identificador.

## Autorrecuperação (item 7)

1. **Classifica** o erro: dados inválidos, sem permissão, conflito, não encontrado, falha temporária, limite do plano ou inesperado.
2. **Repete** só falhas temporárias de operações repetíveis, até 3 vezes com espera. Uma operação que duplicaria não é repetida às cegas: primeiro procura o resultado.
3. Tenta uma **alternativa segura** declarada pela operação. Exemplo: compromisso sem horário recebe um lembrete às 08:00 do dia.
4. **Interrompe** as etapas seguintes quando uma operação crítica falha (risco de inconsistência). As etapas que dependem de uma que falhou ficam bloqueadas; as independentes continuam.
5. **Comunica o resultado real:** "concluída e conferida", "fiz uma parte", "parei" ou "não consegui", com cada etapa marcada como ✓ conferida ou ✗ (com o motivo).

## Segundo plano (item 8)

- Objetivos longos (mais de 5 etapas, "organizar a semana", relatório) rodam numa **fila em segundo plano**, sem prender o chat.
- O usuário acompanha o identificador, o status, o progresso e o histórico pela página ou pelo chat ("como está a tarefa?").
- Ao terminar, recebe uma notificação.
- O **cancelamento é seguro**: a etapa em andamento termina e as próximas não são feitas. O que já foi feito pode ser desfeito.

## Experiência (item 11)

O usuário pede com as próprias palavras, sem conhecer módulos. No chat:

- "sim" aprova o nível 2 e "autorizo EX-…" aprova o nível 3;
- "cancela" desiste;
- "como está a tarefa?" mostra o andamento;
- "desfaz isso" pede confirmação e desfaz.

A página **Minhas execuções** (`/execucoes`, atalho em Configurações) mostra o plano, o progresso, as etapas conferidas e os botões de confirmar, autorizar (com o código), cancelar e desfazer. Também é ali que se escolhe o modo cauteloso.

## Monitoramento (item 12)

O painel fica em Cérebro e busca → **Autonomia operacional** e mostra só números:

- tarefas executadas, concluídas, pendentes e com falha;
- canceladas e desfeitas;
- operações que exigiram confirmação ou autorização, e quantas foram aprovadas;
- tempo médio e taxa de sucesso;
- etapas verificadas e repetidas;
- falhas por causa e resultado por objetivo.

Ações disponíveis:

- ligar e desligar a execução e o segundo plano;
- limite de execuções simultâneas por usuário;
- níveis por operação (só para mais).

## Testes (item 13)

- **Servidor**, 7 testes novos:
  - **unidade**: catálogo, níveis e classificação de erros;
  - **integração**: chat → plano → execução verificada → desfazer;
  - **permissões e segurança**: níveis 2 e 3, código, outra pessoa, expiração, módulo desligado e painel sem conteúdo;
  - **concorrência e idempotência**: execução tripla simultânea, aprovação dupla e retomada sem duplicar;
  - **autorrecuperação**: repete o seguro, não repete o que duplica, interrompe, bloqueia e não declara sem verificar;
  - **segundo plano**: aviso ao terminar, cancelamento no meio e reversão;
  - **IA**: níveis e registro das ações.
- **Navegador**: `test/browser/autonomia_operacional.py`, com 17 verificações.
- **Regressão completa.**

Durante os testes, a verificação no sistema **revelou um defeito real**: alterar só o lembrete de um compromisso não era gravado. A edição era tratada como "sem mudanças" porque o histórico não considerava esse campo. Foi corrigido em `routes/items.ts`. Também foi corrigido o reconhecimento de "marque…".

Desempenho: as configurações novas (execução, previsões e aprendizado) passaram a ser lidas uma vez por requisição, e a análise preditiva usada nas sugestões do chat fica 5 minutos em cache. O teste de consultas por mensagem com IA (limite de 45; antes das fases 1 a 3 eram 72) continua passando.

## Como reverter

| Nível | Como |
|---|---|
| Uma execução | "desfaz isso" no chat ou o botão "Desfazer" na página |
| Usuário | Modo cauteloso em Minhas execuções |
| Uma operação | Painel → Autonomia operacional → elevar o nível |
| Tudo | Painel → desligar "Execução automática": o chat volta ao comportamento anterior |
| Banco | `DROP TABLE executions;` (a coluna `autonomy` pode ficar) |

## Limites

- **Catálogo fechado:** o motor executa só as operações do catálogo, sobre os módulos existentes. Pedidos fora dele continuam com a IA, cujas ferramentas também passam pelos níveis.
- **Sem envio a terceiros:** não envia mensagens a clientes, porque não há uma integração de envio. Se for adicionada, fica no nível 2.
- **Exclusões revertidas:** o registro recriado ganha um novo identificador.
- **Retomada após queda:** é feita pela própria aplicação a cada 3 segundos. Em vários servidores, o controle de versão impede que duas instâncias executem a mesma etapa.
