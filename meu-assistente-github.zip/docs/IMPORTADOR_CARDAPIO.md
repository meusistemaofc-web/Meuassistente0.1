# Importador de Cardápio com IA

Empresas → Produtos → **Cadastro manual** | **Importar cardápio com IA** | **Histórico de importações**. O cadastro manual não mudou.

## Fluxo
1. **Envio** (câmera, galeria, JPG/PNG/WEBP, PDF, DOCX; até 12 arquivos de 12 MB — várias páginas). O formato é validado pelo conteúdo (magic bytes), não pela extensão. Fotos grandes são reduzidas no aparelho.
2. **Leitura assíncrona** (fila em processo, com progresso e etapas: "Analisando seu cardápio…", "Identificando produtos e preços…", "Organizando categorias…", "Preparando seu catálogo…"). Usa o motor multi-IA existente (`askFiles`, IA com visão). Se nenhuma IA com visão ler: PDF → texto embutido; foto → OCR (OCR.space, já existente); DOCX → texto do `word/document.xml`; depois qualquer IA de texto interpreta. Sem dependências novas.
3. **Rascunho para revisão**: itens por categoria com nome, preço, descrição, variações, adicionais, disponibilidade, observações e **confiança**. Itens duvidosos (confiança < 70%, sem preço, dúvida declarada, adicional de valor incompatível) ficam destacados, desmarcados e **só são cadastrados se o responsável conferir e confirmar**.
4. **Descrições**: a original (do documento) é separada da **sugerida pela IA** (só quando o documento tem apenas nome e preço, sem inventar ingredientes). No produto fica `origem.descricaoOrigem = original | ia | manual`.
5. **Duplicidades** (mesma empresa; nome normalizado/similar + categoria): *Atualizar existente*, *Manter existente* ou *Cadastrar como novo*. Sem decisão = **manter** (nunca sobrescreve em silêncio). Atualizar preserva fotos, etiquetas e demais campos.
6. **Publicação** (somente após confirmação): usa o serviço único `salvarProduto` (o mesmo do cadastro manual: mesmas validações, plano Loja completa, tipo de catálogo), numa transação, com reivindicação atômica (publicar duas vezes → 409). Preços conferidos com a regra real `unitPrice` (tamanho substitui o preço; adicionais somam — viram o grupo "Adicionais" com "Sem adicional").
7. **Reversão**: "Desfazer importação" remove o que ela criou e restaura o que atualizou.

## Segurança e integridade
Só o dono da empresa; importação de outra empresa = 404; produtos sempre associados à empresa da URL; auditoria (`cardapio.importar.iniciar|publicar|retomar|cancelar|reverter`); importação idêntica (hash do conteúdo) não é repetida; arquivos são apagados do banco após a leitura (retenção mínima; limpeza ao subir o servidor); importações interrompidas são retomadas ao reiniciar e podem ser retomadas pelo usuário ("Tentar novamente" refaz só o que falhou).

## Agentes de IA
Os agentes leem a tabela `products` em tempo real (catálogo, preços, variações, adicionais, pedidos): produtos importados/atualizados valem sem retreinar nada.

## Estrutura
Migração `029_importador_cardapio.sql` (`menu_imports`, `menu_import_files`, `menu_import_products`); `src/lib/menu-import.ts`; `src/routes/menu-import.ts`; `frontend/public/menu-import-addon.js`. Rotas: `/api/v2/ads/:id/menu-imports[/:iid/(arquivos|iniciar|publicar|retomar|cancelar|reverter)]`.

## Limites
Imagens por produto: o cardápio não permite recortar fotos de itens — a foto é opcional e pode ser anexada na revisão. Produtos importados podem ficar sem foto (o cadastro manual continua exigindo). A fila roda no processo do servidor (retoma ao reiniciar).

## Layout limpo da aba Produtos ("Sua loja")
Mudança só visual.

**O que ficou:**
- **Os três botões do topo:** Cadastro manual, ✨ Importar cardápio com IA e Histórico de importações, cada um abrindo a sua função como antes.

**O que saiu:** o **card** que aparecia abaixo deles, ou seja, a caixa com fundo, borda e espaçamento interno.
- **Conteúdo direto na página:** o conteúdo de cada modo aparece logo abaixo dos botões, alinhado a eles: o formulário "Novo/Editar produto", o envio de fotos/PDF/DOCX com análise e revisão, e a lista do histórico.
- **Títulos repetidos:** saíram os títulos que só repetiam o nome do botão selecionado ("Importar cardápio com IA" e "Histórico de importações"). O "Novo produto"/"Editar produto" continua, porque diz se é cadastro ou edição.

**O que não mudou:**
- **Funcionamento:** os mesmos campos, botões, serviços, endpoints e regras do cadastro manual, da importação com IA e do histórico.
- **Banco e outras seções:** nenhum dado foi alterado e nenhuma outra seção da plataforma mudou.

**Testes:** `importar_cardapio.py` ganhou 6 verificações:
- os três botões mantidos;
- os três modos sem card, verificados no próprio estilo da página (sem caixa, borda ou fundo);
- sem títulos repetidos;
- as funções continuam disponíveis;
- sem rolagem horizontal.

**Como reverter:**
- **Importação e histórico:** em `menu-import-addon.js`, voltar `<div class="mi-body mb-3 px-1" id="mi_body">` para `<div class="glass mb-3 rounded-[1.6rem] p-5" id="mi_body">` e os dois títulos.
- **Cadastro manual:** em `modules-addon.js`, voltar `mi-form px-1` para `glass rounded-[1.6rem] p-5`.
- **Versões:** em `server/src/app.ts`, voltar `?v=2` para `?v=1` e `?v=110` para `?v=109`.
