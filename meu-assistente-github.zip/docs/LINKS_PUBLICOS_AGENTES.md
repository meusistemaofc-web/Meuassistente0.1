# Links públicos dos agentes

Formato: `https://meuassistente.chat/nome-da-empresa` (sem prefixo `/g-`). Ex.: "Ivaslovck Tattoo" → `https://meuassistente.chat/ivaslovck-tattoo`.

## Geração
Minúsculas, sem acentos e caracteres especiais (`&` vira "e"), espaços → hífen, hífens duplicados removidos, até 48 caracteres (`slugify` em `lib/publicurl.ts`).
O domínio vem de Painel → Domínio oficial.

## Exclusividade
* Nome repetido: o sistema gera uma alternativa exclusiva (`nome-2`, `nome-3`…) **sem alterar o nome comercial**.
* O dono pode **personalizar** o endereço em Agente de atendimento → Link para seus clientes → *Personalizar endereço* (mín. 3 caracteres; recusa endereço de outra empresa, antigo de outra empresa ou reservado). Endereço personalizado não muda sozinho se o nome da empresa mudar.
* **Reservados** (nunca viram endereço de empresa): rotas e arquivos do app (`admin`, `api`, `x`, `financeiro`, `assets`, `agente`…). Lista em `RESERVED_SLUGS`. Arquivos existentes na pasta pública também têm prioridade.

## Compatibilidade
* `/g-<nome>` (links já compartilhados) e `/a/<id>` respondem **301** para `/<nome>`; uma empresa cujo nome começa com "g-" abre normalmente.
* Ao trocar o endereço, o anterior continua redirecionando/abrindo (guardados em `slugsAntigos`).
* Os identificadores existentes foram mantidos; só o formato do link mudou. O botão flutuante, "Compartilhar link", "Abrir" e a visualização usam o novo formato automaticamente.

## API
`PUT /api/v2/ads/:id/slug` `{ slug }` (dono) → `{ slug, link }`; `GET /api/v2/ads/:id/agent` devolve `link` no novo padrão.
