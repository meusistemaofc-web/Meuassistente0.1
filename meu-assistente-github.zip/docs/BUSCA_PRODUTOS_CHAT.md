# Modo Inteligente de Busca de Produtos e Serviços (chat principal)

O chat do Meu Assistente encontra **produtos e serviços reais** cadastrados nas empresas e lojas conectadas e mostra os resultados em **cards compactos** dentro da própria conversa. O modo faz parte dos **Modos Inteligentes** (botão ⚡), mas não precisa ser escolhido: ele liga sozinho quando a mensagem mostra que a pessoa está procurando algo.

## Quando liga sozinho

Liga com intenção clara de busca ou compra:

- "quero encontrar…", "quero comprar…", "preciso encontrar…"
- "buscar produto…", "procurar…", "procuro…", "busco…", "estou procurando…"
- "onde comprar…", "onde posso encontrar…"
- "encontre para mim…", "me ajuda a encontrar…"
- "quem vende…", "alguma loja que vende…"

**Não liga** em conversa comum nem em pedidos que não são compra, por exemplo:

- "oi, tudo bem?", "qual a capital da França?"
- "buscar meu filho na escola", "procurar minhas notas"
- "como fazer bolo de chocolate", "quanto gastei este mês?"
- lembretes e compromissos ("me lembra de…", "tenho dentista amanhã às 14h")

Pelo seletor ⚡ → **Busca de produtos e serviços**, o assistente pergunta "O que você procura?".

## Como a busca funciona (dados reais)

- **Origem dos itens:** catálogos das lojas, com as mesmas regras da vitrine: só empresas aprovadas e ativas, com plano de catálogo, módulos ligados e dentro do raio de atendimento. Itens desativados não aparecem.
- **Campos considerados:** nome, palavras-chave, categoria, variações, descrição, nome e categoria da empresa. O nome pesa mais que a descrição.
- **Tolerância:**
  - erros de digitação ("brigadero" → brigadeiro, com o aviso *entendi "brigadeiro"*);
  - plural ("cães" = cão);
  - sinônimos ("cachorro" = cão, "pet", etc.);
  - começo de palavra;
  - descrições ("doce de chocolate belga").
- **Semelhantes:**
  - sem item exato, a resposta diz isso honestamente e mostra os mais parecidos;
  - com resultado, os parecidos aparecem num grupo separado, **"Também podem te interessar"**.
- **Filtros na própria frase:**
  - preço máximo ("até 50 reais");
  - "mais barato" / "menor preço";
  - "mais perto";
  - "em promoção";
  - "só serviços" / "só produtos".
- **Ordem:** relevância primeiro; depois disponíveis antes de esgotados e lojas que atendem a região. Esgotados continuam aparecendo, marcados.
- **Localização:**
  - com localização, mostra a distância e respeita o raio de cada loja;
  - sem localização, busca em todas as lojas e mostra o botão **Usar minha localização**.
- **Sem resultado:** "Não encontrei … nas lojas parceiras perto de você", com o botão **Ver a vitrine**. Nada é inventado.

## Continuando a conversa (modo ativo)

- "mais barato", "mais perto", "em promoção", "até 30 reais": refinam a última busca.
- "e de morango?", "com cobertura": completam a busca anterior.
- "mais opções": mostra a próxima página (6 por vez).
- Um nome solto ("brigadeiro") vira uma nova busca.
- **Outro assunto** (lembrete, agenda, finanças, cumprimento) desliga o modo, e o chat comum responde normalmente.

## Cards

Cada card mostra:

- imagem;
- nome;
- preço, com o valor normal riscado e o percentual quando está em oferta, ou "a partir de"/"sob orçamento" quando é o caso;
- empresa, distância e se está aberta agora;
- disponibilidade: Disponível, Últimas N unidades, Última unidade, Esgotado; para serviços, Agenda aberta ou Agende pelo app.

Botões:

- **Comprar** (produto) ou **Agendar** (serviço) abre o item na página da loja (`/x/empresa/:id?produto=` ou `?servico=`);
- **Catálogo** abre a loja.

Os dados dos cards são lidos **na hora** (`GET /api/v2/busca/cards?ids=p12,s33`, com login): preço, estoque e horário estão sempre atualizados, e itens que saíram do ar somem do card.

## Convivência com a busca de empresas

Palavras que só existem como palavra-chave de **empresa** (por exemplo, um estúdio cadastrado com "microblading") continuam indo para a busca de empresas de sempre (cards de empresas). Quando há produto ou serviço correspondente, o modo de busca responde. Pedidos como "quero fazer um piercing na orelha" seguem como antes.

## Administração

- O modo respeita os módulos **Empresas** e **Catálogo** do painel: com qualquer um deles desligado, a busca não liga, e o seletor ⚡ mostra o modo como indisponível.
- O interruptor geral dos Modos Inteligentes também vale para este modo.

## Arquivos

- `server/src/lib/busca-itens.ts`: detecção de intenção, leitura da frase (termos, preço, ordem, filtros), correspondência aproximada (distância de edição, radicais, sinônimos) e ranqueamento.
- `server/src/modos/busca.ts`: o modo (ativação, refinamentos, saída, respostas e cards).
- `server/src/routes/businesses.ts`: `itensPublicos()`, os itens públicos com as regras da vitrine.
- `server/src/modos/index.ts`: ativação automática pelo `detectar()` de cada modo.
- `frontend/public/modules-addon.js`: marcador `⟦bp:ids|título⟧` e cards compactos.

## Testes

- Servidor (`test/run.ts`): "chat: Modo Busca de produtos e serviços…". Cobre intenção, falsos positivos, digitação, sinônimos, descrição, preços, ofertas, ordem, semelhantes, esgotado, refinamentos, saída por outro assunto, busca de empresas, sem localização, item fora do ar, seletor ⚡ e módulo desligado.
- Navegador (`test/browser/busca_produtos_chat.py`): tela real no celular e no computador, 27 verificações.
