# Cupons e Vouchers para a ativação de anúncios

Códigos promocionais criados pelo administrador para influenciadores, parceiros, clientes e campanhas. Quem cria um anúncio usa o código e recebe automaticamente um destes benefícios:

- desconto;
- período gratuito;
- acesso vitalício.

## Auditoria (antes)

- **Fluxo de anúncio:**
  1. O anúncio é criado em **Anunciar** com o status `pagamento`.
  2. O usuário paga um Pix pelo Mercado Pago (`/api/v2/ads/:id/pay`).
  3. O webhook ou a consulta confirma o pagamento pela API do Mercado Pago e o anúncio segue para aprovação manual ou automática.
  4. `activate()` coloca o anúncio no ar por `plano.dias`.
  5. Ao vencer, o usuário renova pelo mesmo caminho.
- **Cupons existentes:** os "Cupons de desconto" são das **lojas para os clientes delas** (`coupons`). Não têm relação com a ativação de anúncios e **não foram alterados**.
- **Banco:** PostgreSQL, sem transações no adaptador. A atomicidade foi garantida com `UPDATE … WHERE … RETURNING` condicional e índices únicos, que funcionam igual no PostgreSQL e no SQLite dos testes.

## Painel administrativo: **Administração → Cupons e Vouchers**

### Cupons
- Busca e filtros por situação e campanha.
- Cada cupom mostra:
  - código;
  - benefício;
  - situação: ativo, pausado, cancelado, agendado, campanha encerrada, expirado ou esgotado;
  - utilizações (x/máx);
  - limite por usuário;
  - datas e restrições.
- Ações:
  - **Resgates e histórico** (quem resgatou e eventos do cupom);
  - **Editar**;
  - **Pausar/Ativar**;
  - **Cancelar** (com confirmação);
  - **Copiar código**.

### Novo cupom
- **Código:** manual, ou deixado em branco para geração automática (8 caracteres sem 0/O/1/I). É possível **gerar em lote** (até 500 códigos com prefixo, agrupados por campanha).
- **Campanha** e **descrição interna**.
- **Benefício:**

  | Modalidade | Efeito |
  |---|---|
  | **Desconto percentual** (1–100%) | O valor final é calculado no servidor; 100% ativa sem pagamento |
  | **Período gratuito** (dias ou meses) | A ativação não é cobrada e o anúncio fica no ar pelo período; depois, a renovação segue o preço normal |
  | **Acesso vitalício** | O anúncio não vence e não há renovações |

  > Os itens B ("anúncio gratuito por período") e D ("acesso gratuito por período determinado") do pedido têm, neste sistema, o mesmo efeito: o anúncio fica no ar sem cobrança pelo período e depois volta às regras normais. Por isso viraram **uma única modalidade**, que aceita dias ou meses (7 dias, 30 dias, 3 meses, 12 meses…).

- **Regras de utilização:**
  - máximo de utilizações (ou ilimitado);
  - máximo por usuário;
  - **uso único**;
  - início e encerramento da campanha;
  - **validade individual do código**;
  - planos aceitos;
  - ramos aceitos.

### Editar respeitando o que já foi usado
- Depois do primeiro uso, o **código e o benefício ficam travados**.
- Descrição, limites (nunca abaixo do já usado), datas e restrições podem mudar.
- Cancelado não volta a ficar ativo.

### Histórico de resgates
- **Filtros:** código, usuário (nome ou e-mail), campanha, período (de/até) e situação.
- **Cada linha mostra:**
  - código;
  - usuário e e-mail;
  - anúncio beneficiado e plano;
  - data e hora;
  - benefício, percentual, período e indicação de vitalício;
  - valor original → valor final;
  - **valor economizado**;
  - situação (reservado, resgatado, liberado);
  - quando o benefício foi aplicado e até quando.
- **Totais:** resgates, reservas em aberto e economia concedida.

Acesso exige **administrador com a permissão de anúncios** (`ads.manage`): sem login, "não autorizado"; usuário comum, "acesso negado".

## Página Anunciar: "Tenho um cupom"

- Um link discreto, com ícone de cupom, logo acima do botão **"Continuar para o pagamento"**. O campo começa **fechado**.
- Ao tocar, abrem o campo do código, o botão **Aplicar cupom** e, depois de aplicado, **Remover cupom**.
- **Validação no servidor:**
  - o cupom existe;
  - está ativo (não pausado, cancelado, agendado, encerrado ou expirado);
  - ainda há utilizações;
  - limite por usuário;
  - plano e ramo aceitos.
- **Motivos claros:** "Cupom não encontrado…", "Este cupom expirou.", "Você já utilizou este cupom.", "Este cupom não vale para o plano escolhido." etc.
- **Confirmação visual:**
  - "✓ Cupom aplicado! Você recebeu 50% de desconto.";
  - "✓ Cupom aplicado! Seu anúncio ficará gratuito por 30 dias.";
  - "✓ Cupom aplicado! Você recebeu acesso vitalício.".
- **Valor:** aparece o valor original riscado e o novo valor (ou "Grátis"). Trocar de plano recalcula pelo servidor.
- **Envio:** o código vai junto com o anúncio. O servidor valida de novo, cria o anúncio e **reserva** a utilização.

## Sua empresa (anúncio aguardando pagamento)

- Mostra o cupom aplicado e o valor.
- Dá para aplicar ou remover um cupom ali também, inclusive em renovações.
- **Desconto parcial:** botão "Pagar R$ X com Pix" com o **valor já descontado**.
- **Gratuidade** (100%, período gratuito ou vitalício): botão **"Ativar sem pagamento"**. **Nenhum Pix é gerado** e o anúncio segue o mesmo caminho de um pago (aprovação manual ou automática).
- **Anúncio no ar:** mostra "🎟 Cupom X · benefício · economia" e "acesso vitalício" no lugar da data.

## Segurança e integridade

- **O navegador nunca define o preço:** o valor do Pix é o preço do plano menos o cupom, calculado no servidor no momento da cobrança.
- **Limite total:**
  - `UPDATE ad_vouchers SET uses = uses + 1 WHERE … AND uses < max_uses RETURNING`;
  - só uma requisição leva a última utilização;
  - teste com 6 pessoas disputando ao mesmo tempo: 1 sucesso.
- **Limite por usuário:** linha única (cupom, usuário) com incremento condicional.
- **Um cupom por anúncio:** índice único parcial; o mesmo cupom não é reaplicado.
- **Reserva:**
  - aplicar reserva a utilização por **48 h**;
  - se o anúncio não for pago ou ativado nesse prazo, a reserva é liberada e a utilização volta ao limite;
  - remover o cupom também libera.
- **Pix antigo:** ao aplicar ou remover um cupom, o Pix pendente é descartado e o próximo sai com o valor novo.
- **Valor pago menor que o devido** (ex.: gerar o Pix com desconto, remover o cupom e pagar o Pix antigo): o anúncio **não é ativado**, o caso fica registrado e os administradores recebem aviso.
- **Benefício não se perde:**
  - o resgate guarda uma "fotografia" do benefício (tipo, %, período, valores);
  - a aplicação ocorre uma única vez, na ativação, inclusive quando o administrador aprova depois;
  - o vitalício é mantido em reativações.
- **Nada retroativo:** editar, pausar ou cancelar um cupom não muda o que já foi concedido.
- **Auditoria:**
  - `audit_log`: `cupom_anuncio.criar/editar/status`, `cupom.aplicar/remover/ativar_gratis`;
  - `ad_voucher_events`: criado, editado, status, aplicado, removido, expirado, resgatado, benefício aplicado.

## Banco: migração `046_vouchers_anuncio.sql`

A migração é só aditiva. As instruções para desfazê-la estão no cabeçalho do arquivo.

| Tabela | Conteúdo |
|---|---|
| `ad_vouchers` | Códigos e regras |
| `ad_voucher_user_uses` | Contador por usuário |
| `ad_voucher_redemptions` | Reservas e resgates, com a "fotografia" do benefício |
| `ad_voucher_events` | Histórico de cada cupom |

## APIs

| Rota | Quem | Função |
|---|---|---|
| `POST /api/v2/ads/cupom/verificar` | Usuário logado | Prévia na página Anunciar (não consome) |
| `POST /api/v2/ads` (campo `cupom`) | Usuário | Cria o anúncio e reserva o cupom |
| `POST /api/v2/ads/:id/cupom` | Dono do anúncio | `{acao: aplicar \| remover \| ativar}` |
| `GET/POST /api/v2/admin/vouchers` | Admin (`ads.manage`) | Listar / criar (inclui lote) |
| `GET/PUT /api/v2/admin/vouchers/:id` | Admin | Detalhe (resgates e eventos) / editar ou mudar a situação |
| `GET /api/v2/admin/vouchers-historico` | Admin | Histórico com filtros e totais |

## Testes

**Servidor** (`server/test/run.ts`), 4 testes novos:
1. **Administração:**
   - acesso;
   - validação;
   - código manual (normalizado) e duplicado;
   - lote de 3 códigos únicos;
   - gratuito em dias e em meses;
   - vitalício;
   - agendado, vencido, plano e ramo restritos;
   - datas inválidas;
   - filtros.
2. **Desconto parcial:**
   - prévia com o valor certo;
   - motivos de recusa;
   - criação com código inválido não cria nada;
   - reserva na criação;
   - **Pix com o valor calculado no servidor** (o valor enviado pelo navegador é ignorado);
   - webhook confirma o resgate;
   - aprovação aplica o benefício e o registra no anúncio;
   - limite por usuário;
   - benefício travado após o uso;
   - nada retroativo;
   - detalhe com resgates e eventos.
3. **Gratuidade e regras de uso:**
   - gratuidade sem nenhuma cobrança e "Ativar sem pagamento" (uma vez só);
   - 30 dias no ar;
   - vitalício até 2999 e sem renovação;
   - uso único;
   - remover devolve a utilização e descarta o Pix;
   - cupom esgotado;
   - reserva vencida liberada;
   - **tentativa de pagar o Pix com desconto depois de remover o cupom: não ativa**;
   - pausar e cancelar;
   - **última utilização disputada por 6 pessoas: só 1 leva**.
4. **Histórico e auditoria:** filtros (código, usuário, campanha, período), valores economizados e auditoria completa.

**Navegador** (`server/test/browser/vouchers_anuncio.py`), 20/20:
- painel (criar manual, gratuito e lote; filtro de campanha);
- celular, página Anunciar:
  - campo fechado por padrão;
  - erro claro;
  - 50% com R$ 29,90 → R$ 14,95;
  - troca de plano recalculada;
  - remover;
  - gratuito;
- Sua empresa: "Ativar sem pagamento", sem Pix;
- aprovação e benefício no anúncio;
- histórico com filtro, detalhe e pausa;
- sem erros de JavaScript e sem rolagem lateral.

> **Concorrência:** os testes rodam no SQLite, que atende uma escrita por vez. No PostgreSQL da VPS, o `UPDATE` condicional trava a linha do cupom, e o resultado é o mesmo: a última utilização vai para uma única pessoa.

## Arquivos

**Novos:**
- `server/migrations/046_vouchers_anuncio.sql`
- `server/src/lib/vouchers.ts`
- `server/test/browser/vouchers_anuncio.py`
- `docs/CUPONS_VOUCHERS_ANUNCIOS.md`

**Alterados:**

| Arquivo | Mudança |
|---|---|
| `server/src/routes/ads.ts` | Cupom na criação; valor do Pix com o cupom; confirmação no pagamento; benefício na ativação; conferência de valor pago; rotas do usuário e do administrador |
| `server/src/app.ts` | Rotas; `modules-addon.js?v=137`; `panel-addon.js?v=154` |
| `frontend/public/modules-addon.js` | "Tenho um cupom" em Anunciar e em Sua empresa; "Ativar sem pagamento"; benefício no anúncio |
| `frontend/public/panel-addon.js` | Aba **Cupons e Vouchers** |
| `server/test/run.ts` | 4 testes novos |

**Sem alteração:**
- cupons das lojas;
- Mercado Pago (credenciais e webhook seguem iguais; só o valor passa a considerar o cupom);
- anúncios existentes;
- planos.

## Publicação

Suba no GitHub e rode o `update.sh` de sempre. A migração 046 roda sozinha.
