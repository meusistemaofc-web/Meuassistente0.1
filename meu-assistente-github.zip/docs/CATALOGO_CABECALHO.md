# Catálogo público — apresentação da empresa (17/11)

Página: `/x/empresa/:id` (função `viewEmpresa` em `frontend/public/modules-addon.js`, v=117). Só o bloco de apresentação mudou.

## O que mudou
- **Capa e logo separadas:** a logo não fica mais sobre a capa; vem logo abaixo, com ~12px de espaço.
  Capa: 128px no celular, 170px a partir de 768px (antes 140px fixos + logo invadindo).
- **Identidade em linha:** `[logo 64px] Nome / Categoria · Distância / Status`.
  - Nome em destaque: 1,3rem, ou 1,6rem no computador; até 2 linhas.
  - Categoria e distância em 13px cinza.
  - Status em verde quando aberta e em vermelho quando fechada. Sem status, mostra o horário.
- **Ícones de contato** (Localização, WhatsApp, Instagram) à direita do nome — localização e WhatsApp só com o contorno de fora (parte de dentro limpa, pedido de 17/11 21h29); Instagram como estava:
  - outline de traço 1,5, brancos (no tema claro, a cor do texto, para continuar visíveis);
  - sem círculo, fundo ou borda;
  - área de toque de 36px;
  - mesmos links, mesmo `data-hit` (contagem de cliques) e mesmo botão do mapa (`#locbtn`).
- Em telas estreitas (< 390px) ou com nome longo, os ícones descem para a linha de baixo, alinhados ao texto.
- **Compactação:** descrição, cupons e "Site" logo abaixo, com espaçamentos menores.
  O primeiro produto subiu de 580px para ~463px no celular (390×844).

## O que não mudou
Busca, categorias, cards, preços, botões de adicionar/agendar, carrinho, pedidos, mapa, tema da empresa e dados cadastrados.
Os ícones das listas de empresas (`bizBtns`) e o restante do app continuam iguais.

## Testes
- `server/test/browser/catalogo_cabecalho.py`: 45/45 — celular, celular pequeno, computador, nome longo, loja fechada e tema claro.
- `tema_catalogo_agente.py` 63/63, `cupons.py` 22/22, `descricoes_expansiveis.py` 29/29.
