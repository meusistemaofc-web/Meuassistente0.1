# Compromissos — edição individual, agendamento inteligente pelo chat e sincronização

Esta foi uma correção do módulo existente, sem reconstruí-lo. Os compromissos continuam na tabela `items` (`type = 'appointment'`). Não houve migração nem alteração dos registros existentes.

## Diagnóstico

| # | Problema | Causa | Correção |
|---|---|---|---|
| 1 | Editar um compromisso alterava **outro** | A tela da Agenda identificava o compromisso tocado **pelo título e horário** e pegava o primeiro. Com dois "Tatuagem 14:00" em dias diferentes, abria e salvava sempre o primeiro. No servidor, a atualização já era feita por id e dono. | O painel abre pelo **identificador** da linha. Sem o id, abre só se houver um único compromisso compatível; com vários, pergunta qual. |
| 2 | O chat perdia cliente, telefone, valor, sinal e observação | O motor de agendamento lia só serviço, data, hora, local e pessoa | Novo `ai/agendamento-chat.ts`, ligado ao motor existente (`convctx.ts`) |
| 3 | A situação sempre aparecia como "Agendado" | O status não era enviado pela API | `status` e `statusLabel` agora fazem parte da resposta |
| 4 | O valor digitado como `200.50` virava `20050` | A tela removia todos os pontos | O servidor interpreta `1.200,50`, `200,50` e `200.50` corretamente |
| 5 | O campo "Sinal pago" misturava o sinal combinado com o valor recebido | Havia um campo só para as duas coisas | Agora há **sinal combinado** (em R$ ou %) e **valor pago**, separados |
| 6 | A IA só sabia criar compromissos | Faltava uma ferramenta de edição | Nova ferramenta `update_appointment`, que edita pelo id e nunca cria outro |
| 7 | A edição genérica (`action: update`) gravava qualquer campo | Fazia uma mescla livre dos dados | Agora passa pela mesma validação e histórico de `appointment_update` |
| 8 | Qualquer edição reativava avisos já enviados | `remindersSent` era zerado em toda edição | Os avisos só recomeçam quando muda a data, o horário ou a antecedência |

## Regras financeiras (`server/src/lib/appt-fin.ts`)

As regras ficam num só lugar, usado pela tela, pelo chat e pela IA.

- **Valor total**: em reais.
- **Sinal combinado**:
  - quando informado **em %**, é calculado pelo total e recalculado se o total mudar;
  - quando informado **em R$**, fica em R$ e não vira porcentagem.
- **Valor pago**: o que foi efetivamente recebido. Só muda quando o usuário informa ou confirma o recebimento.
- **Calculados na hora** (nunca gravados): saldo após o sinal, restante a receber e situação do pagamento (pendente, parcial ou pago).
- **Validações**:
  - porcentagem entre 0 e 100;
  - sinal em % exige o valor total;
  - sinal não pode ser maior que o total;
  - valor pago não pode ser maior que o total.
- **Número sem unidade** no chat ("sinal de 30"): o assistente **pergunta** se é % ou reais.

## Agendamento pelo chat

Exemplo: *"Agendar uma tatuagem para o dia 10, cliente José, telefone 88999999999, valor de R$ 200, sinal de 50% e observação: tatuagem no braço direito."*

1. Extrai serviço, data, horário, cliente, telefone, valor total, sinal (% ou R$), pagamento informado, observação e situação. A situação fica "Confirmado" quando a frase diz isso.
2. Pergunta **só o que falta**. Os dados podem chegar em várias mensagens. O horário é opcional: o usuário pode dizer "sem horário".
3. Quando há valores, pagamento ou ambiguidade, mostra um **resumo para conferir**. Exemplo: total R$ 200,00, sinal R$ 100,00 (50%), saldo após o sinal R$ 100,00, nenhum pagamento registrado.
4. Respostas à conferência:
   - **"sim"** grava **um** compromisso;
   - **"sim, sinal pago"** grava o compromisso e registra o sinal como recebido no financeiro;
   - **"não"** descarta;
   - **qualquer correção** ("na verdade o valor é 350") atualiza o resumo antes de salvar.
5. Proteções contra duplicação:
   - a confirmação é consumida antes de gravar;
   - um segundo "sim" responde "já está salvo";
   - o mesmo serviço, dia, hora e cliente não é gravado duas vezes;
   - um bloqueio impede gravar duas vezes em pedidos simultâneos.

O fluxo de antes continua igual em dois casos:
- **"o cliente já pagou o sinal"**: agenda e lança a entrada no financeiro na mesma mensagem. Agora também guarda os campos estruturados.
- **Agendamentos simples, sem valores**: são gravados direto.

## Edição

- **Configurações → Compromissos** (nova seção no Perfil):
  - lista os próximos, os anteriores ou todos;
  - busca por serviço, cliente, telefone ou observação;
  - filtra por situação.
- **"Editar"** abre o painel do compromisso pelo identificador. Dá para alterar:
  - serviço, cliente, telefone, data e horário, local, duração, situação e responsável;
  - valor total, sinal (R$ ou %, com prévia do cálculo ao vivo), valor pago e observações.
- **Salvar** usa `appointment_update`:
  - atualiza só o id selecionado, do usuário logado;
  - nunca cria um registro;
  - guarda o **histórico** de cada campo (de, para, quando, pela tela ou pelo chat);
  - recusa uma versão desatualizada (**409**) quando o compromisso foi alterado em outro lugar enquanto a tela estava aberta.
- O mesmo painel abre ao tocar no compromisso em Agenda → Compromissos.

## Sincronização

O chat, a Agenda e Configurações leem e gravam o mesmo registro. Não há cópias.

- Depois de salvar, a tela avisa o app (`nexa:changed`), e a Agenda e a lista de Configurações recarregam.
- O chat sempre consulta o banco:
  - o motor de conversa lê o registro atual ("que horas é essa tatuagem?");
  - a ferramenta `get_agenda` devolve os valores e a situação atualizados.

## Segurança e integridade

- Toda leitura e edição filtra pelo usuário logado. A atualização confirma que alterou exatamente um registro, do dono certo.
- Ids inválidos são recusados (400). Id de outro usuário é tratado como inexistente (404).
- A edição é atômica: uma transação por pedido.
- Contra reenvio: um "sim" repetido não cria outro registro, e reenviar a mesma edição não muda nada nem gera histórico.
- A IA não registra pagamento sem que o usuário tenha dito que pagou.

## Testes

- **Servidor** (`server/test/run.ts`), 4 testes novos:
  - três compromissos iguais, edição só do 2º, validações, conflito, isolamento e edição genérica;
  - chat completo → Configurações → edição → chat atualizado;
  - sinal em R$ e %, ambiguidade, várias mensagens, correção, "não" e sinal pago;
  - IA editando por id e lista com filtros.
- **Ajustado** o teste antigo de "sinal será pago depois": agora ele espera a conferência antes de salvar, como pede esta correção.
- **Navegador** (`server/test/browser/compromissos.py`, 23 verificações): os 10 testes obrigatórios pela tela real, incluindo tocar no 2º de três compromissos idênticos na Agenda.

## Como reverter

Não há migração nem dado convertido. Basta restaurar estes arquivos:

- `routes/items.ts`, `ai/convctx.ts`, `ai/assistant.ts`, `ai/finchat.ts`;
- `frontend/public/modules-addon.js` (v100);
- remover `lib/appt-fin.ts`, `ai/agendamento-chat.ts` e `frontend/public/compromissos-addon.js`, e a linha correspondente em `app.ts`.

Os campos novos gravados nos compromissos (`sinalPct`, `valorPago`, `historico`) são ignorados pela versão anterior.
