# MCoins — Meu Assistente como empresa emissora e integradora

O **Meu Assistente** é uma empresa institucional da plataforma, selecionável como emissora ao criar uma moeda, e a entidade central que vincula essa moeda a quantas empresas quiser.

## Modelo
- **Empresa institucional**: linha em `businesses` com `status='institucional'` e `data.institucional=true`. Criada sob demanda ao escolher "Meu Assistente" na criação da moeda. Não aparece em listas públicas, anúncios, cupons nem como empresa vinculável.
- **Uma moeda institucional** (a regra "uma moeda por empresa" continua valendo). Moedas das demais empresas funcionam exatamente como antes.
- **Vínculos** (`coin_links`): moeda × empresa, com `status` (`pendente`, `ativo`, `pausado`, `recusado`, `revogado`), desconto por moeda (opcional), `maxPct` do pedido, compra mínima e texto de regras. Eventos em `coin_link_events` (quem, quando, o quê).
- **Rastreabilidade**: `coin_ledger.issuer_business_id` e `linked_business_id` em cada movimentação (backfill das existentes: emissora = dona da moeda).

## Fluxo
1. Admin → MCoins → Nova moeda → empresa **Meu Assistente (empresa oficial da plataforma)** → publicar.
2. Admin → "Meu Assistente como emissor e integrador": escolhe uma, várias ou todas as empresas, define regras e cria vínculos (ou "aceite automático").
3. A empresa vê o pedido em **Sua empresa → Ajustes → MCoins do Meu Assistente** e aceita, recusa ou pausa/retoma.
4. No checkout da empresa, o cliente com saldo escolhe a moeda aceita; o pedido leva `moedaId` e respeita `maxPct`/compra mínima do vínculo.
5. Admin pausa, retoma, ajusta regras ou revoga a qualquer momento (histórico por vínculo). Admin não ativa vínculo não aceito nem retoma o que a empresa pausou (e vice-versa).

## API
- `GET /api/panel/coins/hub`, `GET /api/panel/coins/links/:id/events`
- `POST /api/panel/coins` ações `create` (`institucional:true`), `link_criar`, `link_ajustar`
- `GET|POST /api/v2/ads/:id/mcoins` (dono da empresa: `{vinculo, acao}`)
- `GET /api/v2/businesses/:id/coin` agora devolve também `aceitas`.

## Limitações
- Uma única moeda institucional.
- O desconto é absorvido pela empresa vinculada: não há liquidação/reembolso entre empresas.
- Adesão por compra não distribui moedas institucionais; uso apenas em pedidos de produtos, como antes.

## Testes
`server/test/run.ts` (3 testes novos, 181/181) e `server/test/browser/mcoins_integradora.py` (21 verificações).
