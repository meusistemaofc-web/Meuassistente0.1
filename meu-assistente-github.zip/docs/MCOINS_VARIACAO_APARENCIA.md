# MCoins com variação % e Aparência organizada (17/11, 23h40)

## Mercado → MCoins
- **O que mudou:** cada moeda mostra, abaixo do preço, a **variação % do valor de referência nas últimas 24 h**, no mesmo formato de Criptomoedas e Bolsa: verde quando sobe ou fica igual, vermelho quando cai. Antes aparecia "N distribuídas".
- **Cálculo** (`lib/coins.ts`, `variacao24h`):
  - compara o valor atual com o valor de 24 h atrás, usando o histórico de alterações `coin_changes` (campo "valor de referência");
  - sem alteração no período, mostra +0,00%;
  - distribuir moedas não altera a cotação.
- **Endpoint:** `/api/v2/coins/market` passou a enviar `variacao24h`.
- **Arquivos:** `coin-art.js` v=4 (`marketRow`). O texto de rodapé explica a porcentagem.
- **Painel:** a quantidade distribuída e o percentual distribuído continuam no painel e no detalhe da moeda.

## Painel → Aparência
- Em "Texto e ícones dos módulos no menu" e "Botões do cabeçalho", o título e a descrição ficam em cima, na horizontal e com a largura toda.
- O seletor Pequeno/Médio/Grande fica embaixo, alinhado à esquerda (`panel-addon.js` v=149, `rowV`).
- Antes, no celular, o seletor espremia o título até ele ficar com uma palavra por linha.

## Testes
- `server/test/browser/mcoins_variacao_aparencia.py`: 17/17, celular e computador.
- `moedas_bonus.py` 30/30, `mcoins_percentual.py` 12/12, `mcoins_integradora.py` 21/21.
- `npm test`: 294/294.
