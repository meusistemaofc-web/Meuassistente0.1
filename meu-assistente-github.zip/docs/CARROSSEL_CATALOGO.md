# Catálogo do chat em carrossel horizontal

Os cards de produtos e serviços que aparecem no chat do agente da empresa (`/a/:id`), em "Ver nossos serviços", "Ver nossos produtos", "Agendar um horário" com vários serviços e "Continuar escolhendo", agora formam um carrossel horizontal.

## O que mudou

A mudança fica só em `frontend/public/agente.html`, no componente que já existia: a função `cards()`, o CSS `.prods`/`.pc` e o `showCatalog()`. Também entrou a função nova `carousel()`.

| Antes | Agora |
|---|---|
| Cards de 150 px, imagem de 96 px | Cards de ~82% da largura no celular (cerca de 274 px num aparelho de 390 px) e 300 px em tablets e computadores |
| Nome e preço | Etiqueta, nome (até 2 linhas), descrição (até 2 linhas), preço em destaque e condições como selos (duração, sinal) |
| Botão de 34 px | Botão de 46 px na largura toda do card |
| Sem indicação de mais itens | Próximo card parcialmente visível, esmaecimento na borda, pontos de posição (ou "3 de 14" acima de 8 itens) e setas ‹ › |
| Itens sem foto ficavam sem imagem | Espaço da imagem mantido, com a inicial do nome na cor de destaque, para os cards ficarem com a mesma altura |

## Como funciona

- **Navegação:**
  - deslize com o dedo, com encaixe card a card;
  - setas ‹ ›;
  - touchpad (rolagem horizontal);
  - arraste com o mouse, sem disparar o botão do card ao soltar;
  - teclado: setas ← → com o carrossel em foco.
- **Movimento:** rolagem suave, que respeita "reduzir movimento" do sistema.
- **Categorias:** as abas atuais foram mantidas (por exemplo Tatuagem, Piercing, Produtos), e cada categoria mostra o seu próprio carrossel. Ao trocar de categoria e voltar, o carrossel volta para onde estava.
- **Ajuste ao conteúdo:** quando todos os cards cabem na tela, os pontos e as setas somem sozinhos.
- **Empresa fechada:** cada card mostra o selo "Fechado agora", e o botão continua com a regra atual (explica e não pede nem agenda).
- **Visual:** usa as cores do tema da empresa (`--nx-*`), com modo escuro e claro, destaque azul e cantos arredondados.

## Correção posterior

Os produtos que a IA do atendimento mostra no meio da conversa usam o mesmo carrossel. Na primeira versão, setas e pontos ficavam sem ação nesse caso (a rolagem com o dedo funcionava). Isso já foi corrigido: agora o carrossel também é ativado ali.

## Preservado

- **Botões:** os botões **Agendar** e **Adicionar** chamam exatamente as mesmas funções de antes (`showService` e `pick`): agendamento, sinal, variações, carrinho, pedido e Pix.
- **Fora do escopo:** o servidor, o catálogo administrativo e os cadastros não foram alterados. A página pública da empresa (`/x/empresa/:id`) também não mudou.

## Testes

- **Novo:** `server/test/browser/carrossel_catalogo.py`, com 71 verificações em celular, tablet e computador. O teste também confere que nenhum produto ou serviço foi duplicado ou alterado.
- **Regressão:** os testes de atalhos, tema do catálogo, cabeçalho, tipo de catálogo e sinal, vitrine, descrições, MCoins e botões rápidos continuam passando.

## Como reverter

Restaure `frontend/public/agente.html` da versão anterior. Só esse arquivo mudou na interface.
