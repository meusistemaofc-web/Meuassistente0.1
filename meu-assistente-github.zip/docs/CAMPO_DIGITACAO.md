# Campo de digitação do Chat Principal

O campo é um componente único: uma estrutura arredondada, com fundo escuro e borda discreta. Ele fica em `frontend/public/assets/index-MaCmp03.js`, com o estilo em `index-MaCmp03.css`. O ajuste reestruturou esse mesmo componente; não existe um segundo campo.

## Formato compacto (padrão)

- **Disposição:** botão circular "+" à esquerda (com contorno fino), texto centralizado verticalmente, microfone à direita do texto e botão azul circular de enviar na ponta direita. Tudo fica dentro da mesma cápsula.
- **Quando aparece:** é o formato ao abrir o chat e continua sendo **mesmo com o cursor ativo**. Tocar no campo não muda mais o formato.
- **Texto de exemplo:** "Pergunte qualquer coisa", inteiro a partir de 360 px de largura.

## Formato expandido (texto maior)

- **Quando aparece:** quando o texto não cabe mais em uma linha ou tem uma quebra de linha (Shift+Enter).
- **Disposição:** o mesmo componente vira uma caixa vertical, com o texto no alto. O "+" fica no canto inferior esquerdo, e o microfone e o enviar no canto inferior direito.
- **Crescimento:** a caixa cresce sozinha até 40% da altura da tela (no máximo 260 px) e depois rola por dentro.
- **Volta ao compacto:** ao apagar o texto até antes do ponto em que ele passou de uma linha, ou ao enviar.
- **Outros casos que mantêm o formato expandido, como antes:** anexos (a foto ou o arquivo aparecem dentro da caixa) e gravação de áudio.
- **Sem alternar sem parar:** o formato expandido guarda o tamanho do texto no momento em que expandiu e só volta ao compacto quando o texto fica menor que isso.

## O que foi preservado

- **Envio:** Enter envia e Shift+Enter quebra a linha. Há indicador de carregamento e bloqueio de envio duplicado.
- **Botões e recursos:** o "+" abre as mesmas opções de anexo (fotos, arquivos e áudio), e o microfone continua com ditado e gravação. Os atalhos "/" da Vitrine e a integração com o chat e o backend não mudaram.
- **Tela:** a área segura inferior do iPhone (`env(safe-area-inset-bottom)`) é respeitada. Com o teclado virtual aberto, o campo continua visível, e ao redimensionar a janela não há rolagem horizontal.

## Cache

Os arquivos de `/assets/` são entregues como imutáveis, com cache de 1 ano. Por isso o pacote do componente foi renomeado de `index-MaCmp02` para `index-MaCmp03`, em todas as referências: `index.html`, as páginas do Agente e da Central, o pacote principal e os pacotes relacionados.

## Testes

`server/test/browser/composer_novo.py` tem 97 verificações em celular, tablet e computador. Ele confere:

- **Formatos:** compacto com o cursor ativo e texto centralizado; texto curto mantém o compacto; texto maior expande o mesmo componente, com o cursor preservado; apagar volta ao compacto.
- **Disposição e visual:** a posição de "+", microfone e enviar nos dois formatos, o visual e a rolagem interna.
- **Funcionamento:** Enter e Shift+Enter, envio pelo botão, o anexo que abre o seletor e aparece na caixa, o microfone, o carregamento e o bloqueio de envio duplicado.
- **Tela:** teclado aberto nos dois formatos, redimensionamento para 320, 1024 e a largura original, e a área segura.

## Como reverter

1. Restaurar `index-MaCmp03.js` e `index-MaCmp03.css` da versão anterior.
   - **Abrir de novo ao tocar:** voltar o `onFocus`/`onBlur` que ativam `MO`, e `!!d` na condição de `is-open`.
   - **CSS:** remover as 3 regras `.ma-composer:not(.is-open) …`.
2. Se quiser voltar ao nome antigo, trocar `index-MaCmp03` por `index-MaCmp02` em todas as referências.

## Posição vertical (17/11)
O campo ficava 40 px acima da área segura do iPhone. Agora fica **12 px** acima dela (desceu 28 px), sem encostar na barra
de início do iPhone. A regra está em `modules-addon.js` (versão 114), e não no pacote `index-MaCmp03.*`: assim os aparelhos
recebem o ajuste sem depender do cache dos arquivos de `/assets/`. Com o teclado aberto continua valendo a regra de 14 px.
O teste `composer_novo.py` passou a conferir que a regra soma `env(safe-area-inset-bottom)` (antes exigia 30 px fixos).

## Card de anexar acima do campo (17/11)

No iPhone, o menu do sistema (Fototeca / Tirar Foto ou Gravar Vídeo / Escolher Arquivos) é aberto pelo próprio iOS **no ponto do toque**.
Como o toque era no botão +, o menu cobria o campo de digitação — o app não consegue mover nem estilizar esse menu.

Solução (em `modules-addon.js`, sem tocar no bundle em cache): o + agora abre um card próprio **acima do campo**, com
**Câmera** (abre a câmera direto, `capture="environment"`) e **Fotos e arquivos** (o mesmo seletor de antes). Como o toque
que chama o seletor acontece dentro do card, o menu do iPhone também aparece acima do campo. O card usa o mesmo
`<input type="file">` do chat (mesmos tipos aceitos e mesmo envio); fecha ao escolher, ao tocar fora ou com Esc.
Depois da câmera, os atributos do campo voltam ao original. `modules-addon.js?v=115`. Teste: `composer_novo.py` 112/112.

## Botão "Sua empresa" azul (17/11)

Só a cor mudou, na classe `.ma-hdr-emp` (`modules-addon.js`, v=116): fundo azul-marinho `#071123` e texto azul `#417CF7`,
medidos no botão de referência ("Obter o plano Plus"). Tokens `--ma-emp-bg`, `--ma-emp-bg-hover` (`#0b1a36`),
`--ma-emp-bg-press` (`#0e2042`) e `--ma-emp-ink`; foco com contorno azul. Texto, fonte, tamanho, posição, indicador verde,
três pontinhos e o clique continuam iguais. Teste: `sua_empresa_cabecalho.py` 34/34.

## Estilo caixa e novo texto de apoio (17/11, 22h52)
- **Layout:** o campo é sempre uma caixa. O texto fica em cima e ocupa a largura toda. Embaixo, o + e o ⚡ ficam à esquerda (círculos de 40px), e o microfone (40px) e o enviar (42px) à direita.
- **Proporção:** a caixa vazia tem 108px no celular. Ela fica mais baixa que a referência enviada, porque o espaço entre o texto e os botões foi reduzido. O texto tem 17px, e a caixa cresce com textos longos até 40% da tela, passando a rolar depois disso.
- **Texto de apoio:** "Como posso ajudar você hoje?".
- **Onde está:** `modules-addon.js` v=121 (`maComposerCaixa`). As regras usam `:not(#ma-nunca)` para valer sobre o estado compacto antigo do pacote, sem mexer no componente nem nas funções.
- **Teste:** `composer_novo.py` 109/109 e `modos_inteligentes.py` 36/36.
