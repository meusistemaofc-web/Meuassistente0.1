# Meu Assistente

> **Novo:** novas abas no painel administrativo original (`/admin`): Módulos, IA, Fontes de mercado, Mercado Pago, Planos de anúncio, Cérebro e busca.
>
> **Situação:** o servidor e o app original funcionam (login, chat com IA, agenda, finanças, notificações, offline, painel). Os módulos novos (empresas e pedidos, anúncios com Mercado Pago, mercado, impostos, várias IAs e Cérebro) estão **aprovados no protótipo** (`prototipo/index.html`) e serão ligados ao servidor por etapas — veja `docs/ROTEIRO_IMPLEMENTACAO.md` e `docs/ESPECIFICACAO_MODULOS.md`.

## Novidades desta versão

- **Logo centralizada na tela inicial do chat:**
  - A logo M fica no centro exato da área entre o cabeçalho e o campo de digitação.
  - Os botões rápidos ficam numa área própria embaixo e não a deslocam, apareçam, sumam ou estejam desligados.
  - Em telas baixas e com o teclado aberto, a logo fica o mais perto do centro sem encostar nos botões.
  - Detalhes em `docs/BOTOES_RAPIDOS.md`.

- **Botões rápidos do chat reestruturados:**
  - No máximo 3, em lista vertical à esquerda, logo acima do campo de digitação.
  - Ícone sem fundo em cinza discreto e texto branco; "Lojas" fica em azul.
  - Cada botão executa o seu comando de verdade no motor do chat.
  - No painel (Botões do chat): texto, comando, ação pronta, ícone, cores do ícone e do texto, destaque azul, posição, ativar/desativar e mostrar/ocultar.
  - A prévia é o chat real e atualiza na hora. Salvar aplica imediatamente.
  - "Registrar gasto" e "Criar lembrete" agora guiam a conversa.
  - Detalhes em `docs/BOTOES_RAPIDOS.md`.

- **Pedidos do chat em segundo plano:**
  - Pesquisas, análises e execuções continuam no servidor mesmo se você sair do chat, mudar de página ou fechar o app.
  - Estados reais: na fila, processando, concluída ou falhou.
  - O resultado fica salvo na conversa original. Uma notificação push ("Sua resposta está pronta") abre direto essa conversa.
  - Se falhar, chega um aviso e o cartão mostra o motivo, com "Tentar de novo" (o pedido fica guardado) e "Descartar".
  - Fila com limites, sem execução nem aviso duplicado, e recuperação de tarefas interrompidas.
  - Pedidos rápidos continuam instantâneos.
  - Detalhes em `docs/TAREFAS_SEGUNDO_PLANO.md`.

- **Carrinho com fotos e incentivos de compra:**
  - O carrinho e a finalização mostram a foto de cada produto, com os controles de quantidade.
  - A empresa cria incentivos em Sua empresa → Ajustes → Incentivos do carrinho: meta por valor ou por itens; frete grátis, desconto em % ou R$, ou cashback em MCoins; período, limite por cliente e soma com cupom.
  - O cliente vê, em tempo real, quanto falta ("Faltam R$ 15,00 para ganhar frete grátis.") com barra de progresso, e o servidor aplica o benefício de verdade no pedido, sem acúmulo indevido. Detalhes em `docs/INCENTIVOS_CARRINHO.md`.
- **Ditado pelo microfone no chat:**
  - O microfone transcreve a fala para texto no campo de mensagem, no idioma falado. O usuário revisa ou edita, e só ao tocar em enviar o texto vai para o chat, como se tivesse sido digitado; o áudio não é enviado ao motor.
  - Dá para cancelar durante a gravação, gravar de novo ou descartar a transcrição. Falhas (microfone bloqueado, sem fala, transcrição indisponível, sem internet) têm mensagens claras e não alteram o campo. Detalhes em `docs/DITADO_CHAT.md`.
- **Motor de respostas do chat mais inteligente:**
  - Responde no idioma em que o usuário escreve (português, inglês, espanhol, francês, italiano e alemão). "Sempre me responda em inglês" vira preferência na memória do usuário e vale em todas as conversas até ele pedir outra coisa; o idioma de uma mensagem isolada não vira preferência.
  - Perguntas como "como registro um gasto?" recebem passos curtos com as telas e botões reais do app, conferidos contra os módulos ligados, sem executar nada, e uma oferta para fazer pelo chat.
  - O chat diferencia pedido de execução, de explicação, pergunta geral e conversa. Detalhes em `docs/IDIOMA_E_MODO_EXPLICATIVO.md`.
- **Checkout de entrega com "Usar minha localização atual":**
  - Pede a permissão, descobre o endereço pela localização, preenche rua, número, bairro e cidade e mostra o endereço para confirmar, com opção de editar ou usar outro.
  - Com a permissão já concedida, preenche sozinho. Sem número, pede o número antes de confirmar. A taxa por km e a área de entrega usam o ponto confirmado, e a loja vê "Ver no mapa" no pedido.
  - Permissão negada, localização desligada, aparelho sem GPS, endereço não encontrado e fora da área têm mensagens claras e preenchimento manual. Detalhes em `docs/CHECKOUT_LOCALIZACAO.md`.
- **Busca de produtos e serviços no chat:**
  - Ao escrever "quero encontrar…", "onde comprar…", "procuro…", "encontre para mim…" e frases parecidas, o chat procura nos catálogos reais das lojas conectadas e mostra cards compactos com imagem, preço, empresa, distância, disponibilidade e botões Comprar/Agendar e Catálogo.
  - Tolera erros de digitação, plural e sinônimos, entende descrições, sugere itens parecidos e aceita filtros na frase ("até 50 reais", "mais barato", "em promoção").
  - Não liga em conversa comum, e outro assunto desliga o modo. Detalhes em `docs/BUSCA_PRODUTOS_CHAT.md`.
- **Nova página de apresentação (`/conheca`):**
  - Landing page moderna e interativa, que mostra a frase virando o item do app, as ferramentas da rotina em abas, um chat para experimentar e um pedido completo do celular do cliente ao painel da loja.
  - Também mostra o agente, a Página de Links e as Lojas Conectadas, com os planos e preços reais vindos do servidor.
  - Só aparecem recursos que existem: o que o administrador desliga some da página.
  - Ganhou uma imagem de compartilhamento nova, com o endereço oficial.
  - Sem migração. Ver `docs/APRESENTACAO_CONHECA.md`.
- **Pedidos conforme a modalidade:**
  - **Retirada:** a finalização e "Meus pedidos" mostram o endereço completo da loja, o horário, "Ver no mapa" e "Falar no WhatsApp" com mensagem pronta.
  - **Entrega:** o cliente acompanha as etapas (enviado → aceito → em preparo → saiu → entregue) com data e hora, atualizando sozinho, e vê o aviso de que a loja pode falar com ele pelo WhatsApp ou por ligação.
  - Nenhuma modalidade mostra informação da outra. O painel e a central de Lojas Conectadas só oferecem a etapa certa ("Saiu para entrega" × "Pronto para retirar").
  - Sem migração. Ver `docs/PEDIDOS_MODALIDADE.md`.
- **Cupons e Vouchers para anúncios, Agente ou ambos:**
  - O administrador escolhe o destino na criação. "Ambos" é um único cupom com um único limite de uso.
  - A ativação do Agente ganhou "Tenho um cupom", com Pix com desconto, ativação sem pagamento (100%, período gratuito ou vitalício), valor conferido na aprovação e reserva separada da do anúncio.
  - Lista e histórico mostram e filtram por destino.
  - Migração `052`. Ver `docs/CUPONS_DESTINO.md`.
- **Preço por quantidade (desconto progressivo):** opcional em cada produto sem variações, com faixas como 1 un. R$ 50 · 5+ R$ 45 · 10+ R$ 40, validadas no cadastro e no servidor. O card mostra a melhor faixa e o detalhe mostra "Compre mais, pague menos" com incentivo para a próxima faixa. No carrinho, os botões − / + recalculam na hora o preço por unidade, o desconto e o total. Pedido, cupom e agente usam a mesma regra (soma do mesmo produto; vale o menor entre oferta e faixa). Sem migração. Ver `docs/PRECO_QUANTIDADE.md`.
- **Página de Links: modelos de fundo e formato dos botões:** 20 fundos prontos (modernos, minimalistas, degradês, texturas e elegantes) com miniatura, filtro por estilo e aplicação com um toque, mantendo a personalização manual. O formato dos botões pode ser quadrado, cantos suaves, arredondado, pílula ou folha. Tudo aparece na prévia na hora e vale na página pública ao publicar, salvo por empresa. Sem migração. Ver `docs/LINKS_FUNDOS_BOTOES.md`.
- **Chat × Cérebro Central × ferramentas (auditoria):** o chat encontra conhecimentos aprovados mesmo com perguntas reformuladas (sinônimos e radicais), responde curto e sem JSON, blocos de código, marcadores `[C1]` ou nomes de ferramentas, e corta frases com números, e-mails ou links que não estão nos documentos. Chamadas de ferramenta que o modelo escreve como texto passam a ser executadas. Lembretes respeitam "amanhã"/"depois de amanhã" e guardam só o assunto; "9h30" deixa de virar despesa de R$ 30; "Tenho consulta amanhã às 9h30" passa a agendar. Sem migração. Ver `docs/AUDITORIA_CHAT_CEREBRO.md`.
- **Compartilhamento inteligente de produtos e serviços:** ícone nos detalhes de cada item com link próprio, que abre o item direto, sem conta, já na variação compartilhada. A mensagem pronta usa os dados atuais (preço, oferta, variação, serviço sob orçamento). Envia por WhatsApp, Telegram, Facebook, apps do aparelho (Instagram e outros) ou copiando link e texto. A prévia do link funciona nas redes (Open Graph e Twitter Cards). O administrador configura mensagens, ofertas e regras por categoria, com pré-visualização e restauração; cada empresa pode ter mensagens próprias ou desligar. Há estatísticas de compartilhamentos e visitas, sem dados pessoais. Migração `051`. Ver `docs/COMPARTILHAR_ITENS.md`.
- **Lojas Conectadas com várias empresas numa conta:** seletor de loja (logo e nome) que vale para todas as abas e uma aba **Catálogo e informações** só de leitura, com produtos e serviços da loja escolhida. Os avisos ficam separados por empresa e cada um abre o pedido ou o agendamento na loja de origem (inclusive das lojas próprias). O **detalhe do serviço** agora segue o padrão do detalhe do produto. Ver `docs/LOJAS_MULTIEMPRESA.md`.
- **Etiqueta OFERTA no detalhe do produto:** um pouco mais afastada do canto da imagem (14 px no celular, 18 px em telas maiores), sem nenhuma outra mudança visual. Ver `docs/OFERTA_DETALHE_PRODUTO.md`.
- **Imagens dos itens nos pedidos:** cada produto ou serviço do pedido mostra a imagem do próprio cadastro, com quantidade × preço unitário e o total do item. Aparece em Sua empresa → Pedidos (lista e o novo botão Detalhes), em Solicitações e na central de Lojas Conectadas. Uma referência estável é gravada no pedido (sem copiar a imagem), então editar a foto depois não troca a imagem dos pedidos antigos. Item sem foto mostra um espaço reservado. Ver `docs/PEDIDOS_IMAGENS.md`.
- **Interruptor ativo/inativo no painel de produtos:** em Sua empresa → Produtos, o botão "Pausar" virou um interruptor compacto no canto superior direito do card. Editar · Duplicar · Excluir ficam numa faixa própria, sem cobrir nome, preço ou descrição. A lógica é a mesma `toggle` de antes; desligar oculta da vitrine na hora sem apagar nada. Ver `docs/PRODUTOS_INTERRUPTOR.md`.
- **Vitrine pública com Serviços e compartilhamento:** "Empresas perto de você" ganhou a aba **Serviços**, com os serviços já cadastrados pelas empresas e o mesmo card, os mesmos filtros e a mesma ordem dos produtos. O card abre o detalhe do serviço na página da empresa. Há compartilhamento da vitrine (cabeçalho) e de cada empresa, produto e serviço: WhatsApp, outros aplicativos ou copiar o link, com prévia no WhatsApp. A vitrine e as páginas abrem **sem login**: a localização do visitante fica só no aparelho. Sem migração. Ver `docs/VITRINE_SERVICOS_COMPARTILHAMENTO.md`.
- **Central de Processamento de Arquivos e Mídias (etapa 1, independente e desligada por padrão):** serviço próprio em `services/central-midia` (Tesseract, Poppler, OpenCV, FFmpeg) para PDF, DOCX, XLSX, CSV, TXT, OCR de imagens, QR Code/Pix, boletos, áudio e vídeo, sem IA obrigatória (nível 2 opcional com Ollama). Perfil `midia` do docker-compose: não sobe com o `update.sh`. Ver `docs/CENTRAL_MIDIA.md`.
- **Estabilização (TypeScript estrito + PostgreSQL):** `strict`/`strictNullChecks` explícitos e sem `skipLibCheck`; os 30 erros de compilação que travavam o build Docker foram corrigidos na origem, sem `!` nem `any` de contorno. As migrações 021 (palavra reservada `similar`) e 039 (`IF NOT EXISTS`) agora funcionam no PostgreSQL. A suíte inteira roda também contra PostgreSQL real (`TEST_PG_URL`). Há um script de validação do deploy com conta real. Ver `docs/ESTABILIZACAO_TYPESCRIPT.md`.
- **MCoins (moedas digitais de bônus) por empresa:** biblioteca de 10 modelos, personalização, carteira do cliente, desconto no pedido, categoria no Mercado e adesão por compra (desativada). Ver `docs/MOEDAS_BONUS.md`.
- **Meu Assistente como emissor e integrador das MCoins:** empresa institucional selecionável ao criar a moeda, vínculos com várias empresas (aceite, pausa, regras), uso no checkout e rastreio de emissora/vinculada. Ver `docs/MCOINS_MEU_ASSISTENTE.md`.
- **CRM de Sua empresa:** clientes e leads sem duplicidade (reaproveita usuários, pedidos e agendamentos), funil configurável, oportunidades, tarefas com lembrete, linha do tempo, inteligência comercial e ferramentas no chat. Ver `docs/CRM.md`.
- **Analista de negócios no chat:** vendas, faturamento, pedidos, clientes, acessos, agendamentos, produtos e desempenho da empresa em linguagem natural, com dados reais, períodos, comparativos e sugestões com critério. Ver `docs/ANALISTA_NEGOCIO.md`.
- **Central MCoins:** controle administrativo (compra, venda, transferência e compartilhamento, tudo desligado por padrão), permissões por usuário/empresa/grupo, código único permanente (`MC-MA-000001`), compra/venda com liquidação definida pelo admin (sem presumir dinheiro real) e transferência entre contas pronta; auditoria completa. Veja `docs/MCOINS_CENTRAL.md`.
- **MCoins animadas e "Enviar MCoins":** moeda 3D com brilho, animação de recebimento com partículas, saldo animado (respeita redução de movimento) e distribuição administrativa em lote, atômica, idempotente e auditada. Ver `docs/MCOINS_ENVIO_ADMIN.md`.
- **Cupons de desconto por empresa:** criação com validade, quantidade, limite por cliente e produtos participantes; distribuição por push/CRM/área do cliente (só com autorização); validação completa no pedido, estorno automático, combinação com moedas, resultados e conversão, e visão do administrador de todas as empresas. Ver `docs/CUPONS.md`.
- **Laboratório de IA (admin):** o administrador corrige/ensina a IA em chat; a correção vira proposta de regra → análise de duplicidade/conflito → testes em simulação (sem efeito real) → aprovação → publicação no Cérebro, com versões, reversão e auditoria. Veja `docs/LABORATORIO_IA.md`.
- **Importar cardápio com IA:** Empresas → Produtos: foto/galeria/PDF/DOCX → leitura por IA → revisão por categorias → duplicidades → cadastro pelo serviço existente → histórico e reversão. Ver `docs/IMPORTADOR_CARDAPIO.md`. Migração `029_importador_cardapio.sql`.
- **Ações das mensagens do Chat Principal:** as respostas da IA mostram só três ícones cinza, numa linha logo abaixo: Copiar, Curtir e Não curtir, sem a opção de editar. Não curtir registra na hora, e os motivos são opcionais. As mensagens do usuário mantêm o Editar. Ver `docs/ACOES_MENSAGENS.md`.
- **Fase 10 — arquitetura multiagente colaborativa:** o orquestrador da Fase 4 ganhou 7 agentes especializados (Comercial, Agendamentos, CRM, Financeiro, Administrativo, Marketing, Análise e Inteligência) que reúnem e analisam os dados do próprio usuário e da empresa sem custo de IA. Cada agente de raciocínio recebe só a sua fatia. Decisões complexas passam por validação (proposta, crítica e verificação de números). Há memória compartilhada entre execuções, execução coordenada com dependências, reaproveitamento, interrupção e limites de custo, e autonomia de 1 a 4 sempre pelo motor da Fase 8. A Central de Agentes fica em `/admin/agentes`. Ver `docs/ARQUITETURA_MULTIAGENTE_COLABORATIVA.md`.
- **Ícones exclusivos nos Ajustes de Sua empresa:** cada opção tem um ícone próprio, ligado à finalidade (paleta, grade, pasta, etiqueta, selo de %, estrela, cartão, imagem, relógio, calendário, escudo, pessoas, robô, megafone…), com validação automática contra repetição. Ver `docs/ICONES_MENUS.md`.
- **Permissões de Agendamento:** em Sua empresa › Ajustes, o dono liga duas opções independentes. *Agendamento de pedidos* deixa o cliente escolher o dia e o horário do pedido, dentro do funcionamento. *Agendamento de serviços com aprovação* transforma o agendamento numa solicitação "Aguardando aprovação": nada é confirmado sozinho e o horário fica livre, salvo reserva temporária. O dono decide quem pode usar cada opção (todos, quem tem conta ou clientes selecionados) e pode delegar a aprovação a funcionários. O painel `/x/solicitacoes` tem as ações aprovar (com revalidação do horário), recusar, sugerir outro horário (o cliente aceita ou recusa) e detalhes, com notificações e auditoria. Desligadas, os fluxos atuais continuam iguais. Ver `docs/PERMISSOES_AGENDAMENTO.md`.
- **Catálogo do chat da empresa em carrossel:** os cards de produtos e serviços no chat do agente (`/a/:id`) viram um carrossel horizontal com cards amplos (~82% da largura no celular, 300 px em telas maiores), imagem 4:3 em destaque, descrição, preço e condições, botão maior, próximo card parcialmente visível, indicador de posição, setas, deslize com o dedo, arraste com o mouse e teclado. As categorias continuam separadas (cada uma com seu carrossel) e Agendar/Adicionar seguem iguais. Ver `docs/CARROSSEL_CATALOGO.md`.
- **Fase 9 — Laboratório de Inteligência (admin):** página `/admin/laboratorio` (atalho na aba Laboratório de IA) para pesquisa e evolução controlada. Tem visão geral (métricas reais, estimativas e indicadores experimentais separados), Arena com 10 categorias de desafios e desafios personalizados, simulador de conversas com avaliação por mensagem, laboratório de agentes (testar, comparar, colaboração, especialistas novos em experimentação), centro de diagnóstico, central de melhorias, experimentos atual × experimental, controle de evolução e desafios contínuos programados. Tudo roda com usuário sintético e dados fictícios. Nada chega aos usuários sem aprovação, com liberação gradual e reversão. Acesso: Administrador Principal ou permissão "Laboratório de Inteligência". Ver `docs/LABORATORIO_INTELIGENCIA.md`. Migração `036_laboratorio_inteligencia.sql`.
- **Fase 8 — autonomia operacional:** o assistente entende objetivos do dia a dia ("organize minha semana", "crie lembretes para os compromissos de amanhã", "apague as tarefas concluídas"), planeja etapas com dependências e executa com os serviços existentes, sem módulos duplicados. Cada resultado é conferido no sistema antes de ser relatado. Há três níveis de autonomia: 1 automático, 2 "sim", 3 "autorizo EX-…" para exclusões e pagamentos. A execução tem identificador único, proteção contra repetição, controle de versão, autorrecuperação (classifica o erro, repete só o seguro, usa alternativa, para em risco de inconsistência), segundo plano com progresso, cancelamento e aviso, retomada após queda e reversão. As ferramentas da IA passam pelos mesmos níveis. Página `/execucoes`; painel em Cérebro e busca → Autonomia operacional. Ver `docs/AUTONOMIA_OPERACIONAL.md`. Migração `035`.
- **Fase 7 — inteligência preditiva:** analistas de agenda, tarefas, finanças, clientes/comercial, problemas e hábitos olham o histórico do próprio usuário. Eles antecipam conflitos de horário, compromissos sem contato ou confirmação, risco de esquecimento, pós-atendimento, contas e gastos fora do padrão, retornos de clientes, compras recorrentes, duplicidades e oportunidades de campanha. Cada item é **fato** ou **estimativa com % de confiança** e base, e o assistente diz quando faltam dados. Nada é alterado sozinho. As previsões são conferidas depois (acertou/errou) e há retroteste com o histórico. Os avisos são controlados pelo usuário (categorias, canais, frequência, horário de silêncio, sem repetir). Página `/previsoes`; painel em Cérebro e busca → Inteligência preditiva; integrada aos agentes e ao aprendizado contínuo. Ver `docs/INTELIGENCIA_PREDITIVA.md`. Migração `034`.
- **Fase 6 — aprendizado contínuo:** o assistente aprende com avaliações, correções, reclamações e falhas, só a partir de notas e rótulos de quem autorizou. Ele encontra padrões ponderados por usuário (com mínimo de usuários distintos e contas suspeitas excluídas), compara estratégias e versões, faz autodiagnóstico e gera propostas numa **política aprendida** de lista fechada, sem código e sem modelo. Cada proposta é testada num ambiente isolado (precisão, naturalidade, velocidade, consistência e resolução, antes × depois) e só entra com aprovação do administrador, gradual ou total. Dá para promover, reverter ou restaurar qualquer versão, e a liberação gradual para sozinha em caso de regressão. Painel → Cérebro e busca → Aprendizado contínuo; consentimento em Minha memória. Ver `docs/APRENDIZADO_CONTINUO.md`. Migração `033`.
- **Compromissos (correção crítica):** a edição abre e altera só o compromisso escolhido, pelo identificador. Antes, a Agenda identificava pelo título e horário e podia editar outro. O chat agenda com cliente, telefone, valor total, sinal em % ou R$ (pergunta quando é ambíguo), valor pago e observação, confere antes de salvar e grava um único registro. A nova seção Configurações → Compromissos permite editar tudo, inclusive a situação, com histórico e proteção contra edição simultânea. A IA ganhou `update_appointment`, que edita por id e nunca cria outro. Ver `docs/COMPROMISSOS.md`.
- **Fase 5 — memória evolutiva:** a memória existente ganhou camadas (curto prazo, conversação, longo prazo, preferências, experiências), recuperação por significado local (radicais, grupos de assunto, erros de digitação, BM25, nomes próprios) com cache por usuário (~0,7 ms com 1000 memórias), associação entre memórias e conversas do mesmo usuário, versões com origem e data (corrigida a perda do valor anterior e a contradição tratada como duplicata), experiências individuais usadas pelo núcleo e pelos agentes, e privacidade (consentimento, retenção configurável, exportar, corrigir e apagar tudo). Página do usuário: `/minha-memoria` (atalho em Perfil → Memória do assistente). Ver `docs/MEMORIA_EVOLUTIVA.md`. Migração `032`.
- **Fase 4 — arquitetura multiagente:** coordenador central que mede a complexidade e, só em pedidos complexos, mobiliza agentes internos (pesquisa, análise, vendas, planejamento, escrita) em duas ondas sobre um quadro com acesso controlado; execução continua exclusiva da IA principal com as ferramentas; divergências entre agentes detectadas; resposta única (sem citar agentes); prazo, disjuntor e falhas isoladas. Painel: Inteligência avançada → Coordenação multiagente. Ver `docs/MULTIAGENTE.md`.
- **Fase 3 — diagnóstico e desempenho:** corpus sintético de conversas reais (formal, gíria, voz sem pontuação, erros de digitação) com conjunto de validação separado; acerto do núcleo 86,1% → 100%; consultas ao banco por mensagem com IA 72 → 34 (memória por requisição, sem risco de dado desatualizado; `MEMO_REQUISICAO=0` desliga); etapas da IA (preparo, modelo, ferramentas, conclusão) e consultas por mensagem na telemetria; diagnóstico e desempenho no painel e no monitor de regressão. Ver `docs/diagnostico/FASE3.md` e `docs/diagnostico/COMPARACAO.md`. Linha de comando: `npx tsx test/diagnostico/diagnostico.ts`.
- **Inteligência avançada (Nível 2):** sobre o Cérebro cognitivo — fio da conversa, planejamento com acompanhamento das etapas, especialistas dinâmicos com coordenação central (reaproveitando os domínios existentes), memória por relevância com atualização em vez de duplicata, autoverificação de respostas importantes, avaliação 👍/👎 com envio de oportunidades ao Laboratório de IA (testes e aprovação), sugestões proativas com limite, execução verificada no banco e avaliação contínua (bateria automática, indicadores e alerta de regressão). Cada capacidade tem chave própria em Cérebro e busca → Inteligência avançada. Ver `docs/INTELIGENCIA_NIVEL2.md`. Migração `031`.
- **Cérebro cognitivo (inteligência conversacional avançada):** camada aditiva que lê intenção, contexto, lacunas, ambiguidades e contradições antes de a IA responder, orienta o tom e as capacidades reais, confere a resposta depois (ação afirmada sem confirmação, links inventados, tom robótico), exige confirmação para ações sensíveis e avalia cada resposta (só notas, sem texto). Painel: Cérebro e busca → Inteligência cognitiva. Ver `docs/CEREBRO_COGNITIVO.md`. Migração `030`.
- **Aprendizagem adaptativa e memória evolutiva:** o assistente aprende correções e preferências de cada usuário (persistente, individual, silencioso e natural), recupera só o que é relevante em novas conversas e evita repetir erros; a memória global só muda com aprovação do administrador. Ativo por padrão (chave global do administrador); cada aprendizado chega automaticamente à fila de revisão do painel (aprovar, rejeitar ou editar). Ver `docs/APRENDIZAGEM_ADAPTATIVA.md`. Migrações `023_aprendizagem_adaptativa.sql` e `028_aprendizados_revisao.sql`.
- **Contadores sincronizados de pedidos e agendamentos:** serviço único `BusinessActivityCounters` (`GET /api/v2/counters`) alimenta o menu lateral do Chat e Sua empresa > Pedidos/Agenda, com atualização sem recarregar. Ver `docs/CONTADORES_PEDIDOS_AGENDAMENTOS.md`.
- **Campo de digitação do chat (compacto ↔ expandido):** compacto em uma linha (+ à esquerda, “Pergunte qualquer coisa”, microfone e enviar azul com seta ↑); ao tocar, expande na vertical (“Digite sua mensagem…”, até 40% da tela/260 px, rola depois), com + embaixo à esquerda e microfone + enviar embaixo à direita; sem botão “Auto”. Funções preservadas (anexos, ditar/gravar, Enter envia, Shift+Enter quebra linha, sem envio duplicado, carregamento no botão). Em telas curtas (teclado aberto) o cabeçalho rola para o campo não sumir; respeita a área segura. O componente está no pacote compilado `frontend/public/assets/index-MaCmp03.js` (+ `.css`); como o servidor guarda `/assets/*` com cache imutável, os arquivos ganharam novo nome.
- **Vitrine de Links (admin):** links cadastrados no painel aparecem nos chats ao digitar `/` (menu filtrável, card com imagem e botão), busca determinística, públicos e canais, contagem de acessos e cliques. Veja `docs/VITRINE_LINKS.md`. No chat do assistente o card é gravado como mensagem `link_card` do histórico (persistente por conversa e em ordem cronológica); veja `docs/VITRINE_LINKS.md`. Palavras-chave no chat: palavra cadastrada (sozinha ou em frase) mostra os cards das empresas disponíveis (`docs/PALAVRAS_CHAVE_CHAT.md`). Modo de aprovação de anúncios (manual ou automático, só para novos envios): `docs/APROVACAO_ANUNCIOS.md`. Modalidade do catálogo exclusiva por empresa: produtos OU serviços, validada no banco e no servidor, troca com aviso e confirmação (`docs/MODALIDADE_CATALOGO.md`). Organizar módulos: a escolha do usuário (`settings.menuLayout`) é a fonte única do menu lateral (`docs/ORGANIZAR_MODULOS_MENU.md`). Empresas próximas no chat: ao autorizar a localização (GPS ou cidade), a própria resposta vira os cards reais, mesma busca da página Empresas parceiras (`docs/LOCALIZACAO_CHAT.md`). Botão "Sua empresa" no cabeçalho: só com anúncio aprovado pelo admin, validado no servidor (`docs/BOTAO_SUA_EMPRESA_CABECALHO.md`). Campo de digitação: compacto (+ | texto | microfone | enviar) e caixa vertical ao digitar texto maior (`docs/CAMPO_DIGITACAO.md`). Botões rápidos do chat: lista minimalista perto do campo de digitação, com "Ver mais" no celular; somem na 1ª interação e voltam em nova conversa (`docs/BOTOES_RAPIDOS_CHAT.md`).
- **Inteligência de Agenda (capacidade da IA):** calendário empresarial (feriados, intervalos, exceções, bloqueios), cálculo de horários reais no motor existente, alertas proativos e modos manual/inteligente/automático. Veja `docs/INTELIGENCIA_AGENDA.md`.
- **Links públicos limpos dos agentes:** `meuassistente.chat/nome-da-empresa` (sem `/g-`), exclusivos, personalizáveis, com redirecionamento dos links antigos. Ver `docs/LINKS_PUBLICOS_AGENTES.md`.

- **Cérebro do Chat transparente:** nova seção *Capacidades da inteligência* (Painel → Cérebro e busca) lista tudo o que o chat sabe e faz, por categoria, com status real (ativo, inativo, pendente, em desenvolvimento). Ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`.
- **Tema único por empresa** aplicado no catálogo, nas janelas de produto e no agente — ver `docs/TEMA_VISUAL_EMPRESA.md`.
- **Cérebro com regras executáveis, aprendizado pendente de aprovação, versões, conflitos e registro de uso** — ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`. Migração `018_cerebro_regras.sql` (aditiva; roda sozinha ao subir o servidor).

- **Agenda, financeiro, endereço, imagens, nome do atendente e variações** — agendamento pelo chat entra na Agenda e bloqueia o horário; pagamentos geram lançamento único no Financeiro; endereço manual ou automático; ver `docs/CORRECOES_AGENDA_FINANCEIRO.md`.
- **Sinal antecipado no chat e tipo de catálogo (Produtos / Serviços / ambos)** — ver as seções 8 e 9 do mesmo documento.
- **Conhecimento comercial integrado (atendimento, marketing, vendas e CRM)** — ver `docs/CONHECIMENTO_COMERCIAL.md`.
## Estrutura
- `server/` — backend Node.js + TypeScript (PostgreSQL)
- `frontend/public/` — app original (PWA) já corrigido
- `prototipo/` — protótipo navegável aprovado (referência)
- `tools/ia-gateway/` — gateway de IAs com troca automática e painel (pode ser usado já na VPS)
- `deploy/` — Nginx e scripts de instalação, atualização, backup e restauração
- `docs/` — guias, relatórios e especificação

## Subir no GitHub (sem enviar segredos)
O arquivo `.env` nunca vai para o GitHub (já está no `.gitignore`). Envie o ZIP inteiro para o repositório e descompacte na VPS, como você já faz.

---

# Meu Assistente — versão independente da Netlify

App pessoal com chat de IA que organiza gastos, contas, tarefas, compromissos, lembretes, compras e anotações.
Esta versão roda em qualquer servidor Linux (ex.: VPS Hostinger) com **Node.js + PostgreSQL**, sem Netlify.

## Estrutura

```
frontend/public/     App original (PWA compilado), com os nomes de arquivos corrigidos + index.html novo
server/              Backend próprio (Node.js 22 + TypeScript)
  src/               Código-fonte (API REST, autenticação, IA, agendador)
  migrations/        Estrutura do banco PostgreSQL (aplicada automaticamente)
  test/              Testes automatizados
deploy/nginx/        Configuração do Nginx (proxy reverso + HTTPS)
deploy/scripts/      install.sh, update.sh, backup.sh, restore.sh, smoke-test.sh
docs/                Relatórios, guia de instalação e checklist
original/            netlify.toml original (só referência; não é usado)
Dockerfile, docker-compose.yml, .env.example
```

## Instalação rápida na VPS (Ubuntu)

```bash
unzip MEU_ASSISTENTE_COMPLETO.zip
cd MEU_ASSISTENTE_COMPLETO
sudo bash deploy/scripts/install.sh
```

O script instala Docker, Nginx e Certbot, cria o `.env` (com senha do banco aleatória), sobe o banco e o app,
configura o Nginx e o HTTPS. Passo a passo detalhado: **docs/GUIA_INSTALACAO_VPS.md**.

Depois, abra o site e crie a primeira conta em **/cadastro** — ela vira o **Administrador Principal**.

## Configuração essencial (.env)

| Variável | Para quê |
|---|---|
| `PUBLIC_URL` | Endereço do site (https://seudominio) |
| `POSTGRES_PASSWORD` | Senha do banco (gerada pelo install.sh) |
| `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` | IA do chat (OpenAI, OpenRouter, Gemini, Groq, Ollama…) |
| `RESEND_API_KEY`, `MAIL_FROM` | E-mail de recuperação de senha |

Sem `AI_API_KEY` o chat responde com o aviso "IA não configurada" (o resto do app funciona).
Sem `RESEND_API_KEY` o link de recuperação de senha aparece apenas no log do servidor (`docker compose logs app`).

## Comandos do dia a dia

```bash
docker compose ps                      # situação dos serviços
docker compose logs -f app             # logs do app
sudo bash deploy/scripts/update.sh     # atualizar (faz backup antes)
bash deploy/scripts/backup.sh          # backup manual (há backup diário às 03:00)
sudo bash deploy/scripts/restore.sh backups/ARQUIVO.sql.gz
bash deploy/scripts/smoke-test.sh      # teste rápido do sistema instalado
MA_EMAIL=… MA_SENHA=… bash deploy/scripts/validar-estabilizacao.sh   # build + contêiner + logs + saúde + login/chat reais
```

## Desenvolvimento local (sem Docker)

```bash
cd server
npm install
cp ../.env.example ../.env   # preencha DATABASE_URL apontando para um PostgreSQL
npm run dev                  # http://localhost:3000
npm test                     # testes automatizados (usam SQLite embutido, não precisam de PostgreSQL)
TEST_PG_URL=postgres://usuario@localhost/banco_de_teste_vazio npm test   # a mesma suíte contra PostgreSQL real
npm run typecheck            # TypeScript estrito (strict + strictNullChecks), deve dar 0 erros
npm run build && npm start   # produção
```

## O que funciona e o que não foi reconstruído

Veja **docs/RELATORIO_RECONSTRUCAO.md**. Resumo: autenticação completa (com 2FA), chat com IA que grava registros,
agenda, financeiro, Meu Dia, notificações, memória, modo offline e painel de usuários funcionam.
Planos/Mercado Pago, fiscal/DAS, mercado/B3, estúdio de vídeo, eleições, push, e-mails, WhatsApp, treinos,
alimentação, remédios, mapas e espaços compartilhados **não** estavam no ZIP e respondem
"módulo não reconstruído" (erro 501), sem telas falsas.
