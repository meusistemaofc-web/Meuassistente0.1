# Meu Assistente

> **Novo:** novas abas no painel administrativo original (`/admin`): Módulos, IA, Fontes de mercado, Mercado Pago, Planos de anúncio, Cérebro e busca.
>
> **Situação:** o servidor e o app original funcionam (login, chat com IA, agenda, finanças, notificações, offline, painel). Os módulos novos (empresas e pedidos, anúncios com Mercado Pago, mercado, impostos, várias IAs e Cérebro) estão **aprovados no protótipo** (`prototipo/index.html`) e serão ligados ao servidor por etapas — veja `docs/ROTEIRO_IMPLEMENTACAO.md` e `docs/ESPECIFICACAO_MODULOS.md`.

## Novidades desta versão

- **Moedas digitais de bônus por empresa:** biblioteca de 10 modelos, personalização, carteira do cliente, desconto no pedido, categoria no Mercado e adesão por compra (desativada). Ver `docs/MOEDAS_BONUS.md`.
- **Cupons de desconto por empresa:** criação com validade, quantidade, limite por cliente e produtos participantes; distribuição por push/CRM/área do cliente (só com autorização); validação completa no pedido, estorno automático, combinação com moedas, resultados e conversão, e visão do administrador de todas as empresas. Ver `docs/CUPONS.md`.
- **Laboratório de IA (admin):** o administrador corrige/ensina a IA em chat; a correção vira proposta de regra → análise de duplicidade/conflito → testes em simulação (sem efeito real) → aprovação → publicação no Cérebro, com versões, reversão e auditoria. Veja `docs/LABORATORIO_IA.md`.
- **Vitrine de Links (admin):** links cadastrados no painel aparecem nos chats ao digitar `/` (menu filtrável, card com imagem e botão), busca determinística, públicos e canais, contagem de acessos e cliques. Veja `docs/VITRINE_LINKS.md`.
- **Links públicos limpos dos agentes:** `meuassistente.chat/nome-da-empresa` (sem `/g-`), exclusivos, personalizáveis, com redirecionamento dos links antigos. Ver `docs/LINKS_PUBLICOS_AGENTES.md`.

- **Cérebro do Chat transparente:** nova seção *Capacidades da inteligência* (Painel → Cérebro e busca) lista tudo o que o chat sabe e faz, por categoria, com status real (ativo, inativo, pendente, em desenvolvimento). Ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`.
- **Tema único por empresa** aplicado no catálogo, nas janelas de produto e no agente — ver `docs/TEMA_VISUAL_EMPRESA.md`.
- **Cérebro com regras executáveis, aprendizado pendente de aprovação, versões, conflitos e registro de uso** — ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`. Migração `018_cerebro_regras.sql` (aditiva; roda sozinha ao subir o servidor).

- **Agenda, financeiro, endereço, imagens, nome do atendente e variações** — agendamento pelo chat entra na Agenda e bloqueia o horário; pagamentos geram lançamento único no Financeiro; endereço manual ou automático; ver `docs/CORRECOES_AGENDA_FINANCEIRO.md`.
- **Sinal antecipado no chat e tipo de catálogo (Produtos / Serviços / ambos)** — ver as seções 8 e 9 do mesmo documento.
- **Conhecimento comercial integrado (atendimento, marketing, vendas e CRM)** — ver `docs/CONHECIMENTO_COMERCIAL.md`.
## Estrutura
- `server/` — backend Node.js + TypeScript (PostgreSQL)
- `frontend/public/` — app original (PWA) já corrigido
- `prototipo/` — protótipo navegável aprovado (referência)
- `tools/ia-gateway/` — gateway de IAs com troca automática e painel (pode ser usado já na VPS)
- `deploy/` — Nginx e scripts de instalação, atualização, backup e restauração
- `docs/` — guias, relatórios e especificação

## Subir no GitHub (sem enviar segredos)
O arquivo `.env` nunca vai para o GitHub (já está no `.gitignore`). Envie o ZIP inteiro para o repositório e descompacte na VPS, como você já faz.

---

# Meu Assistente — versão independente da Netlify

App pessoal com chat de IA que organiza gastos, contas, tarefas, compromissos, lembretes, compras e anotações.
Esta versão roda em qualquer servidor Linux (ex.: VPS Hostinger) com **Node.js + PostgreSQL**, sem Netlify.

## Estrutura

```
frontend/public/     App original (PWA compilado), com os nomes de arquivos corrigidos + index.html novo
server/              Backend próprio (Node.js 22 + TypeScript)
  src/               Código-fonte (API REST, autenticação, IA, agendador)
  migrations/        Estrutura do banco PostgreSQL (aplicada automaticamente)
  test/              Testes automatizados
deploy/nginx/        Configuração do Nginx (proxy reverso + HTTPS)
deploy/scripts/      install.sh, update.sh, backup.sh, restore.sh, smoke-test.sh
docs/                Relatórios, guia de instalação e checklist
original/            netlify.toml original (só referência; não é usado)
Dockerfile, docker-compose.yml, .env.example
```

## Instalação rápida na VPS (Ubuntu)

```bash
unzip MEU_ASSISTENTE_COMPLETO.zip
cd MEU_ASSISTENTE_COMPLETO
sudo bash deploy/scripts/install.sh
```

O script instala Docker, Nginx e Certbot, cria o `.env` (com senha do banco aleatória), sobe o banco e o app,
configura o Nginx e o HTTPS. Passo a passo detalhado: **docs/GUIA_INSTALACAO_VPS.md**.

Depois, abra o site e crie a primeira conta em **/cadastro** — ela vira o **Administrador Principal**.

## Configuração essencial (.env)

| Variável | Para quê |
|---|---|
| `PUBLIC_URL` | Endereço do site (https://seudominio) |
| `POSTGRES_PASSWORD` | Senha do banco (gerada pelo install.sh) |
| `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` | IA do chat (OpenAI, OpenRouter, Gemini, Groq, Ollama…) |
| `RESEND_API_KEY`, `MAIL_FROM` | E-mail de recuperação de senha |

Sem `AI_API_KEY` o chat responde com o aviso "IA não configurada" (o resto do app funciona).
Sem `RESEND_API_KEY` o link de recuperação de senha aparece apenas no log do servidor (`docker compose logs app`).

## Comandos do dia a dia

```bash
docker compose ps                      # situação dos serviços
docker compose logs -f app             # logs do app
sudo bash deploy/scripts/update.sh     # atualizar (faz backup antes)
bash deploy/scripts/backup.sh          # backup manual (há backup diário às 03:00)
sudo bash deploy/scripts/restore.sh backups/ARQUIVO.sql.gz
bash deploy/scripts/smoke-test.sh      # teste rápido do sistema instalado
```

## Desenvolvimento local (sem Docker)

```bash
cd server
npm install
cp ../.env.example ../.env   # preencha DATABASE_URL apontando para um PostgreSQL
npm run dev                  # http://localhost:3000
npm test                     # testes automatizados (usam SQLite embutido, não precisam de PostgreSQL)
npm run build && npm start   # produção
```

## O que funciona e o que não foi reconstruído

Veja **docs/RELATORIO_RECONSTRUCAO.md**. Resumo: autenticação completa (com 2FA), chat com IA que grava registros,
agenda, financeiro, Meu Dia, notificações, memória, modo offline e painel de usuários funcionam.
Planos/Mercado Pago, fiscal/DAS, mercado/B3, estúdio de vídeo, eleições, push, e-mails, WhatsApp, treinos,
alimentação, remédios, mapas e espaços compartilhados **não** estavam no ZIP e respondem
"módulo não reconstruído" (erro 501), sem telas falsas.
