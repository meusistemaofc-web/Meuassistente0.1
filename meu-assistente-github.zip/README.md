# Meu Assistente

> **Novo:** novas abas no painel administrativo original (`/admin`): Módulos, IA, Fontes de mercado, Mercado Pago, Planos de anúncio, Cérebro e busca.
>
> **Situação:** o servidor e o app original funcionam (login, chat com IA, agenda, finanças, notificações, offline, painel). Os módulos novos (empresas e pedidos, anúncios com Mercado Pago, mercado, impostos, várias IAs e Cérebro) estão **aprovados no protótipo** (`prototipo/index.html`) e serão ligados ao servidor por etapas — veja `docs/ROTEIRO_IMPLEMENTACAO.md` e `docs/ESPECIFICACAO_MODULOS.md`.

## Novidades desta versão

- **Estabilização (TypeScript estrito + PostgreSQL):** `strict`/`strictNullChecks` explícitos e sem `skipLibCheck`; os 30 erros de compilação que travavam o build Docker foram corrigidos na origem, sem `!` nem `any` de contorno. As migrações 021 (palavra reservada `similar`) e 039 (`IF NOT EXISTS`) agora funcionam no PostgreSQL. A suíte inteira roda também contra PostgreSQL real (`TEST_PG_URL`). Há um script de validação do deploy com conta real. Ver `docs/ESTABILIZACAO_TYPESCRIPT.md`.
- **MCoins (moedas digitais de bônus) por empresa:** biblioteca de 10 modelos, personalização, carteira do cliente, desconto no pedido, categoria no Mercado e adesão por compra (desativada). Ver `docs/MOEDAS_BONUS.md`.
- **Meu Assistente como emissor e integrador das MCoins:** empresa institucional selecionável ao criar a moeda, vínculos com várias empresas (aceite, pausa, regras), uso no checkout e rastreio de emissora/vinculada. Ver `docs/MCOINS_MEU_ASSISTENTE.md`.
- **CRM de Sua empresa:** clientes e leads sem duplicidade (reaproveita usuários, pedidos e agendamentos), funil configurável, oportunidades, tarefas com lembrete, linha do tempo, inteligência comercial e ferramentas no chat. Ver `docs/CRM.md`.
- **Analista de negócios no chat:** vendas, faturamento, pedidos, clientes, acessos, agendamentos, produtos e desempenho da empresa em linguagem natural, com dados reais, períodos, comparativos e sugestões com critério. Ver `docs/ANALISTA_NEGOCIO.md`.
- **Central MCoins:** controle administrativo (compra, venda, transferência e compartilhamento, tudo desligado por padrão), permissões por usuário/empresa/grupo, código único permanente (`MC-MA-000001`), compra/venda com liquidação definida pelo admin (sem presumir dinheiro real) e transferência entre contas pronta; auditoria completa. Veja `docs/MCOINS_CENTRAL.md`.
- **MCoins animadas e "Enviar MCoins":** moeda 3D com brilho, animação de recebimento com partículas, saldo animado (respeita redução de movimento) e distribuição administrativa em lote, atômica, idempotente e auditada. Ver `docs/MCOINS_ENVIO_ADMIN.md`.
- **Cupons de desconto por empresa:** criação com validade, quantidade, limite por cliente e produtos participantes; distribuição por push/CRM/área do cliente (só com autorização); validação completa no pedido, estorno automático, combinação com moedas, resultados e conversão, e visão do administrador de todas as empresas. Ver `docs/CUPONS.md`.
- **Laboratório de IA (admin):** o administrador corrige/ensina a IA em chat; a correção vira proposta de regra → análise de duplicidade/conflito → testes em simulação (sem efeito real) → aprovação → publicação no Cérebro, com versões, reversão e auditoria. Veja `docs/LABORATORIO_IA.md`.
- **Importar cardápio com IA:** Empresas → Produtos: foto/galeria/PDF/DOCX → leitura por IA → revisão por categorias → duplicidades → cadastro pelo serviço existente → histórico e reversão. Ver `docs/IMPORTADOR_CARDAPIO.md`. Migração `029_importador_cardapio.sql`.
- **Ações das mensagens do Chat Principal:** as respostas da IA mostram só três ícones cinza, numa linha logo abaixo: Copiar, Curtir e Não curtir, sem a opção de editar. Não curtir registra na hora, e os motivos são opcionais. As mensagens do usuário mantêm o Editar. Ver `docs/ACOES_MENSAGENS.md`.
- **Fase 10 — arquitetura multiagente colaborativa:** o orquestrador da Fase 4 ganhou 7 agentes especializados (Comercial, Agendamentos, CRM, Financeiro, Administrativo, Marketing, Análise e Inteligência) que reúnem e analisam os dados do próprio usuário e da empresa sem custo de IA. Cada agente de raciocínio recebe só a sua fatia. Decisões complexas passam por validação (proposta, crítica e verificação de números). Há memória compartilhada entre execuções, execução coordenada com dependências, reaproveitamento, interrupção e limites de custo, e autonomia de 1 a 4 sempre pelo motor da Fase 8. A Central de Agentes fica em `/admin/agentes`. Ver `docs/ARQUITETURA_MULTIAGENTE_COLABORATIVA.md`.
- **Ícones exclusivos nos Ajustes de Sua empresa:** cada opção tem um ícone próprio, ligado à finalidade (paleta, grade, pasta, etiqueta, selo de %, estrela, cartão, imagem, relógio, calendário, escudo, pessoas, robô, megafone…), com validação automática contra repetição. Ver `docs/ICONES_MENUS.md`.
- **Permissões de Agendamento:** em Sua empresa › Ajustes, o dono liga duas opções independentes. *Agendamento de pedidos* deixa o cliente escolher o dia e o horário do pedido, dentro do funcionamento. *Agendamento de serviços com aprovação* transforma o agendamento numa solicitação "Aguardando aprovação": nada é confirmado sozinho e o horário fica livre, salvo reserva temporária. O dono decide quem pode usar cada opção (todos, quem tem conta ou clientes selecionados) e pode delegar a aprovação a funcionários. O painel `/x/solicitacoes` tem as ações aprovar (com revalidação do horário), recusar, sugerir outro horário (o cliente aceita ou recusa) e detalhes, com notificações e auditoria. Desligadas, os fluxos atuais continuam iguais. Ver `docs/PERMISSOES_AGENDAMENTO.md`.
- **Catálogo do chat da empresa em carrossel:** os cards de produtos e serviços no chat do agente (`/a/:id`) viram um carrossel horizontal com cards amplos (~82% da largura no celular, 300 px em telas maiores), imagem 4:3 em destaque, descrição, preço e condições, botão maior, próximo card parcialmente visível, indicador de posição, setas, deslize com o dedo, arraste com o mouse e teclado. As categorias continuam separadas (cada uma com seu carrossel) e Agendar/Adicionar seguem iguais. Ver `docs/CARROSSEL_CATALOGO.md`.
- **Fase 9 — Laboratório de Inteligência (admin):** página `/admin/laboratorio` (atalho na aba Laboratório de IA) para pesquisa e evolução controlada. Tem visão geral (métricas reais, estimativas e indicadores experimentais separados), Arena com 10 categorias de desafios e desafios personalizados, simulador de conversas com avaliação por mensagem, laboratório de agentes (testar, comparar, colaboração, especialistas novos em experimentação), centro de diagnóstico, central de melhorias, experimentos atual × experimental, controle de evolução e desafios contínuos programados. Tudo roda com usuário sintético e dados fictícios. Nada chega aos usuários sem aprovação, com liberação gradual e reversão. Acesso: Administrador Principal ou permissão "Laboratório de Inteligência". Ver `docs/LABORATORIO_INTELIGENCIA.md`. Migração `036_laboratorio_inteligencia.sql`.
- **Fase 8 — autonomia operacional:** o assistente entende objetivos do dia a dia ("organize minha semana", "crie lembretes para os compromissos de amanhã", "apague as tarefas concluídas"), planeja etapas com dependências e executa com os serviços existentes, sem módulos duplicados. Cada resultado é conferido no sistema antes de ser relatado. Há três níveis de autonomia: 1 automático, 2 "sim", 3 "autorizo EX-…" para exclusões e pagamentos. A execução tem identificador único, proteção contra repetição, controle de versão, autorrecuperação (classifica o erro, repete só o seguro, usa alternativa, para em risco de inconsistência), segundo plano com progresso, cancelamento e aviso, retomada após queda e reversão. As ferramentas da IA passam pelos mesmos níveis. Página `/execucoes`; painel em Cérebro e busca → Autonomia operacional. Ver `docs/AUTONOMIA_OPERACIONAL.md`. Migração `035`.
- **Fase 7 — inteligência preditiva:** analistas de agenda, tarefas, finanças, clientes/comercial, problemas e hábitos olham o histórico do próprio usuário. Eles antecipam conflitos de horário, compromissos sem contato ou confirmação, risco de esquecimento, pós-atendimento, contas e gastos fora do padrão, retornos de clientes, compras recorrentes, duplicidades e oportunidades de campanha. Cada item é **fato** ou **estimativa com % de confiança** e base, e o assistente diz quando faltam dados. Nada é alterado sozinho. As previsões são conferidas depois (acertou/errou) e há retroteste com o histórico. Os avisos são controlados pelo usuário (categorias, canais, frequência, horário de silêncio, sem repetir). Página `/previsoes`; painel em Cérebro e busca → Inteligência preditiva; integrada aos agentes e ao aprendizado contínuo. Ver `docs/INTELIGENCIA_PREDITIVA.md`. Migração `034`.
- **Fase 6 — aprendizado contínuo:** o assistente aprende com avaliações, correções, reclamações e falhas, só a partir de notas e rótulos de quem autorizou. Ele encontra padrões ponderados por usuário (com mínimo de usuários distintos e contas suspeitas excluídas), compara estratégias e versões, faz autodiagnóstico e gera propostas numa **política aprendida** de lista fechada, sem código e sem modelo. Cada proposta é testada num ambiente isolado (precisão, naturalidade, velocidade, consistência e resolução, antes × depois) e só entra com aprovação do administrador, gradual ou total. Dá para promover, reverter ou restaurar qualquer versão, e a liberação gradual para sozinha em caso de regressão. Painel → Cérebro e busca → Aprendizado contínuo; consentimento em Minha memória. Ver `docs/APRENDIZADO_CONTINUO.md`. Migração `033`.
- **Compromissos (correção crítica):** a edição abre e altera só o compromisso escolhido, pelo identificador. Antes, a Agenda identificava pelo título e horário e podia editar outro. O chat agenda com cliente, telefone, valor total, sinal em % ou R$ (pergunta quando é ambíguo), valor pago e observação, confere antes de salvar e grava um único registro. A nova seção Configurações → Compromissos permite editar tudo, inclusive a situação, com histórico e proteção contra edição simultânea. A IA ganhou `update_appointment`, que edita por id e nunca cria outro. Ver `docs/COMPROMISSOS.md`.
- **Fase 5 — memória evolutiva:** a memória existente ganhou camadas (curto prazo, conversação, longo prazo, preferências, experiências), recuperação por significado local (radicais, grupos de assunto, erros de digitação, BM25, nomes próprios) com cache por usuário (~0,7 ms com 1000 memórias), associação entre memórias e conversas do mesmo usuário, versões com origem e data (corrigida a perda do valor anterior e a contradição tratada como duplicata), experiências individuais usadas pelo núcleo e pelos agentes, e privacidade (consentimento, retenção configurável, exportar, corrigir e apagar tudo). Página do usuário: `/minha-memoria` (atalho em Perfil → Memória do assistente). Ver `docs/MEMORIA_EVOLUTIVA.md`. Migração `032`.
- **Fase 4 — arquitetura multiagente:** coordenador central que mede a complexidade e, só em pedidos complexos, mobiliza agentes internos (pesquisa, análise, vendas, planejamento, escrita) em duas ondas sobre um quadro com acesso controlado; execução continua exclusiva da IA principal com as ferramentas; divergências entre agentes detectadas; resposta única (sem citar agentes); prazo, disjuntor e falhas isoladas. Painel: Inteligência avançada → Coordenação multiagente. Ver `docs/MULTIAGENTE.md`.
- **Fase 3 — diagnóstico e desempenho:** corpus sintético de conversas reais (formal, gíria, voz sem pontuação, erros de digitação) com conjunto de validação separado; acerto do núcleo 86,1% → 100%; consultas ao banco por mensagem com IA 72 → 34 (memória por requisição, sem risco de dado desatualizado; `MEMO_REQUISICAO=0` desliga); etapas da IA (preparo, modelo, ferramentas, conclusão) e consultas por mensagem na telemetria; diagnóstico e desempenho no painel e no monitor de regressão. Ver `docs/diagnostico/FASE3.md` e `docs/diagnostico/COMPARACAO.md`. Linha de comando: `npx tsx test/diagnostico/diagnostico.ts`.
- **Inteligência avançada (Nível 2):** sobre o Cérebro cognitivo — fio da conversa, planejamento com acompanhamento das etapas, especialistas dinâmicos com coordenação central (reaproveitando os domínios existentes), memória por relevância com atualização em vez de duplicata, autoverificação de respostas importantes, avaliação 👍/👎 com envio de oportunidades ao Laboratório de IA (testes e aprovação), sugestões proativas com limite, execução verificada no banco e avaliação contínua (bateria automática, indicadores e alerta de regressão). Cada capacidade tem chave própria em Cérebro e busca → Inteligência avançada. Ver `docs/INTELIGENCIA_NIVEL2.md`. Migração `031`.
- **Cérebro cognitivo (inteligência conversacional avançada):** camada aditiva que lê intenção, contexto, lacunas, ambiguidades e contradições antes de a IA responder, orienta o tom e as capacidades reais, confere a resposta depois (ação afirmada sem confirmação, links inventados, tom robótico), exige confirmação para ações sensíveis e avalia cada resposta (só notas, sem texto). Painel: Cérebro e busca → Inteligência cognitiva. Ver `docs/CEREBRO_COGNITIVO.md`. Migração `030`.
- **Aprendizagem adaptativa e memória evolutiva:** o assistente aprende correções e preferências de cada usuário (persistente, individual, silencioso e natural), recupera só o que é relevante em novas conversas e evita repetir erros; a memória global só muda com aprovação do administrador. Ativo por padrão (chave global do administrador); cada aprendizado chega automaticamente à fila de revisão do painel (aprovar, rejeitar ou editar). Ver `docs/APRENDIZAGEM_ADAPTATIVA.md`. Migrações `023_aprendizagem_adaptativa.sql` e `028_aprendizados_revisao.sql`.
- **Contadores sincronizados de pedidos e agendamentos:** serviço único `BusinessActivityCounters` (`GET /api/v2/counters`) alimenta o menu lateral do Chat e Sua empresa > Pedidos/Agenda, com atualização sem recarregar. Ver `docs/CONTADORES_PEDIDOS_AGENDAMENTOS.md`.
- **Campo de digitação do chat (compacto ↔ expandido):** compacto em uma linha (+ à esquerda, “Pergunte qualquer coisa”, microfone e enviar azul com seta ↑); ao tocar, expande na vertical (“Digite sua mensagem…”, até 40% da tela/260 px, rola depois), com + embaixo à esquerda e microfone + enviar embaixo à direita; sem botão “Auto”. Funções preservadas (anexos, ditar/gravar, Enter envia, Shift+Enter quebra linha, sem envio duplicado, carregamento no botão). Em telas curtas (teclado aberto) o cabeçalho rola para o campo não sumir; respeita a área segura. O componente está no pacote compilado `frontend/public/assets/index-MaCmp03.js` (+ `.css`); como o servidor guarda `/assets/*` com cache imutável, os arquivos ganharam novo nome.
- **Vitrine de Links (admin):** links cadastrados no painel aparecem nos chats ao digitar `/` (menu filtrável, card com imagem e botão), busca determinística, públicos e canais, contagem de acessos e cliques. Veja `docs/VITRINE_LINKS.md`. No chat do assistente o card é gravado como mensagem `link_card` do histórico (persistente por conversa e em ordem cronológica); veja `docs/VITRINE_LINKS.md`. Palavras-chave no chat: palavra cadastrada (sozinha ou em frase) mostra os cards das empresas disponíveis (`docs/PALAVRAS_CHAVE_CHAT.md`). Modo de aprovação de anúncios (manual ou automático, só para novos envios): `docs/APROVACAO_ANUNCIOS.md`. Modalidade do catálogo exclusiva por empresa: produtos OU serviços, validada no banco e no servidor, troca com aviso e confirmação (`docs/MODALIDADE_CATALOGO.md`). Organizar módulos: a escolha do usuário (`settings.menuLayout`) é a fonte única do menu lateral (`docs/ORGANIZAR_MODULOS_MENU.md`). Empresas próximas no chat: ao autorizar a localização (GPS ou cidade), a própria resposta vira os cards reais, mesma busca da página Empresas parceiras (`docs/LOCALIZACAO_CHAT.md`). Botão "Sua empresa" no cabeçalho: só com anúncio aprovado pelo admin, validado no servidor (`docs/BOTAO_SUA_EMPRESA_CABECALHO.md`). Campo de digitação: compacto (+ | texto | microfone | enviar) e caixa vertical ao digitar texto maior (`docs/CAMPO_DIGITACAO.md`). Botões rápidos do chat: lista minimalista perto do campo de digitação, com "Ver mais" no celular; somem na 1ª interação e voltam em nova conversa (`docs/BOTOES_RAPIDOS_CHAT.md`).
- **Inteligência de Agenda (capacidade da IA):** calendário empresarial (feriados, intervalos, exceções, bloqueios), cálculo de horários reais no motor existente, alertas proativos e modos manual/inteligente/automático. Veja `docs/INTELIGENCIA_AGENDA.md`.
- **Links públicos limpos dos agentes:** `meuassistente.chat/nome-da-empresa` (sem `/g-`), exclusivos, personalizáveis, com redirecionamento dos links antigos. Ver `docs/LINKS_PUBLICOS_AGENTES.md`.

- **Cérebro do Chat transparente:** nova seção *Capacidades da inteligência* (Painel → Cérebro e busca) lista tudo o que o chat sabe e faz, por categoria, com status real (ativo, inativo, pendente, em desenvolvimento). Ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`.
- **Tema único por empresa** aplicado no catálogo, nas janelas de produto e no agente — ver `docs/TEMA_VISUAL_EMPRESA.md`.
- **Cérebro com regras executáveis, aprendizado pendente de aprovação, versões, conflitos e registro de uso** — ver `docs/CEREBRO_CONHECIMENTO_REGRAS.md`. Migração `018_cerebro_regras.sql` (aditiva; roda sozinha ao subir o servidor).

- **Agenda, financeiro, endereço, imagens, nome do atendente e variações** — agendamento pelo chat entra na Agenda e bloqueia o horário; pagamentos geram lançamento único no Financeiro; endereço manual ou automático; ver `docs/CORRECOES_AGENDA_FINANCEIRO.md`.
- **Sinal antecipado no chat e tipo de catálogo (Produtos / Serviços / ambos)** — ver as seções 8 e 9 do mesmo documento.
- **Conhecimento comercial integrado (atendimento, marketing, vendas e CRM)** — ver `docs/CONHECIMENTO_COMERCIAL.md`.
## Estrutura
- `server/` — backend Node.js + TypeScript (PostgreSQL)
- `frontend/public/` — app original (PWA) já corrigido
- `prototipo/` — protótipo navegável aprovado (referência)
- `tools/ia-gateway/` — gateway de IAs com troca automática e painel (pode ser usado já na VPS)
- `deploy/` — Nginx e scripts de instalação, atualização, backup e restauração
- `docs/` — guias, relatórios e especificação

## Subir no GitHub (sem enviar segredos)
O arquivo `.env` nunca vai para o GitHub (já está no `.gitignore`). Envie o ZIP inteiro para o repositório e descompacte na VPS, como você já faz.

---

# Meu Assistente — versão independente da Netlify

App pessoal com chat de IA que organiza gastos, contas, tarefas, compromissos, lembretes, compras e anotações.
Esta versão roda em qualquer servidor Linux (ex.: VPS Hostinger) com **Node.js + PostgreSQL**, sem Netlify.

## Estrutura

```
frontend/public/     App original (PWA compilado), com os nomes de arquivos corrigidos + index.html novo
server/              Backend próprio (Node.js 22 + TypeScript)
  src/               Código-fonte (API REST, autenticação, IA, agendador)
  migrations/        Estrutura do banco PostgreSQL (aplicada automaticamente)
  test/              Testes automatizados
deploy/nginx/        Configuração do Nginx (proxy reverso + HTTPS)
deploy/scripts/      install.sh, update.sh, backup.sh, restore.sh, smoke-test.sh
docs/                Relatórios, guia de instalação e checklist
original/            netlify.toml original (só referência; não é usado)
Dockerfile, docker-compose.yml, .env.example
```

## Instalação rápida na VPS (Ubuntu)

```bash
unzip MEU_ASSISTENTE_COMPLETO.zip
cd MEU_ASSISTENTE_COMPLETO
sudo bash deploy/scripts/install.sh
```

O script instala Docker, Nginx e Certbot, cria o `.env` (com senha do banco aleatória), sobe o banco e o app,
configura o Nginx e o HTTPS. Passo a passo detalhado: **docs/GUIA_INSTALACAO_VPS.md**.

Depois, abra o site e crie a primeira conta em **/cadastro** — ela vira o **Administrador Principal**.

## Configuração essencial (.env)

| Variável | Para quê |
|---|---|
| `PUBLIC_URL` | Endereço do site (https://seudominio) |
| `POSTGRES_PASSWORD` | Senha do banco (gerada pelo install.sh) |
| `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` | IA do chat (OpenAI, OpenRouter, Gemini, Groq, Ollama…) |
| `RESEND_API_KEY`, `MAIL_FROM` | E-mail de recuperação de senha |

Sem `AI_API_KEY` o chat responde com o aviso "IA não configurada" (o resto do app funciona).
Sem `RESEND_API_KEY` o link de recuperação de senha aparece apenas no log do servidor (`docker compose logs app`).

## Comandos do dia a dia

```bash
docker compose ps                      # situação dos serviços
docker compose logs -f app             # logs do app
sudo bash deploy/scripts/update.sh     # atualizar (faz backup antes)
bash deploy/scripts/backup.sh          # backup manual (há backup diário às 03:00)
sudo bash deploy/scripts/restore.sh backups/ARQUIVO.sql.gz
bash deploy/scripts/smoke-test.sh      # teste rápido do sistema instalado
MA_EMAIL=… MA_SENHA=… bash deploy/scripts/validar-estabilizacao.sh   # build + contêiner + logs + saúde + login/chat reais
```

## Desenvolvimento local (sem Docker)

```bash
cd server
npm install
cp ../.env.example ../.env   # preencha DATABASE_URL apontando para um PostgreSQL
npm run dev                  # http://localhost:3000
npm test                     # testes automatizados (usam SQLite embutido, não precisam de PostgreSQL)
TEST_PG_URL=postgres://usuario@localhost/banco_de_teste_vazio npm test   # a mesma suíte contra PostgreSQL real
npm run typecheck            # TypeScript estrito (strict + strictNullChecks), deve dar 0 erros
npm run build && npm start   # produção
```

## O que funciona e o que não foi reconstruído

Veja **docs/RELATORIO_RECONSTRUCAO.md**. Resumo: autenticação completa (com 2FA), chat com IA que grava registros,
agenda, financeiro, Meu Dia, notificações, memória, modo offline e painel de usuários funcionam.
Planos/Mercado Pago, fiscal/DAS, mercado/B3, estúdio de vídeo, eleições, push, e-mails, WhatsApp, treinos,
alimentação, remédios, mapas e espaços compartilhados **não** estavam no ZIP e respondem
"módulo não reconstruído" (erro 501), sem telas falsas.
