-- Fase 7 — Inteligência preditiva. Tudo aditivo: nenhum registro existente é alterado (previsões nunca mudam dados).
-- Previsões VERIFICÁVEIS (estimativas): registradas para conferir depois se acertaram (precisão real).
CREATE TABLE IF NOT EXISTS predictions (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         TEXT NOT NULL,                 -- conta_recorrente | retorno_cliente | gasto_mes | compra_recorrente
  pkey         TEXT NOT NULL,                 -- chave estável (evita registrar a mesma previsão duas vezes)
  payload      TEXT NOT NULL DEFAULT '{}',    -- o que se espera (do próprio usuário; o painel do administrador só vê contagens)
  confidence   INTEGER,                       -- 0..100
  expected_from TEXT,                         -- AAAA-MM-DD início da janela
  expected_to  TEXT,                          -- AAAA-MM-DD fim da janela
  status       TEXT NOT NULL DEFAULT 'aberta',-- aberta | acertou | errou | cancelada
  resolved_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS predictions_key ON predictions (user_id, pkey);
CREATE INDEX IF NOT EXISTS predictions_status ON predictions (status, expected_to);
-- Alertas e recomendações apresentados (chat, notificação ou página) e a reação do usuário.
CREATE TABLE IF NOT EXISTS predictive_alerts (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ikey        TEXT NOT NULL,                  -- chave estável do sinal (ex.: conflito:12:15)
  tipo        TEXT NOT NULL,                  -- conflito | sem_contato | confirmar | esquecimento | ...
  categoria   TEXT NOT NULL,
  natureza    TEXT NOT NULL,                  -- fato | estimativa
  confidence  INTEGER,
  urgencia    TEXT NOT NULL,
  canal       TEXT NOT NULL,                  -- chat | notificacao | pagina
  status      TEXT NOT NULL DEFAULT 'apresentada', -- apresentada | aceita | dispensada | falso
  created_at  TIMESTAMPTZ NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS predictive_alerts_user ON predictive_alerts (user_id, ikey, id);
-- Preferências de proatividade por usuário: categorias, canais, frequência e horário de silêncio (JSON).
ALTER TABLE user_intel_prefs ADD COLUMN predictive TEXT;
-- Reversão: DROP TABLE predictions, predictive_alerts; (a coluna predictive pode ficar: é opcional)
