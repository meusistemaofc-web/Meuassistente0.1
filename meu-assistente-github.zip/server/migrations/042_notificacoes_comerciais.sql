-- Motor de Notificações Comerciais (ex.: Agente de Atendimento depois da publicação do anúncio).
-- Só acrescenta tabelas; nada existente é alterado. As mensagens usam a central de notificações já existente.
-- Configuração de cada campanha (mensagens, intervalos e chave liga/desliga editáveis no painel).
CREATE TABLE IF NOT EXISTS com_campanhas (
  id              TEXT PRIMARY KEY,
  ativo           BOOLEAN NOT NULL DEFAULT TRUE,
  config          JSONB NOT NULL DEFAULT '{}',
  ativada_em      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_por  BIGINT
);
-- Uma inscrição por campanha e por alvo (dono ou empresa): nunca recomeça a mesma sequência para quem já recebeu.
CREATE TABLE IF NOT EXISTS com_inscricoes (
  id              BIGSERIAL PRIMARY KEY,
  campanha        TEXT NOT NULL,
  chave           TEXT NOT NULL,
  business_id     BIGINT NOT NULL,
  owner_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status          TEXT NOT NULL DEFAULT 'ativa',
  motivo          TEXT,
  inicio_em       TIMESTAMPTZ NOT NULL,
  proxima_etapa   INTEGER NOT NULL DEFAULT 0,
  ultimo_envio_em TIMESTAMPTZ,
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finalizado_em   TIMESTAMPTZ,
  UNIQUE (campanha, chave)
);
CREATE INDEX IF NOT EXISTS com_inscricoes_status ON com_inscricoes (campanha, status);
CREATE INDEX IF NOT EXISTS com_inscricoes_owner ON com_inscricoes (owner_id);
-- Registro de envios, visualizações, cliques, conversões e interrupções (um por etapa e tipo).
CREATE TABLE IF NOT EXISTS com_eventos (
  id              BIGSERIAL PRIMARY KEY,
  campanha        TEXT NOT NULL,
  inscricao_id    BIGINT NOT NULL REFERENCES com_inscricoes(id) ON DELETE CASCADE,
  business_id     BIGINT NOT NULL,
  owner_id        BIGINT NOT NULL,
  etapa           INTEGER NOT NULL DEFAULT -1,
  tipo            TEXT NOT NULL,
  notification_id BIGINT,
  dados           JSONB NOT NULL DEFAULT '{}',
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (inscricao_id, etapa, tipo)
);
CREATE INDEX IF NOT EXISTS com_eventos_campanha ON com_eventos (campanha, tipo);
CREATE INDEX IF NOT EXISTS com_eventos_owner ON com_eventos (owner_id, tipo);
