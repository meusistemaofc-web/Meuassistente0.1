-- CRM de "Sua empresa". Somente ADITIVA: não altera pedidos, agendamentos, usuários nem clientes existentes.
-- O cadastro de clientes continua sendo users + orders; o CRM guarda apenas o relacionamento (contato, funil, tarefas, interações)
-- e se LIGA aos registros existentes (crm_contacts.user_id, crm_order_links) sem copiar pedidos ou agendamentos.
CREATE TABLE IF NOT EXISTS crm_contacts (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL,
  user_id     BIGINT,                          -- usuário do app já existente (reuso do cadastro)
  name        TEXT NOT NULL,
  phone       TEXT,
  phone_key   TEXT,                            -- DDD + 8 últimos dígitos (iguala variações: +55, 9º dígito, máscara)
  email       TEXT,
  email_key   TEXT,
  company     TEXT,
  kind        TEXT NOT NULL DEFAULT 'lead',    -- lead | cliente
  source      TEXT,                            -- origem do contato (manual, chat, pedido, agendamento, indicação…)
  category    TEXT,
  tags        TEXT,                            -- JSON: lista de etiquetas
  notes       TEXT,
  owner_name  TEXT,                            -- responsável
  archived    SMALLINT NOT NULL DEFAULT 0,
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_contacts_biz ON crm_contacts (business_id, kind);
CREATE INDEX IF NOT EXISTS crm_contacts_user ON crm_contacts (business_id, user_id);
CREATE INDEX IF NOT EXISTS crm_contacts_phone ON crm_contacts (business_id, phone_key);
CREATE INDEX IF NOT EXISTS crm_contacts_email ON crm_contacts (business_id, email_key);
CREATE TABLE IF NOT EXISTS crm_stages (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL,
  name        TEXT NOT NULL,
  color       TEXT NOT NULL DEFAULT '#3B5BDB',
  position    INTEGER NOT NULL DEFAULT 0,
  kind        TEXT NOT NULL DEFAULT 'aberta', -- aberta | ganha | perdida
  probability INTEGER NOT NULL DEFAULT 0,
  negotiating SMALLINT NOT NULL DEFAULT 0,    -- conta como "em negociação" nos indicadores
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_stages_biz ON crm_stages (business_id, position);
CREATE TABLE IF NOT EXISTS crm_opps (
  id             BIGSERIAL PRIMARY KEY,
  business_id    BIGINT NOT NULL,
  contact_id     BIGINT NOT NULL,
  title          TEXT NOT NULL,
  value          NUMERIC(14,2) NOT NULL DEFAULT 0,
  stage_id       BIGINT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'aberta', -- aberta | ganha | perdida
  probability    INTEGER NOT NULL DEFAULT 0,
  expected_close TEXT,                           -- AAAA-MM-DD
  owner_name     TEXT,
  notes          TEXT,
  lost_reason    TEXT,
  closed_at      TIMESTAMPTZ,
  created_by     BIGINT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_opps_biz ON crm_opps (business_id, status);
CREATE INDEX IF NOT EXISTS crm_opps_contact ON crm_opps (contact_id);
CREATE TABLE IF NOT EXISTS crm_tasks (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL,
  contact_id  BIGINT,
  opp_id      BIGINT,
  title       TEXT NOT NULL,
  kind        TEXT NOT NULL DEFAULT 'outra',  -- contato | retorno | proposta | confirmar | acompanhamento | reuniao | outra
  due_at      TEXT,                           -- AAAA-MM-DD ou AAAA-MM-DDTHH:MM (fuso da empresa)
  priority    TEXT NOT NULL DEFAULT 'media',  -- baixa | media | alta
  status      TEXT NOT NULL DEFAULT 'aberta', -- aberta | concluida | cancelada
  owner_name  TEXT,
  notes       TEXT,
  notified_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_tasks_biz ON crm_tasks (business_id, status);
CREATE TABLE IF NOT EXISTS crm_events (          -- linha do tempo própria do CRM (o resto é consultado dos registros originais)
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL,
  contact_id  BIGINT,
  opp_id      BIGINT,
  task_id     BIGINT,
  kind        TEXT NOT NULL,                   -- cadastro | interacao | observacao | funil | oportunidade | tarefa | vinculo
  channel     TEXT,                            -- ligacao | whatsapp | email | reuniao | chat | presencial | outro
  actor       TEXT,
  text        TEXT,
  data        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_events_contact ON crm_events (business_id, contact_id);
CREATE INDEX IF NOT EXISTS crm_events_opp ON crm_events (opp_id);
CREATE TABLE IF NOT EXISTS crm_order_links (     -- liga um pedido/agendamento EXISTENTE a um contato (sem copiar o pedido)
  order_id    BIGINT PRIMARY KEY,
  business_id BIGINT NOT NULL,
  contact_id  BIGINT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS crm_order_links_contact ON crm_order_links (contact_id);
CREATE TABLE IF NOT EXISTS crm_labels (          -- categorias e etiquetas personalizadas por empresa
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL,
  kind        TEXT NOT NULL,                   -- categoria | etiqueta | responsavel
  name        TEXT NOT NULL,
  color       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS crm_labels_uniq ON crm_labels (business_id, kind, name);
CREATE TABLE IF NOT EXISTS crm_settings (        -- regras do CRM por empresa (JSON): permissões da IA e critérios da inteligência comercial
  business_id BIGINT PRIMARY KEY,
  data        TEXT NOT NULL DEFAULT '{}',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
