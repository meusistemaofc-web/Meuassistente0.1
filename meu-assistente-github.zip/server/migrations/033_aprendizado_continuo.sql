-- Fase 6 — Aprendizado contínuo. Tudo aditivo: nenhum dado existente é alterado.
-- Política aprendida: parâmetros de comportamento em lista fechada (nunca código nem modelo), versionada.
CREATE TABLE IF NOT EXISTS learning_policy_versions (
  id          BIGSERIAL PRIMARY KEY,
  policy      TEXT NOT NULL,                 -- JSON validado (raciocínio, memória, agentes, ferramentas, qualidade)
  parent_id   BIGINT,                        -- versão de onde saiu (para reverter)
  proposal_id BIGINT,                        -- melhoria que a originou (null = versão inicial/reversão)
  note        TEXT,
  created_by  BIGINT,                        -- administrador
  created_at  TIMESTAMPTZ NOT NULL
);
-- Propostas de melhoria: geradas pela análise (ou pelo administrador), testadas em ambiente isolado e aprovadas no painel.
CREATE TABLE IF NOT EXISTS learning_proposals (
  id           BIGSERIAL PRIMARY KEY,
  kind         TEXT NOT NULL,                -- raciocinio | memoria | agentes | ferramentas | qualidade | regra
  title        TEXT NOT NULL,
  rationale    TEXT NOT NULL,
  evidence     TEXT NOT NULL DEFAULT '{}',   -- só contagens anônimas (nunca texto de conversa)
  change       TEXT NOT NULL,                -- mudança na política: {op, caminho, valor}
  fingerprint  TEXT NOT NULL,                -- evita propor duas vezes a mesma coisa
  status       TEXT NOT NULL DEFAULT 'proposta', -- proposta | testada | reprovada | gradual | ativa | rejeitada | revertida
  test_result  TEXT,                         -- comparação antes × depois do ambiente de experimentação
  version_id   BIGINT,                       -- versão da política criada na aprovação
  created_by   TEXT NOT NULL DEFAULT 'sistema',
  decided_by   BIGINT,
  decided_at   TIMESTAMPTZ,
  history      TEXT NOT NULL DEFAULT '[]',   -- [{em, de, para, por, nota}]
  created_at   TIMESTAMPTZ NOT NULL,
  updated_at   TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS learning_proposals_status ON learning_proposals (status, id);
-- Consentimento do usuário para contribuir ANONIMAMENTE com a melhoria global (null = padrão: sim; pode desligar).
ALTER TABLE user_intel_prefs ADD COLUMN contribute BOOLEAN;
-- Reversão: DROP TABLE learning_policy_versions, learning_proposals; (a coluna contribute pode ficar: é opcional)
