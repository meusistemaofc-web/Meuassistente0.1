-- Motor de Aprendizagem Adaptativa: memória evolutiva INDIVIDUAL (camada 2). Somente ADITIVA.
-- Camada 1 (contexto da conversa) continua em conversation_context; camada 3 (global) continua no Cérebro/Laboratório de IA
-- e só muda por aprovação do administrador. Nada aqui altera o modelo de IA nem outros usuários.
CREATE TABLE IF NOT EXISTS learnings (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,  -- dono do aprendizado (isolamento por usuário)
  business_id     BIGINT,                          -- empresa relacionada, quando aplicável (vazio = vale para a pessoa)
  conversation_id TEXT,                            -- conversa em que nasceu (origem; pontuais só valem nela)
  operation       TEXT NOT NULL,                   -- agendamento | financeiro | exclusao | lembrete | tarefa | compra | geral ...
  kind            TEXT NOT NULL,                   -- consultar_antes | confirmar_antes | considerar_intervalo | evitar | estilo | fazer_assim | preferencia_inferida
  context         TEXT,                            -- contexto da interação
  action_done     TEXT,                            -- ação que o sistema executou
  problem         TEXT,                            -- problema identificado
  correction      TEXT,                            -- correção dita pelo usuário (texto original, limitado)
  preference      TEXT,                            -- preferência identificada
  rule            TEXT NOT NULL,                   -- regra operacional aprendida (frase curta)
  scope           TEXT NOT NULL DEFAULT 'permanente', -- permanente | pontual | candidato (aguarda esclarecimento)
  confidence      REAL NOT NULL DEFAULT 0.5,       -- 0..1
  frequency       INTEGER NOT NULL DEFAULT 1,      -- quantas vezes foi reforçado
  uses            INTEGER NOT NULL DEFAULT 0,      -- quantas vezes foi aplicado
  state           TEXT NOT NULL DEFAULT 'ativo',   -- ativo | pausado | substituido
  history         TEXT NOT NULL DEFAULT '[]',      -- histórico de alterações (JSON)
  created_at      TIMESTAMPTZ NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL,
  last_used_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_learnings_user ON learnings (user_id, state, operation);
