-- Lojas Conectadas: uma conta (central) acompanha e administra pedidos, agendamentos e notificações de várias lojas.
-- Somente ADITIVA. Cada loja continua com o próprio dono, cadastro, catálogo, clientes, pedidos e agendamentos:
-- a conexão é só uma camada de acesso e de notificações (nada é copiado nem transferido).
-- Reversão manual: DROP TABLE store_link_events; DROP TABLE store_links; DROP TABLE store_link_keys; DROP TABLE store_notif_prefs;
--   ALTER TABLE notifications DROP COLUMN business_id; DELETE FROM schema_migrations WHERE version = '048_lojas_conectadas.sql';
CREATE TABLE IF NOT EXISTS store_link_keys (
  id           BIGSERIAL PRIMARY KEY,
  hub_user_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,   -- conta central que gerou a chave
  key_hash     TEXT NOT NULL UNIQUE,                                      -- SHA-256 da chave (a chave em si nunca é guardada)
  prefix       TEXT NOT NULL,                                             -- início da chave, só para identificar na lista
  max_uses     INTEGER NOT NULL DEFAULT 1,
  uses         INTEGER NOT NULL DEFAULT 0,                                -- incremento atômico (uses < max_uses)
  expires_at   TIMESTAMPTZ NOT NULL,
  revoked_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS store_link_keys_hub ON store_link_keys (hub_user_id, id);
CREATE TABLE IF NOT EXISTS store_links (
  id           BIGSERIAL PRIMARY KEY,
  hub_user_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,   -- conta central
  business_id  BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id     BIGINT NOT NULL,                                           -- dono da loja quando pediu a conexão (a posse NÃO muda)
  role         TEXT NOT NULL DEFAULT 'operador',                          -- administrador | operador (definido pelo dono da loja)
  status       TEXT NOT NULL DEFAULT 'pendente',                          -- pendente | ativo | recusado | desvinculado
  key_id       BIGINT,
  requested_by BIGINT,
  decided_by   BIGINT,
  decided_at   TIMESTAMPTZ,
  unlinked_by  BIGINT,
  unlinked_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- no máximo UMA conexão pendente/ativa entre a mesma central e a mesma loja
CREATE UNIQUE INDEX IF NOT EXISTS store_links_aberta ON store_links (hub_user_id, business_id) WHERE status IN ('pendente', 'ativo');
CREATE INDEX IF NOT EXISTS store_links_business ON store_links (business_id, status);
CREATE INDEX IF NOT EXISTS store_links_hub ON store_links (hub_user_id, status);
CREATE TABLE IF NOT EXISTS store_link_events (
  id          BIGSERIAL PRIMARY KEY,
  link_id     BIGINT NOT NULL REFERENCES store_links(id) ON DELETE CASCADE,
  actor_id    BIGINT,
  action      TEXT NOT NULL,          -- solicitada | aceita | recusada | desvinculada | papel
  detail      TEXT NOT NULL DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS store_link_events_link ON store_link_events (link_id, id);
-- preferências de notificação por loja (dono ou central): {pedidos, agendamentos, atualizacoes}; sem linha = tudo ligado
CREATE TABLE IF NOT EXISTS store_notif_prefs (
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  prefs       TEXT NOT NULL DEFAULT '{}',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, business_id)
);
-- loja de origem de cada notificação de pedido/agendamento (contadores e histórico por loja)
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS business_id BIGINT;
CREATE INDEX IF NOT EXISTS notifications_business ON notifications (user_id, business_id, id);
