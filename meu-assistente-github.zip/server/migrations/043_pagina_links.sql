-- Página de Links da empresa (exclusiva do anúncio completo). Só acrescenta uma tabela; nada existente é alterado.
-- rascunho = o que o dono está editando; publicado = o que o endereço público mostra (só muda ao publicar).
CREATE TABLE IF NOT EXISTS link_pages (
  business_id    BIGINT PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rascunho       JSONB NOT NULL DEFAULT '{}',
  publicado      JSONB,
  publicado_em   TIMESTAMPTZ,
  atualizado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  visitas        INTEGER NOT NULL DEFAULT 0,
  cliques        JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS link_pages_owner ON link_pages (owner_id);
