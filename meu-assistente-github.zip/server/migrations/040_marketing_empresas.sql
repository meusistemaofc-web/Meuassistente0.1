-- Central de Marketing das empresas: controle do proprietário, campanhas completas (nome, imagem, encerramento, rascunho),
-- execução confiável (trava por campanha, tentativas por destinatário, registro de cada execução) e auditoria.
-- Só acrescenta colunas e tabelas: nenhuma campanha, envio ou autorização existente é alterada ou apagada.

-- 2º nível de permissão: o proprietário liga/desliga a Central para a própria empresa (independente por empresa).
CREATE TABLE IF NOT EXISTS mkt_empresa (
  business_id   BIGINT PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  ativo         BOOLEAN NOT NULL DEFAULT FALSE,
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- Empresas que já usavam a Central antes desta versão continuam com ela ligada (nada muda para elas).
INSERT INTO mkt_empresa (business_id, owner_id, ativo, atualizado_em)
  SELECT DISTINCT c.business_id, c.owner_id, TRUE, CURRENT_TIMESTAMP FROM mkt_campaigns c
  WHERE c.business_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM mkt_empresa e WHERE e.business_id = c.business_id);

-- Campanha completa. status: rascunho | agendada | enviando | concluida | cancelada | suspensa | expirada
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS nome TEXT;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS imagem TEXT;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS encerra_em TIMESTAMPTZ;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS fuso TEXT;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS falhas INTEGER NOT NULL DEFAULT 0;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS execucoes INTEGER NOT NULL DEFAULT 0;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS trava_ate TIMESTAMPTZ;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS suspensa_por TEXT;
ALTER TABLE mkt_campaigns ADD COLUMN IF NOT EXISTS atualizada_em TIMESTAMPTZ;

-- Envio por destinatário: tentativas e motivo da falha (status: enviado | falha | ignorado_*).
ALTER TABLE mkt_sends ADD COLUMN IF NOT EXISTS tentativas INTEGER NOT NULL DEFAULT 1;
ALTER TABLE mkt_sends ADD COLUMN IF NOT EXISTS erro TEXT;

-- Registro de cada execução do agendador.
CREATE TABLE IF NOT EXISTS mkt_execucoes (
  id           BIGSERIAL PRIMARY KEY,
  campaign_id  BIGINT NOT NULL REFERENCES mkt_campaigns(id) ON DELETE CASCADE,
  iniciada_em  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finalizada_em TIMESTAMPTZ,
  enviados     INTEGER NOT NULL DEFAULT 0,
  falhas       INTEGER NOT NULL DEFAULT 0,
  ignorados    INTEGER NOT NULL DEFAULT 0,
  resultado    TEXT,
  detalhe      TEXT
);
CREATE INDEX IF NOT EXISTS mkt_exec_camp ON mkt_execucoes (campaign_id, id);

-- Auditoria: criação, edição, programação, cancelamento, validação, suspensão, execução e liga/desliga da empresa.
CREATE TABLE IF NOT EXISTS mkt_auditoria (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT,
  campaign_id BIGINT,
  user_id     BIGINT,
  acao        TEXT NOT NULL,
  detalhe     TEXT,
  criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS mkt_aud_biz ON mkt_auditoria (business_id, id);
CREATE INDEX IF NOT EXISTS mkt_aud_camp ON mkt_auditoria (campaign_id, id);
