-- SOLICITAÇÃO DE CRÉDITO DO CLIENTE (sobre o Crédito da Loja da 070). Somente ADITIVA.
--  • credito_solicitacoes: pedido de limite de um cliente a UMA empresa (rascunho → pendente → aprovada | recusada |
--    info_solicitada → pendente … | cancelada | expirada). Dados cadastrais ficam CIFRADOS (dados_cifrados, AES-256-GCM do
--    cofre do servidor); só o CPF mascarado fica legível para listas. O relacionamento com a empresa é um retrato do momento
--    do envio (calculado dos pedidos reais). Consentimento (versão e data) obrigatório para enviar.
--  • credito_documentos: documento com foto, comprovante de endereço e selfie — conteúdo CIFRADO no banco (nunca em pasta
--    pública), com tipo, formato, tamanho, dimensões e hash; apagado (conteúdo zerado) pela política de retenção ou a pedido.
--  • credito_clientes ganha colunas (aditivas) para as condições aprovadas por cliente, a validade e a solicitação de origem:
--    o limite aprovado continua sendo o MESMO registro de limite do Crédito da Loja (nada de carteira paralela).
-- Reversão manual: DROP TABLE credito_documentos, credito_solicitacoes; as colunas novas de credito_clientes podem ficar
--   (têm valor padrão e são ignoradas pelo código anterior). DELETE FROM schema_migrations WHERE version = '071_credito_solicitacoes.sql';
CREATE TABLE IF NOT EXISTS credito_solicitacoes (
  id                 BIGSERIAL PRIMARY KEY,
  business_id        BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id            BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status             TEXT NOT NULL DEFAULT 'rascunho',
  dados_cifrados     TEXT NOT NULL DEFAULT '',
  cpf_mascara        TEXT NOT NULL DEFAULT '',
  limite_solicitado  NUMERIC(12,2) NOT NULL DEFAULT 0,
  parcelas_desejadas INTEGER NOT NULL DEFAULT 0,
  mensagem_cliente   TEXT NOT NULL DEFAULT '',
  relacionamento     TEXT NOT NULL DEFAULT '{}',
  notas_internas     TEXT NOT NULL DEFAULT '[]',
  pedido_info        TEXT NOT NULL DEFAULT '',
  decisao            TEXT NOT NULL DEFAULT '{}',
  consentimento_em   TIMESTAMPTZ,
  consentimento_versao TEXT NOT NULL DEFAULT '',
  enviada_em         TIMESTAMPTZ,
  decidido_por       BIGINT,
  decidido_em        TIMESTAMPTZ,
  docs_excluidos_em  TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS credito_solic_biz ON credito_solicitacoes (business_id, status);
CREATE INDEX IF NOT EXISTS credito_solic_user ON credito_solicitacoes (user_id, business_id);
CREATE TABLE IF NOT EXISTS credito_documentos (
  id              BIGSERIAL PRIMARY KEY,
  solicitacao_id  BIGINT NOT NULL REFERENCES credito_solicitacoes(id) ON DELETE CASCADE,
  business_id     BIGINT NOT NULL,
  user_id         BIGINT NOT NULL,
  tipo            TEXT NOT NULL,
  mime            TEXT NOT NULL DEFAULT '',
  tamanho         INTEGER NOT NULL DEFAULT 0,
  largura         INTEGER NOT NULL DEFAULT 0,
  altura          INTEGER NOT NULL DEFAULT 0,
  sha256          TEXT NOT NULL DEFAULT '',
  conteudo        TEXT NOT NULL DEFAULT '',
  excluido_em     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS credito_docs_solic ON credito_documentos (solicitacao_id, tipo);
ALTER TABLE credito_clientes ADD COLUMN condicoes TEXT NOT NULL DEFAULT '{}';
ALTER TABLE credito_clientes ADD COLUMN validade TEXT NOT NULL DEFAULT '';
ALTER TABLE credito_clientes ADD COLUMN solicitacao_id BIGINT;
