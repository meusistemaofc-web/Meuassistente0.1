-- Cérebro: natureza (consulta / diretriz / regra executável), escopo, prioridade, versão e regra executável.
-- Somente ADITIVA: nenhuma linha é apagada ou alterada de forma destrutiva. Itens existentes continuam funcionando como antes
-- (nature NULL = comportamento anterior: regras valem como consulta e como orientação para a IA).
ALTER TABLE brain_answers ADD COLUMN nature TEXT;
ALTER TABLE brain_answers ADD COLUMN scope TEXT NOT NULL DEFAULT 'chat';
ALTER TABLE brain_answers ADD COLUMN priority INTEGER NOT NULL DEFAULT 50;
ALTER TABLE brain_answers ADD COLUMN version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE brain_answers ADD COLUMN rule_action TEXT;
ALTER TABLE brain_answers ADD COLUMN rule_trigger TEXT;
ALTER TABLE brain_answers ADD COLUMN rule_params TEXT;
ALTER TABLE brain_answers ADD COLUMN rule_audience TEXT;
ALTER TABLE brain_answers ADD COLUMN approved_by TEXT;
ALTER TABLE brain_answers ADD COLUMN approved_at TIMESTAMPTZ;
-- conhecimentos cadastrados pelo administrador têm prioridade maior que os aprendidos
UPDATE brain_answers SET priority = 70 WHERE origin = 'admin';

-- uma linha por versão de cada item (conteúdo, quem mudou e por quê)
CREATE TABLE IF NOT EXISTS brain_versions (
  id         BIGSERIAL PRIMARY KEY,
  item_id    BIGINT NOT NULL,
  version    INTEGER NOT NULL,
  titulo     TEXT NOT NULL,
  conteudo   TEXT NOT NULL,
  kind       TEXT,
  nature     TEXT,
  status     TEXT,
  changed_by TEXT,
  nota       TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS brain_versions_item ON brain_versions (item_id, version);
-- versão 1 de tudo o que já existe (o conteúdo atual fica preservado como ponto de partida)
INSERT INTO brain_versions (item_id, version, titulo, conteudo, kind, nature, status, changed_by, nota, created_at)
  SELECT id, 1, question, answer, kind, NULL, status, 'migração', 'versão inicial preservada', created_at FROM brain_answers;

-- registro de uso: quando um conhecimento/regra foi usado e o que ele influenciou
CREATE TABLE IF NOT EXISTS brain_usage (
  id              BIGSERIAL PRIMARY KEY,
  item_id         BIGINT NOT NULL,
  version         INTEGER,
  channel         TEXT NOT NULL,
  user_id         BIGINT,
  business_id     BIGINT,
  conversation_id TEXT,
  message_id      BIGINT,
  role            TEXT NOT NULL,
  action          TEXT NOT NULL,
  effect          TEXT,
  result          TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS brain_usage_item ON brain_usage (item_id, id);
CREATE INDEX IF NOT EXISTS brain_usage_created ON brain_usage (created_at);
