-- Integrações das empresas (Mercado Pago, SMTP próprio e as próximas: WhatsApp, APIs externas…) em estrutura própria.
-- SOMENTE ADITIVA: cria tabelas novas; nenhum dado existente é alterado, recriado ou apagado por esta migração.
-- Motivo: as credenciais ficavam dentro do JSON businesses.data, que ~30 rotinas regravam por inteiro (editar anúncio,
-- cupons, lixeira, follow-up…). Uma regravação a partir de uma leitura antiga desfazia a renovação do token do Mercado
-- Pago (que troca o refresh token a cada renovação) e a empresa aparecia desconectada. Agora cada integração tem a sua
-- linha, gravada só pelo módulo de integrações, com versão (gravação atômica) e histórico (backup de cada versão).
-- A cópia dos dados que já existem em businesses.data é feita pelo aplicativo ao iniciar (lib/integracoes.ts), sem apagar
-- nada do lugar antigo.
-- Reversão manual: DROP TABLE empresa_integracoes_historico; DROP TABLE empresa_integracoes;
--   DELETE FROM schema_migrations WHERE version = '057_integracoes_empresas.sql';
--   (o código anterior volta a ler businesses.data, que foi mantido como estava).
CREATE TABLE IF NOT EXISTS empresa_integracoes (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  provedor      TEXT NOT NULL,
  dados         JSONB NOT NULL DEFAULT '{}',
  status        TEXT NOT NULL DEFAULT 'desconectado',
  versao        INTEGER NOT NULL DEFAULT 1,
  origem        TEXT NOT NULL DEFAULT 'app',
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (business_id, provedor)
);
-- Backup/histórico: cada versão anterior de cada integração (inclusive antes de migrações). Só acrescenta linhas.
CREATE TABLE IF NOT EXISTS empresa_integracoes_historico (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  provedor      TEXT NOT NULL,
  versao        INTEGER NOT NULL,
  dados         JSONB NOT NULL DEFAULT '{}',
  status        TEXT NOT NULL DEFAULT '',
  motivo        TEXT NOT NULL DEFAULT '',
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS empresa_integracoes_hist_idx ON empresa_integracoes_historico (business_id, provedor, id);
