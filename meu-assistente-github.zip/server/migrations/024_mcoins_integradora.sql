-- Meu Assistente como empresa emissora e integradora das MCoins. Somente ADITIVA: moedas, saldos, carteiras e históricos atuais não mudam.
-- Cada movimentação passa a guardar a empresa EMISSORA e a empresa VINCULADA (onde a moeda foi usada/aceita).
ALTER TABLE coin_ledger ADD COLUMN issuer_business_id BIGINT;
ALTER TABLE coin_ledger ADD COLUMN linked_business_id BIGINT;
-- histórico existente: a emissora é a empresa da própria moeda; usos e estornos antigos aconteceram nessa mesma empresa
UPDATE coin_ledger SET issuer_business_id = (SELECT business_id FROM coins WHERE coins.id = coin_ledger.coin_id) WHERE issuer_business_id IS NULL;
UPDATE coin_ledger SET linked_business_id = issuer_business_id WHERE linked_business_id IS NULL AND kind IN ('resgate','estorno','adesao');
-- vínculos: uma moeda (ex.: a do Meu Assistente) pode ser aceita por várias empresas ao mesmo tempo, cada uma com as suas regras
CREATE TABLE IF NOT EXISTS coin_links (
  id             BIGSERIAL PRIMARY KEY,
  coin_id        BIGINT NOT NULL,
  business_id    BIGINT NOT NULL,                     -- empresa vinculada (que aceita a moeda)
  status         TEXT NOT NULL DEFAULT 'pendente',    -- pendente | ativo | pausado | recusado | revogado
  discount_value NUMERIC(14,4),                       -- desconto por moeda nesta empresa (vazio = o da moeda)
  max_pct        NUMERIC(6,2) NOT NULL DEFAULT 100,   -- % máximo do valor dos itens que a moeda pode cobrir
  min_purchase   NUMERIC(14,2) NOT NULL DEFAULT 0,    -- compra mínima para usar
  rules          TEXT,                                -- observações da regra de utilização
  paused_by      TEXT,                                -- admin | empresa (quem pausou; só quem pausou retoma)
  accepted_at    TIMESTAMPTZ,
  created_by     BIGINT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_links_pair ON coin_links (coin_id, business_id);
CREATE INDEX IF NOT EXISTS coin_links_business ON coin_links (business_id, status);
CREATE TABLE IF NOT EXISTS coin_link_events (       -- trilha de auditoria dos vínculos
  id          BIGSERIAL PRIMARY KEY,
  link_id     BIGINT NOT NULL,
  coin_id     BIGINT NOT NULL,
  business_id BIGINT NOT NULL,
  action      TEXT NOT NULL,
  actor       TEXT,
  detail      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS coin_link_events_link ON coin_link_events (link_id, id);
