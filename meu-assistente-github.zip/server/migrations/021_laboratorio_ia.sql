-- Laboratório de IA (somente administradores). Somente ADITIVA: não altera nenhuma tabela existente.
-- Regras aprendidas viram itens do Cérebro (brain_answers) só quando o administrador PUBLICA; tudo antes disso fica aqui.
CREATE TABLE IF NOT EXISTS lab_messages (        -- conversa do administrador com o Laboratório (persistente)
  id         BIGSERIAL PRIMARY KEY,
  admin_id   BIGINT NOT NULL,
  role       TEXT NOT NULL,                      -- admin | ia | sistema
  content    TEXT NOT NULL,
  data       TEXT,                               -- JSON: proposta criada, simulação, problemas…
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lab_messages_admin ON lab_messages (admin_id, id);
CREATE TABLE IF NOT EXISTS lab_proposals (       -- uma proposta de regra: rascunho → … → publicada
  id             BIGSERIAL PRIMARY KEY,
  category       TEXT NOT NULL,
  title          TEXT NOT NULL,
  problem        TEXT,                           -- a falha identificada
  correction     TEXT,                           -- o que o administrador disse (original)
  rule_text      TEXT NOT NULL,                  -- a regra estruturada (rascunho atual)
  rule_json      TEXT,                           -- quando / então / restrições / regra executável
  nature         TEXT NOT NULL DEFAULT 'diretriz',
  scope          TEXT NOT NULL DEFAULT 'chat',
  priority       INTEGER NOT NULL DEFAULT 80,
  state          TEXT NOT NULL DEFAULT 'rascunho', -- rascunho | em_analise | em_testes | aguardando_aprovacao | aprovada | publicada | rejeitada | desativada
  brain_item_id  BIGINT,                         -- item do Cérebro criado/atualizado (produção)
  published_text TEXT,                           -- texto que está valendo em produção
  version        INTEGER NOT NULL DEFAULT 1,
  risks          TEXT,
  "similar"      TEXT,                           -- entre aspas: SIMILAR é palavra reservada no PostgreSQL
  conflicts      TEXT,
  tests          TEXT,
  created_by     BIGINT,
  approved_by    TEXT,
  approved_at    TIMESTAMPTZ,
  published_at   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lab_proposals_state ON lab_proposals (state, id);
CREATE TABLE IF NOT EXISTS lab_versions (        -- cada texto publicado (permite ver a versão anterior e reverter)
  id          BIGSERIAL PRIMARY KEY,
  proposal_id BIGINT NOT NULL,
  version     INTEGER NOT NULL,
  rule_text   TEXT NOT NULL,
  brain_version INTEGER,
  actor       TEXT,
  note        TEXT,
  tests       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lab_versions_p ON lab_versions (proposal_id, version);
CREATE TABLE IF NOT EXISTS lab_events (          -- auditoria: correção, regra criada, testes, aprovação, publicação, reversão…
  id          BIGSERIAL PRIMARY KEY,
  proposal_id BIGINT,
  kind        TEXT NOT NULL,
  actor       TEXT NOT NULL,
  detail      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS lab_events_p ON lab_events (proposal_id, id);
