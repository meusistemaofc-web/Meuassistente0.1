-- Ofertas, variações de produtos (cor, tamanho, modelo…) com preço, oferta, imagens, estoque e disponibilidade próprios.
-- Somente ADITIVA: produtos antigos continuam iguais (sem variações e sem controle de estoque = como antes).
-- Reversão manual: DROP TABLE product_variants; ALTER TABLE products DROP COLUMN stock;
--   DELETE FROM schema_migrations WHERE version = '047_produtos_variacoes.sql';
-- A oferta do produto simples fica em products.data.oferta = {ativo, preco}.
ALTER TABLE products ADD COLUMN IF NOT EXISTS stock INTEGER;   -- produto sem variações: NULL = não controla estoque
CREATE TABLE IF NOT EXISTS product_variants (
  id          BIGSERIAL PRIMARY KEY,
  product_id  BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL DEFAULT 0,
  data        JSONB NOT NULL,      -- {nome, cor, tamanho, modelo, fotos[], thumb, preco, oferta:{ativo,preco}, disponivel}
  stock       INTEGER,             -- NULL = não controla estoque; o débito é atômico (UPDATE … WHERE stock >= qtd)
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS product_variants_product ON product_variants (product_id, position);
CREATE INDEX IF NOT EXISTS product_variants_business ON product_variants (business_id);
