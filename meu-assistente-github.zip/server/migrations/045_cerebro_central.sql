-- Cérebro Central: biblioteca permanente de conhecimentos, fontes, pesquisa externa, aprendizagem contínua,
-- provedores de busca/embeddings e registro de consultas. Somente ADITIVA: nenhuma tabela existente é alterada.
-- Reaproveita o que já existe: configurações gerais em app_config (chave "cerebro_central", no lugar de uma tabela
-- brain_settings separada), provedores de IA do chat em app_config "ai_providers" (Ollama, Gemini, OpenAI…),
-- auditoria em audit_log e notificações em notifications.
-- Colunas com JSON são TEXT (funcionam igual no PostgreSQL e no SQLite dos testes).
-- Reversão (manual, se necessário — apaga só o que esta migração criou):
--   DROP TABLE knowledge_document_sources; DROP TABLE knowledge_embeddings; DROP TABLE knowledge_chunks;
--   DROP TABLE knowledge_reviews; DROP TABLE learning_history; DROP TABLE learning_jobs; DROP TABLE knowledge_documents;
--   DROP TABLE knowledge_sources; DROP TABLE knowledge_categories; DROP TABLE brain_provider_configs;
--   DROP TABLE brain_query_logs; DROP TABLE brain_web_cache; DELETE FROM schema_migrations WHERE version = '045_cerebro_central.sql';
CREATE TABLE IF NOT EXISTS knowledge_categories (
  id          BIGSERIAL PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  parent_id   BIGINT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO knowledge_categories (slug, name) VALUES
  ('inteligencia-artificial', 'Inteligência artificial'),
  ('tecnologia-programacao', 'Tecnologia e programação'),
  ('marketing-publicidade', 'Marketing e publicidade'),
  ('atendimento-vendas', 'Atendimento e vendas'),
  ('administracao-negocios', 'Administração e negócios'),
  ('financas-economia', 'Finanças e economia'),
  ('educacao-ciencia', 'Educação e ciência'),
  ('saude-bem-estar', 'Saúde e bem-estar'),
  ('direito-legislacao', 'Direito e legislação'),
  ('empreendedorismo', 'Empreendedorismo'),
  ('produtividade', 'Produtividade'),
  ('comunicacao', 'Comunicação'),
  ('recursos-humanos', 'Recursos humanos'),
  ('geral', 'Geral');

CREATE TABLE IF NOT EXISTS knowledge_documents (
  id            BIGSERIAL PRIMARY KEY,
  title         TEXT NOT NULL,
  content       TEXT NOT NULL,
  category_id   BIGINT,
  subcategory   TEXT,
  keywords      TEXT,                               -- separadas por vírgula
  status        TEXT NOT NULL DEFAULT 'pendente',   -- pendente | aprovado | rejeitado | arquivado
  confidence    INTEGER NOT NULL DEFAULT 50,        -- 0 a 100 (nível de confiabilidade)
  version       INTEGER NOT NULL DEFAULT 1,
  origin        TEXT NOT NULL DEFAULT 'manual',     -- manual | pesquisa | aprendizagem | importacao
  topic         TEXT,                               -- assunto que originou (aprendizagem/pesquisa)
  content_hash  TEXT NOT NULL,                      -- proteção contra duplicação exata
  flags         TEXT,                               -- JSON: contradições, desatualizado, duplicado de…
  review_after  TIMESTAMPTZ,                        -- a partir desta data o conhecimento é considerado "a revisar"
  created_by    TEXT,
  approved_by   TEXT,
  approved_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS knowledge_documents_status ON knowledge_documents (status, updated_at);
CREATE INDEX IF NOT EXISTS knowledge_documents_hash ON knowledge_documents (content_hash);
CREATE INDEX IF NOT EXISTS knowledge_documents_cat ON knowledge_documents (category_id);

CREATE TABLE IF NOT EXISTS knowledge_chunks (
  id           BIGSERIAL PRIMARY KEY,
  document_id  BIGINT NOT NULL,
  idx          INTEGER NOT NULL,
  text         TEXT NOT NULL,
  terms        TEXT NOT NULL DEFAULT ''             -- radicais (busca lexical)
);
CREATE INDEX IF NOT EXISTS knowledge_chunks_doc ON knowledge_chunks (document_id, idx);

-- vetor guardado como JSON (portável). Com pgvector disponível, uma coluna vector pode ser acrescentada depois sem mudar a API.
CREATE TABLE IF NOT EXISTS knowledge_embeddings (
  chunk_id    BIGINT NOT NULL,
  provider    TEXT NOT NULL,
  model       TEXT NOT NULL,
  dim         INTEGER NOT NULL,
  vector      TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (chunk_id, provider, model)
);

CREATE TABLE IF NOT EXISTS knowledge_sources (
  id           BIGSERIAL PRIMARY KEY,
  url          TEXT NOT NULL UNIQUE,
  domain       TEXT NOT NULL,
  title        TEXT,
  kind         TEXT NOT NULL DEFAULT 'web',         -- web | manual | api
  trust        TEXT NOT NULL DEFAULT 'normal',      -- confiavel | normal | bloqueada
  http_status  INTEGER,
  content_hash TEXT,
  excerpt      TEXT,
  fetched_at   TIMESTAMPTZ,
  note         TEXT,
  created_by   TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS knowledge_sources_domain ON knowledge_sources (domain);
CREATE TABLE IF NOT EXISTS knowledge_document_sources (
  document_id BIGINT NOT NULL,
  source_id   BIGINT NOT NULL,
  PRIMARY KEY (document_id, source_id)
);

CREATE TABLE IF NOT EXISTS knowledge_reviews (
  id           BIGSERIAL PRIMARY KEY,
  document_id  BIGINT NOT NULL,
  action       TEXT NOT NULL,                       -- criado | editado | aprovado | rejeitado | arquivado | restaurado | fonte_adicionada | importado
  version      INTEGER NOT NULL,
  snapshot     TEXT,                                -- JSON da versão anterior (histórico de versões)
  note         TEXT,
  actor        TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS knowledge_reviews_doc ON knowledge_reviews (document_id, id);

CREATE TABLE IF NOT EXISTS learning_jobs (
  id             BIGSERIAL PRIMARY KEY,
  topic          TEXT NOT NULL,
  category_id    BIGINT,
  mode           TEXT NOT NULL DEFAULT 'manual',    -- manual | programado
  interval_hours INTEGER NOT NULL DEFAULT 168,
  auto_approve   BOOLEAN NOT NULL DEFAULT FALSE,
  active         BOOLEAN NOT NULL DEFAULT TRUE,
  status         TEXT NOT NULL DEFAULT 'aguardando', -- aguardando | executando | concluido | erro
  next_run_at    TIMESTAMPTZ,
  last_run_at    TIMESTAMPTZ,
  last_result    TEXT,
  created_by     TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS learning_history (
  id            BIGSERIAL PRIMARY KEY,
  job_id        BIGINT,
  topic         TEXT NOT NULL,
  status        TEXT NOT NULL,                      -- executando | concluido | erro
  steps         TEXT,                               -- JSON: etapas do processamento (busca, páginas, extração, duplicações…)
  found         INTEGER NOT NULL DEFAULT 0,
  created_docs  INTEGER NOT NULL DEFAULT 0,
  duplicates    INTEGER NOT NULL DEFAULT 0,
  errors        TEXT,
  actor         TEXT,
  started_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finished_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS learning_history_started ON learning_history (started_at);

CREATE TABLE IF NOT EXISTS brain_provider_configs (
  id            BIGSERIAL PRIMARY KEY,
  kind          TEXT NOT NULL,                      -- busca | embeddings
  provider      TEXT NOT NULL,                      -- searxng | google_cse | wikipedia | local | ollama | gemini
  name          TEXT NOT NULL,
  base_url      TEXT,
  api_key       TEXT,                               -- sempre cifrada (seal); nunca volta para o navegador
  model         TEXT,
  extra         TEXT,                               -- JSON (ex.: cx do Google)
  enabled       BOOLEAN NOT NULL DEFAULT FALSE,
  role          TEXT NOT NULL DEFAULT 'alternativo', -- principal | alternativo
  last_test_at  TIMESTAMPTZ,
  last_test_ok  BOOLEAN,
  last_test_msg TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS brain_provider_configs_uq ON brain_provider_configs (kind, provider);

CREATE TABLE IF NOT EXISTS brain_query_logs (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT,
  channel      TEXT NOT NULL,                       -- laboratorio | api | chat | pesquisa
  query        TEXT NOT NULL,
  mode         TEXT NOT NULL,                       -- biblioteca | biblioteca+internet | internet
  origin       TEXT,                                -- biblioteca | internet | ambos | nenhum
  docs         TEXT,                                -- JSON: ids e notas dos conhecimentos usados
  sources      TEXT,                                -- JSON: urls
  sufficient   BOOLEAN,
  ms           INTEGER,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS brain_query_logs_created ON brain_query_logs (created_at);

CREATE TABLE IF NOT EXISTS brain_web_cache (
  key         TEXT PRIMARY KEY,                     -- hash da busca ou da URL
  kind        TEXT NOT NULL,                        -- busca | pagina
  body        TEXT NOT NULL,
  status      INTEGER,
  fetched_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
