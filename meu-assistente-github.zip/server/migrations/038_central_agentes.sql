-- Fase 10 — Arquitetura multiagente colaborativa (evolução da Fase 4). Tudo aditivo: nenhuma tabela existente é alterada.
-- Uma linha = uma tarefa coordenada pelo orquestrador (os agentes que participaram, as etapas com dependências, os resultados,
-- as decisões e as ações preparadas/executadas). É também a MEMÓRIA COMPARTILHADA entre execuções: os agentes recuperam
-- os achados e decisões anteriores do MESMO usuário (e da mesma empresa), sempre filtrados pelo que cada agente pode ver.
-- Nada de texto da conversa é guardado aqui: só achados estruturados, números agregados e metadados.
CREATE TABLE IF NOT EXISTS agent_tasks (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id  BIGINT,                           -- empresa do usuário envolvida (isolamento por empresa); null = só dados pessoais
  conversation_id TEXT,
  chave        TEXT NOT NULL,                    -- hash (usuário + conversa + pedido normalizado): evita execução duplicada
  nivel        TEXT NOT NULL,                    -- simples | moderada | complexa
  dominios     TEXT NOT NULL DEFAULT '[]',       -- agentes de domínio acionados
  etapas       TEXT NOT NULL DEFAULT '[]',       -- [{id, agente, tipo, depende, status, ms, motivo}]
  achados      TEXT NOT NULL DEFAULT '{}',       -- {agente: [fatos]} (dados do próprio usuário; recuperados só por ele)
  decisoes     TEXT NOT NULL DEFAULT '[]',       -- validação/debate, divergências resolvidas, recomendações
  acoes        TEXT NOT NULL DEFAULT '[]',       -- [{agente, objetivo, autonomia, resultado, execucao}]
  status       TEXT NOT NULL DEFAULT 'executando', -- executando | concluida | parcial | falhou | interrompida | reaproveitada
  chamadas_ia  INTEGER NOT NULL DEFAULT 0,
  ms           INTEGER NOT NULL DEFAULT 0,
  message_id   TEXT,
  created_at   TIMESTAMPTZ NOT NULL,
  finished_at  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS agent_tasks_user ON agent_tasks (user_id, created_at);
CREATE INDEX IF NOT EXISTS agent_tasks_chave ON agent_tasks (chave, created_at);
CREATE INDEX IF NOT EXISTS agent_tasks_status ON agent_tasks (status, created_at);
-- Reversão: DROP TABLE agent_tasks; (a coordenação volta ao comportamento da Fase 4)
