-- Conexão automática (OAuth) do Mercado Pago: pedidos de autorização guardados no servidor.
-- O retorno do Mercado Pago é reconhecido pelo "state" (uso único, 15 min), sem depender do cookie da sessão:
-- no celular a autorização costuma abrir no app do Mercado Pago e voltar em outro navegador, sem a sessão.
-- code_verifier (PKCE) fica criptografado. Só acrescenta; nada existente é alterado.
CREATE TABLE IF NOT EXISTS mp_oauth_estados (
  state        TEXT PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id  BIGINT,
  verifier     TEXT NOT NULL DEFAULT '',
  criado_em    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  usado_em     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS mp_oauth_estados_user ON mp_oauth_estados (user_id);
