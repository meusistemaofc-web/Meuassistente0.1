-- Inteligência avançada (Nível 2) — tudo aditivo; nada existente é alterado ou apagado.
-- Planos por conversa: etapas, prioridade, dependências e situação de cada uma.
CREATE TABLE IF NOT EXISTS assistant_plans (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id TEXT NOT NULL,
  steps           TEXT NOT NULL DEFAULT '[]',   -- [{n,acao,texto,ferramenta,prioridade,depende,status,verificado,detalhe}]
  status          TEXT NOT NULL DEFAULT 'ativo', -- ativo | concluido | abandonado
  created_at      TIMESTAMPTZ NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS assistant_plans_conv ON assistant_plans (user_id, conversation_id, id);

-- Avaliação das respostas pelo usuário (👍/👎). O texto da conversa só é guardado com consentimento explícito (shared).
CREATE TABLE IF NOT EXISTS response_feedback (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id      BIGINT NOT NULL,
  conversation_id TEXT,
  rating          INTEGER NOT NULL,              -- 1 útil | -1 não útil
  reasons         TEXT NOT NULL DEFAULT '[]',    -- incorreta | incompleta | nao_entendeu | muito_longa | muito_curta | tom | nao_executou | outro
  comment         TEXT,
  shared          BOOLEAN NOT NULL DEFAULT FALSE,
  question_excerpt TEXT,                         -- só quando shared = TRUE
  answer_excerpt  TEXT,                          -- só quando shared = TRUE
  snapshot        TEXT NOT NULL DEFAULT '{}',    -- notas/sinalizações/especialistas da avaliação interna (sem texto)
  status          TEXT NOT NULL DEFAULT 'novo',  -- novo | proposto | descartado
  lab_proposal_id BIGINT,
  created_at      TIMESTAMPTZ NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS response_feedback_msg ON response_feedback (user_id, message_id);

-- Preferências de inteligência por usuário: sugestões proativas e estilo aprendido das avaliações dele (reversível).
CREATE TABLE IF NOT EXISTS user_intel_prefs (
  user_id     BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  proactive   BOOLEAN NOT NULL DEFAULT TRUE,
  style       TEXT NOT NULL DEFAULT '{}',        -- {"tamanho":"curto"|"detalhado"}
  updated_at  TIMESTAMPTZ NOT NULL
);

-- Sugestões proativas já feitas (limite de frequência, nunca repetir a mesma).
CREATE TABLE IF NOT EXISTS proactive_log (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,
  ref         TEXT,
  conversation_id TEXT,
  accepted    BOOLEAN,
  created_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS proactive_log_user ON proactive_log (user_id, id);

-- Avaliação contínua: bateria automática de cenários e alertas de regressão.
CREATE TABLE IF NOT EXISTS intel_runs (
  id          BIGSERIAL PRIMARY KEY,
  kind        TEXT NOT NULL,                     -- bateria | monitor
  result      TEXT NOT NULL,
  ok          BOOLEAN NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL
);

-- Avaliações internas passam a registrar os especialistas usados e a nota do usuário.
ALTER TABLE cognition_evals ADD COLUMN specialists TEXT;
ALTER TABLE cognition_evals ADD COLUMN feedback INTEGER;
ALTER TABLE cognition_evals ADD COLUMN level2 TEXT;
-- Reversão: DROP TABLE assistant_plans, response_feedback, user_intel_prefs, proactive_log, intel_runs;
--           (as colunas novas de cognition_evals podem ficar: são opcionais e ignoradas pelo Nível 1)
