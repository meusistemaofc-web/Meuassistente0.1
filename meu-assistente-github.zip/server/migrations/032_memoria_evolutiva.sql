-- Fase 5 — Memória evolutiva. Tudo aditivo: nenhuma memória existente é alterada ou apagada.
-- Origem, versões e ciclo de vida das memórias de longo prazo / preferências.
ALTER TABLE memories ADD COLUMN origin_conversation_id TEXT;   -- conversa em que nasceu (quando veio do chat)
ALTER TABLE memories ADD COLUMN versions TEXT;                 -- [{conteudo, de, ate, origem, motivo}] — versões anteriores, nunca descartadas
ALTER TABLE memories ADD COLUMN last_used_at TIMESTAMPTZ;      -- última vez que entrou numa resposta
ALTER TABLE memories ADD COLUMN status TEXT;                   -- null = atual | 'antiga' (sem uso há muito tempo; continua consultável)
CREATE INDEX IF NOT EXISTS memories_user_active ON memories (user_id, active, id);

-- Memória de experiências: resultados de tarefas, planos, correções e avaliações AUTORIZADAS — sempre individual.
CREATE TABLE IF NOT EXISTS experiences (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind            TEXT NOT NULL,                 -- tarefa | plano | correcao | feedback
  tool            TEXT,                          -- ferramenta envolvida (create_appointment…)
  outcome         TEXT NOT NULL,                 -- sucesso | falha | aguardando | corrigido | aprovado | reprovado
  summary         TEXT NOT NULL,                 -- frase curta (sem senhas/documentos)
  concepts        TEXT NOT NULL DEFAULT '[]',    -- termos/conceitos para recuperação semântica
  conversation_id TEXT,
  created_at      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS experiences_user ON experiences (user_id, id);
-- Reversão: DROP TABLE experiences; (as colunas novas de memories são opcionais e ignoradas pelo código antigo)
