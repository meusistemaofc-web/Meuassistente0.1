-- Permissões de Agendamento (por empresa). Tudo aditivo: nenhuma tabela existente é alterada.
-- A configuração (ligar/desligar, quem pode usar, reserva temporária, antecedência) fica no JSON da empresa (businesses.data.permAgenda),
-- como as demais configurações da loja. Aqui ficam só as pessoas: aprovadores delegados e clientes selecionados.
CREATE TABLE IF NOT EXISTS business_permissions (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        TEXT NOT NULL,                     -- aprovador | cliente_pedidos | cliente_servicos
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS business_permissions_key ON business_permissions (business_id, user_id, role);
CREATE INDEX IF NOT EXISTS business_permissions_user ON business_permissions (user_id, role);
-- Os pedidos continuam na tabela orders. Novos status usados só quando a empresa liga as permissões:
--   aguardando_aprovacao (solicitação de serviço enviada) e sugestao (empresa sugeriu outro horário, aguardando o cliente).
-- Reversão: DROP TABLE business_permissions; e desligar as duas opções (o fluxo antigo volta a valer).
