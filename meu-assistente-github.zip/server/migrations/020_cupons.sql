-- Cupons de desconto por empresa. Somente ADITIVA.
-- O uso é contado de forma atômica (used_count nunca passa de total_qty) e cada resgate fica preso a UM pedido (UNIQUE coupon_id+order_id).
CREATE TABLE IF NOT EXISTS coupons (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL,                  -- empresa responsável: o cupom só vale nas compras dela
  name          TEXT NOT NULL,                    -- nome da campanha
  code          TEXT NOT NULL,                    -- código digitado pelo cliente (sempre maiúsculo, único por empresa)
  description   TEXT,
  purpose       TEXT,                             -- finalidade (atrair, recuperar inativos, fidelizar…)
  kind          TEXT NOT NULL DEFAULT 'percentual', -- percentual | fixo
  value         NUMERIC(14,2) NOT NULL DEFAULT 0,
  max_discount  NUMERIC(14,2) NOT NULL DEFAULT 0, -- teto do desconto em reais (0 = sem teto)
  min_purchase  NUMERIC(14,2) NOT NULL DEFAULT 0,
  starts_at     TIMESTAMPTZ,
  ends_at       TIMESTAMPTZ,
  total_qty     BIGINT NOT NULL DEFAULT 0 CHECK (total_qty >= 0),   -- 0 = ilimitado
  used_count    BIGINT NOT NULL DEFAULT 0 CHECK (used_count >= 0),
  per_user_limit BIGINT NOT NULL DEFAULT 1,       -- 0 = sem limite por cliente
  product_ids   TEXT NOT NULL DEFAULT '[]',       -- produtos participantes (vazio = todos)
  audience      TEXT NOT NULL DEFAULT 'todos',    -- todos | especificos (cupom exclusivo)
  visibility    TEXT NOT NULL DEFAULT 'publico',  -- publico (vitrine) | oculto (só por código ou envio)
  combine_coins BOOLEAN NOT NULL DEFAULT TRUE,    -- pode ser somado ao desconto de moedas de bônus
  status        TEXT NOT NULL DEFAULT 'ativo',    -- ativo | pausado (expirado/esgotado são calculados)
  created_by    BIGINT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (business_id, code)
);
CREATE INDEX IF NOT EXISTS coupons_business ON coupons (business_id, status);
CREATE TABLE IF NOT EXISTS coupon_targets (      -- clientes autorizados em cupons exclusivos
  coupon_id BIGINT NOT NULL,
  user_id   BIGINT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (coupon_id, user_id)
);
CREATE TABLE IF NOT EXISTS coupon_grants (       -- distribuição: quem recebeu, por qual canal, se abriu e se usou
  id         BIGSERIAL PRIMARY KEY,
  coupon_id  BIGINT NOT NULL,
  user_id    BIGINT NOT NULL,
  channel    TEXT NOT NULL,                      -- push | area | crm | marketing | vitrine | manual
  status     TEXT NOT NULL DEFAULT 'enviado',    -- enviado | entregue | falhou | disponivel
  sent_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  opened_at  TIMESTAMPTZ,
  redeemed_at TIMESTAMPTZ,
  UNIQUE (coupon_id, user_id, channel)
);
CREATE INDEX IF NOT EXISTS coupon_grants_user ON coupon_grants (user_id);
CREATE TABLE IF NOT EXISTS coupon_redemptions (  -- resgates: um por pedido
  id          BIGSERIAL PRIMARY KEY,
  coupon_id   BIGINT NOT NULL,
  business_id BIGINT NOT NULL,
  user_id     BIGINT NOT NULL,
  order_id    BIGINT NOT NULL,
  discount    NUMERIC(14,2) NOT NULL DEFAULT 0,
  order_total NUMERIC(14,2) NOT NULL DEFAULT 0,
  coin_discount NUMERIC(14,2) NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'reservado', -- reservado (aguardando Pix) | usado | estornado
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (coupon_id, order_id)
);
CREATE INDEX IF NOT EXISTS coupon_red_user ON coupon_redemptions (coupon_id, user_id);
CREATE TABLE IF NOT EXISTS coupon_changes (      -- histórico de alterações (auditoria)
  id         BIGSERIAL PRIMARY KEY,
  coupon_id  BIGINT NOT NULL,
  actor      TEXT NOT NULL,
  kind       TEXT NOT NULL,
  detail     TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS coupon_changes_coupon ON coupon_changes (coupon_id, id);
