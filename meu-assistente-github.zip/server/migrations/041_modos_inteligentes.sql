-- Modos Inteligentes do chat (ex.: Consultor de Marketing). Só acrescenta tabelas; nada existente é alterado.
-- Modo ativo de cada conversa e a etapa do fluxo (o chat comum continua igual nas conversas sem modo).
CREATE TABLE IF NOT EXISTS conversa_modos (
  conversation_id TEXT PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  modo            TEXT NOT NULL,
  estado          JSONB NOT NULL DEFAULT '{}',
  atualizado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS conversa_modos_user ON conversa_modos (user_id);
-- Memória do modo por empresa (briefing, objetivos e entregas): permite retomar sem repetir perguntas.
CREATE TABLE IF NOT EXISTS modo_memoria (
  user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id   BIGINT NOT NULL,
  modo          TEXT NOT NULL,
  dados         JSONB NOT NULL DEFAULT '{}',
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, business_id, modo)
);
-- Propostas criadas pelo modo (ex.: campanha). Só viram rascunho na Central de Marketing com a ação do responsável.
CREATE TABLE IF NOT EXISTS modo_propostas (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id     BIGINT NOT NULL,
  conversation_id TEXT,
  modo            TEXT NOT NULL,
  tipo            TEXT NOT NULL,
  dados           JSONB NOT NULL DEFAULT '{}',
  status          TEXT NOT NULL DEFAULT 'proposta',
  campaign_id     BIGINT,
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS modo_propostas_user ON modo_propostas (user_id, id);
