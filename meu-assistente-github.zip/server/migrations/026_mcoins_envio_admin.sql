-- Distribuição administrativa de MCoins (Enviar MCoins). Somente ADITIVA: moedas, carteiras (coin_balances) e livro-razão (coin_ledger) continuam
-- sendo as MESMAS tabelas; cada crédito do lote vira uma linha normal do livro-razão. Aqui só entra o cabeçalho da operação e seus destinatários.
-- Reversão (manual, se necessário; não apaga saldos nem o livro-razão):
--   DROP TABLE coin_distribution_items; DROP TABLE coin_distributions;
--   (a coluna coin_ledger.seen_at pode ficar: é opcional e inofensiva)
CREATE TABLE IF NOT EXISTS coin_distributions (
  id          BIGSERIAL PRIMARY KEY,
  op_code     TEXT NOT NULL,                       -- identificador público da operação (MCD-…)
  coin_id     BIGINT NOT NULL,
  admin_id    BIGINT NOT NULL,
  admin_name  TEXT,
  idem        TEXT NOT NULL,                       -- chave de idempotência: repetir a solicitação não credita de novo
  qty_each    BIGINT NOT NULL CHECK (qty_each > 0),
  recipients  INTEGER NOT NULL CHECK (recipients > 0),
  total       BIGINT NOT NULL CHECK (total > 0),
  reason      TEXT NOT NULL,
  selection   TEXT NOT NULL DEFAULT 'manual',      -- manual | filtro
  filter_text TEXT,
  status      TEXT NOT NULL DEFAULT 'concluida',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_distributions_idem ON coin_distributions (coin_id, idem);
CREATE UNIQUE INDEX IF NOT EXISTS coin_distributions_code ON coin_distributions (op_code);
CREATE TABLE IF NOT EXISTS coin_distribution_items (
  distribution_id BIGINT NOT NULL,
  user_id         BIGINT NOT NULL,
  quantity        BIGINT NOT NULL,
  ledger_id       BIGINT,
  PRIMARY KEY (distribution_id, user_id)
);
CREATE INDEX IF NOT EXISTS coin_distribution_items_user ON coin_distribution_items (user_id);
-- "visto": a carteira do usuário comemora créditos novos uma única vez. Histórico existente já nasce visto (nada é reanimado).
ALTER TABLE coin_ledger ADD COLUMN seen_at TIMESTAMPTZ;
UPDATE coin_ledger SET seen_at = created_at WHERE seen_at IS NULL;
