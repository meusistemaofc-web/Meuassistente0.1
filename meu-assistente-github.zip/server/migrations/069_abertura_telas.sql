-- Abertura do app: apresentação em stories antes do login (4 telas). Somente ADITIVA.
--  • abertura_telas: ordem, ativa, título, destaque (trecho em ciano), subtítulo, duração própria (0 = a geral) e imagem.
--    imagem = enviada pelo administrador (data URL, servida por /api/v2/abertura/telas/:id/imagem);
--    vazia = imagem padrão do sistema (imagem_padrao, arquivo em frontend/public/abertura/).
--  • Configuração geral (ligada, duração em segundos) em app_config "abertura".
-- Reversão manual: DROP TABLE abertura_telas; DELETE FROM schema_migrations WHERE version = '069_abertura_telas.sql';
CREATE TABLE IF NOT EXISTS abertura_telas (
  id             BIGSERIAL PRIMARY KEY,
  chave          TEXT NOT NULL DEFAULT '',
  ordem          INTEGER NOT NULL DEFAULT 0,
  ativo          BOOLEAN NOT NULL DEFAULT TRUE,
  titulo         TEXT NOT NULL DEFAULT '',
  destaque       TEXT NOT NULL DEFAULT '',
  subtitulo      TEXT NOT NULL DEFAULT '',
  duracao        INTEGER NOT NULL DEFAULT 0,
  imagem         TEXT NOT NULL DEFAULT '',
  imagem_padrao  TEXT NOT NULL DEFAULT '',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO abertura_telas (chave, ordem, ativo, titulo, destaque, subtitulo, imagem_padrao)
  SELECT 'assistente', 1, TRUE, 'Seu assistente inteligente para', 'o dia a dia', 'Organize sua rotina, gerencie suas tarefas e tenha mais produtividade.', '/abertura/tela-1.webp'
  WHERE NOT EXISTS (SELECT 1 FROM abertura_telas WHERE chave = 'assistente');
INSERT INTO abertura_telas (chave, ordem, ativo, titulo, destaque, subtitulo, imagem_padrao)
  SELECT 'agenda', 2, TRUE, 'Agende, lembre e não perca', 'compromissos', 'Crie compromissos, receba lembretes e mantenha sua rotina organizada.', '/abertura/tela-2.webp'
  WHERE NOT EXISTS (SELECT 1 FROM abertura_telas WHERE chave = 'agenda');
INSERT INTO abertura_telas (chave, ordem, ativo, titulo, destaque, subtitulo, imagem_padrao)
  SELECT 'financas', 3, TRUE, 'Tenha o controle', 'das suas finanças', 'Registre gastos, acompanhe entradas e saídas e mantenha suas contas em dia.', '/abertura/tela-3.webp'
  WHERE NOT EXISTS (SELECT 1 FROM abertura_telas WHERE chave = 'financas');
INSERT INTO abertura_telas (chave, ordem, ativo, titulo, destaque, subtitulo, imagem_padrao)
  SELECT 'negocios', 4, TRUE, 'Mais que um app, um aliado para', 'seus negócios', 'Gerencie atendimentos, vendas, clientes e destaque sua empresa no digital.', '/abertura/tela-4.webp'
  WHERE NOT EXISTS (SELECT 1 FROM abertura_telas WHERE chave = 'negocios');
