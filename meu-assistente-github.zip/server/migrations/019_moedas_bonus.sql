-- Moedas digitais de bônus por empresa (crédito promocional fechado: sem negociação, saque ou transferência).
-- Somente ADITIVA. Saldos nunca ficam negativos (CHECK) e cada movimentação gera uma linha no livro-razão (coin_ledger).
CREATE TABLE IF NOT EXISTS coins (
  id             BIGSERIAL PRIMARY KEY,
  business_id    BIGINT NOT NULL UNIQUE,            -- uma moeda por empresa; saldos nunca se misturam entre empresas
  model          TEXT NOT NULL DEFAULT 'dourada',   -- modelo visual (pode ser trocado sem afetar saldos ou histórico)
  name           TEXT NOT NULL,
  symbol         TEXT NOT NULL,
  logo           TEXT,
  color1         TEXT,
  color2         TEXT,
  description    TEXT,
  purpose        TEXT,
  total_supply   BIGINT NOT NULL DEFAULT 0 CHECK (total_supply >= 0),
  distributed    BIGINT NOT NULL DEFAULT 0 CHECK (distributed >= 0),
  redeemed       BIGINT NOT NULL DEFAULT 0 CHECK (redeemed >= 0),
  ref_value      NUMERIC(14,4) NOT NULL DEFAULT 0,  -- valor de referência de cada moeda em reais (informativo)
  discount_value NUMERIC(14,4) NOT NULL DEFAULT 0,  -- desconto em reais que cada moeda dá na compra (definido pelo administrador)
  status         TEXT NOT NULL DEFAULT 'rascunho',  -- rascunho | ativa | suspensa
  published_at   TIMESTAMPTZ,
  created_by     BIGINT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS coin_balances (
  coin_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (coin_id, user_id)
);
CREATE TABLE IF NOT EXISTS coin_ledger (
  id            BIGSERIAL PRIMARY KEY,
  coin_id       BIGINT NOT NULL,
  user_id       BIGINT NOT NULL,
  kind          TEXT NOT NULL,                       -- distribuicao | adesao | resgate | estorno | ajuste
  delta         BIGINT NOT NULL,                     -- + entra, - sai
  balance_after BIGINT NOT NULL,
  order_id      BIGINT,
  idem          TEXT,                                -- chave de idempotência: a mesma operação nunca vale duas vezes
  actor         TEXT,
  note          TEXT,
  discount      NUMERIC(14,2),                       -- desconto em reais concedido (resgates)
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_ledger_idem ON coin_ledger (coin_id, idem);
CREATE INDEX IF NOT EXISTS coin_ledger_user ON coin_ledger (user_id, coin_id);
CREATE INDEX IF NOT EXISTS coin_ledger_coin ON coin_ledger (coin_id, id);
-- toda alteração de valor/quantidade/status fica registrada
CREATE TABLE IF NOT EXISTS coin_changes (
  id         BIGSERIAL PRIMARY KEY,
  coin_id    BIGINT NOT NULL,
  field      TEXT NOT NULL,
  old_value  TEXT,
  new_value  TEXT,
  actor      TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
