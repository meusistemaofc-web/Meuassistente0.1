-- Vitrine inteligente de links (comandos de barra "/" nos chats). Somente ADITIVA e independente dos anúncios.
CREATE TABLE IF NOT EXISTS showcase_links (
  id          BIGSERIAL PRIMARY KEY,
  keyword     TEXT NOT NULL,                       -- sempre "/palavra" em minúsculas, sem acento (único)
  title       TEXT NOT NULL,
  description TEXT NOT NULL,
  url         TEXT NOT NULL,                       -- somente http/https
  image       TEXT,                                -- data:image/... (reduzida no painel) ou URL https
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  position    INTEGER NOT NULL DEFAULT 0,          -- ordem de exibição (menor primeiro)
  channels    TEXT NOT NULL DEFAULT '["chat","agentes"]', -- onde aparece: chat (assistente) e/ou agentes (atendimento das empresas)
  audience    TEXT NOT NULL DEFAULT 'todos',       -- todos | empresas (donos de empresa) | admins
  businesses  TEXT NOT NULL DEFAULT '[]',          -- vazio = todas; senão só estas empresas (agente da empresa ou dono dela)
  views       BIGINT NOT NULL DEFAULT 0,           -- cards abertos
  clicks      BIGINT NOT NULL DEFAULT 0,           -- cliques no link externo
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_showcase_keyword ON showcase_links (keyword);
CREATE INDEX IF NOT EXISTS idx_showcase_order ON showcase_links (active, position, id);
