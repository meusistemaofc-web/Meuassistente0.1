-- Modalidade EXCLUSIVA do catálogo por empresa: 'products' (loja: produtos, estoque, carrinho, pedidos) OU 'services'
-- (prestadora: serviços, horários, agendamentos). Nunca as duas. Campo único, validado também pelo banco (CHECK).
-- O preenchimento das empresas existentes (coerente com o que cada uma já tem cadastrado, sem apagar nada) é feito logo
-- depois das migrações por lib/modalidade.ts (backfillModalidades), porque depende de ler os itens e pedidos de cada uma.
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS modalidade TEXT CHECK (modalidade IS NULL OR modalidade IN ('products', 'services'));
CREATE INDEX IF NOT EXISTS businesses_modalidade ON businesses (modalidade);
-- IF NOT EXISTS: se a coluna já existir (aplicada à mão, por exemplo), a migração não falha nem altera nada.
-- Reversão: ALTER TABLE businesses DROP COLUMN modalidade; (o app volta a ler data.tipo, que é mantido igual)
