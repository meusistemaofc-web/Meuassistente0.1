-- Orquestração central: o rastreamento de cada resposta (brain_chat_traces, criado na 050) passa a guardar também
-- o tempo de cada etapa do pipeline, o tipo do pedido, o idioma, as ferramentas chamadas (e se deram certo), as ações
-- conferidas no sistema, os especialistas e as sinalizações da autoverificação. Somente ADITIVA (JSON numa coluna).
-- Nada de texto da conversa é acrescentado aqui.
-- Reversão manual: ALTER TABLE brain_chat_traces DROP COLUMN detail; DELETE FROM schema_migrations WHERE version = '055_orquestracao_rastro.sql';
ALTER TABLE brain_chat_traces ADD COLUMN IF NOT EXISTS detail TEXT;
CREATE INDEX IF NOT EXISTS brain_chat_traces_msg ON brain_chat_traces (message_id);
CREATE INDEX IF NOT EXISTS cognition_evals_msg ON cognition_evals (message_id);
