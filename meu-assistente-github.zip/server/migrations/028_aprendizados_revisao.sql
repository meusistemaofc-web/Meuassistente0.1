-- Revisão administrativa dos aprendizados (aditiva). Cada aprendizado nasce 'pendente' e vale de imediato para o dono;
-- o administrador pode aprovar, rejeitar (deixa de ser aplicado) ou editar a regra.
ALTER TABLE learnings ADD COLUMN review_status TEXT NOT NULL DEFAULT 'pendente';  -- pendente | aprovado | rejeitado | editado
ALTER TABLE learnings ADD COLUMN reviewed_by BIGINT;
ALTER TABLE learnings ADD COLUMN reviewed_at TIMESTAMPTZ;
ALTER TABLE learnings ADD COLUMN review_note TEXT;
ALTER TABLE learnings ADD COLUMN original_rule TEXT;  -- regra antes da edição do administrador
CREATE INDEX IF NOT EXISTS learnings_review_idx ON learnings (review_status, id);
-- Reversão: DROP INDEX learnings_review_idx; e remover as colunas acima.
