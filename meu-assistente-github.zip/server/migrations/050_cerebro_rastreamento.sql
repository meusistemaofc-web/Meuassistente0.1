-- Cérebro Central integrado ao chat: rastreamento REAL de cada resposta (consulta, conhecimentos recuperados, pesquisa
-- externa, aprendizado, provedor, falhas, tempos e se a resposta de fato USOU o conhecimento). Somente ADITIVA.
-- Privacidade: "question" só guarda perguntas gerais (sem dados pessoais); as demais ficam como "texto não guardado".
-- Reversão manual: DROP TABLE brain_chat_traces; DELETE FROM schema_migrations WHERE version = '050_cerebro_rastreamento.sql';
CREATE TABLE IF NOT EXISTS brain_chat_traces (
  id               BIGSERIAL PRIMARY KEY,
  user_id          BIGINT,
  conversation_id  TEXT,
  message_id       BIGINT,
  channel          TEXT NOT NULL,                  -- chat | agente | laboratorio
  question         TEXT NOT NULL,
  intent           TEXT,                           -- conhecimento | pessoal | acao | conversa
  subject          TEXT,
  consulted        BOOLEAN NOT NULL DEFAULT FALSE,
  retrieved        INTEGER NOT NULL DEFAULT 0,
  docs             TEXT,                           -- JSON: id, título, relevância, origem, revisado, data, fontes
  sufficient       BOOLEAN,
  missing          TEXT,                           -- JSON: termos da pergunta que a biblioteca não cobre
  web_needed       BOOLEAN NOT NULL DEFAULT FALSE,
  web_done         BOOLEAN NOT NULL DEFAULT FALSE,
  web_sources      TEXT,                           -- JSON: urls lidas
  learned_doc      BIGINT,                         -- conhecimento criado/confirmado pela pesquisa
  result           TEXT,
  sent_to_ai       BOOLEAN NOT NULL DEFAULT FALSE,
  provider         TEXT,
  failures         TEXT,                           -- JSON
  via              TEXT,
  used_knowledge   BOOLEAN NOT NULL DEFAULT FALSE, -- verificado no texto da resposta (não basta chamar a IA)
  used_ids         TEXT,                           -- JSON: ids dos conhecimentos usados
  synthesized      BOOLEAN NOT NULL DEFAULT FALSE, -- a síntese do servidor resumiu uma resposta que despejava o conhecimento
  ms_retrieval     INTEGER,
  ms_total         INTEGER,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS brain_chat_traces_created ON brain_chat_traces (created_at);
CREATE INDEX IF NOT EXISTS brain_chat_traces_user ON brain_chat_traces (user_id);
