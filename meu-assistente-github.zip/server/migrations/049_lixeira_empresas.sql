-- Lixeira de empresas: "Excluir empresa" move para a lixeira (status 'lixeira'), restaurável por 30 dias; depois a exclusão
-- é definitiva e automática. Somente ADITIVA. Reversão manual: ALTER TABLE businesses DROP COLUMN deleted_at;
--   DELETE FROM schema_migrations WHERE version = '049_lixeira_empresas.sql';
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS businesses_lixeira ON businesses (status, deleted_at);
