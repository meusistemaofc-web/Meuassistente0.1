-- Central de controle, comercialização e identificação das MCoins. Somente ADITIVA: moedas, carteiras (coin_balances) e livro-razão
-- (coin_ledger) continuam sendo as mesmas tabelas; compras, vendas e transferências geram linhas normais no livro-razão.
-- Tudo novo nasce DESLIGADO (as chaves globais ficam na configuração "coins_central", ausente = desligado).
-- Reversão manual (não apaga saldos nem o livro-razão):
--   DROP TABLE coin_transfers; DROP TABLE coin_orders; DROP TABLE coin_permissions; DROP TABLE coin_group_members; DROP TABLE coin_groups;
--   DROP TABLE coin_policies; DROP TABLE coin_codes; (a coluna coins.code pode ficar: é opcional)
ALTER TABLE coins ADD COLUMN code TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS coins_code_uq ON coins (code);
-- registro PERMANENTE de códigos: nunca é apagado, então um código nunca é reutilizado (mesmo de moeda desativada)
CREATE TABLE IF NOT EXISTS coin_codes (
  code        TEXT PRIMARY KEY,
  seq         BIGINT NOT NULL,
  coin_id     BIGINT NOT NULL,
  business_id BIGINT NOT NULL,
  issuer_kind TEXT NOT NULL DEFAULT 'EM',            -- MA = Meu Assistente (institucional) | EM = empresa
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_codes_seq ON coin_codes (seq);
CREATE UNIQUE INDEX IF NOT EXISTS coin_codes_coin ON coin_codes (coin_id);
-- política por moeda: só RESTRINGE (NULL = herda a chave global; FALSE = bloqueia nesta moeda)
CREATE TABLE IF NOT EXISTS coin_policies (
  coin_id BIGINT PRIMARY KEY, compra BOOLEAN, venda BOOLEAN, transferencia BOOLEAN, compartilhamento BOOLEAN,
  updated_by BIGINT, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS coin_groups (
  id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, description TEXT, created_by BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_groups_name ON coin_groups (name);
CREATE TABLE IF NOT EXISTS coin_group_members (group_id BIGINT NOT NULL, user_id BIGINT NOT NULL, added_by BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY (group_id, user_id));
-- permissões por usuário, empresa (dono) ou grupo; coin_id 0 = todas as moedas; cada permissão: TRUE permite, FALSE bloqueia, NULL herda
CREATE TABLE IF NOT EXISTS coin_permissions (
  id BIGSERIAL PRIMARY KEY, scope_type TEXT NOT NULL, scope_id BIGINT NOT NULL, coin_id BIGINT NOT NULL DEFAULT 0,
  comprar BOOLEAN, vender BOOLEAN, receber BOOLEAN, transferir BOOLEAN, compartilhar BOOLEAN,
  note TEXT, updated_by BIGINT, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_permissions_scope ON coin_permissions (scope_type, scope_id, coin_id);
-- compras e vendas (liquidação definida pelo administrador; nada aqui presume dinheiro real)
CREATE TABLE IF NOT EXISTS coin_orders (
  id BIGSERIAL PRIMARY KEY, op_code TEXT NOT NULL, kind TEXT NOT NULL, coin_id BIGINT NOT NULL, coin_code TEXT, user_id BIGINT NOT NULL,
  qty BIGINT NOT NULL CHECK (qty > 0), unit_price NUMERIC(14,4) NOT NULL DEFAULT 0, gross NUMERIC(14,2) NOT NULL DEFAULT 0, fee NUMERIC(14,2) NOT NULL DEFAULT 0, net NUMERIC(14,2) NOT NULL DEFAULT 0,
  settlement TEXT NOT NULL DEFAULT 'manual', status TEXT NOT NULL DEFAULT 'pendente', idem TEXT NOT NULL, note TEXT,
  resolved_by BIGINT, resolved_note TEXT, resolved_at TIMESTAMPTZ, ledger_id BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_orders_code ON coin_orders (op_code);
CREATE UNIQUE INDEX IF NOT EXISTS coin_orders_idem ON coin_orders (user_id, idem);
CREATE INDEX IF NOT EXISTS coin_orders_status ON coin_orders (status, id);
-- transferências entre contas (funcionalidade pronta e DESLIGADA até autorização administrativa)
CREATE TABLE IF NOT EXISTS coin_transfers (
  id BIGSERIAL PRIMARY KEY, tx_code TEXT NOT NULL, coin_id BIGINT NOT NULL, coin_code TEXT, from_user BIGINT NOT NULL, to_user BIGINT NOT NULL,
  qty BIGINT NOT NULL CHECK (qty > 0), fee BIGINT NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'concluida', idem TEXT NOT NULL, note TEXT,
  ledger_out BIGINT, ledger_in BIGINT, confirmed_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS coin_transfers_code ON coin_transfers (tx_code);
CREATE UNIQUE INDEX IF NOT EXISTS coin_transfers_idem ON coin_transfers (from_user, idem);
CREATE INDEX IF NOT EXISTS coin_transfers_users ON coin_transfers (from_user, to_user);
