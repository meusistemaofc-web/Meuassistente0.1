-- Importador inteligente de cardápios/catálogos com IA (aditivo; os produtos continuam na tabela products).
CREATE TABLE IF NOT EXISTS menu_imports (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id       BIGINT NOT NULL REFERENCES users(id),
  status        TEXT NOT NULL DEFAULT 'rascunho',   -- rascunho | processando | revisao | concluido | falhou | cancelado | revertido
  stage         TEXT,                                -- mensagem amigável da etapa atual
  progress      INTEGER NOT NULL DEFAULT 0,          -- 0..100
  file_hash     TEXT,                                -- controle de importação duplicada
  files         TEXT NOT NULL DEFAULT '[]',          -- [{name,mime,size,done,error}]
  items         TEXT NOT NULL DEFAULT '[]',          -- produtos lidos (rascunho para revisão)
  n_identified  INTEGER NOT NULL DEFAULT 0,
  n_created     INTEGER NOT NULL DEFAULT 0,
  n_updated     INTEGER NOT NULL DEFAULT 0,
  n_ignored     INTEGER NOT NULL DEFAULT 0,
  n_review      INTEGER NOT NULL DEFAULT 0,
  error         TEXT,
  attempts      INTEGER NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL,
  updated_at    TIMESTAMPTZ NOT NULL,
  finished_at   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS menu_imports_biz ON menu_imports (business_id, id);
-- Arquivos ficam só até o fim da leitura (retenção mínima): data é apagado ao concluir/cancelar/falhar de vez.
CREATE TABLE IF NOT EXISTS menu_import_files (
  id         BIGSERIAL PRIMARY KEY,
  import_id  BIGINT NOT NULL REFERENCES menu_imports(id) ON DELETE CASCADE,
  idx        INTEGER NOT NULL,
  name       TEXT NOT NULL,
  mime       TEXT NOT NULL,
  size       INTEGER NOT NULL,
  data       TEXT,                                   -- base64; NULL depois de processado
  created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS menu_import_files_imp ON menu_import_files (import_id, idx);
-- Cada produto criado/atualizado por uma importação (origem + dado anterior para reverter).
CREATE TABLE IF NOT EXISTS menu_import_products (
  id         BIGSERIAL PRIMARY KEY,
  import_id  BIGINT NOT NULL REFERENCES menu_imports(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL,
  action     TEXT NOT NULL,                          -- criado | atualizado
  prev_data  TEXT,                                   -- JSON do produto antes (atualizado)
  created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS menu_import_products_imp ON menu_import_products (import_id);
-- Reversão: DROP TABLE menu_import_products, menu_import_files, menu_imports;
