-- Incentivos do carrinho (estratégias de compra da empresa): "Faltam R$ 15,00 para ganhar frete grátis",
-- "Adicione mais 2 itens e ganhe R$ 10,00 de cashback"… A empresa define a meta (valor dos produtos ou quantidade de
-- itens), o benefício (frete grátis, desconto em %, desconto em R$ ou cashback em MCoins da loja), o período, o limite
-- por cliente e se soma com cupom. O pedido grava qual incentivo foi aplicado (orders.data.incentivo).
-- Somente ADITIVA. Reversão manual: DROP TABLE cart_incentives; DELETE FROM schema_migrations WHERE version = '053_incentivos_carrinho.sql';
CREATE TABLE IF NOT EXISTS cart_incentives (
  id              BIGSERIAL PRIMARY KEY,
  business_id     BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  nome            TEXT NOT NULL,
  meta_tipo       TEXT NOT NULL,                    -- valor | itens
  meta            NUMERIC NOT NULL,                 -- R$ dos produtos ou quantidade de itens
  beneficio       TEXT NOT NULL,                    -- frete_gratis | desconto_pct | desconto_valor | cashback
  valor           NUMERIC NOT NULL DEFAULT 0,       -- % ou R$ (frete grátis: 0)
  inicio          TIMESTAMPTZ,
  fim             TIMESTAMPTZ,
  ativo           BOOLEAN NOT NULL DEFAULT TRUE,
  combina_cupom   BOOLEAN NOT NULL DEFAULT FALSE,
  limite_cliente  INTEGER NOT NULL DEFAULT 0,       -- 0 = sem limite
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS cart_incentives_business ON cart_incentives (business_id, ativo);
