-- Cérebro cognitivo: avaliação interna da qualidade de cada resposta (aditivo).
-- Guarda SOMENTE notas, sinalizações e rótulos técnicos — nunca o texto da conversa — para respeitar a privacidade.
CREATE TABLE IF NOT EXISTS cognition_evals (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id TEXT,
  message_id      BIGINT,
  path            TEXT,                         -- ia | cerebro | atalho | financeiro | agenda | regra ...
  intent          TEXT,                         -- comando | pergunta | continuacao | correcao ...
  scores          TEXT NOT NULL,                -- {precisao,coerencia,naturalidade,clareza,contexto,resolucao}
  overall         INTEGER NOT NULL,             -- nota geral 0..100
  flags           TEXT NOT NULL DEFAULT '[]',   -- ["acao_nao_confirmada","comando_sem_acao",...]
  adjustments     TEXT NOT NULL DEFAULT '[]',   -- correções automáticas aplicadas antes de entregar
  corrected       BOOLEAN NOT NULL DEFAULT FALSE, -- o usuário corrigiu esta resposta logo depois
  created_at      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS cognition_evals_user ON cognition_evals (user_id, id);
CREATE INDEX IF NOT EXISTS cognition_evals_conv ON cognition_evals (conversation_id, id);
-- Reversão: DROP TABLE cognition_evals;
