-- Tarefas do chat em segundo plano: cada envio ao chat (chat_jobs) passa a guardar a conversa, o pedido (para tentar de
-- novo), a fila (aguardando → processando), a "posse" de quem está processando (lease, contra execução duplicada e tarefa
-- abandonada), se o usuário saiu da tela (segundo plano → notificação push ao terminar) e se o aviso já foi enviado.
-- Situações: queued (aguardando) | pending (processando) | done (concluída) | error (falhou) | dismissed (falha descartada).
-- Somente ADITIVA. Reversão manual: ALTER TABLE chat_jobs DROP COLUMN … (as colunas abaixo); DROP INDEX chat_jobs_conversa;
--   DELETE FROM schema_migrations WHERE version = '054_tarefas_segundo_plano.sql';
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS conversation_id TEXT;
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS texto TEXT;                                  -- prévia do pedido (o que o usuário escreveu)
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS payload TEXT;                                -- pedido completo (sem arquivos) para tentar de novo
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS tem_arquivos BOOLEAN NOT NULL DEFAULT FALSE;  -- áudio/foto/documento: para tentar de novo, reenviar
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS tentativas INTEGER NOT NULL DEFAULT 0;
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS lease_ate TIMESTAMPTZ;                       -- até quando o processo atual "tem" a tarefa
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS iniciado_em TIMESTAMPTZ;
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS concluido_em TIMESTAMPTZ;
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS segundo_plano BOOLEAN NOT NULL DEFAULT FALSE; -- o usuário saiu da tela: avisar ao terminar
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS notificado BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE chat_jobs ADD COLUMN IF NOT EXISTS resumo TEXT;                                 -- início da resposta (vai na notificação)
CREATE INDEX IF NOT EXISTS chat_jobs_conversa ON chat_jobs (user_id, conversation_id, status);
CREATE INDEX IF NOT EXISTS chat_jobs_status ON chat_jobs (status, lease_ate);
