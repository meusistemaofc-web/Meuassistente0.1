-- Cupons e Vouchers da plataforma com DESTINO: ativação de anúncios, ativação do Agente de Atendimento ou ambos.
-- Somente ADITIVA: cupons existentes continuam valendo só para anúncios (destino = 'anuncio'), como antes.
-- Um cupom "ambos" tem UM limite de utilizações (total e por usuário) compartilhado entre os dois fluxos.
-- Cada resgate registra o alvo (anuncio | agente); a reserva passa a ser única por (empresa, alvo), para a mesma empresa
-- poder ter um cupom reservado no anúncio e outro na ativação do agente ao mesmo tempo.
-- Reversão manual: DROP INDEX ad_voucher_redemptions_uma_reserva_alvo;
--   CREATE UNIQUE INDEX ad_voucher_redemptions_uma_reserva ON ad_voucher_redemptions (business_id) WHERE status = 'reservado';
--   ALTER TABLE ad_vouchers DROP COLUMN destino; ALTER TABLE ad_voucher_redemptions DROP COLUMN alvo;
--   DELETE FROM schema_migrations WHERE version = '052_vouchers_destino.sql';
ALTER TABLE ad_vouchers ADD COLUMN IF NOT EXISTS destino TEXT NOT NULL DEFAULT 'anuncio';            -- anuncio | agente | ambos
ALTER TABLE ad_voucher_redemptions ADD COLUMN IF NOT EXISTS alvo TEXT NOT NULL DEFAULT 'anuncio';     -- anuncio | agente
DROP INDEX IF EXISTS ad_voucher_redemptions_uma_reserva;
CREATE UNIQUE INDEX IF NOT EXISTS ad_voucher_redemptions_uma_reserva_alvo ON ad_voucher_redemptions (business_id, alvo) WHERE status = 'reservado';
CREATE INDEX IF NOT EXISTS ad_voucher_redemptions_alvo ON ad_voucher_redemptions (business_id, alvo, status);
