-- CRÉDITO DA LOJA: crédito interno para compras parceladas, só para empresas autorizadas pelo administrador.
-- Somente ADITIVA: tabelas novas; pedidos, clientes, financeiro e notificações existentes não são alterados.
--  • credito_empresas: autorização do ADM por empresa (autorizada | suspensa | revogada) e as regras da própria empresa (JSON).
--  • credito_clientes: limite individual concedido pela empresa a um cliente do app (ativo | suspenso).
--  • credito_operacoes: uma compra parcelada, ligada ao pedido (pendente → ativa → quitada; ou rejeitada | cancelada).
--    As condições aceitas pelo cliente (simulação completa) ficam gravadas em `condicoes`.
--  • credito_parcelas: entrada (número 0) e parcelas (1..n), com status pendente | paga | vencida | cancelada e histórico.
--  • credito_pagamentos: cada pagamento registrado (parcial ou integral), com chave contra duplicidade e o lançamento no
--    financeiro do dono (fin_item_id), para o mesmo dinheiro nunca entrar duas vezes.
--  • credito_eventos: histórico auditável (concessão, alteração, aprovação, rejeição, suspensão, pagamentos…).
-- Configuração global do ADM em app_config "credito_loja" (desligada por padrão).
-- Reversão manual: DROP TABLE credito_eventos, credito_pagamentos, credito_parcelas, credito_operacoes, credito_clientes,
--   credito_empresas; DELETE FROM app_config WHERE key = 'credito_loja'; DELETE FROM schema_migrations WHERE version = '070_credito_loja.sql';
CREATE TABLE IF NOT EXISTS credito_empresas (
  business_id    BIGINT PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  situacao       TEXT NOT NULL DEFAULT 'autorizada',
  config         TEXT NOT NULL DEFAULT '{}',
  motivo         TEXT NOT NULL DEFAULT '',
  autorizado_por BIGINT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS credito_clientes (
  id           BIGSERIAL PRIMARY KEY,
  business_id  BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  limite       NUMERIC(12,2) NOT NULL DEFAULT 0,
  situacao     TEXT NOT NULL DEFAULT 'ativo',
  observacao   TEXT NOT NULL DEFAULT '',
  created_by   BIGINT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS credito_clientes_uni ON credito_clientes (business_id, user_id);
CREATE INDEX IF NOT EXISTS credito_clientes_user ON credito_clientes (user_id);
CREATE TABLE IF NOT EXISTS credito_operacoes (
  id              BIGSERIAL PRIMARY KEY,
  business_id     BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  order_id        BIGINT,
  status          TEXT NOT NULL DEFAULT 'pendente',
  valor_compra    NUMERIC(12,2) NOT NULL DEFAULT 0,
  entrada         NUMERIC(12,2) NOT NULL DEFAULT 0,
  principal       NUMERIC(12,2) NOT NULL DEFAULT 0,
  juros           NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_parcelado NUMERIC(12,2) NOT NULL DEFAULT 0,
  n_parcelas      INTEGER NOT NULL DEFAULT 1,
  condicoes       TEXT NOT NULL DEFAULT '{}',
  idem_key        TEXT NOT NULL,
  motivo          TEXT NOT NULL DEFAULT '',
  decidido_por    BIGINT,
  decidido_em     TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS credito_operacoes_idem ON credito_operacoes (idem_key);
CREATE INDEX IF NOT EXISTS credito_operacoes_biz ON credito_operacoes (business_id, status);
CREATE INDEX IF NOT EXISTS credito_operacoes_cli ON credito_operacoes (business_id, user_id);
CREATE INDEX IF NOT EXISTS credito_operacoes_ord ON credito_operacoes (order_id);
CREATE TABLE IF NOT EXISTS credito_parcelas (
  id           BIGSERIAL PRIMARY KEY,
  operacao_id  BIGINT NOT NULL REFERENCES credito_operacoes(id) ON DELETE CASCADE,
  business_id  BIGINT NOT NULL,
  user_id      BIGINT NOT NULL,
  numero       INTEGER NOT NULL,
  valor        NUMERIC(12,2) NOT NULL,
  valor_pago   NUMERIC(12,2) NOT NULL DEFAULT 0,
  vencimento   TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'pendente',
  pago_em      TIMESTAMPTZ,
  forma        TEXT NOT NULL DEFAULT '',
  historico    TEXT NOT NULL DEFAULT '[]',
  avisos       TEXT NOT NULL DEFAULT '[]',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS credito_parcelas_uni ON credito_parcelas (operacao_id, numero);
CREATE INDEX IF NOT EXISTS credito_parcelas_venc ON credito_parcelas (status, vencimento);
CREATE INDEX IF NOT EXISTS credito_parcelas_biz ON credito_parcelas (business_id, status);
CREATE TABLE IF NOT EXISTS credito_pagamentos (
  id            BIGSERIAL PRIMARY KEY,
  parcela_id    BIGINT NOT NULL REFERENCES credito_parcelas(id) ON DELETE CASCADE,
  operacao_id   BIGINT NOT NULL,
  business_id   BIGINT NOT NULL,
  user_id       BIGINT NOT NULL,
  valor         NUMERIC(12,2) NOT NULL,
  forma         TEXT NOT NULL DEFAULT '',
  registrado_por BIGINT,
  idem_key      TEXT NOT NULL,
  fin_item_id   BIGINT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS credito_pagamentos_idem ON credito_pagamentos (idem_key);
CREATE INDEX IF NOT EXISTS credito_pagamentos_biz ON credito_pagamentos (business_id, created_at);
CREATE TABLE IF NOT EXISTS credito_eventos (
  id           BIGSERIAL PRIMARY KEY,
  business_id  BIGINT NOT NULL,
  cliente_id   BIGINT,
  operacao_id  BIGINT,
  ator_id      BIGINT,
  tipo         TEXT NOT NULL,
  dados        TEXT NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS credito_eventos_biz ON credito_eventos (business_id, created_at);
CREATE INDEX IF NOT EXISTS credito_eventos_cli ON credito_eventos (business_id, cliente_id);
