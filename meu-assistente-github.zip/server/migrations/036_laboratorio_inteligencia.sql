-- Fase 9 — Laboratório de Inteligência (exclusivo de administradores autorizados). Tudo aditivo: nenhuma tabela existente é alterada.
-- Os experimentos rodam com um usuário sintético e dados fictícios; nada aqui grava em dados de usuários.

-- Desafios da Arena (catálogo padrão vem do código; aqui ficam os personalizados e as cópias editadas).
CREATE TABLE IF NOT EXISTS lab_challenges (
  id          BIGSERIAL PRIMARY KEY,
  slug        TEXT NOT NULL,                     -- identificador estável (ex.: mat-percentual, custom-12)
  category    TEXT NOT NULL,                     -- logica | contexto | memoria | planejamento | problemas | matematica | financeiro | comunicacao | contradicoes | execucao
  title       TEXT NOT NULL,
  prompt      TEXT NOT NULL,                     -- mensagem do usuário (sintética)
  context     TEXT NOT NULL DEFAULT '{}',        -- {historico:[{papel,texto}], memorias:[...], dados:{get_finance:{...}}}
  criteria    TEXT NOT NULL DEFAULT '[]',        -- [{tipo, valor, peso?}] — avaliação objetiva
  origin      TEXT NOT NULL DEFAULT 'personalizado', -- padrao | personalizado
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS lab_challenges_slug ON lab_challenges (slug);

-- Execuções do laboratório: arena, desafios contínuos, experimentos (atual × experimental), testes de agentes e simulações.
CREATE TABLE IF NOT EXISTS lab_runs (
  id          BIGSERIAL PRIMARY KEY,
  kind        TEXT NOT NULL,                     -- arena | continuo | experimento | agente | colaboracao | simulacao
  label       TEXT NOT NULL,
  config      TEXT NOT NULL DEFAULT '{}',        -- desafios escolhidos, variante experimental, agendamento de origem…
  results     TEXT NOT NULL DEFAULT '{}',        -- resultados por desafio / por turno / comparação
  score       INTEGER,                           -- 0..100 (média)
  total       INTEGER NOT NULL DEFAULT 0,
  passed      INTEGER NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'executando',-- executando | concluida | falhou | interrompida
  progress    INTEGER NOT NULL DEFAULT 0,
  schedule_id BIGINT,
  started_by  BIGINT,                            -- administrador (null = agendamento)
  created_at  TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS lab_runs_kind ON lab_runs (kind, id);

-- Especialistas criados no laboratório (ou cópias experimentais dos agentes existentes).
CREATE TABLE IF NOT EXISTS lab_agents (
  id           BIGSERIAL PRIMARY KEY,
  slug         TEXT NOT NULL,
  base_id      TEXT,                             -- agente existente que esta versão substitui (null = especialista novo)
  name         TEXT NOT NULL,
  role         TEXT NOT NULL,                    -- papel (ex.: "nutrição e saúde")
  instructions TEXT NOT NULL,
  triggers     TEXT NOT NULL DEFAULT '[]',       -- palavras que acionam o especialista
  access       TEXT NOT NULL DEFAULT '[]',       -- o que ele pode ler do quadro (lista fechada)
  status       TEXT NOT NULL DEFAULT 'experimental', -- experimental | aguardando | gradual | publicado | arquivado
  rollout_pct  INTEGER NOT NULL DEFAULT 0,       -- liberação gradual (por usuário, estável)
  version      INTEGER NOT NULL DEFAULT 1,
  versions     TEXT NOT NULL DEFAULT '[]',       -- [{versao, instrucoes, gatilhos, acesso, em, por}]
  last_test    TEXT,                             -- último teste/comparação (resumo) — exigido para aprovar
  history      TEXT NOT NULL DEFAULT '[]',       -- [{em, evento, por, nota}]
  created_by   BIGINT,
  created_at   TIMESTAMPTZ NOT NULL,
  updated_at   TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS lab_agents_status ON lab_agents (status);

-- Central de melhorias: propostas do diagnóstico e anotações (edição/arquivamento) sobre propostas dos outros módulos.
CREATE TABLE IF NOT EXISTS lab_improvements (
  id          BIGSERIAL PRIMARY KEY,
  source      TEXT NOT NULL,                     -- diagnostico | politica (learning_proposals) | regra (lab_proposals) | agente (lab_agents)
  source_id   BIGINT,                            -- id no módulo de origem (null para diagnóstico)
  fingerprint TEXT,
  title       TEXT,
  problem     TEXT,
  cause       TEXT,
  solution    TEXT,
  benefits    TEXT,
  risks       TEXT,
  tests       TEXT,                              -- testes necessários
  test_result TEXT,                              -- JSON
  status      TEXT NOT NULL DEFAULT 'aberta',    -- aberta | aprovada | rejeitada | arquivada
  archived    BOOLEAN NOT NULL DEFAULT FALSE,
  history     TEXT NOT NULL DEFAULT '[]',
  created_by  TEXT NOT NULL DEFAULT 'sistema',
  created_at  TIMESTAMPTZ NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS lab_improvements_src ON lab_improvements (source, source_id);

-- Desafios contínuos: avaliações periódicas programadas pelo administrador.
CREATE TABLE IF NOT EXISTS lab_schedules (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  categories  TEXT NOT NULL DEFAULT '[]',        -- vazio = todas
  every_hours INTEGER NOT NULL DEFAULT 24,       -- 6..168
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  last_run_id BIGINT,
  next_run_at TIMESTAMPTZ NOT NULL,
  created_by  BIGINT,
  created_at  TIMESTAMPTZ NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL
);
-- Reversão: DROP TABLE lab_challenges, lab_runs, lab_agents, lab_improvements, lab_schedules;
