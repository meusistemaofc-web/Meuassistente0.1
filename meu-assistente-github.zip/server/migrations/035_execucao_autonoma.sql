-- Fase 8 — Autonomia operacional. Tudo aditivo: as operações usam os serviços que já existem; nada é migrado.
-- Uma execução = um objetivo do usuário, com plano (etapas, dependências, nível), estado, progresso e histórico.
CREATE TABLE IF NOT EXISTS executions (
  id            TEXT PRIMARY KEY,                -- EX-XXXXXX (identificador único mostrado ao usuário)
  user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id TEXT,
  origin        TEXT NOT NULL DEFAULT 'chat',   -- chat | ia | pagina | api
  playbook      TEXT NOT NULL,                   -- objetivo reconhecido (ou 'ia' para ações da IA no chat)
  goal          TEXT NOT NULL,                   -- objetivo em linguagem natural (do próprio usuário)
  steps         TEXT NOT NULL DEFAULT '[]',      -- [{n, op, rotulo, args, depende, nivel, status, tentativas, erro, classe, resultado, verificado, desfeito}]
  level         INTEGER NOT NULL DEFAULT 1,      -- 1 automático | 2 confirmação | 3 autorização explícita
  status        TEXT NOT NULL,                   -- aguardando_confirmacao | aguardando_autorizacao | na_fila | executando | cancelando | concluida | parcial | falhou | interrompida | cancelada | expirada | revertida
  background    BOOLEAN NOT NULL DEFAULT FALSE,
  progress      INTEGER NOT NULL DEFAULT 0,      -- 0..100
  idem_key      TEXT NOT NULL,                   -- o mesmo pedido repetido em pouco tempo não cria outra execução
  version       INTEGER NOT NULL DEFAULT 0,      -- controle de concorrência (troca de estado só com a versão esperada)
  history       TEXT NOT NULL DEFAULT '[]',      -- [{em, evento, detalhe}]
  approved_by   TEXT,                            -- 'usuario:confirmou' | 'usuario:autorizou'
  started_at    TIMESTAMPTZ,
  finished_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL,
  updated_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS executions_user ON executions (user_id, created_at);
CREATE INDEX IF NOT EXISTS executions_status ON executions (status, updated_at);
CREATE INDEX IF NOT EXISTS executions_idem ON executions (user_id, idem_key);
-- Autonomia escolhida pelo usuário: 'padrao' (níveis do sistema) ou 'cautelosa' (toda alteração pede confirmação).
ALTER TABLE user_intel_prefs ADD COLUMN autonomy TEXT;
-- Reversão: DROP TABLE executions; (a coluna autonomy pode ficar: é opcional)
