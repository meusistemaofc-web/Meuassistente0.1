-- Capacidades pessoais do Cérebro do Chat. A primeira é Treino e Acompanhamento.
-- Só acrescenta tabelas; nada existente é alterado.
-- Arquitetura: `pessoal_perfis` guarda o que o assistente aprendeu sobre a pessoa em cada área (treino agora; depois
-- alimentação, hábitos, estudos, metas, rotinas), um registro por usuário e área, sem depender do histórico da conversa.
-- Cada área tem as próprias tabelas de dados (aqui: planos com versões, sessões realizadas e lembretes).
-- Reversão manual:
--   DROP TABLE treino_sessoes; DROP TABLE treino_plano_versoes; DROP TABLE treino_planos; DROP TABLE pessoal_perfis;
--   DELETE FROM schema_migrations WHERE version = '056_capacidades_pessoais_treino.sql';
CREATE TABLE IF NOT EXISTS pessoal_perfis (
  user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  area          TEXT NOT NULL,
  dados         JSONB NOT NULL DEFAULT '{}',
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, area)
);
-- Plano de treino: só um ativo por pessoa. Os dias (exercícios, séries, repetições, descanso, orientações) ficam em JSON.
CREATE TABLE IF NOT EXISTS treino_planos (
  id            BIGSERIAL PRIMARY KEY,
  user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  nome          TEXT NOT NULL,
  objetivo      TEXT,
  status        TEXT NOT NULL DEFAULT 'ativo',        -- ativo | arquivado
  versao        INTEGER NOT NULL DEFAULT 1,
  plano         JSONB NOT NULL DEFAULT '{}',          -- { dias: [{ dia, titulo, foco, duracaoMin, exercicios: [...] }], orientacoes: [...] }
  origem        TEXT NOT NULL DEFAULT 'ia',           -- ia | modelo (gerado sem IA)
  lembretes     JSONB NOT NULL DEFAULT '{}',          -- { hora, dias, itens: [ids dos lembretes reais da Agenda] }
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS treino_planos_user ON treino_planos (user_id, status);
-- Histórico de alterações do plano: cada versão anterior, com o motivo (o que a pessoa pediu).
CREATE TABLE IF NOT EXISTS treino_plano_versoes (
  id         BIGSERIAL PRIMARY KEY,
  plano_id   BIGINT NOT NULL REFERENCES treino_planos(id) ON DELETE CASCADE,
  versao     INTEGER NOT NULL,
  plano      JSONB NOT NULL DEFAULT '{}',
  motivo     TEXT,
  criado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS treino_plano_versoes_plano ON treino_plano_versoes (plano_id, versao);
-- Treinos realizados: um registro por dia (local da pessoa) e plano. Base da frequência, da sequência e da evolução.
CREATE TABLE IF NOT EXISTS treino_sessoes (
  id         BIGSERIAL PRIMARY KEY,
  user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plano_id   BIGINT REFERENCES treino_planos(id) ON DELETE SET NULL,
  data       TEXT NOT NULL,                           -- AAAA-MM-DD no fuso da pessoa
  dia_plano  INTEGER,                                 -- 0=domingo … 6=sábado (o dia do plano que foi feito)
  titulo     TEXT,
  status     TEXT NOT NULL DEFAULT 'concluido',       -- concluido | parcial | pulado
  nota       TEXT,
  esforco    INTEGER,                                 -- 1 a 10, quando informado
  criado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS treino_sessoes_dia ON treino_sessoes (user_id, data);
