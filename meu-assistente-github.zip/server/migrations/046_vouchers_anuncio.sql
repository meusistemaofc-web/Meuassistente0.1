-- Cupons e Vouchers para ATIVAÇÃO DE ANÚNCIOS (diferentes dos cupons de desconto das lojas, que continuam iguais).
-- Somente ADITIVA. Reversão manual: DROP TABLE ad_voucher_events; DROP TABLE ad_voucher_user_uses;
--   DROP TABLE ad_voucher_redemptions; DROP TABLE ad_vouchers; DELETE FROM schema_migrations WHERE version = '046_vouchers_anuncio.sql';
CREATE TABLE IF NOT EXISTS ad_vouchers (
  id              BIGSERIAL PRIMARY KEY,
  code            TEXT NOT NULL UNIQUE,                 -- sempre MAIÚSCULO, sem espaços
  campaign        TEXT NOT NULL DEFAULT '',             -- campanha (agrupa códigos gerados em lote)
  description     TEXT NOT NULL DEFAULT '',             -- descrição interna
  kind            TEXT NOT NULL,                        -- percentual | gratuito | vitalicio
  percent         INTEGER,                              -- 1 a 100 (percentual)
  period_qty      INTEGER,                              -- gratuito: quantidade
  period_unit     TEXT,                                 -- gratuito: dias | meses
  max_uses        INTEGER,                              -- NULL = ilimitado
  max_per_user    INTEGER NOT NULL DEFAULT 1,
  uses            INTEGER NOT NULL DEFAULT 0,           -- reservados + resgatados (controle atômico do limite)
  starts_at       TIMESTAMPTZ,
  ends_at         TIMESTAMPTZ,                          -- fim da campanha
  valid_until     TIMESTAMPTZ,                          -- validade individual deste código
  plans           TEXT NOT NULL DEFAULT '[]',           -- JSON: planos aceitos ([] = todos)
  categories      TEXT NOT NULL DEFAULT '[]',           -- JSON: ramos aceitos ([] = todos)
  status          TEXT NOT NULL DEFAULT 'ativo',        -- ativo | pausado | cancelado
  created_by      BIGINT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ad_vouchers_campaign ON ad_vouchers (campaign);

-- contador por usuário com chave única: o limite por usuário é garantido por UPDATE condicional (atômico)
CREATE TABLE IF NOT EXISTS ad_voucher_user_uses (
  voucher_id  BIGINT NOT NULL,
  user_id     BIGINT NOT NULL,
  uses        INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (voucher_id, user_id)
);

-- cada aplicação de um código a um anúncio (com a "fotografia" do benefício: editar o cupom depois não muda o concedido)
CREATE TABLE IF NOT EXISTS ad_voucher_redemptions (
  id              BIGSERIAL PRIMARY KEY,
  voucher_id      BIGINT NOT NULL,
  code            TEXT NOT NULL,
  campaign        TEXT NOT NULL DEFAULT '',
  user_id         BIGINT NOT NULL,
  business_id     BIGINT NOT NULL,
  plan_id         TEXT,
  kind            TEXT NOT NULL,
  percent         INTEGER,
  period_days     INTEGER,
  period_label    TEXT,
  original_value  NUMERIC(12,2) NOT NULL DEFAULT 0,
  final_value     NUMERIC(12,2) NOT NULL DEFAULT 0,
  saved_value     NUMERIC(12,2) NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'reservado',    -- reservado | resgatado | liberado
  payment_id      TEXT,
  applied_until   TIMESTAMPTZ,                          -- até quando o anúncio ficou no ar com o benefício
  applied_at      TIMESTAMPTZ,                          -- quando o benefício foi aplicado ao anúncio
  release_reason  TEXT,
  reserved_until  TIMESTAMPTZ,                          -- reserva expira se o anúncio não for ativado/pago
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  confirmed_at    TIMESTAMPTZ,
  released_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ad_voucher_redemptions_voucher ON ad_voucher_redemptions (voucher_id, status);
CREATE INDEX IF NOT EXISTS ad_voucher_redemptions_business ON ad_voucher_redemptions (business_id, status);
-- um anúncio só tem UM cupom em reserva por vez
CREATE UNIQUE INDEX IF NOT EXISTS ad_voucher_redemptions_uma_reserva ON ad_voucher_redemptions (business_id) WHERE status = 'reservado';

CREATE TABLE IF NOT EXISTS ad_voucher_events (
  id          BIGSERIAL PRIMARY KEY,
  voucher_id  BIGINT,
  action      TEXT NOT NULL,                            -- criado | editado | status | aplicado | removido | expirado | resgatado | beneficio_aplicado | recusado
  actor       TEXT,
  detail      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ad_voucher_events_voucher ON ad_voucher_events (voucher_id, id);
