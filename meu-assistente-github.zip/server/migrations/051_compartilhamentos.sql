-- Compartilhamento de produtos e serviços: registro de compartilhamentos (toque num canal do menu de compartilhar) e de
-- visitas que chegaram por um link compartilhado. Somente ADITIVA. Não guarda dados pessoais: o visitante vira um código
-- (hash diário, sem IP nem conta), usado só para não contar a mesma visita duas vezes no dia.
-- Não é venda nem agendamento: fica separado de pedidos e de business_stats.
-- Reversão manual: DROP TABLE share_events; DELETE FROM schema_migrations WHERE version = '051_compartilhamentos.sql';
CREATE TABLE IF NOT EXISTS share_events (
  id           BIGSERIAL PRIMARY KEY,
  business_id  BIGINT NOT NULL,
  product_id   BIGINT NOT NULL,
  item_type    TEXT NOT NULL,              -- produto | servico
  kind         TEXT NOT NULL,              -- compartilhamento | visita
  channel      TEXT NOT NULL DEFAULT '',   -- whatsapp | telegram | facebook | nativo | copiar_link | copiar_mensagem (visita: '')
  viewer       TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS share_events_business ON share_events (business_id, created_at);
CREATE INDEX IF NOT EXISTS share_events_product ON share_events (product_id, kind);
