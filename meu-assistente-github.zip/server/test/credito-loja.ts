// TESTES — CRÉDITO DA LOJA pelo app real (rotas reais, banco real SQLite, checkout de sempre).
//   A. ADM: recurso desligado bloqueia tudo; autorização, suspensão, revogação; tetos globais; só administrador
//   B. empresa: regras dentro dos tetos; sem autorização nada funciona; isolamento entre empresas
//   C. clientes: busca, concessão/alteração/suspensão de limite, limite máximo
//   D. compra no checkout: simulação (sem juros, juros ao mês, entrada mínima), aceite explícito, total conferido, limite
//      insuficiente, aprovação automática × manual (até um valor), aprovação e rejeição (limite e estoque devolvidos)
//   E. parcelas e pagamentos: parcial e integral, duplicidade, valor acima, parcial proibido, quitação, financeiro sem duplicar
//   F. vencimentos e notificações; atraso bloqueia nova compra; cancelamento do pedido libera o limite; concorrência
// Uso: npm run test:credito
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, one, J } = await import('../src/db/index.js')
const CL = await import('../src/lib/credito-loja.js')

let ok = 0, falhas = 0; const erros: string[] = []
const check = (c: unknown, m: string, d?: unknown) => { if (c) { ok++; console.log('    ✓', m) } else { falhas++; erros.push(m); console.log('    ✗', m, d !== undefined ? JSON.stringify(d).slice(0, 400) : '') } }
let nIp = 0; const f0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? f0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.9.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : f0(u, o)) as typeof fetch
const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100
const uidDe = async (c: any) => Number((await c.call('GET', '/api/me')).body.profile.id)

async function loja(nome: string, produtos: any[]) {
  const cli = await S.novoUsuario(), uid = await uidDe(cli)
  const data = { empresa: nome, categoria: 'Loja', titulo: nome, horarioCfg: { modo: 'aberto', dias: {} }, pagamento: { pix: true, dinheiro: true, chavePix: 'loja@pix.com' }, entrega: { retirada: true, entrega: false }, operacao: 'produtos' }
  const bid = Number((await q("INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, expires_at, created_at, updated_at, modalidade) VALUES ($1,$2,'ativo','n4',$3,$4,$5,$5,'products') RETURNING id", [uid, 'AN-CR-' + Math.random().toString(36).slice(2, 8), JSON.stringify(data), new Date(Date.now() + 30 * 864e5).toISOString(), new Date().toISOString()]))[0].id)
  const pids: Record<string, number> = {}
  for (const p of produtos) { const r = await cli.call('POST', `/api/v2/ads/${bid}/products`, { fotos: ['data:image/png;base64,' + Buffer.from('PNG' + p.nome).toString('base64')], ...p }); if (r.status !== 200) throw new Error('produto: ' + JSON.stringify(r.body)) }
  for (const r of await q('SELECT id, data FROM products WHERE business_id = $1', [bid])) pids[J<any>(r.data, {}).nome] = Number(r.id)
  return { cli, uid, bid, pids }
}
const A = await loja('Moda Ana', [{ nome: 'Camisa', preco: 100 }, { nome: 'Jaqueta', preco: 200, estoque: 5 }, { nome: 'Casaco', preco: 600 }, { nome: 'Meia', preco: 10 }])
const B = await loja('Calçados Bia', [{ nome: 'Tênis', preco: 150 }])
const c1 = await S.novoUsuario(), c1id = await uidDe(c1), c1email = (await c1.call('GET', '/api/me')).body.profile.email
const c2 = await S.novoUsuario(), c2id = await uidDe(c2)
const adm = S.admin
const base = `/api/v2/businesses/${A.bid}/credito`
const pedir = (c: any, bid: number, itens: any[], extra: any = {}) => c.call('POST', `/api/v2/businesses/${bid}/orders`, { itens, modo: 'retirada', pagamento: 'credito', idem: 'i' + Math.random().toString(36).slice(2), ...extra })
const estoque = async (pid: number) => (await one('SELECT stock FROM products WHERE id = $1', [pid]))?.stock
const notifs = async (c: any) => ((await c.call('GET', '/api/notifications')).body.items || []).map((n: any) => n.title as string)

console.log('\n# A. ADM: recurso desligado, autorização e permissões')
let r = await c1.call('GET', '/api/panel/credito'); check(r.status === 403, 'usuário comum não acessa o painel do ADM (403)')
r = await A.cli.call('GET', `${base}/painel`); check(r.status === 403 && r.body.code === 'credito_nao_autorizado', 'empresa sem autorização: painel bloqueado no servidor', r.body)
r = await adm.call('GET', '/api/panel/credito'); check(r.status === 200 && r.body.config.ativo === false && r.body.empresas.length === 0, 'ADM: recurso começa desligado e sem empresas')
r = await adm.call('GET', '/api/panel/credito/empresas?q=moda'); check(r.body.empresas?.some((e: any) => e.id === A.bid && e.situacao === null), 'ADM encontra a empresa para autorizar')
r = await adm.call('POST', `/api/panel/credito/empresas/${A.bid}`, { acao: 'autorizar' }); check(r.status === 200 && r.body.situacao === 'autorizada', 'ADM autoriza a empresa A')
r = await A.cli.call('PUT', `${base}/config`, { ativo: true }); check(r.status === 403 && r.body.code === 'credito_desativado', 'com o recurso desligado globalmente, a empresa não configura (bloqueio no backend)', r.body)
r = await c1.call('GET', `${base}/opcoes`); check(r.body.disponivel === false, 'recurso desligado: checkout não oferece crédito')
r = await adm.call('PUT', '/api/panel/credito', { maxParcelas: 99 }); check(r.status === 400, 'ADM: teto inválido recusado')
r = await adm.call('PUT', '/api/panel/credito', { ativo: true, maxParcelas: 6, jurosMaxMes: 5, jurosMaxTotal: 40, limiteMaxCliente: 2000, entradaMinPct: 0, diasAvisoVencimento: 3 }); check(r.status === 200 && r.body.config.ativo === true, 'ADM liga o recurso com tetos globais')

console.log('\n# B. regras da empresa (dentro dos tetos) e isolamento')
r = await A.cli.call('PUT', `${base}/config`, { taxa: 9, jurosTipo: 'mensal' }); check(r.status === 400 && /5%/.test(r.body.error || r.body.message || JSON.stringify(r.body)), 'juros acima do teto do ADM recusados', r.body)
r = await A.cli.call('PUT', `${base}/config`, { parcelas: [2, 12] }); check(r.status === 400, 'parcelas acima do teto do ADM recusadas')
r = await A.cli.call('PUT', `${base}/config`, { limiteMaxCliente: 5000 }); check(r.status === 400, 'limite por cliente acima do teto do ADM recusado')
const CFG = { ativo: true, parcelas: [2, 3, 4], jurosTipo: 'mensal', taxa: 2, semJurosAte: 2, entradaMinPct: 10, aprovacao: 'ate_valor', aprovacaoAutoAte: 150, compraMin: 20, compraMax: 1000, limiteMaxCliente: 800, limitePadrao: 300, primeiraParcela: 'posterior', primeiroVencDias: 30, intervaloDias: 30, permitirParcial: true, condicoes: 'Troca em até 7 dias.' }
r = await A.cli.call('PUT', `${base}/config`, CFG); check(r.status === 200 && r.body.config.taxa === 2 && r.body.config.parcelas.join() === '2,3,4', 'empresa salva as próprias regras')
r = await A.cli.call('GET', `${base}/config`); check(r.body.config.aprovacao === 'ate_valor' && r.body.config.entradaMinPct === 10, 'regras persistidas')
r = await B.cli.call('GET', `${base}/painel`); check(r.status === 404, 'dono de outra empresa não vê o crédito da empresa A')
r = await c1.call('GET', `${base}/painel`); check(r.status === 404, 'cliente não acessa o painel da empresa')
r = await B.cli.call('GET', `/api/v2/businesses/${B.bid}/credito/painel`); check(r.status === 403, 'empresa B (não autorizada) continua bloqueada')
r = await A.cli.call('GET', '/api/v2/ads/mine'); check(r.body.items.find((x: any) => x.id === A.bid)?.creditoLoja?.situacao === 'autorizada', 'Ajustes mostram o Crédito da Loja só para a empresa autorizada')
r = await B.cli.call('GET', '/api/v2/ads/mine'); check(!r.body.items.find((x: any) => x.id === B.bid)?.creditoLoja, 'empresa não autorizada não recebe a opção')

console.log('\n# C. clientes: busca e limites')
r = await A.cli.call('GET', `${base}/clientes?q=${encodeURIComponent(c1email)}`); check(r.body.clientes?.length === 1 && r.body.clientes[0].id === c1id, 'busca encontra o cliente pelo e-mail exato')
r = await A.cli.call('GET', `${base}/clientes?q=Pessoa`); check(Array.isArray(r.body.clientes) && !r.body.clientes.some((c: any) => c.id === c2id), 'busca por nome não lista contas sem relação com a loja')
r = await A.cli.call('PUT', `${base}/clientes`, { userId: c1id, limite: 900 }); check(r.status === 400, 'limite acima do máximo por cliente recusado')
r = await A.cli.call('PUT', `${base}/clientes`, { userId: A.uid, limite: 100 }); check(r.status === 400, 'dono não recebe crédito da própria loja')
r = await A.cli.call('PUT', `${base}/clientes`, { userId: c1id, limite: 500 }); check(r.status === 200 && r.body.cliente.limite === 500 && r.body.cliente.disponivel === 500, 'limite de R$ 500 concedido ao cliente')
check((await notifs(c1)).some((t) => /Limite de crédito liberado/.test(t)), 'cliente avisado: limite liberado')
r = await c1.call('GET', `${base}/opcoes?valor=100`); check(r.body.disponivel === true && r.body.limiteDisponivel === 500 && r.body.simulacoes?.length === 3, 'checkout do cliente com crédito: opções e simulações')
r = await c2.call('GET', `${base}/opcoes`); check(r.body.disponivel === false, 'cliente sem limite: crédito não aparece no checkout')

console.log('\n# D. simulação e compra')
const hoje = await CL.hojeDa(A.bid)
r = await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 3, entrada: 0 })
const i = 0.02, pmt = r2((90 * i) / (1 - Math.pow(1 + i, -3)))
check(r.body.simulacao.entrada === 10 && r.body.simulacao.principal === 90, 'entrada mínima de 10% aplicada (R$ 10) e R$ 90 a parcelar')
check(r.body.simulacao.parcelas.every((p: any) => p.valor === pmt) && r.body.simulacao.juros === r2(pmt * 3 - 90), `3x com juros de 2% ao mês (tabela Price): 3 × ${pmt}`, r.body.simulacao)
check(r.body.simulacao.parcelas[0].vencimento > hoje && r.body.termos.some((t: string) => /Troca em até 7 dias/.test(t)), '1ª parcela depois da compra e condições da loja nos termos')
r = await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 2, entrada: 10 }); check(r.body.simulacao.juros === 0 && r.body.simulacao.parcelas.every((p: any) => p.valor === 45), '2x sem juros (sem juros até 2x)')
r = await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 5 }); check(r.status === 400, 'quantidade de parcelas não oferecida é recusada')
const sim3 = (await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 3, entrada: 10 })).body.simulacao
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 10, totalFinal: sim3.totalFinal } }); check(r.status === 400 && r.body.code === 'credito_aceite', 'sem aceite explícito das condições: recusado', r.body)
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 10, totalFinal: sim3.totalFinal - 5, aceite: true } }); check(r.status === 409 && r.body.code === 'credito_condicoes_mudaram', 'total diferente do aceito: pede nova confirmação (409)')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 5, totalFinal: sim3.totalFinal, aceite: true } }); check(r.status === 400, 'entrada abaixo da mínima recusada')
r = await pedir(c1, A.bid, [{ pid: A.pids.Meia, qtd: 1 }], { credito: { parcelas: 2, entrada: 1, totalFinal: 10, aceite: true } }); check(r.status === 400 && r.body.code === 'credito_valor', 'compra abaixo do mínimo da loja recusada')
r = await pedir(c2, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 10, totalFinal: sim3.totalFinal, aceite: true } }); check(r.status === 403 && r.body.code === 'credito_sem_limite', 'cliente sem crédito não compra a crédito (bloqueio no servidor)')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 10, totalFinal: sim3.totalFinal, aceite: true } })
const o1 = r.body.order; check(r.status === 200 && o1.status === 'novo' && o1.pagamento === 'credito' && o1.credito?.operacaoId, 'compra de R$ 100 aprovada automaticamente (até R$ 150): pedido novo', r.body)
const op1 = await one('SELECT * FROM credito_operacoes WHERE order_id = $1', [o1.id])
check(op1?.status === 'ativa' && Number(op1.principal) === 90, 'operação ativa com R$ 90 financiados')
const pars1 = await q('SELECT * FROM credito_parcelas WHERE operacao_id = $1 ORDER BY numero', [op1!.id])
check(pars1.length === 4 && Number(pars1[0].numero) === 0 && Number(pars1[0].valor) === 10 && pars1.slice(1).every((p: any) => Number(p.valor) === pmt), 'parcelas geradas: entrada + 3 parcelas', pars1.map((p: any) => [p.numero, p.valor, p.vencimento]))
check(String(pars1[2].vencimento) > String(pars1[1].vencimento) && String(pars1[3].vencimento) > String(pars1[2].vencimento), 'vencimentos em sequência mensal')
let uso = await CL.usoCliente(A.bid, c1id); check(uso.utilizado === 90 && uso.disponivel === 410, 'limite utilizado R$ 90, disponível R$ 410', uso)
check((await notifs(c1)).some((t) => /Compra realizada com Crédito da Loja/.test(t)), 'cliente avisado: compra realizada com Crédito da Loja')
r = await A.cli.call('GET', `/api/v2/ads/${A.bid}/orders`); check(r.body.items.some((o: any) => o.id === o1.id), 'pedido aparece no painel de pedidos da loja (fluxo de sempre)')
// limite insuficiente
const est0 = await estoque(A.pids.Casaco)
r = await c1.call('POST', `${base}/simular`, { valor: 600, parcelas: 4, entrada: 60 }); check(r.body.podeContratar === false && r.body.avisos.some((a: string) => /Limite insuficiente/.test(a)), 'simulação avisa limite insuficiente')
r = await pedir(c1, A.bid, [{ pid: A.pids.Casaco, qtd: 1 }], { credito: { parcelas: 4, entrada: 60, totalFinal: r.body.simulacao.totalFinal, aceite: true } }); check(r.status === 400 && r.body.code === 'credito_limite', 'compra acima do limite disponível recusada', r.body)
check(!(await one("SELECT id FROM orders WHERE customer_id = $1 AND total = 600", [c1id])), 'nenhum pedido criado com limite insuficiente')
check((await estoque(A.pids.Casaco)) === est0, 'estoque intacto')

console.log('\n# D2. aprovação manual: rejeitar e aprovar')
const estJ = await estoque(A.pids.Jaqueta)
let s2 = (await c1.call('POST', `${base}/simular`, { valor: 200, parcelas: 4, entrada: 20 })).body
check(s2.aprovacaoManual === true, 'acima de R$ 150 a simulação avisa que depende de aprovação')
r = await pedir(c1, A.bid, [{ pid: A.pids.Jaqueta, qtd: 1 }], { credito: { parcelas: 4, entrada: 20, totalFinal: s2.simulacao.totalFinal, aceite: true } })
const o2 = r.body.order; check(r.status === 200 && o2.status === 'aguardando_credito', 'pedido fica aguardando aprovação do crédito', r.body)
check((await estoque(A.pids.Jaqueta)) === estJ - 1, 'estoque reservado durante a análise')
const op2 = await one('SELECT * FROM credito_operacoes WHERE order_id = $1', [o2.id]); check(op2?.status === 'pendente' && !(await one('SELECT id FROM credito_parcelas WHERE operacao_id = $1', [op2!.id])), 'solicitação pendente sem parcelas geradas')
uso = await CL.usoCliente(A.bid, c1id); check(uso.reservado === 180 && uso.disponivel === 230, 'limite reservado (não consumido) durante a análise', uso)
r = await A.cli.call('GET', `/api/v2/ads/${A.bid}/orders`); check(!r.body.items.some((o: any) => o.id === o2.id), 'pedido em análise não entra na lista de pedidos antes da aprovação')
check((await notifs(A.cli)).some((t) => /Nova solicitação de Crédito da Loja/.test(t)), 'dono avisado da solicitação')
r = await A.cli.call('GET', `${base}/painel`); check(r.body.solicitacoes?.some((s: any) => s.id === Number(op2!.id)), 'solicitação aparece no painel da empresa')
r = await A.cli.call('POST', `${base}/solicitacoes/${op2!.id}/decisao`, { decisao: 'rejeitar' }); check(r.status === 400, 'rejeitar exige motivo')
r = await A.cli.call('POST', `${base}/solicitacoes/${op2!.id}/decisao`, { decisao: 'rejeitar', motivo: 'Cadastro incompleto' }); check(r.status === 200 && r.body.status === 'rejeitada', 'dono rejeita a solicitação')
check((await one('SELECT status FROM orders WHERE id = $1', [o2.id]))?.status === 'recusado' && (await estoque(A.pids.Jaqueta)) === estJ, 'pedido recusado e estoque devolvido')
uso = await CL.usoCliente(A.bid, c1id); check(uso.reservado === 0 && uso.disponivel === 410, 'limite reservado liberado', uso)
check((await notifs(c1)).some((t) => /Crédito não aprovado/.test(t)), 'cliente avisado da rejeição')
r = await A.cli.call('POST', `${base}/solicitacoes/${op2!.id}/decisao`, { decisao: 'aprovar' }); check(r.status === 409, 'decisão repetida recusada (já decidida)')
s2 = (await c1.call('POST', `${base}/simular`, { valor: 200, parcelas: 4, entrada: 20 })).body
r = await pedir(c1, A.bid, [{ pid: A.pids.Jaqueta, qtd: 1 }], { credito: { parcelas: 4, entrada: 20, totalFinal: s2.simulacao.totalFinal, aceite: true } })
const o3 = r.body.order, op3 = await one('SELECT * FROM credito_operacoes WHERE order_id = $1', [o3.id])
r = await A.cli.call('POST', `${base}/solicitacoes/${op3!.id}/decisao`, { decisao: 'aprovar' }); check(r.status === 200 && r.body.status === 'aprovada', 'dono aprova a solicitação')
check((await one('SELECT status FROM orders WHERE id = $1', [o3.id]))?.status === 'novo' && Number((await one('SELECT COUNT(*) AS n FROM credito_parcelas WHERE operacao_id = $1', [op3!.id]))?.n) === 5, 'aprovada: pedido segue o fluxo (novo) e entrada + 4 parcelas geradas')
uso = await CL.usoCliente(A.bid, c1id); check(uso.utilizado === 270 && uso.reservado === 0 && uso.disponivel === 230, 'limite consumido após a aprovação (R$ 90 + R$ 180)', uso)
check((await notifs(c1)).some((t) => /Crédito aprovado/.test(t)), 'cliente avisado: crédito aprovado')

console.log('\n# E. pagamentos (parcial, integral, duplicidade) e financeiro')
const p1 = pars1[1], ent = pars1[0]
r = await A.cli.call('POST', `${base}/parcelas/${ent.id}/pagamento`, { forma: 'pix', idem: 'e1' }); check(r.status === 200 && r.body.parcial === false, 'entrada paga (valor total por padrão)')
r = await A.cli.call('POST', `${base}/parcelas/${p1.id}/pagamento`, { valor: 10, forma: 'dinheiro', idem: 'p1a' }); check(r.status === 200 && r.body.parcial === true && r.body.restante === r2(pmt - 10), 'pagamento parcial de R$ 10 registrado')
r = await A.cli.call('POST', `${base}/parcelas/${p1.id}/pagamento`, { valor: 10, forma: 'dinheiro', idem: 'p1a' }); check(r.body.duplicado === true, 'mesmo pagamento enviado duas vezes não duplica')
check(Number((await one('SELECT COUNT(*) AS n FROM credito_pagamentos WHERE parcela_id = $1', [p1.id]))?.n) === 1, 'um único registro de pagamento')
r = await A.cli.call('POST', `${base}/parcelas/${p1.id}/pagamento`, { valor: 999, forma: 'pix', idem: 'p1b' }); check(r.status === 400, 'valor acima do restante recusado')
r = await A.cli.call('POST', `${base}/parcelas/${p1.id}/pagamento`, { forma: 'xyz', idem: 'p1c' }); check(r.status === 400, 'forma de pagamento inválida recusada')
r = await B.cli.call('POST', `/api/v2/businesses/${B.bid}/credito/parcelas/${p1.id}/pagamento`, { forma: 'pix', idem: 'hack' }); check(r.status === 403 || r.status === 404, 'outra empresa não registra pagamento na parcela da empresa A')
r = await A.cli.call('POST', `${base}/parcelas/${p1.id}/pagamento`, { forma: 'pix', idem: 'p1d' }); check(r.status === 200 && r.body.parcial === false, 'restante da parcela 1 pago')
const pp1 = await one('SELECT * FROM credito_parcelas WHERE id = $1', [p1.id]); check(pp1?.status === 'paga' && Number(pp1.valor_pago) === pmt && J<any[]>(pp1.historico, []).length >= 3, 'parcela 1 paga, com histórico (criada, parcial, paga)')
uso = await CL.usoCliente(A.bid, c1id); check(uso.utilizado === r2(180 + 90 * (1 - pmt / (pmt * 3))), 'pagar a parcela libera limite proporcional', uso)
const fin = await q("SELECT data FROM items WHERE user_id = $1 AND type = 'expense'", [A.uid])
const finCred = fin.filter((x: any) => String(J<any>(x.data, {}).source || '').startsWith('credito:pag:'))
const somaFin = r2(finCred.reduce((a: number, x: any) => a + Number(J<any>(x.data, {}).amount), 0))
check(finCred.length === 3 && somaFin === r2(10 + pmt), 'financeiro do dono: uma receita por pagamento (entrada + parcial + restante)', { n: finCred.length, somaFin })
// pedido concluído: a venda a crédito não entra inteira no financeiro
for (const st of ['aceito', 'preparo', 'pronto', 'concluido']) await A.cli.call('POST', `/api/v2/ads/${A.bid}/orders/${o1.id}`, { status: st })
check((await one('SELECT status FROM orders WHERE id = $1', [o1.id]))?.status === 'concluido', 'pedido a crédito concluído no fluxo normal')
await new Promise((x) => setTimeout(x, 200))
const fin2 = await q("SELECT data FROM items WHERE user_id = $1 AND type = 'expense'", [A.uid])
check(!fin2.some((x: any) => J<any>(x.data, {}).source === `pedido:${o1.id}`), 'concluir o pedido NÃO lança a venda inteira (sem contagem duplicada)')
// parcial desligado
await A.cli.call('PUT', `${base}/config`, { permitirParcial: false })
r = await A.cli.call('POST', `${base}/parcelas/${pars1[2].id}/pagamento`, { valor: 5, forma: 'pix', idem: 'p2a' }); check(r.status === 400, 'com pagamento parcial desligado, valor parcial é recusado')
await A.cli.call('PUT', `${base}/config`, { permitirParcial: true })
await A.cli.call('POST', `${base}/parcelas/${pars1[2].id}/pagamento`, { forma: 'pix', idem: 'p2' })
r = await A.cli.call('POST', `${base}/parcelas/${pars1[3].id}/pagamento`, { forma: 'cartao', idem: 'p3' }); check(r.body.quitada === true, 'última parcela paga: compra quitada')
check((await one('SELECT status FROM credito_operacoes WHERE id = $1', [op1!.id]))?.status === 'quitada', 'operação quitada')
check((await notifs(c1)).some((t) => /Crédito quitado/.test(t)) && (await notifs(c1)).some((t) => /Pagamento registrado/.test(t)), 'cliente avisado dos pagamentos e da quitação')
uso = await CL.usoCliente(A.bid, c1id); check(uso.utilizado === 180 && uso.disponivel === 320, 'compra quitada não usa mais limite', uso)

console.log('\n# F. vencimentos, atraso, notificações')
const pars3 = await q('SELECT * FROM credito_parcelas WHERE operacao_id = $1 ORDER BY numero', [op3!.id])
const ontem = new Date(Date.parse(hoje) - 864e5).toISOString().slice(0, 10), amanha = new Date(Date.parse(hoje) + 864e5).toISOString().slice(0, 10)
await q('UPDATE credito_parcelas SET vencimento = $1 WHERE id = $2', [ontem, pars3[1].id])
await q('UPDATE credito_parcelas SET vencimento = $1 WHERE id = $2', [amanha, pars3[2].id])
await CL.tickVencimentos(new Date(), true)
check((await one('SELECT status FROM credito_parcelas WHERE id = $1', [pars3[1].id]))?.status === 'vencida', 'parcela não paga até o vencimento fica vencida')
const n1 = await notifs(c1); check(n1.some((t) => /Parcela 1\/4 vencida/.test(t)) && n1.some((t) => /Parcela 2\/4 vence amanhã/.test(t)), 'cliente avisado: parcela vencida e parcela que vence amanhã', n1.slice(0, 6))
check((await notifs(A.cli)).some((t) => /Parcela em atraso/.test(t)), 'dono avisado do atraso')
await CL.tickVencimentos(new Date(), true)
check(n1.filter((t) => /vencida/.test(t)).length === (await notifs(c1)).filter((t) => /vencida/.test(t)).length, 'aviso de vencimento não se repete')
r = await A.cli.call('GET', `${base}/painel`); check(r.body.kpis.totalVencido > 0 && r.body.inadimplentes.some((x: any) => x.userId === c1id), 'painel: total vencido e cliente inadimplente', r.body.kpis)
check(r.body.proximas.some((p: any) => p.id === Number(pars3[2].id)), 'painel: parcelas próximas do vencimento')
const sM = (await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 2, entrada: 10 })).body
check(sM.avisos.some((a: string) => /atraso/.test(a)), 'simulação avisa que há atraso')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 2, entrada: 10, totalFinal: sM.simulacao.totalFinal, aceite: true } }); check(r.status === 400 && r.body.code === 'credito_em_atraso', 'cliente em atraso não faz nova compra a crédito')
await A.cli.call('POST', `${base}/parcelas/${pars3[0].id}/pagamento`, { forma: 'pix', idem: 'x0' })
await A.cli.call('POST', `${base}/parcelas/${pars3[1].id}/pagamento`, { forma: 'pix', idem: 'x1' })
check((await one('SELECT status FROM credito_parcelas WHERE id = $1', [pars3[1].id]))?.status === 'paga', 'parcela vencida pode ser paga')

console.log('\n# F2. suspensão do cliente, da empresa e recurso desligado')
await A.cli.call('PUT', `${base}/clientes`, { userId: c1id, situacao: 'suspenso' })
check((await notifs(c1)).some((t) => /Crédito suspenso/.test(t)), 'cliente avisado: crédito suspenso')
r = await c1.call('GET', `${base}/opcoes`); check(r.body.disponivel === false, 'cliente suspenso: crédito some do checkout')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 2, entrada: 10, totalFinal: sM.simulacao.totalFinal, aceite: true } }); check(r.status === 403, 'cliente suspenso não compra a crédito')
await A.cli.call('PUT', `${base}/clientes`, { userId: c1id, situacao: 'ativo', limite: 600 })
check((await one("SELECT COUNT(*) AS n FROM credito_eventos WHERE business_id = $1 AND cliente_id = $2 AND tipo IN ('limite_concedido','limite_alterado','credito_suspenso','credito_liberado')", [A.bid, c1id]))?.n >= 4, 'histórico auditável de concessão, suspensão, liberação e alteração')
r = await adm.call('POST', `/api/panel/credito/empresas/${A.bid}`, { acao: 'suspender' }); check(r.status === 400, 'ADM: suspender exige motivo')
r = await adm.call('POST', `/api/panel/credito/empresas/${A.bid}`, { acao: 'suspender', motivo: 'Análise de risco' }); check(r.status === 200, 'ADM suspende a empresa')
r = await c1.call('GET', `${base}/opcoes`); check(r.body.disponivel === false, 'empresa suspensa: crédito some do checkout')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 2, entrada: 10, totalFinal: sM.simulacao.totalFinal, aceite: true } }); check(r.status === 403 && r.body.code === 'credito_nao_autorizado', 'empresa suspensa: compra a crédito bloqueada no servidor')
r = await A.cli.call('PUT', `${base}/clientes`, { userId: c2id, limite: 100 }); check(r.status === 403, 'empresa suspensa não concede crédito')
r = await A.cli.call('GET', `${base}/painel`); check(r.status === 200 && r.body.estado.situacao === 'suspensa', 'empresa suspensa ainda consulta o painel (somente leitura)')
r = await A.cli.call('POST', `${base}/parcelas/${pars3[2].id}/pagamento`, { forma: 'pix', idem: 'x2' }); check(r.status === 200, 'pagamentos das parcelas em aberto continuam podendo ser registrados')
check((await notifs(A.cli)).some((t) => /Crédito da Loja suspenso/.test(t)), 'dono avisado da suspensão')
await adm.call('POST', `/api/panel/credito/empresas/${A.bid}`, { acao: 'revogar', motivo: 'Fim do piloto' })
r = await A.cli.call('PUT', `${base}/config`, { ativo: true }); check(r.status === 403, 'empresa revogada não altera regras')
await adm.call('POST', `/api/panel/credito/empresas/${A.bid}`, { acao: 'autorizar' })
r = await c1.call('GET', `${base}/opcoes`); check(r.body.disponivel === true, 'reautorizada: crédito volta ao checkout')
await adm.call('PUT', '/api/panel/credito', { ativo: false })
r = await c1.call('GET', `${base}/opcoes`); check(r.body.disponivel === false, 'ADM desliga o recurso: some para clientes')
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 2, entrada: 10, totalFinal: sM.simulacao.totalFinal, aceite: true } }); check(r.status === 403 && r.body.code === 'credito_desativado', 'recurso desligado: compra bloqueada no servidor')
await adm.call('PUT', '/api/panel/credito', { ativo: true })

console.log('\n# F3. cancelamento do pedido, concorrência e visão do cliente')
let sC = (await c1.call('POST', `${base}/simular`, { valor: 100, parcelas: 2, entrada: 10 })).body
r = await pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 2, entrada: 10, totalFinal: sC.simulacao.totalFinal, aceite: true } })
const o4 = r.body.order; check(r.status === 200 && o4.status === 'novo', 'nova compra depois de regularizar')
const u4 = (await CL.usoCliente(A.bid, c1id)).disponivel
await A.cli.call('POST', `/api/v2/ads/${A.bid}/orders/${o4.id}`, { status: 'recusado', motivo: 'Sem estoque' })
check((await one('SELECT status FROM credito_operacoes WHERE order_id = $1', [o4.id]))?.status === 'cancelada' && !(await one("SELECT id FROM credito_parcelas WHERE operacao_id = (SELECT id FROM credito_operacoes WHERE order_id = $1) AND status <> 'cancelada'", [o4.id])), 'pedido recusado pela loja: operação e parcelas canceladas')
check((await CL.usoCliente(A.bid, c1id)).disponivel === r2(u4 + 90), 'limite liberado após o cancelamento')
// concorrência: duas compras ao mesmo tempo que, juntas, passam do limite
const disp = (await CL.usoCliente(A.bid, c1id)).disponivel
await A.cli.call('PUT', `${base}/config`, { aprovacao: 'automatica' })
const valorC = Math.floor((disp * 0.7) / 100) * 100 || 100
const qtdC = Math.max(1, Math.round(valorC / 100)), sP = (await c1.call('POST', `${base}/simular`, { valor: qtdC * 100, parcelas: 2, entrada: qtdC * 10 })).body
const [ra, rb] = await Promise.all([1, 2].map(() => pedir(c1, A.bid, [{ pid: A.pids.Camisa, qtd: qtdC }], { credito: { parcelas: 2, entrada: qtdC * 10, totalFinal: sP.simulacao.totalFinal, aceite: true } })))
check([ra, rb].filter((x) => x.status === 200).length === 1 && [ra, rb].some((x) => x.body.code === 'credito_limite'), `duas compras simultâneas (R$ ${qtdC * 90} cada, R$ ${disp} disponíveis): só uma passa`, [ra.status, rb.status])
check((await CL.usoCliente(A.bid, c1id)).disponivel >= 0, 'limite nunca fica negativo')
r = await c1.call('GET', '/api/v2/credito/meu'); const lj = r.body.lojas?.[0]
check(r.body.lojas?.length === 1 && lj.businessId === A.bid && lj.operacoes.length >= 3 && lj.operacoes.every((o: any) => Array.isArray(o.parcelas)), 'cliente vê o próprio crédito: compras e parcelas')
const donos = await q(`SELECT DISTINCT user_id FROM credito_operacoes WHERE id IN (${lj.operacoes.map((o: any) => Number(o.id)).join(',')})`)
check(donos.length === 1 && Number(donos[0].user_id) === c1id && (await c2.call('GET', '/api/v2/credito/meu')).body.lojas.length === 0, 'cliente vê só as próprias compras; outro cliente não vê nada')
r = await A.cli.call('GET', `${base}/clientes/${c1id}`); check(r.status === 200 && r.body.pagamentos.length >= 6 && r.body.eventos.length > 0, 'dono consulta histórico do cliente: compras, pagamentos e eventos')
r = await A.cli.call('GET', `${base}/clientes/${c2id}`); check(r.status === 404, 'histórico só de clientes com crédito nesta empresa')
r = await A.cli.call('GET', `${base}/operacoes/${op3!.id}`); check(r.status === 200 && r.body.parcelas.length === 5 && r.body.eventos.some((e: any) => e.tipo === 'solicitacao_aprovada'), 'operação individual: parcelas, pagamentos e histórico da decisão')
r = await B.cli.call('GET', `/api/v2/businesses/${B.bid}/credito/operacoes/${op3!.id}`); check(r.status === 403 || r.status === 404, 'outra empresa não abre a operação')
r = await A.cli.call('GET', `${base}/painel?de=${hoje}&ate=${hoje}`); check(r.body.relatorio.compras >= 3 && r.body.relatorio.recebido > 0 && r.body.relatorio.rejeitadas === 1, 'relatório por período', r.body.relatorio)
r = await adm.call('GET', '/api/panel/credito'); const ea = r.body.empresas.find((e: any) => e.businessId === A.bid)
check(ea && ea.situacao === 'autorizada' && ea.movimentado > 0 && ea.recebido > 0 && r.body.totais.habilitadas === 1, 'ADM vê empresas habilitadas, valores movimentados e recebidos', r.body.totais)
r = await adm.call('GET', `/api/panel/credito/relatorio?de=${hoje}&ate=${hoje}`); check(r.body.linhas.some((l: any) => l.businessId === A.bid && l.compras >= 3), 'ADM: relatório de utilização por período')
check((await one("SELECT COUNT(*) AS n FROM audit_log WHERE action LIKE 'credito.%'"))?.n >= 5, 'ações do ADM e decisões registradas na auditoria geral')


console.log('\n# G. solicitação de crédito do cliente (documentos protegidos, análise, aprovação com condições)')
const SL = await import('../src/lib/credito-solicitacoes.js')
const { deflateSync, crc32 } = await import('node:zlib')
function png(w: number, h: number) { // imagem PNG real (ruído: não comprime, como uma foto)
  const raw = Buffer.alloc((w * 3 + 1) * h); for (let i = 0; i < raw.length; i++) raw[i] = (i * 2654435761 >>> 13) & 255; for (let y = 0; y < h; y++) raw[y * (w * 3 + 1)] = 0
  const ch = (t: string, d: Buffer) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td) >>> 0); return Buffer.concat([l, td, c]) }
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2
  return 'data:image/png;base64,' + Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), ch('IHDR', ih), ch('IDAT', deflateSync(raw, { level: 1 })), ch('IEND', Buffer.alloc(0))]).toString('base64')
}
const PDF = 'data:application/pdf;base64,' + Buffer.from('%PDF-1.4\n' + '1 0 obj << /Type /Catalog >> endobj\n'.repeat(60) + 'trailer << >>\n%%EOF\n').toString('base64')
const DOC = png(1000, 640), SELFIE = png(600, 600)
const c3 = await S.novoUsuario(), c3id = await uidDe(c3)
await A.cli.call('PUT', `${base}/config`, { aprovacao: 'ate_valor' })
r = await c3.call('GET', `/api/v2/businesses/${A.bid}`); check(r.body.creditoLoja === true, 'loja anuncia que aceita solicitações de crédito')
r = await c3.call('POST', `${base}/solicitacao`); const sid = r.body.solicitacao?.id
check(r.status === 200 && r.body.solicitacao.status === 'rascunho' && r.body.faltam.length === 3 && r.body.termo.some((t: string) => /reconhecimento facial/.test(t)), 'cliente abre a solicitação (rascunho) com o termo de consentimento', r.body)
check((await c3.call('POST', `${base}/solicitacao`)).body.solicitacao.id === sid, 'abrir de novo retoma a mesma solicitação (sem duplicar)')
const SB = `/api/v2/credito/solicitacoes/${sid}`
const dadosOk = { nome: 'Carla Souza Lima', cpf: '529.982.247-25', telefone: '(11) 98888-1234', email: 'carla@exemplo.com', nascimento: '1990-05-10', limiteSolicitado: 400, parcelasDesejadas: 3, mensagem: 'Compro todo mês.' }
r = await c3.call('PUT', `${SB}/dados`, { ...dadosOk, cpf: '111.111.111-11' }); check(r.status === 400 && r.body.field === 'cpf' || /CPF/.test(r.body.error), 'CPF inválido recusado', r.body)
r = await c3.call('PUT', `${SB}/dados`, { ...dadosOk, nascimento: '2015-01-01' }); check(r.status === 400 && /18 anos/.test(r.body.error), 'menor de idade recusado')
r = await c3.call('PUT', `${SB}/dados`, { ...dadosOk, nome: 'Carla' }); check(r.status === 400 && /nome completo/.test(r.body.error), 'nome incompleto recusado')
r = await c3.call('PUT', `${SB}/dados`, { ...dadosOk, limiteSolicitado: 99999 }); check(r.status === 400, 'limite pedido acima do máximo da loja recusado')
r = await c3.call('PUT', `${SB}/dados`, dadosOk); check(r.status === 200, 'dados cadastrais salvos')
const sRow = await one('SELECT * FROM credito_solicitacoes WHERE id = $1', [sid])
check(String(sRow!.dados_cifrados).startsWith('v2:') && !String(sRow!.dados_cifrados).includes('52998224725') && sRow!.cpf_mascara === '***.982.247-**', 'dados cifrados no banco (CPF só mascarado em claro)')
r = await c3.call('POST', `${SB}/enviar`, { consentimento: true }); check(r.status === 400 && r.body.code === 'documentos', 'sem documentos a solicitação não é enviada')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'documento', arquivo: 'data:text/plain;base64,' + Buffer.from('oi').toString('base64') }); check(r.status === 400, 'formato não aceito recusado')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'documento', arquivo: 'data:image/png;base64,' + Buffer.from('não é imagem').toString('base64') }); check(r.status === 400 && r.body.code === 'formato', 'arquivo que não é imagem de verdade (só o nome) recusado')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'documento', arquivo: png(300, 200) }); check(r.status === 400 && r.body.code === 'ilegivel', 'imagem pequena demais para leitura recusada')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'selfie', arquivo: PDF }); check(r.status === 400 && /selfie/i.test(r.body.error), 'selfie em PDF recusada')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'comprovante', arquivo: 'data:application/pdf;base64,' + Buffer.alloc(1_520_000, 65).toString('base64') }); check(r.status === 400 && r.body.code === 'arquivo_grande', 'arquivo acima do tamanho máximo recusado', r.body)
for (const [tipo, arq] of [['documento', DOC], ['comprovante', PDF], ['selfie', SELFIE]] as const) { r = await c3.call('POST', `${SB}/documentos`, { tipo, arquivo: arq }); check(r.status === 200, `${tipo} enviado`, r.body) }
const docRow = await one("SELECT * FROM credito_documentos WHERE solicitacao_id = $1 AND tipo = 'documento' AND excluido_em IS NULL", [sid])
check(String(docRow!.conteudo).startsWith('v2:') && docRow!.largura === 1000 && docRow!.altura === 640 && docRow!.mime === 'image/png', 'documento cifrado no banco, com formato e dimensões conferidos pelo conteúdo')
r = await c3.call('GET', SB); check(r.body.faltam.length === 0 && r.body.dados.cpf === '52998224725' && r.body.documentos.every((d: any) => /exp=\d+&sig=/.test(d.url)), 'revisão: o cliente vê os próprios dados e documentos (endereços temporários)')
r = await c3.call('POST', `${SB}/enviar`, {}); check(r.status === 400 && r.body.code === 'consentimento', 'sem consentimento não envia')
r = await c3.call('POST', `${SB}/enviar`, { consentimento: true }); check(r.status === 200 && r.body.status === 'pendente', 'solicitação enviada com consentimento')
check((await one('SELECT consentimento_versao FROM credito_solicitacoes WHERE id = $1', [sid]))?.consentimento_versao === SL.CONSENTIMENTO_VERSAO, 'versão e data do consentimento registradas')
check((await notifs(c3)).some((t) => /Solicitação de crédito recebida/.test(t)) && (await notifs(A.cli)).some((t) => /Nova solicitação de crédito/.test(t)), 'cliente e loja avisados do recebimento')
r = await c3.call('PUT', `${SB}/dados`, dadosOk); check(r.status === 400, 'depois de enviada, o cliente não altera a solicitação em análise')
// cliente com histórico (c1) também pede aumento
const s1 = (await c1.call('POST', `${base}/solicitacao`)).body.solicitacao.id
await c1.call('PUT', `/api/v2/credito/solicitacoes/${s1}/dados`, { ...dadosOk, nome: 'Pessoa Sonda Um', cpf: '168.995.350-09', limiteSolicitado: 800 })
for (const [tipo, arq] of [['documento', DOC], ['comprovante', DOC], ['selfie', SELFIE]] as const) await c1.call('POST', `/api/v2/credito/solicitacoes/${s1}/documentos`, { tipo, arquivo: arq })
check((await c1.call('POST', `/api/v2/credito/solicitacoes/${s1}/enviar`, { consentimento: true })).status === 200, 'cliente com histórico envia pedido de aumento')

console.log('\n# G2. análise pela empresa: histórico real e documentos protegidos')
r = await A.cli.call('GET', `${base}/pedidos-limite?status=pendente`); check(r.body.contagem?.pendente === 2 && r.body.solicitacoes.every((x: any) => x.status === 'pendente'), 'painel lista as solicitações pendentes com contagem por status', r.body)
const det = (await A.cli.call('GET', `${base}/pedidos-limite/${sid}`)).body
check(det.dados?.cpf === '52998224725' && det.dados?.nome === 'Carla Souza Lima' && det.solicitacao.limiteSolicitado === 400, 'empresa vê os dados cadastrais e o limite pedido')
check(det.relacionamentoAtual.semCompras === true && det.relacionamentoAtual.compras === 0 && det.relacionamentoAtual.valorTotal === 0 && det.relacionamentoAtual.primeiraCompra === null, 'cliente sem compras: indicado claramente, sem números inventados')
const det1 = (await A.cli.call('GET', `${base}/pedidos-limite/${s1}`)).body, R1 = det1.relacionamentoAtual
const ordsC1 = await q("SELECT status, total FROM orders WHERE business_id = $1 AND customer_id = $2 AND status NOT IN ('aguardando_pagamento','aguardando_credito','cancelado','recusado')", [A.bid, c1id])
const cancC1 = Number((await one("SELECT COUNT(*) AS n FROM orders WHERE business_id = $1 AND customer_id = $2 AND status IN ('cancelado','recusado')", [A.bid, c1id]))?.n)
check(R1.semCompras === false && R1.compras === ordsC1.length && R1.valorTotal === r2(ordsC1.reduce((a: number, o: any) => a + Number(o.total), 0)) && R1.cancelados === cancC1 && R1.concluidos === ordsC1.filter((o: any) => o.status === 'concluido').length && !!R1.primeiraCompra && !!R1.ultimaCompra, 'histórico real: compras, valor total, concluídos, cancelados, primeira e última compra (conferidos no banco)', { R1, n: ordsC1.length, cancC1 })
check(R1.credito && R1.credito.pago > 0 && R1.credito.compras >= 1, 'histórico inclui o crédito e os pagamentos já registrados nesta loja')
const urlDoc = det.documentos.find((d: any) => d.tipo === 'documento').url
r = await A.cli.call('GET', urlDoc); check(r.status === 200 && typeof r.body === 'string', 'dono abre o documento pelo endereço temporário')
r = await B.cli.call('GET', urlDoc); check(r.status === 403 || r.status === 404, 'dono de outra empresa não abre o documento com o mesmo endereço')
r = await c2.call('GET', urlDoc); check(r.status === 403 || r.status === 404, 'outro cliente não abre o documento')
r = await new S.Cli().call('GET', urlDoc); check(r.status === 401, 'sem sessão o documento não abre (não há URL pública)')
r = await A.cli.call('GET', urlDoc.replace(/sig=[^&]+/, 'sig=xxxx')); check(r.status === 403, 'assinatura adulterada recusada')
r = await A.cli.call('GET', urlDoc.replace(/exp=\d+/, 'exp=' + (Math.floor(Date.now() / 1000) - 10))); check(r.status === 403, 'endereço vencido recusado')
r = await c3.call('GET', (await c3.call('GET', SB)).body.documentos[0].url); check(r.status === 200, 'o próprio cliente consegue rever o documento')
r = await B.cli.call('GET', `/api/v2/businesses/${A.bid}/credito/pedidos-limite/${sid}`); check(r.status === 404, 'outra empresa não vê a solicitação')
r = await c2.call('GET', SB); check(r.status === 404, 'outro cliente não vê a solicitação')
check(Number((await one("SELECT COUNT(*) AS n FROM credito_eventos WHERE tipo = 'documento_visualizado' AND business_id = $1", [A.bid]))?.n) >= 2 && Number((await one("SELECT COUNT(*) AS n FROM audit_log WHERE action = 'credito.documento.visualizado'"))?.n) >= 1, 'cada visualização de documento registrada (histórico e auditoria)')
check(!JSON.stringify((await A.cli.call('GET', `${base}/painel`)).body).includes('52998224725'), 'CPF e documentos não aparecem no painel geral nem em outras listas')

console.log('\n# G3. pedir informações, recusar e aprovar com condições')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/nota`, { texto: 'Conferir comprovante em nome da mãe.' }); check(r.status === 200 && r.body.notas.length === 1, 'observação interna registrada')
check(!JSON.stringify((await c3.call('GET', SB)).body).includes('nome da mãe'), 'observações internas não aparecem para o cliente')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/info`, { mensagem: 'Envie um comprovante de endereço em seu nome.' }); check(r.status === 200 && r.body.status === 'info_solicitada', 'empresa pede informações adicionais')
check((await notifs(c3)).some((t) => /pediu mais informações/.test(t)) && (await c3.call('GET', SB)).body.solicitacao.pedidoInfo.includes('em seu nome'), 'cliente avisado e vê o que a loja pediu')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/aprovar`, { limite: 300 }); check(r.status === 409, 'sem a resposta do cliente não dá para decidir')
r = await c3.call('POST', `${SB}/documentos`, { tipo: 'comprovante', arquivo: DOC }); check(r.status === 200, 'cliente troca o comprovante')
check(Number((await one("SELECT COUNT(*) AS n FROM credito_documentos WHERE solicitacao_id = $1 AND tipo = 'comprovante' AND excluido_em IS NULL", [sid]))?.n) === 1 && (await one("SELECT conteudo FROM credito_documentos WHERE solicitacao_id = $1 AND tipo = 'comprovante' AND excluido_em IS NOT NULL", [sid]))?.conteudo === '', 'o comprovante anterior é apagado (não fica cópia)')
r = await c3.call('POST', `${SB}/enviar`, { consentimento: true }); check(r.status === 200 && r.body.status === 'pendente', 'cliente reenvia: volta para análise')
check((await notifs(A.cli)).some((t) => /Cliente respondeu/.test(t)), 'loja avisada da resposta')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/aprovar`, { limite: 5000 }); check(r.status === 400, 'limite acima do máximo da loja/ADM recusado')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/aprovar`, { limite: 300, condicoes: { jurosTipo: 'mensal', taxa: 9 } }); check(r.status === 400 && /5%/.test(r.body.error), 'juros acima do teto do ADM recusados na aprovação')
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/aprovar`, { limite: 300, validade: '2020-01-01' }); check(r.status === 400, 'validade no passado recusada')
const validade = new Date(Date.now() + 180 * 864e5).toISOString().slice(0, 10)
r = await A.cli.call('POST', `${base}/pedidos-limite/${sid}/aprovar`, { limite: 300, validade, condicoes: { parcelas: [2, 3], jurosTipo: 'sem', entradaMinPct: 0, intervaloDias: 30, condicoesCliente: 'Pagamento no balcão.' } })
check(r.status === 200 && r.body.status === 'aprovada' && r.body.cliente.limite === 300 && r.body.cliente.disponivel === 300, 'aprovada: limite de R$ 300 liberado', r.body)
const cc3 = await one('SELECT * FROM credito_clientes WHERE business_id = $1 AND user_id = $2', [A.bid, c3id])
check(cc3 && Number(cc3.solicitacao_id) === sid && cc3.validade === validade && J<any>(cc3.condicoes, {}).jurosTipo === 'sem', 'limite gravado no MESMO cadastro de limites do Crédito da Loja, com condições, validade e origem')
check(Number((await one('SELECT COUNT(*) AS n FROM credito_clientes WHERE user_id = $1', [c3id]))?.n) === 1, 'limite vinculado só a esta empresa (nenhum outro registro criado)')
check((await notifs(c3)).some((t) => /Crédito aprovado · Moda Ana/.test(t)), 'cliente avisado da aprovação com as condições')
r = await c3.call('GET', `${base}/opcoes?valor=100`); check(r.body.disponivel === true && r.body.parcelas.join() === '2,3' && r.body.jurosTipo === 'sem' && r.body.entradaMinPct === 0 && r.body.condicoesCliente === 'Pagamento no balcão.', 'checkout usa as condições aprovadas para este cliente', r.body)
const sim3c = (await c3.call('POST', `${base}/simular`, { valor: 100, parcelas: 3 })).body
check(sim3c.simulacao.juros === 0 && sim3c.simulacao.entrada === 0 && sim3c.termos.some((t: string) => /Pagamento no balcão/.test(t)), 'simulação sem juros e sem entrada, com as condições do cliente nos termos')
r = await pedir(c3, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 0, totalFinal: sim3c.simulacao.totalFinal, aceite: true } })
check(r.status === 200 && r.body.order.status === 'novo', 'cliente aprovado compra a crédito')
check(Number((await one('SELECT COUNT(*) AS n FROM credito_parcelas WHERE operacao_id = (SELECT id FROM credito_operacoes WHERE order_id = $1)', [r.body.order.id]))?.n) === 3, 'parcelamento gerado (3 parcelas, sem entrada)')
check((await CL.usoCliente(A.bid, c3id)).disponivel === 200, 'limite consumido pela compra')
await adm.call('POST', `/api/panel/credito/empresas/${B.bid}`, { acao: 'autorizar' }); await B.cli.call('PUT', `/api/v2/businesses/${B.bid}/credito/config`, { ativo: true, parcelas: [2] })
r = await c3.call('GET', `/api/v2/businesses/${B.bid}/credito/opcoes`); check(r.body.disponivel === false, 'o limite aprovado pela empresa A não vale na empresa B')
r = await A.cli.call('POST', `${base}/pedidos-limite/${s1}/recusar`, {}); check(r.status === 400, 'recusar exige motivo')
r = await A.cli.call('POST', `${base}/pedidos-limite/${s1}/recusar`, { motivo: 'Limite atual já é adequado.' }); check(r.status === 200, 'empresa recusa a solicitação')
check((await notifs(c1)).some((t) => /Solicitação de crédito não aprovada/.test(t)) && (await c1.call('GET', '/api/v2/credito/solicitacoes')).body.solicitacoes.some((x: any) => x.id === s1 && x.status === 'recusada' && /adequado/.test(x.decisao?.motivo)), 'cliente avisado da recusa e acompanha o status')
check((await CL.usoCliente(A.bid, c1id)).limite === 600, 'recusa não mexe no limite atual')
r = await A.cli.call('GET', `${base}/pedidos-limite`); check(r.body.contagem.aprovada === 1 && r.body.contagem.recusada === 1, 'painel organizado por status (aprovadas e recusadas)')

console.log('\n# G4. validade, retenção e exclusão dos documentos')
await q('UPDATE credito_clientes SET validade = $1 WHERE business_id = $2 AND user_id = $3', [new Date(Date.now() - 2 * 864e5).toISOString().slice(0, 10), A.bid, c3id])
r = await c3.call('GET', `${base}/opcoes`); check(r.body.disponivel === false && /venceu/.test(r.body.motivo) && r.body.podeSolicitar === true, 'limite vencido: some do checkout e o cliente pode pedir renovação')
r = await pedir(c3, A.bid, [{ pid: A.pids.Camisa, qtd: 1 }], { credito: { parcelas: 3, entrada: 0, totalFinal: sim3c.simulacao.totalFinal, aceite: true } }); check(r.status === 403 && r.body.code === 'credito_expirado', 'compra com limite vencido bloqueada no servidor')
await q("UPDATE credito_solicitacoes SET decidido_em = $1 WHERE id = $2", [new Date(Date.now() - 100 * 864e5).toISOString(), s1])
await SL.tickRetencao(new Date(), true)
check(!(await one("SELECT id FROM credito_documentos WHERE solicitacao_id = $1 AND (excluido_em IS NULL OR conteudo <> '')", [s1])) && !!(await one("SELECT id FROM credito_eventos WHERE tipo = 'documentos_excluidos_retencao'")), 'retenção: documentos apagados depois do prazo (fica só o histórico)')
check(!!(await one("SELECT id FROM credito_documentos WHERE solicitacao_id = $1 AND excluido_em IS NULL", [sid])), 'documentos ainda dentro do prazo continuam guardados')
const sC2 = (await c2.call('POST', `${base}/solicitacao`)).body.solicitacao.id
await c2.call('POST', `/api/v2/credito/solicitacoes/${sC2}/documentos`, { tipo: 'selfie', arquivo: SELFIE })
r = await c2.call('POST', `/api/v2/credito/solicitacoes/${sC2}/cancelar`, {}); check(r.status === 200 && !(await one("SELECT id FROM credito_documentos WHERE solicitacao_id = $1 AND conteudo <> ''", [sC2])), 'cliente cancela e os documentos são apagados na hora')
r = await c3.call('POST', `${SB}/cancelar`, { apagarDocumentos: true }); check(r.status === 200 && !(await one("SELECT id FROM credito_documentos WHERE solicitacao_id = $1 AND conteudo <> ''", [sid])) && (await one('SELECT status FROM credito_solicitacoes WHERE id = $1', [sid]))?.status === 'aprovada', 'cliente aprovado apaga os documentos a qualquer momento (o limite continua)')
r = await A.cli.call('GET', urlDoc); check(r.status === 404, 'documento apagado não abre mais')
console.log(`\n${ok}/${ok + falhas} verificações${falhas ? '\nFALHAS:\n - ' + erros.join('\n - ') : ''}`)
await S.fechar(); process.exit(falhas ? 1 : 0)
