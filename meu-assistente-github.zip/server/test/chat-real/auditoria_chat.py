# Auditoria do CHAT REAL: servidor real, banco real, Cérebro Central (biblioteca) real, ferramentas reais e o endpoint /api/chat.
# Só o modelo de linguagem é o substituto (modelo_substituto.py), porque o ambiente não tem acesso a provedores de IA.
# Servidor:  python3 test/chat-real/modelo_substituto.py 4390 /tmp/ia_log.jsonl &
#            E2E_AI_URL=http://127.0.0.1:4390/v1 PORT=4330 SQLITE_FILE=/tmp/ma-chat.db npx tsx test/serve-sqlite.ts   (banco novo)
# Saída: cada pergunta, a resposta do chat, o caminho e as verificações; resumo em /tmp/auditoria_chat.json
import json, re, sqlite3, sys, uuid, datetime, requests
BASE = 'http://localhost:4330'; IA = 'http://127.0.0.1:4390'; DBF = '/tmp/ma-chat.db'; LOG = '/tmp/ia_log.jsonl'
PW = 'Senha@Forte123'; res = []
def conta(nome, email, zap, ip):
    s = requests.Session(); s.headers['X-Forwarded-For'] = ip
    r = s.post(BASE + '/api/auth', json={'action': 'signup', 'name': nome, 'whatsapp': zap, 'email': email, 'birthday': '1990-01-01', 'password': PW, 'passwordConfirm': PW}); assert r.ok, r.text
    return s
def modo(m): requests.post(IA + '/__modo', json={'modo': m})
def log_n():
    try: return sum(1 for _ in open(LOG))
    except FileNotFoundError: return 0
def ultimas_reqs(desde):
    try: linhas = open(LOG).read().splitlines()[desde:]
    except FileNotFoundError: return []
    return [json.loads(l) for l in linhas]
TECNICO = re.compile(r'```|\{\s*"|"name"\s*:|"arguments"|<tool_call>|</?function|\[C\d+\]|⟦(?!appt:|fin:|ad:|btn:|mod:|emp:)|tool_call|create_[a-z]+|register_transaction|\bnull\b|\btrue\b|\bfalse\b')
def visivel(t): return re.sub(r'⟦[^⟧]*⟧', '', t or '').strip()
def checa(nome, ok, det=''):
    res.append({'teste': nome, 'ok': bool(ok), 'detalhe': det}); print(('  ✔ ' if ok else '  ✘ ') + nome + ('' if ok else '  → ' + str(det)[:400]))

def main(rodada):
    admin = conta('Admin Auditoria', 'admin.aud@t.com', '+55 85 94444-0001', '10.0.0.1')
    assert admin.put(BASE + '/api/panel/modules', json={'agente': True, 'catalogo': True, 'empresas': True}).ok
    # ---------- Biblioteca do Cérebro Central (pela API real do painel) ----------
    DOCS = [
        ('Política de trocas e devoluções', 'O cliente pode pedir a troca ou a devolução em até 7 dias corridos após o recebimento do produto. Produtos personalizados ou feitos sob medida não têm troca, exceto em caso de defeito. O reembolso é feito em até 10 dias úteis, pelo mesmo meio de pagamento usado na compra. Para pedir, o cliente fala com a loja pelo chat do pedido.'),
        ('Como funcionam as MCoins', 'MCoins são moedas digitais de bônus que as empresas parceiras oferecem aos clientes. Cada MCoin vale R$ 0,10 de desconto no checkout da empresa que a emitiu. As MCoins expiram 12 meses depois de recebidas. Elas não podem ser trocadas por dinheiro.'),
        ('Horário de atendimento do suporte', 'O suporte do Meu Assistente atende de segunda a sexta-feira, das 8h às 18h, e aos sábados, das 9h às 13h. O atendimento é feito pelo chat do aplicativo e pelo e-mail suporte@meuassistente.chat. Domingos e feriados não têm atendimento.'),
        ('Planos de anúncio para empresas', 'O plano Básico custa R$ 19,90 por mês e mostra a empresa na busca do chat. O plano Página custa R$ 29,90 por mês e inclui uma página própria. O plano Loja completa custa R$ 49,90 por mês e inclui catálogo, pedidos e agendamentos. Todos podem ser cancelados a qualquer momento.'),
        ('Guia de cadastro de produtos', 'Para cadastrar um produto, abra Sua empresa e toque em Produtos. Preencha o nome do produto com até 80 caracteres. Informe o preço em reais. Escolha uma categoria existente ou crie uma nova. Envie pelo menos uma foto do produto. As fotos podem ter até 600 KB cada. Você pode adicionar variações de cor, tamanho e modelo. Cada variação pode ter preço, foto e estoque próprios. Ofertas podem ser definidas no produto ou em cada variação. O produto pode ser pausado a qualquer momento pelo interruptor. Produtos pausados não aparecem na vitrine. Excluir um produto pede confirmação.'),
    ]
    ids = {}
    for t, c in DOCS:
        r = admin.post(BASE + '/api/brain/knowledge', json={'titulo': t, 'conteudo': c, 'status': 'aprovado'}); assert r.ok, r.text; ids[t] = r.json()['id']
    # rascunho NÃO aprovado: não pode ser usado nas respostas
    r = admin.post(BASE + '/api/brain/knowledge', json={'titulo': 'Promoção de Natal dos planos', 'conteudo': 'Rascunho: desconto de 50% em todos os planos de anúncio até 31 de dezembro, com o cupom NATAL50.', 'status': 'pendente'}); assert r.ok, r.text
    cli = conta('Carla Teste', 'carla.aud@t.com', '+55 85 94444-0002', '10.0.0.2')
    conv = str(uuid.uuid4())
    def chat(texto, nova=False):
        nonlocal conv
        if nova: conv = str(uuid.uuid4())
        n0 = log_n(); r = cli.post(BASE + '/api/chat', json={'text': texto, 'conversationId': conv}, timeout=90)
        assert r.ok, r.text
        j = r.json(); c = j['assistantMessage']['content']
        reqs = [x for x in ultimas_reqs(n0) if 'Você é o "Meu Assistente"' in str((x['req'].get('messages') or [{}])[0].get('content') or '')]
        print(f'\n> {texto}\n< {visivel(c)}' + (f'   [IA chamada {len(reqs)}x]' if reqs else '   [sem IA]'))
        return c, reqs
    print('\n=== 1. Perguntas sobre a Biblioteca (modo normal) ===')
    modo('normal')
    perguntas = [
        ('Qual o prazo para trocar um produto?', ['7 dias'], 'Política de trocas'),
        ('Comprei uma coisa e não gostei, consigo devolver?', ['7 dias'], 'Política de trocas'),
        ('Em quanto tempo cai o reembolso?', ['10 dias úteis'], 'Política de trocas'),
        ('Quanto vale uma MCoin?', ['0,10'], 'MCoins'),
        ('As moedas de bônus vencem?', ['12 meses'], 'MCoins'),
        ('Que horas o suporte atende no sábado?', ['9h', '13h'], 'Horário'),
        ('Quanto custa o plano loja completa?', ['49,90'], 'Planos'),
        ('Como cadastro um produto?', ['Produtos'], 'Guia'),
    ]
    for p, esperados, tema in perguntas:
        c, reqs = chat(p, nova=True)
        v = visivel(c)
        ctx_ok = any(tema.split()[0] in x['req']['messages'][0]['content'] for x in reqs) if reqs else None
        checa(f'"{p}" → baseada na Biblioteca ({", ".join(esperados)})', all(e in v for e in esperados), v)
        checa(f'"{p}" → sem estruturas técnicas', not TECNICO.search(v), TECNICO.search(v) and TECNICO.search(v).group(0))
        checa(f'"{p}" → curta (≤ 600 caracteres)', len(v) <= 600, len(v))
        if reqs: checa(f'"{p}" → o modelo recebeu o conhecimento certo no contexto', ctx_ok, [x['req']['messages'][0]['content'][-600:] for x in reqs][:1])
    print('\n=== 2. Sem invenção ===')
    c, _ = chat('Tem promoção de Natal nos planos?', nova=True); v = visivel(c)
    checa('rascunho NÃO aprovado não é usado (sem "50%" / "NATAL50")', '50%' not in v and 'NATAL50' not in v, v)
    c, _ = chat('Qual é a capital da Mongólia?', nova=True); v = visivel(c)
    checa('assunto fora da Biblioteca: não inventa', 'Ulaanbaatar' not in v and 'Ulan' not in v and len(v) < 400 and not TECNICO.search(v), v)
    c, _ = chat('Oi, tudo bem?', nova=True); v = visivel(c)
    checa('saudação: resposta natural e curta', 0 < len(v) < 300 and not TECNICO.search(v), v)
    print('\n=== 3. Ações reais (agendamento, lembrete, finanças, tarefa, agenda) ===')
    uid = sqlite3.connect(DBF).execute("select id from users where email='carla.aud@t.com'").fetchone()[0]
    def itens(kind): return sqlite3.connect(DBF).execute('select data, day from items where user_id=? and type=? order by id', (uid, kind)).fetchall()
    amanha = (datetime.date.today() + datetime.timedelta(days=1)).isoformat()
    n = len(itens('reminder')); c, _ = chat('Me lembra de tomar o remédio às 15h', nova=True); v = visivel(c)
    rr = itens('reminder'); checa('lembrete pela frase → criado no banco (remédio, 15:00) e confirmado sem repetir o comando', len(rr) == n + 1 and json.loads(rr[-1][0]).get('message') == 'tomar o remédio' and '15:00' in v and 'Me lembra' not in v and not TECNICO.search(v), (rr[-1:] , v))
    n = len(itens('appointment')); c, _ = chat('Agendar dentista amanhã às 10h', nova=True); v = visivel(c)
    ap = itens('appointment'); checa('agendamento → compromisso criado amanhã às 10:00 e confirmado', len(ap) == n + 1 and 'entista' in ap[-1][0] and ap[-1][1] == amanha and '10:00' in ap[-1][0] and not TECNICO.search(v), (ap[-1:], v))
    n = len(itens('expense')); c, _ = chat('Gastei 50 reais no mercado', nova=True); v = visivel(c)
    ex = itens('expense'); checa('gasto → lançamento de R$ 50 no banco e confirmado', len(ex) == n + 1 and '"amount": 50' in ex[-1][0].replace(':50', ': 50') and not TECNICO.search(v), (ex[-1:], v))
    n = len(itens('task')); c, reqs = chat('Cria uma tarefa de revisar o contrato do aluguel', nova=True); v = visivel(c)
    tk = itens('task'); checa('tarefa → criada no banco e confirmada', len(tk) == n + 1 and 'contrato' in tk[-1][0] and not TECNICO.search(v), (tk[-1:], v))
    n = len(itens('reminder')); c, _ = chat('Pode me avisar amanhã às 8h30 para ligar para a Ana?', nova=True); v = visivel(c)
    rr = itens('reminder'); checa('lembrete pedido de outro jeito → criado amanhã 08:30', len(rr) == n + 1 and '08:30' in rr[-1][0] and 'Ana' in rr[-1][0] and not TECNICO.search(v), (rr[-1:], v))
    depois = (datetime.date.today() + datetime.timedelta(days=2)).isoformat()
    for frase, dia, hora, txt in [('Me lembre de pagar a conta de luz amanhã às 20h', amanha, '20:00', 'pagar a conta de luz'), ('Me lembra de buscar as crianças depois de amanhã às 17h', depois, '17:00', 'buscar as crianças'), ('Você pode me lembrar que tenho que ligar pro banco hoje às 23h?', datetime.date.today().isoformat(), '23:00', 'ligar pro banco')]:
        n = len(itens('reminder')); c, _ = chat(frase, nova=True); v = visivel(c); rr = itens('reminder')
        d = json.loads(rr[-1][0]) if len(rr) == n + 1 else {}
        checa(f'lembrete "{frase}" → dia {dia} {hora}, texto limpo, confirmação certa', d.get('date') == dia and d.get('time') == hora and txt in d.get('message', '') and not re.search(r'(?i)lembr|amanh|hoje', d.get('message', '')) and not re.search(r'(?i)de me lembr|amanhã hoje', v), (d, v))
    for frase, dia, hora, tit in [('Marcar reunião com o João depois de amanhã às 14h', depois, '14:00', 'João'), ('Tenho consulta médica amanhã às 9h30', amanha, '09:30', 'onsulta')]:
        n = len(itens('appointment')); c, _ = chat(frase, nova=True); v = visivel(c); ap = itens('appointment')
        d = json.loads(ap[-1][0]) if len(ap) == n + 1 else {}
        checa(f'compromisso "{frase}" → {dia} {hora}', len(ap) == n + 1 and ap[-1][1] == dia and hora in json.dumps(d) and tit in json.dumps(d, ensure_ascii=False) and not TECNICO.search(v), (ap[-1:], v))
    n = len(itens('expense')); c, _ = chat('Paguei 120 de internet', nova=True); v = visivel(c); ex = itens('expense')
    checa('"Paguei 120 de internet" → lançamento de R$ 120', len(ex) == n + 1 and '120' in ex[-1][0] and not TECNICO.search(v), (ex[-1:], v))
    c, _ = chat('O que tenho na agenda amanhã?', nova=True); v = visivel(c)
    checa('consulta da agenda → menciona o dentista de amanhã, sem estrutura técnica', ('entista' in v or '⟦appt' in c) and not TECNICO.search(v), v)
    print('\n=== 4. Defesas contra defeitos do modelo ===')
    modo('json_resposta'); c, _ = chat('Quanto vale uma MCoin?', nova=True); v = visivel(c)
    checa('modelo responde em JSON → usuário vê só o texto', '0,10' in v and not TECNICO.search(v), v)
    modo('citacao'); c, _ = chat('Que horas o suporte atende no sábado?', nova=True); v = visivel(c)
    checa('modelo cita [C1] → marcador removido', '9h' in v and not TECNICO.search(v), v)
    modo('despejo'); c, _ = chat('Posso pausar um produto?', nova=True); v = visivel(c)
    checa('modelo despeja o documento inteiro → resposta curta', len(v) <= 600 and 'paus' in v.lower() and not TECNICO.search(v), (len(v), v))
    modo('inventa'); c, _ = chat('Em quanto tempo cai o reembolso?', nova=True); v = visivel(c)
    checa('modelo inventa telefone/prazo fora da Biblioteca → não chega ao usuário', '10 dias úteis' in v and '4002' not in v and '90 dias' not in v, v)
    n = len(itens('task')); modo('ferramenta_em_texto'); c, _ = chat('Cria uma tarefa de pagar o IPTU', nova=True); v = visivel(c)
    tk = itens('task'); checa('modelo escreve a chamada de ferramenta como texto (```json```) → ação executada de verdade, sem JSON visível', len(tk) == n + 1 and 'IPTU' in tk[-1][0] and not TECNICO.search(v), (tk[-1:], v))
    n = len(itens('task')); modo('tag_tool_call'); c, _ = chat('Cria uma tarefa de renovar a CNH', nova=True); v = visivel(c)
    tk = itens('task'); checa('modelo usa <tool_call> no texto → ação executada, sem tag visível', len(tk) == n + 1 and 'CNH' in tk[-1][0] and not TECNICO.search(v), (tk[-1:], v))
    modo('normal')
    print('\n=== 5. Contexto da conversa ===')
    c, _ = chat('Qual o prazo para trocar um produto?', nova=True)
    c, _ = chat('E se for personalizado?'); v = visivel(c)
    checa('pergunta de continuação usa o contexto (personalizado não tem troca)', 'personaliz' in v.lower() and ('não' in v.lower() or 'nao' in v.lower()) and not TECNICO.search(v), v)
    ok = sum(1 for r in res if r['ok']); print(f'\nRodada {rodada}: {ok}/{len(res)} verificações')
    json.dump({'rodada': rodada, 'ok': ok, 'total': len(res), 'resultados': res}, open(f'/tmp/auditoria_chat_{rodada}.json', 'w'), ensure_ascii=False, indent=1)
    return ok == len(res)

if __name__ == '__main__':
    sys.exit(0 if main(sys.argv[1] if len(sys.argv) > 1 else '1') else 1)
