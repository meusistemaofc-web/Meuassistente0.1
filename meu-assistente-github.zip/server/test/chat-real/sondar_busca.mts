// Diagnóstico da busca na Biblioteca do Cérebro Central: mostra, para cada pergunta, a intenção, a pontuação de cada
// documento e o que de fato iria para a IA (com o limiar atual). Só leitura.
// Uso: SQLITE_FILE=/tmp/ma-chat.db node --experimental-sqlite --import tsx test/chat-real/sondar_busca.mts "pergunta 1" "pergunta 2"
const { createSqlite } = await import('../../src/db/sqlite.js')
const { setDb } = await import('../../src/db/index.js')
setDb(await createSqlite(process.env.SQLITE_FILE || '/tmp/ma-chat.db'))
const C = await import('../../src/ai/cerebro/central.js')
const INT = await import('../../src/ai/cerebro/integracao.js')
const cfg = await C.cfg(); console.log('limiar', cfg.limiarSuficiente)
for (const q of process.argv.slice(2)) {
  const it = INT.intencao(q)
  const d = await C.buscarDocs(q, { status: ['aprovado', 'pendente'], k: 6 })
  const r = await INT.recuperar(q, { canal: 'chat', userId: null, pesquisar: false })
  console.log('\n' + q, '| intenção:', it.intencao, '| geral:', it.geral)
  for (const x of d) console.log('   doc', x.id, x.score.toFixed(3), x.via)
  console.log('   recuperados:', r.itens.map((i: any) => `${i.titulo}(${i.relevancia.toFixed?.(2) ?? i.relevancia})`), '| resultado:', r.resultado)
}
process.exit(0)
