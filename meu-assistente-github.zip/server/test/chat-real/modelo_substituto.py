# Modelo substituto (compatível com a API OpenAI /v1/chat/completions) para auditar o chat REAL quando não há provedor de IA
# acessível (ambiente sem internet). Tudo o mais é real: servidor, banco, Cérebro Central, ferramentas e o endpoint /api/chat.
#
# • Registra cada requisição em LOG (para conferir o contexto e as ferramentas que o servidor envia ao modelo).
# • Modo "normal": comporta-se como um modelo competente — responde SÓ com o que veio no contexto do Cérebro (frases mais
#   relevantes, curto), diz que não tem a informação quando o contexto não cobre, chama as ferramentas reais para ações e
#   confirma o resultado delas.
# • Modos de falha (POST /__modo {"modo": ...}) imitam defeitos reais de modelos: resposta em JSON, chamada de ferramenta
#   escrita como texto (bloco ```json``` ou <tool_call>), citações [C1], despejo do documento inteiro e invenção de dados.
# Uso: python3 modelo_substituto.py 4390 /tmp/ia_log.jsonl
import json, re, sys, unicodedata, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 4390
LOG = sys.argv[2] if len(sys.argv) > 2 else '/tmp/ia_log.jsonl'
ESTADO = {'modo': 'normal'}
STOP = set('a o as os um uma de da do das dos e é em no na nos nas para pra por com que qual quais como quando onde quanto quantos se me te eu você voce vocês meu minha seu sua isso esse essa este esta tem ter há ha sobre ao aos à às mais muito pode posso preciso queria gostaria fala diz explica explique sabe'.split())

def nrm(t): return unicodedata.normalize('NFD', str(t).lower()).encode('ascii', 'ignore').decode()
def toks(t): return [w for w in re.findall(r'[a-z0-9]+', nrm(t)) if len(w) > 2 and w not in STOP]
def stem(w): return w[:-1] if len(w) > 4 and w.endswith('s') else w
def frases(t): return [f.strip() for f in re.split(r'(?<=[.!?])\s+|\n+', t) if len(f.strip()) > 3]

def contexto_cerebro(system):
    i = system.find('Conhecimentos do Cérebro Central')
    if i < 0: return []
    blocos = re.split(r'\n(?=\[C\d+\] )', system[i:])
    out = []
    for b in blocos[1:]:
        cab, _, corpo = b.partition('\n')
        titulo = re.sub(r'^\[C\d+\]\s*', '', cab).split(' — ')[0].strip()
        corpo = re.split(r'\nFontes:', corpo)[0]
        # termina no próximo bloco de outra seção do system (linhas que não pertencem ao conhecimento)
        corpo = corpo.split('\nSÍNTESE')[0].strip()
        out.append({'titulo': titulo, 'corpo': corpo})
    return out

SIN = [('prazo','dias','tempo','quando','cai','demora'), ('vencem','vence','expiram','expira','validade'), ('devolver','devolucao','reembolso','troca','trocar'), ('custa','preco','valor','custo'), ('atende','atendimento','horario'), ('pausar','pausado','pausa','desativar')]
def expand(ws):
    out = set(ws)
    for g in SIN:
        gs = set(stem(x) for x in g)
        if out & gs: out |= gs
    return out
def resposta_conhecimento(pergunta, docs, n=2):
    q = expand(set(stem(w) for w in toks(pergunta)))
    cands = []
    for d in docs:
        tt = set(stem(w) for w in toks(d['titulo']))
        for j, f in enumerate(frases(d['corpo'])):
            ft = set(stem(w) for w in toks(f))
            s = len(q & ft) + 0.5 * len(q & tt) + (0.6 if d is docs[0] else 0)  # como um modelo: o 1º conhecimento é o mais relevante
            if s > 0: cands.append((s, -j, f, d))
    if not cands: return None
    cands.sort(key=lambda x: (-x[0], -x[1]))
    melhor = cands[0]
    if melhor[0] < 1: return None
    doc = melhor[3]
    escolhidas = [c[2] for c in cands if c[3] is doc][:n]
    return ' '.join(escolhidas)

def hoje_do(system):
    m = re.search(r'Hoje é (\d{4}-\d{2}-\d{2})', system)
    return datetime.date.fromisoformat(m.group(1)) if m else datetime.date.today()

def hora_de(t):
    m = re.search(r'(\d{1,2})(?::|h)(\d{2})?\b', t)
    if not m: return None
    return f'{int(m.group(1)):02d}:{int(m.group(2) or 0):02d}'

def data_de(t, hoje):
    s = nrm(t)
    if 'depois de amanha' in s: return (hoje + datetime.timedelta(days=2)).isoformat()
    if 'amanha' in s: return (hoje + datetime.timedelta(days=1)).isoformat()
    m = re.search(r'dia (\d{1,2})', s)
    if m:
        d = int(m.group(1)); base = hoje.replace(day=1)
        alvo = base.replace(day=d) if d >= hoje.day else (base + datetime.timedelta(days=32)).replace(day=d)
        return alvo.isoformat()
    return hoje.isoformat()

def acao(texto, nomes, system):
    s, hoje = nrm(texto), hoje_do(system)
    if re.search(r'\blembr|\bavis', s) and 'create_reminder' in nomes:
        msg = re.sub(r'^.*?(lembr\w*|avis\w*)\s+(me\s+)?(de\s+|que\s+)?', '', texto, flags=re.I)
        msg = re.sub(r'\s*(amanh[ãa]|hoje|depois de amanh[ãa]|dia \d+)?\s*(às|as|a partir das)?\s*\d{1,2}(:\d{2}|h\d{0,2})?.*$', '', msg, flags=re.I).strip(' ,.') or 'lembrete'
        return 'create_reminder', {'message': msg, 'date': data_de(texto, hoje), 'time': hora_de(texto) or '09:00'}
    if re.search(r'\b(agend|marc)\w*', s) and 'create_appointment' in nomes:
        tit = re.sub(r'^.*?\b(agend\w*|marc\w*)\s+(um\s+|uma\s+|o\s+|a\s+)?', '', texto, flags=re.I)
        tit = re.sub(r'\s*(para\s+|pra\s+)?(amanh[ãa]|hoje|depois de amanh[ãa]|dia \d+).*$', '', tit, flags=re.I).strip(' ,.') or 'Compromisso'
        a = {'title': tit[:1].upper() + tit[1:], 'date': data_de(texto, hoje)}
        h = hora_de(texto)
        if h: a['time'] = h
        return 'create_appointment', a
    if re.search(r'\btarefa\b', s) and 'create_task' in nomes:
        tit = re.sub(r'^.*?\btarefa\b\s*(de\s+|para\s+|:)?\s*', '', texto, flags=re.I).strip(' ,.') or 'Tarefa'
        return 'create_task', {'title': tit}
    if re.search(r'\banot', s) and 'create_note' in nomes:
        return 'create_note', {'content': re.sub(r'^.*?\banot\w*\s*(a[ií]|que)?\s*:?\s*', '', texto, flags=re.I).strip()}
    if re.search(r'\b(minha agenda|meus compromissos|o que tenho)\b', s) and 'get_agenda' in nomes:
        return 'get_agenda', {}
    return None

def confirmar(msgs):
    # última chamada do assistente + resultado das ferramentas
    calls = {}
    for m in msgs:
        if m.get('role') == 'assistant' and m.get('tool_calls'):
            for c in m['tool_calls']: calls[c['id']] = c
    partes = []
    for m in msgs:
        if m.get('role') != 'tool': continue
        c = calls.get(m.get('tool_call_id'), {}); nome = c.get('function', {}).get('name', '')
        try: a = json.loads(c.get('function', {}).get('arguments') or '{}')
        except Exception: a = {}
        try: r = json.loads(m.get('content') or '{}')
        except Exception: r = {}
        ok = not (isinstance(r, dict) and r.get('ok') is False)
        if not ok: partes.append('Não consegui concluir: ' + str(r.get('error') or r.get('message') or 'houve um problema.')); continue
        dd = '/'.join(reversed(a.get('date', '').split('-'))) if a.get('date') else ''
        if nome == 'create_reminder': partes.append(f"Pronto! Vou te lembrar de {a.get('message')} em {dd} às {a.get('time')}.")
        elif nome == 'create_appointment': partes.append(f"Agendado: {a.get('title')} em {dd}" + (f" às {a.get('time')}" if a.get('time') else '') + '.')
        elif nome == 'create_task': partes.append(f"Tarefa criada: {a.get('title')}.")
        elif nome == 'create_note': partes.append('Anotado!')
        elif nome == 'get_agenda':
            itens = (r.get('items') or r.get('itens') or r.get('appointments') or []) if isinstance(r, dict) else []
            partes.append(f'Você tem {len(itens)} compromisso(s) no período.' if itens else 'Sua agenda está livre no período.')
        else: partes.append('Pronto!')
    return ' '.join(partes) or 'Pronto!'

def responder(body):
    msgs = body.get('messages') or []
    system = next((m.get('content') or '' for m in msgs if m.get('role') == 'system'), '')
    principal = 'Você é o "Meu Assistente"' in system
    tools = body.get('tools') or []
    nomes = {t['function']['name'] for t in tools if t.get('function')}
    ultima = msgs[-1] if msgs else {}
    if not principal:
        # chamadas auxiliares (classificação, revisão, agentes): resposta neutra e curta
        return {'role': 'assistant', 'content': 'OK'}
    if ultima.get('role') == 'tool':
        return {'role': 'assistant', 'content': confirmar(msgs)}
    texto = ultima.get('content') or ''
    modo = ESTADO['modo']
    ac = acao(texto, nomes, system)
    if ac:
        nome, args = ac
        if modo == 'ferramenta_em_texto':
            return {'role': 'assistant', 'content': 'Claro! Vou registrar:\n```json\n' + json.dumps({'name': nome, 'arguments': args}, ensure_ascii=False) + '\n```'}
        if modo == 'tag_tool_call':
            return {'role': 'assistant', 'content': '<tool_call>' + json.dumps({'name': nome, 'arguments': args}, ensure_ascii=False) + '</tool_call>'}
        return {'role': 'assistant', 'content': None, 'tool_calls': [{'id': 'call_1', 'type': 'function', 'function': {'name': nome, 'arguments': json.dumps(args, ensure_ascii=False)}}]}
    docs = contexto_cerebro(system)
    r = resposta_conhecimento(texto, docs) if docs else None
    if r is None:
        if re.search(r'^\s*(oi|ol[aá]|bom dia|boa tarde|boa noite)\b', nrm(texto)):
            r = 'Oi! Como posso te ajudar hoje?'
        else:
            r = 'Não tenho essa informação confirmada no momento.'
    if modo == 'json_resposta': return {'role': 'assistant', 'content': json.dumps({'resposta': r, 'fontes': ['C1']}, ensure_ascii=False)}
    if modo == 'citacao': return {'role': 'assistant', 'content': r + ' [C1]'}
    if modo == 'despejo' and docs: return {'role': 'assistant', 'content': '\n'.join(d['corpo'] for d in docs)}
    if modo == 'inventa': return {'role': 'assistant', 'content': r + ' Além disso, o prazo é de 90 dias e o telefone é (11) 4002-8922.'}
    return {'role': 'assistant', 'content': r}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _json(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.endswith('/models'): return self._json(200, {'data': [{'id': 'substituto'}]})
        self._json(200, {'ok': True, 'modo': ESTADO['modo']})
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); body = json.loads(self.rfile.read(n) or b'{}')
        if self.path.startswith('/__modo'):
            ESTADO['modo'] = body.get('modo', 'normal'); return self._json(200, {'ok': True, 'modo': ESTADO['modo']})
        msg = responder(body)
        with open(LOG, 'a') as f: f.write(json.dumps({'modo': ESTADO['modo'], 'req': body, 'res': msg}, ensure_ascii=False) + '\n')
        self._json(200, {'id': 'x', 'object': 'chat.completion', 'model': 'substituto', 'choices': [{'index': 0, 'message': msg, 'finish_reason': 'tool_calls' if msg.get('tool_calls') else 'stop'}], 'usage': {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}})

ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
