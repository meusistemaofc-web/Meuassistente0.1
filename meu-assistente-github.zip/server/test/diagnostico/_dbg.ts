process.argv[1] = 'x'
const S = await import('./sonda-inteligencia.ts')
const P = await S.novoUsuario()
await S.conversa(P, ['Quando foi fundada a Cooperativa Tarvok?'], 'Tarvok', false)
const { q } = await import('../../src/db/index.js')
const d: any = (await q("SELECT title, status, flags, content FROM knowledge_documents ORDER BY id DESC LIMIT 1"))[0]
console.log(d.title, d.status, String(d.flags).slice(0, 400)); console.log(String(d.content).slice(0, 600))
console.log('--- sys:', (S.chamadasIA.at(-1)?.system.match(/ATENÇÃO[^\n]*/) || ['(sem aviso)'])[0])
const h: any = (await q("SELECT steps FROM learning_history ORDER BY id DESC LIMIT 1"))[0]; console.log(String(h?.steps).match(/"etapa":"comparacao"[^}]*/)?.[0])
await S.fechar()
