// Auditoria de N+1: mede as consultas ao banco por requisição (cabeçalho X-Consultas, ligado por DIAG_CONSULTAS_ROTA=1)
// em ~50 rotas, com o banco em DOIS tamanhos (3 e 9 "unidades" de dados). Rota cujo número de consultas cresce junto com
// os dados = N+1 (o crescimento por unidade aparece na coluna "por unidade").
//   1) servidor:  DIAG_CONSULTAS_ROTA=1 DIAG_CONSULTAS=1 PORT=4360 SQLITE_FILE=/tmp/ma-n1.db npx tsx test/serve-sqlite.ts  (banco novo)
//   2) medição:   npx tsx test/diagnostico/n1.ts <rótulo>        → docs/diagnostico/n1-<rótulo>.json
//      comparação: npx tsx test/diagnostico/n1.ts --comparar antes depois → docs/diagnostico/N1_COMPARACAO.md
import { writeFileSync, readFileSync } from 'node:fs'
import { DatabaseSync } from 'node:sqlite'
const OUT = new URL('../../../docs/diagnostico/', import.meta.url)
const PORTA = Number(process.env.N1_PORTA || 4360), BASE = `http://localhost:${PORTA}`, DBF = process.env.N1_DB || '/tmp/ma-n1.db'
const IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
let ipN = 0
class C {
  jar = new Map<string, string>()
  async call(m: string, p: string, j?: unknown) {
    const r = await fetch(BASE + p, { method: m, headers: { ...(j !== undefined ? { 'Content-Type': 'application/json' } : {}), Origin: BASE, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': `10.9.${Math.floor(ipN / 200)}.${ipN % 200 + 1}` }, body: j !== undefined ? JSON.stringify(j) : undefined })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const t = await r.text(); let body: any = t; try { body = JSON.parse(t) } catch { /* texto */ }
    let sql: string[] = []; try { sql = JSON.parse(decodeURIComponent(r.headers.get('x-consultas-sql') || '%5B%5D')) } catch { /* sem detalhe */ }
    return { status: r.status, body, n: Number(r.headers.get('x-consultas') ?? -1), sql }
  }
  get = (p: string) => this.call('GET', p); post = (p: string, j: unknown = {}) => this.call('POST', p, j); put = (p: string, j: unknown = {}) => this.call('PUT', p, j)
}
const U = (n: string, e: string, z: string) => ({ action: 'signup', name: n, email: e, whatsapp: '+55 11 9' + z, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
const ok = (r: any, o: string) => { if (r.status !== 200) throw new Error(`${o}: ${r.status} ${JSON.stringify(r.body).slice(0, 300)}`); return r }
const sqlite = () => new DatabaseSync(DBF)

const admin = new C(), cli = new C()
const lojas: number[] = [], prods: number[] = [], convs: string[] = [], pedidos: number[] = []
async function preparar() {
  ok(await admin.post('/api/auth', U('Admin Auditoria', 'admin@n1.com', '4444-0001')), 'admin'); ipN++
  ok(await cli.post('/api/auth', U('Cliente Auditoria', 'cliente@n1.com', '5555-0002')), 'cliente'); ipN++
  await admin.put('/api/panel/modules', { empresas: true, anuncios: true, catalogo: true, agente: true })
  await cli.put('/api/v2/me/location', { lat: -23.55, lng: -46.63 })
}
/** Uma "unidade" de dados: loja + 4 produtos + 2 pedidos do cliente + 3 tarefas + 1 compromisso + 2 notificações +
 *  1 conversa + 1 conhecimento do Cérebro + 1 chamado de suporte + 1 cupom + 1 usuário novo. */
async function unidade(k: number) {
  const r = ok(await admin.post('/api/v2/ads', { planId: 'n4', empresa: `Loja Auditoria ${k}`, categoria: 'Doces', titulo: `Doces ${k}`, texto: 'Doces artesanais', zap: '5511999990000', lat: -23.55 + k * 0.001, lng: -46.63, raio: 30, tipo: 'produtos' }), 'loja')
  const bid = Number(r.body.items.find((x: any) => x.empresa === `Loja Auditoria ${k}`).id); lojas.push(bid)
  const db = sqlite(); db.prepare("UPDATE businesses SET status='ativo', expires_at=? WHERE id=?").run(new Date(Date.now() + 30 * 864e5).toISOString(), bid); db.close()
  ok(await admin.put(`/api/v2/ads/${bid}`, { horarioCfg: { modo: 'aberto', dias: {} }, pagamento: { dinheiro: true, pix: true }, entrega: { retirada: true } }), 'loja aberta')
  for (let i = 0; i < 4; i++) { const p = ok(await admin.post(`/api/v2/ads/${bid}/products`, { nome: `Bolo ${k}-${i}`, preco: 20 + i, categoria: 'Bolos', descricao: 'Bolo caseiro', fotos: [IMG] }), 'produto'); prods.push(Number(p.body.items.find((x: any) => x.nome === `Bolo ${k}-${i}`).id)) }
  for (let i = 0; i < 2; i++) { const o = ok(await cli.post(`/api/v2/businesses/${bid}/orders`, { itens: [{ pid: prods[prods.length - 1 - i], qtd: 1 }], modo: 'retirada', pagamento: 'dinheiro' }), 'pedido'); pedidos.push(Number(o.body.order?.id || o.body.id || 0)) }
  for (let i = 0; i < 3; i++) ok(await cli.post('/api/items', { action: 'create', type: 'task', data: { title: `Tarefa ${k}-${i}` } }), 'tarefa')
  ok(await cli.post('/api/items', { action: 'create', type: 'appointment', data: { title: `Reunião ${k}`, date: '2099-03-0' + ((k % 9) + 1), time: '10:30' } }), 'compromisso')
  const uid = Number((await cli.get('/api/me')).body.profile.id), db2 = sqlite()
  for (let i = 0; i < 2; i++) db2.prepare('INSERT INTO notifications (user_id, type, title, body, link, ref, read, created_at) VALUES (?,?,?,?,?,?,0,?)').run(uid, 'reminder', `Aviso ${k}-${i}`, 'corpo', '/agenda', `n1:${k}:${i}`, new Date().toISOString())
  db2.close()
  const cv = `${String(k).padStart(8, '0')}-1111-4222-8333-444444444444`; convs.push(cv)
  ok(await cli.post('/api/chat', { text: `xqz-oi conversa ${k}`, conversationId: cv }), 'conversa')
  await admin.post('/api/panel/brain/knowledge', { action: 'add', titulo: `Política ${k} de atendimento`, conteudo: `Regra ${k}: responder clientes em até ${k} horas úteis com cordialidade.`, tipo: 'conhecimento', natureza: 'consulta', confirmar: true })
  await admin.post(`/api/v2/businesses/${bid}/coupons`, { action: 'create', nome: `Campanha ${k}`, codigo: `N1CUPOM${k}`, tipo: 'percentual', valor: 10, quantidade: 0, limitePorCliente: 1 })
  const u = new C(); ipN++; ok(await u.post('/api/auth', U(`Usuario Extra${k} Silva`, `extra${k}@n1.com`, `6666-${String(1000 + k)}`)), 'usuário extra')
  ok(await u.post('/api/v2/tickets', { categoria: 'problema', assunto: `Erro ${k} na tela`, descricao: `Descrição detalhada do problema ${k} encontrado.` }), 'chamado') // chamados de usuários diferentes (limite de 5/h por pessoa)
  ok(await u.post(`/api/v2/businesses/${bid}/orders`, { itens: [{ pid: prods[prods.length - 1], qtd: 2 }], modo: 'retirada', pagamento: 'dinheiro' }), 'pedido de outro cliente')
}
async function medir(rotulo: string) {
  const L = lojas[0], P = prods[0], CV = convs[0], uni = lojas.length
  const rotas: [string, C, string, string, unknown?][] = [
    // chat e assistente
    ['chat', cli, 'GET', '/api/conversations'], ['chat', cli, 'GET', `/api/chat?c=${CV}`], ['chat', cli, 'POST', '/api/chat', { text: 'xqz-oi medindo', conversationId: '99999999-1111-4222-8333-444444444444' }],
    ['chat', cli, 'GET', '/api/v2/modos'], ['chat', cli, 'GET', '/api/v2/chat/tarefas'], ['chat', cli, 'GET', '/api/memory'], ['chat', cli, 'GET', '/api/me'],
    // Cérebro Central / inteligência (administrador)
    ['cerebro', admin, 'GET', '/api/panel/brain/knowledge'], ['cerebro', admin, 'GET', '/api/panel/brain/answers'], ['cerebro', admin, 'GET', '/api/panel/brain/usage'], ['cerebro', admin, 'GET', '/api/panel/brain/conflicts'],
    ['cerebro', admin, 'GET', '/api/panel/cognicao'], ['cerebro', admin, 'GET', '/api/panel/inteligencia'], ['cerebro', admin, 'GET', '/api/panel/orquestracao'], ['cerebro', admin, 'GET', '/api/panel/aprendizagem'], ['cerebro', admin, 'GET', '/api/panel/aprendizado'],
    // empresas (dono)
    ['empresas', admin, 'GET', '/api/v2/ads/mine'], ['empresas', admin, 'GET', `/api/v2/ads/${L}/products`], ['empresas', admin, 'GET', `/api/v2/ads/${L}/orders`], ['empresas', admin, 'GET', '/api/v2/lojas/central'],
    ['empresas', admin, 'GET', '/api/v2/lojas/pedidos'], ['empresas', admin, 'GET', '/api/v2/ads/painel'], ['empresas', admin, 'GET', `/api/v2/businesses/${L}/bi`], ['empresas', admin, 'GET', `/api/v2/businesses/${L}/coupons`], ['empresas', admin, 'GET', '/api/v2/counters'],
    // marketplace e produtos (cliente)
    ['marketplace', cli, 'GET', '/api/v2/businesses/cards'], ['marketplace', cli, 'GET', '/api/v2/businesses/search?q=doces'], ['marketplace', cli, 'GET', '/api/v2/marketplace/produtos'], ['marketplace', cli, 'GET', '/api/v2/marketplace/produtos?q=bolo'],
    ['marketplace', cli, 'GET', '/api/v2/marketplace/servicos'], ['marketplace', cli, 'GET', `/api/v2/businesses/${L}`], ['marketplace', cli, 'GET', `/api/v2/busca/cards?ids=${prods.slice(0, 12).map((x) => 'p' + x).join(',')}`],
    ['marketplace', cli, 'GET', '/api/v2/orders/mine'], ['marketplace', cli, 'GET', '/api/v2/coupons/mine'], ['marketplace', cli, 'GET', '/api/v2/reviews/mine'], ['marketplace', cli, 'GET', `/api/v2/compartilhar/item/${P}`],
    // agenda
    ['agenda', cli, 'GET', '/api/agenda'], ['agenda', cli, 'GET', '/api/day'], ['agenda', cli, 'GET', '/api/summary'], ['agenda', cli, 'GET', '/api/appointments'], ['agenda', cli, 'GET', '/api/v2/compromissos'], ['agenda', cli, 'GET', '/api/v2/compromissos/estatisticas'],
    // notificações
    ['notificacoes', cli, 'GET', '/api/notifications'], ['notificacoes', cli, 'GET', '/api/notifications?count=1'], ['notificacoes', admin, 'GET', '/api/v2/lojas/notificacoes'],
    // painel administrativo
    ['painel', admin, 'GET', '/api/panel'], ['painel', admin, 'GET', '/api/admin/users'], ['painel', admin, 'GET', '/api/admin/audit'], ['painel', admin, 'GET', '/api/v2/admin/ads'], ['painel', admin, 'GET', '/api/v2/admin/ads-approval'],
    ['painel', admin, 'GET', '/api/panel/tickets'], ['painel', admin, 'GET', '/api/v2/admin/ratings'], ['painel', admin, 'GET', '/api/panel/coupons'], ['painel', admin, 'GET', '/api/panel/showcase'], ['painel', admin, 'GET', '/api/v2/admin/vouchers'], ['painel', cli, 'GET', '/api/v2/tickets'],
  ]
  const out: any[] = []
  for (const [area, c, m, p, b] of rotas) {
    const r = await c.call(m, p, b)
    // a mesma consulta repetida muitas vezes na mesma requisição é o sinal clássico de N+1
    const rep = new Map<string, number>(); for (const s of r.sql) { const k = s.replace(/\s\[.*$/, '').slice(0, 70); rep.set(k, (rep.get(k) || 0) + 1) }
    out.push({ area, rota: `${m} ${p.replace(/\d{8}-1111-4222-8333-444444444444/, ':conv').replace(/\/\d+(?=\/|$|\?)/g, '/:id').replace(/ids=[^&]+/, 'ids=…')}`, status: r.status, consultas: r.n, repetidas: [...rep].filter(([, n]) => n >= 3).sort((a, b) => b[1] - a[1]).slice(0, 4) })
  }
  return { rotulo, unidades: uni, rotas: out }
}
function comparar(antes: any, depois: any) {
  const L = ['# Auditoria N+1 — consultas por requisição, antes × depois', '', `Banco de teste (SQLite) com ${antes.a.unidades} e ${antes.b.unidades} unidades de dados; uma unidade = 1 loja, 4 produtos, 2 pedidos, 3 tarefas, 1 compromisso, 2 notificações, 1 conversa, 1 conhecimento do Cérebro, 1 chamado, 1 cupom e 1 usuário. "Por unidade" = consultas a mais para cada unidade de dados (0 = não cresce com os dados).`, '',
    '| Área | Rota | Antes (' + antes.a.unidades + ' → ' + antes.b.unidades + ') | Por unidade antes | Depois (' + depois.a.unidades + ' → ' + depois.b.unidades + ') | Por unidade depois |', '|---|---|---|---|---|---|']
  const du = antes.b.unidades - antes.a.unidades
  let tA = 0, tD = 0
  for (const r of antes.b.rotas) {
    const a0 = antes.a.rotas.find((x: any) => x.rota === r.rota), d0 = depois.a.rotas.find((x: any) => x.rota === r.rota), d1 = depois.b.rotas.find((x: any) => x.rota === r.rota)
    if (!a0 || !d0 || !d1) continue
    const pa = (r.consultas - a0.consultas) / du, pd = (d1.consultas - d0.consultas) / du; tA += r.consultas; tD += d1.consultas
    L.push(`| ${r.area} | \`${r.rota}\` | ${a0.consultas} → ${r.consultas} | ${pa > 0 ? '**' + pa.toFixed(1) + '**' : pa.toFixed(1)} | ${d0.consultas} → ${d1.consultas} | ${pd > 0 ? '**' + pd.toFixed(1) + '**' : pd.toFixed(1)} |`)
  }
  L.push('', `**Total de consultas (todas as rotas medidas, banco maior):** ${tA} → ${tD} (${Math.round((1 - tD / tA) * 100)}% a menos).`)
  return L.join('\n') + '\n'
}
const args = process.argv.slice(2)
if (args[0] === '--comparar') {
  const a = JSON.parse(readFileSync(new URL(`n1-${args[1]}.json`, OUT), 'utf8')), d = JSON.parse(readFileSync(new URL(`n1-${args[2]}.json`, OUT), 'utf8'))
  writeFileSync(new URL('N1_COMPARACAO.md', OUT), comparar(a, d)); console.log('N1_COMPARACAO.md gravado')
} else {
  await preparar()
  for (let k = 1; k <= 3; k++) await unidade(k)
  const a = await medir((args[0] || 'x') + '-3')
  for (let k = 4; k <= 9; k++) await unidade(k)
  const b = await medir((args[0] || 'x') + '-9')
  writeFileSync(new URL(`n1-${args[0] || 'x'}.json`, OUT), JSON.stringify({ a, b }, null, 1))
  const du = b.unidades - a.unidades
  for (const r of b.rotas) { const r0 = a.rotas.find((x: any) => x.rota === r.rota); const pu = (r.consultas - r0.consultas) / du; console.log(`${pu > 0.01 ? '⚠' : ' '} ${String(r0.consultas).padStart(4)} → ${String(r.consultas).padStart(4)}  (${pu.toFixed(1)}/un)  ${r.status}  ${r.area.padEnd(12)} ${r.rota}${pu > 0.01 && r.repetidas.length ? '   ' + r.repetidas.map((x: any) => `${x[1]}× ${x[0]}`).join(' | ') : ''}`) }
}
