// Compatibilidade do cofre: valores cifrados pelo código ORIGINAL (v1:, sha256 da semente) abrem no código atual.
import { createCipheriv, randomBytes, createHash } from 'node:crypto'
import { createSqlite } from '../../src/db/sqlite.js'
import { setDb, q } from '../../src/db/index.js'
import { migrate } from '../../src/db/migrate.js'
import { config } from '../../src/config.js'
const velho = (seed: string, plain: string) => { const k = createHash('sha256').update(seed).digest(), iv = randomBytes(12), c = createCipheriv('aes-256-gcm', k, iv); const e = Buffer.concat([c.update(plain, 'utf8'), c.final()]); return 'v1:' + Buffer.concat([iv, c.getAuthTag(), e]).toString('base64') }
const d = await createSqlite(':memory:'); setDb(d); await migrate(d, config.migrationsDir, () => {})
const S = await import('../../src/lib/settings.js'); let ok = 0, falhas = 0
const caso = async (nome: string, v: string, esperado: string, env: Record<string, string | undefined>) => {
  for (const k of ['APP_SECRET', 'APP_SECRET_ANTERIOR']) { if (env[k] === undefined) delete process.env[k]; else process.env[k] = env[k] }
  S.recarregarCofre(); const r = await S.unsealInfo(v); const bom = esperado ? r.ok && r.valor === esperado : !r.ok
  console.log((bom ? '  ✔ ' : '  ✘ ') + nome + (bom ? '' : ` → ${JSON.stringify(r)}`)); bom ? ok++ : falhas++
}
const VK = 'a'.repeat(64); await q("INSERT INTO app_config (key, value, updated_at) VALUES ('vault-key', $1, $2)", [JSON.stringify(VK), new Date().toISOString()])
const SEC = 'segredo-de-producao-0123456789'
await caso('chave do banco (sem APP_SECRET), como o original', velho(VK, 'APP_USR-banco'), 'APP_USR-banco', {})
await caso('APP_SECRET, como o original', velho(SEC, 'APP_USR-secret'), 'APP_USR-secret', { APP_SECRET: SEC })
await caso('cifrado com a chave do banco, APP_SECRET preenchido depois', velho(VK, 'APP_USR-depois'), 'APP_USR-depois', { APP_SECRET: SEC })
await caso('cifrado com APP_SECRET antigo, valor antigo em APP_SECRET_ANTERIOR', velho(SEC, 'APP_USR-ant'), 'APP_USR-ant', { APP_SECRET: 'outro-segredo-novo-9876543210', APP_SECRET_ANTERIOR: SEC })
await caso('APP_SECRET com espaço/aspas extras NÃO é o mesmo segredo (sinal de .env editado)', velho(SEC, 'x'), '', { APP_SECRET: SEC + ' ' })
await caso('cifrado com APP_SECRET que não está mais em lugar nenhum: ilegível, sem erro', velho(SEC, 'APP_USR-perdido'), '', { APP_SECRET: 'outro-segredo-novo-9876543210' })
console.log(`\n${ok}/${ok + falhas} casos`); process.exit(falhas ? 1 : 0)
