// Linha de comando do diagnóstico da Fase 3 (o executor fica em src/ai/diagnostico/executar.ts).
//   npx tsx test/diagnostico/diagnostico.ts <rótulo>               → grava docs/diagnostico/fase3-<rótulo>.json
//   npx tsx test/diagnostico/diagnostico.ts --comparar antes depois → grava docs/diagnostico/COMPARACAO.md
import { writeFileSync, readFileSync } from 'node:fs'
import { diagnosticar } from '../../src/ai/diagnostico/executar.js'
const OUT = new URL('../../../docs/diagnostico/', import.meta.url)
const pctA = (a: { total: number; ok: number }) => (a.total ? Math.round((a.ok / a.total) * 1000) / 10 : 0)
function comparar(antes: any, depois: any) {
  const areas = [...new Set([...Object.keys(antes.porArea), ...Object.keys(depois.porArea)])]
  const L = ['# Diagnóstico da Fase 3 — antes × depois', '', `Corpus: ${depois.latencia.casos} mensagens + ${depois.latencia.respostas} respostas sintéticas (nenhuma conversa de usuário). Antes: ${antes.em.slice(0, 16)} · Depois: ${depois.em.slice(0, 16)}`, '',
    `**Acerto geral:** ${antes.taxa}% (${antes.aprovadas}/${antes.verificacoes}) → **${depois.taxa}%** (${depois.aprovadas}/${depois.verificacoes})`, '', '| Área | Antes | Depois |', '|---|---|---|']
  for (const a of areas) L.push(`| ${a} | ${antes.porArea[a] ? pctA(antes.porArea[a]) + '%' : '—'} | ${depois.porArea[a] ? pctA(depois.porArea[a]) + '%' : '—'} |`)
  L.push('', '## Latência (microssegundos para o corpus inteiro, média)', '', '| Função | Antes | Depois |', '|---|---|---|')
  for (const k of Object.keys(depois.latencia).filter((k) => typeof depois.latencia[k] === 'object')) L.push(`| ${k} | ${antes.latencia[k]?.mediaUs ?? '—'} | ${depois.latencia[k].mediaUs} |`)
  L.push('', `Por mensagem (todas as etapas determinísticas): ${Math.round((antes.latencia.porMensagem?.mediaUs || 0) / antes.latencia.casos)} µs → ${Math.round(depois.latencia.porMensagem.mediaUs / depois.latencia.casos)} µs`, '', '## Falhas que permanecem', '')
  if (!depois.falhas.length) L.push('Nenhuma.')
  for (const f of depois.falhas) L.push(`- **${f.id}** (${f.componente}) — "${f.texto}": esperado ${JSON.stringify(f.esperado)}, obtido ${JSON.stringify(f.obtido).slice(0, 160)}`)
  L.push('', '## Falhas corrigidas', '')
  const ids = new Set(depois.falhas.map((f: any) => f.id + f.componente))
  for (const f of antes.falhas.filter((f: any) => !ids.has(f.id + f.componente))) L.push(`- ${f.id} (${f.componente}) — "${f.texto}"`)
  return L.join('\n') + '\n'
}

const args = process.argv.slice(2)
if (args[0] === '--comparar') {
  const a = JSON.parse(readFileSync(new URL(`fase3-${args[1]}.json`, OUT), 'utf8')), d = JSON.parse(readFileSync(new URL(`fase3-${args[2]}.json`, OUT), 'utf8'))
  writeFileSync(new URL('COMPARACAO.md', OUT), comparar(a, d)); console.log('COMPARACAO.md gravado')
} else if (args[0]) {
  const r = diagnosticar(); writeFileSync(new URL(`fase3-${args[0]}.json`, OUT), JSON.stringify(r, null, 1))
  console.log(`acerto ${r.taxa}% (${r.aprovadas}/${r.verificacoes}) · falhas ${r.falhas.length} · VALIDAÇÃO (casos novos) ${r.validacao.taxa}% (${r.validacao.aprovadas}/${r.validacao.verificacoes})`)
  for (const f of r.validacao.falhas) console.log(`  ✘ validação ${f.id} [${f.componente}] "${f.texto.slice(0, 70)}" → esperado ${JSON.stringify(f.esperado)} · obtido ${JSON.stringify(f.obtido).slice(0, 140)}`)
  for (const [a, v] of Object.entries(r.porArea)) console.log(`  ${a.padEnd(20)} ${pctA(v)}% (${v.ok}/${v.total})`)
  for (const f of r.falhas) console.log(`  ✘ ${f.id} [${f.componente}] "${f.texto.slice(0, 70)}" → esperado ${JSON.stringify(f.esperado)} · obtido ${JSON.stringify(f.obtido).slice(0, 140)}`)
  console.log('latência µs (corpus inteiro):', JSON.stringify(Object.fromEntries(Object.entries(r.latencia).filter(([, v]) => typeof v === 'object').map(([k, v]: any) => [k, v.mediaUs]))))
}
