// O corpus fica no código do servidor (o painel e o monitor também o usam).
export * from '../../src/ai/diagnostico/corpus.js'
