// INTEGRAÇÃO: onde a empresa recebe os novos pedidos (painel e/ou WhatsApp), pelo app real (createApp + rotas reais), em
// SQLite ou num Postgres real (--pg porta). Dublês: os 3 provedores de WhatsApp (Cloud API da Meta, Evolution API, Z-API)
// e o Mercado Pago (Pix da loja + webhook). Confere: mensagem completa no número da empresa, aviso no painel, nenhum pedido
// perdido/duplicado/concluído automaticamente, novas tentativas, falhas levadas ao painel e logs sem segredos.
// Uso: npm run test:pedidos-whatsapp [-- --pg 54329]
import { createServer } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'

const arg = (n: string) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : undefined }
const PG = arg('--pg')
const logs: string[] = []
for (const k of ['log', 'error', 'warn', 'info'] as const) { const o = console[k].bind(console); console[k] = (...a: any[]) => { logs.push(a.map((x) => (x instanceof Error ? x.stack || x.message : typeof x === 'string' ? x : JSON.stringify(x))).join(' ')); if (process.env.MOSTRAR_LOGS) o(...a) } }
const saida = (s: string) => process.stdout.write(s + '\n')
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

// ---- dublês dos provedores de WhatsApp ----
type Msg = { via: string; para: string; texto: string; tipo: string; auth: string; corpo: any }
const recebidas: Msg[] = []
let modo: 'ok' | '401' | '500' | 'lento' | 'janela' = 'ok'
const SEG = { meta: 'EAAG-token-meta-SECRETO-123', evo: 'evo-apikey-SECRETA-456', zt: 'zapi-token-SECRETO-789', zc: 'zapi-client-SECRETO-000' }
const wa = createServer(async (req, res) => {
  let b = ''; for await (const c of req) b += c; const j = b ? JSON.parse(b) : {}
  const resp = (st: number, o: unknown) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (modo === 'lento') { await sleep(1500); return resp(200, {}) }
  if (modo === '500') return resp(500, { message: 'instabilidade' })
  const url = req.url || ''
  if (/\/v\d+\.\d+\/\d+\/messages$/.test(url)) { // Meta Cloud API
    if (req.headers.authorization !== `Bearer ${SEG.meta}` || modo === '401') return resp(401, { error: { message: 'Invalid OAuth access token.', code: 190 } })
    if (modo === 'janela' && j.type === 'text') return resp(400, { error: { message: 'Re-engagement message', code: 131047 } })
    recebidas.push({ via: 'cloud', para: j.to, texto: j.text?.body || JSON.stringify(j.template?.components || []), tipo: j.type, auth: 'ok', corpo: j })
    return resp(200, { messaging_product: 'whatsapp', messages: [{ id: 'wamid.' + recebidas.length }] })
  }
  if (/\/message\/sendText\//.test(url)) { // Evolution API
    if (req.headers.apikey !== SEG.evo || modo === '401') return resp(401, { message: 'Unauthorized' })
    recebidas.push({ via: 'evolution', para: j.number, texto: j.text, tipo: 'text', auth: 'ok', corpo: j })
    return resp(201, { key: { id: 'EVO' + recebidas.length }, status: 'PENDING' })
  }
  if (/\/instances\/[^/]+\/token\/[^/]+\/send-text$/.test(url)) { // Z-API
    if (!url.includes(SEG.zt) || req.headers['client-token'] !== SEG.zc || modo === '401') return resp(401, { error: 'unauthorized' })
    recebidas.push({ via: 'zapi', para: j.phone, texto: j.message, tipo: 'text', auth: 'ok', corpo: j })
    return resp(200, { zaapId: 'Z' + recebidas.length, messageId: 'ZM' + recebidas.length })
  }
  resp(404, {})
})
await new Promise<void>((r) => wa.listen(0, '127.0.0.1', r)); const WA = `http://127.0.0.1:${(wa.address() as any).port}`
process.env.WHATSAPP_CLOUD_BASE = WA; process.env.ZAPI_BASE = WA; process.env.WHATSAPP_TIMEOUT_MS = '600'
// ---- dublê do Mercado Pago (conta da loja, Pix e consulta do pagamento) ----
const pagamentos = new Map<string, any>()
const mp = createServer(async (req, res) => {
  let b = ''; for await (const c of req) b += c; const j = b ? JSON.parse(b) : {}
  const resp = (st: number, o: unknown) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (req.url === '/users/me') return resp(200, { id: 42, nickname: 'LOJA' })
  if (req.method === 'POST' && req.url === '/v1/payments') { const id = String(9000 + pagamentos.size); pagamentos.set(id, { id: Number(id), status: 'pending', external_reference: j.external_reference, transaction_amount: j.transaction_amount }); return resp(201, { ...pagamentos.get(id), point_of_interaction: { transaction_data: { qr_code: '000201PIX', qr_code_base64: 'AAAA' } }, date_of_expiration: j.date_of_expiration }) }
  const m = /^\/v1\/payments\/(\d+)/.exec(req.url || ''); if (m && pagamentos.has(m[1])) return resp(200, pagamentos.get(m[1]))
  resp(404, {})
})
await new Promise<void>((r) => mp.listen(0, '127.0.0.1', r)); process.env.MP_API_BASE = `http://127.0.0.1:${(mp.address() as any).port}`

// ---- banco e app ----
const { setDb, q, one, J } = await import('../../src/db/index.js'), { migrate } = await import('../../src/db/migrate.js'), { config } = await import('../../src/config.js')
let d: any
if (PG) { const nome = 'wa_diag_' + Date.now(); execFileSync('/usr/lib/postgresql/16/bin/psql', ['-h', '127.0.0.1', '-p', PG, '-U', 'postgres', '-qc', `CREATE DATABASE ${nome}`]); d = await (await import('./pg-mini.js')).createPgMini({ host: '127.0.0.1', port: Number(PG), user: 'postgres', database: nome }); saida(`Banco: PostgreSQL real (porta ${PG})`) }
else { d = await (await import('../../src/db/sqlite.js')).createSqlite(join(mkdtempSync(join(tmpdir(), 'ma-wa-')), 'wa.db')); saida('Banco: SQLite') }
setDb(d); await migrate(d, config.migrationsDir, () => {})
const { createApp } = await import('../../src/app.js'), W = await import('../../src/lib/whatsapp-envio.js'), R = await import('../../src/lib/recebimento-pedidos.js')
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port
class Cli { jar = new Map<string, string>()
  async call(method: string, path: string, body?: unknown) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers: { 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: body === undefined ? undefined : JSON.stringify(body) })
    for (const c of r.headers.getSetCookie?.() || []) { const [kv] = c.split(';'); const [k, v] = kv.split('='); this.jar.set(k.trim(), v) }
    const t = await r.text(); let j: any; try { j = JSON.parse(t) } catch { j = t } return { status: r.status, body: j }
  } }
const cad = async (nome: string, email: string, zap: string) => { const c = new Cli(); const r = await c.call('POST', '/api/auth', { action: 'signup', name: nome, email, whatsapp: zap, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error('cadastro: ' + JSON.stringify(r.body)); return c }
const res: { n: string; ok: boolean; d: string }[] = []
const check = (n: string, ok: unknown, d: unknown = '') => { res.push({ n, ok: !!ok, d: typeof d === 'string' ? d : JSON.stringify(d) }); saida(`${ok ? '  ✔' : '  ✘'} ${n}${ok ? '' : ' → ' + (typeof d === 'string' ? d : JSON.stringify(d)).slice(0, 500)}`) }

const admin = await cad('Admin Sistema', 'admin@wa.com', '+55 11 94444-0001')
await admin.call('PUT', '/api/panel/modules', { empresas: true, anuncios: true, catalogo: true })
const dono = await cad('Dona Pizzaria', 'dona@wa.com', '+55 11 94444-0002')
const cliente = await cad('Carlos Cliente', 'carlos@wa.com', '+55 21 98888-7777')
let r = await dono.call('POST', '/api/v2/ads', { planId: 'n4', empresa: 'Pizzaria Bella', categoria: 'Pizzaria', titulo: 'Pizzaria Bella', texto: 'Forno a lenha', zap: '11 98765-4321', lat: -23.552, lng: -46.63, raio: 10, tipo: 'produtos' })
if (r.status !== 200) throw new Error(JSON.stringify(r.body))
const BID = r.body.items[0].id
await q("UPDATE businesses SET status = 'ativo', expires_at = $1 WHERE id = $2", [new Date(Date.now() + 30 * 86400_000).toISOString(), BID])
await dono.call('PUT', `/api/v2/ads/${BID}`, { horarioCfg: { modo: 'aberto', dias: {} }, entrega: { retirada: true, entrega: true, taxa: 7, raio: 50, minimo: 0 }, pagamento: { pix: true, chavePix: 'pizza@pix.com', dinheiro: true } })
const foto = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
const prods: Record<string, number> = {}
for (const p of [{ nome: 'Pizza Margherita', preco: 52.9, categoria: 'Pizzas', fotos: [foto] }, { nome: 'Refrigerante 2L', preco: 12, categoria: 'Bebidas', fotos: [foto] }]) { const x = await dono.call('POST', `/api/v2/ads/${BID}/products`, p); prods[p.nome] = x.body.items.find((i: any) => i.nome === p.nome).id }
await cliente.call('PUT', '/api/v2/me/location', { lat: -23.55, lng: -46.63 })
let nIdem = 0
const pedir = (extra: any = {}) => cliente.call('POST', `/api/v2/businesses/${BID}/orders`, { itens: [{ pid: prods['Pizza Margherita'], qtd: 2 }, { pid: prods['Refrigerante 2L'], qtd: 1 }], modo: 'retirada', pagamento: 'dinheiro', telefone: '21988887777', nome: 'Carlos Cliente', obs: 'sem cebola', idem: 'i' + (++nIdem), ...extra })
const avisos = async (oid: number) => (await q("SELECT ref, title, body FROM notifications WHERE user_id = (SELECT owner_id FROM businesses WHERE id = $1) AND ref LIKE $2", [BID, `%:${oid}`]))
const status = async (oid: number) => String((await one('SELECT status FROM orders WHERE id = $1', [oid]))!.status)
const espera = async (oid: number, ms = 3000) => { const t = Date.now(); for (;;) { const e = await W.envioDoPedido(oid); if (e && !['pendente', 'enviando'].includes(e.status)) return e; if (e?.status === 'pendente' && e.tentativas > 0) return e; if (Date.now() - t > ms) return e; await sleep(40) } }
const naLista = async (oid: number) => ((await dono.call('GET', `/api/v2/ads/${BID}/orders`)).body.items || []).some((o: any) => o.id === oid)

saida('\n== Configuração e validações')
let s0 = (await dono.call('GET', `/api/v2/ads/${BID}/recebimento`)).body
check('padrão: só o painel (comportamento de antes)', s0.canais?.painel === true && s0.canais?.whatsapp === false && s0.numero === '+55 11 98765-4321', s0)
r = await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: false, whatsapp: false })
check('desligar os dois canais é recusado (nenhum pedido sem aviso)', r.status === 400 && /pelo menos um/.test(r.body.error), r.body)
r = await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: true, whatsapp: true })
check('WhatsApp sem provedor configurado: recusado com motivo claro', r.status === 409 && /administrador/.test(r.body.error), r.body)
r = await admin.call('PUT', '/api/panel/whatsapp_envio', { provedor: 'evolution', evolution: { url: WA, instancia: 'loja-01', apikey: SEG.evo } })
check('admin configura a Evolution API (segredo não volta ao navegador)', r.status === 200 && r.body.whatsapp_envio?.configurado && !JSON.stringify(r.body).includes(SEG.evo), r.body.whatsapp_envio)
const t0 = await admin.call('POST', '/api/panel/whatsapp-teste', { numero: '11 91234-5678' })
check('admin: mensagem de teste enviada de verdade ao provedor', t0.body.ok && recebidas.at(-1)?.para === '5511912345678', t0.body)
const outro = await cad('Outra Pessoa', 'outra@wa.com', '+55 11 94444-0003')
check('outra pessoa não altera o recebimento da loja', (await outro.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: true, whatsapp: true })).status === 404)

saida('\n== Só o painel')
r = await pedir(); const o1 = r.body.order.id; await sleep(150)
check('pedido criado e na lista de Pedidos, com notificação no painel', r.status === 200 && (await naLista(o1)) && (await avisos(o1)).some((a: any) => a.ref === `order-new:${o1}`), r.body)
check('nenhuma mensagem de WhatsApp quando o canal está desligado', !(await W.envioDoPedido(o1)) && !recebidas.some((m) => m.texto.includes(`#${o1}*`)))

saida('\n== Só o WhatsApp (Evolution API)')
r = await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: false, whatsapp: true })
check('loja escolhe só o WhatsApp', r.status === 200 && r.body.canais.whatsapp && !r.body.canais.painel, r.body)
const tl = await dono.call('POST', `/api/v2/ads/${BID}/recebimento/teste`, {})
check('loja: mensagem de teste chega no WhatsApp cadastrado', tl.body.ok && recebidas.at(-1)?.para === '5511987654321', tl.body)
let antes = recebidas.length
r = await pedir({ modo: 'entrega', endereco: 'Rua das Flores, 120 - Centro', enderecoPartes: { rua: 'Rua das Flores', numero: '120', bairro: 'Centro', cidade: 'São Paulo', referencia: 'portão azul' }, pagamento: 'pix' })
const o2 = r.body.order.id; let e2 = await espera(o2)
const m2 = recebidas.slice(antes).filter((m) => m.texto.includes(`#${o2}*`))
check('uma mensagem para o número da empresa (+55 11 98765-4321)', r.status === 200 && e2?.status === 'enviado' && m2.length === 1 && m2[0].para === '5511987654321', { envio: e2, n: m2.length })
const tx = m2[0]?.texto || ''
check('mensagem com produtos, quantidades e valores', /2 × Pizza Margherita — R\$ 52,90 cada = R\$ 105,80/.test(tx) && /1 × Refrigerante 2L — R\$ 12,00 cada = R\$ 12,00/.test(tx) && /Subtotal: R\$ 117,80/.test(tx) && /Entrega: R\$ 7,00/.test(tx) && /Total: R\$ 124,80/.test(tx), tx)
check('mensagem com dados do cliente, entrega, pagamento e observações', /Carlos Cliente · \+5521988887777/.test(tx) && /Rua das Flores, 120/.test(tx) && /Referência: portão azul/.test(tx) && /Pix \(chave da loja\)/.test(tx) && /Observações: sem cebola/.test(tx) && /\/x\/sua-empresa/.test(tx), tx)
check('pedido continua em Pedidos, com status "novo" (nada concluído)', (await naLista(o2)) && (await status(o2)) === 'novo')
check('sem notificação no painel (canal desligado)', !(await avisos(o2)).length, await avisos(o2))
antes = recebidas.length
r = await pedir({ idem: 'i' + nIdem }); await sleep(200)
check('mesmo pedido reenviado (toque duplo): mesmo pedido, nenhuma mensagem nova', r.status === 200 && r.body.order.id === o2 && recebidas.length === antes, { id: r.body.order.id, o2, novas: recebidas.length - antes })
await R.avisarNovoPedido(BID, o2, { title: 'x', ref: `order-new:${o2}` }, { esperarWhatsApp: true })
check('aviso repetido do mesmo pedido não duplica a mensagem', recebidas.length === antes && (await q('SELECT COUNT(*) AS n FROM envios_whatsapp WHERE order_id = $1', [o2]))[0].n == 1)

saida('\n== Os dois canais (Z-API)')
await admin.call('PUT', '/api/panel/whatsapp_envio', { provedor: 'zapi', zapi: { instancia: 'INST1', token: SEG.zt, clientToken: SEG.zc } })
await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: true, whatsapp: true }); antes = recebidas.length
r = await pedir(); const o3 = r.body.order.id; const e3 = await espera(o3)
check('painel + WhatsApp: notificação no painel E uma mensagem pela Z-API', e3?.status === 'enviado' && recebidas.slice(antes).filter((m) => m.via === 'zapi' && m.texto.includes(`#${o3}*`)).length === 1 && (await avisos(o3)).length === 1, { e3, av: await avisos(o3) })
check('retirada aparece na mensagem e o status segue "novo"', /Retirada no local/.test(recebidas.at(-1)?.texto || '') && (await status(o3)) === 'novo')

saida('\n== WhatsApp Cloud API (Meta): texto e modelo fora da janela de 24 h')
await admin.call('PUT', '/api/panel/whatsapp_envio', { provedor: 'cloud', cloud: { phoneNumberId: '1234567890123', token: SEG.meta, template: 'novo_pedido', idioma: 'pt_BR' } })
await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: false, whatsapp: true }); antes = recebidas.length
r = await pedir(); const o4 = r.body.order.id; const e4 = await espera(o4)
check('Cloud API: texto completo entregue', e4?.status === 'enviado' && e4.provedor === 'cloud' && recebidas.slice(antes).some((m) => m.via === 'cloud' && m.tipo === 'text' && m.texto.includes(`#${o4}*`)), e4)
modo = 'janela'; antes = recebidas.length
r = await pedir(); const o5 = r.body.order.id; const e5 = await espera(o5); modo = 'ok'
const tpl = recebidas.slice(antes).find((m) => m.tipo === 'template')
const pars = tpl?.corpo?.template?.components?.[0]?.parameters || []
check('fora da janela: usa o modelo aprovado com nº do pedido e resumo em uma linha', e5?.status === 'enviado' && e5.provedor === 'cloud:modelo' && tpl?.corpo?.template?.name === 'novo_pedido' && pars[0]?.text === `#${o5}` && /2x Pizza Margherita/.test(pars[1]?.text) && !/\n/.test(pars[1]?.text), { e5, pars })

saida('\n== Falhas: nunca perde, nunca duplica')
modo = '401'; r = await pedir(); const o6 = r.body.order.id; const e6 = await espera(o6); await sleep(150); modo = 'ok'
check('token recusado: envio "falhou" e o pedido vai para o painel (mesmo com o painel desligado)', e6?.status === 'falhou' && (await avisos(o6)).some((a: any) => /não foi possível enviar ao WhatsApp/.test(a.body)) && (await status(o6)) === 'novo', { e6, av: await avisos(o6) })
modo = '500'; r = await pedir(); const o7 = r.body.order.id; let e7 = await espera(o7)
check('instabilidade (500): fica pendente para nova tentativa, sem aviso ainda', e7?.status === 'pendente' && e7.tentativas === 1 && !(await avisos(o7)).length, e7)
modo = 'ok'; antes = recebidas.length
await q("UPDATE envios_whatsapp SET proxima_em = $1 WHERE order_id = $2", [new Date(Date.now() - 1000).toISOString(), o7]); await W.processarPendentes(); await W.processarPendentes()
e7 = await W.envioDoPedido(o7)
check('nova tentativa entrega uma vez só (agendador rodando duas vezes)', e7?.status === 'enviado' && e7.tentativas === 2 && recebidas.slice(antes).filter((m) => m.texto.includes(`#${o7}*`)).length === 1, e7)
modo = 'lento'; r = await pedir(); const o8 = r.body.order.id; const e8 = await espera(o8, 4000); await sleep(150); modo = 'ok'
await W.processarPendentes()
check('sem resposta do provedor: "incerto", NÃO reenvia (evita duplicar) e avisa no painel', e8?.status === 'incerto' && (await W.envioDoPedido(o8))?.tentativas === 1 && (await avisos(o8)).some((a: any) => /não confirmou/.test(a.body)), { e8, av: await avisos(o8) })
// reinício no meio do envio: linha presa em "enviando"
r = await pedir(); const o9 = r.body.order.id; await espera(o9)
await q("UPDATE envios_whatsapp SET status = 'enviando', atualizado_em = $1 WHERE order_id = $2", [new Date(Date.now() - 10 * 60_000).toISOString(), o9]); await q('DELETE FROM notifications WHERE ref = $1', [`order-new:${o9}`]); antes = recebidas.length
await W.processarPendentes()
check('envio interrompido por reinício: marcado "incerto", sem reenviar, aviso no painel', (await W.envioDoPedido(o9))?.status === 'incerto' && recebidas.length === antes && (await avisos(o9)).length === 1)
await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: false, whatsapp: true })
const zapLoja = async (z: string) => { const x = J((await one('SELECT data FROM businesses WHERE id = $1', [BID]))!.data, {} as any); x.zap = z; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), BID]) }
await zapLoja('123')
r = await pedir(); const o10 = r.body.order.id; const e10 = await espera(o10); await sleep(100)
check('número da empresa inválido depois de configurado: pedido vai para o painel', e10?.status === 'falhou' && /inválido/.test(e10.erro) && (await avisos(o10)).length === 1, e10)
await zapLoja('5511987654321')

saida('\n== Pedido com Pix automático (Mercado Pago): avisa só quando o pagamento é aprovado, uma vez')
await dono.call('POST', `/api/v2/ads/${BID}/mp`, { tok: 'TEST-1234567890123456-112115-abcdef0123456789abcdef0123456789-42' })
await dono.call('PUT', `/api/v2/ads/${BID}`, { pagamento: { pix: true, chavePix: 'pizza@pix.com', dinheiro: true, online: true } })
await dono.call('PUT', `/api/v2/ads/${BID}/recebimento`, { painel: true, whatsapp: true }); antes = recebidas.length
r = await pedir({ pagamento: 'online' }); const o11 = r.body.order.id; await sleep(200)
check('Pix gerado: nada enviado antes do pagamento', r.status === 200 && !(await W.envioDoPedido(o11)) && !(await avisos(o11)).length, r.body)
const pid = [...pagamentos.values()].find((p) => p.external_reference === `order:${o11}`); pid.status = 'approved'
for (let i = 0; i < 2; i++) await cliente.call('POST', `/api/mercadopago/webhook?store=${BID}&data.id=${pid.id}`, { data: { id: String(pid.id) } }) // o Mercado Pago repete notificações
const e11 = await espera(o11)
check('pago: uma mensagem (marcada PAGO) e um aviso no painel, mesmo com o webhook repetido', e11?.status === 'enviado' && recebidas.slice(antes).filter((m) => m.texto.includes(`#${o11}*`)).length === 1 && /PAGO/.test(recebidas.slice(antes).find((m) => m.texto.includes(`#${o11}*`))?.texto || '') && (await avisos(o11)).length === 1, { e11, av: await avisos(o11) })
check('pedido pago fica "novo" para a loja preparar (não concluído)', (await status(o11)) === 'novo')

saida('\n== Situação na tela e segurança')
const st = (await dono.call('GET', `/api/v2/ads/${BID}/recebimento`)).body
check('tela mostra os últimos envios com o resultado de cada um', st.ultimosEnvios.length >= 5 && st.ultimosEnvios.some((e: any) => e.status === 'falhou') && st.ultimosEnvios.some((e: any) => e.status === 'incerto'), st.ultimosEnvios)
const vazou = logs.filter((l) => Object.values(SEG).some((v) => l.includes(v)))
check('logs sem tokens nem chaves dos provedores', !vazou.length, vazou.slice(0, 2))
const cfgRaw = JSON.stringify((await one("SELECT value FROM app_config WHERE key = 'whatsapp_envio'"))?.value)
check('segredos dos provedores cifrados no banco', !Object.values(SEG).some((v) => cfgRaw.includes(v)) && /v2:/.test(cfgRaw))
const total = await q('SELECT COUNT(*) AS n FROM orders WHERE business_id = $1', [BID])
check('nenhum pedido perdido: todos estão na lista de Pedidos', Number(total[0].n) === ((await dono.call('GET', `/api/v2/ads/${BID}/orders`)).body.items || []).length, { banco: total[0].n })

const f = res.filter((x) => !x.ok).length
saida(`\nResultado: ${res.length - f}/${res.length} verificações aprovadas.`)
server.close(); wa.close(); mp.close(); await d.close(); process.exit(f ? 1 : 0)
