# Ofertas e variações de produtos, de ponta a ponta pela tela (celular):
# dono cadastra produto em oferta e um produto com 4 variações (fotos, preços, oferta, estoque, indisponível) com prévia;
# cliente vê "A partir de", OFERTA e a foto da opção mais barata; no detalhe troca cor/tamanho (foto, preço, disponibilidade);
# adiciona duas variações (itens distintos) e finaliza; dono vê o pedido com as variações; agente de atendimento também.
# Servidor: PORT=4318 SQLITE_FILE=/tmp/ma-var.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4318'; DBF = '/tmp/ma-var.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def png(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return {'name': 'f.png', 'mimeType': 'image/png', 'buffer': b.getvalue()}
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.var@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Moda da Ana', 'categoria': 'Roupas', 'titulo': 'Moda', 'texto': 'Roupas', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'ana@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('#psave', timeout=10000)
    if pg.locator('[data-mim=manual]').count() and not pg.locator('#psave').is_visible(): pg.click('[data-mim=manual]')
    # 1) produto simples em oferta
    pg.fill('#pn', 'Boné'); pg.fill('#ppr', '50,00'); pg.fill('#pc', 'Acessórios')
    check('opção "Produto em oferta" no cadastro (desligada)', 'Produto em oferta' in pg.inner_text('#pofbox') and pg.get_attribute('[data-pof]', 'aria-checked') == 'false')
    pg.click('[data-pof]'); pg.fill('#popr', '55'); pg.wait_for_timeout(150)
    check('valida: promocional maior que o normal', 'menor que o preço normal' in pg.inner_text('#pofp'))
    pg.fill('#popr', '40,00'); pg.wait_for_timeout(150)
    check('calcula o desconto (-20%) e mostra o preço riscado', '-20%' in pg.inner_text('#pofp') and pg.locator('#pofp s').count() == 1)
    pg.set_input_files('#pf', png((30, 90, 200))); pg.wait_for_timeout(700)
    pv = N(pg.inner_text('#pprev'))
    check('prévia do card com OFERTA, preço riscado e promocional', 'OFERTA' in pv and 'R$ 50,00' in pv and 'R$ 40,00' in pv, pv)
    pg.fill('#pest', '5'); pg.click('#psave'); pg.wait_for_timeout(1500)
    check('lista do dono mostra a oferta e o estoque', 'OFERTA' in pg.inner_text('body') and 'estoque 5' in pg.inner_text('body'))
    # 2) produto com variações
    pg.fill('#pn', 'Camiseta Básica'); pg.fill('#pc', 'Camisetas'); pg.fill('#pd', 'Algodão penteado')
    VAR = [('Preta', 'P', '39,90', None, None, (20, 20, 20), True), ('Preta', 'M', '44,90', None, '3', (40, 40, 40), True), ('Branca', 'P', '42,90', '35,00', None, (245, 245, 245), True), ('Branca', 'M', '49,90', None, None, (230, 230, 230), False)]
    for i, (cor, tam, pr, promo, est, rgb, ativa) in enumerate(VAR):
        pg.click('#pvadd'); pg.wait_for_selector(f'[data-var="{i}"] [data-vf=cor]')
        V = pg.locator(f'[data-var="{i}"]')
        V.locator('[data-vf=cor]').fill(cor); V.locator('[data-vf=tamanho]').fill(tam); V.locator('[data-vf=preco]').fill(pr)
        if est: V.locator('[data-vf=estoque]').fill(est)
        V.locator('[data-vfa]').set_input_files(png(rgb)); pg.wait_for_timeout(500); V = pg.locator(f'[data-var="{i}"]')
        if promo: V.locator('[data-vof]').click(); pg.locator(f'[data-var="{i}"] [data-vf=promo]').fill(promo)
        if not ativa: pg.locator(f'[data-var="{i}"] [data-vat]').click()
    check('com variações, o preço do produto principal some e o aviso explica', not pg.locator('#ppr').is_visible() and pg.locator('[data-ofnota]').count() == 1)
    pv = N(pg.inner_text('#pprev'))
    check('prévia: "A partir de", menor preço disponível (oferta da Branca P) e OFERTA', 'A partir de' in pv and 'R$ 35,00' in pv and 'R$ 42,90' in pv and 'OFERTA' in pv and '4 opções' in pv, pv)
    pg.screenshot(path='/tmp/e2e/var_cadastro.png', full_page=True)
    pg.click('#psave'); pg.wait_for_timeout(2000)
    items = R.get(f'/api/v2/ads/{ID}/products').json()['items']; cam = next((x for x in items if x['nome'] == 'Camiseta Básica'), None)
    check('salvou UM produto com 4 variações, fotos, preços, oferta, estoque e disponibilidade', cam and len(items) == 2 and [v['rotulo'] for v in cam['variantes']] == ['Preta · P', 'Preta · M', 'Branca · P', 'Branca · M'] and all(len(v['fotos']) == 1 and v['thumb'] for v in cam['variantes']) and cam['variantes'][2]['oferta']['preco'] == 35 and cam['variantes'][1]['estoque'] == 3 and cam['variantes'][3]['ativa'] is False, cam and [(v['rotulo'], v['preco'], v['estoque'], v['ativa']) for v in cam['variantes']])
    check('lista do dono: "4 variações" e "A partir de"', '4 variações' in pg.inner_text('body') and 'A partir de' in pg.inner_text('body'))
    # 3) edição preserva variações e imagens
    ids0 = [v['id'] for v in cam['variantes']]
    pg.locator(f'[data-pe="{cam["id"]}"]').click(); pg.wait_for_selector('[data-var="3"]')
    check('editar carrega as 4 variações', pg.locator('[data-var]').count() == 4)
    pg.click('[data-vab="0"]'); pg.locator('[data-var="0"] [data-vf=preco]').fill('38,90'); pg.click('#psave'); pg.wait_for_timeout(1800)
    cam = next(x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['nome'] == 'Camiseta Básica')
    check('edição mudou só o preço e manteve ids e imagens', [v['id'] for v in cam['variantes']] == ids0 and cam['variantes'][0]['preco'] == 38.9 and all(len(v['fotos']) == 1 for v in cam['variantes']))
    check('formulário do dono sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    FOTO = {v['rotulo']: v['fotos'][0] for v in cam['variantes']}
    # 4) cliente no celular
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bruno Cliente', 'whatsapp': '+55 11 95555-0101', 'email': 'bruno.var@t.com', **U}, headers={'X-Forwarded-For': '10.6.6.6'}).ok
    pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector('[data-prod]', timeout=20000); pc.wait_for_timeout(800)
    cc = pc.locator(f'[data-prod="{cam["id"]}"]'); ct = N(cc.inner_text())
    check('catálogo: "A partir de R$ 35,00", normal riscado e OFERTA na imagem', 'A partir de' in ct and 'R$ 35,00' in ct and 'R$ 42,90' in ct and '-18%' in ct and cc.locator('.ma-phw .ma-of').count() == 1 and 'OFERTA' in cc.locator('.ma-phw .ma-of').inner_text(), ct)
    check('imagem de destaque = variação de menor preço (Branca P)', cc.locator('img').first.get_attribute('src') == FOTO['Branca · P'])
    bt = N(pc.locator(f'[data-prod="{next(x for x in items if x["nome"] == "Boné")["id"]}"]').inner_text())
    check('produto simples em oferta: R$ 50,00 riscado, R$ 40,00 e OFERTA · -20%', 'R$ 50,00' in bt and 'R$ 40,00' in bt and 'OFERTA' in bt and '-20%' in bt and 'A partir de' not in bt, bt)
    pc.wait_for_timeout(2500); pc.screenshot(path='/tmp/e2e/var_catalogo.png')
    cc.click(); pc.wait_for_selector('[data-vgrupo=cor]', timeout=8000)
    sel = lambda k: [x.inner_text() for x in pc.locator(f'[data-vgrupo={k}] [aria-pressed=true]').all()]
    pr = lambda: N(pc.inner_text('[data-preco]'))
    check('detalhe abre na opção mais barata (Branca · P, R$ 35,00 de R$ 42,90)', sel('cor') == ['Branca'] and sel('tamanho') == ['P'] and 'R$ 35,00' in pr() and 'R$ 42,90' in pr() and pc.get_attribute('[data-vimg]', 'src') == FOTO['Branca · P'], (sel('cor'), sel('tamanho'), pr()))
    check('Branca + M aparece indisponível', 'off' in pc.locator('[data-vgrupo=tamanho] [data-vv="M"]').get_attribute('class'))
    pc.screenshot(path='/tmp/e2e/var_detalhe_oferta.png')
    pc.click('[data-vgrupo=cor] [data-vv="Preta"]'); pc.wait_for_timeout(200)
    check('trocar a cor troca a foto, o nome da opção e o preço (sem oferta)', pc.get_attribute('[data-vimg]', 'src') == FOTO['Preta · P'] and pc.inner_text('[data-vrot]') == 'Preta · P' and pr() == 'R$ 38,90' and pc.locator('[data-preco] s').count() == 0, (pc.inner_text('[data-vrot]'), pr()))
    pc.click('[data-vgrupo=tamanho] [data-vv="M"]'); pc.wait_for_timeout(200)
    check('tamanho M: R$ 44,90 e "Últimas 3 unidades"', pr() == 'R$ 44,90' and 'Últimas 3 unidades' in pc.inner_text('[data-disp]'), (pr(), pc.inner_text('[data-disp]')))
    pc.click('[data-vgrupo=cor] [data-vv="Branca"]'); pc.wait_for_timeout(200)
    check('variação indisponível não pode ir ao carrinho', pc.inner_text('[data-vrot]') == 'Branca · M' and pc.locator('#padd').is_disabled() and 'Indisponível' in pc.inner_text('[data-disp]'), pc.inner_text('[data-vrot]'))
    pc.click('[data-vgrupo=tamanho] [data-vv="P"]'); pc.wait_for_timeout(150); pc.click('#padd'); pc.wait_for_timeout(500)
    pc.locator(f'[data-prod="{cam["id"]}"]').click(); pc.wait_for_selector('[data-vgrupo=cor]')
    pc.click('[data-vgrupo=cor] [data-vv="Preta"]'); pc.wait_for_timeout(150); pc.click('#pp'); pc.wait_for_timeout(150); pc.click('#padd'); pc.wait_for_timeout(500)
    pc.locator('[data-add]').nth(1 if pc.locator('[data-add]').count() > 1 else 0)
    bone_id = next(x for x in items if x['nome'] == 'Boné')['id']; pc.click(f'[data-add="{bone_id}"]'); pc.wait_for_timeout(500)
    pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
    linhas = pc.locator('[data-cart-item]'); txt = N(pc.inner_text('[data-checkout]'))
    check('carrinho: duas variações do mesmo produto como itens distintos, com foto', linhas.count() == 3 and pc.locator(f'[data-cart-item="{cam["id"]}-{ids0[2]}"] img').count() == 1 and pc.locator(f'[data-cart-item="{cam["id"]}-{ids0[0]}"]').count() == 1 and 'Cor: Branca · Tamanho: P' in txt and 'Cor: Preta · Tamanho: P' in txt, txt[:400])
    check('carrinho mostra preço normal riscado nos itens em oferta', 'R$ 42,90' in txt and 'R$ 35,00' in txt and 'R$ 77,80' in txt and 'R$ 40,00' in txt, txt[:500])
    pc.screenshot(path='/tmp/e2e/var_carrinho.png', full_page=True)
    pc.click('#cgo'); pc.wait_for_timeout(2500)
    o = C.request.get('/api/v2/orders/mine').json()['items'][0]
    check('pedido gravado com variações, atributos, foto, preço normal e aplicado (validado no servidor)', o['total'] == 152.8 and [i.get('variante') for i in o['itens']] == ['Branca · P', 'Preta · P', None] and o['itens'][0]['promocao']['precoPromocional'] == 35 and o['itens'][0]['foto'] and o['itens'][1]['qtd'] == 2 and o['itens'][2]['preco'] == 40, [(i.get('variante'), i['qtd'], i['preco']) for i in o['itens']])
    st = next(x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['nome'] == 'Boné')['estoque']
    check('estoque do boné baixou (5 → 4)', st == 4, st)
    # 5) dono vê o pedido com as variações
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1200); pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=8000); pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector('[data-oitem]', timeout=10000)
    ot = pg.inner_text('body')
    check('pedidos do dono: variação, atributos, foto e oferta', 'Camiseta Básica · Cor: Branca, Tamanho: P' in ot and 'oferta' in ot and pg.locator('[data-oitem] img').count() >= 2, ot[:300])
    # 6) agente de atendimento (página pública do agente)
    assert R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    db = sqlite3.connect(DBF); row = db.execute('select data from businesses where id=?', (ID,)).fetchone(); d = json.loads(row[0]); d.setdefault('agente', {})['expiresAt'] = (datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z'; db.execute('update businesses set data=? where id=?', (json.dumps(d), ID)); db.commit(); db.close()
    G = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); pa = G.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto(f'/a/{ID}'); pa.wait_for_selector('#acts button', timeout=15000)
    if not pa.locator('#acts [data-a=cat]').count(): pa.click('#acts [data-a=mais]')
    pa.click('#acts [data-a=cat]'); pa.wait_for_selector('.pc', timeout=8000); pa.wait_for_timeout(400)
    if pa.locator('.opt [data-c="Camisetas"]').count(): pa.click('.opt [data-c="Camisetas"]'); pa.wait_for_timeout(300)
    card = pa.locator('.pc', has_text='Camiseta Básica'); ag = N(card.inner_text())
    check('agente: card com "A partir de", riscado e OFERTA', 'A partir de' in ag and 'R$ 35,00' in ag and 'R$ 42,90' in ag and card.locator('.ofr').count() == 1, ag)
    card.locator('[data-pid]').click(); pa.wait_for_selector('.det [data-vgrupo=cor]', timeout=8000)
    pa.click('.det [data-vgrupo=cor] [data-vv="Preta"]'); pa.click('.det [data-vgrupo=tamanho] [data-vv="M"]'); pa.wait_for_timeout(200)
    check('agente: escolher Preta · M atualiza foto, preço e estoque', pa.get_attribute('.det [data-vimg]', 'src') == FOTO['Preta · M'] and N(pa.inner_text('.det [data-preco]')) == 'R$ 44,90' and 'Últimas 3' in pa.inner_text('.det [data-disp]'))
    pa.screenshot(path='/tmp/e2e/var_agente_detalhe.png')
    pa.click('.det [data-go]'); pa.wait_for_timeout(400)
    pa.locator('button:has-text("Ver carrinho e finalizar")').last.click(); pa.wait_for_selector('#cgo')
    check('agente: carrinho com a variação escolhida', 'Preta · M' in pa.inner_text('.rich:last-of-type') and N(pa.inner_text('.rich:last-of-type')).count('R$ 44,90') >= 1)
    pa.fill('#cn', 'Rui'); pa.fill('#ct', '11988887777')
    if pa.locator('[data-p=dinheiro]').count(): pa.click('[data-p=dinheiro]')
    pa.click('#cgo'); pa.wait_for_timeout(2500)
    og = R.get(f'/api/v2/ads/{ID}/orders').json()['items']; gx = next((x for x in og if x.get('guest')), None)
    check('agente: pedido com a variação e o estoque baixou (3 → 2)', gx and gx['itens'][0]['variante'] == 'Preta · M' and gx['total'] == 44.9 and next(v for v in next(x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['nome'] == 'Camiseta Básica')['variantes'] if v['rotulo'] == 'Preta · M')['estoque'] == 2, gx and gx['itens'])
    check('sem rolagem horizontal (loja e agente)', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and pa.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
