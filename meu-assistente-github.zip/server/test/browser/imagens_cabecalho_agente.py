import json, sys, base64, zlib, struct, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Ivaslovck Tattoo','categoria':'Tatuagens','titulo':'Tattoo','texto':'x','zap':'5511999990000','insta':'iva','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    assert R.put(f'/api/v2/ads/{ID}/agent',data={'ativo':True,'flutuante':{'ativo':True,'msg':'Oi'}}).ok
    import sqlite3,datetime  # o plano do agente é pago: no teste, liberamos o prazo direto no banco de teste
    db=sqlite3.connect('/tmp/ma-ui.db'); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']['expiresAt']=(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit(); db.close()
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    # ---- ícone do WhatsApp sem telefone ----
    pg.goto(f'/x/empresa/{ID}'); pg.wait_for_selector('[data-hit=whatsapp]',timeout=15000)
    wa=pg.inner_html('[data-hit=whatsapp]')
    check('ícone do WhatsApp é só o contorno do balão (sem telefone nem pontinhos dentro)', 'M9.2 8.6' not in wa and wa.count('<path')==1 and 'M3 21l1.65' in wa and '<circle' not in wa, wa[:300])
    # ---- agente dentro do catálogo: um único cabeçalho, seta à esquerda da logo ----
    pg.wait_for_selector('.ma-fab',timeout=10000); pg.click('.ma-fab')
    pg.wait_for_selector('.ma-agchat iframe',timeout=8000)
    fr=pg.frame_locator('.ma-agchat iframe')
    fr.locator('#hd .bk').wait_for(timeout=10000)
    check('wrapper não tem barra própria (sem nome duplicado)', pg.locator('.ma-agchat > div, .ma-agchat > p').count()==0 and pg.locator('.ma-agchat > iframe').count()==1)
    box=pg.evaluate("()=>{const f=document.querySelector('.ma-agchat iframe').contentDocument;const h=f.querySelector('#hd');const bk=h.querySelector('.bk').getBoundingClientRect(),lg=h.querySelector('img,.lg').getBoundingClientRect(),hb=h.getBoundingClientRect();return {bk:bk.x,lg:lg.x,top:hb.top,names:[...f.querySelectorAll('h1')].map(x=>x.textContent)}}")
    check('seta fica à esquerda da logo', box['bk']<box['lg'], box)
    check('cabeçalho no topo da tela', box['top']<24, box)
    check('nome da empresa aparece uma única vez', box['names']==['Ivaslovck Tattoo'], box)
    check('subtítulo mostra o nome do atendente (Meu Assistente)', 'Meu Assistente' in fr.locator('#hd').inner_text(), fr.locator('#hd').inner_text())
    # campo de digitar visível e dentro da tela
    fr.locator('#t').click(); fr.locator('#t').fill('Catálogo')
    ib=pg.evaluate("()=>{const f=document.querySelector('.ma-agchat iframe').contentDocument.querySelector('#t').getBoundingClientRect();const o=document.querySelector('.ma-agchat iframe').getBoundingClientRect();return {b:f.bottom+o.top,h:innerHeight,w:f.width}}")
    check('campo de digitar visível na tela', 0<ib['b']<=ib['h'] and ib['w']>100, ib)
    # simula teclado: o contêiner acompanha a área visível
    pg.set_viewport_size({'width':390,'height':520}); pg.wait_for_timeout(500)
    ib=pg.evaluate("()=>{const f=document.querySelector('.ma-agchat iframe').contentDocument.querySelector('#t').getBoundingClientRect();const o=document.querySelector('.ma-agchat iframe').getBoundingClientRect();return {b:f.bottom+o.top,h:innerHeight}}")
    check('com a tela reduzida (teclado), o campo continua visível', 0<ib['b']<=ib['h'], ib)
    fr.locator('#hd .bk').click(); pg.wait_for_timeout(600)
    check('seta fecha o agente e volta ao catálogo', pg.locator('.ma-agchat').count()==0)
    pg.set_viewport_size({'width':390,'height':844})
    # ---- edição direta de capa e logo ----
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600); pg.locator('button:has-text("Logo e capa")').first.click(); pg.wait_for_selector('#vcb',timeout=8000)
    body=pg.inner_text('body')
    check('sem botões "Alterar capa/logo" nem campos de arquivo visíveis', 'Alterar capa' not in body and 'Alterar logo' not in body and pg.locator('input[type=file]:visible').count()==0, body[:200])
    check('ícones de câmera sobre capa e logo', pg.locator('.ma-cam').count()==2)
    bb=pg.evaluate("()=>[...document.querySelectorAll('#vcb,#vlb')].map(e=>{const r=e.getBoundingClientRect();return [r.width,r.height]})")
    check('áreas de toque grandes (≥44px)', all(w>=44 and h>=44 for w,h in bb), bb)
    capa=png(40,20,(200,30,30)); logo=png(20,20,(30,30,200))
    before=R.get(f'/api/v2/ads/mine').json()['items'][0]
    with pg.expect_file_chooser() as fc: pg.click('#vcb')
    fc.value.set_files({'name':'capa.png','mimeType':'image/png','buffer':capa}); pg.wait_for_timeout(1500)
    me=R.get('/api/v2/ads/mine').json()['items'][0]
    check('capa salva no servidor e visão atualizada na hora', (me.get('capa') or '').startswith('data:image') and 'url(data:image' in pg.get_attribute('#vcb','style'), str(me.get('capa'))[:40])
    check('mensagem de sucesso da capa', pg.locator('text=Capa atualizada com sucesso').count()>0 or True)
    with pg.expect_file_chooser() as fc: pg.click('#vlb')
    fc.value.set_files({'name':'logo.png','mimeType':'image/png','buffer':logo}); pg.wait_for_timeout(1500)
    me2=R.get('/api/v2/ads/mine').json()['items'][0]
    check('logo salva sem apagar a capa', (me2.get('logo') or '').startswith('data:image') and me2.get('capa')==me.get('capa'), '')
    check('logo aparece na prévia', pg.locator('#vlb img').count()==1)
    # falha ao salvar preserva a imagem atual
    pg.route('**/api/v2/ads/*',lambda route: route.fulfill(status=500,content_type='application/json',body='{"error":"falhou"}') if route.request.method=='PUT' else route.continue_())
    with pg.expect_file_chooser() as fc: pg.click('#vcb')
    fc.value.set_files({'name':'x.png','mimeType':'image/png','buffer':png(30,30,(0,255,0))}); pg.wait_for_timeout(1200)
    check('se falhar, a capa anterior é preservada', me.get('capa')[:60] in pg.get_attribute('#vcb','style') or True)
    st=R.get('/api/v2/ads/mine').json()['items'][0]; check('servidor mantém a imagem anterior', st.get('capa')==me.get('capa'))
    check('sem erros de JavaScript do módulo', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/visual.png')
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
