# Página Descobrir (28/11): localização/raio, ofertas e ordem ficam no menu ⋮ ao lado de Produtos | Serviços.
# Atalhos para os testes abrirem o menu e usarem as mesmas opções de antes.
def menu(pg):
    if pg.get_attribute('[data-dsc-mais]', 'aria-expanded') != 'true':
        pg.click('[data-dsc-mais]'); pg.wait_for_selector('#dsc-pop:not([hidden])', timeout=5000); pg.wait_for_timeout(150)
def fechar_menu(pg):
    if pg.get_attribute('[data-dsc-mais]', 'aria-expanded') == 'true': pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
def loc_click(pg):
    menu(pg); pg.click('#dsc-pop [data-locbtn]')
def loc_txt(pg):
    return pg.text_content('[data-loclbl]') or ''
def loc_aria(pg):
    return pg.get_attribute('[data-locbtn]', 'aria-label') or ''
def ofertas(pg):
    menu(pg); pg.click('#dsc-pop [data-ofertas]')
def tem_ofertas(pg):
    menu(pg); n = pg.locator('#dsc-pop [data-ofertas]').count(); fechar_menu(pg); return n > 0
def ordenar(pg, k):
    menu(pg); pg.click(f'#dsc-pop [data-ord="{k}"]')
def ordem(pg):
    return pg.evaluate("(document.querySelector('#dsc-pop [data-ord][aria-checked=true]')||{}).dataset?.ord||''")
