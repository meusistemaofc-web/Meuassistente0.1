# Ícones exclusivos nos menus de Sua empresa (Ajustes): um ícone por opção, coerente com a finalidade, mesmo estilo e cor azul.
import re, sys, collections
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
SRC=open('../frontend/public/modules-addon.js',encoding='utf8').read()
IPB=SRC[SRC.index('const IP='):SRC.index('};',SRC.index('const IP='))]
IP=dict(re.findall(r"(\w+):'([^']*)'",IPB))
sig=lambda h: sorted(re.findall(r'(\w[\w-]*)="([^"]*)"',h))
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
ESPERADO={'Tema do catálogo':'palette','Tipo de catálogo':'grid','Categorias do catálogo':'folder','Etiquetas':'tag','Cupons de desconto':'percent','MCoins do Meu Assistente':'star','Entrega e pagamento':'card','Logo e capa':'image','Horário e abrir/fechar':'clock','Calendário e funcionamento':'calendar','Permissões de Agendamento':'shield','CRM':'users','Agente de atendimento':'bot','Relatórios e acessos':'chart','Central de Marketing':'megaphone'}
DESC={'Tema do catálogo':'Cores, fundo e layout','Tipo de catálogo':'Produtos, serviços ou os dois','Categorias do catálogo':'Crie e organize as seções','Etiquetas':'Oferta, Destaque, Black Friday…','Cupons de desconto':'Crie, distribua e acompanhe resultados','Entrega e pagamento':'Taxas, raio, Pix e Mercado Pago'}
SCAN="""()=>[...document.querySelectorAll('#ma-x .divide-y > button, #ma-x .divide-y > a, #ma-x [data-lt]')].filter(b=>b.querySelector('svg')).map(b=>{const sv=b.querySelector('svg'),sp=sv.parentElement,ls=[...b.querySelectorAll('.block')].map(x=>x.innerText.trim());return {t:ls[0]||b.innerText.trim().split('\\n')[0],d:ls[1]||'',s:sv.innerHTML,w:sv.getAttribute('width'),h:sv.getAttribute('height'),sw:sv.getAttribute('stroke-width'),c:getComputedStyle(sp).color,danger:b.getAttribute('style')||''}})"""
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    assert R.post('/api/v2/ads',data={'planId':'n4','empresa':'Loja Ícones','categoria':'Loja','titulo':'T','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}).ok
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); c.add_cookies(ctx.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500); pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(900)
        it=pg.evaluate(SCAN); por={x['t']:x for x in it}
        check(f'{nome}: validação automática sem erros', pg.evaluate('window.__maIconErros')==[], pg.evaluate('window.__maIconErros'))
        cnt=collections.Counter(x['s'] for x in it)
        check(f'{nome}: nenhum ícone repetido no menu ({len(it)} opções)', len(it)>=19 and all(v==1 for v in cnt.values()), [x['t'] for x in it if cnt[x['s']]>1])
        errados=[(t,k) for t,k in ESPERADO.items() if t not in por or sig(por[t]['s'])!=sig(IP[k])]
        check(f'{nome}: cada opção com o ícone da sua finalidade (paleta, grade, pasta, etiqueta, %, estrela, cartão, imagem, relógio…)', not errados, errados)
        check(f'{nome}: mesmo tamanho e espessura de traço em todos', all(x['w']=='20' and x['h']=='20' and x['sw']=='1.7' for x in it), {(x['w'],x['h'],x['sw']) for x in it})
        azul=pg.evaluate("()=>{const d=document.createElement('span');d.className='text-accent';document.body.appendChild(d);const c=getComputedStyle(d).color;d.remove();return c}")
        check(f'{nome}: ícones em azul (cor de destaque do sistema)', all(x['c']==azul for x in it if 'danger' not in x['danger']), {x['c'] for x in it})
        check(f'{nome}: textos e descrições preservados', all(t in por for t in ESPERADO) and all(por[t]['d']==d for t,d in DESC.items()), [(t,por.get(t,{}).get('d')) for t in DESC])
        if nome=='celular': pg.screenshot(path='/tmp/e2e/icones_ajustes.png',full_page=True)
        pg.locator('button:has-text("Tipo de catálogo")').first.click(); pg.wait_for_selector('[data-op]',timeout=8000)
        check(f'{nome}: navegação preservada (Tipo de catálogo abre a mesma tela)', pg.locator('[data-op]').count()==3)
        # Ajustes da loja (aba Ajustes dentro de Pedidos/Catálogo)
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500); pg.locator('[data-nav]',has_text='Pedidos').first.click(); pg.wait_for_timeout(1000); pg.locator('.ma-nav [data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(1000)
        it2=pg.evaluate(SCAN); cnt2=collections.Counter(x['s'] for x in it2)
        check(f'{nome}: Ajustes da loja também sem repetição', len(it2)>=8 and all(v==1 for v in cnt2.values()), [x['t'] for x in it2 if cnt2[x['s']]>1])
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
