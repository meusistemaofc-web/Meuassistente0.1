# Fase 5 — página "Minha memória": atalho no Perfil, camadas, busca por significado com o motivo, correção com versões e
# restauração, experiências, consentimento e retenção, exportação, exclusão total e layout (celular e computador).
import sys, json
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    ctx=b.new_context(viewport={'width':390,'height':860},base_url=BASE,accept_downloads=True); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Ana Teste','whatsapp':'+55 11 94444-1234','email':'ana@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    for t,k in [('Meu cachorro se chama Thor','fact'),('O veterinário do Thor é o Dr. Silva','person'),('Gosto de jazz','preference'),('Prefiro respostas curtas','preference'),('Meu carro é um Gol 2015','fact')]+[(f'Lembrete fictício número {i} sobre plantas','fact') for i in range(9)]:
        assert R.post('/api/memory',data={'action':'create','content':t,'kind':k}).ok
    r=R.post('/api/chat',data={'text':'xqz-n2-afirma me ajuda','conversationId':'mem00000-0000-4000-8000-000000000001'}).json()
    R.post('/api/chat/feedback',data={'messageId':r['assistantMessage']['id'],'nota':-1,'motivos':['muito_longa']})
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/perfil'); pg.wait_for_selector('section#memoria .ma-mem-link',timeout=20000)
    check('atalho "Abrir minha memória completa" no Perfil', pg.locator('section#memoria .ma-mem-link').count()==1)
    pg.locator('section#memoria .ma-mem-link').click(); pg.wait_for_url('**/minha-memoria'); pg.wait_for_selector('#lista .item',timeout=10000)
    check('página abre com a camada de longo prazo', 'Meu cachorro se chama Thor' in pg.inner_text('#lista') and 'Gosto de jazz' not in pg.inner_text('#lista'))
    pg.click('[data-tab=pref]'); check('aba de preferências', 'Gosto de jazz' in pg.inner_text('#lista') and 'Thor' not in pg.inner_text('#lista'))
    pg.click('[data-tab=exp]'); check('aba de experiências mostra a avaliação', 'Resposta não útil' in pg.inner_text('#lista') and 'Longa demais' in pg.inner_text('#lista'))
    pg.click('[data-tab=camadas]'); check('explica as camadas', 'Curto prazo' in pg.inner_text('#lista') and 'Experiências' in pg.inner_text('#lista'))
    pg.fill('#q','que ração dar pro meu pet?'); pg.click('#fbusca button'); pg.wait_for_timeout(800)
    rs=pg.inner_text('#res'); check('busca por significado mostra o motivo', 'Meu cachorro se chama Thor' in rs and 'mesmo assunto (pet)' in rs and 'Gol' not in rs, rs[:300])
    pg.click('[data-tab=longo]'); it=pg.locator('#lista .item:has-text("Meu carro é um Gol 2015")')
    it.locator('[data-ed]').click(); it.locator('textarea').fill('Meu carro é um Onix 2022'); it.locator('.extra .btn').click(); pg.wait_for_timeout(900)
    it=pg.locator('#lista .item:has-text("Meu carro é um Onix 2022")')
    check('correção guarda a versão anterior', it.count()==1 and '1 versão(ões) anterior(es)' in it.inner_text())
    it.locator('[data-vs]').click(); pg.wait_for_timeout(200)
    check('histórico mostra a versão com motivo', 'Meu carro é um Gol 2015' in it.inner_text() and 'corrigida pelo usuário' in it.inner_text())
    it.locator('[data-rs="0"]').click(); pg.wait_for_timeout(900)
    check('restaurar versão', pg.locator('#lista .item:has-text("Meu carro é um Gol 2015")').count()==1)
    pg.locator('[data-cfg=experiencias]').click(); pg.wait_for_timeout(800)
    check('consentimento: desligar experiências', R.get('/api/memory').json()['experiencias'] is False and pg.locator('[data-cfg=experiencias]').get_attribute('aria-checked')=='false')
    pg.select_option('#ret-exp','30'); pg.wait_for_timeout(800)
    check('retenção escolhida pelo usuário', R.get('/api/memory').json()['retencao']['experienciasDias']==30)
    with pg.expect_download() as dl: pg.click('#exportar')
    d=dl.value; caminho=d.path(); dados=json.load(open(caminho))
    check('exportação de todas as camadas', d.suggested_filename=='minha-memoria.json' and len(dados['camadas']['longoPrazo'])>=10 and len(dados['camadas']['preferencias'])==2 and len(dados['camadas']['experiencias'])>=1)
    for w,h in [(390,860),(1280,900)]:
        pg.set_viewport_size({'width':w,'height':h}); pg.wait_for_timeout(300)
        ov=pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
        check(f'sem rolagem horizontal em {w}px', ov['sw']<=ov['cw']+1, ov)
    pg.click('#apagar'); check('apagar pede confirmação', pg.locator('#apagar-aviso').is_visible() and len(R.get('/api/memory').json()['memories'])>0)
    pg.click('#apagar'); pg.wait_for_timeout(1000)
    m=R.get('/api/memory').json(); check('exclusão total (memórias e experiências)', len(m['memories'])==0 and len(m['experiences'])==0 and 'Thor' not in pg.inner_text('body'))
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/memoria.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
