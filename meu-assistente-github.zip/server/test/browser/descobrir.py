# Descobrir (/x/empresas): seletor Empresas | Produtos, feed de empresas, marketplace (2 colunas no celular), filtros, ordem,
# ofertas, busca, carregamento contínuo, localização recolhida num botão discreto (painel com cidade, automática e raio),
# filtros preservados ao alternar e abertura do produto na loja (com variações). Celular e computador.
# Servidor: PORT=4321 SQLITE_FILE=/tmp/ma-dsc.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4321'; DBF = '/tmp/ma-dsc.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor, w=400, h=300):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'JPEG', quality=70); import base64; return 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
PERTO = (-3.7319, -38.5267)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 85 94444-1234', 'email': 'ana.dsc@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(empresa, cat, dlat, capa, logo):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': cat, 'titulo': f'{empresa} no seu bairro', 'texto': 'Qualidade e preço justo', 'zap': '5585999990000'}); assert r.ok, r.text()
        i = r.json()['items'][0]['id']
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (i,)).fetchone()[0]); d['capa'] = capa; d['logo'] = logo
        db.execute("update businesses set status='ativo', expires_at=?, lat=?, lng=?, data=? where id=?", ((datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z', PERTO[0] + dlat, PERTO[1], json.dumps(d), i)); db.commit(); db.close()
        return i
    A = loja('Moda Perto', 'Roupas', 0.005, img((60, 90, 160), 800, 450), img((240, 240, 240), 120, 120))
    B = loja('Doces da Bia', 'Doceria', 0.02, img((160, 70, 90), 800, 450), img((250, 200, 210), 120, 120))
    P = lambda L, d: R.post(f'/api/v2/ads/{L}/products', data=d)
    assert P(A, {'nome': 'Camiseta Básica', 'categoria': 'Camisetas', 'variantes': [{'cor': 'Preta', 'tamanho': 'P', 'preco': 39.9, 'fotos': [img((20, 20, 20))]}, {'cor': 'Branca', 'tamanho': 'P', 'preco': 42.9, 'oferta': {'ativo': True, 'preco': 35}, 'fotos': [img((235, 235, 235))]}]}).ok
    assert P(A, {'nome': 'Boné', 'preco': 50, 'categoria': 'Acessórios', 'fotos': [img((30, 80, 200))], 'oferta': {'ativo': True, 'preco': 40}}).ok
    for k in range(24): assert P(B, {'nome': f'Doce {k + 1:02d}', 'preco': 5 + k, 'categoria': 'Doces' if k % 2 else 'Bolos', 'fotos': [img((200, 100 + k * 4, 120))]}).ok
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); RC = C.request
        assert RC.post('/api/auth', data={'action': 'signup', 'name': 'Rui Cliente', 'whatsapp': '+55 85 95555-01' + ('01' if mob else '02'), 'email': f'rui.{nome}@t.com', **U}, headers={'X-Forwarded-For': '10.9.1.' + ('1' if mob else '2')}).ok
        assert RC.put('/api/v2/me/location', data={'lat': PERTO[0], 'lng': PERTO[1]}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/empresas'); pg.wait_for_selector('[data-emp]', timeout=20000); pg.wait_for_timeout(2600)
        check(f'{nome}: seletor Empresas | Produtos com Empresas selecionado', [x.inner_text() for x in pg.locator('[data-modo]').all()] == ['Empresas', 'Produtos'] and pg.get_attribute('[data-modo=empresas]', 'aria-selected') == 'true')
        check(f'{nome}: localização recolhida, só um botão compacto ("15 km")', N(pg.inner_text('[data-locbtn]')).strip() == '15 km' and 'perto de você, raio de 15 km' in pg.get_attribute('[data-locbtn]', 'aria-label') and pg.locator('#lraio').count() == 0, pg.inner_text('[data-locbtn]'))
        c1 = pg.locator(f'[data-emp="{A}"]'); t = N(c1.inner_text())
        check(f'{nome}: card do feed com capa, logo, nome, categoria · distância, descrição e acesso à loja', c1.locator('.ma-fcov img').count() == 1 and c1.locator('img.ma-flogo').count() == 1 and 'Moda Perto' in t and 'Roupas · ' in t and ' m' in t and 'Moda Perto no seu bairro' in t and c1.locator('[data-ver-emp]').get_attribute('href') == f'/x/empresa/{A}', t)
        check(f'{nome}: empresas por proximidade (mais perto primeiro)', [x.get_attribute('data-emp') for x in pg.locator('[data-emp]').all()][:2] == [str(A), str(B)])
        if mob: pg.screenshot(path='/tmp/e2e/dsc_empresas.png')
        else: pg.screenshot(path='/tmp/e2e/dsc_empresas_pc.png')
        # painel de localização
        pg.click('[data-locbtn]'); pg.wait_for_selector('[data-locpainel]')
        check(f'{nome}: painel com localização atual, automática, cidade, raio e aplicar', all(pg.locator(s).count() == 1 for s in ['[data-loc-atual]', '#lnow', '#lai', '#lraio', '#lapl']))
        if mob: pg.screenshot(path='/tmp/e2e/dsc_localizacao.png')
        pg.select_option('#lraio', '1'); pg.click('#lapl'); pg.wait_for_function("()=>/1 km/.test(document.querySelector('[data-locbtn]').textContent)&&document.querySelectorAll('[data-emp]').length===1", timeout=10000)
        check(f'{nome}: raio de 1 km aplicado → só a empresa mais perto', pg.locator(f'[data-emp="{A}"]').count() == 1)
        pg.fill('#bq', 'moda'); pg.press('#bq', 'Enter'); pg.wait_for_timeout(800)
        # produtos
        pg.click('[data-modo=produtos]'); pg.wait_for_selector('[data-mk]', timeout=10000); pg.wait_for_timeout(500)
        check(f'{nome}: trocar para Produtos sem recarregar a página (modo na URL, raio mantido)', 'modo=produtos' in pg.url and '1 km' in pg.inner_text('[data-locbtn]') and pg.locator('[data-mk]').count() == 2 and pg.evaluate('performance.getEntriesByType("navigation").length') == 1)
        pg.click('[data-locbtn]'); pg.select_option('#lraio', '15'); pg.click('#lapl'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length>=20", timeout=10000); pg.wait_for_timeout(400)
        cols = pg.evaluate("getComputedStyle(document.querySelector('[data-mkgrid]')).gridTemplateColumns.split(' ').length")
        check(f'{nome}: grade com {2 if mob else 3} colunas', cols == (2 if mob else 3), cols)
        cam = pg.locator('[data-mk]', has_text='Camiseta Básica'); ct = N(cam.inner_text())
        check(f'{nome}: produto com variações: foto da opção mais barata, "A partir de", riscado, preço, OFERTA e a loja', 'A partir de' in ct and 'R$ 42,90' in ct and 'R$ 35,00' in ct and '-18%' in ct and cam.locator('[data-oferta]').count() == 1 and 'Moda Perto' in ct and ' m' in ct, ct)
        check(f'{nome}: 20 primeiros produtos (carregamento por partes)', pg.locator('[data-mk]').count() == 20, pg.locator('[data-mk]').count())
        pg.evaluate('document.querySelector("[data-sent]").scrollIntoView()'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===26", timeout=10000)
        check(f'{nome}: rolar carrega o resto sem repetir (26 produtos)', len(set(x.get_attribute('data-mk') for x in pg.locator('[data-mk]').all())) == 26 and '26 produtos' in pg.inner_text('[data-sent]'))
        if mob: pg.evaluate('scrollTo(0,0)'); pg.locator('#ma-x').evaluate('e=>e.scrollTo&&e.scrollTo(0,0)'); pg.wait_for_timeout(300); pg.screenshot(path='/tmp/e2e/dsc_produtos.png')
        else: pg.screenshot(path='/tmp/e2e/dsc_produtos_pc.png')
        pg.click('[data-ofertas]'); pg.wait_for_function("()=>document.querySelector('[data-ofertas]').getAttribute('aria-pressed')==='true'&&document.querySelectorAll('[data-mk]').length===2", timeout=8000)
        check(f'{nome}: filtro Ofertas', all(x.locator('[data-oferta]').count() == 1 for x in pg.locator('[data-mk]').all()))
        pg.click('[data-ofertas]'); pg.wait_for_timeout(700)
        pg.select_option('#pord', 'menor'); pg.wait_for_timeout(900)
        precos = [N(x.inner_text()) for x in pg.locator('[data-mk-preco] b').all()[:3]]
        check(f'{nome}: ordenar por menor preço', precos == ['R$ 5,00', 'R$ 6,00', 'R$ 7,00'], precos)
        pg.select_option('#pord', 'maior'); pg.wait_for_timeout(900)
        check(f'{nome}: ordenar por maior preço', N(pg.locator('[data-mk-preco] b').first.inner_text()) == 'R$ 40,00', pg.locator('[data-mk-preco] b').first.inner_text())
        pg.click('[data-cat="Bolos"]'); pg.wait_for_timeout(900)
        check(f'{nome}: filtrar por categoria', pg.locator('[data-mk]').count() == 12 and pg.get_attribute('[data-cat="Bolos"]', 'aria-pressed') == 'true')
        pg.fill('#pqi', 'doce 07'); pg.press('#pqi', 'Enter'); pg.wait_for_timeout(900)
        check(f'{nome}: pesquisar produtos', [N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()] == ['Doce 07'])
        # alternar preserva os filtros das duas modalidades
        pg.click('[data-modo=empresas]'); pg.wait_for_selector('[data-emp]')
        check(f'{nome}: voltar a Empresas mantém a busca "moda"', pg.input_value('#bq') == 'moda' and 'modo=' not in pg.url)
        pg.click('[data-modo=produtos]'); pg.wait_for_selector('[data-mk]')
        check(f'{nome}: voltar a Produtos mantém busca, categoria e ordem', pg.input_value('#pqi') == 'doce 07' and pg.input_value('#pord') == 'maior' and pg.get_attribute('[data-cat="Bolos"]', 'aria-pressed') == 'true')
        pg.fill('#pqi', ''); pg.press('#pqi', 'Enter'); pg.wait_for_timeout(600); pg.click('[data-cat=""]'); pg.wait_for_timeout(800)
        # produto abre na loja com as variações
        pg.locator('[data-mk]', has_text='Camiseta Básica').locator('.ma-mkimg').click(); pg.wait_for_selector('[data-vgrupo=cor]', timeout=15000)
        check(f'{nome}: tocar no produto abre o detalhe na loja (variações e preço da opção)', f'/x/empresa/{A}' in pg.url and 'produto=' not in pg.url and pg.get_attribute('[data-vgrupo=cor] [aria-pressed=true]', 'data-vv') == 'Branca' and 'R$ 35,00' in N(pg.inner_text('[data-preco]')))
        pg.go_back(); pg.wait_for_timeout(600)
        if '/x/empresas' not in pg.url: pg.goto('/x/empresas?modo=produtos')
        pg.wait_for_selector('[data-mk-loja]', timeout=15000)
        pg.locator(f'[data-mk-loja="{B}"]').first.click(); pg.wait_for_timeout(1500)
        check(f'{nome}: nome da loja no card leva à empresa responsável', f'/x/empresa/{B}' in pg.url, pg.url)
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
