# Botão "Sua empresa" no cabeçalho do chat: só aparece com anúncio APROVADO pelo administrador (status real no banco),
# surge sozinho após a aprovação (sem sair/entrar nem recarregar), persiste ao recarregar, some ao revogar, backend bloqueia
# reprovado/revogado e isola empresas de outros usuários. Posição: logo à direita do menu sanduíche; três pontinhos preservados.
import sys, sqlite3, time
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def setst(i,st):
    db=sqlite3.connect(DBF); db.execute('update businesses set status=? where id=?',(st,i)); db.commit(); db.close()
AD={'planId':'n1','empresa':'Studio Aurora','categoria':'Beleza','titulo':'Cortes e cor','texto':'x','zap':'5511999990000','endereco':'Rua A, 10'}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); R=c.request
    assert R.post('/api/auth',data={'action':'signup','name':'Dona Aurora','whatsapp':'+55 11 95555-1212','email':'dona@t.com','birthday':'1990-02-02','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m:errs.append('console: '+m.text) if m.type=='error' and 'Failed to load resource' not in m.text else None)
    pg.goto('/'); pg.wait_for_selector('header.nx-chat-header-bar',timeout=20000); pg.wait_for_timeout(1500)
    vis=lambda: pg.locator('.ma-hdr-emp').count()>0 and pg.locator('.ma-hdr-emp').is_visible()
    check('1. usuário sem anúncio: botão oculto', not vis() and R.get('/api/v2/ads/painel').json()['liberado'] is False)
    r=R.post('/api/v2/ads',data=AD); assert r.ok, r.text(); ID=r.json()['items'][0]['id']
    pg.evaluate('window.__maPainelEmpresa()'); pg.wait_for_timeout(600)
    check('anúncio em elaboração/aguardando pagamento: oculto', not vis() and r.json()['items'][0]['status']=='pagamento')
    setst(ID,'analise'); pg.evaluate('window.__maPainelEmpresa()'); pg.wait_for_timeout(600)
    check('2. anúncio enviado para aprovação (pendente): oculto', not vis() and R.get('/api/v2/ads/painel').json()['liberado'] is False)
    A.post(f'/api/v2/admin/ads/{ID}',data={'action':'adjust','motivo':'Envie uma foto melhor'}); pg.evaluate('window.__maPainelEmpresa()'); pg.wait_for_timeout(600)
    check('anúncio com ajustes pedidos (pendente): oculto', not vis())
    A.post(f'/api/v2/admin/ads/{ID}',data={'action':'reject','motivo':'Fora das regras'}); pg.evaluate('window.__maPainelEmpresa()'); pg.wait_for_timeout(600)
    pr=R.get(f'/api/v2/ads/{ID}/products')
    check('3. anúncio reprovado: oculto e painel bloqueado no backend (403)', not vis() and pr.status==403 and pr.json().get('code')=='painel_bloqueado', pr.status)
    assert R.delete(f'/api/v2/ads/{ID}').ok
    r=R.post('/api/v2/ads',data=AD); assert r.ok, r.text(); ID=r.json()['items'][0]['id']; setst(ID,'analise')
    pg.reload(); pg.wait_for_selector('header.nx-chat-header-bar',timeout=20000); pg.wait_for_timeout(1500)
    check('novo anúncio pendente após recarregar: oculto', not vis())
    # 4. aprovação real pelo painel administrativo → botão surge sozinho (sem recarregar nem novo login)
    ap=A.post(f'/api/v2/admin/ads/{ID}',data={'action':'approve'}); t0=time.time()
    check('admin aprova pelo painel administrativo (status real: no ar)', ap.ok and [x for x in ap.json()['items'] if x['id']==ID][0]['status']=='ativo')
    try: pg.wait_for_selector('.ma-hdr-emp',state='visible',timeout=40000); ok=True
    except Exception: ok=False
    check('4. botão aparece automaticamente após a aprovação, sem recarregar', ok, round(time.time()-t0,1))
    hp=lambda: pg.evaluate("""()=>{const h=document.querySelector('header.nx-chat-header-bar'),r=e=>{const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,h:x.height,w:x.width}};
      const m=h.querySelector('button[aria-label="Abrir menu"]'),e=h.querySelector('.ma-hdr-emp'),btns=[...h.children].filter(x=>/^(BUTTON|A)$/.test(x.tagName)),last=btns.at(-1),dot=h.querySelector('[aria-label^="Conexão"]');
      const cs=getComputedStyle(e);return {m:r(m),e:r(e),last:r(last),lastLbl:last.getAttribute('aria-label'),dot:dot?r(dot):null,txt:e.textContent,svg:e.querySelectorAll('svg,img').length,rad:cs.borderRadius,bw:cs.borderTopWidth,bg:cs.backgroundColor,ink:cs.color,fs:cs.fontSize,fw:cs.fontWeight,hx:document.documentElement.scrollWidth-innerWidth,vw:innerWidth,hr:h.getBoundingClientRect().right}}""")
    for nome,vp in [('celular',{'width':390,'height':844}),('celular pequeno',{'width':360,'height':740}),('computador',{'width':1280,'height':900})]:
        pg.set_viewport_size(vp); pg.wait_for_timeout(400); g=hp()
        cy=lambda x:(x['t']+x['b'])/2
        check(f'{nome}: "Sua empresa" só texto, sem ícone, em pílula com borda discreta', g['txt']=='Sua empresa' and g['svg']==0 and float(g['rad'][:-2])>=g['e']['h']/2-1 and g['bw']=='1px', g)
        check(f'{nome}: imediatamente à direita do menu sanduíche, alinhado na vertical', 0<=g['e']['l']-g['m']['r']<=16 and abs(cy(g['e'])-cy(g['m']))<=1.5, (g['m'],g['e']))
        check(f'{nome}: não sobrepõe o indicador nem os botões da direita; três pontinhos no extremo direito', (g['dot'] is None or g['e']['r']<=g['dot']['l']) and g['e']['r']<g['last']['l'] and g['last']['r']>=g['hr']-2 and g['hx']<=1, g)
        check(f'{nome}: dimensão proporcional ao texto', 90<=g['e']['w']<=160, g['e']['w'])
        check(f'{nome}: identidade azul — fundo azul-marinho #071123 e texto azul #417CF7 (fonte 15px/500 preservada)', g['bg']=='rgb(7, 17, 35)' and g['ink']=='rgb(65, 124, 247)' and g['fs']=='15px' and g['fw']=='500', (g['bg'],g['ink'],g['fs'],g['fw']))
        if nome=='celular': pg.screenshot(path='/tmp/e2e/sua_empresa_cabecalho_celular.png')
        if nome=='computador': pg.screenshot(path='/tmp/e2e/sua_empresa_cabecalho_computador.png')
    pg.set_viewport_size({'width':390,'height':844}); pg.wait_for_timeout(300)
    # 9. menu sanduíche e três pontinhos continuam funcionando
    pg.click('button[aria-label="Abrir menu"]'); pg.wait_for_timeout(700)
    check('menu sanduíche continua abrindo o menu lateral', pg.locator('nav.nx-menu').count()>0 and pg.locator('nav.nx-menu').first.is_visible())
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    if pg.locator('nav.nx-menu').count() and pg.locator('nav.nx-menu').first.is_visible(): pg.mouse.click(385,420); pg.wait_for_timeout(600)
    check('menu sanduíche fecha normalmente', not (pg.locator('nav.nx-menu').count() and pg.locator('nav.nx-menu').first.is_visible()))
    lbl=hp()['lastLbl']; pg.locator(f'header.nx-chat-header-bar > [aria-label="{lbl}"]').click(); pg.wait_for_timeout(600)
    check(f'três pontinhos ("{lbl}") continuam abrindo o menu de opções', pg.locator('[role="menu"],[role="menuitem"],[role="dialog"]').count()>0)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    if pg.locator('[role="menu"],[role="dialog"]').count(): pg.mouse.click(200,600); pg.wait_for_timeout(400)
    # 5. abre direto o painel da empresa vinculada
    pg.click('.ma-hdr-emp')
    pg.wait_for_selector('#ma-x',timeout=10000); pg.wait_for_timeout(1500)
    t=pg.inner_text('#ma-x')
    check('5. abre direto o painel de gestão da empresa do usuário (não o menu nem a criação de anúncio)', '/x/sua-empresa' in pg.url and 'Studio Aurora' in t and 'Criar anúncio' not in t and 'Você ainda não anunciou' not in t, (pg.url,t[:200]))
    check('painel empresarial carrega dados (relatório/gestão) sem bloqueio', R.get(f'/api/v2/ads/{ID}/report?dias=30').ok and R.get(f'/api/v2/ads/{ID}/products').ok)
    # 6. persistência ao recarregar
    pg.goto('/'); pg.wait_for_selector('header.nx-chat-header-bar',timeout=20000)
    try: pg.wait_for_selector('.ma-hdr-emp',state='visible',timeout=8000); ok=True
    except Exception: ok=False
    check('6. após recarregar, o botão continua (estado vindo do banco)', ok)
    # isolamento
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Outro User','whatsapp':'+55 11 93333-2222','email':'outro@t.com','birthday':'1992-02-02','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    check('outro usuário não vê botão e não acessa a empresa alheia pela URL/ID (404)', O.get('/api/v2/ads/painel').json()['liberado'] is False and O.get(f'/api/v2/ads/{ID}/products').status==404 and O.get(f'/api/v2/ads/{ID}/report?dias=30').status==404)
    o.close()
    # 7. revogação/suspensão pelo administrador → some sozinho e o backend bloqueia
    A.post(f'/api/v2/admin/ads/{ID}',data={'action':'end'}); t0=time.time()
    try: pg.wait_for_selector('.ma-hdr-emp',state='detached',timeout=40000); ok=True
    except Exception: ok=False
    pr=R.get(f'/api/v2/ads/{ID}/products')
    check('7. aprovação revogada: botão some automaticamente e o acesso é bloqueado (403)', ok and pr.status==403 and R.get('/api/v2/ads/painel').json()['liberado'] is False, (round(time.time()-t0,1),pr.status))
    A.post(f'/api/v2/admin/ads/{ID}',data={'action':'activate'}); pg.evaluate('window.__maPainelEmpresa()')
    try: pg.wait_for_selector('.ma-hdr-emp',state='visible',timeout=8000); ok=True
    except Exception: ok=False
    check('nova aprovação/ativação pelo admin libera de novo', ok and R.get(f'/api/v2/ads/{ID}/products').ok)
    setst(ID,'encerrado'); pg.evaluate('window.__maPainelEmpresa()'); pg.wait_for_timeout(800)
    check('anúncio vencido/encerrado: botão oculto', not vis())
    check('sem erros de JavaScript nem de console', not [e for e in errs if 'React error #418' not in e and e!='Event' and '#418' not in e], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
