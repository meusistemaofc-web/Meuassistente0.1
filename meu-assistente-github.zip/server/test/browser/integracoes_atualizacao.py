# Integrações das empresas x ATUALIZAÇÃO DOS ARQUIVOS (processo real): configura Mercado Pago (Access Token + chave do
# webhook) e SMTP próprio numa empresa; derruba o servidor; copia o código para uma pasta NOVA (como extrair um zip novo
# por cima / num lugar novo) e sobe a cópia com o MESMO banco, agora com APP_SECRET preenchido no ambiente (o caso que
# antes deixava tudo ilegível); confere que a integração continua conectada, sem pedir nova configuração, e que funciona
# de verdade (a API do Mercado Pago recebe o mesmo token). Também confere que nenhuma resposta expõe credenciais.
# Uso (sobe e derruba os próprios servidores): python3 test/browser/integracoes_atualizacao.py
import os, sys, json, time, shutil, signal, sqlite3, subprocess, threading, urllib.request, http.cookiejar, datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
RAIZ=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','..')); DBF='/tmp/ma-integ-update.db'; PORTA=4352; MPP=4353
TOK='APP_USR-5566778899-loja-atualizacao'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
VISTOS=[]
class MP(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        a=self.headers.get('Authorization',''); VISTOS.append(a)
        ok=self.path.startswith('/users/me') and a=='Bearer '+TOK
        b=json.dumps({'id':777,'nickname':'LOJA_ATUALIZADA'} if ok else {'message':'invalid'}).encode()
        self.send_response(200 if ok else 401); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b)
threading.Thread(target=HTTPServer(('127.0.0.1',MPP),MP).serve_forever,daemon=True).start()
def sobe(pasta,extra):
    env={**os.environ,'PORT':str(PORTA),'SQLITE_FILE':DBF,'MP_API_BASE':f'http://127.0.0.1:{MPP}',**extra}
    for k in ('APP_SECRET','APP_SECRET_ANTERIOR'):
        if k not in extra: env.pop(k,None)
    p=subprocess.Popen(['npx','tsx','test/serve-sqlite.ts'],cwd=os.path.join(pasta,'server'),env=env,stdout=open('/tmp/integ-upd.log','a'),stderr=subprocess.STDOUT,preexec_fn=os.setsid)
    for _ in range(120):
        try: urllib.request.urlopen(f'http://127.0.0.1:{PORTA}/api/health',timeout=1); return p
        except Exception: time.sleep(0.5)
    raise SystemExit('servidor não subiu (veja /tmp/integ-upd.log)')
def desce(p): os.killpg(os.getpgid(p.pid),signal.SIGTERM); p.wait(timeout=20)
class Cli:
    def __init__(s): s.cj=http.cookiejar.CookieJar(); s.op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(s.cj))
    def req(s,m,path,body=None):
        r=urllib.request.Request(f'http://localhost:{PORTA}{path}',data=json.dumps(body).encode() if body is not None else None,method=m,headers={'Content-Type':'application/json','Origin':f'http://localhost:{PORTA}'})
        try:
            with s.op.open(r,timeout=30) as x: return x.status,x.read().decode()
        except urllib.error.HTTPError as e: return e.code,e.read().decode()
    def j(s,m,path,body=None): st,t=s.req(m,path,body); return st,(json.loads(t) if t else {}),t
for f in [DBF,DBF+'-wal',DBF+'-shm']:
    if os.path.exists(f): os.remove(f)
open('/tmp/integ-upd.log','w').close()
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
# ---------- versão "instalada": sem APP_SECRET (chave do banco), configura as integrações
p1=sobe(RAIZ,{})
adm=Cli(); _r=adm.j('POST','/api/auth',{'action':'signup','name':'Admin Teste','email':'admin@integ.com','whatsapp':'+55 11 94444-0001',**U}); assert _r[0]==200, _r[2][:300]
dono=Cli(); assert dono.j('POST','/api/auth',{'action':'signup','name':'Dono Loja','email':'dono@integ.com','whatsapp':'+55 11 95555-0002',**U})[0]==200
st,b,_=dono.j('POST','/api/v2/ads',{'planId':'n4','empresa':'Loja Atualizada','categoria':'Doces','titulo':'Doces','texto':'Doces','zap':'5511999990000'}); assert st==200,b
BID=b['items'][0]['id']; c=sqlite3.connect(DBF); c.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); c.commit(); c.close()
st,b,t=dono.j('POST',f'/api/v2/ads/{BID}/mp',{'tok':TOK}); check('configura o Mercado Pago (Access Token)', st==200 and b.get('mpStatus')=='conectado' and TOK not in t, t[:200])
dono.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'secret','secret':'chave-webhook-atualizacao'})
st,b,t=dono.j('PUT',f'/api/v2/ads/{BID}/email',{'remetenteNome':'Loja','remetenteEmail':'vendas@loja.com','smtpProprio':True,'smtp':{'host':'smtp.loja.com','port':465,'seguranca':'ssl','usuario':'vendas@loja.com','senha':'senha-smtp-atualizacao'}})
check('configura o SMTP próprio', st==200 and b['email']['smtp']['temSenha'] and 'senha-smtp-atualizacao' not in t, t[:200])
st,b,_=dono.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'verificar'}); check('funciona antes da atualização', b.get('ok') is True and 'LOJA_ATUALIZADA' in b.get('message',''), b)
masc=dono.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'status'})[1]['mpMasked']
desce(p1)
# ---------- "atualização": código copiado para uma pasta nova + APP_SECRET agora preenchido no .env
NOVA='/tmp/ma-versao-nova'; shutil.rmtree(NOVA,ignore_errors=True)
shutil.copytree(RAIZ,NOVA,ignore=shutil.ignore_patterns('backups','*.db','__pycache__','dist'),symlinks=True)
check('versão nova em outra pasta (arquivos substituídos)', os.path.isdir(os.path.join(NOVA,'server','src')))
p2=sobe(NOVA,{'APP_SECRET':'segredo-preenchido-na-atualizacao-0123456789'})
dono2=Cli(); assert dono2.j('POST','/api/auth',{'action':'login','email':'dono@integ.com','password':'Senha@Forte123'})[0]==200
st,b,t=dono2.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'status'})
check('após atualizar: Mercado Pago continua conectado, sem reconfigurar', b.get('mpStatus')=='conectado' and b.get('mpMasked')==masc and not b.get('credencialIlegivel') and b.get('temChaveWebhook'), t[:300])
n0=len(VISTOS); st,b,_=dono2.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'verificar'})
check('após atualizar: integração funcional (a API recebe o mesmo token)', b.get('ok') is True and VISTOS[n0:]==['Bearer '+TOK], (b,VISTOS[n0:]))
st,b,t=dono2.j('POST',f'/api/v2/ads/{BID}/email',{'action':'ver'})
check('após atualizar: SMTP próprio continua configurado', b['email']['smtpProprio'] and b['email']['smtp']['host']=='smtp.loja.com' and b['email']['smtp']['temSenha'], t[:300])
_,_,t=dono2.j('GET','/api/v2/ads/mine'); _,_,t2=dono2.j('POST',f'/api/v2/ads/{BID}/mp',{'action':'status'})
check('nenhuma resposta expõe credenciais', all(x not in t+t2 for x in [TOK,'senha-smtp-atualizacao','chave-webhook-atualizacao','"mpTok"','"mpRefresh"','"v1:','"v2:']), t[:200])
adm2=Cli(); adm2.j('POST','/api/auth',{'action':'login','email':'admin@integ.com','password':'Senha@Forte123'}); st,b,_=adm2.j('GET','/api/panel')
check('painel: cofre sem credenciais ilegíveis após a atualização', (b.get('cofre') or {}).get('ok') is True, b.get('cofre'))
c=sqlite3.connect(DBF); n=c.execute("select count(*) from empresa_integracoes where business_id=?",(BID,)).fetchone()[0]; h=c.execute("select count(*) from empresa_integracoes_historico where business_id=?",(BID,)).fetchone()[0]; c.close()
check('integrações guardadas por empresa, com histórico', n==2 and h>=1, (n,h))
desce(p2); shutil.rmtree(NOVA,ignore_errors=True)
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); sys.exit(0 if all(res) else 1)
