# Mercado Pago falso (só para os testes de tela): cria Pix "pendente" e, na consulta, responde "aprovado" com a mesma referência.
# Uso: python3 mp_fake.py 4398  e servidor com MP_API_BASE=http://127.0.0.1:4398
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
PAYS={}; NXT=[7000]
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _ok(self,o):
        b=json.dumps(o).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith('/users/me'): return self._ok({'id':123,'nickname':'TESTE'})
        pid=self.path.rstrip('/').split('/')[-1]
        self._ok({'id':int(pid) if pid.isdigit() else 0,'status':'approved','external_reference':PAYS.get(pid,'')})
    def do_POST(self):
        n=int(self.headers.get('Content-Length') or 0); j=json.loads(self.rfile.read(n) or b'{}')
        NXT[0]+=1; pid=str(NXT[0]); PAYS[pid]=str(j.get('external_reference',''))
        self._ok({'id':int(pid),'status':'pending','point_of_interaction':{'transaction_data':{'qr_code':'000201PIX'+pid,'qr_code_base64':'iVBORw0KGgo='}}})
HTTPServer(('127.0.0.1',int(sys.argv[1])),H).serve_forever()
