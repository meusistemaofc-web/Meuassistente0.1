# Fase 6 — Aprendizado contínuo pela tela real.
# Painel (administrador): analisar → proposta → testar no ambiente isolado (antes × depois) → aprovar gradualmente →
# promover → reverter → restaurar versão; autodiagnóstico, evolução, relatório. Usuário: consentimento em "Minha memória".
# Os sinais são semeados direto no banco do servidor de teste (só notas e rótulos, como o sistema grava de verdade).
import sys, json, sqlite3, datetime as dt
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4311'; DB = '/tmp/ma-teste.db'
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def semear(uids):
    c = sqlite3.connect(DB, timeout=10); mid = 70000
    for u in uids:
        for i in range(8):
            mid += 1; em = (dt.datetime.utcnow() - dt.timedelta(hours=2, minutes=i)).strftime('%Y-%m-%dT%H:%M:%S.000Z'); neg = i < 4
            c.execute('INSERT INTO cognition_evals (user_id, conversation_id, message_id, path, intent, scores, overall, flags, adjustments, corrected, created_at, specialists, feedback, level2) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                      (u, 'semente', mid, 'ia', 'pergunta', json.dumps({'precisao': 90, 'naturalidade': 90, 'clareza': 90}), 70 if neg else 90, '[]', '[]', 0, em, json.dumps(['financas']), -1 if neg else 1, json.dumps({'ferramentas': [{'n': 'add_shopping_items', 'ok': i % 2 == 0}]})))
            c.execute('INSERT INTO response_feedback (user_id, message_id, conversation_id, rating, reasons, shared, snapshot, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                      (u, mid, 'semente', -1 if neg else 1, json.dumps(['muito_longa'] if neg else []), 0, '{}', 'novo', em, em))
    c.commit(); c.close()
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-0000', 'email': 'adm@t.com', 'birthday': '1980-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    uids = []
    for i in range(4):
        cx = b.new_context(base_url=BASE); r = cx.request.post('/api/auth', data={'action': 'signup', 'name': f'Usuario {i}', 'whatsapp': f'+55 11 9444{i}-1234', 'email': f'u{i}@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': f'10.9.0.{i+1}'})
        uids.append(cx.request.get('/api/me').json()['profile']['id']); cx.close()
    semear(uids)
    pg = adm.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_aprendizado'); pg.wait_for_selector('#ap6_analisar', timeout=20000)
    txt = pg.inner_text('#ap6_box')
    check('painel mostra coleta anônima e versão em uso', 'Respostas analisadas' in txt and 'Versão em uso: padrão' in txt, txt[:300])
    check('autodiagnóstico aponta a ferramenta que falha', 'add_shopping_items' in pg.inner_text('#ap6_box'), pg.inner_text('#ap6_box')[:400])
    pg.click('#ap6_analisar'); pg.wait_for_selector('[data-ap6prop]', timeout=20000); pg.wait_for_timeout(500)
    card = pg.locator('[data-ap6prop]:has-text("Respostas mais curtas em Finanças")')
    check('análise gera a proposta de estilo para Finanças', card.count() == 1 and 'qualidade.estilo.financas' in card.inner_text(), pg.inner_text('#ap6_abertas')[:400])
    pid = card.get_attribute('data-ap6prop')
    card.locator('[data-ap6="testar"]').click(); pg.wait_for_selector(f'[data-ap6prop="{pid}"] [data-ap6teste]', timeout=60000)
    card = pg.locator(f'[data-ap6prop="{pid}"]'); ct = card.inner_text()
    check('teste isolado mostra antes × depois', 'Aprovada nos testes' in ct and 'Precisão' in ct and 'Consistência' in ct and 'Sem regressão' in ct, ct[:500])
    card.locator(f'[data-ap6pct="{pid}"]').select_option('30'); card.locator('[data-ap6="aprovar-gradual"]').click(); pg.wait_for_timeout(1500)
    check('aprovação gradual para 30%', 'em teste gradual' in pg.inner_text('#ap6_box') and '30% dos usuários' in pg.inner_text('#ap6_box') and 'Liberação gradual' in pg.locator(f'[data-ap6prop="{pid}"]').inner_text())
    pg.locator(f'[data-ap6prop="{pid}"] [data-ap6="promover"]').click(); pg.wait_for_timeout(1500)
    v = A.get('/api/panel/aprendizado').json()['config']['versaoAtiva']
    check('promovida para todos', v is not None and f'Versão em uso: v{v}' in pg.inner_text('#ap6_box'), pg.inner_text('#ap6_box')[:200])
    pg.locator(f'[data-ap6prop="{pid}"] [data-ap6="reverter"]').click(); pg.wait_for_timeout(1500)
    check('reverter volta ao padrão', 'Versão em uso: padrão' in pg.inner_text('#ap6_box') and A.get('/api/panel/aprendizado').json()['config']['versaoAtiva'] is None)
    pg.locator(f'[data-ap6rest="{v}"]').click(); pg.wait_for_timeout(1500)
    check('restaurar versão pelo histórico', A.get('/api/panel/aprendizado').json()['config']['versaoAtiva'] == v and f'Versão em uso: v{v}' in pg.inner_text('#ap6_box'))
    pg.locator('[data-ap6rest=""]').click(); pg.wait_for_timeout(1200)
    check('voltar ao padrão', A.get('/api/panel/aprendizado').json()['config']['versaoAtiva'] is None)
    check('evolução semanal com 8 semanas', pg.locator('#ap6_evo tbody tr').count() == 8)
    with pg.expect_download() as d: pg.click('#ap6_rel')
    rel = open(d.value.path(), encoding='utf-8').read()
    check('relatório anônimo para baixar', d.value.suggested_filename == 'relatorio-aprendizado.md' and '## Evolução semanal' in rel and '@t.com' not in rel and 'Usuario' not in rel, rel[:200])
    pg.locator('[data-ap6sw="ativo"]').click(); pg.wait_for_timeout(1000)
    check('chave geral desliga o aprendizado', A.get('/api/panel/aprendizado').json()['config']['ativo'] is False)
    pg.locator('[data-ap6sw="ativo"]').click(); pg.wait_for_timeout(1000)
    for w, h in [(390, 860), (1280, 900)]:
        pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(400)
        ov = pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
        check(f'painel sem rolagem horizontal em {w}px', ov['sw'] <= ov['cw'] + 1, ov)
    pg.set_viewport_size({'width': 1280, 'height': 900}); pg.locator('#ap6_box').scroll_into_view_if_needed(); pg.locator('#ap6_box').screenshot(path='/tmp/e2e/aprendizado.png')
    # usuário: consentimento em "Minha memória"
    usr = b.new_context(viewport={'width': 390, 'height': 860}, base_url=BASE); U = usr.request
    assert U.post('/api/auth', data={'action': 'login', 'email': 'u0@t.com', 'password': 'Senha@Forte123'}).ok
    up = usr.new_page(); up.on('pageerror', lambda e: errs.append(str(e))); up.goto('/minha-memoria'); up.wait_for_selector('#contrib', timeout=15000); up.wait_for_timeout(600)
    check('consentimento aparece ligado por padrão', up.get_attribute('#contrib', 'aria-checked') == 'true')
    up.click('#contrib'); up.wait_for_timeout(800)
    check('usuário desliga a contribuição anônima', U.get('/api/me/inteligencia').json()['contribuirMelhorias'] is False and up.get_attribute('#contrib', 'aria-checked') == 'false')
    up.reload(); up.wait_for_selector('#contrib'); up.wait_for_timeout(600)
    check('a escolha fica salva', up.get_attribute('#contrib', 'aria-checked') == 'false')
    coleta = A.get('/api/panel/aprendizado').json()['coleta']
    check('painel conta quem não autorizou (sem identificar)', coleta['semConsentimento'] == 1 and 'u0@t.com' not in json.dumps(A.get('/api/panel/aprendizado').json()), coleta)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
