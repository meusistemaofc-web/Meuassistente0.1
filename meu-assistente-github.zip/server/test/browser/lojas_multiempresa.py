# Lojas Conectadas com várias empresas numa conta: seletor de loja (logo + nome) que vale para todas as abas, visão só da loja
# escolhida, aba "Catálogo e informações" (produtos/serviços da loja, só leitura), pedidos sem misturar lojas, avisos separados
# por empresa e aviso → registro na loja de origem. Também: detalhe do SERVIÇO no mesmo padrão do detalhe do produto.
# Celular e computador. Servidor: PORT=4327 SQLITE_FILE=/tmp/ma-lme.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, base64, os, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4327'; DBF = '/tmp/ma-lme.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor, w=600, h=400):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
DIAS = {d: {'ativo': True, 'abre': '08:00', 'fecha': '20:00'} for d in ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    def conta(nome, email, zap, ip):
        X = b.new_context(base_url=BASE); R = X.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': nome, 'whatsapp': zap, 'email': email, **U}, headers={'X-Forwarded-For': ip}).ok
        return R
    RH = conta('Hugo Central', 'hugo.lme@t.com', '+55 85 94444-9001', '10.9.9.1')
    assert RH.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    RB = conta('Bia Moda', 'bia.lme@t.com', '+55 85 94444-9002', '10.9.9.2'); RC = conta('Caio Studio', 'caio.lme@t.com', '+55 85 94444-9003', '10.9.9.3'); RK = conta('Kátia Cliente', 'katia.lme@t.com', '+55 85 94444-9004', '10.9.9.4')
    def loja(R, nome, cor, serv=False):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': nome, 'categoria': 'Variados', 'titulo': 'x', 'texto': 'x', 'zap': '5585999990000', 'endereco': 'Rua das Flores, 10'}); assert r.ok, r.text(); i = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', lat=-3.73, lng=-38.52 where id=?", (i,)); db.commit(); db.close()
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'auto', 'dias': DIAS} if serv else {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}, 'logo': durl(cor, 120, 120)}).ok
        if serv: assert R.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
        return i
    H = loja(RH, 'Central do Hugo', (30, 30, 160)); B = loja(RB, 'Moda da Bia', (200, 60, 120)); C = loja(RC, 'Studio do Caio', (40, 150, 90), True)
    assert RH.post(f'/api/v2/ads/{H}/products', data={'nome': 'Caneca da Central', 'preco': 25, 'categoria': 'Casa', 'fotos': [durl((10, 10, 200))]}).ok
    assert RB.post(f'/api/v2/ads/{B}/products', data={'nome': 'Vestido', 'preco': 120, 'categoria': 'Roupas', 'fotos': [durl((200, 60, 120))], 'oferta': {'ativo': True, 'preco': 99}}).ok
    assert RB.post(f'/api/v2/ads/{B}/products', data={'nome': 'Saia pausada', 'preco': 60, 'categoria': 'Roupas', 'fotos': [durl((90, 90, 90))]}).ok
    its = RB.get(f'/api/v2/ads/{B}/products').json()['items']; SAIA = next(x['id'] for x in its if x['nome'] == 'Saia pausada'); VEST = next(x['id'] for x in its if x['nome'] == 'Vestido')
    assert RB.post(f'/api/v2/ads/{B}/products', data={'action': 'toggle', 'id': SAIA, 'ativo': False}).ok
    assert RC.post(f'/api/v2/ads/{C}/products', data={'tipo': 'servico', 'nome': 'Ensaio fotográfico', 'preco': 200, 'modoPreco': 'fixo', 'duracao': 60, 'categoria': 'Fotos', 'descricao': 'Uma hora de ensaio com 20 fotos tratadas.', 'fotos': [durl((40, 150, 90)), durl((200, 180, 40))]}).ok
    SV = RC.get(f'/api/v2/ads/{C}/products').json()['items'][0]['id']
    for R, bid, papel in [(RB, B, 'administrador'), (RC, C, 'operador')]:
        k = RH.post('/api/v2/lojas/chaves', data={'horas': 24, 'usos': 1}).json()['chave']
        lid = R.post('/api/v2/lojas/conectar', data={'chave': k, 'lojaId': bid, 'papel': papel}).json()['id']; assert RH.post(f'/api/v2/lojas/conexoes/{lid}', data={'acao': 'aceitar'}).ok
    OB = RK.post(f'/api/v2/businesses/{B}/orders', data={'itens': [{'pid': VEST, 'qtd': 1}], 'modo': 'retirada', 'pagamento': 'dinheiro'}).json()['order']['id']
    assert RC.put(f'/api/v2/ads/{C}/permissoes-agendamento', data={'servicos': {'ativo': True, 'publico': 'todos', 'reservaMin': 0}}).ok
    dia = (datetime.date.today() + datetime.timedelta(days=2)).isoformat()
    OS = RK.post(f'/api/v2/businesses/{C}/bookings', data={'servico': SV, 'data': dia, 'hora': '10:00'}).json()['order']['id']
    OH = RK.post(f'/api/v2/businesses/{H}/orders', data={'itens': [{'pid': RH.get(f'/api/v2/ads/{H}/products').json()['items'][0]['id'], 'qtd': 1}], 'modo': 'retirada', 'pagamento': 'dinheiro'}).json()['order']['id']
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        X = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert X.request.post('/api/auth', data={'action': 'login', 'email': 'hugo.lme@t.com', 'password': U['password']}).ok
        pg = X.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/lojas-conectadas'); pg.wait_for_function("document.querySelectorAll('[data-sel-loja]').length>=4", timeout=20000); pg.wait_for_timeout(2500); pg.wait_for_function("document.querySelectorAll('[data-sel-loja]').length>=4", timeout=20000)
        chips = pg.locator('[data-sel-loja]')
        nomes = [N(x.inner_text()).split('\n')[0].strip() for x in chips.all()]
        check(f'{nome}: seletor com todas as empresas, cada uma com logo e nome', nomes[0] == 'Todas as lojas' and set(nomes[1:]) == {'Central do Hugo', 'Moda da Bia', 'Studio do Caio'} and pg.locator('[data-sel-loja] img').count() == 3, nomes)
        pg.click(f'[data-sel-loja="{B}"]'); pg.wait_for_timeout(700)
        check(f'{nome}: escolher a loja (sem sair da conta) → visão só dessa loja', pg.locator('[data-loja]').count() == 1 and pg.locator(f'[data-loja="{B}"]').count() == 1 and pg.get_attribute(f'[data-sel-loja="{B}"]', 'aria-pressed') == 'true' and f'loja={B}' in pg.url)
        check(f'{nome}: aba "Catálogo e informações" aparece para a loja escolhida', pg.locator('[data-aba=loja]').count() == 1)
        pg.click('[data-aba=loja]'); pg.wait_for_selector(f'[data-lj-info="{B}"]', timeout=10000); pg.wait_for_timeout(400)
        info = N(pg.inner_text(f'[data-lj-info="{B}"]')); itens = [N(x.inner_text()) for x in pg.locator('[data-lj-item]').all()]
        sel = pg.evaluate(f"(()=>{{const c=document.querySelector('[data-sel-loja=\"{B}\"]').getBoundingClientRect();return c.left>=0&&c.right<=innerWidth}})()")
        check(f'{nome}: a loja escolhida fica visível no seletor', sel)
        check(f'{nome}: informações da loja (nome, nível, situação, endereço, WhatsApp)', all(x in info for x in ['Moda da Bia', 'Administrador', 'No ar', 'Rua das Flores', '5585999990000']) and 'Gerenciar loja' not in info, info)
        check(f'{nome}: só os produtos dessa loja, com imagem, preço, oferta e situação (inativo sinalizado)', len(itens) == 2 and any('Vestido' in t and 'OFERTA' in t and 'Ativo' in t for t in itens) and any('Saia pausada' in t and 'Inativo' in t for t in itens) and not any('Caneca' in t or 'Ensaio' in t for t in itens) and pg.locator('[data-lj-item] .ma-oth img').count() == 2, itens)
        check(f'{nome}: somente leitura para loja de outro dono', 'Somente leitura' in pg.inner_text('#ma-x') and pg.locator('[data-lj-item] button').count() == 0)
        if mob: pg.screenshot(path='/tmp/e2e/lme_catalogo.png')
        pg.click(f'[data-sel-loja="{C}"]'); pg.wait_for_selector(f'[data-lj-info="{C}"]', timeout=10000); pg.wait_for_timeout(400)
        it2 = [N(x.inner_text()) for x in pg.locator('[data-lj-item]').all()]
        check(f'{nome}: trocar de loja na mesma aba → serviços da outra loja (sem misturar)', len(it2) == 1 and 'Ensaio fotográfico' in it2[0] and '60 min' in it2[0] and 'Operador' in pg.inner_text(f'[data-lj-info="{C}"]') and pg.get_attribute('[data-lj-item]', 'data-lj-tipo') == 'servico', it2)
        pg.click(f'[data-sel-loja="{H}"]'); pg.wait_for_selector(f'[data-lj-info="{H}"]', timeout=10000)
        check(f'{nome}: loja própria com "Gerenciar loja"', 'Gerenciar loja' in pg.inner_text(f'[data-lj-info="{H}"]') and 'Caneca da Central' in pg.inner_text('#ma-x'))
        # pedidos só da loja escolhida
        pg.click(f'[data-sel-loja="{B}"]'); pg.wait_for_timeout(500); pg.click('[data-aba=pedidos]'); pg.wait_for_selector('[data-ped]', timeout=10000); pg.wait_for_timeout(500)
        lojas_ped = {N(x.inner_text()) for x in pg.locator('[data-ped-loja]').all()}
        check(f'{nome}: pedidos só da loja escolhida', lojas_ped == {'Moda da Bia'} and pg.locator(f'[data-ped="{OB}"]').count() == 1, lojas_ped)
        pg.click('[data-sel-loja="0"]'); pg.wait_for_timeout(1200)
        check(f'{nome}: "Todas as lojas" volta ao consolidado (catálogo sai das abas)', {N(x.inner_text()) for x in pg.locator('[data-ped-loja]').all()} >= {'Moda da Bia', 'Studio do Caio', 'Central do Hugo'} and pg.locator('[data-aba=loja]').count() == 0)
        # avisos de todas as lojas separados por empresa
        pg.click('[data-aba=avisos]'); pg.wait_for_selector('[data-av-grupo]', timeout=10000); pg.wait_for_timeout(400)
        grupos = {g.get_attribute('data-av-grupo'): N(g.inner_text()) for g in pg.locator('[data-av-grupo]').all()}
        check(f'{nome}: central de avisos separada por empresa (logo, nome e contagem)', set(grupos) == {str(B), str(C), str(H)} and f'#{OB}' in grupos[str(B)] and f'#{OS}' in grupos[str(C)] and f'#{OS}' not in grupos[str(B)] and f'#{OH}' in grupos[str(H)] and pg.locator('[data-av-grupo] .ma-lcgrp img').count() == 3, {k: v[:80] for k, v in grupos.items()})
        if mob: pg.screenshot(path='/tmp/e2e/lme_avisos.png')
        pg.click(f'[data-sel-loja="{C}"]'); pg.wait_for_timeout(1000)
        check(f'{nome}: avisos filtrados pela loja escolhida', pg.locator('[data-av-grupo]').count() == 0 and pg.locator('[data-av]').count() >= 1 and all('Studio do Caio' in N(x.inner_text()) for x in pg.locator('[data-av]').all()))
        # tocar no aviso → registro na loja de origem
        pg.locator('[data-av]', has_text=f'#{OS}').first.click(); pg.wait_for_selector(f'[data-ped="{OS}"]', timeout=10000); pg.wait_for_timeout(500)
        check(f'{nome}: aviso da solicitação abre o registro na loja de origem (destacado)', 'ring-2' in pg.get_attribute(f'[data-ped="{OS}"]', 'class') and 'Studio do Caio' in pg.inner_text(f'[data-ped="{OS}"]') and f'loja={C}' in pg.url)
        # aviso do app (sino) para a loja própria leva ao pedido exato
        pg.goto(f'/x/lojas-conectadas?loja={H}&pedido={OH}'); pg.wait_for_selector(f'[data-ped="{OH}"]', timeout=15000)
        check(f'{nome}: link do aviso da loja própria abre o pedido certo', 'ring-2' in pg.get_attribute(f'[data-ped="{OH}"]', 'class'))
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        X.close()
        # ---------- detalhe do serviço no padrão do produto ----------
        V = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e)))
        pv.goto(f'/x/empresa/{B}?produto={VEST}'); pv.wait_for_selector(f'[data-detalhe="{VEST}"]', timeout=20000); pv.wait_for_timeout(500)
        prodImg = pv.locator('.ma-sheet [data-vimg]').bounding_box(); prodNome = pv.locator('.ma-sheet [data-detalhe] > p').first.evaluate("e=>getComputedStyle(e).fontSize")
        prodPreco = pv.locator('.ma-sheet [data-preco]').evaluate("e=>getComputedStyle(e).fontSize+'|'+getComputedStyle(e).fontWeight")
        V.close(); V = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e)))
        pv.goto(f'/x/empresa/{C}?servico={SV}'); pv.wait_for_selector(f'[data-detalhe="{SV}"]', timeout=20000); pv.wait_for_timeout(500)
        d = pv.locator(f'.ma-sheet [data-detalhe="{SV}"]'); t = N(d.inner_text())
        svImg = pv.locator('.ma-sheet [data-vimg]').bounding_box()
        check(f'{nome}: detalhe do serviço com a mesma imagem grande do produto (280 px) e miniaturas', round(svImg['height']) == round(prodImg['height']) == 280 and pv.locator('.ma-sheet .ma-phw-det').count() == 1 and pv.locator('.ma-sheet .ma-vthumbs img').count() == 2, (svImg, prodImg))
        check(f'{nome}: mesmo padrão de nome e preço do produto', d.locator('> p').first.evaluate("e=>getComputedStyle(e).fontSize") == prodNome and d.locator('[data-preco]').evaluate("e=>getComputedStyle(e).fontSize+'|'+getComputedStyle(e).fontWeight") == prodPreco and 'R$ 200,00' in t)
        check(f'{nome}: disponibilidade, duração, categoria e descrição', d.locator('[data-disp]').count() == 1 and 'Agendamento com aprovação da empresa' in t and '60 min' in t and 'Fotos' in t and 'Uma hora de ensaio' in t, t)
        check(f'{nome}: informações da empresa no detalhe', 'Studio do Caio' in N(d.locator('[data-serv-emp]').inner_text()) and d.locator('[data-serv-emp] img').count() == 1)
        pv.click('.ma-sheet [data-fi="1"]'); pv.wait_for_timeout(300)
        check(f'{nome}: trocar de foto pela miniatura (como no produto)', pv.locator('.ma-sheet [data-fi="1"].on').count() == 1)
        if mob: pv.screenshot(path='/tmp/e2e/lme_servico.png')
        check(f'{nome}: botão para solicitar o serviço', N(pv.inner_text('#sv_ag')) == 'Solicitar horário')
        pv.click('#sv_ag'); pv.wait_for_timeout(800)
        check(f'{nome}: solicitar abre o agendamento de sempre', pv.locator(f'.ma-sheet [data-detalhe="{SV}"]').count() == 0 and pv.locator('.ma-sheet').count() == 1 and ('Enviar solicitação' in pv.inner_text('.ma-sheet') or 'entrar' in pv.inner_text('.ma-sheet').lower()))
        V.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
