# Modo Busca de produtos e serviços no chat (tela real): "quero encontrar …" liga o modo sozinho e mostra cards compactos
# com imagem, nome, preço (oferta riscada), empresa, distância, disponibilidade e botões Comprar/Agendar + Catálogo;
# digitação errada é corrigida; esgotado aparece marcado; "Comprar" abre o produto na página da loja; refinamento
# "mais barato" na mesma conversa; conversa comum não vira busca; outro assunto desliga o modo; celular e computador.
import sys, sqlite3, datetime
DBF='/tmp/ma-teste.db'
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
PERTO={'latitude':-23.55,'longitude':-46.63}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    LOJAS={}; ITENS={}
    for k,(emp,tipo,itens) in enumerate([
        ('Doceria Mel','produtos',[{'nome':'Bolo de chocolate','preco':45,'categoria':'Bolos','descricao':'Massa fofinha'},
                                   {'nome':'Bolo de morango','preco':50,'categoria':'Bolos','oferta':{'ativo':True,'preco':42}},
                                   {'nome':'Brigadeiro gourmet','preco':4,'categoria':'Docinhos','estoque':'0'}]),
        ('Studio Bela','servicos',[{'nome':'Manicure e pedicure','preco':50,'categoria':'Unhas','tipo':'servico','duracao':60}])]):
        o=b.new_context(base_url=BASE); O=o.request
        assert O.post('/api/auth',data={'action':'signup','name':'Dono '+emp,'whatsapp':f'+55 11 9333{k}-1111','email':f'dono{k}@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
        r=O.post('/api/v2/ads',data={'planId':'n4','empresa':emp,'categoria':'Doces' if k==0 else 'Beleza','titulo':emp,'texto':'Feito com carinho','zap':'5511999990000','lat':-23.55+(k+1)*0.002,'lng':-46.63,'raio':10,'tipo':tipo}); assert r.ok, r.text()
        bid=[x for x in r.json()['items'] if x['empresa']==emp][0]['id']; LOJAS[emp]=bid
        db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),bid)); db.commit(); db.close()
        assert O.put(f'/api/v2/ads/{bid}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'dinheiro':True},'entrega':{'retirada':True}}).ok
        for it in itens:
            r=O.post(f'/api/v2/ads/{bid}/products',data={'fotos':[IMG],**it}); assert r.ok, r.text()
            ITENS[it['nome']]=[x for x in r.json()['items'] if x['nome']==it['nome']][0]['id']
        o.close()
    ultima=lambda pg: pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
    def enviar(pg,t,espera=True):
        n=pg.locator('.chat-scroll .ma-bpc').count()
        pg.fill('textarea.composer-input',t); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
        return n
    def ultimos(pg):
        # cards da última resposta (principais e semelhantes, na ordem em que aparecem)
        return pg.evaluate("()=>{const g=[...document.querySelectorAll('.chat-scroll .ma-bp')].pop();const b=g&&g.parentElement;return b?[...b.querySelectorAll('.ma-bpc')].map(x=>x.querySelector('.n').textContent.trim()):[]}")
    for nome,vp,mob,email in [('celular',{'width':390,'height':844},True,'cel@t.com'),('computador',{'width':1280,'height':900},False,'pc@t.com')]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob,geolocation=PERTO,permissions=['geolocation']); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 96666-'+('1111' if mob else '2222'),'email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
        assert R.put('/api/v2/me/location',data={'lat':-23.55,'lng':-46.63}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(800)
        # conversa comum não ativa
        enviar(pg,'oi, tudo bem?'); check(f'{nome}: conversa comum não vira busca', pg.locator('.chat-scroll .ma-bpc').count()==0, ultima(pg))
        enviar(pg,'quero encontrar bolo de chocolate')
        try: pg.wait_for_selector('.chat-scroll .ma-bpc',timeout=10000); ok=True
        except Exception: ok=False
        pg.wait_for_timeout(600)
        check(f'{nome}: "quero encontrar…" mostra cards no chat', ok and ultimos(pg)[:1]==['Bolo de chocolate'], ultimos(pg))
        check(f'{nome}: texto curto com o que foi pedido', 'Encontrei 1 produto para "bolo de chocolate"' in pg.inner_text('.chat-scroll'), ultima(pg))
        card=pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de chocolate').first; t=card.inner_text().replace('\xa0',' ')
        check(f'{nome}: card com imagem, nome, preço, empresa, distância e disponibilidade', card.locator('img').count()==1 and 'R$ 45,00' in t and 'Doceria Mel' in t and (' m' in t or ' km' in t) and 'Disponível' in t and ('Aberto' in t or 'aberto' in t), t)
        check(f'{nome}: botões Comprar e Catálogo com links reais', card.locator('a',has_text='Comprar').get_attribute('href')==f"/x/empresa/{LOJAS['Doceria Mel']}?produto={ITENS['Bolo de chocolate']}" and card.locator('a',has_text='Catálogo').get_attribute('href')==f"/x/empresa/{LOJAS['Doceria Mel']}", card.inner_html()[:300])
        mor=pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de morango').first
        check(f'{nome}: semelhante em oferta com preço riscado e desconto', mor.count()==1 and 'R$ 42,00' in mor.inner_text().replace('\xa0',' ') and mor.locator('s, del').count()>=1 and '-16%' in mor.inner_text(), mor.inner_text() if mor.count() else '')
        bx=pg.locator('.chat-scroll .ma-bp').last.locator('xpath=..')
        check(f'{nome}: "Também podem te interessar" fica sobre o grupo de semelhantes', bx.locator('.ma-bp').count()==2 and bx.locator('.ma-bp').nth(1).locator('.ma-bp-tit').inner_text()=='Também podem te interessar' and 'Também podem' not in ultima(pg), ultima(pg))
        if nome=='celular': pg.screenshot(path='/tmp/e2e/busca_produtos_chat_celular.png')
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
        # refinamento na mesma conversa
        enviar(pg,'quero encontrar bolo'); a0=ultimos(pg)
        enviar(pg,'mais barato'); check(f'{nome}: refinamento "mais barato" na mesma conversa reordena', sorted(a0)==['Bolo de chocolate','Bolo de morango'] and ultimos(pg)==['Bolo de morango','Bolo de chocolate'] and 'menor preço' in ultima(pg), (a0, ultimos(pg), ultima(pg)[:120]))
        # erro de digitação + esgotado
        enviar(pg,'onde comprar brigadero'); bg=pg.locator('.chat-scroll .ma-bpc',has_text='Brigadeiro gourmet').last
        check(f'{nome}: erro de digitação corrigido e esgotado marcado', ultimos(pg)[:1]==['Brigadeiro gourmet'] and 'entendi "brigadeiro"' in ultima(pg) and 'Esgotado' in bg.inner_text(), (ultimos(pg), ultima(pg)[:200]))
        # serviço
        enviar(pg,'procuro manicure'); sv=pg.locator('.chat-scroll .ma-bpc',has_text='Manicure').last
        check(f'{nome}: serviço com botão Agendar', ultimos(pg)[:1]==['Manicure e pedicure'] and sv.locator('a',has_text='Agendar').get_attribute('href')==f"/x/empresa/{LOJAS['Studio Bela']}?servico={ITENS['Manicure e pedicure']}", sv.inner_text())
        if nome=='computador': pg.screenshot(path='/tmp/e2e/busca_produtos_chat_computador.png')
        # outro assunto: chat comum responde, sem cards
        k=pg.locator('.chat-scroll .ma-bpc').count(); enviar(pg,'me lembra de pagar a luz amanhã às 9h')
        check(f'{nome}: outro assunto sai do modo (lembrete criado, sem cards)', pg.locator('.chat-scroll .ma-bpc').count()==k and 'Vou te lembrar' in ultima(pg), ultima(pg))
        # Comprar abre o produto na loja
        pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de chocolate').first.locator('a',has_text='Comprar').click()
        try: pg.wait_for_function("()=>{const o=document.querySelector('#ma-x');return !!o&&o.innerText.includes('Bolo de chocolate')&&location.pathname.startsWith('/x/empresa/')}",timeout=15000); ok=True
        except Exception: ok=False
        check(f'{nome}: "Comprar" abre o produto na página da loja', ok)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
