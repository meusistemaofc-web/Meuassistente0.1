# Detalhes do compromisso: WhatsApp (texto verde), Ligar (texto vermelho), textos centralizados nos botões e
# "Compartilhar" (antes "Compartilhar convite") — mesmos links e mesma função de compartilhamento; resto do painel igual.
# Servidor: PORT=4317 SQLITE_FILE=/tmp/ma-btn.db npx tsx test/serve-sqlite.ts (banco novo)
import sys
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4317'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
SHOT = sys.argv[1] if len(sys.argv) > 1 else 'depois'
CENTRO = """el=>{const r=el.getBoundingClientRect(),g=document.createRange();g.selectNodeContents(el);const t=[...g.getClientRects()].reduce((a,b)=>({l:Math.min(a.l,b.left),r:Math.max(a.r,b.right),t:Math.min(a.t,b.top),b:Math.max(a.b,b.bottom)}),{l:1e9,r:-1e9,t:1e9,b:-1e9});
 return {dx:Math.abs((t.l+t.r)/2-(r.left+r.right)/2),dy:Math.abs((t.t+t.b)/2-(r.top+r.bottom)/2),w:r.width,h:r.height,cor:getComputedStyle(el).color,ta:getComputedStyle(el).textAlign}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for tema in ['dark', 'light']:
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True, color_scheme=tema)
        R = ctx.request
        if tema == 'dark':
            assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.btn@t.com', **U}).ok
            hoje = R.get('/api/agenda').json()['today']
            aid = R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': 'Corte de cabelo', 'date': hoje, 'time': '14:00', 'cliente_nome': 'Bruno', 'cliente_telefone': '11988887777', 'location': 'Studio', 'notes': 'Trazer referência'}}).json()['item']['id']
            st = ctx.storage_state()
        else:
            ctx.close(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True, color_scheme='light', storage_state=st)
            R = ctx.request; R.patch('/api/me', data={'settings': {'theme': 'light'}})
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/agenda?tab=compromissos'); pg.wait_for_selector('.ma-cal-btn', timeout=20000); pg.wait_for_load_state('networkidle'); pg.wait_for_timeout(800)
        pg.evaluate(f'window.maApptDrawer({aid})'); pg.wait_for_selector(f'[data-appt-id="{aid}"]', timeout=10000); pg.wait_for_timeout(600)
        pg.screenshot(path=f'/tmp/e2e/btn_{SHOT}_{tema}.png')
        if SHOT != 'depois': continue
        print('==', tema)
        wa, li, sh = pg.locator('[data-appt-id] a', has_text='WhatsApp'), pg.locator('[data-appt-id] a', has_text='Ligar'), pg.locator('[data-sh]')
        check(f'{tema}: WhatsApp mantém o link', wa.count() == 1 and wa.get_attribute('href') == 'https://wa.me/5511988887777' and wa.get_attribute('target') == '_blank')
        check(f'{tema}: Ligar mantém a chamada', li.count() == 1 and li.get_attribute('href') == 'tel:+5511988887777')
        W, L, S = wa.evaluate(CENTRO), li.evaluate(CENTRO), sh.evaluate(CENTRO)
        verde = pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--nx-success').trim()")
        verm = pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--nx-danger').trim()")
        rgb = lambda h: 'rgb(%d, %d, %d)' % tuple(int(h.lstrip('#')[i:i + 2], 16) for i in (0, 2, 4))
        check(f'{tema}: texto do WhatsApp verde ({verde})', W['cor'] == rgb(verde), (W['cor'], verde))
        check(f'{tema}: texto do Ligar vermelho ({verm})', L['cor'] == rgb(verm), (L['cor'], verm))
        check(f'{tema}: textos centralizados nos botões (horizontal e vertical)', all(x['dx'] <= 1 and x['dy'] <= 1.5 for x in (W, L, S)), (W, L, S))
        check(f'{tema}: WhatsApp e Ligar com o mesmo tamanho', abs(W['w'] - L['w']) <= 1 and abs(W['h'] - L['h']) <= 0.5 and W['h'] >= 32, (W, L))
        check(f'{tema}: botão "Compartilhar" (sem "convite")', sh.inner_text().strip() == 'Compartilhar')
        t = pg.inner_text(f'[data-appt-id="{aid}"]')
        check(f'{tema}: demais informações do compromisso intactas', all(x.lower() in t.lower() for x in ['Compromisso nº', 'Corte de cabelo', 'Bruno', '(11) 98888-7777', 'Studio', 'Trazer referência', 'Cliente no Meu Assistente', 'Editar', 'Fechar']), t[:400])
        check(f'{tema}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if tema == 'dark':
            pg.evaluate("()=>{window.__ab=[];window.open=(u)=>{window.__ab.push(u);return null}}")
            sh.click(); pg.wait_for_timeout(1500)
            d = pg.evaluate('window.__ab')
            check('Compartilhar continua enviando o convite do compromisso pelo WhatsApp do cliente', len(d) == 1 and d[0].startswith('https://wa.me/5511988887777?text=') and 'http' in d[0][30:], d)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
