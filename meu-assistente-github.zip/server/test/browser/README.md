# Testes de navegador (Playwright + Chromium)

Complementam `npm test` (que cobre API, banco, motores e regras) verificando o que só aparece no navegador.

| Arquivo | O que comprova |
|---|---|
| `compartilhar_itens.py` | Compartilhamento de produtos e serviços: ícone nos detalhes, mensagem com a variação escolhida, oferta e serviço, 6 canais, link aberto sem conta (variação, visita), item indisponível, painel (prévia, validação, regra por categoria, restaurar, desligar) e ajustes da empresa. |
| `lojas_multiempresa.py` | Várias empresas numa conta: seletor de loja (logo e nome) em todas as abas, Catálogo e informações (só leitura), pedidos e avisos por loja, avisos separados por empresa, aviso → registro; detalhe do serviço no padrão do produto. |
| `oferta_detalhe.py` | Etiqueta OFERTA no detalhe do produto a 14 px (celular) e 18 px (telas maiores) do canto, com estilo idêntico; cards do catálogo a 6 px; imagem e botão de fechar intactos. |
| `pedidos_imagens.py` | Imagem de cada item nos pedidos (cor conferida contra a foto do item): Sua empresa → Pedidos (lista e Detalhes), 1 e vários itens, variação, item sem foto (espaço reservado), quantidade × preço e total, Solicitações (lista e Detalhes), central de Lojas Conectadas e pedido antigo × novo após editar a foto. |
| `produtos_interruptor.py` | Painel de produtos: interruptor ativo/inativo no canto superior direito (sem "Pausar"), Editar · Duplicar · Excluir em faixa própria, nada sobre nome/preço/descrição (320 px, 390 px e computador), desligar/religar refletido no banco e na vitrine na hora, estado ao recarregar e clique duplo. |
| `modal_produto_rolagem.py` | Modal de detalhes do produto: produto simples continua compacto e idêntico; com faixas/opções/variantes cabe na tela e rola por dentro, × visível, quantidade/Adicionar fixos na base sem sobrepor, rolagem mantida ao tocar faixa/opção/+, página de trás travada. Celular 390, 360×640 e computador. Porta 4344, banco `/tmp/ma-mpr.db`. |
| `fontes_chat.py` | Fontes nas respostas do chat: corpo sem URL/domínio/"Fonte:"; ícones pequenos e clicáveis acima do horário, no canto direito; abrem a página original em nova aba; inicial do site sem favicon; mensagem sem fonte inalterada. Celular e computador. Porta 4345, banco `/tmp/ma-fontes.db`. |
| `indicador_atividade.py` | Indicador de atividade do chat: um só, compacto (três pontinhos azuis + texto da etapa real), sem card. Confere: etapas na ordem (ferramenta → organiza), "Executando tarefa…", tarefa longa sem "Processando seu pedido", mesmo indicador ao recarregar no meio, erro, nunca dois indicadores, sem piscar, sem fundo/borda/sombra. Celular e computador. Porta 4346, banco `/tmp/ma-ind.db`. |
| `ditado_ao_vivo.py` | Ditado com transcrição AO VIVO (reconhecimento do aparelho simulado na API do navegador): texto surgindo no campo durante a fala, envio imediato do texto já transcrito (uma mensagem), parar e corrigir, cancelar, pausas de até 6 s, microfone bloqueado, reconhecimento que não responde (troca para o servidor). Celular e computador. Porta 4348, banco `/tmp/ma-dav.db`. |
| `treino_chat.py` | Treino e Acompanhamento: opção no ⚡ com ícone, coleta gradual até o plano salvo e formatado, lembretes na Agenda, "Meu treino" em conversa nova, registro e histórico, aviso `/?treino=hoje` abrindo o treino do dia, painel (ativo, visível, ordem), Chat normal e Busca intactos; celular e computador. Servidor: `PORT=4350 SQLITE_FILE=/tmp/ma-treino.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `busca_fotos_ampliadas.py` | Busca do chat: foto do card amplia sobre a conversa (sem navegar), fundo escuro, Fechar/Esc/tocar fora, galeria (setas, deslizar, miniaturas, teclado), zoom (toque duplo, pinça, roda) e arrastar, foto original sem corte, posição da conversa e foco restaurados, Comprar e Catálogo intactos; celular, tablet e computador. Servidor: `PORT=4351 SQLITE_FILE=/tmp/ma-fotos.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `integracoes_atualizacao.py` | Integrações das empresas x atualização dos arquivos (processos reais): configura Mercado Pago e SMTP próprio, derruba o servidor, copia o código para uma pasta nova e sobe com o mesmo banco e APP_SECRET recém-preenchido; tudo continua conectado e funcional, sem reconfigurar, e nada é exposto. Sobe os próprios servidores (portas 4352/4353): `python3 test/browser/integracoes_atualizacao.py` |
| `vitrine_servicos.py` | Vitrine pública: aba Serviços igual a Produtos, detalhe do serviço e empresa, pesquisa/filtros/ordem, compartilhar a vitrine e cada empresa/produto/serviço (WhatsApp, nativo, copiar), links abertos de fora sem conta, localização do visitante, prévia do link e conta logada. Servidor com `GEOCODER_URL` do `geocoder_fake.py`. |
| `mcoins_variacao_aparencia.py` | Mercado → MCoins com variação % em 24 h (sobe verde, cai vermelho, sem mudança +0,00%) no formato das cotações; Painel → Aparência com título em cima e Pequeno/Médio/Grande embaixo. |
| `modos_inteligentes.py` | Botão ⚡ Modos à direita do + sem alterar o campo (comparado com o campo sem o botão), seletor acima do campo, Consultor de Marketing (objetivos, coleta, plano, proposta → Central como rascunho), chat normal, campo aberto e bloqueio para anúncio básico. |
| `marketing_empresas.py` | Central de Marketing das empresas: opção só com a chave do administrador, ativar para meus clientes, campanha completa (imagem, público, data/horário, encerramento), rascunho, edição, cancelamento, detalhes, desligar/suspender sem perder dados, validar e retomar, oferta do cliente com empresa remetente e "não quero mais receber". Servidor com SESSION_SECRET=e2e-mkt. |
| `catalogo_cabecalho.py` | Catálogo público: capa separada da logo, logo à esquerda com nome/categoria · distância/status, ícones outline brancos sem círculo (links preservados), cabeçalho compacto, telas pequenas, tema claro e catálogo intacto. |
| `tema_catalogo_agente.py` | O tema da empresa (5 presets + cantos retos) vale no catálogo, na janela do produto e no chat do agente; ícones de contato; sincronização entre telas; sem resíduos ao trocar de tema. |
| `cerebro_painel.py` | Aba "Cérebro e busca": cadastrar, conflito com confirmação, regra executável criada pela tela e cumprida no chat, detalhes, desativar/reativar, conflitos e uso recente. |
| `produtos_endereco.py` | Aba Produtos: salvar sem variações (campo opcional, sem "Assignment to constant variable"), com variações, foto salva e toast de sucesso; formulário de anúncio: localização automática preenche o endereço, que continua editável. |
| `imagens_cabecalho_agente.py` | Celular: ícone do WhatsApp sem telefone, agente com cabeçalho único no topo (seta à esquerda da logo), campo de digitar visível com teclado, edição direta de capa/logo com salvamento imediato e imagem anterior preservada se falhar. |
| `tipo_catalogo_sinal.py` | Ajustes → Tipo de catálogo (3 opções, salvar, nada apagado), formulário só com o tipo permitido, itens ocultos marcados, página pública acompanha. |
| `atalhos_agente.py` | Atalhos do Agente: ordem, lista vertical, transparentes com borda sutil, Ver mais/menos, somem após a ação ou mensagem, reaparecem em nova conversa, sem clique duplicado. |
| `capacidades_painel.py` | Cérebro → Capacidades da inteligência: categorias, status (ativo/inativo/pendente/em desenvolvimento), conteúdo, filtros, busca, cadastro novo aparecendo sozinho e módulo desligado refletido. |
| `composer_novo.py` | Campo de digitação: compacto, expandido ao tocar, mensagens curtas/longas, envio (botão e Enter, sem duplicar), anexos (card acima do campo: Câmera e Fotos e arquivos), microfone, teclado virtual, 3 tamanhos de tela e ausência do botão Auto. |
| `contadores_sincronizados.py` | Contadores de pedidos/agendamentos: menu lateral e Sua empresa com o mesmo número, tempo real, celular e computador, zerado e isolamento. |
| `importar_cardapio.py` | Importar cardápio com IA: opções manual/IA, envio, erro de leitura, DOCX, revisão por categoria, duplicidade, publicação, histórico, desfazer e manual intacto. |
| `acoes_mensagens.py` | Ações das mensagens: respostas da IA com Copiar → Curtir → Não curtir (uma linha, só ícones cinza, sem fundo ou borda, sem editar), cópia integral, avaliações sem duplicar, Editar do usuário preservado (celular e computador) |
| `central_agentes.py` | Fase 10: Central de Agentes (acesso restrito, visão geral e consumo, 7 agentes especializados, raciocínio, validação e fluxo, liga/desliga, autonomia, permissões, tarefas com etapas e dependências sem conteúdo de conversa, empresas, limites, chave geral, falhas, atalho no painel), no celular e no computador |
| `icones_ajustes.py` | Ajustes de Sua empresa: ícones únicos, coerentes com a finalidade, mesmo tamanho e traço, azuis, textos preservados, navegação, Ajustes da loja e validação sem erros (celular e computador) |
| `permissoes_agendamento.py` | Permissões de Agendamento: dono configura (duas opções, público, antecedência, reserva, aprovador), cliente solicita serviço e agenda pedido no app, aprovador vê, sugere e detalha, cliente aceita a sugestão, dono aprova e recusa, aba Pedidos, visitante do agente solicita, acompanha após recarregar e aceita a sugestão, carrinho do agente com pedido agendado, desligado volta ao fluxo antigo |
| `carrossel_catalogo.py` | Catálogo do chat da empresa em carrossel (celular, tablet, computador; servidor de UI `DBP=/tmp/ma-ui.db`): largura dos cards, próximo card parcial, imagem 4:3, mesma altura, botão ≥ 44 px, nome/descrição/preço/condições, indicador e setas, deslize, arraste com mouse sem disparar o botão, teclado, categorias separadas com posição preservada, Agendar e Adicionar preservados, empresa fechada e cadastros intactos |
| `laboratorio_inteligencia.py` | Fase 9: atalho no painel; visão geral (real × estimativa × experimental); Arena (rodar, resultado, desafio personalizado, dado pessoal recusado); simulador com avaliação; especialista criado → testado → enviado → aprovado gradual; cópia experimental; experimento atual × experimental → proposta; editar e arquivar; diagnóstico; evolução; contínuos com relatório; auditoria; usuário comum sem acesso; sem rolagem lateral. |
| `autonomia_operacional.py` | Fase 8: objetivo pelo chat executado e conferido; exclusão exige autorização explícita; página Minhas execuções (código errado não autoriza, autorizar, etapas conferidas, desfazer, modo cauteloso, cancelar, link destacado); painel (indicadores, nível mínimo não reduzível, elevar nível) e layout. |
| `inteligencia_preditiva.py` | Fase 7: atalho no Perfil, página Previsões e sugestões (fato × estimativa, urgência, consolidação, lacunas), reações que não voltam, preferências (categoria, frequência, silêncio, prioridade), "pedir no chat" sem enviar, nenhum registro alterado, painel do administrador (indicadores, validação, tipos de sinal) e layout. |
| `aprendizado_continuo.py` | Fase 6: painel do aprendizado (coleta, autodiagnóstico, análise → proposta → teste isolado antes × depois → aprovação gradual → promover → reverter → restaurar versão), relatório, chave geral, layout e consentimento do usuário em Minha memória. |
| `compromissos.py` | Compromissos: três iguais na Agenda → tocar no 2º abre e edita só o 2º; chat cria com cliente/valores/sinal → aparece em Configurações → editado lá → chat responde atualizado; sinal em % e R$ (prévia), ambiguidade, observação, sem horário e nenhuma duplicação. |
| `memoria_evolutiva.py` | Fase 5: atalho no Perfil, página Minha memória (camadas, busca por significado com motivo, correção com versões e restauração, experiências, consentimento, retenção, exportação, apagar tudo com confirmação) e layout em celular e computador. |
| `inteligencia_n2.py` | Nível 2: 👍/👎 nas respostas do chat (só no assistente, estilo discreto, desfazer, motivos, preferência pessoal, estado após recarregar), quadro do painel (11 chaves, bateria, oportunidade → Laboratório) e layout sem rolagem horizontal. |
| `cerebro_cognitivo.py` | Cérebro cognitivo: o chat não afirma ação não confirmada, resposta avaliada (só notas), painel (chave, ajustes, números), cartão em Capacidades e volta ao comportamento anterior quando desligado. |
| `aprendizagem_adaptativa.py` | Aprendizagem adaptativa: correção no chat sem anunciar memória, recuperação em nova conversa, chave global do administrador e fila de revisão (aprovar, editar, rejeitar) no Cérebro. |
| `moedas_bonus.py` | MCoins: biblioteca (10 modelos, ampliar, selecionar), personalização com prévia, publicar, distribuir, trocar modelo sem perder saldo, Mercado (3ª categoria), carteira e checkout com desconto. |
| `mcoins_integradora.py` | Meu Assistente como emissor: opção na criação da moeda, central de vínculos, aceite pela empresa, checkout com a moeda, pausa pelo admin, carteira e rastreio emissora/vinculada. |
| `crm.py` | CRM de Sua empresa: indicadores, cliente criado por pedido, lead sem duplicar, interação, oportunidade, funil (mover e perda com motivo), tarefas, inteligência, configurações e celular. |
| `analista_negocio.py` | Analista de negócios: cartões de resumo, comparativo e análise no chat com dados reais, "sem dado" ≠ zero, celular e negação a quem não é dono. |
| `mcoins_percentual.py` | Indicador de distribuição das MCoins em %, atualização após distribuir e absolutos no detalhe |
| `vitrine_historico.py` | Cards "/" como mensagens link_card: ordem cronológica, persistência por conversa, voltar/atualizar, isolamento entre conversas |
| `mcoins_central.py` | Central MCoins: chaves desligadas, código único, config/auditoria, compra pendente→confirmação, permissões individuais, busca por código |
| `mcoins_envio.py` | Enviar MCoins (admin): pesquisa, seleção, prévia/confirmação/cancelamento, crédito, histórico; moeda 3D, aviso com partículas, saldo animado e movimento reduzido. |
| `cupons.py` | Cupons: empresa cria/pausa/distribui, vitrine da loja, checkout aplica/remove e bloqueia reuso, área do cliente, resultados e visão do administrador. |
| `inicio_sua_empresa.py` | Início de "Sua empresa": Vendas, Relatórios e Dados de acessos no lugar da prévia do catálogo; navegação e catálogo preservados |
| `vitrine_links.py` | Vitrine de Links: cadastro no painel, menu `/` no chat e no agente, filtro, card, link externo, desativar, mensagens comuns |
| `laboratorio_ia.py` | Laboratório de IA: chat de correção → proposta, testes em simulação, aprovação, publicação, desativação, simulador e histórico |
| `comprovante_sem_ia.py` | Comprovantes **fotografados** com todas as IAs desligadas, de ponta a ponta: sobe a central REAL (Python + Tesseract) e o servidor (SQLite), envia pelo chat foto torta, foto de lado, print, foto sem data e foto sem direção; confere o resumo para confirmação, as perguntas do que falta, Registrar/Cancelar, o lançamento no financeiro, o bloqueio de duplicado, o painel (IA → Leitura de comprovantes) e que nenhuma IA externa foi chamada. Uso: `python3 test/browser/comprovante_sem_ia.py` (na pasta server). |

## Como rodar
```bash
cd server
PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts &   # servidor de teste (SQLite, IA de mentira)
pip install playwright && playwright install chromium
python3 test/browser/tema_catalogo_agente.py    # troque BASE no topo do arquivo se usar outra porta
python3 test/browser/cerebro_painel.py
python3 test/browser/produtos_endereco.py
python3 test/browser/imagens_cabecalho_agente.py
python3 test/browser/tipo_catalogo_sinal.py
python3 test/browser/atalhos_agente.py
python3 test/browser/capacidades_painel.py
python3 test/browser/composer_novo.py
python3 test/browser/contadores_sincronizados.py
python3 test/browser/acoes_mensagens.py
python3 test/browser/central_agentes.py
python3 test/browser/icones_ajustes.py
python3 test/browser/permissoes_agendamento.py
DBP=/tmp/ma-ui.db python3 test/browser/carrossel_catalogo.py
python3 test/browser/laboratorio_inteligencia.py
python3 test/browser/autonomia_operacional.py
python3 test/browser/inteligencia_preditiva.py
python3 test/browser/aprendizado_continuo.py
python3 test/browser/compromissos.py
python3 test/browser/memoria_evolutiva.py
python3 test/browser/inteligencia_n2.py
python3 test/browser/cerebro_cognitivo.py
python3 test/browser/aprendizagem_adaptativa.py
python3 test/browser/importar_cardapio.py
python3 test/browser/moedas_bonus.py
python3 test/browser/mcoins_integradora.py
python3 test/browser/crm.py
python3 test/browser/analista_negocio.py
python3 test/browser/vitrine_historico.py
python3 test/browser/mcoins_central.py
python3 test/browser/mcoins_envio.py
python3 test/browser/cupons.py
python3 test/browser/laboratorio_ia.py
python3 test/browser/vitrine_links.py
python3 test/browser/agenda_ia.py
python3 test/browser/botoes_rapidos_posicao.py
python3 test/browser/descricoes_expansiveis.py
python3 test/browser/botoes_rapidos_conversa.py
python3 test/browser/vitrine_temporaria.py
python3 test/browser/preco_quantidade.py
python3 test/browser/links_fundos_botoes.py
python3 test/browser/pedidos_modalidade.py
python3 test/browser/cupons_destino.py
python3 test/browser/apresentacao.py
```
Cada script cria o administrador (primeiro cadastro), a empresa e os dados de que precisa: use um banco **novo** a cada execução.
| `apresentacao.py` | Página de apresentação `/conheca`: página nova (não o app antigo) com prévia de compartilhamento, demonstração da abertura (rotina e empresa), abas da rotina (teclado), "Experimente", pedido do cliente ao painel (faixas, entrega × retirada, ações por modalidade, andamento), agente, Página de Links, Lojas Conectadas, planos e preço do agente iguais ao servidor, módulo desligado some, conta logada, navegação interna do app, 320/390/1280 px e movimento reduzido. Servidor: `PORT=4341 SQLITE_FILE=/tmp/ma-apres.db npx tsx test/serve-sqlite.ts` (banco novo). |
| `incentivos_carrinho.py` | Incentivos do carrinho: painel (criar com prévia, pausar/reativar), faixa de progresso na vitrine atualizando a cada produto, fotos no carrinho, frete grátis ao aumentar, 10% na retirada, total recalculado, pedido com o benefício aplicado pelo servidor, Meus pedidos e painel; celular e computador. Servidor: `PORT=4340 SQLITE_FILE=/tmp/ma-inc.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `ditado_chat.py` | Ditado pelo microfone (microfone simulado do Chromium + Whisper falso em 4398): texto no campo sem enviar nada, edição e envio como texto (sem áudio), Gravar de novo, Descartar, Cancelar, fala em espanhol, falha da transcrição, microfone bloqueado; celular e computador. Servidor: `WHISPER_URL=http://127.0.0.1:4398 PORT=4338 SQLITE_FILE=/tmp/ma-dit.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `tarefas_segundo_plano.py` | Pedidos em segundo plano (porta 4341, banco `/tmp/ma-tsp.db`): "Processando… Pode sair do chat", saída para outra página com aviso e link para a conversa, recarregar no meio (cartão depois da última mensagem, resultado sozinho, sem aviso), navegação interna, falha com aviso, cartão visível e Tentar de novo; celular e computador |
| `botoes_rapidos_posicao.py` | Botões rápidos do chat no visual da referência (porta 4311, banco novo): no máximo 3, vertical, à esquerda, logo acima do campo; ícone cinza sem fundo e texto branco; "Lojas" em azul; comando real ao tocar; cores, ícone, ativo/inativo e desligar vindos do painel; celular (2 tamanhos) e computador |
| `botoes_rapidos_painel.py` | Painel → Botões do chat (porta 4342, banco `/tmp/ma-qbpainel.db`): prévia real com o campo de digitação oficial atualizando na hora (texto, ícone, cores, destaque azul, posição, ativar/desativar, mostrar/ocultar, limite de 3, ação pronta), tocar na prévia sem enviar, validação, salvar e aplicar na hora (outra aba e usuário comum), restaurar padrão; computador e celular (prévia fixa no topo) |
| `logo_central_chat.py` | Tela inicial do chat (porta 4311, banco novo): logo M no centro exato com os botões visíveis (celulares e computadores), estável durante o carregamento e quando os botões somem, desligados no painel; telas baixas e teclado aberto sem encostar nos botões e de volta ao centro ao fechar |
| `admin_secoes.py` | Administração em seções (porta 4343, banco novo): Visão Geral com indicadores reais, menu de 10 seções com estado, todas as subabas abrem sem erro, Resumo de seção, "Cérebro e busca" separado, Rastreamento (detalhe e filtros), Arquitetura, links `?aba=`/`?secao=`, Esc, celular e computador |
| `_admin.py` | Auxiliar dos testes: abre uma aba da Administração pelo menu de seções → subaba (`aba(pg, 'ia')`) |
| `idioma_guia_chat.py` | Motor de respostas: explicação "como registro um gasto?" com passos e botão reais (sem marcadores técnicos), "sim" que pede os dados e depois registra; preferência de idioma ("sempre me responda em inglês") salva na memória, valendo em outra conversa, com explicação traduzida e botão preservado, e o apagar; conferência dos passos nas telas reais (menu, Módulos, Financeiro → + Adicionar, + Compromisso, + Lembrete, Nova tarefa…); celular e computador. Servidor: `PORT=4336 SQLITE_FILE=/tmp/ma-idg.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `checkout_localizacao.py` | Checkout com entrega e "Usar minha localização atual" (geolocalização real do navegador): preenche sozinho com permissão já concedida, confirmação, Editar, Usar outro endereço, sem número, permissão negada, aparelho sem localização, endereço não encontrado, fora da área, taxa por km pelo ponto e "Ver no mapa" no painel da loja; celular e computador. Servidor: `python3 test/browser/geocoder_fake.py 4399 & GEOCODER_URL=http://127.0.0.1:4399 PORT=4335 SQLITE_FILE=/tmp/ma-cloc.db npx tsx test/serve-sqlite.ts` (banco novo) |
| `busca_produtos_chat.py` | Busca de produtos e serviços no chat: "quero encontrar…" liga o modo e mostra cards reais (imagem, preço/oferta riscada, empresa, distância, disponibilidade, Comprar/Agendar, Catálogo), grupo "Também podem te interessar", digitação corrigida, esgotado marcado, "mais barato" na mesma conversa, conversa comum e outro assunto sem cards, Comprar abre o produto na loja; celular e computador. Servidor: `PORT=4311 SQLITE_FILE=/tmp/ma-teste.db` (banco novo) |
| `pedidos_modalidade.py` | Pedido por modalidade: checkout de retirada (endereço completo, horário, mapa, WhatsApp com mensagem) e de entrega (endereço, aviso de acompanhamento e de contato) sem misturar; Meus pedidos com o cartão de retirada e as etapas da entrega (data e hora) atualizando sozinhas; painel só com a ação da modalidade. Celular e computador. Servidor: `PORT=4333 SQLITE_FILE=/tmp/ma-pmod.db npx tsx test/serve-sqlite.ts` (banco novo). |
| `cupons_destino.py` | Cupons e Vouchers com destino: painel (destino na criação, planos somem para o agente, lista, filtro, histórico por fluxo) e ativação do Agente no celular (recusa de cupom de anúncios, desconto com preço riscado, remover, "ambos" 100% → ativar sem pagamento). Servidor: `PORT=4334 SQLITE_FILE=/tmp/ma-cdst.db npx tsx test/serve-sqlite.ts` (banco novo). |
| `preco_quantidade.py` | Preço por quantidade: cadastro (interruptor, faixas, validação na hora, prévia), selo no card, quadro "Compre mais, pague menos" no detalhe (toque na faixa, + e −), carrinho com − / + recalculando preço unitário, desconto e total (4 → 5 → 10 → 9 un.), pedido igual à tela e rótulo no painel da empresa; celular e computador. Servidor: `PORT=4331 SQLITE_FILE=/tmp/ma-pq.db npx tsx test/serve-sqlite.ts` (banco novo). |
| `links_fundos_botoes.py` | Página de Links: 20 modelos de fundo (miniaturas, filtros por estilo, um clique aplica na prévia), formato dos botões (quadrado, suave, arredondado, pílula, folha) medido na prévia e na página pública, publicar, fundo manual tira o modelo, preferências salvas e outra empresa intacta; celular e computador. Servidor: `PORT=4332 SQLITE_FILE=/tmp/ma-lkf.db npx tsx test/serve-sqlite.ts` (banco novo). |
| `personalizacao.py` | Personalizar Agente de Atendimento (6 interruptores com salvamento automático, prévia real do atendimento, página pública sem os botões ocultos, recurso preservado quando o cliente pergunta) e Personalizar Página de Links (capa, logotipo, título, descrição, todos os botões e cada botão, posição e tamanho do logotipo, prévia antes de publicar, página pública, ocultar sem apagar), no celular e no computador, e isolamento entre empresas. Servidor: `PORT=4313 SQLITE_FILE=/tmp/ma-pz.db npx tsx test/serve-sqlite.ts` (banco novo). |
