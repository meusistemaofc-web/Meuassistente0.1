# Testes de navegador (Playwright + Chromium)

Complementam `npm test` (que cobre API, banco, motores e regras) verificando o que só aparece no navegador.

| Arquivo | O que comprova |
|---|---|
| `tema_catalogo_agente.py` | O tema da empresa (5 presets + cantos retos) vale no catálogo, na janela do produto e no chat do agente; ícones de contato; sincronização entre telas; sem resíduos ao trocar de tema. |
| `cerebro_painel.py` | Aba "Cérebro e busca": cadastrar, conflito com confirmação, regra executável criada pela tela e cumprida no chat, detalhes, desativar/reativar, conflitos e uso recente. |
| `produtos_endereco.py` | Aba Produtos: salvar sem variações (campo opcional, sem "Assignment to constant variable"), com variações, foto salva e toast de sucesso; formulário de anúncio: localização automática preenche o endereço, que continua editável. |
| `imagens_cabecalho_agente.py` | Celular: ícone do WhatsApp sem telefone, agente com cabeçalho único no topo (seta à esquerda da logo), campo de digitar visível com teclado, edição direta de capa/logo com salvamento imediato e imagem anterior preservada se falhar. |
| `tipo_catalogo_sinal.py` | Ajustes → Tipo de catálogo (3 opções, salvar, nada apagado), formulário só com o tipo permitido, itens ocultos marcados, página pública acompanha. |
| `atalhos_agente.py` | Atalhos rápidos do agente em lista vertical (celular e computador): ordem, alinhamento à esquerda, ícones de uma cor, "Ver mais/Ver menos", ações originais, somem ao primeiro envio do usuário e voltam em conversa nova. |
| `capacidades_painel.py` | Cérebro → Capacidades da inteligência: categorias, status (ativo/inativo/pendente/em desenvolvimento), conteúdo, filtros, busca, cadastro novo aparecendo sozinho e módulo desligado refletido. |

## Como rodar
```bash
cd server
PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts &   # servidor de teste (SQLite, IA de mentira)
pip install playwright && playwright install chromium
python3 test/browser/tema_catalogo_agente.py    # troque BASE no topo do arquivo se usar outra porta
python3 test/browser/cerebro_painel.py
python3 test/browser/produtos_endereco.py
python3 test/browser/imagens_cabecalho_agente.py
python3 test/browser/tipo_catalogo_sinal.py
python3 test/browser/atalhos_agente.py
python3 test/browser/capacidades_painel.py
```
Cada script cria o administrador (primeiro cadastro), a empresa e os dados de que precisa: use um banco **novo** a cada execução.
