# Testes de navegador (Playwright + Chromium)

Complementam `npm test` (que cobre API, banco, motores e regras) verificando o que só aparece no navegador.

| Arquivo | O que comprova |
|---|---|
| `tema_catalogo_agente.py` | O tema da empresa (5 presets + cantos retos) vale no catálogo, na janela do produto e no chat do agente; ícones de contato; sincronização entre telas; sem resíduos ao trocar de tema. |
| `cerebro_painel.py` | Aba "Cérebro e busca": cadastrar, conflito com confirmação, regra executável criada pela tela e cumprida no chat, detalhes, desativar/reativar, conflitos e uso recente. |
| `produtos_endereco.py` | Aba Produtos: salvar sem variações (campo opcional, sem "Assignment to constant variable"), com variações, foto salva e toast de sucesso; formulário de anúncio: localização automática preenche o endereço, que continua editável. |
| `imagens_cabecalho_agente.py` | Celular: ícone do WhatsApp sem telefone, agente com cabeçalho único no topo (seta à esquerda da logo), campo de digitar visível com teclado, edição direta de capa/logo com salvamento imediato e imagem anterior preservada se falhar. |
| `tipo_catalogo_sinal.py` | Ajustes → Tipo de catálogo (3 opções, salvar, nada apagado), formulário só com o tipo permitido, itens ocultos marcados, página pública acompanha. |
| `atalhos_agente.py` | Atalhos rápidos do agente em lista vertical (celular e computador): ordem, alinhamento à esquerda, ícones de uma cor, "Ver mais/Ver menos", ações originais, somem ao primeiro envio do usuário e voltam em conversa nova. |
| `capacidades_painel.py` | Cérebro → Capacidades da inteligência: categorias, status (ativo/inativo/pendente/em desenvolvimento), conteúdo, filtros, busca, cadastro novo aparecendo sozinho e módulo desligado refletido. |
| `composer_novo.py` | Campo de digitação do chat (layout tipo Grok): caixa única, medidas/cores, 1→5 linhas, Enter/Shift+Enter, anexar, microfone, aria-labels, enviar 50% quando vazio. |
| `contadores_sincronizados.py` | Contadores de pedidos/agendamentos: menu lateral e Sua empresa com o mesmo número, tempo real, celular e computador, zerado e isolamento. |
| `aprendizagem_adaptativa.py` | Aprendizagem adaptativa: correção no chat sem anunciar memória, recuperação em nova conversa, tela Aprendizados (editar, pausar, excluir, desligar), item no menu e chave do administrador no Cérebro. |
| `moedas_bonus.py` | MCoins: biblioteca (10 modelos, ampliar, selecionar), personalização com prévia, publicar, distribuir, trocar modelo sem perder saldo, Mercado (3ª categoria), carteira e checkout com desconto. |
| `mcoins_integradora.py` | Meu Assistente como emissor: opção na criação da moeda, central de vínculos, aceite pela empresa, checkout com a moeda, pausa pelo admin, carteira e rastreio emissora/vinculada. |
| `crm.py` | CRM de Sua empresa: indicadores, cliente criado por pedido, lead sem duplicar, interação, oportunidade, funil (mover e perda com motivo), tarefas, inteligência, configurações e celular. |
| `analista_negocio.py` | Analista de negócios: cartões de resumo, comparativo e análise no chat com dados reais, "sem dado" ≠ zero, celular e negação a quem não é dono. |
| `mcoins_percentual.py` | Indicador de distribuição das MCoins em %, atualização após distribuir e absolutos no detalhe |
| `vitrine_historico.py` | Cards "/" como mensagens link_card: ordem cronológica, persistência por conversa, voltar/atualizar, isolamento entre conversas |
| `mcoins_central.py` | Central MCoins: chaves desligadas, código único, config/auditoria, compra pendente→confirmação, permissões individuais, busca por código |
| `mcoins_envio.py` | Enviar MCoins (admin): pesquisa, seleção, prévia/confirmação/cancelamento, crédito, histórico; moeda 3D, aviso com partículas, saldo animado e movimento reduzido. |
| `cupons.py` | Cupons: empresa cria/pausa/distribui, vitrine da loja, checkout aplica/remove e bloqueia reuso, área do cliente, resultados e visão do administrador. |
| `inicio_sua_empresa.py` | Início de "Sua empresa": Vendas, Relatórios e Dados de acessos no lugar da prévia do catálogo; navegação e catálogo preservados |
| `vitrine_links.py` | Vitrine de Links: cadastro no painel, menu `/` no chat e no agente, filtro, card, link externo, desativar, mensagens comuns |
| `laboratorio_ia.py` | Laboratório de IA: chat de correção → proposta, testes em simulação, aprovação, publicação, desativação, simulador e histórico |

## Como rodar
```bash
cd server
PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts &   # servidor de teste (SQLite, IA de mentira)
pip install playwright && playwright install chromium
python3 test/browser/tema_catalogo_agente.py    # troque BASE no topo do arquivo se usar outra porta
python3 test/browser/cerebro_painel.py
python3 test/browser/produtos_endereco.py
python3 test/browser/imagens_cabecalho_agente.py
python3 test/browser/tipo_catalogo_sinal.py
python3 test/browser/atalhos_agente.py
python3 test/browser/capacidades_painel.py
python3 test/browser/composer_novo.py
python3 test/browser/contadores_sincronizados.py
python3 test/browser/aprendizagem_adaptativa.py
python3 test/browser/moedas_bonus.py
python3 test/browser/mcoins_integradora.py
python3 test/browser/crm.py
python3 test/browser/analista_negocio.py
python3 test/browser/vitrine_historico.py
python3 test/browser/mcoins_central.py
python3 test/browser/mcoins_envio.py
python3 test/browser/cupons.py
python3 test/browser/laboratorio_ia.py
python3 test/browser/vitrine_links.py
python3 test/browser/agenda_ia.py
python3 test/browser/botoes_rapidos_chat.py
python3 test/browser/descricoes_expansiveis.py
python3 test/browser/botoes_rapidos_conversa.py
python3 test/browser/vitrine_temporaria.py
```
Cada script cria o administrador (primeiro cadastro), a empresa e os dados de que precisa: use um banco **novo** a cada execução.
