# Compromissos → Calendário: gráfico "Evolução da agenda" acima do calendário (celular e computador).
# Dados reais do banco (criados pela API do próprio app); filtros de período; cards; troca de indicador; toque no ponto;
# comparação com o período anterior; recolher/expandir (lembrado); período personalizado; atualização automática ao
# criar/cancelar; usuário sem compromissos; calendário continua funcionando; sem rolagem lateral e sem erros de JS.
# Servidor: PORT=4316 SQLITE_FILE=/tmp/ma-evo.db npx tsx test/serve-sqlite.ts (banco novo)
import datetime as dt, sys
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4316'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.evo@t.com', **U}).ok
    hoje = RA.get('/api/agenda').json()['today']; H = dt.date.fromisoformat(hoje)
    D = lambda n: (H + dt.timedelta(days=n)).isoformat()
    cria = lambda t, d, h=None, st=None: RA.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': t, 'date': d, **({'time': h} if h else {}), **({'status': st} if st else {})}}).json()['item']['id']
    # últimos 7 dias: 2 concluídos, 1 cancelado, 1 não compareceu, 2 pendentes; 7 dias antes: 4
    ids = [cria('Corte', hoje, '09:30', 'done'), cria('Barba', D(-1), '10:00', 'done'), cria('Reunião', D(-2), None, 'cancelled'), cria('Consulta', D(-3), '14:00', 'no_show'), cria('Retorno', hoje, '18:00'), cria('Visita', D(-5), '11:00', 'confirmed')]
    for i, d in enumerate([-8, -9, -10, -12]): cria(f'Antigo {i}', D(d), '15:00', 'done' if i == 0 else None)
    api = RA.get('/api/v2/compromissos/estatisticas?periodo=7d').json()
    check('API: 6 no período, 4 no anterior, +50%', api['atual']['total'] == 6 and api['anterior']['total'] == 4 and api['comparacao']['total']['variacao'] == 50, api['comparacao'])
    for nome, vp in [('computador', {'width': 1280, 'height': 860}), ('celular', None)]:
        print('==', nome)
        ctx = A if nome == 'celular' else b.new_context(viewport=vp, base_url=BASE, storage_state=A.storage_state())
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/agenda?tab=compromissos'); pg.wait_for_selector('.ma-cal-btn', timeout=20000); pg.wait_for_timeout(400)
        pg.evaluate("()=>{try{localStorage.removeItem('ma-evo-p');localStorage.removeItem('ma-evo-aberto')}catch(e){}}")
        pg.click('.ma-cal-btn'); pg.wait_for_selector('.ma-evo .ma-evo-card', timeout=10000); pg.wait_for_timeout(600)
        ev, nav, grid = pg.locator('.ma-evo').bounding_box(), pg.locator('.ma-cal-mes').bounding_box(), pg.locator('.ma-cal-grid').bounding_box()
        check(f'{nome}: gráfico aparece ao abrir o calendário, acima da visualização do mês', ev['y'] + ev['height'] <= nav['y'] + 1 and nav['y'] < grid['y'], (ev, nav))
        check(f'{nome}: começa expandido em "30 dias"', pg.get_attribute('.ma-evo-cab', 'aria-expanded') == 'true' and pg.get_attribute('[data-per="30d"]', 'aria-pressed') == 'true')
        check(f'{nome}: filtros Hoje, 7, 30, 90 dias, 12 meses e Personalizado', [x.strip() for x in pg.locator('.ma-evo-chip').all_inner_texts()] == ['Hoje', '7 dias', '30 dias', '90 dias', '12 meses', 'Personalizado'])
        pg.click('[data-per="7d"]'); pg.wait_for_function("()=>document.querySelector('[data-per=\"7d\"]').getAttribute('aria-pressed')==='true'&&document.querySelector('[data-card=total] strong')", timeout=8000); pg.wait_for_timeout(500)
        cd = {k: pg.inner_text(f'[data-card={k}]').replace('\xa0', ' ') for k in ['total', 'conclusao', 'cancelamento', 'comparecimento', 'crescimento']}
        check(f'{nome}: cards com os números reais (6 · 33,33% · 16,67% · 66,67% · ▲ +50%)', '6' in cd['total'] and 'anterior: 4' in cd['total'] and '33,33%' in cd['conclusao'] and '16,67%' in cd['cancelamento'] and '66,67%' in cd['comparecimento'] and '▲ +50%' in cd['crescimento'] and '6 vs 4' in cd['crescimento'], cd)
        cmp = pg.inner_text('[data-cmp]')
        check(f'{nome}: comparação com o período anterior equivalente', '6 compromissos vs 4 no período anterior' in cmp and '▲ +50%' in cmp, cmp)
        check(f'{nome}: resumo no cabeçalho', '6 compromissos · ▲ +50%' in pg.inner_text('.ma-evo-res').replace('\xa0', ' '), pg.inner_text('.ma-evo-res'))
        check(f'{nome}: linha suave do período e tracejada do anterior', pg.locator('.ma-evo-graf path.ln').count() == 1 and 'C' in pg.get_attribute('.ma-evo-graf path.ln', 'd') and pg.locator('.ma-evo-graf path.an').count() == 1)
        # tocar no ponto de hoje (último)
        pg.locator('.ma-evo-graf .hit').last.click(); pg.wait_for_timeout(250)
        tip = pg.inner_text('.ma-evo-tip')
        check(f'{nome}: tocar no ponto mostra data, quantidade e detalhes', pg.locator('.ma-evo-tip').is_visible() and H.strftime('%d/%m/%Y') in tip and '2 compromissos' in tip and 'Concluídos 1' in tip and 'Pendentes 1' in tip and 'Novos agendamentos' in tip, tip)
        check(f'{nome}: ponto mostra também o período anterior e a variação', 'Período anterior' in tip, tip)
        if nome == 'celular': pg.screenshot(path='/tmp/e2e/evo_celular_tooltip.png')
        pg.click('[data-ind="concluidos"]'); pg.wait_for_timeout(300)
        check(f'{nome}: alternar indicador (Concluídos)', pg.get_attribute('[data-ind="concluidos"]', 'aria-pressed') == 'true' and 'concluídos' in pg.get_attribute('.ma-evo-graf svg', 'aria-label') and '2 concluídos vs 1' in pg.inner_text('[data-cmp]'), pg.inner_text('[data-cmp]'))
        pg.click('[data-ind="cancelados"]'); pg.wait_for_timeout(200)
        check(f'{nome}: cancelados em indicador separado (não somam aos concluídos)', '1 cancelado · período anterior' in pg.inner_text('[data-cmp]') and 'sem base de comparação' in pg.inner_text('[data-cmp]'), pg.inner_text('[data-cmp]'))
        pg.click('[data-ind="total"]'); pg.wait_for_timeout(200)
        pg.uncheck('[data-ant]'); pg.wait_for_timeout(150)
        check(f'{nome}: ocultar o período anterior', pg.locator('.ma-evo-graf path.an').count() == 0); pg.check('[data-ant]'); pg.wait_for_timeout(150)
        for per, n in [('hoje', 24), ('90d', 13), ('12m', 12), ('30d', 30)]:
            pg.click(f'[data-per="{per}"]'); pg.wait_for_function(f"()=>document.querySelector('[data-per=\"{per}\"]').getAttribute('aria-pressed')==='true'&&document.querySelectorAll('.ma-evo-graf .hit').length==={n}", timeout=8000)
        check(f'{nome}: Hoje (24h), 90 dias (semanas), 12 meses e 30 dias atualizam o gráfico', True)
        if nome == 'celular':
            pg.wait_for_timeout(700); pg.screenshot(path='/tmp/e2e/evo_celular.png'); pg.screenshot(path='/tmp/e2e/evo_celular_full.png', full_page=True)
            check('celular: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and pg.evaluate("document.querySelector('.ma-cal-in').scrollWidth-document.querySelector('.ma-cal-in').clientWidth") <= 1)
            # calendário continua funcionando, rolando abaixo do gráfico
            pg.locator(f'.ma-cal-d[data-d="{hoje}"]').click(); pg.wait_for_timeout(300)
            check('celular: calendário e lista do dia continuam funcionando abaixo do gráfico', 'Corte' in pg.inner_text('.ma-cal-lst') and 'Retorno' in pg.inner_text('.ma-cal-lst'))
            # personalizado
            pg.click('[data-per="personalizado"]'); pg.wait_for_selector('[data-pers]')
            pg.fill('[data-pers] [name=de]', D(-2)); pg.fill('[data-pers] [name=ate]', hoje); pg.click('[data-pers] button'); pg.wait_for_function("()=>document.querySelectorAll('.ma-evo-graf .hit').length===3", timeout=8000)
            check('celular: período personalizado (3 dias)', '4' in pg.inner_text('[data-card=total] strong'), pg.inner_text('[data-card=total]'))
            pg.click('[data-per="7d"]'); pg.wait_for_function("()=>document.querySelectorAll('.ma-evo-graf .hit').length===7", timeout=8000)
            # atualização automática: novo compromisso e cancelamento
            cria('Novo hoje', hoje, '20:00'); RA.post('/api/items', data={'action': 'appointment_update', 'type': 'appointment', 'id': ids[4], 'data': {'status': 'cancelled'}})
            pg.evaluate("()=>window.dispatchEvent(new Event('nexa:changed'))")
            pg.wait_for_function("()=>/^7$/.test(document.querySelector('[data-card=total] strong').textContent.trim())", timeout=8000); pg.wait_for_timeout(300)
            check('celular: atualiza sozinho ao criar e cancelar (7 · 2 cancelados)', '2 cancelados' in pg.inner_text('[data-card=cancelamento]') and '28,57%' in pg.inner_text('[data-card=cancelamento]'), pg.inner_text('[data-card=cancelamento]'))
            # recolher, e o estado é lembrado ao reabrir
            pg.click('.ma-evo-cab'); pg.wait_for_timeout(250)
            check('celular: recolher o gráfico (fica só o cabeçalho com o resumo)', not pg.locator('.ma-evo-corpo').is_visible() and pg.get_attribute('.ma-evo-cab', 'aria-expanded') == 'false' and '7 compromissos' in pg.inner_text('.ma-evo-res'))
            pg.screenshot(path='/tmp/e2e/evo_celular_recolhido.png')
            pg.click('[data-x]'); pg.wait_for_timeout(300); pg.click('.ma-cal-btn'); pg.wait_for_selector('.ma-evo'); pg.wait_for_timeout(500)
            check('celular: ao reabrir, continua recolhido e no último período', pg.get_attribute('.ma-evo-cab', 'aria-expanded') == 'false' and '7 compromissos' in pg.inner_text('.ma-evo-res'))
            pg.click('.ma-evo-cab'); pg.wait_for_selector('.ma-evo-graf svg')
            check('celular: expandir de novo', pg.locator('.ma-evo-corpo').is_visible())
            pg.click('[data-x]'); pg.wait_for_timeout(300)
        else:
            pg.wait_for_timeout(700); pg.screenshot(path='/tmp/e2e/evo_computador.png')
            pg.locator('.ma-evo-graf .hit').nth(5).hover(); pg.wait_for_timeout(200)
            check('computador: passar o mouse mostra o valor do ponto', pg.locator('.ma-evo-tip').is_visible())
            pg.focus('.ma-evo-graf'); pg.keyboard.press('ArrowLeft'); pg.wait_for_timeout(150)
            check('computador: setas do teclado percorrem os pontos sem trocar o mês', pg.locator('.ma-evo-tip').is_visible() and pg.inner_text('.ma-cal-mes').strip() != '')
    # usuário sem compromissos
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Caio Vazio', 'whatsapp': '+55 11 95555-0101', 'email': 'caio.evo@t.com', **U}, headers={'X-Forwarded-For': '10.9.9.9'}).ok
    pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto('/agenda?tab=compromissos'); pc.wait_for_selector('.ma-cal-btn', timeout=20000); pc.click('.ma-cal-btn'); pc.wait_for_selector('.ma-evo .ma-evo-card', timeout=10000)
    t = pc.inner_text('.ma-evo')
    check('sem compromissos: zeros, taxas "—", sem NaN e com aviso claro', 'Nenhum compromisso neste período' in t and 'NaN' not in t and 'Infinity' not in t and '—' in pc.inner_text('[data-card=conclusao]') and 'sem atividade' in pc.inner_text('[data-card=crescimento]'), t[:400])
    pc.wait_for_timeout(600); pc.screenshot(path='/tmp/e2e/evo_vazio.png')
    check('outro usuário não vê os números da Ana', '0' == pc.inner_text('[data-card=total] strong').strip())
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
