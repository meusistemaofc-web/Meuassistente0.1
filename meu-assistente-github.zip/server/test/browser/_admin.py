# Navegação da Administração em seções (usada pelos testes de tela): abre o menu de seções, escolhe a seção e clica na
# subaba — o mesmo caminho de quem usa o painel. `alvo` é a chave da aba (ex.: 'ia', 'cb_cognicao') ou o nome exibido.
def aba(pg, alvo, timeout=20000):
    pg.wait_for_selector('#ma-adm-nav #ma-an-secao', timeout=timeout)
    pg.wait_for_function('()=>!!window.__maAdmMapa', timeout=timeout)
    m = pg.evaluate('n=>window.__maAdmMapa(n)', alvo)
    assert m, f'aba desconhecida na Administração: {alvo}'
    pg.click('#ma-an-secao')
    pg.click(f'#ma-an-menu [data-secao="{m["secao"]}"]')
    pg.click(f'#ma-adm-nav [data-sub="{m["sub"]}"]')
    return m
