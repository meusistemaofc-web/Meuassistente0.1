# Tarefas do chat em segundo plano, pela tela real (celular e computador):
# • pedido demorado: o indicador compacto (pontinhos + etapa real) acompanha o pedido, sem cartão de processamento;
# • sair da tela no meio (ir para outra página): o servidor continua, salva na conversa e cria o aviso "Sua resposta está
#   pronta" com link para a conversa; abrir o link (como ao tocar na notificação) mostra a resposta salva;
# • voltar para a conversa com a tarefa ainda rodando (recarregou o app): o mesmo indicador compacto com a etapa real; ao
#   terminar, a conversa mostra o resultado sozinha;
# • navegar dentro do app (outra página sem recarregar): a tarefa é marcada como "segundo plano" e o aviso chega;
# • falhou: aviso "Não consegui concluir", cartão com o motivo, "Tentar de novo" (pedido guardado) → processa → resultado;
# • pedido rápido continua igual (sem cartão, sem aviso); sem rolagem lateral; sem erros de JavaScript.
# Servidor: PORT=4341 SQLITE_FILE=/tmp/ma-tsp.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re, json, time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4341'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1238', 'email': 'admin.tsp@t.com', **U}).ok
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Tina Teste', 'whatsapp': f'+55 11 98888-{k}{k}{k}{k}', 'email': f'tina{k}.tsp@t.com', **U}, headers={'X-Forwarded-For': f'10.9.4.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        def abrir(url='/'):
            pg.goto(url); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(900)
            if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        def enviar(t):
            pg.fill('textarea.composer-input', t); pg.keyboard.press('Enter')
        def conv():
            for _ in range(40):
                c = pg.evaluate("()=>new URLSearchParams(location.search).get('c')")
                if c: return c
                pg.wait_for_timeout(250)
            return None
        avisos = lambda titulo: [x for x in (R.get('/api/notifications').json().get('items') or R.get('/api/notifications').json().get('notifications') or []) if x['title'] == titulo]
        abrir()
        # 0) pedido rápido: normal, sem cartão de tarefa
        n0 = pg.locator('.chat-scroll .msg-bubble').count(); enviar('oi, tudo bem?'); pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0+2}", timeout=15000); pg.wait_for_timeout(800)
        check(f'{nome}: pedido rápido responde normalmente, sem cartão de tarefa', pg.locator('[data-tarefa]').count() == 0 and pg.locator('[data-processando]').count() == 0)
        # 1) demorado: estado "processando" na bolha e saída da tela
        enviar('pesquise fornecedores de café xqz-tarefa-lenta'); c1 = conv()
        pg.wait_for_timeout(4500)
        ind = pg.evaluate("()=>{const s=document.querySelector('.chat-scroll [role=status][aria-label=\"Preparando a resposta\"]');return s?(s.querySelector('.ma-ind-t')||{}).textContent:''}")
        check(f'{nome}: pedido demorado mostra o indicador compacto com a etapa, sem cartão de processamento', ind in ('Pensando…', 'Consultando o Cérebro Central…') and pg.locator('[data-processando]').count() == 0 and 'Processando seu pedido' not in pg.inner_text('.chat-scroll'), (ind, pg.inner_text('.chat-scroll')[-200:]))
        if mob: pg.screenshot(path='/tmp/e2e/tarefa_processando.png')
        pg.goto('/x/pedidos'); pg.wait_for_timeout(8500)
        av = avisos('Sua resposta está pronta')
        check(f'{nome}: saiu da tela → aviso "Sua resposta está pronta" com link para a conversa', len(av) == 1 and av[0]['link'] == f'/?c={c1}' and 'Resultado da pesquisa' in av[0]['body'], av)
        abrir(av[0]['link'] if av else '/')
        t = N(pg.inner_text('.chat-scroll'))
        check(f'{nome}: o link do aviso abre a conversa com a resposta salva', 'pesquise fornecedores de café' in t and 'Resultado da pesquisa' in t, t[-200:])
        # 2) voltou com a tarefa rodando (recarregou o app): cartão com o estado real; ao terminar, o resultado aparece sozinho
        enviar('pesquise preços de grãos xqz-tarefa-lenta'); c2 = conv(); pg.wait_for_timeout(1200)
        pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000)
        try: pg.wait_for_selector('[data-tarefa][data-estado="processando"] .ma-ind-solo', timeout=8000); ok = True
        except Exception: ok = False
        check(f'{nome}: ao voltar, indicador compacto com a etapa real (sem cartão)', ok and N(pg.inner_text('[data-tarefa]')) in ('Pensando…', 'Consultando o Cérebro Central…') and pg.locator('[data-tarefa] .glass').count() == 0, N(pg.inner_text('.chat-scroll'))[-200:])
        check(f'{nome}: indicador aparece depois da última mensagem', pg.evaluate("()=>{const c=document.querySelector('[data-tarefa]');const r=[...document.querySelectorAll('.chat-scroll .msg-swipe')].pop();return !!c&&!!r&&!!(r.compareDocumentPosition(c)&Node.DOCUMENT_POSITION_FOLLOWING)&&!r.contains(c)}"))
        if mob: pg.screenshot(path='/tmp/e2e/tarefa_cartao.png')
        ok = False
        for _ in range(60):  # ao terminar, o app recarrega a conversa: tolera a navegação
            try:
                if pg.evaluate("()=>!document.querySelector('[data-tarefa]')&&!!document.querySelector('.chat-scroll')&&document.querySelector('.chat-scroll').innerText.includes('Resultado da pesquisa')&&document.querySelector('.chat-scroll').innerText.includes('preços de grãos')"): ok = True; break
            except Exception: pass
            pg.wait_for_timeout(400)
        check(f'{nome}: ao terminar, a conversa mostra o resultado sozinha', ok, N(pg.inner_text('.chat-scroll'))[-200:])
        check(f'{nome}: acompanhou na tela até o fim → sem aviso', len(avisos('Sua resposta está pronta')) == 1)
        # 3) navegação dentro do app (sem recarregar): marcada como segundo plano e avisada
        enviar('pesquise cafeterias novas xqz-tarefa-media'); c3 = conv(); pg.wait_for_timeout(800)
        pg.evaluate("()=>history.pushState({}, '', '/x/pedidos')"); pg.wait_for_timeout(2200)
        tf = [x for x in R.get('/api/v2/chat/tarefas').json()['tarefas'] if x['conversa'] == c3]
        check(f'{nome}: foi para outra página no app → tarefa em segundo plano', tf and tf[0]['segundoPlano'] and tf[0]['estado'] == 'processando', tf)
        pg.wait_for_timeout(4000)
        check(f'{nome}: aviso da tarefa feita fora da tela', len(avisos('Sua resposta está pronta')) == 2)
        # 4) falhou: aviso, cartão com motivo e "Tentar de novo"
        abrir('/')
        enviar(f'quais as tendências zqx de mercado {nome} xqz-tarefa-falha'); pg.wait_for_timeout(700)
        pg.goto('/x/pedidos'); pg.wait_for_timeout(5000)
        c4 = next((x['conversa'] for x in R.get('/api/v2/chat/tarefas').json()['tarefas'] if 'tendências zqx' in (x['texto'] or '')), None)
        check(f'{nome}: falhou fora da tela → aviso "Não consegui concluir"', len(avisos('Não consegui concluir sua solicitação')) == 1, avisos('Não consegui concluir sua solicitação'))
        abrir(f'/?c={c4}')
        try: pg.wait_for_selector('[data-tarefa][data-estado="falhou"]', timeout=8000); ok = True
        except Exception: ok = False
        check(f'{nome}: cartão "Não consegui concluir" com motivo e "Tentar de novo"', ok and 'Não consegui concluir' in N(pg.inner_text('[data-tarefa]')) and pg.locator('[data-tf-tentar]').count() == 1 and pg.locator('[data-tf-descartar]').count() == 1)
        check(f'{nome}: cartão de falha visível na tela (conversa nova sem mensagens)', pg.evaluate("()=>{const r=document.querySelector('[data-tarefa]').getBoundingClientRect();return r.height>0&&r.top>=0&&r.bottom<=innerHeight}"))
        if mob: pg.screenshot(path='/tmp/e2e/tarefa_falhou.png')
        pg.wait_for_timeout(4000)  # a falha simulada dura 8 s
        pg.click('[data-tf-tentar]')
        ok = False
        for _ in range(60):
            try:
                if pg.evaluate("()=>!document.querySelector('[data-tarefa]')&&!!document.querySelector('.chat-scroll')&&document.querySelector('.chat-scroll').innerText.includes('tendências zqx')&&document.querySelectorAll('.chat-scroll .msg-bubble').length>=2"): ok = True; break
            except Exception: pass
            pg.wait_for_timeout(400)
        tj = [x for x in R.get('/api/v2/chat/tarefas').json()['tarefas'] if x['conversa'] == c4]
        check(f'{nome}: "Tentar de novo" processa o pedido guardado e mostra o resultado', ok and tj and tj[0]['estado'] == 'concluida' and tj[0]['tentativas'] == 2, (tj, N(pg.inner_text('.chat-scroll'))[-200:]))
        pg.wait_for_timeout(1500)
        check(f'{nome}: nova tentativa acompanhada na tela → sem aviso extra', len(avisos('Sua resposta está pronta')) == 2)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        C.close()
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
