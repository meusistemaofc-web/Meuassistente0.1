# Cérebro Central integrado ao chat, no celular e no computador, pela tela real do chat:
# 1) conhecimento exclusivo cadastrado pelo administrador aparece na resposta;
# 2) pergunta sem conhecimento → pesquisa nas fontes (servidor local no papel do SearXNG e de dois sites), guarda e responde;
# 3) a mesma pergunta depois é respondida pela base interna, sem nova pesquisa;
# 4) painel "Uso no chat" com os indicadores e o rastreamento por resposta (detalhes ao tocar).
# A IA é um dublê local que responde SOMENTE com o que recebeu do Cérebro no contexto ([C1]…).
# Servidor: CEREBRO_PERMITIR_REDE_LOCAL=1 E2E_AI_URL=http://127.0.0.1:4397/v1 PORT=4316 SQLITE_FILE=/tmp/ma-cch.db npx tsx test/serve-sqlite.ts
import json, threading, subprocess, time, os, re, urllib.request, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4316'; WEB = 4398; AI = 4397; res = []; buscas = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
Z1 = '<p>A técnica Zentrix de irrigação por gotejamento libera pulsos curtos de água a cada 14 minutos diretamente na raiz das plantas, o que reduz a evaporação da irrigação em hortas pequenas.</p><p>Na técnica Zentrix de irrigação por gotejamento, cada gotejador trabalha com baixa pressão e o solo fica úmido sem encharcar.</p>'
Z2 = '<p>O guia da técnica Zentrix de irrigação por gotejamento recomenda revisar os filtros dos gotejadores uma vez por mês para evitar entupimentos na irrigação.</p>'
class Web(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ct):
        b = body.encode(); self.send_response(code); self.send_header('Content-Type', ct); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith('/robots.txt'): return self._send(200, 'User-agent: *\nAllow: /\n', 'text/plain')
        if self.path.startswith('/search'):
            q = urllib.parse.unquote_plus(self.path); buscas.append(q)
            r = [{'url': f'http://127.0.0.1:{WEB}/z1', 'title': 'Técnica Zentrix de irrigação por gotejamento', 'content': 'técnica zentrix', 'engine': 'duckduckgo'}, {'url': f'http://localhost:{WEB}/z2', 'title': 'Guia da irrigação Zentrix', 'content': 'zentrix gotejamento', 'engine': 'bing'}] if 'zentrix' in q.lower() else []
            return self._send(200, json.dumps({'results': r}), 'application/json')
        if self.path == '/z1': return self._send(200, f'<html lang="pt-BR"><title>Técnica Zentrix de irrigação por gotejamento</title><body><main>{Z1}</main></body></html>', 'text/html; charset=utf-8')
        if self.path == '/z2': return self._send(200, f'<html lang="pt-BR"><title>Guia da irrigação Zentrix</title><body><main>{Z2}</main></body></html>', 'text/html; charset=utf-8')
        self._send(404, '', 'text/plain')
class Ia(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self): self.send_response(200); self.end_headers(); self.wfile.write(b'{"data":[]}')
    def do_POST(self):
        j = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}'); sys_ = str((j.get('messages') or [{}])[0].get('content') or '')
        m = re.search(r'\[C1\][^\n]*\n([\s\S]*?)(?=\n\[C\d\]|\n\n|$)', sys_)
        if m: txt = 'Pelo que consta: ' + ' '.join(re.sub(r'\s*\[\d+\]', '', re.sub(r'^[-•]\s*', '', l)) for l in m.group(1).split('\n') if l.strip() and not l.startswith('Fontes:'))
        else: txt = 'Não tenho essa informação confirmada.'
        b = json.dumps({'choices': [{'message': {'role': 'assistant', 'content': txt}}]}).encode()
        self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
for S, porta in [(Web, WEB), (Ia, AI)]:
    sv = ThreadingHTTPServer(('0.0.0.0', porta), S); threading.Thread(target=sv.serve_forever, daemon=True).start()
for f in ['/tmp/ma-cch.db', '/tmp/ma-cch.db-wal', '/tmp/ma-cch.db-shm']:
    if os.path.exists(f): os.remove(f)
env = {**os.environ, 'PORT': '4316', 'SQLITE_FILE': '/tmp/ma-cch.db', 'CEREBRO_PERMITIR_REDE_LOCAL': '1', 'E2E_AI_URL': f'http://127.0.0.1:{AI}/v1'}
srv = subprocess.Popen(['npx', 'tsx', 'test/serve-sqlite.ts'], cwd='/home/claude/repo/meu-assistente/server', env=env, stdout=open('/tmp/cd/srv4316.log', 'w'), stderr=subprocess.STDOUT)
for _ in range(90):
    try: urllib.request.urlopen(BASE + '/api/health', timeout=2); break
    except Exception: time.sleep(1)
errs = []
QQ = 'Qual é o prazo de retorno do Protocolo Quorvex para reclamações?'; QZ = 'O que é a técnica Zentrix de irrigação por gotejamento?'
def enviar(pg, t, espera):
    n0 = pg.locator('text=' + espera).count()
    pg.fill('textarea.composer-input', t); pg.keyboard.press('Enter')
    for _ in range(60):
        if pg.locator('text=' + espera).count() > n0: return True
        pg.wait_for_timeout(500)
    return False
try:
  with sync_playwright() as p:
    b = p.chromium.launch(); R = b.new_context(base_url=BASE).request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    k = R.post('/api/brain/knowledge', data={'titulo': 'Protocolo Quorvex de atendimento', 'conteudo': 'O Protocolo Quorvex determina que toda reclamação de cliente receba retorno em até 37 minutos, com registro no livro azul e confirmação de um supervisor de plantão.', 'status': 'aprovado', 'confianca': 90}); assert k.ok, k.text()
    pv = R.get('/api/brain/providers').json()['provedores']
    for x in pv:
        if x['provedor'] == 'wikipedia': R.put(f"/api/brain/providers/{x['id']}", data={'ativo': False})
        if x['provedor'] == 'searxng': assert R.put(f"/api/brain/providers/{x['id']}", data={'url': f'http://127.0.0.1:{WEB}', 'ativo': True, 'papel': 'principal'}).ok
    U = b.new_context(base_url=BASE).request
    assert U.post('/api/auth', data={'action': 'signup', 'name': 'Rita Cliente', 'whatsapp': '+55 11 95555-1234', 'email': 'rita@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob)
        assert c.request.post('/api/auth', data={'action': 'login', 'email': 'rita@t.com', 'password': 'Senha@Forte123'}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        check(f'{nome}: conhecimento exclusivo do Cérebro aparece na resposta do chat', enviar(pg, QQ, '37 minutos'))
        b0 = len(buscas)
        ok = enviar(pg, QZ, '14 minutos')
        if nome == 'celular': check('celular: sem conhecimento → pesquisou nas fontes e respondeu com o que aprendeu', ok and len(buscas) > b0 and any('zentrix' in x.lower() for x in buscas[b0:]), buscas)
        else: check('computador: a mesma pergunta veio da base interna, sem nova pesquisa', ok and len(buscas) == b0, buscas)
        check(f'{nome}: sem rolagem horizontal (chat)', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.screenshot(path=f'/tmp/cd/shots/cerebro_chat_{nome}.png')
        # painel do administrador: Uso no chat
        a = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob)
        assert a.request.post('/api/auth', data={'action': 'login', 'email': 'admin@t.com', 'password': 'Senha@Forte123'}).ok
        ap = a.new_page(); ap.on('pageerror', lambda e: errs.append(str(e)))
        ap.goto('/admin/cerebro-central#chat'); ap.wait_for_selector('[data-tr]', timeout=20000)
        t = ap.inner_text('#c')
        check(f'{nome}: indicadores de uso real', all(x in t for x in ['Respostas que usaram conhecimento', 'Com conhecimento recuperado', 'Pesquisas externas', 'Conhecimentos aprendidos no chat', 'Respostas com o que foi aprendido', 'Respondidas sem IA']), t[:400])
        check(f'{nome}: rastreamento lista as perguntas gerais e o uso', QQ in t and QZ in t and 'Pesquisou e aprendeu' in t and 'Sim' in t and 'Protocolo Quorvex de atendimento' in t, t[:800])
        ap.locator('[data-tr]').first.click(); ap.wait_for_timeout(300)
        det = ap.inner_text('[id^=trd]:not([hidden])') if ap.locator('[id^=trd]:not([hidden])').count() else ''
        check(f'{nome}: detalhes da resposta (conhecimentos, fontes, caminho)', 'conhecimentos' in det.lower() and 'usado' in det and 'caminho' in det.lower() and 'fontes externas' in det.lower(), det)
        check(f'{nome}: sem rolagem horizontal (painel)', ap.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        ap.screenshot(path=f'/tmp/cd/shots/cerebro_uso_chat_{nome}.png', full_page=True)
        ap.goto('/admin/cerebro-central#configuracoes'); ap.wait_for_selector('[data-k=aprenderNoChat]', timeout=15000)
        check(f'{nome}: configurações do aprendizado no chat e do compartilhamento', ap.get_attribute('[data-k=aprenderNoChat]', 'aria-checked') == 'true' and ap.get_attribute('[data-k=compartilharComAgente]', 'aria-checked') == 'true' and ap.locator('[data-n=esperaPesquisaChatMs]').count() == 1)
        a.close(); c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs) # o #418 (hidratação do React) já existia e é filtrado nos outros testes do chat
finally:
    srv.terminate()
print(f'\n{sum(res)}/{len(res)} verificações')
raise SystemExit(0 if all(res) else 1)
