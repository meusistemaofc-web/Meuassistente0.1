# SOLICITAÇÃO DE CRÉDITO DO CLIENTE pela tela (Playwright), com o servidor real:
# • cliente (iPhone): botão "Crédito da Loja" na página da loja → dados (validação de CPF) → documentos (foto pequena
#   recusada; documento, comprovante em PDF e selfie aceitos, com prévia) → revisão com o termo de tratamento dos dados →
#   consentimento obrigatório → enviada (Em análise);
# • dono (computador): Crédito da Loja → Solicitações de Crédito → dados, documentos na área protegida, histórico real
#   ("ainda não fez nenhuma compra"), observação interna, pedir informações;
# • cliente responde (troca o comprovante) e reenvia; dono aprova com limite e condições próprias (sem juros, até 3x, validade);
# • cliente compra a crédito no checkout com as condições aprovadas; documento não abre sem sessão nem para outra pessoa;
# • sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4374 SQLITE_FILE=/tmp/ma-csol.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, re, sys, sqlite3, base64, json, os, random
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4374'; DBF = '/tmp/ma-csol.db'; res = []; TMP = '/tmp/ma-csol-arq'; os.makedirs(TMP, exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
IPHONE = {'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'device_scale_factor': 2}
DESK = {'viewport': {'width': 1280, 'height': 880}}
def sql(q, a=()):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchall(); db.commit(); db.close(); return r
def lateral(pg): return pg.evaluate("()=>{const x=document.getElementById('ma-x');return Math.max(document.documentElement.scrollWidth,x?x.scrollWidth:0)-innerWidth}")
def foto(nome, w, h, desenho=True):
    random.seed(nome); im = Image.new('RGB', (w, h), (235, 235, 230)); px = im.load()
    for y in range(0, h, 3):
        for x in range(0, w, 3):
            v = random.randint(0, 255) if desenho else 200
            for dy in range(3):
                for dx in range(3):
                    if x + dx < w and y + dy < h: px[x + dx, y + dy] = (v, (v * 3) % 256, 255 - v)
    p = f'{TMP}/{nome}.jpg'; im.save(p, 'JPEG', quality=90); return p
DOC = foto('doc', 1400, 900); SELFIE = foto('selfie', 800, 800); MINI = foto('mini', 300, 200)
PDF = f'{TMP}/comprovante.pdf'; open(PDF, 'wb').write(b'%PDF-1.4\n' + b'1 0 obj << /Type /Catalog >> endobj\n' * 80 + b'trailer << >>\n%%EOF\n')
ULT = {}
def toast(pg):
    ant = ULT.get(id(pg), '')
    try:
        pg.wait_for_function("a=>{const t=document.getElementById('ma-x-toast');return t&&!t.hidden&&t.textContent!==a}", arg=ant, timeout=8000)
        ULT[id(pg)] = pg.inner_text('#ma-x-toast'); return N(ULT[id(pg)])
    except Exception: return ''
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    def ctx(nome, opts, signup, n):
        C = b.new_context(base_url=BASE, **opts)
        if signup: assert C.request.post('/api/auth', data={'action': 'signup', **signup, **U}, headers={'X-Forwarded-For': f'10.7.4.{n}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e, nm=nome: errs.append(nm + ': ' + str(e))); return C, pg
    A, apg = ctx('adm', DESK, {'name': 'Admin Sol', 'whatsapp': '+55 11 94444-7474', 'email': 'adm.sol@t.com'}, 1)
    assert A.request.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    D, dpg = ctx('dono', DESK, {'name': 'Ana Dona', 'whatsapp': '+55 11 94444-7475', 'email': 'ana.sol@t.com'}, 2)
    r = D.request.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Moda Ana', 'categoria': 'Moda', 'titulo': 'x', 'texto': 'Roupas', 'zap': '11988887777', 'endereco': 'Rua Augusta, 900, São Paulo - SP'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']; sql("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,))
    assert D.request.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    bio = io.BytesIO(); Image.new('RGB', (300, 300), (40, 90, 200)).save(bio, 'PNG'); b64 = 'data:image/png;base64,' + base64.b64encode(bio.getvalue()).decode()
    assert D.request.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Camisa', 'preco': 120, 'categoria': 'Roupas', 'fotos': [b64]}).ok
    PID = D.request.get(f'/api/v2/ads/{ID}/products').json()['items'][0]['id']
    assert A.request.put('/api/panel/credito', data={'ativo': True, 'maxParcelas': 6, 'jurosMaxMes': 5}).ok
    assert A.request.post(f'/api/panel/credito/empresas/{ID}', data={'acao': 'autorizar'}).ok
    assert D.request.put(f'/api/v2/businesses/{ID}/credito/config', data={'ativo': True, 'parcelas': [2, 3, 4], 'jurosTipo': 'mensal', 'taxa': 2, 'aprovacao': 'automatica', 'limiteMaxCliente': 800}).ok
    C, cpg = ctx('cliente', IPHONE, {'name': 'Carla Lima', 'whatsapp': '+55 11 95555-7476', 'email': 'carla.sol@t.com'}, 3)
    CID = C.request.get('/api/me').json()['profile']['id']

    print('== cliente (iPhone): pedido de limite')
    cpg.goto(f'/x/empresa/{ID}'); cpg.wait_for_selector('[data-cr-solicitar]', timeout=20000)
    check('página da loja mostra "Crédito da Loja · solicite seu limite"', 'solicite seu limite' in N(cpg.inner_text('[data-cr-solicitar]')))
    cpg.click('[data-cr-solicitar]'); cpg.wait_for_selector('[data-sol-dados]', timeout=15000)
    check('formulário já vem com nome, e-mail e telefone da conta', cpg.input_value('[data-f=email]') == 'carla.sol@t.com' and 'Carla Lima' in cpg.input_value('[data-f=nome]'))
    cpg.fill('[data-f=nome]', 'Carla Souza Lima'); cpg.fill('[data-f=cpf]', '11111111111'); cpg.fill('[data-f=nascimento]', '1990-05-10'); cpg.click('[data-sol-p1]'); cpg.wait_for_timeout(300)
    check('CPF inválido: erro claro, não avança', 'CPF inválido' in N(cpg.inner_text('[data-sol-err]')))
    cpg.fill('[data-f=cpf]', '52998224725'); check('CPF formatado ao digitar', cpg.input_value('[data-f=cpf]') == '529.982.247-25', cpg.input_value('[data-f=cpf]'))
    cpg.fill('[data-f=limiteSolicitado]', '500'); cpg.click('[data-sol-par] [data-n="3"]'); cpg.click('[data-sol-p1]'); cpg.wait_for_selector('[data-sol-doc=selfie]', timeout=10000)
    check('selfie com instruções (sem óculos escuros e boné)', 'óculos escuros' in N(cpg.inner_text('[data-sol-doc=selfie]')) and 'boné' in N(cpg.inner_text('[data-sol-doc=selfie]')))
    check('Revisar fica bloqueado até enviar os 3 arquivos', cpg.is_disabled('[data-sol-p2]'))
    cpg.set_input_files('[data-sol-file=documento]', MINI); cpg.wait_for_function("()=>/pequena demais/.test((document.querySelector('[data-sol-derr=documento]')||{}).textContent||'')", timeout=8000)
    check('foto pequena demais para leitura é recusada antes de enviar', True)
    cpg.set_input_files('[data-sol-file=documento]', DOC); cpg.wait_for_function("()=>/Enviado/.test(document.querySelector('[data-sol-doc=documento]').innerText)", timeout=15000)
    cpg.set_input_files('[data-sol-file=comprovante]', PDF); cpg.wait_for_function("()=>/Enviado/.test(document.querySelector('[data-sol-doc=comprovante]').innerText)", timeout=15000)
    cpg.set_input_files('[data-sol-file=selfie]', SELFIE); cpg.wait_for_function("()=>/Enviado/.test(document.querySelector('[data-sol-doc=selfie]').innerText)", timeout=15000)
    check('documento, comprovante (PDF) e selfie enviados, com prévia', cpg.locator('[data-sol-doc=documento] img').count() == 1 and 'PDF enviado' in N(cpg.inner_text('[data-sol-doc=comprovante]')) and not cpg.is_disabled('[data-sol-p2]'))
    cpg.screenshot(path='/tmp/e2e/solic_documentos_iphone.png', full_page=True)
    check('documentos (iPhone) sem rolagem lateral', lateral(cpg) <= 1, lateral(cpg))
    cpg.click('[data-sol-p2]'); cpg.wait_for_selector('[data-sol-revisao]')
    rv = N(cpg.inner_text('[data-sol-revisao]'))
    check('revisão: dados, documentos e como os dados são tratados', '529.982.247-25' in rv and 'R$ 500,00' in rv and 'reconhecimento facial' in rv and 'apagados 90 dias' in rv, rv[:300])
    cpg.wait_for_function("()=>[...document.querySelectorAll('[data-sol-revisao] img')].every(i=>i.complete&&i.naturalWidth>0)", timeout=8000)
    check('o cliente revê as próprias imagens (endereço temporário)', cpg.locator('[data-sol-revisao] img').count() == 2)
    cpg.click('[data-sol-enviar]'); cpg.wait_for_timeout(300)
    check('sem consentimento não envia', 'autoriza o uso' in N(cpg.inner_text('[data-sol-err]')))
    cpg.screenshot(path='/tmp/e2e/solic_revisao_iphone.png', full_page=True)
    cpg.check('[data-sol-consent]'); cpg.click('[data-sol-enviar]'); tt = toast(cpg); cpg.wait_for_selector('[data-sol-status]', timeout=8000)
    check('solicitação enviada: o cliente acompanha "Em análise"', 'enviada' in tt and 'Em análise' in N(cpg.inner_text('[data-sol-status]')), tt)
    sid = sql("select id, status from credito_solicitacoes where user_id=?", (CID,))[0]
    check('no banco: pendente, dados e documentos cifrados', sid[1] == 'pendente' and all(r0[0].startswith('v2:') for r0 in sql("select conteudo from credito_documentos where solicitacao_id=? and excluido_em is null", (sid[0],))) and '52998224725' not in sql("select dados_cifrados from credito_solicitacoes where id=?", (sid[0],))[0][0])

    print('== dono (computador): análise')
    def abrir_credito(pg, aba):
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=20000); pg.click('.ma-nav [data-nav=mais]'); pg.click('[data-lt2=credito]'); pg.wait_for_selector(f'[data-cr-aba={aba}]', timeout=15000); pg.click(f'[data-cr-aba={aba}]'); pg.wait_for_timeout(800)
    abrir_credito(dpg, 'limites')
    check('aba "Solicitações de Crédito" com contador de pendentes', 'SolicitaçõesdeCrédito1' in N(dpg.inner_text('[data-cr-aba=limites]')).replace(' ', ''), dpg.inner_text('[data-cr-aba=limites]'))
    check('lista mostra a solicitação pendente', 'Carla Lima' in N(dpg.inner_text('[data-sol-ver]')) and 'Em análise' in N(dpg.inner_text('[data-sol-ver]')))
    dpg.click('[data-sol-ver]'); dpg.wait_for_selector('[data-sol-analise]', timeout=10000)
    an = N(dpg.inner_text('[data-sol-analise]'))
    check('análise: dados cadastrais completos e limite pedido', '529.982.247-25' in an and 'carla.sol@t.com' in an and 'R$ 500,00' in an and '3x' in an, an[:300])
    check('histórico real: cliente sem compras indicado claramente', 'ainda não fez nenhuma compra nesta loja' in an)
    dpg.wait_for_function("()=>[...document.querySelectorAll('[data-sol-docs] img')].length===2&&[...document.querySelectorAll('[data-sol-docs] img')].every(i=>i.complete&&i.naturalWidth>0)", timeout=10000)
    check('documentos abrem na área protegida (imagens carregadas e PDF com link)', dpg.locator('[data-sol-docs] [data-doc=comprovante]').count() == 1)
    url = dpg.get_attribute('[data-sol-docs] [data-doc=documento]', 'href')
    check('endereço do documento é temporário e assinado', bool(re.search(r'/api/v2/credito/documentos/\d+\?exp=\d+&sig=', url or '')), url)
    dpg.screenshot(path='/tmp/e2e/solic_analise_computador.png', full_page=True)
    rr = b.new_context(base_url=BASE).request.get(url); check('sem sessão o documento não abre', rr.status == 401, rr.status)
    rr = C.request.get(url); check('outra pessoa (com sessão) não abre com o endereço do dono', rr.status in (403, 404), rr.status)
    rr = D.request.get(url); check('resposta do documento sem cache e sem indexação', rr.status == 200 and 'no-store' in rr.headers.get('cache-control', '') and rr.headers.get('x-content-type-options') == 'nosniff', rr.headers)
    dpg.fill('[data-sol-nota]', 'Conferir o comprovante.'); dpg.click('[data-sol-nota-ok]'); dpg.wait_for_selector('[data-sol-analise]'); dpg.wait_for_timeout(600)
    check('observação interna registrada', 'Conferir o comprovante.' in N(dpg.inner_text('[data-sol-notas]')))
    dpg.click('[data-sol-info]'); dpg.fill('[data-sol-msg]', 'Envie um comprovante de endereço em seu nome.'); dpg.click('[data-sol-info-ok]'); tt = toast(dpg)
    check('dono pede informações adicionais', 'enviado ao cliente' in tt, tt)

    print('== cliente responde e reenvia')
    tits = ' | '.join(n['title'] for n in C.request.get('/api/notifications').json()['items'])
    check('cliente notificado: recebida e pedido de informações', 'Solicitação de crédito recebida' in tits and 'pediu mais informações' in tits, tits)
    cpg.goto('/x/meu-credito'); cpg.wait_for_selector('[data-cr-sol]', timeout=15000)
    check('Meu crédito mostra a solicitação aguardando resposta', 'Informações pedidas' in N(cpg.inner_text('[data-cr-sols]')))
    cpg.click('[data-cr-sol]'); cpg.wait_for_selector('[data-sol-info]', timeout=10000)
    check('cliente vê o que a loja pediu', 'em seu nome' in N(cpg.inner_text('[data-sol-info]')))
    cpg.click('[data-sol-p1]'); cpg.wait_for_selector('[data-sol-doc=comprovante]', timeout=10000)
    cpg.set_input_files('[data-sol-file=comprovante]', DOC); cpg.wait_for_function("()=>document.querySelector('[data-sol-doc=comprovante] img')", timeout=15000)
    cpg.click('[data-sol-p2]'); cpg.wait_for_selector('[data-sol-revisao]'); cpg.check('[data-sol-consent]'); cpg.click('[data-sol-enviar]'); tt = toast(cpg)
    check('cliente reenvia para análise', 'reenviadas' in tt and sql("select status from credito_solicitacoes where id=?", (sid[0],))[0][0] == 'pendente', tt)

    print('== dono aprova com condições próprias')
    abrir_credito(dpg, 'limites'); dpg.click('[data-sol-ver]'); dpg.wait_for_selector('[data-sol-aprovar]', timeout=10000); dpg.click('[data-sol-aprovar]'); dpg.wait_for_selector('[data-sol-apr-ok]')
    check('formulário de aprovação começa com o limite pedido', dpg.input_value('[data-a=limite]') == '500', dpg.input_value('[data-a=limite]'))
    dpg.fill('[data-a=limite]', '300'); dpg.click('[data-a-parc] [data-p="4"]'); dpg.click('[data-a-jt] [data-j=sem]')
    from datetime import date, timedelta
    dpg.fill('[data-a=validade]', (date.today() + timedelta(days=180)).isoformat()); dpg.fill('[data-a=condicoesCliente]', 'Pagamento no balcão.')
    dpg.screenshot(path='/tmp/e2e/solic_aprovar_computador.png', full_page=True)
    dpg.click('[data-sol-apr-ok]'); tt = toast(dpg)
    cc = sql("select limite, condicoes, validade, solicitacao_id from credito_clientes where user_id=?", (CID,))
    check('aprovada: limite e condições no cadastro de limites do Crédito da Loja', 'aprovado' in tt and len(cc) == 1 and float(cc[0][0]) == 300 and json.loads(cc[0][1])['jurosTipo'] == 'sem' and json.loads(cc[0][1])['parcelas'] == [2, 3] and cc[0][3] == sid[0], (tt, cc))

    print('== cliente compra com o limite aprovado')
    cpg.goto(f'/x/empresa/{ID}'); cpg.wait_for_selector(f'[data-add="{PID}"]', timeout=20000); cpg.click(f'[data-add="{PID}"]'); cpg.wait_for_timeout(400)
    cpg.locator('button:has-text("Ver pedido")').click(); cpg.wait_for_selector('[data-checkout]', timeout=8000); cpg.wait_for_timeout(500)
    ULT[id(cpg)] = cpg.evaluate("()=>{const t=document.getElementById('ma-x-toast');return t?t.textContent:''}")
    check('checkout oferece o Crédito da Loja nas condições aprovadas (até 3x)', 'até 3x' in N(cpg.inner_text('[data-pg=credito]')))
    cpg.click('[data-pg=credito]'); cpg.wait_for_selector('[data-cr-tabela]', timeout=8000); cpg.click('[data-cr-n="3"]'); cpg.wait_for_function("()=>/3 parcelas de\\s+R\\$\\s*40,00/.test((document.querySelector('[data-cr-tabela]')||{}).innerText||'')", timeout=8000)
    tb = N(cpg.inner_text('[data-credito-box]'))
    check('simulação sem juros e com as condições do cliente', 'Sem juros' in tb and 'Pagamento no balcão' in tb, tb[:300])
    cpg.check('[data-cr-aceite]'); cpg.fill('#czap', '11955557476'); cpg.click('#cgo'); tt = toast(cpg)
    o = sql("select status, data from orders where customer_id=? order by id desc limit 1", (CID,))[0]
    check('compra a crédito concluída com o limite aprovado', 'enviado' in tt and o[0] == 'novo' and json.loads(o[1])['pagamento'] == 'credito', (tt, o[0]))
    cpg.goto('/x/meu-credito'); cpg.wait_for_selector('[data-cr-loja]', timeout=15000)
    mc = N(cpg.inner_text('[data-cr-loja]'))
    check('Meu crédito: limite disponível, validade, condições e parcelas', 'R$ 180,00' in mc and 'válido até' in mc and 'Pagamento no balcão' in mc and 'Parcela 3/3' in mc, mc[:300])
    cpg.screenshot(path='/tmp/e2e/solic_meu_credito_iphone.png', full_page=True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and not e.endswith(': Event')], errs[:4])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
