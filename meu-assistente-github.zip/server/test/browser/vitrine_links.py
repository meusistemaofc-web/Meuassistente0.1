import sys, sqlite3, json, datetime, os
DBF=os.environ.get('DBP','/tmp/ma-teste.db')
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
norm=lambda s:s.replace('\xa0',' ')
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    ctx.route('https://exemplo.com/**',lambda r:r.fulfill(status=200,content_type='text/html',body='ok'))
    errs=[]
    # ---- painel: cadastrar pela interface
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Vitrine de Links').click(); pg.wait_for_selector('#vnew',timeout=10000)
    pg.click('#vnew'); pg.wait_for_selector('#vform')
    png=open('/tmp/vit.png','wb'); import base64; png.write(base64.b64decode(IMG.split(',')[1])); png.close()
    pg.set_input_files('#vfile','/tmp/vit.png'); pg.wait_for_timeout(500)
    pg.fill('#vt','Plataforma de Música'); pg.fill('#vd','Acesse sua plataforma de música.'); pg.fill('#vu','https://exemplo.com'); pg.fill('#vk','/musica')
    pg.click('#vsave'); pg.wait_for_selector('[data-vi]',timeout=8000)
    body=norm(pg.inner_text('body')); check('cadastro pelo painel aparece na lista', '/musica' in body and 'Plataforma de Música' in body, body[:300])
    pg.click('#vnew'); pg.wait_for_selector('#vform'); pg.fill('#vt','Outra'); pg.fill('#vd','Descrição qualquer'); pg.fill('#vu','https://x.com.br'); pg.fill('#vk','/musica'); pg.set_input_files('#vfile','/tmp/vit.png'); pg.wait_for_timeout(400); pg.click('#vsave'); pg.wait_for_selector('#verr:has-text("já está em uso")',timeout=6000)
    check('palavra-chave duplicada é recusada na tela', True)
    pg.fill('#vk','/musicas-tv'); pg.fill('#vu','javascript:alert(1)'); pg.click('#vsave'); pg.wait_for_timeout(700); check('URL perigosa é recusada', 'http' in pg.inner_text('#verr'), pg.inner_text('#verr'))
    pg.fill('#vu','https://tv.example.com'); pg.click('#vsave'); pg.wait_for_selector('[data-vi]:nth-child(2)',timeout=8000)
    pg.screenshot(path='/tmp/e2e/vitrine_admin.png',full_page=True)
    # ---- chat principal
    c=ctx.new_page(); c.on('pageerror',lambda e:errs.append(str(e))); c.on('dialog',lambda d:d.accept())
    c.goto('/'); c.wait_for_selector('textarea.composer-input',timeout=15000); c.wait_for_timeout(1200)
    ta=c.locator('textarea.composer-input'); sent=[]
    c.on('request',lambda r:sent.append(r.url) if '/api/chat' in r.url or '/api/v2/chat' in r.url else None)
    ta.click(); ta.type('/'); c.wait_for_selector('.ma-vit-menu',timeout=5000)
    opts=c.locator('.ma-vit-menu [role=option]'); check('digitar / abre o menu com todos os atalhos ativos', opts.count()==2, opts.count())
    c.screenshot(path='/tmp/e2e/vitrine_menu.png')
    ta.type('mus'); c.wait_for_timeout(300); check('/mus filtra em tempo real (musica e musicas-tv)', c.locator('.ma-vit-menu [role=option]').count()==2 and '/musica' in c.inner_text('.ma-vit-menu'))
    ta.press('Control+a'); ta.type('/tv'); c.wait_for_timeout(300); check('/tv filtra só a TV', c.locator('.ma-vit-menu [role=option]').count()==1)
    ta.press('Control+a'); ta.type('/musica'); c.wait_for_timeout(300)
    check('/musica deixa a correspondência exata selecionada', 'musica' in c.locator('.ma-vit-menu [aria-selected=true]').inner_text())
    ta.press('Enter'); c.wait_for_selector('.ma-vit-card',timeout=5000)
    cd=norm(c.inner_text('.ma-vit-card')); check('Enter abre o card com título, descrição e botão', 'Plataforma de Música' in cd and 'Acesse sua plataforma' in cd and 'Acessar' in cd, cd)
    check('card tem a imagem cadastrada', c.locator('.ma-vit-card img').count()==1)
    check('o atalho não foi enviado como mensagem e o campo foi limpo', not sent and ta.input_value()=='', (sent, ta.input_value()))
    with ctx.expect_page() as np_: c.click('.ma-vit-card button')
    np_.value.wait_for_load_state('commit') if False else None
    check('botão abre o link externo em nova aba', 'exemplo.com' in np_.value.url or np_.value.url.startswith('https://exemplo'), np_.value.url)
    np_.value.close()
    # selecionar com toque/clique no menu
    ta.click(); ta.type('/'); c.wait_for_selector('.ma-vit-menu'); c.locator('.ma-vit-menu [role=option]').nth(1).dispatch_event('pointerdown'); c.wait_for_timeout(800)
    check('selecionar pelo menu também abre o card', c.locator('.ma-vit-card').count()==2)
    # URLs, código e texto comum não disparam
    for txt in ['http://exemplo.com/a','/usr/bin/env','oi /musica','1/2','//']:
        ta.click(); ta.press('Control+a'); ta.type(txt); c.wait_for_timeout(250)
        check(f'"{txt}" não abre o menu', c.locator('.ma-vit-menu').count()==0)
    ta.press('Control+a'); ta.press('Delete')
    # sem resultado não intercepta o envio
    ta.type('/zzzz'); c.wait_for_timeout(300); check('/zzzz sem resultado não mostra menu', c.locator('.ma-vit-menu').count()==0)
    ta.press('Control+a'); ta.type('olá, tudo bem?'); ta.press('Enter'); c.wait_for_timeout(1500)
    check('mensagem comum continua sendo enviada normalmente', 'olá, tudo bem?' in norm(c.inner_text('.chat-scroll')), norm(c.inner_text('body'))[:200])
    # desativar remove dos resultados
    pg.bring_to_front(); pg.locator('[data-vi] [data-sw]').first.click(); pg.wait_for_timeout(1200)
    c.bring_to_front(); c.evaluate('window.__maVitrineReload()'); ta.click(); ta.type('/'); c.wait_for_timeout(500)
    check('desativar remove o atalho do menu', c.locator('.ma-vit-menu [role=option]').count()==1 and '/musicas-tv' in c.inner_text('.ma-vit-menu'))
    c.screenshot(path='/tmp/e2e/vitrine_card.png')
    # contadores no painel
    pg.reload(); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Vitrine de Links').click(); pg.wait_for_selector('[data-vi]'); bd=norm(pg.inner_text('body')); check('painel mostra acessos e cliques', '1 clique' in bd and 'acesso' in bd, bd[:400])
    # ---- agente da empresa (público)
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    assert R.put(f'/api/v2/ads/{ID}/agent',data={'ativo':True,'flutuante':{'ativo':True,'msg':'Oi'}}).ok
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']['expiresAt']=(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit(); db.close()
    R.post('/api/panel/showcase',data={'action':'update','id':1,'ativo':True,'canais':['chat','agentes']})
    an=b.new_context(viewport={'width':390,'height':844},base_url=BASE,is_mobile=True,has_touch=True).new_page(); an.on('pageerror',lambda e:errs.append(str(e)))
    an.goto(f'/a/{ID}'); an.wait_for_selector('#t',timeout=10000); an.wait_for_timeout(800); an.click('#t'); an.type('#t','/mus'); an.wait_for_selector('.ma-vit-menu',timeout=5000)
    check('agente da empresa também mostra o menu para visitante sem login', 'musica' in an.inner_text('.ma-vit-menu'))
    an.press('#t','Enter'); an.wait_for_selector('.ma-vit-card',timeout=5000); check('card aparece no agente', 'Plataforma de Música' in an.inner_text('.ma-vit-card'))
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
