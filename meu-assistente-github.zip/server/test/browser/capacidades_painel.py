import json, sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'  # ajuste se usar outra porta
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.on('dialog',lambda d:d.accept())
    pg.goto('/admin'); pg.wait_for_timeout(1500)
    pg.get_by_role('button',name='Cérebro e busca').click(); pg.wait_for_selector('#cap_l [data-cap]',timeout=10000)
    api=R.get('/api/panel/brain/capabilities').json()
    body=pg.inner_text('body')
    check('seção "Capacidades da inteligência" aparece no Cérebro', 'capacidades da inteligência' in body.lower())
    check('mostra as 4 situações com contagem', all(x in body for x in ['Ativo','Inativo','Pendente','Em desenvolvimento']))
    cats=['Atendimento ao cliente','Agendamentos e gestão de serviços','Gestão financeira e pagamentos','Marketing e campanhas','Notificações push','Vendas e estratégias comerciais','CRM e relacionamento com clientes','Pós-venda e fidelização','Gestão de clientes','Regras de interpretação e execução de comandos','Integrações e inteligência artificial']
    check('todas as categorias pedidas aparecem', all(c.upper() in body.upper() for c in cats), [c for c in cats if c.upper() not in body.upper()])
    check('quantidade de cartões = capacidades da API', pg.locator('#cap_l [data-cap]').count()==len(api['itens']), (pg.locator('#cap_l [data-cap]').count(),len(api['itens'])))
    crm=pg.locator('[data-cap=crm-completo]').inner_text()
    check('CRM completo aparece como Em desenvolvimento (não como pronto)', 'Em desenvolvimento' in crm and 'Ativo' not in crm, crm)
    # conteúdo
    c=pg.locator('[data-cap=atendimento-playbook]'); c.get_by_role('button',name='Ver conteúdo').click()
    check('Ver conteúdo mostra o que o chat sabe e a origem', 'O que o chat sabe ou faz' in c.inner_text() and 'implementado no sistema' in c.inner_text(), c.inner_text())
    # filtros
    pg.click('[data-capst=desenvolvimento]'); pg.wait_for_timeout(300)
    n=pg.locator('#cap_l [data-cap]').count()
    check('filtro por status mostra só os em desenvolvimento', n==api['resumo']['desenvolvimento'] and n>=2 and all('Em desenvolvimento' in t for t in pg.locator('#cap_l [data-cap]').all_inner_texts()), n)
    pg.click('[data-capst=desenvolvimento]'); pg.wait_for_timeout(300)
    pg.select_option('#cap_c','Notificações push'); pg.wait_for_timeout(200)
    check('filtro por categoria', pg.locator('#cap_l [data-cap]').count()==2 and 'Notificações push' in pg.inner_text('#cap_l'), pg.locator('#cap_l [data-cap]').count())
    pg.select_option('#cap_c',''); pg.fill('#cap_q','fidelidade'); pg.wait_for_timeout(200)
    check('busca por texto', pg.locator('#cap_l [data-cap]').count()>=1 and 'fidelidade' in pg.inner_text('#cap_l').lower())
    pg.fill('#cap_q','')
    # novo cadastro aparece sozinho (ao Atualizar), com status
    pg.fill('#bn_t','Política de cancelamento'); pg.fill('#bn_c','Cancelamentos até 24 horas antes não têm multa.'); pg.click('#bn_go'); pg.wait_for_selector('[data-it]',timeout=8000)
    pg.click('#cap_r'); pg.wait_for_timeout(800)
    pg.select_option('#cap_o','cadastro'); pg.wait_for_timeout(200)
    t=pg.inner_text('#cap_l')
    check('conhecimento novo cadastrado aparece automaticamente, ativo, na categoria de cadastrados', 'Política de cancelamento' in t and 'Conhecimentos e regras cadastrados'.upper() in t.upper() and 'Ativo' in t, t[:300])
    # desligar módulo → status inativo refletido
    R.put('/api/panel/modules',data={'financas':False}); pg.click('#cap_r'); pg.wait_for_timeout(800); pg.select_option('#cap_o','')
    check('módulo desligado vira Inativo na tela', 'Inativo' in pg.locator('[data-cap=fin-lancamentos]').inner_text())
    R.put('/api/panel/modules',data={'financas':True})
    pg.screenshot(path='/tmp/e2e/capacidades.png',full_page=False)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
