# Ditado no chat — FALLBACK sem reconhecimento contínuo do aparelho (iPhone/Safari ou navegador sem SpeechRecognition): grava e
# transcreve no servidor (tela real, microfone simulado do Chromium + Whisper falso controlável). O texto entra DIRETO no campo.
# A transcrição AO VIVO (aparelho com reconhecimento) está em ditado_ao_vivo.py.
# • microfone → botão em "ouvindo" → tocar de novo → botão em "transcrevendo" → o texto aparece NO CAMPO (sem barra
#   "Ouvindo…/Transcrevendo…", sem aviso "Transcrição pronta"); nada é enviado ao chat, nenhum áudio vai para /api/chat;
# • texto digitado antes é preservado; ditados seguidos se somam; editar e enviar → mensagem de TEXTO normal;
# • enviar fica indisponível enquanto grava: nunca há envio automático; o envio é sempre um toque em enviar;
# • fala em espanhol chega em espanhol; falha da transcrição mostra aviso discreto e não mexe no campo;
# • microfone bloqueado → mensagem clara; celular (390 px) e computador; sem erros de JavaScript.
# Servidor: WHISPER_URL=http://127.0.0.1:4398 PORT=4338 SQLITE_FILE=/tmp/ma-dit.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re, json, math, struct, wave, threading, os
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4338'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
# --- Whisper falso: responde o que o teste mandar (/set) ---
ESTADO = {'status': 200, 'text': '', 'hits': 0, 'lang': []}
class W(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        q = parse_qs(urlparse(self.path).query); ESTADO['status'] = int(q.get('status', ['200'])[0]); ESTADO['text'] = q.get('text', [''])[0]
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok')
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); body = self.rfile.read(n); ESTADO['hits'] += 1
        ESTADO['lang'].append(b'name="language"' in body)
        if not self.path.startswith('/v1/audio/transcriptions'): self.send_response(404); self.end_headers(); return
        b = json.dumps({'text': ESTADO['text']} if ESTADO['status'] == 200 else {'error': 'falha simulada'}).encode()
        self.send_response(ESTADO['status']); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)
srv = HTTPServer(('127.0.0.1', 4398), W); threading.Thread(target=srv.serve_forever, daemon=True).start()
def fala(texto, status=200):
    import urllib.request, urllib.parse
    urllib.request.urlopen('http://127.0.0.1:4398/set?' + urllib.parse.urlencode({'text': texto, 'status': status})).read()
# --- áudio do microfone simulado: tom audível (passa do limiar de voz do app) ---
WAV = '/tmp/ditado_tom.wav'
with wave.open(WAV, 'w') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
    w.writeframes(b''.join(struct.pack('<h', int(14000 * math.sin(2 * math.pi * 330 * i / 16000))) for i in range(16000 * 6)))
ARGS = ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', f'--use-file-for-fake-audio-capture={WAV}']
with sync_playwright() as p:
    b = p.chromium.launch(args=ARGS); errs = []
    A = b.new_context(base_url=BASE)
    assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1236', 'email': 'admin.dit@t.com', **U}).ok
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, permissions=['microphone']); R = C.request
        C.add_init_script('delete window.SpeechRecognition; delete window.webkitSpeechRecognition')  # aparelho sem reconhecimento contínuo
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Davi Teste', 'whatsapp': f'+55 11 97777-{k}{k}{k}{k}', 'email': f'davi{k}.dit@t.com', **U}, headers={'X-Forwarded-For': f'10.9.2.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios = []
        pg.on('request', lambda r: envios.append((r.method, r.url, r.headers.get('content-type', ''), r.post_data or '')) if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        transc = []; pg.on('request', lambda r: transc.append(r.url) if '/api/transcribe' in r.url else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(400)
        campo = lambda: pg.input_value('textarea[data-composer-input]')
        bolhas = lambda: pg.locator('.chat-scroll .msg-bubble').count()
        mic = lambda: pg.locator('button[aria-label="Ditar mensagem"], button[aria-label="Parar ditado"]').first
        def ditar(texto, status=200, esperar_texto=True):
            fala(texto, status); mic().click()
            pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=10000); pg.wait_for_timeout(2600)
            pg.locator('button[aria-label="Parar ditado"]').click()
            try: pg.wait_for_selector('[data-ditado-estado="inativo"], [data-ditado-estado="erro"]', timeout=15000)
            except Exception: pass
            pg.wait_for_timeout(300 if esperar_texto else 1500)
        check(f'{nome}: o microfone é de ditado (não grava mensagem de áudio)', pg.locator('button[aria-label="Ditar mensagem"]').count() == 1 and pg.locator('button[aria-label="Gravar mensagem de voz"]').count() == 0)
        # 1) ditado → texto no campo, nada enviado, sem interface separada
        b0, e0 = bolhas(), len(envios)
        fala('gastei 18 reais na padaria'); mic().click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=10000)
        sep = [t for t in ['Ouvindo… fale agora', 'Transcrevendo', 'Preparando o microfone'] if t in pg.inner_text('body')]
        check(f'{nome}: gravando: estado no próprio botão, sem barra "Ouvindo…" nem botão Cancelar separado', not sep and pg.locator('[role="status"] button:has-text("Cancelar")').count() == 0, sep)
        check(f'{nome}: enquanto grava, enviar fica indisponível (sem envio automático)', not pg.locator('button[aria-label="Enviar"]').is_enabled())
        if mob: pg.screenshot(path='/tmp/e2e/ditado_ouvindo.png')
        pg.wait_for_timeout(2600); pg.locator('button[aria-label="Parar ditado"]').click()
        try: pg.wait_for_function("()=>document.querySelector('textarea[data-composer-input]').value.length>0", timeout=15000); ok = True
        except Exception: ok = False
        check(f'{nome}: transcrição aparece direto no campo para revisar', ok and campo() == 'Gastei 18 reais na padaria', campo())  # o app põe a primeira letra em maiúscula
        pg.wait_for_timeout(300)
        check(f'{nome}: sem aviso "Transcrição pronta" nem botões extras', 'Transcrição pronta' not in pg.inner_text('body') and pg.locator('[data-ditado-pronto]').count() == 0, pg.inner_text('body')[-200:])
        check(f'{nome}: nada foi enviado ao chat (nenhuma mensagem, nenhum áudio)', bolhas() == b0 and len(envios) == e0 and len(transc) >= 1, (bolhas(), b0, envios[e0:]))
        check(f'{nome}: a transcrição não força idioma', ESTADO['lang'] and not ESTADO['lang'][-1])
        if mob: pg.screenshot(path='/tmp/e2e/ditado_pronto.png')
        # 2) editar e enviar → texto normal
        pg.fill('textarea[data-composer-input]', 'gastei 19 reais na padaria'); pg.locator('button[aria-label="Enviar"]').click()
        try: pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={b0 + 2}", timeout=15000)
        except Exception: pass
        pg.wait_for_timeout(1200)
        env = envios[e0:]
        check(f'{nome}: ao enviar, vai TEXTO (JSON) com a versão editada — sem áudio', len(env) == 1 and 'application/json' in env[0][2] and json.loads(env[0][3]).get('text') == 'gastei 19 reais na padaria' and 'audio' not in env[0][3], env)
        ult = N(pg.locator('.chat-scroll .msg-bubble').last.inner_text())
        check(f'{nome}: o motor responde como a uma mensagem digitada', re.search(r'Gasto registrado: R\$ 19,00', ult), ult)
        check(f'{nome}: depois do envio o campo fica vazio', campo() == '')
        # 3) texto digitado antes é preservado e ditados seguidos se somam (nada é apagado)
        pg.fill('textarea[data-composer-input]', 'Nota:'); ditar('primeira parte')
        check(f'{nome}: transcrição entra depois do texto que já estava no campo', campo() in ('Nota: primeira parte', 'Nota:primeira parte'), campo())
        ditar('segunda parte')
        check(f'{nome}: um novo ditado complementa o texto (não substitui)', campo().startswith('Nota:') and 'primeira parte' in campo() and campo().lower().endswith('segunda parte'), campo())
        pg.fill('textarea[data-composer-input]', '')
        # 5) fala em espanhol
        b1 = bolhas(); ditar('¿Cuánto gasté este mes en comida?')
        check(f'{nome}: fala em espanhol chega em espanhol ao campo', campo() == '¿Cuánto gasté este mes en comida?', campo())
        pg.locator('button[aria-label="Enviar"]').click()
        try: pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={b1 + 2}", timeout=15000)
        except Exception: pass
        pg.wait_for_timeout(1500); bub = pg.locator('.chat-scroll .msg-bubble')
        resp = N(bub.last.inner_text())
        check(f'{nome}: enviado como digitado e respondido em espanhol', '¿Cuánto gasté este mes en comida?' in N(bub.nth(bub.count() - 2).inner_text()) and (resp.startswith('[es]') or '¡Hola' in resp or 'Hola' in resp), resp)
        # 6) falha da transcrição: mensagem e campo intacto
        pg.fill('textarea[data-composer-input]', 'texto meu'); b2, e2 = bolhas(), len(envios)
        ditar('', status=500, esperar_texto=False)
        corpo = N(pg.inner_text('body'))
        check(f'{nome}: falha na transcrição mostra aviso e não mexe no campo nem envia', ('Não consegui transcrever o áudio agora' in corpo or 'Não reconheci nenhuma fala' in corpo) and campo() == 'texto meu' and bolhas() == b2 and len(envios) == e2, (campo(), corpo[-200:]))
        if mob: pg.screenshot(path='/tmp/e2e/ditado_falha.png')
        # 7) enviar só por toque: durante a gravação o envio fica indisponível; parar → texto no campo → enviar → uma mensagem
        pg.fill('textarea[data-composer-input]', ''); b3, e3 = bolhas(), len(envios)
        fala('lembrar de comprar ração'); mic().click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=10000); pg.wait_for_timeout(2200)
        en = pg.locator('button[aria-label="Enviar"]')
        check(f'{nome}: durante a gravação o botão enviar não dispara nada', not en.is_enabled() and len(envios) == e3)
        pg.locator('button[aria-label="Parar ditado"]').click()
        pg.wait_for_function("()=>document.querySelector('textarea[data-composer-input]').value.includes('ração')", timeout=15000); pg.wait_for_timeout(800)
        check(f'{nome}: ao terminar, o texto fica no campo e nada é enviado sozinho', len(envios) == e3 and 'ração' in campo(), campo())
        en.click()
        try: pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={b3 + 2}", timeout=15000)
        except Exception: pass
        pg.wait_for_timeout(1500)
        env = [e for e in envios[e3:] if 'ração' in e[3]]
        check(f'{nome}: enviar manda o texto do campo (uma mensagem, texto)', len(env) == 1 and 'application/json' in env[0][2] and campo() == '' and 'ração' in N(pg.locator('.chat-scroll .bubble-user').last.inner_text()), env)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        C.close()
    # 7) microfone bloqueado
    print('== microfone bloqueado')
    b2 = p.chromium.launch(args=['--use-fake-device-for-media-stream', '--deny-permission-prompts'])
    C = b2.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    C.add_init_script('delete window.SpeechRecognition; delete window.webkitSpeechRecognition')  # aparelho sem reconhecimento contínuo
    # permissão negada como os navegadores reais respondem (o Chromium sem tela devolve NotSupportedError ao negar o aviso)
    C.add_init_script("navigator.mediaDevices.getUserMedia=()=>Promise.reject(new DOMException('Permission denied','NotAllowedError'))")
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bruna Teste', 'whatsapp': '+55 11 97777-3333', 'email': 'bruna.dit@t.com', **U}, headers={'X-Forwarded-For': '10.9.2.9'}).ok
    pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(400)
    pg.locator('button[aria-label="Ditar mensagem"]').click(); pg.wait_for_timeout(2500); corpo = N(pg.inner_text('body'))
    check('microfone bloqueado → explica como liberar e não envia nada', 'microfone' in corpo.lower() and ('bloqueado' in corpo or 'Libere' in corpo or 'permite' in corpo), corpo[-250:])
    b2.close()
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
srv.shutdown()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
