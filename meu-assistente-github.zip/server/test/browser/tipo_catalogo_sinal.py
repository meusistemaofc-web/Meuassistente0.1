import json, sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Estúdio Misto','categoria':'Variados','titulo':'t','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Caneca','preco':30,'fotos':[IMG],'tipo':'produto'}).ok
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Sessão de foto','preco':200,'tipo':'servico','modoPreco':'fixo','duracao':60}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    pg.locator('button:has-text("Tipo de catálogo")').first.click(); pg.wait_for_selector('[data-op]',timeout=8000)
    check('três opções de catálogo', pg.locator('[data-op]').count()==3)
    check('opção atual (Produtos e serviços) marcada', pg.get_attribute('[data-op=ambos]','aria-pressed')=='true')
    check('mostra quantos itens existem e que nada é apagado', '1 produto(s) e 1 serviço(s)' in pg.inner_text('body') and 'nada é apagado' in pg.inner_text('body'))
    pg.click('[data-op=servicos]'); pg.click('#opsv'); pg.wait_for_timeout(1500)
    me=R.get('/api/v2/ads/mine').json()['items'][0]; check('tipo salvo no servidor', me['operacao']=='servicos' and me['tipoDefinido'], me.get('operacao'))
    pub=R.get(f'/api/v2/businesses/{ID}').json(); check('página pública só com serviços', [x['nome'] for x in pub['produtos']]==['Sessão de foto'], pub['produtos'])
    pg.locator('[data-nav]',has_text='Serviços').first.click(); pg.wait_for_selector('#ptp',timeout=8000)
    check('formulário oferece só Serviço', pg.locator('#ptp option').count()==1 and pg.inner_text('#ptp').startswith('Serviço'))
    body=pg.inner_text('body')
    check('produto existente continua listado, marcado como oculto', 'Caneca' in body and 'oculto aos clientes' in body, body[:400])
    check('faixa mostra o tipo atual com botão Alterar', 'Catálogo: Serviços' in body.replace('\n',' ') or 'Serviços' in body)
    pg.locator('button:has-text("Alterar")').first.click(); pg.wait_for_selector('[data-op]'); pg.click('[data-op=ambos]'); pg.click('#opsv'); pg.wait_for_timeout(1200)
    pub=R.get(f'/api/v2/businesses/{ID}').json(); check('voltou para ambos: tudo reaparece', len(pub['produtos'])==2)
    check('sem erros de JavaScript do módulo', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
