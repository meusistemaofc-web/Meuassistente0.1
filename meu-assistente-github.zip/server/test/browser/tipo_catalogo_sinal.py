# Tipo de catálogo EXCLUSIVO (produtos OU serviços) pela tela real: só duas opções, troca exige aviso das consequências e
# confirmação, cancelar não muda nada, itens da outra modalidade ficam salvos (ocultos), cadastro só oferece a modalidade atual,
# edição do anúncio não troca a modalidade, painel administrativo mostra a modalidade. Celular e computador.
import json, sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    amb=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Estúdio Misto','categoria':'Variados','titulo':'t','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'})
    check('criar empresa com produtos E serviços é bloqueado no servidor', amb.status==400 and amb.json().get('code')=='modalidade_exclusiva', amb.text()[:200])
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Estúdio Misto','categoria':'Variados','titulo':'t','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    check('empresa nasce com UMA modalidade (products)', r.json()['items'][0]['modalidade']=='products')
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Caneca','preco':30,'fotos':[IMG],'tipo':'produto'}).ok
    sv=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Sessão de foto','preco':200,'tipo':'servico','modoPreco':'fixo','duracao':60})
    check('cadastrar serviço numa empresa de produtos é bloqueado', sv.status==400, sv.text()[:200])
    errs=[]
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); c.add_cookies(ctx.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
        pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
        pg.locator('button:has-text("Tipo de catálogo")').first.click(); pg.wait_for_selector('[data-op]',timeout=8000)
        atual='products' if nome=='celular' else 'services'
        check(f'{nome}: só duas opções (Produtos, Serviços), sem "os dois"', pg.locator('[data-op]').count()==2 and pg.locator('[data-op=ambos]').count()==0 and 'Produtos e serviços' not in pg.inner_text('#modbox'))
        check(f'{nome}: opção atual marcada e única', pg.get_attribute(f'[data-op={atual}]','aria-checked')=='true' and pg.locator('[data-op][aria-checked=true]').count()==1)
        outra='services' if atual=='products' else 'products'
        pg.click(f'[data-op={outra}]'); pg.click('#opsv'); pg.wait_for_selector('#modconf',timeout=8000)
        aviso=pg.inner_text('#modconf')
        check(f'{nome}: antes de trocar mostra as consequências (ocultos, nada apagado, histórico preservado)', 'ficarão ocultos' in aviso and 'nada é apagado' in aviso and 'preservado' in aviso and pg.locator('#modok').count()==1, aviso[:300])
        if nome=='celular': pg.screenshot(path='/tmp/e2e/modalidade_aviso_celular.png')
        pg.click('#modno'); pg.wait_for_timeout(500)
        check(f'{nome}: cancelar não altera nada', R.get(f'/api/v2/ads/{ID}/modalidade').json()['atual']==atual and pg.locator('#modconf').count()==0)
        pg.click(f'[data-op={outra}]'); pg.click('#opsv'); pg.wait_for_selector('#modok',timeout=8000); pg.click('#modok'); pg.wait_for_timeout(1500)
        check(f'{nome}: confirmar aplica a nova modalidade no servidor', R.get(f'/api/v2/ads/{ID}/modalidade').json()['atual']==outra)
        pub=R.get(f'/api/v2/businesses/{ID}').json()
        if outra=='services':
            check(f'{nome}: página pública sem produtos (empresa de serviços)', pub['produtos']==[] and pub['operacao']=='servicos', pub.get('produtos'))
            assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Sessão de foto','preco':200,'tipo':'servico','modoPreco':'fixo','duracao':60}).ok
            pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1200); pg.locator('[data-nav]',has_text='Serviços').first.click(); pg.wait_for_selector('#ptp',timeout=8000)
            check(f'{nome}: formulário de cadastro oferece só Serviço', pg.locator('#ptp option').count()==1 and pg.inner_text('#ptp').startswith('Serviço'))
            body=pg.inner_text('body'); check(f'{nome}: produto existente continua salvo, marcado como oculto', 'Caneca' in body and 'oculto aos clientes' in body, body[:300])
        else:
            check(f'{nome}: voltou para produtos: só produtos na página, serviço preservado oculto', [x['nome'] for x in pub['produtos']]==['Caneca'] and len(R.get(f'/api/v2/ads/{ID}/products').json()['items'])==2, pub.get('produtos'))
        # edição comum do anúncio não troca a modalidade
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1000)
        c.close()
    pt=R.put(f'/api/v2/ads/{ID}',data={'tipo':'servicos'}); check('PUT com outra modalidade é recusado (exige o fluxo com confirmação)', pt.status==409 and pt.json()['code']=='modalidade_confirmacao', pt.text()[:200])
    # painel administrativo mostra a modalidade
    a=b.new_context(viewport={'width':1280,'height':900},base_url=BASE); a.add_cookies(ctx.cookies()); ap=a.new_page(); ap.goto('/admin'); ap.wait_for_timeout(1500)
    ap.get_by_role('button',name=re.compile('Anúncios')).first.click(); ap.wait_for_selector('[data-modalidade]',timeout=15000)
    check('painel administrativo mostra a modalidade de cada empresa', ap.locator('[data-modalidade="products"]').count()>=1 and 'Produtos' in ap.inner_text('[data-modalidade="products"]'))
    a.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
