# Busca visual de produtos (telas): no modo "Busca de produtos e serviços", a pessoa anexa uma foto pelo + do campo e recebe,
# no próprio chat, o produto identificado e os cards das lojas (imagem, nome, marca/modelo, preço, loja, disponibilidade,
# correspondência e link), com "Preço não verificado" quando a loja não publica o preço; instrução escrita junto da foto
# ("mais barato"); foto sem marca → "parece ser" e semelhantes; foto que não é produto; pesquisa fora do ar → mensagem
# honesta com "Tentar de novo" (e o botão funciona); celular e computador; os outros modos e o chat normal intactos.
# Servidor: CEREBRO_PERMITIR_REDE_LOCAL=1 PORT=4375 SQLITE_FILE=/tmp/ma-bvis.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
import json, threading, io, os, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from PIL import Image
from playwright.sync_api import sync_playwright
BASE='http://localhost:4375'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
EST={'fora':False}
def ld(o): return '<script type="application/ld+json">'+json.dumps({'@context':'https://schema.org',**o})+'</script>'
PAG={'/zuntra/p/veloz-3':ld({'@type':'Product','name':'Tênis de Corrida Zuntra Veloz 3 Azul','brand':{'@type':'Brand','name':'Zuntra'},'model':'Veloz 3','gtin13':'7891234567895','image':'/img/tenis.png','offers':{'price':'499.90','priceCurrency':'BRL','availability':'https://schema.org/InStock','seller':{'name':'Zuntra Oficial'}}}),
 '/megaloja/produto/zuntra-veloz-3':'<meta property="og:type" content="product"><meta property="og:title" content="Zuntra Veloz 3 Masculino"><meta property="og:image" content="/img/tenis.png"><meta property="product:price:amount" content="429,90"><meta property="product:price:currency" content="BRL"><meta property="og:site_name" content="MegaLoja">',
 '/casa/p/garrafa':ld({'@type':'Product','name':'Garrafa Térmica Termix Inox 1L','brand':'Termix','model':'Inox 1L','offers':{'price':'119.00','priceCurrency':'BRL','availability':'InStock'}}),
 '/casa/p/luminaria':ld({'@type':'Product','name':'Luminária de Mesa Articulada Preta','brand':'Lumi','offers':{'price':'89.90','priceCurrency':'BRL','availability':'InStock'}})}
def png(cor):
    b=io.BytesIO(); Image.new('RGB',(120,120),cor).save(b,'PNG'); return b.getvalue()
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        u=urlparse(self.path); base=f'http://127.0.0.1:{self.server.server_port}'
        def out(code,ct,body): self.send_response(code); self.send_header('Content-Type',ct); self.end_headers(); self.wfile.write(body if isinstance(body,bytes) else body.encode())
        if u.path=='/robots.txt': return out(200,'text/plain','User-agent: *\nDisallow: /bloqueada\n')
        if u.path=='/search':
            if EST['fora']: return out(500,'text/plain','erro')
            q=parse_qs(u.query).get('q',[''])[0]
            if 'zuntra' in q.lower() and not EST.get('lento'): EST['lento']=1; import time; time.sleep(3)  # 1ª pesquisa lenta: o indicador mostra as etapas reais
            R=lambda p,t:{'url':base+p,'title':t,'content':t,'engine':'duckduckgo'}
            if 'zuntra' in q.lower() or '7891234567895' in q: r=[R('/zuntra/p/veloz-3','Zuntra Veloz 3 - Loja Oficial'),R('/megaloja/produto/zuntra-veloz-3','Zuntra Veloz 3 Masculino'),R('/bloqueada/p/zuntra-veloz-3','Zuntra Veloz 3 na Loja Bloqueada')]
            elif 'termix' in q.lower(): r=[R('/casa/p/garrafa','Garrafa Térmica Termix Inox 1L')]
            elif 'lumin' in q.lower(): r=[R('/casa/p/luminaria','Luminária de Mesa Articulada Preta')]
            else: r=[]
            return out(200,'application/json',json.dumps({'results':r}))
        if u.path=='/img/tenis.png': return out(200,'image/png',png((40,90,200)))
        if u.path in PAG: return out(200,'text/html; charset=utf-8','<!doctype html><html><head><title>Loja</title></head><body>'+PAG[u.path]+'</body></html>')
        out(404,'text/plain','')
loja=ThreadingHTTPServer(('127.0.0.1',0),H); threading.Thread(target=loja.serve_forever,daemon=True).start(); LB=f'http://127.0.0.1:{loja.server_port}'
def foto(nome,h):
    p=f'/tmp/e2e/{nome}.jpg'; Image.new('RGB',(300,h),(200,200,210)).save(p,'JPEG',quality=90); return p
F1=foto('vis_tenis',201); F2=foto('vis_lumi',202); F3=foto('vis_nada',203); F4=foto('vis_garrafa',204)
def ultima(pg): return pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
def espera_resposta(pg,n,t=40000):
    for _ in range(t//250):
        if pg.locator('.chat-scroll .msg-bubble').count()>=n+2 and not pg.locator('.chat-scroll [role="status"][aria-label="Preparando a resposta"]').count(): break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(1500); return ultima(pg)
def envia(pg,txt):
    n=pg.locator('.chat-scroll .msg-bubble').count(); pg.locator('textarea.composer-input').fill(txt); pg.wait_for_timeout(150); pg.locator('[aria-label="Enviar"]').click(); return espera_resposta(pg,n)
def anexa(pg,arq,legenda=''):
    n=pg.locator('.chat-scroll .msg-bubble').count()
    if legenda: pg.locator('textarea.composer-input').fill(legenda)
    pg.locator('.ma-composer-bar input[type=file]').first.set_input_files(arq); pg.wait_for_timeout(700)
    if pg.locator('.chat-scroll .msg-bubble').count()<n+1:  # prévia: confirma o envio
        b=pg.locator('[aria-label="Enviar"]');
        if b.count() and b.is_enabled(): b.click()
    return espera_resposta(pg,n)
TEC=['searxng','provedor','timeout','HTTP ','robots','stack','erro interno']
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Visual','email':'admin@vis.com','whatsapp':'+55 11 94444-6161',**U}).ok
    assert A.put('/api/panel/ai_providers',data={'items':[{'id':'servidor','imagem':True,'texto':True,'ativo':True}]}).ok
    pv=A.get('/api/brain/providers').json()['provedores']
    for x in pv:
        if x['tipo']=='busca': A.put(f"/api/brain/providers/{x['id']}",data={'url':LB,'ativo':True,'papel':'principal','retomar':True} if x['provedor']=='searxng' else {'ativo':False})
    u=b.new_context(base_url=BASE); assert u.request.post('/api/auth',data={'action':'signup','name':'Cliente Visual','email':'cli@vis.com','whatsapp':'+55 11 94444-6262',**U}).ok; st=u.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        etapas=[]; pg.on('console',lambda m: None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_selector('.ma-modos-btn',timeout=10000); pg.wait_for_timeout(2000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
        pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo="busca"]',timeout=8000)
        desc=pg.locator('#ma-modos-card [data-modo="busca"]').inner_text(); pg.click('#ma-modos-card [data-modo="busca"]')
        n0=pg.locator('.chat-scroll .msg-bubble').count(); r=espera_resposta(pg,n0-2 if n0>=2 else 0)
        for _ in range(40):
            if 'foto' in ultima(pg): break
            pg.wait_for_timeout(250)
        check(f'{nome}: ⚡ Busca convida a enviar a foto do produto', 'foto' in ultima(pg) and 'foto' in desc, (desc, ultima(pg)[:200]))
        # observa o indicador de etapas durante a busca por foto
        pg.evaluate("()=>{window.__et=[];const o=new MutationObserver(()=>{const e=[...document.querySelectorAll('.ma-ind-t')].pop();if(e&&e.textContent&&window.__et[window.__et.length-1]!==e.textContent)window.__et.push(e.textContent)});o.observe(document.body,{subtree:true,childList:true,characterData:true})}")
        r=anexa(pg,F1); pg.wait_for_selector('.chat-scroll .ma-bv .ma-bvc',timeout=20000); pg.wait_for_timeout(1500)
        et=pg.evaluate("()=>window.__et")
        check(f'{nome}: foto identificada (sem leitura de comprovante) e resposta curta', 'Identifiquei' in r and 'Zuntra' in r and 'comprovante' not in r.lower() and '⟦' not in r and not any(t in r for t in TEC), r[:300])
        if nome=='celular': check(f'{nome}: etapas reais e amigáveis durante o processamento (a 1ª pesquisa demora)', any(x in et for x in ['Analisando a imagem…','Identificando o produto…','Pesquisando produtos…','Comparando resultados…']) and not any(t in ' '.join(et) for t in TEC), et)
        k=pg.evaluate("""()=>{const v=[...document.querySelectorAll('.chat-scroll .ma-bv')].pop();return {chips:[...v.querySelectorAll('.ma-bv-id span')].map(x=>x.textContent),
          itens:[...v.querySelectorAll('.ma-bvc')].map(a=>({cr:a.querySelector('.cr').textContent,n:a.querySelector('.n').textContent,p:a.querySelector('.p').textContent,e:a.querySelector('.e').textContent,href:a.querySelector('a').getAttribute('href'),tgt:a.querySelector('a').target,rel:a.querySelector('a').rel,img:(a.querySelector('img')||{}).naturalWidth||0}))}}""")
        it=k['itens']
        check(f'{nome}: card com o que foi identificado (produto, marca, modelo, cor)', all(x in k['chips'] for x in ['Zuntra','Veloz 3','azul']), k['chips'])
        check(f'{nome}: primeiro resultado = mesmo produto, com preço e disponibilidade lidos da loja', it and it[0]['cr']=='Mesmo produto' and 'R$' in it[0]['p'] and '499,90' in it[0]['p'] and 'Em estoque' in it[0]['e'] and 'Zuntra Oficial' in it[0]['e'], it[:1])
        check(f'{nome}: loja que não pôde ser lida aparece com "Preço não verificado" (nada inventado)', any(x['p']=='Preço não verificado' and 'não verificada' in x['e'] for x in it), it)
        check(f'{nome}: link direto para a loja abre fora do app (nova aba, sem repassar a origem)', all(x['href'].startswith(LB) and x['tgt']=='_blank' and 'noopener' in x['rel'] for x in it), it)
        check(f'{nome}: imagem do produto carregada pelo proxy do app', it[0]['img']>0, it[:1])
        ov=pg.evaluate("()=>document.scrollingElement.scrollWidth-innerWidth"); check(f'{nome}: sem rolagem lateral', ov<=1, ov)
        pg.locator('.chat-scroll .ma-bv').last.scroll_into_view_if_needed(); pg.wait_for_timeout(400); pg.screenshot(path=f'/tmp/e2e/busca_visual_{nome}.png')
        # instrução escrita junto da foto
        r=anexa(pg,F1,'procure o mais barato'); pg.wait_for_timeout(1500)
        p1=pg.evaluate("()=>[...[...document.querySelectorAll('.chat-scroll .ma-bv')].pop().querySelectorAll('.ma-bvc .p')].map(x=>x.textContent)")
        check(f'{nome}: "mais barato" junto da foto ordena pelo preço', 'menor para o maior preço' in r and p1 and '429,90' in p1[0], (r[:200], p1))
        if nome=='celular':
            r=anexa(pg,F2); pg.wait_for_timeout(1200)
            cr=pg.evaluate("()=>[...[...document.querySelectorAll('.chat-scroll .ma-bv')].pop().querySelectorAll('.cr')].map(x=>x.textContent)")
            check(f'{nome}: foto sem marca: "parece ser" e resultados marcados como semelhantes', 'parece ser' in r and 'alternativa' in r and cr and all(x=='Semelhante' for x in cr), (r[:250], cr))
            r=anexa(pg,F3); check(f'{nome}: imagem que não é produto: pede descrição, sem resultado inventado', 'Não consegui identificar um produto' in r, r[:200])
            EST['fora']=True
            r=anexa(pg,F4)  # produto ainda não pesquisado (sem cache)
            fora=ultima(pg)
            A.put(f"/api/brain/providers/{[x for x in pv if x['provedor']=='searxng'][0]['id']}",data={'retomar':True})
            check(f'{nome}: pesquisa fora do ar: mensagem honesta, sem resultado e sem detalhe técnico', ('Não consegui concluir a pesquisa agora' in fora or 'Não encontrei' in fora) and not any(t in fora for t in TEC), fora[:250])
            EST['fora']=False
            bt=pg.locator('.chat-scroll .ma-opc button:has-text("Tentar de novo")')
            if bt.count():
                n=pg.locator('.chat-scroll .msg-bubble').count(); bt.last.click(); r=espera_resposta(pg,n); pg.wait_for_timeout(1200)
                check(f'{nome}: "Tentar de novo" refaz a pesquisa sem pedir a foto', 'Identifiquei' in r and 'Termix' in r and 'Garrafa Térmica Termix' in pg.locator('.chat-scroll .ma-bv').last.inner_text(), r[:200])
            else: check(f'{nome}: botão "Tentar de novo" aparece na falha', False)
            # sai do modo: chat normal continua
            pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo=""]',timeout=8000); pg.click('#ma-modos-card [data-modo=""]'); pg.wait_for_timeout(1200)
            r=envia(pg,'qual a capital da França?'); check(f'{nome}: chat normal intacto depois da busca visual', '⟦' not in r and pg.locator('.chat-scroll .ma-bv').count()>=1 and pg.locator('.ma-modos-btn.on').count()==0, r[:200])
        c.close()
    check('sem erros de página', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
loja.shutdown()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); sys.exit(0 if all(res) else 1)
