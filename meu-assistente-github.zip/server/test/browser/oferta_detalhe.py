# Etiqueta OFERTA no detalhe do produto: um pouco mais afastada do canto (14 px no celular, 18 px em telas ≥ 640 px), com o mesmo
# formato, cor, fonte, tamanho e texto; as etiquetas dos cards do catálogo continuam a 6 px; botão de fechar e imagem iguais.
# Servidor: PORT=4326 SQLITE_FILE=/tmp/ma-ofd.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4326'; DBF = '/tmp/ma-ofd.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (600, 400), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
ESTILO = "e=>{const c=getComputedStyle(e);return [c.backgroundColor,c.color,c.fontSize,c.fontWeight,c.fontFamily,c.borderRadius,c.paddingTop,c.paddingLeft,c.letterSpacing,c.boxShadow,e.textContent,Math.round(e.getBoundingClientRect().width),Math.round(e.getBoundingClientRect().height)].join('|')}"
POS = "e=>{const a=e.getBoundingClientRect(),b=e.parentElement.getBoundingClientRect();return [Math.round(a.left-b.left),Math.round(a.top-b.top)]}"
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Olga', 'whatsapp': '+55 85 94444-8001', 'email': 'olga@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Loja da Olga', 'categoria': 'Casa', 'titulo': 'x', 'texto': 'x', 'zap': '5585999990000'}); ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}, 'tema': {'preset': 'padrao', 'cor': '#3b6cff', 'fundo': 'escuro', 'layout': 'grade', 'cantos': 'arredondado'}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Luminária', 'preco': 120, 'categoria': 'Casa', 'fotos': [durl((90, 70, 50))], 'oferta': {'ativo': True, 'preco': 99}}).ok
    PID = R.get(f'/api/v2/ads/{ID}/products').json()['items'][0]['id']
    base = {}
    for nome, vp, mob, esp in [('celular', {'width': 390, 'height': 844}, True, 14), ('celular pequeno', {'width': 320, 'height': 640}, True, 14), ('computador', {'width': 1280, 'height': 900}, False, 18)]:
        X = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pg = X.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(f'/x/empresa/{ID}'); pg.wait_for_selector('[data-prod]', timeout=20000); pg.wait_for_timeout(2600)
        cardtag = pg.locator('.ma-pgrid .ma-phw>.ma-of').first
        check(f'{nome}: etiqueta do card do catálogo continua no mesmo lugar (6 px)', cardtag.evaluate(POS) == [6, 6], cardtag.evaluate(POS))
        pg.locator(f'[data-prod="{PID}"]').first.click(); pg.wait_for_selector(f'[data-detalhe="{PID}"]'); pg.wait_for_timeout(500)
        tag = pg.locator('.ma-sheet .ma-phw>.ma-of'); pos = tag.evaluate(POS); est = tag.evaluate(ESTILO)
        check(f'{nome}: etiqueta OFERTA do detalhe mais afastada do canto ({esp} px do topo e da esquerda)', pos == [esp, esp], pos)
        base.setdefault('est', est)
        check(f'{nome}: mesmo formato, cor, fonte, tamanho e texto', est == base['est'] and est.split('|')[10] == 'OFERTA' and est == cardtag.evaluate(ESTILO), (est, cardtag.evaluate(ESTILO)))
        img = pg.locator('.ma-sheet [data-vimg]').bounding_box(); x = pg.locator('.ma-sheet-x').bounding_box(); t = tag.bounding_box()
        check(f'{nome}: imagem (280 px) e botão de fechar iguais, sem encostar na etiqueta', round(img['height']) == 280 and t['x'] + t['width'] < x['x'] and pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'), (img, x, t))
        if nome == 'celular': pg.screenshot(path='/tmp/e2e/oferta_detalhe.png')
        if nome == 'computador': pg.screenshot(path='/tmp/e2e/oferta_detalhe_pc.png')
        X.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
