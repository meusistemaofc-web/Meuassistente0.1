import json, sys, sqlite3, uuid
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Doceria Aurora','categoria':'Doceria','titulo':'Doces','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Brigadeiro gourmet','preco':50,'tipo':'produto','fotos':['data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==']}); assert rp.ok, rp.text()
    pid=R.get(f'/api/v2/ads/{ID}/products').json()['items'][0]['id']
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Doce','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    ids=[]
    for i in range(2):
        o=cc.request.post(f'/api/v2/businesses/{ID}/orders',data={'itens':[{'pid':pid,'qtd':1+i,'escolhas':{}}],'modo':'retirada','pagamento':'dinheiro','telefone':'(11) 96666-5555'}); assert o.ok,o.text(); ids.append(o.json().get('id') or o.json().get('order',{}).get('id'))
    db=sqlite3.connect(DBF); db.execute("UPDATE orders SET status='concluido' WHERE id=(SELECT MIN(id) FROM orders WHERE business_id=?)",(ID,)); db.commit()
    api=R.get(f'/api/v2/businesses/{ID}/bi?periodo=hoje').json()
    check('API devolve vendas reais do período (concluído 50, pendente 100)', api['vendas']['faturamento']==50 and api['vendas']['pendente']==100 and api['pedidos']['total']==2, api['vendas'])
    # conversa com os cartões (token anexado à resposta pelo servidor; aqui semeado na mensagem para testar o desenho)
    o3=cc.request.post(f'/api/v2/businesses/{ID}/orders',data={'itens':[{'pid':pid,'qtd':1,'escolhas':{}}],'modo':'retirada','pagamento':'dinheiro','telefone':'(11) 96666-5555'}); assert o3.ok
    db.execute("UPDATE orders SET created_at='2020-01-05T15:00:00.000Z' WHERE id=(SELECT MAX(id) FROM orders WHERE business_id=?)",(ID,)); db.commit() # pedido aberto há muito tempo: gera alerta com critério
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000)
    if pg.locator('button:has-text("Agora não")').count(): pg.click('button:has-text("Agora não")'); pg.wait_for_timeout(500)
    for t in ['xqz-neg-resumo','xqz-neg-comparar','xqz-neg-analise']:
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
    pg.wait_for_selector('[data-neg]',timeout=20000); pg.wait_for_timeout(2500)
    cards=pg.locator('[data-neg]'); n=cards.count(); check('três cartões de análise desenhados no chat', n==3, n)
    t=pg.inner_text('.chat-scroll')
    check('resumo: período, empresa e indicadores reais', all(x in t for x in ['Doceria Aurora','hoje','Faturamento (vendas pagas)','R$\xa050,00','Pendente','R$\xa0100,00','Cancelado','Pedidos','Agendamentos','Clientes novos','Visitas']), t[:600])
    check('visitas sem fonte aparecem como "sem dado" (não zero)', 'sem dado' in t)
    check('comparativo mostra atual × anterior com variação', 'vs' in t and 'Faturamento (vendas pagas)' in t and ('▲' in t or '—' in t or 'sem dado' in t), t[-500:])
    check('análise traz o critério de cada tendência', 'Critério:' in t, t[-400:])
    check('sem rolagem horizontal da página no celular', pg.evaluate("()=>document.documentElement.scrollWidth<=window.innerWidth+1"))
    pg.screenshot(path='/tmp/e2e/negocio_cartoes.png',full_page=False)
    # dono de outra empresa não vê: cliente (sem empresa) recebe erro no cartão
    pc=cc.new_page(); pc.goto('/'); pc.wait_for_timeout(1500)
    check('API nega a quem não é dono', cc.request.get(f'/api/v2/businesses/{ID}/bi?periodo=hoje').status==404)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    print('FIM OK %d/%d'%(sum(res),len(res)) if all(res) else 'FIM FALHOU')
    b.close()
