# Card "Ative suas notificações" (novo desenho compacto) no chat — iPhone (Safari fora da Tela de Início: sem suporte a push,
# estado "instalar") e computador (Chrome: pedido de permissão real).
#   • card compacto dentro da tela, sem invadir o campo de digitação nem os botões; título/descrição/ícone; nada de
#     instruções fixas no card; "Como ativar?" abre instruções do aparelho (iPhone: Adicionar à Tela de Início, com o passo a
#     passo ilustrado de sempre); "Ativar notificações" inicia o fluxo real (pedido de permissão do navegador; no iPhone sem
#     instalação, mostra como instalar); recusa → "Verificar novamente" + instruções de desbloqueio; "Agora não" e o X
#     dispensam (adiamento de 7 dias que já existia) e o chat segue utilizável; tema claro; sem rolagem lateral; sem erros.
# Servidor: PORT=4372 SQLITE_FILE=/tmp/ma-notif.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import sys, json, time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4372'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
SEM_PUSH = "try{delete window.Notification;delete window.PushManager}catch(e){}"  # como no Safari do iPhone fora da Tela de Início
RECUSA = "window.__pedidos=0;try{Object.defineProperty(Notification,'permission',{get:()=>window.__perm||'default',configurable:true});Notification.requestPermission=function(){window.__pedidos++;window.__perm='denied';return Promise.resolve('denied')}}catch(e){}"
CARD = 'section[aria-labelledby=nx-notif-card-title]'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Notif', 'whatsapp': '+55 85 94444-1372', 'email': 'admin.nt@t.com', **U}).ok
    iphone = {**p.devices['iPhone 13']}; iphone.pop('default_browser_type', None)
    for nome, ctx, script in [('iPhone', iphone, SEM_PUSH), ('computador', {'viewport': {'width': 1280, 'height': 860}}, RECUSA)]:
        print('==', nome); mob = nome == 'iPhone'
        C = b.new_context(base_url=BASE, **ctx); C.add_init_script(script)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Rita Souza', 'whatsapp': '+55 85 95555-13' + ('01' if mob else '02'), 'email': f'rita.{nome}@t.com', **U}, headers={'X-Forwarded-For': '10.7.1.' + ('1' if mob else '2')}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(nome + ': ' + str(e)))
        pg.goto('/'); pg.wait_for_selector(CARD, timeout=20000); pg.wait_for_timeout(2600)
        g = pg.evaluate(f"""()=>{{const c=document.querySelector('{CARD}'),r=c.getBoundingClientRect(),ta=document.querySelector('textarea'),tr=ta?ta.closest('form,div').getBoundingClientRect():null;
          return {{t:c.querySelector('h2').textContent,d:c.querySelector('#nx-notif-card-desc').textContent,h:r.height,l:r.left,rr:r.right,w:innerWidth,bot:r.bottom,comp:tr&&tr.top,lado:document.documentElement.scrollWidth-innerWidth,
          chips:c.querySelectorAll('ul').length,botoes:[...c.querySelectorAll('button')].map(x=>x.textContent.trim()||x.getAttribute('aria-label')),como:!!c.querySelector('#nx-notif-como'),icone:!!c.querySelector('.ma-notif-ic svg'),
          borda:getComputedStyle(c).borderTopColor}}}}""")
        check(f'{nome}: título e nova descrição', g['t'] == 'Ative suas notificações' and g['d'] == 'Receba lembretes e avisos importantes, mesmo quando não estiver com o Meu Assistente aberto.', g)
        check(f'{nome}: botões Ativar notificações, Como ativar?, Agora não e o X de dispensar', g['botoes'] == ['Dispensar o aviso de notificações', 'Ativar notificações', 'Como ativar?', 'Agora não'], g['botoes'])
        check(f'{nome}: ícone de sino em destaque e sem a lista de chips nem instruções fixas', g['icone'] and g['chips'] == 0 and not g['como'], g)
        check(f'{nome}: compacto (≤ {175 if mob else 150} px de altura) e dentro das margens da tela', g['h'] <= (175 if mob else 150) and g['l'] >= 8 and g['rr'] <= g['w'] - 8, g)
        check(f'{nome}: não encosta no campo de digitação e sem rolagem lateral', (g['comp'] is None or g['bot'] < g['comp']) and g['lado'] <= 1, g)
        pg.screenshot(path=f'/tmp/e2e/notif_{nome}.png')
        # Como ativar?
        pg.click(f'{CARD} >> text=Como ativar?'); pg.wait_for_selector('#nx-notif-como')
        tx = pg.inner_text('#nx-notif-como'); exp = pg.get_attribute(f'{CARD} [aria-controls=nx-notif-como]', 'aria-expanded')
        if mob:
            check('iPhone: "Como ativar?" explica Adicionar à Tela de Início, em passos', 'Adicionar à Tela de Início' in tx and 'Compartilhar' in tx and exp == 'true', tx)
            pg.screenshot(path='/tmp/e2e/notif_iphone_como.png')
            pg.click('#nx-notif-como >> text=Ver o passo a passo com imagens'); pg.wait_for_timeout(600)
            guia = pg.locator('text=Instalar o Meu Assistente').count()
            check('iPhone: o passo a passo ilustrado de sempre abre (guia de instalação existente)', guia >= 1, guia)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
            check('iPhone: o guia ilustrado fecha com Esc e volta ao chat', pg.locator('text=Instalar o Meu Assistente').count() == 0)
            pg.click(f'{CARD} >> text=Como ativar?'); pg.wait_for_timeout(200)
            check('iPhone: "Como ativar?" fecha de novo (instruções não ficam fixas)', pg.locator('#nx-notif-como').count() == 0)
            pg.click(f'{CARD} >> text=Ativar notificações'); pg.wait_for_selector('#nx-notif-como')
            check('iPhone sem a Tela de Início: "Ativar notificações" mostra como instalar (não promete o impossível)', 'Adicionar à Tela de Início' in pg.inner_text('#nx-notif-como'))
        else:
            check('computador: "Como ativar?" explica o pedido de permissão do navegador', 'Permitir' in tx and exp == 'true', tx)
            pg.click(f'{CARD} >> text=Como ativar?')
            pg.click(f'{CARD} >> text=Ativar notificações'); pg.wait_for_timeout(1500)
            check('computador: "Ativar notificações" faz o pedido real de permissão ao navegador', pg.evaluate('window.__pedidos') == 1, pg.evaluate('window.__pedidos'))
            bt = [x.inner_text().strip() for x in pg.locator(f'{CARD} button').all()]
            check('computador: recusado → "Verificar novamente" (fluxo de sempre)', 'Verificar novamente' in bt, bt)
            pg.click(f'{CARD} >> text=Como ativar?'); pg.wait_for_selector('#nx-notif-como')
            check('computador: recusado → "Como ativar?" mostra como desbloquear no navegador', 'recusadas' in pg.inner_text('#nx-notif-como'), pg.inner_text('#nx-notif-como'))
        # o chat continua utilizável com o card na tela
        pg.click('textarea'); pg.keyboard.type('teste')
        check(f'{nome}: dá para digitar no chat com o card aberto', pg.input_value('textarea') == 'teste')
        pg.fill('textarea', '')
        # tema claro
        pg.evaluate("document.documentElement.dataset.theme='light'"); pg.wait_for_timeout(200)
        lt = pg.evaluate(f"(()=>{{const c=document.querySelector('{CARD}');return [getComputedStyle(c).backgroundImage!=='none',getComputedStyle(c.querySelector('h2')).color]}})()")
        check(f'{nome}: tema claro aplicado (fundo próprio e texto escuro)', lt[0] and lt[1] != 'rgb(255, 255, 255)', lt)
        pg.evaluate("document.documentElement.dataset.theme='dark'")
        # dispensar
        if mob: pg.click(f'{CARD} >> text=Agora não')
        else: pg.click(f'{CARD} [aria-label="Dispensar o aviso de notificações"]')
        pg.wait_for_timeout(400)
        st = pg.evaluate("JSON.parse(localStorage.getItem('nx-notif-card')||'{}')")
        ate = list(st.values())[0]['until'] if st else 0
        check(f'{nome}: {"Agora não" if mob else "o X"} dispensa e adia por 7 dias (lógica existente)', pg.locator(CARD).count() == 0 and 6.9 < (ate / 1000 - time.time()) / 86400 < 7.1, st)
        pg.reload(); pg.wait_for_timeout(3500)
        check(f'{nome}: dispensado continua oculto ao recarregar', pg.locator(CARD).count() == 0)
        C.close()
    # outros tamanhos: Android, iPad e iPhone pequeno — card dentro da tela, ações sem estourar, chat livre
    for i, (nome, dev) in enumerate([('Android', 'Galaxy S9+'), ('iPad', 'iPad (gen 7)'), ('iPhone SE', 'iPhone SE')]):
        d = {**p.devices[dev]}; d.pop('default_browser_type', None)
        C = b.new_context(base_url=BASE, **d)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Rita Souza', 'whatsapp': f'+55 85 95555-140{i}', 'email': f'rita.t{i}@t.com', **U}, headers={'X-Forwarded-For': f'10.7.2.{i}'}).ok
        pg = C.new_page(); pg.goto('/'); pg.wait_for_selector(CARD, timeout=20000); pg.wait_for_timeout(1500)
        r = pg.evaluate('''(s)=>{const c=document.querySelector(s).getBoundingClientRect();const bs=[...document.querySelectorAll(s+' .ma-notif-acts button')].map(b=>b.getBoundingClientRect());const ta=document.querySelector('textarea')?.getBoundingClientRect();
          return {w:innerWidth,h:Math.round(c.height),dentro:c.left>=0&&c.right<=innerWidth+.5,linhas:new Set(bs.map(x=>Math.round(x.top))).size,fora:bs.filter(x=>x.right>c.right+.5||x.left<c.left-.5).length,livre:!ta||ta.top>=c.bottom}}''', CARD)
        check(f'{nome}: card compacto dentro da tela, botões numa linha, sem cobrir o campo de mensagem', r['dentro'] and r['fora'] == 0 and r['linhas'] == 1 and r['h'] <= 190 and r['livre'], r)
        pg.screenshot(path=f'/tmp/e2e/notif_{nome.replace(" ", "_")}.png'); C.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and not e.endswith(': Event')], errs[:4])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
