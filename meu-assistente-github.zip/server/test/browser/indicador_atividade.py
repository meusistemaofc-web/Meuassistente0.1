# Indicador de atividade do chat: um só, compacto (três pontinhos azuis + texto da etapa real), sem card.
# Amostra a tela a cada 100 ms durante pedidos reais e confere:
# • conversa rápida: sem card, indicador some com a resposta;
# • pedido em etapas (IA → ferramenta de consulta → IA organiza): o texto acompanha a etapa real
#   ("Consultando ferramentas…" → "Organizando informações…"), na ordem, sem piscar (cada texto ≥ 0,6 s);
# • pedido que executa uma ação: "Executando tarefa…";
# • tarefa longa: nunca aparece "Processando seu pedido…" nem card; texto genérico "Pensando…";
# • recarregar no meio da tarefa: a tarefa acompanhada de fora usa o MESMO indicador compacto (sem card) e o resultado
#   aparece ao terminar;
# • erro: indicador some e o erro aparece;
# • nunca dois indicadores ao mesmo tempo; sem fundo, borda ou sombra; pontinhos azuis; logo abaixo da mensagem enviada;
#   sem rolagem lateral; sem erros de JavaScript. Celular (390 px) e computador.
# Servidor: PORT=4346 SQLITE_FILE=/tmp/ma-ind.db npx tsx test/serve-sqlite.ts (banco novo)
import re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4346'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
AMOSTRA = """()=>{const vis=e=>{if(!e)return false;const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden'};
 const st=document.querySelector('.chat-scroll [role="status"][aria-label="Preparando a resposta"]'),stv=vis(st);
 const solos=[...document.querySelectorAll('#ma-tarefas .ma-tf-ind')].filter(vis);
 const cards=[...document.querySelectorAll('[data-processando],#ma-tarefas .ma-tf:not(.ma-tf-ind)')].filter(vis);
 const sc=document.querySelector('.chat-scroll');
 let estilo=null;if(stv){const c=getComputedStyle(st),d=st.querySelector('.typing span'),users=[...document.querySelectorAll('.chat-scroll .bubble-user')],ul=users[users.length-1],r=st.getBoundingClientRect();
  estilo={bg:c.backgroundColor,borda:c.borderTopWidth,sombra:c.boxShadow,filtro:c.backdropFilter||c.webkitBackdropFilter||'none',ponto:d?getComputedStyle(d).backgroundColor:'',pontos:st.querySelectorAll('.typing span').length,
   abaixo:ul?r.top>=ul.getBoundingClientRect().bottom-1:true,esquerda:(()=>{const ab=[...document.querySelectorAll('.chat-scroll .msg-bubble:not(.bubble-user)')].pop();return ab?Math.round(Math.abs(r.left-ab.getBoundingClientRect().left)):0})(),altura:Math.round(r.height),texto:(st.querySelector('.ma-ind-t')||{}).textContent||'',reactTexto:[...st.children].filter(e=>e.tagName==='SPAN'&&!e.classList.contains('ma-ind-t')).filter(vis).length}}
 return {t:stv?(st.querySelector('.ma-ind-t')||{}).textContent||'':(solos[0]?(solos[0].querySelector('.ma-ind-t')||{}).textContent:''),n:(stv?1:0)+solos.length,cards:cards.length,proc:/Processando seu pedido|Pode sair do chat/.test(sc?sc.innerText:''),estilo,solo:solos.length,
  sw:document.documentElement.scrollWidth,vw:innerWidth}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, device_scale_factor=2 if mob else 1); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Iara Teste', 'whatsapp': f'+55 11 97777-{k}{k}{k}{k}', 'email': f'iara{k}.ind@t.com', **U}, headers={'X-Forwarded-For': f'10.9.6.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        def abrir(url='/'):
            pg.goto(url); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(900)
            if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        def enviar(t): pg.fill('textarea.composer-input', t); pg.keyboard.press('Enter')
        def acompanhar(fim_re, max_s=20, foto=None):
            seq, amostras, t0 = [], [], pg.evaluate('Date.now()')
            for i in range(int(max_s * 10)):
                a = pg.evaluate(AMOSTRA); a['ms'] = pg.evaluate('Date.now()') - t0; amostras.append(a)
                if a['t'] and (not seq or seq[-1][0] != a['t']): seq.append([a['t'], a['ms']])
                if foto and a['estilo'] and foto not in fotos: pg.screenshot(path=f'/tmp/e2e/indicador_{nome}.png'); fotos.add(foto)
                if i > 5 and a['n'] == 0 and re.search(fim_re, pg.inner_text('.chat-scroll')): break
                pg.wait_for_timeout(100)
            return seq, amostras
        fotos = set()
        abrir()
        # 1) conversa rápida
        enviar('Olá, tudo bem?'); seq, am = acompanhar(r'Como posso ajudar', 10)
        check(f'{nome}: conversa rápida — sem card, sem "Processando", indicador some com a resposta', not any(a['cards'] or a['proc'] for a in am) and am[-1]['n'] == 0, seq)
        # 2) pedido em etapas reais: consulta (ferramenta) → organiza → responde
        enviar('xqz-etapas-leitura por favor'); seq, am = acompanhar(r'agenda de hoje está livre', 20, foto='etapas')
        textos = [x[0] for x in seq]
        check(f'{nome}: o texto acompanha as etapas reais, na ordem', 'Consultando ferramentas…' in textos and 'Organizando informações…' in textos and textos.index('Consultando ferramentas…') < textos.index('Organizando informações…') and textos[0] in ('Analisando sua mensagem…', 'Pensando…', 'Consultando o Cérebro Central…'), seq)
        dur = [seq[i + 1][1] - seq[i][1] for i in range(len(seq) - 1)]
        check(f'{nome}: sem piscar (cada texto fica ≥ 0,6 s)', all(d >= 600 for d in dur), seq)
        com = [a for a in am if a['estilo']]
        e0 = com[len(com) // 2]['estilo'] if com else {}
        check(f'{nome}: um único indicador o tempo todo, sem card', all(a['n'] <= 1 and not a['cards'] and not a['proc'] for a in am) and len(com) > 10, [a for a in am if a['n'] > 1 or a['cards']][:2])
        check(f'{nome}: sem fundo, borda, sombra ou desfoque; três pontinhos azuis; só o texto da etapa', e0 and e0['bg'] in ('rgba(0, 0, 0, 0)', 'transparent') and e0['borda'] in ('0px', '') and e0['sombra'] == 'none' and e0['filtro'] == 'none' and e0['pontos'] == 3 and (lambda m: m and int(m[2]) > int(m[0]) + 60)(re.findall(r'\d+', e0['ponto'])) and e0['reactTexto'] == 0, e0)
        check(f'{nome}: logo abaixo da mensagem enviada, alinhado com as respostas do assistente, compacto', e0 and e0['abaixo'] and e0['esquerda'] <= 8 and e0['altura'] <= 40, e0)
        check(f'{nome}: resposta exibida e indicador removido', am[-1]['n'] == 0 and 'agenda de hoje está livre' in pg.inner_text('.chat-scroll'))
        # 3) ação executada
        enviar('xqz-etapas-grava por favor'); seq, am = acompanhar(r'criei a tarefa', 20)
        check(f'{nome}: ação: "Executando tarefa…"', 'Executando tarefa…' in [x[0] for x in seq] and am[-1]['n'] == 0, seq)
        # 4) tarefa longa: genérico "Pensando…", nunca card
        enviar('xqz-tarefa-media pesquise fornecedores'); seq, am = acompanhar(r'encontrei 3 fornecedores', 15)
        check(f'{nome}: tarefa longa sem card nem "Processando seu pedido…"', not any(a['cards'] or a['proc'] for a in am) and 'Pensando…' in [x[0] for x in seq] and am[-1]['n'] == 0, seq)
        # 5) recarregou no meio: a tarefa acompanhada de fora usa o mesmo indicador compacto
        enviar('xqz-tarefa-lenta pesquise preços de grãos'); pg.wait_for_timeout(1500); pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000)
        vista = None
        for i in range(60):
            a = pg.evaluate(AMOSTRA)
            if a['solo']: vista = a; break
            pg.wait_for_timeout(100)
        sol = pg.evaluate("()=>{const e=document.querySelector('#ma-tarefas .ma-tf-ind');if(!e)return null;const c=getComputedStyle(e.firstElementChild),d=e.querySelector('.ma-ind-d i');return {bg:c.backgroundColor,sombra:c.boxShadow,texto:e.innerText,ponto:d?getComputedStyle(d).backgroundColor:''}}")
        check(f'{nome}: ao voltar, indicador compacto com a etapa real (sem card)', vista and vista['n'] == 1 and not vista['cards'] and sol and sol['bg'] in ('rgba(0, 0, 0, 0)', 'transparent') and sol['sombra'] == 'none' and sol['texto'] in ('Pensando…', 'Consultando o Cérebro Central…', 'Analisando sua mensagem…'), (vista, sol))
        ok = False
        for i in range(160):
            if 'encontrei 3 fornecedores' in pg.inner_text('.chat-scroll') and pg.evaluate(AMOSTRA)['n'] == 0: ok = True; break
            pg.wait_for_timeout(100)
        check(f'{nome}: terminou: resultado aparece e o indicador some', ok)
        # 6) erro
        abrir(); enviar(f'xqz-tarefa-falha agora {nome}'); seq, am = acompanhar(r'Não consegui|não consegui|Tente de novo|tente novamente|erro', 20)
        check(f'{nome}: erro: indicador some e o erro aparece', am[-1]['n'] == 0 and re.search(r'Não consegui|não consegui|Tente|erro', pg.inner_text('.chat-scroll')), pg.inner_text('.chat-scroll')[-200:])
        check(f'{nome}: sem rolagem lateral', all(a['sw'] <= a['vw'] + 1 for a in am))
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
