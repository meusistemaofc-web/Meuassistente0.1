# Auditoria do MICROFONE do chat (ditado): captura → gravação → envio → transcrição → texto no campo → envio ao chat.
# Pela tela real do chat, no Chromium com microfone simulado (arquivo de áudio injetado no getUserMedia) e um Whisper falso
# que ABRE o áudio recebido com o ffmpeg (duração e volume reais): assim o teste prova que o áudio não chega vazio, cortado
# ou num formato que o servidor não consegue ler.
#
# Condições de aparelho reproduzidas no Chromium:
#  • iPhone: user agent do iOS + regra do WebKit para o AudioContext (só começa a rodar se for criado/retomado DENTRO do toque;
#    fora dele fica "suspended" e o medidor de volume lê silêncio) + reconhecimento de fala do aparelho que inicia mas não
#    devolve nada (como no app instalado na tela de início);
#  • Android: reconhecimento de fala que aborta ao iniciar (outro reconhecimento ainda ativo / serviço indisponível);
#  • microfone que é desligado no meio da gravação (permissão revogada, ligação, outro app pegou o microfone);
#  • microfone que entrega silêncio total; servidor de transcrição fora do ar.
#
# Servidor: WHISPER_URL=http://127.0.0.1:4399 PORT=4339 SQLITE_FILE=/tmp/ma-mic.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
import sys, re, json, math, struct, wave, threading, subprocess, tempfile, os, random
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
BASE = os.environ.get('BASE', 'http://localhost:4339'); WPORT = int(os.environ.get('WPORT', '4399')); res = []
LOG = os.environ.get('SRV_LOG', '/tmp/srv-mic.log')
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}

# ---------- Whisper falso que analisa o áudio de verdade ----------
REC = []  # cada transcrição: {'mime','nome','bytes','dur','max_db'}
ESTADO = {'status': 200}
def analisar(dados: bytes, nome: str):
    with tempfile.NamedTemporaryFile(suffix='.' + (nome.rsplit('.', 1)[-1] if '.' in nome else 'bin'), delete=False) as f: f.write(dados); p = f.name
    try:
        r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', p, '-af', 'volumedetect', '-f', 'null', '-'], capture_output=True, text=True, timeout=30)
        dur = re.findall(r'time=(\d+):(\d+):([\d.]+)', r.stderr)
        d = (int(dur[-1][0]) * 3600 + int(dur[-1][1]) * 60 + float(dur[-1][2])) if dur else 0.0
        mx = re.search(r'max_volume: (-?[\d.]+|-inf) dB', r.stderr)
        return d, (float(mx.group(1)) if mx and mx.group(1) != '-inf' else -999.0), r.returncode == 0
    finally: os.unlink(p)
class W(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); body = self.rfile.read(n)
        if not self.path.startswith('/v1/audio/transcriptions'): self.send_response(404); self.end_headers(); return
        bnd = self.headers.get('Content-Type', '').split('boundary=')[-1].strip('"').encode()
        arq, nome, mime = b'', '', ''
        for parte in body.split(b'--' + bnd):
            if b'name="file"' in parte:
                cab, _, corpo = parte.partition(b'\r\n\r\n'); arq = corpo[:-2]
                nome = (re.search(rb'filename="([^"]*)"', cab) or [b'', b''])[1].decode(); mime = (re.search(rb'Content-Type: ([^\r\n]+)', cab) or [b'', b''])[1].decode()
        dur, mx, ok = analisar(arq, nome)
        REC.append({'mime': mime, 'nome': nome, 'bytes': len(arq), 'dur': round(dur, 2), 'max_db': mx, 'decodificou': ok})
        if ESTADO['status'] != 200:
            self.send_response(ESTADO['status']); self.end_headers(); self.wfile.write(b'{"error":"falha simulada"}'); return
        texto = f'fala de {round(dur)} segundos' if ok and dur > 0.4 and mx > -45 else ''  # só "ouve" fala se o áudio tem som de verdade
        b = json.dumps({'text': texto}).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)
srv = HTTPServer(('127.0.0.1', WPORT), W); threading.Thread(target=srv.serve_forever, daemon=True).start()

# ---------- áudio do microfone simulado ----------
def wav(caminho, segundos, amp):
    random.seed(7)
    with wave.open(caminho, 'w') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); fr = []
        for i in range(16000 * segundos):
            t = i / 16000; env = 0.55 + 0.45 * math.sin(2 * math.pi * 3 * t)  # sílabas (modulação de 3 Hz)
            s = amp * env * (math.sin(2 * math.pi * 180 * t) + 0.5 * math.sin(2 * math.pi * 360 * t) + 0.25 * math.sin(2 * math.pi * 720 * t)) / 1.75
            fr.append(struct.pack('<h', int(max(-32767, min(32767, s)))))
        w.writeframes(b''.join(fr))
FALA, MUDO = '/tmp/mic_fala.wav', '/tmp/mic_mudo.wav'
wav(FALA, 20, 12000); wav(MUDO, 5, 0)
ARGS = lambda f: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', f'--use-file-for-fake-audio-capture={f}']

UA_IOS = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1'
UA_AND = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36'
# Regra do WebKit: AudioContext criado ou retomado fora de um toque fica "suspended" (o medidor de volume lê silêncio).
GESTO = r"""(()=>{let g=false;const on=()=>{g=true;setTimeout(()=>{g=false},0)};['pointerdown','pointerup','touchstart','touchend','mousedown','mouseup','click','keydown'].forEach(t=>addEventListener(t,on,true));
 window.__emGesto=()=>g;const AC=window.AudioContext;class P extends AC{constructor(o){super(o);if(!g){this.__preso=true;AC.prototype.suspend.call(this)}}resume(){if(g){this.__preso=false;return AC.prototype.resume.call(this)}return Promise.resolve()}}
 window.AudioContext=P;window.webkitAudioContext=P})()"""
# Reconhecimento do aparelho que inicia (onstart) mas nunca devolve texto — como no iPhone com o app instalado na tela de início.
SR_MUDO = r"""(()=>{class Rec{start(){window.__srInicios=(window.__srInicios||0)+1;this._v=true;setTimeout(()=>this.onstart&&this.onstart(),30)}stop(){if(!this._v)return;this._v=false;setTimeout(()=>this.onend&&this.onend(),20)}abort(){this.stop()}}
 window.SpeechRecognition=undefined;window.webkitSpeechRecognition=Rec})()"""
# Reconhecimento que aborta logo ao iniciar (Android: outro reconhecimento ainda ativo / serviço do Google indisponível).
SR_ABORTA = r"""(()=>{class Rec{start(){window.__srInicios=(window.__srInicios||0)+1;setTimeout(()=>{this.onerror&&this.onerror({error:'aborted'});this.onend&&this.onend()},40)}stop(){}abort(){}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec})()"""
SEM_SR = 'delete window.SpeechRecognition; delete window.webkitSpeechRecognition'
# guarda o stream do microfone para o teste poder "desligar" o microfone no meio da gravação
PEGA = r"""(()=>{const o=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);navigator.mediaDevices.getUserMedia=async c=>{const s=await o(c);window.__streams=(window.__streams||[]).concat(s);return s}})()"""

def abrir(b, nome, k, ua=None, mob=True, scripts=()):
    C = b.new_context(viewport={'width': 390, 'height': 844} if mob else {'width': 1280, 'height': 900}, base_url=BASE, is_mobile=mob, has_touch=mob, permissions=['microphone'], **({'user_agent': ua} if ua else {}))
    for s in scripts: C.add_init_script(s)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': f'Mic {nome}', 'whatsapp': f'+55 11 9{k:04d}-{k:04d}', 'email': f'mic{k}.aud@t.com', **U}, headers={'X-Forwarded-For': f'10.7.{k % 250}.{k % 200 + 1}'}).ok
    pg = C.new_page(); erros = []; pg.on('pageerror', lambda e: erros.append(str(e)))
    tr, chat, diag = [], [], []
    pg.on('request', lambda r: tr.append(r) if r.url.endswith('/api/transcribe') and r.method == 'POST' else None)
    pg.on('request', lambda r: chat.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
    pg.on('request', lambda r: diag.append(((r.post_data_buffer or b'').decode('utf-8', 'replace')) or '{}') if '/api/transcribe/diagnostico' in r.url else None)
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1200)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
    return C, pg, erros, tr, chat, diag
campo = lambda pg: pg.input_value('textarea[data-composer-input]')
mic = lambda pg: pg.locator('button[aria-label="Ditar mensagem"], button[aria-label="Parar ditado"]').first
corpo = lambda pg: N(pg.inner_text('body'))
def esperar_pronto(pg, t=20000):
    try: pg.wait_for_function("()=>document.querySelector('[data-ditado-estado=inativo]')&&document.querySelector('textarea[data-composer-input]').value.length>0", timeout=t); return True
    except Exception: return False

todos_erros = []
with sync_playwright() as p:
    b = p.chromium.launch(args=ARGS(FALA))
    # ---------- 1) iPhone: fala longa (10 s) ----------
    print('== iPhone (Safari): fala de 10 s')
    C, pg, er, tr, chat, diag = abrir(b, 'ios1', 101, UA_IOS, True, [GESTO, SR_MUDO])
    n0 = len(REC); mic(pg).click()
    try: pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); ouvindo = True
    except Exception: ouvindo = False
    check('iPhone: o próprio botão do microfone indica que está ouvindo', ouvindo, corpo(pg)[-200:])
    pg.wait_for_timeout(2500)
    check('iPhone: sem barra separada de gravação ("Ouvindo…", cronômetro, Cancelar) — a transcrição vai direto ao campo', pg.locator('[data-ditado-tempo]').count() == 0 and 'Ouvindo… fale agora' not in corpo(pg) and pg.locator('[role="status"] button:has-text("Cancelar")').count() == 0, corpo(pg)[-200:])
    pg.screenshot(path='/tmp/e2e/mic_ios_gravando.png') if os.path.isdir('/tmp/e2e') else None
    pg.wait_for_timeout(7500)
    ainda = pg.locator('[data-ditado-estado="listening"]').count() == 1
    check('iPhone: com a pessoa falando, a gravação NÃO é cortada aos 8 s ("Não ouvi nada")', ainda and 'Não ouvi nada' not in corpo(pg), corpo(pg)[-200:])
    if ainda: mic(pg).click()
    ok = esperar_pronto(pg)
    r = REC[n0:]
    check('iPhone: o áudio chega ao servidor em trechos (frase a frase) e o texto entra no campo', ok and len(tr) >= 1 and campo(pg).lower().startswith('fala de'), (len(tr), campo(pg), corpo(pg)[-160:]))
    check('iPhone: os trechos têm som e somam a fala inteira (nada vazio, nada cortado)', r and all(x['decodificou'] and x['max_db'] > -30 for x in r) and sum(x['dur'] for x in r) >= 9, r)
    check('iPhone: o reconhecimento do aparelho (que não devolve texto no iPhone) não é usado', not pg.evaluate('window.__srInicios||0'), pg.evaluate('window.__srInicios||0'))
    pg.screenshot(path='/tmp/e2e/mic_ios_pronto.png') if os.path.isdir('/tmp/e2e') else None
    # ---------- 2) iPhone: frase curta ----------
    print('== iPhone: frase curta (1,3 s)')
    pg.fill('textarea[data-composer-input]', ''); pg.locator('[data-ditado-descartar]').click() if pg.locator('[data-ditado-descartar]').count() else None
    n0, t0 = len(REC), len(tr); mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(1300); mic(pg).click()
    ok = esperar_pronto(pg)
    check('iPhone: frase curta ("sim", "ok") é transcrita e não descartada', ok and len(tr) - t0 == 1 and campo(pg).lower().startswith('fala de'), (len(tr) - t0, campo(pg), corpo(pg)[-160:]))
    # ---------- 3) iPhone: enviar durante a gravação ----------
    print('== iPhone: enviar durante a gravação')
    pg.fill('textarea[data-composer-input]', ''); pg.locator('[data-ditado-descartar]').click() if pg.locator('[data-ditado-descartar]').count() else None
    c0 = len(chat); mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(3000)
    check('iPhone: durante a gravação nada é enviado sozinho, e o botão enviar continua disponível', pg.locator('button[aria-label="Enviar"]').is_enabled() and len(chat) == c0)
    pg.locator('button[aria-label="Enviar"]').click()  # enviar DURANTE a captura: transcreve o último trecho, encerra e envia o campo
    try: pg.wait_for_function("()=>[...document.querySelectorAll('.chat-scroll .bubble-user')].some(e=>/fala de/i.test(e.innerText))", timeout=20000); foi = True
    except Exception: foi = False
    pg.wait_for_timeout(1500)
    env = [json.loads(x) for x in chat[c0:] if x.startswith('{')]
    check('iPhone: enviar manda o texto do campo como mensagem de TEXTO (uma só)', foi and len(env) == 1 and env[0].get('text', '').lower().startswith('fala de') and 'audio' not in json.dumps(env[0]), chat[c0:])
    check('iPhone: o assistente responde à mensagem ditada', pg.locator('.chat-scroll .msg-bubble').count() >= 2 and campo(pg) == '', campo(pg))
    todos_erros += er; C.close()

    # ---------- 3b) iPhone sem reconhecimento do aparelho: medidor de volume indisponível (AudioContext suspenso) ----------
    print('== iPhone sem reconhecimento do aparelho: fala de 10 s (transcrição pelo servidor)')
    C, pg, er, tr, chat, diag = abrir(b, 'ios2', 106, UA_IOS, True, [GESTO, SEM_SR])
    n0 = len(REC); mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(10000)
    ainda = pg.locator('[data-ditado-estado="listening"]').count() == 1
    check('iPhone/servidor: a gravação não é descartada aos 8 s por falta do medidor de volume', ainda and 'Não ouvi nada' not in corpo(pg), corpo(pg)[-200:])
    if ainda: mic(pg).click()
    ok = esperar_pronto(pg); r = REC[n0:]
    check('iPhone/servidor: a fala inteira chega ao servidor (em trechos) e volta como texto', ok and r and sum(x['dur'] for x in r) >= 9 and campo(pg).lower().startswith('fala de'), (r, campo(pg)))
    todos_erros += er; C.close()

    # ---------- 4) Android: reconhecimento do aparelho aborta ao iniciar ----------
    print('== Android: reconhecimento do aparelho aborta')
    C, pg, er, tr, chat, diag = abrir(b, 'and', 102, UA_AND, True, [SR_ABORTA])
    n0 = len(REC); mic(pg).click(); pg.wait_for_timeout(1500)
    vivo = pg.locator('[data-ditado-estado="listening"]').count() == 1
    check('Android: se o reconhecimento do aparelho aborta, o app troca para a transcrição do servidor (não some calado)', vivo, corpo(pg)[-220:])
    if vivo:
        pg.wait_for_timeout(2500); mic(pg).click()
    ok = esperar_pronto(pg)
    check('Android: a fala é transcrita e vai para o campo', ok and campo(pg).lower().startswith('fala de'), (campo(pg), corpo(pg)[-160:]))
    todos_erros += er; C.close()

    # ---------- 5) Computador (Chrome) sem reconhecimento do aparelho: formato enviado ----------
    print('== Computador: formato do áudio enviado')
    C, pg, er, tr, chat, diag = abrir(b, 'pc', 103, None, False, [SEM_SR])
    n0 = len(REC); mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(3000); mic(pg).click()
    ok = esperar_pronto(pg); r = REC[n0:]
    check('Computador: transcrição volta ao campo', ok and campo(pg).lower().startswith('fala de'), campo(pg))
    check('Computador: áudio enviado em WAV 16 kHz (aceito por Whisper, Gemini e OpenAI), com som e ~3 s', len(r) == 1 and r[0]['mime'] == 'audio/wav' and r[0]['nome'].endswith('.wav') and r[0]['decodificou'] and 2 <= r[0]['dur'] <= 5 and r[0]['max_db'] > -30, r)
    # ---------- 6) microfone desligado no meio da gravação ----------
    print('== Microfone desligado no meio da gravação')
    C2, pg2, er2, tr2, chat2, diag2 = abrir(b, 'rev', 104, None, True, [SEM_SR, PEGA])
    n0 = len(REC); mic(pg2).click(); pg2.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg2.wait_for_timeout(3000)
    pg2.evaluate("(window.__streams||[]).forEach(s=>s.getAudioTracks().forEach(t=>{t.stop();t.dispatchEvent(new Event('ended'))}))")
    try: pg2.wait_for_function("()=>!document.querySelector('[data-ditado-estado=listening],[data-ditado-estado=transcribing]')&&document.querySelector('textarea[data-composer-input]').value.length>0", timeout=15000); ok = True
    except Exception: ok = False
    preso = pg2.locator('[data-ditado-estado="listening"]').count() == 1
    check('Mic desligado: o app não fica preso em "Ouvindo…" e aproveita o que já foi gravado', not preso and ok and campo(pg2).lower().startswith('fala de'), (preso, campo(pg2), corpo(pg2)[-200:]))
    todos_erros += er2; C2.close()
    # ---------- 7) servidor de transcrição fora do ar ----------
    print('== Transcrição indisponível')
    ESTADO['status'] = 500
    import urllib.request
    pg.fill('textarea[data-composer-input]', 'meu texto'); pg.locator('[data-ditado-descartar]').click() if pg.locator('[data-ditado-descartar]').count() else None
    pg.fill('textarea[data-composer-input]', 'meu texto')
    d0 = len(diag); mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(2000); mic(pg).click(); pg.wait_for_timeout(6000)
    ESTADO['status'] = 200
    check('Falha da IA: mensagem compreensível, campo intacto, nada enviado', 'Não consegui transcrever o áudio agora' in corpo(pg) and campo(pg) == 'meu texto', (campo(pg), corpo(pg)[-200:]))
    pg.wait_for_timeout(500)
    try: log_cli = [l for l in open(LOG, encoding='utf-8', errors='replace').read().splitlines() if l.startswith('[ditado:cliente]')]
    except Exception: log_cli = []
    check('Falha da IA: o app registra o erro técnico no servidor (sem o áudio)', len(diag) > d0 and any('evento=transcricao_recusada' in l and 'status=503' in l for l in log_cli) and all(len(x) < 2000 and 'audio' not in json.loads(x) for x in diag[d0:]), (diag[d0:], log_cli[-3:]))
    pg.screenshot(path='/tmp/e2e/mic_falha.png') if os.path.isdir('/tmp/e2e') else None
    todos_erros += er; C.close()
    b.close()

    # ---------- 8) microfone que entrega silêncio total ----------
    print('== Microfone mudo (silêncio total)')
    b3 = p.chromium.launch(args=ARGS(MUDO))
    C, pg, er, tr, chat, diag = abrir(b3, 'mudo', 105, None, True, [SEM_SR])
    pg.fill('textarea[data-composer-input]', 'antes')
    mic(pg).click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=8000); pg.wait_for_timeout(2500)
    if pg.locator('[data-ditado-estado="listening"]').count(): mic(pg).click()
    pg.wait_for_timeout(4000)
    t = corpo(pg)
    check('Mic mudo: avisa que não captou som, sem inventar texto nem mexer no campo', ('Não ouvi nada' in t or 'não captou som' in t or 'Não reconheci nenhuma fala' in t) and campo(pg) == 'antes', (campo(pg), t[-200:]))
    todos_erros += er; C.close(); b3.close()

    # ---------- 9) registro no servidor ----------
    print('== Registro técnico no servidor')
    try: log = open(LOG, encoding='utf-8', errors='replace').read()
    except Exception: log = ''
    linhas = [l for l in log.splitlines() if l.startswith('[ditado')]
    check('Servidor registra cada transcrição (formato, tamanho, duração, resultado)', any('resultado=ok' in l and 'bytes=' in l and 'mime=' in l for l in linhas), linhas[-5:])
    check('Servidor registra as falhas vindas do aparelho', any(l.startswith('[ditado:cliente]') for l in linhas), linhas[-5:])
    check('O registro não guarda o texto falado', not any('fala de' in l for l in linhas), [l for l in linhas if 'fala de' in l][:2])
bad = [e for e in todos_erros if '#418' not in e and e != 'Event']
check('sem erros de JavaScript', not bad, bad[:3])
srv.shutdown()
print('\nÁudios recebidos pelo Whisper falso:', json.dumps(REC, ensure_ascii=False))
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
