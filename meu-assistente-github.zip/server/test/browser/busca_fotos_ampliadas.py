# Busca do chat: fotos ampliadas na própria conversa. Tocar a foto do card abre a camada escura sobre o chat (sem navegar,
# sem abrir produto ou catálogo), com botão Fechar, galeria (setas, deslizar, miniaturas, teclado), zoom (toque duplo,
# pinça, roda do mouse) e arrastar com zoom; foto original sem corte (proporção e resolução preservadas); fechar devolve a
# conversa à mesma posição e o foco à foto; Comprar e Catálogo continuam com os mesmos links; celular, tablet e computador.
# Servidor: PORT=4351 SQLITE_FILE=/tmp/ma-fotos.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, base64, io
from PIL import Image
from playwright.sync_api import sync_playwright
BASE='http://localhost:4351'; DBF='/tmp/ma-fotos.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def png(w,h,cor):
    im=Image.new('RGB',(w,h),cor); [im.putpixel((x,h//2),(255,255,255)) for x in range(0,w,3)]
    bf=io.BytesIO(); im.save(bf,'PNG'); return 'data:image/png;base64,'+base64.b64encode(bf.getvalue()).decode()
F1,F2,F3=png(1200,800,(200,40,40)),png(600,1000,(40,160,60)),png(900,900,(40,70,200))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Dono Doceria','whatsapp':'+55 11 93330-1111','email':'dono@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    r=O.post('/api/v2/ads',data={'planId':'n4','empresa':'Doceria Mel','categoria':'Doces','titulo':'Doceria Mel','texto':'Feito com carinho','zap':'5511999990000','lat':-23.552,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); db.commit(); db.close()
    assert O.put(f'/api/v2/ads/{BID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'dinheiro':True},'entrega':{'retirada':True}}).ok
    IT={}
    for it in [{'nome':'Bolo de chocolate','categoria':'Bolos','fotos':[F1,F2],'variantes':[{'tamanho':'P','preco':45,'fotos':[]},{'tamanho':'G','preco':60,'fotos':[F3]}]},{'nome':'Bolo de cenoura','preco':39,'categoria':'Bolos','fotos':[F2]}]:
        r=O.post(f'/api/v2/ads/{BID}/products',data=it); assert r.ok, r.text(); IT[it['nome']]=[x for x in r.json()['items'] if x['nome']==it['nome']][0]['id']
    # servidor: a galeria vem com as 3 fotos, servidas na resolução original
    for n,(w,h) in enumerate([(1200,800),(600,1000),(900,900)]):
        rr=A.get(f"/api/v2/vitrine/imagem/item/{IT['Bolo de chocolate']}"+(f'?n={n}' if n else ''))
        im=Image.open(io.BytesIO(rr.body())); check(f'servidor: foto {n+1} da galeria na resolução original ({w}×{h})', rr.ok and im.size==(w,h), (rr.status,im.size if rr.ok else None))
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('tablet',{'width':820,'height':1180},True),('computador',{'width':1280,'height':860},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1,geolocation={'latitude':-23.55,'longitude':-46.63},permissions=['geolocation']); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 96666-'+{'celular':'1111','tablet':'3333','computador':'2222'}[nome],'email':nome+'@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
        assert R.put('/api/v2/me/location',data={'lat':-23.55,'lng':-46.63}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(800)
        for t in ['oi, tudo bem?','me conta uma curiosidade sobre bolos','quero encontrar bolo']:
            pg.fill('textarea.composer-input',t); pg.keyboard.press('Enter'); pg.wait_for_timeout(3000)
        pg.wait_for_selector('.chat-scroll .ma-bpc [data-bp-zoom]',timeout=15000); pg.wait_for_timeout(800)
        card=pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de chocolate').first; z=card.locator('[data-bp-zoom]')
        hc=card.locator('a',has_text='Comprar').get_attribute('href'); hk=card.locator('a',has_text='Catálogo').get_attribute('href')
        check(f'{nome}: foto do card é um botão de ampliar, com contador de fotos', z.count()==1 and 'Ampliar foto' in (z.get_attribute('aria-label') or '') and z.locator('.fn').inner_text()=='3')
        # rola a conversa até um ponto conhecido e abre
        sc=pg.evaluate("()=>{const s=document.querySelector('.chat-scroll');s.scrollTop=Math.max(0,s.scrollHeight-s.clientHeight-40);return s.scrollTop}")
        z.scroll_into_view_if_needed(); sc=pg.evaluate("()=>document.querySelector('.chat-scroll').scrollTop"); url0=pg.url
        if mob: z.tap()
        else: z.click()
        pg.wait_for_selector('.ma-lb.on',timeout=5000); pg.wait_for_function("()=>document.querySelector('.ma-lb-st img.ok')",timeout=8000); pg.wait_for_timeout(300)
        g=pg.evaluate("""()=>{const l=document.querySelector('.ma-lb'),im=l.querySelector('.ma-lb-st img'),r=im.getBoundingClientRect(),x=l.querySelector('.ma-lb-x').getBoundingClientRect(),cs=getComputedStyle(l);
          return {bg:cs.backgroundColor,pos:cs.position,full:l.getBoundingClientRect().width===innerWidth&&l.getBoundingClientRect().height===innerHeight,nw:im.naturalWidth,nh:im.naturalHeight,w:r.width,h:r.height,cx:r.left+r.width/2,vw:innerWidth,
          xw:x.width,xh:x.height,xin:x.top>=0&&x.right<=innerWidth,cnt:l.querySelector('.ma-lb-c').textContent,th:l.querySelectorAll('.ma-lb-th button').length,modal:l.getAttribute('aria-modal'),foco:document.activeElement===l.querySelector('.ma-lb-x'),fit:getComputedStyle(im).objectFit}}""")
        check(f'{nome}: abre sobre o chat, sem sair da página (mesmo endereço)', pg.url==url0 and g['pos']=='fixed' and g['full'] and g['modal']=='true' and '/x/' not in pg.url, (pg.url,g))
        check(f'{nome}: fundo escurecido e foto centralizada', g['bg'].startswith('rgba(4, 7, 14') and abs(g['cx']-g['vw']/2)<2, g)
        check(f'{nome}: foto original (1200×800), proporção preservada e sem corte', g['nw']==1200 and g['nh']==800 and abs(g['w']/g['h']-1.5)<0.02 and g['fit']=='contain', g)
        check(f'{nome}: botão Fechar visível, com área de toque de 44 px e foco inicial', g['xw']>=44 and g['xh']>=44 and g['xin'] and g['foco'], g)
        check(f'{nome}: galeria com contador e 3 miniaturas', g['cnt']=='Foto 1 de 3' and g['th']==3, g)
        if mob: pg.locator('.ma-lb-nav.n').tap()
        else: pg.keyboard.press('ArrowRight')
        pg.wait_for_function("()=>document.querySelector('.ma-lb-c').textContent==='Foto 2 de 3'&&document.querySelector('.ma-lb-st img.ok')",timeout=5000)
        check(f'{nome}: foto em pé cabe inteira na área (sem corte em cima/embaixo)', pg.evaluate("()=>{const i=document.querySelector('.ma-lb-st img').getBoundingClientRect(),st=document.querySelector('.ma-lb-st').getBoundingClientRect();return i.top>=st.top-1&&i.bottom<=st.bottom+1&&i.left>=st.left-1&&i.right<=st.right+1}"))
        check(f'{nome}: próxima foto ({"seta" if mob else "teclado"}) mostra a foto em pé sem distorção', pg.evaluate("()=>{const i=document.querySelector('.ma-lb-st img'),r=i.getBoundingClientRect();return i.naturalWidth===600&&Math.abs(r.width/r.height-0.6)<0.02}"))
        pg.locator('.ma-lb-th button').nth(2).click(); pg.wait_for_timeout(400)
        check(f'{nome}: miniatura leva à foto 3', pg.inner_text('.ma-lb-c')=='Foto 3 de 3')
        # deslizar para a direita volta para a 2 (para a esquerda avançaria)
        st=pg.locator('.ma-lb-st').bounding_box(); y=st['y']+st['height']/2
        pg.mouse.move(st['x']+st['width']*0.25,y); pg.mouse.down(); pg.mouse.move(st['x']+st['width']*0.75,y,steps=8); pg.mouse.up(); pg.wait_for_timeout(400)
        check(f'{nome}: deslizar para o lado troca de foto', pg.inner_text('.ma-lb-c')=='Foto 2 de 3', pg.inner_text('.ma-lb-c'))
        # zoom: toque/clique duplo amplia; arrastar move; duplo de novo volta
        ib=pg.locator('.ma-lb-st img').bounding_box(); cx,cy=ib['x']+ib['width']/2,ib['y']+ib['height']/2
        pg.mouse.click(cx,cy); pg.wait_for_timeout(80); pg.mouse.click(cx,cy); pg.wait_for_timeout(450)
        esc=pg.evaluate("()=>{const m=getComputedStyle(document.querySelector('.ma-lb-st img')).transform;return m==='none'?1:+m.split('(')[1].split(',')[0]}")
        check(f'{nome}: toque duplo amplia a foto (2,5×)', abs(esc-2.5)<0.05, esc)
        t0=pg.evaluate("()=>getComputedStyle(document.querySelector('.ma-lb-st img')).transform")
        pg.mouse.move(cx,cy); pg.mouse.down(); pg.mouse.move(cx+60,cy+40,steps=6); pg.mouse.up(); pg.wait_for_timeout(200)
        check(f'{nome}: com zoom, arrastar move a foto (sem trocar de foto)', pg.evaluate("()=>getComputedStyle(document.querySelector('.ma-lb-st img')).transform")!=t0 and pg.inner_text('.ma-lb-c')=='Foto 2 de 3')
        ib2=pg.locator('.ma-lb-st').bounding_box(); pg.mouse.click(ib2['x']+ib2['width']/2,ib2['y']+ib2['height']/2); pg.wait_for_timeout(80); pg.mouse.click(ib2['x']+ib2['width']/2,ib2['y']+ib2['height']/2); pg.wait_for_timeout(450)
        check(f'{nome}: toque duplo de novo volta ao tamanho normal', pg.evaluate("()=>{const m=getComputedStyle(document.querySelector('.ma-lb-st img')).transform;return m==='none'||m.startsWith('matrix(1, 0, 0, 1')}"))
        if mob:
            # pinça com dois dedos (CDP: toques reais)
            cdp=c.new_cdp_session(pg); ib=pg.locator('.ma-lb-st img').bounding_box(); cx,cy=ib['x']+ib['width']/2,ib['y']+ib['height']/2
            def tq(tipo,d): cdp.send('Input.dispatchTouchEvent',{'type':tipo,'touchPoints':[] if tipo=='touchEnd' else [{'x':cx-d,'y':cy,'id':1},{'x':cx+d,'y':cy,'id':2}]})
            tq('touchStart',30)
            for d in range(40,121,10): tq('touchMove',d); pg.wait_for_timeout(16)
            tq('touchEnd',0); pg.wait_for_timeout(300)
            esc=pg.evaluate("()=>{const m=getComputedStyle(document.querySelector('.ma-lb-st img')).transform;return m==='none'?1:+m.split('(')[1].split(',')[0]}")
            check(f'{nome}: pinça com dois dedos amplia', esc>2.2, esc)
        else:
            pg.mouse.move(cx,cy); pg.mouse.wheel(0,-400); pg.wait_for_timeout(250)
            esc=pg.evaluate("()=>{const m=getComputedStyle(document.querySelector('.ma-lb-st img')).transform;return m==='none'?1:+m.split('(')[1].split(',')[0]}")
            check(f'{nome}: roda do mouse amplia', esc>1.5, esc)
        pg.screenshot(path=f'/tmp/e2e/fotos_ampliadas_zoom_{nome}.png')
        pg.keyboard.press('Escape') if not mob else pg.locator('.ma-lb-x').tap()
        pg.wait_for_timeout(450)
        fim=pg.evaluate("()=>({lb:!!document.querySelector('.ma-lb'),top:document.querySelector('.chat-scroll').scrollTop,foco:document.activeElement&&document.activeElement.hasAttribute('data-bp-zoom'),ov:document.documentElement.style.overflow})")
        check(f'{nome}: fechar ({"botão" if mob else "Esc"}) volta à mesma posição da conversa e devolve o foco à foto', not fim['lb'] and abs(fim['top']-sc)<2 and fim['foco'] and fim['ov']=='' and pg.url==url0, (sc,fim))
        # card de foto única: sem setas nem miniaturas; tocar fora da foto fecha
        z2=pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de cenoura').first.locator('[data-bp-zoom]'); z2.click(); pg.wait_for_selector('.ma-lb.on'); pg.wait_for_timeout(300)
        check(f'{nome}: foto única sem setas nem miniaturas', pg.locator('.ma-lb-nav:visible').count()==0 and pg.locator('.ma-lb-th').count()==0 and pg.inner_text('.ma-lb-c')=='')
        pg.screenshot(path=f'/tmp/e2e/fotos_ampliadas_{nome}.png')
        stb=pg.locator('.ma-lb-st').bounding_box(); pg.mouse.click(stb['x']+6,stb['y']+6); pg.wait_for_timeout(800)
        check(f'{nome}: tocar fora da foto fecha', pg.locator('.ma-lb').count()==0)
        # Comprar e Catálogo intactos
        check(f'{nome}: Comprar e Catálogo com os mesmos links', hc==f"/x/empresa/{BID}?produto={IT['Bolo de chocolate']}" and hk==f"/x/empresa/{BID}", (hc,hk))
        if nome=='computador':
            card.locator('a',has_text='Catálogo').click(); pg.wait_for_timeout(2500)
            check(f'{nome}: Catálogo abre o catálogo da empresa', f'/x/empresa/{BID}' in pg.url and 'produto=' not in pg.url, pg.url)
            pg.go_back(); pg.wait_for_selector('.chat-scroll .ma-bpc',timeout=15000); pg.wait_for_timeout(800)
            pg.locator('.chat-scroll .ma-bpc',has_text='Bolo de chocolate').first.locator('a',has_text='Comprar').click()
            try: pg.wait_for_function("()=>{const o=document.querySelector('#ma-x');return !!o&&o.innerText.includes('Bolo de chocolate')&&location.pathname.startsWith('/x/empresa/')}",timeout=15000); ok=True
            except Exception: ok=False
            check(f'{nome}: Comprar abre o produto na loja (fluxo de detalhes e compra)', ok, pg.url)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); import sys; sys.exit(0 if all(res) else 1)
