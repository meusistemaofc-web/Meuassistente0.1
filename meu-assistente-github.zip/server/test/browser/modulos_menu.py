# Organizar módulos ⇄ menu lateral: fonte única (settings.menuLayout no banco). Adicionar aparece na hora, subir/descer reflete a
# ordem, remover some, recarregar e novo login mantêm; admin "oculto" respeitado sem divergência; integridade (duplicados/inválidos)
# e gravações simultâneas sem perda; tela antiga /x/modulos usa a mesma fonte. Celular e computador.
import sys, json
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
MAIN_JS="""()=>{const nav=document.querySelector('nav.nx-menu');const box=[...nav.querySelectorAll('div.scroll-thin')].find(d=>!d.closest('#nx-menu-projects'));
 return [...box.querySelectorAll('a[href]')].filter(a=>!a.dataset.maX&&a.querySelector('.truncate')&&getComputedStyle(a).display!=='none'&&a.getBoundingClientRect().height>0)
  .sort((x,y)=>x.getBoundingClientRect().top-y.getBoundingClientRect().top).map(a=>a.querySelector('.truncate').textContent.trim())}"""
ORG_JS="""()=>{const h=document.getElementById('org-in-menu');const sec=h.closest('section');return {lista:[...sec.querySelectorAll('li')].filter(li=>li.style.display!=='none').map(li=>li.querySelector('span span, span').textContent.trim()),badge:h.querySelector('span').textContent.trim(),
 disp:[...document.getElementById('org-available').closest('section').querySelectorAll('li')].filter(li=>li.style.display!=='none').map(li=>li.querySelector('span').textContent.trim())}}"""
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    for nome,vp,mob,email,zap in [('celular',{'width':390,'height':844},True,'cel@t.com','+55 11 96666-1111'),('computador',{'width':1280,'height':900},False,'pc@t.com','+55 11 96666-2222')]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':'Usuario Teste','whatsapp':zap,'email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
        def abrir_menu():
            if not pg.evaluate("()=>!!document.querySelector('[data-open]')"): pg.click('button[aria-label="Abrir menu"]'); pg.wait_for_timeout(700)
            if pg.locator('#nx-menu-projects').count(): pg.click('[aria-label="Voltar ao menu principal"]'); pg.wait_for_timeout(400)
        def abrir_org():
            abrir_menu(); pg.locator('nav.nx-menu button', has_text='Módulos').first.click(); pg.wait_for_timeout(500)
            pg.get_by_text('Organizar módulos').click(); pg.wait_for_selector('#org-in-menu',timeout=8000); pg.wait_for_timeout(400)
        def fechar_org():
            pg.locator('.nx-app button[aria-label="Fechar"]').last.click(); pg.wait_for_timeout(700); abrir_menu()
        main=lambda: pg.evaluate(MAIN_JS)
        abrir_menu(); m0=main()
        check(f'{nome}: inicialização — menu com a organização padrão', m0==['Meu Dia','Tarefas','Compromissos','Contas'], m0)
        # 1. adicionar
        abrir_org(); o0=pg.evaluate(ORG_JS)
        pg.click('[aria-label="Adicionar Financeiro ao menu"]'); pg.wait_for_timeout(1200); o1=pg.evaluate(ORG_JS)
        check(f'{nome}: adicionar Financeiro entra em "No menu"', 'Financeiro' in o1['lista'] and o1['badge']==str(len(o1['lista'])) and 'Financeiro' not in o1['disp'], o1)
        fechar_org(); m1=main()
        check(f'{nome}: 1. Financeiro aparece no menu lateral na hora (sem recarregar), na mesma ordem da tela', m1==o1['lista'], (m1,o1['lista']))
        # 4. ordenar
        abrir_org(); pg.click('[aria-label="Subir Financeiro"]'); pg.wait_for_timeout(700); pg.click('[aria-label="Subir Financeiro"]'); pg.wait_for_timeout(700)
        pg.click('[aria-label="Descer Meu Dia"]'); pg.wait_for_timeout(1200); o2=pg.evaluate(ORG_JS)
        check(f'{nome}: subir/descer muda a ordem na tela', o2['lista']==['Tarefas','Meu Dia','Financeiro','Compromissos','Contas'], o2['lista'])
        fechar_org(); m2=main()
        check(f'{nome}: 4. a ordem do menu lateral é exatamente a da tela', m2==o2['lista'], (m2,o2['lista']))
        # 3. remover
        abrir_org(); pg.click('[aria-label="Remover Contas do menu"]'); pg.wait_for_timeout(1200); o3=pg.evaluate(ORG_JS)
        fechar_org(); m3=main()
        check(f'{nome}: 3. remover Contas → some do menu principal', 'Contas' not in m3 and m3==o3['lista'] and 'Contas' in o3['disp'], (m3,o3))
        pg.locator('nav.nx-menu button', has_text='Módulos').first.click(); pg.wait_for_timeout(500)
        pasta=pg.inner_text('#nx-menu-projects')
        check(f'{nome}: módulo removido continua disponível na pasta "Módulos" (não é apagado)', 'Contas' in pasta, pasta[:200])
        pg.click('[aria-label="Voltar ao menu principal"]'); pg.wait_for_timeout(300)
        # 2. persistência
        L=R.get('/api/me').json()['settings']['menuLayout']
        esperado=['tarefas','meu-dia','financeiro','compromissos']
        check(f'{nome}: 2. salvo no banco, vinculado ao usuário', [x for x in L['main'] if x not in ('eleicoes','projetos','admin','mercado')]==esperado and 'contas' in L['projects'], L)
        # 5. recarregar
        pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500); abrir_menu(); m5=main()
        check(f'{nome}: 5. recarregar a página monta o menu com a configuração salva', m5==m3, (m5,m3))
        # 7. sair e entrar de novo (sessão nova)
        c.close(); c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); R=c.request
        assert R.post('/api/auth',data={'action':'login','email':email,'password':'Cliente@123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500); abrir_menu(); m7=main()
        check(f'{nome}: 7. após novo login, o menu continua igual à última configuração', m7==m3, (m7,m3))
        abrir_org(); o7=pg.evaluate(ORG_JS)
        check(f'{nome}: 6. tela de organização e menu usam a mesma fonte (iguais após novo login)', o7['lista']==m7, (o7['lista'],m7))
        fechar_org()
        if nome=='celular':
            pg.screenshot(path='/tmp/e2e/modulos_menu_celular.png')
            # admin esconde um módulo: some do menu E da tela (sem divergência); volta quando liberado
            A.put('/api/panel/menu_layout',data={'financas':'oculto'})
            pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500); abrir_menu(); mh=main()
            abrir_org(); oh=pg.evaluate(ORG_JS); fechar_org()
            check('admin oculta Financeiro: some do menu e da tela de organização (contagem coerente)', 'Financeiro' not in mh and 'Financeiro' not in oh['lista'] and 'Financeiro' not in oh['disp'] and oh['badge']==str(len(oh['lista'])) and mh==oh['lista'], (mh,oh))
            check('a escolha do usuário é preservada enquanto o admin oculta', 'financeiro' in R.get('/api/me').json()['settings']['menuLayout']['main'])
            A.put('/api/panel/menu_layout',data={})
            pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500); abrir_menu()
            check('admin libera: Financeiro volta na mesma posição escolhida', main()==m3, main())
            # tela antiga /x/modulos usa a mesma fonte
            pg.keyboard.press('Escape'); pg.goto('/x/modulos'); pg.wait_for_selector('[data-pin]',timeout=10000); pg.wait_for_timeout(800)
            rows=pg.evaluate("()=>[...document.querySelectorAll('#ma-x [data-om]')].map(b=>{const r=b.parentElement;return b.querySelector('span').textContent.trim()+'|'+((r.querySelector('[data-pin]')||{}).textContent||'')})")
            check('/x/modulos mostra o estado da mesma fonte (Finanças "Fixado", Contas a pagar "Fixar")', 'Finanças|Fixado' in rows and 'Contas a pagar|Fixar' in rows, rows)
            pg.click('#ma-x [data-pin="lembretes"]'); pg.wait_for_timeout(1500)
            L2=R.get('/api/me').json()['settings']['menuLayout']
            check('"Fixar" em /x/modulos grava no menuLayout (sem lista paralela)', 'lembretes' in L2['main'] and 'lembretes' not in L2['projects'], L2)
            pg.go_back(); pg.wait_for_timeout(800); abrir_menu()
            check('e o menu lateral mostra Lembretes na hora', 'Lembretes' in main(), main())
            # integridade
            r=R.patch('/api/me',data={'settings':{'menuLayout':{'main':['meu-dia','meu-dia','xpto','tarefas','<script>'],'projects':['tarefas','compras','compras',7]}}}).json()['settings']['menuLayout']
            check('8. integridade: sem duplicados nem referências inválidas (servidor limpa)', r=={'main':['meu-dia','tarefas'],'projects':['compras']}, r)
            r=R.patch('/api/me',data={'settings':{'menuLayout':'lixo'}}).json()['settings']['menuLayout']
            check('valor inválido vira organização padrão (nada quebra)', r is None, r)
            # gravações simultâneas não apagam uma à outra
            # gravações simultâneas disparadas pelo navegador (como o app faz ao abrir: fuso horário + organização do menu)
            pg.evaluate("""async()=>{await Promise.all([fetch('/api/me',{method:'PATCH',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{menuLayout:{main:['eleicoes','projetos','financeiro','meu-dia','admin'],projects:['contas']}}})}),
              fetch('/api/me',{method:'PATCH',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{currency:'USD'}})}),fetch('/api/me',{method:'PATCH',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({settings:{timezone:'America/Fortaleza'}})})])}""")
            st=R.get('/api/me').json()['settings']
            check('gravações simultâneas (menu + outras configurações) não se perdem', st['menuLayout']['main'][:3]==['eleicoes','projetos','financeiro'] and st['currency']=='USD', (st['menuLayout'],st['currency']))
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
