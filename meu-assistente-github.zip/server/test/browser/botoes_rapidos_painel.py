# Painel administrativo → Botões do chat (tela real, computador e celular):
# • prévia = o chat de verdade (iframe), com o campo de digitação oficial (fundo, borda, +, microfone, enviar) e os botões
#   logo acima dele; atualiza na hora a cada alteração, antes de salvar;
# • texto, comando, ação pronta, ícone, cor do ícone e do texto (paleta e cor livre), "Destacar em azul", posição (select e
#   setas), ativar/desativar cada botão, mostrar/ocultar a lista, no máximo 3 (adicionar some no limite), remover, restaurar;
# • tocar um botão na prévia mostra o comando e não envia nada; validação ao salvar;
# • salvar aplica na hora: outra aba do chat neste navegador muda sem recarregar e um usuário comum vê no chat novo;
# • celular: prévia compacta (parte de baixo do chat) fixa no topo enquanto edita; sem rolagem lateral; sem erros de JS.
# Servidor: PORT=4342 SQLITE_FILE=/tmp/ma-qbpainel.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4342'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
rgb=lambda c:[int(x) for x in re.findall(r'\d+',c)[:3]]
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE); assert A.request.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1299','email':'admin.qb@t.com',**U}).ok
    assert A.request.put('/api/panel/modules',data={'sugestoes':True,'empresas':True}).ok
    UC=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
    assert UC.request.post('/api/auth',data={'action':'signup','name':'Usuária Comum','whatsapp':'+55 11 98888-1299','email':'user.qb@t.com',**U},headers={'X-Forwarded-For':'10.7.7.7'}).ok
    for nome,vp,mob in [('computador',{'width':1280,'height':1000},False),('celular',{'width':390,'height':844},True)]:
        print('==',nome)
        C=b.new_context(base_url=BASE,viewport=vp,is_mobile=mob,has_touch=mob); C.add_cookies(A.cookies())
        assert C.request.put('/api/panel/quick_buttons',data={'enabled':True,'items':[x for x in C.request.get('/api/panel').json()['quick_buttons_opcoes']['presets'] if x['preset'] in ('lojas','agendar','organizar')]}).ok
        chat=C.new_page(); chat.on('pageerror',lambda e:errs.append(str(e))); chat.goto('/'); chat.wait_for_selector('.ma-qb-item',timeout=20000)
        pg=C.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/admin'); aba(pg,'botoes'); pg.wait_for_selector('.ma-qbp',timeout=15000)
        F=pg.frame_locator('#qb_prev')
        def pv(): # botões na prévia: [texto, cor do ícone, cor do texto, path do ícone]
            try: return pg.frame(url=re.compile(r'qbPreview')).evaluate("()=>[...document.querySelectorAll('.ma-qb-item')].filter(x=>x.offsetParent).map(x=>[x.innerText.trim(),getComputedStyle(x.querySelector('svg')).color,getComputedStyle(x).color,x.querySelector('svg path')?.getAttribute('d')||''])")
            except Exception: return None
        def espera(fn,ms=8000):
            for _ in range(ms//200):
                v=pv()
                try:
                    if v is not None and fn(v): return v
                except Exception: pass
                pg.wait_for_timeout(200)
            return pv()
        v=espera(lambda v:len(v)==3)
        check(f'{nome}: prévia mostra os botões atuais no chat de verdade', v and [x[0] for x in v]==['Lojas','Agendar compromisso','Organizar meu dia'], v)
        geo=pg.frame(url=re.compile(r'qbPreview')).evaluate("()=>{const ta=document.querySelector('textarea.composer-input');let f=ta.parentElement;for(let k=0;k<6&&f.querySelectorAll('button').length<3;k++)f=f.parentElement;const r=f.getBoundingClientRect(),l=document.querySelector('.ma-qb-list').getBoundingClientRect();return {acima:l.bottom<=r.top+1&&r.top-l.bottom<=32,mais:f.querySelectorAll('button').length>=3,bg:getComputedStyle(f).backgroundColor!=='rgba(0, 0, 0, 0)'||getComputedStyle(f.parentElement).backgroundColor!=='rgba(0, 0, 0, 0)',ph:ta.placeholder}}")
        check(f'{nome}: prévia com o campo de digitação oficial (+, microfone, enviar) e os botões logo acima', geo['acima'] and geo['mais'] and 'Como posso ajudar' in geo['ph'], geo)
        if mob:
            box=pg.locator('#qb_frame').bounding_box()
            check('celular: prévia compacta (parte de baixo do chat) no topo', box and box['height']<330 and box['y']<500, box)
        # texto: atualiza a prévia na hora, antes de salvar
        pg.fill('[data-tx="0"]','Lojas da cidade')
        v=espera(lambda v:v and v[0][0]=='Lojas da cidade'); check(f'{nome}: mudar o texto atualiza a prévia na hora', v and v[0][0]=='Lojas da cidade', v)
        check(f'{nome}: aviso de alterações não salvas', pg.locator('#qb_dirty').is_visible())
        if mob:
            pg.locator('[data-ic="1|sino"]').scroll_into_view_if_needed(); pg.wait_for_timeout(300); box=pg.locator('#qb_frame').bounding_box()
            check('celular: prévia continua visível (fixa no topo, abaixo do cabeçalho) enquanto edita mais abaixo', box and 40<=box['y']<=140, box)
            pg.screenshot(path='/tmp/e2e/botoes_painel_celular_editando.png')
        # ícone
        pg.click('[data-ic="1|sino"]'); v=espera(lambda v:'M6 16.5' in v[1][3]); check(f'{nome}: trocar o ícone muda a prévia', v and len(v)==3 and 'M6 16.5' in v[1][3], v)
        # destacar em azul / tirar o destaque
        pg.click('[data-sw="qz1"]'); v=espera(lambda v:rgb(v[1][1])==[22,119,255]); check(f'{nome}: "Destacar em azul" deixa ícone e texto azuis', v and rgb(v[1][1])==[22,119,255] and rgb(v[1][2])==[22,119,255], v)
        pg.click('[data-sw="qz0"]'); v=espera(lambda v:rgb(v[0][2])!=[22,119,255]); check(f'{nome}: tirar o destaque volta ao padrão (ícone cinza, texto branco)', v and rgb(v[0][2])==[255,255,255] and 90<sum(rgb(v[0][1]))/3<190, v)
        # cor pela paleta (ícone) e cor livre (texto)
        pg.click('[data-cor="2|corIcone|#22C55E"]'); v=espera(lambda v:rgb(v[2][1])==[34,197,94]); check(f'{nome}: cor do ícone pela paleta', v and rgb(v[2][1])==[34,197,94], v)
        pg.locator('[data-corlivre="2|corTexto"]').fill('#ff8800'); pg.locator('[data-corlivre="2|corTexto"]').dispatch_event('change')
        v=espera(lambda v:rgb(v[2][2])==[255,136,0]); check(f'{nome}: cor livre do texto', v and rgb(v[2][2])==[255,136,0], v)
        # posição: setas e seletor
        pg.click('[data-mv="2|-1"]'); v=espera(lambda v:v[1][0]=='Organizar meu dia'); check(f'{nome}: subir muda a ordem na prévia', v and [x[0] for x in v]==['Lojas da cidade','Organizar meu dia','Agendar compromisso'], v and [x[0] for x in v])
        pg.select_option('[data-pos="0"]','2'); v=espera(lambda v:v[2][0]=='Lojas da cidade'); check(f'{nome}: escolher a posição pelo seletor', v and [x[0] for x in v]==['Organizar meu dia','Agendar compromisso','Lojas da cidade'], v and [x[0] for x in v])
        # ativar/desativar um botão
        pg.click('[data-sw="qa1"]'); v=espera(lambda v:len(v)==2); check(f'{nome}: desativar um botão tira da prévia', v and [x[0] for x in v]==['Organizar meu dia','Lojas da cidade'], v and [x[0] for x in v])
        pg.click('[data-sw="qa1"]'); espera(lambda v:len(v)==3)
        # limite de 3, remover e adicionar ação pronta
        check(f'{nome}: com 3 botões não dá para adicionar outro', pg.locator('#qb_add').count()==0)
        pg.click('[data-rm="1"]'); pg.wait_for_selector('#qb_add'); pg.select_option('#qb_novo','gasto'); pg.click('#qb_add')
        v=espera(lambda v:len(v)==3 and v[2][0]=='Registrar gasto'); check(f'{nome}: remover e adicionar a ação pronta "Registrar gasto"', v and [x[0] for x in v]==['Organizar meu dia','Lojas da cidade','Registrar gasto'], v and [x[0] for x in v])
        check(f'{nome}: ação pronta preenche texto e comando', pg.input_value('[data-tx="2"]')=='Registrar gasto' and pg.input_value('[data-cm="2"]')=='Registrar gasto')
        # tocar na prévia: mostra o comando e não envia nada
        F.locator('.ma-qb-item',has_text='Lojas da cidade').click(); pg.wait_for_timeout(500)
        check(f'{nome}: tocar na prévia mostra o comando, sem enviar', 'Lojas perto de mim' in pg.inner_text('#qb_out') and F.locator('.chat-scroll .msg-swipe').count()==0, pg.inner_text('#qb_out'))
        # mostrar/ocultar a lista
        pg.click('[data-sw="qb"]'); v=espera(lambda v:len(v)==0); check(f'{nome}: ocultar os botões rápidos esvazia a prévia', v==[], v)
        pg.click('[data-sw="qb"]'); espera(lambda v:len(v)==3)
        # validação
        pg.fill('[data-cm="1"]',''); pg.click('#qsave'); pg.wait_for_timeout(400)
        check(f'{nome}: salvar sem comando mostra o erro', 'Botão 2' in pg.inner_text('#qb_err'), pg.inner_text('#qb_err'))
        pg.fill('[data-cm="1"]','Lojas perto de mim'); pg.click('#qsave')
        pg.wait_for_function("()=>document.getElementById('toast')&&!document.getElementById('toast').hidden&&document.getElementById('toast').textContent.includes('Salvo')",timeout=8000)
        q=C.request.get('/api/panel/public').json()['quick_buttons']
        check(f'{nome}: salvo no servidor (ordem, ícone, cores)', [x['texto'] for x in q['items']]==['Organizar meu dia','Lojas da cidade','Registrar gasto'] and q['items'][0]['corIcone']=='#22C55E' and q['items'][0]['corTexto']=='#FF8800' and q['items'][2]['icone']=='carteira', q)
        check(f'{nome}: depois de salvar some o aviso de alterações', not pg.locator('#qb_dirty').is_visible())
        # aplicado na hora: outra aba do chat neste navegador, sem recarregar
        try: chat.wait_for_function("()=>[...document.querySelectorAll('.ma-qb-item')].map(x=>x.innerText.trim()).join('|')==='Organizar meu dia|Lojas da cidade|Registrar gasto'",timeout=8000); ok=True
        except Exception: ok=False
        check(f'{nome}: o chat aberto em outra aba muda na hora (sem recarregar)', ok, chat.evaluate("()=>[...document.querySelectorAll('.ma-qb-item')].map(x=>x.innerText.trim())"))
        # usuário comum: chat novo já com a configuração
        up=UC.new_page(); up.goto('/'); up.wait_for_selector('.ma-qb-item',timeout=15000); up.wait_for_timeout(600)
        t=[x.strip() for x in up.locator('.ma-qb-item:visible').all_inner_texts()]
        check(f'{nome}: usuário comum vê os botões salvos', t==['Organizar meu dia','Lojas da cidade','Registrar gasto'], t)
        up.locator('.ma-qb-item',has_text='Lojas da cidade').click()
        try: up.wait_for_function("()=>document.querySelector('.chat-scroll').innerText.includes('Empresas perto de você')",timeout=15000); ok=True
        except Exception: ok=False
        check(f'{nome}: no chat do usuário o botão executa o comando real', ok)
        up.close()
        if mob: pg.evaluate("()=>window.scrollTo(0,0)"); pg.screenshot(path='/tmp/e2e/botoes_painel_celular.png')
        else: pg.screenshot(path='/tmp/e2e/botoes_painel_computador.png')
        # restaurar padrão (rascunho) e prévia "Computador"
        pg.click('#qb_reset'); v=espera(lambda v:[x[0] for x in v]==['Lojas','Agendar compromisso','Organizar meu dia'])
        check(f'{nome}: restaurar padrão (Lojas em azul, Agendar, Organizar)', v and [x[0] for x in v]==['Lojas','Agendar compromisso','Organizar meu dia'] and rgb(v[0][2])==[22,119,255], v)
        pg.click('[data-modo="pc"]'); pg.wait_for_timeout(300)
        check(f'{nome}: prévia no tamanho de computador', pg.evaluate("()=>document.getElementById('qb_prev').style.width")=='1280px')
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
