import sys, re
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch()
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        ctx=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); R=ctx.request
        R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}) if mobile else R.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'})
        if mobile:
            R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True})
            ID=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Loja Pct','categoria':'Loja','titulo':'P','texto':'x','zap':'5511999990000'}).json()['items'][0]['id']
            R.post('/api/panel/coins',data={'action':'config','ativo':True})
            c=R.post('/api/panel/coins',data={'action':'create','businessId':ID,'modelo':'dourada','nome':'Moeda Pct','simbolo':'pct','quantidade':200,'valorReferencia':1,'desconto':1,'finalidade':'x'}).json(); CID=c['moeda']['id']
            R.post('/api/panel/coins',data={'action':'status','id':CID,'status':'ativa'})
        pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'MCoins'); pg.wait_for_selector('[data-coin]',timeout=10000); pg.wait_for_timeout(500)
        txt=pg.inner_text('#ma-panel-host') if pg.locator('#ma-panel-host').count() else pg.inner_text('body')
        check(f'{nome}: resumo mostra "Distribuídas" em %', pg.locator('.ma-pct').count()>=2 and re.search(r'\d+(,\d)?\s*%\s*\n?\s*Distribuídas',txt) is not None, txt[:300])
        check(f'{nome}: lista da moeda mostra percentual, não "x/y distribuídas"', re.search(r'\d+/\d+ distribuídas',txt) is None)
        check(f'{nome}: símbolo % em destaque (cor de destaque)', pg.evaluate("()=>{const s=document.querySelector('.ma-pct span');return s&&getComputedStyle(s).fontWeight>=700}"))
        antes=pg.locator('[data-coin] .ma-pct').first.inner_text().strip()
        R.post('/api/panel/coins',data={'action':'distribuir','id':CID if mobile else CID,'email':'admin@t.com','quantidade':50,'idem':f'pct-ui-{nome}-0001'}) if 'CID' in dir() else None
        pg.reload(); pg.wait_for_timeout(1500); aba(pg,'MCoins'); pg.wait_for_selector('[data-coin]',timeout=10000); pg.wait_for_timeout(500)
        depois=pg.locator('[data-coin] .ma-pct').first.inner_text().strip()
        check(f'{nome}: percentual atualiza após distribuir ({antes} → {depois})', antes!=depois)
        pg.locator('[data-cd]').first.click(); pg.wait_for_function("document.body.innerText.includes('Qtd. distribuída (detalhe)')",timeout=8000)
        d=pg.inner_text('body'); check(f'{nome}: detalhe mantém quantidade absoluta e o percentual', 'Qtd. distribuída (detalhe)' in d and 'Total emitido' in d and '%' in d)
        check(f'{nome}: sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
        ctx.close()
    b.close()
ok=sum(res); print(('FIM OK ' if ok==len(res) else 'FIM FALHOU ')+f'{ok}/{len(res)}'); sys.exit(0 if ok==len(res) else 1)
