# Página de apresentação (/conheca), de ponta a ponta:
# • servida como página própria (não o app antigo), com prévia de compartilhamento no endereço oficial e imagem nova;
# • abertura: a frase digitada vira o item do app (ciclo automático) e o seletor "Para sua empresa" troca a demonstração;
# • rotina: abas (clique e setas do teclado), Hoje/Amanhã, barras do financeiro, lista marcável;
# • "Experimente": cada exemplo cria o cartão certo; demonstração identificada como simulada;
# • jornada do pedido: faixas de preço por quantidade, checkout entrega × retirada sem misturar, envio, painel da loja com as
#   ações da modalidade e o andamento do cliente atualizando junto;
# • agente, Página de Links (fundo e formato dos botões), Lojas Conectadas (filtro por loja);
# • planos e preço do agente vindos do servidor; módulo desligado pelo administrador some da página;
# • visitante × conta logada (botões); navegação interna do app para /conheca abre a página nova;
# • sem rolagem lateral em 320, 390 e 1280 px, sem erros de JavaScript, movimento reduzido respeitado.
# Servidor: PORT=4341 SQLITE_FILE=/tmp/ma-apres.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4341'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' '))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
IGN = lambda e: '#418' in e or e == 'Event'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    assert RA.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True, 'anuncios': True}).ok
    print('== servidor')
    html = RA.get('/conheca').text()
    check('/conheca é a página nova (não o app), com título e descrição atuais', 'data-landing' in html and 'assets/index-' not in html and 'Você fala.' in html and '<title>Meu Assistente · sua rotina e sua empresa, numa conversa</title>' in html)
    og = re.findall(r'<meta property="og:(url|image)" content="([^"]+)"', html)
    check('prévia de compartilhamento com endereço absoluto e imagem nova', len(og) == 2 and all(v.startswith('http') and '__PUB__' not in v for _, v in og) and og[1][1].endswith('/images/institucional/conheca-2026.png'), og)
    check('imagem de compartilhamento existe', RA.get('/images/institucional/conheca-2026.png').ok and RA.get('/conheca/').ok)
    ap = RA.get('/api/v2/apresentacao').json()
    check('dados públicos reais: planos com o que cada nível inclui e preço do agente', len(ap['planos']) >= 1 and all(x['inclui'] for x in ap['planos']) and ap['agente'] and ap['agente']['preco'] > 0 and ap['modulos']['agente'] is True, ap)
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); k = nome.replace(' ', '')
        V = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob); pg = V.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/conheca'); pg.wait_for_selector('#hero-conversa .item', timeout=15000)
        check(f'{nome}: abertura: a frase vira o item do app (lembrete criado)', 'Pagar a luz' in pg.inner_text('#hero-conversa .item') and pg.locator('#hero-conversa .msg.eu').count() >= 1)
        check(f'{nome}: visitante vê Entrar/Criar conta e não vê "Abrir meu assistente"', pg.locator('.topo a[href="/cadastro"]').is_visible() and not pg.locator('.topo a[data-logado]').is_visible())
        pg.click('.mundos [data-mundo=empresa]'); pg.wait_for_selector('#hero-conversa .msg.cliente', timeout=10000)
        check(f'{nome}: "Para sua empresa" troca a demonstração (cliente perguntando à loja)', 'Doceria da Ana' in pg.inner_text('#hero-nome') and 'entregam' in pg.inner_text('#hero-conversa'))
        pg.wait_for_function("()=>[...document.querySelectorAll('#hero-conversa .item b')].some(b=>/Novo pedido #128/.test(b.textContent))", timeout=20000)
        check(f'{nome}: o pedido feito na conversa chega como "Novo pedido"', True)
        pg.click('.mundos [data-mundo=voce]')
        # rotina
        pg.locator('#rotina').scroll_into_view_if_needed()
        check(f'{nome}: rotina: Agenda aberta com a linha do tempo de hoje', pg.get_attribute('#t-agenda', 'aria-selected') == 'true' and 'Reunião com o contador' in pg.inner_text('#dia-lin'))
        pg.click('[data-dia=amanha]'); check(f'{nome}: Hoje/Amanhã troca a linha do tempo', 'Dentista' in pg.inner_text('#dia-lin') and pg.inner_text('#dia-tit') == 'Amanhã')
        pg.focus('#t-agenda'); pg.keyboard.press('ArrowRight')
        check(f'{nome}: abas pelo teclado (seta) com foco e painel certos', pg.get_attribute('#t-lembretes', 'aria-selected') == 'true' and not pg.locator('#p-lembretes').is_hidden() and pg.locator('#p-agenda').is_hidden() and pg.evaluate("document.activeElement.id") == 't-lembretes')
        pg.click('#t-dinheiro'); pg.wait_for_timeout(1200)
        w = pg.evaluate("[...document.querySelectorAll('#barras i')].map(i=>i.getBoundingClientRect().width)")
        check(f'{nome}: Dinheiro: barras por categoria crescem ao abrir', len(w) == 5 and w[0] > w[-1] > 0, w)
        pg.click('#t-listas'); cb = pg.locator('#p-listas input[type=checkbox]').first; cb.check()
        check(f'{nome}: Listas: marcar um item risca o texto', pg.evaluate("getComputedStyle(document.querySelector('#p-listas input:checked + span')).textDecorationLine") == 'line-through')
        # experimente
        pg.locator('#experimente').scroll_into_view_if_needed()
        check(f'{nome}: "Experimente" avisa que é demonstração simulada', 'respostas são simuladas e nada é salvo' in pg.inner_text('#experimente'))
        pg.click('[data-exp="2"]'); pg.wait_for_selector('#exp-conversa .item', timeout=10000)
        it = N(pg.inner_text('#exp-conversa .item'))
        check(f'{nome}: "Registrar gasto" cria o lançamento', 'R$ 45,00 · Mercado' in it and 'registrado' in it, it)
        pg.wait_for_function("()=>!document.querySelector('[data-exp]').disabled", timeout=10000)
        pg.click('[data-exp="0"]'); pg.wait_for_function("()=>document.querySelectorAll('#exp-conversa .item').length===2", timeout=10000)
        check(f'{nome}: "Agendar compromisso" cria o compromisso de amanhã às 14:00', 'Dentista' in pg.inner_text('#exp-conversa') and '14:00' in pg.inner_text('#exp-conversa'))
        # jornada do pedido
        pg.locator('#jornada').scroll_into_view_if_needed()
        tot = lambda: N(pg.inner_text('#j-cliente .total'))
        check(f'{nome}: pedido: 12 un. na faixa de 10 (R$ 3,50 cada, R$ 42,00, preço cheio riscado)', 'R$ 42,00' in tot() and 'R$ 48,00' in tot() and pg.locator('#j-cliente .faixa.on').inner_text().startswith('A partir de 10'), tot())
        for _ in range(13): pg.click('#j-cliente [data-q="1"]')
        check(f'{nome}: + até 25 un.: R$ 3,00 cada (R$ 75,00)', 'R$ 75,00' in tot() and 'A partir de 25' in pg.inner_text('#j-cliente .faixa.on'), tot())
        pg.click('#j-cliente [data-j=checkout]')
        cx = lambda: N(pg.inner_text('#j-cliente'))
        check(f'{nome}: checkout entrega: aviso de acompanhamento e contato; nada de retirada', 'Meus pedidos' in cx() and 'WhatsApp ou por ligação' in cx() and 'Retire em' not in cx() and 'R$ 80,00' in cx(), cx())
        pg.click('#j-cliente [data-modo=retirada]')
        check(f'{nome}: checkout retirada: endereço, horário e WhatsApp; sem taxa e sem aviso de entrega', 'Retire em' in cx() and 'Falar no WhatsApp' in cx() and 'ligação' not in cx() and 'R$ 75,00' in cx(), cx())
        check(f'{nome}: painel da loja vazio antes do envio', 'aparecem aqui' in pg.inner_text('#j-loja'))
        pg.click('#j-cliente [data-j=enviar]')
        lj = lambda: N(pg.inner_text('#j-loja'))
        check(f'{nome}: enviado: o pedido chega no painel (aviso, itens, preço por quantidade, retirada)', 'Novo pedido #128' in lj() and '25×' in lj() and 'preço por quantidade' in lj() and 'Retirada no local' in lj() and pg.locator('#j-cliente .trilha li.at').inner_text().startswith('Pedido enviado'), lj())
        for s in ['aceito', 'preparo']: pg.click(f'#j-loja [data-st={s}]')
        acs = [x.get_attribute('data-st') for x in pg.locator('#j-loja [data-st]').all()]
        check(f'{nome}: em preparo, a loja só vê "Pronto para retirar" (retirada)', acs == ['pronto'], acs)
        pg.click('#j-loja [data-st=pronto]')
        check(f'{nome}: o cliente acompanha junto: "Pronto para retirar" atual, etapas anteriores concluídas com hora', 'Pronto para retirar' in pg.inner_text('#j-cliente .trilha li.at') and pg.locator('#j-cliente .trilha li.ok').count() == 3 and re.search(r'hoje, \d\d:\d\d', pg.inner_text('#j-cliente .trilha')))
        pg.click('#j-loja [data-st=concluido]')
        check(f'{nome}: concluído: todas as etapas verdes e "Retirado"', pg.locator('#j-cliente .trilha li.ok').count() == 5 and 'Retirado' in pg.inner_text('#j-cliente .trilha') and 'Concluído' in lj())
        pg.click('#j-cliente [data-j=refazer]'); pg.click('#j-cliente [data-j=checkout]'); pg.click('#j-cliente [data-modo=entrega]'); pg.click('#j-cliente [data-j=enviar]')
        for s in ['aceito', 'preparo']: pg.click(f'#j-loja [data-st={s}]')
        acs = [x.get_attribute('data-st') for x in pg.locator('#j-loja [data-st]').all()]
        check(f'{nome}: entrega: em preparo a loja só vê "Saiu para entrega" e o cliente vê a etapa', acs == ['saiu'] and 'Entrega: Rua Sete' in lj(), acs)
        pg.click('#j-loja [data-st=saiu]'); check(f'{nome}: "Saiu para entrega" atual no celular do cliente', 'Saiu para entrega' in pg.inner_text('#j-cliente .trilha li.at'))
        if k == 'computador': pg.locator('#jornada').screenshot(path='/tmp/e2e/apres_jornada.png')
        # agente
        pg.locator('#agente').scroll_into_view_if_needed()
        pg.click('[data-ag="1"]'); pg.wait_for_selector('#ag-conversa .cards-mini', timeout=10000)
        check(f'{nome}: agente: "O que tem hoje?" mostra os produtos', 'Brigadeiro gourmet' in pg.inner_text('#ag-conversa .cards-mini') and 'simuladas' in pg.inner_text('#agente') and pg.inner_text('#ag-url').endswith('/doceria-da-ana'))
        # página de links
        pg.locator('#links').scroll_into_view_if_needed()
        bg0 = pg.evaluate("getComputedStyle(document.getElementById('lk-tela')).backgroundImage"); pg.click('[data-fd="1"]'); pg.wait_for_timeout(500)
        bg1 = pg.evaluate("getComputedStyle(document.getElementById('lk-tela')).backgroundImage"); cor = pg.evaluate("getComputedStyle(document.getElementById('lk-tela')).color")
        check(f'{nome}: Página de Links: um toque troca o fundo (Mármore claro, texto escuro)', bg0 != bg1 and 'radial-gradient' in bg1 and cor == 'rgb(23, 23, 27)' and pg.get_attribute('[data-fd="1"]', 'aria-pressed') == 'true', (bg1[:60], cor))
        pg.click('[data-fm="1"]'); pg.wait_for_timeout(450)
        r = pg.evaluate("getComputedStyle(document.querySelector('#lk-tela .lk-bt')).borderTopLeftRadius")
        check(f'{nome}: formato "Pílula" arredonda os botões da prévia', float(r.replace('px', '')) > 100, r)
        check(f'{nome}: com o agente ligado, o botão "Fale com a Lia" aparece na Página de Links', pg.locator('#lk-tela [data-mod=agente]').is_visible())
        # lojas conectadas
        pg.locator('#conectadas').scroll_into_view_if_needed()
        n0 = pg.locator('#lc-avisos li').count(); pg.click('#lc-sel [data-lc="1"]')
        av = N(pg.inner_text('#lc-avisos'))
        check(f'{nome}: Lojas Conectadas: escolher a loja mostra só os avisos dela', n0 == 5 and pg.locator('#lc-avisos li').count() == 2 and 'Barbearia Navalha' in av and 'Doceria' not in av, (n0, av))
        # planos reais
        pg.locator('#planos').scroll_into_view_if_needed(); pg.wait_for_selector('#escada .degrau', timeout=8000)
        dg = [N(x.inner_text()) for x in pg.locator('#escada .degrau').all()]
        ok = len(dg) == len(ap['planos']) and all(pl['nome'] in t and ('R$ ' + f"{pl['preco']:.2f}".replace('.', ',')) in t and pl['inclui'] in t for pl, t in zip(ap['planos'], dg))
        check(f'{nome}: planos com nome, preço, prazo e o que incluem, iguais ao servidor', ok, dg)
        check(f'{nome}: preço do Agente vindo do servidor', ('R$ ' + f"{ap['agente']['preco']:.2f}".replace('.', ',')) in pg.inner_text('#extra-agente') and pg.locator('#extra-agente').is_visible())
        check(f'{nome}: "Escolher" leva para Anunciar', pg.get_attribute('#escada .degrau a', 'href') == '/anunciar')
        # dúvidas, chamada final, compartilhar
        pg.locator('#duvidas summary').first.click(); check(f'{nome}: dúvidas abrem', pg.locator('#duvidas details').first.evaluate('d=>d.open'))
        check(f'{nome}: chamada final com criar conta e anunciar', pg.locator('.final a[href="/cadastro"]').is_visible() and pg.locator('#cta-anunciar').is_visible())
        if mob:
            pg.evaluate('scrollTo(0, 2600)'); pg.wait_for_timeout(600)
            check(f'{nome}: barra fixa com Entrar/Criar conta aparece depois da abertura', pg.locator('#fixa').evaluate("e=>e.classList.contains('ver')&&getComputedStyle(e).visibility==='visible'"))
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 0)
        pg.goto('/conheca'); pg.wait_for_timeout(800); pg.screenshot(path=f'/tmp/e2e/apres_{k}.png')
        V.close()
    print('== 320 px e movimento reduzido')
    V = b.new_context(base_url=BASE, viewport={'width': 320, 'height': 640}, is_mobile=True, has_touch=True, reduced_motion='reduce'); pg = V.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/conheca'); pg.wait_for_timeout(700)
    check('320 px: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 0)
    check('movimento reduzido: a frase aparece sem digitação (item já criado) e a faixa de frases fica parada', pg.locator('#hero-conversa .item').count() >= 1 and pg.evaluate("getComputedStyle(document.getElementById('frases')).animationName") == 'none')
    V.close()
    print('== módulo desligado e conta logada')
    assert RA.put('/api/panel/modules', data={'agente': False}).ok
    V = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900}); pg = V.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/conheca'); pg.wait_for_selector('#escada .degrau', timeout=8000)
    check('agente desligado pelo administrador: seção, preço, item da lista e botão da Página de Links somem', not pg.locator('#agente').is_visible() and not pg.locator('#extra-agente').is_visible() and not pg.locator('#lk-tela [data-mod=agente]').is_visible() and pg.locator('.recs li[data-mod=agente]').evaluate('e=>getComputedStyle(e).display') == 'none')
    assert RA.put('/api/panel/modules', data={'agente': True}).ok
    C = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900})
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bia Souza', 'whatsapp': '+55 11 95555-0909', 'email': 'bia.apres@t.com', **U}, headers={'X-Forwarded-For': '10.4.4.4'}).ok
    pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e))); pc.goto('/conheca'); pc.wait_for_timeout(1500)
    check('conta logada: "Abrir meu assistente" no lugar de Entrar/Criar conta', pc.locator('.topo a[data-logado]').is_visible() and not pc.locator('.topo a[href="/cadastro"]').is_visible() and not pc.locator('.final a[href="/cadastro"]').is_visible())
    # navegação interna do app (SPA) para /conheca abre a página nova
    pc.goto('/'); pc.wait_for_timeout(3000)
    pc.evaluate("history.pushState({},'','/conheca')"); pc.wait_for_timeout(2500)
    check('dentro do app, ir para /conheca abre a página nova (não a antiga)', pc.url.endswith('/conheca') and pc.evaluate("document.documentElement.hasAttribute('data-landing')"), pc.url)
    bad = [e for e in errs if not IGN(e)]
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
