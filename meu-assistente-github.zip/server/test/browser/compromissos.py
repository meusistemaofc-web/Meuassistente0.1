# Compromissos — edição individual sem duplicação, agendamento inteligente pelo chat e sincronização com Configurações.
# Os 10 testes obrigatórios do pedido, pela tela real:
#  1-3) três compromissos IGUAIS (mesmo título e horário): tocar no 2º da Agenda abre o 2º e editar altera só ele;
#  4-7) criar pelo chat → aparece em Configurações → editar lá → o chat responde com os dados novos;
#  8-9) sinal em % e em R$ (prévia ao vivo), observações e dados incompletos; 10) nenhuma operação duplica.
import sys, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4311'
N = lambda t: str(t).replace('\xa0', ' ')  # moeda pt-BR usa espaço não separável
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    ctx = b.new_context(viewport={'width': 390, 'height': 860}, base_url=BASE); R = ctx.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    today = R.get('/api/agenda').json()['today']
    import datetime as dt
    D = lambda n: (dt.date.fromisoformat(today) + dt.timedelta(days=n)).isoformat()
    todos = lambda: R.get('/api/v2/compromissos?periodo=todos').json()['compromissos']
    item = lambda i: R.get(f'/api/v2/item/{i}').json()
    # 1) três compromissos diferentes, mas com o MESMO título e horário (o caso que causava a edição errada)
    ids = [R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': 'Tatuagem', 'date': D(n), 'time': '14:00', 'cliente_nome': c, 'valor_total': 200}}).json()['item']['id'] for n, c in [(3, 'Ana'), (9, 'Bia'), (16, 'Caio')]]
    antes = {i: json.dumps(item(i), sort_keys=True) for i in ids}
    pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/agenda?tab=compromissos'); pg.wait_for_selector('div.group p.text-\\[15px\\]', timeout=20000); pg.wait_for_timeout(600)
    linhas = pg.locator('div.group:has(p.text-\\[15px\\]:text-is("Tatuagem"))')
    check('agenda lista os três compromissos iguais', linhas.count() == 3, linhas.count())
    # 2) tocar no SEGUNDO abre o segundo (pelo identificador, não pelo título)
    linhas.nth(1).locator('p.text-\\[15px\\]').click(); pg.wait_for_selector('[data-appt-id]', timeout=10000)
    check('tocar no 2º abre o 2º compromisso', pg.get_attribute('[data-appt-id]', 'data-appt-id') == str(ids[1]) and 'Bia' in pg.inner_text('.ma-sheet'), pg.get_attribute('[data-appt-id]', 'data-appt-id'))
    pg.click('[data-ed]'); pg.wait_for_selector(f'[data-appt-edit="{ids[1]}"]')
    pg.fill('#e_cn', 'Bia Souza'); pg.fill('#e_h', '15:30'); pg.fill('#e_n', 'braço direito'); pg.select_option('#e_st', 'confirmed')
    # 8) sinal em % com prévia ao vivo; depois em R$
    pg.fill('#e_s', '50'); pg.select_option('#e_su', 'pct'); pg.wait_for_timeout(150)
    check('prévia do sinal em %', 'Sinal R$ 100,00' in N(pg.inner_text('#e_calc')) and 'saldo após o sinal R$ 100,00' in N(pg.inner_text('#e_calc')), N(pg.inner_text('#e_calc')))
    pg.fill('#e_s', '150'); pg.wait_for_timeout(100); check('prévia avisa porcentagem inválida', 'de 1 a 100' in N(pg.inner_text('#e_calc')), N(pg.inner_text('#e_calc')))
    pg.fill('#e_s', '50'); pg.click('[data-sv]'); pg.wait_for_selector(f'[data-appt-id="{ids[1]}"] [data-fin]', timeout=10000)
    e2 = item(ids[1])
    check('salvar edita o 2º (cliente, horário, situação, sinal 50%)', e2['clienteNome'] == 'Bia Souza' and e2['time'] == '15:30' and e2['status'] == 'confirmed' and e2['sinal'] == 100 and e2['sinalPct'] == 50 and e2['notes'] == 'braço direito', e2)
    # 3) o 1º e o 3º continuam exatamente iguais; nada novo foi criado
    check('1º e 3º intactos', json.dumps(item(ids[0]), sort_keys=True) == antes[ids[0]] and json.dumps(item(ids[2]), sort_keys=True) == antes[ids[2]])
    check('nenhum compromisso criado na edição', len(todos()) == 3)
    check('painel mostra situação e histórico', 'Confirmado' in pg.inner_text('.ma-sheet') and 'Histórico de alterações' in pg.inner_text('.ma-sheet'))
    # sinal em R$ (não vira %)
    pg.click('[data-ed]'); pg.wait_for_selector('#e_su'); pg.select_option('#e_su', 'reais'); pg.fill('#e_s', '80'); pg.fill('#e_p', '80'); pg.click('[data-sv]'); pg.wait_for_timeout(900)
    e2 = item(ids[1]); check('sinal em R$ e valor pago', e2['sinal'] == 80 and e2['sinalPct'] is None and e2['valorPago'] == 80 and e2['restante'] == 120, e2)
    pg.keyboard.press('Escape'); pg.goto('about:blank')
    # 4) criar pelo chat (frase completa → horário → conferência → sim)
    conv = 'cc000000-0000-4000-8000-000000000001'
    say = lambda t: N(R.post('/api/chat', data={'text': t, 'conversationId': conv}).json()['assistantMessage']['content'])
    m1 = say('Agendar uma tatuagem para o dia %d, cliente José, telefone 88999999999, valor de R$ 200, sinal de 50%% e observação: tatuagem no braço direito.' % int(D(5)[8:]))
    m2 = say('às 15h'); m3 = say('sim'); m4 = say('sim')
    novo = [a for a in todos() if a['clienteNome'] == 'José']
    check('chat: pergunta só o horário e confere antes de salvar', 'Que horas?' in m1 and 'Confere antes de eu salvar' in m2 and 'Sinal: R$ 100,00 (50%)' in m2, (m1, m2[:200]))
    check('chat: cria UM compromisso com todos os dados (e não duplica no 2º sim)', len(novo) == 1 and 'já está salvo' in m4 and novo[0]['clienteTelefone'] == '88999999999' and novo[0]['valorTotal'] == 200 and novo[0]['sinal'] == 100 and novo[0]['notes'] == 'tatuagem no braço direito' and novo[0]['valorPago'] is None, (m3, novo))
    nid = novo[0]['id'] if novo else 0
    # 5) aparece em Configurações → Compromissos
    pg.goto('/perfil#compromissos'); pg.wait_for_selector(f'#compromissos [data-mc="{nid}"]', timeout=20000)
    row = N(pg.locator(f'#compromissos [data-mc="{nid}"]').inner_text())
    check('aparece em Configurações com cliente e valores', 'José' in row and 'R$ 200,00' in row and 'sinal R$ 100,00 (50%)' in row, row)
    # 6) editar em Configurações
    pg.click(f'[data-mced="{nid}"]'); pg.wait_for_selector(f'[data-appt-id="{nid}"]'); pg.click('[data-ed]'); pg.wait_for_selector('#e_h')
    pg.fill('#e_h', '16:00'); pg.fill('#e_v', '300'); pg.wait_for_timeout(100)
    check('prévia recalcula o sinal em % com o novo total', 'Sinal R$ 150,00' in N(pg.inner_text('#e_calc')), N(pg.inner_text('#e_calc')))
    pg.click('[data-sv]'); pg.wait_for_selector(f'[data-appt-id="{nid}"] [data-fin]'); pg.keyboard.press('Escape'); pg.wait_for_timeout(1200)
    row = N(pg.locator(f'#compromissos [data-mc="{nid}"]').inner_text())
    check('lista de Configurações atualizada após salvar', '16:00' in row and 'R$ 300,00' in row and 'sinal R$ 150,00' in row, row)
    # 7) o chat reflete a edição
    m5 = say('que horas é essa tatuagem?'); check('o chat responde com os dados atualizados', '16:00' in m5 and '15:00' not in m5, m5)
    # busca e filtros da tela
    pg.fill('#compromissos [data-mc-q]', 'josé'); pg.wait_for_timeout(900)
    check('busca por cliente', pg.locator('#compromissos .mc-row').count() == 1, pg.locator('#compromissos .mc-row').count())
    pg.fill('#compromissos [data-mc-q]', ''); pg.select_option('#compromissos [data-mc-st]', 'confirmed'); pg.wait_for_timeout(900)
    check('filtro por situação', pg.locator('#compromissos .mc-row').count() == 1 and 'Bia Souza' in pg.inner_text('#compromissos'))
    pg.select_option('#compromissos [data-mc-st]', ''); pg.wait_for_timeout(600)
    # 9) dados incompletos e observação pelo chat; sinal ambíguo é perguntado
    conv = 'cc000000-0000-4000-8000-000000000002'
    a1 = say('agendar manicure dia %d sem horário, cliente Duda, obs: trazer esmalte' % int(D(6)[8:]))
    a2 = say('agendar corte dia %d às 11h, cliente Leo, custa 80, sinal de 30' % int(D(7)[8:]))
    a3 = say('reais'); a4 = say('sim')
    md = [a for a in todos() if a['clienteNome'] == 'Duda']; ml = [a for a in todos() if a['clienteNome'] == 'Leo']
    check('dados incompletos com observação', len(md) == 1 and md[0]['time'] is None and md[0]['notes'] == 'trazer esmalte', (a1, md))
    check('sinal ambíguo perguntado e salvo em R$', 'ou **R$' in a2 and len(ml) == 1 and ml[0]['sinal'] == 30 and ml[0]['sinalPct'] is None, (a2, ml))
    # 10) nenhuma duplicação no fim
    t = todos(); check('nenhuma operação gerou duplicação', len(t) == 6 and len({a['id'] for a in t}) == 6, [(a['title'], a['clienteNome']) for a in t])
    for w, h in [(390, 860), (1280, 900)]:
        pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(300)
        ov = pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
        check(f'Configurações sem rolagem horizontal em {w}px', ov['sw'] <= ov['cw'] + 1, ov)
    pg.set_viewport_size({'width': 390, 'height': 860}); pg.locator('#compromissos').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/compromissos.png')
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
