# Preço por quantidade (desconto progressivo), de ponta a ponta pela tela:
# dono liga o recurso no cadastro do produto, cria faixas (1 un. R$ 50 · 5+ R$ 45 · 10+ R$ 40), vê erros na hora e a prévia;
# cliente vê o selo no card, a tabela "Compre mais, pague menos" no detalhe (toque numa faixa ajusta a quantidade),
# o carrinho recalcula preço unitário, desconto e total ao aumentar/diminuir; o pedido gravado bate com o servidor.
# Produto sem o recurso continua com o preço normal. Celular (390 px) e computador.
# Servidor: PORT=4331 SQLITE_FILE=/tmp/ma-pq.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, re
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4331'; DBF = '/tmp/ma-pq.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def png(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return {'name': 'f.png', 'mimeType': 'image/png', 'buffer': b.getvalue()}
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' '))
def cat(pg, nome):
    if pg.locator('#pcs').count() and pg.locator('#pcs').is_visible():
        if pg.locator(f'#pcs option:text-is("{nome}")').count(): pg.select_option('#pcs', label=nome); return
        pg.select_option('#pcs', '__nova')
    pg.fill('#pc', nome)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Lia', 'whatsapp': '+55 11 94444-7070', 'email': 'lia.pq@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Atacado da Lia', 'categoria': 'Utilidades', 'titulo': 'x', 'texto': 'Canecas e pires', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'lia@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('#psave', timeout=10000)
    if pg.locator('[data-mim=manual]').count() and not pg.locator('#psave').is_visible(): pg.click('[data-mim=manual]')
    print('== cadastro (dono, celular)')
    pg.fill('#pn', 'Caneca'); pg.fill('#ppr', '50,00'); cat(pg, 'Cozinha'); pg.set_input_files('#pf', png((200, 80, 40))); pg.wait_for_timeout(600)
    check('opção "Preço por quantidade" no cadastro, desligada por padrão', 'Preço por quantidade' in pg.inner_text('#pofbox') and pg.get_attribute('[data-pqon]', 'aria-checked') == 'false' and pg.locator('[data-pqq]').count() == 0)
    pg.click('[data-pqon]'); pg.wait_for_selector('[data-pqq="0"]')
    check('ligado: mostra 1 unidade = preço normal e a primeira faixa', 'R$ 50,00 cada' in N(pg.inner_text('[data-pq1]')) and pg.locator('[data-pqq]').count() == 1)
    pg.fill('[data-pqq="0"]', '5'); pg.fill('[data-pqp="0"]', '55'); pg.wait_for_timeout(100)
    check('valida na hora: faixa acima do preço normal', 'menor que o preço normal' in pg.inner_text('[data-pqmsg]'), pg.inner_text('[data-pqmsg]'))
    pg.click('#psave'); pg.wait_for_timeout(700)
    check('não salva com faixa inválida (mensagem clara)', 'Preço por quantidade' in pg.inner_text('#perr') and not R.get(f'/api/v2/ads/{ID}/products').json()['items'], pg.inner_text('#perr'))
    pg.fill('[data-pqp="0"]', '45,00'); pg.click('[data-pqadd]'); pg.wait_for_selector('[data-pqq="1"]')
    check('"+ Faixa" sugere o dobro da quantidade anterior', pg.input_value('[data-pqq="1"]') == '10')
    pg.fill('[data-pqp="1"]', '46'); pg.wait_for_timeout(100)
    check('valida: cada faixa mais barata que a anterior', 'menor que a anterior' in pg.inner_text('[data-pqmsg]'), pg.inner_text('[data-pqmsg]'))
    pg.fill('[data-pqp="1"]', '40'); pg.wait_for_timeout(100)
    msg = N(pg.inner_text('[data-pqmsg]'))
    check('resumo das faixas com % de desconto', '5+ un. R$ 45,00 cada -10%' in msg and '10+ un. R$ 40,00 cada -20%' in msg, msg)
    check('prévia do card com o selo "Desconto por quantidade"', 'Desconto por quantidade' in pg.inner_text('#pprev'))
    pg.screenshot(path='/tmp/e2e/pq_cadastro.png', full_page=True)
    check('cadastro sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    pg.click('#psave'); pg.wait_for_timeout(1500)
    its = R.get(f'/api/v2/ads/{ID}/products').json()['items']; can = next(x for x in its if x['nome'] == 'Caneca')
    check('salvo no servidor', can.get('precoQtd') == {'ativo': True, 'faixas': [{'qtd': 5, 'preco': 45}, {'qtd': 10, 'preco': 40}]}, can.get('precoQtd'))
    # segundo produto, sem o recurso
    pg.fill('#pn', 'Pires'); pg.fill('#ppr', '10'); cat(pg, 'Cozinha'); pg.set_input_files('#pf', png((40, 80, 200))); pg.wait_for_timeout(500); pg.click('#psave'); pg.wait_for_timeout(1500)
    # editar: as faixas voltam preenchidas
    pg.locator(f'[data-pe="{can["id"]}"]').click(); pg.wait_for_selector('[data-pqq="1"]', timeout=8000)
    check('editar: faixas carregadas no formulário', pg.input_value('[data-pqq="0"]') == '5' and pg.input_value('[data-pqp="1"]') == '40' and pg.get_attribute('[data-pqon]', 'aria-checked') == 'true')
    pg.click('#pcancel') if pg.locator('#pcancel').count() else None
    PIRES = next(x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['nome'] == 'Pires')['id']; CAN = can['id']
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); k = nome.replace(' ', '')
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bia Cliente', 'whatsapp': {'celular390': '+55 11 95555-0201', 'computador': '+55 11 95555-0202'}[k], 'email': f'bia.{k}@t.com', **U}, headers={'X-Forwarded-For': '10.6.7.' + str(vp['width'] % 250)}).ok
        pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
        pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector(f'[data-prod="{CAN}"]', timeout=20000); pc.wait_for_timeout(600)
        card = N(pc.locator(f'[data-prod="{CAN}"]').inner_text()); cardP = N(pc.locator(f'[data-prod="{PIRES}"]').inner_text())
        check(f'{nome}: card com o selo da melhor faixa; produto sem o recurso sem selo', '10+ un.: R$ 40,00 cada' in card and 'R$ 50,00' in card and 'un.:' not in cardP, card)
        pc.locator(f'[data-prod="{CAN}"]').click(); pc.wait_for_selector('[data-faixas]', timeout=8000)
        tab = N(pc.inner_text('[data-faixas]'))
        check(f'{nome}: detalhe com "Compre mais, pague menos" e as 3 faixas', 'Compre mais, pague menos' in tab and '1 unidade R$ 50,00 cada' in tab and 'A partir de 5 unidades R$ 45,00 cada -10%' in tab and 'A partir de 10 unidades R$ 40,00 cada -20%' in tab, tab)
        check(f'{nome}: incentivo para a próxima faixa', 'Leve mais 4 e pague R$ 45,00 cada' in N(pc.inner_text('[data-qnext]')), pc.inner_text('[data-qnext]'))
        check(f'{nome}: 1 unidade = preço normal', 'R$ 50,00' in N(pc.inner_text('#padd')) and pc.get_attribute('[data-faixa="1"]', 'aria-pressed') == 'true')
        for _ in range(4): pc.click('#pp'); pc.wait_for_timeout(80)
        check(f'{nome}: aumentar para 5 muda para R$ 45 cada (total R$ 225)', 'R$ 225,00' in N(pc.inner_text('#padd')) and pc.get_attribute('[data-faixa="5"]', 'aria-pressed') == 'true' and 'R$ 45,00 cada' in N(pc.inner_text('[data-qunit]')), pc.inner_text('#padd'))
        pc.click('[data-faixa="10"]'); pc.wait_for_timeout(150)
        check(f'{nome}: tocar na faixa de 10 ajusta a quantidade (10 × R$ 40 = R$ 400)', 'R$ 400,00' in N(pc.inner_text('#padd')) and 'Melhor preço' in pc.inner_text('[data-qnext]'), pc.inner_text('#padd'))
        pc.click('#pm'); pc.wait_for_timeout(150)
        check(f'{nome}: diminuir para 9 volta para R$ 45 (R$ 405)', 'R$ 405,00' in N(pc.inner_text('#padd')), pc.inner_text('#padd'))
        if k == 'celular390': pc.screenshot(path='/tmp/e2e/pq_detalhe.png', full_page=True)
        for _ in range(5): pc.click('#pm'); pc.wait_for_timeout(60)
        pc.click('#padd'); pc.wait_for_timeout(500)  # 4 canecas
        pc.click(f'[data-add="{PIRES}"]'); pc.wait_for_timeout(400)
        pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
        it = lambda: N(pc.inner_text(f'[data-cart-item="{CAN}"]')); tot = lambda: N(pc.inner_text('#cgo'))
        check(f'{nome}: carrinho com 4 un. a R$ 50 e o aviso "mais 1"', '4' in pc.inner_text(f'[data-cart-item="{CAN}"] [data-cq-n]') and 'R$ 50,00 cada' in it() and 'Mais 1 e cada um sai por R$ 45,00' in it() and 'R$ 200,00' in it() and 'R$ 210,00' in tot(), it())
        pc.click(f'[data-cart-item="{CAN}"] [data-cq="1"]'); pc.wait_for_timeout(300)
        t5 = N(pc.inner_text('[data-checkout]'))
        check(f'{nome}: +1 → 5 un.: R$ 45 cada, preço normal riscado, desconto e total recalculados', 'R$ 45,00 cada' in it() and 'Preço por quantidade (5+ un.)' in it() and 'R$ 250,00' in it() and 'R$ 225,00' in it() and 'Desconto por quantidade − R$ 25,00' in t5 and 'Produtos R$ 260,00' in t5 and 'R$ 235,00' in tot(), t5[:600])
        for _ in range(5): pc.click(f'[data-cart-item="{CAN}"] [data-cq="1"]'); pc.wait_for_timeout(200)
        check(f'{nome}: +5 → 10 un.: R$ 40 cada (R$ 400 + pires R$ 10 = R$ 410)', 'R$ 40,00 cada' in it() and 'R$ 400,00' in it() and 'Desconto por quantidade − R$ 100,00' in N(pc.inner_text('[data-checkout]')) and 'R$ 410,00' in tot(), it())
        pc.click(f'[data-cart-item="{CAN}"] [data-cq="-1"]'); pc.wait_for_timeout(300)
        check(f'{nome}: −1 → 9 un.: volta para R$ 45 (R$ 405 + R$ 10 = R$ 415)', 'R$ 45,00 cada' in it() and 'R$ 405,00' in it() and 'R$ 415,00' in tot() and 'Mais 1 e cada um sai por R$ 40,00' in it(), it())
        check(f'{nome}: pires sem faixa continua com preço normal e sem aviso', 'R$ 10,00 cada' in N(pc.inner_text(f'[data-cart-item="{PIRES}"]')) and 'quantidade' not in pc.inner_text(f'[data-cart-item="{PIRES}"]').lower())
        check(f'{nome}: carrinho sem rolagem lateral', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if k == 'celular390': pc.screenshot(path='/tmp/e2e/pq_carrinho.png', full_page=True)
        pc.fill('#czap', '11955550201'); pc.click('#cgo'); pc.wait_for_timeout(2500)
        o = C.request.get('/api/v2/orders/mine').json()['items'][0]
        l0 = next(i for i in o['itens'] if i['pid'] == CAN)
        check(f'{nome}: pedido do servidor bate com a tela (9 × R$ 45 + R$ 10 = R$ 415) e registra a faixa', o['total'] == 415 and l0['qtd'] == 9 and l0['preco'] == 45 and l0['precoNormal'] == 50 and l0['promocao']['tipo'] == 'quantidade' and l0['promocao']['faixa'] == 5, (o['total'], l0))
        C.close()
    print('== dono vê o pedido')
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000)
    pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector('[data-odet]', timeout=15000); pg.wait_for_timeout(800)
    pg.locator('[data-odet]').first.click(); pg.wait_for_timeout(1000)
    body = N(pg.inner_text('body'))
    pg.screenshot(path='/tmp/e2e/pq_pedido_dono.png', full_page=True)
    check('painel de pedidos identifica o preço por quantidade', 'preço por quantidade (5+ un.)' in body, body[:400])
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
