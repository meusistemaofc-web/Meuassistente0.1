# Checkout com entrega: "Usar minha localização atual", pela tela, com a geolocalização real do navegador (Playwright) e o
# servidor descobrindo o endereço (geocodificação reversa no formato do Nominatim):
# • permissão já concedida → preenche sozinho e mostra o endereço para confirmar (precisão, taxa por km atualizada);
#   Confirmar → "Entregar em"; complemento; pedido leva endereço, partes e o ponto; a loja vê "Ver no mapa";
# • Editar (campos preenchidos) e "Usar outro endereço" (limpa, sem o ponto);
# • a localização não traz o número → pede o número antes de confirmar; o pedido não sai sem confirmar;
# • permissão negada → mensagem clara e preenchimento manual; aparelho sem localização; endereço não encontrado
#   (mantém o ponto e avisa); fora da área de entrega → aviso e bloqueio; "Não enviar" retira o ponto;
# • celular (390 px) e computador, sem rolagem lateral, sem erros de JavaScript.
# Servidor: python3 test/browser/geocoder_fake.py 4399 & GEOCODER_URL=http://127.0.0.1:4399 PORT=4335 SQLITE_FILE=/tmp/ma-cloc.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, re, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4335'; DBF = '/tmp/ma-cloc.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (200, 200), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
P1 = {'latitude': -23.5505, 'longitude': -46.6333, 'accuracy': 25}   # Avenida Paulista, 1578 (≈0,6 km da loja)
P2 = {'latitude': -23.5600, 'longitude': -46.6400, 'accuracy': 40}   # Rua Pamplona, sem número
P3 = {'latitude': -23.6200, 'longitude': -46.6350, 'accuracy': 30}   # sem endereço no mapa e a ≈7 km (fora da área de 5 km)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono Rui', 'whatsapp': '+55 11 94444-7171', 'email': 'rui.loc@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Padaria Paulista', 'categoria': 'Padaria', 'titulo': 'x', 'texto': 'Pães e bolos', 'zap': '11988887777', 'endereco': 'Rua Augusta, 900, Consolação, São Paulo - SP'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', lat=-23.555, lng=-46.635 where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': True, 'raio': 5, 'modoTaxa': 'km', 'kmGratis': 0.2, 'taxaExcedente': 4, 'taxaKm': 2}}).ok
    PID = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Pão de queijo', 'preco': 20, 'categoria': 'Salgados', 'fotos': [durl((230, 200, 90))]}).json()['items'][0]['id']
    n = [0]
    def cliente(vp, mob, geo=None, perm=True, init=None):
        n[0] += 1; k = n[0]
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, **({'geolocation': geo} if geo else {}), permissions=['geolocation'] if perm else [])
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Loc', 'whatsapp': f'+55 11 95555-03{k:02d}', 'email': f'cli.loc{k}@t.com', **U}, headers={'X-Forwarded-For': f'10.7.1.{k}'}).ok
        if init: C.add_init_script(init)
        pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e))); return C, pc
    def carrinho(pc):
        pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector(f'[data-add="{PID}"]', timeout=20000); pc.wait_for_timeout(400)
        pc.click(f'[data-add="{PID}"]'); pc.wait_for_timeout(300); pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
    T = lambda pc, sel='[data-co-endereco]': N(pc.inner_text(sel)) if pc.locator(sel).count() else ''
    def enviar(pc, zap):
        pc.fill('#czap', zap); pc.click('#cgo'); pc.wait_for_timeout(2200)
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); cel = mob
        # 1) permissão já concedida: preenche sozinho e pede confirmação
        C, pc = cliente(vp, mob, P1); carrinho(pc)
        try: pc.wait_for_selector('[data-ent-confirmar]', timeout=10000); ok = True
        except Exception: ok = False
        t = T(pc)
        check(f'{nome}: já autorizado → preenche sozinho e mostra o endereço para confirmar', ok and 'Confira o endereço encontrado' in t and 'Avenida Paulista, 1578, Bela Vista, São Paulo - SP' in t and 'precisão de ~25 m' in t, t)
        fee = N(pc.inner_text('[data-mo=entrega]'))
        check(f'{nome}: taxa por km calculada pela localização atual', 'R$' in fee and 'use sua localização' not in fee, fee)
        if cel: pc.locator('[data-co-endereco]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/checkout_loc_confirmar.png')
        pc.fill('#czap', '11955550301'); pc.click('#cgo'); pc.wait_for_timeout(300)
        check(f'{nome}: o pedido não sai sem confirmar o endereço', 'Confirme o endereço encontrado' in N(pc.inner_text('#cerr')) and pc.locator('[data-checkout]').count() == 1, pc.inner_text('#cerr'))
        pc.click('[data-ent-ok]'); pc.wait_for_selector('[data-ent-confirmado]')
        t = T(pc); check(f'{nome}: Confirmar → "Entregar em" com o endereço e a localização confirmada', 'Entregar em' in t and 'Avenida Paulista, 1578, Bela Vista, São Paulo - SP' in t and 'Localização atual confirmada' in t, t)
        pc.fill('[data-ent=complemento]', 'Apto 41'); pc.click('[data-mo=retirada]'); pc.wait_for_timeout(200); pc.click('[data-mo=entrega]'); pc.wait_for_selector('[data-ent-confirmado]')
        check(f'{nome}: trocar a modalidade e voltar mantém o endereço confirmado e o complemento', pc.input_value('[data-ent=complemento]') == 'Apto 41')
        if cel: pc.locator('[data-co-endereco]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/checkout_loc_confirmado.png')
        check(f'{nome}: sem rolagem lateral no checkout', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        enviar(pc, '11955550301')
        o = C.request.get('/api/v2/orders/mine').json()['items'][0]
        check(f'{nome}: pedido com endereço completo, partes, ponto de entrega e taxa', o.get('endereco') == 'Avenida Paulista, 1578 - Apto 41, Bela Vista, São Paulo - SP' and o.get('entregaLoc', {}).get('lat') == -23.5505 and o.get('entregaLoc', {}).get('precisao') == 25 and o.get('enderecoPartes', {}).get('complemento') == 'Apto 41' and o.get('taxa', 0) > 4, o)
        OID = o['id']
        # 2) Editar: campos preenchidos, ponto mantido; "Usar outro endereço" limpa tudo
        carrinho(pc); pc.wait_for_selector('[data-ent-confirmar]', timeout=10000); pc.click('[data-ent-editar]'); pc.wait_for_selector('[data-ent=rua]')
        vals = [pc.input_value(f'[data-ent={f}]') for f in ('rua', 'numero', 'bairro', 'cidade')]
        check(f'{nome}: Editar mostra os campos já preenchidos e mantém o ponto', vals == ['Avenida Paulista', '1578', 'Bela Vista', 'São Paulo - SP'] and pc.locator('[data-ent-locmantida]').count() == 1, vals)
        pc.fill('[data-ent=numero]', '1600'); enviar(pc, '11955550301')
        o2 = C.request.get('/api/v2/orders/mine').json()['items'][0]
        check(f'{nome}: pedido com o endereço editado e o ponto da localização', o2['id'] != OID and o2.get('endereco') == 'Avenida Paulista, 1600, Bela Vista, São Paulo - SP' and o2.get('entregaLoc', {}).get('lat') == -23.5505, o2)
        carrinho(pc); pc.wait_for_selector('[data-ent-confirmar]', timeout=10000); pc.click('[data-ent-ok]'); pc.wait_for_selector('[data-ent-confirmado]'); pc.click('[data-ent-outro]'); pc.wait_for_selector('[data-ent=rua]')
        check(f'{nome}: "Usar outro endereço" limpa os campos e não envia o ponto', all(pc.input_value(f'[data-ent={f}]') == '' for f in ('rua', 'numero', 'bairro')) and pc.locator('[data-ent-locmantida]').count() == 0 and pc.locator('[data-ent-confirmar]').count() == 0)
        pc.click('#cgo'); pc.wait_for_timeout(200); check(f'{nome}: sem endereço o pedido não sai (indica o campo)', 'Informe a rua' in pc.inner_text('#cerr'))
        pc.click('[data-ent-gps]'); pc.wait_for_selector('[data-ent-confirmar]', timeout=10000)
        check(f'{nome}: o botão "Usar minha localização atual" preenche de novo', 'Avenida Paulista, 1578' in T(pc))
        C.close()
        if not cel: continue
        # 3) localização sem número: pede o número antes de confirmar
        C, pc = cliente(vp, mob, P2); carrinho(pc); pc.wait_for_selector('[data-ent-confirmar]', timeout=10000)
        check(f'{nome}: sem número → campo Número no cartão', pc.locator('[data-ent-confirmar] [data-ent=numero]').count() == 1 and 'Rua Pamplona, Jardim Paulista, São Paulo - SP' in T(pc), T(pc))
        pc.fill('#czap', '11955550302'); pc.click('#cgo'); pc.wait_for_timeout(200)
        check(f'{nome}: enviar sem o número → pede o número', 'Informe o número e confirme' in pc.inner_text('#cerr'))
        pc.click('[data-ent-ok]'); pc.wait_for_timeout(200)
        check(f'{nome}: confirmar sem o número → aviso', 'Informe o número para confirmar' in T(pc) and pc.locator('[data-ent-confirmado]').count() == 0, T(pc))
        pc.fill('[data-ent-confirmar] [data-ent=numero]', '77'); pc.click('[data-ent-ok]'); pc.wait_for_selector('[data-ent-confirmado]')
        check(f'{nome}: com o número, confirma "Rua Pamplona, 77"', 'Rua Pamplona, 77, Jardim Paulista, São Paulo - SP' in T(pc), T(pc))
        enviar(pc, '11955550302'); o = C.request.get('/api/v2/orders/mine').json()['items'][0]
        check(f'{nome}: pedido com o número informado', o.get('endereco') == 'Rua Pamplona, 77, Jardim Paulista, São Paulo - SP' and o.get('entregaLoc', {}).get('lat') == -23.56, o)
        C.close()
        # 4) permissão negada: mensagem clara e preenchimento manual (localização salva calcula a taxa)
        C, pc = cliente(vp, mob, P1, perm=False); assert C.request.put('/api/v2/me/location', data={'lat': -23.5505, 'lng': -46.6333}).ok
        carrinho(pc); pc.wait_for_timeout(800)
        check(f'{nome}: sem permissão não preenche sozinho', pc.locator('[data-ent-confirmar]').count() == 0 and pc.input_value('[data-ent=rua]') == '')
        pc.click('[data-ent-gps]'); pc.wait_for_selector('[data-ent-msg].err', timeout=10000)
        check(f'{nome}: permissão negada → explica e oferece digitar', 'Permissão de localização negada' in T(pc) and 'preencha o endereço abaixo' in T(pc), T(pc))
        if cel: pc.locator('[data-co-endereco]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/checkout_loc_negada.png')
        for f, v in [('rua', 'Rua Haddock Lobo'), ('numero', '595'), ('bairro', 'Cerqueira César'), ('cidade', 'São Paulo - SP'), ('referencia', 'Portão verde')]: pc.fill(f'[data-ent={f}]', v)
        enviar(pc, '11955550303'); o = C.request.get('/api/v2/orders/mine').json()['items'][0]
        check(f'{nome}: pedido com o endereço digitado, sem ponto', o.get('endereco') == 'Rua Haddock Lobo, 595, Cerqueira César, São Paulo - SP (Ref.: Portão verde)' and not o.get('entregaLoc'), o)
        C.close()
        # 5) endereço não encontrado e fora da área de entrega
        C, pc = cliente(vp, mob, P3); carrinho(pc); pc.wait_for_selector('[data-ent-locmantida]', timeout=10000)
        t = T(pc)
        check(f'{nome}: endereço não encontrado → mantém o ponto e pede para preencher', 'não consegui descobrir o endereço' in t and pc.input_value('[data-ent=rua]') == '', t)
        check(f'{nome}: fora da área → mostra a distância e o limite', pc.locator('[data-ent-fora]').count() == 1 and re.search(r'fica a 7,\d km, fora da área de entrega desta loja \(até 5 km\)', t), t)
        for f, v in [('rua', 'Rua Longe'), ('numero', '9'), ('bairro', 'Jabaquara')]: pc.fill(f'[data-ent={f}]', v)
        pc.fill('#czap', '11955550304'); pc.click('#cgo'); pc.wait_for_timeout(300)
        check(f'{nome}: fora da área → pedido bloqueado', 'fora da área de entrega' in pc.inner_text('#cerr') and pc.locator('[data-checkout]').count() == 1, pc.inner_text('#cerr'))
        pc.click('[data-ent-semloc]'); pc.wait_for_timeout(200)
        check(f'{nome}: "Não enviar" retira o ponto e o aviso, mantendo o que foi digitado', pc.locator('[data-ent-locmantida]').count() == 0 and pc.locator('[data-ent-fora]').count() == 0 and pc.input_value('[data-ent=rua]') == 'Rua Longe')
        C.close()
        # 6) aparelho/navegador sem localização
        C, pc = cliente(vp, mob, None, perm=False, init='delete Navigator.prototype.geolocation'); carrinho(pc); pc.click('[data-ent-gps]'); pc.wait_for_timeout(300)
        check(f'{nome}: sem localização no aparelho → mensagem e campos para digitar', 'não informa a localização' in T(pc) and pc.locator('[data-ent=rua]').count() == 1, T(pc))
        C.close()
    # 7) a loja vê o ponto de entrega no pedido
    print('== painel da loja')
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000); pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector(f'[data-odet="{OID}"]', timeout=15000); pg.wait_for_timeout(400)
    pg.click(f'[data-odet="{OID}"]'); pg.wait_for_selector(f'[data-pedido-det="{OID}"]')
    mp = pg.get_attribute(f'[data-pedido-det="{OID}"] [data-ped-mapa]', 'href') or ''
    check('painel: pedido com o endereço e "Ver no mapa" no ponto da localização', mp == 'https://www.google.com/maps/search/?api=1&query=-23.5505,-46.6333' and 'Avenida Paulista, 1578' in pg.inner_text(f'[data-pedido-det="{OID}"]'), mp)
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
