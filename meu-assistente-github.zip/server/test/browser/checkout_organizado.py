# Checkout ("Seu pedido") organizado: itens num cartão, opções em botões compactos, cupom/observação recolhidos quando não há
# cupons nem MCoins, total e "Enviar pedido · R$" fixos embaixo; textos de exemplo (placeholder) em cinza com opacidade baixa;
# faixa sólida no topo (sem desfoque) na cor da tela. Requer a empresa criada por tema_catalogo_agente.py (id 1, admin@t.com).
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    c0=b.new_context(base_url=BASE); R=c0.request; assert R.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
    R.put('/api/v2/ads/1',data={'tema':{'preset':'padrao','cor':'#3b6cff','fundo':'escuro','layout':'lista','cantos':'arredondado'},'entrega':{'retirada':True,'entrega':False},'pagamento':{'pix':True,'dinheiro':True}})
    st=c0.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/x/empresa/1'); pg.wait_for_selector('[data-add]',timeout=20000); pg.wait_for_timeout(4000)
        pg.locator('[data-add]').nth(1).click(); pg.wait_for_timeout(2500); pg.get_by_text('Ver pedido').click(); pg.wait_for_selector('#cgo'); pg.wait_for_timeout(600)
        g=pg.evaluate("""()=>{const s=document.querySelector('.ma-sheet-in'),r=e=>e.getBoundingClientRect(),go=document.getElementById('cgo'),m=document.getElementById('cmais');return {ops:document.querySelectorAll('.ma-co-op').length,on:[...document.querySelectorAll('.ma-co-op.on')].map(x=>x.dataset.mo||x.dataset.pg||x.dataset.qd),mais:m&&m.open,obsVis:document.getElementById('cobs').checkVisibility(),go:go.textContent,goB:r(go).bottom,inB:r(s).bottom,sticky:getComputedStyle(go.closest('.ma-co-foot')).position,card:document.querySelectorAll('.ma-co-card [data-rm]').length}}""")
        check(f'{nome}: opções em botões compactos (receber + pagamento) com a escolha marcada', g['ops']==3 and 'retirada' in g['on'] and len(g['on'])==2, g)
        check(f'{nome}: itens num cartão com remover (×)', g['card']==1, g)
        check(f'{nome}: sem cupons nem MCoins: cupom e observação ficam recolhidos', g['mais'] is False and not g['obsVis'], g)
        check(f'{nome}: total e "Enviar pedido · R$" fixos embaixo, visíveis sem rolar', g['sticky']=='sticky' and 'R$' in g['go'] and g['goB']<=g['inB']+1, g)
        pg.click('#cmais summary'); pg.wait_for_timeout(300); pg.click('[data-pg=dinheiro]'); pg.wait_for_timeout(500)
        check(f'{nome}: abrir "mais opções" e trocar o pagamento mantém aberto', pg.evaluate("document.getElementById('cmais').open") and pg.locator('[data-tc]').count()==2)
        ph=pg.evaluate("()=>{const t=document.getElementById('cobs'),cs=getComputedStyle(t,'::placeholder');return [t.placeholder,cs.color,cs.webkitTextFillColor]}")
        check(f'{nome}: "Ex.: …" em cinza com opacidade baixa', ph[0].startswith('Ex.') and ph[1]=='rgba(142, 142, 150, 0.55)' and ph[2]=='rgba(142, 142, 150, 0.55)', ph)
        comp=pg.evaluate("()=>document.querySelectorAll('textarea.composer-input').length")
        pg.locator('#czap').fill('(11) 95555-1212'); pg.locator('#cobs').fill('portão azul'); pg.click('#cgo'); pg.wait_for_timeout(2500)
        er=pg.evaluate("()=>{const e=document.getElementById('cerr');return e?e.textContent:''}")
        check(f'{nome}: "Enviar pedido" chega ao servidor (o dono não pode comprar da própria loja: a regra responde no rodapé)', pg.locator('.ma-sheet').count()==0 or 'própria loja' in er, er)
        topo=pg.evaluate("()=>{const t=document.getElementById('ma-topo');if(!t)return null;const cs=getComputedStyle(t);return {pos:cs.position,z:cs.zIndex,bf:cs.backdropFilter||cs.webkitBackdropFilter||'none',bg:cs.backgroundColor,pe:cs.pointerEvents}}")
        check(f'{nome}: faixa sólida no topo (sem desfoque, não bloqueia toques)', topo and topo['pos']=='fixed' and topo['bf'] in ('none','') and topo['pe']=='none' and topo['bg'] not in ('rgba(0, 0, 0, 0)','transparent'), topo)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
