# Cards do catálogo (/x/empresa/:id) e descrição da empresa (pedido de 18/11):
# - cards de serviços e produtos só com imagem, nome e preço (quando cadastrado), sem descrição;
# - tocar no card abre os detalhes (imagem em destaque, nome, preço, categoria, descrição completa, variações e ação);
# - "Agendar" dos detalhes abre o agendamento de sempre; o botão "Agendar" do card continua igual;
# - campo "Sobre a empresa" com contador n/200 em tempo real e limite de 200 (frontend e backend);
# - celular e computador, sem rolagem horizontal.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-ui.db npx tsx test/serve-sqlite.ts (banco novo)
import sys
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4311'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
DESC = 'Corte na tesoura com acabamento na navalha, lavagem e finalização com pomada. Ideal para quem quer manter o visual alinhado.'
with sync_playwright() as p:
    b = p.chromium.launch(); R = b.new_context(base_url=BASE).request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Barbearia Card', 'categoria': 'Barbearia', 'titulo': 'Cortes', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'servicos', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {k: {'ativo': True, 'abre': '00:00', 'fecha': '23:59'} for k in ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']}}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Corte clássico', 'preco': 45, 'tipo': 'servico', 'modoPreco': 'fixo', 'duracao': 40, 'categoria': 'Cortes', 'descricao': DESC, 'fotos': [IMG]}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Barba', 'preco': 30, 'tipo': 'servico', 'modoPreco': 'fixo', 'duracao': 30, 'categoria': 'Cortes', 'descricao': 'Toalha quente.'}).ok
    errs = []
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob)
        assert c.request.post('/api/auth', data={'action': 'login', 'email': 'admin@t.com', 'password': 'Senha@Forte123'}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(f'/x/empresa/{ID}'); pg.wait_for_selector('[data-det]', timeout=15000); pg.wait_for_timeout(800)
        cards = pg.locator('[data-det]'); txt = ' | '.join(cards.nth(i).inner_text() for i in range(cards.count()))
        check(f'{nome}: cards de serviço só com nome e preço (sem descrição)', cards.count() == 2 and 'Corte clássico' in txt and 'R$' in txt and 'Corte na tesoura' not in txt and 'Toalha quente' not in txt, txt)
        check(f'{nome}: botão "Agendar" do card mantido', pg.locator('[data-book]').count() == 2)
        pg.screenshot(path=f'/tmp/e2e/cards_servicos_{nome}.png')
        cards.first.click(); pg.wait_for_selector('.ma-sheet [data-detalhe]', timeout=5000); pg.wait_for_timeout(300)
        det = pg.locator('.ma-sheet [data-detalhe]'); dt = det.inner_text()
        check(f'{nome}: detalhes do serviço: nome, preço, duração, categoria e descrição completa', 'Corte clássico' in dt and 'R$' in det.locator('[data-preco]').inner_text() and '40 min' in dt and 'Cortes' in dt and det.locator('[data-desc]').inner_text().strip() == DESC, dt[:300])
        check(f'{nome}: imagem em destaque', pg.locator('.ma-sheet img').count() == 1 and pg.locator('.ma-sheet img').first.bounding_box()['height'] >= 200)
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.screenshot(path=f'/tmp/e2e/cards_servico_detalhes_{nome}.png')
        pg.click('#sv_ag'); pg.wait_for_timeout(700)
        check(f'{nome}: "Agendar" dos detalhes abre o agendamento do serviço', pg.locator('.ma-sheet [data-detalhe]').count() == 0 and 'Corte clássico' in pg.locator('.ma-sheet').inner_text() and pg.locator('.ma-sheet [data-d], .ma-sheet [data-dia], .ma-sheet button').count() > 2, pg.locator('.ma-sheet').inner_text()[:200])
        pg.locator('.ma-sheet-x').click(); pg.wait_for_timeout(300)
        pg.locator('[data-book]').first.click(); pg.wait_for_timeout(600)
        check(f'{nome}: "Agendar" do card abre direto o agendamento (como antes)', pg.locator('.ma-sheet [data-detalhe]').count() == 0 and pg.locator('.ma-sheet').count() == 1)
        pg.locator('.ma-sheet-x').click(); pg.wait_for_timeout(300)
        c.close()
    # campo "Sobre a empresa": contador em tempo real e limite de 200
    c = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, has_touch=True, is_mobile=True)
    assert c.request.post('/api/auth', data={'action': 'signup', 'name': 'Nova Dona', 'whatsapp': '+55 11 95555-0101', 'email': 'nova@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.9.9.77'}).ok
    pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/anunciar'); pg.wait_for_selector('#adf', timeout=15000); pg.wait_for_timeout(800)
    pg.locator('input[name=planId][value=n4]').evaluate("e=>{e.checked=true;e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('input',{bubbles:true}))}"); pg.wait_for_timeout(800); print('  sobre visível:', pg.locator('textarea[data-sobre]').is_visible())
    ta = pg.locator('textarea[data-sobre]')
    if ta.count():
        ta.fill('A' * 150); pg.wait_for_timeout(200)
        check('contador em tempo real (150/200)', '150/200' in pg.locator('[data-sobre-n]').inner_text(), pg.locator('[data-sobre-n]').inner_text())
        ta.fill('B' * 260); pg.wait_for_timeout(200)
        check('campo não passa de 200 caracteres', len(ta.input_value()) == 200 and '200/200' in pg.locator('[data-sobre-n]').inner_text(), (len(ta.input_value()), pg.locator('[data-sobre-n]').inner_text()))
        check('rótulo informa o limite', 'até 200 caracteres' in pg.inner_text('body'))
        pg.screenshot(path='/tmp/e2e/sobre_contador.png')
    else:
        check('formulário com o campo "Sobre a empresa"', False, pg.url)
    check('backend recusa 201 caracteres', R.put(f'/api/v2/ads/{ID}', data={'sobre': 'C' * 201}).status == 400)
    check('backend aceita 200 caracteres', R.put(f'/api/v2/ads/{ID}', data={'sobre': 'C' * 200}).ok)
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
