# Recebimento de pedidos (painel e/ou WhatsApp), de ponta a ponta no navegador:
# admin configura o provedor (Evolution API) pela aba "WhatsApp (envio)" e envia um teste; a loja escolhe os canais em
# Entrega e pagamento (salva ao tocar, persiste ao recarregar, nunca os dois desligados), envia teste; um pedido real chega
# ao WhatsApp da empresa com os detalhes e continua em Pedidos; com o painel desligado não há notificação. Celular e computador.
# Servidor: PORT=4353 SQLITE_FILE=/tmp/ma-receb.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, json, threading, re
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
import _admin
BASE='http://localhost:4353'; DBF='/tmp/ma-receb.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
MSGS=[]
class Evo(BaseHTTPRequestHandler):
    def do_POST(self):
        b=json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
        if self.headers.get('apikey')!='evo-chave-teste' or '/message/sendText/loja1' not in self.path: self.send_response(401); self.end_headers(); self.wfile.write(b'{}'); return
        MSGS.append(b); self.send_response(201); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps({'key':{'id':'E%d'%len(MSGS)}}).encode())
    def log_message(self,*a): pass
srv=HTTPServer(('127.0.0.1',4399),Evo); threading.Thread(target=srv.serve_forever,daemon=True).start()
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE,viewport={'width':1280,'height':900}); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Dona Pizzaria','whatsapp':'+55 11 93330-1111','email':'dono@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    r=O.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Bella','categoria':'Pizzaria','titulo':'Pizzaria Bella','texto':'Forno a lenha','zap':'11 98765-4321','lat':-23.552,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); db.commit(); db.close()
    assert O.put(f'/api/v2/ads/{BID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'dinheiro':True},'entrega':{'retirada':True}}).ok
    r=O.post(f'/api/v2/ads/{BID}/products',data={'nome':'Pizza Margherita','preco':52.9,'categoria':'Pizzas','fotos':[PNG]}); PID=[x for x in r.json()['items'] if x['nome']=='Pizza Margherita'][0]['id']
    c0=b.new_context(base_url=BASE); C=c0.request
    assert C.post('/api/auth',data={'action':'signup','name':'Carlos Cliente','whatsapp':'+55 21 98888-7777','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    sess=o.cookies()
    def entrega(pg):
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]',timeout=20000); pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector('[data-lt2=entrega]'); pg.click('[data-lt2=entrega]')
        pg.wait_for_selector('[data-rcb-box] [data-rcb="rcb-painel"]',timeout=15000); pg.wait_for_timeout(300)
    sw=lambda pg,k: pg.locator(f'[data-rcb="rcb-{k}"]')
    est=lambda pg: {k:sw(pg,k).get_attribute('aria-checked') for k in ('painel','whatsapp')}
    print('== antes de o administrador configurar')
    pg=o.new_page(); pg.set_viewport_size({'width':390,'height':844}); pg.on('pageerror',lambda e:errs.append(str(e))); entrega(pg)
    check('a seção "Onde receber os novos pedidos" aparece em Entrega e pagamento', pg.locator('#ma-x').get_by_text('Onde receber os novos pedidos').count()>=1)
    check('padrão: painel ligado, WhatsApp desligado', est(pg)=={'painel':'true','whatsapp':'false'}, est(pg))
    check('WhatsApp bloqueado com o motivo (não liberado pelo administrador)', sw(pg,'whatsapp').is_disabled() and 'administrador' in pg.locator('[data-rcb-box]').inner_text())
    pg.screenshot(path='/tmp/receb_antes.png',full_page=False)
    print('== administrador configura o envio (aba WhatsApp (envio))')
    ap=a.new_page(); ap.on('pageerror',lambda e:errs.append(str(e))); ap.goto('/admin'); _admin.aba(ap,'whatsapp'); ap.wait_for_selector('[data-wa-adm]',timeout=15000)
    check('admin: provedor ainda não configurado', 'Não configurado' in ap.locator('[data-wa-st]').inner_text())
    ap.select_option('#wa_p','evolution'); check('admin: mostra só os campos do provedor escolhido', ap.locator('[data-wa-f=evolution]').is_visible() and not ap.locator('[data-wa-f=cloud]').is_visible() and not ap.locator('[data-wa-f=zapi]').is_visible())
    ap.fill('#wa_eu','http://127.0.0.1:4399'); ap.fill('#wa_ei','loja1'); ap.fill('#wa_ek','evo-chave-teste'); ap.fill('#wa_tn','11 91234-5678'); ap.click('#wa_t')
    ap.wait_for_function("()=>/enviada|Não foi/.test(document.querySelector('#wa_m').textContent)",timeout=15000)
    check('admin: "Salvar e enviar teste" envia de verdade ao provedor', 'enviada' in ap.locator('#wa_m').inner_text() and MSGS and MSGS[-1]['number']=='5511912345678', (ap.locator('#wa_m').inner_text(),MSGS[-1:]))
    check('admin: status vira "Configurado" e a chave não fica no campo', 'Configurado' in ap.locator('[data-wa-st]').inner_text() and ap.locator('#wa_ek').input_value()=='')
    ap.reload(); _admin.aba(ap,'whatsapp'); ap.wait_for_selector('[data-wa-adm]')
    check('admin: depois de recarregar, a chave aparece como salva e protegida (sem o valor)', ap.locator('#wa_p').input_value()=='evolution' and 'Salvo e protegido' in (ap.locator('#wa_ek').get_attribute('placeholder') or '') and 'evo-chave-teste' not in ap.content())
    for nome,vp in [('celular',{'width':390,'height':844}),('computador',{'width':1280,'height':900})]:
        print('== loja,',nome)
        c=b.new_context(base_url=BASE,viewport=vp,has_touch=nome=='celular',is_mobile=nome=='celular'); c.add_cookies(sess); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); entrega(pg)
        if nome=='celular':
            check('número cadastrado da empresa aparece', '+55 11 98765-4321' in pg.locator('[data-rcb-num]').inner_text())
            sw(pg,'whatsapp').click(); pg.wait_for_function("()=>/Salvo/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
            check('ligar o WhatsApp salva na hora (painel + WhatsApp)', est(pg)=={'painel':'true','whatsapp':'true'} and 'painel e no WhatsApp' in pg.locator('#rcbm').inner_text(), (est(pg),pg.locator('#rcbm').inner_text()))
            n0=len(MSGS); pg.click('[data-rcb-teste]'); pg.wait_for_function("()=>/enviada|Não foi/.test(document.querySelector('#rcbm').textContent)",timeout=10000)
            check('"Enviar mensagem de teste" chega no WhatsApp da empresa', len(MSGS)==n0+1 and MSGS[-1]['number']=='5511987654321', pg.locator('#rcbm').inner_text())
            sw(pg,'painel').click(); pg.wait_for_function("()=>/Salvo: você recebe os pedidos pelo WhatsApp/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
            sw(pg,'whatsapp').click(); pg.wait_for_timeout(300)
            check('não deixa desligar os dois canais', est(pg)=={'painel':'false','whatsapp':'true'} and 'pelo menos um canal' in pg.locator('#rcbm').inner_text(), (est(pg),pg.locator('#rcbm').inner_text()))
            pg.reload(); entrega(pg)
            check('escolha persiste ao recarregar (só WhatsApp)', est(pg)=={'painel':'false','whatsapp':'true'}, est(pg))
            # pedido real: chega no WhatsApp, fica em Pedidos, sem notificação no painel
            n0=len(MSGS); r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID,'qtd':2}],'modo':'retirada','pagamento':'dinheiro','telefone':'21988887777','nome':'Carlos Cliente','idem':'b1'}); OID=r.json()['order']['id']
            pg.wait_for_timeout(800)
            txt=MSGS[-1]['text'] if len(MSGS)>n0 else ''
            check('pedido real chega no WhatsApp da empresa com itens, valores, cliente e retirada', len(MSGS)==n0+1 and MSGS[-1]['number']=='5511987654321' and f'#{OID}*' in txt and '2 × Pizza Margherita' in txt and 'R$ 105,80' in txt and 'Carlos Cliente' in txt and 'Retirada no local' in txt, txt[:300])
            nt=O.get('/api/notifications').json(); tem=any(f'#{OID}' in (i.get('title') or '') for i in nt.get('items',[]))
            check('com o painel desligado, nenhuma notificação do pedido', not tem)
            pg.reload(); entrega(pg)
            check('"Últimos envios" mostra o pedido como enviado', f'Pedido #{OID}' in pg.locator('[data-rcb-envios]').inner_text() and 'Enviado' in pg.locator('[data-rcb-envios]').inner_text())
            pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]',timeout=20000); pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector(f'[data-odet="{OID}"]',timeout=15000)
            stt=[x['status'] for x in O.get(f'/api/v2/ads/{BID}/orders').json()['items'] if x['id']==OID]
            check('o pedido continua em Pedidos, com status "novo" (nada concluído)', pg.locator(f'[data-odet="{OID}"]').count()==1 and stt==['novo'], stt)
            entrega(pg)
        ov=pg.evaluate("()=>document.documentElement.scrollWidth-innerWidth")
        check(f'{nome}: sem rolagem lateral', ov<=1, ov)
        pg.locator('[data-rcb-box]').scroll_into_view_if_needed(); pg.wait_for_timeout(200); pg.locator('[data-rcb-box]').screenshot(path=f'/tmp/receb_{nome}.png')
        if nome=='computador':
            sw(pg,'painel').click(); pg.wait_for_function("()=>/Salvo/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
            check('computador: religar o painel (os dois canais)', est(pg)=={'painel':'true','whatsapp':'true'})
            n0=len(MSGS); r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID,'qtd':1}],'modo':'retirada','pagamento':'dinheiro','telefone':'21988887777','nome':'Carlos Cliente','idem':'b2'}); OID2=r.json()['order']['id']; pg.wait_for_timeout(800)
            nt=O.get('/api/notifications').json()
            check('os dois canais: notificação no painel E uma mensagem no WhatsApp', len(MSGS)==n0+1 and f'#{OID2}*' in MSGS[-1]['text'] and sum(1 for i in nt.get('items',[]) if f'#{OID2}' in (i.get('title') or ''))==1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
srv.shutdown()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
