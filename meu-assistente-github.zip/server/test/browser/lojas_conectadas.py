# Catálogo público + login antes de finalizar (com retomada), Mensagem pronta e Lojas Conectadas, pela tela (celular).
# Servidor: PORT=4320 SQLITE_FILE=/tmp/ma-lc.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, urllib.parse, datetime, sqlite3
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4320'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
DIAS = {k: {'ativo': True, 'abre': '00:00', 'fecha': '23:59'} for k in ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom']}
N = lambda t: str(t).replace('\xa0', ' ')
MOB = {'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'base_url': BASE}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(**MOB); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Ana Central', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.lc@t.com', **U}).ok
    assert RA.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(R, empresa, zap):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': 'Varejo', 'titulo': 'x', 'texto': 'x', 'zap': zap, 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
        i = r.json()['items'][0]['id']; assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': DIAS}, 'pagamento': {'pix': True, 'chavePix': 'x@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True}}).ok; return i
    LA = loja(RA, 'Doceria da Ana', '5511999990000')
    assert RA.post(f'/api/v2/ads/{LA}/products', data={'nome': 'Bolo de Cenoura', 'preco': 45, 'fotos': [IMG]}).ok
    LS = loja(RA, 'Estúdio da Ana', '5511999990001')
    assert RA.post(f'/api/v2/ads/{LS}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
    rs = RA.post(f'/api/v2/ads/{LS}/products', data={'nome': 'Design de sobrancelha', 'preco': 60, 'tipo': 'servico', 'modoPreco': 'fixo', 'duracao': 30}); assert rs.ok, rs.text()
    # cliente com conta (usado no login de retomada)
    Cx = b.new_context(base_url=BASE); assert Cx.request.post('/api/auth', data={'action': 'signup', 'name': 'Rui Cliente', 'whatsapp': '+55 11 95555-0101', 'email': 'rui.lc@t.com', **U}, headers={'X-Forwarded-For': '10.7.7.7'}).ok; Cx.close()
    # ===== 3) mensagem pronta (dono) =====
    pa = A.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/x/sua-empresa'); pa.wait_for_timeout(1500)
    pa.click(f'[data-sel="{LA}"]'); pa.wait_for_timeout(1200); pa.wait_for_selector('.ma-nav [data-nav=mais]', timeout=10000)
    pa.click('.ma-nav [data-nav=mais]'); pa.wait_for_selector('[data-lt2=mensagem]', timeout=8000)
    check('Ajustes tem "Mensagem pronta" e "Lojas Conectadas"', pa.locator('[data-lt2=mensagem]').count() == 1 and pa.locator('[data-lt2=lojas]').count() == 1)
    pa.locator('[data-lt2=lojas]').scroll_into_view_if_needed(); pa.wait_for_timeout(300); pa.screenshot(path='/tmp/e2e/lc_ajustes.png')
    pa.click('[data-lt2=mensagem]'); pa.wait_for_selector('[data-msgcfg]', timeout=8000)
    check('começa desativada, com o texto e o botão padrão', pa.get_attribute('[data-sw="mp-ativo"]', 'aria-checked') == 'false' and 'Olá, {empresa}!' in pa.input_value('#mp_tx'))
    pa.click('[data-sw="mp-ativo"]'); pa.fill('#mp_bt', 'Pedir pelo WhatsApp'); pa.fill('#mp_tx', 'Oi, {empresa}! ')
    pa.click('[data-var=produto]'); pa.type('#mp_tx', ' ')
    pa.wait_for_timeout(150)
    check('variável inserida no cursor e prévia ao vivo', pa.input_value('#mp_tx') == 'Oi, {empresa}! {produto} ' and 'Oi, Doceria da Ana! Bolo de Cenoura' in pa.inner_text('[data-prev-prod]') and 'Pedir pelo WhatsApp' in pa.inner_text('[data-prev-botao]'), (pa.input_value('#mp_tx'), pa.inner_text('[data-prev-prod]')))
    pa.fill('#mp_tx', 'Oi, {empresa}! [Tenho interesse em {produto} ({preco}). ]Vi no catálogo: {link}'); pa.wait_for_timeout(100)
    check('prévia sem produto remove o trecho opcional', N(pa.inner_text('[data-prev-geral]')) == f'Oi, Doceria da Ana! Vi no catálogo: http://localhost:4320/x/empresa/{LA}' or N(pa.inner_text('[data-prev-geral]')).startswith('Oi, Doceria da Ana! Vi no catálogo: '), pa.inner_text('[data-prev-geral]'))
    pa.click('#mp_ok'); pa.wait_for_timeout(1200)
    check('salvou', RA.get(f'/api/v2/ads/{LA}/mensagem-pronta').json()['ativo'] is True)
    pa.screenshot(path='/tmp/e2e/lc_mensagem.png', full_page=True)
    # ===== 1) visitante sem conta no catálogo =====
    V = b.new_context(**MOB); pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e))); pv.on('dialog', lambda d: d.accept())
    pa.on('dialog', lambda d: d.accept())
    pv.goto(f'/x/empresa/{LA}'); pv.wait_for_selector('[data-prod]', timeout=20000); pv.wait_for_timeout(1500)
    check('visitante sem conta vê o catálogo (sem ir para /entrar)', '/x/empresa/' in pv.url and 'Bolo de Cenoura' in pv.inner_text('body'), pv.url)
    hz = pv.get_attribute('[data-msg-pronta=loja]', 'href') or ''
    msg = urllib.parse.unquote(hz.split('text=')[-1]) if 'text=' in hz else ''
    check('botão de mensagem pronta no catálogo abre o WhatsApp da loja com o texto (sem produto)', hz.startswith('https://wa.me/5511999990000?text=') and msg.startswith('Oi, Doceria da Ana! Vi no catálogo: ') and 'Tenho interesse' not in msg and 'Pedir pelo WhatsApp' in pv.inner_text('[data-msg-pronta=loja]'), msg)
    pv.click('[data-prod]'); pv.wait_for_selector('[data-detalhe] [data-msg-pronta]', timeout=8000)
    m2 = urllib.parse.unquote(pv.get_attribute('[data-detalhe] [data-msg-pronta]', 'href').split('text=')[-1])
    check('no detalhe: produto e preço na mensagem', 'Tenho interesse em Bolo de Cenoura (R$ 45,00).' in N(m2), m2)
    pv.screenshot(path='/tmp/e2e/lc_visitante_detalhe.png')
    pv.click('#padd'); pv.wait_for_timeout(400)
    pv.locator('button:has-text("Ver pedido")').click(); pv.wait_for_selector('[data-pedir-conta]', timeout=8000)
    t = pv.inner_text('[data-pedir-conta]')
    check('finalizar sem conta: opções "Entrar na minha conta" e "Criar minha conta gratuitamente"', 'Entrar na minha conta' in t and 'Criar minha conta gratuitamente' in t)
    nxt = urllib.parse.quote(f'/x/empresa/{LA}?retomar=checkout', safe='')
    check('os dois caminhos voltam para a finalização', pv.get_attribute('[data-conta=entrar]', 'href') == f'/entrar?next={nxt}' and pv.get_attribute('[data-conta=criar]', 'href') == f'/cadastro?next={nxt}')
    pv.screenshot(path='/tmp/e2e/lc_pedir_conta.png')
    pv.click('[data-conta=entrar]'); pv.wait_for_selector('input[type=password]', timeout=15000)
    pv.fill('input[type=email]', 'rui.lc@t.com'); pv.fill('input[type=password]', 'Senha@Forte123'); pv.locator('button[type=submit]').first.click()
    pv.wait_for_selector('[data-checkout]', timeout=20000); pv.wait_for_timeout(600)
    ck = N(pv.inner_text('[data-checkout]'))
    check('depois de entrar, volta direto à finalização com o carrinho preservado', f'/x/empresa/{LA}' in pv.url and '1× Bolo de Cenoura' in ck and 'R$ 45,00' in ck, (pv.url, ck[:200]))
    pv.screenshot(path='/tmp/e2e/lc_retomou_checkout.png')
    pv.click('#cgo'); pv.wait_for_timeout(2500)
    oz = V.request.get('/api/v2/orders/mine').json()['items']
    check('pedido finalizado com a conta', len(oz) == 1 and oz[0]['itens'][0]['nome'] == 'Bolo de Cenoura')
    # criar conta pelo carrinho: volta à finalização com o carrinho
    V3 = b.new_context(**MOB); pz = V3.new_page(); pz.on('pageerror', lambda e: errs.append(str(e)))
    pz.goto(f'/x/empresa/{LA}'); pz.wait_for_selector('[data-add]', timeout=20000); pz.wait_for_timeout(1200)
    pz.locator('[data-add]').first.click(); pz.wait_for_timeout(300); pz.locator('button:has-text("Ver pedido")').click(); pz.wait_for_selector('[data-conta=criar]', timeout=8000)
    pz.click('[data-conta=criar]'); pz.wait_for_selector('input[type=password]', timeout=15000)
    ins = pz.locator('input'); ins.nth(0).fill('Lia Nova'); ins.nth(1).fill('+55 11 97777-0202'); ins.nth(2).fill('lia.lc@t.com'); ins.nth(3).fill('1992-03-04'); ins.nth(4).fill('Senha@Forte123'); ins.nth(5).fill('Senha@Forte123')
    pz.locator('button[type=submit]').first.click(); pz.wait_for_selector('[data-checkout]', timeout=20000); pz.wait_for_timeout(500)
    check('criar conta gratuitamente também volta à finalização com o carrinho', f'/x/empresa/{LA}' in pz.url and '1× Bolo de Cenoura' in N(pz.inner_text('[data-checkout]')), pz.url)
    # agendamento: escolhas preservadas
    V2 = b.new_context(**MOB); pw = V2.new_page(); pw.on('pageerror', lambda e: errs.append(str(e)))
    pw.goto(f'/x/empresa/{LS}'); pw.wait_for_selector('[data-book],[data-det]', timeout=20000); pw.wait_for_timeout(1200)
    pw.locator('[data-book]').first.click(); pw.wait_for_selector('[data-dia]', timeout=8000)
    for k in range(2, 6):  # primeiro dia com horários livres (não depende da hora em que o teste roda)
        pw.locator('[data-dia]').nth(k).click(); pw.wait_for_timeout(1200)
        if pw.locator('[data-h]').count(): break
    dia = pw.locator('[data-dia].btn-send').get_attribute('data-dia'); hora = pw.locator('[data-h]').first.get_attribute('data-h'); pw.locator('[data-h]').first.click()
    pw.fill('#bobs', 'Primeira vez'); pw.click('#bgo'); pw.wait_for_selector('[data-pedir-conta]', timeout=8000)
    check('confirmar agendamento sem conta pede para entrar ou criar conta', 'Falta só entrar para agendar' in pw.inner_text('[data-pedir-conta]'))
    pw.click('[data-conta=entrar]'); pw.wait_for_selector('input[type=password]', timeout=15000)
    pw.fill('input[type=email]', 'rui.lc@t.com'); pw.fill('input[type=password]', 'Senha@Forte123'); pw.locator('button[type=submit]').first.click()
    pw.wait_for_selector('#bgo', timeout=20000); pw.wait_for_timeout(1500)
    check('depois de entrar, volta ao agendamento com dia, horário e observação', pw.locator(f'[data-dia="{dia}"].btn-send').count() == 1 and pw.locator(f'[data-h="{hora}"].btn-send').count() == 1 and pw.input_value('#bobs') == 'Primeira vez' and not pw.locator('#bgo').is_disabled(), (dia, hora, pw.input_value('#bobs')))
    pw.click('#bgo'); pw.wait_for_timeout(2500)
    ag = [o for o in V2.request.get('/api/v2/orders/mine').json()['items'] if o.get('tipo') == 'agendamento']
    check('agendamento criado com as escolhas preservadas', ag and ag[0]['data'] == dia and ag[0]['hora'] == hora and ag[0]['obs'] == 'Primeira vez', ag and (ag[0]['data'], ag[0]['hora'], ag[0].get('obs')))
    # ===== 4) Lojas Conectadas =====
    B_ = b.new_context(**MOB); RB = B_.request
    assert RB.post('/api/auth', data={'action': 'signup', 'name': 'Beto Loja', 'whatsapp': '+55 11 96666-0101', 'email': 'beto.lc@t.com', **U}, headers={'X-Forwarded-For': '10.8.8.8'}).ok
    r = RB.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Mercadinho do Beto', 'categoria': 'Varejo', 'titulo': 'x', 'texto': 'x', 'zap': '5511988880000', 'endereco': 'Rua B, 20'}); assert r.ok, r.text(); LB = r.json()['items'][0]['id']
    db = sqlite3.connect('/tmp/ma-lc.db'); db.execute("update businesses set status='ativo', expires_at=? where id=?", ((datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z', LB)); db.commit(); db.close()
    assert RB.put(f'/api/v2/ads/{LB}', data={'horarioCfg': {'modo': 'aberto', 'dias': DIAS}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
    assert RB.post(f'/api/v2/ads/{LB}/products', data={'nome': 'Café 500g', 'preco': 22, 'fotos': [IMG]}).ok
    pa.goto('/x/lojas-conectadas?aba=conexoes'); pa.wait_for_selector('#lc_gerar', timeout=15000)
    pa.select_option('#lc_h', '72'); pa.click('#lc_gerar'); pa.wait_for_selector('[data-chave]', timeout=8000)
    chave = pa.inner_text('[data-chave]').strip()
    check('central gera chave exclusiva e mostra uma única vez', chave.startswith('MA-') and len(chave) == 22 and 'não aparece de novo' in pa.inner_text('[data-nova-chave]'), chave)
    pa.screenshot(path='/tmp/e2e/lc_chave.png', full_page=True)
    pb = B_.new_page(); pb.on('pageerror', lambda e: errs.append(str(e)))
    pb.goto('/x/lojas-conectadas?aba=conexoes'); pb.wait_for_selector('#lc_con', timeout=15000); pb.wait_for_load_state('networkidle'); pb.wait_for_timeout(800)
    pb.fill('#lc_chave', 'MA-AAAA-BBBB-CCCC-DDDD'); pb.click('#lc_con'); pb.wait_for_timeout(800)
    check('chave errada: mensagem clara', 'Chave não encontrada' in pb.inner_text('#lc_er'), pb.inner_text('#lc_er'))
    pb.fill('#lc_chave', chave.lower()); pb.select_option('#lc_papel', 'operador'); pb.click('#lc_con'); pb.wait_for_timeout(1500)
    check('dono da outra loja envia o pedido de conexão (aguardando aprovação)', 'Aguardando aprovação' in pb.inner_text('body') and 'Mercadinho do Beto' in pb.inner_text('body'))
    pa.goto('/x/lojas-conectadas?aba=conexoes'); pa.wait_for_selector('[data-cacao=aceitar]', timeout=15000)
    pa.click('[data-cacao=aceitar]'); pa.wait_for_timeout(1500)
    check('central aceita e a loja aparece como conectada', 'Conectada' in pa.inner_text('body'))
    oid = None
    cli = b.new_context(base_url=BASE); assert cli.request.post('/api/auth', data={'action': 'login', 'email': 'rui.lc@t.com', 'password': 'Senha@Forte123'}).ok
    pid = RB.get(f'/api/v2/ads/{LB}/products').json()['items'][0]['id']
    r = cli.request.post(f'/api/v2/businesses/{LB}/orders', data={'itens': [{'pid': pid, 'qtd': 2}], 'modo': 'retirada', 'pagamento': 'dinheiro'}); assert r.ok, r.text(); oid = r.json()['order']['id']
    pa.goto('/x/lojas-conectadas'); pa.wait_for_selector('[data-loja]', timeout=15000); pa.wait_for_timeout(500)
    cards = pa.locator('[data-loja]'); tb = N(pa.locator(f'[data-loja="{LB}"]').inner_text())
    check('visão geral: lojas próprias e conectada, com nível, situação e pendentes', cards.count() == 3 and 'Operador' in tb and 'Pedidos pendentes 1' in tb and 'No ar' in tb and 'Proprietário' in pa.locator(f'[data-loja="{LA}"]').inner_text(), tb)
    pa.screenshot(path='/tmp/e2e/lc_central.png', full_page=True)
    pa.locator(f'[data-abrir="{LB}"]').click(); pa.wait_for_selector(f'[data-ped="{oid}"]', timeout=10000)
    pt = pa.locator(f'[data-ped="{oid}"]')
    check('pedido da loja conectada identifica a loja de origem; operador só aceita', 'Mercadinho do Beto' in pt.inner_text() and pt.locator('[data-st]').count() == 1 and pt.locator('[data-st=aceito]').count() == 1, pt.inner_text())
    pt.locator('[data-st=aceito]').click(); pa.wait_for_timeout(1500)
    check('aceitar pela central muda o pedido na loja de origem', RB.get(f'/api/v2/ads/{LB}/orders').json()['items'][0]['status'] == 'aceito')
    pa.locator('[data-aba=avisos]').click(); pa.wait_for_selector('[data-av]', timeout=10000)
    av = pa.inner_text('body')
    check('avisos: "Novo pedido … — Mercadinho do Beto" com a loja de origem', f'Novo pedido #{oid}' in av and '— Mercadinho do Beto' in av, av[:400])
    pa.locator('[data-av]', has_text=f'Novo pedido #{oid}').first.click(); pa.wait_for_selector(f'[data-ped="{oid}"]', timeout=10000)
    check('tocar no aviso abre o registro na loja de origem', 'ring-2' in pa.get_attribute(f'[data-ped="{oid}"]', 'class') and 'loja=' in pa.url, pa.url)
    nb = RB.get('/api/notifications').json(); nbt = str(nb)
    check('dono da loja foi avisado da mudança feita pela central', f'Pedido #{oid} atualizado: aceito' in nbt)
    check('sem rolagem horizontal (catálogo e central)', pv.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and pa.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
