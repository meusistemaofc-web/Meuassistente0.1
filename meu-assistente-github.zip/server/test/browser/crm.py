import json, sys, base64, zlib, struct, sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1100},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':['data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==']}); assert rp.ok, rp.text()
    # cliente em outro contexto
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Moeda','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    BZ=f'/api/v2/businesses/{ID}/crm'
    # cliente faz um pedido antes de o CRM ser aberto: deve aparecer sozinho como cliente
    pid=R.get(f'/api/v2/ads/{ID}/products').json()['items'][0]['id']
    o=cc.request.post(f'/api/v2/businesses/{ID}/orders',data={'itens':[{'pid':pid,'qtd':1,'escolhas':{}}],'modo':'retirada','pagamento':'dinheiro','telefone':'(11) 96666-5555'}); assert o.ok,o.text()
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    check('Sua empresa > Ajustes tem a opção "CRM"', pg.locator('button:has-text("CRM")').count()>=1)
    pg.locator('button:has-text("CRM")').first.click(); pg.wait_for_selector('[data-ca=visao]',timeout=10000); pg.wait_for_timeout(800)
    t=pg.inner_text('body')
    check('visão geral mostra os 9 indicadores', all(x in t for x in ['Total de clientes','Novos leads','Leads em negociação','Oportunidades abertas','Negociações concluídas','Negociações perdidas','Taxa de conversão','Valor das oportunidades','Próximos acompanhamentos']), t[:400])
    check('funil padrão com 8 etapas na visão geral', all(x in t for x in ['Novo lead','Primeiro contato','Em atendimento','Em negociação','Proposta enviada','Aguardando decisão','Venda concluída','Negociação perdida']))
    pg.screenshot(path='/tmp/e2e/crm_visao.png',full_page=True)
    # clientes
    pg.click('[data-ca=clientes]'); pg.wait_for_selector('#cl_list [data-c]',timeout=8000)
    check('cliente com pedido apareceu automaticamente (sem cadastro manual)', 'Cliente Moeda' in pg.inner_text('#cl_list') and '1 pedido' in pg.inner_text('#cl_list'), pg.inner_text('#cl_list'))
    pg.click('#cl_new'); pg.wait_for_selector('#cc_n'); pg.fill('#cc_n','Marina Souza'); pg.fill('#cc_t','(11) 98888-7766'); pg.fill('#cc_e','marina@mail.com'); pg.fill('#cc_tg','festa, vip'); pg.fill('#cc_ob','Pediu orçamento de buffet'); pg.click('#cc_go')
    pg.wait_for_selector('#pf_b',timeout=8000); pg.wait_for_timeout(500)
    check('lead criado abre a ficha completa', 'Marina Souza' in pg.inner_text('body') and 'Lead' in pg.inner_text('body') and 'festa' in pg.inner_text('body'))
    pg.click('#pf_b'); pg.wait_for_selector('#cl_list [data-c]'); pg.click('#cl_new'); pg.wait_for_selector('#cc_n'); pg.fill('#cc_n','Marina S.'); pg.fill('#cc_t','+55 11 988887766'); pg.click('#cc_go'); pg.wait_for_selector('#pf_b',timeout=8000); pg.wait_for_timeout(400)
    n=len([c for c in R.get(BZ+'/contacts?q=Marina').json()['contatos']])
    check('cadastro repetido com variação de telefone reaproveita o mesmo contato', n==1, n)
    # interação e observação
    pg.select_option('#pf_k','interacao'); pg.select_option('#pf_c','whatsapp'); pg.fill('#pf_x','Combinei o orçamento por WhatsApp'); pg.click('#pf_r'); pg.wait_for_selector('text=Combinei o orçamento por WhatsApp',timeout=8000)
    check('interação aparece na linha do tempo', 'Interação · whatsapp' in pg.inner_text('body'))
    # oportunidade pela ficha
    pg.click('#pf_o'); pg.wait_for_selector('#of_t'); pg.fill('#of_t','Buffet Marina'); pg.fill('#of_v','2500'); pg.fill('#of_d','2099-03-01'); pg.click('#of_go'); pg.wait_for_selector('[data-po]',timeout=8000); pg.wait_for_timeout(400)
    check('oportunidade criada na ficha do cliente', 'Buffet Marina' in pg.inner_text('body') and 'Novo lead' in pg.inner_text('body'))
    # tarefa
    pg.click('#pf_t'); pg.wait_for_selector('#tf_t'); pg.fill('#tf_t','Retornar ligação'); pg.select_option('#tf_k','retorno'); pg.select_option('#tf_p','alta'); pg.fill('#tf_d','2099-02-01'); pg.click('#tf_go'); pg.wait_for_selector('[data-tdone]',timeout=8000)
    check('tarefa criada e visível na ficha', 'Retornar ligação' in pg.inner_text('#pf_tk') and 'Alta' in pg.inner_text('#pf_tk'))
    # funil
    pg.click('[data-ca=funil]'); pg.wait_for_selector('[data-mv]',timeout=8000)
    check('funil visual em colunas com a oportunidade em "Novo lead"', pg.locator('#fn_cols > div').count()==8 and 'Buffet Marina' in pg.inner_text('#fn_cols > div:first-child'))
    pg.locator('[data-mv]').first.select_option(label='Em negociação'); pg.wait_for_timeout(1200)
    check('mover a oportunidade entre etapas', 'Buffet Marina' in pg.inner_text('#fn_cols > div:nth-child(4)'), pg.inner_text('#fn_cols'))
    pg.screenshot(path='/tmp/e2e/crm_funil.png',full_page=True)
    pg.locator('[data-mv]').first.select_option(label='Negociação perdida'); pg.wait_for_selector('#lp_m',timeout=5000); pg.click('#lp_go'); pg.wait_for_timeout(300)
    check('perda exige motivo', 'Informe o motivo' in pg.inner_text('#lp_er') if pg.locator('#lp_er').count() else False)
    pg.fill('#lp_m','Preço acima do orçamento'); pg.click('#lp_go'); pg.wait_for_timeout(1200)
    check('perda registrada com o motivo', 'Preço acima do orçamento' in pg.inner_text('#fn_cols > div:nth-child(8)'), pg.inner_text('#fn_cols'))
    # oportunidades
    pg.click('[data-ca=opps]'); pg.wait_for_selector('[data-os]'); pg.click('[data-os=perdida]'); pg.wait_for_selector('[data-po]',timeout=8000)
    pg.click('[data-po]'); pg.wait_for_selector('#os_go'); check('detalhe da oportunidade mostra o histórico de alterações', 'Etapa:' in pg.inner_text('.ma-sheet-in') and 'Novo lead → Em negociação' in pg.inner_text('.ma-sheet-in'), pg.inner_text('.ma-sheet-in')[:400]); pg.keyboard.press('Escape'); pg.evaluate("()=>{const x=document.querySelector('.ma-sheet-x');if(x)x.click()}")
    # tarefas
    pg.click('[data-ca=tarefas]'); pg.wait_for_selector('[data-tdone]',timeout=8000); pg.click('[data-tdone]'); pg.wait_for_timeout(1000)
    check('concluir tarefa tira da lista de abertas', pg.locator('[data-tdone]').count()==0)
    # visão geral atualizada com dados reais
    pg.click('[data-ca=visao]'); pg.wait_for_timeout(1200)
    ind=R.get(BZ+'/overview').json()['indicadores']
    check('indicadores refletem os dados reais', ind['negociacoesPerdidas']==1 and ind['totalClientes']>=1 and ind['novosLeads']>=1, ind)
    check('taxa de conversão exibida', '0%' in pg.inner_text('body'))
    # inteligência e configurações
    pg.click('[data-ca=insights]'); pg.wait_for_selector('text=Motivos frequentes de perda',timeout=8000)
    check('inteligência mostra o motivo da perda com critério', 'preço acima do orçamento' in pg.inner_text('body').lower())
    pg.click('[data-ca=config]'); pg.wait_for_selector('#ne_go',timeout=8000)
    pg.fill('#ne_n','Degustação'); pg.click('#ne_go'); pg.wait_for_timeout(1200)
    check('etapa personalizada criada nas configurações', 'Degustação' in pg.inner_text('body') or pg.locator('input[data-sn][value="Degustação"]').count()==1)
    pg.fill('#lb_e','vip gold'); pg.click('[data-lb=etiqueta]'); pg.wait_for_timeout(1000)
    check('etiqueta personalizada criada', 'vip gold' in pg.inner_text('body'))
    pg.locator('[data-sw=iaMoverEtapas]').click(); pg.wait_for_timeout(1000)
    check('permissão do chat para mover etapas pode ser desligada', R.get(BZ+'/config').json()['config']['iaMoverEtapas'] is False)
    # mobile: sem rolagem lateral da página
    pg.set_viewport_size({'width':360,'height':800}); pg.click('[data-ca=funil]'); pg.wait_for_selector('#fn_cols'); pg.wait_for_timeout(600)
    ov=pg.evaluate("()=>({page:document.documentElement.scrollWidth<=window.innerWidth+1,cols:document.querySelector('#fn_cols').scrollWidth>document.querySelector('#fn_cols').clientWidth})")
    check('celular: funil rola dentro do quadro e a página não ganha rolagem lateral', ov['page'] and ov['cols'], ov)
    pg.screenshot(path='/tmp/e2e/crm_mobile.png',full_page=False)
    # isolamento pela interface: outro usuário não vê o CRM desta empresa
    oc=cc.request.get(BZ+'/overview'); check('outro usuário não acessa o CRM da empresa', oc.status in (403,404), oc.status)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
