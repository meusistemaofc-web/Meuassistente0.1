# Motor de respostas do chat (tela real): modo explicativo e idioma inteligente.
# • "como registro um gasto?" → passos curtos com negrito e lista, botão "Abrir Financeiro" (sem ⟦ ⟧, JSON ou nomes técnicos),
#   nada é registrado; os passos conferem com as telas de verdade (menu → Financeiro → + Adicionar → Novo lançamento → Gasto;
#   Compromissos → + Compromisso; Lembretes → + Lembrete);
# • "sim" depois da oferta pede os dados; a mensagem seguinte registra de verdade;
# • "sempre me responda em inglês" → confirmação em inglês e preferência salva na memória; em OUTRA conversa, o chat responde em
#   inglês e traduz as respostas internas (botões preservados); "responda no idioma em que eu escrever" volta ao normal;
# • celular (390 px) e computador, sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4336 SQLITE_FILE=/tmp/ma-idg.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4336'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE)
    assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1235', 'email': 'admin.idg@t.com', **U}).ok
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Clara Teste', 'whatsapp': f'+55 11 96666-{k}{k}{k}{k}', 'email': f'clara{k}.idg@t.com', **U}, headers={'X-Forwarded-For': f'10.9.1.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        ultima = lambda: pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();if(!b)return '';const p=b.querySelector('[data-ma-tokp]')||b.querySelector('p');return p?p.innerText:b.innerText}")
        ultimaEl = lambda: pg.locator('.chat-scroll .msg-bubble').last
        def enviar(t):
            n0 = pg.locator('.chat-scroll .msg-bubble').count()
            pg.fill('textarea.composer-input', t); pg.keyboard.press('Enter')
            try: pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=15000)
            except Exception: pass
            pg.wait_for_timeout(1200)
        itens = lambda: R.get('/api/finance').json() if False else None
        # 1) explicação: passos com telas reais e botão, nada executado
        enviar('como registro um gasto?'); t = N(ultima())
        box = pg.locator('.chat-scroll .msg-bubble').last.locator('xpath=..')
        btn = pg.locator('.chat-scroll a[href="/financeiro"]').last
        check(f'{nome}: "como registro um gasto?" → passos curtos e numerados', t.startswith('Para registrar um gasto:') and '1. Toque em “Abrir Financeiro” aqui embaixo, ou abra o menu ☰ → Módulos → Financeiro.' in t and '2. Toque em + Adicionar e escolha Gasto' in t and 'gastei 35 no almoço' in t and 'Quer que eu registre um agora?' in t, t)
        check(f'{nome}: sem asteriscos de markdown e botão "Abrir Financeiro"', '**' not in N(pg.inner_text('.chat-scroll')) and btn.count() == 1 and N(btn.inner_text()) == 'Abrir Financeiro', ultimaEl().inner_html()[:300])
        check(f'{nome}: sem marcadores, JSON ou nomes técnicos na tela', not re.search(r'⟦|⟧|[{}]|register_transaction|create_|tool', N(pg.inner_text('.chat-scroll'))), N(pg.inner_text('.chat-scroll'))[-300:])
        if mob: pg.screenshot(path='/tmp/e2e/guia_chat_celular.png')
        # 2) "sim" pede os dados; o pedido seguinte executa
        enviar('sim'); check(f'{nome}: "sim" depois da oferta pede valor e descrição', N(ultima()) == 'Certo! Me diga o valor e com o que foi, por exemplo: “gastei 35 no almoço”.', ultima())
        enviar('gastei 42 no almoço'); check(f'{nome}: o gasto é registrado de verdade depois', re.search(r'Gasto registrado|registrei', ultima()), ultima())
        # 3) outras explicações: compromisso e lembrete
        enviar('como agendo um compromisso?'); t = N(ultima()); check(f'{nome}: compromisso → + Compromisso e botão Abrir Compromissos', '+ Compromisso' in t and pg.locator('.chat-scroll a[href="/agenda?tab=compromissos"]').count() >= 1, t)
        # 4) idioma: preferência permanente, em outra conversa e traduzindo respostas internas
        enviar('sempre me responda em inglês')
        check(f'{nome}: confirmação no idioma pedido', N(ultima()) == "Got it! From now on I'll always reply in English, in every conversation. Just ask if you want to change it.", ultima())
        mem = R.get('/api/memory').json(); check(f'{nome}: preferência salva na Memória do assistente', 'Prefere que eu responda sempre em inglês' in str(mem), str(mem)[:200])
        cv2 = 'f0f0f0f0-1234-4abc-8def-00000000000' + str(k)
        r2 = R.post('/api/chat', data={'text': 'como crio um lembrete?', 'conversationId': cv2}).json()['assistantMessage']['content']
        check(f'{nome}: em outra conversa, a explicação vem traduzida com o botão preservado', r2.startswith('[en] Para criar um lembrete:') and '⟦btn:/agenda?tab=lembretes|[en] Abrir Lembretes⟧' in r2, r2[:200])
        enviar('oi, tudo bem?'); check(f'{nome}: português na tela, resposta em inglês (preferência)', N(ultima()) == 'Hello! How can I help you?', ultima())
        enviar('como crio um lembrete?'); bl = pg.locator('.chat-scroll a[href="/agenda?tab=lembretes"]').last
        check(f'{nome}: explicação traduzida na tela, botão com rótulo traduzido', N(ultima()).startswith('[en] Para criar um lembrete') and bl.count() == 1 and N(bl.inner_text()) == '[en] Abrir Lembretes', (ultima()[:120], bl.count()))
        if mob: pg.screenshot(path='/tmp/e2e/idioma_chat_celular.png')
        enviar('responda no idioma em que eu escrever')
        check(f'{nome}: apagar a preferência', N(ultima()) == 'Certo! Não tenho mais um idioma fixo: vou responder no idioma em que você escrever.' and 'Prefere que eu responda sempre em inglês' not in str([m for m in R.get('/api/memory').json().get('memories', []) if m.get('active', True)]), ultima())
        enviar('how do I create a task?'); check(f'{nome}: mensagem em inglês → explicação em inglês', N(ultima()).startswith('[en] Para criar uma tarefa'), ultima())
        enviar('como crio uma tarefa?'); check(f'{nome}: mensagem em português → português', N(ultima()).startswith('Para criar uma tarefa:'), ultima())
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        # 5) os passos conferem com as telas reais
        if not mob:
            def sem_aviso():
                pg.wait_for_timeout(800)
                if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(600)
            pg.goto('/'); sem_aviso(); pg.wait_for_selector('[aria-label="Abrir menu"]', timeout=15000); pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(900)
            nav = N(pg.inner_text('nav'))
            check('menu: itens do topo citados nos passos (NO_MENU)', all(x in nav for x in ['Empresas perto de você', 'Meus pedidos', 'Mercado', 'Impostos e DAS', 'Meu plano', 'Anunciar minha empresa', 'Notificações', 'Módulos']), nav[:400])
            pg.locator('nav').get_by_text('Módulos', exact=True).last.click(); pg.wait_for_timeout(700); nav = N(pg.inner_text('nav'))
            check('menu → Módulos tem Financeiro, Lembretes, Compras, Anotações e "Organizar módulos" (NA_PASTA / FORA_DO_MENU)', all(x in nav for x in ['Financeiro', 'Lembretes', 'Compras', 'Anotações', 'Organizar módulos']), nav[:300])
            pg.screenshot(path='/tmp/e2e/guia_menu_modulos.png')
            # o botão da explicação abre a tela exata
            pg.goto('/'); sem_aviso(); pg.fill('textarea.composer-input', 'como registro um gasto?'); pg.keyboard.press('Enter'); pg.wait_for_selector('.chat-scroll a[href="/financeiro"]', timeout=15000); pg.locator('.chat-scroll a[href="/financeiro"]').last.click(); pg.wait_for_timeout(1500)
            check('botão “Abrir Financeiro” da explicação abre o Financeiro', '/financeiro' in pg.url, pg.url)
            pg.goto('/financeiro'); sem_aviso(); pg.wait_for_selector('button:has-text("Adicionar")', timeout=15000); pg.click('button:has-text("Adicionar")'); pg.wait_for_timeout(600)
            check('Financeiro → + Adicionar abre "Novo lançamento" com Gasto e Receita', 'Novo lançamento' in N(pg.inner_text('body')) and pg.locator('text=Gasto').count() >= 1 and pg.locator('text=Receita').count() >= 1)
            pg.goto('/agenda?tab=compromissos'); sem_aviso(); bt = pg.get_by_role('button', name='Compromisso', exact=True); bt.wait_for(timeout=15000); bt.click(); pg.wait_for_timeout(500)
            check('Compromissos → + Compromisso abre "Novo compromisso"', 'Novo compromisso' in N(pg.inner_text('body')))
            pg.goto('/agenda?tab=lembretes'); sem_aviso(); bt = pg.get_by_role('button', name='Lembrete', exact=True); bt.wait_for(timeout=15000); bt.click(); pg.wait_for_timeout(500)
            check('Lembretes → + Lembrete abre "Novo lembrete"', 'Novo lembrete' in N(pg.inner_text('body')))
            pg.goto('/agenda?tab=tarefas'); sem_aviso(); pg.wait_for_timeout(1000); check('Tarefas tem o campo "Nova tarefa…"', pg.locator('input[placeholder="Nova tarefa…"]').count() == 1)
        C.close()
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
