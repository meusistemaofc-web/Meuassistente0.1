import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
SOBRE=' '.join(['Somos uma pizzaria artesanal com massa de longa fermentação e ingredientes selecionados todos os dias.']*6)
LONGA=' '.join(['Massa fina, molho caseiro, queijo muçarela de búfala e manjericão fresco colhido na hora.']*4)
CURTA='Massa fina e queijo.'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':SOBRE,'zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'sobre':SOBRE,'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    for nome,cat,desc in [('Pizza Longa A','Pizzas',LONGA),('Pizza Longa B','Pizzas',LONGA),('Pizza Curta','Pizzas',CURTA),('Refri','Bebidas','Gelado.')]:
        assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':nome,'preco':40,'categoria':cat,'tipo':'produto','descricao':desc,'fotos':[IMG]}).ok
    SOBRE_API=R.get(f'/api/v2/businesses/{ID}').json()['sobre']
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'/x/empresa/{ID}'); pg.wait_for_function("()=>document.querySelectorAll('.ma-xd').length>=4",timeout=15000); pg.wait_for_timeout(1200); pg.wait_for_function("()=>document.querySelectorAll('.ma-xd').length>=4",timeout=15000)
        H=lambda sel: pg.evaluate("(s)=>{const t=document.querySelector(s);return t?Math.round(t.getBoundingClientRect().height):-1}",sel)
        lh=lambda sel: pg.evaluate("(s)=>parseFloat(getComputedStyle(document.querySelector(s)).lineHeight)",sel)
        emp='.ma-xd[data-xk$=":emp"]'
        he=H(emp+' .ma-xd-t'); l=lh(emp+' .ma-xd-t')
        check(f'{nome}: descrição da empresa limitada a 3 linhas', abs(he-3*l)<=3, (he,l))
        check(f'{nome}: seta aparece na empresa', pg.locator(emp+' .ma-xd-b').is_visible())
        full=pg.evaluate("(s)=>document.querySelector(s).textContent",emp+' .ma-xd-t')
        check(f'{nome}: texto original completo no DOM (nada cortado)', full.strip()==SOBRE_API and len(SOBRE_API)>300, (len(full),len(SOBRE_API)))
        pg.click(emp+' .ma-xd-b'); pg.wait_for_timeout(600)
        he2=H(emp+' .ma-xd-t'); check(f'{nome}: clicar expande a empresa', he2>he+20, (he,he2))
        check(f'{nome}: seta indica estado (aria-expanded)', pg.get_attribute(emp+' .ma-xd-b','aria-expanded')=='true')
        pg.screenshot(path=f'/tmp/e2e/descricoes_{nome}.png')
        pg.click(emp+' .ma-xd-b'); pg.wait_for_timeout(600)
        check(f'{nome}: clicar de novo recolhe', abs(H(emp+' .ma-xd-t')-he)<=2)
        # produtos
        prods=pg.locator('.ma-xd:not([data-xk$=":emp"])')
        n=prods.count(); check(f'{nome}: um bloco de descrição por produto da categoria (3)', n==3, n)
        vis=[prods.nth(i).locator('.ma-xd-b').is_visible() for i in range(n)]
        check(f'{nome}: seta só nas descrições longas', vis==[True,True,False], vis)
        pl=pg.evaluate("()=>{const t=document.querySelector('.ma-xd:not([data-xk$=\":emp\"]) .ma-xd-t');return [Math.round(t.getBoundingClientRect().height),parseFloat(getComputedStyle(t).lineHeight)]}")
        check(f'{nome}: produto limitado a 2 linhas', abs(pl[0]-2*pl[1])<=3, pl)
        sheet_before=pg.locator('[role=dialog],.ma-sheet').count()
        prods.nth(0).locator('.ma-xd-b').click(); pg.wait_for_timeout(600)
        h0=prods.nth(0).locator('.ma-xd-t').evaluate('e=>e.getBoundingClientRect().height'); h1=prods.nth(1).locator('.ma-xd-t').evaluate('e=>e.getBoundingClientRect().height')
        check(f'{nome}: expandir um produto não expande o outro', h0>h1+15, (h0,h1))
        check(f'{nome}: clicar na seta não abre o produto', pg.locator('[role=dialog],.ma-sheet').count()==sheet_before)
        # estado preservado ao trocar de categoria e voltar
        pg.locator('[data-cat="Bebidas"]').click(); pg.wait_for_timeout(300); pg.locator('[data-cat="Pizzas"]').click(); pg.wait_for_timeout(600)
        prods=pg.locator('.ma-xd:not([data-xk$=":emp"])')
        h0=prods.nth(0).locator('.ma-xd-t').evaluate('e=>e.getBoundingClientRect().height'); h1=prods.nth(1).locator('.ma-xd-t').evaluate('e=>e.getBoundingClientRect().height')
        check(f'{nome}: estado de cada item preservado ao navegar', h0>h1+15, (h0,h1))
        # botão de compra continua funcionando
        pg.locator('[data-add]').first.click(); pg.wait_for_timeout(500)
        check(f'{nome}: botão de compra continua funcionando', pg.locator('[data-cart],#cartbar,:text("carrinho")').count()>0 or pg.locator('text=/R\\$\\s?40/').count()>0)
        # abrir o produto pelo restante do cartão ainda funciona
        pg.locator('[data-prod]').first.locator('.block.text-\\[15\\.5px\\]').first.click(); pg.wait_for_timeout(700)
        check(f'{nome}: clicar no produto ainda abre os detalhes', pg.locator('[data-add-sheet],[role=dialog],.ma-sheet').count()>sheet_before or 'Pizza Longa A' in pg.inner_text('body'))
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
