import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
SOBRE='Somos uma pizzaria artesanal com massa de longa fermentação e ingredientes selecionados todos os dias. Forno a lenha e entrega rápida no bairro.'  # descrição da empresa: até 200 caracteres
LONGA=' '.join(['Massa fina, molho caseiro, queijo muçarela de búfala e manjericão fresco colhido na hora.']*4)
CURTA='Massa fina e queijo.'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':SOBRE,'zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'sobre':SOBRE,'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    for nome,cat,desc in [('Pizza Longa A','Pizzas',LONGA),('Pizza Longa B','Pizzas',LONGA),('Pizza Curta','Pizzas',CURTA),('Refri','Bebidas','Gelado.')]:
        assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':nome,'preco':40,'categoria':cat,'tipo':'produto','descricao':desc,'fotos':[IMG]}).ok
    SOBRE_API=R.get(f'/api/v2/businesses/{ID}').json()['sobre']
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'/x/empresa/{ID}'); pg.wait_for_function("()=>document.querySelectorAll('[data-prod]').length>=1",timeout=15000); pg.wait_for_timeout(1200)
        H=lambda sel: pg.evaluate("(s)=>{const t=document.querySelector(s);return t?Math.round(t.getBoundingClientRect().height):-1}",sel)
        lh=lambda sel: pg.evaluate("(s)=>parseFloat(getComputedStyle(document.querySelector(s)).lineHeight)",sel)
        # empresa: descrição de até 300 caracteres mostrada inteira, sem seta de expandir (pedido de 17/11)
        sob=pg.evaluate("()=>{const e=document.querySelector('.ma-emp-sobre');return e?{t:e.textContent,seta:!!document.querySelector('.ma-xd[data-xk$=\":emp\"]')}:null}")
        check(f'{nome}: descrição da empresa inteira (até 200 caracteres), sem seta', sob and sob['t'].strip()==SOBRE_API and len(SOBRE_API)<=200 and not sob['seta'], sob)
        pg.screenshot(path=f'/tmp/e2e/descricoes_{nome}.png')
        pg.locator('[data-cat]',has_text='Pizzas').click(); pg.wait_for_timeout(600)
        # produtos: o card mostra só foto, nome e preço; a descrição fica só nos detalhes (pedido de 18/11)
        cards=pg.locator('[data-prod]')
        n=cards.count(); check(f'{nome}: 3 cards de produto na categoria', n==3, n)
        txt=' '.join(cards.nth(i).inner_text() for i in range(n))
        check(f'{nome}: nenhuma descrição de produto nos cards', pg.locator('.ma-xd:not([data-xk$=":emp"])').count()==0 and 'Massa fina' not in txt, txt[:200])
        check(f'{nome}: card com nome e preço', 'Pizza Longa A' in txt and 'R$' in txt and cards.nth(0).locator('img').count()>0, txt[:200])
        sheet_before=pg.locator('.ma-sheet').count()
        cards.nth(0).click(); pg.wait_for_selector('.ma-sheet [data-detalhe]',timeout=5000); pg.wait_for_timeout(300)
        det=pg.locator('.ma-sheet [data-detalhe]')
        check(f'{nome}: detalhes com descrição completa', det.locator('[data-desc]').inner_text().strip()==LONGA, det.locator('[data-desc]').inner_text()[:120])
        check(f'{nome}: detalhes com nome, preço e categoria', 'Pizza Longa A' in det.inner_text() and 'R$' in det.locator('[data-preco]').inner_text() and 'Pizzas' in det.inner_text(), det.inner_text()[:200])
        check(f'{nome}: imagem em destaque nos detalhes', pg.locator('.ma-sheet img').count()>0 and pg.locator('.ma-sheet img').first.bounding_box()['height']>=200)
        pg.screenshot(path=f'/tmp/e2e/detalhes_{nome}.png')
        pg.locator('.ma-sheet-x').click(); pg.wait_for_timeout(400)
        check(f'{nome}: detalhes fecham', pg.locator('.ma-sheet [data-detalhe]').count()==0)
        # botão de compra do card continua funcionando
        pg.locator('[data-add]').first.click(); pg.wait_for_timeout(500)
        check(f'{nome}: botão de compra continua funcionando', pg.locator('[data-cart],#cartbar,:text("carrinho")').count()>0 or pg.locator('text=/R\\$\\s?40/').count()>0)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
