# CRÉDITO DA LOJA pela tela (Playwright), com o servidor real:
# • ADM (computador): liga o recurso, define tetos e autoriza a empresa pela busca do painel;
# • dono (iPhone): Ajustes → Crédito da Loja, regras (juros ao mês, sem juros até 2x, entrada mínima, aprovação até R$ 150),
#   concede limite a um cliente pela busca;
# • cliente (iPhone): checkout de sempre com "Pix à vista" e "Crédito da Loja", simulação transparente (entrada, parcelas,
#   juros, total, vencimentos, condições), aceite obrigatório, compra aprovada na hora; compra acima de R$ 150 vira
#   solicitação; limite insuficiente avisa e bloqueia; Meus pedidos → Meu crédito com as parcelas;
# • dono: aprova a solicitação, registra a entrada e um pagamento parcial; resumo no computador;
# • sem rolagem lateral, sem erros de JavaScript, chat continua funcionando.
# Servidor: PORT=4373 SQLITE_FILE=/tmp/ma-cred.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, re, sys, sqlite3, base64, json
from PIL import Image
from playwright.sync_api import sync_playwright
sys.path.insert(0, __file__.rsplit('/', 1)[0]); from _admin import aba
BASE = 'http://localhost:4373'; DBF = '/tmp/ma-cred.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (200, 200), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
IPHONE = {'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'device_scale_factor': 2}
DESK = {'viewport': {'width': 1280, 'height': 880}}
def sql(q, a=()):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchall(); db.commit(); db.close(); return r
def lateral(pg):
    return pg.evaluate("()=>{const x=document.getElementById('ma-x');const w=innerWidth;return Math.max(document.documentElement.scrollWidth,x?x.scrollWidth:0)-w}")
ULT = {}
def toast(pg):
    # espera um aviso NOVO (o anterior pode ainda estar na tela)
    ant = ULT.get(id(pg), '')
    try:
        pg.wait_for_function("a=>{const t=document.getElementById('ma-x-toast');return t&&!t.hidden&&t.textContent!==a}", arg=ant, timeout=7000)
        ULT[id(pg)] = pg.inner_text('#ma-x-toast'); return N(ULT[id(pg)])
    except Exception: return ''
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    ctxs = {}
    def ctx(nome, opts, signup):
        C = b.new_context(base_url=BASE, **opts)
        if signup: assert C.request.post('/api/auth', data={'action': 'signup', **signup, **U}, headers={'X-Forwarded-For': '10.7.3.' + str(len(ctxs) + 1)}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e, n=nome: errs.append(n + ': ' + str(e))); ctxs[nome] = (C, pg); return C, pg
    A, apg = ctx('adm', DESK, {'name': 'Admin Cred', 'whatsapp': '+55 11 94444-7373', 'email': 'adm.cred@t.com'})
    assert A.request.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    D, dpg = ctx('dono', IPHONE, {'name': 'Ana Dona', 'whatsapp': '+55 11 94444-7374', 'email': 'ana.cred@t.com'})
    r = D.request.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Moda Ana', 'categoria': 'Moda', 'titulo': 'x', 'texto': 'Roupas', 'zap': '11988887777', 'endereco': 'Rua Augusta, 900, São Paulo - SP'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    sql("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,))
    assert D.request.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'ana@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    P = {}
    for nome, preco, cor in [('Camisa', 100, (40, 90, 200)), ('Jaqueta', 200, (20, 20, 20))]:
        r0 = D.request.post(f'/api/v2/ads/{ID}/products', data={'nome': nome, 'preco': preco, 'categoria': 'Roupas', 'fotos': [durl(cor)], **({'estoque': 5} if nome == 'Jaqueta' else {})}); assert r0.ok, r0.text()
    for r0 in D.request.get(f'/api/v2/ads/{ID}/products').json()['items']: P[r0['nome']] = r0['id']
    C, cpg = ctx('cliente', IPHONE, {'name': 'Bruno Cliente', 'whatsapp': '+55 11 95555-7375', 'email': 'bruno.cred@t.com'})
    CID = C.request.get('/api/me').json()['profile']['id']

    print('== ADM (computador)')
    apg.goto('/admin'); aba(apg, 'credito'); apg.wait_for_selector('[data-cr-adm]', timeout=15000)
    t = N(apg.inner_text('[data-cr-adm]'))
    check('ADM: tela do Crédito da Loja em Planos e Pagamentos', 'Crédito da Loja' in t and 'Empresas habilitadas' in t, t[:200])
    apg.click('[data-sw="cr-g-ativo"]'); apg.fill('[data-g=maxParcelas]', '6'); apg.fill('[data-g=jurosMaxMes]', '5'); apg.click('[data-cr-gsalvar]'); apg.wait_for_timeout(1500)
    g = A.request.get('/api/panel/credito').json()['config']
    check('ADM liga o recurso e salva os tetos', g['ativo'] is True and g['maxParcelas'] == 6 and g['jurosMaxMes'] == 5, g)
    apg.wait_for_selector('[data-cr-eq]'); apg.fill('[data-cr-eq]', 'Moda'); apg.click('[data-cr-ebusca] button'); apg.wait_for_selector('[data-cr-aut]', timeout=8000); apg.click('[data-cr-aut]'); apg.wait_for_timeout(1500)
    apg.wait_for_selector(f'[data-cr-emp="{ID}"]', timeout=8000)
    check('ADM autoriza a empresa pela busca', 'Autorizada' in N(apg.inner_text(f'[data-cr-emp="{ID}"]')))
    apg.screenshot(path='/tmp/e2e/credito_adm.png', full_page=True)

    print('== dono (iPhone): regras e concessão')
    dpg.goto('/x/sua-empresa'); dpg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=20000); dpg.click('.ma-nav [data-nav=mais]')
    dpg.wait_for_selector('[data-lt2=credito]', timeout=10000)
    check('dono: "Crédito da Loja" aparece em Ajustes (empresa autorizada)', 'Limites, compras parceladas' in N(dpg.inner_text('[data-lt2=credito]')))
    dpg.click('[data-lt2=credito]'); dpg.wait_for_selector('[data-cr-aba]', timeout=15000)
    check('dono: aviso de que o crédito ainda está desligado para os clientes', 'desligado para os seus clientes' in N(dpg.inner_text('[data-cr-estado]')))
    dpg.click('[data-cr-aba=regras]'); dpg.wait_for_selector('[data-cr-regras]', timeout=10000)
    dpg.click('[data-sw="cr-ativo"]'); dpg.click('[data-cr-jt] [data-j=mensal]'); dpg.fill('[data-k=taxa]', '2'); dpg.fill('[data-k=semJurosAte]', '2'); dpg.fill('[data-k=entradaMinPct]', '10')
    dpg.click('[data-cr-ap] [data-ap=ate_valor]'); dpg.fill('[data-k=aprovacaoAutoAte]', '150'); dpg.fill('[data-k=limiteMaxCliente]', '800'); dpg.fill('[data-k=compraMax]', '1000')
    dpg.fill('[data-k=condicoes]', 'Troca em até 7 dias.'); dpg.wait_for_timeout(200)
    ex = N(dpg.inner_text('[data-cr-ex]')); check('dono: exemplo de simulação ao vivo nas regras', 'Entrada de R$ 30,00' in ex and '4x de' in ex, ex)
    dpg.click('[data-cr-salvar]'); tt = toast(dpg)
    cfg = D.request.get(f'/api/v2/businesses/{ID}/credito/config').json()['config']
    check('dono salva as regras (persistidas no servidor)', 'salvas' in tt and cfg['ativo'] and cfg['jurosTipo'] == 'mensal' and cfg['taxa'] == 2 and cfg['aprovacao'] == 'ate_valor' and cfg['aprovacaoAutoAte'] == 150, cfg)
    dpg.wait_for_selector('[data-cr-regras]'); dpg.screenshot(path='/tmp/e2e/credito_regras_iphone.png', full_page=True)
    check('dono (iPhone): regras sem rolagem lateral', lateral(dpg) <= 1, lateral(dpg))
    dpg.fill('[data-k=taxa]', '9'); dpg.click('[data-cr-salvar]'); dpg.wait_for_timeout(1200)
    check('juros acima do teto do ADM: erro claro na tela', '5%' in N(dpg.inner_text('[data-cr-err]')), dpg.inner_text('[data-cr-err]'))
    dpg.click('[data-cr-aba=clientes]'); dpg.wait_for_selector('[data-cr-q]')
    dpg.fill('[data-cr-q]', 'bruno.cred@t.com'); dpg.click('[data-cr-busca] button'); dpg.wait_for_selector('[data-cr-novo]', timeout=8000)
    dpg.click('[data-cr-novo]'); dpg.wait_for_selector('[data-cr-lim]'); dpg.fill('[data-cr-lim]', '500'); dpg.click('[data-cr-lsalvar]'); tt = toast(dpg)
    dpg.wait_for_selector(f'[data-cr-cli="{CID}"]', timeout=8000)
    check('dono concede limite de R$ 500 ao cliente pela busca', 'Crédito concedido' in tt and 'disponível R$ 500,00' in N(dpg.inner_text(f'[data-cr-cli="{CID}"]')), N(dpg.inner_text(f'[data-cr-cli="{CID}"]')))
    dpg.screenshot(path='/tmp/e2e/credito_clientes_iphone.png')

    print('== cliente (iPhone): checkout')
    def carrinho(pid, qtd=1):
        cpg.goto(f'/x/empresa/{ID}'); cpg.wait_for_selector(f'[data-add="{pid}"]', timeout=20000); cpg.wait_for_timeout(400)
        for _ in range(qtd): cpg.click(f'[data-add="{pid}"]'); cpg.wait_for_timeout(350)
        cpg.locator('button:has-text("Ver pedido")').click(); cpg.wait_for_selector('[data-checkout]', timeout=8000); cpg.wait_for_timeout(500)
        ULT[id(cpg)] = cpg.evaluate("()=>{const t=document.getElementById('ma-x-toast');return t?t.textContent:''}")
    carrinho(P['Camisa'])
    seg = N(cpg.inner_text('.ma-co-seg >> nth=-1'))
    check('checkout mostra "Pix à vista" e "Crédito da Loja (parcelado)"', 'Pix à vista' in seg and 'Crédito da Loja' in seg and 'até 4x' in seg, seg)
    cpg.click('[data-pg=credito]'); cpg.wait_for_selector('[data-cr-tabela]', timeout=8000)
    cpg.click('[data-cr-n="3"]'); cpg.wait_for_function("()=>{const t=document.querySelector('[data-cr-tabela]');return t&&/3 parcelas/.test(t.innerText)}", timeout=8000)
    tab = N(cpg.inner_text('[data-credito-box]'))
    check('simulação transparente: valor, entrada, parcelas, juros, total, vencimentos e condições', all(x in tab for x in ['Valor da compra R$ 100,00', 'Entrada (paga à loja no ato) R$ 10,00', '3 parcelas de R$ 31,21', 'Juros (2% ao mês)', 'Total final', 'Vencimentos', 'Condições do crédito', 'Troca em até 7 dias']), tab)
    ft = N(cpg.inner_text('[data-cr-foot]')) if cpg.locator('[data-cr-foot]').count() else ''
    check('rodapé do checkout mostra o total a crédito (com juros) junto do total do pedido', 'No Crédito da Loja' in ft and 'R$ 103,63' in ft, ft)
    cpg.locator('[data-credito-box]').scroll_into_view_if_needed(); cpg.screenshot(path='/tmp/e2e/credito_checkout_iphone.png')
    check('cliente (iPhone): checkout sem rolagem lateral', lateral(cpg) <= 1, lateral(cpg))
    cpg.fill('#czap', '11955557375'); cpg.click('#cgo'); cpg.wait_for_timeout(400)
    check('sem marcar o aceite o pedido não sai', 'aceita as condições' in N(cpg.inner_text('#cerr')) and cpg.locator('[data-checkout]').count() == 1, cpg.inner_text('#cerr'))
    cpg.check('[data-cr-aceite]'); cpg.click('#cgo'); tt = toast(cpg)
    o = sql("select id, status, data from orders where customer_id=? order by id desc limit 1", (CID,))[0]
    check('compra aprovada na hora (até R$ 150): pedido enviado à loja', 'enviado' in tt and o[1] == 'novo' and json.loads(o[2])['pagamento'] == 'credito', (tt, o[:2]))
    op = sql("select status, n_parcelas, principal from credito_operacoes where order_id=?", (o[0],))[0]
    check('operação ativa: 3 parcelas e R$ 90 financiados', op[0] == 'ativa' and op[1] == 3 and float(op[2]) == 90, op)
    cpg.wait_for_url('**/x/pedidos', timeout=8000); cpg.wait_for_selector('[data-meucred]', timeout=10000)
    cpg.click('[data-meucred]'); cpg.wait_for_selector(f'[data-cr-loja="{ID}"]', timeout=10000)
    mc = N(cpg.inner_text(f'[data-cr-loja="{ID}"]'))
    check('Meu crédito: disponível, compra e parcelas com vencimento', 'R$ 410,00' in mc and 'Entrada' in mc and 'Parcela 3/3' in mc and 'Pendente' in mc, mc)
    cpg.screenshot(path='/tmp/e2e/credito_meu_iphone.png', full_page=True)
    check('Meu crédito sem rolagem lateral', lateral(cpg) <= 1, lateral(cpg))

    print('== cliente: solicitação (aprovação manual) e limite insuficiente')
    carrinho(P['Jaqueta']); cpg.click('[data-pg=credito]'); cpg.wait_for_selector('[data-cr-tabela]', timeout=8000); cpg.wait_for_selector('[data-cr-manual]', timeout=8000)
    check('acima de R$ 150: aviso de que depende da aprovação da loja', 'aprovação da loja' in N(cpg.inner_text('[data-cr-manual]')))
    cpg.check('[data-cr-aceite]'); cpg.fill('#czap', '11955557375'); cpg.click('#cgo'); tt = toast(cpg)
    o2 = sql("select id, status from orders where customer_id=? order by id desc limit 1", (CID,))[0]
    check('solicitação de crédito enviada; pedido aguardando aprovação', 'Solicitação de crédito enviada' in tt and o2[1] == 'aguardando_credito', (tt, o2))
    carrinho(P['Camisa'], 5); cpg.click('[data-pg=credito]'); cpg.wait_for_selector('[data-cr-aviso]', timeout=8000)
    av = N(cpg.inner_text('[data-cr-aviso]'))
    check('limite insuficiente: aviso claro e sem caixa de aceite', 'Limite insuficiente' in av and cpg.locator('[data-cr-aceite]').count() == 0, av)
    cpg.fill('#czap', '11955557375'); cpg.click('#cgo'); cpg.wait_for_timeout(400)
    check('limite insuficiente: o pedido não sai', 'Limite insuficiente' in N(cpg.inner_text('#cerr')) and cpg.locator('[data-checkout]').count() == 1)
    cpg.keyboard.press('Escape'); cpg.wait_for_timeout(300)

    print('== dono: aprovação, recebimentos e resumo')
    dpg.click('[data-cr-aba=solicitacoes]'); dpg.wait_for_selector('[data-cr-aprovar]', timeout=8000)
    check('dono vê a solicitação com cliente, pedido e condições', f'Pedido #{o2[0]}' in N(dpg.inner_text('[data-cr-sol]')) and 'Bruno Cliente' in N(dpg.inner_text('[data-cr-sol]')))
    dpg.click('[data-cr-aprovar]'); tt = toast(dpg)
    check('dono aprova: pedido segue o fluxo normal', 'aprovado' in tt and sql("select status from orders where id=?", (o2[0],))[0][0] == 'novo', tt)
    dpg.click('[data-cr-aba=operacoes]'); dpg.wait_for_selector('[data-cr-op]'); dpg.locator('[data-cr-op]').last.click(); dpg.wait_for_selector('[data-cr-opdet] [data-cr-rp]', timeout=8000)
    dpg.locator('[data-cr-opdet] [data-cr-rp]').first.click(); dpg.wait_for_selector('[data-cr-pconf]', timeout=8000)
    check('registrar pagamento: valor restante já preenchido', N(dpg.input_value('[data-cr-valor]')) == '10', dpg.input_value('[data-cr-valor]'))
    dpg.click('[data-cr-formas] [data-f=dinheiro]'); dpg.click('[data-cr-pconf]'); tt = toast(dpg)
    check('entrada registrada em dinheiro', 'Pagamento registrado' in tt, tt)
    dpg.click('[data-cr-aba=operacoes]'); dpg.wait_for_selector('[data-cr-op]'); dpg.locator('[data-cr-op]').last.click(); dpg.wait_for_selector('[data-cr-opdet] [data-cr-rp]', timeout=8000)
    dpg.locator('[data-cr-opdet] [data-cr-rp]').first.click(); dpg.wait_for_selector('[data-cr-valor]'); dpg.fill('[data-cr-valor]', '10'); dpg.click('[data-cr-pconf]'); tt = toast(dpg)
    check('pagamento parcial registrado com o restante informado', 'parcial' in tt and 'Faltam' in tt, tt)
    pag = sql("select count(*), sum(valor) from credito_pagamentos where operacao_id=(select id from credito_operacoes where order_id=?)", (o[0],))[0]
    fin = sql("select count(*) from items where user_id=(select owner_id from businesses where id=?) and type='expense' and data like '%credito:pag:%'", (ID,))[0][0]
    check('financeiro: uma receita por pagamento, sem duplicar a venda', pag[0] == 2 and float(pag[1]) == 20 and fin == 2, (pag, fin))
    cn = C.request.get('/api/notifications').json()['items']; tits = ' | '.join(n['title'] for n in cn)
    check('cliente notificado: limite, compra, aprovação e pagamentos', all(x in tits for x in ['Limite de crédito liberado', 'Compra realizada com Crédito da Loja', 'Crédito aprovado', 'Pagamento registrado']), tits[:400])
    D2 = b.new_context(base_url=BASE, **DESK, storage_state=D.storage_state()); d2 = D2.new_page(); d2.on('pageerror', lambda e: errs.append('dono-pc: ' + str(e)))
    d2.goto('/x/sua-empresa'); d2.wait_for_selector('.ma-nav [data-nav=mais]', timeout=20000); d2.click('.ma-nav [data-nav=mais]'); d2.click('[data-lt2=credito]'); d2.wait_for_selector('[data-cr-kpis]', timeout=15000)
    k = N(d2.inner_text('[data-cr-kpis]'))
    check('resumo financeiro (computador): concedido, utilizado, a receber, recebido, vencido', 'Total concedido R$ 500,00' in k and 'Recebido R$ 20,00' in k and 'A receber' in k and 'Vencido R$ 0,00' in k, k)
    d2.screenshot(path='/tmp/e2e/credito_resumo_computador.png', full_page=True)
    check('computador sem rolagem lateral', lateral(d2) <= 1, lateral(d2))
    d2.click('[data-cr-aba=relatorio]'); d2.wait_for_selector('[data-cr-rel]')
    check('relatório por período', 'Compras a crédito 2' in N(d2.inner_text('[data-cr-rel]')), N(d2.inner_text('[data-cr-rel]')))

    print('== o chat continua normal')
    cpg.goto('/'); cpg.wait_for_selector('textarea', timeout=20000); cpg.fill('textarea', 'oi');
    check('chat: campo de mensagem funciona com o recurso ativo', cpg.input_value('textarea') == 'oi')
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and not e.endswith(': Event')], errs[:4])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
