# Página de Links: gerenciamento em Sua empresa (prévia em tempo real, botões, cores, publicação) e a página pública
# /<endereço>/links com a identidade visual do catálogo; acesso só no anúncio completo.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
iso=lambda d: (datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=d)).isoformat().replace('+00:00','Z')
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE); RA=A.request
    assert RA.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com',**U}).ok
    RA.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True})
    db=sqlite3.connect(DBF)
    def dono(nome,email,ip,plano,empresa):
        c=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':'+55 11 95555-0'+ip,'email':email,**U},headers={'X-Forwarded-For':'10.8.8.'+ip}).ok
        i=R.post('/api/v2/ads',data={'planId':plano,'empresa':empresa,'categoria':'Doceria','titulo':'Doces','texto':'Doces artesanais feitos com carinho','zap':'5511999990000'}).json()['items'][0]['id']
        d=json.loads(db.execute('select data from businesses where id=?',(i,)).fetchone()[0]); d['tema']={'preset':'elegante','cor':'#c9a227','fundo':'escuro','layout':'lista','cantos':'arredondado'}; d['aprovadoEm']=iso(0)
        db.execute("update businesses set status='ativo', expires_at=?, data=? where id=?",(iso(30),json.dumps(d),i)); db.commit(); return c,R,i
    D,RD,ID=dono('Dona Lu','lu@t.com','101','n4','Doceria da Lu')
    pg=D.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(3500)
    if not pg.locator('[data-lt2="links"]').count():
        pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1200)
    check('Sua empresa: opção "Página de Links" no anúncio completo', pg.locator('[data-lt2="links"]').count()==1)
    pg.locator('[data-lt2="links"]').click(); pg.wait_for_selector('[data-lk-status]',timeout=15000); pg.wait_for_timeout(500)
    st=pg.inner_text('[data-lk-status]')
    check('gerenciamento: endereço exclusivo /doceria-da-lu/links e status "Não publicada"', 'doceria-da-lu/links' in st and 'Não publicada' in st, st)
    lista=pg.locator('[data-lk-lista] [data-bt]')
    check('botões padrão criados: Catálogo e Agente de Atendimento (automático)', lista.count()==2 and 'Catálogo' in lista.nth(0).inner_text() and 'aparece quando o agente estiver contratado' in lista.nth(1).inner_text(), [lista.nth(i).inner_text() for i in range(lista.count())])
    # prévia em tempo real (aba Prévia no celular)
    pg.click('[data-lk-aba="previa"]'); pg.wait_for_timeout(1500)
    fr=pg.frame_locator('[data-lk-frame]')
    check('prévia: mostra a empresa e o botão Catálogo, sem o agente (não contratado)', 'Doceria da Lu' in fr.locator('body').inner_text() and fr.locator('[data-tipo="catalogo"]').count()==1 and fr.locator('[data-tipo="agente"]').count()==0)
    pg.click('[data-lk-aba="editar"]'); pg.fill('#lk_t','Doceria da Lu · Links'); pg.fill('#lk_d','Bolos, doces finos e encomendas para festas.')
    pg.click('[data-add="whatsapp"]'); pg.fill('[data-novo] [data-f="titulo"]','Encomendas no WhatsApp'); pg.fill('[data-novo] [data-f="valor"]','11 98765-4321'); pg.click('[data-add-ok]')
    pg.click('[data-add="instagram"]'); pg.fill('[data-novo] [data-f="valor"]','@doceriadalu'); pg.click('[data-add-ok]')
    pg.click('[data-add="site"]'); pg.fill('[data-novo] [data-f="titulo"]','Site antigo'); pg.fill('[data-novo] [data-f="valor"]','doceriadalu.com.br'); pg.click('[data-add-ok]')
    n=pg.locator('[data-lk-lista] [data-bt]').count()
    pg.locator('[data-lk-lista] [data-bt]').nth(n-1).locator('[data-sw]').click()  # desativa o "Site antigo"
    pg.locator('[data-lk-lista] [data-bt]').nth(2).locator('[data-up-i]').click()  # WhatsApp sobe
    pg.locator('[data-lk-lista] [data-bt]').nth(1).locator('[data-up-i]').click()  # WhatsApp vira o primeiro
    pg.click('[data-lk-aba="previa"]'); pg.wait_for_timeout(800)
    tipos=fr.locator('a[data-bt]').evaluate_all('l=>l.map(a=>a.dataset.tipo)')
    check('prévia em tempo real: título, descrição e botões novos na ordem (desativado fora)', fr.locator('h1').inner_text()=='Doceria da Lu · Links' and 'encomendas para festas' in fr.locator('body').inner_text() and tipos==['whatsapp','catalogo','instagram'], (fr.locator('h1').inner_text(),tipos))
    acc=fr.locator('html').evaluate("e=>getComputedStyle(e).getPropertyValue('--nx-accent').trim()")
    check('prévia segue o tema do catálogo (cor da empresa)', acc=='#c9a227', acc)
    pg.wait_for_timeout(300); pg.screenshot(path='/tmp/e2e/links_previa_celular.png')
    # cores próprias
    pg.click('[data-lk-aba="editar"]'); pg.click('[data-sw="lk_tema"]'); pg.click('[data-fd="claro"]'); pg.click('[data-lk-aba="previa"]'); pg.wait_for_timeout(600)
    check('prévia: cores próprias (fundo claro) aplicadas na hora', fr.locator('html').get_attribute('data-theme')=='light')
    pg.click('[data-lk-aba="editar"]'); pg.click('[data-sw="lk_tema"]')
    check('ainda não publicada: endereço público fechado', A.request.get('/api/v2/links/doceria-da-lu').status==404)
    pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
    check('publicar: status "Publicada"', 'Publicada' in pg.inner_text('[data-lk-status]'), pg.inner_text('[data-lk-status]'))
    # página pública (visitante sem login)
    V=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2); pv=V.new_page(); pv.on('pageerror',lambda e:errs.append(str(e)))
    pv.goto('/doceria-da-lu/links'); pv.wait_for_selector('a[data-bt]',timeout=15000); pv.wait_for_timeout(500)
    tp=pv.locator('a[data-bt]').evaluate_all('l=>l.map(a=>[a.dataset.tipo,a.getAttribute("href")])')
    check('página pública: botões publicados com os links certos', tp==[['whatsapp','https://wa.me/5511987654321'],['catalogo',f'/x/empresa/{ID}'],['instagram','https://instagram.com/doceriadalu']], tp)
    vis=pv.evaluate("""()=>{const c=document.querySelector('.ma-emp-capa'),h=document.querySelector('.ma-emp-nm'),b1=document.querySelector('a[data-bt]'),b2=document.querySelectorAll('a[data-bt]')[1];return {acc:getComputedStyle(document.documentElement).getPropertyValue('--nx-accent').trim(),capaR:getComputedStyle(c).borderRadius,nm:getComputedStyle(h).fontWeight,pri:b1.classList.contains('pri'),glass:b2.classList.contains('glass'),vw:innerWidth,sw:document.documentElement.scrollWidth}}""")
    check('mesma identidade do catálogo: cor da empresa, capa 1.6rem, cartões .glass e botão principal na cor', vis['acc']=='#c9a227' and vis['capaR']=='25.6px' and vis['pri'] and vis['glass'], vis)
    check('mobile-first: sem rolagem lateral em 390 px', vis['sw']<=vis['vw'], vis)
    pv.screenshot(path='/tmp/e2e/links_publica_celular.png')
    pv.locator('a[data-tipo="catalogo"]').click(); pv.wait_for_url(f'**/x/empresa/{ID}',timeout=15000)
    check('botão Catálogo abre o catálogo da empresa', pv.url.endswith(f'/x/empresa/{ID}'))
    # agente contratado: aparece sozinho na página pública
    d=json.loads(db.execute('select data from businesses where id=?',(ID,)).fetchone()[0]); d['agente']={'nome':'Lu','ativo':True,'expiresAt':iso(30)}; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit()
    pv.goto('/doceria-da-lu/links'); pv.wait_for_selector('a[data-bt]',timeout=15000)
    check('agente contratado e ativo: botão Agente de Atendimento aparece e leva ao atendimento', pv.locator('a[data-tipo="agente"]').get_attribute('href')=='/doceria-da-lu')
    # computador: gerenciamento com prévia ao lado
    pc=D.new_page(); pc.set_viewport_size({'width':1280,'height':900}); pc.goto('/x/sua-empresa'); pc.wait_for_timeout(3000)
    if not pc.locator('[data-lt2="links"]').count(): pc.locator('.ma-nav button').last.click(); pc.wait_for_timeout(1000)
    pc.locator('[data-lt2="links"]').click(); pc.wait_for_selector('[data-lk-frame]',timeout=15000); pc.wait_for_timeout(2000)
    lay=pc.evaluate("()=>{const e=document.querySelector('.ma-lk-ed').getBoundingClientRect(),v=document.querySelector('.ma-lk-pv').getBoundingClientRect();return {lado:v.left>e.right-1,vis:v.width>300}}")
    check('computador: editor e prévia lado a lado', lay['lado'] and lay['vis'], lay)
    pc.screenshot(path='/tmp/e2e/links_gerenciar_pc.png')
    # plano sem acesso
    D2,RD2,ID2=dono('Dono Beto','beto@t.com','102','n2','Lanches do Beto')
    p2=D2.new_page(); p2.goto('/x/sua-empresa'); p2.wait_for_timeout(3500)
    if not p2.locator('[data-lt2]').count(): p2.locator('.ma-nav button').last.click(); p2.wait_for_timeout(1000)
    check('plano sem acesso: opção oculta em Sua empresa', p2.locator('[data-lt2="links"]').count()==0)
    r=RD2.get(f'/api/v2/ads/{ID2}/links'); check('plano sem acesso: servidor bloqueia (403 links_plano)', r.status==403 and r.json().get('code')=='links_plano')
    check('outra empresa não acessa a página da Lu', RD2.get(f'/api/v2/ads/{ID}/links').status==404)
    pv.goto('/lanches-do-beto/links'); pv.wait_for_timeout(1500); check('endereço de empresa sem página publicada mostra "indisponível"', 'não está disponível' in pv.inner_text('body'))
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
