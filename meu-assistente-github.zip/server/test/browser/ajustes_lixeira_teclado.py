# Teclado aberto (fim das telas alcançável: Entrega e pagamento/Mercado Pago e "Seus dados" do Anunciar), ofertas no topo do catálogo
# (loja e agente), categorias em lista, duplicar produto, duas fotos de uma vez, excluir empresa → Lixeira → restaurar,
# e logo/capa editáveis direto no topo de Sua empresa (sem o item "Logo e capa" em Ajustes). Celular.
# Servidor: PORT=4323 SQLITE_FILE=/tmp/ma-ajl.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4323'; DBF = '/tmp/ma-ajl.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def png(cor, w=300, h=200):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return {'name': 'f.png', 'mimeType': 'image/png', 'buffer': b.getvalue()}
def durl(cor): return 'data:image/png;base64,' + base64.b64encode(png(cor)['buffer']).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
MOB = {'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'base_url': BASE}
def coberto(pg, sel):
    return pg.evaluate("""(s)=>{const e=document.querySelector(s);if(!e)return 'sem elemento';const r=e.getBoundingClientRect(),vh=(window.visualViewport||{height:innerHeight}).height;if(r.bottom>vh+1||r.top<0)return 'fora da tela '+Math.round(r.top)+'/'+Math.round(vh);const x=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return x===e||e.contains(x)?'':'coberto por '+(x&&x.className)}""", sel)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(**MOB); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.ajl@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Moda da Ana', 'categoria': 'Roupas', 'titulo': 'x', 'texto': 'x', 'zap': '5511999990000'}); assert r.ok, r.text(); ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}, 'categorias': ['Camisetas', 'Bonés']}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Camiseta Lisa', 'preco': 40, 'categoria': 'Camisetas', 'fotos': [durl((20, 20, 20))]}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Camiseta Estampada', 'preco': 60, 'categoria': 'Camisetas', 'fotos': [durl((200, 20, 20))], 'oferta': {'ativo': True, 'preco': 45}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Boné', 'preco': 30, 'categoria': 'Bonés', 'fotos': [durl((20, 20, 200))]}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
    abrir = lambda lt: (pg.goto('/x/sua-empresa'), pg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=15000), pg.click('.ma-nav [data-nav=mais]'), pg.wait_for_selector(f'[data-lt2={lt}]'), pg.click(f'[data-lt2={lt}]'), pg.wait_for_timeout(1500))
    # 1) teclado aberto: Entrega e pagamento (Mercado Pago fica nesta tela)
    abrir('entrega'); pg.wait_for_selector('#pk')
    pg.locator('#pk').focus(); pg.set_viewport_size({'width': 390, 'height': 470}); pg.wait_for_timeout(900)
    check('teclado aberto: menu inferior sai da frente', pg.evaluate("document.body.classList.contains('ma-kb')") and pg.evaluate("getComputedStyle(document.querySelector('.ma-nav')).display") == 'none')
    check('teclado aberto: o campo em foco fica visível', coberto(pg, '#pk') == '', coberto(pg, '#pk'))
    pg.locator('#ma-x button:visible', has_text='Salvar entrega e pagamento').scroll_into_view_if_needed(); pg.wait_for_timeout(300)
    sv = pg.locator('#ma-x button:visible', has_text='Salvar entrega e pagamento'); sv.evaluate("e=>e.setAttribute('data-alvo','1')")
    check('teclado aberto: dá para chegar ao fim da tela (botão Salvar livre)', coberto(pg, '[data-alvo]') == '', coberto(pg, '[data-alvo]'))
    pg.screenshot(path='/tmp/e2e/ajl_teclado.png')
    pg.locator('#pk').blur(); pg.set_viewport_size({'width': 390, 'height': 844}); pg.wait_for_timeout(700)
    check('teclado fechado: menu inferior volta', not pg.evaluate("document.body.classList.contains('ma-kb')") and pg.evaluate("getComputedStyle(document.querySelector('.ma-nav')).display") != 'none')
    # página Anunciar: sem cupom na 1ª etapa (ele fica no pagamento); teclado aberto nos "Seus dados"
    pg.goto('/x/anunciar'); pg.wait_for_selector('#adf', timeout=20000); pg.wait_for_timeout(800)
    pg.locator('label:has([name=planId])').first.click(); pg.wait_for_timeout(300)
    check('Anunciar sem "Tenho um cupom" (o cupom fica na etapa de pagamento)', pg.locator('#adf [data-cup-abrir]').count() == 0)
    pg.locator('[name=respTel]').focus(); pg.set_viewport_size({'width': 390, 'height': 470}); pg.wait_for_timeout(900)
    check('teclado aberto em "Seus dados": o campo fica visível', coberto(pg, '[name=respTel]') == '', coberto(pg, '[name=respTel]'))
    pg.locator('#adf button[type=submit]').scroll_into_view_if_needed(); pg.locator('#adf button[type=submit]').evaluate("e=>e.setAttribute('data-alvo2','1')")
    check('teclado aberto: "Continuar para o pagamento" alcançável', coberto(pg, '[data-alvo2]') == '', coberto(pg, '[data-alvo2]'))
    pg.locator('[name=respTel]').blur(); pg.set_viewport_size({'width': 390, 'height': 844}); pg.wait_for_timeout(500)
    # 2) ofertas no topo do catálogo (loja e agente)
    C = b.new_context(**MOB); pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector('[data-prod]', timeout=20000); pc.wait_for_timeout(800)
    nomes = [x.inner_text().split('\n')[0] for x in pc.locator('[data-prod]').all()]
    first = pc.locator('[data-prod]').first.inner_text()
    check('loja: produto em oferta no topo do catálogo', 'Camiseta Estampada' in first, nomes)
    pc.click('[data-cat="Camisetas"]'); pc.wait_for_timeout(400)
    check('loja: oferta no topo da categoria também', 'Camiseta Estampada' in pc.locator('[data-prod]').first.inner_text())
    assert R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (ID,)).fetchone()[0]); d.setdefault('agente', {})['expiresAt'] = '2099-01-01T00:00:00Z'; db.execute('update businesses set data=? where id=?', (json.dumps(d), ID)); db.commit(); db.close()
    pa = C.new_page(); pa.on('pageerror', lambda e: errs.append(str(e))); pa.goto(f'/a/{ID}'); pa.wait_for_selector('#acts button', timeout=15000)
    if not pa.locator('#acts [data-a=cat]').count(): pa.click('#acts [data-a=mais]')
    pa.click('#acts [data-a=cat]'); pa.wait_for_selector('.pc', timeout=8000); pa.wait_for_timeout(300)
    check('agente: grupo "Em oferta" primeiro, com a oferta', pa.locator('.opt [data-c]').first.inner_text() == 'Em oferta' and 'Camiseta Estampada' in pa.locator('.pc').first.inner_text(), pa.locator('.opt [data-c]').first.inner_text())
    # 3) categorias em lista + duplicar + duas fotos de uma vez
    abrir('categorias'); pg.fill('#cnew', 'Bermudas'); pg.click('#cadd'); pg.wait_for_timeout(1000)
    check('categoria nova salva na hora (sem precisar de "Salvar")', 'Bermudas' in R.get('/api/v2/ads/mine').json()['items'][0].get('categorias', []))
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=produtos]', timeout=15000); pg.click('.ma-nav [data-nav=produtos]'); pg.wait_for_selector('#psave', timeout=10000)
    if pg.locator('[data-mim=manual]').count() and not pg.locator('#psave').is_visible(): pg.click('[data-mim=manual]')
    opts = [x.inner_text() for x in pg.locator('#pcs option').all()]
    check('cadastro de produto: categorias criadas aparecem na lista', opts[:3] == ['Camisetas', 'Bonés', 'Bermudas'] and opts[-1] == 'Outra…' and not pg.locator('#pc').is_visible(), opts)
    pg.select_option('#pcs', '__nova'); check('"Outra…" abre o campo para digitar', pg.locator('#pc').is_visible())
    pg.select_option('#pcs', 'Bermudas')
    pg.set_input_files('#pf', [png((10, 120, 10)), png((120, 120, 10))]); pg.wait_for_timeout(1200)
    check('duas fotos escolhidas de uma vez', pg.locator('#pfs img').count() == 2, pg.locator('#pfs img').count())
    pg.fill('#pn', 'Bermuda Jeans'); pg.fill('#ppr', '80,00'); pg.click('#psave'); pg.wait_for_timeout(1800)
    bj = next((x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['nome'] == 'Bermuda Jeans'), None)
    check('produto salvo com as 2 fotos e a categoria escolhida', bj and len(bj['fotos']) == 2 and bj['categoria'] == 'Bermudas')
    pg.locator(f'[data-pdup="{bj["id"]}"]').click(); pg.wait_for_selector('[data-ptitulo]'); pg.wait_for_timeout(300)
    check('duplicar abre o cadastro preenchido (cópia)', 'Duplicar produto' in pg.inner_text('[data-ptitulo]') and pg.input_value('#pn') == 'Bermuda Jeans (cópia)' and pg.locator('#pfs img').count() == 2 and pg.input_value('#pcs') == 'Bermudas')
    pg.fill('#pn', 'Bermuda Jeans Escura'); pg.click('#psave'); pg.wait_for_timeout(1800)
    it = R.get(f'/api/v2/ads/{ID}/products').json()['items']
    check('cópia salva como novo produto, original intacto', sum(1 for x in it if x['nome'].startswith('Bermuda Jeans')) == 2 and any(x['nome'] == 'Bermuda Jeans' for x in it))
    # 4) logo e capa direto no topo; sem "Logo e capa" em Ajustes
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]'); pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector('[data-ed-capa]', timeout=10000)
    check('Ajustes sem o item "Logo e capa"', 'Logo e capa' not in pg.inner_text('#ma-x') and pg.locator('[data-visual]').count() == 0)
    pg.screenshot(path='/tmp/e2e/ajl_topo.png')
    with pg.expect_file_chooser() as fc: pg.click('[data-ed-capa]')
    fc.value.set_files(png((250, 140, 0), 800, 400)); pg.wait_for_function("()=>{const b=document.querySelector('[data-ed-capa]');return b&&/url\\(/.test(b.getAttribute('style'))}", timeout=10000)
    check('tocar na capa troca a capa', bool(R.get('/api/v2/ads/mine').json()['items'][0].get('capa')))
    with pg.expect_file_chooser() as fc: pg.click('[data-ed-logo]')
    fc.value.set_files(png((0, 160, 120), 200, 200)); pg.wait_for_function("()=>!!document.querySelector('[data-ed-logo] img')", timeout=10000)
    check('tocar na logo troca a logo', bool(R.get('/api/v2/ads/mine').json()['items'][0].get('logo')))
    pg.click('[data-rm-capa]'); pg.wait_for_timeout(1500)
    check('remover capa pelo topo', not R.get('/api/v2/ads/mine').json()['items'][0].get('capa'))
    # 5) excluir empresa → lixeira → restaurar
    pg.locator('[data-excluir-emp]').scroll_into_view_if_needed(); pg.click('[data-excluir-emp]'); pg.wait_for_selector('[data-excluir-conf]')
    check('excluir pede confirmação e explica a lixeira de 30 dias', pg.locator('#exsim').is_disabled() and 'Lixeira por 30 dias' in pg.inner_text('[data-excluir-conf]'))
    pg.check('#exok'); pg.click('#exsim'); pg.wait_for_timeout(1800)
    check('empresa sai de Sua empresa e o atalho para a Lixeira aparece', pg.locator('[data-ir-lixeira]').count() == 1 and 'Lixeira (1)' in pg.inner_text('[data-ir-lixeira]'))
    check('catálogo público fora do ar', C.request.get(f'/api/v2/businesses/{ID}').status == 404)
    pg.click('[data-ir-lixeira]'); pg.wait_for_selector('[data-lx]', timeout=10000)
    check('Lixeira mostra a empresa e o prazo de 30 dias', 'Moda da Ana' in pg.inner_text('[data-lx]') and 'Exclusão definitiva em 30 dias' in pg.inner_text('[data-lx-prazo]'), pg.inner_text('[data-lx]'))
    pg.screenshot(path='/tmp/e2e/ajl_lixeira.png')
    pg.click(f'[data-lx-rest="{ID}"]'); pg.wait_for_selector('[data-lixeira-vazia]', timeout=10000)
    check('restaurar devolve a empresa como estava (catálogo e produtos)', C.request.get(f'/api/v2/businesses/{ID}').status == 200 and len(C.request.get(f'/api/v2/businesses/{ID}').json()['produtos']) == 5)
    check('sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
