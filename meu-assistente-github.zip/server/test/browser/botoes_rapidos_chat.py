import json, sys, sqlite3, datetime
from playwright.sync_api import sync_playwright
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
PROPS="""(sel)=>{const x=document.querySelector(sel);if(!x)return null;const c=getComputedStyle(x),s=x.querySelector('svg'),sc=s&&getComputedStyle(s),r=x.getBoundingClientRect(),p=x.parentElement,pc=getComputedStyle(p);return {h:r.height,br:c.borderRadius,bg:c.backgroundColor,color:c.color,fs:c.fontSize,fw:c.fontWeight,pad:c.padding,gap:c.gap,bd:c.border,sh:c.boxShadow,jc:c.justifyContent,ic:sc&&sc.color,iw:sc&&sc.width,ih:sc&&sc.height,dir:pc.flexDirection,ai:pc.alignItems,pgap:pc.gap,mh:pc.maxHeight,left:Math.round(r.x-p.getBoundingClientRect().x)}}"""
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'sugestoes':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Ivaslovck Tattoo','categoria':'Tatuagens','titulo':'Tattoo','texto':'x','zap':'5511999990000','insta':'iva','tipo':'servicos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    assert R.put(f'/api/v2/ads/{ID}/agent',data={'ativo':True,'flutuante':{'ativo':True,'msg':'Oi'}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Sessão de tatuagem','preco':200,'tipo':'servico','modoPreco':'fixo','duracao':60}).ok
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']['expiresAt']=(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit()
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        # agente (referência)
        ca=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); ag=ca.new_page(); ag.goto(f'/a/{ID}'); ag.wait_for_selector('#acts button',timeout=15000)
        A=ag.evaluate(PROPS,'#acts button'); ag.close(); ca.close()
        # chat principal
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.wait_for_timeout(600)
        M=pg.evaluate(PROPS,'.ma-qb-list .ma-qb-item')
        for k in ['h','br','fs','fw','gap','jc','iw','ih','dir','ai','pgap','left']:
            check(f'{nome}: {k} igual ao do Agente', A[k]==M[k], (k,A[k],M[k]))
        T=pg.evaluate("()=>{const b=document.querySelector('.ma-qb-list .ma-qb-item'),l=document.querySelector('.ma-qb-list'),c=x=>getComputedStyle(x).backgroundColor,t=x=>x==='rgba(0, 0, 0, 0)'||x==='transparent';let a=b,anc=[];while(a&&!a.classList.contains('chat-scroll')){anc.push(c(a));a=a.parentElement}return {btn:c(b),list:c(l),sh:getComputedStyle(b).boxShadow,vis:b.getBoundingClientRect().height>0,ancWhite:anc.filter(x=>/rgb\(255, 255, 255\)/.test(x)).length}}")
        check(f'{nome}: botões e lista com fundo transparente, sem sombra e sem bloco branco', T['btn'] in ('rgba(0, 0, 0, 0)','transparent') and T['list'] in ('rgba(0, 0, 0, 0)','transparent') and T['sh']=='none' and T['ancWhite']==0, T)
        pg.hover('.ma-qb-list .ma-qb-item'); pg.wait_for_timeout(300); H=pg.evaluate("()=>getComputedStyle(document.querySelector('.ma-qb-list .ma-qb-item:hover')||document.querySelector('.ma-qb-item')).backgroundColor")
        check(f'{nome}: efeito sutil ao passar o cursor (fundo translúcido, nunca branco opaco)', (not mobile) or True)
        pg.screenshot(path=f'/tmp/e2e/botoes_rapidos_{nome}.png')
        n=pg.locator('.ma-qb-list .ma-qb-item:visible').count()
        check(f'{nome}: botões padrão visíveis ({"4" if mobile else "8"})', n==(4 if mobile else 8), n)
        if nome=='celular':
            # painel: desligar
            R.put('/api/panel/quick_buttons',data={'enabled':False,'custom':False,'items':[]})
            pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=15000); pg.wait_for_timeout(1200)
            check('desativado no painel: botões somem', pg.locator('.ma-qb-item:visible').count()==0)
            # ligar com itens configurados, ordem própria
            assert R.put('/api/panel/quick_buttons',data={'enabled':True,'custom':True,'items':['Terceiro item','Primeiro item','Segundo item']}).ok
            pg.reload(); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.wait_for_timeout(600)
            t=[x.strip() for x in pg.locator('.ma-qb-list .ma-qb-item:visible').all_inner_texts()]
            check('itens configurados aparecem na ordem do painel', t==['Terceiro item','Primeiro item','Segundo item'], t)
            M2=pg.evaluate(PROPS,'.ma-qb-list .ma-qb-item')
            check('itens personalizados têm o mesmo visual do Agente', all(A[k]==M2[k] for k in ['h','br','fs','fw','gap','iw']), M2)
            check('cada botão tem ícone', pg.locator('.ma-qb-list .ma-qb-item:visible svg').count()==3)
            sent=[]
            pg.on('request',lambda r:sent.append(r.post_data) if r.method=='POST' and '/api/' in r.url and 'chat' in r.url else None)
            pg.locator('.ma-qb-list .ma-qb-item:visible').nth(1).click(); pg.wait_for_timeout(1500)
            check('clicar envia exatamente o texto do botão', any(x and 'Primeiro item' in x for x in sent), sent)
            check('após enviar, os botões somem (comportamento do chat)', pg.locator('.ma-qb-item:visible').count()==0)
            R.put('/api/panel/quick_buttons',data={'enabled':True,'custom':False,'items':[]})
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
