# Abertura do app (stories antes do login) + painel "Tela de abertura".
# iPhone (descritor do iPhone 13) e computador: 4 telas padrão com imagens reais, barras segmentadas, avanço automático,
# toque direita/esquerda, deslizar, segurar para pausar, teclado, recomeço depois da última, painel de vidro fixo com
# Entrar (revela o login de sempre — e o login funciona) e Criar conta (cadastro de sempre), uma vez por sessão,
# computador em coluna central. Painel: 4 telas, prévia ao vivo, editar texto, desativar, reordenar, trocar imagem
# (upload), tempo, publicar (persistido e visto pelo visitante), restaurar o padrão, desligar tudo, permissões e validação.
# Servidor: PORT=4371 SQLITE_FILE=/tmp/ma-ab.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, sys, base64, json
from PIL import Image
from playwright.sync_api import sync_playwright
from _admin import aba
BASE = 'http://localhost:4371'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def png(cor, w=540, h=1080):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return b.getvalue()
CONT = "()=>(document.querySelector('.ma-ab:not(.previa) .ma-ab-cont')||{}).textContent||''"
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); R = A.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Abertura', 'whatsapp': '+55 85 94444-1371', 'email': 'admin.ab@t.com', **U}).ok
    pub = A.request.get('/api/v2/abertura').json()
    check('4 telas padrão cadastradas (assistente, agenda, finanças, negócios) com imagens próprias', len(pub['telas']) == 4 and [t['imagem'] for t in pub['telas']] == [f'/abertura/tela-{i}.webp' for i in range(1, 5)] and 'compromissos' in pub['telas'][1]['destaque'] and 'finanças' in pub['telas'][2]['destaque'] and 'negócios' in pub['telas'][3]['destaque'], pub)
    tam = [len(A.request.get(t['imagem']).body()) for t in pub['telas']]
    check('imagens padrão otimizadas (WEBP, < 120 KB cada)', all(20000 < x < 120000 for x in tam), tam)
    iphone = {**p.devices['iPhone 13']}; iphone.pop('default_browser_type', None)
    # tempo curto para o teste do avanço automático
    pan = R.get('/api/panel/abertura').json()
    assert R.put('/api/panel/abertura', data={'duracao': 3, 'telas': [{'id': t['id']} for t in pan['telas']]}).ok
    for nome, ctx in [('iPhone', iphone), ('computador', {'viewport': {'width': 1280, 'height': 860}})]:
        print('==', nome); mob = nome == 'iPhone'
        C = b.new_context(base_url=BASE, **ctx); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(nome + ': ' + str(e)))
        reqs = []; pg.on('request', lambda r: reqs.append(r.url) if '/abertura/tela-' in r.url else None)
        pg.goto('/'); pg.wait_for_selector('.ma-ab:not(.previa) .ma-ab-img.on', timeout=20000); pg.wait_for_function("()=>{const e=document.getElementById('ma-splash');return !e||e.classList.contains('out')}", timeout=8000); pg.wait_for_timeout(300)  # depois da abertura animada
        g = pg.evaluate("""()=>{const r=document.querySelector('.ma-ab:not(.previa)'),pal=r.querySelector('.ma-ab-palco').getBoundingClientRect(),pn=r.querySelector('.ma-ab-painel').getBoundingClientRect(),im=r.querySelector('.ma-ab-img.on');
          return {path:location.pathname,barras:r.querySelectorAll('.ma-ab-barra').length,h1:r.querySelector('h1').textContent,em:(r.querySelector('h1 em')||{}).textContent,sub:r.querySelector('.ma-ab-txt p').textContent,
          img:im.complete&&im.naturalWidth>0,src:im.getAttribute('src'),palL:pal.left,palW:pal.width,pnB:pn.bottom,pnT:pn.top,h:innerHeight,w:innerWidth,lado:document.documentElement.scrollWidth-innerWidth,
          entrar:[...r.querySelectorAll('[data-ab]')].map(x=>x.textContent),blur:getComputedStyle(r.querySelector('.ma-ab-fundo')).filter}}""")
        check(f'{nome}: abre na apresentação (de "/" para /entrar), 4 barras e a 1ª tela', g['path'] == '/entrar' and g['barras'] == 4 and g['h1'].startswith('Seu assistente inteligente') and g['em'] == 'o dia a dia' and 'produtividade' in g['sub'], g)
        check(f'{nome}: imagem de fundo carregada', g['img'] and 'tela-1' in g['src'], g)
        check(f'{nome}: painel de vidro fixo embaixo com Entrar e Criar conta', g['entrar'] == ['Entrar', 'Criar conta'] and g['pnB'] <= g['h'] and g['h'] - g['pnB'] < 40, g)
        check(f'{nome}: só as imagens necessárias carregam no início (preguiçoso)', len(set(reqs)) <= 2, reqs)
        if mob: check('iPhone: tela cheia, sem rolagem lateral', g['palW'] == g['w'] and g['lado'] <= 1, g)
        else: check('computador: coluna central (≤ 520 px) com fundo desfocado da imagem', g['palW'] <= 520 and abs(g['palL'] - (g['w'] - g['palW']) / 2) < 2 and 'blur' in g['blur'], g)
        pg.screenshot(path=f'/tmp/e2e/abertura_{nome}.png')
        # avanço automático (3 s nesta configuração)
        pg.wait_for_function(f"()=>({CONT})()==='2 / 4'", timeout=6000)
        check(f'{nome}: avança sozinho para a 2ª tela (Agenda)', 'compromissos' in pg.text_content('.ma-ab:not(.previa) h1 em'))
        W = pg.viewport_size['width']; H = pg.viewport_size['height']; cx = W / 2
        pal = pg.evaluate("(()=>{const r=document.querySelector('.ma-ab:not(.previa) .ma-ab-palco').getBoundingClientRect();return [r.left,r.width]})()")
        dir_x = pal[0] + pal[1] * 0.8; esq_x = pal[0] + pal[1] * 0.12; mid_y = H * 0.45
        pg.mouse.click(dir_x, mid_y); pg.wait_for_timeout(250)
        check(f'{nome}: toque à direita avança', pg.evaluate(CONT) == '3 / 4', pg.evaluate(CONT))
        pg.mouse.click(esq_x, mid_y); pg.wait_for_timeout(250)
        check(f'{nome}: toque à esquerda volta', pg.evaluate(CONT) == '2 / 4', pg.evaluate(CONT))
        pg.mouse.click(dir_x, mid_y); pg.mouse.click(dir_x, mid_y); pg.wait_for_timeout(150)
        check(f'{nome}: 4ª tela (Negócios)', pg.evaluate(CONT) == '4 / 4' and 'negócios' in pg.text_content('.ma-ab:not(.previa) h1 em'))
        pg.mouse.click(dir_x, mid_y); pg.wait_for_timeout(250)
        check(f'{nome}: depois da última, recomeça da 1ª', pg.evaluate(CONT) == '1 / 4')
        # deslizar
        pg.mouse.move(cx + 80, mid_y); pg.mouse.down(); pg.mouse.move(cx - 60, mid_y, steps=5); pg.mouse.up(); pg.wait_for_timeout(250)
        check(f'{nome}: deslizar para a esquerda avança', pg.evaluate(CONT) == '2 / 4', pg.evaluate(CONT))
        pg.mouse.move(cx - 80, mid_y); pg.mouse.down(); pg.mouse.move(cx + 60, mid_y, steps=5); pg.mouse.up(); pg.wait_for_timeout(250)
        check(f'{nome}: deslizar para a direita volta', pg.evaluate(CONT) == '1 / 4', pg.evaluate(CONT))
        # segurar pausa
        pg.mouse.move(cx, mid_y); pg.mouse.down(); pg.wait_for_timeout(500)
        w1 = pg.evaluate("document.querySelectorAll('.ma-ab:not(.previa) .ma-ab-barra i')[0].style.width"); pg.wait_for_timeout(3300)
        w2 = pg.evaluate("document.querySelectorAll('.ma-ab:not(.previa) .ma-ab-barra i')[0].style.width"); c2 = pg.evaluate(CONT)
        pg.mouse.up(); pg.wait_for_timeout(150)
        check(f'{nome}: segurar pausa (a barra para e a tela não troca)', w1 == w2 and c2 == '1 / 4' and pg.evaluate(CONT) == '1 / 4', (w1, w2, c2))
        if not mob:
            pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(100); a1 = pg.evaluate(CONT); pg.keyboard.press('ArrowLeft'); pg.wait_for_timeout(100)
            check('computador: setas do teclado trocam a tela', a1 == '2 / 4' and pg.evaluate(CONT) == '1 / 4', a1)
        if mob:
            # Criar conta → cadastro de sempre
            pg.click('.ma-ab:not(.previa) [data-ab=criar]'); pg.wait_for_url('**/cadastro', timeout=8000); pg.wait_for_timeout(600)
            check('iPhone: "Criar conta" abre o cadastro de sempre e a apresentação sai', pg.locator('.ma-ab:not(.previa)').count() == 0 and pg.locator('input[type=password]').count() >= 1)
            C.close(); C = b.new_context(base_url=BASE, **ctx); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(nome + ': ' + str(e)))
            pg.goto('/entrar'); pg.wait_for_selector('.ma-ab:not(.previa) .ma-ab-img.on', timeout=20000); pg.wait_for_function("()=>{const e=document.getElementById('ma-splash');return !e||e.classList.contains('out')}", timeout=8000); pg.wait_for_timeout(300)
        # Entrar → login de sempre, que funciona
        pg.click('.ma-ab:not(.previa) [data-ab=entrar]'); pg.wait_for_timeout(700)
        foco = pg.evaluate("document.activeElement&&document.activeElement.type")
        check(f'{nome}: "Entrar" mostra o login de sempre com o e-mail em foco', pg.locator('.ma-ab:not(.previa)').count() == 0 and pg.locator('input[type=email]').is_visible() and foco == 'email', foco)
        pg.reload(); pg.wait_for_timeout(3000)
        check(f'{nome}: na mesma sessão, a apresentação não volta a cada visita ao login', pg.locator('.ma-ab:not(.previa)').count() == 0)
        pg.fill('input[type=email]', 'admin.ab@t.com'); pg.fill('input[type=password]', U['password']); pg.keyboard.press('Enter')
        pg.wait_for_function("!/\\/entrar/.test(location.pathname)", timeout=15000); pg.wait_for_timeout(1500)
        check(f'{nome}: o login funciona normalmente depois da apresentação', '/entrar' not in pg.url and pg.locator('.ma-ab:not(.previa)').count() == 0, pg.url)
        C.close()
    # ---------------- painel ----------------
    print('== painel')
    M = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900}); M.add_cookies(A.cookies()); pg = M.new_page(); pg.on('pageerror', lambda e: errs.append('painel: ' + str(e)))
    pg.on('dialog', lambda d: d.accept())
    pg.goto('/admin'); aba(pg, 'abertura'); pg.wait_for_selector('#ab_prev .ma-ab.previa', timeout=15000)
    check('painel: Identidade e Aparência → Tela de abertura, com as 4 telas e a prévia (4 barras)', pg.locator('[data-abt]').count() == 4 and pg.locator('#ab_prev .ma-ab-barra').count() == 4)
    check('painel: busca global encontra a tela ("stories")', pg.evaluate("(window.__maAdmMapa&&window.__maAdmMapa('abertura')||{}).sub") == 'abertura')
    pg.fill('#ab_t', 'Sua rotina em ordem com o'); pg.wait_for_timeout(600)
    check('painel: prévia ao vivo mostra o título editado (rascunho)', 'Sua rotina em ordem' in pg.text_content('#ab_prev h1') and pg.locator('#ab_sujo').is_visible())
    pg.fill('#ab_d', 'Meu Assistente'); pg.fill('#ab_s', 'Tudo num só lugar.'); pg.wait_for_timeout(500)
    pg.click('[data-abon="2"]'); pg.wait_for_timeout(400)
    check('painel: desativar a 3ª tela tira ela da prévia (3 barras)', pg.locator('#ab_prev .ma-ab-barra').count() == 3)
    pg.click('[data-abup="3"]'); pg.wait_for_timeout(300)
    check('painel: reordenar (Negócios sobe)', 'negócios' in pg.locator('[data-abt]').nth(2).inner_text())
    pg.click('[data-absel="1"]'); pg.wait_for_timeout(200)
    pg.set_input_files('#ab_file', {'name': 'nova.png', 'mimeType': 'image/png', 'buffer': png((200, 40, 120))}); pg.wait_for_timeout(1200)
    src = pg.get_attribute('#ab_img', 'src') or ''
    check('painel: nova imagem escolhida aparece na edição (reduzida no navegador)', src.startswith('data:image/webp') or src.startswith('data:image/jpeg'), src[:40])
    pg.select_option('#ab_dur', '5'); pg.wait_for_timeout(200)
    pg.click('#ab_pub'); pg.wait_for_function("()=>!document.querySelector('#ab_sujo')||document.querySelector('#ab_sujo').hidden", timeout=10000); pg.wait_for_timeout(500)
    pv = A.request.get('/api/v2/abertura').json(); ts = pv['telas']
    check('publicado: 3 telas ativas na nova ordem, tempo 5 s', len(ts) == 3 and pv['duracao'] == 5 and ts[0]['titulo'] == 'Sua rotina em ordem com o' and ts[0]['destaque'] == 'Meu Assistente' and 'negócios' in ts[2]['destaque'], pv)
    up = ts[1]['imagem']; ri = A.request.get(up)
    check('publicado: a imagem enviada é servida pelo servidor (cache longo)', up.startswith('/api/v2/abertura/telas/') and ri.ok and ri.headers['content-type'].startswith('image/') and 'max-age=31536000' in ri.headers.get('cache-control', ''), (up, ri.status))
    V = b.new_context(base_url=BASE, **iphone); pv2 = V.new_page(); pv2.goto('/entrar'); pv2.wait_for_selector('.ma-ab:not(.previa) .ma-ab-img.on', timeout=20000); pv2.wait_for_timeout(2600)
    check('visitante vê o que foi publicado (3 barras, título novo, imagem enviada)', pv2.locator('.ma-ab:not(.previa) .ma-ab-barra').count() == 3 and 'Sua rotina em ordem' in pv2.text_content('.ma-ab:not(.previa) h1'))
    pv2.screenshot(path='/tmp/e2e/abertura_publicada.png'); V.close()
    pg.reload(); aba(pg, 'abertura'); pg.wait_for_selector('[data-abt]')
    check('persistido: o painel reabre com o que foi publicado', 'Sua rotina em ordem' in pg.locator('[data-abt]').nth(0).inner_text() and pg.locator('[data-abt]').nth(3).inner_text().count('desativada') == 1)
    pg.screenshot(path='/tmp/e2e/abertura_painel.png')
    # validação e permissões
    bad = R.put('/api/panel/abertura', data={'telas': [{'id': ts[0]['id'], 'imagem': 'data:image/png;base64,' + base64.b64encode(b'<html>x</html>').decode()}]})
    check('validação: arquivo que não é imagem é recusado', bad.status == 400, bad.status)
    bad2 = R.put('/api/panel/abertura', data={'telas': [{'id': 99999}]})
    check('validação: tela inexistente é recusada', bad2.status == 400)
    UC = b.new_context(base_url=BASE); assert UC.request.post('/api/auth', data={'action': 'signup', 'name': 'Comum Silva', 'whatsapp': '+55 85 95555-1371', 'email': 'comum.ab@t.com', **U}, headers={'X-Forwarded-For': '10.4.4.4'}).ok
    check('usuário comum não lê nem altera a configuração', UC.request.get('/api/panel/abertura').status == 403 and UC.request.put('/api/panel/abertura', data={'ativo': False}).status == 403 and UC.request.post('/api/panel/abertura/restaurar', data={}).status == 403)
    # restaurar
    pg.click('#ab_rest'); pg.wait_for_timeout(1500)
    pv = A.request.get('/api/v2/abertura').json()
    check('restaurar: volta às 4 telas originais (imagens, textos, ordem, tempo)', len(pv['telas']) == 4 and pv['duracao'] == 6 and [t['imagem'] for t in pv['telas']] == [f'/abertura/tela-{i}.webp' for i in range(1, 5)] and pv['telas'][0]['titulo'] == 'Seu assistente inteligente para', pv)
    # desligar tudo
    pg.click('#ab_on'); pg.click('#ab_pub'); pg.wait_for_timeout(1200)
    V = b.new_context(base_url=BASE, **iphone); pv3 = V.new_page(); pv3.goto('/entrar'); pv3.wait_for_timeout(3500)
    check('apresentação desligada: o visitante vai direto ao login de sempre', pv3.locator('.ma-ab:not(.previa)').count() == 0 and pv3.locator('input[type=email]').is_visible())
    V.close(); R.put('/api/panel/abertura', data={'ativo': True, 'telas': []})
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e.strip() not in ('Event',) and not e.endswith(': Event')], errs[:4])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
