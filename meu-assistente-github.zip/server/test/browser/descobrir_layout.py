# Descobrir (28/11) — nova organização: BUSCA no topo → banner rotativo → Produtos | Serviços no centro + menu ⋮ com
# localização/raio, "Só ofertas" e ordem (relevância, mais perto, mais recentes, menor e maior preço).
# iPhone (descritor do iPhone 13: tela, toque, escala) e computador: ordem dos blocos, campo com 16px (sem zoom do iOS),
# busca pelo teclado (Enter fecha o teclado), menu dentro da tela, teclado (setas/Esc), toque fora fecha, filtros aplicados
# de verdade, indicador de filtro ativo, Produtos ↔ Serviços preservando tudo, recomendações, sem rolagem lateral, sem erros.
# Servidor: PORT=4355 SQLITE_FILE=/tmp/ma-dsclay.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4355'; DBF = '/tmp/ma-dsclay.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def img(cor, w=400, h=300, fmt='JPEG'):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, fmt, quality=70); return f'data:image/{fmt.lower()};base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t or '').replace('\xa0', ' ')
PERTO = (-3.7319, -38.5267)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 85 94444-1355', 'email': 'ana.lay@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(empresa, cat, dlat, servicos=False):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': cat, 'titulo': empresa, 'texto': 'Perto de você', 'zap': '5585999990000'}); assert r.ok, r.text()
        i = r.json()['items'][0]['id']
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        if servicos: assert R.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=?, lat=?, lng=? where id=?", ((datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z', PERTO[0] + dlat, PERTO[1], i)); db.commit(); db.close()
        return i
    A = loja('Doces da Bia', 'Doceria', 0.004); S = loja('Studio Bela', 'Beleza', 0.01, True)
    for k, (nome, preco, of) in enumerate([('Bolo de Pote', 15, None), ('Brigadeiro Gourmet', 4, None), ('Torta de Limão', 60, 48), ('Pudim', 25, None), ('Cookie Recheado', 9, 7)]):
        d = {'nome': nome, 'preco': preco, 'categoria': 'Bolos' if k % 2 == 0 else 'Doces', 'fotos': [img((200, 90 + k * 20, 120))]}
        if of: d['oferta'] = {'ativo': True, 'preco': of}
        assert R.post(f'/api/v2/ads/{A}/products', data=d).ok, nome
    for nome, preco in [('Corte Feminino', 80), ('Escova', 45)]:
        assert R.post(f'/api/v2/ads/{S}/products', data={'nome': nome, 'preco': preco, 'tipo': 'servico', 'modoPreco': 'fixo', 'duracao': 60}).ok
    assert R.post('/api/panel/descobrir/banners', data={'imagem': img((40, 120, 200), 1200, 600, 'PNG'), 'titulo': 'Doces artesanais', 'botao': 'Ver doces', 'destinoTipo': 'categoria', 'destinoValor': 'produtos|Doces', 'ordem': 1, 'duracao': 4}).ok
    iphone = {**p.devices['iPhone 13']}; iphone.pop('default_browser_type', None)
    for nome, ctx in [('iPhone', iphone), ('computador', {'viewport': {'width': 1280, 'height': 900}})]:
        print('==', nome); mob = nome == 'iPhone'
        C = b.new_context(base_url=BASE, **ctx); RC = C.request
        assert RC.post('/api/auth', data={'action': 'signup', 'name': 'Rui Cliente', 'whatsapp': '+55 85 95555-13' + ('01' if mob else '02'), 'email': f'rui.lay.{nome}@t.com', **U}, headers={'X-Forwarded-For': '10.9.5.' + ('1' if mob else '2')}).ok
        assert RC.put('/api/v2/me/location', data={'lat': PERTO[0], 'lng': PERTO[1]}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(nome + ': ' + str(e)))
        pg.goto('/x/empresas?modo=produtos'); pg.wait_for_selector('[data-mk]', timeout=20000); pg.wait_for_timeout(1500)
        g = pg.evaluate("""()=>{const R=s=>{const e=document.querySelector(s);return e?e.getBoundingClientRect():null},q=R('#dsc-q'),bn=R('.ma-bn'),bar=R('.ma-dsc-bar'),seg=R('.ma-seg'),mb=R('[data-dsc-mais]'),i=document.querySelector('#dsc-q input'),cs=getComputedStyle(i);
          return {q:q&&q.top,bn:bn&&bn.top,bnB:bn&&bn.bottom,bar:bar&&bar.top,segC:seg&&(seg.left+seg.right)/2,barC:bar&&(bar.left+bar.right)/2,mbR:mb&&mb.right,barR:bar&&bar.right,mbW:mb&&mb.width,font:parseFloat(cs.fontSize),tipo:i.type,eh:i.getAttribute('enterkeyhint'),
          meta:(document.querySelector('meta[name=viewport]')||{}).content||'',lado:document.documentElement.scrollWidth-innerWidth}}""")
        check(f'{nome}: ordem da página: busca no topo → banner → Produtos | Serviços', g['q'] is not None and g['bn'] is not None and g['q'] < g['bn'] and g['bnB'] <= g['bar'] + 1, g)
        check(f'{nome}: campo de busca com 16px ou mais (o iPhone não dá zoom ao tocar), tipo busca e tecla "buscar"', g['font'] >= 16 and g['tipo'] == 'search' and g['eh'] == 'search', g)
        check(f'{nome}: Produtos | Serviços centralizados na barra', abs(g['segC'] - g['barC']) <= 2, g)
        check(f'{nome}: menu ⋮ discreto à direita, área de toque ≥ 40px', abs(g['mbR'] - g['barR']) <= 2 and g['mbW'] >= 40, g)
        tabs = [N(x.inner_text()) for x in pg.locator('[data-modo]').all()]
        check(f'{nome}: Produtos e Serviços como opções principais', 'Produtos' in tabs and 'Serviços' in tabs, tabs)
        vis = pg.evaluate("()=>[...document.querySelectorAll('[data-locbtn],[data-ofertas],[data-ord],#pord,.ma-locbtn')].filter(e=>e.offsetParent).length")
        check(f'{nome}: localização, ofertas e ordem fora da área principal (só no menu)', vis == 0 and pg.locator('#dsc-body [data-ofertas], #pord').count() == 0, vis)
        check(f'{nome}: categorias, banner e cards preservados', pg.locator('[data-cats] [data-cat]').count() >= 3 and pg.locator('.ma-bn-s').count() == 1 and pg.locator('[data-mk]').count() == 5)
        pg.wait_for_timeout(2500); pg.screenshot(path=f'/tmp/e2e/dsclay_{nome}.png')
        # ---- busca pelo teclado ----
        pg.tap('#dsc-q input') if mob else pg.click('#dsc-q input')
        foco = pg.evaluate("document.activeElement===document.querySelector('#dsc-q input')")
        esc = pg.evaluate('visualViewport?visualViewport.scale:1')
        pg.keyboard.type('torta'); pg.keyboard.press('Enter'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===1", timeout=8000)
        check(f'{nome}: tocar na busca foca sem zoom; Enter busca e fecha o teclado', foco and esc == 1 and 'Torta' in pg.inner_text('[data-mkgrid]') and not pg.evaluate("document.activeElement===document.querySelector('#dsc-q input')"), (foco, esc))
        pg.click('[data-modo=servicos]'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===2", timeout=8000)
        check(f'{nome}: em Serviços a busca é outra (campo vazio, placeholder de serviços)', pg.input_value('#dsc-q input') == '' and 'serviços' in (pg.get_attribute('#dsc-q input', 'placeholder') or ''))
        pg.click('[data-modo=produtos]'); pg.wait_for_selector('[data-mk]')
        check(f'{nome}: voltar a Produtos mantém a busca "torta"', pg.input_value('#dsc-q input') == 'torta' and pg.locator('[data-mk]').count() == 1)
        pg.fill('#dsc-q input', ''); pg.press('#dsc-q input', 'Enter'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===5", timeout=8000)
        # ---- menu ⋮ ----
        pg.click('[data-dsc-mais]'); pg.wait_for_selector('#dsc-pop:not([hidden])')
        m = pg.evaluate("""()=>{const p=document.querySelector('#dsc-pop'),r=p.getBoundingClientRect();return {l:r.left,r:r.right,t:r.top,b:r.bottom,w:innerWidth,h:innerHeight,exp:document.querySelector('[data-dsc-mais]').getAttribute('aria-expanded'),
          ords:[...p.querySelectorAll('[data-ord]')].map(x=>x.dataset.ord),of:!!p.querySelector('[data-ofertas]'),loc:(p.querySelector('[data-loclbl]')||{}).textContent,foco:document.activeElement&&document.activeElement.dataset.ord}}""")
        check(f'{nome}: menu abre dentro da tela (sem corte)', m['l'] >= 0 and m['r'] <= m['w'] and m['b'] <= m['h'] and m['exp'] == 'true', m)
        check(f'{nome}: menu com localização e raio, "Só ofertas" e as 5 ordens', m['ords'] == ['relevancia', 'proximos', 'recentes', 'menor', 'maior'] and m['of'] and 'km' in N(m['loc']), m)
        check(f'{nome}: foco vai para a ordem selecionada (teclado)', m['foco'] == 'relevancia', m)
        pg.keyboard.press('ArrowDown'); check(f'{nome}: setas navegam no menu', pg.evaluate("document.activeElement.dataset.ord") == 'proximos')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
        check(f'{nome}: Esc fecha e devolve o foco ao ⋮', pg.locator('#dsc-pop').is_hidden() and pg.evaluate("document.activeElement===document.querySelector('[data-dsc-mais]')"))
        pg.click('[data-dsc-mais]'); pg.wait_for_selector('#dsc-pop:not([hidden])'); pg.click('#dsc-q svg', force=True); pg.wait_for_timeout(200)
        check(f'{nome}: tocar fora fecha o menu', pg.locator('#dsc-pop').is_hidden())
        # ordem
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ord=menor]'); pg.wait_for_timeout(1000)
        pr = [N(x.inner_text()) for x in pg.locator('[data-mk-preco] b').all()]
        check(f'{nome}: "Menor preço" aplicado de verdade', pr[:3] == ['R$ 4,00', 'R$ 7,00', 'R$ 15,00'] and pg.locator('#dsc-pop').is_hidden(), pr)
        check(f'{nome}: ⋮ mostra um ponto quando há filtro/ordem diferente do padrão', pg.locator('[data-dsc-mais] .dot').is_visible())
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ord=recentes]'); pg.wait_for_timeout(1000)
        nm = [N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()]
        check(f'{nome}: "Mais recentes": cadastro mais novo primeiro', nm[:2] == ['Cookie Recheado', 'Pudim'], nm)
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ofertas]'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===2", timeout=8000)
        check(f'{nome}: "Só ofertas" filtra (2 em oferta) e fica marcado', all(x.locator('[data-oferta]').count() == 1 for x in pg.locator('[data-mk]').all()) and pg.get_attribute('#dsc-pop [data-ofertas]', 'aria-checked') == 'true')
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ofertas]'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===5", timeout=8000)
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ord=relevancia]'); pg.wait_for_timeout(800)
        check(f'{nome}: voltar ao padrão apaga o ponto', not pg.locator('[data-dsc-mais] .dot').is_visible())
        # Serviços: sem serviço em oferta, "Só ofertas" não aparece; ordem própria de cada aba
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-ord=maior]'); pg.wait_for_timeout(800)
        pg.click('[data-modo=servicos]'); pg.wait_for_function("()=>document.querySelectorAll('[data-mk]').length===2", timeout=8000); pg.wait_for_timeout(400)
        pg.click('[data-dsc-mais]'); pg.wait_for_selector('#dsc-pop:not([hidden])')
        check(f'{nome}: Serviços: menu sem "Só ofertas" (nenhum serviço em oferta) e com a ordem da própria aba', pg.locator('#dsc-pop [data-ofertas]').count() == 0 and pg.get_attribute('#dsc-pop [data-ord=relevancia]', 'aria-checked') == 'true')
        pg.keyboard.press('Escape')
        pg.click('[data-modo=produtos]'); pg.wait_for_selector('[data-mk]'); pg.wait_for_timeout(700)
        check(f'{nome}: Produtos mantém a ordem escolhida (maior preço)', N(pg.locator('[data-mk-preco] b').first.inner_text()) == 'R$ 48,00' or N(pg.locator('[data-mk-preco] b').first.inner_text()) == 'R$ 60,00', pg.locator('[data-mk-preco] b').first.inner_text())
        # localização pelo menu
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-locbtn]'); pg.wait_for_selector('[data-locpainel]', timeout=8000)
        fs = pg.evaluate("[...document.querySelectorAll('[data-locpainel] input,[data-locpainel] select')].map(e=>parseFloat(getComputedStyle(e).fontSize))")
        check(f'{nome}: "Localização e distância" abre o painel de sempre (campos com 16px, sem zoom)', fs and min(fs) >= 16 and pg.locator('#lraio').count() == 1, fs)
        pg.select_option('#lraio', '1'); pg.click('#lapl'); pg.wait_for_timeout(1500)
        check(f'{nome}: raio aplicado aparece no menu', '1 km' in N(pg.text_content('[data-loclbl]')), pg.text_content('[data-loclbl]'))
        pg.click('[data-dsc-mais]'); pg.click('#dsc-pop [data-locbtn]'); pg.wait_for_selector('#lraio'); pg.select_option('#lraio', '15'); pg.click('#lapl'); pg.wait_for_timeout(1200)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if mob:
            pg.evaluate('scrollTo(0,0)'); pg.wait_for_timeout(300); pg.click('[data-dsc-mais]'); pg.wait_for_timeout(250); pg.screenshot(path='/tmp/e2e/dsclay_menu_iphone.png'); pg.keyboard.press('Escape')
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and not e.endswith('Event')], errs[:3])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
