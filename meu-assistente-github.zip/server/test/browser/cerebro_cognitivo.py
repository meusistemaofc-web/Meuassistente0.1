# Cérebro cognitivo: resposta honesta no chat (ação não confirmada), avaliação registrada, painel do administrador
# (chave, ajustes, números), cartão em Capacidades e volta ao comportamento anterior quando desligado.
import sys
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    ctx=b.new_context(viewport={'width':430,'height':900},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    def enviar(t):
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2500)
    def painel():
        pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_cognicao'); pg.wait_for_selector('#cog_box [data-cogsw]',timeout=10000)
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('xqz-cog-afirma por favor')
    corpo=pg.inner_text('body')
    check('o chat NÃO afirma uma ação que nenhuma ferramenta executou', 'Agendei sua reunião' not in corpo and 'não registrei nada' in corpo, corpo[-400:])
    enviar('oi, tudo bem?')
    check('conversa normal segue natural (texto da IA intacto)', 'Como posso ajudar?' in pg.inner_text('body'))
    st=R.get('/api/panel/cognicao').json()
    check('cada resposta foi avaliada (só notas)', st['total']>=2 and st['medias']['precisao'] is not None and any(s['flag']=='acao_nao_confirmada' for s in st['sinalizacoes']), st)
    check('o painel não expõe texto das conversas', 'Agendei' not in str(st) and 'tudo bem' not in str(st))
    # painel do administrador
    painel()
    box=pg.inner_text('#cog_box')
    check('painel mostra status, notas e sinalizações', 'Cérebro cognitivo' in box and 'Ligado' in box and 'Nota geral' in box and 'Ação afirmada sem confirmação' in box and 'Precisão' in box, box[:400])
    check('quatro chaves (geral, ações, tom, sensíveis)', pg.locator('#cog_box [data-cogsw]').count()==4)
    pg.locator('#cog_box [data-cogsw=humanizar]').click(); pg.wait_for_timeout(1200)
    check('desligar "Tom natural" grava no servidor', R.get('/api/panel/cognicao').json()['config']['humanizar'] is False and pg.locator('#cog_box [data-cogsw=humanizar]').get_attribute('aria-checked')=='false')
    pg.locator('#cog_box [data-cogsw=humanizar]').click(); pg.wait_for_timeout(1200)
    check('religar "Tom natural"', R.get('/api/panel/cognicao').json()['config']['humanizar'] is True)
    # cartão em Capacidades (Cérebro Central → Conhecimento operacional, na Administração em seções)
    aba(pg,'cb_conhecimento'); pg.wait_for_selector('#cap_l [data-cap]',timeout=10000); c=pg.locator('[data-cap=cerebro-cognitivo]')
    check('capacidade aparece no Cérebro', c.count()==1 and 'Cérebro cognitivo' in c.inner_text() and c.locator('[data-agtog]').count()==1, c.inner_text()[:200] if c.count() else '')
    c.locator('[data-agtog]').click(); pg.wait_for_timeout(1300)
    check('desligar a capacidade grava no servidor e o painel reflete', R.get('/api/panel/cognicao').json()['ativo'] is False and 'Desligada pelo administrador' in pg.locator('[data-cap=cerebro-cognitivo]').inner_text() and 'Desligado' in pg.inner_text('#cog_box'))
    # desligado: comportamento anterior
    antes=R.get('/api/panel/cognicao').json()['total']
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1200); enviar('xqz-cog-afirma por favor')
    check('desligado: volta exatamente ao comportamento anterior e nada é avaliado', 'Agendei sua reunião' in pg.inner_text('body') and R.get('/api/panel/cognicao').json()['total']==antes)
    pg.goto('/admin'); aba(pg,'cb_conhecimento'); pg.wait_for_selector('#cap_l [data-cap]',timeout=10000); pg.locator('[data-cap=cerebro-cognitivo] [data-agtog]').click(); pg.wait_for_timeout(1300)
    aba(pg,'cb_cognicao'); pg.wait_for_selector('#cog_box [data-cogsw]',timeout=10000)
    check('religar pela capacidade (a Cognição mostra Ligado)', R.get('/api/panel/cognicao').json()['ativo'] is True and 'Ligado' in pg.inner_text('#cog_box'))
    pg.locator('#cog_box [data-cogsw=ativo]').click(); pg.wait_for_timeout(1300)
    aba(pg,'cb_conhecimento'); pg.wait_for_selector('[data-cap=cerebro-cognitivo]',timeout=10000)
    check('desligar pela chave do quadro atualiza o cartão da capacidade', R.get('/api/panel/cognicao').json()['ativo'] is False and 'Desligada pelo administrador' in pg.locator('[data-cap=cerebro-cognitivo]').inner_text())
    aba(pg,'cb_cognicao'); pg.wait_for_selector('#cog_box [data-cogsw]',timeout=10000)
    pg.locator('#cog_box [data-cogsw=ativo]').click(); pg.wait_for_timeout(1300)
    check('religar pela chave do quadro', R.get('/api/panel/cognicao').json()['ativo'] is True)
    # layout
    for w,h in [(430,900),(1280,800)]:
        pg.set_viewport_size({'width':w,'height':h}); painel(); pg.wait_for_timeout(500)
        ov=pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,bx:document.querySelector('#cog_box').scrollWidth,bc:document.querySelector('#cog_box').clientWidth})")
        check(f'sem rolagem horizontal em {w}px', ov['sw']<=ov['cw']+1 and ov['bx']<=ov['bc']+1, ov)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/cerebro_cognitivo.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
