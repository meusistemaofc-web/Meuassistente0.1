# Fase 7 — Inteligência preditiva pela tela real.
# Usuário: atalho no Perfil → "Previsões e sugestões" (fato × estimativa, urgência, base), reações (útil, dispensar,
# "não faz sentido"), "pedir no chat" preenche a caixa sem enviar, preferências (categorias, canais, frequência, silêncio).
# Administrador: painel com indicadores agregados, validação (cenários + retroteste) e tipos de sinal.
import sys, json, datetime as dt
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4311'
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-0000', 'email': 'adm@t.com', 'birthday': '1980-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    ctx = b.new_context(viewport={'width': 390, 'height': 860}, base_url=BASE); R = ctx.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.8.0.2'}).ok
    hoje = R.get('/api/agenda').json()['today']; D = lambda n: (dt.date.fromisoformat(hoje) + dt.timedelta(days=n)).isoformat()
    ap = lambda d: R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': d}).json()['item']['id']
    a1 = ap({'title': 'Reunião com fornecedor', 'date': D(1), 'time': '14:00', 'duracao_min': 90}); a2 = ap({'title': 'Dentista', 'date': D(1), 'time': '15:00'})
    a3 = ap({'title': 'Tatuagem', 'date': D(2), 'time': '16:00', 'cliente_nome': 'José'})
    R.post('/api/items', data={'action': 'create', 'type': 'bill', 'data': {'name': 'Aluguel', 'amount': 1500, 'due_date': D(-3), 'category': 'casa'}})
    antes = json.dumps(R.get('/api/agenda').json()['appointments'], sort_keys=True)
    pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/perfil'); pg.wait_for_selector('section#previsoes .ma-prev-link', timeout=20000)
    check('atalho no Perfil (Configurações)', pg.locator('section#previsoes .ma-prev-link').count() == 1)
    pg.locator('section#previsoes .ma-prev-link').click(); pg.wait_for_url('**/previsoes'); pg.wait_for_selector('.sinal', timeout=20000)
    lista = pg.inner_text('#lista')
    check('conflito de horário como FATO e urgente', pg.locator(f'[data-chave="conflito:{a1}:{a2}"]').count() == 1 and 'Fato' in pg.locator(f'[data-chave="conflito:{a1}:{a2}"]').inner_text() and 'Urgente' in pg.locator(f'[data-chave="conflito:{a1}:{a2}"]').inner_text(), lista[:300])
    js = pg.locator(f'[data-chave="sem_contato:{a3}"]')
    check('sem telefone + confirmar consolidados num só aviso', js.count() == 1 and 'também: confirmar com o cliente' in js.inner_text().lower(), js.inner_text() if js.count() else lista[:300])
    check('grupos por categoria e conta atrasada', 'COMPROMISSOS' in lista.upper() and 'FINANÇAS' in lista.upper() and 'Conta atrasada: Aluguel' in lista)
    check('resumo com fatos e estimativas', 'urgente' in pg.inner_text('#resumo') and 'fato' in pg.inner_text('#resumo'))
    check('diz onde faltam dados', pg.locator('#lacunas').is_visible() and len(pg.inner_text('#lac')) > 10, pg.inner_text('#lac') if pg.locator('#lac').count() else '')
    # reação: "não faz sentido" some e não volta
    pg.locator(f'[data-chave="sem_contato:{a3}"] [data-a="falso"]').click(); pg.wait_for_timeout(800)
    check('“não faz sentido” remove o aviso', pg.locator(f'[data-chave="sem_contato:{a3}"]').count() == 0)
    pg.reload(); pg.wait_for_selector('.sinal')
    check('e não volta depois de recarregar', pg.locator(f'[data-chave="sem_contato:{a3}"]').count() == 0)
    # preferências
    pg.locator('[data-cat="financas"]').click(); pg.wait_for_timeout(1200)
    check('desligar uma categoria', 'Conta atrasada' not in pg.inner_text('#lista') and R.get('/api/me/previsoes').json()['preferencias']['categorias']['financas'] is False)
    pg.locator('[data-cat="financas"]').click(); pg.wait_for_timeout(1000)
    pg.select_option('#freq', 'baixa'); pg.wait_for_timeout(900)
    pg.fill('#sde', '21:00'); pg.locator('#sde').dispatch_event('change'); pg.wait_for_timeout(900)
    pr = R.get('/api/me/previsoes').json()['preferencias']
    check('frequência e horário de silêncio salvos', pr['frequencia'] == 'baixa' and pr['silencio']['de'] == '21:00', pr)
    pg.locator('[data-pri="clientes"]').click(); pg.wait_for_timeout(900)
    check('prioridade do usuário', 'clientes' in R.get('/api/me/previsoes').json()['preferencias']['prioridades'])
    check('nenhum compromisso alterado pelas previsões', json.dumps(R.get('/api/agenda').json()['appointments'], sort_keys=True) == antes)
    for w, h in [(390, 860), (1280, 900)]:
        pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(300)
        ov = pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
        check(f'página sem rolagem horizontal em {w}px', ov['sw'] <= ov['cw'] + 1, ov)
    pg.set_viewport_size({'width': 390, 'height': 860}); pg.screenshot(path='/tmp/e2e/previsoes.png', full_page=False)
    # "pedir no chat": preenche a caixa e NÃO envia
    href = pg.locator(f'[data-chave="conflito:{a1}:{a2}"] [data-chat]').get_attribute('href')
    n0 = len(R.get('/api/conversations').json().get('conversations', [])) if R.get('/api/conversations').ok else None
    pg.goto(href); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1500)
    val = pg.eval_on_selector('textarea.composer-input', 'e=>e.value')
    check('“pedir no chat” preenche a caixa sem enviar', 'remarcar o compromisso "Dentista"' in val and '?m=' not in pg.url and (n0 is None or len(R.get('/api/conversations').json().get('conversations', [])) == n0), (val, pg.url))
    # administrador
    pa = adm.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(1500); pa.get_by_role('button', name='Cérebro e busca').click(); pa.wait_for_selector('#pd_tiles', timeout=20000)
    t = pa.inner_text('#pd_box')
    check('painel: alertas, aceitas, falsos, previsões e precisão', all(x in t for x in ['Alertas apresentados', 'Recomendações aceitas', 'Falsos alertas', 'Previsões realizadas', 'Precisão das previsões']) and 'José' not in t and 'Dentista' not in t, t[:300])
    pa.click('#pd_validar'); pa.wait_for_selector('#pd_val', timeout=60000)
    check('validação pelo painel (cenários + retroteste)', 'cobertura 100%' in pa.inner_text('#pd_val') and 'precisão 100%' in pa.inner_text('#pd_val') and 'não inventa previsões sem dados' in pa.inner_text('#pd_val'), pa.inner_text('#pd_val'))
    check('falso alerta contado no painel', A.get('/api/panel/preditivo').json()['alertas']['falsos'] >= 1)
    pa.locator('#pd_box summary').click(); pa.locator('[data-pdtipo="conflito"]').uncheck(); pa.wait_for_timeout(1200)
    check('administrador desliga um tipo para todos', not any(s['tipo'] == 'conflito' for s in R.get('/api/me/previsoes').json()['sinais']))
    pa.wait_for_selector('[data-pdtipo="conflito"]', state='attached'); pa.locator('#pd_box summary').click(); pa.locator('[data-pdtipo="conflito"]').check(); pa.wait_for_timeout(1200)
    check('e religa', any(s['tipo'] == 'conflito' for s in R.get('/api/me/previsoes').json()['sinais']))
    pa.locator('#pd_box').screenshot(path='/tmp/e2e/preditivo_painel.png')
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
