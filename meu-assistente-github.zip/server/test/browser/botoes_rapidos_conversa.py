import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'sugestoes':True}).ok
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        # configuração do painel: itens personalizados (só no celular, para cobrir os dois modos)
        assert R.put('/api/panel/quick_buttons',data={'enabled':True,'custom':mobile,'items':['Atalho um','Atalho dois','Atalho três']}).ok
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        vis=lambda: pg.locator('.ma-qb-item:visible').count()
        def novo():
            if not pg.locator('a[aria-label="Chat"]:visible').count(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(500)
            pg.locator('a[aria-label="Chat"]:visible').first.click(); pg.wait_for_timeout(1200)
        def enviar(t):
            ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2500)
        pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=20000); pg.wait_for_timeout(1500)
        n0=vis(); check(f'{nome}: chat novo mostra os botões', n0>=3, n0)
        # desaparecimento imediato (antes mesmo da resposta) ao selecionar um botão rápido
        r=pg.evaluate("()=>{const b=document.querySelector('.ma-qb-item');b.click();return document.querySelectorAll('.ma-qb-item').length&&[...document.querySelectorAll('.ma-qb-item')].filter(x=>x.offsetParent!==null).length}"); check(f'{nome}: selecionar um botão oculta todos imediatamente (mesmo instante do clique)', r==0, r)
        pg.wait_for_timeout(2500)
        novo(); pg.wait_for_selector('.ma-qb-item',timeout=10000); pg.wait_for_timeout(500); check(f'{nome}: nova conversa depois de usar um botão restaura todos', vis()==n0, (vis(),n0))
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type('Mensagem manual'); pg.keyboard.press('Enter'); pg.wait_for_timeout(120)
        check(f'{nome}: enviar mensagem manual oculta os botões na hora', vis()==0, vis()); pg.wait_for_timeout(2500)
        novo(); pg.wait_for_selector('.ma-qb-item',timeout=10000); pg.wait_for_timeout(500)
        enviar('Primeira conversa: oi')
        check(f'{nome}: primeira mensagem oculta os botões', vis()==0)
        check(f'{nome}: não sobra espaço vazio (sem contêiner dos botões)', pg.evaluate("()=>{const b=document.querySelector('.chat-scroll .mt-7');return !b||b.getBoundingClientRect().height===0}"))
        enviar('Segunda mensagem'); check(f'{nome}: continua oculto na continuação', vis()==0)
        pg.reload(); pg.wait_for_timeout(3500); check(f'{nome}: continua oculto ao reabrir a mesma conversa', vis()==0)
        novo(); pg.wait_for_selector('.ma-qb-item',timeout=15000)
        check(f'{nome}: novo chat restaura os botões', vis()==n0, (vis(),n0))
        texto=[x.strip() for x in pg.locator('.ma-qb-item:visible').all_inner_texts()]
        if mobile: check(f'{nome}: com a configuração atual do painel (ordem)', texto[:3]==['Atalho um','Atalho dois','Atalho três'], texto)
        # mudar o painel e abrir outro chat novo: vale a configuração atualizada
        assert R.put('/api/panel/quick_buttons',data={'enabled':True,'custom':True,'items':['Só este']}).ok
        enviar('Segunda conversa: oi')
        check(f'{nome}: ocultou também na segunda conversa', vis()==0)
        novo(); pg.wait_for_timeout(500)
        pg.reload(); pg.wait_for_timeout(3000)
        if vis()==0: novo()
        pg.wait_for_selector('.ma-qb-item',timeout=15000)
        texto=[x.strip() for x in pg.locator('.ma-qb-item:visible').all_inner_texts()]
        check(f'{nome}: novo chat usa a configuração atualizada do painel', texto==['Só este'], texto)
        # independência: abrir a 1ª conversa pelo histórico mantém botões ocultos, e o chat novo segue com botões
        if not pg.get_by_text('Primeira conversa: oi').first.is_visible(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(600)
        pg.get_by_text('Primeira conversa: oi').first.click(); pg.wait_for_timeout(1800)
        check(f'{nome}: conversa antiga aberta pelo histórico não mostra botões', vis()==0)
        novo(); pg.wait_for_timeout(800)
        check(f'{nome}: novo chat depois de abrir conversa antiga mostra botões', vis()>=1, vis())
        # desligar no painel: nenhum botão em chat novo
        assert R.put('/api/panel/quick_buttons',data={'enabled':False,'custom':True,'items':['Só este']}).ok
        pg.reload(); pg.wait_for_timeout(3000)
        if mobile: pass
        novo(); pg.wait_for_timeout(600); check(f'{nome}: painel desligado não mostra botões em chat novo', vis()==0)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
