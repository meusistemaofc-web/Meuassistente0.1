# Agenda → Compromissos: visualização em CALENDÁRIO (celular e computador).
# Ícone ao lado de "+ Compromisso"; mês com indicadores; navegação entre meses; "Hoje"; seleção de dia; abrir detalhes;
# inclusão/edição/exclusão refletidas no calendário e na lista (mesmo cadastro); isolamento entre usuários; a lista
# continua sendo a visualização padrão.
# Servidor: PORT=4314 SQLITE_FILE=/tmp/ma-cal.db npx tsx test/serve-sqlite.ts (banco novo)
import datetime as dt
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4314'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
MES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.cal@t.com', **U}).ok
    hoje = RA.get('/api/agenda').json()['today']; H = dt.date.fromisoformat(hoje)
    D = lambda n: (H + dt.timedelta(days=n)).isoformat()
    prox_mes = (H.replace(day=1) + dt.timedelta(days=32)).replace(day=10).isoformat()
    cria = lambda R, t, d, h, **kw: R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': t, 'date': d, 'time': h, **kw}}).json()['item']['id']
    i1 = cria(RA, 'Corte de cabelo', hoje, '14:00', cliente_nome='Bruno', location='Studio')
    i2 = cria(RA, 'Reunião de equipe', hoje, '09:30')
    i3 = cria(RA, 'Dentista', prox_mes, '16:15', location='Clínica Sorriso')
    # outro usuário com compromisso no mesmo dia: nunca aparece para a Ana
    B = b.new_context(base_url=BASE); RB = B.request
    assert RB.post('/api/auth', data={'action': 'signup', 'name': 'Bia Outra', 'whatsapp': '+55 11 95555-0001', 'email': 'bia.cal@t.com', **U}, headers={'X-Forwarded-For': '10.8.8.8'}).ok
    cria(RB, 'Compromisso da Bia', hoje, '10:00')
    check('API: intervalo de datas devolve só os do próprio usuário', [x['title'] for x in RA.get(f'/api/v2/compromissos?de={hoje}&ate={hoje}').json()['compromissos']] == ['Reunião de equipe', 'Corte de cabelo'] and RB.get(f'/api/v2/compromissos?de={hoje}&ate={hoje}').json()['total'] == 1)
    check('API: sem intervalo, a resposta é a mesma de antes (lista)', 'periodo' in RA.get('/api/v2/compromissos').json())
    for nome, vp in [('computador', {'width': 1280, 'height': 860}), ('celular', {'width': 390, 'height': 844})]:
        print('==', nome)
        ctx = A if nome == 'celular' else b.new_context(viewport=vp, base_url=BASE, storage_state=A.storage_state())
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/agenda?tab=compromissos'); pg.wait_for_selector('.ma-cal-btn', timeout=20000); pg.wait_for_timeout(500)
        ic = pg.locator('.ma-cal-btn'); add = ic.locator('xpath=following-sibling::button[1]')
        bi, ba = ic.bounding_box(), add.bounding_box()
        check(f'{nome}: ícone de calendário imediatamente ao lado de "+ Compromisso", sem texto', ic.count() == 1 and add.inner_text().strip() == 'Compromisso' and ic.inner_text().strip() == '' and abs(bi['y'] + bi['height'] / 2 - (ba['y'] + ba['height'] / 2)) < 2 and 0 <= ba['x'] - (bi['x'] + bi['width']) <= 12, (bi, ba))
        check(f'{nome}: ícone discreto (menor que o botão de adicionar)', bi['width'] <= 40 and bi['width'] < ba['width'])
        check(f'{nome}: a lista continua sendo a visualização padrão', pg.locator('.ma-cal').count() == 0 and 'Corte de cabelo' in pg.inner_text('main'))
        pg.wait_for_function("()=>document.body.innerText.includes('Corte de cabelo')||document.body.innerText.includes('Reunião')", timeout=15000); pg.wait_for_timeout(800); pg.screenshot(path=f'/tmp/e2e/cal_{nome}_lista.png')
        ic.click(); pg.wait_for_selector('.ma-cal .ma-cal-d', timeout=8000); pg.wait_for_function("()=>!document.querySelector('.ma-cal-carr.on')", timeout=8000); pg.wait_for_timeout(200)
        check(f'{nome}: abre o mês atual', pg.inner_text('.ma-cal-mes').strip().lower() == f'{MES[H.month - 1]} {H.year}', pg.inner_text('.ma-cal-mes'))
        dh = pg.locator(f'.ma-cal-d[data-d="{hoje}"]')
        check(f'{nome}: hoje destacado e com indicador (2 pontos)', 'hj' in dh.get_attribute('class') and dh.locator('.ma-cal-pts i').count() == 2)
        semev = pg.locator(f'.ma-cal-d[data-d="{D(1)}"] .ma-cal-pts i').count() if D(1)[:7] == hoje[:7] else 0
        check(f'{nome}: dia sem compromisso não tem indicador', semev == 0)
        lst = pg.inner_text('.ma-cal-lst')
        check(f'{nome}: dia selecionado mostra horário, título e informações (em ordem de horário)', lst.index('09:30') < lst.index('14:00') and 'Reunião de equipe' in lst and 'Bruno · Studio' in lst and 'Compromisso da Bia' not in lst, lst)
        pg.screenshot(path=f'/tmp/e2e/cal_{nome}_mes.png')
        # próximo mês
        pg.click('[data-prox]'); pg.wait_for_timeout(200); pg.wait_for_function("()=>!document.querySelector('.ma-cal-carr.on')", timeout=8000)
        P = dt.date.fromisoformat(prox_mes)
        check(f'{nome}: navega para o próximo mês', pg.inner_text('.ma-cal-mes').strip().lower() == f'{MES[P.month - 1]} {P.year}')
        check(f'{nome}: indicador no dia do dentista', pg.locator(f'.ma-cal-d[data-d="{prox_mes}"] .ma-cal-pts i').count() == 1)
        pg.click(f'.ma-cal-d[data-d="{prox_mes}"]'); pg.wait_for_timeout(200)
        check(f'{nome}: selecionar o dia lista o compromisso', 'Dentista' in pg.inner_text('.ma-cal-lst') and '16:15' in pg.inner_text('.ma-cal-lst'))
        # abrir detalhes (painel que já existe)
        pg.click('.ma-cal-it'); pg.wait_for_selector(f'[data-appt-id="{i3}"]', timeout=8000)
        check(f'{nome}: abre os detalhes do compromisso', 'Dentista' in pg.inner_text(f'[data-appt-id="{i3}"]') and 'Clínica Sorriso' in pg.inner_text(f'[data-appt-id="{i3}"]'))
        pg.screenshot(path=f'/tmp/e2e/cal_{nome}_detalhe.png')
        pg.click('.ma-sheet-x'); pg.wait_for_timeout(300)
        # voltar dois meses e "Hoje"
        pg.click('[data-ant]'); pg.wait_for_timeout(150); pg.click('[data-ant]'); pg.wait_for_timeout(300)
        check(f'{nome}: navega para meses anteriores', pg.inner_text('.ma-cal-mes').strip().lower() != f'{MES[H.month - 1]} {H.year}')
        pg.click('[data-hoje]'); pg.wait_for_timeout(200); pg.wait_for_function("()=>!document.querySelector('.ma-cal-carr.on')", timeout=8000)
        check(f'{nome}: "Hoje" volta para a data atual', pg.inner_text('.ma-cal-mes').strip().lower() == f'{MES[H.month - 1]} {H.year}' and 'sel' in pg.locator(f'.ma-cal-d[data-d="{hoje}"]').get_attribute('class'))
        if nome == 'celular':
            # deslizar troca o mês
            g = pg.locator('.ma-cal-grid').bounding_box()
            pg.evaluate("""([x,y])=>{const g=document.querySelector('.ma-cal-grid');const t=(n,cx)=>new Touch({identifier:1,target:g,clientX:cx,clientY:y});
              g.dispatchEvent(new TouchEvent('touchstart',{touches:[t(1,x+200)],bubbles:true}));g.dispatchEvent(new TouchEvent('touchend',{changedTouches:[t(1,x+40)],bubbles:true}))}""", [g['x'], g['y'] + 40])
            pg.wait_for_timeout(300)
            check('celular: deslizar para o lado troca o mês', pg.inner_text('.ma-cal-mes').strip().lower() == f'{MES[P.month - 1]} {P.year}')
            pg.click('[data-hoje]'); pg.wait_for_timeout(300)
            check('celular: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
            # sincronização: inclusão, edição e exclusão feitas fora do calendário aparecem sozinhas (ao voltar o foco)
            i4 = cria(RA, 'Academia', hoje, '07:00')
            RA.post('/api/items', data={'action': 'appointment_update', 'type': 'appointment', 'id': i2, 'data': {'time': '11:45', 'title': 'Reunião de equipe (nova hora)'}})
            RA.post('/api/items', data={'action': 'delete', 'type': 'appointment', 'id': i1})
            pg.evaluate("window.dispatchEvent(new Event('focus'))"); pg.wait_for_timeout(300); pg.wait_for_function("()=>!document.querySelector('.ma-cal-carr.on')", timeout=8000)
            lst = pg.inner_text('.ma-cal-lst')
            check('sincroniza inclusão, edição e exclusão (sem recarregar a página)', 'Academia' in lst and '11:45' in lst and 'nova hora' in lst and 'Corte de cabelo' not in lst, lst)
            check('indicador do dia atualizado (2 compromissos)', pg.locator(f'.ma-cal-d[data-d="{hoje}"] .ma-cal-pts i').count() == 2)
            # edição pelo calendário (painel existente) → lista atualizada ao fechar
            pg.locator('.ma-cal-it:has-text("Academia")').click(); pg.wait_for_selector(f'[data-appt-id="{i4}"]', timeout=8000)
            check('nenhum compromisso duplicado ou criado pelo calendário', len(RA.get('/api/v2/compromissos?periodo=todos').json()['compromissos']) == 3)
            pg.click('.ma-sheet-x'); pg.wait_for_timeout(200)
            pg.screenshot(path='/tmp/e2e/cal_celular_sincronizado.png')
            pg.click('[data-x]'); pg.wait_for_timeout(800)
            main = pg.inner_text('main')
            check('fechar volta para a lista, já sincronizada com o banco', pg.locator('.ma-cal').count() == 0 and 'Academia' in main and 'Corte de cabelo' not in main, main[:300])
            # botão voltar do celular fecha o calendário (não sai da página)
            pg.click('.ma-cal-btn'); pg.wait_for_selector('.ma-cal', timeout=5000); pg.go_back(); pg.wait_for_timeout(500)
            check('"voltar" do aparelho fecha o calendário e permanece na Agenda', pg.locator('.ma-cal').count() == 0 and '/agenda' in pg.url)
        else:
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            check('computador: Esc fecha o calendário', pg.locator('.ma-cal').count() == 0)
    # isolamento pela tela: a Bia não vê nada da Ana
    pb = B.new_page(); pb.set_viewport_size({'width': 390, 'height': 844}); pb.goto('/agenda?tab=compromissos'); pb.wait_for_selector('.ma-cal-btn', timeout=20000); pb.click('.ma-cal-btn')
    pb.wait_for_selector('.ma-cal .ma-cal-d', timeout=8000); pb.wait_for_function("()=>!document.querySelector('.ma-cal-carr.on')", timeout=8000)
    l = pb.inner_text('.ma-cal-lst')
    check('isolamento: outro usuário vê só os próprios compromissos', 'Compromisso da Bia' in l and 'Academia' not in l and 'Reunião' not in l and pb.locator(f'.ma-cal-d[data-d="{prox_mes}"] .ma-cal-pts i').count() == 0, l)
    errs = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript (fora o aviso antigo de hidratação #418)', not errs, errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); import sys; sys.exit(0 if all(res) else 1)
