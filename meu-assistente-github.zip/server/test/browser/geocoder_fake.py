# Geocodificador falso (formato Nominatim) só para os testes de tela: a rede externa é bloqueada neste ambiente.
# /search?q=…            → coordenadas de lugares conhecidos
# /reverse?lat=…&lon=…   → endereço (jsonv2 + addressdetails) dos pontos conhecidos; fora deles, {"error": …} como o Nominatim
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
LUG={'centro, são paulo':(-23.575,-46.63,'Centro, São Paulo, SP'),'manaus':(-3.1,-60.02,'Manaus, Amazonas, Brasil')}
REV=[  # (lat, lng, address) — vale num raio de ~300 m
    (-23.5505,-46.6333,{'road':'Avenida Paulista','house_number':'1578','suburb':'Bela Vista','city':'São Paulo','ISO3166-2-lvl4':'BR-SP','postcode':'01310-200'}),
    (-23.5600,-46.6400,{'road':'Rua Pamplona','suburb':'Jardim Paulista','city':'São Paulo','ISO3166-2-lvl4':'BR-SP','postcode':'01405000'}),
]
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        u=urlparse(self.path); qs=parse_qs(u.query)
        if u.path.rstrip('/').endswith('/reverse'):
            lat=float((qs.get('lat') or ['0'])[0]); lng=float((qs.get('lon') or ['0'])[0])
            hit=[a for (la,lo,a) in REV if abs(la-lat)<0.003 and abs(lo-lng)<0.003]
            r={'lat':str(lat),'lon':str(lng),'display_name':', '.join(v for k,v in hit[0].items() if k in('road','house_number','suburb','city')),'address':hit[0]} if hit else {'error':'Unable to geocode'}
        else:
            q=(qs.get('q') or [''])[0].strip().lower()
            r=[{'lat':str(v[0]),'lon':str(v[1]),'display_name':v[2]} for k,v in LUG.items() if k==q]
        b=json.dumps(r).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b)
HTTPServer(('127.0.0.1',int(sys.argv[1])),H).serve_forever()
