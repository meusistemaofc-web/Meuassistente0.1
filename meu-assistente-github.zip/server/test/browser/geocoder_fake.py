# Geocodificador falso (formato Nominatim) só para os testes de tela: a rede externa é bloqueada neste ambiente.
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
LUG={'centro, são paulo':(-23.575,-46.63,'Centro, São Paulo, SP'),'manaus':(-3.1,-60.02,'Manaus, Amazonas, Brasil')}
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        q=(parse_qs(urlparse(self.path).query).get('q') or [''])[0].strip().lower()
        r=[{'lat':str(v[0]),'lon':str(v[1]),'display_name':v[2]} for k,v in LUG.items() if k==q]
        b=json.dumps(r).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b)
HTTPServer(('127.0.0.1',int(sys.argv[1])),H).serve_forever()
