import json, sys, base64, zlib, struct, sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1100},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':['data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==']}); assert rp.ok, rp.text()
    # cliente em outro contexto
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Moeda','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    assert R.put('/api/panel/coins',data={'action':'config','ativo':True}).ok or R.post('/api/panel/coins',data={'action':'config','ativo':True}).ok
    pg.goto('/admin'); pg.wait_for_timeout(1500)
    pg.get_by_role('button',name='MCoins',exact=True).click(); pg.wait_for_selector('[data-sw=coinsOn]',timeout=10000); pg.wait_for_timeout(800)
    check('antes de criar a moeda, a central explica como emitir pelo Meu Assistente', 'meu assistente como emissor' in pg.inner_text('#hub').lower() and 'crie uma moeda' in pg.inner_text('#hub').lower())
    pg.click('#mn'); pg.wait_for_selector('[data-lm]'); pg.locator('[data-lm]').nth(1).click(); pg.wait_for_selector('[data-f=businessId]')
    opts=pg.locator('[data-f=businessId] option').all_inner_texts()
    check('"Meu Assistente" aparece como empresa oficial selecionável', any('Meu Assistente' in o and 'oficial' in o for o in opts), opts)
    pg.select_option('[data-f=businessId]','institucional'); pg.fill('[data-f=nome]','MCoin Meu Assistente'); pg.fill('[data-f=simbolo]','mcoin'); pg.fill('[data-f=descricao]','Moeda da plataforma'); pg.fill('[data-f=finalidade]','Descontos nas empresas parceiras'); pg.fill('[data-f=quantidade]','1000'); pg.fill('[data-f=valorReferencia]','1'); pg.fill('[data-f=desconto]','1')
    check('prévia mostra o nome da empresa emissora', 'Meu Assistente' in pg.inner_text('#pv'))
    pg.click('#ep'); pg.wait_for_selector('[data-coin]',timeout=8000); pg.wait_for_timeout(1200)
    row=pg.inner_text('[data-coin]')
    check('moeda institucional criada, publicada e marcada', 'MCoin Meu Assistente' in row and 'Meu Assistente' in row and 'Publicada' in row and pg.locator('[data-inst]').count()==1, row)
    pg.click('#mn'); pg.wait_for_selector('[data-lm]'); pg.locator('[data-lm]').nth(0).click(); pg.wait_for_selector('[data-f=businessId]')
    opts=pg.locator('[data-f=businessId] option').all_inner_texts()
    check('depois de criada, a opção institucional some (uma moeda por empresa emissora)', not any('oficial' in o for o in opts), opts)
    pg.click('#eb'); pg.wait_for_selector('#hv_go',timeout=8000)
    check('central mostra totais e o formulário de novos vínculos', 'Vínculos' in pg.inner_text('#hub') and pg.locator('[data-hve]').count()==1 and 'Pizzaria Forno' in pg.inner_text('#hv_form'))
    check('a empresa institucional não aparece como empresa vinculável', 'Meu Assistente' not in pg.inner_text('#hv_form').split('Todas as empresas')[0])
    pg.check(f'[data-hve="{ID}"]'); pg.fill('#hv_p','50'); pg.fill('#hv_m','20'); pg.fill('#hv_r','Só em produtos'); pg.click('#hv_go'); pg.wait_for_selector('[data-vl]',timeout=8000); pg.wait_for_timeout(600)
    vl=pg.inner_text('[data-vl]')
    check('vínculo criado aguardando aceite, com regras', 'Pizzaria Forno' in vl and 'Aguardando aceite' in vl and '50%' in vl and 'Só em produtos' in vl, vl)
    pg.screenshot(path='/tmp/e2e/mcoins_hub.png',full_page=True)
    # distribuir ao cliente
    hub=R.get('/api/panel/coins/hub').json(); CID=hub['moeda']['id']
    d=R.post('/api/panel/coins',data={'action':'distribuir','id':CID,'email':'cli@t.com','quantidade':40,'idem':'t1'}); assert d.ok,d.text()
    # cliente ainda não pode usar (vínculo pendente)
    cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append(str(e)))
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000); cp.click('[data-add]'); cp.wait_for_timeout(400); cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('#cgo',timeout=8000); cp.wait_for_timeout(500)
    check('com o vínculo pendente, o checkout não oferece a moeda', cp.locator('[data-mq]').count()==0)
    cp.keyboard.press('Escape'); cp.reload(); cp.wait_for_timeout(300)
    # empresa aceita na tela Sua empresa
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    check('Ajustes tem "MCoins do Meu Assistente"', pg.locator('button:has-text("MCoins do Meu Assistente")').count()>=1)
    pg.locator('button:has-text("MCoins do Meu Assistente")').first.click(); pg.wait_for_selector('[data-v] [data-a=aceitar]',timeout=8000)
    t=pg.inner_text('[data-v]')
    check('empresa vê emissora, regras e aguarda decisão', 'Emitida por Meu Assistente' in t and 'Aguardando sua resposta' in t and '50%' in t and 'Só em produtos' in t, t)
    pg.screenshot(path='/tmp/e2e/mcoins_empresa.png',full_page=True)
    pg.click('[data-a=aceitar]'); pg.wait_for_selector('[data-a=pausar]',timeout=8000)
    check('após aceitar, vínculo fica ativo', 'Aceita' in pg.inner_text('[data-v]'))
    # checkout com moeda do Meu Assistente
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000); cp.click('[data-add]'); cp.wait_for_timeout(400); cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('[data-mq=max]',timeout=8000)
    sh=cp.inner_text('.ma-sheet-in')
    check('checkout oferece a moeda do Meu Assistente com regras do vínculo', 'MCOIN' in sh and 'Emitida por Meu Assistente' in sh and 'até 50%' in sh, sh[:400])
    cp.click('[data-mq=max]'); cp.wait_for_timeout(300); sh=cp.inner_text('.ma-sheet-in').replace('\xa0',' ')
    check('uso máximo respeita 50% do pedido (R$ 25,00 de R$ 50,00)', 'Desconto em moedas (25 MCOIN)' in sh and 'R$ 25,00' in sh, sh[-300:])
    cp.screenshot(path='/tmp/e2e/mcoins_checkout.png')
    cp.fill('#czap','11999990000') if cp.locator('#czap').count() else None
    cp.click('#cgo'); cp.wait_for_timeout(2500)
    w=cc.request.get('/api/v2/coins/wallet').json(); m=[x for x in w['moedas'] if x['simbolo']=='MCOIN'][0]
    check('saldo debitado (40 → 15) e movimentação identifica emissora e vinculada', m['saldo']==15 and any(h.get('emissora')=='Meu Assistente' and h.get('vinculada')=='Pizzaria Forno' for h in w['historico']), (m['saldo'],w['historico'][:2]))
    hub=R.get('/api/panel/coins/hub').json()
    check('central registra o uso por empresa vinculada', hub['totais']['usos']>=1 and hub['vinculos'][0]['uso']['moedas']==25, hub['totais'])
    # admin pausa; empresa não consegue retomar o que o admin pausou
    pg.goto('/admin'); pg.wait_for_timeout(1200); pg.get_by_role('button',name='MCoins',exact=True).click(); pg.wait_for_selector('[data-vl]',timeout=10000); pg.wait_for_timeout(600)
    pg.locator('[data-vl] [data-va=pausar]').click(); pg.wait_for_timeout(1000)
    check('administrador pausa o vínculo', 'Pausado' in pg.inner_text('[data-vl]') and 'pausado por admin' in pg.inner_text('[data-vl]'))
    pg.locator('[data-vl] [data-va=ev]').click(); pg.wait_for_timeout(600)
    check('histórico do vínculo registra as ações', 'aceitar' in pg.inner_text('[data-vl] .vev') and 'ativo → pausado' in pg.inner_text('[data-vl] .vev'), pg.inner_text('[data-vl] .vev'))
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000); cp.click('[data-add]'); cp.wait_for_timeout(400); cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('#cgo',timeout=8000); cp.wait_for_timeout(500)
    check('com o vínculo pausado, a moeda deixa de ser aceita no checkout', cp.locator('[data-mq]').count()==0)
    # carteira do cliente
    cp.keyboard.press('Escape'); cp.goto('/x/carteira'); cp.wait_for_selector('[data-wc]',timeout=10000); cp.wait_for_timeout(500)
    w=cp.inner_text('body')
    check('carteira mostra a moeda emitida pelo Meu Assistente', '15 MCOIN' in w and 'Meu Assistente' in w, w[:300])
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
