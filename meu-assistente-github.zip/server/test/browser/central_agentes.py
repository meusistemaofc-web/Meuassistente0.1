# Fase 10 — Central de Agentes pela tela real (/admin/agentes): acesso, visão geral, agentes (liga/desliga, autonomia, permissões),
# tarefas com etapas e dependências (sem texto das conversas), empresas, limites, falhas, atalho no painel; celular e computador.
import json, sys, sqlite3
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'
DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Loja Central','categoria':'Loja','titulo':'T','texto':'x','zap':'5511999990000','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo' where id=?",(ID,))
    db.execute("insert into orders (business_id, customer_id, status, total, data, created_at, updated_at) values (?,?,?,?,?,datetime('now'),datetime('now'))",(ID,1,'concluido',150,json.dumps({'tipo':'pedido','itens':[{'nome':'Pomada','qtd':1,'preco':150,'vars':[]}],'pagamento':'dinheiro','cliente':'Cliente Real','empresa':'Loja Central'})))
    db.commit(); db.close()
    # gera uma tarefa coordenada real (pedido complexo de análise)
    for t in ['analise as vendas e os pedidos da minha loja e monte uma estratégia de vendas para dezembro','analise as vendas e os pedidos da minha loja']:
        rr=R.post('/api/chat',data={'text':t,'conversationId':'c1000000-0000-4000-8000-000000000001' if 'dezembro' in t else 'c1000000-0000-4000-8000-000000000002'}); assert rr.ok, rr.text()
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    errs=[]
    cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append(str(e))); cp.goto('/admin/agentes'); cp.wait_for_timeout(1500)
    check('usuário comum: acesso restrito', 'Acesso restrito' in cp.inner_text('body'))
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); c.add_cookies(ctx.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/admin/agentes'); pg.wait_for_selector('#v-geral',timeout=10000)
        t=pg.inner_text('#v-geral')
        check(f'{nome}: estado operacional e agentes ativos 7/7', 'ligado' in t and '7/ 7' in t.replace('\n','') or '7\n/ 7' in t, t[:200])
        check(f'{nome}: consumo e tarefas sem custo de IA', 'Chamadas de IA hoje' in t and 'Tarefas sem custo de IA' in t)
        check(f'{nome}: página sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
        if nome=='celular': pg.screenshot(path='/tmp/e2e/central_agentes_visao.png',full_page=True)
        pg.click('[data-sec=agentes]'); pg.wait_for_selector('#g-dominio',timeout=8000)
        check(f'{nome}: 7 agentes especializados com especialidade, autonomia, ações e permissões', pg.locator('#g-dominio [data-ag]').count()==7 and pg.locator('#g-dominio [data-aut]').count()==7 and pg.locator('#g-dominio [data-esc]').count()>=9)
        check(f'{nome}: agentes de raciocínio, validação e fluxo listados', pg.locator('#g-raciocinio [data-ag]').count()==5 and pg.locator('#g-validacao [data-ag]').count()==1 and pg.locator('#g-fluxo [data-ag]').count()==3)
        com=pg.inner_text('#g-dominio [data-ag="comercial"]')
        check(f'{nome}: Agente Comercial com métricas reais', 'Vendas, oportunidades e produtos' in com and 'acionamento' in com and 'sem custo de IA' in com, com[:300])
        if nome=='celular':
            pg.screenshot(path='/tmp/e2e/central_agentes_agentes.png',full_page=True)
            pg.click('#g-dominio [data-ag="marketing"] [data-tg]'); pg.wait_for_timeout(1200)
            check('desligar o Agente de Marketing grava e reflete', R.get('/api/panel/agentes').json()['config']['dominio']['marketing'] is False and 'desligado' in pg.inner_text('#g-dominio [data-ag="marketing"]'))
            pg.click('#g-dominio [data-ag="marketing"] [data-tg]'); pg.wait_for_timeout(1200)
            pg.select_option('#g-dominio [data-aut="crm"]','2'); pg.wait_for_timeout(900)
            check('autonomia do CRM passa a 2 (prepara para aprovação)', R.get('/api/panel/agentes').json()['config']['autonomia']['crm']==2)
            pg.locator('#g-dominio [data-esc="financeiro"][value="empresa_vendas"]').uncheck(); pg.wait_for_timeout(900)
            check('permissão do Financeiro restringida (só finanças pessoais)', R.get('/api/panel/agentes').json()['config']['permissoes']['financeiro']==['financas_pessoais'])
            pg.locator('#g-dominio [data-esc="financeiro"][value="empresa_vendas"]').check(); pg.wait_for_timeout(900)
        pg.click('[data-sec=tarefas]'); pg.wait_for_selector('[data-t]',timeout=8000)
        check(f'{nome}: histórico de execuções', pg.locator('[data-t]').count()>=2)
        pg.locator('[data-t]').first.click(); pg.wait_for_selector('#det:not([hidden]) h2',timeout=8000)
        det=pg.inner_text('#det')
        check(f'{nome}: detalhe com etapas, dependências, decisões e ações', 'Etapas e dependências' in det and 'coleta de dados' in det and 'consolidação' in det and 'Ações' in det, det[:300])
        check(f'{nome}: sem dados nem texto das conversas', 'Pomada' not in det and 'Cliente Real' not in det and 'dezembro' not in det and 'R$' not in det, det[:300])
        if nome=='celular': pg.screenshot(path='/tmp/e2e/central_agentes_tarefa.png',full_page=True)
        pg.click('[data-sec=empresas]'); pg.wait_for_selector(f'[data-emp="{ID}"]',timeout=8000)
        if nome=='computador':
            box=pg.locator(f'[data-emp="{ID}"]'); box.locator('[data-ea="comercial"]').uncheck(); box.locator('[data-emax]').select_option('2'); box.locator('[data-salvar]').click(); pg.wait_for_timeout(1200)
            em=[x for x in R.get('/api/panel/agentes/empresas?q=Central').json()['items'] if x['id']==ID][0]
            check('empresa: agente desligado e autonomia máxima salvos', em['config']['agentes']['comercial'] is False and em['config']['autonomiaMax']==2 and em['personalizada'], em)
        pg.click('[data-sec=limites]'); pg.wait_for_selector('#l-cham',timeout=8000)
        if nome=='computador':
            pg.fill('#l-cham','2'); pg.click('#l-salvar'); pg.wait_for_timeout(1200)
            check('limites salvos (chamadas de IA por tarefa)', R.get('/api/panel/agentes').json()['config']['limites']['maxChamadasIA']==2)
            pg.click('#l-ativo'); pg.wait_for_timeout(1000); check('chave geral desliga o orquestrador', R.get('/api/panel/agentes').json()['config']['ativo'] is False)
            pg.click('#l-ativo'); pg.wait_for_timeout(1000); check('e religa', R.get('/api/panel/agentes').json()['config']['ativo'] is True)
        pg.click('[data-sec=falhas]'); pg.wait_for_timeout(800)
        check(f'{nome}: seção de falhas', 'Falhas identificadas' in pg.inner_text('#c'))
        c.close()
    # atalho no painel (Cérebro → Inteligência avançada)
    c=b.new_context(viewport={'width':1280,'height':900},base_url=BASE); c.add_cookies(ctx.cookies()); pg=c.new_page()
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_nucleo'); pg.wait_for_selector('#central_agentes_link',timeout=15000)
    check('atalho "Central de Agentes" no painel', pg.get_attribute('#central_agentes_link','href')=='/admin/agentes')
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
