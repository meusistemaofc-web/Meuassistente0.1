# Modo de aprovação de anúncios pela tela real do painel: manual (pendente até aprovar) × automático (valida e publica),
# confirmação antes de trocar, troca só vale para novos envios, origem visível, botão "Sua empresa" liberado no momento certo.
# Requer o servidor com MP_API_BASE apontando para test/browser/mp_fake.py (Pix simulado; ver docs/APROVACAO_ANUNCIOS.md).
import sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(viewport={'width':1280,'height':900},base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/mercadopago',data={'modo':'teste','teste':{'pub':'TEST-abc123456789','tok':'TEST-1234567890-segredo-muito-longo'}}).ok
    PL=[x for x in A.get('/api/v2/ads/plans').json()['plans'] if x['nivel']>=2][0]['id']
    n=[0]
    def usuario():
        n[0]+=1; c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':f'Dono Teste{n[0]}','whatsapp':f'+55 11 9{n[0]}555-12{n[0]}4','email':f'dono{n[0]}@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
        r=R.post('/api/v2/ads',data={'planId':PL,'empresa':f'Empresa {n[0]}','categoria':'Loja','titulo':'T','texto':'x','zap':'5511912345678','tipo':'produtos'}); assert r.ok, r.text()
        return c,R,r.json()['items'][0]['id']
    def pagar(R,i):
        assert R.post(f'/api/v2/ads/{i}/pay',data={}).json()['payment']['qr']
        st=R.get(f'/api/v2/ads/{i}/pay').json()  # consulta do app: a confirmação vem da API do Mercado Pago
        return st
    status=lambda i:[x for x in A.get('/api/v2/admin/ads').json()['items'] if x['id']==i][0]
    def painel():
        pg=adm.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/admin'); pg.wait_for_timeout(1200)
        pg.get_by_role('button',name=re.compile('Anúncios')).first.click(); pg.wait_for_selector('#ap-sec',timeout=15000); return pg
    # permissões
    c0,R0,_=usuario()
    check('8. usuário comum não vê nem altera o modo de aprovação (backend)', R0.get('/api/v2/admin/ads-approval').status in (401,403) and R0.put('/api/v2/admin/ads-approval',data={'modo':'automatico','confirmar':True}).status in (401,403))
    pg=painel(); sec=pg.inner_text('#ap-sec')
    check('seção "Modo de aprovação de anúncios" com descrição e as duas opções', 'Modo de aprovação de anúncios' in sec and 'Escolha como os anúncios enviados pelas empresas serão aprovados antes da publicação.' in sec and pg.locator('[data-apm]').count()==2)
    check('mostra claramente a modalidade ativa (manual por padrão)', pg.inner_text('#ap-ativo')=='Aprovação manual' and pg.get_attribute('[data-apm=manual]','aria-checked')=='true')
    pg.screenshot(path='/tmp/e2e/aprovacao_anuncios_painel.png')
    # 1–2) manual: enviado fica pendente; sem botão "Sua empresa"
    c1,R1,ID1=usuario(); pagar(R1,ID1)
    check('1–2. modo manual: anúncio enviado e pago fica pendente', status(ID1)['status']=='analise', status(ID1)['status'])
    u1=c1.new_page(); u1.on('pageerror',lambda e:errs.append(str(e))); u1.goto('/'); u1.wait_for_selector('header.nx-chat-header-bar',timeout=20000); u1.wait_for_timeout(1500)
    check('7. pendente: sem botão "Sua empresa" e fora das buscas', u1.locator('.ma-hdr-emp').count()==0 and R0.get(f'/api/v2/businesses/cards?ids={ID1}').json()['items']==[])
    c3,R3,ID3=usuario()  # enviado no modo manual; paga depois da troca para o automático
    # 3) aprova pelo painel
    pg.close(); pg=painel()
    pg.locator(f'[data-id="{ID1}"] [data-act=approve]').click(); pg.wait_for_timeout(1500)
    check('3. aprovado pelo painel: no ar, origem "manual"', status(ID1)['status']=='ativo' and status(ID1)['aprovacao']['origem']=='manual')
    try: u1.wait_for_selector('.ma-hdr-emp',state='visible',timeout=40000); ok=True
    except Exception: ok=False
    check('7. botão "Sua empresa" aparece sozinho após a aprovação manual', ok)
    # 4) troca para automático com confirmação
    pg.close(); pg=painel()
    pg.click('[data-apm=automatico]'); pg.wait_for_timeout(300)
    conf=pg.inner_text('#ap-conf')
    check('pede confirmação antes de alterar e explica o efeito', pg.locator('#ap-conf').is_visible() and 'Vale só para os anúncios enviados a partir de agora' in conf and 'continuam' in conf)
    pg.click('#ap-no'); pg.wait_for_timeout(300)
    check('cancelar mantém o modo manual', A.get('/api/v2/admin/ads-approval').json()['modo']=='manual' and not pg.locator('#ap-conf').is_visible())
    pg.click('[data-apm=automatico]'); pg.click('#ap-ok'); pg.wait_for_selector('#ap-ativo:text("Aprovação automática")',timeout=10000)
    cfg=A.get('/api/v2/admin/ads-approval').json()
    check('4. modo automático ativo, com quem/quando registrados', cfg['modo']=='automatico' and cfg['alteradoPorNome']=='Admin Teste' and 'Admin Teste' in pg.inner_text('#ap-quem'), cfg)
    # 6) anteriores mantêm o estado; o enviado no manual não é aprovado sozinho
    pagar(R3,ID3)
    check('6. anúncio enviado no modo manual continua pendente após a troca', status(ID3)['status']=='analise' and status(ID1)['status']=='ativo', status(ID3)['status'])
    # 5) automático: publicado após as validações
    c2,R2,ID2=usuario(); pagar(R2,ID2); s2=status(ID2)
    check('5. modo automático: publicado após as validações, origem "automática"', s2['status']=='ativo' and s2['aprovacao']['origem']=='automatica' and len(s2['aprovacao']['validacoes'])>=8, s2.get('aprovacao'))
    u2=c2.new_page(); u2.goto('/'); u2.wait_for_selector('header.nx-chat-header-bar',timeout=20000)
    try: u2.wait_for_selector('.ma-hdr-emp',state='visible',timeout=15000); ok=True
    except Exception: ok=False
    check('7. botão "Sua empresa" liberado após a aprovação automática confirmada pelo servidor', ok)
    pg.close(); pg=painel()
    check('painel mostra a origem de cada aprovação', pg.locator(f'[data-id="{ID2}"]').locator('xpath=ancestor::div[contains(@class,"px-5")][1]').locator('[data-origem=automatica]').count()==1 and pg.locator('[data-origem=manual]').count()>=1)
    pg.screenshot(path='/tmp/e2e/aprovacao_anuncios_auto.png')
    # volta ao manual: nada muda nos existentes
    A.put('/api/v2/admin/ads-approval',data={'modo':'manual','confirmar':True})
    check('voltar ao manual mantém aprovados e pendentes como estão', status(ID2)['status']=='ativo' and status(ID1)['status']=='ativo' and status(ID3)['status']=='analise')
    # celular: a seção cabe na tela
    m=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); m.add_cookies(adm.cookies()); mp=m.new_page(); mp.goto('/admin'); mp.wait_for_timeout(1200)
    mp.get_by_role('button',name=re.compile('Anúncios')).first.click(); mp.wait_for_selector('#ap-sec',timeout=15000)
    check('celular: seção sem rolagem horizontal', mp.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
    mp.screenshot(path='/tmp/e2e/aprovacao_anuncios_celular.png'); m.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
