# Modal de detalhes do produto: layout original + rolagem vertical interna.
# Produto simples continua compacto e idêntico (mesma altura, sem rolagem, sem faixa fixa de ações).
# Produto com oferta + preço por quantidade + 2 grupos de opções + descrição longa (e outro com 16 variantes):
# o modal para num teto que cabe na tela, rola por dentro, o × fica sempre visível, a linha quantidade/adicionar
# fica fixa na base sem sobrepor o conteúdo, tocar numa faixa/opção/+ não joga a rolagem para o topo,
# a página de trás não rola, sem rolagem horizontal, sem erros. Celular 390x844, celular pequeno 360x640, computador.
# Servidor: PORT=4344 SQLITE_FILE=/tmp/ma-mpr.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sqlite3, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4344'; DBF = '/tmp/ma-mpr.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
M = """()=>{const s=document.querySelector('.ma-sheet-in');if(!s)return null;const r=s.getBoundingClientRect(),x=document.querySelector('.ma-sheet-x').getBoundingClientRect(),
 ac=document.querySelector('.ma-sheet-acoes').getBoundingClientRect(),a=document.getElementById('padd').getBoundingClientRect(),m=document.getElementById('pm').getBoundingClientRect();
 return {h:r.height,top:r.top,bottom:r.bottom,w:r.width,vh:innerHeight,vw:innerWidth,sh:s.scrollHeight,ch:s.clientHeight,sw:s.scrollWidth,cw:s.clientWidth,st:s.scrollTop,rola:s.classList.contains('ma-rola'),
  xVis:x.top>=r.top-1&&x.bottom<=r.bottom+1,acTop:ac.top,addVis:a.top>=r.top&&a.bottom<=r.bottom+1,menosVis:m.top>=r.top&&m.bottom<=r.bottom+1,
  sticky:getComputedStyle(document.querySelector('.ma-sheet-acoes')).position,docW:document.documentElement.scrollWidth,trava:document.documentElement.classList.contains('ma-sheet-aberto')}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Lia', 'whatsapp': '+55 11 94444-7070', 'email': 'lia.mpr@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Atacado da Lia', 'categoria': 'Utilidades', 'titulo': 'x', 'texto': 'Canecas', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'lia@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Pires', 'preco': 10, 'tipo': 'produto', 'categoria': 'Cozinha', 'fotos': [img((40, 80, 200))]}).ok
    desc = 'Caneca de cerâmica esmaltada, feita à mão, 350 ml. Vai ao micro-ondas e à lava-louças. ' * 6
    r = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Caneca completa', 'preco': 50, 'tipo': 'produto', 'categoria': 'Cozinha', 'descricao': desc, 'fotos': [img((200, 80, 40)), img((20, 160, 90))], 'oferta': {'ativo': True, 'preco': 48},
        'precoQtd': {'ativo': True, 'faixas': [{'qtd': 5, 'preco': 45}, {'qtd': 10, 'preco': 40}, {'qtd': 20, 'preco': 36}, {'qtd': 50, 'preco': 32}]},
        'variacoes': [{'nome': 'Personalização', 'opcoes': [{'nome': 'Sem nome', 'preco': 0}, {'nome': 'Nome gravado', 'preco': 8}, {'nome': 'Frase gravada', 'preco': 12}, {'nome': 'Logotipo', 'preco': 20}]},
                      {'nome': 'Embalagem', 'opcoes': [{'nome': 'Simples', 'preco': 0}, {'nome': 'Caixa presente', 'preco': 6}, {'nome': 'Caixa premium', 'preco': 15}]}]}); assert r.ok, r.text()
    r = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Camiseta', 'preco': 60, 'tipo': 'produto', 'categoria': 'Roupas', 'descricao': desc[:300], 'fotos': [img((90, 90, 90))],
        'variantes': [{'cor': c, 'tamanho': t, 'preco': 60 + i, 'fotos': [img((10 * i, 100, 120))]} for i, (c, t) in enumerate([(c, t) for c in ['Azul', 'Preta', 'Branca', 'Verde'] for t in ['P', 'M', 'G', 'GG']])]}); assert r.ok, r.text()
    its = {x['nome']: x['id'] for x in R.get(f'/api/v2/ads/{ID}/products').json()['items']}
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('celular 360x640', {'width': 360, 'height': 640}, True), ('computador', {'width': 1280, 'height': 800}, False)]:
        print(f'— {nome}')
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pc = C.new_page()
        pc.on('pageerror', lambda e: errs.append(str(e)))
        pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector('[data-prod]', timeout=20000); pc.wait_for_timeout(700)
        def abre(prod):
            pc.locator(f'[data-prod="{its[prod]}"]').first.click(); pc.wait_for_selector('.ma-sheet-in #padd', timeout=8000); pc.wait_for_timeout(450); return pc.evaluate(M)
        # 1) produto simples: compacto como antes (mesma altura medida antes da correção: 600 px), sem rolagem, ações no lugar normal
        m = abre('Pires')
        check(f'{nome}: produto simples continua compacto (altura {round(m["h"])})', abs(m['h'] - 600) <= 2 and m['sh'] <= m['ch'] + 2, m)
        check(f'{nome}: produto simples sem faixa fixa de ações (desenho original)', not m['rola'] and m['sticky'] == 'static', m)
        check(f'{nome}: × e Adicionar visíveis no simples', m['xVis'] and m['addVis'], m)
        check(f'{nome}: página de trás travada com o modal aberto', m['trava'], m)
        pc.click('.ma-sheet-x'); pc.wait_for_timeout(250)
        check(f'{nome}: ao fechar, a página volta a rolar', not pc.evaluate("document.documentElement.classList.contains('ma-sheet-aberto')"))
        # 2) produto completo
        m = abre('Caneca completa')
        check(f'{nome}: completo cabe na tela (altura {round(m["h"])} ≤ {m["vh"]}) e não passa de 46rem', m['top'] >= 0 and m['bottom'] <= m['vh'] + 1 and m['h'] <= 736 + 1, m)
        check(f'{nome}: completo rola por dentro', m['sh'] > m['ch'] + 50 and m['rola'], m)
        check(f'{nome}: largura e cantos iguais ao simples (sem rolagem horizontal)', m['sw'] <= m['cw'] + 1 and m['docW'] <= m['vw'] + 1, m)
        check(f'{nome}: quantidade e Adicionar visíveis já ao abrir (fixos na base)', m['addVis'] and m['menosVis'] and m['sticky'] == 'sticky', m)
        pc.fill('#pobs', 'Embrulhar separado')
        pc.evaluate("()=>{const s=document.querySelector('.ma-sheet-in');s.scrollTop=s.scrollHeight}"); pc.wait_for_timeout(200); m = pc.evaluate(M)
        check(f'{nome}: rolado até o fim, × continua visível', m['xVis'], m)
        ob = pc.locator('#pobs').bounding_box()
        check(f'{nome}: última opção (Observação) acima da faixa de ações, sem sobreposição', ob and ob['y'] + ob['height'] <= m['acTop'] + 1, (ob, m['acTop']))
        # rolagem mantida ao tocar numa faixa, numa opção e no +
        for alvo, sel in [('faixa de 10 un.', '[data-faixa="10"]'), ('opção "Caixa presente"', 'text=Caixa presente')]:
            pc.locator(sel).first.evaluate("e=>e.scrollIntoView({block:'center'})"); pc.wait_for_timeout(150)  # no meio da área rolável, longe da faixa fixa
            st0 = pc.evaluate("document.querySelector('.ma-sheet-in').scrollTop"); y0 = pc.locator(sel).first.evaluate("e=>e.getBoundingClientRect().top")
            pc.locator(sel).first.evaluate("e=>{e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));e.click()}"); pc.wait_for_timeout(300)  # toque direto (o clique do Playwright às vezes rola sozinho para "achar" o alvo)
            st1 = pc.evaluate("document.querySelector('.ma-sheet-in').scrollTop"); y1 = pc.locator(sel).first.evaluate("e=>e.getBoundingClientRect().top")
            # o conteúdo acima pode mudar de altura ("falta x un."): o item tocado precisa ficar no MESMO ponto da tela
            check(f'{nome}: tocar em {alvo} não joga a rolagem para o topo e o item tocado fica no mesmo lugar ({round(y0)}→{round(y1)} px)', st0 > 50 and st1 > 50 and abs(y1 - y0) <= 3, (st0, st1, y0, y1))
        st0 = pc.evaluate("document.querySelector('.ma-sheet-in').scrollTop"); pc.click('#pp'); pc.wait_for_timeout(300)
        st1 = pc.evaluate("document.querySelector('.ma-sheet-in').scrollTop")
        check(f'{nome}: tocar no + mantém a rolagem e a quantidade sobe', abs(st1 - st0) <= 2 and pc.locator('#pq, .ma-sheet-acoes').first.inner_text().find('11') >= 0, (st0, st1, pc.locator('.ma-sheet-acoes').inner_text()))
        check(f'{nome}: observação digitada preservada após os toques', pc.input_value('#pobs') == 'Embrulhar separado')
        y0 = pc.evaluate('scrollY'); pc.mouse.move(vp['width'] / 2, vp['height'] / 2); pc.mouse.wheel(0, 3000); pc.wait_for_timeout(350)
        check(f'{nome}: rolar sobre o modal não rola a página de trás', pc.evaluate('scrollY') == y0)
        pc.screenshot(path=f'/tmp/e2e/mpr_{nome.split()[-1]}.png')
        pc.click('#padd'); pc.wait_for_timeout(600)
        check(f'{nome}: Adicionar continua funcionando (fecha o modal)', pc.locator('.ma-sheet').count() == 0)
        # 3) produto com 16 variantes de cor/tamanho
        m = abre('Camiseta')
        check(f'{nome}: com variantes cabe na tela e rola por dentro', m['bottom'] <= m['vh'] + 1 and m['sh'] > m['ch'] and m['addVis'] and m['xVis'], m)
        pc.click('.ma-sheet-x'); pc.wait_for_timeout(250)
        C.close()
    errs = [e for e in errs if '#418' not in e and e != 'Event']  # aviso de hidratação do React já existente em todas as telas
    check('sem erros de JavaScript', not errs, errs)
    b.close()
print(f'\nT: {sum(res)} ok, {len(res) - sum(res)} falhas')
