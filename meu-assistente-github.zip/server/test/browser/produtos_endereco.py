import json, sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE,geolocation={'latitude':-23.55,'longitude':-46.63},permissions=['geolocation'])
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Restaurantes','titulo':'Pizza','texto':'Pizzas','zap':'5511999990000','endereco':'Rua A, 10, São Paulo'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    # geocodificador de mentira no navegador: a localização automática chama /api/v2/geocode
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/api/v2/geocode',lambda route: route.fulfill(status=200,content_type='application/json',body=json.dumps({'ok':True,'lat':-23.55,'lng':-46.63,'endereco':'Rua das Flores, 10, Centro, São Paulo - SP'})))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    print(pg.evaluate("()=>[...document.querySelectorAll('button,a')].map(b=>(b.dataset&&Object.keys(b.dataset).join('|'))+':'+b.textContent.trim().slice(0,25)).filter(x=>x).slice(0,40)"))
    pg.evaluate("(id)=>{history.pushState({},'','/x/sua-empresa');}",ID)
    # abre a aba Produtos
    tabs=pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")')
    check('há acesso à aba Produtos', tabs.count()>0)
    tabs.first.click(); pg.wait_for_selector('#psave',timeout=8000)
    check('campo de variações é opcional (rótulo)', 'opcional' in pg.inner_text('body').lower())
    # 1) salvar SEM variações e SEM erro de const
    img='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
    pg.fill('#pn','Refri'); pg.fill('#ppr','8,00')
    pg.evaluate("(d)=>{const i=document.querySelector('#pf');}",img)
    pg.set_input_files('#pf',{'name':'a.png','mimeType':'image/png','buffer':__import__('base64').b64decode(img.split(',')[1])})
    pg.wait_for_timeout(800)
    pg.click('#psave'); pg.wait_for_timeout(1500)
    body=pg.inner_text('body')
    check('salvou sem variações com confirmação de sucesso (sem "Assignment to constant variable")', 'Assignment' not in body and 'Refri' in body, body[:300])
    check('toast de sucesso exibido', pg.locator('text=salvo com sucesso').count()>0 or 'salvo com sucesso' in body.lower(), body[:200])
    # 2) com variações (e linha inválida ignorada)
    pg.locator('[data-pe]').first.click(); pg.wait_for_selector('#psave')
    pg.fill('#pv','Tamanho: Média=8; Grande=10\nlinha sem dois pontos'); pg.click('#psave'); pg.wait_for_timeout(1500)
    items=R.get(f'/api/v2/ads/{ID}/products').json()['items']
    check('variações salvas, linha inválida ignorada', items and len(items[0]['variacoes'])==1 and len(items[0]['variacoes'][0]['opcoes'])==2, items)
    check('foto persistida', items and len(items[0]['fotos'])==1)
    errs=[e for e in errs if 'React error #418' not in e and e!='Event']  # #418 = aviso de hidratação do app principal, já existente na página inicial
    check('sem erros de JavaScript do módulo', not errs, errs)
    # 3) formulário de anúncio: localização automática preenche o endereço e ele fica editável
    pg.goto('/x/anunciar'); pg.wait_for_timeout(1500)
    print('anunciar form?', pg.locator('#adf').count())
    if pg.locator('#adf').count():
        pl=pg.locator('[name=planId]'); print('planos',pl.count()); pg.locator('label:has([name=planId])').last.click(); pg.wait_for_timeout(400)
        pg.click('#gps'); pg.wait_for_timeout(1500)
        v=pg.input_value('[name=endereco]'); check('localização automática preenche o endereço', v.startswith('Rua das Flores'), v)
        pg.fill('[name=endereco]','Av. Manual 99, Recife'); check('endereço continua editável manualmente', pg.input_value('[name=endereco]')=='Av. Manual 99, Recife')
        check('status avisa digitação manual', 'manual' in pg.inner_text('#gpss').lower(), pg.inner_text('#gpss'))
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
