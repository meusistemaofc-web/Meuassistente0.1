import json, sys, sqlite3, datetime
from playwright.sync_api import sync_playwright
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Ivaslovck Tattoo','categoria':'Tatuagens','titulo':'Tattoo','texto':'x','zap':'5511999990000','insta':'iva','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    assert R.put(f'/api/v2/ads/{ID}/agent',data={'ativo':True,'flutuante':{'ativo':True,'msg':'Oi'}}).ok
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Caneca','preco':30,'tipo':'produto','fotos':[IMG]}); assert rp.ok, rp.text()
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Sessão de tatuagem','preco':200,'tipo':'servico','modoPreco':'fixo','duracao':60}); assert rp.ok, rp.text()
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']['expiresAt']=(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit(); db.close()
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button',timeout=15000)
        L=lambda: pg.evaluate("""()=>{const a=document.querySelector('#acts');const bs=[...a.querySelectorAll('button,a')].map(x=>{const r=x.getBoundingClientRect();return {t:x.innerText.trim(),x:r.x,y:r.y,w:r.width,h:r.height,bg:getComputedStyle(x).backgroundColor,ic:getComputedStyle(x.querySelector('svg')).color,bw:getComputedStyle(x).borderTopWidth,bs:getComputedStyle(x).borderTopStyle,icR:x.querySelector('svg').getBoundingClientRect().right,spL:x.querySelector('span').getBoundingClientRect().left,icy:(()=>{const v=x.querySelector('svg').getBoundingClientRect(),s=x.querySelector('span').getBoundingClientRect();return (v.y+v.height/2)-(s.y+s.height/2)})(),ty:(()=>{const s=x.querySelector('span').getBoundingClientRect();return s.y+s.height/2-(r.y+r.height/2)})()}});const i=document.querySelector('#f').getBoundingClientRect();const ar=a.getBoundingClientRect();return {bs,inp:{y:i.y,t:i.top},acts:{b:ar.bottom,t:ar.top,disp:getComputedStyle(a).display},tel:getComputedStyle(document.querySelector('.bar .tel')||document.body).color}}""")
        s=L(); t=[x['t'] for x in s['bs']]
        check('ordem: Agendar, Ver nossos serviços, Ver mais', t==['Agendar um horário','Ver nossos serviços','Ver mais'], t)
        xs=[round(x['x']) for x in s['bs']]; ys=[x['y'] for x in s['bs']]
        check('"Ver mais" logo abaixo da última opção visível (último da lista)', t[-1]=='Ver mais' and t.count('Ver mais')==1, t)
        check('sem cápsula: nenhum contorno nem borda nos botões', all(x['bw']=='0px' or x['bs']=='none' for x in s['bs']), [(x['bw'],x['bs']) for x in s['bs']])
        check('só ícone à esquerda e texto à direita, centralizados entre si', all(x['icR']<=x['spL'] and abs(x['icy'])<1.5 for x in s['bs']), [(x['icR'],x['spL'],x['icy']) for x in s['bs']])
        check('boa área de toque mesmo sem borda (≥ 44 px)', all(x['h']>=44 for x in s['bs']), [x['h'] for x in s['bs']])
        dy=[round(s['bs'][i+1]['y']-s['bs'][i]['y'],1) for i in range(len(s['bs'])-1)]
        check('espaçamento vertical uniforme', len(set(dy))==1, dy)
        check('lista vertical, todos alinhados à esquerda', len(set(xs))==1 and ys==sorted(ys) and ys[1]>ys[0]+30, (xs,ys))
        check('botões transparentes, sem preenchimento sólido', all(x['bg'] in ('rgba(0, 0, 0, 0)','transparent') for x in s['bs']), s['bs'][0]['bg'])
        check('uma única cor nos ícones', len({x['ic'] for x in s['bs']})==1, {x['ic'] for x in s['bs']})
        check('texto centralizado verticalmente no botão', all(abs(x['ty'])<2 for x in s['bs']), [x['ty'] for x in s['bs']])
        check('acima do campo, sem sobreposição e próximo', s['acts']['b']<=s['inp']['t']+1 and s['inp']['t']-s['acts']['b']<40, s)
        check('mantém espaço para mensagens', s['acts']['t']>200, s['acts'])
        pg.screenshot(path=f'/tmp/e2e/atalhos_{nome}_fechado.png')
        pg.click('#acts [data-a=mais]'); pg.wait_for_timeout(200)
        s2=L(); t2=[x['t'] for x in s2['bs']]
        check('Ver mais expande na vertical com os demais atalhos', t2[:2]==t[:2] and len(t2)>=7 and 'Horário de funcionamento' in t2 and 'WhatsApp' in t2 and 'Localização' in t2, t2)
        check('aberto: o botão fica abaixo de TODAS as opções (nunca no meio)', t2[-1]=='Ver menos' and t2.count('Ver menos')==1 and 'Ver mais' not in t2, t2)
        vis=pg.evaluate("()=>{const a=document.querySelector('#acts'),t=a.querySelector('[data-a=mais]'),ar=a.getBoundingClientRect(),tr=t.getBoundingClientRect();return tr.top>=ar.top-1&&tr.bottom<=ar.bottom+1}")
        check('aberto: "Ver menos" visível no fim sem precisar rolar a lista', vis)
        check('aberto: indica o estado (aria-expanded)', pg.get_attribute('#acts [data-a=mais]','aria-expanded')=='true')
        dy2=[round(s2['bs'][i+1]['y']-s2['bs'][i]['y'],1) for i in range(len(s2['bs'])-1)]
        check('aberto: espaçamento uniforme e sem contornos', len(set(dy2))==1 and all(x['bw']=='0px' or x['bs']=='none' for x in s2['bs']), dy2)
        check('expandidos alinhados à esquerda', len({round(x['x']) for x in s2['bs']})==1)
        check('expandido não invade o campo', s2['acts']['b']<=s2['inp']['t']+1, s2['acts'])
        pg.screenshot(path=f'/tmp/e2e/atalhos_{nome}_expandido.png')
        pg.click('#acts [data-a=mais]'); pg.wait_for_timeout(200)
        check('Ver menos recolhe', [x['t'] for x in L()['bs']]==t)
        # ações originais: cada ação executa uma vez e os atalhos desaparecem (mesmo padrão do Chat Principal)
        calls=pg.evaluate("()=>{window.__n=0;document.querySelectorAll('#acts [data-a=srv]').forEach(b=>b.addEventListener('click',()=>window.__n++));return 1}")
        pg.click('#acts [data-a=srv]'); pg.wait_for_timeout(900)
        check('Ver nossos serviços abre o catálogo de serviços', 'Sessão de tatuagem' in pg.inner_text('body'))
        check('ação executada uma única vez (sem duplicar clique)', pg.evaluate("()=>window.__n")==1 and pg.locator('text=Sessão de tatuagem').count()>=1)
        check('após a ação, os atalhos desaparecem', pg.locator('#acts button').count()==0 and not pg.is_visible('#acts'))
        pg.reload(); pg.wait_for_selector('#acts button',timeout=15000)
        check('nova conversa (recarregar) mostra os atalhos de novo', [x['t'] for x in L()['bs']]==t)
        pg.click('#acts [data-a=agendar]'); pg.wait_for_timeout(1000)
        check('Agendar um horário abre o agendamento do serviço', pg.locator('text=Sessão de tatuagem').count()>=1 and pg.locator('#acts button').count()==0)
        pg.reload(); pg.wait_for_selector('#acts button',timeout=15000)
        pg.click('#acts [data-a=mais]'); pg.click('#acts [data-a=horario]'); pg.wait_for_timeout(800)
        check('atalho do menu expandido funciona (horário) e some', pg.locator('text=/Horário|aberto|Aberto/').count()>0 and pg.locator('#acts button').count()==0)
        pg.reload(); pg.wait_for_selector('#acts button',timeout=15000)
        pg.press('#t','Tab'); pg.hover('#acts button >> nth=0'); pg.wait_for_timeout(100)
        check('Ver mais não é ação: não esconde os atalhos', pg.locator('#acts button').count()>=3)
        # começa a conversa
        pg.fill('#t','Olá'); pg.press('#t','Enter'); pg.wait_for_timeout(1200)
        check('ao enviar mensagem, todos os atalhos somem (inclusive expandidos)', pg.locator('#acts button').count()==0 and not pg.is_visible('#acts'))
        pg.fill('#t','Obrigado'); pg.press('#t','Enter'); pg.wait_for_timeout(800)
        check('segue oculto durante a conversa', not pg.is_visible('#acts'))
        check('campo de digitação e cabeçalho preservados', pg.is_visible('#t') and pg.is_visible('#hd'))
        # nova conversa vazia
        pg.reload(); pg.wait_for_selector('#acts button',timeout=15000)
        check('nova conversa vazia mostra os atalhos de novo (fechados)', [x['t'] for x in L()['bs']]==t)
        c.close()
    # todas as opções já visíveis: sem "Ver mais"
    r=R.post('/api/v2/ads',data={'planId':'n3','empresa':'Consultório Mínimo','categoria':'Saúde','titulo':'C','texto':'x','insta':'consultorio'}); ID2=[x for x in r.json()['items'] if x['empresa']=='Consultório Mínimo'][0]['id']
    db=sqlite3.connect(DBF); d=json.loads(db.execute('select data from businesses where id=?',(ID2,)).fetchone()[0]); d['agente']={'ativo':True,'expiresAt':(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'}; db.execute("update businesses set data=?, status='ativo' where id=?",(json.dumps(d),ID2)); db.commit(); db.close()
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); pg=c.new_page(); pg.goto(f'/a/{ID2}'); pg.wait_for_selector('#acts button',timeout=15000)
    check('sem opções extras, o botão "Ver mais" não aparece', [x.strip() for x in pg.locator('#acts button,#acts a').all_inner_texts()]==['Horário de funcionamento'] and pg.locator('#acts [data-a=mais]').count()==0)
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
