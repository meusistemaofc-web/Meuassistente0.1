import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
norm=lambda s:s.replace('\xa0',' ')
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok
    ID=r.json()['items'][0]['id']
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':[IMG]}).ok
    errs=[]
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('#homerel',timeout=10000); pg.wait_for_timeout(2000); pg.wait_for_selector('#homerel',timeout=10000)
    ids=pg.eval_on_selector_all('#homerel > button','els=>els.map(e=>e.id)')
    check('ordem: Vendas, Relatórios, Dados de acessos', ids==['hr_vendas','hr_rel','hr_acessos'], ids)
    body=norm(pg.inner_text('body'))
    bl=body.lower(); check('textos das três opções', all(t.lower() in bl for t in ['Vendas','Relatórios','Dados de acessos','Faturamento']), body[:300])
    check('prévia do catálogo removida do início', pg.locator('#catprev').count()==0 and 'Seu catálogo oficial' not in body.replace('Seu catálogo oficial fica em',''))
    check('sem rolagem horizontal (mobile)', pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
    pg.wait_for_timeout(2500); pg.screenshot(path='/tmp/e2e/inicio_empresa.png')
    pg.click('#hr_vendas'); pg.wait_for_selector('#rel-vendas',timeout=8000); pg.wait_for_timeout(500)
    check('Vendas abre o relatório de vendas', 'Faturamento' in norm(pg.inner_text('body')))
    pg.screenshot(path='/tmp/e2e/inicio_vendas.png')
    pg.locator('[data-nav]',has_text='Início').first.click(); pg.wait_for_selector('#homerel')
    pg.click('#hr_acessos'); pg.wait_for_selector('#rel-acessos',timeout=8000)
    check('Dados de acessos abre os acessos', 'Visitaram' in norm(pg.inner_text('body')))
    pg.locator('[data-nav]',has_text='Início').first.click(); pg.wait_for_selector('#homerel')
    pg.click('#hr_rel'); pg.wait_for_selector('#rel-acessos',timeout=8000); check('Relatórios abre a tela de relatórios', 'análise e mei' in norm(pg.inner_text('body')).lower())
    # catálogo e funcionalidades continuam disponíveis
    pg.locator('[data-nav]',has_text='Início').first.click(); pg.wait_for_selector('#homerel')
    nav=norm(pg.inner_text('.ma-nav')); check('navegação inferior preservada (Pedidos, Catálogo, Ajustes)', all(t in nav for t in ['Início','Pedidos','Catálogo','Ajustes']), nav)
    pg.locator('[data-nav=produtos]').click(); pg.wait_for_timeout(1500); check('catálogo continua em Catálogo/Serviços', 'Pizza grande' in norm(pg.inner_text('body')))
    pg.locator('[data-nav=mais]').click(); pg.wait_for_timeout(1000); aj=norm(pg.inner_text('body'))
    check('Ajustes preservado (tema, cupons, relatórios)', all(t in aj for t in ['Tema do catálogo','Cupons de desconto','Relatórios e acessos']), aj[:300])
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
