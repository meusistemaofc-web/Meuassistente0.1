# Notificações comerciais: o administrador configura a campanha do Agente de Atendimento no painel; um anúncio publicado
# (de empresa sem agente) recebe a notificação com botão; o botão abre a contratação do agente; o painel mostra os resultados.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, json, sqlite3, datetime
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE); RA=A.request
    assert RA.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com',**U}).ok
    RA.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True})
    # painel: abre a aba, ajusta o horário (a suíte pode rodar de madrugada) e confere a campanha
    pa=A.new_page(); pa.set_viewport_size({'width':1280,'height':900}); pa.on('pageerror',lambda e:errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(2500); aba(pa,'Notificações comerciais'); pa.wait_for_selector('[data-camp="agente_atendimento"]',timeout=10000)
    txt=pa.inner_text('main')
    check('painel: aba com a campanha do Agente de Atendimento ativa e 4 etapas (publicação, 24 h, 3 dias, 7 dias)', 'Agente de Atendimento após a publicação' in txt and pa.locator('[data-camp] [data-etapa]').count()==4 and pa.locator('[data-sw="nc_on_agente_atendimento"]').get_attribute('aria-checked')=='true' and [pa.locator(f'[data-etapa="{k}"] [data-f="atrasoHoras"]').input_value() for k in ('publicacao','24h','3d','7d')]==['0','24','72','168'], txt[:300])
    pa.fill('#nc_ini','00:00'); pa.fill('#nc_fim','23:59'); pa.click('#nc_gsv'); pa.wait_for_timeout(800)
    check('painel: horário permitido salvo', RA.get('/api/panel/comercial').json()['global']['inicio']=='00:00')
    # dono comum com anúncio publicado agora (sem agente)
    D=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2); RD=D.request
    assert RD.post('/api/auth',data={'action':'signup','name':'Dona Bia','whatsapp':'+55 11 95555-0101','email':'bia@t.com',**U},headers={'X-Forwarded-For':'10.9.9.9'}).ok
    bid=RD.post('/api/v2/ads',data={'planId':'n4','empresa':'Café da Bia','categoria':'Restaurantes','titulo':'Café','texto':'Café fresquinho','zap':'5511999990000'}).json()['items'][0]['id']
    db=sqlite3.connect(DBF); d=json.loads(db.execute('select data from businesses where id=?',(bid,)).fetchone()[0]); d['aprovadoEm']=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
    db.execute("update businesses set status='ativo', expires_at=?, data=? where id=?",((datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=30)).isoformat().replace('+00:00','Z'),json.dumps(d),bid)); db.commit()
    pa.click('#nc_run'); pa.wait_for_timeout(1500)
    check('painel: "Processar agora" envia a mensagem da publicação', pa.locator('[data-res="enviados"]').inner_text().startswith('1'), pa.locator('[data-res="enviados"]').inner_text())
    # dono: central de notificações com o botão
    pd=D.new_page(); pd.on('pageerror',lambda e:errs.append(str(e)))
    pd.goto('/notificacoes'); pd.wait_for_selector('.ma-nc',timeout=15000); pd.wait_for_timeout(600)
    t=pd.inner_text('main')
    check('dono: notificação da publicação com o nome da empresa', 'Seu anúncio está no ar! Que tal um atendente 24h?' in t and 'Café da Bia' in t, t[:300])
    check('dono: botão "Conhecer o agente" e opção "Não quero receber"', pd.locator('.ma-nc [data-nc-go]').inner_text()=='Conhecer o agente' and pd.locator('.ma-nc [data-nc-sair]').count()==1)
    pd.wait_for_timeout(4500); pd.screenshot(path='/tmp/e2e/notif_comercial.png')
    pd.click('.ma-nc [data-nc-go]'); pd.wait_for_function("()=>location.pathname==='/x/sua-empresa'&&/Agente de atendimento/.test((document.querySelector('#ma-x')||{}).innerText||'')",timeout=15000); pd.wait_for_timeout(800)
    check('botão abre a contratação do Agente de Atendimento da empresa', 'Café da Bia' in pd.inner_text('#ma-x') and 'nc=' not in pd.url, pd.url)
    pd.screenshot(path='/tmp/e2e/notif_comercial_agente.png')
    # painel: visualização e clique registrados
    pa.reload(); pa.wait_for_timeout(2500); aba(pa,'Notificações comerciais'); pa.wait_for_selector('[data-res="cliques"]',timeout=10000)
    pa.evaluate("document.querySelector('[data-camp]').scrollIntoView()"); pa.wait_for_timeout(300); pa.screenshot(path='/tmp/e2e/notif_comercial_resultados.png')
    check('painel: visualização e clique registrados; empresa aparece na lista', pa.locator('[data-res="cliques"]').inner_text().startswith('1') and pa.locator('[data-res="visualizacoes"]').inner_text().startswith('1') and 'Café da Bia' in pa.inner_text('main'))
    # edição de mensagem pelo painel
    pa.fill('[data-etapa="24h"] [data-f="titulo"]','Clientes estão de olho em {empresa}'); pa.click('[data-nc-salvar]'); pa.wait_for_timeout(1000)
    check('painel: mensagem editada salva', RA.get('/api/panel/comercial').json()['campanhas'][0]['config']['etapas'][1]['titulo']=='Clientes estão de olho em {empresa}')
    pa.locator('[data-camp]').first.scroll_into_view_if_needed(); pa.screenshot(path='/tmp/e2e/notif_comercial_painel.png',full_page=False)
    # contratou: botão vira "Agente contratado" e a sequência para
    d=json.loads(db.execute('select data from businesses where id=?',(bid,)).fetchone()[0]); d['agente']={'nome':'Lia','ativo':True,'expiresAt':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=30)).isoformat().replace('+00:00','Z')}
    db.execute('update businesses set data=? where id=?',(json.dumps(d),bid)); db.commit()
    RA.post('/api/panel/comercial',data={'action':'processar'})
    pd.goto('/notificacoes'); pd.wait_for_selector('.ma-nc',timeout=15000)
    check('depois de contratar: "✓ Agente contratado" no lugar do botão', 'Agente contratado' in pd.inner_text('.ma-nc') and pd.locator('[data-nc-go]').count()==0)
    check('painel: conversão contada', RA.get('/api/panel/comercial').json()['campanhas'][0]['resultados']['conversoes']==1)
    check('usuário comum não acessa o painel comercial', RD.get('/api/panel/comercial').status==403)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
