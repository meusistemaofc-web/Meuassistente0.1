import json, sys, base64, zlib, struct, sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1100},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    rp=R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':['data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==']}); assert rp.ok, rp.text()
    # cliente em outro contexto
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Moeda','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/admin'); pg.wait_for_timeout(1500)
    pg.get_by_role('button',name='MCoins',exact=True).click(); pg.wait_for_selector('[data-sw=coinsOn]',timeout=10000)
    check('sistema nasce desligado e adesão por compra desativada', pg.get_attribute('[data-sw=coinsOn]','aria-checked')=='false' and pg.get_attribute('[data-sw=adesaoOn]','aria-checked')=='false')
    pg.click('[data-sw=coinsOn]'); pg.wait_for_timeout(700)
    check('administrador liga o sistema', pg.get_attribute('[data-sw=coinsOn]','aria-checked')=='true')
    # biblioteca
    pg.click('#mn'); pg.wait_for_selector('[data-lm]',timeout=8000)
    check('biblioteca mostra 10 modelos com prévia, ampliar e selecionar', pg.locator('[data-lm]').count()==10 and pg.locator('[data-lz]').count()==10 and pg.locator('svg[aria-label^="Moeda"]').count()>=10)
    pg.locator('[data-lz]').nth(5).click(); pg.wait_for_timeout(300)
    check('ampliar abre a moeda em tamanho grande', pg.locator('div[style*="z-index: 150"] svg').count()==1 and 'Roxa' in pg.inner_text('div[style*="z-index: 150"]'))
    pg.click('div[style*="z-index: 150"] [data-ok]'); pg.wait_for_selector('[data-f=nome]',timeout=5000)
    # personalização
    pg.select_option('[data-f=businessId]',str(ID)); pg.fill('[data-f=nome]','Moeda Forno'); pg.fill('[data-f=simbolo]','forno'); pg.fill('[data-f=descricao]','Fidelidade da pizzaria'); pg.fill('[data-f=finalidade]','Descontos'); pg.fill('[data-f=quantidade]','1000'); pg.fill('[data-f=valorReferencia]','1,50'); pg.fill('[data-f=desconto]','2')
    pg.set_input_files('#elg',{'name':'logo.png','mimeType':'image/png','buffer':png(60,60,(250,120,20))}); pg.wait_for_timeout(600)
    pv=pg.inner_text('#pv').replace('\xa0',' ')
    check('prévia mostra Mercado e carteira com os dados digitados', 'no mercado' in pv.lower() and 'na carteira do cliente' in pv.lower() and 'FORNO' in pv and 'R$ 1,50' in pv and 'R$ 2,00' in pv, pv)
    check('logotipo aparece na prévia', pg.locator('#pv image').count()>=1)
    pg.screenshot(path='/tmp/e2e/moedas_editor.png',full_page=True)
    pg.click('#ep'); pg.wait_for_selector('[data-coin]',timeout=8000); pg.wait_for_timeout(500)
    row=pg.inner_text('[data-coin]')
    check('moeda salva, vinculada à empresa e publicada', 'Moeda Forno' in row and 'Pizzaria Forno' in row and 'Publicada' in row and 'Roxa futurista' in row, row)
    # distribuição pelo painel
    pg.click('[data-cd]'); pg.wait_for_selector('#dg',timeout=8000)
    pg.fill('#dm','cli@t.com'); pg.fill('#dq','30'); pg.click('#dg'); pg.wait_for_selector('text=Distribuição',timeout=8000); pg.wait_for_timeout(500)
    det=pg.inner_text('body')
    check('distribuição aparece no histórico, com gráfico e números', 'Distribuição' in det and '+30' in det and pg.locator('svg[aria-label^="Evolução"]').count()==1 and 'não é valorização' in det.lower() or 'Não é valorização' in det, det[:200])
    pg.screenshot(path='/tmp/e2e/moedas_detalhe.png',full_page=True)
    # trocar o modelo preserva saldo
    pg.click('#db'); pg.wait_for_selector('[data-ce]'); pg.click('[data-ce]'); pg.wait_for_selector('#em'); pg.click('#em'); pg.wait_for_selector('[data-lm]'); pg.locator('[data-lm]').nth(0).click(); pg.wait_for_selector('#es'); pg.click('#es'); pg.wait_for_selector('[data-coin]'); pg.wait_for_timeout(500)
    api=R.get('/api/panel/coins').json(); mo=api['moedas'][0]
    check('trocar o modelo visual mantém saldo e histórico', mo['modelo']=='dourada' and mo['distribuidas']==30 and mo['status']=='ativa', mo['modelo'])
    # cliente: Mercado
    cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append(str(e)))
    cp.goto('/x/mercado'); cp.wait_for_selector('[data-aba]',timeout=15000); cp.wait_for_timeout(1500)
    check('Mercado ganhou a terceira categoria "MCoins"', [x.strip() for x in cp.locator('[data-aba]').all_inner_texts()]==['Criptomoedas','Bolsa (B3)','MCoins'], cp.locator('[data-aba]').all_inner_texts())
    # ---- Mercado: botões em linha única com rolagem horizontal (configurável no painel)
    for nome,vp,wheel in [('celular estreito',{'width':300,'height':800},False),('computador',{'width':1000,'height':800},True)]:
        cp.set_viewport_size(vp); cp.reload(); cp.wait_for_selector('[data-aba]',timeout=15000); cp.wait_for_timeout(500)
        T=cp.evaluate("()=>{const t=document.querySelector('#mk-tabs'),bs=[...t.querySelectorAll('[data-aba]')],cs=getComputedStyle(t);return {ys:bs.map(b=>Math.round(b.getBoundingClientRect().y)),ox:cs.overflowX,wrap:cs.flexWrap,sw:t.scrollWidth,cw:t.clientWidth,pw:t.parentElement.clientWidth,gaps:bs.slice(1).map((b,i)=>Math.round(b.getBoundingClientRect().x-bs[i].getBoundingClientRect().right)),page:document.documentElement.scrollWidth<=window.innerWidth+1}}")
        check(f'Mercado ({nome}): todos os botões na mesma linha', len(set(T['ys']))==1 and len(T['ys'])==3 and T['wrap']=='nowrap', T)
        check(f'Mercado ({nome}): espaçamento uniforme e a página não ganha rolagem lateral', len(set(T['gaps']))==1 and T['page'], T)
        if T['sw']>T['cw']:
            check(f'Mercado ({nome}): sem espaço, a barra rola na horizontal', T['ox']=='auto' and T['cw']<=T['pw'], T)
            if wheel:
                cp.mouse.move(40,cp.evaluate("()=>document.querySelector('#mk-tabs').getBoundingClientRect().y+20")); cp.mouse.wheel(0,300); cp.wait_for_timeout(400)
                check(f'Mercado ({nome}): roda do mouse/trackpad desloca os botões', cp.evaluate("()=>document.querySelector('#mk-tabs').scrollLeft")>0)
            else:
                ok=cp.evaluate("()=>{const t=document.querySelector('#mk-tabs');t.scrollLeft=9999;const l=[...t.querySelectorAll('[data-aba]')].pop().getBoundingClientRect(),c=t.getBoundingClientRect();return t.scrollLeft>0&&l.right<=c.right+1}")
                check(f'Mercado ({nome}): deslizando, o último botão fica totalmente alcançável', ok)
        else:
            check(f'Mercado ({nome}): cabe sem rolagem', True)
    dc=b.new_context(viewport={'width':330,'height':800},base_url=BASE); assert dc.request.post('/api/auth',data={'action':'login','email':'cli@t.com','password':'Cliente@123'}).ok
    dp=dc.new_page(); dp.goto('/x/mercado'); dp.wait_for_selector('[data-aba]',timeout=15000); dp.wait_for_timeout(2500)
    y=dp.evaluate("()=>document.querySelector('#mk-tabs').getBoundingClientRect().y+20"); dp.mouse.move(60,y); dp.mouse.wheel(0,300); dp.wait_for_timeout(500)
    check('Mercado (desktop, janela estreita): roda do mouse desloca os botões na horizontal', dp.evaluate("()=>{const t=document.querySelector('#mk-tabs');return t.scrollWidth>t.clientWidth&&t.scrollLeft>0}"))
    dc.close()
    cp.set_viewport_size({'width':390,'height':844})
    # painel: desligar a rolagem
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Aparência').click(); pg.wait_for_selector('[data-sw=mkscroll]',timeout=10000)
    check('painel: rolagem horizontal do Mercado nasce ligada', pg.get_attribute('[data-sw=mkscroll]','aria-checked')=='true')
    pg.click('[data-sw=mkscroll]'); pg.wait_for_timeout(900)
    check('painel: desligar grava a configuração', R.get('/api/panel/public').json()['mercado_ui']['scroll'] is False and pg.get_attribute('[data-sw=mkscroll]','aria-checked')=='false')
    cp.reload(); cp.wait_for_selector('[data-aba]',timeout=15000); cp.wait_for_timeout(400)
    check('Mercado com a rolagem desligada volta à disposição anterior', cp.locator('#mk-tabs[data-hscroll]').count()==0 and 'w-fit' in (cp.get_attribute('#mk-tabs','class') or ''))
    pg.click('[data-sw=mkscroll]'); pg.wait_for_timeout(900)
    cp.reload(); cp.wait_for_selector('[data-aba]',timeout=15000)
    check('religar restaura a linha única com rolagem', cp.locator('#mk-tabs[data-hscroll]').count()==1)
    cp.click('[data-aba=bonus]'); cp.wait_for_selector('[data-moeda]',timeout=8000)
    t=cp.inner_text('[data-moeda]').replace('\xa0',' ')
    check('item no padrão de ativo: sigla, nome, valor de referência', 'FORNO' in t and 'Moeda Forno' in t and 'R$ 1,50' in t, t)
    cp.click('[data-moeda]'); cp.wait_for_selector('svg[aria-label^="Evolução"]',timeout=8000)
    sh=cp.inner_text('.ma-sheet-in').replace('\xa0',' ')
    check('página da moeda: totais, gráfico, saldo e regras', all(x in sh for x in ['Total criado','Distribuídas','Disponíveis','Usadas em descontos','30 FORNO','Não há valorização']), sh[:300])
    cp.screenshot(path='/tmp/e2e/moedas_pagina.png')
    cp.keyboard.press('Escape'); cp.goto('/x/carteira'); cp.wait_for_selector('[data-wc]',timeout=10000)
    w=cp.inner_text('#ma-x').replace('\xa0',' ')
    check('carteira: saldo, empresa, equivalente em desconto, regras', '30' in w and 'Pizzaria Forno' in w and 'R$ 60,00' in w and 'Não pode ser transferida' in w, w[:300])
    cp.screenshot(path='/tmp/e2e/moedas_carteira.png')
    # checkout com moedas
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000); cp.click('[data-add]'); cp.wait_for_timeout(400)
    cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('[data-mq=max]',timeout=8000)
    check('checkout oferece as moedas da empresa', 'Você tem' in cp.inner_text('.ma-sheet-in') and 'FORNO' in cp.inner_text('.ma-sheet-in'))
    cp.click('[data-mq=max]'); cp.wait_for_timeout(300)
    s2=cp.inner_text('.ma-sheet-in').replace('\xa0',' ')
    check('máximo respeita o valor dos itens (R$ 50 / R$ 2 = 25 moedas) e o total é recalculado', 'Desconto em moedas (25 FORNO)' in s2 and 'R$ 0,00' in s2, s2[-400:])
    cp.click('[data-mq="-1"]'); cp.wait_for_timeout(200)
    check('diminuir moedas atualiza o total', 'R$ 2,00' in cp.inner_text('.ma-sheet-in').replace('\xa0',' ') and '24 FORNO' in cp.inner_text('.ma-sheet-in'))
    cp.screenshot(path='/tmp/e2e/moedas_checkout.png')
    cp.fill('#czap','(11) 95555-1212'); cp.click('[data-pg=dinheiro]'); cp.click('#cgo'); cp.wait_for_timeout(1500)
    api2=cc.request.get('/api/v2/coins/wallet').json(); sd=[m for m in api2['moedas']][0]['saldo']
    check('pedido enviado: 24 moedas debitadas, saldo restante 6', sd==6, sd)
    od=cc.request.get('/api/v2/orders/mine').json() if False else None
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
