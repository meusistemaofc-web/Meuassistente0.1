# Campo de digitação do chat (layout tipo Grok): caixa única, textarea em cima, botões embaixo; só ele muda.
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
JS="""()=>{const ta=document.querySelector('textarea.composer-input');const box=ta.closest('.ma-composer');const cs=getComputedStyle,b=cs(box),t=cs(ta);
const bar=box.querySelector('.ma-composer-bar');const btns=[...bar.querySelectorAll('button')];const r=e=>e.getBoundingClientRect();
const wrap=box.parentElement;const w=cs(wrap);
return {bg:b.backgroundColor,bd:b.borderTopWidth+' '+b.borderTopColor,rad:b.borderTopLeftRadius,
 ta:{bg:t.backgroundColor,border:t.borderTopWidth,pad:t.padding,fs:t.fontSize,fw:t.fontWeight,lh:t.lineHeight,color:t.color,rows:ta.rows,ph:ta.placeholder},
 phColor:cs(ta,'::placeholder').color,
 wrapPad:[w.paddingLeft,w.paddingRight,w.paddingBottom],bar:{pad:cs(bar).padding,jc:cs(bar).justifyContent},
 above:r(ta).bottom<=r(bar).top+1,
 btns:btns.map(x=>({l:x.getAttribute('aria-label'),w:r(x).width,h:r(x).height,bg:cs(x).backgroundColor,rad:cs(x).borderTopLeftRadius,dis:x.disabled,op:cs(x).opacity,sh:cs(x).boxShadow,svg:(x.querySelector('svg')||{}).getAttribute&&x.querySelector('svg')?[x.querySelector('svg').getAttribute('width'),x.querySelector('svg').getAttribute('stroke-width')]:null,x:r(x).left})),
 boxW:r(box).width,boxL:r(box).left,vw:innerWidth,pills:box.querySelectorAll('.glass-inset').length}}"""
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); R=c.request
        r=R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True})
        if not r.ok: assert R.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(2500)
        d=pg.evaluate(JS)
        check(f'{nome}: caixa única #161616, borda 1px #2A2A2A, canto 32px', d['bg']=='rgb(22, 22, 22)' and d['bd']=='1px rgb(42, 42, 42)' and d['rad']=='32px', d)
        check(f'{nome}: sem pílulas internas', d['pills']==0, d['pills'])
        check(f'{nome}: margem lateral 12px e inferior 40px (+safe area)', d['wrapPad'][0]=='12px' and d['wrapPad'][1]=='12px' and d['wrapPad'][2]=='40px', d['wrapPad'])
        t=d['ta']; check(f'{nome}: textarea sem borda, transparente, 18px/300/26px, branco, padding 18 22 4', t['bg']=='rgba(0, 0, 0, 0)' and t['border']=='0px' and t['pad']=='18px 22px 4px' and t['fs']=='18px' and t['fw']=='300' and t['lh']=='26px' and t['color']=='rgb(255, 255, 255)' and t['rows']==1, t)
        check(f'{nome}: placeholder e cor #8E8E93', 'Fale ou escreva o que precisa' in t['ph'] and d['phColor']=='rgb(142, 142, 147)', (t['ph'],d['phColor']))
        check(f'{nome}: textarea em cima, botões embaixo (space-between, padding 8 10 10)', d['above'] and d['bar']['jc']=='space-between' and d['bar']['pad']=='8px 10px 10px', d['bar'])
        bt=d['btns']; check(f'{nome}: 3 botões 48x48 redondos (anexar, microfone, enviar)', len(bt)==3 and all(round(x['w'])==48 and round(x['h'])==48 and x['rad'] in('24px','9999px','50%') or x['rad'].endswith('px') and float(x['rad'][:-2])>=24 for x in bt), bt)
        check(f'{nome}: anexar à esquerda; microfone e enviar à direita com gap 8', bt[0]['x']<bt[1]['x'] and abs((bt[2]['x']-bt[1]['x']-48)-8)<1.5, [x['x'] for x in bt])
        check(f'{nome}: anexar/microfone #262626; enviar #3B5BDB com brilho', bt[0]['bg']=='rgb(38, 38, 38)' and bt[1]['bg']=='rgb(38, 38, 38)' and bt[2]['bg']=='rgb(59, 91, 219)' and '59, 91, 219' in bt[2]['sh'] and '18px' in bt[2]['sh'], bt)
        check(f'{nome}: ícones 20px com traço 2', all(x['svg']==['20','2'] for x in bt), [x['svg'] for x in bt])
        check(f'{nome}: aria-label em todos os botões', all(x['l'] for x in bt), [x['l'] for x in bt])
        check(f'{nome}: vazio → enviar desativado com 50%', bt[2]['dis'] and abs(float(bt[2]['op'])-0.5)<0.01, bt[2])
        check(f'{nome}: caixa dentro da tela (12px de cada lado, sem rolagem horizontal)', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1') and (d['boxL']>=11.5), d['boxL'])
        ta=pg.locator('textarea.composer-input'); h0=ta.evaluate('e=>e.getBoundingClientRect().height')
        ta.click(); ta.type('Olá'); pg.wait_for_timeout(300)
        s=pg.evaluate("()=>{const x=document.querySelector('.ma-composer-bar button:last-child');return [x.disabled,getComputedStyle(x).opacity]}"); check(f'{nome}: com texto → enviar ativo (100%)', s[0] is False and float(s[1])==1, s)
        check(f'{nome}: começa com 1 linha (48px)', round(h0)==48, h0)
        for i in range(9): pg.keyboard.press('Shift+Enter'); ta.type('linha')
        pg.wait_for_timeout(300); h=ta.evaluate('e=>[e.getBoundingClientRect().height,e.scrollHeight]')
        check(f'{nome}: cresce até 5 linhas (152px) e passa a rolar', round(h[0])==152 and h[1]>152, h)
        pg.screenshot(path=f'/tmp/e2e/composer_{nome}.png')
        ta.fill(''); pg.wait_for_timeout(200); check(f'{nome}: volta a 1 linha ao esvaziar', round(ta.evaluate('e=>e.getBoundingClientRect().height'))==48)
        # Enter envia; Shift+Enter quebra
        ta.click(); ta.type('Primeira'); pg.keyboard.press('Shift+Enter'); ta.type('Segunda'); v=ta.input_value(); check(f'{nome}: Shift+Enter quebra a linha', v=='Primeira\nSegunda', v)
        ta.fill('teste de envio 123'); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
        check(f'{nome}: Enter envia a mensagem', 'teste de envio 123' in pg.inner_text('body') and ta.input_value()=='', ta.input_value())
        ta.fill('outra mensagem'); pg.locator('.ma-composer-bar button[aria-label="Enviar"]').click(); pg.wait_for_timeout(3000); check(f'{nome}: botão enviar também envia', 'outra mensagem' in pg.inner_text('body'))
        # anexar abre o seletor de arquivos
        with pg.expect_file_chooser(timeout=5000) as fc: pg.locator('.ma-composer-bar button[aria-label^="Anexar"]').click()
        check(f'{nome}: anexar abre o seletor de arquivos', fc.value is not None)
        fc.value.set_files({'name':'a.png','mimeType':'image/png','buffer':bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8cfc0f01f0005000201a2ddbc8b0000000049454e44ae426082')}); pg.wait_for_timeout(1500)
        check(f'{nome}: foto anexada aparece dentro da caixa, acima do campo', pg.locator('.ma-composer img[alt^="Foto"]').count()==1 and pg.locator('[aria-label="Enviar"]').first.is_enabled())
        pg.screenshot(path=f'/tmp/e2e/composer_{nome}_anexo.png')
        # microfone presente e clicável (sem erro de tela)
        check(f'{nome}: microfone presente (ditar/gravar)', pg.locator('.ma-composer-bar button[aria-label*="Ditar"], .ma-composer-bar button[aria-label*="Gravar"]').count()==1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print('FIM','OK' if all(res) else 'FALHOU',f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
