# Campo de digitação do Chat Principal: estado compacto (+ | texto | microfone | enviar ↑) e estado expandido ao tocar. Só ele muda.
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
JS="""()=>{const ta=document.querySelector('textarea.composer-input');const box=ta.closest('.ma-composer');const r=e=>{const x=e.getBoundingClientRect();return {l:x.left,t:x.top,r:x.right,b:x.bottom,w:x.width,h:x.height}};
const bs=[...box.querySelectorAll('.ma-composer-bar button')];const by=k=>bs.find(b=>(b.getAttribute('aria-label')||'').startsWith(k));
const cs=getComputedStyle(box);
return {open:box.classList.contains('is-open'),ph:ta.placeholder,box:r(box),ta:r(ta),plus:r(by('Anexar')),mic:r(bs.find(b=>/Ditar|Gravar|Parar/.test(b.getAttribute('aria-label')||''))),send:r(by('Enviar')),
 sendSvg:by('Enviar').querySelector('svg').innerHTML,rad:cs.borderTopLeftRadius,bg:cs.backgroundColor,bf:cs.backdropFilter||cs.webkitBackdropFilter,n:bs.length,txt:box.innerText,
 auto:[...document.querySelectorAll('button')].some(b=>b.innerText.trim()==='Auto'),sendBg:getComputedStyle(by('Enviar')).backgroundColor,vw:innerWidth,sw:document.documentElement.scrollWidth}}"""
IMG=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d4944415478da63f8cfc0f01f0005000201a2ddbc8b0000000049454e44ae426082')
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('tablet',{'width':820,'height':1180},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); R=c.request
        r=R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True})
        if not r.ok: assert R.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(2500)
        pg.evaluate("()=>document.activeElement&&document.activeElement.blur()"); pg.wait_for_timeout(400)
        d=pg.evaluate(JS)
        # ---- compacto
        check(f'{nome}: compacto — placeholder "Pergunte qualquer coisa"', not d['open'] and d['ph']=='Pergunte qualquer coisa', (d['open'],d['ph']))
        check(f'{nome}: compacto — uma linha: + à esquerda, texto, microfone e enviar à direita', d['plus']['r']<=d['ta']['l']+2 and d['ta']['r']<=d['mic']['l']+2 and d['mic']['r']<=d['send']['l']+2 and abs((d['plus']['t']+d['plus']['h']/2)-(d['send']['t']+d['send']['h']/2))<2, d)
        check(f'{nome}: compacto — altura baixa (≤ 72px) e bordas bem arredondadas (≥ 28px)', d['box']['h']<=72 and float(d['rad'][:-2])>=28, (d['box']['h'],d['rad']))
        check(f'{nome}: fundo cinza-escuro com leve transparência', d['bg'].startswith('rgba(24, 24, 26') and 'blur' in (d['bf'] or ''), (d['bg'],d['bf']))
        check(f'{nome}: botão azul de enviar com seta para cima (↑)', d['sendBg']=='rgb(59, 91, 219)' and 'm5 12 7-7 7 7' in d['sendSvg'].replace('M5 12','m5 12') or 'd="m5 12 7-7 7 7"' in d['sendSvg'], d['sendSvg'])
        check(f'{nome}: 3 botões (anexar, microfone, enviar) e nenhum botão "Auto"', d['n']==3 and not d['auto'] and 'Auto' not in d['txt'], (d['n'],d['auto'],d['txt']))
        check(f'{nome}: sem espaço residual do antigo botão (texto ocupa o espaço livre)', d['ta']['w']>d['box']['w']*0.45, (d['ta']['w'],d['box']['w']))
        check(f'{nome}: sem rolagem horizontal', d['sw']<=d['vw']+1, (d['sw'],d['vw']))
        # ---- expandido ao tocar
        ta=pg.locator('textarea.composer-input'); ta.click(); pg.wait_for_timeout(450)
        e=pg.evaluate(JS)
        check(f'{nome}: ao tocar, expande (placeholder "Digite sua mensagem…")', e['open'] and e['ph']=='Digite sua mensagem…' and e['box']['h']>d['box']['h']+40, (e['open'],e['ph'],e['box']['h'],d['box']['h']))
        check(f'{nome}: expandido — texto em cima; + embaixo à esquerda; microfone e enviar embaixo à direita', e['ta']['b']<=e['plus']['t']+2 and e['plus']['l']<e['box']['l']+70 and e['send']['r']>e['box']['r']-20 and e['mic']['r']<=e['send']['l']+2 and e['mic']['t']>e['ta']['b']-2 and abs(e['plus']['t']-e['send']['t'])<2, e)
        check(f'{nome}: cursor ativo no campo (foco) e na primeira posição', pg.evaluate("()=>{const t=document.querySelector('textarea.composer-input');return document.activeElement===t&&t.selectionStart===0}"))
        pg.screenshot(path=f'/tmp/e2e/composer_{nome}_aberto.png')
        # ---- mensagens curtas e longas
        ta.type('Olá'); pg.wait_for_timeout(300); h1=ta.evaluate('e=>e.getBoundingClientRect().height')
        s=pg.evaluate("()=>{const x=[...document.querySelectorAll('.ma-composer-bar button')].find(b=>b.getAttribute('aria-label')==='Enviar');return [x.disabled,getComputedStyle(x).opacity]}"); check(f'{nome}: com texto → enviar ativo (100%)', s[0] is False and float(s[1])==1, s)
        for i in range(14): pg.keyboard.press('Shift+Enter'); ta.type('linha longa de teste')
        pg.wait_for_timeout(300); hh=ta.evaluate('e=>[e.getBoundingClientRect().height,e.scrollHeight]'); mx=min(pg.evaluate('innerHeight')*0.4,260)
        check(f'{nome}: mensagem longa cresce até a altura máxima da tela e passa a rolar', hh[0]>h1+40 and hh[0]<=mx+2 and hh[1]>hh[0], (hh,mx,h1))
        check(f'{nome}: campo continua dentro da tela', pg.evaluate(JS)['box']['b']<=pg.evaluate('innerHeight') and pg.evaluate(JS)['box']['t']>=0)
        pg.screenshot(path=f'/tmp/e2e/composer_{nome}_longo.png')
        ta.fill(''); pg.wait_for_timeout(250)
        ta.click(); ta.type('Primeira'); pg.keyboard.press('Shift+Enter'); ta.type('Segunda'); v=ta.input_value(); check(f'{nome}: Shift+Enter quebra a linha', v=='Primeira\nSegunda', v)
        # ---- enviar (teclado e botão), com estado de carregamento e sem duplicar
        ta.fill('teste de envio 123'); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
        txt=pg.inner_text('body'); check(f'{nome}: Enter envia a mensagem (uma única vez)', txt.count('teste de envio 123')==1 and ta.input_value()=='', (txt.count('teste de envio 123'),ta.input_value()))
        ta.fill('outra mensagem'); pg.locator('.ma-composer-bar button[aria-label="Enviar"]').click(); pg.wait_for_timeout(3000); check(f'{nome}: botão enviar também envia', pg.inner_text('body').count('outra mensagem')==1)
        # ---- anexos: + abre o seletor e a foto aparece dentro da caixa
        with pg.expect_file_chooser(timeout=5000) as fc: pg.locator('.ma-composer-bar button[aria-label^="Anexar"]').click()
        fc.value.set_files({'name':'a.png','mimeType':'image/png','buffer':IMG}); pg.wait_for_timeout(1500)
        check(f'{nome}: anexar funciona; foto aparece na caixa e permite enviar', pg.locator('.ma-composer img[alt^="Foto"]').count()==1 and pg.locator('[aria-label="Enviar"]').first.is_enabled())
        pg.screenshot(path=f'/tmp/e2e/composer_{nome}_anexo.png')
        check(f'{nome}: microfone presente (ditar/gravar)', pg.locator('.ma-composer-bar button[aria-label*="Ditar"], .ma-composer-bar button[aria-label*="Gravar"]').count()==1)
        # ---- teclado virtual: a área visível encolhe; o campo precisa continuar visível
        pg.locator('button[aria-label="Remover foto 1"]').click(); pg.wait_for_timeout(300)
        ta.click(); pg.set_viewport_size({'width':vp['width'],'height':int(vp['height']*0.55)}); pg.wait_for_timeout(500)
        k=pg.evaluate(JS); check(f'{nome}: com o teclado aberto o campo não fica escondido', k['box']['b']<=pg.evaluate('innerHeight')+1 and k['box']['t']>=0 and k['open'], (k['box'],pg.evaluate('innerHeight')))
        pg.set_viewport_size(vp); pg.evaluate("()=>document.activeElement&&document.activeElement.blur()"); pg.wait_for_timeout(500)
        f=pg.evaluate(JS); check(f'{nome}: ao fechar o teclado/sair do campo vazio, volta ao compacto', not f['open'] and f['ph']=='Pergunte qualquer coisa' and f['box']['h']<=72, (f['open'],f['box']['h']))
        wrap=pg.evaluate("()=>getComputedStyle(document.querySelector('.ma-composer-wrap')).paddingBottom"); check(f'{nome}: respeita a área segura inferior (padding-bottom com env(safe-area))', float(wrap[:-2])>=30, wrap)
        pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
        held=[]; pg.route('**/api/chat', lambda r: held.append(r))
        ta=pg.locator('textarea.composer-input'); ta.fill('teste de carga'); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
        st=pg.evaluate("()=>{const x=[...document.querySelectorAll('.ma-composer-bar button')].find(b=>(b.getAttribute('aria-label')||'')==='Enviar');return {dis:x.disabled,spin:!!x.querySelector('.animate-spin')}}")
        check(f'{nome}: durante o processamento mostra carregamento no botão', st['spin'], st)
        ta.fill('duplicado?'); pg.keyboard.press('Enter'); pg.locator('.ma-composer-bar button[aria-label="Enviar"]').click(force=True); pg.wait_for_timeout(500)
        check(f'{nome}: não permite envio duplicado enquanto processa', len(held)==1, len(held))
        for r_ in held: r_.continue_()
        pg.wait_for_timeout(200); pg.unroute('**/api/chat')
        pg.wait_for_timeout(3000)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print('FIM','OK' if all(res) else 'FALHOU',f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
