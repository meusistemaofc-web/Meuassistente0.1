# Botões rápidos do CHAT PRINCIPAL — visual da referência: no máximo 3 botões em lista vertical, alinhados à esquerda,
# logo acima do campo de digitação (sem sobrepor); ícone de linha sem fundo em cinza discreto e texto branco; "Lojas" com
# ícone e texto em azul; sem borda/fundo/cápsula; sem "Ver mais"; tocar envia o COMANDO do botão ao motor do chat (resposta
# real) e a lista some. Cores e ícone por botão vindos do painel. Celular (2 tamanhos) e computador.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-qbpos.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
M="""()=>{const l=document.querySelector('.ma-qb-list');if(!l)return null;const vis=[...l.children].filter(x=>getComputedStyle(x).display!=='none'&&x.getBoundingClientRect().height>0);
const ta=document.querySelector('textarea.composer-input'),comp=(document.querySelector('.ma-composer')||ta.closest('form')||ta.parentElement).getBoundingClientRect(),lr=l.getBoundingClientRect();
const S=x=>x.querySelector('svg');
return {n:vis.length,txts:vis.map(x=>x.innerText.trim()),todos:vis.every(x=>x.classList.contains('ma-qb-item')),gapComp:Math.round(comp.top-lr.bottom),overlap:lr.bottom>comp.top+1,
 ic:vis.map(x=>getComputedStyle(S(x)).color),tx:vis.map(x=>getComputedStyle(x).color),fw:vis.map(x=>getComputedStyle(x).fontWeight),fs:vis.map(x=>parseFloat(getComputedStyle(x).fontSize)),
 isz:vis.map(x=>Math.round(S(x).getBoundingClientRect().width)),fill:vis.map(x=>getComputedStyle(S(x)).fill),
 st:[...new Set(vis.map(x=>{const c=getComputedStyle(x);return [c.borderTopWidth,c.backgroundColor,c.boxShadow].join('|')}))],
 lefts:[...new Set(vis.map(x=>Math.round(S(x).getBoundingClientRect().left)))],tleft:[...new Set(vis.map(x=>Math.round(x.querySelector('span').getBoundingClientRect().left)))],
 compLeft:Math.round(comp.left),listLeft:Math.round(lr.left),cx:Math.round(innerWidth/2),
 gaps:(()=>{const t=vis.map(x=>Math.round(x.getBoundingClientRect().top));return [...new Set(t.slice(1).map((v,i)=>v-t[i]))]})(),
 tg:!!document.querySelector('.ma-qb-tg'),hx:document.documentElement.scrollWidth-innerWidth}}"""
rgb=lambda c:[int(x) for x in re.findall(r'\d+',c)[:3]]
lum=lambda c:sum(rgb(c))/3
with sync_playwright() as p:
    b=p.chromium.launch(); c0=b.new_context(base_url=BASE); R=c0.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'sugestoes':True,'empresas':True}).ok
    O=R.get('/api/panel').json()['quick_buttons_opcoes']
    errs=[]
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('celular pequeno',{'width':360,'height':640},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); c.add_cookies(c0.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.wait_for_timeout(900)
        if pg.get_by_text('Agora não').count(): pg.get_by_text('Agora não').first.click(); pg.wait_for_timeout(500)
        m=pg.evaluate(M)
        check(f'{nome}: 3 botões padrão, na ordem (Lojas, Agendar compromisso, Organizar meu dia), sem "Ver mais"', m['n']==3 and m['todos'] and m['txts']==['Lojas','Agendar compromisso','Organizar meu dia'] and not m['tg'], m)
        check(f'{nome}: lista logo acima do campo de digitação, sem sobrepor', not m['overlap'] and 0<=m['gapComp']<=32, m['gapComp'])
        check(f'{nome}: alinhados à esquerda (ícones e textos na mesma coluna, à esquerda do centro)', len(m['lefts'])==1 and len(m['tleft'])==1 and m['lefts'][0]<m['cx']-60 and abs(m['listLeft']-m['compLeft'])<=24, (m['lefts'],m['tleft'],m['listLeft'],m['compLeft']))
        check(f'{nome}: "Lojas" com ícone e texto em azul', rgb(m['ic'][0])==[22,119,255] and rgb(m['tx'][0])==[22,119,255], (m['ic'][0],m['tx'][0]))
        check(f'{nome}: demais com ícone cinza discreto e texto branco', all(90<lum(x)<190 and max(rgb(x))-min(rgb(x))<12 for x in m['ic'][1:]) and all(lum(x)>235 for x in m['tx'][1:]), (m['ic'],m['tx']))
        check(f'{nome}: ícones de linha sem fundo; botões sem borda, fundo, sombra ou cápsula', m['st']==['0px|rgba(0, 0, 0, 0)|none'] and all(f=='none' for f in m['fill']), (m['st'],m['fill']))
        check(f'{nome}: tamanho e espaçamento uniformes (ícone 22–24px, texto 16–17px)', all(21<=x<=24 for x in m['isz']) and all(15.5<=x<=17.5 for x in m['fs']) and len(set(m['gaps']))<=1, (m['isz'],m['fs'],m['gaps']))
        check(f'{nome}: sem rolagem horizontal', m['hx']<=1)
        if mob and vp['width']==390: pg.screenshot(path='/tmp/e2e/botoes_rapidos_referencia.png')
        if nome=='computador': pg.screenshot(path='/tmp/e2e/botoes_rapidos_computador.png')
        # tocar: envia o COMANDO do botão (não o texto) ao motor do chat e a lista some na hora
        pg.locator('.ma-qb-item',has_text='Lojas').click(); pg.wait_for_timeout(150)
        check(f'{nome}: ao tocar a lista some na hora', not pg.locator('.ma-qb-list').is_visible())
        try: pg.wait_for_function("()=>document.querySelector('.chat-scroll').innerText.includes('Empresas perto de você')",timeout=15000); ok=True
        except Exception: ok=False
        t=pg.inner_text('.chat-scroll')
        check(f'{nome}: "Lojas" executa o comando real ("Lojas perto de mim" → Empresas perto de você)', ok and 'Lojas perto de mim' in t, t[-300:])
        c.close()
    # cores e ícone por botão, ativo/inativo e desligar tudo — vindos do painel
    print('== configuração do painel')
    r=R.put('/api/panel/quick_buttons',data={'enabled':True,'items':[{'texto':'Registrar gasto','comando':'Registrar gasto','icone':'carteira','corIcone':'#22C55E','corTexto':'#F5A524'},{'texto':'Oculto','comando':'Minhas tarefas','icone':'tarefa','ativo':False},{'texto':'Lojas','comando':'Lojas perto de mim','icone':'loja'}]}); assert r.ok, r.text()
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); c.add_cookies(c0.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.wait_for_timeout(900); m=pg.evaluate(M)
    check('painel: só os ativos, na ordem do painel', m['txts']==['Registrar gasto','Lojas'], m['txts'])
    check('painel: cor do ícone e do texto por botão; "Lojas" sem cor volta ao padrão', rgb(m['ic'][0])==[34,197,94] and rgb(m['tx'][0])==[245,165,36] and lum(m['tx'][1])>235 and 90<lum(m['ic'][1])<190, (m['ic'],m['tx']))
    check('painel: ícone escolhido (carteira) desenhado', pg.locator('.ma-qb-item').first.locator('svg circle').count()==1)
    pg.locator('.ma-qb-item',has_text='Registrar gasto').click()
    try: pg.wait_for_function("()=>document.querySelector('.chat-scroll').innerText.includes('Quanto você gastou e com o quê')",timeout=15000); ok=True
    except Exception: ok=False
    check('painel: "Registrar gasto" pergunta valor e o quê (motor do chat)', ok)
    assert R.put('/api/panel/quick_buttons',data={'enabled':False,'items':[{'texto':'Lojas','comando':'Lojas perto de mim','icone':'loja'}]}).ok
    pg.goto('/'); pg.wait_for_timeout(3000)
    check('painel: exibição desligada não mostra botões', pg.locator('.ma-qb-item:visible').count()==0)
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
