# Botões rápidos do CHAT PRINCIPAL — aparência e posição: lista vertical minimalista (ícone cinza à esquerda, texto claro à direita,
# sem borda/fundo/cápsula), na parte de baixo da área inicial, perto do campo de digitação sem sobrepor; "Ver mais" na MESMA lista,
# sempre por último (celular); continua sumindo após escolher/enviar. Celular (2 tamanhos) e computador.
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
M="""()=>{const l=document.querySelector('.ma-qb-list');if(!l)return null;const vis=[...l.children].filter(x=>getComputedStyle(x).display!=='none'&&x.getBoundingClientRect().height>0);
const comp=document.querySelector('.ma-composer').getBoundingClientRect(),lr=l.getBoundingClientRect();
const ic=vis.map(x=>{const s=x.querySelector('svg');return s?getComputedStyle(s).color:null}),tx=vis.map(x=>getComputedStyle(x).color);
const st=vis.map(x=>{const c=getComputedStyle(x);return [c.borderTopWidth,c.backgroundColor,c.boxShadow].join('|')});
const lefts=vis.map(x=>x.querySelector('svg').getBoundingClientRect().left|0),tops=vis.map(x=>x.getBoundingClientRect().top),gaps=tops.slice(1).map((t,i)=>Math.round(t-tops[i]));
const cen=vis.map(x=>{const s=x.querySelector('svg').getBoundingClientRect(),r=x.getBoundingClientRect();return Math.abs((s.top+s.height/2)-(r.top+r.height/2))<1.5});
return {n:vis.length,txts:vis.map(x=>x.innerText.trim()),last:vis.at(-1).innerText.trim(),isTg:vis.at(-1).classList.contains('ma-qb-tg'),gapComp:Math.round(comp.top-lr.bottom),overlap:lr.bottom>comp.top,
ic:[...new Set(ic)],tx:[...new Set(tx)],st:[...new Set(st)],lefts:[...new Set(lefts)],gaps:[...new Set(gaps)],cen:cen.every(Boolean),hx:document.documentElement.scrollWidth-innerWidth}}"""
def lum(c):
    import re; v=[int(x) for x in re.findall(r'\d+',c)[:3]]; return sum(v)/3
with sync_playwright() as p:
    b=p.chromium.launch(); c0=b.new_context(base_url=BASE); R=c0.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    errs=[]
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('celular pequeno',{'width':360,'height':640},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); c.add_cookies(c0.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.wait_for_timeout(900)
        if pg.get_by_text('Agora não').count(): pg.get_by_text('Agora não').first.click(); pg.wait_for_timeout(500)
        m=pg.evaluate(M)
        check(f'{nome}: lista perto do campo de digitação, sem sobrepor', not m['overlap'] and 0<=m['gapComp']<=64, m['gapComp'])
        check(f'{nome}: ícones cinza e uniformes; texto claro', len(m['ic'])==1 and 60<lum(m['ic'][0])<200 and len(m['tx'])==1 and lum(m['tx'][0])>200, (m['ic'],m['tx']))
        check(f'{nome}: sem borda, fundo ou sombra', m['st']==['0px|rgba(0, 0, 0, 0)|none'], m['st'])
        check(f'{nome}: ícones alinhados, espaçamento uniforme e centralização vertical', len(m['lefts'])==1 and len(m['gaps'])<=1 and m['cen'], (m['lefts'],m['gaps']))
        check(f'{nome}: sem rolagem horizontal', m['hx']<=1)
        if mob:
            check(f'{nome}: 4 opções + "Ver mais" por último', m['n']==5 and m['isTg'] and m['last']=='Ver mais', m)
            antes=m['txts'][:4]
            pg.click('.ma-qb-tg'); pg.wait_for_timeout(300); a=pg.evaluate(M)
            check(f'{nome}: "Ver mais" revela as demais e vira "Ver menos" no fim', a['n']==9 and a['isTg'] and a['last']=='Ver menos' and a['txts'][:4]==antes, a['txts'])
            check(f'{nome}: aberto, "Ver menos" visível e sem sobrepor o campo', not a['overlap'] and pg.locator('.ma-qb-tg').is_visible())
            check(f'{nome}: "Ver mais" não envia nem esconde a lista', pg.locator('.ma-qb-list').is_visible() and pg.locator('.chat-scroll .msg-tools, .chat-scroll [data-role=user]').count()==0)
            pg.click('.ma-qb-tg'); pg.wait_for_timeout(300); f=pg.evaluate(M)
            check(f'{nome}: "Ver menos" recolhe de volta', f['n']==5 and f['last']=='Ver mais')
            pg.locator('textarea.composer-input').focus(); pg.wait_for_timeout(200); k=pg.evaluate(M)
            check(f'{nome}: com o campo em foco a lista não sobrepõe', not k['overlap'])
        else:
            check(f'{nome}: todas as 8 opções visíveis, sem "Ver mais"', m['n']==8 and not m['isTg'] and pg.locator('.ma-qb-tg').count()==0 or not pg.locator('.ma-qb-tg').is_visible(), m)
        if nome!='celular pequeno':
            t=pg.locator('.ma-qb-item').first.inner_text().strip(); pg.locator('.ma-qb-item').first.click(); pg.wait_for_timeout(1500)
            check(f'{nome}: escolher uma opção envia o texto e oculta a lista (inclusive o "Ver mais")', not pg.locator('.ma-qb-list').is_visible() and t in pg.inner_text('.chat-scroll'))
        if nome=='celular': pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=15000); pg.screenshot(path='/tmp/e2e/botoes_rapidos_posicao_celular.png')
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
