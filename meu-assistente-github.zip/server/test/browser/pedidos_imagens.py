# Imagens dos itens nos pedidos: Sua loja → Pedidos (lista e Detalhes), Solicitações (lista e Detalhes) e central de Lojas
# Conectadas. Pedido de 1 item, de vários itens (cada um com a sua imagem, variação com a foto da variação), item sem foto
# (espaço reservado do mesmo tamanho), agendamento de serviço, quantidade × preço unitário e total do item. Celular e computador.
# Servidor: PORT=4325 SQLITE_FILE=/tmp/ma-pim.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, base64, os, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4325'; DBF = '/tmp/ma-pim.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
COR = {'caneca': (200, 40, 40), 'preta': (20, 20, 20), 'branca': (240, 240, 240), 'ensaio': (40, 160, 80), 'nova': (40, 80, 220)}
# cor média da imagem exibida (confere que cada item mostra a SUA foto)
COR_JS = """(img)=>{const c=document.createElement('canvas');c.width=c.height=8;const x=c.getContext('2d');x.drawImage(img,0,0,8,8);const d=x.getImageData(0,0,8,8).data;let r=0,g=0,b=0;for(let i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}const n=d.length/4;return [Math.round(r/n),Math.round(g/n),Math.round(b/n)]}"""
def cores(loc): return [x.evaluate(COR_JS) if x.count() else None for x in [i.locator('img') for i in loc.locator('[data-oitem]').all()]]
def perto(a, b): return all(abs(x - y) <= 12 for x, y in zip(a, b))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Pia', 'whatsapp': '+55 85 94444-7001', 'email': 'pia@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(Rq, nome, servicos=False):
        r = Rq.post('/api/v2/ads', data={'planId': 'n4', 'empresa': nome, 'categoria': 'Variados', 'titulo': 'x', 'texto': 'x', 'zap': '5585999990000'}); assert r.ok, r.text(); i = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (i,)); db.commit(); db.close()
        assert Rq.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        if servicos:
            assert Rq.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
            assert Rq.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'auto', 'dias': {d: {'ativo': True, 'abre': '08:00', 'fecha': '20:00'} for d in ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']}}}).ok
        return i
    E = b.new_context(base_url=BASE); RS = E.request
    assert RS.post('/api/auth', data={'action': 'signup', 'name': 'Sara Studio', 'whatsapp': '+55 85 94444-7004', 'email': 'sara.pim@t.com', **U}, headers={'X-Forwarded-For': '10.8.0.4'}).ok
    L = loja(R, 'Loja da Pia'); S = loja(RS, 'Studio da Sara', True)
    P = lambda bid, d: (RS if bid == S else R).post(f'/api/v2/ads/{bid}/products', data=d)
    assert P(L, {'nome': 'Caneca Vermelha', 'preco': 30, 'categoria': 'Casa', 'fotos': [durl(COR['caneca'])]}).ok
    assert P(L, {'nome': 'Camiseta', 'categoria': 'Roupas', 'variantes': [{'cor': 'Preta', 'tamanho': 'P', 'preco': 40, 'fotos': [durl(COR['preta'])]}, {'cor': 'Branca', 'tamanho': 'M', 'preco': 45, 'fotos': [durl(COR['branca'])]}]}).ok
    assert P(L, {'nome': 'Adesivo', 'preco': 5, 'categoria': 'Casa', 'fotos': [durl((1, 2, 3))]}).ok
    its = R.get(f'/api/v2/ads/{L}/products').json()['items']; pid = lambda n: next(x for x in its if x['nome'] == n)
    CAN, CAM, ADE = pid('Caneca Vermelha')['id'], pid('Camiseta'), pid('Adesivo')['id']
    BR = next(v['id'] for v in CAM['variantes'] if v['cor'] == 'Branca')
    db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from products where id=?', (ADE,)).fetchone()[0]); d['fotos'] = []; db.execute('update products set data=? where id=?', (json.dumps(d), ADE)); db.commit(); db.close()  # item sem foto (como os importados)
    assert P(S, {'tipo': 'servico', 'nome': 'Ensaio fotográfico', 'preco': 150, 'modoPreco': 'fixo', 'duracao': 60, 'fotos': [durl(COR['ensaio'])]}).ok
    SV = next(x for x in RS.get(f'/api/v2/ads/{S}/products').json()['items'] if x['nome'] == 'Ensaio fotográfico')['id']
    C = b.new_context(base_url=BASE).request
    assert C.post('/api/auth', data={'action': 'signup', 'name': 'Caio Cliente', 'whatsapp': '+55 85 95555-7002', 'email': 'caio.pim@t.com', **U}, headers={'X-Forwarded-For': '10.8.0.2'}).ok
    ped = lambda itens: C.post(f'/api/v2/businesses/{L}/orders', data={'itens': itens, 'modo': 'retirada', 'pagamento': 'dinheiro'}).json()['order']['id']
    O1 = ped([{'pid': CAN, 'qtd': 1}])
    O2 = ped([{'pid': CAN, 'qtd': 2}, {'pid': CAM['id'], 'vid': BR, 'qtd': 1}, {'pid': ADE, 'qtd': 3}])
    dia = (datetime.date.today() + datetime.timedelta(days=2)).isoformat()
    OB = C.post(f'/api/v2/businesses/{S}/bookings', data={'servico': SV, 'data': dia, 'hora': '10:00'}).json()['order']['id']
    assert RS.put(f'/api/v2/ads/{S}/permissoes-agendamento', data={'servicos': {'ativo': True, 'publico': 'todos', 'reservaMin': 0}}).ok
    OS = C.post(f'/api/v2/businesses/{S}/bookings', data={'servico': SV, 'data': dia, 'hora': '14:00'}).json()['order']['id']
    # edição depois do pedido: a caneca ganha outra foto principal → os pedidos antigos continuam com a foto da compra
    assert P(L, {'id': CAN, 'nome': 'Caneca Vermelha', 'preco': 30, 'categoria': 'Casa', 'fotos': [durl(COR['nova']), durl(COR['caneca'])]}).ok
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        X = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert X.request.post('/api/auth', data={'action': 'login', 'email': 'pia@t.com', 'password': U['password']}).ok
        pg = X.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000)
        pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector(f'[data-odet="{O2}"]', timeout=15000); pg.wait_for_timeout(1500)
        card = lambda oid: pg.locator(f'[data-odet="{oid}"]').locator('xpath=ancestor::div[contains(@class,"px-5")][1]')
        c1, c2 = card(O1), card(O2)
        k1 = cores(c1); k2 = cores(c2)
        check(f'{nome}: pedido de 1 item com a imagem do item', len(k1) == 1 and k1[0] and perto(k1[0], COR['caneca']), k1)
        check(f'{nome}: pedido com vários itens: cada item com a SUA imagem (variação com a foto da variação)', len(k2) == 3 and k2[0] and perto(k2[0], COR['caneca']) and k2[1] and perto(k2[1], COR['branca']), k2)
        ph = c2.locator('[data-oitem]').nth(2).locator('.ma-oth')
        check(f'{nome}: item sem imagem → espaço reservado discreto do mesmo tamanho', ph.get_attribute('data-oi-foto') == '0' and ph.locator('img').count() == 0 and ph.bounding_box()['width'] == c2.locator('[data-oitem]').nth(0).locator('.ma-oth').bounding_box()['width'])
        t = N(c2.locator('[data-oitens]').inner_text())
        check(f'{nome}: nome, quantidade × preço unitário e total de cada item', all(x in t for x in ['Caneca Vermelha', '2 × R$ 30,00', 'R$ 60,00', 'Camiseta', 'Cor: Branca, Tamanho: M', '1 × R$ 45,00', 'Adesivo', '3 × R$ 5,00', 'R$ 15,00']), t)
        ov = pg.evaluate(f"""(()=>{{const rs=[...document.querySelectorAll('[data-oitem]')];return rs.some(r=>{{const a=r.querySelector('.ma-oth').getBoundingClientRect(),b=r.querySelector('.ma-oi-tx').getBoundingClientRect();return a.right>b.left+0.5}})}})()""")
        check(f'{nome}: imagem ao lado das informações, sem sobrepor; sem rolagem lateral', ov is False and pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        if mob: c2.scroll_into_view_if_needed(); pg.wait_for_timeout(300); pg.screenshot(path='/tmp/e2e/pim_lista.png')
        # detalhes
        pg.click(f'[data-odet="{O2}"]'); pg.wait_for_selector(f'[data-pedido-det="{O2}"]'); pg.wait_for_timeout(900)
        dt = pg.locator(f'[data-pedido-det="{O2}"]'); kd = cores(dt); td = N(dt.inner_text())
        check(f'{nome}: detalhes do pedido com as mesmas imagens (maiores), valores por item e total', len(kd) == 3 and kd[0] and perto(kd[0], COR['caneca']) and kd[1] and perto(kd[1], COR['branca']) and kd[2] is None and dt.locator('.ma-oth').first.bounding_box()['width'] == 56 and 'R$ 120,00' in td and 'Caio Cliente' in td, (kd, td[:200]))
        if mob: pg.screenshot(path='/tmp/e2e/pim_detalhe.png')
        pg.click('.ma-sheet-x'); pg.wait_for_timeout(300)
        X.close()
        # Studio: agendamento (lista) e Solicitações (lista + detalhes)
        Y = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert Y.request.post('/api/auth', data={'action': 'login', 'email': 'sara.pim@t.com', 'password': U['password']}).ok
        ps = Y.new_page(); ps.on('pageerror', lambda e: errs.append(str(e)))
        ps.goto(f'/x/solicitacoes?empresa={S}'); ps.wait_for_selector(f'[data-sol="{OS}"]', timeout=20000); ps.wait_for_timeout(1000)
        ks = cores(ps.locator(f'[data-sol="{OS}"]'))
        check(f'{nome}: solicitação de serviço com a imagem do serviço', len(ks) == 1 and ks[0] and perto(ks[0], COR['ensaio']), ks)
        ps.locator(f'[data-sol="{OS}"] [data-sa=detalhes]').click(); ps.wait_for_timeout(900)
        kd2 = [i.evaluate(COR_JS) for i in ps.locator('.ma-sheet [data-oitem] img').all()]
        check(f'{nome}: detalhes da solicitação com a imagem do serviço', len(kd2) == 1 and perto(kd2[0], COR['ensaio']), kd2)
        Y.close()
    # agendamento direto na lista da empresa de serviços (via API do painel: mesma lista que a tela usa)
    ag = next(x for x in RS.get(f'/api/v2/ads/{S}/orders').json()['items'] if x['id'] == OB)
    check('agendamento direto com imagem do serviço, preço e quantidade', ag['itens'][0]['foto'] and ag['itens'][0]['preco'] == 150 and ag['itens'][0]['qtd'] == 1)
    # central de Lojas Conectadas: os pedidos da loja conectada com as imagens
    H = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); RH = H.request
    assert RH.post('/api/auth', data={'action': 'signup', 'name': 'Hugo Central', 'whatsapp': '+55 85 96666-7003', 'email': 'hugo.pim@t.com', **U}, headers={'X-Forwarded-For': '10.8.0.3'}).ok
    HL = loja(RH, 'Central do Hugo')
    k = RH.post('/api/v2/lojas/chaves', data={'horas': 24, 'usos': 1}).json()['chave']
    lid = R.post('/api/v2/lojas/conectar', data={'chave': k, 'lojaId': L, 'papel': 'administrador'}).json()['id']
    assert RH.post(f'/api/v2/lojas/conexoes/{lid}', data={'acao': 'aceitar'}).ok
    ph2 = H.new_page(); ph2.on('pageerror', lambda e: errs.append(str(e)))
    ph2.goto('/x/lojas-conectadas?aba=pedidos&filtro=todos'); ph2.wait_for_selector(f'[data-ped="{O2}"]', timeout=20000); ph2.wait_for_timeout(1200)
    kc = cores(ph2.locator(f'[data-ped="{O2}"]'))
    check('central de lojas: cada item do pedido com a sua imagem', len(kc) == 3 and kc[0] and perto(kc[0], COR['caneca']) and kc[1] and perto(kc[1], COR['branca']) and kc[2] is None, kc)
    H.close()
    # pedido novo depois da edição usa a foto de agora
    O3 = ped([{'pid': CAN, 'qtd': 1}])
    u3 = next(x for x in R.get(f'/api/v2/ads/{L}/orders').json()['items'] if x['id'] == O3)['itens'][0]['foto']
    u1 = next(x for x in R.get(f'/api/v2/ads/{L}/orders').json()['items'] if x['id'] == O1)['itens'][0]['foto']
    Z = b.new_context(base_url=BASE); pz = Z.new_page()
    def cor_url(u):
        pz.goto('/offline.html'); pz.evaluate("u=>new Promise(r=>{const i=new Image();i.id='i';i.onload=i.onerror=r;i.src=u;document.body.appendChild(i)})", u); return pz.locator('#i').evaluate(COR_JS)  # mesma origem
    check('pedido antigo mantém a foto da compra; pedido novo usa a foto atual', perto(cor_url(u1), COR['caneca']) and perto(cor_url(u3), COR['nova']))
    Z.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
