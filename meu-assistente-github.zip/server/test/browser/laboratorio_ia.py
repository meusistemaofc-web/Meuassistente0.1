import sys
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
norm=lambda s:s.replace('\xa0',' ')
TXT='Você criou o agendamento, mas não registrou o pagamento do sinal. Sempre que eu informar que o cliente já pagou um sinal, registre automaticamente o recebimento no financeiro, vincule ao cliente e ao agendamento e atualize o saldo restante.'
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True}).ok
    errs=[]
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    pg.goto('/admin'); pg.wait_for_timeout(1500)
    aba(pg,'lab'); pg.wait_for_selector('#lbtxt',timeout=10000)
    check('aba Laboratório de IA abre com chat, simulador, regras e histórico', all(t in pg.inner_text('body') for t in ['Chat do laboratório','Simulador','Regras e propostas','Histórico']))
    pg.fill('#lbtxt',TXT); pg.click('#lbsend'); pg.wait_for_selector('[data-open]',timeout=20000)
    body=norm(pg.inner_text('body'))
    check('correção vira proposta em rascunho/análise, sem publicar', 'Criei a proposta #1' in body and 'Nada muda em produção' in body, body[-600:])
    pg.locator('[data-open]').first.click(); pg.wait_for_selector('#lbdet',timeout=6000)
    d=norm(pg.inner_text('#lbdet'))
    dl=d.lower(); check('proposta mostra falha, regra, categoria, parecidos e conflitos', 'falha identificada' in dl and 'regras parecidas' in dl and 'conflitos' in dl and 'pagamentos' in dl, d[:400])
    check('regra ainda não está em produção', 'Em produção' not in d)
    pg.click('[data-ac=testar]'); pg.wait_for_selector('text=sem efeito real',timeout=30000)
    check('testes rodam em simulação', 'sem efeito real' in pg.inner_text('#lbdet'))
    pg.click('[data-ac=enviar]'); pg.wait_for_timeout(1500)
    check('envia para aprovação', 'Aguardando aprovação' in pg.inner_text('#lbdet'), pg.inner_text('#lbdet')[:200])
    check('publicar só aparece depois de aprovar', pg.locator('[data-ac=publicar]').count()==0)
    pg.click('[data-ac=aprovar]'); pg.wait_for_selector('[data-ac=publicar]',timeout=6000)
    pg.click('[data-ac=publicar]'); pg.wait_for_selector('#lbdet >> text=v1 ·',timeout=8000)
    d=norm(pg.inner_text('#lbdet'))
    check('publicada: em produção, com versão e histórico do administrador', 'Publicada' in d and 'Em produção' in d and 'v1 ·' in d and 'Aprovada' in d and 'admin' in d, d[-500:])
    pg.screenshot(path='/tmp/e2e/lab_proposta.png',full_page=True)
    pg.click('[data-ac=desativar]'); pg.wait_for_timeout(1500)
    check('desativar tira da produção', 'Desativada' in pg.inner_text('#lbdet') and 'Em produção' not in pg.inner_text('#lbdet'))
    pg.click('#lbback'); pg.wait_for_selector('#lbfil',timeout=5000)
    check('lista de regras mostra a proposta com o estado', 'Desativada' in pg.inner_text('body'))
    pg.locator('[data-lv=sim]').click(); pg.wait_for_selector('#sitxt'); pg.fill('#sitxt','Ana pagou R$ 50 de sinal'); pg.click('#sirun'); pg.wait_for_selector('#simres',timeout=30000)
    check('simulador avisa que nada foi gravado', 'nada foi gravado' in pg.inner_text('#simres').lower())
    pg.locator('[data-lv=hist]').click(); pg.wait_for_timeout(800)
    h=norm(pg.inner_text('body')); check('histórico geral registra correção, publicação e desativação', all(t in h for t in ['Correção realizada','Publicada','Desativada']), h[:400])
    pg.screenshot(path='/tmp/e2e/lab_hist.png',full_page=True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
