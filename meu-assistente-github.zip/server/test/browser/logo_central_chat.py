# Tela inicial do chat: a logo M fica no centro (horizontal e vertical) da área principal — entre o cabeçalho e o campo
# de digitação — com os botões rápidos numa área própria embaixo, sem deslocá-la:
# • telas com espaço (celulares comuns e computadores): logo no centro exato (±2 px) com os botões visíveis;
# • posição estável: não muda durante o carregamento/animação, nem quando os botões somem, nem com os botões desligados;
# • telas baixas e teclado aberto: a logo fica o mais perto possível do centro sem nunca encostar nos botões;
#   ao voltar o tamanho (teclado fechado), volta ao centro;
# • nada sobrepõe o campo de digitação; animação de entrada preservada; sem rolagem lateral; sem erros de JS.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-logo.db npx tsx test/serve-sqlite.ts (banco novo)
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
M="""()=>{const sc=document.querySelector('.chat-scroll'),m=document.querySelector('.nx-welcome-mark');if(!m)return null;const a=sc.getBoundingClientRect(),r=m.getBoundingClientRect(),h=m.closest('.rise');
const l=document.querySelector('.ma-qb-list'),bs=l?[...l.querySelectorAll('.ma-qb-item')].filter(x=>x.offsetParent):[],b1=bs[0]&&bs[0].getBoundingClientRect(),bl=bs.length&&bs[bs.length-1].getBoundingClientRect();
const ta=document.querySelector('textarea.composer-input');let f=ta.parentElement;for(let k=0;k<6&&f.querySelectorAll('button').length<3;k++)f=f.parentElement;const cp=f.getBoundingClientRect();
const hr=h.getBoundingClientRect();
return {dy:Math.round((r.top+r.height/2)-(a.top+a.bottom)/2),dx:Math.round((r.left+r.width/2)-(a.left+a.right)/2),y:Math.round(r.top),n:bs.length,
 folga:b1?Math.round(b1.top-hr.bottom):null,sobreCampo:bl?bl.bottom>cp.top+1:false,anim:getComputedStyle(h).animationName,hx:document.documentElement.scrollWidth-innerWidth}}"""
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE); assert A.request.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1277','email':'admin.logo@t.com',**U}).ok
    assert A.request.put('/api/panel/modules',data={'sugestoes':True}).ok
    def abrir(vp,mob):
        C=b.new_context(base_url=BASE,viewport=vp,is_mobile=mob,has_touch=mob); C.add_cookies(A.cookies()); pg=C.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('.ma-qb-item',timeout=20000); pg.wait_for_timeout(700)
        if pg.get_by_text('Agora não').count(): pg.get_by_text('Agora não').first.click()
        pg.wait_for_timeout(900); return C,pg
    # 1) telas com espaço: centro exato, estável, e não muda quando os botões somem
    for nome,vp,mob in [('celular 390×844',{'width':390,'height':844},True),('celular 414×896',{'width':414,'height':896},True),('computador 1280×860',{'width':1280,'height':860},False),('computador 1920×1080',{'width':1920,'height':1080},False)]:
        print('==',nome)
        C,pg=abrir(vp,mob); m=pg.evaluate(M)
        check(f'{nome}: logo no centro da área principal com os 3 botões visíveis', m['n']==3 and abs(m['dy'])<=2 and abs(m['dx'])<=1, m)
        check(f'{nome}: botões abaixo da logo, sem encostar no texto nem no campo', m['folga']>=12 and not m['sobreCampo'], m)
        ys=[]
        for _ in range(8): ys.append(pg.evaluate(M)['y']); pg.wait_for_timeout(120)
        check(f'{nome}: posição estável (sem subir/descer)', len(set(ys))==1, ys)
        check(f'{nome}: animação de entrada preservada', m['anim']=='nx-rise', m['anim'])
        if nome.startswith('celular 390'): pg.screenshot(path='/tmp/e2e/logo_central_celular.png')
        if nome.startswith('computador 1280'): pg.screenshot(path='/tmp/e2e/logo_central_computador.png')
        # botões somem (mesmo caminho do 1º toque/envio): a logo fica no mesmo lugar
        pg.evaluate("()=>{const b=document.querySelector('.chat-scroll .mt-7');b.dataset.maGone='1';b.style.setProperty('display','none','important');dispatchEvent(new Event('resize'))}"); pg.wait_for_timeout(400)
        m2=pg.evaluate(M); check(f'{nome}: botões somem e a logo não se move', m2['n']==0 and m2['y']==m['y'], (m['y'],m2['y']))
        check(f'{nome}: sem rolagem lateral', m['hx']<=1)
        C.close()
    # 2) telas baixas e teclado aberto: o mais perto do centro sem encostar nos botões; estável quando somem
    for nome,vp in [('celular 360×640',{'width':360,'height':640}),('celular 320×568',{'width':320,'height':568})]:
        print('==',nome)
        C,pg=abrir(vp,True); m=pg.evaluate(M)
        check(f'{nome}: logo centralizada na horizontal e acima do centro só o necessário (sem encostar nos botões)', abs(m['dx'])<=1 and m['dy']<=2 and m['folga']>=11 and not m['sobreCampo'], m)
        pg.evaluate("()=>{const b=document.querySelector('.chat-scroll .mt-7');b.dataset.maGone='1';b.style.setProperty('display','none','important');dispatchEvent(new Event('resize'))}"); pg.wait_for_timeout(400)
        check(f'{nome}: botões somem e a logo não se move', pg.evaluate(M)['y']==m['y'])
        C.close()
    print('== teclado (celular 390×844 → 390×430 → 390×844)')
    C,pg=abrir({'width':390,'height':844},True); m0=pg.evaluate(M)
    pg.set_viewport_size({'width':390,'height':430}); pg.wait_for_timeout(600); k=pg.evaluate(M)
    check('teclado aberto: nada encosta nos botões nem passa por cima do campo', k['folga']>=11 and not k['sobreCampo'] and abs(k['dx'])<=1, k)
    pg.screenshot(path='/tmp/e2e/logo_central_teclado.png')
    pg.set_viewport_size({'width':390,'height':844}); pg.wait_for_timeout(600); k2=pg.evaluate(M)
    check('teclado fechado: logo volta exatamente ao centro', abs(k2['dy'])<=2 and k2['y']==m0['y'], (m0,k2))
    C.close()
    # 3) botões desligados no painel: logo continua no centro
    print('== botões desligados')
    assert A.request.put('/api/panel/quick_buttons',data={'enabled':False,'items':[{'texto':'Lojas','comando':'Lojas perto de mim','icone':'loja'}]}).ok
    C=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True); C.add_cookies(A.cookies()); pg=C.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('.nx-welcome-mark',timeout=20000); pg.wait_for_timeout(700)
    if pg.get_by_text('Agora não').count(): pg.get_by_text('Agora não').first.click()
    pg.wait_for_timeout(1200); m=pg.evaluate(M)
    check('desligados: sem botões e logo no centro', m['n']==0 and abs(m['dy'])<=2 and abs(m['dx'])<=1, m)
    C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
