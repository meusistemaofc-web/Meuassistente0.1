# Vitrine pública "Empresas perto de você" (/x/empresas): aba Serviços igual à de Produtos, detalhes do serviço, página da
# empresa, pesquisa/filtros/ordem, compartilhamento (vitrine e cards de empresas, produtos e serviços), links abertos de fora
# (sem conta, sem passar pela página inicial) e visitante sem login. Celular e computador.
# Servidor: python3 test/browser/geocoder_fake.py 4399 &  GEOCODER_URL=http://127.0.0.1:4399 PORT=4322 SQLITE_FILE=/tmp/ma-vit.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime, base64, os
from urllib.parse import unquote
from PIL import Image
from playwright.sync_api import sync_playwright
from _descobrir import menu, fechar_menu, loc_click, loc_txt, loc_aria, ofertas, tem_ofertas, ordenar, ordem
BASE = 'http://localhost:4322'; DBF = '/tmp/ma-vit.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor, w=400, h=300):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'JPEG', quality=70); return 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
MANAUS = (-3.1, -60.02)  # o geocodificador falso devolve isto para "manaus"
# captura o compartilhamento nativo (o Chromium de teste não tem navigator.share) e a área de transferência
SHARE_JS = "window.__shares=[];navigator.share=async d=>{window.__shares.push(d)};"
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 92 94444-1234', 'email': 'ana.vit@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(empresa, cat, dlat, servicos):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': cat, 'titulo': f'{empresa} no seu bairro', 'texto': 'Qualidade e preço justo', 'zap': '5592999990000'}); assert r.ok, r.text()
        i = r.json()['items'][0]['id']
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        if servicos: assert R.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
        db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (i,)).fetchone()[0]); d['capa'] = img((60, 90, 160), 800, 450); d['logo'] = img((240, 240, 240), 120, 120)
        db.execute("update businesses set status='ativo', expires_at=?, lat=?, lng=?, data=? where id=?", ((datetime.datetime.now(datetime.UTC).replace(tzinfo=None) + datetime.timedelta(days=30)).isoformat() + 'Z', MANAUS[0] + dlat, MANAUS[1], json.dumps(d), i)); db.commit(); db.close()
        return i
    S = loja('Salão da Ana', 'Salão de beleza', 0.004, True)
    C = loja('Clínica Bem Estar', 'Estética', 0.02, True)
    L = loja('Moda Manaus', 'Roupas', 0.006, False)
    P = lambda bid, d: R.post(f'/api/v2/ads/{bid}/products', data=d)
    def sid(bid, nome): return next(x['id'] for x in R.get(f'/api/v2/ads/{bid}/products').json()['items'] if x['nome'] == nome)
    assert P(S, {'tipo': 'servico', 'nome': 'Corte feminino', 'preco': 80, 'modoPreco': 'fixo', 'duracao': 60, 'categoria': 'Cabelo', 'descricao': 'Corte com lavagem e finalização', 'fotos': [img((200, 120, 160))]}).ok
    assert P(S, {'tipo': 'servico', 'nome': 'Escova', 'preco': 45, 'modoPreco': 'fixo', 'duracao': 40, 'categoria': 'Cabelo', 'fotos': [img((180, 140, 100))]}).ok
    assert P(S, {'tipo': 'servico', 'nome': 'Noiva completa', 'preco': 0, 'modoPreco': 'orcamento', 'duracao': 180, 'categoria': 'Eventos'}).ok
    assert P(C, {'tipo': 'servico', 'nome': 'Avaliação facial', 'preco': 120, 'modoPreco': 'consulta', 'duracao': 30, 'categoria': 'Estética', 'fotos': [img((90, 160, 140))]}).ok
    assert P(C, {'tipo': 'servico', 'nome': 'Massagem relaxante', 'preco': 90, 'modoPreco': 'hora', 'duracao': 60, 'categoria': 'Estética', 'fotos': [img((70, 110, 170))]}).ok
    assert P(L, {'nome': 'Camiseta Manaus', 'preco': 49.9, 'categoria': 'Camisetas', 'fotos': [img((20, 20, 20))], 'oferta': {'ativo': True, 'preco': 39.9}}).ok
    assert P(L, {'nome': 'Boné', 'preco': 35, 'categoria': 'Acessórios', 'fotos': [img((30, 80, 200))]}).ok
    CORTE, MASS, CAMI = sid(S, 'Corte feminino'), sid(C, 'Massagem relaxante'), sid(L, 'Camiseta Manaus')
    def sem_rolagem_lateral(pg): return pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        # ---------- visitante SEM conta ----------
        V = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, geolocation={'latitude': MANAUS[0], 'longitude': MANAUS[1]}, permissions=['geolocation', 'clipboard-read', 'clipboard-write'])
        V.add_init_script(SHARE_JS)
        pg = V.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/empresas'); pg.wait_for_selector('#locok', timeout=20000)
        check(f'{nome}: visitante sem conta abre a vitrine (sem ir para a tela de entrar) e é convidado a informar a localização', '/x/empresas' in pg.url and 'entrar' not in pg.url and pg.locator('#locok').count() == 1, pg.url)
        pg.fill('#lai2', 'manaus'); pg.click('#laf2 button'); pg.wait_for_selector('[data-emp]', timeout=15000); pg.wait_for_timeout(800)
        check(f'{nome}: cidade digitada pelo visitante → empresas reais com distância (nada gravado na conta)', pg.locator(f'[data-emp="{S}"]').count() == 1 and 'Manaus' in N(loc_txt(pg)) and pg.evaluate("!!localStorage.getItem('ma-loc-visitante')"), loc_txt(pg))
        check(f'{nome}: três abas no mesmo padrão: Empresas | Produtos | Serviços', [x.inner_text() for x in pg.locator('.ma-seg [data-modo]').all()] == ['Empresas', 'Produtos', 'Serviços'] and len(set(pg.evaluate("[...document.querySelectorAll('.ma-seg [data-modo]')].map(b=>getComputedStyle(b).height+getComputedStyle(b).fontSize)"))) == 1)
        check(f'{nome}: ícone discreto de compartilhar no cabeçalho', pg.locator('header [data-share-vitrine]').count() == 1 and pg.locator('header [data-share-vitrine]').is_visible() and pg.locator('header [data-share-vitrine] svg path').count() >= 2)
        PUB = pg.evaluate('window.__MA_PUB').rstrip('/')  # links compartilhados usam o endereço público oficial
        check(f'{nome}: card de empresa com ícone de compartilhar', pg.locator(f'[data-emp="{S}"] [data-shr] svg path').count() >= 2)
        # ---------- aba Serviços ----------
        pg.click('[data-modo=servicos]'); pg.wait_for_selector('[data-mk]', timeout=10000); pg.wait_for_timeout(500)
        nomes = [N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()]
        check(f'{nome}: Serviços sem recarregar (modo na URL) com todos os serviços cadastrados e só serviços', 'modo=servicos' in pg.url and pg.evaluate('performance.getEntriesByType("navigation").length') == 1 and sorted(nomes) == sorted(['Corte feminino', 'Escova', 'Noiva completa', 'Avaliação facial', 'Massagem relaxante']), nomes)
        c1 = pg.locator(f'[data-mk="{CORTE}"]'); t = N(c1.inner_text())
        check(f'{nome}: card do serviço com imagem, nome, preço, empresa e distância', c1.locator('.ma-mkimg img').count() == 1 and 'Corte feminino' in t and 'R$ 80,00' in t and 'Salão da Ana' in t and ' m' in t and c1.locator('[data-mk-loja]').get_attribute('href') == f'/x/empresa/{S}', t)
        t2 = N(pg.locator(f'[data-mk="{MASS}"]').inner_text()); t3 = N(pg.locator('[data-mk]', has_text='Noiva completa').inner_text())
        check(f'{nome}: preço por hora e sob orçamento', '/hora' in t2 and 'Sob orçamento' in t3, (t2, t3))
        # mesmo visual dos produtos: mesma classe de grade, imagem quadrada, colunas
        cols = pg.evaluate("getComputedStyle(document.querySelector('[data-mkgrid]')).gridTemplateColumns.split(' ').length")
        ar = pg.evaluate("(()=>{const r=document.querySelector('[data-mk] .ma-mkimg').getBoundingClientRect();return Math.round(r.width/r.height*100)/100})()")
        check(f'{nome}: mesma grade dos produtos ({2 if mob else 3} colunas, imagem quadrada)', cols == (2 if mob else 3) and ar == 1, (cols, ar))
        check(f'{nome}: sem botões extras no card (só o ícone de compartilhar, visível)', c1.locator('button').count() == 1 and c1.locator('[data-shr-item] svg path').count() >= 2)
        check(f'{nome}: localização legível no menu ⋮, que não encosta nas três abas', len(N(loc_txt(pg)).strip()) >= 6 and pg.evaluate("(()=>{const a=document.querySelector('.ma-seg').getBoundingClientRect(),b=document.querySelector('[data-dsc-mais]').getBoundingClientRect();return a.right<=b.left})()"), loc_txt(pg))
        if mob: pg.screenshot(path='/tmp/e2e/vit_servicos.png')
        else: pg.screenshot(path='/tmp/e2e/vit_servicos_pc.png')
        # pesquisa, ordem, categorias
        ordenar(pg, 'menor'); pg.wait_for_timeout(900)
        pr = [N(x.inner_text()) for x in pg.locator('[data-mk-preco]').all()]
        check(f'{nome}: ordem menor preço (sob orçamento por último)', pr[0].startswith('R$ 45,00') and 'Sob orçamento' in pr[-1], pr)
        pg.click('[data-cat="Estética"]'); pg.wait_for_timeout(900)
        check(f'{nome}: filtro de categoria', sorted(N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()) == ['Avaliação facial', 'Massagem relaxante'])
        pg.click('[data-cat=""]'); pg.wait_for_timeout(700); ordenar(pg, 'proximos'); pg.wait_for_timeout(700)
        pg.fill('#pqi', 'escova'); pg.press('#pqi', 'Enter'); pg.wait_for_timeout(900)
        check(f'{nome}: pesquisa de serviços', [N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()] == ['Escova'])
        pg.fill('#pqi', ''); pg.press('#pqi', 'Enter'); pg.wait_for_timeout(900)
        check(f'{nome}: "Ofertas" escondido quando nenhum serviço está em oferta', not tem_ofertas(pg))
        # compartilhar um serviço pelo card (não abre o serviço)
        pg.click(f'[data-mk="{CORTE}"] [data-shr-item]'); pg.wait_for_selector('[data-share-sheet]')
        url_s = f'{PUB}/x/empresa/{S}?servico={CORTE}&ref=share'  # link individual (com marca de compartilhamento para contar visitas)
        wa = unquote(pg.get_attribute('[data-sh=whatsapp]', 'href'))
        check(f'{nome}: compartilhar serviço → WhatsApp, outros aplicativos e copiar com o link direto do serviço', 'modo=servicos' in pg.url and wa.startswith('https://wa.me/?text=') and url_s in wa and pg.locator('[data-sh=apps]').count() == 1 and N(pg.inner_text('[data-sh-url]')) == url_s, wa)
        pg.click('[data-sh=copiar]'); pg.wait_for_timeout(300)
        check(f'{nome}: copiar link do serviço', pg.evaluate('navigator.clipboard.readText()') == url_s and pg.locator('[data-share-sheet]').count() == 0)
        # abrir o serviço pelo card
        pg.click(f'[data-mk="{CORTE}"] .ma-mkimg'); pg.wait_for_selector(f'[data-detalhe="{CORTE}"]', timeout=10000); pg.wait_for_timeout(400)
        dt = N(pg.inner_text(f'[data-detalhe="{CORTE}"]'))
        check(f'{nome}: tocar no card abre o detalhe do serviço (descrição, preço) na página da empresa', f'/x/empresa/{S}' in pg.url and 'Corte feminino' in dt and 'Corte com lavagem' in dt and 'R$ 80,00' in dt, (pg.url, dt[:200]))
        if mob: pg.screenshot(path='/tmp/e2e/vit_servico_detalhe.png')
        pg.click('.ma-sheet-x'); pg.wait_for_timeout(400)
        check(f'{nome}: atrás do detalhe, a página da empresa com os outros serviços', 'Salão da Ana' in pg.inner_text('#ma-x') and pg.locator('[data-det]').count() == 3)
        pg.go_back(); pg.wait_for_selector('[data-mk]', timeout=10000); pg.wait_for_timeout(500)
        check(f'{nome}: voltar retorna à aba Serviços', pg.get_attribute('[data-modo=servicos]', 'aria-selected') == 'true')
        # nome da empresa no card leva à empresa
        pg.click(f'[data-mk="{MASS}"] [data-mk-loja]'); pg.wait_for_timeout(1500)
        check(f'{nome}: empresa responsável pelo card do serviço', f'/x/empresa/{C}' in pg.url and 'Clínica Bem Estar' in pg.inner_text('#ma-x'))
        pg.go_back(); pg.wait_for_selector('[data-mk]', timeout=10000)
        # ---------- Produtos continuam iguais ----------
        pg.click('[data-modo=produtos]'); pg.wait_for_selector('[data-mk]', timeout=10000); pg.wait_for_timeout(500)
        pn = [N(x.inner_text()) for x in pg.locator('[data-mk-nome]').all()]
        check(f'{nome}: Produtos continuam funcionando, sem serviços misturados', sorted(pn) == ['Boné', 'Camiseta Manaus'] and pg.locator(f'[data-mk="{CAMI}"] [data-oferta]').count() == 1, pn)
        pg.click(f'[data-mk="{CAMI}"] [data-shr-item]'); pg.wait_for_selector('[data-share-sheet]')
        url_p = f'{PUB}/x/empresa/{L}?produto={CAMI}&ref=share'
        check(f'{nome}: compartilhar produto pelo card', N(pg.inner_text('[data-sh-url]')) == url_p)
        pg.click('[data-sh=apps]'); pg.wait_for_timeout(300)
        sh = pg.evaluate('window.__shares')
        check(f'{nome}: "Outros aplicativos" usa o compartilhamento nativo com o link', sh and sh[-1]['url'] == url_p, sh)
        # compartilhar a vitrine
        pg.click('[data-share-vitrine]'); pg.wait_for_selector('[data-share-sheet]')
        wa = unquote(pg.get_attribute('[data-sh=whatsapp]', 'href'))
        check(f'{nome}: compartilhar a vitrine → texto atrativo + endereço permanente', 'Descubra empresas, produtos e serviços perto de você!' in wa and f'{PUB}/x/empresas' in wa and N(pg.inner_text('[data-sh-url]')) == f'{PUB}/x/empresas', wa)
        pg.click('[data-sh=copiar]'); pg.wait_for_timeout(300)
        check(f'{nome}: copiar link da vitrine', pg.evaluate('navigator.clipboard.readText()') == f'{PUB}/x/empresas')
        pg.click('[data-modo=empresas]'); pg.wait_for_selector('[data-emp]', timeout=10000)
        pg.click(f'[data-emp="{S}"] [data-shr]'); pg.wait_for_selector('[data-share-sheet]')
        check(f'{nome}: compartilhar empresa pelo card', N(pg.inner_text('[data-sh-url]')) == f'{PUB}/x/empresa/{S}')
        pg.click('.ma-sheet-x')
        check(f'{nome}: sem rolagem lateral', sem_rolagem_lateral(pg))
        V.close()
        # ---------- links abertos de fora (WhatsApp/navegador): sem conta e sem passar pela página inicial ----------
        X = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); px = X.new_page(); px.on('pageerror', lambda e: errs.append(str(e)))
        px.goto(f'/x/empresa/{S}?servico={CORTE}'); px.wait_for_selector(f'[data-detalhe="{CORTE}"]', timeout=20000)
        check(f'{nome}: link do serviço aberto de fora abre direto o serviço', 'Corte feminino' in px.inner_text(f'[data-detalhe="{CORTE}"]') and 'entrar' not in px.url)
        px.goto(f'/x/empresa/{L}?produto={CAMI}'); px.wait_for_selector(f'[data-detalhe="{CAMI}"]', timeout=20000)
        check(f'{nome}: link do produto aberto de fora abre direto o produto', 'Camiseta Manaus' in px.inner_text(f'[data-detalhe="{CAMI}"]'))
        px.goto(f'/x/empresa/{C}'); px.wait_for_selector('[data-det]', timeout=20000)
        check(f'{nome}: link da empresa aberto de fora', 'Clínica Bem Estar' in px.inner_text('#ma-x') and px.locator('[data-det]').count() == 2)
        px.goto('/x/empresas?modo=servicos'); px.wait_for_selector('#locok', timeout=20000)
        check(f'{nome}: link da vitrine aberto de fora (sem conta) abre a vitrine', '/x/empresas' in px.url and 'entrar' not in px.url and px.locator('#locok').is_visible(), px.url)
        X.grant_permissions(['geolocation']); X.set_geolocation({'latitude': MANAUS[0], 'longitude': MANAUS[1]})
        px.click('#locok'); px.wait_for_selector('[data-mk]', timeout=15000)
        check(f'{nome}: localização automática do visitante → aba Serviços preservada', px.get_attribute('[data-modo=servicos]', 'aria-selected') == 'true' and px.locator('[data-mk]').count() == 5)
        X.close()
        # ---------- prévia do link (WhatsApp lê o HTML) ----------
        if mob:
            h = R.get(f'/x/empresa/{S}?servico={CORTE}').text()
            check('prévia do link do serviço (og:title, og:image)', 'og:title" content="Corte feminino · Salão da Ana"' in h and f'/api/v2/vitrine/imagem/item/{CORTE}' in h)
            h = R.get('/x/empresas').text()
            check('prévia do link da vitrine', 'Descubra empresas, produtos e serviços perto de você!' in h)
        # ---------- conta logada continua igual ----------
        A = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); RA = A.request
        assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Rui Cliente', 'whatsapp': '+55 92 95555-01' + ('01' if mob else '02'), 'email': f'rui.vit.{nome}@t.com', **U}, headers={'X-Forwarded-For': '10.9.2.' + ('1' if mob else '2')}).ok
        assert RA.put('/api/v2/me/location', data={'lat': MANAUS[0], 'lng': MANAUS[1]}).ok
        pa = A.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
        pa.goto('/x/empresas?modo=servicos'); pa.wait_for_selector('[data-mk]', timeout=20000)
        check(f'{nome}: com conta, a vitrine usa a localização da conta (Serviços direto pelo link)', pa.locator('[data-mk]').count() == 5 and pa.evaluate("!localStorage.getItem('ma-loc-visitante')"))
        A.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
