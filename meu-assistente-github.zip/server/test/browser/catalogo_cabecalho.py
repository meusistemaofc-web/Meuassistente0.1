# Catálogo público (/x/empresa/:id) — apresentação da empresa: capa separada da logo (sem sobreposição), logo à esquerda com
# nome / categoria · distância / status em verde à direita, ícones de contato outline brancos sem círculo/fundo/borda (links
# preservados), cabeçalho mais compacto (produtos aparecem mais cedo), telas pequenas, tema claro e itens do catálogo intactos.
# Requer a empresa criada por tema_catalogo_agente.py (id 1, admin@t.com).
import sys, json
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
JS="""()=>{const r=e=>{if(!e)return null;const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,w:x.width,h:x.height}};
const q=s=>document.querySelector(s);const ic=[...document.querySelectorAll('.ma-emp-ct .ma-ico-btn')];
return {capa:r(q('.ma-emp-capa')),logo:r(q('.ma-emp-logo')),tx:r(q('.ma-emp-tx')),nm:q('.ma-emp-nm')&&q('.ma-emp-nm').textContent,nmFs:parseFloat(getComputedStyle(q('.ma-emp-nm')).fontSize),
 meta:[...document.querySelectorAll('.ma-emp-meta')].map(x=>({t:x.textContent,fs:parseFloat(getComputedStyle(x).fontSize)})),st:q('.ma-emp-st')&&{t:q('.ma-emp-st').textContent,c:getComputedStyle(q('.ma-emp-st')).color},
 ic:ic.map(e=>{const cs=getComputedStyle(e);return {l:e.getAttribute('aria-label'),href:e.getAttribute('href'),r:r(e),bw:cs.borderTopWidth,bs:cs.borderTopStyle,bg:cs.backgroundColor,c:cs.color,sw:e.querySelector('svg').getAttribute('stroke-width'),inner:e.querySelector('svg').children.length,fill:e.querySelector('svg').getAttribute('fill')}}),
 prod:r(q('[data-prod]')),cats:document.querySelectorAll('[data-cat]').length,busca:!!q('#psearch'),add:document.querySelectorAll('[data-add]').length,sw:document.documentElement.scrollWidth,vw:innerWidth,
 logos:document.querySelectorAll('.ma-emp-logo').length,sobre:r(q('.ma-emp-sobre')),sobreTxt:q('.ma-emp-sobre')&&q('.ma-emp-sobre').textContent,nmCs:(()=>{const x=getComputedStyle(q('.ma-emp-nm'));return {ws:x.whiteSpace,h:q('.ma-emp-nm').getBoundingClientRect().height,lh:parseFloat(x.lineHeight)}})(),catTxt:[...document.querySelectorAll('[data-cat]')].map(b=>b.textContent.trim()),catOn:(document.querySelector('[data-cat].btn-send')||{}).textContent,nProd:document.querySelectorAll('[data-prod],[data-book]').length,capas:document.querySelectorAll('.ma-emp-capa').length}}"""
def mod(route,extra):
    r=route.fetch(); j=r.json(); j.update(extra); route.fulfill(response=r,body=json.dumps(j),headers={**r.headers,'content-type':'application/json'})
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    c0=b.new_context(base_url=BASE); R=c0.request
    assert R.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
    R.put('/api/v2/ads/1',data={'tema':{'preset':'padrao','cor':'#3b6cff','fundo':'escuro','layout':'lista','cantos':'arredondado'}})
    st=c0.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('celular pequeno',{'width':320,'height':640},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/api/v2/businesses/1',lambda rt:mod(rt,{'distancia':1.4}))
        pg.goto('/x/empresa/1'); pg.wait_for_selector('[data-prod]',timeout=20000); pg.wait_for_timeout(4500)
        d=pg.evaluate(JS)
        check(f'{nome}: capa e logo separadas (logo abaixo da capa, sem sobreposição, com espaço)', d['capa'] and d['logo'] and 6<=d['logo']['t']-d['capa']['b']<=24, (d['capa'],d['logo']))
        check(f'{nome}: um único cabeçalho (sem componente duplicado)', d['logos']==1 and d['capas']==1)
        check(f'{nome}: logo à esquerda e informações ao lado direito', d['tx']['l']>=d['logo']['r']+8 and d['tx']['t']<d['logo']['b'] , (d['logo'],d['tx']))
        check(f'{nome}: nome em destaque; categoria · distância em fonte menor', d['nm']=='Pizzaria Forno' and d['meta'] and d['meta'][0]['t']=='Restaurantes · 1,4 km' and d['meta'][0]['fs']<d['nmFs'], (d['nm'],d['meta'],d['nmFs']))
        check(f'{nome}: status "Aberto agora" em verde', d['st'] and d['st']['t']=='Aberto agora' and (lambda c:[int(x) for x in c[c.index('(')+1:c.index(')')].split(',')[:3]])(d['st']['c'])[1]>150, d['st'])
        check(f'{nome}: ícones Localização, WhatsApp, Instagram — outline fino, brancos, sem borda nem fundo', [i['l'] for i in d['ic']]==['Localização','WhatsApp','Instagram'] and all(i['bw']=='0px' or i['bs']=='none' for i in d['ic']) and all(i['bg'] in ('rgba(0, 0, 0, 0)','transparent') for i in d['ic']) and all(i['c']=='rgb(255, 255, 255)' and i['sw']=='1.5' and i['fill']=='none' for i in d['ic']), d['ic'])
        check(f'{nome}: localização com o detalhe de dentro; WhatsApp só o contorno; Instagram como estava', [i['inner'] for i in d['ic']]==[2,1,3], [i['inner'] for i in d['ic']])
        check(f'{nome}: links originais preservados', {i['l']:i['href'] for i in d['ic'] if i['href']}=={'WhatsApp':'https://wa.me/5511999990000','Instagram':'https://instagram.com/pizzariaforno'}, d['ic'])
        check(f'{nome}: ícones alinhados e com área de toque de 36px', len({round(i['r']['t']) for i in d['ic']})==1 and all(round(i['r']['w'])==36 and round(i['r']['h'])==36 for i in d['ic']), d['ic'])
        check(f'{nome}: nada sai da tela (sem rolagem horizontal)', d['sw']<=d['vw']+1 and all(i['r']['r']<=d['vw'] for i in d['ic']), (d['sw'],d['vw']))
        check(f'{nome}: ícones acima da descrição, alinhados à esquerda com a logo', all(i['r']['b']<=d['sobre']['t']+1 for i in d['ic']) and all(i['r']['t']>=d['logo']['b'] for i in d['ic']) and abs((d['ic'][0]['r']['l']+7)-d['logo']['l'])<=3, (d['ic'][0]['r'],d['logo'],d['sobre']))
        check(f'{nome}: nome da empresa em uma linha', d['nmCs']['ws']=='nowrap' and d['nmCs']['h']<d['nmCs']['lh']*1.5, d['nmCs'])
        check(f'{nome}: categorias com "Todos" em primeiro, selecionado por padrão, mostrando tudo', d['catTxt'][0]=='Todos' and d['catOn']=='Todos' and d['catTxt'][1:]==['Pizzas','Bebidas'] and d['nProd']==3, (d['catTxt'],d['catOn'],d['nProd']))
        check(f'{nome}: busca, categorias, produtos e botões de adicionar intactos', d['busca'] and d['cats']==3 and d['add']>=1)
        if nome=='celular':
            check('celular: primeiro produto aparece mais cedo que o cabeçalho antigo (topo < 520px; antes 580px)', d['prod']['t']<520, d['prod'])
            pg.screenshot(path='/tmp/e2e/catalogo_cabecalho_celular.png')
        if nome=='celular pequeno': pg.screenshot(path='/tmp/e2e/catalogo_cabecalho_pequeno.png')
        if nome=='computador': pg.screenshot(path='/tmp/e2e/catalogo_cabecalho_computador.png')
        pg.locator('[data-cat]',has_text='Bebidas').click(); pg.wait_for_timeout(300); n1=pg.locator('[data-prod],[data-book]').count()
        pg.locator('[data-cat]',has_text='Todos').click(); pg.wait_for_timeout(300); n2=pg.locator('[data-prod],[data-book]').count()
        check(f'{nome}: filtrar por categoria e voltar para Todos', n1==1 and n2==3, (n1,n2))
        # localização abre/fecha o mapa
        pg.click('#locbtn'); pg.wait_for_timeout(500)
        check(f'{nome}: ícone de localização abre o mapa', pg.evaluate("()=>getComputedStyle(document.getElementById('mapbox')).display!=='none'"))
        pg.click('#locbtn'); pg.wait_for_timeout(300)
        check(f'{nome}: e fecha de novo', pg.evaluate("()=>getComputedStyle(document.getElementById('mapbox')).display==='none'"))
        # carrinho continua funcionando
        pg.locator('[data-add]').nth(1).click(); pg.wait_for_timeout(500)
        check(f'{nome}: adicionar ao pedido continua funcionando (barra do pedido)', pg.locator('text=Ver pedido').count()>0)
        c.close()
    # nome longo, sem distância, loja fechada, tema claro
    c=b.new_context(viewport={'width':360,'height':740},base_url=BASE,storage_state=st,is_mobile=True,has_touch=True); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    R.put('/api/v2/ads/1',data={'tema':{'preset':'natural','cor':'#2f9e5b','fundo':'claro','layout':'grade','cantos':'arredondado'}})
    pg.route('**/api/v2/businesses/1',lambda rt:mod(rt,{'empresa':'Pizzaria e Restaurante Forno a Lenha da Família Rossi','aberto':False,'situacao':'Fechado agora','sobre':'Pizzaria familiar. '*25}))
    pg.goto('/x/empresa/1'); pg.wait_for_selector('[data-prod]',timeout=20000); pg.wait_for_timeout(4500)
    d=pg.evaluate(JS)
    check('nome longo: fica em uma linha (reticências) sem empurrar nada para fora', d['nmCs']['h']<d['nmCs']['lh']*1.5 and d['tx']['h']<90 and all(i['r']['r']<=d['vw'] for i in d['ic']) and d['sw']<=d['vw']+1, (d['tx'],d['sw']))
    check('descrição mostrada com até 300 caracteres', d['sobreTxt'] and len(d['sobreTxt'])<=300 and d['sobreTxt'].endswith('…'), len(d['sobreTxt'] or ''))
    check('sem distância: mostra só a categoria', d['meta'][0]['t']=='Restaurantes', d['meta'])
    check('loja fechada: status em vermelho (não verde)', d['st']['t']=='Fechado agora' and 'rgb(' in d['st']['c'] and (lambda c:[int(x) for x in c[c.index('(')+1:c.index(')')].split(',')[:3]])(d['st']['c'])[0]>150, d['st'])
    check('tema claro: ícones usam a cor do texto (visíveis no fundo claro)', all(i['c']!='rgb(255, 255, 255)' for i in d['ic']), [i['c'] for i in d['ic']])
    pg.screenshot(path='/tmp/e2e/catalogo_cabecalho_claro.png')
    R.put('/api/v2/ads/1',data={'tema':{'preset':'padrao','cor':'#3b6cff','fundo':'escuro','layout':'lista','cantos':'arredondado'}})
    longo='x'*301; r1=R.put('/api/v2/ads/1',data={'sobre':longo}); r2=R.put('/api/v2/ads/1',data={'sobre':'Pizzas artesanais no forno a lenha.'})
    check('cadastro: descrição acima de 300 caracteres é recusada (até 300 aceita)', r1.status==400 and 'até 300' in r1.text() and r2.ok, (r1.status,r2.status))
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
