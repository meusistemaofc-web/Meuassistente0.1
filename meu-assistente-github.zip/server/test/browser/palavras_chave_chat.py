# Palavras-chave no chat (tela real): "Piercing" sozinho → pede localização → autorizar → volta e mostra os cards reais das
# empresas com a palavra-chave (sem reenviar a palavra; botão some); maiúsculas e frases encontram; pedaço de palavra não;
# empresa pendente não aparece; celular e computador.
import sys, sqlite3, datetime
DBF='/tmp/ma-teste.db'
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
PERTO={'latitude':-23.55,'longitude':-46.63}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True}).ok
    IDS={}
    for emp,cat,pal,k,pl in [('Studio Agulha','Tatuagem','piercing, tattoo',1,'n3'),('Body Art','Arte corporal','piercing, alargador',2,'n2'),('Pet Feliz','Pet shop','banho e tosa',3,'n2')]:
        r=A.post('/api/v2/ads',data={'planId':pl,'empresa':emp,'categoria':cat,'titulo':emp,'texto':'Atendimento com hora marcada','zap':'5511999990000','palavras':pal,'lat':-23.55+k*0.001,'lng':-46.63,'raio':10,'tipo':'servicos'}); assert r.ok, r.text(); IDS[emp]=[x for x in r.json()['items'] if x['empresa']==emp][0]['id']
    db=sqlite3.connect(DBF); now=datetime.datetime.now(datetime.UTC).isoformat()
    for nota in (5,4): db.execute("insert into reviews (business_id, origem, rating, created_at) values (?, 'cliente', ?, ?)",(IDS['Studio Agulha'],nota,now))
    db.commit(); db.close()
    o=b.new_context(base_url=BASE); O=o.request
    O.post('/api/auth',data={'action':'signup','name':'Dono Pendente','whatsapp':'+55 11 92222-1111','email':'pend@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'})
    O.post('/api/v2/ads',data={'planId':'n2','empresa':'Piercing Pendente','categoria':'Tatuagem','titulo':'x','texto':'x','zap':'5511911110000','palavras':'piercing','lat':-23.551,'lng':-46.63,'raio':10,'tipo':'servicos'}); o.close()
    nomes=lambda pg: pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .ma-emp-cards')].pop();return b?[...b.querySelectorAll('.ma-pc p.font-bold')].map(x=>x.textContent.trim()):[]}")
    ultima=lambda pg: pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
    def enviar(pg,t):
        pg.fill('textarea.composer-input',t); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
    for nome,vp,mob,email in [('celular',{'width':390,'height':844},True,'cel@t.com'),('computador',{'width':1280,'height':900},False,'pc@t.com')]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob,geolocation=PERTO,permissions=['geolocation']); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 96666-'+('1111' if mob else '2222'),'email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(800)
        enviar(pg,'Piercing'); n0=pg.locator('.chat-scroll .msg-swipe').count()
        check(f'{nome}: 8. palavra-chave sem localização: reconhece e pede a localização', 'empresas que trabalham com piercing' in ultima(pg) and pg.locator('.chat-scroll a',has_text='Permitir localização e ver empresas').count()==1, ultima(pg))
        pg.locator('.chat-scroll a',has_text='Permitir localização e ver empresas').click(); pg.wait_for_selector('#locok',timeout=8000); pg.click('#locok')
        try: pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); ok=True
        except Exception: ok=False
        pg.wait_for_timeout(800)
        check(f'{nome}: após autorizar, volta ao chat com os cards (sem reenviar a palavra; botão some)', ok and sorted(nomes(pg))==['Body Art','Studio Agulha'] and pg.locator('.chat-scroll a',has_text='Permitir localização e ver empresas').count()==0 and pg.locator('.chat-scroll .msg-swipe').count()==n0, nomes(pg))
        check(f'{nome}: resposta "Encontrei empresas que trabalham com piercing para você!"', 'Encontrei empresas que trabalham com piercing para você!' in pg.inner_text('.chat-scroll'))
        check(f'{nome}: 9. empresa pendente não aparece', 'Piercing Pendente' not in pg.inner_text('.chat-scroll'))
        cards=pg.locator('.chat-scroll .ma-emp-cards').last
        sa=cards.locator('.ma-pc',has_text='Studio Agulha').inner_text()
        check(f'{nome}: card original do chat (logo, nome, descrição, avaliação, distância, situação, "Saiba mais")', cards.locator('.ma-pc').count()==2 and cards.locator('.ma-pc > .flex > span, .ma-pc > .flex > img').count()==2 and cards.locator('.ma-pc a',has_text='Saiba mais').count()==2 and cards.locator('a',has_text='Ver todas as empresas').count()==1, cards.inner_text()[:200])
        check(f'{nome}: 6. avaliações reais exibidas (★ 4,5 · 2 avaliações)', '4,5' in sa and '(2 avaliações)' in sa and (' m · ' in sa or ' km · ' in sa) and ('Aberto' in sa or 'Fechado' in sa), sa)
        ba=cards.locator('.ma-pc',has_text='Body Art').inner_text(); check(f'{nome}: empresa sem avaliações não mostra nota inventada', '★' not in ba and 'avalia' not in ba, ba)
        check(f'{nome}: 7. botões do card: página da empresa (plano com página) e WhatsApp (plano sem página)', cards.locator('.ma-pc',has_text='Studio Agulha').locator('a',has_text='Saiba mais').get_attribute('href')==f"/x/empresa/{IDS['Studio Agulha']}" and cards.locator('.ma-pc',has_text='Body Art').locator('a',has_text='Saiba mais').get_attribute('href').startswith('https://wa.me/'))
        if nome=='celular': pg.screenshot(path='/tmp/e2e/palavras_chave_chat_celular.png')
        cards.locator('.ma-pc',has_text='Studio Agulha').locator('a',has_text='Saiba mais').click()
        try: pg.wait_for_function("()=>{const o=document.querySelector('#ma-x');return !!o&&o.innerText.includes('Studio Agulha')&&location.pathname.startsWith('/x/empresa/')}",timeout=15000); ok=True
        except Exception: ok=False
        check(f'{nome}: 7. "Saiba mais" abre a página da empresa', ok)
        pg.go_back(); pg.wait_for_timeout(1500)
        enviar(pg,'PIERCING'); check(f'{nome}: 3/7. maiúsculas com localização: cards direto', sorted(nomes(pg))==['Body Art','Studio Agulha'], nomes(pg))
        enviar(pg,'quero fazer um piercing na orelha'); check(f'{nome}: 2. palavra-chave dentro de uma frase', sorted(nomes(pg))==['Body Art','Studio Agulha'], nomes(pg))
        enviar(pg,'banho e tosa'); check(f'{nome}: expressão composta encontra só a empresa certa', nomes(pg)==['Pet Feliz'], nomes(pg))
        k=pg.locator('.chat-scroll .ma-emp-cards').count(); enviar(pg,'pier')
        check(f'{nome}: pedaço de palavra não vira busca de empresas', pg.locator('.chat-scroll .ma-emp-cards').count()==k and 'trabalham com' not in ultima(pg), ultima(pg))
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
