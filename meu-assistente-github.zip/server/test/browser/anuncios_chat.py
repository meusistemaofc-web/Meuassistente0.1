# Anúncios DENTRO das conversas — novo padrão visual (25/11) e cabeçalho do chat sem o ponto verde de conexão.
# App e servidor reais. Anúncio de empresa parceira (⟦ad:id⟧) real: anunciante cadastrado, frequência "a cada mensagem",
# seleção/impressão do servidor e clique contado pelo app. Avaliação: injetada na resposta de /api/v2/businesses/cards
# (o servidor de teste não tem avaliações). Campanha (componente React J8): o backend /api/ads ainda não foi reconstruído,
# então ela é SIMULADA aqui (resposta de /api/ads interceptada) — prova só o desenho e o rastreamento do componente.
# Servidor: PORT=4361 SQLITE_FILE=/tmp/ma-anuncios.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, re, sqlite3, time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4361'; DB = '/tmp/ma-anuncios.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def sql(q, a=()):
    c = sqlite3.connect(DB); r = c.execute(q, a).fetchall(); c.commit(); c.close(); return r
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    # anunciante com dois anúncios (curto com imagem; longo sem imagem); só um fica ativo por vez
    A = b.new_context(base_url=BASE).request; t0 = int(time.time())
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Dono Isqueiros', 'whatsapp': '+55 11 91111-2222', 'email': f'dono{t0}@t.com', **U}, headers={'X-Forwarded-For': '10.8.1.1'}).ok
    ids = []
    for emp, tit, logo in [('Mini Isqueiros', 'Isqueiro compacto, leve e ideal para o dia a dia.', '/icons/icon-512.png'), ('Oficina Mecânica e Auto Center Irmãos Rodrigues Especializada em Suspensão', 'Revisão completa, alinhamento, balanceamento, troca de óleo, freios, embreagem e suspensão com garantia de seis meses e atendimento no mesmo dia.', None)]:
        r = A.post('/api/v2/ads', data={'planId': 'n4', 'empresa': emp, 'categoria': 'Comércio', 'titulo': tit, 'texto': tit, 'zap': '5585999990000'}).json()
        i = r['items'][0]['id']; ids.append(i)
        d = json.loads(sql('SELECT data FROM businesses WHERE id=?', (i,))[0][0]); d['logo'] = logo
        sql("UPDATE businesses SET status='ativo', expires_at='2099-01-01T00:00:00Z', data=? WHERE id=?", (json.dumps(d), i))
    sql("UPDATE businesses SET status='pausado' WHERE id=?", (ids[1],))
    sql("DELETE FROM app_config WHERE key='ad_frequency'"); sql("INSERT INTO app_config (key, value, updated_at) VALUES ('ad_frequency', ?, ?)", (json.dumps({'ativo': True, 'cada': 1, 'intervaloMin': 0}), '2026-01-01'))
    for nome, vp, mob, k, tam in [('celular', {'width': 390, 'height': 844}, True, 3, 104), ('tablet', {'width': 820, 'height': 1180}, True, 4, 132), ('computador', {'width': 1280, 'height': 900}, False, 5, 132)]:
        print('==', nome)
        sql("UPDATE businesses SET status='ativo' WHERE id=?", (ids[0],)); sql("UPDATE businesses SET status='pausado' WHERE id=?", (ids[1],))
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Teste', 'whatsapp': f'+55 11 9{k}{k}{k}{k}-{k}{k}{k}{k}', 'email': f'cli{k}.{t0}@t.com', **U}, headers={'X-Forwarded-For': f'10.8.2.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        hits = []; pg.on('request', lambda r: hits.append(r.url) if re.search(r'/api/v2/businesses/\d+/hit', r.url) else None)
        def cards(route):  # avaliação real não existe no banco de teste: injeta 5,0 (1 avaliação) no anúncio curto
            r = route.fetch(); j = r.json()
            for it in j.get('items', []):
                if it.get('empresa') == 'Mini Isqueiros': it['avaliacao'] = {'avg': 5, 'count': 1}
            route.fulfill(response=r, json=j)
        pg.route('**/api/v2/businesses/cards*', cards)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(900)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        # cabeçalho: sem ponto verde (online), demais elementos preservados e alinhados
        hd = pg.evaluate("""()=>{const h=document.querySelector('.nx-chat-header-bar');const r=e=>e&&e.getBoundingClientRect();const menu=h.querySelector('[aria-label="Abrir menu"]'),op=h.querySelector('[aria-label="Opções"]'),no=h.querySelector('a[href="/notificacoes"]');
          const verdes=[...h.querySelectorAll('*')].filter(e=>{const c=getComputedStyle(e).backgroundColor;return c==='rgb(47, 210, 122)'});
          return {conexao:h.querySelectorAll('[aria-label^="Conexão"]').length,verdes:verdes.length,menu:!!menu,op:!!op,no:!!no,alinhado:[menu,op,no].filter(e=>e&&r(e).height>0).every(e=>Math.abs((r(e).top+r(e).height/2)-(r(menu).top+r(menu).height/2))<=2),larg:h.scrollWidth<=h.clientWidth+1}}""")
        check(f'{nome}: cabeçalho sem o ponto verde de conexão', hd['conexao'] == 0 and hd['verdes'] == 0, hd)
        check(f'{nome}: menu, notificações e opções preservados e alinhados', hd['menu'] and hd['op'] and hd['no'] and hd['alinhado'] and hd['larg'], hd)
        pg.locator('[aria-label="Opções"]').first.click(); pg.wait_for_timeout(300)
        check(f'{nome}: menu de opções abre', pg.locator('[aria-label="Opções"][aria-expanded="true"]').count() == 1)
        pg.keyboard.press('Escape'); pg.locator('[aria-label="Opções"]').first.click() if pg.locator('[aria-label="Opções"][aria-expanded="true"]').count() else None; pg.wait_for_timeout(200)
        C.set_offline(True); pg.evaluate("dispatchEvent(new Event('offline'))"); pg.wait_for_timeout(600)
        off = pg.evaluate("(()=>{const e=document.querySelector('.nx-chat-header-bar [aria-label^=\"Conexão\"]');return e?e.innerText:null})()")
        check(f'{nome}: sem internet, o aviso de conexão continua aparecendo (status preservado)', off and 'Offline' in off, off)
        C.set_offline(False); pg.evaluate("dispatchEvent(new Event('online'))"); pg.wait_for_timeout(1200)
        check(f'{nome}: de volta online, o indicador some de novo', pg.locator('.nx-chat-header-bar [aria-label^="Conexão"]').count() == 0)
        ta = pg.locator('textarea[data-composer-input]')
        def enviar(t):
            n = pg.locator('.chat-scroll .ma-ad').count(); ta.click(); ta.fill(t); ta.press('Enter')
            pg.wait_for_function(f"document.querySelectorAll('.chat-scroll .ma-ad').length>{n}", timeout=20000); pg.wait_for_timeout(900)
            return pg.locator('.chat-scroll .ma-ad').last
        ad = enviar('bom dia')
        g = ad.evaluate("""a=>{const R=e=>e.getBoundingClientRect(),cs=getComputedStyle(a),i=a.querySelector('.ma-ad-i'),t=a.querySelector('.ma-ad-t'),f=a.querySelector('.ma-ad-f'),n=a.querySelector('.ma-ad-n'),bd=a.querySelector('.ma-ad-b'),l=a.querySelector('.ma-ad-a'),ls=getComputedStyle(l),m=a.querySelector('.ma-ad-m');
          const lc=cs.borderTopColor.match(/[\\d.]+/g).map(Number);
          return {linha:cs.borderTopWidth,linhaAlfa:lc.length>3?lc[3]:1,espaco:Math.round(R(i).top-R(a).top),intro:i.innerText,introEstilo:getComputedStyle(i).fontStyle,titulo:n.innerText,tituloPx:getComputedStyle(n).fontSize,descPx:getComputedStyle(a.querySelector('.ma-ad-d')).fontSize,
           etiqueta:bd.innerText,etiquetaCanto:Math.abs(R(bd).right-R(a).right)<=2&&R(bd).bottom<=R(n).top+1&&(!f||R(bd).bottom<=R(f).top+1)&&Math.abs(R(bd).top-R(i).top)<=6,etiquetaIntro:R(i).right<=R(bd).left+1||R(i).width<=R(a).width,meta:m?m.innerText:'',
           imgDireita:f?R(f).left>=R(t).right:false,imgW:f?Math.round(R(f).width):0,imgH:f?Math.round(R(f).height):0,imgRaio:f?getComputedStyle(f).borderTopLeftRadius:'',imgOk:f?f.querySelector('img').naturalWidth>0:false,
           link:l.innerText,linkFundo:ls.backgroundColor,linkBorda:ls.borderBottomStyle,linkBotao:ls.borderTopWidth,href:l.getAttribute('href'),hit:l.dataset.hit,bid:l.dataset.bid,
           dentroDaBolha:!!a.closest('.msg-bubble'),largura:Math.round(R(a).width),scroll:document.documentElement.scrollWidth-innerWidth}}""")
        ad.screenshot(path=f'/tmp/e2e/anuncio_{nome}_escuro.png'); pg.evaluate("document.documentElement.dataset.theme='light'"); pg.wait_for_timeout(300)
        gl = ad.evaluate("a=>{const R=e=>e.getBoundingClientRect(),b=a.querySelector('.ma-ad-b');return {canto:Math.abs(R(b).right-R(a).right)<=2,cor:getComputedStyle(b).color}}"); ad.screenshot(path=f'/tmp/e2e/anuncio_{nome}_claro.png')
        pg.evaluate("document.documentElement.dataset.theme='dark'"); pg.wait_for_timeout(200)
        check(f'{nome}: tema claro — etiqueta no mesmo lugar e legível', gl['canto'] and gl['cor'] not in ('rgb(201, 206, 214)',), gl)
        check(f'{nome}: linha divisória fina, cinza e discreta (perceptível)', g['linha'] == '1px' and 0.2 <= g['linhaAlfa'] <= 0.6, g)
        check(f'{nome}: "Isso pode interessar a você." levemente inclinado, com espaço da linha', g['intro'] == 'Isso pode interessar a você.' and 'oblique' in g['introEstilo'] or 'italic' in g['introEstilo'], g)
        check(f'{nome}: nome em destaque ({g["tituloPx"]}) e descrição confortável ({g["descPx"]})', g['titulo'] == 'Mini Isqueiros' and float(g['tituloPx'][:-2]) >= 16 and float(g['descPx'][:-2]) >= 14, g)
        check(f'{nome}: etiqueta "Anúncio" discreta no canto superior direito do bloco (acima da imagem, fora da linha do nome)', g['etiqueta'] == 'Anúncio' and g['etiquetaCanto'], g)
        check(f'{nome}: avaliação preservada ("5,0 (1 avaliação)")', '5,0' in g['meta'] and '(1 avaliação)' in g['meta'], g['meta'])
        check(f'{nome}: anúncio no chat SEM o indicador Aberto/Fechado (28/11)', 'Aberto' not in ad.inner_text() and 'Fechado' not in ad.inner_text() and ad.locator('.ab,.fe').count() == 0, ad.inner_text())
        check(f'{nome}: imagem à direita, {g["imgW"]}×{g["imgH"]} px, quadrada e arredondada', g['imgDireita'] and g['imgOk'] and abs(g['imgW'] - tam) <= 2 and g['imgW'] == g['imgH'] and g['imgRaio'] not in ('0px', ''), g)
        check(f'{nome}: "Saiba mais" só em texto (sem fundo, sem botão)', g['link'].startswith('Saiba mais') and g['linkFundo'] in ('rgba(0, 0, 0, 0)', 'transparent') and g['linkBorda'] == 'dotted' and g['linkBotao'] == '0px', g)
        check(f'{nome}: link e rastreamento preservados (data-hit/data-bid)', g['href'] == f'/x/empresa/{ids[0]}' and g['hit'] == 'visita' and g['bid'] == str(ids[0]), g)
        check(f'{nome}: fora da bolha do assistente e sem rolagem lateral', not g['dentroDaBolha'] and g['scroll'] <= 1, g)
        # resposta normal do assistente continua com o desenho de sempre
        bol = pg.evaluate("(()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble:not(.bubble-user)')].pop();return {tem:!!b,ad:!!b.querySelector('.ma-ad'),txt:b.innerText.slice(0,60)}})()")
        check(f'{nome}: mensagem normal do assistente intacta', bol['tem'] and not bol['ad'] and bol['txt'], bol)
        n0 = len(hits); pg.locator('.chat-scroll .ma-ad-a').last.click(); pg.wait_for_timeout(1200)
        check(f'{nome}: clique em "Saiba mais" é contado e abre a página do anunciante', len(hits) > n0 and f'/x/empresa/{ids[0]}' in pg.url, (hits[n0:], pg.url))
        pg.go_back(); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800); ta = pg.locator('textarea[data-composer-input]')
        # anúncio com textos longos e SEM imagem
        sql("UPDATE businesses SET status='pausado' WHERE id=?", (ids[0],)); sql("UPDATE businesses SET status='ativo' WHERE id=?", (ids[1],))
        ad2 = enviar('obrigado')
        g2 = ad2.evaluate("""a=>{const R=e=>e.getBoundingClientRect(),n=a.querySelector('.ma-ad-n'),bd=a.querySelector('.ma-ad-b'),d=a.querySelector('.ma-ad-d'),lh=parseFloat(getComputedStyle(n).lineHeight);
          return {img:!!a.querySelector('.ma-ad-f'),linhasTit:Math.round(R(n).height/lh),linhasDesc:Math.round(R(d).height/parseFloat(getComputedStyle(d).lineHeight)),sobrepoe:(()=>{const x=R(n),y=R(bd);return x.left<y.right-1&&y.left<x.right-1&&x.top<y.bottom-1&&y.top<x.bottom-1})(),cabe:R(a).right<=innerWidth,larg:Math.round(R(a.querySelector('.ma-ad-t')).width),total:Math.round(R(a).width),scroll:document.documentElement.scrollWidth-innerWidth}}""")
        check(f'{nome}: texto longo limitado (título ≤2, descrição ≤3 linhas), sem sobrepor a etiqueta', g2['linhasTit'] <= 2 and g2['linhasDesc'] <= 3 and not g2['sobrepoe'] and g2['cabe'] and g2['scroll'] <= 1, g2)
        check(f'{nome}: sem imagem, o texto usa toda a largura', not g2['img'] and g2['larg'] >= g2['total'] - 2, g2)
        pg.screenshot(path=f'/tmp/anuncio_{nome}.png', full_page=False)
        C.close()
    # o status continua onde ele ajuda a escolher: a página Descobrir (Empresas perto de você)
    sql("UPDATE businesses SET status='ativo' WHERE id=?", (ids[0],))
    A.put(f'/api/v2/ads/{ids[0]}', data={'lat': -23.552, 'lng': -46.632, 'raio': 30, 'horarioCfg': {'modo': 'aberto', 'dias': {}}})
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Descobre', 'whatsapp': '+55 11 97777-4321', 'email': f'desc.{t0}@t.com', **U}, headers={'X-Forwarded-For': '10.8.3.9'}).ok
    C.request.put('/api/v2/me/location', data={'lat': -23.552, 'lng': -46.632, 'raio': 30})
    pg = C.new_page(); pg.goto('/x/empresas'); pg.wait_for_timeout(3500)
    pills = pg.locator('.ma-fpill').all_inner_texts()
    check('Descobrir: o status Aberto/Fechado continua nos cards das empresas', any(x.strip() in ('Aberto', 'Fechado') for x in pills), pills)
    C.close()
    # campanha (componente React J8) — SIMULADA: /api/ads ainda não tem backend reconstruído
    print('== campanha (simulada)')
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Camp', 'whatsapp': '+55 11 97777-1234', 'email': f'camp.{t0}@t.com', **U}, headers={'X-Forwarded-For': '10.8.3.1'}).ok
    sql("UPDATE app_config SET value=? WHERE key='ad_frequency'", (json.dumps({'ativo': False}),))
    pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); vistos = []
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
    ta = pg.locator('textarea[data-composer-input]'); ta.fill('oi'); ta.press('Enter'); pg.wait_for_timeout(2500)
    mid = sql("SELECT id, conversation_id FROM messages WHERE role='assistant' ORDER BY id DESC LIMIT 1")[0]
    def ads(route):
        if route.request.method == 'POST': vistos.append(route.request.post_data); return route.fulfill(json={'ok': True})
        route.fulfill(json={'ads': [{'token': 'tk1', 'afterMessageId': mid[0], 'company': 'Loja Exemplo', 'title': 'Fones sem fio', 'body': 'Som limpo e bateria para o dia todo.', 'ctaLabel': 'Saiba mais', 'imageUrl': '/icons/icon-512.png', 'host': 'lojaexemplo.com'}]})
    pg.route('**/api/ads*', ads)
    pg.goto('/?c=' + mid[1]); pg.wait_for_timeout(3000)
    cp = pg.evaluate("""()=>{const a=document.querySelector('aside.nx-sponsored');if(!a)return null;const R=e=>e.getBoundingClientRect(),t=a.querySelector('.ma-ad-t'),f=a.querySelector('.ma-ad-f'),l=a.querySelector('.ma-ad-a');
      return {classe:a.className,intro:(a.querySelector('.ma-ad-i')||{}).innerText,tit:(a.querySelector('.ma-ad-n')||{}).innerText,et:(a.querySelector('.ma-ad-b')||{}).innerText,dir:f&&t?R(f).left>=R(t).right:false,href:l&&l.getAttribute('href'),fundo:l&&getComputedStyle(l).backgroundColor,ocultar:!!a.querySelector('[aria-label="Ocultar este anúncio"]')}}""")
    check('campanha (simulada): mesmo padrão visual no componente React', cp and 'ma-ad' in cp['classe'] and cp['intro'] == 'Isso pode interessar a você.' and cp['tit'] == 'Fones sem fio' and cp['et'] == 'Anúncio' and cp['dir'] and cp['fundo'] in ('rgba(0, 0, 0, 0)', 'transparent'), cp)
    check('campanha (simulada): link rastreado e "ocultar" preservados', cp and cp['href'] == '/api/ads/go?t=tk1' and cp['ocultar'], cp)
    pg.wait_for_timeout(1500)
    check('campanha (simulada): impressão registrada pelo componente (view)', any('"view"' in (v or '') for v in vistos), vistos)
    C.close()
    check('sem erros de JavaScript na página (fora o aviso #418 de hidratação, já conhecido)', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'{sum(res)}/{len(res)} verificações')
