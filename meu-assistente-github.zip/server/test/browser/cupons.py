import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
norm=lambda s:s.replace('\xa0',' ')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'pix':True,'dinheiro':True,'online':False},'entrega':{'retirada':True}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':[IMG]}).ok
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    assert cc.request.post('/api/auth',data={'action':'signup','name':'Cliente Cupom','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    errs=[]
    # ---- empresa: aba Cupons em Ajustes
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    check('Ajustes da empresa tem a opção "Cupons de desconto"', pg.locator('button:has-text("Cupons de desconto")').count()>=1)
    pg.locator('button:has-text("Cupons de desconto")').first.click(); pg.wait_for_selector('#cp_new',timeout=8000)
    check('painel de resultados começa zerado', 'Criados' in pg.inner_text('body') and 'Conversão' in pg.inner_text('body') and 'ainda não criou cupons' in pg.inner_text('body'))
    pg.click('#cp_new'); pg.wait_for_selector('#cf_nome',timeout=5000)
    pg.fill('#cf_nome','Volta pra cá'); pg.fill('#cf_codigo','volta10'); pg.fill('#cf_valor','10'); pg.fill('#cf_finalidade','Recuperar inativos'); pg.fill('#cf_limitePorCliente','1')
    pg.click('#cf_go'); pg.wait_for_timeout(1200)
    body=norm(pg.inner_text('body'))
    check('cupom criado aparece na lista, ativo, com código em maiúsculas', 'Volta pra cá' in body and 'VOLTA10' in body and 'Ativo' in body and '10%' in body, body[:500])
    pg.screenshot(path='/tmp/e2e/cupons_empresa.png',full_page=True)
    # validação de formulário na tela
    pg.click('#cp_new'); pg.wait_for_selector('#cf_nome'); pg.fill('#cf_nome','Outro'); pg.fill('#cf_codigo','VOLTA10'); pg.fill('#cf_valor','5'); pg.click('#cf_go'); pg.wait_for_timeout(800)
    check('código repetido é recusado com mensagem', 'já tem um cupom com esse código' in pg.inner_text('#cf_err'), pg.inner_text('#cf_err'))
    pg.keyboard.press('Escape'); pg.click('.ma-sheet-x'); pg.wait_for_timeout(300)
    # pausar e reativar
    pg.locator('[data-cp] [data-a=st]').first.click(); pg.wait_for_timeout(1000)
    check('pausar mostra situação Pausado', 'Pausado' in pg.inner_text('body'))
    pg.locator('[data-cp] [data-a=st]').first.click(); pg.wait_for_timeout(1000)
    check('reativar volta a Ativo', 'Ativo' in pg.inner_text('[data-cp]'))
    # distribuir pelo CRM/área
    pg.locator('[data-cp] [data-a=dist]').first.click(); pg.wait_for_selector('#cd_go',timeout=5000)
    check('distribuição oferece segmentos do CRM e canais', all(x in pg.inner_text('.ma-sheet-in') for x in ['Todos os clientes','Clientes inativos','Potenciais','Notificação push','área de cupons']))
    pg.select_option('#cd_canal','area'); pg.click('#cd_pv'); pg.wait_for_timeout(700)
    check('"Ver alcance" informa quantos clientes', 'cliente(s) neste público' in pg.inner_text('#cd_info'), pg.inner_text('#cd_info'))
    pg.keyboard.press('Escape'); pg.click('.ma-sheet-x'); pg.wait_for_timeout(300)
    # ---- cliente: vitrine, checkout com cupom
    cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append(str(e)))
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000)
    check('vitrine da loja mostra o cupom público', cp.locator('[data-vcp=VOLTA10]').count()==1 and 'cupons desta loja' in cp.inner_text('#ma-x').lower())
    cp.click('[data-add]'); cp.wait_for_timeout(400); cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('#cpcode',timeout=8000)
    check('checkout tem o campo de cupom e a lista de cupons da loja', cp.locator('#cpapply').count()==1 and cp.locator('[data-cpick=VOLTA10]').count()==1)
    cp.fill('#cpcode','naoexiste'); cp.click('#cpapply'); cp.wait_for_timeout(800)
    check('cupom inválido mostra o motivo', 'inválido' in cp.inner_text('#cperr').lower(), cp.inner_text('#cperr'))
    cp.click('[data-cpick=VOLTA10]'); cp.wait_for_timeout(900)
    s=norm(cp.inner_text('.ma-sheet-in'))
    check('cupom aplicado: desconto de 10% (R$ 5,00) e total R$ 45,00', 'VOLTA10' in s and '− R$ 5,00' in s and 'R$ 45,00' in s, s[-500:])
    cp.screenshot(path='/tmp/e2e/cupons_checkout.png')
    cp.click('#cprm'); cp.wait_for_timeout(500)
    check('remover cupom volta o total cheio', 'R$ 50,00' in norm(cp.inner_text('.ma-sheet-in')) and cp.locator('#cpcode').count()==1)
    cp.fill('#cpcode','volta10'); cp.click('#cpapply'); cp.wait_for_timeout(900)
    cp.fill('#czap','(11) 95555-1212'); cp.click('[data-pg=dinheiro]'); cp.click('#cgo'); cp.wait_for_timeout(1800)
    od=cc.request.get('/api/v2/orders/mine').json()['items'][0]
    check('pedido enviado com o total já com cupom', abs(od['total']-45)<0.01, od['total'])
    # reuso bloqueado
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-add]',timeout=15000); cp.click('[data-add]'); cp.wait_for_timeout(400); cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('#cpcode',timeout=8000)
    cp.fill('#cpcode','VOLTA10'); cp.click('#cpapply'); cp.wait_for_timeout(900)
    check('o mesmo cliente não consegue usar o cupom de novo', 'já usou' in cp.inner_text('#cperr').lower(), cp.inner_text('#cperr'))
    # área do cliente
    cp.goto('/x/cupons'); cp.wait_for_selector('[data-cc]',timeout=10000)
    t=norm(cp.inner_text('#ma-x'))
    check('área de cupons: cupom, empresa, regras e histórico de uso', 'VOLTA10' in t and 'Pizzaria Forno' in t and 'Você já usou' in t and 'cupons que você já usou' in t.lower() and '− R$ 5,00' in t, t[:500])
    check('cliente não vê números internos da empresa', 'Conversão' not in t and 'Clientes alcançados' not in t)
    cp.screenshot(path='/tmp/e2e/cupons_cliente.png',full_page=True)
    # ---- resultados na empresa e no admin
    pg.reload(); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(500); pg.locator('button:has-text("Cupons de desconto")').first.click(); pg.wait_for_selector('#cp_new',timeout=8000)
    pg.locator('[data-cp] [data-a=det]').first.click(); pg.wait_for_selector('text=Histórico de alterações',timeout=6000)
    d=norm(pg.inner_text('.ma-sheet-in'))
    check('resultados do cupom: 1 uso, 1 venda, desconto R$ 5,00 e histórico com resgate', 'Vendas com cupom' in d and 'R$ 5,00' in d and 'resgate' in d and 'criado' in d, d[:600])
    pg.screenshot(path='/tmp/e2e/cupons_resultados.png',full_page=True)
    pg.keyboard.press('Escape'); pg.click('.ma-sheet-x'); pg.wait_for_timeout(300)
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Cupons de desconto').click(); pg.wait_for_selector('#cnew',timeout=10000)
    a=norm(pg.inner_text('body'))
    check('admin vê o cupom da empresa, o resumo geral e o filtro por empresa', 'Pizzaria Forno' in a and 'VOLTA10' in a and 'Todas as empresas' in a and 'Desconto concedido' in a, a[:400])
    pg.locator('[data-cp] [data-a=st]').first.click(); pg.wait_for_timeout(1000)
    check('admin pausa cupom de qualquer empresa', 'Pausado' in pg.inner_text('body'))
    pg.locator('[data-cp] [data-a=det]').first.click(); pg.wait_for_selector('text=Histórico de alterações',timeout=6000)
    check('histórico do admin registra a pausa e o resgate', 'pausado' in pg.inner_text('body') and 'resgate' in pg.inner_text('body'))
    pg.screenshot(path='/tmp/e2e/cupons_admin.png',full_page=True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print(f'{sum(res)}/{len(res)} verificações'); sys.exit(0 if all(res) else 1)
