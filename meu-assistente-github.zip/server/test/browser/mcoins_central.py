import sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def user(b,nome,email):
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True,reduced_motion='reduce')
    assert c.request.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':'+55 11 96666-5555','email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    return c
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    ID=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}).json()['items'][0]['id']
    assert R.post('/api/panel/coins',data={'action':'config','ativo':True}).ok
    c=R.post('/api/panel/coins',data={'action':'create','businessId':ID,'modelo':'dourada','nome':'Moeda Forno','simbolo':'forno','quantidade':500,'valorReferencia':1,'desconto':1,'finalidade':'x'}).json(); CID=c['moeda']['id']; COD=c['moeda']['codigo']
    assert R.post('/api/panel/coins',data={'action':'status','id':CID,'status':'ativa'}).ok
    ana=user(b,'Ana Central','ana@t.com'); bruno=user(b,'Bruno Central','bruno@t.com')
    db=sqlite3.connect(DBF); uid=lambda e:db.execute('select id from users where email=?',(e,)).fetchone()[0]
    saldo=lambda e:(db.execute('select balance from coin_balances where coin_id=? and user_id=?',(CID,uid(e))).fetchone() or [0])[0]
    assert R.post('/api/panel/coins',data={'action':'distribuir','id':CID,'email':'ana@t.com','quantidade':50,'idem':'bro-seed-0001'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Central MCoins',exact=True).click(); pg.wait_for_selector('#cc_save',timeout=10000)
    t=pg.inner_text('#ma-panel-host') if pg.locator('#ma-panel-host').count() else pg.inner_text('body')
    check('aba "Central MCoins" com chaves globais desligadas por padrão', not pg.locator('#cc_compra').is_checked() and not pg.locator('#cc_venda').is_checked() and not pg.locator('#cc_transf').is_checked() and not pg.locator('#cc_comp').is_checked())
    check('código único da moeda aparece na central', COD in pg.inner_text('body') and COD.startswith('MC-'), COD)
    check('aviso de que compra/venda não presumem dinheiro real', 'dinheiro real' in pg.inner_text('body'))
    # carteira com tudo desligado: sem botões
    pa=ana.new_page(); ea=[]; pa.on('pageerror',lambda e:ea.append(str(e)))
    pa.goto('/x/carteira'); pa.wait_for_selector('[data-mc-saldo]',timeout=15000); pa.wait_for_timeout(1500)
    check('carteira e saldo visíveis e sem botões de compra/venda/transferência com a central desligada', pa.inner_text('[data-mc-saldo]').strip()=='50' and pa.locator('[data-mc]').count()==0)
    # admin liga compra e venda
    pg.check('#cc_compra'); pg.check('#cc_venda'); pg.select_option('#cc_liq','manual')
    pg.fill('[data-l="compra.preco"]','2'); pg.fill('[data-l="compra.max"]','100'); pg.fill('[data-l="venda.preco"]','1'); pg.fill('[data-l="venda.max"]','100')
    pg.click('#cc_save'); pg.wait_for_timeout(1500); pg.wait_for_selector('#cc_save',timeout=8000)
    check('configuração salva e persistida', pg.locator('#cc_compra').is_checked() and db.execute("select count(*) from audit_log where action='coins.central.config'").fetchone()[0]>=1)
    pa.reload(); pa.wait_for_selector('[data-mc-saldo]',timeout=15000); pa.wait_for_timeout(1500)
    check('carteira passa a mostrar Comprar e Vender (e não Transferir)', pa.locator('[data-mc^="comprar:"]').count()==1 and pa.locator('[data-mc^="vender:"]').count()==1 and pa.locator('[data-mc^="transferir:"]').count()==0, pa.locator('[data-mc]').count())
    # comprar: resumo e confirmação
    pa.locator('[data-mc^="comprar:"]').click(); pa.wait_for_selector('#mc_q'); pa.fill('#mc_q','10'); pa.click('#mc_prev'); pa.wait_for_selector('#mc_ok:visible',timeout=8000)
    r=pa.inner_text('#mc_r'); check('resumo da compra mostra preço, total e aviso de liquidação manual', '20,00' in r and 'manual' in r.lower() and 'Nenhum pagamento' in r, r)
    check('prévia não cria pedido nem altera o saldo', db.execute('select count(*) from coin_orders').fetchone()[0]==0 and saldo('ana@t.com')==50)
    pa.click('#mc_ok'); pa.wait_for_timeout(1800)
    check('pedido criado como pendente, sem creditar', db.execute("select status from coin_orders").fetchone()[0]=='pendente' and saldo('ana@t.com')==50)
    check('carteira lista o pedido pendente', 'Meus pedidos' in pa.inner_text('#ma-x') and 'Pendente' in pa.inner_text('#ma-x'), pa.inner_text('#ma-x')[-300:])
    # admin confirma
    pg.get_by_role('button',name='Central MCoins',exact=True).click(); pg.wait_for_selector('[data-po]',timeout=10000)
    pg.once('dialog',lambda d:d.accept()); pg.locator('[data-po$=":confirmar"]').first.click(); pg.wait_for_timeout(1800)
    check('admin confirma e o saldo é creditado atomicamente (60)', saldo('ana@t.com')==60, saldo('ana@t.com'))
    pa.reload(); pa.wait_for_selector('[data-mc-saldo]',timeout=15000); pa.wait_for_timeout(2000); check('histórico do usuário mostra "Compra de MCoins"', 'Compra de MCoins' in pa.inner_text('#ma-x'), pa.inner_text('#ma-x')[:400])
    # permissões: modo selecionados bloqueia Bruno e libera Ana individualmente
    r2=R.post('/api/panel/coins/central',data={'action':'config','acesso':{'modo':'selecionados'}}); check('modo "somente selecionados" salvo', r2.ok)
    pb=bruno.new_page(); pb.goto('/x/carteira'); pb.wait_for_timeout(2500)
    check('Bruno sem permissão não recebe botões e o servidor recusa', pb.locator('[data-mc]').count()==0 and bruno.request.post('/api/v2/coins/comprar',data={'moedaId':CID,'quantidade':1,'confirmar':True,'idem':'bro-blk-00001'}).status==403)
    pg.get_by_role('button',name='Central MCoins',exact=True).click(); pg.wait_for_selector('#cc_pq',timeout=10000); pg.fill('#cc_pq','Ana Central'); pg.press('#cc_pq','Enter'); pg.wait_for_selector('[data-pu]',timeout=8000)
    pg.select_option(f'[data-pu="{uid("ana@t.com")}:comprar"]','1'); pg.wait_for_timeout(1500)
    check('permissão individual gravada pela interface', db.execute("select comprar from coin_permissions where scope_type='usuario' and scope_id=?",(uid('ana@t.com'),)).fetchone()[0] in (1,True))
    check('Ana (liberada) compra; Bruno continua bloqueado', ana.request.post('/api/v2/coins/comprar',data={'moedaId':CID,'quantidade':1,'confirmar':True,'idem':'bro-ana-00001'}).ok and bruno.request.post('/api/v2/coins/comprar',data={'moedaId':CID,'quantidade':1,'confirmar':True,'idem':'bro-blk-00002'}).status==403)
    # busca por código
    pg.get_by_role('button',name='Central MCoins',exact=True).click(); pg.wait_for_selector('#cc_cod',timeout=10000); pg.fill('#cc_cod',COD); pg.click('#cc_codb'); pg.wait_for_selector('#cc_codr b',timeout=8000)
    check('busca por código encontra a moeda e o emissor', COD in pg.inner_text('#cc_codr') and 'Pizzaria Forno' in pg.inner_text('#cc_codr'), pg.inner_text('#cc_codr'))
    pg.screenshot(path='/tmp/e2e/central_mcoins.png',full_page=True); pa.screenshot(path='/tmp/e2e/central_carteira.png')
    check('sem erros de JavaScript', not [e for e in errs+ea if 'React error #418' not in e and e!='Event'], (errs,ea))
    b.close()
print('FIM OK %d/%d'%(sum(res),len(res)) if all(res) else 'FIM FALHOU')
