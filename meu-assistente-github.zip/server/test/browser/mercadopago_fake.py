# Dublê do OAuth do Mercado Pago para os testes automáticos (o contêiner de testes não alcança mercadopago.com).
# Segue o contrato oficial (developers/pt/docs/security/oauth/creation):
#   GET  /authorization?client_id&response_type=code&platform_id=mp&state&redirect_uri[&code_challenge&code_challenge_method]
#   POST /oauth/token  grant_type=authorization_code|refresh_token|client_credentials (JSON ou formulário)
#   GET  /users/me     (Authorization: Bearer <access_token>)
# Regras conferidas como o Mercado Pago real: redirect_uri idêntico ao cadastrado, código de uso único (10 min),
# PKCE obrigatório quando ligado na aplicação, client_secret correto, refresh_token de uso único.
# Uso: python3 mercadopago_fake.py PORTA REDIRECT_URI [pkce]
import sys, json, time, secrets, hashlib, base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, urlencode
PORT = int(sys.argv[1]); REDIRECT = sys.argv[2]; PKCE = len(sys.argv) > 3 and sys.argv[3] == 'pkce'
APP = {'client_id': '1234567890123456', 'client_secret': 'segredo-da-aplicacao-de-teste'}
# a "pessoa" que autoriza é escolhida pelo teste com ?conta= na URL de autorização (simula quem fez login no Mercado Pago)
CONTAS = {'loja1': {'id': 1001, 'nickname': 'LOJADALU', 'email': 'lu.vendas@exemplo.com', 'first_name': 'Lu', 'last_name': 'Vendas', 'site_id': 'MLB'},
          'loja2': {'id': 2002, 'nickname': 'BETOLANCHES', 'email': 'beto@exemplo.com', 'first_name': 'Beto', 'last_name': 'Silva', 'site_id': 'MLB'}}
codes = {}; access = {}; refresh = {}; log = []
EXPIRES = {'v': 15552000}
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, obj, headers=None):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b)))
        for k, v in (headers or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == '/__log': return self.send(200, log)
        if u.path == '/__expira':  # o teste ajusta a validade dos próximos tokens
            EXPIRES['v'] = int(q.get('s', '15552000')); return self.send(200, {'ok': True})
        if u.path == '/__revogar':  # simula token revogado pelo dono no Mercado Pago
            for t in list(access): access.pop(t)
            for t in list(refresh): refresh.pop(t)
            return self.send(200, {'ok': True})
        if u.path == '/authorization':
            log.append({'tipo': 'authorization', **q})
            if q.get('client_id') != APP['client_id']: return self.send(400, {'error': 'invalid_client'})
            if q.get('response_type') != 'code': return self.send(400, {'error': 'unsupported_response_type'})
            if q.get('redirect_uri') != REDIRECT: return self.send(400, {'error': 'invalid_redirect_uri', 'message': 'redirect_uri does not match'})
            if PKCE and not (q.get('code_challenge') and q.get('code_challenge_method') == 'S256'): return self.send(400, {'error': 'invalid_request', 'message': 'code_challenge is required'})
            dest = q['redirect_uri']
            if q.get('negar') == '1':
                loc = dest + '?' + urlencode({'error': 'access_denied', 'error_description': 'The user denied', 'state': q.get('state', '')})
            else:
                code = 'TG-' + secrets.token_hex(12)
                codes[code] = {'conta': q.get('conta', 'loja1'), 'at': time.time(), 'redirect_uri': dest, 'challenge': q.get('code_challenge')}
                loc = dest + '?' + urlencode({'code': code, 'state': q.get('state', '')})
            self.send_response(302); self.send_header('Location', loc); self.end_headers(); return
        if u.path == '/users/me':
            tok = (self.headers.get('Authorization') or '').replace('Bearer ', '')
            if tok not in access: return self.send(401, {'message': 'invalid access token', 'status': 401})
            return self.send(200, CONTAS[access[tok]['conta']])
        return self.send(404, {'message': 'not found'})
    def do_POST(self):
        u = urlparse(self.path); n = int(self.headers.get('Content-Length') or 0); raw = self.rfile.read(n).decode()
        try: b = json.loads(raw) if 'json' in (self.headers.get('Content-Type') or '') else {k: v[0] for k, v in parse_qs(raw).items()}
        except Exception: b = {}
        if u.path != '/oauth/token': return self.send(404, {'message': 'not found'})
        log.append({'tipo': 'token', **{k: (v if k not in ('client_secret',) else '***') for k, v in b.items()}})
        if b.get('client_id') != APP['client_id'] or b.get('client_secret') != APP['client_secret']: return self.send(401, {'error': 'invalid_client', 'message': 'invalid client_id or client_secret'})
        g = b.get('grant_type'); teste = str(b.get('test_token')).lower() == 'true'
        def emitir(conta):
            pre = 'TEST-' if teste else 'APP_USR-'
            at = pre + secrets.token_hex(16) + '-' + str(CONTAS[conta]['id']); rt = 'TG-' + secrets.token_hex(16)
            access[at] = {'conta': conta}; refresh[rt] = {'conta': conta, 'teste': teste}
            return {'access_token': at, 'token_type': 'Bearer', 'expires_in': EXPIRES['v'], 'scope': 'offline_access payments read write', 'user_id': CONTAS[conta]['id'], 'refresh_token': rt, 'public_key': pre + secrets.token_hex(8), 'live_mode': not teste}
        if g == 'client_credentials':
            at = 'APP_USR-' + secrets.token_hex(16); return self.send(200, {'access_token': at, 'token_type': 'Bearer', 'expires_in': 21600, 'scope': 'payments', 'live_mode': True})
        if g == 'authorization_code':
            c = codes.pop(b.get('code', ''), None)
            if not c or time.time() - c['at'] > 600: return self.send(400, {'error': 'invalid_grant', 'message': 'invalid_grant: code expired or used'})
            if b.get('redirect_uri') != c['redirect_uri']: return self.send(400, {'error': 'invalid_grant', 'message': 'redirect_uri mismatch'})
            if c['challenge']:
                v = b.get('code_verifier') or ''
                ch = base64.urlsafe_b64encode(hashlib.sha256(v.encode()).digest()).decode().rstrip('=')
                if ch != c['challenge']: return self.send(400, {'error': 'invalid_grant', 'message': 'invalid code_verifier'})
            return self.send(200, emitir(c['conta']))
        if g == 'refresh_token':
            r = refresh.pop(b.get('refresh_token', ''), None)
            if not r: return self.send(400, {'error': 'invalid_grant', 'message': 'invalid refresh_token'})
            return self.send(200, emitir(r['conta']))
        return self.send(400, {'error': 'unsupported_grant_type'})
ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
