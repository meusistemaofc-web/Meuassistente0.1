# Cérebro Central (/admin/cerebro-central) no celular e no computador: painel, biblioteca (criar, abrir, editar, aprovar,
# buscar), provedores (configurar e testar), pesquisa + estudo com progresso, laboratório (comparar), fontes,
# configurações e token; acesso negado a usuário comum; persistência depois de reiniciar o servidor.
# A internet real não é acessível aqui: um servidor local faz o papel do SearXNG e de dois sites.
# Servidor: CEREBRO_PERMITIR_REDE_LOCAL=1 PORT=4315 SQLITE_FILE=/tmp/ma-cc.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, json, threading, subprocess, time, os, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4315'; WEB = 4399; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
P1 = '<p>A energia solar fotovoltaica transforma a luz do sol em energia elétrica por meio de painéis com células de silício.</p><p>Os painéis de energia solar produzem corrente contínua, que o inversor converte em corrente alternada para a casa.</p>'
P2 = '<p>Os painéis de energia solar produzem corrente contínua, que o inversor converte em corrente alternada para a casa.</p><p>A manutenção de um sistema de energia solar residencial é simples: limpeza periódica dos painéis e revisão anual do inversor.</p>'
class Web(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ct):
        b = body.encode(); self.send_response(code); self.send_header('Content-Type', ct); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith('/robots.txt'): return self._send(200, 'User-agent: *\nAllow: /\n', 'text/plain')
        if self.path.startswith('/search'):
            if 'format=json' not in self.path: return self._send(403, '', 'text/plain')
            r = [{'url': f'http://127.0.0.1:{WEB}/p1', 'title': 'Energia solar fotovoltaica', 'content': 'energia solar', 'engine': 'duckduckgo'}, {'url': f'http://localhost:{WEB}/p2', 'title': 'Energia solar residencial', 'content': 'energia solar', 'engine': 'bing'}] if 'solar' in urllib.parse.unquote(self.path) else []
            return self._send(200, json.dumps({'results': r}), 'application/json')
        if self.path == '/p1': return self._send(200, f'<html lang="pt-BR"><title>Energia solar fotovoltaica</title><body><main>{P1}</main></body></html>', 'text/html; charset=utf-8')
        if self.path == '/p2': return self._send(200, f'<html lang="pt-BR"><title>Energia solar residencial</title><body><main>{P2}</main></body></html>', 'text/html; charset=utf-8')
        self._send(404, '', 'text/plain')
import urllib.parse
web = ThreadingHTTPServer(('0.0.0.0', WEB), Web); threading.Thread(target=web.serve_forever, daemon=True).start()
def subir():
    env = {**os.environ, 'PORT': '4315', 'SQLITE_FILE': '/tmp/ma-cc.db', 'CEREBRO_PERMITIR_REDE_LOCAL': '1'}
    pr = subprocess.Popen(['npx', 'tsx', 'test/serve-sqlite.ts'], cwd='/home/claude/repo/meu-assistente/server', env=env, stdout=open('/tmp/cd/srv4315.log', 'a'), stderr=subprocess.STDOUT)
    for _ in range(90):
        try: urllib.request.urlopen(BASE + '/api/health', timeout=2); return pr
        except Exception: time.sleep(1)
    raise SystemExit('servidor não subiu')
for f in ['/tmp/ma-cc.db', '/tmp/ma-cc.db-wal', '/tmp/ma-cc.db-shm']:
    if os.path.exists(f): os.remove(f)
srv = subir()
errs = []
try:
  with sync_playwright() as p:
    b = p.chromium.launch(); R = b.new_context(base_url=BASE).request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob)
        assert c.request.post('/api/auth', data={'action': 'login', 'email': 'admin@t.com', 'password': 'Senha@Forte123'}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        sem_rolagem = lambda: pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1
        # painel
        pg.goto('/admin/cerebro-central'); pg.wait_for_selector('#tiles', timeout=20000)
        t = pg.inner_text('#tiles')
        check(f'{nome}: painel com os totais', all(x in t for x in ['Conhecimentos armazenados', 'Aguardando aprovação', 'Categorias', 'Fontes cadastradas', 'Pesquisas e estudos', 'Última atualização']) and '14' in t, t)
        check(f'{nome}: status dos mecanismos', 'Wikipédia' in pg.inner_text('#c') and 'Vetores locais' in pg.inner_text('#c') and 'Uso de hoje' in pg.inner_text('#c'))
        check(f'{nome}: sem rolagem horizontal (painel)', sem_rolagem())
        pg.screenshot(path=f'/tmp/e2e/cc_painel_{nome}.png')
        # biblioteca: criar (aprovado), abrir, editar
        titulo = f'Regime do MEI ({nome})'
        pg.click('nav a[href="#biblioteca"]'); pg.wait_for_selector('#b_novo')
        pg.click('#b_novo'); pg.fill('#ed_t', titulo); pg.fill('#ed_c', f'O microempreendedor individual paga mensalmente o DAS, boleto único com INSS e impostos ({nome}). O faturamento anual tem limite definido em lei.')
        pg.fill('#ed_f', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor'); pg.check('#ed_ap'); pg.click('#ed_ok'); pg.wait_for_timeout(1200)
        it = pg.locator('#b_lista .item', has_text=titulo)
        check(f'{nome}: conhecimento criado e aprovado aparece na biblioteca', it.count() == 1 and 'Aprovado' in it.inner_text() and 'Empreendedorismo' in it.inner_text() and 'Versão 1' in it.inner_text(), pg.inner_text('#b_lista')[:300])
        it.locator('[data-ver]').click(); pg.wait_for_selector('#mod .kb-doc')
        md = pg.inner_text('#mod')
        check(f'{nome}: detalhes com conteúdo, fontes e histórico', 'gov.br' in md and 'criado' in md and 'Fontes de origem (1)' in md, md[:300])
        pg.click('#mod [data-ed]'); pg.fill('#ed_c', pg.input_value('#ed_c') + ' Pode ter um empregado.'); pg.click('#ed_ok'); pg.wait_for_timeout(1000)
        check(f'{nome}: edição gera nova versão', 'Versão 2' in pg.locator('#b_lista .item', has_text=titulo).inner_text())
        pg.fill('#b_q', 'boleto mensal do microempreendedor'); pg.click('#b_ir'); pg.wait_for_timeout(1000)
        check(f'{nome}: busca semântica encontra pelo sentido', pg.locator('#b_lista .item').first.inner_text().startswith('Regime do MEI') and 'Relevância' in pg.locator('#b_lista .item').first.inner_text())
        check(f'{nome}: sem rolagem horizontal (biblioteca)', sem_rolagem())
        pg.screenshot(path=f'/tmp/e2e/cc_biblioteca_{nome}.png')
        if nome == 'celular':
            # provedores: SearXNG local como principal, Wikipédia desligada
            pg.click('nav a[href="#provedores"]'); pg.wait_for_selector('[data-p]')
            wk = pg.locator('[data-p]', has_text='Wikipédia'); wk.locator('[data-sw]').click(); pg.wait_for_timeout(800)
            sx = pg.locator('[data-p]', has_text='SearXNG'); sx.locator('[data-url]').fill(f'http://127.0.0.1:{WEB}'); sx.locator('[data-salvar]').click(); pg.wait_for_timeout(800)
            sx = pg.locator('[data-p]', has_text='SearXNG'); sx.locator('[data-sw]').click(); pg.wait_for_timeout(800)
            sx = pg.locator('[data-p]', has_text='SearXNG'); sx.locator('[data-papel]').select_option('principal'); pg.wait_for_timeout(800)
            sx = pg.locator('[data-p]', has_text='SearXNG'); sx.locator('[data-teste]').click(); pg.wait_for_timeout(1500)
            check('provedor SearXNG configurado e testado pela tela', sx.locator('[data-sw]').get_attribute('aria-checked') == 'true' and 'conectou' in sx.locator('[data-res]').inner_text(), sx.inner_text()[:300])
            gg = pg.locator('[data-p]', has_text='Google Programmable'); gg.locator('[data-key]').fill('AIza-chave-secreta-xyz'); gg.locator('[data-salvar]').click(); pg.wait_for_timeout(800)
            check('chave salva não volta para a tela', 'guardada' in pg.locator('[data-p]', has_text='Google Programmable').locator('[data-key]').get_attribute('placeholder') and 'chave-secreta' not in pg.content())
            pg.screenshot(path='/tmp/e2e/cc_provedores_celular.png', full_page=True)
            # pesquisa e estudo
            pg.click('nav a[href="#aprendizagem"]'); pg.wait_for_selector('#p_t')
            pg.fill('#p_t', 'energia solar'); pg.click('#p_ir'); pg.wait_for_selector('#p_r .item', timeout=15000)
            check('pesquisa na internet mostra as páginas lidas', pg.locator('#p_r .item').count() == 2)
            pg.fill('#a_t', 'energia solar'); pg.click('#a_ir'); pg.wait_for_selector('#a_prog .caso.ok', timeout=30000)
            pr = pg.inner_text('#a_prog')
            check('estudo acompanhado etapa por etapa até concluir', all(x in pr for x in ['Busca', 'Leitura', 'Extração', 'Comparação', 'Guardado como conhecimento']) and 'concluído' in pr, pr[:500])
            check('repetição entre fontes eliminada', 'repetição(ões) entre fontes eliminada(s)' in pr and '0 repetição' not in pr, pr[:500])
            pg.fill('#j_t', 'manutenção de energia solar'); pg.click('#j_ok'); pg.wait_for_timeout(800)
            check('tarefa de aprendizagem contínua criada', 'manutenção de energia solar' in pg.inner_text('#j_l') and 'Programado' in pg.inner_text('#j_l'))
            check('histórico de aprendizagem', 'energia solar' in pg.inner_text('#h_l') and 'Concluído' in pg.inner_text('#h_l'))
            pg.screenshot(path='/tmp/e2e/cc_aprendizagem_celular.png', full_page=True)
            # aprovar o estudo e testar no laboratório
            pg.click('nav a[href="#biblioteca"]'); pg.wait_for_selector('#b_lista .item'); pg.fill('#b_q', ''); pg.select_option('#b_st', 'pendente'); pg.wait_for_timeout(900)
            pg.locator('#b_lista .item', has_text='Energia solar').locator('[data-rv=aprovar]').click(); pg.wait_for_timeout(900)
            pg.click('nav a[href="#laboratorio"]'); pg.wait_for_selector('#l_q'); pg.fill('#l_q', 'como o inversor funciona na energia solar?'); pg.uncheck('#l_ia')
            pg.click('[data-m=comparar]'); pg.wait_for_selector('#l_r .duas', timeout=20000)
            lr = pg.inner_text('#l_r')
            check('laboratório compara biblioteca × biblioteca + internet, com fontes e lacunas', 'Só biblioteca' in lr and 'Biblioteca + internet' in lr and 'Origem: biblioteca' in lr and '[B1]' in lr and '[W1]' in lr and 'O que está faltando' in lr and 'Divergências' in lr, lr[:600])
            pg.screenshot(path='/tmp/e2e/cc_laboratorio_celular.png', full_page=True)
            pg.click('nav a[href="#fontes"]'); pg.wait_for_selector('#f_l')
            check('fontes lidas listadas', pg.locator('#f_l .item').count() >= 3)
            pg.locator('#f_l .item', has_text='localhost').locator('[data-c]').select_option('bloqueada'); pg.wait_for_timeout(600)
            pg.click('nav a[href="#configuracoes"]'); pg.wait_for_selector('#c_ok')
            pg.click('[data-k=pesquisaAutomatica]'); pg.click('#c_ok'); pg.wait_for_timeout(700)
            check('configurações salvas', c.request.get('/api/brain/settings').json()['pesquisaAutomatica'] is False)
            pg.click('#t_gen'); pg.wait_for_selector('#t_v')
            tok = pg.inner_text('#t_v').strip()
            check('token de integração gerado e consultável', tok.startswith('mab_') and b.new_context(base_url=BASE).request.get('/api/brain/knowledge', headers={'Authorization': 'Bearer ' + tok}).json()['total'] >= 2)
            check('sem rolagem horizontal (configurações)', sem_rolagem())
        c.close()
    # usuário comum não acessa
    u = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE)
    assert u.request.post('/api/auth', data={'action': 'signup', 'name': 'Usuario Comum', 'whatsapp': '+55 11 95555-0101', 'email': 'u@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.7.7.7'}).ok
    pu = u.new_page(); pu.goto('/admin/cerebro-central'); pu.wait_for_selector('.neg', timeout=15000)
    check('usuário comum vê "Acesso restrito" e nenhum dado', 'Acesso restrito' in pu.inner_text('body') and pu.locator('#tiles').count() == 0)
    check('API recusa usuário comum', u.request.get('/api/brain/knowledge').status == 403)
    u.close()
    total_antes = R.get('/api/brain/status').json()['totais']['conhecimentos']
    b.close()
  # persistência: reinicia o servidor com o mesmo banco
  srv.terminate(); srv.wait(timeout=20); srv = subir()
  with sync_playwright() as p:
    b = p.chromium.launch(); R = b.new_context(base_url=BASE).request
    assert R.post('/api/auth', data={'action': 'login', 'email': 'admin@t.com', 'password': 'Senha@Forte123'}).ok
    st = R.get('/api/brain/status').json(); l = R.get('/api/brain/knowledge?q=inversor%20corrente').json()
    check('persistência após reiniciar: conhecimentos, versões, provedores e busca', st['totais']['conhecimentos'] == total_antes and st['totais']['conhecimentos'] >= 3 and l['itens'][0]['titulo'].startswith('Energia solar') and any(x['provedor'] == 'searxng' and x['ativo'] for x in R.get('/api/brain/providers').json()['provedores']), (st['totais'], l['itens'][:1]))
    b.close()
  check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e], errs)
finally:
  srv.terminate(); web.shutdown()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
