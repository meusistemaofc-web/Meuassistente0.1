# Meus Avisos (/notificacoes): tocar num aviso abre os detalhes na hora (sem tela preta), com título, mensagem completa,
# data/hora, categoria, registro relacionado e a ação do aviso; "Voltar aos avisos" e o voltar do aparelho retornam à lista;
# abrir marca como lida sem mudar o conteúdo; avisos antigos (sem mensagem/link) abrem; as ações levam a telas que carregam.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-ui.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, sqlite3, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4311'; DBF = '/tmp/ma-ui.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
LONGA = ('Seu pedido de renovação foi recebido e está sendo processado. ' * 9).strip() + ' FIM-DA-MENSAGEM'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); R = A.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    R.put('/api/panel/modules', data={'carteira': True, 'mercado': True})
    rem = R.post('/api/items', data={'action': 'create', 'type': 'reminder', 'data': {'message': 'Levar o carro na revisão', 'date': '2099-05-02', 'time': '08:30'}}).json()['item']['id']
    uid = sqlite3.connect(DBF).execute("select id from users where email='admin@t.com'").fetchone()[0]
    db = sqlite3.connect(DBF)
    def ins(t, title, body, link, ref, when):
        db.execute('insert into notifications (user_id,type,title,body,link,ref,read,created_at) values (?,?,?,?,?,?,0,?)', (uid, t, title, body, link, ref, when)); db.commit()
        return db.execute('select max(id) from notifications').fetchone()[0]
    # formatos gravados pelo sistema (lembrete com registro real, tela /x/*, página própria, aviso antigo sem mensagem/link, mensagem longa)
    N_ANT = ins('tipo_antigo', 'Aviso antigo sem detalhes', None, None, None, '2024-03-05T13:00:00.000Z')
    N_EXE = ins('execucao', 'Tarefa concluída', 'Organizar a agenda — 3 de 3 etapa(s) concluída(s).', '/execucoes#1', 'exec:1', '2026-11-10T12:00:00.000Z')
    N_CAR = ins('coin', 'Você recebeu 10 MCX', 'Loja X · Motivo: fidelidade', '/x/carteira', 'coin-lote:T1:%d' % uid, '2026-11-12T12:00:00.000Z')
    N_LON = ins('plan', 'Plano em processamento', LONGA, '/', None, '2026-11-14T12:00:00.000Z')
    N_REM = ins('reminder', 'Levar o carro na revisão', 'Em 15 min', '/agenda?tab=lembretes&lembrete=%d' % rem, 'reminder:%d:2099-05-02T11:30:00.000Z' % rem, '2026-11-16T12:00:00.000Z')
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        db.execute('update notifications set read=0 where user_id=?', (uid,)); db.commit()
        c = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob)
        assert c.request.post('/api/auth', data={'action': 'login', 'email': 'admin@t.com', 'password': 'Senha@Forte123'}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/notificacoes'); pg.wait_for_selector('main button:has-text("Levar o carro na revisão")', timeout=20000); pg.wait_for_timeout(600)
        lista = lambda: pg.locator('main button:has-text("Aviso antigo sem detalhes")').count() == 1 and pg.locator('[data-aviso]').count() == 0
        check(f'{nome}: lista de avisos carregada', lista())
        # 1) lembrete: detalhes + registro relacionado
        pg.locator('main button:has-text("Levar o carro na revisão")').first.click()
        pg.wait_for_selector('[data-aviso-titulo]', timeout=1500)
        check(f'{nome}: detalhes aparecem imediatamente (título, mensagem, categoria, data)', pg.locator('[data-aviso-titulo]').inner_text() == 'Levar o carro na revisão' and pg.locator('[data-aviso-msg]').inner_text() == 'Em 15 min' and pg.locator('[data-aviso-cat]').inner_text().lower() == 'lembrete' and 'Recebido em' in pg.locator('[data-aviso-quando]').inner_text())
        pg.wait_for_selector('[data-aviso-rel]', timeout=8000)
        rel = pg.locator('[data-aviso-rel]').inner_text()
        check(f'{nome}: registro relacionado (lembrete) com data e situação', 'Levar o carro na revisão' in rel and '02/05/2099' in rel and 'Pendente' in rel, rel)
        check(f'{nome}: data e hora de recebimento completas', '16/11/2026 às' in pg.locator('[data-aviso-quando]').inner_text(), pg.locator('[data-aviso-quando]').inner_text())
        check(f'{nome}: ação do aviso disponível', pg.locator('[data-aviso-acao]').inner_text().strip() == 'Abrir lembretes')
        check(f'{nome}: marcado como lido ao abrir, conteúdo intacto', db.execute('select read,title,body,link from notifications where id=?', (N_REM,)).fetchone() == (1, 'Levar o carro na revisão', 'Em 15 min', '/agenda?tab=lembretes&lembrete=%d' % rem))
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.screenshot(path=f'/tmp/e2e/aviso_detalhe_{nome}.png')
        pg.click('[data-aviso-voltar]'); pg.wait_for_timeout(500)
        check(f'{nome}: "Voltar aos avisos" volta à lista', lista() and pg.url.endswith('/notificacoes'), pg.url)
        # 2) voltar do aparelho
        pg.locator('main button:has-text("Plano em processamento")').first.click(); pg.wait_for_selector('[data-aviso-msg]', timeout=1500)
        check(f'{nome}: mensagem longa completa, sem cortes', pg.locator('[data-aviso-msg]').inner_text() == LONGA and pg.locator('[data-aviso-msg]').evaluate('e=>e.scrollHeight<=e.clientHeight+1'))
        pg.wait_for_timeout(600)
        check(f'{nome}: aviso sem link não mostra ação vazia', pg.locator('[data-aviso-acao]').count() == 0)
        pg.go_back(); pg.wait_for_timeout(600)
        check(f'{nome}: voltar do aparelho fecha os detalhes e mantém a lista', lista() and pg.url.endswith('/notificacoes'), pg.url)
        # 3) aviso antigo, sem mensagem e sem link
        pg.locator('main button:has-text("Aviso antigo sem detalhes")').first.click(); pg.wait_for_selector('[data-aviso-titulo]', timeout=1500); pg.wait_for_timeout(800)
        check(f'{nome}: aviso antigo abre com título, categoria e data', pg.locator('[data-aviso-titulo]').inner_text() == 'Aviso antigo sem detalhes' and pg.locator('[data-aviso-cat]').inner_text().lower() == 'aviso' and '05/03/2024' in pg.locator('[data-aviso-quando]').inner_text() and pg.locator('[data-aviso-acao]').count() == 0 and pg.locator('.text-danger').count() == 0)
        pg.click('[data-aviso-voltar]'); pg.wait_for_timeout(400)
        # 4) ação para uma tela extra (/x/carteira): abre a carteira (antes: tela preta)
        pg.locator('main button:has-text("Você recebeu 10 MCX")').first.click(); pg.wait_for_selector('[data-aviso-acao]', timeout=8000)
        pg.click('[data-aviso-acao]'); pg.wait_for_timeout(2500)
        txt = pg.inner_text('body')
        check(f'{nome}: ação "Abrir carteira" abre a carteira (sem tela preta)', pg.url.endswith('/x/carteira') and pg.locator('#ma-x').count() == 1 and 'arteira' in pg.locator('#ma-x').inner_text(), (pg.url, txt[:200]))
        pg.go_back(); pg.wait_for_timeout(1200)
        check(f'{nome}: voltar da carteira retorna à lista de avisos', pg.url.endswith('/notificacoes') and lista(), pg.url)
        # 5) ação para página própria (/execucoes)
        pg.locator('main button:has-text("Tarefa concluída")').first.click(); pg.wait_for_selector('[data-aviso-acao]', timeout=8000)
        pg.click('[data-aviso-acao]'); pg.wait_for_load_state('load'); pg.wait_for_timeout(1500)
        check(f'{nome}: ação "Abrir execuções" abre a página de execuções com conteúdo', '/execucoes' in pg.url and len(pg.inner_text('body').strip()) > 20, (pg.url, pg.inner_text('body')[:150]))
        # 6) ação para rota do app (/agenda)
        pg.goto('/notificacoes'); pg.wait_for_selector('main button:has-text("Levar o carro na revisão")', timeout=20000)
        pg.locator('main button:has-text("Levar o carro na revisão")').first.click(); pg.wait_for_selector('[data-aviso-acao]', timeout=8000)
        pg.click('[data-aviso-acao]'); pg.wait_for_timeout(2000)
        check(f'{nome}: ação "Abrir lembretes" abre a agenda', '/agenda' in pg.url and 'tab=lembretes' in pg.url and len(pg.locator('main').inner_text().strip()) > 20, pg.url)
        # 7) link direto para um aviso (/notificacoes?aviso=ID)
        pg.goto(f'/notificacoes?aviso={N_CAR}'); pg.wait_for_selector('[data-aviso-titulo]', timeout=20000); pg.wait_for_timeout(800)
        check(f'{nome}: link direto abre o aviso', pg.locator('[data-aviso-titulo]').inner_text() == 'Você recebeu 10 MCX' and 'fidelidade' in pg.locator('[data-aviso-msg]').inner_text())
        pg.click('[data-aviso-voltar]'); pg.wait_for_timeout(600)
        check(f'{nome}: e volta para a lista', lista() and 'aviso=' not in pg.url, pg.url)
        check(f'{nome}: contador de não lidas atualizado', c.request.get('/api/notifications?count=1').json()['unread'] == db.execute('select count(*) from notifications where user_id=? and read=0', (uid,)).fetchone()[0])
        c.close()
    check('outro usuário não abre o aviso', b.new_context(base_url=BASE).request.get(f'/api/notifications/{N_REM}').status == 401)
    check('nenhum aviso apagado', db.execute('select count(*) from notifications where user_id=?', (uid,)).fetchone()[0] >= 5)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
