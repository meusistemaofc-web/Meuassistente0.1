# Compartilhamento de produtos e serviços: ícone nos detalhes (produto e serviço), mensagem pronta com dados de agora
# (variação escolhida, oferta, serviço), canais (WhatsApp, Telegram, Facebook, apps do aparelho, copiar link, copiar mensagem),
# link aberto por quem não tem conta (abre o item, na variação; conta a visita), item indisponível com mensagem, painel do
# administrador (ligar/desligar, mensagens, regra por categoria, prévia, restaurar, estatísticas) e ajustes da empresa.
# Celular e computador. Servidor: PORT=4328 SQLITE_FILE=/tmp/ma-shr.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, base64, os
from urllib.parse import unquote
from PIL import Image
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4328'; DBF = '/tmp/ma-shr.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (600, 400), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
SHARE_JS = "window.__shares=[];navigator.share=async d=>{window.__shares.push(d)};"
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Admin Sh', 'whatsapp': '+55 85 94444-6001', 'email': 'admin.sh@t.com', **U}).ok
    assert RA.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def dono(nome, email, zap, ip):
        X = b.new_context(base_url=BASE); R = X.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': nome, 'whatsapp': zap, 'email': email, **U}, headers={'X-Forwarded-For': ip}).ok
        return R
    RL = dono('Lia Loja', 'lia.sh@t.com', '+55 85 94444-6002', '10.6.0.2'); RS = dono('Sol Studio', 'sol.sh@t.com', '+55 85 94444-6003', '10.6.0.3')
    def loja(R, nome, serv=False):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': nome, 'categoria': 'Variados', 'titulo': 'x', 'texto': 'x', 'zap': '5585999990000'}); assert r.ok, r.text(); i = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (i,)); db.commit(); db.close()
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        if serv: assert R.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
        return i
    L = loja(RL, 'Loja da Lia'); S = loja(RS, 'Studio da Sol', True)
    assert RL.post(f'/api/v2/ads/{L}/products', data={'nome': 'Camiseta', 'categoria': 'Roupas', 'descricao': 'Algodão', 'variantes': [{'cor': 'Preta', 'tamanho': 'P', 'preco': 40, 'fotos': [durl((20, 20, 20))]}, {'cor': 'Branca', 'tamanho': 'M', 'preco': 55, 'fotos': [durl((240, 240, 240))]}]}).ok
    assert RL.post(f'/api/v2/ads/{L}/products', data={'nome': 'Tênis', 'preco': 300, 'categoria': 'Calçados', 'fotos': [durl((200, 50, 50))], 'oferta': {'ativo': True, 'preco': 249.9}}).ok
    assert RL.post(f'/api/v2/ads/{L}/products', data={'nome': 'Boné pausado', 'preco': 30, 'categoria': 'Acessórios', 'fotos': [durl((50, 50, 200))]}).ok
    its = RL.get(f'/api/v2/ads/{L}/products').json()['items']; it = lambda n: next(x for x in its if x['nome'] == n)
    CAM, TEN, BON = it('Camiseta'), it('Tênis')['id'], it('Boné pausado')['id']
    BR = next(v['id'] for v in CAM['variantes'] if v['cor'] == 'Branca')
    assert RL.post(f'/api/v2/ads/{L}/products', data={'action': 'toggle', 'id': BON, 'ativo': False}).ok
    assert RS.post(f'/api/v2/ads/{S}/products', data={'tipo': 'servico', 'nome': 'Massagem', 'preco': 90, 'modoPreco': 'hora', 'duracao': 60, 'categoria': 'Bem-estar', 'fotos': [durl((40, 160, 90))]}).ok
    SV = RS.get(f'/api/v2/ads/{S}/products').json()['items'][0]['id']
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        V = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, permissions=['clipboard-read', 'clipboard-write'])
        if mob: V.add_init_script(SHARE_JS)
        pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e)))
        # ---------- detalhe do produto: ícone discreto, variação escolhida vai na mensagem ----------
        pv.goto(f'/x/empresa/{L}?produto={CAM["id"]}'); pv.wait_for_selector(f'[data-detalhe="{CAM["id"]}"]', timeout=20000); pv.wait_for_timeout(2600)
        ic = pv.locator('.ma-sheet [data-item-share]'); bb = ic.bounding_box(); x = pv.locator('.ma-sheet-x').bounding_box()
        check(f'{nome}: ícone de compartilhar discreto ao lado do nome do produto', ic.count() == 1 and bb['width'] <= 40 and ic.locator('svg path').count() >= 2 and abs(bb['y'] - x['y']) > 50)
        pv.click('.ma-sheet [data-vv="Branca"]'); pv.wait_for_timeout(300)
        pv.click('.ma-sheet [data-item-share]'); pv.wait_for_selector('[data-share-sheet]', timeout=8000)
        msg = N(pv.inner_text('[data-sh-msg]')); url = N(pv.inner_text('[data-sh-url]'))
        check(f'{nome}: mensagem pronta com a variação escolhida e o preço dela (sem outro preço)', 'Camiseta (Branca · M)' in msg and 'R$ 55,00' in msg and '40,00' not in msg and 'Loja da Lia' in msg and url in msg and f'&v={BR}' in url, msg)
        canais = [x.get_attribute('data-sh') for x in pv.locator('[data-share-sheet] [data-sh]').all()]
        check(f'{nome}: canais WhatsApp, Telegram, Facebook, {"apps do aparelho, " if mob else ""}copiar link e copiar mensagem', canais == ['whatsapp', 'telegram', 'facebook'] + (['apps'] if mob else []) + ['copiar', 'copiar-msg'], canais)
        wa = unquote(pv.get_attribute('[data-sh=whatsapp]', 'href')); tg = unquote(pv.get_attribute('[data-sh=telegram]', 'href')); fb = unquote(pv.get_attribute('[data-sh=facebook]', 'href'))
        check(f'{nome}: botões do compartilhar em uma linha cada', all(x.bounding_box()['height'] <= 46 for x in pv.locator('[data-share-sheet] [data-sh]').all()))
        check(f'{nome}: WhatsApp leva a mensagem; Telegram e Facebook levam o link', wa.startswith('https://wa.me/?text=') and msg[:40] in wa and url in tg and tg.startswith('https://t.me/share/url') and fb.startswith('https://www.facebook.com/sharer/sharer.php?u=') and url in fb)
        if mob:
            pv.screenshot(path='/tmp/e2e/shr_sheet.png')
            pv.click('[data-sh=apps]'); pv.wait_for_timeout(400); sh = pv.evaluate('window.__shares')
            check('celular: "Instagram e outros" usa o compartilhamento do aparelho (texto + link)', sh and sh[-1]['url'] == url and 'Camiseta (Branca · M)' in sh[-1]['text'] and url not in sh[-1]['text'], sh)
            pv.click('.ma-sheet [data-item-share]'); pv.wait_for_selector('[data-share-sheet]')
        else:
            check('computador: sem compartilhamento do aparelho, dica para o Instagram', 'Copiar texto' in pv.inner_text('[data-sh-insta]'))
        pv.click('[data-sh=copiar-msg]'); pv.wait_for_timeout(300)
        check(f'{nome}: copiar mensagem', pv.evaluate('navigator.clipboard.readText()') == msg)
        # oferta e serviço
        pv.goto(f'/x/empresa/{L}?produto={TEN}'); pv.wait_for_selector(f'[data-detalhe="{TEN}"]', timeout=15000); pv.wait_for_timeout(400)
        pv.click('.ma-sheet [data-item-share]'); pv.wait_for_selector('[data-share-sheet]'); mo = N(pv.inner_text('[data-sh-msg]'))
        check(f'{nome}: oferta com preço promocional e o normal', mo.startswith('🔥') and 'R$ 249,90' in mo and 'R$ 300,00' in mo, mo)
        pv.click('[data-sh=copiar]'); pv.wait_for_timeout(300)
        pv.goto(f'/x/empresa/{S}?servico={SV}'); pv.wait_for_selector(f'[data-detalhe="{SV}"]', timeout=15000); pv.wait_for_timeout(400)
        check(f'{nome}: ícone também no detalhe do serviço', pv.locator('.ma-sheet [data-item-share]').count() == 1)
        pv.click('.ma-sheet [data-item-share]'); pv.wait_for_selector('[data-share-sheet]'); ms = N(pv.inner_text('[data-sh-msg]'))
        check(f'{nome}: mensagem de serviço com preço por hora', 'Massagem' in ms and 'R$ 90,00/hora' in ms and 'Studio da Sol' in ms and f'servico={SV}' in ms, ms)
        pv.click('[data-sh=whatsapp]'); pv.wait_for_timeout(600)
        check(f'{nome}: sem rolagem lateral', pv.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        V.close()
        # ---------- link aberto por quem não tem conta ----------
        X = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); px = X.new_page(); px.on('pageerror', lambda e: errs.append(str(e)))
        px.goto(f'/x/empresa/{L}?produto={CAM["id"]}&v={BR}&ref=share'); px.wait_for_selector(f'[data-detalhe="{CAM["id"]}"]', timeout=20000); px.wait_for_timeout(800)
        check(f'{nome}: link abre o item direto, sem conta, já na variação compartilhada, com preço atual', N(px.inner_text('[data-vrot]')) == 'Branca · M' and 'R$ 55,00' in N(px.inner_text('[data-preco]')) and 'entrar' not in px.url and 'ref=share' not in px.url)
        px.goto(f'/x/empresa/{L}?produto={BON}&ref=share'); px.wait_for_selector('[data-item-indisponivel]', timeout=20000)
        check(f'{nome}: item pausado/removido → mensagem adequada e o catálogo da empresa', 'não está mais disponível' in px.inner_text('[data-item-indisponivel]') and 'Loja da Lia' in px.inner_text('[data-item-indisponivel]'))
        px.click('[data-ver-catalogo]'); px.wait_for_timeout(400)
        check(f'{nome}: "Ver o catálogo" mostra os itens disponíveis', px.locator('.ma-sheet').count() == 0 and px.locator('[data-prod]').count() >= 2)
        X.close()
    # visitas e compartilhamentos registrados (sem dados pessoais)
    db = sqlite3.connect(DBF); ev = db.execute("select kind, channel, product_id from share_events").fetchall(); vw = db.execute("select viewer from share_events").fetchall(); db.close()
    check('registro: compartilhamentos por canal e visitas pelo link (mesma pessoa no mesmo dia = 1 visita)', sum(1 for k, c, pid in ev if k == 'visita' and pid == CAM['id']) == 1 and any(c == 'whatsapp' and pid == SV for k, c, pid in ev) and any(c == 'copiar_mensagem' for k, c, pid in ev) and any(c == 'nativo' for k, c, pid in ev), ev)
    check('registro sem IP nem conta (código diário)', all(len(v[0]) == 16 and '.' not in v[0] for v in vw))
    # ---------- painel do administrador ----------
    P = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); assert P.request.post('/api/auth', data={'action': 'login', 'email': 'admin.sh@t.com', 'password': U['password']}).ok
    pa = P.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(1500); aba(pa,'Compartilhamento'); pa.wait_for_selector('[data-pshare]', timeout=10000); pa.wait_for_timeout(500)
    check('painel: liga/desliga, três mensagens, prévia e estatísticas', pa.locator('[data-sw="shp-ativo"]').count() == 1 and all(pa.locator(f'#shp_{k}').count() == 1 for k in ['produto', 'servico', 'oferta']) and 'Olha só' in pa.inner_text('[data-shp-prev-k=produto]') and int(pa.inner_text('[data-shp-total]')) >= 4 and pa.locator(f'[data-shp-item="{SV}"]').count() == 1 and 'Studio da Sol' in pa.inner_text('[data-shp-stats]'))
    pa.fill('#shp_produto', 'Novidade na {empresa}: {produto} {link}'); pa.wait_for_timeout(200)
    check('painel: pré-visualização ao vivo', N(pa.inner_text('[data-shp-prev-k=produto]')).startswith('Novidade na'))
    pa.click('#shp_add'); pa.fill('[data-rc="0"]', 'Calçados'); pa.fill('[data-rt="0"]', 'Pra correr com estilo: {produto} {link}')
    pa.fill('#shp_servico', 'Serviço sem link'); pa.click('#shp_ok'); pa.wait_for_timeout(600)
    check('painel: valida a mensagem (precisa de {link})', '{link}' in pa.inner_text('#shp_er'))
    pa.fill('#shp_servico', 'Agende {produto} na {empresa}: {link}'); pa.click('#shp_ok'); pa.wait_for_timeout(800)
    cfg = P.request.get('/api/panel/compartilhar').json()['config']
    check('painel: salvar mensagens e regra por categoria', cfg['produto'].startswith('Novidade') and cfg['servico'].startswith('Agende') and cfg['categorias'] == [{'categoria': 'Calçados', 'texto': 'Pra correr com estilo: {produto} {link}'}])
    W = b.new_context(base_url=BASE).request
    check('mensagens novas valem na hora (serviço e regra da categoria; oferta mantém o modelo de oferta)', W.get(f'/api/v2/compartilhar/item/{SV}').json()['mensagem'].startswith('Agende Massagem') and W.get(f'/api/v2/compartilhar/item/{CAM["id"]}').json()['mensagem'].startswith('Novidade na Loja da Lia') and W.get(f'/api/v2/compartilhar/item/{TEN}').json()['modelo'] == 'oferta')
    pa.screenshot(path='/tmp/e2e/shr_painel.png', full_page=True)
    pa.on('dialog', lambda d: d.accept()); pa.click('#shp_pd'); pa.wait_for_timeout(800)
    check('painel: restaurar mensagens padrão', P.request.get('/api/panel/compartilhar').json()['config']['produto'].startswith('Olha só'))
    pa.click('[data-sw="shp-ativo"]'); pa.click('#shp_ok'); pa.wait_for_timeout(700)
    V2 = b.new_context(base_url=BASE); p2 = V2.new_page(); p2.goto(f'/x/empresa/{S}?servico={SV}'); p2.wait_for_selector(f'[data-detalhe="{SV}"]', timeout=20000); p2.wait_for_timeout(500)
    check('painel: desligado → o ícone some dos detalhes', p2.locator('.ma-sheet [data-item-share]').count() == 0); V2.close()
    pa.click('[data-sw="shp-ativo"]'); pa.click('#shp_ok'); pa.wait_for_timeout(700); P.close()
    # ---------- ajustes da empresa ----------
    E = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); assert E.request.post('/api/auth', data={'action': 'login', 'email': 'lia.sh@t.com', 'password': U['password']}).ok
    pe = E.new_page(); pe.on('pageerror', lambda e: errs.append(str(e))); pe.on('dialog', lambda d: d.accept())
    pe.goto('/x/sua-empresa'); pe.wait_for_selector('.ma-nav [data-nav=mais]', timeout=20000); pe.click('.ma-nav [data-nav=mais]'); pe.wait_for_selector('[data-lt2=divulgar]', timeout=10000); pe.click('[data-lt2=divulgar]'); pe.wait_for_selector('[data-shcfg]', timeout=10000); pe.wait_for_timeout(300)
    check('empresa: Ajustes → Compartilhamento com liga/desliga, mensagens próprias, prévia e resultados', pe.locator('[data-sw="sh-ativo"]').get_attribute('aria-checked') == 'true' and pe.locator('#sh_produto').get_attribute('placeholder').startswith('Olha só') and 'Camiseta' in pe.inner_text('[data-shprev]') and int(pe.inner_text('[data-sh-total]')) >= 3 and pe.locator(f'[data-sh-item="{SV}"]').count() == 0)
    pe.fill('#sh_produto', 'Da Lia pra você: {produto} {link}'); pe.wait_for_timeout(200)
    check('empresa: prévia ao vivo', N(pe.inner_text('[data-shprev-k=produto]')).startswith('Da Lia pra você: Camiseta'))
    pe.click('#sh_ok'); pe.wait_for_timeout(700)
    check('empresa: mensagem própria vale para os itens dela', W.get(f'/api/v2/compartilhar/item/{CAM["id"]}').json()['mensagem'].startswith('Da Lia pra você') and not W.get(f'/api/v2/compartilhar/item/{SV}').json()['mensagem'].startswith('Da Lia'))
    pe.screenshot(path='/tmp/e2e/shr_empresa.png', full_page=True)
    pe.click('[data-sw="sh-ativo"]'); pe.click('#sh_ok'); pe.wait_for_timeout(700)
    V3 = b.new_context(base_url=BASE); p3 = V3.new_page(); p3.goto(f'/x/empresa/{L}?produto={TEN}'); p3.wait_for_selector(f'[data-detalhe="{TEN}"]', timeout=20000); p3.wait_for_timeout(500)
    check('empresa desligou → sem ícone nos itens dela', p3.locator('.ma-sheet [data-item-share]').count() == 0); V3.close()
    pe.click('#sh_pd'); pe.wait_for_timeout(700)
    check('empresa: restaurar mensagens padrão', W.get(f'/api/v2/ads/{L}/compartilhamento').status == 401 and RL.get(f'/api/v2/ads/{L}/compartilhamento').json()['config']['produto'] == '')
    E.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
