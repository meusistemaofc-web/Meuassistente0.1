# Mercado Pago (OAuth) de ponta a ponta no navegador: o dono toca em "Conectar minha conta Mercado Pago", é levado à
# autorização do Mercado Pago, autoriza e volta sozinho ao Meu Assistente; status Conectado / Desconectado / Erro na
# conexão, dados da conta, verificar, reconectar, desconectar; retorno sem sessão (celular: app do Mercado Pago).
# Servidor e dublê do Mercado Pago (o contêiner de testes não alcança mercadopago.com):
#   python3 test/browser/mercadopago_fake.py 4399 http://localhost:4311/api/mercadopago/oauth/callback pkce
#   MP_API_BASE=http://127.0.0.1:4399 MP_AUTH_BASE=http://127.0.0.1:4399 PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts
import sys, json, sqlite3, datetime, urllib.request
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'; FAKE='http://127.0.0.1:4399'; DBF='/tmp/ma-teste.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
iso=lambda d:(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=d)).isoformat().replace('+00:00','Z')
fk=lambda path: json.loads(urllib.request.urlopen(FAKE+path).read())
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE,viewport={'width':1280,'height':900}); RA=A.request
    assert RA.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com',**U}).ok
    RA.put('/api/panel/site',data={'url':'http://localhost:4311'})
    sistema=RA.get('/api/panel').json().get('mercadopago')
    # painel: aplicação do OAuth (separada das credenciais manuais do sistema), ambiente de teste e PKCE
    pa=A.new_page(); pa.on('pageerror',lambda e:errs.append(str(e))); pa.goto('/admin'); pa.wait_for_timeout(2500)
    aba(pa,'Mercado Pago'); pa.wait_for_selector('#mo_id',timeout=10000)
    check('painel: URL de redirecionamento exibida para cadastrar na aplicação', pa.locator('input[readonly]').first.input_value()=='http://localhost:4311/api/mercadopago/oauth/callback')
    pa.fill('#mo_id','1234567890123456'); pa.fill('#mo_sc','segredo-da-aplicacao-de-teste'); pa.select_option('#mo_amb','teste'); pa.check('#mo_pk')
    pa.click('#mo_t'); pa.wait_for_timeout(1500)
    check('painel: "Testar credenciais" valida a aplicação no Mercado Pago', 'Credenciais válidas' in pa.inner_text('#mo_m'), pa.inner_text('#mo_m'))
    cfg=RA.get('/api/panel').json()
    check('painel: PKCE e ambiente de teste salvos; credenciais manuais do sistema intactas', cfg['mp_oauth']['pkce'] is True and cfg['mp_oauth']['ambiente']=='teste' and cfg.get('mercadopago')==sistema and 'segredo-da-aplicacao' not in json.dumps(cfg))
    pa.screenshot(path='/tmp/e2e/mp_painel.png')
    db=sqlite3.connect(DBF)
    def dono(nome,email,ip,plano,empresa):
        c=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':'+55 11 95555-0'+ip,'email':email,**U},headers={'X-Forwarded-For':'10.7.7.'+ip}).ok
        i=R.post('/api/v2/ads',data={'planId':plano,'empresa':empresa,'categoria':'Doceria','titulo':'Doces','texto':'Doces artesanais','zap':'5511999990000'}).json()['items'][0]['id']
        db.execute("update businesses set status='ativo', expires_at=? where id=?",(iso(30),i)); db.commit(); return c,R,i
    D,RD,ID=dono('Dona Lu','lu@t.com','101','n4','Doceria da Lu')
    pg=D.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    def abrir():
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(3500)
        if not pg.locator('[data-lt2="entrega"]').count(): pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1200)
        pg.locator('[data-lt2="entrega"]').click(); pg.wait_for_selector('[data-mp-status]',timeout=15000)
    abrir()
    check('dono: status "Desconectado" e botão "Conectar minha conta Mercado Pago" (sem pedir Access Token)', pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='desconectado' and pg.locator('[data-mp-oauth]').inner_text()=='Conectar minha conta Mercado Pago' and pg.locator('#mpk').count()==0)
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_desconectado.png')
    # 1) toca no botão → vai ao Mercado Pago (dublê) → autoriza → volta sozinho
    pg.route('**/authorization?**',lambda r: r.continue_(url=r.request.url+'&conta=loja1'))
    pg.click('[data-mp-oauth]'); pg.wait_for_url('**/x/sua-empresa**',timeout=15000); pg.wait_for_selector('[data-mp-aviso="ok"]',timeout=15000); pg.wait_for_timeout(800)
    lg=fk('/__log'); au=[x for x in lg if x['tipo']=='authorization'][-1]; tk=[x for x in lg if x['tipo']=='token' and x.get('grant_type')=='authorization_code'][-1]
    check('autorização oficial: client_id, response_type=code, platform_id=mp, state e PKCE S256', au['response_type']=='code' and au['platform_id']=='mp' and len(au['state'])>=32 and au.get('code_challenge_method')=='S256', au)
    check('retorno: código trocado por tokens no servidor (code_verifier, test_token e redirect_uri exato)', tk.get('test_token') in (True,'true') and len(tk.get('code_verifier',''))>=43 and tk['redirect_uri']=='http://localhost:4311/api/mercadopago/oauth/callback', tk)
    t=pg.inner_text('[data-mp-box]')
    check('dono: "Conectado" com os dados da conta (apelido, nome, e-mail mascarado, ID, ambiente de teste)', 'LOJADALU' in t and 'Lu Vendas' in t and 'lu***@exemplo.com' in t and '1001' in t and 'ambiente de teste' in t and 'renovação automática' in t, t)
    check('tokens nunca aparecem na tela', 'TEST-' not in pg.content() and 'TG-' not in pg.content())
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_conectado.png')
    pg.click('[data-mp-ver]'); pg.wait_for_timeout(1200); check('"Verificar conexão" confirma na API oficial', 'Conectado à conta LOJADALU' in pg.inner_text('#mpm'), pg.inner_text('#mpm'))
    # 2) celular: autoriza no app do Mercado Pago e volta em outro navegador (sem sessão) → conecta mesmo assim
    url=RD.post(f'/api/v2/ads/{ID}/mp',data={'action':'oauth'}).json()['url']
    X=b.new_context(base_url=BASE); px=X.new_page(); px.goto(url+'&conta=loja1'); px.wait_for_timeout(1500)
    ok=db.execute('select data from businesses where id=?',(ID,)).fetchone()[0]; d=json.loads(ok)
    check('retorno em outro navegador (sem a sessão) também conecta a empresa certa', d.get('mpModo')=='oauth' and d.get('mpStatus')=='conectado' and d.get('mpUserId')==1001 and ('/entrar' in px.url or '/x/sua-empresa' in px.url), px.url)
    # 3) o dono revoga no Mercado Pago → "Erro na conexão" + Reconectar
    fk('/__revogar'); pg.click('[data-mp-ver]'); pg.wait_for_selector('[data-mp-status="erro"]',timeout=10000)
    check('autorização revogada: status "Erro na conexão", motivo e botão "Reconectar"', 'Erro na conexão' in pg.inner_text('[data-mp-box]') and pg.locator('[data-mp-erro]').count()==1 and 'Reconectar' in pg.locator('[data-mp-oauth]').inner_text())
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_erro.png')
    pg.click('[data-mp-oauth]'); pg.wait_for_url('**/x/sua-empresa**',timeout=15000); pg.wait_for_selector('[data-mp-status="conectado"]',timeout=15000)
    check('reconectar volta a "Conectado"', pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='conectado')
    # 4) cancelar no Mercado Pago mostra a mensagem certa e não derruba a conexão
    pg.unroute('**/authorization?**'); pg.route('**/authorization?**',lambda r: r.continue_(url=r.request.url+'&negar=1'))
    pg.click('[data-mp-oauth]'); pg.wait_for_selector('[data-mp-aviso="erro"]',timeout=15000)
    check('cancelou no Mercado Pago: aviso claro e a conta continua conectada', 'cancelou a autorização' in pg.inner_text('#mpm') and pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='conectado')
    # 5) outra empresa conecta a própria conta; não usa a mesma conta de outra dona
    D2,RD2,ID2=dono('Dono Beto','beto@t.com','102','n4','Lanches do Beto')
    u2=RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'oauth'}).json()['url']; p2=D2.new_page(); p2.goto(u2+'&conta=loja1'); p2.wait_for_selector('[data-mp-aviso]',timeout=15000)
    check('a mesma conta Mercado Pago não fica vinculada a duas empresas de donos diferentes', 'já recebe por outra empresa' in p2.inner_text('#mpm') and p2.locator('[data-mp-status]').get_attribute('data-mp-status')=='desconectado', p2.inner_text('[data-mp-box]')[:300])
    u3=RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'oauth'}).json()['url']; p2.goto(u3+'&conta=loja2'); p2.wait_for_selector('[data-mp-status="conectado"]',timeout=15000)
    check('segunda empresa conectada à própria conta (BETOLANCHES)', 'BETOLANCHES' in p2.inner_text('[data-mp-box]'))
    check('isolamento: uma empresa não vê nem desconecta a conexão da outra', RD2.post(f'/api/v2/ads/{ID}/mp',data={'action':'status'}).status==404 and RD2.post(f'/api/v2/ads/{ID}/mp',data={'action':'remove'}).status==404)
    # 6) desconectar
    pg.unroute('**/authorization?**'); pg.click('[data-mp-off]'); pg.wait_for_selector('[data-mp-status="desconectado"]',timeout=10000)
    d=json.loads(db.execute('select data from businesses where id=?',(ID,)).fetchone()[0])
    check('desconectar: status "Desconectado" e tokens apagados só desta empresa', not d.get('mpTok') and not d.get('mpRefresh') and RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'status'}).json()['mpStatus']=='conectado')
    # 7) plano sem acesso
    D3,RD3,ID3=dono('Dona Cris','cris@t.com','103','n1','Bazar da Cris')
    check('plano sem acesso: servidor bloqueia a conexão', RD3.post(f'/api/v2/ads/{ID3}/mp',data={'action':'oauth'}).status==403)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
