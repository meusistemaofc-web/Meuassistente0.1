# Inteligência avançada (Nível 2): avaliação 👍/👎 nas respostas do chat (preferência pessoal, privacidade),
# quadro do painel (chaves, indicadores, bateria, oportunidades → Laboratório) e layout sem quebras.
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    ctx=b.new_context(viewport={'width':430,'height':900},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    def enviar(t):
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2600)
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('xqz-n2-afirma me ajuda com uma ideia')
    pg.wait_for_selector('.msg-swipe .ma-fb',timeout=8000)
    rows=pg.locator('.msg-swipe:has(.ma-fb)')
    check('avaliação aparece só nas respostas do assistente', rows.count()>=1 and pg.locator('.msg-swipe:has(.bubble-user) .ma-fb').count()==0)
    row=rows.last; mid=row.get_attribute('data-mid')
    up=row.locator('[data-fb="1"]'); down=row.locator('[data-fb="-1"]')
    st=up.evaluate("e=>{const s=getComputedStyle(e);return {bg:s.backgroundColor,bd:s.borderStyle}}")
    check('botões discretos: só ícone, sem fundo e sem borda', st['bg'] in ('rgba(0, 0, 0, 0)','transparent') and st['bd']=='none', st)
    up.click(); pg.wait_for_timeout(900)
    check('👍 grava e fica marcado', up.get_attribute('aria-pressed')=='true' and R.get(f'/api/chat/feedback?ids={mid}').json()['avaliacoes'].get(mid)==1)
    up.click(); pg.wait_for_timeout(900)
    check('tocar de novo desfaz', up.get_attribute('aria-pressed')=='false' and R.get(f'/api/chat/feedback?ids={mid}').json()['avaliacoes'].get(mid) is None)
    down.click(); pg.wait_for_timeout(300); pan=row.locator('.ma-fb-panel')
    check('👎 abre painel com motivos, comentário e compartilhar desmarcado', pan.count()==1 and pan.locator('[data-m]').count()==8 and pan.locator('textarea').count()==1 and not pan.locator('input[type=checkbox]').is_checked())
    pan.locator('[data-m=muito_longa]').click(); pan.locator('textarea').fill('podia ser mais direto'); pan.locator('.env').click(); pg.wait_for_timeout(1200)
    check('enviar fecha o painel e confirma a preferência pessoal', row.locator('.ma-fb-panel').count()==0 and 'mais breve' in row.locator('.ma-fb-ok').inner_text() and down.get_attribute('aria-pressed')=='true')
    me=R.get('/api/me/inteligencia').json()
    check('preferência de tamanho salva só para este usuário', me['estilo']['tamanho']=='curto', me)
    pg.reload(); pg.wait_for_selector('.msg-swipe .ma-fb',timeout=10000); pg.wait_for_timeout(800)
    check('estado da avaliação volta depois de recarregar', pg.locator(f'.msg-swipe[data-mid="{mid}"] [data-fb="-1"]').get_attribute('aria-pressed')=='true')
    enviar('xqz-n2-afirma mais uma coisa')
    antes=pg.locator('.msg-swipe:has(.msg-bubble.glass)').count()
    enviar('analise o faturamento da loja e monte uma estratégia de vendas para dezembro')
    pg.wait_for_timeout(1500); corpo=pg.inner_text('.chat-scroll')
    check('Fase 4: pedido complexo recebe UMA resposta, sem citar agentes internos', pg.locator('.msg-swipe:has(.msg-bubble.glass)').count()==antes+1 and 'AGENTE:' not in corpo and 'especialista interno' not in corpo.lower())
    check('o chat continua enviando normalmente', pg.locator('.msg-swipe:has(.ma-fb)').count()>=2)
    ov=pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
    check('chat sem rolagem horizontal em 430px', ov['sw']<=ov['cw']+1, ov)
    # painel do administrador
    def painel():
        pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Cérebro e busca').click(); pg.wait_for_selector('#n2_box [data-n2sw]',timeout=10000)
    painel(); box=pg.inner_text('#n2_box')
    check('quadro do Nível 2 com status, indicadores e oportunidade', 'Núcleo de inteligência' in box and 'Ligado' in box and 'Avaliações positivas' in box and 'Longa demais' in box and 'podia ser mais direto' in box, box[:500])
    check('onze chaves (geral + 10 capacidades)', pg.locator('#n2_box [data-n2sw]').count()==11)
    pg.locator('#n2_bat').click(); pg.wait_for_timeout(1500)
    check('rodar bateria pelo painel', 'aprovados' in pg.inner_text('#n2_box') and R.get('/api/panel/inteligencia').json()['indicadores']['bateria']['ok'] is True)
    pg.locator('#n2_diag').click(); pg.wait_for_timeout(1800)
    f3=pg.inner_text('#n2_f3')
    check('Fase 3: diagnóstico e desempenho no painel', 'Diagnóstico do núcleo' in f3 and '100%' in f3 and 'casos novos 100%' in f3 and 'Consultas por mensagem' in f3 and 'Resposta com IA' in f3, f3[:300])
    ma=pg.inner_text('#ma_box')
    check('Fase 4: coordenação multiagente no painel (5 agentes + 3 etapas do fluxo)', 'Multiagente' in ma and pg.locator('#ma_box [data-maag]').count()==5 and pg.locator('#ma_box [data-masw]').count()==1 and 'Execução de tarefas' in ma and 'Auditoria e verificação' in ma and 'complexas' in ma, ma[:300])
    pg.locator('#ma_box [data-maag=escrita]').click(); pg.wait_for_timeout(1300)
    check('desligar um agente grava no servidor', R.get('/api/panel/inteligencia').json()['multiagente']['config']['agentes']['escrita'] is False)
    pg.locator('#ma_box [data-maag=escrita]').click(); pg.wait_for_timeout(1300)
    pg.select_option('#ma_max','2'); pg.wait_for_timeout(1300)
    check('máximo de agentes pelo painel', R.get('/api/panel/inteligencia').json()['multiagente']['config']['maxAgentes']==2 and R.get('/api/panel/inteligencia').json()['multiagente']['config']['agentes']['escrita'] is True)
    pg.select_option('#ma_max','3'); pg.wait_for_timeout(1000)
    pg.locator('#n2_box [data-n2sw=proatividade]').click(); pg.wait_for_timeout(1200)
    check('desligar uma capacidade grava no servidor', R.get('/api/panel/inteligencia').json()['config']['proatividade'] is False and pg.locator('#n2_box [data-n2sw=proatividade]').get_attribute('aria-checked')=='false')
    pg.locator('#n2_box [data-n2sw=proatividade]').click(); pg.wait_for_timeout(1200)
    check('religar', R.get('/api/panel/inteligencia').json()['config']['proatividade'] is True)
    pg.locator('#n2_box [data-oplab="0"]').click(); pg.wait_for_timeout(1500)
    check('oportunidade enviada ao Laboratório sai da fila', len(R.get('/api/panel/inteligencia').json()['oportunidades'])==0 and 'Nenhuma avaliação negativa pendente' in pg.inner_text('#n2_box'))
    for w,h in [(430,900),(1280,800)]:
        pg.set_viewport_size({'width':w,'height':h}); painel(); pg.wait_for_timeout(400)
        ov=pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,bx:document.querySelector('#n2_box').scrollWidth,bc:document.querySelector('#n2_box').clientWidth})")
        check(f'painel sem rolagem horizontal em {w}px', ov['sw']<=ov['cw']+1 and ov['bx']<=ov['bc']+1, ov)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.locator('#n2_box').screenshot(path='/tmp/e2e/n2_painel.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
