import json, sys, re, io, zipfile
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
def docx(texto):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types/>')
        z.writestr('word/document.xml','<w:document><w:body>'+''.join(f'<w:p><w:r><w:t>{l}</w:t></w:r></w:p>' for l in texto)+'</w:body></w:document>')
    return b.getvalue()
def cat(pg, nome):  # categoria: escolhe na lista (ou "Outra…" e digita), ou digita quando ainda não há lista
    if pg.locator('#pcs').count() and pg.locator('#pcs').is_visible():
        if pg.locator(f'#pcs option:text-is("{nome}")').count(): pg.select_option('#pcs', label=nome); return
        pg.select_option('#pcs', '__nova')
    pg.fill('#pc', nome)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Importa','categoria':'Pizzaria','titulo':'t','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Caneca','preco':30,'fotos':[IMG],'tipo':'produto'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('#psave',timeout=8000)
    # 1) o cadastro manual continua ali, com as duas opções
    check('opções Cadastro manual e Importar catálogo', pg.locator('[data-mim=manual]').count()==1 and 'Importar catálogo' in pg.inner_text('[data-mim=ia]'))
    check('cadastro manual visível por padrão', pg.locator('#psave').is_visible())
    # layout limpo: os três botões continuam; abaixo deles não há mais card (sem fundo/borda de caixa nem título repetido)
    semCard=lambda sel: pg.evaluate("s=>{const e=document.querySelector(s);if(!e)return null;const c=getComputedStyle(e);return !e.classList.contains('glass')&&c.borderTopWidth==='0px'&&(c.backgroundColor==='rgba(0, 0, 0, 0)'||c.backgroundColor==='transparent')}",sel)
    check('botões Cadastro manual, Importar cardápio e Histórico de importações mantidos', pg.locator('[data-mim]').count()==3 and pg.locator('[data-mim=hist]').count()==1)
    check('cadastro manual: formulário sem card abaixo dos botões', semCard('.mi-form') is True)
    pg.click('[data-mim=hist]'); pg.wait_for_timeout(800)
    check('histórico: sem card e sem título repetido; lista funciona', semCard('#mi_body') is True and pg.locator('#mi_body p:text-is("Histórico de importações")').count()==0 and 'Nenhuma importação ainda' in pg.inner_text('#mi_body'))
    pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_img',state='attached',timeout=5000)
    check('importar com IA: sem card e sem título repetido; envio continua disponível', semCard('#mi_body') is True and pg.locator('#mi_body p:text-is("Importar cardápio com IA")').count()==0 and pg.locator('#mi_go').count()==1)
    check('sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
    pg.click('[data-mim=manual]'); pg.wait_for_selector('#psave',state='visible',timeout=5000)
    pg.fill('#pn','Item manual'); pg.fill('#ppr','5'); cat(pg,'Teste')
    # 2) importar: envio de imagem ilegível → mensagem de erro clara + retomada
    pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_img',state='attached',timeout=5000)
    check('formulário manual escondido durante a importação', not pg.locator('#psave').is_visible())
    check('três formas: câmera, galeria e documentos', pg.locator('#mi_cam').count()==1 and pg.locator('#mi_img').count()==1 and pg.locator('#mi_doc').count()==1 and pg.get_attribute('#mi_cam','capture')=='environment')
    jpg=bytes([0xff,0xd8,0xff,0xe0])+b'JFIF-----foto-borrada'
    pg.set_input_files('#mi_img',{'name':'foto.jpg','mimeType':'image/jpeg','buffer':jpg}); pg.wait_for_timeout(300)
    check('arquivo aparece na lista e libera o botão', 'foto.jpg' in pg.inner_text('#mi_files') and pg.locator('#mi_go').is_enabled())
    pg.click('#mi_go'); pg.wait_for_selector('#mi_rt',timeout=30000)
    check('imagem ilegível: erro claro e botões de retomar/enviar outro', 'Não consegui ler' in pg.inner_text('#mi_body') or 'Não foi possível' in pg.inner_text('#mi_body'), pg.inner_text('#mi_body')[:200])
    # 3) DOCX (leitura por texto) → progresso → revisão
    pg.click('#mi_nw'); pg.wait_for_selector('#mi_doc',state='attached')
    arq=docx(['CARDAPIO','Pizza Calabresa media 45 grande 56','Coca-Cola 2L 12','X-Bacon 28 (bacon extra +4)','Brigadeiro (preco borrado)','Caneca 32'])
    pg.set_input_files('#mi_doc',{'name':'cardapio.docx','mimeType':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','buffer':arq}); pg.click('#mi_go')
    pg.wait_for_selector('#mi_pub',timeout=40000)
    corpo=pg.inner_text('#mi_body')
    check('tela de revisão por categorias', all(c in corpo.upper() for c in ['PIZZAS','BEBIDAS','HAMBÚRGUERES','SOBREMESAS']), corpo[:300])
    pg.locator('#mi_body').screenshot(path='/tmp/e2e/importar_revisao.png')
    check('nada foi cadastrado antes da confirmação', len(R.get(f'/api/v2/ads/{ID}/products').json()['items'])==1)
    check('descrição sugerida pela IA é identificada como tal', 'sugerida pela IA' in corpo and 'original do catálogo' in corpo)
    check('item duvidoso destacado e desmarcado', 'Conferi este item' in corpo and pg.locator('.mi-item.mi-rev').count()>=1 and not pg.locator('.mi-item:has(input[data-f=nome][value="Brigadeiro"]) [data-f=selecionado]').is_checked())
    check('indicador de confiança', 'Confiança Alta' in corpo and 'Confiança Baixa' in corpo)
    check('duplicidade com produto existente oferece 3 opções', 'Possível duplicidade' in corpo and pg.locator('[data-acao]').count()==3 and 'Atualizar o existente' in corpo and 'Cadastrar como novo' in corpo)
    check('por padrão mantém o existente', pg.locator('[data-acao=manter]').is_checked())
    # edição: preço e descrição de um item
    it=pg.locator('.mi-item:has(input[data-f=nome][value="Coca-Cola 2L"])'); it.locator('[data-f=preco]').fill('13,50'); it.locator('[data-f=desc]').fill('Refrigerante 2 litros gelado'); pg.wait_for_timeout(1300)
    # excluir X-Bacon? mantém. Seleção: filtro "só revisão"
    pg.click('#mi_flt'); check('filtro mostra só o que precisa de revisão', pg.locator('.mi-item').count()==1); pg.click('#mi_flt')
    pg.click('#mi_none'); check('limpar seleção', pg.locator('[data-f=selecionado]:checked').count()==0); pg.click('#mi_all')
    check('selecionar todos não seleciona o que exige conferência', pg.locator('.mi-item:has(input[data-f=nome][value="Brigadeiro"]) [data-f=selecionado]').is_checked()==False)
    pg.locator('.mi-item:has(input[data-f=nome][value="Brigadeiro"]) [data-f=preco]').fill('7'); pg.locator('.mi-item:has(input[data-f=nome][value="Brigadeiro"]) [data-f=confirmado]').check(); pg.wait_for_timeout(500)
    check('rascunho foi salvo no servidor', True)
    pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver',timeout=20000)
    check('mensagem de sucesso', 'Importação concluída com sucesso!' in pg.inner_text('#mi_body'))
    prods=R.get(f'/api/v2/ads/{ID}/products').json()['items']; nm={x['nome']:x for x in prods}
    check('produtos cadastrados com origem registrada', {'Pizza Calabresa','Coca-Cola 2L','X-Bacon','Brigadeiro'}<=set(nm) and nm['Coca-Cola 2L']['origem']['fonte']=='importacao_cardapio', list(nm))
    check('edições da revisão aplicadas', nm['Coca-Cola 2L']['preco']==13.5 and nm['Coca-Cola 2L']['descricao']=='Refrigerante 2 litros gelado' and nm['Brigadeiro']['preco']==7)
    check('Caneca existente foi mantida (sem sobrescrever)', nm['Caneca']['preco']==30 and len(nm['Caneca']['fotos'])==1 and sum(1 for x in prods if x['nome']=='Caneca')==1)
    check('variações e adicionais registrados', len(nm['Pizza Calabresa']['variacoes'][0]['opcoes'])==2 and nm['X-Bacon']['variacoes'][0]['nome']=='Adicionais')
    # 4) histórico
    pg.click('[data-mim=hist]'); pg.wait_for_selector('[data-hv]',timeout=8000)
    h=pg.inner_text('#mi_body'); check('histórico lista a importação com contagens e arquivo', 'cardapio.docx' in h and 'Concluída' in h and 'cadastrado(s)' in h and 'Admin Teste' in h, h[:300])
    check('histórico também mostra a tentativa que falhou', 'Falhou' in h)
    # 5) desfazer
    pg.locator('[data-hu]').first.click(); pg.wait_for_timeout(1500)
    after=R.get(f'/api/v2/ads/{ID}/products').json()['items']; check('desfazer remove só o que a importação criou', [x['nome'] for x in after]==['Caneca'], [x['nome'] for x in after])
    # 6) manual continua funcionando pelo mesmo formulário
    pg.click('[data-mim=manual]'); pg.wait_for_selector('#psave',state='visible'); check('formulário manual volta com os dados digitados', pg.input_value('#pn')=='Item manual')
    pg.set_input_files('#pf',{'name':'f.png','mimeType':'image/png','buffer':__import__('base64').b64decode(IMG.split(',')[1])}); pg.wait_for_timeout(600); pg.click('#psave'); pg.wait_for_timeout(1500)
    check('cadastro manual salvo normalmente', any(x['nome']=='Item manual' for x in R.get(f'/api/v2/ads/{ID}/products').json()['items']))
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/importar_cardapio.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
