# Incentivos do carrinho, de ponta a ponta pela tela:
# • painel da empresa (Sua empresa → Ajustes → Incentivos do carrinho): criar pelo formulário (prévia da mensagem), listar,
#   pausar/reativar;
# • vitrine: faixa compacta acima de "Ver pedido" com a mensagem e a barra de progresso, atualizando a cada produto;
# • carrinho: foto de cada produto, faixa de progresso, aumentar/diminuir/remover recalculando na hora; frete grátis
#   desbloqueado (entrega riscada, "Grátis"); na retirada, o desconto de 10%; total e botão de enviar recalculados;
# • pedido enviado: o servidor aplica o mesmo benefício (total e incentivo gravados); Meus pedidos e o painel mostram;
# • celular (390 px) e computador, sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4340 SQLITE_FILE=/tmp/ma-inc.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, re, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4340'; DBF = '/tmp/ma-inc.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Cida', 'whatsapp': '+55 85 94444-7171', 'email': 'cida.inc@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Empório da Cida', 'categoria': 'Mercearia', 'titulo': 'x', 'texto': 'Cafés e doces', 'zap': '85988887777', 'endereco': 'Rua A, 1, Centro, Fortaleza - CE'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', lat=-3.73, lng=-38.52 where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': True, 'taxa': 8, 'raio': 50}}).ok
    P1 = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Café especial', 'preco': 20, 'categoria': 'Cafés', 'fotos': [durl((120, 70, 40))]}).json()['items'][0]['id']
    P2 = [x for x in R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Pão de mel', 'preco': 12, 'categoria': 'Doces', 'fotos': [durl((200, 140, 60))]}).json()['items'] if x['nome'] == 'Pão de mel'][0]['id']
    # ---- painel: criar pelo formulário
    print('== painel da empresa')
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
    pg.goto(f'/x/sua-empresa'); pg.wait_for_timeout(2500)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
    def abrir_painel():
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav', timeout=20000); pg.locator('.ma-nav [data-nav="mais"], .ma-nav button:has-text("Ajustes"), .ma-nav a:has-text("Ajustes")').first.click(); pg.wait_for_selector('[data-lt2="incentivos"]', timeout=15000)
    abrir_painel()
    check('Ajustes tem "Incentivos do carrinho"', 'Frete grátis, descontos e cashback' in N(pg.inner_text('[data-lt2="incentivos"]')))
    pg.click('[data-lt2="incentivos"]'); pg.wait_for_selector('#inc_new', timeout=15000)
    check('painel vazio explica o recurso', pg.locator('[data-inc-vazio]').count() == 1)
    pg.click('#inc_new'); pg.wait_for_selector('[data-inc-form]')
    pg.fill('#if_nome', 'Frete grátis acima de R$ 50'); pg.fill('#if_meta', '50')
    check('formulário: prévia da mensagem que o cliente verá', 'Faltam R$ 15,00 para ganhar frete grátis.' in N(pg.inner_text('#if_prev')), pg.inner_text('#if_prev'))
    pg.click('[data-bn="desconto_pct"]'); check('benefício em %: campo de desconto aparece', pg.is_visible('#if_val'))
    pg.click('[data-bn="frete_gratis"]'); check('frete grátis: sem campo de valor', not pg.is_visible('#if_val'))
    pg.screenshot(path='/tmp/e2e/incentivo_form.png')
    pg.click('#if_ok'); pg.wait_for_selector('[data-inc]', timeout=10000)
    check('incentivo criado e em vigor', 'Frete grátis acima de R$ 50' in N(pg.inner_text('[data-inc]')) and 'Em vigor' in N(pg.inner_text('[data-inc]')))
    assert R.post(f'/api/v2/ads/{ID}/incentivos', data={'nome': '10% levando 3', 'metaTipo': 'itens', 'meta': 3, 'beneficio': 'desconto_pct', 'valor': 10}).ok
    abrir_painel(); pg.click('[data-lt2="incentivos"]'); pg.wait_for_selector('[data-inc]', timeout=15000)
    pg.locator('[data-inc]', has_text='10% levando 3').locator('[data-a="st"]').click(); pg.wait_for_timeout(1200)
    check('pausar pelo painel', 'Pausado' in N(pg.locator('[data-inc]', has_text='10% levando 3').inner_text()))
    pg.locator('[data-inc]', has_text='10% levando 3').locator('[data-a="st"]').click(); pg.wait_for_timeout(1200)
    check('reativar pelo painel', 'Em vigor' in N(pg.locator('[data-inc]', has_text='10% levando 3').inner_text()))
    pg.screenshot(path='/tmp/e2e/incentivo_painel.png', full_page=True)
    for nome, vp, mob, k in [('celular 390', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Rui Cliente', 'whatsapp': f'+55 85 95555-02{k}{k}', 'email': f'rui{k}.inc@t.com', **U}, headers={'X-Forwarded-For': f'10.8.7.{k}'}).ok
        assert C.request.put('/api/v2/me/location', data={'lat': -3.731, 'lng': -38.521}).ok
        pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
        pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector(f'[data-add="{P1}"]', timeout=20000); pc.wait_for_timeout(600)
        faixa = lambda: N(pc.inner_text('.ma-inc-c')) if pc.locator('.ma-inc-c').count() else ''
        pc.click(f'[data-add="{P1}"]'); pc.wait_for_timeout(500)
        check(f'{nome}: vitrine mostra quanto falta (1 item)', faixa() == 'Faltam R$ 30,00 para ganhar frete grátis.', faixa())
        pc.click(f'[data-add="{P2}"]'); pc.wait_for_timeout(500)
        check(f'{nome}: atualiza ao adicionar (2 itens, R$ 32)', faixa() in ('Adicione mais 1 produto e ganhe 10% de desconto.', 'Faltam R$ 18,00 para ganhar frete grátis.'), faixa())
        w = pc.evaluate("()=>{const b=document.querySelector('.ma-inc-c [role=progressbar]');return b?+b.getAttribute('aria-valuenow'):-1}")
        check(f'{nome}: barra de progresso na vitrine', w > 0 and w < 100, w)
        if k == 1: pc.screenshot(path='/tmp/e2e/incentivo_vitrine.png')
        # carrinho
        pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
        imgs = pc.locator('[data-checkout] img[data-cart-img]')
        check(f'{nome}: carrinho com a foto de cada produto', imgs.count() == 2 and all((imgs.nth(j).get_attribute('src') or '').startswith('data:image/png') for j in range(2)) and pc.evaluate("()=>[...document.querySelectorAll('[data-checkout] img[data-cart-img]')].every(i=>i.complete&&i.naturalWidth>0)"))
        ban = lambda: N(pc.inner_text('[data-checkout] [data-incentivo]')) if pc.locator('[data-checkout] [data-incentivo]').count() else ''
        check(f'{nome}: faixa de progresso no carrinho', 'Adicione mais 1 produto e ganhe 10% de desconto.' in ban() or 'Faltam R$ 18,00 para ganhar frete grátis.' in ban(), ban())
        total = lambda: N(pc.inner_text('[data-co-total]'))
        # aumentar o café: 2×20 + 12 = 52 → frete grátis (R$ 8) vale mais que 10% (R$ 5,20)
        pc.locator('[data-cart-item]', has_text='Café especial').locator('[data-cq="1"]').click(); pc.wait_for_timeout(700)
        check(f'{nome}: ao aumentar, desbloqueia frete grátis', 'Você ganhou frete grátis!' in ban(), ban())
        fr = N(pc.inner_text('[data-inc-frete]')) if pc.locator('[data-inc-frete]').count() else ''
        check(f'{nome}: entrega riscada e "Grátis"; total sem frete', 'R$ 8,00' in fr and 'Grátis' in fr and total() == 'R$ 52,00' and 'R$ 52,00' in N(pc.inner_text('#cgo')), (fr, total()))
        check(f'{nome}: opção de entrega mostra "grátis"', 'grátis' in N(pc.inner_text('[data-mo="entrega"]')), N(pc.inner_text('[data-mo="entrega"]')))
        if k == 1: pc.locator('[data-checkout] [data-incentivo]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/incentivo_carrinho.png')
        # retirada: frete não se aplica → vale o 10% (R$ 5,20)
        pc.click('[data-mo="retirada"]'); pc.wait_for_timeout(600)
        check(f'{nome}: na retirada vale o 10% de desconto', 'Você ganhou 10% de desconto!' in ban() and 'R$ 5,20' in N(pc.inner_text('[data-inc-linha]')) and total() == 'R$ 46,80', (ban(), total()))
        pc.click('[data-mo="entrega"]'); pc.wait_for_timeout(600)
        # diminuir: volta ao progresso
        pc.locator('[data-cart-item]', has_text='Café especial').locator('[data-cq="-1"]').click(); pc.wait_for_timeout(700)
        check(f'{nome}: ao diminuir, volta a mostrar quanto falta', 'Ganhou' not in ban() and ('Faltam R$ 18,00 para ganhar frete grátis.' in ban() or 'Adicione mais 1 produto e ganhe 10% de desconto.' in ban()) and total() == 'R$ 40,00', (ban(), total()))
        check(f'{nome}: a faixa da vitrine acompanha o carrinho', pc.locator('.ma-inc-c').count() == 1)
        # remover e adicionar de novo: 1 pão + 2 cafés
        pc.locator('[data-cart-item]', has_text='Café especial').locator('[data-cq="1"]').click(); pc.wait_for_timeout(700)
        check(f'{nome}: sem rolagem lateral no carrinho', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        # enviar o pedido (entrega)
        for f, v in [('rua', 'Rua das Flores'), ('numero', '10'), ('bairro', 'Centro')]: pc.fill(f'[data-ent={f}]', v)
        pc.fill('#czap', f'8595555020{k}'); pc.click('#cgo'); pc.wait_for_timeout(2500)
        o = C.request.get('/api/v2/orders/mine').json()['items'][0]
        check(f'{nome}: o servidor aplicou o mesmo benefício (frete grátis, total R$ 52)', o['total'] == 52 and o.get('taxa') == 0 and (o.get('incentivo') or {}).get('freteGratis') and o['incentivo']['taxaOriginal'] == 8, {k2: o.get(k2) for k2 in ('total', 'taxa', 'incentivo')})
        pc.wait_for_selector('[data-ped-incentivo]', timeout=15000)
        check(f'{nome}: Meus pedidos mostra o incentivo', 'Frete grátis · Frete grátis acima de R$ 50' in N(pc.inner_text('[data-ped-incentivo]')), N(pc.inner_text('[data-ped-incentivo]')))
        C.close()
    # painel da loja: o pedido mostra o incentivo e o resultado aparece no painel
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000); pg.click('.ma-nav [data-nav=pedidos]')
    oid = R.get(f'/api/v2/ads/{ID}/orders').json()['items'][0]['id']; pg.wait_for_selector(f'[data-odet="{oid}"]', timeout=15000); pg.click(f'[data-odet="{oid}"]'); pg.wait_for_selector(f'[data-pedido-det="{oid}"]')
    check('painel: pedido mostra "Incentivo · ... Frete grátis"', 'Incentivo · Frete grátis acima de R$ 50' in N(pg.inner_text(f'[data-pedido-det="{oid}"]')), N(pg.inner_text(f'[data-pedido-det="{oid}"]'))[:300])
    res_ = R.get(f'/api/v2/ads/{ID}/incentivos').json()['itens']; fg = [x for x in res_ if x['beneficio'] == 'frete_gratis'][0]
    check('painel: resultados contam os pedidos com incentivo', fg['resultados']['pedidos'] == 2 and fg['resultados']['desconto'] == 16, fg['resultados'])
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
