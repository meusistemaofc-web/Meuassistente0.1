# Página de Links: modelos de fundo prontos (prévia em miniatura, aplicar com um clique, filtros por estilo) e formato dos botões.
# Confere na prévia em tempo real e na página pública publicada: fundo, cor do texto (claro/escuro), raio dos botões; a
# personalização manual continua (fundo manual tira o modelo); outra empresa não é afetada. Celular (390 px) e computador.
# Servidor: PORT=4332 SQLITE_FILE=/tmp/ma-lkf.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4332'; DBF = '/tmp/ma-lkf.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
iso = lambda d: (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=d)).isoformat().replace('+00:00', 'Z')
# estado visual da página (prévia ou pública): fundo do body, tema claro/escuro, raio do 1º e 2º botão
VIS = """()=>{const bt=[...document.querySelectorAll('.ma-pc')].map(a=>getComputedStyle(a).borderTopLeftRadius+'|'+getComputedStyle(a).borderTopRightRadius);
 return {bg:getComputedStyle(document.body).backgroundImage+' '+getComputedStyle(document.body).backgroundColor,fundo:document.body.dataset.fundo||'',tema:document.documentElement.getAttribute('data-theme'),cls:document.getElementById('app').className,bt,ink:getComputedStyle(document.querySelector('.ma-emp-nm')||document.body).color}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    RA.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    db = sqlite3.connect(DBF)
    def dono(nome, email, ip, empresa, vp, mob):
        c = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': nome, 'whatsapp': '+55 11 95555-0' + ip, 'email': email, **U}, headers={'X-Forwarded-For': '10.8.9.' + ip}).ok
        i = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': 'Doceria', 'titulo': 'Doces', 'texto': 'Doces artesanais', 'zap': '5511999990000'}).json()['items'][0]['id']
        d = json.loads(db.execute('select data from businesses where id=?', (i,)).fetchone()[0]); d['tema'] = {'preset': 'padrao', 'cor': '#3b6cff', 'fundo': 'escuro', 'layout': 'lista', 'cantos': 'arredondado'}; d['aprovadoEm'] = iso(0)
        db.execute("update businesses set status='ativo', expires_at=?, data=? where id=?", (iso(30), json.dumps(d), i)); db.commit(); return c, R, i
    V, RV, IDV = dono('Dona Vizinha', 'viz@t.com', '150', 'Loja Vizinha', {'width': 390, 'height': 844}, True)
    RV.post(f'/api/v2/ads/{IDV}/links', data={'action': 'publicar', 'conteudo': RV.get(f'/api/v2/ads/{IDV}/links').json()['rascunho']})
    slugV = RV.get(f'/api/v2/ads/{IDV}/links').json()['base']['slug']
    for nome, vp, mob, ip in [('celular 390', {'width': 390, 'height': 844}, True, '151'), ('computador', {'width': 1280, 'height': 900}, False, '152')]:
        print('==', nome); k = nome.replace(' ', '')
        D, RD, ID = dono('Dona Flor ' + k, f'flor.{k}@t.com', ip, f'Doceria Flor {k}', vp, mob)
        RD.post(f'/api/v2/ads/{ID}/links', data={'action': 'publicar', 'conteudo': {**RD.get(f'/api/v2/ads/{ID}/links').json()['rascunho']}})
        slug = RD.get(f'/api/v2/ads/{ID}/links').json()['base']['slug']
        pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(3000)
        if not pg.locator('[data-lt2="links"]').count(): pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1200)
        pg.locator('[data-lt2="links"]').click(); pg.wait_for_selector('[data-lk-fundos]', timeout=15000); pg.wait_for_timeout(800)
        F = pg.locator('[data-lk-fundos]')
        tiles = F.locator('[data-fundo]').count()
        check(f'{nome}: seção "Fundo da página" com modelos prontos (+ Personalizado selecionado por padrão)', tiles >= 21 and F.locator('[data-fundo=""]').get_attribute('aria-checked') == 'true', tiles)
        chips = [x.inner_text() for x in F.locator('[data-fgrp]').all()]
        check(f'{nome}: filtros Modernos, Minimalistas, Degradês, Texturas e Elegantes', chips == ['Todos', 'Modernos', 'Minimalistas', 'Degradês', 'Texturas', 'Elegantes'], chips)
        F.locator('[data-fgrp="Texturas"]').click(); pg.wait_for_timeout(200); F = pg.locator('[data-lk-fundos]')
        check(f'{nome}: filtro Texturas mostra só as texturas', sorted(x.get_attribute('data-fundo') for x in F.locator('[data-fundo]').all()) == ['linho', 'listras', 'pontos', 'quadriculado'])
        mini = pg.evaluate("()=>getComputedStyle(document.querySelector('[data-fundo=pontos] > span')).backgroundImage")
        check(f'{nome}: miniatura mostra o próprio fundo (prévia do modelo)', 'radial-gradient' in mini, mini[:80])
        pg.locator('[data-fgrp=""]').click(); pg.wait_for_timeout(200)
        # prévia em tempo real (iframe): no computador fica ao lado; no celular, aba Prévia
        fr = pg.frame_locator('[data-lk-frame]')
        def previa():
            if mob: pg.click('[data-lk-aba="previa"]'); pg.wait_for_timeout(450)
            v = pg.frame(url=lambda u: 'previa=1' in u).evaluate(VIS)
            if mob: pg.click('[data-lk-aba="editar"]'); pg.wait_for_timeout(250)
            return v
        v0 = previa()
        check(f'{nome}: prévia começa sem modelo e com botões no formato atual', v0['fundo'] == '' and v0['tema'] == 'dark' and 'bf-' not in v0['cls'] and v0['bt'][0].startswith('21.6px'), v0)
        pg.locator('[data-fundo="marmore"]').click(); pg.wait_for_timeout(300)
        v1 = previa()
        check(f'{nome}: um clique em "Mármore" aplica na prévia (fundo claro, texto escuro)', v1['fundo'] == 'marmore' and 'linear-gradient' in v1['bg'] and v1['tema'] == 'light' and v1['ink'] in ('rgb(23, 23, 27)',), v1)
        check(f'{nome}: modelo marcado e aviso de modelo aplicado', pg.locator('[data-fundo="marmore"]').get_attribute('aria-checked') == 'true' and 'Mármore' in pg.inner_text('[data-lk-fundo-at]'))
        sh = [x.inner_text().strip() for x in pg.locator('[data-bforma]').all()]
        check(f'{nome}: formatos dos botões (Quadrado, Cantos suaves, Arredondado, Pílula, Folha) com o atual marcado', sh == ['Quadrado', 'Cantos suaves', 'Arredondado', 'Pílula', 'Folha'] and pg.locator('[data-bforma="arredondado"]').get_attribute('aria-checked') == 'true', sh)
        for forma, raio in [('quadrado', '0px|0px'), ('pilula', None), ('folha', '24px|5.6px')]:
            pg.locator(f'[data-bforma="{forma}"]').click(); pg.wait_for_timeout(250); vf = previa()
            ok = ('bf-' + forma) in vf['cls'] and (vf['bt'][0] == raio if raio else float(vf['bt'][0].split('px')[0]) >= 30)
            check(f'{nome}: "{forma}" muda os botões na prévia na hora', ok, vf['bt'])
        if mob: pg.click('[data-lk-aba="editar"]')
        pg.locator('[data-lk-fundos]').scroll_into_view_if_needed(); pg.screenshot(path=f'/tmp/e2e/lkf_editor_{k}.png')
        check(f'{nome}: editor sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        # nada da galeria fica cortado: todas as miniaturas cabem dentro do cartão (só a fileira de filtros rola)
        cort = pg.evaluate("()=>{const c=document.querySelector('[data-lk-fundos]').getBoundingClientRect();return [...document.querySelectorAll('[data-lk-fundos] [data-fundo],[data-bforma]')].filter(t=>{const r=t.getBoundingClientRect();return r.right>c.right+1||r.right>innerWidth+1}).length}")
        check(f'{nome}: miniaturas e formatos inteiros dentro da tela', cort == 0, cort)
        # página pública só muda depois de publicar
        P = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob).new_page(); P.on('pageerror', lambda e: errs.append(str(e)))
        P.goto(f'/{slug}/links'); P.wait_for_selector('.ma-pc', timeout=15000); P.wait_for_timeout(300)
        check(f'{nome}: antes de publicar a página pública continua igual', P.evaluate(VIS)['fundo'] == '')
        pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
        P.reload(); P.wait_for_selector('.ma-pc', timeout=15000); P.wait_for_timeout(300); vp1 = P.evaluate(VIS)
        check(f'{nome}: publicada com Mármore e botões em folha', vp1['fundo'] == 'marmore' and vp1['tema'] == 'light' and 'bf-folha' in vp1['cls'] and vp1['bt'][0] == '24px|5.6px', vp1)
        check(f'{nome}: página pública sem rolagem lateral', P.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        P.screenshot(path=f'/tmp/e2e/lkf_publica_{k}.png', full_page=True)
        # modelo escuro "Preto e dourado" + pílula
        pg.locator('[data-fundo="dourado"]').click(); pg.locator('[data-bforma="pilula"]').click(); pg.wait_for_timeout(200); pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
        P.reload(); P.wait_for_selector('.ma-pc'); P.wait_for_timeout(300); vp2 = P.evaluate(VIS)
        check(f'{nome}: trocar para um modelo escuro (texto claro) e pílula', vp2['fundo'] == 'dourado' and vp2['tema'] == 'dark' and 'bf-pilula' in vp2['cls'], vp2)
        if k == 'celular390': P.screenshot(path='/tmp/e2e/lkf_publica_dourado.png', full_page=True)
        # personalização manual continua: cores próprias + fundo "Claro" tira o modelo
        pg.click('[data-sw="lk_tema"]'); pg.wait_for_timeout(300); pg.locator('[data-fd="claro"]').click(); pg.wait_for_timeout(300)
        check(f'{nome}: escolher um fundo manual tira o modelo (volta para Personalizado)', pg.locator('[data-fundo=""]').get_attribute('aria-checked') == 'true' and pg.locator('[data-lk-fundo-at]').count() == 0)
        pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
        P.reload(); P.wait_for_selector('.ma-pc'); P.wait_for_timeout(300); vp3 = P.evaluate(VIS)
        check(f'{nome}: publicada com o fundo manual (claro) e o formato mantido', vp3['fundo'] == '' and vp3['tema'] == 'light' and 'gradient' not in vp3['bg'] and 'bf-pilula' in vp3['cls'], vp3)
        sv = RD.get(f'/api/v2/ads/{ID}/links').json()['rascunho']
        check(f'{nome}: preferências salvas na empresa', sv['fundoModelo'] == '' and sv['botaoForma'] == 'pilula' and sv['temaProprio'] is True and sv['tema']['fundo'] == 'claro', sv)
        D.close()
    print('== isolamento')
    P = b.new_context(base_url=BASE).new_page(); P.goto(f'/{slugV}/links'); P.wait_for_selector('.ma-pc'); vv = P.evaluate(VIS)
    check('a outra empresa continua sem modelo e com os botões de antes', vv['fundo'] == '' and 'bf-' not in vv['cls'] and RV.get(f'/api/v2/ads/{IDV}/links').json()['rascunho']['fundoModelo'] == '', vv)
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
