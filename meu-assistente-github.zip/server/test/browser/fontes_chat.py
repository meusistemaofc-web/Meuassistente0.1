# Fontes nas respostas do chat: o corpo da mensagem não mostra URLs, domínios nem "Fonte:"; no fim da resposta, um
# rodapé discreto "Fontes" com os ícones (favicons) à direita do título, clicáveis, abrindo a página original em nova aba.
# Formatação leve das respostas: títulos, listas e negrito desenhados (sem símbolos ** ou ## à mostra).
# Sem favicon (ou sem internet), aparece a inicial do site. Várias fontes → vários ícones (máx. 4), sem poluir.
# Mensagem sem fontes continua igual. Celular (390 px) e computador.
# Servidor: PORT=4345 SQLITE_FILE=/tmp/ma-fontes.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, uuid
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4345'; DBF = '/tmp/ma-fontes.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
MARC = ' ⟦src:pt.wikipedia.org~https://pt.wikipedia.org/wiki/Santos_Dumont|bcb.gov.br~https://www.bcb.gov.br/controleinflacao/taxaselic⟧'
MD = '## Como economizar\nAlgumas ideias **práticas** para o mês:\n\n- Anote os gastos fixos\n- Corte assinaturas que você não usa\n1. Defina um teto semanal\n2. Revise no domingo\n\nUse `planilha` se preferir.'
TEXTO = 'Alberto Santos Dumont foi um aeronauta e inventor brasileiro. Ele pilotou o 14-bis em 1906, em Paris.'
GEO = """()=>{const bs=[...document.querySelectorAll('.chat-scroll .msg-bubble')];const b=bs.find(x=>x.innerText.includes('14-bis'));if(!b)return null;
 const ps=[...b.children].filter(e=>e.tagName==='P'),hora=ps[ps.length-1],src=b.querySelector('.ma-src'),r=e=>{const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,w:x.width,h:x.height}};
 return {texto:ps[0].innerText,hora:r(hora),horaTxt:hora.innerText,bolha:r(b),src:src?r(src):null,antesDaHora:!!src&&src.nextElementSibling===hora,
  rot:src&&src.querySelector('.ma-src-t')?r(src.querySelector('.ma-src-t')):null,rotTxt:src&&src.querySelector('.ma-src-t')?src.querySelector('.ma-src-t').innerText:'',borda:src?getComputedStyle(src).borderTopWidth:'',
  links:src?[...src.querySelectorAll('a')].map(a=>({href:a.href,alvo:a.target,rel:a.rel,rot:a.getAttribute('aria-label'),txt:a.innerText,img:!!a.querySelector('img'),...r(a)})):[],
  outras:bs.filter(x=>x!==b).map(x=>!!x.querySelector('.ma-src')),sw:document.documentElement.scrollWidth,vw:innerWidth}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Rita Fontes', 'whatsapp': '+55 11 94444-6060', 'email': 'rita@t.com', **U}).ok
    conv = str(uuid.uuid4())
    for t in ['Olá!', 'Quem foi Santos Dumont?']: assert R.post('/api/chat', data={'text': t, 'conversationId': conv}).ok
    db = sqlite3.connect(DBF)
    mid = db.execute("select id from messages where conversation_id=? and role='assistant' order by id desc limit 1", (conv,)).fetchone()[0]
    db.execute('update messages set content=? where id=?', (TEXTO + MARC, mid))
    mid0 = db.execute("select id from messages where conversation_id=? and role='assistant' order by id asc limit 1", (conv,)).fetchone()[0]
    db.execute('update messages set content=? where id=?', (MD, mid0)); db.commit(); db.close()
    st = D.storage_state()
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 860}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, storage_state=st, is_mobile=mob, has_touch=mob, device_scale_factor=2 if mob else 1); pg = c.new_page()
        pg.on('pageerror', lambda e: errs.append(str(e)))
        c.route('https://pt.wikipedia.org/**', lambda r: r.fulfill(status=200, content_type='text/html', body='<title>Santos Dumont</title><h1>Santos Dumont</h1>'))  # sem internet no teste: simula a página original
        pg.goto(f'/?c={conv}'); pg.wait_for_selector('.chat-scroll .msg-bubble', timeout=20000); pg.wait_for_timeout(2500)
        g = pg.evaluate(GEO)
        check(f'{nome}: corpo da mensagem sem URL, domínio, "Fonte:" nem marcador', g and g['texto'] == TEXTO and 'http' not in g['texto'] and '⟦' not in g['texto'], g and g['texto'])
        check(f'{nome}: rodapé "Fontes" no fim da resposta (antes do horário), com linha discreta', g['src'] and g['antesDaHora'] and g['rotTxt'] == 'Fontes' and g['src']['b'] <= g['hora']['t'] + 1 and g['borda'] not in ('', '0px'), g)
        check(f'{nome}: dois ícones alinhados à direita do título "Fontes", na mesma linha', len(g['links']) == 2 and all(x['l'] > g['rot']['r'] for x in g['links']) and all(abs((x['t'] + x['b']) / 2 - (g['rot']['t'] + g['rot']['b']) / 2) <= 4 for x in g['links']) and g['links'][0]['r'] <= g['links'][1]['l'], (g['rot'], g['links']))
        check(f'{nome}: ícones pequenos e discretos (≤ 22 px), dentro do balão', all(x['w'] <= 22 and x['h'] <= 22 for x in g['links']) and g['src']['l'] >= g['bolha']['l'] and g['src']['r'] <= g['bolha']['r'] + 1, g['links'])
        check(f'{nome}: cada ícone abre a página original em nova aba, com rótulo acessível', [x['href'] for x in g['links']] == ['https://pt.wikipedia.org/wiki/Santos_Dumont', 'https://www.bcb.gov.br/controleinflacao/taxaselic'] and all(x['alvo'] == '_blank' and 'noopener' in x['rel'] for x in g['links']) and g['links'][0]['rot'] == 'Abrir a fonte: pt.wikipedia.org', g['links'])
        pg.wait_for_timeout(1500); g = pg.evaluate(GEO)
        check(f'{nome}: sem favicon (sem internet aqui), aparece a inicial do site', [x['txt'] for x in g['links']] == ['P', 'B'] or all(x['img'] for x in g['links']), g['links'])
        check(f'{nome}: mensagem sem fontes não ganha rodapé', not any(g['outras']), g['outras'])
        md = pg.evaluate("""()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].find(x=>x.innerText.includes('Como economizar'));if(!b)return null;const p=b.querySelector('p.ma-md');return p?{h:[...p.querySelectorAll('.ma-md-h')].map(e=>e.innerText),li:[...p.querySelectorAll('.ma-md-li')].map(e=>e.innerText.replace(/\\s+/g,' ')),strong:[...p.querySelectorAll('strong')].map(e=>e.innerText),code:[...p.querySelectorAll('code')].map(e=>e.innerText),txt:p.innerText,peso:getComputedStyle(p.querySelector('.ma-md-h')).fontWeight}:{cru:b.innerText}}""")
        check(f'{nome}: resposta formatada: título, listas, negrito e código desenhados', md and md.get('h') == ['Como economizar'] and len(md.get('li', [])) == 4 and md['li'][0] == '• Anote os gastos fixos' and md['li'][2].startswith('1.') and md.get('strong') == ['práticas'] and md.get('code') == ['planilha'] and int(md.get('peso', 400)) >= 600, md)
        check(f'{nome}: sem símbolos de formatação à mostra (**, ##, crases)', md and '**' not in md.get('txt', '') and '##' not in md.get('txt', '') and '`' not in md.get('txt', ''), md and md.get('txt'))
        check(f'{nome}: sem rolagem horizontal', g['sw'] <= g['vw'] + 1)
        with c.expect_page() as nova: pg.locator('.ma-src a').first.click()
        np_ = nova.value
        np_.wait_for_load_state()
        check(f'{nome}: tocar no ícone abre a página da fonte', 'pt.wikipedia.org/wiki/Santos_Dumont' in np_.url, np_.url); np_.close()
        pg.locator('.ma-src').first.scroll_into_view_if_needed()
        bb = pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].find(x=>x.innerText.includes('14-bis')).getBoundingClientRect();return {x:b.left,y:b.top,width:b.width,height:b.height}}")
        pg.screenshot(path=f'/tmp/e2e/fontes_{nome}.png', clip={'x': max(0, bb['x'] - 8), 'y': max(0, bb['y'] - 8), 'width': min(vp['width'] - max(0, bb['x'] - 8), bb['width'] + 16), 'height': bb['height'] + 16})
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
