import json, base64, zlib, struct, sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'  # ajuste se usar outra porta
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return 'data:image/png;base64,'+base64.b64encode(b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')).decode()
def lum(rgb):
    r,g,b=[x/255 for x in rgb]; return .2126*r+.7152*g+.0722*b
def parse(c):
    m=re.findall(r'[\d.]+',c); return [float(x) for x in m[:3]]
results=[]
def check(name,ok,detail=''):
    results.append((name,bool(ok),detail)); print(('  ✔ ' if ok else '  ✘ ')+name+(' → '+repr(detail)[:400] if not ok else ''))
TEMAS={
 'padrao':{'preset':'padrao','cor':'#3b6cff','fundo':'escuro','layout':'lista','cantos':'arredondado'},
 'elegante':{'preset':'elegante','cor':'#c9a227','fundo':'escuro','layout':'lista','cantos':'arredondado'},
 'vibrante':{'preset':'vibrante','cor':'#ff4d6d','fundo':'colorido','layout':'grade','cantos':'arredondado'},
 'natural':{'preset':'natural','cor':'#2f9e5b','fundo':'claro','layout':'grade','cantos':'arredondado'},
 'clean':{'preset':'clean','cor':'#111827','fundo':'claro','layout':'lista','cantos':'reto'},
}
with sync_playwright() as p:
    b=p.chromium.launch()
    ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE)
    R=ctx.request
    r=R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}); assert r.ok, r.text()
    r=R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}); assert r.ok, r.text()
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Restaurantes','titulo':'Pizza no forno a lenha','texto':'As melhores pizzas','zap':'5511999990000','insta':'pizzariaforno','endereco':'Rua A, 10, São Paulo','sobre':'Pizzas artesanais no forno a lenha.'}); assert r.ok, r.text()
    ad=r.json()['items'][0]; ID=ad['id']
    r=R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'entrega':{'retirada':True,'entrega':True,'taxa':5,'raio':10},'pagamento':{'pix':True,'dinheiro':True},'categorias':['Pizzas','Bebidas']}); assert r.ok, r.text()
    for nome,preco,cat,col in [('Margherita',45,'Pizzas',(200,80,60)),('Calabresa',49,'Pizzas',(180,60,40)),('Guaraná 2L',12,'Bebidas',(60,150,80))]:
        body={'nome':nome,'preco':preco,'categoria':cat,'descricao':'Massa fina, molho caseiro e queijo.','fotos':[png(320,200,col)]}
        if nome=='Margherita': body['variacoes']=[{'nome':'Tamanho','opcoes':[{'nome':'Média','preco':45},{'nome':'Grande','preco':56}]}]
        r=R.post(f'/api/v2/ads/{ID}/products',data=body); assert r.ok,r.text()
    r=R.put(f'/api/v2/ads/{ID}/agent',data={'nome':'Lia'}); assert r.ok,r.text()
    ag=R.get(f'/api/v2/ads/{ID}/agent').json(); print('agent keys',list(ag.keys())[:12])
    slug=None
    m=re.search(r'"link": "(?:https://[^/"]+)?/([a-z0-9-]+)"',json.dumps(ag)); 
    if m: slug=m.group(1)
    if not slug:
        cat=R.get(f'/api/v2/businesses/{ID}').json(); m=re.search(r'"link": "(?:https://[^/"]+)?/([a-z0-9-]+)"',json.dumps(cat)); slug=m.group(1) if m else None
    print('slug',slug, 'id',ID)
    json.dump({'id':ID,'slug':slug},open('/tmp/e2e/ids.json','w'))
    # ---------- servidor entrega o tema normalizado ----------
    for nome,t in TEMAS.items():
        R.put(f'/api/v2/ads/{ID}',data={'tema':t})
        j=R.get(f'/api/v2/businesses/{ID}').json(); a1=R.get(f'/api/v2/agent/{ID}').json(); a2=R.get(f'/api/v2/agent/{ID}/info').json(); a3=R.get(f'/api/v2/theme/{ID}').json()
        check(f'servidor [{nome}]: catálogo, agente, info e rota de tema devolvem o mesmo tema', j['tema']==t==a1['tema']==a2['tema']==a3['tema'], (j.get('tema'),a1.get('tema')))
    # tema inválido/antigo é normalizado
    R.put(f'/api/v2/ads/{ID}',data={'tema':{'cor':'vermelho','fundo':'xyz','layout':'grade'}})
    t=R.get(f'/api/v2/theme/{ID}').json()['tema']; check('tema inválido vira tema completo e válido', t=={'preset':'padrao','cor':'#3b6cff','fundo':'escuro','layout':'grade','cantos':'arredondado'}, t)
    page=ctx.new_page()
    errs=[]; page.on('pageerror',lambda e:errs.append(str(e)))
    for nome,t in TEMAS.items():
        R.put(f'/api/v2/ads/{ID}',data={'tema':t})
        light = t['fundo']=='claro'
        # ---------------- catálogo ----------------
        page.goto(f'/x/empresa/{ID}'); page.wait_for_selector('[data-prod],[data-add]',timeout=15000)
        info=page.evaluate("""()=>{const r=document.querySelector('[data-ma-themed="page"]');const cs=getComputedStyle(r);return {has:!!r,accent:cs.getPropertyValue('--nx-accent').trim(),theme:r.getAttribute('data-theme'),canvas:cs.getPropertyValue('--nx-canvas').trim(),reto:r.classList.contains('ma-reto')}}""")
        check(f'catálogo [{nome}]: página recebe a identidade (cor, modo, cantos)', info['has'] and info['accent']==t['cor'] and info['theme']==('light' if light else 'dark') and info['reto']==(t['cantos']=='reto'), info)
        page.wait_for_function("document.querySelectorAll('.ma-ico-btn').length===3",timeout=10000); page.wait_for_timeout(600); page.wait_for_function("document.querySelectorAll('.ma-ico-btn').length===3",timeout=10000)
        page.screenshot(path=f'/tmp/e2e/cat_{nome}.png')
        # ícones de contato
        ic=page.evaluate("""()=>[...document.querySelectorAll('.ma-ico-btn')].map(e=>{const r=e.getBoundingClientRect();return {label:e.getAttribute('aria-label'),href:e.getAttribute('href'),text:e.textContent.trim(),w:Math.round(r.width),h:Math.round(r.height),top:Math.round(r.top),svg:!!e.querySelector('svg')}})""")
        labs=[i['label'] for i in ic]
        check(f'catálogo [{nome}]: Localização, WhatsApp e Instagram são ícones compactos alinhados', labs==['Localização','WhatsApp','Instagram'] and all(i['text']=='' and i['svg'] and i['w']==36 and i['h']==36 for i in ic) and len({i['top'] for i in ic})==1, ic)
        hrefs={i['label']:i['href'] for i in ic}
        check(f'catálogo [{nome}]: links preservados', hrefs['WhatsApp']=='https://wa.me/5511999990000' and hrefs['Instagram']=='https://instagram.com/pizzariaforno', hrefs)
        # ---------------- janela do produto ----------------
        page.click('[data-prod]'); page.wait_for_selector('.ma-sheet-in',timeout=5000)
        sh=page.evaluate("""()=>{const s=document.querySelector('.ma-sheet-in');const w=s.closest('.ma-sheet');const cs=getComputedStyle(s);const btn=s.querySelector('.btn-send');const bcs=btn?getComputedStyle(btn):null;const inp=s.querySelector('textarea,input');return {themed:w.getAttribute('data-ma-themed'),accent:getComputedStyle(w).getPropertyValue('--nx-accent').trim(),bg:cs.backgroundColor,bgImg:cs.backgroundImage,ink:getComputedStyle(w).color,btnColor:bcs&&bcs.color,btnImg:bcs&&bcs.backgroundImage,hasBtn:!!btn,hasInp:!!inp,inpColor:inp&&getComputedStyle(inp).color,hasPhoto:!!s.querySelector('img')}}""")
        ink_rgb=parse(sh['ink']); 
        check(f'produto [{nome}]: janela herda o tema (não fica preta no tema claro)', sh['themed']=='layer' and sh['accent']==t['cor'] and ((lum(ink_rgb)<.5)==light), sh)
        # luminância do fundo real da janela
        bgc=page.evaluate("""()=>{const s=document.querySelector('.ma-sheet-in');const c=document.createElement('canvas');c.width=c.height=1;const x=c.getContext('2d');const cs=getComputedStyle(s);const v=cs.backgroundImage&&cs.backgroundImage!=='none'?cs.backgroundImage:cs.backgroundColor;return v}""")
        stops=re.findall(r'rgba?\([^)]*\)',bgc); lm=sum(lum(parse(c)) for c in stops)/max(1,len(stops))
        check(f'produto [{nome}]: fundo da janela acompanha o modo ({"claro" if light else "escuro"})', (lm>.6)==light, (bgc[:120],round(lm,2)))
        check(f'produto [{nome}]: botão de adicionar usa a cor do tema e texto legível', sh['hasBtn'] and ('rgb' in (sh['btnImg'] or '')), sh)
        page.screenshot(path=f'/tmp/e2e/prod_{nome}.png')
        page.keyboard.press('Escape'); 
        page.evaluate("()=>document.querySelector('.ma-sheet-x')&&document.querySelector('.ma-sheet-x').click()")
        # ---------------- agente ----------------
        page.goto(f'/{slug}'); page.wait_for_selector('.m.a',timeout=15000)
        page.wait_for_timeout(300)
        page.click('#acts [data-a=mais]'); page.wait_for_timeout(150)
        ag=page.evaluate("""()=>{const h=document.documentElement;const cs=getComputedStyle(h);const bubble=document.querySelector('.m.a');const bb=getComputedStyle(document.body);return {themed:h.getAttribute('data-ma-themed'),theme:h.getAttribute('data-theme'),accent:cs.getPropertyValue('--nx-accent').trim(),bodyBg:bb.backgroundColor+'|'+bb.backgroundImage.slice(0,60),text:getComputedStyle(bubble).color,reto:h.classList.contains('ma-reto'),chips:[...document.querySelectorAll('#acts button,#acts a')].filter(e=>/Localização|WhatsApp/.test(e.textContent)).map(e=>({l:e.textContent.trim(),svg:!!e.querySelector('svg')}))}}""")
        check(f'agente [{nome}]: chat recebe a mesma identidade (cor, modo, cantos)', ag['themed']=='page' and ag['accent']==t['cor'] and ag['theme']==('light' if light else 'dark') and ag['reto']==(t['cantos']=='reto'), ag)
        check(f'agente [{nome}]: texto das mensagens acompanha o modo', (lum(parse(ag['text']))<.5)==light, ag['text'])
        check(f'agente [{nome}]: Localização e WhatsApp com ícone no menu expandido', [c['l'] for c in ag['chips']]==['Localização','WhatsApp'] and all(c['svg'] for c in ag['chips']), ag['chips'])
        page.click('[data-a="cat"]'); page.wait_for_selector('.rich',timeout=5000); page.wait_for_timeout(200)
        page.click('.rich [data-pid]'); page.wait_for_timeout(300)
        page.screenshot(path=f'/tmp/e2e/agent_{nome}.png')
        card=page.evaluate("""()=>{const rs=[...document.querySelectorAll('.rich')];const r=rs[rs.length-1];const cs=getComputedStyle(r);const ta=r.querySelector('textarea,input.fi');const btn=r.querySelector('.btn-send');return {bg:cs.backgroundImage!=='none'?cs.backgroundImage:cs.backgroundColor,ink:getComputedStyle(r).color,btn:btn?getComputedStyle(btn).backgroundImage.slice(0,80):null,ta:ta?getComputedStyle(ta).color:null,hasTa:!!ta}}""")
        stops=re.findall(r'rgba?\([^)]*\)',card['bg']); lm=sum(lum(parse(c)) for c in stops)/max(1,len(stops))
        check(f'agente [{nome}]: card de detalhes do produto acompanha o tema (fundo, texto, observação, botão)', (lm>.6)==light and (lum(parse(card['ink']))<.5)==light and card['btn'] and card['hasTa'], card)
    errs=[e for e in errs if 'React error #418' not in e and e!='Event']  # #418 (hidratação) já existe na versão original
    check('nenhum erro de JavaScript do tema/catálogo/agente', not errs, errs)
    # ---------------- sincronização ----------------
    R.put(f'/api/v2/ads/{ID}',data={'tema':TEMAS['padrao']})
    page.goto(f'/x/empresa/{ID}'); page.wait_for_selector('[data-prod]',timeout=15000)
    page2=ctx.new_page(); page2.goto(f'/x/empresa/{ID}'); page2.wait_for_selector('[data-prod]',timeout=15000)
    page.bring_to_front()
    acc=lambda pg: pg.evaluate("()=>getComputedStyle(document.querySelector('[data-ma-themed=\"page\"]')).getPropertyValue('--nx-accent').trim()")
    check('sync: ambas as telas começam com o tema padrão', acc(page)=='#3b6cff' and acc(page2)=='#3b6cff')
    nova=TEMAS['natural']
    R.put(f'/api/v2/ads/{ID}',data={'tema':nova})
    page2.evaluate("(t)=>MaTheme.broadcast(%d,t)"%ID, nova)   # o que o botão "Salvar tema" do painel faz
    page.wait_for_timeout(500)
    st=page.evaluate("()=>({a:getComputedStyle(document.querySelector('[data-ma-themed=\"page\"]')).getPropertyValue('--nx-accent').trim(),t:document.querySelector('[data-ma-themed=\"page\"]').getAttribute('data-theme')})")
    check('sync: salvar o tema atualiza a outra tela aberta na hora (sem recarregar)', st=={'a':'#2f9e5b','t':'light'}, st)
    R.put(f'/api/v2/ads/{ID}',data={'tema':TEMAS['elegante']})
    page.evaluate("()=>{window.dispatchEvent(new Event('focus'))}"); page.wait_for_timeout(800)
    st=page.evaluate("()=>({a:getComputedStyle(document.querySelector('[data-ma-themed=\"page\"]')).getPropertyValue('--nx-accent').trim(),t:document.querySelector('[data-ma-themed=\"page\"]').getAttribute('data-theme')})")
    check('sync: mudança feita em outro aparelho chega ao voltar para a tela (consulta leve)', st=={'a':'#c9a227','t':'dark'}, st)
    # trocar claro -> escuro não deixa resíduo
    left=page.evaluate("()=>{const r=document.querySelector('[data-ma-themed=\"page\"]');return {canvas:r.style.getPropertyValue('--nx-canvas'),light:r.classList.contains('ma-light'),grad:r.hasAttribute('data-ma-grad')}}")
    check('troca claro→escuro limpa o tema anterior (sem resíduos)', left['canvas']=='#000' and not left['light'] and not left['grad'], left)
    # agente acompanha a troca sem recarregar
    page3=ctx.new_page(); page3.goto(f'/{slug}'); page3.wait_for_selector('.m.a',timeout=15000)
    page2.evaluate("(t)=>MaTheme.broadcast(%d,t)"%ID, TEMAS['vibrante'])
    page3.wait_for_timeout(500)
    st=page3.evaluate("()=>({a:getComputedStyle(document.documentElement).getPropertyValue('--nx-accent').trim(),t:document.documentElement.getAttribute('data-theme'),grad:getComputedStyle(document.body).backgroundImage.includes('gradient')})")
    check('sync: o chat do agente aberto acompanha a troca (colorido, cor nova)', st['a']=='#ff4d6d' and st['grad'], st)
    # tema só vale no catálogo: fora dele o app volta ao normal
    page.goto('/'); page.wait_for_timeout(1500)
    out=page.evaluate("()=>({any:!!document.querySelector('[data-ma-themed]'),accent:getComputedStyle(document.documentElement).getPropertyValue('--nx-accent').trim()})")
    check('fora do catálogo o tema da empresa não vaza para o app', not out['any'], out)
    b.close()
bad=[r for r in results if not r[1]]
print(f'\nResultado: {len(results)-len(bad)}/{len(results)} verificações aprovadas')
sys.exit(1 if bad else 0)
