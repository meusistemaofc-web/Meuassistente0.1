# Contadores de pedidos/agendamentos: menu lateral do Chat e "Sua empresa" (Pedidos/Agenda) usam a mesma fonte, atualizam sem recarregar, celular e computador.
import sys, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    own=b.new_context(base_url=BASE); R=own.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}); assert r.ok
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{k:{'ativo':True,'abre':'00:00','fecha':'23:59'} for k in ['dom','seg','ter','qua','qui','sex','sab']}}}).ok
    pid=[x for x in R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pizza grande','preco':50,'tipo':'produto','fotos':[IMG]}).json()['items'] if x['nome']=='Pizza grande'][0]['id']
    sid=[x for x in R.post(f'/api/v2/ads/{ID}/products',data={'tipo':'servico','nome':'Consulta','preco':50,'modoPreco':'hora','duracao':30,'fotos':[IMG]}).json()['items'] if x['nome']=='Consulta'][0]['id']
    cli=b.new_context(base_url=BASE); C=cli.request
    assert C.post('/api/auth',data={'action':'signup','name':'Cliente Contador','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123','acceptTerms':True}).ok
    dia=(datetime.date.today()+datetime.timedelta(days=3)).isoformat()
    def novo_pedido(): assert C.post(f'/api/v2/businesses/{ID}/orders',data={'itens':[{'pid':pid,'qtd':1,'escolhas':{}}],'modo':'retirada','pagamento':'dinheiro'}).ok
    def novo_agend(i):
        hs=C.get(f'/api/v2/businesses/{ID}/slots?servico={sid}&data={dia}').json()['horarios']; assert C.post(f'/api/v2/businesses/{ID}/bookings',data={'servico':sid,'data':dia,'hora':hs[i]}).ok
    novo_pedido(); novo_pedido(); novo_agend(0)
    api=R.get('/api/v2/counters').json(); check('API: 2 pedidos + 1 agendamento novos', api['pedidos']==2 and api['agendamentos']==1 and api['total']==3, api)
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        tot=R.get('/api/v2/counters').json()
        # menu lateral do Chat
        pg.goto('/'); pg.wait_for_selector('[aria-label="Abrir menu"]',timeout=20000); pg.wait_for_timeout(1500); pg.click('[aria-label="Abrir menu"]') if pg.locator('[aria-label="Abrir menu"]:visible').count() else None
        pg.wait_for_selector('[data-ma-x="suaempresa"] .ma-badge',timeout=15000)
        lat=pg.inner_text('[data-ma-x="suaempresa"] .ma-badge').strip()
        check(f'{nome}: menu lateral mostra o total (pedidos + agendamentos)', lat==str(tot['total']), (lat,tot))
        # Sua empresa > Pedidos (empresa "ambos": pedidos e agenda na mesma aba)
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]',timeout=15000); pg.wait_for_selector('.ma-nav [data-nav=pedidos] .ma-badge',timeout=15000)
        nb=pg.inner_text('.ma-nav [data-nav=pedidos] .ma-badge').strip()
        check(f'{nome}: Sua empresa > Pedidos mostra o MESMO número do menu lateral', nb==lat, (nb,lat))
        check(f'{nome}: contador no padrão visual do chat (mesma classe) e sem rolagem horizontal', pg.locator('.ma-nav [data-nav=pedidos] .ma-badge').count()==1 and pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
        pg.screenshot(path=f'/tmp/e2e/contadores_{nome}.png')
        # tempo real: novo pedido e novo agendamento chegam sem recarregar a página
        novo_pedido(); novo_agend(2)
        pg.wait_for_function("()=>{const b=document.querySelector('.ma-nav [data-nav=pedidos] .ma-badge');return b&&+b.textContent=="+str(tot['total']+2)+"}",timeout=35000)
        check(f'{nome}: novo pedido e novo agendamento atualizam sem recarregar', True)
        # decisão do dono na própria tela atualiza na hora; abre a aba, aceita um novo
        pg.locator('.ma-nav [data-nav=pedidos]').click(); pg.wait_for_selector('[data-os=aceito]',timeout=15000); pg.locator('[data-os=aceito]').first.click(); pg.wait_for_timeout(2500)
        esperado=R.get('/api/v2/counters').json()['total']
        pg.wait_for_function("()=>{const b=document.querySelector('.ma-nav [data-nav=pedidos] .ma-badge');return !!b&&+b.textContent=="+str(esperado)+"}",timeout=10000)
        check(f'{nome}: aceitar um pedido reduz o contador na hora e coincide com o servidor', esperado==tot['total']+1, (esperado,tot))
        c.close()
        # preparar o 2º ciclo (mesmo estado base): conta de novo a partir do servidor
    # sem "novos": o contador some (comportamento atual) e o cliente vê só o que está em andamento
    for o in R.get(f'/api/v2/ads/{ID}/orders').json()['items']:
        if o['status']=='novo': R.post(f'/api/v2/ads/{ID}/orders/{o["id"]}',data={'status':'aceito'})
    z=R.get('/api/v2/counters').json(); check('sem novos: total zera', z['total']==0 and z['pedidos']==0 and z['agendamentos']==0, z)
    pg2=own.new_page(); pg2.goto('/x/sua-empresa'); pg2.wait_for_selector('.ma-nav [data-nav=pedidos]',timeout=15000); pg2.wait_for_timeout(2500)
    check('zerado: o indicador desaparece em Sua empresa', pg2.locator('.ma-nav [data-nav=pedidos] .ma-badge').count()==0)
    cz=C.get('/api/v2/counters').json(); check('cliente não vê "novos" de empresa (isolamento) e tem pedidos em andamento', cz['total']==0 and cz['meus']['total']>=3, cz)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
print('FIM','OK' if all(res) else 'FALHOU',f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
