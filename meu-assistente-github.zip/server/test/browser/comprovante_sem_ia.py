# Comprovante FOTOGRAFADO lido com TODAS as IAs desligadas, de ponta a ponta e pela tela do chat:
# central REAL (services/central-midia, Python + Tesseract) + servidor completo (SQLite) + modo "sem IA".
# Envia fotos (tortas, com sombra, desfoque, ruído e JPEG), uma foto de lado e um print; confere o resumo para
# confirmação, as perguntas do que falta (data, entrada/saída), o botão Registrar e o lançamento no financeiro.
# Garante que nada é registrado sem confirmação e que nenhuma IA externa foi chamada.
# Uso (na pasta server):  python3 test/browser/comprovante_sem_ia.py
import os, re, sys, time, json, socket, subprocess, urllib.request, pathlib
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
RAIZ = pathlib.Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RAIZ / 'services' / 'central-midia'))
from tests import fotos  # noqa: E402  (gerador de comprovantes fotografados da suíte da central)

def porta_livre():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p
PC, PS = porta_livre(), porta_livre()
TOKEN = 'e2e-leitura-local-' + 'k' * 24
BASE = f'http://127.0.0.1:{PS}'
OUT = pathlib.Path('/tmp/e2e'); OUT.mkdir(exist_ok=True)
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))

db = '/tmp/ma-leitura-local.db'
for x in (db, db + '-wal', db + '-shm'):
    try: os.remove(x)
    except FileNotFoundError: pass
log = open('/tmp/e2e/leitura-local-servidor.log', 'w')
central = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', str(PC), '--log-level', 'warning'],
                           cwd=RAIZ / 'services' / 'central-midia', env={**os.environ, 'MIDIA_TOKEN': TOKEN, 'DIR_TEMP': '/tmp/central-e2e-ll'}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
srv = subprocess.Popen(['npx', 'tsx', 'test/serve-sqlite.ts'], cwd=RAIZ / 'server', stdout=log, stderr=subprocess.STDOUT,
                       env={**os.environ, 'PORT': str(PS), 'SQLITE_FILE': db, 'MIDIA_URL': f'http://127.0.0.1:{PC}', 'MIDIA_TOKEN': TOKEN})
def espera(url, n=150):
    for _ in range(n):
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200: return True
        except Exception: pass
        time.sleep(0.3)
    return False
try:
    check('central de mídias REAL no ar', espera(f'http://127.0.0.1:{PC}/saude'))
    check('Meu Assistente no ar (SQLite de teste)', espera(BASE + '/api/health'))
    with sync_playwright() as p:
        b = p.chromium.launch(); errs = []
        c = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, has_touch=True, is_mobile=True); R = c.request
        r = R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Clara Souza', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.ll@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True})
        check('conta criada', r.ok, r.text()[:200])
        r = R.put('/api/panel/brain_mode', data={'modoIA': 'sem_ia'}); check('modo "sem IA" ligado: todas as IAs desligadas', r.ok, r.text()[:200])
        st = R.get('/api/panel/leitura-local').json()
        check('painel: política "leitura local primeiro" e central no ar', st.get('politica') == 'local_primeiro' and st['central']['configurada'] and st['central']['disponivel'], st)
        marca_log = log.tell() if not log.closed else 0
        log.flush(); inicio_log = os.path.getsize('/tmp/e2e/leitura-local-servidor.log')
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=30000); pg.wait_for_timeout(2500)
        n_bolhas = lambda: pg.locator('.chat-scroll .msg-bubble').count()
        def ultima():
            return pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
        def espera_resposta(antes, texto_ok, t=120):
            fim = time.time() + t
            while time.time() < fim:
                if n_bolhas() >= antes + 2:
                    u = ultima()
                    if texto_ok(u): return u
                pg.wait_for_timeout(500)
            return ultima()
        OBS = """()=>{window.__vis={foto:false,comp:false};const f=()=>{const t=document.body.innerText;if(t.includes('Lendo a foto'))window.__vis.foto=true;if(/Lendo o comprovante|Lendo as fotos/.test(t))window.__vis.comp=true};if(window.__obs)window.__obs.disconnect();window.__obs=new MutationObserver(f);window.__obs.observe(document.body,{subtree:true,childList:true,characterData:true})}"""
        def enviar_foto(nome, dados, mime='image/jpeg'):
            pg.evaluate(OBS)
            antes = n_bolhas()
            pg.locator('.ma-composer-bar button[aria-label^="Anexar"]').click(); pg.wait_for_timeout(250)
            with pg.expect_file_chooser(timeout=5000) as fc: pg.locator('#ma-attach-card button[data-a="arq"]').click()
            fc.value.set_files({'name': nome, 'mimeType': mime, 'buffer': dados}); pg.wait_for_timeout(900)
            pg.locator('[aria-label="Enviar"]').first.click()
            if not os.path.exists(str(OUT / 'leitura_local_0_lendo.png')):
                try: pg.get_by_text('Lendo a foto').wait_for(timeout=5000); pg.screenshot(path=str(OUT / 'leitura_local_0_lendo.png'))
                except Exception: pass
            return espera_resposta(antes, lambda u: 'Lendo' not in u and len(u) > 30)
        def botoes():
            return pg.evaluate("()=>[...document.querySelectorAll('[data-dk],[data-opt]')].map(b=>b.innerText.trim())")
        def clicar(rotulo, ok):
            antes = n_bolhas()
            try: pg.locator('[data-dk],[data-opt]').filter(has_text=rotulo).last.click(timeout=15000)
            except Exception:
                print('DEBUG botoes', botoes(), pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.outerHTML.slice(-1500):''}")); raise
            return espera_resposta(antes, ok, 40)
        def entradas(): return R.get('/api/finance').json().get('entries', [])

        # 1) foto torta de comprovante Pix (tema escuro)
        t0 = time.time(); u = enviar_foto('pix.jpg', fotos.fotografar(fotos.renderizar('nubank_escuro'), semente=3)); dt = time.time() - t0
        pg.screenshot(path=str(OUT / 'leitura_local_1_resumo.png'))
        check('foto de Pix: resumo em linguagem natural, sem citar o método de leitura', u.startswith('Li o comprovante:') and not re.search(r'\bIA\b|OCR|leitura local|servidor|central', u) and 'Categoria: Alimentação' in u and 'Saída' in u and '152,30' in u and '14/11/2026' in u and '09:41' in u and 'Padaria' in u, u)
        check('foto de Pix: botões Registrar / É entrada / Cancelar e nada gravado antes', 'Registrar' in ' '.join(botoes()) and not entradas(), u)
        check(f'foto de Pix: lida em {dt:.1f} s', dt < 60, dt)
        vis = pg.evaluate('window.__vis')
        check('durante a leitura aparece somente "Lendo a foto" (sem "Lendo o comprovante")', vis['foto'] and not vis['comp'], vis)
        check('"Lendo a foto" desaparece quando a leitura termina', 'Lendo a foto' not in pg.inner_text('body'))
        u = clicar('Registrar', lambda x: 'egistr' in x or 'anotei' in x.lower() or 'R$' in x)
        e = entradas(); it = next((x for x in e if abs(x['amount'] - 152.3) < 0.001), None)
        pg.screenshot(path=str(OUT / 'leitura_local_2_registrado.png'))
        check('Registrar: saída de R$ 152,30 em 14/11/2026 no financeiro', it and it['date'] == '2026-11-14' and 'Padaria' in it['description'] and it.get('kind', it.get('type')) in ('expense', 'despesa'), (it, e))
        # correção de categoria pela conversa: altera o MESMO lançamento (sem criar outro) e confirma
        antes_n = len(entradas())
        pg.locator('textarea.composer-input').fill('Essa compra é lazer.'); n_ = n_bolhas(); pg.locator('[aria-label="Enviar"]').first.click()
        u = espera_resposta(n_, lambda x: 'Corrigido' in x or 'lançamento' in x, 40)
        it2 = next((x for x in entradas() if x['id'] == it['id']), None) if it else None
        check('"Essa compra é lazer.": categoria corrigida no mesmo lançamento, sem duplicar', 'Corrigido' in u and 'Lazer' in u and it2 and it2['category'] == 'lazer' and abs(it2['amount'] - 152.3) < 0.001 and len(entradas()) == antes_n, (u, it2))
        pg.screenshot(path=str(OUT / 'leitura_local_2b_categoria.png'))

        # 2) cupom fiscal fotografado DE LADO
        u = enviar_foto('cupom.jpg', fotos.fotografar(fotos.renderizar('cupom_nfce', 700), semente=5, de_lado=True))
        pg.screenshot(path=str(OUT / 'leitura_local_3_cupom_de_lado.png'))
        check('cupom fotografado de lado: R$ 63,47, 15/11/2026 e supermercado', '63,47' in u and '15/11/2026' in u and 'SUPERMERCADO' in u.upper() and 'Registrar' in ' '.join(botoes()), u)
        clicar('Registrar', lambda x: 'R$' in x)
        check('cupom registrado', any(abs(x['amount'] - 63.47) < 0.001 and x['date'] == '2026-11-15' for x in entradas()), entradas())

        # 3) print de Pix recebido: entrada
        u = enviar_foto('recebido.png', fotos.print_tela('pix_recebido'), 'image/png')
        check('print de Pix recebido: Entrada de R$ 250,00', 'Entrada' in u and '250,00' in u and '10/11/2026' in u, u)
        clicar('Registrar', lambda x: 'R$' in x)
        it = next((x for x in entradas() if abs(x['amount'] - 250) < 0.001), None)
        check('entrada registrada como receita', it and it.get('kind', it.get('type')) in ('income', 'receita'), it)

        # 4) foto sem data: pergunta a data (não usa "hoje" por conta própria)
        u = enviar_foto('semdata.jpg', fotos.fotografar(fotos.renderizar('sem_data'), semente=7))
        pg.screenshot(path=str(OUT / 'leitura_local_4_sem_data.png'))
        check('sem data: pergunta a data antes de mostrar o registro', 'Não encontrei a data' in u and 'Registrar' not in u, u)
        u = clicar('Ontem', lambda x: 'Registrar' in x or 'Confirma' in x)
        check('após responder "ontem": resumo com R$ 40,00 e Bruno Lima', '40,00' in u and 'Bruno Lima' in u and 'Confirma' in u, u)
        clicar('Registrar', lambda x: 'R$' in x)
        check('sem data: registrado com a data informada', any(abs(x['amount'] - 40) < 0.001 for x in entradas()), entradas())

        # 5) comprovante sem pista de direção: pergunta entrada/saída; cancelar não grava
        n0 = len(entradas())
        u = enviar_foto('ambiguo.jpg', fotos.fotografar(fotos.renderizar('ambiguo'), semente=9))
        pg.screenshot(path=str(OUT / 'leitura_local_5_entrou_saiu.png'))
        check('sem direção clara: pergunta "entrou ou saiu?"', 'entrou ou saiu' in u and '75,00' in u, u)
        u = clicar('Saiu', lambda x: 'Confirma' in x)
        check('"Saiu" mostra o resumo para confirmar (não grava sozinho)', 'Saída' in u and 'Confirma' in u and len(entradas()) == n0, u)
        clicar('Cancelar', lambda x: 'não registrei' in x)
        check('Cancelar: nada registrado', len(entradas()) == n0, entradas())

        # 6) a mesma foto de novo: duplicado bloqueado
        dup = fotos.fotografar(fotos.renderizar('itau_claro'), semente=11)
        enviar_foto('itau.jpg', dup); clicar('Registrar', lambda x: 'R$' in x)
        u = enviar_foto('itau.jpg', dup)
        check('mesmo comprovante de novo: não lança duplicado', 'já foi registrado' in u, u)

        # 7) painel do administrador → IA → "Leitura de comprovantes"
        cd = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE, storage_state=c.storage_state()); a = cd.new_page(); a.on('pageerror', lambda e: errs.append(str(e)))
        a.goto('/admin'); a.wait_for_timeout(1500); aba(a,'ia'); a.wait_for_selector('#ma-leitura-local input[name=ll_pol]', timeout=15000)
        bx = a.locator('#ma-leitura-local'); bx.scroll_into_view_if_needed(); a.wait_for_timeout(400); bx.screenshot(path=str(OUT / 'leitura_local_6_painel.png'))
        check('painel: caixa "Leitura de comprovantes" com a central no ar e 3 políticas', 'No ar' in bx.inner_text() and bx.locator('input[name=ll_pol]').count() == 3 and bx.locator('input[value=local_primeiro]').is_checked(), bx.inner_text()[:300])
        bx.locator('input[value=so_local]').check(); a.wait_for_timeout(1200)
        check('painel: trocar a política salva no servidor', R.get('/api/panel/leitura-local').json().get('politica') == 'so_local')
        R.put('/api/panel/leitura-local', data={'politica': 'local_primeiro'}); cd.close()
        log.flush(); txt = open('/tmp/e2e/leitura-local-servidor.log').read()[inicio_log:]
        check('nenhuma IA externa chamada (registro do servidor sem "[ai] provedor")', '[ai] provedor' not in txt, [l for l in txt.splitlines() if '[ai]' in l][:3])
        # o aviso #418 (hidratação do pacote compilado) é antigo e independe deste fluxo
        errs = [e for e in errs if '#418' not in e and e != 'Event']
        check('sem erros de JavaScript na página (fora o aviso antigo de hidratação #418)', not errs, errs[:3])
        b.close()
finally:
    srv.terminate(); central.terminate()
    try: srv.wait(5); central.wait(5)
    except Exception: srv.kill(); central.kill()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); sys.exit(0 if all(res) else 1)
