# Cupons e Vouchers com destino (anúncios, Agente de Atendimento ou ambos), de ponta a ponta pela tela:
# • administrador escolhe o destino na criação (o campo de planos some quando é só para o agente), vê o destino na lista,
#   filtra por destino e vê no histórico onde cada código foi usado;
# • dono da empresa, na ativação do agente (celular): cupom só de anúncios é recusado com mensagem clara; cupom do agente
#   mostra o preço riscado e o valor com desconto; remover volta ao preço; cupom "ambos" de 100% ativa sem pagamento.
# Servidor: PORT=4334 SQLITE_FILE=/tmp/ma-cdst.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re, sqlite3, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4334'; DBF = '/tmp/ma-cdst.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' '))
brl = lambda v: 'R$ ' + f'{v:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE)
    assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    assert A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    pa = A.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(1500); pa.get_by_role('button', name='Cupons e Vouchers', exact=True).click(); pa.wait_for_selector('[data-vcv]', timeout=10000)
    print('== painel do administrador')
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f')
    ds = [x.get_attribute('value') for x in pa.locator('#vc_f [name=destino]').all()]
    check('criação: escolha do destino (Anúncios, Agente de Atendimento, Anúncios e Agente), anúncios por padrão', ds == ['anuncio', 'agente', 'ambos'] and pa.locator('#vc_f [name=destino][value=anuncio]').is_checked() and 'Agente de Atendimento' in pa.inner_text('#vc_f'), ds)
    check('com destino "Anúncios", os planos de anúncio aparecem', pa.locator('[data-vc-planos]').is_visible())
    pa.check('#vc_f [name=destino][value=agente]'); pa.wait_for_timeout(100)
    check('com destino "Agente", o campo de planos de anúncio some', not pa.locator('[data-vc-planos]').is_visible())
    pa.fill('#vc_f [name=codigo]', 'agente50'); pa.check('#vc_f [name=tipo][value=percentual]'); pa.fill('#vc_f [name=percentual]', '50'); pa.fill('#vc_f [name=campanha]', 'Agente')
    pa.click('#vc_f button[type=submit]'); pa.wait_for_selector('[data-vc]', timeout=8000)
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f'); pa.check('#vc_f [name=destino][value=ambos]'); pa.fill('#vc_f [name=codigo]', 'TUDOGRATIS'); pa.check('#vc_f [name=tipo][value=percentual]'); pa.fill('#vc_f [name=percentual]', '100'); pa.fill('#vc_f [name=maxUsos]', '5')
    pa.click('#vc_f button[type=submit]'); pa.wait_for_timeout(1200)
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f'); pa.fill('#vc_f [name=codigo]', 'SOANUNCIO'); pa.check('#vc_f [name=tipo][value=percentual]'); pa.fill('#vc_f [name=percentual]', '20')
    pa.click('#vc_f button[type=submit]'); pa.wait_for_timeout(1200)
    dest = {pa.locator('[data-vc]').nth(i).locator('code').inner_text(): pa.locator('[data-vc]').nth(i).locator('[data-vc-destino]').inner_text() for i in range(pa.locator('[data-vc]').count())}
    check('lista mostra o destino de cada cupom', dest == {'SOANUNCIO': 'Anúncios', 'TUDOGRATIS': 'Anúncios e Agente', 'AGENTE50': 'Agente de Atendimento'}, dest)
    pa.select_option('#vc_d', 'agente'); pa.wait_for_timeout(300)
    check('filtro por destino', [x.inner_text() for x in pa.locator('[data-vc] code').all()] == ['AGENTE50'])
    pa.select_option('#vc_d', ''); pa.wait_for_timeout(200); pa.screenshot(path='/tmp/e2e/cdst_painel.png', full_page=True)
    preco = A.request.get('/api/v2/admin/vouchers').json()['agentePlano']['preco']
    print('== ativação do agente (celular)')
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Rosa', 'whatsapp': '+55 11 95555-0404', 'email': 'rosa@t.com', **U}, headers={'X-Forwarded-For': '10.9.9.4'}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Floricultura Rosa', 'categoria': 'Floricultura', 'titulo': 'x', 'texto': 'Flores', 'zap': '5511999990000'}).json()['items'][0]['id']
    db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (ID,)).fetchone()[0]); d['aprovadoEm'] = '2026-01-01T00:00:00Z'
    db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', data=? where id=?", (json.dumps(d), ID)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}/agent', data={'nome': 'Lia'}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    def abrir():
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(2500)
        if not pg.locator(f'[data-agente="{ID}"]').count(): pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1000)
        pg.locator(f'[data-agente="{ID}"]').first.click(); pg.wait_for_selector('[data-pay="ag"]', timeout=15000); pg.wait_for_timeout(500)
    abrir()
    check('ativação do agente com o campo discreto "Tenho um cupom" e o preço normal', pg.locator('[data-cupom-agente] [data-cup-abrir]').count() == 1 and brl(preco) in N(pg.inner_text('#agpay')), N(pg.inner_text('[data-pay="ag"]')))
    def aplicar(cod):
        pg.click('[data-cupom-agente] [data-cup-abrir]'); pg.fill('[data-cupom-agente] [data-cup-cod]', cod); pg.click('[data-cupom-agente] [data-cup-aplicar]'); pg.wait_for_timeout(1500)
    aplicar('soanuncio')
    check('cupom só de anúncios: recusado com mensagem clara', 'só para a ativação de anúncios' in pg.inner_text('[data-cupom-agente] [data-cup-msg]'), pg.inner_text('[data-cupom-agente]'))
    pg.fill('[data-cupom-agente] [data-cup-cod]', 'agente50'); pg.click('[data-cupom-agente] [data-cup-aplicar]'); pg.wait_for_selector('[data-cup-ok]', timeout=8000); pg.wait_for_timeout(500)
    metade = round(preco * 0.5, 2); bt = N(pg.inner_text('#agpay')); ok = N(pg.inner_text('[data-cup-ok]'))
    check('cupom do agente: mensagem, preço riscado e valor com desconto no botão', '50% de desconto' in ok and 'AGENTE50' in ok and brl(metade) in ok and pg.locator('[data-cup-ok] s').count() == 1 and brl(metade) in bt and brl(preco) not in bt, (ok, bt))
    pg.locator('[data-pay="ag"]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/cdst_agente_desconto.png')
    pg.click('[data-cup-remover]'); pg.wait_for_selector('[data-cup-abrir]', timeout=8000); pg.wait_for_timeout(500)
    check('remover: volta ao preço normal', pg.locator('[data-cup-ok]').count() == 0 and brl(preco) in N(pg.inner_text('#agpay')))
    aplicar('TUDOGRATIS'); pg.wait_for_selector('[data-agcupativar]', timeout=8000)
    check('cupom "ambos" de 100%: "Ativar sem pagamento" no lugar do Pix', pg.locator('#agpay').count() == 0 and 'Ativação grátis' not in pg.inner_text('body') and 'Grátis' in pg.inner_text('[data-cup-ok]'))
    pg.click('[data-agcupativar]'); pg.wait_for_timeout(2500)
    inf = R.get(f'/api/v2/ads/{ID}/agent').json()
    check('agente no ar sem pagamento, com o benefício registrado', inf['ativo'] and inf['beneficio']['cupom'] == 'TUDOGRATIS' and pg.locator('[data-ag-beneficio]').count() == 1, (inf['ativo'], inf.get('beneficio')))
    check('tela do agente sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    print('== histórico')
    pa.click('[data-vcv=historico]'); pa.wait_for_selector('#vh_alvo', timeout=8000); pa.select_option('#vh_alvo', 'agente'); pa.click('#vh_ok'); pa.wait_for_timeout(1500)
    h = N(pa.inner_text('#vc_corpo'))
    check('histórico mostra o uso no Agente e filtra por fluxo', 'TUDOGRATIS' in h and 'Agente · Floricultura Rosa' in h and pa.locator('[data-vh-alvo=anuncio]').count() == 0, h[:400])
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
