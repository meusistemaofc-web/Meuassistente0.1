# Ações das mensagens do Chat Principal: respostas da IA com Copiar → Curtir → Não curtir (só ícones cinza, numa linha, logo abaixo),
# sem editar; mensagens do usuário mantêm o editar. Cópia integral, avaliações sem duplicar, celular e computador.
import sys, sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
INFO="""(row)=>{const r=document.querySelector(`.msg-swipe[data-mid="${row}"]`),tl=r.querySelector('.msg-tools'),bub=r.querySelector('.msg-bubble').getBoundingClientRect();
 const bs=[...tl.querySelectorAll('button')].filter(b=>b.getBoundingClientRect().width>0&&getComputedStyle(b).display!=='none');
 return {bub:{b:bub.bottom,l:bub.left},tl:tl.getBoundingClientRect().top,bs:bs.map(b=>{const c=getComputedStyle(b),q=b.getBoundingClientRect(),s=b.querySelector('svg').getBoundingClientRect();return {lab:b.getAttribute('aria-label'),txt:b.innerText.trim(),vis:[...b.querySelectorAll('span')].filter(x=>{const z=x.getBoundingClientRect();return z.width>2&&z.height>2&&x.innerText.trim()}).length,w:q.width,h:q.height,y:Math.round(q.top+q.height/2),bg:c.backgroundColor,bd:c.borderTopStyle,br:c.borderTopWidth,cor:c.color,iw:Math.round(s.width)}})}}"""
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile,permissions=['clipboard-read','clipboard-write']); c.add_cookies(ctx.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_timeout(2500)
        pg.fill('textarea','me dá dicas de como economizar no mercado este mês'); pg.keyboard.press('Enter')
        pg.wait_for_selector('.msg-swipe.ma-ia .msg-tools .ma-fb',timeout=15000); pg.wait_for_timeout(800)
        ia=pg.locator('.msg-swipe.ma-ia').last; mid=ia.get_attribute('data-mid'); us=pg.locator('.msg-swipe:has(.bubble-user)').last
        x=pg.evaluate(INFO,mid); bs=x['bs']
        check(f'{nome}: resposta da IA com exatamente Copiar → Curtir → Não curtir', [z['lab'] for z in bs]==['Copiar mensagem','Resposta útil','Resposta não ajudou'], [z['lab'] for z in bs])
        check(f'{nome}: sem a opção de editar na resposta da IA', ia.locator('[aria-label="Editar texto"]:visible').count()==0 and ia.locator('[aria-label^="Editar"]:visible').count()==0)
        check(f'{nome}: os três numa única linha', len({z['y'] for z in bs})==1, [z['y'] for z in bs])
        check(f'{nome}: logo abaixo da resposta', 0<=x['tl']-x['bub']['b']<=14, (x['tl'],x['bub']['b']))
        check(f'{nome}: só ícones (sem texto visível)', all(z['txt']=='' or z['vis']==0 for z in bs) and all(z['vis']==0 for z in bs), [(z['txt'],z['vis']) for z in bs])
        check(f'{nome}: sem círculo, borda ou fundo', all(z['bg'] in ('rgba(0, 0, 0, 0)','transparent') and (z['bd']=='none' or z['br']=='0px') for z in bs), [(z['bg'],z['bd']) for z in bs])
        check(f'{nome}: ícones cinza, mesmo tamanho e mesma área de toque', len({z['cor'] for z in bs})==1 and len({z['iw'] for z in bs})==1 and all(z['w']==z['h']==32 for z in bs), [(z['cor'],z['iw'],z['w']) for z in bs])
        if nome=='celular': ia.screenshot(path='/tmp/e2e/acoes_ia_celular.png')
        texto=pg.evaluate("(m)=>document.querySelector(`.msg-swipe[data-mid=\"${m}\"] .msg-bubble p`).innerText",mid)
        ia.locator('[aria-label="Copiar mensagem"]').click(); pg.wait_for_timeout(500)
        cop=pg.evaluate('navigator.clipboard.readText()')
        check(f'{nome}: Copiar copia a resposta inteira', cop.strip()==texto.strip() and len(cop)>10, (cop[:80],texto[:80]))
        up=ia.locator('[data-fb="1"]'); down=ia.locator('[data-fb="-1"]')
        up.click(); pg.wait_for_timeout(900)
        cor_up=up.evaluate('e=>getComputedStyle(e).color'); cinza=bs[0]['cor']
        check(f'{nome}: Curtir registra avaliação positiva com destaque discreto', R.get(f'/api/chat/feedback?ids={mid}').json()['avaliacoes'].get(mid)==1 and up.get_attribute('aria-pressed')=='true' and cor_up!=cinza, (cor_up,cinza))
        down.click(); pg.wait_for_timeout(1000)
        check(f'{nome}: Não curtir registra avaliação negativa na hora', R.get(f'/api/chat/feedback?ids={mid}').json()['avaliacoes'].get(mid)==-1 and down.get_attribute('aria-pressed')=='true' and up.get_attribute('aria-pressed')=='false')
        pan=ia.locator('.ma-fb-panel')
        check(f'{nome}: motivos continuam disponíveis (opcionais)', pan.count()==1 and pan.locator('[data-m]').count()>=6)
        pan.locator('[data-m]').first.click(); pan.locator('.env').click(); pg.wait_for_timeout(1000)
        db=sqlite3.connect(DBF); n=db.execute('select count(*) from response_feedback where message_id=?',(mid,)).fetchone()[0]; db.close()
        check(f'{nome}: sem registro duplicado (uma avaliação por resposta)', n==1 and R.get(f'/api/chat/feedback?ids={mid}').json()['avaliacoes'].get(mid)==-1, n)
        # mensagem do usuário: editar preservado
        ed=us.locator('[aria-label="Editar mensagem"]')
        check(f'{nome}: mensagem do usuário mantém o Editar', ed.count()==1)
        orig=us.locator('.msg-bubble p').first.inner_text()
        ed.evaluate('e=>e.click()'); pg.wait_for_timeout(700)
        vals=pg.evaluate("()=>[...document.querySelectorAll('textarea')].map(t=>t.value)")
        check(f'{nome}: Editar da mensagem do usuário continua funcionando', any(orig.strip() in v for v in vals), (orig,vals))
        if nome=='computador': pg.screenshot(path='/tmp/e2e/acoes_ia_computador.png')
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
