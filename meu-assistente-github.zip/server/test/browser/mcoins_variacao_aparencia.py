# Mercado → MCoins mostra a variação % do valor de referência (24 h), como Criptomoedas e Bolsa, em vez de "N distribuídas";
# Painel → Aparência: título e descrição em cima (horizontal) e as opções Pequeno/Médio/Grande embaixo, no celular e no computador.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts (banco novo)
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); R=a.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True})
    ID=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Loja Var','categoria':'Loja','titulo':'P','texto':'x','zap':'5511999990000'}).json()['items'][0]['id']
    R.post('/api/panel/coins',data={'action':'config','ativo':True})
    IDS=[ID]+[R.post('/api/v2/ads',data={'planId':pl,'empresa':'Loja '+pl,'categoria':'Loja','titulo':'P','texto':'x','zap':'5511999990000'}).json()['items'][0]['id'] for pl in ('n2','n3')]  # cada empresa tem a sua moeda
    mk=lambda nome,sim,v: R.post('/api/panel/coins',data={'action':'create','businessId':IDS.pop(0),'modelo':'dourada','nome':nome,'simbolo':sim,'quantidade':200,'valorReferencia':v,'desconto':1,'finalidade':'x'}).json()['moeda']['id']
    C1=mk('Moeda Sobe','SOBE',1); C2=mk('Moeda Fixa','FIXA',1); C3=mk('Moeda Cai','CAI',2)
    for c in (C1,C2,C3): R.post('/api/panel/coins',data={'action':'status','id':c,'status':'ativa'})
    R.post('/api/panel/coins',data={'action':'update','id':C1,'valorReferencia':1.28}); R.post('/api/panel/coins',data={'action':'update','id':C3,'valorReferencia':1.5})
    R.post('/api/panel/coins',data={'action':'distribuir','id':C2,'email':'admin@t.com','quantidade':100,'idem':'var-ui-0001'})
    api=R.get('/api/v2/coins/market').json() if R.get('/api/v2/coins/market').ok else {}
    st=a.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':860},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/x/mercado'); pg.wait_for_selector('[data-aba="bonus"]',timeout=20000); pg.wait_for_timeout(2500); pg.click('[data-aba="bonus"]'); pg.wait_for_selector('[data-moeda]',timeout=10000); pg.wait_for_timeout(600)
        rows={r.locator('p.text-\\[15px\\]').first.inner_text().strip():r for r in pg.locator('[data-moeda]').all()}
        v=lambda s: rows[s].locator('[data-var24h]').inner_text().strip() if s in rows and rows[s].locator('[data-var24h]').count() else None
        cor=lambda s: rows[s].locator('[data-var24h]').evaluate('e=>getComputedStyle(e).color')
        check(f'{nome}: MCoins mostram a variação em % (não "distribuídas")', 'distribuídas' not in pg.inner_text('#ma-x') and all(v(s) for s in ('SOBE','FIXA','CAI')), pg.inner_text('#ma-x')[:300])
        check(f'{nome}: valor subiu 1,00 → 1,28: +28,00% em verde', v('SOBE')=='+28,00%' and cor('SOBE')==pg.evaluate("()=>getComputedStyle(document.querySelector('.text-success')).color"), (v('SOBE'),))
        check(f'{nome}: valor caiu 2,00 → 1,50: -25,00% em vermelho', v('CAI')=='-25,00%' and 'text-danger' in rows['CAI'].locator('[data-var24h]').get_attribute('class'), v('CAI'))
        check(f'{nome}: valor sem alteração: +0,00% (distribuir moedas não muda a cotação)', v('FIXA')=='+0,00%', v('FIXA'))
        check(f'{nome}: mesmo formato das Criptomoedas (coluna da direita: preço e % embaixo)', rows['SOBE'].locator('.w-32.text-right p').count()==2)
        pg.screenshot(path=f'/tmp/e2e/mcoins_variacao_{nome}.png')
        # Painel → Aparência
        pg.goto('/admin'); pg.wait_for_timeout(2500); pg.get_by_role('button',name='Aparência',exact=True).first.click(); pg.wait_for_selector('[data-rowv]',timeout=10000); pg.wait_for_timeout(500)
        g=pg.evaluate("""()=>[...document.querySelectorAll('[data-rowv]')].map(r=>{const t=r.querySelector('p'),s=r.querySelector('[data-sz]').parentElement,a=t.getBoundingClientRect(),b=s.getBoundingClientRect(),cs=getComputedStyle(t);return {txt:t.textContent,th:a.height,lh:parseFloat(cs.lineHeight)||22,tw:a.width,rw:r.getBoundingClientRect().width,segTop:b.top,txtBottom:a.bottom,segL:b.left,txtL:a.left,segR:b.right,vw:innerWidth}})""")
        check(f'{nome}: títulos na horizontal (no máximo 2 linhas, largura da linha)', all(x['th']<=x['lh']*2.2 and x['tw']>=x['rw']*0.5 for x in g), g)
        check(f'{nome}: opções Pequeno/Médio/Grande abaixo do texto, alinhadas à esquerda e dentro da tela', all(x['segTop']>=x['txtBottom'] and abs(x['segL']-x['txtL'])<=6 and x['segR']<=x['vw'] for x in g), g)
        pg.locator('[data-rowv]').first.locator('[data-sz$="|g"]').click(); pg.wait_for_timeout(300)
        check(f'{nome}: escolher o tamanho continua funcionando', 'btn-send' in pg.locator('[data-rowv]').first.locator('[data-sz$="|g"]').get_attribute('class'))
        pg.locator('[data-rowv]').first.scroll_into_view_if_needed(); pg.screenshot(path=f'/tmp/e2e/aparencia_{nome}.png')
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
