import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    for t,k in [('Plataforma de Música','/musica'),('TV ao vivo','/tv')]:
        assert R.post('/api/panel/showcase',data={'action':'create','titulo':t,'descricao':'Acesse '+t,'url':'https://exemplo.com','palavra':k,'imagem':IMG}).ok
    errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        menu=lambda: pg.locator('.ma-vit-menu').count()
        cards=lambda: pg.locator('.ma-vit-card').count()
        def novo():
            if not pg.locator('a[aria-label="Chat"]:visible').count(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(500)
            pg.locator('a[aria-label="Chat"]:visible').first.click(); pg.wait_for_timeout(1500)
        def enviar(t):
            ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2500)
        def abrir(i=0):
            ta=pg.locator('textarea.composer-input'); ta.click(); ta.press('Control+a'); ta.type('/'); pg.wait_for_selector('.ma-vit-menu.in',timeout=5000); pg.wait_for_timeout(300)
            pg.locator('.ma-vit-menu [role=option]').nth(i).dispatch_event('pointerdown')
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(3000)
        enviar('Primeira conversa')
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type('/'); pg.wait_for_selector('.ma-vit-menu',timeout=5000)
        check(f'{nome}: "/" abre o menu com as opções', pg.locator('.ma-vit-menu [role=option]').count()==2)
        pg.wait_for_timeout(300)
        check(f'{nome}: abertura animada (transição de opacidade)', pg.evaluate("()=>{const m=document.querySelector('.ma-vit-menu');const c=getComputedStyle(m);return m.classList.contains('in')&&c.transitionProperty.includes('opacity')&&+c.opacity===1}"))
        pg.locator('.ma-vit-menu [role=option]').first.dispatch_event('pointerdown'); pg.wait_for_selector('.ma-vit-card',timeout=5000); pg.wait_for_timeout(500)
        check(f'{nome}: ao selecionar, o menu some automaticamente', menu()==0)
        check(f'{nome}: card aberto e campo limpo', cards()==1 and ta.input_value()=='')
        abrir(1); pg.wait_for_timeout(500); check(f'{nome}: o menu pode ser aberto de novo quando o usuário quiser', cards()==2 and menu()==0, (cards(),menu()))
        enviar('Mais uma mensagem'); check(f'{nome}: menu não fica fixo durante a conversa', menu()==0)
        # menu aberto e novo chat: nada fica na tela
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type('/'); pg.wait_for_selector('.ma-vit-menu.in')
        novo()
        pg.wait_for_timeout(400)
        check(f'{nome}: novo chat esconde o menu', menu()==0)
        check(f'{nome}: novo chat esconde os acessos (cards) da conversa anterior', cards()==0, cards())
        check(f'{nome}: sem sobras de espaço (nenhum elemento da vitrine no chat)', pg.evaluate("()=>document.querySelectorAll('.chat-scroll .ma-vit-card, .ma-vit-menu').length")==0)
        # card em chat novo ainda vazio; a 1ª mensagem não apaga
        abrir(0); pg.wait_for_selector('.ma-vit-card',timeout=5000)
        enviar('Segunda conversa'); pg.wait_for_timeout(500)
        check(f'{nome}: card aberto antes da 1ª mensagem permanece nessa conversa', cards()==1, cards())
        # voltar à primeira conversa pelo histórico
        if not pg.get_by_text('Primeira conversa').first.is_visible(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(600)
        pg.get_by_text('Primeira conversa').first.click(); pg.wait_for_timeout(1800)
        check(f'{nome}: ao voltar à primeira conversa aparecem só os cards dela (2, gravados no histórico) e nenhum da segunda', cards()==2, cards())
        novo(); check(f'{nome}: opções e atalhos continuam funcionando em novo chat', menu()==0 and cards()==0)
        abrir(0); pg.wait_for_selector('.ma-vit-card',timeout=5000); check(f'{nome}: abrir novamente em novo chat funciona', cards()==1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
