# Fase 8 — Autonomia operacional pela tela real.
# Chat: objetivo em linguagem do dia a dia → plano → execução verificada; nível 3 exige "autorizo" + código.
# Página "Minhas execuções": plano, progresso, etapas conferidas, autorizar (com código), cancelar, desfazer, autonomia.
# Painel do administrador: indicadores e níveis por operação (sem reduzir o mínimo).
import sys, json, datetime as dt
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4311'
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-0000', 'email': 'adm@t.com', 'birthday': '1980-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    ctx = b.new_context(viewport={'width': 390, 'height': 860}, base_url=BASE); R = ctx.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.8.0.3'}).ok
    hoje = R.get('/api/agenda').json()['today']; D = lambda n: (dt.date.fromisoformat(hoje) + dt.timedelta(days=n)).isoformat()
    for t, h in [('Dentista', '10:00'), ('Reunião', '15:00')]: R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': t, 'date': D(1), 'time': h, 'reminder_minutes': 0}})
    for t in ['Ligar banco', 'Enviar proposta']:
        i = R.post('/api/items', data={'action': 'create', 'type': 'task', 'data': {'title': t}}).json()['item']['id']; R.post('/api/items', data={'action': 'task_status', 'type': 'task', 'id': i, 'data': {'status': 'done'}})
    conv = 'ab000000-0000-4000-8000-000000000001'
    say = lambda t: R.post('/api/chat', data={'text': t, 'conversationId': conv}).json()['assistantMessage']['content']
    m1 = say('crie lembretes para todos os compromissos de amanhã')
    check('objetivo em linguagem natural executado e conferido', 'concluída e conferida no sistema (2 de 2)' in m1, m1)
    m2 = say('apague as tarefas concluídas'); cod = __import__('re').search(r'EX-[0-9A-F]{6}', m2).group(0)
    check('exclusão pede autorização explícita', 'autorização explícita' in m2 and f'autorizo {cod}' in m2, m2)
    pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
    pg.goto('/perfil'); pg.wait_for_selector('section#execucoes .ma-exec-link', timeout=20000)
    check('atalho "Minhas execuções" no Perfil', pg.locator('section#execucoes .ma-exec-link').count() == 1)
    pg.locator('section#execucoes .ma-exec-link').click(); pg.wait_for_url('**/execucoes'); pg.wait_for_selector(f'[data-ex="{cod}"]', timeout=20000)
    card = pg.locator(f'[data-ex="{cod}"]')
    check('cartão aguardando autorização com o plano', 'Aguardando sua autorização' in card.inner_text() and 'Excluir tarefa: Ligar banco' in card.inner_text() and card.locator('[data-cod]').count() == 1, card.inner_text()[:300])
    card.locator('[data-cod]').fill('EX-000000'); card.locator('[data-a="autorizar"]').click(); pg.wait_for_timeout(900)
    check('código errado não autoriza', len([t for t in R.get('/api/items?type=task').json().get('items', [])]) >= 0 and R.get(f'/api/me/execucoes/{cod}').json()['status'] == 'aguardando_autorizacao')
    card = pg.locator(f'[data-ex="{cod}"]'); card.locator('[data-cod]').fill(cod.lower()); card.locator('[data-a="autorizar"]').click(); pg.wait_for_timeout(1500)
    card = pg.locator(f'[data-ex="{cod}"]'); ct = card.inner_text()
    check('autorizado: concluída e cada etapa conferida', 'Concluída e conferida' in ct and ct.count('conferido') == 2, ct[:400])
    card.locator('[data-a="reverter"]').click(); pg.wait_for_timeout(1500)
    check('desfazer pela página', 'Desfeita' in pg.locator(f'[data-ex="{cod}"]').inner_text() and R.get(f'/api/me/execucoes/{cod}').json()['status'] == 'revertida')
    pg.locator('#caut').click(); pg.wait_for_timeout(900)
    check('modo cauteloso escolhido pelo usuário', R.get('/api/me/execucoes').json()['autonomia'] == 'cautelosa')
    m3 = say('organize minha semana'); cod3 = __import__('re').search(r'EX-[0-9A-F]{6}', m3).group(0)
    check('cauteloso: até operações simples pedem "sim"', 'Posso executar?' in m3, m3)
    pg.reload(); pg.wait_for_selector(f'[data-ex="{cod3}"] [data-a="cancelar"]'); pg.locator(f'[data-ex="{cod3}"] [data-a="cancelar"]').click(); pg.wait_for_timeout(1000)
    check('cancelar pela página', R.get(f'/api/me/execucoes/{cod3}').json()['status'] == 'cancelada')
    pg.locator('#caut').click(); pg.wait_for_timeout(800)
    for w, h in [(390, 860), (1280, 900)]:
        pg.set_viewport_size({'width': w, 'height': h}); pg.wait_for_timeout(300)
        ov = pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
        check(f'página sem rolagem horizontal em {w}px', ov['sw'] <= ov['cw'] + 1, ov)
    pg.set_viewport_size({'width': 390, 'height': 860}); pg.goto(f'/execucoes#{cod}'); pg.wait_for_selector(f'[data-ex="{cod}"].foco', timeout=10000); pg.screenshot(path='/tmp/e2e/execucoes.png')
    check('link de uma execução abre e destaca o cartão', pg.locator(f'[data-ex="{cod}"].foco').count() == 1)
    # administrador
    pa = adm.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(1500); aba(pa,'cb_autonomia'); pa.wait_for_selector('#ex_tiles', timeout=20000)
    t = pa.inner_text('#ex_box')
    check('painel: executadas, concluídas, pendentes, falhas, autorização, tempo médio e sucesso', all(x in t for x in ['Tarefas executadas', 'Concluídas', 'Pendentes', 'Falhas de execução', 'Exigiram autorização', 'Tempo médio', 'Taxa de sucesso']) and 'Ligar banco' not in t, t[:400])
    pa.locator('#ex_box summary').click(); sel = pa.locator('[data-exop="tarefa.excluir"] option')
    check('exclusão não pode ser reduzida abaixo do nível 3', sel.count() == 1 and '3' in sel.first.get_attribute('value'))
    pa.locator('[data-exop="tarefa.criar"]').select_option('2'); pa.wait_for_timeout(1200)
    check('administrador exige confirmação numa operação', A.get('/api/panel/execucao').json()['config']['niveis'].get('tarefa.criar') == 2)
    pa.wait_for_selector('[data-exop="tarefa.criar"]', state='attached'); A.put('/api/panel/execucao', data={'operacao': 'tarefa.criar', 'nivel': 1})
    pa.locator('#ex_box').screenshot(path='/tmp/e2e/execucao_painel.png')
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
