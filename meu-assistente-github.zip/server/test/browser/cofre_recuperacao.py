# Recuperação da chave do cofre — simulação do incidente com o servidor do app (test/serve-sqlite.ts: mesmo código e
# rotas da produção, banco SQLite porque este ambiente não tem o driver do Postgres) e um pg_dump REAL do Postgres 16:
#  1) instalação com APP_SECRET original: aplicação OAuth do Mercado Pago no painel (Client Secret cifrado), loja A
#     conectada pelo OAuth (PKCE, simulador do Mercado Pago), loja B com Access Token manual; backup.sh: env-* e pg_dump;
#  2) incidente: o .env é recriado com OUTRO APP_SECRET → painel acusa credenciais ilegíveis, loja A aparece com a
#     credencial ilegível; nada no banco muda;
#  3) deploy/scripts/recuperar-chave.sh (com "docker" simulado que roda a CLI de verdade contra o mesmo Postgres):
#     sem --aplicar só diagnostica (código 10, .env intacto, nenhum valor de chave na tela); com --aplicar grava
#     APP_SECRET_ANTERIOR (APP_SECRET intacto, backup do .env) e confere;
#  4) depois de reiniciar: descriptografia OK, Mercado Pago da loja A conectado e funcional (API recebe o token
#     original), banco das credenciais idêntico ao de antes do incidente, OAuth de novo funciona (usa o Client Secret
#     antigo), salvar Access Token manual funciona;
#  5) sem a chave em lugar nenhum: código 12 e nada alterado;
#  6) instalação SEM APP_SECRET (chave do banco) cuja vault-key foi trocada: a chave antiga é achada no backup do banco.
# Uso: python3 test/browser/cofre_recuperacao.py   (sobe Postgres em /tmp, simulador do MP e o servidor; derruba ao fim)
import os, sys, json, time, shutil, signal, subprocess, urllib.request, urllib.parse, http.cookiejar, hashlib, gzip, re
SRV=os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..')); RAIZ=os.path.dirname(SRV)
PG='/usr/lib/postgresql/16/bin'; PGD='/tmp/pgcofre'; PGP=5499; APORTA=4354; MPP=4398; PASTA='/tmp/ma-servidor'
ORIG='segredo-original-de-producao-7f3a9c2e11'; NOVO='segredo-recriado-no-update-55b0d4e9aa'; ERRADO='chave-de-outro-sistema-qualquer-000'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:500])); sys.stdout.flush()
def sh(cmd,**k): return subprocess.run(cmd,shell=True,capture_output=True,text=True,**k)
def pg(sql,db='ma'):
    if db!='ma' or not sql.startswith(('DROP','CREATE','INSERT')):  # consultas do app: no banco do app (SQLite)
        import sqlite3; c=sqlite3.connect(URL(db)); sql2=sql.replace("NOW()+interval '30 days'","strftime('%Y-%m-%dT%H:%M:%fZ','now','+30 days')").replace('::text',''); out=c.execute(sql2).fetchall(); c.commit(); c.close(); return '\n'.join('|'.join(str(x) for x in r) for r in out)
    r=subprocess.run(['su','postgres','-c',f'{PG}/psql -h /tmp -p {PGP} -d ma -tAc "$0"',sql],capture_output=True,text=True); assert r.returncode==0, r.stderr[:300]; return r.stdout.strip()
# ---------- Postgres temporário
sh(f'su postgres -c "{PG}/pg_ctl -D {PGD} stop -m immediate"'); shutil.rmtree(PGD,ignore_errors=True)
assert sh(f'su postgres -c "{PG}/initdb -D {PGD} -A trust -U postgres"').returncode==0
assert sh(f'su postgres -c "{PG}/pg_ctl -D {PGD} -o \'-p {PGP} -k /tmp\' -l /tmp/pgcofre.log start"').returncode==0; time.sleep(2)
sh(f'su postgres -c "{PG}/createdb -h /tmp -p {PGP} ma"')
def URL(db): return f'/tmp/cofre-{db}.db'  # arquivo SQLite do app
for f in os.listdir('/tmp'):
    if f.startswith('cofre-ma'): os.remove('/tmp/'+f)
def dump(db,arq):
    # backup.sh faz pg_dump do Postgres: aqui o app_config do app (SQLite) é copiado para o Postgres 16 e o arquivo do
    # backup sai do pg_dump de verdade (mesmo formato que o script vai ler na VPS)
    import sqlite3; c=sqlite3.connect(URL(db)); rows=c.execute('select key, value, updated_at from app_config').fetchall(); c.close()
    pg('DROP TABLE IF EXISTS app_config'); pg('CREATE TABLE app_config (key TEXT PRIMARY KEY, value JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())')
    for k,v,u in rows: pg("INSERT INTO app_config (key, value) VALUES ('%s', '%s'::jsonb)" % (k.replace("'","''"), v.replace("'","''")))
    r=subprocess.run(['su','postgres','-c',f'{PG}/pg_dump -h /tmp -p {PGP} ma'],capture_output=True); assert r.returncode==0, r.stderr[:300]
    with gzip.open(arq,'wb') as f: f.write(r.stdout)
# ---------- simulador do Mercado Pago
mp=subprocess.Popen([sys.executable,os.path.join(SRV,'test/browser/mercadopago_fake.py'),str(MPP),f'http://localhost:{APORTA}/api/mercadopago/oauth/callback','pkce'],stdout=open('/tmp/mpfake-cofre.log','w'),stderr=subprocess.STDOUT)
# ---------- servidor de produção (src/index.ts)
app=None
def sobe(env_extra):
    global app
    if app: os.killpg(os.getpgid(app.pid),signal.SIGTERM); app.wait(20)
    env={k:v for k,v in os.environ.items() if k not in ('APP_SECRET','APP_SECRET_ANTERIOR','DATABASE_URL','SQLITE_FILE')}
    if 'DATABASE_URL' in env_extra: env_extra={**env_extra,'SQLITE_FILE':env_extra.pop('DATABASE_URL')}
    env.update({'PORT':str(APORTA),'HOST':'127.0.0.1','PUBLIC_URL':f'http://localhost:{APORTA}','AUTO_MIGRATE':'1','SCHEDULER_ENABLED':'0','COOKIE_SECURE':'0','MP_API_BASE':f'http://127.0.0.1:{MPP}','MP_AUTH_BASE':f'http://127.0.0.1:{MPP}','STATIC_DIR':os.path.join(RAIZ,'frontend/public'),'MIGRATIONS_DIR':os.path.join(SRV,'migrations'),**env_extra})
    app=subprocess.Popen(['npx','tsx','test/serve-sqlite.ts'],cwd=SRV,env=env,stdout=open('/tmp/app-cofre.log','a'),stderr=subprocess.STDOUT,preexec_fn=os.setsid)
    for _ in range(150):
        try: urllib.request.urlopen(f'http://localhost:{APORTA}/api/health',timeout=1); return
        except Exception: time.sleep(0.4)
    raise SystemExit('servidor não subiu: '+open('/tmp/app-cofre.log').read()[-1500:])
class Cli:
    def __init__(s): s.cj=http.cookiejar.CookieJar(); s.op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(s.cj))
    def j(s,m,p,b=None):
        r=urllib.request.Request(p if p.startswith('http') else f'http://localhost:{APORTA}{p}',data=json.dumps(b).encode() if b is not None else None,method=m,headers={'Content-Type':'application/json','Origin':f'http://localhost:{APORTA}'})
        try:
            with s.op.open(r,timeout=30) as x: t=x.read().decode(); return x.status,(json.loads(t) if t.strip().startswith(('{','[')) else {}),t,x.url
        except urllib.error.HTTPError as e: t=e.read().decode(); return e.code,(json.loads(t) if t.strip().startswith('{') else {}),t,''
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
def loja(c,nome,db='ma'):
    st,b,t,_=c.j('POST','/api/v2/ads',{'planId':'n4','empresa':nome,'categoria':'Doces','titulo':'Doces','texto':'Doces','zap':'5511999990000'}); assert st==200,t
    bid=[x for x in b['items'] if x['empresa']==nome][0]['id']; pg(f"UPDATE businesses SET status='ativo', expires_at=NOW()+interval '30 days' WHERE id={bid}",db); return bid
def credenciais(db='ma'): return hashlib.sha256((pg("SELECT business_id||provedor||dados::text FROM empresa_integracoes ORDER BY 1",db)+pg("SELECT value::text FROM app_config WHERE key IN ('mp_oauth','vault-key') ORDER BY key",db)).encode()).hexdigest()
# ---------- pasta do servidor (como na VPS) e "docker" simulado
def prepara_pasta(dbn,env_txt):
    shutil.rmtree(PASTA,ignore_errors=True); os.makedirs(PASTA+'/deploy/scripts'); os.makedirs(PASTA+'/backups'); os.makedirs(PASTA+'/bin')
    shutil.copy(os.path.join(RAIZ,'deploy/scripts/recuperar-chave.sh'),PASTA+'/deploy/scripts/')
    open(PASTA+'/.env','w').write(env_txt)
    open(PASTA+'/bin/docker','w').write(f'''#!/usr/bin/env bash
# docker simulado: "compose exec/run app node dist/db/cofre-recuperar-cli.js" roda a CLI de verdade contra o Postgres,
# com o ambiente do .env (como o contêiner); "up -d app" registra; um contêiner antigo com outra chave (isca).
case "$1 $2" in
  "compose ps") echo "meuassistente-app-1  app  running"; exit 0;;
  "compose up") echo up >> "{PASTA}/docker.log"; exit 0;;
  "compose exec"|"compose run") if printf '%s ' "$@" | grep -q wget; then exit 0; fi
     set -a; . "{PASTA}/.env"; set +a; cd "{SRV}"; exec npx tsx src/db/cofre-recuperar-cli.ts 2> >(grep -v ExperimentalWarning >&2);;
  "ps -aq") echo c0ffee; exit 0;;
  "inspect -f") if [ "$3" = "{{{{.Name}}}}" ]; then echo /meuassistente-app-antigo; else printf 'PATH=/usr/bin\\nAPP_SECRET={ERRADO}\\nNODE_ENV=production\\n'; fi; exit 0;;
esac
echo "docker simulado: comando não previsto: $*" >&2; exit 99
'''); os.chmod(PASTA+'/bin/docker',0o755)
def recuperar(*args):
    r=subprocess.run(['bash',PASTA+'/deploy/scripts/recuperar-chave.sh',*args],cwd=PASTA,capture_output=True,text=True,env={**os.environ,'PATH':PASTA+'/bin:'+os.environ['PATH']},timeout=600)
    return r.returncode, r.stdout+r.stderr
try:
    # ======== 1) instalação original
    sobe({'DATABASE_URL':URL('ma'),'APP_SECRET':ORIG})
    A=Cli(); assert A.j('POST','/api/auth',{'action':'signup','name':'Admin Producao','email':'admin@prod.com','whatsapp':'+55 11 94444-0101',**U})[0]==200
    A.j('PUT','/api/panel/modules',{'empresas':True,'anuncios':True}); A.j('PUT','/api/panel/site',{'url':f'http://localhost:{APORTA}'})
    st,_,t,_=A.j('PUT','/api/panel/mp_oauth',{'clientId':'1234567890123456','clientSecret':'segredo-da-aplicacao-de-teste','ambiente':'teste','pkce':True}); check('painel: aplicação OAuth do Mercado Pago salva (Client Secret cifrado)', st==200 and 'segredo-da-aplicacao' not in t, t[:200])
    LA=loja(A,'Loja OAuth'); LB=loja(A,'Loja Manual')
    st,b,t,_=A.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'oauth'}); st2,_,_,fim=A.j('GET',b['url']+'&conta=loja1')
    st,sA,t,_=A.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'status'}); check('loja A conectada pelo OAuth (PKCE)', sA.get('mpStatus')=='conectado' and sA.get('mpModo')=='oauth', (fim,t[:300]))
    st,b,t,_=A.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'verificar'}); check('loja A funcional antes do incidente', b.get('ok') is True, t[:200])
    st,b,t,_=A.j('POST',f'/api/v2/ads/{LB}/mp',{'tok':'APP_USR-1111222233334444-manual-loja-b'}); check('loja B com Access Token manual', b.get('mpStatus')=='conectado' and b.get('mpModo')=='manual', t[:200])
    masc=(sA.get('mpMasked'),A.j('POST',f'/api/v2/ads/{LB}/mp',{'action':'status'})[1].get('mpMasked'))
    antes=credenciais()
    # backup.sh: cópia do .env e do banco
    prepara_pasta('ma',f'SQLITE_FILE={URL("ma")}\nAPP_SECRET={ORIG}\n')
    shutil.copy(PASTA+'/.env',PASTA+'/backups/env-20261120-030000'); dump('ma',PASTA+'/backups/meuassistente-20261120-030000.sql.gz')
    # ======== 2) incidente: .env recriado com outro APP_SECRET
    open(PASTA+'/.env','w').write(f'SQLITE_FILE={URL("ma")}\nAPP_SECRET={NOVO}\n')
    sobe({'DATABASE_URL':URL('ma'),'APP_SECRET':NOVO})
    A2=Cli(); A2.j('POST','/api/auth',{'action':'login','email':'admin@prod.com','password':'Senha@Forte123'})
    cof=A2.j('GET','/api/panel')[1].get('cofre') or {}; st,sA,t,_=A2.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'status'})
    check('incidente reproduzido: painel acusa credenciais ilegíveis e a loja A fica com a credencial ilegível', cof.get('ok') is False and cof.get('ilegiveis',0)>=2 and sA.get('credencialIlegivel') is True, (cof,t[:200]))
    check('incidente: nada mudou no banco', credenciais()==antes)
    # ======== 3) recuperação
    rc,out=recuperar()
    check('diagnóstico (sem --aplicar): acha a chave no backup do .env (código 10)', rc==10 and 'backups/env-20261120-030000' in out and 'TODAS as credenciais em uso' in out, out[-1500:])
    check('diagnóstico: isca do contêiner antigo testada e descartada', 'contêiner /meuassistente-app-antigo' in out and re.search(r'contêiner /meuassistente-app-antigo.*abre 0 credencial', out), out[-1500:])
    check('diagnóstico não mostra nenhum valor de chave nem credencial', all(x not in out for x in (ORIG,NOVO,ERRADO,'segredo-da-aplicacao','APP_USR-1111')), out[-800:])
    check('diagnóstico não altera nada (.env e banco intactos)', open(PASTA+'/.env').read()==f'SQLITE_FILE={URL("ma")}\nAPP_SECRET={NOVO}\n' and credenciais()==antes)
    rc,out=recuperar('--aplicar'); env=open(PASTA+'/.env').read()
    check('--aplicar: grava APP_SECRET_ANTERIOR com a chave original, mantém APP_SECRET, faz backup do .env e confere', rc==0 and f'APP_SECRET_ANTERIOR={ORIG}' in env and f'APP_SECRET={NOVO}\n' in env and any(f.startswith('env-antes-recuperacao-') for f in os.listdir(PASTA+'/backups')) and 'voltaram a abrir' in out, (rc,out[-800:],env))
    check('--aplicar: banco não foi alterado', credenciais()==antes)
    # ======== 4) depois de reiniciar com o .env recuperado
    vals=dict(l.split('=',1) for l in env.strip().split('\n')); sobe({'DATABASE_URL':URL('ma'),'APP_SECRET':vals['APP_SECRET'],'APP_SECRET_ANTERIOR':vals['APP_SECRET_ANTERIOR']})
    A3=Cli(); A3.j('POST','/api/auth',{'action':'login','email':'admin@prod.com','password':'Senha@Forte123'})
    cof=A3.j('GET','/api/panel')[1].get('cofre') or {}
    check('após recuperar: painel sem credenciais ilegíveis', cof.get('ok') is True and cof.get('ilegiveis')==0, cof)
    st,sA,t,_=A3.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'status'}); sB=A3.j('POST',f'/api/v2/ads/{LB}/mp',{'action':'status'})[1]
    check('após recuperar: lojas A (OAuth) e B (manual) conectadas, sem reconectar, mesmas credenciais', sA.get('mpStatus')=='conectado' and not sA.get('credencialIlegivel') and sB.get('mpStatus')=='conectado' and (sA.get('mpMasked'),sB.get('mpMasked'))==masc, (t[:300],sB))
    check('após recuperar: credenciais no banco idênticas às de antes do incidente', credenciais()==antes)
    st,b,t,_=A3.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'verificar'}); check('após recuperar: Mercado Pago da loja A funcional (API recebe o token original)', b.get('ok') is True, t[:200])
    cfg=A3.j('GET','/api/panel')[1].get('mp_oauth',{}); check('após recuperar: configuração OAuth do painel intacta', cfg.get('clientId')=='1234567890123456' and cfg.get('temSecret') is True, cfg)
    st,b,t,_=A3.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'oauth'}); A3.j('GET',b['url']+'&conta=loja1')
    st,sA,t,_=A3.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'status'}); st,b,_,_=A3.j('POST',f'/api/v2/ads/{LA}/mp',{'action':'verificar'})
    check('após recuperar: OAuth das empresas funciona (troca de código com o Client Secret antigo)', sA.get('mpStatus')=='conectado' and sA.get('mpModo')=='oauth' and b.get('ok') is True, t[:300])
    st,b,t,_=A3.j('POST',f'/api/v2/ads/{LB}/mp',{'tok':'APP_USR-9999888877776666-novo-token-b'}); check('após recuperar: salvar Access Token manual funciona', b.get('mpStatus')=='conectado' and b.get('mpMasked','').endswith('en-b'), t[:200])
    # ======== 5) sem a chave em lugar nenhum
    prepara_pasta('ma',f'SQLITE_FILE={URL("ma")}\nAPP_SECRET={NOVO}\n')
    rc,out=recuperar('--aplicar')
    check('sem a chave original disponível: código 12, informa o que falta e não altera nada', rc==12 and 'NÃO foi encontrada' in out and 'NENHUMA candidata abre' in out and open(PASTA+'/.env').read()==f'SQLITE_FILE={URL("ma")}\nAPP_SECRET={NOVO}\n' and not any(f.startswith('env-antes') for f in os.listdir(PASTA+'/backups')), out[-1200:])
    # ======== 6) instalação sem APP_SECRET (chave do banco) cuja vault-key foi trocada
    sobe({'DATABASE_URL':URL('ma2')})
    C=Cli(); assert C.j('POST','/api/auth',{'action':'signup','name':'Admin Dois','email':'admin@dois.com','whatsapp':'+55 11 94444-0202',**U})[0]==200
    C.j('PUT','/api/panel/modules',{'empresas':True,'anuncios':True}); L2=loja(C,'Loja Banco','ma2')
    C.j('POST',f'/api/v2/ads/{L2}/mp',{'tok':'APP_USR-5555666677778888-loja-chave-banco'})
    prepara_pasta('ma2',f'SQLITE_FILE={URL("ma2")}\n'); dump('ma2',PASTA+'/backups/meuassistente-20261119-030000.sql.gz')
    pg("UPDATE app_config SET value = '\"%s\"' WHERE key = 'vault-key'" % os.urandom(32).hex(),'ma2')  # chave do banco trocada (como uma versão antiga fazia ao recriá-la)
    sobe({'DATABASE_URL':URL('ma2')})
    C2=Cli(); C2.j('POST','/api/auth',{'action':'login','email':'admin@dois.com','password':'Senha@Forte123'})
    check('chave do banco trocada: credencial ilegível', C2.j('POST',f'/api/v2/ads/{L2}/mp',{'action':'status'})[1].get('credencialIlegivel') is True)
    rc,out=recuperar('--aplicar'); env=open(PASTA+'/.env').read()
    check('chave do banco antiga achada no backup do banco e aplicada em APP_SECRET_ANTERIOR', rc==0 and 'backup do banco backups/meuassistente-20261119-030000.sql.gz (vault-key)' in out and 'APP_SECRET_ANTERIOR=' in env, (rc,out[-1200:]))
    vals=dict(l.split('=',1) for l in env.strip().split('\n')); sobe({'DATABASE_URL':URL('ma2'),'APP_SECRET_ANTERIOR':vals['APP_SECRET_ANTERIOR']})
    C3=Cli(); C3.j('POST','/api/auth',{'action':'login','email':'admin@dois.com','password':'Senha@Forte123'}); s2=C3.j('POST',f'/api/v2/ads/{L2}/mp',{'action':'status'})[1]
    check('após recuperar: loja com chave do banco conectada de novo', s2.get('mpStatus')=='conectado' and not s2.get('credencialIlegivel') and s2.get('mpMasked','').endswith('anco'), s2)
finally:
    if app: os.killpg(os.getpgid(app.pid),signal.SIGTERM)
    mp.terminate(); sh(f'su postgres -c "{PG}/pg_ctl -D {PGD} stop -m fast"')
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); sys.exit(0 if all(res) else 1)
