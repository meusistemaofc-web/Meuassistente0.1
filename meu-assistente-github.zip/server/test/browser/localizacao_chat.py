# Localização ⇄ chat: pedir empresas sem localização → botão; autorizar (GPS) ou digitar cidade na tela própria → volta ao chat
# e a MESMA mensagem vira os cards reais (sem botão antigo, sem duplicar), persistindo ao recarregar/reabrir; nenhuma empresa →
# ampliar raio / outra cidade; permissão negada → digitar cidade; alteração de raio/cidade atualiza; só empresas aprovadas.
# Requer o servidor iniciado com GEOCODER_URL apontando para test/browser/geocoder_fake.py (ver docs/LOCALIZACAO_CHAT.md).
import sys, json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
PERTO={'latitude':-23.575,'longitude':-46.63}   # ~2,8 km da pizzaria
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'agente':True,'catalogo':True}).ok
    mk=lambda d: A.post('/api/v2/ads',data=d).json()['items'][0]['id']
    PIZ=mk({'planId':'n4','empresa':'Pizzaria Bella','categoria':'Pizzaria','titulo':'Pizza artesanal','texto':'Forno a lenha','zap':'5511999990000','insta':'pizzariabella','horarioCfg':{'modo':'aberto','dias':{}},'lat':-23.55,'lng':-46.63,'raio':10})
    SUS=mk({'planId':'n2','empresa':'Pizzaria Suspensa','categoria':'Pizzaria','titulo':'X','texto':'x','zap':'5511999990001','lat':-23.551,'lng':-46.631,'raio':10})
    A.post(f'/api/v2/admin/ads/{SUS}',data={'action':'end'})
    BAR=mk({'planId':'n2','empresa':'Barbearia Norte','categoria':'Barbearia','titulo':'Corte e barba','texto':'x','zap':'5592999990000','lat':-3.1,'lng':-60.02,'raio':10})
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(PIZ,)).fetchone(); d=json.loads(row[0]); d['agente']={'nome':'Lia','ativo':True,'expiresAt':(datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat().replace('+00:00','Z')}
    db.execute('update businesses set data=? where id=?',(json.dumps(d),PIZ)); db.commit(); db.close()
    # proposta NÃO aprovada de outro usuário, bem perto: nunca pode aparecer
    o=b.new_context(base_url=BASE); O=o.request
    O.post('/api/auth',data={'action':'signup','name':'Dono Pendente','whatsapp':'+55 11 92222-1111','email':'pend@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'})
    O.post('/api/v2/ads',data={'planId':'n2','empresa':'Pizzaria Pendente','categoria':'Pizzaria','titulo':'X','texto':'x','zap':'5511911110000','lat':-23.574,'lng':-46.63,'raio':10}); o.close()

    def usuario(email,zap,geo):
        kw=dict(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True)
        if geo: kw.update(geolocation=geo,permissions=['geolocation'])
        c=b.new_context(**kw); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':'Cliente '+email[:3],'whatsapp':zap,'email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(800)
        return c,R,pg
    def perguntar(pg,t):
        pg.fill('textarea.composer-input',t); pg.keyboard.press('Enter'); pg.wait_for_timeout(3500)
    est=lambda pg: pg.evaluate("()=>[...document.querySelectorAll('.chat-scroll [data-loc-estado]')].map(x=>x.dataset.locEstado)")
    nmsg=lambda pg: pg.locator('.chat-scroll .msg-swipe').count()
    nomes=lambda pg: pg.evaluate("()=>[...document.querySelectorAll('.chat-scroll .ma-emp-cards .glass p.font-semibold')].map(x=>x.textContent.trim())")
    btnLoc=lambda pg: pg.locator('.chat-scroll a', has_text='Permitir localização e ver empresas').count()

    print('== 1-5: GPS autorizado')
    c,R,pg=usuario('gps@t.com','+55 11 96666-1111',PERTO)
    perguntar(pg,'pizzaria')
    check('1. sem localização: chat pede localização com o botão "Permitir localização e ver empresas"', btnLoc(pg)==1 and 'aguardando_autorizacao' in est(pg), est(pg))
    pg.screenshot(path='/tmp/e2e/localizacao_chat_pedido.png')
    n0=nmsg(pg); conv=pg.url
    pg.locator('.chat-scroll a', has_text='Permitir localização e ver empresas').click(); pg.wait_for_selector('#locok',timeout=8000)
    t=pg.inner_text('#ma-x')
    check('3. botão abre a tela própria de localização com as duas alternativas', 'Permitir localização' in t and pg.locator('#lai2').count()==1 and 'Usar' in t)
    pg.click('#locok')
    try: pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); ok=True
    except Exception: ok=False
    check('2/4. autorizou → volta ao chat sozinho e a resposta vira os cards (sem nova pergunta, sem recarregar)', ok and pg.url==conv and pg.locator('#ma-x').count()==0, pg.url)
    pg.wait_for_timeout(800)
    check('botão de autorização e pedido pendente removidos; sem mensagens duplicadas', btnLoc(pg)==0 and nmsg(pg)==n0 and 'aguardando_autorizacao' not in est(pg) and 'empresas_encontradas' in est(pg), (btnLoc(pg),nmsg(pg),n0,est(pg)))
    nm=nomes(pg); txt=pg.inner_text('.chat-scroll')
    check('5. empresa real da região; suspensa e não aprovada não aparecem', nm==['Pizzaria Bella'] and 'Pizzaria Suspensa' not in txt and 'Pizzaria Pendente' not in txt, nm)
    card=pg.inner_text('.chat-scroll .ma-emp-cards .glass')
    check('card no padrão "Empresas parceiras": logo, nome, descrição, distância, categoria, situação e patrocinado', 'Pizzaria Bella' in card and 'Forno a lenha' in card and 'km' in card and 'Pizzaria' in card and ('Aberto' in card or 'Fechado' in card) and 'Patrocinado' in card, card)
    check('ações conforme o plano: catálogo/pedido, conversar (agente ativo), WhatsApp e Instagram', pg.locator('.chat-scroll .ma-emp-cards a', has_text='Ver cardápio e pedir').count()==1 and pg.locator('.chat-scroll .ma-emp-cards a', has_text='Conversar').count()==1 and pg.locator('.chat-scroll .ma-emp-cards a[aria-label="WhatsApp"]').count()==1 and pg.locator('.chat-scroll .ma-emp-cards a[aria-label="Instagram"]').count()==1)
    pg.screenshot(path='/tmp/e2e/localizacao_chat_resultado.png')
    db=sqlite3.connect(DBF); cont=[r[0] for r in db.execute("select content from messages where role='assistant' and content like '%pizzaria%' or content like '%Encontrei%'")]; db.close()
    check('a mensagem original foi reescrita no banco (sem criar outra)', any('⟦emp:' in x for x in cont) and not any('⟦loc:' in x for x in cont), cont)
    # mesma fonte de dados da página Empresas parceiras
    pr=R.get('/api/v2/businesses/search?q=pizzaria').json()
    check('mesma busca e critérios da página "Empresas parceiras"', [x['empresa'] for x in pr['items']]==nm, pr['items'])
    pg.reload(); pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); pg.wait_for_timeout(800)
    check('recarregar: cards continuam, sem botão de autorização', nomes(pg)==['Pizzaria Bella'] and btnLoc(pg)==0)
    pg.goto('/'); pg.wait_for_timeout(1200); pg.goto(conv); pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000)
    check('9. reabrir a conversa: resultado preservado', nomes(pg)==['Pizzaria Bella'] and btnLoc(pg)==0)

    print('== 8/10: alteração do raio atualiza os resultados')
    pg.goto('/x/empresas'); pg.wait_for_selector('#lraio',timeout=10000); pg.select_option('#lraio','1'); pg.wait_for_timeout(1500)
    pg.go_back(); pg.wait_for_timeout(500)
    if '/x/' in pg.url: pg.goto(conv)
    try: pg.wait_for_selector('.chat-scroll [data-loc-estado="nenhuma_empresa"]',timeout=15000); ok=True
    except Exception: ok=False
    check('10. raio reduzido para 1 km → a resposta da conversa é atualizada: nenhuma empresa na região', ok and nomes(pg)==[] and btnLoc(pg)==0, est(pg))
    t=pg.inner_text('.chat-scroll')
    check('6. sem empresas: informa e oferece ampliar o raio ou outra cidade (sem botão de autorização)', 'Não encontrei empresas disponíveis' in t and pg.locator('[data-loc-raio]').count()==1 and pg.locator('[data-loc-cidade]').count()==1 and btnLoc(pg)==0)
    pg.screenshot(path='/tmp/e2e/localizacao_chat_nenhuma.png')
    pg.click('[data-loc-raio]'); pg.wait_for_timeout(2500)
    if pg.locator('[data-loc-raio]').count(): pg.click('[data-loc-raio]'); pg.wait_for_timeout(2500)
    check('8. "Ampliar o raio" atualiza a mesma resposta até encontrar a empresa', nomes(pg)==['Pizzaria Bella'] and nmsg(pg)==n0, (nomes(pg),est(pg)))
    c.close()

    print('== 3/6/8: nenhuma empresa e outra cidade digitada')
    c,R,pg=usuario('cid@t.com','+55 11 96666-2222',PERTO)
    R.put('/api/v2/me/location',data={'lat':PERTO['latitude'],'lng':PERTO['longitude']}); pg.reload(); pg.wait_for_selector('textarea.composer-input',timeout=20000)
    perguntar(pg,'barbearia')
    check('com localização já autorizada, responde direto (sem pedir de novo); nenhuma barbearia perto', btnLoc(pg)==0 and 'nenhuma_empresa' in est(pg), est(pg))
    n0=nmsg(pg); conv=pg.url
    pg.click('[data-loc-cidade]'); pg.wait_for_selector('#laddr',timeout=10000); pg.click('#laddr'); pg.fill('#lai','Manaus'); pg.locator('#laf button').click()
    try: pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); ok=True
    except Exception: ok=False
    check('3. cidade digitada → volta ao chat e a resposta mostra a empresa da nova cidade', ok and pg.url==conv and nomes(pg)==['Barbearia Norte'] and nmsg(pg)==n0, (pg.url,nomes(pg)))
    c.close()

    print('== 7: permissão negada')
    c,R,pg=usuario('neg@t.com','+55 11 96666-3333',None)
    perguntar(pg,'pizzaria'); n0=nmsg(pg); conv=pg.url
    pg.locator('.chat-scroll a', has_text='Permitir localização e ver empresas').click(); pg.wait_for_selector('#locok',timeout=8000); pg.click('#locok'); pg.wait_for_timeout(2500)
    m=pg.inner_text('#locmsg')
    check('7. permissão negada: informa que não foi concedida e mantém a opção de digitar', 'não permitiu' in m.lower() and pg.locator('#lai2').is_visible(), m)
    pg.go_back(); pg.wait_for_timeout(600)
    if '/x/' in pg.url: pg.goto(conv)
    pg.wait_for_selector('.chat-scroll [data-loc-estado="negada"]',timeout=10000)
    check('de volta ao chat: estado "negada" com campo de bairro/cidade, chat segue funcionando', pg.locator('.chat-scroll [data-loci]').count()==1 and pg.locator('textarea.composer-input').is_enabled())
    pg.fill('.chat-scroll [data-loci]','Centro, São Paulo'); pg.locator('.chat-scroll [data-locf] button').click()
    try: pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); ok=True
    except Exception: ok=False
    check('cidade digitada no próprio chat → a mesma resposta vira os cards', ok and nomes(pg)==['Pizzaria Bella'] and btnLoc(pg)==0 and nmsg(pg)==n0, (nomes(pg),est(pg)))
    perguntar(pg,'qual a capital da frança?')
    check('chat continua respondendo normalmente depois', nmsg(pg)>=n0+2)
    c.close()
    print('== 3: cidade digitada na tela de localização ("Usar")')
    c,R,pg=usuario('man@t.com','+55 11 96666-5555',None)
    perguntar(pg,'pizzaria'); n1=nmsg(pg); conv2=pg.url
    pg.locator('.chat-scroll a', has_text='Permitir localização e ver empresas').click(); pg.wait_for_selector('#lai2',timeout=8000)
    pg.fill('#lai2','Centro, São Paulo'); pg.locator('#laf2 button').click()
    try: pg.wait_for_selector('.chat-scroll .ma-emp-cards',timeout=15000); ok=True
    except Exception: ok=False
    check('3. bairro/cidade + "Usar" → volta ao chat com os cards na mesma resposta', ok and pg.url==conv2 and nomes(pg)==['Pizzaria Bella'] and btnLoc(pg)==0 and nmsg(pg)==n1, (pg.url,nomes(pg)))
    loc=R.get('/api/v2/businesses/search?q=pizzaria').json()['location']
    check('localização manual persistida (rótulo da cidade)', 'Centro' in loc['label'], loc)
    c.close()
    # isolamento: outro usuário não reescreve conversa alheia
    c,R,pg=usuario('iso@t.com','+55 11 96666-4444',None)
    r=R.post('/api/v2/chat/empresas',data={'conversationId':conv.split('c=')[1]})
    check('outro usuário não acessa nem altera a conversa alheia (404)', r.status==404, r.status)
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
