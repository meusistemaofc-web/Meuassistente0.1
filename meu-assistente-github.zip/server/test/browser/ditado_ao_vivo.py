# Ditado com transcrição AO VIVO (reconhecimento de fala do aparelho), pela tela real do chat. A API de reconhecimento do
# navegador é simulada (resultados parciais chegando como num aparelho); o app é o real.
# • tocar no microfone: "Ouvindo… fale agora" aparece na hora e o texto vai surgindo NO CAMPO enquanto se fala;
# • nada vai para /api/transcribe (sem gravar, enviar e esperar transcrição);
# • tocar em enviar durante a fala: envia NA HORA o texto já transcrito (uma mensagem só, sem duplicar) e encerra a escuta;
# • parar o ditado: o texto fica no campo para corrigir; a correção é o que vai no envio;
# • cancelar: volta ao texto que havia antes; digitar normalmente depois;
# • fala longa com pausas não é cortada (a escuta só encerra sozinha depois de 6 s de silêncio);
# • celular (390 px) e computador; sem erros de JavaScript.
# Servidor: PORT=4348 SQLITE_FILE=/tmp/ma-dav.db npx tsx test/serve-sqlite.ts (banco novo)
import re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4348'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
# reconhecimento de fala do aparelho (simulado): parciais a cada 300 ms; window.__fala define o que é "dito"
FAKE = r"""(()=>{class Rec{constructor(){this.lang='';this.continuous=false;this.interimResults=false;this._t=[];window.__recCriados=(window.__recCriados||0)+1}
 start(){if(window.__falhaInicio==='not-allowed'){setTimeout(()=>{this.onerror&&this.onerror({error:'not-allowed'});this.onend&&this.onend()},30);return}if(window.__falhaInicio==='mudo')return;window.__recInicios=(window.__recInicios||0)+1;window.__recAtivo=this;this._ok=true;setTimeout(()=>this.onstart&&this.onstart(),20);
  const partes=(window.__fala||'quero marcar dentista amanhã às dez').split(' ');let i=0;
  const tick=()=>{if(!this._ok)return;i++;const fin=i>=partes.length&&window.__falaFinal!==false;const res=[{0:{transcript:partes.slice(0,i).join(' ')},isFinal:fin,length:1}];this.onresult&&this.onresult({results:res,resultIndex:0});if(i<partes.length)this._t.push(setTimeout(tick,window.__ritmo||300))};
  this._t.push(setTimeout(tick,150))}
 _fim(){this._ok=false;this._t.forEach(clearTimeout);setTimeout(()=>{this.onend&&this.onend();if(window.__recAtivo===this)window.__recAtivo=null},20)}
 stop(){window.__recParadas=(window.__recParadas||0)+1;this._fim()}
 abort(){window.__recAbortos=(window.__recAbortos||0)+1;this._fim()}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec;
 const oq=navigator.permissions.query.bind(navigator.permissions);navigator.permissions.query=d=>d&&d.name==='microphone'?Promise.resolve({get state(){return window.__permMic||'granted'},onchange:null}):oq(d)})()"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, permissions=['microphone']); C.add_init_script(FAKE); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Vera Teste', 'whatsapp': f'+55 11 95555-{k}{k}{k}{k}', 'email': f'vera{k}.dav@t.com', **U}, headers={'X-Forwarded-For': f'10.9.7.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios, transc = [], []
        pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        pg.on('request', lambda r: transc.append(r.url) if '/api/transcribe' in r.url else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(400)
        campo = lambda: pg.input_value('textarea[data-composer-input]')
        mic = lambda: pg.locator('button[aria-label="Ditar mensagem"], button[aria-label="Parar ditado"]').first
        enviar_btn = lambda: pg.locator('button[aria-label="Enviar"]').first
        bolhas_user = lambda: [t.strip() for t in pg.locator('.chat-scroll .bubble-user').all_inner_texts()]
        # 1) fala aparece no campo enquanto se fala; envio imediato do texto já transcrito
        pg.evaluate("window.__fala='quero marcar dentista amanhã às dez da manhã';window.__falaFinal=false")
        t0 = pg.evaluate('Date.now()'); mic().click()
        pg.wait_for_selector('text=Ouvindo… fale agora', timeout=3000); t_ind = pg.evaluate('Date.now()') - t0
        amostras = []
        for i in range(14): amostras.append(campo()); pg.wait_for_timeout(150)
        cresceu = [a for j, a in enumerate(amostras) if a and (j == 0 or a != amostras[j - 1])]
        check(f'{nome}: microfone começa na hora (indicador de gravação em {t_ind} ms)', t_ind < 1000, t_ind)
        check(f'{nome}: o texto vai aparecendo no campo enquanto a pessoa fala', len(cresceu) >= 3 and all(len(cresceu[j]) > len(cresceu[j - 1]) for j in range(1, len(cresceu))), cresceu)
        texto_na_hora = campo()
        n0 = len(bolhas_user()); te = pg.evaluate('Date.now()'); enviar_btn().click()
        pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .bubble-user').length>{n0}", timeout=5000); t_env = pg.evaluate('Date.now()') - te
        pg.wait_for_timeout(1500)
        ultimas = bolhas_user()[n0:]
        check(f'{nome}: enviar durante a fala manda na hora o texto já transcrito ({t_env} ms)', t_env < 1500 and len(ultimas) == 1 and texto_na_hora and texto_na_hora in ultimas[0], (t_env, texto_na_hora, ultimas))
        check(f'{nome}: escuta encerrada ao enviar, campo limpo, sem indicador de gravação', not pg.evaluate('!!window.__recAtivo') and campo() == '' and pg.locator('text=Ouvindo… fale agora').count() == 0, (campo(), pg.evaluate('window.__recAtivo&&1')))
        check(f'{nome}: nada passou por /api/transcribe (sem gravar e esperar transcrição)', not transc, transc)
        pg.wait_for_timeout(1500)
        check(f'{nome}: uma mensagem só (sem duplicar o envio)', len(bolhas_user()[n0:]) == 1 and sum(1 for e in envios if 'dentista' in e) == 1, (bolhas_user()[n0:], len(envios)))
        # 2) parar: texto fica no campo para corrigir; a correção é o que vai
        pg.evaluate("window.__fala='comprei pão e leite no mercado';window.__falaFinal=true")
        mic().click(); pg.wait_for_selector('text=Ouvindo… fale agora', timeout=3000)
        pg.wait_for_function("()=>document.querySelector('textarea[data-composer-input]').value.includes('mercado')", timeout=6000)
        mic().click(); pg.wait_for_timeout(500)
        check(f'{nome}: parar o ditado deixa o texto no campo, editável', campo().lower() == 'comprei pão e leite no mercado' and not pg.evaluate("document.querySelector('textarea[data-composer-input]').readOnly") and pg.locator('text=Ouvindo… fale agora').count() == 0, campo())
        pg.fill('textarea[data-composer-input]', 'comprei pão, leite e café no mercado')
        n0 = len(bolhas_user()); enviar_btn().click(); pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .bubble-user').length>{n0}", timeout=5000); pg.wait_for_timeout(800)
        check(f'{nome}: a correção feita no campo é o que vai na mensagem', 'café' in bolhas_user()[-1], bolhas_user()[-1:])
        # 3) cancelar: volta ao texto anterior e segue digitando normalmente
        pg.wait_for_timeout(1500)
        pg.fill('textarea[data-composer-input]', 'lembrar de ')
        pg.evaluate("window.__fala='isso não deveria ficar';window.__falaFinal=false")
        mic().click(); pg.wait_for_selector('text=Ouvindo… fale agora', timeout=3000); pg.wait_for_timeout(700)
        pg.locator('button:has-text("Cancelar")').first.click(); pg.wait_for_timeout(400)
        check(f'{nome}: cancelar volta ao texto que havia antes', campo() == 'lembrar de ' and not pg.evaluate('!!window.__recAtivo'), campo())
        pg.locator('textarea[data-composer-input]').press_sequentially('pagar a luz')
        check(f'{nome}: depois de cancelar, digita normalmente', campo() == 'lembrar de pagar a luz', campo())
        pg.fill('textarea[data-composer-input]', '')
        # 4) fala com pausa: não corta antes de 6 s de silêncio
        pg.evaluate("window.__fala='primeira parte da fala segunda parte';window.__ritmo=1200;window.__falaFinal=false")
        mic().click(); pg.wait_for_selector('text=Ouvindo… fale agora', timeout=3000); pg.wait_for_timeout(5200)
        check(f'{nome}: pausas de 1,2 s entre palavras não encerram a escuta', pg.locator('text=Ouvindo… fale agora').count() == 1 and 'segunda' in campo(), campo())
        pg.wait_for_timeout(7200)
        check(f'{nome}: depois de 6 s de silêncio a escuta encerra sozinha e o texto fica', pg.locator('text=Ouvindo… fale agora').count() == 0 and campo().lower() == 'primeira parte da fala segunda parte', campo())
        pg.evaluate('window.__ritmo=300'); pg.fill('textarea[data-composer-input]', '')
        if mob: pg.screenshot(path='/tmp/e2e/ditado_ao_vivo.png')
        if not mob:
            # microfone bloqueado no reconhecimento do aparelho: explica como liberar
            pg.evaluate("window.__falhaInicio='not-allowed';window.__permMic='denied'")
            mic().click(); pg.wait_for_timeout(800); corpo = pg.inner_text('body')
            check(f'{nome}: microfone bloqueado → explica como liberar (sem ficar preso)', 'microfone' in corpo.lower() and ('bloqueado' in corpo or 'Libere' in corpo) and pg.locator('text=Ouvindo… fale agora').count() == 0 and pg.locator('text=Preparando o microfone').count() == 0, corpo[-200:])
            # microfone liberado, mas o reconhecimento de fala do aparelho recusado (Siri/Ditado desligados): passa para a transcrição do servidor
            pg.evaluate("window.__permMic='granted'"); pg.wait_for_timeout(300)
            mic().click(); pg.wait_for_timeout(1200); corpo = pg.inner_text('body')
            check(f'{nome}: só o reconhecimento do aparelho recusado → usa a transcrição do Meu Assistente (não diz que o microfone está bloqueado)', 'usando a transcrição do Meu Assistente' in corpo or 'Nenhum microfone' in corpo, corpo[-200:])
            if pg.locator('[role="status"] button:has-text("Cancelar")').count(): pg.locator('[role="status"] button:has-text("Cancelar")').first.click()
            pg.evaluate("try{localStorage.removeItem('nx-voice-engine')}catch(e){}")
            # reconhecimento do aparelho que não responde: em 4 s passa para a gravação com transcrição no servidor
            pg.evaluate("window.__falhaInicio='mudo'"); pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
            mic().click(); pg.wait_for_timeout(5500); corpo = pg.inner_text('body')
            check(f'{nome}: reconhecimento que não responde não trava: troca para a transcrição do Meu Assistente', pg.locator('text=Preparando o microfone').count() == 0 and ('usando a transcrição do Meu Assistente' in corpo or 'Ouvindo… fale agora' in corpo or 'microfone' in corpo.lower()), corpo[-200:])
            if pg.locator('button:has-text("Cancelar")').count(): pg.locator('button:has-text("Cancelar")').first.click()
            pg.evaluate("window.__falhaInicio=''")
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
