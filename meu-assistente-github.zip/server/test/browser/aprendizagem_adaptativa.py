# Aprendizagem adaptativa: conversa real → aprendizado silencioso → tela "Aprendizados" (editar, pausar, excluir, desligar) → nova conversa → painel do administrador.
import sys
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    ctx=b.new_context(viewport={'width':430,'height':900},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    def enviar(t):
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2500)
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('Não faça o agendamento antes de verificar a disponibilidade.')
    corpo=pg.inner_text('body')
    check('o chat responde de forma natural', 'Vou conferir a disponibilidade antes de seguir' in corpo, corpo[-300:])
    check('o chat NÃO anuncia memória/aprendizado', not any(x in corpo.lower() for x in ['aprendizado registrado','memória','estou aprendendo','regra salva']), corpo[-300:])
    itens=R.get('/api/learning').json()['itens']; check('aprendizado gravado no servidor (persistente)', len(itens)==1 and itens[0]['operacao']=='agendamento', itens)
    # nova conversa: a mesma preferência aparece no comportamento
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('quero marcar uma reunião amanhã')
    corpo=pg.inner_text('body'); check('nova conversa: confere a disponibilidade sem mencionar a memória', 'Vou conferir os horários disponíveis primeiro' in corpo and 'memória' not in corpo.lower(), corpo[-300:])
    # tela Aprendizados
    pg.goto('/x/aprendizados'); pg.wait_for_selector('[data-apr]',timeout=15000); pg.wait_for_timeout(500)
    t=pg.inner_text('#ma-x'); check('tela lista a regra com operação, escopo e confiança', 'Antes de agendar, conferir a disponibilidade' in t and 'Agendamentos' in t and 'Sempre' in t and 'confiança' in t, t[:400])
    pg.click('[data-apre]'); pg.fill('[data-aprin]','Antes de agendar, mostrar os horários livres do dia.'); pg.click('[data-aprs]'); pg.wait_for_timeout(1200)
    check('editar o aprendizado', 'mostrar os horários livres' in pg.inner_text('#ma-x'), pg.inner_text('#ma-x')[:300])
    pg.click('[data-aprp]'); pg.wait_for_timeout(1000); check('pausar', 'Pausado' in pg.inner_text('#ma-x'))
    check('pausado deixa de ser aplicado (servidor)', R.get('/api/learning').json()['itens'][0]['estado']=='pausado')
    pg.click('[data-aprp]'); pg.wait_for_timeout(1000); check('reativar', 'Pausado' not in pg.inner_text('#ma-x'))
    pg.click('#apr_t'); pg.wait_for_timeout(1000); check('desligar "aprender com minhas correções"', pg.locator('#apr_t').inner_text()=='Desligado' and R.get('/api/learning').json()['ativo'] is False)
    pg.click('#apr_t'); pg.wait_for_timeout(1000); check('religar', pg.locator('#apr_t').inner_text()=='Ligado')
    pg.click('[data-aprx]'); pg.wait_for_timeout(1200); check('excluir', 'Nada aprendido ainda' in pg.inner_text('#ma-x') and R.get('/api/learning').json()['itens']==[])
    # menu lateral tem a entrada
    pg.goto('/'); pg.wait_for_selector('[aria-label="Abrir menu"]',timeout=15000); pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(1500)
    check('menu tem "Aprendizados"', pg.get_by_text('Aprendizados').count()>=1)
    # painel do administrador: cartão da capacidade e chave
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Cérebro e busca').click(); pg.wait_for_selector('#cap_l [data-cap]',timeout=10000)
    c=pg.locator('[data-cap=aprendizagem-adaptativa]'); check('capacidade aparece no Cérebro', c.count()==1 and 'Aprendizagem adaptativa' in c.inner_text(), c.inner_text() if c.count() else '')
    c.locator('[data-agtog]').click(); pg.wait_for_timeout(1200)
    check('administrador desliga a capacidade', R.get('/api/panel/aprendizagem').json()['ativo'] is False and 'Desligada pelo administrador' in pg.locator('[data-cap=aprendizagem-adaptativa]').inner_text(), pg.locator('[data-cap=aprendizagem-adaptativa]').inner_text())
    pg.locator('[data-cap=aprendizagem-adaptativa] [data-agtog]').click(); pg.wait_for_timeout(1200)
    check('administrador religa a capacidade', R.get('/api/panel/aprendizagem').json()['ativo'] is True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/aprendizados.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
