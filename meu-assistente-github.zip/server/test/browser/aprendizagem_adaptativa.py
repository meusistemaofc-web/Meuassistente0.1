# Aprendizagem adaptativa: conversa real → aprendizado silencioso → sem tela/menu do usuário → controle global no painel do administrador.
import sys
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    ctx=b.new_context(viewport={'width':430,'height':900},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); ANS=['']; pg.on('dialog',lambda d:d.accept(ANS[0]))
    def enviar(t):
        ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2500)
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('Não faça o agendamento antes de verificar a disponibilidade.')
    corpo=pg.inner_text('body')
    check('o chat responde de forma natural', 'Vou conferir a disponibilidade antes de seguir' in corpo, corpo[-300:])
    check('o chat NÃO anuncia memória/aprendizado', not any(x in corpo.lower() for x in ['aprendizado registrado','memória','estou aprendendo','regra salva']), corpo[-300:])
    itens=R.get('/api/learning').json()['itens']; check('aprendizado gravado no servidor (persistente)', len(itens)==1 and itens[0]['operacao']=='agendamento', itens)
    # nova conversa: a mesma preferência aparece no comportamento
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
    enviar('quero marcar uma reunião amanhã')
    corpo=pg.inner_text('body'); check('nova conversa: confere a disponibilidade sem mencionar a memória', 'Vou conferir os horários disponíveis primeiro' in corpo and 'memória' not in corpo.lower(), corpo[-300:])
    # Aprendizados é institucional: sem tela, sem menu e sem chave individual
    pg.goto('/x/aprendizados'); pg.wait_for_timeout(2500)
    check('a rota antiga /x/aprendizados não abre tela (volta ao chat)', pg.locator('[data-apr]').count()==0 and pg.locator('#apr_t').count()==0 and '/x/aprendizados' not in pg.url, pg.url)
    pg.goto('/'); pg.wait_for_selector('[aria-label="Abrir menu"]',timeout=15000); pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(1500)
    check('menu do usuário NÃO tem "Aprendizados"', pg.get_by_text('Aprendizados',exact=True).count()==0)
    check('usuário comum não consegue ligar/desligar (servidor)', R.post('/api/learning',data={'action':'settings','ativo':False}).status==403 and R.get('/api/learning').json()['ativo'] is True)
    check('dados já registrados preservados', len(R.get('/api/learning').json()['itens'])==1)
    # gestão dos próprios itens continua pela API (dados do usuário)
    it=R.get('/api/learning').json()['itens'][0]
    check('editar/pausar/excluir seguem funcionando na API', R.post('/api/learning',data={'action':'update','id':it['id'],'estado':'pausado'}).ok and R.post('/api/learning',data={'action':'update','id':it['id'],'estado':'ativo'}).ok)
    # painel do administrador: cartão da capacidade e chave
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_conhecimento'); pg.wait_for_selector('#cap_l [data-cap]',timeout=10000)
    c=pg.locator('[data-cap=aprendizagem-adaptativa]'); check('capacidade aparece no Cérebro', c.count()==1 and 'Aprendizagem adaptativa' in c.inner_text(), c.inner_text() if c.count() else '')
    c.locator('[data-agtog]').click(); pg.wait_for_timeout(1200)
    check('administrador desliga a capacidade', R.get('/api/panel/aprendizagem').json()['ativo'] is False and 'Desligada pelo administrador' in pg.locator('[data-cap=aprendizagem-adaptativa]').inner_text(), pg.locator('[data-cap=aprendizagem-adaptativa]').inner_text())
    pg.locator('[data-cap=aprendizagem-adaptativa] [data-agtog]').click(); pg.wait_for_timeout(1200)
    check('administrador religa a capacidade', R.get('/api/panel/aprendizagem').json()['ativo'] is True)
    # controle global "Aprendizados" no painel (ativar/desativar, status, última alteração e responsável)
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_aprendizados'); pg.wait_for_selector('#apr_on',timeout=10000)
    check('painel mostra status Ativado e botões', 'Ativado' in pg.inner_text('#apr_box') and pg.locator('#apr_off').is_enabled() and pg.locator('#apr_on').is_disabled())
    pg.click('#apr_off'); pg.wait_for_timeout(1500)
    st=R.get('/api/panel/aprendizagem').json()
    check('Desativar: global desligado, com data e administrador responsável', st['ativo'] is False and st['atualizadoEm'] and st['atualizadoPor']['nome'] and 'Desativado' in pg.inner_text('#apr_box') and 'Admin Teste' in pg.inner_text('#apr_meta'), st)
    n=len(R.get('/api/learning').json()['itens']); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1000); enviar('Sempre confirme comigo antes de excluir qualquer coisa.')
    check('desativado: nenhum novo aprendizado e os antigos preservados', len(R.get('/api/learning').json()['itens'])==n, R.get('/api/learning').json()['itens'])
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_aprendizados'); pg.wait_for_selector('#apr_on',timeout=10000); pg.click('#apr_on'); pg.wait_for_timeout(1500)
    check('Ativar: global ligado de novo', R.get('/api/panel/aprendizagem').json()['ativo'] is True and 'Ativado' in pg.inner_text('#apr_box'))
    # fila de revisão do administrador (aprovar / editar / rejeitar)
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg,'cb_aprendizados'); pg.wait_for_selector('#apr_rev [data-apr]',timeout=10000)
    check('fila mostra aprendizados pendentes com usuário e regra', pg.locator('#apr_rev [data-apr]').count()>=1 and 'pendente' in pg.inner_text('#apr_rev').lower(), pg.inner_text('#apr_rev')[:300])
    rid=pg.locator('#apr_rev [data-apr]').first.get_attribute('data-apr')
    pg.locator('#apr_rev [data-apr]').first.locator('[data-ra=aprovar]').click(); pg.wait_for_timeout(1200)
    fila=R.get('/api/panel/aprendizagem/fila?status=aprovado').json()['itens']; check('Aprovar muda o status no servidor', any(str(i['id'])==rid for i in fila), fila)
    pg.locator('#apr_rev [data-aprf=aprovado]').click(); pg.wait_for_timeout(1000)
    ANS[0]='Antes de agendar, conferir a agenda e confirmar o horário.'
    pg.locator('#apr_rev [data-apr]').first.locator('[data-ra=editar]').click(); pg.wait_for_timeout(1200)
    ed=R.get('/api/panel/aprendizagem/fila?status=editado').json()['itens']; check('Editar altera a regra e guarda a original', any('conferir a agenda' in i['regra'] and i['regraOriginal'] for i in ed), ed)
    pg.locator('#apr_rev [data-aprf=editado]').click(); pg.wait_for_timeout(1000)
    pg.locator('#apr_rev [data-apr]').first.locator('[data-ra=rejeitar]').click(); pg.wait_for_timeout(1200)
    rj=R.get('/api/panel/aprendizagem/fila?status=rejeitado').json()['itens']; check('Rejeitar marca como rejeitado (dado do usuário preservado)', len(rj)>=1 and len(R.get('/api/learning').json()['itens'])>=1, rj)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    pg.screenshot(path='/tmp/e2e/aprendizados.png'); b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
