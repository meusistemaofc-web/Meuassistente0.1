import json, sys, re
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'  # ajuste se usar outra porta
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    dlg={'accept':True,'msgs':[]}
    pg.on('dialog',lambda d:(dlg['msgs'].append(d.message),d.accept() if dlg['accept'] else d.dismiss()))
    pg.goto('/admin'); pg.wait_for_timeout(1500)
    aba(pg,'cb_conhecimento'); pg.wait_for_selector('#bn_box',timeout=10000)
    # 1) conhecimento de consulta
    pg.fill('#bn_t','Prazo de reembolso'); pg.fill('#bn_c','O reembolso é feito em até 7 dias úteis.'); pg.click('#bn_go')
    pg.wait_for_selector('[data-it]',timeout=8000); pg.wait_for_timeout(400)
    row=pg.locator('[data-it]').first.inner_text()
    check('UI: conhecimento cadastrado aparece ativo, com natureza, escopo, prioridade e versão', all(x in row for x in ['Prazo de reembolso','ativo','Consulta','prioridade 70','v1','Chat do usuário']), row)
    # 2) conflito: fica pendente se o admin cancelar a confirmação
    dlg['accept']=False
    pg.fill('#bn_t','Prazo de reembolso dos pedidos'); pg.fill('#bn_c','O reembolso é feito em até 30 dias úteis.'); pg.fill('#bn_p','40'); pg.click('#bn_go'); pg.wait_for_timeout(1200)
    check('UI: conflito de valores é avisado ao cadastrar', dlg['msgs'] and 'Contradição' in dlg['msgs'][-1] and '7' in dlg['msgs'][-1], dlg['msgs'])
    pg.get_by_role('button',name='Pendentes').click(); pg.wait_for_timeout(700)
    pend=pg.locator('[data-it]').first.inner_text()
    check('UI: ao cancelar, o item fica pendente para revisão', 'pendente' in pend and 'prioridade 40' in pend, pend)
    dlg['accept']=True
    pg.locator('[data-it]').first.get_by_role('button',name='Aprovar').click(); pg.wait_for_timeout(1200)
    check('UI: aprovar pede confirmação listando o conflito', 'Conflitos' in dlg['msgs'][-1] or 'Contradição' in dlg['msgs'][-1], dlg['msgs'][-1])
    # 3) regra executável pela tela
    pg.get_by_role('button',name='Tudo',exact=True).click(); pg.wait_for_timeout(500)
    pg.fill('#bn_t','Recusar política'); pg.select_option('#bn_n','executavel'); pg.select_option('#bn_acao','bloquear')
    pg.fill('#bn_gat','quero conversar sobre politica'); pg.fill('#bn_msg','Não trato desse assunto por aqui.'); pg.fill('#bn_c','Evita discussões políticas no chat.')
    vis=pg.evaluate("()=>({rule:getComputedStyle(document.querySelector('#bn_rule')).display, msg:getComputedStyle(document.querySelector('[data-ac=bloquear]')).display, mod:getComputedStyle(document.querySelector('[data-ac=abrir_modulo]')).display})")
    check('UI: campos da regra aparecem só para a ação escolhida', vis['rule']!='none' and vis['msg']!='none' and vis['mod']=='none', vis)
    pg.screenshot(path='/tmp/e2e/brain_form.png',full_page=False)
    pg.click('#bn_go'); pg.wait_for_timeout(1200)
    pg.get_by_role('button',name='Regra executável',exact=True).first.click(); pg.wait_for_timeout(700)
    rr=pg.locator('[data-it]').first.inner_text()
    check('UI: regra executável listada com ação, gatilho e público', all(x in rr for x in ['Recusar política','Regra executável','quero conversar sobre politica','público: todos']), rr)
    # 4) a regra criada pela tela vale no chat (sem IA)
    u=ctx.browser.new_context(base_url=BASE); UR=u.request
    assert UR.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 95555-1234','email':'cli@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'},headers={'X-Forwarded-For':'10.0.0.9'}).ok
    c=UR.post('/api/chat',data={'text':'Quero conversar sobre política','conversationId':'11111111-2222-4333-8444-555555555555'}).json()
    check('regra criada pela tela é cumprida no chat', c['assistantMessage']['content']=='Não trato desse assunto por aqui.', c)
    # 5) detalhes, desativar e reativar
    pg.get_by_role('button',name='Tudo',exact=True).click(); pg.wait_for_timeout(400); pg.get_by_role('button',name='Todas as naturezas').click(); pg.wait_for_timeout(500)
    first=pg.locator('[data-it]',has_text='Prazo de reembolso').last
    first.get_by_role('button',name='Detalhes').click(); pg.wait_for_timeout(900)
    det=first.inner_text()
    check('UI: detalhes mostram versões, histórico, uso e conflitos', all(x in det for x in ['Versões','Histórico','Onde foi usado','Conflitos']), det[:300])
    pg.get_by_role('button',name='Regra executável',exact=True).first.click(); pg.wait_for_timeout(600)
    pg.locator('[data-it]').first.get_by_role('button',name='Desativar').click(); pg.wait_for_timeout(1000)
    c2=UR.post('/api/chat',data={'text':'Quero conversar sobre política','conversationId':'11111111-2222-4333-8444-555555555555'}).json()
    check('regra desativada pela tela deixa de valer', c2['assistantMessage']['content']!='Não trato desse assunto por aqui.', c2['assistantMessage']['content'])
    pg.get_by_role('button',name='Desativados').click(); pg.wait_for_timeout(600)
    pg.locator('[data-it]').first.get_by_role('button',name='Reativar').click(); pg.wait_for_timeout(1000)
    c3=UR.post('/api/chat',data={'text':'Quero conversar sobre política','conversationId':'11111111-2222-4333-8444-555555555555'}).json()
    check('regra reativada volta a valer', c3['assistantMessage']['content']=='Não trato desse assunto por aqui.', c3['assistantMessage']['content'])
    # 6) conflitos + uso recente
    pg.get_by_role('button',name='Verificar agora').click(); pg.wait_for_timeout(1000)
    cr=pg.locator('#bc_r').inner_text()
    check('UI: verificação de conflitos lista a contradição', 'Contradição' in cr, cr)
    ub=pg.locator('#bu_box').inner_text()
    check('UI: uso recente mostra regra e resposta influenciada', 'bloqueou' in ub and 'Recusar política' in ub, ub)
    pg.locator('#bu_box').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/brain_uso.png')
    errs=[e for e in errs if 'React error #418' not in e and e!='Event']
    check('sem erros de JavaScript na tela', not errs, errs)
    b.close()
print(f'\nResultado UI: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
