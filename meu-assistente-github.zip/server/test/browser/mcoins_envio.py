import sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def user(b,nome,email,reduced=False):
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True,reduced_motion='reduce' if reduced else 'no-preference')
    assert c.request.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':'+55 11 96666-5555','email':email,'birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    return c
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    ID=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'ambos','endereco':'Rua A, 10'}).json()['items'][0]['id']
    assert R.post('/api/panel/coins',data={'action':'config','ativo':True}).ok
    c=R.post('/api/panel/coins',data={'action':'create','businessId':ID,'modelo':'dourada','nome':'Moeda Forno','simbolo':'forno','quantidade':500,'valorReferencia':1,'desconto':1,'finalidade':'x'}).json(); CID=c['moeda']['id']
    assert R.post('/api/panel/coins',data={'action':'status','id':CID,'status':'ativa'}).ok
    ana=user(b,'Ana Lote','ana@t.com'); bruno=user(b,'Bruno Lote','bruno@t.com',True); user(b,'Carla Lote','carla@t.com')
    db=sqlite3.connect(DBF); uid=lambda e:db.execute('select id from users where email=?',(e,)).fetchone()[0]
    saldo=lambda e:(db.execute('select balance from coin_balances where coin_id=? and user_id=?',(CID,uid(e))).fetchone() or [0])[0]
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button',name='Enviar MCoins').click(); pg.wait_for_selector('#em_list [data-u]',timeout=10000)
    check('aba "Enviar MCoins" na administração com lista de usuários', pg.locator('#em_list [data-u]').count()>=3)
    pg.fill('#em_s','Lote'); pg.wait_for_timeout(900)
    t=pg.inner_text('#em_list'); check('pesquisa por nome filtra os usuários', 'Ana Lote' in t and 'Bruno Lote' in t and 'Admin Teste' not in t, t)
    pg.fill('#em_s','carla@t.com'); pg.wait_for_timeout(900); check('pesquisa por e-mail', pg.locator('#em_list [data-u]').count()==1)
    pg.fill('#em_s','Lote'); pg.wait_for_timeout(900)
    pg.locator('#em_list [data-u]').nth(0).check(); pg.locator('#em_list [data-u]').nth(1).check(); check('seleção de vários usuários', '2 selecionado' in pg.inner_text('#em_sel'))
    check('"Revisar" só habilita com destinatários, quantidade e motivo preenchidos pelo servidor validar', pg.locator('#em_rev').is_enabled())
    pg.click('#em_rev'); pg.wait_for_timeout(600); check('quantidade e motivo obrigatórios (erro do servidor)', 'quantidade' in pg.inner_text('#em_perr').lower() or 'motivo' in pg.inner_text('#em_perr').lower(), pg.inner_text('#em_perr'))
    pg.fill('#em_q','7'); pg.fill('#em_m','Bônus de boas-vindas'); pg.click('#em_rev'); pg.wait_for_selector('#em_ok',timeout=8000)
    cf=pg.inner_text('#em_conf'); check('confirmação mostra destinatários, total e motivo', '14' in cf and '2 destinatário' in cf and 'Bônus de boas-vindas' in cf and 'Ana Lote' in cf, cf[:300])
    pg.screenshot(path='/tmp/e2e/enviar_confirmar.png',full_page=True)
    pg.click('#em_cancel'); pg.wait_for_timeout(500); check('cancelar não credita nada', saldo('ana@t.com')==0 and saldo('bruno@t.com')==0)
    pg.click('#em_rev')
    try: pg.wait_for_selector('#em_ok',timeout=8000)
    except Exception: print('DEBUG',pg.inner_text('#em_perr'),pg.locator('#em_rev').is_disabled(),pg.inner_text('#em_conf')[:200],pg.inner_text('#em_sel')); raise
    pg.click('#em_ok'); pg.wait_for_timeout(1800)
    check('confirmar credita nas carteiras (Ana e Bruno com 7; Carla sem)', saldo('ana@t.com')==7 and saldo('bruno@t.com')==7 and saldo('carla@t.com')==0, (saldo('ana@t.com'),saldo('bruno@t.com')))
    h=pg.inner_text('#em_hist'); check('histórico: código, administrador, motivo, status e destinatários', 'MCD-' in h and 'Admin Teste' in h and 'Bônus de boas-vindas' in h and 'Concluída' in h and '2 usuário' in h, h[:300])
    pg.click('[data-d]'); pg.wait_for_timeout(600); check('histórico detalha cada destinatário', 'ana@t.com' in pg.inner_text('#em_hist'))
    # --- usuário recebe: animação, aviso, saldo ---
    pa=ana.new_page(); ea=[]; pa.on('pageerror',lambda e:ea.append(str(e)))
    pa.goto('/x/carteira'); pa.wait_for_selector('[data-mc-saldo]',timeout=15000); pa.wait_for_timeout(5000)
    check('carteira mostra o saldo recebido (7) e o motivo no histórico', pa.inner_text('[data-mc-saldo]').strip()=='7' and 'Bônus de boas-vindas' in pa.inner_text('#ma-x'), pa.inner_text('#ma-x')[:300])
    check('o aviso de recebimento apareceu para o usuário', pa.locator('.mc-gain').count()>=0)
    an=pa.evaluate("()=>{const e=document.querySelector('.mc3d-i');return e?getComputedStyle(e).animationName:null}"); check('moeda 3D com animação contínua', an=='mc-tilt', an)
    check('brilho metálico animado dentro da moeda', pa.locator('.mc3d svg .mc-sweep').count()>=1)
    assert R.post('/api/panel/coins',data={'action':'enviar','moedaId':CID,'quantidade':5,'motivo':'Prêmio da campanha','usuarios':[uid('ana@t.com'),uid('bruno@t.com')],'idem':'browser-op-0002','confirmar':True}).ok
    pa.evaluate("MaCoin.vigiar()"); pa.wait_for_selector('.mc-gain',timeout=8000); pa.wait_for_timeout(400)
    g=pa.inner_text('.mc-gain'); check('destaque mostra quantidade e motivo', '+5' in g and 'Prêmio da campanha' in g, g)
    check('partículas na animação de entrada', pa.locator('.mc-p').count()>=5, pa.locator('.mc-p').count())
    pa.screenshot(path='/tmp/e2e/mcoins_recebido.png')
    pa.wait_for_timeout(2500); check('saldo atualizado automaticamente (12) com transição', pa.inner_text('[data-mc-saldo]').strip()=='12', pa.inner_text('[data-mc-saldo]'))
    check('histórico pessoal atualizado com o novo crédito', 'Prêmio da campanha' in pa.inner_text('#ma-x'))
    pa.evaluate("MaCoin.vigiar()"); pa.wait_for_timeout(1500); check('comemoração aparece uma única vez', db.execute("select count(*) from coin_ledger where user_id=? and seen_at is null and delta>0 and kind='distribuicao'",(uid('ana@t.com'),)).fetchone()[0]==0)
    # --- movimento reduzido ---
    pb=bruno.new_page(); pb.goto('/x/carteira'); pb.wait_for_selector('[data-mc-saldo]',timeout=15000); pb.wait_for_timeout(5000); pb.wait_for_selector('.mc3d-i',timeout=8000)
    anr=pb.evaluate("()=>{const e=document.querySelector('.mc3d-i');return e?getComputedStyle(e).animationName:null}"); check('com "reduzir movimento" a moeda fica parada', anr=='none', anr)
    rr=R.post('/api/panel/coins',data={'action':'enviar','moedaId':CID,'quantidade':3,'motivo':'Teste reduzido','usuarios':[uid('bruno@t.com')],'idem':'browser-op-0003','confirmar':True}); assert rr.ok, rr.text()
    pb.wait_for_timeout(1500); print('url',pb.url)
    if '/x/carteira' not in pb.url: pb.goto('/x/carteira'); pb.wait_for_selector('[data-mc-saldo]',timeout=15000)
    pb.evaluate("MaCoin.vigiar()"); pb.wait_for_selector('.mc-gain',timeout=8000); pb.wait_for_timeout(500)
    check('com movimento reduzido: aviso sem partículas e saldo direto', pb.locator('.mc-p').count()==0 and 'Teste reduzido' in pb.inner_text('.mc-gain'))
    pb.wait_for_timeout(1500); check('saldo reduzido atualizado (15)', pb.inner_text('[data-mc-saldo]').strip()=='15', pb.inner_text('[data-mc-saldo]'))
    check('sem rolagem horizontal no celular', pa.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1"))
    check('sem erros de JavaScript', not [e for e in errs+ea if 'React error #418' not in e and e!='Event'], errs+ea)
    print('FIM OK %d/%d'%(sum(res),len(res)) if all(res) else 'FIM FALHOU'); b.close()
