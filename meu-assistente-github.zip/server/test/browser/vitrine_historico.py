import sys, sqlite3
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    for t,k,u in [('Plataforma de Música','/musica','https://exemplo.com/musica'),('TV ao vivo','/tv','https://exemplo.com/tv')]:
        assert R.post('/api/panel/showcase',data={'action':'create','titulo':t,'descricao':'Acesse '+t,'url':u,'palavra':k,'imagem':IMG}).ok
    db=sqlite3.connect(DBF); errs=[]
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile)
        assert c.request.post('/api/auth',data={'action':'login','email':'admin@t.com','password':'Senha@Forte123'}).ok
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        cards=lambda: pg.locator('.chat-scroll .ma-vit-card').count()
        conv=lambda: pg.evaluate("new URLSearchParams(location.search).get('c')||''")
        def novo():
            if not pg.locator('a[aria-label="Chat"]:visible').count(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(500)
            pg.locator('a[aria-label="Chat"]:visible').first.click(); pg.wait_for_timeout(1500)
        def enviar(t):
            ta=pg.locator('textarea.composer-input'); ta.click(); ta.type(t); pg.keyboard.press('Enter'); pg.wait_for_timeout(2800)
        def abrir(i):
            ta=pg.locator('textarea.composer-input'); ta.click(); ta.press('Control+a'); ta.type('/'); pg.wait_for_selector('.ma-vit-menu.in',timeout=5000); pg.wait_for_timeout(300)
            pg.locator('.ma-vit-menu [role=option]').nth(i).dispatch_event('pointerdown'); pg.wait_for_selector('.chat-scroll .ma-vit-card',timeout=5000); pg.wait_for_timeout(700)
        # ordem dos blocos na tela (cartões e mensagens) como lista de rótulos
        ordem=lambda: pg.evaluate("""()=>{const l=document.querySelector('.chat-scroll > div > .mt-auto');return [...l.children].map(e=>e.querySelector('.ma-vit-card')||e.classList.contains('ma-vit-card')?'CARD:'+((e.querySelector('h4')||{}).textContent||''):(e.querySelector('.bubble-user')?'USER':'BOT'))}""")
        suf=nome
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(2500)
        # ---- Teste A: chat novo, card ANTES da pergunta; resposta abaixo ----
        abrir(0)
        check(f'{nome} A: card aparece dentro da lista de mensagens (não fora dela)', pg.evaluate("()=>!!document.querySelector('.chat-scroll > div > .mt-auto > .ma-vit-card')"))
        check(f'{nome} A: o card é do lado do usuário (direita) e a tela de boas-vindas some', pg.evaluate("()=>{const c=document.querySelector('.ma-vit-card>div').getBoundingClientRect();return c.right>innerWidth/2}"))
        enviar(f'Pergunta A {suf}')
        o=ordem(); check(f'{nome} A: ordem card → pergunta → resposta', o[:3]==['CARD:Plataforma de Música','USER','BOT'], o)
        C1=conv(); check(f'{nome} A: conversa criada', len(C1)>10, C1)
        row=db.execute("select role,content,cards from messages where conversation_id=? order by id",(C1,)).fetchall()
        check(f'{nome} A: servidor gravou card(user) → pergunta(user) → resposta(assistant) nessa ordem', [r[0] for r in row]==['user','user','assistant'] and row[0][1].startswith('⟦lc:') and '"link_card"' in row[0][2], row)
        # segunda rodada na mesma conversa (card no meio)
        abrir(1); enviar(f'Segunda pergunta {suf}')
        o=ordem(); check(f'{nome} A: novos cards e respostas sempre no fim', o==['CARD:Plataforma de Música','USER','BOT','CARD:TV ao vivo','USER','BOT'], o)
        # ---- Teste F: atualizar a página ----
        pg.reload(); pg.wait_for_selector('.chat-scroll .ma-vit-card',timeout=15000); pg.wait_for_timeout(1500)
        o=ordem(); check(f'{nome} F: após atualizar, cards e ordem cronológica preservados', o==['CARD:Plataforma de Música','USER','BOT','CARD:TV ao vivo','USER','BOT'], o)
        check(f'{nome} F: sem duplicar cards', cards()==2, cards())
        enviar(f'Terceira {suf}'); o=ordem(); check(f'{nome} F: nova resposta depois de atualizar fica no fim', o[-2:]==['USER','BOT'] and len(o)==8 and o[6]=='USER', o)
        # botão abre exatamente o endereço cadastrado, mesmo após o histórico
        pg.evaluate("()=>{window.__abertos=[];window.open=(u)=>{window.__abertos.push(u);return null}}")
        pg.locator('.chat-scroll .ma-vit-card button').first.click(); pg.wait_for_timeout(300)
        ab=pg.evaluate("window.__abertos"); check(f'{nome}: botão do card recuperado abre exatamente o endereço cadastrado', ab==['https://exemplo.com/musica'], ab)
        # ---- Teste C: nova conversa sem cards ----
        novo(); pg.wait_for_timeout(600)
        check(f'{nome} C: nova conversa não carrega cards anteriores', cards()==0 and conv()=='', (cards(),conv()))
        # ---- Teste E: cards em outra conversa ----
        abrir(1); enviar(f'Conversa dois {suf}'); C2=conv()
        o=ordem(); check(f'{nome} E: conversa 2 só tem o próprio card', o==['CARD:TV ao vivo','USER','BOT'] and C2!=C1, (o,C1,C2))
        # ---- Testes B/D: voltar à conversa anterior ----
        def ir(titulo):
            if not pg.get_by_text(titulo,exact=True).first.is_visible(): pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(700)
            pg.get_by_text(titulo,exact=True).first.click(); pg.wait_for_timeout(2500)
        ir(f'Pergunta A {suf}')
        o=ordem(); check(f'{nome} B/D: ao voltar à conversa 1 (clique no histórico), os cards são recuperados na ordem certa', o[:6]==['CARD:Plataforma de Música','USER','BOT','CARD:TV ao vivo','USER','BOT'] and cards()==2, o)
        ir(f'Conversa dois {suf}')
        o=ordem(); check(f'{nome} E: ao voltar à conversa 2, só o card dela', o==['CARD:TV ao vivo','USER','BOT'], o)
        ir(f'Pergunta A {suf}'); enviar(f'Quarta {suf}'); o=ordem(); check(f'{nome} B: resposta nova após voltar fica abaixo de tudo', o[-2:]==['USER','BOT'] and len(o)==10, o)
        check(f'{nome}: título da conversa vem da pergunta real (não do card)', db.execute("select title from conversations where id=?",(C1,)).fetchone()[0]==f'Pergunta A {suf}', db.execute("select title from conversations where id=?",(C1,)).fetchone())
        # a IA nunca recebe o marcador do card
        check(f'{nome}: marcador do card não vai para o contexto da IA', db.execute("select count(*) from messages where role='assistant' and content like '%⟦lc:%'").fetchone()[0]==0)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(('FIM OK ' if ok==len(res) else 'FIM FALHOU ')+f'{ok}/{len(res)}'); sys.exit(0 if ok==len(res) else 1)
