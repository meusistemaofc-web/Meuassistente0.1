# Central de Marketing das empresas (telas): a opção em Sua empresa só aparece com a chave do administrador ligada; o
# proprietário ativa "Ativar campanhas de marketing para meus clientes", cria campanha completa (nome, título, conteúdo,
# imagem, público, data/horário, encerramento), salva rascunho, edita, cancela, vê detalhes; o administrador desliga
# (opção some, campanha programada fica suspensa sem perder dados) e religa (validar e retomar); o cliente que toca na
# oferta vê a empresa remetente e consegue deixar de receber. Celular e computador.
# Servidor: SESSION_SECRET=e2e-mkt PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, sqlite3, hmac, hashlib, base64, zlib, struct, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'; KEY=b'e2e-mkt'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def sig(s): return hmac.new(KEY,s.encode(),hashlib.sha256).hexdigest()[:20]
def png(w,h,rgb):
    raw=b''.join(b'\x00'+bytes(rgb)*w for _ in range(h))
    def ch(t,d): c=struct.pack('>I',len(d))+t+d; return c+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+ch(b'IDAT',zlib.compress(raw))+ch(b'IEND',b'')
def db(sql,args=()):
    c=sqlite3.connect(DBF); r=c.execute(sql,args).fetchall(); c.commit(); c.close(); return r
def abrirAjustes(pg):
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('nav.ma-nav',timeout=15000); pg.wait_for_timeout(1500)
    pg.locator('nav.ma-nav').get_by_text('Ajustes',exact=True).click(); pg.wait_for_timeout(1500)
U={'whatsapp':'+55 11 94444-1234','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','email':'admin@t.com',**U}).ok
    A.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True})
    r=A.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Restaurantes','titulo':'Pizza','texto':'Pizzas','zap':'5511999990000','endereco':'Rua A, 10'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']; db("update businesses set status='ativo' where id=?",(BID,))
    OWNER=db('select owner_id from businesses where id=?',(BID,))[0][0]
    A.put('/api/panel/mkt_plans',data={'n4':{'acesso':True,'campanhasPeriodo':20,'notificacoesPeriodo':500,'agendar':True,'segmentacao':True,'relatorios':True}})
    A.put('/api/panel/mkt_global',data={'ativo':True})
    cli=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True); C=cli.request
    assert C.post('/api/auth',data={'action':'signup','name':'Cliente Ana','email':'ana@t.com',**{**U,'whatsapp':'+55 11 95555-0000'}}).ok
    assert C.post('/api/v2/me/consents',data={'ownerId':OWNER,'aceito':True}).ok
    CID=db("select id from users where email='ana@t.com'")[0][0]
    st=adm.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        A.post('/api/v2/marketing',data={'action':'empresa','ativo':False})
        # 1-2. opção aparece em Sua empresa (chave do administrador ligada)
        abrirAjustes(pg)
        check(f'{nome}: "Central de Marketing" aparece em Sua empresa', pg.locator('[data-mkt]').count()>0)
        pg.goto('/x/marketing'); pg.wait_for_selector('[data-mk-toggle]',timeout=15000); pg.wait_for_timeout(600)
        check(f'{nome}: controle "Ativar campanhas de marketing para meus clientes" desligado e criação bloqueada', pg.locator('[data-sw="mk_emp"]').get_attribute('aria-checked')=='false' and pg.locator('[data-mk-off]').count()==1 and pg.locator('#mk_new').count()==0)
        # 3. ativa
        pg.click('[data-sw="mk_emp"]'); pg.wait_for_selector('#mk_new',timeout=8000); pg.wait_for_timeout(400)
        check(f'{nome}: proprietário ativa e a Central libera as campanhas', pg.locator('[data-sw="mk_emp"]').get_attribute('aria-checked')=='true')
        # 4-5. cria e programa campanha completa
        pg.click('#mk_new'); pg.wait_for_selector('[data-mk-form]')
        pg.fill('#mk_n',f'Black Friday {nome}'); pg.fill('#mk_t','Black Friday na Pizzaria'); pg.fill('#mk_m','Pizza grande com 30% de desconto!')
        pg.set_input_files('#mk_i',files=[{'name':'promo.png','mimeType':'image/png','buffer':png(400,300,(220,90,40))}]); pg.wait_for_timeout(800)
        check(f'{nome}: imagem promocional carregada com prévia', pg.locator('#mk_iv img').count()==1)
        opts=pg.eval_on_selector_all('#mk_s option','e=>e.map(o=>o.value)')
        check(f'{nome}: público com todos, compradores, recentes, sem compras e personalizado', opts==['todos','compradores','recentes','sem_compras','personalizado'], opts)
        pg.select_option('#mk_s','personalizado'); pg.wait_for_timeout(300)
        check(f'{nome}: segmento personalizado mostra os filtros', pg.locator('#mk_so').count()==1 and pg.locator('#mk_sc').count()==1)
        pg.select_option('#mk_s','todos'); pg.wait_for_timeout(600)
        check(f'{nome}: mostra quantos clientes autorizados recebem', 'Vai para 1 cliente' in pg.inner_text('#mk_pub'), pg.inner_text('#mk_pub'))
        pg.check('input[name=mk_q][value=prog]')
        am=(datetime.date.today()+datetime.timedelta(days=2)).isoformat(); fim=(datetime.date.today()+datetime.timedelta(days=6)).isoformat()
        pg.fill('#mk_d',am); pg.fill('#mk_h','10:30'); pg.fill('#mk_fim',fim)
        check(f'{nome}: botão principal vira "Programar campanha"', pg.inner_text('#mk_go')=='Programar campanha')
        pg.click('#mk_go'); pg.wait_for_selector('[data-camp]',timeout=8000); pg.wait_for_timeout(500)
        row=db("select id,status,nome,imagem is not null,agendada_para,encerra_em,fuso from mkt_campaigns where nome=?",(f'Black Friday {nome}',))
        check(f'{nome}: campanha programada no banco (nome, imagem, data/horário no fuso, encerramento)', row and row[0][1]=='agendada' and row[0][3]==1 and row[0][5] and row[0][6], row)
        PID=row[0][0]
        it=pg.locator(f'[data-camp="{PID}"]')
        check(f'{nome}: aparece em Programadas com imagem, data e status', it.count()==1 and 'Programada para' in it.inner_text() and '10:30' in it.inner_text() and it.locator('img').count()==1, it.inner_text() if it.count() else '')
        # rascunho, edição e cancelamento
        pg.click('#mk_new'); pg.wait_for_selector('[data-mk-form]'); pg.fill('#mk_n','Ideia de campanha'); pg.fill('#mk_t','Rascunho'); pg.click('#mk_dr'); pg.wait_for_timeout(1200)
        rid=db("select id,status from mkt_campaigns where nome='Ideia de campanha' order by id desc limit 1")[0]
        check(f'{nome}: salvar como rascunho (filtro Rascunhos)', rid[1]=='rascunho' and pg.locator(f'[data-camp="{rid[0]}"]').count()==1)
        pg.click(f'[data-ce="{rid[0]}"]'); pg.wait_for_selector('[data-mk-form]'); pg.fill('#mk_t','Rascunho editado'); pg.click('#mk_dr'); pg.wait_for_timeout(1200)
        check(f'{nome}: editar rascunho', db('select titulo from mkt_campaigns where id=?',(rid[0],))[0][0]=='Rascunho editado')
        pg.click(f'[data-cc="{rid[0]}"]'); pg.wait_for_timeout(200); pg.click(f'[data-cc="{rid[0]}"]'); pg.wait_for_timeout(1200)
        check(f'{nome}: cancelar (com confirmação) antes do envio', db('select status from mkt_campaigns where id=?',(rid[0],))[0][0]=='cancelada')
        # resultados: filtros por situação e detalhes
        pg.click('[data-f=""]'); pg.wait_for_timeout(300)
        fil=pg.inner_text('#mk_fil')
        check(f'{nome}: painel com Programadas, Em andamento, Concluídas, Suspensas e Canceladas', all(x in fil for x in ['Programadas','Em andamento','Concluídas','Suspensas','Canceladas']), fil)
        pg.click(f'[data-cd="{PID}"]'); pg.wait_for_timeout(900)
        check(f'{nome}: detalhes mostram conteúdo, público e histórico', 'Histórico' in pg.inner_text(f'[data-det="{PID}"]') and 'Criada e programada' in pg.inner_text(f'[data-det="{PID}"]'), pg.inner_text(f'[data-det="{PID}"]'))
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        pg.screenshot(path=f'/tmp/e2e/marketing_{nome}.png',full_page=True)
        # 9-10. administrador desliga: opção some, campanha suspensa, dados guardados
        A.put('/api/panel/mkt_global',data={'ativo':False})
        check(f'{nome}: desligar suspende a campanha programada', db('select status,suspensa_por from mkt_campaigns where id=?',(PID,))[0]==('suspensa','administrador'))
        abrirAjustes(pg)
        check(f'{nome}: com a chave desligada a opção some de Sua empresa', pg.locator('[data-mkt]').count()==0)
        pg.goto('/x/marketing'); pg.wait_for_selector('[data-mk-aviso]',timeout=10000)
        check(f'{nome}: acesso direto mostra "desativada pelo administrador" sem formulário', 'desativou' in pg.inner_text('[data-mk-aviso]') and pg.locator('#mk_new').count()==0)
        check(f'{nome}: nenhum dado apagado', db('select count(*) from mkt_campaigns where business_id=?',(BID,))[0][0]>=2)
        # 11. religa: campanha continua suspensa até validar
        A.put('/api/panel/mkt_global',data={'ativo':True})
        pg.goto('/x/marketing'); pg.wait_for_selector('[data-mk-susp]',timeout=10000)
        check(f'{nome}: ao religar, avisa campanhas suspensas aguardando validação', pg.locator(f'[data-cv="{PID}"]').count()==1)
        pg.click(f'[data-cv="{PID}"]'); pg.wait_for_timeout(1500)
        check(f'{nome}: "Validar e retomar" volta a programar', db('select status from mkt_campaigns where id=?',(PID,))[0][0]=='agendada' and pg.locator(f'[data-camp="{PID}"]').count()==1)
        pg.screenshot(path=f'/tmp/e2e/marketing_{nome}_validada.png')
        c.close()
    # 7. cliente toca na oferta: vê quem enviou e consegue sair
    cid=db("select id from mkt_campaigns where business_id=? and status='agendada' order by id limit 1",(BID,))[0][0]
    db("insert into mkt_sends (campaign_id, owner_id, user_id, status, canal, criado_em) values (?,?,?,'enviado','app',?)",(cid,OWNER,CID,datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%S.000Z")))
    sid=db('select id from mkt_sends where campaign_id=? and user_id=?',(cid,CID))[0][0]
    pc=cli.new_page(); pc.on('pageerror',lambda e:errs.append(str(e)))
    pc.goto(f'/?mkt={sid}.{sig("c:"+str(sid))}'); pc.wait_for_timeout(3500); pc.wait_for_selector('#ma-oferta',timeout=15000)
    t=pc.inner_text('#ma-oferta')
    check('cliente: oferta identifica a empresa remetente, título e validade', 'Pizzaria Forno' in t and 'Black Friday na Pizzaria' in t and 'válida até' in t and pc.locator('#ma-oferta img').count()==1, t)
    pc.screenshot(path='/tmp/e2e/marketing_oferta_cliente.png')
    pc.click('[data-of="sair"]'); pc.wait_for_timeout(1200)
    check('cliente: "Não quero mais receber" cancela a autorização', 'não vai mais receber' in pc.inner_text('#ma-oferta') and db('select status from marketing_consents where owner_id=? and user_id=?',(OWNER,CID))[0][0]=='revogado')
    check('cliente: interação (clique) registrada', db('select cliques from mkt_campaigns where id=?',(cid,))[0][0]==1)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
