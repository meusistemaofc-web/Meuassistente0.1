import sys
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
norm=lambda s:s.replace('\xa0',' ')
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':430,'height':1000},base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True,'mercado':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Pizzaria','titulo':'Pizza','texto':'x','zap':'5511999990000','tipo':'produtos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    errs=[]
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    check('Ajustes tem "Calendário e funcionamento"', pg.locator('button:has-text("Calendário e funcionamento")').count()>=1)
    pg.locator('button:has-text("Calendário e funcionamento")').first.click(); pg.wait_for_selector('#cal_modos',timeout=8000)
    body=norm(pg.inner_text('body')); check('tela mostra modos manual/inteligente/automático', all(x in body for x in ['Manual','Inteligente','Automático']), body[:300])
    check('mostra próximos feriados', 'próximos feriados' in body.lower() and pg.locator('[data-dec]').count()>0)
    pg.locator('[data-modo=inteligente]').click(); pg.wait_for_timeout(900)
    check('modo inteligente fica selecionado', '✓' in pg.locator('[data-modo=inteligente]').inner_text())
    check('"todo ano" só no automático', pg.locator('[data-rec]').count()==0)
    pg.locator('[data-modo=automatico]').click(); pg.wait_for_timeout(900)
    check('no automático aparece "todo ano"', pg.locator('[data-rec]').count()>0)
    pg.fill('#ci_n','Almoço'); pg.fill('#ci_a','12:00'); pg.fill('#ci_f','13:00'); pg.click('#ci_add'); pg.wait_for_timeout(900)
    check('intervalo cadastrado aparece', 'Almoço · 12:00–13:00' in norm(pg.inner_text('body')))
    pg.locator('[data-dec]',has_text='Fechar').first.click(); pg.wait_for_timeout(900)
    check('decisão de fechar aplicada ao feriado', 'fechado (decidido)' in norm(pg.inner_text('body')) or 'decidido' in pg.inner_text('body'))
    d=R.get(f'/api/v2/ads/{ID}/calendar').json()
    check('persistido no servidor', d['calendario']['modo']=='automatico' and len(d['calendario']['intervalos'])==1 and len(d['calendario']['decisoes'])==1)
    pg.fill('#cf_n','Aniversário da cidade'); pg.fill('#cf_d','2026-12-10'); pg.click('#cf_add'); pg.wait_for_timeout(900)
    check('feriado municipal cadastrado', 'Aniversário da cidade' in pg.inner_text('body'))
    pg.screenshot(path='/tmp/e2e/agenda_ia_empresa.png',full_page=True)
    pg.locator('[data-rmi]').first.click(); pg.wait_for_timeout(900)
    check('intervalo removido', 'Almoço · 12:00' not in pg.inner_text('body'))
    # admin
    a=ctx.new_page(); a.on('pageerror',lambda e:errs.append(str(e)))
    a.goto('/admin'); a.wait_for_timeout(1500)
    aba(a,'cb_conhecimento'); a.wait_for_selector('#cap_l [data-cap=agenda-ia]',timeout=10000)
    check('capacidade aparece no painel', 'Inteligência de Agenda e Funcionamento Empresarial' in norm(a.inner_text('body')))
    a.locator('[data-agtog]').first.click(); a.wait_for_timeout(1200)
    check('desligar reflete no servidor', R.get('/api/panel/agenda_ia').json().get('ativo') is False, R.get('/api/panel/agenda_ia').text())
    a.locator('[data-agtog]').first.click(); a.wait_for_timeout(1200)
    check('ligar reflete no servidor', R.get('/api/panel/agenda_ia').json().get('ativo') is True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs)
    b.close()
ok=sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok==len(res) else 1)
