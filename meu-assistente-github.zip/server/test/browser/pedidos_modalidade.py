# Pedido conforme a modalidade, de ponta a ponta pela tela:
# • checkout: RETIRADA mostra o endereço completo da loja, horário, "Ver no mapa" e WhatsApp (dados reais do cadastro), sem nada
#   de entrega; ENTREGA mostra os campos de endereço, o aviso de acompanhamento e de contato por WhatsApp/ligação, sem nada de retirada;
# • Meus pedidos: retirada com o cartão "Retire seu pedido em" e WhatsApp; entrega com as etapas (enviado → aceito → em preparo →
#   saiu → entregue), data e hora, atualizando sozinho quando a loja muda a situação;
# • painel da loja: em preparo, só a ação da modalidade ("Saiu para entrega" × "Pronto para retirar").
# Celular (390 px) e computador. Servidor: PORT=4333 SQLITE_FILE=/tmp/ma-pmod.db npx tsx test/serve-sqlite.ts (banco novo)
import io, sys, sqlite3, re, base64
from urllib.parse import unquote
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4333'; DBF = '/tmp/ma-pmod.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (200, 200), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' '))
END = 'Rua das Flores, 120 - Centro, Maceió - AL'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Lu', 'whatsapp': '+55 82 94444-7070', 'email': 'lu.mod@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Empório da Lu', 'categoria': 'Mercearia', 'titulo': 'x', 'texto': 'Queijos e doces', 'zap': '82988887777', 'endereco': END}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', lat=-9.6658, lng=-35.735 where id=?", (ID,)); db.commit(); db.close()
    dias = {k: {'ativo': k != 'dom', 'abre': '08:00', 'fecha': '18:00'} for k in ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom']}
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': dias}, 'pagamento': {'dinheiro': True, 'pix': True, 'chavePix': 'lu@pix.com'}, 'entrega': {'retirada': True, 'entrega': True, 'taxa': 5, 'raio': 50}}).ok
    PID = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Queijo coalho', 'preco': 30, 'categoria': 'Queijos', 'fotos': [durl((230, 200, 90))]}).json()['items'][0]['id']
    pedidos = {}
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); k = nome.replace(' ', '')
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bia Cliente', 'whatsapp': {'celular390': '+55 82 95555-0201', 'computador': '+55 82 95555-0202'}[k], 'email': f'bia.mod.{k}@t.com', **U}, headers={'X-Forwarded-For': '10.6.8.' + str(vp['width'] % 250)}).ok
        pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
        def carrinho():
            pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector(f'[data-add="{PID}"]', timeout=20000); pc.wait_for_timeout(500)
            pc.click(f'[data-add="{PID}"]'); pc.wait_for_timeout(400); pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
        carrinho()
        # começa em entrega (a loja faz entrega)
        co = lambda: N(pc.inner_text('[data-checkout]'))
        check(f'{nome}: entrega: campo de endereço, aviso de acompanhamento e de contato por WhatsApp/ligação', pc.locator('[data-co-endereco] [data-ent=rua]').count() == 1 and pc.locator('[data-co-entrega]').count() == 1 and 'Meus pedidos' in co() and 'WhatsApp ou por ligação' in co(), co()[:500])
        check(f'{nome}: entrega não mostra nada de retirada', pc.locator('[data-retirada]').count() == 0 and END not in co())
        pc.click('[data-mo=retirada]'); pc.wait_for_selector('[data-retirada]')
        rt = N(pc.inner_text('[data-retirada]')); zap = pc.get_attribute('[data-ret-zap]', 'href') or ''
        check(f'{nome}: retirada: endereço completo e horário reais da loja', END in rt and 'Seg 08:00–18:00' in rt, rt)
        check(f'{nome}: retirada: WhatsApp da loja com mensagem pronta e "Ver no mapa"', zap.startswith('https://wa.me/5582988887777?text=') and 'retirada' in unquote(zap) and '-9.6658,-35.735' in (pc.get_attribute('[data-ret-mapa]', 'href') or ''), zap)
        check(f'{nome}: retirada não mostra nada de entrega', pc.locator('[data-co-endereco]').count() == 0 and pc.locator('[data-co-entrega]').count() == 0 and 'ligação' not in co())
        check(f'{nome}: checkout sem rolagem lateral', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if k == 'celular390': pc.locator('[data-retirada]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/pmod_checkout_retirada.png')
        pc.fill('#czap', '82955550201'); pc.click('#cgo'); pc.wait_for_timeout(2200)
        ret = C.request.get('/api/v2/orders/mine').json()['items'][0]['id']
        # pedido de entrega
        carrinho(); pc.click('[data-mo=entrega]'); pc.wait_for_selector('[data-ent=rua]')
        for f, v in [('rua', 'Av. Brasil'), ('numero', '500'), ('complemento', 'ap 12'), ('bairro', 'Centro')]: pc.fill(f'[data-ent={f}]', v)
        pc.click('[data-pg=pix]'); pc.wait_for_timeout(200)
        check(f'{nome}: o endereço digitado continua ao trocar o pagamento', [pc.input_value(f'[data-ent={f}]') for f in ('rua', 'numero', 'complemento', 'bairro')] == ['Av. Brasil', '500', 'ap 12', 'Centro'])
        if k == 'celular390': pc.locator('[data-co-entrega]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/pmod_checkout_entrega.png')
        pc.fill('#czap', '82955550201'); pc.click('#cgo'); pc.wait_for_timeout(2200)
        ent = C.request.get('/api/v2/orders/mine').json()['items'][0]['id']
        check(f'{nome}: os dois pedidos foram enviados', ent != ret and pc.url.endswith('/x/pedidos'), (ret, ent, pc.url))
        pc.wait_for_selector('[data-ped-entrega]', timeout=10000)
        pr = N(pc.inner_text('[data-retirada]')); pe = N(pc.inner_text('[data-ped-entrega]'))
        check(f'{nome}: Meus pedidos (retirada): "Retire seu pedido em", endereço e WhatsApp', 'retire seu pedido em' in pr.lower() and END in pr and pc.locator('[data-retirada] [data-ret-zap]').count() == 1 and f'#{ret}' in unquote(pc.get_attribute('[data-retirada] [data-ret-zap]', 'href')), pr)
        check(f'{nome}: Meus pedidos (entrega): endereço, etapas e aviso de contato; nada de retirada', 'Av. Brasil, 500 - ap 12, Centro' in pe and [x.get_attribute('data-etapa') for x in pc.locator('[data-ped-entrega] [data-etapa]').all()] == ['novo', 'aceito', 'preparo', 'saiu', 'concluido'] and 'WhatsApp ou por ligação' in pe and END not in pe, pe)
        check(f'{nome}: etapa atual = Pedido enviado (com data e hora)', 'at' in pc.get_attribute('[data-ped-entrega] [data-etapa="novo"]', 'class') and re.search(r'\d\d/\d\d,? \d\d:\d\d', pc.inner_text('[data-ped-entrega] [data-etapa="novo"]')))
        # a loja muda a situação → a tela atualiza sozinha (sem recarregar)
        for s in ['aceito', 'preparo', 'saiu']: assert R.post(f'/api/v2/ads/{ID}/orders/{ent}', data={'status': s}).ok
        pc.wait_for_function("()=>{const e=document.querySelector('[data-ped-entrega] [data-etapa=\"saiu\"]');return e&&e.classList.contains('at')}", timeout=30000)
        okE = [x.get_attribute('data-etapa') for x in pc.locator('[data-ped-entrega] .ma-trk-i.ok').all()]
        check(f'{nome}: andamento ao vivo: aceito e em preparo concluídos, "Saiu para entrega" atual', okE == ['novo', 'aceito', 'preparo'] and 'Saiu para entrega' in N(pc.inner_text('[data-ped-entrega]')), okE)
        if k == 'celular390': pc.locator('[data-ped-entrega]').scroll_into_view_if_needed(); pc.screenshot(path='/tmp/e2e/pmod_meus_pedidos.png', full_page=True)
        assert R.post(f'/api/v2/ads/{ID}/orders/{ent}', data={'status': 'concluido'}).ok
        pc.reload(); pc.wait_for_selector('[data-ped-entrega]', timeout=10000)
        check(f'{nome}: entregue: todas as etapas concluídas e sem aviso de contato', pc.locator('[data-ped-entrega] .ma-trk-i.ok').count() == 5 and pc.locator('[data-ped-entrega] [data-entrega-aviso]').count() == 0)
        check(f'{nome}: Meus pedidos sem rolagem lateral', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pedidos[k] = (ret, ent); C.close()
    print('== painel da loja')
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    ret, _ = pedidos['celular390']
    C2 = b.new_context(base_url=BASE); assert C2.request.post('/api/auth', data={'action': 'signup', 'name': 'Caio Lima', 'whatsapp': '+55 82 95555-0303', 'email': 'caio.mod@t.com', **U}, headers={'X-Forwarded-For': '10.6.9.9'}).ok
    ent2 = C2.request.post(f'/api/v2/businesses/{ID}/orders', data={'itens': [{'pid': PID, 'qtd': 1}], 'modo': 'entrega', 'endereco': 'Rua C, 3', 'pagamento': 'dinheiro', 'telefone': '82955550303'}).json()['order']['id']
    for oid in (ret, ent2):
        for s in ['aceito', 'preparo']: assert R.post(f'/api/v2/ads/{ID}/orders/{oid}', data={'status': s}).ok
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000); pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector(f'[data-odet="{ent2}"]', timeout=15000); pg.wait_for_timeout(500)
    acE = [x.get_attribute('data-os') for x in pg.locator(f'[data-oid="{ent2}"]').all()]; acR = [x.get_attribute('data-os') for x in pg.locator(f'[data-oid="{ret}"]').all()]
    check('painel: entrega em preparo só oferece "Saiu para entrega"; retirada só "Pronto para retirar"', acE == ['saiu', 'cancelado'] and acR == ['pronto', 'cancelado'], (acE, acR))
    bad = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript', not bad, bad[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
