# Modos Inteligentes (telas): botão ⚡ "Modos" logo à direita do + sem mudar o campo de digitação (altura, +, texto,
# microfone e enviar), seletor acima do campo, Consultor de Marketing (conversa livre com dados reais, plano, continuidade), proposta → Central
# como rascunho, volta ao chat normal, empresa sem anúncio completo vê o benefício exclusivo (sem executar o modo).
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, sqlite3, json
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'; DBF='/tmp/ma-teste.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def db(sql,args=()):
    c=sqlite3.connect(DBF); r=c.execute(sql,args).fetchall(); c.commit(); c.close(); return r
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
GEO="""()=>{const q=s=>document.querySelector(s),r=e=>{if(!e)return null;const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,w:x.width,h:x.height}};const bar=q('.ma-composer-bar');const bs=[...bar.querySelectorAll('button')];const by=k=>bs.find(b=>(b.getAttribute('aria-label')||'').startsWith(k));
 const m=q('.ma-modos-btn');const cs=m&&getComputedStyle(m);return {box:r(q('.ma-composer')),plus:r(by('Anexar')),modos:r(m),ta:r(q('textarea.composer-input')),send:r(by('Enviar')),mic:r(bs.find(b=>/Ditar|Gravar|Parar/.test(b.getAttribute('aria-label')||''))),ph:q('textarea.composer-input').placeholder,
 bg:cs&&cs.backgroundColor,cor:cs&&cs.color,txt:m&&m.innerText.trim(),prev:m&&m.previousElementSibling&&m.previousElementSibling.getAttribute('aria-label'),sw:document.documentElement.scrollWidth,vw:innerWidth}}"""
def ultima(pg): return pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
def espera(pg,txt,t=20000):
    for _ in range(t//250):
        if txt in ultima(pg) or pg.locator(f'.chat-scroll >> text={txt}').count(): return True
        pg.wait_for_timeout(250)
    return False
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Dono Pizzaria','email':'admin@t.com','whatsapp':'+55 11 94444-1234',**U}).ok
    A.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True})
    r=A.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Forno','categoria':'Restaurantes','titulo':'Pizza no forno a lenha','texto':'Pizzas artesanais','zap':'5511999990000','insta':'pizzariaforno','endereco':'Rua A, 10, São Paulo'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']; db("update businesses set status='ativo', expires_at=? where id=?",('2099-01-01T00:00:00Z',BID))
    for nome,preco in [('Margherita',45),('Calabresa',49)]: A.post(f'/api/v2/ads/{BID}/products',data={'nome':nome,'preco':preco,'categoria':'Pizzas'})
    A.put('/api/panel/mkt_global',data={'ativo':True}); A.post('/api/v2/marketing',data={'action':'empresa','ativo':True})
    st=adm.storage_state()
    # empresa com anúncio básico
    bas=b.new_context(base_url=BASE); B=bas.request
    assert B.post('/api/auth',data={'action':'signup','name':'Dona Basica','email':'basica@t.com','whatsapp':'+55 11 95555-1212',**U}).ok
    r2=B.post('/api/v2/ads',data={'planId':'n2','empresa':'Floricultura Básica','categoria':'Flores','titulo':'Flores','texto':'Buquês','zap':'5511966665555'}); assert r2.ok, r2.text()
    db("update businesses set status='ativo', expires_at=? where id=?",('2099-01-01T00:00:00Z',r2.json()['items'][0]['id']))
    stB=bas.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':860},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_selector('.ma-modos-btn',timeout=10000); pg.wait_for_timeout(4000)
        pg.evaluate("()=>document.activeElement&&document.activeElement.blur()"); pg.wait_for_timeout(300)
        g=pg.evaluate(GEO)
        # 3. preservação: compara com o mesmo campo sem o botão novo
        sem=pg.evaluate("()=>{const m=document.querySelector('.ma-modos-btn');const pai=m.parentElement,nx=m.nextSibling;m.remove();const q=s=>document.querySelector(s),r=e=>{const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,w:x.width,h:x.height}};const bs=[...q('.ma-composer-bar').querySelectorAll('button')];const o={box:r(q('.ma-composer')),plus:r(bs[0]),ta:r(q('textarea.composer-input')),send:r(bs[bs.length-1])};pai.insertBefore(m,nx);return o}")
        igual=lambda a,b2:all(abs(a[k]-b2[k])<0.6 for k in ['l','r','t','b','w','h'])
        check(f'{nome}: campo preservado — mesma altura, mesma posição do +, do enviar e do microfone', igual(g['box'],sem['box']) and igual(g['plus'],sem['plus']) and igual(g['send'],sem['send']) and g['ph']=='Como posso ajudar você hoje?', (g['box'],sem['box']))
        check(f'{nome}: só o espaço mínimo: o texto anda no máximo a largura do botão novo + 6px', 0<=g['ta']['l']-sem['ta']['l']<=g['modos']['w']+6.5, (g['ta'],sem['ta'],g['modos']))
        # 2. botão: logo à direita do +, cápsula compacta azul-marinho com raio e "Modos"
        check(f'{nome}: botão "Modos" imediatamente à direita do +', g['prev'] and g['prev'].startswith('Anexar') and 0<=g['modos']['l']-g['plus']['r']<=12 and abs((g['modos']['t']+g['modos']['h']/2)-(g['plus']['t']+g['plus']['h']/2))<1.5, (g['plus'],g['modos']))
        check(f'{nome}: círculo azul-marinho com raio azul, do tamanho do +, dentro do campo', g['bg']=='rgb(7, 17, 35)' and g['cor']=='rgb(65, 124, 247)' and g['txt']=='' and g['modos']['w']<=42 and abs(g['modos']['h']-g['plus']['h'])<1 and g['modos']['t']>=g['box']['t'] and g['modos']['b']<=g['box']['b'], (g['bg'],g['cor'],g['txt'],g['modos']))
        check(f'{nome}: sem rolagem horizontal', g['sw']<=g['vw']+1)
        pg.screenshot(path=f'/tmp/e2e/modos_campo_{nome}.png')
        # 1. seletor acima do campo
        pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo="marketing"]',timeout=8000)
        k=pg.evaluate("()=>{const c=document.getElementById('ma-modos-card').getBoundingClientRect(),b=document.querySelector('.ma-composer').getBoundingClientRect();return {cb:c.bottom,bt:b.top,txt:document.getElementById('ma-modos-card').innerText}}")
        check(f'{nome}: seletor abre acima do campo com Chat normal e Consultor de Marketing (exclusivo do anúncio completo)', k['cb']<=k['bt'] and 'Chat normal' in k['txt'] and 'Consultor de Marketing' in k['txt'] and 'Exclusivo' in k['txt'] and '🔒' not in k['txt'], k)
        pg.screenshot(path=f'/tmp/e2e/modos_seletor_{nome}.png')
        # 5. ativa o Consultor de Marketing
        pg.click('#ma-modos-card [data-modo="marketing"]')
        check(f'{nome}: Consultor ativado já com os dados reais da empresa e as limitações (sem menu de objetivos)', espera(pg,'Acabei de consultar os dados') and 'Pizzaria Forno' in ultima(pg) and 'custo dos produtos' in ultima(pg) and 'O que você quer melhorar' not in ultima(pg), ultima(pg)[:300])
        if nome=='computador':
            check(f'{nome}: retoma o plano construído na conversa anterior (celular)', 'Da última vez construímos o plano' in ultima(pg) and 'Reativar clientes inativos' in ultima(pg), ultima(pg)[:300])
        pg.wait_for_timeout(1200)
        check(f'{nome}: sugestões opcionais (não obrigatórias) como respostas rápidas', 3<=pg.locator('.ma-opc[data-opc] button').count()<=5 and pg.locator('.ma-opc button',has_text='Quais oportunidades você vê?').count()>=1, pg.locator('.ma-opc button').count())
        check(f'{nome}: botão mostra o modo ativo', pg.locator('.ma-modos-btn.on').count()==1 and pg.locator('.ma-modos-btn').get_attribute('aria-label').startswith('Modo inteligente: Marketing') )
        pg.screenshot(path=f'/tmp/e2e/modos_ativo_{nome}.png')
        # pergunta livre (sugestão opcional): análise com os dados, sem questionário
        pg.locator('.ma-opc button',has_text='Quais oportunidades você vê?').first.click()
        check(f'{nome}: pergunta livre vira análise com os dados (sem "Pergunta 1 de")', espera(pg,'O que os dados mostram') and 'Pergunta 1 de' not in ultima(pg), ultima(pg)[:200])
        # pedido escrito do jeito do proprietário: plano fundamentado + proposta → Central como rascunho
        pg.locator('textarea.composer-input').fill('Monte um plano para trazer de volta quem parou de comprar'); pg.wait_for_timeout(200); pg.locator('[aria-label="Enviar"]').click()
        ok=espera(pg,'Próximos passos',20000); pg.wait_for_selector('[data-mkprop]',timeout=15000); pg.wait_for_timeout(800)
        txt=ultima(pg)
        check(f'{nome}: plano com dados que sustentam, custos sem invenção e cartão da proposta', ok and 'Dados que sustentam' in txt and 'sem base para estimar' in txt and '```' not in txt and pg.locator('[data-mkprop]').count()>=1 and 'Sentimos sua falta!' in pg.inner_text('[data-mkprop]'), txt[:300])
        pg.screenshot(path=f'/tmp/e2e/modos_proposta_{nome}.png')
        antes=db("select count(*) from mkt_campaigns where titulo='Sentimos sua falta!'")[0][0]
        pg.locator('[data-mkprop] [data-lev]').last.click(); pg.wait_for_timeout(2000)
        check(f'{nome}: "Levar para a Central" cria rascunho (nada enviado)', db("select count(*) from mkt_campaigns where titulo='Sentimos sua falta!' and status='rascunho'")[0][0]==antes+1 and 'Na Central de Marketing' in pg.locator('[data-mkprop]').last.inner_text(), (antes, db("select count(*), group_concat(status) from mkt_campaigns")[0], pg.locator('[data-mkprop]').last.inner_text()))
        # expandido: o botão continua logo à direita do + na linha de baixo
        pg.locator('textarea.composer-input').fill('Um texto bem maior para abrir o campo de digitação em duas linhas e conferir a posição do botão novo de modos'); pg.wait_for_timeout(500)
        g2=pg.evaluate(GEO)
        check(f'{nome}: campo expandido: Modos logo à direita do +, mesma linha do microfone e do enviar', pg.evaluate("document.querySelector('.ma-composer').classList.contains('is-open')") and 0<=g2['modos']['l']-g2['plus']['r']<=12 and abs((g2['modos']['t']+g2['modos']['h']/2)-(g2['plus']['t']+g2['plus']['h']/2))<2 and g2['ta']['b']<=g2['modos']['t']+2, (g2['plus'],g2['modos'],g2['ta']))
        pg.locator('textarea.composer-input').fill(''); pg.wait_for_timeout(300)
        # 4. volta ao chat normal
        pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo=""]'); pg.click('#ma-modos-card [data-modo=""]'); pg.wait_for_timeout(1200)
        c_=pg.evaluate("new URLSearchParams(location.search).get('c')")
        check(f'{nome}: "Chat normal" desativa o modo na conversa', pg.locator('.ma-modos-btn.on').count()==0 and not db('select 1 from conversa_modos where conversation_id=?',(c_,)), c_)
        pg.locator('textarea.composer-input').fill('Olá, tudo bem?'); pg.wait_for_timeout(200); pg.locator('[aria-label="Enviar"]').click()
        check(f'{nome}: chat tradicional responde normalmente', espera(pg,'Como posso ajudar'), ultima(pg)[:200])
        c.close()
    # 10. empresa sem anúncio completo: vê o recurso, recebe o aviso e a ação de contratar, sem executar o modo
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,storage_state=stB,is_mobile=True,has_touch=True,device_scale_factor=2); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('.ma-modos-btn',timeout=20000); pg.wait_for_timeout(3500)
    n0=db("select count(*) from messages")[0][0]
    pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo="marketing"]');
    check('anúncio básico: botão visível e Consultor marcado como exclusivo (🔒)', '🔒' in pg.inner_text('#ma-modos-card'))
    pg.click('#ma-modos-card [data-modo="marketing"]'); pg.wait_for_selector('[data-upsell]',timeout=5000)
    t=pg.inner_text('#ma-modos-card')
    check('anúncio básico: mensagem de benefício exclusivo do anúncio completo + ação para conhecer', 'benefício exclusivo do anúncio completo' in t and pg.locator('#ma-modos-card [data-go]').count()==1, t)
    pg.screenshot(path='/tmp/e2e/modos_bloqueado.png')
    pg.wait_for_timeout(800)
    check('anúncio básico: nenhuma mensagem enviada e modo não ativado', db("select count(*) from messages")[0][0]==n0 and pg.locator('.ma-modos-btn.on').count()==0)
    pg.click('#ma-modos-card [data-go]'); pg.wait_for_timeout(1500)
    check('anúncio básico: ação leva para conhecer/contratar', '/x/sua-empresa' in pg.url, pg.url)
    # chave no painel administrativo: Motor do chat → Modos inteligentes (desligar oculta o ⚡ para todos)
    ca=b.new_context(viewport={'width':1280,'height':900},base_url=BASE,storage_state=st,device_scale_factor=1); pa=ca.new_page(); pa.on('pageerror',lambda e:errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(3000)
    if pa.locator('[data-sw="modos_chat"]').count()==0: aba(pa,'motor')
    pa.wait_for_selector('[data-sw="modos_chat"]',timeout=20000); pa.wait_for_timeout(800)
    check('painel: chave "Modos inteligentes do chat" ligada por padrão', pa.get_attribute('[data-sw="modos_chat"]','aria-checked')=='true')
    pa.click('[data-sw="modos_chat"]'); pa.wait_for_timeout(1500)
    pa.screenshot(path='/tmp/e2e/modos_painel_desligado.png')
    check('painel: desligar grava a chave', pa.get_attribute('[data-sw="modos_chat"]','aria-checked')=='false' and 'Desligado' in pa.inner_text('[data-modos-cfg]') and A.get('/api/panel/public').json().get('modos_chat') is False)
    for nome,ctxst in [('dono',st),('anúncio básico',stB)]:
        cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,storage_state=ctxst,is_mobile=True,has_touch=True); pp=cc.new_page()
        pp.goto('/'); pp.wait_for_selector('textarea.composer-input',timeout=20000); pp.wait_for_timeout(4000)
        g=pp.evaluate("()=>{const q=s=>document.querySelector(s),r=e=>e.getBoundingClientRect();return {btn:document.querySelectorAll('.ma-modos-btn').length,plus:!!q('.ma-composer-bar button[aria-label^=\"Anexar\"]'),send:!!q('[aria-label=\"Enviar\"]'),ph:q('textarea.composer-input').placeholder}}")
        check(f'chave desligada ({nome}): botão ⚡ oculto, campo continua com +, enviar e texto', g['btn']==0 and g['plus'] and g['send'] and g['ph']=='Como posso ajudar você hoje?', g)
        if nome=='dono': pp.screenshot(path='/tmp/e2e/modos_desligado_campo.png')
        cc.close()
    pa.click('[data-sw="modos_chat"]'); pa.wait_for_timeout(1500)
    cc=b.new_context(viewport={'width':390,'height':844},base_url=BASE,storage_state=st,is_mobile=True,has_touch=True); pp=cc.new_page()
    pp.goto('/'); pp.wait_for_timeout(4500)
    check('religar no painel: botão ⚡ volta', pp.locator('.ma-modos-btn').count()==1 and pa.get_attribute('[data-sw="modos_chat"]','aria-checked')=='true')
    cc.close(); ca.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
