# Fase 9 — Laboratório de Inteligência pela tela real (/admin/laboratorio).
# Visão geral (real × estimativa × experimental), Arena (rodar e ver o resultado), Simulador (avaliação por mensagem),
# Agentes (criar, testar, enviar, aprovar gradual), Experimentos (atual × experimental → proposta), Diagnóstico,
# Melhorias, Evolução, Desafios contínuos, Auditoria; usuário comum sem acesso; atalho no painel; sem rolagem lateral.
import sys
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4311'
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-0000', 'email': 'adm@t.com', 'birthday': '1980-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    pg = adm.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
    def ir(sec, sel):
        pg.goto(f'/admin/laboratorio#{sec}'); pg.wait_for_selector(sel, timeout=20000)
    # atalho no painel
    pg.goto('/admin'); pg.wait_for_timeout(1500); pg.get_by_role('button', name='Laboratório de IA').click(); pg.wait_for_selector('#lab9link', timeout=10000)
    pg.locator('#lab9link').click(); pg.wait_for_url('**/admin/laboratorio'); pg.wait_for_selector('#v-nucleo', timeout=20000)
    check('atalho no Laboratório de IA abre o Laboratório de Inteligência', pg.locator('#v-nucleo').count() == 1)
    t = pg.inner_text('#c')
    check('visão geral separa métricas reais, estimativas e experimentais', all(x in t for x in ['Métricas reais', 'Estimativas', 'Indicadores experimentais', 'Estado operacional do núcleo', 'Desempenho dos agentes', 'Falhas identificadas', 'Evolução histórica da qualidade']), t[:300])
    check('cada métrica traz o selo do tipo', pg.locator('.tile .tag.real').count() >= 3 and pg.locator('.tile .tag.estimativa').count() >= 3 and pg.locator('.tile .tag.experimental').count() >= 2)
    # Arena: rodar uma categoria e ver o resultado detalhado
    ir('arena', '#ar-rodar')
    pg.locator('[data-cat="matematica"]').click(); pg.locator('#ar-rodar').click()
    pg.wait_for_selector('#rod-det[data-estado="concluida"]', timeout=30000)
    d = pg.inner_text('#rod-det')
    check('Arena roda e mostra nota, aprovados e por categoria', 'Nota da rodada' in d and 'Matemática' in d and 'Desafios aprovados' in d, d[:300])
    check('cada desafio com critérios e caminho (motor matemático)', pg.locator('#rod-det [data-caso="mat-percentual"]').count() == 1 and 'motor matemático' in pg.inner_text('#rod-det [data-caso="mat-percentual"]'))
    pg.screenshot(path='/tmp/e2e/lab9_arena.png', full_page=False)
    # desafio personalizado
    pg.locator('#fd-cat').select_option('logica'); pg.fill('#fd-tit', 'Pergunta sobre ordem'); pg.fill('#fd-pr', 'Quem chega primeiro: Ana às 9h ou Beto às 8h?')
    pg.locator('[data-crit] [data-cv]').first.fill('beto'); pg.locator('#fd-salvar').click(); pg.wait_for_timeout(1200)
    pg.locator('details.dcat').first.evaluate('e=>e.open=true')
    check('desafio personalizado criado pelo formulário', 'Pergunta sobre ordem' in pg.inner_text('#ar-lista'))
    pg.wait_for_selector('#fd-tit[value=""]'); pg.fill('#fd-tit', 'Contato real'); pg.fill('#fd-pr', 'mande para fulano.real@gmail.com'); pg.locator('[data-crit] [data-cv]').first.fill('ok')
    with pg.expect_response(lambda r: '/api/panel/laboratorio/desafios' in r.url and r.request.method == 'POST') as rr: pg.locator('#fd-salvar').click()
    pg.wait_for_timeout(300)
    check('dado pessoal real é recusado', rr.value.status == 400 and 'dado pessoal' in pg.inner_text('#toast'), pg.inner_text('#toast'))
    # Simulador
    ir('simulador', '#si-env')
    pg.locator('#si-cfg summary').click(); pg.fill('#si-mem', 'O usuário prefere respostas curtas.')
    pg.fill('#si-txt', 'gastei 50 no mercado'); pg.locator('#si-env').click(); pg.wait_for_selector('[data-av]', timeout=20000)
    av = pg.inner_text('[data-av]')
    check('simulador mostra a avaliação da resposta', all(x in av.upper() for x in ['INTERPRETAÇÃO', 'AMBIGUIDADES', 'MEMÓRIA', 'ESPECIALISTAS', 'AGENTES', 'FERRAMENTAS', 'PRECISÃO', 'QUALIDADE']), av[:300])
    check('precisão aponta o valor ignorado e nada foi gravado', 'não aparece na ação' in av and 'nada foi gravado' in pg.inner_text('#si-conv'), av[-300:])
    pg.fill('#si-txt', 'e amanhã?'); pg.locator('#si-env').click(); pg.wait_for_selector('[data-turno="2"]', timeout=20000)
    check('conversa continua na mesma simulação', pg.locator('.bolha.u').count() == 2 and 'eliptica' in pg.inner_text('#si-conv'))
    tasks = A.get('/api/items?type=expense').json()
    check('nenhum lançamento real criado pela simulação', not tasks.get('items'), tasks)
    # Agentes: criar → testar → enviar → aprovar gradual
    ir('agentes', '#nf-salvar')
    pg.fill('#nf-nome', 'Nutrição e saúde'); pg.fill('#nf-papel', 'nutrição e alimentação'); pg.fill('#nf-instr', 'Sugira refeições equilibradas e práticas, sem diagnóstico médico.'); pg.fill('#nf-gat', 'dieta, nutricao')
    pg.locator('#nf-salvar').click(); pg.wait_for_selector('[data-lab] >> text=Em experimentação', timeout=10000)
    lab = pg.locator('[data-lab]').first
    check('especialista criado em experimentação', 'Em experimentação' in lab.inner_text() and 'ainda não testado' in lab.inner_text())
    pg.fill('#ag-pr', 'monte um cardápio saudável para a semana'); pg.locator('#ag-testar').click(); pg.wait_for_selector('#ag-res [data-contrib]', timeout=20000)
    check('teste do especialista mostra a contribuição (sem efeito real)', 'nada foi gravado' in pg.inner_text('#ag-res'))
    pg.locator('[data-lab] [data-ag="enviar"]').first.click(); pg.wait_for_selector('[data-lab] >> text=Aguardando aprovação', timeout=10000)
    pg.locator('[data-lab] select[data-pct]').first.select_option('30'); pg.locator('[data-lab] [data-ag="aprovar_gradual"]').first.click(); pg.wait_for_selector('[data-lab] >> text=Liberação gradual 30%', timeout=10000)
    check('aprovação gradual (30%) com a versão em produção', 'produção: v1' in pg.locator('[data-lab]').first.inner_text())
    pg.locator('[data-cl="escrita"]').click(); pg.wait_for_timeout(1200)
    check('cópia experimental de um agente existente', 'substitui: escrita' in pg.inner_text('#ag-lab'))
    # Experimentos
    ir('experimentos', '#ex-rodar')
    pg.locator('#xt').select_option('raciocinio'); pg.locator('#xr-a').select_option('financas'); pg.fill('#xn', 'Revisar sempre em finanças')
    pg.locator('[data-xcat="financeiro"]').click(); pg.locator('#xrep').select_option('1'); pg.locator('#ex-rodar').click()
    pg.wait_for_selector('#ex-det[data-estado="concluida"] #ex-prop', timeout=40000)
    e = pg.inner_text('#ex-det')
    check('experimento compara versão atual × experimental nos mesmos desafios', 'Versão atual' in e and 'Versão experimental' in e and 'Diferença' in e and 'Interpretação financeira' in e, e[:300])
    pg.screenshot(path='/tmp/e2e/lab9_experimento.png', full_page=False)
    pg.locator('#ex-prop').click(); pg.wait_for_url('**#melhorias', timeout=10000); pg.wait_for_selector('#me-lista', timeout=10000)
    pg.locator('#me-est').select_option('todas'); pg.wait_for_timeout(1200)
    m = pg.inner_text('#me-lista')
    check('experimento vira proposta na Central (com os 7 campos)', 'Revisar sempre em finanças' in m and all(x in m.upper() for x in ['PROBLEMA IDENTIFICADO', 'CAUSA PROVÁVEL', 'SOLUÇÃO SUGERIDA', 'BENEFÍCIOS ESPERADOS', 'RISCOS', 'TESTES NECESSÁRIOS', 'RESULTADO DOS TESTES']), m[:400])
    check('produção intocada: política continua a padrão', A.get('/api/panel/laboratorio/evolucao').json()['politica']['versaoAtiva'] is None)
    card = pg.locator('[data-mel^="politica:"]').first
    card.locator('[data-medit]').click(); pg.wait_for_selector('[data-edform]')
    pg.locator('[data-campo="beneficios"]').fill('Menos valores errados em finanças.'); pg.locator('[data-msalvar]').click(); pg.wait_for_timeout(1200)
    check('editar o texto da proposta', 'Menos valores errados em finanças.' in pg.inner_text('#me-lista'))
    pg.locator('[data-mel^="politica:"]').first.locator('[data-macao="arquivar"]').click(); pg.wait_for_timeout(1200)
    pg.locator('#me-est').select_option('arquivadas'); pg.wait_for_timeout(1200)
    check('arquivar proposta', 'arquivada' in pg.inner_text('#me-lista'))
    # Diagnóstico, Evolução, Contínuos, Auditoria
    ir('diagnostico', '#dg-gerar'); check('centro de diagnóstico com tipos de achados', all(x in pg.inner_text('#c') for x in ['Respostas inconsistentes', 'Falhas de interpretação', 'Gargalos de desempenho', 'Agentes com baixo desempenho']))
    ir('evolucao', '#ev-pol'); ev = pg.inner_text('#c')
    check('evolução: fluxo, política, especialistas em produção e linha do tempo', 'Liberação gradual (por usuário)' in ev and 'Nutrição e saúde' in pg.inner_text('#ev-ag') and 'Linha do tempo' in ev, ev[:300])
    ir('continuos', '#ct-salvar'); pg.fill('#ct-nome', 'Avaliação diária'); pg.locator('[data-ccat="matematica"]').click(); pg.locator('#ct-salvar').click(); pg.wait_for_selector('[data-agenda]', timeout=10000)
    pg.locator('[data-ctrel]').first.click(); pg.wait_for_selector('[data-rel]', timeout=10000)
    check('desafio contínuo programado com relatório comparativo', 'Avaliação contínua: Avaliação diária' in pg.inner_text('[data-rel]'))
    ir('auditoria', '#au'); au = pg.inner_text('#au')
    check('auditoria registra as ações', all(x in au for x in ['laboratorio.arena', 'laboratorio.agente.criar', 'laboratorio.experimento']), au[:300])
    for w, h in [(390, 860), (1280, 900)]:
        pg.set_viewport_size({'width': w, 'height': h})
        for sec, sel in [('visao', '#v-nucleo'), ('agentes', '#ag-lab'), ('melhorias', '#me-lista'), ('experimentos', '#ex-form')]:
            ir(sec, sel); ov = pg.evaluate("()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})")
            if ov['sw'] > ov['cw'] + 1: check(f'{sec} sem rolagem horizontal em {w}px', False, ov)
        check(f'sem rolagem horizontal em {w}px', True)
    pg.set_viewport_size({'width': 390, 'height': 860}); ir('visao', '#v-nucleo'); pg.screenshot(path='/tmp/e2e/lab9_visao_390.png', full_page=False)
    # usuário comum
    u = b.new_context(viewport={'width': 390, 'height': 860}, base_url=BASE)
    assert u.request.post('/api/auth', data={'action': 'signup', 'name': 'Ana Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'ana@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.8.0.9'}).ok
    pu = u.new_page(); pu.on('pageerror', lambda e: errs.append(str(e))); pu.goto('/admin/laboratorio'); pu.wait_for_selector('.neg', timeout=10000)
    check('usuário comum vê "acesso restrito" e nenhum dado', 'Acesso restrito' in pu.inner_text('body') and 'Métricas reais' not in pu.inner_text('body'))
    check('sem erros de JavaScript', not [x for x in errs if 'React error #418' not in x and x != 'Event'], errs)
    b.close()
print('FIM', 'OK' if all(res) else 'FALHOU', f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
