# Importação de cardápios com TODAS as IAs desligadas, de ponta a ponta e pela tela (Sua empresa → Produtos → Importar cardápio):
# central REAL (services/central-midia: Tesseract + regras) + servidor completo (SQLite) + modo "Sem IA (teste)".
# Fotos inclinadas/de lado, várias fotos do mesmo cardápio, PDF digital de várias páginas, PDF escaneado, foto parcialmente
# ilegível, conferência (editar/excluir/confirmar), cadastro só após confirmar, importação duplicada, separação entre empresas
# e prova de que nenhuma IA foi chamada.
# Uso (na pasta server):  python3 test/browser/cardapio_sem_ia.py
import os, sys, time, socket, subprocess, urllib.request, pathlib
from playwright.sync_api import sync_playwright
RAIZ = pathlib.Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RAIZ / 'services' / 'central-midia'))
from tests import cardapios as CD  # noqa: E402

def porta_livre():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p
PC, PS = porta_livre(), porta_livre()
TOKEN = 'e2e-cardapio-local-' + 'k' * 24
BASE = f'http://127.0.0.1:{PS}'
OUT = pathlib.Path('/tmp/e2e'); OUT.mkdir(exist_ok=True)
res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:500]))

db = '/tmp/ma-cardapio-local.db'
for x in (db, db + '-wal', db + '-shm'):
    try: os.remove(x)
    except FileNotFoundError: pass
LOG = '/tmp/e2e/cardapio-local-servidor.log'
log = open(LOG, 'w')
central = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', str(PC), '--log-level', 'warning'],
                           cwd=RAIZ / 'services' / 'central-midia', env={**os.environ, 'MIDIA_TOKEN': TOKEN, 'DIR_TEMP': '/tmp/central-e2e-cd', 'TEMPO_LIMITE_S': '120'}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
srv = subprocess.Popen(['npx', 'tsx', 'test/serve-sqlite.ts'], cwd=RAIZ / 'server', stdout=log, stderr=subprocess.STDOUT,
                       env={**os.environ, 'PORT': str(PS), 'SQLITE_FILE': db, 'MIDIA_URL': f'http://127.0.0.1:{PC}', 'MIDIA_TOKEN': TOKEN})
def espera(url, n=150):
    for _ in range(n):
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status == 200: return True
        except Exception: pass
        time.sleep(0.3)
    return False
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
try:
    check('central de mídias REAL no ar', espera(f'http://127.0.0.1:{PC}/saude'))
    check('Meu Assistente no ar (SQLite de teste)', espera(BASE + '/api/health'))
    with sync_playwright() as p:
        b = p.chromium.launch(); errs = []
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, has_touch=True, is_mobile=True); R = ctx.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Clara Souza', 'whatsapp': '+55 11 94444-1234', 'email': 'ana.cd@t.com', **U}).ok
        R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
        check('modo "Sem IA (teste)": todas as IAs desligadas', R.put('/api/panel/brain_mode', data={'modoIA': 'sem_ia'}).ok)
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Lanchonete do Zé', 'categoria': 'Lanchonete', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'})
        ID = r.json()['items'][0]['id']
        log.flush(); inicio_log = os.path.getsize(LOG)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
        pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('[data-mim=ia]', timeout=10000)
        def nova_importacao():
            pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_img', state='attached', timeout=8000)
        def revisao(t=180):
            pg.wait_for_selector('#mi_pub,#mi_rt,#mi_ab', timeout=t * 1000); pg.wait_for_timeout(400)
            return pg.inner_text('#mi_body')
        def item(nome):
            return pg.locator(f'.mi-item:has(input[data-f=nome][value="{nome}"])')
        prods = lambda: R.get(f'/api/v2/ads/{ID}/products').json()['items']

        # ---------- 1) três FOTOS do cardápio (inclinada, de lado, outra página) ----------
        nova_importacao()
        fotos = [('cardapio-p1.jpg', CD.fotografar(CD.renderizar('lanchonete'), semente=3)),
                 ('cardapio-p2.jpg', CD.fotografar(CD.renderizar('pizzaria'), semente=4, de_lado=True)),
                 ('cardapio-p3.jpg', CD.fotografar(CD.renderizar('acai'), semente=7))]
        pg.set_input_files('#mi_img', [{'name': n, 'mimeType': 'image/jpeg', 'buffer': d} for n, d in fotos]); pg.wait_for_timeout(300)
        check('três fotos na lista de envio', all(n in pg.inner_text('#mi_files') for n, _ in fotos))
        t0 = time.time(); pg.click('#mi_go')
        try: pg.wait_for_selector('.mi-doc', timeout=8000); pg.screenshot(path=str(OUT / 'cardapio_0_processando.png'))
        except Exception: pass
        corpo = revisao(); dt = time.time() - t0
        pg.screenshot(path=str(OUT / 'cardapio_1_revisao.png'), full_page=True)
        check(f'fotos lidas no servidor, sem IA, em {dt:.0f} s', 'Lido no servidor · sem IA' in corpo and 'Revise antes de cadastrar' in corpo, corpo[:300])
        cats = ['HAMBÚRGUERES', 'BEBIDAS', 'PIZZAS SALGADAS', 'PIZZAS DOCES', 'AÇAÍ']
        check('categorias de cada página', all(c in corpo.upper() for c in cats), corpo[:600])
        val = lambda n, f: item(n).locator(f'[data-f={f}]').input_value() if item(n).count() else None
        check('preços com vírgula decimal (X-Burguer 22,9 · X-Salada 25,5 · Água 3,5)', val('X-Burguer', 'preco') == '22,9' and val('X-Salada', 'preco') == '25,5' and val('Água mineral', 'preco') == '3,5', (val('X-Burguer', 'preco'), val('X-Salada', 'preco')))
        check('tamanhos (pizza Broto/Média/Grande · suco 300ml/500ml · açaí 300/500/700 ml)', 'Broto=28' in val('Calabresa', 'var') and 'Grande=55' in val('Calabresa', 'var') and '500ml=12' in val('Suco natural', 'var') and '700 ml=24' in val('Açaí tradicional', 'var'), (val('Calabresa', 'var'), val('Suco natural', 'var'), val('Açaí tradicional', 'var')))
        check('adicionais separados dos produtos (Bacon/Ovo/Cheddar nos hambúrgueres · Granola no açaí)', 'Bacon=5' in val('X-Bacon', 'add') and 'Cheddar=4' in val('X-Burguer', 'add') and 'Granola=2' in val('Açaí tradicional', 'add') and not item('Bacon').count() and not item('Granola').count(), (val('X-Bacon', 'add'), val('Açaí tradicional', 'add')))
        check('descrição original do cardápio', 'molho da casa' in (val('X-Burguer', 'desc') or '') and 'original do cardápio' in corpo)
        check('nenhuma descrição sugerida por IA', 'sugerida pela IA' not in corpo)
        check('"Taxa de entrega" não virou produto', not item('Taxa de entrega').count())
        check('nada cadastrado antes da confirmação', len(prods()) == 0)
        # conferência: editar preço, excluir item, conferir os marcados
        item('Água mineral').locator('[data-f=preco]').fill('4,00'); item('Água mineral').locator('[data-f=nome]').fill('Água mineral 500ml')
        item('Chocolate').locator('[data-del]').click(); pg.wait_for_timeout(600)
        for el in pg.locator('.mi-item [data-f=confirmado]').all():
            el.check()
        pg.wait_for_timeout(1500)
        pg.screenshot(path=str(OUT / 'cardapio_2_conferencia.png'), full_page=True)
        pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver', timeout=30000)
        check('cadastrado só após confirmar', 'Importação concluída com sucesso!' in pg.inner_text('#mi_body'))
        nm = {x['nome']: x for x in prods()}
        check('produtos no cadastro atual (com origem da importação)', {'X-Burguer', 'X-Salada', 'X-Bacon', 'Calabresa', 'Marguerita', 'Suco natural', 'Açaí tradicional', 'Água mineral 500ml'} <= set(nm) and all(x['origem']['fonte'] == 'importacao_cardapio' for x in nm.values()), sorted(nm))
        check('edição aplicada e item excluído não cadastrado', nm['Água mineral 500ml']['preco'] == 4 and 'Chocolate' not in nm)
        check('tamanhos e adicionais no produto (regra de preço do catálogo)', [o['preco'] for o in nm['Calabresa']['variacoes'][0]['opcoes']] == [28, 42, 55] and any(v['nome'] == 'Adicionais' for v in nm['X-Burguer']['variacoes']))
        pg.screenshot(path=str(OUT / 'cardapio_3_concluido.png'))

        # ---------- 2) PDF digital de VÁRIAS páginas (2 colunas + preço abaixo do nome) ----------
        nova_importacao()
        pdf = CD.pdf_digital(['cafeteria_2col', 'executivo'])
        pg.set_input_files('#mi_doc', {'name': 'cardapio.pdf', 'mimeType': 'application/pdf', 'buffer': pdf}); pg.click('#mi_go')
        corpo = revisao()
        check('PDF de 2 páginas: colunas separadas e categorias certas', all(c in corpo.upper() for c in ['CAFÉS', 'SALGADOS', 'PRATOS EXECUTIVOS', 'SOBREMESAS']) and val('Croissant misto', 'preco') == '12,9' and val('Cappuccino', 'preco') == '9,5', corpo[:400])
        check('preço na linha de baixo associado ao prato certo', val('Frango grelhado', 'preco') == '32,9' and val('Parmegiana de carne', 'preco') == '39,9')
        check('observação e indisponibilidade lidas', val('Parmegiana de carne', 'observacoes') == 'serve 1 pessoa' and 'Indisponível no cardápio' in item('Mousse de maracujá').inner_text())
        pg.locator('#mi_body').screenshot(path=str(OUT / 'cardapio_4_pdf.png'))
        pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver', timeout=30000)
        check('PDF cadastrado', {'Expresso', 'Coxinha', 'Frango grelhado', 'Pudim de leite'} <= {x['nome'] for x in prods()})

        # ---------- 3) mesmo PDF de novo: importação duplicada barrada ----------
        nova_importacao()
        pg.set_input_files('#mi_doc', {'name': 'cardapio.pdf', 'mimeType': 'application/pdf', 'buffer': pdf}); pg.click('#mi_go')
        pg.wait_for_selector('#mi_ab', timeout=30000)
        check('importação duplicada: "Este cardápio já foi importado"', 'Este cardápio já foi importado' in pg.inner_text('#mi_body'))
        n_antes = len(prods())

        # ---------- 4) PDF ESCANEADO + foto PARCIALMENTE ILEGÍVEL ----------
        nova_importacao()
        pg.set_input_files('#mi_doc', {'name': 'escaneado.pdf', 'mimeType': 'application/pdf', 'buffer': CD.pdf_escaneado(['acai'], semente=9)})
        pg.set_input_files('#mi_img', {'name': 'borrada.jpg', 'mimeType': 'image/jpeg', 'buffer': CD.foto_borrada('lanchonete', 6)}); pg.click('#mi_go')
        corpo = revisao()
        pg.locator('#mi_body').screenshot(path=str(OUT / 'cardapio_5_ilegivel.png'))
        xb = item('X-Burguer')
        check('trecho ilegível: preço NÃO inventado, item marcado para revisão e desmarcado', xb.count() and val('X-Burguer', 'preco') == '' and 'Preço não identificado' in xb.inner_text() and not xb.locator('[data-f=selecionado]').is_checked(), xb.inner_text()[:300] if xb.count() else corpo[:300])
        check('nome coberto não aparece inventado', not item('X-Salada').count())
        check('PDF escaneado lido (açaí com 3 tamanhos)', '300 ml=14' in (val('Açaí tradicional', 'var') or '') and '700 ml=24' in (val('Açaí tradicional', 'var') or ''))
        pg.click('#mi_cn2'); pg.wait_for_timeout(1200)
        check('cancelar: nada cadastrado', len(prods()) == n_antes)

        # ---------- 5) separação entre empresas ----------
        O = b.new_context(base_url=BASE); RO = O.request
        assert RO.post('/api/auth', data={'action': 'signup', 'name': 'Bruno Lima', 'whatsapp': '+55 11 95555-0101', 'email': 'bruno.cd@t.com', **U}, headers={'X-Forwarded-For': '10.7.7.7'}).ok
        lst = R.get(f'/api/v2/ads/{ID}/menu-imports').json()['itens']
        check('outra empresa não vê nem publica importações alheias', RO.get(f'/api/v2/ads/{ID}/menu-imports').status in (403, 404) and RO.get(f'/api/v2/ads/{ID}/menu-imports/{lst[0]["id"]}').status in (403, 404) and RO.post(f'/api/v2/ads/{ID}/menu-imports/{lst[0]["id"]}/publicar', data={}).status in (403, 404))
        O.close()

        log.flush(); txt = open(LOG).read()[inicio_log:]
        check('nenhuma IA externa chamada (registro do servidor sem "[ai] provedor")', '[ai] provedor' not in txt and '[cardapio] leitura direta falhou' not in txt, [l for l in txt.splitlines() if '[ai]' in l or 'cardapio' in l][:3])
        errs = [e for e in errs if '#418' not in e and e != 'Event']
        check('sem erros de JavaScript (fora o aviso antigo de hidratação #418)', not errs, errs[:3])
        b.close()
finally:
    srv.terminate(); central.terminate()
    try: srv.wait(5); central.wait(5)
    except Exception: srv.kill(); central.kill()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); sys.exit(0 if all(res) else 1)
