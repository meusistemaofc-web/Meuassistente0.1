# Cards de produtos e serviços em carrossel horizontal no chat da empresa (/a/:id).
# Rodar com o servidor de UI: DBP=/tmp/ma-ui.db bash /tmp/cp/fresh.sh
import json, sys, sqlite3, datetime
from playwright.sync_api import sync_playwright
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
BASE='http://localhost:4311'
DBF='/tmp/ma-ui.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
LONGA='Fineline delicado com sombreamento suave, feito com agulhas finas e tinta de alta durabilidade. Inclui retoque gratuito em 30 dias.'
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(base_url=BASE)
    R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Ivaslovck Tattoo','categoria':'Tatuagens','titulo':'Tattoo','texto':'x','zap':'5511999990000','tipo':'servicos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{}}}).ok
    assert R.put(f'/api/v2/ads/{ID}/agent',data={'ativo':True}).ok
    SERV=[('Fineline pequeno',150,'Tatuagem',LONGA,{}),('Blackwork médio',400,'Tatuagem','Traço forte.',{}),('Realismo',0,'Tatuagem','',{'modoPreco':'orcamento','preco':900,'sinal':{'ativo':True,'tipo':'fixo','valor':100}}),
          ('Cobertura',350,'Tatuagem','',{}),('Lettering',120,'Tatuagem','',{}),('Piercing nariz',80,'Piercing','Joia de titânio inclusa.',{}),('Piercing orelha',60,'Piercing','',{})]
    for nome,preco,cat,desc,extra in SERV:
        d={'nome':nome,'preco':preco,'tipo':'servico','modoPreco':'fixo','duracao':60,'categoria':cat,'descricao':desc}; d.update(extra)
        rp=R.post(f'/api/v2/ads/{ID}/products',data=d); assert rp.ok, rp.text()
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok
    for nome in ['Caneca','Camiseta','Pomada cicatrizante']:
        assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':nome,'preco':30,'tipo':'produto','categoria':'Produtos','fotos':[IMG],'descricao':'Item da loja.'}).ok
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'services','confirmar':True}).ok  # modalidade exclusiva: produtos ficam salvos, ocultos
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']['expiresAt']=(datetime.datetime.utcnow()+datetime.timedelta(days=30)).isoformat()+'Z'; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit()
    antes=db.execute('select count(*), group_concat(data) from products where business_id=?',(ID,)).fetchone(); db.close()
    errs=[]
    CAR="""()=>{const rs=[...document.querySelectorAll('.rich')];const r=rs[rs.length-1];const tr=r.querySelector('.prods');const cs=[...tr.querySelectorAll('.pc')];const bx=r.getBoundingClientRect(),tb=tr.getBoundingClientRect();
      return {rich:bx.width,tr:tb.width,trL:tb.left,trR:tb.right,sl:tr.scrollLeft,sw:tr.scrollWidth,cw:tr.clientWidth,snap:getComputedStyle(tr).scrollSnapType,ox:getComputedStyle(tr).overflowX,
        cards:cs.map(c=>{const q=c.getBoundingClientRect(),ph=c.querySelector('.ph').getBoundingClientRect(),bt=c.querySelector('button').getBoundingClientRect();return {w:q.width,h:q.height,l:q.left,r:q.right,phw:ph.width,phh:ph.height,bh:bt.height,bw:bt.width,t:c.innerText,rad:parseFloat(getComputedStyle(c).borderTopLeftRadius)}}),
        dots:r.querySelectorAll('.dots i').length,on:[...r.querySelectorAll('.dots i')].findIndex(i=>i.classList.contains('on')),fit:r.querySelector('.car').classList.contains('fit'),
        nav:getComputedStyle(r.querySelector('.cnav')).display,prev:r.querySelector('[data-nav="-1"]').disabled,next:r.querySelector('[data-nav="1"]').disabled,
        cats:[...r.querySelectorAll('[data-c]')].map(x=>x.textContent),cur:(r.querySelector('[data-c].on')||{}).textContent,page:document.documentElement.scrollWidth-innerWidth}}"""
    for nome,vp,mobile in [('celular',{'width':390,'height':844},True),('tablet',{'width':820,'height':1180},True),('computador',{'width':1280,'height':800},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button',timeout=15000)
        pg.click('#acts [data-a=srv]'); pg.wait_for_selector('.rich .prods',timeout=8000); pg.wait_for_timeout(500)
        s=pg.evaluate(CAR); cs=s['cards']
        check(f'{nome}: categorias mantidas, cada uma com seu carrossel (Tatuagem, Piercing)', s['cats']==['Tatuagem','Piercing'] and s['cur']=='Tatuagem' and len(cs)==5, (s['cats'],len(cs)))
        check(f'{nome}: rolagem horizontal com encaixe', s['ox']=='auto' and 'x' in s['snap'] and s['sw']>s['cw'], (s['ox'],s['snap']))
        if nome=='celular':
            fr=cs[0]['w']/s['rich']
            check(f'celular: card ocupa ~80–85% da largura disponível', 0.74<=fr<=0.86, (cs[0]['w'],s['rich'],fr))
        else:
            check(f'{nome}: card amplo em tela grande (≥ 300 px, sem esticar demais)', 300<=cs[0]['w']<=330, cs[0]['w'])
        pv=[round(s['trR']-x['l']) for x in cs if x['l']<s['trR'] and x['r']>s['trR']+1]
        check(f'{nome}: próximo card aparece parcialmente (≥ 40 px), indicando que há mais', len(pv)==1 and pv[0]>=40, (pv,s['trR']))
        check(f'{nome}: imagem em destaque, proporção 4:3 em todos', all(abs(x['phw']/x['phh']-4/3)<0.03 for x in cs), [(x['phw'],x['phh']) for x in cs][:2])
        check(f'{nome}: cards com a mesma altura', len({round(x['h']) for x in cs})==1, [x['h'] for x in cs])
        check(f'{nome}: botão de ação maior (≥ 44 px, largura toda)', all(x['bh']>=44 and x['bw']>=x['w']-30 for x in cs), [(x['bh'],x['bw']) for x in cs][:2])
        check(f'{nome}: bordas arredondadas', cs[0]['rad']>=16, cs[0]['rad'])
        t0=cs[0]['t']
        check(f'{nome}: card só com imagem, nome, preço e duração (sem descrição)', 'Fineline pequeno' in t0 and 'Fineline delicado' not in t0 and 'R$' in t0 and '60 min' in t0 and 'Agendar' in t0 and pg.locator('.rich .pc .pd').count()==0, t0)
        rz=[x['t'] for x in cs if 'Realismo' in x['t']][0]
        check(f'{nome}: condições preservadas (sob orçamento + sinal)', 'Sob orçamento' in rz and 'sinal' in rz and 'R$' in rz, rz)
        check(f'{nome}: indicador de posição (5 pontos, 1º ativo) e navegação visível', s['dots']==5 and s['on']==0 and s['nav']!='none' and s['prev'] and not s['next'], (s['dots'],s['on'],s['nav'],s['prev'],s['next']))
        check(f'{nome}: página sem rolagem horizontal', s['page']<=1, s['page'])
        pg.click('.rich [data-nav="1"]'); pg.wait_for_timeout(700)
        s2=pg.evaluate(CAR)
        check(f'{nome}: seta "próximo" avança exatamente um card', abs(s2['sl']-(cs[1]['l']-cs[0]['l']))<=3 and s2['on']==1 and not s2['prev'], (s2['sl'],cs[1]['l']-cs[0]['l'],s2['on']))
        pg.click('.rich [data-nav="-1"]'); pg.wait_for_timeout(700)
        check(f'{nome}: seta "anterior" volta', pg.evaluate(CAR)['sl']<=2)
        if mobile:
            box=pg.locator('.rich .prods').bounding_box(); y=box['y']+box['height']*0.3
            sl=pg.evaluate("""([x0,x1,y])=>new Promise(res=>{const tr=document.querySelector('.rich .prods');const T=(x)=>new Touch({identifier:1,target:tr,clientX:x,clientY:y});
              tr.dispatchEvent(new TouchEvent('touchstart',{touches:[T(x0)],bubbles:true}));tr.scrollBy({left:x0-x1,behavior:'auto'});tr.dispatchEvent(new TouchEvent('touchend',{changedTouches:[T(x1)],bubbles:true}));setTimeout(()=>res(tr.scrollLeft),700)})""",[box['x']+box['width']*0.8,box['x']+box['width']*0.2,y])
            s3=pg.evaluate(CAR)
            check(f'{nome}: deslizar com o dedo encaixa no próximo card e atualiza o indicador', s3['on']>=1 and any(abs(s3['sl']-(x['l']-cs[0]['l']))<=3 for x in cs), (sl,s3['on']))
            pg.evaluate("()=>{const tr=document.querySelector('.rich .prods');tr.style.scrollBehavior='auto';tr.scrollLeft=tr.scrollWidth}"); pg.wait_for_timeout(500)
            s4=pg.evaluate(CAR)
            check(f'{nome}: no fim, último ponto ativo e "próximo" desativado', s4['on']==4 and s4['next'], (s4['on'],s4['next']))
        else:
            box=pg.locator('.rich .prods').bounding_box(); y=box['y']+60
            pg.mouse.move(box['x']+box['width']*0.8,y); pg.mouse.down(); pg.mouse.move(box['x']+box['width']*0.5,y,steps=8); pg.mouse.move(box['x']+box['width']*0.2,y,steps=8); pg.mouse.up(); pg.wait_for_timeout(800)
            s3=pg.evaluate(CAR); n_rich=pg.locator('.rich').count()
            check(f'{nome}: arrastar com o mouse rola e encaixa num card', s3['sl']>50 and any(abs(s3['sl']-(x['l']-cs[0]['l']))<=3 for x in cs), s3['sl'])
            check(f'{nome}: arrastar não dispara o botão do card', n_rich==1, n_rich)
            pg.focus('.rich .prods'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(700)
            check(f'{nome}: teclado (seta) navega no carrossel', pg.evaluate(CAR)['sl']>s3['sl'])
        # trocar de categoria e voltar preserva a posição
        pg.evaluate("()=>{const tr=document.querySelector('.rich .prods');tr.style.scrollBehavior='auto';tr.scrollLeft=(tr.children[2].offsetLeft-tr.children[0].offsetLeft)}"); pg.wait_for_timeout(400)
        pg.click('.rich [data-c="Piercing"]'); pg.wait_for_timeout(400)
        sp=pg.evaluate(CAR)
        check(f'{nome}: Piercing mostra só os 2 serviços de Piercing', [('Piercing' in x['t']) for x in sp['cards']]==[True,True] and sp['cur']=='Piercing', [x['t'][:20] for x in sp['cards']])
        if nome!='celular':
            check(f'{nome}: categoria que cabe inteira esconde a navegação', sp['fit'] and sp['nav']=='none', (sp['fit'],sp['nav']))
        pg.click('.rich [data-c="Tatuagem"]'); pg.wait_for_timeout(500)
        st=pg.evaluate(CAR)
        check(f'{nome}: voltar à categoria mantém a posição do carrossel', st['on']==2, st['on'])
        # tocar no card (foto ou nome) abre os detalhes, com a descrição completa
        pg.evaluate("()=>{const tr=document.querySelector('.rich .prods');tr.style.scrollBehavior='auto';tr.scrollLeft=0}"); pg.wait_for_timeout(300)
        pg.locator('.rich .pc', has_text='Fineline pequeno').locator('.ph').click(); pg.wait_for_selector('.det',timeout=5000); pg.wait_for_timeout(300)
        dt=pg.locator('.det').inner_text()
        check(f'{nome}: detalhes: nome, preço, duração, categoria e descrição completa', 'Fineline pequeno' in dt and 'R$' in dt and '60 min' in dt and 'Tatuagem' in dt and pg.locator('.det [data-desc]').inner_text().strip()==LONGA, dt[:300])
        db_=pg.locator('.det-c').bounding_box()
        check(f'{nome}: detalhes cabem na tela, sem rolagem horizontal', db_['width']<=vp['width']+1 and pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1, db_)
        pg.screenshot(path=f'/tmp/e2e/carrossel_{nome}_detalhes.png')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        check(f'{nome}: detalhes fecham (Esc)', pg.locator('.det').count()==0)
        u0=pg.url; pg.locator('.rich .pc', has_text='Blackwork médio').locator('.pn').click(); pg.wait_for_selector('.det',timeout=5000)
        pg.go_back(); pg.wait_for_timeout(400)
        check(f'{nome}: voltar do celular fecha os detalhes sem sair do chat', pg.locator('.det').count()==0 and pg.url==u0 and pg.locator('.rich .prods').count()>=1, pg.url)
        pg.locator('.rich .pc', has_text='Blackwork médio').locator('.pn').click(); pg.wait_for_selector('.det',timeout=5000)
        pg.click('.det [data-go]'); pg.wait_for_timeout(900)
        last=pg.locator('.rich').last.inner_text()
        check(f'{nome}: "Agendar" dos detalhes abre o agendamento do serviço', pg.locator('.det').count()==0 and 'Blackwork médio' in last and pg.locator('.rich').count()==2, last[:120])
        pg.reload(); pg.wait_for_selector('#acts button',timeout=15000); pg.click('#acts [data-a=srv]'); pg.wait_for_selector('.rich .prods',timeout=8000); pg.wait_for_timeout(400)
        # funções preservadas: Agendar abre o agendamento do serviço certo
        pg.locator('.rich .pc', has_text='Blackwork médio').locator('[data-pid]').click(); pg.wait_for_timeout(900)
        last=pg.locator('.rich').last.inner_text()
        check(f'{nome}: Agendar abre o agendamento do serviço escolhido', 'Blackwork médio' in last and pg.locator('.rich').count()==2, last[:120])
        # produtos: Adicionar continua indo para o carrinho
        check(f'{nome}: modalidade de serviços: sem atalho nem carrossel de produtos', pg.locator('#acts [data-a=cat]').count()==0)
        c.close()
        # produtos: a MESMA empresa na modalidade de produtos (troca confirmada; os serviços ficam salvos, ocultos)
        assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button',timeout=15000)
        if pg.locator('#acts [data-a=mais]').count(): pg.click('#acts [data-a=mais]')
        pg.click('#acts [data-a=cat]'); pg.wait_for_selector('.rich .prods',timeout=8000); pg.wait_for_timeout(400)
        sc=pg.evaluate(CAR)
        check(f'{nome}: catálogo de produtos em carrossel com fotos', sc['cats']==['Produtos'] and len(sc['cards'])==3 and pg.locator('.rich .pc .ph img').count()==3 and all('Adicionar' in x['t'] for x in sc['cards']), (sc['cats'],len(sc['cards'])))
        pg.screenshot(path=f'/tmp/e2e/carrossel_{nome}_produtos.png')
        pg.locator('.rich .pc', has_text='Camiseta').locator('[data-pid]').click(); pg.wait_for_timeout(700)
        check(f'{nome}: Adicionar continua colocando no pedido', 'Adicionei 1× Camiseta' in pg.inner_text('body'))
        pg.locator('.rich .pc', has_text='Caneca').first.locator('.ph').click(); pg.wait_for_selector('.det',timeout=5000)
        check(f'{nome}: detalhes do produto com descrição e "Adicionar"', 'Item da loja.' in pg.locator('.det [data-desc]').inner_text() and pg.locator('.det [data-go]').inner_text().strip()=='Adicionar' and pg.locator('.det .det-ph img').count()==1)
        pg.click('.det [data-go]'); pg.wait_for_timeout(700)
        check(f'{nome}: "Adicionar" dos detalhes coloca no pedido', 'Adicionei 1× Caneca' in pg.inner_text('body') and pg.locator('.det').count()==0)
        c.close()
        assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'services','confirmar':True}).ok
        # captura do carrossel de serviços
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mobile,is_mobile=mobile,device_scale_factor=2); pg=c.new_page()
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button',timeout=15000); pg.click('#acts [data-a=srv]'); pg.wait_for_selector('.rich .prods'); pg.wait_for_timeout(600)
        pg.screenshot(path=f'/tmp/e2e/carrossel_{nome}.png'); c.close()
    # empresa fechada: aviso no card, e o botão continua explicando
    db=sqlite3.connect(DBF); row=db.execute('select data from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['horarioCfg']={'modo':'fechado','dias':{}}; db.execute('update businesses set data=? where id=?',(json.dumps(d),ID)); db.commit(); db.close()
    R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'fechado','dias':{}}})
    c=b.new_context(viewport={'width':390,'height':844},base_url=BASE,has_touch=True,is_mobile=True); pg=c.new_page()
    pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button',timeout=15000)
    pg.click('#acts [data-a=srv]'); pg.wait_for_selector('.rich .pc',timeout=8000); pg.wait_for_timeout(400)
    check('empresa fechada: catálogo continua visível', pg.locator('.rich .pc').count()==5)
    if True:
        check('empresa fechada: selo "Fechado agora" no card', pg.locator('.rich .pc .fch').count()==5, pg.locator('.rich .pc .fch').count())
        pg.locator('.rich [data-pid]').first.click(); pg.wait_for_timeout(500)
        check('empresa fechada: botão mantém a regra atual (explica e não agenda)', 'está fechada agora' in pg.inner_text('body'))
    c.close()
    db=sqlite3.connect(DBF); depois=db.execute('select count(*), group_concat(data) from products where business_id=?',(ID,)).fetchone(); db.close()
    check('cadastros intactos: nenhum produto/serviço duplicado ou alterado', antes==depois, (antes[0],depois[0]))
    check('sem erros de JavaScript na página', not errs, errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
