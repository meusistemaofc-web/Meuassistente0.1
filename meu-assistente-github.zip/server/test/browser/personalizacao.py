# Personalizar Agente de Atendimento e Personalizar Página de Links (painel da empresa, celular e computador):
# - liga/desliga de cada botão do agente salva na hora e some/volta no atendimento público (e na prévia);
# - Página de Links: ocultar capa/logo/título/descrição/botões, botão a botão, posição e tamanho do logotipo,
#   prévia antes de publicar e página pública depois de publicar; logotipo proporcional no celular;
# - outra empresa não altera nada.
# Servidor: PORT=4313 SQLITE_FILE=/tmp/ma-pz.db npx tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4313'; DBF = '/tmp/ma-pz.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
iso = lambda d: (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=d)).isoformat().replace('+00:00', 'Z')
LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); RA = A.request
    assert RA.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    RA.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    db = sqlite3.connect(DBF)
    def dono(nome, email, ip, empresa, vp):
        c = b.new_context(base_url=BASE, viewport=vp, is_mobile=vp['width'] < 600, has_touch=vp['width'] < 600); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': nome, 'whatsapp': '+55 11 95555-0' + ip, 'email': email, **U}, headers={'X-Forwarded-For': '10.9.9.' + ip}).ok
        i = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': 'Barbearia', 'titulo': 'Cortes', 'texto': 'Cortes e barba com hora marcada', 'zap': '5511999990000'}).json()['items'][0]['id']
        d = json.loads(db.execute('select data from businesses where id=?', (i,)).fetchone()[0])
        d.update({'aprovadoEm': iso(0), 'tipo': 'servicos', 'endereco': 'Rua das Flores, 100 - Centro', 'logo': LOGO,
                  'agente': {'nome': 'Assistente', 'ativo': True, 'expiresAt': iso(20)}})
        db.execute("update businesses set status='ativo', expires_at=?, data=? where id=?", (iso(30), json.dumps(d), i)); db.commit()
        r = R.post(f'/api/v2/ads/{i}/products', data={'tipo': 'servico', 'nome': 'Corte masculino', 'preco': 45, 'modoPreco': 'fixo', 'duracao': 40, 'categoria': 'Cortes'})
        assert r.ok, r.text()
        return c, R, i
    for nome_vp, vp in [('celular', {'width': 390, 'height': 844}), ('computador', {'width': 1280, 'height': 900})]:
        print('==', nome_vp)
        sfx = '1' if nome_vp == 'celular' else '2'
        D, RD, ID = dono('Dono ' + sfx, f'dono{sfx}@t.com', '10' + sfx, f'Barbearia Navalha {sfx}', vp)
        slug = RD.get(f'/api/v2/ads/{ID}/links').json()['base']['slug']
        pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        # ---------------- 1) Personalizar Agente de Atendimento ----------------
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(3000)
        if not pg.locator(f'[data-agente="{ID}"]').count():
            pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1000)
        pg.locator(f'[data-agente="{ID}"]').first.click(); pg.wait_for_selector('[data-agpz]', timeout=15000); pg.wait_for_timeout(600)
        sec = pg.locator('[data-agpz]')
        nomes = sec.locator('[data-agop]').evaluate_all('l=>l.map(e=>e.innerText.split("\\n")[0])')
        check(f'{nome_vp}: seção "Personalizar Agente de Atendimento" com as 6 opções e interruptores', 'personalizar agente de atendimento' in pg.inner_text('body').lower() and nomes == ['Agendar um horário', 'Ver nossos serviços', 'Localização', 'Horário de funcionamento', 'Pagamento e entrega', 'WhatsApp'] and sec.locator('[role=switch][aria-checked=true]').count() == 6, nomes)
        fr = pg.frame_locator('[data-agpz-frame]')
        def chips():
            pg.wait_for_timeout(300)
            try: fr.locator('#acts button,#acts a').first.wait_for(timeout=15000)
            except Exception: return []
            m = fr.locator('[data-a="mais"]')
            if m.count() and m.get_attribute('aria-expanded') == 'false': m.dispatch_event('click'); pg.wait_for_timeout(300)
            return [t.strip() for t in fr.locator('#acts button,#acts a').all_inner_texts() if t.strip() not in ('Ver mais', 'Ver menos')]
        c0 = chips()
        check(f'{nome_vp}: prévia real do atendimento mostra todos os botões', all(x in c0 for x in ['Agendar um horário', 'Ver nossos serviços', 'Localização', 'Horário de funcionamento', 'Pagamento e entrega', 'WhatsApp']), c0)
        sec.scroll_into_view_if_needed(); pg.screenshot(path=f'/tmp/e2e/pz_agente_{nome_vp}_antes.png', full_page=False)
        sec.locator('.glass').first.screenshot(path=f'/tmp/e2e/pz_agente_{nome_vp}_secao.png')
        for k in ['whatsapp', 'localizacao', 'agendar']:
            pg.click(f'[data-sw="agop_{k}"]'); pg.wait_for_timeout(700)
        salvo = RD.get(f'/api/v2/ads/{ID}/agent').json()['opcoes']
        check(f'{nome_vp}: salvo automaticamente no banco (sem botão Salvar)', salvo == {'agendar': False, 'servicos': True, 'localizacao': False, 'horario': True, 'pagamento': True, 'whatsapp': False}, salvo)
        pg.wait_for_timeout(1200); c1 = chips()
        check(f'{nome_vp}: prévia atualiza na hora (Agendar, Localização e WhatsApp somem)', c1 and not any(x in c1 for x in ['Agendar um horário', 'Localização', 'WhatsApp']) and 'Ver nossos serviços' in c1 and 'Pagamento e entrega' in c1, c1)
        pg.screenshot(path=f'/tmp/e2e/pz_agente_{nome_vp}_depois.png')
        # atendimento público (cliente sem login)
        V = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True); pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e)))
        pv.goto('/' + slug); pv.wait_for_selector('#acts button', timeout=15000); pv.wait_for_timeout(500)
        if pv.locator('[data-a="mais"]').count(): pv.click('[data-a="mais"]'); pv.wait_for_timeout(300)
        cp = [t.strip() for t in pv.locator('#acts button,#acts a').all_inner_texts()]
        check(f'{nome_vp}: página pública do agente respeita (sem Agendar, Localização e WhatsApp)', not any(x in cp for x in ['Agendar um horário', 'Localização', 'WhatsApp']) and 'Ver nossos serviços' in cp, cp)
        # recurso preservado: pergunta direta sobre o endereço continua respondida com o mapa
        pv.fill('#t', 'onde fica?')
        pv.keyboard.press('Enter'); pv.wait_for_timeout(2500)
        check(f'{nome_vp}: ocultar o botão não desativa o recurso (mapa responde se o cliente perguntar)', 'Rua das Flores' in pv.inner_text('body') and pv.locator('iframe[title="Mapa"]').count() >= 1, pv.inner_text('body')[-300:])
        V.close()
        # religa
        for k in ['whatsapp', 'localizacao', 'agendar']: pg.click(f'[data-sw="agop_{k}"]'); pg.wait_for_timeout(500)
        check(f'{nome_vp}: religar volta tudo', all(RD.get(f'/api/v2/ads/{ID}/agent').json()['opcoes'].values()))
        # ---------------- 2) Personalizar Página de Links ----------------
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(2500)
        if not pg.locator('[data-lt2="links"]').count(): pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1000)
        pg.locator('[data-lt2="links"]').click(); pg.wait_for_selector('[data-lk-pz]', timeout=15000); pg.wait_for_timeout(500)
        pz = pg.locator('[data-lk-pz]')
        check(f'{nome_vp}: seção "Personalizar Página de Links" com 5 interruptores, posição e tamanho do logotipo', 'personalizar página de links' in pg.inner_text('body').lower() and pz.locator('[role=switch]').count() == 5 and pz.locator('[data-lpos]').count() == 3 and pz.locator('#lk_tam').count() == 1)
        check(f'{nome_vp}: cada botão (inclusive Catálogo e Agente) tem interruptor próprio', pg.locator('[data-lk-lista] [data-bt]').count() == 2 and pg.locator('[data-lk-lista] [data-bt] [role=switch]').count() == 2)
        pz.scroll_into_view_if_needed(); pz.screenshot(path=f'/tmp/e2e/pz_links_{nome_vp}_secao.png')
        mob = vp['width'] < 900
        def ver_previa():
            if mob: pg.click('[data-lk-aba="previa"]')
            pg.wait_for_timeout(700)
        def editar():
            if mob: pg.click('[data-lk-aba="editar"]'); pg.wait_for_timeout(200)
        lf = pg.frame_locator('[data-lk-frame]')
        ver_previa()
        geo0 = lf.locator('.ma-emp-logo img').evaluate('e=>{const r=e.getBoundingClientRect(),w=document.querySelector(".ma-emp-hd").getBoundingClientRect();return {w:r.width,h:r.height,l:r.left-w.left,rr:w.right-r.right}}')
        check(f'{nome_vp}: prévia padrão = layout atual (logo 64px à esquerda, capa, título e descrição)', abs(geo0['w'] - 64) < 1 and geo0['l'] < geo0['rr'] and lf.locator('.ma-emp-capa').count() == 1 and lf.locator('h1').count() == 1, geo0)
        editar()
        pg.click('[data-lpos="centro"]'); pg.wait_for_timeout(200)
        pg.locator('#lk_tam').evaluate("e=>{e.value=104;e.dispatchEvent(new Event('input',{bubbles:true}))}")
        pg.click('[data-sw="lkx_descricao"]'); pg.wait_for_timeout(200); pg.click('[data-sw="lkx_capa"]'); pg.wait_for_timeout(200)
        pg.locator('[data-lk-lista] [data-bt]').first.locator('[role=switch]').click(); pg.wait_for_timeout(200)  # oculta só o Catálogo
        ver_previa()
        geo = lf.locator('.ma-emp-logo img').evaluate('e=>{const r=e.getBoundingClientRect(),w=document.querySelector(".ma-emp-hd").getBoundingClientRect();return {w:r.width,h:r.height,c:(r.left+r.right)/2-(w.left+w.right)/2,vw:innerWidth}}')
        esperado = min(104, geo['vw'] * 0.40)
        check(f'{nome_vp}: prévia antes de publicar — logo centralizado, tamanho {round(esperado)}px proporcional (quadrado), sem capa e sem descrição',
              abs(geo['w'] - esperado) < 1.5 and abs(geo['w'] - geo['h']) < 0.5 and abs(geo['c']) < 2 and lf.locator('.ma-emp-capa').count() == 0 and lf.locator('.ma-emp-sobre').count() == 0, geo)
        check(f'{nome_vp}: prévia sem o botão Catálogo (oculto um a um)', lf.locator('[data-tipo="catalogo"]').count() == 0)
        pg.screenshot(path=f'/tmp/e2e/pz_links_{nome_vp}_previa.png')
        check(f'{nome_vp}: nada publicado antes de "Publicar"', A.request.get(f'/api/v2/links/{slug}').status == 404)
        editar(); pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
        V = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, device_scale_factor=2); pv = V.new_page(); pv.on('pageerror', lambda e: errs.append(str(e)))
        pv.goto(f'/{slug}/links'); pv.wait_for_selector('.ma-emp-hd', timeout=15000); pv.wait_for_timeout(500)
        g2 = pv.locator('.ma-emp-logo img').evaluate('e=>{const r=e.getBoundingClientRect();return {w:r.width,h:r.height,c:(r.left+r.right)/2-innerWidth/2}}')
        check(f'{nome_vp}: página pública publicada igual à prévia (logo centralizado {round(g2["w"])}px, sem capa/descrição/Catálogo)', abs(g2['w'] - min(104, 390 * .4)) < 1.5 and abs(g2['c']) < 2 and pv.locator('.ma-emp-capa').count() == 0 and pv.locator('.ma-emp-sobre').count() == 0 and pv.locator('[data-tipo="catalogo"]').count() == 0 and pv.locator('h1').count() == 1, g2)
        check(f'{nome_vp}: sem rolagem horizontal na página pública', pv.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        pv.screenshot(path=f'/tmp/e2e/pz_links_{nome_vp}_publica.png')
        check(f'{nome_vp}: catálogo continua funcionando mesmo com o botão oculto', V.request.get(f'/x/empresa/{ID}').status == 200)
        # à direita, pequeno; ocultar todos os botões e o título
        editar(); pg.click('[data-lpos="direita"]'); pg.locator('#lk_tam').evaluate("e=>{e.value=48;e.dispatchEvent(new Event('input',{bubbles:true}))}")
        pg.click('[data-sw="lkx_botoes"]'); pg.wait_for_timeout(200); pg.click('[data-sw="lkx_titulo"]'); pg.wait_for_timeout(200); pg.click('[data-lk-pub]'); pg.wait_for_timeout(1500)
        pv.reload(); pv.wait_for_selector('.ma-emp-hd', timeout=15000); pv.wait_for_timeout(400)
        g3 = pv.locator('.ma-emp-logo img').evaluate('e=>{const r=e.getBoundingClientRect(),h=document.querySelector(".ma-emp-hd").getBoundingClientRect();return {w:r.width,dr:h.right-r.right,dl:r.left-h.left}}')
        check(f'{nome_vp}: logo à direita (48px), sem título e sem botões', abs(g3['w'] - 48) < 1 and g3['dr'] < g3['dl'] and pv.locator('h1').count() == 0 and pv.locator('a[data-bt]').count() == 0 and pv.locator('.vazio').count() == 0, g3)
        pv.screenshot(path=f'/tmp/e2e/pz_links_{nome_vp}_direita.png')
        rasc = RD.get(f'/api/v2/ads/{ID}/links').json()['rascunho']
        check(f'{nome_vp}: ocultar não apaga (botões, logo e descrição continuam salvos)', len(rasc['botoes']) == 2 and rasc['exibir']['botoes'] is False and rasc['logoPos'] == 'direita')
        V.close()
        # isolamento: outra empresa não altera
        if nome_vp == 'celular': OUTRO = (D, RD, ID)
        else:
            _, RO, IO = OUTRO
            check('outra empresa não altera o agente nem a página de links alheia', RO.put(f'/api/v2/ads/{ID}/agent/opcoes', data={'opcoes': {'whatsapp': False}}).status == 404 and RO.put(f'/api/v2/ads/{ID}/links', data={'conteudo': {'exibir': {'capa': False}}}).status == 404)
    errs = [e for e in errs if '#418' not in e and e != 'Event']
    check('sem erros de JavaScript (fora o aviso antigo de hidratação #418)', not errs, errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); import sys; sys.exit(0 if all(res) else 1)
