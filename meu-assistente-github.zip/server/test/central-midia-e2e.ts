// Teste de ponta a ponta: o cliente do Meu Assistente (src/lib/central-midia.ts) falando com a central REAL
// (services/central-midia, Python). Requer Python 3 com as dependências da central e Tesseract/Poppler instalados.
// Uso: npx tsx test/central-midia-e2e.ts
import { spawn } from 'node:child_process'
import { join } from 'node:path'
import { createServer } from 'node:net'

const porta: number = await new Promise((r) => { const s = createServer(); s.listen(0, '127.0.0.1', () => { const p = (s.address() as any).port; s.close(() => r(p)) }) })
const token = 'e2e-' + 'k'.repeat(30)
const dir = join(process.cwd(), '..', 'services', 'central-midia')
const proc = spawn('python3', ['-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', String(porta), '--log-level', 'warning'], { cwd: dir, env: { ...process.env, MIDIA_TOKEN: token, DIR_TEMP: '/tmp/central-e2e' }, stdio: 'ignore' })
let falhas = 0
const ok = (n: string, c: boolean, d = '') => { console.log((c ? '  ✔ ' : '  ✘ ') + n + (c ? '' : ' → ' + d)); if (!c) falhas++ }
try {
  process.env.MIDIA_URL = `http://127.0.0.1:${porta}`; process.env.MIDIA_TOKEN = token
  const C = await import('../src/lib/central-midia.js')
  for (let i = 0; i < 80; i++) { try { if ((await fetch(process.env.MIDIA_URL + '/saude')).ok) break } catch { /* subindo */ } await new Promise((r) => setTimeout(r, 200)) }
  ok('central no ar', await C.centralDisponivel())
  // PDF digital mínimo com texto de comprovante
  const linhas = ['Comprovante de transferencia', 'Pix enviado', 'Valor: R$ 152,30', 'Data: 14/11/2026 as 09:41']
  const st = Buffer.from('BT /F1 14 Tf 60 780 Td 18 TL ' + linhas.map((l) => `(${l}) Tj T*`).join(' ') + ' ET', 'latin1')
  const objs = ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>', '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>', `<< /Length ${st.length} >>\nstream\n${st.toString('latin1')}\nendstream`]
  let pdf = '%PDF-1.4\n'; const pos: number[] = []
  objs.forEach((o, i) => { pos.push(Buffer.byteLength(pdf, 'latin1')); pdf += `${i + 1} 0 obj\n${o}\nendobj\n` })
  const xref = Buffer.byteLength(pdf, 'latin1'); pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + pos.map((p) => String(p).padStart(10, '0') + ' 00000 n \n').join('') + `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`
  const r = await C.processarNaCentral(Buffer.from(pdf, 'latin1'), 'comprovante.pdf', 'application/pdf', { cliente: 'e2e' })
  ok('PDF processado pela central real', r.ok && r.arquivo.familia === 'pdf' && r.texto.includes('Pix enviado'), JSON.stringify(r).slice(0, 300))
  ok('comprovante extraído sem IA (nível 1)', r.ok && r.nivel === 1 && (r.comprovante as any)?.valor === 152.3 && (r.comprovante as any)?.data === '2026-11-14', JSON.stringify(r.ok && r.comprovante))
  const x = await C.processarNaCentral(Buffer.concat([Buffer.from('MZ'), Buffer.alloc(100)]), 'nota.pdf')
  ok('executável disfarçado recusado', !x.ok && x.codigo === 'executavel' && !x.indisponivel, JSON.stringify(x))
  proc.kill('SIGTERM'); await new Promise((r) => setTimeout(r, 800))
  const y = await C.processarNaCentral(Buffer.from('oi'), 'a.txt', 'text/plain', { tempoMs: 2000 })
  ok('central parada: cliente devolve "indisponível" sem quebrar', !y.ok && y.indisponivel, JSON.stringify(y))
} finally { proc.kill('SIGKILL') }
console.log(falhas ? `FIM FALHOU (${falhas})` : 'FIM OK'); process.exit(falhas ? 1 : 0)
