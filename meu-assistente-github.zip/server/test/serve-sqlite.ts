// Sobe o servidor completo com banco SQLite de teste e um dublê local da IA, para os testes no navegador.
import { createServer } from 'node:http'
import { join } from 'node:path'
const ai = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  const j = JSON.parse(body); const last = j.messages[j.messages.length - 1]
  const send = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  if (last.role === 'tool') return send({ role: 'assistant', content: 'Pronto, registrei para você.' })
  if (String(j.messages?.[0]?.content || '').startsWith('MODO: CONSULTOR DE MARKETING')) return send({ role: 'assistant', content: '**Diagnóstico**\nPontos fortes: catálogo completo e entrega no bairro.\nOportunidades: mostrar o forno a lenha e trazer de volta quem sumiu.\n\n**Plano de ação**\n1. Três posts por semana com a pizza mais pedida.\n2. Oferta com prazo para clientes autorizados.\n\n```campanha\n{"nome":"Volta dos clientes","titulo":"Sentimos sua falta!","mensagem":"Nesta semana, sua pizza favorita com borda recheada grátis. Toque para pedir.","publico":"todos"}\n```\n\nPróximo passo: revise a proposta e leve para a Central.' }) // Modos Inteligentes (teste de tela)
  for (const [k, n, a] of [['xqz-neg-resumo', 'negocio_resumo', { periodo: 'hoje' }], ['xqz-neg-comparar', 'negocio_comparar', { periodo: 'hoje' }], ['xqz-neg-analise', 'negocio_analise', { periodo: 'hoje' }]] as const) if (String(last.content).includes(k) && (j.tools || []).some((x: any) => x.function.name === n)) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: n, arguments: JSON.stringify(a) } }] })
  if (typeof last.content === 'string' && last.content.includes('IMPORTADOR-CARDAPIO')) return send({ role: 'assistant', content: JSON.stringify({ legivel: true, produtos: [{ nome: 'Pizza Calabresa', descricao: 'Molho, calabresa e cebola', preco: null, categoria: 'Pizzas', variacoes: [{ nome: 'Tamanho', opcoes: [{ nome: 'Média', preco: 45 }, { nome: 'Grande', preco: 56 }] }], confianca: 0.95, tipo: 'produto' }, { nome: 'Coca-Cola 2L', descricao: '', descricao_sugerida: 'Refrigerante gelado para acompanhar sua refeição.', preco: 12, categoria: 'Bebidas', confianca: 0.9, tipo: 'produto' }, { nome: 'X-Bacon', descricao: 'Pão, hambúrguer e bacon', preco: 28, categoria: 'Hambúrgueres', adicionais: [{ nome: 'Bacon extra', preco: 4 }], confianca: 0.9, tipo: 'produto' }, { nome: 'Brigadeiro', descricao: '', preco: null, categoria: 'Sobremesas', confianca: 0.4, duvida: 'preço borrado', tipo: 'produto' }, { nome: 'Caneca', descricao: '', preco: 32, categoria: 'Variados', confianca: 0.95, tipo: 'produto' }] }) })
  if (typeof last.content === 'string' && last.content.includes('xqz-n2-afirma')) return send({ role: 'assistant', content: 'Tudo certo por aqui. Uma resposta comum para avaliar.' })
  if (typeof last.content === 'string' && last.content.includes('xqz-cog-afirma')) return send({ role: 'assistant', content: 'Pronto! Agendei sua reunião para amanhã às 14h.' }) // a IA afirma uma ação que nenhuma ferramenta executou
  if (/gastei/i.test(last.content)) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'register_transaction', arguments: JSON.stringify({ kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' }) } }] })
  send({ role: 'assistant', content: 'Olá! Sou o Meu Assistente. Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
Object.assign(process.env, { AI_BASE_URL: process.env.E2E_AI_URL || `http://127.0.0.1:${(ai.address() as any).port}/v1`, AI_API_KEY: 'k', PUBLIC_URL: 'http://localhost:' + (process.env.PORT || 4300), STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public') })
const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const d = await createSqlite(process.env.SQLITE_FILE || '/tmp/ma-e2e.db'); setDb(d)
await migrate(d, config.migrationsDir)
await (await import('../src/routes/kb.js')).seedKb()
createApp().listen(Number(process.env.PORT || 4300), '127.0.0.1', () => console.log('e2e server up'))
