// Sobe o servidor completo com banco SQLite de teste e um dublê local da IA, para os testes no navegador.
import { createServer } from 'node:http'
import { join } from 'node:path'
const FALHOU = new Map<string, number>() // falha durante 8 s a partir da 1ª tentativa (as novas tentativas automáticas da IA também falham)
const ai = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  const j = JSON.parse(body); const last = j.messages[j.messages.length - 1]
  const send = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  // busca visual de produtos: a IA com visão responde pela "foto" de teste, identificada pelas dimensões do JPEG (o app reencoda a
  // imagem antes de enviar, então só o tamanho sobrevive): 300x201 = tênis Zuntra; 300x202 = luminária sem marca; 300x204 = garrafa Termix; outra = não é produto
  if (Array.isArray(last?.content)) { const t = String(last.content.find((x: any) => x.type === 'text')?.text || ''), im = last.content.find((x: any) => x.type === 'image_url')
    if (t.startsWith('BUSCA VISUAL DE PRODUTO') && im) { const buf = Buffer.from(String(im.image_url?.url || '').split(',')[1] || '', 'base64'); let w = 0, h = 0
      for (let i = 2; i < buf.length - 9; i++) if (buf[i] === 0xff && (buf[i + 1] === 0xc0 || buf[i + 1] === 0xc2)) { h = buf.readUInt16BE(i + 5); w = buf.readUInt16BE(i + 7); break }
      const J = (o: any) => send({ role: 'assistant', content: JSON.stringify(o) })
      if (w === 300 && h === 201) return J({ eProduto: true, produto: 'tênis de corrida', categoria: 'calçados', marca: 'Zuntra', modelo: 'Veloz 3', cor: 'azul', formato: '', caracteristicas: ['solado branco'], textos: ['ZUNTRA'], codigos: ['7891234567895'], consultas: ['Zuntra Veloz 3 tênis'], confianca: 0.9 })
      if (w === 300 && h === 204) return J({ eProduto: true, produto: 'garrafa térmica', categoria: 'utilidades', marca: 'Termix', modelo: 'Inox 1L', cor: 'prata', formato: '', caracteristicas: [], textos: ['TERMIX'], codigos: [], consultas: ['garrafa térmica Termix Inox 1L'], confianca: 0.8 })
      if (w === 300 && h === 202) return J({ eProduto: true, produto: 'luminária de mesa articulada', categoria: 'iluminação', marca: '', modelo: '', cor: 'preta', formato: '', caracteristicas: [], textos: [], codigos: [], consultas: ['luminária de mesa articulada preta'], confianca: 0.5 })
      return J({ eProduto: false, produto: '', categoria: '', marca: '', modelo: '', cor: '', formato: '', caracteristicas: [], textos: [], codigos: [], consultas: [], confianca: 0.1 }) } }
  // tradução interna (idioma.ts): texto marcado com o idioma, marcadores ⟦n⟧ preservados e rótulos traduzidos
  { const tm = typeof last?.content === 'string' && last.content.match(/^\[TRADUÇÃO INTERNA → (\w\w)\]/); if (tm) { const txt = (last.content.split('\nTEXTO:\n')[1] || '').split('\n\nRÓTULOS:\n')[0]; const rot = (last.content.split('\n\nRÓTULOS:\n')[1] || '').split('\n').filter((l: string) => /^\d+\|/.test(l)); return send({ role: 'assistant', content: JSON.stringify({ texto: `[${tm[1]}] ${txt}`, rotulos: rot.map((l: string) => l.replace(/^(\d+)\|/, `$1|[${tm[1]}] `)) }) }) } }
  // idioma da resposta pedido no prompt
  { const lm = String(j.messages?.[0]?.content || '').match(/IDIOMA DA RESPOSTA: [^(\n]*\((\w\w)\)/); const R: Record<string, string> = { en: 'Hello! How can I help you?', es: '¡Hola! ¿En qué puedo ayudarte?', fr: 'Bonjour ! Comment puis-je vous aider ?', it: 'Ciao! Come posso aiutarti?', de: 'Hallo! Wie kann ich helfen?', pt: 'Olá! Como posso ajudar?' }; if (lm && last.role === 'user') return send({ role: 'assistant', content: R[lm[1]] || R.pt }) }
  // tarefas em segundo plano: pedido demorado (xqz-tarefa-lenta = 7 s, xqz-tarefa-media = 4 s; sem números na frase: o motor financeiro leria como valor) e falha só na 1ª tentativa (xqz-tarefa-falha)
  if (typeof last?.content === 'string' && last.role === 'user' && /xqz-tarefa-(lenta|media)/.test(last.content)) { await new Promise((r) => setTimeout(r, /xqz-tarefa-media/.test(last.content) ? 4000 : 7000)); if (!res.writableEnded) send({ role: 'assistant', content: 'Resultado da pesquisa: encontrei 3 fornecedores de café em Fortaleza com entrega no mesmo dia.' }); return }
  if (typeof last?.content === 'string' && last.role === 'user' && /xqz-tarefa-falha/.test(last.content) && Date.now() - (FALHOU.get(last.content) ?? Date.now()) < 8000) { if (!FALHOU.has(last.content)) FALHOU.set(last.content, Date.now()); res.writeHead(500, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: { message: 'falha simulada' } })) }
  // indicador de atividade: pedido em várias etapas reais (pensa → ferramenta → organiza → responde), cada uma com ~1,5 s
  { const pedido = String([...j.messages].reverse().find((m: any) => m.role === 'user')?.content || ''), m = pedido.match(/xqz-etapas-(leitura|grava)/), espera = () => new Promise((r) => setTimeout(r, 1500))
    if (m && last.role === 'user') { await espera(); return send({ role: 'assistant', content: null, tool_calls: [{ id: 'e1', type: 'function', function: m[1] === 'leitura' ? { name: 'get_agenda', arguments: '{}' } : { name: 'create_task', arguments: JSON.stringify({ title: 'Revisar estoque da loja' }) } }] }) }
    if (m && last.role === 'tool') { await espera(); return send({ role: 'assistant', content: m[1] === 'leitura' ? 'Sua agenda de hoje está livre.' : 'Pronto, criei a tarefa "Revisar estoque da loja".' }) } }
  { // administrador conversacional: chama a ferramenta pedida (xqz-emp {json}) e responde SÓ com o que ela devolveu
    const ped = String([...j.messages].reverse().find((m: any) => m.role === 'user')?.content || ''), mm = ped.match(/xqz-emp (\{.*\})/)
    if (mm && last.role === 'user' && (j.tools || []).some((t: any) => t.function.name === 'empresa_alterar')) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'emp1', type: 'function', function: { name: 'empresa_alterar', arguments: mm[1] } }] })
    if (mm && last.role === 'tool') { const r = JSON.parse(String(last.content || '{}')); return send({ role: 'assistant', content: r.ok ? `Pronto! ${r.empresa}: ${r.alteracao} — ${r.antes} → ${r.depois}.` : r.precisaConfirmar ? `${r.resumo} Confirma?` : `Não alterei: ${r.error}` }) }
  }
  // lentidão (25/11): xqz-lento-N responde depois de N segundos (para o aviso amigável de lentidão e o tempo esgotado no navegador)
  { const lm = typeof last?.content === 'string' && last.role === 'user' ? last.content.match(/xqz-lento-(\d+)/) : null; if (lm) { await new Promise((r) => setTimeout(r, Number(lm[1]) * 1000)); if (!res.writableEnded) send({ role: 'assistant', content: 'Pronto: aqui está a resposta que demorou um pouco mais.' }); return } }
  if (last.role === 'tool') return send({ role: 'assistant', content: 'Pronto, registrei para você.' })
  if (String(j.messages?.[0]?.content || '').startsWith('MODO: CONSULTOR DE MARKETING')) { // dublê do consultor: responde com o que RECEBEU nos dados da empresa
    const sys = String(j.messages[0].content), um = String(last?.content || '')
    const cat = (sys.match(/CATÁLOGO: (\d+) item/) || [])[1], cli = (sys.match(/CLIENTES \(histórico de pedidos\): (\d+) cliente/) || [])[1], plano = (sys.match(/- "([^"]+)" \[(proposto|aprovado|em_andamento)\]/) || [])[1]
    if (/plano|estrat[eé]gia/i.test(um)) return send({ role: 'assistant', content: `**Objetivo:** Reativar clientes inativos\n**Oportunidade identificada:** quem já comprou e parou.\n**Dados que sustentam:** ${cli ? cli + ' cliente(s) com compras registradas' : 'histórico de pedidos'}.\n**Público-alvo sugerido:** quem não compra há mais de 60 dias.\n**Produtos ou serviços envolvidos:** a pizza mais pedida.\n**Estratégia de execução:** oferta com prazo pela Central.\n**Conteúdo e comunicação:** mensagem curta e pessoal.\n**Canais:** Central de Marketing e WhatsApp.\n**Custos estimados:** sem base para estimar.\n**Indicadores para acompanhar:** cliques da Central e pedidos.\n**Próximos passos:** levar a proposta para a Central.\n\n\`\`\`campanha\n{"nome":"Volta dos clientes","titulo":"Sentimos sua falta!","mensagem":"Nesta semana, sua pizza favorita com borda recheada grátis. Toque para pedir.","publico":"sem_compras"}\n\`\`\`\n\`\`\`memoria\n{"objetivo":"Reativar clientes inativos","plano":{"titulo":"Reativar clientes inativos","objetivo":"Trazer de volta quem parou de comprar","resumo":"Oferta com prazo pela Central","status":"proposto"}}\n\`\`\`` })
    return send({ role: 'assistant', content: `**O que os dados mostram:** ${cat ? cat + ' item(ns) ativos no catálogo' : 'catálogo sem itens'}${cli ? ' e ' + cli + ' cliente(s) com compras' : ''}.${plano ? `\n\nRetomando o plano "${plano}".` : ''}\n\n**Oportunidades:** mostrar o forno a lenha e trazer de volta quem sumiu.\n\nQuer que eu monte o plano de ação?` })
  }
  for (const [k, n, a] of [['xqz-neg-resumo', 'negocio_resumo', { periodo: 'hoje' }], ['xqz-neg-comparar', 'negocio_comparar', { periodo: 'hoje' }], ['xqz-neg-analise', 'negocio_analise', { periodo: 'hoje' }]] as const) if (String(last.content).includes(k) && (j.tools || []).some((x: any) => x.function.name === n)) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: n, arguments: JSON.stringify(a) } }] })
  if (typeof last.content === 'string' && last.content.includes('IMPORTADOR-CARDAPIO')) return send({ role: 'assistant', content: JSON.stringify({ legivel: true, produtos: [{ nome: 'Pizza Calabresa', descricao: 'Molho, calabresa e cebola', preco: null, categoria: 'Pizzas', variacoes: [{ nome: 'Tamanho', opcoes: [{ nome: 'Média', preco: 45 }, { nome: 'Grande', preco: 56 }] }], confianca: 0.95, tipo: 'produto' }, { nome: 'Coca-Cola 2L', descricao: '', descricao_sugerida: 'Refrigerante gelado para acompanhar sua refeição.', preco: 12, categoria: 'Bebidas', confianca: 0.9, tipo: 'produto' }, { nome: 'X-Bacon', descricao: 'Pão, hambúrguer e bacon', preco: 28, categoria: 'Hambúrgueres', adicionais: [{ nome: 'Bacon extra', preco: 4 }], confianca: 0.9, tipo: 'produto' }, { nome: 'Brigadeiro', descricao: '', preco: null, categoria: 'Sobremesas', confianca: 0.4, duvida: 'preço borrado', tipo: 'produto' }, { nome: 'Caneca', descricao: '', preco: 32, categoria: 'Variados', confianca: 0.95, tipo: 'produto' }] }) })
  if (typeof last.content === 'string' && last.content.includes('xqz-n2-afirma')) return send({ role: 'assistant', content: 'Tudo certo por aqui. Uma resposta comum para avaliar.' })
  if (typeof last.content === 'string' && last.content.includes('xqz-cog-afirma')) return send({ role: 'assistant', content: 'Pronto! Agendei sua reunião para amanhã às 14h.' }) // a IA afirma uma ação que nenhuma ferramenta executou
  if (/gastei/i.test(last.content)) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'register_transaction', arguments: JSON.stringify({ kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' }) } }] })
  send({ role: 'assistant', content: 'Olá! Sou o Meu Assistente. Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
Object.assign(process.env, { AI_BASE_URL: process.env.E2E_AI_URL || `http://127.0.0.1:${(ai.address() as any).port}/v1`, AI_API_KEY: 'k', PUBLIC_URL: 'http://localhost:' + (process.env.PORT || 4300), STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public') })
const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const d = await createSqlite(process.env.SQLITE_FILE || '/tmp/ma-e2e.db'); setDb(d)
await migrate(d, config.migrationsDir)
await (await import('../src/routes/kb.js')).seedKb()
createApp().listen(Number(process.env.PORT || 4300), '127.0.0.1', () => console.log('e2e server up'))
