// PESQUISA NA INTERNET DESLIGADA PELO ADMINISTRADOR — comportamento do chat (app real, rotas reais; dublês de IA e de web).
//   A. ligada: pergunta externa pesquisa normalmente (linha de base)
//   B. desligada: "Quem foi Bob Marley?", cotação, "pesquise…" → resposta natural que conduz para o que o chat faz, sem IA,
//      sem busca, sem imagem, sem "Não consegui concluir", sem mencionar internet/bloqueio/administrador; frases variadas
//   C. funções internas seguem: compromisso (criar, editar, consultar), gasto, lembrete, tarefa, nota; perguntas sobre o app
//      e conversa comum continuam com a IA
//   D. contexto preservado: no meio de um compromisso ou de um gasto, a resposta continua aquele assunto
//   E. Cérebro Central/conhecimento aprovado continua respondendo
//   F. IA fora do ar + internet desligada: nunca "Não consegui concluir…"
//   G. nenhuma chamada externa em nenhum fluxo (chat, modo ⚡, agente da empresa, rotas do Cérebro); religar volta ao normal
// Uso: npm run test:sem-internet
process.env.SONDA_FERRAMENTAS = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, J } = await import('../src/db/index.js')
let ok = 0, falhas = 0; const erros: string[] = []
function check(c: unknown, m: string, d?: unknown) { if (c) { ok++; console.log('  ✓', m) } else { falhas++; erros.push(m); console.log('  ✗', m, d === undefined ? '' : '→ ' + JSON.stringify(d).slice(0, 400)) } }
// toda saída de rede do processo: só os dublês locais podem ser chamados
const externos: string[] = []; const f0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any) => { const s = String(u?.url || u); if (!/^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(s)) externos.push(s); return f0(u, o) }) as any
const PROIBIDO = /internet|pesquis|desativad|desligad|administrador|bloque|configura|n[aã]o consegui concluir|tente novamente/i
async function diga(c: InstanceType<typeof S.Cli>, conv: string, t: string) {
  const b0 = S.buscas.length, l0 = S.lidas.length, i0 = S.chamadasIA.length
  const r = await c.call('POST', '/api/chat', { text: t, conversationId: conv })
  const txt = String(r.body?.assistantMessage?.content ?? '').replace(/⟦[^⟧]*⟧/g, '').trim()
  console.log(`    👤 ${t}\n    🤖 ${txt.replace(/\n+/g, ' ⏎ ').slice(0, 200)}`)
  return { txt, raw: JSON.stringify(r.body?.assistantMessage ?? {}), status: r.status, buscas: S.buscas.slice(b0), lidas: S.lidas.slice(l0), ia: S.chamadasIA.length - i0 }
}
const itens = async (email: string, tipo: string) => ((await q(`SELECT data FROM items WHERE user_id = (SELECT id FROM users WHERE email = $1) AND type = $2`, [email, tipo])) as any[]).map((r) => J<any>(r.data, {}))
const u = await S.novoUsuario(), email = 'p1@sonda.com'

console.log('\n== A. pesquisa ligada (linha de base)')
let t = await diga(u, crypto.randomUUID(), 'pesquise na internet sobre a cooperativa tarvok')
check(t.buscas.length > 0, 'ligada: o pedido de pesquisa pesquisa', t.buscas)

console.log('\n== B. pesquisa desligada: perguntas que dependem de fora')
check((await S.admin.call('PUT', '/api/panel/pesquisa_internet', { ativo: false })).status === 200, 'administrador desliga a pesquisa na internet')
const respostas: string[] = []
for (const p of ['Quem foi Bob Marley?', 'qual a cotação do dólar hoje?', 'pesquise sobre a história do reggae', 'quais as notícias de hoje?', 'quem descobriu o Brasil?', 'me fala sobre o protocolo zyntra']) {
  t = await diga(u, crypto.randomUUID(), p); respostas.push(t.txt)
  check(t.status === 200 && t.txt.length > 20 && !PROIBIDO.test(t.txt), `"${p}": resposta natural, sem falha nem aviso técnico/de bloqueio`, t.txt)
  check(t.buscas.length === 0 && t.lidas.length === 0 && !/⟦img/.test(t.raw) && !/"imagens"/.test(t.raw), `"${p}": nenhuma busca, leitura de página ou imagem`, { b: t.buscas, l: t.lidas })
  check(t.ia === 0, `"${p}": resolvida na hora, sem chamar a IA`, t.ia)
  check(/compromisso|agenda|lembrete|tarefa|nota|gasto|finan/i.test(t.txt), `"${p}": conduz para o que o chat faz`, t.txt)
}
check(new Set(respostas).size >= 3, `respostas variadas (${new Set(respostas).size} diferentes em ${respostas.length})`, respostas)
{ const c = crypto.randomUUID(); const a = await diga(u, c, 'Quem foi Bob Marley?'), b = await diga(u, c, 'e quem foi Bob Marley mesmo?')
  check(a.txt !== b.txt, 'na mesma conversa, não repete a frase anterior', [a.txt, b.txt]) }

t = await diga(u, crypto.randomUUID(), 'me fala sobre a cooperativa tarvok')
check(/Tarvok/i.test(t.txt) && t.buscas.length === 0, 'o que o Cérebro já aprendeu continua sendo respondido (conhecimento interno, sem nova busca)', t.txt)

console.log('\n== C. funções internas continuam')
const cv = crypto.randomUUID()
t = await diga(u, cv, 'marca dentista amanhã às 15h')
const ap = await itens(email, 'appointment')
check(ap.some((x) => /dentista/i.test(x.title || '')) && t.buscas.length === 0, 'compromisso criado normalmente', ap.map((x) => x.title))
t = await diga(u, cv, 'muda para as 16h')
check((await itens(email, 'appointment')).some((x) => /dentista/i.test(x.title || '') && /16:00/.test(String(x.time || x.startsAt || x.start || JSON.stringify(x)))), 'compromisso editado pela continuidade (16h)', await itens(email, 'appointment'))
t = await diga(u, cv, 'o que eu tenho amanhã?')
check((/dentista/i.test(t.raw) || /1 compromisso/.test(t.txt)) && t.buscas.length === 0, 'consulta da agenda responde com os dados reais', t.txt)
t = await diga(u, crypto.randomUUID(), 'gastei 45 reais no mercado')
check((await itens(email, 'expense')).some((x) => Number(x.amount) === 45), 'gasto registrado normalmente')
t = await diga(u, crypto.randomUUID(), 'me lembra de pagar a luz amanhã às 9h')
check((await itens(email, 'reminder')).length >= 1 || /lembr/i.test(t.txt), 'lembrete criado', t.txt)
t = await diga(u, crypto.randomUUID(), 'tarefa comprar ração')
check((await itens(email, 'task')).some((x) => /ra[cç][aã]o/i.test(x.title || '')), 'tarefa criada')
t = await diga(u, crypto.randomUUID(), 'como eu crio um lembrete?')
check(/lembrete/i.test(t.txt) && /Toque|menu|escrever/i.test(t.txt) && t.buscas.length === 0, 'pergunta sobre o próprio app é respondida (passo a passo, sem pesquisa)', t)
t = await diga(u, crypto.randomUUID(), 'oi, tudo bem?')
check(t.ia > 0 && t.buscas.length === 0, 'conversa comum segue com a IA', t)

console.log('\n== D. contexto preservado')
{ const c = crypto.randomUUID(); await diga(u, c, 'marca reunião com o contador sexta às 10h'); t = await diga(u, c, 'quem foi Bob Marley?')
  check(/compromisso|agenda|hor[aá]rio|remarcar/i.test(t.txt) && !PROIBIDO.test(t.txt), 'no meio de um compromisso: continua o assunto do compromisso', t.txt)
  t = await diga(u, c, 'muda para as 11h')
  check((await itens(email, 'appointment')).some((x) => /reuni/i.test(x.title || '') && /11:00/.test(JSON.stringify(x))), 'e o fluxo do compromisso segue normalmente depois', (await itens(email, 'appointment')).map((x) => [x.title, x.time])) }
{ const c = crypto.randomUUID(); await diga(u, c, 'gastei 30 reais de uber'); t = await diga(u, c, 'qual a cotação do euro?')
  check(/finan|gasto|despesa|lan[cç]amento|saldo/i.test(t.txt), 'no meio de um gasto: continua o assunto das finanças', t.txt) }

console.log('\n== E. Cérebro Central continua respondendo')
const kb = await S.admin.call('POST', '/api/panel/brain/knowledge', { action: 'add', titulo: 'Horário da biblioteca Velmora', conteudo: 'A biblioteca Velmora abre de segunda a sexta das 8h às 18h.', tipo: 'conhecimento', natureza: 'consulta', escopo: 'chat', status: 'aprovado' })
t = await diga(u, crypto.randomUUID(), 'qual o horário da biblioteca Velmora?')
check(/8h|18h|segunda/i.test(t.txt) && t.buscas.length === 0, 'conhecimento aprovado responde normalmente', { kb: kb.status, t: t.txt })

console.log('\n== F. IA fora do ar + internet desligada')
S.falhaIA.ativa = true
t = await diga(u, crypto.randomUUID(), 'me explica o que foi a revolução industrial')
check(!PROIBIDO.test(t.txt) && t.txt.length > 20, 'pergunta externa: nunca "Não consegui concluir…"', t.txt)
t = await diga(u, crypto.randomUUID(), 'me conta uma curiosidade')
check(!/n[aã]o consegui concluir/i.test(t.txt) && t.txt.length > 10, 'conversa com a IA fora do ar: resposta conduzida, sem a mensagem de falha', t.txt)
S.falhaIA.ativa = false

console.log('\n== G. nenhuma chamada externa; religar volta ao normal')
const BP = await import('../src/ai/bloqueio-pesquisa.js'), web = await import('../src/ai/cerebro/web.js')
let barrou = false; try { await (web as any).buscar?.('bob marley', { motivo: 'teste' }) } catch (e: any) { barrou = /pesquisa/i.test(String(e?.message)) || e?.code === 'pesquisa_bloqueada' }
check(BP.internetDesligada() && (barrou || !(web as any).buscar), 'camada de busca do Cérebro recusa fora do chat (agendador, painel)')
check(!(await u.call('GET', '/api/v2/modos')).body?.modos?.some?.((m: any) => m.id === 'pesquisa'), 'o modo Pesquisa some do ⚡')
check(externos.length === 0, 'nenhuma requisição a servidores externos em todo o teste', externos.slice(0, 5))
await S.admin.call('PUT', '/api/panel/pesquisa_internet', { ativo: true })
t = await diga(u, crypto.randomUUID(), 'pesquise na internet sobre o jaguar')
check(t.buscas.length > 0, 'religada: volta a pesquisar', t.buscas)

await S.fechar()
console.log(`\nResultado: ${ok}/${ok + falhas} verificações aprovadas.${falhas ? '\nFalhas:\n - ' + erros.join('\n - ') : ''}`)
process.exit(falhas ? 1 : 0)
