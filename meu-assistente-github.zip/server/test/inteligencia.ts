// TESTES DE INTELIGÊNCIA DO CHAT — asserções sobre conversas sequenciais pelo FLUXO REAL (POST /api/chat).
// Usa a sonda (dublê de IA que só repete o contexto recebido + dublê de internet com homônimos, resultado
// irrelevante, fontes contraditórias e busca que precisa ser refeita).
// Uso: npm run test:inteligencia
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const CMP = await import('../src/ai/compreensao.js')

let ok = 0, falhas = 0
const checar = (nome: string, cond: unknown, detalhe = '') => { if (cond) { ok++; console.log(`  ✔ ${nome}`) } else { falhas++; console.log(`  ✘ ${nome}${detalhe ? ' → ' + detalhe : ''}`) } }
const limpa = (s: string) => s.replace(/⟦[^⟧]*⟧/g, '')
const conhecimentos = (t: any) => (t.ia?.system.match(/\[C\d\] [^\n—]*/g) || []).join(' | ')

console.log('\n## Normalização (sem a sonda)')
const N = (s: string) => CMP.normalizar(s).texto
checar('abreviações: "qnto gastei hj" → "quanto gastei hoje"', N('qnto gastei hj') === 'quanto gastei hoje', N('qnto gastei hj'))
checar('erro de digitação em comando: "lenbra" → "lembra"', /^lembra /.test(N('lenbra de pagar a luz')))
checar('não troca palavras parecidas ("marcar", "gatos", "Quando")', N('marcar consulta para os gatos') === 'marcar consulta para os gatos' && N('Quando foi?') === 'Quando foi?')
checar('não mexe em nomes próprios', N('O Jaguar Pace e a Lenbra Ltda') === 'O Jaguar Pace e a Lenbra Ltda')
checar('não mexe em código, links e e-mails', ['const q = n => n+1', 'veja https://x.com/q?n=1', 'mande p/ vc@ex.com'].every((s) => N(s) === s))
checar('não mexe em códigos com hífen/parênteses', N('xqz-n2 dobrar(n)') === 'xqz-n2 dobrar(n)')

console.log('\n## Resolução de contexto (sem a sonda)')
const H = (...p: string[]) => p.map((content, i) => ({ role: i % 2 ? 'assistant' : 'user', content }))
const r1 = CMP.resolver('e quem criou?', H('O que é o Protocolo Zyntra?', 'É um protocolo hospitalar.'))
checar('continuação curta herda o assunto', /Zyntra/.test(r1.pergunta) && r1.seguimento, JSON.stringify(r1.pergunta))
const r2 = CMP.resolver('o jaguar é bom?', H('Estou pensando em comprar um carro para a família', 'Legal!'))
checar('domínio da conversa (carro) e pedido de avaliação', r2.dominio === 'veiculo' && r2.avaliacao && /carro/.test(r2.consulta || ''), JSON.stringify(r2))
const r3 = CMP.resolver('e ontem?', H('qnto gastei hj?', 'Saídas R$ 30,00'))
checar('continuação temporal troca só o período', /ontem/.test(r3.textoMotores) && /gastei/.test(r3.textoMotores), r3.textoMotores)
const r4 = CMP.resolver('e ontem?', H('gastei 30 no uber', 'Gasto registrado'))
checar('continuação temporal não repete um lançamento', !/gastei 30/.test(r4.textoMotores), r4.textoMotores)
const r5 = CMP.resolver('qual a capital da frança?', H('agenda uma reuniao com o joao', 'Para que dia?'))
checar('pergunta com assunto próprio não herda o anterior', !r5.seguimento && !/joao/i.test(r5.pergunta))

console.log('\n## Conversas pelo fluxo real do chat')
const P = await S.novoUsuario()

let t = await S.conversa(P, ['O que é o Protocolo Zyntra?', 'e quem criou?', 'em que ano?'], '', false)
checar('1. pesquisa um assunto desconhecido e responde com a fonte', t[0].buscas.length === 1 && /Helena Vasconcelos/.test(t[0].resposta))
checar('1. "e quem criou?" usa o conhecimento do Zyntra, sem nova busca', /Zyntra/.test(conhecimentos(t[1])) && t[1].buscas.length === 0)
checar('1. "em que ano?" mantém o assunto e envia o histórico à IA', /Zyntra/.test(conhecimentos(t[2])) && (t[2].ia?.mensagens.length || 0) >= 5)

t = await S.conversa(P, ['Estou pensando em comprar um carro para a família', 'o jaguar é bom?'], '', false)
checar('2. "o jaguar é bom?" com contexto de carro busca o carro', t[1].buscas.some((b) => /jaguar carro/i.test(b)), JSON.stringify(t[1].buscas))
checar('2. responde só sobre o carro (sem a onça)', /F-Pace/.test(t[1].resposta) && !/felino|onça/i.test(t[1].resposta))

t = await S.conversa(P, ['O que é jaguar?', 'o animal'], '', false)
checar('3. nome ambíguo sem contexto → pergunta qual sentido, sem chamar a IA', /mais de uma coisa/.test(t[0].resposta) && !t[0].ia)
checar('3. "o animal" responde sobre a onça', /onça/i.test(t[1].resposta) && !/F-Pace/.test(t[1].resposta))

t = await S.conversa(P, ['O que é a Norma Velnor?'], '', false)
checar('4. ignora o primeiro resultado irrelevante', /alergênicos/.test(t[0].resposta) && t[0].lidas.every((l) => /velnor\/norma/.test(l)), t[0].lidas.join(' '))

t = await S.conversa(P, ['Quais os sintomas da doença de Quarvel em gatos e como tratar?'], '', false)
checar('5. refaz a busca com uma consulta mais curta', t[0].buscas.length >= 2 && /gengivas/.test(t[0].resposta), JSON.stringify(t[0].buscas))

t = await S.conversa(P, ['Quando foi fundada a Cooperativa Tarvok?'], '', false)
checar('6. avisa que as fontes divergem (1998 × 2004)', /divergem/i.test(t[0].resposta) && /1998/.test(t[0].resposta) && /2004/.test(t[0].resposta))
checar('6. o conhecimento recebe um título limpo', /\[C1\] Cooperativa Tarvok/.test(conhecimentos(t[0])), conhecimentos(t[0]))

t = await S.conversa(P, ['marca dentista', 'amanha', 'as 3 da tarde'], '', false)
checar('7. agendamento em partes com respostas curtas', /Dentista/.test(t[2].resposta) && /15:00/.test(t[2].resposta), t[2].resposta)

t = await S.conversa(P, ['agenda uma reuniao com o joao', 'qual a capital da frança?', 'quinta as 10h'], '', false)
checar('8. responde a outra pergunta no meio e retoma o agendamento', /Paris/.test(t[1].resposta) && /Reunião/.test(t[2].resposta) && /10:00/.test(t[2].resposta), t[2].resposta)

t = await S.conversa(P, ['gastei 30 conto no uber', 'qnto gastei hj?', 'e ontem?'], '', false)
checar('9. gíria registrada como gasto', /R\$\s*30,00/.test(t[0].resposta), t[0].resposta)
checar('9. "qnto gastei hj?" resume o dia', /hoje/.test(t[1].resposta) && /30,00/.test(t[1].resposta), t[1].resposta)
checar('9. "e ontem?" resume ontem, sem registrar outro gasto', /ontem/.test(t[2].resposta) && !/registrado/i.test(t[2].resposta), t[2].resposta)

t = await S.conversa(P, ['lenbra de pagar a luz amanha as 9'], '', false)
checar('10. lembrete com erro de digitação é criado', /lembrar de pagar a luz/.test(t[0].resposta) && /09:00/.test(t[0].resposta), t[0].resposta)

t = await S.conversa(P, ['O que é o Protocolo Zyntra?', 'O que é o Protocolo Zyntra?'], '', false)
checar('11. pergunta repetida não pesquisa de novo', t.every((x) => x.buscas.length === 0))

t = await S.conversa(P, ['O que é o Protocolo Zyntra?', 'não, na verdade ele foi criado em 2012'], '', false)
checar('12. correção do usuário é anotada', /correção/i.test(t[1].resposta), limpa(t[1].resposta))
t = await S.conversa(P, ['Quem criou o Protocolo Zyntra?'], '', false)
checar('13. em outra conversa, a IA recebe a ressalva da correção', /RESSALVA — um usuário corrigiu/.test(t[0].ia?.system || ''))
checar('13. "quem criou X" não vira pergunta sobre quem criou o assistente', /Helena/.test(t[0].resposta))

t = await S.conversa(P, ['O que é o método Plimbex de estudo?'], '', false)
checar('14. sem fonte, não inventa', /não tenho essa informação/i.test(t[0].resposta))
const ind = (await S.admin.call('GET', '/api/brain/chat/indicadores?dias=1')).body
checar('14. a lacuna aparece no painel do Cérebro', (ind.lacunas || []).some((x: any) => /Plimbex/.test(x.pergunta)))
checar('3. a pergunta ambígua é contada no painel', ind.perguntasAmbiguas >= 1)

await S.fechar()
console.log(`\nResultado: ${ok}/${ok + falhas} verificações aprovadas.`)
process.exit(falhas ? 1 : 0)
