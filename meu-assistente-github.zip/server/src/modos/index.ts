// Central de Modos Inteligentes: registro dos modos, estado por conversa e o motor que o chat consulta antes dos demais.
// Para criar um modo novo: implemente a interface Modo (tipos.ts) num arquivo próprio e acrescente-o em MODOS. Só entram
// aqui modos com capacidade real implementada; nada é exibido como disponível sem existir.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import type { ChatMsg } from '../ai/types.js'
import type { Modo, EstadoModo, Resposta } from './tipos.js'
import { consultorMarketing } from './marketing.js'

export const MODOS: Modo[] = [consultorMarketing]
export const modoPorId = (id: string) => MODOS.find((m) => m.id === id) || null
/** Chave geral do painel (Motor do chat → Modos inteligentes). Desligada: o botão ⚡ some e o chat ignora qualquer modo. */
export async function modosLigados() { const { getConfig } = await import('../lib/settings.js'); return (await getConfig<any>('modos_chat', {})).ativo !== false }
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()

export async function estadoDe(conversationId: string, userId: number): Promise<{ modo: string; estado: EstadoModo } | null> {
  if (!conversationId) return null
  const r = await one('SELECT modo, estado FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2', [conversationId, userId])
  return r ? { modo: String(r.modo), estado: J<EstadoModo>(r.estado, { etapa: 'objetivo' }) } : null
}
async function salvar(conversationId: string, userId: number, modo: string, estado: EstadoModo) {
  const ex = await one('SELECT user_id FROM conversa_modos WHERE conversation_id = $1', [conversationId])
  if (ex && Number(ex.user_id) !== userId) return // conversa de outra pessoa: nunca grava
  if (ex) await q('UPDATE conversa_modos SET modo = $1, estado = $2, atualizado_em = $3 WHERE conversation_id = $4 AND user_id = $5', [modo, JSON.stringify(estado), nowIso(), conversationId, userId])
  else await q('INSERT INTO conversa_modos (conversation_id, user_id, modo, estado, atualizado_em) VALUES ($1,$2,$3,$4,$5)', [conversationId, userId, modo, JSON.stringify(estado), nowIso()])
}
export async function desativar(conversationId: string, userId: number) { await q('DELETE FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2', [conversationId, userId]) }

/** Lista para o seletor: o que existe e se está liberado para este usuário (calculado no servidor). */
export async function listar(u: SessionUser, conversationId = '') {
  if (!(await modosLigados())) return { habilitado: false, modos: [], ativo: null }
  const est = await estadoDe(conversationId, u.id)
  const modos = []
  for (const m of MODOS) { const a = await m.acesso(u); modos.push({ id: m.id, nome: m.nome, descricao: m.descricao, icone: m.icone, exclusivo: m.exclusivo || null, liberado: a.liberado, codigo: a.codigo, mensagem: a.liberado ? null : a.mensagem, acao: a.liberado ? null : a.acao || null }) }
  return { habilitado: true, modos, ativo: est && modoPorId(est.modo) ? est.modo : null }
}
const bloqueio = (m: Modo, msg: string, acao?: { rotulo: string; link: string }): Resposta => ({ content: `🔒 **${m.nome}**\n\n${msg}${acao ? ` ⟦btn:${acao.link}|${acao.rotulo}⟧` : ''}`, cards: [] })
const SAIR = /^(sair do modo|sair do consultor|voltar (ao|para o) chat (normal|comum)|desativar (o )?modo|modo normal|chat normal)\b/

/**
 * Chamado pelo chat antes dos motores comuns. Devolve a resposta do modo ou null (segue o chat tradicional).
 * body.modo: string com o id para ativar/manter, '' para voltar ao chat normal; ausente = usa o modo salvo da conversa.
 */
export async function processar(u: SessionUser, conversationId: string, texto: string, historico: ChatMsg[], body: any): Promise<(Resposta & { modo: string }) | null> {
  if (!conversationId) return null
  if (!(await modosLigados())) { if (await estadoDe(conversationId, u.id)) await desativar(conversationId, u.id); return null } // desligado no painel: chat normal
  const pedido = typeof body?.modo === 'string' ? body.modo.trim() : undefined
  let atual = await estadoDe(conversationId, u.id)
  if (pedido === '') { if (atual) await desativar(conversationId, u.id); return null }
  if (atual && SAIR.test(nrm(texto))) { await desativar(conversationId, u.id); const m = modoPorId(atual.modo); return { content: `Pronto, saí do modo ${m?.nome || ''} e voltei ao chat normal. Seu planejamento fica guardado para quando você voltar.`, cards: [], modo: '' } }
  let ativando = false
  if (pedido && (!atual || atual.modo !== pedido)) { if (!modoPorId(pedido)) return null; ativando = true; atual = { modo: pedido, estado: { etapa: 'objetivo' } } }
  if (!atual) return null
  const m = modoPorId(atual.modo); if (!m) { await desativar(conversationId, u.id); return null }
  // regras de acesso conferidas a cada mensagem (contratação pode vencer, ser suspensa ou mudar de plano a qualquer momento)
  const acesso = await m.acesso(u)
  if (!acesso.liberado) { if (!ativando) await desativar(conversationId, u.id); return { ...bloqueio(m, acesso.mensagem, acesso.acao), modo: '' } }
  const ctx = { u, conversationId, texto, historico, estado: atual.estado, acesso }
  const r = ativando && /^⚡/.test(texto.trim()) ? await m.iniciar(ctx) : await m.responder(ctx)
  await salvar(conversationId, u.id, m.id, r.estado)
  return { ...r.resposta, modo: m.id }
}
