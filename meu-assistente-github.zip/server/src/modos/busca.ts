// Modo Busca de Produtos e Serviços: liga sozinho quando a mensagem pede claramente para procurar/comprar algo ("quero
// encontrar…", "onde comprar…", "procuro…", "quem vende…") ou pelo botão ⚡. Pesquisa os produtos e serviços REAIS das lojas no ar
// (mesmas regras da vitrine), tolera erro de digitação, plural, sinônimos e descrições, e responde com cards compactos
// (⟦bp:…⟧: imagem, nome, preço, empresa, distância, disponibilidade e botões), sempre com dados atuais lidos na hora de mostrar.
// Enquanto ativo, entende refinamentos ("mais barato", "até 50 reais", "e de chocolate?", "mais opções"); qualquer outro
// assunto (lembrete, agenda, gasto, conversa) devolve a mensagem ao chat comum e o modo se desliga.
import { ehPedidoDeExplicacao } from '../ai/guia.js'
import type { Modo, ContextoExec, EstadoModo, Resposta } from './tipos.js'
import { intencaoBusca, lerConsulta, buscar, norm } from '../lib/busca-itens.js'

const POR_PAGINA = 6
const brl = (v: number) => 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',')
const fotoUrl = (id: number, src: string | null) => { const v = String(src || ''); return /^data:image\//.test(v) ? `/api/v2/vitrine/imagem/item/${id}` : /^https?:\/\//.test(v) ? v : null }
/** Cards do chat (⟦bp:p12,s33⟧): lidos AGORA dos catálogos (preço, oferta, estoque, loja aberta), na ordem pedida; o que saiu do ar some. */
export async function cards(userId: number, idsTxt: string) {
  const pedidos = String(idsTxt || '').split(',').map((x) => x.trim()).filter((x) => /^[ps]\d{1,9}$/.test(x)).slice(0, 24)
  if (!pedidos.length) return []
  const B = await import('../routes/businesses.js'), loc = await B.userLocation(userId).catch(() => null)
  const lista = await B.itensPublicos(loc, { ids: pedidos.map((x) => Number(x.slice(1))) }), por = new Map(lista.map((x) => [(x.tipo === 'servico' ? 's' : 'p') + x.id, x]))
  return pedidos.map((k) => por.get(k)).filter(Boolean).map((x: any) => {
    const serv = x.tipo === 'servico'
    const disp = serv ? (x.empresa.aberto ? 'Agenda aberta' : 'Agende pelo app') : !x.disponivel ? 'Esgotado' : x.restantes ? (x.restantes === 1 ? 'Última unidade' : `Últimas ${x.restantes} unidades`) : 'Disponível'
    return { id: x.id, tipo: x.tipo, nome: x.nome, foto: fotoUrl(x.id, x.foto), preco: x.preco, precoNormal: x.precoNormal, emOferta: x.emOferta, desconto: x.desconto, aPartirDe: x.aPartirDe, modoPreco: x.modoPreco, duracao: x.duracao,
      disponivel: x.disponivel, disponibilidade: disp, empresa: { id: x.empresa.id, nome: x.empresa.nome, distancia: x.empresa.distancia, atende: x.empresa.atende, aberto: x.empresa.aberto },
      link: `/x/empresa/${x.empresa.id}?${serv ? 'servico' : 'produto'}=${x.id}`, catalogo: `/x/empresa/${x.empresa.id}` }
  })
}
const NOMES_ORDEM: Record<string, string> = { menor: ', do menor preço', perto: ', dos mais perto' }

interface Consulta { termos: string[]; maxPreco: number | null; ordem: 'relevancia' | 'menor' | 'perto'; ofertas: boolean; tipo: 'produto' | 'servico' | null; pagina: number; texto: string }
/** Refinamentos de uma busca já feita (sem termos novos). */
function refinamento(texto: string): Partial<Consulta> | null {
  const s = norm(texto), r: Partial<Consulta> = {}
  if (/^(mais|outr\w*|ver mais|mostrar mais|mostra mais|tem mais|mais opco\w*|mais resultado\w*|proxim\w* pagina|continua\w*)( opco\w*| resultado\w*| itens| produtos| servicos)?\??$/.test(s)) r.pagina = 1 // +1 página
  const c = lerConsulta(texto)
  if (c.maxPreco != null) r.maxPreco = c.maxPreco
  if (c.ordem !== 'relevancia') r.ordem = c.ordem
  if (c.ofertas) r.ofertas = true
  if (/\b(so|somente|apenas) (servico\w*)\b/.test(s)) r.tipo = 'servico'; else if (/\b(so|somente|apenas) (produto\w*)\b/.test(s)) r.tipo = 'produto'
  return Object.keys(r).length && c.termos.length === 0 ? r : null
}
/** Assuntos de outros recursos: o modo devolve a mensagem para o chat comum (que cria lembrete, compromisso, lançamento…). */
async function outroAssunto(u: any, texto: string): Promise<boolean> {
  const s = norm(texto)
  if (/^(oi|ola|obrigad\w*|valeu|ok|blz|beleza|tchau|bom dia|boa tarde|boa noite|sim|nao)\b/.test(s) && s.split(' ').length <= 3) return true
  if (/\b(lembr\w*|lembrete\w*|anot\w*|agenda|compromisso\w*|tarefa\w*|gastei|paguei|recebi|vendi|gasto\w*|despesa\w*|saldo|quanto gastei|cotacao|clima|tempo hoje)\b/.test(s)) return true
  try {
    const tz = (await import('../lib/account.js')).settingsOf(u).timezone, A = await import('../ai/appt.js'), G = await import('../ai/agenda.js')
    if (A.parseReminder(texto, tz) || A.parseAppointment(texto, tz) || G.isAgendaQuery(texto)) return true
  } catch { /* sem motores: segue */ }
  return false
}

export async function pesquisar(userId: number, c: Consulta) {
  const B = await import('../routes/businesses.js')
  const loc = await B.userLocation(userId).catch(() => null)
  const lista = await B.itensPublicos(loc)
  const limite = POR_PAGINA * (c.pagina + 1)
  const r = buscar(lista, c, limite + 1)
  const pag = r.itens.slice(POR_PAGINA * c.pagina, limite)
  return { ...r, pag, temMais: r.total > limite, loc, vazio: !lista.length }
}
function rotulo(c: Consulta) { return c.texto || c.termos.join(' ') }
function cabecalho(n: number, c: Consulta, corr: Record<string, string>, tipos: string[], pagina: number) {
  const so = tipos.every((t) => t === 'servico') ? 'servico' : tipos.every((t) => t === 'produto') ? 'produto' : c.tipo
  const tipo = so === 'servico' ? (n === 1 ? 'serviço' : 'serviços') : so === 'produto' ? (n === 1 ? 'produto' : 'produtos') : (n === 1 ? 'opção' : 'opções')
  const filtros = [c.maxPreco != null ? `até ${brl(c.maxPreco)}` : '', c.ofertas ? 'em oferta' : ''].filter(Boolean).join(', ')
  const corrTxt = Object.keys(corr).length ? ` (entendi "${Object.entries(corr).map(([, b]) => b).join(' ')}")` : ''
  return `${pagina ? 'Mais' : `Encontrei ${n}`} ${tipo} para "${rotulo(c)}"${filtros ? ` ${filtros}` : ''}${corrTxt}${NOMES_ORDEM[c.ordem] || ''}:`
}
function montar(res: Awaited<ReturnType<typeof pesquisar>>, c: Consulta): Resposta {
  const ids = (l: any[]) => l.map((x) => (x.tipo === 'servico' ? 's' : 'p') + x.id).join(',')
  const semLoc = !res.loc ? ' Para ver primeiro o que está perto de você, ative sua localização. ⟦btn:/x/empresas|Usar minha localização⟧' : ''
  const vitrine = `⟦btn:/x/empresas?modo=${c.tipo === 'servico' ? 'servicos' : 'produtos'}|Ver a vitrine⟧`
  if (res.pag.length) {
    const mais = res.temMais ? ' Quer ver mais? É só dizer "mais opções".' : ''
    return { content: `${cabecalho(res.pag.length, c, res.corrigidas, res.pag.map((x: any) => x.tipo), c.pagina)} ⟦bp:${ids(res.pag)}⟧${res.semelhantes.length && !c.pagina ? ` ⟦bp:${ids(res.semelhantes)}|Também podem te interessar⟧` : ''}${mais}${c.pagina ? '' : semLoc}`, cards: [] }
  }
  if (c.pagina) return { content: `Esses eram todos os resultados para "${rotulo(c)}". Quer procurar outra coisa?`, cards: [] }
  if (res.semelhantes.length) return { content: `Não encontrei exatamente "${rotulo(c)}", mas estes são parecidos: ⟦bp:${ids(res.semelhantes)}⟧`, cards: [] }
  const filtro = c.maxPreco != null || c.ofertas ? ' com esses filtros' : ''
  if (res.vazio) return { content: `Ainda não há lojas parceiras com produtos ou serviços no ar${res.loc ? ' perto de você' : ''}. ${vitrine}`, cards: [] }
  return { content: `Não encontrei "${rotulo(c)}"${filtro} nas lojas parceiras${res.loc ? ' perto de você' : ''}. Tente outro nome ou descreva o que precisa. ${vitrine}`, cards: [] }
}
const PERGUNTA: Resposta = { content: 'Certo! O que você procura? Escreva o nome ou descreva o produto ou serviço (ex.: "bolo de chocolate", "corte de cabelo", "ração até 80 reais").', cards: [] }

export const buscaProdutos: Modo = {
  id: 'busca',
  nome: 'Busca de produtos e serviços',
  descricao: 'Encontra produtos e serviços nas lojas parceiras, com preço, disponibilidade e link para comprar.',
  icone: 'busca',
  ferramentas: ['itens_publicos'],
  detectar: (texto) => !!intencaoBusca(texto) && !ehPedidoDeExplicacao(texto), // "como faço para buscar produtos?" é pedido de explicação (guia), não busca
  async acesso() {
    const { modules } = await import('../lib/usermod.js'), m = await modules()
    if (m.empresas === false || m.catalogo === false) return { liberado: false, codigo: 'desligado', mensagem: 'A busca de produtos e serviços está desligada no momento.' }
    return { liberado: true, codigo: 'ok', mensagem: 'Disponível para todos.' }
  },
  async iniciar() { return { resposta: PERGUNTA, estado: { etapa: 'aguardando' } } },
  async responder(ctx: ContextoExec) {
    const { texto, estado, u } = ctx, ant = (estado.consulta || null) as Consulta | null
    const it = intencaoBusca(texto)
    let c: Consulta | null = null
    if (it && it.termos.length) c = { termos: it.termos, maxPreco: it.maxPreco, ordem: it.ordem, ofertas: it.ofertas, tipo: it.tipo, pagina: 0, texto: it.rotulo }
    else if (it && !ant) return { resposta: PERGUNTA, estado: { etapa: 'aguardando' } } // "buscar produto": pergunta o quê
    else if (!it && ctx.auto) return null
    else if (await outroAssunto(u, texto)) return null // outro recurso: o chat comum responde (e o modo se desliga)
    else {
      const rf = ant ? refinamento(texto) : null
      if (rf && ant) c = { ...ant, ...rf, pagina: rf.pagina ? ant.pagina + 1 : 0 }
      else {
        // texto curto dentro do modo: um item novo ("bolo de pote") ou complemento do anterior ("e de chocolate?")
        const l = lerConsulta(texto), curto = norm(texto).split(' ').length <= 7
        if (!l.termos.length || !curto) return null
        const compl = ant && /^(e|tem|com|sem|de|da|do|so)\b/.test(norm(texto)) ? { ...ant, termos: [...new Set([...ant.termos, ...l.termos])], pagina: 0, texto: `${ant.texto} ${l.rotulo}`.trim() } : null
        if (compl) { const r1 = await pesquisar(u.id, compl); if (r1.pag.length) return { resposta: montar(r1, compl), estado: { etapa: 'resultado', consulta: compl } } }
        c = { termos: l.termos, maxPreco: l.maxPreco ?? ant?.maxPreco ?? null, ordem: l.ordem !== 'relevancia' ? l.ordem : 'relevancia', ofertas: l.ofertas, tipo: l.tipo, pagina: 0, texto: l.rotulo }
        const r2 = await pesquisar(u.id, c)
        if (!r2.pag.length && !r2.semelhantes.length) return null // sem pedido explícito e sem resultado: não era busca, o chat comum responde
        return { resposta: montar(r2, c), estado: { etapa: 'resultado', consulta: c } }
      }
    }
    const res = await pesquisar(u.id, c!)
    // ligado sozinho e nada encontrado: se a palavra é de uma EMPRESA parceira (ex.: "piercing"), quem responde é a busca de
    // empresas de sempre; sem nada em lugar nenhum, o modo responde com honestidade e sugestões
    if (ctx.auto && !res.pag.length && !res.semelhantes.length) {
      const rec = await (await import('../routes/businesses.js')).reconhecerBusca(texto).catch(() => null)
      if (rec || !it?.forte) return null
    }
    return { resposta: montar(res, c!), estado: { etapa: 'resultado', consulta: c } as EstadoModo }
  },
}
