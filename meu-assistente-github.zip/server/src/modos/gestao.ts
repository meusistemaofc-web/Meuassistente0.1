// MODO INTELIGENTE "GESTÃO DA EMPRESA" — o dono (ou quem tem vínculo válido) gerencia a empresa conversando, com PRÉVIA
// nativa no chat antes de salvar. Não é uma gestão paralela: lê e grava pelo administrador conversacional que já existe
// (ai/empresa-admin.ts → empresaAtiva, localizar, alterar, chamar), que usa as ROTAS OFICIAIS do painel (mesmas validações,
// permissões, vínculos, auditoria e isolamento entre empresas).
//
// Fluxo: pedido em linguagem natural → interpretação (regras locais; IA com as ferramentas oficiais como apoio) → PRÉVIA
// (antes × depois, valor alterado destacado) com Confirmar / Editar novamente / Cancelar → só no "Confirmar" a alteração é
// gravada → resposta com o resultado REAL lido do banco. Nada é gravado antes da confirmação; ações destrutivas (excluir)
// pedem a confirmação explícita na própria prévia. A proposta fica no estado do modo da conversa (conversa_modos).
import type { Modo, ContextoExec, EstadoModo, Resposta } from './tipos.js'
import type { SessionUser } from '../lib/session.js'
import { J, nowIso } from '../db/index.js'

const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const num = (s: string) => { const t = String(s || '').replace(/[^\d.,]/g, ''); const v = Number(t.includes(',') ? t.replace(/\./g, '').replace(',', '.') : t); return Number.isFinite(v) ? Math.round(v * 100) / 100 : NaN }
const limpa = (s: string) => String(s || '').trim().replace(/^["“'«]|["”'»]$/g, '').replace(/[.!]+$/, '').trim()

export interface Card { nome?: string; preco?: number | null; oferta?: number | null; descricao?: string; categoria?: string; foto?: string | null; ativo?: boolean; tipo?: string
  empresa?: string; whatsapp?: string; endereco?: string; instagram?: string; contato?: string; logo?: string | null; horario?: string; pedidos?: string }
export interface Previa { tipo: 'produto' | 'produto_novo' | 'empresa' | 'excluir_produto' | 'texto'; titulo: string; antes?: Card | null; depois: Card; destaque: string[]; aviso?: string; destrutiva?: boolean }
export interface Proposta { id: string; acao: string; args: any; previa: Previa; status: 'pendente' | 'confirmada' | 'cancelada' | 'falhou' | 'substituida'; resultado?: string; bid: number; empresa: string; criadaEm: string }

/* ---------- interpretação (regras locais) ---------- */
const VERB = String.raw`(?:altere|alterar|mude|mudar|muda|troque|trocar|coloque|colocar|ajuste|ajustar|atualize|atualizar|defina|definir|deixe|deixar|passe|passar)`
const DIA: Record<string, string> = { seg: 'seg', segunda: 'seg', ter: 'ter', terca: 'ter', qua: 'qua', quarta: 'qua', qui: 'qui', quinta: 'qui', sex: 'sex', sexta: 'sex', sab: 'sab', sabado: 'sab', dom: 'dom', domingo: 'dom' }
const ORD = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom']
const empresaAlvo = (s: string) => /^(a |da |minha |nossa )*(empresa|loja|perfil|negocio|estabelecimento)$/.test(nrm(s))
export function interpretar(texto: string, anexo = ''): { acao: string; args: any } | null {
  const t = String(texto || '').replace(/\s+/g, ' ').trim(), n = nrm(t)
  let m: RegExpExecArray | null
  // criar produto/serviço: "crie um produto Brigadeiro gourmet por R$ 6,50, descrição: chocolate belga"
  if ((m = /^(?:crie|criar|cadastre|cadastrar|adicione|adicionar|inclua|incluir|novo|nova)\s+(?:um\s+|uma\s+)?(?:novo\s+|nova\s+)?(produto|servi[cç]o)\s*:?\s*(.+)$/i.exec(t))) {
    const tipo = /produto/i.test(m[1]) ? 'produto' : 'servico'; let resto = m[2]
    const desc = /[,;]?\s*(?:com\s+)?(?:a\s+)?descri[cç][aã]o\s*:?\s*(.+)$/i.exec(resto); if (desc) resto = resto.slice(0, desc.index)
    const cat = /[,;]?\s*(?:na\s+)?categoria\s*:?\s*([^,;]+)/i.exec(resto); if (cat) resto = resto.replace(cat[0], '')
    const pr = /[,;]?\s*(?:por|a|de|custando|no valor de|valor|pre[cç]o)\s*:?\s*(?:r\$\s*)?(\d[\d.,]*)\s*(?:reais)?/i.exec(resto); if (pr) resto = resto.replace(pr[0], '')
    const nome = limpa(resto.replace(/^(chamad[oa]|com o nome|de nome)\s+/i, '').replace(/[,;]+$/, ''))
    return { acao: 'produto_criar', args: { tipo, nome, preco: pr ? num(pr[1]) : null, descricao: desc ? limpa(desc[1]) : '', categoria: cat ? limpa(cat[1]) : '', foto: anexo || '' } }
  }
  // preço / oferta de produto
  if ((m = new RegExp(String.raw`^${VERB}\s+(?:o\s+)?(?:pre[cç]o|valor)\s+d[oa]s?\s+(?:produto\s+|servi[cç]o\s+)?(.+?)\s+(?:para|pra|por|em)\s+(?:r\$\s*)?(\d[\d.,]*)`, 'i').exec(t))) return { acao: 'produto_preco', args: { produto: limpa(m[1]), valor: num(m[2]) } }
  if ((m = /^(?:o\s+)?(?:pre[cç]o|valor)\s+d[oa]s?\s+(.+?)\s+(?:agora\s+)?(?:[eé]|fica|passa a ser|vai ser)\s+(?:r\$\s*)?(\d[\d.,]*)/i.exec(t))) return { acao: 'produto_preco', args: { produto: limpa(m[1]), valor: num(m[2]) } }
  if ((m = /^(?:coloque|ponha|crie|fa[cç]a|ative|deixe)\s+(?:uma\s+|em\s+)?(?:oferta|promo[cç][aã]o)\s+(?:d[oa]\s+|n[oa]\s+|para\s+o\s+|para\s+a\s+)?(.+?)\s+(?:por|a|de|em)\s+(?:r\$\s*)?(\d[\d.,]*)/i.exec(t))) return { acao: 'produto_oferta', args: { produto: limpa(m[1]), valor: num(m[2]), ativo: true } }
  if ((m = /^(?:tire|remova|retire|encerre|desative)\s+a\s+(?:oferta|promo[cç][aã]o)\s+d[oa]\s+(.+)$/i.exec(t))) return { acao: 'produto_oferta', args: { produto: limpa(m[1]), ativo: false } }
  // nome
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+nome\s+d[oa]\s+(.+?)\s+para\s+(.+)$`, 'i').exec(t))) return empresaAlvo(m[1]) ? { acao: 'alterar_nome', args: { texto: limpa(m[2]) } } : { acao: 'produto_nome', args: { produto: limpa(m[1].replace(/^(produto|servi[cç]o)\s+/i, '')), texto: limpa(m[2]) } }
  if ((m = /^renomei?e\s+(?:o\s+)?(?:produto\s+|servi[cç]o\s+)?(.+?)\s+para\s+(.+)$/i.exec(t))) return { acao: 'produto_nome', args: { produto: limpa(m[1]), texto: limpa(m[2]) } }
  // descrição
  if ((m = new RegExp(String.raw`^${VERB}\s+a\s+descri[cç][aã]o\s+d[oa]\s+(.+?)\s+para\s*:?\s*(.+)$`, 'i').exec(t))) return empresaAlvo(m[1]) ? { acao: 'alterar_descricao', args: { texto: limpa(m[2]) } } : { acao: 'produto_descricao', args: { produto: limpa(m[1].replace(/^(produto|servi[cç]o)\s+/i, '')), texto: limpa(m[2]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+a\s+descri[cç][aã]o\s+(?:da\s+)?(?:minha\s+)?(?:empresa|loja)?\s*para\s*:?\s*(.+)$`, 'i').exec(t))) return { acao: 'alterar_descricao', args: { texto: limpa(m[1]) } }
  // contato e endereço
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+(?:whats\s*app|whatsapp|zap|telefone|celular|n[uú]mero)\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_whatsapp', args: { texto: limpa(m[1]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+endere[cç]o\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_endereco', args: { texto: limpa(m[1]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+instagram\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_instagram', args: { texto: limpa(m[1]) } }
  // categoria
  if ((m = /^(?:mude|mova|coloque|passe|troque)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+?)\s+(?:para|na|pra)\s+(?:a\s+)?categoria\s+(.+)$/i.exec(t))) return { acao: 'produto_categoria', args: { produto: limpa(m[1]), texto: limpa(m[2]) } }
  // foto do produto (com a foto anexada)
  if (anexo && (m = /(?:foto|imagem)\s+d[oa]\s+(?:produto\s+|servi[cç]o\s+)?(.+?)(?:\s+(?:por|com)\s+(?:esta|essa|a)\s+(?:foto|imagem).*)?$/i.exec(t))) return { acao: 'produto_foto', args: { produto: limpa(m[1].replace(/\s+(?:por|com)\s+.*$/, '')), foto: anexo } }
  // pedidos (loja)
  if (/^(?:pause|pausar|feche|fechar|suspenda|pare|parar)\s+(?:os\s+|a\s+|o\s+)?(?:pedidos|loja|catalogo)\b/.test(n)) return { acao: 'pausar_pedidos', args: {} }
  if (/^(?:reative|reativar|reabra|reabrir|abra|abrir|volte a receber|ative)\s+(?:os\s+|a\s+|o\s+)?(?:pedidos|loja|catalogo)\b/.test(n)) return { acao: 'reativar_pedidos', args: {} }
  // pausar / reativar / excluir produto
  if ((m = /^(?:pause|pausar|desative|desativar|esconda|esconder|oculte|ocultar|tire do ar|tirar do ar)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'produto_pausar', args: { produto: limpa(m[1]) } }
  if ((m = /^(?:reative|reativar|ative|ativar|mostre de novo|volte a vender|volte a mostrar|coloque de volta)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'produto_ativar', args: { produto: limpa(m[1]) } }
  if ((m = /^(?:exclua|excluir|apague|apagar|remova|remover|delete|deletar)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'excluir_produto', args: { produto: limpa(m[1]) } }
  // horário: "abra de segunda a sexta das 9h às 18h"
  if (/hor[aá]rio|abr[ae]|funciona|atend/.test(n) && (m = /\b(seg\w*|ter\w*|qua\w*|qui\w*|sex\w*|sab\w*|dom\w*)\s+(?:a|ate)\s+(seg\w*|ter\w*|qua\w*|qui\w*|sex\w*|sab\w*|dom\w*).*?(\d{1,2})(?:h|:)?(\d{2})?\s*(?:as|a|ate|-)\s*(\d{1,2})(?:h|:)?(\d{2})?/.exec(n))) {
    const a = DIA[m[1].replace(/-feira$/, '').slice(0, 7)] || DIA[m[1].slice(0, 3)], b = DIA[m[2].replace(/-feira$/, '').slice(0, 7)] || DIA[m[2].slice(0, 3)]
    const i = ORD.indexOf(a), j = ORD.indexOf(b); if (i >= 0 && j >= i) return { acao: 'alterar_horario', args: { dias: ORD.slice(i, j + 1), abre: `${m[3].padStart(2, '0')}:${m[4] || '00'}`, fecha: `${m[5].padStart(2, '0')}:${m[6] || '00'}` } }
  }
  return null
}

/* ---------- apoio da IA (mesmas ferramentas oficiais) ---------- */
async function interpretarComIA(u: SessionUser, texto: string): Promise<{ acao: string; args: any } | null> {
  try {
    const P = await import('../ai/provider.js'); if (!(await P.readyCount('conversa'))) return null
    const EA = await import('../ai/empresa-admin.js')
    const tools = [...EA.EMPRESA_TOOLS.filter((x) => x.function.name === 'empresa_alterar'), { type: 'function' as const, function: { name: 'produto_criar', description: 'Cria um produto ou serviço novo no catálogo da empresa ativa.', parameters: { type: 'object', properties: { tipo: { type: 'string', enum: ['produto', 'servico'] }, nome: { type: 'string' }, preco: { type: 'number' }, descricao: { type: 'string' }, categoria: { type: 'string' } }, required: ['nome'] } } }]
    const m: any = await P.complete([{ role: 'system', content: 'Você traduz o pedido do dono da empresa em UMA chamada de ferramenta (empresa_alterar ou produto_criar), sem executar nada: a alteração só será salva depois que ele confirmar a prévia. Não invente valores que ele não disse. Se o pedido não for uma alteração da empresa, não chame ferramenta.' }, { role: 'user', content: String(texto).slice(0, 1000) }], tools as any, { temperature: 0.1 })
    const tc = (m?.tool_calls || [])[0]; if (!tc) return null
    const args = J<any>(tc.function?.arguments, {})
    if (tc.function?.name === 'produto_criar') return { acao: 'produto_criar', args: { tipo: args.tipo === 'servico' ? 'servico' : 'produto', nome: String(args.nome || ''), preco: Number.isFinite(Number(args.preco)) ? Number(args.preco) : null, descricao: String(args.descricao || ''), categoria: String(args.categoria || ''), foto: '' } }
    if (tc.function?.name === 'empresa_alterar' && args.acao && args.acao !== 'trocar_empresa_ativa') { const { acao, confirmacao, ...rest } = args; return { acao: String(acao), args: rest } }
  } catch { /* sem IA: segue pelas regras locais */ }
  return null
}

/* ---------- prévia (lida do banco, nada é gravado) ---------- */
const ROT_ACAO: Record<string, string> = { produto_preco: 'Novo preço', produto_oferta: 'Oferta', produto_nome: 'Novo nome', produto_descricao: 'Nova descrição', produto_categoria: 'Nova categoria', produto_pausar: 'Pausar produto', produto_ativar: 'Reativar produto', produto_foto: 'Nova foto', produto_criar: 'Novo produto', excluir_produto: 'Excluir produto', alterar_descricao: 'Nova descrição da empresa', alterar_nome: 'Novo nome da empresa', alterar_whatsapp: 'Novo WhatsApp', alterar_endereco: 'Novo endereço', alterar_instagram: 'Novo Instagram', alterar_contato: 'Novo contato', alterar_horario: 'Novo horário', pausar_pedidos: 'Pausar pedidos', reativar_pedidos: 'Reativar pedidos' }
type Ativa = { b: any; x: any; nome: string; propria: boolean }
async function cardProduto(u: SessionUser, e: Ativa, pid: number): Promise<Card> {
  const EA = await import('../ai/empresa-admin.js'), f: any = await EA.chamar(u, e as any, 'GET', `/api/v2/ads/${e.b.id}/products/${pid}`)
  const lista = await EA.produtos(Number(e.b.id)), p = lista.find((x) => x.id === pid)
  return { nome: f.nome, preco: Number(f.preco) || 0, oferta: p?.oferta ?? null, descricao: f.descricao || '', categoria: f.categoria || '', foto: f.thumb || (f.fotos || [])[0] || null, ativo: p ? p.ativo : true, tipo: f.tipo }
}
const cardEmpresa = (e: Ativa, x: any): Card => ({ empresa: x.empresa || e.nome, descricao: x.sobre || x.texto || '', whatsapp: x.zap || '', endereco: x.endereco || '', instagram: x.insta || '', contato: x.contato || '', logo: x.logo || null, horario: x.horario || '', pedidos: x.horarioCfg?.modo === 'fechado' ? 'Pausados' : 'Recebendo' })
export async function montarPrevia(u: SessionUser, e: Ativa, acao: string, args: any): Promise<{ ok: true; previa: Previa; args: any } | { ok: false; msg: string }> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id)
  const titulo = ROT_ACAO[acao] || 'Alteração'
  if (acao === 'produto_criar') {
    const nome = String(args.nome || '').trim(), preco = Number(args.preco)
    if (!nome) return { ok: false, msg: 'Qual o nome do novo produto? Ex.: "crie um produto Brigadeiro gourmet por R$ 6,50".' }
    if (!(preco > 0) && args.tipo !== 'servico') return { ok: false, msg: `Qual o preço de **${nome}**? Ex.: "por R$ 6,50".` }
    if (args.foto && String(args.foto).length >= 900_000) return { ok: false, msg: 'Essa foto é muito grande para o catálogo. Envie uma imagem menor (até ~600 KB).' }
    if (args.tipo !== 'servico' && !args.foto) return { ok: false, msg: `Para publicar **${nome}** no catálogo, envie uma foto do produto aqui na conversa (o catálogo exige foto nos produtos).`, }
    const existe = (await EA.produtos(bid)).find((p) => nrm(p.nome) === nrm(nome)); if (existe) return { ok: false, msg: `Já existe **${existe.nome}** no catálogo. Quer alterar esse produto? Ex.: "altere o preço do ${existe.nome} para R$ 10".` }
    return { ok: true, args, previa: { tipo: 'produto_novo', titulo, antes: null, depois: { nome, preco: preco > 0 ? preco : null, descricao: args.descricao || '', categoria: args.categoria || '', foto: args.foto || null, ativo: true, tipo: args.tipo }, destaque: ['nome', 'preco', 'descricao', 'foto'] } }
  }
  if (acao.startsWith('produto_') || acao === 'excluir_produto') {
    const loc = await EA.localizar(bid, args.produto, args.variacao)
    if (!loc.ok) return { ok: false, msg: `${loc.erro}${loc.opcoes?.length ? '\n' + loc.opcoes.map((x) => `- ${x}`).join('\n') : ''}` }
    const pid = Number(loc.alvo.p.id), antes = await cardProduto(u, e, pid), depois: Card = { ...antes }, destaque: string[] = []
    const a2 = { ...args, produto: String(pid), ...(loc.alvo.v ? { variacao: String(loc.alvo.v.id) } : {}) }
    if (acao === 'produto_preco') { const v = Number(args.valor); if (!(v > 0)) return { ok: false, msg: 'Qual o novo preço? Ex.: "R$ 29,90".' }; if (loc.alvo.v) { depois.nome = `${antes.nome} · ${loc.alvo.v.rotulo}`; antes.nome = depois.nome; antes.preco = loc.alvo.v.preco } depois.preco = v; destaque.push('preco') }
    else if (acao === 'produto_oferta') { if (args.ativo === false) { depois.oferta = null; destaque.push('oferta') } else { const v = Number(args.valor); if (!(v > 0)) return { ok: false, msg: 'Qual o preço da oferta?' }; if (v >= Number(antes.preco)) return { ok: false, msg: `O preço da oferta (${brl(v)}) precisa ser menor que o preço normal (${brl(Number(antes.preco))}).` }; depois.oferta = v; destaque.push('oferta') } }
    else if (acao === 'produto_nome') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual o novo nome?' }; depois.nome = v.slice(0, 80); destaque.push('nome') }
    else if (acao === 'produto_descricao') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual a nova descrição?' }; depois.descricao = v.slice(0, 600); destaque.push('descricao') }
    else if (acao === 'produto_categoria') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual a categoria?' }; depois.categoria = v.slice(0, 40); destaque.push('categoria') }
    else if (acao === 'produto_pausar') { depois.ativo = false; destaque.push('ativo') }
    else if (acao === 'produto_ativar') { depois.ativo = true; destaque.push('ativo') }
    else if (acao === 'produto_foto') { if (!args.foto) return { ok: false, msg: 'Envie a foto aqui na conversa junto com o pedido.' }; if (String(args.foto).length >= 900_000) return { ok: false, msg: 'Essa foto é muito grande para o catálogo. Envie uma imagem menor (até ~600 KB).' }; depois.foto = args.foto; destaque.push('foto') }
    else if (acao === 'excluir_produto') return { ok: true, args: a2, previa: { tipo: 'excluir_produto', titulo, antes, depois: { ...antes }, destaque: [], destrutiva: true, aviso: `Isso EXCLUI "${antes.nome}" do catálogo de forma definitiva (não dá para desfazer). Se quiser só tirar do ar por um tempo, peça para pausar.` } }
    else return { ok: false, msg: 'Não sei mostrar a prévia dessa alteração.' }
    if (acao === 'produto_pausar' && antes.ativo === false) return { ok: false, msg: `${antes.nome} já está pausado.` }
    if (acao === 'produto_ativar' && antes.ativo !== false) return { ok: false, msg: `${antes.nome} já está ativo no catálogo.` }
    return { ok: true, args: a2, previa: { tipo: 'produto', titulo, antes, depois, destaque } }
  }
  const x = await EA.dados(bid), antes = cardEmpresa(e, x), depois: Card = { ...antes }, destaque: string[] = []
  const tx = String(args.texto || '').trim()
  if (acao === 'alterar_descricao') { if (tx.length < 10) return { ok: false, msg: 'Escreva a nova descrição (pelo menos uma frase).' }; depois.descricao = tx.slice(0, 1000); destaque.push('descricao') }
  else if (acao === 'alterar_nome') { if (tx.length < 2) return { ok: false, msg: 'Qual o novo nome da empresa?' }; depois.empresa = tx.slice(0, 80); destaque.push('empresa') }
  else if (acao === 'alterar_whatsapp') { const d = tx.replace(/\D/g, ''); if (d.length < 10 || d.length > 13) return { ok: false, msg: 'Informe o WhatsApp com DDD. Ex.: (11) 98888-7777.' }; depois.whatsapp = d.length <= 11 ? '55' + d : d; destaque.push('whatsapp') }
  else if (acao === 'alterar_endereco') { if (tx.length < 6) return { ok: false, msg: 'Informe o endereço completo (rua, número, bairro e cidade).' }; depois.endereco = tx.slice(0, 200); destaque.push('endereco') }
  else if (acao === 'alterar_instagram') { depois.instagram = tx.replace(/^@/, '').slice(0, 60); destaque.push('instagram') }
  else if (acao === 'alterar_contato') { depois.contato = tx.slice(0, 80); destaque.push('contato') }
  else if (acao === 'alterar_horario') { const NOME: Record<string, string> = { seg: 'seg', ter: 'ter', qua: 'qua', qui: 'qui', sex: 'sex', sab: 'sáb', dom: 'dom' }; const ds: string[] = args.dias || []; depois.horario = `${ds.length === 7 ? 'Todos os dias' : `${NOME[ds[0]]} a ${NOME[ds[ds.length - 1]]}`}, ${args.abre}–${args.fecha} (demais dias fechados)`; destaque.push('horario') }
  else if (acao === 'pausar_pedidos') { if (antes.pedidos === 'Pausados') return { ok: false, msg: 'Os pedidos já estão pausados.' }; depois.pedidos = 'Pausados'; destaque.push('pedidos') }
  else if (acao === 'reativar_pedidos') { if (antes.pedidos === 'Recebendo') return { ok: false, msg: 'A empresa já está recebendo pedidos.' }; depois.pedidos = 'Recebendo'; destaque.push('pedidos') }
  else return { ok: false, msg: 'Essa alteração ainda não tem prévia no modo Gestão da Empresa. Use Sua empresa → Ajustes para fazê-la.' }
  return { ok: true, args, previa: { tipo: 'empresa', titulo, antes, depois, destaque } }
}

/* ---------- execução (só depois do Confirmar) ---------- */
async function executar(u: SessionUser, e: Ativa, p: Proposta): Promise<{ ok: boolean; texto: string }> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id)
  if (Number(p.bid) !== bid) return { ok: false, texto: 'A empresa ativa mudou depois da prévia; nada foi alterado. Peça de novo.' }
  if (p.acao === 'produto_criar') {
    const a = p.args, antes = (await EA.produtos(bid)).length
    await EA.chamar(u, e as any, 'POST', `/api/v2/ads/${bid}/products`, { tipo: a.tipo, nome: a.nome, preco: Number(a.preco) || 0, descricao: a.descricao || '', categoria: a.categoria || '', fotos: a.foto ? [a.foto] : [], ...(a.tipo === 'servico' ? { duracao: 30 } : {}) })
    const novo = (await EA.produtos(bid)).find((x) => nrm(x.nome) === nrm(a.nome))
    return novo && (await EA.produtos(bid)).length === antes + 1 ? { ok: true, texto: `Pronto! **${novo.nome}** foi publicado no catálogo da ${e.nome} por ${brl(novo.preco)}.` } : { ok: false, texto: 'O produto não apareceu no catálogo depois de salvar; considere que NÃO foi criado.' }
  }
  if (p.acao === 'produto_foto') {
    const { f, body } = await EA.corpoProduto(u, e as any, Number(p.args.produto))
    await EA.chamar(u, e as any, 'POST', `/api/v2/ads/${bid}/products`, { ...body, fotos: [p.args.foto, ...(body.fotos || []).slice(0, 1)], thumb: undefined })
    const depois: any = await EA.chamar(u, e as any, 'GET', `/api/v2/ads/${bid}/products/${p.args.produto}`)
    return (depois.fotos || [])[0] === p.args.foto ? { ok: true, texto: `Pronto! A foto de **${f.nome}** foi trocada no catálogo.` } : { ok: false, texto: 'A foto não foi confirmada no catálogo; considere que NÃO foi trocada.' }
  }
  const r = await EA.alterar(u, e as any, { ...p.args, acao: p.acao, __confirmado: true }) // a confirmação foi a própria prévia
  return { ok: !!r?.ok, texto: EA.formatar(r) }
}

/* ---------- modo ---------- */
const CONFIRMA = /^(confirmar( altera[cç][oõ]es)?|confirmo|confirma|sim|sim,? (pode )?(salvar|confirmar|publicar|excluir)|pode salvar|salvar|salva|publicar|publica|ok,? (pode )?salvar|excluir definitivamente|confirmar exclusao)$/
const CANCELA = /^(cancelar( altera[cç][oõ]es)?|cancela|cancele|n[aã]o|nao,? cancele|deixa|deixa pra l[aá]|esquece|desistir)$/
const EDITA = /^(editar( novamente)?|editar de novo|quero (editar|ajustar|mudar)|ajustar|corrigir|alterar a pr[eé]via)$/
const SAUDACAO_MODO = (nome: string, varias: boolean) => `🏪 **Gestão da Empresa** — ${nome}\n\nMe diga o que quer mudar e eu mostro uma **prévia** antes de salvar. Exemplos:\n- "altere o preço do Brigadeiro para R$ 6,50"\n- "crie um produto Bolo de pote por R$ 12, descrição: chocolate com morango" (envie a foto junto)\n- "mude a descrição da empresa para …"\n- "pause o produto Torta de limão" · "horário de segunda a sábado das 9h às 18h"${varias ? '\n\nVocê tem mais de uma empresa: para trocar, diga "gerenciar <nome da empresa>".' : ''}`
const rotuloEmpresa = async (u: SessionUser) => { const EA = await import('../ai/empresa-admin.js'); const a = await EA.empresaAtiva(u); return a }
const resposta = (content: string, meta?: any): Resposta => ({ content, cards: [], ...(meta ? { meta } : {}) })
const marca = (conv: string, id: string) => `⟦gest:${conv}|${id}⟧`
const novoId = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)

async function propor(c: ContextoExec, e: Ativa, acao: string, args: any, estado: EstadoModo, pre = ''): Promise<{ resposta: Resposta; estado: EstadoModo }> {
  const pv = await montarPrevia(c.u, e, acao, args)
  if (!pv.ok) return { resposta: resposta(pv.msg), estado: { ...estado, etapa: 'aguardando', ...(acao === 'produto_criar' ? { rascunho: { acao, args } } : {}) } }
  const props: Proposta[] = ((estado.propostas as Proposta[]) || []).map((p) => (p.status === 'pendente' ? { ...p, status: 'substituida' as const } : p)).slice(-5)
  const p: Proposta = { id: novoId(), acao, args: pv.args, previa: pv.previa, status: 'pendente', bid: Number(e.b.id), empresa: e.nome, criadaEm: nowIso() }
  const txt = pv.previa.destrutiva ? `${pre}Confira antes: esta ação **exclui** um produto da ${e.nome}. Nada foi alterado ainda.` : `${pre}Confira a prévia na ${e.nome}. **Nada foi salvo ainda** — toque em Confirmar para salvar, Editar novamente para ajustar ou Cancelar.`
  return { resposta: resposta(`${txt} ${marca(c.conversationId, p.id)}`, { gestao: { proposta: p.id, acao } }), estado: { ...estado, etapa: 'previa', propostas: [...props, p], atual: p.id, rascunho: null } }
}
export const gestaoEmpresa: Modo = {
  id: 'gestao_empresa', nome: 'Gestão da Empresa', descricao: 'Altere produtos, serviços, preços, horários e dados da sua empresa conversando, com prévia antes de salvar.', icone: 'store', ocultoSemAcesso: true,
  ferramentas: ['empresa_consultar', 'empresa_alterar', 'produto_criar'],
  async acesso(u) {
    const EA = await import('../ai/empresa-admin.js')
    if (!(await EA.empresaAdminDisponivel(u))) return { liberado: false, codigo: 'sem_empresa', mensagem: 'Disponível para quem tem uma empresa vinculada.' }
    const a = await EA.empresaAtiva(u)
    return { liberado: true, codigo: 'ok', mensagem: '', ...(a.ok ? { businessId: Number(a.e.b.id) } : {}) }
  },
  async iniciar(c) {
    const a = await rotuloEmpresa(c.u)
    if (!a.ok) return { resposta: resposta(`🏪 **Gestão da Empresa**\n\n${a.erro}${a.opcoes ? '\n' + a.opcoes.map((x) => `- ${x}`).join('\n') + '\n\nDiga "gerenciar <nome da empresa>".' : ''}`), estado: { etapa: 'escolher_empresa', propostas: [] } }
    const { q } = await import('../db/index.js'), V = await import('../lib/vinculos.js')
    const n = Number((await q("SELECT COUNT(*) AS n FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira')", [c.u.id]))[0]?.n || 0) + (await V.vinculadasValidas(c.u.id).catch(() => [] as any[])).length
    return { resposta: resposta(SAUDACAO_MODO(a.e.nome, n > 1)), estado: { etapa: 'aguardando', propostas: [] } }
  },
  async responder(c) {
    const EA = await import('../ai/empresa-admin.js'), t = String(c.texto || '').trim(), n = nrm(t).replace(/[!.?]+$/, '')
    const estado: EstadoModo = { ...(c.estado || { etapa: 'aguardando' }) }
    // trocar a empresa gerenciada (a mesma troca do seletor de empresas)
    const tr = /^(?:gerenciar|gerencie|trocar para|trocar de empresa para|usar a empresa|mudar para a empresa)\s+(?:a\s+empresa\s+)?(.+)$/i.exec(t)
    if (tr) { const r = await EA.runEmpresaTool(c.u, 'empresa_alterar', { acao: 'trocar_empresa_ativa', texto: tr[1] }); const a2 = await rotuloEmpresa(c.u); return { resposta: resposta(r?.ok ? `Pronto! Agora estou gerenciando a **${a2.ok ? a2.e.nome : tr[1]}**. O que você quer mudar?` : EA.formatar(r)), estado: { ...estado, etapa: 'aguardando', propostas: ((estado.propostas as Proposta[]) || []).map((p) => (p.status === 'pendente' ? { ...p, status: 'substituida' as const } : p)) } } }
    const at = await rotuloEmpresa(c.u); if (!at.ok) return { resposta: resposta(`${at.erro}${at.opcoes ? '\n' + at.opcoes.map((x) => `- ${x}`).join('\n') + '\n\nDiga "gerenciar <nome da empresa>".' : ''}`), estado }
    const e = at.e as Ativa
    const props = (estado.propostas as Proposta[]) || [], atual = props.find((p) => p.id === estado.atual && p.status === 'pendente')
    if (atual && CONFIRMA.test(n)) {
      if (atual.previa.destrutiva && !/excluir|confirm|sim/.test(n)) return { resposta: resposta('Para excluir, toque em Confirmar exclusão.'), estado }
      let r: { ok: boolean; texto: string }
      try { r = await executar(c.u, e, atual) } catch (x: any) { r = { ok: false, texto: `Não alterei: ${String(x?.message || 'algo deu errado').slice(0, 200)}` } }
      const novas = props.map((p) => (p.id === atual.id ? { ...p, status: (r.ok ? 'confirmada' : 'falhou') as Proposta['status'], resultado: r.texto } : p))
      return { resposta: resposta(`${r.texto}${r.ok ? '\n\nQuer ajustar mais alguma coisa?' : ''} ${marca(c.conversationId, atual.id)}`, { gestao: { proposta: atual.id, executada: r.ok } }), estado: { ...estado, etapa: 'aguardando', propostas: novas, atual: null } }
    }
    if (atual && CANCELA.test(n)) return { resposta: resposta(`Tudo bem, cancelei. Nada foi alterado na ${e.nome}. ${marca(c.conversationId, atual.id)}`), estado: { ...estado, etapa: 'aguardando', propostas: props.map((p) => (p.id === atual.id ? { ...p, status: 'cancelada' as const } : p)), atual: null } }
    if (atual && EDITA.test(n)) return { resposta: resposta(atual.acao === 'produto_criar' ? 'Certo! O que você quer mudar? Pode dizer, por exemplo: "preço 7,90", "nome Brigadeiro belga", "descrição: …", "categoria Doces" ou mandar outra foto.' : 'Certo! Me diga como deve ficar (ex.: o novo valor ou o novo texto).'), estado: { ...estado, etapa: 'editando' } }
    if (!atual && (CONFIRMA.test(n) || CANCELA.test(n) || EDITA.test(n))) { const ult = props[props.length - 1]; return { resposta: resposta(ult && ult.status === 'confirmada' ? 'Essa alteração já foi salva. Quer mudar mais alguma coisa?' : 'Não há nenhuma prévia aguardando confirmação. Me diga o que você quer mudar.'), estado } }
    // ajuste da prévia em aberto: "preço 7,90", "descrição: …", "nome …", só o valor/texto
    if (atual && (estado.etapa === 'editando' || /^(pre[cç]o|valor|nome|descri[cç][aã]o|categoria)\b/i.test(t) || (c.anexo && atual.acao === 'produto_criar'))) {
      const a = { ...atual.args }; let mudou = false
      const pr = /(?:pre[cç]o|valor)\s*:?\s*(?:r\$\s*)?(\d[\d.,]*)/i.exec(t) || (/^(?:r\$\s*)?(\d[\d.,]*)$/.exec(t))
      if (pr) { const v = num(pr[1]); if (atual.acao === 'produto_criar') a.preco = v; else if (['produto_preco', 'produto_oferta'].includes(atual.acao)) a.valor = v; mudou = true }
      const nm = /\bnome\s*:?\s*(.+?)(?:[,;]|$)/i.exec(t); if (nm) { if (atual.acao === 'produto_criar') a.nome = limpa(nm[1]); else if (['produto_nome', 'alterar_nome'].includes(atual.acao)) a.texto = limpa(nm[1]); mudou = true }
      const ds = /descri[cç][aã]o\s*:?\s*(.+)$/i.exec(t); if (ds) { if (atual.acao === 'produto_criar') a.descricao = limpa(ds[1]); else a.texto = limpa(ds[1]); mudou = true }
      const ct = /categoria\s*:?\s*(.+?)(?:[,;]|$)/i.exec(t); if (ct && atual.acao === 'produto_criar') { a.categoria = limpa(ct[1]); mudou = true }
      if (c.anexo && ['produto_criar', 'produto_foto'].includes(atual.acao)) { a.foto = c.anexo; mudou = true }
      if (!mudou && estado.etapa === 'editando' && ['produto_descricao', 'alterar_descricao', 'produto_nome', 'alterar_nome', 'alterar_endereco', 'alterar_whatsapp', 'produto_categoria'].includes(atual.acao)) { a.texto = limpa(t); mudou = true }
      if (mudou) return propor(c, e, atual.acao, a, { ...estado, etapa: 'aguardando' }, 'Prévia atualizada. ')
    }
    // rascunho de produto esperando um dado (foto, preço, nome)
    const rasc = estado.rascunho as any
    if (rasc && rasc.acao === 'produto_criar' && !interpretar(t, c.anexo || '')) {
      const a = { ...rasc.args }, pr = /(?:r\$\s*)?(\d[\d.,]*)/.exec(t)
      if (c.anexo) a.foto = c.anexo; if (pr && !a.preco) a.preco = num(pr[1]); if (!a.nome && t && !pr && !c.anexo) a.nome = limpa(t)
      return propor(c, e, 'produto_criar', a, estado)
    }
    if (/^(o que (voce|vc) (pode|consegue) (fazer|mudar)|ajuda|exemplos?|como funciona)\b/.test(n)) return { resposta: resposta(SAUDACAO_MODO(e.nome, false)), estado }
    let it = interpretar(t, c.anexo || '')
    if (!it) it = await interpretarComIA(c.u, t)
    if (!it) {
      if (/^(oi|ola|bom dia|boa tarde|boa noite|obrigad|valeu|ok|beleza)\b/.test(n)) return { resposta: resposta(`Estou no modo Gestão da Empresa da **${e.nome}**. O que você quer mudar? Ex.: "altere o preço do … para R$ …".`), estado }
      return null // não é um pedido de gestão: o chat comum responde (o modo se desliga sozinho)
    }
    if (it.acao === 'produto_criar' && c.anexo) it.args.foto = c.anexo
    return propor(c, e, it.acao, it.args, estado)
  },
}
/** Prévia para o cartão ⟦gest:conversa|id⟧ (só o próprio usuário, só a sua conversa). */
export async function previaDaConversa(userId: number, conv: string, id: string) {
  const { one } = await import('../db/index.js')
  const r = await one("SELECT estado FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2 AND modo = 'gestao_empresa'", [conv, userId]); if (!r) return null
  const p = ((J<any>(r.estado, {}).propostas || []) as Proposta[]).find((x) => x.id === id); if (!p) return null
  return { id: p.id, acao: p.acao, status: p.status, empresa: p.empresa, previa: p.previa, resultado: p.resultado || '', atual: J<any>(r.estado, {}).atual === p.id }
}
/** A foto desta mensagem é para o modo Gestão da Empresa? (modo ligado agora pelo ⚡ ou já ativo na conversa) */
export async function usaFoto(userId: number, conv: string, modoPedido: unknown) {
  if (modoPedido === 'gestao_empresa') return true
  if (typeof modoPedido === 'string' || !conv) return false
  const { one } = await import('../db/index.js')
  return !!(await one("SELECT 1 AS x FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2 AND modo = 'gestao_empresa'", [conv, userId]))
}
