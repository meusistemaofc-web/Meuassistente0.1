// Modos Inteligentes: especializações do Meu Assistente acionadas pelo botão ⚡ do campo de digitação.
// Cada modo declara identidade, regras de acesso (conferidas no servidor a cada mensagem), ferramentas autorizadas,
// contexto de execução e o próprio fluxo de conversa. O chat comum não muda nas conversas sem modo.
import type { SessionUser } from '../lib/session.js'
import type { ChatMsg } from '../ai/types.js'

export interface Acesso {
  liberado: boolean
  /** código estável do motivo (ex.: sem_empresa, plano_basico, vencido, suspenso) */
  codigo: string
  /** explicação curta para o usuário */
  mensagem: string
  /** ação sugerida quando bloqueado (ex.: conhecer/contratar a modalidade) */
  acao?: { rotulo: string; link: string }
  /** dados internos úteis ao modo quando liberado */
  businessId?: number
}
export interface EstadoModo {
  /** etapa do fluxo do modo (cada modo define as suas) */
  etapa: string
  [k: string]: unknown
}
export interface Resposta { content: string; cards: unknown[] }
export interface ContextoExec { u: SessionUser; conversationId: string; texto: string; historico: ChatMsg[]; estado: EstadoModo; acesso: Acesso }
export interface Modo {
  id: string
  nome: string
  descricao: string
  /** nome de ícone usado pelo app */
  icone: string
  /** benefício exclusivo de qual contratação (texto exibido no seletor) */
  exclusivo?: string
  /** ferramentas que o modo pode usar (declaradas e conferidas no código do modo) */
  ferramentas: string[]
  acesso(u: SessionUser): Promise<Acesso>
  /** primeira interação ao ativar o modo */
  iniciar(c: ContextoExec): Promise<{ resposta: Resposta; estado: EstadoModo }>
  /** cada mensagem enquanto o modo está ativo */
  responder(c: ContextoExec): Promise<{ resposta: Resposta; estado: EstadoModo }>
}
