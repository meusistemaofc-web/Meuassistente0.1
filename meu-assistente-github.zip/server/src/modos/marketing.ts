// Modo Consultor de Marketing: estrategista de negócios e marketing que trabalha COM o proprietário. A cada mensagem
// consulta os dados reais da empresa (dossiê abaixo), a memória estratégica e o conhecimento do Cérebro; conversa
// livremente (sem menus nem questionário), pergunta só o que muda a estratégia, constrói planos aos poucos e confere os
// números da resposta contra os dados. Propostas de campanha viram rascunho na Central de Marketing SÓ com a ação do responsável.
// Benefício exclusivo do anúncio completo da empresa (plano de nível 4 ativo), conferido no servidor a cada mensagem.
import { q, one, J, nowIso } from '../db/index.js'
import type { Modo, Acesso, ContextoExec, EstadoModo, Resposta } from './tipos.js'

const NIVEL_COMPLETO = 4
const VALIDADE_DIAS = 120 // respostas do briefing valem por 4 meses; depois o consultor confirma de novo
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()
const brl = (v: number) => 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')

/* ---------- acesso premium (reutiliza a contratação existente: tabela businesses + planos do anúncio) ---------- */
export async function acessoCompleto(userId: number): Promise<Acesso> {
  const { plans } = await import('../routes/ads.js')
  const ps: any[] = await plans(), nivel = (b: any) => Number(ps.find((p) => p.id === b.plan_id)?.nivel) || 0
  const nomePlano = (b: any) => ps.find((p) => p.id === b.plan_id)?.nome || 'atual'
  const completo = ps.filter((p) => Number(p.nivel) >= NIVEL_COMPLETO).map((p) => p.nome)[0] || 'Loja completa'
  const bs = await q("SELECT id, status, plan_id, expires_at FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') ORDER BY id DESC", [userId])
  const base = `O Consultor de Marketing é um benefício exclusivo do anúncio completo da empresa (plano ${completo}).`
  if (!bs.length) return { liberado: false, codigo: 'sem_empresa', mensagem: `${base} Você ainda não tem um anúncio contratado.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/anunciar' } }
  const vigente = (b: any) => b.status === 'ativo' && (!b.expires_at || Date.parse(b.expires_at) > Date.now())
  const ok = bs.find((b: any) => vigente(b) && nivel(b) >= NIVEL_COMPLETO)
  if (ok) return { liberado: true, codigo: 'ok', mensagem: 'Liberado pelo anúncio completo.', businessId: Number(ok.id) }
  const atual = bs.find(vigente)
  if (atual) return { liberado: false, codigo: 'plano_basico', mensagem: `${base} Seu anúncio está no plano ${nomePlano(atual)}. Ao mudar para o ${completo}, o acesso é liberado na hora.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/sua-empresa' } }
  const ult = bs[0]
  if (ult.status === 'ativo' || ult.status === 'encerrado') return { liberado: false, codigo: 'vencido', mensagem: `${base} A contratação do seu anúncio venceu. Ao renovar no plano ${completo}, o acesso volta na hora.`, acao: { rotulo: 'Renovar o anúncio', link: '/x/sua-empresa' } }
  if (['pagamento', 'analise', 'ajustes', 'aprovado'].includes(ult.status)) return { liberado: false, codigo: 'pendente', mensagem: `${base} Seu anúncio ainda não está no ar (aguardando ${ult.status === 'pagamento' ? 'pagamento' : 'aprovação'}). O acesso é liberado assim que ele for ativado no plano ${completo}.`, acao: { rotulo: 'Ver meu anúncio', link: '/x/sua-empresa' } }
  return { liberado: false, codigo: 'suspenso', mensagem: `${base} A contratação do seu anúncio está cancelada ou suspensa.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/sua-empresa' } }
}

/* ---------- dados reais da empresa ---------- */
interface Negocio { id: number; empresa: string; categoria: string; descricao: string; local: string; atendimento: string; instagram: string; whatsapp: string; site: string; publicoAlvo: string; tipo: string; itens: { nome: string; preco: number; categoria: string; servico: boolean }[]; horario: string }
export async function negocio(businessId: number): Promise<Negocio> {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [businessId]); const d = J<any>(b?.data, {})
  const prods = (await q('SELECT data FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 40', [businessId, true])).map((p: any) => J<any>(p.data, {}))
  const e = d.entrega || {}
  return { id: businessId, empresa: String(d.empresa || 'Sua empresa'), categoria: String(d.categoria || ''), descricao: [d.titulo, d.texto, d.sobre].filter(Boolean).join(' — ').slice(0, 600), local: String(d.endereco || d.cidade || ''),
    atendimento: e.entrega ? `entrega até ${e.raio || '?'} km${e.taxa != null ? ' (taxa ' + brl(e.taxa) + ')' : ''}${e.retirada ? ' e retirada' : ''}` : e.retirada ? 'somente retirada' : '', instagram: String(d.insta || '').replace(/^@/, ''), whatsapp: String(d.zap || ''), site: String(d.link || ''),
    publicoAlvo: String(d.publicoAlvo || d.publico || ''), tipo: d.tipo === 'servicos' ? 'serviços' : 'produtos', horario: typeof d.horario === 'string' ? d.horario : '',
    itens: prods.map((p: any) => ({ nome: String(p.nome || ''), preco: Number(p.preco) || 0, categoria: String(p.categoria || ''), servico: p.tipo === 'servico' })).filter((p) => p.nome) }
}
/** Situação real da Central de Marketing (ferramenta "central_marketing_resultados"): permissões, público e resultados. */
async function central(userId: number) {
  const M = await import('../lib/marketing.js'); const pl = await M.ownerPlan(userId)
  const camps = pl.business ? await q('SELECT nome, titulo, status, total, enviados, cliques, falhas, concluida_em FROM mkt_campaigns WHERE owner_id = $1 AND business_id = $2 ORDER BY id DESC LIMIT 5', [userId, pl.business.id]) : []
  const aut = Number((await q("SELECT COUNT(*) AS n FROM marketing_consents WHERE owner_id = $1 AND status = 'ativo'", [userId]))[0].n)
  return { podeUsar: !!pl.permissoes.podeUsar, permissoes: pl.permissoes, autorizados: aut, campanhas: camps.map((c: any) => ({ nome: c.nome || c.titulo, status: c.status, total: Number(c.total), enviados: Number(c.enviados), cliques: Number(c.cliques), falhas: Number(c.falhas || 0) })) }
}

/* ---------- memória do modo (por empresa): briefing, objetivo e entregas ---------- */
export async function memoria(userId: number, businessId: number): Promise<any> { return J<any>((await one("SELECT dados FROM modo_memoria WHERE user_id = $1 AND business_id = $2 AND modo = 'marketing'", [userId, businessId]))?.dados, {}) }
async function salvarMemoria(userId: number, businessId: number, dados: any) {
  const ex = await one("SELECT user_id FROM modo_memoria WHERE user_id = $1 AND business_id = $2 AND modo = 'marketing'", [userId, businessId])
  if (ex) await q("UPDATE modo_memoria SET dados = $1, atualizado_em = $2 WHERE user_id = $3 AND business_id = $4 AND modo = 'marketing'", [JSON.stringify(dados), nowIso(), userId, businessId])
  else await q("INSERT INTO modo_memoria (user_id, business_id, modo, dados, atualizado_em) VALUES ($1,$2,'marketing',$3,$4)", [userId, businessId, JSON.stringify(dados), nowIso()])
}

const PUBLICOS = ['todos', 'compradores', 'recentes', 'sem_compras']
/** Transforma os blocos de campanha em propostas guardadas e cartões no chat. */
async function extrairPropostas(c: ContextoExec, businessId: number, texto: string) {
  let n = 0
  const parse = (s: string) => { try { return JSON.parse(s) } catch { try { return JSON.parse(s.replace(/[“”]/g, '"').replace(/,\s*}/g, '}')) } catch { return null } } }
  let resto = texto, mt: RegExpExecArray | null; const re = /```\s*campanha\s*\n?([\s\S]*?)```/gi
  while ((mt = re.exec(texto))) {
    const p = parse(mt[1].trim()); let tok = ''
    if (p && n < 2) {
      const titulo = String(p.titulo || '').trim().slice(0, 80), mensagem = String(p.mensagem || '').trim().slice(0, 500)
      if (titulo.length >= 3 && mensagem.length >= 5) {
        const dados = { nome: String(p.nome || titulo).trim().slice(0, 60), titulo, mensagem, publico: PUBLICOS.includes(p.publico) ? p.publico : 'todos' }
        const r = await q("INSERT INTO modo_propostas (user_id, business_id, conversation_id, modo, tipo, dados, status, criado_em) VALUES ($1,$2,$3,'marketing','campanha',$4,'proposta',$5) RETURNING id", [c.u.id, businessId, c.conversationId, JSON.stringify(dados), nowIso()])
        tok = ` ⟦mkprop:${Number(r[0].id)}⟧`; n++
      }
    }
    resto = resto.replace(mt[0], tok ? '\n' + tok.trim() + '\n' : '')
  }
  return resto.replace(/\n{3,}/g, '\n\n').trim()
}
/* =====================================================================================================================
   DOSSIÊ DA EMPRESA — dados REAIS, somente leitura, de cada fonte oficial do sistema. Cada parte diz se está disponível e,
   se não estiver, o motivo (nada é simulado). Clientes entram só como contagens (nunca nomes ou contatos).
   Fontes: businesses (cadastro), products/product_variants (catálogo, ofertas e estoque), lib/bi.ts (vendas, pedidos,
   clientes, horários, visitas, CRM — a mesma fonte do Analista de negócio), ai/commercial.ts (clientes inativos e
   autorizados), coupons, cart_incentives, mkt_campaigns (Central de Marketing), reviews e modo_propostas.
   ===================================================================================================================== */
export interface Sinal { tipo: 'oportunidade' | 'alerta' | 'alta' | 'queda' | 'info'; texto: string; criterio: string }
export interface Dossie { empresaId: number; nome: string; texto: string; fontes: string[]; indisponivel: string[]; limitacoes: string[]; sinais: Sinal[]; resumo: Record<string, number | string | null> }
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) : 0)
const dtBR = (s: string | null | undefined) => (s ? new Date(s).toLocaleDateString('pt-BR') : '')
const LIMITACOES_FIXAS = [
  'Custo dos produtos/serviços: não é cadastrado no sistema — margem e lucro não podem ser calculados.',
  'Redes sociais: só os links cadastrados; seguidores, alcance e curtidas não estão integrados ao sistema.',
  'Perfil demográfico dos clientes (idade, renda, gênero): não é registrado; só há histórico de compras e o CRM.',
  'Visualizações por produto/serviço: não são registradas; "mais procurados" usa o que foi pedido/agendado.',
]
export async function dossie(userId: number, bid: number, tz = 'America/Sao_Paulo'): Promise<Dossie> {
  const fontes: string[] = [], indisp: string[] = [], sinais: Sinal[] = [], partes: string[] = [], resumo: Record<string, number | string | null> = {}
  const parte = async (nome: string, fn: () => Promise<string | null>) => {
    try { const t = await fn(); if (t) { partes.push(t); fontes.push(nome) } } catch (e: any) { indisp.push(`${nome}: não foi possível consultar agora (${String(e?.message || e).slice(0, 80)}).`) }
  }
  // 1. cadastro e posicionamento
  const b = await one('SELECT id, data FROM businesses WHERE id = $1 AND owner_id = $2', [bid, userId]); if (!b) throw new Error('empresa não encontrada para este usuário')
  const d = J<any>(b.data, {}), nome = String(d.empresa || 'Sua empresa'); resumo.empresa = nome
  await parte('Cadastro da empresa', async () => {
    const e = d.entrega || {}, pg = d.pagamento || {}
    const canais = Object.entries({ Instagram: d.insta && '@' + String(d.insta).replace(/^@/, ''), WhatsApp: d.zap, Site: d.link, Facebook: d.facebook, TikTok: d.tiktok, YouTube: d.youtube }).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`)
    resumo.canais = canais.length
    if (!d.insta) sinais.push({ tipo: 'oportunidade', texto: 'Não há Instagram cadastrado no perfil da empresa.', criterio: 'Campo Instagram vazio no cadastro' })
    return ['CADASTRO E POSICIONAMENTO', `Empresa: ${nome}${d.categoria ? ' · segmento: ' + d.categoria : ''} · vende ${d.tipo === 'servicos' ? 'serviços' : 'produtos'}`,
      `Descrição: ${[d.titulo, d.texto, d.sobre].filter(Boolean).join(' — ').slice(0, 600) || '(não cadastrada)'}`, `Local: ${d.endereco || d.cidade || '(não informado)'}`,
      `Atendimento: ${e.entrega ? `entrega até ${e.raio || '?'} km${e.taxa != null ? ' (taxa ' + brl(e.taxa) + ')' : ''}` : 'sem entrega'}${e.retirada ? ' · retirada' : ''} · pagamento: ${['pix', 'dinheiro', 'cartao', 'online'].filter((k) => pg[k]).join(', ') || '(não informado)'}`,
      `Público-alvo cadastrado: ${d.publicoAlvo || d.publico || '(não cadastrado)'}`, `Canais cadastrados: ${canais.join(' · ') || 'nenhum'}`].join('\n')
  })
  // 2. catálogo, ofertas e estoque
  await parte('Catálogo (produtos, preços, ofertas e estoque)', async () => {
    const { precos } = await import('../lib/catalogo.js')
    const ps = await q('SELECT id, data, active, stock FROM products WHERE business_id = $1 ORDER BY id', [bid]) as any[]
    const vs = await q('SELECT product_id, stock FROM product_variants WHERE business_id = $1', [bid]) as any[]
    const estoqueVar = new Map<number, number | null>(); for (const v of vs) { const k = Number(v.product_id), s = v.stock == null ? null : Number(v.stock); estoqueVar.set(k, s == null ? (estoqueVar.get(k) ?? null) : (estoqueVar.get(k) || 0) + s) }
    const itens = ps.map((p) => { const x = J<any>(p.data, {}), pr = precos(Number(x.preco) || 0, x.tipo === 'servico' ? null : x.oferta), est = estoqueVar.has(Number(p.id)) ? estoqueVar.get(Number(p.id))! : p.stock == null ? null : Number(p.stock)
      return { nome: String(x.nome || ''), ativo: p.active === true || p.active === 1 || p.active === '1' || p.active === 't', servico: x.tipo === 'servico', categoria: String(x.categoria || ''), preco: pr.normal, aplicado: pr.aplicado, oferta: pr.emOferta, desconto: pr.desconto, estoque: est, foto: Array.isArray(x.fotos) ? x.fotos.length > 0 : !!x.foto } }).filter((i) => i.nome)
    const at = itens.filter((i) => i.ativo); resumo.itens = at.length; resumo.ofertas = at.filter((i) => i.oferta).length
    if (!itens.length) { sinais.push({ tipo: 'alerta', texto: 'Nenhum produto ou serviço cadastrado no catálogo.', criterio: 'Tabela products sem itens desta empresa' }); return 'CATÁLOGO\nNenhum produto ou serviço cadastrado.' }
    const precosAt = at.map((i) => i.aplicado).filter((v) => v > 0), cats = [...new Set(at.map((i) => i.categoria).filter(Boolean))]
    const semFoto = at.filter((i) => !i.foto && !i.servico).length, esg = at.filter((i) => i.estoque === 0), baixo = at.filter((i) => i.estoque != null && i.estoque > 0 && i.estoque <= 5), controla = at.filter((i) => i.estoque != null).length
    if (at.length && !resumo.ofertas) sinais.push({ tipo: 'oportunidade', texto: 'Nenhum item do catálogo está com preço promocional ativo.', criterio: 'Nenhum produto com oferta ativa' })
    if (semFoto) sinais.push({ tipo: 'oportunidade', texto: `${semFoto} produto(s) ativo(s) sem foto.`, criterio: 'Produtos ativos sem imagem cadastrada' })
    if (esg.length) sinais.push({ tipo: 'alerta', texto: `${esg.length} item(ns) esgotado(s): ${esg.slice(0, 4).map((i) => i.nome).join(', ')}.`, criterio: 'Estoque controlado igual a zero' })
    if (baixo.length) sinais.push({ tipo: 'info', texto: `${baixo.length} item(ns) com estoque baixo (até 5): ${baixo.slice(0, 4).map((i) => `${i.nome} (${i.estoque})`).join(', ')}.`, criterio: 'Estoque controlado entre 1 e 5' })
    const linha = (i: typeof itens[number]) => `- ${i.nome}${i.servico ? ' [serviço]' : ''}${i.categoria ? ' (' + i.categoria + ')' : ''}: ${i.oferta ? `${brl(i.aplicado)} em oferta (normal ${brl(i.preco)}, -${i.desconto}%)` : brl(i.preco)}${i.estoque != null ? ` · estoque ${i.estoque}` : ''}${i.ativo ? '' : ' · INATIVO'}`
    return [`CATÁLOGO: ${at.length} item(ns) ativo(s)${itens.length > at.length ? ` e ${itens.length - at.length} inativo(s)` : ''} · ${cats.length} categoria(s)${cats.length ? ': ' + cats.slice(0, 8).join(', ') : ''}`,
      precosAt.length ? `Faixa de preço: ${brl(Math.min(...precosAt))} a ${brl(Math.max(...precosAt))} · preço médio ${brl(precosAt.reduce((a, v) => a + v, 0) / precosAt.length)}` : 'Sem preços cadastrados',
      `Em oferta: ${resumo.ofertas} · sem foto: ${semFoto} · controle de estoque em ${controla} item(ns)${esg.length ? ` · esgotados: ${esg.length}` : ''}`,
      ...itens.slice(0, 40).map(linha), itens.length > 40 ? `- (+${itens.length - 40} itens não listados)` : ''].filter(Boolean).join('\n')
  })
  // 3. vendas, pedidos, clientes, horários e visitas (lib/bi.ts — mesma fonte do Analista de negócio)
  await parte('Vendas, pedidos, clientes e visitas', async () => {
    const B = await import('../lib/bi.js')
    const a: any = await B.analise(userId, bid, { periodo: 'ultimos_30_dias' }, tz), ano: any = B.publico(await B.resumo(userId, bid, { periodo: 'ano' }, tz))
    const v = a.vendas, cl = a.clientes, ac = a.acessos
    resumo.pedidos30 = a.pedidos.total + a.agendamentos.total; resumo.faturamento30 = v.faturamento; resumo.clientes = cl.comPedidos
    for (const t of a.tendencias || []) sinais.push({ tipo: t.tipo, texto: t.texto + (t.sugestao ? ' Sugestão do sistema: ' + t.sugestao : ''), criterio: t.criterio })
    if (a.semMovimento && !(ano.pedidos.total + ano.agendamentos.total)) return 'VENDAS E PEDIDOS\nNenhum pedido nem agendamento registrado no sistema (nem nos últimos 30 dias, nem no ano). Não há histórico de vendas para analisar.'
    const top = (l: any[]) => l.map((p) => `${p.nome} (${p.qtd}× · ${brl(p.valor)})`).join(', ')
    return ['VENDAS E PEDIDOS (registros do sistema; faturamento = vendas pagas/concluídas)',
      `Últimos 30 dias (${a.periodo.de} a ${a.periodo.ate}): faturamento ${brl(v.faturamento)} · pendente ${brl(v.pendente)} · cancelado ${brl(v.cancelado)} · ${v.vendasPagas} venda(s) paga(s)${v.ticketMedio != null ? ' · ticket médio ' + brl(v.ticketMedio) : ''}`,
      `Pedidos: ${a.pedidos.total} (${a.pedidos.concluidos} concluídos, ${a.pedidos.pendentes} em aberto, ${a.pedidos.cancelados} cancelados) · agendamentos: ${a.agendamentos.total}`,
      `Período anterior (${a.comparativoBase.label}): faturamento ${brl(a.comparativoBase.faturamento)}`,
      `No ano: faturamento ${brl(ano.vendas.faturamento)} · ${ano.pedidos.total} pedido(s) · ${ano.agendamentos.total} agendamento(s)`,
      `Mais vendidos (30 dias): ${top(a.produtos.topProdutos) || '—'}${a.produtos.topServicos.length ? ' · serviços: ' + top(a.produtos.topServicos) : ''}`,
      `Mais vendidos (ano): ${top(ano.produtos.topProdutos) || '—'}`,
      a.horariosDeMovimento.length ? `Horários de mais pedidos (30 dias): ${a.horariosDeMovimento.map((h: any) => `${String(h.hora).padStart(2, '0')}h (${h.pedidos})`).join(', ')}` : '',
      a.melhorDia ? `Melhor dia (30 dias): ${dtBR(a.melhorDia.dia + 'T12:00:00')} com ${brl(a.melhorDia.faturamento)}` : '',
      `CLIENTES (histórico de pedidos): ${cl.comPedidos} cliente(s) já compraram · ${cl.ativosNoPeriodo} ativo(s) nos últimos 30 dias · ${cl.novos} novo(s) · ${cl.recorrentesTotal} compraram mais de uma vez (${pct(cl.recorrentesTotal, cl.comPedidos)}%)`,
      cl.crm?.disponivel ? `CRM: ${cl.crm.totalClientes} contato(s) · ${cl.crm.novosLeads} lead(s) novo(s) · ${cl.crm.leadsEmNegociacao} em negociação · ${cl.crm.oportunidadesAbertas} oportunidade(s) abertas (${brl(cl.crm.valorEmAberto || 0)})` : `CRM: ${cl.crm?.motivo || 'indisponível'}`,
      ac.disponivel ? `VISITAS À PÁGINA (30 dias): ${ac.visitas} visita(s) · ${ac.impressoes} impressão(ões) · ${ac.contatos} clique(s) em contato${ac.pedidosPorVisita != null ? ` · ${ac.pedidosPorVisita} pedido por visita` : ''}` : `VISITAS: ${ac.motivo}`,
      `Incentivos usados em pedidos (30 dias): cupons ${a.incentivos.cupons.usos}× (${brl(a.incentivos.cupons.desconto)} de desconto) · MCoins ${a.incentivos.mcoins.usos}×`].filter(Boolean).join('\n')
  })
  // 4. relacionamento: inativos, potenciais e autorizados a receber ofertas (ai/commercial.ts, só contagens)
  await parte('Relacionamento com clientes', async () => {
    const CM = await import('../ai/commercial.js'); const vc = await CM.visaoClientes(userId)
    if (!vc) return null
    resumo.inativos = vc.inativos; resumo.autorizados = vc.autorizados
    if (vc.inativos >= 3) sinais.push({ tipo: 'oportunidade', texto: `${vc.inativos} cliente(s) não compram há mais de ${CM.INATIVO_DIAS} dias.`, criterio: `Última compra válida há mais de ${CM.INATIVO_DIAS} dias` })
    if (!vc.autorizados) sinais.push({ tipo: 'alerta', texto: 'Nenhum cliente autorizou receber ofertas: campanhas pela Central de Marketing não teriam público.', criterio: 'marketing_consents ativos = 0' })
    return `RELACIONAMENTO (todas as empresas do proprietário): ${vc.novos} novo(s) · ${vc.recorrentes} ativo(s)/recorrente(s) · ${vc.inativos} inativo(s) (sem comprar há mais de ${CM.INATIVO_DIAS} dias) · ${vc.potenciais} potencial(is) (autorizaram ou clicaram e ainda não compraram) · ${vc.autorizados} autorizado(s) a receber ofertas`
  })
  // 5. cupons e incentivos do carrinho
  await parte('Cupons e incentivos', async () => {
    const cs = await q('SELECT name, code, purpose, kind, value, min_purchase, used_count, total_qty, status, starts_at, ends_at, created_at FROM coupons WHERE business_id = $1 ORDER BY id DESC LIMIT 20', [bid]) as any[]
    const I = await import('../lib/incentivos.js'), inc = await I.listar(bid), res = await I.resultados(bid)
    const agora = Date.now(), vig = (c: any) => c.status === 'ativo' && (!c.ends_at || Date.parse(c.ends_at) > agora) && (!c.starts_at || Date.parse(c.starts_at) <= agora)
    const ativos = cs.filter(vig); resumo.cuponsAtivos = ativos.length
    const parados = ativos.filter((c) => Number(c.used_count) === 0 && agora - Date.parse(c.created_at) > 14 * 86400_000)
    if (!ativos.length) sinais.push({ tipo: 'oportunidade', texto: 'Nenhum cupom de desconto ativo.', criterio: 'Nenhum cupom ativo e vigente' })
    if (parados.length) sinais.push({ tipo: 'alerta', texto: `${parados.length} cupom(ns) ativo(s) há mais de 14 dias sem nenhum uso: ${parados.map((c) => c.code).join(', ')}.`, criterio: 'Cupom ativo, criado há 14+ dias, 0 usos' })
    const incAt = inc.filter((i) => I.situacao(i) === 'ativo')
    const cup = cs.map((c) => `- ${c.code} (${c.name}${c.purpose ? ', finalidade: ' + c.purpose : ''}): ${c.kind === 'fixo' ? brl(Number(c.value)) : Number(c.value) + '%'} de desconto${Number(c.min_purchase) ? ' acima de ' + brl(Number(c.min_purchase)) : ''} · ${c.used_count} uso(s)${Number(c.total_qty) ? ' de ' + c.total_qty : ''} · ${vig(c) ? 'ativo' : c.status}${c.ends_at ? ' até ' + dtBR(c.ends_at) : ''}`)
    const ic = inc.map((i) => { const r = res.get(i.id); return `- ${i.nome}: ${I.textoBeneficio(i)} a partir de ${i.metaTipo === 'itens' ? i.meta + ' itens' : brl(i.meta)} · ${I.situacao(i)}${r ? ` · ${r.pedidos} pedido(s), ${brl(r.vendido)} vendidos` : ' · sem pedidos ainda'}` })
    return [`CUPONS: ${cs.length} cadastrado(s), ${ativos.length} ativo(s)`, ...cup, `INCENTIVOS DO CARRINHO: ${inc.length} cadastrado(s), ${incAt.length} ativo(s)`, ...ic].join('\n')
  })
  // 6. campanhas da Central de Marketing e propostas anteriores do consultor
  await parte('Campanhas (Central de Marketing)', async () => {
    const cen = await central(userId)
    const camps = await q('SELECT nome, titulo, status, total, enviados, cliques, falhas, criada_em, concluida_em FROM mkt_campaigns WHERE owner_id = $1 AND business_id = $2 ORDER BY id DESC LIMIT 8', [userId, bid]) as any[]
    const props = await q("SELECT dados, status, criado_em FROM modo_propostas WHERE user_id = $1 AND business_id = $2 AND modo = 'marketing' ORDER BY id DESC LIMIT 6", [userId, bid]) as any[]
    resumo.campanhas = camps.length
    for (const c of camps) if (Number(c.enviados) >= 10 && Number(c.cliques) === 0) sinais.push({ tipo: 'alerta', texto: `A campanha "${c.nome || c.titulo}" foi enviada a ${c.enviados} pessoa(s) e não teve cliques.`, criterio: 'Campanha concluída com 10+ envios e 0 cliques' })
    return [`CENTRAL DE MARKETING: ${cen.podeUsar ? `ativa · ${cen.autorizados} cliente(s) autorizaram receber ofertas` : `ainda NÃO pronta para envios (administrador: ${cen.permissoes.administrador ? 'ligada' : 'desligada'}; empresa ativou: ${cen.permissoes.empresa ? 'sim' : 'não'})`}`,
      camps.length ? camps.map((c) => `- ${c.nome || c.titulo} (${dtBR(c.concluida_em || c.criada_em)}): ${c.status} · ${c.enviados}/${c.total} enviadas · ${c.cliques} clique(s)${Number(c.falhas) ? ` · ${c.falhas} falha(s)` : ''}${Number(c.enviados) ? ` · taxa de clique ${pct(Number(c.cliques), Number(c.enviados))}%` : ''}`).join('\n') : '- nenhuma campanha criada ainda',
      props.length ? 'Propostas anteriores do consultor: ' + props.map((p) => { const x = J<any>(p.dados, {}); return `"${x.titulo}" (${p.status === 'na_central' ? 'levada para a Central' : 'só proposta'})` }).join('; ') : ''].filter(Boolean).join('\n')
  })
  // 7. avaliações dos clientes
  await parte('Avaliações', async () => {
    const rs = await q("SELECT rating, comment, created_at FROM reviews WHERE business_id = $1 AND origem = 'cliente' ORDER BY id DESC LIMIT 200", [bid]) as any[]
    resumo.avaliacoes = rs.length
    if (!rs.length) { sinais.push({ tipo: 'oportunidade', texto: 'A empresa ainda não tem avaliações de clientes.', criterio: 'Nenhuma avaliação de cliente' }); return 'AVALIAÇÕES: nenhuma avaliação de cliente ainda.' }
    const media = rs.reduce((a, r) => a + Number(r.rating), 0) / rs.length; resumo.notaMedia = Math.round(media * 10) / 10
    if (rs.length >= 3 && media < 4) sinais.push({ tipo: 'alerta', texto: `Nota média das avaliações é ${media.toFixed(1).replace('.', ',')} em ${rs.length} avaliações.`, criterio: 'Média abaixo de 4 com 3+ avaliações' })
    const coment = rs.filter((r) => String(r.comment || '').trim()).slice(0, 5).map((r) => `- ${r.rating}★: "${String(r.comment).replace(/\s+/g, ' ').slice(0, 140)}"`)
    return [`AVALIAÇÕES: ${rs.length} de clientes · média ${media.toFixed(1).replace('.', ',')} de 5 · notas: ${[5, 4, 3, 2, 1].map((n) => `${n}★ ${rs.filter((r) => Number(r.rating) === n).length}`).join(', ')}`, ...coment].join('\n')
  })
  const limitacoes = [...LIMITACOES_FIXAS, ...indisp]
  const texto = [...partes, 'SINAIS CALCULADOS PELO SISTEMA (cada um com o critério usado):\n' + (sinais.length ? sinais.map((s) => `- [${s.tipo}] ${s.texto} (critério: ${s.criterio})`).join('\n') : '- nenhum sinal relevante'), 'O QUE NÃO ESTÁ DISPONÍVEL (não estime, não simule):\n' + limitacoes.map((l) => '- ' + l).join('\n')].join('\n\n')
  return { empresaId: bid, nome, texto, fontes, indisponivel: indisp, limitacoes, sinais, resumo }
}

/* =====================================================================================================================
   MEMÓRIA ESTRATÉGICA (modo_memoria, por empresa): objetivos, fatos informados pelo proprietário, decisões, planos e o
   que ficou em aberto. Gravada de duas formas: (1) o bloco ```memoria``` que o consultor emite (validado aqui) e
   (2) regras determinísticas (plano entregue, aprovação ou descarte pelo proprietário), que valem mesmo se a IA falhar.
   ===================================================================================================================== */
type Plano = { id: string; titulo: string; objetivo: string; resumo: string; status: 'proposto' | 'aprovado' | 'em_andamento' | 'concluido' | 'descartado'; em: string; atualizadoEm: string }
const STATUS_PLANO = ['proposto', 'aprovado', 'em_andamento', 'concluido', 'descartado']
const curto = (v: unknown, n: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n)
const juntar = <T>(lista: T[] | undefined, novo: T, chave: (x: T) => string, max: number) => { const l = (lista || []).filter((x) => chave(x) !== chave(novo)); l.push(novo); return l.slice(-max) }
function memoriaTexto(m: any): string {
  const linhas: string[] = []
  const ob = (m.objetivos || []).map((o: any) => (typeof o === 'string' ? o : o.texto)).slice(-4); if (ob.length) linhas.push('Objetivos definidos: ' + ob.join('; '))
  const br = Object.entries(m.briefing || {}).filter(([, v]: any) => v?.valor && v.valor !== 'não informado').map(([k, v]: any) => `${k.replace(/_/g, ' ')}: ${v.valor}`)
  const fatos = [...br, ...(m.fatos || []).map((f: any) => f.texto)].slice(-10); if (fatos.length) linhas.push('O proprietário já informou:\n' + fatos.map((f) => '- ' + f).join('\n'))
  const dec = (m.decisoes || []).slice(-6); if (dec.length) linhas.push('Decisões tomadas:\n' + dec.map((x: any) => `- ${x.em?.slice(0, 10)}: ${x.texto}`).join('\n'))
  const pl = (m.planos || []).slice(-5); if (pl.length) linhas.push('Planos construídos:\n' + pl.map((p: Plano) => `- "${p.titulo}" [${p.status}] (${p.em.slice(0, 10)})${p.objetivo ? ' · objetivo: ' + p.objetivo : ''}${p.resumo ? ' · ' + p.resumo : ''}`).join('\n'))
  const ab = (m.perguntasAbertas || []).slice(-3); if (ab.length) linhas.push('Ficou em aberto: ' + ab.join('; '))
  return linhas.join('\n') || '(nenhuma estratégia construída ainda com esta empresa)'
}
/** Extrai e aplica o bloco ```memoria``` (JSON) da resposta; devolve o texto sem o bloco. */
function aplicarBlocoMemoria(texto: string, m: any, conversa: string): { texto: string; aplicou: string[] } {
  const aplicou: string[] = []; const agora = nowIso()
  const re = /```\s*memoria\s*\n?([\s\S]*?)```/gi; let mt: RegExpExecArray | null; let out = texto
  while ((mt = re.exec(texto))) {
    out = out.replace(mt[0], '')
    let j: any = null; try { j = JSON.parse(mt[1].trim()) } catch { try { j = JSON.parse(mt[1].trim().replace(/[“”]/g, '"').replace(/,\s*([}\]])/g, '$1')) } catch { continue } }
    if (!j || typeof j !== 'object') continue
    if (j.objetivo && curto(j.objetivo, 120).length >= 4) { m.objetivos = juntar(m.objetivos, { texto: curto(j.objetivo, 120), em: agora } as any, (x: any) => nrm(typeof x === 'string' ? x : x.texto), 8); aplicou.push('objetivo') }
    for (const f of (Array.isArray(j.fatos) ? j.fatos : j.fato ? [j.fato] : []).slice(0, 4)) { const t = curto(typeof f === 'string' ? f : f?.valor ? `${f.campo || ''}: ${f.valor}` : '', 200); if (t.length >= 4) { m.fatos = juntar(m.fatos, { texto: t, em: agora }, (x: any) => nrm(x.texto), 20); aplicou.push('fato') } }
    for (const dz of (Array.isArray(j.decisoes) ? j.decisoes : j.decisao ? [j.decisao] : []).slice(0, 3)) { const t = curto(dz, 200); if (t.length >= 4) { m.decisoes = juntar(m.decisoes, { texto: t, em: agora }, (x: any) => nrm(x.texto), 15); aplicou.push('decisao') } }
    if (j.plano && curto(j.plano.titulo, 90).length >= 3) { salvarPlano(m, { titulo: curto(j.plano.titulo, 90), objetivo: curto(j.plano.objetivo, 160), resumo: curto(j.plano.resumo, 300), status: STATUS_PLANO.includes(j.plano.status) ? j.plano.status : 'proposto' }, conversa); aplicou.push('plano') }
    if (j.atualizarPlano && j.atualizarPlano.titulo && STATUS_PLANO.includes(j.atualizarPlano.status)) { const p = (m.planos || []).find((x: Plano) => nrm(x.titulo) === nrm(j.atualizarPlano.titulo)); if (p) { p.status = j.atualizarPlano.status; p.atualizadoEm = agora; aplicou.push('status_plano') } }
    if (j.pergunta) { m.perguntasAbertas = [...(m.perguntasAbertas || []).filter((x: string) => nrm(x) !== nrm(j.pergunta)), curto(j.pergunta, 160)].slice(-3); aplicou.push('pergunta') }
    if (j.respondida) m.perguntasAbertas = (m.perguntasAbertas || []).filter((x: string) => !nrm(x).includes(nrm(String(j.respondida)).slice(0, 30)))
  }
  return { texto: out.replace(/\n{3,}/g, '\n\n').trim(), aplicou }
}
function salvarPlano(m: any, p: Pick<Plano, 'titulo' | 'objetivo' | 'resumo' | 'status'>, _conversa: string) {
  const agora = nowIso(), ex = (m.planos || []).find((x: Plano) => nrm(x.titulo) === nrm(p.titulo))
  if (ex) { Object.assign(ex, { ...p, objetivo: p.objetivo || ex.objetivo, resumo: p.resumo || ex.resumo, atualizadoEm: agora }); return ex }
  const novo: Plano = { id: 'pl' + Date.now().toString(36), ...p, em: agora, atualizadoEm: agora }
  m.planos = [...(m.planos || []), novo].slice(-12); return novo
}
const APROVA = /^(sim[,!. ]+)?(vamos (fazer|nessa|com (esse|este))|pode (seguir|ir|ser)|aprovad|aprovo|fechado|combinado|gostei|bora|vou (fazer|seguir|aplicar)|decidi|quero (seguir|fazer) (esse|este|com esse|com este)|ok,? vamos)/
const DESCARTA = /\b(descart\w*|esquece (esse|este|o) plano|n[aã]o (gostei|quero) (desse|deste|esse|este) plano|outra (ideia|estrat[eé]gia|abordagem))\b/
/** Regras que não dependem da IA: plano entregue vira "proposto"; aprovação/descarte do proprietário muda o status e vira decisão. */
function memoriaDeterministica(m: any, pedido: string, resposta: string, conversa: string, blocoTevePlano: boolean) {
  const t = nrm(pedido), agora = nowIso(), ult: Plano | undefined = [...(m.planos || [])].reverse().find((p: Plano) => p.status === 'proposto' || p.status === 'aprovado')
  if (ult && APROVA.test(t)) { if (ult.status === 'proposto') { ult.status = 'aprovado'; ult.atualizadoEm = agora } m.decisoes = juntar(m.decisoes, { texto: `Aprovou o plano "${ult.titulo}"`, em: agora }, (x: any) => nrm(x.texto), 15) }
  if (ult && DESCARTA.test(t)) { ult.status = 'descartado'; ult.atualizadoEm = agora; m.decisoes = juntar(m.decisoes, { texto: `Descartou o plano "${ult.titulo}"`, em: agora }, (x: any) => nrm(x.texto), 15) }
  if (!blocoTevePlano && /objetivo/i.test(resposta) && /pr[oó]ximos passos/i.test(resposta) && /indicadores/i.test(resposta)) {
    const linha = resposta.split('\n').find((l) => /^\W*objetivo\W*[:\-–]/i.test(nrm(l).replace(/\*/g, ''))) || ''
    const tit = curto(linha.replace(/\*+/g, '').replace(/^\W*objetivo\W*[:\-–]\s*/i, ''), 90) || curto(pedido, 90)
    salvarPlano(m, { titulo: tit, objetivo: tit, resumo: '', status: 'proposto' }, conversa)
  }
}

/* =====================================================================================================================
   CONFERÊNCIA DOS NÚMEROS — valores em R$ e percentuais da resposta precisam existir nos dados da empresa, no que o
   proprietário disse ou na memória; quando não existem e não estão marcados como hipótese/proposta, o proprietário é
   avisado no fim da resposta (não apagamos o texto: ele vê exatamente o que não foi confirmado).
   ===================================================================================================================== */
const num = (s: string) => Number(s.replace(/[^\d,.-]/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.'))
const HIPOTESE = /(meta|hip[oó]tese|exemplo|ex\.|sugest|premissa|estimativ|simula|cen[aá]rio|teste|or[cç]amento|investimento|investir|desconto|cupom|off\b|promo|oferta|cashback|frete|brinde|combo|leve|pague|pre[cç]o promocional|at[eé] R\$|por dia|por m[eê]s|por semana|limite|teto|m[ií]nimo|pedido m[ií]nimo|acima de|a partir de)/i
export function numerosNaoConfirmados(resposta: string, permitido: string): string[] {
  const base = new Set<string>(), percBase: number[] = []
  for (const m of permitido.matchAll(/R\$\s?\d[\d.]*(?:,\d{1,2})?/g)) base.add(num(m[0]).toFixed(2))
  for (const m of permitido.matchAll(/\d[\d.]*(?:,\d+)?/g)) { const v = num(m[0]); if (Number.isFinite(v)) { base.add(v.toFixed(2)); percBase.push(v) } }
  const out: string[] = []
  const frases = resposta.replace(/⟦[^⟧]*⟧/g, '').split(/(?<=[.!?\n])\s+/)
  for (const f of frases) {
    if (HIPOTESE.test(f)) continue
    for (const m of f.matchAll(/R\$\s?\d[\d.]*(?:,\d{1,2})?/g)) { const v = num(m[0]); if (!base.has(v.toFixed(2))) out.push(m[0].trim()) }
    for (const m of f.matchAll(/(\d+(?:[.,]\d+)?)\s?%/g)) { const v = num(m[1]); if (!percBase.some((x) => Math.abs(x - v) <= 1)) out.push(m[0].trim()) }
  }
  return [...new Set(out)].slice(0, 8)
}

/* =====================================================================================================================
   CONSULTOR (IA com o dossiê, a memória estratégica e o conhecimento do Cérebro). Sem menus nem questionário: a IA lê o
   pedido em linguagem natural, analisa os dados, pergunta só o que muda a estratégia e constrói o plano aos poucos.
   ===================================================================================================================== */
function sistema(dz: Dossie, memoriaTxt: string, conhecimento: string, cen: Awaited<ReturnType<typeof central>>, HONESTIDADE: string) {
  return [
    'MODO: CONSULTOR DE MARKETING (Meu Assistente). Você é um estrategista de negócios e marketing para pequenas empresas brasileiras, trabalhando EM CONJUNTO com o proprietário: especialista em marketing digital, estratégia comercial, posicionamento de marca, vendas e conversão, conteúdo e redes sociais, campanhas promocionais, fidelização, precificação estratégica e crescimento.',
    'COMO CONVERSAR: entenda o pedido escrito livremente e responda a ele — sem menus, sem etapas obrigatórias, sem questionário. Analise primeiro os DADOS DA EMPRESA abaixo e mostre o raciocínio (o que os dados mostram → o que isso significa → o que fazer). Quando o proprietário só cita um objetivo, NÃO entregue de cara uma campanha genérica: mostre o cenário, as oportunidades e as opções, e combine o caminho. Faça no máximo UMA pergunta por resposta, e só quando a resposta realmente mudar a estratégia (diga por que precisa dela); se der para avançar com o que existe, avance e deixe a premissa explícita. Aceite discordância, reconsidere e ajuste o plano. Retome o que já foi construído (MEMÓRIA ESTRATÉGICA) em vez de recomeçar.',
    'REGRAS DE DADOS (obrigatórias): use SOMENTE números que aparecem nos DADOS DA EMPRESA, no que o proprietário disse ou na memória, citando a origem e o período (ex.: "nos últimos 30 dias o sistema registrou…"). NUNCA invente ou estime vendas, faturamento, margens, lucros, taxas de conversão, métricas de redes sociais, tamanho de mercado ou comportamento de clientes individuais. Se um dado não existe (veja "O QUE NÃO ESTÁ DISPONÍVEL"), diga que não existe e, se fizer diferença, como obtê-lo. Metas e custos só como hipótese marcada ("meta sugerida", "premissa:") e com a base explicada; sem base, escreva "sem base para estimar".',
    'QUANDO PEDIREM UMA ESTRATÉGIA, CAMPANHA OU PLANO, entregue com estas seções, cada uma numa linha começando pelo nome seguido de dois-pontos: Objetivo · Oportunidade identificada · Dados que sustentam · Público-alvo sugerido (e por quê) · Produtos ou serviços envolvidos · Estratégia de execução · Conteúdo e comunicação · Canais · Custos estimados (só com premissas claras) · Indicadores para acompanhar (que o sistema mede: pedidos, faturamento, cliques da Central, usos de cupom, visitas) · Próximos passos.',
    HONESTIDADE,
    'CENTRAL DE MARKETING: quando propuser uma campanha para os clientes do app, inclua no máximo 2 blocos exatamente neste formato (o app transforma em um cartão que o proprietário revisa e leva para a Central como rascunho; nada é enviado sem ele):\n```campanha\n{"nome":"nome interno curto","titulo":"título da notificação (até 80 caracteres)","mensagem":"texto da notificação (até 300 caracteres)","publico":"todos|compradores|recentes|sem_compras"}\n```',
    cen.podeUsar ? '' : 'A Central ainda não está pronta para envios: se propuser campanha, explique que o rascunho fica guardado e que é preciso ativar em Sua empresa → Central de Marketing.',
    'MEMÓRIA: no FIM da resposta, se algo importante foi definido, inclua UM bloco (o proprietário não vê; o sistema guarda para as próximas conversas) só com os campos que mudaram:\n```memoria\n{"objetivo":"objetivo combinado","fatos":["informação nova dada pelo proprietário"],"decisoes":["decisão tomada"],"plano":{"titulo":"nome curto do plano","objetivo":"…","resumo":"1 frase","status":"proposto|aprovado|em_andamento|concluido|descartado"},"atualizarPlano":{"titulo":"plano existente","status":"…"},"pergunta":"pergunta que ficou em aberto","respondida":"pergunta em aberto que foi respondida"}\n```',
    `DADOS DA EMPRESA (consultados agora no sistema):\n${dz.texto}`,
    `MEMÓRIA ESTRATÉGICA (conversas anteriores com ${dz.nome}):\n${memoriaTxt}`,
    conhecimento ? `CONHECIMENTO DO CÉREBRO (boas práticas e conhecimentos cadastrados; cite a fonte [C…] quando usar a biblioteca):\n${conhecimento}` : '',
    'FORMATO: português do Brasil, direto. O chat mostra TEXTO PURO: não use markdown (nada de **, # ou _); títulos como "Objetivo:" no início da linha e listas com "•". Explique o porquê de cada recomendação com os dados. Termine com o próximo passo concreto ou com a única pergunta necessária.',
  ].filter(Boolean).join('\n\n')
}
/** Análise com os dados reais quando nenhuma IA está disponível (o modo nunca simula: mostra os sinais calculados). */
function analiseSemIA(dz: Dossie, texto: string, m: any) {
  const ops = dz.sinais.filter((s) => s.tipo === 'oportunidade' || s.tipo === 'alerta' || s.tipo === 'queda').slice(0, 6), info = dz.sinais.filter((s) => s.tipo === 'alta' || s.tipo === 'info').slice(0, 3)
  const linhas = [`**Análise da ${dz.nome} com os dados do sistema**`, '', `Consultei: ${dz.fontes.join(', ')}.`]
  if (ops.length) linhas.push('', '**Oportunidades e pontos de atenção**', ...ops.map((s, i) => `${i + 1}. ${s.texto} _(critério: ${s.criterio})_`))
  else linhas.push('', 'Os dados não mostram nenhum ponto de atenção pelos critérios do sistema.')
  if (info.length) linhas.push('', '**Também vale saber**', ...info.map((s) => `- ${s.texto}`))
  const pl = (m.planos || []).filter((p: Plano) => p.status !== 'descartado').slice(-1)[0]; if (pl) linhas.push('', `Plano em andamento: **${pl.titulo}** (${pl.status}).`)
  if (/plano|estrat|campanha/.test(nrm(texto)) && ops[0]) linhas.push('', '**Ponto de partida sugerido**', `- Objetivo: tratar "${ops[0].texto}"`, `- Dados que sustentam: ${ops[0].criterio}`, '- Custos estimados: sem base para estimar', '- Indicadores: pedidos, faturamento e usos de cupom no próprio app', '- Próximos passos: confirme se quer seguir por aqui para eu detalhar o plano completo')
  linhas.push('', `_O que não está disponível: ${dz.limitacoes.slice(0, 2).map((l) => l.split(':')[0]).join(' e ')}._`, '', '_A inteligência artificial está indisponível agora: esta análise usa só as regras do sistema. Tente de novo para uma conversa completa._')
  return linhas.join('\n')
}
async function consultar(c: ContextoExec): Promise<{ resposta: Resposta; meta: any; rastro: any }> {
  const bid = c.acesso.businessId!, { settingsOf } = await import('../lib/account.js'), tz = settingsOf(c.u).timezone || 'America/Sao_Paulo'
  const [dz, m, cen] = await Promise.all([dossie(c.u.id, bid, tz), memoria(c.u.id, bid), central(c.u.id)])
  const CM = await import('../ai/commercial.js'), INT = await import('../ai/cerebro/integracao.js'), K = await import('../ai/knowledge.js')
  // Cérebro do chat: boas práticas comerciais (playbook) + conhecimentos cadastrados pelo administrador + biblioteca geral
  const pb = CM.playbookFor(c.texto + ' marketing clientes vendas')
  const kn = await K.answerKnowledge(c.texto, c.u.id, 0.55, { canal: 'chat' }).catch(() => null)
  const rastro = await INT.recuperar(c.texto, { canal: 'chat', userId: c.u.id, pesquisar: false }).catch(() => INT.rastroDireto(c.texto, 'chat', c.u.id, 'falha_consulta'))
  const conhecimento = [pb, kn ? `Conhecimento cadastrado no Cérebro ("${kn.titulo}"): ${kn.resposta}` : '', rastro?.contexto || ''].filter(Boolean).join('\n\n')
  const memTxt = memoriaTexto(m), sys = sistema(dz, memTxt, conhecimento, cen, CM.HONESTIDADE)
  const hist = c.historico.slice(-12).map((h: any) => ({ role: h.role === 'assistant' ? 'assistant' : 'user', content: String(h.content || '').replace(/⟦[^⟧]*⟧/g, '').trim() })).filter((h) => h.content) as any[]
  let txt = '', provedor = '', semIA = false
  try {
    const E = await import('../ai/engine.js'); const r = await E.run([{ role: 'system', content: sys }, ...hist, { role: 'user', content: c.texto }] as any, { task: 'analise', temperature: 0.5 } as any)
    txt = String(r.message?.content || '').trim(); provedor = r.provider?.nome || r.provider?.id || ''
    for (const a of r.attempts || []) if (!a.ok) rastro.falhas.push(`IA ${a.nome || a.id}: ${a.msg || a.kind || 'falhou'}`)
  } catch (e: any) { console.error('[modo marketing] IA indisponível:', e?.message); rastro.falhas.push('IA indisponível: ' + String(e?.message || e).slice(0, 120)) }
  if (!txt) { txt = analiseSemIA(dz, c.texto, m); semIA = true } else { rastro.provedor = provedor; rastro.enviadoIA = true }
  // memória estratégica: bloco da IA + regras determinísticas
  const bm = aplicarBlocoMemoria(txt, m, c.conversationId); txt = bm.texto
  memoriaDeterministica(m, c.texto, txt, c.conversationId, bm.aplicou.includes('plano'))
  txt = await extrairPropostas(c, bid, txt)
  txt = CM.guardExternalClaims(txt)
  // conferência dos números contra os dados reais, o que o proprietário disse e a memória
  const permitido = [dz.texto, memTxt, c.texto, ...c.historico.filter((h: any) => h.role === 'user').map((h: any) => String(h.content || ''))].join('\n')
  const soltos = semIA ? [] : numerosNaoConfirmados(txt, permitido)
  if (soltos.length) txt += `\n\n⚠️ Conferência dos dados: ${soltos.join(', ')} não aparece${soltos.length > 1 ? 'm' : ''} nos registros da ${dz.nome} nem na nossa conversa. Trate como hipótese a validar, não como resultado real.`
  m.entregas = [...(m.entregas || []), { em: nowIso(), pedido: c.texto.slice(0, 120) }].slice(-10)
  await salvarMemoria(c.u.id, bid, m)
  const meta = { modo: 'marketing', fontes: dz.fontes, indisponivel: dz.indisponivel, sinais: dz.sinais.length, memoria: bm.aplicou, numerosNaoConfirmados: soltos, semIA, conhecimento: kn ? kn.ids : [] }
  return { resposta: { content: textoLimpo(txt) + chipsSeguir(m), cards: [] }, meta, rastro }
}
/** O chat mostra texto puro (sem markdown): tira **negrito**, _itálico_ e # títulos e usa • nas listas — mesma regra do
 *  "copiar" do app. Blocos ``` e marcadores ⟦…⟧ ficam intactos. */
export function textoLimpo(t: string) {
  return String(t || '').replace(/\r\n?/g, '\n').split(/(```[\s\S]*?(?:```|$))/).map((s, i) => i % 2 === 1 ? s : s
    .replace(/\*\*(.+?)\*\*/g, '$1').replace(/__(.+?)__/g, '$1').replace(/(^|[\s(])_([^_\n]+?)_(?=[\s).,;:!?]|$)/gm, '$1$2')
    .replace(/^#{1,6}\s+/gm, '').replace(/^(\s*)[*-]\s+/gm, '$1• ').replace(/^>\s?/gm, '')).join('')
}
/** Respostas rápidas OPCIONAIS (o proprietário pode escrever o que quiser). */
const opc = (itens: [string, string][]) => itens.length ? ` ⟦opc:${itens.map(([l, t]) => `${l.replace(/[;=⟧]/g, '')}=${t.replace(/[;=⟧]/g, '')}`).join(';')}⟧` : ''
function chipsSeguir(m: any) {
  const pl = (m.planos || []).filter((p: Plano) => p.status === 'proposto' || p.status === 'aprovado').slice(-1)[0]
  return opc([...(pl ? [['Detalhar os próximos passos', `Detalhe os próximos passos do plano "${pl.titulo}"`] as [string, string]] : []), ['Quais oportunidades você vê?', 'Quais oportunidades você identifica na minha empresa?'], ['Montar um plano', 'Monte um plano de ação com base nos dados da empresa'], ['Criar conteúdo', 'Crie conteúdos para divulgar os produtos que mais vendem']])
}

/* ---------- o modo ---------- */
export const consultorMarketing: Modo = {
  id: 'marketing', nome: 'Consultor de Marketing', descricao: 'Estrategista que analisa os dados reais da sua empresa, propõe e constrói o plano com você.', icone: 'megafone', exclusivo: 'Anúncio completo da empresa',
  ferramentas: ['dados_empresa', 'catalogo', 'vendas_bi', 'clientes_agregados', 'cupons_incentivos', 'avaliacoes', 'central_marketing_resultados', 'proposta_campanha', 'memoria_estrategica', 'cerebro'],
  acesso: (u) => acessoCompleto(u.id),
  async iniciar(c) {
    const bid = c.acesso.businessId!, { settingsOf } = await import('../lib/account.js')
    const [dz, m] = await Promise.all([dossie(c.u.id, bid, settingsOf(c.u).timezone || 'America/Sao_Paulo'), memoria(c.u.id, bid)])
    const r = dz.resumo, num = (v: any) => Number(v || 0)
    const tem = [r.itens != null && `${r.itens} item(ns) no catálogo${num(r.ofertas) ? ` (${r.ofertas} em oferta)` : ''}`, r.pedidos30 != null && `${r.pedidos30} pedido(s)/agendamento(s) nos últimos 30 dias${num(r.faturamento30) ? ` (${brl(num(r.faturamento30))} faturados)` : ''}`, r.clientes != null && `${r.clientes} cliente(s) com compras`, r.cuponsAtivos != null && `${r.cuponsAtivos} cupom(ns) ativo(s)`, r.avaliacoes != null && (num(r.avaliacoes) ? `${r.avaliacoes} avaliação(ões), média ${String(r.notaMedia).replace('.', ',')}` : 'nenhuma avaliação ainda'), r.campanhas != null && `${r.campanhas} campanha(s) na Central`].filter(Boolean)
    const pl = (m.planos || []).filter((p: Plano) => p.status !== 'descartado' && p.status !== 'concluido').slice(-1)[0], dec = (m.decisoes || []).slice(-1)[0]
    const txt = [`⚡ **Consultor de Marketing** ativado para a **${dz.nome}**.`, '', `Acabei de consultar os dados da empresa no sistema: ${tem.join(' · ')}.`,
      `_Não tenho acesso a: custo dos produtos (margem), métricas das redes sociais e perfil demográfico dos clientes — não vou estimar isso._`,
      pl ? `\nDa última vez construímos o plano **${pl.titulo}** (${pl.status === 'proposto' ? 'proposto' : pl.status === 'aprovado' ? 'aprovado' : 'em andamento'})${dec ? `; decisão mais recente: ${dec.texto}` : ''}. Podemos continuar de onde paramos.` : '',
      '', 'Pode me perguntar o que quiser, do seu jeito — por exemplo, "quais oportunidades você vê na minha empresa?" ou "como vender mais o produto X?".'].filter((x) => x !== '').join('\n')
    const chips: [string, string][] = [...(pl ? [[`Continuar: ${pl.titulo}`, `Vamos continuar o plano "${pl.titulo}"`] as [string, string]] : []), ['Quais oportunidades você vê?', 'Quais oportunidades você identifica na minha empresa?'], ['Analise minhas vendas', 'Analise minhas vendas e clientes e me diga o que está funcionando'], ['Montar um plano', 'Monte um plano de ação com base nos dados da empresa']]
    return { resposta: { content: textoLimpo(txt) + opc(chips), cards: [] }, estado: { etapa: 'consultoria' } }
  },
  async responder(c) {
    // conversa livre: todo pedido vai para a consultoria (estados antigos "objetivo"/"coleta" também)
    const r = await consultar(c)
    return { resposta: { ...r.resposta, meta: r.meta, rastro: r.rastro } as any, estado: { etapa: 'consultoria' } }
  },
}
/** Proposta de campanha → rascunho na Central de Marketing (só por ação do responsável; nada é programado ou enviado). */
export async function levarParaCentral(userId: number, propostaId: number) {
  const { fail } = await import('../lib/http.js')
  const ac = await acessoCompleto(userId); if (!ac.liberado) fail(403, ac.mensagem, 'modo_bloqueado')
  const p = await one("SELECT * FROM modo_propostas WHERE id = $1 AND user_id = $2 AND tipo = 'campanha'", [propostaId, userId]); if (!p) return fail(404, 'Proposta não encontrada.', 'not_found')
  if (p.status === 'na_central' && p.campaign_id && await one('SELECT id FROM mkt_campaigns WHERE id = $1 AND owner_id = $2', [p.campaign_id, userId])) return { ok: true, campanhaId: Number(p.campaign_id), jaEstava: true }
  const d = J<any>(p.dados, {}), M = await import('../lib/marketing.js')
  const c: any = await M.salvarCampanha(userId, { rascunho: true, nome: d.nome, titulo: d.titulo, mensagem: d.mensagem, segmento: { tipo: d.publico || 'todos' } })
  await q("UPDATE modo_propostas SET status = 'na_central', campaign_id = $1 WHERE id = $2", [Number(c.id), propostaId])
  return { ok: true, campanhaId: Number(c.id) }
}
export async function propostaDe(userId: number, id: number) {
  const ac = await acessoCompleto(userId); const p = await one('SELECT * FROM modo_propostas WHERE id = $1 AND user_id = $2', [id, userId])
  if (!p) return null
  const d = J<any>(p.dados, {}); let campanha: any = null
  if (p.campaign_id) { const c = await one('SELECT id, status FROM mkt_campaigns WHERE id = $1 AND owner_id = $2', [p.campaign_id, userId]); if (c) campanha = { id: Number(c.id), status: c.status } }
  return { id: Number(p.id), tipo: p.tipo, ...d, status: p.status, campanha, liberado: ac.liberado }
}
