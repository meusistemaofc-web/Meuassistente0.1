// Modo Consultor de Marketing: consultor especializado que conhece o negócio (cadastro, catálogo, Central de Marketing),
// pergunta só o que falta (uma pergunta por vez), e entrega diagnóstico, estratégias, planos e conteúdos com os dados
// reais da empresa. Propostas de campanha viram rascunho na Central de Marketing SÓ com a ação do responsável.
// Benefício exclusivo do anúncio completo da empresa (plano de nível 4 ativo), conferido no servidor a cada mensagem.
import { q, one, J, nowIso } from '../db/index.js'
import type { Modo, Acesso, ContextoExec, EstadoModo, Resposta } from './tipos.js'

const NIVEL_COMPLETO = 4
const VALIDADE_DIAS = 120 // respostas do briefing valem por 4 meses; depois o consultor confirma de novo
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()
const brl = (v: number) => 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')

/* ---------- acesso premium (reutiliza a contratação existente: tabela businesses + planos do anúncio) ---------- */
export async function acessoCompleto(userId: number): Promise<Acesso> {
  const { plans } = await import('../routes/ads.js')
  const ps: any[] = await plans(), nivel = (b: any) => Number(ps.find((p) => p.id === b.plan_id)?.nivel) || 0
  const nomePlano = (b: any) => ps.find((p) => p.id === b.plan_id)?.nome || 'atual'
  const completo = ps.filter((p) => Number(p.nivel) >= NIVEL_COMPLETO).map((p) => p.nome)[0] || 'Loja completa'
  const bs = await q("SELECT id, status, plan_id, expires_at FROM businesses WHERE owner_id = $1 AND status <> 'institucional' ORDER BY id DESC", [userId])
  const base = `O Consultor de Marketing é um benefício exclusivo do anúncio completo da empresa (plano ${completo}).`
  if (!bs.length) return { liberado: false, codigo: 'sem_empresa', mensagem: `${base} Você ainda não tem um anúncio contratado.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/anunciar' } }
  const vigente = (b: any) => b.status === 'ativo' && (!b.expires_at || Date.parse(b.expires_at) > Date.now())
  const ok = bs.find((b: any) => vigente(b) && nivel(b) >= NIVEL_COMPLETO)
  if (ok) return { liberado: true, codigo: 'ok', mensagem: 'Liberado pelo anúncio completo.', businessId: Number(ok.id) }
  const atual = bs.find(vigente)
  if (atual) return { liberado: false, codigo: 'plano_basico', mensagem: `${base} Seu anúncio está no plano ${nomePlano(atual)}. Ao mudar para o ${completo}, o acesso é liberado na hora.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/sua-empresa' } }
  const ult = bs[0]
  if (ult.status === 'ativo' || ult.status === 'encerrado') return { liberado: false, codigo: 'vencido', mensagem: `${base} A contratação do seu anúncio venceu. Ao renovar no plano ${completo}, o acesso volta na hora.`, acao: { rotulo: 'Renovar o anúncio', link: '/x/sua-empresa' } }
  if (['pagamento', 'analise', 'ajustes', 'aprovado'].includes(ult.status)) return { liberado: false, codigo: 'pendente', mensagem: `${base} Seu anúncio ainda não está no ar (aguardando ${ult.status === 'pagamento' ? 'pagamento' : 'aprovação'}). O acesso é liberado assim que ele for ativado no plano ${completo}.`, acao: { rotulo: 'Ver meu anúncio', link: '/x/sua-empresa' } }
  return { liberado: false, codigo: 'suspenso', mensagem: `${base} A contratação do seu anúncio está cancelada ou suspensa.`, acao: { rotulo: 'Conhecer o anúncio completo', link: '/x/sua-empresa' } }
}

/* ---------- dados reais da empresa ---------- */
interface Negocio { id: number; empresa: string; categoria: string; descricao: string; local: string; atendimento: string; instagram: string; whatsapp: string; site: string; publicoAlvo: string; tipo: string; itens: { nome: string; preco: number; categoria: string; servico: boolean }[]; horario: string }
export async function negocio(businessId: number): Promise<Negocio> {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [businessId]); const d = J<any>(b?.data, {})
  const prods = (await q('SELECT data FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 40', [businessId, true])).map((p: any) => J<any>(p.data, {}))
  const e = d.entrega || {}
  return { id: businessId, empresa: String(d.empresa || 'Sua empresa'), categoria: String(d.categoria || ''), descricao: [d.titulo, d.texto, d.sobre].filter(Boolean).join(' — ').slice(0, 600), local: String(d.endereco || d.cidade || ''),
    atendimento: e.entrega ? `entrega até ${e.raio || '?'} km${e.taxa != null ? ' (taxa ' + brl(e.taxa) + ')' : ''}${e.retirada ? ' e retirada' : ''}` : e.retirada ? 'somente retirada' : '', instagram: String(d.insta || '').replace(/^@/, ''), whatsapp: String(d.zap || ''), site: String(d.link || ''),
    publicoAlvo: String(d.publicoAlvo || d.publico || ''), tipo: d.tipo === 'servicos' ? 'serviços' : 'produtos', horario: typeof d.horario === 'string' ? d.horario : '',
    itens: prods.map((p: any) => ({ nome: String(p.nome || ''), preco: Number(p.preco) || 0, categoria: String(p.categoria || ''), servico: p.tipo === 'servico' })).filter((p) => p.nome) }
}
/** Situação real da Central de Marketing (ferramenta "central_marketing_resultados"): permissões, público e resultados. */
async function central(userId: number) {
  const M = await import('../lib/marketing.js'); const pl = await M.ownerPlan(userId)
  const camps = pl.business ? await q('SELECT nome, titulo, status, total, enviados, cliques, falhas, concluida_em FROM mkt_campaigns WHERE owner_id = $1 AND business_id = $2 ORDER BY id DESC LIMIT 5', [userId, pl.business.id]) : []
  const aut = Number((await q("SELECT COUNT(*) AS n FROM marketing_consents WHERE owner_id = $1 AND status = 'ativo'", [userId]))[0].n)
  return { podeUsar: !!pl.permissoes.podeUsar, permissoes: pl.permissoes, autorizados: aut, campanhas: camps.map((c: any) => ({ nome: c.nome || c.titulo, status: c.status, total: Number(c.total), enviados: Number(c.enviados), cliques: Number(c.cliques), falhas: Number(c.falhas || 0) })) }
}

/* ---------- memória do modo (por empresa): briefing, objetivo e entregas ---------- */
export async function memoria(userId: number, businessId: number): Promise<any> { return J<any>((await one("SELECT dados FROM modo_memoria WHERE user_id = $1 AND business_id = $2 AND modo = 'marketing'", [userId, businessId]))?.dados, {}) }
async function salvarMemoria(userId: number, businessId: number, dados: any) {
  const ex = await one("SELECT user_id FROM modo_memoria WHERE user_id = $1 AND business_id = $2 AND modo = 'marketing'", [userId, businessId])
  if (ex) await q("UPDATE modo_memoria SET dados = $1, atualizado_em = $2 WHERE user_id = $3 AND business_id = $4 AND modo = 'marketing'", [JSON.stringify(dados), nowIso(), userId, businessId])
  else await q("INSERT INTO modo_memoria (user_id, business_id, modo, dados, atualizado_em) VALUES ($1,$2,'marketing',$3,$4)", [userId, businessId, JSON.stringify(dados), nowIso()])
}

/* ---------- objetivos e perguntas progressivas ---------- */
export const OBJETIVOS: [string, string, RegExp][] = [
  ['clientes', 'Atrair mais clientes', /atrair|mais cliente|novos cliente|clientela/],
  ['vendas', 'Aumentar as vendas', /vend|faturar|faturamento|lucr/],
  ['instagram', 'Melhorar o Instagram', /instagram|insta\b|seguidor|rede social|redes sociais/],
  ['divulgar', 'Divulgar produtos ou serviços', /divulg|anunciar|mostrar meus|propaganda/],
  ['campanha', 'Criar campanhas promocionais', /campanha|promoc|promo\b|oferta|cupom|desconto/],
  ['marca', 'Fortalecer a marca', /marca|reconhec|branding/],
  ['posicionamento', 'Melhorar o posicionamento comercial', /posicion|concorr|diferencia/],
  ['crescimento', 'Criar estratégias de crescimento', /cresc|expandir|escalar|estrateg/],
  ['diagnostico', 'Diagnóstico completo do marketing', /diagnost|analis|avali|auditori|completo/],
]
const CONTEUDO = /legenda|post|publica[cç]|texto|an[uú]ncio|copy|calend[aá]rio|v[ií]deo|reels|stories|descri[cç][aã]o|data(s)? especia|dia das|natal|black friday|slogan|bio\b/
type Campo = 'perfil_clientes' | 'diferenciais' | 'dificuldades' | 'metas' | 'orcamento' | 'canais'
const POR_OBJETIVO: Record<string, Campo[]> = {
  clientes: ['perfil_clientes', 'diferenciais', 'canais', 'orcamento'], vendas: ['perfil_clientes', 'dificuldades', 'metas', 'canais'],
  instagram: ['perfil_clientes', 'diferenciais', 'canais'], divulgar: ['perfil_clientes', 'diferenciais', 'canais', 'orcamento'],
  campanha: ['perfil_clientes', 'diferenciais', 'orcamento'], marca: ['perfil_clientes', 'diferenciais'], posicionamento: ['perfil_clientes', 'diferenciais', 'dificuldades'],
  crescimento: ['perfil_clientes', 'dificuldades', 'metas', 'orcamento', 'canais'], diagnostico: ['perfil_clientes', 'diferenciais', 'dificuldades', 'metas', 'orcamento', 'canais'], livre: ['perfil_clientes', 'diferenciais'], conteudo: [],
}
const ROTULO: Record<Campo, string> = { perfil_clientes: 'Perfil dos clientes', diferenciais: 'Diferenciais', dificuldades: 'Principais dificuldades', metas: 'Objetivos de crescimento', orcamento: 'Orçamento para divulgação', canais: 'Canais de divulgação' }
function pergunta(c: Campo, n: Negocio): { texto: string; opcoes?: string[] } {
  if (c === 'perfil_clientes') return { texto: `Quem são os principais clientes da ${n.empresa}? Conte idade aproximada, região e o que eles mais procuram${n.itens.length ? ` (ex.: ${n.itens.slice(0, 2).map((i) => i.nome).join(', ')})` : ''}.` }
  if (c === 'diferenciais') return { texto: `O que faz a ${n.empresa} ser escolhida em vez das concorrentes? (qualidade, preço, atendimento, rapidez, algo único…)` }
  if (c === 'dificuldades') return { texto: 'Qual é hoje a maior dificuldade para vender mais?', opcoes: ['Pouca gente conhece a empresa', 'Muita concorrência', 'Clientes não voltam', 'Preço', 'Falta tempo para divulgar'] }
  if (c === 'metas') return { texto: 'Qual resultado você quer alcançar nos próximos meses? Pode ser em pedidos, clientes ou faturamento.' }
  if (c === 'orcamento') return { texto: 'Quanto você pode investir por mês em divulgação?', opcoes: ['R$ 0 (só ações gratuitas)', 'Até R$ 100', 'De R$ 100 a R$ 300', 'Mais de R$ 300'] }
  return { texto: n.instagram ? `Além do Instagram @${n.instagram}, onde você divulga hoje?` : 'Onde você divulga a empresa hoje?', opcoes: ['Instagram', 'WhatsApp', 'Google / Maps', 'Indicação boca a boca', 'Ainda não divulgo'] }
}
const valido = (m: any, c: Campo) => m?.briefing?.[c]?.valor && Date.now() - Date.parse(m.briefing[c].em || 0) < VALIDADE_DIAS * 86400_000
function faltando(objetivo: string, m: any, n: Negocio): Campo[] {
  return (POR_OBJETIVO[objetivo] || POR_OBJETIVO.livre).filter((c) => !(c === 'perfil_clientes' && n.publicoAlvo) && !valido(m, c))
}
/** Chips de resposta rápida (o app transforma em botões que enviam o texto). */
const opc = (itens: [string, string][]) => itens.length ? ` ⟦opc:${itens.map(([l, t]) => `${l.replace(/[;=⟧]/g, '')}=${t.replace(/[;=⟧]/g, '')}`).join(';')}⟧` : ''
const chipsObjetivos = () => opc(OBJETIVOS.map(([, l]) => [l, l]))
const chipsSeguir = () => opc([['Legendas para o Instagram', 'Crie 5 legendas para o Instagram da empresa'], ['Calendário de posts', 'Monte um calendário de publicações para as próximas 2 semanas'], ['Proposta de campanha', 'Crie uma proposta de campanha promocional para meus clientes'], ['Ideias de vídeos', 'Me dê ideias de vídeos curtos para divulgar'], ['Datas especiais', 'Planeje ações para as próximas datas especiais'], ['Outro objetivo', 'Quero trabalhar outro objetivo']])
function objetivoDe(texto: string): [string, string] | null {
  const t = nrm(texto); const exato = OBJETIVOS.find(([, l]) => nrm(l) === t); if (exato) return [exato[0], exato[1]]
  const r = OBJETIVOS.find(([, , re]) => re.test(t)); return r ? [r[0], r[1]] : null
}
const ehPular = (t: string) => /^(pular|pula|prox|proxima|nao sei|sei la|prefiro nao|nenhum|nada)\b/.test(nrm(t))
const resumoNegocio = (n: Negocio) => [n.categoria && `segmento ${n.categoria}`, n.itens.length && `${n.itens.length} ${n.tipo} no catálogo`, n.local && `em ${n.local.split(',').slice(-2).join(',').trim()}`, n.instagram && `Instagram @${n.instagram}`].filter(Boolean).join(', ')

/* ---------- consultoria (IA com contexto empresarial completo) ---------- */
function sistema(n: Negocio, m: any, cen: Awaited<ReturnType<typeof central>>, objetivo: string, HONESTIDADE: string) {
  const br = Object.entries(m.briefing || {}).filter(([, v]: any) => v?.valor).map(([k, v]: any) => `- ${ROTULO[k as Campo] || k}: ${v.valor}`).join('\n') || '- (ainda sem respostas do empresário)'
  const itens = n.itens.slice(0, 25).map((i) => `- ${i.nome}${i.preco ? ' — ' + brl(i.preco) : ''}${i.categoria ? ' (' + i.categoria + ')' : ''}`).join('\n') || '- (nenhum item cadastrado no catálogo)'
  const camps = cen.campanhas.length ? cen.campanhas.map((c) => `- ${c.nome}: ${c.status}, ${c.enviados} enviadas de ${c.total}, ${c.cliques} cliques${c.falhas ? ', ' + c.falhas + ' falhas' : ''}`).join('\n') : '- nenhuma campanha ainda'
  const entregas = (m.entregas || []).slice(-4).map((e: any) => `- ${e.em?.slice(0, 10)} · ${e.objetivo}: ${e.pedido}`).join('\n') || '- nenhuma'
  return [
    'MODO: CONSULTOR DE MARKETING (Meu Assistente). Você é um consultor de marketing para pequenas empresas brasileiras: prático, direto e orientado a resultados.',
    'REGRAS: use SOMENTE os dados reais abaixo e o que o empresário disse. Não invente resultados, métricas, porcentagens de mercado, concorrentes ou dados que não foram informados; quando algo for uma hipótese, diga que é para testar e medir. Adapte tudo ao segmento, à cidade, ao orçamento e aos canais informados. Seja concreto: passos, frequência, exemplos de texto com o nome real da empresa e dos produtos/serviços, e como medir pelo próprio app (pedidos, visitas, cliques da Central).',
    HONESTIDADE,
    'CENTRAL DE MARKETING: quando propuser uma campanha para os clientes do app, inclua no máximo 2 blocos exatamente neste formato (o app transforma em um cartão que o responsável revisa e leva para a Central como rascunho; nada é enviado sem ele):',
    '```campanha\n{"nome":"nome interno curto","titulo":"título da notificação (até 80 caracteres)","mensagem":"texto da notificação (até 300 caracteres)","publico":"todos|compradores|recentes|sem_compras"}\n```',
    cen.podeUsar ? `A Central está ATIVA para esta empresa: ${cen.autorizados} cliente(s) autorizaram receber ofertas.` : `A Central ainda NÃO está pronta para envios (administrador: ${cen.permissoes.administrador ? 'ligada' : 'desligada'}; empresa ativou: ${cen.permissoes.empresa ? 'sim' : 'não'}); explique que o rascunho fica guardado e que é preciso ativar em Sua empresa → Central de Marketing.`,
    `EMPRESA: ${n.empresa}${n.categoria ? ' · segmento: ' + n.categoria : ''}\nDescrição: ${n.descricao || '(não cadastrada)'}\nLocal: ${n.local || '(não informado)'}${n.atendimento ? '\nAtendimento: ' + n.atendimento : ''}${n.horario ? '\nHorário: ' + n.horario : ''}\nCanais cadastrados: ${[n.instagram && 'Instagram @' + n.instagram, n.whatsapp && 'WhatsApp', n.site && 'site ' + n.site].filter(Boolean).join(', ') || 'nenhum'}${n.publicoAlvo ? '\nPúblico-alvo cadastrado: ' + n.publicoAlvo : ''}`,
    `${n.tipo.toUpperCase()} E PREÇOS:\n${itens}`,
    `BRIEFING DO EMPRESÁRIO:\n${br}`,
    `CAMPANHAS NA CENTRAL (resultados reais):\n${camps}`,
    `ENTREGAS ANTERIORES DESTE MODO:\n${entregas}`,
    `OBJETIVO ATUAL: ${objetivo}`,
    'FORMATO: português do Brasil, títulos curtos e listas; em diagnósticos, separe Pontos fortes, Oportunidades e Plano de ação (com prazos). Termine sugerindo um próximo passo concreto.',
  ].join('\n\n')
}
/** Plano básico com os dados reais quando nenhuma IA está disponível (o modo nunca fica sem resposta). */
function planoSemIA(n: Negocio, m: any, objetivo: string, texto: string) {
  const top = n.itens.slice(0, 3).map((i) => i.nome + (i.preco ? ' (' + brl(i.preco) + ')' : '')).join(', ')
  const dif = m.briefing?.diferenciais?.valor, pub = m.briefing?.perfil_clientes?.valor || n.publicoAlvo
  const linhas = [`**${objetivo} — ${n.empresa}**`, '', 'Plano de ação para começar esta semana:',
    `1. Destaque ${top || 'seus produtos/serviços principais'} no Instagram${n.instagram ? ' @' + n.instagram : ''} e no status do WhatsApp, 3 vezes por semana.`,
    `2. Mostre o diferencial${dif ? ` ("${dif}")` : ''} em uma publicação fixa e na descrição do perfil.`,
    `3. Fale com quem já é cliente${pub ? ` (${pub})` : ''}: peça indicação e uma avaliação.`,
    '4. Crie uma oferta simples com prazo para os clientes que autorizaram receber ofertas (proposta abaixo) e meça os cliques na Central.',
    '5. Revise em 2 semanas: pedidos, visitas da página e cliques da campanha.']
  if (/legenda|post|publica/.test(nrm(texto))) linhas.push('', '**Legenda sugerida:**', `${n.empresa}${n.categoria ? ' · ' + n.categoria : ''}: ${top ? 'experimente ' + top.split(',')[0] : 'venha conhecer'}! Peça pelo app ou chame no WhatsApp.`)
  const prop = { nome: `${objetivo} · ${n.empresa}`.slice(0, 60), titulo: `Novidade na ${n.empresa}`.slice(0, 80), mensagem: (top ? `Hoje tem ${top.split(',')[0]} esperando por você. ` : '') + 'Toque para ver as ofertas da semana!', publico: 'todos' }
  return linhas.join('\n') + '\n\n```campanha\n' + JSON.stringify(prop) + '\n```\n\n_Plano gerado com os dados cadastrados (a inteligência artificial está indisponível agora; tente de novo para uma análise mais detalhada)._'
}
const PUBLICOS = ['todos', 'compradores', 'recentes', 'sem_compras']
/** Transforma os blocos de campanha em propostas guardadas e cartões no chat. */
async function extrairPropostas(c: ContextoExec, businessId: number, texto: string) {
  let n = 0
  const parse = (s: string) => { try { return JSON.parse(s) } catch { try { return JSON.parse(s.replace(/[“”]/g, '"').replace(/,\s*}/g, '}')) } catch { return null } } }
  let resto = texto, mt: RegExpExecArray | null; const re = /```\s*campanha\s*\n?([\s\S]*?)```/gi
  while ((mt = re.exec(texto))) {
    const p = parse(mt[1].trim()); let tok = ''
    if (p && n < 2) {
      const titulo = String(p.titulo || '').trim().slice(0, 80), mensagem = String(p.mensagem || '').trim().slice(0, 500)
      if (titulo.length >= 3 && mensagem.length >= 5) {
        const dados = { nome: String(p.nome || titulo).trim().slice(0, 60), titulo, mensagem, publico: PUBLICOS.includes(p.publico) ? p.publico : 'todos' }
        const r = await q("INSERT INTO modo_propostas (user_id, business_id, conversation_id, modo, tipo, dados, status, criado_em) VALUES ($1,$2,$3,'marketing','campanha',$4,'proposta',$5) RETURNING id", [c.u.id, businessId, c.conversationId, JSON.stringify(dados), nowIso()])
        tok = ` ⟦mkprop:${Number(r[0].id)}⟧`; n++
      }
    }
    resto = resto.replace(mt[0], tok ? '\n' + tok.trim() + '\n' : '')
  }
  return resto.replace(/\n{3,}/g, '\n\n').trim()
}
async function consultar(c: ContextoExec, objetivo: string): Promise<Resposta> {
  const bid = c.acesso.businessId!, n = await negocio(bid), m = await memoria(c.u.id, bid), cen = await central(c.u.id)
  const CM = await import('../ai/commercial.js')
  const sys = sistema(n, m, cen, objetivo, CM.HONESTIDADE)
  const hist = c.historico.slice(-10).map((h: any) => ({ role: h.role === 'assistant' ? 'assistant' : 'user', content: String(h.content || '').replace(/⟦[^⟧]*⟧/g, '').trim() })).filter((h) => h.content) as any[]
  let txt = ''
  try { const { complete } = await import('../ai/provider.js'); const r = await complete([{ role: 'system', content: sys }, ...hist, { role: 'user', content: c.texto }], undefined, { task: 'analise', temperature: 0.6 } as any); txt = String(r?.content || '').trim() } catch (e: any) { console.error('[modo marketing] IA indisponível:', e?.message) }
  if (!txt) txt = planoSemIA(n, m, objetivo, c.texto)
  txt = await extrairPropostas(c, bid, txt)
  txt = CM.guardExternalClaims(txt)
  m.entregas = [...(m.entregas || []), { em: nowIso(), objetivo, pedido: c.texto.slice(0, 120) }].slice(-10); m.ultimoObjetivo = objetivo
  await salvarMemoria(c.u.id, bid, m)
  return { content: txt + chipsSeguir(), cards: [] }
}

/* ---------- o modo ---------- */
export const consultorMarketing: Modo = {
  id: 'marketing', nome: 'Consultor de Marketing', descricao: 'Diagnóstico, estratégias, campanhas e conteúdos com os dados reais da sua empresa.', icone: 'megafone', exclusivo: 'Anúncio completo da empresa',
  ferramentas: ['dados_empresa', 'catalogo', 'central_marketing_resultados', 'proposta_campanha'],
  acesso: (u) => acessoCompleto(u.id),
  async iniciar(c) {
    const n = await negocio(c.acesso.businessId!), m = await memoria(c.u.id, n.id)
    const conhece = resumoNegocio(n)
    const retomar: [string, string][] = m.ultimoObjetivo ? [[`Continuar: ${m.ultimoObjetivo}`, `Continuar: ${m.ultimoObjetivo}`]] : []
    const txt = `⚡ **Consultor de Marketing** ativado para a **${n.empresa}**.\n\n${conhece ? `Já conheço os dados do seu cadastro (${conhece}), então não vou perguntar o que já está lá.` : 'Vou usar os dados do seu cadastro e perguntar só o que faltar.'}${m.ultimoObjetivo ? `\n\nDa última vez trabalhamos em **${m.ultimoObjetivo}**. Quer continuar ou escolher outro objetivo?` : ''}\n\n**O que você quer melhorar na sua empresa agora?**`
    return { resposta: { content: txt + opc([...retomar, ...OBJETIVOS.map(([, l]) => [l, l] as [string, string])]), cards: [] }, estado: { etapa: 'objetivo' } }
  },
  async responder(c) {
    const bid = c.acesso.businessId!, n = await negocio(bid), m = await memoria(c.u.id, bid)
    let est: EstadoModo = { ...c.estado }; const t = nrm(c.texto)
    if (/^(quero trabalhar )?outro objetivo|^trocar (de )?objetivo|^novo objetivo/.test(t)) return { resposta: { content: '**Qual objetivo vamos trabalhar agora?**' + chipsObjetivos(), cards: [] }, estado: { etapa: 'objetivo' } }
    // etapa 1: objetivo
    if (est.etapa === 'objetivo') {
      const cont = /^continuar:?\s*(.+)$/.exec(c.texto.trim())
      const ob = cont ? (OBJETIVOS.find(([, l]) => l === cont[1].trim()) || ['livre', cont[1].trim()]) as [string, string] : objetivoDe(c.texto)
      if (!ob && CONTEUDO.test(t)) { est = { etapa: 'consultoria', objetivo: 'conteudo', objetivoNome: 'Criação de conteúdo' }; return { resposta: await consultar(c, 'Criação de conteúdo'), estado: est } }
      const [id, nome] = ob || ['livre', c.texto.trim().slice(0, 80)]
      est = { etapa: 'coleta', objetivo: id, objetivoNome: nome }
      m.objetivos = [...new Set([...(m.objetivos || []), nome])].slice(-8); await salvarMemoria(c.u.id, bid, m)
    } else if (est.etapa === 'coleta' && est.pendente) {
      // etapa 2: guarda a resposta da pergunta anterior (ou pula) — uma pergunta por vez
      const campo = est.pendente as Campo
      if (CONTEUDO.test(t) && t.split(' ').length > 3) { est = { ...est, etapa: 'consultoria', pendente: null }; return { resposta: await consultar(c, String(est.objetivoNome)), estado: est } }
      m.briefing = { ...(m.briefing || {}), [campo]: { valor: ehPular(c.texto) ? 'não informado' : c.texto.trim().slice(0, 300), em: nowIso() } }
      await salvarMemoria(c.u.id, bid, m)
      est = { ...est, pendente: null }
    } else if (est.etapa === 'consultoria') {
      return { resposta: await consultar(c, String(est.objetivoNome || 'Marketing da empresa')), estado: est }
    }
    // próxima pergunta que ainda falta para este objetivo
    const falta = faltando(String(est.objetivo), m, n)
    if (falta.length) {
      const total = (POR_OBJETIVO[String(est.objetivo)] || POR_OBJETIVO.livre).length, feitas = total - falta.length, p = pergunta(falta[0], n)
      const intro = c.estado.etapa === 'objetivo' ? `Ótimo: **${est.objetivoNome}**. Antes de recomendar, preciso entender alguns pontos do seu negócio (uma pergunta por vez; responda "pular" se preferir).\n\n` : ''
      return { resposta: { content: `${intro}**Pergunta ${feitas + 1} de ${total}** · ${p.texto}` + opc([...(p.opcoes || []).map((o) => [o, o] as [string, string]), ['Pular', 'pular']]), cards: [] }, estado: { ...est, etapa: 'coleta', pendente: falta[0] } }
    }
    est = { ...est, etapa: 'consultoria', pendente: null }
    return { resposta: await consultar({ ...c, texto: `Meu objetivo: ${est.objetivoNome}. Com os dados da empresa e as informações que já passei, faça o diagnóstico e o plano de ação.` }, String(est.objetivoNome)), estado: est }
  },
}
/** Proposta de campanha → rascunho na Central de Marketing (só por ação do responsável; nada é programado ou enviado). */
export async function levarParaCentral(userId: number, propostaId: number) {
  const { fail } = await import('../lib/http.js')
  const ac = await acessoCompleto(userId); if (!ac.liberado) fail(403, ac.mensagem, 'modo_bloqueado')
  const p = await one("SELECT * FROM modo_propostas WHERE id = $1 AND user_id = $2 AND tipo = 'campanha'", [propostaId, userId]); if (!p) return fail(404, 'Proposta não encontrada.', 'not_found')
  if (p.status === 'na_central' && p.campaign_id && await one('SELECT id FROM mkt_campaigns WHERE id = $1 AND owner_id = $2', [p.campaign_id, userId])) return { ok: true, campanhaId: Number(p.campaign_id), jaEstava: true }
  const d = J<any>(p.dados, {}), M = await import('../lib/marketing.js')
  const c: any = await M.salvarCampanha(userId, { rascunho: true, nome: d.nome, titulo: d.titulo, mensagem: d.mensagem, segmento: { tipo: d.publico || 'todos' } })
  await q("UPDATE modo_propostas SET status = 'na_central', campaign_id = $1 WHERE id = $2", [Number(c.id), propostaId])
  return { ok: true, campanhaId: Number(c.id) }
}
export async function propostaDe(userId: number, id: number) {
  const ac = await acessoCompleto(userId); const p = await one('SELECT * FROM modo_propostas WHERE id = $1 AND user_id = $2', [id, userId])
  if (!p) return null
  const d = J<any>(p.dados, {}); let campanha: any = null
  if (p.campaign_id) { const c = await one('SELECT id, status FROM mkt_campaigns WHERE id = $1 AND owner_id = $2', [p.campaign_id, userId]); if (c) campanha = { id: Number(c.id), status: c.status } }
  return { id: Number(p.id), tipo: p.tipo, ...d, status: p.status, campanha, liberado: ac.liberado }
}
