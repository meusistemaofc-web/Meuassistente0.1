// Modo Inteligente: Treino e Acompanhamento (botão ⚡, ou sozinho quando a mensagem pede: "meu treino", "treino de hoje"…).
// Conduz a criação do plano numa conversa gradual (uma pergunta por vez, aproveitando o que a pessoa já disse e o que o
// sistema já sabe), gera o plano (IA com JSON validado; sem IA, gerador próprio), salva tudo no banco e executa comandos
// naturais: ver o plano, treino de hoje/amanhã/de um dia, concluir, trocar/tirar/incluir exercício, mudar o dia, desfazer,
// lembretes reais da Agenda e acompanhamento (frequência, sequência, adesão). Perguntas abertas sobre treino vão para a IA
// com o contexto do plano e dos registros. Mensagem que não é sobre treino: devolve null e o chat comum responde.
import type { Modo, ContextoExec, EstadoModo, Resposta } from './tipos.js'
import * as TR from '../lib/treino.js'
import { localDate, addDays } from '../lib/time.js'
import { etapa } from '../lib/etapas.js'

const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const R = (content: string, meta: Record<string, unknown> = {}): Resposta => ({ content, cards: [], meta: { modo: 'treino', ...meta } })
const DIA_N = '(domingo|segunda|terca|quarta|quinta|sexta|sabado)(?:-feira)?'
const I = {
  criar: /\b(cri[ae]r?|mont[ae]r?|faz(er)?|faca|ger[ae]r?|elabor[ae]r?|prepar[ae]r?)\s+(um |o |uma |meu |minha )*(novo |nova )?(plano de |ficha de )?treino|\b(quero|preciso( de)?) (um |uma )?(novo |nova )?(plano de |ficha de )?treino\b|\bnovo plano de treino\b|\bcomecar a treinar\b/,
  ver: /\b(meu|minha) (plano( de treino)?|ficha( de treino)?|treino)( completo| da semana| todo)?\s*\??$|\b(mostr|ve[rj]|qual (e|eh)) .{0,12}(meu |o )(plano|treino)( completo| da semana)?\b|\btreinos? da semana\b/,
  hoje: /\btreino (de|para|pra|do dia de) hoje\b|\bo que (eu )?(vou |tenho que |devo |vou ter que )?trein(o|ar) hoje\b|\bhoje (e|eh|tem) (dia de )?treino\b|\btreino do dia\b/,
  amanha: /\btreino (de|para|pra) amanha\b|\bo que (eu )?(vou |tenho que |devo )?trein(o|ar) amanha\b|\bamanha (e|eh|tem) (dia de )?treino\b/,
  diaNome: new RegExp(`\\btreino (de|da|do|na|no|para|pra) ${DIA_N}\\b|\\bo que (eu )?(vou |tenho que )?treinar (na|no|de) ${DIA_N}\\b`),
  pulei: /\b(pulei (o )?treino|nao (fiz|consegui fazer) (o |meu )?treino|nao treinei|faltei (no |o )?treino)\b/,
  concluir: /\b(marc(a|ar)|marqu(e|em)|registr(a|ar|e)|anot(a|ar|e))\b.{0,30}\btreino\b.{0,25}(concluido|feito|realizado|como feito|como concluido)|\btreino (de hoje |de ontem )?(concluido|feito|finalizado|realizado)\b|\b(terminei|conclui|finalizei|acabei|completei) (o |meu |de )?(treino|treinar)\b|\b(treinei|fiz (o |meu )?treino)\b/,
  hist: /\b(historico|frequencia|evolucao|progresso|como (eu )?(estou|to|vou) (indo|nos treinos|no treino)|quantos treinos|minha sequencia|resumo dos (meus )?treinos|estatistica|acompanhamento)\b/,
  lembDesl: /\b(deslig|desativ|cancel|remov|tir|par[ae]r? de|nao quero mais)\w*\b.{0,30}\b(lembrete|aviso|notifica)/,
  lemb: /\b(lembr(e|a|ar|ete|etes)|avis(e|a|ar)|notifi\w*|alarme)\b/,
  desfazer: /\b(desfa(z|ca|zer)|volt(a|e|ar) (o treino |o plano )?(como estava|para a versao anterior|atras|o que era)|versao anterior)\b/,
  mover: new RegExp(`\\b(mud|pass|mov|troc|troqu|transfir)\\w*\\b.{0,20}\\btreino (de|da|do) ${DIA_N} (para|pra) (a |o )?${DIA_N}`),
  trocar: /\b(troc(a|ar|o)|troqu(e|em)|substitu(a|ir|i|o|e))\b/,
  remover: /\b(tir(a|e|ar)|remov(a|e|er)|exclu(a|ir|i)|corta?r?)\b/,
  adicionar: /\b(adicion(a|e|ar)|inclu(a|ir|i)|coloc(a|que|ar)|acrescent(a|e|ar)|bot(a|e|ar))\b/,
  alterar: /\b(alter(a|e|ar)|mud(a|e|ar)|ajust(a|e|ar)|modific\w*|refa(z|ca|zer)|atualiz\w*)\b.{0,25}\b(treino|plano|ficha)\b|\btreino (mais|menos) (curto|longo|leve|pesado|intenso|puxado)\b/,
  sim: /^(sim|s|pode|pode sim|confirmo|confirma|isso|ok|okay|bora|claro|manda|quero|faz|faca|pode fazer|pode refazer|vamos|fechado|com certeza)\b/,
  nao: /^(nao|n|cancela|cancelar|deixa|esquece|melhor nao|agora nao|nao quero)\b/,
  assunto: /\btreino|exercici|academia|muscula|\bseries?\b|repetic|\bcarga\b|halter|agach|supino|flexao|prancha|alonga|aqueci|descanso|cardio|corrida|caminhada|dor muscular|hipertrof|emagrec|massa muscular|abdomin|gluteo|perna|bicep|tricep|ombro|costas|peito|whey|creatina|lesao|\bfolga\b|\btreinar\b/,
}
/** Ficha visual no chat: ⟦tr:plano⟧ (semana inteira), ⟦tr:dia:N⟧ (um dia), ⟦tr:hoje⟧; ⟦trs:1⟧ atualiza as fichas já abertas. */
const FICHA = { plano: ' ⟦tr:plano⟧', hoje: ' ⟦tr:hoje⟧', dia: (d: number) => ` ⟦tr:dia:${d}⟧`, sync: ' ⟦trs:1⟧' }
const Cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
function resumoPlano(p: TR.Plano) {
  const dias = [...p.plano.dias].sort((a, b) => ((a.dia + 6) % 7) - ((b.dia + 6) % 7))
  return [`**${p.nome}** — ${dias.length} treino${dias.length > 1 ? 's' : ''} por semana (${TR.listaDias(dias.map((d) => d.dia))}):`, ...dias.map((d) => `- ${Cap(TR.DIAS[d.dia])}: ${d.titulo} · ${d.exercicios.length} exercícios`)].join('\n')
}
const orientacoes = (p: TR.Plano) => p.plano.orientacoes.length ? '\n\n**Orientações**\n' + p.plano.orientacoes.slice(0, 5).map((o) => '- ' + o).join('\n') : ''
const EX_NOMES = /\b(supino|agachamento|rosca|remada|puxada|leg press|desenvolvimento|stiff|levantamento terra|elevacao (lateral|pelvica)|triceps|extensora|flexora|afundo|panturrilha|crucifixo|abdutora|barra fixa)\b/
const diaNomeado = (t: string): number | null => { const m = t.match(new RegExp(DIA_N)); return m ? TR.diasCitados(m[1])[0] ?? null : null }
const horaDe = (t: string): string | null => {
  const m = t.match(/\b(?:as|a|para as|pras|por volta das)?\s*(\d{1,2})(?:(?::|h)(\d{2})|\s*h(?:oras?)?)\b/) || t.match(/\bas (\d{1,2})\b/)
  if (!m) return null
  let h = Number(m[1]); const mm = m[2] ? Number(m[2]) : 0
  if (/\b(da tarde|da noite)\b/.test(t) && h < 12) h += 12
  return h <= 23 && mm <= 59 ? `${String(h).padStart(2, '0')}:${String(mm).padStart(2, '0')}` : null
}

/* ---------------------------------------------------------------- IA */
async function ia(sys: string, usuario: string, json = false): Promise<string | null> {
  try { const E = await import('../ai/engine.js'); const r = await E.run([{ role: 'system', content: sys }, { role: 'user', content: usuario }] as any, { task: 'analise', temperature: json ? 0.3 : 0.5, ...(json ? { json: true } : {}) } as any); return String(r.message?.content || '').trim() || null } catch { return null }
}
const jsonDe = (s: string | null) => { if (!s) return null; try { const t = s.replace(/^```(?:json)?\s*|\s*```$/g, ''); const i = t.indexOf('{'), j = t.lastIndexOf('}'); return i >= 0 && j > i ? JSON.parse(t.slice(i, j + 1)) : null } catch { return null } }
const PERSONAL = 'Você é o Meu Assistente atuando como um personal trainer cuidadoso, em português do Brasil. Orienta execução segura, recomenda avaliação de médico, fisioterapeuta ou profissional de educação física quando houver dor, lesão, condição de saúde ou dúvida de execução, e nunca prescreve remédios, suplementos ou dietas clínicas.'
async function gerarPlano(p: TR.Perfil): Promise<{ nome: string; dados: TR.PlanoDados; origem: string }> {
  etapa('planejando')
  const dias = (p.diasPreferidos?.length === p.diasSemana ? p.diasPreferidos : TR.diasPadrao(p.diasSemana || 3))!
  const sys = `${PERSONAL}\nMonte um plano de treino semanal personalizado. Responda SOMENTE com JSON no formato:\n{"nome": "...", "dias": [{"dia": 1, "titulo": "Treino A — ...", "foco": "...", "duracaoMin": 45, "aquecimento": "...", "exercicios": [{"nome": "...", "series": 3, "reps": "8–12", "descanso": "60–90 s", "obs": "opcional"}], "final": "..."}], "orientacoes": ["..."]}\n"dia": 0=domingo, 1=segunda … 6=sábado. Use EXATAMENTE estes dias: ${JSON.stringify(dias)}. Respeite o tempo por treino, o local/equipamentos, o nível e as limitações (não inclua exercícios que sobrecarreguem a região com dor ou lesão). Orientações curtas e práticas.`
  const x = jsonDe(await ia(sys, `Perfil: ${TR.perfilTexto(p)}.`, true))
  const v = x ? TR.validarPlano(x, { ...p, diasPreferidos: dias }) : null
  if (v) return { nome: String(x.nome || '').slice(0, 120) || TR.gerarModelo(p).nome, dados: v, origem: 'ia' }
  const m = TR.gerarModelo({ ...p, diasPreferidos: dias }); return { ...m, origem: 'modelo' }
}

/* ---------------------------------------------------------- respostas */
async function criarAgora(c: ContextoExec, p: TR.Perfil): Promise<{ resposta: Resposta; estado: EstadoModo }> {
  const g = await gerarPlano(p)
  etapa('executando')
  const plano = await TR.criarPlano(c.u.id, g.nome, p.objetivo || 'saude', g.dados, g.origem)
  const lemb = plano.lembretes?.hora ? `\n\nSeus lembretes continuam ligados às ${plano.lembretes.hora} nos dias de treino.` : '\n\nQuer que eu te lembre nos dias de treino? É só dizer o horário (ex.: "me lembre às 7h").'
  return { resposta: R(`Pronto! Montei e salvei seu plano — ele fica guardado e você pode pedir "meu treino" em qualquer conversa.\n\n${resumoPlano(plano)}\n\nNa ficha abaixo, toque no dia para ver cada exercício com a execução, as séries, as repetições e o descanso, marcar o que concluiu e anotar as cargas.${FICHA.plano}${orientacoes(plano)}${lemb}\n\nSe quiser ajustar algo, é só pedir (ex.: "troque o supino por flexão", "mude o treino de segunda para terça").`, { acao: 'plano_criado', planoId: plano.id, origem: g.origem }), estado: { etapa: 'ativo', ultimoDia: null } }
}
async function proximaPergunta(c: ContextoExec, p: TR.Perfil, prefixo = ''): Promise<{ resposta: Resposta; estado: EstadoModo }> {
  const f = TR.faltando(p)
  if (!f.length) return criarAgora(c, p)
  const q = TR.pergunta(p, f[0])
  return { resposta: R((prefixo ? prefixo + '\n\n' : '') + q.texto, { coleta: f[0] }), estado: { etapa: 'coleta', esperado: q.esperado, tentativas: 0 } }
}
async function comecarCriacao(c: ContextoExec, recomecar: boolean): Promise<{ resposta: Resposta; estado: EstadoModo }> {
  const p0 = await TR.perfil(c.u.id)
  const extra = TR.extrair(c.texto)
  const p = Object.keys(extra).length ? await TR.atualizarPerfil(c.u.id, extra) : p0
  const sabido = TR.perfilTexto(p)
  if (recomecar || !sabido) return proximaPergunta(c, p, 'Vamos montar seu treino. Vou te fazer poucas perguntas, uma de cada vez.')
  // já sabe tudo: confirma antes de usar (o perfil pode ter mudado)
  if (!TR.faltando(p).length) return { resposta: R(`Vou usar o que já sei de você: ${sabido}.\n\nPosso montar o plano com isso? Se algo mudou, me conte (ex.: "agora treino em casa", "4 dias por semana").`), estado: { etapa: 'confirmar', pendente: { acao: 'criar' } } }
  return proximaPergunta(c, p, `Vamos montar seu treino. Já sei que: ${sabido}.`)
}
function respostaDia(p: TR.Plano, data: string, hoje: string, feitoHoje: boolean, rotulo: string) {
  const d = TR.diaDaSemana(data), t = TR.treinoDoDia(p, d)
  if (!t) { const prox = TR.proximoTreino(p, data); return `${rotulo[0].toUpperCase() + rotulo.slice(1)} (${TR.DIAS[d]}) é dia de descanso no seu plano.${prox ? ` O próximo treino é ${prox.data === addDays(hoje, 1) ? 'amanhã' : 'na ' + TR.DIAS[prox.dia.dia]}: **${prox.dia.titulo}**.` : ''}` }
  const fim = data === hoje ? (feitoHoje ? '\n\nEsse você já registrou como concluído hoje. 💪' : '\n\nMarque cada exercício na ficha conforme for fazendo e anote a carga — ou, no fim, me diga "treino concluído".') : ''
  const rot = rotulo === 'hoje' ? `Hoje (${TR.DIAS[d]})` : rotulo === 'amanhã' ? `Amanhã (${TR.DIAS[d]})` : Cap(TR.DIAS[d])
  return `${rot}: **${t.titulo}** · ${t.exercicios.length} exercícios · ≈ ${t.duracaoMin} min${t.aquecimento ? `\nAquecimento: ${t.aquecimento}` : ''}${FICHA.dia(d)}${fim}`
}
async function responderPergunta(c: ContextoExec, p: TR.Plano | null, hoje: string): Promise<string> {
  etapa('pensando')
  const pf = await TR.perfil(c.u.id), a = await TR.acompanhamento(c.u.id, p, hoje)
  const sys = `${PERSONAL}\nResponda direto e curto (até 6 frases ou uma lista curta), usando o contexto abaixo quando ajudar. Se a pessoa pedir para mudar o plano, explique que você pode fazer isso (ex.: "troque o supino por flexão") — não diga que mudou nada.\nPerfil: ${TR.perfilTexto(pf) || 'ainda não informado'}.\n${p ? 'Plano ativo:\n' + TR.fmtPlano(p, false) : 'Ainda não há plano salvo.'}\nAcompanhamento: ${a.total} treino(s) registrado(s); nesta semana ${a.semana}/${a.metaSemana}; últimos 30 dias: ${a.ultimos30}.`
  const r = await ia(sys, c.texto)
  if (r && !/^(ol[aá]!? (sou|como posso))/i.test(r)) return r
  return p ? `Posso te ajudar com o seu plano: pedir o treino de hoje, registrar um treino concluído, trocar um exercício, mudar um treino de dia ou configurar lembretes. Sobre "${c.texto.slice(0, 80)}", se envolver dor ou lesão, procure um médico ou fisioterapeuta antes de continuar.` : 'Ainda não temos um plano salvo. Quer que eu monte um agora? É só dizer "crie meu treino".'
}
async function editarComIA(p: TR.Plano, pf: TR.Perfil, pedido: string): Promise<TR.PlanoDados | null> {
  etapa('planejando')
  const sys = `${PERSONAL}\nVocê recebe o plano de treino atual em JSON e um pedido de alteração. Aplique SÓ o que foi pedido e devolva o plano COMPLETO, no mesmo formato JSON (dias 0=domingo … 6=sábado), sem comentários. Respeite as limitações: ${pf.limitacoes || 'nenhuma informada'}.`
  const x = jsonDe(await ia(sys, `Plano atual:\n${JSON.stringify(p.plano)}\n\nPedido: ${pedido}`, true))
  return x ? TR.validarPlano(x, { ...pf, diasSemana: undefined }) : null
}

/* ------------------------------------------------------------- o modo */
export const treinoAcompanhamento: Modo = {
  id: 'treino', nome: 'Treino e Acompanhamento', descricao: 'Monta seu plano de treino, acompanha os treinos feitos e lembra você de treinar.', icone: 'haltere',
  ferramentas: ['perfil_pessoal', 'plano_treino', 'versoes_plano', 'sessoes_treino', 'lembretes_agenda', 'ia_plano'],
  async acesso() { return { liberado: true, codigo: 'ok', mensagem: '' } },
  detectar(texto: string) {
    const t = nrm(texto)
    return I.criar.test(t) || I.hoje.test(t) || I.amanha.test(t) || I.diaNome.test(t) || /^(meu|minha) (plano de treino|ficha de treino|treino)\b/.test(t) || (I.concluir.test(t) && /\btreino|treinei\b/.test(t)) || /\bhistorico de treinos?|frequencia (de|dos) treinos?|lembretes? de treino\b/.test(t) || /\b(lembr|avis)\w* .{0,25}\b(treinar|treino)\b/.test(t) || (I.trocar.test(t) && /\bexercicio\b/.test(t))
      // carga ou exercício concluído dito fora do modo ("fiz supino com 40 kg", "concluí o agachamento")
      || ((/\d+(?:[.,]\d+)?\s*(kg|quilos?)\b/.test(t) || /\b(conclui|terminei|fiz)\b/.test(t)) && EX_NOMES.test(t))
  },
  async iniciar(c) {
    const p = await TR.planoAtivo(c.u.id)
    if (!p) return comecarCriacao(c, false)
    const hoje = localDate(TR.tzDe(c.u)), a = await TR.acompanhamento(c.u.id, p, hoje), t = TR.treinoDoDia(p, TR.diaDaSemana(hoje))
    return { resposta: R(`Seu plano **${p.nome}** está ativo. ${t ? `Hoje tem **${t.titulo}**${a.feitoHoje ? ' — já registrado como concluído' : ''}.` : 'Hoje é dia de descanso.'} ${TR.leitura(a)}\n\nO que você quer fazer? Ver o treino de hoje, marcar exercícios e anotar cargas, ajustar um exercício, configurar lembretes ou ver como você está indo.${FICHA.hoje}`), estado: { etapa: 'ativo' } }
  },
  async responder(c) {
    const t = nrm(c.texto), e = c.estado || { etapa: 'inicio' }, u = c.u, hoje = localDate(TR.tzDe(u))
    let p = await TR.planoAtivo(u.id)

    // confirmação pendente (criar/refazer o plano, mudar perfil)
    if (e.etapa === 'confirmar' && e.pendente) {
      const pend: any = e.pendente
      if (I.sim.test(t)) { const pf = await TR.perfil(u.id); return criarAgora(c, pf) }
      if (I.nao.test(t)) return { resposta: R(p ? 'Tudo bem, mantive o seu plano como estava.' : 'Tudo bem. Quando quiser, é só pedir para montar o treino.'), estado: { etapa: 'ativo' } }
      const extra = TR.extrair(c.texto)
      if (Object.keys(extra).length) { const pf = await TR.atualizarPerfil(u.id, extra); return { resposta: R(`Anotado: ${TR.perfilTexto(pf)}.\n\nPosso ${p ? 'refazer' : 'montar'} o plano com isso?`), estado: { etapa: 'confirmar', pendente: pend } } }
    }

    // coleta gradual (respostas curtas como "3", "academia", "nenhuma")
    if (e.etapa === 'coleta' && !(I.ver.test(t) || I.hoje.test(t) || I.hist.test(t))) {
      const esperado = (e.esperado as string[]) || []
      const extra = TR.extrair(c.texto, esperado)
      if (!Object.keys(extra).length) {
        if (!I.assunto.test(t) && t.split(' ').length > 6 && Number(e.tentativas || 0) >= 1) return null // mudou de assunto: o chat comum responde
        const q = TR.pergunta(await TR.perfil(u.id), TR.faltando(await TR.perfil(u.id))[0] || 'limitacoes')
        return { resposta: R(`Não peguei essa. ${q.texto}`), estado: { ...e, tentativas: Number(e.tentativas || 0) + 1 } }
      }
      const pf = await TR.atualizarPerfil(u.id, extra)
      return proximaPergunta(c, pf)
    }

    // comandos
    if (I.mover.test(t)) {
      if (!p) return comecarCriacao(c, false)
      const mm = t.match(I.mover)!, nd = (x?: string) => (x ? TR.diasCitados(x)[0] : undefined), de = nd(mm[3]), para = nd(mm[6]) // na ordem em que foram ditos
      const dd = TR.clonar(p.plano), a = dd.dias.find((x) => x.dia === de)
      if (de === undefined || para === undefined || !a) return { resposta: R(`Não encontrei treino na ${de !== undefined ? TR.DIAS[de] : 'data indicada'}. Seus treinos são: ${TR.listaDias(p.plano.dias.map((x) => x.dia))}.`), estado: { etapa: 'ativo' } }
      const b = dd.dias.find((x) => x.dia === para); a.dia = para; if (b) b.dia = de
      etapa('executando'); p = await TR.alterarPlano(u.id, p, dd, c.texto)
      await TR.atualizarPerfil(u.id, { diasPreferidos: p.plano.dias.map((x) => x.dia) })
      return { resposta: R(`Feito: **${a.titulo}** passou para ${TR.DIAS[para]}${b ? `, e **${b.titulo}** foi para ${TR.DIAS[de]}` : ''}. Seus treinos agora são: ${TR.listaDias(p.plano.dias.map((x) => x.dia))}.${p.lembretes?.itens?.length ? ' Os lembretes acompanharam a mudança.' : ''}\n\nSe preferir como estava, diga "desfaça".${FICHA.plano}${FICHA.sync}`, { acao: 'plano_alterado', versao: p.versao }), estado: { etapa: 'ativo' } }
    }
    if (I.desfazer.test(t) && p) {
      etapa('executando'); const d = await TR.desfazer(u.id, p)
      return { resposta: R(d ? `Voltei o plano para como estava antes${d.motivo ? ` de "${d.motivo.slice(0, 80)}"` : ''}.\n\n${resumoPlano(d.plano)}${FICHA.plano}${FICHA.sync}` : 'Não há alteração anterior para desfazer neste plano.', { acao: d ? 'plano_restaurado' : 'nada' }), estado: { etapa: 'ativo' } }
    }
    if (I.lembDesl.test(t)) {
      if (!p?.lembretes?.itens?.length) return { resposta: R('Você não tem lembretes de treino ligados.'), estado: { etapa: 'ativo' } }
      etapa('executando'); await TR.desligarLembretes(u.id, p)
      return { resposta: R('Desliguei os lembretes de treino. Se quiser de volta, é só dizer o horário.', { acao: 'lembretes_desligados' }), estado: { etapa: 'ativo' } }
    }
    if (I.lemb.test(t) && (/treino|treinar/.test(t) || e.etapa !== 'inicio')) {
      if (!p) return e.etapa === 'inicio' ? null : { resposta: R('Primeiro preciso montar seu plano para saber os dias de treino. Quer começar? É só dizer "crie meu treino".'), estado: { etapa: 'ativo' } } // sem plano: um lembrete comum (o chat cuida)
      const h = horaDe(t)
      if (!h) return { resposta: R(`Em que horário você quer ser lembrado? Os lembretes vão nos seus dias de treino (${TR.listaDias(p.plano.dias.map((x) => x.dia))}). Ex.: "me lembre às 7h".`), estado: { etapa: 'ativo' } }
      const ds = TR.diasCitados(c.texto).filter((d) => !/\btreino (de|da) /.test(t))
      etapa('executando'); p = await TR.definirLembretes(u, p, h, ds.length ? ds : undefined)
      return { resposta: R(`Combinado: vou te lembrar às ${h} ${ds.length ? 'na ' + TR.listaDias(ds) : 'nos dias de treino (' + TR.listaDias(p.lembretes.dias || []) + ')'}. O aviso chega como notificação, mesmo com o app fechado, e abre o treino do dia. Os lembretes também aparecem na sua Agenda.`, { acao: 'lembretes_definidos', itens: p.lembretes.itens }), estado: { etapa: 'ativo' } }
    }
    // exercício do dia: anotar a carga ("fiz supino com 40 kg", "registre 20 kg na rosca") ou concluir um exercício ("concluí o
    // agachamento"). "Fiz o treino" (o treino inteiro) segue para o registro da sessão logo abaixo.
    const kg = t.match(/(\d+(?:[.,]\d+)?)\s*(kg|quilos?|kilos?)\b/), exConc = /\b(conclui|fiz|terminei|marc\w*|marqu\w*|feito|feita)\b/.test(t) && !/\b(treino|treinei|treinar)\b/.test(t)
    if (p && (kg || exConc) && !I.trocar.test(t) && !I.remover.test(t)) {
      const data = /\bontem\b/.test(t) ? addDays(hoje, -1) : hoje, dSem = TR.diaDaSemana(data), tDia = TR.treinoDoDia(p, dSem), quando = data === hoje ? 'hoje' : 'ontem'
      const alvo = tDia ? TR.exercicioDoTexto(p.plano, c.texto, dSem) : null
      if (alvo) {
        const ex = alvo.d.exercicios[alvo.i], rp = t.match(/(\d{1,3})\s*(reps?|repeticoes|repeticao|vezes)\b/)
        let r: Awaited<ReturnType<typeof TR.marcarExercicio>>
        try { etapa('executando'); r = await TR.marcarExercicio(u, { data, chave: TR.chaveEx(ex.nome), concluido: true, ...(kg ? { carga: kg[1] } : {}), ...(rp ? { reps: rp[1] } : {}) }) }
        catch (er: any) { return { resposta: R(String(er?.message || 'Não consegui anotar agora.')), estado: { etapa: 'ativo' } } }
        const ant = r.cargas?.historico.find((h) => h.data !== data), carga = r.registro?.carga
        const comp = kg && ant ? ` Na vez anterior (${ant.data.split('-').reverse().slice(0, 2).join('/')}): ${TR.brKg(ant.carga)}${carga != null && carga > ant.carga ? ' — subiu! 💪' : '.'}` : ''
        const fimDia = r.dia.total ? (r.dia.feitos >= r.dia.total ? ` Todos os ${r.dia.total} exercícios de ${tDia!.titulo} concluídos — treino de ${quando} registrado. 💪` : ` ${r.dia.feitos} de ${r.dia.total} exercícios de ${tDia!.titulo} feitos ${quando}.`) : ''
        return { resposta: R(`Anotei: **${ex.nome}** ${carga != null ? `com ${TR.brKg(carga)}${r.registro?.reps ? ` (${r.registro.reps} repetições)` : ''}` : 'concluído'} ${quando}.${comp}${fimDia}${FICHA.sync}`, { acao: 'exercicio_registrado', chave: r.chave, data }), estado: { etapa: 'ativo', ultimoDia: dSem } }
      }
      if (kg) {
        const outro = TR.exercicioDoTexto(p.plano, c.texto)
        if (outro) return { resposta: R(`${outro.d.exercicios[outro.i].nome} não está no treino de ${quando}${tDia ? ` (${tDia.titulo})` : ', que é dia de descanso'}: ele é da ${TR.DIAS[outro.d.dia]}. Quer anotar quando fizer esse treino?`), estado: { etapa: 'ativo' } }
        if (tDia) return { resposta: R(EX_NOMES.test(t) ? `Não encontrei esse exercício no seu plano atual. Os de ${quando} são: ${tDia.exercicios.map((e) => e.nome).join(', ')}.` : `De qual exercício é essa carga? Diga, por exemplo: "${tDia.exercicios[0].nome} ${kg[1]} kg".`), estado: { etapa: 'ativo', ultimoDia: dSem } }
      }
    }
    if (I.pulei.test(t)) {
      const data = /\bontem\b/.test(t) ? addDays(hoje, -1) : hoje
      await TR.registrar(u.id, p, data, { status: 'pulado', nota: c.texto.slice(0, 200) })
      const prox = p ? TR.proximoTreino(p, data) : null
      return { resposta: R(`Tudo bem, anotei que ${data === hoje ? 'hoje' : 'ontem'} não rolou. ${prox ? `O próximo é ${prox.data === addDays(hoje, 1) ? 'amanhã' : 'na ' + TR.DIAS[prox.dia.dia]}: **${prox.dia.titulo}**.` : ''} Se isso estiver acontecendo com frequência, posso ajustar os dias ou encurtar os treinos.`, { acao: 'sessao_pulada' }), estado: { etapa: 'ativo' } }
    }
    if (I.concluir.test(t)) {
      const data = /\bontem\b/.test(t) ? addDays(hoje, -1) : hoje
      const esf = t.match(/\b(?:nota|esforco|intensidade)\s*(\d{1,2})\b/)
      etapa('executando'); const r = await TR.registrar(u.id, p, data, { nota: /\b(pesado|puxado|leve|cansativo|dor)\b/.test(t) ? c.texto.slice(0, 200) : undefined, esforco: esf ? Math.min(10, Number(esf[1])) : undefined })
      const a = await TR.acompanhamento(u.id, p, hoje)
      const quando = data === hoje ? 'de hoje' : 'de ontem'
      return { resposta: R(`${r.jaHavia ? `O treino ${quando} já estava registrado — atualizei.` : `Registrado: treino ${quando}${r.planejado ? ` (**${r.titulo}**)` : ' (extra, fora dos dias do plano)'} concluído. 💪`} ${TR.leitura(a)}`.trim(), { acao: 'sessao_registrada', data }), estado: { etapa: 'ativo' } }
    }
    if (I.hist.test(t)) {
      const a = await TR.acompanhamento(u.id, p, hoje)
      if (!a.total) return { resposta: R(p ? 'Ainda não há treinos registrados. Quando terminar um treino, me diga "treino concluído" que eu começo a acompanhar sua frequência.' : 'Ainda não temos plano nem treinos registrados. Quer que eu monte seu treino?'), estado: { etapa: 'ativo' } }
      const vs = p ? await TR.versoes(p.id) : []
      return { resposta: R([`**Seu acompanhamento**`, `- Total registrado: ${a.total} treino(s)`, `- Nesta semana: ${a.semana}${a.metaSemana ? ` de ${a.metaSemana}` : ''}`, `- Últimos 30 dias: ${a.ultimos30}`, `- Últimas 4 semanas: ${a.semanas.join(' → ')} treinos por semana`, a.adesao.planejados ? `- Treinos planejados cumpridos (4 semanas): ${a.adesao.feitos} de ${a.adesao.planejados} (${a.adesao.pct}%)` : '', a.ultimo ? `- Último: ${a.ultimo.titulo} em ${a.ultimo.data.split('-').reverse().join('/')}` : '', vs.length ? `- Alterações no plano: ${vs.length}` : '', '', TR.leitura(a)].filter((x) => x !== '').join('\n'), { acao: 'acompanhamento' }), estado: { etapa: 'ativo' } }
    }
    if (I.criar.test(t)) {
      if (p && !/\bnovo|outro|do zero|refaz|recome/.test(t)) return { resposta: R(`Você já tem o plano **${p.nome}** ativo. Quer que eu monte um novo do zero (o atual fica no histórico) ou prefere ajustar o atual?`), estado: { etapa: 'confirmar', pendente: { acao: 'recriar' } } }
      return comecarCriacao(c, false)
    }
    if (I.hoje.test(t) || I.amanha.test(t) || I.diaNome.test(t)) {
      if (!p) return comecarCriacao(c, false)
      const a = await TR.acompanhamento(u.id, p, hoje)
      if (I.hoje.test(t)) return { resposta: R(respostaDia(p, hoje, hoje, a.feitoHoje, 'hoje'), { consulta: 'hoje' }), estado: { etapa: 'ativo', ultimoDia: TR.diaDaSemana(hoje) } }
      if (I.amanha.test(t)) return { resposta: R(respostaDia(p, addDays(hoje, 1), hoje, false, 'amanhã'), { consulta: 'amanha' }), estado: { etapa: 'ativo', ultimoDia: TR.diaDaSemana(addDays(hoje, 1)) } }
      const d = diaNomeado(t)!, t2 = TR.treinoDoDia(p, d)
      return { resposta: R(t2 ? `${Cap(TR.DIAS[d])}: **${t2.titulo}** · ${t2.exercicios.length} exercícios · ≈ ${t2.duracaoMin} min${FICHA.dia(d)}` : `${TR.DIAS[d][0].toUpperCase() + TR.DIAS[d].slice(1)} é dia de descanso no seu plano. Seus treinos são: ${TR.listaDias(p.plano.dias.map((x) => x.dia))}.`, { consulta: 'dia' }), estado: { etapa: 'ativo', ultimoDia: d } }
    }
    if (I.ver.test(t)) {
      if (!p) return comecarCriacao(c, false)
      return { resposta: R(`${resumoPlano(p)}${FICHA.plano}${orientacoes(p)}`, { consulta: 'plano' }), estado: { etapa: 'ativo' } }
    }
    if (p && I.trocar.test(t) && !/\b(dia|horario)\b/.test(t)) {
      const m = c.texto.match(/(?:troc\w*|troqu\w*|substitu\w*)\s+(?:o |a |os |as |esse |este |essa |esta )?(?:exerc[ií]cio )?(.+?)(?:\s+(?:por|pelo|pela)\s+(?:o |a |um |uma )?(.+?))?[.!?]?$/i)
      const de = m?.[1] && !/^(esse|este|essa|esta|exerc[ií]cio)$/i.test(m[1].trim()) ? m[1].trim() : '', para = m?.[2]?.trim() || ''
      const ultimo = typeof e.ultimoDia === 'number' ? (e.ultimoDia as number) : undefined
      // o mesmo exercício pode estar em vários dias: vale o dia citado, depois o último mostrado, depois o de hoje (ficha aberta), depois qualquer um
      const citado = TR.diasCitados(c.texto)[0]
      const alvo = de ? (citado !== undefined ? TR.acharExercicio(p.plano, de, citado) : null) || (ultimo !== undefined ? TR.acharExercicio(p.plano, de, ultimo) : null) || TR.acharExercicio(p.plano, de, TR.diaDaSemana(hoje)) || TR.acharExercicio(p.plano, de) : null
      if (!alvo) return { resposta: R(de ? `Não encontrei "${de}" no seu plano. Qual exercício você quer trocar? Ex.: "troque o supino por flexão".` : 'Qual exercício você quer trocar, e por qual? Ex.: "troque o supino por flexão". Se não souber por qual, diga só o exercício que eu sugiro um equivalente.'), estado: { ...e, etapa: 'ativo' } }
      const dd = TR.clonar(p.plano), d = dd.dias.find((x) => x.dia === alvo.d.dia)!, ex = d.exercicios[alvo.i], antigo = ex.nome
      const pf = await TR.perfil(u.id), novo = para ? para.charAt(0).toUpperCase() + para.slice(1) : TR.alternativa(pf, dd, ex)
      if (!novo) return { resposta: R(`Por qual exercício você quer trocar ${antigo}?`), estado: { ...e, etapa: 'ativo' } }
      ex.nome = novo.slice(0, 80); delete ex.obs; delete ex.grupo // o grupo muscular passa a ser o do exercício novo (ficha visual)
      etapa('executando'); p = await TR.alterarPlano(u.id, p, dd, c.texto)
      return { resposta: R(`Troquei **${antigo}** por **${ex.nome}** na ${TR.DIAS[d.dia]} (${d.titulo}), mantendo ${ex.series} × ${ex.reps}.${pf.limitacoes ? ' Se sentir dor nesse movimento, pare e me avise.' : ''} Se preferir como estava, diga "desfaça".${FICHA.dia(d.dia)}${FICHA.sync}`, { acao: 'exercicio_trocado' }), estado: { etapa: 'ativo', ultimoDia: d.dia } }
    }
    if (p && I.remover.test(t) && !/\blembrete|aviso\b/.test(t)) {
      const m = c.texto.match(/(?:tir\w*|remov\w*|exclu\w*|cort\w*)\s+(?:o |a |os |as |esse |este )?(?:exerc[ií]cio )?(.+?)(?:\s+(?:do|da|de)\s+(?:treino|plano|ficha|segunda|ter[cç]a|quarta|quinta|sexta|s[aá]bado|domingo).*)?[.!?]?$/i)
      const dia = TR.diasCitados(c.texto)[0], alvo = m?.[1] ? TR.acharExercicio(p.plano, m[1], dia) : null
      if (alvo) {
        const dd = TR.clonar(p.plano), d = dd.dias.find((x) => x.dia === alvo.d.dia)!
        if (d.exercicios.length <= 2) return { resposta: R(`O ${d.titulo} ficaria com menos de 2 exercícios. Prefere trocar esse exercício por outro?`), estado: { etapa: 'ativo', ultimoDia: d.dia } }
        const [x] = d.exercicios.splice(alvo.i, 1); etapa('executando'); p = await TR.alterarPlano(u.id, p, dd, c.texto)
        return { resposta: R(`Tirei **${x.nome}** da ${TR.DIAS[d.dia]} (${d.titulo}). Se preferir como estava, diga "desfaça".${FICHA.dia(d.dia)}${FICHA.sync}`, { acao: 'exercicio_removido' }), estado: { etapa: 'ativo', ultimoDia: d.dia } }
      }
    }
    if (p && I.adicionar.test(t) && TR.diasCitados(c.texto).length) {
      const dia = TR.diasCitados(c.texto)[0], m = c.texto.match(/(?:adicion\w*|inclu\w*|coloc\w*|acrescent\w*|bot\w*)\s+(?:o |a |um |uma )?(?:exerc[ií]cio (?:de )?)?(.+?)\s+(?:na|no|em|para a|pra)\s+/i)
      const d0 = p.plano.dias.find((x) => x.dia === dia)
      if (m?.[1] && d0) {
        const dd = TR.clonar(p.plano), d = dd.dias.find((x) => x.dia === dia)!, ref = d.exercicios.find((x) => !/prancha|abdominal|dead bug/i.test(x.nome)) || d.exercicios[0]
        d.exercicios.push({ nome: m[1].charAt(0).toUpperCase() + m[1].slice(1, 80), series: ref.series, reps: ref.reps, descanso: ref.descanso })
        etapa('executando'); p = await TR.alterarPlano(u.id, p, dd, c.texto)
        return { resposta: R(`Incluí **${m[1]}** na ${TR.DIAS[dia]} (${d.titulo}), com ${ref.series} × ${ref.reps}. Se preferir como estava, diga "desfaça".${FICHA.dia(dia)}${FICHA.sync}`, { acao: 'exercicio_incluido' }), estado: { etapa: 'ativo', ultimoDia: dia } }
      }
    }
    // mudança de perfil (dias, duração, local, objetivo) → refazer o plano, com confirmação
    if (p && (I.alterar.test(t) || /\b(agora|a partir de agora|vou passar a)\b/.test(t))) {
      const extra = TR.extrair(c.texto)
      const muda = (['objetivo', 'nivel', 'diasSemana', 'duracaoMin', 'local', 'limitacoes'] as const).filter((k) => extra[k] !== undefined)
      if (muda.length) { const pf = await TR.atualizarPerfil(u.id, extra); return { resposta: R(`Anotado: ${TR.perfilTexto(pf)}.\n\nIsso muda a estrutura do plano. Posso refazer o plano com essas informações? O atual fica guardado no histórico.`), estado: { etapa: 'confirmar', pendente: { acao: 'refazer' } } } }
      if (I.alterar.test(t)) {
        const dd = await editarComIA(p, await TR.perfil(u.id), c.texto)
        if (dd) { etapa('executando'); p = await TR.alterarPlano(u.id, p, dd, c.texto); return { resposta: R(`Pronto, ajustei o plano:\n\n${resumoPlano(p)}${FICHA.plano}${FICHA.sync}\n\nSe preferir como estava, diga "desfaça".`, { acao: 'plano_alterado_ia' }), estado: { etapa: 'ativo' } } }
        return { resposta: R('O que você quer mudar no treino? Posso, por exemplo:\n- trocar um exercício ("troque o supino por flexão")\n- tirar ou incluir um exercício ("tire a prancha", "inclua rosca martelo na quarta")\n- mudar um treino de dia ("mude o treino de segunda para terça")\n- refazer o plano com outros dias, tempo ou local ("agora vou treinar 4 dias")'), estado: { etapa: 'ativo' } }
      }
    }
    // pergunta aberta sobre treino → IA com o contexto do plano e dos registros
    if (I.assunto.test(t) || e.etapa === 'ativo' && /^(e |mas |entao |por que|porque|como|qual|quanto|posso|devo|da pra|pode)\b/.test(t)) {
      if (!I.assunto.test(t) && e.etapa !== 'ativo') return null
      return { resposta: R(await responderPergunta(c, p, hoje), { consulta: 'ia' }), estado: { ...e, etapa: 'ativo' } }
    }
    return null // não é sobre treino: o chat comum responde (e o modo se desliga)
  },
}
