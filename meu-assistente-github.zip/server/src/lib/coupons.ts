// Cupons de desconto por empresa: criação, validação, resgate, distribuição (push/CRM/área do cliente) e resultados.
// Regras de ouro: o cupom só vale na empresa dona dele; o uso é contado dentro de um bloqueio (nunca passa do total nem do
// limite por cliente); cada resgate fica preso a UM pedido; tudo que muda fica no histórico (coupon_changes).
import { q, one, J, B, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'
import { notify } from './notify.js'

const num = (v: any) => Number(v) || 0
const iso = (v: any): string => isoOf(v) || ''
const r2 = (n: number) => Math.round(n * 100) / 100
const RESERVA_MIN = 30 // um cupom reservado por um Pix não pago volta ao estoque depois deste tempo

/* ---------- conversões ---------- */
const dia = (v: any, fim: boolean): string | null => {
  const s = String(v ?? '').trim(); if (!s) return null
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return new Date(`${s}T${fim ? '23:59:59' : '00:00:00'}-03:00`).toISOString() // dia inteiro no horário de Brasília
  const d = new Date(s); if (isNaN(d.getTime())) fail(400, 'Data inválida.', 'invalid', fim ? 'fim' : 'inicio'); return d.toISOString()
}
export function situacao(c: any, agora = Date.now()): 'ativo' | 'pausado' | 'expirado' | 'esgotado' | 'agendado' {
  if (c.ends_at && Date.parse(iso(c.ends_at)) < agora) return 'expirado'
  if (num(c.total_qty) > 0 && num(c.used_count) >= num(c.total_qty)) return 'esgotado'
  if (c.status === 'pausado') return 'pausado'
  if (c.starts_at && Date.parse(iso(c.starts_at)) > agora) return 'agendado'
  return 'ativo'
}
export function couponOut(r: any) {
  const total = num(r.total_qty), used = num(r.used_count)
  return { id: Number(r.id), businessId: Number(r.business_id), empresa: r.empresa || undefined, nome: r.name, codigo: r.code, descricao: r.description || '', finalidade: r.purpose || '', tipo: r.kind, valor: num(r.value), tetoDesconto: num(r.max_discount), compraMinima: num(r.min_purchase),
    inicio: r.starts_at ? isoOf(r.starts_at) : null, fim: r.ends_at ? isoOf(r.ends_at) : null, quantidade: total, usados: used, restantes: total > 0 ? Math.max(0, total - used) : null, limitePorCliente: num(r.per_user_limit), produtos: J<number[]>(r.product_ids, []).map(Number),
    publico: r.audience, visibilidade: r.visibility, combinaMoedas: B(r.combine_coins), status: r.status, situacao: situacao(r), criadoEm: isoOf(r.created_at) }
}
const SEL = 'SELECT c.*, b.data AS bdata FROM coupons c JOIN businesses b ON b.id = c.business_id'
const comEmpresa = (rows: any[]) => rows.map((r) => couponOut({ ...r, empresa: J<any>(r.bdata, {}).empresa || `Empresa #${r.business_id}` }))
export async function listByBusiness(businessId: number) { return comEmpresa(await q(`${SEL} WHERE c.business_id = $1 ORDER BY c.id DESC`, [businessId])) }
export async function listAll() { return comEmpresa(await q(`${SEL} ORDER BY c.id DESC LIMIT 1000`)) }
export async function byId(id: number) { const r = await one(`${SEL} WHERE c.id = $1`, [id]); return r ? comEmpresa([r])[0] : null }
/** Garante que o cupom é da empresa indicada (isolamento entre empresas). */
export async function ofBusiness(id: number, businessId: number) { const c = await byId(id); if (!c || c.businessId !== businessId) fail(404, 'Cupom não encontrado.', 'not_found'); return c! }

/* ---------- histórico ---------- */
export async function log(couponId: number, actor: string, kind: string, detail: any = {}) {
  await q('INSERT INTO coupon_changes (coupon_id, actor, kind, detail, created_at) VALUES ($1,$2,$3,$4,$5)', [couponId, actor, kind, JSON.stringify(detail).slice(0, 1500), nowIso()])
}
export async function changes(couponId: number) { return (await q('SELECT * FROM coupon_changes WHERE coupon_id = $1 ORDER BY id DESC LIMIT 100', [couponId])).map((r: any) => ({ id: Number(r.id), quem: r.actor, tipo: r.kind, detalhe: J<any>(r.detail, {}), em: isoOf(r.created_at) })) }

/* ---------- criação e edição ---------- */
function parse(b: any, cur?: any) {
  const nome = String(b.nome ?? cur?.nome ?? '').trim().slice(0, 80); if (nome.length < 3) fail(400, 'Dê um nome à campanha (mínimo 3 letras).', 'invalid', 'nome')
  const codigo = String(b.codigo ?? cur?.codigo ?? '').trim().toUpperCase().replace(/\s+/g, ''); if (!/^[A-Z0-9_-]{3,24}$/.test(codigo)) fail(400, 'O código deve ter de 3 a 24 letras, números, - ou _ (sem espaços).', 'invalid', 'codigo')
  const tipo = (b.tipo ?? cur?.tipo) === 'fixo' ? 'fixo' : 'percentual'
  const valor = r2(Number(b.valor ?? cur?.valor)); if (!(valor > 0)) fail(400, 'Informe o valor do desconto.', 'invalid', 'valor')
  if (tipo === 'percentual' && valor > 100) fail(400, 'O desconto percentual não pode passar de 100%.', 'invalid', 'valor')
  if (tipo === 'fixo' && valor > 100000) fail(400, 'Valor de desconto alto demais.', 'invalid', 'valor')
  const inicio = 'inicio' in b ? dia(b.inicio, false) : cur?.inicio ?? null, fim = 'fim' in b ? dia(b.fim, true) : cur?.fim ?? null
  if (inicio && fim && Date.parse(fim) <= Date.parse(inicio)) fail(400, 'A data final deve ser depois da inicial.', 'invalid', 'fim')
  const int = (v: any, d: number, max: number) => { const x = Math.floor(Number(v ?? d)); return isFinite(x) ? Math.min(max, Math.max(0, x)) : d }
  const minC = Math.max(0, r2(Number(b.compraMinima ?? cur?.compraMinima ?? 0)) || 0), teto = Math.max(0, r2(Number(b.tetoDesconto ?? cur?.tetoDesconto ?? 0)) || 0)
  const produtos: number[] = [...new Set<number>((Array.isArray(b.produtos) ? b.produtos : cur?.produtos || []).map(Number).filter((n: number) => n > 0))].slice(0, 500)
  return { nome, codigo, tipo, valor, inicio, fim, minC, teto, produtos, qtd: int(b.quantidade, cur?.quantidade ?? 0, 1e9), lim: int(b.limitePorCliente, cur?.limitePorCliente ?? 1, 1e6),
    desc: String(b.descricao ?? cur?.descricao ?? '').trim().slice(0, 300), fin: String(b.finalidade ?? cur?.finalidade ?? '').trim().slice(0, 120),
    publico: (b.publico ?? cur?.publico) === 'especificos' ? 'especificos' : 'todos', vis: (b.visibilidade ?? cur?.visibilidade) === 'oculto' ? 'oculto' : 'publico', comb: typeof b.combinaMoedas === 'boolean' ? b.combinaMoedas : (cur?.combinaMoedas ?? true) }
}
async function checkProducts(businessId: number, ids: number[]) {
  if (!ids.length) return
  const ok = new Set((await q('SELECT id FROM products WHERE business_id = $1', [businessId])).map((p: any) => Number(p.id)))
  if (ids.some((i) => !ok.has(i))) fail(400, 'Algum produto escolhido não pertence a esta empresa.', 'invalid', 'produtos')
}
export async function createCoupon(businessId: number, b: any, actor: string, userId: number | null) {
  const p = parse(b); await checkProducts(businessId, p.produtos)
  if (await one('SELECT id FROM coupons WHERE business_id = $1 AND code = $2', [businessId, p.codigo])) fail(409, 'Esta empresa já tem um cupom com esse código.', 'duplicate', 'codigo')
  await q('INSERT INTO coupons (business_id, name, code, description, purpose, kind, value, max_discount, min_purchase, starts_at, ends_at, total_qty, per_user_limit, product_ids, audience, visibility, combine_coins, status, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$20)',
    [businessId, p.nome, p.codigo, p.desc, p.fin, p.tipo, p.valor, p.teto, p.minC, p.inicio, p.fim, p.qtd, p.lim, JSON.stringify(p.produtos), p.publico, p.vis, p.comb, 'ativo', userId, nowIso()])
  const c = (await one('SELECT id FROM coupons WHERE business_id = $1 AND code = $2', [businessId, p.codigo]))!
  await log(Number(c.id), actor, 'criado', { codigo: p.codigo, tipo: p.tipo, valor: p.valor })
  if (p.publico === 'especificos' && Array.isArray(b.clientes)) await setTargets(Number(c.id), b.clientes, actor)
  return (await byId(Number(c.id)))!
}
export async function updateCoupon(id: number, businessId: number, b: any, actor: string) {
  const cur = await ofBusiness(id, businessId), p = parse(b, cur); await checkProducts(businessId, p.produtos)
  if (p.codigo !== cur.codigo) {
    if (cur.usados > 0) fail(409, 'O código não pode mudar depois que o cupom já foi usado. Crie outro cupom.', 'invalid', 'codigo')
    if (await one('SELECT id FROM coupons WHERE business_id = $1 AND code = $2 AND id <> $3', [businessId, p.codigo, id])) fail(409, 'Esta empresa já tem um cupom com esse código.', 'duplicate', 'codigo')
  }
  if (p.qtd > 0 && p.qtd < cur.usados) fail(400, `A quantidade total não pode ser menor que os ${cur.usados} usos já registrados.`, 'invalid', 'quantidade')
  await q('UPDATE coupons SET name=$1, code=$2, description=$3, purpose=$4, kind=$5, value=$6, max_discount=$7, min_purchase=$8, starts_at=$9, ends_at=$10, total_qty=$11, per_user_limit=$12, product_ids=$13, audience=$14, visibility=$15, combine_coins=$16, updated_at=$17 WHERE id=$18',
    [p.nome, p.codigo, p.desc, p.fin, p.tipo, p.valor, p.teto, p.minC, p.inicio, p.fim, p.qtd, p.lim, JSON.stringify(p.produtos), p.publico, p.vis, p.comb, nowIso(), id])
  const novo = (await byId(id))!, dif: any = {}
  for (const k of ['nome', 'codigo', 'tipo', 'valor', 'tetoDesconto', 'compraMinima', 'inicio', 'fim', 'quantidade', 'limitePorCliente', 'publico', 'visibilidade', 'combinaMoedas', 'descricao', 'finalidade'] as const) if (JSON.stringify((cur as any)[k]) !== JSON.stringify((novo as any)[k])) dif[k] = { de: (cur as any)[k], para: (novo as any)[k] }
  if (JSON.stringify(cur.produtos) !== JSON.stringify(novo.produtos)) dif.produtos = { de: cur.produtos.length, para: novo.produtos.length }
  if (Array.isArray(b.clientes) && p.publico === 'especificos') { await setTargets(id, b.clientes, actor); dif.clientes = b.clientes.length }
  if (Object.keys(dif).length) await log(id, actor, 'editado', dif)
  return novo
}
export async function setStatus(id: number, businessId: number, status: string, actor: string) {
  if (!['ativo', 'pausado'].includes(status)) fail(400, 'Situação inválida.', 'invalid')
  const c = await ofBusiness(id, businessId); if (c.status === status) return c
  await q('UPDATE coupons SET status = $1, updated_at = $2 WHERE id = $3', [status, nowIso(), id]); await log(id, actor, status === 'pausado' ? 'pausado' : 'reativado', {})
  return (await byId(id))!
}
export async function removeCoupon(id: number, businessId: number, actor: string) {
  const c = await ofBusiness(id, businessId)
  if (c.usados > 0) fail(409, 'Este cupom já foi usado e não pode ser excluído (o histórico é mantido). Pause o cupom.', 'invalid')
  await q('DELETE FROM coupon_targets WHERE coupon_id = $1', [id]); await q('DELETE FROM coupon_grants WHERE coupon_id = $1', [id]); await q('DELETE FROM coupons WHERE id = $1', [id])
  await log(id, actor, 'excluido', { codigo: c.codigo })
}

/* ---------- clientes exclusivos ---------- */
export async function resolveUsers(list: any[]): Promise<number[]> {
  const ids = new Set<number>()
  for (const raw of (Array.isArray(list) ? list : []).slice(0, 2000)) {
    const s = String(raw).trim().toLowerCase(); if (!s) continue
    const u = /^\d+$/.test(s) ? await one('SELECT id FROM users WHERE id = $1', [Number(s)]) : await one('SELECT id FROM users WHERE LOWER(email) = $1', [s])
    if (u) ids.add(Number(u.id))
  }
  return [...ids]
}
export async function setTargets(couponId: number, list: any[], actor: string) {
  const ids = await resolveUsers(list)
  await q('DELETE FROM coupon_targets WHERE coupon_id = $1', [couponId])
  for (const uid of ids) await q('INSERT INTO coupon_targets (coupon_id, user_id, created_at) VALUES ($1,$2,$3) ON CONFLICT (coupon_id, user_id) DO NOTHING', [couponId, uid, nowIso()])
  await log(couponId, actor, 'clientes', { total: ids.length })
  return ids
}
export async function targets(couponId: number) {
  return (await q('SELECT t.user_id, u.name, u.email FROM coupon_targets t JOIN users u ON u.id = t.user_id WHERE t.coupon_id = $1 ORDER BY t.created_at LIMIT 500', [couponId])).map((r: any) => ({ id: Number(r.user_id), nome: r.name, email: r.email }))
}

/* ---------- validação e uso na compra ---------- */
export interface Linha { pid: number; qtd: number; preco: number }
export interface Aplicacao { coupon: ReturnType<typeof couponOut>; desconto: number; elegivel: number }
async function usosDoCliente(couponId: number, userId: number) {
  return num((await one("SELECT COUNT(*) AS n FROM coupon_redemptions WHERE coupon_id = $1 AND user_id = $2 AND status <> 'estornado'", [couponId, userId]))?.n)
}
/** Reservas de Pix não pagos que passaram do prazo voltam para o estoque. */
async function liberarReservas(couponId: number) {
  const lim = new Date(Date.now() - RESERVA_MIN * 60_000).toISOString()
  const rs = await q("SELECT r.id, r.order_id FROM coupon_redemptions r JOIN orders o ON o.id = r.order_id WHERE r.coupon_id = $1 AND r.status = 'reservado' AND r.created_at < $2 AND o.status = 'aguardando_pagamento'", [couponId, lim])
  for (const r of rs as any[]) await estornarUm(Number(r.id), 'reserva expirada')
}
/** Todas as checagens exigidas, sem gravar nada. */
export async function validar(businessId: number, userId: number, codigo: string, linhas: Linha[], opts: { ignorarReserva?: boolean } = {}): Promise<Aplicacao> {
  const code = String(codigo || '').trim().toUpperCase()
  if (!code) fail(400, 'Digite o código do cupom.', 'invalid', 'cupom')
  const r = await one(`${SEL} WHERE c.business_id = $1 AND c.code = $2`, [businessId, code])
  if (!r) fail(400, 'Cupom inválido para esta empresa.', 'cupom_invalido', 'cupom') // mesmo texto para "não existe" e "é de outra empresa"
  const c = comEmpresa([r])[0]
  if (c.situacao === 'pausado') fail(400, 'Este cupom está pausado.', 'cupom_pausado', 'cupom')
  if (c.situacao === 'agendado') fail(400, `Este cupom ainda não começou (válido a partir de ${new Date(c.inicio!).toLocaleDateString('pt-BR', { timeZone: 'America/Fortaleza' })}).`, 'cupom_agendado', 'cupom')
  if (c.situacao === 'expirado') fail(400, 'Este cupom expirou.', 'cupom_expirado', 'cupom')
  if (c.situacao === 'esgotado') { await liberarReservas(c.id); const again = await byId(c.id); if (!again || again.situacao === 'esgotado') fail(400, 'Este cupom esgotou.', 'cupom_esgotado', 'cupom') }
  if (c.publico === 'especificos' && !(await one('SELECT 1 AS x FROM coupon_targets WHERE coupon_id = $1 AND user_id = $2', [c.id, userId]))) fail(400, 'Este cupom é exclusivo para clientes selecionados.', 'cupom_exclusivo', 'cupom')
  if (c.limitePorCliente > 0 && (await usosDoCliente(c.id, userId)) >= c.limitePorCliente) fail(400, c.limitePorCliente === 1 ? 'Você já usou este cupom.' : `Você já usou este cupom ${c.limitePorCliente} vezes (limite).`, 'cupom_limite_cliente', 'cupom')
  const part = new Set(c.produtos), elegiveis = linhas.filter((l) => !part.size || part.has(l.pid))
  const total = r2(linhas.reduce((a, l) => a + l.preco * l.qtd, 0)), elegivel = r2(elegiveis.reduce((a, l) => a + l.preco * l.qtd, 0))
  if (!(elegivel > 0)) fail(400, 'Nenhum item do seu pedido participa deste cupom.', 'cupom_sem_item', 'cupom')
  if (total < c.compraMinima) fail(400, `Compra mínima para este cupom: R$ ${c.compraMinima.toFixed(2).replace('.', ',')}.`, 'cupom_minimo', 'cupom')
  let desconto = c.tipo === 'percentual' ? r2((elegivel * c.valor) / 100) : c.valor
  if (c.tetoDesconto > 0) desconto = Math.min(desconto, c.tetoDesconto)
  desconto = r2(Math.min(desconto, elegivel)) // nunca passa do valor dos itens participantes
  if (!(desconto > 0)) fail(400, 'Este cupom não gera desconto neste pedido.', 'cupom_sem_desconto', 'cupom')
  return { coupon: c, desconto, elegivel }
}
/** Registra o uso depois que o pedido existe. Revalida dentro do bloqueio: dois pedidos simultâneos não passam do estoque/limite. */
export async function resgatar(app: Aplicacao, userId: number, orderId: number, orderTotal: number, coinDiscount: number, reservado: boolean) {
  const c = app.coupon
  return withLock(`cupom:${c.id}`, async () => {
    if (await one('SELECT id FROM coupon_redemptions WHERE coupon_id = $1 AND order_id = $2', [c.id, orderId])) return { duplicado: true }
    await liberarReservas(c.id)
    const f = (await byId(c.id))!
    if (f.situacao !== 'ativo') fail(400, f.situacao === 'esgotado' ? 'Este cupom acabou de esgotar.' : 'Este cupom não está mais disponível.', 'cupom_indisponivel', 'cupom')
    if (f.limitePorCliente > 0 && (await usosDoCliente(c.id, userId)) >= f.limitePorCliente) fail(400, 'Você já usou este cupom.', 'cupom_limite_cliente', 'cupom')
    await q('INSERT INTO coupon_redemptions (coupon_id, business_id, user_id, order_id, discount, order_total, coin_discount, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)', [c.id, c.businessId, userId, orderId, app.desconto, orderTotal, coinDiscount, reservado ? 'reservado' : 'usado', nowIso()])
    await q('UPDATE coupons SET used_count = used_count + 1, updated_at = $1 WHERE id = $2', [nowIso(), c.id])
    await q("UPDATE coupon_grants SET redeemed_at = $1 WHERE coupon_id = $2 AND user_id = $3 AND redeemed_at IS NULL", [nowIso(), c.id, userId])
    await log(c.id, `cliente ${userId}`, 'resgate', { pedido: orderId, desconto: app.desconto })
    return { duplicado: false }
  })
}
async function estornarUm(redId: number, motivo: string) {
  const r = await one('SELECT * FROM coupon_redemptions WHERE id = $1', [redId]); if (!r || r.status === 'estornado') return
  await withLock(`cupom:${r.coupon_id}`, async () => {
    const cur = await one('SELECT status FROM coupon_redemptions WHERE id = $1', [redId]); if (!cur || cur.status === 'estornado') return
    await q("UPDATE coupon_redemptions SET status = 'estornado', updated_at = $1 WHERE id = $2", [nowIso(), redId])
    await q('UPDATE coupons SET used_count = CASE WHEN used_count > 0 THEN used_count - 1 ELSE 0 END, updated_at = $1 WHERE id = $2', [nowIso(), r.coupon_id])
    await log(Number(r.coupon_id), 'sistema', 'estorno', { pedido: Number(r.order_id), motivo })
  })
}
/** Pedido recusado/cancelado/sem Pix: o cupom volta (uma única vez). */
export async function estornarPedido(orderId: number, motivo = 'pedido não concluído') {
  for (const r of (await q("SELECT id FROM coupon_redemptions WHERE order_id = $1 AND status <> 'estornado'", [orderId])) as any[]) await estornarUm(Number(r.id), motivo)
}
/** Pix aprovado: a reserva vira uso definitivo. */
export async function confirmarPedido(orderId: number) {
  await q("UPDATE coupon_redemptions SET status = 'usado', updated_at = $1 WHERE order_id = $2 AND status = 'reservado'", [nowIso(), orderId])
}

/* ---------- vitrine e área do cliente ---------- */
const visivelAoCliente = (c: any) => c.situacao === 'ativo'
export async function publicOf(businessId: number, userId: number | null) {
  const l = (await listByBusiness(businessId)).filter((c) => visivelAoCliente(c) && c.visibilidade === 'publico')
  const out: any[] = []
  for (const c of l) {
    if (c.publico === 'especificos' && !(userId && await one('SELECT 1 AS x FROM coupon_targets WHERE coupon_id = $1 AND user_id = $2', [c.id, userId]))) continue
    out.push({ ...cliente(c), usadoPorMim: userId ? await usosDoCliente(c.id, userId) : 0 })
  }
  return out
}
/** O que o cliente pode ver (sem números internos da empresa). */
const cliente = (c: any) => ({ id: c.id, businessId: c.businessId, empresa: c.empresa, nome: c.nome, codigo: c.codigo, descricao: c.descricao, tipo: c.tipo, valor: c.valor, tetoDesconto: c.tetoDesconto, compraMinima: c.compraMinima, fim: c.fim, produtos: c.produtos.length, limitePorCliente: c.limitePorCliente, combinaMoedas: c.combinaMoedas, exclusivo: c.publico === 'especificos' })
export async function mine(userId: number) {
  const grants = await q('SELECT * FROM coupon_grants WHERE user_id = $1 ORDER BY id DESC LIMIT 200', [userId]), seen = new Set<number>(), out: any[] = []
  for (const g of grants as any[]) {
    if (seen.has(Number(g.coupon_id))) continue; seen.add(Number(g.coupon_id))
    const c = await byId(Number(g.coupon_id)); if (!c) continue
    out.push({ ...cliente(c), situacao: c.situacao, recebidoEm: isoOf(g.sent_at), canal: g.channel, usadoPorMim: await usosDoCliente(c.id, userId), origem: 'recebido' })
  }
  for (const c of (await listAll()).filter((x) => visivelAoCliente(x) && x.visibilidade === 'publico' && !seen.has(x.id))) {
    if (out.length >= 150) break
    if (c.publico === 'especificos' && !(await one('SELECT 1 AS x FROM coupon_targets WHERE coupon_id = $1 AND user_id = $2', [c.id, userId]))) continue
    out.push({ ...cliente(c), situacao: c.situacao, usadoPorMim: await usosDoCliente(c.id, userId), origem: 'vitrine' }); seen.add(c.id)
  }
  await q('UPDATE coupon_grants SET opened_at = $1 WHERE user_id = $2 AND opened_at IS NULL', [nowIso(), userId]) // abriu a área de cupons = interação
  const usados = await q("SELECT r.discount, r.order_id, r.created_at, r.status, c.code, c.name FROM coupon_redemptions r JOIN coupons c ON c.id = r.coupon_id WHERE r.user_id = $1 AND r.status <> 'estornado' ORDER BY r.id DESC LIMIT 50", [userId])
  return { cupons: out, historico: usados.map((r: any) => ({ codigo: r.code, nome: r.name, desconto: num(r.discount), pedido: Number(r.order_id), em: isoOf(r.created_at) })) }
}

/* ---------- distribuição (push, CRM, área do cliente) ---------- */
export const SEGMENTOS = ['todos', 'novos', 'recorrentes', 'inativos', 'potenciais', 'comprou_produto', 'especificos'] as const
/** CRM: classifica os clientes da empresa pelo histórico real de pedidos. */
export async function crmSegmentos(businessId: number) {
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [businessId]); if (!b) return null
  const rows = await q("SELECT customer_id, data, created_at FROM orders WHERE business_id = $1 AND customer_id IS NOT NULL AND status NOT IN ('recusado','cancelado','aguardando_pagamento') ORDER BY id DESC LIMIT 5000", [businessId])
  const por = new Map<number, { n: number; ultima: number; primeira: number; produtos: Set<number> }>()
  for (const r of rows as any[]) {
    const d = J<any>(r.data, {}); if (d.guest) continue
    const c = Number(r.customer_id), t = Date.parse(iso(r.created_at)), x = por.get(c) || { n: 0, ultima: 0, primeira: Infinity, produtos: new Set<number>() }
    x.n++; x.ultima = Math.max(x.ultima, t); x.primeira = Math.min(x.primeira, t); for (const l of d.itens || []) if (l.pid) x.produtos.add(Number(l.pid)); por.set(c, x)
  }
  const agora = Date.now(), D = 86400_000, seg: Record<string, number[]> = { todos: [], novos: [], recorrentes: [], inativos: [], potenciais: [] }
  for (const [c, x] of por) {
    if (c === Number(b.owner_id)) continue
    seg.todos.push(c)
    if (agora - x.ultima > 60 * D) seg.inativos.push(c); else if (x.n >= 2) seg.recorrentes.push(c); else if (agora - x.primeira <= 30 * D) seg.novos.push(c); else seg.recorrentes.push(c)
  }
  const cons = (await q("SELECT user_id FROM marketing_consents WHERE owner_id = $1 AND status = 'ativo'", [b.owner_id])).map((r: any) => Number(r.user_id))
  seg.potenciais = cons.filter((id) => !por.has(id) && id !== Number(b.owner_id))
  return { seg, por, consentidos: new Set(cons) }
}
export async function previewDistribuicao(businessId: number, couponId: number, body: any) {
  const c = await ofBusiness(couponId, businessId), crm = await crmSegmentos(businessId); if (!crm) fail(404, 'Empresa não encontrada.', 'not_found')
  const segmento = String(body.segmento || 'todos'); if (!(SEGMENTOS as readonly string[]).includes(segmento)) fail(400, 'Segmento inválido.', 'invalid', 'segmento')
  let ids: number[]
  if (segmento === 'especificos') ids = c.publico === 'especificos' && !(Array.isArray(body.clientes) && body.clientes.length) ? (await targets(c.id)).map((t) => t.id) : await resolveUsers(body.clientes)
  else if (segmento === 'comprou_produto') { const pids = (Array.isArray(body.produtos) ? body.produtos : c.produtos).map(Number); ids = [...crm!.por].filter(([, x]) => pids.some((p: number) => x.produtos.has(p))).map(([id]) => id) }
  else ids = crm!.seg[segmento] || []
  if (c.publico === 'especificos') { const ok = new Set((await targets(c.id)).map((t) => t.id)); ids = ids.filter((i) => ok.has(i)) } // exclusivo: só chega a quem está autorizado
  const users = ids.length ? await q(`SELECT id FROM users WHERE status = 'active' AND id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids) : []
  const ativos = new Set((users as any[]).map((u) => Number(u.id)))
  return { cupom: c, segmento, alvo: ids.filter((i) => ativos.has(i)), consentidos: crm!.consentidos }
}
async function criarGrant(couponId: number, userId: number, channel: string, status: string) {
  await q('INSERT INTO coupon_grants (coupon_id, user_id, channel, status, sent_at) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (coupon_id, user_id, channel) DO NOTHING', [couponId, userId, channel, status, nowIso()])
}
/** Entrega o cupom: sempre aparece na área de cupons do cliente; por push só para quem autorizou comunicações e dentro do plano. */
export async function distribuir(businessId: number, couponId: number, body: any, actor: string) {
  const pv = await previewDistribuicao(businessId, couponId, body), c = pv.cupom
  if (!['ativo', 'agendado'].includes(c.situacao)) fail(400, 'Só é possível distribuir cupons ativos (não pausados, expirados ou esgotados).', 'invalid')
  const canal = ['push', 'area', 'crm', 'marketing'].includes(body.canal) ? String(body.canal) : 'push'
  const b = (await one('SELECT owner_id FROM businesses WHERE id = $1', [businessId]))!
  let limiteRestante = Infinity, planoOk = true
  if (canal === 'push' || canal === 'marketing') {
    const mk = await import('./marketing.js'), pl = await mk.ownerPlan(Number(b.owner_id))
    if (!pl.limites.acesso) planoOk = false
    else { const ini = pl.periodo.inicio, usadoCupom = num((await one("SELECT COUNT(*) AS n FROM coupon_grants g JOIN coupons c ON c.id = g.coupon_id WHERE c.business_id = $1 AND g.channel IN ('push','marketing') AND g.sent_at >= $2 AND g.status <> 'falhou'", [businessId, ini]))?.n); limiteRestante = Math.max(0, pl.limites.notificacoesPeriodo - pl.uso.notificacoes - usadoCupom) }
    if (!planoOk) fail(402, 'A Central de Marketing não está disponível no plano atual. Distribua pela área de cupons do cliente (sem notificação) ou faça upgrade.', 'plan_limit')
  }
  const empresa = c.empresa || 'a empresa'
  let enviados = 0, area = 0, semAutorizacao = 0, foraLimite = 0, jaTinha = 0
  for (const uid of pv.alvo) {
    if (canal === 'area' || canal === 'crm') { const ex = await one('SELECT id FROM coupon_grants WHERE coupon_id = $1 AND user_id = $2 AND channel = $3', [c.id, uid, canal]); if (ex) { jaTinha++; continue } await criarGrant(c.id, uid, canal, 'disponivel'); area++; continue }
    if (await one('SELECT id FROM coupon_grants WHERE coupon_id = $1 AND user_id = $2 AND channel = $3', [c.id, uid, canal])) { jaTinha++; continue }
    if (!pv.consentidos.has(uid)) { semAutorizacao++; await criarGrant(c.id, uid, 'area', 'disponivel'); continue } // sem autorização de comunicação: só fica disponível na área dele
    if (enviados >= limiteRestante) { foraLimite++; await criarGrant(c.id, uid, 'area', 'disponivel'); continue }
    const msg = String(body.mensagem || '').trim().slice(0, 200) || `Use o cupom ${c.codigo}: ${c.tipo === 'percentual' ? c.valor + '%' : 'R$ ' + c.valor.toFixed(2).replace('.', ',')} de desconto em ${empresa}.`
    try { await notify(uid, { type: 'market', title: `Cupom de ${empresa}: ${c.codigo}`, body: msg, link: '/x/cupons', ref: `cupom:${c.id}:${uid}` }); await criarGrant(c.id, uid, canal, 'entregue'); enviados++ }
    catch { await criarGrant(c.id, uid, canal, 'falhou') }
  }
  await log(c.id, actor, 'distribuido', { canal, segmento: pv.segmento, alvo: pv.alvo.length, enviados, area, semAutorizacao, foraLimite, jaTinha })
  return { ok: true, alvo: pv.alvo.length, enviadosPush: enviados, disponibilizadosNaArea: area + semAutorizacao + foraLimite, semAutorizacao, foraLimite, jaRecebiam: jaTinha, canal }
}

/* ---------- resultados ---------- */
export async function stats(couponId: number) {
  const c = (await byId(couponId))!
  const reds = (await q("SELECT user_id, discount, order_total, coin_discount, status, created_at FROM coupon_redemptions WHERE coupon_id = $1 AND status <> 'estornado'", [couponId])) as any[]
  const grants = (await q('SELECT user_id, channel, status, opened_at, redeemed_at FROM coupon_grants WHERE coupon_id = $1', [couponId])) as any[]
  const alcancados = new Set(grants.map((g) => Number(g.user_id))), pushes = grants.filter((g) => ['push', 'marketing'].includes(g.channel))
  const usuarios = new Set(reds.map((r) => Number(r.user_id))), convertidos = [...usuarios].filter((u) => alcancados.has(u)).length
  return { ...c, distribuidos: grants.length, clientesAlcancados: alcancados.size, enviadosPush: pushes.length, entreguesPush: pushes.filter((g) => g.status === 'entregue').length, abertos: grants.filter((g) => g.opened_at).length, usadosPorAlcancados: convertidos,
    clientesQueUsaram: usuarios.size, vendasComCupom: reds.length, valorVendido: r2(reds.reduce((a, r) => a + num(r.order_total), 0)), descontoTotal: r2(reds.reduce((a, r) => a + num(r.discount), 0)), descontoMoedas: r2(reds.reduce((a, r) => a + num(r.coin_discount), 0)),
    conversao: alcancados.size ? r2((convertidos / alcancados.size) * 100) : 0, disponiveis: c.restantes }
}
export async function dashboard(businessId: number | null) {
  const list = (businessId ? await listByBusiness(businessId) : await listAll()), det = await Promise.all(list.map((c) => stats(c.id)))
  const sum = (f: (s: any) => number) => r2(det.reduce((a, s) => a + f(s), 0)), alc = new Set<number>()
  if (det.length) for (const g of (await q(`SELECT DISTINCT user_id FROM coupon_grants WHERE coupon_id IN (${det.map((_, i) => '$' + (i + 1)).join(',')})`, det.map((s) => s.id))) as any[]) alc.add(Number(g.user_id))
  const conv = sum((s) => s.usadosPorAlcancados)
  return { resumo: { criados: det.length, ativos: det.filter((s) => s.situacao === 'ativo').length, pausados: det.filter((s) => s.situacao === 'pausado').length, expirados: det.filter((s) => s.situacao === 'expirado').length, esgotados: det.filter((s) => s.situacao === 'esgotado').length,
    distribuidos: sum((s) => s.distribuidos), usados: sum((s) => s.usados), disponiveis: sum((s) => s.disponiveis ?? 0), ilimitados: det.filter((s) => s.quantidade === 0).length, clientesAlcancados: alc.size, vendasComCupom: sum((s) => s.vendasComCupom), valorVendido: sum((s) => s.valorVendido), descontoTotal: sum((s) => s.descontoTotal),
    conversao: alc.size ? r2((conv / alc.size) * 100) : 0 }, cupons: det }
}
