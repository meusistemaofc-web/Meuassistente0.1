// Capacidades pessoais do Cérebro do Chat: o que o assistente aprende sobre a pessoa em cada ÁREA da vida (treino agora;
// alimentação, hábitos, estudos, metas e rotinas no futuro) fica salvo por usuário — não depende do histórico da conversa
// e é recuperado em qualquer conversa nova.
//
// Para criar uma capacidade nova:
//   1. registre a área em AREAS (nome e descrição);
//   2. guarde o perfil com salvarPerfil(userId, area, dados) e leia com perfil(userId, area);
//   3. crie as tabelas próprias da área (como treino_planos/treino_sessoes) e um modo em src/modos/ que use tudo isso;
//   4. o modo aparece sozinho no painel (Motor do chat → Modos do botão ⚡) para ativar, ocultar e ordenar.
import { q, one, J, nowIso } from '../db/index.js'

export const AREAS: Record<string, { nome: string; descricao: string; implementada: boolean }> = {
  treino: { nome: 'Treino e Acompanhamento', descricao: 'Plano de treino personalizado, treinos realizados, frequência e lembretes.', implementada: true },
  // previstas (sem implementação ainda — não aparecem como disponíveis em lugar nenhum):
  alimentacao: { nome: 'Alimentação', descricao: 'Previsto.', implementada: false },
  habitos: { nome: 'Hábitos', descricao: 'Previsto.', implementada: false },
  estudos: { nome: 'Estudos', descricao: 'Previsto.', implementada: false },
  metas: { nome: 'Metas', descricao: 'Previsto.', implementada: false },
  rotinas: { nome: 'Rotinas', descricao: 'Previsto.', implementada: false },
}

export async function perfil<T = any>(userId: number, area: string): Promise<T | null> {
  const r = await one('SELECT dados FROM pessoal_perfis WHERE user_id = $1 AND area = $2', [userId, area])
  return r ? J<T>(r.dados, {} as T) : null
}
/** Mescla os dados novos no perfil da área (campos ausentes não apagam o que já se sabia). */
export async function salvarPerfil<T extends object>(userId: number, area: string, dados: Partial<T>): Promise<T> {
  const atual = (await perfil<T>(userId, area)) || ({} as T)
  const novo = { ...atual } as any
  for (const [k, v] of Object.entries(dados)) if (v !== undefined) novo[k] = v
  const ex = await one('SELECT 1 FROM pessoal_perfis WHERE user_id = $1 AND area = $2', [userId, area])
  if (ex) await q('UPDATE pessoal_perfis SET dados = $1, atualizado_em = $2 WHERE user_id = $3 AND area = $4', [JSON.stringify(novo), nowIso(), userId, area])
  else await q('INSERT INTO pessoal_perfis (user_id, area, dados, atualizado_em) VALUES ($1,$2,$3,$4)', [userId, area, JSON.stringify(novo), nowIso()])
  return novo
}
export async function apagarPerfil(userId: number, area: string) { await q('DELETE FROM pessoal_perfis WHERE user_id = $1 AND area = $2', [userId, area]) }
