// Dados por usuário dos módulos novos, guardados em JSON (tabela user_modules).
import { one, q, J, nowIso, memoRequisicao } from '../db/index.js'
import { getConfig } from './settings.js'
import { MODULES_DEFAULT } from './panel-defaults.js'
import { fail } from './http.js'

export async function getUM<T>(userId: number, key: string, fallback: T): Promise<T> {
  const m = memoRequisicao(), k = `um:${userId}:${key}`
  let raw: unknown
  if (m && m.has(k)) raw = m.get(k)
  else { const r = await one('SELECT value FROM user_modules WHERE user_id = $1 AND key = $2', [userId, key]); raw = r ? r.value : null; m?.set(k, raw) }
  if (raw == null) return fallback
  return J<T>(typeof raw === 'string' ? raw : structuredClone(raw), fallback)
}
/** Busca várias chaves do usuário numa só consulta (memória da requisição). */
export async function prefetchUM(userId: number, keys: string[]) {
  const m = memoRequisicao(); if (!m || !keys.length) return
  const falta = keys.filter((k) => !m.has(`um:${userId}:${k}`)); if (!falta.length) return
  const rows = await q(`SELECT key, value FROM user_modules WHERE user_id = $1 AND key IN (${falta.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...falta])
  const achou = new Map(rows.map((r: any) => [String(r.key), r.value]))
  for (const k of falta) m.set(`um:${userId}:${k}`, achou.has(k) ? achou.get(k) : null)
}
export async function setUM(userId: number, key: string, value: unknown) {
  const v = JSON.stringify(value)
  memoRequisicao()?.delete(`um:${userId}:${key}`)
  const ex = await one('SELECT key FROM user_modules WHERE user_id = $1 AND key = $2', [userId, key])
  if (ex) await q('UPDATE user_modules SET value = $1, updated_at = $2 WHERE user_id = $3 AND key = $4', [v, nowIso(), userId, key])
  else await q('INSERT INTO user_modules (user_id, key, value, updated_at) VALUES ($1,$2,$3,$4)', [userId, key, v, nowIso()])
}
export let MOD_CACHE: Record<string, boolean> = { ...MODULES_DEFAULT }
export async function modules() { MOD_CACHE = { ...MODULES_DEFAULT, ...(await getConfig<Record<string, boolean>>('modules', {})) } as Record<string, boolean>; return MOD_CACHE }
export async function requireModule(name: string) { if (!(await modules())[name]) fail(403, 'Este módulo está desligado pelo administrador.', 'module_disabled') }
