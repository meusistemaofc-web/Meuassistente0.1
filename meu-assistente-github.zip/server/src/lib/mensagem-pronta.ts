// Mensagem pronta (por empresa): botão no catálogo público que abre o WhatsApp da loja com o texto já preenchido.
// Variáveis: {produto} {preco} {empresa} {link} {cliente}. Trechos entre [colchetes] somem quando alguma variável
// dentro deles não tem valor (ex.: sem produto escolhido, sem cliente identificado) — o texto continua natural.
export const VARIAVEIS = ['produto', 'preco', 'empresa', 'link', 'cliente'] as const
export const PADRAO = { ativo: false, texto: 'Olá, {empresa}! [Meu nome é {cliente}. ][Tenho interesse em {produto} ({preco}). ]Vi no seu catálogo: {link}', botao: 'Chamar no WhatsApp' }
export const LIMITES = { texto: 700, botao: 40 }
export function config(x: any) { const m = x?.mensagemPronta || {}; return { ativo: m.ativo === true, texto: typeof m.texto === 'string' && m.texto.trim() ? m.texto : PADRAO.texto, botao: typeof m.botao === 'string' && m.botao.trim() ? m.botao : PADRAO.botao } }
/** Monta o texto final. Variáveis desconhecidas ficam como estão (o dono vê na prévia). */
export function renderizar(tpl: string, vars: Partial<Record<(typeof VARIAVEIS)[number], string>>) {
  const val = (k: string) => String((vars as any)[k] ?? '').trim()
  const sub = (s: string) => s.replace(/\{(\w+)\}/g, (m, k) => (VARIAVEIS as readonly string[]).includes(k) ? val(k) : m)
  let out = String(tpl || '').replace(/\[([^\[\]]*)\]/g, (_, seg) => { const ks = [...seg.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter((k) => (VARIAVEIS as readonly string[]).includes(k)); return ks.some((k) => !val(k)) ? '' : sub(seg) })
  out = sub(out)
  return out.replace(/[ \t]{2,}/g, ' ').replace(/ +([,.!?])/g, '$1').replace(/\n{3,}/g, '\n\n').trim()
}
export function validar(body: any) {
  const ativo = body?.ativo === true
  const texto = String(body?.texto ?? '').replace(/\r/g, '').trim(), botao = String(body?.botao ?? '').replace(/\s+/g, ' ').trim()
  if (!texto) throw Object.assign(new Error('Escreva a mensagem.'), { campo: 'texto' })
  if (texto.length > LIMITES.texto) throw Object.assign(new Error(`A mensagem pode ter até ${LIMITES.texto} caracteres.`), { campo: 'texto' })
  if (!botao) throw Object.assign(new Error('Escreva o texto do botão.'), { campo: 'botao' })
  if (botao.length > LIMITES.botao) throw Object.assign(new Error(`O texto do botão pode ter até ${LIMITES.botao} caracteres.`), { campo: 'botao' })
  const desconhecidas = [...texto.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter((k) => !(VARIAVEIS as readonly string[]).includes(k))
  if (desconhecidas.length) throw Object.assign(new Error(`Variável desconhecida: {${desconhecidas[0]}}. Use {produto}, {preco}, {empresa}, {link} ou {cliente}.`), { campo: 'texto' })
  return { ativo, texto, botao }
}
