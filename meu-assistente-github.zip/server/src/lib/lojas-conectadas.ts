// Lojas Conectadas — uma conta (a "central") acompanha e administra pedidos, agendamentos e notificações de várias lojas.
// Regras:
// • a conexão nasce de uma CHAVE gerada pela central (guardada só como SHA-256, com validade e número de usos controlados);
// • o DONO da loja digita a chave e escolhe o nível de acesso (administrador ou operador) → solicitação pendente;
// • a central ACEITA ou RECUSA. Os dois lados autorizam; qualquer um dos dois pode desvincular a qualquer momento;
// • a posse da loja nunca muda; cada loja continua com o próprio cadastro, catálogo, clientes, pedidos e agendamentos.
//   Desvincular não apaga nem cancela nada — só tira o acesso da central;
// • tudo fica registrado (store_link_events + audit_log).
import { createHash, randomBytes } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'

export type Papel = 'proprietario' | 'administrador' | 'operador'
export const PAPEIS_LINK = ['administrador', 'operador'] as const
export const PAPEL_ROTULO: Record<string, string> = { proprietario: 'Proprietário', administrador: 'Administrador', operador: 'Operador' }
export const VALIDADES_HORAS = [1, 24, 72, 168, 720] as const
const ALF = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const MAX_CHAVES_ATIVAS = 10
const hash = (k: string) => createHash('sha256').update(normalizar(k)).digest('hex')
export const normalizar = (k: string) => String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, '')
function novaChave() { const b = randomBytes(16); let s = ''; for (let i = 0; i < 16; i++) s += ALF[b[i] % ALF.length]; return `MA-${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}` }
const audit = async (uid: number, acao: string, alvo: any, meta: any) => { try { await (await import('./account.js')).audit(uid, acao, alvo, meta) } catch (e: any) { console.error('[lojas]', e?.message) } }
const notify = async (uid: number, n: any) => { try { await (await import('./notify.js')).notify(uid, n) } catch (e: any) { console.error('[lojas]', e?.message) } }
async function evento(linkId: number, actor: number | null, action: string, detail = '') { await q('INSERT INTO store_link_events (link_id, actor_id, action, detail, created_at) VALUES ($1,$2,$3,$4,$5)', [linkId, actor, action, detail, nowIso()]) }
const nomeLoja = (b: any) => String(J<any>(b?.data, {}).empresa || `Loja #${b?.id}`)

/* ---------- quem pode ---------- */
/** Lojas do próprio usuário que contam para a central (painel liberado: não em pagamento/análise nem recusadas). */
export async function lojasProprias(userId: number) {
  const { gestaoLiberada } = await import('./painel-empresa.js')
  return (await q("SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','recusado') ORDER BY id", [userId]) as any[]).filter((b) => gestaoLiberada(b))
}
export async function exigirLoja(userId: number) { if (!(await lojasProprias(userId)).length) fail(403, 'Para usar Lojas Conectadas, você precisa ter pelo menos uma loja com o painel liberado.', 'sem_loja') }
/** Nível de acesso do usuário numa loja: proprietário, conexão ativa (administrador/operador) ou nenhum. */
export async function papelNaLoja(userId: number | null | undefined, businessId: number): Promise<Papel | null> {
  if (!userId) return null
  const b = await one('SELECT owner_id, status FROM businesses WHERE id = $1', [businessId]); if (!b) return null
  if (b.status === 'lixeira') return null // empresa na lixeira: ninguém administra até ser restaurada
  if (Number(b.owner_id) === Number(userId)) return 'proprietario'
  const l = await one("SELECT role FROM store_links WHERE hub_user_id = $1 AND business_id = $2 AND status = 'ativo'", [userId, businessId])
  return l ? (l.role === 'administrador' ? 'administrador' : 'operador') : null
}
/** Lojas da central: as próprias (proprietário) + as conectadas e ativas. */
export async function lojasDaCentral(userId: number): Promise<{ b: any; papel: Papel; linkId: number | null }[]> {
  const proprias = (await lojasProprias(userId)).map((b) => ({ b, papel: 'proprietario' as Papel, linkId: null as number | null }))
  const ligadas = await q("SELECT l.id AS link_id, l.role, b.* FROM store_links l JOIN businesses b ON b.id = l.business_id WHERE l.hub_user_id = $1 AND l.status = 'ativo' AND b.status <> 'lixeira' ORDER BY l.id", [userId]) as any[]
  return [...proprias, ...ligadas.filter((r) => Number(r.owner_id) !== userId).map((r) => ({ b: r, papel: (r.role === 'administrador' ? 'administrador' : 'operador') as Papel, linkId: Number(r.link_id) }))]
}
/** Ações de pedido permitidas: operador só avança (aceitar, preparar, concluir…); recusar/cancelar é do proprietário ou administrador. */
export const podeTransicao = (papel: Papel | null, to: string) => !!papel && (papel !== 'operador' || !['recusado', 'cancelado'].includes(to))

/* ---------- chaves ---------- */
export async function criarChave(userId: number, o: { horas?: any; usos?: any }) {
  await exigirLoja(userId)
  const horas = Number(o.horas ?? 24), usos = Math.floor(Number(o.usos ?? 1))
  if (!VALIDADES_HORAS.includes(horas as any)) fail(400, 'Validade inválida. Escolha 1 hora, 24 horas, 3 dias, 7 dias ou 30 dias.', 'invalid', 'horas')
  if (!(usos >= 1 && usos <= 10)) fail(400, 'Cada chave pode ser usada de 1 a 10 vezes.', 'invalid', 'usos')
  const ativas = Number((await one('SELECT COUNT(*) AS n FROM store_link_keys WHERE hub_user_id = $1 AND revoked_at IS NULL AND expires_at > $2 AND uses < max_uses', [userId, nowIso()]))?.n || 0)
  if (ativas >= MAX_CHAVES_ATIVAS) fail(429, `Você já tem ${MAX_CHAVES_ATIVAS} chaves válidas. Revogue alguma antes de gerar outra.`, 'limite_chaves')
  const chave = novaChave(), exp = new Date(Date.now() + horas * 3600_000).toISOString()
  const r = await q('INSERT INTO store_link_keys (hub_user_id, key_hash, prefix, max_uses, uses, expires_at, created_at) VALUES ($1,$2,$3,$4,0,$5,$6) RETURNING id', [userId, hash(chave), chave.slice(0, 7), usos, exp, nowIso()])
  await audit(userId, 'lojas.chave.criar', Number(r[0].id), { horas, usos })
  return { id: Number(r[0].id), chave, prefixo: chave.slice(0, 7), expiraEm: exp, usos, horas }
}
const chaveOut = (k: any) => { const exp = Date.parse(String(k.expires_at)) <= Date.now(), gasta = Number(k.uses) >= Number(k.max_uses)
  return { id: Number(k.id), prefixo: k.prefix + '…', usos: Number(k.uses), maxUsos: Number(k.max_uses), expiraEm: k.expires_at, criadaEm: k.created_at, situacao: k.revoked_at ? 'revogada' : exp ? 'expirada' : gasta ? 'usada' : 'valida' } }
export async function listarChaves(userId: number) { return (await q('SELECT * FROM store_link_keys WHERE hub_user_id = $1 ORDER BY id DESC LIMIT 30', [userId])).map(chaveOut) }
export async function revogarChave(userId: number, id: number) {
  const r = await q('UPDATE store_link_keys SET revoked_at = $1 WHERE id = $2 AND hub_user_id = $3 AND revoked_at IS NULL RETURNING id', [nowIso(), id, userId])
  if (!r.length) fail(404, 'Chave não encontrada.', 'not_found')
  await audit(userId, 'lojas.chave.revogar', id, {})
}

/* ---------- conexões ---------- */
const FALHAS = new Map<number, { n: number; desde: number }>()
function falhou(userId: number) { const f = FALHAS.get(userId); const agora = Date.now(); if (!f || agora - f.desde > 15 * 60_000) FALHAS.set(userId, { n: 1, desde: agora }); else f.n++ }
function bloqueado(userId: number) { const f = FALHAS.get(userId); return !!f && Date.now() - f.desde <= 15 * 60_000 && f.n >= 5 }
export const _limparFalhas = () => FALHAS.clear()

/** O DONO da loja usa a chave recebida: cria a solicitação (pendente) para a central aprovar. */
export async function conectar(userId: number, o: { chave?: any; lojaId?: any; papel?: any }) {
  if (bloqueado(userId)) fail(429, 'Muitas tentativas com chave inválida. Aguarde 15 minutos e tente de novo.', 'muitas_tentativas')
  const papel = PAPEIS_LINK.includes(o.papel) ? o.papel : 'operador'
  const loja = await one('SELECT * FROM businesses WHERE id = $1', [Number(o.lojaId)])
  if (!loja || Number(loja.owner_id) !== userId) fail(403, 'Só o proprietário da loja pode conectá-la a uma central.', 'forbidden', 'lojaId')
  const { gestaoLiberada } = await import('./painel-empresa.js'); if (!gestaoLiberada(loja)) fail(403, 'O painel desta loja ainda não foi liberado.', 'forbidden', 'lojaId')
  const n = normalizar(String(o.chave || '')); if (!/^MA[A-Z0-9]{16}$/.test(n)) { falhou(userId); fail(400, 'Chave inválida. Confira e cole a chave completa (MA-XXXX-XXXX-XXXX-XXXX).', 'chave_invalida', 'chave') }
  const k = await one('SELECT * FROM store_link_keys WHERE key_hash = $1', [hash(n)])
  if (!k) { falhou(userId); fail(400, 'Chave não encontrada. Peça uma nova chave à conta central.', 'chave_invalida', 'chave') }
  if (k!.revoked_at) fail(400, 'Esta chave foi revogada.', 'chave_revogada', 'chave')
  if (Date.parse(String(k!.expires_at)) <= Date.now()) fail(400, 'Esta chave expirou. Peça uma nova.', 'chave_expirada', 'chave')
  if (Number(k!.uses) >= Number(k!.max_uses)) fail(400, 'Esta chave já foi utilizada.', 'chave_usada', 'chave')
  const hub = Number(k!.hub_user_id)
  if (hub === userId) fail(400, 'Esta chave é sua: as suas próprias lojas já aparecem na sua central.', 'mesma_conta', 'chave')
  if (await one("SELECT id FROM store_links WHERE hub_user_id = $1 AND business_id = $2 AND status IN ('pendente','ativo')", [hub, loja!.id])) fail(409, 'Esta loja já está conectada (ou aguardando aprovação) a essa central.', 'ja_conectada')
  // uso da chave: incremento atômico (duas pessoas não usam a última vaga ao mesmo tempo)
  const u = await q('UPDATE store_link_keys SET uses = uses + 1 WHERE id = $1 AND uses < max_uses AND revoked_at IS NULL AND expires_at > $2 RETURNING id', [k!.id, nowIso()])
  if (!u.length) fail(400, 'Esta chave já foi utilizada.', 'chave_usada', 'chave')
  let id = 0
  try { id = Number((await q("INSERT INTO store_links (hub_user_id, business_id, owner_id, role, status, key_id, requested_by, created_at, updated_at) VALUES ($1,$2,$3,$4,'pendente',$5,$6,$7,$7) RETURNING id", [hub, loja!.id, userId, papel, k!.id, userId, nowIso()]))[0].id) }
  catch { await q('UPDATE store_link_keys SET uses = uses - 1 WHERE id = $1 AND uses > 0', [k!.id]); fail(409, 'Esta loja já está conectada (ou aguardando aprovação) a essa central.', 'ja_conectada') }
  await evento(id, userId, 'solicitada', `nível ${PAPEL_ROTULO[papel]}`)
  await audit(userId, 'lojas.conexao.solicitar', id, { loja: Number(loja!.id), central: hub, papel })
  await notify(hub, { type: 'loja', title: `Pedido de conexão: ${nomeLoja(loja)}`, body: `A loja quer se conectar à sua central com acesso de ${PAPEL_ROTULO[papel].toLowerCase()}. Aceite ou recuse em Lojas Conectadas.`, link: '/x/lojas-conectadas?aba=conexoes', ref: `link-req:${id}` })
  return { id, status: 'pendente', loja: { id: Number(loja!.id), empresa: nomeLoja(loja) }, papel }
}
async function linkComLoja(id: number) { return one('SELECT l.*, b.data AS bdata, b.owner_id AS bowner FROM store_links l JOIN businesses b ON b.id = l.business_id WHERE l.id = $1', [id]) }
/** A central aceita ou recusa a solicitação. */
export async function decidir(userId: number, id: number, aceitar: boolean) {
  const l = await linkComLoja(id); if (!l || Number(l.hub_user_id) !== userId) fail(404, 'Solicitação não encontrada.', 'not_found')
  const para = aceitar ? 'ativo' : 'recusado'
  const r = await q("UPDATE store_links SET status = $1, decided_by = $2, decided_at = $3, updated_at = $3 WHERE id = $4 AND status = 'pendente' RETURNING id", [para, userId, nowIso(), id])
  if (!r.length) fail(409, 'Esta solicitação já foi decidida.', 'ja_decidida')
  await evento(id, userId, aceitar ? 'aceita' : 'recusada')
  await audit(userId, aceitar ? 'lojas.conexao.aceitar' : 'lojas.conexao.recusar', id, { loja: Number(l!.business_id) })
  const emp = String(J<any>(l!.bdata, {}).empresa || 'Sua loja')
  await notify(Number(l!.bowner), { type: 'loja', title: aceitar ? `Conexão aceita: ${emp}` : `Conexão recusada: ${emp}`, body: aceitar ? 'A central agora acompanha os pedidos e agendamentos desta loja.' : 'A central recusou a conexão. Nada foi alterado na sua loja.', link: '/x/lojas-conectadas?aba=conexoes', ref: `link-dec:${id}` })
}
/** Desvincula (central ou dono da loja). Não apaga dados nem cancela pedidos/agendamentos. */
export async function desvincular(userId: number, id: number) {
  const l = await linkComLoja(id); if (!l || (Number(l.hub_user_id) !== userId && Number(l.bowner) !== userId)) fail(404, 'Conexão não encontrada.', 'not_found')
  const r = await q("UPDATE store_links SET status = 'desvinculado', unlinked_by = $1, unlinked_at = $2, updated_at = $2 WHERE id = $3 AND status IN ('pendente','ativo') RETURNING id", [userId, nowIso(), id])
  if (!r.length) fail(409, 'Esta conexão já foi encerrada.', 'ja_encerrada')
  await evento(id, userId, 'desvinculada')
  await audit(userId, 'lojas.conexao.desvincular', id, { loja: Number(l!.business_id) })
  const outro = Number(l!.hub_user_id) === userId ? Number(l!.bowner) : Number(l!.hub_user_id), emp = String(J<any>(l!.bdata, {}).empresa || 'Loja')
  await notify(outro, { type: 'loja', title: `Loja desconectada: ${emp}`, body: 'A conexão foi encerrada. Pedidos, agendamentos e dados da loja continuam intactos.', link: '/x/lojas-conectadas?aba=conexoes', ref: `link-off:${id}` })
}
/** O dono da loja muda o nível de acesso da central (registrado). */
export async function mudarPapel(userId: number, id: number, papel: any) {
  if (!PAPEIS_LINK.includes(papel)) fail(400, 'Nível inválido: use administrador ou operador.', 'invalid', 'papel')
  const l = await linkComLoja(id); if (!l || Number(l.bowner) !== userId) fail(403, 'Só o proprietário da loja pode mudar o nível de acesso.', 'forbidden')
  if (!['pendente', 'ativo'].includes(l!.status)) fail(409, 'Esta conexão já foi encerrada.', 'ja_encerrada')
  if (l!.role === papel) return
  await q('UPDATE store_links SET role = $1, updated_at = $2 WHERE id = $3', [papel, nowIso(), id])
  await evento(id, userId, 'papel', `${PAPEL_ROTULO[l!.role]} → ${PAPEL_ROTULO[papel]}`)
  await audit(userId, 'lojas.conexao.papel', id, { de: l!.role, para: papel })
  await notify(Number(l!.hub_user_id), { type: 'loja', title: `Nível de acesso alterado: ${String(J<any>(l!.bdata, {}).empresa || 'Loja')}`, body: `Agora: ${PAPEL_ROTULO[papel]}.`, link: '/x/lojas-conectadas?aba=conexoes', ref: `link-papel:${id}:${Date.now()}` })
}
/** Conexões vistas pelo usuário: como central (recebidas) e como dono de loja (enviadas), com o histórico. */
export async function conexoes(userId: number) {
  const rows = await q("SELECT l.*, b.data AS bdata, b.owner_id AS bowner, uh.name AS hub_nome, uo.name AS dono_nome FROM store_links l JOIN businesses b ON b.id = l.business_id LEFT JOIN users uh ON uh.id = l.hub_user_id LEFT JOIN users uo ON uo.id = b.owner_id WHERE l.hub_user_id = $1 OR b.owner_id = $1 ORDER BY l.id DESC LIMIT 100", [userId]) as any[]
  const ev = rows.length ? await q(`SELECT * FROM store_link_events WHERE link_id IN (${rows.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY id`, rows.map((r) => r.id)) as any[] : []
  return rows.map((r) => ({ id: Number(r.id), status: r.status, papel: r.role, papelRotulo: PAPEL_ROTULO[r.role], souCentral: Number(r.hub_user_id) === userId, souDono: Number(r.bowner) === userId,
    loja: { id: Number(r.business_id), empresa: String(J<any>(r.bdata, {}).empresa || ''), logo: J<any>(r.bdata, {}).logo || null }, central: r.hub_nome || '', dono: r.dono_nome || '',
    criadaEm: r.created_at, decididaEm: r.decided_at, desvinculadaEm: r.unlinked_at,
    historico: ev.filter((e) => Number(e.link_id) === Number(r.id)).map((e) => ({ acao: e.action, detalhe: e.detail, em: e.created_at, porMim: Number(e.actor_id) === userId })) }))
}

/* ---------- notificações centralizadas ---------- */
export const CATS = ['pedidos', 'agendamentos', 'atualizacoes'] as const
export async function prefsDe(userId: number, businessId: number): Promise<Record<string, boolean>> {
  const r = await one('SELECT prefs FROM store_notif_prefs WHERE user_id = $1 AND business_id = $2', [userId, businessId])
  const p = J<any>(r?.prefs, {}); return Object.fromEntries(CATS.map((c) => [c, p[c] !== false]))
}
export async function salvarPrefs(userId: number, businessId: number, prefs: any) {
  if (!(await papelNaLoja(userId, businessId))) fail(404, 'Loja não encontrada na sua central.', 'not_found')
  const p = Object.fromEntries(CATS.map((c) => [c, prefs?.[c] !== false]))
  const ex = await one('SELECT 1 AS x FROM store_notif_prefs WHERE user_id = $1 AND business_id = $2', [userId, businessId])
  if (ex) await q('UPDATE store_notif_prefs SET prefs = $1, updated_at = $2 WHERE user_id = $3 AND business_id = $4', [JSON.stringify(p), nowIso(), userId, businessId])
  else await q('INSERT INTO store_notif_prefs (user_id, business_id, prefs, updated_at) VALUES ($1,$2,$3,$4)', [userId, businessId, JSON.stringify(p), nowIso()])
  await audit(userId, 'lojas.notificacoes.preferencias', businessId, p)
  return p
}
const REF_LOJA = /^(?:hub:)?(order-new|order-paid|booking|solic|solic-resp|upd):(\d+)/
/** Loja de origem de uma notificação de pedido/agendamento (pela referência do evento). */
export async function origemDe(ref?: string | null) {
  const m = REF_LOJA.exec(String(ref || '')); if (!m) return null
  const o = await one('SELECT o.business_id, o.data, b.owner_id, b.data AS bdata FROM orders o JOIN businesses b ON b.id = o.business_id WHERE o.id = $1', [Number(m[2])]); if (!o) return null
  const ag = J<any>(o.data, {}).tipo === 'agendamento'
  const cat = m[1] === 'upd' ? 'atualizacoes' : ['booking', 'solic', 'solic-resp'].includes(m[1]) || ag ? 'agendamentos' : 'pedidos'
  return { businessId: Number(o.business_id), ownerId: Number(o.owner_id), empresa: String(J<any>(o.bdata, {}).empresa || 'Loja'), orderId: Number(m[2]), cat, evento: m[1] }
}
/** Quem acompanha mais de uma loja (várias lojas próprias ou alguma conectada) vê o nome da loja em cada aviso. */
export async function centralizado(userId: number) {
  const n = Number((await one("SELECT COUNT(*) AS n FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','recusado','lixeira')", [userId]))?.n || 0)
  if (n >= 2) return true
  return !!(await one("SELECT 1 AS x FROM store_links WHERE hub_user_id = $1 AND status = 'ativo' LIMIT 1", [userId]))
}
/** Repassa o aviso do DONO para as centrais conectadas (uma vez por evento: ref "hub:…" + índice único por usuário). */
export async function repassarCentrais(org: NonNullable<Awaited<ReturnType<typeof origemDe>>>, n: { type: string; title: string; body?: string; ref?: string }) {
  if (org.cat === 'atualizacoes') return // atualizações já são enviadas direto (sem repetir para quem fez a mudança)
  const hubs = await q("SELECT hub_user_id FROM store_links WHERE business_id = $1 AND status = 'ativo'", [org.businessId]) as any[]
  for (const h of hubs) {
    const hub = Number(h.hub_user_id); if (hub === org.ownerId) continue
    await notify(hub, { type: n.type, title: n.title, body: n.body, link: `/x/lojas-conectadas?loja=${org.businessId}&pedido=${org.orderId}`, ref: `hub:${n.ref}` })
  }
}
const ROT_ST: Record<string, string> = { aceito: 'aceito', recusado: 'recusado', preparo: 'em preparo', saiu: 'saiu para entrega', pronto: 'pronto para retirar', concluido: 'concluído', cancelado: 'cancelado', aguardando_aprovacao: 'aguardando aprovação', sugestao: 'novo horário sugerido' }
/** Pedido/agendamento atualizado: avisa o dono e as centrais, menos quem fez a mudança. */
export async function avisarAtualizacao(b: any, oid: number, to: string, atorId: number | null, atorNome = '') {
  try {
    const o = await one('SELECT data FROM orders WHERE id = $1', [oid]); const ag = J<any>(o?.data, {}).tipo === 'agendamento'
    const alvos = [Number(b.owner_id), ...(await q("SELECT hub_user_id FROM store_links WHERE business_id = $1 AND status = 'ativo'", [Number(b.id)]) as any[]).map((r) => Number(r.hub_user_id))]
    for (const uid of [...new Set(alvos)]) {
      if (uid === atorId) continue
      await notify(uid, { type: 'order', title: `${ag ? 'Agendamento' : 'Pedido'} #${oid} ${to === 'cancelado' ? 'cancelado' : 'atualizado: ' + (ROT_ST[to] || to)}`, body: atorNome ? `Alterado por ${atorNome}` : undefined, link: uid === Number(b.owner_id) ? '/x/sua-empresa' : `/x/lojas-conectadas?loja=${b.id}&pedido=${oid}`, ref: `upd:${oid}:${to}` })
    }
  } catch (e: any) { console.error('[lojas]', e?.message) }
}
