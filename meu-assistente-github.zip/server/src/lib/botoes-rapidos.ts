/* Botões rápidos do chat principal (configurados no painel administrativo → Botões rápidos).
   • No máximo 3 botões, em lista vertical logo acima do campo de digitação.
   • Cada botão: texto, comando (enviado ao motor principal do chat, como se o usuário tivesse digitado), ícone,
     cor do ícone e cor do texto ('' = padrão: ícone cinza discreto e texto na cor do tema), ativo/inativo.
   • A ordem da lista é a posição no chat (1º em cima).
   • Configurações antigas ({ custom, items: string[] }) são convertidas sem perder nada. */
import { fail } from './http.js'

export const QB_MAX = 3
export const QB_AZUL = '#1677FF'
/** Ícones disponíveis (o desenho de cada um fica em frontend/public/botoes-rapidos.js). */
export const QB_ICONES = ['loja', 'calendario', 'checklist', 'sino', 'carteira', 'carrinho', 'busca', 'grafico', 'moeda', 'pedido', 'tarefa', 'recibo', 'chat', 'estrela', 'local', 'relogio', 'casa', 'presente'] as const
/** Paleta sugerida no painel (qualquer cor #RRGGBB também é aceita). */
export const QB_CORES = [
  { id: 'padrao', nome: 'Padrão', valor: '' },
  { id: 'azul', nome: 'Azul', valor: QB_AZUL },
  { id: 'verde', nome: 'Verde', valor: '#22C55E' },
  { id: 'ambar', nome: 'Âmbar', valor: '#F5A524' },
  { id: 'rosa', nome: 'Rosa', valor: '#F43F5E' },
  { id: 'roxo', nome: 'Roxo', valor: '#A855F7' },
  { id: 'cinza', nome: 'Cinza', valor: '#8E8E93' },
  { id: 'branco', nome: 'Branco', valor: '#FFFFFF' },
]

export interface QbItem { id: string; ativo: boolean; preset: string | null; texto: string; comando: string; icone: string; corIcone: string; corTexto: string }
export interface QbConfig { v: 2; enabled: boolean; items: QbItem[] }

/** Ações prontas: o comando de cada uma é tratado pelo motor do chat (módulos, finanças, agenda, busca, IA). */
export const QB_PRESETS: Omit<QbItem, 'id' | 'ativo'>[] = [
  { preset: 'lojas', texto: 'Lojas', comando: 'Lojas perto de mim', icone: 'loja', corIcone: QB_AZUL, corTexto: QB_AZUL },
  { preset: 'agendar', texto: 'Agendar compromisso', comando: 'Quero agendar um compromisso', icone: 'calendario', corIcone: '', corTexto: '' },
  { preset: 'organizar', texto: 'Organizar meu dia', comando: 'Quero organizar meu dia de hoje', icone: 'checklist', corIcone: '', corTexto: '' },
  { preset: 'lembrete', texto: 'Criar lembrete', comando: 'Criar lembrete', icone: 'sino', corIcone: '', corTexto: '' },
  { preset: 'gasto', texto: 'Registrar gasto', comando: 'Registrar gasto', icone: 'carteira', corIcone: '', corTexto: '' },
  { preset: 'buscar', texto: 'Buscar produtos', comando: 'Quero encontrar produtos', icone: 'busca', corIcone: '', corTexto: '' },
  { preset: 'financas', texto: 'Gastos do mês', comando: 'Quanto gastei esse mês?', icone: 'grafico', corIcone: '', corTexto: '' },
  { preset: 'contas', texto: 'Contas a pagar', comando: 'Contas a pagar', icone: 'recibo', corIcone: '', corTexto: '' },
  { preset: 'tarefas', texto: 'Minhas tarefas', comando: 'Minhas tarefas', icone: 'tarefa', corIcone: '', corTexto: '' },
  { preset: 'compras', texto: 'Lista de compras', comando: 'Lista de compras', icone: 'carrinho', corIcone: '', corTexto: '' },
  { preset: 'pedidos', texto: 'Meus pedidos', comando: 'Meus pedidos', icone: 'pedido', corIcone: '', corTexto: '' },
  { preset: 'cotacoes', texto: 'Cotação do Bitcoin', comando: 'Como está o Bitcoin hoje?', icone: 'moeda', corIcone: '', corTexto: '' },
]
const PADRAO = ['lojas', 'agendar', 'organizar']
const novoId = () => 'qb' + Math.random().toString(36).slice(2, 9)
const doPreset = (k: string, id?: string): QbItem => ({ id: id || novoId(), ativo: true, ...QB_PRESETS.find((p) => p.preset === k)! })
export const qbPadrao = (): QbConfig => ({ v: 2, enabled: true, items: PADRAO.map((k, i) => doPreset(k, 'qb-' + k)) })

const cor = (v: unknown) => { const s = String(v ?? '').trim(); return /^#[0-9a-f]{6}$/i.test(s) ? s.toUpperCase() : '' }
const txt = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n)

/** Lê o que está salvo (formato novo ou antigo) e devolve sempre o formato novo, válido. */
export function qbNormalizar(raw: any): QbConfig {
  if (!raw || typeof raw !== 'object') return qbPadrao()
  if (raw.v === 2 && Array.isArray(raw.items)) {
    const items = raw.items.slice(0, QB_MAX).map((it: any) => ({ id: /^[\w-]{1,24}$/.test(String(it?.id)) ? String(it.id) : novoId(), ativo: it?.ativo !== false, preset: QB_PRESETS.some((p) => p.preset === it?.preset) ? String(it.preset) : null, texto: txt(it?.texto, 40), comando: txt(it?.comando, 200), icone: (QB_ICONES as readonly string[]).includes(it?.icone) ? String(it.icone) : 'chat', corIcone: cor(it?.corIcone), corTexto: cor(it?.corTexto) })).filter((it: QbItem) => it.texto && it.comando)
    return { v: 2, enabled: raw.enabled !== false, items }
  }
  // formato antigo: lista de frases (só valia com "Usar a minha lista" ligado)
  const base = qbPadrao(); base.enabled = raw.enabled !== false
  if (raw.custom && Array.isArray(raw.items)) {
    const frases = raw.items.map((x: unknown) => txt(x, 200)).filter(Boolean).slice(0, QB_MAX)
    if (frases.length) base.items = frases.map((f: string) => ({ id: novoId(), ativo: true, preset: null, texto: f.slice(0, 40), comando: f, icone: 'chat', corIcone: '', corTexto: '' }))
  }
  return base
}

/** Validação do que o painel envia (erros claros em vez de cortar em silêncio). */
export function qbValidar(b: any): QbConfig {
  const lista = Array.isArray(b?.items) ? b.items : []
  if (lista.length > QB_MAX) fail(400, `São no máximo ${QB_MAX} botões rápidos.`, 'invalid')
  const items: QbItem[] = lista.map((it: any, i: number) => {
    const texto = txt(it?.texto, 40), comando = txt(it?.comando, 200)
    if (!texto) fail(400, `Botão ${i + 1}: escreva o texto do botão.`, 'invalid')
    if (!comando) fail(400, `Botão ${i + 1} (“${texto}”): escreva o comando que ele envia ao chat.`, 'invalid')
    if (it?.icone && !(QB_ICONES as readonly string[]).includes(it.icone)) fail(400, `Botão ${i + 1}: ícone inválido.`, 'invalid')
    for (const k of ['corIcone', 'corTexto']) if (it?.[k] && !cor(it[k])) fail(400, `Botão ${i + 1}: cor inválida (use o formato #RRGGBB).`, 'invalid')
    return { id: /^[\w-]{1,24}$/.test(String(it?.id)) ? String(it.id) : novoId(), ativo: it?.ativo !== false, preset: QB_PRESETS.some((p) => p.preset === it?.preset) ? String(it.preset) : null, texto, comando, icone: it?.icone ? String(it.icone) : 'chat', corIcone: cor(it?.corIcone), corTexto: cor(it?.corTexto) }
  })
  const ids = new Set(items.map((x) => x.id)); if (ids.size !== items.length) items.forEach((x) => { x.id = novoId() })
  return { v: 2, enabled: b?.enabled !== false, items }
}

/** O que o chat recebe: só os botões ativos, na ordem. */
export const qbPublico = (c: QbConfig) => ({ v: 2, enabled: c.enabled, items: c.items.filter((x) => x.ativo).map(({ id, texto, comando, icone, corIcone, corTexto }) => ({ id, texto, comando, icone, corIcone, corTexto })) })
