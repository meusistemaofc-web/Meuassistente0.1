// Vinculação e troca rápida de empresas (estilo "trocar de conta").
// Modelo: o usuário P (sessão atual) vincula UMA empresa de outra conta Q depois de provar acesso à conta Q (e-mail e senha,
// mais o código do 2FA quando a conta tiver). O servidor guarda só a relação (empresa_vinculos) — nunca a senha, nem cookie ou
// token da conta Q. Nas trocas não há nova senha: a cada requisição do painel DAQUELA empresa, o servidor confere o vínculo e
// executa a rota como dono da empresa (delegação), restrita ao que a rota da empresa pode fazer. Tudo o mais continua sendo
// da conta de P: chat pessoal, agenda, finanças e dados de Q ficam inacessíveis.
//  • delegação só quando o cabeçalho X-MA-Empresa for igual ao id da empresa na própria URL (rota do painel da empresa);
//  • o usuário delegado é SEMPRE comum (sem papel de administrador, sem permissões extras, sem segredos da conta);
//  • exclusão da empresa, pagamento/renovação do plano e recebimento (Mercado Pago) exigem entrar na conta dona;
//  • o vínculo é suspenso sozinho se a senha da conta dona mudar, se a empresa trocar de dono ou for para a lixeira, ou
//    se a conta dona for desativada;
//  • toda ação de escrita feita por delegação fica na auditoria (quem, qual empresa, método e rota — sem o corpo).
import { q, one, nowIso, J } from '../db/index.js'
import { HttpError, fail, type Ctx } from './http.js'
import { sha256, token, verifyPassword, hashPassword, rateLimit } from './security.js'
import { requireUser, hydrateUser, type SessionUser } from './session.js'

export const MAX_VINCULOS = 20
const FORA = "('institucional','lixeira')"
const stamp = (passwordHash: string) => sha256('vinculo:' + passwordHash)
const audit = async (uid: number | null, acao: string, alvo: number | null, meta: object) => { try { await (await import('./account.js')).audit(uid, acao, alvo, meta) } catch (e: any) { console.error('[vínculos] auditoria falhou:', e?.message) } }
export const mascararEmail = (e: string) => { const [a, d] = String(e || '').split('@'); return a && d ? `${a.slice(0, 1)}${'•'.repeat(Math.max(2, Math.min(6, a.length - 1)))}@${d}` : '' }

export type Situacao = 'ok' | 'nao_vinculada' | 'empresa_indisponivel' | 'dono_mudou' | 'conta_desativada' | 'reautenticar'
const MSG: Record<Situacao, string> = {
  ok: '', nao_vinculada: 'Esta empresa não está vinculada à sua conta.', empresa_indisponivel: 'A empresa vinculada não está mais disponível.',
  dono_mudou: 'A empresa mudou de dono. Refaça o vínculo.', conta_desativada: 'A conta dona da empresa está desativada.', reautenticar: 'A senha da conta dona foi alterada. Refaça o vínculo para continuar.',
}
/** Confere um vínculo: existe, a empresa continua válida e do mesmo dono, a conta dona está ativa e a senha dela não mudou. */
export async function validar(userId: number, businessId: number): Promise<{ ok: true; owner: any; biz: any; vinculo: any } | { ok: false; codigo: Situacao; motivo: string }> {
  const v = await one('SELECT * FROM empresa_vinculos WHERE user_id = $1 AND business_id = $2', [userId, businessId])
  const no = (codigo: Situacao) => ({ ok: false as const, codigo, motivo: MSG[codigo] })
  if (!v) return no('nao_vinculada')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [businessId])
  if (!b || ['lixeira', 'institucional'].includes(String(b.status))) return no('empresa_indisponivel')
  if (Number(b.owner_id) !== Number(v.owner_id)) return no('dono_mudou')
  const o = await one('SELECT * FROM users WHERE id = $1', [b.owner_id])
  if (!o || o.status !== 'active') return no('conta_desativada')
  if (stamp(String(o.password_hash)) !== v.auth_stamp) return no('reautenticar')
  return { ok: true, owner: o, biz: b, vinculo: v }
}
/** Empresas vinculadas e válidas do usuário (linhas completas de businesses), para listar ao lado das próprias. */
export async function vinculadasValidas(userId: number): Promise<any[]> {
  const rows = await q(`SELECT b.*, v.auth_stamp AS v_stamp, o.password_hash AS o_hash, o.status AS o_status FROM empresa_vinculos v JOIN businesses b ON b.id = v.business_id AND b.owner_id = v.owner_id JOIN users o ON o.id = v.owner_id WHERE v.user_id = $1 AND b.status NOT IN ${FORA} ORDER BY v.id DESC`, [userId])
  return rows.filter((r: any) => r.o_status === 'active' && stamp(String(r.o_hash)) === r.v_stamp).map(({ v_stamp, o_hash, o_status, ...b }: any) => b)
}

/* ---------- delegação por requisição ---------- */
/** Rota do painel de UMA empresa (id na URL). `bloqueado`: ação que só vale entrando na conta dona. Rotas públicas (pedidos,
 *  agendamentos, vitrine) e as que não trazem o id da empresa NUNCA são delegadas. */
export function escopoEmpresa(method: string, path: string): { id: string; bloqueado: boolean } | null {
  let m = path.match(/^\/api\/v2\/ads\/(\d+)(\/.*)?$/)
  if (m) {
    const rest = m[2] || ''
    const bloq = (!rest && method === 'DELETE') || /^\/(excluir|renew|pay|cupom|mp)(\/|$)/.test(rest) || /^\/agent\/(pay|transferir|cupom)(\/|$)/.test(rest) || (/^\/recebimento(\/|$)/.test(rest) && method !== 'GET')
    return { id: m[1], bloqueado: bloq }
  }
  m = path.match(/^\/api\/v2\/businesses\/(\d+)\/(coupons|coin|crm|bi|solicitacoes)(\/.*)?$/)
  if (m) { if (m[2] === 'coupons' && /^\/(public|validate)$/.test(m[3] || '')) return null; return { id: m[1], bloqueado: false } }
  return null
}
function usuarioDelegado(owner: any): SessionUser {
  // comum e sem segredos: quem opera por vínculo nunca ganha papel de administrador nem acesso a credenciais da conta dona
  return { ...hydrateUser(owner), role: 'user', permissions: [], mfa_secret: null, mfa_pending_secret: null, backup_codes: [], password_hash: '' }
}
export async function delegar(ctx: Ctx) {
  const h = String(ctx.req.headers['x-ma-empresa'] || '').trim(); if (!h) return
  const u = ctx.user; if (!u || !ctx.session || ctx.session.mfa_pending || ctx.session.recovery || u.status !== 'active') return
  const esc = escopoEmpresa(ctx.method, ctx.path); if (!esc || esc.id !== h) return // o cabeçalho só vale para a empresa da própria URL
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [Number(h)])
  if (!b || Number(b.owner_id) === Number(u.id)) return // empresa própria (ou inexistente): nada a delegar
  if (esc.bloqueado) throw new HttpError(403, 'Esta ação só pode ser feita entrando na conta dona da empresa (pagamento, exclusão e recebimento).', 'vinculo_acao_bloqueada')
  const r = await validar(Number(u.id), Number(h))
  if (!r.ok) { if (r.codigo === 'nao_vinculada') return; throw new HttpError(403, r.motivo, 'vinculo_' + r.codigo) } // sem vínculo: segue como antes (a rota nega: empresa alheia)
  ;(ctx as any).delegadoPor = u
  ctx.user = usuarioDelegado(r.owner)
  if (ctx.method !== 'GET' && ctx.method !== 'HEAD') void audit(Number(u.id), 'vinculo.acao', Number(h), { metodo: ctx.method, rota: ctx.path.replace(/\d{6,}/g, '#') })
}

/* ---------- vincular: autenticar → escolher → confirmar ---------- */
interface Ticket { userId: number; sessionId: string; ownerId: number; stamp: string; ids: Set<number>; exp: number }
const tickets = new Map<string, Ticket>() // vida curta, só em memória: nada que dê acesso fica gravado
const limpa = () => { const n = Date.now(); for (const [k, t] of tickets) if (t.exp < n) tickets.delete(k) }
const cartao = (b: any) => { const d = J<any>(b.data, {}); return { id: Number(b.id), nome: String(d.empresa || 'Empresa'), categoria: String(d.categoria || d.ramo || ''), logo: d.logo || null, status: String(b.status) } }

export async function vinculosAutenticar(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const email = String(b.email || '').trim().toLowerCase().slice(0, 254), senha = String(b.password || '')
  if (!rateLimit(`vinculo:${u.id}`, 8, 15 * 60_000) || !rateLimit(`login:${email}`, 8, 15 * 60_000)) fail(429, 'Muitas tentativas. Aguarde alguns minutos e tente de novo.', 'rate_limited')
  if (!email || !senha) fail(400, 'Informe o e-mail e a senha da conta.', 'invalid')
  if ((await one('SELECT COUNT(*) AS n FROM empresa_vinculos WHERE user_id = $1', [u.id]) as any)?.n >= MAX_VINCULOS) fail(400, `Você já vinculou o máximo de ${MAX_VINCULOS} empresas.`, 'limite')
  const row = await one('SELECT * FROM users WHERE email = $1', [email])
  const ok = row ? await verifyPassword(senha, row.password_hash) : await hashPassword('x').then(() => false) // mesmo custo com ou sem conta: não revela se o e-mail existe
  if (!row || !ok) fail(400, 'E-mail ou senha incorretos.', 'invalid_credentials') // 400 (não 401): o app trata 401 como sessão expirada e sairia da tela
  const dono = hydrateUser(row)
  if (dono.status !== 'active') fail(403, 'Esta conta está desativada. Fale com o administrador.', 'account_disabled')
  if (Number(dono.id) === Number(u.id)) fail(400, 'Esta é a sua própria conta: as empresas dela já aparecem na lista.', 'mesma_conta')
  if (dono.mfa_enabled) {
    const code = String(b.code || '').trim().toUpperCase()
    if (!code) return { mfaRequired: true }
    const { consumeMfaCode } = await import('../routes/auth.js')
    if (!(await consumeMfaCode(dono, code))) fail(400, 'Código inválido.', 'invalid_code', 'code')
  }
  const rows = await q(`SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ${FORA} ORDER BY id DESC`, [dono.id])
  const ja = new Set((await q('SELECT business_id FROM empresa_vinculos WHERE user_id = $1', [u.id])).map((r: any) => Number(r.business_id)))
  if (!rows.length) fail(404, 'Esta conta não possui empresa para vincular.', 'sem_empresa')
  limpa(); const t = token(24)
  tickets.set(sha256(t), { userId: Number(u.id), sessionId: ctx.session!.id, ownerId: Number(dono.id), stamp: stamp(row.password_hash), ids: new Set(rows.map((r: any) => Number(r.id))), exp: Date.now() + 5 * 60_000 })
  await audit(Number(u.id), 'vinculo.autenticar', Number(dono.id), { empresas: rows.length })
  return { ticket: t, conta: { nome: dono.name, email: mascararEmail(dono.email) }, empresas: rows.map((r: any) => ({ ...cartao(r), jaVinculada: ja.has(Number(r.id)) })), expiraEm: 300 }
}

export async function vinculosConfirmar(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  limpa(); const k = sha256(String(b.ticket || '')), t = tickets.get(k)
  if (!t || t.userId !== Number(u.id) || t.sessionId !== ctx.session!.id || t.exp < Date.now()) fail(400, 'A autenticação expirou. Entre novamente com o e-mail e a senha da conta.', 'ticket_invalido')
  const ids: number[] = [...new Set<number>((Array.isArray(b.businessIds) ? b.businessIds : [b.businessId]).map(Number).filter((x: number) => Number.isInteger(x) && x > 0))]
  if (!ids.length) fail(400, 'Escolha a empresa que será vinculada.', 'invalid', 'businessId')
  if (ids.some((i) => !t.ids.has(i))) fail(403, 'Empresa não autorizada nesta autenticação.', 'forbidden')
  const dono = await one('SELECT * FROM users WHERE id = $1', [t.ownerId])
  if (!dono || dono.status !== 'active' || stamp(String(dono.password_hash)) !== t.stamp) { tickets.delete(k); fail(400, 'A conta mudou desde a autenticação. Tente de novo.', 'ticket_invalido') } // senha trocada no meio do caminho
  const feitas: number[] = []
  for (const id of ids) {
    const emp = await one(`SELECT id FROM businesses WHERE id = $1 AND owner_id = $2 AND status NOT IN ${FORA}`, [id, t.ownerId]) // propriedade conferida de novo no servidor
    if (!emp) continue
    if (await one('SELECT id FROM empresa_vinculos WHERE user_id = $1 AND business_id = $2', [u.id, id])) { await q('UPDATE empresa_vinculos SET auth_stamp = $1, owner_id = $2 WHERE user_id = $3 AND business_id = $4', [t.stamp, t.ownerId, u.id, id]); feitas.push(id); continue } // refaz vínculo suspenso, sem duplicar
    if ((await one('SELECT COUNT(*) AS n FROM empresa_vinculos WHERE user_id = $1', [u.id]) as any).n >= MAX_VINCULOS) break
    await q('INSERT INTO empresa_vinculos (user_id, business_id, owner_id, auth_stamp, created_at) VALUES ($1,$2,$3,$4,$5)', [u.id, id, t.ownerId, t.stamp, nowIso()]); feitas.push(id)
  }
  tickets.delete(k)
  if (!feitas.length) fail(400, 'Nenhuma empresa foi vinculada.', 'invalid')
  await audit(Number(u.id), 'vinculo.criar', t.ownerId, { empresas: feitas })
  await q('INSERT INTO empresa_contexto (user_id, business_id, updated_at) VALUES ($1,$2,$3) ON CONFLICT (user_id) DO UPDATE SET business_id = EXCLUDED.business_id, updated_at = EXCLUDED.updated_at', [u.id, feitas[0], nowIso()])
  return { ok: true, vinculadas: feitas, ativa: feitas[0] }
}

export async function vinculosDesvincular(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id)
  const v = await one('SELECT id, owner_id FROM empresa_vinculos WHERE user_id = $1 AND business_id = $2', [u.id, id]); if (!v) fail(404, 'Esta empresa não está vinculada à sua conta.', 'not_found')
  await q('DELETE FROM empresa_vinculos WHERE id = $1', [v.id]) // só a relação: a empresa, a conta dona e os dados continuam intactos
  await q('UPDATE empresa_contexto SET business_id = NULL, updated_at = $1 WHERE user_id = $2 AND business_id = $3', [nowIso(), u.id, id])
  await audit(Number(u.id), 'vinculo.remover', Number(v.owner_id), { empresa: id })
  return { ok: true }
}

/* ---------- contexto: lista de empresas e última escolhida ---------- */
export async function contextoGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const proprias = await q(`SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ${FORA} ORDER BY id DESC`, [u.id])
  const vincs = await q('SELECT v.*, o.email AS o_email, o.name AS o_name FROM empresa_vinculos v JOIN users o ON o.id = v.owner_id WHERE v.user_id = $1 ORDER BY v.id DESC', [u.id])
  const itens: any[] = proprias.map((b: any) => ({ ...cartao(b), vinculada: false, situacao: 'ok' as Situacao, conta: null }))
  for (const v of vincs) {
    const r = await validar(Number(u.id), Number(v.business_id))
    const b = r.ok ? r.biz : await one('SELECT * FROM businesses WHERE id = $1', [v.business_id])
    if (!b) continue
    itens.push({ ...cartao(b), vinculada: true, situacao: r.ok ? 'ok' : r.codigo, aviso: r.ok ? '' : r.motivo, conta: mascararEmail(v.o_email) })
  }
  const c = await one('SELECT business_id FROM empresa_contexto WHERE user_id = $1', [u.id])
  const ativa = c?.business_id != null && itens.some((i) => i.id === Number(c.business_id) && i.situacao === 'ok') ? Number(c.business_id) : null
  return { ativa, itens, limite: MAX_VINCULOS }
}
export async function contextoPut(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.body?.businessId)
  if (!Number.isInteger(id) || id <= 0) fail(400, 'Escolha uma empresa.', 'invalid', 'businessId')
  const propria = await one(`SELECT id FROM businesses WHERE id = $1 AND owner_id = $2 AND status NOT IN ${FORA}`, [id, u.id])
  if (!propria) {
    const r = await validar(Number(u.id), id); if (!r.ok) fail(403, r.motivo, 'vinculo_' + r.codigo)
    await q('UPDATE empresa_vinculos SET last_used_at = $1 WHERE id = $2', [nowIso(), r.vinculo.id])
  }
  await q('INSERT INTO empresa_contexto (user_id, business_id, updated_at) VALUES ($1,$2,$3) ON CONFLICT (user_id) DO UPDATE SET business_id = EXCLUDED.business_id, updated_at = EXCLUDED.updated_at', [u.id, id, nowIso()])
  return contextoGet(ctx)
}
