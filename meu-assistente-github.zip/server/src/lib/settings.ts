// Configurações persistentes (tabela app_config) e cofre para chaves secretas (AES-256-GCM).
import { createCipheriv, createDecipheriv, randomBytes, createHash } from 'node:crypto'
import { one, q, J, nowIso, memoRequisicao } from '../db/index.js'

export async function getConfig<T>(key: string, fallback: T): Promise<T> {
  const m = memoRequisicao(), k = 'cfg:' + key
  let raw: unknown
  if (m && m.has(k)) raw = m.get(k)
  else { const r = await one('SELECT value FROM app_config WHERE key = $1', [key]); raw = r ? r.value : null; m?.set(k, raw) }
  if (raw == null) return fallback
  return J<T>(typeof raw === 'string' ? raw : structuredClone(raw), fallback) // sempre um objeto novo: quem altera o retorno não altera a memória
}
/** Busca várias chaves numa só consulta e guarda na memória da requisição (chaves ausentes ficam como "sem valor"). */
export async function prefetchConfig(keys: string[]) {
  const m = memoRequisicao(); if (!m || !keys.length) return
  const falta = keys.filter((k) => !m.has('cfg:' + k)); if (!falta.length) return
  const rows = await q(`SELECT key, value FROM app_config WHERE key IN (${falta.map((_, i) => '$' + (i + 1)).join(',')})`, falta)
  const achou = new Map(rows.map((r: any) => [String(r.key), r.value]))
  for (const k of falta) m.set('cfg:' + k, achou.has(k) ? achou.get(k) : null)
}
export async function setConfig(key: string, value: unknown) {
  const v = JSON.stringify(value)
  memoRequisicao()?.delete('cfg:' + key)
  const ex = await one('SELECT key FROM app_config WHERE key = $1', [key])
  if (ex) await q('UPDATE app_config SET value = $1, updated_at = $2 WHERE key = $3', [v, nowIso(), key])
  else await q('INSERT INTO app_config (key, value, updated_at) VALUES ($1,$2,$3)', [key, v, nowIso()])
}

/* ---------------------------------------------------------------------------------------------- COFRE
 * Credenciais (tokens do Mercado Pago, senha SMTP, chaves de IA…) são cifradas com AES-256-GCM.
 * CAUSA DO "SUMIÇO" DE INTEGRAÇÕES APÓS ATUALIZAR: a chave vinha de UMA fonte só — APP_SECRET (.env) se existisse,
 * senão a chave guardada no banco. Recriar o .env a partir do .env.example, preencher APP_SECRET depois, trocá-lo ou
 * removê-lo mudava a chave em silêncio: os dados continuavam no banco, mas nada mais abria (unseal devolvia vazio) e as
 * integrações apareciam como desconectadas.
 * AGORA (chaveiro):
 *  • todas as chaves conhecidas são tentadas na leitura: APP_SECRET, APP_SECRET_ANTERIOR (lista separada por vírgula) e a
 *    chave do banco (app_config "vault-key") — acrescentar ou trocar APP_SECRET não deixa o que já existe ilegível;
 *  • o que é cifrado de agora em diante leva a identificação da chave ("v2:<id>:…"), e as chaves usadas ficam
 *    registradas (só a impressão digital, nunca a chave) em app_config "cofre_chaves" para o diagnóstico apontar a falta;
 *  • a chave do banco nunca é recriada se já houver dado cifrado (antes, uma chave nova era gerada e gravada por cima,
 *    tornando tudo ilegível para sempre). Sem chave utilizável, nada é cifrado com chave provisória: a gravação falha
 *    com mensagem clara e os dados antigos ficam intactos;
 *  • diagnosticoCofre() conta credenciais ilegíveis e diz qual chave falta (painel e log ao iniciar).
 * A cifra continua igual (AES-256-GCM, IV aleatório). Valores "v1:" antigos seguem válidos. */
type Chave = { kid: string; key: Buffer; origem: string }
let chaves: Chave[] | null = null, semChave = false
const kidDe = (k: Buffer) => createHash('sha256').update(Buffer.concat([Buffer.from('ma-kid:'), k])).digest('hex').slice(0, 12)
const derivar = (seed: string) => createHash('sha256').update(seed).digest()
/** Algum valor cifrado guardado? (só é consultado quando não há NENHUMA chave disponível) */
async function existeCifrado(): Promise<boolean> {
  const tem = (v: unknown) => /"?v[12]:[A-Za-z0-9+/=:]{20,}/.test(typeof v === 'string' ? v : JSON.stringify(v ?? ''))
  for (const sql of ['SELECT value AS v FROM app_config', 'SELECT data AS v FROM businesses', 'SELECT dados AS v FROM empresa_integracoes', 'SELECT value AS v FROM user_modules'])
    try { if ((await q(sql)).some((r: any) => tem(r.v))) return true } catch { /* tabela ainda não existe */ }
  return false
}
async function chaveiro(): Promise<Chave[]> {
  if (chaves) return chaves
  const lista: Chave[] = []
  const add = (seed: string, origem: string) => { const key = derivar(seed), kid = kidDe(key); if (!lista.some((c) => c.kid === kid)) lista.push({ kid, key, origem }) }
  const s = process.env.APP_SECRET || ''
  if (s.length >= 16) add(s, 'APP_SECRET')
  const banco = await getConfig<string>('vault-key', '')
  if (banco && !lista.length) add(banco, 'banco') // sem APP_SECRET a chave do banco é a principal (como sempre foi)
  for (const x of String(process.env.APP_SECRET_ANTERIOR || '').split(',').map((t) => t.trim()).filter((t) => t.length >= 16)) add(x, 'APP_SECRET_ANTERIOR')
  if (banco) add(banco, 'banco') // e continua valendo para ler o que foi cifrado com ela
  if (!lista.length) {
    if (await existeCifrado()) { semChave = true; console.error('[cofre] ATENÇÃO: há credenciais cifradas, mas nenhuma chave disponível (APP_SECRET vazio e a chave do banco não existe). Nada foi apagado. Restaure APP_SECRET (ou APP_SECRET_ANTERIOR) ou a linha "vault-key" do backup.'); return (chaves = []) }
    const k = randomBytes(32).toString('hex'); await setConfig('vault-key', k); add(k, 'banco') // primeira instalação
  }
  return (chaves = lista)
}
/** Esquece as chaves em memória (testes e troca de APP_SECRET sem reiniciar). */
export function recarregarCofre() { chaves = null; semChave = false; registradas.clear() }
const registradas = new Set<string>()
async function registrar(c: Chave) {
  if (registradas.has(c.kid)) return
  const reg = await getConfig<any[]>('cofre_chaves', [])
  if (!reg.some((x) => x.kid === c.kid)) { reg.push({ kid: c.kid, origem: c.origem, desde: nowIso() }); await setConfig('cofre_chaves', reg) }
  registradas.add(c.kid)
}
export async function seal(plain: string): Promise<string> {
  if (!plain) return ''
  const ks = await chaveiro()
  if (!ks.length) throw new Error('O cofre de credenciais está sem chave (APP_SECRET/chave do banco ausente). Por segurança nada foi gravado; restaure a chave anterior.')
  const c0 = ks[0]; await registrar(c0)
  const iv = randomBytes(12)
  const c = createCipheriv('aes-256-gcm', c0.key, iv)
  const enc = Buffer.concat([c.update(plain, 'utf8'), c.final()])
  return `v2:${c0.kid}:` + Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64')
}
const abrir = (key: Buffer, b: Buffer) => { const d = createDecipheriv('aes-256-gcm', key, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8') }
/** Abre um valor cifrado. { ok:false } = existe, mas nenhuma chave disponível abre (nada é apagado). */
export async function unsealInfo(sealed: string): Promise<{ ok: boolean; valor: string; kid?: string }> {
  if (!sealed) return { ok: true, valor: '' }
  const ks = await chaveiro().catch(() => [] as Chave[])
  const m = /^v2:([a-f0-9]{12}):(.+)$/.exec(sealed)
  if (m) { const c = ks.find((x) => x.kid === m[1]); if (c) try { return { ok: true, valor: abrir(c.key, Buffer.from(m[2], 'base64')), kid: c.kid } } catch { /* corrompido */ } return { ok: false, valor: '', kid: m[1] } }
  if (sealed.startsWith('v1:')) { const b = Buffer.from(sealed.slice(3), 'base64'); for (const c of ks) try { return { ok: true, valor: abrir(c.key, b), kid: c.kid } } catch { /* tenta a próxima */ } return { ok: false, valor: '' } }
  return { ok: false, valor: '' }
}
export async function unseal(sealed: string): Promise<string> { return (await unsealInfo(sealed)).valor }
/** Diagnóstico do cofre: quantas credenciais abrem e quais não (por chave). Nunca devolve valores. */
export async function diagnosticoCofre() {
  const ks = await chaveiro().catch(() => [] as Chave[]), reg = await getConfig<any[]>('cofre_chaves', [])
  const achados: string[] = []
  const varre = (v: unknown) => { const t = typeof v === 'string' ? v : JSON.stringify(v ?? ''); for (const m of t.matchAll(/v1:[A-Za-z0-9+/=]{20,}|v2:[a-f0-9]{12}:[A-Za-z0-9+/=]{20,}/g)) achados.push(m[0]) }
  for (const sql of ['SELECT value AS v FROM app_config', 'SELECT dados AS v FROM empresa_integracoes', 'SELECT value AS v FROM user_modules']) try { for (const r of await q(sql)) varre((r as any).v) } catch { /* tabela ausente */ }
  let ilegiveis = 0; const faltam = new Set<string>()
  for (const v of achados) { const r = await unsealInfo(v); if (!r.ok) { ilegiveis++; if (r.kid) faltam.add(r.kid) } }
  const chavesFaltando = [...faltam].map((kid) => ({ kid, origem: reg.find((x) => x.kid === kid)?.origem || 'desconhecida', desde: reg.find((x) => x.kid === kid)?.desde || null }))
  return { ok: !semChave && ilegiveis === 0, semChave, chaves: ks.map((c, i) => ({ kid: c.kid, origem: c.origem, principal: i === 0 })), total: achados.length, ilegiveis, chavesFaltando,
    mensagem: semChave ? 'Há credenciais cifradas, mas nenhuma chave está disponível. Restaure APP_SECRET (ou APP_SECRET_ANTERIOR) ou a chave do banco a partir do backup. Nada foi apagado.'
      : ilegiveis ? `${ilegiveis} credencial(is) salva(s) não abre(m) com as chaves atuais${chavesFaltando.some((c) => c.origem.startsWith('APP_SECRET')) ? ': o APP_SECRET usado antes foi trocado ou removido. Coloque o valor antigo em APP_SECRET_ANTERIOR no .env e reinicie' : ''}. Nada foi apagado.` : 'Todas as credenciais salvas abrem normalmente.' }
}
export const maskSecret = (s: string) => (s ? s.slice(0, 6) + '••••' + s.slice(-4) : '')
