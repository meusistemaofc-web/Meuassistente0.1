// Organização do menu do usuário ("Organizar módulos"): settings.menuLayout = { main: [...ids], projects: [...ids] }.
// Fonte ÚNICA do que aparece no menu lateral e em que ordem (o app desenha a partir dela). O servidor garante a integridade:
// só módulos conhecidos, sem duplicados (um módulo fica em UM lugar), tamanho limitado — mesmas regras do app.
export const MENU_MODULOS = ['meu-dia', 'tarefas', 'compromissos', 'mercado', 'contas', 'financeiro', 'fiscal', 'das', 'lembretes', 'compras', 'anotacoes', 'alimentacao', 'espaco', 'organizar', 'treinos', 'estudio', 'emails', 'mcp', 'mapas', 'cerebro', 'anuncios'] as const
const SO_MENU = ['admin', 'eleicoes', 'projetos'] // fixos do menu principal (não vão para a pasta)
const MAIN = new Set<string>([...MENU_MODULOS, ...SO_MENU]), PROJ = new Set<string>(MENU_MODULOS)
/** null = organização padrão. Lixo vira padrão; listas são limpas (ids inválidos/duplicados removidos). */
export function sanitizeMenuLayout(v: unknown): { main: string[]; projects: string[] } | null {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return null
  const x = v as any, vistos = new Set<string>()
  const lim = (arr: unknown, ok: Set<string>) => (Array.isArray(arr) ? arr : []).slice(0, 60).filter((id) => typeof id === 'string' && ok.has(id) && !vistos.has(id) && !!vistos.add(id))
  const main = lim(x.main, MAIN), projects = lim(x.projects, PROJ)
  return main.length || projects.length ? { main, projects } : null
}
