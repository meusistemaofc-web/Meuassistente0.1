// SOLICITAÇÃO DE CRÉDITO DO CLIENTE — pedido de limite a UMA empresa do Crédito da Loja (lib/credito-loja.ts).
// Fluxo: rascunho (dados + 3 documentos, revisão) → pendente (enviada com consentimento) → aprovada | recusada |
//        info_solicitada (a empresa pede algo; o cliente completa e reenvia → pendente) | cancelada | expirada.
// A aprovação NÃO cria carteira nova: grava o limite e as condições no registro de limite que o Crédito da Loja já usa
// (credito_clientes, via salvarCliente), vinculado só a esta empresa e a este cliente.
// LGPD / proteção:
//   • dados cadastrais e documentos CIFRADOS no banco (AES-256-GCM do cofre do servidor); nada em pasta ou URL pública;
//   • documento aberto só por endereço temporário (5 min) assinado para QUEM pediu (dono da empresa ou o próprio cliente),
//     conferido junto com a sessão; resposta sem cache; cada visualização vai para o histórico e para a auditoria;
//   • a selfie serve só para conferência visual pela empresa — não há reconhecimento facial/biométrico automatizado;
//   • retenção: conteúdo dos documentos apagado depois de N dias da decisão (ADM: retencaoDocsDias), rascunhos abandonados
//     e pedidos de informação sem resposta expiram; o cliente pode cancelar e apagar os documentos a qualquer momento.
import { createHash, createHmac, timingSafeEqual } from 'node:crypto'
import { q, one, J, nowIso, db } from '../db/index.js'
import { fail } from './http.js'
import { seal, unseal } from './settings.js'
import { notify } from './notify.js'
import { withLock } from './business-sync.js'
import * as CL from './credito-loja.js'

export const CONSENTIMENTO_VERSAO = '2026-11-28'
export const TIPOS = { documento: 'Documento oficial com foto (RG ou CNH)', comprovante: 'Comprovante de endereço', selfie: 'Selfie de identificação' } as const
type Tipo = keyof typeof TIPOS
export const MAX_ARQ = 1_500_000 // bytes (o arquivo vai em uma requisição; o app reduz fotos grandes antes de enviar)
const MIN_IMG = 15_000
const MIN_DIM: Record<Tipo, [number, number]> = { documento: [800, 500], comprovante: [800, 500], selfie: [480, 480] } // [lado maior, lado menor]
const ATIVOS = ['rascunho', 'pendente', 'info_solicitada']
const txt = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u0008\u000b-\u001f<>]/g, ' ').trim().slice(0, n)
const brl = (n: number) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

/* ---------------- validações ---------------- */
export function cpfValido(v: string) {
  const c = String(v || '').replace(/\D/g, ''); if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false
  const dv = (n: number) => { let s = 0; for (let i = 0; i < n; i++) s += Number(c[i]) * (n + 1 - i); const r = (s * 10) % 11; return r === 10 ? 0 : r }
  return dv(9) === Number(c[9]) && dv(10) === Number(c[10])
}
const mascaraCpf = (c: string) => `***.${c.slice(3, 6)}.${c.slice(6, 9)}-**`
export function validarDados(b: any) {
  const nome = txt(b?.nome, 120).replace(/\s+/g, ' ')
  if (nome.split(' ').filter((x) => x.length >= 2).length < 2) fail(400, 'Informe o nome completo (nome e sobrenome).', 'invalid', 'nome')
  const cpf = String(b?.cpf || '').replace(/\D/g, ''); if (!cpfValido(cpf)) fail(400, 'CPF inválido. Confira os números.', 'invalid', 'cpf')
  const tel = String(b?.telefone || '').replace(/\D/g, ''); if (tel.length < 10 || tel.length > 13) fail(400, 'Informe o telefone com DDD.', 'invalid', 'telefone')
  const email = txt(b?.email, 160).toLowerCase(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'E-mail inválido.', 'invalid', 'email')
  const nasc = String(b?.nascimento || ''); const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(nasc); const t = m ? Date.parse(nasc + 'T12:00:00Z') : NaN
  if (!m || !Number.isFinite(t)) fail(400, 'Informe a data de nascimento.', 'invalid', 'nascimento')
  const idade = (Date.now() - t) / (365.25 * 864e5); if (idade < 18) fail(400, 'O Crédito da Loja é só para maiores de 18 anos.', 'invalid', 'nascimento'); if (idade > 120) fail(400, 'Confira a data de nascimento.', 'invalid', 'nascimento')
  return { nome, cpf, telefone: tel.length <= 11 ? '+55' + tel : '+' + tel, email, nascimento: nasc }
}
/** Formato real do arquivo pelo conteúdo (não pela extensão/nome) e dimensões das imagens. */
export function inspecionar(buf: Buffer): { mime: string; largura: number; altura: number } | null {
  if (buf.length > 4 && buf.subarray(0, 5).toString('latin1') === '%PDF-') return { mime: 'application/pdf', largura: 0, altura: 0 }
  if (buf.length > 24 && buf[0] === 0x89 && buf.subarray(1, 4).toString('latin1') === 'PNG') return { mime: 'image/png', largura: buf.readUInt32BE(16), altura: buf.readUInt32BE(20) }
  if (buf.length > 30 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') {
    const k = buf.subarray(12, 16).toString('latin1')
    if (k === 'VP8X') return { mime: 'image/webp', largura: 1 + buf.readUIntLE(24, 3), altura: 1 + buf.readUIntLE(27, 3) }
    if (k === 'VP8L') { const b0 = buf[21], b1 = buf[22], b2 = buf[23], b3 = buf[24]; return { mime: 'image/webp', largura: 1 + (((b1 & 0x3f) << 8) | b0), altura: 1 + (((b3 & 0xf) << 10) | (b2 << 2) | ((b1 & 0xc0) >> 6)) } }
    if (k === 'VP8 ') return { mime: 'image/webp', largura: buf.readUInt16LE(26) & 0x3fff, altura: buf.readUInt16LE(28) & 0x3fff }
    return null
  }
  if (buf.length > 4 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    let i = 2
    while (i + 9 < buf.length) { if (buf[i] !== 0xff) { i++; continue } const mk = buf[i + 1]; if (mk === 0xd8 || mk === 0x01 || (mk >= 0xd0 && mk <= 0xd7)) { i += 2; continue } const len = buf.readUInt16BE(i + 2)
      if ((mk >= 0xc0 && mk <= 0xcf) && mk !== 0xc4 && mk !== 0xc8 && mk !== 0xcc) return { mime: 'image/jpeg', altura: buf.readUInt16BE(i + 5), largura: buf.readUInt16BE(i + 7) }
      i += 2 + len }
    return { mime: 'image/jpeg', largura: 0, altura: 0 }
  }
  return null
}
export function validarArquivo(tipo: Tipo, dataUrl: string) {
  const m = /^data:([\w/+.-]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(String(dataUrl || ''))
  if (!m) fail(400, 'Arquivo inválido. Envie uma foto (JPG, PNG ou WEBP)' + (tipo === 'selfie' ? '.' : ' ou um PDF.'), 'invalid', 'arquivo')
  const buf = Buffer.from(m![2].replace(/\s/g, ''), 'base64')
  if (buf.length > MAX_ARQ) fail(400, `Arquivo grande demais (máximo ${(MAX_ARQ / 1e6).toFixed(1).replace('.', ',')} MB). Tire a foto de novo ou envie um PDF menor.`, 'arquivo_grande', 'arquivo')
  const info = inspecionar(buf)
  if (!info) fail(400, 'Formato não aceito. Use JPG, PNG, WEBP' + (tipo === 'selfie' ? '.' : ' ou PDF.'), 'formato', 'arquivo')
  if (info!.mime === 'application/pdf') {
    if (tipo === 'selfie') fail(400, 'A selfie precisa ser uma foto (JPG, PNG ou WEBP), não PDF.', 'formato', 'arquivo')
    if (buf.length < 1000 || !buf.subarray(Math.max(0, buf.length - 2048)).toString('latin1').includes('%%EOF')) fail(400, 'O PDF parece incompleto ou corrompido. Envie de novo.', 'ilegivel', 'arquivo')
    return { buf, ...info! }
  }
  const [maior, menor] = MIN_DIM[tipo], L = Math.max(info!.largura, info!.altura), S = Math.min(info!.largura, info!.altura)
  if (buf.length < MIN_IMG || !L || L < maior || S < menor) fail(400, `A imagem está pequena demais para leitura (mínimo ${maior} × ${menor} pixels). Tire a foto de perto, com boa luz e sem cortes.`, 'ilegivel', 'arquivo')
  return { buf, ...info! }
}

/* ---------------- relacionamento real com a empresa ---------------- */
export async function relacionamento(bid: number, uid: number) {
  const rows = (await q('SELECT id, status, total, data, created_at FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id', [bid, uid])).map((o: any) => ({ ...o, d: J<any>(o.data, {}) })).filter((o: any) => !o.d.guest)
  const tentativas = rows.filter((o: any) => ['aguardando_pagamento', 'aguardando_credito'].includes(o.status))
  const validos = rows.filter((o: any) => !['aguardando_pagamento', 'aguardando_credito', 'cancelado', 'recusado'].includes(o.status))
  const conc = rows.filter((o: any) => o.status === 'concluido'), canc = rows.filter((o: any) => ['cancelado', 'recusado'].includes(o.status))
  const soma = (l: any[]) => CL.r2(l.reduce((a, o) => a + Number(o.total || 0), 0))
  const pagosOnline = rows.filter((o: any) => o.d.pagamento === 'online' && o.d.pago)
  const porForma: Record<string, number> = {}; for (const o of validos) porForma[o.d.pagamento || 'outro'] = (porForma[o.d.pagamento || 'outro'] || 0) + 1
  const ops = await q('SELECT status FROM credito_operacoes WHERE business_id = $1 AND user_id = $2', [bid, uid])
  const temCredito = !!(await one('SELECT id FROM credito_clientes WHERE business_id = $1 AND user_id = $2', [bid, uid]))
  const uso = temCredito || ops.length ? await CL.usoCliente(bid, uid) : null
  return {
    semCompras: validos.length === 0,
    compras: validos.length, pedidos: validos.filter((o: any) => o.d.tipo !== 'agendamento').length, agendamentos: validos.filter((o: any) => o.d.tipo === 'agendamento').length,
    valorTotal: soma(validos), concluidos: conc.length, valorConcluido: soma(conc), cancelados: canc.length, emAndamento: validos.length - conc.length,
    primeiraCompra: validos[0]?.created_at || null, ultimaCompra: validos[validos.length - 1]?.created_at || null,
    tentativasNaoConcluidas: tentativas.length, pagamentosOnlineConfirmados: pagosOnline.length, valorPagoOnline: soma(pagosOnline), formasDePagamento: porForma,
    credito: uso ? { limiteAtual: uso.limite, situacao: uso.situacao, compras: ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).length, quitadas: ops.filter((o: any) => o.status === 'quitada').length, saldoDevedor: uso.saldoDevedor, vencido: uso.vencido, pago: uso.pago } : null,
    calculadoEm: nowIso(),
  }
}

/* ---------------- acesso e auxiliares ---------------- */
const empresaDe = async (bid: number) => { const b = await one('SELECT owner_id, data FROM businesses WHERE id = $1', [bid]); return { dono: Number(b?.owner_id || 0), nome: String(J<any>(b?.data, {}).empresa || 'Loja') } }
const avisar = (uid: number, title: string, body: string, ref: string, link: string) => notify(uid, { type: 'credito', title, body, link, ref }).catch((e) => console.error('[credito] aviso:', e?.message))
async function minha(sid: number, uid: number) { const s = await one('SELECT * FROM credito_solicitacoes WHERE id = $1 AND user_id = $2', [sid, uid]); if (!s) fail(404, 'Solicitação não encontrada.', 'not_found'); return s! }
async function daEmpresa(sid: number, bid: number) { const s = await one("SELECT * FROM credito_solicitacoes WHERE id = $1 AND business_id = $2 AND status <> 'rascunho'", [sid, bid]); if (!s) fail(404, 'Solicitação não encontrada.', 'not_found'); return s! }
async function dadosDe(s: any) { if (!s.dados_cifrados) return null; try { return JSON.parse(await unseal(String(s.dados_cifrados))) } catch { return null } }
const docsMeta = async (sid: number) => (await q('SELECT id, tipo, mime, tamanho, largura, altura, excluido_em, created_at FROM credito_documentos WHERE solicitacao_id = $1 AND excluido_em IS NULL ORDER BY id', [sid])).map((d: any) => ({ id: Number(d.id), tipo: String(d.tipo), nomeTipo: (TIPOS as any)[d.tipo] || d.tipo, mime: String(d.mime), tamanho: Number(d.tamanho), largura: Number(d.largura), altura: Number(d.altura), enviadoEm: d.created_at }))
/* endereço temporário do documento: assinado para um visualizador, um documento e um prazo (5 min) */
const segredo = () => process.env.APP_SECRET || process.env.SETTINGS_KEY || process.env.SESSION_SECRET || 'meu-assistente-docs'
const assinatura = (did: number, viewer: number, exp: number) => createHmac('sha256', segredo()).update(`credito-doc:${did}:${viewer}:${exp}`).digest('base64url')
export function urlTemporaria(base: string, did: number, viewer: number) { const exp = Math.floor(Date.now() / 1000) + 300; return `${base}/${did}?exp=${exp}&sig=${assinatura(did, viewer, exp)}` }
function conferirAssinatura(did: number, viewer: number, exp: number, sig: string) {
  if (!Number.isFinite(exp) || exp < Date.now() / 1000) fail(403, 'Este endereço do documento expirou. Abra de novo pela tela da solicitação.', 'link_expirado')
  const a = Buffer.from(assinatura(did, viewer, exp)), b = Buffer.from(String(sig || ''))
  if (a.length !== b.length || !timingSafeEqual(a, b)) fail(403, 'Endereço do documento inválido.', 'forbidden')
}
async function apagarDocs(t: any, sid: number) { await t.query("UPDATE credito_documentos SET conteudo = '', excluido_em = $1 WHERE solicitacao_id = $2 AND excluido_em IS NULL", [nowIso(), sid]); await t.query('UPDATE credito_solicitacoes SET docs_excluidos_em = $1 WHERE id = $2', [nowIso(), sid]) }
const saidaCliente = async (s: any) => ({ id: Number(s.id), businessId: Number(s.business_id), empresa: (await empresaDe(Number(s.business_id))).nome, status: String(s.status), limiteSolicitado: Number(s.limite_solicitado), parcelasDesejadas: Number(s.parcelas_desejadas), mensagem: String(s.mensagem_cliente || ''), pedidoInfo: s.status === 'info_solicitada' ? String(s.pedido_info || '') : '', decisao: ['aprovada', 'recusada'].includes(s.status) ? J<any>(s.decisao, {}) : null, enviadaEm: s.enviada_em || null, decididaEm: s.decidido_em || null, documentosExcluidos: !!s.docs_excluidos_em, criadaEm: s.created_at })

/* ---------------- cliente ---------------- */
/** Abre (ou retoma) a solicitação desta loja: uma ativa por vez. */
export async function abrir(bid: number, uid: number) {
  const e = await CL.estadoEmpresa(bid)
  if (!e.paraClientes || !e.cfg.aceitarSolicitacoes) fail(403, 'Esta loja não está recebendo solicitações de crédito agora.', 'credito_indisponivel')
  const emp = await empresaDe(bid); if (emp.dono === uid) fail(400, 'Você não pode pedir crédito à sua própria loja.', 'invalid')
  return withLock(`credito-sol:${bid}:${uid}`, async () => {
    const ativa = await one(`SELECT * FROM credito_solicitacoes WHERE business_id = $1 AND user_id = $2 AND status IN ('rascunho','pendente','info_solicitada') ORDER BY id DESC LIMIT 1`, [bid, uid])
    if (ativa) return ativa
    const [s] = await q('INSERT INTO credito_solicitacoes (business_id, user_id, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$4) RETURNING *', [bid, uid, 'rascunho', nowIso()])
    return s
  })
}
export async function verMinha(sid: number, uid: number, base: string) {
  const s = await minha(sid, uid), e = await CL.estadoEmpresa(Number(s.business_id)), me = await one('SELECT name, email, whatsapp, birthday FROM users WHERE id = $1', [uid])
  const docs = (await docsMeta(sid)).map((d) => ({ ...d, url: urlTemporaria(base, d.id, uid) }))
  return { solicitacao: await saidaCliente(s), dados: (await dadosDe(s)) || { nome: String(me?.name || ''), email: String(me?.email || ''), telefone: String(me?.whatsapp || ''), nascimento: String(me?.birthday || '').slice(0, 10), cpf: '' }, documentos: docs, faltam: (Object.keys(TIPOS) as Tipo[]).filter((t) => !docs.some((d) => d.tipo === t)),
    regras: { parcelas: e.cfg.parcelas, tetoLimite: Math.min(e.cfg.limiteMaxCliente, e.g.limiteMaxCliente), retencaoDias: e.g.retencaoDocsDias, maxArquivo: MAX_ARQ }, consentimentoVersao: CONSENTIMENTO_VERSAO, termo: termoConsentimento((await empresaDe(Number(s.business_id))).nome, e.g.retencaoDocsDias) }
}
export function termoConsentimento(empresa: string, dias: number) {
  return [
    `Seus dados e documentos são usados só para ${empresa} analisar este pedido de crédito e, se aprovado, administrar o seu limite nesta loja.`,
    `Somente o responsável por ${empresa} pode ver os documentos, por um endereço temporário e registrado; nenhuma outra empresa tem acesso.`,
    'Os documentos ficam cifrados no servidor e nunca são publicados.',
    'A selfie é usada apenas para a loja conferir visualmente que o documento é seu. Não fazemos reconhecimento facial nem biométrico automatizado.',
    `Os documentos são apagados ${dias} dias depois da decisão (ou antes, se você pedir). Você pode cancelar o pedido e apagar os documentos a qualquer momento em Meu crédito.`,
    'Você pode pedir acesso, correção ou exclusão dos seus dados (LGPD, Lei 13.709/2018).',
  ]
}
const editavel = (s: any) => ['rascunho', 'info_solicitada'].includes(String(s.status))
export async function salvarDados(sid: number, uid: number, b: any) {
  const s = await minha(sid, uid); if (!editavel(s)) fail(400, 'Esta solicitação não pode mais ser alterada.', 'invalid')
  const d = validarDados(b), e = await CL.estadoEmpresa(Number(s.business_id)), teto = Math.min(e.cfg.limiteMaxCliente, e.g.limiteMaxCliente)
  const lim = CL.r2(Math.max(0, Number(b?.limiteSolicitado) || 0)); if (lim > teto) fail(400, `Esta loja concede até ${brl(teto)} por cliente.`, 'invalid', 'limiteSolicitado')
  const par = Math.floor(Number(b?.parcelasDesejadas) || 0); if (par && !e.cfg.parcelas.includes(par)) fail(400, 'Escolha uma quantidade de parcelas oferecida pela loja.', 'invalid', 'parcelasDesejadas')
  await q('UPDATE credito_solicitacoes SET dados_cifrados = $1, cpf_mascara = $2, limite_solicitado = $3, parcelas_desejadas = $4, mensagem_cliente = $5, updated_at = $6 WHERE id = $7', [await seal(JSON.stringify(d)), mascaraCpf(d.cpf), lim, par, txt(b?.mensagem, 500), nowIso(), sid])
  return { ok: true }
}
export async function enviarDocumento(sid: number, uid: number, b: any) {
  const s = await minha(sid, uid); if (!editavel(s)) fail(400, 'Esta solicitação não pode mais ser alterada.', 'invalid')
  const tipo = String(b?.tipo || '') as Tipo; if (!(tipo in TIPOS)) fail(400, 'Tipo de documento inválido.', 'invalid')
  const a = validarArquivo(tipo, String(b?.arquivo || ''))
  const sha = createHash('sha256').update(a.buf).digest('hex'), cif = await seal(a.buf.toString('base64'))
  return withLock(`credito-doc:${sid}:${tipo}`, () => db().tx(async (t) => {
    await t.query("UPDATE credito_documentos SET conteudo = '', excluido_em = $1 WHERE solicitacao_id = $2 AND tipo = $3 AND excluido_em IS NULL", [nowIso(), sid, tipo]) // troca: o anterior é apagado
    const [d] = await t.query('INSERT INTO credito_documentos (solicitacao_id, business_id, user_id, tipo, mime, tamanho, largura, altura, sha256, conteudo, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id', [sid, s.business_id, uid, tipo, a.mime, a.buf.length, a.largura, a.altura, sha, cif, nowIso()])
    await t.query('UPDATE credito_solicitacoes SET docs_excluidos_em = NULL, updated_at = $1 WHERE id = $2', [nowIso(), sid])
    return { ok: true, documento: { id: Number(d.id), tipo, mime: a.mime, tamanho: a.buf.length, largura: a.largura, altura: a.altura } }
  }))
}
export async function enviar(sid: number, uid: number, b: any) {
  if (b?.consentimento !== true) fail(400, 'Para enviar, leia e aceite como seus dados e documentos serão usados.', 'consentimento')
  return withLock(`credito-sol:${sid}`, async () => {
    const s = await minha(sid, uid); if (!editavel(s)) fail(409, 'Esta solicitação já foi enviada.', 'conflito')
    const bid = Number(s.business_id), e = await CL.estadoEmpresa(bid)
    if (!e.paraClientes || !e.cfg.aceitarSolicitacoes) fail(403, 'Esta loja não está recebendo solicitações de crédito agora.', 'credito_indisponivel')
    if (!(await dadosDe(s))) fail(400, 'Preencha seus dados cadastrais antes de enviar.', 'invalid', 'dados')
    const docs = await docsMeta(sid), faltam = (Object.keys(TIPOS) as Tipo[]).filter((t) => !docs.some((d) => d.tipo === t))
    if (faltam.length) fail(400, `Falta enviar: ${faltam.map((t) => TIPOS[t].toLowerCase()).join(', ')}.`, 'documentos', faltam[0])
    const reenvio = s.status === 'info_solicitada', rel = await relacionamento(bid, uid)
    await db().tx(async (t) => {
      await t.query("UPDATE credito_solicitacoes SET status = 'pendente', relacionamento = $1, consentimento_em = $2, consentimento_versao = $3, enviada_em = $2, updated_at = $2 WHERE id = $4", [JSON.stringify(rel), nowIso(), CONSENTIMENTO_VERSAO, sid])
      await CL.evento(t, bid, reenvio ? 'solicitacao_limite_complementada' : 'solicitacao_limite_recebida', { solicitacao: sid, limiteSolicitado: Number(s.limite_solicitado), consentimento: CONSENTIMENTO_VERSAO }, { cliente: uid, ator: uid })
    })
    const emp = await empresaDe(bid)
    await avisar(uid, reenvio ? `Informações enviadas · ${emp.nome}` : `Solicitação de crédito recebida · ${emp.nome}`, 'A loja vai analisar seus dados. Você acompanha o andamento em Meu crédito.', `credito:sol-${reenvio ? 'complemento' : 'recebida'}:${sid}:${Date.now().toString(36)}`, '/x/meu-credito')
    await avisar(emp.dono, reenvio ? 'Cliente respondeu à solicitação de crédito' : 'Nova solicitação de crédito', `${s.cpf_mascara ? 'CPF ' + s.cpf_mascara + ' · ' : ''}${Number(s.limite_solicitado) > 0 ? 'limite pedido ' + brl(Number(s.limite_solicitado)) + ' · ' : ''}${rel.semCompras ? 'ainda sem compras na loja' : rel.compras + ' compra(s) na loja'} · analise em Sua empresa → Crédito da Loja`, `credito:sol-loja:${sid}:${Date.now().toString(36)}`, '/x/sua-empresa')
    return { ok: true, status: 'pendente' }
  })
}
export async function cancelar(sid: number, uid: number, apagar = true) {
  const s = await minha(sid, uid)
  await db().tx(async (t) => {
    if (ATIVOS.includes(String(s.status))) await t.query("UPDATE credito_solicitacoes SET status = 'cancelada', updated_at = $1 WHERE id = $2", [nowIso(), sid])
    if (apagar) await apagarDocs(t, sid)
    if (s.status !== 'rascunho') await CL.evento(t, Number(s.business_id), ATIVOS.includes(String(s.status)) ? 'solicitacao_limite_cancelada' : 'documentos_excluidos_cliente', { solicitacao: sid }, { cliente: uid, ator: uid })
  })
  return { ok: true }
}
export async function minhas(uid: number) {
  const rows = await q("SELECT * FROM credito_solicitacoes WHERE user_id = $1 AND NOT (status = 'cancelada' AND enviada_em IS NULL) ORDER BY id DESC LIMIT 50", [uid])
  return { solicitacoes: await Promise.all(rows.map(saidaCliente)) }
}

/* ---------------- empresa (dono) ---------------- */
export async function listar(bid: number, status: string) {
  const rows = await q(`SELECT s.*, u.name FROM credito_solicitacoes s JOIN users u ON u.id = s.user_id WHERE s.business_id = $1 AND s.status <> 'rascunho' ${status ? 'AND s.status = $2' : ''} ORDER BY CASE s.status WHEN 'pendente' THEN 0 WHEN 'info_solicitada' THEN 1 ELSE 2 END, s.id DESC LIMIT 200`, status ? [bid, status] : [bid])
  const cont = await q("SELECT status, COUNT(*) AS n FROM credito_solicitacoes WHERE business_id = $1 AND status <> 'rascunho' GROUP BY status", [bid])
  return { contagem: Object.fromEntries(cont.map((r: any) => [String(r.status), Number(r.n)])), solicitacoes: rows.map((s: any) => ({ id: Number(s.id), cliente: String(s.name || ''), userId: Number(s.user_id), cpf: String(s.cpf_mascara || ''), status: String(s.status), limiteSolicitado: Number(s.limite_solicitado), enviadaEm: s.enviada_em, decididaEm: s.decidido_em, semCompras: !!J<any>(s.relacionamento, {}).semCompras, compras: Number(J<any>(s.relacionamento, {}).compras || 0) })) }
}
export async function detalhe(bid: number, sid: number, viewer: number, base: string) {
  const s = await daEmpresa(sid, bid), uid = Number(s.user_id), e = await CL.estadoEmpresa(bid)
  const eventos = (await q('SELECT tipo, dados, ator_id, created_at FROM credito_eventos WHERE business_id = $1 AND cliente_id = $2 ORDER BY id DESC LIMIT 80', [bid, uid])).map((r: any) => ({ tipo: String(r.tipo), dados: J<any>(r.dados, {}), em: r.created_at })).filter((x: any) => x.dados?.solicitacao === sid || x.tipo.startsWith('limite') || x.tipo.startsWith('credito_'))
  return {
    solicitacao: { ...(await saidaCliente(s)), cpf: String(s.cpf_mascara || ''), pedidoInfo: String(s.pedido_info || ''), decisao: J<any>(s.decisao, {}), consentimento: { versao: String(s.consentimento_versao || ''), em: s.consentimento_em || null } },
    dados: await dadosDe(s), documentos: (await docsMeta(sid)).map((d) => ({ ...d, url: urlTemporaria(base, d.id, viewer) })),
    relacionamentoNoEnvio: J<any>(s.relacionamento, {}), relacionamentoAtual: await relacionamento(bid, uid), notas: J<any[]>(s.notas_internas, []), eventos,
    regras: { empresa: e.cfg, tetos: { maxParcelas: e.g.maxParcelas, jurosMaxMes: e.g.jurosMaxMes, jurosMaxTotal: e.g.jurosMaxTotal, limiteMaxCliente: Math.min(e.cfg.limiteMaxCliente, e.g.limiteMaxCliente), entradaMinPct: e.g.entradaMinPct }, retencaoDias: e.g.retencaoDocsDias }, operavel: e.operavel,
  }
}
export async function nota(bid: number, sid: number, texto: string, ator: { id: number; nome: string }) {
  const t0 = txt(texto, 1000); if (!t0) fail(400, 'Escreva a observação.', 'invalid')
  const s = await daEmpresa(sid, bid), notas = [...J<any[]>(s.notas_internas, []), { em: nowIso(), por: ator.nome, texto: t0 }].slice(-100)
  await q('UPDATE credito_solicitacoes SET notas_internas = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(notas), nowIso(), sid])
  return { ok: true, notas }
}
async function decidirBase(bid: number, sid: number, ator: { id: number }, fn: (s: any) => Promise<any>) {
  return withLock(`credito-sol:${sid}`, async () => { const s = await daEmpresa(sid, bid); if (s.status !== 'pendente') fail(409, s.status === 'info_solicitada' ? 'Aguardando o cliente enviar as informações pedidas.' : 'Esta solicitação já foi decidida.', 'conflito'); return fn(s) })
}
export async function pedirInfo(bid: number, sid: number, mensagem: string, ator: { id: number; nome: string }) {
  const m = txt(mensagem, 600); if (m.length < 5) fail(400, 'Escreva o que o cliente precisa enviar ou corrigir.', 'invalid', 'mensagem')
  CL.exigirOperavel(await CL.estadoEmpresa(bid), 'analisar solicitações')
  return decidirBase(bid, sid, ator, async (s) => {
    await db().tx(async (t) => { await t.query("UPDATE credito_solicitacoes SET status = 'info_solicitada', pedido_info = $1, updated_at = $2 WHERE id = $3", [m, nowIso(), sid]); await CL.evento(t, bid, 'solicitacao_limite_info', { solicitacao: sid, mensagem: m }, { cliente: Number(s.user_id), ator: ator.id }) })
    await avisar(Number(s.user_id), `A loja pediu mais informações · ${(await empresaDe(bid)).nome}`, m, `credito:sol-info:${sid}:${Date.now().toString(36)}`, `/x/meu-credito?solicitacao=${sid}`)
    return { ok: true, status: 'info_solicitada' }
  })
}
export async function recusar(bid: number, sid: number, motivo: string, ator: { id: number; nome: string }) {
  const m = txt(motivo, 400); if (m.length < 3) fail(400, 'Informe o motivo da recusa (o cliente vê).', 'invalid', 'motivo')
  CL.exigirOperavel(await CL.estadoEmpresa(bid), 'analisar solicitações')
  return decidirBase(bid, sid, ator, async (s) => {
    await db().tx(async (t) => { await t.query("UPDATE credito_solicitacoes SET status = 'recusada', decisao = $1, decidido_por = $2, decidido_em = $3, updated_at = $3 WHERE id = $4", [JSON.stringify({ motivo: m }), ator.id, nowIso(), sid]); await CL.evento(t, bid, 'solicitacao_limite_recusada', { solicitacao: sid, motivo: m }, { cliente: Number(s.user_id), ator: ator.id }) })
    await avisar(Number(s.user_id), `Solicitação de crédito não aprovada · ${(await empresaDe(bid)).nome}`, m, `credito:sol-recusada:${sid}`, '/x/meu-credito')
    const { audit } = await import('./account.js'); await audit(ator.id, 'credito.solicitacao_limite.recusada', bid, { solicitacao: sid })
    return { ok: true, status: 'recusada' }
  })
}
/** Aprova: o limite e as condições vão para o registro de limite do Crédito da Loja (só desta empresa e deste cliente). */
export async function aprovar(bid: number, sid: number, b: any, ator: { id: number; nome: string }) {
  const e = await CL.estadoEmpresa(bid); CL.exigirOperavel(e, 'aprovar crédito')
  const limite = CL.r2(Number(b?.limite)); if (!(limite > 0)) fail(400, 'Informe o limite concedido.', 'invalid', 'limite')
  const condicoes: any = {}; for (const k of CL.CHAVES_CLIENTE) if (b?.condicoes?.[k] !== undefined && b.condicoes[k] !== null && b.condicoes[k] !== '') condicoes[k] = b.condicoes[k]
  const validade = String(b?.validade || '')
  return decidirBase(bid, sid, ator, async (s) => {
    const uid = Number(s.user_id)
    const r = await CL.salvarCliente(bid, { userId: uid, limite, situacao: 'ativo', condicoes, validade, solicitacaoId: sid, silencioso: true }, ator) // valida tetos, validade e grava (com histórico)
    const cfg = CL.cfgDoCliente(e.cfg, e.g, r.cliente.condicoes)
    const decisao = { limite, validade, condicoes: r.cliente.condicoes, resumo: { parcelas: cfg.parcelas, jurosTipo: cfg.jurosTipo, taxa: cfg.taxa, semJurosAte: cfg.semJurosAte, entradaMinPct: cfg.entradaMinPct, primeiraParcela: cfg.primeiraParcela, primeiroVencDias: cfg.primeiroVencDias, intervaloDias: cfg.intervaloDias, compraMax: cfg.compraMax, condicoesCliente: cfg.condicoesCliente || '' } }
    await db().tx(async (t) => { await t.query("UPDATE credito_solicitacoes SET status = 'aprovada', decisao = $1, decidido_por = $2, decidido_em = $3, updated_at = $3 WHERE id = $4", [JSON.stringify(decisao), ator.id, nowIso(), sid]); await CL.evento(t, bid, 'solicitacao_limite_aprovada', { solicitacao: sid, limite, validade }, { cliente: uid, ator: ator.id }) })
    const juros = cfg.jurosTipo === 'sem' ? 'sem juros' : `juros de ${String(cfg.taxa).replace('.', ',')}% ${cfg.jurosTipo === 'mensal' ? 'ao mês' : 'sobre o parcelamento'}${cfg.semJurosAte ? ` (sem juros até ${cfg.semJurosAte}x)` : ''}`
    await avisar(uid, `Crédito aprovado · ${(await empresaDe(bid)).nome}`, `Limite de ${brl(limite)} · até ${Math.max(...cfg.parcelas)}x, ${juros}${cfg.entradaMinPct ? `, entrada mínima de ${String(cfg.entradaMinPct).replace('.', ',')}%` : ''}${validade ? ` · válido até ${validade.split('-').reverse().join('/')}` : ''}.`, `credito:sol-aprovada:${sid}`, '/x/meu-credito')
    const { audit } = await import('./account.js'); await audit(ator.id, 'credito.solicitacao_limite.aprovada', bid, { solicitacao: sid, limite })
    return { ok: true, status: 'aprovada', cliente: r.cliente }
  })
}

/* ---------------- documento protegido ---------------- */
/** Conteúdo de um documento: assinatura válida para ESTE visualizador + sessão dele + permissão (dono da empresa da
 *  solicitação, ou o próprio cliente). Cada abertura fica registrada. */
export async function documento(did: number, viewer: number, exp: number, sig: string) {
  conferirAssinatura(did, viewer, exp, sig)
  const d = await one('SELECT d.*, s.business_id AS bid, s.user_id AS uid, b.owner_id FROM credito_documentos d JOIN credito_solicitacoes s ON s.id = d.solicitacao_id JOIN businesses b ON b.id = s.business_id WHERE d.id = $1', [did])
  if (!d || d.excluido_em || !d.conteudo) fail(404, 'Documento não disponível (pode ter sido apagado pela política de retenção).', 'not_found')
  const dono = Number(d!.owner_id) === viewer, cliente = Number(d!.uid) === viewer
  if (!dono && !cliente) fail(404, 'Documento não disponível.', 'not_found')
  const buf = Buffer.from(await unseal(String(d!.conteudo)), 'base64')
  if (!buf.length || createHash('sha256').update(buf).digest('hex') !== d!.sha256) fail(500, 'Não foi possível abrir o documento com segurança.', 'integridade')
  await CL.evento(db(), Number(d!.bid), 'documento_visualizado', { solicitacao: Number(d!.solicitacao_id), documento: did, tipo: String(d!.tipo), por: dono ? 'empresa' : 'cliente' }, { cliente: Number(d!.uid), ator: viewer })
  if (dono) { const { audit } = await import('./account.js'); await audit(viewer, 'credito.documento.visualizado', Number(d!.bid), { solicitacao: Number(d!.solicitacao_id), documento: did, tipo: String(d!.tipo) }) }
  return { _binary: true, mime: String(d!.mime), data: buf, headers: { 'Cache-Control': 'no-store, max-age=0', Pragma: 'no-cache', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': `inline; filename="${d!.tipo}"`, 'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox", 'Referrer-Policy': 'no-referrer', 'X-Robots-Tag': 'noindex' } }
}

/* ---------------- retenção (agendador) ---------------- */
let ultimo = 0
export async function tickRetencao(now = new Date(), forcar = false) {
  if (!forcar && now.getTime() - ultimo < 60 * 60_000) return; ultimo = now.getTime()
  const g = await CL.globalCfg(), limite = new Date(now.getTime() - g.retencaoDocsDias * 864e5).toISOString(), d30 = new Date(now.getTime() - 30 * 864e5).toISOString()
  // pedido de informação sem resposta por 30 dias → expirada; rascunho abandonado por 30 dias → cancelado e apagado
  for (const s of await q("SELECT id, business_id, user_id FROM credito_solicitacoes WHERE status = 'info_solicitada' AND updated_at < $1", [d30])) {
    await q("UPDATE credito_solicitacoes SET status = 'expirada', decidido_em = $1, updated_at = $1 WHERE id = $2 AND status = 'info_solicitada'", [nowIso(), s.id])
    await CL.evento(db(), Number(s.business_id), 'solicitacao_limite_expirada', { solicitacao: Number(s.id) }, { cliente: Number(s.user_id) })
  }
  for (const s of await q("SELECT id FROM credito_solicitacoes WHERE status = 'rascunho' AND updated_at < $1", [d30])) await db().tx(async (t) => { await t.query("UPDATE credito_solicitacoes SET status = 'cancelada', updated_at = $1 WHERE id = $2", [nowIso(), s.id]); await apagarDocs(t, Number(s.id)) })
  // decididas há mais de N dias: conteúdo dos documentos apagado (os metadados e o histórico ficam)
  const venc = await q("SELECT id, business_id, user_id FROM credito_solicitacoes WHERE status IN ('aprovada','recusada','cancelada','expirada') AND docs_excluidos_em IS NULL AND COALESCE(decidido_em, updated_at) < $1", [limite])
  for (const s of venc) await db().tx(async (t) => { await apagarDocs(t, Number(s.id)); await CL.evento(t, Number(s.business_id), 'documentos_excluidos_retencao', { solicitacao: Number(s.id), dias: g.retencaoDocsDias }, { cliente: Number(s.user_id) }) })
  return { expiradas: venc.length }
}
