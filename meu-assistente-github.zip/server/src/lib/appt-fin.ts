// Compromissos: situação (status) e parte financeira (valor total, sinal em R$ ou %, valor efetivamente pago, saldo).
// Regras únicas usadas pela API, pelo chat e pela IA — um só lugar para não haver cálculos divergentes.
//  • sinal em % vira R$ pelo valor total (e é recalculado se o total mudar); sinal informado em R$ fica em R$;
//  • "sinal" é o combinado; "valorPago" é o que foi efetivamente recebido — só muda quando o usuário informa/confirma;
//  • nunca aceita sinal ou pago maior que o total, nem porcentagem acima de 100.
import { fail } from './http.js'

export const APPT_STATUS = ['scheduled', 'confirmed', 'done', 'cancelled', 'no_show'] as const
export const STATUS_LABEL: Record<string, string> = { scheduled: 'Agendado', confirmed: 'Confirmado', done: 'Concluído', cancelled: 'Cancelado', no_show: 'Não compareceu' }
export const r2 = (n: number) => Math.round(n * 100) / 100

/** Valor monetário vindo da tela/chat: undefined = não informado; null = apagar; número válido ≥ 0. */
export function dinheiro(v: unknown, campo: string): number | null | undefined {
  if (v === undefined) return undefined
  if (v === null || String(v).trim() === '') return null
  let t = String(v).trim().replace(/^r\$\s*/i, '').replace(/\s/g, '')
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(t)) t = t.replace(/\./g, '') // 1.200,50
  t = t.replace(',', '.')
  const n = Number(t)
  if (!isFinite(n) || n < 0 || n > 1e9) fail(400, 'Valor inválido.', 'invalid', campo)
  return r2(n)
}
function pct(v: unknown): number | null | undefined {
  if (v === undefined) return undefined
  if (v === null || String(v).trim() === '') return null
  const n = Number(String(v).replace('%', '').replace(',', '.').trim())
  if (!isFinite(n) || n <= 0 || n > 100) fail(400, 'A porcentagem do sinal deve ser maior que 0 e no máximo 100%.', 'invalid', 'sinal_pct')
  return Math.round(n * 100) / 100
}

/** Aplica os campos financeiros enviados (d) sobre os atuais (cur) e devolve o novo estado validado. */
export function aplicarFinanceiro(cur: any, d: any) {
  const g = (a: string, b: string) => (d[a] !== undefined ? d[a] : d[b])
  let valorTotal = cur.valorTotal ?? null, sinal = cur.sinal ?? null, sinalPct = cur.sinalPct ?? null, valorPago = cur.valorPago ?? null
  const vt = dinheiro(g('valor_total', 'valorTotal'), 'valor_total'); if (vt !== undefined) valorTotal = vt
  const sp = pct(g('sinal_pct', 'sinalPct'))
  const sv = dinheiro(g('sinal', 'sinal_valor'), 'sinal')
  if (sp !== undefined && sp !== null) { sinalPct = sp; sinal = null } // em % → calculado abaixo
  else if (sv !== undefined) { sinal = sv; sinalPct = null } // em R$ → fica em R$ (nunca confunde com %)
  else if (sp === null) { sinalPct = null; sinal = null }
  if (sinalPct !== null) {
    if (valorTotal === null) fail(400, 'Para sinal em porcentagem, informe o valor total.', 'invalid', 'sinal_pct')
    sinal = r2((valorTotal as number) * (sinalPct as number) / 100)
  }
  const vp = dinheiro(g('valor_pago', 'valorPago'), 'valor_pago'); if (vp !== undefined) valorPago = vp
  if (valorTotal !== null && sinal !== null && sinal > valorTotal) fail(400, 'O sinal não pode ser maior que o valor total.', 'invalid', 'sinal')
  if (valorTotal !== null && valorPago !== null && valorPago > valorTotal) fail(400, 'O valor pago não pode ser maior que o valor total.', 'invalid', 'valor_pago')
  return { valorTotal, sinal, sinalPct, valorPago }
}

/** Valores derivados para exibir (nunca gravados: sempre coerentes com os valores de origem). */
export function resumoFinanceiro(d: any) {
  const total = d.valorTotal ?? null, sinal = d.sinal ?? null, pago = d.valorPago ?? null
  const sinalPctCalc = d.sinalPct ?? (total && sinal !== null ? Math.round((sinal / total) * 1000) / 10 : null)
  return {
    valorTotal: total, sinal, sinalPct: d.sinalPct ?? null, sinalPctCalculado: sinalPctCalc, valorPago: pago,
    saldoAposSinal: total !== null && sinal !== null ? r2(total - sinal) : null,
    restante: total !== null ? r2(total - (pago || 0)) : null,
    pagamentoStatus: total === null ? (pago ? 'parcial' : null) : (pago || 0) >= total && total > 0 ? 'pago' : (pago || 0) > 0 ? 'parcial' : 'pendente',
  }
}

export const brl = (n: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(n)
/** Linhas de texto do financeiro de um compromisso (chat e confirmação). */
export function linhasFinanceiras(d: any): string[] {
  const f = resumoFinanceiro(d), L: string[] = []
  if (f.valorTotal !== null) L.push(`Valor total: ${brl(f.valorTotal)}`)
  if (f.sinal !== null) L.push(`Sinal: ${brl(f.sinal)}${f.sinalPct !== null ? ` (${String(f.sinalPct).replace('.', ',')}%)` : ''}`)
  if (f.saldoAposSinal !== null) L.push(`Saldo após o sinal: ${brl(f.saldoAposSinal)}`)
  if (f.valorPago !== null && f.valorPago > 0) L.push(`Valor pago: ${brl(f.valorPago)}`)
  else if (f.sinal !== null || f.valorTotal !== null) L.push('Valor pago: nenhum pagamento registrado')
  if (f.restante !== null && (f.valorPago || 0) > 0) L.push(`Restante a receber: ${brl(f.restante)}`)
  return L
}
