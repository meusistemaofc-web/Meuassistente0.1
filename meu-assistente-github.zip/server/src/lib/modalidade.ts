// Modalidade EXCLUSIVA do catálogo de cada empresa: 'products' OU 'services' (coluna businesses.modalidade, com CHECK no banco).
// data.tipo ('produtos' | 'servicos') é um ESPELHO gravado sempre no mesmo UPDATE (o restante do sistema já lê data.tipo);
// a coluna é a fonte de verdade e a sincronização do início corrige qualquer divergência a favor dela.
import type { Db } from '../db/index.js'

export type Modalidade = 'products' | 'services'
export const TIPO_DE: Record<Modalidade, 'produtos' | 'servicos'> = { products: 'produtos', services: 'servicos' }
export const MOD_DE = (tipo: unknown): Modalidade | null => (tipo === 'produtos' || tipo === 'products' ? 'products' : tipo === 'servicos' || tipo === 'services' ? 'services' : null)
export const ROTULO: Record<Modalidade, string> = { products: 'Produtos', services: 'Serviços' }
// mesmo critério de ramo já usado pelo sistema (nicheType) para empresas sem escolha
export const SERV_RE = /(barbear|salao|salão|cabel|manicure|pedicure|unha|estetic|estétic|clinic|clínic|consult|dentist|odonto|psicolog|terap|fisio|nutri|medic|médic|veterin|pet ?shop|banho e tosa|personal|academia|aula|curso|advog|contab|oficina|mec[aâ]nic|tatu|tattoo|massag|fotograf|eletricist|encanad|diarista|limpeza|costur|manuten)/i
const J = (v: any) => { if (v && typeof v === 'object') return v; try { return JSON.parse(String(v || '{}')) } catch { return {} } }
const ATIVOS_PED = ['novo', 'aceito', 'aguardando_pagamento', 'aguardando_aprovacao', 'sugestao']

/** Modalidade coerente com o que a empresa JÁ tem: escolha explícita → itens ativos → pedidos x agendamentos → ramo. */
export async function inferirModalidade(d: Pick<Db, 'query'>, b: any): Promise<{ modalidade: Modalidade; regra: string; ocultos: number }> {
  const x = J(b.data)
  const conta = async (m: Modalidade) => {
    const its = await d.query<any>('SELECT data FROM products WHERE business_id = $1', [b.id])
    return its.filter((r: any) => (J(r.data).tipo === 'servico') !== (m === 'products')).length
  }
  const exp = MOD_DE(x.tipo)
  if (exp) return { modalidade: exp, regra: 'escolha já feita pela empresa', ocultos: await conta(exp === 'products' ? 'services' : 'products') }
  const its = (await d.query<any>('SELECT data, active FROM products WHERE business_id = $1', [b.id])).filter((r: any) => r.active === true || r.active === 1 || r.active === 't')
  const s = its.filter((r: any) => J(r.data).tipo === 'servico').length, p = its.length - s
  let m: Modalidade | null = null, regra = ''
  if (p && !s) { m = 'products'; regra = 'só tinha produtos ativos' } else if (s && !p) { m = 'services'; regra = 'só tinha serviços ativos' }
  else if (p !== s) { m = p > s ? 'products' : 'services'; regra = `maioria dos itens ativos (${p} produto(s), ${s} serviço(s))` }
  if (!m) {
    const ords = await d.query<any>('SELECT data FROM orders WHERE business_id = $1', [b.id])
    const ag = ords.filter((o: any) => J(o.data).tipo === 'agendamento').length, pe = ords.length - ag
    if (ag !== pe) { m = ag > pe ? 'services' : 'products'; regra = `histórico (${pe} pedido(s), ${ag} agendamento(s))` }
  }
  if (!m) { m = SERV_RE.test(`${x.categoria || ''} ${x.tags || ''}`) ? 'services' : 'products'; regra = 'ramo da empresa' }
  return { modalidade: m, regra, ocultos: await conta(m === 'products' ? 'services' : 'products') }
}

/** Empresas existentes recebem a modalidade (uma vez, sem apagar nada) e o espelho data.tipo é alinhado à coluna. */
export async function backfillModalidades(d: Db, log: (m: string) => void = () => {}) {
  let rows: any[]
  try { rows = await d.query<any>('SELECT id, data, modalidade FROM businesses') } catch { return 0 } // banco antigo sem a coluna
  let n = 0
  for (const b of rows) {
    const x = J(b.data)
    if (b.modalidade && x.tipo === TIPO_DE[b.modalidade as Modalidade]) continue
    if (b.modalidade) { x.tipo = TIPO_DE[b.modalidade as Modalidade]; await d.query('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), b.id]); n++; continue }
    const r = await inferirModalidade(d, b)
    x.tipo = TIPO_DE[r.modalidade]
    x.modalidadeMigrada = { em: new Date().toISOString(), regra: r.regra, itensOcultos: r.ocultos }
    await d.query('UPDATE businesses SET modalidade = $1, data = $2 WHERE id = $3 AND modalidade IS NULL', [r.modalidade, JSON.stringify(x), b.id]); n++
  }
  if (n) log(`[modalidade] ${n} empresa(s) com modalidade definida/alinhada`)
  return n
}

/** Resumo do impacto de trocar a modalidade (nada é apagado nem convertido). */
export async function impactoTroca(d: Pick<Db, 'query'>, b: any, para: Modalidade) {
  const its = await d.query<any>('SELECT data, active FROM products WHERE business_id = $1', [b.id])
  const ativo = (r: any) => r.active === true || r.active === 1 || r.active === 't'
  const ehServ = (r: any) => J(r.data).tipo === 'servico'
  const daAtual = its.filter((r: any) => ativo(r) && (para === 'products' ? ehServ(r) : !ehServ(r))).length
  const daNova = its.filter((r: any) => para === 'products' ? !ehServ(r) : ehServ(r)).length
  const ords = await d.query<any>('SELECT status, data FROM orders WHERE business_id = $1', [b.id])
  const vivos = ords.filter((o: any) => ATIVOS_PED.includes(String(o.status)))
  const agend = vivos.filter((o: any) => J(o.data).tipo === 'agendamento').length, peds = vivos.length - agend
  return { itensOcultados: daAtual, itensReexibidos: daNova, pedidosAtivos: peds, agendamentosAtivos: agend }
}
