// Integração entre pedidos/agendamentos da empresa e os módulos do dono: Agenda (bloqueio de horário) e Financeiro (entradas).
// Tudo aqui é idempotente: o vínculo fica gravado no próprio pedido (agendaItemId / finItemId), então repetir a chamada
// (webhook duplicado, clique duplo, nova consulta de pagamento) nunca cria um segundo compromisso nem um segundo lançamento.
import { q, one, J, nowIso } from '../db/index.js'
import { createItem } from '../routes/items.js'
import { hydrateUser } from './session.js'
import { localDate } from './time.js'
import { settingsOf } from './account.js'

const tails = new Map<string, Promise<unknown>>()
/** Fila por chave (empresa ou pedido): duas operações com a mesma chave nunca rodam ao mesmo tempo neste processo. */
export function withLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const prev = tails.get(key) || Promise.resolve()
  const run = prev.catch(() => {}).then(fn)
  const tail = run.catch(() => {})
  tails.set(key, tail)
  tail.then(() => { if (tails.get(key) === tail) tails.delete(key) })
  return run
}

const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
const hhmm = (m: number) => `${String(Math.floor(m / 60) % 24).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
const brl = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ',')
const ownerOf = async (businessId: number) => {
  const b = await one('SELECT owner_id, data FROM businesses WHERE id = $1', [businessId]); if (!b) return null
  const u = await one('SELECT * FROM users WHERE id = $1', [Number(b.owner_id)]); if (!u) return null
  return { user: hydrateUser(u), biz: b, x: J<any>(b.data, {}) }
}
const saveOrderData = (orderId: number, d: any) => q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(d), orderId])

/** Registra o agendamento na Agenda do dono da empresa (uma vez só). O horário passa a ocupar a agenda e o dono recebe os avisos de 24 h/1 h. */
export function registerBookingInAgenda(orderId: number) {
  return withLock(`order:${orderId}`, async () => {
    const o = await one('SELECT * FROM orders WHERE id = $1', [orderId]); if (!o) return null
    const d = J<any>(o.data, {}); if (d.tipo !== 'agendamento' || d.agendaItemId) return d.agendaItemId || null
    if (['recusado', 'cancelado', 'aguardando_pagamento'].includes(String(o.status))) return null
    const ow = await ownerOf(Number(o.business_id)); if (!ow) return null
    const dur = Number(d.duracao) || 30, endTime = hhmm(toMin(d.hora) + dur)
    const notes = [`Agendamento #${o.id} pelo atendimento da empresa`, d.telefone ? `WhatsApp: ${d.telefone}` : '', d.obs ? `Obs.: ${d.obs}` : '', d.pagamento === 'online' && d.pago ? `Pago online: ${brl(Number(o.total))}` : '', d.restante != null ? `Restante a combinar: ${brl(d.restante)}` : ''].filter(Boolean).join('\n')
    const [it] = await createItem(ow.user, 'appointment', { title: `${d.servico} · ${d.cliente}`, date: d.data, time: d.hora, location: ow.x.endereco || '', person: d.cliente, notes })
    const cur = await one('SELECT data FROM items WHERE id = $1', [it.id]); const idata = J<any>(cur!.data, {})
    await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify({ ...idata, endTime, duration: dur, source: 'agendamento', orderId: Number(o.id), businessId: Number(o.business_id) }), it.id])
    d.agendaItemId = Number(it.id); await saveOrderData(Number(o.id), d)
    return Number(it.id)
  })
}
/** Pedido cancelado/recusado libera o horário; concluído marca o compromisso como feito. */
export async function syncBookingStatus(orderId: number, status: string) {
  const o = await one('SELECT * FROM orders WHERE id = $1', [orderId]); if (!o) return
  const d = J<any>(o.data, {}); if (d.tipo !== 'agendamento' || !d.agendaItemId) return
  if (status === 'cancelado' || status === 'recusado') { await q('DELETE FROM items WHERE id = $1', [d.agendaItemId]); delete d.agendaItemId; d.agendaLiberada = true; await saveOrderData(orderId, d) }
  else if (status === 'concluido') await q("UPDATE items SET status = 'done', updated_at = $1 WHERE id = $2", [nowIso(), d.agendaItemId])
}

/** Horários já ocupados na Agenda do dono por compromissos próprios (não vinculados a pedidos): também bloqueiam a venda de horários. */
export async function ownerBusySlots(businessId: number, date: string): Promise<[number, number][]> {
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [businessId]); if (!b) return []
  const rows = await q("SELECT data FROM items WHERE user_id = $1 AND type = 'appointment' AND day = $2 AND COALESCE(status,'scheduled') <> 'cancelled'", [Number(b.owner_id), date])
  const out: [number, number][] = []
  for (const r of rows) { const d = J<any>(r.data, {}); if (d.orderId || !d.time) continue; const s = toMin(d.time); out.push([s, d.endTime ? toMin(d.endTime) : s + 60]) }
  return out
}

/** Gera a entrada no Financeiro do dono quando o dinheiro de fato entrou (Pix online aprovado ou pedido/serviço concluído). Nunca duplica. */
export function recordOrderIncome(orderId: number, why: 'pago_online' | 'concluido') {
  return withLock(`order:${orderId}`, async () => {
    const o = await one('SELECT * FROM orders WHERE id = $1', [orderId]); if (!o) return null
    const d = J<any>(o.data, {}); if (d.finItemId) return d.finItemId
    if (['recusado', 'cancelado'].includes(String(o.status)) && why !== 'pago_online') return null
    const total = Math.round(Number(o.total) * 100) / 100; if (!(total > 0)) return null
    if (why === 'concluido' && d.pagamento === 'online' && !d.pago) return null // Pix automático ainda não pago: não entrou dinheiro
    await import('./coins.js').then((m) => m.adesaoPorCompra(o, d)).catch((e) => console.error('[moedas]', e?.message)) // adesão por compra (desativada por padrão; uma vez por pedido)
    const ow = await ownerOf(Number(o.business_id)); if (!ow) return null
    // idempotência independente da marca no pedido: outra gravação do pedido pode ter apagado `finItemId` (leitura-e-gravação concorrente)
    const jaLancado = (await q("SELECT id, data FROM items WHERE user_id = $1 AND type = 'expense' ORDER BY id DESC LIMIT 3000", [Number(ow.user.id)])).find((r: any) => J<any>(r.data, {}).source === `pedido:${Number(o.id)}`)
    if (jaLancado) { const nd0 = { ...J<any>((await one('SELECT data FROM orders WHERE id = $1', [orderId]))!.data, {}), finItemId: Number(jaLancado.id) }; await saveOrderData(Number(o.id), nd0); return Number(jaLancado.id) }
    const ag = d.tipo === 'agendamento'
    const method = ({ online: 'Pix (Mercado Pago)', pix: 'Pix', pixentrega: 'Pix', cartao: 'Cartão', dinheiro: 'Dinheiro' } as Record<string, string>)[d.pagamento] || ''
    const date = localDate(settingsOf(ow.user).timezone)
    const [it] = await createItem(ow.user, 'expense', { kind: 'income', amount: total, category: ag ? 'servicos' : 'vendas', date, method, source: `pedido:${o.id}`, description: `${ag ? 'Agendamento' : 'Pedido'} #${o.id} · ${ow.x.empresa || 'Empresa'} · ${d.cliente || ''}`.trim() })
    const cur = await one('SELECT data FROM items WHERE id = $1', [it.id]); const idata = J<any>(cur!.data, {})
    await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify({ ...idata, orderId: Number(o.id), businessId: Number(o.business_id), origem: why }), it.id])
    const fresh = await one('SELECT data FROM orders WHERE id = $1', [orderId]); const nd = { ...J<any>(fresh!.data, {}), finItemId: Number(it.id) }
    await saveOrderData(Number(o.id), nd)
    return Number(it.id)
  })
}
