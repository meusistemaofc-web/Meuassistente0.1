// INCENTIVOS DO CARRINHO — estratégias de compra configuradas pela empresa (Sua empresa → Ajustes → Incentivos do carrinho).
//
// Cada incentivo tem uma META (valor dos produtos ou quantidade de itens), um BENEFÍCIO (frete grátis, desconto em %,
// desconto em R$ ou cashback em MCoins da própria loja), período de validade, limite por cliente e a regra de soma com cupom.
//
// avaliar() é a regra ÚNICA: a vitrine mostra o progresso com ela ("Faltam R$ 15,00 para ganhar frete grátis") e o pedido
// é recalculado com ela no servidor — o que aparece na tela é o que vale no pedido.
// Regras de aplicação (sem acúmulo indevido):
//  • no máximo UM incentivo por pedido — o de maior vantagem para o cliente entre os desbloqueados;
//  • com cupom, só vale incentivo marcado "soma com cupom";
//  • frete grátis só vale na entrega (na retirada não há frete) e zera a taxa; descontos saem do valor dos produtos
//    (nunca passam dele); cashback é creditado em MCoins da loja só quando o pedido é pago/concluído, uma única vez;
//  • período (início/fim), pausa e limite por cliente são conferidos na hora do pedido.
import { q, one, J, B, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'

export type Beneficio = 'frete_gratis' | 'desconto_pct' | 'desconto_valor' | 'cashback'
export interface Incentivo { id: number; nome: string; metaTipo: 'valor' | 'itens'; meta: number; beneficio: Beneficio; valor: number; inicio: string | null; fim: string | null; ativo: boolean; combinaCupom: boolean; limiteCliente: number }
const num = (v: any) => Number(v) || 0
const r2 = (n: number) => Math.round(n * 100) / 100
const brl = (v: number) => 'R$ ' + r2(v).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const MAX_POR_EMPRESA = 10

export const out = (r: any): Incentivo => ({ id: Number(r.id), nome: String(r.nome), metaTipo: r.meta_tipo === 'itens' ? 'itens' : 'valor', meta: num(r.meta), beneficio: r.beneficio, valor: num(r.valor), inicio: isoOf(r.inicio) || null, fim: isoOf(r.fim) || null, ativo: B(r.ativo), combinaCupom: B(r.combina_cupom), limiteCliente: Math.max(0, Math.floor(num(r.limite_cliente))) })

/** Texto do benefício ("frete grátis", "10% de desconto", "R$ 10,00 de desconto", "R$ 10,00 de cashback"). */
export function textoBeneficio(i: Pick<Incentivo, 'beneficio' | 'valor'>) {
  return i.beneficio === 'frete_gratis' ? 'frete grátis' : i.beneficio === 'desconto_pct' ? `${String(i.valor).replace('.', ',')}% de desconto` : i.beneficio === 'desconto_valor' ? `${brl(i.valor)} de desconto` : `${brl(i.valor)} de cashback`
}
/** Situação no momento: em vigor, agendado, encerrado ou pausado. */
export function situacao(i: Incentivo, agora = Date.now()) {
  if (!i.ativo) return 'pausado'
  if (i.inicio && Date.parse(i.inicio) > agora) return 'agendado'
  if (i.fim && Date.parse(i.fim) < agora) return 'encerrado'
  return 'ativo'
}

/* ---------- MCoins para o cashback ---------- */
/** Moeda da loja que paga o cashback (precisa estar publicada, com valor de desconto e o sistema de MCoins ligado). */
export async function moedaCashback(businessId: number) {
  const C = await import('./coins.js'); const cfg = await C.coinsCfg(); if (!cfg.ativo) return null
  const c: any = await C.coinOfBusiness(businessId); if (!c || c.status !== 'ativa' || !(num(c.desconto) > 0)) return null
  return c as { id: number; simbolo: string; desconto: number; disponiveis: number; nome?: string }
}
/** Quantas moedas valem um cashback em R$ (para baixo: nunca credita mais do que o prometido). */
export const moedasDoCashback = (valor: number, desconto: number) => desconto > 0 ? Math.floor(Math.round((valor / desconto) * 10000) / 10000) : 0

/* ---------- cadastro (painel da empresa) ---------- */
export async function listar(businessId: number) { return (await q('SELECT * FROM cart_incentives WHERE business_id = $1 ORDER BY id DESC', [businessId])).map(out) }
function validar(b: any, x: any, temMoeda: boolean): Omit<Incentivo, 'id'> {
  const nome = String(b.nome ?? '').replace(/\s+/g, ' ').trim().slice(0, 60)
  if (nome.length < 3) fail(400, 'Dê um nome ao incentivo (ex.: Frete grátis acima de R$ 80).', 'invalid', 'nome')
  const metaTipo = b.metaTipo === 'itens' ? 'itens' : b.metaTipo === 'valor' ? 'valor' : null
  if (!metaTipo) fail(400, 'Escolha a meta: valor dos produtos ou quantidade de itens.', 'invalid', 'metaTipo')
  const meta = metaTipo === 'itens' ? Math.floor(num(b.meta)) : r2(num(b.meta))
  if (metaTipo === 'itens' && !(meta >= 2 && meta <= 999)) fail(400, 'A meta de itens precisa ser de 2 a 999 itens.', 'invalid', 'meta')
  if (metaTipo === 'valor' && !(meta >= 1 && meta <= 100000)) fail(400, 'A meta de valor precisa ser de R$ 1,00 a R$ 100.000,00.', 'invalid', 'meta')
  const beneficio = (['frete_gratis', 'desconto_pct', 'desconto_valor', 'cashback'] as const).find((k) => k === b.beneficio)
  if (!beneficio) fail(400, 'Escolha o benefício.', 'invalid', 'beneficio')
  let valor = r2(num(b.valor))
  if (beneficio === 'frete_gratis') { valor = 0; if (!x.entrega?.entrega) fail(400, 'Frete grátis só faz sentido com entrega: ligue a entrega em Entrega e pagamento.', 'invalid', 'beneficio') }
  if (beneficio === 'desconto_pct' && !(valor >= 1 && valor <= 90)) fail(400, 'O desconto precisa ser de 1% a 90%.', 'invalid', 'valor')
  if (beneficio === 'desconto_valor' && !(valor > 0)) fail(400, 'Informe o valor do desconto.', 'invalid', 'valor')
  if (beneficio === 'desconto_valor' && metaTipo === 'valor' && valor >= meta) fail(400, 'O desconto precisa ser menor que a meta de valor (senão o pedido sai de graça).', 'invalid', 'valor')
  if (beneficio === 'cashback') { if (!(valor > 0 && valor <= 10000)) fail(400, 'Informe o valor do cashback.', 'invalid', 'valor'); if (!temMoeda) fail(400, 'O cashback é pago em MCoins da sua loja, e a sua empresa ainda não tem uma moeda ativa. Escolha outro benefício ou peça a moeda ao administrador.', 'invalid', 'beneficio') }
  const dt = (v: any, campo: string) => { if (v == null || v === '') return null; const t = Date.parse(String(v)); if (!Number.isFinite(t)) fail(400, 'Data inválida.', 'invalid', campo); return new Date(t).toISOString() }
  const inicio = dt(b.inicio, 'inicio'), fim = dt(b.fim, 'fim')
  if (inicio && fim && Date.parse(fim) <= Date.parse(inicio)) fail(400, 'O fim precisa ser depois do início.', 'invalid', 'fim')
  const limiteCliente = Math.max(0, Math.min(100, Math.floor(num(b.limiteCliente))))
  return { nome, metaTipo, meta, beneficio: beneficio!, valor, inicio, fim, ativo: b.ativo !== false, combinaCupom: b.combinaCupom === true, limiteCliente }
}
export async function salvar(business: any, b: any, id?: number) {
  const x = J<any>(business.data, {}), bid = Number(business.id)
  const v = validar(b, x, !!(await moedaCashback(bid)))
  const agora = nowIso()
  if (id) {
    const ex = await one('SELECT id FROM cart_incentives WHERE id = $1 AND business_id = $2', [id, bid]); if (!ex) fail(404, 'Incentivo não encontrado.', 'not_found')
    await q('UPDATE cart_incentives SET nome=$1, meta_tipo=$2, meta=$3, beneficio=$4, valor=$5, inicio=$6, fim=$7, ativo=$8, combina_cupom=$9, limite_cliente=$10, updated_at=$11 WHERE id=$12', [v.nome, v.metaTipo, v.meta, v.beneficio, v.valor, v.inicio, v.fim, v.ativo, v.combinaCupom, v.limiteCliente, agora, id])
    return id
  }
  const n = Number((await one('SELECT COUNT(*) AS n FROM cart_incentives WHERE business_id = $1', [bid]))?.n || 0)
  if (n >= MAX_POR_EMPRESA) fail(400, `Limite de ${MAX_POR_EMPRESA} incentivos por empresa. Exclua um que não usa mais.`, 'invalid')
  await q('INSERT INTO cart_incentives (business_id, nome, meta_tipo, meta, beneficio, valor, inicio, fim, ativo, combina_cupom, limite_cliente, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12)', [bid, v.nome, v.metaTipo, v.meta, v.beneficio, v.valor, v.inicio, v.fim, v.ativo, v.combinaCupom, v.limiteCliente, agora])
  return Number((await one('SELECT id FROM cart_incentives WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [bid]))!.id)
}
export async function mudarStatus(businessId: number, id: number, ativo: boolean) {
  const r = await q('UPDATE cart_incentives SET ativo = $1, updated_at = $2 WHERE id = $3 AND business_id = $4 RETURNING id', [ativo, nowIso(), id, businessId]); if (!r.length) fail(404, 'Incentivo não encontrado.', 'not_found')
}
export async function excluir(businessId: number, id: number) {
  const r = await q('DELETE FROM cart_incentives WHERE id = $1 AND business_id = $2 RETURNING id', [id, businessId]); if (!r.length) fail(404, 'Incentivo não encontrado.', 'not_found')
}
/** Resultados por incentivo (pedidos que usaram, valor vendido, desconto e cashback concedidos). */
export async function resultados(businessId: number) {
  const rows = await q("SELECT total, status, data FROM orders WHERE business_id = $1 AND status NOT IN ('recusado','cancelado','aguardando_pagamento') ORDER BY id DESC LIMIT 5000", [businessId])
  const m = new Map<number, { pedidos: number; vendido: number; desconto: number; cashback: number }>()
  for (const r of rows as any[]) { const inc = J<any>(r.data, {}).incentivo; if (!inc?.id) continue; const s = m.get(Number(inc.id)) || { pedidos: 0, vendido: 0, desconto: 0, cashback: 0 }; s.pedidos++; s.vendido = r2(s.vendido + num(r.total)); s.desconto = r2(s.desconto + num(inc.desconto) + num(inc.freteGratis ? inc.taxaOriginal : 0)); s.cashback = r2(s.cashback + num(inc.cashback?.valor)); m.set(Number(inc.id), s) }
  return m
}

/* ---------- regra de avaliação (vitrine, carrinho e pedido) ---------- */
/** Incentivos em vigor agora para a vitrine e o pedido (cashback só aparece se a loja tiver moeda para pagar). */
export async function vigentes(businessId: number, agora = Date.now()) {
  const todos = (await q('SELECT * FROM cart_incentives WHERE business_id = $1 AND ativo = $2', [businessId, true])).map(out).filter((i) => situacao(i, agora) === 'ativo')
  if (!todos.some((i) => i.beneficio === 'cashback')) return todos
  const moeda = await moedaCashback(businessId)
  return todos.filter((i) => i.beneficio !== 'cashback' || (moeda && moedasDoCashback(i.valor, moeda.desconto) > 0))
}
/** Forma pública (vitrine): sem regras internas além do necessário para o cliente entender e o app calcular igual. */
export const publico = (i: Incentivo) => ({ id: i.id, nome: i.nome, metaTipo: i.metaTipo, meta: i.meta, beneficio: i.beneficio, valor: i.valor, fim: i.fim, combinaCupom: i.combinaCupom, texto: textoBeneficio(i) })

export interface Carrinho { subtotal: number; itens: number; modo?: 'entrega' | 'retirada' | null; taxa?: number; temCupom?: boolean; entrega?: boolean }
export interface Avaliacao {
  aplicado: null | { id: number; nome: string; beneficio: Beneficio; texto: string; desconto: number; freteGratis: boolean; cashback: number; mensagem: string }
  proximo: null | { id: number; texto: string; falta: number; faltaTipo: 'valor' | 'itens'; progresso: number; mensagem: string }
  bloqueadoPorCupom: null | { id: number; nome: string; texto: string }
}
const atingiu = (i: Pick<Incentivo, 'metaTipo' | 'meta'>, c: Carrinho) => (i.metaTipo === 'itens' ? c.itens : c.subtotal) >= i.meta - 1e-9
/** Vantagem em R$ de um incentivo para este carrinho (frete grátis vale a taxa da entrega; cashback, o valor prometido). */
function vantagem(i: Incentivo, c: Carrinho) {
  if (i.beneficio === 'frete_gratis') return c.modo === 'entrega' ? num(c.taxa) : 0
  if (i.beneficio === 'desconto_pct') return r2(c.subtotal * i.valor / 100)
  if (i.beneficio === 'desconto_valor') return r2(Math.min(i.valor, c.subtotal))
  return i.valor // cashback: crédito depois da compra
}
export function avaliar(lista: Incentivo[], c: Carrinho): Avaliacao {
  const valem = lista.filter((i) => i.beneficio !== 'frete_gratis' || c.entrega !== false) // loja sem entrega: frete grátis não se aplica
  const desbloq = valem.filter((i) => atingiu(i, c)), podem = desbloq.filter((i) => !c.temCupom || i.combinaCupom)
  // o melhor para o cliente; empate: desconto imediato antes de cashback; depois o mais antigo (id menor)
  const ord = (a: Incentivo, b: Incentivo) => vantagem(b, c) - vantagem(a, c) || (a.beneficio === 'cashback' ? 1 : 0) - (b.beneficio === 'cashback' ? 1 : 0) || a.id - b.id
  const util = podem.filter((i) => vantagem(i, c) > 0 || (i.beneficio === 'frete_gratis' && c.modo == null)).sort(ord)
  const best = util[0] || null
  let aplicado: Avaliacao['aplicado'] = null
  if (best) {
    const fg = best.beneficio === 'frete_gratis', desc = best.beneficio === 'desconto_pct' || best.beneficio === 'desconto_valor' ? vantagem(best, c) : 0
    const t = textoBeneficio(best)
    aplicado = { id: best.id, nome: best.nome, beneficio: best.beneficio, texto: t, desconto: desc, freteGratis: fg && c.modo === 'entrega', cashback: best.beneficio === 'cashback' ? best.valor : 0,
      mensagem: fg ? (c.modo === 'retirada' ? 'Você desbloqueou frete grátis (vale para entrega).' : 'Você ganhou frete grátis!') : best.beneficio === 'cashback' ? `Você ganhou ${t}! O crédito cai em MCoins da loja quando o pedido for concluído.` : `Você ganhou ${t}!` }
  }
  // próximo benefício a desbloquear: entre os que ainda faltam, o mais perto (maior progresso); com cupom, só os que somam
  const faltam = valem.filter((i) => !atingiu(i, c) && (!c.temCupom || i.combinaCupom) && (!best || vantagemPotencial(i, c) > vantagem(best, c)))
  const prog = (i: Incentivo) => Math.max(0, Math.min(0.999, (i.metaTipo === 'itens' ? c.itens : c.subtotal) / i.meta))
  const nx = faltam.sort((a, b) => prog(b) - prog(a) || a.meta - b.meta)[0] || null
  let proximo: Avaliacao['proximo'] = null
  if (nx) {
    const t = textoBeneficio(nx)
    if (nx.metaTipo === 'itens') { const f = Math.max(1, Math.ceil(nx.meta - c.itens)); proximo = { id: nx.id, texto: t, falta: f, faltaTipo: 'itens', progresso: prog(nx), mensagem: `Adicione mais ${f} ${f === 1 ? 'produto' : 'itens'} e ganhe ${t}.` } }
    else { const f = r2(nx.meta - c.subtotal); proximo = { id: nx.id, texto: t, falta: f, faltaTipo: 'valor', progresso: prog(nx), mensagem: `Faltam ${brl(f)} para ganhar ${t}.` } }
  }
  const bl = c.temCupom ? desbloq.filter((i) => !i.combinaCupom).sort(ord)[0] : null
  return { aplicado, proximo, bloqueadoPorCupom: bl ? { id: bl.id, nome: bl.nome, texto: textoBeneficio(bl) } : null }
}
/** Vantagem que o incentivo daria se fosse atingido (para não anunciar um "próximo" pior do que o já conquistado). */
function vantagemPotencial(i: Incentivo, c: Carrinho) {
  if (i.beneficio === 'frete_gratis') return c.modo === 'entrega' ? num(c.taxa) : c.modo == null ? 1 : 0
  if (i.beneficio === 'desconto_pct') return r2(Math.max(c.subtotal, i.metaTipo === 'valor' ? i.meta : 0) * i.valor / 100)
  return i.valor
}

/** Aplicação no PEDIDO (servidor): confere vigência e limite por cliente e devolve o que entra no pedido. */
export async function paraPedido(businessId: number, userId: number, c: Carrinho) {
  const lista = await vigentes(businessId)
  if (!lista.length) return { av: avaliar([], c), registro: null as any }
  // limite por cliente: pedidos válidos (não recusados/cancelados) que já usaram o incentivo
  const comLimite = lista.filter((i) => i.limiteCliente > 0)
  let usados = new Map<number, number>()
  if (comLimite.length) { const rows = await q("SELECT data FROM orders WHERE business_id = $1 AND customer_id = $2 AND status NOT IN ('recusado','cancelado') ORDER BY id DESC LIMIT 1000", [businessId, userId]); for (const r of rows as any[]) { const id = Number(J<any>(r.data, {}).incentivo?.id); if (id) usados.set(id, (usados.get(id) || 0) + 1) } }
  const validos = lista.filter((i) => !(i.limiteCliente > 0 && (usados.get(i.id) || 0) >= i.limiteCliente))
  const av = avaliar(validos, c)
  const a = av.aplicado
  if (!a || (!a.desconto && !a.freteGratis && !a.cashback)) return { av, registro: null as any }
  let cashback: any = undefined
  if (a.cashback) { const m = await moedaCashback(businessId); const moedas = m ? moedasDoCashback(a.cashback, m.desconto) : 0; if (!m || moedas <= 0) return { av: { ...av, aplicado: null }, registro: null as any }; cashback = { valor: a.cashback, moedas, coinId: m.id, simbolo: m.simbolo, creditado: false } }
  return { av, registro: { id: a.id, nome: a.nome, beneficio: a.beneficio, texto: a.texto, desconto: a.desconto, freteGratis: a.freteGratis, taxaOriginal: a.freteGratis ? r2(num(c.taxa)) : 0, ...(cashback ? { cashback } : {}) } }
}
