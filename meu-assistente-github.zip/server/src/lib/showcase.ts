// Vitrine inteligente de links: o administrador cadastra; o chat abre um menu com "/". Busca 100% determinística (sem IA).
// Independente dos anúncios. Um atalho só abre um card com link externo: nunca executa comando administrativo ou financeiro.
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'

export const KEYWORD_RE = /^\/[a-z0-9][a-z0-9_-]{0,29}$/
const strip = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
export const normKeyword = (v: any) => { let k = strip(String(v ?? '')).trim().replace(/\s+/g, ''); if (k && !k.startsWith('/')) k = '/' + k; return k }
export function cleanUrl(v: any): string {
  const s = String(v ?? '').trim()
  if (s.length < 8 || s.length > 600 || /[\s<>"']/.test(s)) fail(400, 'Informe uma URL válida que comece com https:// (ou http://).', 'invalid', 'url')
  let u: URL; try { u = new URL(s) } catch { fail(400, 'Informe uma URL válida que comece com https:// (ou http://).', 'invalid', 'url'); throw 0 }
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || !u.hostname.includes('.')) fail(400, 'Só são aceitos links http/https de sites públicos, sem usuário e senha.', 'invalid', 'url')
  return u.toString()
}
function cleanImage(v: any): string | null {
  const s = String(v ?? '').trim(); if (!s) return null
  if (/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(s)) { if (s.length > 350_000) fail(400, 'Imagem grande demais (máx. ~250 KB).', 'invalid', 'image'); return s }
  if (/^https:\/\/[^\s<>"']{4,500}$/.test(s)) return s
  return fail(400, 'Imagem inválida: envie PNG, JPG ou WebP, ou um link https.', 'invalid', 'image')
}
const arrN = (v: any) => (Array.isArray(v) ? [...new Set(v.map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 200) : [])
export const CANAIS = ['chat', 'agentes'] as const
export const PUBLICOS = ['todos', 'empresas', 'admins'] as const

const out = (r: any, admin = false) => ({
  id: Number(r.id), palavra: r.keyword, titulo: r.title, descricao: r.description, url: r.url, imagem: r.image || null, ativo: !!r.active, ordem: Number(r.position),
  canais: J<string[]>(r.channels, []), publico: r.audience, empresas: J<number[]>(r.businesses, []),
  ...(admin ? { acessos: Number(r.views), cliques: Number(r.clicks), atualizadoEm: r.updated_at } : {}),
})
function clean(b: any, cur?: any) {
  const d: any = {}
  if (!cur || b.palavra !== undefined) { const k = normKeyword(b.palavra); if (!KEYWORD_RE.test(k)) fail(400, 'A palavra-chave precisa começar com / e ter letras, números, - ou _ (ex.: /musica).', 'invalid', 'palavra'); d.keyword = k }
  if (!cur || b.titulo !== undefined) { const t = String(b.titulo ?? '').trim(); if (t.length < 2 || t.length > 80) fail(400, 'Título de 2 a 80 letras.', 'invalid', 'titulo'); d.title = t }
  if (!cur || b.descricao !== undefined) { const t = String(b.descricao ?? '').trim(); if (t.length < 3 || t.length > 300) fail(400, 'Descrição de 3 a 300 letras.', 'invalid', 'descricao'); d.description = t }
  if (!cur || b.url !== undefined) d.url = cleanUrl(b.url)
  if (!cur || b.imagem !== undefined) { d.image = cleanImage(b.imagem); if (!cur && !d.image) fail(400, 'Envie a imagem ou capa.', 'invalid', 'imagem') }
  if (b.canais !== undefined || !cur) { const c = (Array.isArray(b.canais) ? b.canais : ['chat', 'agentes']).filter((x: any) => (CANAIS as readonly string[]).includes(x)); if (!c.length) fail(400, 'Escolha onde o atalho aparece (chat e/ou agentes).', 'invalid', 'canais'); d.channels = JSON.stringify([...new Set(c)]) }
  if (b.publico !== undefined || !cur) { if (!(PUBLICOS as readonly string[]).includes(b.publico ?? 'todos')) fail(400, 'Público inválido.', 'invalid', 'publico'); d.audience = b.publico ?? 'todos' }
  if (b.empresas !== undefined || !cur) d.businesses = JSON.stringify(arrN(b.empresas))
  if (b.ativo !== undefined) d.active = !!b.ativo
  if (b.ordem !== undefined) d.position = Math.max(0, Math.min(9999, Math.round(Number(b.ordem)) || 0))
  return d
}
const dupCheck = async (k: string, except = 0) => { const x = await one('SELECT id FROM showcase_links WHERE keyword = $1 AND id <> $2', [k, except]); if (x) fail(409, `A palavra-chave ${k} já está em uso por outro cadastro.`, 'duplicate', 'palavra') }
export async function listAdmin() { return (await q('SELECT * FROM showcase_links ORDER BY position, id')).map((r) => out(r, true)) }
export async function create(b: any, adminId: number) {
  const d = clean(b); await dupCheck(d.keyword)
  const pos = d.position ?? Number((await one('SELECT COALESCE(MAX(position),0)+10 AS n FROM showcase_links'))?.n || 10), n = nowIso()
  await q('INSERT INTO showcase_links (keyword,title,description,url,image,active,position,channels,audience,businesses,created_by,created_at,updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12)', [d.keyword, d.title, d.description, d.url, d.image, d.active ?? true, pos, d.channels, d.audience, d.businesses, adminId, n])
  return out(await one('SELECT * FROM showcase_links WHERE keyword = $1', [d.keyword]), true)
}
export async function update(id: number, b: any) {
  const cur = await one('SELECT * FROM showcase_links WHERE id = $1', [id]); if (!cur) fail(404, 'Cadastro não encontrado.', 'not_found')
  const d = clean(b, cur); if (d.keyword) await dupCheck(d.keyword, id)
  const keys = Object.keys(d); if (keys.length) await q(`UPDATE showcase_links SET ${keys.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${keys.length + 1} WHERE id = $${keys.length + 2}`, [...keys.map((k) => d[k]), nowIso(), id])
  return out(await one('SELECT * FROM showcase_links WHERE id = $1', [id]), true)
}
export async function remove(id: number) { const r = await one('SELECT id FROM showcase_links WHERE id = $1', [id]); if (!r) fail(404, 'Cadastro não encontrado.', 'not_found'); await q('DELETE FROM showcase_links WHERE id = $1', [id]) }
export async function reorder(ids: number[]) { let i = 10; for (const id of arrN(ids)) { await q('UPDATE showcase_links SET position = $1, updated_at = $2 WHERE id = $3', [i, nowIso(), id]); i += 10 } }

export interface Viewer { userId: number | null; isAdmin: boolean; ownedBusinesses: number[] }
/** Quem pode ver o atalho (ativo, canal, público e empresas). Regras fixas e determinísticas. */
export function visibleTo(r: any, canal: 'chat' | 'agentes', v: Viewer, businessId = 0): boolean {
  if (!r.active || !J<string[]>(r.channels, []).includes(canal)) return false
  if (r.audience === 'admins' && !v.isAdmin) return false
  if (r.audience === 'empresas' && !v.isAdmin && !v.ownedBusinesses.length) return false
  const bs = J<number[]>(r.businesses, [])
  if (bs.length) { if (canal === 'agentes') { if (!bs.includes(businessId)) return false } else if (!v.isAdmin && !bs.some((x) => v.ownedBusinesses.includes(x))) return false }
  return true
}
/** Busca: "/" lista tudo; "/mus" filtra por prefixo (depois por trecho); "/musica" exato destaca o cadastro. */
export function search<T extends { keyword?: string; palavra?: string; title?: string; titulo?: string }>(list: T[], token: string) {
  const t = normKeyword(token), kw = (x: any) => String(x.palavra ?? x.keyword), ti = (x: any) => strip(String(x.titulo ?? x.title ?? ''))
  if (t === '/' || t === '') return { exato: null as T | null, itens: list }
  const exato = list.find((x) => kw(x) === t) || null, term = t.slice(1)
  const pre = list.filter((x) => kw(x).startsWith(t)), rest = list.filter((x) => !pre.includes(x) && (kw(x).slice(1).includes(term) || ti(x).includes(term)))
  return { exato, itens: [...pre, ...rest] }
}
export async function visibleList(canal: 'chat' | 'agentes', v: Viewer, businessId = 0) {
  return (await q('SELECT * FROM showcase_links WHERE active = $1 ORDER BY position, id', [true])).filter((r) => visibleTo(r, canal, v, businessId))
}
export const lite = (r: any) => ({ id: Number(r.id), palavra: r.keyword, titulo: r.title, descricao: r.description })
export async function openCard(id: number, canal: 'chat' | 'agentes', v: Viewer, businessId = 0) {
  const r: any = await one('SELECT * FROM showcase_links WHERE id = $1', [id]); if (!r || !visibleTo(r, canal, v, businessId)) fail(404, 'Atalho indisponível.', 'not_found')
  await q('UPDATE showcase_links SET views = views + 1 WHERE id = $1', [id])
  return { id: Number(r.id), palavra: r.keyword, titulo: r.title, descricao: r.description, imagem: r.image || null, url: r.url as string }
}
export async function click(id: number, canal: 'chat' | 'agentes', v: Viewer, businessId = 0) {
  const r: any = await one('SELECT * FROM showcase_links WHERE id = $1', [id]); if (!r || !visibleTo(r, canal, v, businessId)) fail(404, 'Atalho indisponível.', 'not_found')
  await q('UPDATE showcase_links SET clicks = clicks + 1 WHERE id = $1', [id]); return { url: r.url as string }
}
