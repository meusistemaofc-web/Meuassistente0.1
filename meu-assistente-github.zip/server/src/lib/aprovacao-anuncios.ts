// Modo de aprovação dos anúncios (configuração GLOBAL do administrador): 'manual' (padrão — o admin aprova cada anúncio)
// ou 'automatico' (o anúncio é aprovado e publicado sozinho depois das validações de segurança e integridade).
// Regras: o modo é registrado no anúncio no momento em que ele é ENVIADO (criado); trocar o modo depois não aprova,
// reprova nem suspende nada que já existe. Fluxo ÚNICO: a aprovação automática usa a mesma publicação (activate) da manual.
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'

export type ModoAprovacao = 'manual' | 'automatico'
export interface CfgAprovacao { modo: ModoAprovacao; alteradoPor: number | null; alteradoPorNome: string | null; alteradoEm: string | null; historico: { modo: ModoAprovacao; por: number; nome: string; em: string }[] }
const PADRAO: CfgAprovacao = { modo: 'manual', alteradoPor: null, alteradoPorNome: null, alteradoEm: null, historico: [] }
export async function cfgAprovacao(): Promise<CfgAprovacao> { const c = await getConfig<any>('ads_approval', {}); return { ...PADRAO, ...c, modo: c?.modo === 'automatico' ? 'automatico' : 'manual', historico: Array.isArray(c?.historico) ? c.historico : [] } }
export async function definirModo(modo: ModoAprovacao, por: { id: number; name?: string }) {
  const c = await cfgAprovacao(), em = nowIso()
  const nova: CfgAprovacao = { modo, alteradoPor: por.id, alteradoPorNome: por.name || null, alteradoEm: em, historico: [{ modo, por: por.id, nome: por.name || '', em }, ...c.historico].slice(0, 30) }
  await setConfig('ads_approval', nova); return nova
}

/** Validações de segurança e integridade antes da publicação automática. Qualquer falha → o anúncio vai para a análise manual. */
export async function validarParaPublicacao(b: any, planos: any[]): Promise<{ ok: boolean; falhas: string[]; verificadas: string[] }> {
  const d = J<any>(b.data, {}), falhas: string[] = [], verificadas: string[] = []
  const chk = (nome: string, ok: boolean, falha: string) => { verificadas.push(nome); if (!ok) falhas.push(falha) }
  const plano = planos.find((p) => p.id === b.plan_id)
  chk('plano válido', !!plano, 'plano inexistente')
  chk('dados obrigatórios', !!(String(d.empresa || '').trim() && String(d.categoria || '').trim() && String(d.titulo || '').trim()), 'faltam nome, ramo ou título')
  chk('contato do plano', !plano || Number(plano.nivel) < 2 || !!(d.zap || d.insta), 'plano exige WhatsApp ou Instagram')
  chk('pagamento confirmado', d.pago === true || Number(plano?.preco) === 0, 'pagamento não confirmado')
  chk('modalidade definida', d.tipo === 'produtos' || d.tipo === 'servicos', 'modalidade do catálogo não definida')
  chk('link seguro', !d.link || /^https:\/\/\S+\.\S+/.test(String(d.link)), 'link sem https')
  const dono = await one('SELECT status FROM users WHERE id = $1', [b.owner_id])
  chk('conta do dono ativa', !!dono && dono.status === 'active', 'conta do dono inativa ou bloqueada')
  chk('sem suspensão/revogação anterior', !d.revogado, 'anúncio já foi suspenso pelo administrador')
  const rec = await q("SELECT COUNT(*) AS n FROM businesses WHERE owner_id = $1 AND status = 'recusado' AND id <> $2", [b.owner_id, b.id])
  chk('dono sem anúncio reprovado pendente', Number(rec[0]?.n || 0) === 0, 'o dono tem anúncio reprovado (revisão manual)')
  return { ok: !falhas.length, falhas, verificadas }
}
