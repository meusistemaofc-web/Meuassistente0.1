// Inteligência empresarial: o Chat Principal (e o cartão do chat) consulta os dados REAIS da empresa do dono por aqui.
// Regras:
//  • SOMENTE LEITURA: nada aqui grava, move saldo ou altera pedido/registro financeiro; não há banco paralelo — as fontes oficiais são
//    `orders` (pedidos e agendamentos), `business_stats` (acessos), `items` (módulo Finanças), `crm_*` (CRM) e os dados de cupom/MCoins gravados no pedido;
//  • permissão no servidor: só o DONO da empresa (não existem contas de equipe); outra empresa responde 404, como no CRM;
//  • integridade: "sem fonte" (disponivel:false) é diferente de zero; nada é estimado; cada indicador diz de onde vem e como foi calculado.
// Serviços: PeriodService (períodos), SalesAnalyticsService (vendas/pedidos/clientes/agendamentos/produtos), TrafficAnalyticsService (acessos),
// FinanceAnalyticsService (Finanças), InsightService (tendências e sugestões com critério visível) e BusinessIntelligenceService (orquestra).
import { q, one, J } from '../db/index.js'
import { fail } from './http.js'
import { localDate, addDays, validTz } from './time.js'
import { phoneKey } from './crm.js'

const r2 = (n: number) => Math.round(n * 100) / 100
const num = (v: any) => Number(v) || 0
const DATA = /^\d{4}-\d{2}-\d{2}$/
const CANCEL = ['cancelado', 'recusado']
const ABERTO = ['aguardando_pagamento', 'novo', 'aceito', 'preparo', 'saiu', 'pronto']

export const DEFINICOES = {
  faturamento: 'Vendas pagas/concluídas: pedido concluído ou pago online (mesma regra do relatório da empresa e do MEI). Inclui agendamentos.',
  pendente: 'Pedidos/agendamentos em aberto (não cancelados) que ainda não foram concluídos nem pagos online.',
  bruto: 'Faturamento + pendente: tudo que foi vendido no período, sem os cancelados.',
  cancelado: 'Pedidos/agendamentos com situação cancelado ou recusado.',
  periodo: 'Dias pelo horário local do usuário; acessos seguem o dia de Brasília (como são gravados).',
  clientes: 'Clientes = quem fez pedido/agendamento (inclusive convidados, unidos por telefone). Novo = primeira compra no período; recorrente = 2 ou mais compras válidas.'
}

/* ---------- períodos ---------- */
export type Per = { id: string; label: string; de: string; ate: string; dias: number; anterior: { de: string; ate: string; label: string }; hoje: string; tz: string }
const diff = (a: string, b: string) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86400_000)
const dow = (d: string) => (new Date(d + 'T12:00:00Z').getUTCDay() + 6) % 7 // 0 = segunda
const fimMes = (d: string) => { const x = new Date(d.slice(0, 7) + '-01T12:00:00Z'); x.setUTCMonth(x.getUTCMonth() + 1); x.setUTCDate(0); return x.toISOString().slice(0, 10) }
const mesAnt = (d: string) => { const x = new Date(d.slice(0, 7) + '-01T12:00:00Z'); x.setUTCMonth(x.getUTCMonth() - 1); return x.toISOString().slice(0, 10) }
const br = (d: string) => d.split('-').reverse().join('/')
export const PERIODOS = ['hoje', 'ontem', 'semana', 'semana_passada', 'mes', 'mes_passado', 'ultimos_7_dias', 'ultimos_30_dias', 'ano', 'personalizado']
export function periodo(spec: { periodo?: string; de?: string; ate?: string }, tzIn?: string): Per {
  const tz = validTz(tzIn), hoje = localDate(tz); let id = String(spec.periodo || '').toLowerCase().trim(), de = hoje, ate = hoje, label = ''
  if (spec.de || spec.ate) id = 'personalizado'
  if (!id) id = 'mes'
  const wk = addDays(hoje, -dow(hoje)), m0 = hoje.slice(0, 7) + '-01'
  switch (id) {
    case 'hoje': label = 'hoje'; break
    case 'ontem': de = ate = addDays(hoje, -1); label = 'ontem'; break
    case 'semana': de = wk; label = 'esta semana (segunda até hoje)'; break
    case 'semana_passada': de = addDays(wk, -7); ate = addDays(wk, -1); label = 'semana passada'; break
    case 'mes': de = m0; label = 'este mês'; break
    case 'mes_passado': de = mesAnt(hoje); ate = fimMes(de); label = 'mês passado'; break
    case 'ultimos_7_dias': de = addDays(hoje, -6); label = 'últimos 7 dias'; break
    case 'ultimos_30_dias': de = addDays(hoje, -29); label = 'últimos 30 dias'; break
    case 'ano': de = hoje.slice(0, 4) + '-01-01'; label = 'este ano'; break
    case 'personalizado': {
      de = DATA.test(String(spec.de)) ? String(spec.de) : (DATA.test(String(spec.ate)) ? String(spec.ate) : hoje); ate = DATA.test(String(spec.ate)) ? String(spec.ate) : hoje
      if (de > ate) [de, ate] = [ate, de]
      label = de === ate ? br(de) : `${br(de)} a ${br(ate)}`; break
    }
    default: fail(400, `Período "${id}" desconhecido. Use: ${PERIODOS.join(', ')}.`, 'invalid', 'periodo')
  }
  if (ate > hoje) ate = hoje // futuro ainda não aconteceu
  if (de > ate) de = ate
  const dias = diff(de, ate) + 1; if (dias > 400) fail(400, 'Período muito longo (máximo de 400 dias).', 'invalid', 'periodo')
  let aDe: string, aAte: string, aLabel: string
  if (id === 'semana') { aDe = addDays(de, -7); aAte = addDays(aDe, dias - 1); aLabel = 'mesmos dias da semana passada' }
  else if (id === 'mes') { aDe = mesAnt(de); aAte = addDays(aDe, dias - 1); if (aAte > fimMes(aDe)) aAte = fimMes(aDe); aLabel = 'mesmos dias do mês passado' }
  else if (id === 'ano') { aDe = `${+de.slice(0, 4) - 1}-01-01`; aAte = `${+de.slice(0, 4) - 1}${ate.slice(4)}`; aLabel = 'mesmo período do ano passado' }
  else if (id === 'semana_passada') { aDe = addDays(de, -7); aAte = addDays(ate, -7); aLabel = 'semana anterior' }
  else if (id === 'mes_passado') { aDe = mesAnt(de); aAte = fimMes(aDe); aLabel = 'mês anterior' }
  else { aDe = addDays(de, -dias); aAte = addDays(de, -1); aLabel = id === 'hoje' ? 'ontem' : id === 'ontem' ? 'anteontem' : `${dias} dia(s) imediatamente antes` }
  return { id, label, de, ate, dias, hoje, tz, anterior: { de: aDe, ate: aAte, label: aLabel } }
}

/* ---------- acesso ---------- */
/** Empresa do dono. Quem não é dono (ou empresa inexistente/institucional) recebe 404: nada de outra empresa é revelado. */
export async function acesso(userId: number, bid: number) {
  const b = await one("SELECT id, owner_id, status, data FROM businesses WHERE id = $1 AND owner_id = $2 AND status <> 'institucional'", [bid, userId])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  return b!
}
export async function empresasBI(userId: number) {
  const out: { id: number; nome: string }[] = []
  for (const b of await (await import('../db/index.js')).empresasAtivasDoDono(userId) as any[]) out.push({ id: Number(b.id), nome: J<any>(b.data, {}).empresa || `Empresa #${b.id}` })
  return out
}

/* ---------- pedidos (fonte oficial: orders) ---------- */
type Ped = { id: number; dia: string; hora: number; status: string; total: number; tipo: 'pedido' | 'agendamento'; pago: boolean; recebido: boolean; cancelado: boolean; aberto: boolean; pagamento: string; cliente: string | null; itens: { nome: string; qtd: number; valor: number }[]; servico: string; agData: string; cupom: number; moedas: { qtd: number; desconto: number; simbolo: string } | null; criadoMs: number }
async function carregar(bid: number, ownerId: number, tz: string): Promise<Ped[]> {
  const rows = await q('SELECT id, customer_id, status, total, data, created_at FROM orders WHERE business_id = $1 ORDER BY id', [bid]) as any[]
  const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit' })
  return rows.map((o) => {
    const d = J<any>(o.data, {}), t = new Date(o.created_at), p: Record<string, string> = {}; for (const x of fmt.formatToParts(t)) p[x.type] = x.value
    const status = String(o.status), cancelado = CANCEL.includes(status), pago = d.pago === true, recebido = !cancelado && (status === 'concluido' || (d.pagamento === 'online' && pago))
    const dono = !d.guest && Number(o.customer_id) === ownerId // o dono comprando na própria loja não é cliente
    const tel = phoneKey(d.telefone)
    return { id: Number(o.id), dia: `${p.year}-${p.month}-${p.day}`, hora: +p.hour % 24, status, total: num(o.total), tipo: d.tipo === 'agendamento' ? 'agendamento' : 'pedido', pago, recebido, cancelado, aberto: ABERTO.includes(status), pagamento: String(d.pagamento || 'não informado'),
      cliente: dono ? null : (d.guest ? (tel ? 'tel:' + tel : 'conv:' + o.id) : 'u:' + o.customer_id), itens: (Array.isArray(d.itens) ? d.itens : []).map((i: any) => ({ nome: String(i.nome || ''), qtd: num(i.qtd) || 1, valor: r2((num(i.qtd) || 1) * num(i.preco)) })),
      servico: String(d.servico || ''), agData: String(d.data || ''), cupom: num(d.cupom?.desconto), moedas: d.moedas ? { qtd: num(d.moedas.qtd), desconto: num(d.moedas.desconto), simbolo: String(d.moedas.simbolo || '') } : null, criadoMs: t.getTime() }
  })
}
const noPeriodo = (l: Ped[], de: string, ate: string) => l.filter((o) => o.dia >= de && o.dia <= ate)

function vendas(l: Ped[]) {
  const rec = l.filter((o) => o.recebido), pend = l.filter((o) => !o.cancelado && !o.recebido), can = l.filter((o) => o.cancelado)
  const soma = (x: Ped[]) => r2(x.reduce((a, o) => a + o.total, 0))
  const porPag: Record<string, number> = {}; for (const o of rec) porPag[o.pagamento] = r2((porPag[o.pagamento] || 0) + o.total)
  const faturamento = soma(rec), pendente = soma(pend), cancelado = soma(can)
  return { faturamento, bruto: r2(faturamento + pendente), pendente, cancelado, vendasPagas: rec.length, ticketMedio: rec.length ? r2(faturamento / rec.length) : null, porPagamento: porPag,
    porTipo: { pedidos: soma(rec.filter((o) => o.tipo === 'pedido')), agendamentos: soma(rec.filter((o) => o.tipo === 'agendamento')) } }
}
function contagens(l: Ped[]) {
  const ped = l.filter((o) => o.tipo === 'pedido'), ag = l.filter((o) => o.tipo === 'agendamento')
  const g = (x: Ped[]) => ({ total: x.length, pendentes: x.filter((o) => o.aberto).length, concluidos: x.filter((o) => o.status === 'concluido').length, cancelados: x.filter((o) => o.cancelado).length })
  return { pedidos: g(ped), agendamentos: g(ag) }
}
function produtos(l: Ped[]) {
  const pr: Record<string, { qtd: number; valor: number }> = {}, sv: Record<string, { qtd: number; valor: number }> = {}
  for (const o of l.filter((x) => !x.cancelado)) {
    if (o.tipo === 'agendamento') { const n = o.servico || o.itens[0]?.nome || 'Serviço'; const s = (sv[n] ||= { qtd: 0, valor: 0 }); s.qtd++; s.valor = r2(s.valor + o.total) }
    else for (const i of o.itens) { if (!i.nome) continue; const s = (pr[i.nome] ||= { qtd: 0, valor: 0 }); s.qtd += i.qtd; s.valor = r2(s.valor + i.valor) }
  }
  const top = (m: Record<string, { qtd: number; valor: number }>) => Object.entries(m).sort((a, b) => b[1].qtd - a[1].qtd || b[1].valor - a[1].valor).slice(0, 5).map(([nome, v]) => ({ nome, ...v }))
  return { topProdutos: top(pr), topServicos: top(sv) }
}
function clientes(todos: Ped[], de: string, ate: string) {
  const validos = todos.filter((o) => o.cliente && !o.cancelado && o.status !== 'aguardando_pagamento')
  const por = new Map<string, Ped[]>(); for (const o of validos) (por.get(o.cliente!) || por.set(o.cliente!, []).get(o.cliente!)!).push(o)
  let ativos = 0, novos = 0, recorrentes = 0
  for (const l of por.values()) {
    const noP = l.filter((o) => o.dia >= de && o.dia <= ate); if (!noP.length) continue
    ativos++; const primeira = l.reduce((m, o) => (o.dia < m ? o.dia : m), l[0].dia)
    if (primeira >= de && primeira <= ate) novos++
    if (l.length >= 2) recorrentes++
  }
  return { comPedidos: por.size, ativosNoPeriodo: ativos, novos, recorrentes, recorrentesTotal: [...por.values()].filter((l) => l.length >= 2).length }
}

/* ---------- acessos (fonte oficial: business_stats) ---------- */
async function acessos(bid: number, de: string, ate: string) {
  const algum = await one('SELECT 1 AS x FROM business_stats WHERE business_id = $1 LIMIT 1', [bid])
  if (!algum) return { disponivel: false, motivo: 'Ainda não há nenhum registro de acessos desta empresa.' }
  const rows = await q('SELECT day, kind, n FROM business_stats WHERE business_id = $1 AND day >= $2 AND day <= $3', [bid, de, ate]) as any[]
  const t: Record<string, number> = {}, porDia: Record<string, number> = {}
  for (const r of rows) { t[r.kind] = (t[r.kind] || 0) + num(r.n); if (r.kind === 'visita') porDia[r.day] = num(r.n) }
  return { disponivel: true, visitas: t.visita || 0, impressoes: t.impressao || 0, contatos: (t.whatsapp || 0) + (t.instagram || 0) + (t.link || 0) + (t.mapa || 0), compartilhamentos: t.compartilhar || 0, conversasAgente: t.agente || 0, porDia }
}

/* ---------- Finanças do dono (fonte oficial: items) ---------- */
async function financas(userId: number, de: string, ate: string) {
  const { modules } = await import('./usermod.js'); if ((await modules()).financas === false) return { disponivel: false, motivo: 'O módulo Finanças está desligado.' }
  const rows = await q("SELECT data FROM items WHERE user_id = $1 AND type = 'expense' AND day >= $2 AND day <= $3", [userId, de, ate]) as any[]
  if (!rows.length) return { disponivel: false, motivo: 'Nenhum lançamento registrado no módulo Finanças neste período.' }
  let receitas = 0, despesas = 0; for (const r of rows) { const d = J<any>(r.data, {}); if (d.kind === 'income') receitas += num(d.amount); else despesas += num(d.amount) }
  return { disponivel: true, receitas: r2(receitas), despesas: r2(despesas), saldo: r2(receitas - despesas), lancamentos: rows.length, origem: 'Módulo Finanças do dono (lançamentos pessoais/da operação; não separado por empresa)' }
}
/* ---------- CRM (somente leitura) ---------- */
async function crm(bid: number) {
  try {
    const K = await import('./crm.js'); await K.acesso((await one('SELECT owner_id FROM businesses WHERE id = $1', [bid]) as any).owner_id, bid)
    const i = await K.CommercialIntelligenceService.indicadores(bid)
    return { disponivel: true, totalClientes: i.totalClientes, novosLeads: i.novosLeads, leadsEmNegociacao: i.leadsEmNegociacao, oportunidadesAbertas: i.oportunidadesAbertas, valorEmAberto: i.valorOportunidades, conversao: i.taxaConversao }
  } catch { return { disponivel: false, motivo: 'CRM indisponível para esta empresa (plano com loja e módulo ligado).' } }
}

/* ---------- resumo ---------- */
export async function resumo(userId: number, bid: number, spec: { periodo?: string; de?: string; ate?: string }, tz?: string) {
  const b = await acesso(userId, bid), per = periodo(spec, tz), nome = J<any>(b.data, {}).empresa || `Empresa #${bid}`
  const todos = await carregar(bid, userId, per.tz), l = noPeriodo(todos, per.de, per.ate)
  const v = vendas(l), c = contagens(l), pr = produtos(l), cli = clientes(todos, per.de, per.ate), ac = await acessos(bid, per.de, per.ate)
  // série diária (gráfico) e horários de movimento — só com pedidos válidos
  const dias: any[] = []; for (let i = 0; i < per.dias && i < 120; i++) { const d = addDays(per.de, i), x = l.filter((o) => o.dia === d); dias.push({ dia: d, faturamento: r2(x.filter((o) => o.recebido).reduce((a, o) => a + o.total, 0)), pedidos: x.filter((o) => !o.cancelado).length, visitas: ac.disponivel ? (ac as any).porDia[d] || 0 : null }) }
  const comVenda = dias.filter((d) => d.faturamento > 0), melhor = comVenda.length ? comVenda.reduce((m, d) => (d.faturamento > m.faturamento ? d : m)) : null
  const hr: Record<number, number> = {}; for (const o of l.filter((x) => !x.cancelado)) hr[o.hora] = (hr[o.hora] || 0) + 1
  const horarios = Object.entries(hr).map(([h, n]) => ({ hora: +h, pedidos: n })).sort((a, b) => b.pedidos - a.pedidos || a.hora - b.hora).slice(0, 3)
  const inc = l.filter((o) => !o.cancelado), cupons = inc.filter((o) => o.cupom > 0), moedas = inc.filter((o) => o.moedas && o.moedas.qtd > 0)
  const hojeAg = todos.filter((o) => o.tipo === 'agendamento' && o.aberto && o.agData >= per.hoje).length
  const { porDia: _pd, ...acOut } = ac as any
  return { empresa: { id: bid, nome }, periodo: { id: per.id, label: per.label, de: per.de, ate: per.ate, dias: per.dias, fuso: per.tz }, geradoEm: new Date().toISOString(),
    vendas: v, ...c, agendamentos: { ...c.agendamentos, proximosAbertos: hojeAg }, clientes: { ...cli, crm: await crm(bid) },
    acessos: ac.disponivel ? { ...acOut, pedidosPorVisita: acOut.visitas > 0 ? r2(c.pedidos.total / acOut.visitas) : null } : ac,
    produtos: { ...pr, visualizacoes: { disponivel: false, motivo: 'O sistema ainda não registra visualizações por produto/serviço; "mais procurados" usa o que foi pedido/agendado.' } },
    incentivos: { cupons: { usos: cupons.length, desconto: r2(cupons.reduce((a, o) => a + o.cupom, 0)) }, mcoins: { usos: moedas.length, moedas: moedas.reduce((a, o) => a + (o.moedas?.qtd || 0), 0), desconto: r2(moedas.reduce((a, o) => a + (o.moedas?.desconto || 0), 0)) } },
    financeiro: await financas(userId, per.de, per.ate), serie: dias, melhorDia: melhor, horariosDeMovimento: horarios, semMovimento: l.length === 0, definicoes: DEFINICOES,
    _interno: { todos, l, per } }
}
const strip = <T extends { _interno?: any }>(r: T): Omit<T, '_interno'> => { const { _interno, ...o } = r; return o }
export const publico = strip

/* ---------- comparativo ---------- */
const delta = (a: number | null, b: number | null) => (a == null || b == null ? { variacao: null, percentual: null } : { variacao: r2(a - b), percentual: b === 0 ? null : r2(((a - b) / b) * 100) })
export async function comparar(userId: number, bid: number, spec: { periodo?: string; de?: string; ate?: string; contra?: { de: string; ate: string } }, tz?: string) {
  const b = await acesso(userId, bid), per = periodo(spec, tz); let aDe = per.anterior.de, aAte = per.anterior.ate, aLabel = per.anterior.label
  if (spec.contra && DATA.test(spec.contra.de) && DATA.test(spec.contra.ate)) { aDe = spec.contra.de; aAte = spec.contra.ate; aLabel = `${br(aDe)} a ${br(aAte)}` }
  const todos = await carregar(bid, userId, per.tz), A = noPeriodo(todos, per.de, per.ate), B = noPeriodo(todos, aDe, aAte)
  const va = vendas(A), vb = vendas(B), ca = contagens(A), cb = contagens(B), cla = clientes(todos, per.de, per.ate), clb = clientes(todos, aDe, aAte)
  const aca = await acessos(bid, per.de, per.ate), acb = await acessos(bid, aDe, aAte)
  const linha = (nome: string, a: number | null, bb: number | null, tipo: 'moeda' | 'qtd') => ({ indicador: nome, tipo, atual: a, anterior: bb, ...delta(a, bb) })
  return { empresa: { id: bid, nome: J<any>(b.data, {}).empresa || `Empresa #${bid}` }, atual: { label: per.label, de: per.de, ate: per.ate }, anterior: { label: aLabel, de: aDe, ate: aAte },
    parcial: per.ate === per.hoje && !['hoje', 'ontem'].includes(per.id) ? 'O período atual ainda está em andamento; o anterior foi cortado no mesmo número de dias.' : null,
    indicadores: [linha('Faturamento (vendas pagas)', va.faturamento, vb.faturamento, 'moeda'), linha('Valor pendente', va.pendente, vb.pendente, 'moeda'), linha('Valor cancelado', va.cancelado, vb.cancelado, 'moeda'), linha('Ticket médio', va.ticketMedio, vb.ticketMedio, 'moeda'),
      linha('Pedidos', ca.pedidos.total, cb.pedidos.total, 'qtd'), linha('Agendamentos', ca.agendamentos.total, cb.agendamentos.total, 'qtd'), linha('Clientes novos', cla.novos, clb.novos, 'qtd'), linha('Clientes ativos', cla.ativosNoPeriodo, clb.ativosNoPeriodo, 'qtd'),
      linha('Visitas', aca.disponivel ? (aca as any).visitas : null, acb.disponivel ? (acb as any).visitas : null, 'qtd')], definicoes: DEFINICOES }
}

/* ---------- tendências e sugestões (critérios visíveis) ---------- */
export type Insight = { tipo: 'alta' | 'queda' | 'alerta' | 'oportunidade' | 'info'; texto: string; sugestao?: string; criterio: string; base: Record<string, any> }
export async function analise(userId: number, bid: number, spec: { periodo?: string; de?: string; ate?: string }, tz?: string) {
  const r = await resumo(userId, bid, spec, tz), { per, todos, l } = r._interno as { per: Per; todos: Ped[]; l: Ped[] }, ant = noPeriodo(todos, per.anterior.de, per.anterior.ate), va = vendas(ant)
  const out: Insight[] = [], fmt = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
  if (r.semMovimento) out.push({ tipo: 'info', texto: `Não houve pedidos nem agendamentos ${per.label}.`, sugestao: 'Divulgue o link da vitrine e confira se produtos/serviços e horários estão ativos.', criterio: 'Nenhum registro em orders no período', base: { pedidos: 0 } })
  const f = r.vendas.faturamento, fa = va.faturamento
  if (fa > 0 && f >= 0) { const p = ((f - fa) / fa) * 100; if (p >= 10) out.push({ tipo: 'alta', texto: `O faturamento subiu ${r2(p)}% (${fmt(f)} contra ${fmt(fa)} em ${per.anterior.label}).`, sugestao: 'Descubra o que mudou (produto, divulgação, dia da semana) e repita.', criterio: 'Variação ≥ +10% sobre o período anterior', base: { atual: f, anterior: fa } }); else if (p <= -10) out.push({ tipo: 'queda', texto: `O faturamento caiu ${r2(Math.abs(p))}% (${fmt(f)} contra ${fmt(fa)} em ${per.anterior.label}).`, sugestao: 'Reative clientes antigos (CRM/MCoins/cupom) e reforce a divulgação dos itens mais vendidos.', criterio: 'Variação ≤ −10% sobre o período anterior', base: { atual: f, anterior: fa } }) }
  const total = r.pedidos.total + r.agendamentos.total, can = r.pedidos.cancelados + r.agendamentos.cancelados
  if (total >= 5 && can / total >= 0.2) out.push({ tipo: 'alerta', texto: `${can} de ${total} pedidos/agendamentos foram cancelados (${Math.round((can / total) * 100)}%).`, sugestao: 'Veja os motivos informados nos cancelamentos e ajuste prazos, estoque ou horários.', criterio: 'Cancelados ≥ 20% (mínimo de 5 registros)', base: { cancelados: can, total } })
  const antigos = todos.filter((o) => o.aberto && o.dia <= addDays(per.hoje, -2)).length
  if (antigos) out.push({ tipo: 'alerta', texto: `${antigos} pedido(s)/agendamento(s) estão em aberto há mais de 2 dias.`, sugestao: 'Atualize a situação ou fale com o cliente para não perder a venda.', criterio: 'Em aberto com criação anterior a 2 dias (considera todos os registros da empresa)', base: { emAberto: antigos } })
  const ac: any = r.acessos
  if (ac.disponivel && ac.visitas >= 30 && r.pedidos.total + r.agendamentos.total > 0 && (r.pedidos.total + r.agendamentos.total) / ac.visitas < 0.02) out.push({ tipo: 'oportunidade', texto: `Só ${r.pedidos.total + r.agendamentos.total} pedido(s)/agendamento(s) para ${ac.visitas} visitas.`, sugestao: 'Melhore fotos, preços e descrições da vitrine e use o agente da loja para tirar dúvidas.', criterio: 'Menos de 2 pedidos por 100 visitas (mínimo de 30 visitas)', base: { visitas: ac.visitas, pedidos: r.pedidos.total + r.agendamentos.total } })
  if (ac.disponivel && ac.visitas >= 30 && !(r.pedidos.total + r.agendamentos.total)) out.push({ tipo: 'oportunidade', texto: `Houve ${ac.visitas} visitas e nenhum pedido ou agendamento.`, sugestao: 'Revise a vitrine e ofereça cupom de primeira compra.', criterio: 'Visitas ≥ 30 sem pedidos', base: { visitas: ac.visitas } })
  const h = r.horariosDeMovimento[0]; if (h && h.pedidos >= 3) out.push({ tipo: 'info', texto: `O horário de maior movimento é por volta das ${String(h.hora).padStart(2, '0')}h (${h.pedidos} pedidos).`, sugestao: 'Divulgue antes desse horário e garanta atendimento rápido nele.', criterio: 'Hora com mais pedidos válidos (mínimo de 3)', base: { hora: h.hora, pedidos: h.pedidos } })
  const tp = r.produtos.topProdutos, tot = r.vendas.bruto
  if (tp[0] && tot > 0 && tp[0].valor / tot >= 0.5 && r.pedidos.total >= 5) out.push({ tipo: 'oportunidade', texto: `${tp[0].nome} concentra ${Math.round((tp[0].valor / tot) * 100)}% das vendas.`, sugestao: 'Crie combos ou ofereça um segundo item junto para reduzir a dependência.', criterio: 'Um item ≥ 50% do valor vendido (mínimo de 5 pedidos)', base: { item: tp[0].nome, valor: tp[0].valor, total: tot } })
  const cl = r.clientes
  if (cl.comPedidos >= 10 && cl.recorrentesTotal / cl.comPedidos < 0.2) out.push({ tipo: 'oportunidade', texto: `Só ${cl.recorrentesTotal} de ${cl.comPedidos} clientes compraram mais de uma vez.`, sugestao: 'Use o CRM para chamar quem sumiu e MCoins/cupom para incentivar a volta.', criterio: 'Recorrentes < 20% dos clientes (mínimo de 10 clientes)', base: { recorrentes: cl.recorrentesTotal, clientes: cl.comPedidos } })
  const agp = r.agendamentos.pendentes; if (agp) out.push({ tipo: 'info', texto: `${agp} agendamento(s) ainda aguardando confirmação ou conclusão.`, criterio: 'Agendamentos em aberto', base: { pendentes: agp } })
  return { ...strip(r), tendencias: out, comparativoBase: { label: per.anterior.label, de: per.anterior.de, ate: per.anterior.ate, faturamento: va.faturamento } }
}
