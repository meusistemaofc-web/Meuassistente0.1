// Cupons e Vouchers para a ATIVAÇÃO DE ANÚNCIOS.
// Modalidades: percentual (desconto sobre o preço do plano), gratuito (N dias/meses sem cobrança) e vitalício.
// Segurança: tudo é validado e calculado no servidor; o limite total e o limite por usuário são consumidos com
// UPDATE condicional atômico (dois usuários nunca levam a última utilização); cada resgate guarda a "fotografia" do
// benefício (editar o cupom depois não altera o que já foi concedido); toda operação fica registrada.
import { randomInt } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'

export const KINDS = ['percentual', 'gratuito', 'vitalicio'] as const
/** Destino do cupom: ativação de anúncios, ativação do Agente de Atendimento ou os dois (um único limite de uso para ambos). */
export const DESTINOS = ['anuncio', 'agente', 'ambos'] as const
export type Alvo2 = 'anuncio' | 'agente'
export const DESTINO_TXT: Record<string, string> = { anuncio: 'Anúncios', agente: 'Agente de Atendimento', ambos: 'Anúncios e Agente' }
export const vale = (destino: any, alvo: Alvo2) => (destino || 'anuncio') === 'ambos' || (destino || 'anuncio') === alvo
export type Kind = (typeof KINDS)[number]
export const RESERVA_HORAS = 48 // um código aplicado a um anúncio ainda não ativado fica reservado por 48 h
const VITALICIO_ATE = '2999-12-31T23:59:59.000Z'
const r2 = (n: number) => Math.round(n * 100) / 100
const brl = (n: number) => `R$ ${r2(n).toFixed(2).replace('.', ',')}`
export const normCode = (s: any) => String(s || '').toUpperCase().replace(/\s+/g, '').replace(/[^A-Z0-9_-]/g, '').slice(0, 40)

export const periodoDias = (qty: number, unit: string) => (unit === 'meses' ? Math.round(qty * 30.4375) : qty)
export const periodoTxt = (qty: number, unit: string) => `${qty} ${unit === 'meses' ? (qty === 1 ? 'mês' : 'meses') : qty === 1 ? 'dia' : 'dias'}`
export function beneficioTxt(v: { kind: string; percent?: number | null; period_label?: string | null; period_qty?: number | null; period_unit?: string | null }, alvo?: Alvo2 | 'ambos') {
  if (v.kind === 'percentual') return Number(v.percent) >= 100 ? '100% de desconto (ativação gratuita)' : `${v.percent}% de desconto`
  const per = v.period_label || periodoTxt(Number(v.period_qty), String(v.period_unit))
  if (v.kind === 'gratuito') return alvo === 'agente' ? `agente gratuito por ${per}` : alvo === 'ambos' ? `gratuito por ${per}` : `anúncio gratuito por ${per}`
  return 'acesso vitalício (sem renovações)'
}
export function mensagemAplicado(v: any, alvo: Alvo2 = 'anuncio') {
  if (v.kind === 'percentual') return Number(v.percent) >= 100 ? 'Cupom aplicado! Você recebeu 100% de desconto: a ativação é gratuita.' : `Cupom aplicado! Você recebeu ${v.percent}% de desconto.`
  if (v.kind === 'gratuito') return `Cupom aplicado! ${alvo === 'agente' ? 'Seu agente ficará no ar sem custo' : 'Seu anúncio ficará gratuito'} por ${v.period_label || periodoTxt(Number(v.period_qty), String(v.period_unit))}.`
  return alvo === 'agente' ? 'Cupom aplicado! Seu agente recebeu acesso vitalício.' : 'Cupom aplicado! Você recebeu acesso vitalício.'
}
/** Valor final de uma ativação, calculado só no servidor. */
export function calcular(v: { kind: string; percent?: number | null }, preco: number) {
  const original = r2(Math.max(0, Number(preco) || 0))
  const final = v.kind === 'percentual' ? r2(original * (100 - Math.min(100, Math.max(0, Number(v.percent) || 0))) / 100) : 0
  return { original, final, economia: r2(original - final) }
}

async function evento(voucherId: number | null, action: string, actor: string, detail: any = {}) {
  await q('INSERT INTO ad_voucher_events (voucher_id, action, actor, detail, created_at) VALUES ($1,$2,$3,$4,$5)', [voucherId, action, actor, JSON.stringify(detail), nowIso()])
}
const vOut = (v: any) => ({
  id: Number(v.id), codigo: v.code, campanha: v.campaign || '', descricao: v.description || '', tipo: v.kind, percentual: v.percent != null ? Number(v.percent) : null,
  periodo: v.period_qty ? { quantidade: Number(v.period_qty), unidade: v.period_unit, dias: periodoDias(Number(v.period_qty), v.period_unit), texto: periodoTxt(Number(v.period_qty), v.period_unit) } : null,
  destino: v.destino || 'anuncio', destinoTxt: DESTINO_TXT[v.destino || 'anuncio'], beneficio: beneficioTxt(v, v.destino || 'anuncio'), maxUsos: v.max_uses != null ? Number(v.max_uses) : null, maxPorUsuario: Number(v.max_per_user), usos: Number(v.uses),
  inicio: v.starts_at ? new Date(v.starts_at).toISOString() : null, fim: v.ends_at ? new Date(v.ends_at).toISOString() : null, validade: v.valid_until ? new Date(v.valid_until).toISOString() : null,
  planos: J<string[]>(v.plans, []), categorias: J<string[]>(v.categories, []), status: v.status, situacao: situacao(v), criadoEm: new Date(v.created_at).toISOString(), atualizadoEm: new Date(v.updated_at).toISOString(),
})
export function situacao(v: any): string {
  const now = Date.now()
  if (v.status === 'cancelado') return 'cancelado'
  if (v.status === 'pausado') return 'pausado'
  if (v.starts_at && Date.parse(new Date(v.starts_at).toISOString()) > now) return 'agendado'
  if (v.ends_at && Date.parse(new Date(v.ends_at).toISOString()) < now) return 'encerrado'
  if (v.valid_until && Date.parse(new Date(v.valid_until).toISOString()) < now) return 'expirado'
  if (v.max_uses != null && Number(v.uses) >= Number(v.max_uses)) return 'esgotado'
  return 'ativo'
}

/* ---------- administração ---------- */
function validarCampos(b: any, parcial: boolean, atual?: any) {
  const o: any = {}
  const usado = atual && Number(atual.uses) > 0
  if (!parcial || b.tipo !== undefined) { if (!KINDS.includes(b.tipo)) fail(400, 'Escolha a modalidade: desconto percentual, período gratuito ou vitalício.', 'invalid', 'tipo'); o.kind = b.tipo }
  const kind = o.kind || atual?.kind
  if (kind === 'percentual' && (!parcial || b.percentual !== undefined || o.kind)) { const p = Math.round(Number(b.percentual)); if (!(p >= 1 && p <= 100)) fail(400, 'O desconto deve ser de 1% a 100%.', 'invalid', 'percentual'); o.percent = p; o.period_qty = null; o.period_unit = null }
  if (kind === 'gratuito' && (!parcial || b.periodo !== undefined || o.kind)) {
    const qt = Math.round(Number(b.periodo?.quantidade)), un = b.periodo?.unidade === 'meses' ? 'meses' : b.periodo?.unidade === 'dias' ? 'dias' : ''
    if (!un || !(qt >= 1 && qt <= (un === 'meses' ? 60 : 1825))) fail(400, 'Informe o período gratuito (1 a 1.825 dias ou 1 a 60 meses).', 'invalid', 'periodo')
    o.period_qty = qt; o.period_unit = un; o.percent = null
  }
  if (kind === 'vitalicio' && o.kind) { o.percent = null; o.period_qty = null; o.period_unit = null }
  if (usado && ['kind', 'percent', 'period_qty', 'period_unit'].some((k) => k in o && String(o[k] ?? '') !== String(atual[k] ?? ''))) fail(409, 'Este cupom já foi utilizado: o benefício não pode mudar (quem resgatou mantém o que recebeu). Crie um novo cupom.', 'em_uso')
  if (!parcial || b.destino !== undefined) { const de = b.destino === undefined || b.destino === '' ? 'anuncio' : b.destino; if (!(DESTINOS as readonly string[]).includes(de)) fail(400, 'Escolha o destino do cupom: anúncios, Agente de Atendimento ou ambos.', 'invalid', 'destino'); o.destino = de
    // já usado: dá para AMPLIAR o destino (ex.: anúncios → ambos), nunca tirar o fluxo em que alguém já resgatou
    if (usado && de !== (atual.destino || 'anuncio') && de !== 'ambos') fail(409, 'Este cupom já foi utilizado: o destino só pode ser ampliado para "ambos". Crie um novo cupom para outra finalidade.', 'em_uso', 'destino') }
  if (b.descricao !== undefined) o.description = String(b.descricao || '').trim().slice(0, 300)
  if (b.campanha !== undefined) o.campaign = String(b.campanha || '').trim().slice(0, 80)
  const int = (v: any, nome: string, min: number) => { if (v === null || v === '' || v === undefined) return null; const n = Math.round(Number(v)); if (!(n >= min && n <= 1_000_000)) fail(400, `Valor inválido em ${nome}.`, 'invalid'); return n }
  if (b.usoUnico === true) { o.max_uses = 1; o.max_per_user = 1 }
  else {
    if (b.maxUsos !== undefined) { o.max_uses = int(b.maxUsos, 'máximo de utilizações', 1); if (atual && o.max_uses != null && o.max_uses < Number(atual.uses)) fail(400, `O cupom já tem ${atual.uses} utilização(ões): o máximo não pode ser menor que isso.`, 'invalid', 'maxUsos') }
    if (b.maxPorUsuario !== undefined) o.max_per_user = int(b.maxPorUsuario, 'máximo por usuário', 1) ?? 1
  }
  const data = (v: any, nome: string) => { if (v === null || v === '' || v === undefined) return null; const t = Date.parse(String(v)); if (!Number.isFinite(t)) fail(400, `Data inválida em ${nome}.`, 'invalid'); return new Date(t).toISOString() }
  if (b.inicio !== undefined) o.starts_at = data(b.inicio, 'início')
  if (b.fim !== undefined) o.ends_at = data(b.fim, 'encerramento')
  if (b.validade !== undefined) o.valid_until = data(b.validade, 'validade')
  const ini = o.starts_at !== undefined ? o.starts_at : atual?.starts_at, fim = o.ends_at !== undefined ? o.ends_at : atual?.ends_at
  if (ini && fim && Date.parse(new Date(fim).toISOString()) <= Date.parse(new Date(ini).toISOString())) fail(400, 'O encerramento precisa ser depois do início.', 'invalid', 'fim')
  if (b.planos !== undefined) o.plans = JSON.stringify((Array.isArray(b.planos) ? b.planos : []).map((x: any) => String(x).slice(0, 40)).slice(0, 20))
  if (b.categorias !== undefined) o.categories = JSON.stringify((Array.isArray(b.categorias) ? b.categorias : []).map((x: any) => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 40))
  return o
}
const ALFA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' // sem 0/O/1/I para não confundir
export function gerarCodigo(prefixo = '') { const p = normCode(prefixo).slice(0, 12); let s = ''; for (let i = 0; i < 8; i++) s += ALFA[randomInt(ALFA.length)]; return (p ? p + '-' : '') + s }
export async function criar(b: any, actor: { id: number; nome: string }) {
  const o = validarCampos(b, false)
  const qtd = Math.min(500, Math.max(1, Math.round(Number(b.quantidade) || 1)))
  const manual = normCode(b.codigo)
  if (manual && qtd > 1) fail(400, 'Para gerar vários códigos, deixe o código em branco (eles são gerados automaticamente).', 'invalid', 'codigo')
  if (manual && manual.length < 4) fail(400, 'O código precisa ter ao menos 4 letras ou números.', 'invalid', 'codigo')
  if (qtd > 1 && !String(b.campanha || '').trim()) fail(400, 'Dê um nome à campanha para agrupar os códigos gerados.', 'invalid', 'campanha')
  const ids: number[] = [], now = nowIso()
  for (let i = 0; i < qtd; i++) {
    let code = manual || gerarCodigo(b.prefixo), tent = 0
    while (!manual && (await one('SELECT id FROM ad_vouchers WHERE code = $1', [code])) && tent++ < 10) code = gerarCodigo(b.prefixo)
    if (await one('SELECT id FROM ad_vouchers WHERE code = $1', [code])) fail(409, `O código ${code} já existe. Escolha outro.`, 'duplicado', 'codigo')
    const r = await q(`INSERT INTO ad_vouchers (code, campaign, description, kind, percent, period_qty, period_unit, max_uses, max_per_user, uses, starts_at, ends_at, valid_until, plans, categories, status, created_by, created_at, updated_at, destino)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,0,$10,$11,$12,$13,$14,'ativo',$15,$16,$16,$17) RETURNING id`,
      [code, o.campaign ?? '', o.description ?? '', o.kind, o.percent ?? null, o.period_qty ?? null, o.period_unit ?? null, o.max_uses ?? null, o.max_per_user ?? 1, o.starts_at ?? null, o.ends_at ?? null, o.valid_until ?? null, o.plans ?? '[]', o.categories ?? '[]', actor.id, now, o.destino || 'anuncio'])
    ids.push(Number(r[0].id)); await evento(Number(r[0].id), 'criado', actor.nome, { codigo: code, destino: DESTINO_TXT[o.destino || 'anuncio'], beneficio: beneficioTxt({ ...o }, o.destino) })
  }
  return Promise.all(ids.map((id) => detalhe(id).then((x) => x.cupom)))
}
export async function editar(id: number, b: any, actor: { id: number; nome: string }) {
  const v: any = await one('SELECT * FROM ad_vouchers WHERE id = $1', [id]); if (!v) fail(404, 'Cupom não encontrado.', 'not_found')
  if (v.status === 'cancelado') fail(400, 'Cupom cancelado não pode ser editado.', 'invalid')
  if (b.codigo !== undefined && normCode(b.codigo) !== v.code) fail(400, 'O código não pode ser trocado depois de criado (crie outro cupom).', 'invalid', 'codigo')
  const o = validarCampos(b, true, v); const ks = Object.keys(o); if (!ks.length) return (await detalhe(id)).cupom
  const vals = ks.map((k) => o[k]); vals.push(nowIso(), id)
  await q(`UPDATE ad_vouchers SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${ks.length + 1} WHERE id = $${ks.length + 2}`, vals)
  await evento(id, 'editado', actor.nome, Object.fromEntries(ks.map((k) => [k, o[k]])))
  return (await detalhe(id)).cupom
}
export async function mudarStatus(id: number, st: string, actor: { id: number; nome: string }) {
  if (!['ativo', 'pausado', 'cancelado'].includes(st)) fail(400, 'Situação inválida.', 'invalid')
  const v: any = await one('SELECT * FROM ad_vouchers WHERE id = $1', [id]); if (!v) fail(404, 'Cupom não encontrado.', 'not_found')
  if (v.status === 'cancelado') fail(400, 'Cupom cancelado não pode ser reativado (crie um novo).', 'invalid')
  await q('UPDATE ad_vouchers SET status = $1, updated_at = $2 WHERE id = $3', [st, nowIso(), id])
  await evento(id, 'status', actor.nome, { de: v.status, para: st })
  return (await detalhe(id)).cupom
}
export async function listar(f: { q?: string; status?: string; campanha?: string; destino?: string }) {
  await expirarReservas()
  const rows = await q('SELECT * FROM ad_vouchers ORDER BY id DESC LIMIT 2000')
  const t = String(f.q || '').toLowerCase()
  return rows.map(vOut).filter((v) => (!t || `${v.codigo} ${v.descricao} ${v.campanha}`.toLowerCase().includes(t)) && (!f.status || f.status === 'todos' || v.situacao === f.status) && (!f.campanha || v.campanha === f.campanha) && (!f.destino || f.destino === 'todos' || v.destino === f.destino))
}
const rOut = (r: any) => ({ id: Number(r.id), cupomId: Number(r.voucher_id), alvo: (r.alvo || 'anuncio') as Alvo2, codigo: r.code, campanha: r.campaign || '', usuario: r.user_name ? { id: Number(r.user_id), nome: r.user_name, email: r.user_email } : { id: Number(r.user_id) }, anuncio: { id: Number(r.business_id), empresa: J<any>(r.biz_data, {}).empresa || '', plano: r.plan_id }, tipo: r.kind, beneficio: beneficioTxt({ kind: r.kind, percent: r.percent, period_label: r.period_label }, r.alvo || 'anuncio'), percentual: r.percent != null ? Number(r.percent) : null, periodoDias: r.period_days != null ? Number(r.period_days) : null, periodo: r.period_label || null, vitalicio: r.kind === 'vitalicio', valorOriginal: Number(r.original_value), valorFinal: Number(r.final_value), economia: Number(r.saved_value), status: r.status, aplicadoAte: r.applied_until ? new Date(r.applied_until).toISOString() : null, aplicadoEm: r.applied_at ? new Date(r.applied_at).toISOString() : null, motivoLiberacao: r.release_reason || '', em: new Date(r.created_at).toISOString(), confirmadoEm: r.confirmed_at ? new Date(r.confirmed_at).toISOString() : null })
const R_SEL = 'SELECT r.*, u.name AS user_name, u.email AS user_email, b.data AS biz_data FROM ad_voucher_redemptions r LEFT JOIN users u ON u.id = r.user_id LEFT JOIN businesses b ON b.id = r.business_id'
export async function detalhe(id: number) {
  const v: any = await one('SELECT * FROM ad_vouchers WHERE id = $1', [id]); if (!v) fail(404, 'Cupom não encontrado.', 'not_found')
  const res = (await q(`${R_SEL} WHERE r.voucher_id = $1 ORDER BY r.id DESC`, [id])).map(rOut)
  const ev = (await q('SELECT * FROM ad_voucher_events WHERE voucher_id = $1 ORDER BY id DESC LIMIT 200', [id])).map((e: any) => ({ acao: e.action, quem: e.actor || '', detalhe: J<any>(e.detail, {}), em: new Date(e.created_at).toISOString() }))
  return { cupom: { ...vOut(v), resgatados: res.filter((r) => r.status === 'resgatado').length, reservados: res.filter((r) => r.status === 'reservado').length, economiaTotal: r2(res.filter((r) => r.status === 'resgatado').reduce((s, r) => s + r.economia, 0)) }, resgates: res, eventos: ev }
}
export async function historico(f: { codigo?: string; usuario?: string; campanha?: string; de?: string; ate?: string; status?: string; alvo?: string }) {
  await expirarReservas()
  const rows = (await q(`${R_SEL} ORDER BY r.id DESC LIMIT 5000`)).map(rOut)
  const de = f.de ? Date.parse(f.de) : null, ate = f.ate ? Date.parse(f.ate) + 86400_000 - 1 : null, cod = normCode(f.codigo), us = String(f.usuario || '').toLowerCase().trim()
  const itens = rows.filter((r) => (!cod || r.codigo.includes(cod)) && (!us || `${(r.usuario as any).nome || ''} ${(r.usuario as any).email || ''} ${r.usuario.id}`.toLowerCase().includes(us)) && (!f.campanha || r.campanha === f.campanha) && (!f.status || f.status === 'todos' || r.status === f.status) && (!f.alvo || f.alvo === 'todos' || r.alvo === f.alvo) && (de == null || Date.parse(r.em) >= de) && (ate == null || Date.parse(r.em) <= ate))
  const ok = itens.filter((r) => r.status === 'resgatado')
  return { itens, totais: { resgates: ok.length, reservas: itens.filter((r) => r.status === 'reservado').length, economia: r2(ok.reduce((s, r) => s + r.economia, 0)) }, campanhas: [...new Set((await q("SELECT DISTINCT campaign FROM ad_vouchers WHERE campaign <> ''")).map((x: any) => String(x.campaign)))].sort() }
}

/* ---------- validação, reserva, confirmação e aplicação ---------- */
export interface Alvo { userId: number; planId: string; preco: number; categoria: string; businessId?: number; alvo?: Alvo2 }
/** Verifica se o código pode ser usado (sem consumir). Devolve o motivo claro quando não pode. */
export async function verificar(codigo: string, a: Alvo) {
  const code = normCode(codigo); if (!code) fail(400, 'Digite o código do cupom.', 'invalid', 'codigo')
  await expirarReservas()
  const v: any = await one('SELECT * FROM ad_vouchers WHERE code = $1', [code])
  if (!v) fail(404, 'Cupom não encontrado. Confira se digitou o código corretamente.', 'cupom_inexistente', 'codigo')
  const st = situacao(v)
  const msg: Record<string, string> = { cancelado: 'Este cupom foi cancelado.', pausado: 'Este cupom está pausado no momento.', agendado: `Este cupom ainda não está valendo: a campanha começa em ${new Date(v.starts_at).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.`, encerrado: 'A campanha deste cupom já terminou.', expirado: 'Este cupom expirou.', esgotado: 'Este cupom já atingiu o limite de utilizações.' }
  if (st !== 'ativo') fail(400, msg[st], 'cupom_' + st, 'codigo')
  const alvo: Alvo2 = a.alvo || 'anuncio'
  if (!vale(v.destino, alvo)) fail(400, alvo === 'agente' ? 'Este cupom vale só para a ativação de anúncios, não para o Agente de Atendimento.' : 'Este cupom vale só para a ativação do Agente de Atendimento, não para anúncios.', 'cupom_destino', 'codigo')
  const planos = J<string[]>(v.plans, []), cats = J<string[]>(v.categories, [])
  if (alvo === 'anuncio' && planos.length && !planos.includes(a.planId)) fail(400, 'Este cupom não vale para o plano escolhido.', 'cupom_plano', 'codigo') // planos são os de anúncio: não se aplicam ao agente
  if (cats.length && !cats.some((c) => c.toLowerCase() === String(a.categoria || '').toLowerCase())) fail(400, `Este cupom vale só para os ramos: ${cats.join(', ')}.`, 'cupom_categoria', 'codigo')
  const pu: any = await one('SELECT uses FROM ad_voucher_user_uses WHERE voucher_id = $1 AND user_id = $2', [v.id, a.userId])
  if (pu && Number(pu.uses) >= Number(v.max_per_user)) fail(400, Number(v.max_per_user) === 1 ? 'Você já utilizou este cupom.' : `Você já utilizou este cupom ${v.max_per_user} vezes (limite por pessoa).`, 'cupom_limite_usuario', 'codigo')
  if (a.businessId && (await one("SELECT id FROM ad_voucher_redemptions WHERE business_id = $1 AND voucher_id = $2 AND alvo = $3 AND status IN ('reservado','resgatado')", [a.businessId, v.id, alvo]))) fail(400, alvo === 'agente' ? 'Este cupom já foi usado no agente desta empresa.' : 'Este cupom já está aplicado a este anúncio.', 'cupom_repetido', 'codigo')
  const c = calcular(v, a.preco)
  return { v, ...c, beneficio: beneficioTxt(v, alvo), mensagem: mensagemAplicado(v, alvo) }
}
/** Reserva atômica de uma utilização para um anúncio (não deixa passar do limite, nem por usuário). */
export async function reservar(codigo: string, a: Alvo & { businessId: number }, actor: string) {
  const x = await verificar(codigo, a), v = x.v, alvo: Alvo2 = a.alvo || 'anuncio', oQue = alvo === 'agente' ? 'A ativação do agente' : 'Este anúncio'
  if (await one("SELECT id FROM ad_voucher_redemptions WHERE business_id = $1 AND alvo = $2 AND status = 'reservado'", [a.businessId, alvo])) fail(409, `${oQue} já tem um cupom aplicado. Remova-o para usar outro.`, 'cupom_ja_aplicado')
  if (await one("SELECT id FROM ad_voucher_redemptions WHERE business_id = $1 AND alvo = $2 AND status = 'resgatado' AND applied_at IS NULL", [a.businessId, alvo])) fail(409, `${oQue} já tem um cupom resgatado aguardando a ativação.`, 'cupom_ja_aplicado')
  // 1) limite total: UPDATE condicional — só uma requisição consegue a última utilização
  const g = await q("UPDATE ad_vouchers SET uses = uses + 1, updated_at = $2 WHERE id = $1 AND status = 'ativo' AND (max_uses IS NULL OR uses < max_uses) RETURNING uses", [v.id, nowIso()])
  if (!g.length) fail(409, 'Este cupom acabou de atingir o limite de utilizações.', 'cupom_esgotado', 'codigo')
  // 2) limite por usuário: linha única (cupom, usuário) com incremento condicional
  await q('INSERT INTO ad_voucher_user_uses (voucher_id, user_id, uses) VALUES ($1,$2,0) ON CONFLICT (voucher_id, user_id) DO NOTHING', [v.id, a.userId])
  const pu = await q('UPDATE ad_voucher_user_uses SET uses = uses + 1 WHERE voucher_id = $1 AND user_id = $2 AND uses < $3 RETURNING uses', [v.id, a.userId, Number(v.max_per_user)])
  if (!pu.length) { await q('UPDATE ad_vouchers SET uses = uses - 1 WHERE id = $1 AND uses > 0', [v.id]); fail(400, 'Você já atingiu o limite de uso deste cupom.', 'cupom_limite_usuario', 'codigo') }
  // 3) registro da reserva (índice único: um anúncio, uma reserva)
  const dias = v.kind === 'gratuito' ? periodoDias(Number(v.period_qty), v.period_unit) : null, label = v.kind === 'gratuito' ? periodoTxt(Number(v.period_qty), v.period_unit) : null
  try {
    const r = await q(`INSERT INTO ad_voucher_redemptions (voucher_id, code, campaign, user_id, business_id, plan_id, kind, percent, period_days, period_label, original_value, final_value, saved_value, status, reserved_until, created_at, alvo)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'reservado',$14,$15,$16) RETURNING id`, [v.id, v.code, v.campaign || '', a.userId, a.businessId, alvo === 'agente' ? 'agente' : a.planId, v.kind, v.percent ?? null, dias, label, x.original, x.final, x.economia, new Date(Date.now() + RESERVA_HORAS * 3600_000).toISOString(), nowIso(), alvo])
    await evento(Number(v.id), 'aplicado', actor, { [alvo === 'agente' ? 'agente' : 'anuncio']: a.businessId, usuario: a.userId, valorFinal: x.final })
    return { redemptionId: Number(r[0].id), voucher: v, ...x }
  } catch (e: any) {
    await q('UPDATE ad_vouchers SET uses = uses - 1 WHERE id = $1 AND uses > 0', [v.id]); await q('UPDATE ad_voucher_user_uses SET uses = uses - 1 WHERE voucher_id = $1 AND user_id = $2 AND uses > 0', [v.id, a.userId])
    if (/unique|duplic/i.test(String(e?.message))) fail(409, `${oQue} já tem um cupom aplicado.`, 'cupom_ja_aplicado')
    throw e
  }
}
/** Libera uma reserva (removida pelo usuário ou vencida): devolve a utilização ao limite. */
export async function liberar(redemptionId: number, motivo: string, actor: string) {
  const r = await q("UPDATE ad_voucher_redemptions SET status = 'liberado', released_at = $1, release_reason = $2 WHERE id = $3 AND status = 'reservado' RETURNING voucher_id, user_id, business_id, alvo", [nowIso(), motivo, redemptionId])
  if (!r.length) return false
  await q('UPDATE ad_vouchers SET uses = uses - 1 WHERE id = $1 AND uses > 0', [r[0].voucher_id])
  await q('UPDATE ad_voucher_user_uses SET uses = uses - 1 WHERE voucher_id = $1 AND user_id = $2 AND uses > 0', [r[0].voucher_id, r[0].user_id])
  await evento(Number(r[0].voucher_id), motivo === 'expirada' ? 'expirado' : 'removido', actor, { [r[0].alvo === 'agente' ? 'agente' : 'anuncio']: Number(r[0].business_id), motivo })
  await sincronizarAnuncio(Number(r[0].business_id), (r[0].alvo || 'anuncio') as Alvo2)
  return true
}
let ultimaLimpeza = 0
export async function expirarReservas(forcar = false) {
  if (!forcar && Date.now() - ultimaLimpeza < 30_000) return; ultimaLimpeza = Date.now()
  for (const r of await q("SELECT id FROM ad_voucher_redemptions WHERE status = 'reservado' AND reserved_until < $1", [nowIso()])) await liberar(Number(r.id), 'expirada', 'sistema')
}
export async function reservaDo(businessId: number, alvo: Alvo2 = 'anuncio') { return (await one("SELECT * FROM ad_voucher_redemptions WHERE business_id = $1 AND alvo = $2 AND status = 'reservado'", [businessId, alvo])) as any }
/** Recalcula o valor da reserva para o preço atual do plano (o preço/plano do anúncio pode mudar antes do pagamento). */
export async function recalcular(businessId: number, planId: string, preco: number, alvo: Alvo2 = 'anuncio') {
  const r = await reservaDo(businessId, alvo); if (!r) return null
  const v: any = await one('SELECT plans FROM ad_vouchers WHERE id = $1', [r.voucher_id]); const planos = J<string[]>(v?.plans, [])
  if (alvo === 'anuncio' && planos.length && !planos.includes(planId)) { await liberar(Number(r.id), 'plano não aceito pelo cupom', 'sistema'); return null }
  const c = calcular({ kind: r.kind, percent: r.percent }, preco)
  if (c.final !== Number(r.final_value) || c.original !== Number(r.original_value) || r.plan_id !== planId) await q('UPDATE ad_voucher_redemptions SET original_value = $1, final_value = $2, saved_value = $3, plan_id = $4 WHERE id = $5', [c.original, c.final, c.economia, planId, r.id])
  return { ...r, original_value: c.original, final_value: c.final, saved_value: c.economia, plan_id: planId }
}
/** Pagamento confirmado (ou ativação gratuita): a reserva vira resgate definitivo. */
export async function confirmar(businessId: number, paymentId: string, alvo: Alvo2 = 'anuncio') {
  const r = await q("UPDATE ad_voucher_redemptions SET status = 'resgatado', confirmed_at = $1, payment_id = $2 WHERE business_id = $3 AND alvo = $4 AND status = 'reservado' RETURNING *", [nowIso(), paymentId, businessId, alvo])
  if (!r.length) return null
  await evento(Number(r[0].voucher_id), 'resgatado', 'sistema', { [alvo]: businessId, pagamento: paymentId, valorFinal: Number(r[0].final_value) })
  await sincronizarAnuncio(businessId, alvo)
  return r[0]
}
/** Na ativação do anúncio: aplica o benefício resgatado (uma única vez) e devolve até quando o anúncio fica no ar. */
export async function aplicarNaAtivacao(businessId: number, diasPlano: number, alvo: Alvo2 = 'anuncio', baseMs = Date.now()): Promise<{ exp: string; beneficio: any } | null> {
  const r: any = await one("SELECT * FROM ad_voucher_redemptions WHERE business_id = $1 AND alvo = $2 AND status = 'resgatado' AND applied_at IS NULL ORDER BY id LIMIT 1", [businessId, alvo])
  if (!r) return null
  const exp = r.kind === 'vitalicio' ? VITALICIO_ATE : new Date(baseMs + (r.kind === 'gratuito' ? Number(r.period_days) : diasPlano) * 86400_000).toISOString()
  const ok = await q('UPDATE ad_voucher_redemptions SET applied_at = $1, applied_until = $2 WHERE id = $3 AND applied_at IS NULL RETURNING id', [nowIso(), exp, r.id])
  if (!ok.length) return null
  const beneficio = { cupom: r.code, tipo: r.kind, descricao: beneficioTxt({ kind: r.kind, percent: r.percent, period_label: r.period_label }, alvo), percentual: r.percent != null ? Number(r.percent) : null, periodo: r.period_label || null, vitalicio: r.kind === 'vitalicio', valorOriginal: Number(r.original_value), valorPago: Number(r.final_value), economia: Number(r.saved_value), aplicadoEm: nowIso(), ate: exp }
  await evento(Number(r.voucher_id), 'beneficio_aplicado', 'sistema', { [alvo]: businessId, ate: exp, tipo: r.kind })
  return { exp, beneficio }
}
/** Mantém em businesses.data.cupom um resumo para a tela (a fonte de verdade é ad_voucher_redemptions). */
export async function sincronizarAnuncio(businessId: number, alvo: Alvo2 = 'anuncio') {
  const b: any = await one('SELECT data FROM businesses WHERE id = $1', [businessId]); if (!b) return
  const d = J<any>(b.data, {}), r: any = await one("SELECT * FROM ad_voucher_redemptions WHERE business_id = $1 AND alvo = $2 AND (status = 'reservado' OR (status = 'resgatado' AND applied_at IS NULL)) ORDER BY id DESC LIMIT 1", [businessId, alvo])
  const k = alvo === 'agente' ? 'agenteCupom' : 'cupom' // anúncio: data.cupom (como antes); agente: data.agenteCupom
  if (r) d[k] = { codigo: r.code, tipo: r.kind, beneficio: beneficioTxt({ kind: r.kind, percent: r.percent, period_label: r.period_label }, alvo), mensagem: mensagemAplicado({ kind: r.kind, percent: r.percent, period_label: r.period_label }, alvo), valorOriginal: Number(r.original_value), valorFinal: Number(r.final_value), economia: Number(r.saved_value), status: r.status, reservadoAte: r.reserved_until ? new Date(r.reserved_until).toISOString() : null }
  else delete d[k]
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(d), businessId])
}
export { VITALICIO_ATE, brl as brlCupom }
