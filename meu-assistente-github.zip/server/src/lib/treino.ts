// Treino e Acompanhamento — capacidade pessoal do Cérebro do Chat (área "treino" de lib/pessoal.ts).
// Tudo aqui é persistente e por usuário: perfil (objetivo, nível, disponibilidade, local, limitações), plano ativo com
// versões (cada alteração guarda a anterior e o motivo), treinos realizados (frequência, sequência, adesão) e lembretes,
// que são LEMBRETES REAIS da Agenda (repetição semanal, disparados pelo agendador com push/e-mail, mesmo com o app fechado).
// O plano é gerado pela IA (JSON validado) e, se ela falhar ou responder fora do formato, por um gerador próprio
// (biblioteca de exercícios por local, divisão por dias, séries/repetições por objetivo e nível, limitações respeitadas).
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from './session.js'
import { localDate, addDays, validTz } from './time.js'
import { perfil as perfilArea, salvarPerfil } from './pessoal.js'
import * as ILU from './treino-ilustracoes.js'

/* ------------------------------------------------------------------ tipos */
export type Objetivo = 'emagrecer' | 'hipertrofia' | 'forca' | 'condicionamento' | 'saude'
export type Nivel = 'iniciante' | 'intermediario' | 'avancado'
export type Local = 'academia' | 'casa_halteres' | 'casa' | 'ar_livre'
export interface Perfil { objetivo?: Objetivo; nivel?: Nivel; diasSemana?: number; diasPreferidos?: number[]; duracaoMin?: number; local?: Local; limitacoes?: string; semLimitacoes?: boolean; preferencias?: string; atualizadoEm?: string }
export interface Exercicio { nome: string; series: number; reps: string; descanso: string; obs?: string; grupo?: string }
export interface DiaTreino { dia: number; titulo: string; foco: string; duracaoMin: number; exercicios: Exercicio[]; aquecimento?: string; final?: string }
export interface PlanoDados { dias: DiaTreino[]; orientacoes: string[] }
export interface Plano { id: number; nome: string; objetivo: string | null; versao: number; status: string; plano: PlanoDados; origem: string; lembretes: { hora?: string; dias?: number[]; itens?: number[] }; criadoEm: string; atualizadoEm: string }

export const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado']
export const OBJ_TXT: Record<Objetivo, string> = { emagrecer: 'emagrecimento', hipertrofia: 'ganho de massa muscular', forca: 'ganho de força', condicionamento: 'condicionamento físico', saude: 'saúde e bem-estar' }
export const NIVEL_TXT: Record<Nivel, string> = { iniciante: 'iniciante', intermediario: 'intermediário', avancado: 'avançado' }
export const LOCAL_TXT: Record<Local, string> = { academia: 'academia', casa_halteres: 'em casa com halteres/elásticos', casa: 'em casa, sem equipamentos', ar_livre: 'ao ar livre' }
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
export const tzDe = (u: SessionUser) => validTz(J<any>(u.settings, {})?.timezone)
export const diaDaSemana = (data: string) => new Date(data + 'T12:00:00Z').getUTCDay()
export const listaDias = (ds: number[]) => { const n = [...ds].sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7)).map((d) => DIAS[d]); return n.length <= 1 ? n.join('') : n.slice(0, -1).join(', ') + ' e ' + n[n.length - 1] }

/* ------------------------------------------------------------ extração */
const NUM: Record<string, number> = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7 }
const DIA_RE: [RegExp, number][] = [[/\bdomingos?\b/, 0], [/\bsegundas?(-feira)?\b|\bseg\b/, 1], [/\btercas?(-feira)?\b|\bter\b/, 2], [/\bquartas?(-feira)?\b|\bqua\b/, 3], [/\bquintas?(-feira)?\b|\bqui\b/, 4], [/\bsextas?(-feira)?\b|\bsex\b/, 5], [/\bsabados?\b|\bsab\b/, 6]]
export function diasCitados(texto: string): number[] { const t = nrm(texto); return DIA_RE.filter(([re]) => re.test(t)).map(([, d]) => d) }
/** O que a mensagem informa sobre o perfil. `esperado`: o que acabou de ser perguntado (respostas curtas como "3" ou "nenhuma"). */
export function extrair(texto: string, esperado: string[] = []): Partial<Perfil> {
  const t = nrm(texto), out: Partial<Perfil> = {}
  if (/emagrec|perder (peso|gordura|barriga)|secar|queimar gordura|baixar (o )?peso|reduzir (o )?peso/.test(t)) out.objetivo = 'emagrecer'
  else if (/hipertrof|massa (muscular|magra)|ganhar (massa|musculo)|ganho de massa|crescer|ficar (grande|maior)|definir|definicao|tonific/.test(t)) out.objetivo = 'hipertrofia'
  else if (/\bforca\b|mais forte|ficar forte|powerlift|levantar mais peso/.test(t)) out.objetivo = 'forca'
  else if (/condicionamento|resistencia|folego|correr|corrida|cardio|aerobic|preparo fisico/.test(t)) out.objetivo = 'condicionamento'
  else if (/saude|saudavel|qualidade de vida|bem.estar|disposicao|manter (a )?forma|me mexer|sair do sedentarismo/.test(t)) out.objetivo = 'saude'
  const tempo = t.match(/(?:treino|malho|faco academia|pratico)\s+(?:ha|faz)\s+(\d+|um|uma|dois|duas|tres)\s+(mes|meses|ano|anos)/)
  if (/nunca (treinei|fiz academia|malhei)|sedentari|iniciante|comecando|estou parad|parado ha|voltando a treinar|faz (muito )?tempo que nao|nao treino|primeira vez/.test(t)) out.nivel = 'iniciante'
  else if (tempo) { const n = NUM[tempo[1]] ?? Number(tempo[1]), meses = /ano/.test(tempo[2]) ? n * 12 : n; out.nivel = meses < 6 ? 'iniciante' : meses < 24 ? 'intermediario' : 'avancado' }
  else if (/avancad|experiente|anos de treino|treino ha anos|competi/.test(t)) out.nivel = 'avancado'
  else if (/intermediari|ja treino|treino regularmente|treino faz|ja malho/.test(t)) out.nivel = 'intermediario'
  const cit = diasCitados(texto)
  const dsm = t.match(/\b(\d|uma|duas|tres|quatro|cinco|seis|sete)\s*(?:x|vezes?|dias?)\s*(?:por|na|a|da)?\s*semana\b/) || t.match(/\b(\d|duas|tres|quatro|cinco|seis)\s+dias\b/) || (esperado.includes('diasSemana') ? t.match(/^\s*(\d|duas|tres|quatro|cinco|seis|sete)\b/) : null)
  if (/todos os dias|todo dia|diariamente/.test(t)) out.diasSemana = 6
  else if (/dia sim,? dia nao/.test(t)) out.diasSemana = 3
  else if (dsm) out.diasSemana = Math.max(1, Math.min(6, NUM[dsm[1]] ?? Number(dsm[1])))
  if (cit.length >= 1 && (cit.length >= 2 || esperado.includes('diasSemana') || /\b(nas?|aos?|de|toda|todas)\s+(segunda|terca|quarta|quinta|sexta|sabado|domingo)/.test(t))) { out.diasPreferidos = cit.slice(0, 6); if (!out.diasSemana) out.diasSemana = out.diasPreferidos.length }
  const min = t.match(/(\d{2,3})\s*(?:min|minutos)\b/), hora = t.match(/\b(uma|1)\s*hora(?:\s*e\s*meia)?\b|\bhora e meia\b|\bmeia hora\b|\b(\d)\s*h(?:oras?)?\b(?!\s*\d)/)
  if (min) out.duracaoMin = Math.max(15, Math.min(150, Number(min[1])))
  else if (hora) out.duracaoMin = /meia hora/.test(hora[0]) && !/e meia/.test(hora[0]) ? 30 : /e meia/.test(hora[0]) ? 90 : hora[2] ? Math.min(150, Number(hora[2]) * 60) : 60
  else if (esperado.includes('duracaoMin')) { const n = t.match(/^\s*(\d{2,3})\b/); if (n) out.duracaoMin = Math.max(15, Math.min(150, Number(n[1]))) }
  if (/academia|musculacao|crossfit|box\b/.test(t)) out.local = 'academia'
  else if (/halter|anilha|elastic|kettlebell|barra fixa|tenho peso/.test(t)) out.local = 'casa_halteres'
  else if (/ar livre|parque|praca|na rua|praia|calcadao/.test(t)) out.local = 'ar_livre'
  else if (/em casa|\bcasa\b|sem equipamento|peso do corpo|no quarto|na sala/.test(t)) out.local = 'casa'
  const lim = String(texto).match(/[^.!?\n]*(dor|les[aã]o|machuc|problema (no|na|de)|operei|cirurgia|h[eé]rnia|tendinite|condromal[aá]cia|artrose|bursite|asma|hipertens|press[aã]o alta|diabet|gr[aá]vida|gestante|card[ií]ac|labirintite|escoliose|joelho|lombar|coluna|ombro|punho)[^.!?\n]*/i)
  if (lim && !/\b(nao tenho|nenhuma|sem) (dor|lesao|limitacao|problema)/.test(t)) out.limitacoes = lim[0].trim().slice(0, 240)
  else if ((esperado.includes('limitacoes') && /^(nao|nada|nenhum|nenhuma|tudo certo|tranquilo|sem|nao tenho|to bem|estou bem|ok)\b/.test(t)) || /\b(nao tenho|nenhuma|sem) (dor|lesao|lesoes|limitac|problema)/.test(t)) out.semLimitacoes = true
  return out
}
/** O que ainda falta para montar o plano (na ordem das perguntas). */
export function faltando(p: Perfil): string[] {
  const f: string[] = []
  if (!p.objetivo || !p.nivel) f.push('objetivo')
  if (!p.diasSemana) f.push('diasSemana')
  if (!p.local) f.push('local')
  if (!p.limitacoes && !p.semLimitacoes) f.push('limitacoes')
  return f
}
/** Pergunta natural para o próximo passo (uma de cada vez; aproveita o que já se sabe). */
export function pergunta(p: Perfil, campo: string): { texto: string; esperado: string[] } {
  if (campo === 'objetivo') {
    if (p.objetivo && !p.nivel) return { texto: `Beleza, foco em ${OBJ_TXT[p.objetivo]}. Você já treina ou está começando agora? Se já treina, há quanto tempo?`, esperado: ['nivel'] }
    if (!p.objetivo && p.nivel) return { texto: 'Qual é o seu objetivo principal: emagrecer, ganhar massa muscular, ganhar força, melhorar o condicionamento ou cuidar da saúde?', esperado: ['objetivo'] }
    return { texto: 'Pra montar um treino que faça sentido pra você: qual é o seu objetivo principal (emagrecer, ganhar massa, ganhar força, condicionamento ou saúde)? E você já treina ou está começando agora?', esperado: ['objetivo', 'nivel'] }
  }
  if (campo === 'diasSemana') return { texto: 'Quantos dias por semana você consegue treinar, e quanto tempo por treino? Se tiver dias certos, me diga também (ex.: "segunda, quarta e sexta, 45 minutos").', esperado: ['diasSemana', 'duracaoMin'] }
  if (campo === 'local') return { texto: 'Onde você vai treinar: academia, em casa sem equipamentos, em casa com halteres ou elásticos, ou ao ar livre?', esperado: ['local'] }
  return { texto: 'Última coisa: tem alguma dor, lesão ou condição de saúde que eu deva considerar? Se não tiver, é só dizer "nenhuma".', esperado: ['limitacoes'] }
}

/* --------------------------------------------------------- persistência */
export const perfil = async (userId: number) => ((await perfilArea<Perfil>(userId, 'treino')) || {}) as Perfil
export const atualizarPerfil = (userId: number, p: Partial<Perfil>) => salvarPerfil<Perfil>(userId, 'treino', { ...p, atualizadoEm: nowIso() })
const planoOut = (r: any): Plano => ({ id: Number(r.id), nome: String(r.nome), objetivo: r.objetivo || null, versao: Number(r.versao) || 1, status: String(r.status || 'ativo'), plano: J<PlanoDados>(r.plano, { dias: [], orientacoes: [] }), origem: String(r.origem || 'ia'), lembretes: J<any>(r.lembretes, {}), criadoEm: String(r.criado_em), atualizadoEm: String(r.atualizado_em) })
export async function planoAtivo(userId: number): Promise<Plano | null> {
  const r = await one("SELECT * FROM treino_planos WHERE user_id = $1 AND status = 'ativo' ORDER BY id DESC LIMIT 1", [userId])
  return r ? planoOut(r) : null
}
/** Novo plano: o anterior é arquivado (continua no histórico). */
export async function criarPlano(userId: number, nome: string, objetivo: string, dados: PlanoDados, origem: string): Promise<Plano> {
  const ant = await planoAtivo(userId)
  await q("UPDATE treino_planos SET status = 'arquivado', atualizado_em = $1 WHERE user_id = $2 AND status = 'ativo'", [nowIso(), userId])
  const r = await q('INSERT INTO treino_planos (user_id, nome, objetivo, status, versao, plano, origem, lembretes, criado_em, atualizado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9) RETURNING *',
    [userId, nome.slice(0, 120), objetivo, 'ativo', 1, JSON.stringify(dados), origem, JSON.stringify(ant?.lembretes || {}), nowIso()])
  const p = planoOut(r[0])
  if (ant?.lembretes?.itens?.length) await moverLembretes(userId, ant, p) // lembretes seguem os dias do plano novo
  return p
}
/** Alteração do plano ativo: guarda a versão anterior com o motivo. */
export async function alterarPlano(userId: number, p: Plano, dados: PlanoDados, motivo: string): Promise<Plano> {
  await q('INSERT INTO treino_plano_versoes (plano_id, versao, plano, motivo, criado_em) VALUES ($1,$2,$3,$4,$5)', [p.id, p.versao, JSON.stringify(p.plano), motivo.slice(0, 300), nowIso()])
  await q('UPDATE treino_planos SET plano = $1, versao = $2, atualizado_em = $3 WHERE id = $4 AND user_id = $5', [JSON.stringify(dados), p.versao + 1, nowIso(), p.id, userId])
  const novo = { ...p, plano: dados, versao: p.versao + 1 }
  if (p.lembretes?.itens?.length && JSON.stringify(p.plano.dias.map((d) => d.dia)) !== JSON.stringify(dados.dias.map((d) => d.dia))) await moverLembretes(userId, p, novo)
  return novo
}
/** Desfaz a última alteração (volta à versão anterior). */
export async function desfazer(userId: number, p: Plano): Promise<{ plano: Plano; motivo: string } | null> {
  const v = await one('SELECT * FROM treino_plano_versoes WHERE plano_id = $1 ORDER BY versao DESC LIMIT 1', [p.id])
  if (!v) return null
  await q('UPDATE treino_planos SET plano = $1, versao = $2, atualizado_em = $3 WHERE id = $4 AND user_id = $5', [String(typeof v.plano === 'string' ? v.plano : JSON.stringify(v.plano)), Number(v.versao), nowIso(), p.id, userId])
  await q('DELETE FROM treino_plano_versoes WHERE id = $1', [v.id])
  return { plano: { ...p, plano: J<PlanoDados>(v.plano, p.plano), versao: Number(v.versao) }, motivo: String(v.motivo || '') }
}
export async function versoes(planoId: number) { return (await q('SELECT versao, motivo, criado_em FROM treino_plano_versoes WHERE plano_id = $1 ORDER BY versao DESC LIMIT 20', [planoId])).map((r: any) => ({ versao: Number(r.versao), motivo: String(r.motivo || ''), em: String(r.criado_em) })) }

/* ------------------------------------------------------------ consulta */
export const treinoDoDia = (p: Plano, dia: number) => p.plano.dias.find((d) => d.dia === dia) || null
export function proximoTreino(p: Plano, data: string): { data: string; dia: DiaTreino } | null {
  for (let i = 1; i <= 7; i++) { const d = addDays(data, i), t = treinoDoDia(p, diaDaSemana(d)); if (t) return { data: d, dia: t } }
  return null
}
export const fmtEx = (e: Exercicio) => `- ${e.nome} — ${e.series} × ${e.reps}, descanso ${e.descanso}${e.obs ? ` (${e.obs})` : ''}`
export function fmtDia(d: DiaTreino, rotulo?: string) {
  return [`**${rotulo || DIAS[d.dia][0].toUpperCase() + DIAS[d.dia].slice(1)} — ${d.titulo}** (≈ ${d.duracaoMin} min)`, d.aquecimento ? `Aquecimento: ${d.aquecimento}` : '', ...d.exercicios.map(fmtEx), d.final ? `Para fechar: ${d.final}` : ''].filter(Boolean).join('\n')
}
export function fmtPlano(p: Plano, comOrientacoes = true) {
  const dias = [...p.plano.dias].sort((a, b) => ((a.dia + 6) % 7) - ((b.dia + 6) % 7))
  return [`## ${p.nome}`, `${dias.length} treino${dias.length > 1 ? 's' : ''} por semana: ${listaDias(dias.map((d) => d.dia))}.`, ...dias.map((d) => '\n' + fmtDia(d)), comOrientacoes && p.plano.orientacoes.length ? '\n**Orientações**\n' + p.plano.orientacoes.map((o) => '- ' + o).join('\n') : ''].filter(Boolean).join('\n')
}

/* --------------------------------------------------------- acompanhamento */
export async function registrar(userId: number, p: Plano | null, data: string, o: { status?: 'concluido' | 'parcial' | 'pulado'; nota?: string; esforco?: number } = {}) {
  const dia = diaDaSemana(data), t = p ? treinoDoDia(p, dia) : null
  const ex = await one('SELECT id FROM treino_sessoes WHERE user_id = $1 AND data = $2', [userId, data])
  const vals = [p?.id ?? null, dia, t ? t.titulo : 'Treino extra', o.status || 'concluido', o.nota?.slice(0, 300) || null, o.esforco ?? null]
  if (ex) await q('UPDATE treino_sessoes SET plano_id = $1, dia_plano = $2, titulo = $3, status = $4, nota = COALESCE($5, nota), esforco = COALESCE($6, esforco) WHERE id = $7', [...vals, ex.id])
  else await q('INSERT INTO treino_sessoes (user_id, plano_id, dia_plano, titulo, status, nota, esforco, data, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)', [userId, ...vals, data, nowIso()])
  return { jaHavia: !!ex, planejado: !!t, titulo: t ? t.titulo : 'Treino extra' }
}
export async function desfazerRegistro(userId: number, data: string) { return (await q('DELETE FROM treino_sessoes WHERE user_id = $1 AND data = $2 RETURNING id', [userId, data])).length > 0 }
export interface Acomp { total: number; semana: number; metaSemana: number; ultimos30: number; sequencia: number; adesao: { feitos: number; planejados: number; pct: number }; ultimo: { data: string; titulo: string } | null; feitoHoje: boolean; semanas: number[] }
export async function acompanhamento(userId: number, p: Plano | null, hoje: string): Promise<Acomp> {
  const rows = (await q("SELECT data, titulo, status FROM treino_sessoes WHERE user_id = $1 AND status <> 'pulado' ORDER BY data DESC LIMIT 400", [userId])) as any[]
  const feitos = new Set(rows.map((r) => String(r.data)))
  const planejado = (d: string) => !!(p && treinoDoDia(p, diaDaSemana(d)))
  // semana atual (segunda a domingo)
  const seg = addDays(hoje, -((diaDaSemana(hoje) + 6) % 7))
  let semana = 0; for (let i = 0; i < 7; i++) if (feitos.has(addDays(seg, i))) semana++
  let ultimos30 = 0; for (let i = 0; i < 30; i++) if (feitos.has(addDays(hoje, -i))) ultimos30++
  // sequência: treinos planejados cumpridos sem falta (dias de descanso não quebram; hoje só conta se já foi feito)
  let sequencia = 0
  for (let i = feitos.has(hoje) ? 0 : 1; i < 180; i++) { const d = addDays(hoje, -i); if (feitos.has(d)) { sequencia++; continue } if (planejado(d)) break }
  // adesão das últimas 4 semanas (até ontem): dias planejados cumpridos
  let pl = 0, ok = 0; for (let i = 1; i <= 28; i++) { const d = addDays(hoje, -i); if (planejado(d)) { pl++; if (feitos.has(d)) ok++ } }
  const semanas: number[] = []; for (let w = 3; w >= 0; w--) { let n = 0; for (let i = 0; i < 7; i++) if (feitos.has(addDays(seg, -7 * w + i))) n++; semanas.push(n) }
  return { total: rows.length, semana, metaSemana: p?.plano.dias.length || 0, ultimos30, sequencia, adesao: { feitos: ok, planejados: pl, pct: pl ? Math.round((ok / pl) * 100) : 0 }, ultimo: rows[0] ? { data: String(rows[0].data), titulo: String(rows[0].titulo || '') } : null, feitoHoje: feitos.has(hoje), semanas }
}
/** Leitura dos números (específica, sem frase genérica): reconhece progresso, aponta o que falta. */
export function leitura(a: Acomp): string {
  const f: string[] = []
  if (a.metaSemana) f.push(a.semana >= a.metaSemana ? `Meta da semana batida: ${a.semana} de ${a.metaSemana} treinos.` : `Nesta semana: ${a.semana} de ${a.metaSemana} treinos${a.semana ? '' : ' até agora'}.`)
  if (a.sequencia >= 3) f.push(`Sequência de ${a.sequencia} treinos sem faltar nenhum planejado.`)
  if (a.adesao.planejados >= 4) f.push(a.adesao.pct >= 80 ? `Nas últimas 4 semanas você cumpriu ${a.adesao.feitos} de ${a.adesao.planejados} treinos planejados (${a.adesao.pct}%) — consistência muito boa.` : a.adesao.pct >= 50 ? `Nas últimas 4 semanas: ${a.adesao.feitos} de ${a.adesao.planejados} treinos planejados (${a.adesao.pct}%). Dá para subir isso ajustando os dias ao que cabe na sua rotina.` : `Nas últimas 4 semanas: ${a.adesao.feitos} de ${a.adesao.planejados} treinos planejados (${a.adesao.pct}%). Se a rotina apertou, posso reduzir os dias ou encurtar os treinos.`)
  const [a3, a2, a1, a0] = a.semanas
  if (a1 + a2 + a3 > 0 && a0 > Math.max(a1, a2, a3)) f.push('Esta é a sua semana com mais treinos do último mês.')
  return f.join(' ')
}

/* ------------------------------------------------------------ lembretes */
async function apagarLembretes(userId: number, ids: number[]) { if (ids.length) for (const id of ids) await q("DELETE FROM items WHERE id = $1 AND user_id = $2 AND type = 'reminder'", [id, userId]) }
/** Lembretes reais da Agenda (um por dia de treino, repetição semanal), que abrem o treino do dia. */
export async function definirLembretes(u: SessionUser, p: Plano, hora: string, dias?: number[]): Promise<Plano> {
  const { createItem } = await import('../routes/items.js')
  const tz = tzDe(u), hoje = localDate(tz), ds = (dias?.length ? dias : p.plano.dias.map((d) => d.dia)).filter((d, i, a) => a.indexOf(d) === i)
  await apagarLembretes(u.id, p.lembretes?.itens || [])
  const itens: number[] = []
  for (const d of ds) {
    let data = hoje; for (let i = 0; i < 7; i++) { const x = addDays(hoje, i); if (diaDaSemana(x) === d) { data = x; break } }
    const [row] = await createItem(u, 'reminder', { message: 'Hora do treino 🏋️', date: data, time: hora, recurrence: 'weekly' })
    const id = Number((row as any).id); itens.push(id)
    const r = await one('SELECT data FROM items WHERE id = $1', [id]); const dd = J<any>(r?.data, {})
    await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify({ ...dd, origem: 'treino', link: '/?treino=hoje' }), id])
  }
  const lembretes = { hora, dias: ds, itens }
  await q('UPDATE treino_planos SET lembretes = $1, atualizado_em = $2 WHERE id = $3 AND user_id = $4', [JSON.stringify(lembretes), nowIso(), p.id, u.id])
  return { ...p, lembretes }
}
export async function desligarLembretes(userId: number, p: Plano) { await apagarLembretes(userId, p.lembretes?.itens || []); await q('UPDATE treino_planos SET lembretes = $1 WHERE id = $2 AND user_id = $3', ['{}', p.id, userId]); return { ...p, lembretes: {} } }
async function moverLembretes(userId: number, de: Plano, para: Plano) {
  const r = await one('SELECT * FROM users WHERE id = $1', [userId]); if (!r || !de.lembretes?.hora) return
  const { hydrateUser } = await import('./session.js')
  await definirLembretes(hydrateUser(r), { ...para, lembretes: de.lembretes }, de.lembretes.hora)
}
/** Texto do aviso no horário do treino (o agendador chama): o treino do dia, ou o próximo. */
export async function resumoAviso(userId: number, tz: string, quando = new Date()): Promise<string | undefined> {
  const p = await planoAtivo(userId); if (!p) return undefined
  const hoje = localDate(tz, quando), t = treinoDoDia(p, diaDaSemana(hoje))
  return t ? `Hoje: ${t.titulo} · ${t.exercicios.length} exercícios · ≈ ${t.duracaoMin} min` : undefined
}

/* ---------------------------------------------- geração do plano (modelo) */
type Tag = 'joelho' | 'lombar' | 'ombro' | 'punho' | 'impacto'
interface Ex0 { nome: string; grupo: string; locais: ('academia' | 'halteres' | 'corpo')[]; evita?: Tag[] }
const L = (s: string) => s.split('|') as Ex0['locais']
const BIB: Ex0[] = [
  { nome: 'Agachamento livre', grupo: 'quadriceps', locais: L('academia'), evita: ['joelho', 'lombar'] },
  { nome: 'Leg press 45°', grupo: 'quadriceps', locais: L('academia'), evita: ['joelho'] },
  { nome: 'Cadeira extensora', grupo: 'quadriceps', locais: L('academia'), evita: ['joelho'] },
  { nome: 'Agachamento goblet com halter', grupo: 'quadriceps', locais: L('halteres'), evita: ['joelho'] },
  { nome: 'Afundo alternado', grupo: 'quadriceps', locais: L('academia|halteres|corpo'), evita: ['joelho'] },
  { nome: 'Agachamento com o peso do corpo', grupo: 'quadriceps', locais: L('corpo'), evita: ['joelho'] },
  { nome: 'Subida no degrau', grupo: 'quadriceps', locais: L('corpo|halteres'), evita: ['joelho'] },
  { nome: 'Mesa flexora', grupo: 'posterior', locais: L('academia') },
  { nome: 'Stiff com halteres', grupo: 'posterior', locais: L('academia|halteres'), evita: ['lombar'] },
  { nome: 'Elevação pélvica', grupo: 'gluteo', locais: L('academia|halteres|corpo') },
  { nome: 'Ponte de glúteo', grupo: 'gluteo', locais: L('corpo|halteres') },
  { nome: 'Cadeira abdutora', grupo: 'gluteo', locais: L('academia') },
  { nome: 'Abdução de quadril deitado de lado', grupo: 'gluteo', locais: L('corpo|halteres') },
  { nome: 'Supino reto com barra', grupo: 'peito', locais: L('academia'), evita: ['ombro'] },
  { nome: 'Supino inclinado com halteres', grupo: 'peito', locais: L('academia|halteres'), evita: ['ombro'] },
  { nome: 'Crucifixo na máquina', grupo: 'peito', locais: L('academia') },
  { nome: 'Supino com halteres no chão', grupo: 'peito', locais: L('halteres') },
  { nome: 'Flexão de braço (apoie os joelhos se precisar)', grupo: 'peito', locais: L('corpo'), evita: ['punho', 'ombro'] },
  { nome: 'Flexão inclinada com as mãos no banco', grupo: 'peito', locais: L('corpo|halteres'), evita: ['punho'] },
  { nome: 'Puxada frontal', grupo: 'costas', locais: L('academia') },
  { nome: 'Remada baixa', grupo: 'costas', locais: L('academia') },
  { nome: 'Remada unilateral com halter', grupo: 'costas', locais: L('academia|halteres') },
  { nome: 'Remada invertida na mesa ou barra baixa', grupo: 'costas', locais: L('corpo') },
  { nome: 'Remada com elástico', grupo: 'costas', locais: L('halteres|corpo') },
  { nome: 'Desenvolvimento com halteres', grupo: 'ombro', locais: L('academia|halteres'), evita: ['ombro'] },
  { nome: 'Elevação lateral', grupo: 'ombro', locais: L('academia|halteres'), evita: ['ombro'] },
  { nome: 'Face pull na polia', grupo: 'ombro', locais: L('academia') },
  { nome: 'Elevação de braços em Y deitado', grupo: 'ombro', locais: L('corpo') },
  { nome: 'Rosca direta', grupo: 'biceps', locais: L('academia|halteres'), evita: ['punho'] },
  { nome: 'Rosca martelo', grupo: 'biceps', locais: L('academia|halteres') },
  { nome: 'Tríceps na polia', grupo: 'triceps', locais: L('academia') },
  { nome: 'Tríceps francês com halter', grupo: 'triceps', locais: L('academia|halteres'), evita: ['ombro'] },
  { nome: 'Mergulho no banco', grupo: 'triceps', locais: L('corpo'), evita: ['ombro', 'punho'] },
  { nome: 'Prancha', grupo: 'core', locais: L('academia|halteres|corpo') },
  { nome: 'Prancha lateral', grupo: 'core', locais: L('academia|halteres|corpo') },
  { nome: 'Dead bug', grupo: 'core', locais: L('academia|halteres|corpo') },
  { nome: 'Abdominal supra', grupo: 'core', locais: L('academia|halteres|corpo'), evita: ['lombar'] },
  { nome: 'Bicicleta ergométrica (ritmo moderado)', grupo: 'cardio', locais: L('academia') },
  { nome: 'Esteira com caminhada inclinada', grupo: 'cardio', locais: L('academia') },
  { nome: 'Polichinelo', grupo: 'cardio', locais: L('corpo|halteres'), evita: ['joelho', 'impacto'] },
  { nome: 'Caminhada rápida', grupo: 'cardio', locais: L('corpo|halteres') },
  { nome: 'Corrida leve', grupo: 'cardio', locais: L('corpo'), evita: ['joelho', 'impacto'] },
]
export function tagsLimitacao(t: string): Tag[] {
  const s = nrm(t), out: Tag[] = []
  if (/joelh|menisco|condromal|patel|ligamento/.test(s)) out.push('joelho', 'impacto')
  if (/lombar|coluna|hernia|costas|escoliose|ciatic/.test(s)) out.push('lombar')
  if (/ombro|manguito|bursite/.test(s)) out.push('ombro')
  if (/punho|pulso|mao|tunel do carpo|tendinite no (punho|pulso)/.test(s)) out.push('punho')
  if (/gravida|gestante|cardiac|coracao|hipertens|pressao alta|labirint/.test(s)) out.push('impacto')
  return [...new Set(out)]
}
export const exigeAvaliacao = (t: string) => /gravida|gestante|cardiac|coracao|hipertens|pressao alta|diabet|cirurgia|operei|hernia|asma|labirint/.test(nrm(t))
const DIVISOES: Record<string, { titulo: string; foco: string; grupos: string[] }[]> = {
  fullA: [{ titulo: 'Treino A — Corpo inteiro', foco: 'corpo inteiro', grupos: ['quadriceps', 'peito', 'costas', 'gluteo', 'ombro', 'core', 'biceps', 'triceps'] }],
  fullB: [{ titulo: 'Treino B — Corpo inteiro', foco: 'corpo inteiro', grupos: ['posterior', 'costas', 'peito', 'quadriceps', 'core', 'ombro', 'triceps', 'biceps'] }],
  abc: [{ titulo: 'Treino A — Peito, ombro e tríceps', foco: 'empurrar', grupos: ['peito', 'peito', 'ombro', 'triceps', 'ombro', 'core'] }, { titulo: 'Treino B — Costas e bíceps', foco: 'puxar', grupos: ['costas', 'costas', 'biceps', 'costas', 'biceps', 'core'] }, { titulo: 'Treino C — Pernas e abdômen', foco: 'pernas', grupos: ['quadriceps', 'posterior', 'gluteo', 'quadriceps', 'gluteo', 'core'] }],
  ul: [{ titulo: 'Treino A — Superiores', foco: 'superiores', grupos: ['peito', 'costas', 'ombro', 'triceps', 'biceps', 'core'] }, { titulo: 'Treino B — Inferiores', foco: 'inferiores', grupos: ['quadriceps', 'posterior', 'gluteo', 'quadriceps', 'core', 'gluteo'] }],
}
function divisao(n: number, nivel: Nivel) {
  if (n <= 2 || (n === 3 && nivel === 'iniciante')) return Array.from({ length: n }, (_, i) => (i % 2 ? DIVISOES.fullB[0] : DIVISOES.fullA[0]))
  if (n === 3) return DIVISOES.abc
  if (n === 4) return [DIVISOES.ul[0], DIVISOES.ul[1], { ...DIVISOES.ul[0], titulo: 'Treino C — Superiores' }, { ...DIVISOES.ul[1], titulo: 'Treino D — Inferiores' }]
  if (n === 5) return [...DIVISOES.abc, { ...DIVISOES.ul[0], titulo: 'Treino D — Superiores' }, { ...DIVISOES.ul[1], titulo: 'Treino E — Inferiores' }]
  return [...DIVISOES.abc, ...DIVISOES.abc.map((d, i) => ({ ...d, titulo: d.titulo.replace(/^Treino ./, 'Treino ' + 'DEF'[i]) }))]
}
export const diasPadrao = (n: number): number[] => ({ 1: [3], 2: [2, 4], 3: [1, 3, 5], 4: [1, 2, 4, 5], 5: [1, 2, 3, 4, 5], 6: [1, 2, 3, 4, 5, 6] } as Record<number, number[]>)[Math.max(1, Math.min(6, n))]
function volume(o: Objetivo, n: Nivel) {
  const s = n === 'iniciante' ? 0 : n === 'avancado' ? 1 : 0
  if (o === 'forca') return { series: 4 + s, reps: n === 'iniciante' ? '8–10' : '4–6', descanso: n === 'iniciante' ? '90 s' : '2–3 min' }
  if (o === 'hipertrofia') return { series: 3 + s, reps: '8–12', descanso: '60–90 s' }
  if (o === 'emagrecer' || o === 'condicionamento') return { series: 3, reps: '12–15', descanso: '30–45 s' }
  return { series: n === 'iniciante' ? 2 : 3, reps: '10–15', descanso: '60 s' }
}
/** Plano sem IA: mesma estrutura, regras claras e seguras. */
export function gerarModelo(p: Perfil): { nome: string; dados: PlanoDados } {
  const objetivo = p.objetivo || 'saude', nivel = p.nivel || 'iniciante', n = Math.max(1, Math.min(6, p.diasSemana || 3)), dur = p.duracaoMin || 45
  const loc: Ex0['locais'][number] = p.local === 'academia' ? 'academia' : p.local === 'casa_halteres' ? 'halteres' : 'corpo'
  const tags = tagsLimitacao(p.limitacoes || ''), v = volume(objetivo, nivel)
  const comCardio = objetivo === 'emagrecer' || objetivo === 'condicionamento'
  const nEx = Math.max(3, Math.min(8, Math.round((dur - 10 - (comCardio ? 15 : 0)) / 7)))
  const dias = (p.diasPreferidos?.length === n ? p.diasPreferidos : diasPadrao(n)).slice().sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7))
  const usados = new Map<string, number>()
  const escolhe = (grupo: string, ja: Set<string>) => {
    const ok = BIB.filter((e) => e.grupo === grupo && e.locais.includes(loc) && !(e.evita || []).some((t) => tags.includes(t)) && !ja.has(e.nome))
    ok.sort((a, b) => (usados.get(a.nome) || 0) - (usados.get(b.nome) || 0))
    const e = ok[0]; if (e) usados.set(e.nome, (usados.get(e.nome) || 0) + 1)
    return e
  }
  const dv = divisao(n, nivel)
  const diasT: DiaTreino[] = dias.map((dia, i) => {
    const d = dv[i % dv.length], ja = new Set<string>(), ex: Exercicio[] = []
    for (const g of d.grupos) { if (ex.length >= nEx) break; const e = escolhe(g, ja); if (!e) continue; ja.add(e.nome); ex.push(g === 'core' ? { nome: e.nome, series: v.series, reps: /prancha/i.test(e.nome) ? '30–45 s' : '12–15', descanso: '30–45 s', grupo: g } : { nome: e.nome, series: v.series, reps: v.reps, descanso: v.descanso, grupo: g }) }
    const cardio = comCardio ? escolhe('cardio', new Set()) : null
    return { dia, titulo: d.titulo, foco: d.foco, duracaoMin: dur, exercicios: ex, aquecimento: '5–10 min de caminhada ou bike leve + mobilidade das articulações que vai usar', final: cardio ? `${cardio.nome}, 15–20 min` : 'alongamento leve, 5 min' }
  })
  const orient = [
    nivel === 'iniciante' ? 'Nas duas primeiras semanas, use cargas leves e foque em aprender a execução de cada exercício.' : 'Aumente a carga quando completar todas as séries no topo das repetições com boa técnica.',
    'Faça os movimentos de forma controlada, sem pressa, e respire durante o esforço (solte o ar na fase de força).',
    'Pare o exercício se sentir dor aguda ou articular — desconforto muscular é normal, dor não.',
    'Beba água durante o treino e durma bem: a evolução acontece no descanso.',
  ]
  if (p.limitacoes) orient.unshift(`Como você comentou: "${p.limitacoes}", deixei de fora exercícios que costumam sobrecarregar essa região. Antes de começar, vale passar por um médico ou fisioterapeuta.`)
  else if (exigeAvaliacao(p.preferencias || '')) orient.unshift('Antes de começar, faça uma avaliação médica.')
  if (nivel === 'iniciante') orient.push('Se puder, peça a um profissional de educação física para conferir a sua execução nas primeiras sessões.')
  return { nome: `Plano de ${OBJ_TXT[objetivo]} — ${n} dia${n > 1 ? 's' : ''} por semana`, dados: { dias: diasT, orientacoes: orient } }
}
/** Valida (e normaliza) um plano vindo da IA. null = fora do formato. */
export function validarPlano(x: any, p: Perfil): PlanoDados | null {
  if (!x || !Array.isArray(x.dias) || !x.dias.length || x.dias.length > 7) return null
  const dias: DiaTreino[] = []
  for (const d of x.dias) {
    const dia = typeof d.dia === 'number' ? d.dia : diasCitados(String(d.dia || ''))[0]
    if (!(dia >= 0 && dia <= 6) || dias.some((y) => y.dia === dia)) return null
    const ex = (Array.isArray(d.exercicios) ? d.exercicios : []).map((e: any) => ({ nome: String(e?.nome || '').trim().slice(0, 80), series: Math.max(1, Math.min(8, Math.round(Number(e?.series) || 0))), reps: String(e?.reps || e?.repeticoes || '').trim().slice(0, 20), descanso: String(e?.descanso || '').trim().slice(0, 20) || '60 s', obs: e?.obs ? String(e.obs).slice(0, 120) : undefined })).filter((e: Exercicio) => e.nome && e.series && e.reps)
    if (ex.length < 2 || ex.length > 12) return null
    dias.push({ dia, titulo: String(d.titulo || 'Treino').slice(0, 80), foco: String(d.foco || '').slice(0, 60), duracaoMin: Math.max(15, Math.min(150, Math.round(Number(d.duracaoMin) || p.duracaoMin || 45))), exercicios: ex, aquecimento: d.aquecimento ? String(d.aquecimento).slice(0, 160) : undefined, final: d.final ? String(d.final).slice(0, 160) : undefined })
  }
  if (p.diasSemana && dias.length !== p.diasSemana) return null
  // limitação informada: exercício que sabidamente sobrecarrega a região não passa
  const tags = tagsLimitacao(p.limitacoes || ''); const proibidos = BIB.filter((e) => (e.evita || []).some((t) => tags.includes(t))).map((e) => nrm(e.nome).split(' (')[0])
  if (tags.length && dias.some((d) => d.exercicios.some((e) => proibidos.some((pp) => nrm(e.nome).startsWith(pp))))) return null
  const orient = (Array.isArray(x.orientacoes) ? x.orientacoes : []).map((o: any) => String(o).slice(0, 240)).filter(Boolean).slice(0, 8)
  if (p.limitacoes && !orient.some((o: string) => /m[eé]dic|fisioterap|profissional/i.test(o))) orient.unshift(`Como você comentou: "${p.limitacoes}", passe por um médico ou fisioterapeuta antes de começar.`)
  return { dias: dias.sort((a, b) => ((a.dia + 6) % 7) - ((b.dia + 6) % 7)), orientacoes: orient.length ? orient : gerarModelo(p).dados.orientacoes }
}
export const perfilTexto = (p: Perfil) => [p.objetivo ? `objetivo: ${OBJ_TXT[p.objetivo]}` : '', p.nivel ? `nível: ${NIVEL_TXT[p.nivel]}` : '', p.diasSemana ? `${p.diasSemana} dia(s)/semana${p.diasPreferidos?.length ? ` (${listaDias(p.diasPreferidos)})` : ''}` : '', p.duracaoMin ? `${p.duracaoMin} min por treino` : '', p.local ? `local: ${LOCAL_TXT[p.local]}` : '', p.limitacoes ? `limitações: ${p.limitacoes}` : p.semLimitacoes ? 'sem limitações informadas' : '', p.preferencias ? `preferências: ${p.preferencias}` : ''].filter(Boolean).join('; ')

/* ------------------------------------------------------ edição do plano */
const tokens = (s: string) => nrm(s).replace(/[^a-z0-9 ]/g, ' ').split(' ').filter((w) => w.length > 2 && !['com', 'para', 'por', 'dos', 'das', 'que', 'exercicio'].includes(w))
/** Exercício do plano mais parecido com o nome dito (no dia indicado, se houver). */
export function acharExercicio(p: PlanoDados, nome: string, dia?: number): { d: DiaTreino; i: number } | null {
  const alvo = tokens(nome); if (!alvo.length) return null
  let best: { d: DiaTreino; i: number; s: number } | null = null
  for (const d of p.dias) { if (dia !== undefined && d.dia !== dia) continue; d.exercicios.forEach((e, i) => { const et = tokens(e.nome); const s = alvo.filter((w) => et.some((x) => x.startsWith(w.slice(0, 5)) || w.startsWith(x.slice(0, 5)))).length / alvo.length; if (s > 0 && (!best || s > best.s)) best = { d, i, s } }) }
  return best && (best as any).s >= 0.5 ? { d: (best as any).d, i: (best as any).i } : null
}
/** Alternativa da biblioteca para o mesmo grupo (respeita local e limitações). */
export function alternativa(p: Perfil, plano: PlanoDados, ex: Exercicio): string | null {
  const loc = p.local === 'academia' ? 'academia' : p.local === 'casa_halteres' ? 'halteres' : 'corpo', tags = tagsLimitacao(p.limitacoes || '')
  const grupo = ex.grupo || BIB.find((b) => nrm(b.nome) === nrm(ex.nome))?.grupo || BIB.find((b) => tokens(ex.nome).some((w) => nrm(b.nome).includes(w)))?.grupo
  if (!grupo) return null
  const noPlano = new Set(plano.dias.flatMap((d) => d.exercicios.map((e) => nrm(e.nome))))
  // na academia também há halteres e espaço para o peso do corpo; com halteres em casa, também o peso do corpo
  const ok = (loc === 'academia' ? ['academia', 'halteres', 'corpo'] : loc === 'halteres' ? ['halteres', 'corpo'] : ['corpo']) as any[]
  const livre = (b: any) => b.grupo === grupo && !(b.evita || []).some((t: any) => tags.includes(t)) && !noPlano.has(nrm(b.nome))
  for (const l of ok) { const b = BIB.find((x) => livre(x) && x.locais.includes(l)); if (b) return b.nome }
  return null
}
export const clonar = (p: PlanoDados): PlanoDados => JSON.parse(JSON.stringify(p))

/** Resumo curto para o Cérebro do Chat (contexto de qualquer conversa, mesmo fora do modo). */
export async function contextoChat(u: SessionUser): Promise<string> {
  const p = await planoAtivo(u.id); if (!p) return ''
  const hoje = localDate(tzDe(u)), t = treinoDoDia(p, diaDaSemana(hoje)), a = await acompanhamento(u.id, p, hoje)
  return `Treino do usuário (Treino e Acompanhamento, salvo no sistema): "${p.nome}", ${listaDias(p.plano.dias.map((d) => d.dia))}. Hoje: ${t ? t.titulo + (a.feitoHoje ? ' (já concluído)' : '') : 'descanso'}. Nesta semana: ${a.semana}/${a.metaSemana} treinos. Para ver, criar, alterar ou registrar treinos, o usuário pode pedir diretamente (ex.: "treino de hoje", "marque meu treino como concluído").`
}

/* ------------------------------------------------- ficha visual (chat) */
// A ficha do chat (card ⟦tr:…⟧) mostra o plano ATIVO por dia da semana, agrupado por grupo muscular, com cada exercício em
// um cartão (ilustração das posições inicial/final quando há padrão de movimento conhecido, séries, repetições, descanso e
// instruções). A pessoa marca o que concluiu e anota a carga; isso fica em treino_exercicio_registros e alimenta o progresso
// diário/semanal e a evolução de carga. Marcar exercícios também registra a sessão do dia (treino_sessoes, origem "ficha"):
// todos concluídos = treino concluído; parte = parcial. Desmarcar tudo só desfaz a sessão que a própria ficha criou.
export const chaveEx = (nome: string) => nrm(nome).replace(/\([^)]*\)/g, ' ').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80)
const AREA: Record<string, string> = { quadriceps: 'Pernas', posterior: 'Pernas', gluteo: 'Glúteos', peito: 'Peito', costas: 'Costas', ombro: 'Ombros', biceps: 'Braços', triceps: 'Braços', core: 'Abdômen e core', cardio: 'Cardio' }
const AREA_PADRAO: Record<string, string> = { agachamento: 'Pernas', afundo: 'Pernas', terra: 'Pernas', leg_press: 'Pernas', supino_chao: 'Peito', remada_invertida: 'Costas', extensora: 'Pernas', flexora: 'Pernas', step: 'Pernas', panturrilha: 'Pernas', supino: 'Peito', supino_inclinado: 'Peito', crucifixo: 'Peito', flexao: 'Peito', remada: 'Costas', puxada: 'Costas', desenvolvimento: 'Ombros', elevacao_lateral: 'Ombros', face_pull: 'Ombros', elevacao_y: 'Ombros', rosca: 'Braços', triceps_polia: 'Braços', triceps_frances: 'Braços', mergulho: 'Braços', prancha: 'Abdômen e core', prancha_lateral: 'Abdômen e core', abdominal: 'Abdômen e core', dead_bug: 'Abdômen e core', ponte: 'Glúteos', abducao_lateral: 'Glúteos', abducao_sentado: 'Glúteos', polichinelo: 'Cardio', caminhada: 'Cardio', corrida: 'Cardio', bike: 'Cardio', burpee: 'Corpo inteiro' }
const ORDEM_AREA = ['Peito', 'Costas', 'Ombros', 'Braços', 'Pernas', 'Glúteos', 'Abdômen e core', 'Corpo inteiro', 'Cardio', 'Outros']
export function areaDe(e: Exercicio): string {
  const g = e.grupo || BIB.find((b) => nrm(b.nome) === nrm(e.nome))?.grupo
  if (g && AREA[g]) return AREA[g]
  const pd = ILU.padraoDe(e.nome); return pd ? AREA_PADRAO[pd.id] || 'Outros' : 'Outros'
}
const DIA_CURTO = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
export const segundaDe = (data: string) => addDays(data, -((diaDaSemana(data) + 6) % 7))
const num = (v: unknown) => (v === null || v === undefined || v === '' ? null : Number(v))
export interface RegEx { concluido: boolean; carga: number | null; reps: string | null }
async function registrosDe(userId: number, de: string, ate: string) {
  const rows = (await q('SELECT data, chave, concluido, carga_kg, reps FROM treino_exercicio_registros WHERE user_id = $1 AND data >= $2 AND data <= $3', [userId, de, ate])) as any[]
  const out: Record<string, Record<string, RegEx>> = {}
  for (const r of rows) (out[String(r.data)] ||= {})[String(r.chave)] = { concluido: Number(r.concluido) === 1 || r.concluido === true, carga: num(r.carga_kg), reps: r.reps ? String(r.reps) : null }
  return out
}
/** Evolução de carga por exercício: última carga, melhor carga e as últimas anotações (mais recente primeiro). */
export async function cargasDe(userId: number, chaves: string[]) {
  const out: Record<string, { ultima: { data: string; carga: number; reps: string | null } | null; melhor: number | null; historico: { data: string; carga: number }[] }> = {}
  if (!chaves.length) return out
  const rows = (await q(`SELECT chave, data, carga_kg, reps FROM treino_exercicio_registros WHERE user_id = $1 AND carga_kg IS NOT NULL AND chave IN (${chaves.map((_, i) => '$' + (i + 2)).join(',')}) ORDER BY data DESC LIMIT 600`, [userId, ...chaves])) as any[]
  for (const k of chaves) { const rs = rows.filter((r) => String(r.chave) === k); out[k] = { ultima: rs[0] ? { data: String(rs[0].data), carga: Number(rs[0].carga_kg), reps: rs[0].reps ? String(rs[0].reps) : null } : null, melhor: rs.length ? Math.max(...rs.map((r) => Number(r.carga_kg))) : null, historico: rs.slice(0, 8).map((r) => ({ data: String(r.data), carga: Number(r.carga_kg) })) } }
  return out
}
export function exercicioFicha(e: Exercicio) {
  const pd = ILU.padraoDe(e.nome)
  return { chave: chaveEx(e.nome), nome: e.nome, series: e.series, reps: e.reps, descanso: e.descanso, obs: e.obs || null, area: areaDe(e),
    instrucoes: pd ? pd.instrucoes : [], ilustracao: pd ? { padrao: pd.id, nome: pd.nome, ini: ILU.urlIlustracao(pd.id, 'ini'), fim: ILU.urlIlustracao(pd.id, 'fim'), isometrico: !!pd.isometrico, musculos: pd.grupo } : null }
}
/** Dados completos da ficha do plano ativo (semana atual, registros, progresso e cargas). */
export async function ficha(u: SessionUser) {
  const p = await planoAtivo(u.id), hoje = localDate(tzDe(u))
  if (!p) return { semPlano: true as const, hoje }
  const seg = segundaDe(hoje), dom = addDays(seg, 6), regs = await registrosDe(u.id, seg, dom)
  const sess = (await q('SELECT data, status, origem FROM treino_sessoes WHERE user_id = $1 AND data >= $2 AND data <= $3', [u.id, seg, dom])) as any[]
  const dias = [...p.plano.dias].sort((a, b) => ((a.dia + 6) % 7) - ((b.dia + 6) % 7)).map((d) => {
    const exs = d.exercicios.map(exercicioFicha), grupos: { nome: string; exercicios: typeof exs }[] = []
    for (const e of exs) { let g = grupos.find((x) => x.nome === e.area); if (!g) grupos.push(g = { nome: e.area, exercicios: [] }); g.exercicios.push(e) }
    grupos.sort((a, b) => ORDEM_AREA.indexOf(a.nome) - ORDEM_AREA.indexOf(b.nome))
    const data = addDays(seg, (d.dia + 6) % 7)
    return { dia: d.dia, nome: DIAS[d.dia], curto: DIA_CURTO[d.dia], data, titulo: d.titulo, foco: d.foco, duracaoMin: d.duracaoMin, aquecimento: d.aquecimento || null, final: d.final || null, total: exs.length, grupos }
  })
  const semana = Array.from({ length: 7 }, (_, i) => { const data = addDays(seg, i), dia = diaDaSemana(data), t = dias.find((x) => x.dia === dia), s = sess.find((x) => String(x.data) === data), r = regs[data] || {}
    const feitos = t ? t.grupos.flatMap((g) => g.exercicios).filter((e) => r[e.chave]?.concluido).length : 0
    return { data, dia, curto: DIA_CURTO[dia], planejado: !!t, titulo: t?.titulo || null, status: s ? String(s.status) : null, feitos, total: t?.total || 0, hoje: data === hoje, futuro: data > hoje } })
  const a = await acompanhamento(u.id, p, hoje)
  const chaves = [...new Set(dias.flatMap((d) => d.grupos.flatMap((g) => g.exercicios.map((e) => e.chave))))]
  const tHoje = dias.find((d) => d.data === hoje)
  return { semPlano: false as const, hoje, diaHoje: diaDaSemana(hoje), semanaDe: seg,
    plano: { id: p.id, nome: p.nome, versao: p.versao, objetivo: p.objetivo, orientacoes: p.plano.orientacoes, atualizadoEm: p.atualizadoEm },
    dias, registros: regs, semana, cargas: await cargasDe(u.id, chaves),
    progresso: { hojeFeitos: tHoje ? semana.find((s) => s.data === hoje)!.feitos : 0, hojeTotal: tHoje?.total || 0, semanaTreinos: a.semana, metaSemana: a.metaSemana,
      semanaExercicios: semana.reduce((s, x) => s + x.feitos, 0), semanaExerciciosTotal: semana.reduce((s, x) => s + x.total, 0), sequencia: a.sequencia, ultimos30: a.ultimos30, semanas: a.semanas, total: a.total } }
}
/** Mantém a sessão do dia coerente com o que foi marcado na ficha. */
async function sincronizarSessao(userId: number, p: Plano, data: string) {
  const d = treinoDoDia(p, diaDaSemana(data)); if (!d) return null
  const chaves = d.exercicios.map((e) => chaveEx(e.nome)), regs = (await registrosDe(userId, data, data))[data] || {}
  const feitos = chaves.filter((k) => regs[k]?.concluido).length, total = chaves.length
  const s: any = await one('SELECT id, status, origem FROM treino_sessoes WHERE user_id = $1 AND data = $2', [userId, data])
  const status = feitos >= total ? 'concluido' : 'parcial'
  if (feitos === 0) { if (s && s.origem === 'ficha') await q('DELETE FROM treino_sessoes WHERE id = $1 AND user_id = $2', [s.id, userId]); return { feitos, total, status: s && s.origem !== 'ficha' ? String(s.status) : null } }
  if (!s) await q('INSERT INTO treino_sessoes (user_id, plano_id, dia_plano, titulo, status, data, origem, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [userId, p.id, d.dia, d.titulo, status, data, 'ficha', nowIso()])
  else if (s.origem === 'ficha' || s.status === 'pulado' || (s.status === 'parcial' && status === 'concluido')) await q('UPDATE treino_sessoes SET status = $1, plano_id = $2, dia_plano = $3, titulo = $4 WHERE id = $5', [status, p.id, d.dia, d.titulo, s.id])
  // treino registrado como concluído pelo chat ("treinei") continua concluído: a ficha não rebaixa o que a pessoa disse
  const atual: any = await one('SELECT status FROM treino_sessoes WHERE user_id = $1 AND data = $2', [userId, data])
  return { feitos, total, status: atual ? String(atual.status) : null }
}
/** Marca/desmarca um exercício e/ou anota carga e repetições. Só o plano ativo, só o exercício do dia, só até hoje (7 dias). */
export async function marcarExercicio(u: SessionUser, b: { data?: unknown; chave?: unknown; concluido?: unknown; carga?: unknown; reps?: unknown }) {
  const { fail } = await import('./http.js')
  const p = await planoAtivo(u.id); if (!p) fail(404, 'Você ainda não tem um plano de treino ativo.', 'sem_plano')
  const hoje = localDate(tzDe(u)), data = String(b.data || hoje)
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) fail(400, 'Data inválida.', 'invalid', 'data')
  if (data > hoje) fail(400, 'Esse treino ainda não chegou: dá para marcar no dia.', 'futuro', 'data')
  if (data < addDays(hoje, -6)) fail(400, 'Só dá para marcar treinos dos últimos 7 dias.', 'antigo', 'data')
  const d = treinoDoDia(p!, diaDaSemana(data)); if (!d) fail(400, 'Esse dia é de descanso no seu plano.', 'descanso', 'data')
  const ex = d!.exercicios.find((e) => chaveEx(e.nome) === String(b.chave || '')); if (!ex) fail(400, 'Esse exercício não está no treino deste dia.', 'exercicio', 'chave')
  let carga: number | null | undefined
  if (b.carga !== undefined) { if (b.carga === null || b.carga === '') carga = null; else { const n = Number(String(b.carga).replace(',', '.')); if (!Number.isFinite(n) || n < 0 || n > 1000) fail(400, 'Informe a carga em kg (de 0 a 1000).', 'invalid', 'carga'); carga = Math.round(n * 100) / 100 } }
  let reps: string | null | undefined
  if (b.reps !== undefined) { reps = b.reps === null ? null : String(b.reps).replace(/[^\d,x×\-–/ ]/g, '').trim().slice(0, 20) || null }
  const conc = b.concluido === undefined ? undefined : (b.concluido === true || b.concluido === 1 || b.concluido === 'true' ? 1 : 0)
  const chave = chaveEx(ex!.nome), atual: any = await one('SELECT id, concluido, carga_kg, reps FROM treino_exercicio_registros WHERE user_id = $1 AND data = $2 AND chave = $3', [u.id, data, chave])
  // anotar a carga também conta como feito (quem anota o peso fez o exercício), a não ser que a pessoa desmarque
  const concFinal = conc !== undefined ? conc : carga != null && !atual ? 1 : atual ? Number(atual.concluido) : 0
  if (atual) await q('UPDATE treino_exercicio_registros SET concluido = $1, carga_kg = $2, reps = $3, plano_id = $4, nome = $5, atualizado_em = $6 WHERE id = $7', [concFinal, carga !== undefined ? carga : atual.carga_kg, reps !== undefined ? reps : atual.reps, p!.id, ex!.nome, nowIso(), atual.id])
  else await q('INSERT INTO treino_exercicio_registros (user_id, plano_id, data, dia_plano, chave, nome, concluido, carga_kg, reps, atualizado_em, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [u.id, p!.id, data, d!.dia, chave, ex!.nome, concFinal, carga ?? null, reps ?? null, nowIso()])
  const sessao = await sincronizarSessao(u.id, p!, data)
  const reg = ((await registrosDe(u.id, data, data))[data] || {})[chave]
  return { ok: true, data, chave, registro: reg, dia: { feitos: sessao?.feitos || 0, total: sessao?.total || 0, status: sessao?.status || null }, cargas: (await cargasDe(u.id, [chave]))[chave] }
}
/** Texto do chat → exercício do plano: tira números, unidades e verbos e procura o nome que sobrou. */
export function exercicioDoTexto(p: PlanoDados, texto: string, dia?: number) {
  const limpo = nrm(texto).replace(/\d+(?:[.,]\d+)?\s*(kg|quilos?|kilos?|reps?|repeticoes|repeticao|vezes|x|series?)?\b/g, ' ')
    .replace(/\b(fiz|faco|fizemos|registr\w*|anot\w*|marc\w*|marqu\w*|conclu\w*|termin\w*|coloc\w*|usei|levantei|peguei|subi|carga|peso|de|do|da|no|na|o|a|os|as|com|em|hoje|ontem|como|feito|feita|concluido|concluida|pronto|ja|eu|meu|minha|exercicio|treino|series|serie|por|pra|para|mais|kg)\b/g, ' ').replace(/\s+/g, ' ').trim()
  if (!limpo) return null
  return acharExercicio(p, limpo, dia) || null
}
export const brKg = (n: number) => `${String(Math.round(n * 100) / 100).replace('.', ',')} kg`
