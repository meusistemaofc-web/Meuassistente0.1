// TAREFAS DO CHAT EM SEGUNDO PLANO
//
// Cada envio ao chat é uma tarefa persistente (tabela chat_jobs), ligada ao usuário e à conversa:
//   aguardando (queued) → processando (pending) → concluída (done) | falhou (error) [→ descartada (dismissed)]
// • O processamento NÃO depende da tela: se o usuário sai do chat, fecha o app ou navega para outra página, a tarefa
//   continua no servidor (pesquisa, consultas ao Cérebro Central, ferramentas…) e o resultado fica salvo na conversa.
// • Quem saiu (conexão encerrada ou aviso do app) recebe uma notificação — in-app e push, respeitando as preferências e a
//   permissão do aparelho — com o início da resposta; tocar abre a conversa (/?c=<conversa>).
// • Fila com limite global e por usuário: pedidos rápidos começam na hora; o excesso espera a vez (aguardando).
// • Contra execução duplicada: a passagem para "processando" é atômica (UPDATE … WHERE status = 'queued') e a posse tem
//   prazo (lease_ate), renovado enquanto roda. Contra notificação duplicada: "notificado" é marcado atomicamente e a
//   notificação tem referência única. Contra tarefa abandonada: a varredura encerra como "falhou" (com aviso) o que ficou
//   sem dono — ex.: o servidor reiniciou — e o pedido fica guardado para "Tentar de novo".
import { etapaAtual } from './etapas.js'
import { q, one, nowIso } from '../db/index.js'
import { fail } from './http.js'

const MAX_GLOBAL = Math.max(1, Number(process.env.CHAT_TAREFAS_MAX) || 8)
const MAX_USUARIO = Math.max(1, Number(process.env.CHAT_TAREFAS_POR_USUARIO) || 2)
const LEASE_MS = 15 * 60_000, RENOVA_MS = 4 * 60_000, AGUARDA_MAX_MS = 10 * 60_000
export const ESTADO: Record<string, 'aguardando' | 'processando' | 'concluida' | 'falhou' | 'descartada'> = { queued: 'aguardando', pending: 'processando', done: 'concluida', error: 'falhou', dismissed: 'descartada' }
const emAndamento = new Set<string>() // tarefas deste processo (na fila ou rodando): a varredura não mexe nelas

/* ---------- fila (limite global e por usuário) ---------- */
let ativos = 0
const porUsuario = new Map<number, number>()
const espera: { uid: number; ok: () => void }[] = []
const pode = (uid: number) => ativos < MAX_GLOBAL && (porUsuario.get(uid) || 0) < MAX_USUARIO
const ocupa = (uid: number) => { ativos++; porUsuario.set(uid, (porUsuario.get(uid) || 0) + 1) }
export function entrar(uid: number): Promise<void> {
  if (!espera.length && pode(uid)) { ocupa(uid); return Promise.resolve() }
  return new Promise((r) => { espera.push({ uid, ok: () => { ocupa(uid); r() } }); acordar() })
}
export function sair(uid: number) { ativos = Math.max(0, ativos - 1); const n = (porUsuario.get(uid) || 1) - 1; if (n > 0) porUsuario.set(uid, n); else porUsuario.delete(uid); acordar() }
function acordar() { for (let i = 0; i < espera.length && ativos < MAX_GLOBAL; i++) if (pode(espera[i].uid)) { const w = espera.splice(i, 1)[0]; i--; w.ok() } }
export const situacaoFila = () => ({ ativos, aguardando: espera.length, maxGlobal: MAX_GLOBAL, maxPorUsuario: MAX_USUARIO })

/* ---------- ciclo de vida ---------- */
const prevResumo = (t: string, n = 160) => { const s = String(t || '').replace(/⟦[^⟧]*⟧/g, ' ').replace(/[*_`#>]+/g, '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s }
/** Registra a tarefa (aguardando). O pedido fica guardado (sem arquivos) para poder tentar de novo. */
export async function registrar(id: string, userId: number, b: any, temArquivos: boolean) {
  const payload = { text: String(b.text || '').slice(0, 8000), conversationId: b.conversationId || undefined, replyToId: b.replyToId || undefined, modo: typeof b.modo === 'string' ? b.modo : undefined, resendOf: b.resendOf || undefined }
  const arquivos = temArquivos || !!b.photos?.batchId
  await q('INSERT INTO chat_jobs (id, user_id, status, conversation_id, texto, payload, tem_arquivos, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)',
    [id, userId, 'queued', b.conversationId ? String(b.conversationId).slice(0, 64) : null, prevResumo(b.text || (arquivos ? '📎 Arquivo enviado' : ''), 200), JSON.stringify(payload), arquivos, nowIso()])
  emAndamento.add(id)
}
/** Passa para "processando" (atômico: só um processo consegue) e começa a renovar a posse enquanto roda. */
export async function iniciar(id: string): Promise<(() => void) | null> {
  const agora = Date.now()
  const r = await q("UPDATE chat_jobs SET status = 'pending', iniciado_em = $1, lease_ate = $2, tentativas = tentativas + 1, updated_at = $1 WHERE id = $3 AND status = 'queued' RETURNING id", [new Date(agora).toISOString(), new Date(agora + LEASE_MS).toISOString(), id])
  if (!r.length) return null
  const t = setInterval(() => { void q("UPDATE chat_jobs SET lease_ate = $1 WHERE id = $2 AND status = 'pending'", [new Date(Date.now() + LEASE_MS).toISOString(), id]).catch(() => {}) }, RENOVA_MS)
  t.unref?.()
  return () => clearInterval(t)
}
export async function concluir(id: string, res: any) {
  const a = res?.assistantMessage, conv = res?.conversation?.id || null
  await q("UPDATE chat_jobs SET status = 'done', result = $1, resumo = $2, conversation_id = COALESCE($3, conversation_id), concluido_em = $4, lease_ate = NULL, updated_at = $4 WHERE id = $5",
    [JSON.stringify(res), prevResumo(a?.content || ''), conv, nowIso(), id])
  emAndamento.delete(id)
  void avisarSeSaiu(id).catch((e) => console.error('[tarefas] aviso:', e?.message)) // a resposta ao app não espera o aviso
}
export async function falhar(id: string, e: any) {
  await q("UPDATE chat_jobs SET status = 'error', error = $1, error_code = $2, error_status = $3, concluido_em = $4, lease_ate = NULL, updated_at = $4 WHERE id = $5",
    [String(e?.message || 'Não consegui responder agora.').slice(0, 300), e?.code || 'ai_error', Number(e?.status) || 502, nowIso(), id])
  emAndamento.delete(id)
  void avisarSeSaiu(id).catch((e) => console.error('[tarefas] aviso:', e?.message))
}
/** O usuário saiu da tela (conexão caiu, app minimizado, outra página) ou voltou. Se a tarefa já terminou e ele não viu, avisa. */
export async function marcarSegundoPlano(id: string, userId: number, ativo: boolean) {
  const r = await q('UPDATE chat_jobs SET segundo_plano = $1 WHERE id = $2 AND user_id = $3 RETURNING status', [ativo, id, userId])
  if (ativo && r.length && ['done', 'error'].includes(String(r[0].status))) await avisarSeSaiu(id)
  return r.length ? ESTADO[String(r[0].status)] : null
}
/** Notificação (uma única vez por resultado): só para quem saiu da tela. */
export async function avisarSeSaiu(id: string) {
  const j = await one('SELECT * FROM chat_jobs WHERE id = $1', [id]); if (!j || !j.segundo_plano || j.notificado) return false
  if (!['done', 'error'].includes(String(j.status))) return false
  const ok = await q('UPDATE chat_jobs SET notificado = $1 WHERE id = $2 AND notificado = $3 RETURNING id', [true, id, false]); if (!ok.length) return false
  const link = j.conversation_id ? `/?c=${encodeURIComponent(j.conversation_id)}` : '/'
  const pedido = j.texto ? `“${prevResumo(j.texto, 60)}”` : 'sua solicitação'
  const { notify } = await import('./notify.js')
  if (j.status === 'done') await notify(Number(j.user_id), { type: 'chat', title: 'Sua resposta está pronta', body: j.resumo ? `${pedido}: ${j.resumo}` : `Concluí ${pedido}. Toque para ver.`, link, ref: `chat-tarefa:${id}:${j.tentativas}` })
  else await notify(Number(j.user_id), { type: 'chat', title: 'Não consegui concluir sua solicitação', body: `${pedido} — ${prevResumo(j.error || 'erro ao processar', 120)} Toque para tentar de novo.`, link, ref: `chat-tarefa-erro:${id}:${j.tentativas}` })
  return true
}

/* ---------- consulta (estados reais para o app) ---------- */
// etapa real em andamento (indicador compacto do app); na fila: "Na fila…"
const etapaDo = (j: any) => { if (j.status === 'queued') return { e: 'fila', t: 'Na fila…' }; if (j.status !== 'pending') return null; const x = etapaAtual(String(j.id)); return x ? { e: x.e, t: x.t } : null }
export const tarefaOut = (j: any) => ({ id: String(j.id), estado: ESTADO[String(j.status)] || 'processando', conversa: j.conversation_id || null, texto: j.texto || '', tentativas: Number(j.tentativas) || 0,
  criadaEm: j.created_at instanceof Date ? j.created_at.toISOString() : String(j.created_at || ''), iniciadaEm: j.iniciado_em ? String(j.iniciado_em instanceof Date ? j.iniciado_em.toISOString() : j.iniciado_em) : null,
  concluidaEm: j.concluido_em ? String(j.concluido_em instanceof Date ? j.concluido_em.toISOString() : j.concluido_em) : null, erro: j.status === 'error' ? String(j.error || '') : null,
  podeTentarDeNovo: j.status === 'error' && !j.tem_arquivos && !!j.payload, reenviarArquivo: j.status === 'error' && !!j.tem_arquivos, segundoPlano: !!j.segundo_plano, resumo: j.status === 'done' ? (j.resumo || '') : null, etapa: etapaDo(j) })
/** Tarefas de uma conversa (ou de todas): as em andamento e as que falharam nas últimas 24 h; concluídas das últimas 2 h. */
export async function listar(userId: number, conversa?: string) {
  const desde = new Date(Date.now() - 24 * 3600e3).toISOString(), recente = Date.now() - 2 * 3600e3
  const rows = await q(`SELECT * FROM chat_jobs WHERE user_id = $1 AND created_at >= $2 ${conversa ? 'AND conversation_id = $3' : ''} AND status IN ('queued','pending','error','done') ORDER BY created_at DESC LIMIT 30`, conversa ? [userId, desde, conversa] : [userId, desde])
  return rows.filter((j: any) => j.status !== 'done' || Date.parse(String(j.concluido_em instanceof Date ? j.concluido_em.toISOString() : j.concluido_em || 0)) >= recente).map(tarefaOut)
}
export async function descartar(id: string, userId: number) {
  const r = await q("UPDATE chat_jobs SET status = 'dismissed', updated_at = $1 WHERE id = $2 AND user_id = $3 AND status = 'error' RETURNING id", [nowIso(), id, userId])
  if (!r.length) fail(409, 'Só dá para descartar uma tarefa que falhou.', 'invalid')
}

/* ---------- tentar de novo (pedido guardado) ---------- */
export async function tentarDeNovo(id: string, userId: number) {
  const j = await one('SELECT * FROM chat_jobs WHERE id = $1 AND user_id = $2', [id, userId]); if (!j) fail(404, 'Tarefa não encontrada.', 'not_found')
  if (j!.tem_arquivos) fail(409, 'Este pedido tinha arquivo (foto, áudio ou documento). Envie o arquivo de novo pelo chat.', 'reenviar_arquivo')
  if (!j!.payload) fail(409, 'Este pedido não pode ser repetido automaticamente. Escreva de novo no chat.', 'invalid')
  // atômico: dois toques em "Tentar de novo" não disparam duas execuções
  const r = await q("UPDATE chat_jobs SET status = 'queued', error = NULL, error_code = NULL, error_status = NULL, notificado = $1, segundo_plano = $1, result = NULL, concluido_em = NULL, updated_at = $2 WHERE id = $3 AND user_id = $4 AND status = 'error' RETURNING *", [false, nowIso(), id, userId])
  if (!r.length) fail(409, j!.status === 'error' ? 'A tarefa já está sendo processada.' : 'Esta tarefa não falhou: não há o que repetir.', 'invalid')
  emAndamento.add(id)
  void executarSalvo(r[0]).catch((e) => console.error('[tarefas] nova tentativa:', e?.message))
  return tarefaOut(r[0])
}
/** Executa um pedido guardado, fora de uma requisição (tentar de novo): mesma fila, posse e avisos. */
async function executarSalvo(j: any) {
  const uid = Number(j.user_id)
  await entrar(uid)
  let parar: (() => void) | null = null
  try {
    parar = await iniciar(String(j.id)); if (!parar) return
    const row = await one('SELECT * FROM users WHERE id = $1', [uid]); if (!row) throw Object.assign(new Error('Conta não encontrada.'), { code: 'not_found', status: 404 })
    const { hydrateUser } = await import('./session.js')
    const ctx: any = { user: hydrateUser(row), session: { id: 'tarefa', user_id: uid, mfa_pending: false, recovery: false }, body: JSON.parse(String(j.payload)), req: { headers: {}, socket: {} }, params: {}, files: [], query: new URLSearchParams() }
    const { executarChat } = await import('../routes/chat.js')
    const res = await (await import('./etapas.js')).comEtapas(String(j.id), () => {}, () => executarChat(ctx))
    await concluir(String(j.id), res)
  } catch (e) { await falhar(String(j.id), e) } finally { parar?.(); sair(uid); emAndamento.delete(String(j.id)) }
}

/* ---------- varredura (tarefas abandonadas) ---------- */
/** Encerra como "falhou" (com aviso e pedido guardado) o que ficou sem dono: posse vencida ou fila parada demais. */
export async function varrer(agora = Date.now()) {
  const rows = await q("SELECT id, status, lease_ate, created_at FROM chat_jobs WHERE status IN ('queued','pending') AND created_at >= $1", [new Date(agora - 7 * 24 * 3600e3).toISOString()])
  let n = 0
  for (const j of rows as any[]) {
    const id = String(j.id); if (emAndamento.has(id)) continue
    const lease = j.lease_ate ? Date.parse(String(j.lease_ate instanceof Date ? j.lease_ate.toISOString() : j.lease_ate)) : 0
    const criada = Date.parse(String(j.created_at instanceof Date ? j.created_at.toISOString() : j.created_at))
    const abandonada = j.status === 'pending' ? lease < agora : agora - criada > AGUARDA_MAX_MS
    if (!abandonada) continue
    const r = await q("UPDATE chat_jobs SET status = 'error', error = $1, error_code = 'interrompida', error_status = 503, segundo_plano = $2, lease_ate = NULL, concluido_em = $3, updated_at = $3 WHERE id = $4 AND status = $5 RETURNING id",
      ['O processamento foi interrompido antes de terminar (o servidor reiniciou). Seu pedido ficou guardado.', true, nowIso(), id, j.status])
    if (r.length) { n++; await avisarSeSaiu(id).catch(() => {}) }
  }
  return n
}
let varredura: NodeJS.Timeout | null = null
/** Na subida do servidor: recupera o que o processo anterior deixou pela metade e varre a cada minuto. */
export function iniciarVarredura() {
  if (varredura) return
  setTimeout(() => void varrer().then((n) => n && console.log(`[tarefas] ${n} tarefa(s) interrompida(s) encerrada(s) com aviso`)).catch((e) => console.error('[tarefas]', e?.message)), 5_000).unref?.()
  varredura = setInterval(() => void varrer().catch((e) => console.error('[tarefas]', e?.message)), 60_000); varredura.unref?.()
}
