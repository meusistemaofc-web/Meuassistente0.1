// Busca inteligente de produtos e serviços (modo "Busca" do chat). Funções puras, sem banco: a lista de itens vem de
// itensPublicos() (routes/businesses.ts), com as mesmas regras de publicação da vitrine.
//  • intenção: só ativa com pedido claro de procura/compra ("quero encontrar", "onde comprar", "procuro", "quem vende"…);
//    conversas comuns, dados pessoais ("buscar meu filho", "procurar minha nota"), lembretes, agenda e finanças ficam de fora;
//  • consulta: tira as palavras do pedido, limite de preço ("até 50 reais") e ordem ("mais barato", "mais perto");
//  • correspondência aproximada: acentos, plural, erro de digitação (distância de edição), prefixo, sinônimos do comércio
//    e descrição do item; nome e palavras-chave pesam mais que a descrição;
//  • semelhantes: quando há poucos resultados exatos, itens da mesma categoria dos encontrados (ou que batem em parte).

export const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()

/** Radical leve do português (plural e alguns sufixos), o mesmo para a consulta e para os itens. */
export function radical(w: string) {
  if (w.length <= 3 || /^\d+$/.test(w)) return w
  if (/(oes|aes|aos)$/.test(w)) return w.slice(0, -3) + 'ao'
  if (/eis$/.test(w) && w.length > 4) return w.slice(0, -3) + 'el'
  if (/[rz]es$/.test(w)) return w.slice(0, -2)
  if (/ns$/.test(w)) return w.slice(0, -2) + 'm'
  if (/s$/.test(w) && !/(ss|us|is)$/.test(w)) return w.slice(0, -1)
  return w
}
const STOP = new Set('a o as os um uma uns umas de da do das dos d em no na nos nas num numa para pra pro pros pras por pelo pela com sem e ou que qual quais algum alguma alguns algumas me mim eu voce vc to ta tem ter tenho isso esse essa este esta aqui ai la ja so tambem mais muito muita bem bom boa favor porfavor pfv pf ola oi oie bom dia tarde noite ate o a ao aos sobre como onde quem quero queria gostaria preciso precisando estou ando agora hoje hj amanha perto proximo proxima regiao minha meu bairro cidade aqui local lugar lugares loja lojas empresa empresas vende vendem venda vendendo comprar compro compra encontrar encontre encontra encontro achar ache acha acho procurar procuro procura procurando procure buscar busque busca buscando pesquisar pesquise pesquisa algo coisa coisas produto produtos servico servicos item itens opcao opcoes tipo tipos favor ver mostrar mostre mostra quanto custa preco valor barato barata baratos baratas caro reais real rs r posso consigo pode podem da dar mae pai esposa marido namorado namorada amigo amiga vo avo sogra sogro tia tio irma irmao chefe colega'.split(' '))

/* Sinônimos e equivalências comuns do comércio de bairro (grupos fechados; cada palavra já no radical). */
const GRUPOS = [
  'celular smartphone telefone iphone android', 'notebook laptop computador pc', 'fone headphone headset earphone', 'carregador fonte cabo',
  'tenis sapatenis calcado sapato', 'camiseta camisa blusa', 'calca jeans', 'vestido saia', 'bolsa mochila', 'oculo oculos',
  'doce docinho brigadeiro beijinho', 'salgado salgadinho coxinha esfiha empada', 'pao paozinho', 'lanche hamburguer burger sanduiche', 'pizza pizzaria',
  'refrigerante refri soda', 'cerveja breja chopp', 'suco sucos', 'agua mineral', 'cafe cafezinho expresso', 'acai acaiteria',
  'marmita quentinha marmitex prato refeicao almoco', 'sorvete picole gelato', 'chocolate cacau', 'presente lembrancinha mimo', 'flor buque arranjo floricultura',
  'racao petisco', 'cachorro cao dog pet', 'gato felino pet', 'banho tosa', 'remedio medicamento farmacia', 'perfume fragrancia colonia',
  'maquiagem make batom base', 'cabelo corte cabeleireiro', 'barba barbearia barbeiro', 'unha manicure pedicure esmalte', 'sobrancelha design',
  'massagem massoterapia', 'conserto reparo manutencao assistencia', 'eletricista eletrica', 'encanador encanamento hidraulica', 'limpeza faxina diarista',
  'aula curso professor', 'foto fotografia fotografo', 'festa aniversario infantil', 'crianca infantil kid', 'roupa vestuario moda', 'mercado mercearia supermercado',
  'fruta hortifruti verdura legume', 'carne acougue', 'frango galinha', 'peixe frutos', 'artesanal caseiro', 'vegano vegetariano', 'diet zero', 'integral fit',
]
const SIN = new Map<string, number>(); GRUPOS.forEach((g, i) => g.split(' ').forEach((w) => SIN.set(radical(w), i)))

/** Distância de edição com transposição (Damerau–Levenshtein restrita), interrompida cedo acima do limite. */
export function distancia(a: string, b: string, lim = 2) {
  if (Math.abs(a.length - b.length) > lim) return lim + 1
  const d: number[][] = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)])
  for (let j = 1; j <= b.length; j++) d[0][j] = j
  for (let i = 1; i <= a.length; i++) {
    let min = Infinity
    for (let j = 1; j <= b.length; j++) {
      const c = a[i - 1] === b[j - 1] ? 0 : 1
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1)
      min = Math.min(min, d[i][j])
    }
    if (min > lim) return lim + 1
  }
  return d[a.length][b.length]
}
/** Quanto a palavra da consulta corresponde a uma palavra do item (0 a 1) e de que jeito. */
export function casar(q: string, t: string): { v: number; como: 'exato' | 'prefixo' | 'sinonimo' | 'digitacao' | '' } {
  if (q === t) return { v: 1, como: 'exato' }
  const mn = Math.min(q.length, t.length)
  if (mn >= 4 && (t.startsWith(q) || q.startsWith(t))) return { v: 0.85, como: 'prefixo' }
  const gq = SIN.get(q); if (gq !== undefined && gq === SIN.get(t)) return { v: 0.8, como: 'sinonimo' }
  if (q.length >= 4 && t.length >= 4 && q[0] === t[0] || (q.length >= 6 && t.length >= 6)) {
    const lim = Math.min(q.length, t.length) >= 7 ? 2 : Math.min(q.length, t.length) >= 4 ? 1 : 0
    if (lim && distancia(q, t, lim) <= lim) return { v: lim === 2 && distancia(q, t, 1) > 1 ? 0.7 : 0.78, como: 'digitacao' }
  }
  return { v: 0, como: '' }
}
const toks = (t: string) => norm(t).split(' ').filter((w) => w.length >= 2 && !STOP.has(w)).map(radical)

/* ---------- intenção ---------- */
const FORTE = [
  /\b(quero|queria|preciso|gostaria de|vou) (encontrar|achar|comprar|contratar|procurar|buscar)\b/,
  /\b(encontr[ae]|ache|acha|busque|busca|procure|procura|pesquise) (pra|para) (mim|gente|nos)\b/,
  /\bme ajud[ae] a (encontrar|achar|procurar|comprar)\b/,
  /\b(buscar|procurar|pesquisar|encontrar|achar|busca|procura|pesquisa)( um| uma| o| a| os| as)? (produto|produtos|servico|servicos|item|itens)\b/,
  /\bonde (eu )?(posso |consigo |da pra |da para |tem para |tem pra |tem )?(comprar|compro|compra|encontrar|encontro|achar|acho|contratar|vende|vendem|tem pra vender)\b/,
  /\b(quem|que loja|qual loja|alguma loja|algum lugar|algum local|alguma empresa)( que)? (vende|vendem|faz|fazem|tem|conserta|entrega)\b/,
  /\b(estou|to|tou|ando|tamo|estamos) (procurando|buscando|atras de|querendo comprar|precisando de)\b/,
  /\b(procuro|busco)\b/,
  /\bmodo (de )?busca\b/,
]
const FRACO = /\b(encontrar|encontre|encontra|achar|ache|procurar|procure|buscar|busque|pesquisar|pesquise)\b/
/** Não é procura de compra: dados pessoais, pessoas, informação, trabalho, lembretes, agenda e finanças. */
const VERBO = '(encontr\\w*|ach(ar|e|a|o)|procur\\w*|busc\\w*|pesquis\\w*|peg(ar|ue|a))'
const NAO = [
  // o objeto da procura é algo pessoal ou uma pessoa ("buscar meu filho", "procurar minhas notas", "encontrar a Ana")
  new RegExp(`\\b${VERBO} (o |a |os |as )?(meu|minha|meus|minhas|seu|sua|seus|suas|nosso|nossa|dele|dela)\\b`),
  new RegExp(`\\b${VERBO} (o |a |os |as |um |uma )?(filh\\w*|crianc\\w*|mae|pai|esposa|marido|namorad\\w*|amig\\w*|alguem|pessoa\\w*|ele|ela|voce|vc)\\b`),
  // informação, conteúdo e trabalho
  /\b(no google|na internet|na web|no youtube|informac\w*|noticia\w*|significado|o que (e|significa)|receita de|como fazer|tutorial|videos?|musicas?|filmes?|series?|letra d\w*|emprego\w*|vaga\w* de|estagio|solucao|motivacao|sentido da)\b/,
  // recursos pessoais do app (lembretes, agenda, notas, finanças, histórico)
  /\b(lembr\w*|lembrete\w*|anot\w*|remarc\w*|desmarc\w*|compromisso\w*|tarefa\w*|historico|conversa\w*|mensage\w*|gastei|paguei|recebi|vendi|gasto\w*|despesa\w*|conta de|na lista|lista de compras|minha agenda|na agenda)\b/,
  /\b(aeroporto|rodoviaria|escola|creche|faculdade)\b/,
  // horário marcado: é compromisso/lembrete ("buscar a encomenda às 15h")
  /\b\d{1,2}(h|:\d{2})\b|\bas \d{1,2}\b/,
]
export interface Intencao { forte: boolean; consulta: string; rotulo: string; termos: string[]; maxPreco: number | null; ordem: 'relevancia' | 'menor' | 'perto'; ofertas: boolean; tipo: 'produto' | 'servico' | null }
/** Lê o pedido: limite de preço, ordem, só ofertas, tipo e os termos de busca (sem as palavras do pedido). */
export function lerConsulta(texto: string): Omit<Intencao, 'forte'> {
  let s = norm(texto)
  let maxPreco: number | null = null
  const mp = s.match(/\b(ate|abaixo de|menos de|no maximo|max|maximo)( r)?( \$)? ?(\d+(?: \d{1,2})?)( reais| real| rs)?\b/)
  if (mp) { maxPreco = Number(mp[4].replace(' ', '.')); s = s.replace(mp[0], ' ') }
  const ordem = /\b(mais barat\w*|menor preco|mais em conta|economic\w*)\b/.test(s) ? 'menor' : /\b(mais pert\w*|mais proxim\w*)\b/.test(s) ? 'perto' : 'relevancia'
  const ofertas = /\b(oferta\w*|promoc\w*|desconto\w*|liquidac\w*)\b/.test(s)
  const tipo = /\b(servico\w*|contratar|agendar|fazer (um|uma)|profissional)\b/.test(s) ? 'servico' : /\b(produto\w*|comprar|compro)\b/.test(s) ? 'produto' : null
  s = s.replace(/\b(mais barat\w*|menor preco|mais em conta|mais pert\w*|mais proxim\w*|oferta\w*|promoc\w*|desconto\w*|liquidac\w*|em conta)\b/g, ' ')
  s = s.replace(/\b(modo (de )?busca|me ajud[ae] a|pra mim|para mim|pra gente|perto de (mim|casa|aqui)|na minha regiao|por aqui|aqui perto|por favor|atras de|querendo comprar|precisando de)\b/g, ' ')
  const termos = [...new Set(toks(s))]
  return { consulta: termos.join(' '), rotulo: rotuloDe(texto, termos), termos, maxPreco, ordem: ordem as any, ofertas, tipo }
}
/** O que o usuário pediu, com as palavras dele (acentos e preposições internas): do primeiro ao último termo de busca,
 *  sem o pedido ("quero encontrar"), o preço e a ordem. Ex.: "Quero comprar bolo de chocolate até 50 reais" → "bolo de chocolate". */
export function rotuloDe(texto: string, termos: string[]) {
  const orig = String(texto || '').replace(/[?!.,;:"“”()]/g, ' ').split(/\s+/).filter(Boolean), set = new Set(termos)
  const ehTermo = (w: string) => { const n = norm(w); return !!n && !STOP.has(n) && set.has(radical(n)) }
  const i = orig.findIndex(ehTermo); if (i < 0) return termos.join(' ')
  let j = orig.length - 1; while (j > i && !ehTermo(orig[j])) j--
  return orig.slice(i, j + 1).join(' ').toLowerCase().slice(0, 60)
}
/** Intenção clara de procurar/comprar um produto ou serviço (null = conversa comum: o modo NÃO ativa). */
export function intencaoBusca(texto: string): Intencao | null {
  const s = norm(texto); if (!s || s.length > 220) return null
  if (NAO.some((re) => re.test(s))) return null
  const forte = FORTE.some((re) => re.test(s))
  if (!forte && !FRACO.test(s)) return null
  return { forte, ...lerConsulta(texto) }
}

/* ---------- correspondência e ranqueamento ---------- */
export interface ItemBusca { id: number; tipo: 'produto' | 'servico'; nome: string; categoria: string; descricao: string; palavras: string; variantes: string[]; preco: number | null; emOferta: boolean; disponivel: boolean; empresa: { nome: string; categoria: string; distancia: number | null; atende: boolean } }
const CAMPOS: [keyof ItemBusca | 'empresaNome' | 'empresaCat', number][] = [['nome', 1], ['palavras', 0.9], ['categoria', 0.75], ['variantes', 0.6], ['descricao', 0.5], ['empresaNome', 0.45], ['empresaCat', 0.35]]
const cacheTok = new WeakMap<object, Record<string, string[]>>()
function camposDe(it: ItemBusca) {
  let c = cacheTok.get(it); if (c) return c
  c = { nome: toks(it.nome), palavras: toks(it.palavras), categoria: toks(it.categoria), variantes: toks(it.variantes.join(' ')), descricao: toks(it.descricao), empresaNome: toks(it.empresa.nome), empresaCat: toks(it.empresa.categoria) }
  cacheTok.set(it, c); return c
}
export interface Pontos { score: number; cobertura: number; forteNoNome: boolean; corrigidas: Record<string, string> }
/** Nota do item para os termos: média do melhor casamento de cada termo (ponderado pelo campo) e quantos termos bateram. */
export function pontuar(it: ItemBusca, termos: string[]): Pontos {
  const c = camposDe(it); let soma = 0, bateu = 0, forteNoNome = false; const corrigidas: Record<string, string> = {}
  for (const q of termos) {
    let melhor = 0, campoMelhor = '', como = '', alvo = ''
    for (const [k, peso] of CAMPOS) for (const t of c[k as string] || []) { const m = casar(q, t); const v = m.v * peso; if (v > melhor) { melhor = v; campoMelhor = k as string; como = m.como; alvo = t } }
    soma += melhor; if (melhor >= 0.35) bateu++
    if (melhor >= 0.6 && ['nome', 'palavras', 'categoria'].includes(campoMelhor)) forteNoNome = true
    if (como === 'digitacao' && melhor >= 0.35) corrigidas[q] = alvo
  }
  const n = termos.length || 1
  // todos os termos no nome, em sequência: bônus (ex.: "bolo de chocolate" × "Bolo de chocolate com morango")
  const nomeN = c.nome.join(' '), seq = termos.length > 1 && nomeN.includes(termos.join(' ')) ? 0.15 : 0
  return { score: soma / n + seq, cobertura: bateu / n, forteNoNome, corrigidas }
}
export interface ResultadoBusca<T> { itens: T[]; semelhantes: T[]; corrigidas: Record<string, string>; total: number }
/** Ranqueia os itens publicados para a consulta. Exige que os termos batam (cobertura) e que algo bata no nome, palavras-chave ou categoria. */
export function buscar<T extends ItemBusca>(lista: T[], c: Pick<Intencao, 'termos' | 'maxPreco' | 'ordem' | 'ofertas' | 'tipo'>, limite = 6): ResultadoBusca<T> {
  const termos = c.termos.slice(0, 8); if (!termos.length) return { itens: [], semelhantes: [], corrigidas: {}, total: 0 }
  const minCob = termos.length <= 2 ? 1 : termos.length === 3 ? 0.66 : 0.6
  const av = lista.filter((it) => (c.maxPreco == null || (it.preco != null && it.preco <= c.maxPreco)) && (!c.ofertas || it.emOferta) && (!c.tipo || it.tipo === c.tipo || !lista.some((x) => x.tipo === c.tipo)))
    .map((it) => ({ it, p: pontuar(it, termos) }))
  const bons = av.filter((x) => x.p.cobertura >= minCob && x.p.forteNoNome && x.p.score >= 0.5)
  const peso = (x: { it: T; p: Pontos }) => x.p.score + (x.it.disponivel ? 0.25 : 0) + (x.it.empresa.atende ? 0.1 : 0)
  const dist = (x: { it: T }) => x.it.empresa.distancia ?? 1e9
  const ord = c.ordem === 'menor' ? (a: any, b: any) => (Number(b.it.disponivel) - Number(a.it.disponivel)) || ((a.it.preco ?? 1e9) - (b.it.preco ?? 1e9)) || peso(b) - peso(a)
    : c.ordem === 'perto' ? (a: any, b: any) => (Number(b.it.disponivel) - Number(a.it.disponivel)) || dist(a) - dist(b) || peso(b) - peso(a)
    : (a: any, b: any) => peso(b) - peso(a) || dist(a) - dist(b) || a.it.id - b.it.id
  bons.sort(ord)
  const corrigidas: Record<string, string> = {}; for (const x of bons.slice(0, limite)) Object.assign(corrigidas, x.p.corrigidas)
  // semelhantes: mesma categoria dos encontrados (ou batem em parte no nome), sem repetir
  const usados = new Set(bons.slice(0, limite).map((x) => x.it.id)), cats = new Set(bons.slice(0, 3).map((x) => norm(x.it.categoria)).filter(Boolean))
  const sem = av.filter((x) => !usados.has(x.it.id) && x.it.disponivel && ((cats.size && cats.has(norm(x.it.categoria)) && x.p.score > 0) || (x.p.forteNoNome && x.p.cobertura >= 0.5 && x.p.score >= 0.35)))
    .sort((a, b) => peso(b) - peso(a) || dist(a) - dist(b)).slice(0, bons.length >= 3 ? 0 : 3)
  if (!bons.length) for (const x of sem) Object.assign(corrigidas, x.p.corrigidas)
  return { itens: bons.slice(0, limite).map((x) => x.it), semelhantes: sem.map((x) => x.it), corrigidas, total: bons.length }
}
