// Endereço ⇄ coordenadas (OpenStreetMap/Nominatim). Opcional e "best effort": se o serviço estiver fora do ar,
// a empresa continua podendo digitar o endereço manualmente e salvar normalmente.
const base = () => (process.env.GEOCODER_URL || 'https://nominatim.openstreetmap.org').replace(/\/$/, '')
const H = { 'User-Agent': 'MeuAssistente/1.0 (contato pelo app)', 'Accept-Language': 'pt-BR' }
const get = async (path: string): Promise<any> => {
  const r = await fetch(base() + path, { headers: H, signal: AbortSignal.timeout(6000) }).catch(() => null)
  return r && r.ok ? await r.json().catch(() => null) : null
}
export const validCoords = (lat: number, lng: number) => Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

/** Endereço digitado → coordenadas. */
export async function geocodeAddress(text: string, min = 5): Promise<{ lat: number; lng: number; label: string } | null> {
  const t = String(text || '').trim(); if (t.length < min) return null
  const j = await get('/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(t))
  const r = Array.isArray(j) ? j[0] : null
  const lat = Number(r?.lat), lng = Number(r?.lon)
  return r && validCoords(lat, lng) ? { lat, lng, label: String(r.display_name || '') } : null
}
/** Coordenadas (localização automática) → endereço legível: "Rua X, 123, Bairro, Cidade - UF". */
export async function reverseGeocode(lat: number, lng: number): Promise<{ endereco: string } | null> {
  if (!validCoords(lat, lng)) return null
  const j = await get(`/reverse?format=jsonv2&addressdetails=1&zoom=18&lat=${lat}&lon=${lng}`)
  const a = j?.address; if (!j) return null
  const rua = a?.road || a?.pedestrian || a?.footway || '', cidade = a?.city || a?.town || a?.village || a?.municipality || ''
  const uf = String(a?.['ISO3166-2-lvl4'] || '').replace(/^BR-/, '') || ''
  const partes = [[rua, a?.house_number].filter(Boolean).join(', '), a?.suburb || a?.neighbourhood || '', cidade ? cidade + (uf ? ' - ' + uf : '') : ''].filter(Boolean)
  const endereco = (partes.length >= 2 ? partes.join(', ') : String(j.display_name || '').split(',').slice(0, 4).join(',')).trim().slice(0, 160)
  return endereco ? { endereco } : null
}
