// Endereço ⇄ coordenadas (OpenStreetMap/Nominatim). Opcional e "best effort": se o serviço estiver fora do ar,
// a empresa continua podendo digitar o endereço manualmente e salvar normalmente.
const base = () => (process.env.GEOCODER_URL || 'https://nominatim.openstreetmap.org').replace(/\/$/, '')
const H = { 'User-Agent': 'MeuAssistente/1.0 (contato pelo app)', 'Accept-Language': 'pt-BR' }
const get = async (path: string): Promise<any> => {
  const r = await fetch(base() + path, { headers: H, signal: AbortSignal.timeout(6000) }).catch(() => null)
  return r && r.ok ? await r.json().catch(() => null) : null
}
export const validCoords = (lat: number, lng: number) => Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

/** Endereço digitado → coordenadas. */
export async function geocodeAddress(text: string, min = 5): Promise<{ lat: number; lng: number; label: string } | null> {
  const t = String(text || '').trim(); if (t.length < min) return null
  const j = await get('/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(t))
  const r = Array.isArray(j) ? j[0] : null
  const lat = Number(r?.lat), lng = Number(r?.lon)
  return r && validCoords(lat, lng) ? { lat, lng, label: String(r.display_name || '') } : null
}
/** Partes de um endereço (para preencher formulários campo a campo). */
export interface PartesEndereco { rua: string; numero: string; bairro: string; cidade: string; uf: string; cep: string }
/** Coordenadas (localização automática) → endereço legível ("Rua X, 123, Bairro, Cidade - UF") e as partes separadas. */
export async function reverseGeocode(lat: number, lng: number): Promise<{ endereco: string; partes: PartesEndereco } | null> {
  if (!validCoords(lat, lng)) return null
  const j = await get(`/reverse?format=jsonv2&addressdetails=1&zoom=18&lat=${lat}&lon=${lng}`)
  const a = j?.address; if (!j || j.error) return null
  const c = (v: any) => String(v || '').trim().slice(0, 80)
  const partes: PartesEndereco = {
    rua: c(a?.road || a?.pedestrian || a?.footway || a?.residential || ''),
    numero: c(a?.house_number).slice(0, 12),
    bairro: c(a?.suburb || a?.neighbourhood || a?.quarter || a?.city_district || ''),
    cidade: c(a?.city || a?.town || a?.village || a?.municipality || ''),
    uf: (String(a?.['ISO3166-2-lvl4'] || '').match(/^BR-([A-Z]{2})$/) || [])[1] || '',
    cep: (String(a?.postcode || '').replace(/\D/g, '').match(/^\d{8}$/) || [''])[0].replace(/^(\d{5})(\d{3})$/, '$1-$2'),
  }
  const pp = [[partes.rua, partes.numero].filter(Boolean).join(', '), partes.bairro, partes.cidade ? partes.cidade + (partes.uf ? ' - ' + partes.uf : '') : ''].filter(Boolean)
  const endereco = (pp.length >= 2 ? pp.join(', ') : String(j.display_name || '').split(',').slice(0, 4).join(',')).trim().slice(0, 160)
  return endereco ? { endereco, partes } : null
}
