// Compartilhamento inteligente de produtos e serviços.
// • Cada item já tem uma URL pública e permanente: /x/empresa/:empresa?produto=:id (ou ?servico=:id), que abre o detalhe do
//   item no catálogo da empresa, sem conta, com imagens, preço, variações, oferta e disponibilidade de agora. O link compartilhado
//   ganha "&ref=share" (para contar visitas vindas de compartilhamento) e, quando há variação escolhida, "&v=:variação".
// • Mensagem pronta montada NO SERVIDOR com os dados atuais (nunca um preço antigo ou de outra variação). Modelos:
//   produto, serviço e oferta, definidos pelo administrador; regras por categoria; e textos próprios da empresa (opcionais).
//   Ordem: empresa → regra da categoria → modelo da plataforma. Ofertas usam sempre o modelo de oferta.
// • Variáveis: {produto} {empresa} {preco} {preco_normal} {desconto} {categoria} {link}. Trechos entre [colchetes] somem
//   quando alguma variável dentro deles não tem valor (ex.: serviço sob orçamento não tem preço).
import { q, one, nowIso, J } from '../db/index.js'
import { getConfig } from './settings.js'
import { createHash } from 'node:crypto'

export const VARIAVEIS = ['produto', 'empresa', 'preco', 'preco_normal', 'desconto', 'categoria', 'link'] as const
export const PADRAO = {
  ativo: true,
  produto: 'Olha só o que encontrei! 😍 {produto}[ por {preco}], na {empresa}. Pode ser exatamente o que você está procurando. Confira os detalhes e veja as opções disponíveis aqui: {link}',
  servico: 'Está pensando em fazer algo novo ou procurando um bom profissional? Conheça {produto}[ ({preco})], da {empresa}, e veja todos os detalhes: {link}',
  oferta: '🔥 Confira esta oferta da {empresa}!\n\n{produto} por apenas {preco}[ (de {preco_normal})].\n\nVeja fotos, detalhes e opções disponíveis: {link}',
  categorias: [] as { categoria: string; texto: string }[],
}
export const LIMITE = 500, MAX_REGRAS = 20
export const CANAIS = ['whatsapp', 'telegram', 'facebook', 'nativo', 'copiar_link', 'copiar_mensagem'] as const
const nrm = (t: any) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const brl = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')

export async function configPlataforma() {
  const c = await getConfig<any>('compartilhar', {})
  const txt = (k: 'produto' | 'servico' | 'oferta') => (typeof c[k] === 'string' && c[k].trim() ? c[k] : PADRAO[k])
  return { ativo: c.ativo !== false, produto: txt('produto'), servico: txt('servico'), oferta: txt('oferta'),
    categorias: Array.isArray(c.categorias) ? c.categorias.filter((r: any) => r && r.categoria && r.texto).slice(0, MAX_REGRAS) : [] }
}
/** Configuração da empresa (Sua empresa → Ajustes → Compartilhamento). Textos vazios = usar o modelo da plataforma. */
export const configEmpresa = (x: any) => { const c = x?.compartilhar || {}; const t = (k: string) => (typeof c[k] === 'string' ? c[k] : ''); return { ativo: c.ativo !== false, produto: t('produto'), servico: t('servico'), oferta: t('oferta') } }
export async function ativoPara(x: any) { return (await configPlataforma()).ativo && configEmpresa(x).ativo }

export function renderizar(tpl: string, vars: Partial<Record<(typeof VARIAVEIS)[number], string>>) {
  const val = (k: string) => String((vars as any)[k] ?? '').trim(), ok = (k: string) => (VARIAVEIS as readonly string[]).includes(k)
  const sub = (s: string) => s.replace(/\{(\w+)\}/g, (m, k) => (ok(k) ? val(k) : m))
  const out = String(tpl || '').replace(/\[([^\[\]]*)\]/g, (_, seg) => ([...seg.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter(ok).some((k) => !val(k)) ? '' : sub(seg)))
  return sub(out).replace(/[ \t]{2,}/g, ' ').replace(/ +([,.!?])/g, '$1').replace(/\n{3,}/g, '\n\n').trim()
}
/** Valida um modelo: tamanho, variáveis conhecidas e o {link} obrigatório (a mensagem sempre leva ao item). */
export function validarTexto(t: any, rotulo: string, obrigatorio = true) {
  const s = String(t ?? '').replace(/\r/g, '').trim()
  if (!s) { if (obrigatorio) throw Object.assign(new Error(`${rotulo}: escreva a mensagem.`), { campo: rotulo }); return '' }
  if (s.length > LIMITE) throw Object.assign(new Error(`${rotulo}: até ${LIMITE} caracteres.`), { campo: rotulo })
  const desc = [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).filter((k) => !(VARIAVEIS as readonly string[]).includes(k))
  if (desc.length) throw Object.assign(new Error(`${rotulo}: variável desconhecida {${desc[0]}}. Use ${VARIAVEIS.map((v) => `{${v}}`).join(', ')}.`), { campo: rotulo })
  if (!s.includes('{link}')) throw Object.assign(new Error(`${rotulo}: inclua {link}, para a mensagem levar ao item.`), { campo: rotulo })
  return s
}

/** Dados de AGORA do item (produto enriquecido pelo catálogo): preço do destaque ou da variação escolhida, oferta e disponibilidade. */
export function dadosDoItem(p: any, vid?: number | null) {
  const serv = p.tipo === 'servico'
  if (serv) {
    const orc = p.modoPreco === 'orcamento', pr = Number(p.preco) || 0
    return { serv, nome: p.nome, oferta: false, preco: orc || !pr ? '' : p.modoPreco === 'hora' ? brl(pr) + '/hora' : brl(pr), precoNormal: '', desconto: '', vid: null as number | null, rotulo: '' }
  }
  const v = vid ? (p.variantes || []).find((x: any) => Number(x.id) === Number(vid) && x.disponivel) : null
  if (v) return { serv, nome: `${p.nome} (${v.rotulo})`, oferta: !!v.emOferta, preco: brl(v.precoAplicado), precoNormal: v.emOferta ? brl(v.preco) : '', desconto: v.emOferta && v.desconto ? v.desconto + '%' : '', vid: Number(v.id), rotulo: v.rotulo }
  const d = p.destaque || {}, disp = !p.esgotado && d.preco > 0
  return { serv, nome: p.nome, oferta: disp && !!d.emOferta, preco: disp ? (d.aPartirDe ? 'a partir de ' : '') + brl(d.preco) : '', precoNormal: disp && d.emOferta ? brl(d.precoNormal) : '', desconto: disp && d.emOferta && d.desconto ? d.desconto + '%' : '', vid: null as number | null, rotulo: '' }
}
/** Qual modelo usar e a mensagem final. */
export async function mensagemDo(p: any, x: any, link: string, vid?: number | null) {
  const pl = await configPlataforma(), em = configEmpresa(x), d = dadosDoItem(p, vid)
  const chave = d.oferta ? 'oferta' : d.serv ? 'servico' : 'produto'
  const regra = chave === 'oferta' ? null : pl.categorias.find((r: any) => nrm(r.categoria) && nrm(p.categoria) && (nrm(p.categoria) === nrm(r.categoria) || nrm(p.categoria).includes(nrm(r.categoria))))
  const tpl = (em as any)[chave] || regra?.texto || (pl as any)[chave], origem = (em as any)[chave] ? 'empresa' : regra ? 'categoria' : 'plataforma'
  const vars = { produto: d.nome, empresa: String(x.empresa || ''), preco: d.preco, preco_normal: d.precoNormal, desconto: d.desconto, categoria: String(p.categoria || ''), link }
  return { mensagem: renderizar(tpl, vars), modelo: chave, origem, dados: d }
}

/* ---------- registro ---------- */
const viewerCode = (v: string) => createHash('sha256').update(new Date().toISOString().slice(0, 10) + ':' + v).digest('hex').slice(0, 16) // muda todo dia; não guarda IP nem conta
export async function registrar(e: { businessId: number; productId: number; tipoItem: 'produto' | 'servico'; kind: 'compartilhamento' | 'visita'; canal?: string; viewer: string }) {
  const vw = viewerCode(e.viewer), desde = new Date(Date.now() - (e.kind === 'visita' ? 86400_000 : 60_000)).toISOString()
  // visita: uma por pessoa, item e dia; compartilhamento: o mesmo canal repetido no mesmo minuto conta uma vez
  const rep = await one(`SELECT id FROM share_events WHERE product_id = $1 AND kind = $2 AND viewer = $3 AND channel = $4 AND created_at > $5 LIMIT 1`, [e.productId, e.kind, vw, e.canal || '', desde])
  if (rep) return false
  await q('INSERT INTO share_events (business_id, product_id, item_type, kind, channel, viewer, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [e.businessId, e.productId, e.tipoItem, e.kind, e.canal || '', vw, nowIso()])
  return true
}
/** Estatísticas (todas as empresas, ou uma). Nada de dados pessoais: só contagens por item, empresa, canal e dia. */
export async function estatisticas(businessId?: number | null, dias = 30) {
  const desde = new Date(Date.now() - dias * 86400_000).toISOString(), f = businessId ? ' AND business_id = $2' : '', ps = businessId ? [desde, businessId] : [desde]
  const ev = await q(`SELECT business_id, product_id, item_type, kind, channel, created_at FROM share_events WHERE created_at > $1${f}`, ps) as any[]
  const comp = ev.filter((r) => r.kind === 'compartilhamento'), vis = ev.filter((r) => r.kind === 'visita')
  const porCanal: Record<string, number> = {}; for (const r of comp) porCanal[r.channel] = (porCanal[r.channel] || 0) + 1
  const itens = new Map<number, any>(); for (const r of ev) { const k = Number(r.product_id); const it = itens.get(k) || { id: k, businessId: Number(r.business_id), tipo: r.item_type, compartilhamentos: 0, visitas: 0, ultimo: '' }; if (r.kind === 'visita') it.visitas++; else { it.compartilhamentos++; if (r.created_at > it.ultimo) it.ultimo = r.created_at } itens.set(k, it) }
  const ids = [...itens.keys()], bids = [...new Set([...itens.values()].map((i) => i.businessId))]
  const nomes = new Map<number, string>(), emps = new Map<number, string>()
  if (ids.length) for (const r of await q(`SELECT id, data FROM products WHERE id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids) as any[]) nomes.set(Number(r.id), String(J<any>(r.data, {}).nome || ''))
  if (bids.length) for (const r of await q(`SELECT id, data FROM businesses WHERE id IN (${bids.map((_, i) => '$' + (i + 1)).join(',')})`, bids) as any[]) emps.set(Number(r.id), String(J<any>(r.data, {}).empresa || ''))
  const lista = [...itens.values()].map((i) => ({ ...i, nome: nomes.get(i.id) || '(item removido)', empresa: emps.get(i.businessId) || '' })).sort((a, b) => b.compartilhamentos - a.compartilhamentos || b.visitas - a.visitas)
  const porEmpresa = bids.map((b) => ({ id: b, empresa: emps.get(b) || '', compartilhamentos: comp.filter((r) => Number(r.business_id) === b).length, visitas: vis.filter((r) => Number(r.business_id) === b).length })).sort((a, b) => b.compartilhamentos - a.compartilhamentos)
  return { dias, compartilhamentos: comp.length, visitas: vis.length, porCanal, itens: lista.slice(0, 30), porEmpresa: businessId ? [] : porEmpresa.slice(0, 30) }
}
