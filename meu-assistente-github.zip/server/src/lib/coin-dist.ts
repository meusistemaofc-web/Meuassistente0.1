// Enviar MCoins (administração): crédito em LOTE na carteira de vários usuários, usando a MESMA carteira (coin_balances) e o MESMO
// livro-razão (coin_ledger) das MCoins. Garantias:
//  • atômico: todos os créditos do lote (e o limite da emissão) numa única transação — ou todos entram, ou nenhum;
//  • idempotente: a chave da operação é única por moeda (coin_distributions) e cada crédito tem chave própria no livro-razão;
//  • o valor, o destinatário e o administrador vêm do servidor (o cliente só envia a intenção); permissão validada nas rotas;
//  • rastreável: operação (código, admin, motivo, data, status) + destinatários + linhas do livro-razão + auditoria.
import { q, one, db, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'
import { audit } from './account.js'
import { notify } from './notify.js'
import * as C from './coins.js'

const num = (v: any) => Number(v) || 0
export const MAX_DESTINATARIOS = 2000, MAX_POR_USUARIO = 100000
const IDEM = /^[A-Za-z0-9:_.-]{8,80}$/

export type Filtro = { q?: string }
/** Pesquisa de usuários ativos por nome, e-mail ou identificador. */
export async function buscarUsuarios(f: Filtro, limit = 30, offset = 0) {
  const s = String(f.q || '').trim().toLowerCase().slice(0, 80), like = `%${s.replace(/[%_\\]/g, '')}%`
  const where = s ? `WHERE status = 'active' AND (LOWER(name) LIKE $1 OR LOWER(email) LIKE $1 OR CAST(id AS TEXT) = $2)` : `WHERE status = 'active'`
  const args = s ? [like, s] : []
  const total = num((await one(`SELECT COUNT(*) AS n FROM users ${where}`, args))?.n)
  const rows = await q(`SELECT id, name, email FROM users ${where} ORDER BY id LIMIT ${Math.min(200, Math.max(1, Math.floor(limit)))} OFFSET ${Math.max(0, Math.floor(offset))}`, args)
  return { total, usuarios: rows.map((r: any) => ({ id: Number(r.id), nome: r.name, email: r.email })) }
}
async function resolver(b: any) {
  let ids: number[] = [], selecao: 'manual' | 'filtro' = 'manual', filtroTxt = ''
  if (b.filtro && typeof b.filtro === 'object') {
    selecao = 'filtro'; filtroTxt = String(b.filtro.q || '').trim().slice(0, 80)
    const t = (await buscarUsuarios({ q: filtroTxt }, 1, 0)).total; if (t > MAX_DESTINATARIOS) fail(400, `O filtro tem ${t} usuários; o máximo por operação é ${MAX_DESTINATARIOS}. Refine a busca.`, 'invalid', 'filtro')
    ids = (await q(`SELECT id FROM users WHERE status = 'active'${filtroTxt ? ` AND (LOWER(name) LIKE $1 OR LOWER(email) LIKE $1 OR CAST(id AS TEXT) = $2)` : ''} ORDER BY id`, filtroTxt ? [`%${filtroTxt.toLowerCase().replace(/[%_\\]/g, '')}%`, filtroTxt.toLowerCase()] : [])).map((r: any) => Number(r.id))
  } else {
    if (!Array.isArray(b.usuarios)) fail(400, 'Selecione os destinatários.', 'invalid', 'usuarios')
    ids = [...new Set((b.usuarios as any[]).map(Number).filter((n) => Number.isInteger(n) && n > 0))]
    if (ids.length > MAX_DESTINATARIOS) fail(400, `Máximo de ${MAX_DESTINATARIOS} destinatários por operação.`, 'invalid', 'usuarios')
  }
  if (!ids.length) fail(400, 'Nenhum destinatário selecionado.', 'invalid', 'usuarios')
  const ok = (await q(`SELECT id, name, email FROM users WHERE status = 'active' AND id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY id`, ids)) as any[]
  if (ok.length !== ids.length) fail(404, 'Algum destinatário não existe ou está desativado. Atualize a seleção.', 'not_found', 'usuarios')
  return { usuarios: ok.map((r) => ({ id: Number(r.id), nome: r.name as string, email: r.email as string })), selecao, filtroTxt }
}
function validar(b: any) {
  const quantidade = Number(b.quantidade); if (!Number.isInteger(quantidade) || quantidade < 1 || quantidade > MAX_POR_USUARIO) fail(400, `Informe uma quantidade inteira de 1 a ${MAX_POR_USUARIO} MCoins por usuário.`, 'invalid', 'quantidade')
  const motivo = String(b.motivo || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 200); if (motivo.length < 3) fail(400, 'Informe o motivo ou a justificativa da distribuição.', 'invalid', 'motivo')
  return { quantidade, motivo }
}
const opOut = (o: any) => ({ id: Number(o.id), codigo: o.op_code, moedaId: Number(o.coin_id), administradorId: Number(o.admin_id), administrador: o.admin_name || '', quantidadePorUsuario: num(o.qty_each), destinatarios: num(o.recipients), total: num(o.total), motivo: o.reason, selecao: o.selection, filtro: o.filter_text || '', status: o.status, em: isoOf(o.created_at) })

/** Prévia: nada é gravado. Mostra destinatários, total e o que resta da emissão. */
export async function previa(b: any) {
  const { quantidade, motivo } = validar(b), coin = await C.activeCoin(Number(b.moedaId)), r = await resolver(b), total = quantidade * r.usuarios.length
  const disp = Number(coin.disponiveis)
  const idemUsado = b.idem && IDEM.test(String(b.idem)) ? !!(await one('SELECT id FROM coin_distributions WHERE coin_id = $1 AND idem = $2', [coin.id, String(b.idem)])) : false
  return { moeda: { id: coin.id, nome: coin.nome, simbolo: coin.simbolo, disponivel: disp }, quantidadePorUsuario: quantidade, motivo, destinatarios: r.usuarios.length, total, selecao: r.selecao, lista: r.usuarios.slice(0, 200), listaCompleta: r.usuarios.length <= 200, suficiente: total <= disp, operacaoJaExecutada: idemUsado }
}

/** Execução: tudo ou nada. Repetir a mesma chave devolve a operação original sem creditar de novo. */
export async function enviar(admin: { id: number; name: string }, b: any) {
  const idem = String(b.idem || '').trim(); if (!IDEM.test(idem)) fail(400, 'Chave da operação inválida (8 a 80 caracteres: letras, números, : _ . -).', 'invalid', 'idem')
  const { quantidade, motivo } = validar(b), coin = await C.activeCoin(Number(b.moedaId))
  const ja = await one('SELECT * FROM coin_distributions WHERE coin_id = $1 AND idem = $2', [coin.id, idem]); if (ja) return { ok: true, duplicado: true, operacao: opOut(ja) }
  if (b.confirmar !== true) fail(400, 'Confirme a operação após revisar os destinatários e o total.', 'invalid', 'confirmar')
  const r = await resolver(b), total = quantidade * r.usuarios.length
  if (b.esperado && (num(b.esperado.destinatarios) !== r.usuarios.length || num(b.esperado.total) !== total)) fail(409, 'A lista de destinatários mudou desde a prévia. Revise e confirme novamente.', 'mudou')
  const codigo = 'MCD-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase()
  try {
    const op = await withLock(`coin:${coin.id}`, async () => {
      const dup = await one('SELECT * FROM coin_distributions WHERE coin_id = $1 AND idem = $2', [coin.id, idem]); if (dup) return { dup }
      return db().tx(async (t) => {
        const now = nowIso()
        const lim = await t.query('UPDATE coins SET distributed = distributed + $1, updated_at = $3 WHERE id = $2 AND distributed + $1 <= total_supply RETURNING id', [total, coin.id, now]); if (!lim.length) fail(409, 'Não há MCoins disponíveis na emissão para esta distribuição (quantidade total esgotada). Nada foi creditado.', 'sem_estoque')
        await t.query('INSERT INTO coin_distributions (op_code, coin_id, admin_id, admin_name, idem, qty_each, recipients, total, reason, selection, filter_text, status, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)', [codigo, coin.id, admin.id, admin.name, idem, quantidade, r.usuarios.length, total, motivo, r.selecao, r.filtroTxt || null, 'concluida', now])
        const opId = Number((await t.query('SELECT id FROM coin_distributions WHERE op_code = $1', [codigo]))[0].id)
        for (const u of r.usuarios) {
          await t.query('INSERT INTO coin_balances (coin_id, user_id, balance, updated_at) VALUES ($1,$2,0,$3) ON CONFLICT (coin_id, user_id) DO NOTHING', [coin.id, u.id, now])
          await t.query('UPDATE coin_balances SET balance = balance + $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3', [quantidade, coin.id, u.id, now])
          const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coin.id, u.id]))[0]?.balance)
          await t.query('INSERT INTO coin_ledger (coin_id, user_id, kind, delta, balance_after, order_id, idem, actor, note, discount, created_at, issuer_business_id, linked_business_id) VALUES ($1,$2,$3,$4,$5,NULL,$6,$7,$8,NULL,$9,(SELECT business_id FROM coins WHERE id = $1),NULL)', [coin.id, u.id, 'distribuicao', quantidade, saldo, `lote:${opId}:${u.id}`, `admin ${admin.id}`, motivo, now])
          const lid = Number((await t.query('SELECT id FROM coin_ledger WHERE coin_id = $1 AND idem = $2', [coin.id, `lote:${opId}:${u.id}`]))[0].id)
          await t.query('INSERT INTO coin_distribution_items (distribution_id, user_id, quantity, ledger_id) VALUES ($1,$2,$3,$4)', [opId, u.id, quantidade, lid])
        }
        return { op: (await t.query('SELECT * FROM coin_distributions WHERE id = $1', [opId]))[0] }
      })
    })
    if ('dup' in op && op.dup) return { ok: true, duplicado: true, operacao: opOut(op.dup) }
    const o = (op as any).op
    await audit(admin.id, 'coins.enviar', Number(coin.id), { operacao: codigo, destinatarios: r.usuarios.length, quantidadePorUsuario: quantidade, total, motivo, selecao: r.selecao })
    // avisos fora da transação (falha de aviso nunca desfaz o crédito já gravado)
    for (const u of r.usuarios) { try { await notify(u.id, { type: 'coin', title: `Você recebeu ${quantidade} ${coin.simbolo}`, body: `${coin.empresa || coin.nome} · Motivo: ${motivo}`, link: '/x/carteira', ref: `coin-lote:${codigo}:${u.id}` }) } catch { /* segue */ } }
    return { ok: true, duplicado: false, operacao: opOut(o) }
  } catch (e: any) {
    try { await audit(admin.id, 'coins.enviar.falha', Number(coin.id), { operacao: codigo, erro: String(e?.message || e).slice(0, 200), destinatarios: r.usuarios.length, total }) } catch { /* segue */ }
    throw e
  }
}

/** Histórico administrativo das distribuições. */
export async function historico(limit = 100, coinId?: number) {
  const rows = await q(`SELECT d.*, c.name AS coin_name, c.symbol AS coin_symbol FROM coin_distributions d LEFT JOIN coins c ON c.id = d.coin_id ${coinId ? 'WHERE d.coin_id = $1' : ''} ORDER BY d.id DESC LIMIT ${Math.min(500, Math.max(1, Math.floor(limit)))}`, coinId ? [coinId] : []) as any[]
  return rows.map((o) => ({ ...opOut(o), moeda: o.coin_name || '', simbolo: o.coin_symbol || '' }))
}
export async function detalhe(id: number) {
  const o = await one('SELECT d.*, c.name AS coin_name, c.symbol AS coin_symbol FROM coin_distributions d LEFT JOIN coins c ON c.id = d.coin_id WHERE d.id = $1', [id]); if (!o) fail(404, 'Operação não encontrada.', 'not_found')
  const it = await q('SELECT i.user_id, i.quantity, i.ledger_id, u.name, u.email, l.balance_after FROM coin_distribution_items i LEFT JOIN users u ON u.id = i.user_id LEFT JOIN coin_ledger l ON l.id = i.ledger_id WHERE i.distribution_id = $1 ORDER BY i.user_id', [id]) as any[]
  return { operacao: { ...opOut(o), moeda: (o as any).coin_name || '', simbolo: (o as any).coin_symbol || '' }, destinatarios: it.map((r) => ({ usuarioId: Number(r.user_id), nome: r.name || '', email: r.email || '', quantidade: num(r.quantity), saldoApos: num(r.balance_after), movimentacao: r.ledger_id ? Number(r.ledger_id) : null })) }
}

/* ---------- lado do usuário: créditos novos (comemorar uma única vez) ---------- */
export async function novas(userId: number) {
  const rows = await q("SELECT l.id, l.coin_id, l.kind, l.delta, l.balance_after, l.note, l.created_at FROM coin_ledger l WHERE l.user_id = $1 AND l.seen_at IS NULL AND l.delta > 0 AND l.kind IN ('distribuicao','adesao') ORDER BY l.id LIMIT 20", [userId]) as any[]
  const out = []; for (const r of rows) { const c = await C.coinById(Number(r.coin_id)); out.push({ id: Number(r.id), moedaId: Number(r.coin_id), simbolo: c?.simbolo || '', nome: c?.nome || '', empresa: c?.empresa || '', modelo: c?.modeloInfo || null, cor1: c?.cor1, cor2: c?.cor2, logo: c?.logo || null, tipo: r.kind, quantidade: num(r.delta), saldoApos: num(r.balance_after), motivo: r.note || '', em: isoOf(r.created_at) }) }
  return out
}
export async function marcarVistas(userId: number, ids: any) {
  const l = (Array.isArray(ids) ? ids : []).map(Number).filter((n) => Number.isInteger(n) && n > 0).slice(0, 50); if (!l.length) return { ok: true, marcadas: 0 }
  await q(`UPDATE coin_ledger SET seen_at = $1 WHERE user_id = $2 AND seen_at IS NULL AND id IN (${l.map((_, i) => '$' + (i + 3)).join(',')})`, [nowIso(), userId, ...l])
  return { ok: true, marcadas: l.length }
}
