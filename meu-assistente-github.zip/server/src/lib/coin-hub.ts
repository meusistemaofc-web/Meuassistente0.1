// Meu Assistente como empresa EMISSORA e INTEGRADORA das MCoins.
// • "Meu Assistente" é uma empresa institucional da plataforma (linha em `businesses` com status 'institucional': nunca aparece em
//   buscas, catálogo, Mercado de anúncios nem em "Minhas empresas"), criada uma única vez e selecionável ao criar/configurar uma moeda.
// • A moeda dela pode ser VINCULADA a qualquer número de empresas ao mesmo tempo (tabela coin_links), cada vínculo com as suas regras
//   (desconto por moeda, % máximo do pedido, compra mínima). A empresa reconhece e aceita o vínculo; o administrador gerencia tudo.
// • Cada movimentação guarda a emissora e a vinculada (coin_ledger). Nada aqui altera as moedas, saldos e históricos já existentes.
import { q, one, J, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'
import * as C from './coins.js'

export const NOME_INSTITUCIONAL = 'Meu Assistente'
const num = (v: any) => Number(v) || 0
const txt = (v: any, n: number) => String(v ?? '').trim().slice(0, n)

export async function institucionalId(): Promise<number | null> {
  for (const r of await q("SELECT id, data FROM businesses WHERE status = 'institucional' ORDER BY id LIMIT 5")) if (J<any>(r.data, {}).institucional === true) return Number(r.id)
  return null
}
export async function ensureInstitucional(adminId: number): Promise<number> {
  return withLock('coin:institucional', async () => {
    const ex = await institucionalId(); if (ex) return ex
    const now = nowIso(), data = { empresa: NOME_INSTITUCIONAL, categoria: 'Plataforma', titulo: NOME_INSTITUCIONAL, texto: 'Empresa institucional da plataforma: emite e integra as MCoins.', institucional: true, tipo: 'servicos' }
    const r = await q("INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, created_at, updated_at) VALUES ($1,$2,'institucional','institucional',$3,$4,$4) RETURNING id", [adminId, 'MA-INSTITUCIONAL', JSON.stringify(data), now])
    return Number(r[0].id)
  })
}

/* ---------- vínculos ---------- */
export type VinculoStatus = 'pendente' | 'ativo' | 'pausado' | 'recusado' | 'revogado'
const out = (r: any, empresa = '') => ({ id: Number(r.id), moedaId: Number(r.coin_id), empresaId: Number(r.business_id), empresa, status: r.status as VinculoStatus, desconto: r.discount_value == null ? null : num(r.discount_value), maxPct: num(r.max_pct), minCompra: num(r.min_purchase), regras: r.rules || '', pausadoPor: r.paused_by || '', aceitoEm: r.accepted_at ? isoOf(r.accepted_at) : null, criadoEm: isoOf(r.created_at), atualizadoEm: isoOf(r.updated_at) })
async function evento(l: any, action: string, actor: string, detail = '') { await q('INSERT INTO coin_link_events (link_id, coin_id, business_id, action, actor, detail, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [l.id, l.coin_id, l.business_id, action, actor, detail.slice(0, 300), nowIso()]) }
async function coinInst(coinId: number) {
  const c: any = await C.coinById(coinId); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  if (!c.institucional) fail(400, 'Só a moeda do Meu Assistente pode ser vinculada a outras empresas.', 'invalid'); return c
}
const limites = (b: any, cur?: any) => {
  const n = (v: any, d: number, min: number, max: number) => { if (v === undefined || v === null || v === '') return d; const x = Number(v); if (!isFinite(x) || x < min || x > max) fail(400, 'Valor inválido na regra do vínculo.', 'invalid'); return x }
  return { desconto: b.desconto === undefined ? (cur ? cur.discount_value : null) : (b.desconto === null || b.desconto === '' ? null : n(b.desconto, 0, 0.0001, 1e6)),
    maxPct: n(b.maxPct, cur ? num(cur.max_pct) : 100, 1, 100), minCompra: n(b.minCompra, cur ? num(cur.min_purchase) : 0, 0, 1e6), regras: b.regras === undefined ? (cur ? cur.rules : '') : txt(b.regras, 300) }
}
export async function vinculos(coinId: number) {
  const rows = await q('SELECT * FROM coin_links WHERE coin_id = $1 ORDER BY id DESC', [coinId]); const nomes = await C.nomesEmpresas(rows.map((r: any) => r.business_id))
  return rows.map((r: any) => out(r, nomes[Number(r.business_id)] || ''))
}
/** Cria vínculos com uma, várias ou TODAS as empresas ativas. Reabre vínculos recusados/revogados. */
export async function criarVinculos(coinId: number, empresas: number[] | 'todas', o: any, actor: string, adminId: number) {
  const c = await coinInst(coinId), lim = limites(o)
  let ids: number[]
  if (empresas === 'todas') ids = (await q("SELECT id FROM businesses WHERE status = 'ativo'")).map((r: any) => Number(r.id))
  else ids = [...new Set((Array.isArray(empresas) ? empresas : []).map(Number).filter((n) => n > 0))]
  if (!ids.length) fail(400, 'Escolha ao menos uma empresa.', 'invalid', 'empresas')
  const criados: number[] = [], ja: number[] = []
  for (const bid of ids) {
    const b = await one('SELECT id, owner_id, status, data FROM businesses WHERE id = $1', [bid]); if (!b) fail(404, `Empresa #${bid} não encontrada.`, 'not_found')
    if (b!.status === 'institucional' || Number(b!.id) === c.businessId) continue
    const status = o.aceiteAutomatico === true ? 'ativo' : 'pendente', now = nowIso()
    const ex: any = await one('SELECT * FROM coin_links WHERE coin_id = $1 AND business_id = $2', [coinId, bid])
    if (ex && ['pendente', 'ativo', 'pausado'].includes(ex.status)) { ja.push(bid); continue }
    let id: number
    if (ex) { await q('UPDATE coin_links SET status = $1, discount_value = $2, max_pct = $3, min_purchase = $4, rules = $5, paused_by = NULL, accepted_at = $6, updated_at = $7 WHERE id = $8', [status, lim.desconto, lim.maxPct, lim.minCompra, lim.regras, status === 'ativo' ? now : null, now, ex.id]); id = Number(ex.id) }
    else id = Number((await q('INSERT INTO coin_links (coin_id, business_id, status, discount_value, max_pct, min_purchase, rules, accepted_at, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10) RETURNING id', [coinId, bid, status, lim.desconto, lim.maxPct, lim.minCompra, lim.regras, status === 'ativo' ? now : null, adminId, now]))[0].id)
    await evento({ id, coin_id: coinId, business_id: bid }, 'criado', actor, o.aceiteAutomatico === true ? 'ativo (aceite automático autorizado pelo administrador)' : 'aguardando aceite da empresa')
    criados.push(bid)
    if (status === 'pendente') try { await (await import('./notify.js')).notify(Number(b!.owner_id), { type: 'coin', title: `${NOME_INSTITUCIONAL} convidou ${J<any>(b!.data, {}).empresa || 'sua empresa'} para aceitar a ${c.nome} (${c.simbolo})`, body: 'Abra Sua empresa → Ajustes → MCoins do Meu Assistente para aceitar ou recusar.', link: '/x/sua-empresa', ref: `coin-link:${id}:${now}` } as any) } catch { /* aviso é apoio */ }
  }
  return { criados, jaVinculadas: ja, vinculos: await vinculos(coinId) }
}
export async function ajustarVinculo(id: number, b: any, actor: string) {
  const l: any = await one('SELECT * FROM coin_links WHERE id = $1', [id]); if (!l) fail(404, 'Vínculo não encontrado.', 'not_found')
  const lim = limites(b, l), sets: string[] = [], vals: any[] = [], log: string[] = []
  const set = (c: string, v: any) => { sets.push(`${c} = $${vals.length + 1}`); vals.push(v) }
  if (b.desconto !== undefined || b.maxPct !== undefined || b.minCompra !== undefined || b.regras !== undefined) { set('discount_value', lim.desconto); set('max_pct', lim.maxPct); set('min_purchase', lim.minCompra); set('rules', lim.regras); log.push(`regras: desconto ${lim.desconto ?? 'da moeda'}, até ${lim.maxPct}%, mínimo R$ ${lim.minCompra}`) }
  if (b.status !== undefined) {
    const to = String(b.status)
    if (to === 'ativo') { if (l.status === 'pendente' || l.status === 'recusado') fail(409, 'A empresa ainda não aceitou este vínculo.', 'invalid'); if (l.status === 'revogado') fail(409, 'Vínculo revogado: crie-o novamente.', 'invalid'); if (l.status === 'pausado' && l.paused_by === 'empresa') fail(409, 'A própria empresa pausou o vínculo; só ela pode retomar.', 'invalid') }
    else if (to === 'pausado') { if (l.status !== 'ativo') fail(409, 'Só vínculos ativos podem ser pausados.', 'invalid') }
    else if (to !== 'revogado') fail(400, 'Situação inválida.', 'invalid')
    set('status', to); set('paused_by', to === 'pausado' ? 'admin' : null); log.push(`situação: ${l.status} → ${to}`)
  }
  if (!sets.length) return out(l)
  set('updated_at', nowIso()); vals.push(id)
  await q(`UPDATE coin_links SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals); await evento(l, 'ajustado', actor, log.join('; '))
  return out(await one('SELECT * FROM coin_links WHERE id = $1', [id]))
}
/** A própria empresa reconhece e aceita (ou recusa, pausa, retoma) o vínculo. */
export async function responder(userId: number, linkId: number, acao: string) {
  const l: any = await one('SELECT l.*, b.owner_id FROM coin_links l JOIN businesses b ON b.id = l.business_id WHERE l.id = $1', [linkId])
  if (!l || Number(l.owner_id) !== userId) fail(404, 'Vínculo não encontrado.', 'not_found')
  const now = nowIso(); let to = '', extra = ''
  if (acao === 'aceitar' && l.status === 'pendente') { to = 'ativo'; extra = ', accepted_at = $4' }
  else if (acao === 'recusar' && l.status === 'pendente') to = 'recusado'
  else if (acao === 'pausar' && l.status === 'ativo') to = 'pausado'
  else if (acao === 'retomar' && l.status === 'pausado' && l.paused_by === 'empresa') to = 'ativo'
  else fail(409, 'Esta ação não é possível na situação atual do vínculo.', 'invalid')
  await q(`UPDATE coin_links SET status = $1, paused_by = $2, updated_at = $3${extra} WHERE id = $${extra ? 5 : 4}`, extra ? [to, to === 'pausado' ? 'empresa' : null, now, now, linkId] : [to, to === 'pausado' ? 'empresa' : null, now, linkId])
  await evento(l, acao, `empresa (usuário ${userId})`, `${l.status} → ${to}`)
  return out(await one('SELECT * FROM coin_links WHERE id = $1', [linkId]))
}
/** Vínculos recebidos por uma empresa (para o dono responder) com os dados da moeda. */
export async function vinculosDaEmpresa(businessId: number) {
  const rows = await q('SELECT * FROM coin_links WHERE business_id = $1 ORDER BY id DESC', [businessId]); const res = []
  for (const r of rows as any[]) { const c = await C.coinById(Number(r.coin_id)); if (c) res.push({ ...out(r, c.empresa), moeda: { id: c.id, nome: c.nome, simbolo: c.simbolo, descontoPadrao: c.desconto, status: c.status, modelo: c.modeloInfo, cor1: c.cor1, cor2: c.cor2, logo: c.logo, emissora: c.empresa } }) }
  return res
}

/** Moedas de outras emissoras que a empresa aceita AGORA (vínculo ativo, moeda ativa, sistema ligado) com as regras de uso. */
export async function aceitas(businessId: number) {
  if (!(await C.coinsCfg()).ativo) return []
  const rows = await q("SELECT * FROM coin_links WHERE business_id = $1 AND status = 'ativo'", [businessId]); const res = []
  for (const r of rows as any[]) { const c: any = await C.coinById(Number(r.coin_id)); if (!c || c.status !== 'ativa') continue; res.push({ coin: c, linkId: Number(r.id), desconto: r.discount_value == null ? c.desconto : num(r.discount_value), maxPct: num(r.max_pct), minCompra: num(r.min_purchase), regras: r.rules || '' }) }
  return res
}
export async function aceita(businessId: number, coinId: number) { return (await aceitas(businessId)).find((a) => a.coin.id === coinId) || null }

/* ---------- gestão central (visão do administrador) ---------- */
export async function resumo() {
  const iid = await institucionalId(); const coin = iid ? await C.coinOfBusiness(iid) : null
  if (!coin) return { criada: !!iid, empresaId: iid, moeda: null, vinculos: [], movimentos: [], totais: { vinculos: 0, ativos: 0, pendentes: 0, usos: 0, moedasUsadas: 0, descontoReais: 0 } }
  const vs = await vinculos(coin.id)
  const uso = await q("SELECT linked_business_id AS b, kind, COUNT(*) AS n, COALESCE(SUM(delta),0) AS d, COALESCE(SUM(discount),0) AS dsc FROM coin_ledger WHERE coin_id = $1 AND kind IN ('resgate','estorno') GROUP BY linked_business_id, kind", [coin.id])
  const porEmpresa = new Map<number, { moedas: number; desconto: number; usos: number }>()
  for (const r of uso as any[]) { const k = Number(r.b), x = porEmpresa.get(k) || { moedas: 0, desconto: 0, usos: 0 }; const sinal = r.kind === 'estorno' ? -1 : 1; x.moedas += sinal * Math.abs(num(r.d)); x.desconto += sinal * num(r.dsc); x.usos += sinal * num(r.n); porEmpresa.set(k, x) }
  const itens = vs.map((v) => ({ ...v, uso: { moedas: porEmpresa.get(v.empresaId)?.moedas || 0, desconto: Math.round((porEmpresa.get(v.empresaId)?.desconto || 0) * 100) / 100, usos: porEmpresa.get(v.empresaId)?.usos || 0 } }))
  const mov = await C.ledger(coin.id, 100)
  return { criada: true, empresaId: iid, moeda: await C.stats(coin.id), vinculos: itens, movimentos: mov,
    totais: { vinculos: vs.length, ativos: vs.filter((v) => v.status === 'ativo').length, pendentes: vs.filter((v) => v.status === 'pendente').length, usos: itens.reduce((a, v) => a + v.uso.usos, 0), moedasUsadas: itens.reduce((a, v) => a + v.uso.moedas, 0), descontoReais: Math.round(itens.reduce((a, v) => a + v.uso.desconto, 0) * 100) / 100 } }
}
export async function eventosDoVinculo(linkId: number) { return (await q('SELECT action, actor, detail, created_at FROM coin_link_events WHERE link_id = $1 ORDER BY id DESC LIMIT 100', [linkId])).map((r: any) => ({ acao: r.action, quem: r.actor || '', detalhe: r.detail || '', em: isoOf(r.created_at) })) }
