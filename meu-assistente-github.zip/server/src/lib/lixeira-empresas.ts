// Lixeira de empresas.
// • Excluir empresa (só o dono): a empresa sai do ar na hora (catálogo, busca, marketplace, agente, painel e central de lojas
//   deixam de mostrá-la) e vai para a lixeira por 30 dias, com a situação anterior guardada. Nada é apagado ainda.
// • Restaurar (até 30 dias): volta exatamente como estava (mesma situação, produtos, pedidos, configurações e validade do anúncio).
// • Depois de 30 dias a exclusão é definitiva e automática (tarefa periódica); o dono também pode excluir definitivamente antes.
// • Tudo fica na auditoria.
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'

export const DIAS_LIXEIRA = 30
const DIA = 86400_000
const audit = async (uid: number | null, acao: string, alvo: any, meta: any) => { try { await (await import('./account.js')).audit(uid as any, acao, alvo, meta) } catch (e: any) { console.error('[lixeira]', e?.message) } }
const nome = (b: any) => String(J<any>(b?.data, {}).empresa || `Empresa #${b?.id}`)
const expiraEm = (b: any) => new Date(Date.parse(String(b.deleted_at)) + DIAS_LIXEIRA * DIA).toISOString()

export async function excluir(userId: number, id: number, confirmar: any) {
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [id, userId])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  if (b!.status === 'lixeira') fail(409, 'Esta empresa já está na lixeira.', 'ja_na_lixeira')
  if (b!.status === 'institucional') fail(403, 'Esta empresa não pode ser excluída.', 'forbidden')
  if (confirmar !== true) fail(400, 'Confirme a exclusão.', 'confirmar')
  const d = J<any>(b!.data, {}), agora = nowIso()
  d.lixeira = { statusAnterior: b!.status, em: agora, por: userId }
  const r = await q("UPDATE businesses SET status = 'lixeira', deleted_at = $1, data = $2, updated_at = $1 WHERE id = $3 AND status <> 'lixeira' RETURNING id", [agora, JSON.stringify(d), id])
  if (!r.length) fail(409, 'Esta empresa já está na lixeira.', 'ja_na_lixeira')
  await audit(userId, 'empresa.lixeira.excluir', id, { empresa: nome(b), statusAnterior: b!.status })
  return { id, empresa: nome(b), excluidaEm: agora, expiraEm: new Date(Date.parse(agora) + DIAS_LIXEIRA * DIA).toISOString(), dias: DIAS_LIXEIRA }
}
export async function listar(userId: number) {
  const rows = await q("SELECT * FROM businesses WHERE owner_id = $1 AND status = 'lixeira' ORDER BY deleted_at DESC", [userId]) as any[]
  return rows.map((b) => { const d = J<any>(b.data, {}), exp = expiraEm(b), resta = Math.max(0, Math.ceil((Date.parse(exp) - Date.now()) / DIA))
    return { id: Number(b.id), empresa: d.empresa || '', logo: d.logo || null, categoria: d.categoria || '', excluidaEm: b.deleted_at, expiraEm: exp, diasRestantes: resta, statusAnterior: d.lixeira?.statusAnterior || 'ativo' } })
}
export async function restaurar(userId: number, id: number) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND owner_id = $2 AND status = 'lixeira'", [id, userId])
  if (!b) fail(404, 'Empresa não encontrada na lixeira.', 'not_found')
  if (Date.parse(expiraEm(b)) <= Date.now()) fail(410, 'O prazo de 30 dias terminou: esta empresa será excluída definitivamente.', 'expirada')
  const d = J<any>(b!.data, {}), volta = String(d.lixeira?.statusAnterior || 'ativo'); delete d.lixeira
  const r = await q("UPDATE businesses SET status = $1, deleted_at = NULL, data = $2, updated_at = $3 WHERE id = $4 AND status = 'lixeira' RETURNING id", [volta, JSON.stringify(d), nowIso(), id])
  if (!r.length) fail(409, 'Esta empresa não está mais na lixeira.', 'conflito')
  await audit(userId, 'empresa.lixeira.restaurar', id, { empresa: nome(b), status: volta })
  return { id, empresa: nome(b), status: volta }
}
/** Exclusão definitiva: apaga a empresa e o que pertence a ela (produtos, pedidos, configurações…), como a exclusão de anúncio. */
async function apagar(b: any, motivo: string, actor: number | null) {
  try { const VC = await import('./vouchers.js'); const rsv = await VC.reservaDo(Number(b.id)); if (rsv) await VC.liberar(Number(rsv.id), 'empresa excluída', motivo) } catch { /* sem cupom reservado */ }
  const r = await q("DELETE FROM businesses WHERE id = $1 AND status = 'lixeira' RETURNING id", [b.id])
  if (r.length) await audit(actor, 'empresa.lixeira.excluir_definitivo', Number(b.id), { empresa: nome(b), motivo })
  return r.length > 0
}
export async function excluirDefinitivo(userId: number, id: number, confirmar: any) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND owner_id = $2 AND status = 'lixeira'", [id, userId])
  if (!b) fail(404, 'Empresa não encontrada na lixeira.', 'not_found')
  if (confirmar !== true) fail(400, 'Confirme a exclusão definitiva.', 'confirmar')
  await apagar(b, 'pelo dono', userId); return { ok: true }
}
/** Tarefa periódica: o que passou de 30 dias na lixeira é excluído definitivamente. */
export async function limparVencidas(agora = Date.now()) {
  const limite = new Date(agora - DIAS_LIXEIRA * DIA).toISOString()
  const rows = await q("SELECT * FROM businesses WHERE status = 'lixeira' AND deleted_at IS NOT NULL AND deleted_at <= $1", [limite]) as any[]
  let n = 0; for (const b of rows) if (await apagar(b, `${DIAS_LIXEIRA} dias na lixeira`, null)) n++
  return n
}
