// Moedas digitais de bônus por empresa: crédito promocional FECHADO (sem negociação, saque ou transferência).
// Regras de ouro: saldo nunca negativo (UPDATE condicional + CHECK no banco), nada se distribui duas vezes (chave de
// idempotência única por moeda), toda movimentação e toda alteração de valor ficam registradas, e cada empresa tem
// a sua moeda e os seus saldos (coin_id nunca se mistura).
import { q, one, db, J, nowIso, isoOf } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'

/* ---------- biblioteca de modelos visuais (o desenho é feito no front com estes parâmetros) ---------- */
export interface Modelo { id: string; nome: string; estilo: string; forma: 'redonda' | 'hexagono' | 'octogono' | 'escudo'; acabamento: 'metalico' | 'brilho' | 'fosco' | 'neon' | 'minimal' | 'corporativo'; c1: string; c2: string; borda: string; texto: string; usaLogo?: boolean }
export const MODELOS: Modelo[] = [
  { id: 'dourada', nome: 'Dourada premium', estilo: 'Metal dourado com brilho', forma: 'redonda', acabamento: 'metalico', c1: '#f7d56a', c2: '#b8860b', borda: '#fff1b8', texto: '#5a3c00' },
  { id: 'prateada', nome: 'Prateada', estilo: 'Metal prata polido', forma: 'redonda', acabamento: 'metalico', c1: '#f1f5f9', c2: '#8793a6', borda: '#ffffff', texto: '#2b3442' },
  { id: 'azul', nome: 'Azul tecnológica', estilo: 'Hexágono digital', forma: 'hexagono', acabamento: 'brilho', c1: '#5aa2ff', c2: '#0b2a6b', borda: '#a9d0ff', texto: '#ffffff' },
  { id: 'verde', nome: 'Verde de recompensas', estilo: 'Brilho de prêmio', forma: 'redonda', acabamento: 'brilho', c1: '#4ade80', c2: '#0b5d2a', borda: '#c4f5d3', texto: '#ffffff' },
  { id: 'preta', nome: 'Preta sofisticada', estilo: 'Fosco com friso dourado', forma: 'octogono', acabamento: 'fosco', c1: '#3a3a3f', c2: '#08080a', borda: '#d4af37', texto: '#d4af37' },
  { id: 'roxa', nome: 'Roxa futurista', estilo: 'Neon espacial', forma: 'hexagono', acabamento: 'neon', c1: '#c084fc', c2: '#3b0a6b', borda: '#e9c9ff', texto: '#ffffff' },
  { id: 'metalica', nome: 'Efeito metálico', estilo: 'Bronze escovado', forma: 'escudo', acabamento: 'metalico', c1: '#f0b27a', c2: '#7a3f18', borda: '#ffe0c2', texto: '#3d1d08' },
  { id: 'minimalista', nome: 'Minimalista', estilo: 'Contorno limpo', forma: 'redonda', acabamento: 'minimal', c1: '#ffffff', c2: '#e5e7eb', borda: '#111827', texto: '#111827' },
  { id: 'simbolo', nome: 'Símbolo personalizado', estilo: 'Símbolo grande em destaque', forma: 'redonda', acabamento: 'brilho', c1: '#fb923c', c2: '#9a3412', borda: '#ffd8b8', texto: '#ffffff' },
  { id: 'corporativa', nome: 'Identidade corporativa', estilo: 'Logo e cores da empresa', forma: 'octogono', acabamento: 'corporativo', c1: '#334155', c2: '#0f172a', borda: '#94a3b8', texto: '#ffffff', usaLogo: true },
]
export const modeloOf = (id: string) => MODELOS.find((m) => m.id === id)

/* ---------- configuração global ---------- */
export const COINS_DEFAULT = { ativo: false, adesao: { ativo: false, blocoValor: 100, moedasPorBloco: 5, regra: 'por_bloco' as 'por_bloco' | 'fixa', minCompra: 0, limiteCliente: 0, empresas: [] as number[] } }
export async function coinsCfg() {
  const c = await getConfig<any>('coins', {})
  const a = { ...COINS_DEFAULT.adesao, ...(c.adesao || {}) }
  return { ativo: c.ativo === true, adesao: { ...a, empresas: (Array.isArray(a.empresas) ? a.empresas : []).map(Number).filter((n: number) => n > 0) } }
}
export async function saveCoinsCfg(b: any) {
  const cur = await coinsCfg(), a = b.adesao || {}
  const n = (v: any, d: number, min: number, max: number) => { const x = Number(v); return isFinite(x) ? Math.min(max, Math.max(min, x)) : d }
  const next = {
    ativo: typeof b.ativo === 'boolean' ? b.ativo : cur.ativo,
    adesao: {
      ativo: typeof a.ativo === 'boolean' ? a.ativo : cur.adesao.ativo,
      blocoValor: n(a.blocoValor, cur.adesao.blocoValor, 0.01, 1e6), moedasPorBloco: Math.floor(n(a.moedasPorBloco, cur.adesao.moedasPorBloco, 1, 1e6)),
      regra: a.regra === 'fixa' ? 'fixa' : a.regra === 'por_bloco' ? 'por_bloco' : cur.adesao.regra,
      minCompra: n(a.minCompra, cur.adesao.minCompra, 0, 1e6), limiteCliente: Math.floor(n(a.limiteCliente, cur.adesao.limiteCliente, 0, 1e9)),
      empresas: Array.isArray(a.empresas) ? [...new Set(a.empresas.map(Number).filter((x: number) => x > 0))] : cur.adesao.empresas,
    },
  }
  await setConfig('coins', next); return next
}

/* ---------- leitura ---------- */
const num = (v: any) => Number(v) || 0
export function coinOut(r: any) {
  const m = modeloOf(String(r.model)) || MODELOS[0], total = num(r.total_supply), dist = num(r.distributed), red = num(r.redeemed)
  return { id: Number(r.id), businessId: Number(r.business_id), modelo: m.id, modeloInfo: m, nome: r.name, simbolo: r.symbol, logo: r.logo || '', cor1: r.color1 || m.c1, cor2: r.color2 || m.c2, descricao: r.description || '', finalidade: r.purpose || '',
    total, distribuidas: dist, disponiveis: Math.max(0, total - dist), utilizadas: red, emCirculacao: Math.max(0, dist - red), valorReferencia: num(r.ref_value), desconto: num(r.discount_value), status: r.status, publicadaEm: r.published_at ? isoOf(r.published_at) : null, criadaEm: isoOf(r.created_at), empresa: r.empresa || undefined }
}
const SELECT = 'SELECT c.*, b.data AS bdata FROM coins c JOIN businesses b ON b.id = c.business_id'
const withEmpresa = (rows: any[]) => rows.map((r) => { const bd = J<any>(r.bdata, {}); return { ...coinOut({ ...r, empresa: bd.empresa || `Empresa #${r.business_id}` }), institucional: bd.institucional === true } })
export async function listCoins(onlyActive = false) { return withEmpresa(await q(`${SELECT}${onlyActive ? " WHERE c.status = 'ativa'" : ''} ORDER BY c.id DESC`)) }
export async function coinById(id: number) { const r = await one(`${SELECT} WHERE c.id = $1`, [id]); return r ? withEmpresa([r])[0] : null }
export async function coinOfBusiness(businessId: number) { const r = await one(`${SELECT} WHERE c.business_id = $1`, [businessId]); return r ? withEmpresa([r])[0] : null }
export async function balanceOf(coinId: number, userId: number) { return num((await one('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coinId, userId]))?.balance) }

export async function stats(coinId: number) {
  const c = (await coinById(coinId))!
  const rows = await q('SELECT kind, delta, discount, user_id, created_at FROM coin_ledger WHERE coin_id = $1', [coinId])
  const holders = num((await one('SELECT COUNT(*) AS n FROM coin_balances WHERE coin_id = $1 AND balance > 0', [coinId]))?.n)
  const descontoReais = rows.filter((r: any) => r.kind === 'resgate' || r.kind === 'estorno').reduce((a: number, r: any) => a + num(r.discount) * (r.kind === 'estorno' ? -1 : 1), 0)
  const sete = Date.now() - 7 * 86400_000
  const dist7 = rows.filter((r: any) => ['distribuicao', 'adesao', 'ajuste'].includes(r.kind) && num(r.delta) > 0 && Date.parse(isoOf(r.created_at) || '') >= sete).reduce((a: number, r: any) => a + num(r.delta), 0)
  return { ...c, detentores: holders, descontoConcedidoReais: Math.round(descontoReais * 100) / 100, distribuidas7d: dist7, adesaoPct: c.total ? Math.round((c.distribuidas / c.total) * 1000) / 10 : 0, utilizacaoPct: c.distribuidas ? Math.round((c.utilizadas / c.distribuidas) * 1000) / 10 : 0 }
}
/** Evolução diária de DISTRIBUIÇÃO e UTILIZAÇÃO (não é valorização financeira: o valor de referência é fixo e definido pelo administrador). */
export async function series(coinId: number, dias = 30) {
  const rows = await q('SELECT kind, delta, created_at FROM coin_ledger WHERE coin_id = $1 ORDER BY id', [coinId])
  const day = (r: any) => (isoOf(r.created_at) || nowIso()).slice(0, 10)
  const por = new Map<string, { d: number; r: number }>()
  for (const r of rows as any[]) { const k = day(r), x = por.get(k) || { d: 0, r: 0 }; if (['distribuicao', 'adesao', 'ajuste'].includes(r.kind) && num(r.delta) > 0) x.d += num(r.delta); else if (r.kind === 'resgate') x.r += -num(r.delta); else if (r.kind === 'estorno') x.r -= num(r.delta); por.set(k, x) }
  const out: { data: string; distribuido: number; resgatado: number; acumDistribuido: number; acumResgatado: number }[] = []
  let ad = 0, ar = 0
  const antes = [...por.keys()].filter((k) => k < new Date(Date.now() - (dias - 1) * 86400_000).toISOString().slice(0, 10))
  for (const k of antes.sort()) { ad += por.get(k)!.d; ar += por.get(k)!.r }
  for (let i = dias - 1; i >= 0; i--) { const k = new Date(Date.now() - i * 86400_000).toISOString().slice(0, 10), x = por.get(k) || { d: 0, r: 0 }; ad += x.d; ar += x.r; out.push({ data: k, distribuido: x.d, resgatado: x.r, acumDistribuido: ad, acumResgatado: ar }) }
  return out
}

/* ---------- escrita da moeda ---------- */
const COR = /^#[0-9a-fA-F]{6}$/
const txt = (v: any, n: number) => String(v ?? '').trim().slice(0, n)
async function logChange(coinId: number, field: string, o: any, n: any, actor: string) { if (String(o ?? '') !== String(n ?? '')) await q('INSERT INTO coin_changes (coin_id, field, old_value, new_value, actor, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [coinId, field, String(o ?? ''), String(n ?? ''), actor, nowIso()]) }
export async function createCoin(b: any, actor: string, adminId: number) {
  if (b.institucional === true || b.businessId === 'institucional') b = { ...b, businessId: await (await import('./coin-hub.js')).ensureInstitucional(adminId) } // "Meu Assistente" como empresa emissora
  const bid = Number(b.businessId), biz = await one('SELECT id, data FROM businesses WHERE id = $1', [bid]); if (!biz) fail(404, 'Empresa não encontrada.', 'not_found')
  if (await one('SELECT id FROM coins WHERE business_id = $1', [bid])) fail(409, 'Esta empresa já tem uma moeda. Edite a existente (cada empresa tem a sua).', 'exists')
  const m = modeloOf(String(b.modelo))!; if (!m) fail(400, 'Escolha um modelo da biblioteca.', 'invalid')
  const f = fields(b, null)
  await q('INSERT INTO coins (business_id, model, name, symbol, logo, color1, color2, description, purpose, total_supply, ref_value, discount_value, status, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$15)',
    [bid, m.id, f.name, f.symbol, f.logo, f.color1, f.color2, f.description, f.purpose, f.total_supply, f.ref_value, f.discount_value, 'rascunho', adminId, nowIso()])
  const c = (await coinOfBusiness(bid))!
  await q('INSERT INTO coin_changes (coin_id, field, old_value, new_value, actor, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [c.id, 'criada', '', `${c.nome} (${c.simbolo}) · ${c.total} moedas · desconto R$ ${c.desconto}`, actor, nowIso()])
  return c
}
function fields(b: any, cur: any): any {
  const name = txt(b.nome, 40), symbol = txt(b.simbolo, 6).toUpperCase().replace(/[^A-Z0-9$]/g, '')
  if (!cur || b.nome !== undefined) { if (name.length < 2) fail(400, 'Informe o nome da moeda (mínimo 2 letras).', 'invalid', 'nome') }
  if (!cur || b.simbolo !== undefined) { if (symbol.length < 2) fail(400, 'Informe a sigla da moeda (2 a 6 letras ou números).', 'invalid', 'simbolo') }
  const money = (k: string, label: string) => { const v = Number(b[k]); if (b[k] === undefined) return cur ? undefined : 0; if (!isFinite(v) || v < 0 || v > 1e6) fail(400, `${label} inválido.`, 'invalid', k); return Math.round(v * 10000) / 10000 }
  const sup = b.quantidade === undefined ? (cur ? undefined : 0) : Math.floor(Number(b.quantidade)); if (sup !== undefined && (!isFinite(sup) || sup < 0 || sup > 1e12)) fail(400, 'Quantidade total inválida.', 'invalid', 'quantidade')
  const cor = (k: string) => (b[k] === undefined ? undefined : COR.test(String(b[k])) ? String(b[k]) : (fail(400, 'Cor inválida (use #RRGGBB).', 'invalid', k) as never))
  const logo = b.logo === undefined ? undefined : String(b.logo || '')
  if (logo && (!/^data:image\/(png|jpeg|webp|svg\+xml);base64,/.test(logo) || logo.length > 400_000)) fail(400, 'Logotipo inválido ou grande demais (máx. ~300 KB, PNG, JPG, WebP ou SVG).', 'invalid', 'logo')
  return { name, symbol, logo: logo ?? (cur ? undefined : ''), color1: cor('cor1') ?? (cur ? undefined : ''), color2: cor('cor2') ?? (cur ? undefined : ''), description: b.descricao === undefined ? (cur ? undefined : '') : txt(b.descricao, 400), purpose: b.finalidade === undefined ? (cur ? undefined : '') : txt(b.finalidade, 300), total_supply: sup, ref_value: money('valorReferencia', 'Valor de referência'), discount_value: money('desconto', 'Valor de desconto') }
}
export async function updateCoin(id: number, b: any, actor: string) {
  return withLock(`coin:${id}`, async () => {
    const cur: any = await one('SELECT * FROM coins WHERE id = $1', [id]); if (!cur) fail(404, 'Moeda não encontrada.', 'not_found')
    const f = fields(b, cur), sets: string[] = [], vals: any[] = [], logs: [string, any, any][] = []
    const set = (col: string, label: string, v: any, old: any) => { if (v === undefined) return; sets.push(`${col} = $${vals.length + 1}`); vals.push(v); logs.push([label, old, v]) }
    if (b.modelo !== undefined) { const m = modeloOf(String(b.modelo))!; if (!m) fail(400, 'Modelo inválido.', 'invalid'); set('model', 'modelo', m.id, cur.model) }
    set('name', 'nome', b.nome !== undefined ? f.name : undefined, cur.name); set('symbol', 'simbolo', b.simbolo !== undefined ? f.symbol : undefined, cur.symbol)
    set('logo', 'logo', f.logo, cur.logo ? '(imagem)' : '');  set('color1', 'cor1', f.color1, cur.color1); set('color2', 'cor2', f.color2, cur.color2)
    set('description', 'descricao', f.description, cur.description); set('purpose', 'finalidade', f.purpose, cur.purpose)
    if (f.total_supply !== undefined) { if (f.total_supply < num(cur.distributed)) fail(400, `A quantidade total não pode ser menor que as ${num(cur.distributed)} moedas já distribuídas.`, 'invalid', 'quantidade'); set('total_supply', 'quantidade total', f.total_supply, cur.total_supply) }
    set('ref_value', 'valor de referência', f.ref_value, num(cur.ref_value)); set('discount_value', 'valor de desconto', f.discount_value, num(cur.discount_value))
    if (!sets.length) return (await coinById(id))!
    sets.push(`updated_at = $${vals.length + 1}`); vals.push(nowIso()); vals.push(id)
    await q(`UPDATE coins SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals)
    for (const [l, o, n] of logs) await logChange(id, l, o, n, actor)
    return (await coinById(id))!
  })
}
export async function setStatus(id: number, status: string, actor: string) {
  if (!['ativa', 'suspensa', 'rascunho'].includes(status)) fail(400, 'Situação inválida.', 'invalid')
  const cur: any = await one('SELECT * FROM coins WHERE id = $1', [id]); if (!cur) fail(404, 'Moeda não encontrada.', 'not_found')
  if (status === 'ativa') { if (num(cur.total_supply) <= 0) fail(400, 'Defina a quantidade total de moedas antes de publicar.', 'invalid'); if (num(cur.discount_value) <= 0) fail(400, 'Defina o valor de desconto de cada moeda antes de publicar.', 'invalid') }
  await q('UPDATE coins SET status = $1, published_at = COALESCE(published_at, $2), updated_at = $2 WHERE id = $3', [status, nowIso(), id])
  await logChange(id, 'situação', cur.status, status, actor)
  return (await coinById(id))!
}

/* ---------- movimentação (único ponto que altera saldos) ---------- */
export type Mov = { ok: true; duplicado: boolean; saldo: number; quantidade: number }
async function movimentar(coinId: number, userId: number, tipo: 'distribuicao' | 'adesao' | 'ajuste' | 'resgate' | 'estorno', qtd: number, o: { idem?: string; orderId?: number; actor: string; nota?: string; desconto?: number; linked?: number | null }): Promise<Mov> {
  if (!Number.isInteger(qtd) || qtd <= 0) fail(400, 'Quantidade de moedas inválida.', 'invalid')
  return withLock(`coin:${coinId}`, async () => {
    if (o.idem) { const ex = await one('SELECT balance_after, delta FROM coin_ledger WHERE coin_id = $1 AND idem = $2', [coinId, o.idem]); if (ex) return { ok: true as const, duplicado: true, saldo: num(ex.balance_after), quantidade: Math.abs(num(ex.delta)) } }
    const entra = tipo !== 'resgate'
    return db().tx(async (t) => {
      const now = nowIso()
      if (entra) {
        if (tipo === 'estorno') { const r = await t.query('UPDATE coins SET redeemed = redeemed - $1, updated_at = $3 WHERE id = $2 AND redeemed >= $1 RETURNING id', [qtd, coinId, now]); if (!r.length) fail(409, 'Estorno maior que o total utilizado.', 'invalid') }
        else { const r = await t.query('UPDATE coins SET distributed = distributed + $1, updated_at = $3 WHERE id = $2 AND distributed + $1 <= total_supply RETURNING id', [qtd, coinId, now]); if (!r.length) fail(409, 'Não há moedas disponíveis para distribuir (quantidade total esgotada).', 'sem_estoque') }
        await t.query('INSERT INTO coin_balances (coin_id, user_id, balance, updated_at) VALUES ($1,$2,0,$3) ON CONFLICT (coin_id, user_id) DO NOTHING', [coinId, userId, now])
        await t.query('UPDATE coin_balances SET balance = balance + $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3', [qtd, coinId, userId, now])
      } else {
        // saldo nunca negativo: só debita se houver saldo suficiente, na mesma instrução
        const r = await t.query('UPDATE coin_balances SET balance = balance - $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3 AND balance >= $1 RETURNING balance', [qtd, coinId, userId, now]); if (!r.length) fail(409, 'Saldo de moedas insuficiente.', 'saldo_insuficiente')
        await t.query('UPDATE coins SET redeemed = redeemed + $1, updated_at = $3 WHERE id = $2', [qtd, coinId, now])
      }
      const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coinId, userId]))[0]?.balance)
      await t.query('INSERT INTO coin_ledger (coin_id, user_id, kind, delta, balance_after, order_id, idem, actor, note, discount, created_at, issuer_business_id, linked_business_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,(SELECT business_id FROM coins WHERE id = $1),$12)', [coinId, userId, tipo, entra ? qtd : -qtd, saldo, o.orderId ?? null, o.idem ?? null, o.actor, o.nota ?? null, o.desconto ?? null, now, o.linked ?? null])
      return { ok: true as const, duplicado: false, saldo, quantidade: qtd }
    })
  })
}
async function activeCoin(coinId: number) {
  const c = await coinById(coinId); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  if (!(await coinsCfg()).ativo) fail(403, 'O sistema de MCoins está desligado.', 'disabled')
  if (c!.status !== 'ativa') fail(409, 'Esta moeda está suspensa ou ainda não foi publicada.', 'inactive')
  return c!
}
/** Distribuição manual feita pelo administrador. */
export async function distribuir(coinId: number, userId: number, qtd: number, idem: string, adminId: number, nota = '') {
  await activeCoin(coinId); if (!(await one('SELECT id FROM users WHERE id = $1', [userId]))) fail(404, 'Cliente não encontrado.', 'not_found')
  const r = await movimentar(coinId, userId, 'distribuicao', qtd, { idem: idem || undefined, actor: 'admin ' + adminId, nota })
  if (!r.duplicado) await avisar(userId, coinId, `Você recebeu ${qtd} moeda(s)`, `Crédito promocional para usar em compras da empresa.`, `coin-dist:${coinId}:${idem || Date.now()}`)
  return r
}
const avisar = async (userId: number, coinId: number, title: string, body: string, ref: string) => { try { const c = await coinById(coinId); await (await import('./notify.js')).notify(userId, { type: 'coin', title: `${title} ${c ? c.simbolo : ''}`.trim(), body: `${c?.empresa || ''} · ${body}`, link: '/x/carteira', ref }) } catch { /* aviso é opcional */ } }

/** Quanto desconto `qtd` moedas dão num valor de itens (confere saldo, situação da moeda e limite do pedido). */
export async function previewUso(businessId: number, userId: number, qtd: number, subtotal: number, coinId?: number) {
  const c: any = await coinOfBusiness(businessId); const cfg = await coinsCfg()
  // moeda de OUTRA empresa emissora (ex.: Meu Assistente) aceita por vínculo ativo: usa as regras do vínculo
  if (coinId && (!c || Number(coinId) !== c.id)) {
    const a = await (await import('./coin-hub.js')).aceita(businessId, Number(coinId))
    if (!cfg.ativo || !a) fail(400, 'Esta empresa não aceita esta MCoin no momento.', 'invalid', 'moedas')
    const un = a!.desconto; if (!(un > 0)) fail(400, 'Esta moeda não tem valor de desconto definido.', 'invalid', 'moedas')
    if (subtotal < a!.minCompra) fail(400, `Para usar ${a!.coin.simbolo} nesta empresa a compra mínima é R$ ${a!.minCompra.toFixed(2).replace('.', ',')}.`, 'invalid', 'moedas')
    const saldo = await balanceOf(a!.coin.id, userId); if (qtd > saldo) fail(400, `Você tem ${saldo} ${a!.coin.simbolo}; não é possível usar ${qtd}.`, 'saldo_insuficiente', 'moedas')
    const teto = Math.round(subtotal * Math.min(100, a!.maxPct)) / 100, max = Math.floor(Math.round((Math.min(subtotal, teto) / un) * 10000) / 10000)
    if (qtd > max) fail(400, `Neste pedido você pode usar no máximo ${max} ${a!.coin.simbolo} (regra desta empresa: até ${a!.maxPct}% do valor dos itens).`, 'invalid', 'moedas')
    return { coin: a!.coin as any, desconto: Math.round(qtd * un * 100) / 100, vinculo: a!.linkId }
  }
  if (!c || c.status !== 'ativa' || !cfg.ativo) fail(400, 'Esta empresa não aceita MCoins no momento.', 'invalid', 'moedas')
  if (!(c.desconto > 0)) fail(400, 'Esta moeda não tem valor de desconto definido.', 'invalid', 'moedas')
  const saldo = await balanceOf(c.id, userId); if (qtd > saldo) fail(400, `Você tem ${saldo} ${c.simbolo}; não é possível usar ${qtd}.`, 'saldo_insuficiente', 'moedas')
  const max = Math.floor(Math.round((subtotal / c.desconto) * 10000) / 10000); if (qtd > max) fail(400, `Neste pedido você pode usar no máximo ${max} ${c.simbolo} (o desconto não passa do valor dos itens).`, 'invalid', 'moedas')
  return { coin: c, desconto: Math.round(qtd * c.desconto * 100) / 100, vinculo: null as number | null }
}
export async function resgatar(coinId: number, userId: number, qtd: number, orderId: number, desconto: number, linked?: number) {
  await activeCoin(coinId)
  return movimentar(coinId, userId, 'resgate', qtd, { idem: `order:${orderId}:uso`, orderId, actor: 'cliente ' + userId, desconto, linked: linked ?? null, nota: `Desconto no pedido #${orderId}` })
}
/** Devolve as moedas de um pedido recusado/cancelado (uma única vez). */
export async function estornarPedido(orderId: number) {
  const l = await q("SELECT coin_id, user_id, delta, discount, linked_business_id FROM coin_ledger WHERE order_id = $1 AND kind = 'resgate'", [orderId])
  for (const r of l as any[]) { await movimentar(Number(r.coin_id), Number(r.user_id), 'estorno', -num(r.delta), { idem: `order:${orderId}:estorno`, orderId, actor: 'sistema', desconto: num(r.discount), linked: r.linked_business_id == null ? null : Number(r.linked_business_id), nota: `Pedido #${orderId} não concluído` }) }
}
/** Adesão por compra: depois de o pagamento ser confirmado, concede moedas uma única vez por pedido. Desativada por padrão. */
export async function adesaoPorCompra(o: any, d: any) {
  const cfg = await coinsCfg(); if (!cfg.ativo || !cfg.adesao.ativo) return null
  if (d?.guest || !o.customer_id) return null
  const c: any = await coinOfBusiness(Number(o.business_id)); if (!c || c.status !== 'ativa' || !cfg.adesao.empresas.includes(Number(o.business_id))) return null
  const base = Math.round((Number(o.total) - (Number(d?.taxa) || 0)) * 100) / 100 // o que foi pago pelos itens, já sem o desconto das moedas
  const a = cfg.adesao; if (base <= 0 || base < a.minCompra) return null
  let qtd = a.regra === 'fixa' ? (base >= a.blocoValor ? a.moedasPorBloco : 0) : Math.floor(base / a.blocoValor) * a.moedasPorBloco
  if (a.limiteCliente > 0) { const ja = num((await one("SELECT COALESCE(SUM(delta),0) AS n FROM coin_ledger WHERE coin_id = $1 AND user_id = $2 AND kind = 'adesao'", [c.id, Number(o.customer_id)]))?.n); qtd = Math.min(qtd, Math.max(0, a.limiteCliente - ja)) }
  qtd = Math.min(qtd, c.disponiveis); if (qtd <= 0) return null
  const r = await movimentar(c.id, Number(o.customer_id), 'adesao', qtd, { idem: `order:${o.id}:adesao`, orderId: Number(o.id), actor: 'sistema', linked: Number(o.business_id), nota: `Compra do pedido #${o.id}` })
  if (!r.duplicado) await avisar(Number(o.customer_id), c.id, `Você ganhou ${qtd} moeda(s)`, `pela compra #${o.id}.`, `coin-adesao:${o.id}`)
  return r
}

/* ---------- carteira e relatórios ---------- */
export async function wallet(userId: number) {
  const bal = await q('SELECT coin_id, balance FROM coin_balances WHERE user_id = $1', [userId])
  const hist = await q('SELECT coin_id, kind, delta, balance_after, order_id, note, discount, created_at, issuer_business_id, linked_business_id FROM coin_ledger WHERE user_id = $1 ORDER BY id DESC LIMIT 200', [userId])
  const ids = [...new Set([...bal.map((b: any) => Number(b.coin_id)), ...hist.map((h: any) => Number(h.coin_id))])]
  const coins = (await Promise.all(ids.map((i) => coinById(i)))).filter(Boolean) as any[]
  const nomes = await nomesEmpresas(hist.flatMap((h: any) => [h.issuer_business_id, h.linked_business_id]))
  return { moedas: coins.map((c) => { const saldo = num(bal.find((b: any) => Number(b.coin_id) === c.id)?.balance); return { ...c, saldo, equivalente: Math.round(saldo * c.desconto * 100) / 100, regras: c.institucional ? `Emitida pelo Meu Assistente e aceita nas empresas vinculadas, conforme a regra de cada uma. Não pode ser transferida, trocada ou sacada.` : `1 ${c.simbolo} = R$ ${c.desconto.toFixed(2).replace('.', ',')} de desconto, só em compras na empresa ${c.empresa}. Não pode ser transferida, trocada ou sacada.` } }),
    historico: hist.map((h: any) => ({ moedaId: Number(h.coin_id), tipo: h.kind, quantidade: num(h.delta), saldoApos: num(h.balance_after), pedido: h.order_id ? Number(h.order_id) : null, nota: h.note || '', desconto: h.discount != null ? num(h.discount) : null, em: isoOf(h.created_at), emissora: nomes[Number(h.issuer_business_id)] || '', vinculada: nomes[Number(h.linked_business_id)] || '' })) }
}
export async function ledger(coinId: number, limit = 200) {
  const rows = await q('SELECT l.id, l.user_id, l.kind, l.delta, l.balance_after, l.order_id, l.actor, l.note, l.discount, l.created_at, u.name, u.email, l.issuer_business_id, l.linked_business_id FROM coin_ledger l LEFT JOIN users u ON u.id = l.user_id WHERE l.coin_id = $1 ORDER BY l.id DESC LIMIT $2', [coinId, limit])
  const nomes = await nomesEmpresas(rows.flatMap((l: any) => [l.issuer_business_id, l.linked_business_id]))
  return rows.map((l: any) => ({ id: Number(l.id), clienteId: Number(l.user_id), cliente: l.name || '', email: l.email || '', tipo: l.kind, quantidade: num(l.delta), saldoApos: num(l.balance_after), pedido: l.order_id ? Number(l.order_id) : null, quem: l.actor || '', nota: l.note || '', desconto: l.discount != null ? num(l.discount) : null, em: isoOf(l.created_at) , emissoraId: l.issuer_business_id == null ? null : Number(l.issuer_business_id), vinculadaId: l.linked_business_id == null ? null : Number(l.linked_business_id), emissora: nomes[Number(l.issuer_business_id)] || '', vinculada: nomes[Number(l.linked_business_id)] || '' }))
}
export async function topBalances(coinId: number) { return (await q('SELECT b.user_id, b.balance, u.name FROM coin_balances b LEFT JOIN users u ON u.id = b.user_id WHERE b.coin_id = $1 AND b.balance > 0 ORDER BY b.balance DESC LIMIT 20', [coinId])).map((r: any) => ({ clienteId: Number(r.user_id), cliente: r.name || '', saldo: num(r.balance) })) }
export async function changes(coinId: number) { return (await q('SELECT field, old_value, new_value, actor, created_at FROM coin_changes WHERE coin_id = $1 ORDER BY id DESC LIMIT 100', [coinId])).map((r: any) => ({ campo: r.field, de: r.old_value, para: r.new_value, quem: r.actor, em: isoOf(r.created_at) })) }

/** Nomes das empresas (emissora/vinculada) para rastrear cada movimentação. */
export async function nomesEmpresas(ids: any[]): Promise<Record<number, string>> {
  const u = [...new Set(ids.filter((x) => x != null).map(Number).filter((n) => n > 0))]; const out: Record<number, string> = {}
  if (!u.length) return out
  for (const r of await q(`SELECT id, data FROM businesses WHERE id IN (${u.map((_, i) => '$' + (i + 1)).join(',')})`, u)) out[Number(r.id)] = J<any>(r.data, {}).empresa || `Empresa #${r.id}`
  return out
}
