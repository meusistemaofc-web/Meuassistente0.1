// Código exclusivo e PERMANENTE de cada moeda (ex.: MC-MA-000001). É apenas um IDENTIFICADOR (para busca, relatórios e futuras
// transferências): nunca é credencial, senha ou autorização — toda operação continua exigindo sessão e permissão no servidor.
//  • gerado automaticamente na criação da moeda; formato MC-<MA|EM>-<sequência de 6 dígitos> (MA = Meu Assistente, EM = empresa);
//  • a sequência vem do registro permanente `coin_codes`, que nunca é apagado ⇒ nenhum código é reutilizado (nem de moeda desativada);
//  • não muda com alterações cadastrais (nenhuma rota de edição o recebe); índices únicos impedem duplicidade.
import { q, one, J, nowIso, isoOf } from '../db/index.js'
import { withLock } from './business-sync.js'

export const CODIGO = /^MC-(MA|EM)-\d{6,}$/
const fmt = (kind: string, seq: number) => `MC-${kind}-${String(seq).padStart(6, '0')}`

export async function atribuirCodigo(coinId: number): Promise<string> {
  return withLock('coin-code', async () => {
    const c = await one('SELECT id, business_id, code FROM coins WHERE id = $1', [coinId]); if (!c) throw new Error('moeda inexistente')
    if (c.code) return String(c.code)
    const reg = await one('SELECT code FROM coin_codes WHERE coin_id = $1', [coinId]); if (reg) { await q('UPDATE coins SET code = $1 WHERE id = $2 AND code IS NULL', [reg.code, coinId]); return String(reg.code) }
    const b = await one('SELECT data FROM businesses WHERE id = $1', [c.business_id]), kind = J<any>(b?.data, {}).institucional === true ? 'MA' : 'EM'
    const seq = Number((await one('SELECT COALESCE(MAX(seq), 0) AS m FROM coin_codes'))?.m || 0) + 1, code = fmt(kind, seq)
    await q('INSERT INTO coin_codes (code, seq, coin_id, business_id, issuer_kind, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [code, seq, coinId, c.business_id, kind, nowIso()])
    await q('UPDATE coins SET code = $1 WHERE id = $2', [code, coinId])
    return code
  })
}
let feito = false
/** Moedas criadas antes desta função recebem o código na primeira leitura (ordem de criação). */
export async function garantirCodigos() {
  if (feito) return
  for (const r of await q('SELECT id FROM coins WHERE code IS NULL ORDER BY id') as any[]) await atribuirCodigo(Number(r.id))
  feito = true
}
const nomeEmp = async (id: number) => { const b = await one('SELECT data FROM businesses WHERE id = $1', [id]); return J<any>(b?.data, {}).empresa || `Empresa #${id}` }
/** Consulta administrativa: pelo código (ou parte dele), nome, sigla ou emissora. Mostra emissor, moeda e empresas vinculadas. */
export async function buscar(termo: string) {
  await garantirCodigos()
  const t = String(termo || '').trim().toUpperCase().slice(0, 60), like = `%${t.replace(/[%_\\]/g, '')}%`
  const rows = await q(`SELECT cc.code, cc.seq, cc.issuer_kind, cc.coin_id, cc.business_id, cc.created_at, c.name, c.symbol, c.status FROM coin_codes cc LEFT JOIN coins c ON c.id = cc.coin_id ${t ? 'WHERE UPPER(cc.code) LIKE $1 OR UPPER(c.name) LIKE $1 OR UPPER(c.symbol) LIKE $1' : ''} ORDER BY cc.seq LIMIT 100`, t ? [like] : []) as any[]
  const out = []
  for (const r of rows) {
    const links = await q("SELECT business_id, status FROM coin_links WHERE coin_id = $1 ORDER BY id", [r.coin_id]) as any[]
    out.push({ codigo: r.code, sequencia: Number(r.seq), emissorTipo: r.issuer_kind === 'MA' ? 'Meu Assistente (institucional)' : 'Empresa', emissor: { id: Number(r.business_id), nome: await nomeEmp(Number(r.business_id)) },
      moeda: { id: Number(r.coin_id), nome: r.name || '', simbolo: r.symbol || '', status: r.status || 'removida' }, vinculadas: await Promise.all(links.map(async (l) => ({ empresaId: Number(l.business_id), empresa: await nomeEmp(Number(l.business_id)), status: l.status }))), criadoEm: isoOf(r.created_at) })
  }
  return out
}
