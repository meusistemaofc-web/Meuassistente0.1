// CRÉDITO DA LOJA — crédito interno para compras parceladas, só para empresas autorizadas pelo administrador (ADM).
// Camadas (todas validadas AQUI, no servidor; o aplicativo só mostra e escolhe):
//   ADM ........ liga/desliga o recurso (app_config "credito_loja"), autoriza/suspende/revoga cada empresa e define tetos globais
//                (parcelas, juros, limite por cliente, entrada mínima, pagamento parcial).
//   Empresa .... regras próprias dentro dos tetos (parcelas, juros mensal/sobre o total, sem juros até N, 1ª parcela no ato ou
//                depois, intervalo, entrada mínima, compra mín./máx., aprovação automática/manual/até um valor, limites).
//   Cliente .... limite individual concedido pela empresa (ativo/suspenso). Limite utilizado = principal ainda não amortizado
//                das compras ativas; reservado = compras aguardando aprovação; disponível = limite − utilizado − reservado.
//   Compra ..... no checkout de sempre (POST /api/v2/businesses/:id/orders com pagamento "credito"): simulação refeita no
//                servidor, aceite explícito, conferência do total aceito, limite conferido sob trava; aprovação automática gera
//                as parcelas na hora; manual cria a solicitação (o pedido fica "aguardando_credito" e só reserva o limite).
//   Parcelas ... entrada = número 0; 1..n com vencimento, status (pendente | paga | vencida | cancelada), histórico.
//   Pagamentos . registrados pelo dono (parcial quando as regras permitem), sem duplicidade (chave por parcela), e lançados no
//                financeiro do dono UMA vez por pagamento — o pedido a crédito NÃO lança a venda inteira (ver business-sync),
//                então a receita entra exatamente quando o dinheiro entra. Sem integração bancária: nada é "pago" sozinho.
import { q, one, J, nowIso, db, type Db } from '../db/index.js'
import { fail } from './http.js'
import { getConfig, setConfig } from './settings.js'
import { notify } from './notify.js'
import { withLock } from './business-sync.js'
import { localDate, validTz } from './time.js'

/* ---------------- configuração ---------------- */
export type GlobalCfg = { ativo: boolean; maxParcelas: number; jurosMaxMes: number; jurosMaxTotal: number; limiteMaxCliente: number; entradaMinPct: number; permitirParcial: boolean; diasAvisoVencimento: number; retencaoDocsDias: number }
export const GLOBAL_PADRAO: GlobalCfg = { ativo: false, maxParcelas: 12, jurosMaxMes: 8, jurosMaxTotal: 60, limiteMaxCliente: 10000, entradaMinPct: 0, permitirParcial: true, diasAvisoVencimento: 3, retencaoDocsDias: 90 }
export type EmpresaCfg = {
  ativo: boolean; limitePadrao: number; limiteMaxCliente: number; compraMin: number; compraMax: number; parcelas: number[]
  jurosTipo: 'sem' | 'mensal' | 'total'; taxa: number; semJurosAte: number; primeiraParcela: 'ato' | 'posterior'
  primeiroVencDias: number; intervaloDias: number; entradaMinPct: number; aprovacao: 'automatica' | 'manual' | 'ate_valor'
  aprovacaoAutoAte: number; permitirParcial: boolean; condicoes: string; aceitarSolicitacoes: boolean; condicoesCliente?: string
}
export const EMPRESA_PADRAO: EmpresaCfg = { ativo: false, limitePadrao: 300, limiteMaxCliente: 1000, compraMin: 20, compraMax: 1000, parcelas: [2, 3, 4], jurosTipo: 'sem', taxa: 0, semJurosAte: 0, primeiraParcela: 'posterior', primeiroVencDias: 30, intervaloDias: 30, entradaMinPct: 0, aprovacao: 'manual', aprovacaoAutoAte: 0, permitirParcial: true, condicoes: '', aceitarSolicitacoes: true }

export const r2 = (n: number) => Math.round((Number(n) + Number.EPSILON) * 100) / 100
const num = (v: unknown, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d }
const txt = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u0008\u000b-\u001f<>]/g, ' ').trim().slice(0, n)
const bool = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d)
const brl = (n: number) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const brData = (iso: string) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso); return m ? `${m[3]}/${m[2]}/${m[1]}` : iso }

export async function globalCfg(): Promise<GlobalCfg> { return { ...GLOBAL_PADRAO, ...(await getConfig<Partial<GlobalCfg>>('credito_loja', {})) } }
/** Validação da configuração global (PUT do ADM): valores fora da faixa são recusados, não ajustados em silêncio. */
export function validarGlobal(b: any, atual: GlobalCfg): GlobalCfg {
  const g = { ...atual }
  if (b.ativo !== undefined) g.ativo = !!b.ativo
  const faixa = (k: keyof GlobalCfg, min: number, max: number, nome: string, inteiro = false) => { if (b[k] === undefined) return; const n = num(b[k], NaN); if (!Number.isFinite(n) || n < min || n > max || (inteiro && !Number.isInteger(n))) fail(400, `${nome}: use um valor entre ${min} e ${max}.`, 'invalid', String(k)); (g as any)[k] = inteiro ? n : r2(n) }
  faixa('maxParcelas', 1, 48, 'Máximo de parcelas', true); faixa('jurosMaxMes', 0, 20, 'Juros máximos ao mês (%)'); faixa('jurosMaxTotal', 0, 300, 'Juros máximos sobre o parcelamento (%)')
  faixa('limiteMaxCliente', 0, 1_000_000, 'Limite máximo por cliente'); faixa('entradaMinPct', 0, 90, 'Entrada mínima (%)'); faixa('diasAvisoVencimento', 0, 15, 'Aviso antes do vencimento (dias)', true); faixa('retencaoDocsDias', 7, 1825, 'Retenção dos documentos das solicitações (dias)', true)
  if (b.permitirParcial !== undefined) g.permitirParcial = !!b.permitirParcial
  return g
}
/** Regras da empresa sempre dentro dos tetos do ADM. `estrito` recusa valores inválidos (PUT); sem ele, ajusta (leitura). */
export function normEmpresa(c: any, g: GlobalCfg, estrito = false): EmpresaCfg {
  const e: EmpresaCfg = { ...EMPRESA_PADRAO, ...(c || {}) } as EmpresaCfg
  const ruim = (campo: string, msg: string) => { if (estrito) fail(400, msg, 'invalid', campo) }
  e.ativo = bool(e.ativo, false)
  const tetoLim = g.limiteMaxCliente
  e.limiteMaxCliente = r2(num(e.limiteMaxCliente, 0)); if (e.limiteMaxCliente < 0 || e.limiteMaxCliente > tetoLim) { ruim('limiteMaxCliente', `O limite máximo por cliente vai até ${brl(tetoLim)} (definido pelo administrador).`); e.limiteMaxCliente = Math.min(Math.max(0, e.limiteMaxCliente), tetoLim) }
  e.limitePadrao = r2(num(e.limitePadrao, 0)); if (e.limitePadrao < 0 || e.limitePadrao > e.limiteMaxCliente) { ruim('limitePadrao', 'O limite padrão não pode passar do limite máximo por cliente.'); e.limitePadrao = Math.min(Math.max(0, e.limitePadrao), e.limiteMaxCliente) }
  e.compraMin = r2(num(e.compraMin, 0)); e.compraMax = r2(num(e.compraMax, 0))
  if (e.compraMin < 0) { ruim('compraMin', 'A compra mínima não pode ser negativa.'); e.compraMin = 0 }
  if (e.compraMax <= 0 || e.compraMax < e.compraMin) { ruim('compraMax', 'A compra máxima precisa ser maior que a mínima.'); e.compraMax = Math.max(e.compraMin, 1) }
  const ps = [...new Set((Array.isArray(e.parcelas) ? e.parcelas : []).map((n: any) => Math.floor(num(n, 0))))].filter((n) => n >= 1).sort((a, b) => a - b)
  if (ps.some((n) => n > g.maxParcelas)) ruim('parcelas', `O administrador permite no máximo ${g.maxParcelas} parcelas.`)
  e.parcelas = ps.filter((n) => n <= g.maxParcelas).slice(0, 48); if (!e.parcelas.length) { ruim('parcelas', 'Escolha pelo menos uma quantidade de parcelas.'); e.parcelas = [Math.min(2, g.maxParcelas)] }
  if (!['sem', 'mensal', 'total'].includes(e.jurosTipo)) { ruim('jurosTipo', 'Tipo de juros inválido.'); e.jurosTipo = 'sem' }
  e.taxa = r2(num(e.taxa, 0)); const maxT = e.jurosTipo === 'mensal' ? g.jurosMaxMes : e.jurosTipo === 'total' ? g.jurosMaxTotal : 100
  if (e.taxa < 0 || e.taxa > maxT) { ruim('taxa', `Os juros ${e.jurosTipo === 'mensal' ? 'ao mês' : 'sobre o parcelamento'} vão até ${String(maxT).replace('.', ',')}% (definido pelo administrador).`); e.taxa = Math.min(Math.max(0, e.taxa), maxT) }
  if (e.jurosTipo === 'sem') e.taxa = 0
  e.semJurosAte = Math.max(0, Math.min(48, Math.floor(num(e.semJurosAte, 0))))
  if (!['ato', 'posterior'].includes(e.primeiraParcela)) e.primeiraParcela = 'posterior'
  e.primeiroVencDias = Math.floor(num(e.primeiroVencDias, 30)); if (e.primeiroVencDias < 1 || e.primeiroVencDias > 90) { ruim('primeiroVencDias', 'O primeiro vencimento fica entre 1 e 90 dias depois da compra.'); e.primeiroVencDias = Math.min(90, Math.max(1, e.primeiroVencDias)) }
  e.intervaloDias = Math.floor(num(e.intervaloDias, 30)); if (e.intervaloDias < 7 || e.intervaloDias > 90) { ruim('intervaloDias', 'O intervalo entre vencimentos fica entre 7 e 90 dias.'); e.intervaloDias = Math.min(90, Math.max(7, e.intervaloDias)) }
  e.entradaMinPct = r2(num(e.entradaMinPct, 0)); if (e.entradaMinPct < 0 || e.entradaMinPct > 90) { ruim('entradaMinPct', 'A entrada mínima fica entre 0% e 90%.'); e.entradaMinPct = Math.min(90, Math.max(0, e.entradaMinPct)) }
  if (e.entradaMinPct < g.entradaMinPct) { ruim('entradaMinPct', `O administrador exige entrada mínima de ${String(g.entradaMinPct).replace('.', ',')}%.`); e.entradaMinPct = g.entradaMinPct }
  if (!['automatica', 'manual', 'ate_valor'].includes(e.aprovacao)) { ruim('aprovacao', 'Regra de aprovação inválida.'); e.aprovacao = 'manual' }
  e.aprovacaoAutoAte = r2(Math.max(0, num(e.aprovacaoAutoAte, 0)))
  e.permitirParcial = bool(e.permitirParcial, true) && g.permitirParcial
  e.condicoes = txt(e.condicoes, 600)
  e.aceitarSolicitacoes = bool(e.aceitarSolicitacoes, true)
  if (e.condicoesCliente !== undefined) e.condicoesCliente = txt(e.condicoesCliente, 600)
  return e
}

/** Condições aprovadas para UM cliente (solicitação de crédito): sobrepõem as da empresa, sempre dentro dos tetos do ADM. */
export const CHAVES_CLIENTE = ['parcelas', 'jurosTipo', 'taxa', 'semJurosAte', 'entradaMinPct', 'primeiraParcela', 'primeiroVencDias', 'intervaloDias', 'compraMax', 'condicoesCliente'] as const
export function cfgDoCliente(cfg: EmpresaCfg, g: GlobalCfg, ov: any, estrito = false): EmpresaCfg {
  const o: any = {}; for (const k of CHAVES_CLIENTE) if (ov && ov[k] !== undefined && ov[k] !== null && ov[k] !== '') o[k] = ov[k]
  return Object.keys(o).length ? normEmpresa({ ...cfg, ...o }, g, estrito) : cfg
}
async function cfgClienteDe(bid: number, uid: number, e: { cfg: EmpresaCfg; g: GlobalCfg }) { const r = await one('SELECT condicoes FROM credito_clientes WHERE business_id = $1 AND user_id = $2', [bid, uid]); return cfgDoCliente(e.cfg, e.g, J<any>(r?.condicoes, {})) }

/* ---------------- datas ---------------- */
const addDias = (iso: string, d: number) => { const t = new Date(iso + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + d); return t.toISOString().slice(0, 10) }
const addMeses = (iso: string, m: number) => { const [y, mo, d] = iso.split('-').map(Number); const alvo = new Date(Date.UTC(y, mo - 1 + m, 1, 12)); const fim = new Date(Date.UTC(alvo.getUTCFullYear(), alvo.getUTCMonth() + 1, 0, 12)).getUTCDate(); alvo.setUTCDate(Math.min(d, fim)); return alvo.toISOString().slice(0, 10) }
/** Período em dias; múltiplos de 30 contam como meses (mesmo dia do mês), que é como o cliente entende "a cada 30 dias". */
const addPeriodo = (iso: string, dias: number, vezes = 1) => (dias % 30 === 0 ? addMeses(iso, (dias / 30) * vezes) : addDias(iso, dias * vezes))
const tzCache = new Map<number, string>()
export async function hojeDa(bid: number) {
  let tz = tzCache.get(bid)
  if (!tz) { const r = await one('SELECT u.settings FROM businesses b JOIN users u ON u.id = b.owner_id WHERE b.id = $1', [bid]); tz = validTz(J<any>(r?.settings, {}).timezone || 'America/Sao_Paulo'); tzCache.set(bid, tz) }
  return localDate(tz)
}

/* ---------------- simulação (pura: mesma conta na tela, na compra e na aprovação) ---------------- */
export type Simulacao = {
  valorCompra: number; entrada: number; entradaMin: number; principal: number; nParcelas: number; valorParcela: number
  parcelas: { numero: number; valor: number; vencimento: string }[]; juros: number; totalParcelado: number; totalFinal: number
  jurosTipo: 'sem' | 'mensal' | 'total'; taxa: number; primeiraParcela: 'ato' | 'posterior'; intervaloDias: number; resumo: string
}
export function simular(cfg: EmpresaCfg, valor: number, n: number, entradaIn: number, hoje: string): Simulacao {
  const v = r2(valor), nP = Math.max(1, Math.floor(n))
  const entradaMin = r2((v * cfg.entradaMinPct) / 100)
  const entrada = r2(Math.max(entradaMin, Math.min(Math.max(0, num(entradaIn, 0)), v)))
  const principal = r2(v - entrada)
  const semJuros = cfg.jurosTipo === 'sem' || cfg.taxa <= 0 || nP <= cfg.semJurosAte
  const ato = cfg.primeiraParcela === 'ato'
  let valores: number[]
  if (!semJuros && cfg.jurosTipo === 'mensal') {
    const i = cfg.taxa / 100; let pmt = (principal * i) / (1 - Math.pow(1 + i, -nP)); if (ato) pmt = pmt / (1 + i) // tabela Price (antecipada quando a 1ª é no ato)
    valores = Array(nP).fill(r2(pmt))
  } else {
    const total = semJuros ? principal : r2(principal * (1 + cfg.taxa / 100)), base = r2(total / nP)
    valores = Array(nP).fill(base); valores[nP - 1] = r2(total - base * (nP - 1)) // a última acerta os centavos
  }
  const primeira = ato ? hoje : addPeriodo(hoje, cfg.primeiroVencDias)
  const parcelas = valores.map((valor, k) => ({ numero: k + 1, valor, vencimento: k === 0 ? primeira : addPeriodo(primeira, cfg.intervaloDias, k) }))
  const totalParcelado = r2(valores.reduce((a, x) => a + x, 0)), juros = r2(totalParcelado - principal)
  const jt = semJuros ? 'sem' : cfg.jurosTipo, taxa = semJuros ? 0 : cfg.taxa
  const resumo = `${entrada > 0 ? `Entrada de ${brl(entrada)} + ` : ''}${nP}x de ${brl(valores[0])}${valores[nP - 1] !== valores[0] ? ` (última ${brl(valores[nP - 1])})` : ''}${jt === 'sem' ? ' sem juros' : jt === 'mensal' ? ` com juros de ${String(taxa).replace('.', ',')}% ao mês` : ` com juros de ${String(taxa).replace('.', ',')}% sobre o parcelamento`} · total ${brl(r2(entrada + totalParcelado))}`
  return { valorCompra: v, entrada, entradaMin, principal, nParcelas: nP, valorParcela: valores[0], parcelas, juros, totalParcelado, totalFinal: r2(entrada + totalParcelado), jurosTipo: jt, taxa, primeiraParcela: cfg.primeiraParcela, intervaloDias: cfg.intervaloDias, resumo }
}
/** Texto das condições que o cliente aceita (o mesmo fica gravado na operação). */
export function termos(s: Simulacao, empresa: string, cfg: EmpresaCfg) {
  return [
    `Crédito concedido por ${empresa}, que é a responsável pela cobrança. O Meu Assistente apenas registra a operação.`,
    `${s.resumo}.`,
    s.entrada > 0 ? `A entrada de ${brl(s.entrada)} é paga no ato da compra, direto à loja.` : '',
    s.primeiraParcela === 'ato' ? 'A 1ª parcela vence no dia da compra.' : `A 1ª parcela vence em ${brData(s.parcelas[0].vencimento)}.`,
    'Os pagamentos são feitos à loja (Pix, dinheiro ou outra forma combinada) e registrados por ela; você acompanha tudo em Meu crédito.',
    'Parcelas não pagas até o vencimento ficam em atraso e podem suspender novas compras a crédito nesta loja.',
    cfg.condicoes ? `Condições da loja: ${cfg.condicoes}` : '',
    cfg.condicoesCliente ? `Condições do seu crédito: ${cfg.condicoesCliente}` : '',
  ].filter(Boolean)
}

/* ---------------- estado da empresa e do cliente ---------------- */
export type Situacao = 'autorizada' | 'suspensa' | 'revogada'
export async function estadoEmpresa(bid: number) {
  const g = await globalCfg(), r = await one('SELECT * FROM credito_empresas WHERE business_id = $1', [bid])
  const situacao = (r?.situacao || null) as Situacao | null, cfg = normEmpresa(J<any>(r?.config, {}), g)
  const operavel = g.ativo && situacao === 'autorizada'
  return { g, situacao, cfg, operavel, paraClientes: operavel && cfg.ativo, motivo: String(r?.motivo || '') }
}
/** Bloqueio central (backend): sem autorização do ADM ou com o recurso desligado, nada de crédito novo. */
export function exigirOperavel(e: Awaited<ReturnType<typeof estadoEmpresa>>, acao = 'usar o Crédito da Loja') {
  if (!e.g.ativo) fail(403, `O Crédito da Loja está desativado pelo administrador. Não é possível ${acao} agora.`, 'credito_desativado')
  if (e.situacao !== 'autorizada') fail(403, e.situacao === 'suspensa' ? `O Crédito da Loja desta empresa está suspenso pelo administrador. Não é possível ${acao}.` : 'Esta empresa não está autorizada a usar o Crédito da Loja.', 'credito_nao_autorizado')
}
type Uso = { limite: number; situacao: string; validade: string; expirado: boolean; utilizado: number; reservado: number; disponivel: number; saldoDevedor: number; vencido: number; pago: number; parcelasAbertas: number; parcelasVencidas: number }
/** Limite e saldo de um cliente numa empresa (exceto a operação `ignorar`, usada ao aprovar a própria solicitação). */
export async function usoCliente(bid: number, uid: number, hoje?: string, ignorar = 0, t: Db = db()): Promise<Uso> {
  const h = hoje || (await hojeDa(bid))
  const c = (await t.query('SELECT limite, situacao, validade FROM credito_clientes WHERE business_id = $1 AND user_id = $2', [bid, uid]))[0]
  const ops = await t.query("SELECT o.id, o.status, o.principal, o.total_parcelado, (SELECT COALESCE(SUM(p.valor_pago),0) FROM credito_parcelas p WHERE p.operacao_id = o.id AND p.numero > 0) AS pago FROM credito_operacoes o WHERE o.business_id = $1 AND o.user_id = $2 AND o.status IN ('pendente','ativa')", [bid, uid])
  let utilizado = 0, reservado = 0
  for (const o of ops) { if (Number(o.id) === ignorar) continue; const pr = num(o.principal); if (o.status === 'pendente') reservado += pr; else { const tp = num(o.total_parcelado); utilizado += tp > 0 ? pr * Math.max(0, 1 - num(o.pago) / tp) : 0 } }
  const ps = await t.query("SELECT valor, valor_pago, status, vencimento FROM credito_parcelas WHERE business_id = $1 AND user_id = $2 AND status IN ('pendente','vencida','paga')", [bid, uid])
  let saldo = 0, vencido = 0, pago = 0, ab = 0, venc = 0
  for (const p of ps) { pago += num(p.valor_pago); if (p.status === 'paga') continue; const resta = r2(num(p.valor) - num(p.valor_pago)); saldo += resta; ab++; if (p.status === 'vencida' || String(p.vencimento) < h) { vencido += resta; venc++ } }
  const limite = r2(num(c?.limite)), situacao = String(c?.situacao || 'sem_credito')
  utilizado = r2(utilizado); reservado = r2(reservado)
  const validade = String(c?.validade || ''), expirado = !!validade && validade < h
  return { limite, situacao, validade, expirado, utilizado, reservado, disponivel: situacao === 'ativo' && !expirado ? r2(Math.max(0, limite - utilizado - reservado)) : 0, saldoDevedor: r2(saldo), vencido: r2(vencido), pago: r2(pago), parcelasAbertas: ab, parcelasVencidas: venc }
}

/* ---------------- histórico auditável ---------------- */
export async function evento(t: Db, bid: number, tipo: string, dados: object, o: { cliente?: number | null; operacao?: number | null; ator?: number | null } = {}) {
  await t.query('INSERT INTO credito_eventos (business_id, cliente_id, operacao_id, ator_id, tipo, dados, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [bid, o.cliente ?? null, o.operacao ?? null, o.ator ?? null, tipo, JSON.stringify(dados), nowIso()])
}
const nomeEmpresa = async (bid: number) => String(J<any>((await one('SELECT data FROM businesses WHERE id = $1', [bid]))?.data, {}).empresa || 'Loja')
const donoDe = async (bid: number) => Number((await one('SELECT owner_id FROM businesses WHERE id = $1', [bid]))?.owner_id || 0)
const avisar = (uid: number, title: string, body: string, ref: string, link = '/x/meu-credito') => notify(uid, { type: 'credito', title, body, link, ref }).catch((e) => console.error('[credito] aviso:', e?.message))

/* ---------------- compra no checkout ---------------- */
export type Preparo = { sim: Simulacao; manual: boolean; cfg: EmpresaCfg; empresa: string; termos: string[] }
/** Antes de criar o pedido: tudo que o cliente escolheu é refeito e conferido aqui (nada vem pronto do aplicativo). */
export async function prepararCompra(bid: number, uid: number, total: number, escolha: any): Promise<Preparo> {
  const e0 = await estadoEmpresa(bid); exigirOperavel(e0, 'comprar a crédito')
  if (!e0.cfg.ativo) fail(400, 'Esta loja não está oferecendo o Crédito da Loja agora. Escolha outra forma de pagamento.', 'credito_indisponivel')
  const e = { ...e0, cfg: await cfgClienteDe(bid, uid, e0) } // condições aprovadas para este cliente (se houver)
  const ch = escolha && typeof escolha === 'object' ? escolha : {}
  if (ch.aceite !== true) fail(400, 'Para comprar com o Crédito da Loja, confira a simulação e confirme que aceita as condições.', 'credito_aceite')
  const n = Math.floor(num(ch.parcelas, 0))
  if (!e.cfg.parcelas.includes(n)) fail(400, 'Escolha uma quantidade de parcelas oferecida pela loja.', 'invalid')
  const v = r2(total)
  if (v < e.cfg.compraMin) fail(400, `O Crédito da Loja vale para compras a partir de ${brl(e.cfg.compraMin)}.`, 'credito_valor')
  if (v > e.cfg.compraMax) fail(400, `O Crédito da Loja vale para compras de até ${brl(e.cfg.compraMax)}.`, 'credito_valor')
  const entradaPedida = r2(Math.max(0, num(ch.entrada, 0)))
  const sim = simular(e.cfg, v, n, entradaPedida, await hojeDa(bid))
  if (entradaPedida > 0 && entradaPedida < sim.entradaMin) fail(400, `A entrada mínima é ${brl(sim.entradaMin)}.`, 'invalid')
  if (sim.principal <= 0) fail(400, 'Com essa entrada não sobra valor para parcelar. Escolha outra forma de pagamento.', 'invalid')
  const u = await usoCliente(bid, uid)
  if (u.situacao !== 'ativo') fail(403, u.situacao === 'suspenso' ? 'Seu crédito nesta loja está suspenso. Fale com a loja.' : 'Você ainda não tem crédito liberado nesta loja.', 'credito_sem_limite')
  if (u.expirado) fail(403, `Seu limite nesta loja venceu em ${brData(u.validade)}. Solicite a renovação à loja.`, 'credito_expirado')
  if (u.vencido > 0) fail(400, 'Há parcelas em atraso no seu crédito desta loja. Regularize para fazer novas compras a crédito.', 'credito_em_atraso')
  if (sim.principal > u.disponivel + 0.001) fail(400, `Limite insuficiente: você tem ${brl(u.disponivel)} disponíveis e o valor a parcelar é ${brl(sim.principal)}. Aumente a entrada ou escolha outra forma de pagamento.`, 'credito_limite')
  // o cliente confirmou um total: se algo mudou (preço, frete, regra da loja), ele precisa ver a nova simulação antes
  const aceito = r2(num(ch.totalFinal, NaN))
  if (!Number.isFinite(aceito) || Math.abs(aceito - sim.totalFinal) > 0.009) fail(409, `As condições mudaram: o total a crédito agora é ${brl(sim.totalFinal)}. Confira a simulação e confirme de novo.`, 'credito_condicoes_mudaram')
  const manual = e.cfg.aprovacao === 'manual' || (e.cfg.aprovacao === 'ate_valor' && sim.principal > e.cfg.aprovacaoAutoAte)
  const empresa = await nomeEmpresa(bid)
  return { sim, manual, cfg: e.cfg, empresa, termos: termos(sim, empresa, e.cfg) }
}
async function gerarParcelas(t: Db, op: { id: number; business_id: number; user_id: number }, sim: Simulacao, hoje: string) {
  const lin: { numero: number; valor: number; vencimento: string }[] = [...(sim.entrada > 0 ? [{ numero: 0, valor: sim.entrada, vencimento: hoje }] : []), ...sim.parcelas]
  for (const p of lin) await t.query('INSERT INTO credito_parcelas (operacao_id, business_id, user_id, numero, valor, vencimento, status, historico, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)', [op.id, op.business_id, op.user_id, p.numero, p.valor, p.vencimento, 'pendente', JSON.stringify([{ em: nowIso(), acao: 'criada', valor: p.valor, vencimento: p.vencimento }]), nowIso()])
}
/** Depois do pedido criado: grava a operação (uma por pedido), sob trava do cliente e com o limite conferido de novo. */
export async function registrarCompra(orderId: number, bid: number, uid: number, prep: Preparo) {
  return withLock(`credito:${bid}:${uid}`, async () => {
    const hoje = await hojeDa(bid)
    return db().tx(async (t) => {
      const ja = (await t.query('SELECT * FROM credito_operacoes WHERE idem_key = $1', [`pedido:${orderId}`]))[0]; if (ja) return ja
      const u = await usoCliente(bid, uid, hoje, 0, t)
      if (u.situacao !== 'ativo' || prep.sim.principal > u.disponivel + 0.001) fail(400, `Limite insuficiente: você tem ${brl(u.disponivel)} disponíveis.`, 'credito_limite')
      // a simulação gravada é refeita na data de hoje (aprovação automática) ou na data da aprovação (manual)
      const sim = prep.manual ? prep.sim : simular(prep.cfg, prep.sim.valorCompra, prep.sim.nParcelas, prep.sim.entrada, hoje)
      const cond = { sim, cfg: prep.cfg, termos: prep.termos, aceitoEm: nowIso(), empresa: prep.empresa }
      const [op] = await t.query('INSERT INTO credito_operacoes (business_id, user_id, order_id, status, valor_compra, entrada, principal, juros, total_parcelado, n_parcelas, condicoes, idem_key, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$13) RETURNING *',
        [bid, uid, orderId, prep.manual ? 'pendente' : 'ativa', sim.valorCompra, sim.entrada, sim.principal, sim.juros, sim.totalParcelado, sim.nParcelas, JSON.stringify(cond), `pedido:${orderId}`, nowIso()])
      if (!prep.manual) await gerarParcelas(t, { id: Number(op.id), business_id: bid, user_id: uid }, sim, hoje)
      await evento(t, bid, prep.manual ? 'solicitacao_criada' : 'compra_aprovada_automatica', { pedido: orderId, valor: sim.valorCompra, entrada: sim.entrada, parcelas: sim.nParcelas, totalFinal: sim.totalFinal }, { cliente: uid, operacao: Number(op.id), ator: uid })
      return op
    })
  })
}
/** Avisos depois que o pedido ficou definitivo (fora da transação). */
export async function avisarCompra(op: any, orderId: number) {
  const bid = Number(op.business_id), uid = Number(op.user_id), emp = await nomeEmpresa(bid), c = J<any>(op.condicoes, {})
  if (op.status === 'pendente') {
    await avisar(uid, `Solicitação de crédito enviada · pedido #${orderId}`, `${emp} vai analisar: ${c.sim?.resumo || ''}`, `credito:solicitada:${op.id}`)
    await avisar(await donoDe(bid), `Nova solicitação de Crédito da Loja · pedido #${orderId}`, `${c.sim ? brl(c.sim.principal) + ' a parcelar em ' + c.sim.nParcelas + 'x' : ''} · aprove ou recuse em Sua empresa → Crédito da Loja`, `credito:solicitacao-loja:${op.id}`, '/x/sua-empresa')
  } else await avisar(uid, `Compra realizada com Crédito da Loja · pedido #${orderId}`, `${emp} · ${c.sim?.resumo || ''}`, `credito:compra:${op.id}`)
}

/* ---------------- aprovação / rejeição (dono da empresa) ---------------- */
export async function decidir(bid: number, opId: number, decisao: string, motivo: string, ator: { id: number; nome: string }) {
  if (!['aprovar', 'rejeitar'].includes(decisao)) fail(400, 'Decisão inválida.', 'invalid')
  if (decisao === 'rejeitar' && !motivo) fail(400, 'Informe o motivo da recusa: ele aparece para o cliente.', 'invalid', 'motivo')
  const op0 = await one('SELECT * FROM credito_operacoes WHERE id = $1 AND business_id = $2', [opId, bid])
  if (!op0) fail(404, 'Solicitação não encontrada.', 'not_found')
  const uid = Number(op0!.user_id)
  const r = await withLock(`credito:${bid}:${uid}`, async () => {
    const hoje = await hojeDa(bid)
    return db().tx(async (t) => {
      const op = (await t.query('SELECT * FROM credito_operacoes WHERE id = $1 AND business_id = $2', [opId, bid]))[0]
      if (op.status !== 'pendente') fail(409, 'Esta solicitação já foi decidida.', 'conflito')
      const ord = op.order_id ? (await t.query('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(op.order_id), bid]))[0] : null
      const c = J<any>(op.condicoes, {})
      if (decisao === 'aprovar') {
        exigirOperavel(await estadoEmpresa(bid), 'aprovar crédito')
        const u = await usoCliente(bid, uid, hoje, opId, t)
        if (u.situacao !== 'ativo') fail(400, 'O crédito deste cliente está suspenso. Libere o cliente antes de aprovar.', 'credito_suspenso')
        if (num(op.principal) > u.disponivel + 0.001) fail(400, `Limite insuficiente para aprovar: o cliente tem ${brl(u.disponivel)} disponíveis e a compra precisa de ${brl(num(op.principal))}.`, 'credito_limite')
        if (!ord || ord.status !== 'aguardando_credito') fail(409, 'O pedido desta solicitação não está mais aguardando aprovação.', 'conflito')
        const sim = simular(normEmpresa(c.cfg, await globalCfg()), num(op.valor_compra), Number(op.n_parcelas), num(op.entrada), hoje) // mesmas regras aceitas, datas a partir de hoje
        await gerarParcelas(t, { id: opId, business_id: bid, user_id: uid }, sim, hoje)
        await t.query("UPDATE credito_operacoes SET status = 'ativa', juros = $1, total_parcelado = $2, condicoes = $3, decidido_por = $4, decidido_em = $5, updated_at = $5 WHERE id = $6", [sim.juros, sim.totalParcelado, JSON.stringify({ ...c, sim }), ator.id, nowIso(), opId])
        const d = J<any>(ord.data, {}); d.andamento = [...(Array.isArray(d.andamento) ? d.andamento : []), { status: 'novo', em: nowIso() }].slice(-20); d.credito = { ...(d.credito || {}), status: 'ativa', resumo: sim.resumo, totalFinal: sim.totalFinal }
        await t.query("UPDATE orders SET status = 'novo', data = $1, updated_at = $2 WHERE id = $3 AND status = 'aguardando_credito'", [JSON.stringify(d), nowIso(), ord.id])
        await evento(t, bid, 'solicitacao_aprovada', { pedido: Number(ord.id), totalFinal: sim.totalFinal }, { cliente: uid, operacao: opId, ator: ator.id })
        return { acao: 'aprovada', ord, sim, total: Number(ord.total), d }
      }
      await t.query("UPDATE credito_operacoes SET status = 'rejeitada', motivo = $1, decidido_por = $2, decidido_em = $3, updated_at = $3 WHERE id = $4", [motivo, ator.id, nowIso(), opId])
      if (ord && ord.status === 'aguardando_credito') { const d = J<any>(ord.data, {}); d.motivo = motivo; d.andamento = [...(Array.isArray(d.andamento) ? d.andamento : []), { status: 'recusado', em: nowIso() }].slice(-20); d.credito = { ...(d.credito || {}), status: 'rejeitada' }; await t.query("UPDATE orders SET status = 'recusado', data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify(d), nowIso(), ord.id]) }
      await evento(t, bid, 'solicitacao_rejeitada', { pedido: ord ? Number(ord.id) : null, motivo }, { cliente: uid, operacao: opId, ator: ator.id })
      return { acao: 'rejeitada', ord }
    })
  })
  const emp = await nomeEmpresa(bid), oid = r.ord ? Number(r.ord.id) : 0
  if (r.acao === 'aprovada') {
    await avisar(uid, `Crédito aprovado · pedido #${oid}`, `${emp} · ${r.sim!.resumo}`, `credito:aprovado:${opId}`)
    const d = r.d!
    await (await import('./recebimento-pedidos.js')).avisarNovoPedido(bid, oid, { title: `Novo pedido #${oid} · R$ ${Number(r.total).toFixed(2).replace('.', ',')} · Crédito da Loja`, body: `${d.cliente || ''} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'}`, link: '/x/sua-empresa', ref: `order-new:${oid}` }).catch(() => {})
  } else {
    // o que o pedido reservou volta (cupom, estoque e moedas), como em qualquer pedido recusado
    if (oid) {
      await (await import('./coupons.js')).estornarPedido(oid).catch((e) => console.error('[cupons]', e?.message))
      await (await import('./catalogo.js')).devolverPedido(oid).catch((e) => console.error('[estoque]', e?.message))
      await (await import('./coins.js')).estornarPedido(oid).catch((e) => console.error('[moedas]', e?.message))
    }
    await avisar(uid, `Crédito não aprovado · pedido #${oid}`, `${emp} · ${motivo}. Nenhum valor foi cobrado e o limite reservado foi liberado.`, `credito:rejeitado:${opId}`)
  }
  const { audit } = await import('./account.js'); await audit(ator.id, `credito.solicitacao.${r.acao}`, bid, { operacao: opId, pedido: oid })
  return { ok: true, status: r.acao }
}
/** Pedido a crédito recusado/cancelado pela loja: parcelas em aberto canceladas e limite liberado (pagamentos já feitos ficam
 *  registrados — a devolução, se houver, é combinada entre loja e cliente e fica no histórico). */
export async function cancelarPorPedido(orderId: number, motivo: string, atorId: number) {
  const op0 = await one("SELECT * FROM credito_operacoes WHERE order_id = $1 AND status IN ('pendente','ativa')", [orderId]); if (!op0) return
  const bid = Number(op0.business_id), uid = Number(op0.user_id)
  await withLock(`credito:${bid}:${uid}`, () => db().tx(async (t) => {
    const op = (await t.query('SELECT * FROM credito_operacoes WHERE id = $1', [op0.id]))[0]; if (!['pendente', 'ativa'].includes(op.status)) return
    const pago = num((await t.query('SELECT COALESCE(SUM(valor_pago),0) AS v FROM credito_parcelas WHERE operacao_id = $1', [op.id]))[0]?.v)
    for (const p of await t.query("SELECT id, historico FROM credito_parcelas WHERE operacao_id = $1 AND status IN ('pendente','vencida')", [op.id]))
      await t.query("UPDATE credito_parcelas SET status = 'cancelada', historico = $1, updated_at = $2 WHERE id = $3", [JSON.stringify([...J<any[]>(p.historico, []), { em: nowIso(), acao: 'cancelada', motivo }].slice(-30)), nowIso(), p.id])
    await t.query("UPDATE credito_operacoes SET status = 'cancelada', motivo = $1, updated_at = $2 WHERE id = $3", [motivo, nowIso(), op.id])
    await evento(t, bid, 'operacao_cancelada', { pedido: orderId, motivo, valorJaPago: r2(pago) }, { cliente: uid, operacao: Number(op.id), ator: atorId })
  }))
}

/* ---------------- pagamentos ---------------- */
const FORMAS: Record<string, string> = { pix: 'Pix', dinheiro: 'Dinheiro', cartao: 'Cartão', transferencia: 'Transferência', outro: 'Outro' }
export async function registrarPagamento(bid: number, parcelaId: number, b: any, ator: { id: number; nome: string }) {
  const forma = String(b?.forma || '')
  if (!FORMAS[forma]) fail(400, 'Escolha a forma de pagamento.', 'invalid', 'forma')
  const idem = txt(b?.idem, 40); if (!idem) fail(400, 'Requisição sem identificador.', 'invalid')
  const e = await estadoEmpresa(bid)
  const r = await withLock(`credito:parcela:${parcelaId}`, () => db().tx(async (t) => {
    const ja = (await t.query('SELECT * FROM credito_pagamentos WHERE idem_key = $1', [`${parcelaId}:${idem}`]))[0]
    if (ja) return { pag: ja, duplicado: true } as any // mesmo toque enviado duas vezes: nada é registrado de novo
    const p = (await t.query('SELECT * FROM credito_parcelas WHERE id = $1 AND business_id = $2', [parcelaId, bid]))[0]
    if (!p) fail(404, 'Parcela não encontrada.', 'not_found')
    const op = (await t.query('SELECT * FROM credito_operacoes WHERE id = $1', [p.operacao_id]))[0]
    if (op.status !== 'ativa') fail(400, 'Esta compra não está ativa (quitada, cancelada ou aguardando aprovação).', 'invalid')
    if (!['pendente', 'vencida'].includes(p.status)) fail(400, p.status === 'paga' ? 'Esta parcela já está paga.' : 'Esta parcela foi cancelada.', 'invalid')
    const resta = r2(num(p.valor) - num(p.valor_pago))
    const valor = b?.valor === undefined || b?.valor === null || b?.valor === '' ? resta : r2(num(b.valor, NaN))
    if (!Number.isFinite(valor) || valor <= 0) fail(400, 'Informe um valor maior que zero.', 'invalid', 'valor')
    if (valor > resta + 0.001) fail(400, `O valor passa do que falta nesta parcela (${brl(resta)}).`, 'invalid', 'valor')
    const parcial = valor < resta - 0.001
    if (parcial && !e.cfg.permitirParcial) fail(400, `Pagamento parcial não é permitido pelas regras do crédito. Registre o valor total (${brl(resta)}).`, 'invalid', 'valor')
    const [pag] = await t.query('INSERT INTO credito_pagamentos (parcela_id, operacao_id, business_id, user_id, valor, forma, registrado_por, idem_key, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *', [parcelaId, op.id, bid, op.user_id, valor, forma, ator.id, `${parcelaId}:${idem}`, nowIso()])
    const novoPago = r2(num(p.valor_pago) + valor), quit = !parcial
    await t.query('UPDATE credito_parcelas SET valor_pago = $1, status = $2, pago_em = $3, forma = $4, historico = $5, updated_at = $6 WHERE id = $7',
      [novoPago, quit ? 'paga' : p.status, quit ? nowIso() : p.pago_em, forma, JSON.stringify([...J<any[]>(p.historico, []), { em: nowIso(), acao: quit ? 'paga' : 'pagamento_parcial', valor, forma, por: ator.nome }].slice(-30)), nowIso(), parcelaId])
    const abertas = Number((await t.query("SELECT COUNT(*) AS n FROM credito_parcelas WHERE operacao_id = $1 AND status IN ('pendente','vencida')", [op.id]))[0]?.n || 0)
    if (!abertas) await t.query("UPDATE credito_operacoes SET status = 'quitada', updated_at = $1 WHERE id = $2", [nowIso(), op.id])
    await evento(t, bid, parcial ? 'pagamento_parcial' : 'pagamento', { parcela: Number(p.numero), valor, forma, restante: r2(resta - valor) }, { cliente: Number(op.user_id), operacao: Number(op.id), ator: ator.id })
    return { pag, p, op, valor, quit, quitada: !abertas, restante: r2(resta - valor) }
  }))
  if (r.duplicado) return { ok: true, duplicado: true, pagamentoId: Number(r.pag.id) }
  await lancarFinanceiro(Number(r.pag.id)).catch((x) => console.error('[credito] financeiro:', x?.message))
  const emp = await nomeEmpresa(bid), np = Number(r.p.numero), oid = Number(r.op.order_id || 0)
  await avisar(Number(r.op.user_id), `Pagamento registrado · ${np === 0 ? 'entrada' : `parcela ${np}/${r.op.n_parcelas}`}`, `${emp} · ${brl(r.valor)} (${FORMAS[forma]})${r.restante > 0 ? ` · faltam ${brl(r.restante)} desta parcela` : ''}${oid ? ` · pedido #${oid}` : ''}`, `credito:pag:${r.pag.id}`)
  if (r.quitada) await avisar(Number(r.op.user_id), `Crédito quitado · pedido #${oid}`, `${emp} · todas as parcelas foram pagas.`, `credito:quitado:${r.op.id}`)
  return { ok: true, pagamentoId: Number(r.pag.id), parcial: !r.quit, restante: r.restante, quitada: r.quitada }
}
/** Lançamento de receita no financeiro do dono — um por pagamento (o pedido a crédito não lança a venda inteira). */
export async function lancarFinanceiro(pagId: number) {
  return withLock(`credito:fin:${pagId}`, async () => {
    const pg = await one('SELECT * FROM credito_pagamentos WHERE id = $1', [pagId]); if (!pg || pg.fin_item_id) return pg?.fin_item_id ?? null
    const ow = await one('SELECT u.*, b.data AS bdata FROM credito_pagamentos p JOIN businesses b ON b.id = p.business_id JOIN users u ON u.id = b.owner_id WHERE p.id = $1', [pagId]); if (!ow) return null
    const { hydrateUser } = await import('./session.js'), { settingsOf } = await import('./account.js'), { createItem } = await import('../routes/items.js')
    const user = hydrateUser(ow), op = await one('SELECT order_id, n_parcelas FROM credito_operacoes WHERE id = $1', [pg.operacao_id]), par = await one('SELECT numero FROM credito_parcelas WHERE id = $1', [pg.parcela_id])
    const cli = await one('SELECT name FROM users WHERE id = $1', [pg.user_id]), emp = String(J<any>(ow.bdata, {}).empresa || 'Empresa')
    const np = Number(par?.numero || 0)
    const [it] = await createItem(user, 'expense', { kind: 'income', amount: r2(num(pg.valor)), category: 'vendas', date: localDate(settingsOf(user).timezone), method: FORMAS[String(pg.forma)] || '', source: `credito:pag:${pagId}`, description: `Crédito da Loja · ${np === 0 ? 'entrada' : `parcela ${np}/${op?.n_parcelas || '?'}`}${op?.order_id ? ` · pedido #${op.order_id}` : ''} · ${emp} · ${cli?.name || ''}`.trim() })
    await q('UPDATE credito_pagamentos SET fin_item_id = $1 WHERE id = $2 AND fin_item_id IS NULL', [Number(it.id), pagId])
    return Number(it.id)
  })
}

/* ---------------- limites por cliente (dono da empresa) ---------------- */
export async function salvarCliente(bid: number, b: any, ator: { id: number; nome: string }) {
  const e = await estadoEmpresa(bid); exigirOperavel(e, 'conceder ou alterar crédito')
  const uid = Math.floor(num(b?.userId, 0)); if (!(uid > 0)) fail(400, 'Escolha o cliente.', 'invalid')
  const owner = await donoDe(bid); if (uid === owner) fail(400, 'O dono da empresa não pode receber crédito da própria loja.', 'invalid')
  if (!(await one('SELECT id FROM users WHERE id = $1', [uid]))) fail(404, 'Cliente não encontrado.', 'not_found')
  const teto = Math.min(e.cfg.limiteMaxCliente, e.g.limiteMaxCliente)
  const atual = await one('SELECT * FROM credito_clientes WHERE business_id = $1 AND user_id = $2', [bid, uid])
  const limite = b?.limite === undefined ? r2(num(atual?.limite, e.cfg.limitePadrao)) : r2(num(b.limite, NaN))
  if (!Number.isFinite(limite) || limite < 0) fail(400, 'Informe um limite válido.', 'invalid', 'limite')
  if (limite > teto + 0.001) fail(400, `O limite por cliente vai até ${brl(teto)}.`, 'invalid', 'limite')
  const situacao = b?.situacao === undefined ? String(atual?.situacao || 'ativo') : String(b.situacao)
  if (!['ativo', 'suspenso'].includes(situacao)) fail(400, 'Situação inválida.', 'invalid')
  const obs = b?.observacao === undefined ? String(atual?.observacao || '') : txt(b.observacao, 300)
  // condições próprias do cliente (aprovação de solicitação): validadas contra os tetos do ADM; vazio = regras da empresa
  let cond = J<any>(atual?.condicoes, {})
  if (b?.condicoes !== undefined) { const ov: any = {}; for (const k of CHAVES_CLIENTE) if (b.condicoes?.[k] !== undefined && b.condicoes[k] !== null && b.condicoes[k] !== '') ov[k] = b.condicoes[k]; const n = cfgDoCliente(e.cfg, e.g, ov, true); cond = Object.fromEntries(Object.keys(ov).map((k) => [k, (n as any)[k]])) }
  let validade = String(atual?.validade || '')
  if (b?.validade !== undefined) { validade = String(b.validade || ''); if (validade && (!/^\d{4}-\d{2}-\d{2}$/.test(validade) || validade < (await hojeDa(bid)))) fail(400, 'A validade precisa ser uma data futura.', 'invalid', 'validade') }
  const solId = b?.solicitacaoId ? Number(b.solicitacaoId) : (atual?.solicitacao_id ?? null)
  const tipos: string[] = []
  await withLock(`credito:${bid}:${uid}`, () => db().tx(async (t) => {
    if (atual) await t.query('UPDATE credito_clientes SET limite = $1, situacao = $2, observacao = $3, condicoes = $4, validade = $5, solicitacao_id = $6, updated_at = $7 WHERE id = $8', [limite, situacao, obs, JSON.stringify(cond), validade, solId, nowIso(), atual.id])
    else await t.query('INSERT INTO credito_clientes (business_id, user_id, limite, situacao, observacao, condicoes, validade, solicitacao_id, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [bid, uid, limite, situacao, obs, JSON.stringify(cond), validade, solId, ator.id, nowIso()])
    if (!atual) tipos.push('limite_concedido')
    else if (r2(num(atual.limite)) !== limite) tipos.push('limite_alterado')
    if (atual && atual.situacao !== situacao) tipos.push(situacao === 'suspenso' ? 'credito_suspenso' : 'credito_liberado')
    if (!atual && situacao === 'suspenso') tipos.push('credito_suspenso')
    if (atual && (JSON.stringify(cond) !== String(atual.condicoes || '{}') || validade !== String(atual.validade || ''))) tipos.push('condicoes_alteradas')
    for (const tp of tipos) await evento(t, bid, tp, { de: atual ? r2(num(atual.limite)) : null, para: limite, situacao }, { cliente: uid, ator: ator.id })
  }))
  const emp = await nomeEmpresa(bid), stamp = Date.now().toString(36)
  if (tipos.includes('credito_suspenso')) await avisar(uid, `Crédito suspenso · ${emp}`, 'Novas compras a crédito nesta loja estão suspensas. As parcelas em aberto continuam valendo.', `credito:susp:${bid}:${uid}:${stamp}`)
  else if (b?.silencioso) { /* a aprovação da solicitação manda o próprio aviso */ }
  else if (tipos.some((x) => ['limite_concedido', 'limite_alterado', 'credito_liberado'].includes(x))) await avisar(uid, `Limite de crédito ${tipos.includes('limite_concedido') ? 'liberado' : 'atualizado'} · ${emp}`, `Seu limite no Crédito da Loja agora é ${brl(limite)}.`, `credito:limite:${bid}:${uid}:${stamp}`)
  return { ok: true, cliente: { userId: uid, condicoes: cond, ...(await usoCliente(bid, uid)) } }
}
/** Busca de clientes da empresa: quem já comprou/agendou ou está no CRM (com conta no app); fora disso, só por e-mail ou
 *  WhatsApp exatos (sem listar contas de outras pessoas). */
export async function buscarClientes(bid: number, termo: string) {
  const t = txt(termo, 80).toLowerCase(), dig = t.replace(/\D/g, '')
  const rel = await q(`SELECT DISTINCT u.id, u.name, u.email, u.whatsapp FROM users u WHERE u.id IN (SELECT customer_id FROM orders WHERE business_id = $1 AND customer_id IS NOT NULL UNION SELECT user_id FROM crm_contacts WHERE business_id = $1 AND user_id IS NOT NULL UNION SELECT user_id FROM credito_clientes WHERE business_id = $1) LIMIT 2000`, [bid])
  const owner = await donoDe(bid)
  let lista = rel.filter((u: any) => Number(u.id) !== owner && (!t || String(u.name || '').toLowerCase().includes(t) || String(u.email || '').toLowerCase().includes(t) || (dig.length >= 4 && String(u.whatsapp || '').replace(/\D/g, '').includes(dig))))
  if (!lista.length && t) {
    const ex = /@/.test(t) ? await q('SELECT id, name, email, whatsapp FROM users WHERE LOWER(email) = $1 LIMIT 1', [t]) : dig.length >= 10 ? (await q("SELECT id, name, email, whatsapp FROM users WHERE whatsapp IS NOT NULL LIMIT 5000")).filter((u: any) => { const w = String(u.whatsapp).replace(/\D/g, ''); return w === dig || w.endsWith(dig) || dig.endsWith(w.slice(-10)) }).slice(0, 1) : []
    lista = ex.filter((u: any) => Number(u.id) !== owner)
  }
  const ids = new Set((await q('SELECT user_id FROM credito_clientes WHERE business_id = $1', [bid])).map((r: any) => Number(r.user_id)))
  return lista.slice(0, 30).map((u: any) => ({ id: Number(u.id), nome: String(u.name || ''), email: String(u.email || ''), whatsapp: String(u.whatsapp || ''), temCredito: ids.has(Number(u.id)) }))
}

/* ---------------- leitura: empresa, cliente, ADM ---------------- */
const opOut = (o: any) => { const c = J<any>(o.condicoes, {}); return { id: Number(o.id), pedido: o.order_id ? Number(o.order_id) : null, status: String(o.status), valorCompra: num(o.valor_compra), entrada: num(o.entrada), principal: num(o.principal), juros: num(o.juros), totalParcelado: num(o.total_parcelado), totalFinal: r2(num(o.entrada) + num(o.total_parcelado)), nParcelas: Number(o.n_parcelas), resumo: c.sim?.resumo || '', termos: c.termos || [], simulacao: c.sim || null, motivo: String(o.motivo || ''), criadaEm: o.created_at, decididaEm: o.decidido_em || null } }
const parOut = (p: any, hoje: string) => ({ id: Number(p.id), operacaoId: Number(p.operacao_id), numero: Number(p.numero), valor: num(p.valor), valorPago: num(p.valor_pago), restante: r2(num(p.valor) - num(p.valor_pago)), vencimento: String(p.vencimento), status: p.status === 'pendente' && String(p.vencimento) < hoje ? 'vencida' : String(p.status), pagoEm: p.pago_em || null, forma: String(p.forma || ''), historico: J<any[]>(p.historico, []) })
function periodo(de: string, ate: string, hoje: string) {
  const ok = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s)
  const a = ok(ate) ? ate : hoje, d = ok(de) ? de : addDias(a, -29)
  return d <= a ? { de: d, ate: a } : { de: a, ate: d }
}
/** Painel financeiro do Crédito da Loja de UMA empresa (só o dono chama). */
export async function painelEmpresa(bid: number, de = '', ate = '') {
  const e = await estadoEmpresa(bid), hoje = await hojeDa(bid), P = periodo(de, ate, hoje)
  const clientesR = await q('SELECT c.*, u.name, u.email, u.whatsapp FROM credito_clientes c JOIN users u ON u.id = c.user_id WHERE c.business_id = $1 ORDER BY u.name', [bid])
  const clientes = [] as any[]
  for (const c of clientesR) clientes.push({ userId: Number(c.user_id), nome: String(c.name || ''), email: String(c.email || ''), whatsapp: String(c.whatsapp || ''), observacao: String(c.observacao || ''), condicoes: J<any>(c.condicoes, {}), solicitacaoId: c.solicitacao_id ? Number(c.solicitacao_id) : null, ...(await usoCliente(bid, Number(c.user_id), hoje)) })
  const pars = (await q("SELECT p.*, u.name AS cliente, o.order_id FROM credito_parcelas p JOIN users u ON u.id = p.user_id JOIN credito_operacoes o ON o.id = p.operacao_id WHERE p.business_id = $1 AND p.status IN ('pendente','vencida')", [bid])).map((p: any) => ({ ...parOut(p, hoje), cliente: String(p.cliente || ''), userId: Number(p.user_id), pedido: p.order_id ? Number(p.order_id) : null }))
  const recebido = r2(num((await one('SELECT COALESCE(SUM(valor),0) AS v FROM credito_pagamentos WHERE business_id = $1', [bid]))?.v))
  const kpis = {
    totalConcedido: r2(clientes.filter((c) => c.situacao === 'ativo').reduce((a, c) => a + c.limite, 0)),
    totalUtilizado: r2(clientes.reduce((a, c) => a + c.utilizado, 0)), totalReservado: r2(clientes.reduce((a, c) => a + c.reservado, 0)),
    totalAReceber: r2(pars.reduce((a, p) => a + p.restante, 0)), totalRecebido: recebido,
    totalVencido: r2(pars.filter((p) => p.status === 'vencida').reduce((a, p) => a + p.restante, 0)),
    clientesComCredito: clientes.filter((c) => c.situacao === 'ativo').length,
  }
  const lim7 = addDias(hoje, 7)
  const proximas = pars.filter((p) => p.status === 'pendente' && p.vencimento >= hoje && p.vencimento <= lim7).sort((a, b) => a.vencimento.localeCompare(b.vencimento))
  const inad = new Map<number, any>()
  for (const p of pars.filter((x) => x.status === 'vencida')) { const k = inad.get(p.userId) || { userId: p.userId, nome: p.cliente, vencido: 0, parcelas: 0, maisAntiga: p.vencimento }; k.vencido = r2(k.vencido + p.restante); k.parcelas++; if (p.vencimento < k.maisAntiga) k.maisAntiga = p.vencimento; inad.set(p.userId, k) }
  const inadimplentes = [...inad.values()].map((k) => ({ ...k, diasAtraso: Math.round((Date.parse(hoje) - Date.parse(k.maisAntiga)) / 86400000) })).sort((a, b) => b.vencido - a.vencido)
  const opsR = await q('SELECT o.*, u.name AS cliente FROM credito_operacoes o JOIN users u ON u.id = o.user_id WHERE o.business_id = $1 ORDER BY o.id DESC LIMIT 200', [bid])
  const saldoOp = new Map<number, number>(); for (const p of pars) saldoOp.set(p.operacaoId, r2((saldoOp.get(p.operacaoId) || 0) + p.restante))
  const operacoes = opsR.map((o: any) => ({ ...opOut(o), cliente: String(o.cliente || ''), userId: Number(o.user_id), saldo: saldoOp.get(Number(o.id)) || 0 }))
  const solicitacoes = operacoes.filter((o) => o.status === 'pendente')
  // relatório do período (datas no fuso da empresa; criado_em em ISO UTC — comparação pelo dia)
  const noP = (iso: any) => { const d = String(iso || '').slice(0, 10); return d >= P.de && d <= P.ate }
  const pagsP = (await q('SELECT valor, created_at FROM credito_pagamentos WHERE business_id = $1', [bid])).filter((r: any) => noP(r.created_at))
  const opsP = operacoes.filter((o) => noP(o.criadaEm))
  const relatorio = {
    ...P, compras: opsP.filter((o) => ['ativa', 'quitada'].includes(o.status)).length, solicitadas: opsP.length,
    valorFinanciado: r2(opsP.filter((o) => ['ativa', 'quitada', 'pendente'].includes(o.status)).reduce((a, o) => a + o.principal, 0)),
    juros: r2(opsP.filter((o) => ['ativa', 'quitada'].includes(o.status)).reduce((a, o) => a + o.juros, 0)),
    recebido: r2(pagsP.reduce((a: number, r: any) => a + num(r.valor), 0)), pagamentos: pagsP.length,
    rejeitadas: opsP.filter((o) => o.status === 'rejeitada').length, canceladas: opsP.filter((o) => o.status === 'cancelada').length,
    vencendoNoPeriodo: r2(pars.filter((p) => p.vencimento >= P.de && p.vencimento <= P.ate).reduce((a, p) => a + p.restante, 0)),
  }
  return { estado: { global: e.g.ativo, situacao: e.situacao, operavel: e.operavel, paraClientes: e.paraClientes, motivo: e.motivo }, config: e.cfg, tetos: { maxParcelas: e.g.maxParcelas, jurosMaxMes: e.g.jurosMaxMes, jurosMaxTotal: e.g.jurosMaxTotal, limiteMaxCliente: e.g.limiteMaxCliente, entradaMinPct: e.g.entradaMinPct, permitirParcial: e.g.permitirParcial }, hoje, kpis, proximas, inadimplentes, solicitacoes, operacoes, clientes, relatorio }
}
export async function operacaoEmpresa(bid: number, opId: number) {
  const o = await one('SELECT o.*, u.name AS cliente, u.whatsapp FROM credito_operacoes o JOIN users u ON u.id = o.user_id WHERE o.id = $1 AND o.business_id = $2', [opId, bid])
  if (!o) fail(404, 'Operação não encontrada.', 'not_found')
  const hoje = await hojeDa(bid)
  const parcelas = (await q('SELECT * FROM credito_parcelas WHERE operacao_id = $1 ORDER BY numero', [opId])).map((p: any) => parOut(p, hoje))
  const pagamentos = (await q('SELECT id, parcela_id, valor, forma, created_at FROM credito_pagamentos WHERE operacao_id = $1 ORDER BY id', [opId])).map((p: any) => ({ id: Number(p.id), parcelaId: Number(p.parcela_id), valor: num(p.valor), forma: FORMAS[String(p.forma)] || String(p.forma), em: p.created_at }))
  const eventos = (await q('SELECT tipo, dados, created_at FROM credito_eventos WHERE operacao_id = $1 ORDER BY id', [opId])).map((r: any) => ({ tipo: String(r.tipo), dados: J<any>(r.dados, {}), em: r.created_at }))
  return { operacao: { ...opOut(o!), cliente: String(o!.cliente || ''), userId: Number(o!.user_id), whatsapp: String(o!.whatsapp || '') }, parcelas, pagamentos, eventos, permitirParcial: (await estadoEmpresa(bid)).cfg.permitirParcial }
}
export async function historicoCliente(bid: number, uid: number) {
  const hoje = await hojeDa(bid)
  const ops = (await q('SELECT * FROM credito_operacoes WHERE business_id = $1 AND user_id = $2 ORDER BY id DESC LIMIT 100', [bid, uid])).map(opOut)
  const pars = (await q('SELECT * FROM credito_parcelas WHERE business_id = $1 AND user_id = $2 ORDER BY operacao_id DESC, numero', [bid, uid])).map((p: any) => parOut(p, hoje))
  const pagamentos = (await q('SELECT p.id, p.valor, p.forma, p.created_at, pa.numero, o.order_id FROM credito_pagamentos p JOIN credito_parcelas pa ON pa.id = p.parcela_id JOIN credito_operacoes o ON o.id = p.operacao_id WHERE p.business_id = $1 AND p.user_id = $2 ORDER BY p.id DESC LIMIT 200', [bid, uid])).map((r: any) => ({ id: Number(r.id), valor: num(r.valor), forma: FORMAS[String(r.forma)] || String(r.forma), em: r.created_at, parcela: Number(r.numero), pedido: r.order_id ? Number(r.order_id) : null }))
  const eventos = (await q('SELECT tipo, dados, created_at FROM credito_eventos WHERE business_id = $1 AND cliente_id = $2 ORDER BY id DESC LIMIT 100', [bid, uid])).map((r: any) => ({ tipo: String(r.tipo), dados: J<any>(r.dados, {}), em: r.created_at }))
  const u = await one('SELECT name, email, whatsapp FROM users WHERE id = $1', [uid])
  return { cliente: { userId: uid, nome: String(u?.name || ''), email: String(u?.email || ''), whatsapp: String(u?.whatsapp || ''), ...(await usoCliente(bid, uid, hoje)) }, operacoes: ops.map((o) => ({ ...o, parcelas: pars.filter((p) => p.operacaoId === o.id) })), pagamentos, eventos }
}
/** O cliente vê SÓ o próprio crédito, em todas as lojas onde tem limite ou compras. */
export async function meuCredito(uid: number) {
  const bids = [...new Set([...(await q('SELECT business_id FROM credito_clientes WHERE user_id = $1', [uid])), ...(await q('SELECT DISTINCT business_id FROM credito_operacoes WHERE user_id = $1', [uid]))].map((r: any) => Number(r.business_id)))]
  const lojas = [] as any[]
  for (const bid of bids) {
    const e = await estadoEmpresa(bid), hoje = await hojeDa(bid), uso = await usoCliente(bid, uid, hoje)
    const ops = (await q('SELECT * FROM credito_operacoes WHERE business_id = $1 AND user_id = $2 ORDER BY id DESC LIMIT 60', [bid, uid])).map(opOut)
    const pars = (await q('SELECT * FROM credito_parcelas WHERE business_id = $1 AND user_id = $2 ORDER BY numero', [bid, uid])).map((p: any) => parOut(p, hoje))
    const cc = await cfgClienteDe(bid, uid, e)
    lojas.push({ businessId: bid, empresa: await nomeEmpresa(bid), disponivelParaCompras: e.paraClientes && uso.situacao === 'ativo' && !uso.expirado, condicoes: { parcelas: cc.parcelas, jurosTipo: cc.jurosTipo, taxa: cc.taxa, semJurosAte: cc.semJurosAte, entradaMinPct: cc.entradaMinPct, condicoesCliente: cc.condicoesCliente || '' }, ...uso, disponivel: e.paraClientes ? uso.disponivel : 0, operacoes: ops.map((o) => ({ ...o, termos: undefined, parcelas: pars.filter((p) => p.operacaoId === o.id).map((p) => ({ ...p, historico: undefined })) })) })
  }
  return { lojas }
}
/** Opções para o checkout (cliente logado): disponibilidade e regras públicas; simulações se vier o valor. */
export async function opcoesCheckout(bid: number, uid: number, valor?: number) {
  const e = await estadoEmpresa(bid)
  if (!e.paraClientes) return { disponivel: false }
  const uso = await usoCliente(bid, uid), podeSolicitar = e.cfg.aceitarSolicitacoes
  const sol = await one("SELECT id, status FROM credito_solicitacoes WHERE business_id = $1 AND user_id = $2 AND status IN ('rascunho','pendente','info_solicitada') ORDER BY id DESC LIMIT 1", [bid, uid])
  const solicitacao = sol ? { id: Number(sol.id), status: String(sol.status) } : null
  if (uso.situacao !== 'ativo' || uso.expirado) return { disponivel: false, podeSolicitar, solicitacao, motivo: uso.situacao === 'suspenso' ? 'Seu crédito nesta loja está suspenso.' : uso.expirado ? `Seu limite nesta loja venceu em ${brData(uso.validade)}.` : '' }
  const c = await cfgClienteDe(bid, uid, e), hoje = await hojeDa(bid)
  const base = { disponivel: true, limiteDisponivel: uso.disponivel, emAtraso: uso.vencido > 0, parcelas: c.parcelas, entradaMinPct: c.entradaMinPct, jurosTipo: c.jurosTipo, taxa: c.taxa, semJurosAte: c.semJurosAte, primeiraParcela: c.primeiraParcela, compraMin: c.compraMin, compraMax: c.compraMax, aprovacao: c.aprovacao, aprovacaoAutoAte: c.aprovacaoAutoAte, condicoes: c.condicoes, condicoesCliente: c.condicoesCliente || '', validade: uso.validade, podeSolicitar, solicitacao, empresa: await nomeEmpresa(bid) }
  if (!(Number(valor) > 0)) return base
  return { ...base, simulacoes: c.parcelas.map((n) => simular(c, Number(valor), n, 0, hoje)) }
}
export async function simularCheckout(bid: number, uid: number, b: any) {
  const e0 = await estadoEmpresa(bid); exigirOperavel(e0, 'simular o crédito'); if (!e0.cfg.ativo) fail(400, 'Esta loja não está oferecendo o Crédito da Loja agora.', 'credito_indisponivel')
  const e = { ...e0, cfg: await cfgClienteDe(bid, uid, e0) }
  const v = r2(num(b?.valor, 0)), n = Math.floor(num(b?.parcelas, 0))
  if (!(v > 0)) fail(400, 'Valor inválido.', 'invalid')
  if (!e.cfg.parcelas.includes(n)) fail(400, 'Escolha uma quantidade de parcelas oferecida pela loja.', 'invalid')
  const sim = simular(e.cfg, v, n, num(b?.entrada, 0), await hojeDa(bid)), uso = await usoCliente(bid, uid), empresa = await nomeEmpresa(bid)
  const avisos: string[] = []
  if (v < e.cfg.compraMin) avisos.push(`O Crédito da Loja vale para compras a partir de ${brl(e.cfg.compraMin)}.`)
  if (v > e.cfg.compraMax) avisos.push(`O Crédito da Loja vale para compras de até ${brl(e.cfg.compraMax)}.`)
  if (uso.situacao !== 'ativo') avisos.push('Você não tem crédito liberado nesta loja.')
  else if (uso.expirado) avisos.push(`Seu limite nesta loja venceu em ${brData(uso.validade)}.`)
  if (uso.vencido > 0) avisos.push('Há parcelas em atraso no seu crédito desta loja. Regularize para fazer novas compras a crédito.')
  if (sim.principal <= 0) avisos.push('Com essa entrada não sobra valor para parcelar.')
  else if (sim.principal > uso.disponivel + 0.001) avisos.push(`Limite insuficiente: você tem ${brl(uso.disponivel)} disponíveis e o valor a parcelar é ${brl(sim.principal)}. Aumente a entrada ou escolha outra forma de pagamento.`)
  const manual = e.cfg.aprovacao === 'manual' || (e.cfg.aprovacao === 'ate_valor' && sim.principal > e.cfg.aprovacaoAutoAte)
  return { simulacao: sim, termos: termos(sim, empresa, e.cfg), aprovacaoManual: manual, limiteDisponivel: uso.disponivel, podeContratar: !avisos.length, avisos }
}

/* ---------------- ADM ---------------- */
async function estatEmpresa(bid: number, hoje: string) {
  const cl = await q("SELECT user_id, limite, situacao FROM credito_clientes WHERE business_id = $1", [bid])
  const pars = await q("SELECT valor, valor_pago, status, vencimento, user_id FROM credito_parcelas WHERE business_id = $1 AND status IN ('pendente','vencida')", [bid])
  const aberto = pars.reduce((a: number, p: any) => a + (num(p.valor) - num(p.valor_pago)), 0)
  const venc = pars.filter((p: any) => p.status === 'vencida' || String(p.vencimento) < hoje)
  const ops = await q("SELECT status, principal FROM credito_operacoes WHERE business_id = $1", [bid])
  return {
    clientes: cl.filter((c: any) => c.situacao === 'ativo').length, concedido: r2(cl.filter((c: any) => c.situacao === 'ativo').reduce((a: number, c: any) => a + num(c.limite), 0)),
    movimentado: r2(ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).reduce((a: number, o: any) => a + num(o.principal), 0)),
    operacoes: ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).length, pendentes: ops.filter((o: any) => o.status === 'pendente').length,
    aReceber: r2(aberto), parcelasAbertas: pars.length, vencido: r2(venc.reduce((a: number, p: any) => a + (num(p.valor) - num(p.valor_pago)), 0)),
    inadimplentes: new Set(venc.map((p: any) => Number(p.user_id))).size,
    recebido: r2(num((await one('SELECT COALESCE(SUM(valor),0) AS v FROM credito_pagamentos WHERE business_id = $1', [bid]))?.v)),
  }
}
export async function admVisao() {
  const g = await globalCfg(), hoje = localDate('America/Sao_Paulo')
  const rows = await q('SELECT c.business_id, c.situacao, c.config, c.motivo, c.updated_at, b.data, b.status AS bstatus FROM credito_empresas c JOIN businesses b ON b.id = c.business_id ORDER BY c.updated_at DESC')
  const empresas = [] as any[]
  for (const r of rows) empresas.push({ businessId: Number(r.business_id), empresa: String(J<any>(r.data, {}).empresa || ''), situacao: String(r.situacao), ativoNaEmpresa: !!normEmpresa(J<any>(r.config, {}), g).ativo, motivo: String(r.motivo || ''), atualizadoEm: r.updated_at, ...(await estatEmpresa(Number(r.business_id), hoje)) })
  const soma = (k: string) => r2(empresas.reduce((a, e) => a + num(e[k]), 0))
  return { config: g, empresas, totais: { habilitadas: empresas.filter((e) => e.situacao === 'autorizada').length, suspensas: empresas.filter((e) => e.situacao === 'suspensa').length, concedido: soma('concedido'), movimentado: soma('movimentado'), aReceber: soma('aReceber'), parcelasAbertas: soma('parcelasAbertas'), vencido: soma('vencido'), inadimplentes: soma('inadimplentes'), recebido: soma('recebido') } }
}
export async function admBuscarEmpresas(termo: string) {
  const t = txt(termo, 80).toLowerCase(); const { plans } = await import('../routes/ads.js'); const ps = await plans()
  const rows = await q("SELECT id, plan_id, data, status FROM businesses WHERE status = 'ativo' ORDER BY id DESC LIMIT 3000")
  const ja = new Map((await q('SELECT business_id, situacao FROM credito_empresas')).map((r: any) => [Number(r.business_id), String(r.situacao)]))
  return rows.map((b: any) => ({ id: Number(b.id), empresa: String(J<any>(b.data, {}).empresa || ''), nivel: Number(ps.find((p: any) => p.id === b.plan_id)?.nivel || 1), situacao: ja.get(Number(b.id)) || null }))
    .filter((b: any) => b.nivel >= 4 && (!t || b.empresa.toLowerCase().includes(t) || String(b.id) === t)).slice(0, 30)
}
export async function admAcaoEmpresa(bid: number, acao: string, motivo: string, ator: { id: number; nome: string }) {
  if (!['autorizar', 'suspender', 'revogar'].includes(acao)) fail(400, 'Ação inválida.', 'invalid')
  const b = await one('SELECT id, owner_id, plan_id, status, data FROM businesses WHERE id = $1', [bid]); if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  if (acao === 'autorizar') { const { plans } = await import('../routes/ads.js'); if (Number((await plans()).find((p: any) => p.id === b!.plan_id)?.nivel || 1) < 4) fail(400, 'Só empresas com loja e pedidos (plano com catálogo de compras) podem usar o Crédito da Loja.', 'invalid') }
  if (acao !== 'autorizar' && !motivo) fail(400, 'Informe o motivo (fica no histórico e é enviado à empresa).', 'invalid', 'motivo')
  const situacao: Situacao = acao === 'autorizar' ? 'autorizada' : acao === 'suspender' ? 'suspensa' : 'revogada'
  const atual = await one('SELECT * FROM credito_empresas WHERE business_id = $1', [bid])
  if (!atual && acao !== 'autorizar') fail(400, 'Esta empresa não tem o Crédito da Loja.', 'invalid')
  await db().tx(async (t) => {
    if (atual) await t.query('UPDATE credito_empresas SET situacao = $1, motivo = $2, autorizado_por = $3, updated_at = $4 WHERE business_id = $5', [situacao, motivo, ator.id, nowIso(), bid])
    else await t.query('INSERT INTO credito_empresas (business_id, situacao, config, motivo, autorizado_por, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [bid, situacao, '{}', motivo, ator.id, nowIso()])
    await evento(t, bid, `empresa_${situacao}`, { motivo, de: atual?.situacao || null }, { ator: ator.id })
  })
  const { audit } = await import('./account.js'); await audit(ator.id, `credito.empresa.${acao}`, bid, { motivo, de: atual?.situacao || null })
  const emp = String(J<any>(b!.data, {}).empresa || 'sua empresa')
  await avisar(Number(b!.owner_id), acao === 'autorizar' ? `Crédito da Loja liberado para ${emp}` : acao === 'suspender' ? `Crédito da Loja suspenso · ${emp}` : `Crédito da Loja revogado · ${emp}`, acao === 'autorizar' ? 'Configure as regras e conceda limites em Sua empresa → Ajustes → Crédito da Loja.' : `${motivo}. Novas compras e concessões estão bloqueadas; as parcelas em aberto continuam e os pagamentos podem ser registrados.`, `credito:adm:${bid}:${acao}:${Date.now().toString(36)}`, '/x/sua-empresa')
  return { ok: true, situacao }
}
export async function admRelatorio(de: string, ate: string) {
  const hoje = localDate('America/Sao_Paulo'), P = periodo(de, ate, hoje)
  const noP = (iso: any) => { const d = String(iso || '').slice(0, 10); return d >= P.de && d <= P.ate }
  const emps = await q('SELECT c.business_id, b.data FROM credito_empresas c JOIN businesses b ON b.id = c.business_id')
  const linhas = [] as any[]
  for (const r of emps) {
    const bid = Number(r.business_id)
    const ops = (await q('SELECT status, principal, juros, created_at FROM credito_operacoes WHERE business_id = $1', [bid])).filter((o: any) => noP(o.created_at))
    const pags = (await q('SELECT valor, created_at FROM credito_pagamentos WHERE business_id = $1', [bid])).filter((p: any) => noP(p.created_at))
    const st = await estatEmpresa(bid, hoje)
    linhas.push({ businessId: bid, empresa: String(J<any>(r.data, {}).empresa || ''), compras: ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).length, financiado: r2(ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).reduce((a: number, o: any) => a + num(o.principal), 0)), juros: r2(ops.filter((o: any) => ['ativa', 'quitada'].includes(o.status)).reduce((a: number, o: any) => a + num(o.juros), 0)), rejeitadas: ops.filter((o: any) => o.status === 'rejeitada').length, recebido: r2(pags.reduce((a: number, p: any) => a + num(p.valor), 0)), vencidoAtual: st.vencido, inadimplentes: st.inadimplentes })
  }
  return { ...P, linhas, totais: { compras: linhas.reduce((a, l) => a + l.compras, 0), financiado: r2(linhas.reduce((a, l) => a + l.financiado, 0)), recebido: r2(linhas.reduce((a, l) => a + l.recebido, 0)), vencidoAtual: r2(linhas.reduce((a, l) => a + l.vencidoAtual, 0)) } }
}
export async function admSalvarConfig(b: any, atorId: number) {
  const g = validarGlobal(b || {}, await globalCfg()); await setConfig('credito_loja', g)
  const { audit } = await import('./account.js'); await audit(atorId, 'credito.config', null, g)
  return { ok: true, config: g }
}
/** Configuração da empresa (dono): dentro dos tetos do ADM; só com a empresa autorizada e o recurso ligado. */
export async function salvarConfigEmpresa(bid: number, b: any, ator: { id: number }) {
  const e = await estadoEmpresa(bid); exigirOperavel(e, 'alterar as regras do crédito')
  const novo = normEmpresa({ ...e.cfg, ...(b || {}) }, e.g, true)
  await db().tx(async (t) => {
    await t.query('UPDATE credito_empresas SET config = $1, updated_at = $2 WHERE business_id = $3', [JSON.stringify(novo), nowIso(), bid])
    const mud = Object.keys(novo).filter((k) => JSON.stringify((novo as any)[k]) !== JSON.stringify((e.cfg as any)[k]))
    if (mud.length) await evento(t, bid, 'config_empresa', { campos: mud, ativo: novo.ativo }, { ator: ator.id })
  })
  return { ok: true, config: novo }
}

/* ---------------- vencimentos (agendador) ---------------- */
let ultimoTick = 0
export async function tickVencimentos(now = new Date(), forcar = false) {
  if (!forcar && now.getTime() - ultimoTick < 10 * 60_000) return; ultimoTick = now.getTime()
  const g = await globalCfg()
  const rows = await q("SELECT p.*, o.order_id, o.n_parcelas FROM credito_parcelas p JOIN credito_operacoes o ON o.id = p.operacao_id WHERE p.status = 'pendente' AND o.status = 'ativa'")
  const nomes = new Map<number, string>(), donos = new Map<number, number>()
  for (const p of rows) {
    const bid = Number(p.business_id), hoje = await hojeDa(bid), venc = String(p.vencimento)
    if (!nomes.has(bid)) { nomes.set(bid, await nomeEmpresa(bid)); donos.set(bid, await donoDe(bid)) }
    const rot = Number(p.numero) === 0 ? 'Entrada' : `Parcela ${p.numero}/${p.n_parcelas}`, resta = r2(num(p.valor) - num(p.valor_pago)), emp = nomes.get(bid)!
    if (venc < hoje) {
      const mudou = await q("UPDATE credito_parcelas SET status = 'vencida', historico = $1, updated_at = $2 WHERE id = $3 AND status = 'pendente' RETURNING id", [JSON.stringify([...J<any[]>(p.historico, []), { em: nowIso(), acao: 'vencida' }].slice(-30)), nowIso(), p.id])
      if (!mudou.length) continue
      await evento(db(), bid, 'parcela_vencida', { parcela: Number(p.numero), valor: resta, vencimento: venc }, { cliente: Number(p.user_id), operacao: Number(p.operacao_id) })
      await avisar(Number(p.user_id), `${rot} vencida · ${emp}`, `${brl(resta)} venceu em ${brData(venc)}${p.order_id ? ` · pedido #${p.order_id}` : ''}. Fale com a loja para pagar.`, `credito:vencida:${p.id}`)
      await avisar(donos.get(bid)!, `Parcela em atraso · Crédito da Loja`, `${rot} de ${brl(resta)} venceu em ${brData(venc)}${p.order_id ? ` · pedido #${p.order_id}` : ''}.`, `credito:vencida-loja:${p.id}`, '/x/sua-empresa')
    } else if (g.diasAvisoVencimento > 0 && venc <= addDias(hoje, g.diasAvisoVencimento) && Number(p.numero) > 0) {
      const dias = Math.round((Date.parse(venc) - Date.parse(hoje)) / 86400000)
      await avisar(Number(p.user_id), `${rot} ${dias === 0 ? 'vence hoje' : dias === 1 ? 'vence amanhã' : `vence em ${dias} dias`} · ${emp}`, `${brl(resta)} · vencimento ${brData(venc)}${p.order_id ? ` · pedido #${p.order_id}` : ''}.`, `credito:venc:${p.id}`)
    }
  }
}
