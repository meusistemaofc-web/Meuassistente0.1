// Acesso ao PAINEL DA EMPRESA ("Sua empresa" no cabeçalho do chat). Fonte única de verdade, sempre no servidor:
// o painel de gestão só é liberado quando o anúncio do próprio usuário foi APROVADO pelo administrador
// (status 'aprovado' = aprovado aguardando pagamento, ou 'ativo' = aprovado e no ar, dentro da validade).
// Em elaboração/pagamento ('pagamento'), enviado/pendente ('analise', 'ajustes'), reprovado ('recusado') e
// suspenso/revogado/vencido ('encerrado' ou 'ativo' vencido) → oculto e bloqueado.
// O ciclo do ANÚNCIO (criar, editar a proposta, pagar, renovar, excluir recusado) continua nas rotas de ads.ts, sem esta trava.
import { q } from '../db/index.js'
import { modules } from './usermod.js'

export const PAINEL_STATUS = ['aprovado', 'ativo'] as const
const vencido = (b: any) => b.status === 'ativo' && !!b.expires_at && Date.parse(b.expires_at) < Date.now()
/** O anúncio/empresa libera o painel de gestão? ('institucional' é a empresa da própria plataforma, administrada pelo admin.) */
export function painelLiberado(b: any): boolean {
  if (!b) return false
  if (b.status === 'institucional') return true
  return (PAINEL_STATUS as readonly string[]).includes(String(b.status)) && !vencido(b)
}
/** Trava do BACKEND para as rotas de gestão da empresa (ownBusiness), seguindo as regras administrativas já existentes:
 *  - anúncio REPROVADO ('recusado') → bloqueado;
 *  - aprovação REVOGADA/SUSPENSA pelo administrador (ação "Encerrar" → data.revogado) → bloqueado até nova aprovação;
 *  - aprovado/no ar → liberado;
 *  - proposta ainda em pagamento/análise/ajustes → mantém a preparação que já existia antes da aprovação
 *    (agente em modo teste, importador de cardápio, catálogo), sem botão no cabeçalho;
 *  - já aprovado e agora vencido/em renovação → mantém os dados e o agente com validade própria (regra existente).
 *  O isolamento entre usuários continua garantido pela consulta com owner_id = usuário autenticado (404 para empresa alheia). */
export function gestaoLiberada(b: any): boolean {
  if (!b) return false
  const d = typeof b.data === 'string' ? (() => { try { return JSON.parse(b.data) } catch { return {} } })() : (b.data || {})
  return !(b.status === 'recusado' || d.revogado)
}
/** Estado do botão "Sua empresa" para o usuário autenticado: só empresas DELE e só as aprovadas. */
export async function painelAcesso(userId: number): Promise<{ liberado: boolean; empresaId: number | null; empresas: number[] }> {
  if ((await modules()).anuncios === false) return { liberado: false, empresaId: null, empresas: [] }
  const rows = await q("SELECT id, status, expires_at FROM businesses WHERE owner_id = $1 AND status IN ('aprovado','ativo') ORDER BY id DESC", [userId])
  const ok = rows.filter(painelLiberado).map((r: any) => Number(r.id))
  return { liberado: ok.length > 0, empresaId: ok[0] ?? null, empresas: ok }
}
