// Cliente da Central de Processamento de Arquivos e Mídias (serviço independente em services/central-midia).
// OPCIONAL: usado só pela leitura local de comprovantes (ai/leitura-local.ts). Sem a central, tudo segue pelo caminho antigo.
// Ligado só com MIDIA_URL e MIDIA_TOKEN no .env. Nunca lança exceção: se a central estiver desligada, fora do ar
// ou lenta, devolve { ok: false, indisponivel: true } e quem chamar segue pelo caminho atual.

export interface OpcoesCentral {
  ocr?: 'auto' | 'sempre' | 'nunca'
  codigos?: boolean
  comprovante?: 'auto' | 'nunca'
  transcrever?: boolean
  interpretar?: '0' | '1' | 'auto'
  idioma?: string
  /** identificação de quem pediu, para o registro da central (ex.: "user:12"); nunca dados pessoais */
  cliente?: string
  tempoMs?: number
}
export interface ResultadoCentral {
  ok: true
  id: string
  nivel: 1 | 2
  arquivo: { nome: string; tamanho: number; sha256: string; familia: string; formato: string; mime: string }
  texto: string
  paginas: { numero: number; texto: string; ocr: boolean }[] | null
  tabelas: { nome: string; linhas: string[][]; total_linhas: number; truncada?: boolean }[] | null
  metadados: Record<string, unknown>
  codigos: { tipo: string; conteudo: string; formato?: string; uso?: string; pix?: Record<string, unknown> }[]
  comprovante: Record<string, unknown> | null
  ocr: { usado: boolean; confianca: number | null }
  nivel2?: Record<string, unknown>
  avisos: string[]
  tempo_ms: number
}
export type RespostaCentral = ResultadoCentral | { ok: false; indisponivel: boolean; codigo: string; mensagem: string; status?: number }

const base = () => String(process.env.MIDIA_URL || '').trim().replace(/\/+$/, '')
const token = () => String(process.env.MIDIA_TOKEN || '').trim()
export const centralConfigurada = () => !!(base() && token().length >= 24)

let saudeCache: { at: number; ok: boolean; url: string } | null = null
/** A central está no ar? (consulta /saude, com cache de 30 s para não pesar). */
export async function centralDisponivel(): Promise<boolean> {
  if (!centralConfigurada()) return false
  if (saudeCache && saudeCache.url === base() && Date.now() - saudeCache.at < 30_000) return saudeCache.ok
  let ok = false
  try { const r = await fetch(base() + '/saude', { signal: AbortSignal.timeout(2500) }); const j: any = await r.json().catch(() => ({})); ok = r.ok && j.ok === true && j.ativa !== false } catch { ok = false }
  saudeCache = { at: Date.now(), ok, url: base() }
  return ok
}

/** Processa um arquivo na central. Erros de rede, tempo ou central desligada viram { ok:false, indisponivel:true }. */
export async function processarNaCentral(dados: Buffer | Uint8Array, nome: string, mime = '', o: OpcoesCentral = {}): Promise<RespostaCentral> {
  if (!centralConfigurada()) return { ok: false, indisponivel: true, codigo: 'nao_configurada', mensagem: 'Central de mídias não configurada (MIDIA_URL/MIDIA_TOKEN).' }
  const q = new URLSearchParams()
  if (o.ocr) q.set('ocr', o.ocr)
  if (o.codigos === false) q.set('codigos', '0')
  if (o.comprovante) q.set('comprovante', o.comprovante)
  if (o.transcrever) q.set('transcrever', '1')
  if (o.interpretar) q.set('interpretar', o.interpretar)
  if (o.idioma) q.set('idioma', o.idioma)
  try {
    const r = await fetch(`${base()}/v1/processar${q.size ? '?' + q : ''}`, {
      method: 'POST', body: new Uint8Array(dados),
      headers: { Authorization: `Bearer ${token()}`, 'Content-Type': mime || 'application/octet-stream', 'X-Arquivo-Nome': encodeURIComponent(nome || 'arquivo'), ...(o.cliente ? { 'X-Cliente': o.cliente.slice(0, 64) } : {}) },
      signal: AbortSignal.timeout(o.tempoMs ?? 90_000),
    })
    const j: any = await r.json().catch(() => null)
    if (r.ok && j?.ok) return j as ResultadoCentral
    const codigo = String(j?.erro?.codigo || `http_${r.status}`)
    // 401/503/429/5xx = problema da central (não do arquivo): quem chama deve seguir pelo caminho atual
    const indisponivel = [401, 429, 503].includes(r.status) || r.status >= 500
    if (indisponivel) saudeCache = { at: Date.now(), ok: false, url: base() }
    return { ok: false, indisponivel, codigo, mensagem: String(j?.erro?.mensagem || 'A central não processou o arquivo.'), status: r.status }
  } catch (e: any) {
    saudeCache = { at: Date.now(), ok: false, url: base() }
    return { ok: false, indisponivel: true, codigo: e?.name === 'TimeoutError' ? 'tempo_excedido' : 'sem_conexao', mensagem: 'A central de mídias não respondeu.' }
  }
}
