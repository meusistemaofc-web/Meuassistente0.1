// Calendário empresarial (funções puras, sem banco): feriados, intervalos, exceções, decisões do dono e o "dia efetivo".
// Tudo é ADITIVO: sem `calendario` configurado, o dia efetivo é exatamente o horário semanal que a empresa já tinha.
export const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'] as const
export const DIA_NOME = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado']
export const MODOS = ['manual', 'inteligente', 'automatico'] as const
export type Modo = (typeof MODOS)[number]
export const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return (a || 0) * 60 + (b || 0) }
export const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
const HM = /^([01]\d|2[0-3]):[0-5]\d$/, DATA = /^\d{4}-\d{2}-\d{2}$/, MD = /^\d{2}-\d{2}$/
const dowOf = (date: string) => new Date(date + 'T12:00:00Z').getUTCDay()
export const addDays = (date: string, n: number) => { const d = new Date(date + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
const validDate = (s: string) => DATA.test(s) && !isNaN(Date.parse(s + 'T12:00:00Z')) && new Date(s + 'T12:00:00Z').toISOString().slice(0, 10) === s

/* ---------- feriados ---------- */
export interface Feriado { data: string; nome: string; nivel: 'nacional' | 'estadual' | 'municipal'; facultativo?: boolean }
/** Páscoa (algoritmo de Meeus/Jones/Butcher). */
export function pascoa(ano: number) {
  const a = ano % 19, b = Math.floor(ano / 100), c = ano % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3)
  const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451)
  const mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1
  return `${ano}-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`
}
const FIXOS: [string, string][] = [['01-01', 'Confraternização Universal'], ['04-21', 'Tiradentes'], ['05-01', 'Dia do Trabalho'], ['09-07', 'Independência do Brasil'], ['10-12', 'Nossa Senhora Aparecida'], ['11-02', 'Finados'], ['11-15', 'Proclamação da República'], ['11-20', 'Consciência Negra'], ['12-25', 'Natal']]
export function feriadosNacionais(ano: number): Feriado[] {
  const p = pascoa(ano), out: Feriado[] = FIXOS.map(([md, nome]) => ({ data: `${ano}-${md}`, nome, nivel: 'nacional' as const }))
  out.push({ data: addDays(p, -48), nome: 'Carnaval (segunda-feira)', nivel: 'nacional', facultativo: true }, { data: addDays(p, -47), nome: 'Carnaval (terça-feira)', nivel: 'nacional', facultativo: true },
    { data: addDays(p, -2), nome: 'Sexta-feira Santa', nivel: 'nacional' }, { data: addDays(p, 60), nome: 'Corpus Christi', nivel: 'nacional', facultativo: true })
  return out.sort((x, y) => x.data.localeCompare(y.data))
}
/** Feriados do ano: nacionais (calculados) + estaduais/municipais cadastrados pelo dono (MM-DD recorrente ou AAAA-MM-DD). */
export function feriadosDoAno(ano: number, proprios: any[] = []): Feriado[] {
  const out = feriadosNacionais(ano)
  for (const f of Array.isArray(proprios) ? proprios : []) {
    const d = String(f?.data || ''), nivel = f?.nivel === 'estadual' ? 'estadual' : 'municipal'
    if (MD.test(d)) out.push({ data: `${ano}-${d}`, nome: String(f.nome || 'Feriado').slice(0, 60), nivel })
    else if (validDate(d) && d.startsWith(String(ano))) out.push({ data: d, nome: String(f.nome || 'Feriado').slice(0, 60), nivel })
  }
  return out.sort((x, y) => x.data.localeCompare(y.data))
}
export function feriadoDe(date: string, proprios: any[] = []): Feriado | null {
  const todos = feriadosDoAno(Number(date.slice(0, 4)), proprios).filter((f) => f.data === date)
  return todos.find((f) => f.nivel !== 'nacional') || todos[0] || null
}
export function proximosFeriados(de: string, dias: number, proprios: any[] = []): Feriado[] {
  const ate = addDays(de, dias), a = Number(de.slice(0, 4)), b = Number(ate.slice(0, 4))
  const todos: Feriado[] = []; for (let y = a; y <= b; y++) todos.push(...feriadosDoAno(y, proprios))
  return todos.filter((f) => f.data >= de && f.data <= ate)
}

/* ---------- configuração ---------- */
export interface Decisao { acao: 'abrir' | 'fechar' | 'especial'; abre?: string; fecha?: string; recorrente?: boolean; em?: string; por?: string; motivo?: string }
export interface Calendario {
  modo: Modo; passoMin: number | null; gradePorDuracao: boolean // gradePorDuracao: os inícios andam de duração em duração (ex.: 09h–12h, 60 min → 09h, 10h, 11h; 120 min → 09h)
  intervalos: { id: string; nome: string; ini: string; fim: string; dias: number[] | null }[]
  excecoes: { data: string; tipo: 'fechado' | 'especial'; abre?: string; fecha?: string; motivo?: string }[]
  bloqueios: { id: string; data: string; ini: string; fim: string; motivo?: string }[]
  feriadosProprios: { data: string; nome: string; nivel: 'estadual' | 'municipal' }[]
  decisoes: Record<string, Decisao>
  historico: { data: string; nome: string; acao: string; em: string; por: string }[]
}
export const CAL_VAZIO: Calendario = { modo: 'manual', passoMin: null, gradePorDuracao: false, intervalos: [], excecoes: [], bloqueios: [], feriadosProprios: [], decisoes: {}, historico: [] }
const txt = (v: any, n: number) => String(v ?? '').trim().slice(0, n)
const rid = () => Math.random().toString(36).slice(2, 9)
/** Normaliza (e valida) o que veio do banco ou do dono. Entradas inválidas são descartadas, nunca quebram o agendamento. */
export function normalizeCalendario(raw: any): Calendario {
  const r = raw && typeof raw === 'object' ? raw : {}
  const hm = (v: any) => (HM.test(String(v)) ? String(v) : '')
  const intervalos = (Array.isArray(r.intervalos) ? r.intervalos : []).map((i: any) => ({ id: txt(i?.id, 12) || rid(), nome: txt(i?.nome, 40) || 'Intervalo', ini: hm(i?.ini), fim: hm(i?.fim), dias: Array.isArray(i?.dias) && i.dias.length ? [...new Set(i.dias.map(Number).filter((n: number) => n >= 0 && n <= 6))] as number[] : null }))
    .filter((i: any) => i.ini && i.fim && toMin(i.fim) > toMin(i.ini)).slice(0, 20)
  const excecoes = (Array.isArray(r.excecoes) ? r.excecoes : []).map((e: any) => ({ data: String(e?.data || ''), tipo: e?.tipo === 'especial' ? 'especial' as const : 'fechado' as const, abre: hm(e?.abre) || undefined, fecha: hm(e?.fecha) || undefined, motivo: txt(e?.motivo, 80) || undefined }))
    .filter((e: any) => validDate(e.data) && (e.tipo === 'fechado' || (e.abre && e.fecha))).slice(0, 400)
  const bloqueios = (Array.isArray(r.bloqueios) ? r.bloqueios : []).map((b: any) => ({ id: txt(b?.id, 12) || rid(), data: String(b?.data || ''), ini: hm(b?.ini), fim: hm(b?.fim), motivo: txt(b?.motivo, 80) || undefined }))
    .filter((b: any) => validDate(b.data) && b.ini && b.fim && toMin(b.fim) > toMin(b.ini)).slice(0, 400)
  const proprios = (Array.isArray(r.feriadosProprios) ? r.feriadosProprios : []).map((f: any) => ({ data: String(f?.data || ''), nome: txt(f?.nome, 60) || 'Feriado', nivel: f?.nivel === 'estadual' ? 'estadual' as const : 'municipal' as const }))
    .filter((f: any) => MD.test(f.data) ? validDate('2024-' + f.data) : validDate(f.data)).slice(0, 60)
  const decisoes: Record<string, Decisao> = {}
  for (const [k, v] of Object.entries(r.decisoes && typeof r.decisoes === 'object' ? r.decisoes : {}) as [string, any][]) {
    if (!(MD.test(k) || DATA.test(k)) || !['abrir', 'fechar', 'especial'].includes(v?.acao)) continue
    const d: Decisao = { acao: v.acao, recorrente: !!v.recorrente && MD.test(k), em: txt(v.em, 30) || undefined, por: txt(v.por, 20) || undefined, motivo: txt(v.motivo, 80) || undefined }
    if (v.acao !== 'fechar' && hm(v.abre) && hm(v.fecha) && toMin(v.fecha) > toMin(v.abre)) { d.abre = v.abre; d.fecha = v.fecha }
    if (v.acao === 'especial' && !d.abre) continue
    decisoes[k] = d
  }
  const historico = (Array.isArray(r.historico) ? r.historico : []).map((h: any) => ({ data: String(h?.data || ''), nome: txt(h?.nome, 60), acao: txt(h?.acao, 12), em: txt(h?.em, 30), por: txt(h?.por, 20) })).filter((h: any) => DATA.test(h.data)).slice(-80)
  const passo = Math.round(Number(r.passoMin)); 
  return { modo: (MODOS as readonly string[]).includes(r.modo) ? r.modo : 'manual', passoMin: [15, 20, 30, 45, 60, 90, 120].includes(passo) ? passo : null, gradePorDuracao: r.gradePorDuracao === true, intervalos, excecoes, bloqueios, feriadosProprios: proprios, decisoes, historico }
}
export const calendarioDe = (x: any) => normalizeCalendario(x?.calendario)

/* ---------- dia efetivo ---------- */
export interface DiaEfetivo {
  data: string; diaSemana: string; aberto: boolean; abre: string | null; fecha: string | null
  origem: 'semana' | 'excecao' | 'decisao' | 'decisao_recorrente'; feriado: Feriado | null; motivo: string
  intervalos: { nome: string; ini: string; fim: string }[]; bloqueios: { ini: string; fim: string; motivo?: string }[]
}
/** Resolve como a empresa funciona em `data`. Prioridade: exceção do dono > decisão do dono (data exata; recorrente só no modo automático) > horário semanal. */
export function diaEfetivo(x: any, data: string): DiaEfetivo {
  const cal = calendarioDe(x), dow = dowOf(data), dias = x?.horarioCfg?.dias
  const base = dias ? dias[DIAS[dow]] : { ativo: true, abre: '08:00', fecha: '18:00' }
  let aberto = !!(base && base.ativo), abre: string | null = aberto ? base.abre : null, fecha: string | null = aberto ? base.fecha : null
  let origem: DiaEfetivo['origem'] = 'semana', motivo = aberto ? 'Horário semanal' : 'Dia sem atendimento no horário semanal'
  const fer = feriadoDe(data, cal.feriadosProprios)
  const ex = cal.excecoes.find((e) => e.data === data)
  const dec = cal.decisoes[data] || (cal.modo === 'automatico' ? cal.decisoes[data.slice(5)] : undefined)
  const aplicar = (acao: string, a?: string, f?: string, m?: string, o: DiaEfetivo['origem'] = 'decisao') => {
    origem = o
    if (acao === 'fechar' || acao === 'fechado') { aberto = false; abre = fecha = null; motivo = m || (fer ? `Fechado: ${fer.nome}` : 'Fechado') }
    else { aberto = true; abre = a || (base && base.ativo ? base.abre : '08:00'); fecha = f || (base && base.ativo ? base.fecha : '18:00'); motivo = m || (fer ? `Aberto no feriado: ${fer.nome}` : 'Horário especial') }
  }
  if (ex) aplicar(ex.tipo, ex.abre, ex.fecha, ex.motivo, 'excecao')
  else if (dec) aplicar(dec.acao, dec.abre, dec.fecha, dec.motivo, cal.decisoes[data] ? 'decisao' : 'decisao_recorrente')
  const intervalos = aberto ? cal.intervalos.filter((i) => !i.dias || i.dias.includes(dow)).map((i) => ({ nome: i.nome, ini: i.ini, fim: i.fim })) : []
  const bloqueios = cal.bloqueios.filter((b) => b.data === data).map((b) => ({ ini: b.ini, fim: b.fim, motivo: b.motivo }))
  return { data, diaSemana: DIA_NOME[dow], aberto, abre, fecha, origem, feriado: fer, motivo, intervalos, bloqueios }
}
/** Faixas (em minutos) em que NÃO se pode marcar: intervalos do dia + bloqueios da agenda. */
export const faixasIndisponiveis = (d: DiaEfetivo): [number, number][] => [...d.intervalos, ...d.bloqueios].map((i) => [toMin(i.ini), toMin(i.fim)] as [number, number])

/** Horários de início livres (mesma regra do motor: não passa do fechamento, não atravessa intervalo nem reserva). */
export function calcularHorarios(d: DiaEfetivo, duracao: number, ocupados: [number, number][], opts: { passo?: number | null; porDuracao?: boolean; agoraMin?: number | null } = {}): string[] {
  if (!d.aberto || !d.abre || !d.fecha) return []
  const ab = toMin(d.abre), fe = toMin(d.fecha) > ab ? toMin(d.fecha) : 24 * 60, dur = Math.max(5, duracao || 30), passo = opts.porDuracao ? dur : opts.passo || Math.min(dur, 30)
  const busy = [...ocupados, ...faixasIndisponiveis(d)], out: string[] = []
  for (let t = ab; t + dur <= fe; t += passo) { if (opts.agoraMin != null && t < opts.agoraMin) continue; if (busy.some(([s, e]) => t < e && t + dur > s)) continue; out.push(hhmm(t)) }
  return out
}
