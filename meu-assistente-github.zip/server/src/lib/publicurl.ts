// Domínio oficial dos links públicos (assistentes das empresas, convites, catálogos, QR Codes, recuperação de
// senha e avisos de pagamento). Configurável no painel (Páginas e links); padrão: https://meuassistente.chat.
// Nunca usa o endereço antigo meuassistente.ivaslovck.tech.
import { getConfig } from './settings.js'
export const DEFAULT_PUBLIC = 'https://meuassistente.chat'
export const OLD_HOSTS = /(^|\.)ivaslovck\.tech$/i
let BASE = DEFAULT_PUBLIC
const clean = (u: string) => String(u || '').trim().replace(/\/+$/, '')
const valid = (u: string) => /^https?:\/\/[a-z0-9.-]+(:\d+)?$/i.test(u) && !OLD_HOSTS.test(new URL(u).hostname)
export const pub = () => BASE
export async function refreshPublicUrl() {
  const cfg = clean((await getConfig<any>('site', {}).catch(() => ({}))).url || '')
  const env = clean(process.env.PUBLIC_LINK_URL || '')
  BASE = valid(cfg) ? cfg : valid(env) ? env : DEFAULT_PUBLIC
  return BASE
}
/** Nomes que pertencem ao próprio app (rotas, arquivos, API): nenhuma empresa pode usá-los como endereço público. */
export const RESERVED_SLUGS = new Set(('api admin painel x a g c assets brand icons images agente compromisso offline favicon manifest sw index login logout entrar cadastro signup auth recuperar convite chat financeiro financas agenda tarefas contas compromissos notificacoes ativar-notificacoes configuracao configuracoes configuracao-inicial perfil ajuda planos plano termos privacidade suporte empresas empresa mercado carteira cupons pedidos anunciar meu-dia organizar espaco estudio treinos alimentacao fiscal integracoes conexoes-mcp mapas emails eleicoes eleicoes-2026 conheca dashboard inicio home app static public robots sitemap health status webhook webhooks mp pagamento pagar checkout loja produto produtos servico servicos meuassistente teste test www mail ftp').split(' '))
/** Identificador amigável a partir do nome da empresa: "Pizzaria Bella Napoli" → "pizzaria-bella-napoli". */
export function slugify(nome: string) {
  return String(nome || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/&/g, ' e ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48).replace(/-+$/g, '') || 'empresa'
}
