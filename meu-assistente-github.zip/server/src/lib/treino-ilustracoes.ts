// Ilustrações da execução dos exercícios do Treino e Acompanhamento (ficha visual do chat).
// Por que desenhadas aqui e não buscadas na internet: a imagem precisa mostrar O MOVIMENTO CERTO (uma foto achada por nome
// costuma ser de outro exercício, de outra variação ou de outra pessoa), sem custo por imagem e sem depender de serviço
// externo. Cada PADRÃO DE MOVIMENTO tem duas posições (inicial e final) desenhadas em SVG, com o grupo muscular e as
// instruções principais. O exercício é ligado ao padrão pelo nome; o que não tiver padrão conhecido fica SEM ilustração
// (o app mostra só o texto) — nunca uma imagem que não corresponde. O SVG é pequeno (~1–2 KB), servido com cache longo.
type Pt = [number, number]
interface Pose { seg: Record<string, Pt[]>; cab: Pt; props?: Prop[] }
type Prop = { t: 'banco'; x1: number; x2: number; y: number; incl?: Pt } | { t: 'halter' | 'barra'; at: Pt } | { t: 'barraH'; at: Pt; w?: number }
  | { t: 'cabo'; de: Pt; para: Pt } | { t: 'caixa'; x: number; y: number; w: number; h: number } | { t: 'linha'; pts: Pt[]; w?: number } | { t: 'roda'; at: Pt; r: number }
export interface Padrao { id: string; nome: string; grupo: string; mov: string[]; ini: Pose; fim: Pose; isometrico?: boolean; instrucoes: string[] }

/** Vista lateral (de frente para a direita). Segmentos com "2" ficam atrás (traço mais claro). */
function corpo(j: Record<string, Pt | undefined>, props: Prop[] = []): Pose {
  const s: Record<string, Pt[]> = {}
  if (j.S && j.P) s.tronco = [j.S, j.P]
  if (j.S && j.E && j.W) s.braco = [j.S, j.E, j.W]
  if (j.S && j.E2 && j.W2) s.braco2 = [j.S, j.E2, j.W2]
  if (j.P && j.K && j.F) s.perna = [j.P, j.K, j.F, ...(j.T ? [j.T] : [])]
  if (j.P && j.K2 && j.F2) s.perna2 = [j.P, j.K2, j.F2, ...(j.T2 ? [j.T2] : [])]
  return { seg: s, cab: j.H!, props }
}
const mover = (p: Pose, dx: number, dy: number): Pose => ({ cab: [p.cab[0] + dx, p.cab[1] + dy], seg: Object.fromEntries(Object.entries(p.seg).map(([k, v]) => [k, v.map(([x, y]) => [x + dx, y + dy] as Pt)])), props: (p.props || []).map((x: any) => x.at ? { ...x, at: [x.at[0] + dx, x.at[1] + dy] } : x) })
// em pé, de lado (base de vários padrões)
const EM_PE = { H: [80, 24] as Pt, S: [80, 37] as Pt, P: [80, 64] as Pt, K: [81, 85] as Pt, F: [80, 105] as Pt, T: [89, 106] as Pt, K2: [78, 85] as Pt, F2: [77, 105] as Pt, T2: [86, 106] as Pt }
/** Vista de frente: braços e pernas dos dois lados. */
function frente(o: { maos: [Pt, Pt]; cotov: [Pt, Pt]; pes?: [Pt, Pt]; joelhos?: [Pt, Pt]; quadril?: number }, props: Prop[] = []): Pose {
  const q = o.quadril ?? 64, pes = o.pes || [[75, 105], [85, 105]], jo = o.joelhos || [[76, 85], [84, 85]]
  return { cab: [80, 24], seg: { ombros: [[71, 38], [89, 38]], tronco: [[80, 37], [80, q]], quadril: [[75, q], [85, q]], braco: [[71, 38], o.cotov[0], o.maos[0]], braco_: [[89, 38], o.cotov[1], o.maos[1]], perna: [[75, q], jo[0], pes[0]], perna_: [[85, q], jo[1], pes[1]] }, props }
}

export const PADROES: Padrao[] = [
  { id: 'agachamento', nome: 'Agachamento', grupo: 'Quadríceps e glúteos', mov: ['perna', 'perna2', 'tronco'],
    ini: corpo({ ...EM_PE, E: [87, 49], W: [99, 48] }), fim: corpo({ H: [84, 46], S: [80, 57], P: [64, 82], K: [88, 80], F: [80, 105], T: [89, 106], K2: [85, 81], F2: [77, 105], T2: [86, 106], E: [93, 62], W: [107, 60] }),
    instrucoes: ['Pés na largura dos ombros, pontas levemente para fora.', 'Desça levando o quadril para trás, joelhos na direção dos pés e coluna reta.', 'Suba empurrando o chão com o pé inteiro.'] },
  { id: 'afundo', nome: 'Afundo', grupo: 'Quadríceps e glúteos', mov: ['perna', 'perna2'],
    ini: corpo({ H: [80, 24], S: [80, 37], P: [80, 64], K: [88, 84], F: [94, 105], T: [102, 106], K2: [74, 85], F2: [66, 104], T2: [72, 106], E: [80, 51], W: [81, 63] }),
    fim: corpo({ H: [80, 40], S: [80, 53], P: [80, 80], K: [99, 82], F: [98, 105], T: [106, 106], K2: [74, 100], F2: [60, 104], T2: [56, 106], E: [80, 67], W: [81, 79] }),
    instrucoes: ['Dê um passo à frente mantendo o tronco ereto.', 'Desça até os dois joelhos ficarem perto de 90°, sem o joelho da frente passar muito da ponta do pé.', 'Volte empurrando com o calcanhar da frente.'] },
  { id: 'terra', nome: 'Levantamento terra / stiff', grupo: 'Posterior de coxa e glúteos', mov: ['tronco'],
    ini: corpo({ ...EM_PE, E: [82, 51], W: [84, 66] }, [{ t: 'halter', at: [84, 68] }]),
    fim: corpo({ H: [110, 52], S: [100, 56], P: [72, 62], K: [80, 84], F: [80, 105], T: [89, 106], K2: [77, 84], F2: [77, 105], T2: [86, 106], E: [101, 72], W: [100, 88] }, [{ t: 'halter', at: [100, 90] }]),
    instrucoes: ['Joelhos levemente flexionados e coluna neutra durante todo o movimento.', 'Leve o quadril para trás e desça o peso rente às pernas.', 'Suba contraindo glúteos e posterior, sem arredondar as costas.'] },
  { id: 'supino', nome: 'Supino', grupo: 'Peito, ombros e tríceps', mov: ['braco', 'braco2'],
    ini: corpo({ H: [38, 63], S: [48, 67], P: [92, 67], K: [114, 62], F: [120, 105], T: [128, 106], E: [50, 49], W: [50, 30] }, [{ t: 'banco', x1: 34, x2: 100, y: 73 }, { t: 'barra', at: [50, 30] }]),
    fim: corpo({ H: [38, 63], S: [48, 67], P: [92, 67], K: [114, 62], F: [120, 105], T: [128, 106], E: [40, 72], W: [52, 56] }, [{ t: 'banco', x1: 34, x2: 100, y: 73 }, { t: 'barra', at: [52, 56] }]),
    instrucoes: ['Deitado no banco, pés firmes no chão e escápulas encaixadas.', 'Desça o peso controlando até perto do peito, cotovelos a cerca de 45° do corpo.', 'Empurre de volta até estender os braços, sem tirar o quadril do banco.'] },
  { id: 'supino_chao', nome: 'Supino no chão', grupo: 'Peito, ombros e tríceps', mov: ['braco'],
    ini: corpo({ H: [38, 97], S: [48, 101], P: [90, 102], K: [110, 84], F: [120, 105], T: [128, 106], E: [50, 83], W: [50, 64] }, [{ t: 'halter', at: [50, 63] }]),
    fim: corpo({ H: [38, 97], S: [48, 101], P: [90, 102], K: [110, 84], F: [120, 105], T: [128, 106], E: [40, 104], W: [52, 89] }, [{ t: 'halter', at: [52, 88] }]),
    instrucoes: ['Deitado no chão, joelhos dobrados e halteres acima do peito.', 'Desça os pesos até os cotovelos encostarem de leve no chão.', 'Empurre de volta até estender os braços, sem perder o controle.'] },
  { id: 'supino_inclinado', nome: 'Supino inclinado', grupo: 'Peito (parte superior) e ombros', mov: ['braco'],
    ini: corpo({ H: [46, 42], S: [54, 53], P: [84, 76], K: [106, 70], F: [112, 105], T: [120, 106], E: [62, 37], W: [64, 20] }, [{ t: 'banco', x1: 50, x2: 96, y: 82, incl: [40, 46] }, { t: 'halter', at: [64, 20] }]),
    fim: corpo({ H: [46, 42], S: [54, 53], P: [84, 76], K: [106, 70], F: [112, 105], T: [120, 106], E: [46, 62], W: [60, 48] }, [{ t: 'banco', x1: 50, x2: 96, y: 82, incl: [40, 46] }, { t: 'halter', at: [60, 48] }]),
    instrucoes: ['Banco inclinado entre 30° e 45°, costas apoiadas.', 'Desça os halteres até a linha do peito, controlando.', 'Empurre para cima e um pouco para dentro, sem bater os pesos.'] },
  { id: 'crucifixo', nome: 'Crucifixo', grupo: 'Peito', mov: ['braco', 'braco_'],
    ini: frente({ cotov: [[58, 42], [102, 42]], maos: [[46, 40], [114, 40]] }), fim: frente({ cotov: [[66, 46], [94, 46]], maos: [[77, 44], [83, 44]] }),
    instrucoes: ['Braços abertos com os cotovelos levemente dobrados.', 'Feche os braços à frente do peito, como num abraço.', 'Volte devagar até sentir o peito alongar, sem forçar o ombro.'] },
  { id: 'flexao', nome: 'Flexão de braço', grupo: 'Peito, ombros e tríceps', mov: ['braco', 'tronco'],
    ini: corpo({ H: [38, 58], S: [48, 64], P: [90, 80], K: [110, 90], F: [130, 102], T: [134, 106], E: [48, 85], W: [48, 106] }),
    fim: corpo({ H: [36, 86], S: [48, 92], P: [90, 98], K: [110, 102], F: [130, 104], T: [134, 106], E: [62, 94], W: [48, 106] }),
    instrucoes: ['Mãos um pouco mais abertas que os ombros e corpo em linha reta.', 'Desça o peito controlando, cotovelos apontando para trás e para fora.', 'Empurre o chão até estender os braços (apoie os joelhos se precisar).'] },
  { id: 'remada', nome: 'Remada', grupo: 'Costas e bíceps', mov: ['braco'],
    ini: corpo({ H: [108, 47], S: [98, 52], P: [70, 64], K: [80, 85], F: [77, 105], T: [86, 106], K2: [76, 85], F2: [74, 105], T2: [82, 106], E: [100, 68], W: [100, 84] }, [{ t: 'halter', at: [100, 86] }]),
    fim: corpo({ H: [108, 47], S: [98, 52], P: [70, 64], K: [80, 85], F: [77, 105], T: [86, 106], K2: [76, 85], F2: [74, 105], T2: [82, 106], E: [84, 50], W: [92, 66] }, [{ t: 'halter', at: [92, 68] }]),
    instrucoes: ['Tronco inclinado à frente com a coluna reta.', 'Puxe o peso em direção ao quadril levando o cotovelo para trás.', 'Aperte as escápulas no fim e desça devagar.'] },
  { id: 'remada_invertida', nome: 'Remada invertida', grupo: 'Costas e bíceps', mov: ['braco'],
    ini: corpo({ H: [106, 86], S: [96, 84], P: [66, 92], K: [48, 98], F: [30, 104], T: [27, 106], E: [100, 71], W: [104, 59] }, [{ t: 'barraH', at: [104, 58], w: 34 }, { t: 'linha', pts: [[119, 58], [119, 107]], w: 3 }]),
    fim: corpo({ H: [110, 66], S: [98, 70], P: [66, 85], K: [47, 95], F: [30, 104], T: [27, 106], E: [88, 76], W: [104, 59] }, [{ t: 'barraH', at: [104, 58], w: 34 }, { t: 'linha', pts: [[119, 58], [119, 107]], w: 3 }]),
    instrucoes: ['Deite sob uma barra baixa ou mesa firme e segure com as mãos na largura dos ombros.', 'Com o corpo reto, puxe o peito em direção à barra.', 'Desça devagar até estender os braços.'] },
  { id: 'puxada', nome: 'Puxada', grupo: 'Costas e bíceps', mov: ['braco'],
    ini: corpo({ H: [76, 40], S: [78, 52], P: [78, 80], K: [100, 80], F: [102, 105], T: [110, 106], E: [84, 32], W: [88, 14] }, [{ t: 'banco', x1: 64, x2: 92, y: 84 }, { t: 'barraH', at: [88, 14], w: 44 }, { t: 'cabo', de: [88, 2], para: [88, 14] }]),
    fim: corpo({ H: [74, 40], S: [78, 52], P: [78, 80], K: [100, 80], F: [102, 105], T: [110, 106], E: [74, 62], W: [90, 46] }, [{ t: 'banco', x1: 64, x2: 92, y: 84 }, { t: 'barraH', at: [90, 46], w: 44 }, { t: 'cabo', de: [88, 2], para: [90, 46] }]),
    instrucoes: ['Segure a barra um pouco mais aberta que os ombros, peito alto.', 'Puxe a barra até a parte de cima do peito, levando os cotovelos para baixo.', 'Volte devagar até estender os braços.'] },
  { id: 'desenvolvimento', nome: 'Desenvolvimento', grupo: 'Ombros e tríceps', mov: ['braco'],
    ini: corpo({ ...EM_PE, E: [90, 46], W: [88, 32] }, [{ t: 'halter', at: [88, 31] }]), fim: corpo({ ...EM_PE, E: [84, 22], W: [82, 7] }, [{ t: 'halter', at: [82, 6] }]),
    instrucoes: ['Pesos na altura dos ombros, abdômen firme.', 'Empurre para cima até quase estender os braços.', 'Desça controlando até a altura das orelhas, sem arquear a lombar.'] },
  { id: 'elevacao_lateral', nome: 'Elevação lateral', grupo: 'Ombros', mov: ['braco', 'braco_'],
    ini: frente({ cotov: [[69, 52], [91, 52]], maos: [[68, 65], [92, 65]] }, [{ t: 'halter', at: [68, 66] }, { t: 'halter', at: [92, 66] }]),
    fim: frente({ cotov: [[57, 40], [103, 40]], maos: [[45, 41], [115, 41]] }, [{ t: 'halter', at: [45, 41] }, { t: 'halter', at: [115, 41] }]),
    instrucoes: ['Em pé, halteres ao lado do corpo e cotovelos levemente dobrados.', 'Eleve os braços pelas laterais até a altura dos ombros.', 'Desça devagar, sem balançar o tronco.'] },
  { id: 'face_pull', nome: 'Face pull', grupo: 'Ombros (posterior) e costas', mov: ['braco'],
    ini: corpo({ ...EM_PE, E: [98, 38], W: [116, 36] }, [{ t: 'cabo', de: [150, 34], para: [116, 36] }]), fim: corpo({ ...EM_PE, E: [84, 30], W: [96, 24] }, [{ t: 'cabo', de: [150, 34], para: [96, 24] }]),
    instrucoes: ['Polia na altura do rosto, segure a corda com as palmas para dentro.', 'Puxe em direção ao rosto abrindo os cotovelos para os lados.', 'Volte controlando até estender os braços.'] },
  { id: 'elevacao_y', nome: 'Elevação em Y', grupo: 'Ombros e parte alta das costas', mov: ['braco'],
    ini: corpo({ H: [36, 99], S: [46, 102], P: [88, 104], K: [110, 104], F: [130, 104], T: [132, 106], E: [32, 104], W: [18, 105] }), fim: corpo({ H: [36, 97], S: [46, 101], P: [88, 104], K: [110, 104], F: [130, 104], T: [132, 106], E: [32, 96], W: [18, 90] }),
    instrucoes: ['Deitado de bruços, braços estendidos à frente em forma de Y.', 'Eleve os braços do chão apertando as escápulas.', 'Segure 1 segundo e desça devagar.'] },
  { id: 'rosca', nome: 'Rosca', grupo: 'Bíceps', mov: ['braco'],
    ini: corpo({ ...EM_PE, E: [81, 51], W: [83, 66] }, [{ t: 'halter', at: [83, 67] }]), fim: corpo({ ...EM_PE, E: [81, 51], W: [92, 38] }, [{ t: 'halter', at: [93, 37] }]),
    instrucoes: ['Cotovelos colados ao corpo e punhos firmes.', 'Suba o peso dobrando só o cotovelo.', 'Desça devagar até estender o braço, sem balançar o tronco.'] },
  { id: 'triceps_polia', nome: 'Tríceps na polia', grupo: 'Tríceps', mov: ['braco'],
    ini: corpo({ ...EM_PE, E: [84, 52], W: [96, 44] }, [{ t: 'cabo', de: [98, 2], para: [96, 44] }]), fim: corpo({ ...EM_PE, E: [84, 52], W: [88, 68] }, [{ t: 'cabo', de: [98, 2], para: [88, 68] }]),
    instrucoes: ['Cotovelos parados ao lado do corpo.', 'Empurre a barra ou corda para baixo até estender os braços.', 'Volte devagar até a altura do peito.'] },
  { id: 'triceps_frances', nome: 'Tríceps francês', grupo: 'Tríceps', mov: ['braco'],
    ini: corpo({ ...EM_PE, E: [85, 16], W: [73, 26] }, [{ t: 'halter', at: [72, 27] }]), fim: corpo({ ...EM_PE, E: [85, 18], W: [85, 6] }, [{ t: 'halter', at: [85, 6] }]),
    instrucoes: ['Halter acima da cabeça, cotovelos apontando para cima.', 'Desça o peso atrás da cabeça dobrando só os cotovelos.', 'Estenda os braços de volta sem abrir os cotovelos.'] },
  { id: 'mergulho', nome: 'Mergulho no banco', grupo: 'Tríceps e peito', mov: ['braco', 'tronco'],
    ini: corpo({ H: [72, 40], S: [70, 53], P: [74, 80], K: [100, 82], F: [120, 104], T: [126, 106], E: [64, 64], W: [58, 76] }, [{ t: 'banco', x1: 30, x2: 62, y: 78 }]),
    fim: corpo({ H: [72, 58], S: [70, 71], P: [74, 96], K: [100, 90], F: [120, 104], T: [126, 106], E: [52, 70], W: [58, 77] }, [{ t: 'banco', x1: 30, x2: 62, y: 78 }]),
    instrucoes: ['Mãos na beira do banco, dedos para a frente.', 'Desça dobrando os cotovelos para trás, sem passar de 90°.', 'Empurre o banco para subir, ombros longe das orelhas.'] },
  { id: 'prancha', nome: 'Prancha', grupo: 'Abdômen e core', mov: ['tronco'], isometrico: true,
    ini: corpo({ H: [38, 86], S: [48, 92], P: [90, 96], K: [110, 100], F: [130, 103], T: [134, 106], E: [48, 106], W: [64, 106] }), fim: corpo({ H: [38, 86], S: [48, 92], P: [90, 96], K: [110, 100], F: [130, 103], T: [134, 106], E: [48, 106], W: [64, 106] }),
    instrucoes: ['Antebraços no chão, cotovelos abaixo dos ombros.', 'Corpo em linha reta da cabeça aos pés, abdômen e glúteos contraídos.', 'Mantenha a posição respirando normalmente, sem deixar o quadril cair.'] },
  { id: 'prancha_lateral', nome: 'Prancha lateral', grupo: 'Oblíquos e core', mov: ['tronco'], isometrico: true,
    ini: corpo({ H: [42, 78], S: [50, 88], P: [90, 98], K: [110, 102], F: [130, 104], T: [132, 106], E: [50, 106], W: [62, 106], E2: [62, 82], W2: [72, 86] }), fim: corpo({ H: [42, 78], S: [50, 88], P: [90, 98], K: [110, 102], F: [130, 104], T: [132, 106], E: [50, 106], W: [62, 106], E2: [62, 82], W2: [72, 86] }),
    instrucoes: ['De lado, cotovelo apoiado abaixo do ombro.', 'Eleve o quadril até o corpo ficar em linha reta.', 'Mantenha a posição sem deixar o quadril cair; depois troque de lado.'] },
  { id: 'abdominal', nome: 'Abdominal', grupo: 'Abdômen', mov: ['tronco'],
    ini: corpo({ H: [36, 98], S: [46, 102], P: [86, 102], K: [102, 84], F: [118, 104], T: [124, 106], E: [44, 90], W: [36, 94] }), fim: corpo({ H: [52, 82], S: [58, 92], P: [86, 102], K: [102, 84], F: [118, 104], T: [124, 106], E: [62, 80], W: [50, 80] }),
    instrucoes: ['Deitado, joelhos dobrados e pés no chão.', 'Tire as escápulas do chão contraindo o abdômen, sem puxar o pescoço.', 'Desça devagar, mantendo a lombar apoiada.'] },
  { id: 'dead_bug', nome: 'Dead bug', grupo: 'Abdômen e core', mov: ['braco2', 'perna2'],
    ini: corpo({ H: [36, 98], S: [46, 102], P: [86, 102], K: [90, 80], F: [108, 80], K2: [88, 80], F2: [106, 80], E: [48, 88], W: [50, 72], E2: [48, 88], W2: [50, 72] }),
    fim: corpo({ H: [36, 98], S: [46, 102], P: [86, 102], K: [90, 80], F: [108, 80], K2: [106, 96], F2: [128, 98], E: [48, 88], W: [50, 72], E2: [36, 94], W2: [22, 96] }),
    instrucoes: ['Deitado de costas, braços para cima e joelhos dobrados a 90°.', 'Estenda um braço para trás e a perna oposta à frente, sem tirar a lombar do chão.', 'Volte e alterne os lados, devagar.'] },
  { id: 'ponte', nome: 'Elevação pélvica', grupo: 'Glúteos e posterior', mov: ['tronco', 'perna'],
    ini: corpo({ H: [36, 99], S: [46, 102], P: [82, 102], K: [100, 82], F: [110, 105], T: [118, 106], E: [60, 104], W: [72, 105] }), fim: corpo({ H: [36, 99], S: [46, 101], P: [82, 82], K: [104, 78], F: [110, 105], T: [118, 106], E: [60, 104], W: [72, 105] }),
    instrucoes: ['Deitado, joelhos dobrados e pés apoiados perto do quadril.', 'Suba o quadril contraindo os glúteos até alinhar ombros, quadril e joelhos.', 'Segure 1 segundo e desça devagar.'] },
  { id: 'abducao_lateral', nome: 'Abdução de quadril deitado', grupo: 'Glúteo médio', mov: ['perna2'],
    ini: corpo({ H: [36, 94], S: [46, 98], P: [86, 100], K: [106, 102], F: [126, 104], T: [130, 106], K2: [106, 98], F2: [126, 100], E: [40, 106], W: [30, 104] }),
    fim: corpo({ H: [36, 94], S: [46, 98], P: [86, 100], K: [106, 102], F: [126, 104], T: [130, 106], K2: [104, 88], F2: [122, 76], E: [40, 106], W: [30, 104] }),
    instrucoes: ['Deitado de lado, pernas estendidas e quadril alinhado.', 'Eleve a perna de cima sem girar o quadril para trás.', 'Desça devagar e repita; depois troque de lado.'] },
  { id: 'abducao_sentado', nome: 'Cadeira abdutora', grupo: 'Glúteo médio', mov: ['perna', 'perna_'],
    ini: frente({ cotov: [[70, 52], [90, 52]], maos: [[72, 64], [88, 64]], quadril: 70, joelhos: [[76, 78], [84, 78]], pes: [[76, 104], [84, 104]] }, [{ t: 'linha', pts: [[62, 72], [98, 72]], w: 4 }]),
    fim: frente({ cotov: [[70, 52], [90, 52]], maos: [[72, 64], [88, 64]], quadril: 70, joelhos: [[60, 80], [100, 80]], pes: [[66, 104], [94, 104]] }, [{ t: 'linha', pts: [[62, 72], [98, 72]], w: 4 }]),
    instrucoes: ['Sentado com as costas apoiadas e as pernas encostadas nos apoios.', 'Abra as pernas empurrando os apoios para fora.', 'Volte devagar, sem deixar o peso bater.'] },
  { id: 'panturrilha', nome: 'Panturrilha em pé', grupo: 'Panturrilhas', mov: ['perna'],
    ini: corpo({ ...EM_PE, E: [82, 51], W: [83, 65] }), fim: mover(corpo({ H: [80, 24], S: [80, 37], P: [80, 64], K: [81, 85], F: [82, 103], T: [89, 112], E: [82, 51], W: [83, 65] }), 0, -6),
    instrucoes: ['Em pé, pés na largura do quadril (apoie-se se precisar).', 'Suba na ponta dos pés o mais alto que conseguir.', 'Desça devagar até apoiar o calcanhar.'] },
  { id: 'extensora', nome: 'Cadeira extensora', grupo: 'Quadríceps', mov: ['perna'],
    ini: corpo({ H: [74, 34], S: [76, 46], P: [80, 74], K: [102, 74], F: [104, 100], T: [110, 102], E: [80, 60], W: [86, 74] }, [{ t: 'banco', x1: 66, x2: 102, y: 80, incl: [68, 40] }]),
    fim: corpo({ H: [74, 34], S: [76, 46], P: [80, 74], K: [102, 74], F: [128, 70], T: [132, 64], E: [80, 60], W: [86, 74] }, [{ t: 'banco', x1: 66, x2: 102, y: 80, incl: [68, 40] }]),
    instrucoes: ['Sentado com as costas apoiadas e o rolo sobre a canela.', 'Estenda os joelhos até as pernas ficarem retas.', 'Desça devagar, sem deixar o peso bater.'] },
  { id: 'leg_press', nome: 'Leg press', grupo: 'Quadríceps e glúteos', mov: ['perna'],
    ini: corpo({ H: [42, 58], S: [52, 66], P: [74, 86], K: [88, 60], F: [108, 66], T: [110, 58], E: [62, 80], W: [72, 88] }, [{ t: 'banco', x1: 66, x2: 84, y: 92, incl: [38, 62] }, { t: 'linha', pts: [[104, 48], [118, 80]], w: 5 }]),
    fim: corpo({ H: [42, 58], S: [52, 66], P: [74, 86], K: [102, 66], F: [126, 54], T: [128, 46], E: [62, 80], W: [72, 88] }, [{ t: 'banco', x1: 66, x2: 84, y: 92, incl: [38, 62] }, { t: 'linha', pts: [[122, 36], [136, 68]], w: 5 }]),
    instrucoes: ['Costas e quadril bem apoiados, pés no meio da plataforma.', 'Empurre a plataforma até quase estender os joelhos (sem travar).', 'Desça devagar até os joelhos perto de 90°.'] },
  { id: 'flexora', nome: 'Mesa flexora', grupo: 'Posterior de coxa', mov: ['perna'],
    ini: corpo({ H: [30, 64], S: [40, 69], P: [84, 69], K: [106, 69], F: [128, 70], T: [132, 66], E: [32, 76], W: [24, 74] }, [{ t: 'banco', x1: 26, x2: 110, y: 75 }]),
    fim: corpo({ H: [30, 64], S: [40, 69], P: [84, 69], K: [106, 69], F: [110, 46], T: [104, 42], E: [32, 76], W: [24, 74] }, [{ t: 'banco', x1: 26, x2: 110, y: 75 }]),
    instrucoes: ['Deitado de bruços, rolo logo acima dos calcanhares.', 'Dobre os joelhos trazendo os calcanhares em direção aos glúteos.', 'Desça devagar, sem tirar o quadril do banco.'] },
  { id: 'step', nome: 'Subida no degrau', grupo: 'Quadríceps e glúteos', mov: ['perna', 'perna2'],
    ini: corpo({ H: [80, 24], S: [80, 37], P: [80, 64], K: [96, 72], F: [98, 90], T: [106, 90], K2: [78, 85], F2: [76, 105], T2: [84, 106], E: [82, 51], W: [83, 64] }, [{ t: 'caixa', x: 88, y: 91, w: 36, h: 15 }]),
    fim: corpo({ H: [94, 8], S: [94, 21], P: [94, 48], K: [96, 69], F: [98, 89], T: [106, 90], K2: [92, 69], F2: [94, 89], T2: [102, 90], E: [96, 35], W: [97, 48] }, [{ t: 'caixa', x: 88, y: 91, w: 36, h: 15 }]),
    instrucoes: ['Apoie o pé inteiro no degrau.', 'Suba empurrando com a perna de cima, sem dar impulso com a de baixo.', 'Desça controlando e alterne as pernas.'] },
  { id: 'polichinelo', nome: 'Polichinelo', grupo: 'Cardio', mov: ['braco', 'braco_', 'perna', 'perna_'],
    ini: frente({ cotov: [[69, 52], [91, 52]], maos: [[68, 65], [92, 65]] }), fim: frente({ cotov: [[62, 24], [98, 24]], maos: [[58, 10], [102, 10]], joelhos: [[68, 85], [92, 85]], pes: [[60, 105], [100, 105]] }),
    instrucoes: ['Comece em pé, pés juntos e braços ao lado do corpo.', 'Salte abrindo as pernas e levando os braços acima da cabeça.', 'Salte de volta à posição inicial, aterrissando com suavidade.'] },
  { id: 'caminhada', nome: 'Caminhada', grupo: 'Cardio', mov: ['perna', 'perna2'],
    ini: corpo({ H: [82, 24], S: [81, 37], P: [80, 64], K: [88, 84], F: [94, 104], T: [102, 105], K2: [74, 85], F2: [66, 103], T2: [72, 106], E: [86, 50], W: [94, 58], E2: [76, 50], W2: [70, 60] }),
    fim: corpo({ H: [82, 24], S: [81, 37], P: [80, 64], K: [74, 85], F: [66, 103], T: [72, 106], K2: [88, 84], F2: [94, 104], T2: [102, 105], E: [76, 50], W: [70, 60], E2: [86, 50], W2: [94, 58] }),
    instrucoes: ['Passos firmes, apoiando primeiro o calcanhar.', 'Braços balançando naturalmente, postura ereta.', 'Mantenha um ritmo em que ainda consiga conversar.'] },
  { id: 'corrida', nome: 'Corrida', grupo: 'Cardio', mov: ['perna', 'perna2'],
    ini: corpo({ H: [86, 24], S: [84, 37], P: [80, 63], K: [96, 74], F: [92, 92], T: [99, 94], K2: [72, 84], F2: [60, 98], T2: [64, 104], E: [92, 48], W: [100, 40], E2: [74, 48], W2: [72, 60] }),
    fim: corpo({ H: [86, 24], S: [84, 37], P: [80, 63], K: [72, 84], F: [60, 98], T: [64, 104], K2: [96, 74], F2: [92, 92], T2: [99, 94], E: [74, 48], W: [72, 60], E2: [92, 48], W2: [100, 40] }),
    instrucoes: ['Tronco levemente inclinado à frente, passadas curtas.', 'Aterrisse com o pé embaixo do corpo, sem bater o calcanhar à frente.', 'Comece leve e aumente o ritmo aos poucos.'] },
  { id: 'bike', nome: 'Bicicleta', grupo: 'Cardio', mov: ['perna', 'perna2'],
    ini: corpo({ H: [74, 22], S: [78, 34], P: [70, 58], K: [92, 56], F: [90, 80], T: [96, 82], K2: [80, 72], F2: [88, 96], T2: [94, 98], E: [90, 42], W: [102, 46] }, [{ t: 'roda', at: [50, 92], r: 13 }, { t: 'roda', at: [118, 92], r: 13 }, { t: 'linha', pts: [[50, 92], [70, 60], [104, 60], [118, 92]], w: 3 }, { t: 'linha', pts: [[70, 60], [88, 88], [104, 60]], w: 3 }, { t: 'linha', pts: [[104, 60], [104, 46]], w: 3 }]),
    fim: corpo({ H: [74, 22], S: [78, 34], P: [70, 58], K: [80, 72], F: [88, 96], T: [94, 98], K2: [92, 56], F2: [90, 80], T2: [96, 82], E: [90, 42], W: [102, 46] }, [{ t: 'roda', at: [50, 92], r: 13 }, { t: 'roda', at: [118, 92], r: 13 }, { t: 'linha', pts: [[50, 92], [70, 60], [104, 60], [118, 92]], w: 3 }, { t: 'linha', pts: [[70, 60], [88, 88], [104, 60]], w: 3 }, { t: 'linha', pts: [[104, 60], [104, 46]], w: 3 }]),
    instrucoes: ['Ajuste o banco: com o pedal embaixo, o joelho fica quase estendido.', 'Pedale num ritmo constante, tronco relaxado.', 'Ajuste a carga para conseguir falar frases curtas.'] },
  { id: 'burpee', nome: 'Burpee', grupo: 'Corpo inteiro', mov: ['perna', 'braco', 'tronco'],
    ini: corpo({ H: [84, 46], S: [80, 57], P: [64, 82], K: [88, 80], F: [80, 105], T: [89, 106], E: [92, 80], W: [96, 104] }),
    fim: corpo({ H: [38, 58], S: [48, 64], P: [90, 80], K: [110, 90], F: [130, 102], T: [134, 106], E: [48, 85], W: [48, 106] }),
    instrucoes: ['Agache e apoie as mãos no chão.', 'Leve as pernas para trás até a posição de prancha.', 'Volte as pernas, levante e, se quiser, finalize com um salto.'] },
]
const POR_ID = new Map(PADROES.map((p) => [p.id, p]))
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
/** Nome do exercício → padrão de movimento (ordem importa: o mais específico primeiro). null = sem ilustração confiável. */
const REGRAS: [RegExp, string][] = [
  [/\bsupino inclinado\b/, 'supino_inclinado'], [/\bsupino\b.*\b(no chao|no solo)\b|\bfloor press\b/, 'supino_chao'], [/\bsupino\b|\bchest press\b/, 'supino'],
  [/\bcrucifixo\b|\bvoador\b|\bpeck ?deck\b|\bfly\b/, 'crucifixo'],
  [/\bmesa flexora\b|\bflexora\b|\bleg curl\b/, 'flexora'],
  [/\bflex(ao|oes)\b|\bpush.?ups?\b/, 'flexao'],
  [/\bburpees?\b/, 'burpee'],
  [/\bleg ?press\b/, 'leg_press'], [/\bextensora\b/, 'extensora'],
  [/\bagachamento\b|\bsquat\b|\bgoblet\b/, 'agachamento'],
  [/\bafundo\b|\bavanco\b|\bpassada\b|\bbulgaro\b|\blunge\b/, 'afundo'],
  [/\bstiff\b|\blevantamento terra\b|\bterra romeno\b|\bgood morning\b|\brdl\b/, 'terra'],
  [/\bremada invertida\b|\binverted row\b/, 'remada_invertida'], [/\bremada\b|\brow\b/, 'remada'],
  [/\bpuxada\b|\bbarra fixa\b|\bpull ?down\b|\bpull.?ups?\b|\bchin.?ups?\b/, 'puxada'],
  [/\bface pull\b/, 'face_pull'],
  [/\belevacao lateral\b|\belevacao frontal\b/, 'elevacao_lateral'],
  [/\bem y\b|\belevacao de bracos\b/, 'elevacao_y'],
  [/\bdesenvolvimento\b|\barnold\b|\bmilitar\b|\boverhead press\b/, 'desenvolvimento'],
  [/\brosca\b|\bcurl\b/, 'rosca'],
  [/\btriceps frances\b|\bfrances\b|\btesta\b/, 'triceps_frances'], [/\btriceps\b|\bcoice\b|\bpulley\b/, 'triceps_polia'],
  [/\bmergulho\b|\bparalelas?\b|\bdips?\b/, 'mergulho'],
  [/\bprancha lateral\b/, 'prancha_lateral'], [/\bprancha\b|\bplank\b/, 'prancha'],
  [/\bdead ?bug\b/, 'dead_bug'], [/\babdominal\b|\babdominais\b|\bcrunch\b/, 'abdominal'],
  [/\belevacao pelvica\b|\bponte\b|\bhip thrust\b/, 'ponte'],
  [/\babducao\b.*\bdeitad|\bdeitad\w* de lado\b/, 'abducao_lateral'], [/\babdutora\b|\babducao\b/, 'abducao_sentado'],
  [/\bpanturrilhas?\b|\bgemeos\b|\bcalf\b/, 'panturrilha'],
  [/\bsubida (no|em) (degrau|banco|caixa|step)\b|\bstep.?up\b/, 'step'],
  [/\bpolichinelos?\b|\bjumping jacks?\b/, 'polichinelo'],
  [/\bbicicleta\b|\bbike\b|\bergometrica\b|\bspinning\b/, 'bike'],
  [/\bcorrida\b|\btrote\b|\bcorrer\b/, 'corrida'], [/\bcaminhada\b|\besteira\b|\bcaminhar\b/, 'caminhada'],
]
export function padraoDe(nome: string): Padrao | null { const t = nrm(nome); for (const [re, id] of REGRAS) if (re.test(t)) return POR_ID.get(id) || null; return null }
export const padraoPorId = (id: string) => POR_ID.get(id) || null
/** Versão das ilustrações (entra no endereço: mudou o desenho, muda o endereço e o cache antigo não é usado). */
export const VERSAO_ILUSTRACOES = '1'

const PALETA = {
  claro: { fundo: '#EEF3FB', chao: '#C9D4E5', corpo: '#334155', fundoCorpo: '#94A3B8', ativo: '#2563EB', equip: '#64748B', cab: '#334155' },
  escuro: { fundo: '#161B26', chao: '#2C3546', corpo: '#CBD5E1', fundoCorpo: '#5B6678', ativo: '#60A5FA', equip: '#94A3B8', cab: '#CBD5E1' },
}
const pts = (l: Pt[]) => l.map(([x, y]) => `${x},${y}`).join(' ')
/** SVG de uma fase (ini|fim) de um padrão. */
export function svg(p: Padrao, fase: 'ini' | 'fim', tema: 'claro' | 'escuro' = 'claro'): string {
  const c = PALETA[tema], pose = fase === 'fim' ? p.fim : p.ini, out: string[] = []
  out.push(`<rect width="160" height="120" rx="14" fill="${c.fundo}"/>`, `<line x1="8" y1="108" x2="152" y2="108" stroke="${c.chao}" stroke-width="3" stroke-linecap="round"/>`)
  for (const pr of pose.props || []) {
    if (pr.t === 'banco') { out.push(`<line x1="${pr.x1}" y1="${pr.y}" x2="${pr.x2}" y2="${pr.y}" stroke="${c.equip}" stroke-width="6" stroke-linecap="round"/>`, `<line x1="${pr.x1 + 6}" y1="${pr.y}" x2="${pr.x1 + 6}" y2="107" stroke="${c.equip}" stroke-width="3"/>`, `<line x1="${pr.x2 - 6}" y1="${pr.y}" x2="${pr.x2 - 6}" y2="107" stroke="${c.equip}" stroke-width="3"/>`); if (pr.incl) out.push(`<line x1="${pr.x1}" y1="${pr.y}" x2="${pr.incl[0]}" y2="${pr.incl[1]}" stroke="${c.equip}" stroke-width="6" stroke-linecap="round"/>`) }
    else if (pr.t === 'caixa') out.push(`<rect x="${pr.x}" y="${pr.y}" width="${pr.w}" height="${pr.h}" rx="3" fill="none" stroke="${c.equip}" stroke-width="3"/>`)
    else if (pr.t === 'linha') out.push(`<polyline points="${pts(pr.pts)}" fill="none" stroke="${c.equip}" stroke-width="${pr.w || 3}" stroke-linecap="round" stroke-linejoin="round"/>`)
    else if (pr.t === 'roda') out.push(`<circle cx="${pr.at[0]}" cy="${pr.at[1]}" r="${pr.r}" fill="none" stroke="${c.equip}" stroke-width="3"/>`)
    else if (pr.t === 'cabo') out.push(`<circle cx="${pr.de[0]}" cy="${pr.de[1]}" r="3" fill="${c.equip}"/>`, `<line x1="${pr.de[0]}" y1="${pr.de[1]}" x2="${pr.para[0]}" y2="${pr.para[1]}" stroke="${c.equip}" stroke-width="1.5" stroke-dasharray="3 2"/>`)
  }
  const ordem = Object.keys(pose.seg).sort((a, b) => Number(/2$/.test(b)) - Number(/2$/.test(a))) // os de trás primeiro
  for (const k of ordem) {
    const atras = /2$/.test(k), ativo = p.mov.includes(k)
    const cor = ativo ? c.ativo : atras ? c.fundoCorpo : c.corpo, w = k === 'tronco' ? 7 : 5
    out.push(`<polyline points="${pts(pose.seg[k])}" fill="none" stroke="${cor}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"${atras && !ativo ? ' opacity=".8"' : ''}/>`)
  }
  out.push(`<circle cx="${pose.cab[0]}" cy="${pose.cab[1]}" r="7.5" fill="${c.cab}"/>`)
  for (const pr of pose.props || []) {
    if (pr.t === 'halter') out.push(`<g transform="translate(${pr.at[0]},${pr.at[1]})"><rect x="-6" y="-1.5" width="12" height="3" rx="1.5" fill="${c.equip}"/><rect x="-8" y="-4.5" width="4" height="9" rx="1.5" fill="${c.equip}"/><rect x="4" y="-4.5" width="4" height="9" rx="1.5" fill="${c.equip}"/></g>`)
    else if (pr.t === 'barra') out.push(`<circle cx="${pr.at[0]}" cy="${pr.at[1]}" r="9" fill="none" stroke="${c.equip}" stroke-width="3.5"/><circle cx="${pr.at[0]}" cy="${pr.at[1]}" r="2" fill="${c.equip}"/>`)
    else if (pr.t === 'barraH') out.push(`<line x1="${pr.at[0] - (pr.w || 30) / 2}" y1="${pr.at[1]}" x2="${pr.at[0] + (pr.w || 30) / 2}" y2="${pr.at[1]}" stroke="${c.equip}" stroke-width="4" stroke-linecap="round"/>`)
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 120" width="320" height="240" role="img" aria-label="${p.nome} — posição ${fase === 'fim' ? 'final' : 'inicial'}">${out.join('')}</svg>`
}
/** Endereço das duas fases (o app escolhe o tema). */
export const urlIlustracao = (id: string, fase: 'ini' | 'fim') => `/api/v2/treino/ilustracao/${id}/${fase}.svg?v=${VERSAO_ILUSTRACOES}`
