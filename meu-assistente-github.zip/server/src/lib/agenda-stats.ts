// Evolução da agenda (Compromissos → calendário): estatísticas REAIS dos compromissos do próprio usuário.
// • Período por data do compromisso (dia local, no fuso do usuário/empresa); "novos agendamentos" pela data em que
//   o compromisso foi registrado (created_at convertido para o mesmo fuso).
// • Cada compromisso conta uma vez, pelo status atual: concluído (done), pendente (scheduled/confirmed),
//   cancelado (cancelled) e não compareceu (no_show). Cancelado nunca conta como concluído.
// • Período anterior equivalente: mesmo número de dias imediatamente antes. Percentuais sem divisão por zero
//   (sem base → null, e a tela mostra "sem base de comparação").
import { q } from '../db/index.js'
import { localDate } from './time.js'
import { fail } from './http.js'

export const PERIODOS = ['hoje', '7d', '30d', '90d', '12m', 'personalizado'] as const
type Grao = 'hora' | 'dia' | 'semana' | 'mes'
const DIA = 86400_000
const iso = (t: number) => new Date(t).toISOString().slice(0, 10)
const ms = (d: string) => Date.parse(d + 'T00:00:00Z')
export const somaDias = (d: string, n: number) => iso(ms(d) + n * DIA)
const diasEntre = (a: string, b: string) => Math.round((ms(b) - ms(a)) / DIA) + 1
const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 10000) / 100 : null)
const variacao = (atual: number, anterior: number) => (anterior > 0 ? Math.round(((atual - anterior) / anterior) * 10000) / 100 : null)

export function intervalo(periodo: string, hoje: string, de?: string, ate?: string): { de: string; ate: string; grao: Grao } {
  if (periodo === 'hoje') return { de: hoje, ate: hoje, grao: 'hora' }
  if (periodo === '7d') return { de: somaDias(hoje, -6), ate: hoje, grao: 'dia' }
  if (periodo === '30d') return { de: somaDias(hoje, -29), ate: hoje, grao: 'dia' }
  if (periodo === '90d') return { de: somaDias(hoje, -89), ate: hoje, grao: 'semana' }
  if (periodo === '12m') { const [y, m] = hoje.split('-').map(Number); const ini = new Date(Date.UTC(y, m - 12, 1)); return { de: iso(ini.getTime()), ate: hoje, grao: 'mes' } }
  // personalizado
  const ok = (s?: string) => !!s && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(ms(s))
  if (!ok(de) || !ok(ate) || de! > ate!) fail(400, 'Informe as datas inicial e final do período (a inicial antes da final).', 'periodo_invalido')
  const n = diasEntre(de!, ate!); if (n > 731) fail(400, 'O período personalizado pode ter até 2 anos.', 'periodo_longo')
  return { de: de!, ate: ate!, grao: n === 1 ? 'hora' : n <= 45 ? 'dia' : n <= 200 ? 'semana' : 'mes' }
}
/** Rótulos e chaves dos intervalos do gráfico. */
function baldes(de: string, ate: string, grao: Grao): { chave: string; ini: string; fim: string; rotulo: string }[] {
  const out: { chave: string; ini: string; fim: string; rotulo: string }[] = []
  const dm = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}`
  if (grao === 'hora') { for (let h = 0; h < 24; h++) out.push({ chave: String(h).padStart(2, '0'), ini: de, fim: ate, rotulo: `${String(h).padStart(2, '0')}h` }); return out }
  if (grao === 'dia') { for (let d = de; d <= ate; d = somaDias(d, 1)) out.push({ chave: d, ini: d, fim: d, rotulo: dm(d) }); return out }
  if (grao === 'semana') { for (let d = de; d <= ate; d = somaDias(d, 7)) { const f = somaDias(d, 6) > ate ? ate : somaDias(d, 6); out.push({ chave: d, ini: d, fim: f, rotulo: `${dm(d)}–${dm(f)}` }) } return out }
  const M = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
  let [y, m] = de.split('-').map(Number)
  for (;;) { const ini = `${y}-${String(m).padStart(2, '0')}-01`; if (ini > ate) break; const fimM = iso(Date.UTC(y, m, 0)); out.push({ chave: ini.slice(0, 7), ini: ini < de ? de : ini, fim: fimM > ate ? ate : fimM, rotulo: `${M[m - 1]}/${String(y).slice(2)}` }); m++; if (m > 12) { m = 1; y++ } }
  return out
}
const vazio = () => ({ total: 0, concluidos: 0, pendentes: 0, cancelados: 0, naoCompareceu: 0, novos: 0 })
type Cont = ReturnType<typeof vazio>
function contar(c: Cont, status: string) {
  c.total++
  if (status === 'done') c.concluidos++
  else if (status === 'cancelled') c.cancelados++
  else if (status === 'no_show') c.naoCompareceu++
  else c.pendentes++ // scheduled, confirmed (e qualquer status antigo sem desfecho)
}
function indicadores(c: Cont) {
  const registrados = c.concluidos + c.naoCompareceu
  return {
    ...c,
    taxaConclusao: pct(c.concluidos, c.total),
    taxaCancelamento: pct(c.cancelados, c.total),
    taxaComparecimento: registrados > 0 ? pct(c.concluidos, registrados) : null, // só quando há registro de comparecimento (concluído ou não compareceu)
  }
}

export async function estatisticas(userId: number, tz: string, periodo: string, de?: string, ate?: string) {
  const hoje = localDate(tz), p = PERIODOS.includes(periodo as any) ? periodo : '30d'
  const I = intervalo(p, hoje, de, ate), n = diasEntre(I.de, I.ate)
  // período anterior equivalente (mesma quantidade de dias, logo antes; nos 12 meses, os 12 meses anteriores)
  const A = p === '12m' ? { de: iso(Date.UTC(Number(I.de.slice(0, 4)) - 1, Number(I.de.slice(5, 7)) - 1, 1)), ate: somaDias(I.de, -1) } : { de: somaDias(I.de, -n), ate: somaDias(I.de, -1) }
  // uma única consulta: compromissos do período atual e do anterior (por data do compromisso OU de registro)
  const desdeUtc = new Date(ms(A.de) - 2 * DIA).toISOString(), ateUtc = new Date(ms(I.ate) + 2 * DIA).toISOString()
  const rows = await q("SELECT id, status, day, data, created_at FROM items WHERE user_id = $1 AND type = 'appointment' AND ((day >= $2 AND day <= $3) OR (created_at >= $4 AND created_at <= $5))", [userId, A.de, I.ate, desdeUtc, ateUtc])
  const vistos = new Set<number>()
  const B = baldes(I.de, I.ate, I.grao), BA = baldes(A.de, A.ate, I.grao)
  const serie = B.map(() => vazio()), serieAnt = BA.map(() => vazio()), atual = vazio(), anterior = vazio()
  const idx = (lista: typeof B, d: string, hora: string | null) => I.grao === 'hora' ? (hora ? Number(hora.slice(0, 2)) : -1) : lista.findIndex((b) => d >= b.ini && d <= b.fim)
  const semHora = { atual: 0 }
  for (const r of rows as any[]) {
    const id = Number(r.id); if (vistos.has(id)) continue; vistos.add(id) // cada compromisso uma vez
    const d = typeof r.data === 'string' ? JSON.parse(r.data || '{}') : r.data || {}, dia = String(r.day || ''), st = String(r.status || 'scheduled'), hora = d.time ? String(d.time) : null
    if (dia >= I.de && dia <= I.ate) { contar(atual, st); const k = idx(B, dia, hora); if (k >= 0) contar(serie[k], st); else semHora.atual++ }
    else if (dia >= A.de && dia <= A.ate) { contar(anterior, st); const k = idx(BA, dia, hora); if (k >= 0) contar(serieAnt[k], st) }
    // novos agendamentos: pelo dia (no fuso do usuário) em que o compromisso foi registrado
    const criado = localDate(tz, new Date(r.created_at)), hc = I.grao === 'hora' ? new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', hourCycle: 'h23' }).format(new Date(r.created_at)) : null
    if (criado >= I.de && criado <= I.ate) { atual.novos++; const k = idx(B, criado, hc ? hc + ':00' : null); if (k >= 0) serie[k].novos++ }
    else if (criado >= A.de && criado <= A.ate) { anterior.novos++; const k = idx(BA, criado, hc ? hc + ':00' : null); if (k >= 0) serieAnt[k].novos++ }
  }
  const pontos = B.map((b, i) => ({ chave: b.chave, rotulo: b.rotulo, de: b.ini, ate: b.fim, ...serie[i], anterior: serieAnt[i] ? { ...serieAnt[i], rotulo: BA[i].rotulo, de: BA[i].ini, ate: BA[i].fim } : null, variacao: i > 0 ? variacao(serie[i].total, serie[i - 1].total) : null }))
  return {
    hoje, periodo: p, fuso: tz, grao: I.grao, de: I.de, ate: I.ate, anterior: { de: A.de, ate: A.ate, ...indicadores(anterior) },
    atual: { ...indicadores(atual), semHorario: I.grao === 'hora' ? semHora.atual : 0 },
    comparacao: {
      total: { atual: atual.total, anterior: anterior.total, diferenca: atual.total - anterior.total, variacao: variacao(atual.total, anterior.total) },
      concluidos: { atual: atual.concluidos, anterior: anterior.concluidos, variacao: variacao(atual.concluidos, anterior.concluidos) },
      cancelados: { atual: atual.cancelados, anterior: anterior.cancelados, variacao: variacao(atual.cancelados, anterior.cancelados) },
      novos: { atual: atual.novos, anterior: anterior.novos, variacao: variacao(atual.novos, anterior.novos) },
    },
    pontos,
  }
}
