// ONDE A EMPRESA RECEBE OS NOVOS PEDIDOS: painel do sistema, WhatsApp da empresa, ou os dois.
//
// Configuração por empresa em businesses.data.recebimentoPedidos = { painel: boolean, whatsapp: boolean }
// (padrão: só o painel, que é o comportamento de sempre). Pelo menos um canal fica ligado.
//
// Regras:
//  • o pedido é SEMPRE gravado e aparece em Pedidos, com qualquer combinação — é lá que a empresa aceita, recusa e conclui;
//    o canal decide só para onde vai o AVISO de pedido novo;
//  • painel ligado → notificação no app (e push/e-mail conforme as preferências do dono), como antes;
//  • WhatsApp ligado → mensagem com o pedido completo para o WhatsApp cadastrado da empresa (lib/whatsapp-envio.ts);
//  • se o WhatsApp não puder ser confirmado (sem configuração, número inválido, falha), o aviso vai para o painel mesmo
//    com o painel desligado — nenhum pedido fica sem aviso;
//  • nenhum canal altera o status do pedido (nada é aceito ou concluído automaticamente);
//  • centrais de Lojas Conectadas continuam recebendo o repasse do aviso, qualquer que seja o canal.
import { one, q, J, nowIso } from '../db/index.js'
import { notify } from './notify.js'
import { HttpError } from './http.js'
import * as W from './whatsapp-envio.js'

export type Canais = { painel: boolean; whatsapp: boolean }
export const PADRAO: Canais = { painel: true, whatsapp: false }
export function canaisDe(data: unknown): Canais {
  const r = J<any>(data, {})?.recebimentoPedidos
  if (!r || typeof r !== 'object') return { ...PADRAO }
  const c = { painel: r.painel !== false, whatsapp: r.whatsapp === true }
  return c.painel || c.whatsapp ? c : { ...PADRAO }
}
type Aviso = { title: string; body?: string; link?: string; ref: string }

/** +55 11 98765-4321 (Brasil); outros países: +código e o número. */
export const fmtNumero = (d: string) => !d ? '' : /^55\d{10,11}$/.test(d) ? `+55 ${d.slice(2, 4)} ${d.slice(4, -4)}-${d.slice(-4)}` : '+' + d
/** Situação do recebimento para a tela da empresa (sem segredos). */
export async function situacao(b: any) {
  const x = J<any>(b.data, {}), canais = canaisDe(x), numero = W.numeroWhats(x.zap)
  return {
    canais, numero: fmtNumero(numero), numeroCadastrado: String(x.zap || ''), numeroValido: !!numero,
    whatsappDisponivel: await W.configurado(), provedor: (await W.cfgPublica()).nomeProvedor,
    ultimosEnvios: (await W.ultimosEnvios(Number(b.id), 8)).map((e) => ({ pedido: e.orderId, status: e.status, erro: e.erro, em: e.atualizadoEm, tentativas: e.tentativas })),
  }
}
/** Grava os canais (só esta chave de businesses.data, relida na hora para não desfazer outra alteração). */
export async function salvar(b: any, body: any): Promise<Canais> {
  const painel = body?.painel === true, whatsapp = body?.whatsapp === true
  if (!painel && !whatsapp) throw new HttpError(400, 'Escolha pelo menos um canal para receber os pedidos.', 'invalid')
  const x0 = J<any>(b.data, {})
  if (whatsapp && !W.numeroWhats(x0.zap)) throw new HttpError(400, 'Cadastre o WhatsApp da empresa (com DDD) para receber os pedidos por lá.', 'sem_numero')
  if (whatsapp && !(await W.configurado())) throw new HttpError(409, 'O envio automático pelo WhatsApp ainda não foi liberado pelo administrador do sistema.', 'whatsapp_indisponivel')
  const fresh = await one('SELECT data FROM businesses WHERE id = $1', [b.id]), d = J<any>(fresh?.data, {})
  d.recebimentoPedidos = { painel, whatsapp, atualizadoEm: nowIso() }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { painel, whatsapp }
}

/** Aviso de PEDIDO NOVO (catálogo, atendimento automático, Pix aprovado). Chamado uma vez por pedido e evento. */
export async function avisarNovoPedido(bid: number, orderId: number, aviso: Aviso, opts: { esperarWhatsApp?: boolean } = {}) {
  const b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [bid]); if (!b) return
  const x = J<any>(b.data, {}), canais = canaisDe(x), owner = Number(b.owner_id), aviso1 = { type: 'order', link: '/x/sua-empresa', ...aviso }
  if (canais.painel) await notify(owner, aviso1)
  else { // painel desligado: as centrais de Lojas Conectadas continuam recebendo o repasse (como notify faria)
    const LC = await import('./lojas-conectadas.js'); const org = await LC.origemDe(aviso.ref).catch(() => null)
    if (org && owner === org.ownerId) await LC.repassarCentrais(org, aviso1).catch((e) => console.error('[lojas]', e?.message))
  }
  if (!canais.whatsapp) return
  const o = await one('SELECT id, total, data, created_at FROM orders WHERE id = $1', [orderId]); if (!o) return
  const link = (await import('./publicurl.js')).pub() + '/x/sua-empresa'
  avisos.set(orderId, aviso1) // para levar ao painel, se o WhatsApp falhar
  await W.enfileirar(Number(b.id), orderId, W.numeroWhats(x.zap), W.textoPedido(o, x.empresa, link), opts.esperarWhatsApp)
}
const avisos = new Map<number, any>()
// WhatsApp não confirmado → o pedido vai para o painel (mesmo com o painel desligado), sem duplicar o aviso (mesma ref)
W.aoFalhar(async (orderId) => {
  const o = await one('SELECT id, business_id, total, data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const b = await one('SELECT owner_id, data FROM businesses WHERE id = $1', [o.business_id]); if (!b) return
  const d = J<any>(o.data, {}), env = await W.envioDoPedido(orderId)
  const base = avisos.get(orderId) || { type: 'order', link: '/x/sua-empresa', ref: `order-new:${orderId}`, title: `Novo pedido #${orderId} · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente || ''} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'}` }
  avisos.delete(orderId)
  const motivo = env?.status === 'incerto' ? 'o WhatsApp não confirmou o envio' : 'não foi possível enviar ao WhatsApp'
  await notify(Number(b.owner_id), { ...base, body: `${base.body || ''} · ${motivo}`.replace(/^ · /, '') })
})
