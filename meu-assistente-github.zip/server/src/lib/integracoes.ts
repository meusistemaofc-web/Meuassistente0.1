// Integrações das empresas: Mercado Pago, SMTP próprio e as próximas (WhatsApp, APIs externas…), uma linha por empresa e
// provedor em empresa_integracoes, separada do JSON businesses.data.
//
// Regras (valem para todo provedor registrado em PROVEDORES):
//  • só este módulo grava integrações; a gravação é atômica por versão (otimista: UPDATE … WHERE versao = lida), então uma
//    rotina com leitura antiga nunca desfaz o que outra acabou de gravar (ex.: a renovação do token do Mercado Pago);
//  • cada alteração guarda a versão anterior em empresa_integracoes_historico (backup); antes de migrações do banco, todas
//    as integrações também são copiadas para lá;
//  • nunca grava uma configuração sem credenciais por cima de uma que tinha, a não ser que o pedido seja explicitamente de
//    desconectar (permitirLimpar);
//  • tudo é por business_id: quem chama já verificou que a empresa é do usuário (ownBusiness), e nenhuma consulta daqui
//    mistura empresas;
//  • segredos ficam cifrados (settings.seal) e não saem em respostas: use semSegredos()/resumoPublico().
//  • dados que ainda estão no lugar antigo (businesses.data) são copiados para cá na primeira leitura ou ao iniciar o app,
//    sem apagar o original — uma versão antiga do sistema continua achando o que esperava.
import { one, q, J, nowIso } from '../db/index.js'

export type Dados = Record<string, any>
export interface Provedor {
  id: string; nome: string
  /** campos cifrados (caminhos com ponto) — nunca saem em respostas */
  segredos: string[]
  /** status calculado dos dados (sem abrir segredos) */
  status: (d: Dados) => string
  /** dados no formato antigo (dentro de businesses.data), se houver */
  legado?: (data: Dados) => Dados | null
  /** chaves que pertenciam ao provedor dentro de businesses.data (para limpar das respostas) */
  chavesLegado?: string[]
}
const MP_KEYS = ['mpTok', 'mpSecret', 'mpRefresh', 'mpExp', 'mpUserId', 'mpConta', 'mpModo', 'mpStatus', 'mpErro', 'mpTeste', 'mpConectadoEm', 'mpRenovadoEm', 'mpVerificadoEm', 'mpUltimaFalha']
const pick = (o: Dados, ks: string[]) => Object.fromEntries(ks.filter((k) => o[k] !== undefined).map((k) => [k, o[k]]))
export const PROVEDORES: Record<string, Provedor> = {
  mercadopago: {
    id: 'mercadopago', nome: 'Mercado Pago', segredos: ['mpTok', 'mpRefresh', 'mpSecret'], chavesLegado: MP_KEYS,
    status: (d) => !d.mpTok ? 'desconectado' : d.mpStatus === 'erro' ? 'erro' : 'conectado',
    legado: (x) => (x.mpTok || x.mpSecret || x.mpRefresh ? pick(x, MP_KEYS) : null),
  },
  smtp: {
    id: 'smtp', nome: 'E-mail (SMTP próprio)', segredos: ['smtp.senha'],
    status: (d) => (d.smtpProprio && d.smtp?.host ? 'configurado' : d.smtp?.host ? 'desligado' : 'desconectado'),
    legado: (x) => (x.email?.smtp && (x.email.smtp.host || x.email.smtp.senha) ? { smtpProprio: !!x.email.smtpProprio, smtp: { ...x.email.smtp } } : null),
  },
  // Próximas integrações entram aqui (ex.: whatsapp: { segredos: ['token'], … }) e ganham automaticamente a mesma
  // persistência, versão, histórico, backup antes de migrações, isolamento por empresa e limpeza de segredos.
}
const prov = (id: string) => { const p = PROVEDORES[id]; if (!p) throw new Error(`Integração desconhecida: ${id}`); return p }
const obter = (o: any, cam: string) => cam.split('.').reduce((a, k) => (a == null ? a : a[k]), o)
const temSegredo = (p: Provedor, d: Dados) => p.segredos.some((c) => !!obter(d, c))
const igual = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b)

export interface Registro { id: number; businessId: number; provedor: string; dados: Dados; status: string; versao: number; origem: string; atualizadoEm: string }
const reg = (r: any): Registro => ({ id: Number(r.id), businessId: Number(r.business_id), provedor: String(r.provedor), dados: J<Dados>(r.dados, {}), status: String(r.status || ''), versao: Number(r.versao) || 1, origem: String(r.origem || 'app'), atualizadoEm: String(r.atualizado_em || '') })
const linha = async (bid: number, p: string) => { const r = await one('SELECT * FROM empresa_integracoes WHERE business_id = $1 AND provedor = $2', [bid, p]); return r ? reg(r) : null }

async function historico(r: Registro, motivo: string) {
  if (!Object.keys(r.dados).length && r.status === 'desconectado') return
  await q('INSERT INTO empresa_integracoes_historico (business_id, provedor, versao, dados, status, motivo, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7)', [r.businessId, r.provedor, r.versao, JSON.stringify(r.dados), r.status, motivo.slice(0, 200), nowIso()])
  // mantém as 100 versões mais recentes por empresa e provedor
  const velhas = await q('SELECT id FROM empresa_integracoes_historico WHERE business_id = $1 AND provedor = $2 ORDER BY id DESC LIMIT 1000 OFFSET 100', [r.businessId, r.provedor])
  for (const v of velhas) await q('DELETE FROM empresa_integracoes_historico WHERE id = $1', [v.id])
}
/** Copia para cá o que ainda estiver só em businesses.data (sem apagar de lá). Idempotente: nunca sobrescreve uma linha. */
async function importar(bid: number, p: Provedor, dataEmpresa?: Dados): Promise<Registro | null> {
  if (!p.legado) return null
  const data = dataEmpresa ?? J<Dados>((await one('SELECT data FROM businesses WHERE id = $1', [bid]))?.data, {})
  const d = p.legado(data); if (!d) return null
  try {
    await q('INSERT INTO empresa_integracoes (business_id, provedor, dados, status, versao, origem, criado_em, atualizado_em) VALUES ($1,$2,$3,$4,1,$5,$6,$6)', [bid, p.id, JSON.stringify(d), p.status(d), 'importado', nowIso()])
    const r = await linha(bid, p.id); if (r) await historico(r, 'importado de businesses.data (original mantido)')
    return r
  } catch { return linha(bid, p.id) } // outra rotina importou ao mesmo tempo: vale a que entrou
}
/** Integração da empresa (ou null se nunca configurada). */
export async function ler(bid: number, provedor: string): Promise<Registro | null> {
  const p = prov(provedor); return (await linha(bid, p.id)) || importar(bid, p)
}
export async function dados(bid: number, provedor: string): Promise<Dados> { return (await ler(bid, provedor))?.dados || {} }
/** Mesma leitura para várias empresas numa consulta só (listas: "Minhas empresas", administração). Recebe as linhas de
 *  businesses já carregadas (id, data) para não reler cada empresa; só importa do formato antigo quem precisar. */
export async function dadosDeVarias(empresas: Record<string, any>[], provedor: string): Promise<Map<number, Dados>> {
  const p = prov(provedor), ids = [...new Set(empresas.map((b) => Number(b.id)).filter((x) => x > 0))], out = new Map<number, Dados>()
  if (!ids.length) return out
  for (let i = 0; i < ids.length; i += 500) { const lote = ids.slice(i, i + 500)
    for (const r of await q(`SELECT business_id, dados FROM empresa_integracoes WHERE provedor = $1 AND business_id IN (${lote.map((_, k) => '$' + (k + 2)).join(',')})`, [p.id, ...lote])) out.set(Number((r as any).business_id), J<Dados>((r as any).dados, {})) }
  if (p.legado) for (const b of empresas) { const id = Number(b.id); if (out.has(id)) continue; const data = J<Dados>(b.data, {}); if (p.legado(data)) { const r = await importar(id, p, data); if (r) out.set(id, r.dados) } }
  return out
}

export class ConflitoIntegracao extends Error {}
/** Altera a integração da empresa de forma atômica. fn recebe uma cópia dos dados atuais e devolve os novos.
 *  Repete se outra gravação entrou no meio (fn é chamada de novo com os dados atualizados). */
export async function atualizar(bid: number, provedor: string, fn: (d: Dados) => Dados | Promise<Dados>, motivo: string, opts: { permitirLimpar?: boolean } = {}): Promise<Registro> {
  const p = prov(provedor)
  for (let tentativa = 0; tentativa < 6; tentativa++) {
    const atual = await ler(bid, p.id)
    const antes = atual?.dados || {}, novo = await fn(structuredClone(antes))
    if (!novo || typeof novo !== 'object') throw new Error('Dados de integração inválidos.')
    if (temSegredo(p, antes) && !temSegredo(p, novo) && !opts.permitirLimpar) throw new Error(`Proteção: a gravação apagaria as credenciais de ${p.nome} sem um pedido de desconexão. Nada foi alterado.`)
    if (atual && igual(antes, novo)) return atual
    const st = p.status(novo), agora = nowIso()
    if (!atual) {
      try { await q('INSERT INTO empresa_integracoes (business_id, provedor, dados, status, versao, origem, criado_em, atualizado_em) VALUES ($1,$2,$3,$4,1,$5,$6,$6)', [bid, p.id, JSON.stringify(novo), st, 'app', agora]) } catch { continue } // corrida na criação: relê
      return (await linha(bid, p.id))!
    }
    const ok = await q('UPDATE empresa_integracoes SET dados = $1, status = $2, versao = versao + 1, atualizado_em = $3 WHERE id = $4 AND versao = $5 RETURNING id', [JSON.stringify(novo), st, agora, atual.id, atual.versao])
    if (ok.length) { await historico(atual, motivo); return (await linha(bid, p.id))! }
  }
  throw new ConflitoIntegracao('A integração foi alterada ao mesmo tempo por outra operação. Tente de novo.')
}

/** Backup de todas as integrações (antes de migrações do banco ou de operações em massa). */
export async function backupTodas(motivo: string): Promise<number> {
  let n = 0
  try { for (const r of await q('SELECT * FROM empresa_integracoes ORDER BY id')) { await historico(reg(r), motivo); n++ } } catch { /* tabela ainda não existe */ }
  return n
}
/** Ao iniciar: copia para a nova estrutura as integrações que só existem no formato antigo. Não apaga nada. */
export async function importarTodas(): Promise<number> {
  let n = 0
  for (const b of await q('SELECT id, data FROM businesses')) {
    const data = J<Dados>((b as any).data, {})
    for (const p of Object.values(PROVEDORES)) if (p.legado && p.legado(data) && !(await linha(Number((b as any).id), p.id))) { if (await importar(Number((b as any).id), p, data)) n++ }
  }
  return n
}

/** Remove segredos e campos internos de integração de um businesses.data antes de devolver ao navegador. */
export function semSegredos<T extends Dados>(data: T): T {
  if (!data || typeof data !== 'object') return data
  const d: any = { ...data }
  for (const p of Object.values(PROVEDORES)) for (const k of p.chavesLegado || []) delete d[k]
  if (d.email?.smtp) d.email = { ...d.email, smtp: { ...d.email.smtp, senha: '', temSenha: !!d.email.smtp.senha } }
  return d
}
/** Situação das integrações da empresa, sem nenhum segredo (painel da empresa e diagnóstico). */
export async function resumoPublico(bid: number) {
  const out: Record<string, { nome: string; status: string; configurada: boolean; atualizadaEm: string | null; versao: number }> = {}
  for (const p of Object.values(PROVEDORES)) { const r = await ler(bid, p.id); out[p.id] = { nome: p.nome, status: r ? p.status(r.dados) : 'desconectado', configurada: !!r && temSegredo(p, r.dados), atualizadaEm: r?.atualizadoEm || null, versao: r?.versao || 0 } }
  return out
}
