// Importador inteligente de cardápios/catálogos: leitura LOCAL na Central de Mídias (OCR + regras, sem IA) e, se houver, IA.
// Fluxo: arquivos (fotos/PDF/DOCX) → fila assíncrona com progresso → leitura multimodal (OCR/texto como alternativa) → rascunho para REVISÃO
// → publicação só após confirmação, usando o serviço ÚNICO de cadastro (salvarProduto) → histórico, origem e reversão.
import { createHash } from 'node:crypto'
import { inflateRawSync } from 'node:zlib'
import { q, one, J, nowIso, db } from '../db/index.js'
import { HttpError } from './http.js'
import { askFiles, run, readyCount } from '../ai/engine.js'
import { processarNaCentral, centralConfigurada } from './central-midia.js'
import { politicaLeitura } from '../ai/leitura-local.js'
import { parseJsonLoose } from '../ai/types.js'
import { pdfText, ocrImage } from '../ai/docs.js'
import { salvarProduto, unitPrice } from '../routes/businesses.js'

export const MAX_ARQUIVOS = 12
export const MAX_ARQUIVO_BYTES = 12 * 1024 * 1024
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const clip = (v: any, n: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n)

/* ---------- validação do arquivo (pelo conteúdo, não pela extensão) ---------- */
export function tipoDoArquivo(buf: Buffer): 'image/jpeg' | 'image/png' | 'image/webp' | 'application/pdf' | 'docx' | null {
  if (buf.length < 12) return null
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg'
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png'
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp'
  if (buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'application/pdf'
  if (buf[0] === 0x50 && buf[1] === 0x4b && buf.includes(Buffer.from('word/document.xml'))) return 'docx'
  return null
}

/** Texto de um .docx (zip com word/document.xml), sem dependências. */
export function docxText(buf: Buffer): string {
  let pos = buf.lastIndexOf(Buffer.from([0x50, 0x4b, 0x01, 0x02])) // última entrada do diretório central; varre desde o início
  const eocd = buf.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06])); if (eocd < 0) return ''
  const n = buf.readUInt16LE(eocd + 10); pos = buf.readUInt32LE(eocd + 16)
  for (let i = 0; i < n && pos + 46 <= buf.length; i++) {
    if (buf.readUInt32LE(pos) !== 0x02014b50) break
    const method = buf.readUInt16LE(pos + 10), csize = buf.readUInt32LE(pos + 20), nlen = buf.readUInt16LE(pos + 28), elen = buf.readUInt16LE(pos + 30), clen = buf.readUInt16LE(pos + 32), off = buf.readUInt32LE(pos + 42)
    const name = buf.subarray(pos + 46, pos + 46 + nlen).toString('utf8')
    if (name === 'word/document.xml') {
      const ln = buf.readUInt16LE(off + 26), le = buf.readUInt16LE(off + 28), start = off + 30 + ln + le
      const raw = buf.subarray(start, start + csize), xml = (method === 8 ? inflateRawSync(raw) : raw).toString('utf8')
      return xml.replace(/<\/w:p>/g, '\n').replace(/<w:tab\/>/g, '\t').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/\n{3,}/g, '\n\n').trim()
    }
    pos += 46 + nlen + elen + clen
  }
  return ''
}

/* ---------- leitura por IA ---------- */
const PROMPT = `Você lê CARDÁPIOS, catálogos e tabelas de preços (restaurantes, lanchonetes, lojas, serviços, qualquer segmento) para o app Meu Assistente. Marcador: IMPORTADOR-CARDAPIO.
Extraia TODOS os itens do documento, agrupando por categoria como aparece nele (ex.: Hambúrgueres, Pizzas, Bebidas, Sobremesas, Porções, Combos, Serviços).
REGRAS: NÃO invente nada. Campo que não aparece fica "" / null / []. Preços em reais como número (12.5). Ingredientes só se estiverem escritos.
- "descricao": texto ORIGINAL do documento (ingredientes/explicação). Se o documento tem só nome e preço, deixe "".
- "descricao_sugerida": SOMENTE quando "descricao" está vazia: frase comercial curta (até 110 caracteres) baseada apenas no nome e na categoria, SEM citar ingredientes, tamanhos, benefícios ou características que não estejam escritos. Caso contrário "".
- "variacoes": grupos como Tamanho (opções com o PREÇO FINAL de cada tamanho) ou outros grupos de escolha. "adicionais": extras com o valor a somar (ex.: Bacon +4,00).
- "disponivel": true/false só se o documento disser (esgotado, indisponível); senão null.
- "confianca": 0 a 1 (quão seguro você está da leitura deste item). "duvida": explique em poucas palavras se o nome/preço está borrado, cortado ou ambíguo; senão "".
- "tipo": "produto" ou "servico".
Responda SOMENTE com JSON: {"legivel":bool,"produtos":[{"nome":"","descricao":"","descricao_sugerida":"","preco":number|null,"categoria":"","ingredientes":[""],"variacoes":[{"nome":"","opcoes":[{"nome":"","preco":number}]}],"adicionais":[{"nome":"","preco":number}],"disponivel":bool|null,"observacoes":"","confianca":number,"duvida":"","tipo":"produto"}]}`

const validar = (m: any): string | null => { try { const j = parseJsonLoose(String(m.content || '')); if (!j || typeof j !== 'object' || !Array.isArray(j.produtos)) return 'JSON sem a lista "produtos"'; return null } catch { return 'resposta não é JSON' } }
const preco = (v: any): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) && v >= 0 && v < 1e6 ? Math.round(v * 100) / 100 : null
  const s = String(v ?? '').replace(/[^\d,.-]/g, ''); if (!s) return null
  const n = Number(s.includes(',') ? s.replace(/\./g, '').replace(',', '.') : s)
  return Number.isFinite(n) && n >= 0 && n < 1e6 ? Math.round(n * 100) / 100 : null
}

/* ---------- leitura LOCAL (Central de Mídias, sem IA) ---------- */
/** Lê o cardápio na central. disponivel=false quando a central não está configurada/no ar (segue-se pelo caminho com IA). */
export async function lerCardapioLocal(f: { name: string; mime: string; data: Buffer }, businessId: number): Promise<{ disponivel: boolean; itens: any[]; avisos: string[]; erro?: string }> {
  if (!centralConfigurada()) return { disponivel: false, itens: [], avisos: [] }
  const mime = f.mime === 'docx' ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : f.mime
  const ext = f.mime === 'docx' ? 'docx' : f.mime === 'application/pdf' ? 'pdf' : (f.mime.split('/')[1] || 'jpg').replace('jpeg', 'jpg')
  // só o número interno da empresa vai para o registro da central; o arquivo é apagado lá ao fim da leitura
  const r = await processarNaCentral(f.data, `cardapio.${ext}`, mime, { cliente: `b${businessId}`, cardapio: true, comprovante: 'nunca', codigos: false, interpretar: '0', tempoMs: 150_000 })
  if (!r.ok) return r.indisponivel ? { disponivel: false, itens: [], avisos: [] } : { disponivel: true, itens: [], avisos: [], erro: r.mensagem }
  const c = r.cardapio || { itens: [], avisos: [] } as any
  const avisos = [...(r.avisos || []).filter((a) => /foto_girada|ocr_baixa/.test(a)), ...(c.avisos || [])]
  return { disponivel: true, itens: Array.isArray(c.itens) ? c.itens : [], avisos }
}

/** Ordem de leitura (mesma política da leitura de comprovantes no Painel → IA): local primeiro (padrão), só local ou IA primeiro.
 *  Com o modo "Sem IA (teste)" ou sem IA configurada, a leitura é SÓ local. */
async function lerArquivo(f: { name: string; mime: string; data: Buffer }, businessId = 0): Promise<{ itens: any[]; leitura: 'local' | 'ia' }> {
  const pol = await politicaLeitura()
  // o caminho com IA sempre termina numa IA de texto (a visão é opcional): sem nenhuma pronta (ou no modo "Sem IA"), só resta a leitura local
  const temIA = (await readyCount('conversa').catch(() => 0)) > 0
  const semItens = () => new HttpError(422, 'Não encontrei produtos com preço neste arquivo. Tente uma foto mais nítida, reta, bem iluminada e com o cardápio inteiro.', 'unreadable')
  if (pol !== 'ia_primeiro') {
    const loc = await lerCardapioLocal(f, businessId)
    if (loc.disponivel) {
      if (loc.itens.length) return { itens: loc.itens, leitura: 'local' }
      if (pol === 'so_local' || !temIA) throw loc.erro ? new HttpError(422, loc.erro, 'unreadable') : semItens()
    } else if (pol === 'so_local' || !temIA) {
      throw new HttpError(503, 'A leitura de cardápios no servidor está indisponível no momento. Tente novamente em alguns minutos.', 'unavailable')
    }
  }
  try { return { itens: await lerArquivoIA(f), leitura: 'ia' } }
  catch (e) {
    if (pol === 'ia_primeiro') { const loc = await lerCardapioLocal(f, businessId); if (loc.itens.length) return { itens: loc.itens, leitura: 'local' } }
    throw e
  }
}

async function lerArquivoIA(f: { name: string; mime: string; data: Buffer }): Promise<any[]> {
  let out = ''
  const viaTexto = async (txt: string) => {
    const partes: string[] = []; for (let i = 0; i < txt.length; i += 9000) partes.push(txt.slice(i, i + 9000))
    const lista: any[] = []
    for (const p of partes.slice(0, 8)) {
      const r = await run([{ role: 'user', content: PROMPT + '\n\nTEXTO EXTRAÍDO DO ARQUIVO (pode ter quebras estranhas):\n' + p }], { json: true, parallel: 'off', validate: validar })
      const j = parseJsonLoose(String(r.message.content || '')); lista.push(...(j.produtos || []))
    }
    return lista
  }
  if (f.mime === 'docx') { const t = docxText(f.data); if (t.replace(/\s/g, '').length < 10) throw new Error('Documento sem texto legível.'); return viaTexto(t) }
  try {
    out = await askFiles(PROMPT, [{ mime: f.mime, data: f.data.toString('base64') }], { json: true, validate: validar })
    const j = parseJsonLoose(out)
    if (j.produtos.length) return j.produtos
    throw new Error('nenhum item lido')
  } catch (e: any) {
    // sem IA com visão (ou ilegível para ela): PDF digital tem texto; foto passa pelo OCR; qualquer IA de texto interpreta
    const txt = f.mime === 'application/pdf' ? pdfText(f.data) : await ocrImage(f.data, f.mime).catch(() => '')
    console.error(`[cardapio] leitura direta falhou (${e?.message || e}); tentativas: ${JSON.stringify(e?.attempts || [])}; texto alternativo: ${txt.length} caracteres`)
    if (txt.replace(/\s/g, '').length < 20) throw new HttpError(422, 'Não consegui ler este arquivo. Tente uma foto mais nítida, reta e bem iluminada.', 'unreadable')
    return viaTexto(txt)
  }
}

/* ---------- normalização do que a IA devolveu ---------- */
export interface ItemRascunho {
  id: string; nome: string; descricao: string; descricaoIA: string; descricaoOrigem: 'original' | 'ia' | 'manual' | ''; preco: number | null; categoria: string
  ingredientes: string[]; variacoes: { nome: string; opcoes: { nome: string; preco: number }[] }[]; adicionais: { nome: string; preco: number }[]
  disponivel: boolean | null; observacoes: string; confianca: number; avisos: string[]; revisar: boolean; confirmado: boolean; selecionado: boolean
  tipo: 'produto' | 'servico'; arquivo: string; foto: string; acao: '' | 'novo' | 'atualizar' | 'manter'; origemManual?: boolean
}
const grupo = (g: any) => ({ nome: clip(g?.nome, 40), opcoes: (Array.isArray(g?.opcoes) ? g.opcoes : []).slice(0, 12).map((o: any) => ({ nome: clip(o?.nome, 40), preco: preco(o?.preco) ?? 0 })).filter((o: any) => o.nome) })
/** Normaliza e valida um item (vindo da IA ou editado pelo usuário). Recalcula alertas; nada incerto é marcado como confirmado. */
export function sanitizarItem(raw: any, idx = 0, arquivo = ''): ItemRascunho | null {
  const nome = clip(raw?.nome, 80); if (nome.length < 2) return null
  const variacoes = (Array.isArray(raw.variacoes) ? raw.variacoes : []).slice(0, 6).map(grupo).filter((v: any) => v.nome && v.opcoes.length)
  const adicionais = (Array.isArray(raw.adicionais) ? raw.adicionais : []).slice(0, 30).map((a: any) => ({ nome: clip(a?.nome, 40), preco: preco(a?.preco) ?? 0 })).filter((a: any) => a.nome)
  const descricao = clip(raw.descricao, 600), descricaoIA = clip(raw.descricaoIA ?? raw.descricao_sugerida, 160)
  let origem: ItemRascunho['descricaoOrigem'] = raw.descricaoOrigem === 'manual' ? 'manual' : descricao ? 'original' : descricaoIA ? 'ia' : ''
  if (raw.descricaoOrigem === 'manual' && !descricao) origem = descricaoIA ? 'ia' : ''
  let p = preco(raw.preco); const avisos: string[] = Array.isArray(raw.avisos) ? raw.avisos.filter((a: any) => typeof a === 'string' && !/^(Preço|Leitura|Adicional|Possível|Repetido|Duvida|Dúvida)/.test(a)).slice(0, 5) : []
  const tipo = raw.tipo === 'servico' ? 'servico' : 'produto'
  const grupoPreco = variacoes.find((v: any) => v.opcoes.length && v.opcoes.every((o: any) => o.preco > 0))
  if ((p === null || p === 0) && grupoPreco) p = Math.min(...grupoPreco.opcoes.map((o: any) => o.preco))
  let conf = Number(raw.confianca); conf = Number.isFinite(conf) ? Math.max(0, Math.min(1, conf)) : 0.6
  const duvida = clip(raw.duvida, 160)
  if (duvida) avisos.push('Dúvida na leitura: ' + duvida)
  if (p === null || p <= 0) avisos.push('Preço não identificado — informe o valor.')
  if (conf < 0.7) avisos.push('Leitura com baixa confiança — confira nome e preço.')
  // preços de adicionais precisam ser coerentes com a regra de preço do catálogo (somam ao valor; não substituem)
  const base = grupoPreco ? Math.min(...grupoPreco.opcoes.map((o: any) => o.preco)) : p || 0
  if (adicionais.some((a: any) => a.preco > 0 && base > 0 && a.preco >= base * 0.5)) avisos.push('Adicional com valor alto em relação ao produto — confira antes de publicar.')
  const revisar = avisos.length > 0 && (conf < 0.7 || p === null || p <= 0 || !!duvida || avisos.some((a) => /Adicional com valor alto/.test(a)))
  return {
    id: String(raw.id || 'i' + (idx + 1)), nome, descricao, descricaoIA, descricaoOrigem: origem, preco: p, categoria: clip(raw.categoria, 40) || (tipo === 'servico' ? 'Serviços' : 'Outros'),
    ingredientes: (Array.isArray(raw.ingredientes) ? raw.ingredientes : []).map((x: any) => clip(x, 40)).filter(Boolean).slice(0, 20), variacoes, adicionais,
    disponivel: typeof raw.disponivel === 'boolean' ? raw.disponivel : null, observacoes: clip(raw.observacoes, 200), confianca: Math.round(conf * 100) / 100, avisos, revisar,
    confirmado: raw.confirmado === true && !!(p !== null && p > 0), selecionado: raw.selecionado === undefined ? !revisar : raw.selecionado === true, tipo, arquivo: clip(raw.arquivo || arquivo, 120),
    foto: typeof raw.foto === 'string' && raw.foto.startsWith('data:image/') && raw.foto.length < 900_000 ? raw.foto : '', acao: ['novo', 'atualizar', 'manter'].includes(raw.acao) ? raw.acao : '',
  }
}
/** Junta as leituras de várias páginas/arquivos: o mesmo item lido duas vezes (páginas sobrepostas) fica só uma vez e é sinalizado. */
function consolidar(brutos: { raw: any; arquivo: string }[]): ItemRascunho[] {
  const vistos = new Map<string, ItemRascunho>(), out: ItemRascunho[] = []
  brutos.forEach((b, i) => {
    const it = sanitizarItem({ ...b.raw, id: 'i' + (out.length + 1) }, i, b.arquivo); if (!it) return
    const k = norm(it.nome) + '|' + norm(it.categoria), prev = vistos.get(k)
    if (prev) { if (prev.preco === it.preco) return; it.avisos.push('Repetido com preço diferente de outro item igual no documento.'); it.revisar = true; it.selecionado = false }
    else vistos.set(k, it)
    it.id = 'i' + (out.length + 1); out.push(it)
  })
  return out
}

/* ---------- duplicidades com o catálogo atual da MESMA empresa ---------- */
const lev = (a: string, b: string) => { const m = a.length, n = b.length; if (!m) return n; if (!n) return m; let prev = Array.from({ length: n + 1 }, (_, j) => j); for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur } return prev[n] }
export function parecidos(a: string, b: string): { score: number; igual: boolean } {
  const x = norm(a), y = norm(b); if (!x || !y) return { score: 0, igual: false }
  if (x === y) return { score: 1, igual: true }
  const sing = (s: string) => s.split(' ').map((w) => w.replace(/(s|es)$/, '')).join(' ')
  if (sing(x) === sing(y)) return { score: 0.97, igual: false }
  const ta = new Set(x.split(' ')), tb = new Set(y.split(' ')), inter = [...ta].filter((t) => tb.has(t)).length
  const jac = inter / (ta.size + tb.size - inter), sim = 1 - lev(x, y) / Math.max(x.length, y.length)
  return { score: Math.max(jac >= 0.8 ? jac : 0, sim), igual: false }
}
export async function duplicidades(businessId: number, itens: ItemRascunho[]) {
  const existentes = (await q('SELECT id, data, active FROM products WHERE business_id = $1', [businessId])).map((r: any) => ({ id: Number(r.id), d: J<any>(r.data, {}), ativo: r.active === true || r.active === 1 }))
  const res: Record<string, any> = {}
  for (const it of itens) {
    let best: any = null
    for (const e of existentes) {
      const s = parecidos(it.nome, e.d.nome || ''); if (s.score < 0.86) continue
      const mesmaCat = norm(it.categoria) === norm(e.d.categoria || '')
      const sc = s.score + (mesmaCat ? 0.02 : 0)
      if (!best || sc > best.sc) best = { sc, id: e.id, nome: e.d.nome, preco: e.d.preco, categoria: e.d.categoria, mesmaCategoria: mesmaCat, igual: s.igual, mesmoPreco: it.preco !== null && Number(e.d.preco) === it.preco, variacoes: (e.d.variacoes || []).length }
    }
    if (best) { delete best.sc; res[it.id] = best }
  }
  return res
}

/* ---------- registro e fila ---------- */
const outImp = (r: any, comItens = false) => ({
  id: Number(r.id), businessId: Number(r.business_id), userId: Number(r.user_id), status: r.status, etapa: r.stage || '', progresso: Number(r.progress), arquivos: J<any[]>(r.files, []),
  identificados: Number(r.n_identified), cadastrados: Number(r.n_created), atualizados: Number(r.n_updated), ignorados: Number(r.n_ignored), revisao: Number(r.n_review), erro: r.error || '',
  criadoEm: r.created_at, atualizadoEm: r.updated_at, concluidoEm: r.finished_at || null, ...(comItens ? { itens: J<ItemRascunho[]>(r.items, []) } : {}),
})
export { outImp }
const rodando = new Set<number>()
const upd = (id: number, f: Record<string, any>) => {
  const ks = Object.keys(f); return q(`UPDATE menu_imports SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${ks.length + 1} WHERE id = $${ks.length + 2}`, [...ks.map((k) => f[k]), nowIso(), id])
}
export async function criar(businessId: number, userId: number) {
  const now = nowIso()
  const r = await q('INSERT INTO menu_imports (business_id, user_id, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$4) RETURNING *', [businessId, userId, 'rascunho', now])
  return outImp(r[0])
}
export async function anexar(imp: any, name: string, buf: Buffer) {
  if (imp.status !== 'rascunho') throw new HttpError(409, 'Esta importação já foi iniciada.', 'conflict')
  const n = Number((await one('SELECT COUNT(*) AS n FROM menu_import_files WHERE import_id = $1', [imp.id]))?.n || 0)
  if (n >= MAX_ARQUIVOS) throw new HttpError(400, `Máximo de ${MAX_ARQUIVOS} arquivos por importação.`, 'invalid')
  if (buf.length > MAX_ARQUIVO_BYTES) throw new HttpError(413, `Arquivo grande demais (máximo ${Math.round(MAX_ARQUIVO_BYTES / 1048576)} MB).`, 'payload_too_large')
  const mime = tipoDoArquivo(buf)
  if (!mime) throw new HttpError(400, 'Formato não suportado. Envie JPG, PNG, WEBP, PDF ou DOCX.', 'invalid')
  await q('INSERT INTO menu_import_files (import_id, idx, name, mime, size, data, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [imp.id, n, clip(name, 120) || 'arquivo', mime, buf.length, buf.toString('base64'), nowIso()])
  return { nome: clip(name, 120), mime, tamanho: buf.length, total: n + 1 }
}
/** Inicia o processamento em segundo plano. Importação idêntica (mesmo conteúdo) já feita/em andamento na mesma empresa não é repetida. */
export async function iniciar(imp: any, forcar = false) {
  const fs = await q('SELECT id, idx, name, mime, size, data FROM menu_import_files WHERE import_id = $1 ORDER BY idx', [imp.id])
  if (!fs.length) throw new HttpError(400, 'Envie ao menos um arquivo.', 'invalid')
  const h = createHash('sha256'); for (const f of fs) h.update(createHash('sha256').update(String(f.data || '')).digest('hex'))
  const hash = h.digest('hex')
  if (!forcar) {
    const ig = await one("SELECT * FROM menu_imports WHERE business_id = $1 AND file_hash = $2 AND id <> $3 AND status IN ('processando','revisao','concluido') ORDER BY id DESC", [imp.business_id, hash, imp.id])
    if (ig) { await upd(imp.id, { status: 'cancelado', stage: 'Arquivo já importado', file_hash: hash }); await q('UPDATE menu_import_files SET data = NULL WHERE import_id = $1', [imp.id]); return { repetida: true, importacao: outImp(ig) } }
  }
  await upd(imp.id, { status: 'processando', stage: 'Analisando seu cardápio…', progress: 2, file_hash: hash, error: null, files: JSON.stringify(fs.map((f: any) => ({ name: f.name, mime: f.mime, size: Number(f.size), done: false }))) })
  void processar(Number(imp.id))
  return { repetida: false, importacao: outImp((await one('SELECT * FROM menu_imports WHERE id = $1', [imp.id]))!) }
}
/** Lê os arquivos pendentes (retoma de onde parou) e monta o rascunho. Um arquivo que falha não perde os já lidos. */
export async function processar(id: number) {
  if (rodando.has(id)) return; rodando.add(id)
  try {
    const imp = await one('SELECT * FROM menu_imports WHERE id = $1', [id]); if (!imp || imp.status !== 'processando') return
    await upd(id, { attempts: Number(imp.attempts) + 1 })
    const files = await q('SELECT id, idx, name, mime, data FROM menu_import_files WHERE import_id = $1 ORDER BY idx', [id])
    const meta = J<any[]>(imp.files, []), acum = J<any>(imp.items, []) as any[] // itens brutos acumulados por arquivo (retomada)
    const brutos: { raw: any; arquivo: string }[] = Array.isArray(acum) ? acum : []
    let erros = 0
    for (let i = 0; i < files.length; i++) {
      const f = files[i]; if (meta[i]?.done) continue
      const cur = await one('SELECT status FROM menu_imports WHERE id = $1', [id]); if (cur?.status !== 'processando') return // cancelado
      await upd(id, { stage: `Analisando seu cardápio… (${i + 1} de ${files.length})`, progress: Math.round((i / files.length) * 80) + 3 })
      try {
        if (!f.data) throw new Error('Arquivo não está mais disponível.')
        const lido = await lerArquivo({ name: f.name, mime: f.mime, data: Buffer.from(f.data, 'base64') }, Number(imp.business_id))
        const lista = lido.itens
        await upd(id, { stage: 'Identificando produtos e preços…' })
        // várias fotos do mesmo cardápio: itens do topo de uma página sem título continuam a categoria da página anterior
        const ultimaCat = [...brutos].reverse().find((b) => b.raw?.categoria)?.raw?.categoria || ''
        for (const raw of lista) {
          if (lido.leitura === 'local' && !raw.categoria && ultimaCat) brutos.push({ raw: { ...raw, categoria: ultimaCat, avisos: ['Categoria continuada da página anterior.'] }, arquivo: f.name })
          else brutos.push({ raw, arquivo: f.name })
        }
        meta[i] = { ...meta[i], done: true, itens: lista.length, leitura: lido.leitura }; await q('UPDATE menu_import_files SET data = NULL WHERE id = $1', [f.id]) // retenção mínima
      } catch (e: any) { erros++; meta[i] = { ...meta[i], done: false, erro: String(e?.message || e).slice(0, 200) } }
      await upd(id, { files: JSON.stringify(meta), items: JSON.stringify(brutos), progress: Math.round(((i + 1) / files.length) * 80) + 3 })
    }
    if (meta.some((m) => !m.done)) { // falha: mantém o que já foi lido; "retomar" refaz só o que faltou
      await upd(id, { status: 'falhou', error: meta.find((m) => m.erro)?.erro || 'Falha na leitura.', stage: 'Leitura interrompida' }); return
    }
    await upd(id, { stage: 'Organizando categorias…', progress: 90 })
    const itens = consolidar(brutos)
    if (!itens.length) { await upd(id, { status: 'falhou', error: 'Não encontrei produtos neste documento. Tente uma foto mais nítida ou outro arquivo.', stage: 'Nada encontrado', items: '[]' }); return }
    await upd(id, { stage: 'Preparando seu catálogo…', progress: 96 })
    await upd(id, { status: 'revisao', stage: 'Pronto para revisar', progress: 100, items: JSON.stringify(itens), n_identified: itens.length, n_review: itens.filter((x) => x.revisar).length })
  } catch (e: any) {
    console.error('[cardapio] falha:', e?.message || e)
    await upd(id, { status: 'falhou', error: String(e?.message || 'Falha inesperada').slice(0, 300), stage: 'Falha no processamento' }).catch(() => {})
  } finally { rodando.delete(id) }
}
/** Tenta de novo só o que falhou (arquivos já lidos são mantidos). */
export async function retomar(imp: any) {
  if (!['falhou', 'processando'].includes(imp.status)) throw new HttpError(409, 'Esta importação não pode ser retomada.', 'conflict')
  const pend = await one('SELECT COUNT(*) AS n FROM menu_import_files WHERE import_id = $1 AND data IS NOT NULL', [imp.id])
  const meta = J<any[]>(imp.files, []); if (!Number(pend?.n) && meta.some((m) => !m.done)) throw new HttpError(410, 'Os arquivos já foram descartados. Envie novamente.', 'gone')
  await upd(imp.id, { status: 'processando', error: null, stage: 'Retomando…' }); void processar(Number(imp.id)); return outImp((await one('SELECT * FROM menu_imports WHERE id = $1', [imp.id]))!)
}
export async function cancelar(imp: any) {
  if (!['rascunho', 'processando', 'revisao', 'falhou'].includes(imp.status)) throw new HttpError(409, 'Esta importação não pode ser cancelada.', 'conflict')
  await upd(imp.id, { status: 'cancelado', stage: 'Cancelada', items: '[]' }); await q('UPDATE menu_import_files SET data = NULL WHERE import_id = $1', [imp.id])
}
/** Ao subir o servidor: continua importações interrompidas e descarta arquivos que não precisam mais ficar guardados. */
export async function retomarPendentes() {
  try {
    for (const r of await q("SELECT id FROM menu_imports WHERE status = 'processando'")) void processar(Number(r.id))
    const limite = new Date(Date.now() - 3 * 86400_000).toISOString()
    await q("UPDATE menu_import_files SET data = NULL WHERE data IS NOT NULL AND import_id IN (SELECT id FROM menu_imports WHERE status NOT IN ('rascunho','processando') OR updated_at < $1)", [limite])
  } catch (e: any) { console.error('[cardapio] retomada:', e?.message) }
}

/* ---------- publicação (só após confirmação) ---------- */
function produtoDe(it: ItemRascunho, importId: number, existente?: any) {
  const adds = it.adicionais.filter((a) => a.nome)
  const variacoes = [...it.variacoes, ...(adds.length ? [{ nome: 'Adicionais', opcoes: [{ nome: 'Sem adicional', preco: 0 }, ...adds.map((a) => ({ nome: a.nome, preco: a.preco }))].slice(0, 12) }] : [])].slice(0, 6)
  const grupoPreco = it.variacoes.find((v) => v.opcoes.every((o) => o.preco > 0))
  const base = it.preco !== null && it.preco > 0 ? it.preco : grupoPreco ? Math.min(...grupoPreco.opcoes.map((o) => o.preco)) : 0
  const desc = it.descricao || (it.descricaoOrigem === 'ia' || it.descricaoOrigem === 'manual' ? it.descricaoIA : '')
  const origemDesc = it.descricao ? (it.descricaoOrigem === 'manual' ? 'manual' : 'original') : it.descricaoIA ? (it.descricaoOrigem === 'manual' ? 'manual' : 'ia') : ''
  return {
    ...(existente || {}), nome: it.nome, preco: base, descricao: desc, categoria: it.categoria, variacoes, tipo: existente?.tipo || it.tipo, modoPreco: existente?.modoPreco || 'fixo',
    palavras: existente?.palavras ?? [it.nome, ...it.ingredientes].join(', ').toLowerCase(), fotos: existente?.fotos?.length ? existente.fotos : it.foto ? [it.foto] : [],
    origem: { fonte: 'importacao_cardapio', importId, descricaoOrigem: origemDesc, ...(it.observacoes ? { observacoes: it.observacoes } : {}) },
  }
}
/** Confere, com a regra REAL de preço do catálogo (unitPrice), que cada opção resulta no valor lido; senão o item não é publicado. */
function precosCoerentes(p: any): string | null {
  try {
    const base = unitPrice(p, {})
    let absoluto = true
    for (const v of p.variacoes || []) {
      const add = v.nome === 'Adicionais', temAbs = !add && absoluto && v.opcoes.every((x: any) => x.preco > 0)
      if (temAbs) absoluto = false
      v.opcoes.forEach((o: any, i: number) => {
        const got = unitPrice(p, { [v.nome]: i })
        if (add && Math.abs(got - (base + o.preco)) > 0.005) throw new Error(`O adicional “${o.nome}” tem valor incompatível com o produto.`)
        if (temAbs && Math.abs(got - o.preco) > 0.005) throw new Error(`O preço de “${v.nome}: ${o.nome}” não bate com o catálogo.`)
      })
    }
  } catch (e: any) { return e.message }
  return null
}
export interface Resultado { criados: any[]; atualizados: any[]; ignorados: { nome: string; motivo: string }[]; revisaoPendente: number }
export async function publicar(b: any, imp: any, userId: number, edits: any[] | null): Promise<Resultado> {
  // reivindica a importação de forma atômica: publicar duas vezes (duplo clique, duas abas) não duplica produtos
  const claim = await q("UPDATE menu_imports SET status = 'publicando', updated_at = $1 WHERE id = $2 AND status = 'revisao' RETURNING id", [nowIso(), imp.id])
  if (!claim.length) throw new HttpError(409, 'Esta importação já foi publicada ou não está pronta para publicar.', 'conflict')
  try {
    const salvos = J<ItemRascunho[]>(imp.items, [])
    const porId = new Map((edits || []).map((e) => [String(e.id), e]))
    const itens = salvos.map((s) => { const e = porId.get(s.id); return e ? sanitizarItem({ ...s, ...e, id: s.id, avisos: [] }, 0, s.arquivo)! : s }).filter(Boolean)
    // quem edita um item duvidoso e confirma assume a revisão; sem confirmação, itens duvidosos NÃO são cadastrados
    const dups = await duplicidades(Number(b.id), itens)
    const res: Resultado = { criados: [], atualizados: [], ignorados: [], revisaoPendente: 0 }
    await db().tx(async (d) => {
      for (const it of itens) {
        if (!it.selecionado) { res.ignorados.push({ nome: it.nome, motivo: 'Não selecionado' }); continue }
        if (it.preco === null && !it.variacoes.some((v) => v.opcoes.every((o) => o.preco > 0))) { res.ignorados.push({ nome: it.nome, motivo: 'Sem preço' }); res.revisaoPendente++; continue }
        if (it.revisar && !it.confirmado) { res.ignorados.push({ nome: it.nome, motivo: 'Leitura duvidosa não confirmada' }); res.revisaoPendente++; continue }
        const dup = dups[it.id], acao = it.acao || (dup ? 'manter' : 'novo')
        if (dup && acao === 'manter') { res.ignorados.push({ nome: it.nome, motivo: `Mantido o produto existente “${dup.nome}”` }); continue }
        try {
          if (dup && acao === 'atualizar') {
            const ex = (await d.query('SELECT * FROM products WHERE id = $1 AND business_id = $2', [dup.id, b.id]))[0]; if (!ex) { res.ignorados.push({ nome: it.nome, motivo: 'Produto existente não encontrado' }); continue }
            const antes = J<any>(ex.data, {}), novo = produtoDe(it, Number(imp.id), antes)
            const prob = precosCoerentes(novo); if (prob) { res.ignorados.push({ nome: it.nome, motivo: prob }); continue }
            await salvarProduto(b, { ...novo, id: dup.id }, { exigirFoto: false, origem: novo.origem, db: d })
            await d.query('INSERT INTO menu_import_products (import_id, product_id, action, prev_data, created_at) VALUES ($1,$2,$3,$4,$5)', [imp.id, dup.id, 'atualizado', JSON.stringify({ data: antes, ativo: ex.active === true || ex.active === 1 }), nowIso()])
            res.atualizados.push({ id: dup.id, nome: it.nome })
          } else {
            const novo = produtoDe(it, Number(imp.id)), prob = precosCoerentes(novo); if (prob) { res.ignorados.push({ nome: it.nome, motivo: prob }); continue }
            const pid = await salvarProduto(b, novo, { exigirFoto: false, origem: novo.origem, ativo: it.disponivel !== false, db: d })
            await d.query('INSERT INTO menu_import_products (import_id, product_id, action, created_at) VALUES ($1,$2,$3,$4)', [imp.id, pid, 'criado', nowIso()])
            res.criados.push({ id: pid, nome: it.nome })
          }
        } catch (e: any) { if (e instanceof HttpError) res.ignorados.push({ nome: it.nome, motivo: e.message }); else throw e }
      }
    })
    await upd(imp.id, { status: 'concluido', stage: 'Importação concluída', progress: 100, finished_at: nowIso(), items: JSON.stringify(itens), n_created: res.criados.length, n_updated: res.atualizados.length, n_ignored: res.ignorados.length, n_review: itens.filter((x) => x.revisar).length })
    await q('UPDATE menu_import_files SET data = NULL WHERE import_id = $1', [imp.id])
    return res
  } catch (e) { await q("UPDATE menu_imports SET status = 'revisao', updated_at = $1 WHERE id = $2 AND status = 'publicando'", [nowIso(), imp.id]); throw e }
}
/** Desfaz uma importação: remove o que ela criou e restaura o que ela atualizou. Não toca em nada que não seja dela. */
export async function reverter(b: any, imp: any) {
  if (imp.status !== 'concluido') throw new HttpError(409, 'Só é possível reverter importações concluídas.', 'conflict')
  let removidos = 0, restaurados = 0
  await db().tx(async (d) => {
    for (const r of await d.query('SELECT * FROM menu_import_products WHERE import_id = $1 ORDER BY id DESC', [imp.id])) {
      if (r.action === 'criado') { await d.query('DELETE FROM products WHERE id = $1 AND business_id = $2', [r.product_id, b.id]); removidos++ }
      else { const prev = J<any>(r.prev_data, null); if (prev) { await d.query('UPDATE products SET data = $1, active = $2, updated_at = $3 WHERE id = $4 AND business_id = $5', [JSON.stringify(prev.data), prev.ativo, nowIso(), r.product_id, b.id]); restaurados++ } }
    }
    await d.query("UPDATE menu_imports SET status = 'revertido', stage = 'Importação revertida', updated_at = $1 WHERE id = $2", [nowIso(), imp.id])
  })
  return { removidos, restaurados }
}
