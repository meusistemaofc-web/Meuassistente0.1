// CRM de "Sua empresa". Serviços (cada um com uma responsabilidade) sobre as estruturas que JÁ existem:
//  • clientes = users + orders (pedidos e agendamentos, inclusive de convidados): o CRM só guarda o RELACIONAMENTO e se liga a eles
//    (crm_contacts.user_id, crm_order_links). Pedidos e agendamentos NUNCA são copiados: a linha do tempo os consulta no original;
//  • isolamento: toda função recebe o `bid` já validado como empresa do usuário (ver `acesso`) e filtra por business_id;
//  • auditoria: ações importantes vão para audit_log (com o canal: painel ou chat).
// Serviços: CustomerRelationshipService (contatos/histórico), LeadManagementService (leads), SalesPipelineService (funil),
// OpportunityService, CRMTaskService, CommercialIntelligenceService e CRMService (visão geral/configuração).
import { q, one, J, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'
import { audit } from './account.js'
import { notify } from './notify.js'
import { localDate, localTime, validTz, addDays } from './time.js'

export type Ator = { id: number; nome: string; via: 'painel' | 'chat' | 'sistema' }
const txt = (v: any, n: number) => String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, n)
const num = (v: any) => Number(v) || 0
const r2 = (n: number) => Math.round(n * 100) / 100
const ph = (n: number, from = 1) => Array.from({ length: n }, (_, i) => '$' + (i + from)).join(',')
const DATA = /^\d{4}-\d{2}-\d{2}$/
const PRAZO = /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?$/
const VALIDO = ['recusado', 'cancelado', 'aguardando_pagamento'] // pedidos que ainda não contam como compra
const DIAS = 86400_000

/* ---------- acesso e configuração ---------- */
/** Empresa do usuário (dono). Fora disso nada do CRM é acessível: isolamento entre empresas. */
export async function acesso(userId: number, bid: number) {
  const b = await one("SELECT id, owner_id, plan_id, status, data FROM businesses WHERE id = $1 AND owner_id = $2 AND status <> 'institucional'", [bid, userId])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  const { modules } = await import('./usermod.js'); if ((await modules()).crm === false) fail(403, 'O CRM está desligado pelo administrador.', 'module_disabled')
  const { plans } = await import('../routes/ads.js'); const nv = Number((await plans()).find((p: any) => p.id === b!.plan_id)?.nivel || 1)
  if (nv < 4) fail(403, 'O CRM faz parte dos planos com loja e pedidos.', 'plan_required')
  return b!
}
export type Cfg = { iaCriarLeads: boolean; iaMoverEtapas: boolean; diasParado: number; diasSemAcompanhamento: number; diasRetorno: number }
const CFG0: Cfg = { iaCriarLeads: true, iaMoverEtapas: true, diasParado: 14, diasSemAcompanhamento: 7, diasRetorno: 30 }
export async function config(bid: number): Promise<Cfg> { const r = await one('SELECT data FROM crm_settings WHERE business_id = $1', [bid]); return { ...CFG0, ...J<any>(r?.data, {}) } }
export async function salvarConfig(bid: number, b: any, a: Ator) {
  const cur = await config(bid), n = (v: any, d: number, lo: number, hi: number) => v === undefined ? d : Math.min(hi, Math.max(lo, Math.round(Number(v)) || d))
  const next: Cfg = { iaCriarLeads: b.iaCriarLeads === undefined ? cur.iaCriarLeads : b.iaCriarLeads === true, iaMoverEtapas: b.iaMoverEtapas === undefined ? cur.iaMoverEtapas : b.iaMoverEtapas === true, diasParado: n(b.diasParado, cur.diasParado, 3, 180), diasSemAcompanhamento: n(b.diasSemAcompanhamento, cur.diasSemAcompanhamento, 1, 90), diasRetorno: n(b.diasRetorno, cur.diasRetorno, 7, 365) }
  await q('INSERT INTO crm_settings (business_id, data, updated_at) VALUES ($1,$2,$3) ON CONFLICT (business_id) DO UPDATE SET data = $2, updated_at = $3', [bid, JSON.stringify(next), nowIso()])
  await log(a, bid, 'crm.config', bid, next); return next
}
async function log(a: Ator, bid: number, action: string, target: number | null, details: object = {}) { await audit(a.id || null, action, target, { empresa: bid, via: a.via, ...details }).catch(() => {}) }
async function evento(bid: number, e: { contato?: number | null; opp?: number | null; tarefa?: number | null; tipo: string; canal?: string; texto: string; dados?: any }, a: Ator) {
  await q('INSERT INTO crm_events (business_id, contact_id, opp_id, task_id, kind, channel, actor, text, data, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
    [bid, e.contato ?? null, e.opp ?? null, e.tarefa ?? null, e.tipo, e.canal || null, a.via === 'chat' ? `${a.nome} (via chat)` : a.via === 'sistema' ? 'Sistema' : a.nome, txt(e.texto, 600), e.dados ? JSON.stringify(e.dados) : null, nowIso()])
}
const tzDe = async (bid: number) => { const r = await one('SELECT u.settings FROM businesses b JOIN users u ON u.id = b.owner_id WHERE b.id = $1', [bid]); return validTz(J<any>(r?.settings, {}).timezone) }
export const hoje = async (bid: number) => localDate(await tzDe(bid))

/* ---------- identidade: telefone/e-mail normalizados para evitar duplicidade ---------- */
export function phoneKey(p: any): string {
  let d = String(p ?? '').replace(/\D/g, ''); if (d.startsWith('55') && d.length >= 12) d = d.slice(2)
  if (d.length === 11 && d[2] === '9') d = d.slice(0, 2) + d.slice(3) // com ou sem o 9º dígito é a mesma linha
  return d.length === 10 ? d : ''
}
export const emailKey = (e: any) => { const s = String(e ?? '').trim().toLowerCase(); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) ? s : '' }

/* ===================== CustomerRelationshipService ===================== */
const cOut = (r: any) => ({ id: Number(r.id), usuarioId: r.user_id == null ? null : Number(r.user_id), nome: r.name, telefone: r.phone || '', email: r.email || '', empresa: r.company || '', tipo: r.kind as 'lead' | 'cliente', origem: r.source || '', categoria: r.category || '', etiquetas: J<string[]>(r.tags, []), observacoes: r.notes || '', responsavel: r.owner_name || '', arquivado: num(r.archived) === 1, criadoEm: isoOf(r.created_at), atualizadoEm: isoOf(r.updated_at) })
export type ContatoIn = { nome?: string; telefone?: string; email?: string; empresa?: string; origem?: string; categoria?: string; etiquetas?: string[]; observacoes?: string; responsavel?: string; tipo?: string; usuarioId?: number | null }
const tags = (v: any) => Array.isArray(v) ? [...new Set(v.map((t) => txt(t, 30)).filter(Boolean))].slice(0, 12) : []

export const CustomerRelationshipService = {
  /** Procura o MESMO contato: pelo usuário do app, depois e-mail e telefone (variações incluídas). */
  async achar(bid: number, k: { usuarioId?: number | null; telefone?: any; email?: any }, ignorar?: number) {
    const cond: { sql: string; v: any }[] = []
    if (k.usuarioId) cond.push({ sql: 'user_id = $2', v: k.usuarioId })
    const ek = emailKey(k.email); if (ek) cond.push({ sql: 'email_key = $2', v: ek })
    const pk = phoneKey(k.telefone); if (pk) cond.push({ sql: 'phone_key = $2', v: pk })
    for (const c of cond) { const r = await one(`SELECT * FROM crm_contacts WHERE business_id = $1 AND ${c.sql} AND archived = 0 ORDER BY id LIMIT 1`, [bid, c.v]); if (r && Number(r.id) !== ignorar) return r }
    return null
  },
  async obter(bid: number, id: number) { const r = await one('SELECT * FROM crm_contacts WHERE id = $1 AND business_id = $2', [id, bid]); if (!r) fail(404, 'Contato não encontrado.', 'not_found'); return r! },
  /** Cria o contato OU reaproveita o existente (completando só o que faltava). Nunca cria duplicado. */
  async salvar(bid: number, b: ContatoIn, a: Ator, via = 'manual') {
    const nome = txt(b.nome, 120); const tel = txt(b.telefone, 30), em = txt(b.email, 120)
    if (nome.length < 2) fail(400, 'Informe o nome do contato.', 'invalid', 'nome')
    if (em && !emailKey(em)) fail(400, 'E-mail inválido.', 'invalid', 'email')
    if (tel && !phoneKey(tel)) fail(400, 'Telefone inválido: informe com DDD.', 'invalid', 'telefone')
    const ex = await this.achar(bid, { usuarioId: b.usuarioId, telefone: tel, email: em })
    if (ex) {
      const patch: any = {}
      if (!ex.phone && tel) patch.telefone = tel; if (!ex.email && em) patch.email = em; if (!ex.company && b.empresa) patch.empresa = b.empresa; if (!ex.user_id && b.usuarioId) patch.usuarioId = b.usuarioId
      if (!ex.notes && b.observacoes) patch.observacoes = b.observacoes
      if (Object.keys(patch).length) await this.editar(bid, Number(ex.id), patch, { ...a, via: a.via }, true)
      await evento(bid, { contato: Number(ex.id), tipo: 'cadastro', texto: `Contato já cadastrado: registro reaproveitado${Object.keys(patch).length ? ' e completado' : ''} (${via}).` }, a)
      return { contato: cOut(await this.obter(bid, Number(ex.id))), reutilizado: true }
    }
    const kind = b.tipo === 'cliente' ? 'cliente' : 'lead', now = nowIso()
    const r = await q('INSERT INTO crm_contacts (business_id, user_id, name, phone, phone_key, email, email_key, company, kind, source, category, tags, notes, owner_name, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$16) RETURNING id',
      [bid, b.usuarioId || null, nome, tel || null, phoneKey(tel) || null, em || null, emailKey(em) || null, txt(b.empresa, 120) || null, kind, txt(b.origem, 40) || via, txt(b.categoria, 40) || null, JSON.stringify(tags(b.etiquetas)), txt(b.observacoes, 2000) || null, txt(b.responsavel, 60) || null, a.id || null, now])
    const id = Number(r[0].id)
    await evento(bid, { contato: id, tipo: 'cadastro', texto: `${kind === 'lead' ? 'Lead' : 'Cliente'} cadastrado (${txt(b.origem, 40) || via}).` }, a)
    await log(a, bid, 'crm.contato.criar', id, { tipo: kind })
    return { contato: cOut(await this.obter(bid, id)), reutilizado: false }
  },
  async editar(bid: number, id: number, p: ContatoIn, a: Ator, silencioso = false) {
    const cur = await this.obter(bid, id), sets: string[] = [], vals: any[] = [], mud: string[] = []
    const set = (col: string, v: any, rot: string, antes: any) => { sets.push(`${col} = $${vals.length + 1}`); vals.push(v); if (String(antes ?? '') !== String(v ?? '')) mud.push(rot) }
    if (p.nome !== undefined) { const n = txt(p.nome, 120); if (n.length < 2) fail(400, 'Informe o nome do contato.', 'invalid', 'nome'); set('name', n, 'nome', cur.name) }
    if (p.telefone !== undefined) { const t = txt(p.telefone, 30); if (t && !phoneKey(t)) fail(400, 'Telefone inválido: informe com DDD.', 'invalid', 'telefone'); if (t && await this.achar(bid, { telefone: t }, id)) fail(409, 'Já existe outro contato com este telefone.', 'duplicate', 'telefone'); set('phone', t || null, 'telefone', cur.phone); set('phone_key', phoneKey(t) || null, 'x', phoneKey(t) || null) }
    if (p.email !== undefined) { const e = txt(p.email, 120); if (e && !emailKey(e)) fail(400, 'E-mail inválido.', 'invalid', 'email'); if (e && await this.achar(bid, { email: e }, id)) fail(409, 'Já existe outro contato com este e-mail.', 'duplicate', 'email'); set('email', e || null, 'e-mail', cur.email); set('email_key', emailKey(e) || null, 'x', emailKey(e) || null) }
    if (p.usuarioId !== undefined && p.usuarioId && !cur.user_id) set('user_id', p.usuarioId, 'vínculo com usuário', null)
    if (p.empresa !== undefined) set('company', txt(p.empresa, 120) || null, 'empresa', cur.company)
    if (p.origem !== undefined) set('source', txt(p.origem, 40) || null, 'origem', cur.source)
    if (p.categoria !== undefined) set('category', txt(p.categoria, 40) || null, 'categoria', cur.category)
    if (p.etiquetas !== undefined) set('tags', JSON.stringify(tags(p.etiquetas)), 'etiquetas', cur.tags)
    if (p.observacoes !== undefined) set('notes', txt(p.observacoes, 2000) || null, 'observações', cur.notes)
    if (p.responsavel !== undefined) set('owner_name', txt(p.responsavel, 60) || null, 'responsável', cur.owner_name)
    if (p.tipo !== undefined && ['lead', 'cliente'].includes(p.tipo)) set('kind', p.tipo, 'tipo', cur.kind)
    if (!sets.length) return cOut(cur)
    sets.push(`updated_at = $${vals.length + 1}`); vals.push(nowIso())
    await q(`UPDATE crm_contacts SET ${sets.join(', ')} WHERE id = $${vals.length + 1} AND business_id = $${vals.length + 2}`, [...vals, id, bid])
    if (mud.length && !silencioso) { await evento(bid, { contato: id, tipo: 'cadastro', texto: `Cadastro alterado: ${mud.filter((m) => m !== 'x').join(', ')}.` }, a); await log(a, bid, 'crm.contato.editar', id, { campos: mud.filter((m) => m !== 'x') }) }
    return cOut(await this.obter(bid, id))
  },
  async arquivar(bid: number, id: number, arq: boolean, a: Ator) {
    await this.obter(bid, id); await q('UPDATE crm_contacts SET archived = $1, updated_at = $2 WHERE id = $3 AND business_id = $4', [arq ? 1 : 0, nowIso(), id, bid])
    await evento(bid, { contato: id, tipo: 'cadastro', texto: arq ? 'Contato arquivado.' : 'Contato reativado.' }, a); await log(a, bid, arq ? 'crm.contato.arquivar' : 'crm.contato.reativar', id)
  },
  /** Compras/agendamentos ligados a cada contato (consulta, sem copiar): total, última compra, recorrência. */
  async resumoCompras(bid: number) {
    const rows = await q('SELECT l.contact_id, o.id, o.status, o.total, o.created_at, o.data FROM crm_order_links l JOIN orders o ON o.id = l.order_id WHERE l.business_id = $1', [bid]) as any[]
    const m = new Map<number, { pedidos: number; agendamentos: number; total: number; ultima: string; primeira: string }>()
    for (const r of rows) {
      if (VALIDO.includes(r.status)) continue
      const c = Number(r.contact_id), x = m.get(c) || { pedidos: 0, agendamentos: 0, total: 0, ultima: '', primeira: '' }, t = isoOf(r.created_at)
      if (J<any>(r.data, {}).tipo === 'agendamento') x.agendamentos++; else x.pedidos++
      x.total = r2(x.total + num(r.total)); if (!x.ultima || t > x.ultima) x.ultima = t; if (!x.primeira || t < x.primeira) x.primeira = t; m.set(c, x)
    }
    return m
  },
  async listar(bid: number, f: { busca?: string; tipo?: string; categoria?: string; etiqueta?: string; origem?: string; responsavel?: string; arquivados?: boolean; recorrentes?: boolean } = {}) {
    await LeadManagementService.sincronizar(bid)
    const rows = await q('SELECT * FROM crm_contacts WHERE business_id = $1 AND archived = $2 ORDER BY updated_at DESC, id DESC LIMIT 1000', [bid, f.arquivados ? 1 : 0]) as any[]
    const compras = await this.resumoCompras(bid), opps = await q("SELECT contact_id, COUNT(*) AS n, COALESCE(SUM(value),0) AS v FROM crm_opps WHERE business_id = $1 AND status = 'aberta' GROUP BY contact_id", [bid]) as any[]
    const op = new Map(opps.map((o) => [Number(o.contact_id), { n: Number(o.n), v: num(o.v) }]))
    const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''), bq = norm(txt(f.busca, 80)), bd = bq.replace(/\D/g, '')
    let out = rows.map((r) => { const c = cOut(r), x = compras.get(c.id); return { ...c, compras: x ? { pedidos: x.pedidos, agendamentos: x.agendamentos, total: x.total, ultima: x.ultima } : { pedidos: 0, agendamentos: 0, total: 0, ultima: '' }, recorrente: !!x && x.pedidos + x.agendamentos >= 2, oportunidadesAbertas: op.get(c.id)?.n || 0, valorEmAberto: op.get(c.id)?.v || 0 } })
    if (bq) out = out.filter((c) => norm(`${c.nome} ${c.empresa} ${c.email}`).includes(bq) || (bd.length >= 4 && (c.telefone.replace(/\D/g, '').includes(bd))))
    if (f.tipo === 'lead' || f.tipo === 'cliente') out = out.filter((c) => c.tipo === f.tipo)
    if (f.categoria) out = out.filter((c) => c.categoria === f.categoria)
    if (f.etiqueta) out = out.filter((c) => c.etiquetas.includes(f.etiqueta!))
    if (f.origem) out = out.filter((c) => c.origem === f.origem)
    if (f.responsavel) out = out.filter((c) => c.responsavel === f.responsavel)
    if (f.recorrentes) out = out.filter((c) => c.recorrente)
    return out
  },
  /** Pedidos e agendamentos reais ligados ao contato. */
  async pedidos(bid: number, contactId: number) {
    const rows = await q('SELECT o.* FROM crm_order_links l JOIN orders o ON o.id = l.order_id WHERE l.business_id = $1 AND l.contact_id = $2 ORDER BY o.id DESC LIMIT 200', [bid, contactId]) as any[]
    return rows.map((o) => { const d = J<any>(o.data, {}), ag = d.tipo === 'agendamento'; return { id: Number(o.id), tipo: ag ? 'agendamento' : 'pedido', status: o.status, total: r2(num(o.total)), pago: d.pago === true, resumo: ag ? `${d.servico || 'Serviço'} · ${d.data || ''} ${d.hora || ''}`.trim() : `${(d.itens || []).reduce((s: number, i: any) => s + (Number(i.qtd) || 1), 0)} item(ns)${d.modo ? ' · ' + d.modo : ''}`, em: isoOf(o.created_at), atualizadoEm: isoOf(o.updated_at) } })
  },
  /** Linha do tempo: eventos do CRM + pedidos/agendamentos/pagamentos consultados nos registros originais. */
  async linhaDoTempo(bid: number, contactId: number) {
    await this.obter(bid, contactId)
    const ev = (await q('SELECT * FROM crm_events WHERE business_id = $1 AND contact_id = $2 ORDER BY id DESC LIMIT 300', [bid, contactId]) as any[]).map((e) => ({ tipo: e.kind as string, canal: e.channel || '', quem: e.actor || '', texto: e.text || '', oportunidadeId: e.opp_id == null ? null : Number(e.opp_id), tarefaId: e.task_id == null ? null : Number(e.task_id), em: isoOf(e.created_at), origem: 'crm' as string, ref: null as number | null }))
    const ped = await this.pedidos(bid, contactId)
    const itens = [...ev]
    for (const p of ped) {
      itens.push({ tipo: p.tipo, canal: '', quem: '', texto: `${p.tipo === 'agendamento' ? 'Agendamento' : 'Pedido'} #${p.id} · ${p.resumo} · R$ ${p.total.toFixed(2).replace('.', ',')} · ${p.status}`, oportunidadeId: null, tarefaId: null, em: p.em, origem: 'pedidos', ref: p.id })
      if (p.pago) itens.push({ tipo: 'pagamento', canal: '', quem: '', texto: `Pagamento confirmado · ${p.tipo} #${p.id} · R$ ${p.total.toFixed(2).replace('.', ',')}`, oportunidadeId: null, tarefaId: null, em: p.atualizadoEm, origem: 'pedidos', ref: p.id })
    }
    return itens.sort((x, y) => y.em.localeCompare(x.em))
  },
  async perfil(bid: number, id: number) {
    await LeadManagementService.sincronizar(bid)
    const c = cOut(await this.obter(bid, id)), compras = (await this.resumoCompras(bid)).get(id)
    return { contato: c, compras: compras ? { ...compras, recorrente: compras.pedidos + compras.agendamentos >= 2 } : { pedidos: 0, agendamentos: 0, total: 0, ultima: '', primeira: '', recorrente: false },
      pedidos: await this.pedidos(bid, id), oportunidades: await OpportunityService.listar(bid, { contatoId: id }), tarefas: await CRMTaskService.listar(bid, { contatoId: id }), linhaDoTempo: await this.linhaDoTempo(bid, id) }
  },
  /** Observação ou interação registrada (ligação, WhatsApp, reunião…). */
  async registrar(bid: number, id: number, b: { tipo?: string; canal?: string; texto?: string }, a: Ator) {
    await this.obter(bid, id); const t = txt(b.texto, 600); if (t.length < 2) fail(400, 'Escreva o texto do registro.', 'invalid', 'texto')
    const tipo = b.tipo === 'interacao' ? 'interacao' : 'observacao', canal = ['ligacao', 'whatsapp', 'email', 'reuniao', 'chat', 'presencial', 'outro'].includes(String(b.canal)) ? String(b.canal) : ''
    await evento(bid, { contato: id, tipo, canal, texto: t }, a); await q('UPDATE crm_contacts SET updated_at = $1 WHERE id = $2', [nowIso(), id]); await log(a, bid, 'crm.contato.' + tipo, id)
  },
}

/* ===================== LeadManagementService ===================== */
export const LeadManagementService = {
  /** Liga pedidos/agendamentos existentes aos contatos: reaproveita o cadastro (usuário/telefone/e-mail) ou cria o cliente. Idempotente. */
  async vincularPedido(orderId: number): Promise<number | null> {
    const o = await one('SELECT * FROM orders WHERE id = $1', [orderId]); if (!o) return null
    const bid = Number(o.business_id); if (await one('SELECT 1 AS x FROM crm_order_links WHERE order_id = $1', [orderId])) return null
    const b = await one('SELECT owner_id, plan_id FROM businesses WHERE id = $1', [bid]); if (!b) return null
    const d = J<any>(o.data, {}), ag = d.tipo === 'agendamento', guest = d.guest === true
    if (!guest && Number(o.customer_id) === Number(b.owner_id)) { await q('INSERT INTO crm_order_links (order_id, business_id, contact_id, created_at) VALUES ($1,$2,0,$3) ON CONFLICT (order_id) DO NOTHING', [orderId, bid, nowIso()]); return null } // o dono comprando na própria loja não é cliente (contato 0 = ignorado)
    let nome = txt(d.cliente, 120), tel = txt(d.telefone, 30), email = '', uid: number | null = null
    if (!guest) { const u = await one('SELECT id, name, email, whatsapp FROM users WHERE id = $1', [o.customer_id]); if (u) { uid = Number(u.id); nome = nome || u.name; email = u.email; tel = tel || u.whatsapp || '' } }
    if (!nome) nome = 'Cliente'
    const sis: Ator = { id: Number(b.owner_id), nome: 'Sistema', via: 'sistema' }
    let ex = await CustomerRelationshipService.achar(bid, { usuarioId: uid, telefone: tel, email }), cid: number
    if (ex) { cid = Number(ex.id); const p: any = {}; if (!ex.user_id && uid) p.usuarioId = uid; if (!ex.phone && phoneKey(tel)) p.telefone = tel; if (!ex.email && emailKey(email)) p.email = email; if (Object.keys(p).length) await CustomerRelationshipService.editar(bid, cid, p, sis, true) }
    else { const r = await CustomerRelationshipService.salvar(bid, { nome, telefone: phoneKey(tel) ? tel : '', email: emailKey(email) ? email : '', usuarioId: uid, origem: ag ? 'agendamento' : 'pedido', tipo: 'cliente' }, sis, ag ? 'agendamento' : 'pedido'); cid = r.contato.id }
    await q('INSERT INTO crm_order_links (order_id, business_id, contact_id, created_at) VALUES ($1,$2,$3,$4) ON CONFLICT (order_id) DO NOTHING', [orderId, bid, cid, nowIso()])
    if (!VALIDO.includes(o.status)) await q("UPDATE crm_contacts SET kind = 'cliente', updated_at = $1 WHERE id = $2 AND kind <> 'cliente'", [nowIso(), cid])
    await evento(bid, { contato: cid, tipo: 'vinculo', texto: `${ag ? 'Agendamento' : 'Pedido'} #${orderId} vinculado ao contato.` }, sis)
    return cid
  },
  /** Varre os pedidos/agendamentos ainda não ligados (poucos por chamada) e promove a "cliente" quem já comprou. */
  async sincronizar(bid: number) {
    let cursor = 0
    for (let i = 0; i < 30; i++) {
      const rows = await q('SELECT id FROM orders WHERE business_id = $1 AND id > $2 AND id NOT IN (SELECT order_id FROM crm_order_links WHERE business_id = $1) ORDER BY id LIMIT 100', [bid, cursor]) as any[]
      if (!rows.length) break
      for (const r of rows) { cursor = Number(r.id); try { await this.vincularPedido(cursor) } catch (e: any) { console.error('[crm] vínculo do pedido', cursor, e?.message) } }
    }
  },
}

/* ===================== SalesPipelineService ===================== */
export const ETAPAS_PADRAO: { nome: string; cor: string; tipo: 'aberta' | 'ganha' | 'perdida'; prob: number; neg: number }[] = [
  { nome: 'Novo lead', cor: '#64748B', tipo: 'aberta', prob: 10, neg: 0 }, { nome: 'Primeiro contato', cor: '#0EA5E9', tipo: 'aberta', prob: 20, neg: 0 },
  { nome: 'Em atendimento', cor: '#6366F1', tipo: 'aberta', prob: 35, neg: 0 }, { nome: 'Em negociação', cor: '#F59E0B', tipo: 'aberta', prob: 50, neg: 1 },
  { nome: 'Proposta enviada', cor: '#F97316', tipo: 'aberta', prob: 65, neg: 1 }, { nome: 'Aguardando decisão', cor: '#A855F7', tipo: 'aberta', prob: 75, neg: 1 },
  { nome: 'Venda concluída', cor: '#22C55E', tipo: 'ganha', prob: 100, neg: 0 }, { nome: 'Negociação perdida', cor: '#EF4444', tipo: 'perdida', prob: 0, neg: 0 }]
const sOut = (r: any) => ({ id: Number(r.id), nome: r.name, cor: r.color, posicao: Number(r.position), tipo: r.kind as 'aberta' | 'ganha' | 'perdida', probabilidade: Number(r.probability), emNegociacao: num(r.negotiating) === 1 })
const COR = /^#[0-9a-fA-F]{6}$/
export const SalesPipelineService = {
  async garantir(bid: number) {
    if ((await one('SELECT COUNT(*) AS n FROM crm_stages WHERE business_id = $1', [bid]))!.n > 0) return
    await withLockSafe(`crm:stages:${bid}`, async () => {
      if (num((await one('SELECT COUNT(*) AS n FROM crm_stages WHERE business_id = $1', [bid]))!.n) > 0) return
      for (const [i, e] of ETAPAS_PADRAO.entries()) await q('INSERT INTO crm_stages (business_id, name, color, position, kind, probability, negotiating, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [bid, e.nome, e.cor, i, e.tipo, e.prob, e.neg, nowIso()])
    })
  },
  async etapas(bid: number) { await this.garantir(bid); return (await q('SELECT * FROM crm_stages WHERE business_id = $1 ORDER BY position, id', [bid]) as any[]).map(sOut) },
  async obter(bid: number, id: number) { const r = await one('SELECT * FROM crm_stages WHERE id = $1 AND business_id = $2', [id, bid]); if (!r) fail(404, 'Etapa não encontrada.', 'not_found'); return sOut(r!) },
  async criar(bid: number, b: any, a: Ator) {
    await this.garantir(bid); const nome = txt(b.nome, 40); if (nome.length < 2) fail(400, 'Informe o nome da etapa.', 'invalid', 'nome')
    if (await one('SELECT 1 AS x FROM crm_stages WHERE business_id = $1 AND LOWER(name) = $2', [bid, nome.toLowerCase()])) fail(409, 'Já existe uma etapa com este nome.', 'duplicate', 'nome')
    const cor = COR.test(String(b.cor)) ? String(b.cor) : '#3B5BDB', tipo = ['ganha', 'perdida'].includes(b.tipo) ? b.tipo : 'aberta', prob = Math.min(100, Math.max(0, Math.round(Number(b.probabilidade)) || (tipo === 'ganha' ? 100 : 0)))
    // nova etapa aberta entra antes das etapas finais (ganha/perdida)
    const fin = await one("SELECT MIN(position) AS p FROM crm_stages WHERE business_id = $1 AND kind <> 'aberta'", [bid]), pos = tipo === 'aberta' && fin?.p != null ? Number(fin.p) : num((await one('SELECT COALESCE(MAX(position),-1)+1 AS p FROM crm_stages WHERE business_id = $1', [bid]))!.p)
    if (tipo === 'aberta') await q("UPDATE crm_stages SET position = position + 1 WHERE business_id = $1 AND position >= $2", [bid, pos])
    const r = await q('INSERT INTO crm_stages (business_id, name, color, position, kind, probability, negotiating, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id', [bid, nome, cor, pos, tipo, prob, b.emNegociacao === true ? 1 : 0, nowIso()])
    await log(a, bid, 'crm.etapa.criar', Number(r[0].id), { nome }); return this.obter(bid, Number(r[0].id))
  },
  async editar(bid: number, id: number, b: any, a: Ator) {
    const cur = await this.obter(bid, id), sets: string[] = [], vals: any[] = []
    const set = (c: string, v: any) => { sets.push(`${c} = $${vals.length + 1}`); vals.push(v) }
    if (b.nome !== undefined) { const n = txt(b.nome, 40); if (n.length < 2) fail(400, 'Informe o nome da etapa.', 'invalid', 'nome'); if (await one('SELECT 1 AS x FROM crm_stages WHERE business_id = $1 AND LOWER(name) = $2 AND id <> $3', [bid, n.toLowerCase(), id])) fail(409, 'Já existe uma etapa com este nome.', 'duplicate', 'nome'); set('name', n) }
    if (b.cor !== undefined) { if (!COR.test(String(b.cor))) fail(400, 'Cor inválida (use #RRGGBB).', 'invalid', 'cor'); set('color', String(b.cor)) }
    if (b.probabilidade !== undefined && cur.tipo === 'aberta') set('probability', Math.min(100, Math.max(0, Math.round(Number(b.probabilidade)) || 0)))
    if (b.emNegociacao !== undefined && cur.tipo === 'aberta') set('negotiating', b.emNegociacao === true ? 1 : 0)
    if (!sets.length) return cur
    await q(`UPDATE crm_stages SET ${sets.join(', ')} WHERE id = $${vals.length + 1} AND business_id = $${vals.length + 2}`, [...vals, id, bid]); await log(a, bid, 'crm.etapa.editar', id, { de: cur.nome }); return this.obter(bid, id)
  },
  async reordenar(bid: number, ids: number[], a: Ator) {
    const todas = await this.etapas(bid), set = new Set(todas.map((e) => e.id)); if (ids.length !== todas.length || ids.some((i) => !set.has(i)) || new Set(ids).size !== ids.length) fail(400, 'A ordem deve conter todas as etapas, sem repetir.', 'invalid')
    for (const [i, id] of ids.entries()) await q('UPDATE crm_stages SET position = $1 WHERE id = $2 AND business_id = $3', [i, id, bid]); await log(a, bid, 'crm.etapa.ordem', null, { ids }); return this.etapas(bid)
  },
  async remover(bid: number, id: number, moverPara: number | null, a: Ator) {
    const e = await this.obter(bid, id), todas = await this.etapas(bid)
    if (e.tipo !== 'aberta' && todas.filter((x) => x.tipo === e.tipo).length <= 1) fail(409, `É preciso manter ao menos uma etapa de ${e.tipo === 'ganha' ? 'venda concluída' : 'negociação perdida'}.`, 'invalid')
    const n = num((await one('SELECT COUNT(*) AS n FROM crm_opps WHERE stage_id = $1 AND business_id = $2', [id, bid]))!.n)
    if (n > 0) { if (!moverPara) fail(409, `Há ${n} oportunidade(s) nesta etapa. Escolha para qual etapa movê-las.`, 'invalid'); const dest = await this.obter(bid, moverPara); if (dest.id === id || dest.tipo !== e.tipo) fail(400, 'Mova para outra etapa do mesmo tipo.', 'invalid'); await q('UPDATE crm_opps SET stage_id = $1, updated_at = $2 WHERE stage_id = $3 AND business_id = $4', [dest.id, nowIso(), id, bid]) }
    await q('DELETE FROM crm_stages WHERE id = $1 AND business_id = $2', [id, bid]); await log(a, bid, 'crm.etapa.remover', id, { nome: e.nome, movidas: n })
  },
  /** Funil visual: etapas com suas oportunidades e totais. */
  async funil(bid: number) {
    const etapas = await this.etapas(bid), opps = await OpportunityService.listar(bid, {})
    return etapas.map((e) => { const l = opps.filter((o) => o.etapaId === e.id); return { ...e, total: l.length, valor: r2(l.reduce((s, o) => s + o.valor, 0)), oportunidades: l } })
  },
}
async function withLockSafe(k: string, f: () => Promise<void>) { const { withLock } = await import('./business-sync.js'); return withLock(k, f) }

/* ===================== OpportunityService ===================== */
const oOut = (r: any, st?: Map<number, any>, ct?: Map<number, any>) => ({ id: Number(r.id), titulo: r.title, contatoId: Number(r.contact_id), cliente: ct?.get(Number(r.contact_id))?.name || '', valor: r2(num(r.value)), etapaId: Number(r.stage_id), etapa: st?.get(Number(r.stage_id))?.nome || '', cor: st?.get(Number(r.stage_id))?.cor || '', situacao: r.status as 'aberta' | 'ganha' | 'perdida', probabilidade: Number(r.probability), previsaoFechamento: r.expected_close || '', responsavel: r.owner_name || '', observacoes: r.notes || '', motivoPerda: r.lost_reason || '', fechadaEm: r.closed_at ? isoOf(r.closed_at) : '', criadaEm: isoOf(r.created_at), atualizadaEm: isoOf(r.updated_at) })
const pct = (v: any, d: number) => v === undefined || v === null || v === '' ? d : Math.min(100, Math.max(0, Math.round(Number(v)) ))
export const OpportunityService = {
  async listar(bid: number, f: { contatoId?: number; situacao?: string; etapaId?: number; busca?: string } = {}) {
    const rows = await q('SELECT * FROM crm_opps WHERE business_id = $1 ORDER BY updated_at DESC, id DESC LIMIT 1000', [bid]) as any[]
    const st = new Map((await SalesPipelineService.etapas(bid)).map((e) => [e.id, e])), ct = new Map((await q('SELECT id, name FROM crm_contacts WHERE business_id = $1', [bid]) as any[]).map((c) => [Number(c.id), c]))
    let out = rows.map((r) => oOut(r, st, ct))
    if (f.contatoId) out = out.filter((o) => o.contatoId === f.contatoId); if (f.situacao) out = out.filter((o) => o.situacao === f.situacao); if (f.etapaId) out = out.filter((o) => o.etapaId === f.etapaId)
    if (f.busca) { const s = f.busca.toLowerCase(); out = out.filter((o) => `${o.titulo} ${o.cliente}`.toLowerCase().includes(s)) }
    return out
  },
  async obter(bid: number, id: number) {
    const r = await one('SELECT * FROM crm_opps WHERE id = $1 AND business_id = $2', [id, bid]); if (!r) fail(404, 'Oportunidade não encontrada.', 'not_found')
    const st = new Map((await SalesPipelineService.etapas(bid)).map((e) => [e.id, e])), ct = new Map([[Number(r!.contact_id), await one('SELECT id, name FROM crm_contacts WHERE id = $1', [r!.contact_id])]])
    const hist = (await q('SELECT * FROM crm_events WHERE business_id = $1 AND opp_id = $2 ORDER BY id DESC LIMIT 200', [bid, id]) as any[]).map((e) => ({ tipo: e.kind, quem: e.actor || '', texto: e.text || '', em: isoOf(e.created_at) }))
    return { ...oOut(r, st, ct), historico: hist }
  },
  async criar(bid: number, b: any, a: Ator) {
    const c = await CustomerRelationshipService.obter(bid, Number(b.contatoId)); const titulo = txt(b.titulo, 140); if (titulo.length < 2) fail(400, 'Informe o título da oportunidade.', 'invalid', 'titulo')
    const valor = b.valor === undefined || b.valor === '' ? 0 : Number(String(b.valor).replace(',', '.')); if (!isFinite(valor) || valor < 0 || valor > 1e9) fail(400, 'Valor inválido.', 'invalid', 'valor')
    const etapas = await SalesPipelineService.etapas(bid), et = b.etapaId ? etapas.find((e) => e.id === Number(b.etapaId)) : etapas.find((e) => e.tipo === 'aberta'); if (!et) fail(400, 'Etapa inválida.', 'invalid', 'etapaId')
    if (et!.tipo !== 'aberta') fail(400, 'Crie a oportunidade em uma etapa aberta e depois conclua ou perca.', 'invalid', 'etapaId')
    if (b.previsaoFechamento && !DATA.test(String(b.previsaoFechamento))) fail(400, 'Previsão de fechamento inválida (AAAA-MM-DD).', 'invalid', 'previsaoFechamento')
    const now = nowIso(), r = await q('INSERT INTO crm_opps (business_id, contact_id, title, value, stage_id, status, probability, expected_close, owner_name, notes, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12) RETURNING id',
      [bid, c.id, titulo, valor, et!.id, 'aberta', pct(b.probabilidade, et!.probabilidade), b.previsaoFechamento || null, txt(b.responsavel, 60) || c.owner_name || null, txt(b.observacoes, 2000) || null, a.id || null, now])
    const id = Number(r[0].id); await evento(bid, { contato: Number(c.id), opp: id, tipo: 'oportunidade', texto: `Oportunidade criada: ${titulo} · R$ ${valor.toFixed(2).replace('.', ',')} · etapa ${et!.nome}.` }, a); await log(a, bid, 'crm.oportunidade.criar', id, { valor })
    return this.obter(bid, id)
  },
  async editar(bid: number, id: number, b: any, a: Ator) {
    const cur = await this.obter(bid, id), sets: string[] = [], vals: any[] = [], mud: string[] = []
    const set = (c: string, v: any, rot: string, antes: any) => { sets.push(`${c} = $${vals.length + 1}`); vals.push(v); if (String(antes ?? '') !== String(v ?? '')) mud.push(`${rot}: ${antes === '' || antes == null ? '—' : antes} → ${v === '' || v == null ? '—' : v}`) }
    if (b.titulo !== undefined) { const t = txt(b.titulo, 140); if (t.length < 2) fail(400, 'Informe o título.', 'invalid', 'titulo'); set('title', t, 'título', cur.titulo) }
    if (b.valor !== undefined) { const v = Number(String(b.valor).replace(',', '.')); if (!isFinite(v) || v < 0 || v > 1e9) fail(400, 'Valor inválido.', 'invalid', 'valor'); set('value', v, 'valor', cur.valor) }
    if (b.probabilidade !== undefined && cur.situacao === 'aberta') set('probability', pct(b.probabilidade, cur.probabilidade), 'probabilidade', cur.probabilidade)
    if (b.previsaoFechamento !== undefined) { if (b.previsaoFechamento && !DATA.test(String(b.previsaoFechamento))) fail(400, 'Previsão de fechamento inválida (AAAA-MM-DD).', 'invalid', 'previsaoFechamento'); set('expected_close', b.previsaoFechamento || null, 'previsão', cur.previsaoFechamento) }
    if (b.responsavel !== undefined) set('owner_name', txt(b.responsavel, 60) || null, 'responsável', cur.responsavel)
    if (b.observacoes !== undefined) set('notes', txt(b.observacoes, 2000) || null, 'observações', cur.observacoes)
    if (!sets.length) return cur
    sets.push(`updated_at = $${vals.length + 1}`); vals.push(nowIso()); await q(`UPDATE crm_opps SET ${sets.join(', ')} WHERE id = $${vals.length + 1} AND business_id = $${vals.length + 2}`, [...vals, id, bid])
    if (mud.length) { await evento(bid, { contato: cur.contatoId, opp: id, tipo: 'oportunidade', texto: 'Alterada — ' + mud.join('; ') }, a); await log(a, bid, 'crm.oportunidade.editar', id, { mud }) }
    return this.obter(bid, id)
  },
  /** Move entre etapas: ganha fecha como venda; perdida exige o motivo; voltar para etapa aberta reabre. */
  async mover(bid: number, id: number, etapaId: number, b: { motivoPerda?: string; valor?: any }, a: Ator) {
    const cur = await this.obter(bid, id), et = await SalesPipelineService.obter(bid, etapaId)
    if (cur.etapaId === et.id) return cur
    const motivo = txt(b.motivoPerda, 200); if (et.tipo === 'perdida' && motivo.length < 3) fail(400, 'Informe o motivo da perda.', 'invalid', 'motivoPerda')
    const sets = ['stage_id = $1', 'status = $2', 'probability = $3', 'lost_reason = $4', 'closed_at = $5', 'updated_at = $6'], now = nowIso()
    const vals: any[] = [et.id, et.tipo, et.tipo === 'ganha' ? 100 : et.tipo === 'perdida' ? 0 : et.probabilidade, et.tipo === 'perdida' ? motivo : null, et.tipo === 'aberta' ? null : now, now]
    if (b.valor !== undefined && b.valor !== '') { const v = Number(String(b.valor).replace(',', '.')); if (!isFinite(v) || v < 0) fail(400, 'Valor inválido.', 'invalid', 'valor'); sets.push(`value = $${vals.length + 1}`); vals.push(v) }
    await q(`UPDATE crm_opps SET ${sets.join(', ')} WHERE id = $${vals.length + 1} AND business_id = $${vals.length + 2}`, [...vals, id, bid])
    await evento(bid, { contato: cur.contatoId, opp: id, tipo: 'funil', texto: `Etapa: ${cur.etapa} → ${et.nome}${et.tipo === 'perdida' ? ` · motivo: ${motivo}` : ''}.`, dados: { de: cur.etapaId, para: et.id } }, a)
    if (et.tipo === 'ganha') await q("UPDATE crm_contacts SET kind = 'cliente', updated_at = $1 WHERE id = $2", [now, cur.contatoId])
    await log(a, bid, 'crm.oportunidade.mover', id, { de: cur.etapa, para: et.nome, motivo: motivo || undefined }); return this.obter(bid, id)
  },
  async excluir(bid: number, id: number, a: Ator) {
    const o = await this.obter(bid, id); await q('DELETE FROM crm_opps WHERE id = $1 AND business_id = $2', [id, bid]); await q('UPDATE crm_tasks SET opp_id = NULL WHERE opp_id = $1 AND business_id = $2', [id, bid])
    await evento(bid, { contato: o.contatoId, tipo: 'oportunidade', texto: `Oportunidade excluída: ${o.titulo}.` }, a); await log(a, bid, 'crm.oportunidade.excluir', id, { titulo: o.titulo })
  },
}

/* ===================== CRMTaskService ===================== */
const TK = ['contato', 'retorno', 'proposta', 'confirmar', 'acompanhamento', 'reuniao', 'outra']
const tOut = (r: any, ct?: Map<number, any>) => ({ id: Number(r.id), titulo: r.title, tipo: r.kind, contatoId: r.contact_id == null ? null : Number(r.contact_id), cliente: r.contact_id == null ? '' : ct?.get(Number(r.contact_id))?.name || '', oportunidadeId: r.opp_id == null ? null : Number(r.opp_id), prazo: r.due_at || '', prioridade: r.priority, situacao: r.status as 'aberta' | 'concluida' | 'cancelada', responsavel: r.owner_name || '', observacoes: r.notes || '', concluidaEm: r.completed_at ? isoOf(r.completed_at) : '', criadaEm: isoOf(r.created_at) })
export const CRMTaskService = {
  async listar(bid: number, f: { situacao?: string; contatoId?: number; oppId?: number } = {}) {
    const rows = await q('SELECT * FROM crm_tasks WHERE business_id = $1 ORDER BY CASE status WHEN \'aberta\' THEN 0 ELSE 1 END, COALESCE(due_at, \'9999\'), id DESC LIMIT 1000', [bid]) as any[]
    const ct = new Map((await q('SELECT id, name FROM crm_contacts WHERE business_id = $1', [bid]) as any[]).map((c) => [Number(c.id), c]))
    let out = rows.map((r) => tOut(r, ct)); if (f.situacao) out = out.filter((t) => t.situacao === f.situacao); if (f.contatoId) out = out.filter((t) => t.contatoId === f.contatoId); if (f.oppId) out = out.filter((t) => t.oportunidadeId === f.oppId)
    return out
  },
  async obter(bid: number, id: number) { const r = await one('SELECT * FROM crm_tasks WHERE id = $1 AND business_id = $2', [id, bid]); if (!r) fail(404, 'Tarefa não encontrada.', 'not_found'); return r! },
  async criar(bid: number, b: any, a: Ator) {
    const titulo = txt(b.titulo, 140); if (titulo.length < 2) fail(400, 'Informe o título da tarefa.', 'invalid', 'titulo')
    let cid: number | null = b.contatoId ? Number(b.contatoId) : null, oid: number | null = b.oportunidadeId ? Number(b.oportunidadeId) : null
    if (oid) { const o = await OpportunityService.obter(bid, oid); if (cid && cid !== o.contatoId) fail(400, 'A oportunidade pertence a outro cliente.', 'invalid'); cid = o.contatoId }
    if (cid) await CustomerRelationshipService.obter(bid, cid)
    if (b.prazo && !PRAZO.test(String(b.prazo))) fail(400, 'Prazo inválido (AAAA-MM-DD ou AAAA-MM-DDTHH:MM).', 'invalid', 'prazo')
    const kind = TK.includes(b.tipo) ? b.tipo : 'outra', pr = ['baixa', 'media', 'alta'].includes(b.prioridade) ? b.prioridade : 'media', now = nowIso()
    const r = await q('INSERT INTO crm_tasks (business_id, contact_id, opp_id, title, kind, due_at, priority, status, owner_name, notes, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12) RETURNING id', [bid, cid, oid, titulo, kind, b.prazo || null, pr, 'aberta', txt(b.responsavel, 60) || null, txt(b.observacoes, 1000) || null, a.id || null, now])
    const id = Number(r[0].id); await evento(bid, { contato: cid, opp: oid, tarefa: id, tipo: 'tarefa', texto: `Tarefa criada: ${titulo}${b.prazo ? ' · prazo ' + b.prazo.replace('T', ' ') : ''}.` }, a); await log(a, bid, 'crm.tarefa.criar', id, { tipo: kind })
    return tOut(await this.obter(bid, id), new Map(cid ? [[cid, { name: (await CustomerRelationshipService.obter(bid, cid)).name }]] : []))
  },
  async editar(bid: number, id: number, b: any, a: Ator) {
    const cur = await this.obter(bid, id), sets: string[] = [], vals: any[] = [], set = (c: string, v: any) => { sets.push(`${c} = $${vals.length + 1}`); vals.push(v) }
    if (b.titulo !== undefined) { const t = txt(b.titulo, 140); if (t.length < 2) fail(400, 'Informe o título.', 'invalid', 'titulo'); set('title', t) }
    if (b.prazo !== undefined) { if (b.prazo && !PRAZO.test(String(b.prazo))) fail(400, 'Prazo inválido.', 'invalid', 'prazo'); set('due_at', b.prazo || null); set('notified_at', null) }
    if (b.prioridade !== undefined && ['baixa', 'media', 'alta'].includes(b.prioridade)) set('priority', b.prioridade)
    if (b.tipo !== undefined && TK.includes(b.tipo)) set('kind', b.tipo)
    if (b.responsavel !== undefined) set('owner_name', txt(b.responsavel, 60) || null)
    if (b.observacoes !== undefined) set('notes', txt(b.observacoes, 1000) || null)
    if (!sets.length) return tOut(cur)
    set('updated_at', nowIso()); await q(`UPDATE crm_tasks SET ${sets.join(', ')} WHERE id = $${vals.length + 1} AND business_id = $${vals.length + 2}`, [...vals, id, bid])
    await evento(bid, { contato: cur.contact_id == null ? null : Number(cur.contact_id), opp: cur.opp_id == null ? null : Number(cur.opp_id), tarefa: id, tipo: 'tarefa', texto: `Tarefa alterada: ${txt(b.titulo, 140) || cur.title}.` }, a); await log(a, bid, 'crm.tarefa.editar', id)
    return tOut(await this.obter(bid, id))
  },
  async situacao(bid: number, id: number, st: string, a: Ator) {
    if (!['aberta', 'concluida', 'cancelada'].includes(st)) fail(400, 'Situação inválida.', 'invalid'); const cur = await this.obter(bid, id), now = nowIso()
    await q('UPDATE crm_tasks SET status = $1, completed_at = $2, updated_at = $3 WHERE id = $4 AND business_id = $5', [st, st === 'aberta' ? null : now, now, id, bid])
    await evento(bid, { contato: cur.contact_id == null ? null : Number(cur.contact_id), opp: cur.opp_id == null ? null : Number(cur.opp_id), tarefa: id, tipo: 'tarefa', texto: `Tarefa ${st === 'concluida' ? 'concluída' : st === 'cancelada' ? 'cancelada' : 'reaberta'}: ${cur.title}.` }, a); await log(a, bid, 'crm.tarefa.' + st, id)
    return tOut(await this.obter(bid, id))
  },
  /** Lembretes pelas notificações do app (chamado pelo agendador): uma vez por tarefa/prazo. */
  async lembretes(now = new Date()) {
    const rows = await q("SELECT t.*, b.owner_id FROM crm_tasks t JOIN businesses b ON b.id = t.business_id WHERE t.status = 'aberta' AND t.due_at IS NOT NULL AND t.notified_at IS NULL LIMIT 300") as any[]
    for (const t of rows) {
      const tz = await tzDe(Number(t.business_id)), dia = localDate(tz, now), hora = localTime(tz, now), due = String(t.due_at), venceu = due.length === 10 ? due <= dia : due.slice(0, 10) < dia || (due.slice(0, 10) === dia && due.slice(11) <= hora)
      if (!venceu) continue
      await q('UPDATE crm_tasks SET notified_at = $1 WHERE id = $2', [now.toISOString(), t.id])
      await notify(Number(t.owner_id), { type: 'reminder', title: `CRM: ${t.title}`, body: `Prazo ${due.replace('T', ' ')}${t.priority === 'alta' ? ' · prioridade alta' : ''}`, link: '/x/sua-empresa', ref: `crm-task:${t.id}:${due}` })
    }
  },
}

/* ===================== CommercialIntelligenceService ===================== */
/** Análises com critério transparente: cada item traz o motivo e o registro de origem (contato/oportunidade/tarefa). */
export const CommercialIntelligenceService = {
  async indicadores(bid: number) {
    const c = await CustomerRelationshipService.listar(bid, {}), opps = await OpportunityService.listar(bid, {}), et = await SalesPipelineService.etapas(bid), tk = await CRMTaskService.listar(bid, { situacao: 'aberta' }), dia = await hoje(bid)
    const abertas = opps.filter((o) => o.situacao === 'aberta'), ganhas = opps.filter((o) => o.situacao === 'ganha'), perdidas = opps.filter((o) => o.situacao === 'perdida'), neg = new Set(et.filter((e) => e.emNegociacao).map((e) => e.id))
    const lim = Date.now() - 30 * DIAS, prox = addDays(dia, 7)
    return { totalClientes: c.filter((x) => x.tipo === 'cliente').length, totalContatos: c.length, novosLeads: c.filter((x) => x.tipo === 'lead' && Date.parse(x.criadoEm) >= lim).length, leadsEmNegociacao: new Set(abertas.filter((o) => neg.has(o.etapaId)).map((o) => o.contatoId)).size,
      oportunidadesAbertas: abertas.length, negociacoesConcluidas: ganhas.length, negociacoesPerdidas: perdidas.length, taxaConversao: ganhas.length + perdidas.length ? Math.round((ganhas.length / (ganhas.length + perdidas.length)) * 1000) / 10 : 0,
      valorOportunidades: r2(abertas.reduce((s, o) => s + o.valor, 0)), valorPonderado: r2(abertas.reduce((s, o) => s + (o.valor * o.probabilidade) / 100, 0)), valorGanho: r2(ganhas.reduce((s, o) => s + o.valor, 0)),
      proximosAcompanhamentos: tk.filter((t) => t.prazo && t.prazo.slice(0, 10) <= prox).slice(0, 8), tarefasAtrasadas: tk.filter((t) => t.prazo && t.prazo.slice(0, 10) < dia).length, tarefasAbertas: tk.length }
  },
  async analise(bid: number) {
    const cfg = await config(bid), dia = await hoje(bid), now = Date.now()
    const contatos = await CustomerRelationshipService.listar(bid, {}), opps = await OpportunityService.listar(bid, {}), tarefas = await CRMTaskService.listar(bid, { situacao: 'aberta' })
    const ult = new Map<number, number>(); for (const e of await q("SELECT contact_id, MAX(created_at) AS m FROM crm_events WHERE business_id = $1 AND kind IN ('interacao','observacao','funil','tarefa') AND contact_id IS NOT NULL GROUP BY contact_id", [bid]) as any[]) ult.set(Number(e.contact_id), Date.parse(isoOf(e.m)))
    const comTarefa = new Set(tarefas.map((t) => t.contatoId).filter(Boolean) as number[])
    const dias = (t: number) => Math.floor((now - t) / DIAS)
    const semAcomp = contatos.filter((c) => c.tipo === 'lead' && !comTarefa.has(c.id) && dias(ult.get(c.id) || Date.parse(c.criadoEm)) >= cfg.diasSemAcompanhamento)
      .map((c) => ({ contatoId: c.id, nome: c.nome, dias: dias(ult.get(c.id) || Date.parse(c.criadoEm)), motivo: `Lead sem tarefa aberta e sem interação há ${dias(ult.get(c.id) || Date.parse(c.criadoEm))} dias (limite: ${cfg.diasSemAcompanhamento}).` })).sort((a, b) => b.dias - a.dias)
    const abertas = opps.filter((o) => o.situacao === 'aberta')
    const paradas = abertas.filter((o) => dias(Date.parse(o.atualizadaEm)) >= cfg.diasParado).map((o) => ({ oportunidadeId: o.id, titulo: o.titulo, cliente: o.cliente, etapa: o.etapa, valor: o.valor, dias: dias(Date.parse(o.atualizadaEm)), motivo: `Sem movimentação há ${dias(Date.parse(o.atualizadaEm))} dias (limite: ${cfg.diasParado}).` })).sort((a, b) => b.dias - a.dias)
    const em7 = addDays(dia, 7)
    const proximas = abertas.filter((o) => (o.previsaoFechamento && o.previsaoFechamento <= em7) || o.probabilidade >= 75).map((o) => ({ oportunidadeId: o.id, titulo: o.titulo, cliente: o.cliente, valor: o.valor, probabilidade: o.probabilidade, previsao: o.previsaoFechamento, motivo: o.previsaoFechamento && o.previsaoFechamento <= em7 ? `Previsão de fechamento em ${o.previsaoFechamento}${o.previsaoFechamento < dia ? ' (vencida)' : ''}.` : `Probabilidade ${o.probabilidade}% (≥ 75%).` })).sort((a, b) => (a.previsao || '9').localeCompare(b.previsao || '9'))
    const retorno = contatos.filter((c) => c.tipo === 'cliente' && c.compras.ultima && !comTarefa.has(c.id) && dias(Date.parse(c.compras.ultima)) >= cfg.diasRetorno).map((c) => ({ contatoId: c.id, nome: c.nome, dias: dias(Date.parse(c.compras.ultima)), compras: c.compras.pedidos + c.compras.agendamentos, motivo: `Última compra/agendamento há ${dias(Date.parse(c.compras.ultima))} dias (limite: ${cfg.diasRetorno}) e sem tarefa de retorno.` })).sort((a, b) => b.dias - a.dias)
    const prob = [...abertas].sort((a, b) => b.probabilidade - a.probabilidade || b.valor - a.valor).slice(0, 5).map((o) => ({ oportunidadeId: o.id, titulo: o.titulo, cliente: o.cliente, probabilidade: o.probabilidade, valor: o.valor, motivo: `Maior probabilidade informada entre as oportunidades abertas (${o.probabilidade}%).` }))
    const recorrentes = contatos.filter((c) => c.recorrente).map((c) => ({ contatoId: c.id, nome: c.nome, compras: c.compras.pedidos + c.compras.agendamentos, total: c.compras.total, motivo: `${c.compras.pedidos + c.compras.agendamentos} compras/agendamentos válidos (≥ 2).` })).sort((a, b) => b.compras - a.compras).slice(0, 20)
    const mot = new Map<string, number>(); for (const o of opps.filter((x) => x.situacao === 'perdida')) mot.set(o.motivoPerda.toLowerCase(), (mot.get(o.motivoPerda.toLowerCase()) || 0) + 1)
    const motivos = [...mot.entries()].map(([motivo, n]) => ({ motivo, ocorrencias: n })).sort((a, b) => b.ocorrencias - a.ocorrencias)
    return { geradoEm: nowIso(), criterios: cfg, leadsSemAcompanhamento: semAcomp, oportunidadesParadas: paradas, proximasDoFechamento: proximas, clientesParaRetorno: retorno, maiorProbabilidade: prob, clientesRecorrentes: recorrentes, motivosDePerda: motivos, desempenho: await this.desempenho(bid) }
  },
  /** Desempenho por período e responsável (oportunidades fechadas no período). */
  async desempenho(bid: number) {
    const opps = await OpportunityService.listar(bid, {}), now = Date.now()
    const per = (d: number) => { const l = opps.filter((o) => o.fechadaEm && now - Date.parse(o.fechadaEm) <= d * DIAS), g = l.filter((o) => o.situacao === 'ganha'), p = l.filter((o) => o.situacao === 'perdida'); return { ganhas: g.length, perdidas: p.length, valorGanho: r2(g.reduce((s, o) => s + o.valor, 0)), conversao: g.length + p.length ? Math.round((g.length / (g.length + p.length)) * 1000) / 10 : 0 } }
    const por = new Map<string, { ganhas: number; perdidas: number; abertas: number; valorGanho: number }>()
    for (const o of opps) { const k = o.responsavel || 'Sem responsável', x = por.get(k) || { ganhas: 0, perdidas: 0, abertas: 0, valorGanho: 0 }; if (o.situacao === 'ganha') { x.ganhas++; x.valorGanho = r2(x.valorGanho + o.valor) } else if (o.situacao === 'perdida') x.perdidas++; else x.abertas++; por.set(k, x) }
    return { ultimos7dias: per(7), ultimos30dias: per(30), ultimos90dias: per(90), porResponsavel: [...por.entries()].map(([responsavel, v]) => ({ responsavel, ...v, conversao: v.ganhas + v.perdidas ? Math.round((v.ganhas / (v.ganhas + v.perdidas)) * 1000) / 10 : 0 })) }
  },
}

/* ===================== CRMService (visão geral, categorias, etiquetas e responsáveis) ===================== */
export const CRMService = {
  async visao(bid: number) { await LeadManagementService.sincronizar(bid); await SalesPipelineService.garantir(bid); return { indicadores: await CommercialIntelligenceService.indicadores(bid), funil: (await SalesPipelineService.funil(bid)).map((e) => ({ id: e.id, nome: e.nome, cor: e.cor, tipo: e.tipo, total: e.total, valor: e.valor })) } },
  async rotulos(bid: number, ownerNome = '') {
    const l = await q('SELECT * FROM crm_labels WHERE business_id = $1 ORDER BY name', [bid]) as any[], por = (k: string) => l.filter((x) => x.kind === k).map((x) => ({ id: Number(x.id), nome: x.name, cor: x.color || '' }))
    const resp = por('responsavel'); if (ownerNome && !resp.some((r) => r.nome === ownerNome)) resp.unshift({ id: 0, nome: ownerNome, cor: '' })
    return { categorias: por('categoria'), etiquetas: por('etiqueta'), responsaveis: resp, origens: ['manual', 'chat', 'pedido', 'agendamento', 'indicação', 'site', 'redes sociais', 'WhatsApp', 'outra'] }
  },
  async criarRotulo(bid: number, b: any, a: Ator) {
    const kind = String(b.tipo), nome = txt(b.nome, 40); if (!['categoria', 'etiqueta', 'responsavel'].includes(kind)) fail(400, 'Tipo inválido.', 'invalid', 'tipo'); if (nome.length < 2) fail(400, 'Informe o nome.', 'invalid', 'nome')
    if (await one('SELECT 1 AS x FROM crm_labels WHERE business_id = $1 AND kind = $2 AND LOWER(name) = $3', [bid, kind, nome.toLowerCase()])) fail(409, 'Já existe.', 'duplicate', 'nome')
    await q('INSERT INTO crm_labels (business_id, kind, name, color, created_at) VALUES ($1,$2,$3,$4,$5)', [bid, kind, nome, COR.test(String(b.cor)) ? b.cor : null, nowIso()]); await log(a, bid, 'crm.rotulo.criar', null, { kind, nome })
  },
  async removerRotulo(bid: number, id: number, a: Ator) { await q('DELETE FROM crm_labels WHERE id = $1 AND business_id = $2', [id, bid]); await log(a, bid, 'crm.rotulo.remover', id) },
}
export const CRM_INTERNALS = { phoneKey, emailKey, cOut }
