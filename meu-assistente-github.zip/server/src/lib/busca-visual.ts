// Busca visual de produtos (modo "Busca de produtos e serviços"): a pessoa envia uma foto, print ou imagem de catálogo e o
// assistente identifica o produto e procura correspondências REAIS.
//
// Fluxo, coordenado pelo Cérebro Central (os mesmos recursos que ele já usa, sem sistema paralelo):
//  1. Análise da imagem: a Central de Mídia (quando configurada) extrai textos (OCR) e códigos de barras/QR; a IA com visão
//     (motor multi-IA, a mesma da leitura de comprovantes) gera a DESCRIÇÃO ESTRUTURADA (produto, categoria, marca, modelo,
//     cor, formato, características, textos e códigos visíveis) e as consultas. Sem IA com visão, segue só com o que a
//     Central leu; sem nada legível, diz que não conseguiu identificar e pede uma descrição — nunca chuta.
//  2. Pesquisa: (a) lojas parceiras do app (mesmo catálogo/regras da vitrine); (b) internet, pelos mecanismos de pesquisa
//     ATIVOS no Cérebro Central (gratuitos primeiro, fallback, cache e limites diários), com consultas montadas a partir de
//     marca, modelo, códigos, características e das instruções da pessoa ("o mais barato", "só originais"…).
//  3. Conferência: as páginas de produto escolhidas são lidas (robots.txt respeitado) e só os dados que a LOJA publica de
//     forma estruturada viram preço, disponibilidade, marca e imagem. O que não foi lido fica "não verificado".
//  4. Comparação: cada resultado ganha a correspondência — "mesmo produto" (código de barras igual, ou marca + modelo no
//     produto da loja), "provável" ou "semelhante" — e é ordenado por correspondência (ou por preço, se pedido).
// A imagem enviada NÃO é guardada: fica só a descrição estruturada e os resultados (tabela busca_visual, do próprio dono).
import { q, one, J, nowIso } from '../db/index.js'
import { etapa } from './etapas.js'
import { norm, lerConsulta } from './busca-itens.js'

export interface Analise { eProduto: boolean; produto: string; categoria: string; marca: string; modelo: string; cor: string; formato: string; caracteristicas: string[]; textos: string[]; codigos: string[]; consultas: string[]; confianca: number; origem: 'ia' | 'central' | 'ia+central' | 'nenhuma' }
export interface Instrucao { foco: 'exato' | 'semelhantes' | 'normal'; ordem: 'correspondencia' | 'preco'; originais: boolean; qualidade: boolean; regiao: boolean; maxPreco: number | null; texto: string }
export type Corresp = 'mesmo' | 'provavel' | 'semelhante'
export interface ResultadoWeb { titulo: string; url: string; loja: string; dominio: string; imagem: string | null; preco: number | null; moeda: string | null; disponibilidade: 'em_estoque' | 'esgotado' | 'pre_venda' | null; marca: string | null; modelo: string | null; correspondencia: Corresp; nota: number; verificado: boolean }

/* ------------------------------------------------------------------ instruções */
export function lerInstrucao(texto: string): Instrucao {
  const s = norm(texto)
  const foco = /\b(exatamente|exato|exata|mesmo produto|mesmo modelo|identic\w*|igualzinh\w*|este mesmo|esse mesmo)\b/.test(s) ? 'exato' : /\b(semelhante\w*|parecid\w*|similar\w*|alternativ\w*|tipo esse|tipo este|parecido com)\b/.test(s) ? 'semelhantes' : 'normal'
  return { foco, ordem: /\b(mais barat\w*|menor preco|barat\w*|economic\w*|em conta|preco baixo|melhor preco)\b/.test(s) ? 'preco' : 'correspondencia', originais: /\b(origina(l|is)|oficia(l|is)|autentic\w*|genuin\w*|nao (seja )?(replica|falsificad\w*|pirata))\b/.test(s),
    qualidade: /\b(melhor qualidade|mais qualidade|qualidade|premium|mais resistente|durave(l|is)|bem avaliad\w*)\b/.test(s), regiao: /\b(minha regiao|perto de mim|aqui perto|na minha cidade|entreg\w* (na|em|para|aqui)|regiao)\b/.test(s), maxPreco: lerConsulta(texto).maxPreco, texto: String(texto || '').slice(0, 300) }
}
/** A legenda da foto pede busca de produto? (fora do modo: "onde compro isso?", "encontre este produto") */
export const legendaPedeBusca = (texto: string) => /\b(onde (eu )?(compro|comprar|acho|encontro|vende)|quem vende|encontr\w* (esse|este|essa|esta|o mesmo|um parecido|produto)|procur\w* (esse|este|essa|esta|produto|um parecido)|ach\w* (esse|este|essa|esta) (produto|item)|quanto custa (isso|esse|este|essa|esta)|qual (e )?(esse|este) produto|que produto (e esse|e este)|mais barat\w*|busca visual|pesquis\w* (esse|este|essa|esta) produto|semelhantes? a (esse|este|essa|esta))\b/.test(norm(texto))

/* ------------------------------------------------------------------ análise */
const PROMPT = (ocr: string, codigos: string[], legenda: string) => `BUSCA VISUAL DE PRODUTO. Você analisa a imagem enviada por um cliente brasileiro que quer encontrar o produto para comprar.
Identifique SÓ o que a imagem mostra. Não invente marca, modelo ou código: se não estiver claro, deixe "" e use confianca baixa.
${ocr ? `Textos lidos na imagem (OCR): "${ocr.slice(0, 600)}".` : ''}${codigos.length ? ` Códigos lidos: ${codigos.join(', ')}.` : ''}${legenda ? ` Pedido do cliente: "${legenda.slice(0, 200)}".` : ''}
Responda SOMENTE com JSON: {"eProduto":bool,"produto":"nome genérico em português (ex.: tênis de corrida)","categoria":"","marca":"","modelo":"","cor":"","formato":"","caracteristicas":["até 5 características visuais úteis para a busca"],"textos":["textos/etiquetas visíveis"],"codigos":["códigos de barras ou de modelo visíveis"],"consultas":["2 a 3 consultas de pesquisa em português, da mais específica à mais geral"],"confianca":0-1}`
const lista = (v: unknown, n: number, max = 80) => (Array.isArray(v) ? v : []).map((x) => String(x || '').replace(/\s+/g, ' ').trim().slice(0, max)).filter(Boolean).slice(0, n)
const txt = (v: unknown, max = 80) => String(v || '').replace(/\s+/g, ' ').trim().slice(0, max)
/** Normaliza o JSON da IA (tudo vira texto curto; nada que não seja do formato passa). */
export function validarAnalise(j: any): Omit<Analise, 'origem'> | null {
  if (!j || typeof j !== 'object' || !('produto' in j || 'eProduto' in j)) return null
  const codigos = lista(j.codigos, 5, 40).map((c) => c.replace(/[^\w-]/g, '')).filter((c) => c.length >= 4)
  return { eProduto: j.eProduto !== false, produto: txt(j.produto), categoria: txt(j.categoria, 60), marca: txt(j.marca, 60), modelo: txt(j.modelo, 60), cor: txt(j.cor, 40), formato: txt(j.formato, 60), caracteristicas: lista(j.caracteristicas, 5), textos: lista(j.textos, 8), codigos, consultas: lista(j.consultas, 3, 120), confianca: Math.max(0, Math.min(1, Number(j.confianca) || 0)) }
}
const EAN = /^\d{8}$|^\d{12,14}$/
export async function analisarImagem(dataUrl: string, legenda: string, userId: number): Promise<{ analise: Analise; passos: string[] }> {
  const m = String(dataUrl).match(/^data:(image\/[a-z+]+);base64,(.+)$/), passos: string[] = []
  const vazia: Analise = { eProduto: false, produto: '', categoria: '', marca: '', modelo: '', cor: '', formato: '', caracteristicas: [], textos: [], codigos: [], consultas: [], confianca: 0, origem: 'nenhuma' }
  if (!m) return { analise: vazia, passos: ['imagem inválida'] }
  const mime = m[1], b64 = m[2], buf = Buffer.from(b64, 'base64')
  etapa('visual_analisando')
  // 1) Central de Mídia: OCR + códigos (opcional; fora do ar = segue sem ela)
  let ocr = '', codigos: string[] = []
  try {
    const C = await import('./central-midia.js')
    if (C.centralConfigurada()) {
      const r = await C.processarNaCentral(buf, 'produto.' + (mime.split('/')[1] || 'jpg'), mime, { ocr: 'sempre', codigos: true, comprovante: 'nunca', interpretar: '0', cliente: `user:${userId}`, tempoMs: 25_000 })
      if (r.ok) { ocr = String(r.texto || '').replace(/\s+/g, ' ').trim().slice(0, 1200); codigos = (r.codigos || []).map((c) => String(c.conteudo || '').trim()).filter((c) => c && c.length <= 40 && !/^https?:/i.test(c)).slice(0, 5); passos.push(`central: ${ocr.length} caracteres, ${codigos.length} código(s)`) }
      else passos.push('central: ' + (r.indisponivel ? 'indisponível' : 'não leu'))
    }
  } catch { passos.push('central: indisponível') }
  // 2) IA com visão (motor multi-IA): descrição estruturada
  etapa('visual_identificando')
  let ia: Omit<Analise, 'origem'> | null = null
  try {
    const E = await import('../ai/engine.js'), { parseJsonLoose } = await import('../ai/types.js')
    if ((await E.readyCount('imagem').catch(() => 0)) > 0) {
      const out = await E.askFiles(PROMPT(ocr, codigos, legenda), [{ mime, data: b64 }], { json: true, validate: (mm) => { try { return validarAnalise(parseJsonLoose(String(mm.content || ''))) ? null : 'JSON fora do formato' } catch { return 'JSON inválido' } } })
      ia = validarAnalise(parseJsonLoose(out)); passos.push(ia ? 'ia: ok' : 'ia: fora do formato')
    } else passos.push('ia: nenhuma com visão pronta')
  } catch (e: any) { passos.push('ia: falhou') }
  if (ia) {
    const cods = [...new Set([...codigos, ...ia.codigos])].slice(0, 5)
    return { analise: { ...ia, codigos: cods, textos: ia.textos.length ? ia.textos : ocr ? [ocr.slice(0, 120)] : [], origem: ocr || codigos.length ? 'ia+central' : 'ia' }, passos }
  }
  // 3) sem IA: só o que a Central leu (texto/código). Sem nada: não identificado (a resposta pede uma descrição)
  const palavras = ocr.split(/\s+/).filter((w) => /[a-zà-ú]{3,}/i.test(w)).slice(0, 8).join(' ')
  if (codigos.length || palavras) return { analise: { ...vazia, eProduto: true, produto: palavras.slice(0, 80), textos: ocr ? [ocr.slice(0, 160)] : [], codigos, consultas: [...codigos.filter((c) => EAN.test(c)), palavras].filter(Boolean).slice(0, 3), confianca: codigos.some((c) => EAN.test(c)) ? 0.6 : 0.3, origem: 'central' }, passos }
  return { analise: vazia, passos }
}

/* ------------------------------------------------------------------ pesquisa */
const LOJA_DOMINIO = /(mercadolivre|mercadolibre|amazon\.|magazineluiza|magalu|americanas|submarino|shoptime|casasbahia|pontofrio|extra\.com|carrefour|kabum|netshoes|centauro|dafiti|zattini|shopee|aliexpress|riachuelo|renner|cea\.com|leroymerlin|madeiramadeira|fastshop|samsung|apple\.com|nike\.com|adidas|drogasil|drogaraia|panvel|boticario|natura|sephora|olist|shopify|nuvemshop|vtex|loja|store|shop)/i
const NAO_LOJA = /(wikipedia|wikimedia|youtube|youtu\.be|facebook|instagram|tiktok|twitter|x\.com|pinterest|reddit|linkedin|reclameaqui|gov\.br|\.edu|blogspot|medium\.com)/i
const REPLICA = /\b(replica|réplica|inspired|inspirad|similar|tipo|compat[ií]vel|paralel|primeira linha|aaa|imitac|falsificad)\b/i
const tokens = (s: string) => [...new Set(norm(s).replace(/[^a-z0-9 ]/g, ' ').split(' ').filter((w) => w.length >= 2 && !['de', 'da', 'do', 'com', 'para', 'em', 'e', 'o', 'a', 'os', 'as', 'um', 'uma', 'na', 'no'].includes(w)))]
const cobertura = (alvo: string, texto: string) => { const a = tokens(alvo); if (!a.length) return 0; const t = new Set(tokens(texto)); return a.filter((w) => t.has(w) || [...t].some((x) => x.length >= 4 && w.length >= 4 && (x.startsWith(w) || w.startsWith(x)))).length / a.length }
export function montarConsultas(a: Analise, ins: Instrucao, cidade = ''): string[] {
  const out: string[] = [], add = (s: string) => { const v = s.replace(/\s+/g, ' ').trim(); if (v.length >= 3 && !out.some((x) => norm(x) === norm(v))) out.push(v) }
  for (const c of a.codigos) if (EAN.test(c)) add(c)
  const base = [a.marca, a.produto && a.marca && norm(a.produto).includes(norm(a.marca)) ? a.produto.replace(new RegExp(a.marca, 'i'), '') : a.produto, a.modelo].filter(Boolean).join(' ')
  if (ins.foco === 'semelhantes') { add([a.produto || a.categoria, a.cor, a.caracteristicas[0]].filter(Boolean).join(' ')); add(base) }
  else { if (a.marca && a.modelo) add(`${a.marca} ${a.modelo}`); add(base); for (const c of a.consultas) add(c) }
  if (ins.originais && a.marca) out.unshift(`${base} loja oficial ${a.marca}`)
  if (ins.regiao && cidade) out.unshift(`${base} ${cidade}`)
  if (!out.length && a.categoria) add(a.categoria)
  return out.slice(0, 3)
}
export function corresp(a: Analise, r: { titulo: string; marca: string | null; modelo: string | null; gtin?: string | null }): { c: Corresp; nota: number } | null {
  const tt = `${r.titulo} ${r.marca || ''} ${r.modelo || ''}`
  if (r.gtin && a.codigos.some((c) => c.replace(/^0+/, '') === r.gtin!.replace(/^0+/, ''))) return { c: 'mesmo', nota: 1 }
  const marcaOk = !!a.marca && cobertura(a.marca, tt) >= 1, modeloOk = !!a.modelo && a.modelo.length >= 3 && cobertura(a.modelo, tt) >= 0.99
  const prod = cobertura(a.produto || a.categoria, tt), carac = a.caracteristicas.length ? Math.max(...a.caracteristicas.map((x) => cobertura(x, tt))) : 0
  if (marcaOk && modeloOk) return { c: 'mesmo', nota: 0.9 + 0.05 * prod }
  if (marcaOk && (prod >= 0.5 || cobertura(a.modelo, tt) >= 0.5)) return { c: 'provavel', nota: 0.6 + 0.2 * prod + 0.1 * carac }
  const n = 0.5 * prod + 0.2 * carac + (marcaOk ? 0.2 : 0) + 0.1 * cobertura(a.cor, tt)
  return n >= 0.3 ? { c: 'semelhante', nota: n } : null
}
const RANK: Record<Corresp, number> = { mesmo: 0, provavel: 1, semelhante: 2 }
export function ordenar(rs: ResultadoWeb[], ins: Instrucao): ResultadoWeb[] {
  const v = [...rs]
  // "o mais barato": o mesmo produto (ou provável) do menor para o maior preço; alternativas semelhantes depois, também por preço
  if (ins.ordem === 'preco') return v.sort((x, y) => Number(x.correspondencia === 'semelhante') - Number(y.correspondencia === 'semelhante') || (x.preco == null ? 1 : 0) - (y.preco == null ? 1 : 0) || (x.preco ?? 0) - (y.preco ?? 0) || RANK[x.correspondencia] - RANK[y.correspondencia] || y.nota - x.nota)
  return v.sort((x, y) => RANK[x.correspondencia] - RANK[y.correspondencia] || (x.disponibilidade === 'esgotado' ? 1 : 0) - (y.disponibilidade === 'esgotado' ? 1 : 0) || y.nota - x.nota || (x.preco == null ? 1 : 0) - (y.preco == null ? 1 : 0))
}

export interface Pesquisa { status: 'concluida' | 'sem_resultados' | 'falhou'; web: ResultadoWeb[]; parceiros: string; parceirosSemelhantes: string; consultas: string[]; webDisponivel: boolean; webErro: string | null; paginasLidas: number; localizacao: string | null }
export async function pesquisar(userId: number, a: Analise, ins: Instrucao): Promise<Pesquisa> {
  etapa('visual_pesquisando')
  const B = await import('../routes/businesses.js'), loc = await B.userLocation(userId).catch(() => null)
  const consultas = montarConsultas(a, ins, ins.regiao ? String(loc?.label || '').split(',').slice(-2).join(' ').trim() : '')
  // (a) lojas parceiras do app — mesmas regras da vitrine; termos do produto (não do modelo, que a loja local raramente escreve)
  let parceiros = '', parceirosSemelhantes = ''
  try {
    const MB = await import('../modos/busca.js'), l = lerConsulta([a.produto || a.categoria, a.marca].filter(Boolean).join(' '))
    if (l.termos.length) {
      const r = await MB.pesquisar(userId, { termos: l.termos, maxPreco: ins.maxPreco, ordem: ins.ordem === 'preco' ? 'menor' : 'relevancia', ofertas: false, tipo: 'produto', pagina: 0, texto: a.produto })
      const ids = (xs: any[]) => xs.map((x) => (x.tipo === 'servico' ? 's' : 'p') + x.id).join(',')
      parceiros = ids(r.pag); parceirosSemelhantes = r.pag.length ? '' : ids(r.semelhantes)
    }
  } catch { /* catálogo indisponível: segue com a internet */ }
  // (b) internet: mecanismos ativos do Cérebro Central
  const C = await import('../ai/cerebro/central.js'), W = await import('../ai/cerebro/web.js'), cfg = await C.cfgPesquisa()
  const brutos = new Map<string, { titulo: string; resumo: string; url: string }>(); let webErro: string | null = null, algumOk = false
  for (const cq of consultas) {
    const r = await C.pesquisarResultados(cq, { limite: 10 }).catch(() => ({ resultados: [], usados: [], erro: 'falha' as const }))
    if (r.erro === 'sem_motor') { webErro = 'sem_motor'; break }
    if (r.erro) { webErro = webErro || r.erro; continue }
    algumOk = true
    for (const x of r.resultados) { const d = W.dominio(x.url); if (!d || NAO_LOJA.test(d) || brutos.has(x.url)) continue; brutos.set(x.url, { titulo: x.titulo, resumo: x.resumo, url: x.url }) }
    if (brutos.size >= 14) break
  }
  if (algumOk) webErro = null
  // pré-seleção: o que parece página de loja e trata do produto vem primeiro; até 8 páginas lidas (em paralelo, com prazo)
  const cand = [...brutos.values()].map((x) => ({ ...x, pre: (LOJA_DOMINIO.test(W.dominio(x.url)) ? 0.3 : 0) + (/\/(p|produto|product|dp|item|mlb|prd)[\/-]|\/p$|-p$|\.html$/i.test(x.url) ? 0.2 : 0) + cobertura([a.marca, a.produto, a.modelo].filter(Boolean).join(' '), `${x.titulo} ${x.resumo}`) }))
    .sort((p, q2) => q2.pre - p.pre).slice(0, 8)
  etapa('visual_comparando')
  let paginasLidas = 0
  const lidos = await Promise.all(cand.map(async (x) => {
    try { const d = await W.lerProduto(x.url, { timeoutMs: Math.min(cfg.timeoutMs, 8000), cacheHoras: Math.min(cfg.cacheHoras || 6, 6) }); paginasLidas++; return { x, d } } catch { return { x, d: null } }
  }))
  const web: ResultadoWeb[] = []
  for (const { x, d } of lidos) {
    const titulo = (d?.produto && d.titulo) || x.titulo, dom = W.dominio(d?.url || x.url)
    // página lida e SEM dados de produto (artigo, review, blog, categoria): não é uma oferta — fica de fora. Página que não pôde ser
    // lida (robots, tempo) só entra se parecer página de produto de loja, e entra como "não verificada" (sem preço)
    if (d && !d.produto) continue
    if (!d && !(LOJA_DOMINIO.test(dom) || /\/(p|produto|product|dp|item|prd)[\/-]/i.test(x.url))) continue
    let cr = corresp(a, { titulo, marca: d?.marca || null, modelo: d?.modelo || null, gtin: d?.gtin || null }); if (!cr) continue
    if (!d && cr.c === 'mesmo') cr = { c: 'provavel', nota: Math.min(cr.nota, 0.85) } // página não conferida: no máximo "provável"
    if (REPLICA.test(titulo) && cr.c !== 'semelhante') cr = { c: 'semelhante', nota: Math.min(cr.nota, 0.5) } // réplica/"similar" nunca é "o mesmo produto"
    if (ins.foco === 'exato' && cr.c === 'semelhante' && (a.marca || a.modelo || a.codigos.length)) continue
    if (ins.originais && (REPLICA.test(titulo) || (a.marca && cr.c !== 'mesmo' && !norm(dom).includes(norm(a.marca).replace(/\s+/g, '')) && !LOJA_DOMINIO.test(dom)))) continue
    const brl = !d?.moeda || d.moeda === 'BRL'
    const preco = d?.produto && d.preco != null && brl ? d.preco : null
    if (ins.maxPreco != null && preco != null && preco > ins.maxPreco) continue
    web.push({ titulo: titulo.slice(0, 160), url: d?.url || x.url, loja: (d?.loja && d.loja.length <= 40 ? d.loja : '') || dom, dominio: dom, imagem: d?.imagem ? await (await import('../ai/cerebro/imagens.js')).caminhoProxy(d.imagem) : null, preco, moeda: preco != null ? 'BRL' : null, disponibilidade: d?.produto ? d.disponibilidade : null, marca: d?.marca || null, modelo: d?.modelo || null, correspondencia: cr.c, nota: Math.round(cr.nota * 100) / 100, verificado: !!d?.produto })
  }
  const ord = ordenar(web, ins).slice(0, 8)
  const status = ord.length || parceiros || parceirosSemelhantes ? 'concluida' : webErro && webErro !== 'sem_motor' ? 'falhou' : 'sem_resultados'
  return { status, web: ord, parceiros, parceirosSemelhantes, consultas, webDisponivel: webErro !== 'sem_motor', webErro, paginasLidas, localizacao: loc?.label || null }
}

/* ------------------------------------------------------------------ registro e leitura */
export async function salvar(userId: number, conv: string, a: Analise, ins: Instrucao, p: Pesquisa, passos: string[]) {
  const r = await q('INSERT INTO busca_visual (user_id, conversation_id, analise, instrucao, resultados, parceiros, status, fontes, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id',
    [userId, conv || null, JSON.stringify(a), JSON.stringify(ins), JSON.stringify(p.web), [p.parceiros, p.parceirosSemelhantes].join('|'), p.status, JSON.stringify({ analise: passos, consultas: p.consultas, paginasLidas: p.paginasLidas, web: p.webDisponivel ? (p.webErro || 'ok') : 'indisponivel' }), nowIso()])
  return Number(r[0].id)
}
/** Card ⟦bv:id⟧: só o dono vê. */
export async function ler(userId: number, id: number) {
  const r: any = await one('SELECT * FROM busca_visual WHERE id = $1 AND user_id = $2', [id, userId]); if (!r) return null
  const a = J<Analise>(r.analise, {} as Analise), ins = J<Instrucao>(r.instrucao, {} as Instrucao)
  return { id: Number(r.id), status: String(r.status), criadoEm: r.criado_em, analise: { produto: a.produto, categoria: a.categoria, marca: a.marca, modelo: a.modelo, cor: a.cor, caracteristicas: a.caracteristicas || [], textos: a.textos || [], codigos: a.codigos || [], confianca: a.confianca, identificado: !!(a.produto || a.marca) },
    instrucao: { foco: ins.foco, ordem: ins.ordem, originais: ins.originais, regiao: ins.regiao }, resultados: J<ResultadoWeb[]>(r.resultados, []) }
}
export const descricao = (a: Analise) => [a.produto || a.categoria, a.marca && !norm(a.produto).includes(norm(a.marca)) ? a.marca : '', a.modelo, a.cor].filter(Boolean).join(' · ')
