// Página de Links da empresa: central de links pública (/<endereço-da-empresa>/links), exclusiva do anúncio completo.
// Reaproveita o que já existe: o endereço exclusivo da empresa (slug do agente), a identidade visual do catálogo
// (businesses.data.tema via normalizeTema/MaTheme), o logo e a capa do anúncio e a contratação do agente.
// Regras (conferidas no servidor a cada leitura e gravação):
//  - só empresas no plano completo (nível 4) editam; a página pública só abre com o anúncio no ar nesse plano;
//  - "Catálogo" é padrão e sempre presente; "Agente de Atendimento" só aparece com o agente contratado e ligado;
//  - cada empresa só lê e grava a própria página (dono confirmado por ownBusiness).
import { randomBytes } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'
import { cleanUrl } from './showcase.js'
import { normalizeTema } from './theme.js'

export const NIVEL_COMPLETO = 4
export const MAX_BOTOES = 30
export const TIPOS: Record<string, { nome: string; pede: string }> = {
  link: { nome: 'Link', pede: 'url' }, site: { nome: 'Site', pede: 'url' }, whatsapp: { nome: 'WhatsApp', pede: 'telefone' },
  instagram: { nome: 'Instagram', pede: 'usuario' }, facebook: { nome: 'Facebook', pede: 'url' }, tiktok: { nome: 'TikTok', pede: 'usuario' },
  youtube: { nome: 'YouTube', pede: 'url' }, linkedin: { nome: 'LinkedIn', pede: 'url' }, telegram: { nome: 'Telegram', pede: 'usuario' },
  email: { nome: 'E-mail', pede: 'email' },
}
const SISTEMA = ['catalogo', 'agente']
/* Personalização visual (o que aparece e onde fica o logotipo). Ocultar só esconde: nada é apagado. */
export const ELEMENTOS = ['capa', 'logo', 'titulo', 'descricao', 'botoes'] as const
export const LOGO_POS = ['esquerda', 'centro', 'direita'] as const
export const LOGO_MIN = 48, LOGO_MAX = 120, LOGO_PADRAO = 64
export function exibirDe(e: any) { const o = e && typeof e === 'object' ? e : {}; return Object.fromEntries(ELEMENTOS.map((k) => [k, o[k] !== false])) as Record<(typeof ELEMENTOS)[number], boolean> }
export const logoPosDe = (v: any) => ((LOGO_POS as readonly string[]).includes(v) ? v : 'esquerda') as (typeof LOGO_POS)[number]
export const logoTamDe = (v: any) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n > 0 ? Math.min(LOGO_MAX, Math.max(LOGO_MIN, n)) : LOGO_PADRAO }
const txt = (v: any, n: number) => String(v ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').replace(/[ \t]+/g, ' ').trim().slice(0, n)

/* ---------- acesso ---------- */
export async function nivelDe(b: any) { const { plans } = await import('../routes/ads.js'); return Number((await plans()).find((p: any) => p.id === b.plan_id)?.nivel) || 0 }
export async function nomeCompleto() { const { plans } = await import('../routes/ads.js'); return (await plans()).filter((p: any) => Number(p.nivel) >= NIVEL_COMPLETO).map((p: any) => p.nome)[0] || 'Loja completa' }
export const noAr = (b: any) => b?.status === 'ativo' && !(b.expires_at && Date.parse(b.expires_at) < Date.now()) && !J<any>(b.data, {}).revogado
/** Edição: plano completo. */
export async function podeEditar(b: any) {
  if ((await nivelDe(b)) >= NIVEL_COMPLETO) return { ok: true as const }
  return { ok: false as const, codigo: 'links_plano', mensagem: `A Página de Links é exclusiva do anúncio completo (plano ${await nomeCompleto()}). Mude de plano para liberar.` }
}
/** Página pública: plano completo e anúncio no ar. */
export async function podePublicar(b: any) { return (await nivelDe(b)) >= NIVEL_COMPLETO && noAr(b) }
export async function agenteAtivo(x: any) {
  const { modules } = await import('./usermod.js')
  return !!(x?.agente && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() && x.agente.ativo !== false && (await modules()).agente)
}

/* ---------- conteúdo ---------- */
export function padrao(x: any) {
  const serv = x.tipo === 'servicos'
  return {
    titulo: '', descricao: '', logo: '', capa: '', exibir: exibirDe({}), logoPos: 'esquerda', logoTam: LOGO_PADRAO, temaProprio: false, tema: { cor: normalizeTema(x.tema).cor, fundo: normalizeTema(x.tema).fundo },
    botoes: [
      { id: 'catalogo', tipo: 'catalogo', titulo: 'Catálogo', descricao: serv ? 'Serviços, preços e agendamento' : 'Produtos, preços e pedidos', valor: '', ativo: true },
      { id: 'agente', tipo: 'agente', titulo: 'Agente de Atendimento', descricao: 'Tire suas dúvidas e faça seu pedido, 24 horas', valor: '', ativo: true },
    ],
  }
}
function imagem(v: any, max: number): string {
  const s = String(v ?? '').trim(); if (!s) return ''
  if (/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(s)) { if (s.length > max) fail(400, 'Imagem grande demais. Use uma imagem menor.', 'invalid', 'imagem'); return s }
  if (/^https:\/\/[^\s<>"']{4,500}$/.test(s)) return s
  fail(400, 'Imagem inválida: envie PNG, JPG ou WebP.', 'invalid', 'imagem'); return ''
}
/** Valida e normaliza o valor de cada tipo de botão (devolve o valor guardado). */
export function valorDe(tipo: string, v: any): string {
  const s = String(v ?? '').trim(), nome = TIPOS[tipo]?.nome || 'link'
  if (!s) fail(400, `Preencha o ${TIPOS[tipo]?.pede === 'telefone' ? 'número' : TIPOS[tipo]?.pede === 'usuario' ? 'usuário ou link' : TIPOS[tipo]?.pede === 'email' ? 'e-mail' : 'link'} do botão ${nome}.`, 'invalid', 'valor')
  if (tipo === 'whatsapp') { let d = s.replace(/\D/g, ''); if (d.length === 10 || d.length === 11) d = '55' + d; if (d.length < 12 || d.length > 13) fail(400, 'Informe o WhatsApp com DDD (ex.: 11 98765-4321).', 'invalid', 'valor'); return d }
  if (tipo === 'email') { if (!/^[^\s@<>"']{1,64}@[^\s@<>"']{1,190}\.[a-z]{2,}$/i.test(s)) fail(400, 'Informe um e-mail válido.', 'invalid', 'valor'); return s.toLowerCase() }
  if (['instagram', 'tiktok', 'telegram'].includes(tipo) && !/^https?:\/\//i.test(s)) { const h = s.replace(/^@/, ''); if (!/^[A-Za-z0-9._]{1,40}$/.test(h)) fail(400, `Informe o usuário do ${nome} (ex.: @suaempresa) ou o link completo.`, 'invalid', 'valor'); return '@' + h }
  return cleanUrl(/^https?:\/\//i.test(s) ? s : 'https://' + s)
}
export function hrefDe(tipo: string, valor: string): string {
  if (tipo === 'whatsapp') return `https://wa.me/${valor}`
  if (tipo === 'email') return `mailto:${valor}`
  if (valor.startsWith('@')) { const h = valor.slice(1); return tipo === 'instagram' ? `https://instagram.com/${h}` : tipo === 'tiktok' ? `https://www.tiktok.com/@${h}` : `https://t.me/${h}` }
  return valor
}
/** Valida o rascunho enviado pelo dono. Botões do sistema nunca somem; os personalizados são validados um a um. */
export function normalizar(x: any, b: any) {
  const base = padrao(x), entrada = b && typeof b === 'object' ? b : {}
  const t = entrada.tema && typeof entrada.tema === 'object' ? entrada.tema : {}
  const tema = normalizeTema({ ...normalizeTema(x.tema), ...(/^#[0-9a-f]{6}$/i.test(String(t.cor)) ? { cor: t.cor } : {}), ...(['escuro', 'claro', 'colorido'].includes(t.fundo) ? { fundo: t.fundo } : {}) })
  const lista = Array.isArray(entrada.botoes) ? entrada.botoes : []
  const out: any[] = [], vistos = new Set<string>()
  let custom = 0
  for (const r of lista) {
    if (!r || typeof r !== 'object') continue
    const tipo = String(r.tipo || '')
    if (SISTEMA.includes(tipo)) {
      if (vistos.has(tipo)) continue; vistos.add(tipo)
      const p = base.botoes.find((x) => x.tipo === tipo)!
      out.push({ ...p, titulo: txt(r.titulo, 40) || p.titulo, descricao: txt(r.descricao, 80), ativo: r.ativo !== false }) // pode ser ocultado, nunca excluído
      continue
    }
    if (!TIPOS[tipo]) fail(400, 'Tipo de botão inválido.', 'invalid', 'tipo')
    if (++custom > MAX_BOTOES) fail(400, `Use no máximo ${MAX_BOTOES} botões personalizados.`, 'invalid', 'botoes')
    const titulo = txt(r.titulo, 40); if (!titulo) fail(400, `Dê um título ao botão ${TIPOS[tipo].nome}.`, 'invalid', 'titulo')
    let id = String(r.id || ''); if (!/^[a-z0-9]{6,16}$/.test(id) || vistos.has(id) || SISTEMA.includes(id)) id = randomBytes(5).toString('hex'); vistos.add(id)
    out.push({ id, tipo, titulo, descricao: txt(r.descricao, 80), valor: valorDe(tipo, r.valor), ativo: r.ativo !== false })
  }
  for (const p of base.botoes) if (!vistos.has(p.tipo)) out.unshift(p) // o padrão volta se faltar
  return { titulo: txt(entrada.titulo, 60), descricao: txt(entrada.descricao, 300), logo: imagem(entrada.logo, 350_000), capa: imagem(entrada.capa, 900_000), exibir: exibirDe(entrada.exibir), logoPos: logoPosDe(entrada.logoPos), logoTam: logoTamDe(entrada.logoTam), temaProprio: entrada.temaProprio === true, tema: { cor: tema.cor, fundo: tema.fundo }, botoes: out }
}

/* ---------- leitura/gravação (sempre pela empresa dona) ---------- */
export async function linha(businessId: number) { return one('SELECT * FROM link_pages WHERE business_id = $1', [businessId]) }
export async function rascunhoDe(b: any) {
  const x = J<any>(b.data, {}), r = await linha(Number(b.id))
  if (!r) return padrao(x)
  const d = J<any>(r.rascunho, {})
  return Object.keys(d).length ? { ...padrao(x), ...d } : padrao(x)
}
export async function salvarRascunho(b: any, entrada: any) {
  const x = J<any>(b.data, {}), d = normalizar(x, entrada), r = await linha(Number(b.id))
  if (r) await q('UPDATE link_pages SET rascunho = $1, atualizado_em = $2 WHERE business_id = $3 AND owner_id = $4', [JSON.stringify(d), nowIso(), Number(b.id), Number(b.owner_id)])
  else await q('INSERT INTO link_pages (business_id, owner_id, rascunho, atualizado_em) VALUES ($1,$2,$3,$4)', [Number(b.id), Number(b.owner_id), JSON.stringify(d), nowIso()])
  return d
}
export async function publicar(b: any, entrada?: any) {
  const d = entrada !== undefined ? await salvarRascunho(b, entrada) : normalizar(J<any>(b.data, {}), await rascunhoDe(b))
  if (!(await linha(Number(b.id)))) await salvarRascunho(b, d)
  await q('UPDATE link_pages SET publicado = $1, publicado_em = $2 WHERE business_id = $3 AND owner_id = $4', [JSON.stringify(d), nowIso(), Number(b.id), Number(b.owner_id)])
  return d
}
export async function despublicar(b: any) { await q('UPDATE link_pages SET publicado = NULL, publicado_em = NULL WHERE business_id = $1 AND owner_id = $2', [Number(b.id), Number(b.owner_id)]) }
export async function descartar(b: any) { const r = await linha(Number(b.id)); if (r?.publicado) await q('UPDATE link_pages SET rascunho = publicado, atualizado_em = $1 WHERE business_id = $2', [nowIso(), Number(b.id)]) }

/** Base comum da página (dados da empresa + botões automáticos), usada pela prévia e pela página pública. */
export async function base(b: any) {
  const x = J<any>(b.data, {}), { ensureSlug, openState } = await import('../routes/businesses.js')
  const slug = await ensureSlug(Number(b.id)), st = openState(x)
  return { id: Number(b.id), slug, empresa: x.empresa || 'Empresa', categoria: x.categoria || '', logo: x.logo || null, capa: x.capa || null, sobre: String(x.sobre || x.texto || '').slice(0, 300), aberto: st.aberto, situacao: st.texto, temaCatalogo: normalizeTema(x.tema), agenteAtivo: await agenteAtivo(x), catalogoHref: `/x/empresa/${b.id}`, agenteHref: `/${slug}` }
}
/** Monta o que a página mostra a partir de um conteúdo (rascunho ou publicado). Botões desativados e o agente sem contratação ficam de fora. */
export function montar(B: any, c: any) {
  const tema = c.temaProprio ? normalizeTema({ ...B.temaCatalogo, cor: c.tema?.cor, fundo: c.tema?.fundo }) : B.temaCatalogo
  const exibir = exibirDe(c.exibir)
  const botoes = (exibir.botoes ? c.botoes || [] : []).filter((x: any) => x.ativo !== false && (x.tipo !== 'agente' || B.agenteAtivo)).map((x: any) => ({
    id: x.id, tipo: x.tipo, titulo: x.titulo, descricao: x.descricao || '',
    href: x.tipo === 'catalogo' ? B.catalogoHref : x.tipo === 'agente' ? B.agenteHref : hrefDe(x.tipo, x.valor),
    externo: !['catalogo', 'agente'].includes(x.tipo),
  }))
  return { empresa: B.empresa, categoria: B.categoria, aberto: B.aberto, situacao: B.situacao, titulo: c.titulo || B.empresa, descricao: c.descricao || B.sobre, logo: c.logo || B.logo, capa: c.capa || B.capa, tema, botoes, exibir, logoPos: logoPosDe(c.logoPos), logoTam: logoTamDe(c.logoTam) }
}
