// Identidade visual da empresa: UMA configuração central (businesses.data.tema), normalizada aqui e
// entregue igual ao catálogo, ao agente de atendimento e a qualquer tela comercial da empresa.
export type Tema = { preset: string; cor: string; fundo: 'escuro' | 'claro' | 'colorido'; layout: 'lista' | 'grade'; cantos: 'arredondado' | 'reto' }
export const TEMA_PADRAO: Tema = { preset: 'padrao', cor: '#3b6cff', fundo: 'escuro', layout: 'lista', cantos: 'arredondado' }

/** Aceita qualquer valor salvo (inclusive temas antigos incompletos) e devolve um tema sempre completo e válido. */
export function normalizeTema(t: any): Tema {
  const o = t && typeof t === 'object' ? t : {}
  return {
    preset: typeof o.preset === 'string' && /^[a-z0-9_-]{1,20}$/i.test(o.preset) ? o.preset : TEMA_PADRAO.preset,
    cor: /^#[0-9a-f]{6}$/i.test(String(o.cor)) ? String(o.cor).toLowerCase() : TEMA_PADRAO.cor,
    fundo: ['escuro', 'claro', 'colorido'].includes(o.fundo) ? o.fundo : TEMA_PADRAO.fundo,
    layout: o.layout === 'grade' ? 'grade' : 'lista',
    cantos: o.cantos === 'reto' ? 'reto' : 'arredondado',
  }
}
