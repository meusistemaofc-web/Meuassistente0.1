// Permissões de Agendamento (por empresa) — duas opções independentes, configuradas só pelo dono:
//  • pedidos  → o cliente pode AGENDAR um pedido (data e hora para preparar/entregar/retirar). Desligado = pedidos só "para agora" (como sempre foi).
//  • servicos → o agendamento de serviço vira SOLICITAÇÃO: fica "Aguardando aprovação", não confirma sozinho e (salvo reserva temporária)
//               não bloqueia o horário. Desligado = o fluxo atual de agendamento continua exatamente como antes.
// Quem pode usar cada opção: todos, só quem tem conta, ou clientes selecionados pelo dono. A aprovação pode ser delegada a funcionários.
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'
import { notify } from './notify.js'
import { audit } from './account.js'
import { diaEfetivo, calcularHorarios } from './calendar.js'

export type Publico = 'todos' | 'cadastrados' | 'selecionados'
export type Tipo = 'pedidos' | 'servicos'
export const PA_PADRAO = {
  pedidos: { ativo: false, publico: 'todos' as Publico, antecedenciaMin: 60, diasMax: 7 },
  servicos: { ativo: false, publico: 'todos' as Publico, reservaMin: 0 },
}
export const STATUS_SOLICITACAO = ['aguardando_aprovacao', 'sugestao'] as const
export const ROTULO: Record<string, string> = { aguardando_aprovacao: 'Aguardando aprovação', sugestao: 'Novo horário sugerido', aceito: 'Confirmado', recusado: 'Não aprovado', cancelado: 'Cancelado', concluido: 'Concluído' }
const PUBLICOS: Publico[] = ['todos', 'cadastrados', 'selecionados']
const ROLES = ['aprovador', 'cliente_pedidos', 'cliente_servicos'] as const
const clamp = (n: any, a: number, b: number, d: number) => { const v = Math.round(Number(n)); return Number.isFinite(v) ? Math.min(b, Math.max(a, v)) : d }

/** Configuração efetiva (com padrões). Empresas que nunca configuraram: tudo desligado → fluxos antigos. */
export function paCfg(x: any) {
  const c = x?.permAgenda || {}
  return {
    pedidos: { ...PA_PADRAO.pedidos, ...(c.pedidos || {}) },
    servicos: { ...PA_PADRAO.servicos, ...(c.servicos || {}) },
  }
}
/** Valida e normaliza o que o dono enviou (lista fechada de campos). */
export function validarCfg(inp: any) {
  const p = inp?.pedidos || {}, s = inp?.servicos || {}
  const pub = (v: any) => (PUBLICOS.includes(v) ? v : 'todos') as Publico
  return {
    pedidos: { ativo: p.ativo === true, publico: pub(p.publico), antecedenciaMin: clamp(p.antecedenciaMin, 0, 24 * 60, 60), diasMax: clamp(p.diasMax, 1, 60, 7) },
    servicos: { ativo: s.ativo === true, publico: pub(s.publico), reservaMin: clamp(s.reservaMin, 0, 48 * 60, 0) },
  }
}

/** Papel de alguém na empresa: dono, aprovador delegado ou nenhum (isolamento por empresa). */
export async function papel(b: any, userId: number | null | undefined): Promise<'dono' | 'aprovador' | null> {
  if (!userId || !b) return null
  if (Number(b.owner_id) === Number(userId)) return 'dono'
  const r = await one("SELECT 1 AS ok FROM business_permissions WHERE business_id = $1 AND user_id = $2 AND role = 'aprovador'", [Number(b.id), Number(userId)])
  if (r) return 'aprovador'
  // Lojas Conectadas: a central com acesso de ADMINISTRADOR responde às solicitações como um aprovador
  const l = await one("SELECT 1 AS ok FROM store_links WHERE business_id = $1 AND hub_user_id = $2 AND status = 'ativo' AND role = 'administrador'", [Number(b.id), Number(userId)])
  return l ? 'aprovador' : null
}
export async function pessoas(businessId: number, role: string) {
  return (await q('SELECT bp.user_id, bp.created_at, u.name, u.email, u.whatsapp FROM business_permissions bp JOIN users u ON u.id = bp.user_id WHERE bp.business_id = $1 AND bp.role = $2 ORDER BY bp.id', [businessId, role]))
    .map((r) => ({ id: Number(r.user_id), nome: r.name, contato: mascarar(r.email, r.whatsapp), desde: r.created_at }))
}
const mascarar = (email: string, zap: string) => {
  const e = String(email || ''); if (e.includes('@')) { const [a, d] = e.split('@'); return `${a.slice(0, 2)}${'•'.repeat(Math.max(1, a.length - 2))}@${d}` }
  const z = String(zap || '').replace(/\D/g, ''); return z ? `••••${z.slice(-4)}` : ''
}
/** Acha uma conta pelo e-mail ou WhatsApp (só contas existentes; nada é criado). */
export async function acharConta(contato: string) {
  const c = String(contato || '').trim(); if (!c) fail(400, 'Informe o e-mail ou o WhatsApp da pessoa.', 'invalid')
  let u: any = null
  if (c.includes('@')) u = await one('SELECT id, name, status FROM users WHERE LOWER(email) = $1', [c.toLowerCase()])
  else { const d = c.replace(/\D/g, ''); if (d.length >= 10) { for (const r of await q('SELECT id, name, status, whatsapp FROM users WHERE whatsapp LIKE $1 LIMIT 50', ['%' + d.slice(-4) + '%'])) { const w = String(r.whatsapp).replace(/\D/g, ''); if (w && (w.endsWith(d.slice(-11)) || d.endsWith(w.slice(-11)))) { u = r; break } } } }
  if (!u || u.status !== 'active') fail(404, 'Não encontramos uma conta ativa com esse contato. A pessoa precisa ter cadastro no Meu Assistente.', 'not_found')
  return { id: Number(u.id), nome: String(u.name || '') }
}
export async function adicionarPessoa(b: any, role: string, userId: number, actorId: number) {
  if (!(ROLES as readonly string[]).includes(role)) fail(400, 'Tipo de permissão inválido.', 'invalid')
  if (Number(b.owner_id) === userId) fail(400, role === 'aprovador' ? 'O dono já aprova as solicitações.' : 'O dono não faz pedidos na própria empresa.', 'invalid')
  await q('INSERT INTO business_permissions (business_id, user_id, role, created_by, created_at) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (business_id, user_id, role) DO NOTHING', [Number(b.id), userId, role, actorId, nowIso()])
  await audit(actorId, 'empresa.permissoes.adicionar', Number(b.id), { papel: role, usuario: userId })
}
export async function removerPessoa(b: any, role: string, userId: number, actorId: number) {
  await q('DELETE FROM business_permissions WHERE business_id = $1 AND user_id = $2 AND role = $3', [Number(b.id), userId, role])
  await audit(actorId, 'empresa.permissoes.remover', Number(b.id), { papel: role, usuario: userId })
}

/**
 * Quem pode usar cada opção. Para serviços com a opção desligada, devolve modo 'direto' (fluxo antigo, sem mudança).
 * Para pedidos desligados, o agendamento simplesmente não existe (pedido só para agora, como antes).
 */
export async function acesso(b: any, tipo: Tipo, userId: number | null | undefined): Promise<{ ok: boolean; modo?: 'direto' | 'solicitacao' | 'agendado'; motivo?: string; codigo?: string }> {
  const c = paCfg(J<any>(b.data, {}))[tipo]
  if (!c.ativo) return tipo === 'servicos' ? { ok: true, modo: 'direto' } : { ok: false, motivo: 'Esta empresa não recebe pedidos agendados.', codigo: 'desligado' }
  const modo = tipo === 'servicos' ? 'solicitacao' : 'agendado'
  if (c.publico === 'todos') return { ok: true, modo }
  if (!userId) return { ok: false, motivo: tipo === 'servicos' ? 'Para solicitar um horário nesta empresa, entre na sua conta do Meu Assistente.' : 'Para agendar um pedido nesta empresa, entre na sua conta do Meu Assistente.', codigo: 'precisa_conta' }
  if (c.publico === 'cadastrados') return { ok: true, modo }
  const r = await one('SELECT 1 AS ok FROM business_permissions WHERE business_id = $1 AND user_id = $2 AND role = $3', [Number(b.id), Number(userId), tipo === 'servicos' ? 'cliente_servicos' : 'cliente_pedidos'])
  return r ? { ok: true, modo } : { ok: false, motivo: tipo === 'servicos' ? 'Os agendamentos desta empresa estão disponíveis só para clientes autorizados por ela. Fale com a empresa pelo WhatsApp.' : 'O agendamento de pedidos desta empresa está disponível só para clientes autorizados por ela.', codigo: 'nao_autorizado' }
}

/* ---------- pedidos agendados ---------- */
const agoraBR = () => new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }))
const isoDia = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
/** Horários possíveis para um pedido agendado numa data: só dentro do funcionamento real do dia (calendário, feriados, intervalos), com a antecedência mínima e o limite de dias. */
export function horariosPedido(b: any, data: string): string[] {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return []
  const x = J<any>(b.data, {}), c = paCfg(x).pedidos, now = agoraBR(), hoje = isoDia(now)
  const lim = new Date(now.getTime() + c.diasMax * 86400_000), limIso = isoDia(lim)
  if (data < hoje || data > limIso) return []
  const ef = diaEfetivo(x, data); if (!ef.aberto) return []
  const minAgora = now.getHours() * 60 + now.getMinutes() + Math.max(0, c.antecedenciaMin)
  if (data === hoje && minAgora >= 24 * 60) return []
  return calcularHorarios(ef, 15, [], { passo: 30, agoraMin: data === hoje ? minAgora : null })
}
/** Datas (até o limite) em que há algum horário para pedido agendado. */
export function diasPedido(b: any): { data: string; horarios: number }[] {
  const c = paCfg(J<any>(b.data, {})).pedidos, now = agoraBR(), out: { data: string; horarios: number }[] = []
  for (let i = 0; i <= c.diasMax; i++) { const d = isoDia(new Date(now.getTime() + i * 86400_000)); const h = horariosPedido(b, d).length; if (h) out.push({ data: d, horarios: h }) }
  return out
}
/** Valida o agendamento de um pedido (data/hora dentro das regras); devolve o objeto gravado no pedido. */
export function validarAgendadoPara(b: any, a: any) {
  const data = String(a?.data || ''), hora = String(a?.hora || '')
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !/^\d{2}:\d{2}$/.test(hora)) fail(400, 'Escolha a data e o horário do pedido agendado.', 'invalid')
  if (!horariosPedido(b, data).includes(hora)) fail(400, 'Esse horário não está disponível para pedidos agendados. Escolha outro horário de funcionamento da loja.', 'slot_invalido')
  return { data, hora }
}

/* ---------- responsáveis, notificações e histórico ---------- */
export async function responsaveis(b: any): Promise<number[]> {
  const ids = [Number(b.owner_id), ...(await q("SELECT user_id FROM business_permissions WHERE business_id = $1 AND role = 'aprovador'", [Number(b.id)])).map((r) => Number(r.user_id))]
  return [...new Set(ids)]
}
export async function avisarResponsaveis(b: any, msg: { title: string; body: string; ref: string }) {
  for (const id of await responsaveis(b)) await notify(id, { type: 'order', title: msg.title, body: msg.body, link: `/x/solicitacoes?empresa=${b.id}`, ref: `${msg.ref}:${id}` })
}
/** Acrescenta um evento ao histórico do pedido (quem, quando, o quê) — complementa o audit_log. */
export function historico(d: any, evento: string, ator: string, detalhe = '') {
  d.historico = [...(Array.isArray(d.historico) ? d.historico : []), { em: nowIso(), evento, ator, ...(detalhe ? { detalhe } : {}) }].slice(-30)
  return d
}
export const brDia = (d: string) => String(d || '').split('-').reverse().join('/')
