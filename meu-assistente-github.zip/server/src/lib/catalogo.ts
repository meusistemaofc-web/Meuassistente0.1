// Ofertas e variações de produtos (cor, tamanho, modelo…), preço de destaque, linhas de pedido e estoque.
// Regras centrais usadas pelo cadastro, pela loja, pelo agente de atendimento e pelos pedidos:
// • preço aplicado = preço promocional quando a oferta está ativa (sempre > 0 e < preço normal); senão o preço normal;
// • destaque do produto = MENOR preço aplicado entre as variações DISPONÍVEIS (disponível e com estoque); a foto do destaque é
//   a da variação escolhida; sem nenhuma disponível, o produto aparece indisponível e nunca como oferta;
// • o preço do pedido é sempre recalculado aqui no servidor (o navegador só manda produto, variação, opções e quantidade);
// • o pedido guarda uma "fotografia" do item (variação, atributos, imagem, preço normal, preço aplicado, promoção) — mudar
//   preços depois não altera pedidos já feitos;
// • estoque (quando controlado) é debitado de forma atômica (UPDATE … WHERE stock >= qtd) e devolvido uma única vez.
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from './http.js'
import { createHash } from 'node:crypto'

export const MAX_VARIANTES = 40, MAX_FOTOS_VAR = 4, ATRIBUTOS = [['cor', 'Cor'], ['tamanho', 'Tamanho'], ['modelo', 'Modelo']] as const
const r2 = (n: number) => Math.round(n * 100) / 100
const s = (v: any, n: number) => String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n)
const nrm = (v: any) => String(v ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()

/** Preço normal, preço aplicado, se está em oferta e o percentual de desconto (inteiro). */
export function precos(normal: number, oferta: any) {
  const n = r2(Number(normal) || 0), pr = oferta && oferta.ativo ? r2(Number(oferta.preco) || 0) : 0
  const em = pr > 0 && pr < n
  return { normal: n, aplicado: em ? pr : n, emOferta: em, desconto: em ? Math.round((1 - pr / n) * 100) : 0 }
}
/** Valida a oferta enviada pelo formulário (null = sem oferta). */
export function validarOferta(normal: number, o: any, rotulo = ''): { ativo: true; preco: number } | null {
  if (!o || !o.ativo) return null
  const pr = r2(Number(o.preco))
  if (!(pr > 0)) fail(400, `${rotulo}Informe o preço promocional (maior que zero).`, 'invalid', 'oferta')
  if (!(pr < r2(Number(normal) || 0))) fail(400, `${rotulo}O preço promocional deve ser menor que o preço normal.`, 'invalid', 'oferta')
  return { ativo: true, preco: pr }
}
const estoqueIn = (v: any) => { if (v === null || v === undefined || v === '') return null; const n = Math.floor(Number(v)); if (!(n >= 0 && n <= 1_000_000)) fail(400, 'Estoque inválido: use um número inteiro (0 ou mais) ou deixe em branco para não controlar.', 'invalid', 'estoque'); return n }
export { estoqueIn as validarEstoque }

export interface Variante { id: number; nome: string; cor: string; tamanho: string; modelo: string; fotos: string[]; thumb: string | null; preco: number; oferta: { ativo: boolean; preco: number } | null; disponivel: boolean; estoque: number | null; ordem: number }
const varOut = (r: any): Variante => { const d = J<any>(r.data, {}); return { id: Number(r.id), nome: d.nome || '', cor: d.cor || '', tamanho: d.tamanho || '', modelo: d.modelo || '', fotos: Array.isArray(d.fotos) ? d.fotos : [], thumb: d.thumb || null, preco: Number(d.preco) || 0, oferta: d.oferta || null, disponivel: d.disponivel !== false, estoque: r.stock == null ? null : Number(r.stock), ordem: Number(r.position) || 0 } }
export const rotuloVariante = (v: { nome?: string; cor?: string; tamanho?: string; modelo?: string }) => v.nome || [v.cor, v.tamanho, v.modelo].filter(Boolean).join(' · ')
export const atributosDe = (v: any) => ATRIBUTOS.filter(([k]) => v[k]).map(([k, l]) => ({ chave: k, nome: l, valor: v[k] as string }))
const temEstoque = (e: number | null, qtd = 1) => e == null || e >= qtd

/** Variações de vários produtos numa consulta só. */
export async function variantesDe(ids: number[]): Promise<Map<number, Variante[]>> {
  const m = new Map<number, Variante[]>(); if (!ids.length) return m
  const rows = await q(`SELECT * FROM product_variants WHERE product_id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY product_id, position, id`, ids)
  for (const r of rows as any[]) { const k = Number(r.product_id); m.set(k, [...(m.get(k) || []), varOut(r)]) }
  return m
}
/** Visão pública de uma variação (sem o número exato do estoque: só "últimas unidades" quando está acabando). */
function varPublica(v: Variante, dono: boolean) {
  const p = precos(v.preco, v.oferta), disp = v.disponivel && temEstoque(v.estoque)
  return { id: v.id, nome: v.nome, rotulo: rotuloVariante(v), cor: v.cor, tamanho: v.tamanho, modelo: v.modelo, atributos: atributosDe(v), fotos: v.fotos, thumb: v.thumb,
    preco: p.normal, precoAplicado: p.aplicado, emOferta: p.emOferta && disp, ofertaCadastrada: p.emOferta, desconto: p.desconto, oferta: v.oferta, disponivel: disp, ativa: v.disponivel,
    ...(dono ? { estoque: v.estoque } : { restantes: v.estoque != null && v.estoque > 0 && v.estoque <= 5 ? v.estoque : null }), esgotada: v.estoque === 0 }
}
/** Acrescenta ao produto: oferta calculada, variações (públicas ou do dono), destaque (menor preço disponível) e disponibilidade. */
export function comCatalogo(p: any, vars: Variante[] | undefined, estoqueProduto: number | null, dono = false) {
  const lista = (vars || []).map((v) => varPublica(v, dono))
  if (!lista.length) {
    const pr = p.tipo === 'servico' ? precos(p.preco, null) : precos(p.preco, p.oferta), disp = temEstoque(estoqueProduto)
    return { ...p, variantes: [], ...(dono ? { estoque: estoqueProduto } : { restantes: estoqueProduto != null && estoqueProduto > 0 && estoqueProduto <= 5 ? estoqueProduto : null }), esgotado: !disp,
      destaque: { preco: pr.aplicado, precoNormal: pr.normal, emOferta: pr.emOferta && disp, desconto: pr.desconto, aPartirDe: false, foto: (p.fotos || [])[0] || null, varianteId: null, disponivel: disp } }
  }
  const disp = lista.filter((v) => v.disponivel)
  const base = disp.length ? disp : lista
  const menor = base.reduce((a, v) => ((disp.length ? v.precoAplicado : v.preco) < (disp.length ? a.precoAplicado : a.preco) ? v : a), base[0])
  const precosDisp = new Set(disp.map((v) => v.precoAplicado))
  return { ...p, variantes: lista, esgotado: !disp.length,
    destaque: { preco: disp.length ? menor.precoAplicado : menor.preco, precoNormal: menor.preco, emOferta: !!disp.length && menor.emOferta, desconto: disp.length && menor.emOferta ? menor.desconto : 0,
      aPartirDe: precosDisp.size > 1, foto: menor.fotos[0] || (p.fotos || [])[0] || null, varianteId: menor.id, disponivel: !!disp.length } }
}
/** Enriquece linhas de `products` (já passadas por productOut) com variações, ofertas e destaque. */
export async function enriquecer(prods: any[], dono = false): Promise<any[]> {
  if (!prods.length) return prods
  const ids = prods.map((p) => Number(p.id)), vm = await variantesDe(ids)
  const st = new Map((await q(`SELECT id, stock FROM products WHERE id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids) as any[]).map((r) => [Number(r.id), r.stock == null ? null : Number(r.stock)]))
  return prods.map((p) => comCatalogo(p, vm.get(Number(p.id)), st.get(Number(p.id)) ?? null, dono))
}

/* ---------- cadastro ---------- */
/** Normaliza e valida as variações enviadas pelo formulário. Fotos já salvas podem vir como "keep:<id>:<índice>" (não reenviadas). */
export async function prepararVariantes(productId: number | null, lista: any[], businessId?: number): Promise<{ id: number | null; data: any; stock: number | null; position: number }[]> {
  if (!Array.isArray(lista)) return []
  if (lista.length > MAX_VARIANTES) fail(400, `Um produto pode ter até ${MAX_VARIANTES} variações.`, 'invalid', 'variantes')
  const atuais = productId ? (await variantesDe([productId])).get(productId) || [] : []
  const porId = new Map(atuais.map((v) => [v.id, v])), vistas = new Set<string>()
  // fotos de OUTRO item da mesma empresa (duplicar produto): "keep:<id>:<n>" vale para variações da própria empresa
  const outras = [...new Set(lista.flatMap((v: any) => (Array.isArray(v?.fotos) ? v.fotos : []).map((f: any) => (typeof f === 'string' ? f.match(/^keep:(\d+):\d+$/) : null)).filter(Boolean).map((m: any) => Number(m[1]))))].filter((id) => !porId.has(id))
  if (outras.length && businessId) for (const r of await q(`SELECT * FROM product_variants WHERE business_id = $1 AND id IN (${outras.map((_, i) => '$' + (i + 2)).join(',')})`, [businessId, ...outras]) as any[]) { const v = varOut(r); porId.set(v.id, v) }
  return lista.map((v: any, i: number) => {
    const n = i + 1, rot = `Variação ${n}: `
    const nome = s(v.nome, 60), cor = s(v.cor, 40), tamanho = s(v.tamanho, 40), modelo = s(v.modelo, 60)
    if (!nome && !cor && !tamanho && !modelo) fail(400, `${rot}informe um nome ou pelo menos uma característica (cor, tamanho ou modelo).`, 'invalid', 'variantes')
    const chave = [nome, cor, tamanho, modelo].map(nrm).join('|'); if (vistas.has(chave)) fail(400, `${rot}já existe outra variação igual (${rotuloVariante({ nome, cor, tamanho, modelo })}).`, 'invalid', 'variantes'); vistas.add(chave)
    const preco = r2(Number(v.preco)); if (!(preco > 0 && preco < 1e6)) fail(400, `${rot}informe um preço válido (maior que zero).`, 'invalid', 'variantes')
    const oferta = validarOferta(preco, v.oferta, rot)
    const id = Number(v.id) > 0 && atuais.some((x) => x.id === Number(v.id)) ? Number(v.id) : null, antes = id ? porId.get(id)! : null
    const fotos: string[] = []; let thumbOrigem: string | null = null
    for (const f of Array.isArray(v.fotos) ? v.fotos : []) {
      if (typeof f !== 'string') continue
      const k = f.match(/^keep:(\d+):(\d+)$/)
      if (k) { const src = porId.get(Number(k[1])); const ff = src?.fotos[Number(k[2])]; if (ff) { if (!fotos.length && Number(k[2]) === 0) thumbOrigem = src!.thumb; fotos.push(ff) } continue }
      if (!f.startsWith('data:image/')) continue
      if (f.length >= 900_000) fail(400, `${rot}uma das fotos é muito grande. Escolha uma imagem menor (até ~600 KB).`, 'too_large', 'variantes')
      fotos.push(f)
    }
    if (fotos.length > MAX_FOTOS_VAR) fail(400, `${rot}use até ${MAX_FOTOS_VAR} fotos por variação.`, 'invalid', 'variantes')
    let thumb = typeof v.thumb === 'string' && v.thumb.startsWith('data:image/') && v.thumb.length < 40_000 ? v.thumb : null
    if (!thumb && antes && antes.fotos[0] === fotos[0]) thumb = antes.thumb // mesma foto principal: mantém a miniatura
    if (!thumb && thumbOrigem) thumb = thumbOrigem // foto principal reaproveitada (ex.: produto duplicado)
    if (!fotos.length) thumb = null
    return { id, position: i, stock: estoqueIn(v.estoque), data: { nome, cor, tamanho, modelo, fotos, thumb, preco, oferta, disponivel: v.disponivel !== false } }
  })
}
/** Grava as variações do produto: atualiza as existentes, cria as novas e remove as que saíram (pedidos antigos guardam a própria cópia). */
export async function gravarVariantes(dq: { query: (sql: string, p?: unknown[]) => Promise<any[]> }, productId: number, businessId: number, vs: Awaited<ReturnType<typeof prepararVariantes>>) {
  const now = nowIso(), manter: number[] = []
  for (const v of vs) {
    if (v.id) { await dq.query('UPDATE product_variants SET data = $1, stock = $2, position = $3, updated_at = $4 WHERE id = $5 AND product_id = $6', [JSON.stringify(v.data), v.stock, v.position, now, v.id, productId]); manter.push(v.id) }
    else { const r = await dq.query('INSERT INTO product_variants (product_id, business_id, position, data, stock, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6) RETURNING id', [productId, businessId, v.position, JSON.stringify(v.data), v.stock, now]); manter.push(Number(r[0].id)) }
  }
  const atuais = await dq.query('SELECT id FROM product_variants WHERE product_id = $1', [productId])
  for (const r of atuais) if (!manter.includes(Number(r.id))) await dq.query('DELETE FROM product_variants WHERE id = $1 AND product_id = $2', [Number(r.id), productId])
}

/* ---------- pedido ---------- */
/** Uma linha do pedido com o preço de AGORA, calculado no servidor. `unitPrice` aplica as opções/adicionais antigos sobre a base. */
/* ---------- Imagem dos itens do pedido ----------
   O pedido guarda só uma REFERÊNCIA estável da foto usada no momento da compra (`fotoRef`: impressão digital curta do arquivo),
   nunca uma cópia da imagem. A foto é buscada no cadastro do próprio item (produto/serviço da mesma empresa, variação escolhida):
   1) a foto com a mesma impressão digital (continua certa se o lojista reordenar fotos ou trocar a foto principal);
   2) se ela foi removida do cadastro: a miniatura gravada no pedido (pedidos de variação já guardavam) ou a foto atual do MESMO item;
   3) item apagado ou sem foto: nenhuma (o painel mostra um espaço reservado). Nunca usa foto de outro item. */
export const refFoto = (src: any): string | null => { const v = String(src || ''); return v ? createHash('sha256').update(v).digest('hex').slice(0, 16) : null }
type ItemFoto = { pid: number | null; vid: number | null; ref: string | null; salva: string | null }
/** Item `idx` do pedido → produto/serviço, variação e referência da foto (pedidos antigos sem referência também funcionam). */
export function itemFotoDe(d: any, idx: number): ItemFoto | null {
  const it = (d?.itens || [])[idx]; if (!it) return null
  if (d.tipo === 'agendamento') return { pid: Number(d.servicoId) || null, vid: null, ref: d.servicoFotoRef || null, salva: null }
  return { pid: Number(it.pid) || null, vid: it.varianteId != null ? Number(it.varianteId) : null, ref: it.fotoRef || null, salva: typeof it.foto === 'string' && it.foto ? it.foto : null }
}
/** Carrega, de uma vez, as fotos cadastradas dos itens citados nos pedidos (só itens da MESMA empresa de cada pedido). */
export async function fotosDosItens(pedidos: { business_id: any; data: any }[]) {
  const ids = new Set<number>()
  for (const o of pedidos) { const d = J<any>(o.data, {}); (d.itens || []).forEach((_: any, i: number) => { const f = itemFotoDe(d, i); if (f?.pid) ids.add(f.pid) }) }
  const prods = new Map<number, { bid: number; fotos: string[] }>(), lista = [...ids]
  if (lista.length) for (const r of await q(`SELECT id, business_id, data FROM products WHERE id IN (${lista.map((_, i) => '$' + (i + 1)).join(',')})`, lista) as any[]) prods.set(Number(r.id), { bid: Number(r.business_id), fotos: (J<any>(r.data, {}).fotos || []).filter(Boolean) })
  const vars = lista.length ? await variantesDe(lista) : new Map<number, Variante[]>()
  return { prods, vars }
}
/** A foto certa do item `idx` do pedido (ou null). */
export function fotoDoItem(o: { business_id: any; data: any }, idx: number, cache: Awaited<ReturnType<typeof fotosDosItens>>): string | null {
  const d = J<any>(o.data, {}), f = itemFotoDe(d, idx); if (!f) return null
  const p = f.pid ? cache.prods.get(f.pid) : null
  if (!p || p.bid !== Number(o.business_id)) return f.salva // item apagado (ou de outra empresa): só o que o pedido já guardava
  const vs = cache.vars.get(f.pid!) || [], v = f.vid != null ? vs.find((x) => Number(x.id) === f.vid) : null
  const daVar = v ? [...v.fotos, v.thumb].filter(Boolean) as string[] : []
  const todas = [...daVar, ...p.fotos, ...vs.filter((x) => x !== v).flatMap((x) => [...x.fotos, x.thumb].filter(Boolean) as string[])]
  if (f.ref) { const igual = todas.find((x) => refFoto(x) === f.ref); if (igual) return igual }
  return f.salva || daVar[0] || p.fotos[0] || null
}
/** Foto principal no momento do pedido (para a referência estável). */
export const fotoAtual = (p: any, v?: any) => (v && ((v.fotos || [])[0] || v.thumb)) || (p?.fotos || [])[0] || null

export function linhaPedido(p: any, it: { vid?: any; variante?: any; escolhas?: Record<string, number>; qtd: number; obs?: string }, unitPrice: (prod: any, esc: Record<string, number>, base?: number) => number) {
  const qtd = it.qtd, vars0 = (p.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[Number(it.escolhas?.[v.nome] ?? 0)]?.nome ?? ''}`)
  const vs: any[] = p.variantes || []
  if (vs.length) {
    let v = vs.find((x) => Number(x.id) === Number(it.vid))
    if (!v && it.variante) { const w = nrm(it.variante); v = vs.find((x) => nrm(x.rotulo) === w || nrm(x.nome) === w) }
    if (!v) fail(400, `Escolha a opção de ${p.nome} (${vs.filter((x) => x.disponivel).map((x) => x.rotulo).join(', ') || 'nenhuma disponível'}).`, 'variante_obrigatoria')
    if (!v.disponivel) fail(409, `${p.nome} · ${v.rotulo} está indisponível no momento.`, 'indisponivel')
    const lim = (p.__estoqueVar || {})[v.id]; if (lim != null && lim < qtd) fail(409, `${p.nome} · ${v.rotulo}: só ${lim === 1 ? 'resta 1 unidade' : `restam ${lim} unidades`}.`, 'sem_estoque')
    const preco = unitPrice(p, it.escolhas || {}, v.precoAplicado), precoNormal = unitPrice(p, it.escolhas || {}, v.preco)
    return { pid: Number(p.id), nome: p.nome, varianteId: v.id, variante: v.rotulo, atributos: v.atributos.map((a: any) => ({ nome: a.nome, valor: a.valor })), foto: v.thumb || null, fotoRef: refFoto(fotoAtual(p, v)),
      vars: [...v.atributos.map((a: any) => `${a.nome}: ${a.valor}`), ...(v.nome && v.atributos.length ? [v.nome] : !v.atributos.length ? [v.rotulo] : []), ...vars0], obs: s(it.obs, 140), qtd, precoNormal, preco,
      promocao: v.emOferta ? { tipo: 'oferta', escopo: 'variacao', varianteId: v.id, precoNormal: v.preco, precoPromocional: v.precoAplicado, desconto: v.desconto } : null }
  }
  if (p.esgotado) fail(409, `${p.nome} está esgotado no momento.`, 'sem_estoque')
  const lim = p.__estoque; if (lim != null && lim < qtd) fail(409, `${p.nome}: só ${lim === 1 ? 'resta 1 unidade' : `restam ${lim} unidades`}.`, 'sem_estoque')
  const pr = precos(p.preco, p.oferta)
  const preco = unitPrice(p, it.escolhas || {}, pr.emOferta ? pr.aplicado : undefined), precoNormal = unitPrice(p, it.escolhas || {})
  return { pid: Number(p.id), nome: p.nome, fotoRef: refFoto(fotoAtual(p)), vars: vars0, obs: s(it.obs, 140), qtd, precoNormal, preco,
    promocao: pr.emOferta ? { tipo: 'oferta', escopo: 'produto', precoNormal: pr.normal, precoPromocional: pr.aplicado, desconto: pr.desconto } : null }
}
/** Carrega os produtos ativos da empresa com variações e o estoque exato (só para cálculo interno do pedido). */
export async function produtosParaPedido(businessId: number, productOut: (r: any) => any) {
  const rows = await q('SELECT * FROM products WHERE business_id = $1 AND active = $2', [businessId, true]) as any[]
  const prods = await enriquecer(rows.map(productOut), true)
  for (const p of prods) { p.__estoque = p.estoque ?? null; p.__estoqueVar = Object.fromEntries((p.variantes || []).map((v: any) => [v.id, v.estoque ?? null])) }
  return new Map(prods.map((p) => [Number(p.id), p]))
}

/** Débito atômico do estoque das linhas (quem controla estoque). Se faltar em qualquer item, devolve o que já debitou e recusa. */
export async function reservarEstoque(linhas: any[]): Promise<{ tipo: 'v' | 'p'; id: number; qtd: number }[]> {
  const somas = new Map<string, { tipo: 'v' | 'p'; id: number; qtd: number; nome: string }>()
  for (const l of linhas) { const k = l.varianteId ? `v${l.varianteId}` : `p${l.pid}`; const e = somas.get(k) || { tipo: l.varianteId ? 'v' as const : 'p' as const, id: Number(l.varianteId || l.pid), qtd: 0, nome: l.variante ? `${l.nome} · ${l.variante}` : l.nome }; e.qtd += l.qtd; somas.set(k, e) }
  const feitas: { tipo: 'v' | 'p'; id: number; qtd: number }[] = []
  for (const e of somas.values()) {
    const tab = e.tipo === 'v' ? 'product_variants' : 'products'
    const ctl = await one(`SELECT stock FROM ${tab} WHERE id = $1`, [e.id]); if (!ctl || ctl.stock == null) continue // não controla estoque
    const r = await q(`UPDATE ${tab} SET stock = stock - $1 WHERE id = $2 AND stock IS NOT NULL AND stock >= $1 RETURNING stock`, [e.qtd, e.id])
    if (!r.length) { await devolverEstoque(feitas); const ag = await one(`SELECT stock FROM ${tab} WHERE id = $1`, [e.id]); const n = Number(ag?.stock) || 0; fail(409, n > 0 ? `${e.nome}: só ${n === 1 ? 'resta 1 unidade' : `restam ${n} unidades`}.` : `${e.nome} esgotou.`, 'sem_estoque') }
    feitas.push({ tipo: e.tipo, id: e.id, qtd: e.qtd })
  }
  return feitas
}
export async function devolverEstoque(res: { tipo: 'v' | 'p'; id: number; qtd: number }[]) {
  for (const e of res || []) await q(`UPDATE ${e.tipo === 'v' ? 'product_variants' : 'products'} SET stock = stock + $1 WHERE id = $2 AND stock IS NOT NULL`, [e.qtd, e.id])
}
/** Devolve o estoque reservado por um pedido (cancelado, recusado ou Pix não pago). Idempotente: marca o pedido. */
export async function devolverPedido(orderId: number) {
  const o = await one('SELECT data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const d = J<any>(o.data, {}); if (!Array.isArray(d.estoque) || !d.estoque.length || d.estoqueDevolvido) return
  // marca primeiro (condicional) para nunca devolver duas vezes em chamadas simultâneas
  const marcado = { ...d, estoqueDevolvido: nowIso() }
  const r = await q('UPDATE orders SET data = $1 WHERE id = $2 AND data = $3 RETURNING id', [JSON.stringify(marcado), orderId, typeof o.data === 'string' ? o.data : JSON.stringify(o.data)])
  if (!r.length) return
  await devolverEstoque(d.estoque)
}
/** Pix pago depois que a reserva foi devolvida: debita de novo (sem deixar negativo — a venda já está paga). */
export async function retomarPedido(orderId: number) {
  const o = await one('SELECT data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const d = J<any>(o.data, {}); if (!d.estoqueDevolvido || !Array.isArray(d.estoque)) return
  delete d.estoqueDevolvido
  await q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(d), orderId])
  for (const e of d.estoque) await q(`UPDATE ${e.tipo === 'v' ? 'product_variants' : 'products'} SET stock = CASE WHEN stock >= $1 THEN stock - $1 ELSE 0 END WHERE id = $2 AND stock IS NOT NULL`, [e.qtd, e.id])
}
