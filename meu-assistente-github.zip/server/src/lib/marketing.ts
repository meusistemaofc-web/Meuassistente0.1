// Acompanhamento de convites + Central de Marketing.
// Permissões em 3 níveis, conferidas no servidor a cada operação: (1) administrador liga/desliga a Central para todas as
// empresas (mkt_global); (2) o proprietário liga/desliga para a própria empresa (mkt_empresa); (3) o sistema confere
// plano, autorização dos clientes e limites antes de programar e antes de cada envio. Desligar suspende, nunca apaga.
// Regras: lembrete ativado NUNCA é consentimento de marketing; consentimento é separado, opcional, com data e origem,
// revogável a qualquer momento. Cada dono só vê e alcança quem autorizou A ELE. Limites vêm do plano da empresa
// (editáveis no painel) e são conferidos no servidor a cada criação e a cada envio.
import { createHmac } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig } from './settings.js'
import { notify } from './notify.js'
import { pub } from './publicurl.js'
import { fail } from './http.js'
import { validTz, zonedToUtc } from './time.js'

export const MKT_DEFAULT: Record<string, any> = {
  _sem_plano: { acesso: false, campanhasPeriodo: 0, notificacoesPeriodo: 0, agendar: false, segmentacao: false, relatorios: false },
  n1: { acesso: false, campanhasPeriodo: 0, notificacoesPeriodo: 0, agendar: false, segmentacao: false, relatorios: false },
  n2: { acesso: true, campanhasPeriodo: 1, notificacoesPeriodo: 100, agendar: false, segmentacao: false, relatorios: false },
  n3: { acesso: true, campanhasPeriodo: 4, notificacoesPeriodo: 500, agendar: true, segmentacao: true, relatorios: true },
  n4: { acesso: true, campanhasPeriodo: 15, notificacoesPeriodo: 3000, agendar: true, segmentacao: true, relatorios: true },
}
export async function mktOn() { return (await getConfig<any>('mkt_global', {})).ativo !== false }
export async function mktPlans() { return { ...MKT_DEFAULT, ...(await getConfig<any>('mkt_plans', {})) } }
const sig = (s: string) => createHmac('sha256', process.env.SETTINGS_KEY || process.env.SESSION_SECRET || 'meu-assistente-mkt').update(s).digest('hex').slice(0, 20)

/* ---------- acompanhamento ---------- */
export async function recordActivation(token: string, ownerId: number, ownerItemId: number, guestId: number, guestItemId: number, shareCreatedAt: string) {
  const g = await one('SELECT created_at FROM users WHERE id = $1', [guestId])
  const novo = !!g && Date.parse(g.created_at) >= Date.parse(shareCreatedAt || '1970-01-01') // conta criada depois do convite
  try { await q('INSERT INTO invite_activations (token, owner_id, owner_item_id, guest_id, guest_item_id, conta_nova, ativado_em) VALUES ($1,$2,$3,$4,$5,$6,$7)', [token, ownerId, ownerItemId, guestId, guestItemId, novo, nowIso()]) } catch { /* já registrado */ }
}
/** O que o dono vê dentro do compromisso: só dados do próprio convite e do consentimento dado a ele. */
export async function trackingOf(ownerId: number, itemId: number) {
  const it = await one("SELECT id, status, data FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [itemId, ownerId]); if (!it) return null
  const d = J<any>(it.data, {})
  const acts = await q('SELECT a.*, u.name FROM invite_activations a JOIN users u ON u.id = a.guest_id WHERE a.owner_id = $1 AND a.owner_item_id = $2 ORDER BY a.ativado_em', [ownerId, itemId])
  const out = []
  for (const a of acts) {
    const c = await one('SELECT status, criado_em, revogado_em, origem FROM marketing_consents WHERE owner_id = $1 AND user_id = $2', [ownerId, a.guest_id])
    const gi = a.guest_item_id ? await one('SELECT status FROM items WHERE id = $1', [a.guest_item_id]) : null
    out.push({ nome: String(a.name || '').split(' ')[0] + (String(a.name || '').split(' ')[1] ? ' ' + String(a.name).split(' ')[1][0] + '.' : ''), criouConta: !!a.conta_nova, contaExistente: !a.conta_nova, lembreteAtivo: !!gi && gi.status !== 'cancelled', ativadoEm: a.ativado_em, marketing: c ? { status: c.status, desde: c.criado_em, revogadoEm: c.revogado_em, origem: c.origem } : { status: 'nao_autorizado' } })
  }
  return { compromisso: { id: Number(it.id), titulo: d.title, situacao: it.status === 'cancelled' ? 'cancelado' : it.status === 'done' ? 'concluido' : 'agendado' }, compartilhado: !!d.shareToken, convidados: out }
}
/* ---------- consentimento ---------- */
export async function setConsent(ownerId: number, userId: number, aceito: boolean, origem: string) {
  if (ownerId === userId) return { status: 'proprio' }
  const ex = await one('SELECT id, status FROM marketing_consents WHERE owner_id = $1 AND user_id = $2', [ownerId, userId])
  if (aceito) { if (ex) await q("UPDATE marketing_consents SET status = 'ativo', origem = $1, criado_em = $2, revogado_em = NULL WHERE id = $3", [origem.slice(0, 80), nowIso(), ex.id]); else await q("INSERT INTO marketing_consents (owner_id, user_id, status, origem, criado_em) VALUES ($1,$2,'ativo',$3,$4)", [ownerId, userId, origem.slice(0, 80), nowIso()]) }
  else if (ex) await q("UPDATE marketing_consents SET status = 'revogado', revogado_em = $1 WHERE id = $2", [nowIso(), ex.id])
  return { status: aceito ? 'ativo' : 'revogado' }
}
export const unsubLink = (ownerId: number, userId: number) => `${pub()}/api/v2/marketing/sair?o=${ownerId}&u=${userId}&s=${sig(`sair:${ownerId}:${userId}`)}`
export const checkUnsub = (o: number, u: number, s: string) => s === sig(`sair:${o}:${u}`)

export async function systemAudience() {
  return (await q("SELECT id, settings FROM users WHERE status = 'active'")).filter((u: any) => { const st = J<any>(u.settings, {}); return st.notificationsEnabled !== false && st.promoSistemaOptOut !== true }).map((u: any) => Number(u.id))
}
export async function createSystemCampaign(adminId: number, b: any) {
  const titulo = String(b.titulo || '').trim().slice(0, 80), mensagem = String(b.mensagem || '').trim().slice(0, 500)
  if (titulo.length < 3 || mensagem.length < 5) fail(400, 'Escreva o título e a mensagem.', 'invalid')
  const link = /^https?:\/\//.test(String(b.link || '')) || /^\/[\w/?=&.-]*$/.test(String(b.link || '')) ? String(b.link).slice(0, 300) : ''
  let quando = new Date(); if (b.agendarPara) { quando = new Date(b.agendarPara); if (isNaN(quando.getTime()) || quando.getTime() < Date.now() - 60_000) fail(400, 'Escolha uma data e hora futuras.', 'invalid') }
  const total = (await systemAudience()).length; if (!total) fail(400, 'Nenhum usuário com notificações ativas.', 'no_audience')
  await q('INSERT INTO mkt_campaigns (owner_id, business_id, titulo, mensagem, link, segmento, status, agendada_para, total, criada_em) VALUES ($1,NULL,$2,$3,$4,$5,$6,$7,$8,$9)', [adminId, titulo, mensagem, link, JSON.stringify({ sistema: true }), 'agendada', quando.toISOString(), total, nowIso()])
  const c = await one('SELECT * FROM mkt_campaigns WHERE owner_id = $1 ORDER BY id DESC LIMIT 1', [adminId])
  if (quando.getTime() <= Date.now() + 5000) void runCampaigns().catch((e) => console.error('[marketing]', e?.message))
  return c
}
/* ---------- permissões (3 níveis) ---------- */
const iso = (x: any) => (x ? new Date(x).toISOString() : null)
const tzDono = async (ownerId: number) => validTz(J<any>((await one('SELECT settings FROM users WHERE id = $1', [ownerId]))?.settings, {}).timezone)
/** Empresa aprovada (anúncio no ar) do proprietário. */
export async function empresaDo(ownerId: number) {
  const b = await one("SELECT * FROM businesses WHERE owner_id = $1 AND status = 'ativo' ORDER BY id DESC LIMIT 1", [ownerId])
  return b && (!b.expires_at || Date.parse(b.expires_at) > Date.now()) ? b : null
}
/** 2º nível: a empresa ligou a Central para os próprios clientes? (padrão: desligada) */
export async function empresaAtiva(businessId: number) { const r = await one('SELECT ativo FROM mkt_empresa WHERE business_id = $1', [businessId]); return !!r && !!r.ativo && r.ativo !== '0' }
export async function auditar(a: { businessId?: number | null; campaignId?: number | null; userId?: number | null; acao: string; detalhe?: any }) {
  await q('INSERT INTO mkt_auditoria (business_id, campaign_id, user_id, acao, detalhe, criado_em) VALUES ($1,$2,$3,$4,$5,$6)', [a.businessId ?? null, a.campaignId ?? null, a.userId ?? null, a.acao, a.detalhe == null ? null : typeof a.detalhe === 'string' ? a.detalhe : JSON.stringify(a.detalhe), nowIso()]).catch((e) => console.error('[marketing auditoria]', e?.message))
}

/* ---------- plano, período e consumo (sempre calculados no servidor) ---------- */
export async function ownerPlan(ownerId: number) {
  const b = await empresaDo(ownerId)
  const P = await mktPlans(), pid = b ? String(b.plan_id) : '_sem_plano'
  const lim = { ...MKT_DEFAULT._sem_plano, ...(P[pid] || P._sem_plano) }
  const administrador = await mktOn(), plano = !!lim.acesso
  if (!administrador) lim.acesso = false // desligada pelo administrador para todas as empresas
  const ads: any[] = await getConfig<any[]>('ad_plans', []), planoCfg = ads.find((x) => x.id === pid)
  const dias = Number(planoCfg?.dias) || 30, fim = b?.expires_at ? Date.parse(b.expires_at) : Date.now() + 30 * 86400_000
  const inicio = new Date(Math.min(Date.now(), fim - dias * 86400_000)).toISOString()
  const camp = Number((await q("SELECT COUNT(*) AS n FROM mkt_campaigns WHERE owner_id = $1 AND business_id IS NOT NULL AND criada_em >= $2 AND status NOT IN ('cancelada', 'rascunho')", [ownerId, inicio]))[0].n)
  const notif = Number((await q("SELECT COUNT(*) AS n FROM mkt_sends WHERE owner_id = $1 AND criado_em >= $2 AND status = 'enviado'", [ownerId, inicio]))[0].n)
  const empresa = b ? await empresaAtiva(Number(b.id)) : false
  return { business: b ? { id: Number(b.id), empresa: J<any>(b.data, {}).empresa, planId: pid } : null, limites: lim, periodo: { inicio, fim: new Date(fim).toISOString() }, uso: { campanhas: camp, notificacoes: notif },
    permissoes: { administrador, plano, empresa, podeUsar: administrador && plano && !!b && empresa } }
}
const upgrade = (msg: string) => fail(402, `${msg} Faça upgrade do plano da sua empresa para liberar mais.`, 'plan_limit')
/** Confere os 3 níveis antes de programar/validar. */
function exigirPermissoes(pl: Awaited<ReturnType<typeof ownerPlan>>) {
  if (!pl.permissoes.administrador) fail(403, 'A Central de Marketing está desativada pelo administrador. Suas campanhas e dados continuam guardados.', 'mkt_off')
  if (!pl.business) fail(403, 'É preciso ter uma empresa aprovada para usar a Central de Marketing.', 'no_business')
  if (!pl.permissoes.plano) upgrade('A Central de Marketing não está disponível no plano atual.')
  if (!pl.permissoes.empresa) fail(403, 'Ative “Ativar campanhas de marketing para meus clientes” para criar e programar campanhas.', 'mkt_empresa_off')
}

/* ---------- suspensão (desligar nunca apaga; reativar exige validar cada campanha) ---------- */
const MOTIVO: Record<string, string> = { administrador: 'Suspensa: a Central de Marketing foi desativada pelo administrador. Valide a campanha para retomar.', empresa: 'Suspensa: as campanhas da empresa foram desativadas. Valide a campanha para retomar.', plano: 'Suspensa: o plano atual não inclui a Central de Marketing. Valide a campanha depois de regularizar o plano.' }
async function suspender(where: string, params: unknown[], motivo: keyof typeof MOTIVO) {
  const rows = await q(`UPDATE mkt_campaigns SET status = 'suspensa', suspensa_por = $${params.length + 1}, erro = $${params.length + 2}, trava_ate = NULL, atualizada_em = $${params.length + 3} WHERE business_id IS NOT NULL AND status IN ('agendada', 'enviando') AND ${where} RETURNING id, business_id`, [...params, motivo, MOTIVO[motivo], nowIso()])
  for (const r of rows) await auditar({ businessId: Number(r.business_id), campaignId: Number(r.id), acao: 'suspensa', detalhe: { motivo } })
  return rows.length
}
/** Mantém o estado das campanhas coerente com as chaves do administrador e das empresas. Idempotente. */
export async function sincronizarSuspensoes() {
  if (!(await mktOn())) return suspender('1 = 1', [], 'administrador')
  return suspender('business_id NOT IN (SELECT business_id FROM mkt_empresa WHERE ativo = TRUE)', [], 'empresa')
}
/** 2º nível: o proprietário liga/desliga a Central para a própria empresa. */
export async function definirEmpresaAtiva(ownerId: number, ativo: boolean) {
  const pl = await ownerPlan(ownerId)
  if (!pl.business) fail(403, 'É preciso ter uma empresa aprovada para usar a Central de Marketing.', 'no_business')
  if (ativo) { if (!pl.permissoes.administrador) fail(403, 'A Central de Marketing está desativada pelo administrador.', 'mkt_off'); if (!pl.permissoes.plano) upgrade('A Central de Marketing não está disponível no plano atual.') }
  const bid = pl.business.id
  if (await one('SELECT business_id FROM mkt_empresa WHERE business_id = $1', [bid])) await q('UPDATE mkt_empresa SET ativo = $1, atualizado_em = $2 WHERE business_id = $3', [ativo, nowIso(), bid])
  else await q('INSERT INTO mkt_empresa (business_id, owner_id, ativo, atualizado_em) VALUES ($1,$2,$3,$4)', [bid, ownerId, ativo, nowIso()])
  await auditar({ businessId: bid, userId: ownerId, acao: ativo ? 'empresa_ativou' : 'empresa_desativou' })
  const suspensas = ativo ? 0 : await suspender('business_id = $1', [bid], 'empresa')
  return { ativo, suspensas }
}

/* ---------- público e segmentação (somente a base da própria empresa) ---------- */
export const SEGMENTOS = ['todos', 'compradores', 'recentes', 'sem_compras', 'personalizado'] as const
/** Normaliza o segmento (aceita também o formato antigo: origem/desdeDias/compradores). */
export function normSeg(s: any = {}) {
  const dia = (v: any, d: number) => Math.max(1, Math.min(3650, Math.round(Number(v) || d)))
  let tipo = SEGMENTOS.includes(s?.tipo) ? s.tipo : ''
  if (!tipo) tipo = s?.origem || s?.desdeDias > 0 || s?.compradores ? 'personalizado' : 'todos'
  const out: any = { tipo }
  if (tipo === 'recentes') out.dias = dia(s.dias, 30)
  if (tipo === 'sem_compras') out.dias = dia(s.dias, 60)
  if (tipo === 'personalizado') {
    if (['convite', 'pedido', 'perfil'].includes(s.origem)) out.origem = s.origem
    if (s.compradores === true || s.compradores === 'sim') out.compradores = true
    if (s.desdeDias > 0) out.desdeDias = dia(s.desdeDias, 30)
    if (s.semComprasDias > 0) out.semComprasDias = dia(s.semComprasDias, 60)
  }
  return out
}
async function comprasDo(ownerId: number) {
  const ult = new Map<number, number>()
  for (const o of await q("SELECT o.customer_id, o.created_at FROM orders o JOIN businesses b ON b.id = o.business_id WHERE b.owner_id = $1 AND o.status NOT IN ('recusado', 'cancelado')", [ownerId])) {
    const t = Date.parse(o.created_at); const k = Number(o.customer_id); if (!ult.has(k) || ult.get(k)! < t) ult.set(k, t)
  }
  return ult
}
export async function audience(ownerId: number, segIn: any = {}) {
  const seg = normSeg(segIn)
  let rows = await q("SELECT c.user_id, c.origem, c.criado_em FROM marketing_consents c JOIN users u ON u.id = c.user_id WHERE c.owner_id = $1 AND c.status = 'ativo' AND u.status = 'active'", [ownerId])
  rows = rows.filter((r: any) => Number(r.user_id) !== ownerId)
  const precisaCompras = seg.tipo === 'compradores' || seg.tipo === 'sem_compras' || seg.compradores || seg.semComprasDias
  const C = precisaCompras ? await comprasDo(ownerId) : new Map<number, number>()
  const desde = (d: number) => Date.now() - d * 86400_000
  if (seg.tipo === 'compradores') rows = rows.filter((r: any) => C.has(Number(r.user_id)))
  if (seg.tipo === 'recentes') rows = rows.filter((r: any) => Date.parse(r.criado_em) >= desde(seg.dias))
  if (seg.tipo === 'sem_compras') rows = rows.filter((r: any) => !C.has(Number(r.user_id)) || C.get(Number(r.user_id))! < desde(seg.dias))
  if (seg.tipo === 'personalizado') {
    if (seg.origem) rows = rows.filter((r: any) => new RegExp('^' + seg.origem).test(String(r.origem)))
    if (seg.compradores) rows = rows.filter((r: any) => C.has(Number(r.user_id)))
    if (seg.desdeDias) rows = rows.filter((r: any) => Date.parse(r.criado_em) >= desde(seg.desdeDias))
    if (seg.semComprasDias) rows = rows.filter((r: any) => !C.has(Number(r.user_id)) || C.get(Number(r.user_id))! < desde(seg.semComprasDias))
  }
  return rows.map((r: any) => Number(r.user_id))
}

/* ---------- campanhas: criar, editar, rascunho, programar, cancelar, validar ---------- */
const IMG_MAX = 480_000 // ~350 KB de imagem
function imagemOk(v: any) {
  if (v == null || v === '') return null
  if (typeof v === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)) { if (v.length > IMG_MAX) fail(400, 'Imagem grande demais (máx. ~350 KB).', 'invalid', 'imagem'); return v }
  fail(400, 'Imagem inválida: use PNG, JPG ou WebP.', 'invalid', 'imagem')
}
const EDITAVEIS = ['rascunho', 'agendada', 'suspensa']
async function minhaCampanha(ownerId: number, id: number) {
  const c = await one('SELECT * FROM mkt_campaigns WHERE id = $1 AND owner_id = $2 AND business_id IS NOT NULL', [id, ownerId])
  if (!c) fail(404, 'Campanha não encontrada.', 'not_found')
  const b = await empresaDo(ownerId); if (!b || Number(b.id) !== Number(c.business_id)) fail(404, 'Campanha não encontrada.', 'not_found')
  return c
}
/** Data e hora informadas no fuso do proprietário → instante. Aceita também agendarPara (ISO) do formato antigo. */
function quandoDe(b: any, tz: string) {
  if (b.data && /^\d{4}-\d{2}-\d{2}$/.test(String(b.data))) {
    const h = /^\d{2}:\d{2}$/.test(String(b.hora || '')) ? String(b.hora) : '09:00'
    return new Date(zonedToUtc(String(b.data), h, tz))
  }
  if (b.agendarPara) { const d = new Date(b.agendarPara); if (isNaN(d.getTime())) fail(400, 'Data ou horário inválido.', 'invalid'); return d }
  return null
}
function encerraDe(b: any, tz: string) {
  if (b.encerraData && /^\d{4}-\d{2}-\d{2}$/.test(String(b.encerraData))) return new Date(zonedToUtc(String(b.encerraData), '23:59', tz))
  if (b.encerraEm) { const d = new Date(b.encerraEm); if (isNaN(d.getTime())) fail(400, 'Data de encerramento inválida.', 'invalid'); return d }
  return null
}
/** Salva (cria ou edita) uma campanha. rascunho=true guarda sem programar; caso contrário valida tudo e programa. */
export async function salvarCampanha(ownerId: number, b: any) {
  const pl = await ownerPlan(ownerId), L = pl.limites
  exigirPermissoes(pl)
  const tz = await tzDono(ownerId), bid = pl.business!.id
  const atual = b.id ? await minhaCampanha(ownerId, Number(b.id)) : null
  if (atual && !EDITAVEIS.includes(atual.status)) fail(400, 'Só campanhas ainda não enviadas podem ser editadas.', 'invalid')
  const titulo = String(b.titulo ?? atual?.titulo ?? '').trim().slice(0, 80), mensagem = String(b.mensagem ?? atual?.mensagem ?? '').trim().slice(0, 500)
  const nome = String(b.nome ?? atual?.nome ?? '').trim().slice(0, 60) || titulo
  const link = b.link !== undefined ? (/^https?:\/\//.test(String(b.link || '')) ? String(b.link).slice(0, 300) : '') : atual?.link || ''
  const imagem = b.imagem !== undefined ? imagemOk(b.imagem) : atual?.imagem || null
  const rascunho = b.rascunho === true
  if (!rascunho && (titulo.length < 3 || mensagem.length < 5)) fail(400, 'Escreva o título e a mensagem da campanha.', 'invalid')
  if (rascunho && !nome && titulo.length < 1) fail(400, 'Dê um nome à campanha para salvar o rascunho.', 'invalid')
  const segIn = b.segmento !== undefined ? b.segmento : J<any>(atual?.segmento, {})
  const seg = normSeg(segIn)
  if (seg.tipo !== 'todos' && !L.segmentacao) upgrade('A segmentação de clientes não está disponível no plano atual.')
  let quando = quandoDe(b, tz) || (atual && !b.agoraMesmo && b.data === undefined && b.agendarPara === undefined ? new Date(atual.agendada_para) : null) || new Date()
  const encerra = b.encerraData !== undefined || b.encerraEm !== undefined ? encerraDe(b, tz) : atual?.encerra_em ? new Date(atual.encerra_em) : null
  let total = Number(atual?.total || 0)
  if (!rascunho) {
    if (quando.getTime() > Date.now() + 60_000 && !L.agendar) upgrade('Programar campanhas não está disponível no plano atual.')
    if (quando.getTime() < Date.now() - 60_000) fail(400, 'Escolha uma data e um horário futuros (ou “Enviar agora”).', 'invalid')
    if (quando.getTime() < Date.now()) quando = new Date()
    if (encerra && encerra.getTime() <= quando.getTime()) fail(400, 'A data de encerramento precisa ser depois do início.', 'invalid')
    const conta = !atual || atual.status === 'rascunho'
    if (conta && pl.uso.campanhas >= L.campanhasPeriodo) upgrade(`Você já usou as ${L.campanhasPeriodo} campanhas deste período.`)
    const publico = await audience(ownerId, seg)
    if (!publico.length) fail(400, 'Nenhum cliente autorizou receber comunicações da sua empresa neste público ainda.', 'no_audience')
    if (pl.uso.notificacoes + publico.length > L.notificacoesPeriodo) upgrade(`Esta campanha teria ${publico.length} envios e restam ${Math.max(0, L.notificacoesPeriodo - pl.uso.notificacoes)} no período.`)
    total = publico.length
  }
  const status = rascunho ? 'rascunho' : 'agendada'
  let id: number
  if (atual) {
    await q('UPDATE mkt_campaigns SET nome = $1, titulo = $2, mensagem = $3, link = $4, imagem = $5, segmento = $6, status = $7, agendada_para = $8, encerra_em = $9, total = $10, fuso = $11, erro = NULL, suspensa_por = NULL, atualizada_em = $12' + (atual.status === 'rascunho' && !rascunho ? ', criada_em = $12' : '') + ' WHERE id = $13',
      [nome, titulo || nome, mensagem, link, imagem, JSON.stringify(seg), status, quando.toISOString(), iso(encerra), total, tz, nowIso(), Number(atual.id)])
    id = Number(atual.id)
    await auditar({ businessId: bid, campaignId: id, userId: ownerId, acao: atual.status === 'suspensa' && !rascunho ? 'validada' : rascunho ? 'rascunho_editado' : atual.status === 'rascunho' ? 'programada' : 'editada', detalhe: { quando: quando.toISOString(), segmento: seg } })
  } else {
    const r = await q('INSERT INTO mkt_campaigns (owner_id, business_id, nome, titulo, mensagem, link, imagem, segmento, status, agendada_para, encerra_em, total, fuso, criada_em, atualizada_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$14) RETURNING id',
      [ownerId, bid, nome, titulo || nome, mensagem, link, imagem, JSON.stringify(seg), status, quando.toISOString(), iso(encerra), total, tz, nowIso()])
    id = Number(r[0].id)
    await auditar({ businessId: bid, campaignId: id, userId: ownerId, acao: rascunho ? 'rascunho_criado' : 'criada', detalhe: { quando: quando.toISOString(), segmento: seg } })
  }
  if (!rascunho && quando.getTime() <= Date.now() + 5000) void runCampaigns().catch((e) => console.error('[marketing]', e?.message))
  return one('SELECT * FROM mkt_campaigns WHERE id = $1', [id])
}
/** Compatibilidade: a ação antiga "criar" é um salvar que programa (ou envia agora). */
export const createCampaign = (ownerId: number, b: any) => salvarCampanha(ownerId, { ...b, rascunho: false, id: undefined })
export async function cancelarCampanha(ownerId: number, id: number) {
  const c = await minhaCampanha(ownerId, id)
  const r = await q("UPDATE mkt_campaigns SET status = 'cancelada', trava_ate = NULL, atualizada_em = $1 WHERE id = $2 AND status IN ('rascunho', 'agendada', 'suspensa') RETURNING id", [nowIso(), id])
  if (!r.length) fail(400, 'Só campanhas ainda não enviadas podem ser canceladas.', 'invalid')
  await auditar({ businessId: Number(c.business_id), campaignId: id, userId: ownerId, acao: 'cancelada', detalhe: { statusAnterior: c.status } })
  return { ok: true }
}
/** Retoma uma campanha suspensa depois que as permissões voltaram: o proprietário revisa e confirma (pode trocar a data). */
export async function validarCampanha(ownerId: number, id: number, b: any = {}) {
  const c = await minhaCampanha(ownerId, id)
  if (c.status !== 'suspensa') fail(400, 'Só campanhas suspensas precisam de validação.', 'invalid')
  if (c.encerra_em && Date.parse(c.encerra_em) <= Date.now()) {
    await q("UPDATE mkt_campaigns SET status = 'expirada', erro = $1, atualizada_em = $2 WHERE id = $3", ['A data de encerramento passou enquanto a campanha estava suspensa.', nowIso(), id])
    await auditar({ businessId: Number(c.business_id), campaignId: id, userId: ownerId, acao: 'expirada' })
    fail(400, 'A data de encerramento desta campanha já passou. Crie uma nova campanha.', 'expired')
  }
  const passou = Date.parse(c.agendada_para) < Date.now()
  return salvarCampanha(ownerId, { id, ...(b.data ? { data: b.data, hora: b.hora } : passou ? { agoraMesmo: true, agendarPara: new Date().toISOString() } : {}) })
}
export async function detalheCampanha(ownerId: number, id: number) {
  const c = await minhaCampanha(ownerId, id)
  const ex = await q('SELECT * FROM mkt_execucoes WHERE campaign_id = $1 ORDER BY id DESC LIMIT 20', [id])
  const au = await q('SELECT acao, detalhe, criado_em FROM mkt_auditoria WHERE campaign_id = $1 ORDER BY id DESC LIMIT 30', [id])
  return { campanha: campanhaOut(c, true), execucoes: ex.map((e: any) => ({ iniciadaEm: iso(e.iniciada_em), finalizadaEm: iso(e.finalizada_em), enviados: Number(e.enviados), falhas: Number(e.falhas), ignorados: Number(e.ignorados), resultado: e.resultado, detalhe: e.detalhe })), historico: au.map((a: any) => ({ acao: a.acao, em: iso(a.criado_em), detalhe: J<any>(a.detalhe, a.detalhe) })) }
}
export const imagemUrl = (c: any) => (c.imagem ? `/api/v2/marketing/img/${c.id}.${sig('img:' + c.id)}` : null)
export const checkImg = (id: number, s: string) => s === sig('img:' + id)
export function campanhaOut(c: any, relatorios: boolean) {
  return { id: Number(c.id), nome: c.nome || c.titulo, titulo: c.titulo, mensagem: c.mensagem, link: c.link, imagem: imagemUrl(c), status: c.status, agendadaPara: iso(c.agendada_para), encerraEm: iso(c.encerra_em), criadaEm: iso(c.criada_em), concluidaEm: iso(c.concluida_em), fuso: c.fuso || null,
    total: Number(c.total), enviados: Number(c.enviados), falhas: Number(c.falhas || 0), ignorados: Number(c.ignorados), pushOk: relatorios ? Number(c.push_ok) : null, cliques: relatorios ? Number(c.cliques) : null, execucoes: Number(c.execucoes || 0), erro: c.erro, suspensaPor: c.suspensa_por || null, segmento: normSeg(J<any>(c.segmento, {})) }
}

/* ---------- execução ---------- */
/** Hora local entre 8h e 21h no fuso da campanha: campanhas não acordam ninguém. */
const horaBoa = (d = new Date(), tz = 'America/Sao_Paulo') => { const h = new Date(d.toLocaleString('en-US', { timeZone: validTz(tz) })).getHours(); return h >= 8 && h < 21 }
/** Canal de entrega (notificação no app + push). Substituível nos testes para simular falhas. */
export const canal = { enviar: async (uid: number, n: { type: string; title: string; body?: string; link?: string; ref?: string }) => { await notify(uid, n) } }
export const MAX_TENTATIVAS = 3
const RETRY_MIN = 5
let rodando = false
/** Agendador: executa campanhas devidas (mesmo com o dono desconectado), sem duplicar, com tentativas e respeitando permissões e limites. */
export async function runCampaigns(now = new Date(), forcarHorario = false) {
  if (rodando) return; rodando = true
  try {
    await sincronizarSuspensoes()
    for (const x of await q("UPDATE mkt_campaigns SET status = 'expirada', erro = $1, trava_ate = NULL WHERE business_id IS NOT NULL AND status IN ('agendada', 'enviando') AND encerra_em IS NOT NULL AND encerra_em <= $2 RETURNING id, business_id", ['A data de encerramento chegou; envio interrompido.', now.toISOString()]))
      await auditar({ businessId: Number(x.business_id), campaignId: Number(x.id), acao: 'expirada' })
    const due = await q("SELECT * FROM mkt_campaigns WHERE status IN ('agendada','enviando') AND agendada_para <= $1 AND (trava_ate IS NULL OR trava_ate <= $1) ORDER BY id LIMIT 10", [now.toISOString()])
    for (const c0 of due) {
      if (!forcarHorario && !horaBoa(now, c0.fuso)) { await q('UPDATE mkt_campaigns SET erro = $1 WHERE id = $2', ['Aguardando horário comercial (8h às 21h).', c0.id]); continue }
      // trava atômica: só um processo executa cada campanha por vez (evita envios duplicados entre instâncias)
      const got = await q("UPDATE mkt_campaigns SET status = 'enviando', erro = NULL, trava_ate = $1, execucoes = execucoes + 1 WHERE id = $2 AND status IN ('agendada','enviando') AND (trava_ate IS NULL OR trava_ate <= $3) RETURNING *", [new Date(now.getTime() + 10 * 60_000).toISOString(), c0.id, now.toISOString()])
      if (!got.length) continue
      const c = got[0], sist = !!J<any>(c.segmento, {}).sistema
      const ex = (await q('INSERT INTO mkt_execucoes (campaign_id, iniciada_em) VALUES ($1,$2) RETURNING id', [c.id, nowIso()]))[0]
      const fecharExec = async (r: { enviados?: number; falhas?: number; ignorados?: number; resultado: string; detalhe?: string }) => { await q('UPDATE mkt_execucoes SET finalizada_em = $1, enviados = $2, falhas = $3, ignorados = $4, resultado = $5, detalhe = $6 WHERE id = $7', [nowIso(), r.enviados || 0, r.falhas || 0, r.ignorados || 0, r.resultado, r.detalhe || null, ex.id]) }
      // 3º nível: o sistema confere as permissões antes de enviar
      const pl: any = sist ? { limites: { notificacoesPeriodo: Infinity }, uso: { notificacoes: 0 }, permissoes: { podeUsar: true } } : await ownerPlan(Number(c.owner_id))
      if (!sist && (!pl.permissoes.podeUsar || Number(pl.business?.id) !== Number(c.business_id))) {
        const motivo = !pl.permissoes.administrador ? 'administrador' : !pl.permissoes.plano || !pl.business ? 'plano' : 'empresa'
        await q("UPDATE mkt_campaigns SET status = 'suspensa', suspensa_por = $1, erro = $2, trava_ate = NULL WHERE id = $3", [motivo, MOTIVO[motivo], c.id])
        await fecharExec({ resultado: 'suspensa', detalhe: MOTIVO[motivo] }); await auditar({ businessId: Number(c.business_id), campaignId: Number(c.id), acao: 'suspensa', detalhe: { motivo } })
        continue
      }
      const b = c.business_id ? await one('SELECT data FROM businesses WHERE id = $1', [c.business_id]) : null, empresa = sist ? 'Meu Assistente' : J<any>(b?.data, {}).empresa || 'Empresa parceira'
      const publico = sist ? await systemAudience() : await audience(Number(c.owner_id), J<any>(c.segmento, {}))
      let usados = Number(pl.uso.notificacoes), nEnv = 0, nFal = 0, nIgn = 0, push = Number(c.push_ok), limite = false
      const valida = c.encerra_em ? ` · Válida até ${new Date(c.encerra_em).toLocaleDateString('pt-BR', { timeZone: validTz(c.fuso) })}` : ''
      for (const uid of publico) {
        // a cada destinatário confere de novo se a campanha não foi cancelada/suspensa no meio do envio
        if ((nEnv + nFal) % 25 === 24) { const st = await one('SELECT status FROM mkt_campaigns WHERE id = $1', [c.id]); if (st?.status !== 'enviando') break }
        const ja = await one('SELECT id, status, tentativas FROM mkt_sends WHERE campaign_id = $1 AND user_id = $2', [c.id, uid])
        if (ja && (ja.status !== 'falha' || Number(ja.tentativas) >= MAX_TENTATIVAS)) continue // já enviado/ignorado (nunca duplica) ou sem mais tentativas
        if (usados >= pl.limites.notificacoesPeriodo) { limite = true; break }
        const u = await one('SELECT settings FROM users WHERE id = $1', [uid]); const st = J<any>(u?.settings, {})
        const recente = !ja && await one("SELECT id FROM mkt_sends WHERE owner_id = $1 AND user_id = $2 AND status = 'enviado' AND campaign_id <> $3 AND criado_em >= $4", [c.owner_id, uid, c.id, new Date(now.getTime() - 20 * 3600_000).toISOString()])
        if (st.notificationsEnabled === false || recente) { await q('INSERT INTO mkt_sends (campaign_id, owner_id, user_id, status, canal, criado_em) VALUES ($1,$2,$3,$4,$5,$6)', [c.id, c.owner_id, uid, st.notificationsEnabled === false ? 'ignorado_preferencia' : 'ignorado_frequencia', '', nowIso()]).catch(() => {}); nIgn++; continue }
        // reserva o envio ANTES de entregar (índice único campanha+cliente): um segundo processo nunca entrega de novo
        let sendId: number
        if (ja) { sendId = Number(ja.id); await q("UPDATE mkt_sends SET status = 'enviando', tentativas = tentativas + 1 WHERE id = $1 AND status = 'falha'", [sendId]) }
        else { try { sendId = Number((await q("INSERT INTO mkt_sends (campaign_id, owner_id, user_id, status, canal, criado_em) VALUES ($1,$2,$3,'enviando','app',$4) RETURNING id", [c.id, c.owner_id, uid, nowIso()]))[0].id) } catch { continue } }
        try {
          await canal.enviar(uid, { type: 'promo', title: `${empresa}: ${c.titulo}`, body: c.mensagem + valida, link: `/?mkt=${sendId}.${sig('c:' + sendId)}`, ref: `mkt:${c.id}:${uid}` })
          await q("UPDATE mkt_sends SET status = 'enviado', canal = 'app', erro = NULL, criado_em = $1 WHERE id = $2", [nowIso(), sendId])
          nEnv++; usados++
          if (Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [uid]).catch(() => [{ n: 0 }]))[0].n) > 0) push++
        } catch (e: any) {
          await q("UPDATE mkt_sends SET status = 'falha', erro = $1 WHERE id = $2", [String(e?.message || e).slice(0, 200), sendId]); nFal++
        }
      }
      const cnt = async (cond: string) => Number((await q(`SELECT COUNT(*) AS n FROM mkt_sends WHERE campaign_id = $1 AND ${cond}`, [c.id]))[0].n)
      const enviados = await cnt("status = 'enviado'"), falhas = await cnt("status = 'falha'"), ignorados = await cnt("status LIKE 'ignorado%'"), aRetentar = await cnt(`status = 'falha' AND tentativas < ${MAX_TENTATIVAS}`)
      const atual = (await one('SELECT status FROM mkt_campaigns WHERE id = $1', [c.id]))?.status
      if (atual !== 'enviando') { await fecharExec({ enviados: nEnv, falhas: nFal, ignorados: nIgn, resultado: 'interrompida', detalhe: `Campanha ${atual} durante o envio.` }); await q('UPDATE mkt_campaigns SET enviados = $1, falhas = $2, ignorados = $3, push_ok = $4, trava_ate = NULL WHERE id = $5', [enviados, falhas, ignorados, push, c.id]); continue }
      if (aRetentar > 0 && !limite) {
        const prox = new Date(now.getTime() + RETRY_MIN * 60_000)
        await q("UPDATE mkt_campaigns SET enviados = $1, falhas = $2, ignorados = $3, push_ok = $4, total = $5, agendada_para = $6, trava_ate = NULL, erro = $7 WHERE id = $8", [enviados, falhas, ignorados, push, publico.length, prox.toISOString(), `${aRetentar} envio(s) com falha; nova tentativa automática em ${RETRY_MIN} min.`, c.id])
        await fecharExec({ enviados: nEnv, falhas: nFal, ignorados: nIgn, resultado: 'parcial', detalhe: `${aRetentar} para tentar de novo` })
      } else {
        await q("UPDATE mkt_campaigns SET status = 'concluida', enviados = $1, falhas = $2, ignorados = $3, push_ok = $4, total = $5, concluida_em = $6, trava_ate = NULL, erro = $7 WHERE id = $8", [enviados, falhas, ignorados, push, publico.length, nowIso(), limite ? 'Limite de notificações do plano atingido; parte do público não recebeu.' : falhas ? `${falhas} envio(s) falharam após ${MAX_TENTATIVAS} tentativas.` : null, c.id])
        await fecharExec({ enviados: nEnv, falhas: nFal, ignorados: nIgn, resultado: 'concluida' })
      }
      if (!sist) await auditar({ businessId: Number(c.business_id), campaignId: Number(c.id), acao: 'executada', detalhe: { enviados: nEnv, falhas: nFal, ignorados: nIgn } })
    }
  } finally { rodando = false }
}
/** Clique na notificação: conta a interação e devolve o destino + a identificação da empresa e o link para sair. */
export async function clickInfo(sendId: number, s: string) {
  if (s !== sig('c:' + sendId)) return { to: '/' }
  const r = await one('SELECT s.id, s.clicado_em, s.user_id, s.owner_id, c.id AS cid, c.link, c.business_id, c.titulo, c.mensagem, c.imagem, c.encerra_em, c.fuso FROM mkt_sends s JOIN mkt_campaigns c ON c.id = s.campaign_id WHERE s.id = $1', [sendId]); if (!r) return { to: '/' }
  if (!r.clicado_em) { await q('UPDATE mkt_sends SET clicado_em = $1 WHERE id = $2', [nowIso(), sendId]); await q('UPDATE mkt_campaigns SET cliques = cliques + 1 WHERE id = $1', [r.cid]) }
  const to = r.link ? r.link : r.business_id ? `/x/empresa/${r.business_id}` : '/'
  if (!r.business_id) return { to }
  const b = await one('SELECT data FROM businesses WHERE id = $1', [r.business_id])
  return { to, oferta: { empresa: J<any>(b?.data, {}).empresa || 'Empresa parceira', titulo: r.titulo, mensagem: r.mensagem, imagem: imagemUrl({ id: r.cid, imagem: r.imagem }), validaAte: iso(r.encerra_em), sair: `/api/v2/marketing/sair?o=${r.owner_id}&u=${r.user_id}&s=${sig(`sair:${r.owner_id}:${r.user_id}`)}` } }
}
export async function clickRedirect(sendId: number, s: string) { return (await clickInfo(sendId, s)).to }
