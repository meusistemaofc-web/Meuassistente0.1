// Notificações comerciais: painel do administrador (ligar/desligar, mensagens, intervalos e resultados)
// e as ações do dono da empresa (botão da notificação e "não quero receber"). Cada dono só alcança as próprias inscrições.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit } from '../lib/account.js'
import * as M from '../comercial/motor.js'
import { CAMPANHAS, campanhaPorId } from '../comercial/campanhas.js'

function requireAdm(ctx: Ctx) { const u = requireUser(ctx); if (u.role !== 'superadmin' && u.role !== 'admin') fail(403, 'Só para administradores.', 'forbidden'); return u }
const erro = (e: any) => { if (e?.status) fail(e.status, e.message, 'invalid'); throw e }

async function painel() {
  const campanhas = []
  for (const c of CAMPANHAS) { const st = await M.estado(c); campanhas.push({ id: c.id, nome: c.nome, descricao: c.descricao, servico: c.servico, escopo: c.escopo, disponivel: await c.disponivel(), ativo: st.ativo, ativadaEm: st.ativadaEm, atualizadoEm: st.atualizadoEm, config: st.config, resultados: await M.resultados(c) }) }
  return { global: await M.cfgGlobal(), campanhas }
}
export async function comercialPainelGet(ctx: Ctx) { requireAdm(ctx); return painel() }
export async function comercialPainelPost(ctx: Ctx) {
  const u = requireAdm(ctx), b = ctx.body || {}
  if (b.action === 'global') { const g = await M.salvarGlobal(b).catch(erro); await audit(u.id, 'comercial.global', null, g); return painel() }
  if (b.action === 'salvar') { if (!campanhaPorId(String(b.id))) fail(404, 'Campanha não encontrada.', 'not_found'); await M.salvarCampanha(String(b.id), b, u.id).catch(erro); await audit(u.id, 'comercial.campanha', null, { id: b.id, ativo: b.ativo }); return painel() }
  if (b.action === 'incluir_existentes') { if (!campanhaPorId(String(b.id))) fail(404, 'Campanha não encontrada.', 'not_found'); const n = await M.incluirExistentes(String(b.id)); await audit(u.id, 'comercial.incluir', null, { id: b.id, n }); return { ...(await painel()), incluidas: n } }
  if (b.action === 'processar') { const r = await M.processar(new Date()); return { ...(await painel()), rodada: r } }
  fail(400, 'Ação inválida.', 'invalid')
}
/** Dono: lista das próprias notificações comerciais (o app põe o botão embaixo de cada uma). */
export async function comercialMinhasGet(ctx: Ctx) { const u = requireUser(ctx); return { itens: await M.minhas(u.id) } }
export async function comercialPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.action === 'clique') { const r = await M.clique(u.id, String(b.t || '')); if (!r) fail(404, 'Oferta não encontrada.', 'not_found'); return r }
  if (b.action === 'sair') { if (!(await M.sair(u.id, String(b.t || '')))) fail(404, 'Oferta não encontrada.', 'not_found'); return { ok: true } }
  fail(400, 'Ação inválida.', 'invalid')
}
