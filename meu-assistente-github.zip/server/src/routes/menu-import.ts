// Rotas do Importador de Cardápio com IA (dentro de Empresas → Produtos). Só o dono da empresa; sempre filtrado pela empresa da URL.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { audit } from '../lib/account.js'
import { notify } from '../lib/notify.js'
import { ownBusiness, exigirLojaCompleta } from './businesses.js'
import * as M from '../lib/menu-import.js'

async function minha(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx)
  const imp = await one('SELECT * FROM menu_imports WHERE id = $1 AND business_id = $2', [Number(ctx.params.iid), b.id]) // isolamento: importação de outra empresa = 404
  if (!imp) fail(404, 'Importação não encontrada.', 'not_found')
  return { u, b, imp: imp! }
}
const detalhe = async (b: any, imp: any) => {
  const o = M.outImp(imp, true), itens = o.itens || []
  return { ...o, duplicidades: imp.status === 'revisao' ? await M.duplicidades(Number(b.id), itens) : {}, origem: undefined }
}

export async function menuImportList(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  const rows = await q('SELECT i.*, u.name AS user_name FROM menu_imports i JOIN users u ON u.id = i.user_id WHERE i.business_id = $1 AND i.status <> $2 ORDER BY i.id DESC LIMIT 100', [b.id, 'rascunho'])
  return { itens: rows.map((r: any) => ({ ...M.outImp(r), empresa: J<any>(b.data, {}).empresa || J<any>(b.data, {}).nome || '', usuario: r.user_name || '' })) }
}
export async function menuImportCreate(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await exigirLojaCompleta(b)
  return M.criar(Number(b.id), u.id)
}
export async function menuImportFile(ctx: Ctx) {
  const { b, imp } = await minha(ctx); await exigirLojaCompleta(b)
  const f = ((ctx as any).files || [])[0]; if (!f) fail(400, 'Nenhum arquivo recebido.', 'invalid')
  return M.anexar(imp, f.filename, f.data)
}
export async function menuImportStart(ctx: Ctx) {
  const { u, b, imp } = await minha(ctx); await exigirLojaCompleta(b)
  if (imp.status !== 'rascunho') fail(409, 'Esta importação já foi iniciada.', 'conflict')
  const r = await M.iniciar(imp, ctx.body?.forcar === true)
  await audit(u.id, 'cardapio.importar.iniciar', Number(imp.id), { empresa: Number(b.id), repetida: r.repetida })
  return r
}
export async function menuImportGet(ctx: Ctx) { const { b, imp } = await minha(ctx); return detalhe(b, imp) }
export async function menuImportSave(ctx: Ctx) {
  const { b, imp } = await minha(ctx)
  if (imp.status !== 'revisao') fail(409, 'Esta importação não está em revisão.', 'conflict')
  const edits: any[] = Array.isArray(ctx.body?.itens) ? ctx.body.itens : [], atuais = J<M.ItemRascunho[]>(imp.items, [])
  const por = new Map(edits.map((e) => [String(e.id), e]))
  const novos = atuais.map((a) => { const e = por.get(a.id); return e ? M.sanitizarItem({ ...a, ...e, id: a.id, avisos: [] }, 0, a.arquivo)! : a }).filter(Boolean)
  await q('UPDATE menu_imports SET items = $1, n_review = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(novos), novos.filter((x) => x.revisar && !x.confirmado).length, new Date().toISOString(), imp.id])
  return detalhe(b, (await one('SELECT * FROM menu_imports WHERE id = $1', [imp.id]))!)
}
export async function menuImportPublish(ctx: Ctx) {
  const { u, b, imp } = await minha(ctx); await exigirLojaCompleta(b)
  const r = await M.publicar(b, imp, u.id, Array.isArray(ctx.body?.itens) ? ctx.body.itens : null)
  await audit(u.id, 'cardapio.importar.publicar', Number(imp.id), { empresa: Number(b.id), criados: r.criados.length, atualizados: r.atualizados.length, ignorados: r.ignorados.length })
  await notify(u.id, { type: 'catalogo', title: 'Importação concluída', body: `${r.criados.length} produto(s) cadastrado(s), ${r.atualizados.length} atualizado(s).`, link: '/', ref: 'cardapio:' + imp.id }).catch(() => {})
  return { ok: true, ...r, importacao: M.outImp((await one('SELECT * FROM menu_imports WHERE id = $1', [imp.id]))!) }
}
export async function menuImportRetry(ctx: Ctx) { const { u, imp } = await minha(ctx); const r = await M.retomar(imp); await audit(u.id, 'cardapio.importar.retomar', Number(imp.id), {}); return r }
export async function menuImportCancel(ctx: Ctx) { const { u, imp } = await minha(ctx); await M.cancelar(imp); await audit(u.id, 'cardapio.importar.cancelar', Number(imp.id), {}); return { ok: true } }
export async function menuImportRevert(ctx: Ctx) { const { u, b, imp } = await minha(ctx); const r = await M.reverter(b, imp); await audit(u.id, 'cardapio.importar.reverter', Number(imp.id), r); return { ok: true, ...r } }
