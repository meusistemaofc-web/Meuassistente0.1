import { normalizeTema } from '../lib/theme.js'
import { geocodeAddress, reverseGeocode, validCoords } from '../lib/geocode.js'
import { pub } from '../lib/publicurl.js'
// Anúncios das empresas: proposta pelo usuário, aprovação pelo administrador, pagamento por Pix (Mercado Pago)
// e ativação automática pelo webhook. Os planos (níveis 1 a 4) vêm de Administração → Planos de anúncio.
import { createHmac, timingSafeEqual } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { getConfig, unseal } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import { requireModule } from '../lib/usermod.js'
import { PLANS_DEFAULT, MP_DEFAULT } from '../lib/panel-defaults.js'
import { config } from '../config.js'
import { pixExpiry, pixValid } from '../lib/pix.js'
import { nicheType } from './businesses.js'
import { MOD_DE, TIPO_DE, ROTULO, impactoTroca, type Modalidade } from '../lib/modalidade.js'
import { cfgAprovacao, definirModo, validarParaPublicacao } from '../lib/aprovacao-anuncios.js'

const MP_API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const STATUS = ['pagamento', 'analise', 'ajustes', 'recusado', 'aprovado', 'ativo', 'encerrado']
export async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const out = (b: any, plan?: any) => {
  const d = J<any>(b.data, {})
  const expired = b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now()
  const { mpTok, ...dd } = d
  return { id: Number(b.id), protocolo: b.protocolo, status: expired ? 'encerrado' : b.status, planId: b.plan_id, plan: plan || null, ...dd, tipo: nicheType(dd), tipoDefinido: ['produtos', 'servicos'].includes(dd.tipo), modalidade: b.modalidade || MOD_DE(nicheType(dd)), operacao: ['produtos', 'servicos', 'ambos'].includes(dd.tipo) ? dd.tipo : 'ambos', mpLoja: !!mpTok, payment: d.payment ? { status: d.payment.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor, expiresAt: d.payment.expiresAt } : null, lat: b.lat, lng: b.lng, expiresAt: b.expires_at, createdAt: b.created_at }
}
const clean = (v: unknown, n = 200) => str(v, n)
function fields(b: any) {
  const f: any = {
    empresa: clean(b.empresa, 80), categoria: clean(b.categoria, 60), tags: clean(b.tags, 200), titulo: clean(b.titulo, 70), texto: clean(b.texto, 180),
    link: clean(b.link, 300), zap: String(b.zap || '').replace(/\D/g, '').slice(0, 15), insta: clean(b.insta, 40).replace(/^@/, ''),
    endereco: clean(b.endereco, 160), horario: clean(b.horario, 220), sobre: clean(b.sobre, 600), contato: clean(b.contato, 80),
    palavras: String(b.palavras ?? '').split(/[,;\n]/).map((w) => clean(w, 40).toLowerCase()).filter(Boolean).slice(0, 25).join(', '),
    raio: Math.min(100, Math.max(1, Number(b.raio) || 5)),
  }
  if (f.link && !/^https?:\/\/\S+\.\S+/.test(f.link)) fail(400, 'O link precisa começar com https://', 'invalid', 'link')
  if (typeof b.logo === 'string' && b.logo.startsWith('data:image/')) { if (b.logo.length >= 300_000) fail(400, 'O logotipo é grande demais. Escolha uma imagem menor.', 'too_large'); f.logo = b.logo }
  if (typeof b.capa === 'string' && b.capa.startsWith('data:image/')) { if (b.capa.length >= 600_000) fail(400, 'A capa é grande demais. Escolha uma imagem menor.', 'too_large'); f.capa = b.capa }
  if (b.capa === '') f.capa = ''
  if (b.entrega && typeof b.entrega === 'object') { const e = b.entrega; f.entrega = { retirada: e.retirada !== false, entrega: !!e.entrega, taxa: Math.max(0, Number(e.taxa) || 0), raio: Math.min(100, Math.max(0, Number(e.raio) || 3)), minimo: Math.max(0, Number(e.minimo) || 0), tempo: str(e.tempo, 40), modoTaxa: e.modoTaxa === 'km' ? 'km' : 'fixa', kmGratis: Math.max(0, Number(e.kmGratis) || 0), taxaExcedente: Math.max(0, Number(e.taxaExcedente) || 0), taxaKm: Math.max(0, Number(e.taxaKm) || 0) } }
  if (b.pagamento && typeof b.pagamento === 'object') { const p = b.pagamento; f.pagamento = { pix: !!p.pix, chavePix: str(p.chavePix, 120), mostrarChave: p.mostrarChave !== false, pixentrega: !!p.pixentrega, cartao: !!p.cartao, dinheiro: !!p.dinheiro, online: !!p.online } }
  if (typeof b.mpTok === 'string') f.mpTok = b.mpTok
  if (b.tema && typeof b.tema === 'object') f.tema = normalizeTema(b.tema) // única configuração visual da empresa
  if (b.tipo === 'ambos' || (Array.isArray(b.tipo) && b.tipo.length > 1)) fail(400, 'Escolha apenas uma modalidade: produtos OU serviços.', 'modalidade_exclusiva', 'tipo')
  if (['produtos', 'servicos'].includes(b.tipo)) f.tipo = b.tipo
  if (Array.isArray(b.categorias)) f.categorias = [...new Set(b.categorias.map((c: any) => str(c, 40)).filter(Boolean))].slice(0, 30)
  if (Array.isArray(b.etiquetas)) { const vistos = new Set<string>(); f.etiquetas = b.etiquetas.slice(0, 20).map((e: any, i: number) => ({ id: str(e.id, 12) || 't' + Date.now().toString(36) + i, nome: str(e.nome, 24), cor: /^#[0-9a-f]{6}$/i.test(String(e.cor)) ? String(e.cor) : '#ef4444', tipo: ['produto', 'servico'].includes(e.tipo) ? e.tipo : 'ambos' })).filter((e: any) => { const k = e.nome.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); if (!k || vistos.has(k)) return false; vistos.add(k); return true }) } // sem etiquetas repetidas pelo nome
  if (b.horarioCfg && typeof b.horarioCfg === 'object') {
    const h = b.horarioCfg, hm = (t: unknown) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(t)) ? String(t) : null), dias: any = {}
    for (const k of ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']) { const d = h.dias?.[k] || {}; dias[k] = { ativo: !!d.ativo, abre: hm(d.abre) || '08:00', fecha: hm(d.fecha) || '18:00' } }
    f.horarioCfg = { modo: ['auto', 'aberto', 'fechado'].includes(h.modo) ? h.modo : 'auto', dias }
    // o texto do horário acompanha sempre a configuração (catálogo, busca e atendente mostram o mesmo)
    const N: any = { seg: 'Seg', ter: 'Ter', qua: 'Qua', qui: 'Qui', sex: 'Sex', sab: 'Sáb', dom: 'Dom' }
    f.horario = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'].filter((k) => dias[k].ativo).map((k) => `${N[k]} ${dias[k].abre}–${dias[k].fecha}`).join(', ') || 'Fechado'
  }
  return f
}
async function isAdsAdmin(ctx: Ctx) { const u = requireUser(ctx); if (u.role === 'user' || !effectivePermissions(u).includes('ads.manage')) fail(403, 'Sem permissão.', 'forbidden'); return u }
async function admins() { return (await q("SELECT id, role, permissions FROM users WHERE role IN ('admin','superadmin') AND status = 'active'")).map((r) => Number(r.id)) }

// Uma contratação por modalidade e por proprietário: ocupa a modalidade enquanto estiver em pagamento, análise,
// ajustes, aprovada ou no ar (e não vencida). Vencida, encerrada, cancelada ou excluída libera de novo.
const OCUPA = ['pagamento', 'analise', 'ajustes', 'aprovado', 'ativo']
export async function contratadas(ownerId: number) {
  const rows = await q(`SELECT id, plan_id, status, expires_at, data FROM businesses WHERE owner_id = $1 AND status IN ('pagamento','analise','ajustes','aprovado','ativo','recusado')`, [ownerId])
  const now = Date.now(), out: Record<string, { id: number; status: string; empresa: string; ate: string | null }> = {}
  for (const r of rows) {
    if (r.status === 'ativo' && r.expires_at && Date.parse(r.expires_at) < now) { await q("UPDATE businesses SET status = 'encerrado', updated_at = $1 WHERE id = $2 AND status = 'ativo'", [nowIso(), r.id]); continue } // vencido: libera
    if (!OCUPA.includes(r.status) && r.status !== 'recusado') continue
    out[r.plan_id] = { id: Number(r.id), status: r.status, empresa: J<any>(r.data, {}).empresa || '', ate: r.expires_at || null }
  }
  return out
}
const hiring = new Set<string>() // trava contra duas contratações simultâneas da mesma modalidade
export async function adsPlansGet(ctx: Ctx) { await requireModule('anuncios'); const u = ctx.user && ctx.session && !ctx.session.mfa_pending ? ctx.user : null; return { plans: await plans(), contratadas: u ? await contratadas(Number(u.id)) : {}, semLimite: !!u && u.role !== 'user' && effectivePermissions(u).includes('ads.manage') } }
/** Botão "Sua empresa" do cabeçalho: liberado só com anúncio aprovado pelo administrador (consulta o banco a cada chamada). */
export async function adsPainelGet(ctx: Ctx) { const u = requireUser(ctx); return await (await import('../lib/painel-empresa.js')).painelAcesso(u.id) }
export async function adsMineGet(ctx: Ctx) {
  const u = requireUser(ctx); const ps = await plans()
  const { empresaTemMcoins } = await import('./coins.js')
  // temMcoins: a opção MCoins de Ajustes só aparece quando o administrador criou/vinculou uma moeda a ESTA empresa
  return { items: await Promise.all((await q("SELECT * FROM businesses WHERE owner_id = $1 AND status <> 'institucional' ORDER BY id DESC", [u.id])).map(async (b) => ({ ...out(b, ps.find((p) => p.id === b.plan_id)), temMcoins: await empresaTemMcoins(Number(b.id)).catch(() => false) }))) }
}
/** Descrição institucional da empresa ("Sobre a empresa"). Não vale para descrição de produtos/serviços. */
export const SOBRE_MAX = 200
export async function adsPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('anuncios')
  const b = ctx.body || {}, ps = await plans(), plan = ps.find((p) => p.id === b.planId)
  if (!plan) fail(400, 'Escolha um plano.', 'invalid', 'planId')
  if (String(b.sobre ?? '').trim().length > SOBRE_MAX) fail(400, `A descrição da empresa pode ter até ${SOBRE_MAX} caracteres.`, 'invalid', 'sobre')
  const f = fields({ ...b, mpTok: undefined })
  if (!f.empresa || !f.categoria || !f.titulo) fail(400, 'Preencha o nome da empresa, o ramo e o título.', 'invalid')
  const lockKey = `${u.id}:${plan.id}`
  if (hiring.has(lockKey)) fail(409, `A contratação do plano ${plan.nome} já está sendo registrada.`, 'plan_taken')
  hiring.add(lockKey)
  try {
  const adminFree = u.role !== 'user' && effectivePermissions(u).includes('ads.manage') // administrador publica para clientes sem esse limite
  if (!adminFree) { const c = (await contratadas(u.id))[plan.id]; if (c) fail(409, c.status === 'recusado' ? `Seu anúncio no plano ${plan.nome} foi recusado: exclua-o em Sua empresa para contratar de novo.` : `Você já contratou o plano ${plan.nome} (${c.empresa}). Renove ou edite em Sua empresa.`, 'plan_taken') }
  if (plan.nivel >= 2 && !f.zap && !f.insta) fail(400, 'Informe WhatsApp ou Instagram para este plano.', 'invalid')
  if (u.role === 'user' && (await q("SELECT id FROM businesses WHERE owner_id = $1 AND status IN ('pagamento','analise','ajustes')", [u.id])).length >= 3) fail(400, 'Você já tem propostas em análise.', 'invalid')
  let lat = Number(b.lat), lng = Number(b.lng), hasLoc = validCoords(lat, lng)
  // endereço digitado sem localização automática: tenta achar as coordenadas (se não achar, o anúncio salva igual, só sem o raio por distância)
  if (!hasLoc && f.endereco) { const g = await geocodeAddress(f.endereco).catch(() => null); if (g) { lat = g.lat; lng = g.lng; hasLoc = true } }
  const protocolo = 'AN-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 8).toUpperCase()
  // administrador com permissão de anúncios publica direto, sem aprovação e sem pagamento
  const isAdmin = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  f.registros = [{ t: isAdmin ? 'Publicado pelo administrador (sem pagamento)' : 'Anúncio criado · aguardando pagamento', q: nowIso() }]
  const exp = isAdmin ? new Date(Date.now() + (Number(plan.dias) || 30) * 86400_000).toISOString() : null
  f.tipo = nicheType(f); const modalidade = MOD_DE(f.tipo)
  if (isAdmin) f.aprovacao = { origem: 'administrador', em: nowIso(), por: u.id } // publicado pelo próprio administrador
  else f.modoAprovacao = (await cfgAprovacao()).modo // o modo vigente no ENVIO é o que vale para este anúncio
  await q('INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, lat, lng, expires_at, created_at, updated_at, modalidade) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10)',
    [u.id, protocolo, isAdmin ? 'ativo' : 'pagamento', plan.id, JSON.stringify(f), hasLoc ? lat : null, hasLoc ? lng : null, exp, nowIso(), modalidade])
  } finally { hiring.delete(lockKey) }
  return adsMineGet(ctx)
}
export async function adsPut(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const body = { ...(ctx.body || {}) }; delete body.mpTok
  const atual = J<any>(b.data, {}).tipo
  if (body.tipo !== undefined && body.tipo !== atual) fail(body.tipo === 'ambos' ? 400 : 409, body.tipo === 'ambos' ? 'Escolha apenas uma modalidade: produtos OU serviços.' : 'Para trocar entre produtos e serviços use Ajustes → Tipo de catálogo: o sistema mostra as consequências e pede confirmação.', body.tipo === 'ambos' ? 'modalidade_exclusiva' : 'modalidade_confirmacao', 'tipo')
  delete body.tipo
  // descrição da empresa: até 200 caracteres (textos maiores já salvos continuam como estão até a empresa editar a descrição)
  if (body.sobre !== undefined && String(body.sobre).trim() !== String(J<any>(b.data, {}).sobre || '').trim() && String(body.sobre).trim().length > SOBRE_MAX) fail(400, `A descrição da empresa pode ter até ${SOBRE_MAX} caracteres.`, 'invalid', 'sobre')
  const d = { ...J<any>(b.data, {}), ...fields({ ...J<any>(b.data, {}), ...body, tipo: undefined }) }; if (atual) d.tipo = atual
  d.registros = [{ t: 'Detalhes atualizados', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  let lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng), hasLoc = validCoords(lat, lng)
  const antes = String(J<any>(b.data, {}).endereco || '')
  if (!hasLoc && d.endereco && (d.endereco !== antes || b.lat == null)) { const g = await geocodeAddress(d.endereco).catch(() => null); if (g) { lat = g.lat; lng = g.lng; hasLoc = true } } // endereço novo/alterado → coordenadas novas
  const st = b.status === 'ajustes' ? 'analise' : b.status
  await q('UPDATE businesses SET data = $1, status = $2, lat = COALESCE($3, lat), lng = COALESCE($4, lng), updated_at = $5 WHERE id = $6', [JSON.stringify(d), st, hasLoc ? lat : null, hasLoc ? lng : null, nowIso(), b.id])
  return adsMineGet(ctx)
}

/* ---------- pagamento Pix (Mercado Pago) ---------- */
async function mpToken() {
  const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }
  const tok = await unseal((mp[mp.modo] || {}).tok || '')
  return { tok, seg: await unseal((mp[mp.modo] || {}).seg || ''), modo: mp.modo }
}
async function paidSendReview(b: any, paymentId: string) {
  if (J<any>(b.data, {}).renovacao && (J<any>(b.data, {}).aprovadoEm || b.expires_at)) return activate(b, paymentId)
  const d = J<any>(b.data, {}); d.payment = { ...(d.payment || {}), status: 'approved' }; d.pago = true
  if (d.modoAprovacao === 'automatico') {
    const v = await validarParaPublicacao({ ...b, data: JSON.stringify(d) }, await plans())
    if (v.ok) { await activate({ ...b, data: JSON.stringify(d) }, paymentId, { origem: 'automatica', em: nowIso(), validacoes: v.verificadas }); await audit(Number(b.owner_id), 'ads.approve.auto', Number(b.id), { validacoes: v.verificadas }); return }
    d.aprovacao = { origem: 'pendente', motivoAutomatica: v.falhas } // falhou alguma validação: segue para a análise manual
  }
  d.registros = [{ t: 'Pagamento confirmado · enviado para aprovação', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q("UPDATE businesses SET status = 'analise', payment_id = $1, data = $2, updated_at = $3 WHERE id = $4", [paymentId, JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Pagamento confirmado! Enviamos seu anúncio para aprovação.', body: d.empresa, link: '/x/sua-empresa', ref: `ad-paid:${b.id}:${paymentId}` })
  const plan = (await plans()).find((p) => p.id === b.plan_id)
  for (const a of await admins()) await notify(a, { type: 'ads', title: 'Novo anúncio pago para aprovar', body: `${d.empresa}${plan ? ' · plano ' + plan.nome : ''} · toque para analisar`, link: '/admin?aba=anuncios', ref: `ad-new:${b.id}:${a}` })
}
async function activate(b: any, paymentId: string, aprovacao?: any) {
  const ps = await plans(), plan = ps.find((p) => p.id === b.plan_id) || { dias: 30 }
  const d = J<any>(b.data, {}); if (aprovacao) d.aprovacao = aprovacao; d.payment = { ...(d.payment || {}), status: 'approved' }; d.aprovadoEm = nowIso(); d.renovacao = false; d.pago = true; delete d.revogado
  d.registros = [{ t: aprovacao?.origem === 'automatica' ? 'Aprovado automaticamente (validações ok) · anúncio no ar' : 'Pagamento confirmado · anúncio no ar', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const exp = new Date(Date.now() + plan.dias * 86400_000).toISOString()
  await q("UPDATE businesses SET status = 'ativo', expires_at = $1, payment_id = $2, data = $3, updated_at = $4 WHERE id = $5", [exp, paymentId, JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Seu anúncio está no ar!', body: `${d.empresa} · até ${exp.slice(0, 10).split('-').reverse().join('/')}`, link: '/x/sua-empresa', ref: `ad-live:${b.id}:${paymentId}` })
}
async function mpGet(id: string, tok: string) {
  const r = await fetch(`${MP_API()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${tok}` } })
  if (!r.ok) throw new Error('MP ' + r.status)
  return r.json() as Promise<any>
}
export async function adsPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'pagamento' && b.status !== 'aprovado') fail(400, 'Este anúncio não está aguardando pagamento.', 'invalid')
  const { tok } = await mpToken()
  if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador (Administração → Mercado Pago).', 'mp_not_configured')
  const plan = (await plans()).find((p) => p.id === b.plan_id)
  if (!plan) fail(400, 'Plano não encontrado.', 'invalid')
  const d = J<any>(b.data, {})
  if (d.payment?.id && d.payment.status === 'pending' && pixValid(d.payment)) return { payment: { status: 'pending', qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor, expiresAt: d.payment.expiresAt } }
  const exp = await pixExpiry()
  const r = await fetch(`${MP_API()}/v1/payments`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `${b.protocolo}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: plan.preco, description: `Anúncio Meu Assistente · ${plan.nome}`, payment_method_id: 'pix', payer: { email: u.email }, date_of_expiration: exp.iso,
      external_reference: String(b.id), notification_url: `${pub()}/api/mercadopago/webhook` }),
  })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp] erro ao criar Pix:', r.status, JSON.stringify(p)?.slice(0, 300)); fail(502, 'O Mercado Pago recusou a criação do Pix. Confira as credenciais no painel.', 'mp_error') }
  const td = p.point_of_interaction?.transaction_data || {}
  d.payment = { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', valor: plan.preco, expiresAt: exp.at }
  await q('UPDATE businesses SET data = $1, payment_id = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(d), String(p.id), nowIso(), b.id])
  if (p.status === 'approved') await paidSendReview({ ...b, data: JSON.stringify(d) }, String(p.id))
  return { payment: { status: p.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor: plan.preco, expiresAt: exp.at } }
}
export async function adsPayStatusGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'pagamento' && b.status !== 'aprovado') return { status: J<any>(b.data, {}).pago ? 'approved' : 'none', adStatus: b.status }
  const pid = J<any>(b.data, {}).payment?.id
  if (!pid) return { status: 'none' }
  const { tok } = await mpToken()
  try { const p = await mpGet(pid, tok); if (p.status === 'approved' && String(p.external_reference) === String(b.id)) { await paidSendReview(b, pid); return { status: 'approved', adStatus: (await one('SELECT status FROM businesses WHERE id = $1', [b.id]))?.status || 'analise' } } return { status: p.status } }
  catch { return { status: 'unknown' } }
}
export async function mpWebhookPost(ctx: Ctx) {
  if (ctx.query.get('store')) return (await import('./businesses.js')).storeWebhook(ctx)
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const type = String(ctx.query.get('type') || ctx.body?.type || ctx.query.get('topic') || '')
  if (!id || (type && type !== 'payment')) return { ok: true }
  const { tok, seg } = await mpToken()
  if (seg) { // assinatura x-signature do Mercado Pago (quando o segredo foi configurado)
    const sig = String(ctx.req.headers['x-signature'] || ''), reqId = String(ctx.req.headers['x-request-id'] || '')
    const parts = Object.fromEntries(sig.split(',').map((s) => s.trim().split('=') as [string, string]))
    const expected = createHmac('sha256', seg).update(`id:${id};request-id:${reqId};ts:${parts.ts};`).digest('hex')
    if (!parts.v1 || parts.v1.length !== expected.length || !timingSafeEqual(Buffer.from(parts.v1), Buffer.from(expected))) fail(401, 'Assinatura inválida.', 'bad_signature')
  }
  if (!tok) return { ok: true }
  try {
    const p = await mpGet(id, tok) // a confirmação vem sempre da API do Mercado Pago, nunca do corpo recebido
    if (String(p.external_reference || '').startsWith('agent:')) { if (p.status === 'approved') await (await import('./businesses.js')).activateAgent(Number(String(p.external_reference).slice(6)), id); return { ok: true } }
    if (String(p.external_reference || '').startsWith('sub:')) { const [, uid, pid] = String(p.external_reference).split(':'); if (p.status === 'approved') await (await import('./plans.js')).activateSub(Number(uid), pid, id); return { ok: true } }
    const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(p.external_reference)])
    if (b && p.status === 'approved' && (b.status === 'pagamento' || b.status === 'aprovado')) await paidSendReview(b, id)
  } catch (e: any) { console.error('[mp] webhook:', e?.message) }
  return { ok: true }
}

/* ---------- administração ---------- */
export async function adminAdsGet(ctx: Ctx) {
  await isAdsAdmin(ctx); const ps = await plans()
  const rows = await q("SELECT b.*, u.name AS owner_name, u.email AS owner_email FROM businesses b JOIN users u ON u.id = b.owner_id WHERE b.status <> 'institucional' ORDER BY b.id DESC LIMIT 300")
  return { items: rows.map((b) => ({ ...out(b, ps.find((p) => p.id === b.plan_id)), owner: { name: b.owner_name, email: b.owner_email } })) }
}
export async function adminAdsPost(ctx: Ctx) {
  const u = await isAdsAdmin(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const act = String(ctx.body?.action || ''), motivo = str(ctx.body?.motivo, 300)
  const d = J<any>(b.data, {})
  const map: Record<string, [string, string, string]> = {
    approve: ['aprovado', 'Anúncio aprovado · aguardando pagamento', 'Seu anúncio foi aprovado! Faça o pagamento para colocá-lo no ar.'],
    adjust: ['ajustes', 'A equipe pediu ajustes: ' + motivo, 'A equipe pediu ajustes no seu anúncio: ' + motivo],
    reject: ['recusado', 'Anúncio recusado: ' + motivo, 'Seu anúncio foi recusado: ' + motivo + (J<any>(b.data, {}).pago ? ' (o valor pago será devolvido)' : '')],
  }
  if (act === 'approve' && (J<any>(b.data, {}).pago || b.status === 'analise')) { await activate(b, b.payment_id || 'manual-' + u.id, { origem: 'manual', em: nowIso(), por: u.id }); await notify(Number(b.owner_id), { type: 'ads', title: 'Seu anúncio foi aprovado e está no ar!', body: J<any>(b.data, {}).empresa, link: '/x/sua-empresa', ref: `ad-approve:${b.id}` }); await audit(u.id, 'ads.approve', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) }
  if (act === 'activate') { await activate(b, 'manual-' + u.id, { origem: 'manual', em: nowIso(), por: u.id }); await audit(u.id, 'ads.activate', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) }
  if (act === 'end') { const de = J<any>(b.data, {}); de.revogado = { em: nowIso(), por: u.id }; await q("UPDATE businesses SET status = 'encerrado', data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify(de), nowIso(), b.id]); await audit(u.id, 'ads.end', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) } // encerrar pelo admin = aprovação revogada (painel bloqueado até nova aprovação)
  const m = map[act]; if (!m) fail(400, 'Ação inválida.', 'invalid')
  if ((act === 'adjust' || act === 'reject') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  d.motivo = act === 'approve' ? '' : motivo
  d.registros = [{ t: m[1], q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q('UPDATE businesses SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [m[0], JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: m[2], body: d.empresa, link: '/x/sua-empresa', ref: `ad-${act}:${b.id}:${Date.now()}` })
  await audit(u.id, 'ads.' + act, Number(b.owner_id), { id: b.id })
  return adminAdsGet(ctx)
}
export { STATUS }

/** Subir de novo um anúncio encerrado/vencido: escolhe o plano, gera o Pix; os dados e produtos continuam salvos. */
export async function adsRenewPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const expired = b.status === 'encerrado' || (b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now())
  if (!expired) fail(400, 'Este anúncio ainda está no ar.', 'invalid')
  const plan = (await plans()).find((p) => p.id === ctx.body?.planId); if (!plan) fail(400, 'Escolha um plano.', 'invalid')
  if (u.role === 'user' && plan.id !== b.plan_id) { const dup = await one("SELECT id FROM businesses WHERE owner_id = $1 AND plan_id = $2 AND status <> 'recusado' AND id <> $3", [u.id, plan.id, b.id]); if (dup) fail(409, `Você já tem outro anúncio no plano ${plan.nome}.`, 'plan_in_use') }
  const d = J<any>(b.data, {}); delete d.payment; d.renovacao = true; d.pago = false
  d.registros = [{ t: `Renovação solicitada · plano ${plan.nome}`, q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const isAdmin = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  if (isAdmin) { await q('UPDATE businesses SET plan_id = $1, data = $2, updated_at = $3 WHERE id = $4', [plan.id, JSON.stringify(d), nowIso(), b.id]); await activate({ ...b, plan_id: plan.id, data: JSON.stringify(d) }, 'admin'); return adsMineGet(ctx) }
  await q("UPDATE businesses SET status = 'pagamento', plan_id = $1, data = $2, payment_id = NULL, updated_at = $3 WHERE id = $4", [plan.id, JSON.stringify(d), nowIso(), b.id])
  return adsMineGet(ctx)
}

/** Excluir um anúncio recusado pelo administrador (só o dono, só quando recusado). */
export async function adsDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT id, status FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'recusado') fail(400, 'Só anúncios recusados podem ser excluídos.', 'invalid')
  await q('DELETE FROM businesses WHERE id = $1', [b.id])
  return adsMineGet(ctx)
}

/** Preenche o endereço a partir da localização automática (lat/lng) ou acha as coordenadas de um endereço digitado. */
export async function geocodePost(ctx: Ctx) {
  requireUser(ctx)
  const b = ctx.body || {}, lat = Number(b.lat), lng = Number(b.lng)
  if (validCoords(lat, lng)) {
    const r = await reverseGeocode(lat, lng)
    if (!r) return { ok: false, lat, lng, message: 'Não consegui descobrir o endereço desta localização. Digite o endereço manualmente.' }
    return { ok: true, lat, lng, endereco: r.endereco }
  }
  const t = typeof b.endereco === 'string' ? b.endereco.trim() : ''
  if (t.length < 5) fail(400, 'Digite o endereço (rua, número, bairro e cidade).', 'invalid')
  const g = await geocodeAddress(t)
  if (!g) return { ok: false, message: 'Não encontrei esse endereço no mapa. Ele será salvo mesmo assim; confira bairro e cidade se quiser aparecer nas buscas por distância.' }
  return { ok: true, lat: g.lat, lng: g.lng, endereco: t }
}

/* ---------- modalidade exclusiva do catálogo (produtos OU serviços): troca só com aviso e confirmação ---------- */
async function modBiz(ctx: Ctx) { const { u, b } = await (await import('./businesses.js')).ownBusiness(ctx); return { u, b, atual: (b.modalidade || MOD_DE(nicheType(J<any>(b.data, {})))) as Modalidade } }
const consequencias = (para: Modalidade, imp: any) => [
  para === 'products' ? 'Serviços, horários e agendamentos deixam de aparecer na página, nos anúncios, nos cards e no chat do agente.' : 'Produtos, estoque, carrinho e pedidos deixam de aparecer na página, nos anúncios, nos cards e no chat do agente.',
  `${imp.itensOcultados} ${para === 'products' ? 'serviço(s)' : 'produto(s)'} ativo(s) ficarão ocultos — nada é apagado nem convertido; voltam se você trocar de novo.`,
  imp.itensReexibidos ? `${imp.itensReexibidos} ${para === 'products' ? 'produto(s)' : 'serviço(s)'} já cadastrado(s) volta(m) a aparecer.` : '',
  imp.pedidosAtivos || imp.agendamentosAtivos ? `Há ${imp.pedidosAtivos} pedido(s) e ${imp.agendamentosAtivos} agendamento(s) em andamento: eles continuam no seu painel para você concluir, mas novos ${para === 'products' ? 'agendamentos' : 'pedidos'} deixam de ser aceitos.` : '',
  'O histórico de pedidos e agendamentos é preservado para consulta.',
].filter(Boolean)
export async function modalidadeGet(ctx: Ctx) {
  const { b, atual } = await modBiz(ctx), para: Modalidade = atual === 'products' ? 'services' : 'products'
  const imp = await impactoTroca({ query: q }, b, para)
  return { atual, rotulo: ROTULO[atual], opcoes: ['products', 'services'], troca: { para, rotulo: ROTULO[para], impacto: imp, consequencias: consequencias(para, imp) } }
}
export async function modalidadePost(ctx: Ctx) {
  const { u, b, atual } = await modBiz(ctx)
  const raw = ctx.body?.modalidade
  if (Array.isArray(raw) || raw === 'ambos' || raw === 'both') fail(400, 'Escolha apenas uma modalidade: produtos OU serviços.', 'modalidade_exclusiva')
  const para = MOD_DE(raw); if (!para) fail(400, 'Modalidade inválida: use products (produtos) ou services (serviços).', 'invalid')
  if (para === atual) return modalidadeGet(ctx)
  const imp = await impactoTroca({ query: q }, b, para)
  if (ctx.body?.confirmar !== true) return { precisaConfirmar: true, atual, para, impacto: imp, consequencias: consequencias(para, imp) } // nada muda sem confirmação
  const d = J<any>(b.data, {}); d.tipo = TIPO_DE[para]
  d.registros = [{ t: `Modalidade alterada: ${ROTULO[atual]} → ${ROTULO[para]}`, q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const r = await q('UPDATE businesses SET modalidade = $1, data = $2, updated_at = $3 WHERE id = $4 AND owner_id = $5 AND (modalidade = $6 OR modalidade IS NULL) RETURNING id', [para, JSON.stringify(d), nowIso(), b.id, u.id, atual])
  if (!r.length) fail(409, 'A modalidade foi alterada em outro lugar. Atualize e tente de novo.', 'conflict')
  await audit(u.id, 'empresa.modalidade', Number(b.id), { de: atual, para, ...imp })
  return { ok: true, ...(await modalidadeGet(ctx)) }
}

/* ---------- Modo de aprovação de anúncios (configuração global do administrador) ---------- */
export async function adsApprovalGet(ctx: Ctx) {
  await isAdsAdmin(ctx); const c = await cfgAprovacao()
  const cont = async (st: string) => Number((await q('SELECT COUNT(*) AS n FROM businesses WHERE status = $1', [st]))[0]?.n || 0)
  return { ...c, pendentes: (await cont('analise')) + (await cont('ajustes')) }
}
export async function adsApprovalPut(ctx: Ctx) {
  const u = await isAdsAdmin(ctx)
  const modo = ctx.body?.modo
  if (modo !== 'manual' && modo !== 'automatico') fail(400, 'Modo inválido: use manual ou automatico.', 'invalid')
  const atual = await cfgAprovacao()
  if (atual.modo === modo) return adsApprovalGet(ctx)
  if (ctx.body?.confirmar !== true) fail(409, 'Confirme a alteração do modo de aprovação.', 'confirmacao_necessaria')
  await definirModo(modo, { id: u.id, name: u.name })
  await audit(u.id, 'ads.modo_aprovacao', null, { de: atual.modo, para: modo })
  return adsApprovalGet(ctx)
}
