import { normalizeTema } from '../lib/theme.js'
import { geocodeAddress, reverseGeocode, validCoords } from '../lib/geocode.js'
import * as CEP from '../lib/cep.js'
import { pub } from '../lib/publicurl.js'
// Anúncios das empresas: proposta pelo usuário, aprovação pelo administrador, pagamento por Pix (Mercado Pago)
// e ativação automática pelo webhook. Os planos (níveis 1 a 4) vêm de Administração → Planos de anúncio.
import { createHmac, timingSafeEqual } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { rateLimit, whatsappProblem, normWhatsapp } from '../lib/security.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { getConfig, unseal } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import { requireModule } from '../lib/usermod.js'
import { PLANS_DEFAULT, MP_DEFAULT } from '../lib/panel-defaults.js'
import { config } from '../config.js'
import { pixExpiry, pixValid, normalizarChavePix, tipoProvavel, TIPOS_CHAVE_PIX } from '../lib/pix.js'
import { nicheType } from './businesses.js'
import { MOD_DE, TIPO_DE, ROTULO, impactoTroca, type Modalidade } from '../lib/modalidade.js'
import { cfgAprovacao, definirModo, validarParaPublicacao } from '../lib/aprovacao-anuncios.js'
import * as VC from '../lib/vouchers.js'
import { semSegredos } from '../lib/integracoes.js'

const MP_API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const STATUS = ['pagamento', 'analise', 'ajustes', 'recusado', 'aprovado', 'ativo', 'encerrado']
export async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const out = (b: any, plan?: any, mpLoja = false) => {
  const d = J<any>(b.data, {})
  const expired = b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now()
  const dd = semSegredos(d) // credenciais de integração nunca vão para o navegador (ficam em empresa_integracoes)
  return { id: Number(b.id), protocolo: b.protocolo, status: expired ? 'encerrado' : b.status, planId: b.plan_id, plan: plan || null, ...dd, tipo: nicheType(dd), tipoDefinido: ['produtos', 'servicos'].includes(dd.tipo), modalidade: b.modalidade || MOD_DE(nicheType(dd)), operacao: ['produtos', 'servicos', 'ambos'].includes(dd.tipo) ? dd.tipo : 'ambos', mpLoja, payment: d.payment ? { status: d.payment.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor, expiresAt: d.payment.expiresAt } : null, lat: b.lat, lng: b.lng, expiresAt: b.expires_at, createdAt: b.created_at }
}
const clean = (v: unknown, n = 200) => str(v, n)
function fields(b: any) {
  const f: any = {
    empresa: clean(b.empresa, 80), categoria: clean(b.categoria, 60), tags: clean(b.tags, 200), titulo: clean(b.titulo, 70), texto: clean(b.texto, 180),
    link: clean(b.link, 300), zap: String(b.zap || '').replace(/\D/g, '').slice(0, 15), insta: clean(b.insta, 40).replace(/^@/, ''),
    endereco: clean(b.endereco, 160), horario: clean(b.horario, 220), sobre: clean(b.sobre, 600), contato: clean(b.contato, 80),
    palavras: String(b.palavras ?? '').split(/[,;\n]/).map((w) => clean(w, 40).toLowerCase()).filter(Boolean).slice(0, 25).join(', '),
    raio: Math.min(100, Math.max(1, Number(b.raio) || 5)),
  }
  // endereço por partes (CEP, rua, número, complemento, bairro, cidade, UF e ponto de referência): a linha `endereco` de sempre
  // é montada a partir delas (mapa, rota, busca e telas antigas continuam iguais). Sem partes, vale o texto livre (cadastros antigos).
  if (b.enderecoPartes !== undefined) {
    const pt = CEP.normalizarPartes(b.enderecoPartes)
    if (pt) { const er = CEP.problemaPartes(pt, b.enderecoPartes?.cep); if (er) fail(400, er, 'invalid', 'endereco'); f.enderecoPartes = pt; f.endereco = CEP.linhaEndereco(pt); f.referencia = pt.referencia }
    else { f.enderecoPartes = null; f.referencia = '' }
  }
  if (f.link && !/^https?:\/\/\S+\.\S+/.test(f.link)) fail(400, 'O link precisa começar com https://', 'invalid', 'link')
  if (typeof b.logo === 'string' && b.logo.startsWith('data:image/')) { if (b.logo.length >= 300_000) fail(400, 'O logotipo é grande demais. Escolha uma imagem menor.', 'too_large'); f.logo = b.logo }
  if (typeof b.capa === 'string' && b.capa.startsWith('data:image/')) { if (b.capa.length >= 600_000) fail(400, 'A capa é grande demais. Escolha uma imagem menor.', 'too_large'); f.capa = b.capa }
  if (b.capa === '') f.capa = ''
  if (b.entrega && typeof b.entrega === 'object') { const e = b.entrega; f.entrega = { retirada: e.retirada !== false, entrega: !!e.entrega, taxa: Math.max(0, Number(e.taxa) || 0), raio: Math.min(100, Math.max(0, Number(e.raio) || 3)), minimo: Math.max(0, Number(e.minimo) || 0), tempo: str(e.tempo, 40), modoTaxa: e.modoTaxa === 'km' ? 'km' : 'fixa', kmGratis: Math.max(0, Number(e.kmGratis) || 0), taxaExcedente: Math.max(0, Number(e.taxaExcedente) || 0), taxaKm: Math.max(0, Number(e.taxaKm) || 0) } }
  if (b.pagamento && typeof b.pagamento === 'object') { const p = b.pagamento; f.pagamento = { pix: !!p.pix, chavePix: str(p.chavePix, 120), mostrarChave: p.mostrarChave !== false, pixentrega: !!p.pixentrega, cartao: !!p.cartao, dinheiro: !!p.dinheiro, online: !!p.online } }
  if (f.pagamento) { // chave Pix da empresa: tipo + validação (tela nova); chaves antigas sem tipo continuam valendo como estão
    const p = b.pagamento, tipo = String(p.tipoChave || '')
    if (tipo) {
      if (!(TIPOS_CHAVE_PIX as string[]).includes(tipo)) fail(400, 'Escolha o tipo da chave: CPF/CNPJ, e-mail, telefone ou chave aleatória.', 'invalid', 'chavePix')
      f.pagamento.tipoChave = tipo
      if (f.pagamento.chavePix) { const r = normalizarChavePix(tipo, f.pagamento.chavePix); if (!r.ok) fail(400, r.erro, 'invalid', 'chavePix'); f.pagamento.chavePix = r.chave }
      if (f.pagamento.pix && !f.pagamento.chavePix) fail(400, 'Cadastre a chave Pix para ativar o Pix direto (ou desative o Pix direto).', 'invalid', 'chavePix')
    } else if (f.pagamento.chavePix) { const t = tipoProvavel(f.pagamento.chavePix); if (t) f.pagamento.tipoChave = t }
  }
  if (typeof b.mpTok === 'string') f.mpTok = b.mpTok
  if (b.tema && typeof b.tema === 'object') f.tema = normalizeTema(b.tema) // única configuração visual da empresa
  if (b.tipo === 'ambos' || (Array.isArray(b.tipo) && b.tipo.length > 1)) fail(400, 'Escolha apenas uma modalidade: produtos OU serviços.', 'modalidade_exclusiva', 'tipo')
  if (['produtos', 'servicos'].includes(b.tipo)) f.tipo = b.tipo
  if (Array.isArray(b.categorias)) f.categorias = [...new Set(b.categorias.map((c: any) => str(c, 40)).filter(Boolean))].slice(0, 30)
  if (Array.isArray(b.etiquetas)) { const vistos = new Set<string>(); f.etiquetas = b.etiquetas.slice(0, 20).map((e: any, i: number) => ({ id: str(e.id, 12) || 't' + Date.now().toString(36) + i, nome: str(e.nome, 24), cor: /^#[0-9a-f]{6}$/i.test(String(e.cor)) ? String(e.cor) : '#ef4444', tipo: ['produto', 'servico'].includes(e.tipo) ? e.tipo : 'ambos' })).filter((e: any) => { const k = e.nome.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); if (!k || vistos.has(k)) return false; vistos.add(k); return true }) } // sem etiquetas repetidas pelo nome
  if (b.horarioCfg && typeof b.horarioCfg === 'object') {
    const h = b.horarioCfg, hm = (t: unknown) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(t)) ? String(t) : null), dias: any = {}
    for (const k of ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']) { const d = h.dias?.[k] || {}; dias[k] = { ativo: !!d.ativo, abre: hm(d.abre) || '08:00', fecha: hm(d.fecha) || '18:00' } }
    f.horarioCfg = { modo: ['auto', 'aberto', 'fechado'].includes(h.modo) ? h.modo : 'auto', dias }
    // o texto do horário acompanha sempre a configuração (catálogo, busca e atendente mostram o mesmo)
    const N: any = { seg: 'Seg', ter: 'Ter', qua: 'Qua', qui: 'Qui', sex: 'Sex', sab: 'Sáb', dom: 'Dom' }
    f.horario = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'].filter((k) => dias[k].ativo).map((k) => `${N[k]} ${dias[k].abre}–${dias[k].fecha}`).join(', ') || 'Fechado'
  }
  return f
}
async function isAdsAdmin(ctx: Ctx) { const u = requireUser(ctx); if (u.role === 'user' || !effectivePermissions(u).includes('ads.manage')) fail(403, 'Sem permissão.', 'forbidden'); return u }
export async function admins() { return (await q("SELECT id, role, permissions FROM users WHERE role IN ('admin','superadmin') AND status = 'active'")).map((r) => Number(r.id)) }

// Uma contratação por modalidade e por proprietário: ocupa a modalidade enquanto estiver em pagamento, análise,
// ajustes, aprovada ou no ar (e não vencida). Vencida, encerrada, cancelada ou excluída libera de novo.
const OCUPA = ['pagamento', 'analise', 'ajustes', 'aprovado', 'ativo']
export async function contratadas(ownerId: number) {
  const rows = await q(`SELECT id, plan_id, status, expires_at, data FROM businesses WHERE owner_id = $1 AND status IN ('pagamento','analise','ajustes','aprovado','ativo','recusado')`, [ownerId])
  const now = Date.now(), out: Record<string, { id: number; status: string; empresa: string; ate: string | null }> = {}
  for (const r of rows) {
    if (r.status === 'ativo' && r.expires_at && Date.parse(r.expires_at) < now) { await q("UPDATE businesses SET status = 'encerrado', updated_at = $1 WHERE id = $2 AND status = 'ativo'", [nowIso(), r.id]); continue } // vencido: libera
    if (!OCUPA.includes(r.status) && r.status !== 'recusado') continue
    out[r.plan_id] = { id: Number(r.id), status: r.status, empresa: J<any>(r.data, {}).empresa || '', ate: r.expires_at || null }
  }
  return out
}
const hiring = new Set<string>() // trava contra duas contratações simultâneas da mesma modalidade
export async function adsPlansGet(ctx: Ctx) { await requireModule('anuncios'); const u = ctx.user && ctx.session && !ctx.session.mfa_pending ? ctx.user : null; return { plans: await plans(), contratadas: u ? await contratadas(Number(u.id)) : {}, semLimite: !!u && u.role !== 'user' && effectivePermissions(u).includes('ads.manage') } }
/** Botão "Sua empresa" do cabeçalho: liberado só com anúncio aprovado pelo administrador (consulta o banco a cada chamada). */
export async function adsPainelGet(ctx: Ctx) { const u = requireUser(ctx); return await (await import('../lib/painel-empresa.js')).painelAcesso(u.id) }
export async function adsMineGet(ctx: Ctx) {
  const u = requireUser(ctx); const ps = await plans()
  const { empresasComMcoins } = await import('./coins.js'), I = await import('../lib/integracoes.js')
  const proprias = await q("SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') ORDER BY id DESC", [u.id])
  const vinculadas = await (await import('../lib/vinculos.js')).vinculadasValidas(Number(u.id)) // empresas de outras contas vinculadas a esta sessão (troca rápida)
  const rows = [...proprias, ...vinculadas], idsVinc = new Set(vinculadas.map((b: any) => Number(b.id)))
  // em lote (antes: 4 consultas por empresa): Mercado Pago de todas as empresas e quais têm MCoins
  const mp = await I.dadosDeVarias(rows, 'mercadopago'), mc = await empresasComMcoins(rows.map((b) => Number(b.id)))
  // temMcoins: a opção MCoins de Ajustes só aparece quando o administrador criou/vinculou uma moeda a ESTA empresa
  const { refImagem } = await import('../lib/imagem-empresa.js') // logo/capa por endereço (cache do navegador), não embutidos no JSON
  // Crédito da Loja: a opção aparece em Ajustes só para as empresas PRÓPRIAS que o administrador autorizou (ou já autorizou)
  const crIds = proprias.map((b: any) => Number(b.id)), crG = crIds.length ? await (await import('../lib/credito-loja.js')).globalCfg() : null
  const cr = new Map(crIds.length ? (await q(`SELECT business_id, situacao FROM credito_empresas WHERE business_id IN (${crIds.map((_, i) => '$' + (i + 1)).join(',')})`, crIds)).map((r: any) => [Number(r.business_id), { situacao: String(r.situacao), global: !!crG?.ativo }]) : [])
  return { items: rows.map((b) => { const o: any = out(b, ps.find((p) => p.id === b.plan_id), !!mp.get(Number(b.id))?.mpTok); if (idsVinc.has(Number(b.id))) delete o.responsavel; /* dados pessoais do dono: não vão para a conta vinculada */ o.logo = refImagem(Number(b.id), 'logo', o.logo); o.capa = refImagem(Number(b.id), 'capa', o.capa); return { ...o, temMcoins: mc.has(Number(b.id)), ...(cr.has(Number(b.id)) && !idsVinc.has(Number(b.id)) ? { creditoLoja: cr.get(Number(b.id)) } : {}), ...(idsVinc.has(Number(b.id)) ? { vinculada: true } : {}) } }) }
}
/** Descrição institucional da empresa ("Sobre a empresa"). Não vale para descrição de produtos/serviços. */
export const SOBRE_MAX = 200
export async function adsPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('anuncios')
  const b = ctx.body || {}, ps = await plans(), plan = ps.find((p) => p.id === b.planId)
  if (!plan) fail(400, 'Escolha um plano.', 'invalid', 'planId')
  if (String(b.sobre ?? '').trim().length > SOBRE_MAX) fail(400, `A descrição da empresa pode ter até ${SOBRE_MAX} caracteres.`, 'invalid', 'sobre')
  const f = fields({ ...b, mpTok: undefined })
  if (!f.empresa || !f.categoria || !f.titulo) fail(400, 'Preencha o nome da empresa, o ramo e o título.', 'invalid')
  // DADOS DO RESPONSÁVEL pelo anúncio (preenchidos do perfil, editáveis): ficam no anúncio. O perfil da conta só muda se a
  // pessoa marcar "Atualizar também meus dados de perfil" — e só nome e telefone (o e-mail de acesso muda pelo suporte/painel).
  const resp = responsavelDe(b, u)
  if (resp) f.responsavel = resp
  const perfilPatch: { name?: string; whatsapp?: string } = {}
  if (b.atualizarPerfil === true && resp) {
    if (resp.nome && resp.nome !== String(u.name || '')) { if (resp.nome.length < 3 || !resp.nome.includes(' ')) fail(400, 'Para atualizar o perfil, informe o nome completo (nome e sobrenome).', 'invalid', 'contato'); perfilPatch.name = resp.nome }
    if (resp.telefone) { const wp = whatsappProblem(resp.telefone); if (wp) fail(400, wp, 'invalid', 'respTel'); const nw = normWhatsapp(resp.telefone); if (nw !== String((u as any).whatsapp || '')) perfilPatch.whatsapp = nw }
  }
  const isAdm0 = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  const cupomCod = !isAdm0 && b.cupom ? VC.normCode(b.cupom) : ''
  if (cupomCod) await VC.verificar(cupomCod, { userId: u.id, planId: plan.id, preco: Number(plan.preco), categoria: String(b.categoria || '') }) // código inválido: nada é criado e o motivo aparece
  const lockKey = `${u.id}:${plan.id}`; let novoId = 0
  if (hiring.has(lockKey)) fail(409, `A contratação do plano ${plan.nome} já está sendo registrada.`, 'plan_taken')
  hiring.add(lockKey)
  try {
  const adminFree = u.role !== 'user' && effectivePermissions(u).includes('ads.manage') // administrador publica para clientes sem esse limite
  if (!adminFree) { const c = (await contratadas(u.id))[plan.id]; if (c) fail(409, c.status === 'recusado' ? `Seu anúncio no plano ${plan.nome} foi recusado: exclua-o em Sua empresa para contratar de novo.` : `Você já contratou o plano ${plan.nome} (${c.empresa}). Renove ou edite em Sua empresa.`, 'plan_taken') }
  if (plan.nivel >= 2 && !f.zap && !f.insta) fail(400, 'Informe WhatsApp ou Instagram para este plano.', 'invalid')
  if (u.role === 'user' && (await q("SELECT id FROM businesses WHERE owner_id = $1 AND status IN ('pagamento','analise','ajustes')", [u.id])).length >= 3) fail(400, 'Você já tem propostas em análise.', 'invalid')
  let lat = Number(b.lat), lng = Number(b.lng), hasLoc = validCoords(lat, lng)
  // endereço digitado sem localização automática: tenta achar as coordenadas (se não achar, o anúncio salva igual, só sem o raio por distância)
  if (!hasLoc && f.endereco) { const g = await geoEmpresa(f); if (g) { lat = g.lat; lng = g.lng; hasLoc = true } }
  const protocolo = 'AN-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 8).toUpperCase()
  // administrador com permissão de anúncios publica direto, sem aprovação e sem pagamento
  const isAdmin = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  f.registros = [{ t: isAdmin ? 'Publicado pelo administrador (sem pagamento)' : 'Anúncio criado · aguardando pagamento', q: nowIso() }]
  const exp = isAdmin ? new Date(Date.now() + (Number(plan.dias) || 30) * 86400_000).toISOString() : null
  f.tipo = nicheType(f); const modalidade = MOD_DE(f.tipo)
  if (isAdmin) f.aprovacao = { origem: 'administrador', em: nowIso(), por: u.id } // publicado pelo próprio administrador
  else f.modoAprovacao = (await cfgAprovacao()).modo // o modo vigente no ENVIO é o que vale para este anúncio
  novoId = Number((await q('INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, lat, lng, expires_at, created_at, updated_at, modalidade) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10) RETURNING id',
    [u.id, protocolo, isAdmin ? 'ativo' : 'pagamento', plan.id, JSON.stringify(f), hasLoc ? lat : null, hasLoc ? lng : null, exp, nowIso(), modalidade]))[0].id)
  } finally { hiring.delete(lockKey) }
  let cupom: any = null
  if (cupomCod) {
    const nb = { id: novoId }
    try { const r = await VC.reservar(cupomCod, { userId: u.id, planId: plan.id, preco: Number(plan.preco), categoria: String(b.categoria || ''), businessId: Number(nb.id) }, `usuário ${u.id}`); await VC.sincronizarAnuncio(Number(nb.id)); cupom = { ok: true, mensagem: r.mensagem, valorFinal: r.final }; await audit(u.id, 'cupom.aplicar', Number(nb.id), { codigo: cupomCod }) }
    catch (e: any) { cupom = { ok: false, mensagem: `O anúncio foi criado, mas o cupom não pôde ser aplicado: ${e?.message}` } }
  }
  let perfilAtualizado: string[] = []
  if (novoId && Object.keys(perfilPatch).length) { // só depois de o anúncio existir; mesmas regras de PATCH /api/me
    const sets = Object.keys(perfilPatch).map((k, i) => `${k} = $${i + 1}`), vals = Object.values(perfilPatch)
    await q(`UPDATE users SET ${sets.join(', ')}, updated_at = $${vals.length + 1} WHERE id = $${vals.length + 2}`, [...vals, nowIso(), u.id])
    perfilAtualizado = Object.keys(perfilPatch).map((k) => (k === 'name' ? 'nome' : 'telefone'))
    await audit(u.id, 'perfil.atualizado_pelo_anuncio', u.id, { campos: perfilAtualizado, anuncio: novoId }).catch(() => {})
  }
  return { ...(await adsMineGet(ctx)), cupom, perfilAtualizado }
}
/** Nome, e-mail e telefone do responsável (formulário do anúncio). Sem nenhum dos três no pedido, nada é gravado (clientes antigos). */
function responsavelDe(b: any, u: any, edicao = false): { nome: string; email: string; telefone: string } | null {
  if (b.respEmail === undefined && b.respTel === undefined) return null
  if (edicao && !String(b.respEmail ?? '').trim() && !String(b.respTel ?? '').trim()) return null // anúncio antigo sem esses dados: a edição segue
  const nome = clean(b.contato, 80), email = String(b.respEmail ?? '').trim().toLowerCase().slice(0, 120), tel = String(b.respTel ?? '').replace(/\D/g, '')
  if (!nome) fail(400, 'Informe o seu nome.', 'invalid', 'contato')
  if (!/^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'Informe um e-mail válido para contato sobre o anúncio.', 'invalid', 'respEmail')
  if (tel.length < 10 || tel.length > 13) fail(400, 'Informe um telefone com DDD.', 'invalid', 'respTel')
  void u
  return { nome, email, telefone: tel.length <= 11 ? '55' + tel : tel }
}
export async function adsPut(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const body = { ...(ctx.body || {}) }; delete body.mpTok
  const atual = J<any>(b.data, {}).tipo
  if (body.tipo !== undefined && body.tipo !== atual) fail(body.tipo === 'ambos' ? 400 : 409, body.tipo === 'ambos' ? 'Escolha apenas uma modalidade: produtos OU serviços.' : 'Para trocar entre produtos e serviços use Ajustes → Tipo de catálogo: o sistema mostra as consequências e pede confirmação.', body.tipo === 'ambos' ? 'modalidade_exclusiva' : 'modalidade_confirmacao', 'tipo')
  delete body.tipo
  // descrição da empresa: até 200 caracteres (textos maiores já salvos continuam como estão até a empresa editar a descrição)
  if (body.sobre !== undefined && String(body.sobre).trim() !== String(J<any>(b.data, {}).sobre || '').trim() && String(body.sobre).trim().length > SOBRE_MAX) fail(400, `A descrição da empresa pode ter até ${SOBRE_MAX} caracteres.`, 'invalid', 'sobre')
  const d = { ...J<any>(b.data, {}), ...fields({ ...J<any>(b.data, {}), ...body, tipo: undefined }) }; if (atual) d.tipo = atual
  { const r = responsavelDe(body, u, true); if (r) d.responsavel = r } // edição do anúncio: só o anúncio muda (o perfil, nunca)
  d.registros = [{ t: 'Detalhes atualizados', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  let lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng), hasLoc = validCoords(lat, lng)
  const antes = String(J<any>(b.data, {}).endereco || '')
  if (!hasLoc && d.endereco && (d.endereco !== antes || b.lat == null)) { const g = await geoEmpresa(d); if (g) { lat = g.lat; lng = g.lng; hasLoc = true } } // endereço novo/alterado → coordenadas novas
  const st = b.status === 'ajustes' ? 'analise' : b.status
  await q('UPDATE businesses SET data = $1, status = $2, lat = COALESCE($3, lat), lng = COALESCE($4, lng), updated_at = $5 WHERE id = $6', [JSON.stringify(d), st, hasLoc ? lat : null, hasLoc ? lng : null, nowIso(), b.id])
  return adsMineGet(ctx)
}

/* ---------- pagamento Pix (Mercado Pago) ---------- */
async function mpToken() {
  const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }
  const tok = await unseal((mp[mp.modo] || {}).tok || '')
  return { tok, seg: await unseal((mp[mp.modo] || {}).seg || ''), modo: mp.modo }
}
async function paidSendReview(b: any, paymentId: string) {
  // cupom reservado vira resgate definitivo junto com a confirmação do pagamento (ou da ativação gratuita)
  if (await VC.confirmar(Number(b.id), paymentId)) { const nd: any = await one('SELECT data FROM businesses WHERE id = $1', [b.id]); const d0 = J<any>(b.data, {}), d1 = J<any>(nd?.data, {}); b = { ...b, data: JSON.stringify({ ...d0, cupom: d1.cupom }) } }
  if (J<any>(b.data, {}).renovacao && (J<any>(b.data, {}).aprovadoEm || b.expires_at)) return activate(b, paymentId)
  const d = J<any>(b.data, {}); d.payment = { ...(d.payment || {}), status: 'approved' }; d.pago = true
  if (d.modoAprovacao === 'automatico') {
    const v = await validarParaPublicacao({ ...b, data: JSON.stringify(d) }, await plans())
    if (v.ok) { await activate({ ...b, data: JSON.stringify(d) }, paymentId, { origem: 'automatica', em: nowIso(), validacoes: v.verificadas }); await audit(Number(b.owner_id), 'ads.approve.auto', Number(b.id), { validacoes: v.verificadas }); return }
    d.aprovacao = { origem: 'pendente', motivoAutomatica: v.falhas } // falhou alguma validação: segue para a análise manual
  }
  d.registros = [{ t: 'Pagamento confirmado · enviado para aprovação', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q("UPDATE businesses SET status = 'analise', payment_id = $1, data = $2, updated_at = $3 WHERE id = $4", [paymentId, JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Pagamento confirmado! Enviamos seu anúncio para aprovação.', body: d.empresa, link: '/x/sua-empresa', ref: `ad-paid:${b.id}:${paymentId}` })
  const plan = (await plans()).find((p) => p.id === b.plan_id)
  for (const a of await admins()) await notify(a, { type: 'ads', title: 'Novo anúncio pago para aprovar', body: `${d.empresa}${plan ? ' · plano ' + plan.nome : ''} · toque para analisar`, link: '/admin?aba=anuncios', ref: `ad-new:${b.id}:${a}` })
}
async function activate(b: any, paymentId: string, aprovacao?: any) {
  const ps = await plans(), plan = ps.find((p) => p.id === b.plan_id) || { dias: 30 }
  const d = J<any>(b.data, {}); if (aprovacao) d.aprovacao = aprovacao; d.payment = { ...(d.payment || {}), status: 'approved' }; d.aprovadoEm = nowIso(); d.renovacao = false; d.pago = true; delete d.revogado
  d.registros = [{ t: aprovacao?.origem === 'automatica' ? 'Aprovado automaticamente (validações ok) · anúncio no ar' : 'Pagamento confirmado · anúncio no ar', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  let exp = new Date(Date.now() + plan.dias * 86400_000).toISOString()
  // cupom resgatado: período gratuito ou vitalício definem até quando o anúncio fica no ar (aplicado uma única vez)
  const bn = await VC.aplicarNaAtivacao(Number(b.id), Number(plan.dias) || 30)
  if (bn) { exp = bn.exp; d.beneficio = bn.beneficio; delete d.cupom; d.registros = [{ t: `Cupom ${bn.beneficio.cupom}: ${bn.beneficio.descricao}${bn.beneficio.economia ? ` · economia de R$ ${bn.beneficio.economia.toFixed(2).replace('.', ',')}` : ''}`, q: nowIso() }, ...(d.registros || [])].slice(0, 80) }
  else if (d.beneficio?.vitalicio) exp = VC.VITALICIO_ATE // benefício vitalício já concedido nunca é perdido
  await q("UPDATE businesses SET status = 'ativo', expires_at = $1, payment_id = $2, data = $3, updated_at = $4 WHERE id = $5", [exp, paymentId, JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Seu anúncio está no ar!', body: `${d.empresa} · ${exp === VC.VITALICIO_ATE ? 'acesso vitalício' : 'até ' + exp.slice(0, 10).split('-').reverse().join('/')}`, link: '/x/sua-empresa', ref: `ad-live:${b.id}:${paymentId}` })
}
/** Confere se o valor pago cobre o valor devido AGORA (plano menos o cupom ainda aplicado). Impede, por exemplo, pagar um Pix
 *  com desconto depois de remover o cupom. Se não cobrir, o anúncio não é ativado e os administradores conferem. */
async function valorConfere(b: any, p: any) {
  const plan = (await plans()).find((x) => x.id === b.plan_id); if (!plan) return true
  const rv = await VC.recalcular(Number(b.id), plan.id, Number(plan.preco)), devido = rv ? Number(rv.final_value) : Number(plan.preco)
  const pago = Number(p?.transaction_amount); if (!Number.isFinite(pago) || pago + 0.009 >= devido) return true
  const d = J<any>(b.data, {}); d.registros = [{ t: `Pagamento de R$ ${pago.toFixed(2).replace('.', ',')} menor que o devido (R$ ${devido.toFixed(2).replace('.', ',')}) · aguardando conferência`, q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  for (const a of await admins()) await notify(a, { type: 'ads', title: 'Pagamento de anúncio com valor menor que o devido', body: `${d.empresa}: pago R$ ${pago.toFixed(2).replace('.', ',')}, devido R$ ${devido.toFixed(2).replace('.', ',')}`, link: '/admin?aba=anuncios', ref: `ad-valor:${b.id}:${p.id}` })
  console.error(`[anúncios] pagamento ${p.id} do anúncio #${b.id} menor que o devido (${pago} < ${devido}); não ativado`)
  return false
}
async function mpGet(id: string, tok: string) {
  const r = await fetch(`${MP_API()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${tok}` } })
  if (!r.ok) throw new Error('MP ' + r.status)
  return r.json() as Promise<any>
}
export async function adsPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'pagamento' && b.status !== 'aprovado') fail(400, 'Este anúncio não está aguardando pagamento.', 'invalid')
  const { tok } = await mpToken()
  if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador (Administração → Mercado Pago).', 'mp_not_configured')
  const plan = (await plans()).find((p) => p.id === b.plan_id)
  if (!plan) fail(400, 'Plano não encontrado.', 'invalid')
  const d = J<any>(b.data, {})
  // valor SEMPRE calculado no servidor: preço do plano menos o cupom reservado (se houver)
  await VC.expirarReservas()
  const rv = await VC.recalcular(Number(b.id), plan.id, Number(plan.preco)), valor = rv ? Number(rv.final_value) : Number(plan.preco)
  if (rv && valor <= 0) fail(400, 'Com este cupom a ativação é gratuita: toque em "Ativar sem pagamento".', 'cupom_gratuito')
  if (d.payment?.id && d.payment.status === 'pending' && pixValid(d.payment) && Number(d.payment.valor) === valor) return { payment: { status: 'pending', qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor, expiresAt: d.payment.expiresAt } }
  const exp = await pixExpiry()
  const r = await fetch(`${MP_API()}/v1/payments`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `${b.protocolo}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: valor, description: `Anúncio Meu Assistente · ${plan.nome}${rv ? ' · cupom ' + rv.code : ''}`, payment_method_id: 'pix', payer: { email: (() => { const e = String(J<any>(b.data, {}).responsavel?.email || ''); return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) ? e : u.email })() }, date_of_expiration: exp.iso,
      external_reference: String(b.id), notification_url: `${pub()}/api/mercadopago/webhook` }),
  })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp] erro ao criar Pix:', r.status, JSON.stringify(p)?.slice(0, 300)); fail(502, 'O Mercado Pago recusou a criação do Pix. Confira as credenciais no painel.', 'mp_error') }
  const td = p.point_of_interaction?.transaction_data || {}
  d.payment = { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', valor, expiresAt: exp.at }
  await q('UPDATE businesses SET data = $1, payment_id = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(d), String(p.id), nowIso(), b.id])
  if (p.status === 'approved') await paidSendReview({ ...b, data: JSON.stringify(d) }, String(p.id))
  return { payment: { status: p.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor, expiresAt: exp.at } }
}
export async function adsPayStatusGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'pagamento' && b.status !== 'aprovado') return { status: J<any>(b.data, {}).pago ? 'approved' : 'none', adStatus: b.status }
  const pid = J<any>(b.data, {}).payment?.id
  if (!pid) return { status: 'none' }
  const { tok } = await mpToken()
  try { const p = await mpGet(pid, tok); if (p.status === 'approved' && String(p.external_reference) === String(b.id) && (await valorConfere(b, p))) { await paidSendReview(b, pid); return { status: 'approved', adStatus: (await one('SELECT status FROM businesses WHERE id = $1', [b.id]))?.status || 'analise' } } return { status: p.status } }
  catch { return { status: 'unknown' } }
}
export async function mpWebhookPost(ctx: Ctx) {
  if (ctx.query.get('store')) return (await import('./businesses.js')).storeWebhook(ctx)
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const type = String(ctx.query.get('type') || ctx.body?.type || ctx.query.get('topic') || '')
  if (type === 'mp-connect') return (await import('./mpuser.js')).mpConnectWebhook(ctx) // vínculo/desvínculo da conexão automática (OAuth)
  if (!id || (type && type !== 'payment')) return { ok: true }
  const { tok, seg } = await mpToken()
  if (seg) { // assinatura x-signature do Mercado Pago (quando o segredo foi configurado)
    const sig = String(ctx.req.headers['x-signature'] || ''), reqId = String(ctx.req.headers['x-request-id'] || '')
    const parts = Object.fromEntries(sig.split(',').map((s) => s.trim().split('=') as [string, string]))
    const expected = createHmac('sha256', seg).update(`id:${id};request-id:${reqId};ts:${parts.ts};`).digest('hex')
    if (!parts.v1 || parts.v1.length !== expected.length || !timingSafeEqual(Buffer.from(parts.v1), Buffer.from(expected))) fail(401, 'Assinatura inválida.', 'bad_signature')
  }
  if (!tok) return { ok: true }
  try {
    const p = await mpGet(id, tok) // a confirmação vem sempre da API do Mercado Pago, nunca do corpo recebido
    if (String(p.external_reference || '').startsWith('agent:')) { if (p.status === 'approved') await (await import('./businesses.js')).activateAgent(Number(String(p.external_reference).slice(6)), id, Number(p.transaction_amount)); return { ok: true } }
    if (String(p.external_reference || '').startsWith('sub:')) { const [, uid, pid] = String(p.external_reference).split(':'); if (p.status === 'approved') await (await import('./plans.js')).activateSub(Number(uid), pid, id); return { ok: true } }
    const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(p.external_reference)])
    if (b && p.status === 'approved' && (b.status === 'pagamento' || b.status === 'aprovado') && (await valorConfere(b, p))) await paidSendReview(b, id)
  } catch (e: any) { console.error('[mp] webhook:', e?.message) }
  return { ok: true }
}

/* ---------- administração ---------- */
export async function adminAdsGet(ctx: Ctx) {
  await isAdsAdmin(ctx); const ps = await plans()
  const rows = await q("SELECT b.*, u.name AS owner_name, u.email AS owner_email FROM businesses b JOIN users u ON u.id = b.owner_id WHERE b.status <> 'institucional' ORDER BY b.id DESC LIMIT 300")
  const mp = await (await import('../lib/integracoes.js')).dadosDeVarias(rows, 'mercadopago') // em lote (antes: 2 consultas por empresa)
  return { items: rows.map((b) => ({ ...out(b, ps.find((p) => p.id === b.plan_id), !!mp.get(Number(b.id))?.mpTok), owner: { name: b.owner_name, email: b.owner_email } })) }
}
export async function adminAdsPost(ctx: Ctx) {
  const u = await isAdsAdmin(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const act = String(ctx.body?.action || ''), motivo = str(ctx.body?.motivo, 300)
  const d = J<any>(b.data, {})
  const map: Record<string, [string, string, string]> = {
    approve: ['aprovado', 'Anúncio aprovado · aguardando pagamento', 'Seu anúncio foi aprovado! Faça o pagamento para colocá-lo no ar.'],
    adjust: ['ajustes', 'A equipe pediu ajustes: ' + motivo, 'A equipe pediu ajustes no seu anúncio: ' + motivo],
    reject: ['recusado', 'Anúncio recusado: ' + motivo, 'Seu anúncio foi recusado: ' + motivo + (J<any>(b.data, {}).pago ? ' (o valor pago será devolvido)' : '')],
  }
  if (act === 'approve' && (J<any>(b.data, {}).pago || b.status === 'analise')) { await activate(b, b.payment_id || 'manual-' + u.id, { origem: 'manual', em: nowIso(), por: u.id }); await notify(Number(b.owner_id), { type: 'ads', title: 'Seu anúncio foi aprovado e está no ar!', body: J<any>(b.data, {}).empresa, link: '/x/sua-empresa', ref: `ad-approve:${b.id}` }); await audit(u.id, 'ads.approve', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) }
  if (act === 'activate') { await activate(b, 'manual-' + u.id, { origem: 'manual', em: nowIso(), por: u.id }); await audit(u.id, 'ads.activate', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) }
  if (act === 'end') { const de = J<any>(b.data, {}); de.revogado = { em: nowIso(), por: u.id }; await q("UPDATE businesses SET status = 'encerrado', data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify(de), nowIso(), b.id]); await audit(u.id, 'ads.end', Number(b.owner_id), { id: b.id }); return adminAdsGet(ctx) } // encerrar pelo admin = aprovação revogada (painel bloqueado até nova aprovação)
  const m = map[act]; if (!m) fail(400, 'Ação inválida.', 'invalid')
  if ((act === 'adjust' || act === 'reject') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  d.motivo = act === 'approve' ? '' : motivo
  d.registros = [{ t: m[1], q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q('UPDATE businesses SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [m[0], JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: m[2], body: d.empresa, link: '/x/sua-empresa', ref: `ad-${act}:${b.id}:${Date.now()}` })
  await audit(u.id, 'ads.' + act, Number(b.owner_id), { id: b.id })
  return adminAdsGet(ctx)
}
export { STATUS }

/** Subir de novo um anúncio encerrado/vencido: escolhe o plano, gera o Pix; os dados e produtos continuam salvos. */
export async function adsRenewPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const expired = b.status === 'encerrado' || (b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now())
  if (!expired) fail(400, 'Este anúncio ainda está no ar.', 'invalid')
  const plan = (await plans()).find((p) => p.id === ctx.body?.planId); if (!plan) fail(400, 'Escolha um plano.', 'invalid')
  if (u.role === 'user' && plan.id !== b.plan_id) { const dup = await one("SELECT id FROM businesses WHERE owner_id = $1 AND plan_id = $2 AND status NOT IN ('recusado','lixeira') AND id <> $3", [u.id, plan.id, b.id]); if (dup) fail(409, `Você já tem outro anúncio no plano ${plan.nome}.`, 'plan_in_use') }
  const d = J<any>(b.data, {}); delete d.payment; d.renovacao = true; d.pago = false
  d.registros = [{ t: `Renovação solicitada · plano ${plan.nome}`, q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const isAdmin = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  if (isAdmin) { await q('UPDATE businesses SET plan_id = $1, data = $2, updated_at = $3 WHERE id = $4', [plan.id, JSON.stringify(d), nowIso(), b.id]); await activate({ ...b, plan_id: plan.id, data: JSON.stringify(d) }, 'admin'); return adsMineGet(ctx) }
  await q("UPDATE businesses SET status = 'pagamento', plan_id = $1, data = $2, payment_id = NULL, updated_at = $3 WHERE id = $4", [plan.id, JSON.stringify(d), nowIso(), b.id])
  return adsMineGet(ctx)
}

/** Excluir um anúncio recusado pelo administrador (só o dono, só quando recusado). */
export async function adsDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT id, status FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b.status !== 'recusado') fail(400, 'Só anúncios recusados podem ser excluídos.', 'invalid')
  for (const al of ['anuncio', 'agente'] as const) { const rsv = await VC.reservaDo(Number(b.id), al); if (rsv) await VC.liberar(Number(rsv.id), 'anúncio excluído', `usuário ${u.id}`) }
  await q('DELETE FROM businesses WHERE id = $1', [b.id])
  return adsMineGet(ctx)
}

/** Preenche o endereço a partir da localização automática (lat/lng) ou acha as coordenadas de um endereço digitado. */
/** Coordenadas do endereço da empresa: pelas partes (mais preciso, sem complemento/CEP) e, por fim, pela linha inteira. */
async function geoEmpresa(d: any) {
  const qs = d.enderecoPartes ? CEP.consultasMapa(d.enderecoPartes) : []
  for (const t of [...qs, String(d.endereco || '')]) { const g = await geocodeAddress(t).catch(() => null); if (g) return g }
  return null
}
/** CEP → rua, bairro, cidade e UF (cadastro da empresa). Só usuário logado; limite por pessoa; o CEP não vai para o log. */
export async function cepGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (!rateLimit(`cep:${u.id}`, 40, 10 * 60_000)) fail(429, 'Muitas buscas de CEP seguidas. Aguarde alguns minutos ou preencha o endereço manualmente.', 'rate_limited')
  return CEP.buscarCep(ctx.params.cep)
}
export async function geocodePost(ctx: Ctx) {
  requireUser(ctx)
  const b = ctx.body || {}, lat = Number(b.lat), lng = Number(b.lng)
  if (validCoords(lat, lng)) {
    const r = await reverseGeocode(lat, lng)
    if (!r) return { ok: false, lat, lng, message: 'Não consegui descobrir o endereço desta localização. Digite o endereço manualmente.' }
    return { ok: true, lat, lng, endereco: r.endereco, partes: r.partes }
  }
  const t = typeof b.endereco === 'string' ? b.endereco.trim() : ''
  if (t.length < 5) fail(400, 'Digite o endereço (rua, número, bairro e cidade).', 'invalid')
  const g = await geocodeAddress(t)
  if (!g) return { ok: false, message: 'Não encontrei esse endereço no mapa. Ele será salvo mesmo assim; confira bairro e cidade se quiser aparecer nas buscas por distância.' }
  return { ok: true, lat: g.lat, lng: g.lng, endereco: t }
}

/* ---------- modalidade exclusiva do catálogo (produtos OU serviços): troca só com aviso e confirmação ---------- */
async function modBiz(ctx: Ctx) { const { u, b } = await (await import('./businesses.js')).ownBusiness(ctx); return { u, b, atual: (b.modalidade || MOD_DE(nicheType(J<any>(b.data, {})))) as Modalidade } }
const consequencias = (para: Modalidade, imp: any) => [
  para === 'products' ? 'Serviços, horários e agendamentos deixam de aparecer na página, nos anúncios, nos cards e no chat do agente.' : 'Produtos, estoque, carrinho e pedidos deixam de aparecer na página, nos anúncios, nos cards e no chat do agente.',
  `${imp.itensOcultados} ${para === 'products' ? 'serviço(s)' : 'produto(s)'} ativo(s) ficarão ocultos — nada é apagado nem convertido; voltam se você trocar de novo.`,
  imp.itensReexibidos ? `${imp.itensReexibidos} ${para === 'products' ? 'produto(s)' : 'serviço(s)'} já cadastrado(s) volta(m) a aparecer.` : '',
  imp.pedidosAtivos || imp.agendamentosAtivos ? `Há ${imp.pedidosAtivos} pedido(s) e ${imp.agendamentosAtivos} agendamento(s) em andamento: eles continuam no seu painel para você concluir, mas novos ${para === 'products' ? 'agendamentos' : 'pedidos'} deixam de ser aceitos.` : '',
  'O histórico de pedidos e agendamentos é preservado para consulta.',
].filter(Boolean)
export async function modalidadeGet(ctx: Ctx) {
  const { b, atual } = await modBiz(ctx), para: Modalidade = atual === 'products' ? 'services' : 'products'
  const imp = await impactoTroca({ query: q }, b, para)
  return { atual, rotulo: ROTULO[atual], opcoes: ['products', 'services'], troca: { para, rotulo: ROTULO[para], impacto: imp, consequencias: consequencias(para, imp) } }
}
export async function modalidadePost(ctx: Ctx) {
  const { u, b, atual } = await modBiz(ctx)
  const raw = ctx.body?.modalidade
  if (Array.isArray(raw) || raw === 'ambos' || raw === 'both') fail(400, 'Escolha apenas uma modalidade: produtos OU serviços.', 'modalidade_exclusiva')
  const para = MOD_DE(raw); if (!para) fail(400, 'Modalidade inválida: use products (produtos) ou services (serviços).', 'invalid')
  if (para === atual) return modalidadeGet(ctx)
  const imp = await impactoTroca({ query: q }, b, para)
  if (ctx.body?.confirmar !== true) return { precisaConfirmar: true, atual, para, impacto: imp, consequencias: consequencias(para, imp) } // nada muda sem confirmação
  const d = J<any>(b.data, {}); d.tipo = TIPO_DE[para]
  d.registros = [{ t: `Modalidade alterada: ${ROTULO[atual]} → ${ROTULO[para]}`, q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const r = await q('UPDATE businesses SET modalidade = $1, data = $2, updated_at = $3 WHERE id = $4 AND owner_id = $5 AND (modalidade = $6 OR modalidade IS NULL) RETURNING id', [para, JSON.stringify(d), nowIso(), b.id, u.id, atual])
  if (!r.length) fail(409, 'A modalidade foi alterada em outro lugar. Atualize e tente de novo.', 'conflict')
  await audit(u.id, 'empresa.modalidade', Number(b.id), { de: atual, para, ...imp })
  return { ok: true, ...(await modalidadeGet(ctx)) }
}

/* ---------- Modo de aprovação de anúncios (configuração global do administrador) ---------- */
export async function adsApprovalGet(ctx: Ctx) {
  await isAdsAdmin(ctx); const c = await cfgAprovacao()
  const cont = async (st: string) => Number((await q('SELECT COUNT(*) AS n FROM businesses WHERE status = $1', [st]))[0]?.n || 0)
  return { ...c, pendentes: (await cont('analise')) + (await cont('ajustes')) }
}
export async function adsApprovalPut(ctx: Ctx) {
  const u = await isAdsAdmin(ctx)
  const modo = ctx.body?.modo
  if (modo !== 'manual' && modo !== 'automatico') fail(400, 'Modo inválido: use manual ou automatico.', 'invalid')
  const atual = await cfgAprovacao()
  if (atual.modo === modo) return adsApprovalGet(ctx)
  if (ctx.body?.confirmar !== true) fail(409, 'Confirme a alteração do modo de aprovação.', 'confirmacao_necessaria')
  await definirModo(modo, { id: u.id, name: u.name })
  await audit(u.id, 'ads.modo_aprovacao', null, { de: atual.modo, para: modo })
  return adsApprovalGet(ctx)
}

/* ---------- Cupons e vouchers na ativação do anúncio ---------- */
/** Prévia na página Anunciar (antes de o anúncio existir): valida e calcula, sem consumir o cupom. */
export async function adsCupomVerificarPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const plan = (await plans()).find((p) => p.id === b.planId); if (!plan) fail(400, 'Escolha um plano antes de aplicar o cupom.', 'invalid', 'planId')
  const x = await VC.verificar(String(b.codigo || ''), { userId: u.id, planId: plan.id, preco: Number(plan.preco), categoria: String(b.categoria || '') })
  return { ok: true, codigo: x.v.code, tipo: x.v.kind, beneficio: x.beneficio, mensagem: x.mensagem, valorOriginal: x.original, valorFinal: x.final, economia: x.economia, gratuito: x.final <= 0 }
}
/** Aplicar, remover ou ativar sem pagamento (anúncio aguardando pagamento). */
export async function adsCupomPost(ctx: Ctx) {
  const u = requireUser(ctx), acao = String(ctx.body?.acao || '')
  const b: any = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const d = J<any>(b.data, {})
  if (!['pagamento', 'aprovado'].includes(b.status) || d.pago) fail(400, 'O cupom só pode ser usado enquanto o anúncio aguarda o pagamento da ativação.', 'invalid')
  const plan = (await plans()).find((p) => p.id === b.plan_id); if (!plan) fail(400, 'Plano não encontrado.', 'invalid')
  const limparPix = async () => { const x: any = await one('SELECT data FROM businesses WHERE id = $1', [b.id]); const dd = J<any>(x.data, {}); if (dd.payment?.status === 'pending') { delete dd.payment; await q('UPDATE businesses SET data = $1, payment_id = NULL, updated_at = $2 WHERE id = $3', [JSON.stringify(dd), nowIso(), b.id]) } } // o valor mudou: o próximo Pix sai com o valor novo
  if (acao === 'aplicar') {
    const r = await VC.reservar(String(ctx.body?.codigo || ''), { userId: u.id, planId: plan.id, preco: Number(plan.preco), categoria: String(d.categoria || ''), businessId: Number(b.id) }, `usuário ${u.id}`)
    await VC.sincronizarAnuncio(Number(b.id)); await limparPix(); await audit(u.id, 'cupom.aplicar', Number(b.id), { codigo: r.voucher.code })
    return { ok: true, mensagem: r.mensagem, beneficio: r.beneficio, valorOriginal: r.original, valorFinal: r.final, economia: r.economia, gratuito: r.final <= 0, ...(await adsMineGet(ctx)) }
  }
  if (acao === 'remover') {
    const r = await VC.reservaDo(Number(b.id)); if (!r) fail(400, 'Nenhum cupom aplicado a este anúncio.', 'invalid')
    await VC.liberar(Number(r.id), 'removido pelo usuário', `usuário ${u.id}`); await limparPix(); await audit(u.id, 'cupom.remover', Number(b.id), { codigo: r.code })
    return { ok: true, mensagem: 'Cupom removido. O valor voltou ao preço normal.', ...(await adsMineGet(ctx)) }
  }
  if (acao === 'ativar') {
    await VC.expirarReservas(true)
    const r = await VC.recalcular(Number(b.id), plan.id, Number(plan.preco))
    if (!r) fail(400, 'Nenhum cupom válido aplicado a este anúncio.', 'invalid')
    if (Number(r.final_value) > 0) fail(400, 'Este cupom não cobre todo o valor: pague o restante pelo Pix.', 'invalid')
    await paidSendReview(b, `cupom-${r.id}`) // sem cobrança: segue o mesmo caminho de um anúncio pago (aprovação manual ou automática)
    await audit(u.id, 'cupom.ativar_gratis', Number(b.id), { codigo: r.code })
    const st = (await one('SELECT status FROM businesses WHERE id = $1', [b.id]))?.status
    return { ok: true, status: st, mensagem: st === 'ativo' ? 'Anúncio ativado sem pagamento: já está no ar!' : 'Ativação gratuita confirmada! Seu anúncio foi enviado para aprovação.', ...(await adsMineGet(ctx)) }
  }
  fail(400, 'Ação inválida.', 'invalid')
}
/* administração */
const admNome = (u: any) => `admin ${u.id}${u.name ? ' (' + u.name + ')' : ''}`
export async function adminVouchersGet(ctx: Ctx) { await isAdsAdmin(ctx); const qp = ctx.query; return { cupons: await VC.listar({ q: qp.get('q') || '', status: qp.get('status') || '', campanha: qp.get('campanha') || '', destino: qp.get('destino') || '' }), destinos: VC.DESTINO_TXT, agentePlano: await (await import('./businesses.js')).agentPlanPublic(), planos: (await plans()).map((p) => ({ id: p.id, nome: p.nome, preco: p.preco, dias: p.dias })), categorias: [...new Set((await q("SELECT data FROM businesses WHERE status <> 'institucional'")).map((r: any) => String(J<any>(r.data, {}).categoria || '').trim()).filter(Boolean))].sort() } }
export async function adminVouchersPost(ctx: Ctx) { const u = await isAdsAdmin(ctx); const r = await VC.criar(ctx.body || {}, { id: u.id, nome: admNome(u) }); await audit(u.id, 'cupom_anuncio.criar', r[0]?.id ?? null, { codigos: r.map((x) => x.codigo).slice(0, 50), quantidade: r.length }); return { cupons: r } }
export async function adminVoucherGet(ctx: Ctx) { await isAdsAdmin(ctx); return VC.detalhe(Number(ctx.params.id)) }
export async function adminVoucherPut(ctx: Ctx) { const u = await isAdsAdmin(ctx); const id = Number(ctx.params.id); const b = ctx.body || {}; const r = b.status && Object.keys(b).length === 1 ? await VC.mudarStatus(id, String(b.status), { id: u.id, nome: admNome(u) }) : await VC.editar(id, b, { id: u.id, nome: admNome(u) }); await audit(u.id, b.status && Object.keys(b).length === 1 ? 'cupom_anuncio.status' : 'cupom_anuncio.editar', id, b); return { cupom: r } }
export async function adminVouchersHistoricoGet(ctx: Ctx) { await isAdsAdmin(ctx); const qp = ctx.query; return VC.historico({ codigo: qp.get('codigo') || '', usuario: qp.get('usuario') || '', campanha: qp.get('campanha') || '', de: qp.get('de') || '', ate: qp.get('ate') || '', status: qp.get('status') || '', alvo: qp.get('alvo') || '' }) }

/** PREENCHIMENTO AUTOMÁTICO do formulário "Anunciar": dados de contato lidos AGORA do banco (sem cópia guardada, então uma
 *  alteração no perfil ou na empresa vale na próxima criação). Fontes, nesta ordem: a empresa ativa do usuário (a mesma do
 *  seletor "Trocar de empresa"; com uma empresa só, ela mesma) e o perfil da conta (nome, WhatsApp e localização salva).
 *  Só leitura: preencher NÃO altera o cadastro, e tudo continua editável no formulário. Sem dados sensíveis (nada de
 *  credenciais, chaves, e-mail ou dados de pagamento). */
export async function adsPreenchimentoGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const user = await one('SELECT id, name, email, whatsapp FROM users WHERE id = $1', [u.id])
  const loc: any = await (await import('../lib/usermod.js')).getUM<any>(Number(u.id), 'location', null).catch(() => null)
  const proprias = await q("SELECT id, data, updated_at FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') ORDER BY id DESC", [u.id])
  const vinc = await (await import('../lib/vinculos.js')).vinculadasValidas(Number(u.id)).catch(() => [] as any[])
  const todas = [...proprias, ...vinc]
  const ctxRow = await one('SELECT business_id FROM empresa_contexto WHERE user_id = $1', [u.id])
  const emp = (ctxRow?.business_id != null ? todas.find((b: any) => Number(b.id) === Number(ctxRow.business_id)) : null) || (todas.length === 1 ? todas[0] : null)
  const x = emp ? J<any>(emp.data, {}) : {}
  const digitos = (v: any) => { let d = String(v || '').replace(/\D/g, ''); if (d.length === 10 || d.length === 11) d = '55' + d; return d.length >= 12 && d.length <= 13 ? d : '' }
  const insta = (v: any) => String(v || '').trim().replace(/^@/, '').replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/\/.*$/, '').slice(0, 60)
  const campos: Record<string, string> = {}, origem: Record<string, 'empresa' | 'perfil'> = {}
  const por = (k: string, v: any, o: 'empresa' | 'perfil') => { const s = String(v ?? '').trim(); if (s && !campos[k]) { campos[k] = s.slice(0, 200); origem[k] = o } }
  if (emp) { por('empresa', x.empresa, 'empresa'); por('contato', x.contato, 'empresa'); por('zap', digitos(x.zap), 'empresa'); por('insta', insta(x.insta), 'empresa'); por('endereco', x.endereco, 'empresa'); por('link', /^https?:\/\//i.test(String(x.link || '')) ? x.link : '', 'empresa') }
  por('contato', user?.name, 'perfil'); por('zap', digitos(user?.whatsapp), 'perfil'); por('endereco', loc && typeof loc.endereco === 'string' ? loc.endereco : loc && typeof loc.label === 'string' ? loc.label : '', 'perfil') // localização salva em "Perto de mim" (endereço confirmado pelo geocodificador)
  // responsável pelo anúncio: SEMPRE do perfil da conta autenticada (nome completo, e-mail e telefone), editável no formulário
  const responsavel = { nome: String(user?.name || '').trim(), email: String(user?.email || '').trim(), telefone: digitos(user?.whatsapp) }
  const faltando = Object.entries(responsavel).filter(([, v]) => !v).map(([k]) => k)
  return { campos, origem, responsavel, faltando, empresa: emp ? { id: Number(emp.id), nome: String(x.empresa || '') } : null, enderecoPartes: emp && x.enderecoPartes && campos.endereco === x.endereco ? x.enderecoPartes : null }
}
