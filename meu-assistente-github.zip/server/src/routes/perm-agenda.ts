// Rotas das Permissões de Agendamento: configuração (só o dono), painel de aprovação (dono e aprovadores delegados),
// resposta do cliente a um novo horário sugerido e horários para pedidos agendados. Usa os pedidos (tabela orders),
// a Agenda do dono, o Pix da loja, o CRM e as notificações que já existem — nada é duplicado.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { notify } from '../lib/notify.js'
import { audit } from '../lib/account.js'
import { withLock, registerBookingInAgenda } from '../lib/business-sync.js'
import { ownBusiness, freeSlots, createOrderPix, agentBizPublic } from './businesses.js'
import { paCfg, validarCfg, papel, pessoas, acharConta, adicionarPessoa, removerPessoa, acesso, horariosPedido, diasPedido, avisarResponsaveis, historico, brDia, ROTULO } from '../lib/perm-agenda.js'

/* ---------- configuração (somente o dono) ---------- */
async function painelCfg(b: any) {
  return {
    config: paCfg(J<any>(b.data, {})),
    aprovadores: await pessoas(Number(b.id), 'aprovador'),
    clientes: { pedidos: await pessoas(Number(b.id), 'cliente_pedidos'), servicos: await pessoas(Number(b.id), 'cliente_servicos') },
    pendentes: Number((await one("SELECT COUNT(*) AS n FROM orders WHERE business_id = $1 AND status IN ('aguardando_aprovacao','sugestao')", [b.id]))?.n || 0),
  }
}
export async function permCfgGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return painelCfg(b) }
export async function permCfgPut(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx)
  const novo = validarCfg(ctx.body || {})
  await withLock(`biz:${b.id}`, async () => {
    const cur = await one('SELECT data FROM businesses WHERE id = $1 AND owner_id = $2', [b.id, u.id]); if (!cur) fail(404, 'Empresa não encontrada.', 'not_found')
    const x = J<any>(cur!.data, {}), antes = paCfg(x)
    x.permAgenda = novo
    await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), b.id])
    await audit(u.id, 'empresa.permissoes.config', Number(b.id), { antes, depois: novo })
  })
  return painelCfg(await one('SELECT * FROM businesses WHERE id = $1', [b.id]))
}
export async function permPessoasPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx)
  const papelP = String(ctx.body?.papel || ''), acao = String(ctx.body?.acao || 'adicionar')
  if (!['aprovador', 'cliente_pedidos', 'cliente_servicos'].includes(papelP)) fail(400, 'Tipo de permissão inválido.', 'invalid')
  if (acao === 'remover') await removerPessoa(b, papelP, Number(ctx.body?.userId), u.id)
  else { const c = await acharConta(String(ctx.body?.contato || '')); await adicionarPessoa(b, papelP, c.id, u.id) }
  return painelCfg(b)
}

/* ---------- painel de aprovação (dono ou aprovador delegado) ---------- */
async function empresaComPapel(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const p = await papel(b, u.id); if (!b || !p) fail(403, 'Você não tem permissão para ver as solicitações desta empresa.', 'forbidden')
  return { u, b: b!, papel: p! }
}
const solOut = (o: any) => { const d = J<any>(o.data, {}); return {
  id: Number(o.id), status: o.status, statusLabel: ROTULO[o.status] || o.status, cliente: d.cliente, telefone: d.telefone || '', servico: d.servico, servicoId: d.servicoId,
  data: d.data, hora: d.hora, duracao: Number(d.duracao) || 30, obs: d.obs || '', enviadoEm: o.created_at, atualizadoEm: o.updated_at, sugestao: d.sugestao || null, motivo: d.motivo || '',
  sinal: d.sinal ?? null, restante: d.restante ?? null, canal: d.canal === 'agente' ? 'Atendimento automático' : 'App', reservaAte: d.reservaAte || null, historico: d.historico || [],
  conta: !d.guest, pago: !!d.pago, dataOriginal: d.dataOriginal || null } }

export async function minhasEmpresasSolicitacoesGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const ids = new Set<number>([...(await q("SELECT id FROM businesses WHERE owner_id = $1", [u.id])).map((r) => Number(r.id)), ...(await q("SELECT business_id FROM business_permissions WHERE user_id = $1 AND role = 'aprovador'", [u.id])).map((r) => Number(r.business_id))])
  const out: any[] = []
  for (const id of ids) {
    const b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [id]); if (!b) continue
    const x = J<any>(b.data, {}), c = paCfg(x)
    const n = Number((await one("SELECT COUNT(*) AS n FROM orders WHERE business_id = $1 AND status = 'aguardando_aprovacao'", [id]))?.n || 0)
    if (!c.servicos.ativo && !n && Number(b.owner_id) !== u.id) continue
    out.push({ id, empresa: x.empresa, papel: Number(b.owner_id) === u.id ? 'dono' : 'aprovador', ativo: c.servicos.ativo, pendentes: n })
  }
  return { empresas: out }
}
export async function solicitacoesGet(ctx: Ctx) {
  const { b, papel: p } = await empresaComPapel(ctx)
  const f = String(ctx.query.get('filtro') || 'pendentes')
  const st = f === 'todas' ? "('aguardando_aprovacao','sugestao','aceito','recusado','cancelado','concluido')" : "('aguardando_aprovacao','sugestao')"
  const rows = (await q(`SELECT * FROM orders WHERE business_id = $1 AND status IN ${st} ORDER BY id DESC LIMIT 200`, [b.id])).filter((o) => J<any>(o.data, {}).solicitacao)
  // imagem do serviço (cadastro do próprio serviço, mesma regra dos pedidos): o item 0 da solicitação é o serviço
  const { comFotos } = await import('./businesses.js'), comF = await comFotos(rows.map((o) => ({ id: Number(o.id), itens: J<any>(o.data, {}).itens || [] })), rows)
  const fotoDe = new Map(comF.map((x) => [x.id, (x.itens || [])[0]?.foto || null]))
  return { empresa: J<any>(b.data, {}).empresa, papel: p, ativo: paCfg(J<any>(b.data, {})).servicos.ativo, items: rows.map((o) => ({ ...solOut(o), foto: fotoDe.get(Number(o.id)) || null })) }
}
export async function solicitacaoHorariosGet(ctx: Ctx) {
  const { b } = await empresaComPapel(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), b.id]); if (!o) fail(404, 'Solicitação não encontrada.', 'not_found')
  const date = String(ctx.query.get('data') || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) fail(400, 'Data inválida.', 'invalid')
  return { horarios: await freeSlots(b, { duracao: J<any>(o!.data, {}).duracao }, date, Number(o!.id)) }
}

/** Confirma (aprovação, ou aceite do cliente a um horário sugerido): entra na Agenda do dono e, se houver sinal, gera o Pix agora. */
async function confirmar(b: any, oid: number) {
  await registerBookingInAgenda(oid).catch((e) => console.error('[agenda]', e?.message))
  let o = (await one('SELECT * FROM orders WHERE id = $1', [oid]))!; const d = J<any>(o.data, {}), x = J<any>(b.data, {})
  let pix = false
  if (d.sinalAposAprovacao && (await (await import('./mpuser.js')).mpPronto(Number(b.id))) && Number(o.total) > 0 && !d.pago) {
    d.pagamento = 'online'; await q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(d), oid]); o = (await one('SELECT * FROM orders WHERE id = $1', [oid]))!
    const email = d.guest ? '' : String((await one('SELECT email FROM users WHERE id = $1', [o.customer_id]))?.email || '')
    try { await createOrderPix(b, o, email, Number(o.total)); pix = true } catch { d.pagamento = 'local'; await q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(d), oid]) }
  }
  return pix
}

export async function solicitacaoPost(ctx: Ctx) {
  const { u, b, papel: p } = await empresaComPapel(ctx)
  const acao = String(ctx.body?.acao || ''), oid = Number(ctx.params.oid)
  if (!['aprovar', 'recusar', 'sugerir'].includes(acao)) fail(400, 'Ação inválida.', 'invalid')
  const ator = `${p === 'dono' ? 'proprietário' : 'aprovador'} ${u.name}`.trim()
  const res = await withLock(`biz:${b.id}`, async () => { // decisão + revalidação do horário juntas: dois aprovadores nunca confirmam o mesmo horário
    const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [oid, b.id]); if (!o) fail(404, 'Solicitação não encontrada.', 'not_found')
    const d = J<any>(o!.data, {}); if (!d.solicitacao) fail(400, 'Este agendamento não é uma solicitação.', 'invalid')
    const x = J<any>(b.data, {})
    if (acao === 'aprovar') {
      if (o!.status !== 'aguardando_aprovacao') fail(409, o!.status === 'sugestao' ? 'Já existe um novo horário sugerido: aguarde a resposta do cliente.' : 'Esta solicitação já foi decidida.', 'already_decided')
      const livres = await freeSlots(b, { duracao: d.duracao }, d.data, oid) // nova validação na hora da aprovação
      if (!livres.includes(d.hora)) fail(409, 'Esse horário não está mais disponível (já foi confirmado outro agendamento ou o horário passou). Sugira outro horário ao cliente.', 'slot_taken')
      historico(d, 'aprovado', ator); delete d.reservaAte; d.decididoPor = { id: u.id, papel: p, em: nowIso() }
      await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['aceito', JSON.stringify(d), nowIso(), oid])
      return { o: o!, d, de: o!.status, para: 'aceito' }
    }
    if (acao === 'recusar') {
      if (!['aguardando_aprovacao', 'sugestao'].includes(o!.status)) fail(409, 'Esta solicitação já foi decidida.', 'already_decided')
      const motivo = str(ctx.body?.motivo, 200).trim(); if (!motivo) fail(400, 'Informe o motivo (o cliente vê).', 'invalid', 'motivo')
      historico(d, 'recusado', ator, motivo); d.motivo = motivo; delete d.reservaAte; d.decididoPor = { id: u.id, papel: p, em: nowIso() }
      await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['recusado', JSON.stringify(d), nowIso(), oid])
      await (await import('../lib/catalogo.js')).devolverPedido(Number(oid)).catch((e) => console.error('[estoque]', e?.message)) // unidades reservadas voltam ao estoque
      return { o: o!, d, de: o!.status, para: 'recusado', motivo }
    }
    // sugerir outro horário: proposta ao cliente, nunca confirmação
    if (!['aguardando_aprovacao', 'sugestao'].includes(o!.status)) fail(409, 'Esta solicitação já foi decidida.', 'already_decided')
    const data = String(ctx.body?.data || ''), hora = String(ctx.body?.hora || '')
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !/^\d{2}:\d{2}$/.test(hora)) fail(400, 'Escolha a data e o horário sugeridos.', 'invalid')
    if (data === d.data && hora === d.hora) fail(400, 'Escolha um horário diferente do solicitado (ou aprove a solicitação).', 'invalid')
    if (!(await freeSlots(b, { duracao: d.duracao }, data, oid)).includes(hora)) fail(409, 'Esse horário não está disponível. Escolha outro.', 'slot_taken')
    const mensagem = str(ctx.body?.mensagem, 200).trim(), cfg = paCfg(x).servicos
    d.sugestao = { data, hora, mensagem, em: nowIso(), por: p }
    if (cfg.reservaMin > 0) d.reservaAte = new Date(Date.now() + cfg.reservaMin * 60_000).toISOString(); else delete d.reservaAte
    historico(d, 'novo horário sugerido', ator, `${brDia(data)} às ${hora}${mensagem ? ' · ' + mensagem : ''}`)
    await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['sugestao', JSON.stringify(d), nowIso(), oid])
    return { o: o!, d, de: o!.status, para: 'sugestao', sugestao: d.sugestao }
  })
  const { o, d } = res as any
  await audit(u.id, `empresa.agendamento.${acao === 'aprovar' ? 'aprovado' : acao === 'recusar' ? 'recusado' : 'sugerido'}`, Number(b.id), { pedido: oid, papel: p, de: res.de, para: res.para, horario: `${d.data} ${d.hora}`, ...(res.motivo ? { motivo: res.motivo } : {}), ...(res.sugestao ? { sugerido: `${res.sugestao.data} ${res.sugestao.hora}` } : {}) })
  let pix = false
  await (await import('../lib/lojas-conectadas.js')).avisarAtualizacao(b, oid, res.para, u.id, u.name || '') // dono e centrais conectadas (menos quem decidiu)
  if (res.para === 'aceito') pix = await confirmar(b, oid)
  if (!d.guest) {
    const msg = res.para === 'aceito' ? { title: `Agendamento #${oid} confirmado`, body: `${d.empresa} · ${d.servico} · ${brDia(d.data)} às ${d.hora}${pix ? ' · pague o sinal pelo Pix em Meus pedidos' : ''}` }
      : res.para === 'recusado' ? { title: `Sua solicitação #${oid} não foi aprovada`, body: `${d.empresa} · ${res.motivo}` }
      : { title: `${d.empresa} sugeriu outro horário`, body: `${d.servico} · ${brDia(res.sugestao.data)} às ${res.sugestao.hora}. Toque para aceitar ou recusar.` }
    await notify(Number(o.customer_id), { type: 'order', ...msg, link: '/x/pedidos', ref: `solic:${oid}:${res.para}:${Date.now()}` })
  }
  return { ok: true, item: solOut(await one('SELECT * FROM orders WHERE id = $1', [oid])), pix }
}

/* ---------- cliente responde ao horário sugerido ---------- */
async function responder(b: any, oid: number, aceitar: boolean, quem: { id: number | null; rotulo: string }) {
  const r = await withLock(`biz:${b.id}`, async () => {
    const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [oid, b.id]); if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
    const d = J<any>(o!.data, {}); if (o!.status !== 'sugestao' || !d.sugestao) fail(409, 'Não há horário sugerido aguardando sua resposta.', 'invalid')
    const sug = d.sugestao
    if (!aceitar) {
      historico(d, 'cliente recusou o horário sugerido', quem.rotulo); d.motivo = 'O cliente não aceitou o horário sugerido.'; delete d.reservaAte
      await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['cancelado', JSON.stringify(d), nowIso(), oid])
      await (await import('../lib/catalogo.js')).devolverPedido(Number(oid)).catch((e) => console.error('[estoque]', e?.message)) // unidades reservadas voltam ao estoque
      return { d, para: 'cancelado' }
    }
    if (!(await freeSlots(b, { duracao: d.duracao }, sug.data, oid)).includes(sug.hora)) { // o horário foi ocupado: volta para a empresa decidir
      historico(d, 'horário sugerido ficou indisponível', 'sistema', `${brDia(sug.data)} às ${sug.hora}`); delete d.sugestao; delete d.reservaAte
      await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['aguardando_aprovacao', JSON.stringify(d), nowIso(), oid])
      return { d, para: 'aguardando_aprovacao', ocupado: true }
    }
    d.dataOriginal = { data: d.data, hora: d.hora }; d.data = sug.data; d.hora = sug.hora; delete d.sugestao; delete d.reservaAte
    historico(d, 'cliente aceitou o horário sugerido', quem.rotulo, `${brDia(d.data)} às ${d.hora}`)
    await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', ['aceito', JSON.stringify(d), nowIso(), oid])
    return { d, para: 'aceito' }
  })
  const d = r.d
  await audit(quem.id, `empresa.agendamento.cliente_${aceitar ? 'aceitou' : 'recusou'}_sugestao`, Number(b.id), { pedido: oid, para: r.para })
  let pix = false
  if (r.para === 'aceito') pix = await confirmar(b, oid)
  await avisarResponsaveis(b, r.para === 'aceito' ? { title: `Agendamento #${oid} confirmado pelo cliente`, body: `${d.cliente} aceitou ${brDia(d.data)} às ${d.hora} · ${d.servico}`, ref: `solic-resp:${oid}` }
    : r.para === 'cancelado' ? { title: `Cliente recusou o horário sugerido (#${oid})`, body: `${d.cliente} · ${d.servico}`, ref: `solic-resp:${oid}` }
    : { title: `Horário sugerido ficou indisponível (#${oid})`, body: `${d.cliente} aceitou, mas o horário foi ocupado. Decida de novo.`, ref: `solic-resp:${oid}:${Date.now()}` })
  if (r.ocupado) fail(409, 'Esse horário acabou de ser ocupado. A empresa foi avisada e vai responder de novo.', 'slot_taken')
  return { ok: true, status: r.para, statusLabel: ROTULO[r.para] || r.para, pix }
}
export async function sugestaoClientePost(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id]); if (!o || J<any>(o.data, {}).guest) fail(404, 'Pedido não encontrado.', 'not_found')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [o!.business_id])
  return responder(b, Number(o!.id), ctx.body?.aceitar === true, { id: u.id, rotulo: 'cliente' })
}
export async function sugestaoAgentePost(ctx: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), b!.id]); const d = o ? J<any>(o.data, {}) : null
  if (!o || !d.guestKey || d.guestKey !== String(ctx.query.get('k') || ctx.body?.k || '')) fail(404, 'Pedido não encontrado.', 'not_found')
  return responder(b, Number(o!.id), ctx.body?.aceitar === true, { id: ctx.user?.id || null, rotulo: 'cliente (atendimento automático)' })
}

/* ---------- o que o cliente pode fazer (app e agente) e horários de pedido agendado ---------- */
async function permissoesVisitante(b: any, uid: number | null) {
  const pe = await acesso(b, 'pedidos', uid), se = await acesso(b, 'servicos', uid)
  return { pedidos: { ok: pe.ok, motivo: pe.ok ? '' : (pe.codigo === 'desligado' ? '' : pe.motivo), dias: pe.ok ? diasPedido(b) : [] }, servicos: { ok: se.ok, modo: se.modo || null, motivo: se.ok ? '' : se.motivo } }
}
export async function permVisitanteGet(ctx: Ctx) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  return permissoesVisitante(b, ctx.user?.id || null)
}
export async function pedidoHorariosGet(ctx: Ctx) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  const ac = await acesso(b, 'pedidos', ctx.user?.id || null); if (!ac.ok) fail(403, ac.motivo || 'Agendamento de pedidos indisponível.', ac.codigo || 'forbidden')
  return { horarios: horariosPedido(b, String(ctx.query.get('data') || '')) }
}
export async function agentePermGet(ctx: Ctx) {
  const { b } = await agentBizPublic(Number(ctx.params.id), ctx)
  return permissoesVisitante(b, ctx.user?.id || null)
}
export async function agentePedidoHorariosGet(ctx: Ctx) {
  const { b } = await agentBizPublic(Number(ctx.params.id), ctx)
  const ac = await acesso(b, 'pedidos', ctx.user?.id || null); if (!ac.ok) fail(403, ac.motivo || 'Agendamento de pedidos indisponível.', ac.codigo || 'forbidden')
  return { horarios: horariosPedido(b, String(ctx.query.get('data') || '')) }
}
