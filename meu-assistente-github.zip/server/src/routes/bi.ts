// Inteligência empresarial: rota fina (só leitura) usada pelo cartão do chat. Exige o DONO da empresa (validado no serviço).
import type { Ctx } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import * as B from '../lib/bi.js'

export async function biGet(ctx: Ctx) {
  const u = requireUser(ctx), bid = Number(ctx.params.id), tipo = String(ctx.query.get('tipo') || 'resumo')
  const spec = { periodo: ctx.query.get('periodo') || undefined, de: ctx.query.get('de') || undefined, ate: ctx.query.get('ate') || undefined }, tz = settingsOf(u).timezone
  if (tipo === 'comparar') return B.comparar(u.id, bid, spec, tz)
  if (tipo === 'analise') return B.analise(u.id, bid, spec, tz)
  return B.publico(await B.resumo(u.id, bid, spec, tz))
}
