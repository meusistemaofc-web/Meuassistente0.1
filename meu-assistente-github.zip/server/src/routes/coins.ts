// MCoins: painel do administrador, Mercado, carteira do cliente e consulta no checkout.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import * as C from '../lib/coins.js'

function admin(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
const nm = (u: any) => `admin ${u.id}`

/** Painel: configuração, modelos, moedas (com números e relatório por empresa) e empresas disponíveis. */
export async function panelCoinsGet(ctx: Ctx) {
  admin(ctx)
  const moedas = await Promise.all((await C.listCoins()).map((c) => C.stats(c.id)))
  const emp = (await q("SELECT id, data, status FROM businesses ORDER BY id DESC LIMIT 500")).map((b: any) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa || `Empresa #${b.id}`, status: b.status, temMoeda: moedas.some((m) => m.businessId === Number(b.id)) }))
  return { config: await C.coinsCfg(), modelos: C.MODELOS, moedas, empresas: emp,
    resumo: { moedas: moedas.length, ativas: moedas.filter((m) => m.status === 'ativa').length, distribuidas: moedas.reduce((a, m) => a + m.distribuidas, 0), utilizadas: moedas.reduce((a, m) => a + m.utilizadas, 0), descontoReais: Math.round(moedas.reduce((a, m) => a + m.descontoConcedidoReais, 0) * 100) / 100 } }
}
export async function panelCoinGet(ctx: Ctx) {
  admin(ctx); const id = Number(ctx.params.id), c = await C.coinById(id); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  return { moeda: await C.stats(id), serie: await C.series(id, Math.min(180, Math.max(7, Number(ctx.query.get('dias')) || 30))), historico: await C.ledger(id), saldos: await C.topBalances(id), alteracoes: await C.changes(id) }
}
export async function panelCoinsPost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, actor = nm(u)
  switch (b.action) {
    case 'config': { const cfg = await C.saveCoinsCfg(b); await audit(u.id, 'coins.config', null, { ativo: cfg.ativo, adesao: cfg.adesao.ativo }); return { ok: true, config: cfg } }
    case 'create': { const c = await C.createCoin(b, actor, u.id); await audit(u.id, 'coins.create', c.id, { empresa: c.businessId }); return { ok: true, moeda: c } }
    case 'update': { const c = await C.updateCoin(Number(b.id), b, actor); await audit(u.id, 'coins.update', c.id, {}); return { ok: true, moeda: c } }
    case 'status': { const c = await C.setStatus(Number(b.id), String(b.status), actor); await audit(u.id, 'coins.status', c.id, { status: c.status }); return { ok: true, moeda: c } }
    case 'distribuir': {
      const email = String(b.email || '').trim().toLowerCase(), cli = await one('SELECT id FROM users WHERE LOWER(email) = $1', [email]); if (!cli) fail(404, 'Nenhum cliente com este e-mail.', 'not_found', 'email')
      const idem = String(b.idem || '').trim().slice(0, 60); if (!idem) fail(400, 'Informe uma chave da operação para evitar distribuição em duplicidade.', 'invalid', 'idem')
      const r = await C.distribuir(Number(b.id), Number(cli!.id), Math.floor(Number(b.quantidade)), 'admin:' + idem, u.id, String(b.nota || '').slice(0, 200))
      await audit(u.id, 'coins.distribuir', Number(b.id), { cliente: Number(cli!.id), quantidade: r.quantidade, duplicado: r.duplicado }); return { ...r }
    }
    default: fail(400, 'Ação inválida.', 'invalid')
  }
}

/** Mercado: moedas publicadas, só quando o sistema está ligado e existe ao menos uma. */
export async function coinsMarketGet(ctx: Ctx) {
  requireUser(ctx)
  const cfg = await C.coinsCfg(); if (!cfg.ativo) return { visivel: false, itens: [] }
  const l = await C.listCoins(true); if (!l.length) return { visivel: false, itens: [] }
  const itens = await Promise.all(l.map(async (c) => ({ ...(await C.stats(c.id)), serie: (await C.series(c.id, 30)).map((p) => p.acumDistribuido) })))
  return { visivel: true, itens }
}
export async function coinPublicGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id), c: any = await C.coinById(id), cfg = await C.coinsCfg()
  if (!c || !cfg.ativo || c.status !== 'ativa') fail(404, 'Moeda indisponível.', 'not_found')
  const hist = (await C.ledger(id, 30)).map((h) => ({ tipo: h.tipo, quantidade: h.quantidade, em: h.em })) // sem dados de clientes
  return { moeda: await C.stats(id), serie: await C.series(id, 30), recentes: hist, meuSaldo: await C.balanceOf(id, u.id), regras: `1 ${c.simbolo} = R$ ${c.desconto.toFixed(2).replace('.', ',')} de desconto em compras na empresa ${c.empresa}. Crédito promocional: não é negociável, transferível nem sacável.` }
}
export async function coinsWalletGet(ctx: Ctx) { const u = requireUser(ctx); return { ativo: (await C.coinsCfg()).ativo, ...(await C.wallet(u.id)) } }
/** Checkout: a moeda da empresa e o saldo do cliente. */
export async function businessCoinGet(ctx: Ctx) {
  const u = requireUser(ctx), cfg = await C.coinsCfg(), c = await C.coinOfBusiness(Number(ctx.params.id))
  if (!cfg.ativo || !c || c.status !== 'ativa') return { moeda: null }
  return { moeda: { id: c.id, nome: c.nome, simbolo: c.simbolo, desconto: c.desconto, modelo: c.modeloInfo, cor1: c.cor1, cor2: c.cor2, logo: c.logo }, saldo: await C.balanceOf(c.id, u.id) }
}
