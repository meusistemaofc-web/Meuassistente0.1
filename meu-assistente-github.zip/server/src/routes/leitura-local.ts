// Painel: política de leitura de comprovantes (leitura local pela Central de Mídias × IA) e estado da central.
// Não liga nem desliga a central (isso é feito no servidor, com MIDIA_URL/MIDIA_TOKEN); só escolhe a ordem de uso.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { centralConfigurada, centralDisponivel } from '../lib/central-midia.js'
import { requirePanel } from './panel.js'
import { politicaLeitura } from '../ai/leitura-local.js'

export async function panelLeituraLocalGet(ctx: Ctx) {
  await requirePanel(ctx)
  return { politica: await politicaLeitura(), central: { configurada: centralConfigurada(), disponivel: await centralDisponivel() } }
}
export async function panelLeituraLocalPut(ctx: Ctx) {
  await requirePanel(ctx, true)
  const p = String(ctx.body?.politica || '')
  if (!['local_primeiro', 'ia_primeiro', 'so_local'].includes(p)) fail(400, 'Política inválida.', 'invalid')
  await setConfig('leitura_local', { ...(await getConfig<any>('leitura_local', {})), politica: p })
  return panelLeituraLocalGet(ctx)
}
