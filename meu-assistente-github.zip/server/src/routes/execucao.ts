// Fase 8 — execuções do próprio usuário (acompanhar, confirmar, autorizar, cancelar, desfazer, autonomia) e painel do
// administrador (indicadores agregados e níveis de autonomia). Cada usuário só vê e aciona as PRÓPRIAS execuções.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { setConfig } from '../lib/settings.js'
import { q } from '../db/index.js'
import * as EX from '../ai/execucao.js'

export async function meExecucoesGet(ctx: Ctx) {
  const u = requireUser(ctx), rows = (await q('SELECT id FROM executions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50', [u.id])) as any[]
  const lista = []; for (const r of rows) lista.push(EX.publico(await EX.obter(u.id, String(r.id))))
  return { execucoes: lista, autonomia: await EX.autonomia(u.id), niveis: EX.NIVEL_NOME }
}
export async function meExecucaoGet(ctx: Ctx) { const u = requireUser(ctx); return EX.publico(await EX.obter(u.id, String(ctx.params.id))) }
export async function meExecucaoAcao(ctx: Ctx) {
  const u = requireUser(ctx), id = String(ctx.params.id), acao = String(ctx.params.acao)
  const EP = await import('../ai/execucao-planos.js')
  if (acao === 'confirmar' || acao === 'autorizar') {
    if (acao === 'autorizar' && String(ctx.body?.codigo || '').toUpperCase() !== id) fail(400, `Para autorizar, digite o código ${id}.`, 'invalid', 'codigo')
    const e = await EX.aprovar(u, id, acao); await audit(u.id, 'execucao.' + acao, null, { id, nivel: e.level })
    const texto = await EP.iniciarExecucao(u, e); return { ok: true, mensagem: texto.replace(/⟦[^⟧]*⟧/g, '').trim(), execucao: EX.publico(await EX.obter(u.id, id)) }
  }
  if (acao === 'cancelar') { const e: any = await EX.cancelar(u, id); await audit(u.id, 'execucao.cancelar', null, { id }); return { ok: true, execucao: EX.publico(await EX.obter(u.id, e.id)) } }
  if (acao === 'reverter') { const r = await EX.reverter(u, id); await audit(u.id, 'execucao.reverter', null, { id, desfeitas: r.desfeitas }); return { ok: true, desfeitas: r.desfeitas, semReversao: r.semReversao, falhas: r.falhas, execucao: EX.publico(await EX.obter(u.id, id)) } }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function meAutonomiaPut(ctx: Ctx) { const u = requireUser(ctx); await EX.salvarAutonomia(u.id, String(ctx.body?.autonomia || '')); await audit(u.id, 'execucao.autonomia', null, { autonomia: ctx.body?.autonomia }); return { ok: true, autonomia: await EX.autonomia(u.id) } }

const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelExecucaoGet(ctx: Ctx) {
  admin(ctx)
  const ops = Object.values(EX.OPERACOES).map((o) => ({ id: o.id, nome: o.nome, nivelMinimo: o.nivel, reversivel: o.reversivel, repetivel: o.repetivel }))
  const OB = (await import('../ai/execucao-planos.js')).OBJETIVOS.map((o) => ({ id: o.id, nome: o.nome }))
  return { ...(await EX.indicadores()), operacoes: ops, objetivos: OB }
}
export async function panelExecucaoPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, atual = await EX.execCfg(), novo: any = { ...atual, niveis: { ...atual.niveis } }, mud: any = {}
  for (const k of ['ativo', 'segundoPlano'] as const) if (b[k] !== undefined) { if (typeof b[k] !== 'boolean') fail(400, `Informe ${k}: true ou false.`, 'invalid', k); novo[k] = mud[k] = b[k] }
  if (b.maxPorUsuario !== undefined) { const n = Number(b.maxPorUsuario); if (!Number.isInteger(n) || n < 1 || n > 5) fail(400, 'Execuções simultâneas por usuário: de 1 a 5.', 'invalid', 'maxPorUsuario'); novo.maxPorUsuario = mud.maxPorUsuario = n }
  if (b.operacao !== undefined) {
    const op = EX.OPERACOES[String(b.operacao)], n = Number(b.nivel)
    if (!op || ![1, 2, 3].includes(n)) fail(400, 'Operação ou nível inválido.', 'invalid', 'operacao')
    // o administrador pode EXIGIR mais controle; nunca baixar o mínimo da operação (exclusões e pagamentos ficam no nível 3)
    if (n < op.nivel) fail(400, `O nível mínimo de "${op.nome}" é ${op.nivel}: não dá para reduzir.`, 'invalid', 'nivel')
    if (n === op.nivel) delete novo.niveis[op.id]; else novo.niveis[op.id] = n
    mud[op.id] = n
  }
  if (!Object.keys(mud).length) fail(400, 'Nada para alterar.', 'invalid')
  await setConfig('execucao', novo); await audit(u.id, 'execucao.config', null, mud)
  return panelExecucaoGet(ctx)
}
