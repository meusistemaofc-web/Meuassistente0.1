// BusinessActivityCounters — fonte ÚNICA dos contadores de pedidos e agendamentos (menu lateral do Chat e "Sua empresa" > Pedidos/Agenda).
// Lê os registros oficiais (tabela `orders`; agendamento = data.tipo === 'agendamento') e preserva a semântica que já existia no menu lateral:
//  • "novos" = pedidos/agendamentos recebidos pela empresa do usuário que ainda aguardam a decisão dele (status 'novo') e, se o pagamento é online, já pagos;
//  • "meus ativos" = pedidos/agendamentos do próprio usuário como cliente que ainda estão em andamento.
// Não conta total de registros, não conta notificações e não usa valores fixos. Respeita dono da empresa (isolamento) e o nível do plano (≥ 4 = loja com pedidos).
import type { Ctx } from '../lib/http.js'
import { q, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { plans } from './ads.js'

const EM_ANDAMENTO = ['novo', 'aceito', 'preparo', 'saiu', 'pronto']
const ehAgendamento = (d: any) => d?.tipo === 'agendamento'

export const BusinessActivityCounters = {
  /** Totais de uma pessoa: o que a(s) empresa(s) dela precisa(m) atender e o que ela mesma tem em andamento como cliente. */
  async daPessoa(userId: number) {
    const ps = await plans()
    const empresas: Record<string, { pedidos: number; agendamentos: number }> = {}
    let pedidos = 0, agendamentos = 0
    for (const b of await q("SELECT id, plan_id FROM businesses WHERE owner_id = $1 AND status = 'ativo'", [userId])) {
      const nivel = Number(ps.find((p) => p.id === b.plan_id)?.nivel || 1); if (nivel < 4) continue
      const e = { pedidos: 0, agendamentos: 0 }
      for (const o of await q("SELECT data FROM orders WHERE business_id = $1 AND status = 'novo'", [b.id])) {
        const d = J<any>(o.data, {}); if (d.pagamento === 'online' && !d.pago) continue // aguardando pagamento online não é "novo" ainda
        if (ehAgendamento(d)) e.agendamentos++; else e.pedidos++
      }
      empresas[String(b.id)] = e; pedidos += e.pedidos; agendamentos += e.agendamentos
    }
    const meus = { pedidos: 0, agendamentos: 0 }
    for (const o of await q(`SELECT data FROM orders WHERE customer_id = $1 AND status IN (${EM_ANDAMENTO.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...EM_ANDAMENTO])) {
      const d = J<any>(o.data, {}); if (d.guest) continue
      if (ehAgendamento(d)) meus.agendamentos++; else meus.pedidos++
    }
    return { empresas, pedidos, agendamentos, total: pedidos + agendamentos, meus: { ...meus, total: meus.pedidos + meus.agendamentos } }
  },
}
export async function countersGet(ctx: Ctx) { const u = requireUser(ctx); return BusinessActivityCounters.daPessoa(u.id) }
