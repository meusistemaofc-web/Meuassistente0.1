// Calendário e funcionamento empresarial: telas do dono (Sua empresa → Ajustes) e chave geral da capacidade (administrador).
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { withLock } from '../lib/business-sync.js'
import { ownBusiness } from './businesses.js'
import * as K from '../lib/calendar.js'
import { alertas, agendaIAOn } from '../ai/agenda-ia.js'

const hojeBR = () => new Date(Date.now() - 3 * 3600_000).toISOString().slice(0, 10)
async function view(b: any) {
  const x = J<any>(b.data, {}), cal = K.calendarioDe(x), hoje = hojeBR()
  const feriados = K.proximosFeriados(hoje, 120, cal.feriadosProprios).map((f) => { const e = K.diaEfetivo(x, f.data); return { ...f, aberto: e.aberto, abre: e.abre, fecha: e.fecha, decidido: e.origem !== 'semana', origem: e.origem, diaSemana: e.diaSemana } })
  const proximos = Array.from({ length: 7 }, (_, i) => K.diaEfetivo(x, K.addDays(hoje, i)))
  return { ativo: await agendaIAOn(), calendario: cal, feriados, proximos, alertas: await alertas(b, x, hoje, 60), hoje }
}
export async function calendarGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return view(b) }
export async function calendarPut(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), a = ctx.body || {}
  await withLock(`biz:${b.id}`, async () => {
    const row = (await q('SELECT data FROM businesses WHERE id = $1', [b.id]))[0], x = J<any>(row.data, {}), cal = K.calendarioDe(x)
    switch (a.action) {
      case 'config': {
        const n = K.normalizeCalendario({ ...cal, ...Object.fromEntries(['modo', 'passoMin', 'gradePorDuracao', 'intervalos', 'excecoes', 'bloqueios', 'feriadosProprios'].filter((k) => a[k] !== undefined).map((k) => [k, a[k]])) })
        if (a.modo !== undefined && !(K.MODOS as readonly string[]).includes(a.modo)) fail(400, 'Modo inválido.', 'invalid', 'modo')
        x.calendario = n; break
      }
      case 'decidir': {
        const data = String(a.data || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) fail(400, 'Data inválida.', 'invalid', 'data')
        if (!['abrir', 'fechar', 'especial'].includes(a.acao)) fail(400, 'Ação inválida.', 'invalid', 'acao')
        if (a.acao === 'especial' && !(/^([01]\d|2[0-3]):[0-5]\d$/.test(a.abre) && /^([01]\d|2[0-3]):[0-5]\d$/.test(a.fecha) && K.toMin(a.fecha) > K.toMin(a.abre))) fail(400, 'Informe abertura e fechamento válidos.', 'invalid', 'abre')
        const fer = K.feriadoDe(data, cal.feriadosProprios), rec = a.recorrente === true && cal.modo === 'automatico' && !!fer
        cal.decisoes[rec ? data.slice(5) : data] = { acao: a.acao, abre: a.acao === 'especial' ? a.abre : undefined, fecha: a.acao === 'especial' ? a.fecha : undefined, recorrente: rec, em: nowIso(), por: 'dono' }
        cal.historico = [...cal.historico, { data, nome: fer?.nome || 'Data especial', acao: a.acao, em: nowIso(), por: 'dono' }].slice(-80); x.calendario = K.normalizeCalendario(cal); break
      }
      case 'limpar': { const data = String(a.data || ''); delete cal.decisoes[data]; delete cal.decisoes[data.slice(5)]; cal.excecoes = cal.excecoes.filter((e) => e.data !== data); x.calendario = cal; break }
      default: fail(400, 'Ação desconhecida.', 'invalid', 'action')
    }
    await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), b.id])
  })
  await audit(u.id, 'agenda.' + a.action, Number(b.id), a.action === 'config' ? { modo: a.modo } : { data: a.data, acao: a.acao })
  return view((await q('SELECT * FROM businesses WHERE id = $1', [b.id]))[0])
}
/** Chave geral da capacidade (Painel → Capacidades). Desligada: a IA deixa de usar as ferramentas de agenda; o motor de agendamento continua igual. */
export async function panelAgendaIaGet(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const c = await getConfig<any>('agenda_ia', { ativo: true }); return { ativo: c.ativo !== false }
}
export async function panelAgendaIaPut(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (!effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  const ativo = ctx.body?.ativo !== false; await setConfig('agenda_ia', { ativo }); await audit(u.id, 'agenda_ia.chave', null, { ativo }); return { ok: true, ativo }
}
