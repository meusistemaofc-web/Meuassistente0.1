// CRÉDITO DA LOJA — rotas finas sobre lib/credito-loja.ts (toda regra e conta fica no servidor).
//   ADM ......... GET/PUT /api/panel/credito · GET /api/panel/credito/empresas?q= · POST /api/panel/credito/empresas/:bid
//                 GET /api/panel/credito/relatorio?de=&ate=
//   Empresa ..... (só o DONO; ownBusiness) GET /api/v2/businesses/:id/credito/painel · GET/PUT …/credito/config
//                 GET …/credito/clientes?q= · PUT …/credito/clientes · GET …/credito/clientes/:uid
//                 GET …/credito/operacoes/:opid · POST …/credito/solicitacoes/:opid/decisao · POST …/credito/parcelas/:pid/pagamento
//   Cliente ..... GET /api/v2/credito/meu · GET …/businesses/:id/credito/opcoes?valor= · POST …/credito/simular
// A compra acontece no checkout de sempre (POST /api/v2/businesses/:id/orders, pagamento "credito").
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as CL from '../lib/credito-loja.js'
import { one } from '../db/index.js'

const nid = (v: any) => { const n = Number(v); if (!Number.isInteger(n) || n <= 0) fail(400, 'Identificador inválido.', 'invalid'); return n }
const Q = (ctx: Ctx, k: string) => String(ctx.query.get(k) || '')
/** Dono da empresa (isolamento entre empresas) com loja e pedidos; precisa ter sido autorizada alguma vez pelo ADM. */
async function dono(ctx: Ctx) {
  const { ownBusiness } = await import('./businesses.js'); const { u, b } = await ownBusiness(ctx)
  const { plans } = await import('./ads.js'); if (Number((await plans()).find((p: any) => p.id === b.plan_id)?.nivel || 1) < 4) fail(403, 'O Crédito da Loja faz parte dos planos com loja e pedidos.', 'plan_required')
  if (!(await one('SELECT business_id FROM credito_empresas WHERE business_id = $1', [b.id]))) fail(403, 'Esta empresa não está autorizada a usar o Crédito da Loja. A liberação é feita pelo administrador.', 'credito_nao_autorizado')
  return { u, bid: Number(b.id), ator: { id: u.id, nome: u.name || '' } }
}
async function adm(ctx: Ctx, write = false) { const { requirePanel } = await import('./panel.js'); const u = await requirePanel(ctx, write); return { id: u.id, nome: u.name || '' } }

/* ADM */
export async function admGet(ctx: Ctx) { await adm(ctx); return CL.admVisao() }
export async function admPut(ctx: Ctx) { const a = await adm(ctx, true); return CL.admSalvarConfig(ctx.body || {}, a.id) }
export async function admEmpresasGet(ctx: Ctx) { await adm(ctx); return { empresas: await CL.admBuscarEmpresas(Q(ctx, 'q')) } }
export async function admEmpresaPost(ctx: Ctx) { const a = await adm(ctx, true); return CL.admAcaoEmpresa(nid(ctx.params.bid), String(ctx.body?.acao || ''), String(ctx.body?.motivo || '').trim().slice(0, 300), a) }
export async function admRelatorioGet(ctx: Ctx) { await adm(ctx); return CL.admRelatorio(Q(ctx, 'de'), Q(ctx, 'ate')) }

/* Empresa (dono) */
export async function painelGet(ctx: Ctx) { const { bid } = await dono(ctx); return CL.painelEmpresa(bid, Q(ctx, 'de'), Q(ctx, 'ate')) }
export async function configGet(ctx: Ctx) { const { bid } = await dono(ctx); const p = await CL.painelEmpresa(bid); return { estado: p.estado, config: p.config, tetos: p.tetos } }
export async function configPut(ctx: Ctx) { const { bid, ator } = await dono(ctx); return CL.salvarConfigEmpresa(bid, ctx.body || {}, ator) }
export async function clientesGet(ctx: Ctx) { const { bid } = await dono(ctx); return { clientes: await CL.buscarClientes(bid, Q(ctx, 'q')) } }
export async function clientesPut(ctx: Ctx) { const { bid, ator } = await dono(ctx); return CL.salvarCliente(bid, ctx.body || {}, ator) }
export async function clienteGet(ctx: Ctx) { const { bid } = await dono(ctx); const uid = nid(ctx.params.uid)
  if (!(await one('SELECT id FROM credito_clientes WHERE business_id = $1 AND user_id = $2 UNION SELECT id FROM credito_operacoes WHERE business_id = $1 AND user_id = $2', [bid, uid]))) fail(404, 'Este cliente não tem crédito nesta empresa.', 'not_found')
  return CL.historicoCliente(bid, uid) }
export async function operacaoGet(ctx: Ctx) { const { bid } = await dono(ctx); return CL.operacaoEmpresa(bid, nid(ctx.params.opid)) }
export async function decisaoPost(ctx: Ctx) { const { bid, ator } = await dono(ctx); return CL.decidir(bid, nid(ctx.params.opid), String(ctx.body?.decisao || ''), String(ctx.body?.motivo || '').trim().slice(0, 300), ator) }
export async function pagamentoPost(ctx: Ctx) { const { bid, ator } = await dono(ctx); return CL.registrarPagamento(bid, nid(ctx.params.pid), ctx.body || {}, ator) }

/* Cliente */
export async function meuGet(ctx: Ctx) { const u = requireUser(ctx); return CL.meuCredito(u.id) }
async function lojaAtiva(ctx: Ctx) { const b = await one("SELECT id, owner_id FROM businesses WHERE id = $1 AND status = 'ativo'", [nid(ctx.params.id)]); if (!b) fail(404, 'Loja não encontrada.', 'not_found'); return b! }
export async function opcoesGet(ctx: Ctx) { const u = requireUser(ctx), b = await lojaAtiva(ctx); if (Number(b.owner_id) === u.id) return { disponivel: false }; return CL.opcoesCheckout(Number(b.id), u.id, Number(Q(ctx, 'valor')) || undefined) }
export async function simularPost(ctx: Ctx) { const u = requireUser(ctx), b = await lojaAtiva(ctx); if (Number(b.owner_id) === u.id) fail(400, 'Você não pode comprar a crédito na sua própria loja.', 'invalid'); return CL.simularCheckout(Number(b.id), u.id, ctx.body || {}) }

/* ---------------- SOLICITAÇÃO DE CRÉDITO DO CLIENTE (lib/credito-solicitacoes.ts) ---------------- */
const SL = () => import('../lib/credito-solicitacoes.js')
const DOCS = '/api/v2/credito/documentos'
export async function solAbrirPost(ctx: Ctx) { const u = requireUser(ctx), b = await lojaAtiva(ctx); const S = await SL(); const s = await S.abrir(Number(b.id), u.id); return S.verMinha(Number(s.id), u.id, DOCS) }
export async function solMinhasGet(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).minhas(u.id) }
export async function solMinhaGet(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).verMinha(nid(ctx.params.sid), u.id, DOCS) }
export async function solDadosPut(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).salvarDados(nid(ctx.params.sid), u.id, ctx.body || {}) }
export async function solDocPost(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).enviarDocumento(nid(ctx.params.sid), u.id, ctx.body || {}) }
export async function solEnviarPost(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).enviar(nid(ctx.params.sid), u.id, ctx.body || {}) }
export async function solCancelarPost(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).cancelar(nid(ctx.params.sid), u.id, ctx.body?.apagarDocumentos !== false) }
export async function documentoGet(ctx: Ctx) { const u = requireUser(ctx); return (await SL()).documento(nid(ctx.params.did), u.id, Number(Q(ctx, 'exp')), Q(ctx, 'sig')) }
export async function limitesGet(ctx: Ctx) { const { bid } = await dono(ctx); return (await SL()).listar(bid, ['pendente', 'info_solicitada', 'aprovada', 'recusada', 'cancelada', 'expirada'].includes(Q(ctx, 'status')) ? Q(ctx, 'status') : '') }
export async function limiteGet(ctx: Ctx) { const { bid, u } = await dono(ctx); return (await SL()).detalhe(bid, nid(ctx.params.sid), u.id, DOCS) }
export async function limiteAcaoPost(ctx: Ctx) {
  const { bid, ator } = await dono(ctx), S = await SL(), sid = nid(ctx.params.sid), b = ctx.body || {}
  switch (String(ctx.params.acao)) {
    case 'nota': return S.nota(bid, sid, String(b.texto || ''), ator)
    case 'info': return S.pedirInfo(bid, sid, String(b.mensagem || ''), ator)
    case 'recusar': return S.recusar(bid, sid, String(b.motivo || ''), ator)
    case 'aprovar': return S.aprovar(bid, sid, b, ator)
  }
  fail(404, 'Ação desconhecida.', 'not_found')
}
