// Painel → Cérebro → Inteligência cognitiva: chave geral, ajustes finos e números agregados de qualidade.
// O administrador vê só notas, sinalizações e contagens — nunca o texto das conversas nem dados identificáveis.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import * as C from '../ai/cognition.js'

const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelCognicaoGet(ctx: Ctx) { admin(ctx); return C.resumoAdmin() }
export async function panelCognicaoPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, antes = await C.cogCfg(), novo: any = { ...(await getConfig<any>('cognition', {})) }
  let mudou = false
  for (const k of ['ativo', 'humanizar', 'guardaAcoes', 'portaoSensivel'] as const) if (b[k] !== undefined) { if (typeof b[k] !== 'boolean') fail(400, `Informe ${k}: true ou false.`, 'invalid', k); novo[k] = b[k]; mudou = true }
  if (!mudou) fail(400, 'Nada para alterar.', 'invalid')
  novo.atualizadoEm = new Date().toISOString(); novo.atualizadoPor = u.id
  await setConfig('cognition', novo)
  await audit(u.id, 'cognicao.config', null, { de: { ativo: antes.ativo, humanizar: antes.humanizar, guardaAcoes: antes.guardaAcoes, portaoSensivel: antes.portaoSensivel }, para: Object.fromEntries(Object.keys(b).filter((k) => typeof b[k] === 'boolean').map((k) => [k, b[k]])) })
  return { ok: true, ...(await C.resumoAdmin()) }
}
