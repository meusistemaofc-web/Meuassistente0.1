import { settingsOf } from '../lib/account.js'
// /api/notifications — central de notificações (lista, contagem, marcar como lida).
import type { Ctx } from '../lib/http.js'
import { q, one, B, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'

async function unread(userId: number) {
  const r = await one<{ n: number }>('SELECT COUNT(*) AS n FROM notifications WHERE user_id = $1 AND read = $2', [userId, false])
  return Number(r?.n || 0)
}
export async function notificationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (ctx.query.get('count')) return { unread: await unread(u.id) }
  const rows = await q('SELECT * FROM notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 100', [u.id])
  return {
    unread: await unread(u.id),
    items: rows.map((r) => ({ id: Number(r.id), type: r.type, ref: r.ref || null, title: r.title, body: r.body, link: r.link, read: B(r.read), createdAt: r.created_at })),
  }
}
/* ---------- Detalhes de uma notificação (Meus Avisos) ----------
   Lê só o que está gravado: a própria notificação e, quando o "ref" aponta para um registro do MESMO usuário
   (lembrete, compromisso, conta, pedido/agendamento, acompanhamento, tarefa do CRM, chamado, empresa), os dados desse registro.
   Nada é inventado nem interpretado por IA; se o registro não existir mais, mostra só o aviso. Abrir marca como lida. */
const CATEGORIA: Record<string, string> = {
  reminder: 'Lembrete', appointment: 'Compromisso', bill: 'Conta a pagar', task: 'Tarefa', tasks: 'Tarefa', summary: 'Resumo', market: 'Mercado',
  das: 'DAS', fiscal: 'Fiscal', plan: 'Plano', election: 'Eleições 2026', email: 'E-mail', order: 'Pedidos e agendamentos', ads: 'Anúncio',
  coin: 'MCoins', credito: 'Crédito da Loja', sistema: 'Sistema', followup: 'Acompanhamento', previsao: 'Previsão', execucao: 'Execução', catalogo: 'Catálogo',
  brain_rule: 'Cérebro', aprendizado: 'Aprendizado', agenda: 'Agenda da empresa', support: 'Suporte', support_admin: 'Suporte', expiry: 'Vencimento',
}
const brl = (n: any) => (Number.isFinite(Number(n)) ? Number(n).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '')
const dBr = (s: any) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || '')); return m ? `${m[3]}/${m[2]}/${m[1]}` : '' }
const dtBr = (iso: any, tz: string) => { const t = Date.parse(String(iso || '')); if (!Number.isFinite(t)) return ''; try { return new Date(t).toLocaleString('pt-BR', { timeZone: tz, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(',', ' às') } catch { return new Date(t).toISOString().slice(0, 16).replace('T', ' ') } }
const ST_ITEM: Record<string, string> = { pending: 'Pendente', done: 'Concluído', paid: 'Paga', overdue: 'Atrasada', cancelled: 'Cancelado', snoozed: 'Adiado' }
const ST_ORDER: Record<string, string> = { novo: 'Novo', aguardando_pagamento: 'Aguardando pagamento', aguardando_credito: 'Aguardando aprovação do crédito', aguardando_aprovacao: 'Aguardando aprovação', aceito: 'Aceito', preparo: 'Em preparo', saiu: 'Saiu para entrega', pronto: 'Pronto para retirar', concluido: 'Concluído', recusado: 'Recusado', cancelado: 'Cancelado', expirado: 'Expirado' }
const ST_TICKET: Record<string, string> = { aberto: 'Aberto', em_andamento: 'Em andamento', respondido: 'Respondido', resolvido: 'Resolvido', fechado: 'Fechado' }
type Rel = { tipo: string; titulo: string; campos: [string, string][] }
const limpa = (r: Rel | null): Rel | null => (r ? { ...r, campos: r.campos.filter(([, v]) => v != null && String(v).trim() !== '').map(([k, v]) => [k, String(v)]) } : null)
async function relacionado(userId: number, ref: string, tz: string): Promise<Rel | null> {
  const m = /^([a-z][a-z-]*?)[:-](\d+)/.exec(ref || ''); if (!m) return null
  const kind = m[1], id = Number(m[2]); if (!Number.isSafeInteger(id) || id <= 0) return null
  const item = async (type: string) => { const r = (await q('SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [id, userId, type]))[0]; if (!r) return null; const { serialize } = await import('./items.js'); return serialize({ ...r, data: typeof r.data === 'string' ? JSON.parse(r.data) : r.data || {} } as any) as any }
  if (kind === 'reminder') { const s = await item('reminder'); return s && { tipo: 'Lembrete', titulo: s.message || 'Lembrete', campos: [['Quando', s.remindAt ? dtBr(s.remindAt, tz) : [dBr(s.date), s.time].filter(Boolean).join(' às ')], ['Situação', ST_ITEM[s.status] || s.status], ['Repetição', s.recurrence && s.recurrence !== 'none' ? s.recurrence : ''], ['Aviso antes', s.leadMinutes ? `${s.leadMinutes} min` : '']] } }
  if (kind === 'appointment') { const s = await item('appointment'); return s && { tipo: 'Compromisso', titulo: s.title || 'Compromisso', campos: [['Data', dBr(s.date)], ['Horário', [s.time, s.endTime].filter(Boolean).join(' às ')], ['Local', s.location], ['Com', s.person], ['Observações', s.notes]] } }
  if (kind === 'bill') { const s = await item('bill'); return s && { tipo: 'Conta a pagar', titulo: s.name || 'Conta', campos: [['Valor', brl(s.amount)], ['Vencimento', dBr(s.dueDate)], ['Situação', s.status === 'paid' ? 'Paga' : 'Pendente'], ['Categoria', s.category], ['Pago em', s.paidAt ? dtBr(s.paidAt, tz) : '']] } }
  if (['order', 'order-new', 'order-paid', 'order-paid-c', 'order-pay', 'booking', 'solic', 'solic-resp', 'review'].includes(kind)) {
    // o pedido é do usuário (cliente) ou da empresa dele (dono)
    const o = (await q('SELECT o.*, b.owner_id FROM orders o JOIN businesses b ON b.id = o.business_id WHERE o.id = $1 AND (o.customer_id = $2 OR b.owner_id = $2)', [id, userId]))[0]; if (!o) return null
    const d = J<any>(o.data, {}); const ag = d.tipo === 'agendamento'
    return { tipo: ag ? 'Agendamento' : 'Pedido', titulo: `${ag ? 'Agendamento' : 'Pedido'} #${o.id}${d.empresa ? ' · ' + d.empresa : ''}`, campos: [['Situação', ST_ORDER[o.status] || String(o.status || '')], ['Total', brl(o.total)], ['Serviço', ag ? d.servico : ''], ['Data marcada', ag ? [dBr(d.data), d.hora].filter(Boolean).join(' às ') : ''], ['Itens', !ag && Array.isArray(d.itens) ? d.itens.slice(0, 12).map((i: any) => `${i.qtd || 1}× ${i.nome}`).join(', ') : ''], ['Cliente', Number(o.owner_id) === userId ? d.cliente : ''], ['Recebimento', d.modo === 'entrega' ? 'Entrega' : d.modo === 'retirada' ? 'Retirada' : ''], ['Feito em', dtBr(o.created_at, tz)]] }
  }
  if (kind === 'followup') { const f = (await q('SELECT * FROM followups WHERE id = $1 AND owner_id = $2', [id, userId]))[0]; return f && { tipo: 'Acompanhamento', titulo: `Acompanhamento: ${f.cliente}`, campos: [['Cliente', f.cliente], ['Contato', f.contato], ['Serviço', f.servico], ['Concluído em', dtBr(f.concluido_em, tz)], ['Retorno previsto', dtBr(f.due_at, tz)]] } }
  if (kind === 'crm-task') { const t = (await q('SELECT t.* FROM crm_tasks t JOIN businesses b ON b.id = t.business_id WHERE t.id = $1 AND b.owner_id = $2', [id, userId]))[0]; return t && { tipo: 'Tarefa do CRM', titulo: t.title, campos: [['Prazo', String(t.due_at || '').includes('T') ? `${dBr(t.due_at)} às ${String(t.due_at).slice(11, 16)}` : dBr(t.due_at)], ['Prioridade', t.priority], ['Situação', t.status], ['Responsável', t.owner_name], ['Observações', t.notes]] } }
  if (kind === 'ticket') { const t = (await q('SELECT * FROM tickets WHERE id = $1 AND user_id = $2', [id, userId]))[0]; return t && { tipo: 'Chamado de suporte', titulo: t.assunto, campos: [['Protocolo', t.protocolo], ['Categoria', t.categoria], ['Situação', ST_TICKET[t.status] || t.status], ['Aberto em', dtBr(t.created_at, tz)], ['Atualizado em', dtBr(t.updated_at, tz)]] } }
  if (kind.startsWith('ad-') || kind === 'agent' || kind === 'agenda-ia') { const b = (await q('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [id, userId]))[0]; if (!b) return null; const d = J<any>(b.data, {}); return { tipo: 'Empresa', titulo: d.empresa || 'Sua empresa', campos: [['Ramo', d.categoria], ['Situação do anúncio', ({ ativo: 'No ar', analise: 'Em análise', ajustes: 'Ajustes pedidos', recusado: 'Recusado', pendente: 'Aguardando pagamento', expirado: 'Fora do ar' } as Record<string, string>)[b.status] || b.status], ['No ar até', b.expires_at ? dBr(b.expires_at) : '']] } }
  return null
}
export async function notificationGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const id = Number(ctx.params.id)
  if (!Number.isSafeInteger(id) || id <= 0) fail(400, 'Aviso inválido.', 'invalid')
  const r = (await q('SELECT * FROM notifications WHERE id = $1 AND user_id = $2', [id, u.id]))[0]
  if (!r) fail(404, 'Este aviso não existe mais.', 'not_found')
  const tz = settingsOf(u).timezone
  // abrir = ler: só muda o "lida"; título, mensagem e link ficam como estão
  if (!B(r.read)) await q('UPDATE notifications SET read = $1 WHERE id = $2 AND user_id = $3', [true, id, u.id])
  let rel: Rel | null = null
  try { rel = limpa(await relacionado(u.id, String(r.ref || ''), tz)) } catch (e: any) { console.error('[avisos] detalhe do registro relacionado indisponível:', e?.message || e) }
  return {
    item: { id: Number(r.id), type: r.type, categoria: CATEGORIA[r.type] || 'Aviso', title: r.title, body: r.body, link: r.link, read: true, createdAt: r.created_at, recebidoEm: dtBr(r.created_at, tz) },
    relacionado: rel && rel.campos.length ? rel : rel ? { ...rel, campos: [] } : null,
    unread: await unread(u.id),
  }
}
export async function notificationsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  if (b.all) await q('UPDATE notifications SET read = $1 WHERE user_id = $2', [true, u.id])
  else if (b.id) await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND id = $3', [true, u.id, Number(b.id)])
  return { ok: true, unread: await unread(u.id) }
}

import { getPublicKey, saveSubscription, sendToUser } from '../lib/push.js'
import { fail } from '../lib/http.js'

export async function pushGet(ctx: Ctx) { return safePush('pushGet', () => pushGet0(ctx)) }
async function pushGet0(ctx: Ctx) {
  const u = requireUser(ctx), ep = String(ctx.query.get('endpoint') || '')
  const { getPublicKey, isRegistered, ensurePushSchema } = await import('../lib/push.js')
  await ensurePushSchema()
  if (ctx.query.get('status')) {
    const st: any = settingsOf(u), devices = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [u.id]))[0]?.n || 0)
    return { registered: ep ? await isRegistered(u.id, ep) : false, account: { planPush: true, notificationsEnabled: st.notificationsEnabled !== false, pushEnabled: st.pushEnabled !== false, appointmentsEnabled: st.appointmentsEnabled !== false, devices } }
  }
  if (ep) return { registered: await isRegistered(u.id, ep) }
  return { publicKey: await getPublicKey() }
}
export async function pushPost(ctx: Ctx) { return safePush('pushPost', () => pushPost0(ctx)) }
async function pushPost0(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.test) { const r = await sendToUser(u.id, { title: 'Meu Assistente', body: 'Notificações ativadas neste aparelho. Seus lembretes vão chegar aqui.', url: '/', tag: 'push-test' }); return { ok: true, push: { ...r, delivered: r.sent, devices: r.total, expired: r.errors.filter((x: string) => /expirada/.test(x)).length } } }
  if (!b.subscription) fail(400, 'Inscrição inválida.', 'invalid')
  let ok = false
  try { ok = await saveSubscription(u.id, b.subscription, String(ctx.req.headers['user-agent'] || '')) } catch (e: any) { console.error('[push] não foi possível salvar a inscrição:', e?.message || e); fail(503, 'Não foi possível registrar este aparelho agora. Tente de novo em instantes.', 'push_unavailable') }
  if (!ok) fail(400, 'Inscrição inválida.', 'invalid')
  return { ok: true }
}
export async function pushDelete(ctx: Ctx) { return safePush('pushDelete', () => pushDelete0(ctx)) }
async function pushDelete0(ctx: Ctx) {
  const u = requireUser(ctx); const { removeSubscription } = await import('../lib/push.js')
  await removeSubscription(u.id, ctx.body?.endpoint ? String(ctx.body.endpoint) : undefined); return { ok: true }
}

// Helper used by other modules to notify a user
export async function notifyPush(userId: number, title: string, body?: string, url?: string) {
  return sendToUser(userId, { title, body, url })
}

/** Erros inesperados do push voltam com o motivo (sem dados sensíveis) em vez de "Algo deu errado no servidor". */
async function safePush<T>(nome: string, fn: () => Promise<T>): Promise<T> {
  try { return await fn() }
  catch (e: any) {
    if (e?.status && e.status < 500) throw e
    const motivo = String(e?.message || e).replace(/postgres(ql)?:\/\/\S+/gi, '[banco]').slice(0, 160)
    console.error(`[push] ${nome} falhou:`, e?.stack || e)
    fail(503, `Não foi possível ativar as notificações agora (${motivo}). Tente de novo em instantes.`, 'push_error')
    throw e
  }
}
/** Diagnóstico do push para o administrador: tabela, chaves VAPID e assinatura. */
export async function pushDiagGet(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  const out: any = {}
  const m = await import('../lib/push.js')
  try { await m.ensurePushSchema(true); out.tabela = 'ok' } catch (e: any) { out.tabela = 'erro: ' + e?.message }
  try { const k = await m.getPublicKey(); out.chave = k && k.length > 80 ? 'ok' : 'inválida' } catch (e: any) { out.chave = 'erro: ' + e?.message }
  try { const ep = 'https://diagnostico.invalid/' + Date.now(); await m.saveSubscription(u.id, { endpoint: ep, keys: { p256dh: 'BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM', auth: 'tBHItJI5svbpez7KI4CCXg' } }, 'diagnóstico'); await m.removeSubscription(u.id, ep); out.gravacao = 'ok' } catch (e: any) { out.gravacao = 'erro: ' + e?.message }
  try { m.encryptPayload('BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM', 'tBHItJI5svbpez7KI4CCXg', '{}'); out.criptografia = 'ok' } catch (e: any) { out.criptografia = 'erro: ' + e?.message }
  out.aparelhos = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [u.id]))[0]?.n || 0)
  return out
}
