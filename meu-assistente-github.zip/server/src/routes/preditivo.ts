// Inteligência preditiva (Fase 7): página do usuário (previsões, reações e preferências) e painel do administrador
// (indicadores agregados, chaves, validação). O usuário só vê os PRÓPRIOS sinais; o administrador só vê contagens.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { setConfig } from '../lib/settings.js'
import * as P from '../ai/preditivo.js'
import * as PS from '../ai/preditivo-servico.js'

/* ---------- usuário ---------- */
export async function mePrevisoesGet(ctx: Ctx) {
  const u = requireUser(ctx), r = await PS.paraUsuario(u), prefs = await P.prefsPred(u.id)
  // registra o que foi mostrado na página (uma vez por dia por sinal) para medir aceite e falsos alertas
  if (r.ativo) { const { q } = await import('../db/index.js'); for (const s of r.sinais.slice(0, 30)) { const ja = await q("SELECT id FROM predictive_alerts WHERE user_id = $1 AND ikey = $2 AND canal = 'pagina' AND created_at >= $3", [u.id, s.chave, new Date(Date.now() - 864e5).toISOString()]); if (!ja.length) await PS.registrarAlerta(u.id, s, 'pagina') } }
  const reac = r.ativo ? Object.fromEntries((await (await import('../db/index.js')).q("SELECT ikey, status FROM predictive_alerts WHERE user_id = $1 AND status <> 'apresentada' AND updated_at >= $2", [u.id, new Date(Date.now() - 30 * 864e5).toISOString()]) as any[]).map((x) => [x.ikey, x.status])) : {}
  return { ativo: r.ativo, hoje: r.hoje, ms: r.ms, sinais: r.sinais.filter((s) => !['dispensada', 'falso', 'aceita'].includes(reac[s.chave])).map((s) => ({ ...s, previsao: s.previsao ? { de: s.previsao.de, ate: s.previsao.ate } : undefined })), resolvidos: Object.keys(reac).length, lacunas: r.lacunas, categorias: P.CATEGORIAS, tipos: P.TIPOS, preferencias: prefs }
}
export async function mePrevisoesAcao(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (typeof b.chave !== 'string' || !/^[a-z_]+:[\w:.\-]{1,160}$/.test(b.chave)) fail(400, 'Sinal inválido.', 'invalid', 'chave')
  if (!['aceita', 'dispensada', 'falso', 'adiar'].includes(b.acao)) fail(400, 'Ação inválida.', 'invalid', 'acao')
  return PS.reagir(u.id, b.chave, b.acao)
}
export async function mePrevisoesPrefsPut(ctx: Ctx) {
  const u = requireUser(ctx), novo = P.validarPrefs(ctx.body || {}, await P.prefsPred(u.id))
  await P.salvarPrefsPred(u.id, novo); return { ok: true, preferencias: novo }
}

/* ---------- administrador ---------- */
const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelPreditivoGet(ctx: Ctx) { admin(ctx); return { ...(await PS.indicadores()), tipos: P.TIPOS, categorias: P.CATEGORIAS } }
export async function panelPreditivoPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, atual = await P.predCfg(), novo: any = { ...atual }, mud: any = {}
  for (const k of ['ativo', 'notificacoes'] as const) if (b[k] !== undefined) { if (typeof b[k] !== 'boolean') fail(400, `Informe ${k}: true ou false.`, 'invalid', k); novo[k] = mud[k] = b[k] }
  if (b.limiteDiarioGlobal !== undefined) { const n = Number(b.limiteDiarioGlobal); if (!Number.isInteger(n) || n < 0 || n > 10) fail(400, 'Limite diário: de 0 a 10 avisos por usuário.', 'invalid', 'limiteDiarioGlobal'); novo.limiteDiarioGlobal = mud.limiteDiarioGlobal = n }
  if (b.tipo !== undefined) { if (!(b.tipo in P.TIPOS) || typeof b.ligado !== 'boolean') fail(400, 'Tipo de sinal inválido.', 'invalid', 'tipo'); novo.tiposDesligados = b.ligado ? atual.tiposDesligados.filter((t) => t !== b.tipo) : [...new Set([...atual.tiposDesligados, b.tipo])]; mud[b.tipo] = b.ligado }
  if (!Object.keys(mud).length) fail(400, 'Nada para alterar.', 'invalid')
  await setConfig('preditivo', novo); await audit(u.id, 'preditivo.config', null, mud)
  return panelPreditivoGet(ctx)
}
export async function panelPreditivoValidar(ctx: Ctx) { const u = admin(ctx, true); const r = await PS.validarTudo(u); await audit(u.id, 'preditivo.validacao', null, { cobertura: r.cenarios.cobertura, precisao: r.cenarios.precisao, retroteste: r.retroteste.precisao }); return r }
export async function panelPreditivoAvaliar(ctx: Ctx) { admin(ctx, true); return PS.avaliarPrevisoes() }
export async function panelPreditivoAvisar(ctx: Ctx) { const u = admin(ctx, true); const r = await PS.rodarNotificacoes(); await audit(u.id, 'preditivo.avisos', null, r); return r }
