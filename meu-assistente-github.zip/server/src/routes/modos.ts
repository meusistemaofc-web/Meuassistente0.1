// Modos Inteligentes: seletor do campo de digitação, estado da conversa e propostas (ex.: campanha → Central de Marketing).
// Todo acesso é decidido no servidor (contratação, dono da conversa e dono da proposta); a interface só exibe.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as MD from '../modos/index.js'
import { levarParaCentral, propostaDe } from '../modos/marketing.js'

const conv = (v: unknown) => { const s = String(v || '').trim(); return /^[A-Za-z0-9_-]{6,80}$/.test(s) ? s : '' }
export async function modosGet(ctx: Ctx) { const u = requireUser(ctx); return MD.listar(u, conv(ctx.query.get('c'))) }
export async function modosPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.action === 'desativar') { const c = conv(b.conversationId); if (c) await MD.desativar(c, u.id); return { ok: true, ativo: null } }
  if (b.action === 'verificar') { const m = MD.modoPorId(String(b.modo || '')); if (!m || !(await MD.cfgModos()).find((x) => x.id === m.id)?.ativo) fail(404, 'Modo não encontrado.', 'not_found'); const a = await m.acesso(u); if (!a.liberado && m.ocultoSemAcesso) fail(404, 'Modo não encontrado.', 'not_found'); return { liberado: a.liberado, codigo: a.codigo, mensagem: a.liberado ? null : a.mensagem, acao: a.liberado ? null : a.acao || null } }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function modoPropostaGet(ctx: Ctx) { const u = requireUser(ctx); const p = await propostaDe(u.id, Number(ctx.params.id)); if (!p) fail(404, 'Proposta não encontrada.', 'not_found'); return p }
export async function modoPropostaPost(ctx: Ctx) { const u = requireUser(ctx); if (ctx.body?.action !== 'central') fail(400, 'Ação inválida.', 'invalid'); return levarParaCentral(u.id, Number(ctx.params.id)) }

/* Treino e Acompanhamento — ficha visual do chat (⟦tr:…⟧): dados do plano ativo do próprio usuário, marcação de exercícios e
   ilustrações (SVG desenhado no servidor, sem dados pessoais: cache público e longo). */
export async function treinoFichaGet(ctx: Ctx) { const u = requireUser(ctx); const TR = await import('../lib/treino.js'); return TR.ficha(u) }
export async function treinoRegistroPost(ctx: Ctx) { const u = requireUser(ctx); const TR = await import('../lib/treino.js'); return TR.marcarExercicio(u, ctx.body || {}) }
export async function treinoCargasGet(ctx: Ctx) {
  const u = requireUser(ctx), TR = await import('../lib/treino.js'), k = TR.chaveEx(String(ctx.query.get('chave') || ''))
  if (!k) fail(400, 'Exercício inválido.', 'invalid', 'chave')
  return { chave: k, ...(await TR.cargasDe(u.id, [k]))[k] }
}
export async function treinoIlustracaoGet(ctx: Ctx) {
  const IL = await import('../lib/treino-ilustracoes.js'), p = IL.padraoPorId(String(ctx.params.padrao || '')), fase = String(ctx.params.fase || '').replace(/\.svg$/, '')
  if (!p || (fase !== 'ini' && fase !== 'fim')) fail(404, 'Ilustração não encontrada.', 'not_found')
  const tema = ctx.query.get('t') === 'escuro' ? 'escuro' : 'claro'
  return { _binary: true, mime: 'image/svg+xml; charset=utf-8', data: Buffer.from(IL.svg(p!, fase as 'ini' | 'fim', tema)), headers: { 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" } }
}
/** Card da busca visual (⟦bv:id⟧): resultados já conferidos, só do próprio dono. */
export async function buscaVisualGet(ctx: Ctx) {
  const u = requireUser(ctx), BV = await import('../lib/busca-visual.js'), id = Number(ctx.params.id)
  const r = Number.isInteger(id) && id > 0 ? await BV.ler(u.id, id) : null; if (!r) fail(404, 'Busca não encontrada.', 'not_found')
  return r
}
