// Modos Inteligentes: seletor do campo de digitação, estado da conversa e propostas (ex.: campanha → Central de Marketing).
// Todo acesso é decidido no servidor (contratação, dono da conversa e dono da proposta); a interface só exibe.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as MD from '../modos/index.js'
import { levarParaCentral, propostaDe } from '../modos/marketing.js'

const conv = (v: unknown) => { const s = String(v || '').trim(); return /^[A-Za-z0-9_-]{6,80}$/.test(s) ? s : '' }
export async function modosGet(ctx: Ctx) { const u = requireUser(ctx); return MD.listar(u, conv(ctx.query.get('c'))) }
export async function modosPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.action === 'desativar') { const c = conv(b.conversationId); if (c) await MD.desativar(c, u.id); return { ok: true, ativo: null } }
  if (b.action === 'verificar') { const m = MD.modoPorId(String(b.modo || '')); if (!m) fail(404, 'Modo não encontrado.', 'not_found'); const a = await m.acesso(u); return { liberado: a.liberado, codigo: a.codigo, mensagem: a.liberado ? null : a.mensagem, acao: a.liberado ? null : a.acao || null } }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function modoPropostaGet(ctx: Ctx) { const u = requireUser(ctx); const p = await propostaDe(u.id, Number(ctx.params.id)); if (!p) fail(404, 'Proposta não encontrada.', 'not_found'); return p }
export async function modoPropostaPost(ctx: Ctx) { const u = requireUser(ctx); if (ctx.body?.action !== 'central') fail(400, 'Ação inválida.', 'invalid'); return levarParaCentral(u.id, Number(ctx.params.id)) }
