// Fase 9 — Laboratório de Inteligência: rotas EXCLUSIVAS de administradores autorizados
// (Administrador Principal, ou administrador com a permissão "lab.manage" ou "panel.manage").
// Toda ação que muda algo fica na auditoria (audit_log, ações "laboratorio.*").
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'

const LB = () => import('../ai/laboratorio.js')
const LA = () => import('../ai/laboratorio-agentes.js')
const LP = () => import('../ai/laboratorio-painel.js')
function admin(ctx: Ctx) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const p = effectivePermissions(u); if (!p.includes('lab.manage') && !p.includes('panel.manage')) fail(403, 'Seu acesso de administrador não inclui o Laboratório de Inteligência. Peça ao Administrador Principal a permissão "Laboratório de Inteligência".', 'forbidden')
  return u
}
const num = (ctx: Ctx, k = 'id') => { const n = Number(ctx.params[k]); if (!Number.isInteger(n) || n <= 0) fail(400, 'Identificador inválido.', 'invalid'); return n }
const b = (ctx: Ctx) => (ctx.body && typeof ctx.body === 'object' ? ctx.body : {}) as any
const reg = async (u: { id: number }, acao: string, alvo: number | null, det: object = {}) => audit(u.id, 'laboratorio.' + acao, alvo, det)

export const R: [string, string, (c: Ctx) => Promise<unknown>][] = [
  // 1) visão geral
  ['GET', '/api/panel/laboratorio/visao', async (c) => { admin(c); return (await LP()).painelCentral() }],
  ['PUT', '/api/panel/laboratorio/config', async (c) => { const u = admin(c); const r = await (await LB()).salvarLabCfg(b(c)); await reg(u, 'config', null, r); return { config: r } }],
  // 2) arena
  ['GET', '/api/panel/laboratorio/desafios', async (c) => { admin(c); const L = await LB(); return { desafios: (await L.desafios({ todos: true })).map((d) => ({ ...d, criteriosTexto: d.criterios.map(L.descreverCriterio) })), categorias: L.CATEGORIAS, tiposCriterio: L.TIPOS_CRITERIO, dadosPermitidos: L.DADOS_PERMITIDOS } }],
  ['POST', '/api/panel/laboratorio/desafios', async (c) => { const u = admin(c); const r = await (await LB()).salvarDesafio(u, b(c)); await reg(u, 'desafio.salvar', null, r); return r }],
  ['POST', '/api/panel/laboratorio/desafios/:slug/ativo', async (c) => { const u = admin(c); const r = await (await LB()).ativarDesafio(u, String(c.params.slug), b(c).ativo !== false); await reg(u, 'desafio.ativo', null, { slug: c.params.slug, ativo: b(c).ativo !== false }); return r }],
  ['POST', '/api/panel/laboratorio/arena', async (c) => { const u = admin(c); const id = await (await LB()).iniciarArena(u, b(c)); await reg(u, 'arena', id, { categorias: b(c).categorias || [], slugs: b(c).slugs || [] }); return { rodada: id } }],
  ['GET', '/api/panel/laboratorio/rodadas', async (c) => { admin(c); const t = String(c.query.get('tipo') || 'arena,continuo,experimento').split(',').filter((x) => ['arena', 'continuo', 'experimento', 'agente', 'colaboracao'].includes(x)); return { rodadas: await (await LB()).rodadas(t.length ? t : ['arena'], Number(c.query.get('limite') || 30)) } }],
  ['GET', '/api/panel/laboratorio/rodadas/:id', async (c) => { admin(c); return (await LB()).rodada(num(c)) }],
  ['POST', '/api/panel/laboratorio/rodadas/:id/interromper', async (c) => { const u = admin(c); const r = await (await LB()).interromper(num(c)); await reg(u, 'rodada.interromper', num(c)); return r }],
  // 3) simulador
  ['GET', '/api/panel/laboratorio/simulador', async (c) => { const u = admin(c); return { simulacoes: await (await LB()).simulacoes(u) } }],
  ['GET', '/api/panel/laboratorio/simulador/:id', async (c) => { const u = admin(c); return (await LB()).simulacao(u, num(c)) }],
  ['POST', '/api/panel/laboratorio/simulador', async (c) => { const u = admin(c); const r = await (await LB()).simular(u, b(c)); if (!b(c).sessao) await reg(u, 'simulacao', r.sessao); return r }],
  // 4) agentes
  ['GET', '/api/panel/laboratorio/agentes', async (c) => { admin(c); return (await LA()).visao() }],
  ['POST', '/api/panel/laboratorio/agentes/testar', async (c) => { const u = admin(c); const x = b(c); const r = await (await LA()).testar(u, Array.isArray(x.agentes) ? x.agentes : [], String(x.prompt || ''), x.contexto || {}); await reg(u, 'agente.testar', r.rodada, { agentes: x.agentes }); return r }],
  ['POST', '/api/panel/laboratorio/agentes/colaboracao', async (c) => { const u = admin(c); const x = b(c); const r = await (await LA()).colaboracao(u, Array.isArray(x.agentes) ? x.agentes : [], String(x.prompt || ''), x.contexto || {}); await reg(u, 'agente.colaboracao', r.rodada, { agentes: x.agentes }); return r }],
  ['POST', '/api/panel/laboratorio/agentes/clonar', async (c) => { const u = admin(c); const r = await (await LA()).clonar(u, String(b(c).base || '')); await reg(u, 'agente.clonar', r.id, { base: b(c).base }); return r }],
  ['POST', '/api/panel/laboratorio/agentes', async (c) => { const u = admin(c); const r = await (await LA()).criar(u, b(c)); await reg(u, 'agente.criar', r.id, { nome: r.nome }); return r }],
  ['PUT', '/api/panel/laboratorio/agentes/:id', async (c) => { const u = admin(c); const r = await (await LA()).editar(u, num(c), b(c)); await reg(u, 'agente.editar', r.id, { versao: r.versao }); return r }],
  ['POST', '/api/panel/laboratorio/agentes/:id/:acao', async (c) => { const u = admin(c); const a = String(c.params.acao); const r = await (await LA()).decidir(u, num(c), a, b(c)); await reg(u, 'agente.' + a, num(c), { pct: b(c).pct, modo: b(c).modo, versao: b(c).versao }); return r }],
  // 5) diagnóstico
  ['GET', '/api/panel/laboratorio/diagnostico', async (c) => { admin(c); return (await LP()).diagnosticar() }],
  ['POST', '/api/panel/laboratorio/diagnostico/propostas', async (c) => { const u = admin(c); const r = await (await LP()).diagnosticar({ gerar: true, por: u.name || 'administrador' }); await reg(u, 'diagnostico.propostas', null, { geradas: r.geradas.length }); return r }],
  // 6) melhorias
  ['GET', '/api/panel/laboratorio/melhorias', async (c) => { admin(c); return (await LP()).melhorias({ estado: c.query.get('estado') || undefined, origem: c.query.get('origem') || undefined }) }],
  ['POST', '/api/panel/laboratorio/melhorias/:origem/:id/:acao', async (c) => { const u = admin(c); const o = String(c.params.origem), a = String(c.params.acao); if (!['politica', 'regra', 'agente', 'diagnostico'].includes(o)) fail(400, 'Origem inválida.', 'invalid'); const r = await (await LP()).acaoMelhoria(u, o, num(c), a, b(c)); await reg(u, `melhoria.${a}`, num(c), { origem: o, pct: b(c).pct }); return r }],
  // 7) experimentos
  ['GET', '/api/panel/laboratorio/experimentos/opcoes', async (c) => {
    admin(c); const POL = await import('../ai/politica.js'), APR = await import('../ai/aprendizado.js'), AG = await import('../ai/agentes.js'), cfg = await POL.aprCfg(), pol = await POL.versao(cfg.versaoAtiva)
    const lab = ((await (await LA()).visao()).laboratorio as any[]).filter((x) => x.estado !== 'arquivado').map((x) => ({ id: x.id, nome: x.nome, versao: x.versao, estado: x.estadoLabel, base: x.base }))
    return { areas: POL.AREAS.map((a) => ({ id: a, nome: APR.nomeArea(a) })), estilos: POL.ESTILOS, dicas: POL.DICAS, agentesIds: AG.AGENTES.map((a) => ({ id: a.id, nome: a.nome })), ferramentas: ['create_task', 'create_appointment', 'update_appointment', 'create_reminder', 'add_shopping_items', 'create_note', 'register_transaction', 'create_bill', 'complete_task', 'save_memory'], politica: pol, versaoAtiva: cfg.versaoAtiva, especialistas: lab }
  }],
  ['POST', '/api/panel/laboratorio/experimentos', async (c) => { const u = admin(c); const id = await (await LB()).iniciarExperimento(u, b(c)); await reg(u, 'experimento', id, { variante: { nome: b(c).variante?.nome, tipo: b(c).variante?.tipo, mudancas: b(c).variante?.mudancas, agentes: b(c).variante?.agentes, instrucoes: b(c).variante?.instrucoes ? '(texto)' : undefined } }); return { rodada: id } }],
  ['POST', '/api/panel/laboratorio/experimentos/:id/proposta', async (c) => { const u = admin(c); const r = await (await LB()).propostaDoExperimento(u, num(c)); await reg(u, 'experimento.proposta', num(c), r); return r }],
  // 8) evolução global
  ['GET', '/api/panel/laboratorio/evolucao', async (c) => { admin(c); return (await LP()).evolucao() }],
  ['POST', '/api/panel/laboratorio/evolucao/restaurar', async (c) => { const u = admin(c); const v = b(c).versao == null ? null : Number(b(c).versao); const r = await (await import('../ai/aprendizado.js')).restaurarVersao(v, u); await reg(u, 'evolucao.restaurar', v, {}); return r }],
  // 9) desafios contínuos
  ['GET', '/api/panel/laboratorio/continuos', async (c) => { admin(c); const L = await LB(); return { agendas: await Promise.all((await L.agendas()).map(async (a) => ({ ...a, comparativo: await L.comparativo(a.id) }))), categorias: L.CATEGORIAS } }],
  ['POST', '/api/panel/laboratorio/continuos', async (c) => { const u = admin(c); const id = await (await LB()).salvarAgenda(u, b(c)); await reg(u, 'continuo.salvar', id, { horas: b(c).horas, categorias: b(c).categorias }); return { id } }],
  ['DELETE', '/api/panel/laboratorio/continuos/:id', async (c) => { const u = admin(c); const r = await (await LB()).excluirAgenda(num(c)); await reg(u, 'continuo.excluir', num(c)); return r }],
  ['POST', '/api/panel/laboratorio/continuos/:id/rodar', async (c) => { const u = admin(c); const id = await (await LB()).rodarAgenda(num(c), u.id); await reg(u, 'continuo.rodar', num(c), { rodada: id }); return { rodada: id } }],
  ['GET', '/api/panel/laboratorio/continuos/:id/relatorio', async (c) => { admin(c); return { markdown: await (await LB()).relatorioContinuo(num(c)) } }],
  // 10) auditoria
  ['GET', '/api/panel/laboratorio/auditoria', async (c) => { admin(c); return { registros: await (await LP()).auditoria(Number(c.query.get('limite') || 100)) } }],
]
