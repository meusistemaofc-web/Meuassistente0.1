// Inteligência avançada (Nível 2): avaliação das respostas pelo usuário, preferências pessoais de inteligência e painel
// do administrador (chaves de cada capacidade, indicadores, bateria automática, oportunidades vindas do feedback).
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import * as FB from '../ai/feedback.js'
import * as PRO from '../ai/proativo.js'
import * as AVAL from '../ai/avaliacao.js'
import { intelCfg, INTEL_DEFAULT } from '../ai/nucleo.js'

/* ---------- usuário ---------- */
export async function chatFeedbackPost(ctx: Ctx) { const u = requireUser(ctx); if (!(await intelCfg()).ativo) fail(409, 'As avaliações estão temporariamente desligadas.', 'disabled'); return FB.registrar(u, ctx.body || {}) }
export async function chatFeedbackGet(ctx: Ctx) {
  const u = requireUser(ctx), ids = String(ctx.query.get('ids') || '').split(',').map((x) => Number(x)).filter((n) => Number.isInteger(n) && n > 0)
  return { ativo: (await intelCfg()).ativo, motivos: FB.MOTIVOS, avaliacoes: await FB.minhas(u.id, ids) }
}
export async function meInteligenciaGet(ctx: Ctx) { const u = requireUser(ctx); const p = await PRO.prefsDe(u.id); return { sugestoesProativas: p.proactive, estilo: { tamanho: p.style.tamanho || null }, contribuirMelhorias: await (await import('../ai/aprendizado.js')).consentimento(u.id) } }
export async function meInteligenciaPut(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.sugestoesProativas !== undefined) { if (typeof b.sugestoesProativas !== 'boolean') fail(400, 'Informe true ou false.', 'invalid', 'sugestoesProativas'); await PRO.salvarPrefs(u.id, { proactive: b.sugestoesProativas }) }
  if (b.zerarEstilo === true) await FB.zerarEstilo(u.id)
  // consentimento para o aprendizado GLOBAL anônimo (o aprendizado individual continua nas chaves da memória)
  if (b.contribuirMelhorias !== undefined) { if (typeof b.contribuirMelhorias !== 'boolean') fail(400, 'Informe true ou false.', 'invalid', 'contribuirMelhorias'); await (await import('../ai/aprendizado.js')).salvarConsentimento(u.id, b.contribuirMelhorias); await audit(u.id, 'inteligencia.consentimento', null, { contribuirMelhorias: b.contribuirMelhorias }) }
  return meInteligenciaGet(ctx)
}

/* ---------- administrador ---------- */
const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
async function painel() {
  const cfg = await intelCfg(), ind = await AVAL.indicadores()
  const f3 = await AVAL.desempenhoEDiagnostico()
  const AG = await import('../ai/agentes.js'), mc = await AG.maCfg()
  const memoria = await (await import('../ai/memoria-evolutiva.js')).indicadores()
  const multiagente = { config: { ativo: mc.ativo, maxAgentes: mc.maxAgentes, tempoMaxMs: mc.tempoMaxMs, agentes: mc.agentes }, indicadores: await AG.indicadoresMultiagente() }
  return { config: Object.fromEntries(Object.keys(INTEL_DEFAULT).map((k) => [k, (cfg as any)[k]])), atualizadoEm: cfg.atualizadoEm || null, indicadores: ind, fase3: f3, multiagente, memoria, alertas: [...AVAL.alertasDe(ind), ...AVAL.alertasFase3(f3)], ultimoMonitor: await AVAL.ultimosAlertas(), oportunidades: (await FB.oportunidades()).slice(0, 30).map(({ ids, ...g }) => g), motivos: FB.MOTIVOS }
}
export async function panelInteligenciaGet(ctx: Ctx) { admin(ctx); return painel() }
export async function panelInteligenciaPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, antes = await intelCfg(), novo: any = { ...(await getConfig<any>('inteligencia', {})) }, mud: Record<string, boolean> = {}
  for (const k of Object.keys(INTEL_DEFAULT)) if (b[k] !== undefined) { if (typeof b[k] !== 'boolean') fail(400, `Informe ${k}: true ou false.`, 'invalid', k); novo[k] = b[k]; mud[k] = b[k] }
  if (!Object.keys(mud).length) fail(400, 'Nada para alterar.', 'invalid')
  novo.atualizadoEm = new Date().toISOString(); novo.atualizadoPor = u.id
  await setConfig('inteligencia', novo)
  await audit(u.id, 'inteligencia.config', null, { de: Object.fromEntries(Object.keys(mud).map((k) => [k, (antes as any)[k]])), para: mud })
  return { ok: true, ...(await painel()) }
}
export async function panelInteligenciaBateria(ctx: Ctx) { const u = admin(ctx, true); const r = await AVAL.rodarBateria(true); await audit(u.id, 'inteligencia.bateria', null, { aprovados: r.aprovados, total: r.total }); return r }
export async function panelInteligenciaDiagnostico(ctx: Ctx) { const u = admin(ctx, true); const r = await AVAL.rodarDiagnostico(true); await audit(u.id, 'inteligencia.diagnostico', null, { taxa: r.taxa, validacao: r.validacao.taxa }); return r }
export async function panelMultiagentePut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, AG = await import('../ai/agentes.js'), atual: any = await getConfig<any>('multiagente', {}), novo: any = { ...atual, agentes: { ...(atual.agentes || {}) } }, mud: any = {}
  if (b.ativo !== undefined) { if (typeof b.ativo !== 'boolean') fail(400, 'Informe ativo: true ou false.', 'invalid', 'ativo'); novo.ativo = mud.ativo = b.ativo }
  if (b.maxAgentes !== undefined) { const n = Number(b.maxAgentes); if (!Number.isInteger(n) || n < 1 || n > 5) fail(400, 'Máximo de agentes por mensagem: de 1 a 5.', 'invalid', 'maxAgentes'); novo.maxAgentes = mud.maxAgentes = n }
  if (b.tempoMaxMs !== undefined) { const n = Number(b.tempoMaxMs); if (!Number.isInteger(n) || n < 2000 || n > 20000) fail(400, 'Tempo dos agentes: de 2000 a 20000 ms.', 'invalid', 'tempoMaxMs'); novo.tempoMaxMs = mud.tempoMaxMs = n }
  if (b.agentes !== undefined) { if (typeof b.agentes !== 'object' || Array.isArray(b.agentes)) fail(400, 'Agentes inválidos.', 'invalid', 'agentes'); for (const [k, v] of Object.entries(b.agentes)) { if (!AG.AGENTES.some((a) => a.id === k) || typeof v !== 'boolean') fail(400, `Agente inválido: ${k}.`, 'invalid', 'agentes'); novo.agentes[k] = v; (mud.agentes ||= {})[k] = v } }
  if (b.zerarDisjuntores === true) { AG.zerarDisjuntores(); mud.zerarDisjuntores = true }
  if (!Object.keys(mud).length) fail(400, 'Nada para alterar.', 'invalid')
  novo.atualizadoEm = new Date().toISOString(); await setConfig('multiagente', novo); await audit(u.id, 'inteligencia.multiagente', null, mud)
  return { ok: true, ...(await painel()) }
}
export async function panelInteligenciaMonitor(ctx: Ctx) { admin(ctx, true); return AVAL.monitorar() }
export async function panelOportunidadeLab(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}; if (!b.chave) fail(400, 'Informe a oportunidade.', 'invalid', 'chave')
  const r = await FB.enviarAoLaboratorio(u, String(b.chave), String(b.nota || '')); await audit(u.id, 'inteligencia.feedback.laboratorio', r.propostaId, { chave: b.chave, feedbacks: r.feedbacks }); return r
}
export async function panelOportunidadeDescartar(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}; if (!b.chave) fail(400, 'Informe a oportunidade.', 'invalid', 'chave')
  const r = await FB.descartar(String(b.chave)); await audit(u.id, 'inteligencia.feedback.descartar', null, { chave: b.chave, feedbacks: r.feedbacks }); return r
}

/* ---------- Fase 6: aprendizado contínuo (administrador) ---------- */
const APR = () => import('../ai/aprendizado.js')
export async function panelAprendizadoGet(ctx: Ctx) { admin(ctx); return (await APR()).painel() }
export async function panelAprendizadoPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, POL = await import('../ai/politica.js'), mud: any = {}
  if (b.ativo !== undefined) { if (typeof b.ativo !== 'boolean') fail(400, 'Informe ativo: true ou false.', 'invalid', 'ativo'); mud.ativo = b.ativo }
  if (b.pararGradualEmRegressao !== undefined) { if (typeof b.pararGradualEmRegressao !== 'boolean') fail(400, 'Informe true ou false.', 'invalid', 'pararGradualEmRegressao'); mud.pararGradualEmRegressao = b.pararGradualEmRegressao }
  if (b.minUsuarios !== undefined) { const n = Number(b.minUsuarios); if (!Number.isInteger(n) || n < 2 || n > 50) fail(400, 'Mínimo de usuários distintos: de 2 a 50.', 'invalid', 'minUsuarios'); mud.minUsuarios = n }
  if (b.minAmostra !== undefined) { const n = Number(b.minAmostra); if (!Number.isInteger(n) || n < 5 || n > 1000) fail(400, 'Amostra mínima: de 5 a 1000 respostas.', 'invalid', 'minAmostra'); mud.minAmostra = n }
  if (!Object.keys(mud).length) fail(400, 'Nada para alterar.', 'invalid')
  await POL.salvarCfg(mud); await audit(u.id, 'aprendizado.config', null, mud)
  return (await APR()).painel()
}
export async function panelAprendizadoAnalisar(ctx: Ctx) { const u = admin(ctx, true); const r = await (await APR()).gerarPropostas(); await audit(u.id, 'aprendizado.analise', null, { novas: r.novas.length, turnos: r.turnos }); return r }
const idDe = (ctx: Ctx) => { const n = Number(ctx.params.id); if (!Number.isInteger(n) || n <= 0) fail(400, 'Proposta inválida.', 'invalid'); return n }
export async function panelAprendizadoTestar(ctx: Ctx) { const u = admin(ctx, true), id = idDe(ctx); const r = await (await APR()).experimentar(id, u); await audit(u.id, 'aprendizado.teste', id, { aprovada: r.aprovada, motivos: r.motivos }); return r }
export async function panelAprendizadoDecidir(ctx: Ctx) {
  const u = admin(ctx, true), id = idDe(ctx), b = ctx.body || {}
  const r = await (await APR()).decidir(id, String(b.acao || ''), u, { modo: b.modo, pct: b.pct, nota: b.nota }); await audit(u.id, 'aprendizado.' + String(b.acao), id, { modo: b.modo, pct: b.pct, resultado: r })
  return r
}
export async function panelAprendizadoRestaurar(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, v = b.versao == null ? null : Number(b.versao)
  if (v !== null && (!Number.isInteger(v) || v <= 0)) fail(400, 'Versão inválida.', 'invalid', 'versao')
  const r = await (await APR()).restaurarVersao(v, u); await audit(u.id, 'aprendizado.restaurar', v, r); return r
}
export async function panelAprendizadoVigiar(ctx: Ctx) { admin(ctx, true); return (await APR()).vigiar() }
export async function panelAprendizadoRelatorio(ctx: Ctx) { admin(ctx); return { markdown: await (await APR()).relatorio() } }
