// Central de Marketing (dono da empresa) e privacidade (cliente). Toda operação confere no servidor a empresa do usuário:
// campanhas, público e resultados de uma empresa nunca são visíveis nem alteráveis por outra.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { q, one, J } from '../db/index.js'
import * as M from '../lib/marketing.js'
import { validTz } from '../lib/time.js'
export async function mktGet(ctx: Ctx) {
  const u = requireUser(ctx)
  await M.sincronizarSuspensoes().catch(() => {}) // reflete na hora a chave do administrador
  const pl = await M.ownerPlan(u.id), rel = !!pl.limites.relatorios
  const consent = await q("SELECT c.origem, c.criado_em, c.status, u.name FROM marketing_consents c JOIN users u ON u.id = c.user_id WHERE c.owner_id = $1 ORDER BY c.criado_em DESC LIMIT 300", [u.id])
  const camps = pl.business ? await q('SELECT * FROM mkt_campaigns WHERE owner_id = $1 AND business_id = $2 ORDER BY id DESC LIMIT 100', [u.id, pl.business.id]) : []
  const segN = async (s: any) => (await M.audience(u.id, s)).length
  const grupos: Record<string, number> = {}; for (const c of camps) grupos[c.status] = (grupos[c.status] || 0) + 1
  return { ...pl, fuso: validTz(J<any>((await one('SELECT settings FROM users WHERE id = $1', [u.id]))?.settings, {}).timezone),
    publico: { autorizados: consent.filter((c: any) => c.status === 'ativo').length, revogados: consent.filter((c: any) => c.status !== 'ativo').length, convite: consent.filter((c: any) => c.status === 'ativo' && /^convite/.test(c.origem)).length, pedido: consent.filter((c: any) => c.status === 'ativo' && /^pedido/.test(c.origem)).length,
      segmentos: { todos: await segN({ tipo: 'todos' }), compradores: await segN({ tipo: 'compradores' }), recentes: await segN({ tipo: 'recentes', dias: 30 }), sem_compras: await segN({ tipo: 'sem_compras', dias: 60 }) } },
    clientes: rel ? consent.map((c: any) => ({ nome: String(c.name || '').split(' ')[0], origem: /^convite/.test(c.origem) ? 'convite de compromisso' : /^pedido/.test(c.origem) ? 'pedido' : c.origem, desde: c.criado_em, status: c.status })) : [],
    grupos, campanhas: camps.map((c: any) => M.campanhaOut(c, rel)),
    modelos: [{ titulo: 'Novidade na casa', mensagem: 'Temos novidade esperando por você! Toque para conferir.' }, { titulo: 'Oferta da semana', mensagem: 'Só esta semana: condição especial para clientes. Toque para ver.' }, { titulo: 'Horários disponíveis', mensagem: 'Abrimos novos horários. Garanta o seu antes que acabem!' }] }
}
export async function mktPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const out = (c: any) => ({ ok: true, campanha: { id: Number(c.id), status: c.status, total: Number(c.total), agendadaPara: c.agendada_para } })
  if (b.action === 'empresa') return M.definirEmpresaAtiva(u.id, b.ativo === true)
  if (b.action === 'criar') return out(await M.createCampaign(u.id, b))
  if (b.action === 'salvar') return out(await M.salvarCampanha(u.id, { ...b, rascunho: b.rascunho === true }))
  if (b.action === 'cancelar') return M.cancelarCampanha(u.id, Number(b.id))
  if (b.action === 'validar') return out(await M.validarCampanha(u.id, Number(b.id), b))
  if (b.action === 'detalhe') { const pl = await M.ownerPlan(u.id); const d = await M.detalheCampanha(u.id, Number(b.id)); if (!pl.limites.relatorios) { d.campanha.cliques = null; d.campanha.pushOk = null } return d }
  if (b.action === 'publico') { const pl = await M.ownerPlan(u.id); const seg = M.normSeg(b.segmento || {}); return { total: (await M.audience(u.id, pl.limites.segmentacao ? seg : { tipo: 'todos' })).length } }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function mktClickGet(ctx: Ctx) { const [id, s] = String(ctx.params.id || '').split('.'); return M.clickInfo(Number(id), String(s || ctx.query.get('s') || '')) }
/** Imagem da campanha (pública por link assinado: quem recebeu a oferta vê a imagem). */
export async function mktImgGet(ctx: Ctx) {
  const [id, s] = String(ctx.params.id || '').split('.'); const ok = M.checkImg(Number(id), String(s || ''))
  const r = ok ? await one('SELECT imagem FROM mkt_campaigns WHERE id = $1', [Number(id)]) : null
  const m = /^data:(image\/(?:png|jpeg|webp));base64,(.+)$/.exec(String(r?.imagem || ''))
  if (!m) { ctx.res.writeHead(404, { 'Content-Type': 'text/plain' }); ctx.res.end('not found'); return { _handled: true } }
  ctx.res.writeHead(200, { 'Content-Type': m[1], 'Cache-Control': 'public, max-age=86400', 'X-Content-Type-Options': 'nosniff' }); ctx.res.end(Buffer.from(m[2], 'base64')); return { _handled: true }
}
export async function mktUnsubGet(ctx: Ctx) {
  const o = Number(ctx.query.get('o')), uid = Number(ctx.query.get('u')), ok = M.checkUnsub(o, uid, String(ctx.query.get('s') || ''))
  if (ok) await M.setConsent(o, uid, false, 'descadastro')
  ctx.res.writeHead(ok ? 200 : 400, { 'Content-Type': 'text/html; charset=utf-8' })
  ctx.res.end(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#0b0d12;color:#e8eaf0;padding:40px 20px;text-align:center"><h1 style="font-size:20px">${ok ? 'Pronto, você não vai mais receber ofertas desta empresa.' : 'Link inválido.'}</h1><p><a href="/" style="color:#7aa2ff">Abrir o Meu Assistente</a></p></body>`)
  return { _handled: true }
}
/** Cliente: ver e cancelar as autorizações de ofertas que deu. */
export async function myConsentsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const rows = await q("SELECT c.owner_id, c.origem, c.criado_em, c.status, b.data FROM marketing_consents c LEFT JOIN businesses b ON b.owner_id = c.owner_id AND b.status = 'ativo' WHERE c.user_id = $1 ORDER BY c.criado_em DESC", [u.id])
  const vist = new Set<number>(); const out: any[] = []
  for (const r of rows) { if (vist.has(Number(r.owner_id))) continue; vist.add(Number(r.owner_id)); const ow = await one('SELECT name FROM users WHERE id = $1', [r.owner_id]); out.push({ ownerId: Number(r.owner_id), nome: J<any>(r.data, {}).empresa || String(ow?.name || '').split(' ')[0], status: r.status, desde: r.criado_em, origem: r.origem }) }
  const me = await one('SELECT settings FROM users WHERE id = $1', [u.id]); out.unshift({ ownerId: 0, nome: 'Novidades e ofertas do Meu Assistente', status: J<any>(me?.settings, {}).promoSistemaOptOut ? 'revogado' : 'ativo', desde: null, origem: 'sistema' })
  return { items: out }
}
export async function myConsentsPost(ctx: Ctx) { const u = requireUser(ctx)
  if (Number(ctx.body?.ownerId) === 0) { const r = await one('SELECT settings FROM users WHERE id = $1', [u.id]); const st = { ...J<any>(r?.settings, {}), promoSistemaOptOut: ctx.body?.aceito !== true }; await q('UPDATE users SET settings = $1 WHERE id = $2', [JSON.stringify(st), u.id]); return { status: st.promoSistemaOptOut ? 'revogado' : 'ativo' } }
  return M.setConsent(Number(ctx.body?.ownerId), u.id, ctx.body?.aceito === true, ctx.body?.aceito ? 'perfil' : 'perfil') }

/* ---------- campanhas do próprio Meu Assistente (administrador): push/notificação no app, nunca e-mail ---------- */
async function requireAdm(ctx: Ctx) { const u = requireUser(ctx); if (u.role !== 'superadmin' && u.role !== 'admin') fail(403, 'Só para administradores.', 'forbidden'); return u }
export async function sysMktGet(ctx: Ctx) {
  await requireAdm(ctx)
  const camps = await q("SELECT * FROM mkt_campaigns WHERE business_id IS NULL ORDER BY id DESC LIMIT 50")
  return { ativo: await M.mktOn(), publico: (await M.systemAudience()).length, campanhas: camps.filter((c: any) => J<any>(c.segmento, {}).sistema).map((c: any) => ({ id: Number(c.id), titulo: c.titulo, mensagem: c.mensagem, status: c.status, agendadaPara: c.agendada_para, concluidaEm: c.concluida_em, total: c.total, enviados: c.enviados, pushOk: c.push_ok, cliques: c.cliques, ignorados: c.ignorados, erro: c.erro })) }
}
export async function sysMktPost(ctx: Ctx) {
  const u = await requireAdm(ctx), b = ctx.body || {}
  if (b.action === 'criar') { const c: any = await M.createSystemCampaign(u.id, b); return { ok: true, id: Number(c.id), status: c.status } }
  if (b.action === 'cancelar') { const r = await q("UPDATE mkt_campaigns SET status = 'cancelada' WHERE id = $1 AND business_id IS NULL AND status = 'agendada' RETURNING id", [Number(b.id)]); if (!r.length) fail(400, 'Só campanhas ainda não enviadas podem ser canceladas.', 'invalid'); return { ok: true } }
  fail(400, 'Ação inválida.', 'invalid')
}
