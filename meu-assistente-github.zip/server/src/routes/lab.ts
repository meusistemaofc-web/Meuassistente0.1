// Laboratório de IA: rotas exclusivas de administradores (leitura: qualquer admin; escrita: panel.manage). Nada aqui executa ação real.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import * as L from '../ai/lab.js'

function admin(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function labGet(ctx: Ctx) {
  const u = admin(ctx), estado = ctx.query.get('estado') || undefined
  return { categorias: L.CATEGORIAS, estados: L.ESTADOS.map((e) => ({ id: e, label: L.ESTADO_LABEL[e] })), resumo: await L.resumo(), propostas: await L.listar(estado), mensagens: await L.mensagens(u.id), historico: await L.historicoGeral(100) }
}
export async function labPropostaGet(ctx: Ctx) { admin(ctx); return L.detalhe(Number(ctx.params.id)) }
export async function labPost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, actor = `admin ${u.id}`, id = Number(b.id)
  switch (b.action) {
    case 'chat': { const r = await L.conversaAdmin(u, String(b.texto || '')); await audit(u.id, 'lab.chat', (r as any).propostaId ?? null, {}); return r }
    case 'simular': return L.simular(u, String(b.texto || ''), b.regra ? String(b.regra).slice(0, 1500) : null, [], b.regra ? String(b.regra) : '')
    case 'criar': { const nid = await L.criar(actor, u.id, b); await audit(u.id, 'lab.criar', nid, {}); return L.analisar(nid, actor) }
    case 'editar': { const r = await L.editar(id, actor, b); await audit(u.id, 'lab.editar', id, {}); return r }
    case 'analisar': return L.analisar(id, actor)
    case 'testar': { const r = await L.testar(u, id, actor, Array.isArray(b.cenarios) ? b.cenarios : undefined); await audit(u.id, 'lab.testar', id, {}); return r }
    case 'enviar': { const r = await L.enviarParaAprovacao(id, actor, !!b.confirmar); await audit(u.id, 'lab.enviar', id, {}); return r }
    case 'aprovar': { const r = await L.aprovar(id, actor); await audit(u.id, 'lab.aprovar', id, {}); return r }
    case 'rejeitar': { const r = await L.rejeitar(id, actor, String(b.motivo || '')); await audit(u.id, 'lab.rejeitar', id, {}); return r }
    case 'publicar': { const r = await L.publicar(id, actor, !!b.confirmar); await audit(u.id, 'lab.publicar', id, {}); return r }
    case 'desativar': { const r = await L.desativar(id, actor); await audit(u.id, 'lab.desativar', id, {}); return r }
    case 'reativar': { const r = await L.reativar(id, actor); await audit(u.id, 'lab.reativar', id, {}); return r }
    case 'reverter': { const r = await L.reverter(id, actor); await audit(u.id, 'lab.reverter', id, {}); return r }
  }
  fail(400, 'Ação desconhecida.', 'invalid', 'action')
}
