// Ícone (favicon) da fonte de uma resposta do chat: o app mostra um ícone pequeno e clicável por fonte, junto do horário.
// O servidor busca o favicon real do site da fonte (/favicon.ico ou o ícone declarado na página) com as mesmas proteções da leitura de páginas do Cérebro (só http/https,
// sem endereços internos, cada redirecionamento revalidado, tempo e tamanho limitados, só imagem) e guarda em cache
// (7 dias; falha fica 1 dia). Sem ícone, o app mostra a inicial do site.
import type { Ctx } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { one, q, nowIso } from '../db/index.js'
import { validarUrl, UA } from '../ai/cerebro/web.js'

const DIA = 86400_000
/** Favicon real do site: /favicon.ico; se não houver, o ícone declarado na página inicial (<link rel="icon">,
 *  "shortcut icon" ou "apple-touch-icon"). */
async function buscarIcone(origem: string): Promise<{ tipo: string; dados: Buffer } | null> {
  const direto = await baixarImagem(origem + '/favicon.ico')
  if (direto) return direto
  const html = await baixarTexto(origem + '/')
  if (!html) return null
  const links = [...html.matchAll(/<link\b[^>]*>/gi)].map((m) => m[0]).filter((l) => /rel\s*=\s*["']?[^"'>]*\b(icon|apple-touch-icon)\b/i.test(l))
  // prefere ícone pequeno/vetorial; apple-touch-icon por último (é grande)
  links.sort((a, b) => Number(/apple-touch/i.test(a)) - Number(/apple-touch/i.test(b)))
  for (const l of links.slice(0, 4)) {
    const href = (l.match(/href\s*=\s*["']([^"']+)["']/i) || l.match(/href\s*=\s*([^\s>]+)/i) || [])[1]
    if (!href || /^data:/i.test(href)) continue
    let u = ''; try { u = new URL(href, origem + '/').href } catch { continue }
    const ic = await baixarImagem(u); if (ic) return ic
  }
  return null
}
/** Página inicial (só o começo do HTML, onde ficam os <link>): para achar o ícone declarado. */
async function baixarTexto(url: string): Promise<string> {
  let atual = url
  for (let salto = 0; salto < 4; salto++) {
    const u = await validarUrl(atual).catch(() => null); if (!u) return ''
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), 5000)
    try {
      const r = await fetch(u, { redirect: 'manual', signal: ac.signal, headers: { 'User-Agent': UA, Accept: 'text/html' } })
      if (r.status >= 300 && r.status < 400 && r.headers.get('location')) { atual = new URL(r.headers.get('location')!, u).href; continue }
      if (!r.ok || !/text\/html|application\/xhtml/.test(r.headers.get('content-type') || '')) return ''
      const reader = r.body?.getReader(); let total = 0; const partes: Uint8Array[] = []
      if (reader) for (;;) { const { done, value } = await reader.read(); if (done) break; total += value.length; partes.push(value); if (total > 200_000 || /<\/head>/i.test(Buffer.from(value).toString('latin1'))) { ac.abort(); break } }
      return Buffer.concat(partes).toString('utf8')
    } catch { return '' } finally { clearTimeout(t) }
  }
  return ''
}
async function baixarImagem(url: string): Promise<{ tipo: string; dados: Buffer } | null> {
  let atual = url
  for (let salto = 0; salto < 4; salto++) {
    const u = await validarUrl(atual).catch(() => null); if (!u) return null
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), 5000)
    try {
      const r = await fetch(u, { redirect: 'manual', signal: ac.signal, headers: { 'User-Agent': UA, Accept: 'image/*' } })
      if (r.status >= 300 && r.status < 400 && r.headers.get('location')) { atual = new URL(r.headers.get('location')!, u).href; continue }
      const tipo = (r.headers.get('content-type') || '').split(';')[0].trim().toLowerCase()
      if (!r.ok || !/^image\/(x-icon|vnd\.microsoft\.icon|png|gif|jpeg|webp|svg\+xml)$/.test(tipo)) return null
      const reader = r.body?.getReader(); let total = 0; const partes: Uint8Array[] = []
      if (reader) for (;;) { const { done, value } = await reader.read(); if (done) break; total += value.length; if (total > 100_000) { ac.abort(); return null } partes.push(value) }
      return total ? { tipo, dados: Buffer.concat(partes) } : null
    } catch { return null } finally { clearTimeout(t) }
  }
  return null
}
export async function fonteIconeGet(ctx: Ctx) {
  requireUser(ctx)
  let origem = ''
  try { const u = new URL(String(ctx.query.get('u') || '')); if (/^https?:$/.test(u.protocol) && !u.username && !u.password) origem = u.origin } catch { /* inválido */ }
  const res = ctx.res
  const fim = (status: number, corpo?: Buffer, tipo = 'text/plain', idade = 3600) => { res.writeHead(status, { 'Content-Type': tipo, 'Cache-Control': `private, max-age=${idade}`, 'X-Content-Type-Options': 'nosniff', ...(tipo === 'image/svg+xml' ? { 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" } : {}) }); res.end(corpo); return { _handled: true } }
  if (!origem) return fim(400)
  const key = 'ico:' + origem
  const c: any = await one('SELECT body, status, fetched_at FROM brain_web_cache WHERE key = $1', [key])
  if (c && Date.parse(String(c.fetched_at)) > Date.now() - (Number(c.status) === 200 ? 7 : 1) * DIA) {
    if (Number(c.status) !== 200) return fim(404)
    const j = JSON.parse(String(c.body)); return fim(200, Buffer.from(j.b, 'base64'), j.t, 7 * 86400)
  }
  const ic = await buscarIcone(origem).catch(() => null)
  await q('DELETE FROM brain_web_cache WHERE key = $1', [key])
  await q('INSERT INTO brain_web_cache (key, kind, body, status, fetched_at) VALUES ($1,$2,$3,$4,$5)', [key, 'icone', ic ? JSON.stringify({ t: ic.tipo, b: ic.dados.toString('base64') }) : '', ic ? 200 : 404, nowIso()])
  return ic ? fim(200, ic.dados, ic.tipo, 7 * 86400) : fim(404)
}
