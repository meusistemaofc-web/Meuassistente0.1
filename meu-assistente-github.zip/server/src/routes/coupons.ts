// Cupons de desconto: painel do administrador (todas as empresas), ambiente da empresa (só as suas), área do cliente e checkout.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import * as C from '../lib/coupons.js'
import { ownBusiness, calcLinhas } from './businesses.js'

function admin(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
/** Ações comuns (criar, editar, pausar, excluir, distribuir) — a autorização é decidida por quem chama; o cupom é sempre filtrado pela empresa. */
async function acao(businessId: number, b: any, actor: string, userId: number, auditKey: string) {
  switch (b.action) {
    case 'create': { const c = await C.createCoupon(businessId, b, actor, userId); await audit(userId, `${auditKey}.create`, c.id, { empresa: businessId, codigo: c.codigo }); return { ok: true, cupom: c } }
    case 'update': { const c = await C.updateCoupon(Number(b.id), businessId, b, actor); await audit(userId, `${auditKey}.update`, c.id, {}); return { ok: true, cupom: c } }
    case 'status': { const c = await C.setStatus(Number(b.id), businessId, String(b.status), actor); await audit(userId, `${auditKey}.status`, c.id, { status: c.status }); return { ok: true, cupom: c } }
    case 'delete': { await C.removeCoupon(Number(b.id), businessId, actor); await audit(userId, `${auditKey}.delete`, Number(b.id), {}); return { ok: true } }
    case 'preview': { const p = await C.previewDistribuicao(businessId, Number(b.id), b); return { ok: true, alvo: p.alvo.length, comAutorizacao: p.alvo.filter((i) => p.consentidos.has(i)).length } }
    case 'distribuir': { const r = await C.distribuir(businessId, Number(b.id), b, actor); await audit(userId, `${auditKey}.distribuir`, Number(b.id), { canal: r.canal, alvo: r.alvo }); return r }
    case 'detalhe': { const id = Number(b.id); await C.ofBusiness(id, businessId); return { ok: true, cupom: await C.stats(id), historico: await C.changes(id), clientes: await C.targets(id) } }
    default: fail(400, 'Ação inválida.', 'invalid')
  }
}
const nome = (u: any, adm: boolean) => adm ? `admin ${u.id}` : `empresa ${u.id}`

/* ---------- administrador ---------- */
export async function panelCouponsGet(ctx: Ctx) {
  admin(ctx); const bid = Number(ctx.query.get('empresa')) || null
  const d = await C.dashboard(bid)
  const emp = (await q("SELECT id, data, status FROM businesses WHERE status <> 'institucional' ORDER BY id DESC LIMIT 500")).map((b: any) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa || `Empresa #${b.id}`, status: b.status }))
  return { ...d, empresas: emp }
}
export async function panelCouponsPost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, bid = Number(b.businessId)
  if (!(bid > 0) || !(await one('SELECT id FROM businesses WHERE id = $1', [bid]))) fail(400, 'Escolha a empresa responsável pelo cupom.', 'invalid', 'businessId')
  return acao(bid, b, nome(u, true), u.id, 'cupons.admin')
}

/* ---------- empresa ---------- */
export async function businessCouponsGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), d = await C.dashboard(Number(b.id))
  const produtos = (await q('SELECT id, data FROM products WHERE business_id = $1 ORDER BY id LIMIT 500', [b.id])).map((p: any) => ({ id: Number(p.id), nome: J<any>(p.data, {}).nome, tipo: J<any>(p.data, {}).tipo || 'produto' }))
  const crm = await C.crmSegmentos(Number(b.id))
  return { ...d, produtos, publico: crm ? { todos: crm.seg.todos.length, novos: crm.seg.novos.length, recorrentes: crm.seg.recorrentes.length, inativos: crm.seg.inativos.length, potenciais: crm.seg.potenciais.length, autorizados: crm.consentidos.size } : null }
}
export async function businessCouponsPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx)
  if (b.status !== 'ativo') fail(403, 'Sua empresa precisa estar ativa para criar cupons.', 'forbidden')
  return acao(Number(b.id), ctx.body || {}, nome(u, false), u.id, 'cupons.empresa')
}

/* ---------- cliente ---------- */
export async function couponsMineGet(ctx: Ctx) { const u = requireUser(ctx); return C.mine(u.id) }
export async function businessCouponsPublicGet(ctx: Ctx) { return { cupons: await C.publicOf(Number(ctx.params.id), ctx.user ? Number(ctx.user.id) : null) } } // catálogo público: visitante sem conta também vê os cupons públicos
/** Checkout: mostra o desconto do cupom antes de finalizar (nada é gravado). */
export async function couponValidatePost(ctx: Ctx) {
  const u = requireUser(ctx), body = ctx.body || {}, b0 = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b0 || b0.status !== 'ativo') fail(404, 'Loja não encontrada.', 'not_found')
  const b = b0!
  if (Number(b.owner_id) === u.id) fail(400, 'Você não pode usar cupom na sua própria loja.', 'invalid')
  const { linhas, sub } = await calcLinhas(b, Array.isArray(body.itens) ? body.itens.slice(0, 50) : [])
  const a = await C.validar(Number(b.id), u.id, String(body.codigo || ''), linhas.map((l) => ({ pid: l.pid, qtd: l.qtd, preco: l.preco })))
  return { ok: true, cupom: { id: a.coupon.id, codigo: a.coupon.codigo, nome: a.coupon.nome, tipo: a.coupon.tipo, valor: a.coupon.valor, combinaMoedas: a.coupon.combinaMoedas }, desconto: a.desconto, subtotal: sub, subtotalComCupom: Math.round((sub - a.desconto) * 100) / 100 }
}
