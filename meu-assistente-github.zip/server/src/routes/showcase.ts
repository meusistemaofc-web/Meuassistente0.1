// Vitrine de links: painel do administrador e consulta dos chats (assistente e agentes das empresas).
import type { Ctx } from '../lib/http.js'
import { fail, clientIp } from '../lib/http.js'
import { q } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { rateLimit } from '../lib/security.js'
import * as S from '../lib/showcase.js'
import { ensureConversation, insertMsg, LINK_CARD } from './chat.js'
import { one, nowIso } from '../db/index.js'

function admin(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelShowcaseGet(ctx: Ctx) {
  admin(ctx); const itens = await S.listAdmin()
  const empresas = (await q("SELECT id, data FROM businesses WHERE status = 'ativo' ORDER BY id DESC LIMIT 300")).map((b: any) => ({ id: Number(b.id), empresa: (typeof b.data === 'string' ? JSON.parse(b.data || '{}') : b.data || {}).empresa || `Empresa #${b.id}` }))
  return { itens, empresas, resumo: { total: itens.length, ativos: itens.filter((i) => i.ativo).length, acessos: itens.reduce((a, i) => a + (i.acessos || 0), 0), cliques: itens.reduce((a, i) => a + (i.cliques || 0), 0) } }
}
export async function panelShowcasePost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}
  switch (b.action) {
    case 'create': { const r = await S.create(b, u.id); await audit(u.id, 'showcase.create', r.id, { palavra: r.palavra }); return { ok: true, item: r } }
    case 'update': { const r = await S.update(Number(b.id), b); await audit(u.id, 'showcase.update', r.id, { palavra: r.palavra }); return { ok: true, item: r } }
    case 'toggle': { const r = await S.update(Number(b.id), { ativo: !!b.ativo }); await audit(u.id, 'showcase.toggle', r.id, { ativo: r.ativo }); return { ok: true, item: r } }
    case 'delete': { await S.remove(Number(b.id)); await audit(u.id, 'showcase.delete', Number(b.id), {}); return { ok: true } }
    case 'reorder': { await S.reorder(b.ids); await audit(u.id, 'showcase.reorder', null, {}); return { ok: true } }
  }
  fail(400, 'Ação desconhecida.', 'invalid', 'action')
}
async function viewer(ctx: Ctx, canal: 'chat' | 'agentes'): Promise<S.Viewer> {
  if (canal === 'chat') requireUser(ctx) // no chat do assistente só usuários logados; os agentes das empresas são públicos
  const u = ctx.user && ctx.session && !ctx.session.mfa_pending ? ctx.user : null
  const owned = u ? (await q('SELECT id FROM businesses WHERE owner_id = $1', [u.id])).map((r: any) => Number(r.id)) : []
  return { userId: u ? Number(u.id) : null, isAdmin: !!u && u.role !== 'user', ownedBusinesses: owned }
}
const canalOf = (ctx: Ctx) => (ctx.query.get('canal') === 'agentes' ? 'agentes' : 'chat') as 'chat' | 'agentes'
const biz = (ctx: Ctx) => Math.max(0, Math.floor(Number(ctx.query.get('b')) || 0))
/** Lista leve (sem imagem nem URL) do menu "/": já filtrada pelo que o usuário pode ver. Aceita ?q=/mus para filtrar no servidor. */
export async function showcaseGet(ctx: Ctx) {
  const canal = canalOf(ctx), v = await viewer(ctx, canal)
  if (!rateLimit('showcase:' + clientIp(ctx.req), 240, 60_000)) fail(429, 'Muitas consultas. Aguarde um instante.', 'rate_limited')
  const lista = (await S.visibleList(canal, v, biz(ctx))).map(S.lite), t = ctx.query.get('q')
  if (t == null) return { itens: lista }
  const r = S.search(lista, t); return { exato: r.exato, itens: r.itens }
}
export async function showcaseCardGet(ctx: Ctx) { const canal = canalOf(ctx), v = await viewer(ctx, canal); return { card: await S.openCard(Number(ctx.params.id), canal, v, biz(ctx)) } }
export async function showcaseClickPost(ctx: Ctx) {
  const canal = canalOf(ctx), v = await viewer(ctx, canal)
  if (!rateLimit('showcase-click:' + clientIp(ctx.req), 60, 60_000)) fail(429, 'Muitos cliques. Aguarde um instante.', 'rate_limited')
  return S.click(Number(ctx.params.id), canal, v, biz(ctx))
}

/** Cartão de link como mensagem estruturada (link_card) do histórico oficial da conversa: associado ao conversation_id, na ordem cronológica,
 *  com os metadados do cartão e identificador único (opId) contra duplicação. O servidor revalida a visibilidade do atalho. */
export async function showcaseMessagePost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (!rateLimit('showcase-msg:' + u.id, 120, 60_000)) fail(429, 'Muitas consultas. Aguarde um instante.', 'rate_limited')
  const convId = String(b.conversationId || '').slice(0, 64), opId = String(b.opId || '').trim()
  if (!/^[A-Za-z0-9-]{8,40}$/.test(opId)) fail(400, 'Identificador da operação inválido.', 'invalid', 'opId')
  const linkId = Math.floor(Number(ctx.params.id)), content = `⟦lc:${linkId}:${opId}⟧`
  if (!(linkId > 0) || !LINK_CARD.test(content)) fail(400, 'Cartão inválido.', 'invalid')
  const dup = await one("SELECT m.id FROM messages m JOIN conversations c ON c.id = m.conversation_id WHERE m.conversation_id = $1 AND c.user_id = $2 AND m.role = 'user' AND m.content = $3", [convId, u.id, content])
  if (dup) return { ok: true, duplicado: true, id: Number(dup.id) } // mesma operação repetida: nunca duplica o cartão
  const card = await S.openCard(linkId, 'chat', await viewer(ctx, 'chat'))
  const conv = await ensureConversation(u, convId, '') // título 'Nova conversa' até a primeira pergunta real
  const cards = [{ kind: 'link_card', type: 'link_card', linkId: card.id, palavra: card.palavra, titulo: card.titulo, descricao: card.descricao, imagem: card.imagem, url: card.url, opId }]
  const m = await insertMsg(u, String(conv!.id), 'user', content, cards)
  await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), conv!.id])
  return { ok: true, duplicado: false, id: Number(m.id), createdAt: m.created_at }
}
