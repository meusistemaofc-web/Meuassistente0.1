// CRM de "Sua empresa": rotas finas sobre lib/crm.ts. Toda rota exige o DONO da empresa (isolamento) e respeita plano/módulo.
import type { Ctx } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as K from '../lib/crm.js'
import { fail } from '../lib/http.js'

async function ini(ctx: Ctx) {
  const u = requireUser(ctx), bid = Number(ctx.params.id); const b = await K.acesso(u.id, bid)
  return { u, bid, b, a: { id: u.id, nome: u.name, via: 'painel' } as K.Ator }
}
const nid = (v: any) => { const n = Number(v); if (!Number.isInteger(n) || n <= 0) fail(400, 'Identificador inválido.', 'invalid'); return n }
const Q = (ctx: Ctx, k: string) => String(ctx.query.get(k) || '')

export async function crmOverviewGet(ctx: Ctx) { const { bid, u } = await ini(ctx); return { ...(await K.CRMService.visao(bid)), rotulos: await K.CRMService.rotulos(bid, u.name), config: await K.config(bid) } }
export async function crmContactsGet(ctx: Ctx) { const { bid } = await ini(ctx); return { contatos: await K.CustomerRelationshipService.listar(bid, { busca: Q(ctx, 'q'), tipo: Q(ctx, 'tipo'), categoria: Q(ctx, 'categoria'), etiqueta: Q(ctx, 'etiqueta'), origem: Q(ctx, 'origem'), responsavel: Q(ctx, 'responsavel'), arquivados: Q(ctx, 'arquivados') === '1', recorrentes: Q(ctx, 'recorrentes') === '1' }) } }
export async function crmContactsPost(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, ...(await K.CustomerRelationshipService.salvar(bid, ctx.body || {}, a, 'manual')) } }
export async function crmContactGet(ctx: Ctx) { const { bid } = await ini(ctx); return K.CustomerRelationshipService.perfil(bid, nid(ctx.params.cid)) }
export async function crmContactPut(ctx: Ctx) {
  const { bid, a } = await ini(ctx), id = nid(ctx.params.cid), b = ctx.body || {}
  if (b.arquivado !== undefined) await K.CustomerRelationshipService.arquivar(bid, id, b.arquivado === true, a)
  return { ok: true, contato: await K.CustomerRelationshipService.editar(bid, id, b, a) }
}
export async function crmContactEventPost(ctx: Ctx) { const { bid, a } = await ini(ctx); await K.CustomerRelationshipService.registrar(bid, nid(ctx.params.cid), ctx.body || {}, a); return { ok: true, linhaDoTempo: await K.CustomerRelationshipService.linhaDoTempo(bid, nid(ctx.params.cid)) } }

export async function crmPipelineGet(ctx: Ctx) { const { bid } = await ini(ctx); return { etapas: await K.SalesPipelineService.funil(bid) } }
export async function crmStagesPost(ctx: Ctx) {
  const { bid, a } = await ini(ctx), b = ctx.body || {}
  if (Array.isArray(b.ordem)) return { ok: true, etapas: await K.SalesPipelineService.reordenar(bid, b.ordem.map(Number), a) }
  return { ok: true, etapa: await K.SalesPipelineService.criar(bid, b, a) }
}
export async function crmStagePut(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, etapa: await K.SalesPipelineService.editar(bid, nid(ctx.params.sid), ctx.body || {}, a) } }
export async function crmStageDelete(ctx: Ctx) { const { bid, a } = await ini(ctx); await K.SalesPipelineService.remover(bid, nid(ctx.params.sid), ctx.body?.moverPara ? Number(ctx.body.moverPara) : (Q(ctx, 'moverPara') ? Number(Q(ctx, 'moverPara')) : null), a); return { ok: true } }

export async function crmOppsGet(ctx: Ctx) { const { bid } = await ini(ctx); return { oportunidades: await K.OpportunityService.listar(bid, { situacao: Q(ctx, 'situacao'), busca: Q(ctx, 'q'), contatoId: Q(ctx, 'contatoId') ? Number(Q(ctx, 'contatoId')) : undefined }) } }
export async function crmOppsPost(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, oportunidade: await K.OpportunityService.criar(bid, ctx.body || {}, a) } }
export async function crmOppGet(ctx: Ctx) { const { bid } = await ini(ctx); return K.OpportunityService.obter(bid, nid(ctx.params.oid)) }
export async function crmOppPut(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, oportunidade: await K.OpportunityService.editar(bid, nid(ctx.params.oid), ctx.body || {}, a) } }
export async function crmOppDelete(ctx: Ctx) { const { bid, a } = await ini(ctx); await K.OpportunityService.excluir(bid, nid(ctx.params.oid), a); return { ok: true } }
export async function crmOppMovePost(ctx: Ctx) { const { bid, a } = await ini(ctx), b = ctx.body || {}; return { ok: true, oportunidade: await K.OpportunityService.mover(bid, nid(ctx.params.oid), nid(b.etapaId), b, a) } }

export async function crmTasksGet(ctx: Ctx) { const { bid } = await ini(ctx); return { tarefas: await K.CRMTaskService.listar(bid, { situacao: Q(ctx, 'situacao'), contatoId: Q(ctx, 'contatoId') ? Number(Q(ctx, 'contatoId')) : undefined }) } }
export async function crmTasksPost(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, tarefa: await K.CRMTaskService.criar(bid, ctx.body || {}, a) } }
export async function crmTaskPut(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, tarefa: await K.CRMTaskService.editar(bid, nid(ctx.params.tid), ctx.body || {}, a) } }
export async function crmTaskStatusPost(ctx: Ctx) { const { bid, a } = await ini(ctx); return { ok: true, tarefa: await K.CRMTaskService.situacao(bid, nid(ctx.params.tid), String(ctx.body?.situacao || ''), a) } }

export async function crmInsightsGet(ctx: Ctx) { const { bid } = await ini(ctx); await K.LeadManagementService.sincronizar(bid); return K.CommercialIntelligenceService.analise(bid) }
export async function crmConfigGet(ctx: Ctx) { const { bid, u } = await ini(ctx); return { config: await K.config(bid), rotulos: await K.CRMService.rotulos(bid, u.name) } }
export async function crmConfigPut(ctx: Ctx) { const { bid, a, u } = await ini(ctx), b = ctx.body || {}; if (b.rotulo) await K.CRMService.criarRotulo(bid, b.rotulo, a); if (b.removerRotulo) await K.CRMService.removerRotulo(bid, nid(b.removerRotulo), a); return { ok: true, config: await K.salvarConfig(bid, b.config || {}, a), rotulos: await K.CRMService.rotulos(bid, u.name) } }
