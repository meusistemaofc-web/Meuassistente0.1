import { etapa, comEtapas, etapaAtual } from '../lib/etapas.js'
import { randomBytes } from 'node:crypto'
import { proposeCorrection } from '../ai/brain.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { identityReply } from '../lib/identity.js'
import { financeSummary } from '../ai/finsummary.js'
import { moduleIntent } from '../lib/modcatalog.js'
import type { UpFile } from '../lib/multipart.js'
import { findLearnedAnswer, saveLearnedAnswer } from '../ai/brain.js'
import { transcribeAudio } from '../ai/docs.js'
import { documentReply } from '../ai/finchat.js'
import { requireModule, modules } from '../lib/usermod.js'
import { isAgendaQuery, agendaReply } from '../ai/agenda.js'
import { financeReply } from '../ai/finchat.js'
import { parseAppointment, parseReminder } from '../ai/appt.js'
import { cardFor } from '../ai/assistant.js'
import { createItem, serialize } from './items.js'
import { humanDate, localDate } from '../lib/time.js'
import { useQuota, refundQuota } from '../lib/usage.js'
import { maybeAd } from './businesses.js'
import { quickReply } from '../ai/intents.js'
import { applyRules } from '../ai/rules.js'
import { registrarUso, type Uso } from '../ai/brain-usage.js'
// /api/chat, /api/conversations — conversas com o assistente.
// Contrato reconstruído do componente de chat (index-MaCmp03.js): a resposta traz
// {conversation, userMessage, assistantMessage}; IDs de conversa são UUIDs gerados no aparelho.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, J, B, db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { runAssistant } from '../ai/assistant.js'
import type { ChatMsg } from '../ai/provider.js'
import { hashOf } from '../ai/once.js'

const CONV_ID = /^[A-Za-z0-9-]{8,64}$/
const convOut = (c: any) => c && ({ id: c.id, title: c.title, pinned: B(c.pinned), createdAt: c.created_at, updatedAt: c.updated_at })
/** Códigos internos (ex.: [rem:34]) nunca aparecem para o usuário. */
export const cleanCodes = (t: string) => String(t || '').replace(/\s*\[(?:rem|lem|lembrete|reminder|task|tarefa|appt|appointment|compromisso|bill|conta|exp|expense|gasto|note|nota|shop|shopping|item|id)\s*[:#]\s*\d+\]/gi, '').replace(/[ \t]+\n/g, '\n').trim()
const avisoTxt = (it: any) => { const r: number[] = Array.isArray(it.reminders) ? it.reminders : it.reminderMinutes > 0 ? [it.reminderMinutes] : []; if (!r.length) return 'Sem aviso antecipado.'; const f = (m: number) => m >= 1440 && m % 1440 === 0 ? `${m / 1440} dia${m >= 2880 ? 's' : ''}` : m >= 60 && m % 60 === 0 ? `${m / 60} hora${m >= 120 ? 's' : ''}` : `${m} minutos`; return `Vou te avisar ${[...r].sort((a, b) => b - a).map(f).join(' e ')} antes.` }
export const LINK_CARD = /^⟦lc:\d+:[A-Za-z0-9-]{8,40}⟧$/
function msgOut(m: any, byId?: Map<number, any>) {
  const replyTo = m.reply_to_id && byId?.get(Number(m.reply_to_id))
  return {
    id: Number(m.id), role: m.role, content: m.role === 'assistant' ? cleanCodes(m.content) : m.content, cards: J(m.cards, []), ...(LINK_CARD.test(String(m.content)) ? { type: 'link_card' } : {}), voiceMessageId: null, createdAt: m.created_at,
    replyToId: m.reply_to_id ? Number(m.reply_to_id) : null,
    ...(replyTo ? { replyTo: { id: Number(replyTo.id), role: replyTo.role, content: String(replyTo.content).slice(0, 200) } } : {}),
    ...(B(m.superseded) ? { superseded: true } : {}),
  }
}

export async function ensureConversation(u: SessionUser, id: string, firstText: string) {
  if (!CONV_ID.test(id)) fail(400, 'Conversa inválida.', 'invalid')
  const c = await one('SELECT * FROM conversations WHERE id = $1', [id])
  if (c) { if (Number(c.user_id) !== u.id) fail(404, 'Conversa não encontrada.', 'not_found'); return c }
  const now = nowIso()
  const title = firstText.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'
  await q('INSERT INTO conversations (id, user_id, title, pinned, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5)', [id, u.id, title, false, now])
  return one('SELECT * FROM conversations WHERE id = $1', [id])
}
async function history(convId: string, beforeId?: number): Promise<ChatMsg[]> {
  const rows = await q(`SELECT role, content FROM messages WHERE conversation_id = $1 AND superseded = $2 AND content NOT LIKE '⟦lc:%' ${beforeId ? 'AND id < $3' : ''} ORDER BY id DESC LIMIT 40`,
    beforeId ? [convId, false, beforeId] : [convId, false])
  return rows.reverse().map((r) => ({ role: r.role, content: r.content }))
}
export async function insertMsg(u: SessionUser, convId: string, role: string, content: string, cards: any[] = [], replyTo: number | null = null) {
  if (role === 'assistant') content = cleanCodes(content)
  const r = await q('INSERT INTO messages (conversation_id, user_id, role, content, cards, reply_to_id, superseded, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
    [convId, u.id, role, content, JSON.stringify(cards), replyTo, false, nowIso()])
  return r[0]
}

const CHAT_CONFIG_KEYS = ['usage_plans', 'modules', 'adaptive', 'fin_dict', 'ceo_identity', 'brain', 'brain_stats', 'engine', 'agenda_ia', 'cognition', 'inteligencia', 'ai_router', 'ai-status', 'ai_providers', 'ad_frequency', 'execucao', 'preditivo', 'aprendizado', 'multiagente', 'cerebro_central']
const CHAT_UM_KEYS = ['idioma', 'doc_pending', 'doc_dup', 'fin_dup', 'fin_pending', 'fin_partial_confirm', 'fin_fix_pending', 'ad_state', 'lembrete_guia']
async function chatPostInner(ctx: Ctx, live?: { onDelta: (s: string) => void; onReset: () => void }) {
  const T = (await import('../lib/timing.js')).timer(), CONS = (await import('../db/index.js')).contarConsultas()
  const u = requireUser(ctx)
  // desempenho: configurações e estados que o chat sempre lê vêm em 2 consultas, em vez de ~22 (memória só desta requisição)
  await (await import('../lib/settings.js')).prefetchConfig(CHAT_CONFIG_KEYS).catch(() => {})
  await (await import('../lib/usermod.js')).prefetchUM(u.id, CHAT_UM_KEYS).catch(() => {})
  const b = ctx.body || {}
  etapa('analisando')
  // anexos: áudio (transcrito), foto ou documento (lidos pelo Gemini), ou várias fotos enviadas antes em /api/images
  let pre: { content: string; cards: any[] } | null = null
  const files: UpFile[] = (ctx as any).files || []
  const audio = files.find((f) => f.field === 'audio'), doc = files.find((f) => f.field === 'image' || f.field === 'document')
  if (audio) { await requireModule('voz'); etapa('audio'); const tx = (await transcribeAudio(audio.data, audio.mime)).slice(0, 4000); if (!tx) fail(422, 'Não entendi o áudio. Tente falar de novo, mais perto do microfone.', 'audio_empty'); b.text = tx }
  else if (doc) {
    await requireModule('imagens')
    const mime = doc.mime === 'application/octet-stream' && /\.pdf$/i.test(doc.filename) ? 'application/pdf' : doc.mime
    if (!/^(image\/(jpeg|png|webp|heic|heif)|application\/pdf)$/.test(mime)) fail(415, 'Envie uma foto (JPG, PNG) ou um PDF.', 'unsupported_file')
    etapa(mime === 'application/pdf' ? 'documentos' : 'imagem')
    pre = await documentReply(u, doc.data, mime, str(b.text, 500))
    b.text = str(b.text, 500) || (doc.field === 'image' ? '📷 Foto enviada' : `📄 ${doc.filename || 'Documento'}`)
  } else if (b.photos?.batchId) {
    await requireModule('imagens')
    const batch = takeBatch(String(b.photos.batchId), u.id)
    if (!batch.length) fail(400, 'As fotos expiraram. Envie de novo.', 'invalid')
    const outs: string[] = []; etapa('imagem')
    for (const f of batch) { try { outs.push((await documentReply(u, f.data, f.mime, str(b.text, 500))).content) } catch (e: any) { outs.push(`Foto ${f.position}: ${e?.message || 'não foi possível ler'}`) } }
    pre = { content: outs.map((c, i) => (batch.length > 1 ? `Foto ${batch[i].position}: ` : '') + c).join('\n'), cards: [] }
    b.text = str(b.text, 500) || `📷 ${batch.length} fotos enviadas`
  }
  const convId = str(b.conversationId, 64)

  if (b.forwardOf) {
    const src = await one('SELECT m.* FROM messages m WHERE m.id = $1 AND m.user_id = $2', [Number(b.forwardOf), u.id])
    if (!src) fail(404, 'Mensagem não encontrada.', 'not_found')
    await ensureConversation(u, convId, src!.content)
    await insertMsg(u, convId, src!.role, src!.content, J(src!.cards, []))
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
    return { ok: true }
  }

  const text = str(b.text, 8000)
  if (!text) fail(400, 'Escreva uma mensagem.', 'invalid', 'text')

  if (b.resendOf) {
    const orig = await one("SELECT * FROM messages WHERE id = $1 AND user_id = $2 AND role = 'user'", [Number(b.resendOf), u.id])
    if (!orig) fail(404, 'Mensagem não encontrada.', 'not_found')
    const later = await q('SELECT id FROM messages WHERE conversation_id = $1 AND id > $2 AND superseded = $3', [orig!.conversation_id, orig!.id, false])
    const rrU: Uso[] = []; const rr = await applyRules({ user: u, canal: 'chat', texto: text, conversationId: orig!.conversation_id }).catch(() => null); if (rr) rrU.push(...rr.usos)
    const reply = rr?.terminal && rr.reply ? { content: rr.reply, cards: [] as any[] } : await runAssistant(u, await history(orig!.conversation_id, Number(orig!.id)), text, undefined, '', rrU)
    if (rr?.rodape.length) reply.content += '\n\n' + [...new Set(rr.rodape)].join('\n')
    await q('UPDATE messages SET content = $1 WHERE id = $2', [text, orig!.id])
    if (later.length) await q(`UPDATE messages SET superseded = $1 WHERE conversation_id = $2 AND id > $3`, [true, orig!.conversation_id, orig!.id])
    const am = await insertMsg(u, orig!.conversation_id, 'assistant', reply.content, reply.cards)
    await registrarUso(rrU, { canal: 'chat', userId: u.id, conversationId: orig!.conversation_id, messageId: Number(am.id) })
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), orig!.conversation_id])
    const conv = await one('SELECT * FROM conversations WHERE id = $1', [orig!.conversation_id])
    return { resent: true, superseded: later.map((r) => Number(r.id)), userMessage: msgOut({ ...orig, content: text }), assistantMessage: msgOut(am), conversation: convOut(conv), usageAlert: null }
  }

  let conv = await ensureConversation(u, convId, text)
  if (conv && conv.title === 'Nova conversa' && text) { // conversa criada por um cartão de link: o título vem da primeira pergunta real
    const t = text.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'; await q('UPDATE conversations SET title = $1 WHERE id = $2', [t, convId]); conv = { ...conv, title: t }
  }
  const replyToId = b.replyToId ? Number(b.replyToId) : null
  const hist = await history(convId)
  const COG = await import('../ai/cognition.js'), anCog = COG.analisar(text, hist) // leitura da mensagem (intenção, lacunas…): serve também à avaliação da resposta
  // resposta a uma sugestão proativa (sim/não) vale em qualquer caminho de resposta (IA, cérebro, motores internos)
  if (anCog.tipo === 'confirmacao' || anCog.tipo === 'negacao') void (await import('../ai/proativo.js')).registrarResposta(u.id, convId, anCog).catch(() => {})
  // Fase 6: reclamação em texto sobre a resposta anterior vira sinal de aprendizado (só o rótulo; o texto não é guardado)
  if (anCog.tipo !== 'correcao') { const APR = await import('../ai/aprendizado.js'); if (APR.ehReclamacao(text)) void APR.marcarReclamacao(convId, u.id).catch(() => {}) }
  if (anCog.tipo === 'correcao') { void COG.marcarCorrecao(convId, u.id).catch(() => {}); void (await import('../ai/memoria-evolutiva.js')).registrarExperiencia(u, { kind: 'correcao', outcome: 'corrigido', summary: `Correção do usuário: "${text.slice(0, 140)}"`, conversationId: convId, base: hist.filter((m: any) => m.role === 'user').slice(-1).map((m: any) => String(m.content || '')).join(' ') }).catch(() => {}) } // sinal de aprendizado individual
  T.mark('conversa_e_historico')
  let limitMsg: string | null = null
  try { await useQuota(u, 'chat') } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e }
  // IDIOMA: idioma da resposta deste turno (preferência salva → pedido pontual → idioma da mensagem → da conversa → português).
  // Pedido permanente ("sempre me responda em inglês") é salvo na memória do usuário; o idioma de uma mensagem isolada não.
  const IDI = await import('../ai/idioma.js'), GUIA = await import('../ai/guia.js')
  const idi: import('../ai/idioma.js').IdiomaTurno = await IDI.idiomaDoTurno(u.id, text, hist as any).catch((e) => { console.error('[idioma]', e?.message); return { lang: 'pt' as const, origem: 'padrao' as const, preferencia: null, detectado: null, pedido: null } })
  await IDI.marcarTurno(idi)
  // tipo do pedido: execução × explicação × pergunta geral × conversa (orienta o caminho e a IA)
  const tipoPedido = GUIA.classificar(text), soExplicar = tipoPedido === 'explicacao'
  let jaNoIdioma = false, prefixoIdioma = '', viaIdioma = false, viaGuia = false
  if (!pre && !limitMsg && idi.pedido && (idi.pedido.acao === 'definir' || idi.pedido.acao === 'apagar')) {
    const conf = idi.pedido.acao === 'definir' && idi.pedido.lang ? (await IDI.salvarPreferencia(u.id, idi.pedido.lang, convId), IDI.CONFIRMA[idi.pedido.lang]) : (await IDI.apagarPreferencia(u.id), IDI.APAGADA[idi.lang])
    if (idi.pedido.resto && idi.pedido.resto.split(/\s+/).length >= 3) prefixoIdioma = conf // a mensagem também tem uma pergunta: responde a ela (já no novo idioma)
    else { pre = { content: conf, cards: [] }; jaNoIdioma = true; viaIdioma = true }
  }
  // MODO EXPLICATIVO: "sim/não" à oferta feita na explicação anterior; "como faço…?" sobre um recurso real → passos (nada é executado)
  if (!pre && !limitMsg) { const so = await GUIA.seguirOferta(u, convId, text, hist, b).catch((e) => { console.error('[guia]', e?.message); return null }); if (so) { pre = { content: so.content, cards: [] }; viaGuia = true } }
  if (!pre && !limitMsg && soExplicar) { const g = await GUIA.explicar(u, convId, text).catch((e) => { console.error('[guia]', e?.message); return null }); if (g) { pre = { content: g.content, cards: [] }; viaGuia = true } }
  // Modos Inteligentes (botão ⚡ do campo de digitação): conversa com modo ativo é atendida pelo modo, com o acesso conferido aqui
  let viaModo = false, rastroModo: any = null, metaModo: any = null
  if (!pre && !limitMsg) { const md = await (await import('../modos/index.js')).processar(u, convId, text, hist, b).catch((e) => { console.error('[modos]', e?.message); return null }); if (md) { pre = { content: md.content, cards: [] }; viaModo = true; rastroModo = (md as any).rastro || null; metaModo = (md as any).meta || null } }
  // regras executáveis do Cérebro (cadastradas no painel): cumpridas pelo sistema antes de qualquer motor ou IA
  const usos: Uso[] = []; let viaRegra = false, rodape: string[] = []
  const finOn = (await modules()).financas !== false // módulo Finanças desligado no painel: o chat não lança nem resume finanças
  if (!pre && !limitMsg) {
    const rr = await applyRules({ user: u, canal: 'chat', texto: text, conversationId: convId }).catch((e) => { console.error('[regras]', e?.message); return null })
    if (rr) { usos.push(...rr.usos); rodape = rr.rodape; if (rr.terminal && rr.reply) { pre = { content: rr.reply, cards: [] }; viaRegra = true } }
  }
  // Motor de Aprendizagem Adaptativa: correções/preferências viram aprendizado individual (silencioso); só responde quando a mensagem é só a correção
  if (!pre && !limitMsg) { const ob = await (await import('../ai/adaptive.js')).observar(u, convId, text, hist).catch((e) => { console.error('[aprendizagem]', e?.message); return null }); if (ob?.reply) pre = { content: ob.reply, cards: [] } }
  // Fase 8: objetivos em linguagem natural (planejar → aprovar → executar → verificar), aprovações, andamento e desfazer
  if (!pre && !limitMsg && !soExplicar) { const { localDate } = await import('../lib/time.js'); const ex = await (await import('../ai/execucao-planos.js')).responderChat(u, convId, text, hist as any, localDate(settingsOf(u).timezone)).catch((e) => { console.error('[execução]', e?.message); return e?.status && e?.message ? { content: e.message, cards: [] } : null }); if (ex) pre = ex }
  // motor matemático interno: uma conta nunca vira lançamento, compromisso ou pergunta para IA
  const conta: any = (await import('../lib/math.js')).solveMath(text)
  // memória da conversa: continua agendamentos em partes, entende referências e retomadas (sem IA)
  const cx: any = !conta && !pre && !limitMsg ? await (await import('../ai/convctx.js')).contextReply(u, convId, text, hist).catch((e) => { console.error('[contexto]', e?.message); return null }) : null
  // resposta ao "Criar lembrete" (botão rápido): a mensagem seguinte é o lembrete, antes de finanças e agenda
  const UMx = await import('../lib/usermod.js')
  let guiaPr: any = null
  if (!pre && !limitMsg && !conta && !cx && !soExplicar && !parseReminder(text, settingsOf(u).timezone)) { const g = await UMx.getUM<any>(u.id, 'lembrete_guia', null); if (g && Date.now() - g.at < 10 * 60_000) guiaPr = parseReminder('me lembra de ' + text.trim().replace(/^(de |que )/i, ''), settingsOf(u).timezone) }
  let fin: any = null
  if (pre) fin = pre
  else if (!limitMsg && !conta && !cx && !guiaPr && finOn && !soExplicar) { try { fin = await (await import('../ai/finchat.js')).appointmentWithDeposit(u, text) ?? await financeReply(u, text, convId) } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } }
  { const fid = Number((String(fin?.content || '').match(/⟦fin:(\d+)⟧/) || [])[1]); if (fid) await (await import('../ai/convctx.js')).lembrarAcao(convId, u.id, 'expense', fid, String(fin.content).replace(/⟦[^⟧]*⟧/g, '').slice(0, 120)).catch(() => {}) }
  let appt: any = null
  let modCard: any = null
  if (conta) modCard = { content: conta.erro || `${conta.expr} = **${conta.texto}**`, cards: [] }
  if (cx) modCard = cx
  if (!limitMsg && !fin && !conta && !cx && !guiaPr && isAgendaQuery(text)) appt = await agendaReply(u, text)
  if (!limitMsg && !fin && !appt && !pre && !conta && !cx) { const idr = await identityReply(text).catch(() => null); if (idr) modCard = { content: idr, cards: [] } }
  if (!limitMsg && !fin && !appt && !pre && !modCard) { const fu = await (await import('../lib/followup.js')).followupChat(u, text).catch(() => null); if (fu) modCard = fu }
  if (!limitMsg && !fin && !appt && !pre && !modCard && /^(n[aã]o[,.!]?\s+(o certo|na verdade|[eé] |era |s[aã]o )|na verdade[,: ]|corrigindo[,: ]|corre[cç][aã]o[,: ]|errado[,.!]\s)/i.test(text.trim())) {
    const prevQ = [...hist].reverse().filter((m: any) => m.role === 'user')[0]?.content || ''
    const r = prevQ ? await proposeCorrection(String(prevQ), text, u.id).catch(() => null) : null
    if (r && (r as any).ok) modCard = { content: 'Obrigado pela correção! Guardei essa informação no Cérebro para revisão, assim eu aprendo e não repito o erro.', cards: [] }
  }
  if (!limitMsg && !fin && !appt && !pre && !modCard && finOn) { const fr = await financeSummary(u, text).catch(() => null); if (fr) modCard = fr }
  // "Criar lembrete" sem detalhes (botão rápido): pergunta o quê e quando; a próxima mensagem vira o lembrete
  if (!limitMsg && !fin && !appt && !pre && !modCard && /^(quero |eu quero |vamos |pode )?(criar|crie|cria|novo|nova|adicionar|adiciona|fazer|faz|definir|colocar|programar|marcar)( um| uma| o)?( novo)? lembrete[.!]?$/i.test(text.trim())) {
    await UMx.setUM(u.id, 'lembrete_guia', { at: Date.now() })
    modCard = { content: 'Do que você quer ser lembrado e quando? Escreva, por exemplo: “pagar a internet amanhã às 9h” ou “tomar remédio daqui a 2 horas”.', cards: [] }
  }
  if (!limitMsg && !fin && !appt && !pre && !modCard) { const m = moduleIntent(text); if (m) modCard = { content: `${m.label} — ${m.desc} ⟦mod:${m.key}⟧`, cards: [] } }
  if (!limitMsg && !fin && !appt && !conta && !cx && !guiaPr && !soExplicar) { const pa = parseAppointment(text, settingsOf(u).timezone); if (pa) { try { const gd: any = await (await import('../ai/adaptive.js')).guardarAgendamento(u, convId, pa as any).catch(() => ({})); if (gd.reply) { appt = { content: gd.reply, cards: [] } } else { await useQuota(u, 'appointment'); const s = settingsOf(u); const rows = await db().tx((t: any) => createItem(u, 'appointment', { ...pa, location: '', reminder_minutes: undefined }, t)); const it: any = serialize(rows[0]); await (await import('../ai/convctx.js')).lembrarAcao(convId, u.id, 'appointment', Number(it.id), `"${it.title}" ${it.date} ${it.time}`, it.title).catch(() => {}); appt = { content: `${gd.prefixo || ''}Pronto! Agendei "${it.title}"${it.clienteNome ? ` para ${it.clienteNome}` : ''} ${humanDate(it.date, localDate(s.timezone)).toLowerCase()} às ${it.time}. ${avisoTxt(it)} ⟦appt:${it.id}⟧`, cards: [] } } } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } } }
  // lembrete simples pela frase: cria na hora, sem IA, avisando exatamente no horário pedido
  if (!limitMsg && !fin && !appt && !modCard && !soExplicar) {
    const pr = parseReminder(text, settingsOf(u).timezone) || guiaPr
    if (guiaPr && pr === guiaPr) await UMx.setUM(u.id, 'lembrete_guia', null)
    if (pr) {
      try {
        await useQuota(u, 'reminder')
        const tz = settingsOf(u).timezone, agora = new Date(new Date().toLocaleString('en-US', { timeZone: tz }))
        let when = new Date(agora)
        if (pr.minutesFromNow != null) when = new Date(agora.getTime() + pr.minutesFromNow * 60000)
        else { const [h, m] = String(pr.time).split(':').map(Number); when.setHours(h, m, 0, 0); if (pr.dayOffset) when.setDate(when.getDate() + pr.dayOffset); else if (when.getTime() <= agora.getTime() - 30000) when.setDate(when.getDate() + 1) } // "amanhã"/"depois de amanhã": o dia pedido; sem dia: hoje, ou amanhã se o horário já passou
        const pad = (n: number) => String(n).padStart(2, '0'), date = `${when.getFullYear()}-${pad(when.getMonth() + 1)}-${pad(when.getDate())}`, time = `${pad(when.getHours())}:${pad(when.getMinutes())}`
        const { itemAction } = await import('./items.js'), { db } = await import('../db/index.js')
        await db().tx((t: any) => itemAction(u, 'create', 'reminder', 0, { message: pr.message, date, time }, t))
        const hoje = `${agora.getFullYear()}-${pad(agora.getMonth() + 1)}-${pad(agora.getDate())}`
        const amanha = (() => { const d = new Date(agora); d.setDate(d.getDate() + 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` })()
        const quando = date === hoje ? 'hoje' : date === amanha ? 'amanhã' : `em ${date.split('-').reverse().join('/')}`
        const oQue = pr.message === 'Lembrete' ? '' : ` de ${pr.message.charAt(0).toLowerCase() + pr.message.slice(1)}`
        modCard = { content: `Pronto! Vou te lembrar${oQue} ${quando} às ${time}.`, cards: [] }
      } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧' }
    }
  }
  T.mark('motores_internos')
  const quick = limitMsg || appt || fin || modCard ? null : await quickReply(u, text).catch(() => null) // mercado, impostos: dados reais, sem gastar IA
  T.mark('atalhos')
  let learned: { answer: string; id: number } | null = null
  const usosAntesDaMemoria = usos.length
  if (!limitMsg && !fin && !appt && !quick && !modCard) {
    learned = await findLearnedAnswer(u, text).catch(() => null)
    if (learned) usos.push({ itemId: learned.id, version: (learned as any).version || 1, role: 'consulta', action: 'respondeu', effect: 'Reutilizou uma resposta aprovada do Cérebro (sem IA)' })
    // conhecimento próprio (cadastrado ou aprendido) responde antes de qualquer IA
    if (!learned) { const bc = await getConfig<any>('brain', {}); if (bc.cerebroPrimeiro !== false) { const K = await import('../ai/knowledge.js'); if (!K.ehConsultaDePedidoReal(text)) { const k = await K.answerKnowledge(text, u.id, bc.modoIA === 'sem_ia' ? 0.5 : 0.6).catch((e) => { console.error('[cérebro] busca falhou:', e?.message); return null }); if (k) { learned = { answer: k.resposta, id: k.ids[0] }; usos.push(...K.usoDeConsulta(k, 'chat')) } } } }
  }
  // memória do Cérebro: resposta guardada que não cita o nome perguntado é de outro assunto (ex.: "capital da França"
  // para "capital da Austrália") — não responde; a pergunta segue para a consulta e a pesquisa
  if (learned && !(await import('../ai/cerebro/relevancia.js')).citaNomes(text, learned.answer)) { learned = null; usos.splice(usosAntesDaMemoria) }
  T.mark('conhecimento')
  const fromAi = !limitMsg && !fin && !appt && !quick && !learned && !modCard
  // CÉREBRO CENTRAL: consulta obrigatória antes da IA (biblioteca → suficiência → pesquisa e aprendizado, se a pergunta for geral)
  const INT = await import('../ai/cerebro/integracao.js')
  if (fromAi) etapa('cerebro')
  const rastro = fromAi ? await INT.recuperar(text, { canal: 'chat', userId: u.id, pesquisar: true }).catch((e) => { console.error('[cérebro central] consulta:', e?.message); return INT.rastroDireto(text, 'chat', u.id, 'falha_consulta') }) : null
  if (fromAi) T.mark('cerebro_central')
  let cerebroSemIA = false, falhaIA = ''
  void (async () => { try { const st = await getConfig<any>('brain_stats', { semIA: 0, comIA: 0 }); st[fromAi ? 'comIA' : 'semIA'] = (Number(st[fromAi ? 'comIA' : 'semIA']) || 0) + 1; await setConfig('brain_stats', st) } catch { /* estatística opcional */ } })()
  const reply = limitMsg ? { content: limitMsg, cards: [] as any[] }
    : fin ? fin
    : appt ? appt
    : modCard ? modCard
    : quick ? { content: quick, cards: [] as any[] }
    : learned ? { content: learned.answer, cards: [] as any[] }
    : await runAssistant(u, hist, text, live, await (await import('../ai/convctx.js')).ctxParaIA(convId, u).catch(() => ''), usos, undefined, convId, rastro, { idioma: idi, tipo: tipoPedido }).catch(async (e) => { await refundQuota(u, 'chat').catch(() => {}); falhaIA = String(e?.message || e).slice(0, 200)
      // provedores de IA indisponíveis: o Cérebro Central continua respondendo com o que já sabe (trecho + fonte)
      const semIA = INT.respostaSemIA(rastro); if (semIA) { cerebroSemIA = true; return { content: semIA, cards: [] as any[] } }
      if (e?.code === 'chat_deadline') { const K = await import('../ai/knowledge.js'); const k = await K.answerKnowledge(text, u.id, 0.4).catch(() => null); if (k) usos.push(...K.usoDeConsulta(k, 'chat')); return { content: k ? k.resposta : 'Desculpe, a resposta está demorando mais que o normal e eu parei para não te deixar esperando. Tente de novo em instantes ou reformule a pergunta.', cards: [] as any[] } } if ((await getConfig<any>('brain', {})).modoIA === 'sem_ia') return { content: 'Ainda não aprendi a responder isso sozinho. Estou no modo sem IAs externas: posso registrar gastos, compromissos, tarefas e lembretes, consultar sua agenda e finanças, abrir módulos e responder o que já está no meu Cérebro.', cards: [] as any[] }; throw e })
  T.mark(fromAi ? 'ia' : 'montar_resposta')
  etapa('preparando')
  { const tp = (reply as any)?.cog?.tempos; if (tp) for (const [k, v] of Object.entries(tp)) T.etapas['ia.' + k] = Math.round(Number(v)) } // subetapas da IA: preparo, modelo, ferramentas, conclusão
  // aprende a resposta da IA (perguntas gerais, sem efeitos colaterais); entra como PENDENTE e sem o texto fixo das regras
  if (fromAi && !cerebroSemIA && reply?.content) { const sx = INT.sintetizar(reply.content, rastro); if (sx.ajustou && rastro) { reply.content = sx.texto; rastro.sintetizado = true } } // síntese inteligente (proteção contra despejo)
  // FONTES: o corpo da resposta fica sem URLs, domínios, "Fonte:" ou "Segundo <site>"; as fontes que SUSTENTAM a resposta
  // (conhecimento realmente usado ou a pesquisa da IA) vão num marcador que o app mostra como ícones junto do horário
  if ((fromAi || learned) && reply?.content) {
    const REL = await import('../ai/cerebro/relevancia.js')
    const lf = REL.limparFontes(reply.content, rastro ? rastro.itens.flatMap((x) => x.fontes) : [])
    const texto = lf.texto || reply.content.replace(/⟦src[^⟧]*⟧/g, '').trim()
    const fontes = [...lf.fontes, ...INT.fontesDaResposta(texto, rastro, cerebroSemIA ? 'cerebro_sem_ia' : 'ia')]
    const mk = REL.marcador(fontes)
    if (lf.removeu || mk) reply.content = texto + (mk ? ' ' + mk : '')
  }
  if (fromAi && !cerebroSemIA && reply?.content && !reply.cards?.length && idi.lang === 'pt' && tipoPedido !== 'explicacao') { // o Cérebro aprende em português; explicações saem do catálogo vivo
    saveLearnedAnswer(u, text, reply.content).catch(() => {})
  }
  if (!limitMsg && reply?.content) void (await import('../ai/adaptive.js')).observarUso(u, convId, reply.content).catch(() => {}) // padrões de uso (preferências inferidas)
  if (rodape.length && !limitMsg && reply?.content) reply.content += '\n\n' + [...new Set(rodape)].join('\n') // regra executável "anexar"
  // cartões de compromisso, gasto e receita viram cartões premium (dados lidos do módulo real pelo id)
  if (Array.isArray(reply.cards)) { const keep: any[] = []; for (const c of reply.cards) { if (c && c.id && c.kind === 'appointment') { if (!/⟦appt:/.test(reply.content)) reply.content += ` ⟦appt:${c.id}⟧` } else if (c && c.id && (c.kind === 'expense' || c.kind === 'income')) { reply.content += ` ⟦fin:${c.id}⟧` } else keep.push(c) } reply.cards = keep }
  if (idi.lang !== 'pt' && !jaNoIdioma && !(fromAi && !cerebroSemIA) && reply?.content) { const tr = await IDI.traduzir(reply.content, idi.lang).catch(() => null); if (tr) reply.content = tr } // motores internos escrevem em português
  if (prefixoIdioma && reply?.content) reply.content = prefixoIdioma + '\n\n' + reply.content
  if (!limitMsg && !viaModo && !viaGuia && !viaIdioma && !/⟦(emp|loc|mkt)/.test(reply.content)) { const ad = await maybeAd(u).catch(() => null); if (ad) reply.content += ` ⟦ad:${ad}⟧` } // gera antes de gravar: se a IA falhar, nada fica pela metade
  const via = limitMsg ? 'limite' : viaIdioma ? 'idioma' : viaGuia ? 'guia' : viaModo ? 'modo' : viaRegra ? 'regra' : conta ? 'calculo' : cx ? 'memoria_conversa' : fin ? 'financeiro' : appt ? 'agenda' : modCard ? 'motor_interno' : quick ? 'atalho' : learned ? 'cerebro' : cerebroSemIA ? 'cerebro_sem_ia' : 'ia'
  const um = await insertMsg(u, convId, 'user', text, [], replyToId)
  const am = await insertMsg(u, convId, 'assistant', reply.content, reply.cards)
  if (!limitMsg) { const cg = (reply as any).cog; await COG.avaliarERegistrar(u, convId, Number(am.id), { idioma: idi.lang, texto: text, resposta: reply.content, analise: cg?.analise || anCog, exec: cg?.exec, hist, ferramentas: cg?.ferramentas ?? 0, caminho: via, flagsPrev: cg?.flags, ajustes: cg?.ajustes, especialistas: cg?.n2?.especialistas, n2: cg?.n2 }).catch((e) => console.error('[cognição] avaliação:', e?.message)) } // só notas e rótulos; o texto da conversa não é guardado
  await registrarUso(usos, { canal: 'chat', userId: u.id, conversationId: convId, messageId: Number(am.id) }) // quando e em qual resposta o conhecimento/regra foi usado
  if (!limitMsg) await INT.finalizar(rastro || rastroModo || INT.rastroDireto(text, 'chat', u.id, learned ? 'resposta_da_memoria' : 'acao_interna'), { resposta: reply.content, via, messageId: Number(am.id), conversationId: convId, falhas: falhaIA ? ['IA indisponível: ' + falhaIA] : [], memoria: learned ? [{ id: learned.id }] : metaModo?.conhecimento?.length ? metaModo.conhecimento.map((id: number) => ({ id })) : undefined, detalhe: (() => { const cg = (reply as any)?.cog, ex = cg?.exec; return { etapas: { ...T.etapas }, totalMs: Object.entries(T.etapas).filter(([k]) => !k.startsWith('ia.')).reduce((a, [, v]) => a + Number(v || 0), 0), tipo: tipoPedido, idioma: idi.lang, ferramentas: (cg?.n2?.ferramentas || []).slice(0, 12), acoes: ex ? { feitas: ex.escritas || [], verificacao: cg?.n2?.verificacao ?? null, pendentes: ex.pendentes || [], falhas: (ex.falhas || []).slice(0, 5), leituras: (ex.leituras || []).length } : null, especialistas: cg?.n2?.especialistas || [], sinais: (cg?.flags || []).slice(0, 10), multiagente: !!cg?.n2?.multiagente, consultas: CONS.n, ...(metaModo ? { modo: metaModo } : {}) } })() }).catch(() => null) // rastreamento real (painel do Cérebro Central)
  await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
  const byId = new Map<number, any>()
  if (replyToId) { const rt = await one('SELECT * FROM messages WHERE id = $1 AND user_id = $2', [replyToId, u.id]); if (rt) byId.set(replyToId, rt) }
  T.mark('gravacao_e_entrega')
  T.finish(via, fromAi, text.length, CONS.n)
  if (CONS.sql) { const c = new Map<string, number>(); for (const x of CONS.sql) c.set(x, (c.get(x) || 0) + 1); console.log(`[consultas] ${CONS.n} via ${via}: ` + [...c].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${v}× ${k}`).join(' || ')) } // diagnóstico (DIAG_CONSULTAS=1)
  return { conversation: convOut({ ...conv, updated_at: nowIso() }), userMessage: msgOut(um, byId), assistantMessage: msgOut(am), usageAlert: null, ad: null }
}

/** Impede resposta duplicada: o mesmo pedido enquanto o primeiro ainda é processado (toque duplo, nova tentativa do
 *  aplicativo após demora) recebe a resposta do primeiro em vez de gerar outra mensagem e outros lançamentos. */
const inflight = new Map<string, { at: number; p: Promise<any> }>()
/* ---------- processamento persistente: cada envio vira um "pedido" com id; a geração continua no servidor
   mesmo se o app sair, minimizar ou perder a internet, e a resposta pode ser buscada depois pelo id ---------- */
interface Live { text: string; done: boolean; subs: Set<(ev: string, data: any) => void>; etapa?: { e: string; t: string } }
const lives = new Map<string, Live>()
const liveOf = (id: string) => { let l = lives.get(id); if (!l) { l = { text: '', done: false, subs: new Set() }; lives.set(id, l) } return l }
const emit = (id: string, ev: string, data: any) => { const l = lives.get(id); if (l) for (const f of l.subs) { try { f(ev, data) } catch { /* conexão fechada */ } } }
const jobRunning = new Map<string, Promise<any>>()
const cleanJobId = (v: any) => { const s = String(v || '').trim(); return /^[A-Za-z0-9_-]{8,80}$/.test(s) ? s : '' }

/* ---------- Ditado (microfone do chat): áudio → texto no campo de mensagem ----------
   O app grava, envia aqui só para TRANSCREVER e mostra o texto no campo para o usuário revisar/editar; ao tocar em enviar,
   o texto segue para o motor do chat como se tivesse sido digitado (o áudio não vai para o motor). O texto sai no idioma
   falado (sem forçar português) e o motor responde nesse idioma (idioma.ts). Nada é gravado: o áudio é descartado. */
const DITADO_JANELA = 5 * 60000, DITADO_MAX = 40, ditados = new Map<number, number[]>()
// frases que o Whisper costuma "ouvir" em gravações sem fala (legendas de vídeo): tratadas como silêncio
const FANTASMA = /^(legendas? (pela|por) comunidade amara\.org|obrigad[oa] por assistir!?|thanks? (you )?for watching!?|subt[ií]tulos? (realizados? )?por la comunidad de amara\.org|sous-titres? r[ée]alis[ée]s? par la communaut[ée] d'amara\.org|untertitel (im auftrag des zdf|der amara\.org-community)|sottotitoli (creati )?dalla comunit[aà] amara\.org|\[?(m[uú]sica|music|silence|sil[eê]ncio|aplausos|applause)\]?|\.+|…)$/i
export async function transcribePost(ctx: Ctx) {
  const u = requireUser(ctx)
  await requireModule('voz')
  const f = ((ctx as any).files as UpFile[] || []).find((x) => x.field === 'audio')
  if (!f || !f.data?.length) fail(400, 'Nenhum áudio recebido. Toque no microfone e fale de novo.', 'audio_missing')
  const mime = (/^application\/octet-stream/.test(f!.mime) || !f!.mime ? 'audio/webm' : f!.mime).toLowerCase()
  if (!/^(audio\/|video\/(webm|mp4))/.test(mime)) fail(415, 'Formato de áudio não suportado. Grave de novo pelo microfone do chat.', 'unsupported_file')
  if (f!.data.length < 800) fail(422, 'Gravação muito curta. Toque no microfone e fale de novo.', 'audio_empty')
  const agora = Date.now(), lista = (ditados.get(u.id) || []).filter((t) => agora - t < DITADO_JANELA)
  if (lista.length >= DITADO_MAX) fail(429, 'Muitas gravações em pouco tempo. Aguarde um instante ou digite sua mensagem.', 'rate_limited')
  lista.push(agora); ditados.set(u.id, lista)
  let texto = ''
  try { texto = String(await transcribeAudio(f!.data, mime) || '') }
  catch (e: any) { console.error('[ditado] transcrição falhou:', e?.message || e); fail(503, 'Não consegui transcrever o áudio agora. Tente de novo ou digite sua mensagem.', 'transcribe_failed') }
  texto = texto.replace(/\s+/g, ' ').trim().slice(0, 4000)
  if (!texto || FANTASMA.test(texto)) fail(422, 'Não reconheci nenhuma fala. Tente falar mais perto do microfone.', 'audio_empty')
  const { detectar } = await import('../ai/idioma.js')
  return { ok: true, text: texto, idioma: detectar(texto).lang }
}

/** Pedido guardado executado fora de uma requisição (Tentar de novo, lib/tarefas-chat.ts). */
export async function executarChat(ctx: Ctx) { return chatPostInner(ctx) }
export async function chatPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const files: UpFile[] = (ctx as any).files || []
  const jobId0 = cleanJobId(ctx.req.headers['x-chat-job'] || b.jobId)
  if (jobId0) {
    const ex = await one('SELECT * FROM chat_jobs WHERE id = $1', [jobId0])
    if (ex && Number(ex.user_id) !== u.id) fail(409, 'Pedido inválido.', 'invalid')
    if (ex && ex.status === 'done') return JSON.parse(ex.result) // repetição do mesmo envio: devolve a mesma resposta, sem gerar outra
    if (ex && ex.status === 'error') fail(Number(ex.error_status) || 502, ex.error || 'Não consegui responder agora.', ex.error_code || 'ai_error')
    const running = jobRunning.get(jobId0)
    if (running) return running
    if (ex && ['queued', 'pending'].includes(String(ex.status))) fail(409, 'Este pedido já está sendo processado. A resposta aparece na conversa quando ficar pronta.', 'em_andamento')
  }
  const key = [u.id, b.conversationId || '', b.resendOf || '', b.forwardOf || '', b.photos?.batchId || '', hashOf(String(b.text || '')), files.map((f) => f.field + hashOf(f.data)).join(',')].join('|')
  const now = Date.now(), ex = inflight.get(key)
  if (ex && now - ex.at < 120_000) return ex.p
  for (const [k, v] of inflight) if (now - v.at > 120_000) inflight.delete(k)
  // TAREFA PERSISTENTE (lib/tarefas-chat.ts): todo envio vira tarefa ligada ao usuário e à conversa — aguardando → processando
  // → concluída/falhou —, com o pedido guardado para tentar de novo; a fila limita o processamento simultâneo
  const jobId = jobId0 || ('s' + Date.now().toString(36) + randomBytes(6).toString('hex'))
  const TC = await import('../lib/tarefas-chat.js')
  const temTarefa = await TC.registrar(jobId, u.id, b, files.length > 0).then(() => true, (e) => { console.error('[tarefas] registrar:', e?.message); return false })
  // saiu da tela antes da resposta (fechou o app, perdeu a conexão): a tarefa continua e o usuário é avisado ao terminar
  const res0: any = (ctx as any).res
  if (temTarefa && res0?.on) res0.on('close', () => { if (!res0.writableFinished) void TC.marcarSegundoPlano(jobId, u.id, true).catch(() => {}) })
  const lv = jobId0 ? liveOf(jobId0) : null
  const live = lv ? { onDelta: (d: string) => { if (d && !lv.text.trim() && d.trim()) etapa('digitando'); lv.text += d; emit(jobId0, 'delta', d) }, onReset: () => { lv.text = ''; emit(jobId0, 'reset', '') } } : undefined
  // a geração não depende da conexão: se o app sair, ela termina e fica salva
  const p = (async () => {
    // ETAPAS REAIS: cada mudança vai para o canal do envio (SSE "etapa") e fica consultável pela situação/lista de tarefas
    const publicar = (x: { e: string; t: string }) => { if (lv) { lv.etapa = { e: x.e, t: x.t }; emit(jobId0, 'etapa', { e: x.e, t: x.t }) } }
    // fila: só aparece se a espera for real (não pisca "Na fila…" quando a vez é imediata)
    let naFila = true; const tFila = setTimeout(() => { if (naFila) publicar({ e: 'fila', t: 'Na fila…' }) }, 400)
    await TC.entrar(u.id); naFila = false; clearTimeout(tFila)
    let parar: (() => void) | null = null
    try {
      if (temTarefa) parar = await TC.iniciar(jobId)
      const res = await comEtapas(jobId, publicar, () => chatPostInner(ctx, live))
      if (temTarefa) await TC.concluir(jobId, res).catch((e) => console.error('[tarefas] concluir:', e?.message))
      if (lv) { lv.done = true; emit(jobId0, 'done', '') }
      return res
    } catch (e: any) {
      if (temTarefa) await TC.falhar(jobId, e).catch((x) => console.error('[tarefas] falhar:', x?.message))
      if (lv) { lv.done = true; emit(jobId0, 'error', e?.message || '') }
      throw e
    } finally { parar?.(); TC.sair(u.id) }
  })()
  p.catch(() => {})
  inflight.set(key, { at: now, p })
  jobRunning.set(jobId, p)
  const done = () => { if (inflight.get(key)?.p === p) inflight.delete(key); jobRunning.delete(jobId); if (jobId0) setTimeout(() => lives.delete(jobId0), 60_000) }
  p.then(done, done)
  return p
}
/** Situação de um envio: o app usa ao voltar para a tela ou quando a conexão caiu no meio. */
export async function chatJobGet(ctx: Ctx) {
  const u = requireUser(ctx), id = cleanJobId(ctx.params.id)
  const r = id ? await one('SELECT * FROM chat_jobs WHERE id = $1 AND user_id = $2', [id, u.id]) : null
  if (!r) return { status: 'unknown' }
  if (r.status === 'done') return { status: 'done', estado: 'concluida', result: JSON.parse(r.result) }
  if (r.status === 'error') return { status: 'error', error: r.error, code: r.error_code, httpStatus: Number(r.error_status) || 502 }
  const et = etapaAtual(id) || lives.get(id)?.etapa || null
  return { status: 'pending', estado: r.status === 'queued' ? 'aguardando' : 'processando', partial: lives.get(id)?.text || '', etapa: r.status === 'queued' ? { e: 'fila', t: 'Na fila…' } : et ? { e: et.e, t: et.t } : null }
}
/** Texto chegando em tempo real (Server-Sent Events). */
export async function chatJobStream(ctx: Ctx) {
  const u = requireUser(ctx), id = cleanJobId(ctx.params.id)
  if (!id) fail(400, 'Pedido inválido.', 'invalid')
  const res = ctx.res
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' })
  const send = (ev: string, data: any) => res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`)
  const r = await one('SELECT status, user_id FROM chat_jobs WHERE id = $1', [id])
  if (r && Number(r.user_id) !== u.id) { send('error', 'inválido'); res.end(); return { _handled: true } }
  if (r && !['pending', 'queued'].includes(String(r.status))) { send(r.status === 'done' ? 'done' : 'error', ''); res.end(); return { _handled: true } }
  const lv = liveOf(id)
  if (lv.etapa) send('etapa', lv.etapa)
  if (lv.text) send('delta', lv.text)
  if (lv.done) { send('done', ''); res.end(); return { _handled: true } }
  const sub = (ev: string, data: any) => { send(ev, data); if (ev === 'done' || ev === 'error') { lv.subs.delete(sub); res.end() } }
  lv.subs.add(sub)
  const ping = setInterval(() => res.write(': ping\n\n'), 15_000)
  const stop = setTimeout(() => { lv.subs.delete(sub); res.end() }, 180_000)
  ctx.req.on('close', () => { clearInterval(ping); clearTimeout(stop); lv.subs.delete(sub) })
  return { _handled: true }
}

export async function chatGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const id = ctx.query.get('c') || ''
  const conv = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [id, u.id])
  if (!conv) return { conversation: null, messages: [] }
  const rows = await q('SELECT * FROM messages WHERE conversation_id = $1 ORDER BY id', [id])
  const byId = new Map(rows.map((r) => [Number(r.id), r]))
  return { conversation: convOut(conv), messages: rows.map((m) => msgOut(m, byId)) }
}
export async function chatDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE user_id = $1', [u.id])
  return { ok: true }
}

export async function conversationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const term = str(ctx.query.get('q'), 100)
  const rows = term
    ? await q(`SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id = c.id
               WHERE c.user_id = $1 AND (c.title ILIKE $2 OR m.content ILIKE $2) ORDER BY c.updated_at DESC LIMIT 100`, [u.id, `%${term}%`])
    : await q('SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 200', [u.id])
  return { conversations: rows.map(convOut) }
}
export async function conversationPatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const c = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  if (!c) fail(404, 'Conversa não encontrada.', 'not_found')
  const b = ctx.body || {}
  const title = b.title !== undefined ? str(b.title, 120) || c!.title : c!.title
  const pinned = typeof b.pinned === 'boolean' ? b.pinned : B(c!.pinned)
  await q('UPDATE conversations SET title = $1, pinned = $2 WHERE id = $3', [title, pinned, c!.id])
  return { ok: true, conversation: convOut({ ...c, title, pinned }) }
}
export async function conversationDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  return { ok: true }
}

/* ---------- várias fotos: o app envia primeiro para /api/images e depois chama o chat com o lote ---------- */
const batches = new Map<string, { userId: number; at: number; files: { position: number; mime: string; data: Buffer }[] }>()
export function takeBatch(id: string, userId: number) { const b = batches.get(id); batches.delete(id); return b && b.userId === userId && Date.now() - b.at < 15 * 60_000 ? b.files.sort((x, y) => x.position - y.position) : [] }
export async function imagesPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('imagens')
  const id = str(ctx.body?.batchId, 64); if (!id) fail(400, 'Lote inválido.', 'invalid')
  const files: UpFile[] = ((ctx as any).files || []).filter((f: UpFile) => f.field === 'image')
  const pos = String(ctx.body?.position || '').split(',')
  const b = batches.get(id) || { userId: u.id, at: Date.now(), files: [] }
  if (b.userId !== u.id) fail(403, 'Lote inválido.', 'forbidden')
  for (const [i, f] of files.entries()) b.files.push({ position: Number(pos[i] || b.files.length + 1) || b.files.length + 1, mime: f.mime, data: f.data })
  b.files = b.files.slice(0, 10); batches.set(id, b)
  for (const [k, v] of batches) if (Date.now() - v.at > 15 * 60_000) batches.delete(k)
  return { results: files.map((_, i) => ({ ok: true, position: Number(pos[i] || i + 1) })) }
}

/* ---------- Tarefas em segundo plano (estados reais, saiu da tela, tentar de novo) ---------- */
export async function tarefasGet(ctx: Ctx) { const u = requireUser(ctx); const c = String(ctx.query.get('c') || '').slice(0, 64); return { tarefas: await (await import('../lib/tarefas-chat.js')).listar(u.id, c || undefined) } }
export async function tarefaSegundoPlanoPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); const est = await (await import('../lib/tarefas-chat.js')).marcarSegundoPlano(id, u.id, ctx.body?.ativo !== false); if (!est) fail(404, 'Tarefa não encontrada.', 'not_found'); return { ok: true, estado: est } }
export async function tarefaTentarPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); return { tarefa: await (await import('../lib/tarefas-chat.js')).tentarDeNovo(id, u.id) } }
export async function tarefaDescartarPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); await (await import('../lib/tarefas-chat.js')).descartar(id, u.id); return { ok: true } }
