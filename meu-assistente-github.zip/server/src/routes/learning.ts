// Aprendizados do usuário (Motor de Aprendizagem Adaptativa): cada pessoa revisa, corrige, pausa e exclui os SEUS aprendizados.
// O administrador só vê números agregados e sugestões anônimas; promover uma sugestão cria apenas um RASCUNHO no Laboratório de IA.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import * as A from '../ai/adaptive.js'

export async function learningGet(ctx: Ctx) {
  const u = requireUser(ctx)
  return { ativo: u.memory_settings?.learning !== false, memoriaLigada: u.memory_settings?.enabled !== false, global: await A.globalOn(), itens: await A.listar(u.id) }
}
export async function learningPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  switch (b.action) {
    case 'update': {
      const r = await A.atualizar(u.id, Number(b.id), { regra: b.regra !== undefined ? str(b.regra, 200) : undefined, estado: b.estado })
      if (!r) fail(400, 'Não foi possível alterar este item (texto vazio, não permitido ou não encontrado).', 'invalid')
      await audit(u.id, 'aprendizado.update', r!.id, {}); return { ok: true, item: r }
    }
    case 'delete': await A.excluir(u.id, Number(b.id)); await audit(u.id, 'aprendizado.delete', Number(b.id), {}); return { ok: true }
    case 'delete_all': await A.excluirTodos(u.id); await audit(u.id, 'aprendizado.delete_all', null, {}); return { ok: true }
    case 'settings': {
      const next = { ...u.memory_settings, learning: b.ativo !== false }
      await q('UPDATE users SET memory_settings = $1 WHERE id = $2', [JSON.stringify(next), u.id]); return { ok: true, ativo: next.learning }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}

const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelLearningGet(ctx: Ctx) { admin(ctx); return A.resumoAdmin() }
export async function panelLearningPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}
  if (b.action === 'promover') {
    const id = await A.promoverParaLaboratorio(u.id, String(b.operacao || ''), String(b.kind || ''))
    if (!id) fail(404, 'Sugestão não encontrada.', 'not_found')
    await audit(u.id, 'aprendizado.promover_laboratorio', Number(id), { operacao: b.operacao, kind: b.kind }); return { ok: true, propostaId: id }
  }
  const ativo = b.ativo !== false; await setConfig('adaptive', { ...(await getConfig<any>('adaptive', {})), ativo }); await audit(u.id, 'aprendizagem.chave', null, { ativo }); return { ok: true, ativo }
}
