// Compartilhamento de produtos e serviços: link e mensagem do item (público), registro de compartilhamentos e visitas,
// configuração do administrador (Painel → Compartilhamento) e da empresa (Sua empresa → Ajustes → Compartilhamento).
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { pub } from '../lib/publicurl.js'
import { audit } from '../lib/account.js'
import * as SH from '../lib/compartilhar.js'
import * as CAT from '../lib/catalogo.js'
import { requirePanel } from './panel.js'

const viewerOf = (ctx: Ctx) => (ctx.user ? 'u' + ctx.user.id : 'ip' + String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon').split(',')[0].trim())
const fora = () => fail(404, 'Este item não está mais disponível para compartilhar.', 'indisponivel')
/** Item público (empresa no ar, com página; item ativo da modalidade atual) → produto enriquecido + dados da empresa. */
async function itemDe(pid: number) {
  const r = await one('SELECT business_id FROM products WHERE id = $1', [pid]); if (!r) fora()
  const { itemPublico } = await import('./businesses.js')
  const it = await itemPublico(Number(r!.business_id), pid); if (!it || !it.p) fora()
  return it!
}
export const linkDo = (bid: number, p: any, vid?: number | null) => `${pub()}/x/empresa/${bid}?${p.tipo === 'servico' ? 'servico' : 'produto'}=${p.id}${vid ? `&v=${vid}` : ''}&ref=share`

/** GET /api/v2/compartilhar/item/:pid?vid= — link individual e mensagem pronta com os dados de agora. Sem conta. */
export async function itemGet(ctx: Ctx) {
  const pid = Number(ctx.params.pid), it = await itemDe(pid), x = it.x, bid = Number(it.b.id)
  if (!(await SH.ativoPara(x))) fail(403, 'O compartilhamento deste item está desligado.', 'desligado')
  const vid = Number(ctx.query.get('vid')) || null, d0 = SH.dadosDoItem(it.p, vid), url = linkDo(bid, it.p, d0.vid)
  const m = await SH.mensagemDo(it.p, x, url, vid)
  // texto sem o link (o compartilhamento nativo manda o link à parte): tira o link e os dois-pontos que o antecediam
  const semLink = m.mensagem.split('\n').map((l) => (l.includes(url) ? l.split(url).join('').replace(/[\s:]+$/, '') : l)).join('\n').replace(/\n{3,}/g, '\n\n').trim()
  return { url, mensagem: m.mensagem, texto: semLink, titulo: `${m.dados.nome} · ${x.empresa || ''}`, item: { id: pid, tipo: it.p.tipo === 'servico' ? 'servico' : 'produto', nome: m.dados.nome }, empresa: { id: bid, nome: x.empresa || '' }, modelo: m.modelo, origem: m.origem }
}
/** POST /api/v2/compartilhar/item/:pid/registro — { canal } (compartilhamento) ou { visita: true } (chegou por um link compartilhado). */
export async function registroPost(ctx: Ctx) {
  const pid = Number(ctx.params.pid), it = await itemDe(pid), visita = ctx.body?.visita === true
  const canal = visita ? '' : String(ctx.body?.canal || '')
  if (!visita && !(SH.CANAIS as readonly string[]).includes(canal)) fail(400, 'Canal inválido.', 'invalid')
  const { rateLimit } = await import('../lib/security.js'); if (!rateLimit('share:' + viewerOf(ctx), 60, 60_000)) fail(429, 'Muitas ações seguidas. Aguarde um instante.', 'rate_limited')
  const ok = await SH.registrar({ businessId: Number(it.b.id), productId: pid, tipoItem: it.p.tipo === 'servico' ? 'servico' : 'produto', kind: visita ? 'visita' : 'compartilhamento', canal, viewer: viewerOf(ctx) })
  return { ok: true, registrado: ok }
}

/* ---------- exemplos para a pré-visualização (itens reais quando existem; senão, fictícios) ---------- */
async function exemplos(bid?: number) {
  const base = { produto: { produto: 'Camiseta Básica', empresa: 'Loja Exemplo', preco: 'R$ 59,90', preco_normal: '', desconto: '', categoria: 'Roupas', link: pub() + '/x/empresa/1?produto=1' },
    servico: { produto: 'Corte de cabelo', empresa: 'Studio Exemplo', preco: 'R$ 45,00', preco_normal: '', desconto: '', categoria: 'Cabelo', link: pub() + '/x/empresa/2?servico=2' },
    oferta: { produto: 'Tênis Corrida', empresa: 'Loja Exemplo', preco: 'R$ 199,90', preco_normal: 'R$ 249,90', desconto: '20%', categoria: 'Calçados', link: pub() + '/x/empresa/1?produto=3' } }
  if (!bid) return base
  const b = await one('SELECT id, data FROM businesses WHERE id = $1', [bid]); const x = J<any>(b?.data, {})
  const rows = await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 30', [bid, true]) as any[]
  const ps = await CAT.enriquecer(rows.map((r) => ({ id: Number(r.id), ...J<any>(r.data, {}) })))
  for (const p of ps) {
    const d = SH.dadosDoItem(p), k = d.oferta ? 'oferta' : d.serv ? 'servico' : 'produto'
    ;(base as any)[k] = { produto: d.nome, empresa: x.empresa || '', preco: d.preco, preco_normal: d.precoNormal, desconto: d.desconto, categoria: p.categoria || '', link: linkDo(bid, p) }
  }
  for (const k of ['produto', 'servico', 'oferta']) (base as any)[k].empresa = x.empresa || (base as any)[k].empresa
  return base
}

/* ---------- Painel do administrador ---------- */
export async function panelGet(ctx: Ctx) {
  await requirePanel(ctx)
  const dias = Math.min(365, Math.max(1, Number(ctx.query.get('dias')) || 30))
  return { config: await SH.configPlataforma(), padrao: SH.PADRAO, variaveis: SH.VARIAVEIS, limite: SH.LIMITE, maxRegras: SH.MAX_REGRAS, exemplos: await exemplos(), estatisticas: await SH.estatisticas(null, dias) }
}
export async function panelPut(ctx: Ctx) {
  const u = await requirePanel(ctx, true) as any, b = ctx.body || {}
  let cfg: any
  if (b.restaurar === true) cfg = { ativo: (await SH.configPlataforma()).ativo, produto: SH.PADRAO.produto, servico: SH.PADRAO.servico, oferta: SH.PADRAO.oferta, categorias: [] }
  else {
    try {
      const regras = (Array.isArray(b.categorias) ? b.categorias : []).filter((r: any) => String(r?.categoria || '').trim() || String(r?.texto || '').trim())
      if (regras.length > SH.MAX_REGRAS) fail(400, `Até ${SH.MAX_REGRAS} regras por categoria.`, 'invalid')
      cfg = { ativo: b.ativo !== false, produto: SH.validarTexto(b.produto, 'Mensagem de produtos'), servico: SH.validarTexto(b.servico, 'Mensagem de serviços'), oferta: SH.validarTexto(b.oferta, 'Mensagem de ofertas'),
        categorias: regras.map((r: any, i: number) => { const c = String(r.categoria || '').trim().slice(0, 60); if (!c) fail(400, `Regra ${i + 1}: informe a categoria.`, 'invalid'); return { categoria: c, texto: SH.validarTexto(r.texto, `Regra "${c}"`) } }) }
    } catch (e: any) { if (e?.status) throw e; fail(400, e.message, 'invalid', e.campo) }
  }
  await setConfig('compartilhar', cfg); await audit(u?.id ?? null, 'compartilhar.config', null, { ativo: cfg.ativo, regras: cfg.categorias.length, restaurar: b.restaurar === true })
  return panelGet(ctx)
}

/* ---------- Empresa (Sua empresa → Ajustes → Compartilhamento) ---------- */
export async function empresaGet(ctx: Ctx) {
  const { ownBusiness } = await import('./businesses.js'), { b } = await ownBusiness(ctx), x = J<any>(b.data, {})
  const pl = await SH.configPlataforma()
  return { config: SH.configEmpresa(x), plataforma: { ativo: pl.ativo, produto: pl.produto, servico: pl.servico, oferta: pl.oferta }, variaveis: SH.VARIAVEIS, limite: SH.LIMITE, exemplos: await exemplos(Number(b.id)), estatisticas: await SH.estatisticas(Number(b.id), 30) }
}
export async function empresaPut(ctx: Ctx) {
  const { ownBusiness } = await import('./businesses.js'), { u, b } = await ownBusiness(ctx), x = J<any>(b.data, {}), body = ctx.body || {}
  let c: any
  try { c = { ativo: body.ativo !== false, produto: SH.validarTexto(body.produto, 'Mensagem de produtos', false), servico: SH.validarTexto(body.servico, 'Mensagem de serviços', false), oferta: SH.validarTexto(body.oferta, 'Mensagem de ofertas', false) } }
  catch (e: any) { fail(400, e.message, 'invalid', e.campo) }
  if (body.restaurar === true) c = { ativo: c.ativo, produto: '', servico: '', oferta: '' }
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify({ ...x, compartilhar: c }), b.id]) // só a chave "compartilhar"; o resto do cadastro fica igual
  await audit(u.id, 'empresa.compartilhar', Number(b.id), { ativo: c.ativo })
  return empresaGet(ctx)
}
/** Para quem renderiza o catálogo: o botão de compartilhar aparece? (plataforma e empresa ligadas) */
export const ativoNaEmpresa = (x: any) => SH.ativoPara(x)
