// ABERTURA DO APP — apresentação da tela inicial (stories antes do login) — configuração persistente e editável pelo painel.
//   público ... GET /api/v2/abertura                    → telas ativas na ordem (título, destaque, subtítulo, imagem, duração)
//               GET /api/v2/abertura/telas/:id/imagem   → imagem enviada pelo administrador (cache longo, versionada)
//   painel .... GET/PUT /api/panel/abertura, POST /api/panel/abertura/restaurar  (permissão de editar o painel)
// As 4 telas padrão vêm da migração 069 (imagens em frontend/public/abertura/); trocar imagem, textos, ordem, ativação
// e duração não exige código nem deploy. A autenticação não muda: os botões levam às telas de entrar e cadastro de sempre.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { audit } from '../lib/account.js'
import { q, one, nowIso, B } from '../db/index.js'
import { getConfig, setConfig } from '../lib/settings.js'

export interface Cfg { ativo: boolean; duracao: number }
const CFG_PADRAO: Cfg = { ativo: true, duracao: 6 }
export const PADRAO = [
  { chave: 'assistente', ordem: 1, titulo: 'Seu assistente inteligente para', destaque: 'o dia a dia', subtitulo: 'Organize sua rotina, gerencie suas tarefas e tenha mais produtividade.', imagem_padrao: '/abertura/tela-1.webp' },
  { chave: 'agenda', ordem: 2, titulo: 'Agende, lembre e não perca', destaque: 'compromissos', subtitulo: 'Crie compromissos, receba lembretes e mantenha sua rotina organizada.', imagem_padrao: '/abertura/tela-2.webp' },
  { chave: 'financas', ordem: 3, titulo: 'Tenha o controle', destaque: 'das suas finanças', subtitulo: 'Registre gastos, acompanhe entradas e saídas e mantenha suas contas em dia.', imagem_padrao: '/abertura/tela-3.webp' },
  { chave: 'negocios', ordem: 4, titulo: 'Mais que um app, um aliado para', destaque: 'seus negócios', subtitulo: 'Gerencie atendimentos, vendas, clientes e destaque sua empresa no digital.', imagem_padrao: '/abertura/tela-4.webp' },
]
const IMG = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=]+)$/
const MAX_IMG = 2.5 * 1024 * 1024
const lim = (v: unknown, n: number) => String(v ?? '').replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n)
async function cfg(): Promise<Cfg> { const c = await getConfig<Partial<Cfg>>('abertura', {}); return { ...CFG_PADRAO, ...c, duracao: Math.min(20, Math.max(3, Number(c?.duracao) || CFG_PADRAO.duracao)) } }
const versao = (r: any) => String(Date.parse(String(r.updated_at)) || 0)
const imagemUrl = (r: any) => (r.imagem ? `/api/v2/abertura/telas/${r.id}/imagem?v=${versao(r)}` : String(r.imagem_padrao || ''))
const tela = (r: any, c: Cfg) => ({ id: Number(r.id), chave: String(r.chave), ordem: Number(r.ordem), ativo: B(r.ativo), titulo: String(r.titulo), destaque: String(r.destaque), subtitulo: String(r.subtitulo), duracao: Number(r.duracao) || c.duracao, duracaoPropria: Number(r.duracao) || 0, imagem: imagemUrl(r), imagemPersonalizada: !!r.imagem, imagemPadrao: String(r.imagem_padrao || '') })
async function linhas() { return (await q('SELECT * FROM abertura_telas ORDER BY ordem, id')) as any[] }
/** Garante as telas padrão (banco novo, ou alguém apagou linhas): nunca sobrescreve o que existe. */
async function garantir() {
  const rs = await linhas(); if (rs.length >= PADRAO.length) return rs
  for (const p of PADRAO) if (!rs.some((r) => r.chave === p.chave)) await q('INSERT INTO abertura_telas (chave, ordem, ativo, titulo, destaque, subtitulo, imagem_padrao, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)', [p.chave, p.ordem, true, p.titulo, p.destaque, p.subtitulo, p.imagem_padrao, nowIso()])
  return linhas()
}

/* ---------- público (sem login: é a primeira tela do app) ---------- */
export async function publicoGet(ctx: Ctx) {
  const c = await cfg(), rs = await garantir()
  const telas = c.ativo ? rs.filter((r) => B(r.ativo)).map((r) => { const t = tela(r, c); return { id: t.id, titulo: t.titulo, destaque: t.destaque, subtitulo: t.subtitulo, imagem: t.imagem, duracao: t.duracao } }) : []
  ctx.res.setHeader('Cache-Control', 'no-cache')
  return { ativo: c.ativo && telas.length > 0, duracao: c.duracao, telas }
}
export async function imagemGet(ctx: Ctx) {
  const r = await one('SELECT imagem FROM abertura_telas WHERE id = $1', [Number(ctx.params.id)]); const m = r && String(r.imagem).match(IMG)
  if (!m) fail(404, 'Imagem não encontrada.', 'not_found')
  return { _binary: true, mime: 'image/' + (m![1] === 'jpg' ? 'jpeg' : m![1]), data: Buffer.from(m![2], 'base64'), headers: { 'Cache-Control': 'public, max-age=31536000, immutable' } }
}

/* ---------- painel ---------- */
const P = () => import('./panel.js')
export async function painelGet(ctx: Ctx) {
  await (await P()).requirePanel(ctx)
  const c = await cfg(); return { config: c, telas: (await garantir()).map((r) => tela(r, c)), padrao: PADRAO.map((p) => ({ chave: p.chave, imagem: p.imagem_padrao })) }
}
function validarImagem(v: string) {
  const m = v.match(IMG); if (!m) fail(400, 'Envie uma imagem PNG, JPG ou WEBP.', 'invalid')
  const buf = Buffer.from(m![2], 'base64')
  if (buf.length > MAX_IMG) fail(400, 'A imagem passa de 2,5 MB. Reduza e tente de novo.', 'invalid')
  const png = buf[0] === 0x89 && buf[1] === 0x50, jpg = buf[0] === 0xff && buf[1] === 0xd8, webp = buf.slice(8, 12).toString() === 'WEBP'
  if (!png && !jpg && !webp) fail(400, 'O arquivo enviado não é uma imagem válida.', 'invalid')
}
/** Publica tudo de uma vez (a tela do painel edita um rascunho local e envia aqui ao "Salvar e publicar"). */
export async function painelPut(ctx: Ctx) {
  const u = await (await P()).requirePanel(ctx, true), b = ctx.body || {}, atual = await garantir()
  const c0 = await cfg(), c: Cfg = { ativo: typeof b.ativo === 'boolean' ? b.ativo : c0.ativo, duracao: b.duracao != null ? Math.min(20, Math.max(3, Math.round(Number(b.duracao)) || c0.duracao)) : c0.duracao }
  const lista: any[] = Array.isArray(b.telas) ? b.telas.slice(0, 20) : []
  const ids = new Set(atual.map((r) => Number(r.id)))
  for (const t of lista) if (!ids.has(Number(t?.id))) fail(400, 'Tela inexistente.', 'invalid')
  for (const t of lista) if (typeof t.imagem === 'string' && t.imagem && t.imagem !== 'padrao') validarImagem(t.imagem)
  for (const t of lista) { const ti = lim(t.titulo, 90); if (t.titulo !== undefined && !ti) fail(400, 'Cada tela precisa de um título.', 'invalid') }
  const agora = nowIso()
  for (const t of lista) {
    const r = atual.find((x) => Number(x.id) === Number(t.id))
    const img = t.imagem === 'padrao' ? '' : typeof t.imagem === 'string' && t.imagem ? t.imagem : String(r.imagem || '')
    await q('UPDATE abertura_telas SET ordem = $1, ativo = $2, titulo = $3, destaque = $4, subtitulo = $5, duracao = $6, imagem = $7, updated_at = $8 WHERE id = $9', [
      Number.isFinite(Number(t.ordem)) ? Math.round(Number(t.ordem)) : Number(r.ordem),
      typeof t.ativo === 'boolean' ? t.ativo : B(r.ativo),
      t.titulo !== undefined ? lim(t.titulo, 90) : r.titulo,
      t.destaque !== undefined ? lim(t.destaque, 60) : r.destaque,
      t.subtitulo !== undefined ? lim(t.subtitulo, 200) : r.subtitulo,
      t.duracao != null ? (Number(t.duracao) ? Math.min(20, Math.max(3, Math.round(Number(t.duracao)))) : 0) : Number(r.duracao),
      img, img !== String(r.imagem || '') || t.titulo !== undefined ? agora : r.updated_at, Number(t.id),
    ])
  }
  await setConfig('abertura', c)
  await audit(u.id, 'abertura.publicar', null, { ativo: c.ativo, duracao: c.duracao, telas: lista.map((t) => ({ id: t.id, ativo: t.ativo, ordem: t.ordem, imagem: t.imagem === 'padrao' ? 'padrao' : t.imagem ? 'nova' : 'mantida' })) })
  return painelGet(ctx)
}
export async function restaurarPost(ctx: Ctx) {
  const u = await (await P()).requirePanel(ctx, true), agora = nowIso()
  await garantir()
  for (const p of PADRAO) await q('UPDATE abertura_telas SET ordem = $1, ativo = $2, titulo = $3, destaque = $4, subtitulo = $5, duracao = 0, imagem = $6, imagem_padrao = $7, updated_at = $8 WHERE chave = $9', [p.ordem, true, p.titulo, p.destaque, p.subtitulo, '', p.imagem_padrao, agora, p.chave])
  await setConfig('abertura', CFG_PADRAO)
  await audit(u.id, 'abertura.restaurar', null, {})
  return painelGet(ctx)
}
