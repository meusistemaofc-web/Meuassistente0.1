import { registrarUso, type Uso } from '../ai/brain-usage.js'
import { withLock, registerBookingInAgenda, syncBookingStatus, ownerBusySlots, recordOrderIncome } from '../lib/business-sync.js'
import { normalizeTema } from '../lib/theme.js'
import { pub } from '../lib/publicurl.js'
import { once, canon } from '../ai/once.js'
import { randomBytes } from 'node:crypto'
// Empresas parceiras: busca por ramo e distância (com permissão de localização), página da empresa,
// loja com produtos/variações e pedidos (plano Loja completa) que chegam em Sua empresa.
import type { Ctx } from '../lib/http.js'
import { fail, str, HttpError } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { config } from '../config.js'
import { pixExpiry, pixValid } from '../lib/pix.js'
import { notify } from '../lib/notify.js'
import { getUM, setUM, requireModule, modules } from '../lib/usermod.js'
import { PLANS_DEFAULT, SEARCH_DEFAULT } from '../lib/panel-defaults.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set(['perto', 'proximo', 'proxima', 'quero', 'procuro', 'onde', 'tem', 'uma', 'um', 'mim', 'aqui', 'minha', 'meu', 'de', 'da', 'do', 'com', 'para', 'tem', 'algum', 'alguma', 'uns', 'umas', 'os', 'as', 'no', 'na'])
/* ---------- estatísticas de acesso ---------- */
const seen = new Set<string>()
const dayBR = () => new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10)
export async function hit(bid: number, kind: string, viewer?: string | number | null, ownerId?: number | null) {
  try {
    if (ownerId != null && viewer != null && String(viewer) === String(ownerId)) return // o dono não conta
    const day = dayBR()
    if (viewer != null && kind !== 'agente' && kind !== 'pedido') { const k = `${bid}:${kind}:${viewer}:${day}`; if (seen.has(k)) return; if (seen.size > 200000) seen.clear(); seen.add(k) }
    await q('INSERT INTO business_stats (business_id, day, kind, n) VALUES ($1,$2,$3,1) ON CONFLICT (business_id, day, kind) DO UPDATE SET n = business_stats.n + 1', [bid, day, kind])
  } catch (e: any) { console.error('[stats]', e?.message) }
}
/** Taxa de entrega: fixa, ou por distância (grátis até X km; acima, taxa de saída + valor por km excedente). */
export function deliveryFee(E: any, km: number) {
  if (E.modoTaxa !== 'km') return Number(E.taxa) || 0
  if (km <= (Number(E.kmGratis) || 0)) return 0
  return Math.round(((Number(E.taxaExcedente) || 0) + (Number(E.taxaKm) || 0) * (km - (Number(E.kmGratis) || 0))) * 100) / 100
}
export function distKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371, t = (x: number) => (x * Math.PI) / 180, dl = t(b.lat - a.lat), dn = t(b.lng - a.lng)
  const h = Math.sin(dl / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dn / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}
async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const nivelOf = (ps: any[], id: string) => (ps.find((p) => p.id === id) || {}).nivel || 1
async function activeRows() { return q("SELECT * FROM businesses WHERE status = 'ativo' AND (expires_at IS NULL OR expires_at > $1)", [nowIso()]) }
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']
const SERV_RE = /(barbear|salao|salão|cabel|manicure|pedicure|unha|estetic|estétic|clinic|clínic|consult|dentist|odonto|psicolog|terap|fisio|nutri|medic|médic|veterin|pet ?shop|banho e tosa|personal|academia|aula|curso|advog|contab|oficina|mecanic|mecânic|tatu|tattoo|piercing|fotograf|massag|spa|depila|sobrancel|cilios|cílios|maquiag|lavagem|lava ?jato|eletricist|encanad|diarista|limpeza|conserto|assistencia|assistência|studio|estúdio)/i
/** Como a empresa trabalha com o catálogo. Escolha explícita (produtos | servicos | ambos); sem escolha (empresas antigas) = ambos, para nada sumir. */
export const opTipo = (x: any): 'produtos' | 'servicos' | 'ambos' => (['produtos', 'servicos', 'ambos'].includes(x?.tipo) ? x.tipo : 'ambos')
export const allowsKind = (x: any, kind: string) => { const t = opTipo(x); return t === 'ambos' || (kind === 'servico' ? t === 'servicos' : t === 'produtos') }
const inOp = (x: any) => (p: any) => allowsKind(x, p.tipo === 'servico' ? 'servico' : 'produto')
export const nicheType = (x: any) => x.tipo || (SERV_RE.test(`${x.categoria || ''} ${x.tags || ''}`) ? 'servicos' : 'produtos')
/** Dinheiro: "precisa de troco?" → troco para quanto (não pode ser menor que o total). */
function trocoTxt(body: any, total: number) {
  if (body.precisaTroco === false) return 'sem troco'
  const raw = String(body.trocoPara ?? body.troco ?? '').replace(/[^0-9,.]/g, '')
  if (!raw) return body.precisaTroco ? (fail(400, 'Informe para quanto precisa de troco.', 'invalid') as any) : ''
  const v = Number(raw.includes(',') ? raw.replace(/\./g, '').replace(',', '.') : raw)
  if (!(v > 0)) fail(400, 'Valor do troco inválido.', 'invalid')
  if (v < total) fail(400, `O troco precisa ser para um valor maior que o total (R$ ${total.toFixed(2).replace('.', ',')}).`, 'invalid')
  return `R$ ${v.toFixed(2).replace('.', ',')}`
}
export function openState(x: any, agora: Date = new Date()): { aberto: boolean; texto: string } {
  const h = x.horarioCfg
  if (!h) return { aberto: true, texto: x.horario || '' }
  if (h.modo === 'aberto') return { aberto: true, texto: 'Aberto agora' }
  if (h.modo === 'fechado') return { aberto: false, texto: 'Fechado no momento' }
  // hora local da empresa
  const tz = (() => { try { const z = String(x.fuso || x.timezone || 'America/Sao_Paulo'); new Intl.DateTimeFormat('en-US', { timeZone: z }); return z } catch { return 'America/Sao_Paulo' } })()
  const now = new Date(agora.toLocaleString('en-US', { timeZone: tz }))
  const hm = now.getHours() * 60 + now.getMinutes(), wd = now.getDay()
  const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return (a || 0) * 60 + (b || 0) }
  const dia = (k: number) => { const d = h.dias?.[DIAS[(k + 7) % 7]]; return d && d.ativo ? { ab: toMin(d.abre), fe: toMin(d.fecha), abre: d.abre, fecha: d.fecha } : null }
  const vira = (d: { ab: number; fe: number }) => d.fe <= d.ab // expediente que atravessa a meia-noite (ex.: 08:00 → 00:30)
  // 1) expediente que começou ontem e ainda não fechou (ex.: quarta 08:00 → quinta 00:30; agora quinta 00:06)
  const ontem = dia(wd - 1)
  if (ontem && vira(ontem) && hm < ontem.fe) return { aberto: true, texto: `Aberto até ${ontem.fecha}` }
  // 2) expediente de hoje
  const hoje = dia(wd)
  if (hoje && (vira(hoje) ? hm >= hoje.ab : hm >= hoje.ab && hm < hoje.fe)) return { aberto: true, texto: `Aberto até ${hoje.fecha}` }
  // 3) fechado: próximo horário de abertura configurado
  if (hoje && hm < hoje.ab) return { aberto: false, texto: `Fechado · abre hoje às ${hoje.abre}` }
  const NOME = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb']
  for (let k = 1; k <= 7; k++) { const d = dia(wd + k); if (d) return { aberto: false, texto: `Fechado · abre ${k === 1 ? 'amanhã' : NOME[(wd + k) % 7]} às ${d.abre}` } }
  return { aberto: false, texto: 'Fechado' }
}
/** Etiqueta do produto: só uma, que exista na empresa e combine com o tipo (produto/serviço). */
export function validTags(x: any, tags: any, tipo: string) {
  const ids = (Array.isArray(tags) ? tags : []).map((t: any) => String(t || '').slice(0, 12)).filter(Boolean)
  const ok = ids.filter((id: string) => (x.etiquetas || []).some((e: any) => e.id === id && (!e.tipo || e.tipo === 'ambos' || e.tipo === (tipo === 'servico' ? 'servico' : 'produto'))))
  return ok.slice(-1)
}
let RATINGS = new Map<number, { avg: number; count: number }>(), ratingsAt = 0
export async function refreshRatings(force = false) {
  if (!force && Date.now() - ratingsAt < 60_000) return
  ratingsAt = Date.now()
  try { const m = new Map<number, { avg: number; count: number }>(); for (const r of await q('SELECT business_id, AVG(rating) AS avg, COUNT(*) AS n FROM reviews GROUP BY business_id')) m.set(Number(r.business_id), { avg: Math.round(Number(r.avg) * 10) / 10, count: Number(r.n) }); RATINGS = m } catch { /* tabela ainda não criada */ }
}
export const ratingOf = (id: number) => RATINGS.get(Number(id)) || null
function card(b: any, n: number, d: number | null) {
  const x = J<any>(b.data, {}), st = openState(x)
  return { id: Number(b.id), empresa: x.empresa, categoria: x.categoria, titulo: x.titulo, texto: x.texto, logo: x.logo || null, nivel: n, distancia: d,
    zap: n >= 2 ? x.zap || null : null, insta: n >= 2 ? x.insta || null : null, link: x.link || null, temPagina: n >= 3, temLoja: n >= 4, capa: x.capa || null, aberto: st.aberto, situacao: st.texto, avaliacao: ratingOf(Number(b.id)), descricao: String(x.titulo || x.texto || x.sobre || '').slice(0, 90) }
}
export function matches(q0: string, b: any, extra = '') {
  const words = norm(q0).split(' ').filter((w) => w.length >= 3 && !STOP.has(w))
  if (!words.length) return true
  const x = J<any>(b.data, {}), kw = norm(`${x.categoria} ${x.tags || ''} ${x.empresa} ${x.titulo || ''} ${x.palavras || ''} ${extra}`).split(' ').filter(Boolean)
  const forms = (w: string) => [w, w.replace(/s$/, ''), w.replace(/(ria|rias)$/, '')]
  return words.some((w) => forms(w).some((f) => f.length >= 3 && kw.some((k) => k === f || k.startsWith(f) || (f.startsWith(k) && k.length >= 4))))
}
export async function searchBusinesses(text: string, loc: { lat: number; lng: number; raio?: number | null } | null) {
  await refreshRatings()
  const ps = await plans(), admMax = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(admMax, loc?.raio || admMax)
  const out: any[] = []
  // palavras dos produtos/serviços publicados (nome, categoria e palavras-chave) também encontram a loja
  const pw = new Map<number, string>()
  for (const r of await q('SELECT business_id, data FROM products WHERE active = $1', [true])) { const d = J<any>(r.data, {}); pw.set(Number(r.business_id), (pw.get(Number(r.business_id)) || '') + ` ${d.nome || ''} ${d.categoria || ''} ${d.palavras || ''}`) }
  for (const b of await activeRows()) {
    if (!matches(text, b, pw.get(Number(b.id)) || '')) continue
    const raio = Math.min(max, Number(J<any>(b.data, {}).raio) || 5)
    const d = loc && b.lat != null ? distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) : null
    if (loc && (d === null || d > raio)) continue
    out.push(card(b, nivelOf(ps, b.plan_id), d === null ? null : Math.round(d * 10) / 10)); (out[out.length - 1] as any)._owner = Number(b.owner_id)
  }
  return out.sort((a, b) => (a.distancia ?? 1e9) - (b.distancia ?? 1e9)).slice(0, 30)
}
const locOk = (lat: number, lng: number) => isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

export async function myLocationPut(ctx: Ctx) {
  const u = requireUser(ctx), lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng)
  if (ctx.body?.clear) { await setUM(u.id, 'location', null); return { ok: true } }
  const old = await getUM<any>(u.id, 'location', null)
  const raio = Number(ctx.body?.raio) >= 1 && Number(ctx.body?.raio) <= 100 ? Number(ctx.body.raio) : old?.raio || null
  if (ctx.body?.raio && !ctx.body?.endereco && !isFinite(lat) && old) { await setUM(u.id, 'location', { ...old, raio }); return { ok: true, location: { ...old, raio } } }
  if (typeof ctx.body?.endereco === 'string' && ctx.body.endereco.trim().length >= 3) {
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(ctx.body.endereco.trim()), { headers: { 'User-Agent': 'MeuAssistente/1.0 (contato pelo app)', 'Accept-Language': 'pt-BR' } }).catch(() => null)
    const j: any = r && r.ok ? await r.json().catch(() => []) : []
    if (!j[0]) fail(400, 'Não encontrei esse endereço. Tente com bairro e cidade.', 'invalid')
    const loc = { lat: Number(j[0].lat), lng: Number(j[0].lon), at: nowIso(), raio, label: String(j[0].display_name || '').split(',').slice(0, 3).join(','), manual: true }
    await setUM(u.id, 'location', loc); return { ok: true, location: loc }
  }
  if (!locOk(lat, lng)) fail(400, 'Localização inválida.', 'invalid')
  const loc = { lat, lng, at: nowIso(), raio, label: 'Localização atual', manual: false }
  await setUM(u.id, 'location', loc); return { ok: true, location: loc }
}
export async function userLocation(userId: number) {
  const l = await getUM<any>(userId, 'location', null)
  return l && (l.manual || Date.now() - Date.parse(l.at) < 7 * 86400_000) ? { lat: l.lat, lng: l.lng, raio: l.raio || null, label: l.label || '' } : null
}
export async function businessSearchGet(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const lat = Number(ctx.query.get('lat')), lng = Number(ctx.query.get('lng'))
  const loc = locOk(lat, lng) ? { lat, lng } : await userLocation(u.id)
  if (!loc) return { needLocation: true, items: [] }
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15
  const items = await searchBusinesses(str(ctx.query.get('q'), 80), loc as any)
  for (const it of items) await hit(it.id, 'impressao', u.id, it._owner)
  items.forEach((it: any) => delete it._owner)
  return { needLocation: false, location: { label: (loc as any).label || 'Localização atual', raio: Math.min(adm, (loc as any).raio || adm), max: adm }, items }
}

/* ---------- página pública e produtos ---------- */
function productOut(p: any) { const d = J<any>(p.data, {}); return { id: Number(p.id), active: !!(p.active === true || p.active === 1 || p.active === 't'), ...d } }
export function unitPrice(prod: any, escolhas: Record<string, number>) {
  let base = Number(prod.preco) || 0, extra = 0
  for (const v of prod.variacoes || []) {
    const o = v.opcoes?.[Number(escolhas?.[v.nome] ?? 0)]
    if (!o) fail(400, `Escolha uma opção de ${v.nome}.`, 'invalid')
    const pr = Number(o.preco) || 0
    if (pr >= (Number(prod.preco) || 0) * 0.5 && pr > 0) base = pr; else extra += pr
  }
  return Math.round((base + extra) * 100) / 100
}
export async function businessGet(ctx: Ctx) {
  const u = ctx.user || null; await requireModule('empresas'); await refreshRatings()
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const ps = await plans()
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) fail(404, 'O anúncio desta empresa não está ativo.', 'not_found')
  const n = nivelOf(ps, b!.plan_id); if (n < 3) fail(404, 'Esta empresa não tem página própria.', 'not_found')
  const x = J<any>(b!.data, {}), loc = u ? await userLocation(u.id) : null
  await hit(Number(b!.id), 'visita', u ? u.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b!.owner_id))
  const loja = n >= 4 && (await modules()).catalogo !== false
  const prods = loja ? (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b!.id, true])).map(productOut).filter(inOp(x)) : [] // só o que o tipo de catálogo atual permite (o resto continua salvo, apenas oculto)
  return { ...card(b, n, loc && b!.lat != null ? Math.round(distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) * 10) / 10 : null),
    endereco: x.endereco, horario: x.horario, sobre: x.sobre, capa: x.capa || null, lat: b!.lat, lng: b!.lng, loja, operacao: opTipo(x), produtos: prods,
    // dono vendo a própria loja: explica por que o botão flutuante não aparece (ou confirma que está ativo)
    agenteAviso: u && Number(u.id) === Number(b!.owner_id) && x.agente?.flutuante?.ativo ? (!(await modules()).agente ? 'O botão flutuante não aparece: o administrador desligou o agente.' : x.agente.ativo === false ? 'O botão flutuante está oculto porque você desligou o atendente.' : !agentOn(x) ? 'O botão flutuante aparece aqui para seus clientes assim que o atendente estiver no ar (Ajustes → Agente de atendimento → Ativar agente).' : '') : '',
    // botão flutuante só com o atendente realmente no ar (contratado, dentro do prazo e ligado) e o botão ativado
    agente: (await modules()).agente && agentOn(x) && x.agente.flutuante?.ativo ? { link: `/g-${await ensureSlug(Number(b!.id))}`, msg: x.agente.flutuante.msg || 'Se precisar de ajuda, me chama aqui!', avatar: x.agente.avatar || x.logo || null, nome: agentName(x.agente) } : null,
    tema: normalizeTema(x.tema), tipo: nicheType(x), etiquetas: x.etiquetas || [], categorias: x.categorias || [], dias: x.horarioCfg?.dias || null, pagOnline: !!(x.pagamento?.online && x.mpTok), chavePix: x.pagamento?.chavePix || '',
    entrega: loja ? { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', modoTaxa: 'fixa', kmGratis: 0, taxaExcedente: 0, taxaKm: 0, ...(x.entrega || {}) } : null,
    pagamento: loja ? (() => { const pg = { pix: true, chavePix: '', mostrarChave: true, pixentrega: false, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }; if (pg.mostrarChave === false) pg.chavePix = ''; pg.online = !!(pg.online && x.mpTok); return pg })() : null }
}
async function ownBusiness(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  return { u, b: b! }
}
export async function productsGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); const x = J<any>(b.data, {}); return { operacao: opTipo(x), items: (await q('SELECT * FROM products WHERE business_id = $1 ORDER BY id', [b.id])).map(productOut).map((p: any) => ({ ...p, foraDoTipo: !inOp(x)(p) })) } }
export async function productsPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  if (nivelOf(await plans(), b.plan_id) < 4) fail(403, 'Produtos fazem parte do plano Loja completa.', 'forbidden')
  const it = ctx.body || {}
  if (it.action === 'delete') { await q('DELETE FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); return productsGet(ctx) }
  if (it.action === 'tags') { const p = await one('SELECT data FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) { const d = J<any>(p.data, {}); d.tags = validTags(J<any>(b.data, {}), it.tags, d.tipo); await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), Number(it.id)]) } return productsGet(ctx) }
  if (it.action === 'toggle') { const p = await one('SELECT active FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) await q('UPDATE products SET active = $1 WHERE id = $2', [!(p.active === true || p.active === 1), Number(it.id)]); return productsGet(ctx) }
  const nome = str(it.nome, 80), tipo = it.tipo === 'servico' ? 'servico' : 'produto', modoPreco = ['fixo', 'hora', 'consulta', 'orcamento'].includes(it.modoPreco) ? it.modoPreco : 'fixo'
  if (!it.id && !allowsKind(J<any>(b.data, {}), tipo)) fail(400, tipo === 'servico' ? 'Seu catálogo está configurado só para produtos. Mude em Ajustes → Tipo de catálogo para cadastrar serviços.' : 'Seu catálogo está configurado só para serviços. Mude em Ajustes → Tipo de catálogo para cadastrar produtos.', 'invalid')
  const preco = modoPreco === 'orcamento' ? Math.max(0, Number(it.preco) || 0) : Number(it.preco)
  if (!nome || !(preco >= 0 && preco < 1e6)) fail(400, 'Preencha o nome e um preço válido.', 'invalid')
  const fotosIn = (Array.isArray(it.fotos) ? it.fotos : []).filter((f: any) => typeof f === 'string' && f.startsWith('data:image/'))
  if (fotosIn.some((f: string) => f.length >= 900_000)) fail(400, 'Uma das fotos é muito grande. Escolha uma imagem menor (até ~600 KB) e tente de novo.', 'too_large')
  const fotos = fotosIn.slice(0, 2)
  if (!fotos.length && tipo === 'produto') fail(400, 'Adicione pelo menos uma foto do produto.', 'invalid')
  const duracao = tipo === 'servico' ? Math.min(600, Math.max(10, Math.round(Number(it.duracao) || 30))) : 0
  const tags = validTags(J<any>(b.data, {}), it.tags, it.tipo === 'servico' ? 'servico' : 'produto') // uma etiqueta por produto, existente e compatível
  const variacoes = (Array.isArray(it.variacoes) ? it.variacoes : []).slice(0, 6).map((v: any) => ({ nome: str(v.nome, 40), opcoes: (Array.isArray(v.opcoes) ? v.opcoes : []).slice(0, 12).map((o: any) => ({ nome: str(o.nome, 40), preco: Math.max(0, Number(o.preco) || 0) })).filter((o: any) => o.nome) })).filter((v: any) => v.nome && v.opcoes.length)
  // sinal antecipado: só em serviços sob orçamento (valor fixo em R$ ou % do valor de referência)
  let sinal: any = null
  if (tipo === 'servico' && modoPreco === 'orcamento' && it.sinal && it.sinal.ativo) {
    const st = it.sinal.tipo === 'pct' ? 'pct' : 'fixo', sv = Math.round((Number(it.sinal.valor) || 0) * 100) / 100
    if (!(sv > 0)) fail(400, 'Informe o valor do sinal.', 'invalid')
    if (st === 'pct' && (sv >= 100)) fail(400, 'A porcentagem do sinal deve ser menor que 100%.', 'invalid')
    if (st === 'pct' && !(preco > 0)) fail(400, 'Para sinal em porcentagem, informe o valor de referência do serviço.', 'invalid')
    if (st === 'fixo' && preco > 0 && sv >= preco) fail(400, 'O sinal deve ser menor que o valor de referência.', 'invalid')
    sinal = { ativo: true, tipo: st, valor: sv }
  }
  const palavras = String(it.palavras ?? '').split(/[,;\n]/).map((w: string) => str(w, 40).toLowerCase()).filter(Boolean).slice(0, 20).join(', ')
  const data = JSON.stringify({ nome, preco: Math.round(preco * 100) / 100, palavras, descricao: str(it.descricao, 600), categoria: str(it.categoria, 40) || (tipo === 'servico' ? 'Serviços' : 'Outros'), fotos, variacoes, tipo, modoPreco, duracao, tags, sinal })
  if (it.id) await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3 AND business_id = $4', [data, nowIso(), Number(it.id), b.id])
  else await q('INSERT INTO products (business_id, data, active, created_at, updated_at) VALUES ($1,$2,$3,$4,$4)', [b.id, data, true, nowIso()])
  return productsGet(ctx)
}

/* ---------- pedidos ---------- */
const NEXT: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['preparo', 'cancelado'], preparo: ['saiu', 'pronto', 'cancelado'], saiu: ['concluido', 'cancelado'], pronto: ['concluido', 'cancelado'] }
const NEXT_AG: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['concluido', 'cancelado'] }
const MSG: Record<string, string> = { aceito: 'foi aceito', preparo: 'está em preparo', saiu: 'saiu para entrega', pronto: 'está pronto para retirar', concluido: 'foi concluído', recusado: 'foi recusado', cancelado: 'foi cancelado' }
const orderOut = (o: any) => ({ id: Number(o.id), businessId: Number(o.business_id), status: o.status, total: Number(o.total), ...J<any>(o.data, {}), createdAt: o.created_at, updatedAt: o.updated_at })
export async function orderPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b || b.status !== 'ativo' || nivelOf(await plans(), b.plan_id) < 4) fail(404, 'Esta loja não está recebendo pedidos.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode fazer pedido na sua própria loja.', 'invalid')
  if (!openState(J<any>(b!.data, {})).aberto) fail(400, 'A loja está fechada agora. Veja o horário de funcionamento.', 'closed')
  const x = J<any>(b!.data, {}), E = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  P.online = !!(P.online && x.mpTok)
  if (!allowsKind(x, 'produto')) fail(400, 'Esta empresa trabalha só com serviços (agendamentos), sem pedidos de produtos.', 'invalid')
  const body = ctx.body || {}, itens: any[] = Array.isArray(body.itens) ? body.itens.slice(0, 50) : []
  if (!itens.length) fail(400, 'Seu pedido está vazio.', 'invalid')
  const prods = new Map((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2', [b!.id, true])).map((p) => [Number(p.id), J<any>(p.data, {})]))
  const linhas = itens.map((it) => {
    const p = prods.get(Number(it.pid)); if (!p || p.tipo === 'servico') fail(400, 'Um dos produtos não está mais disponível.', 'invalid')
    const qtd = Math.min(99, Math.max(1, Math.floor(Number(it.qtd) || 1))), preco = unitPrice(p, it.escolhas || {})
    const vars = (p!.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[Number(it.escolhas?.[v.nome] ?? 0)].nome}`)
    return { pid: Number(it.pid), nome: p!.nome, vars, obs: str(it.obs, 140), qtd, preco }
  })
  const sub = Math.round(linhas.reduce((a, l) => a + l.preco * l.qtd, 0) * 100) / 100
  const modo = body.modo === 'entrega' ? 'entrega' : 'retirada'
  if (modo === 'entrega' && !E.entrega) fail(400, 'Esta loja não faz entregas.', 'invalid')
  if (modo === 'retirada' && !E.retirada) fail(400, 'Esta loja não tem retirada no local.', 'invalid')
  if (E.minimo && sub < E.minimo) fail(400, `Pedido mínimo: R$ ${Number(E.minimo).toFixed(2).replace('.', ',')}.`, 'invalid')
  const endereco = modo === 'entrega' ? str(body.endereco, 200) : ''
  if (modo === 'entrega' && endereco.length < 6) fail(400, 'Informe o endereço de entrega.', 'invalid')
  if (modo === 'entrega' && b!.lat != null) { const loc = await userLocation(u.id); if (loc && distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) > Number(E.raio || 3)) fail(400, 'Seu endereço está fora da área de entrega desta loja.', 'invalid') }
  const pag = ['pix', 'pixentrega', 'cartao', 'dinheiro', 'online'].includes(body.pagamento) && P[body.pagamento] ? body.pagamento : null
  if (!pag) fail(400, 'Escolha uma forma de pagamento aceita pela loja.', 'invalid')
  let taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0
  if (modo === 'entrega' && E.modoTaxa === 'km') { const loc = await userLocation(u.id); if (!loc || b!.lat == null) fail(400, 'Para calcular a entrega por distância, ative sua localização em Empresas perto de você.', 'need_location'); taxa = deliveryFee(E, distKm(loc!, { lat: Number(b!.lat), lng: Number(b!.lng) })) }
  const total = Math.round((sub + taxa) * 100) / 100
  const zap = String(body.telefone || u.whatsapp || '').replace(/\D/g, '')
  if (zap.length < 10 || zap.length > 13) fail(400, 'Informe seu WhatsApp com DDD para a empresa falar com você.', 'invalid', 'telefone')
  body.telefone = zap.length <= 11 ? `+55${zap}` : `+${zap}`
  // mesmo pedido enviado duas vezes (toque duplo, rede lenta): devolve o mesmo, sem duplicar
  const idem = str(body.idem, 40)
  if (idem) { const ex = (await q("SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 AND status IN ('aguardando_pagamento','novo') ORDER BY id DESC LIMIT 5", [b!.id, u.id])).find((r) => J<any>(r.data, {}).idem === idem); if (ex) return { order: orderOut(ex) } }
  const data = { idem, itens: linhas, subtotal: sub, taxa, modo, endereco, pagamento: pag, obs: str(body.obs, 300), troco: pag === 'dinheiro' ? trocoTxt(body, total) : '', cliente: str(body.nome, 80) || u.name, telefone: str(body.telefone, 30) || u.whatsapp, empresa: x.empresa, motivo: '' }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, pag === 'online' ? 'aguardando_pagamento' : 'novo', total, JSON.stringify(data), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  if (pag === 'online') { // Pix automático pelo Mercado Pago da própria loja: o pedido só vai para a empresa depois da aprovação
    try { await createOrderPix(b, o, u.email, total) }
    catch (e: any) { await q('DELETE FROM orders WHERE id = $1', [o.id]); fail(502, 'Não foi possível gerar o Pix da loja agora. Escolha outra forma de pagamento.', 'mp_error') }
    o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!
  }
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  if (body.aceitaMarketing === true) await (await import('../lib/marketing.js')).setConsent(Number(b!.owner_id), u.id, true, 'pedido:' + o.id).catch(() => {})
  if (pag !== 'online') await notify(Number(b!.owner_id), { type: 'order', title: `Novo pedido #${o.id} · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente} · ${modo === 'entrega' ? 'entrega' : 'retirada'}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  return { order: orderOut(o) }
}
export async function myOrdersGet(ctx: Ctx) { const u = requireUser(ctx); return { items: (await q('SELECT * FROM orders WHERE customer_id = $1 ORDER BY id DESC LIMIT 60', [u.id])).map(orderOut).filter((o: any) => !o.guest).slice(0, 50) } }
export async function businessOrdersGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { items: (await q("SELECT * FROM orders WHERE business_id = $1 AND status <> 'aguardando_pagamento' ORDER BY id DESC LIMIT 200", [b.id])).map(orderOut) } }
export async function businessOrderPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), b.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const to = String(ctx.body?.status || ''), motivo = str(ctx.body?.motivo, 200)
  const ag = J<any>(o!.data, {}).tipo === 'agendamento'
  if (!((ag ? NEXT_AG : NEXT)[o!.status] || []).includes(to)) fail(400, 'Mudança de situação inválida.', 'invalid')
  if ((to === 'recusado' || to === 'cancelado') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  const d = { ...J<any>(o!.data, {}), motivo }
  await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [to, JSON.stringify(d), nowIso(), o!.id])
  await syncBookingStatus(Number(o!.id), to).catch((e) => console.error('[agenda]', e?.message))
  if (to === 'concluido') await recordOrderIncome(Number(o!.id), 'concluido').catch((e) => console.error('[financeiro]', e?.message))
  if (to === 'concluido') await (await import('../lib/followup.js')).scheduleFollowup(Number(o!.id)).catch((e) => console.error('[follow-up]', e?.message)) // só pedidos/agendamentos concluídos
  if (!J<any>(o!.data, {}).guest) await notify(Number(o!.customer_id), { type: 'order', title: ag ? `Agendamento #${o!.id} ${to === 'aceito' ? 'foi confirmado' : MSG[to]}` : `Pedido #${o!.id} ${MSG[to]}`, body: `${d.empresa}${motivo ? ' · ' + motivo : ''}`, link: '/x/pedidos', ref: `order:${o!.id}:${to}` })
  return businessOrdersGet(ctx)
}

/* ---------- Mercado Pago da loja (pagamento automático dos pedidos) ---------- */
const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
async function storeToken(b: any) {
  const d = J<any>(b.data, {}); let tok = await unseal(d.mpTok || '').catch(() => '')
  if (tok && d.mpModo === 'oauth' && d.mpRefresh && Number(d.mpExp) && Date.now() > Number(d.mpExp) - 7 * 86400_000) {
    const r = await (await import('./mpuser.js')).refreshToken(await unseal(d.mpRefresh))
    if (r) { tok = r.access; d.mpTok = await seal(r.access); if (r.refresh) d.mpRefresh = await seal(r.refresh); d.mpExp = r.exp; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(d), b.id]) }
  }
  return tok
}
async function createOrderPix(b: any, o: any, email: string, total: number, novo = false) {
  const tok = await storeToken(b); if (!tok) throw new Error('sem token')
  const exp = await pixExpiry()
  const x = J<any>(b.data, {})
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `order-${o.id}${novo ? '-' + Date.now() : ''}` },
    body: JSON.stringify({ transaction_amount: total, description: `Pedido #${o.id} · ${x.empresa}`, payment_method_id: 'pix', payer: { email: email || `pedido${o.id}@clientes.meuassistente.app` }, date_of_expiration: exp.iso, external_reference: `order:${o.id}`, notification_url: `${pub()}/api/mercadopago/webhook?store=${b.id}` }) })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp-loja] Pix:', r.status, JSON.stringify(p)?.slice(0, 200)); throw new Error('mp') }
  const td = p.point_of_interaction?.transaction_data || {}
  const d = { ...J<any>(o.data, {}), payment: { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }, pago: p.status === 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
}
/** Situação do Pix vinda do Mercado Pago (pendente, recusado, cancelado, expirado) — nunca aprova sem confirmação real. */
async function markOrderPayment(o: any, status: string) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment) return
  if (d.payment.status === status) return
  d.payment = { ...d.payment, status }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
  if (['rejected', 'cancelled', 'expired'].includes(status) && !d.guest) await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} não aprovado`, body: `${d.empresa} · gere um novo Pix em Meus pedidos ou escolha outra forma de pagamento`, link: '/x/pedidos', ref: `order-pay-${status}:${o.id}:${d.payment.id}` })
}
async function markOrderPaid(o: any) {
  const d = J<any>(o.data, {}); if (d.pago) return
  d.pago = true; d.payment = { ...(d.payment || {}), status: 'approved' }
  await q('UPDATE orders SET data = $1, status = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(d), o.status === 'aguardando_pagamento' ? 'novo' : o.status, nowIso(), o.id])
  await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message)) // agendamento com sinal: entra na Agenda quando o Pix é aprovado
  await recordOrderIncome(Number(o.id), 'pago_online').catch((e) => console.error('[financeiro]', e?.message)) // dinheiro recebido → lançamento de entrada
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [o.business_id])
  if (b) await notify(Number(b.owner_id), { type: 'order', title: `Novo pedido #${o.id} · PAGO · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'} · Pix confirmado`, link: '/x/sua-empresa', ref: `order-paid:${o.id}` })
  if (!d.guest) await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} confirmado`, body: d.empresa, link: '/x/pedidos', ref: `order-paid-c:${o.id}` })
}
async function checkOrderPayment(o: any) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment?.id) return d.pago ? 'approved' : 'none'
  const b = await one('SELECT * FROM businesses WHERE id = $1', [o.business_id]); if (!b) return 'none'
  const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(d.payment.id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
  const p: any = await r.json().catch(() => ({}))
  if (r.ok && p.status === 'approved' && String(p.external_reference) === `order:${o.id}`) { await markOrderPaid(o); return 'approved' }
  if (r.ok && String(p.external_reference) === `order:${o.id}` && ['rejected', 'cancelled', 'expired', 'pending', 'in_process'].includes(p.status)) await markOrderPayment(o, p.status)
  return p.status || 'unknown'
}
export async function orderPayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown'), d = J<any>(o!.data, {})
  return { status: st, payment: d.payment ? { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt } : null, expirado: !d.pago && !pixValid(d.payment), total: Number(o!.total) }
}
export async function orderPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const d = J<any>(o!.data, {}); if (d.pago) return orderPayGet(ctx)
  if (['cancelado', 'recusado', 'concluido'].includes(o!.status)) fail(400, 'Este pedido não aceita mais pagamento.', 'invalid')
  if (!pixValid(d.payment) || ['rejected', 'cancelled', 'expired'].includes(d.payment?.status)) { const b = await one('SELECT * FROM businesses WHERE id = $1', [o!.business_id]); await createOrderPix(b, o, u.email, Number(o!.total), true) }
  return orderPayGet(ctx)
}
export async function storeWebhook(ctx: Ctx) {
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.query.get('store'))])
  if (!id || !b) return { ok: true }
  const gsec = await (await import('./mpuser.js')).globalWebhookSecret()
  const sec = (await unseal(J<any>(b.data, {}).mpSecret || '').catch(() => '')) || gsec
  if (sec) { // valida a assinatura x-signature do Mercado Pago com a chave secreta da própria loja
    const sig = String(ctx.req.headers['x-signature'] || ''), rid = String(ctx.req.headers['x-request-id'] || '')
    const ts = /ts=([^,]+)/.exec(sig)?.[1] || '', v1 = /v1=([^,]+)/.exec(sig)?.[1] || ''
    const { createHmac, timingSafeEqual } = await import('node:crypto')
    const calc = createHmac('sha256', sec).update(`id:${id.toLowerCase()};request-id:${rid};ts:${ts};`).digest('hex')
    if (!v1 || v1.length !== calc.length || !timingSafeEqual(Buffer.from(v1), Buffer.from(calc))) { console.error('[mp-loja] webhook com assinatura inválida, ignorado'); return { ok: true } }
  }
  try {
    const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
    const p: any = await r.json()
    const oid = String(p.external_reference || '').replace('order:', '')
    // o pedido precisa ser desta empresa e o pagamento precisa existir na conta Mercado Pago DELA (consulta com o token da loja)
    const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(oid), b.id])
    if (o && r.ok && String(p.external_reference) === `order:${o.id}` && String(J<any>(o.data, {}).payment?.id || '') === String(p.id)) {
      if (p.status === 'approved') await markOrderPaid(o)
      else await markOrderPayment(o, String(p.status || ''))
    }
  } catch (e: any) { console.error('[mp-loja] webhook:', e?.message) }
  return { ok: true }
}
export async function storeMpPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, d = J<any>(b.data, {})
  const M = await import('./mpuser.js')
  if (body.action === 'status') return mpView(b, d, await M.planAllowed(b))
  if (['oauth', 'connect', undefined, ''].includes(body.action) && body.action !== 'remove' && !(await M.planAllowed(b))) fail(403, 'O recebimento pelo Mercado Pago está disponível só para empresas com plano empresarial ativo.', 'plan_required')
  if (body.action === 'oauth') return { url: await M.businessAuthUrl(Number((ctx as any).user?.id || 0), Number(b.id)) }
  if (body.action === 'test') {
    const tok = await storeToken(b); if (!tok) return { ok: false, message: 'Salve o Access Token da sua conta Mercado Pago antes de testar.' }
    try { const r = await fetch(`${MPB()}/users/me`, { headers: { Authorization: `Bearer ${tok}` } }); const j: any = await r.json().catch(() => ({}))
      if (!r.ok) return { ok: false, message: r.status === 401 || r.status === 403 ? 'O Mercado Pago recusou o Access Token.' : 'Erro ' + r.status + ' no Mercado Pago.' }
      return { ok: true, message: `Conectado à conta ${j.nickname || j.email || j.id}${tok.startsWith('TEST-') ? ' (modo teste)' : ''}. Pronto para receber.` }
    } catch (e: any) { return { ok: false, message: 'Sem conexão com o Mercado Pago.' } }
  }
  if (body.action === 'secret') { const sec = String(body.secret || '').trim(); if (sec) d.mpSecret = await seal(sec.slice(0, 200)); else delete d.mpSecret }
  else if (body.action === 'remove') { delete d.mpTok; delete d.mpSecret; delete d.mpRefresh; delete d.mpExp; delete d.mpUserId; delete d.mpConta; delete d.mpModo; d.pagamento = { ...(d.pagamento || {}), online: false } }
  else {
    const tok = String(body.tok || '').trim()
    if (!/^(APP_USR|TEST)-[\w-]{10,}$/.test(tok)) fail(400, 'O Access Token começa com APP_USR- (produção) ou TEST- (teste).', 'invalid')
    d.mpTok = await seal(tok); d.mpModo = 'manual'; delete d.mpRefresh; delete d.mpExp; d.pagamento = { ...(d.pagamento || {}), online: true }
  }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, ...(await mpView(b, d, true)) }
}
async function mpView(b: any, d: any, permitido: boolean) { const tok = d.mpTok ? await unseal(d.mpTok).catch(() => '') : ''; return { mpLoja: !!d.mpTok, mpMasked: tok ? maskSecret(tok) : '', mpModo: d.mpModo || (d.mpTok ? 'manual' : null), mpConta: d.mpConta || null, mpTeste: /^TEST-/.test(tok), mpExp: d.mpExp || null, permitido, oauthDisponivel: await (await import('./mpuser.js')).appConfigured() } }

/** Cartões das empresas para o chat (imagem, descrição e botões conforme o plano). */
export async function businessCardsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const ids = String(ctx.query.get('ids') || '').split(',').map(Number).filter((n) => n > 0).slice(0, 12)
  if (!ids.length) return { items: [] }
  await refreshRatings()
  const ps = await plans(), loc = await userLocation(u.id), out: any[] = []
  for (const id of ids) {
    const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [id])
    if (!b || (b.expires_at && Date.parse(b.expires_at) < Date.now())) continue
    out.push(card(b, nivelOf(ps, b.plan_id), loc && b.lat != null ? Math.round(distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) * 10) / 10 : null))
    await hit(id, 'impressao', u.id, Number(b.owner_id))
  }
  return { items: out }
}

/** Escolhe um anúncio para aparecer no chat conforme a frequência definida no painel. */
export async function maybeAd(u: { id: number }) {
  const cfg = { ativo: true, cada: 6, intervaloMin: 30, ...(await getConfig<any>('ad_frequency', {})) }
  if (!cfg.ativo || !(await modules()).anuncios) return null
  const st = await getUM<any>(u.id, 'ad_state', { n: 0, at: 0 }); st.n = (st.n || 0) + 1
  if (st.n < Math.max(1, Number(cfg.cada) || 6) || Date.now() - (st.at || 0) < (Number(cfg.intervaloMin) || 0) * 60_000) { await setUM(u.id, 'ad_state', st); return null }
  const loc = await userLocation(u.id), rows = (await activeRows()).filter((b) => Number(b.owner_id) !== u.id && (!loc || b.lat == null || distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) <= (Number(J<any>(b.data, {}).raio) || 5)))
  if (!rows.length) { await setUM(u.id, 'ad_state', st); return null }
  const pick = rows[Math.floor(Math.random() * rows.length)]
  await setUM(u.id, 'ad_state', { n: 0, at: Date.now() })
  await hit(Number(pick.id), 'impressao', u.id, Number(pick.owner_id))
  return Number(pick.id)
}

/* ---------- Agente de atendimento da empresa (plano próprio, link público) ---------- */
const agentHits = new Map<string, number[]>()
async function agentPlan() { return { preco: 39.9, dias: 30, limiteDia: 300, ...(await getConfig<any>('agent_plan', {})) } }
/** Nome do atendente virtual: padrão "Meu Assistente"; qualquer nome que a empresa escolher é respeitado (o antigo padrão "Atendente" também vira o novo padrão). */
export const AGENT_NAME_DEFAULT = 'Meu Assistente'
export const agentName = (a: any) => { const n = String(a?.nome ?? '').trim(); return n && n !== 'Atendente' ? n : AGENT_NAME_DEFAULT }
const agentOn = (x: any) => !!(x.agente && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() && x.agente.ativo !== false)
export async function agentPut(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const outro = (await q('SELECT id, data FROM businesses WHERE owner_id = $1 AND id <> $2', [u.id, b.id])).find((r) => J<any>(r.data, {}).agente)
  const d = J<any>(b.data, {}), a = ctx.body || {}
  // só bloqueia CRIAR um segundo agente; editar o agente que já existe nesta empresa sempre salva
  if (outro && !d.agente) fail(409, `Você já tem um agente (${J<any>(outro.data, {}).empresa}).`, 'agent_exists')
  const av = typeof a.avatar === 'string' ? (a.avatar === '' ? '' : a.avatar.startsWith('data:image/') && a.avatar.length < 300_000 ? a.avatar : undefined) : undefined
  d.agente = { ...(d.agente || {}), nome: str(a.nome, 40) || AGENT_NAME_DEFAULT, saudacao: str(a.saudacao, 300), instrucoes: str(a.instrucoes, 2000), tom: ['amigavel', 'profissional', 'divertido', 'direto'].includes(a.tom) ? a.tom : 'amigavel', ativo: a.ativo !== undefined ? a.ativo !== false : d.agente?.ativo !== false, botoes: a.botoes !== undefined ? a.botoes !== false : d.agente?.botoes !== false, flutuante: a.flutuante && typeof a.flutuante === 'object' ? { ativo: !!a.flutuante.ativo, msg: str(a.flutuante.msg, 80) || 'Se precisar de ajuda, me chama aqui!' } : d.agente?.flutuante || { ativo: false, msg: 'Se precisar de ajuda, me chama aqui!' }, ...(av !== undefined ? { avatar: av } : {}) }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(b.id)
}
async function agentInfo(id: number) {
  let b = await one('SELECT * FROM businesses WHERE id = $1', [id]); let x = J<any>(b!.data, {})
  if (x.agente?.payment?.id && !agentOn(x)) { try { const r = await fetch(`${MPB()}/v1/payments/${x.agente.payment.id}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json(); if (j.status === 'approved' && j.external_reference === `agent:${id}`) { await activateAgent(id, String(x.agente.payment.id)); b = await one('SELECT * FROM businesses WHERE id = $1', [id]); x = J<any>(b!.data, {}) } } catch {} }
  const p = await agentPlan()
  const mod = (await modules()).agente, adNoAr = b!.status === 'ativo' && !(b!.expires_at && Date.parse(b!.expires_at) < Date.now()), expired = false
  const motivo = !mod ? 'O administrador desligou o agente para todas as empresas.' : x.agente && x.agente.ativo === false && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() ? 'Você desligou o agente. Ligue de novo quando quiser.' : !agentOn(x) ? (x.agente?.expiresAt ? 'O plano do agente venceu: renove para voltar a atender.' : 'Coloque o agente no ar para ele atender seus clientes.') : ''
  return { motivo, anuncio: { noAr: adNoAr, ate: b!.expires_at || null, status: b!.status }, agenteAte: x.agente?.expiresAt || null, vencido: !!(x.agente?.expiresAt && Date.parse(x.agente.expiresAt) <= Date.now()), agente: x.agente ? { ...x.agente, nome: agentName(x.agente) } : null, nomePadrao: AGENT_NAME_DEFAULT, ativo: agentOn(x) && mod && !expired, link: await agentLink(id), plano: { preco: p.preco, dias: p.dias }, payment: x.agente?.payment || null }
}
export async function agentGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return agentInfo(Number(b.id)) }
async function adminTok() { const { MP_DEFAULT } = await import('../lib/panel-defaults.js'); const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }; return unseal((mp[mp.modo] || {}).tok || '') }
export async function agentPayPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const d = J<any>(b.data, {}); if (!d.agente) fail(400, 'Configure o agente antes de pagar.', 'invalid')
  const p = await agentPlan()
  if (u.role !== 'user') { await activateAgent(Number(b.id), 'admin-' + Date.now()); return agentInfo(Number(b.id)) } // administrador: sem pagamento
  if (pixValid(d.agente.payment)) return agentInfo(Number(b.id))
  const exp = await pixExpiry(), tok = await adminTok(); if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador.', 'mp_not_configured')
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `agent-${b.id}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: p.preco, description: `Agente de atendimento · ${d.empresa}`, payment_method_id: 'pix', payer: { email: u.email }, date_of_expiration: exp.iso, external_reference: `agent:${b.id}`, notification_url: `${pub()}/api/mercadopago/webhook` }) })
  const j: any = await r.json().catch(() => null); if (!r.ok || !j?.id) fail(502, 'Não foi possível gerar o Pix agora.', 'mp_error')
  const td = j.point_of_interaction?.transaction_data || {}
  d.agente.payment = { id: String(j.id), valor: p.preco, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(Number(b.id))
}
export async function activateAgent(bid: number, paymentId: string) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); if (!b) return
  const d = J<any>(b.data, {}), p = await agentPlan(); if (!d.agente || d.agente.lastPayment === paymentId) return
  const base = d.agente.expiresAt && Date.parse(d.agente.expiresAt) > Date.now() ? Date.parse(d.agente.expiresAt) : Date.now()
  d.agente = { ...d.agente, expiresAt: new Date(base + p.dias * 86400_000).toISOString(), lastPayment: paymentId, payment: null }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), bid])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Seu agente de atendimento está no ar!', body: `Compartilhe o link: ${await agentLink(Number(bid))}`, link: '/x/sua-empresa', ref: `agent:${bid}:${paymentId}` })
}
export async function agentPayGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), d = J<any>(b.data, {})
  if (agentOn(d) && !d.agente?.payment) return { status: 'approved' }
  const pid = d.agente?.payment?.id; if (!pid) return { status: 'none' }
  try { const r = await fetch(`${MPB()}/v1/payments/${pid}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json()
    if (j.status === 'approved' && j.external_reference === `agent:${b.id}`) { await activateAgent(Number(b.id), pid); return { status: 'approved' } } return { status: j.status } } catch { return { status: 'unknown' } }
}
async function agentBiz(id: number, ctx?: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [id]); const x = b ? J<any>(b.data, {}) : null
  const dono = !!(ctx?.user && b && Number(b.owner_id) === ctx.user.id)
  if (b && x && dono && x.agente) return { b, x, teste: !agentOn(x) } // o dono pode testar antes de colocar no ar
  if (!b || !x || !(await modules()).agente || !agentOn(x)) {
    const err: any = new HttpError(404, 'O atendimento automático desta empresa está pausado no momento.', 'not_found')
    err.extra = b && x ? { empresa: x.empresa, logo: x.logo || null, zap: x.zap || null, loja: b.status === 'ativo' ? `${pub()}/x/empresa/${b.id}` : null } : null
    throw err
  }
  return { b, x, teste: false }
}
export async function agentPublicGet(ctx: Ctx) {
  const { b, x, teste } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x)
  return { teste, avatar: x.agente.avatar || x.logo || null, botoes: x.agente.botoes !== false, nome: agentName(x.agente), saudacao: x.agente.saudacao || `Olá! Sou ${agentName(x.agente)}, da ${x.empresa}. Como posso ajudar?`, empresa: x.empresa, categoria: x.categoria, logo: x.logo || null, aberto: st.aberto, situacao: st.texto, loja: `${pub()}/x/empresa/${b.id}`, zap: x.zap || null, tema: normalizeTema(x.tema) }
}
export async function agentChatPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b, x, teste } = await agentBiz(id, ctx)
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= 12) fail(429, 'Muitas mensagens seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
  const p = await agentPlan(), day = new Date().toISOString().slice(0, 10), cnt = x.agente.uso?.dia === day ? x.agente.uso.n : 0
  if (cnt >= p.limiteDia) fail(429, 'O atendimento automático atingiu o limite de hoje. Fale com a empresa pelo WhatsApp.', 'limit_reached')
  const msgs = (Array.isArray(ctx.body?.messages) ? ctx.body.messages : []).slice(-8).map((m: any) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: str(m.content, 500) })).filter((m: any) => m.content)
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') fail(400, 'Envie uma mensagem.', 'invalid')
  const last = nrm(msgs[msgs.length - 1].content), curto = last.split(/\s+/).length <= 14
  const est = openState(x), local: [RegExp, string, string][] = [
    [/(cardapio|catalogo|\bmenu\b|produtos|servicos|o que (voce|voces|vcs?) (tem|vende|faz)|opcoes|lista de precos|ver precos)/, 'catalogo', 'Aqui está o nosso catálogo. Toque em Adicionar para montar seu pedido.'],
    [/(onde fica|onde voces ficam|endereco|localizacao|como chego|como chegar|\bmapa\b|fica onde)/, 'mapa', x.endereco ? `Estamos em ${x.endereco}. Veja o mapa e a rota abaixo.` : 'Veja nossa localização no mapa abaixo.'],
    [/(horario|que horas|abre|fecha|funcionamento|esta aberto|estao abertos|aberto hoje)/, 'horario', `Agora: ${est.texto || (est.aberto ? 'aberto' : 'fechado')}. Veja nosso horário abaixo.`],
    [/(forma de pagamento|formas de pagamento|como pago|como pagar|aceita (pix|cartao|dinheiro)|tem entrega|faz entrega|entregam|taxa de entrega|frete|delivery|retirada|chave pix)/, 'pagamento', 'Veja as formas de pagamento e de entrega abaixo.'],
    [/(meu carrinho|ver carrinho|finalizar( o)? pedido|fechar( o)? pedido)/, 'carrinho', 'Aqui está o seu carrinho.'],
  ]
  const hitL = curto ? local.find(([re]) => re.test(last)) : null
  if (hitL && !(hitL[1] === 'catalogo' && nivelOf(await plans(), b.plan_id) < 4)) {
    if (!teste) { x.agente.uso = { dia: new Date().toISOString().slice(0, 10), n: (x.agente.uso?.dia === new Date().toISOString().slice(0, 10) ? x.agente.uso.n : 0) + 1 }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); await hit(id, 'agente', null) }
    if (hitL[1] === 'catalogo') {
      const nProd = Number((await q('SELECT COUNT(*) AS n FROM products WHERE business_id = $1 AND active = $2', [id, true]))[0]?.n || 0)
      if (!nProd) return { reply: `No momento ${x.empresa || 'a loja'} ainda não tem produtos publicados aqui.${x.zap ? ' Você pode falar direto com a empresa pelo WhatsApp.' : ''}`, produtos: null, pix: null, secao: null }
    }
    return { reply: hitL[2], produtos: null, pix: null, secao: hitL[1] }
  }
  // Cérebro: regras executáveis (recusar/anexar) e conhecimento aprovado com escopo "agentes", antes de qualquer IA
  const rawLast = msgs[msgs.length - 1].content, usosAg: Uso[] = []; let rodapeAg: string[] = []
  {
    const R = await import('../ai/rules.js'), K = await import('../ai/knowledge.js')
    const rr = await R.applyRules({ user: null, canal: 'agente', texto: rawLast, businessId: id }).catch(() => null)
    if (rr) { usosAg.push(...rr.usos); rodapeAg = rr.rodape }
    const kb = !rr?.terminal && (await (await import('../lib/settings.js')).getConfig<any>('brain', {})).cerebroPrimeiro !== false ? await K.answerKnowledge(rawLast, null, 0.6, { canal: 'agente' }).catch(() => null) : null
    const direta = rr?.terminal && rr.reply ? rr.reply : kb ? kb.resposta : null
    if (direta) {
      if (kb) usosAg.push(...K.usoDeConsulta(kb, 'agente'))
      if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); await hit(id, 'agente', null) }
      await registrarUso(usosAg, { canal: 'agente', businessId: id })
      return { reply: direta + (rodapeAg.length ? '\n\n' + [...new Set(rodapeAg)].join('\n') : ''), produtos: null, pix: null, secao: null }
    }
  }
  const brainCtxAg = await (await import('../ai/brain.js')).brainContext(rawLast, usosAg, 'agente').catch(() => '')
  const prods = (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 60', [id, true])).map(productOut).filter(inOp(x))
  const ps = await plans(), n = nivelOf(ps, b.plan_id), st = openState(x), E = { ...(x.entrega || {}) }, P = { ...(x.pagamento || {}) }
  const { complete, engineCfg, engineInstructions } = await import('../ai/provider.js')
  const eng = await engineCfg()
  const sys = [
    `Você é ${agentName(x.agente)}, atendente virtual da empresa "${x.empresa}" (${x.categoria}). Atenda clientes em português do Brasil, de forma natural, educada e objetiva, ajudando a tirar dúvidas e a vender.`,
    engineInstructions({ ...eng, personalidade: x.agente.tom || eng.personalidade, personalidadeTexto: '' }),
    (await import('../ai/commercial.js')).AGENTE_VENDAS,
    'Use SOMENTE as informações abaixo. Não invente preços, produtos, prazos ou políticas. Se não souber, diga que vai verificar e ofereça o WhatsApp da empresa.',
    `Sobre: ${x.sobre || x.texto || ''}`, x.horarioCfg?.dias ? `Horário de funcionamento ATUAL (vale mais que qualquer horário dito antes nesta conversa): ${['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'].map((k) => { const d = x.horarioCfg.dias[k]; return `${k} ${d?.ativo ? d.abre + '–' + d.fecha : 'fechado'}` }).join(', ')}.` : (x.horario ? `Horário: ${x.horario}` : ''), x.endereco ? `Endereço: ${x.endereco}` : '', `Situação agora: ${st.texto || (st.aberto ? 'aberto' : 'fechado')}.`,
    n >= 4 ? `Pedidos: o cliente faz o pedido pela loja online: ${pub()}/x/empresa/${id}` : '', x.zap ? `WhatsApp: https://wa.me/${x.zap}` : '',
    E.entrega ? `Entrega: até ${E.raio || 3} km; ${E.modoTaxa === 'km' ? `grátis até ${E.kmGratis || 0} km, depois R$ ${E.taxaExcedente || 0} + R$ ${E.taxaKm || 0} por km` : `taxa R$ ${E.taxa || 0}`}${E.tempo ? `; tempo ${E.tempo}` : ''}.` : 'Somente retirada no local.',
    `Pagamento: ${[P.online ? 'Pix pelo app' : '', P.pix ? 'Pix' : '', P.cartao ? 'cartão na entrega/retirada' : '', P.dinheiro ? 'dinheiro' : ''].filter(Boolean).join(', ') || 'combinar com a empresa'}.`,
    prods.length ? `Catálogo (use o id nas ferramentas):\n${prods.map((p: any) => `- [id ${p.id}] ${p.tipo === 'servico' ? '(serviço ' + (p.duracao || 30) + ' min, ' + ({ fixo: 'valor fixo', hora: 'por hora', consulta: 'consulta', orcamento: 'sob orçamento' } as any)[p.modoPreco || 'fixo'] + ') ' : ''}${p.nome}: R$ ${Number(p.preco).toFixed(2).replace('.', ',')}${(p.variacoes || []).length ? ' (' + p.variacoes.map((v: any) => v.nome + ': ' + v.opcoes.map((o: any) => o.nome + (o.preco ? ' R$ ' + o.preco : '')).join('/')).join('; ') + ')' : ''}${p.descricao ? ' – ' + String(p.descricao).slice(0, 120) : ''}`).join('\n')}` : '',
    x.agente.instrucoes ? `Instruções da empresa: ${x.agente.instrucoes}` : '',
    brainCtxAg,
  ].filter(Boolean).join('\n')
  const out: any = {}, conv: any[] = [{ role: 'system', content: sys + '\nVocê pode usar ferramentas: ' + ({ produtos: 'mostrar_catalogo (mostra fotos e preços na tela) e criar_pedido. Esta empresa trabalha SÓ com produtos: não ofereça agendamentos.', servicos: 'mostrar_catalogo (mostra fotos e preços na tela), horarios_livres e agendar_servico. Esta empresa trabalha SÓ com serviços: não existe pedido de produtos.', ambos: 'mostrar_catalogo (mostra fotos e preços na tela), criar_pedido, horarios_livres e agendar_servico.' } as any)[opTipo(x)] + ' Antes de criar pedido ou agendamento, confirme itens/opções, retirada ou entrega (com endereço), forma de pagamento e o nome do cliente. Quando gerar Pix, diga que o QR Code apareceu na tela. Datas de hoje: ' + new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10) + '.' }, ...msgs]
  let m: any = null
  const turn = Math.random().toString(36).slice(2, 10)
  for (let round = 0; round < 4; round++) {
    try { m = await complete(conv as any, AG_TOOLS.filter((t: any) => opTipo(x) === 'ambos' || (opTipo(x) === 'produtos' ? !['horarios_livres', 'agendar_servico'].includes(t.function.name) : t.function.name !== 'criar_pedido')) as any, { allowEmpty: round > 0 }) } catch (e) { if (round > 0) { m = null; break } throw e } // pedido/Pix já gerado nunca se perde nem se repete
    if (!m.tool_calls?.length) break
    conv.push({ role: 'assistant', content: m.content ?? null, tool_calls: m.tool_calls })
    for (const call of m.tool_calls) {
      let res: any
      try {
        const args = JSON.parse(call.function.arguments || '{}'), r = await once('t:' + turn, call.function.name + ':' + canon(args), 600_000, () => runAgentTool(b, call.function.name, args, out))
        res = r.hit ? { ...(r.value && typeof r.value === 'object' ? r.value : {}), deduped: true, aviso: 'Já executado: não repita esta ação.' } : r.value
      } catch (e: any) { res = { ok: false, erro: e?.message || 'falha' } }
      conv.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(res) })
    }
    // só mostrou catálogo/seção na tela: responde na hora, sem outra ida à IA (economiza uma rodada inteira)
    const soMostrar = m.tool_calls.every((c: any) => c.function.name === 'mostrar_catalogo' || c.function.name === 'mostrar_secao')
    if (soMostrar && (out.produtos?.length || out.secao)) {
      const txt = String(m.content || '').trim()
      m = { role: 'assistant', content: txt && !/n[aã]o (temos|h[aá]|tem) produtos/i.test(txt) ? txt : out.produtos?.length ? 'Aqui estão as opções 👇 Toque em Adicionar ou Agendar no que quiser.' : ({ mapa: 'Aqui está a nossa localização 👇', horario: 'Este é o nosso horário de funcionamento 👇', pagamento: 'Estas são as formas de pagamento e entrega 👇', carrinho: 'Este é o seu carrinho 👇', catalogo: 'Aqui está o catálogo 👇' } as any)[out.secao] || 'Pronto 👇' }
      break
    }
    m = null
  }
  if (!m) m = { content: out.pix ? 'Pronto! Gerei o Pix: o QR Code e o código copia e cola estão logo abaixo.' : 'Pronto!' }
  // Garante catálogo real: se o cliente pediu cardápio/catálogo e há produtos, força os cards e limpa contradição
  const pediuCat = /(cardapio|catalogo|menu|produtos|servicos|o que (voce|voces|vcs?) (tem|vende|faz)|opcoes|lista de precos|ver precos)/.test(last)
  if (pediuCat && prods.length && !out.produtos) {
    out.produtos = prods.slice(0, 10).map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', foto: (p.fotos || [])[0] || null, categoria: p.categoria }))
  }
  let reply = String(m.content || '').trim() || 'Desculpe, pode repetir?'
  if (out.produtos && out.produtos.length && /não (há|tem|existem)|nenhum produto|sem produtos|não encontrei/i.test(reply)) {
    reply = 'Aqui está o nosso catálogo. Toque em Adicionar ou Agendar para continuar.'
  }
  if (rodapeAg.length) reply += '\n\n' + [...new Set(rodapeAg)].join('\n') // regra executável "anexar"
  await registrarUso(usosAg, { canal: 'agente', businessId: id })
  if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await hit(id, 'agente', null) }
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  return { reply, produtos: out.produtos || null, pix: out.pix || null, secao: out.secao || null }
}

export async function businessHitPost(ctx: Ctx) {
  const kind = String(ctx.body?.kind || ''); if (!['whatsapp', 'instagram', 'link', 'compartilhar', 'mapa'].includes(kind)) return { ok: true }
  const b = await one('SELECT id, owner_id FROM businesses WHERE id = $1', [Number(ctx.params.id)]); if (!b) return { ok: true }
  await hit(Number(b.id), kind, ctx.user ? ctx.user.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b.owner_id))
  return { ok: true }
}
/* ---------- relatórios da empresa ---------- */
async function reportData(bid: number, dias: number) {
  const since = new Date(Date.now() - dias * 86400_000), sinceDay = since.toISOString().slice(0, 10)
  const st = await q('SELECT day, kind, n FROM business_stats WHERE business_id = $1 AND day >= $2', [bid, sinceDay])
  const tot: Record<string, number> = {}, porDia: Record<string, any> = {}
  for (const r of st) { tot[r.kind] = (tot[r.kind] || 0) + Number(r.n); (porDia[r.day] ||= {})[r.kind] = Number(r.n) }
  const orders = (await q('SELECT * FROM orders WHERE business_id = $1 AND created_at >= $2', [bid, since.toISOString()])).map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total), day: String(o.created_at).slice(0, 10) }))
  const ok = orders.filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status)))
  const fat = Math.round(ok.reduce((a, o) => a + o.total, 0) * 100) / 100
  const porPag: Record<string, number> = {}, prod: Record<string, { qtd: number; valor: number }> = {}
  for (const o of ok) { porPag[o.pagamento] = Math.round(((porPag[o.pagamento] || 0) + o.total) * 100) / 100; for (const i of o.itens || []) { const p = (prod[i.nome] ||= { qtd: 0, valor: 0 }); p.qtd += i.qtd; p.valor = Math.round((p.valor + i.qtd * i.preco) * 100) / 100 } }
  for (const o of orders) { (porDia[o.day] ||= {}).vendas = Math.round(((porDia[o.day].vendas || 0) + (ok.includes(o) ? o.total : 0)) * 100) / 100 }
  const serie = Array.from({ length: dias }, (_, i) => { const d = new Date(Date.now() - (dias - 1 - i) * 86400_000).toISOString().slice(0, 10); return { day: d, ...(porDia[d] || {}) } })
  return { dias, acessos: { impressoes: tot.impressao || 0, visitas: tot.visita || 0, contatos: (tot.whatsapp || 0) + (tot.instagram || 0) + (tot.link || 0) + (tot.mapa || 0), compartilhamentos: tot.compartilhar || 0, conversasAgente: tot.agente || 0, pedidos: tot.pedido || 0 },
    vendas: { pedidos: orders.length, concluidos: ok.length, cancelados: orders.filter((o) => ['cancelado', 'recusado'].includes(o.status)).length, faturamento: fat, ticket: ok.length ? Math.round((fat / ok.length) * 100) / 100 : 0, taxasEntrega: Math.round(ok.reduce((a, o) => a + (o.taxa || 0), 0) * 100) / 100, porPagamento: porPag, topProdutos: Object.entries(prod).sort((a, b) => b[1].valor - a[1].valor).slice(0, 5).map(([nome, v]) => ({ nome, ...v })) }, serie }
}
export async function reportGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return reportData(Number(b.id), Math.min(365, Math.max(1, Number(ctx.query.get('dias')) || 30))) }
export async function reportAiPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), x = J<any>(b.data, {}), dias = Math.min(365, Math.max(1, Number(ctx.body?.dias) || 30))
  const r = await reportData(Number(b.id), dias), f = await (await import('./modules.js')).fiscalState((ctx.user as any).id).catch(() => null)
  const { complete } = await import('../ai/provider.js')
  const m = await complete([{ role: 'system', content: 'Você é um analista de negócios que ajuda pequenos empreendedores brasileiros. Escreva em português, de forma clara e prática, com no máximo 12 linhas: resumo do período, o que entrou (faturamento, pedidos), destaques (produtos, forma de pagamento), alcance (impressões, visitas, contatos, conversão de visitas em pedidos) e 3 recomendações objetivas. Use SOMENTE os números fornecidos; não invente. Se houver dados do MEI, comente o uso do limite anual e lembre do DAS/declaração quando fizer sentido. Não dê conselho contábil definitivo.' },
    { role: 'user', content: JSON.stringify({ empresa: x.empresa, periodoDias: dias, ...r, serie: undefined, mei: f ? { faturamentoAno: f.faturamento, limite: f.limite, proximoDAS: f.proximo, valorDAS: f.das.total, declaracaoAte: f.dasn.prazo } : null }) }] as any, undefined, { task: 'analise' })
  return { texto: String(m.content || '').trim() }
}
export async function reportMeiPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), mes = /^\d{4}-\d{2}$/.test(String(ctx.body?.mes)) ? String(ctx.body.mes) : new Date().toISOString().slice(0, 7)
  const rows = await q('SELECT * FROM orders WHERE business_id = $1', [b.id])
  const valor = Math.round(rows.filter((o) => String(o.created_at).slice(0, 7) === mes).map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total) })).filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status))).reduce((a, o) => a + o.total, 0) * 100) / 100
  const d = J<any>(b.data, {}); d.meiLancado = d.meiLancado || {}; const ja = Number(d.meiLancado[mes] || 0), diff = Math.round((valor - ja) * 100) / 100
  if (diff <= 0) return { ok: true, adicionado: 0, mes, message: 'O faturamento deste mês já está lançado no MEI.' }
  const { FISCAL_USER_DEFAULT } = await import('./modules.js')
  const fz: any = { ...FISCAL_USER_DEFAULT, ...(await getUM<any>(u.id, 'fiscal', {})) }; fz.receitas = { ...(fz.receitas || {}), [mes]: Math.round(((Number(fz.receitas?.[mes]) || 0) + diff) * 100) / 100 }
  await setUM(u.id, 'fiscal', fz); d.meiLancado[mes] = valor
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, adicionado: diff, mes, message: `R$ ${diff.toFixed(2).replace('.', ',')} lançados no faturamento do MEI (${mes.split('-').reverse().join('/')}).` }
}

/* ---------- agendamentos de serviços ---------- */
const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
/** Sinal antecipado do serviço sob orçamento: valor a pagar agora e o restante (null = a combinar no orçamento). */
export function sinalOf(s: any): { valor: number; restante: number | null; texto: string } | null {
  if (s.modoPreco !== 'orcamento' || !s.sinal?.ativo) return null
  const ref = Number(s.preco) || 0
  const valor = Math.round((s.sinal.tipo === 'pct' ? ref * s.sinal.valor / 100 : Number(s.sinal.valor)) * 100) / 100
  if (!(valor > 0)) return null
  const restante = ref > 0 ? Math.round((ref - valor) * 100) / 100 : null
  const f = (n: number) => 'R$ ' + n.toFixed(2).replace('.', ',')
  return { valor, restante, texto: `Sinal de ${f(valor)}${s.sinal.tipo === 'pct' ? ` (${String(s.sinal.valor).replace('.', ',')}% do valor de referência)` : ''} pago no agendamento. Restante: ${restante !== null ? `${f(restante)} (referência ${f(ref)}, ajustado no orçamento)` : 'definido no orçamento'}.` }
}
export function servicePrice(s: any) { const si = sinalOf(s); if (si) return si.valor
  return s.modoPreco === 'orcamento' ? 0 : s.modoPreco === 'hora' ? Math.round((Number(s.preco) || 0) * ((Number(s.duracao) || 60) / 60) * 100) / 100 : Number(s.preco) || 0 }
async function freeSlots(b: any, svc: any, date: string) {
  const x = J<any>(b.data, {}), dias = x.horarioCfg?.dias
  const dow = DIAS[new Date(date + 'T12:00:00').getDay()], d = dias ? dias[dow] : { ativo: true, abre: '08:00', fecha: '18:00' }
  if (!d || !d.ativo) return []
  const dur = Number(svc.duracao) || 30, ab = toMin(d.abre), fe = toMin(d.fecha) > ab ? toMin(d.fecha) : 24 * 60
  // ocupam o horário: agendamentos novos/aceitos, Pix ainda aguardando pagamento (reserva por 30 min) e compromissos do próprio dono na Agenda
  const hold = Date.now() - 30 * 60_000
  const busy: [number, number][] = (await q("SELECT data, status, created_at FROM orders WHERE business_id = $1 AND status IN ('novo','aceito','aguardando_pagamento')", [b.id]))
    .filter((r) => r.status !== 'aguardando_pagamento' || Date.parse(String(r.created_at)) >= hold)
    .map((r) => J<any>(r.data, {})).filter((o) => o.tipo === 'agendamento' && o.data === date).map((o) => [toMin(o.hora), toMin(o.hora) + (Number(o.duracao) || 30)] as [number, number])
  busy.push(...(await ownerBusySlots(Number(b.id), date)))
  const nowBR = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), today = nowBR.toISOString().slice(0, 10), nowMin = nowBR.getHours() * 60 + nowBR.getMinutes() + 30
  const out: string[] = []
  for (let t = ab; t + dur <= fe; t += Math.min(dur, 30)) { if (date === today && t < nowMin) continue; if (busy.some(([s, e]) => t < e && t + dur > s)) continue; out.push(hhmm(t)) }
  return out
}
export async function slotsGet(ctx: Ctx) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2', [Number(ctx.query.get('servico')), b!.id]); if (!p || !allowsKind(J<any>(b!.data, {}), 'servico')) fail(404, 'Serviço não encontrado.', 'not_found')
  const date = String(ctx.query.get('data') || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) fail(400, 'Data inválida.', 'invalid')
  return { horarios: await freeSlots(b, J<any>(p!.data, {}), date) }
}
export async function bookingPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode agendar na sua própria empresa.', 'invalid')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2 AND active = $3', [Number(ctx.body?.servico), b!.id, true]); if (!p || !allowsKind(J<any>(b!.data, {}), 'servico')) fail(400, 'Serviço indisponível.', 'invalid')
  const s = J<any>(p!.data, {}), date = String(ctx.body?.data || ''), hora = String(ctx.body?.hora || '')
  return withLock(`biz:${b!.id}`, async () => { // verificação + gravação juntas: dois clientes nunca levam o mesmo horário
  if (!(await freeSlots(b, s, date)).includes(hora)) fail(409, 'Esse horário acabou de ser ocupado. Escolha outro.', 'slot_taken')
  const x = J<any>(b!.data, {}), total = servicePrice(s)
  const si = sinalOf(s)
  const data = { tipo: 'agendamento', servico: s.nome, servicoId: Number(p!.id), modoPreco: s.modoPreco, duracao: s.duracao, data: date, hora, obs: str(ctx.body?.obs, 300), cliente: str(ctx.body?.nome, 80) || u.name, telefone: str(ctx.body?.telefone, 30) || u.whatsapp, empresa: x.empresa, itens: [{ nome: si ? `Sinal · ${s.nome}` : s.nome, qtd: 1, preco: total, vars: [] }], pagamento: si && x.mpTok ? 'online' : 'local', modo: 'agendamento', motivo: '', ...(si ? { sinal: si.valor, restante: si.restante, condicoes: si.texto } : {}) }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, 'novo', total, JSON.stringify(data), nowIso()])
  const o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  let payment: any = null
  if (si && x.mpTok) { try { await createOrderPix(b, o, u.email, total); const o2 = await one('SELECT data FROM orders WHERE id = $1', [o.id]); payment = J<any>(o2!.data, {}).payment || null } catch { payment = null } }
  await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message)) // entra na Agenda do dono e bloqueia o horário
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  await notify(Number(b!.owner_id), { type: 'order', title: `Novo agendamento #${o.id}: ${s.nome}${si ? ' · sinal R$ ' + si.valor.toFixed(2).replace('.', ',') : ''}`, body: `${data.cliente} · ${date.split('-').reverse().join('/')} às ${hora}`, link: '/x/sua-empresa', ref: `booking:${o.id}` })
  return { order: { id: Number(o.id), status: 'novo', total, ...data, payment, chavePix: si && !payment ? (x.pagamento?.mostrarChave === false ? '' : x.pagamento?.chavePix || '') : '' } }
  })
}

/* ---------- agente vendedor: mostra catálogo, cria pedidos e agendamentos, gera Pix ---------- */
const AG_TOOLS = [
  { type: 'function', function: { name: 'mostrar_catalogo', description: 'Mostra ao cliente os produtos/serviços (com foto e preço) na tela. Use quando ele quiser ver o cardápio, o catálogo ou opções.', parameters: { type: 'object', properties: { categoria: { type: 'string' }, busca: { type: 'string' } } } } },
  { type: 'function', function: { name: 'mostrar_secao', description: 'Mostra na tela, dentro do chat, uma seção da empresa: mapa (localização e como chegar), horario, pagamento (formas de pagamento e entrega) ou carrinho.', parameters: { type: 'object', properties: { secao: { type: 'string', enum: ['mapa', 'horario', 'pagamento', 'carrinho'] } }, required: ['secao'] } } },
  { type: 'function', function: { name: 'criar_pedido', description: 'Cria o pedido do cliente depois que ele confirmou itens, forma de recebimento e pagamento. Gera Pix automático se ele escolher pix_online.', parameters: { type: 'object', properties: { itens: { type: 'array', items: { type: 'object', properties: { produto_id: { type: 'number' }, quantidade: { type: 'number' }, opcoes: { type: 'object', description: 'nome da variação → nome da opção escolhida' } }, required: ['produto_id'] } }, modo: { type: 'string', enum: ['retirada', 'entrega'] }, endereco: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string', description: 'WhatsApp do cliente com DDD (obrigatório)' }, pagamento: { type: 'string', enum: ['pix_online', 'pix', 'dinheiro', 'cartao'] }, precisa_troco: { type: 'boolean' }, troco_para: { type: 'string', description: 'valor para o troco, se pagar em dinheiro e precisar' }, observacao: { type: 'string' } }, required: ['itens', 'modo', 'nome', 'telefone', 'pagamento'] } } },
  { type: 'function', function: { name: 'horarios_livres', description: 'Lista horários livres de um serviço numa data (AAAA-MM-DD).', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' } }, required: ['servico_id', 'data'] } } },
  { type: 'function', function: { name: 'agendar_servico', description: 'Agenda um serviço depois que o cliente confirmou data, horário e nome. pagar_pix=true gera Pix quando o serviço tem valor.', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' }, hora: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string' }, observacao: { type: 'string' }, pagar_pix: { type: 'boolean' } }, required: ['servico_id', 'data', 'hora', 'nome'] } } },
]
async function guestOrder(b: any, data: any, total: number, wantPix: boolean) {
  const key = randomBytes(8).toString('hex')
  const zap = String(data.telefone || '').replace(/\D/g, '')
  if (zap.length < 10 || zap.length > 13) fail(400, 'Informe seu WhatsApp com DDD para a empresa falar com você.', 'invalid', 'telefone')
  // com Pix automático, o pedido só vai para a empresa depois da aprovação do Mercado Pago
  const preMp = !!(wantPix && total > 0 && J<any>(b.data, {}).mpTok)
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b.id, b.owner_id, preMp ? 'aguardando_pagamento' : 'novo', total, JSON.stringify({ ...data, guest: true, guestKey: key, canal: 'agente' }), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [b.id]))[0]
  let pix: any = null
  if (wantPix && total > 0 && J<any>(b.data, {}).mpTok) { try { await createOrderPix(b, o, '', total); o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!; const d = J<any>(o.data, {}); pix = { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt, valor: total, orderId: Number(o.id), key } } catch { await q('DELETE FROM orders WHERE id = $1', [o.id]); fail(502, 'Não foi possível gerar o Pix agora. Escolha outra forma de pagamento.', 'mp_error') } }
  if (data.tipo === 'agendamento' && !preMp) await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message))
  await hit(Number(b.id), 'pedido', null)
  if (!pix) await notify(Number(b.owner_id), { type: 'order', title: `${data.tipo === 'agendamento' ? 'Novo agendamento' : 'Novo pedido'} #${o.id} pelo agente · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente}${data.telefone ? ' · ' + data.telefone : ''}${pix ? ' · Pix gerado' : ''}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  return { id: Number(o.id), key, pix }
}
export async function runAgentTool(b: any, name: string, a: any, out: any) {
  const x = J<any>(b.data, {}), prods = (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut).filter(inOp(x))
  if (name === 'criar_pedido' && !allowsKind(x, 'produto')) return { ok: false, erro: 'Esta empresa trabalha só com serviços: não há pedidos de produtos. Ofereça um agendamento.' }
  if ((name === 'horarios_livres' || name === 'agendar_servico') && !allowsKind(x, 'servico')) return { ok: false, erro: 'Esta empresa não faz agendamentos de serviços. Ofereça o catálogo de produtos.' }
  if (name === 'mostrar_catalogo') {
    if (!prods.length) { out.produtos = []; return { ok: true, total: 0, mensagem: 'A loja ainda não tem produtos ou serviços publicados. Diga isso ao cliente com clareza e ofereça o WhatsApp.' } }
    // palavras genéricas não filtram nada ("catálogo", "todos", "produtos"…): só nome, categoria ou descrição reais
    const GEN = new Set(['catalogo', 'cardapio', 'menu', 'todos', 'todas', 'tudo', 'produtos', 'produto', 'servicos', 'servico', 'opcoes', 'itens', 'geral', 'loja', 'ver', 'mostrar', 'de', 'do', 'da', 'o', 'a', 'os', 'as'])
    const words = nrm(`${a.categoria || ''} ${a.busca || ''}`).split(/[^a-z0-9]+/).filter((w) => w.length > 1 && !GEN.has(w))
    const hay = (p: any) => nrm(`${p.nome} ${p.categoria} ${p.descricao || ''} ${p.palavras || ''}`)
    let list = words.length ? prods.filter((p: any) => words.some((w) => hay(p).includes(w))) : prods
    const filtrou = words.length > 0
    if (!list.length) list = prods // nada bateu com o filtro: mostra o catálogo inteiro em vez de dizer que não há produtos
    list = list.slice(0, 12)
    out.produtos = list.map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', foto: (p.fotos || [])[0] || null, categoria: p.categoria }))
    return { ok: true, total: prods.length, mostrados: out.produtos.map((p: any) => `${p.nome} (id ${p.id}, R$ ${Number(p.preco).toFixed(2).replace('.', ',')})`), aviso: filtrou && list.length === prods.slice(0, 12).length && !words.some((w) => list.some((p: any) => hay(p).includes(w))) ? 'Nenhum item corresponde exatamente ao pedido; mostrei o catálogo completo.' : undefined, instrucao: 'Os cartões com fotos, preços e botões já estão na tela. Não diga que não há produtos.' }
  }
  if (name === 'mostrar_secao') { out.secao = ['mapa', 'horario', 'pagamento', 'carrinho'].includes(a.secao) ? a.secao : 'mapa'; return { ok: true, mostrado: out.secao } }
  if (!openState(x).aberto && name !== 'horarios_livres') return { ok: false, erro: 'A empresa está fechada agora; não é possível concluir pedidos neste momento.' }
  if (name === 'criar_pedido') {
    const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
    const linhas: any[] = []
    for (const it of Array.isArray(a.itens) ? a.itens.slice(0, 30) : []) {
      const p: any = prods.find((y: any) => y.id === Number(it.produto_id)); if (!p || p.tipo === 'servico') return { ok: false, erro: `Produto ${it.produto_id} não existe no catálogo.` }
      const esc: Record<string, number> = {}
      for (const v of p.variacoes || []) { const want = nrm(String(it.opcoes?.[v.nome] || '')); const i = v.opcoes.findIndex((o: any) => nrm(o.nome) === want); esc[v.nome] = i >= 0 ? i : 0 }
      const qtd = Math.min(50, Math.max(1, Math.floor(Number(it.quantidade) || 1))), preco = unitPrice(p, esc)
      linhas.push({ pid: p.id, nome: p.nome, qtd, preco, vars: (p.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[esc[v.nome]].nome}`), obs: '' })
    }
    if (!linhas.length) return { ok: false, erro: 'O pedido está sem itens.' }
    const modo = a.modo === 'entrega' ? 'entrega' : 'retirada'
    if (modo === 'entrega' && !E.entrega) return { ok: false, erro: 'A loja não faz entrega; ofereça retirada.' }
    if (modo === 'entrega' && String(a.endereco || '').length < 6) return { ok: false, erro: 'Peça o endereço completo de entrega.' }
    if (modo === 'entrega' && E.modoTaxa === 'km') return { ok: false, erro: 'A taxa desta loja é por distância: oriente o cliente a finalizar pelo link da loja para calcular a entrega.' }
    const sub = Math.round(linhas.reduce((s2, l) => s2 + l.preco * l.qtd, 0) * 100) / 100
    if (E.minimo && sub < E.minimo) return { ok: false, erro: `Pedido mínimo de R$ ${E.minimo}.` }
    const pg = a.pagamento === 'pix_online' ? 'online' : a.pagamento
    if (!['online', 'pix', 'dinheiro', 'cartao'].includes(pg) || (pg === 'online' ? !(P.online && x.mpTok) : !P[pg])) return { ok: false, erro: `Forma de pagamento indisponível. Aceitas: ${[P.online && x.mpTok ? 'pix_online' : '', P.pix ? 'pix' : '', P.dinheiro ? 'dinheiro' : '', P.cartao ? 'cartao' : ''].filter(Boolean).join(', ')}.` }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0, total = Math.round((sub + taxa) * 100) / 100
    { const zd = String(a.telefone || '').replace(/\D/g, ''); if (zd.length < 10 || zd.length > 13) return { ok: false, erro: 'Peça o WhatsApp do cliente com DDD antes de finalizar o pedido.' } }
    if (pg === 'dinheiro' && (a.precisaTroco ?? a.precisa_troco) === undefined && !a.trocoPara && !a.troco_para) a.precisaTroco = false
    const troco = pg === 'dinheiro' ? trocoTxt({ precisaTroco: a.precisaTroco ?? a.precisa_troco, trocoPara: a.trocoPara ?? a.troco_para }, total) : ''
    const r = await guestOrder(b, { itens: linhas, subtotal: sub, taxa, modo, endereco: modo === 'entrega' ? str(a.endereco, 200) : '', pagamento: pg, troco, obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, motivo: '' }, total, pg === 'online')
    if (r.pix) out.pix = r.pix
    return { ok: true, pedido: r.id, total, pix_gerado: !!r.pix, mensagem: r.pix ? 'Pix gerado e mostrado na tela; o cliente pode pagar pelo QR Code ou copia e cola.' : 'Pedido enviado para a loja.' }
  }
  if (name === 'horarios_livres' || name === 'agendar_servico') {
    const sv: any = prods.find((y: any) => y.id === Number(a.servico_id) && y.tipo === 'servico'); if (!sv) return { ok: false, erro: 'Serviço não encontrado.' }
    const date = String(a.data || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, erro: 'Data no formato AAAA-MM-DD.' }
    const livres = await freeSlots(b, sv, date)
    if (name === 'horarios_livres') return { ok: true, livres: livres.slice(0, 24) }
    return withLock(`biz:${b.id}`, async () => { // verificação + gravação juntas (sem reserva duplicada)
    const livres2 = await freeSlots(b, sv, date)
    if (!livres2.includes(String(a.hora))) return { ok: false, erro: 'Horário indisponível.', livres: livres2.slice(0, 12) }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const total = servicePrice(sv)
      const si = sinalOf(sv), pix = !!a.pagar_pix || (!!si && !!x.mpTok)
    { const zd = String(a.telefone || '').replace(/\D/g, ''); if (zd.length < 10 || zd.length > 13) return { ok: false, erro: 'Peça o WhatsApp do cliente com DDD antes de agendar.' } }
    const r = await guestOrder(b, { tipo: 'agendamento', servico: sv.nome, servicoId: sv.id, modoPreco: sv.modoPreco, duracao: sv.duracao, data: date, hora: String(a.hora), obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, itens: [{ nome: si ? `Sinal · ${sv.nome}` : sv.nome, qtd: 1, preco: total, vars: [] }], pagamento: pix ? 'online' : 'local', modo: 'agendamento', motivo: '', ...(si ? { sinal: si.valor, restante: si.restante, condicoes: si.texto } : {}) }, total, pix)
    if (r.pix) out.pix = r.pix
    return { ok: true, agendamento: r.id, total, pix_gerado: !!r.pix }
    })
  }
  return { ok: false, erro: 'Ferramenta desconhecida.' }
}
export async function agentOrderGet(ctx: Ctx) {
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), Number(ctx.params.id)])
  const d = o ? J<any>(o.data, {}) : null
  if (!o || !d.guest || d.guestKey !== String(ctx.query.get('k') || '')) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown')
  return { status: o!.status, pago: st === 'approved' || !!d.pago }
}

/* ---------- página do agente: tudo dentro do chat (catálogo, mapa, horário, pagamento, pedido, agendamento, Pix) ---------- */
function agentLimit(ctx: Ctx, id: number, max = 20) {
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `act:${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= max) fail(429, 'Muitas ações seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
}
export async function agentInfoGet(ctx: Ctx) {
  const { b, x } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x), ps = await plans(), n = nivelOf(ps, b.plan_id)
  const prods = n >= 4 ? (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut).filter(inOp(x)).map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, descricao: p.descricao || '', categoria: p.categoria || 'Outros', foto: (p.fotos || [])[0] || null, variacoes: p.variacoes || [], tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', duracao: p.duracao || 0, tags: p.tags || [], sinal: sinalOf(p) })) : []
  const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, chavePix: '', cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  return { tema: normalizeTema(x.tema), empresa: x.empresa, categoria: x.categoria, sobre: x.sobre || x.texto || '', endereco: x.endereco || '', lat: b.lat, lng: b.lng, aberto: st.aberto, situacao: st.texto, dias: x.horarioCfg?.dias || null, horario: x.horario || '',
    telefone: (() => { const raw = String(x.contato || '').match(/[\d()+\s-]{10,}/)?.[0] || x.zap || ''; const dg = String(raw).replace(/\D/g, ''); return dg.length >= 10 && dg.length <= 13 ? (dg.length <= 11 ? '+55' + dg : '+' + dg) : null })(), // número do perfil da empresa, pronto para discar
    loja: n >= 4, produtos: prods, categorias: x.categorias || [], etiquetas: x.etiquetas || [], zap: x.zap || null, insta: x.insta || null,
    entrega: { retirada: E.retirada !== false, entrega: !!E.entrega && E.modoTaxa !== 'km', porKm: E.modoTaxa === 'km', taxa: Number(E.taxa) || 0, raio: E.raio, minimo: Number(E.minimo) || 0, tempo: E.tempo || '' },
    pagamento: { online: !!(P.online && x.mpTok), pix: !!P.pix, chavePix: P.chavePix || '', cartao: !!P.cartao, dinheiro: !!P.dinheiro } }
}
export async function agentOrderPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'criar_pedido', ctx.body || {}, out)
  if (!r.ok) fail(400, r.erro || 'Não foi possível criar o pedido.', 'invalid')
  return { ...r, pix: out.pix || null }
}
export async function agentSlotsGet(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 40)
  const r: any = await runAgentTool(b, 'horarios_livres', { servico_id: Number(ctx.query.get('servico')), data: String(ctx.query.get('data') || '') }, {})
  if (!r.ok) fail(400, r.erro, 'invalid'); return { horarios: r.livres }
}
export async function agentBookingPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'agendar_servico', ctx.body || {}, out)
  if (!r.ok) fail(400, r.erro || 'Não foi possível agendar.', 'invalid')
  return { ...r, pix: out.pix || null }
}

/* ---------- avaliações ---------- */
/** Cliente avalia um pedido concluído ou um agendamento realizado (uma avaliação por pedido). */
export async function orderReviewPost(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [id, u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  if (o!.status !== 'concluido') fail(400, 'Você pode avaliar quando o pedido for concluído ou o agendamento realizado.', 'invalid')
  const d = J<any>(o!.data, {}); if (d.guest) fail(400, 'Pedido inválido.', 'invalid')
  const rating = Math.round(Number(ctx.body?.rating)); if (!(rating >= 1 && rating <= 5)) fail(400, 'Escolha de 1 a 5 estrelas.', 'invalid')
  if (await one('SELECT id FROM reviews WHERE order_id = $1', [id])) fail(409, 'Você já avaliou este pedido.', 'already')
  await q('INSERT INTO reviews (business_id, user_id, order_id, origem, rating, comment, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [o!.business_id, u.id, id, 'cliente', rating, str(ctx.body?.comment, 400), nowIso()])
  await refreshRatings(true)
  await notify(Number((await one('SELECT owner_id FROM businesses WHERE id = $1', [o!.business_id]))!.owner_id), { type: 'order', title: `Nova avaliação: ${'★'.repeat(rating)}${'☆'.repeat(5 - rating)}`, body: str(ctx.body?.comment, 120) || `Pedido #${id}`, link: '/x/sua-empresa', ref: `review:${id}` })
  return { ok: true, avaliacao: ratingOf(Number(o!.business_id)) }
}
/** Pedidos do cliente: quais já foram avaliados. */
export async function myReviewsGet(ctx: Ctx) { const u = requireUser(ctx); return { orders: (await q('SELECT order_id, rating FROM reviews WHERE user_id = $1 AND order_id IS NOT NULL', [u.id])).map((r) => ({ orderId: Number(r.order_id), rating: Number(r.rating) })) } }
/** Administrador atribui nota a uma empresa (uma nota por administrador e empresa). */
export async function adminRatingPut(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  const id = Number(ctx.params.id), rating = Math.round(Number(ctx.body?.rating))
  if (!(await one('SELECT id FROM businesses WHERE id = $1', [id]))) fail(404, 'Empresa não encontrada.', 'not_found')
  await q("DELETE FROM reviews WHERE business_id = $1 AND origem = 'admin' AND user_id = $2", [id, u.id])
  if (rating >= 1 && rating <= 5) await q('INSERT INTO reviews (business_id, user_id, origem, rating, comment, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [id, u.id, 'admin', rating, str(ctx.body?.comment, 400), nowIso()])
  await refreshRatings(true)
  return { ok: true, avaliacao: ratingOf(id) }
}
export async function adminRatingsGet(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  await refreshRatings(true)
  const mine = new Map((await q("SELECT business_id, rating FROM reviews WHERE origem = 'admin' AND user_id = $1", [u.id])).map((r) => [Number(r.business_id), Number(r.rating)]))
  return { items: (await q("SELECT id, data, status FROM businesses WHERE status IN ('ativo','aprovado') ORDER BY id DESC")).map((b) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa, status: b.status, avaliacao: ratingOf(Number(b.id)), minha: mine.get(Number(b.id)) || 0 })) }
}

/* ---------- endereço amigável do assistente: domínio oficial + /g-<nome-da-empresa> ---------- */
import { slugify } from '../lib/publicurl.js'
/** Garante um identificador único para a empresa (gerado do nome; só muda se o dono trocar o nome). */
export async function ensureSlug(id: number): Promise<string> {
  const b = await one('SELECT id, data FROM businesses WHERE id = $1', [id]); if (!b) return ''
  const x = J<any>(b.data, {}), base = slugify(x.empresa || '')
  if (x.slug && (x.slugBase === base || !x.slugBase)) return x.slug
  const usados = new Set((await q('SELECT id, data FROM businesses WHERE id <> $1', [id])).map((r) => J<any>(r.data, {}).slug).filter(Boolean))
  let slug = base, n = 2
  while (usados.has(slug)) slug = `${base}-${n++}`
  if (x.slug && x.slug !== slug) x.slugsAntigos = [...new Set([...(x.slugsAntigos || []), x.slug])].slice(-10) // links antigos continuam abrindo
  x.slug = slug; x.slugBase = base
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  return slug
}
export async function slugOfId(id: number) { return (await one('SELECT id FROM businesses WHERE id = $1', [id])) ? ensureSlug(id) : null }
export async function idOfSlug(slug: string) {
  for (const r of await q('SELECT id, data FROM businesses')) { const x = J<any>(r.data, {}); if (x.slug === slug || (x.slugsAntigos || []).includes(slug)) return Number(r.id) }
  // empresas antigas sem identificador: gera na primeira visita
  for (const r of await q('SELECT id, data FROM businesses')) { const x = J<any>(r.data, {}); if (!x.slug && slugify(x.empresa || '') === slug) { await ensureSlug(Number(r.id)); return Number(r.id) } }
  return null
}
export const agentLink = async (id: number) => `${pub()}/g-${await ensureSlug(id)}`

/* ---------- e-mails da empresa: remetente, resposta, SMTP próprio (opcional) e modelos ---------- */
export async function bizEmailPut(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, M = await import('../lib/mail.js'), { seal } = await import('../lib/settings.js')
  const x = J<any>(b.data, {}), cur = x.email || {}
  const remetenteEmail = String(body.remetenteEmail ?? cur.remetenteEmail ?? '').trim().toLowerCase(), responderPara = String(body.responderPara ?? cur.responderPara ?? '').trim().toLowerCase()
  if (remetenteEmail && !M.validEmail(remetenteEmail)) fail(400, 'E-mail do remetente inválido.', 'invalid')
  if (responderPara && !M.validEmail(responderPara)) fail(400, 'E-mail para respostas inválido.', 'invalid')
  const smtp = body.smtp ? { host: str(body.smtp.host, 120), port: Math.min(65535, Math.max(1, Number(body.smtp.port) || 465)), seguranca: ['ssl', 'starttls', 'nenhuma'].includes(body.smtp.seguranca) ? body.smtp.seguranca : 'ssl', usuario: str(body.smtp.usuario, 160), senha: body.smtp.senha ? await seal(String(body.smtp.senha)) : cur.smtp?.senha || '' } : cur.smtp
  const tpl: any = {}; for (const k of ['pedidos', 'comunicados']) if (body.templates?.[k]) tpl[k] = { assunto: str(body.templates[k].assunto, 200), corpo: str(body.templates[k].corpo, 6000) }
  x.email = { remetenteNome: str(body.remetenteNome ?? cur.remetenteNome, 80), remetenteEmail, responderPara, smtpProprio: body.smtpProprio === undefined ? !!cur.smtpProprio : !!body.smtpProprio, smtp, limiteHora: Math.max(1, Math.round(Number(body.limiteHora ?? cur.limiteHora) || 30)), limiteDia: Math.max(1, Math.round(Number(body.limiteDia ?? cur.limiteDia) || 150)) }
  if (Object.keys(tpl).length) x.emailTemplates = { ...(x.emailTemplates || {}), ...tpl }
  if (x.email.smtpProprio && (!x.email.smtp?.host || !remetenteEmail)) fail(400, 'Para usar o SMTP próprio, preencha servidor e e-mail do remetente.', 'invalid')
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), b.id])
  return bizEmailView(x)
}
const bizEmailView = (x: any) => ({ email: { ...(x.email || {}), smtp: x.email?.smtp ? { ...x.email.smtp, senha: '', temSenha: !!x.email.smtp.senha } : null }, templates: x.emailTemplates || {} })
export async function bizEmailPost(ctx: Ctx) {
  const { b, u } = await ownBusiness(ctx) as any, M = await import('../lib/mail.js')
  if (ctx.body?.action === 'testar') return M.testConnection(Number(b.id))
  if (ctx.body?.action === 'ver') return bizEmailView(J<any>(b.data, {}))
  if (ctx.body?.action === 'enviar_teste') { const to = String(ctx.body?.to || u?.email || ''); const r = await M.enqueueMail({ kind: 'teste', to, businessId: Number(b.id), dedupe: `teste:b${b.id}:${Date.now()}` }); if (!r.queued) fail(400, 'Não foi para a fila: ' + r.motivo, 'invalid'); return { ok: true, id: r.id } }
  fail(400, 'Ação inválida.', 'invalid')
}

/** Tema da empresa (rota leve usada para manter catálogo e agente sincronizados; não conta como visita). */
export async function themeGet(ctx: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const dono = !!(ctx.user && b && Number(b.owner_id) === Number(ctx.user.id))
  if (!b || (b.status !== 'ativo' && !dono)) fail(404, 'Empresa não encontrada.', 'not_found')
  return { tema: normalizeTema(J<any>(b!.data, {}).tema) }
}
