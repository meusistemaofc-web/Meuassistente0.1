import { gestaoLiberada } from '../lib/painel-empresa.js'
import { validCoords } from '../lib/geocode.js'
import { registrarUso, type Uso } from '../ai/brain-usage.js'
import { withLock, registerBookingInAgenda, syncBookingStatus, ownerBusySlots, recordOrderIncome } from '../lib/business-sync.js'
import { normalizeTema } from '../lib/theme.js'
import { diaEfetivo, calcularHorarios, calendarioDe } from '../lib/calendar.js'
import { acesso, paCfg, validarAgendadoPara, avisarResponsaveis, historico, brDia, ROTULO } from '../lib/perm-agenda.js'
import { audit } from '../lib/account.js'
import { pub } from '../lib/publicurl.js'
import { once, canon } from '../ai/once.js'
import { randomBytes, createHmac, createHash } from 'node:crypto'
import * as CAT from '../lib/catalogo.js'
import * as D from '../db/index.js'
import * as MPR from '../lib/mensagem-pronta.js'
// Empresas parceiras: busca por ramo e distância (com permissão de localização), página da empresa,
// loja com produtos/variações e pedidos (plano Loja completa) que chegam em Sua empresa.
import type { Ctx } from '../lib/http.js'
import { fail, str, HttpError } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { config } from '../config.js'
import { pixExpiry, pixValid } from '../lib/pix.js'
import { notify } from '../lib/notify.js'
import { getUM, setUM, requireModule, modules } from '../lib/usermod.js'
import { PLANS_DEFAULT, SEARCH_DEFAULT } from '../lib/panel-defaults.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set(['perto', 'proximo', 'proxima', 'quero', 'procuro', 'onde', 'tem', 'uma', 'um', 'mim', 'aqui', 'minha', 'meu', 'de', 'da', 'do', 'com', 'para', 'tem', 'algum', 'alguma', 'uns', 'umas', 'os', 'as', 'no', 'na'])
/* ---------- estatísticas de acesso ---------- */
const seen = new Set<string>()
const dayBR = () => new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10)
export async function hit(bid: number, kind: string, viewer?: string | number | null, ownerId?: number | null) {
  try {
    if (ownerId != null && viewer != null && String(viewer) === String(ownerId)) return // o dono não conta
    const day = dayBR()
    if (viewer != null && kind !== 'agente' && kind !== 'pedido') { const k = `${bid}:${kind}:${viewer}:${day}`; if (seen.has(k)) return; if (seen.size > 200000) seen.clear(); seen.add(k) }
    await q('INSERT INTO business_stats (business_id, day, kind, n) VALUES ($1,$2,$3,1) ON CONFLICT (business_id, day, kind) DO UPDATE SET n = business_stats.n + 1', [bid, day, kind])
  } catch (e: any) { console.error('[stats]', e?.message) }
}
/** hit() para várias empresas de uma vez (impressões de uma lista): as mesmas regras, numa gravação só. */
export async function hits(lista: { bid: number; owner?: number | null }[], kind: string, viewer?: string | number | null) {
  try {
    const day = dayBR(), bids: number[] = []
    for (const { bid, owner } of lista) {
      if (owner != null && viewer != null && String(viewer) === String(owner)) continue // o dono não conta
      if (viewer != null && kind !== 'agente' && kind !== 'pedido') { const k = `${bid}:${kind}:${viewer}:${day}`; if (seen.has(k)) continue; if (seen.size > 200000) seen.clear(); seen.add(k) }
      if (!bids.includes(bid)) bids.push(bid)
    }
    if (!bids.length) return
    await q(`INSERT INTO business_stats (business_id, day, kind, n) VALUES ${bids.map((_, i) => `($${i + 3},$1,$2,1)`).join(',')} ON CONFLICT (business_id, day, kind) DO UPDATE SET n = business_stats.n + 1`, [day, kind, ...bids])
  } catch (e: any) { console.error('[stats]', e?.message) }
}
/** Taxa de entrega: fixa, ou por distância (grátis até X km; acima, taxa de saída + valor por km excedente). */
export function deliveryFee(E: any, km: number) {
  if (E.modoTaxa !== 'km') return Number(E.taxa) || 0
  if (km <= (Number(E.kmGratis) || 0)) return 0
  return Math.round(((Number(E.taxaExcedente) || 0) + (Number(E.taxaKm) || 0) * (km - (Number(E.kmGratis) || 0))) * 100) / 100
}
export function distKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371, t = (x: number) => (x * Math.PI) / 180, dl = t(b.lat - a.lat), dn = t(b.lng - a.lng)
  const h = Math.sin(dl / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dn / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}
async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const nivelOf = (ps: any[], id: string) => (ps.find((p) => p.id === id) || {}).nivel || 1
async function activeRows() { return q("SELECT * FROM businesses WHERE status = 'ativo' AND (expires_at IS NULL OR expires_at > $1)", [nowIso()]) }
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']
const SERV_RE = /(barbear|salao|salão|cabel|manicure|pedicure|unha|estetic|estétic|clinic|clínic|consult|dentist|odonto|psicolog|terap|fisio|nutri|medic|médic|veterin|pet ?shop|banho e tosa|personal|academia|aula|curso|advog|contab|oficina|mecanic|mecânic|tatu|tattoo|piercing|fotograf|massag|spa|depila|sobrancel|cilios|cílios|maquiag|lavagem|lava ?jato|eletricist|encanad|diarista|limpeza|conserto|assistencia|assistência|studio|estúdio)/i
/** Modalidade EXCLUSIVA do catálogo: 'produtos' OU 'servicos' — nunca as duas (coluna businesses.modalidade; data.tipo é o espelho
 *  gravado junto, ver lib/modalidade.ts). Sem escolha registrada (não deveria ocorrer após a migração 039): critério do ramo. */
export const opTipo = (x: any): 'produtos' | 'servicos' => (x?.tipo === 'produtos' || x?.tipo === 'servicos' ? x.tipo : nicheType(x))
export const allowsKind = (x: any, kind: string) => (kind === 'servico' ? opTipo(x) === 'servicos' : opTipo(x) === 'produtos')
const inOp = (x: any) => (p: any) => allowsKind(x, p.tipo === 'servico' ? 'servico' : 'produto')
export const nicheType = (x: any): 'produtos' | 'servicos' => (x?.tipo === 'produtos' || x?.tipo === 'servicos' ? x.tipo : SERV_RE.test(`${x?.categoria || ''} ${x?.tags || ''}`) ? 'servicos' : 'produtos')
/** Dinheiro: "precisa de troco?" → troco para quanto (não pode ser menor que o total). */
function trocoTxt(body: any, total: number) {
  if (body.precisaTroco === false) return 'sem troco'
  const raw = String(body.trocoPara ?? body.troco ?? '').replace(/[^0-9,.]/g, '')
  if (!raw) return body.precisaTroco ? (fail(400, 'Informe para quanto precisa de troco.', 'invalid') as any) : ''
  const v = Number(raw.includes(',') ? raw.replace(/\./g, '').replace(',', '.') : raw)
  if (!(v > 0)) fail(400, 'Valor do troco inválido.', 'invalid')
  if (v < total) fail(400, `O troco precisa ser para um valor maior que o total (R$ ${total.toFixed(2).replace('.', ',')}).`, 'invalid')
  return `R$ ${v.toFixed(2).replace('.', ',')}`
}
export function openState(x: any, agora: Date = new Date()): { aberto: boolean; texto: string } {
  const h = x.horarioCfg
  if (!h) return { aberto: true, texto: x.horario || '' }
  if (h.modo === 'aberto') return { aberto: true, texto: 'Aberto agora' }
  if (h.modo === 'fechado') return { aberto: false, texto: 'Fechado no momento' }
  // hora local da empresa
  const tz = (() => { try { const z = String(x.fuso || x.timezone || 'America/Sao_Paulo'); new Intl.DateTimeFormat('en-US', { timeZone: z }); return z } catch { return 'America/Sao_Paulo' } })()
  const now = new Date(agora.toLocaleString('en-US', { timeZone: tz }))
  const hm = now.getHours() * 60 + now.getMinutes(), wd = now.getDay()
  const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return (a || 0) * 60 + (b || 0) }
  // calendário (feriado decidido, exceção ou horário especial de HOJE) vale mais que o horário semanal; sem calendário nada muda
  const hojeISO = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
  let HD = h.dias
  const efHoje = x.calendario ? diaEfetivo(x, hojeISO) : null
  if (efHoje && efHoje.origem !== 'semana') HD = { ...(h.dias || {}), [DIAS[wd]]: { ativo: efHoje.aberto, abre: efHoje.abre || '00:00', fecha: efHoje.fecha || '00:00' } }
  const dia = (k: number) => { const d = HD?.[DIAS[(k + 7) % 7]]; return d && d.ativo ? { ab: toMin(d.abre), fe: toMin(d.fecha), abre: d.abre, fecha: d.fecha } : null }
  const vira = (d: { ab: number; fe: number }) => d.fe <= d.ab // expediente que atravessa a meia-noite (ex.: 08:00 → 00:30)
  // 1) expediente que começou ontem e ainda não fechou (ex.: quarta 08:00 → quinta 00:30; agora quinta 00:06)
  const ontem = dia(wd - 1)
  if (ontem && vira(ontem) && hm < ontem.fe) return { aberto: true, texto: `Aberto até ${ontem.fecha}` }
  // 2) expediente de hoje
  const hoje = dia(wd)
  if (hoje && (vira(hoje) ? hm >= hoje.ab : hm >= hoje.ab && hm < hoje.fe)) {
    const pausa = efHoje?.intervalos.find((i) => hm >= toMin(i.ini) && hm < toMin(i.fim))
    if (pausa) return { aberto: false, texto: `Em intervalo · volta às ${pausa.fim}` }
    return { aberto: true, texto: `Aberto até ${hoje.fecha}` }
  }
  // 3) fechado: próximo horário de abertura configurado
  if (hoje && hm < hoje.ab) return { aberto: false, texto: `Fechado · abre hoje às ${hoje.abre}` }
  const NOME = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb']
  for (let k = 1; k <= 7; k++) { const d = dia(wd + k); if (d) return { aberto: false, texto: `Fechado · abre ${k === 1 ? 'amanhã' : NOME[(wd + k) % 7]} às ${d.abre}` } }
  return { aberto: false, texto: 'Fechado' }
}
/** Etiqueta do produto: só uma, que exista na empresa e combine com o tipo (produto/serviço). */
export function validTags(x: any, tags: any, tipo: string) {
  const ids = (Array.isArray(tags) ? tags : []).map((t: any) => String(t || '').slice(0, 12)).filter(Boolean)
  const ok = ids.filter((id: string) => (x.etiquetas || []).some((e: any) => e.id === id && (!e.tipo || e.tipo === 'ambos' || e.tipo === (tipo === 'servico' ? 'servico' : 'produto'))))
  return ok.slice(-1)
}
let RATINGS = new Map<number, { avg: number; count: number }>(), ratingsAt = 0
export async function refreshRatings(force = false) {
  if (!force && Date.now() - ratingsAt < 60_000) return
  ratingsAt = Date.now()
  try { const m = new Map<number, { avg: number; count: number }>(); for (const r of await q('SELECT business_id, AVG(rating) AS avg, COUNT(*) AS n FROM reviews GROUP BY business_id')) m.set(Number(r.business_id), { avg: Math.round(Number(r.avg) * 10) / 10, count: Number(r.n) }); RATINGS = m } catch { /* tabela ainda não criada */ }
}
export const ratingOf = (id: number) => RATINGS.get(Number(id)) || null
function card(b: any, n: number, d: number | null) {
  const x = J<any>(b.data, {}), st = openState(x)
  return { id: Number(b.id), empresa: x.empresa, categoria: x.categoria, titulo: x.titulo, texto: x.texto, logo: x.logo || null, nivel: n, distancia: d,
    zap: n >= 2 ? x.zap || null : null, insta: n >= 2 ? x.insta || null : null, link: x.link || null, temPagina: n >= 3, temLoja: n >= 4, capa: x.capa || null, aberto: st.aberto, situacao: st.texto, avaliacao: ratingOf(Number(b.id)), descricao: String(x.titulo || x.texto || x.sobre || '').slice(0, 90) }
}
/* ---------- Reconhecimento de palavras-chave (fonte única: página "Empresas parceiras", chat e agente) ----------
   Termos de cada empresa: palavras-chave cadastradas (no anúncio e nos itens da modalidade atual), categoria/ramo, tags,
   nome e título. Comparação sem maiúsculas/acentos/espaços extras, por PALAVRA INTEIRA (singular/plural e "-ria":
   pizza ↔ pizzaria), e expressões compostas pela sequência completa ("banho e tosa"). Nunca por pedaço de palavra
   ("pier" não acha "piercing"). Cada termo tem um peso; a relevância ordena os resultados. */
const STOP_BUSCA = new Set([...STOP, 'fazer', 'faco', 'faz', 'preciso', 'precisando', 'queria', 'gostaria', 'quer', 'alguem', 'empresa', 'empresas', 'lugar', 'lugares', 'hoje', 'agora', 'bom', 'boa', 'bons', 'boas', 'mais', 'que', 'qual', 'quais', 'como', 'ver', 'achar', 'encontrar', 'buscar', 'procurar', 'indica', 'indicacao', 'me', 'eu', 'voce', 'vc', 'por', 'favor', 'em', 'e', 'ou', 'o', 'a', 'ao', 'aos', 'dos', 'das', 'nos', 'nas', 'pra', 'pro', 'sobre', 'tenho', 'ter', 'esta', 'estou', 'muito', 'melhor', 'barato', 'barata', 'servico', 'servicos'])
const stemW = (w: string) => { let x = w; if (x.length > 3 && x.endsWith('s')) x = x.slice(0, -1); if (x.length > 5 && x.endsWith('ria')) x = x.slice(0, -3); return x }
const toksB = (t: string) => norm(t).split(' ').filter(Boolean).map(stemW)
type Termo = { orig: string; t: string[]; peso: number }
/** Termos pesquisáveis de uma empresa (dados do cadastro real; itens só da modalidade atual). */
export function termosEmpresa(x: any, itens: any[] = []): Termo[] {
  const out: Termo[] = [], add = (orig: unknown, peso: number) => { const o = String(orig || '').trim(); const t = toksB(o).filter((w) => !STOP_BUSCA.has(w)); if (o && t.length) out.push({ orig: o, t, peso }) }
  const lista = (v: unknown) => String(v || '').split(/[,;\n]/)
  lista(x.palavras).forEach((k) => add(k, 3)) // palavras-chave cadastradas pela empresa
  add(x.categoria, 2); lista(x.tags).forEach((k) => add(k, 2))
  add(x.empresa, 1); add(x.titulo, 1)
  for (const p of itens.filter(inOp(x))) { lista(p.palavras).forEach((k) => add(k, 3)); add(p.categoria, 2); add(p.nome, 2) }
  return out
}
/** Relevância da consulta para a empresa (0 = sem relação) e o termo reconhecido (como está no cadastro). */
export function relevancia(q0: string, termos: Termo[]): { score: number; termo: string; peso: number } {
  const qs = toksB(q0), sig = new Set(qs.filter((w) => w.length >= 3 && !STOP_BUSCA.has(w)))
  let score = 0, termo = '', melhor = 0, peso = 0
  for (const tm of termos) {
    let pts = 0
    // expressão completa, na ordem, como palavras inteiras
    outer: for (let i = 0; i + tm.t.length <= qs.length; i++) { for (let j = 0; j < tm.t.length; j++) if (qs[i + j] !== tm.t[j]) continue outer; pts = tm.peso * (1 + 0.5 * (tm.t.length - 1)); break }
    // parte significativa de uma expressão composta, palavra inteira: "tosa" → "banho e tosa"; "Pierre" → "Pierre Modas"
    if (!pts && tm.t.length > 1 && tm.t.some((w) => w.length >= (tm.peso >= 2 ? 4 : 5) && sig.has(w))) pts = tm.peso * 0.5
    if (pts) { score += pts; if (pts > melhor) { melhor = pts; termo = tm.orig; peso = tm.peso } }
  }
  return { score, termo: peso >= 2 ? termo.toLowerCase() : termo, peso }
}
/** Compatibilidade: consulta sem palavras significativas lista tudo (página de empresas sem filtro). */
export function matches(q0: string, b: any, itens: any[] | string = []) {
  if (![...new Set(toksB(q0))].some((w) => w.length >= 3 && !STOP_BUSCA.has(w))) return true
  return relevancia(q0, termosEmpresa(J<any>(b.data, {}), Array.isArray(itens) ? itens : [])).score > 0
}
async function itensPorEmpresa() {
  const m = new Map<number, any[]>()
  for (const r of await q('SELECT business_id, data FROM products WHERE active = $1', [true])) { const k = Number(r.business_id); m.set(k, [...(m.get(k) || []), J<any>(r.data, {})]) }
  return m
}
export async function searchBusinesses(text: string, loc: { lat: number; lng: number; raio?: number | null } | null, limite = 30) {
  await refreshRatings()
  const ps = await plans(), admMax = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(admMax, loc?.raio || admMax)
  const out: any[] = [], semFiltro = ![...new Set(toksB(text))].some((w) => w.length >= 3 && !STOP_BUSCA.has(w))
  const itens = await itensPorEmpresa() // palavras dos produtos/serviços publicados (nome, categoria e palavras-chave) também encontram a empresa
  for (const b of await activeRows()) { // só anúncios aprovados, no ar e dentro da validade
    const r = semFiltro ? { score: 0, termo: '', peso: 0 } : relevancia(text, termosEmpresa(J<any>(b.data, {}), itens.get(Number(b.id)) || []))
    if (!semFiltro && !r.score) continue
    const raio = Math.min(max, Number(J<any>(b.data, {}).raio) || 5)
    const d = loc && b.lat != null ? distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) : null
    if (loc && (d === null || d > raio)) continue
    const c: any = card(b, nivelOf(ps, b.plan_id), d === null ? null : Math.round(d * 10) / 10); c._owner = Number(b.owner_id); c._score = r.score; c._termo = r.termo; out.push(c)
  }
  // mais relevantes primeiro (palavra-chave cadastrada > ramo > nome), depois os mais perto
  return out.sort((a, b) => (b._score - a._score) || ((a.distancia ?? 1e9) - (b.distancia ?? 1e9))).slice(0, limite)
}
/** O que a mensagem pede, segundo o cadastro de palavras-chave de TODAS as empresas (inclusive as que ainda não estão
 *  disponíveis): termo reconhecido, força da correspondência e se há alguma empresa disponível com ele. */
export async function reconhecerBusca(text: string): Promise<{ termo: string; score: number; peso: number; disponivel: boolean } | null> {
  if (![...new Set(toksB(text))].some((w) => w.length >= 3 && !STOP_BUSCA.has(w))) return null
  const itens = await itensPorEmpresa(), agora = Date.now()
  let best: { termo: string; score: number; peso: number } | null = null, disponivel = false
  for (const b of await q("SELECT id, status, expires_at, data FROM businesses WHERE status NOT IN ('recusado', 'institucional')")) {
    const r = relevancia(text, termosEmpresa(J<any>(b.data, {}), itens.get(Number(b.id)) || []))
    if (!r.score) continue
    if (!best || r.score > best.score) best = r
    if (b.status === 'ativo' && !(b.expires_at && Date.parse(b.expires_at) < agora)) disponivel = true
  }
  return best ? { ...best, disponivel } : null
}
const locOk = (lat: number, lng: number) => isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

export async function myLocationPut(ctx: Ctx) {
  const u = requireUser(ctx), lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng)
  if (ctx.body?.clear) { await setUM(u.id, 'location', null); return { ok: true } }
  const old = await getUM<any>(u.id, 'location', null)
  const raio = Number(ctx.body?.raio) >= 1 && Number(ctx.body?.raio) <= 100 ? Number(ctx.body.raio) : old?.raio || null
  if (ctx.body?.raio && !ctx.body?.endereco && !isFinite(lat) && old) { await setUM(u.id, 'location', { ...old, raio }); return { ok: true, location: { ...old, raio } } }
  if (typeof ctx.body?.endereco === 'string' && ctx.body.endereco.trim().length >= 3) {
    // mesmo geocodificador do resto do sistema (lib/geocode.ts — configurável por GEOCODER_URL)
    const g = await (await import('../lib/geocode.js')).geocodeAddress(ctx.body.endereco, 3)
    if (!g) fail(400, 'Não encontrei esse endereço. Tente com bairro e cidade.', 'invalid')
    const loc = { lat: g!.lat, lng: g!.lng, at: nowIso(), raio, label: String(g!.label || '').split(',').slice(0, 3).join(','), manual: true }
    await setUM(u.id, 'location', loc); return { ok: true, location: loc }
  }
  if (!locOk(lat, lng)) fail(400, 'Localização inválida.', 'invalid')
  const loc = { lat, lng, at: nowIso(), raio, label: 'Localização atual', manual: false }
  await setUM(u.id, 'location', loc); return { ok: true, location: loc }
}
export async function userLocation(userId: number) {
  const l = await getUM<any>(userId, 'location', null)
  return l && (l.manual || Date.now() - Date.parse(l.at) < 7 * 86400_000) ? { lat: l.lat, lng: l.lng, raio: l.raio || null, label: l.label || '' } : null
}
/** Atalho para conversar com a empresa: só quando o agente dela está ativo (pago, no prazo e módulo ligado). Mesma regra da página da empresa. */
async function comAgente(items: any[]) {
  if (!(await modules()).agente) return items
  if (!items.length) return items
  // dados de todas as empresas da lista numa consulta (antes: uma por empresa); o endereço só é recalculado se precisar
  const ids = items.map((it) => Number(it.id)), por = new Map((await q(`SELECT id, data FROM businesses WHERE id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids)).map((b: any) => [Number(b.id), J<any>(b.data, {})]))
  for (const it of items) { const x = por.get(Number(it.id)); if (x && agentOn(x)) it.agente = `/${slugPronto(x) || await ensureSlug(Number(it.id))}` }
  return items
}
/** Rótulo e raio efetivos da localização do usuário (mesmos usados pela página "Empresas parceiras"). */
async function locInfo(loc: any) { const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15; return { label: loc?.label || 'Localização atual', raio: Math.min(adm, loc?.raio || adm), max: adm } }
const RAIOS = [1, 2, 3, 5, 10, 15, 20, 30, 50, 100]
/** Resposta ÚNICA do chat para "empresas perto de mim" — usada pela 1ª resposta (intents) e pela atualização automática
 *  depois que a localização é autorizada. Mesma busca (searchBusinesses), mesmo raio e mesmas regras de publicação da página. */
export async function respostaEmpresas(userId: number, text: string): Promise<{ estado: 'aguardando_autorizacao' | 'empresas_encontradas' | 'nenhuma_empresa'; content: string; ids: number[] }> {
  const rec = await reconhecerBusca(text), com = rec?.termo && rec.peso >= 2 ? ` que trabalham com ${rec.termo}` : ''
  // palavra-chave cadastrada, mas nenhuma empresa aprovada e disponível (só pendentes, reprovadas, suspensas ou vencidas)
  if (rec && !rec.disponivel) return { estado: 'nenhuma_empresa', content: `Ainda não há empresas parceiras disponíveis${com}.`, ids: [] }
  const loc = await userLocation(userId)
  if (!loc) return { estado: 'aguardando_autorizacao', content: `Para mostrar empresas${com} perto de você, preciso da sua localização. ⟦loc:${encodeURIComponent(text)}⟧`, ids: [] }
  const rs = await searchBusinesses(text, loc), L = await locInfo(loc)
  const onde = !L.label || L.label === 'Localização atual' ? 'perto de você' : `perto de ${L.label}`
  if (!rs.length) {
    const prox = RAIOS.find((r) => r > L.raio && r <= L.max) || 0
    return { estado: 'nenhuma_empresa', content: `Não encontrei empresas disponíveis${com} ${onde} (raio de ${L.raio} km). Você pode ampliar o raio de busca ou informar outra cidade. ⟦locopt:${encodeURIComponent(text)}|${prox}⟧`, ids: [] }
  }
  const ids = rs.slice(0, 12).map((r) => Number(r.id)), termo = rec && rec.peso >= 2 ? rec.termo : ''
  const frase = termo ? `Encontrei ${ids.length === 1 ? 'uma empresa que trabalha' : 'empresas que trabalham'} com ${termo} para você!` : `Encontrei ${ids.length === 1 ? 'esta opção' : ids.length + ' opções'} para você!`
  return { estado: 'empresas_encontradas', content: `${frase} (${onde}, raio de ${L.raio} km) ⟦emp:${ids.join(',')}⟧`, ids }
}
const PEND_RE = /⟦(loc|locopt):([^⟧|]*)(?:\|[^⟧]*)?⟧/
/** Atualiza NA PRÓPRIA CONVERSA a resposta que pedia localização (ou que não achou empresas): reescreve a mesma mensagem com o
 *  resultado real, sem criar mensagem nova. Só mensagens do próprio usuário; só as ainda pendentes (ou, com refazer, as de resultado). */
export async function chatEmpresasPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const conv = str(ctx.body?.conversationId, 80), mid = Number(ctx.body?.messageId) || 0, refazer = !!ctx.body?.refazer
  if (!conv) fail(400, 'Conversa inválida.', 'invalid')
  const c = await one('SELECT id FROM conversations WHERE id = $1 AND user_id = $2', [conv, u.id]); if (!c) fail(404, 'Conversa não encontrada.', 'not_found')
  const rows = await q(`SELECT id, content FROM messages WHERE conversation_id = $1 AND user_id = $2 AND role = 'assistant' AND superseded = $3 ${mid ? 'AND id = $4' : ''} ORDER BY id`, mid ? [conv, u.id, false, mid] : [conv, u.id, false])
  const loc = await userLocation(u.id), out: any[] = []
  for (const m of rows) {
    const pm = String(m.content).match(PEND_RE)
    // "refazer" (cidade/raio alterados): também reprocessa respostas com resultado — a consulta original fica guardada no próprio texto
    const em = refazer ? String(m.content).match(/⟦emp:[\d,]+⟧(?:⟦q:([^⟧]*)⟧)?/) : null
    if (!pm && !(em && em[1] !== undefined)) { if (mid) out.push({ id: Number(m.id), estado: 'atual', content: m.content }); continue } // já resolvida: devolve o texto atual (o app troca o componente antigo)
    if (!loc) { out.push({ id: Number(m.id), estado: 'aguardando_autorizacao', content: m.content }); continue }
    const texto = decodeURIComponent((pm ? pm[2] : em![1]) || '')
    const r = await respostaEmpresas(u.id, texto)
    const content = r.estado === 'empresas_encontradas' ? `${r.content}⟦q:${encodeURIComponent(texto)}⟧` : r.content
    if (content !== m.content) await q('UPDATE messages SET content = $1 WHERE id = $2 AND user_id = $3', [content, m.id, u.id])
    out.push({ id: Number(m.id), estado: r.estado, content })
  }
  return { localizacao: loc ? { ...(await locInfo(loc)), manual: !!(await getUM<any>(u.id, 'location', null))?.manual } : null, estado: loc ? 'localizacao_autorizada' : 'aguardando_autorizacao', mensagens: out }
}
/* ---------- Vitrine pública ("Empresas perto de você") ----------
   Visualização SEM conta: quem não entrou informa a localização no próprio aparelho (GPS ou cidade) e ela vem na consulta
   (lat, lng, raio, rótulo) — nada é gravado no servidor. Quem entrou continua usando a localização da conta, como sempre.
   As regras de publicação, raio e privacidade são as mesmas para os dois. */
const viewerOf = (ctx: Ctx) => (ctx.user ? ctx.user.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon').split(',')[0].trim())
async function locVitrine(ctx: Ctx): Promise<{ lat: number; lng: number; raio: number | null; label: string } | null> {
  const lat = Number(ctx.query.get('lat')), lng = Number(ctx.query.get('lng'))
  if (ctx.query.get('lat') != null && locOk(lat, lng)) {
    const r = Number(ctx.query.get('raio'))
    return { lat, lng, raio: r >= 1 && r <= 100 ? r : null, label: str(ctx.query.get('label'), 80) }
  }
  return ctx.user ? await userLocation(ctx.user.id) : null
}
/** Cidade ou bairro → coordenadas, para o visitante sem conta (o mesmo geocodificador da conta; nada é gravado). */
export async function vitrineGeoGet(ctx: Ctx) {
  await requireModule('empresas')
  const { rateLimit } = await import('../lib/security.js')
  if (!rateLimit('vitrine-geo:' + viewerOf(ctx), 20, 60_000)) fail(429, 'Muitas buscas seguidas. Aguarde um instante e tente de novo.', 'rate_limited')
  const t = str(ctx.query.get('endereco'), 120)
  if (t.trim().length < 3) fail(400, 'Digite a cidade ou o bairro.', 'invalid')
  const g = await (await import('../lib/geocode.js')).geocodeAddress(t, 3)
  if (!g) fail(400, 'Não encontrei esse endereço. Tente com bairro e cidade.', 'invalid')
  return { location: { lat: g!.lat, lng: g!.lng, label: String(g!.label || '').split(',').slice(0, 3).join(',') } }
}
export async function businessSearchGet(ctx: Ctx) {
  await requireModule('empresas')
  const DSC = await import('../lib/descobrir.js'); await DSC.exigirModo('empresas') // desligada no painel: bloqueada também por requisição direta
  const loc = await locVitrine(ctx)
  if (!loc) return { needLocation: true, items: [] }
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15
  // feed (Descobrir → Empresas): paginado para o carregamento contínuo; sem "pagina" a resposta é a de sempre (30 primeiras)
  const pag = ctx.query.get('pagina') != null ? Math.max(1, Math.floor(Number(ctx.query.get('pagina')) || 1)) : 0, por = Math.min(30, Math.max(4, Math.floor(Number(ctx.query.get('por')) || 10)))
  const qtxt = str(ctx.query.get('q'), 80), todos0 = await searchBusinesses(qtxt, loc as any, pag ? 500 : 30)
  // personalização (Descobrir): a ordem da relevância geral ganha a afinidade do PRÓPRIO usuário — mais forte sem busca,
  // mais leve com busca (o termo digitado continua mandando); visitante e usuário novo ficam na ordem geral
  const pf = pag ? await DSC.perfil(ctx.user?.id) : null
  const todos = pf && !pf.vazio ? todos0.map((it: any, i: number) => ({ it, s: (1 - i / Math.max(1, todos0.length)) + (qtxt ? 0.4 : 0.8) * DSC.afinidade(pf, { k: 'e', id: Number(it.id), cat: it.categoria, nome: it.empresa }) })).sort((a: any, b: any) => b.s - a.s).map((x: any) => x.it) : todos0
  const items = pag ? todos.slice((pag - 1) * por, pag * por) : todos
  const viewer = viewerOf(ctx)
  await hits(items.map((it: any) => ({ bid: Number(it.id), owner: it._owner })), 'impressao', viewer) // uma gravação para a lista (antes: uma por empresa)
  items.forEach((it: any) => { delete it._owner; delete it._score; delete it._termo })
  await comAgente(items)
  return { needLocation: false, location: { label: (loc as any).label || 'Localização atual', raio: Math.min(adm, (loc as any).raio || adm), max: adm }, items,
    ...(pag ? { pagina: pag, total: todos.length, temMais: pag * por < todos.length } : {}) }
}

/* ---------- Descobrir → Produtos (marketplace) e Serviços ----------
   Itens REAIS das lojas que estão no ar (anúncio aprovado e na validade, plano com loja, módulo de catálogo ligado) e dentro
   do raio da localização — a mesma regra da lista de empresas. A modalidade do catálogo da empresa decide a aba (exclusiva):
   empresas de PRODUTOS aparecem em Produtos; empresas de SERVIÇOS, em Serviços. Nada é misturado e nada é cadastrado aqui:
   os serviços são os mesmos já cadastrados pelas empresas (tabela products, tipo "servico").
   Produtos: ofertas, variações e disponibilidade (preço e foto do destaque); esgotados não entram.
   Serviços: preço fixo, por hora, consulta ou sob orçamento (o "sob orçamento" fica no fim das ordens por preço). */
export async function vitrineItens(ctx: Ctx, tipo: 'produtos' | 'servicos') {
  await requireModule('empresas')
  const DSC = await import('../lib/descobrir.js'); await DSC.exigirModo(tipo) // desligada no painel: bloqueada também por requisição direta
  if ((await modules()).catalogo === false) return { needLocation: false, items: [], categorias: [], total: 0, temMais: false, pagina: 1 }
  const loc = await locVitrine(ctx)
  if (!loc) return { needLocation: true, items: [], categorias: [], total: 0, temMais: false, pagina: 1 }
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(adm, loc.raio || adm), ps = await plans()
  const qp = (k: string) => String(ctx.query.get(k) || '')
  const busca = norm(str(qp('q'), 80)).split(' ').filter((w) => w.length >= 2).map((w) => (w.length > 3 && w.endsWith('s') ? w.slice(0, -1) : w))
  const categoria = str(qp('categoria'), 40), ordem = ['menor', 'maior', 'proximos', 'relevancia', 'recentes'].includes(qp('ordem')) ? qp('ordem') : 'proximos', soOfertas = qp('ofertas') === '1'
  const pag = Math.max(1, Math.floor(Number(qp('pagina')) || 1)), por = Math.min(40, Math.max(6, Math.floor(Number(qp('por')) || 20)))
  const location = { label: loc.label || 'Localização atual', raio: max, max: adm }
  // lojas elegíveis dentro do raio (cada uma com o próprio raio de atendimento, como na lista de empresas)
  const lojas = new Map<number, any>()
  for (const b of await activeRows()) {
    if (nivelOf(ps, b.plan_id) < 4 || b.lat == null) continue
    const x = J<any>(b.data, {}); if (opTipo(x) !== tipo) continue
    const d = distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }), raio = Math.min(max, Number(x.raio) || 5); if (d > raio) continue
    const st = openState(x)
    lojas.set(Number(b.id), { id: Number(b.id), empresa: x.empresa || '', logo: x.logo || null, categoria: x.categoria || '', distancia: Math.round(d * 10) / 10, aberto: st.aberto, x })
  }
  if (!lojas.size) return { needLocation: false, location, items: [], categorias: [], total: 0, temMais: false, pagina: pag, ofertas: 0 }
  const ids = [...lojas.keys()], serv = tipo === 'servicos'
  const rows = await q(`SELECT * FROM products WHERE active = $1 AND business_id IN (${ids.map((_, i) => '$' + (i + 2)).join(',')}) ORDER BY id`, [true, ...ids]) as any[]
  const base = rows.filter((r) => { const l = lojas.get(Number(r.business_id)), d = J<any>(r.data, {}); return l && inOp(l.x)(d) && (d.tipo === 'servico') === serv })
  const itens = (await CAT.enriquecer(base.map((r) => ({ ...productOut(r), _bid: Number(r.business_id) }))))
    .filter((p: any) => (serv ? p.modoPreco === 'orcamento' || Number(p.preco) > 0 : !p.esgotado && p.destaque && Number(p.destaque.preco) > 0)) // só o que pode ser pedido/agendado agora
  const vistos = new Set<number>(), lista: any[] = []
  for (const p of itens) {
    if (vistos.has(p.id)) continue; vistos.add(p.id)
    const l = lojas.get(p._bid)
    if (busca.length) { const h = norm([p.nome, p.categoria, p.descricao, p.palavras, l.empresa, ...(p.variantes || []).map((v: any) => v.rotulo)].join(' ')); if (!busca.every((w) => h.includes(w))) continue }
    const empresa = { id: l.id, nome: l.empresa, logo: l.logo, distancia: l.distancia, aberto: l.aberto }
    if (l.share === undefined) l.share = await (await import('../lib/compartilhar.js')).ativoPara(l.x)
    if (serv) {
      const orc = p.modoPreco === 'orcamento', d = p.destaque || {}
      lista.push({ id: p.id, tipo: 'servico', nome: p.nome, categoria: p.categoria || 'Outros', foto: d.foto || (p.fotos || [])[0] || null, preco: orc ? null : Number(d.preco ?? p.preco),
        precoNormal: d.emOferta ? d.precoNormal : null, emOferta: !!d.emOferta, desconto: d.desconto || 0, aPartirDe: false, modoPreco: p.modoPreco || 'fixo', duracao: Number(p.duracao) || null,
        empresa, link: `/x/empresa/${l.id}?servico=${p.id}`, ...(l.share ? {} : { share: false }) })
      continue
    }
    lista.push({ id: p.id, nome: p.nome, categoria: p.categoria || 'Outros', foto: p.destaque.foto || (p.fotos || [])[0] || null, preco: p.destaque.preco, precoNormal: p.destaque.emOferta ? p.destaque.precoNormal : null,
      emOferta: !!p.destaque.emOferta, desconto: p.destaque.desconto || 0, aPartirDe: !!p.destaque.aPartirDe || (p.variacoes || []).length > 0, opcoes: (p.variantes || []).filter((v: any) => v.disponivel).length,
      empresa, link: `/x/empresa/${l.id}?produto=${p.id}`, ...(l.share ? {} : { share: false }) })
  }
  // categorias do que sobrou da busca/ofertas (antes de filtrar a categoria, para trocar de uma para outra)
  const pre = soOfertas ? lista.filter((p) => p.emOferta) : lista
  const cont = new Map<string, number>(); for (const p of pre) cont.set(p.categoria, (cont.get(p.categoria) || 0) + 1)
  const categorias = [...cont.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'pt-BR')).map(([nome, n]) => ({ nome, n }))
  const fil = categoria ? pre.filter((p) => norm(p.categoria) === norm(categoria)) : pre
  const semPreco = (p: any) => (p.preco == null ? 1 : 0) // serviço sob orçamento: sempre depois dos que têm preço
  // "relevancia" (padrão da tela): relevância geral + afinidade do próprio usuário (Descobrir → personalização)
  if (ordem === 'relevancia') {
    const pf = await DSC.perfil(ctx.user?.id), sc = new Map<number, number>()
    for (const p of fil) sc.set(p.id, DSC.relevanciaGeral({ distancia: p.empresa.distancia, aberto: p.empresa.aberto, foto: p.foto, emOferta: p.emOferta, preco: p.preco }) + 0.9 * DSC.afinidade(pf, { k: serv ? 's' : 'p', id: p.id, bid: p.empresa.id, cat: p.categoria, nome: p.nome }))
    fil.sort((a, b) => (sc.get(b.id)! - sc.get(a.id)!) || a.id - b.id)
  }
  const ord = ordem === 'relevancia' ? fil : fil.sort(ordem === 'menor' ? (a, b) => semPreco(a) - semPreco(b) || (a.preco ?? 0) - (b.preco ?? 0) || a.empresa.distancia - b.empresa.distancia
    : ordem === 'maior' ? (a, b) => semPreco(a) - semPreco(b) || (b.preco ?? 0) - (a.preco ?? 0) || a.empresa.distancia - b.empresa.distancia
    : ordem === 'recentes' ? (a, b) => b.id - a.id // cadastro mais novo primeiro (o id cresce a cada cadastro)
    : (a, b) => a.empresa.distancia - b.empresa.distancia || Number(b.emOferta) - Number(a.emOferta) || a.id - b.id)
  return { needLocation: false, location, items: ord.slice((pag - 1) * por, pag * por), categorias, total: ord.length, pagina: pag, temMais: pag * por < ord.length, ofertas: lista.filter((p) => p.emOferta).length }
}
/* ---------- Busca de produtos e serviços do chat (modo "Busca", src/modos/busca.ts) ----------
   Mesmas regras de publicação da vitrine (anúncio aprovado, no ar e na validade; plano com loja; módulo de catálogo; modalidade
   do catálogo da empresa), mas SEM exigir localização: com localização, cada item sabe a distância e se a loja atende ali
   (raio de atendimento); sem ela, a busca vale para todas as lojas no ar. Esgotados entram marcados como indisponíveis. */
/** Galeria do item: foto de destaque + fotos do produto + fotos das variações (sem repetir), na ordem da loja. */
export const galeriaItem = (p: any): string[] => [...new Set([(p.destaque || {}).foto, ...(p.fotos || []), ...(p.variantes || []).flatMap((v: any) => (Array.isArray(v?.fotos) ? v.fotos : []))].map((x) => String(x || '')).filter((x) => /^(data:image\/|https?:\/\/)/.test(x)))].slice(0, 12)
export interface ItemPublico { fotos?: string[]; id: number; tipo: 'produto' | 'servico'; bid: number; nome: string; categoria: string; descricao: string; palavras: string; variantes: string[]
  foto: string | null; preco: number | null; precoNormal: number | null; emOferta: boolean; desconto: number; aPartirDe: boolean; modoPreco: string; duracao: number | null
  disponivel: boolean; restantes: number | null; empresa: { id: number; nome: string; categoria: string; logo: string | null; distancia: number | null; atende: boolean; aberto: boolean; agora: string } }
export async function itensPublicos(loc: { lat: number; lng: number; raio?: number | null } | null, so?: { ids?: number[] }): Promise<ItemPublico[]> {
  if ((await modules()).catalogo === false || (await modules()).empresas === false) return []
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(adm, loc?.raio || adm), ps = await plans()
  const lojas = new Map<number, any>()
  for (const b of await activeRows()) {
    if (nivelOf(ps, b.plan_id) < 4) continue
    const x = J<any>(b.data, {}), d = loc && b.lat != null ? distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) : null, raio = Math.min(max, Number(x.raio) || 5), st = openState(x)
    lojas.set(Number(b.id), { id: Number(b.id), nome: String(x.empresa || ''), categoria: String(x.categoria || ''), logo: typeof x.logo === 'string' && x.logo ? x.logo : null, distancia: d == null ? null : Math.round(d * 10) / 10, atende: d == null ? !loc : d <= raio, aberto: st.aberto, agora: st.texto, x })
  }
  if (!lojas.size) return []
  const ids = [...lojas.keys()], filtroIds = so?.ids?.length ? so.ids.filter((n) => Number.isInteger(n) && n > 0).slice(0, 60) : null
  const rows = await q(`SELECT * FROM products WHERE active = $1 AND business_id IN (${ids.map((_, i) => '$' + (i + 2)).join(',')})${filtroIds ? ` AND id IN (${filtroIds.map((_, i) => '$' + (i + 2 + ids.length)).join(',')})` : ''} ORDER BY id`, [true, ...ids, ...(filtroIds || [])]) as any[]
  const base = rows.filter((r) => { const l = lojas.get(Number(r.business_id)); return l && inOp(l.x)(J<any>(r.data, {})) })
  const out: ItemPublico[] = []
  for (const p of await CAT.enriquecer(base.map((r) => ({ ...productOut(r), _bid: Number(r.business_id) })))) {
    const l = lojas.get(p._bid), serv = p.tipo === 'servico', d = p.destaque || {}, orc = serv && p.modoPreco === 'orcamento'
    const preco = orc ? null : serv ? Number(d.preco ?? p.preco) : Number(d.preco ?? 0)
    if (!orc && !(preco! > 0)) continue // sem preço (rascunho) não aparece
    const disponivel = serv ? true : !p.esgotado && !!p.destaque
    out.push({ id: p.id, tipo: serv ? 'servico' : 'produto', bid: l.id, nome: String(p.nome || ''), categoria: String(p.categoria || ''), descricao: String(p.descricao || '').slice(0, 400), palavras: String(p.palavras || ''),
      variantes: (p.variantes || []).map((v: any) => String(v.rotulo || '')).filter(Boolean), foto: d.foto || (p.fotos || [])[0] || null, fotos: galeriaItem(p), preco, precoNormal: d.emOferta ? Number(d.precoNormal) : null,
      emOferta: !!d.emOferta, desconto: Number(d.desconto) || 0, aPartirDe: !serv && (!!d.aPartirDe || (p.variacoes || []).length > 0), modoPreco: serv ? String(p.modoPreco || 'fixo') : 'fixo', duracao: serv ? Number(p.duracao) || null : null,
      disponivel, restantes: !serv && p.restantes != null ? Number(p.restantes) : null,
      empresa: { id: l.id, nome: l.nome, categoria: l.categoria, logo: l.logo, distancia: l.distancia, atende: l.atende, aberto: l.aberto, agora: l.agora } })
  }
  return out
}
export const marketplaceGet = (ctx: Ctx) => vitrineItens(ctx, 'produtos')
export const marketplaceServicosGet = (ctx: Ctx) => vitrineItens(ctx, 'servicos')

/* ---------- Links compartilhados: prévia (WhatsApp, redes, navegador) ----------
   Título, descrição e imagem da vitrine, da empresa, do produto ou do serviço compartilhado. Só conteúdo público: empresa no ar
   com página própria; produto/serviço ativo, da modalidade atual do catálogo, de uma loja no ar. Fora disso, a prévia é a padrão. */
const VITRINE_TXT = 'Descubra empresas, produtos e serviços perto de você! Encontre opções na sua região e conheça tudo o que os estabelecimentos têm a oferecer.'
const brlTxt = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ',')
export async function itemPublico(bid: number, pid: number) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) return null
  const n = nivelOf(await plans(), b.plan_id), x = J<any>(b.data, {}); if (n < 3) return null
  if (!pid) return { b, x, p: null as any }
  if (n < 4 || (await modules()).catalogo === false) return null
  const r = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2 AND active = $3', [pid, bid, true]); if (!r) return null
  const p = (await CAT.enriquecer([productOut(r)]))[0]; if (!inOp(x)(p)) return null
  return { b, x, p }
}
const imgDe = (src: any, rota: string) => { const v = String(src || ''); return /^data:image\//.test(v) ? pub() + rota : /^https?:\/\//.test(v) ? v : '' }
export async function metaVitrine(path: string, sp: URLSearchParams): Promise<{ titulo: string; descricao: string; imagem: string; url: string } | null> {
  try {
    if (!(await modules()).empresas) return null
    const padrao = pub() + '/brand/og-image.png'
    if (/^\/x\/empresas\/?$/.test(path)) return { titulo: 'Empresas, produtos e serviços perto de você · Meu Assistente', descricao: VITRINE_TXT, imagem: padrao, url: pub() + '/x/empresas' }
    const m = /^\/x\/empresa\/(\d+)\/?$/.exec(path); if (!m) return null
    const pid = Number(sp.get('servico') || sp.get('produto')) || 0, it = (await itemPublico(Number(m[1]), pid)) || (pid ? await itemPublico(Number(m[1]), 0) : null) // item fora do ar: prévia da empresa
    if (!it) return null
    const { x, p } = it, emp = String(x.empresa || 'Empresa')
    if (p) {
      const serv = p.tipo === 'servico', d = p.destaque || {}, vSel = Number(sp.get('v')) || 0, SH = await import('../lib/compartilhar.js'), dv = vSel ? SH.dadosDoItem(p, vSel) : null
      const preco = serv ? (p.modoPreco === 'orcamento' ? 'Sob orçamento' : p.modoPreco === 'hora' ? brlTxt(p.preco) + '/hora' : p.modoPreco === 'consulta' ? 'Consulta ' + brlTxt(p.preco) : brlTxt(p.preco))
        : dv && dv.vid ? `${dv.preco}${dv.oferta ? ` (oferta, de ${dv.precoNormal})` : ''}` : p.esgotado ? 'Indisponível no momento' : `${d.aPartirDe ? 'A partir de ' : ''}${brlTxt(d.preco ?? p.preco)}${d.emOferta ? ` (oferta, de ${brlTxt(d.precoNormal)})` : ''}`
      return { titulo: `${dv && dv.vid ? dv.nome : p.nome} · ${emp}`, descricao: [preco, emp, String(p.descricao || '').slice(0, 140)].filter(Boolean).join(' · '),
        imagem: imgDe(d.foto || (p.fotos || [])[0], `/api/v2/vitrine/imagem/item/${p.id}`) || imgDe(x.capa || x.logo, `/api/v2/vitrine/imagem/empresa/${it.b.id}`) || padrao,
        url: `${pub()}/x/empresa/${it.b.id}?${serv ? 'servico' : 'produto'}=${p.id}` }
    }
    return { titulo: `${emp} · Meu Assistente`, descricao: String(x.titulo || x.texto || x.sobre || x.categoria || VITRINE_TXT).slice(0, 200), imagem: imgDe(x.capa || x.logo, `/api/v2/vitrine/imagem/empresa/${it.b.id}`) || padrao, url: `${pub()}/x/empresa/${it.b.id}` }
  } catch { return null }
}
/** Imagem da prévia (as fotos ficam gravadas no cadastro): só de conteúdo público, com as mesmas regras acima. */
export async function vitrineImagemGet(ctx: Ctx) {
  let src = ''
  if (ctx.params.tipo === 'empresa') { const it = await itemPublico(Number(ctx.params.id), 0); if (it) src = it.x.capa || it.x.logo || '' }
  else if (ctx.params.tipo === 'item') { const r = await one('SELECT business_id FROM products WHERE id = $1', [Number(ctx.params.id)]); const it = r ? await itemPublico(Number(r.business_id), Number(ctx.params.id)) : null; if (it?.p) { const n = Number(ctx.query.get('n')); src = Number.isInteger(n) && n > 0 ? galeriaItem(it.p)[n] || '' : (it.p.destaque || {}).foto || (it.p.fotos || [])[0] || '' } } // ?n= : foto n da galeria (ampliação no chat)
  const m = /^data:(image\/(?:png|jpe?g|webp|gif));base64,(.+)$/.exec(String(src))
  if (!m) fail(404, 'Imagem não encontrada.', 'not_found')
  return { _binary: true, mime: m![1], data: Buffer.from(m![2], 'base64'), headers: { 'Cache-Control': 'public, max-age=3600' } }
}

/* ---------- página pública e produtos ---------- */
function productOut(p: any) { const d = J<any>(p.data, {}); return { id: Number(p.id), active: !!(p.active === true || p.active === 1 || p.active === 't'), ...d } }
/** Card de produto no chat: preço e foto do destaque (menor preço disponível), oferta e "a partir de". */
const cardProduto = (p: any) => ({ id: p.id, nome: p.nome, preco: p.destaque ? p.destaque.preco : p.preco, precoNormal: p.destaque?.emOferta ? p.destaque.precoNormal : undefined, oferta: !!p.destaque?.emOferta, desconto: p.destaque?.desconto || 0, aPartirDe: !!p.destaque?.aPartirDe, esgotado: !!p.esgotado, tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', foto: p.destaque?.foto || (p.fotos || [])[0] || null, categoria: p.categoria })
const precoTxt = (p: any) => { const d = p.destaque, f = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ','); if (!d) return f(p.preco); return `${d.aPartirDe ? 'a partir de ' : ''}${f(d.preco)}${d.emOferta ? ` (oferta, de ${f(d.precoNormal)})` : ''}${(p.faixasQtd || []).length > 1 ? ` · preço por quantidade: ${p.faixasQtd.slice(1).map((x: any) => `a partir de ${x.qtd} un. ${f(x.preco)} cada`).join('; ')}` : ''}${p.esgotado ? ' — ESGOTADO' : ''}` }
/** Preço unitário com as opções/adicionais. `baseFixa` (preço da variação escolhida ou preço promocional) é a base do item:
 *  nesse caso as opções só somam adicionais (não trocam a base). */
export function unitPrice(prod: any, escolhas: Record<string, number>, baseFixa?: number) {
  let base = baseFixa != null ? Number(baseFixa) : Number(prod.preco) || 0, extra = 0
  for (const v of prod.variacoes || []) {
    const o = v.opcoes?.[Number(escolhas?.[v.nome] ?? 0)]
    if (!o) fail(400, `Escolha uma opção de ${v.nome}.`, 'invalid')
    const pr = Number(o.preco) || 0
    if (baseFixa == null && pr >= (Number(prod.preco) || 0) * 0.5 && pr > 0) base = pr; else extra += pr
  }
  return Math.round((base + extra) * 100) / 100
}
export async function businessGet(ctx: Ctx) {
  const u = ctx.user || null; await requireModule('empresas'); await refreshRatings()
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const ps = await plans()
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) fail(404, 'O anúncio desta empresa não está ativo.', 'not_found')
  const n = nivelOf(ps, b!.plan_id); if (n < 3) fail(404, 'Esta empresa não tem página própria.', 'not_found')
  const x = J<any>(b!.data, {}), loc = await locVitrine(ctx) // conta: localização da conta; visitante: a do aparelho (se informada)
  await hit(Number(b!.id), 'visita', u ? u.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b!.owner_id))
  const loja = n >= 4 && (await modules()).catalogo !== false
  const prods = loja ? await CAT.enriquecer((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b!.id, true])).map(productOut).filter(inOp(x))) : [] // só o que o tipo de catálogo atual permite (o resto continua salvo, apenas oculto)
  return { ...card(b, n, loc && b!.lat != null ? Math.round(distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) * 10) / 10 : null),
    endereco: x.endereco, referencia: x.referencia || '', horario: x.horario, sobre: x.sobre, capa: x.capa || null, lat: b!.lat, lng: b!.lng, loja, operacao: opTipo(x), produtos: prods,
    compartilhar: await (await import('../lib/compartilhar.js')).ativoPara(x), // botão de compartilhar nos detalhes (plataforma e empresa)
    // dono vendo a própria loja: explica por que o botão flutuante não aparece (ou confirma que está ativo)
    agenteAviso: u && Number(u.id) === Number(b!.owner_id) && x.agente?.flutuante?.ativo ? (!(await modules()).agente ? 'O botão flutuante não aparece: o administrador desligou o agente.' : x.agente.ativo === false ? 'O botão flutuante está oculto porque você desligou o atendente.' : !agentOn(x) ? 'O botão flutuante aparece aqui para seus clientes assim que o atendente estiver no ar (Ajustes → Agente de atendimento → Ativar agente).' : '') : '',
    // botão flutuante só com o atendente realmente no ar (contratado, dentro do prazo e ligado) e o botão ativado
    agente: (await modules()).agente && agentOn(x) && x.agente.flutuante?.ativo ? { link: `/${await ensureSlug(Number(b!.id))}`, msg: x.agente.flutuante.msg || 'Se precisar de ajuda, me chama aqui!', avatar: x.agente.avatar || x.logo || null, nome: agentName(x.agente) } : null,
    // forma de receber pedidos que vale para o cliente: 'whatsapp' só quando o cliente leva o pedido ao WhatsApp (sem envio automático)
    pedidoPeloWhatsApp: await (async () => { const R = await import('../lib/recebimento-pedidos.js'); return (await R.canaisEfetivos(x)).whatsapp && !!(await import('../lib/whatsapp-envio.js')).numeroWhats(x.zap) && !(await (await import('../lib/whatsapp-envio.js')).configurado()) })().catch(() => false),
    mensagemPronta: (() => { const m = MPR.config(x); return m.ativo && x.zap ? { botao: m.botao, texto: m.texto } : null })(), linkCatalogo: `${pub()}/x/empresa/${b!.id}`,
    incentivos: loja ? (await (await import('../lib/incentivos.js')).vigentes(Number(b!.id))).map((await import('../lib/incentivos.js')).publico) : [], // estratégias de compra em vigor (o carrinho mostra o progresso)
    tema: normalizeTema(x.tema), tipo: nicheType(x), etiquetas: x.etiquetas || [], categorias: x.categorias || [], dias: x.horarioCfg?.dias || null, pagOnline: !!(x.pagamento?.online && (await mpPronto(b))), chavePix: x.pagamento?.chavePix || '',
    entrega: loja ? { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', modoTaxa: 'fixa', kmGratis: 0, taxaExcedente: 0, taxaKm: 0, ...(x.entrega || {}) } : null,
    creditoLoja: loja ? await (await import('../lib/credito-loja.js')).estadoEmpresa(Number(b!.id)).then((e) => e.paraClientes && e.cfg.aceitarSolicitacoes).catch(() => false) : false, // Crédito da Loja: aceita solicitações de limite
    pagamento: loja ? await (async () => { const pg = { pix: true, chavePix: '', mostrarChave: true, pixentrega: false, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }; if (pg.mostrarChave === false) pg.chavePix = ''; pg.online = !!(pg.online && (await mpPronto(b))); return pg })() : null }
}
/** CRM: liga o pedido/agendamento recém-criado ao contato (reaproveita o cadastro existente). Nunca atrapalha o pedido. */
export const crmLink = (id: any) => { if (id) void import('../lib/crm.js').then((m) => m.LeadManagementService.vincularPedido(Number(id))).catch((e) => console.error('[crm]', e?.message)) }
export async function ownBusiness(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  if (b!.status === 'lixeira') fail(410, 'Esta empresa está na lixeira. Restaure-a em Sua empresa → Lixeira para voltar a usá-la.', 'na_lixeira')
  if (!gestaoLiberada(b)) fail(403, 'O painel da empresa é liberado depois que o anúncio é aprovado pelo administrador.', 'painel_bloqueado')
  return { u, b: b! }
}
/* ---------- Aba Produtos: lista LEVE (causa do travamento: a lista mandava todas as fotos originais em base64 — 150 produtos
   davam ~165 MB de JSON). Agora cada foto vai como endereço (/api/v2/ads/:id/products/:pid/foto/:n, com cache), a linha usa a
   miniatura, e as fotos originais só vêm ao abrir um produto (GET /api/v2/ads/:id/products/:pid). Nada muda no banco. ---------- */
// impressão digital da foto para o cache do navegador (muda quando a foto muda): tamanho + começo + meio + fim, sem ler os ~300 KB
const hashFoto = (f: string) => createHash('sha1').update(`${f.length}|${f.slice(0, 4096)}|${f.slice(f.length >> 1, (f.length >> 1) + 2048)}|${f.slice(-4096)}`).digest('hex').slice(0, 10)
const urlFoto = (bid: number, pid: number, n: number, f: string, vid?: number) => `/api/v2/ads/${bid}/products/${pid}/foto/${n}?${vid ? `v=${vid}&` : ''}h=${hashFoto(f)}`
const ehFotoInline = (f: unknown): f is string => typeof f === 'string' && f.startsWith('data:image/')
export function produtoLeve(p: any, bid: number) {
  const pid = Number(p.id), mapa = new Map<string, string>()
  const fotos = (p.fotos || []).map((f: any, n: number) => { if (!ehFotoInline(f)) return f; const u = urlFoto(bid, pid, n, f); mapa.set(f, u); return u })
  const variantes = (p.variantes || []).map((v: any) => ({ ...v, thumb: null, temThumb: !!v.thumb, fotos: (v.fotos || []).map((f: any, n: number) => { if (!ehFotoInline(f)) return f; const u = urlFoto(bid, pid, n, f, Number(v.id)); mapa.set(f, u); return u }) }))
  const pequena = (t: unknown) => (ehFotoInline(t) && t.length < 40_000 ? t : null)
  const thumb = pequena(p.thumb) || (p.variantes || []).map((v: any) => pequena(v.thumb)).find(Boolean) || null
  const dest = p.destaque ? { ...p.destaque, foto: p.destaque.foto ? (mapa.get(p.destaque.foto) || (ehFotoInline(p.destaque.foto) ? null : p.destaque.foto)) : null } : p.destaque
  return { ...p, fotos, variantes, thumb, destaque: dest, leve: true }
}
const urlImpressao = (bid: number, pid: number, n: number, fp: string, vid?: number) => `/api/v2/ads/${bid}/products/${pid}/foto/${n}?${vid ? `v=${vid}&` : ''}h=${createHash('sha1').update(fp).digest('hex').slice(0, 10)}`
export async function productsGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); const x = J<any>(b.data, {}), bid = Number(b.id), kind = D.db().kind
  // o banco devolve os produtos e as variações SEM as fotos (só uma impressão digital de cada): lista leve mesmo com muitos itens
  const rows = await q(`SELECT id, business_id, active, stock, created_at, updated_at, ${CAT.colunasSemFotos(kind, MAX_FOTOS_PRODUTO)} FROM products WHERE business_id = $1 ORDER BY id`, [b.id])
  const prods = rows.map((r: any) => { const p: any = productOut(r); p.fotos = CAT.impressoes(r, MAX_FOTOS_PRODUTO).map((fp, n) => urlImpressao(bid, p.id, n, fp)); return p })
  const vm = await CAT.variantesLeves(prods.map((p: any) => Number(p.id)), kind)
  for (const [pid, vs] of vm) for (const v of vs) v.fotos = v.fotos.map((fp, n) => urlImpressao(bid, pid, n, fp, v.id))
  return { operacao: opTipo(x), items: (await CAT.enriquecer(prods, true, vm)).map((p: any) => produtoLeve({ ...p, foraDoTipo: !inOp(x)(p) }, bid)) }
}
/** Um produto completo (fotos originais, variações com fotos e miniaturas): abre Editar e Duplicar. */
export async function productGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), x = J<any>(b.data, {}), row = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2', [Number(ctx.params.pid), b.id])
  if (!row) fail(404, 'Produto não encontrado.', 'not_found')
  const [p] = await CAT.enriquecer([productOut(row)], true); return { ...p, foraDoTipo: !inOp(x)(p) }
}
/** Fotos do produto principal (cada variação tem as suas, até CAT.MAX_FOTOS_VAR). */
export const MAX_FOTOS_PRODUTO = 3
/** Foto n do produto (ou da variação ?v=) para as telas da empresa. Só o dono; o endereço muda quando a foto muda (h=). */
export async function productFotoGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), pid = Number(ctx.params.pid), n = Number(ctx.params.n), vid = Number(ctx.query.get('v') || 0)
  const row = vid ? await one('SELECT data FROM product_variants WHERE id = $1 AND product_id = $2 AND business_id = $3', [vid, pid, b.id]) : await one('SELECT data FROM products WHERE id = $1 AND business_id = $2', [pid, b.id])
  const f = String((J<any>(row?.data, {}).fotos || [])[n] || '')
  const m = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i.exec(f)
  if (!m) { if (/^https?:\/\//.test(f)) return { _binary: true, status: 302, headers: { Location: f } }; fail(404, 'Foto não encontrada.', 'not_found') }
  return { _binary: true, mime: m![1], data: Buffer.from(m![2], 'base64'), headers: { 'Cache-Control': 'private, max-age=604800', ETag: `"${hashFoto(f)}"` } }
}
/** Endereços de foto do próprio sistema que voltem num salvamento viram a foto original guardada (nunca se perde foto). */
async function resolverFotosProprias(bid: number, it: any) {
  const re = new RegExp(`^/api/v2/ads/${bid}/products/(\\d+)/foto/(\\d+)(?:\\?(?:v=(\\d+)&)?h=[0-9a-f]+)?$`)
  const cache = new Map<string, any>()
  const dados = async (pid: number) => { const k = 'p' + pid; if (!cache.has(k)) cache.set(k, J<any>((await one('SELECT data FROM products WHERE id = $1 AND business_id = $2', [pid, bid]))?.data, {})); return cache.get(k) }
  if (Array.isArray(it.fotos)) it.fotos = await Promise.all(it.fotos.map(async (f: any) => { const m = typeof f === 'string' ? re.exec(f) : null; if (!m || m[3]) return f; return ((await dados(Number(m[1]))).fotos || [])[Number(m[2])] || f }))
  if (Array.isArray(it.variantes)) for (const v of it.variantes) if (v && Array.isArray(v.fotos)) v.fotos = v.fotos.map((f: any) => { const m = typeof f === 'string' ? re.exec(f) : null; return m && m[3] ? `keep:${m[3]}:${m[2]}` : f })
}
/** O catálogo de produtos faz parte do plano Loja completa (mesma regra do cadastro manual). */
export async function exigirLojaCompleta(b: any) { if (nivelOf(await plans(), b.plan_id) < 4) fail(403, 'Produtos fazem parte do plano Loja completa.', 'forbidden') }
/** Serviço ÚNICO de cadastro/atualização de produto (cadastro manual e importador de cardápio usam este mesmo caminho e as mesmas validações). */
export async function salvarProduto(b: any, it: any, o: { exigirFoto?: boolean; ativo?: boolean; origem?: any; db?: { query: (sql: string, p?: unknown[]) => Promise<any[]> } } = {}): Promise<number> {
  const dq = o.db || { query: (s: string, p?: unknown[]) => q(s, p) }
  await resolverFotosProprias(Number(b.id), it)
  let origem = o.origem
  const ex0 = it.id ? (await dq.query('SELECT data, stock FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]))[0] : null
  if (it.id && !ex0) fail(404, 'Produto não encontrado.', 'not_found')
  const antes = ex0 ? J<any>(ex0.data, {}) : null
  if (it.id && !origem && antes) origem = antes.origem
  const nome = str(it.nome, 80), tipo = it.tipo === 'servico' ? 'servico' : 'produto', modoPreco = ['fixo', 'hora', 'consulta', 'orcamento'].includes(it.modoPreco) ? it.modoPreco : 'fixo'
  if (!allowsKind(J<any>(b.data, {}), tipo)) fail(400, tipo === 'servico' ? 'Seu catálogo está configurado só para produtos. Mude em Ajustes → Tipo de catálogo para cadastrar serviços.' : 'Seu catálogo está configurado só para serviços. Mude em Ajustes → Tipo de catálogo para cadastrar produtos.', 'invalid')
  // variações (cor, tamanho, modelo…): só mexe nelas quando o formulário as envia (importador e edições antigas preservam)
  const mexeVar = tipo === 'produto' && Array.isArray(it.variantes)
  const variantes = mexeVar ? await CAT.prepararVariantes(it.id ? Number(it.id) : null, it.variantes, Number(b.id)) : null
  const temVar = variantes ? variantes.length > 0 : !!(it.id && tipo === 'produto' && (await dq.query('SELECT id FROM product_variants WHERE product_id = $1 LIMIT 1', [Number(it.id)])).length)
  // OPÇÃO PRINCIPAL: o produto cadastrado (sem variação) é a 1ª opção, com o PRÓPRIO preço, oferta, estoque e fotos; as variações
  // vêm depois. O formulário novo envia `opcaoBase: true`. Produtos antigos (sem o campo) seguem a regra antiga até serem salvos
  // de novo pelo formulário: o preço principal = menor preço entre as variações e a 1ª opção é a 1ª variação.
  const opcaoBase = tipo === 'produto' && (it.opcaoBase === undefined ? !!antes?.opcaoBase : it.opcaoBase === true)
  const baseNaVar = opcaoBase && temVar
  let preco = modoPreco === 'orcamento' ? Math.max(0, Number(it.preco) || 0) : Number(it.preco)
  if (baseNaVar) { if (!(Number(it.preco) >= 0) && antes) preco = Number(antes.preco) || 0; if (!(preco > 0)) fail(400, 'Informe o preço do produto principal (1ª opção). As variações aparecem depois dele.', 'invalid', 'preco') }
  else if (variantes && variantes.length) preco = Math.min(...variantes.map((v) => v.data.preco))
  else if (temVar && !variantes && !(Number(it.preco) >= 0) && antes) preco = Number(antes.preco) || 0 // edição que não mexe nas variações: mantém o preço principal
  if (!nome || !(preco >= 0 && preco < 1e6)) fail(400, 'Preencha o nome e um preço válido.', 'invalid')
  // oferta do produto sem variações: preço promocional > 0 e menor que o normal (com variações, cada uma tem a sua)
  const oferta = tipo !== 'produto' || (temVar && !baseNaVar) ? null : it.oferta === undefined ? (antes?.oferta && antes.oferta.preco < preco ? antes.oferta : null) : CAT.validarOferta(preco, it.oferta)
  // preço por quantidade (só produto sem variações): undefined no formulário = mantém o que estava salvo
  const manterQtd = (c: any) => { try { return CAT.validarFaixas(preco, c) } catch { return CAT.validarFaixas(preco, { ...c, ativo: false }) } } // preço mudou e alguma faixa ficou incoerente: guarda desligado
  const precoQtd = tipo !== 'produto' || temVar ? null : it.precoQtd === undefined ? (antes?.precoQtd ? manterQtd(antes.precoQtd) : null) : CAT.validarFaixas(preco, it.precoQtd)
  const stock = tipo !== 'produto' || (temVar && !baseNaVar) ? null : it.estoque === undefined ? (ex0 && ex0.stock != null ? Number(ex0.stock) : null) : CAT.validarEstoque(it.estoque)
  const fotosIn = (Array.isArray(it.fotos) ? it.fotos : []).filter((f: any) => typeof f === 'string' && f.startsWith('data:image/'))
  if (fotosIn.some((f: string) => f.length >= 900_000)) fail(400, 'Uma das fotos é muito grande. Escolha uma imagem menor (até ~600 KB) e tente de novo.', 'too_large')
  const fotos = fotosIn.slice(0, MAX_FOTOS_PRODUTO)
  // miniatura da foto principal (gerada no navegador, como nas variações): é o que a lista da aba Produtos mostra
  let thumb: string | null = typeof it.thumb === 'string' && it.thumb.startsWith('data:image/') && it.thumb.length < 40_000 ? it.thumb : null
  if (!thumb && antes?.thumb && (antes.fotos || [])[0] === fotos[0]) thumb = antes.thumb // mesma foto principal: mantém
  if (!fotos.length) thumb = null
  if (!fotos.length && tipo === 'produto' && o.exigirFoto !== false && !(variantes || []).some((v) => v.data.fotos.length) && !(temVar && !variantes)) fail(400, 'Adicione pelo menos uma foto do produto (ou das variações).', 'invalid')
  const duracao = tipo === 'servico' ? Math.min(600, Math.max(10, Math.round(Number(it.duracao) || 30))) : 0
  const tags = validTags(J<any>(b.data, {}), it.tags, it.tipo === 'servico' ? 'servico' : 'produto') // uma etiqueta por produto, existente e compatível
  const variacoes = (Array.isArray(it.variacoes) ? it.variacoes : []).slice(0, 6).map((v: any) => ({ nome: str(v.nome, 40), opcoes: (Array.isArray(v.opcoes) ? v.opcoes : []).slice(0, 12).map((o: any) => ({ nome: str(o.nome, 40), preco: Math.max(0, Number(o.preco) || 0) })).filter((o: any) => o.nome) })).filter((v: any) => v.nome && v.opcoes.length)
  // sinal antecipado: só em serviços sob orçamento (valor fixo em R$ ou % do valor de referência)
  let sinal: any = null
  if (tipo === 'servico' && modoPreco === 'orcamento' && it.sinal && it.sinal.ativo) {
    const st = it.sinal.tipo === 'pct' ? 'pct' : 'fixo', sv = Math.round((Number(it.sinal.valor) || 0) * 100) / 100
    if (!(sv > 0)) fail(400, 'Informe o valor do sinal.', 'invalid')
    if (st === 'pct' && (sv >= 100)) fail(400, 'A porcentagem do sinal deve ser menor que 100%.', 'invalid')
    if (st === 'pct' && !(preco > 0)) fail(400, 'Para sinal em porcentagem, informe o valor de referência do serviço.', 'invalid')
    if (st === 'fixo' && preco > 0 && sv >= preco) fail(400, 'O sinal deve ser menor que o valor de referência.', 'invalid')
    sinal = { ativo: true, tipo: st, valor: sv }
  }
  const rotuloBase = opcaoBase ? str(it.rotuloBase === undefined ? antes?.rotuloBase || '' : it.rotuloBase, 40) : ''
  const baseAtiva = opcaoBase ? (it.baseAtiva === undefined ? antes?.baseAtiva !== false : it.baseAtiva !== false) : true
  const palavras = String(it.palavras ?? '').split(/[,;\n]/).map((w: string) => str(w, 40).toLowerCase()).filter(Boolean).slice(0, 20).join(', ')
  const data = JSON.stringify({ nome, preco: Math.round(preco * 100) / 100, palavras, descricao: str(it.descricao, 600), categoria: str(it.categoria, 40) || (tipo === 'servico' ? 'Serviços' : 'Outros'), fotos, variacoes, tipo, modoPreco, duracao, tags, sinal, ...(oferta ? { oferta } : {}), ...(precoQtd ? { precoQtd } : {}), ...(origem ? { origem } : {}), ...(thumb ? { thumb } : {}),
    ...(opcaoBase ? { opcaoBase: true, ...(rotuloBase ? { rotuloBase } : {}), ...(baseAtiva === false ? { baseAtiva: false } : {}) } : {}) })
  // categoria nova digitada no produto ("Outra…") passa a fazer parte das categorias do catálogo (aparece na lista de seleção)
  { const cat = str(it.categoria, 40); const bx = (await dq.query('SELECT data FROM businesses WHERE id = $1', [b.id]))[0]; const xd = J<any>(bx?.data, {})
    if (cat && Array.isArray(xd.categorias) && xd.categorias.length && !xd.categorias.includes(cat) && xd.categorias.length < 60) { xd.categorias.push(cat); await dq.query('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(xd), b.id]) } }
  if (it.id) { await dq.query('UPDATE products SET data = $1, stock = $2, updated_at = $3 WHERE id = $4 AND business_id = $5', [data, stock, nowIso(), Number(it.id), b.id]); if (variantes) await CAT.gravarVariantes(dq, Number(it.id), Number(b.id), variantes); else if (tipo === 'servico') await dq.query('DELETE FROM product_variants WHERE product_id = $1', [Number(it.id)]); return Number(it.id) }
  const ins = await dq.query('INSERT INTO products (business_id, data, active, stock, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5) RETURNING id', [b.id, data, o.ativo !== false, stock, nowIso()])
  if (variantes && variantes.length) await CAT.gravarVariantes(dq, Number(ins[0].id), Number(b.id), variantes)
  return Number(ins[0].id)
}
export async function productsPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  if (nivelOf(await plans(), b.plan_id) < 4) fail(403, 'Produtos fazem parte do plano Loja completa.', 'forbidden')
  const it = ctx.body || {}
  if (it.action === 'delete') { await q('DELETE FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); return productsGet(ctx) }
  if (it.action === 'tags') { const p = await one('SELECT data FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) { const d = J<any>(p.data, {}); d.tags = validTags(J<any>(b.data, {}), it.tags, d.tipo); await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), Number(it.id)]) } return productsGet(ctx) }
  if (it.action === 'toggle') { const p = await one('SELECT active FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) await q('UPDATE products SET active = $1 WHERE id = $2', [typeof it.ativo === 'boolean' ? it.ativo : !(p.active === true || p.active === 1), Number(it.id)]); return productsGet(ctx) } // pausar/reativar (o interruptor do painel manda o estado desejado em "ativo"; sem ele, alterna como antes)
  await salvarProduto(b, it)
  return productsGet(ctx)
}

/* ---------- pedidos ---------- */
const NEXT: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['preparo', 'cancelado'], preparo: ['saiu', 'pronto', 'cancelado'], saiu: ['concluido', 'cancelado'], pronto: ['concluido', 'cancelado'] }
const NEXT_AG: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['concluido', 'cancelado'] }
const MSG: Record<string, string> = { aceito: 'foi aceito', preparo: 'está em preparo', saiu: 'saiu para entrega', pronto: 'está pronto para retirar', concluido: 'foi concluído', recusado: 'foi recusado', cancelado: 'foi cancelado' }
const orderOut = (o: any) => ({ id: Number(o.id), businessId: Number(o.business_id), status: o.status, total: Number(o.total), ...J<any>(o.data, {}), createdAt: o.created_at, updatedAt: o.updated_at })
/** Imagem de cada item nos painéis de pedidos: troca a miniatura crua por um endereço assinado (`/api/v2/pedidos/:id/itens/:i/foto`)
 *  que entrega a foto do cadastro do próprio item (ver lib/catalogo.ts → fotoDoItem). `foto: null` = sem imagem (espaço reservado).
 *  Quem recebeu o pedido na lista é quem pode ver a foto: a assinatura vale só para aquele pedido e aquele item. */
const fotoSig = (oid: number, i: number) => createHmac('sha256', process.env.SETTINGS_KEY || process.env.SESSION_SECRET || config.databaseUrl || 'meu-assistente').update(`pedido-foto:${oid}:${i}`).digest('hex').slice(0, 24)
export async function comFotos<T extends { id: number; itens?: any[] }>(saida: T[], linhas: any[]): Promise<T[]> {
  const cache = await CAT.fotosDosItens(linhas), porId = new Map(linhas.map((o) => [Number(o.id), o]))
  for (const o of saida) { const row = porId.get(Number(o.id)); if (!row || !Array.isArray(o.itens)) continue
    o.itens = o.itens.map((it: any, i: number) => ({ ...it, foto: CAT.fotoDoItem(row, i, cache) ? `/api/v2/pedidos/${o.id}/itens/${i}/foto?s=${fotoSig(Number(o.id), i)}` : null })) }
  return saida
}
export async function pedidoFotoGet(ctx: Ctx) {
  const oid = Number(ctx.params.id), i = Number(ctx.params.i)
  if (!Number.isInteger(oid) || !Number.isInteger(i) || i < 0 || String(ctx.query.get('s') || '') !== fotoSig(oid, i)) fail(404, 'Imagem não encontrada.', 'not_found')
  const o = await one('SELECT id, business_id, data FROM orders WHERE id = $1', [oid]); if (!o) fail(404, 'Imagem não encontrada.', 'not_found')
  const ped = o as any, src = CAT.fotoDoItem(ped, i, await CAT.fotosDosItens([ped]))
  if (src && /^https?:\/\//.test(src)) return { _binary: true, status: 302, headers: { Location: src } }
  const m = /^data:(image\/(?:png|jpe?g|webp|gif));base64,(.+)$/.exec(String(src || ''))
  if (!m) fail(404, 'Imagem não encontrada.', 'not_found')
  return { _binary: true, mime: m![1], data: Buffer.from(m![2], 'base64'), headers: { 'Cache-Control': 'private, max-age=600' } }
}
/** Itens do pedido com o preço de agora (variações incluídas) e o subtotal. Usado no pedido e na validação de cupom. */
export async function calcLinhas(b: any, itens: any[]) {
  const prods = await CAT.produtosParaPedido(Number(b!.id), productOut)
  const qtdDe = (it: any) => Math.min(99, Math.max(1, Math.floor(Number(it.qtd) || 1)))
  const somaPid = new Map<number, number>(); for (const it of itens) somaPid.set(Number(it.pid), (somaPid.get(Number(it.pid)) || 0) + qtdDe(it)) // preço por quantidade: soma do mesmo produto
  const linhas = itens.map((it) => {
    const p = prods.get(Number(it.pid)); if (!p || p.tipo === 'servico') fail(400, 'Um dos produtos não está mais disponível.', 'invalid')
    return CAT.linhaPedido(p, { vid: it.vid, escolhas: it.escolhas || {}, qtd: qtdDe(it), obs: it.obs, qtdTotal: somaPid.get(Number(it.pid)) }, unitPrice) // preço sempre do servidor (variação/oferta/faixa de agora)
  })
  CAT.conferirSomas(prods, linhas) // a soma do mesmo produto/variação no pedido não pode passar do estoque dela
  const sub = Math.round(linhas.reduce((a, l) => a + l.preco * l.qtd, 0) * 100) / 100
  return { linhas, sub }
}
/** Estoque atual dos itens do carrinho (ao adicionar, ao abrir o carrinho e antes de finalizar). Público como o catálogo. */
export async function cartCheckPost(ctx: Ctx) {
  await requireModule('empresas')
  const b = await one('SELECT id, status FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b || b.status !== 'ativo') fail(404, 'Loja não encontrada.', 'not_found')
  return checarCarrinho(b, ctx.body?.itens)
}
async function checarCarrinho(b: any, itens0: any) {
  const itens = (Array.isArray(itens0) ? itens0 : []).slice(0, 60).map((it: any) => ({ pid: Number(it?.pid ?? it?.produto_id), vid: Number(it?.vid ?? it?.variante_id) || null, qtd: Math.max(0, Math.min(999, Math.floor(Number(it?.qtd ?? it?.quantidade) || 0))) })).filter((it) => Number.isInteger(it.pid) && it.pid > 0)
  const prods = await CAT.produtosParaPedido(Number(b.id), productOut)
  const r = CAT.situacaoCarrinho(prods, itens)
  return { ok: r.every((x) => x.ok), itens: r }
}
export async function orderPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b || b.status !== 'ativo' || nivelOf(await plans(), b.plan_id) < 4) fail(404, 'Esta loja não está recebendo pedidos.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode fazer pedido na sua própria loja.', 'invalid')
  // Pedido agendado (Permissões de Agendamento → Agendamento de pedidos): só quando a empresa ligou e a pessoa está autorizada
  let agendadoPara: { data: string; hora: string } | null = null
  if (ctx.body?.agendarPara) { const ac = await acesso(b, 'pedidos', u.id); if (!ac.ok) fail(403, ac.motivo || 'Agendamento de pedidos indisponível.', ac.codigo || 'forbidden'); agendadoPara = validarAgendadoPara(b, ctx.body.agendarPara) }
  if (!agendadoPara && !openState(J<any>(b!.data, {})).aberto) fail(400, 'A loja está fechada agora. Veja o horário de funcionamento.', 'closed')
  const x = J<any>(b!.data, {}), E = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  P.online = !!(P.online && (await mpPronto(b)))
  if (!allowsKind(x, 'produto')) fail(400, 'Esta empresa trabalha só com serviços (agendamentos), sem pedidos de produtos.', 'invalid')
  const body = ctx.body || {}, itens: any[] = Array.isArray(body.itens) ? body.itens.slice(0, 50) : []
  if (!itens.length) fail(400, 'Seu pedido está vazio.', 'invalid')
  const { linhas, sub } = await calcLinhas(b, itens)
  const modo = body.modo === 'entrega' ? 'entrega' : 'retirada'
  if (modo === 'entrega' && !E.entrega) fail(400, 'Esta loja não faz entregas.', 'invalid')
  if (modo === 'retirada' && !E.retirada) fail(400, 'Esta loja não tem retirada no local.', 'invalid')
  if (E.minimo && sub < E.minimo) fail(400, `Pedido mínimo: R$ ${Number(E.minimo).toFixed(2).replace('.', ',')}.`, 'invalid')
  const endereco = modo === 'entrega' ? str(body.endereco, 200) : ''
  if (modo === 'entrega' && endereco.length < 6) fail(400, 'Informe o endereço de entrega.', 'invalid')
  // "Usar minha localização atual" no checkout: o ponto confirmado pelo cliente vira o local da entrega (área, taxa por km e mapa
  // para a loja). Sem ele, vale a localização salva do cliente, como antes.
  const el = body.entregaLoc && typeof body.entregaLoc === 'object' ? { lat: Number(body.entregaLoc.lat), lng: Number(body.entregaLoc.lng), precisao: Math.round(Number(body.entregaLoc.precisao) || 0) } : null
  if (el && !validCoords(el.lat, el.lng)) fail(400, 'A localização de entrega é inválida. Use a localização de novo ou digite o endereço.', 'invalid')
  const entregaLoc = modo === 'entrega' && el ? { lat: Math.round(el.lat * 1e6) / 1e6, lng: Math.round(el.lng * 1e6) / 1e6, ...(el.precisao > 0 ? { precisao: Math.min(el.precisao, 100000) } : {}) } : null
  const locEntrega = async () => entregaLoc || await userLocation(u.id)
  const pe = body.enderecoPartes && typeof body.enderecoPartes === 'object' ? body.enderecoPartes : null
  const enderecoPartes = modo === 'entrega' && pe ? Object.fromEntries(['rua', 'numero', 'complemento', 'bairro', 'cidade', 'referencia'].map((k) => [k, str(pe[k], k === 'numero' ? 12 : 80)]).filter(([, v]) => v)) : null
  if (modo === 'entrega' && b!.lat != null) { const loc = await locEntrega(); if (loc) { const d = distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }); if (d > Number(E.raio || 3)) fail(400, `Este endereço fica a ${d.toFixed(1).replace('.', ',')} km, fora da área de entrega desta loja (até ${String(Number(E.raio || 3)).replace('.', ',')} km).`, 'fora_area') } }
  // CRÉDITO DA LOJA (lib/credito-loja.ts): forma extra, liberada só para empresa autorizada pelo ADM e cliente com limite
  const pag = body.pagamento === 'credito' ? 'credito' : ['pix', 'pixentrega', 'cartao', 'dinheiro', 'online'].includes(body.pagamento) && P[body.pagamento] ? body.pagamento : null
  if (!pag) fail(400, 'Escolha uma forma de pagamento aceita pela loja.', 'invalid')
  if (pag === 'online' && !(await mpPronto(b))) fail(400, 'O Pix automático desta loja não está disponível agora. Escolha outra forma de pagamento.', 'invalid') // método desativado/desconectado: recusado antes de criar o pedido
  let taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0
  if (modo === 'entrega' && E.modoTaxa === 'km') { const loc = await locEntrega(); if (!loc || b!.lat == null) fail(400, 'Para calcular a entrega por distância, toque em "Usar minha localização atual" no endereço de entrega.', 'need_location'); taxa = deliveryFee(E, distKm(loc!, { lat: Number(b!.lat), lng: Number(b!.lng) })) }
  // MCoins da própria empresa: valida saldo e limite; o débito acontece junto da criação do pedido
  // cupom de desconto da própria empresa: validado por completo antes de criar o pedido
  const idem0 = str(body.idem, 40)
  if (idem0 && body.cupom) { const ex0 = (await q("SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 AND status IN ('aguardando_pagamento','aguardando_credito','novo') ORDER BY id DESC LIMIT 5", [b!.id, u.id])).find((r) => J<any>(r.data, {}).idem === idem0); if (ex0) return { order: orderOut(ex0) } } // toque duplo: devolve o mesmo pedido antes de revalidar o cupom
  const CP = await import('../lib/coupons.js'), cupomCod = str(body.cupom, 30)
  const cup = cupomCod ? await CP.validar(Number(b!.id), u.id, cupomCod, linhas.map((l) => ({ pid: l.pid, qtd: l.qtd, preco: l.preco }))) : null
  // INCENTIVO DO CARRINHO (lib/incentivos.ts): recalculado aqui, com as regras da empresa — no máximo um por pedido, o melhor
  // para o cliente; com cupom, só os que somam com cupom; frete grátis zera a taxa; desconto sai dos produtos; cashback vira
  // MCoins quando o pedido for pago/concluído. O que a vitrine mostrou é o que vale aqui (mesma regra).
  const INC = await import('../lib/incentivos.js')
  const incAv = await INC.paraPedido(Number(b!.id), u.id, { subtotal: sub, itens: linhas.reduce((a, l: any) => a + (Number(l.qtd) || 0), 0), modo, taxa, temCupom: !!cup, entrega: !!E.entrega })
  const incentivo = incAv.registro
  if (incentivo?.freteGratis) taxa = 0
  const descInc = Math.min(Number(incentivo?.desconto) || 0, Math.max(0, Math.round((sub - (cup?.desconto || 0)) * 100) / 100)) // nunca passa do que sobrou dos produtos
  if (incentivo) incentivo.desconto = descInc
  const moedasQtd = Math.max(0, Math.floor(Number(body.moedas) || 0))
  if (cup && moedasQtd > 0 && !cup.coupon.combinaMoedas) fail(400, 'Este cupom não pode ser usado junto com MCoins. Use só um dos dois.', 'invalid', 'cupom')
  const uso = moedasQtd > 0 ? await (await import('../lib/coins.js')).previewUso(Number(b!.id), u.id, moedasQtd, Math.round((sub - (cup?.desconto || 0) - descInc) * 100) / 100, Number(body.moedaId) || undefined) : null // as moedas só descontam o que sobrou depois do cupom e do incentivo
  const total = Math.round((sub + taxa - (cup?.desconto || 0) - descInc - (uso?.desconto || 0)) * 100) / 100
  if ((uso || cup) && pag === 'online' && total <= 0) fail(400, 'Com o desconto total, escolha outra forma de pagamento (o Pix online precisa de valor).', 'invalid', 'moedas')
  if (pag === 'credito' && total <= 0) fail(400, 'Com o desconto total, escolha outra forma de pagamento.', 'invalid')
  const zap = String(body.telefone || u.whatsapp || '').replace(/\D/g, '')
  if (zap.length < 10 || zap.length > 13) fail(400, 'Informe seu WhatsApp com DDD para a empresa falar com você.', 'invalid', 'telefone')
  body.telefone = zap.length <= 11 ? `+55${zap}` : `+${zap}`
  // mesmo pedido enviado duas vezes (toque duplo, rede lenta): devolve o mesmo, sem duplicar
  const idem = str(body.idem, 40)
  if (idem) { const ex = (await q("SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 AND status IN ('aguardando_pagamento','aguardando_credito','novo') ORDER BY id DESC LIMIT 5", [b!.id, u.id])).find((r) => J<any>(r.data, {}).idem === idem); if (ex) return { order: orderOut(ex) } }
  // crédito: simulação refeita aqui, aceite e total conferidos, limite conferido (de novo, sob trava, ao gravar a operação)
  const CL = pag === 'credito' ? await import('../lib/credito-loja.js') : null
  const cred = CL ? await CL.prepararCompra(Number(b!.id), u.id, total, body.credito) : null
  const st0 = pag === 'online' ? 'aguardando_pagamento' : cred?.manual ? 'aguardando_credito' : 'novo'
  // estoque (quando controlado): débito atômico agora; devolvido se o pedido não se concretizar
  const reservas = await CAT.reservarEstoque(linhas)
  const data = { idem, andamento: [{ status: st0, em: nowIso() }], ...(cred ? { credito: { parcelas: cred.sim.nParcelas, entrada: cred.sim.entrada, totalFinal: cred.sim.totalFinal, resumo: cred.sim.resumo, status: cred.manual ? 'pendente' : 'ativa' } } : {}), itens: linhas, subtotal: sub, taxa, ...(incentivo ? { incentivo } : {}), ...(reservas.length ? { estoque: reservas } : {}), cupom: cup ? { id: cup.coupon.id, codigo: cup.coupon.codigo, nome: cup.coupon.nome, desconto: cup.desconto } : undefined, moedas: uso ? { coinId: uso.coin.id, simbolo: uso.coin.simbolo, qtd: moedasQtd, desconto: uso.desconto, emissoraId: uso.coin.businessId, emissora: uso.coin.empresa, vinculadaId: Number(b!.id), vinculo: uso.vinculo || undefined } : undefined, modo, endereco, ...(entregaLoc ? { entregaLoc } : {}), ...(enderecoPartes && Object.keys(enderecoPartes).length ? { enderecoPartes } : {}), pagamento: pag, obs: str(body.obs, 300), troco: pag === 'dinheiro' ? trocoTxt(body, total) : '', cliente: str(body.nome, 80) || u.name, telefone: str(body.telefone, 30) || u.whatsapp, empresa: x.empresa, motivo: '', ...(agendadoPara ? { agendadoPara } : {}) }
  try { await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, st0, total, JSON.stringify(data), nowIso()]) } catch (e) { await CAT.devolverEstoque(reservas); throw e }
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  void (await import('../lib/descobrir.js')).registrar(u.id, (Array.isArray(body.itens) ? body.itens : []).slice(0, 20).map((it: any) => ({ t: 'pedido', k: 'p', id: Number(it.pid), bid: Number(b!.id) }))).catch(() => {}) // interesse (Descobrir): só do próprio cliente
  if (cup) { try { await CP.resgatar(cup, u.id, Number(o.id), total, uso?.desconto || 0, pag === 'online') } catch (e) { await CAT.devolverEstoque(reservas); await q('DELETE FROM orders WHERE id = $1', [o.id]); throw e } }
  if (uso) { try { await (await import('../lib/coins.js')).resgatar(uso.coin.id, u.id, moedasQtd, Number(o.id), uso.desconto, Number(b!.id)) } catch (e) { if (cup) await CP.estornarPedido(Number(o.id)).catch(() => {}); await CAT.devolverEstoque(reservas); await q('DELETE FROM orders WHERE id = $1', [o.id]); throw e } }
  let opCred: any = null
  if (cred && CL) { // operação de crédito (uma por pedido): se o limite não fechar agora, o pedido é desfeito como nos outros casos
    try { opCred = await CL.registrarCompra(Number(o.id), Number(b!.id), u.id, cred); const dd = { ...J<any>(o.data, {}), credito: { ...data.credito, operacaoId: Number(opCred.id) } }; await q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(dd), o.id]); o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))! }
    catch (e) { if (uso) await (await import('../lib/coins.js')).estornarPedido(Number(o.id)).catch(() => {}); if (cup) await CP.estornarPedido(Number(o.id)).catch(() => {}); await CAT.devolverEstoque(reservas); await q('DELETE FROM orders WHERE id = $1', [o.id]); throw e }
  }
  if (pag === 'online') { // Pix automático pelo Mercado Pago da própria loja: o pedido só vai para a empresa depois da aprovação
    try { await createOrderPix(b, o, u.email, total) }
    catch (e: any) { if (uso) await (await import('../lib/coins.js')).estornarPedido(Number(o.id)).catch(() => {}); if (cup) await CP.estornarPedido(Number(o.id)).catch(() => {}); await CAT.devolverEstoque(reservas); await q('DELETE FROM orders WHERE id = $1', [o.id]); fail(502, 'Não foi possível gerar o Pix da loja agora. Escolha outra forma de pagamento.', 'mp_error') }
    o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!
  }
  // vínculo com o CRM só depois que o pedido é definitivo (cupom, moedas e Pix confirmados): se algum deles falha o pedido é
  // desfeito, e o vínculo em segundo plano não pode chegar depois e deixar no CRM um pedido que não existe mais
  crmLink(o?.id)
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  if (body.aceitaMarketing === true) await (await import('../lib/marketing.js')).setConsent(Number(b!.owner_id), u.id, true, 'pedido:' + o.id).catch(() => {})
  if (agendadoPara) await audit(u.id, 'empresa.pedido.agendado', Number(b!.id), { pedido: Number(o.id), ...agendadoPara })
  // aviso do pedido novo pelos canais que a empresa escolheu (painel e/ou WhatsApp) — lib/recebimento-pedidos.ts
  if (opCred && CL) await CL.avisarCompra(opCred, Number(o.id)) // cliente (compra/solicitação) e, se for manual, o dono (solicitação)
  if (st0 === 'novo') await (await import('../lib/recebimento-pedidos.js')).avisarNovoPedido(Number(b!.id), Number(o.id), { title: `${agendadoPara ? 'Novo pedido agendado' : 'Novo pedido'} #${o.id} · R$ ${total.toFixed(2).replace('.', ',')}${pag === 'credito' ? ' · Crédito da Loja' : ''}`, body: `${data.cliente} · ${modo === 'entrega' ? 'entrega' : 'retirada'}${agendadoPara ? ` · para ${brDia(agendadoPara.data)} às ${agendadoPara.hora}` : ''}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  // forma WhatsApp sem envio automático: o cliente é levado ao WhatsApp da empresa com o pedido pronto (Pix automático: o aviso sai na aprovação)
  const whatsapp = st0 === 'novo' ? await (await import('../lib/recebimento-pedidos.js')).linkCliente(Number(b!.id), Number(o.id)).catch(() => null) : null
  return { order: orderOut(o), ...(whatsapp ? { whatsapp } : {}) }
}
export async function myOrdersGet(ctx: Ctx) {
  const u = requireUser(ctx), items = (await q('SELECT * FROM orders WHERE customer_id = $1 ORDER BY id DESC LIMIT 60', [u.id])).map(orderOut).filter((o: any) => !o.guest).slice(0, 50)
  // dados ATUAIS da empresa conforme a modalidade: retirada → endereço completo, mapa e WhatsApp; entrega → só o contato
  const ids = [...new Set(items.filter((o: any) => o.tipo !== 'agendamento').map((o: any) => o.businessId))]
  const bs = new Map((ids.length ? await q(`SELECT id, lat, lng, data FROM businesses WHERE id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids) : []).map((b: any) => [Number(b.id), b]))
  for (const o of items as any[]) { if (o.tipo === 'agendamento') continue; const b = bs.get(o.businessId); if (!b) continue; o.loja = lojaDoPedido(b, o.modo) }
  // concluídos: link de avaliação no Google da empresa, se ela ativou (botão opcional ao lado da avaliação interna)
  const conc = [...new Set(items.filter((o: any) => o.status === 'concluido').map((o: any) => o.businessId))]
  if (conc.length) { const R = await import('../lib/reputacao.js'), gs = new Map((await q(`SELECT id, data FROM businesses WHERE id IN (${conc.map((_, i) => '$' + (i + 1)).join(',')})`, conc)).map((b: any) => [Number(b.id), R.reputacaoDe(J<any>(b.data, {})).google]))
    for (const o of items as any[]) { const g = o.status === 'concluido' ? gs.get(o.businessId) : null; if (g?.ativo) o.googleAvaliacao = g.url } }
  return { items }
}
/** O que o cliente precisa da loja em cada modalidade (sem nada da outra): retirada = onde retirar e como falar; entrega = como a loja fala com ele. */
export function lojaDoPedido(b: any, modo: string) {
  const x = J<any>(b.data, {}), zap = String(x.zap || '').replace(/\D/g, '')
  const contato = { empresa: x.empresa || '', zap: zap.length >= 10 ? (zap.length <= 11 ? '55' + zap : zap) : '' }
  if (modo === 'entrega') return contato
  const temLoc = b.lat != null && b.lng != null && Number.isFinite(Number(b.lat))
  const horario = String(x.horario || '').trim(), semDias = horario === 'Fechado' // "Fechado" = nenhum dia marcado (loja aberta/fechada pelo botão): não informa nada
  return { ...contato, endereco: String(x.endereco || '').trim(), ...(x.referencia ? { referencia: String(x.referencia) } : {}), horario: semDias ? '' : horario, mapa: temLoc ? `https://www.google.com/maps/search/?api=1&query=${Number(b.lat)},${Number(b.lng)}` : x.endereco ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(String(x.endereco))}` : '' }
}
export async function businessOrdersGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); const rows = await q("SELECT * FROM orders WHERE business_id = $1 AND status NOT IN ('aguardando_pagamento','aguardando_credito') ORDER BY id DESC LIMIT 200", [b.id]); return { items: await comFotos(rows.map(orderOut), rows) } }
export async function businessOrderPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx)
  await mudarStatusPedido(b, Number(ctx.params.oid), String(ctx.body?.status || ''), str(ctx.body?.motivo, 200), { id: u.id, nome: u.name || '' })
  return businessOrdersGet(ctx)
}
/** Próximas situações possíveis de um pedido/agendamento (mesma regra da tela da loja e da central de Lojas Conectadas). */
export const transicoes = (o: any) => { const d = J<any>(o.data, {}); return ((d.tipo === 'agendamento' ? NEXT_AG : NEXT)[o.status] || []).filter((s) => d.tipo === 'agendamento' || !(s === 'saiu' && d.modo !== 'entrega') && !(s === 'pronto' && d.modo === 'entrega')) as string[] }
/** Andamento do pedido: cada mudança de situação com data e hora (o cliente acompanha em Meus pedidos). */
const comAndamento = (d: any, status: string) => ({ ...d, andamento: [...(Array.isArray(d.andamento) ? d.andamento : []), { status, em: nowIso() }].slice(-20) })
export const pedidoOut = (o: any) => orderOut(o)
/** Muda a situação de um pedido (dono da loja ou central conectada, já autorizados por quem chama). */
export async function mudarStatusPedido(b: any, oid: number, to: string, motivo: string, ator: { id: number; nome: string }) {
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [oid, b.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const ag = J<any>(o!.data, {}).tipo === 'agendamento'
  if (!transicoes(o).includes(to)) { const pode = !ag && (NEXT[o!.status] || []).includes(to); fail(400, pode && to === 'saiu' ? 'Este pedido é para retirada: use "Pronto para retirar".' : pode && to === 'pronto' ? 'Este pedido é para entrega: use "Saiu para entrega".' : 'Mudança de situação inválida.', 'invalid') }
  if ((to === 'recusado' || to === 'cancelado') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  const d = comAndamento({ ...J<any>(o!.data, {}), motivo }, to)
  // condicional: duas pessoas (loja e central) mudando ao mesmo tempo não aplicam a mesma transição duas vezes
  const ok = await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4 AND status = $5 RETURNING id', [to, JSON.stringify(d), nowIso(), o!.id, o!.status])
  if (!ok.length) fail(409, 'Este pedido acabou de ser atualizado por outra pessoa. Atualize a tela.', 'conflito')
  await syncBookingStatus(Number(o!.id), to).catch((e) => console.error('[agenda]', e?.message))
  if (to === 'recusado' || to === 'cancelado') await (await import('../lib/coupons.js')).estornarPedido(Number(o!.id)).catch((e) => console.error('[cupons]', e?.message)) // o cupom volta ao estoque e ao cliente
  if (to === 'recusado' || to === 'cancelado') await CAT.devolverPedido(Number(o!.id)).catch((e) => console.error('[estoque]', e?.message)) // as unidades voltam ao estoque
  if (to === 'recusado' || to === 'cancelado') await (await import('../lib/coins.js')).estornarPedido(Number(o!.id)).catch((e) => console.error('[moedas]', e?.message)) // devolve as moedas usadas, uma única vez
  if ((to === 'recusado' || to === 'cancelado') && d.pagamento === 'credito') await (await import('../lib/credito-loja.js')).cancelarPorPedido(Number(o!.id), motivo, ator.id).catch((e) => console.error('[credito]', e?.message)) // parcelas em aberto canceladas, limite liberado
  if (to === 'concluido') await recordOrderIncome(Number(o!.id), 'concluido').catch((e) => console.error('[financeiro]', e?.message))
  if (to === 'concluido') await (await import('../lib/followup.js')).scheduleFollowup(Number(o!.id)).catch((e) => console.error('[follow-up]', e?.message)) // só pedidos/agendamentos concluídos
  if (!J<any>(o!.data, {}).guest) await notify(Number(o!.customer_id), { type: 'order', title: ag ? `Agendamento #${o!.id} ${to === 'aceito' ? 'foi confirmado' : MSG[to]}` : `Pedido #${o!.id} ${MSG[to]}`, body: `${d.empresa}${motivo ? ' · ' + motivo : ''}`, link: '/x/pedidos', ref: `order:${o!.id}:${to}` })
  await (await import('../lib/lojas-conectadas.js')).avisarAtualizacao(b, Number(o!.id), to, ator.id, ator.nome) // dono e centrais conectadas (menos quem mudou)
  await audit(ator.id, 'empresa.pedido.status', Number(b.id), { pedido: Number(o!.id), de: o!.status, para: to })
}

/* ---------- Mercado Pago da loja (pagamento automático dos pedidos) ---------- */
/** Conexão utilizável para cobrar: token salvo e sem erro de conexão (OAuth revogado/expirado não oferece Pix automático). */
export const mpOk = (x: any) => !!(x?.mpTok && x.mpStatus !== 'erro')
/** Conexão utilizável da EMPRESA (lida da integração salva, não do JSON da empresa). */
export const mpPronto = async (b: any) => !!b && (await import('./mpuser.js')).mpPronto(Number(b.id))
const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
async function storeToken(b: any) {
  // OAuth: renova antes de vencer e não usa conexão com erro; manual: o Access Token salvo
  return (await import('./mpuser.js')).tokenLoja(b)
}
export async function createOrderPix(b: any, o: any, email: string, total: number, novo = false) {
  const tok = await storeToken(b); if (!tok) throw new Error('sem token')
  const exp = await pixExpiry()
  const x = J<any>(b.data, {})
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `order-${o.id}${novo ? '-' + Date.now() : ''}` },
    body: JSON.stringify({ transaction_amount: total, description: `Pedido #${o.id} · ${x.empresa}`, payment_method_id: 'pix', payer: { email: email || `pedido${o.id}@clientes.meuassistente.app` }, date_of_expiration: exp.iso, external_reference: `order:${o.id}`, notification_url: `${pub()}/api/mercadopago/webhook?store=${b.id}` }) })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp-loja] Pix:', r.status, JSON.stringify(p)?.slice(0, 200)); throw new Error('mp') }
  const td = p.point_of_interaction?.transaction_data || {}
  const d = { ...J<any>(o.data, {}), payment: { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }, pago: p.status === 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
}
/** Situação do Pix vinda do Mercado Pago (pendente, recusado, cancelado, expirado) — nunca aprova sem confirmação real. */
async function markOrderPayment(o: any, status: string) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment) return
  if (d.payment.status === status) return
  d.payment = { ...d.payment, status }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
  if (['rejected', 'cancelled', 'expired'].includes(status)) await CAT.devolverPedido(Number(o.id)).catch((e) => console.error('[estoque]', e?.message)) // Pix não pago: as unidades reservadas voltam
  if (['rejected', 'cancelled', 'expired'].includes(status) && !d.guest) await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} não aprovado`, body: `${d.empresa} · gere um novo Pix em Meus pedidos ou escolha outra forma de pagamento`, link: '/x/pedidos', ref: `order-pay-${status}:${o.id}:${d.payment.id}` })
}
/** Confirmação do pagamento: processada UMA vez por pedido (webhook repetido, simultâneo ou junto da consulta do cliente).
 *  Quem grava a linha em mp_pagamentos_processados primeiro processa; se falhar no meio, a linha sai e a próxima tentativa
 *  processa de novo (o Mercado Pago reenvia a notificação quando a resposta não é 2xx). */
async function markOrderPaid(o: any) {
  const d0 = J<any>(o.data, {}); if (d0.pago) return
  const ganhou = await q('INSERT INTO mp_pagamentos_processados (business_id, order_id, payment_id, evento, processado_em) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING RETURNING order_id', [o.business_id, o.id, String(d0.payment?.id || ''), 'approved', nowIso()])
  if (!ganhou.length) return
  try { const atual = await one('SELECT * FROM orders WHERE id = $1', [o.id]); if (!atual || J<any>(atual.data, {}).pago) return; await markOrderPaid0(atual) }
  catch (e) { await q('DELETE FROM mp_pagamentos_processados WHERE order_id = $1 AND evento = $2', [o.id, 'approved']).catch(() => null); throw e }
}
async function markOrderPaid0(o: any) {
  const d = J<any>(o.data, {}); if (d.pago) return
  d.pago = true; d.payment = { ...(d.payment || {}), status: 'approved' }
  await q('UPDATE orders SET data = $1, status = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(d), o.status === 'aguardando_pagamento' ? 'novo' : o.status, nowIso(), o.id])
  await (await import('../lib/coupons.js')).confirmarPedido(Number(o.id)).catch((e) => console.error('[cupons]', e?.message)) // reserva do cupom vira uso definitivo
  const faltou = await CAT.retomarPedido(Number(o.id)).catch((e) => { console.error('[estoque]', e?.message); return [] as { nome: string; faltam: number }[] }) // pago depois de o Pix vencer: debita de novo (nunca negativo)
  await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message)) // agendamento com sinal: entra na Agenda quando o Pix é aprovado
  await recordOrderIncome(Number(o.id), 'pago_online').catch((e) => console.error('[financeiro]', e?.message)) // dinheiro recebido → lançamento de entrada
  const b = await one('SELECT id, owner_id FROM businesses WHERE id = $1', [o.business_id])
  const avisoPago = { type: 'order', title: `Novo pedido #${o.id} · PAGO · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'} · Pix confirmado`, link: '/x/sua-empresa', ref: `order-paid:${o.id}` }
  if (b && d.tipo !== 'agendamento') await (await import('../lib/recebimento-pedidos.js')).avisarNovoPedido(Number(b.id), Number(o.id), avisoPago) // pedido: canais da empresa
  if (b && faltou.length) await notify(Number(b.owner_id), { type: 'order', title: `Pedido #${o.id} pago sem estoque suficiente`, body: `O Pix foi pago depois de vencer e faltam: ${faltou.map((f) => `${f.faltam}× ${f.nome}`).join(', ')}. Combine com o cliente a troca ou a devolução do valor.`, link: '/x/sua-empresa', ref: `order-falta:${o.id}` })
  else if (b) await notify(Number(b.owner_id), avisoPago) // agendamento com sinal: como antes
  if (!d.guest) await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} confirmado`, body: d.empresa, link: '/x/pedidos', ref: `order-paid-c:${o.id}` })
}
async function checkOrderPayment(o: any) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment?.id) return d.pago ? 'approved' : 'none'
  const b = await one('SELECT * FROM businesses WHERE id = $1', [o.business_id]); if (!b) return 'none'
  const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(d.payment.id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
  const p: any = await r.json().catch(() => ({}))
  if (r.ok && p.status === 'approved' && String(p.external_reference) === `order:${o.id}`) { await markOrderPaid(o); return 'approved' }
  if (r.ok && String(p.external_reference) === `order:${o.id}` && ['rejected', 'cancelled', 'expired', 'pending', 'in_process'].includes(p.status)) await markOrderPayment(o, p.status)
  return p.status || 'unknown'
}
export async function orderPayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown'), d = J<any>(o!.data, {})
  return { status: st, payment: d.payment ? { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt } : null, expirado: !d.pago && !pixValid(d.payment), total: Number(o!.total) }
}
export async function orderPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const d = J<any>(o!.data, {}); if (d.pago) return orderPayGet(ctx)
  if (['cancelado', 'recusado', 'concluido'].includes(o!.status)) fail(400, 'Este pedido não aceita mais pagamento.', 'invalid')
  if (['aguardando_aprovacao', 'sugestao'].includes(o!.status)) fail(400, 'O pagamento fica disponível depois que a empresa aprovar a solicitação.', 'invalid')
  if (!pixValid(d.payment) || ['rejected', 'cancelled', 'expired'].includes(d.payment?.status)) {
    const b = await one('SELECT * FROM businesses WHERE id = $1', [o!.business_id])
    // a reserva voltou ao estoque quando o Pix anterior venceu/foi recusado: reserva de novo ANTES de cobrar (sem estoque, recusa)
    const tinhaDevolvido = !!d.estoqueDevolvido
    await CAT.reservarDeNovo(Number(o!.id))
    const o2 = (await one('SELECT * FROM orders WHERE id = $1', [o!.id]))!
    try { await createOrderPix(b, o2, u.email, Number(o2.total), true) }
    catch (e) { if (tinhaDevolvido) await CAT.devolverPedido(Number(o!.id)).catch(() => {}); throw e }
  }
  return orderPayGet(ctx)
}
export async function storeWebhook(ctx: Ctx) {
  // Notificação de pagamento de uma loja (notification_url = /api/mercadopago/webhook?store=<empresa>, posta no pagamento criado).
  //  • autenticidade: assinatura x-signature com a chave da aplicação dona da credencial (OAuth → aplicação do sistema; manual →
  //    a da empresa); assinatura inválida → 401 (como orienta o Mercado Pago). E a confirmação NUNCA vem do corpo: o pagamento é
  //    consultado na API com o token DESTA empresa e precisa ser do pedido DESTA empresa;
  //  • idempotência: markOrderPaid processa uma vez por pedido (mp_pagamentos_processados);
  //  • falha temporária (sem rede, 5xx/429 do Mercado Pago, erro ao gravar) → 503, e o Mercado Pago reenvia depois.
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const tipo = String(ctx.query.get('type') || ctx.body?.type || ctx.query.get('topic') || '')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.query.get('store'))])
  if (!id || !b || (tipo && tipo !== 'payment')) return { ok: true }
  const M = await import('./mpuser.js'), d = await M.mpDe(Number(b.id)), sec = await M.segredoWebhookLoja(d)
  if (sec) {
    const sig = String(ctx.req.headers['x-signature'] || ''), rid = String(ctx.req.headers['x-request-id'] || '')
    const ts = /ts=([^,]+)/.exec(sig)?.[1]?.trim() || '', v1 = /v1=([^,]+)/.exec(sig)?.[1]?.trim() || ''
    const { createHmac, timingSafeEqual } = await import('node:crypto')
    // manifesto oficial: id:<data.id>;request-id:<x-request-id>;ts:<ts>; — o par ausente é omitido; data.id alfanumérico em minúsculas
    const manifesto = `id:${/^[a-z0-9]+$/i.test(id) ? id.toLowerCase() : id};` + (rid ? `request-id:${rid};` : '') + (ts ? `ts:${ts};` : '')
    const calc = createHmac('sha256', sec).update(manifesto).digest('hex')
    if (!v1 || v1.length !== calc.length || !timingSafeEqual(Buffer.from(v1), Buffer.from(calc))) { console.error(`[mp-loja] empresa ${b.id}: notificação com assinatura inválida recusada (401)`); fail(401, 'Assinatura inválida.', 'bad_signature') }
  }
  const tok = await storeToken(b); if (!tok) return { ok: true } // empresa desconectada: nada a confirmar com esta conta
  let r: Response
  try { r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${tok}` }, signal: AbortSignal.timeout(15_000) }) }
  catch { console.error(`[mp-loja] empresa ${b.id}: Mercado Pago sem resposta ao conferir a notificação; será reenviada`); fail(503, 'Mercado Pago indisponível; reenvie a notificação.', 'mp_indisponivel') }
  if (r!.status >= 500 || r!.status === 429) fail(503, 'Mercado Pago indisponível; reenvie a notificação.', 'mp_indisponivel')
  if (!r!.ok) return { ok: true } // 404/401: o pagamento não é desta conta Mercado Pago — ignorado
  const p: any = await r!.json().catch(() => ({}))
  // cobrança avulsa criada pelo chat (lib/cobrancas.ts): mesma conferência — consultada na API com o token DESTA empresa,
  // e a cobrança precisa ser desta empresa, com o mesmo pagamento e o mesmo valor
  if (/^cob:\d+$/.test(String(p.external_reference || ''))) {
    try { await (await import('../lib/cobrancas.js')).aplicarPagamento(b, p) }
    catch (e: any) { console.error(`[cobranças] empresa ${b.id}: falha ao processar a notificação (${e?.message}); será reprocessada`); fail(503, 'Falha ao processar; reenvie a notificação.', 'reprocessar') }
    return { ok: true }
  }
  const oid = String(p.external_reference || '').replace('order:', '')
  // o pedido precisa ser desta empresa e o pagamento precisa ser o que foi gerado para ele
  const o = /^\d+$/.test(oid) ? await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(oid), b.id]) : null
  if (!o || String(p.external_reference) !== `order:${o.id}` || String(J<any>(o.data, {}).payment?.id || '') !== String(p.id)) return { ok: true }
  try { if (p.status === 'approved') await markOrderPaid(o); else await markOrderPayment(o, String(p.status || '')) }
  catch (e: any) { console.error(`[mp-loja] empresa ${b.id}: falha ao processar o pedido ${o.id} (${e?.message}); será reprocessado`); fail(503, 'Falha ao processar; reenvie a notificação.', 'reprocessar') }
  return { ok: true }
}
/** Onde a empresa recebe os novos pedidos (painel e/ou WhatsApp): ver, alterar e enviar uma mensagem de teste. */
export async function recebimentoGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return (await import('../lib/recebimento-pedidos.js')).situacao(b) }
export async function recebimentoPut(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), R = await import('../lib/recebimento-pedidos.js')
  await R.salvar(b, ctx.body || {})
  return R.situacao((await one('SELECT * FROM businesses WHERE id = $1', [b.id]))!)
}
export async function recebimentoTestePost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), W = await import('../lib/whatsapp-envio.js'), R0 = await import('../lib/recebimento-pedidos.js'), x = J<any>(b.data, {}), para = W.numeroWhats(x.zap)
  if (!(await R0.liberadoGlobal())) fail(403, R0.RECURSO_OFF, 'recurso_desativado')
  if (!para) fail(400, 'Cadastre o WhatsApp da empresa (com DDD) para receber os pedidos por lá.', 'sem_numero')
  if (!(await W.configurado())) fail(409, 'O envio automático pelo WhatsApp ainda não foi liberado pelo administrador do sistema.', 'whatsapp_indisponivel')
  const r = await W.enviarTexto(para, `✅ Teste do Meu Assistente: os novos pedidos de ${x.empresa || 'sua empresa'} chegam aqui pelo WhatsApp, com itens, valores, cliente e entrega/retirada.`)
  return r.ok ? { ok: true, message: `Mensagem de teste enviada para ${R0.fmtNumero(para)}. Confira o WhatsApp da empresa.` } : { ok: false, message: `Não foi possível enviar: ${r.erro}` }
}
export async function storeMpPost(ctx: Ctx) {
  // integração lida e gravada em empresa_integracoes (por empresa; ownBusiness garante que é do usuário)
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, M = await import('./mpuser.js'), bid = Number(b.id)
  const d = await M.mpDe(bid)
  if (body.action === 'status') return mpView(b, d, await M.planAllowed(b))
  if (['oauth', 'connect', undefined, ''].includes(body.action)) { const bl = await M.motivoBloqueio(b); if (bl) fail(403, bl.mensagem, bl.codigo) }
  if (body.action === 'oauth') return { url: await M.businessAuthUrl(Number((ctx as any).user?.id || 0), bid) }
  if (body.action === 'cancelar_autorizacao') { await M.cancelarAutorizacao(bid); return { ok: true, message: 'Conexão automática cancelada. Nada foi alterado.', ...(await mpView(b, d, await M.planAllowed(b))) } }
  if (body.action === 'test' || body.action === 'verificar') {
    if (!d.mpTok) return { ok: false, message: 'Nenhuma conta Mercado Pago conectada.', ...(await mpView(b, d, await M.planAllowed(b))) }
    const r = await M.verificarLoja(b)
    return { ok: r.ok, message: r.mensagem, ...(await mpView(b, await M.mpDe(bid), await M.planAllowed(b))) }
  }
  if (body.action === 'secret') { const sec = String(body.secret || '').trim(), sealed = sec ? await seal(sec.slice(0, 200)) : ''; await M.gravarMp(bid, (c: any) => { const n = { ...c }; if (sealed) n.mpSecret = sealed; else delete n.mpSecret; return n }, sec ? 'chave secreta do webhook definida' : 'chave secreta do webhook removida', !sec) }
  else if (body.action === 'remove') { await M.gravarMp(bid, (c: any) => M.limparLoja({ ...c }), 'desconectado pela empresa', true); await M.pagamentoOnline(bid, false) } // desconecta só esta empresa; a versão anterior fica no histórico
  else {
    // colado com "Bearer ", aspas, espaços ou quebra de linha: fica só o token
    const tok = String(body.tok || '').replace(/^\s*bearer\s+/i, '').replace(/^["'\s]+|["'\s]+$/g, '').replace(/\s+/g, '')
    if (/^(APP_USR|TEST)-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(tok)) fail(400, 'Isso é a Public Key. Cole o Access Token (fica logo abaixo da Public Key, em Credenciais).', 'invalid', 'tok')
    if (!/^(APP_USR|TEST)-[\w-]{10,}$/.test(tok)) fail(400, 'O Access Token começa com APP_USR- (produção) ou TEST- (teste).', 'invalid', 'tok')
    // valida na API do Mercado Pago ANTES de gravar: um token recusado não substitui a configuração que já existe
    const v = await M.validarToken(tok)
    // 25/11: a mesma conta Mercado Pago pode ser conectada por empresas de donos diferentes — cada empresa guarda a própria
    // credencial e recebe só os próprios pedidos/cobranças (webhook conferido por empresa). Só fica registrado na auditoria.
    if (v.ok) await M.registrarContaCompartilhada(bid, Number(v.conta?.id) || null, Number(b.owner_id), Number(b.owner_id))
    if (v.recusado) fail(400, 'O Mercado Pago recusou este Access Token (incorreto, revogado ou de outro tipo de credencial). Nada foi alterado: confira o token em mercadopago.com.br/developers → Suas integrações → Credenciais.', 'mp_recusado', 'tok')
    const sealed = await seal(tok), agora = nowIso()
    // modo manual não herda dados da conexão OAuth; a chave secreta do webhook definida pela empresa no modo manual é mantida
    await M.gravarMp(bid, (c: any) => ({ mpTok: sealed, mpModo: 'manual', mpStatus: v.ok ? 'conectado' : 'pendente', mpConectadoEm: agora, mpTeste: /^TEST-/.test(tok),
      ...(v.ok ? { mpVerificadoEm: agora, mpConta: v.conta, mpUserId: Number(v.conta?.id) || null } : {}), ...(c.mpSecret && c.mpModo !== 'oauth' ? { mpSecret: c.mpSecret } : {}) }), 'Access Token (modo manual) salvo', true)
    await M.pagamentoOnline(bid, true)
    const conta = v.conta?.nickname || v.conta?.email || v.conta?.id
    return { ok: true, verificado: v.ok, message: v.ok ? `Access Token salvo e conferido no Mercado Pago${conta ? ` (conta ${conta})` : ''}${/^TEST-/.test(tok) ? ' · ambiente de teste' : ''}.` : 'Access Token salvo como pendente: o Mercado Pago não respondeu agora para confirmar. A conferência é refeita sozinha; ou toque em "Verificar conexão" em instantes.', ...(await mpView(b, await M.mpDe(bid), true)) }
  }
  return { ok: true, ...(await mpView(b, await M.mpDe(bid), true)) }
}
async function mpView(b: any, d: any, permitido: boolean) {
  const M = await import('./mpuser.js'), { unsealInfo } = await import('../lib/settings.js'), info = d.mpTok ? await unsealInfo(d.mpTok) : { ok: true, valor: '' }, tok = info.valor, oauth = await M.appConfigured()
  const pend = d.mpTok ? null : await M.autorizacaoPendente(Number(b.id))
  const status = pend ? 'pendente' : M.statusLoja(d), bloqueio = permitido ? null : await M.motivoBloqueio(b)
  return { mpLoja: !!d.mpTok, motivoBloqueio: bloqueio?.mensagem || null, mpStatus: status, mpErro: !info.ok ? 'A conexão está salva, mas o servidor não consegue abrir a credencial (a chave de criptografia mudou). Nada foi apagado: o administrador do sistema deve restaurar a chave anterior.' : status === 'erro' ? d.mpErro || 'A conexão com o Mercado Pago precisa ser refeita.' : null,
    credencialIlegivel: !info.ok, mpMasked: tok ? maskSecret(tok) : '', mpModo: d.mpModo || (d.mpTok ? 'manual' : null), mpConta: d.mpConta || null, mpTeste: !!d.mpTeste || /^TEST-/.test(tok), mpExp: d.mpExp || null,
    mpConectadoEm: d.mpConectadoEm || null, mpRenovadoEm: d.mpRenovadoEm || null, mpVerificadoEm: d.mpVerificadoEm || null, renovacaoAutomatica: d.mpModo === 'oauth' && !!d.mpRefresh, permitido, oauthDisponivel: oauth,
    temChaveWebhook: !!d.mpSecret, autorizacaoPendenteDesde: pend,
    // as duas modalidades ficam sempre à escolha do dono: automática (OAuth, quando o administrador liberou) e manual
    manualDisponivel: true }
}

/** Cartões das empresas para o chat (imagem, descrição e botões conforme o plano). */
export async function businessCardsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const ids = String(ctx.query.get('ids') || '').split(',').map(Number).filter((n) => n > 0).slice(0, 12)
  if (!ids.length) return { items: [] }
  await refreshRatings()
  const ps = await plans(), loc = await userLocation(u.id), out: any[] = []
  // todas as empresas pedidas numa consulta e as impressões numa gravação (antes: 2 por empresa); a ordem pedida é mantida
  const por = new Map((await q(`SELECT * FROM businesses WHERE status = 'ativo' AND id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids)).map((b: any) => [Number(b.id), b])), vistos: { bid: number; owner: number }[] = []
  for (const id of ids) {
    const b = por.get(id)
    if (!b || (b.expires_at && Date.parse(b.expires_at) < Date.now())) continue
    out.push(card(b, nivelOf(ps, b.plan_id), loc && b.lat != null ? Math.round(distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) * 10) / 10 : null))
    vistos.push({ bid: id, owner: Number(b.owner_id) })
  }
  await hits(vistos, 'impressao', u.id)
  return { items: await comAgente(out) }
}

/** Escolhe um anúncio para aparecer no chat conforme a frequência definida no painel. */
export async function maybeAd(u: { id: number }) {
  const cfg = { ativo: true, cada: 6, intervaloMin: 30, ...(await getConfig<any>('ad_frequency', {})) }
  if (!cfg.ativo || !(await modules()).anuncios) return null
  const st = await getUM<any>(u.id, 'ad_state', { n: 0, at: 0 }); st.n = (st.n || 0) + 1
  if (st.n < Math.max(1, Number(cfg.cada) || 6) || Date.now() - (st.at || 0) < (Number(cfg.intervaloMin) || 0) * 60_000) { await setUM(u.id, 'ad_state', st); return null }
  const loc = await userLocation(u.id), rows = (await activeRows()).filter((b) => Number(b.owner_id) !== u.id && (!loc || b.lat == null || distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) <= (Number(J<any>(b.data, {}).raio) || 5)))
  if (!rows.length) { await setUM(u.id, 'ad_state', st); return null }
  const pick = rows[Math.floor(Math.random() * rows.length)]
  await setUM(u.id, 'ad_state', { n: 0, at: Date.now() })
  await hit(Number(pick.id), 'impressao', u.id, Number(pick.owner_id))
  return Number(pick.id)
}

/* ---------- Agente de atendimento da empresa (plano próprio, link público) ---------- */
const agentHits = new Map<string, number[]>()
export const agentPlanPublic = async () => { const p = await agentPlan(); return { preco: Number(p.preco), dias: Number(p.dias) } }
async function agentPlan() { return { preco: 39.9, dias: 30, limiteDia: 300, ...(await getConfig<any>('agent_plan', {})) } }
/** Nome do atendente virtual: padrão "Meu Assistente"; qualquer nome que a empresa escolher é respeitado (o antigo padrão "Atendente" também vira o novo padrão). */
export const AGENT_NAME_DEFAULT = 'Meu Assistente'
export const agentName = (a: any) => { const n = String(a?.nome ?? '').trim(); return n && n !== 'Atendente' ? n : AGENT_NAME_DEFAULT }
const agentOn = (x: any) => !!(x.agente && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() && x.agente.ativo !== false)
export async function agentPut(ctx: Ctx) {
  const own = await ownBusiness(ctx), u = own.u; let b = own.b; await requireModule('agente')
  // um agente por dono: se ele está numa empresa que não está mais em uso (encerrada, recusada, lixeira), vem para esta;
  // se está noutra empresa no ar, não cria um segundo — explica onde está e como trazer (Usar meu agente nesta empresa)
  if (!J<any>(b.data, {}).agente) {
    const out = await agenteEmOutraEmpresa(Number(u.id), Number(b.id))
    if (out && !out.emUso) { await transferirAgente(out.id, Number(b.id), 'empresa anterior fora de uso'); b = (await one('SELECT * FROM businesses WHERE id = $1', [b.id]))! }
    else if (out) fail(409, `Seu agente já está contratado na empresa ${out.empresa}. Para usá-lo aqui, toque em "Usar meu agente nesta empresa" (sem nova cobrança).`, 'agent_exists')
  }
  const d = J<any>(b.data, {}), a = ctx.body || {}
  const av = typeof a.avatar === 'string' ? (a.avatar === '' ? '' : a.avatar.startsWith('data:image/') && a.avatar.length < 300_000 ? a.avatar : undefined) : undefined
  d.agente = { ...(d.agente || {}), nome: str(a.nome, 40) || AGENT_NAME_DEFAULT, saudacao: str(a.saudacao, 300), instrucoes: str(a.instrucoes, 2000), tom: ['amigavel', 'profissional', 'divertido', 'direto'].includes(a.tom) ? a.tom : 'amigavel', ativo: a.ativo !== undefined ? a.ativo !== false : d.agente?.ativo !== false, botoes: a.botoes !== undefined ? a.botoes !== false : d.agente?.botoes !== false, flutuante: a.flutuante && typeof a.flutuante === 'object' ? { ativo: !!a.flutuante.ativo, msg: str(a.flutuante.msg, 80) || 'Se precisar de ajuda, me chama aqui!' } : d.agente?.flutuante || { ativo: false, msg: 'Se precisar de ajuda, me chama aqui!' }, ...(av !== undefined ? { avatar: av } : {}) }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(b.id)
}
/* Botões do atendimento que o dono pode ocultar. Ocultar só tira o botão da tela e das sugestões do agente:
   o recurso continua funcionando (agendar, mapa, horário, pagamento e WhatsApp seguem respondendo se o cliente pedir). */
export const AG_OPCOES = ['agendar', 'servicos', 'localizacao', 'horario', 'pagamento', 'whatsapp'] as const
const AG_OPCAO_NOME: Record<string, string> = { agendar: 'Agendar um horário', servicos: 'Ver nossos serviços', localizacao: 'Localização', horario: 'Horário de funcionamento', pagamento: 'Pagamento e entrega', whatsapp: 'WhatsApp' }
/** Padrão de quem ainda não personalizou: 5 botões ligados; "Pagamento e entrega" começa desligado.
 *  Escolhas já salvas por uma empresa (true/false) sempre prevalecem — nada personalizado é sobrescrito. */
export const AG_PADRAO: Record<(typeof AG_OPCOES)[number], boolean> = { agendar: true, servicos: true, localizacao: true, horario: true, pagamento: false, whatsapp: true }
export const agentOpcoes = (x: any) => Object.fromEntries(AG_OPCOES.map((k) => [k, typeof x?.agenteOpcoes?.[k] === 'boolean' ? x.agenteOpcoes[k] : AG_PADRAO[k]])) as Record<(typeof AG_OPCOES)[number], boolean>
/** Grava as opções de uma empresa (só o dono, por ownBusiness). Salva na hora; vale para a página pública na próxima leitura. */
export async function agentOpcoesPut(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); await requireModule('agente')
  const o = ctx.body?.opcoes
  if (!o || typeof o !== 'object' || Array.isArray(o)) fail(400, 'Envie as opções.', 'invalid')
  for (const [k, v] of Object.entries(o)) { if (!(AG_OPCOES as readonly string[]).includes(k) || typeof v !== 'boolean') fail(400, 'Opção inválida.', 'invalid', k) }
  const fresh = await one('SELECT data FROM businesses WHERE id = $1 AND owner_id = $2', [b.id, b.owner_id]) // relê para não perder alterações feitas em paralelo
  const d = J<any>(fresh!.data, {}); d.agenteOpcoes = { ...agentOpcoes(d), ...o }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3 AND owner_id = $4', [JSON.stringify(d), nowIso(), b.id, b.owner_id])
  return { opcoes: agentOpcoes(d) }
}
async function agentInfo(id: number) {
  let b = await one('SELECT * FROM businesses WHERE id = $1', [id]); let x = J<any>(b!.data, {})
  // o agente é do dono (um por dono): numa empresa fora de uso, vem para esta; noutra no ar, a tela mostra onde está
  let outra: Awaited<ReturnType<typeof agenteEmOutraEmpresa>> = null
  if (!x.agente) {
    outra = await agenteEmOutraEmpresa(Number(b!.owner_id), id)
    if (outra && !outra.emUso && empresaEmUso(b)) { await transferirAgente(outra.id, id, 'empresa anterior fora de uso'); outra = null; b = await one('SELECT * FROM businesses WHERE id = $1', [id]); x = J<any>(b!.data, {}) }
  }
  if (x.agente?.payment?.id && !agentOn(x)) { try { const r = await fetch(`${MPB()}/v1/payments/${x.agente.payment.id}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json(); if (j.status === 'approved' && refAgente(j.external_reference, id, x)) { await activateAgent(id, String(x.agente.payment.id), Number(j.transaction_amount)); b = await one('SELECT * FROM businesses WHERE id = $1', [id]); x = J<any>(b!.data, {}) } } catch {} }
  const p = await agentPlan()
  // cupom da plataforma na ativação do agente (destino "agente" ou "ambos"): valor sempre recalculado aqui
  const VC = await import('../lib/vouchers.js'); await VC.expirarReservas(); const rv = await VC.recalcular(id, 'agente', Number(p.preco), 'agente')
  if (rv) { b = await one('SELECT * FROM businesses WHERE id = $1', [id]); x = J<any>(b!.data, {}) }
  const valor = rv ? Number(rv.final_value) : Number(p.preco)
  const mod = (await modules()).agente, adNoAr = b!.status === 'ativo' && !(b!.expires_at && Date.parse(b!.expires_at) < Date.now()), expired = false
  const motivo = !mod ? 'O administrador desligou o agente para todas as empresas.' : x.agente && x.agente.ativo === false && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() ? 'Você desligou o agente. Ligue de novo quando quiser.' : !agentOn(x) ? (x.agente?.expiresAt ? 'O plano do agente venceu: renove para voltar a atender.' : 'Coloque o agente no ar para ele atender seus clientes.') : ''
  return { outraEmpresa: outra ? { id: outra.id, empresa: outra.empresa, status: outra.status, contratado: outra.contratado, ativo: outra.ativo, ate: outra.ate } : null, motivo: outra ? `Seu agente está ${outra.ativo ? 'no ar' : 'configurado'} na empresa ${outra.empresa}.` : motivo, anuncio: { noAr: adNoAr, ate: b!.expires_at || null, status: b!.status }, agenteAte: x.agente?.expiresAt || null, vencido: !!(x.agente?.expiresAt && Date.parse(x.agente.expiresAt) <= Date.now()), agente: x.agente ? { ...x.agente, nome: agentName(x.agente) } : null, opcoes: agentOpcoes(x), nomePadrao: AGENT_NAME_DEFAULT, ativo: agentOn(x) && mod && !expired, link: await agentLink(id), plano: { preco: p.preco, dias: p.dias }, valor, cupom: x.agenteCupom || null, beneficio: x.agente?.beneficio || null, payment: x.agente?.payment || null }
}
/** O Pix é do agente desta empresa? (gerado aqui, ou na empresa de onde o agente foi transferido) */
const refAgente = (ref: unknown, id: number, x: any) => String(ref) === `agent:${id}` || (!!x?.agente?.transferidoDe && String(ref) === `agent:${x.agente.transferidoDe}`)
/** Empresa que o dono está usando (painel liberado e anúncio em andamento ou no ar, dentro da validade). */
function empresaEmUso(b: any): boolean {
  const x = J<any>(b?.data, {})
  if (!b || x.revogado || ['encerrado', 'recusado', 'lixeira', 'cancelado'].includes(String(b.status))) return false
  return !(b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now())
}
/** O agente do dono em OUTRA empresa (um agente por dono). Prefere o contratado; entre iguais, o mais recente. */
async function agenteEmOutraEmpresa(ownerId: number, exceptId: number) {
  const rows = (await q('SELECT id, status, expires_at, data FROM businesses WHERE owner_id = $1 AND id <> $2 ORDER BY id DESC', [ownerId, exceptId])).filter((r) => J<any>(r.data, {}).agente)
  if (!rows.length) return null
  const info = rows.map((r) => { const x = J<any>(r.data, {}), ag = x.agente; return { id: Number(r.id), empresa: String(x.empresa || ''), status: String(r.status), emUso: empresaEmUso(r), contratado: !!(ag.expiresAt || ag.lastPayment), ativo: agentOn(x), ate: ag.expiresAt || null } })
  return info.sort((a, b2) => Number(b2.contratado) - Number(a.contratado) || Number(b2.emUso) - Number(a.emUso))[0]
}
/** Leva o agente (configuração, período pago, benefício, Pix pendente, opções e links já divulgados) de uma empresa para
 *  outra do MESMO dono, numa transação. A empresa de origem guarda o histórico completo (agenteTransferido). Sem cobrança. */
async function transferirAgente(deId: number, paraId: number, motivo: string) {
  return withLock(`agente-dono:${deId}:${paraId}`, () => (D.db().tx(async (t) => {
    const [de] = await t.query<any>('SELECT id, owner_id, data FROM businesses WHERE id = $1', [deId]), [para] = await t.query<any>('SELECT id, owner_id, data FROM businesses WHERE id = $1', [paraId])
    if (!de || !para || Number(de.owner_id) !== Number(para.owner_id)) return false
    const xd = J<any>(de.data, {}), xp = J<any>(para.data, {})
    if (!xd.agente || xp.agente) return false // nada para levar, ou o destino já tem agente (nunca sobrescreve)
    const agora = nowIso(), links = [xd.slug, ...(xd.slugsAntigos || [])].filter(Boolean)
    xp.agente = { ...xd.agente, transferidoDe: deId, transferidoEm: agora }
    if (xd.agenteOpcoes && !xp.agenteOpcoes) xp.agenteOpcoes = xd.agenteOpcoes
    if (links.length) xp.slugsAntigos = [...new Set([...(xp.slugsAntigos || []), ...links])].filter((s) => s !== xp.slug).slice(-10) // o link que os clientes já têm abre o agente aqui
    xd.agenteTransferido = [{ para: paraId, em: agora, motivo, agente: xd.agente, agenteOpcoes: xd.agenteOpcoes || null, slug: xd.slug || null, slugsAntigos: xd.slugsAntigos || [] }, ...(xd.agenteTransferido || [])].slice(0, 10)
    delete xd.agente; delete xd.slug; delete xd.slugsAntigos; delete xd.slugBase // um agente só; se a empresa voltar a ser usada, ganha um endereço novo
    await t.query('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(xp), agora, paraId])
    await t.query('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(xd), agora, deId])
    return true
  }))).then(async (ok) => { if (ok) await audit(null, 'empresa.agente.transferido', paraId, { de: deId, para: paraId, motivo }).catch(() => null); return ok })
}
/** "Usar meu agente nesta empresa": traz o agente do dono de outra empresa dele para esta (sem nova cobrança). */
export async function agentTransferirPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  if (J<any>(b.data, {}).agente) return agentInfo(Number(b.id)) // já está aqui
  const out = await agenteEmOutraEmpresa(Number(u.id), Number(b.id)); if (!out) fail(404, 'Você ainda não tem um agente para trazer. Configure e ative o agente nesta empresa.', 'not_found')
  if (!(await transferirAgente(out!.id, Number(b.id), 'pedido do dono'))) fail(409, 'Não foi possível trazer o agente agora. Tente de novo.', 'conflict')
  return agentInfo(Number(b.id))
}
export async function agentGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return agentInfo(Number(b.id)) }
async function adminTok() { const { MP_DEFAULT } = await import('../lib/panel-defaults.js'); const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }; return unseal((mp[mp.modo] || {}).tok || '') }
export async function agentPayPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const d = J<any>(b.data, {}); if (!d.agente) fail(400, 'Configure o agente antes de pagar.', 'invalid')
  const p = await agentPlan()
  if (u.role !== 'user') { await activateAgent(Number(b.id), 'admin-' + Date.now()); return agentInfo(Number(b.id)) } // administrador: sem pagamento
  const VC = await import('../lib/vouchers.js'); await VC.expirarReservas()
  const rv = await VC.recalcular(Number(b.id), 'agente', Number(p.preco), 'agente'), valor = rv ? Number(rv.final_value) : Number(p.preco) // valor do servidor (cupom incluído)
  if (rv && valor <= 0) fail(400, 'Com este cupom a ativação do agente é gratuita: toque em "Ativar sem pagamento".', 'cupom_gratuito')
  if (pixValid(d.agente.payment) && Number(d.agente.payment.valor) === valor) return agentInfo(Number(b.id))
  const exp = await pixExpiry(), tok = await adminTok(); if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador.', 'mp_not_configured')
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `agent-${b.id}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: valor, description: `Agente de atendimento · ${d.empresa}${rv ? ' · cupom ' + rv.code : ''}`, payment_method_id: 'pix', payer: { email: u.email }, date_of_expiration: exp.iso, external_reference: `agent:${b.id}`, notification_url: `${pub()}/api/mercadopago/webhook` }) })
  const j: any = await r.json().catch(() => null); if (!r.ok || !j?.id) fail(502, 'Não foi possível gerar o Pix agora.', 'mp_error')
  const td = j.point_of_interaction?.transaction_data || {}
  const d2 = J<any>((await one('SELECT data FROM businesses WHERE id = $1', [b.id]))!.data, {}); Object.assign(d, { agenteCupom: d2.agenteCupom }); if (!d.agenteCupom) delete d.agenteCupom
  d.agente.payment = { id: String(j.id), valor, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(Number(b.id))
}
/** Ativa/renova o agente. `pago` (valor do Pix aprovado) é conferido com o devido AGORA (plano menos o cupom ainda aplicado):
 *  um Pix com desconto pago depois de remover o cupom não ativa (os administradores são avisados). O cupom reservado vira
 *  resgate junto com a ativação e o benefício (período gratuito, vitalício) é aplicado uma única vez. */
export async function activateAgent(bid0: number, paymentId: string, pago?: number) {
  let bid = bid0, b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); if (!b) return
  // o agente foi transferido depois de gerar o Pix (external_reference agent:<empresa antiga>): ativa onde ele está agora
  for (let i = 0; i < 5 && !J<any>(b!.data, {}).agente; i++) { const para: number = Number(J<any>(b!.data, {}).agenteTransferido?.[0]?.para); const nb: any = para ? await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [para, b!.owner_id]) : null; if (!nb) break; b = nb; bid = Number(nb.id) }
  const d0 = J<any>(b!.data, {}), p = await agentPlan(); if (!d0.agente || d0.agente.lastPayment === paymentId) return
  const VC = await import('../lib/vouchers.js')
  if (pago != null && Number.isFinite(pago)) {
    const rv = await VC.recalcular(bid0, 'agente', Number(p.preco), 'agente'), devido = rv ? Number(rv.final_value) : Number(p.preco)
    if (pago + 0.009 < devido) {
      console.error(`[agente] pagamento ${paymentId} da empresa #${bid} menor que o devido (${pago} < ${devido}); não ativado`)
      const { admins } = await import('./ads.js'); for (const a of await admins()) await notify(a, { type: 'ads', title: 'Pagamento do agente com valor menor que o devido', body: `${d0.empresa}: pago R$ ${pago.toFixed(2).replace('.', ',')}, devido R$ ${devido.toFixed(2).replace('.', ',')}`, link: '/admin?aba=anuncios', ref: `agent-valor:${bid}:${paymentId}` })
      return
    }
  }
  await VC.confirmar(bid0, paymentId, 'agente')
  b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); const d = J<any>(b!.data, {}) // relê: confirmar atualiza o resumo do cupom
  const base = d.agente.expiresAt && Date.parse(d.agente.expiresAt) > Date.now() ? Date.parse(d.agente.expiresAt) : Date.now()
  const bn = await VC.aplicarNaAtivacao(bid0, Number(p.dias) || 30, 'agente', base)
  let exp = bn ? bn.exp : new Date(base + p.dias * 86400_000).toISOString()
  if (!bn && d.agente.beneficio?.vitalicio) exp = VC.VITALICIO_ATE // vitalício já concedido nunca é perdido
  d.agente = { ...d.agente, expiresAt: exp, lastPayment: paymentId, payment: null, ...(bn ? { beneficio: bn.beneficio } : {}) }; delete d.agenteCupom
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), bid])
  await notify(Number(b!.owner_id), { type: 'ads', title: d.agente.expiresAt === VC.VITALICIO_ATE ? 'Seu agente de atendimento está no ar (acesso vitalício)!' : 'Seu agente de atendimento está no ar!', body: `Compartilhe o link: ${await agentLink(Number(bid))}`, link: '/x/sua-empresa', ref: `agent:${bid}:${paymentId}` })
}
/** Cupom da plataforma na ativação do Agente (aplicar, remover, ativar sem pagamento). Mesmas regras dos anúncios:
 *  destino, validade, limites (total e por usuário, atômicos), reserva de 48 h e valor calculado no servidor. */
export async function agentCupomPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const d = J<any>(b.data, {}); if (!d.agente) fail(400, 'Configure o agente antes de usar um cupom.', 'invalid')
  const p = await agentPlan(), VC = await import('../lib/vouchers.js'), acao = String(ctx.body?.acao || ''), bid = Number(b.id)
  const limparPix = async () => { const x = J<any>((await one('SELECT data FROM businesses WHERE id = $1', [bid]))!.data, {}); if (x.agente?.payment) { x.agente.payment = null; await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), bid]) } } // o valor mudou: o próximo Pix sai com o valor novo
  if (acao === 'aplicar') {
    const r = await VC.reservar(String(ctx.body?.codigo || ''), { userId: u.id, planId: 'agente', preco: Number(p.preco), categoria: String(d.categoria || ''), businessId: bid, alvo: 'agente' }, `usuário ${u.id}`)
    await VC.sincronizarAnuncio(bid, 'agente'); await limparPix(); await audit(u.id, 'cupom.agente.aplicar', bid, { codigo: r.voucher.code })
    return { ok: true, mensagem: r.mensagem, ...(await agentInfo(bid)) }
  }
  if (acao === 'remover') {
    const r = await VC.reservaDo(bid, 'agente'); if (!r) fail(400, 'Nenhum cupom aplicado à ativação do agente.', 'invalid')
    await VC.liberar(Number(r.id), 'removido pelo usuário', `usuário ${u.id}`); await limparPix(); await audit(u.id, 'cupom.agente.remover', bid, { codigo: r.code })
    return { ok: true, mensagem: 'Cupom removido. O valor voltou ao preço normal.', ...(await agentInfo(bid)) }
  }
  if (acao === 'ativar') {
    await VC.expirarReservas(true)
    const r = await VC.recalcular(bid, 'agente', Number(p.preco), 'agente'); if (!r) fail(400, 'Nenhum cupom válido aplicado à ativação do agente.', 'invalid')
    if (Number(r.final_value) > 0) fail(400, 'Este cupom não cobre todo o valor: pague o restante pelo Pix.', 'invalid')
    await activateAgent(bid, `cupom-${r.id}`); await audit(u.id, 'cupom.agente.ativar_gratis', bid, { codigo: r.code })
    return { ok: true, mensagem: 'Agente ativado sem pagamento: já está no ar!', ...(await agentInfo(bid)) }
  }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function agentPayGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), d = J<any>(b.data, {})
  if (agentOn(d) && !d.agente?.payment) return { status: 'approved' }
  const pid = d.agente?.payment?.id; if (!pid) return { status: 'none' }
  try { const r = await fetch(`${MPB()}/v1/payments/${pid}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json()
    if (j.status === 'approved' && refAgente(j.external_reference, Number(b.id), d)) { await activateAgent(Number(b.id), pid, Number(j.transaction_amount)); return { status: 'approved' } } return { status: j.status } } catch { return { status: 'unknown' } }
}
export const agentBizPublic = (id: number, ctx?: Ctx) => agentBiz(id, ctx)
export async function agentBiz(id: number, ctx?: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [id]); const x = b ? J<any>(b.data, {}) : null
  const dono = !!(ctx?.user && b && Number(b.owner_id) === ctx.user.id)
  if (b && b.status === 'lixeira') throw new HttpError(404, 'O atendimento automático desta empresa está pausado no momento.', 'not_found') // empresa na lixeira: nada público
  if (b && x && dono && x.agente) return { b, x, teste: !agentOn(x) } // o dono pode testar antes de colocar no ar
  if (!b || !x || !(await modules()).agente || !agentOn(x)) {
    const err: any = new HttpError(404, 'O atendimento automático desta empresa está pausado no momento.', 'not_found')
    err.extra = b && x ? { empresa: x.empresa, logo: x.logo || null, zap: x.zap || null, loja: b.status === 'ativo' ? `${pub()}/x/empresa/${b.id}` : null } : null
    throw err
  }
  return { b, x, teste: false }
}
export async function agentPublicGet(ctx: Ctx) {
  const { b, x, teste } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x)
  return { teste, avatar: x.agente.avatar || x.logo || null, botoes: x.agente.botoes !== false, opcoes: agentOpcoes(x), nome: agentName(x.agente), saudacao: x.agente.saudacao || `Olá! Sou ${agentName(x.agente)}, da ${x.empresa}. Como posso ajudar?`, empresa: x.empresa, categoria: x.categoria, logo: x.logo || null, aberto: st.aberto, situacao: st.texto, loja: `${pub()}/x/empresa/${b.id}`, zap: x.zap || null, tema: normalizeTema(x.tema) }
}
export async function agentChatPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b, x, teste } = await agentBiz(id, ctx)
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= 12) fail(429, 'Muitas mensagens seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
  const p = await agentPlan(), day = new Date().toISOString().slice(0, 10), cnt = x.agente.uso?.dia === day ? x.agente.uso.n : 0
  if (cnt >= p.limiteDia) fail(429, 'O atendimento automático atingiu o limite de hoje. Fale com a empresa pelo WhatsApp.', 'limit_reached')
  // "⟦ids:1,2⟧" (cards mostrados naquela resposta, guardados pela tela) sobrevive ao corte de tamanho: é o que permite
  // "quero a segunda", "tem dessa em preto?" (ai/atendente.ts). Nunca vai para a IA.
  const msgs = (Array.isArray(ctx.body?.messages) ? ctx.body.messages : []).slice(-8).map((m: any) => { const raw = String(m?.content ?? ''), mk = m?.role === 'assistant' ? (raw.match(/⟦ids:[\d,]{1,80}⟧/) || [''])[0] : ''; return { role: m.role === 'assistant' ? 'assistant' : 'user', content: (str(raw.replace(/⟦ids:[^⟧]*⟧/g, '').trim(), 500) + (mk ? ' ' + mk : '')).trim() } }).filter((m: any) => m.content)
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') fail(400, 'Envie uma mensagem.', 'invalid')
  const last = nrm(msgs[msgs.length - 1].content), curto = last.split(/\s+/).length <= 14
  // atendimento HUMANO: "quero falar com uma pessoa", "abrir um chamado", "estou com um problema"… vai direto para a abertura do
  // chamado com a empresa (routes/atendimento.ts) — antes de catálogo, Cérebro, IA ou qualquer pesquisa, e sem gastar a cota do agente
  if ((await import('./atendimento.js')).pedeAtendimentoHumano(msgs[msgs.length - 1].content))
    return { reply: `Claro! Vou chamar a equipe ${x.empresa ? 'da ' + x.empresa : 'da empresa'} para te atender pessoalmente. Conte o que aconteceu — se quiser, anexe fotos, prints ou documentos — e toque em "Abrir atendimento".`, produtos: null, pix: null, secao: 'atendimento' }
  const est = openState(x), local: [RegExp, string, string][] = [
    [/(cardapio|catalogo|\bmenu\b|produtos|servicos|o que (voce|voces|vcs?) (tem|vende|faz)|opcoes|lista de precos|ver precos)/, 'catalogo', 'Aqui está o nosso catálogo. Toque em Adicionar para montar seu pedido.'],
    [/(onde fica|onde voces ficam|endereco|localizacao|como chego|como chegar|\bmapa\b|fica onde)/, 'mapa', x.endereco ? `Estamos em ${x.endereco}${x.referencia ? ` (ponto de referência: ${x.referencia})` : ''}. Veja o mapa e a rota abaixo.` : 'Veja nossa localização no mapa abaixo.'],
    [/(horario|que horas|abre|fecha|funcionamento|esta aberto|estao abertos|aberto hoje)/, 'horario', `Agora: ${est.texto || (est.aberto ? 'aberto' : 'fechado')}. Veja nosso horário abaixo.`],
    [/(forma de pagamento|formas de pagamento|como pago|como pagar|aceita (pix|cartao|dinheiro)|tem entrega|faz entrega|entregam|taxa de entrega|frete|delivery|retirada|chave pix)/, 'pagamento', 'Veja as formas de pagamento e de entrega abaixo.'],
    [/(meu carrinho|ver carrinho|finalizar( o)? pedido|fechar( o)? pedido)/, 'carrinho', 'Aqui está o seu carrinho.'],
  ]
  const hitL = curto ? local.find(([re]) => re.test(last)) : null
  if (hitL && !(hitL[1] === 'catalogo' && nivelOf(await plans(), b.plan_id) < 4)) {
    if (!teste) { x.agente.uso = { dia: new Date().toISOString().slice(0, 10), n: (x.agente.uso?.dia === new Date().toISOString().slice(0, 10) ? x.agente.uso.n : 0) + 1 }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); await hit(id, 'agente', null) }
    if (hitL[1] === 'catalogo') {
      const nProd = Number((await q('SELECT COUNT(*) AS n FROM products WHERE business_id = $1 AND active = $2', [id, true]))[0]?.n || 0)
      if (!nProd) return { reply: `No momento ${x.empresa || 'a loja'} ainda não tem produtos publicados aqui.${x.zap && agentOpcoes(x).whatsapp ? ' Você pode falar direto com a empresa pelo WhatsApp.' : ''}`, produtos: null, pix: null, secao: null }
    }
    return { reply: hitL[2], produtos: null, pix: null, secao: hitL[1] }
  }
  // Cérebro: regras executáveis (recusar/anexar) e conhecimento aprovado com escopo "agentes", antes de qualquer IA
  const rawLast = msgs[msgs.length - 1].content, usosAg: Uso[] = []; let rodapeAg: string[] = []
  {
    const R = await import('../ai/rules.js'), K = await import('../ai/knowledge.js')
    const rr = await R.applyRules({ user: null, canal: 'agente', texto: rawLast, businessId: id }).catch(() => null)
    if (rr) { usosAg.push(...rr.usos); rodapeAg = rr.rodape }
    const kb = !rr?.terminal && (await (await import('../lib/settings.js')).getConfig<any>('brain', {})).cerebroPrimeiro !== false ? await K.answerKnowledge(rawLast, null, 0.6, { canal: 'agente' }).catch(() => null) : null
    const direta = rr?.terminal && rr.reply ? rr.reply : kb ? kb.resposta : null
    if (direta) {
      if (kb) usosAg.push(...K.usoDeConsulta(kb, 'agente'))
      if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); await hit(id, 'agente', null) }
      await registrarUso(usosAg, { canal: 'agente', businessId: id })
      return { reply: direta + (rodapeAg.length ? '\n\n' + [...new Set(rodapeAg)].join('\n') : ''), produtos: null, pix: null, secao: null }
    }
  }
  // ATENDENTE COMERCIAL (ai/atendente.ts): pedidos comerciais claros sobre o catálogo REAL — procurar, refinar (cor, tamanho,
  // material, preço), dúvida de preço/opção e "coloca no carrinho" — resolvidos aqui, sem IA, em milissegundos. O carrinho é o
  // da tela (a resposta traz os itens para ela adicionar com as regras de estoque de sempre). O resto segue para a IA.
  const prods = await CAT.enriquecer((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 60', [id, true])).map(productOut).filter(inOp(x)))
  if (prods.length && nivelOf(await plans(), b.plan_id) >= 4) {
    const AT = await import('../ai/atendente.js'), noCarrinho = (Array.isArray(ctx.body?.carrinho) ? ctx.body.carrinho : []).map(Number).filter(Boolean).slice(0, 50)
    const r = AT.atender(msgs as any, prods as any, { carrinho: noCarrinho })
    if (r) {
      if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); await hit(id, 'agente', null) }
      // camada coletiva: COMO os clientes pedem (modelo anônimo + intenção), só de quem tem conta e consentiu — nunca o catálogo
      if (ctx.user) (await import('../ai/aprendizado-coletivo.js')).observar(ctx.user as any, `ag:${id}:${ctx.user.id}`, { texto: rawLast, intencoes: [r.intencao] })
      const porId = new Map(prods.map((p: any) => [Number(p.id), p]))
      const cards = r.ids.map((i) => porId.get(Number(i))).filter(Boolean).map(cardProduto)
      const carrinho = (r.carrinho || []).filter((c) => porId.has(Number(c.pid)))
      return { reply: r.reply, produtos: cards.length ? cards : null, carrinho: carrinho.length ? carrinho : null, pix: null, secao: null, atendente: r.intencao }
    }
  }
  let rastroAg: any = null // Cérebro Central: conhecimento geral aprovado compartilhado com o agente (rastreado)
  const brainCtxAg = await (await import('../ai/brain.js')).brainContext(rawLast, usosAg, 'agente', { onRastro: (r) => { rastroAg = r } }).catch(() => '')
  const COLag = await import('../ai/aprendizado-coletivo.js')
  const ps = await plans(), n = nivelOf(ps, b.plan_id), st = openState(x), E = { ...(x.entrega || {}) }, P = { ...(x.pagamento || {}) }
  const { complete, engineCfg, engineInstructions } = await import('../ai/provider.js')
  const eng = await engineCfg()
  const sys = [
    `Você é ${agentName(x.agente)}, atendente virtual da empresa "${x.empresa}" (${x.categoria}). Atenda clientes em português do Brasil, de forma natural, educada e objetiva, ajudando a tirar dúvidas e a vender.`,
    engineInstructions({ ...eng, personalidade: x.agente.tom || eng.personalidade, personalidadeTexto: '' }),
    (await import('../ai/commercial.js')).AGENTE_VENDAS,
    `Use SOMENTE as informações abaixo. Não invente preços, produtos, prazos ou políticas. Se não souber, diga que vai verificar${agentOpcoes(x).whatsapp ? ' e ofereça o WhatsApp da empresa' : ''}.`,
    (() => { const oc = AG_OPCOES.filter((k) => !agentOpcoes(x)[k]).map((k) => AG_OPCAO_NOME[k]); return oc.length ? `A empresa escolheu NÃO apresentar estas opções de atendimento: ${oc.join(', ')}. Não as sugira nem as liste entre as opções; se o cliente perguntar diretamente sobre uma delas, responda normalmente com as informações abaixo.` : '' })(),
    `Sobre: ${x.sobre || x.texto || ''}`, x.horarioCfg?.dias ? `Horário de funcionamento ATUAL (vale mais que qualquer horário dito antes nesta conversa): ${['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'].map((k) => { const d = x.horarioCfg.dias[k]; return `${k} ${d?.ativo ? d.abre + '–' + d.fecha : 'fechado'}` }).join(', ')}.` : (x.horario ? `Horário: ${x.horario}` : ''), x.endereco ? `Endereço: ${x.endereco}${x.referencia ? ` (ponto de referência: ${x.referencia})` : ''}` : '', `Situação agora: ${st.texto || (st.aberto ? 'aberto' : 'fechado')}.`, (await import('../ai/agenda-ia.js')).calendarioParaAgente(x, new Date(Date.now() - 3 * 3600_000).toISOString().slice(0, 10)),
    n >= 4 ? `Pedidos: o cliente faz o pedido pela loja online: ${pub()}/x/empresa/${id}` : '', x.zap ? `WhatsApp: https://wa.me/${x.zap}` : '',
    E.entrega ? `Entrega: até ${E.raio || 3} km; ${E.modoTaxa === 'km' ? `grátis até ${E.kmGratis || 0} km, depois R$ ${E.taxaExcedente || 0} + R$ ${E.taxaKm || 0} por km` : `taxa R$ ${E.taxa || 0}`}${E.tempo ? `; tempo ${E.tempo}` : ''}.` : 'Somente retirada no local.',
    `Pagamento: ${[P.online ? 'Pix pelo app' : '', P.pix ? 'Pix' : '', P.cartao ? 'cartão na entrega/retirada' : '', P.dinheiro ? 'dinheiro' : ''].filter(Boolean).join(', ') || 'combinar com a empresa'}.`,
    prods.length ? `Catálogo (use o id nas ferramentas):\n${prods.map((p: any) => `- [id ${p.id}] ${p.tipo === 'servico' ? '(serviço ' + (p.duracao || 30) + ' min, ' + ({ fixo: 'valor fixo', hora: 'por hora', consulta: 'consulta', orcamento: 'sob orçamento' } as any)[p.modoPreco || 'fixo'] + ') ' : ''}${p.nome}: ${precoTxt(p)}${(p.variantes || []).length ? ' [variações: ' + p.variantes.map((v: any) => `id ${v.id} ${v.rotulo} R$ ${Number(v.precoAplicado).toFixed(2).replace('.', ',')}${v.emOferta ? ` (oferta, de R$ ${Number(v.preco).toFixed(2).replace('.', ',')})` : ''}${v.disponivel ? '' : ' INDISPONÍVEL'}`).join('; ') + ']' : ''}${(p.variacoes || []).length ? ' (' + p.variacoes.map((v: any) => v.nome + ': ' + v.opcoes.map((o: any) => o.nome + (o.preco ? ' R$ ' + o.preco : '')).join('/')).join('; ') + ')' : ''}${p.descricao ? ' – ' + String(p.descricao).slice(0, 120) : ''}`).join('\n')}` : '',
    x.agente.instrucoes ? `Instruções da empresa: ${x.agente.instrucoes}` : '',
    brainCtxAg,
    // Cérebro Central, camada coletiva de ATENDIMENTO (anônima): como os clientes costumam pedir — nunca dados de outra loja
    (() => { const cs = COLag.sugerir(rawLast, { escopo: 'loja' }); return cs ? `Apoio do Cérebro Central (aprendido com o atendimento de muitas lojas, anônimo): mensagens escritas assim costumam significar "${cs.nome}". Use só para entender a intenção; responda com os dados DESTA empresa.` : '' })(),
    'Conduza como um bom vendedor: entenda a necessidade, use o que o cliente já disse nesta conversa (cor, tamanho, preço) para refinar em vez de recomeçar, mostre as opções reais com mostrar_catalogo, ofereça no máximo um complemento pertinente, nunca pressione e nunca invente oferta, preço ou disponibilidade. Quando o cliente pedir uma ação (ver opções, pedir, agendar), execute com as ferramentas em vez de só dizer que vai fazer.',
  ].filter(Boolean).join('\n')
  const out: any = {}, conv: any[] = [{ role: 'system', content: sys + '\nVocê pode usar ferramentas: ' + ({ produtos: 'mostrar_catalogo (mostra fotos e preços na tela) e criar_pedido. Esta empresa trabalha SÓ com produtos: não ofereça agendamentos.', servicos: 'mostrar_catalogo (mostra fotos e preços na tela), horarios_livres e agendar_servico. Esta empresa trabalha SÓ com serviços: não existe pedido de produtos.' } as any)[opTipo(x)] + ' Antes de criar pedido ou agendamento, confirme itens/opções, retirada ou entrega (com endereço), forma de pagamento e o nome do cliente. Quando gerar Pix, diga que o QR Code apareceu na tela. Datas de hoje: ' + new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10) + '.' }, ...msgs.map((m: any) => ({ ...m, content: String(m.content).replace(/\s*⟦ids:[^⟧]*⟧/g, "") }))]
  let m: any = null
  const turn = Math.random().toString(36).slice(2, 10)
  for (let round = 0; round < 4; round++) {
    try { m = await complete(conv as any, AG_TOOLS.filter((t: any) => (opTipo(x) === 'produtos' ? !['horarios_livres', 'agendar_servico'].includes(t.function.name) : t.function.name !== 'criar_pedido')) as any, { allowEmpty: round > 0 }) } catch (e) { if (round > 0) { m = null; break } throw e } // pedido/Pix já gerado nunca se perde nem se repete
    if (!m.tool_calls?.length) break
    conv.push({ role: 'assistant', content: m.content ?? null, tool_calls: m.tool_calls })
    for (const call of m.tool_calls) {
      let res: any
      try {
        const args = JSON.parse(call.function.arguments || '{}'), r = await once('t:' + turn, call.function.name + ':' + canon(args), 600_000, () => runAgentTool(b, call.function.name, args, out, ctx.user?.id || null))
        res = r.hit ? { ...(r.value && typeof r.value === 'object' ? r.value : {}), deduped: true, aviso: 'Já executado: não repita esta ação.' } : r.value
      } catch (e: any) { res = { ok: false, erro: e?.message || 'falha' } }
      conv.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(res) })
    }
    // só mostrou catálogo/seção na tela: responde na hora, sem outra ida à IA (economiza uma rodada inteira)
    const soMostrar = m.tool_calls.every((c: any) => c.function.name === 'mostrar_catalogo' || c.function.name === 'mostrar_secao')
    if (soMostrar && (out.produtos?.length || out.secao)) {
      const txt = String(m.content || '').trim()
      m = { role: 'assistant', content: txt && !/n[aã]o (temos|h[aá]|tem) produtos/i.test(txt) ? txt : out.produtos?.length ? 'Aqui estão as opções 👇 Toque em Adicionar ou Agendar no que quiser.' : ({ mapa: 'Aqui está a nossa localização 👇', horario: 'Este é o nosso horário de funcionamento 👇', pagamento: 'Estas são as formas de pagamento e entrega 👇', carrinho: 'Este é o seu carrinho 👇', catalogo: 'Aqui está o catálogo 👇' } as any)[out.secao] || 'Pronto 👇' }
      break
    }
    m = null
  }
  if (!m) m = { content: out.pix ? 'Pronto! Gerei o Pix: o QR Code e o código copia e cola estão logo abaixo.' : 'Pronto!' }
  // Garante catálogo real: se o cliente pediu cardápio/catálogo e há produtos, força os cards e limpa contradição
  const pediuCat = /(cardapio|catalogo|menu|produtos|servicos|o que (voce|voces|vcs?) (tem|vende|faz)|opcoes|lista de precos|ver precos)/.test(last)
  if (pediuCat && prods.length && !out.produtos) {
    out.produtos = prods.slice(0, 10).map(cardProduto)
  }
  let reply = String(m.content || '').trim() || 'Desculpe, pode repetir?'
  if (out.produtos && out.produtos.length && /não (há|tem|existem)|nenhum produto|sem produtos|não encontrei/i.test(reply)) {
    reply = 'Aqui está o nosso catálogo. Toque em Adicionar ou Agendar para continuar.'
  }
  if (rodapeAg.length) reply += '\n\n' + [...new Set(rodapeAg)].join('\n') // regra executável "anexar"
  await registrarUso(usosAg, { canal: 'agente', businessId: id })
  if (rastroAg?.consultou) await (await import('../ai/cerebro/integracao.js')).finalizar(rastroAg, { resposta: reply, via: 'agente', enviadoIA: rastroAg.itens.length > 0 }).catch(() => null)
  if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await hit(id, 'agente', null) }
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  return { reply, produtos: out.produtos || null, pix: out.pix || null, secao: out.secao || null, solicitacao: out.solicitacao || null, pedido: out.pedido || null }
}

export async function businessHitPost(ctx: Ctx) {
  const kind = String(ctx.body?.kind || ''); if (!['whatsapp', 'instagram', 'link', 'compartilhar', 'mapa', 'google_avaliacao'].includes(kind)) return { ok: true } // google_avaliacao = CLIQUE em "Avaliar no Google" (não é publicação)
  const b = await one('SELECT id, owner_id FROM businesses WHERE id = $1', [Number(ctx.params.id)]); if (!b) return { ok: true }
  await hit(Number(b.id), kind, ctx.user ? ctx.user.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b.owner_id))
  return { ok: true }
}
/* ---------- relatórios da empresa ---------- */
async function reportData(bid: number, dias: number) {
  const since = new Date(Date.now() - dias * 86400_000), sinceDay = since.toISOString().slice(0, 10)
  const st = await q('SELECT day, kind, n FROM business_stats WHERE business_id = $1 AND day >= $2', [bid, sinceDay])
  const tot: Record<string, number> = {}, porDia: Record<string, any> = {}
  for (const r of st) { tot[r.kind] = (tot[r.kind] || 0) + Number(r.n); (porDia[r.day] ||= {})[r.kind] = Number(r.n) }
  const rows = await q('SELECT * FROM orders WHERE business_id = $1 AND created_at >= $2', [bid, since.toISOString()])
  const orders = rows.map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total), day: String(o.created_at).slice(0, 10), _oid: Number(o.id), _em: String(o.created_at) }))
  const ok = orders.filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status)))
  const fat = Math.round(ok.reduce((a, o) => a + o.total, 0) * 100) / 100
  const porPag: Record<string, number> = {}, prod: Record<string, { qtd: number; valor: number }> = {}, ref: Record<string, { oid: number; idx: number; em: string; servico: boolean }> = {}
  for (const o of ok) { porPag[o.pagamento] = Math.round(((porPag[o.pagamento] || 0) + o.total) * 100) / 100; (o.itens || []).forEach((i: any, idx: number) => { const p = (prod[i.nome] ||= { qtd: 0, valor: 0 }); p.qtd += i.qtd; p.valor = Math.round((p.valor + i.qtd * i.preco) * 100) / 100
    // pedido mais recente com o item: dele vem a foto (mesma rota assinada dos painéis de pedidos)
    if (!ref[i.nome] || o._em > ref[i.nome].em) ref[i.nome] = { oid: o._oid, idx, em: o._em, servico: o.tipo === 'agendamento' } }) }
  for (const o of orders) { (porDia[o.day] ||= {}).vendas = Math.round(((porDia[o.day].vendas || 0) + (ok.includes(o) ? o.total : 0)) * 100) / 100 }
  const serie = Array.from({ length: dias }, (_, i) => { const d = new Date(Date.now() - (dias - 1 - i) * 86400_000).toISOString().slice(0, 10); return { day: d, ...(porDia[d] || {}) } })
  return { dias, acessos: { impressoes: tot.impressao || 0, visitas: tot.visita || 0, contatos: (tot.whatsapp || 0) + (tot.instagram || 0) + (tot.link || 0) + (tot.mapa || 0), compartilhamentos: tot.compartilhar || 0, conversasAgente: tot.agente || 0, pedidos: tot.pedido || 0 },
    vendas: { pedidos: orders.length, concluidos: ok.length, cancelados: orders.filter((o) => ['cancelado', 'recusado'].includes(o.status)).length, faturamento: fat, ticket: ok.length ? Math.round((fat / ok.length) * 100) / 100 : 0, taxasEntrega: Math.round(ok.reduce((a, o) => a + (o.taxa || 0), 0) * 100) / 100, porPagamento: porPag, topProdutos: await fotosDosAgregados(rows, Object.entries(prod).sort((a, b) => b[1].valor - a[1].valor).slice(0, 5).map(([nome, v]) => ({ nome, ...v, tipo: ref[nome]?.servico ? 'servico' : 'produto', _ref: ref[nome] }))) }, serie }
}
/** Relatórios: foto REAL de cada item agregado (produto, variação ou serviço), pela mesma regra e rota assinada dos painéis de
 *  pedidos (lib/catalogo → fotoDoItem): segue a foto usada na venda, trata foto trocada/removida e nunca usa foto de outro item.
 *  `foto: null` = sem imagem → a tela mostra o espaço reservado. Só endereços vão no JSON (as imagens carregam sob demanda, com cache). */
export async function fotosDosAgregados<T extends { _ref?: { oid: number; idx: number } | null }>(rows: any[], itens: T[]): Promise<(Omit<T, '_ref'> & { foto: string | null })[]> {
  const byId = new Map(rows.map((r) => [Number(r.id), r])), usados = [...new Set(itens.map((t) => t._ref && byId.get(t._ref.oid)).filter(Boolean))]
  const cache = usados.length ? await CAT.fotosDosItens(usados as any[]) : null
  return itens.map(({ _ref, ...t }) => { const row = _ref ? byId.get(_ref.oid) : null
    return { ...t, foto: row && cache && CAT.fotoDoItem(row, _ref!.idx, cache) ? `/api/v2/pedidos/${_ref!.oid}/itens/${_ref!.idx}/foto?s=${fotoSig(_ref!.oid, _ref!.idx)}` : null } as any })
}
export async function reportGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return reportData(Number(b.id), Math.min(365, Math.max(1, Number(ctx.query.get('dias')) || 30))) }
export async function reportAiPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), x = J<any>(b.data, {}), dias = Math.min(365, Math.max(1, Number(ctx.body?.dias) || 30))
  const r = await reportData(Number(b.id), dias), f = await (await import('./modules.js')).fiscalState((ctx.user as any).id).catch(() => null)
  const { complete } = await import('../ai/provider.js')
  const m = await complete([{ role: 'system', content: 'Você é um analista de negócios que ajuda pequenos empreendedores brasileiros. Escreva em português, de forma clara e prática, com no máximo 12 linhas: resumo do período, o que entrou (faturamento, pedidos), destaques (produtos, forma de pagamento), alcance (impressões, visitas, contatos, conversão de visitas em pedidos) e 3 recomendações objetivas. Use SOMENTE os números fornecidos; não invente. Se houver dados do MEI, comente o uso do limite anual e lembre do DAS/declaração quando fizer sentido. Não dê conselho contábil definitivo.' },
    { role: 'user', content: JSON.stringify({ empresa: x.empresa, periodoDias: dias, ...r, vendas: { ...r.vendas, topProdutos: r.vendas.topProdutos.map(({ foto, ...t }) => t) }, serie: undefined, mei: f ? { faturamentoAno: f.faturamento, limite: f.limite, proximoDAS: f.proximo, valorDAS: f.das.total, declaracaoAte: f.dasn.prazo } : null }) }] as any, undefined, { task: 'analise' })
  return { texto: String(m.content || '').trim() }
}
export async function reportMeiPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), mes = /^\d{4}-\d{2}$/.test(String(ctx.body?.mes)) ? String(ctx.body.mes) : new Date().toISOString().slice(0, 7)
  const rows = await q('SELECT * FROM orders WHERE business_id = $1', [b.id])
  const valor = Math.round(rows.filter((o) => String(o.created_at).slice(0, 7) === mes).map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total) })).filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status))).reduce((a, o) => a + o.total, 0) * 100) / 100
  const d = J<any>(b.data, {}); d.meiLancado = d.meiLancado || {}; const ja = Number(d.meiLancado[mes] || 0), diff = Math.round((valor - ja) * 100) / 100
  if (diff <= 0) return { ok: true, adicionado: 0, mes, message: 'O faturamento deste mês já está lançado no MEI.' }
  const { FISCAL_USER_DEFAULT } = await import('./modules.js')
  const fz: any = { ...FISCAL_USER_DEFAULT, ...(await getUM<any>(u.id, 'fiscal', {})) }; fz.receitas = { ...(fz.receitas || {}), [mes]: Math.round(((Number(fz.receitas?.[mes]) || 0) + diff) * 100) / 100 }
  await setUM(u.id, 'fiscal', fz); d.meiLancado[mes] = valor
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, adicionado: diff, mes, message: `R$ ${diff.toFixed(2).replace('.', ',')} lançados no faturamento do MEI (${mes.split('-').reverse().join('/')}).` }
}

/* ---------- agendamentos de serviços ---------- */
const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
/** Sinal antecipado do serviço sob orçamento: valor a pagar agora e o restante (null = a combinar no orçamento). */
export function sinalOf(s: any): { valor: number; restante: number | null; texto: string } | null {
  if (s.modoPreco !== 'orcamento' || !s.sinal?.ativo) return null
  const ref = Number(s.preco) || 0
  const valor = Math.round((s.sinal.tipo === 'pct' ? ref * s.sinal.valor / 100 : Number(s.sinal.valor)) * 100) / 100
  if (!(valor > 0)) return null
  const restante = ref > 0 ? Math.round((ref - valor) * 100) / 100 : null
  const f = (n: number) => 'R$ ' + n.toFixed(2).replace('.', ',')
  return { valor, restante, texto: `Sinal de ${f(valor)}${s.sinal.tipo === 'pct' ? ` (${String(s.sinal.valor).replace('.', ',')}% do valor de referência)` : ''} pago no agendamento. Restante: ${restante !== null ? `${f(restante)} (referência ${f(ref)}, ajustado no orçamento)` : 'definido no orçamento'}.` }
}
export function servicePrice(s: any) { const si = sinalOf(s); if (si) return si.valor
  return s.modoPreco === 'orcamento' ? 0 : s.modoPreco === 'hora' ? Math.round((Number(s.preco) || 0) * ((Number(s.duracao) || 60) / 60) * 100) / 100 : Number(s.preco) || 0 }
/** Faixas já ocupadas no dia: agendamentos novos/aceitos, Pix aguardando (reserva de 30 min) e compromissos do próprio dono na Agenda. */
export async function bookedRanges(b: any, date: string, excluir = 0): Promise<[number, number][]> {
  const hold = Date.now() - 30 * 60_000, agora = Date.now()
  const busy: [number, number][] = []
  for (const r of await q("SELECT id, data, status, created_at FROM orders WHERE business_id = $1 AND status IN ('novo','aceito','aguardando_pagamento','aguardando_aprovacao','sugestao')", [b.id])) {
    if (excluir && Number(r.id) === Number(excluir)) continue // a própria solicitação, ao ser revalidada na aprovação
    if (r.status === 'aguardando_pagamento' && Date.parse(String(r.created_at)) < hold) continue
    const o = J<any>(r.data, {}); if (o.tipo !== 'agendamento') continue
    // solicitações (Permissões de Agendamento) só ocupam o horário com reserva temporária ainda válida
    if (r.status === 'aguardando_aprovacao' || r.status === 'sugestao') { if (!(o.reservaAte && Date.parse(o.reservaAte) > agora)) continue }
    const alvo = r.status === 'sugestao' && o.sugestao ? o.sugestao : o
    if (alvo.data === date) busy.push([toMin(alvo.hora), toMin(alvo.hora) + (Number(o.duracao) || 30)])
  }
  busy.push(...(await ownerBusySlots(Number(b.id), date)))
  return busy
}
/** Horários de início livres. Respeita o horário semanal e, quando configurados, o calendário (feriados, exceções, intervalos e bloqueios). */
export async function freeSlots(b: any, svc: any, date: string, excluir = 0) {
  const x = J<any>(b.data, {}), ef = diaEfetivo(x, date)
  if (!ef.aberto) return []
  const nowBR = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), today = nowBR.toISOString().slice(0, 10), nowMin = nowBR.getHours() * 60 + nowBR.getMinutes() + 30
  return calcularHorarios(ef, Number(svc.duracao) || 30, await bookedRanges(b, date, excluir), { passo: calendarioDe(x).passoMin, porDuracao: calendarioDe(x).gradePorDuracao, agoraMin: date === today ? nowMin : null })
}
export async function slotsGet(ctx: Ctx) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2', [Number(ctx.query.get('servico')), b!.id]); if (!p || !allowsKind(J<any>(b!.data, {}), 'servico')) fail(404, 'Serviço não encontrado.', 'not_found')
  const date = String(ctx.query.get('data') || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) fail(400, 'Data inválida.', 'invalid')
  return { horarios: await freeSlots(b, J<any>(p!.data, {}), date) }
}
export async function bookingPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode agendar na sua própria empresa.', 'invalid')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2 AND active = $3', [Number(ctx.body?.servico), b!.id, true]); if (!p || !allowsKind(J<any>(b!.data, {}), 'servico')) fail(400, 'Serviço indisponível.', 'invalid')
  const s = J<any>(p!.data, {}), date = String(ctx.body?.data || ''), hora = String(ctx.body?.hora || '')
  const ac = await acesso(b, 'servicos', u.id); if (!ac.ok) fail(403, ac.motivo || 'Agendamento indisponível.', ac.codigo || 'forbidden')
  if (ac.modo === 'solicitacao') { const o = await criarSolicitacao(b, s, Number(p!.id), { data: date, hora, obs: ctx.body?.obs, nome: ctx.body?.nome || u.name, telefone: ctx.body?.telefone || u.whatsapp }, { userId: u.id }); return { order: o, solicitacao: true } }
  return withLock(`biz:${b!.id}`, async () => { // verificação + gravação juntas: dois clientes nunca levam o mesmo horário
  if (!(await freeSlots(b, s, date)).includes(hora)) fail(409, 'Esse horário acabou de ser ocupado. Escolha outro.', 'slot_taken')
  const x = J<any>(b!.data, {}), total = servicePrice(s)
  const si = sinalOf(s)
  const data = { tipo: 'agendamento', servico: s.nome, servicoId: Number(p!.id), servicoFotoRef: CAT.refFoto(CAT.fotoAtual(s)), modoPreco: s.modoPreco, duracao: s.duracao, data: date, hora, obs: str(ctx.body?.obs, 300), cliente: str(ctx.body?.nome, 80) || u.name, telefone: str(ctx.body?.telefone, 30) || u.whatsapp, empresa: x.empresa, itens: [{ nome: si ? `Sinal · ${s.nome}` : s.nome, qtd: 1, preco: total, vars: [] }], pagamento: si && (await mpPronto(b)) ? 'online' : 'local', modo: 'agendamento', motivo: '', ...(si ? { sinal: si.valor, restante: si.restante, condicoes: si.texto } : {}) }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, 'novo', total, JSON.stringify(data), nowIso()])
  const o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  void (await import('../lib/descobrir.js')).registrar(u.id, [{ t: 'agendar', k: 's', id: Number(p!.id), bid: Number(b!.id), cat: s.categoria }]).catch(() => {}) // interesse (Descobrir): só do próprio cliente
  let payment: any = null
  crmLink(o?.id)
  if (si && (await mpPronto(b))) { try { await createOrderPix(b, o, u.email, total); const o2 = await one('SELECT data FROM orders WHERE id = $1', [o.id]); payment = J<any>(o2!.data, {}).payment || null } catch { payment = null } }
  await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message)) // entra na Agenda do dono e bloqueia o horário
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  await notify(Number(b!.owner_id), { type: 'order', title: `Novo agendamento #${o.id}: ${s.nome}${si ? ' · sinal R$ ' + si.valor.toFixed(2).replace('.', ',') : ''}`, body: `${data.cliente} · ${date.split('-').reverse().join('/')} às ${hora}`, link: '/x/sua-empresa', ref: `booking:${o.id}` })
  return { order: { id: Number(o.id), status: 'novo', total, ...data, payment, chavePix: si && !payment ? (x.pagamento?.mostrarChave === false ? '' : x.pagamento?.chavePix || '') : '' } }
  })
}

/**
 * Permissões de Agendamento → solicitação de serviço. Registra "Aguardando aprovação": não confirma nada, não entra na Agenda do dono,
 * não cobra sinal antes da aprovação e (salvo reserva temporária configurada) não bloqueia o horário. Avisa o dono e os aprovadores.
 */
export async function criarSolicitacao(b: any, s: any, servicoId: number, f: { data: string; hora: string; obs?: any; nome?: any; telefone?: any }, quem: { userId?: number | null; agente?: boolean }) {
  const date = String(f.data || ''), hora = String(f.hora || '')
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(hora)) fail(400, 'Escolha a data e o horário pretendidos.', 'invalid')
  const cliente = str(f.nome, 80).trim(), tel = str(f.telefone, 30)
  if (!cliente) fail(400, 'Informe seu nome.', 'invalid', 'nome')
  if (quem.agente) { const zd = tel.replace(/\D/g, ''); if (zd.length < 10 || zd.length > 13) fail(400, 'Informe seu WhatsApp com DDD para a empresa responder sua solicitação.', 'invalid', 'telefone') }
  const uid = quem.userId && Number(quem.userId) !== Number(b.owner_id) ? Number(quem.userId) : null
  return withLock(`biz:${b.id}`, async () => {
    if (uid) { // a mesma solicitação repetida (toque duplo, rede lenta) devolve a mesma, sem duplicar
      const ex = (await q("SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 AND status = 'aguardando_aprovacao' ORDER BY id DESC LIMIT 10", [b.id, uid])).find((r) => { const d = J<any>(r.data, {}); return Number(d.servicoId) === Number(servicoId) && d.data === date && d.hora === hora })
      if (ex) return { ...orderOut(ex), statusLabel: ROTULO.aguardando_aprovacao, repetida: true }
    }
    if (!(await freeSlots(b, s, date)).includes(hora)) fail(409, 'Esse horário não está disponível. Escolha outro.', 'slot_taken')
    const x = J<any>(b.data, {}), cfg = paCfg(x).servicos, total = servicePrice(s), si = sinalOf(s), key = randomBytes(8).toString('hex')
    const data: any = { tipo: 'agendamento', solicitacao: true, servico: s.nome, servicoId: Number(servicoId), servicoFotoRef: CAT.refFoto(CAT.fotoAtual(s)), modoPreco: s.modoPreco, duracao: s.duracao, data: date, hora, obs: str(f.obs, 300), cliente, telefone: tel, empresa: x.empresa,
      itens: [{ nome: si ? `Sinal · ${s.nome}` : s.nome, qtd: 1, preco: total, vars: [] }], pagamento: 'local', modo: 'agendamento', motivo: '', guestKey: key,
      ...(uid ? {} : { guest: true }), ...(quem.agente ? { canal: 'agente' } : {}),
      ...(si ? { sinal: si.valor, restante: si.restante, condicoes: si.texto, sinalAposAprovacao: true } : {}),
      ...(cfg.reservaMin > 0 ? { reservaAte: new Date(Date.now() + cfg.reservaMin * 60_000).toISOString() } : {}) }
    historico(data, 'solicitado', quem.agente ? 'cliente (atendimento automático)' : 'cliente')
    await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b.id, uid || b.owner_id, 'aguardando_aprovacao', total, JSON.stringify(data), nowIso()])
    const o = (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 5', [b.id])).find((r) => J<any>(r.data, {}).guestKey === key)!
    crmLink(o.id)
    await hit(Number(b.id), 'pedido', uid, Number(b.owner_id))
    await audit(uid, 'empresa.agendamento.solicitado', Number(b.id), { pedido: Number(o.id), servico: s.nome, data: date, hora, canal: quem.agente ? 'agente' : 'app' })
    await avisarResponsaveis(b, { title: `Nova solicitação de agendamento #${o.id}: ${s.nome}`, body: `${cliente} · ${brDia(date)} às ${hora} · aguardando sua aprovação`, ref: `solic:${o.id}` })
    return { ...orderOut(o), statusLabel: ROTULO.aguardando_aprovacao }
  })
}

/* ---------- agente vendedor: mostra catálogo, cria pedidos e agendamentos, gera Pix ---------- */
const AG_TOOLS = [
  { type: 'function', function: { name: 'mostrar_catalogo', description: 'Mostra ao cliente os produtos/serviços (com foto e preço) na tela. Use quando ele quiser ver o cardápio, o catálogo ou opções.', parameters: { type: 'object', properties: { categoria: { type: 'string' }, busca: { type: 'string' } } } } },
  { type: 'function', function: { name: 'mostrar_secao', description: 'Mostra na tela, dentro do chat, uma seção da empresa: mapa (localização e como chegar), horario, pagamento (formas de pagamento e entrega) ou carrinho.', parameters: { type: 'object', properties: { secao: { type: 'string', enum: ['mapa', 'horario', 'pagamento', 'carrinho'] } }, required: ['secao'] } } },
  { type: 'function', function: { name: 'criar_pedido', description: 'Cria o pedido do cliente depois que ele confirmou itens, forma de recebimento e pagamento. Gera Pix automático se ele escolher pix_online.', parameters: { type: 'object', properties: { agendar_para: { type: 'object', description: 'Só se o cliente quiser o pedido para outra data/hora e a empresa aceitar pedidos agendados: {data: AAAA-MM-DD, hora: HH:MM}.', properties: { data: { type: 'string' }, hora: { type: 'string' } } }, itens: { type: 'array', items: { type: 'object', properties: { produto_id: { type: 'number' }, variante_id: { type: 'number', description: 'Obrigatório quando o produto tem variações (cor, tamanho, modelo): id da variação escolhida pelo cliente (0 = opção principal, o produto sem variação, quando o produto tiver).' }, quantidade: { type: 'number' }, opcoes: { type: 'object', description: 'nome da opção/adicional → nome da escolha' } }, required: ['produto_id'] } }, modo: { type: 'string', enum: ['retirada', 'entrega'] }, endereco: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string', description: 'WhatsApp do cliente com DDD (obrigatório)' }, pagamento: { type: 'string', enum: ['pix_online', 'pix', 'dinheiro', 'cartao'] }, precisa_troco: { type: 'boolean' }, troco_para: { type: 'string', description: 'valor para o troco, se pagar em dinheiro e precisar' }, observacao: { type: 'string' } }, required: ['itens', 'modo', 'nome', 'telefone', 'pagamento'] } } },
  { type: 'function', function: { name: 'horarios_livres', description: 'Lista horários livres de um serviço numa data (AAAA-MM-DD).', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' } }, required: ['servico_id', 'data'] } } },
  { type: 'function', function: { name: 'agendar_servico', description: 'Agenda um serviço (ou envia a SOLICITAÇÃO de agendamento, quando a empresa aprova cada pedido) depois que o cliente confirmou data, horário e nome. pagar_pix=true gera Pix quando o serviço tem valor.', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' }, hora: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string' }, observacao: { type: 'string' }, pagar_pix: { type: 'boolean' } }, required: ['servico_id', 'data', 'hora', 'nome'] } } },
]
async function guestOrder(b: any, data: any, total: number, wantPix: boolean, uid: number | null = null) {
  const key = randomBytes(8).toString('hex')
  const zap = String(data.telefone || '').replace(/\D/g, '')
  if (zap.length < 10 || zap.length > 13) fail(400, 'Informe seu WhatsApp com DDD para a empresa falar com você.', 'invalid', 'telefone')
  // com Pix automático, o pedido só vai para a empresa depois da aprovação do Mercado Pago
  const preMp = !!(wantPix && total > 0 && (await mpPronto(b)))
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b.id, b.owner_id, preMp ? 'aguardando_pagamento' : 'novo', total, JSON.stringify({ ...data, guest: true, guestKey: key, canal: 'agente', ...(uid ? { clienteUid: uid } : {}) }), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [b.id]))[0]
  let pix: any = null
  crmLink(o?.id)
  if (wantPix && total > 0 && (await mpPronto(b))) { try { await createOrderPix(b, o, '', total); o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!; const d = J<any>(o.data, {}); pix = { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt, valor: total, orderId: Number(o.id), key } } catch { await q('DELETE FROM orders WHERE id = $1', [o.id]); fail(502, 'Não foi possível gerar o Pix agora. Escolha outra forma de pagamento.', 'mp_error') } }
  if (data.tipo === 'agendamento' && !preMp) await registerBookingInAgenda(Number(o.id)).catch((e) => console.error('[agenda]', e?.message))
  await hit(Number(b.id), 'pedido', null)
  const avisoAg = { type: 'order', title: `${data.tipo === 'agendamento' ? 'Novo agendamento' : 'Novo pedido'} #${o.id} pelo agente · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente}${data.telefone ? ' · ' + data.telefone : ''}${pix ? ' · Pix gerado' : ''}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` }
  if (!pix && data.tipo !== 'agendamento') await (await import('../lib/recebimento-pedidos.js')).avisarNovoPedido(Number(b.id), Number(o.id), avisoAg) // pedido: canais da empresa
  else if (!pix) await notify(Number(b.owner_id), avisoAg) // agendamento: como antes
  return { id: Number(o.id), key, pix }
}
export async function runAgentTool(b: any, name: string, a: any, out: any, uid: number | null = null) {
  const x = J<any>(b.data, {}), prods = await CAT.enriquecer((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut).filter(inOp(x)), name === 'criar_pedido')
  if (name === 'criar_pedido') for (const p of prods) { p.__estoque = p.estoque ?? null; p.__estoqueVar = Object.fromEntries((p.variantes || []).map((v: any) => [v.id, v.estoque ?? null])) }
  if (name === 'criar_pedido' && !allowsKind(x, 'produto')) return { ok: false, erro: 'Esta empresa trabalha só com serviços: não há pedidos de produtos. Ofereça um agendamento.' }
  if ((name === 'horarios_livres' || name === 'agendar_servico') && !allowsKind(x, 'servico')) return { ok: false, erro: 'Esta empresa não faz agendamentos de serviços. Ofereça o catálogo de produtos.' }
  if (name === 'mostrar_catalogo') {
    if (!prods.length) { out.produtos = []; return { ok: true, total: 0, mensagem: 'A loja ainda não tem produtos ou serviços publicados. Diga isso ao cliente com clareza e ofereça o WhatsApp.' } }
    // palavras genéricas não filtram nada ("catálogo", "todos", "produtos"…): só nome, categoria ou descrição reais
    const GEN = new Set(['catalogo', 'cardapio', 'menu', 'todos', 'todas', 'tudo', 'produtos', 'produto', 'servicos', 'servico', 'opcoes', 'itens', 'geral', 'loja', 'ver', 'mostrar', 'de', 'do', 'da', 'o', 'a', 'os', 'as'])
    const words = nrm(`${a.categoria || ''} ${a.busca || ''}`).split(/[^a-z0-9]+/).filter((w) => w.length > 1 && !GEN.has(w))
    const hay = (p: any) => nrm(`${p.nome} ${p.categoria} ${p.descricao || ''} ${p.palavras || ''}`)
    let list = words.length ? prods.filter((p: any) => words.some((w) => hay(p).includes(w))) : prods
    const filtrou = words.length > 0
    if (!list.length) list = prods // nada bateu com o filtro: mostra o catálogo inteiro em vez de dizer que não há produtos
    list = list.slice(0, 12)
    out.produtos = list.map(cardProduto)
    return { ok: true, total: prods.length, mostrados: out.produtos.map((p: any) => `${p.nome} (id ${p.id}, ${p.aPartirDe ? 'a partir de ' : ''}R$ ${Number(p.preco).toFixed(2).replace('.', ',')}${p.oferta ? ' em oferta' : ''}${p.esgotado ? ', esgotado' : ''})`), aviso: filtrou && list.length === prods.slice(0, 12).length && !words.some((w) => list.some((p: any) => hay(p).includes(w))) ? 'Nenhum item corresponde exatamente ao pedido; mostrei o catálogo completo.' : undefined, instrucao: 'Os cartões com fotos, preços e botões já estão na tela. Não diga que não há produtos.' }
  }
  if (name === 'mostrar_secao') { out.secao = ['mapa', 'horario', 'pagamento', 'carrinho'].includes(a.secao) ? a.secao : 'mapa'; return { ok: true, mostrado: out.secao } }
  // pedido AGENDADO pode ser feito com a loja fechada agora (o horário escolhido é validado dentro do funcionamento)
  const agPedido = name === 'criar_pedido' && a.agendar_para && (a.agendar_para.data || a.agendar_para.hora)
  if (!openState(x).aberto && name !== 'horarios_livres' && !agPedido) return { ok: false, erro: 'A empresa está fechada agora; não é possível concluir pedidos neste momento.' }
  let agendadoPara: { data: string; hora: string } | null = null
  if (agPedido) { const ac = await acesso(b, 'pedidos', uid); if (!ac.ok) return { ok: false, erro: ac.motivo }; try { agendadoPara = validarAgendadoPara(b, a.agendar_para) } catch (e: any) { return { ok: false, erro: e?.message || 'Horário inválido para pedido agendado.' } } }
  if (name === 'criar_pedido') {
    const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
    const linhas: any[] = [], itensIA = Array.isArray(a.itens) ? a.itens.slice(0, 30) : []
    const somaIA = new Map<number, number>(); for (const it of itensIA) somaIA.set(Number(it.produto_id), (somaIA.get(Number(it.produto_id)) || 0) + Math.min(50, Math.max(1, Math.floor(Number(it.quantidade) || 1))))
    for (const it of itensIA) {
      const p: any = prods.find((y: any) => y.id === Number(it.produto_id)); if (!p || p.tipo === 'servico') return { ok: false, erro: `Produto ${it.produto_id} não existe no catálogo.` }
      const esc: Record<string, number> = {}
      for (const v of p.variacoes || []) { const want = nrm(String(it.opcoes?.[v.nome] || '')); const i = v.opcoes.findIndex((o: any) => nrm(o.nome) === want); esc[v.nome] = i >= 0 ? i : 0 }
      const qtd = Math.min(50, Math.max(1, Math.floor(Number(it.quantidade) || 1)))
      try { linhas.push(CAT.linhaPedido(p, { vid: it.variante_id, variante: it.variante, escolhas: esc, qtd, obs: '', qtdTotal: somaIA.get(Number(it.produto_id)) }, unitPrice)) } catch (e: any) { return { ok: false, erro: e?.message || 'Item indisponível.' } }
    }
    if (!linhas.length) return { ok: false, erro: 'O pedido está sem itens.' }
    try { CAT.conferirSomas(new Map(prods.map((p: any) => [Number(p.id), p])), linhas) } catch (e: any) { return { ok: false, erro: e?.message || 'Item sem estoque.' } }
    const modo = a.modo === 'entrega' ? 'entrega' : 'retirada'
    if (modo === 'entrega' && !E.entrega) return { ok: false, erro: 'A loja não faz entrega; ofereça retirada.' }
    if (modo === 'entrega' && String(a.endereco || '').length < 6) return { ok: false, erro: 'Peça o endereço completo de entrega.' }
    if (modo === 'entrega' && E.modoTaxa === 'km') return { ok: false, erro: 'A taxa desta loja é por distância: oriente o cliente a finalizar pelo link da loja para calcular a entrega.' }
    const sub = Math.round(linhas.reduce((s2, l) => s2 + l.preco * l.qtd, 0) * 100) / 100
    if (E.minimo && sub < E.minimo) return { ok: false, erro: `Pedido mínimo de R$ ${E.minimo}.` }
    const pg = a.pagamento === 'pix_online' ? 'online' : a.pagamento
    if (!['online', 'pix', 'dinheiro', 'cartao'].includes(pg) || (pg === 'online' ? !(P.online && (await mpPronto(b))) : !P[pg])) return { ok: false, erro: `Forma de pagamento indisponível. Aceitas: ${[P.online && (await mpPronto(b)) ? 'pix_online' : '', P.pix ? 'pix' : '', P.dinheiro ? 'dinheiro' : '', P.cartao ? 'cartao' : ''].filter(Boolean).join(', ')}.` }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0, total = Math.round((sub + taxa) * 100) / 100
    { const zd = String(a.telefone || '').replace(/\D/g, ''); if (zd.length < 10 || zd.length > 13) return { ok: false, erro: 'Peça o WhatsApp do cliente com DDD antes de finalizar o pedido.' } }
    if (pg === 'dinheiro' && (a.precisaTroco ?? a.precisa_troco) === undefined && !a.trocoPara && !a.troco_para) a.precisaTroco = false
    const troco = pg === 'dinheiro' ? trocoTxt({ precisaTroco: a.precisaTroco ?? a.precisa_troco, trocoPara: a.trocoPara ?? a.troco_para }, total) : ''
    let reservas: any[] = []
    try { reservas = await CAT.reservarEstoque(linhas) } catch (e: any) { return { ok: false, erro: e?.message || 'Item sem estoque.' } }
    let r: any
    try { r = await guestOrder(b, { itens: linhas, subtotal: sub, taxa, ...(reservas.length ? { estoque: reservas } : {}), modo, endereco: modo === 'entrega' ? str(a.endereco, 200) : '', pagamento: pg, troco, obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, motivo: '', ...(agendadoPara ? { agendadoPara } : {}) }, total, pg === 'online', uid); out.pedido = { id: r.id, key: r.key } } catch (e) { await CAT.devolverEstoque(reservas); throw e }
    if (r.pix) out.pix = r.pix
    if (agendadoPara) await audit(uid, 'empresa.pedido.agendado', Number(b.id), { pedido: r.id, ...agendadoPara, canal: 'agente' })
    return { ok: true, pedido: r.id, total, pix_gerado: !!r.pix, ...(agendadoPara ? { agendado_para: `${brDia(agendadoPara.data)} às ${agendadoPara.hora}` } : {}), mensagem: r.pix ? 'Pix gerado e mostrado na tela; o cliente pode pagar pelo QR Code ou copia e cola.' : 'Pedido enviado para a loja.' }
  }
  if (name === 'horarios_livres' || name === 'agendar_servico') {
    const sv: any = prods.find((y: any) => y.id === Number(a.servico_id) && y.tipo === 'servico'); if (!sv) return { ok: false, erro: 'Serviço não encontrado.' }
    const date = String(a.data || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, erro: 'Data no formato AAAA-MM-DD.' }
    const livres = await freeSlots(b, sv, date)
    if (name === 'horarios_livres') return { ok: true, livres: livres.slice(0, 24) }
    { // Permissões de Agendamento: com a opção ligada, vira solicitação (nunca confirmação automática)
      const ac = await acesso(b, 'servicos', uid); if (!ac.ok) return { ok: false, erro: ac.motivo }
      if (ac.modo === 'solicitacao') {
        try { const o: any = await criarSolicitacao(b, sv, Number(sv.id), { data: date, hora: String(a.hora), obs: a.observacao, nome: a.nome, telefone: a.telefone }, { userId: uid, agente: true }); out.solicitacao = { id: o.id, key: o.guestKey }
          return { ok: true, solicitacao: o.id, situacao: 'Aguardando aprovação', mensagem: 'Solicitação enviada. NÃO está confirmada: a empresa vai analisar e responder (aprovar, recusar ou sugerir outro horário). Diga isso ao cliente com clareza.' } }
        catch (e: any) { return { ok: false, erro: e?.message || 'Não foi possível enviar a solicitação.' } }
      }
    }
    return withLock(`biz:${b.id}`, async () => { // verificação + gravação juntas (sem reserva duplicada)
    const livres2 = await freeSlots(b, sv, date)
    if (!livres2.includes(String(a.hora))) return { ok: false, erro: 'Horário indisponível.', livres: livres2.slice(0, 12) }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const total = servicePrice(sv)
      const si = sinalOf(sv), pix = !!a.pagar_pix || (!!si && !!(await mpPronto(b)))
    { const zd = String(a.telefone || '').replace(/\D/g, ''); if (zd.length < 10 || zd.length > 13) return { ok: false, erro: 'Peça o WhatsApp do cliente com DDD antes de agendar.' } }
    const r = await guestOrder(b, { tipo: 'agendamento', servico: sv.nome, servicoId: sv.id, servicoFotoRef: CAT.refFoto(CAT.fotoAtual(sv)), modoPreco: sv.modoPreco, duracao: sv.duracao, data: date, hora: String(a.hora), obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, itens: [{ nome: si ? `Sinal · ${sv.nome}` : sv.nome, qtd: 1, preco: total, vars: [] }], pagamento: pix ? 'online' : 'local', modo: 'agendamento', motivo: '', ...(si ? { sinal: si.valor, restante: si.restante, condicoes: si.texto } : {}) }, total, pix)
    if (r.pix) out.pix = r.pix
    return { ok: true, agendamento: r.id, total, pix_gerado: !!r.pix }
    })
  }
  return { ok: false, erro: 'Ferramenta desconhecida.' }
}
export async function agentOrderGet(ctx: Ctx) {
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), Number(ctx.params.id)])
  const d = o ? J<any>(o.data, {}) : null
  if (!o || !d.guestKey || d.guestKey !== String(ctx.query.get('k') || '')) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown')
  const pago = st === 'approved' || !!d.pago
  return { status: o!.status, pago, ...(d.solicitacao ? { solicitacao: true, statusLabel: ROTULO[o!.status] || o!.status, servico: d.servico, data: d.data, hora: d.hora, motivo: d.motivo || '', sugestao: o!.status === 'sugestao' ? d.sugestao || null : null, pix: !pago && d.payment?.qr && o!.status === 'aceito' ? { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt, valor: Number(o!.total) } : null } : {}) }
}

/* ---------- página do agente: tudo dentro do chat (catálogo, mapa, horário, pagamento, pedido, agendamento, Pix) ---------- */
function agentLimit(ctx: Ctx, id: number, max = 20, grupo = '') {
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `act:${grupo ? grupo + ':' : ''}${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= max) fail(429, 'Muitas ações seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
}
export async function agentInfoGet(ctx: Ctx) {
  const { b, x } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x), ps = await plans(), n = nivelOf(ps, b.plan_id)
  const prods = n >= 4 ? (await CAT.enriquecer((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut).filter(inOp(x)))).map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, descricao: p.descricao || '', categoria: p.categoria || 'Outros', foto: p.destaque?.foto || (p.fotos || [])[0] || null, fotos: p.fotos || [], variacoes: p.variacoes || [], variantes: p.variantes || [], destaque: p.destaque, oferta: p.oferta || null, esgotado: !!p.esgotado, restantes: p.restantes ?? null, tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', duracao: p.duracao || 0, tags: p.tags || [], sinal: sinalOf(p) })) : []
  const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, chavePix: '', cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  return { tema: normalizeTema(x.tema), empresa: x.empresa, categoria: x.categoria, sobre: x.sobre || x.texto || '', endereco: x.endereco || '', referencia: x.referencia || '', lat: b.lat, lng: b.lng, aberto: st.aberto, situacao: st.texto, dias: x.horarioCfg?.dias || null, horario: x.horario || '',
    telefone: (() => { const raw = String(x.contato || '').match(/[\d()+\s-]{10,}/)?.[0] || x.zap || ''; const dg = String(raw).replace(/\D/g, ''); return dg.length >= 10 && dg.length <= 13 ? (dg.length <= 11 ? '+55' + dg : '+' + dg) : null })(), // número do perfil da empresa, pronto para discar
    opcoes: agentOpcoes(x), loja: n >= 4, produtos: prods, categorias: x.categorias || [], etiquetas: x.etiquetas || [], zap: x.zap || null, insta: x.insta || null,
    entrega: { retirada: E.retirada !== false, entrega: !!E.entrega && E.modoTaxa !== 'km', porKm: E.modoTaxa === 'km', taxa: Number(E.taxa) || 0, raio: E.raio, minimo: Number(E.minimo) || 0, tempo: E.tempo || '' },
    pagamento: { online: !!(P.online && (await mpPronto(b))), pix: !!P.pix, chavePix: P.chavePix || '', cartao: !!P.cartao, dinheiro: !!P.dinheiro } }
}
/** Estoque do carrinho do agente de atendimento (mesma regra da loja). */
export async function agentCartCheckPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 60)
  return checarCarrinho(b, ctx.body?.itens)
}
export async function agentOrderPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'criar_pedido', ctx.body || {}, out, ctx.user?.id || null)
  if (!r.ok) fail(400, r.erro || 'Não foi possível criar o pedido.', 'invalid')
  return { ...r, pix: out.pix || null, chave: out.pedido?.key || null }
}
/** Pedidos que ESTE cliente fez NESTA empresa (menu do cabeçalho do agente). Só aparecem pedidos com a chave secreta
 *  guardada neste navegador ("id.chave") ou, para quem está logado, os feitos com a conta (pelo agente ou pelo catálogo).
 *  Agendamentos e solicitações de serviço ficam de fora (têm o próprio acompanhamento); nada de outros clientes. */
export async function agentPedidosGet(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 30, 'pedidos') // contador próprio: consultar não gasta o limite de criar pedidos
  const uid = ctx.user ? Number(ctx.user.id) : 0
  const pares = String(ctx.query.get('k') || '').split(',').map((x) => x.trim().match(/^(\d{1,10})\.([a-f0-9]{16})$/)).filter(Boolean).slice(0, 20) as RegExpMatchArray[]
  if (!uid && !pares.length) return { items: [] }
  const ids = pares.map((m) => Number(m[1]))
  // pedidos do agente são de visitante (gravados em nome da empresa): para quem está logado, confere clienteUid nos mais recentes
  const conds = [ids.length ? `id IN (${ids.map((_, i) => '$' + (i + 3)).join(',')})` : '', uid ? 'customer_id = $2' : '', uid ? 'customer_id = $' + (ids.length + 3) : ''].filter(Boolean).join(' OR ')
  const rows = await q(`SELECT * FROM orders WHERE business_id = $1 AND (${conds}) ORDER BY id DESC LIMIT 300`, [b.id, uid || 0, ...ids, ...(uid ? [b.owner_id] : [])])
  const chaves = new Map(pares.map((m) => [Number(m[1]), m[2]]))
  const { ROT } = await import('./lojas.js')
  const items = rows.filter((o: any) => {
    const d = J<any>(o.data, {})
    if (d.tipo === 'agendamento' || d.solicitacao) return false
    if (d.guest) return (d.guestKey && chaves.get(Number(o.id)) === d.guestKey) || (uid && Number(d.clienteUid) === uid)
    return uid && Number(o.customer_id) === uid
  }).slice(0, 30).map((o: any) => {
    const d = J<any>(o.data, {}), pend = o.status === 'aguardando_pagamento'
    return { id: Number(o.id), status: o.status, statusLabel: ROT[o.status] || o.status, total: Number(o.total), createdAt: o.created_at,
      itens: (d.itens || []).map((i: any) => ({ nome: String(i.nome || ''), qtd: Number(i.qtd) || 1, preco: Number(i.preco) || 0, vars: (i.vars || []).map((v: any) => typeof v === 'string' ? v : [v.nome, v.valor ?? v.opcao].filter(Boolean).join(': ')).filter(Boolean) })),
      subtotal: Number(d.subtotal ?? o.total), taxa: Number(d.taxa) || 0, desconto: Number(d.desconto) || 0, modo: d.modo || '', endereco: d.modo === 'entrega' ? d.endereco || '' : '', pagamento: d.pagamento || '',
      ...(d.agendadoPara ? { agendadoPara: `${brDia(d.agendadoPara.data)} às ${d.agendadoPara.hora}` } : {}), canal: d.canal === 'agente' ? 'agente' : 'catalogo',
      ...(pend && d.guest && d.guestKey && d.payment?.qr && Date.parse(d.payment.expiresAt || '') > Date.now() ? { pix: { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt, valor: Number(o.total), orderId: Number(o.id), key: d.guestKey || '' } } : {}) }
  })
  return { items }
}
export async function agentSlotsGet(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 40)
  const r: any = await runAgentTool(b, 'horarios_livres', { servico_id: Number(ctx.query.get('servico')), data: String(ctx.query.get('data') || '') }, {})
  if (!r.ok) fail(400, r.erro, 'invalid'); return { horarios: r.livres }
}
export async function agentBookingPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'agendar_servico', ctx.body || {}, out, ctx.user?.id || null)
  if (!r.ok) fail(400, r.erro || 'Não foi possível agendar.', 'invalid')
  return { ...r, pix: out.pix || null, solicitacao: out.solicitacao || null }
}

/* ---------- avaliações ---------- */
/** Cliente avalia um pedido concluído ou um agendamento realizado (uma avaliação por pedido). */
export async function orderReviewPost(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [id, u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  if (o!.status !== 'concluido') fail(400, 'Você pode avaliar quando o pedido for concluído ou o agendamento realizado.', 'invalid')
  const d = J<any>(o!.data, {}); if (d.guest) fail(400, 'Pedido inválido.', 'invalid')
  const rating = Math.round(Number(ctx.body?.rating)); if (!(rating >= 1 && rating <= 5)) fail(400, 'Escolha de 1 a 5 estrelas.', 'invalid')
  if (await one('SELECT id FROM reviews WHERE order_id = $1', [id])) fail(409, 'Você já avaliou este pedido.', 'already')
  await q('INSERT INTO reviews (business_id, user_id, order_id, origem, rating, comment, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [o!.business_id, u.id, id, 'cliente', rating, str(ctx.body?.comment, 400), nowIso()])
  await refreshRatings(true)
  await notify(Number((await one('SELECT owner_id FROM businesses WHERE id = $1', [o!.business_id]))!.owner_id), { type: 'order', title: `Nova avaliação: ${'★'.repeat(rating)}${'☆'.repeat(5 - rating)}`, body: str(ctx.body?.comment, 120) || `Pedido #${id}`, link: '/x/sua-empresa', ref: `review:${id}` })
  return { ok: true, avaliacao: ratingOf(Number(o!.business_id)) }
}
/* ---------- reputação: avaliação também no Google (lib/reputacao.ts) ---------- */
/** Convite de avaliação de UM pedido do próprio cliente: situação, se já avaliou (sistema interno) e o link do Google da empresa. */
export async function orderAvaliacaoGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id)
  const o = await one('SELECT id, business_id, status, data FROM orders WHERE id = $1 AND customer_id = $2', [id, u.id]); if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const b = await one('SELECT id, data FROM businesses WHERE id = $1', [o!.business_id]); const x = J<any>(b?.data, {}), d = J<any>(o!.data, {})
  const R = await import('../lib/reputacao.js'), rep = R.reputacaoDe(x), rv = await one('SELECT rating FROM reviews WHERE order_id = $1', [id])
  return { pedido: id, businessId: Number(o!.business_id), empresa: x.empresa || d.empresa || '', tipo: d.tipo === 'agendamento' ? 'agendamento' : 'pedido', concluido: o!.status === 'concluido', avaliado: rv ? Number(rv.rating) : null,
    convite: R.textoConvite(rep, x.empresa || ''), google: rep.google.ativo ? { url: rep.google.url, direto: rep.google.tipo === 'avaliacao' } : null }
}
/** Configuração de reputação da empresa (só o dono). */
export async function reputacaoGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); const x = J<any>(b.data, {}), R = await import('../lib/reputacao.js'), rep = R.reputacaoDe(x)
  await refreshRatings(true)
  const cliques = Number((await one("SELECT COALESCE(SUM(n), 0) AS n FROM business_stats WHERE business_id = $1 AND kind = 'google_avaliacao' AND day >= $2", [b.id, new Date(Date.now() - 30 * 86400_000).toISOString().slice(0, 10)]))?.n || 0)
  return { reputacao: rep, conviteEfetivo: R.textoConvite(rep, x.empresa || ''), convitePadrao: R.CONVITE_PADRAO, interna: ratingOf(Number(b.id)) || { avg: 0, count: 0 }, cliquesGoogle30d: cliques }
}
export async function reputacaoPut(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), R = await import('../lib/reputacao.js'), body = ctx.body || {}
  const x = J<any>(b.data, {}), atual = R.reputacaoDe(x)
  const next: any = { google: { url: atual.google.url, ativo: atual.google.ativo }, convite: atual.convite }
  let aviso = ''
  if (body.remover === true) next.google = { url: '', ativo: false }
  else if (body.url !== undefined) {
    if (!String(body.url || '').trim()) next.google = { url: '', ativo: false }
    else { const v = R.validarLinkGoogle(String(body.url)); if (!v.ok) fail(400, v.erro, 'invalid', 'url'); next.google.url = v.url; aviso = v.aviso || '' }
  }
  if (typeof body.ativo === 'boolean') { if (body.ativo && !next.google.url) fail(400, 'Cadastre o link do Google antes de ativar o convite.', 'invalid', 'url'); next.google.ativo = body.ativo }
  if (body.convite !== undefined) { const c = String(body.convite || '').trim().slice(0, 300), proib = R.conviteProibido(c); if (proib) fail(400, proib, 'invalid', 'convite'); next.convite = c }
  // grava só a chave de reputação (as demais configurações da empresa ficam intactas, mesmo com outra tela salvando ao mesmo tempo)
  const fresh = await one('SELECT data FROM businesses WHERE id = $1 AND owner_id = $2', [b.id, u.id]); const xd = J<any>(fresh?.data, {}); xd.reputacao = next
  await q('UPDATE businesses SET data = $1 WHERE id = $2 AND owner_id = $3', [JSON.stringify(xd), b.id, u.id])
  await audit(u.id, 'empresa.reputacao', Number(b.id), { googleAtivo: next.google.ativo, temLink: !!next.google.url })
  const rep = R.reputacaoDe(xd)
  return { reputacao: rep, conviteEfetivo: R.textoConvite(rep, xd.empresa || ''), convitePadrao: R.CONVITE_PADRAO, aviso }
}
/** Pedidos do cliente: quais já foram avaliados. */
export async function myReviewsGet(ctx: Ctx) { const u = requireUser(ctx); return { orders: (await q('SELECT order_id, rating FROM reviews WHERE user_id = $1 AND order_id IS NOT NULL', [u.id])).map((r) => ({ orderId: Number(r.order_id), rating: Number(r.rating) })) } }
/** Administrador atribui nota a uma empresa (uma nota por administrador e empresa). */
export async function adminRatingPut(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  const id = Number(ctx.params.id), rating = Math.round(Number(ctx.body?.rating))
  if (!(await one('SELECT id FROM businesses WHERE id = $1', [id]))) fail(404, 'Empresa não encontrada.', 'not_found')
  await q("DELETE FROM reviews WHERE business_id = $1 AND origem = 'admin' AND user_id = $2", [id, u.id])
  if (rating >= 1 && rating <= 5) await q('INSERT INTO reviews (business_id, user_id, origem, rating, comment, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [id, u.id, 'admin', rating, str(ctx.body?.comment, 400), nowIso()])
  await refreshRatings(true)
  return { ok: true, avaliacao: ratingOf(id) }
}
export async function adminRatingsGet(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  await refreshRatings(true)
  const mine = new Map((await q("SELECT business_id, rating FROM reviews WHERE origem = 'admin' AND user_id = $1", [u.id])).map((r) => [Number(r.business_id), Number(r.rating)]))
  return { items: (await q("SELECT id, data, status FROM businesses WHERE status IN ('ativo','aprovado') ORDER BY id DESC")).map((b) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa, status: b.status, avaliacao: ratingOf(Number(b.id)), minha: mine.get(Number(b.id)) || 0 })) }
}

/* ---------- endereço amigável do assistente: domínio oficial + /<nome-da-empresa> (sem prefixo) ---------- */
import { slugify, RESERVED_SLUGS } from '../lib/publicurl.js'
/** Garante um identificador único para a empresa (gerado do nome; só muda se o dono trocar o nome). */
/** Endereço já definido e válido (mesma regra do início de ensureSlug), sem consultar o banco. Vazio = chamar ensureSlug. */
function slugPronto(x: any): string { const base = slugify(x.empresa || ''); return x.slug && (x.slugCustom || x.slugBase === base || !x.slugBase) && !RESERVED_SLUGS.has(x.slug) ? x.slug : '' }
export async function ensureSlug(id: number): Promise<string> {
  const b = await one('SELECT id, data FROM businesses WHERE id = $1', [id]); if (!b) return ''
  const x = J<any>(b.data, {}), base = slugify(x.empresa || '')
  if (x.slug && (x.slugCustom || x.slugBase === base || !x.slugBase) && !RESERVED_SLUGS.has(x.slug)) return x.slug // endereço personalizado nunca é trocado sozinho
  const usados = await slugsEmUso(id)
  let slug = base, n = 2
  while (usados.has(slug) || RESERVED_SLUGS.has(slug)) slug = `${base}-${n++}` // nome repetido ou reservado: alternativa exclusiva, sem mexer no nome comercial
  if (x.slug && x.slug !== slug) x.slugsAntigos = [...new Set([...(x.slugsAntigos || []), x.slug])].slice(-10) // links antigos continuam abrindo
  x.slug = slug; x.slugBase = base
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  return slug
}
/** Endereços já ocupados por OUTRAS empresas (inclusive os antigos, que ainda redirecionam). */
async function slugsEmUso(exceptId: number) {
  const s = new Set<string>()
  for (const r of await q('SELECT id, data FROM businesses WHERE id <> $1', [exceptId])) { const x = J<any>(r.data, {}); if (x.slug) s.add(x.slug); for (const o of x.slugsAntigos || []) s.add(o) }
  return s
}
/** O dono escolhe o próprio endereço (ex.: o nome já está ocupado). Valida formato, reservados e exclusividade. */
export async function setCustomSlug(id: number, raw: string) {
  const want = slugify(raw); if (!String(raw || '').trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(want) || want.length < 3) fail(400, 'Use pelo menos 3 letras ou números. Espaços viram hífen.', 'invalid', 'slug')
  if (RESERVED_SLUGS.has(want)) fail(409, 'Este endereço é reservado pelo sistema. Escolha outro.', 'slug_reservado', 'slug')
  if ((await slugsEmUso(id)).has(want)) fail(409, 'Este endereço já está em uso por outra empresa. Escolha outro.', 'slug_em_uso', 'slug')
  const b = (await one('SELECT id, data FROM businesses WHERE id = $1', [id]))!, x = J<any>(b.data, {})
  if (x.slug && x.slug !== want) x.slugsAntigos = [...new Set([...(x.slugsAntigos || []), x.slug])].slice(-10)
  x.slugsAntigos = (x.slugsAntigos || []).filter((s: string) => s !== want); x.slug = want; x.slugCustom = true
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id]); return want
}
export async function agentSlugPut(ctx: Ctx) { const { b } = await ownBusiness(ctx); const slug = await setCustomSlug(Number(b.id), String(ctx.body?.slug || '')); return { ok: true, slug, link: await agentLink(Number(b.id)) } }
export async function slugOfId(id: number) { return (await one('SELECT id FROM businesses WHERE id = $1', [id])) ? ensureSlug(id) : null }
export async function idOfSlug(slug: string) {
  for (const r of await q('SELECT id, data FROM businesses')) { const x = J<any>(r.data, {}); if (x.slug === slug || (x.slugsAntigos || []).includes(slug)) return Number(r.id) }
  // empresas antigas sem identificador: gera na primeira visita
  for (const r of await q('SELECT id, data FROM businesses')) { const x = J<any>(r.data, {}); if (!x.slug && slugify(x.empresa || '') === slug) { await ensureSlug(Number(r.id)); return Number(r.id) } }
  return null
}
export const agentLink = async (id: number) => `${pub()}/${await ensureSlug(id)}`

/* ---------- e-mails da empresa: remetente, resposta, SMTP próprio (opcional) e modelos ---------- */
export async function bizEmailPut(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, M = await import('../lib/mail.js'), { seal } = await import('../lib/settings.js')
  // SMTP (servidor, usuário, senha cifrada e se está em uso) fica na integração "smtp" da empresa; remetente, resposta e limites seguem em businesses.data
  const I = await import('../lib/integracoes.js'), bid = Number(b.id), si = await I.dados(bid, 'smtp')
  const x = J<any>(b.data, {}), cur = { ...(x.email || {}), smtp: si.smtp ?? x.email?.smtp, smtpProprio: si.smtpProprio ?? x.email?.smtpProprio }
  const remetenteEmail = String(body.remetenteEmail ?? cur.remetenteEmail ?? '').trim().toLowerCase(), responderPara = String(body.responderPara ?? cur.responderPara ?? '').trim().toLowerCase()
  if (remetenteEmail && !M.validEmail(remetenteEmail)) fail(400, 'E-mail do remetente inválido.', 'invalid')
  if (responderPara && !M.validEmail(responderPara)) fail(400, 'E-mail para respostas inválido.', 'invalid')
  const smtp = body.smtp ? { host: str(body.smtp.host, 120), port: Math.min(65535, Math.max(1, Number(body.smtp.port) || 465)), seguranca: ['ssl', 'starttls', 'nenhuma'].includes(body.smtp.seguranca) ? body.smtp.seguranca : 'ssl', usuario: str(body.smtp.usuario, 160), senha: body.smtp.senha ? await seal(String(body.smtp.senha)) : cur.smtp?.senha || '' } : cur.smtp
  const tpl: any = {}; for (const k of ['pedidos', 'comunicados']) if (body.templates?.[k]) tpl[k] = { assunto: str(body.templates[k].assunto, 200), corpo: str(body.templates[k].corpo, 6000) }
  const smtpProprio = body.smtpProprio === undefined ? !!cur.smtpProprio : !!body.smtpProprio
  if (smtpProprio && (!smtp?.host || !remetenteEmail)) fail(400, 'Para usar o SMTP próprio, preencha servidor e e-mail do remetente.', 'invalid')
  if (smtp || si.smtp || body.smtpProprio !== undefined) await I.atualizar(bid, 'smtp', (c) => ({ ...c, smtpProprio, ...(smtp ? { smtp } : {}) }), 'configuração de e-mail da empresa')
  // a cópia antiga do SMTP em businesses.data (se existir) fica como estava: não é mais lida nem atualizada
  const ant = x.email || {}
  x.email = { remetenteNome: str(body.remetenteNome ?? cur.remetenteNome, 80), remetenteEmail, responderPara, limiteHora: Math.max(1, Math.round(Number(body.limiteHora ?? cur.limiteHora) || 30)), limiteDia: Math.max(1, Math.round(Number(body.limiteDia ?? cur.limiteDia) || 150)), ...(ant.smtp ? { smtp: ant.smtp, smtpProprio: ant.smtpProprio } : {}) }
  if (Object.keys(tpl).length) x.emailTemplates = { ...(x.emailTemplates || {}), ...tpl }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), b.id])
  return bizEmailView(b, x)
}
const bizEmailView = async (b: any, x: any) => { const si = await (await import('../lib/integracoes.js')).dados(Number(b.id), 'smtp'), smtp = si.smtp ?? null
  return { email: { ...(x.email || {}), smtpProprio: !!si.smtpProprio, smtp: smtp ? { ...smtp, senha: '', temSenha: !!smtp.senha } : null }, templates: x.emailTemplates || {} } }
export async function bizEmailPost(ctx: Ctx) {
  const { b, u } = await ownBusiness(ctx) as any, M = await import('../lib/mail.js')
  if (ctx.body?.action === 'testar') return M.testConnection(Number(b.id))
  if (ctx.body?.action === 'ver') return bizEmailView(b, J<any>(b.data, {}))
  if (ctx.body?.action === 'enviar_teste') { const to = String(ctx.body?.to || u?.email || ''); const r = await M.enqueueMail({ kind: 'teste', to, businessId: Number(b.id), dedupe: `teste:b${b.id}:${Date.now()}` }); if (!r.queued) fail(400, 'Não foi para a fila: ' + r.motivo, 'invalid'); return { ok: true, id: r.id } }
  fail(400, 'Ação inválida.', 'invalid')
}

/** Tema da empresa (rota leve usada para manter catálogo e agente sincronizados; não conta como visita). */
export async function themeGet(ctx: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const dono = !!(ctx.user && b && Number(b.owner_id) === Number(ctx.user.id))
  if (!b || (b.status !== 'ativo' && !dono)) fail(404, 'Empresa não encontrada.', 'not_found')
  return { tema: normalizeTema(J<any>(b!.data, {}).tema) }
}

/* ---------- Incentivos do carrinho (Sua empresa → Ajustes → Incentivos do carrinho) ---------- */
export async function incentivosGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); const INC = await import('../lib/incentivos.js')
  const lista = await INC.listar(Number(b.id)), res = await INC.resultados(Number(b.id)), m = await INC.moedaCashback(Number(b.id)), x = J<any>(b.data, {})
  return {
    itens: lista.map((i) => ({ ...i, texto: INC.textoBeneficio(i), situacao: INC.situacao(i), resultados: res.get(i.id) || { pedidos: 0, vendido: 0, desconto: 0, cashback: 0 }, moedasCashback: i.beneficio === 'cashback' && m ? INC.moedasDoCashback(i.valor, m.desconto) : null })),
    moeda: m ? { simbolo: m.simbolo, desconto: m.desconto, disponiveis: m.disponiveis } : null,
    entrega: !!x.entrega?.entrega,
  }
}
export async function incentivosPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); const INC = await import('../lib/incentivos.js'); const body = ctx.body || {}
  const id = Number(body.id) || 0
  if (body.action === 'excluir') await INC.excluir(Number(b.id), id)
  else if (body.action === 'status') await INC.mudarStatus(Number(b.id), id, body.ativo === true)
  else await INC.salvar(b, body, id || undefined)
  return incentivosGet(ctx)
}
