// Fase 10 — Central de Agentes: rotas EXCLUSIVAS de administradores autorizados
// (Administrador Principal, ou administrador com a permissão "agents.manage" ou "panel.manage").
// Mostra só metadados e números (agentes, etapas, falhas, consumo) — nunca o texto das conversas dos usuários.
// Toda mudança fica na auditoria (audit_log, ações "agentes.*").
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser, hydrateUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { q, one, J } from '../db/index.js'

const D = () => import('../ai/agentes-dominio.js')
const A = () => import('../ai/agentes.js')
function admin(ctx: Ctx) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const p = effectivePermissions(u); if (!p.includes('agents.manage') && !p.includes('panel.manage')) fail(403, 'Seu acesso de administrador não inclui a Central de Agentes. Peça ao Administrador Principal a permissão "Central de Agentes".', 'forbidden')
  return u
}
const b = (ctx: Ctx) => (ctx.body && typeof ctx.body === 'object' ? ctx.body : {}) as any
const num = (ctx: Ctx, k = 'id') => { const n = Number(ctx.params[k]); if (!Number.isInteger(n) || n <= 0) fail(400, 'Identificador inválido.', 'invalid'); return n }
const dias = (n: number) => new Date(Date.now() - n * 864e5).toISOString()
const med = (xs: number[]) => (xs.length ? Math.round(xs.reduce((a, x) => a + x, 0) / xs.length) : null)
const pub = (r: any) => ({ id: Number(r.id), usuario: Number(r.user_id), empresa: r.business_id != null ? Number(r.business_id) : null, nivel: r.nivel, status: r.status, dominios: J<any>(r.dominios, []), etapas: J<any>(r.etapas, []), decisoes: J<any>(r.decisoes, []), acoes: J<any>(r.acoes, []), chamadasIA: Number(r.chamadas_ia || 0), ms: Number(r.ms || 0), criadaEm: r.created_at, concluidaEm: r.finished_at,
  achados: Object.fromEntries(Object.entries(J<any>(r.achados, {})).filter(([k]) => !k.startsWith('ia:')).map(([k, v]) => [k, (v as any[]).length])) }) // só a QUANTIDADE de achados: o conteúdo é dado do usuário

export async function painel() {
  const DM = await D(), AG = await A(), cfg = await DM.f10Cfg(), mc = await AG.maCfg()
  const rows = await q('SELECT etapas, status, chamadas_ia, ms, created_at FROM agent_tasks WHERE created_at >= $1 ORDER BY id DESC LIMIT 4000', [dias(30)]).catch(() => [] as any[])
  const por: Record<string, { n: number; ok: number; ms: number[]; falhas: Record<string, number> }> = {}
  for (const r of rows) for (const e of J<any>(r.etapas, [])) { if (!e.agente || e.tipo === 'consolidacao') continue; const x = (por[e.agente] ||= { n: 0, ok: 0, ms: [], falhas: {} }); x.n++; if (e.status === 'ok' || e.status === 'sem dados') x.ok++; else if (e.status !== 'pulado') x.falhas[e.motivo || e.status] = (x.falhas[e.motivo || e.status] || 0) + 1; x.ms.push(Number(e.ms) || 0) }
  const met = (id: string) => { const x = por[id]; return { acionamentos: x?.n || 0, sucesso: x?.n ? Math.round((x.ok / x.n) * 100) : null, msMedio: x ? med(x.ms) : null, falhas: x?.falhas || {} } }
  const lab = await q("SELECT id, name, role, status FROM lab_agents WHERE status IN ('gradual','publicado')").catch(() => [] as any[])
  const agentes = [
    ...DM.DOMINIO.map((a) => ({ id: a.id, nome: a.nome, tipo: 'dominio', especialidade: a.especialidade, responsabilidades: a.responsabilidades, escopos: a.escopos.map((e) => ({ id: e, nome: DM.ESCOPO_NOME[e], ativo: !cfg.permissoes[a.id] || cfg.permissoes[a.id].includes(e) })), raciocinioIA: a.perfilIA ? AG.AGENTES.find((x) => x.id === a.perfilIA)?.nome : null, acoes: a.acoes, ativo: cfg.ativo && cfg.dominio[a.id] !== false, autonomia: cfg.autonomia[a.id] || 1, estado: !cfg.ativo || cfg.dominio[a.id] === false ? 'desligado' : 'ativo', usaIA: false, ...met(a.id) })),
    ...AG.AGENTES.map((a) => ({ id: a.id, nome: a.nome, tipo: 'raciocinio', especialidade: a.papel, responsabilidades: [a.instrucao], escopos: [], ativo: mc.ativo && mc.agentes[a.id] !== false, estado: !mc.ativo || mc.agentes[a.id] === false ? 'desligado' : AG.pausado(a.id) ? 'pausado' : 'ativo', usaIA: true, acessoAchados: (DM.ACESSO_ACHADOS[a.id] || []).map((id) => DM.DOMINIO.find((x) => x.id === id)?.nome), ...met(a.id) })),
    { id: 'revisor', nome: AG.REVISOR.nome, tipo: 'validacao', especialidade: 'Analisa possíveis falhas antes da resposta (situações complexas e decisórias)', responsabilidades: [AG.REVISOR.instrucao], escopos: [], ativo: cfg.ativo && cfg.debate, estado: cfg.ativo && cfg.debate ? 'ativo' : 'desligado', usaIA: true, ...met('revisor') },
    ...AG.AGENTES_FLUXO.map((a) => ({ id: a.id, nome: a.nome, tipo: 'fluxo', especialidade: a.desc, responsabilidades: [], escopos: [], ativo: true, estado: 'ativo', usaIA: a.id === 'execucao' })),
    ...lab.map((x: any) => ({ id: 'lab:' + x.id, nome: x.name, tipo: 'laboratorio', especialidade: x.role, responsabilidades: [], escopos: [], ativo: true, estado: x.status === 'gradual' ? 'liberação gradual' : 'publicado', usaIA: true })),
  ]
  const hoje = new Date(); hoje.setUTCHours(0, 0, 0, 0)
  const desde = (d: string) => rows.filter((r: any) => String(r.created_at) >= d)
  const cons = (rs: any[]) => ({ tarefas: rs.length, comIA: rs.filter((r) => Number(r.chamadas_ia) > 0).length, chamadasIA: rs.reduce((a, r) => a + Number(r.chamadas_ia || 0), 0), msMedio: med(rs.map((r) => Number(r.ms) || 0)), semIA: rs.filter((r) => !Number(r.chamadas_ia)).length })
  const porDia: any[] = []; for (let i = 6; i >= 0; i--) { const d = new Date(hoje.getTime() - i * 864e5).toISOString().slice(0, 10); const x = rows.filter((r: any) => String(r.created_at).slice(0, 10) === d); porDia.push({ dia: d, tarefas: x.length, chamadasIA: x.reduce((a: number, r: any) => a + Number(r.chamadas_ia || 0), 0) }) }
  const falhas: any[] = []
  for (const r of rows.slice(0, 400)) for (const e of J<any>(r.etapas, [])) if (e.status === 'falhou' && falhas.length < 20) falhas.push({ agente: e.agente, motivo: e.motivo || 'falha', em: r.created_at })
  const and = (await D()).emAndamento()
  return {
    config: { ativo: cfg.ativo, maxAgentes: mc.maxAgentes, tempoMaxMs: mc.tempoMaxMs, agentesIA: mc.agentes, dominio: cfg.dominio, autonomia: cfg.autonomia, permissoes: cfg.permissoes, debate: cfg.debate, limites: cfg.limites },
    niveisAutonomia: DM.AUTONOMIA_NOME, escopos: DM.ESCOPO_NOME,
    agentes, andamento: and,
    consumo: { hoje: cons(desde(hoje.toISOString())), dias7: cons(desde(dias(7))), dias30: cons(rows), porDia },
    status: rows.reduce((m: any, r: any) => ({ ...m, [r.status]: (m[r.status] || 0) + 1 }), {}),
    falhas,
    empresasConfiguradas: Object.keys(cfg.empresas).length,
  }
}
async function salvar(u: any, body: any) {
  const DM = await D(), atual: any = await getConfig<any>('multiagente', {}), cfg = await DM.f10Cfg()
  let novo: any
  try { novo = DM.validarF10(body, cfg) } catch (e: any) { fail(400, e.message, 'invalid') }
  if (body.ativo !== undefined) { if (typeof body.ativo !== 'boolean') fail(400, 'Chave geral inválida.', 'invalid'); novo.ativo = body.ativo }
  if (body.agentesIA !== undefined) { const AG = await A(); if (typeof body.agentesIA !== 'object' || Object.entries(body.agentesIA).some(([k, v]) => !AG.AGENTES.some((a) => a.id === k) || typeof v !== 'boolean')) fail(400, 'Agentes de raciocínio inválidos.', 'invalid'); novo.agentes = { ...(atual.agentes || {}), ...body.agentesIA } }
  if (body.maxAgentes !== undefined) { if (!Number.isInteger(body.maxAgentes) || body.maxAgentes < 1 || body.maxAgentes > 5) fail(400, 'Máximo de agentes por mensagem: 1 a 5.', 'invalid'); novo.maxAgentes = body.maxAgentes }
  if (body.tempoMaxMs !== undefined) { if (!Number.isInteger(body.tempoMaxMs) || body.tempoMaxMs < 2000 || body.tempoMaxMs > 20000) fail(400, 'Tempo máximo: 2 a 20 s.', 'invalid'); novo.tempoMaxMs = body.tempoMaxMs }
  if (!Object.keys(novo).length) fail(400, 'Nada para alterar.', 'invalid')
  await setConfig('multiagente', { ...atual, ...novo, atualizadoEm: new Date().toISOString() })
  await audit(u.id, 'agentes.config', null, novo)
  return painel()
}

export const R: [string, string, (c: Ctx) => Promise<unknown>][] = [
  ['GET', '/api/panel/agentes', async (c) => { admin(c); return painel() }],
  ['PUT', '/api/panel/agentes', async (c) => salvar(admin(c), b(c))],
  ['GET', '/api/panel/agentes/tarefas', async (c) => {
    admin(c)
    const st = String(c.query.get('status') || ''), ag = String(c.query.get('agente') || ''), lim = Math.min(200, Math.max(1, Number(c.query.get('limite')) || 50))
    let rows = await q('SELECT * FROM agent_tasks ORDER BY id DESC LIMIT 600').catch(() => [] as any[])
    if (st) rows = rows.filter((r: any) => r.status === st)
    if (ag) rows = rows.filter((r: any) => J<any>(r.etapas, []).some((e: any) => e.agente === ag) || J<any>(r.dominios, []).includes(ag))
    return { items: rows.slice(0, lim).map(pub), total: rows.length }
  }],
  ['GET', '/api/panel/agentes/tarefas/:id', async (c) => { admin(c); const r = await one('SELECT * FROM agent_tasks WHERE id = $1', [num(c)]); if (!r) fail(404, 'Tarefa não encontrada.', 'not_found'); return pub(r) }],
  ['POST', '/api/panel/agentes/tarefas/:id/interromper', async (c) => {
    const u = admin(c), id = num(c), DM = await D()
    const r = await one('SELECT status FROM agent_tasks WHERE id = $1', [id]); if (!r) fail(404, 'Tarefa não encontrada.', 'not_found')
    const ok = DM.interromper(id)
    if (!ok && r!.status !== 'executando') fail(409, 'Esta tarefa já terminou.', 'invalid')
    if (!ok) await q("UPDATE agent_tasks SET status = 'interrompida', finished_at = $1 WHERE id = $2", [new Date().toISOString(), id]) // ficou presa (reinício do servidor)
    await audit(u.id, 'agentes.tarefa.interromper', id, {})
    return { ok: true, interrompida: true }
  }],
  ['POST', '/api/panel/agentes/tarefas/:id/reverter', async (c) => {
    const u = admin(c), id = num(c)
    const r = await one('SELECT user_id, acoes FROM agent_tasks WHERE id = $1', [id]); if (!r) fail(404, 'Tarefa não encontrada.', 'not_found')
    const acoes = J<any>(r!.acoes, []).filter((a: any) => a.execucao); if (!acoes.length) fail(409, 'Esta tarefa não executou nenhuma ação para reverter.', 'invalid')
    const dono = await one('SELECT * FROM users WHERE id = $1', [r!.user_id]); if (!dono) fail(404, 'Usuário não encontrado.', 'not_found')
    const EX = await import('../ai/execucao.js'), out: any[] = []
    for (const a of acoes) {
      try { const e = await EX.obter(Number(r!.user_id), a.execucao)
        if (['aguardando_confirmacao', 'aguardando_autorizacao', 'na_fila'].includes(e.status)) { await EX.cancelar(hydrateUser(dono), a.execucao); out.push({ execucao: a.execucao, resultado: 'cancelada' }) }
        else { await EX.reverter(hydrateUser(dono), a.execucao); out.push({ execucao: a.execucao, resultado: 'revertida' }) } }
      catch (e: any) { out.push({ execucao: a.execucao, resultado: 'não revertida', motivo: String(e?.message || e).slice(0, 120) }) }
    }
    await q('UPDATE agent_tasks SET acoes = $1 WHERE id = $2', [JSON.stringify(J<any>(r!.acoes, []).map((a: any) => ({ ...a, revertida: out.find((x) => x.execucao === a.execucao)?.resultado }))), id])
    await audit(u.id, 'agentes.tarefa.reverter', id, { resultado: out })
    return { ok: true, resultado: out }
  }],
  ['GET', '/api/panel/agentes/empresas', async (c) => {
    admin(c); const DM = await D(), cfg = await DM.f10Cfg(), termo = String(c.query.get('q') || '').toLowerCase()
    const rows = (await q("SELECT id, data, status FROM businesses WHERE status = 'ativo' ORDER BY id DESC LIMIT 500")).map((x: any) => ({ id: Number(x.id), nome: J<any>(x.data, {}).empresa || `Empresa #${x.id}` }))
    const lista = rows.filter((x) => !termo || x.nome.toLowerCase().includes(termo) || String(x.id) === termo).slice(0, 50)
    return { items: lista.map((x) => ({ ...x, config: { agentes: Object.fromEntries(DM.IDS_DOMINIO.map((id) => [id, cfg.empresas[String(x.id)]?.agentes?.[id] !== false])), autonomiaMax: cfg.empresas[String(x.id)]?.autonomiaMax || 4 }, personalizada: !!cfg.empresas[String(x.id)] })) }
  }],
  ['PUT', '/api/panel/agentes/empresas/:id', async (c) => {
    const u = admin(c), id = num(c), DM = await D()
    if (!(await one('SELECT id FROM businesses WHERE id = $1', [id]))) fail(404, 'Empresa não encontrada.', 'not_found')
    let v: any; try { v = DM.validarEmpresa(b(c)) } catch (e: any) { fail(400, e.message, 'invalid') }
    const atual: any = await getConfig<any>('multiagente', {}), emp = { ...(atual.empresas || {}) }
    emp[String(id)] = { ...(emp[String(id)] || {}), ...v }
    await setConfig('multiagente', { ...atual, empresas: emp, atualizadoEm: new Date().toISOString() })
    await audit(u.id, 'agentes.empresa', id, v)
    return { ok: true, config: emp[String(id)] }
  }],
]
