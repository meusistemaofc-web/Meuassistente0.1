// Página de apresentação (/conheca): dados públicos e REAIS para a landing page — planos de anúncio com preço, prazo e o que
// cada nível inclui (mesmos textos da tela Anunciar), preço do Agente de Atendimento e quais módulos o administrador deixou
// ligados (a página esconde o que estiver desligado, para nunca anunciar um recurso indisponível). Nada pessoal, só leitura.
import type { Ctx } from '../lib/http.js'

/** O que cada nível de plano inclui — os mesmos textos da prévia em Anunciar (modules-addon.js → NIVEL). */
export const NIVEL_TXT: Record<number, string> = {
  1: 'Cartão patrocinado no chat e na busca, com link.',
  2: 'Tudo do anterior + botões de WhatsApp e Instagram.',
  3: 'Tudo do anterior + página da empresa com localização e horário.',
  4: 'Tudo do anterior + loja com produtos, variações e pedidos, e um link direto do seu catálogo para compartilhar com seus clientes.',
}
export async function apresentacaoGet(_ctx: Ctx) {
  const { modules } = await import('../lib/usermod.js'), { plans } = await import('./ads.js'), { agentPlanPublic } = await import('./businesses.js')
  const m = await modules()
  const planos = m.anuncios === false ? [] : (await plans()).filter((p: any) => p && p.id && Number(p.preco) >= 0).map((p: any) => ({ id: String(p.id), nome: String(p.nome), preco: Number(p.preco), dias: Number(p.dias) || 30, nivel: Number(p.nivel) || 1, inclui: NIVEL_TXT[Number(p.nivel)] || '' })).sort((a, b) => a.nivel - b.nivel || a.preco - b.preco)
  return {
    planos,
    agente: m.agente ? await agentPlanPublic() : null,
    modulos: { empresas: m.empresas !== false, catalogo: m.catalogo !== false, anuncios: m.anuncios !== false, agente: !!m.agente, financas: m.financas !== false, lembretes: m.lembretes !== false, voz: m.voz !== false, imagens: m.imagens !== false },
  }
}
