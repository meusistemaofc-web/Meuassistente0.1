// /api/memory — memórias do assistente (Perfil → Memória do assistente).
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, B, J } from '../db/index.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import * as ME from '../ai/memoria-evolutiva.js'

const KINDS = ['preference', 'fact', 'person', 'routine', 'goal']
export const memSettings = (u: SessionUser) => { const c = ME.cfgUsuario(u); return { enabled: c.enabled, summaries: u.memory_settings.summaries === true, experiencias: c.experiencias, associativa: c.associativa, retencao: c.retencao } }
const ser = (r: any) => ({ id: Number(r.id), content: r.content, kind: r.kind, source: r.source, active: B(r.active), useCount: Number(r.use_count), createdAt: r.created_at, updatedAt: r.updated_at, purpose: null,
  layer: ME.camadaDe(r.kind), originConversationId: r.origin_conversation_id || null, lastUsedAt: r.last_used_at || null, status: r.status || 'atual', versions: J<any[]>(r.versions, []) })
const SECRET_RE = /(senha|password|token|cart[aã]o de cr[eé]dito|cvv|pin\b)/i

export async function addMemory(userId: number, content: string, kind = 'fact', source = 'manual', originConversationId: string | null = null) {
  const c = content.trim().slice(0, 600)
  if (!c) fail(400, 'Escreva a memória.', 'invalid', 'content')
  if (SECRET_RE.test(c)) fail(400, 'Por segurança, senhas e credenciais não são guardadas na memória.', 'secret_rejected', 'content')
  const now = nowIso()
  const r = await q('INSERT INTO memories (user_id, content, kind, source, active, use_count, created_at, updated_at, origin_conversation_id) VALUES ($1,$2,$3,$4,$5,0,$6,$6,$7) RETURNING *',
    [userId, c, KINDS.includes(kind) ? kind : 'fact', source, true, now, originConversationId])
  return ser(r[0])
}
export async function activeMemories(userId: number): Promise<string[]> {
  return (await q('SELECT content FROM memories WHERE user_id = $1 AND active = $2 ORDER BY id DESC LIMIT 50', [userId, true])).map((r) => r.content)
}

export async function memoryGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const rows = await q('SELECT * FROM memories WHERE user_id = $1 ORDER BY id DESC', [u.id])
  const exps = await q('SELECT id, kind, tool, outcome, summary, conversation_id, created_at FROM experiences WHERE user_id = $1 ORDER BY id DESC LIMIT 300', [u.id]).catch(() => [] as any[])
  return { available: true, ...memSettings(u), memories: rows.map(ser), experiences: exps.map((e: any) => ({ id: Number(e.id), kind: e.kind, tool: e.tool, outcome: e.outcome, summary: e.summary, conversationId: e.conversation_id, createdAt: e.created_at })),
    layers: { curtoPrazo: 'somente durante cada mensagem (não é guardada)', conversacao: 'contexto de cada conversa (assunto, pendências, ações)', longoPrazo: rows.filter((r: any) => r.kind !== 'preference').length, preferencias: rows.filter((r: any) => r.kind === 'preference').length, experiencias: exps.length } }
}
export async function memoryPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  switch (b.action) {
    case 'create': return { ok: true, memory: await addMemory(u.id, str(b.content, 600), b.kind, 'manual') }
    case 'update': {
      const m = await one('SELECT * FROM memories WHERE id = $1 AND user_id = $2', [Number(b.id), u.id])
      if (!m) fail(404, 'Memória não encontrada.', 'not_found')
      const content = b.content !== undefined ? str(b.content, 600) : m!.content
      if (!content) fail(400, 'Escreva a memória.', 'invalid', 'content')
      if (SECRET_RE.test(content)) fail(400, 'Por segurança, senhas e credenciais não são guardadas na memória.', 'secret_rejected', 'content')
      const active = typeof b.active === 'boolean' ? b.active : B(m!.active)
      if (content !== m!.content) await ME.atualizarComHistorico(u.id, Number(m!.id), content, { motivo: 'corrigida pelo usuário' })
      if (active !== B(m!.active)) await q('UPDATE memories SET active = $1, updated_at = $2 WHERE id = $3 AND user_id = $4', [active, nowIso(), m!.id, u.id])
      ME.limparCache(u.id)
      return { ok: true }
    }
    case 'delete':
      await q('DELETE FROM memories WHERE id = $1 AND user_id = $2', [Number(b.id), u.id])
      return { ok: true }
    case 'delete_all':
      await q('DELETE FROM memories WHERE user_id = $1', [u.id]); ME.limparCache(u.id)
      if (b.incluirExperiencias === true) await q('DELETE FROM experiences WHERE user_id = $1', [u.id])
      return { ok: true }
    case 'search': { const t = str(b.query, 300); if (!t) fail(400, 'Escreva o que procurar.', 'invalid', 'query'); return { ok: true, resultados: await ME.pesquisar(u.id, t) } }
    case 'restore_version': { const ok = await ME.restaurarVersao(u.id, Number(b.id), Number(b.index)); if (!ok) fail(404, 'Versão não encontrada.', 'not_found'); ME.limparCache(u.id); return { ok: true } }
    case 'organize': return { ok: true, ...(await ME.organizar(u.id)) }
    case 'export': return { ok: true, exportacao: await ME.exportar(u) }
    case 'experience_delete': await q('DELETE FROM experiences WHERE id = $1 AND user_id = $2', [Number(b.id), u.id]); return { ok: true }
    case 'experiences_delete_all': await q('DELETE FROM experiences WHERE user_id = $1', [u.id]); return { ok: true }
    case 'settings': {
      const next = { ...u.memory_settings }
      if (typeof b.enabled === 'boolean') next.enabled = b.enabled
      if (typeof b.summaries === 'boolean') next.summaries = b.summaries
      if (typeof b.experiencias === 'boolean') next.experiencias = b.experiencias
      if (typeof b.associativa === 'boolean') next.associativa = b.associativa
      if (b.retencao !== undefined) {
        const r = b.retencao || {}, md = r.memoriasDias == null ? null : Number(r.memoriasDias), ed = r.experienciasDias == null ? 180 : Number(r.experienciasDias)
        if (md !== null && ![90, 180, 365, 730].includes(md)) fail(400, 'Retenção das memórias: nunca apagar, 90, 180, 365 ou 730 dias.', 'invalid', 'retencao')
        if (![30, 90, 180, 365].includes(ed)) fail(400, 'Retenção das experiências: 30, 90, 180 ou 365 dias.', 'invalid', 'retencao')
        next.retencao = { memoriasDias: md, experienciasDias: ed }
      }
      await q('UPDATE users SET memory_settings = $1 WHERE id = $2', [JSON.stringify(next), u.id])
      return { ok: true }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}
