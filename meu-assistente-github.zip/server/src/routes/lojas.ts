// Lojas Conectadas (central de várias lojas) e Mensagem pronta (por empresa).
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import * as LC from '../lib/lojas-conectadas.js'
import * as MP from '../lib/mensagem-pronta.js'
import { pub } from '../lib/publicurl.js'

const ROT: Record<string, string> = { aguardando_pagamento: 'Aguardando pagamento', novo: 'Novo', aceito: 'Aceito', preparo: 'Em preparo', saiu: 'Saiu para entrega', pronto: 'Pronto para retirar', concluido: 'Concluído', recusado: 'Recusado', cancelado: 'Cancelado', aguardando_aprovacao: 'Aguardando aprovação', sugestao: 'Novo horário sugerido' }
const ACAO: Record<string, string> = { aceito: 'Aceitar', recusado: 'Recusar', preparo: 'Em preparo', saiu: 'Saiu para entrega', pronto: 'Pronto para retirar', concluido: 'Concluir', cancelado: 'Cancelar' }
const ehAg = (o: any) => J<any>(o.data, {}).tipo === 'agendamento'
const PEND_PED = ['novo'], PEND_AG = ['novo', 'aguardando_aprovacao', 'sugestao']
const ABERTOS = ['novo', 'aceito', 'preparo', 'saiu', 'pronto', 'aguardando_aprovacao', 'sugestao']
const inList = (n: number, off = 0) => Array.from({ length: n }, (_, i) => '$' + (i + 1 + off)).join(',')

async function situacaoLoja(b: any) {
  const { openState } = await import('./businesses.js'); const x = J<any>(b.data, {})
  const vencida = b.expires_at && Date.parse(String(b.expires_at)) < Date.now()
  const st = b.status === 'ativo' && !vencida ? 'ativa' : vencida ? 'vencida' : b.status
  const ab = openState(x)
  return { situacao: st, situacaoTexto: st === 'ativa' ? (ab.aberto ? 'No ar · aberta agora' : 'No ar · fechada agora') : st === 'vencida' ? 'Anúncio vencido' : 'Fora do ar', aberto: ab.aberto }
}

/** Central: todas as lojas (próprias e conectadas) com contadores, avisos recentes e situação; solicitações e chaves. */
export async function centralGet(ctx: Ctx) {
  const u = requireUser(ctx), lojas = await LC.lojasDaCentral(u.id), ids = lojas.map((l) => Number(l.b.id))
  const ords = ids.length ? await q(`SELECT id, business_id, status, data, created_at FROM orders WHERE business_id IN (${inList(ids.length)}) AND status <> 'aguardando_pagamento'`, ids) as any[] : []
  const nots = ids.length ? await q(`SELECT id, business_id, title, body, link, read, created_at FROM notifications WHERE user_id = $1 AND business_id IN (${inList(ids.length, 1)}) ORDER BY id DESC LIMIT 300`, [u.id, ...ids]) as any[] : []
  const out = [], prefs = await LC.prefsVarias(u.id, ids) // preferências de todas as lojas numa consulta (antes: uma por loja)
  for (const l of lojas) {
    const bid = Number(l.b.id), os = ords.filter((o) => Number(o.business_id) === bid), ns = nots.filter((n) => Number(n.business_id) === bid), x = J<any>(l.b.data, {})
    const ped = os.filter((o) => !ehAg(o)), ag = os.filter(ehAg)
    out.push({ id: bid, empresa: x.empresa || `Loja #${bid}`, logo: x.logo || null, categoria: x.categoria || '', papel: l.papel, papelRotulo: LC.PAPEL_ROTULO[l.papel], linkId: l.linkId,
      ...(await situacaoLoja(l.b)), catalogo: `/x/empresa/${bid}`,
      contadores: { pedidos: ped.length, agendamentos: ag.length, pedidosPendentes: ped.filter((o) => PEND_PED.includes(o.status)).length, agendamentosPendentes: ag.filter((o) => PEND_AG.includes(o.status)).length },
      naoLidas: ns.filter((n) => !(n.read === true || n.read === 1 || n.read === 't')).length,
      recentes: ns.slice(0, 3).map((n) => ({ id: Number(n.id), titulo: n.title, texto: n.body || '', link: n.link || '', lida: n.read === true || n.read === 1 || n.read === 't', em: n.created_at })),
      preferencias: prefs.get(bid)! })
  }
  const tot = out.reduce((a, l) => ({ pedidos: a.pedidos + l.contadores.pedidos, agendamentos: a.agendamentos + l.contadores.agendamentos, pedidosPendentes: a.pedidosPendentes + l.contadores.pedidosPendentes, agendamentosPendentes: a.agendamentosPendentes + l.contadores.agendamentosPendentes, naoLidas: a.naoLidas + l.naoLidas }), { pedidos: 0, agendamentos: 0, pedidosPendentes: 0, agendamentosPendentes: 0, naoLidas: 0 })
  const minhas = (await LC.lojasProprias(u.id)).map((b) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa || `Loja #${b.id}` }))
  return { lojas: out, totais: tot, conexoes: await LC.conexoes(u.id), chaves: minhas.length ? await LC.listarChaves(u.id) : [], minhasLojas: minhas, podeConectar: minhas.length > 0, validades: LC.VALIDADES_HORAS }
}
export async function chavePost(ctx: Ctx) { const u = requireUser(ctx); return LC.criarChave(u.id, ctx.body || {}) }
export async function chaveRevogarPost(ctx: Ctx) { const u = requireUser(ctx); await LC.revogarChave(u.id, Number(ctx.params.id)); return { ok: true, chaves: await LC.listarChaves(u.id) } }
export async function conectarPost(ctx: Ctx) { const u = requireUser(ctx); return LC.conectar(u.id, ctx.body || {}) }
export async function conexaoPost(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id), acao = String(ctx.body?.acao || '')
  if (acao === 'aceitar' || acao === 'recusar') await LC.decidir(u.id, id, acao === 'aceitar')
  else if (acao === 'desvincular') await LC.desvincular(u.id, id)
  else if (acao === 'papel') await LC.mudarPapel(u.id, id, ctx.body?.papel)
  else fail(400, 'Ação inválida.', 'invalid')
  return { ok: true, conexoes: await LC.conexoes(u.id) }
}

/** Uma loja da central: identificação, informações e o catálogo (produtos OU serviços, conforme a modalidade da loja), só leitura.
 *  Acesso: proprietário ou central conectada (qualquer nível). Nada é alterado aqui; a gestão do catálogo continua com o dono. */
export async function lojaGet(ctx: Ctx) {
  const u = requireUser(ctx), bid = Number(ctx.params.bid)
  const papel = await LC.papelNaLoja(u.id, bid); if (!papel) fail(404, 'Loja não encontrada na sua central.', 'not_found')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [bid]), x = J<any>(b!.data, {})
  const BZ = await import('./businesses.js'), CAT = await import('../lib/catalogo.js'), op = BZ.opTipo(x)
  const rows = await q('SELECT * FROM products WHERE business_id = $1 ORDER BY id', [bid]) as any[]
  const base = rows.map((r) => ({ id: Number(r.id), ativo: r.active === true || r.active === 1 || r.active === 't', ...J<any>(r.data, {}) }))
    .filter((p) => BZ.allowsKind(x, p.tipo === 'servico' ? 'servico' : 'produto')) // só a modalidade atual (o resto continua salvo e oculto, como no catálogo)
  const itens = (await CAT.enriquecer(base)).map((p: any) => ({ id: p.id, tipo: p.tipo === 'servico' ? 'servico' : 'produto', nome: p.nome, categoria: p.categoria || 'Outros', ativo: p.ativo,
    foto: (p.destaque && p.destaque.foto) || (p.fotos || [])[0] || null, preco: p.tipo === 'servico' ? Number(p.preco) || 0 : Number(p.destaque?.preco ?? p.preco) || 0,
    precoNormal: p.destaque?.emOferta ? p.destaque.precoNormal : null, emOferta: !!p.destaque?.emOferta, aPartirDe: !!p.destaque?.aPartirDe || (p.variacoes || []).length > 0,
    esgotado: p.tipo !== 'servico' && !!p.esgotado, modoPreco: p.modoPreco || null, duracao: Number(p.duracao) || null, variacoes: (p.variantes || []).length, link: `/x/empresa/${bid}?${p.tipo === 'servico' ? 'servico' : 'produto'}=${p.id}` }))
  return { loja: { id: bid, empresa: x.empresa || `Loja #${bid}`, logo: x.logo || null, capa: x.capa || null, categoria: x.categoria || '', papel, papelRotulo: LC.PAPEL_ROTULO[papel],
    ...(await situacaoLoja(b)), modalidade: op, endereco: x.endereco || '', horario: x.horario || '', zap: x.zap || '', insta: x.insta || '', catalogo: `/x/empresa/${bid}`, gerenciar: papel === 'proprietario' },
    itens, totais: { itens: itens.length, ativos: itens.filter((i) => i.ativo).length } }
}
/** Pedidos e agendamentos consolidados (ou de uma loja), cada um com a loja de origem e as ações permitidas ao nível de acesso. */
export async function pedidosGet(ctx: Ctx) {
  const u = requireUser(ctx), qp = (k: string) => String(ctx.query.get(k) || '')
  let lojas = await LC.lojasDaCentral(u.id)
  if (qp('loja')) { lojas = lojas.filter((l) => Number(l.b.id) === Number(qp('loja'))); if (!lojas.length) fail(404, 'Loja não encontrada na sua central.', 'not_found') }
  const ids = lojas.map((l) => Number(l.b.id)); if (!ids.length) return { itens: [] }
  const { pedidoOut, transicoes } = await import('./businesses.js')
  const rows = await q(`SELECT * FROM orders WHERE business_id IN (${inList(ids.length)}) AND status <> 'aguardando_pagamento' ORDER BY id DESC LIMIT 400`, ids) as any[]
  const tipo = qp('tipo'), filtro = qp('filtro') || 'abertos', alvo = Number(qp('pedido')) || 0
  const itens = rows.filter((o) => (tipo === 'agendamentos' ? ehAg(o) : tipo === 'pedidos' ? !ehAg(o) : true))
    .filter((o) => Number(o.id) === alvo || (filtro === 'todos' ? true : filtro === 'pendentes' ? (ehAg(o) ? PEND_AG : PEND_PED).includes(o.status) : ABERTOS.includes(o.status)))
    .slice(0, 150).map((o) => {
      const l = lojas.find((x) => Number(x.b.id) === Number(o.business_id))!, x = J<any>(l.b.data, {}), d = pedidoOut(o)
      const sol = ['aguardando_aprovacao', 'sugestao'].includes(o.status) && J<any>(o.data, {}).solicitacao
      return { ...d, guestKey: undefined, payment: d.payment ? { status: d.payment.status } : undefined, statusRotulo: ROT[o.status] || o.status, agendamento: ehAg(o),
        loja: { id: Number(l.b.id), empresa: x.empresa || `Loja #${l.b.id}` }, papel: l.papel,
        acoes: sol ? [] : transicoes(o).filter((to) => LC.podeTransicao(l.papel, to)).map((to) => ({ status: to, rotulo: ACAO[to] || to, motivo: to === 'recusado' || to === 'cancelado' })),
        responder: sol && l.papel !== 'operador' ? `/x/solicitacoes?empresa=${l.b.id}` : null }
    })
  const { comFotos } = await import('./businesses.js')
  return { itens: await comFotos(itens, rows) } // imagem de cada item (mesma regra do painel da loja)
}
export async function pedidoStatusPost(ctx: Ctx) {
  const u = requireUser(ctx), bid = Number(ctx.params.bid), to = String(ctx.body?.status || '')
  const papel = await LC.papelNaLoja(u.id, bid); if (!papel) fail(404, 'Loja não encontrada na sua central.', 'not_found')
  if (!LC.podeTransicao(papel, to)) fail(403, 'Seu nível de acesso (operador) não permite recusar ou cancelar. Peça ao proprietário ou a um administrador.', 'forbidden')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [bid])
  const { mudarStatusPedido } = await import('./businesses.js')
  await mudarStatusPedido(b, Number(ctx.params.oid), to, str(ctx.body?.motivo, 200), { id: u.id, nome: `${u.name || ''}${papel === 'proprietario' ? '' : ' (' + LC.PAPEL_ROTULO[papel].toLowerCase() + ', Lojas Conectadas)'}` })
  return { ok: true }
}
/** Histórico de avisos das lojas (todas ou uma), com a loja de origem. */
export async function notificacoesGet(ctx: Ctx) {
  const u = requireUser(ctx), loja = Number(ctx.query.get('loja')) || 0, lojas = await LC.lojasDaCentral(u.id), ids = lojas.map((l) => Number(l.b.id))
  if (loja && !ids.includes(loja)) fail(404, 'Loja não encontrada na sua central.', 'not_found')
  const alvo = loja ? [loja] : ids; if (!alvo.length) return { itens: [], naoLidas: 0 }
  const rows = await q(`SELECT * FROM notifications WHERE user_id = $1 AND business_id IN (${inList(alvo.length, 1)}) ORDER BY id DESC LIMIT 100`, [u.id, ...alvo]) as any[]
  const nome = new Map(lojas.map((l) => [Number(l.b.id), J<any>(l.b.data, {}).empresa || `Loja #${l.b.id}`]))
  const lida = (n: any) => n.read === true || n.read === 1 || n.read === 't'
  return { itens: rows.map((n) => ({ id: Number(n.id), titulo: n.title, texto: n.body || '', link: n.link || '', lida: lida(n), em: n.created_at, loja: { id: Number(n.business_id), empresa: nome.get(Number(n.business_id)) } })), naoLidas: rows.filter((n) => !lida(n)).length }
}
export async function notificacoesLidasPost(ctx: Ctx) {
  const u = requireUser(ctx), loja = Number(ctx.body?.loja) || 0, id = Number(ctx.body?.id) || 0
  if (id) await q('UPDATE notifications SET read = $1 WHERE id = $2 AND user_id = $3', [true, id, u.id])
  else if (loja) { if (!(await LC.papelNaLoja(u.id, loja))) fail(404, 'Loja não encontrada na sua central.', 'not_found'); await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND business_id = $3', [true, u.id, loja]) }
  else { const ids = (await LC.lojasDaCentral(u.id)).map((l) => Number(l.b.id)); if (ids.length) await q(`UPDATE notifications SET read = $1 WHERE user_id = $2 AND business_id IN (${inList(ids.length, 2)})`, [true, u.id, ...ids]) }
  return { ok: true }
}
export async function preferenciasPut(ctx: Ctx) { const u = requireUser(ctx); return { preferencias: await LC.salvarPrefs(u.id, Number(ctx.params.bid), ctx.body || {}) } }

/* ---------- Mensagem pronta (dono da empresa) ---------- */
async function minhaEmpresa(ctx: Ctx) {
  const u = requireUser(ctx), b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found'); return { u, b: b! }
}
const exemplo = async (b: any) => { const p = await one('SELECT data FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 1', [b.id, true]); const d = J<any>(p?.data, {}); return { produto: d.nome || 'Produto de exemplo', preco: d.preco ? 'R$ ' + Number(d.preco).toFixed(2).replace('.', ',') : 'R$ 49,90' } }
export async function mensagemProntaGet(ctx: Ctx) {
  const { u, b } = await minhaEmpresa(ctx), x = J<any>(b.data, {}), c = MP.config(x), ex = await exemplo(b)
  const vars = { ...ex, empresa: x.empresa || '', link: `${pub()}/x/empresa/${b.id}`, cliente: String(u.name || '').split(' ')[0] }
  return { ...c, padrao: MP.PADRAO, variaveis: MP.VARIAVEIS, limites: MP.LIMITES, exemplo: vars, previa: MP.renderizar(c.texto, vars), previaSemProduto: MP.renderizar(c.texto, { ...vars, produto: '', preco: '', cliente: '' }), temWhatsapp: !!x.zap }
}
export async function mensagemProntaPut(ctx: Ctx) {
  const { u, b } = await minhaEmpresa(ctx)
  const body = ctx.body?.restaurar === true ? { ...MP.PADRAO, ativo: ctx.body?.ativo === true } : ctx.body || {}
  let v: any; try { v = MP.validar(body) } catch (e: any) { fail(400, e.message, 'invalid', e.campo) }
  const x = J<any>(b.data, {}); x.mensagemPronta = { ...v, atualizadoEm: nowIso() }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), b.id])
  await (await import('../lib/account.js')).audit(u.id, 'empresa.mensagem_pronta', Number(b.id), { ativo: v.ativo, restaurar: ctx.body?.restaurar === true })
  return mensagemProntaGet(ctx)
}
