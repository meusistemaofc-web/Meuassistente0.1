// Financeiro → Mercado Pago: conexão real da conta do usuário pelo OAuth oficial do Mercado Pago e
// leitura dos pagamentos recebidos pela API oficial (/v1/payments/search). Nada é simulado.
// O administrador cadastra a aplicação (Client ID e Client Secret) em Painel → Mercado Pago.
import { randomBytes, createHash } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal } from '../lib/settings.js'
import { getUM, setUM } from '../lib/usermod.js'
import { pub } from '../lib/publicurl.js'
export { app as mpApp }
const API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const AUTH = () => (process.env.MP_AUTH_BASE || 'https://auth.mercadopago.com').replace(/\/$/, '')
const redirectUri = () => `${pub()}/api/mercadopago/oauth/callback`
async function app() { const c = await getConfig<any>('mp_oauth', {}); return { clientId: String(c.clientId || ''), clientSecret: await unseal(c.clientSecret || '').catch(() => ''), teste: c.ambiente === 'teste', pkce: c.pkce === true } }
export async function appConfigured() { const a = await app(); return !!(a.clientId && a.clientSecret) }
export async function globalWebhookSecret() { const c = await getConfig<any>('mp_oauth', {}); return c.exigirAssinatura && c.webhookSecret ? await unseal(c.webhookSecret).catch(() => '') : '' }
/** Empresa pode receber pelo Mercado Pago? (plano empresarial ativo, conforme o painel) */
export async function planAllowed(b: any) {
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) return false
  const c = await getConfig<any>('mp_oauth', {}); const ads: any[] = await getConfig<any[]>('ad_plans', [])
  const lista: string[] = Array.isArray(c.planos) && c.planos.length ? c.planos : (ads.length ? ads.filter((p) => Number(p.nivel) >= 4).map((p) => p.id) : ['n4'])
  return lista.includes(String(b.plan_id))
}
const mascara = (e: any) => (e ? String(e).replace(/^(.{2}).*(@.*)$/, '$1***$2') : '')
/** POST /oauth/token (contrato oficial). Ambiente de teste envia test_token=true; PKCE envia o code_verifier. */
async function tokenReq(body: Record<string, string>): Promise<{ ok: boolean; status: number; j: any; erro: string }> {
  const a = await app()
  try {
    const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ client_id: a.clientId, client_secret: a.clientSecret, ...body }) })
    const j: any = await r.json().catch(() => ({}))
    return { ok: r.ok && !!j.access_token, status: r.status, j, erro: r.ok && j.access_token ? '' : String(j.message || j.error_description || j.error || `HTTP ${r.status}`).slice(0, 200) }
  } catch (e: any) { return { ok: false, status: 0, j: {}, erro: 'sem conexão com o Mercado Pago' } }
}
/** Renova o token de acesso (grant_type=refresh_token). invalido=true quando o Mercado Pago recusa o refresh (revogado/expirado). */
export async function refreshToken(refresh: string): Promise<{ access: string; refresh: string; exp: number } | null> { const r = await renovar(refresh); return r.ok ? r.t : null }
export async function renovar(refresh: string): Promise<{ ok: true; t: { access: string; refresh: string; exp: number } } | { ok: false; invalido: boolean; erro: string }> {
  const a = await app(); if (!a.clientId || !a.clientSecret || !refresh) return { ok: false, invalido: false, erro: 'aplicação não configurada' }
  const r = await tokenReq({ grant_type: 'refresh_token', refresh_token: refresh })
  if (r.ok) return { ok: true, t: { access: r.j.access_token, refresh: r.j.refresh_token || refresh, exp: Date.now() + (Number(r.j.expires_in) || 15552000) * 1000 } }
  return { ok: false, invalido: r.status >= 400 && r.status < 500, erro: r.erro }
}
/** Valida Client ID/Secret no Mercado Pago (grant_type=client_credentials). */
export async function testApp() {
  const a = await app(); if (!a.clientId || !a.clientSecret) return { ok: false, mensagem: 'Preencha o Client ID e o Client Secret.' }
  const r = await tokenReq({ grant_type: 'client_credentials' })
  if (r.status === 0) return { ok: false, mensagem: 'Sem conexão com o Mercado Pago.' }
  return r.ok ? { ok: true, mensagem: `Credenciais válidas. URL de redirecionamento a cadastrar na aplicação: ${redirectUri()}${a.teste ? ' · ambiente de teste (homologação)' : ''}${a.pkce ? ' · PKCE ligado' : ''}.` } : { ok: false, mensagem: `O Mercado Pago recusou as credenciais (${r.status}${r.erro ? ': ' + r.erro : ''}).` }
}
/* ---------- pedido de autorização: state guardado no servidor (uso único, 15 min) ---------- */
const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
async function autorizacao(userId: number, bid: number | null) {
  const ap = await app(); if (!ap.clientId || !ap.clientSecret) fail(400, 'A conexão automática ainda não foi configurada pelo administrador do sistema (Painel → Mercado Pago → Aplicação Mercado Pago).', 'not_configured')
  if (!userId) fail(401, 'Entre para continuar.', 'auth_required')
  const { q } = await import('../db/index.js')
  await q('DELETE FROM mp_oauth_estados WHERE criado_em < $1', [new Date(Date.now() - 86400_000).toISOString()])
  const state = randomBytes(24).toString('hex'), verifier = ap.pkce ? b64url(randomBytes(48)) : ''
  await q('INSERT INTO mp_oauth_estados (state, user_id, business_id, verifier, criado_em) VALUES ($1,$2,$3,$4,$5)', [state, userId, bid, verifier ? await seal(verifier) : '', new Date().toISOString()])
  const qs = new URLSearchParams({ client_id: ap.clientId, response_type: 'code', platform_id: 'mp', state, redirect_uri: redirectUri() })
  if (verifier) { qs.set('code_challenge', b64url(createHash('sha256').update(verifier).digest())); qs.set('code_challenge_method', 'S256') }
  return `${AUTH()}/authorization?${qs.toString()}`
}
export async function businessAuthUrl(userId: number, bid: number) { return autorizacao(userId, bid) }

/* ---------- conexão da EMPRESA (tokens próprios, criptografados, só no servidor) ---------- */
export type StatusLoja = 'conectado' | 'desconectado' | 'erro'
export function statusLoja(d: any): StatusLoja {
  if (!d?.mpTok) return 'desconectado'
  if (d.mpStatus === 'erro') return 'erro'
  if (d.mpModo === 'oauth' && Number(d.mpExp) && Date.now() > Number(d.mpExp) && !d.mpRefresh) return 'erro'
  return 'conectado'
}
async function gravarLoja(id: number, d: any) { const { q, nowIso } = await import('../db/index.js'); await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), id]) }
const dadosDe = (b: any) => (typeof b.data === 'string' ? JSON.parse(b.data || '{}') : { ...(b.data || {}) })
/** Renova o token da empresa (OAuth). force=false só renova quando faltam menos de 30 dias. Erros ficam no status. */
export async function renovarLoja(b: any, force = false): Promise<{ ok: boolean; renovado: boolean; erro?: string }> {
  const d = dadosDe(b); if (d.mpModo !== 'oauth' || !d.mpTok) return { ok: true, renovado: false }
  if (!force && Number(d.mpExp) && Number(d.mpExp) - Date.now() > 30 * 86400_000) return { ok: true, renovado: false }
  const ref = d.mpRefresh ? await unseal(d.mpRefresh).catch(() => '') : ''
  if (!ref) { if (Number(d.mpExp) && Date.now() > Number(d.mpExp)) { d.mpStatus = 'erro'; d.mpErro = 'A autorização expirou. Conecte a conta novamente.'; await gravarLoja(Number(b.id), d) } return { ok: false, renovado: false, erro: 'sem refresh token' } }
  const r = await renovar(ref)
  if (r.ok) { d.mpTok = await seal(r.t.access); d.mpRefresh = await seal(r.t.refresh); d.mpExp = r.t.exp; d.mpStatus = 'conectado'; d.mpErro = null; d.mpRenovadoEm = new Date().toISOString(); await gravarLoja(Number(b.id), d); return { ok: true, renovado: true } }
  if (r.invalido) { d.mpStatus = 'erro'; d.mpErro = 'O Mercado Pago não aceitou mais a autorização (revogada ou expirada). Conecte a conta novamente.'; await gravarLoja(Number(b.id), d) }
  return { ok: false, renovado: false, erro: r.erro }
}
/** Token da empresa para cobrar (renova antes de vencer). Vazio = sem conexão utilizável. */
export async function tokenLoja(b: any): Promise<string> {
  let d = dadosDe(b); if (!d.mpTok) return ''
  if (d.mpModo === 'oauth' && Number(d.mpExp) && Number(d.mpExp) - Date.now() < 30 * 86400_000 && d.mpRefresh) {
    await renovarLoja(b); const { one } = await import('../db/index.js'); const b2 = await one('SELECT data FROM businesses WHERE id = $1', [b.id]); d = dadosDe(b2 || b)
  }
  if (d.mpModo === 'oauth' && d.mpStatus === 'erro') return ''
  return unseal(d.mpTok).catch(() => '')
}
/** Confere a conexão na API oficial (/users/me); 401 tenta renovar uma vez; atualiza status e dados da conta. */
export async function verificarLoja(b: any): Promise<{ ok: boolean; mensagem: string }> {
  const { one } = await import('../db/index.js')
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    const atual = await one('SELECT * FROM businesses WHERE id = $1', [b.id]); const d = dadosDe(atual); const tok = d.mpTok ? await unseal(d.mpTok).catch(() => '') : ''
    if (!tok) return { ok: false, mensagem: 'Nenhuma conta Mercado Pago conectada.' }
    let r: Response | null = null; try { r = await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${tok}` } }) } catch { r = null }
    if (!r) return { ok: false, mensagem: 'Sem conexão com o Mercado Pago agora. Tente de novo em instantes.' }
    const j: any = await r.json().catch(() => ({}))
    if (r.ok) {
      if (d.mpModo === 'oauth' && d.mpUserId && j.id && Number(j.id) !== Number(d.mpUserId)) { d.mpStatus = 'erro'; d.mpErro = 'A conta respondeu com outro usuário. Conecte novamente.'; await gravarLoja(Number(b.id), d); return { ok: false, mensagem: d.mpErro } }
      d.mpStatus = 'conectado'; d.mpErro = null; d.mpVerificadoEm = new Date().toISOString()
      if (d.mpModo === 'oauth') d.mpConta = contaDe(j, d.mpConta)
      await gravarLoja(Number(b.id), d)
      return { ok: true, mensagem: `Conectado à conta ${j.nickname || mascara(j.email) || j.id}${/^TEST-/.test(tok) || d.mpTeste ? ' (ambiente de teste)' : ''}. Pronto para receber.` }
    }
    if ((r.status === 401 || r.status === 403) && d.mpModo === 'oauth' && tentativa === 0) { const rn = await renovarLoja(atual, true); if (rn.ok) continue }
    if (r.status === 401 || r.status === 403) { d.mpStatus = 'erro'; d.mpErro = d.mpModo === 'oauth' ? 'O Mercado Pago recusou a autorização. Conecte a conta novamente.' : 'O Mercado Pago recusou o Access Token.'; await gravarLoja(Number(b.id), d); return { ok: false, mensagem: d.mpErro } }
    return { ok: false, mensagem: `O Mercado Pago respondeu ${r.status}. Tente de novo em instantes.` }
  }
  return { ok: false, mensagem: 'Não foi possível verificar agora.' }
}
const contaDe = (me: any, ant: any = {}) => ({ id: me.id ?? ant?.id ?? null, nickname: me.nickname || ant?.nickname || '', nome: [me.first_name, me.last_name].filter(Boolean).join(' ') || ant?.nome || '', email: mascara(me.email) || ant?.email || '', site: me.site_id || ant?.site || '' })
/** Renovação automática (agendador): empresas conectadas pelo OAuth com menos de 30 dias de validade. */
let ultimaRenovacao = 0
export async function renovarTodas(force = false) {
  if (!force && Date.now() - ultimaRenovacao < 6 * 3600_000) return { renovadas: 0, erros: 0 }
  ultimaRenovacao = Date.now()
  const { q } = await import('../db/index.js'); let renovadas = 0, erros = 0
  for (const b of await q('SELECT id, data FROM businesses')) {
    const d = dadosDe(b); if (d.mpModo !== 'oauth' || !d.mpTok || d.mpStatus === 'erro') continue
    if (Number(d.mpExp) && Number(d.mpExp) - Date.now() > 30 * 86400_000) continue
    const r = await renovarLoja(b); if (r.renovado) renovadas++; else if (!r.ok) erros++
  }
  return { renovadas, erros }
}
export function limparLoja(d: any) { for (const k of ['mpTok', 'mpSecret', 'mpRefresh', 'mpExp', 'mpUserId', 'mpConta', 'mpModo', 'mpStatus', 'mpErro', 'mpTeste', 'mpConectadoEm', 'mpRenovadoEm', 'mpVerificadoEm']) delete d[k]; d.pagamento = { ...(d.pagamento || {}), online: false }; return d }
type Conn = { access: string; refresh: string; userId: number | null; expiresAt: number; account: any; lastSyncAt?: string; status: string; test?: boolean }
const connOut = (c: Conn | null) => c ? { connected: c.status !== 'expired', status: c.status, account: c.account || null, lastSyncAt: c.lastSyncAt || null, syncPartial: false, test: !!c.test } : { connected: false, status: 'disconnected', account: null, lastSyncAt: null }
async function token(u: number): Promise<{ c: Conn; tok: string } | null> {
  const c = await getUM<Conn | null>(u, 'mp_user', null); if (!c) return null
  let tok = await unseal(c.access).catch(() => '')
  if (c.expiresAt && Date.now() > c.expiresAt - 86400_000 && c.refresh) { // renova antes de expirar
    const r = await renovar(await unseal(c.refresh).catch(() => ''))
    if (r.ok) { tok = r.t.access; c.access = await seal(r.t.access); c.refresh = await seal(r.t.refresh); c.expiresAt = r.t.exp; c.status = 'connected'; await setUM(u, 'mp_user', c) }
    else if (Date.now() > c.expiresAt || r.invalido) { c.status = 'expired'; await setUM(u, 'mp_user', c); return null }
  }
  return { c, tok }
}
const PER: Record<string, string> = { today: 'Hoje', yesterday: 'Ontem', last_7_days: 'Últimos 7 dias', this_week: 'Esta semana', this_month: 'Este mês', last_month: 'Mês passado', last_30_days: 'Últimos 30 dias', last_90_days: 'Últimos 90 dias', custom: 'Período escolhido' }
function range(period: string, from?: string, to?: string) {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), d0 = new Date(now); d0.setHours(0, 0, 0, 0)
  const day = 86400_000; let a = d0.getTime(), b = now.getTime()
  if (period === 'yesterday') { a -= day; b = d0.getTime() - 1 } else if (period === 'last_7_days') a -= 6 * day; else if (period === 'last_30_days') a -= 29 * day; else if (period === 'last_90_days') a -= 89 * day
  else if (period === 'this_week') a -= ((d0.getDay() + 6) % 7) * day; else if (period === 'this_month') a = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime()
  else if (period === 'last_month') { a = new Date(d0.getFullYear(), d0.getMonth() - 1, 1).getTime(); b = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime() - 1 }
  else if (period === 'custom' && from) { a = Date.parse(from + 'T00:00:00-03:00'); b = to ? Date.parse(to + 'T23:59:59-03:00') : b }
  const iso = (t: number) => new Date(t).toISOString().replace('Z', '-00:00')
  return { begin: iso(a), end: iso(b), label: PER[period] || PER.this_month }
}
const GROUP: Record<string, string> = { approved: 'approved', authorized: 'pending', pending: 'pending', in_process: 'pending', in_mediation: 'pending', rejected: 'rejected', cancelled: 'rejected', refunded: 'refunded', charged_back: 'refunded' }
const LABEL: Record<string, string> = { approved: 'Aprovado', authorized: 'Autorizado', pending: 'Pendente', in_process: 'Em análise', in_mediation: 'Em disputa', rejected: 'Recusado', cancelled: 'Cancelado', refunded: 'Reembolsado', charged_back: 'Estornado' }
export async function mpUserGet(ctx: Ctx) {
  const u = requireUser(ctx), q = ctx.query
  const t = await token(u.id)
  const base: any = { connection: connOut(t?.c || (await getUM<Conn | null>(u.id, 'mp_user', null))), balance: { reason: 'O Mercado Pago não disponibiliza o saldo da conta pela API para aplicações de terceiros. Consulte o saldo no app do Mercado Pago.' } }
  if (!t) return base
  const period = String(q.get('period') || 'this_month'), page = Math.max(1, Number(q.get('page')) || 1), status = String(q.get('status') || '')
  const r0 = range(period, q.get('from') || undefined, q.get('to') || undefined), limit = 30
  const url = `${API()}/v1/payments/search?sort=date_created&criteria=desc&range=date_created&begin_date=${encodeURIComponent(r0.begin)}&end_date=${encodeURIComponent(r0.end)}&limit=100&offset=0`
  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${t.tok}` } })
    if (r.status === 401) { t.c.status = 'expired'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c) } }
    const j: any = await r.json(); if (!r.ok) throw new Error(j.message || `Mercado Pago respondeu ${r.status}`)
    const all = (j.results || []).filter((p: any) => !t.c.userId || !p.collector_id || Number(p.collector_id) === Number(t.c.userId)) // só o que esta conta recebeu
    const sum = (f: (p: any) => boolean, k = 'transaction_amount') => Math.round(all.filter(f).reduce((a: number, p: any) => a + Number(p[k] || 0), 0) * 100) / 100
    const fees = (p: any) => (p.fee_details || []).reduce((a: number, f: any) => a + Number(f.amount || 0), 0)
    const appr = all.filter((p: any) => p.status === 'approved')
    const totals = { currency: 'BRL', gross: sum((p) => p.status === 'approved'), approvedCount: appr.length, fees: Math.round(appr.reduce((a: number, p: any) => a + fees(p), 0) * 100) / 100, net: 0, pendingCount: all.filter((p: any) => GROUP[p.status] === 'pending').length, pendingAmount: sum((p) => GROUP[p.status] === 'pending'), refundedCount: all.filter((p: any) => GROUP[p.status] === 'refunded').length, refundedAmount: sum((p) => GROUP[p.status] === 'refunded'), refundedPartial: Math.round(appr.reduce((a: number, p: any) => a + Number(p.transaction_amount_refunded || 0), 0) * 100) / 100, rejectedCount: all.filter((p: any) => GROUP[p.status] === 'rejected').length }
    totals.net = Math.round((totals.gross - totals.fees - totals.refundedPartial) * 100) / 100
    const list = all.filter((p: any) => !status || GROUP[p.status] === status)
    const payments = list.slice((page - 1) * limit, page * limit).map((p: any) => ({ id: String(p.id), description: p.description || '', paymentType: p.payment_type_id, method: p.payment_method_id, amount: Number(p.transaction_amount), currency: p.currency_id || 'BRL', feeTotal: Math.round(fees(p) * 100) / 100, net: Number(p.transaction_details?.net_received_amount ?? 0), status: p.status, statusLabel: LABEL[p.status] || p.status, statusDetail: p.status_detail, group: GROUP[p.status] || '', dateCreated: p.date_created, dateApproved: p.date_approved, payer: p.payer?.email ? { email: String(p.payer.email).replace(/^(.{2}).*(@.*)$/, '$1***$2') } : null, installments: p.installments, externalReference: p.external_reference || '' }))
    t.c.lastSyncAt = new Date().toISOString(); t.c.status = 'connected'; await setUM(u.id, 'mp_user', t.c)
    return { ...base, connection: connOut(t.c), period: { key: period, label: r0.label }, totals, payments, pages: Math.max(1, Math.ceil(list.length / limit)), page, truncated: (j.paging?.total || 0) > 100 }
  } catch (e: any) { t.c.status = 'error'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c), refreshError: String(e?.message || e).slice(0, 160) } }
}
export async function mpUserPost(ctx: Ctx) {
  const u = requireUser(ctx), a = String(ctx.body?.action || '')
  if (a === 'connect') {
    return { url: await autorizacao(u.id, null) }
  }
  if (a === 'disconnect') { await setUM(u.id, 'mp_user', null); return { connection: connOut(null) } }
  if (a === 'refresh' || a === 'sync') { const t = await token(u.id); return { connection: connOut(t?.c || null) } }
  fail(400, 'Ação inválida.', 'invalid')
}
/**
 * Volta do Mercado Pago (redirect_uri). Reconhece o pedido pelo state guardado no servidor (uso único, 15 min),
 * sem depender do cookie: no celular a autorização costuma voltar em outro navegador ou pelo app do Mercado Pago.
 * Troca o code por tokens no servidor, confere a conta (/users/me) e guarda tudo criptografado na empresa dona.
 */
export async function mpUserCallback(ctx: Ctx) {
  const { q, one } = await import('../db/index.js')
  const state = String(ctx.query.get('state') || '')
  const row = /^[a-f0-9]{32,64}$/.test(state) ? await one('SELECT * FROM mp_oauth_estados WHERE state = $1', [state]) : null
  const destino = (motivo: string, extra = '') => { const bid = row?.business_id ? Number(row.business_id) : 0; return bid ? `/x/sua-empresa?mp=${motivo === 'conectado' ? 'conectado' : 'erro'}${motivo === 'conectado' ? '' : '&motivo=' + motivo}&loja=${bid}${extra}` : `/financeiro?tab=mercadopago&mp=${motivo === 'conectado' ? 'conectado' : 'erro'}${motivo === 'conectado' ? '' : '&motivo=' + motivo}` }
  const go = (motivo: string, extra = '') => { ctx.res.writeHead(302, { Location: destino(motivo, extra), 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }); ctx.res.end(); return { _handled: true } }
  if (!row) return go('expirado')
  // uso único: marca antes de qualquer outra coisa (um segundo retorno com o mesmo state é recusado)
  await q('UPDATE mp_oauth_estados SET usado_em = $1 WHERE state = $2 AND usado_em IS NULL', [new Date().toISOString(), state])
  const marcado = await one('SELECT usado_em, criado_em FROM mp_oauth_estados WHERE state = $1', [state])
  if (row.usado_em || !marcado?.usado_em) return go('expirado')
  if (Date.now() - Date.parse(String(row.criado_em instanceof Date ? row.criado_em.toISOString() : row.criado_em)) > 15 * 60_000) return go('expirado')
  if (ctx.query.get('error')) return go(ctx.query.get('error') === 'access_denied' ? 'cancelado' : 'provedor')
  const userId = Number(row.user_id)
  if (ctx.user && Number(ctx.user.id) !== userId) return go('outra_sessao') // logado como outra pessoa neste navegador
  const code = String(ctx.query.get('code') || ''); if (!/^[\w.-]{1,300}$/.test(code)) return go('provedor')
  if (!(await appConfigured())) return go('nao_configurado')
  const bid = row.business_id ? Number(row.business_id) : 0
  let b: any = null
  if (bid) { b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [bid, userId]); if (!b) return go('empresa'); if (!(await planAllowed(b))) return go('plano') }
  const ap = await app(), verifier = row.verifier ? await unseal(row.verifier).catch(() => '') : ''
  const body: Record<string, string> = { grant_type: 'authorization_code', code, redirect_uri: redirectUri() }
  if (verifier) body.code_verifier = verifier
  if (ap.teste) body.test_token = 'true'
  const t = await tokenReq(body)
  if (!t.ok) { console.error('[mp-oauth] troca do código recusada:', t.status, t.erro); if (b) { const d = dadosDe(b); if (d.mpTok) { d.mpUltimaFalha = { em: new Date().toISOString(), erro: t.erro } ; await gravarLoja(bid, d) } } return go('provedor') }
  let me: any = {}; try { const r = await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${t.j.access_token}` } }); me = r.ok ? await r.json() : {} } catch { me = {} }
  const mpUserId = Number(t.j.user_id || me.id) || null
  const teste = ap.teste || /^TEST-/.test(t.j.access_token) || t.j.live_mode === false
  if (b) {
    // a mesma conta Mercado Pago não pode receber por empresas de donos diferentes
    if (mpUserId) for (const o of await q('SELECT id, owner_id, data FROM businesses WHERE id <> $1', [bid])) { const od = dadosDe(o); if (od.mpModo === 'oauth' && Number(od.mpUserId) === mpUserId && Number(o.owner_id) !== userId) return go('conta_em_uso') }
    const d = dadosDe(b)
    Object.assign(d, { mpTok: await seal(t.j.access_token), mpRefresh: t.j.refresh_token ? await seal(t.j.refresh_token) : '', mpExp: Date.now() + (Number(t.j.expires_in) || 15552000) * 1000, mpUserId, mpModo: 'oauth', mpConta: contaDe({ ...me, id: me.id ?? mpUserId }), mpTeste: teste, mpStatus: 'conectado', mpErro: null, mpConectadoEm: new Date().toISOString(), mpRenovadoEm: null, mpVerificadoEm: me.id ? new Date().toISOString() : null })
    delete d.mpSecret; delete d.mpUltimaFalha // a chave de webhook do modo manual não vale para a nova conta
    d.pagamento = { ...(d.pagamento || {}), online: true }
    await gravarLoja(bid, d)
    try { const { audit } = await import('../lib/account.js'); await audit(userId, 'mp.oauth.conectado', null, { business: bid, conta: mpUserId, teste }) } catch { /* auditoria é opcional */ }
    return go('conectado')
  }
  await setUM(userId, 'mp_user', { access: await seal(t.j.access_token), refresh: t.j.refresh_token ? await seal(t.j.refresh_token) : '', userId: mpUserId, expiresAt: Date.now() + (Number(t.j.expires_in) || 15552000) * 1000, account: { id: me.id || mpUserId, nickname: me.nickname || '', name: [me.first_name, me.last_name].filter(Boolean).join(' '), email: mascara(me.email) }, status: 'connected', test: teste })
  return go('conectado')
}
