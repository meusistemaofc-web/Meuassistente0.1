// Página de Links: gerenciamento pelo dono (painel da empresa) e endereço público /<endereço-da-empresa>/links.
import type { Ctx } from '../lib/http.js'
import { fail, HttpError } from '../lib/http.js'
import { q, J } from '../db/index.js'
import { pub } from '../lib/publicurl.js'
import * as L from '../lib/linkpage.js'

async function minha(ctx: Ctx) {
  const { ownBusiness } = await import('./businesses.js')
  const { b } = await ownBusiness(ctx) // isolamento: só o dono da empresa
  const ok = await L.podeEditar(b); if (!ok.ok) fail(403, ok.mensagem, ok.codigo)
  return b
}
/** Página publicada antes de um campo novo existir: compara já normalizada, para não acusar "alterações não publicadas" à toa. */
function mesmaForma(b: any, c: any) { try { return L.normalizar(J<any>(b.data, {}), c) } catch { return c } }
async function estado(b: any) {
  const r = await L.linha(Number(b.id)), B = await L.base(b), rasc = await L.rascunhoDe(b)
  const pubC = r?.publicado ? J<any>(r.publicado, null) : null
  return {
    rascunho: rasc, publicado: !!pubC, publicadoEm: r?.publicado_em || null, pendente: !pubC || JSON.stringify(mesmaForma(b, pubC)) !== JSON.stringify(L.normalizar(J<any>(b.data, {}), rasc)),
    noAr: await L.podePublicar(b), url: `${pub()}/${B.slug}/links`, caminho: `/${B.slug}/links`, base: B, tipos: L.TIPOS, fundos: L.FUNDOS, botaoFormas: L.BOTAO_FORMAS,
    visitas: Number(r?.visitas || 0), cliques: J<Record<string, number>>(r?.cliques, {}),
  }
}
export async function linksGet(ctx: Ctx) { return estado(await minha(ctx)) }
export async function linksPut(ctx: Ctx) { const b = await minha(ctx); await L.salvarRascunho(b, ctx.body?.conteudo); return estado(b) }
export async function linksPost(ctx: Ctx) {
  const b = await minha(ctx), a = String(ctx.body?.action || '')
  if (a === 'publicar') { await L.publicar(b, ctx.body?.conteudo); return estado(b) }
  if (a === 'despublicar') { await L.despublicar(b); return estado(b) }
  if (a === 'descartar') { await L.descartar(b); return estado(b) }
  fail(400, 'Ação inválida.', 'invalid')
}

/* ---------- página pública ---------- */
const vistos = new Set<string>()
async function publica(slug: string) {
  const { idOfSlug } = await import('./businesses.js')
  const id = /^[a-z0-9][a-z0-9-]{0,59}$/.test(slug) ? await idOfSlug(slug).catch(() => null) : null
  const { one } = await import('../db/index.js')
  const b = id ? await one('SELECT * FROM businesses WHERE id = $1', [id]) : null
  const r = b ? await L.linha(Number(b.id)) : null
  if (!b || !r?.publicado || !(await L.podePublicar(b))) { const e: any = new HttpError(404, 'Esta página de links não está disponível no momento.', 'not_found'); e.extra = b ? { empresa: J<any>(b.data, {}).empresa || null } : null; throw e }
  return { b, r }
}
export async function linksPublicGet(ctx: Ctx) {
  const { b, r } = await publica(String(ctx.params.slug || ''))
  const B = await L.base(b), dia = new Date().toISOString().slice(0, 10), k = `${b.id}:${ctx.ip}:${dia}`
  if (!vistos.has(k)) { if (vistos.size > 100000) vistos.clear(); vistos.add(k); await q('UPDATE link_pages SET visitas = visitas + 1 WHERE business_id = $1', [Number(b.id)]) }
  return { id: B.id, slug: B.slug, url: `${pub()}/${B.slug}/links`, pagina: L.montar(B, J<any>(r.publicado, {})) }
}
export async function linksCliquePost(ctx: Ctx) {
  const { b, r } = await publica(String(ctx.params.slug || ''))
  const id = String(ctx.body?.id || ''), c = J<Record<string, number>>(r.cliques, {})
  if (!(J<any>(r.publicado, {}).botoes || []).some((x: any) => x.id === id)) return { ok: true }
  const k = `c:${b.id}:${id}:${ctx.ip}:${new Date().toISOString().slice(0, 10)}`; if (vistos.has(k)) return { ok: true }; vistos.add(k)
  c[id] = (c[id] || 0) + 1; await q('UPDATE link_pages SET cliques = $1 WHERE business_id = $2', [JSON.stringify(c), Number(b.id)])
  return { ok: true }
}
