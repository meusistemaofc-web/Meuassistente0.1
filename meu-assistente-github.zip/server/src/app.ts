import { ticketsGet, ticketsPost, ticketAttGet, ticketGet, ticketMsgPost, adminTicketsGet, adminTicketGet, adminTicketPost, adminTicketsCountGet } from './routes/tickets.js'
import { linksGet, linksPut, linksPost, linksPublicGet, linksCliquePost } from './routes/linkpage.js'
import { comercialPainelGet, comercialPainelPost, comercialMinhasGet, comercialPost } from './routes/comercial.js'
import { modosGet, modosPost, modoPropostaGet, modoPropostaPost } from './routes/modos.js'
import { sysMktGet, sysMktPost, mktGet, mktPost, mktClickGet, mktImgGet, mktUnsubGet, myConsentsGet, myConsentsPost } from './routes/marketing.js'
import { mpUserGet, mpUserPost, mpUserCallback } from './routes/mpuser.js'
import { INVITE_TPL } from './lib/invite.js'
import { emailAdminPost, emailLogGet, followupTestPost, mpOauthTestPost, chatTimingGet } from './routes/panel.js'
import { emailConfirmGet, emailOptOutGet } from './routes/me.js'
import { bizEmailPut, bizEmailPost } from './routes/businesses.js'
import { followupsGet, followupGet, followupPut } from './lib/followup.js'
import { menuPinsGet, menuPinsPut } from './routes/me.js'
// Servidor HTTP do Meu Assistente: API REST + arquivos do frontend (PWA) com fallback de SPA.
// Substitui o servidor TanStack Start que rodava nas Netlify Functions.
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { createReadStream, existsSync, statSync, readFileSync } from 'node:fs'
import { extname, join, normalize, sep } from 'node:path'
import { config } from './config.js'
import { readMultipart } from './lib/multipart.js'
import { pub, OLD_HOSTS, RESERVED_SLUGS } from './lib/publicurl.js'
import { fail, HttpError, parseCookies, readBody, sendJson, clientIp, type Ctx } from './lib/http.js'
import { loadSession } from './lib/session.js'
import { authGet, authPost } from './routes/auth.js'
import { meGet, mePatch } from './routes/me.js'
import { memoryGet, memoryPost } from './routes/memory.js'
import { notificationsGet, notificationGet, notificationsPost, pushGet, pushPost, pushDelete, pushDiagGet } from './routes/notifications.js'
import { itemsPost, agendaGet, financeGet, dayGet, summaryGet } from './routes/items.js'
import { chatJobGet, chatJobStream, imagesPost, chatPost, transcribePost, tarefasGet, tarefaSegundoPlanoPost, tarefaTentarPost, tarefaDescartarPost, chatGet, chatDelete, conversationsGet, conversationPatch, conversationDelete } from './routes/chat.js'
import { adminGet, adminUsersGet, adminUsersPost, adminAuditGet } from './routes/admin.js'
import { syncPost } from './routes/sync.js'
import { agentSlugPut, incentivosGet, incentivosPost } from './routes/businesses.js'
import { panelCouponsGet, panelCouponsPost, businessCouponsGet, businessCouponsPost, couponsMineGet, businessCouponsPublicGet, couponValidatePost } from './routes/coupons.js'
import { calendarGet, calendarPut, panelAgendaIaGet, panelAgendaIaPut } from './routes/agenda-ia.js'
import { menuImportList, menuImportCreate, menuImportFile, menuImportStart, menuImportGet, menuImportSave, menuImportPublish, menuImportRetry, menuImportCancel, menuImportRevert } from './routes/menu-import.js'
import { learningGet, learningPost, panelLearningGet, panelLearningPut, panelLearningFila, panelLearningRevisar } from './routes/learning.js'
import { panelCognicaoGet, panelCognicaoPut } from './routes/cognition.js'
import { chatFeedbackPost, chatFeedbackGet, meInteligenciaGet, meInteligenciaPut, panelInteligenciaGet, panelInteligenciaPut, panelInteligenciaBateria, panelInteligenciaDiagnostico, panelMultiagentePut, panelInteligenciaMonitor, panelOportunidadeLab, panelOportunidadeDescartar } from './routes/inteligencia.js'
import { panelShowcaseGet, panelShowcasePost, showcaseGet, showcaseCardGet, showcaseClickPost  , showcaseMessagePost } from './routes/showcase.js'
import { labGet, labPost, labPropostaGet } from './routes/lab.js'
import { R as LAB9_ROUTES } from './routes/laboratorio.js'
import { R as AG10_ROUTES } from './routes/agentes.js'
import { R as CEREBRO_ROUTES } from './routes/cerebro.js'
import * as CRM from './routes/crm.js'
import * as BI from './routes/bi.js'
import { panelCoinsHubGet, panelCoinLinkEventsGet, businessMcoinsGet, businessMcoinsPainelGet, businessMcoinsPost, panelCoinsGet, panelCoinsPost, panelCoinSendUsersGet, panelCoinDistributionsGet, panelCoinDistributionGet, coinsNewGet, coinsNewSeenPost, panelCoinGet, coinsMarketGet, coinsWalletGet, coinPublicGet, businessCoinGet, panelCentralGet, panelCentralPost, panelCentralPermissoesGet, panelCentralGrupoGet, panelCentralPedidosGet, panelCoinCodigoGet, coinsCapacidadesGet, coinsOrdersGet, coinsBuyPost, coinsSellPost, coinsTransferPost, coinsOrderCancelPost } from './routes/coins.js'
import { panelLeituraLocalGet, panelLeituraLocalPut } from './routes/leitura-local.js'
import { panelGet, panelPut, panelPublicGet, panelTestPost, brainAnswersGet, brainKnowledgeGet, brainKnowledgePost, brainItemGet, brainUsageGet, brainConflictsGet, brainCapabilitiesGet, brainTestPost, brainAnswerPut, brainAnswerDelete, ttsPost, ttsStatusGet, ollamaModelsGet } from './routes/panel.js'
import { marketQuoteGet } from './routes/market.js'
import { itemGet } from './routes/appts.js'
import { shareConsentPost, apptTrackingGet, shareSavePost, apptGet, apptSharePost, sharePublicGet, appointmentsLegacyGet, appointmentsLegacyPost } from './routes/appts.js'
import { usageGet, subscriptionPost, subscriptionPayGet } from './routes/plans.js'
import { kbOfflineGet, adminKbGet, adminKbPost } from './routes/kb.js'
import { orderReviewPost, myReviewsGet, adminRatingsGet, adminRatingPut, agentOrderGet, agentInfoGet, agentOrderPost, agentSlotsGet, agentBookingPost } from './routes/businesses.js'
import { businessHitPost, reportGet, reportAiPost, reportMeiPost } from './routes/businesses.js'
import { orderPayPost, slotsGet, bookingPost, themeGet } from './routes/businesses.js'
import * as PA from './routes/perm-agenda.js'
import { orderPayGet, storeMpPost, businessCardsGet, agentPut, agentGet, agentPayPost, agentPayGet, agentCupomPost, agentPublicGet, agentChatPost, agentOpcoesPut } from './routes/businesses.js'
import { myLocationPut, businessSearchGet, chatEmpresasPost, businessGet, productsGet, productsPost, orderPost, myOrdersGet, businessOrdersGet, businessOrderPost } from './routes/businesses.js'
import { adsCupomVerificarPost, adsCupomPost, adminVouchersGet, adminVouchersPost, adminVoucherGet, adminVoucherPut, adminVouchersHistoricoGet, adsRenewPost, modalidadeGet, modalidadePost, adsApprovalGet, adsApprovalPut } from './routes/ads.js'
import { countersGet } from './routes/counters.js'
import { geocodePost, adsPlansGet, adsMineGet, adsPost, adsPut, adsDelete, adsPainelGet, adsPayPost, adsPayStatusGet, mpWebhookPost, adminAdsGet, adminAdsPost } from './routes/ads.js'
import { marketSeriesGet, marketSummaryGet, marketAlertsGet, marketAlertsPost, fiscalGet, fiscalPut } from './routes/modules.js'
import { db } from './db/index.js'

type Handler = (ctx: Ctx) => Promise<unknown>
const routes: { method: string; pattern: RegExp; keys: string[]; handler: Handler }[] = []
function route(method: string, path: string, handler: Handler) {
  const keys: string[] = []
  const pattern = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)' }) + '/?$')
  routes.push({ method, pattern, keys, handler })
}

route('GET', '/api/health', async () => { await db().query('SELECT 1'); return { ok: true, db: db().kind, time: new Date().toISOString() } })
route('GET', '/api/auth', authGet)
route('POST', '/api/auth', authPost)
route('GET', '/api/me', meGet)
route('PATCH', '/api/me', mePatch)
route('GET', '/api/memory', memoryGet)
route('POST', '/api/memory', memoryPost)
route('GET', '/api/notifications', notificationsGet)
route('POST', '/api/notifications', notificationsPost)
route('GET', '/api/notifications/:id', notificationGet)
route('GET', '/api/push', pushGet)
route('POST', '/api/push', pushPost)
route('DELETE', '/api/push', pushDelete)
route('GET', '/api/push/diagnostico', pushDiagGet)
route('POST', '/api/items', itemsPost)
route('GET', '/api/agenda', agendaGet)
route('GET', '/api/finance', financeGet)
route('GET', '/api/day', dayGet)
route('GET', '/api/summary', summaryGet)
route('POST', '/api/sync', syncPost)
route('GET', '/api/chat', chatGet)
route('POST', '/api/chat', chatPost)
route('GET', '/api/v2/chat/tarefas', tarefasGet) // tarefas em segundo plano: estados reais (aguardando, processando, concluída, falhou)
route('POST', '/api/v2/chat/jobs/:id/segundo-plano', tarefaSegundoPlanoPost)
route('POST', '/api/v2/chat/jobs/:id/tentar', tarefaTentarPost)
route('POST', '/api/v2/chat/jobs/:id/descartar', tarefaDescartarPost)
route('POST', '/api/transcribe', transcribePost) // ditado do microfone: só transcreve (o texto volta ao campo de mensagem)
route('GET', '/api/v2/modos', modosGet)
route('POST', '/api/v2/modos', modosPost)
route('GET', '/api/v2/modos/propostas/:id', modoPropostaGet)
route('POST', '/api/v2/modos/propostas/:id', modoPropostaPost)
route('GET', '/api/v2/chat/jobs/:id', chatJobGet)
route('GET', '/api/v2/me/menu-pins', menuPinsGet)
route('PUT', '/api/v2/me/menu-pins', menuPinsPut)
route('GET', '/api/v2/chat/jobs/:id/stream', chatJobStream)
route('POST', '/api/images', imagesPost)
route('DELETE', '/api/chat', chatDelete)
route('GET', '/api/conversations', conversationsGet)
route('PATCH', '/api/conversations/:id', conversationPatch)
route('DELETE', '/api/conversations/:id', conversationDelete)
route('GET', '/api/assistant-avatar', async () => {
  const r = (await db().query("SELECT value FROM app_config WHERE key = 'assistant-avatar'"))[0]
  return { model: r ? String(r.value).replace(/"/g, '') : 'orb' }
})
route('GET', '/api/admin', adminGet)
route('GET', '/api/admin/users', adminUsersGet)
route('POST', '/api/admin/users', adminUsersPost)
route('GET', '/api/admin/audit', adminAuditGet)
route('GET', '/api/panel/compartilhar', async (ctx: any) => (await import('./routes/compartilhar.js')).panelGet(ctx)) // compartilhamento de produtos e serviços (modelos, regras, estatísticas)
route('PUT', '/api/panel/compartilhar', async (ctx: any) => (await import('./routes/compartilhar.js')).panelPut(ctx))
route('GET', '/api/v2/compartilhar/item/:pid', async (ctx: any) => (await import('./routes/compartilhar.js')).itemGet(ctx)) // link + mensagem do item (sem conta)
route('POST', '/api/v2/compartilhar/item/:pid/registro', async (ctx: any) => (await import('./routes/compartilhar.js')).registroPost(ctx))
route('GET', '/api/v2/ads/:id/compartilhamento', async (ctx: any) => (await import('./routes/compartilhar.js')).empresaGet(ctx))
route('PUT', '/api/v2/ads/:id/compartilhamento', async (ctx: any) => (await import('./routes/compartilhar.js')).empresaPut(ctx))
route('GET', '/api/panel/leitura-local', panelLeituraLocalGet)
route('PUT', '/api/panel/leitura-local', panelLeituraLocalPut)
route('GET', '/api/panel', panelGet)
route('GET', '/api/panel/public', panelPublicGet)
  route('GET', '/api/panel/ollama-models', ollamaModelsGet)
route('POST', '/api/panel/test', panelTestPost)
route('GET', '/api/panel/aprendizagem', panelLearningGet)
route('PUT', '/api/panel/aprendizagem', panelLearningPut)
route('GET', '/api/panel/aprendizagem/fila', panelLearningFila)
route('POST', '/api/panel/aprendizagem/:id/revisar', panelLearningRevisar)
route('GET', '/api/panel/cognicao', panelCognicaoGet)
route('PUT', '/api/panel/cognicao', panelCognicaoPut)
route('POST', '/api/chat/feedback', chatFeedbackPost)
route('GET', '/api/chat/feedback', chatFeedbackGet)
route('GET', '/api/me/inteligencia', meInteligenciaGet)
route('PUT', '/api/me/inteligencia', meInteligenciaPut)
route('GET', '/api/panel/inteligencia', panelInteligenciaGet)
route('PUT', '/api/panel/inteligencia', panelInteligenciaPut)
route('POST', '/api/panel/inteligencia/bateria', panelInteligenciaBateria)
route('POST', '/api/panel/inteligencia/monitor', panelInteligenciaMonitor)
route('POST', '/api/panel/inteligencia/diagnostico', panelInteligenciaDiagnostico)
route('PUT', '/api/panel/inteligencia/multiagente', panelMultiagentePut)
route('POST', '/api/panel/inteligencia/oportunidades/laboratorio', panelOportunidadeLab)
route('POST', '/api/panel/inteligencia/oportunidades/descartar', panelOportunidadeDescartar)
{ // Fase 8 — autonomia operacional
  const E = () => import('./routes/execucao.js')
  route('GET', '/api/me/execucoes', async (c: any) => (await E()).meExecucoesGet(c))
  route('PUT', '/api/me/execucoes/autonomia', async (c: any) => (await E()).meAutonomiaPut(c))
  route('GET', '/api/me/execucoes/:id', async (c: any) => (await E()).meExecucaoGet(c))
  route('POST', '/api/me/execucoes/:id/:acao', async (c: any) => (await E()).meExecucaoAcao(c))
  route('GET', '/api/panel/execucao', async (c: any) => (await E()).panelExecucaoGet(c))
  route('PUT', '/api/panel/execucao', async (c: any) => (await E()).panelExecucaoPut(c))
}
{ // Fase 7 — inteligência preditiva
  const R = () => import('./routes/preditivo.js')
  route('GET', '/api/me/previsoes', async (c: any) => (await R()).mePrevisoesGet(c))
  route('POST', '/api/me/previsoes/acao', async (c: any) => (await R()).mePrevisoesAcao(c))
  route('PUT', '/api/me/previsoes/preferencias', async (c: any) => (await R()).mePrevisoesPrefsPut(c))
  route('GET', '/api/panel/preditivo', async (c: any) => (await R()).panelPreditivoGet(c))
  route('PUT', '/api/panel/preditivo', async (c: any) => (await R()).panelPreditivoPut(c))
  route('POST', '/api/panel/preditivo/validar', async (c: any) => (await R()).panelPreditivoValidar(c))
  route('POST', '/api/panel/preditivo/avaliar', async (c: any) => (await R()).panelPreditivoAvaliar(c))
  route('POST', '/api/panel/preditivo/avisar', async (c: any) => (await R()).panelPreditivoAvisar(c))
}
{ // Fase 6 — aprendizado contínuo
  const I = () => import('./routes/inteligencia.js')
  route('GET', '/api/panel/aprendizado', async (c: any) => (await I()).panelAprendizadoGet(c))
  route('PUT', '/api/panel/aprendizado', async (c: any) => (await I()).panelAprendizadoPut(c))
  route('POST', '/api/panel/aprendizado/analisar', async (c: any) => (await I()).panelAprendizadoAnalisar(c))
  route('POST', '/api/panel/aprendizado/propostas/:id/testar', async (c: any) => (await I()).panelAprendizadoTestar(c))
  route('POST', '/api/panel/aprendizado/propostas/:id/decidir', async (c: any) => (await I()).panelAprendizadoDecidir(c))
  route('POST', '/api/panel/aprendizado/versoes/restaurar', async (c: any) => (await I()).panelAprendizadoRestaurar(c))
  route('POST', '/api/panel/aprendizado/vigiar', async (c: any) => (await I()).panelAprendizadoVigiar(c))
  route('GET', '/api/panel/aprendizado/relatorio', async (c: any) => (await I()).panelAprendizadoRelatorio(c))
}
route('GET', '/api/learning', learningGet)
route('POST', '/api/learning', learningPost)
route('GET', '/api/panel/agenda_ia', panelAgendaIaGet)
route('PUT', '/api/panel/agenda_ia', panelAgendaIaPut)
for (const [m, p, h] of CEREBRO_ROUTES) route(m, p, h as any) // Cérebro Central (biblioteca, pesquisa, aprendizagem, laboratório, provedores)
for (const [m, p, h] of AG10_ROUTES) route(m, p, h as any) // Fase 10: Central de Agentes (antes da rota genérica /api/panel/:key)
route('PUT', '/api/panel/:key', panelPut)
route('GET', '/api/panel/brain/answers', brainAnswersGet)
route('GET', '/api/panel/brain/knowledge', brainKnowledgeGet)
route('POST', '/api/panel/brain/knowledge', brainKnowledgePost)
route('GET', '/api/panel/brain/item/:id', brainItemGet)
route('GET', '/api/panel/brain/usage', brainUsageGet)
route('GET', '/api/panel/brain/conflicts', brainConflictsGet)
route('GET', '/api/panel/brain/capabilities', brainCapabilitiesGet)
route('POST', '/api/panel/brain/test', brainTestPost)
route('PUT', '/api/panel/brain/answers/:id', brainAnswerPut)
route('DELETE', '/api/panel/brain/answers/:id', brainAnswerDelete)
route('POST', '/api/tts', ttsPost)
route('GET', '/api/tts', ttsStatusGet)
route('GET', '/api/v2/ads/:id/calendar', calendarGet)
route('PUT', '/api/v2/ads/:id/calendar', calendarPut)
route('GET', '/api/panel/showcase', panelShowcaseGet)
route('POST', '/api/panel/showcase', panelShowcasePost)
route('GET', '/api/v2/showcase', showcaseGet)
route('POST', '/api/v2/showcase/:id/message', showcaseMessagePost)
route('GET', '/api/v2/showcase/:id', showcaseCardGet)
route('POST', '/api/v2/showcase/:id/click', showcaseClickPost)
route('GET', '/api/panel/lab', labGet)
route('POST', '/api/panel/lab', labPost)
route('GET', '/api/panel/lab/:id', labPropostaGet)
for (const [m, p, h] of LAB9_ROUTES) route(m, p, h as any) // Fase 9: Laboratório de Inteligência (administradores autorizados)
route('GET', '/api/panel/coins', panelCoinsGet)
route('POST', '/api/panel/coins', panelCoinsPost)
route('GET', '/api/panel/coins/hub', panelCoinsHubGet)
route('GET', '/api/panel/coins/send/users', panelCoinSendUsersGet)
route('GET', '/api/panel/coins/distributions', panelCoinDistributionsGet)
route('GET', '/api/panel/coins/distributions/:id', panelCoinDistributionGet)
route('GET', '/api/panel/coins/links/:id/events', panelCoinLinkEventsGet)
route('GET', '/api/panel/coins/central', panelCentralGet)
route('POST', '/api/panel/coins/central', panelCentralPost)
route('GET', '/api/panel/coins/central/permissoes', panelCentralPermissoesGet)
route('GET', '/api/panel/coins/central/grupos/:id', panelCentralGrupoGet)
route('GET', '/api/panel/coins/central/pedidos', panelCentralPedidosGet)
route('GET', '/api/panel/coins/codigo', panelCoinCodigoGet)
route('GET', '/api/panel/coins/:id', panelCoinGet)
route('GET', '/api/panel/coupons', panelCouponsGet)
route('POST', '/api/panel/coupons', panelCouponsPost)
route('GET', '/api/v2/ads/:id/incentivos', incentivosGet) // incentivos do carrinho (painel da empresa)
route('POST', '/api/v2/ads/:id/incentivos', incentivosPost)
route('GET', '/api/v2/businesses/:id/coupons', businessCouponsGet)
route('POST', '/api/v2/businesses/:id/coupons', businessCouponsPost)
route('GET', '/api/v2/businesses/:id/coupons/public', businessCouponsPublicGet)
route('POST', '/api/v2/businesses/:id/coupons/validate', couponValidatePost)
route('GET', '/api/v2/coupons/mine', couponsMineGet)
route('GET', '/api/v2/coins/market', coinsMarketGet)
route('GET', '/api/v2/coins/wallet', coinsWalletGet)
route('GET', '/api/v2/coins/capacidades', coinsCapacidadesGet)
route('GET', '/api/v2/coins/pedidos', coinsOrdersGet)
route('POST', '/api/v2/coins/comprar', coinsBuyPost)
route('POST', '/api/v2/coins/vender', coinsSellPost)
route('POST', '/api/v2/coins/transferir', coinsTransferPost)
route('POST', '/api/v2/coins/pedidos/:id/cancelar', coinsOrderCancelPost)
route('GET', '/api/v2/coins/novas', coinsNewGet)
route('POST', '/api/v2/coins/novas/vistas', coinsNewSeenPost)
route('GET', '/api/v2/coins/:id', coinPublicGet)
route('GET', '/api/v2/businesses/:id/coin', businessCoinGet)
const CB = '/api/v2/businesses/:id/crm'
route('GET', CB + '/overview', CRM.crmOverviewGet)
route('GET', '/api/v2/businesses/:id/bi', BI.biGet)
route('GET', CB + '/contacts', CRM.crmContactsGet); route('POST', CB + '/contacts', CRM.crmContactsPost)
route('GET', CB + '/contacts/:cid', CRM.crmContactGet); route('PUT', CB + '/contacts/:cid', CRM.crmContactPut); route('POST', CB + '/contacts/:cid/events', CRM.crmContactEventPost)
route('GET', CB + '/pipeline', CRM.crmPipelineGet); route('POST', CB + '/stages', CRM.crmStagesPost); route('PUT', CB + '/stages/:sid', CRM.crmStagePut); route('DELETE', CB + '/stages/:sid', CRM.crmStageDelete)
route('GET', CB + '/opps', CRM.crmOppsGet); route('POST', CB + '/opps', CRM.crmOppsPost); route('GET', CB + '/opps/:oid', CRM.crmOppGet); route('PUT', CB + '/opps/:oid', CRM.crmOppPut); route('DELETE', CB + '/opps/:oid', CRM.crmOppDelete); route('POST', CB + '/opps/:oid/move', CRM.crmOppMovePost)
route('GET', CB + '/tasks', CRM.crmTasksGet); route('POST', CB + '/tasks', CRM.crmTasksPost); route('PUT', CB + '/tasks/:tid', CRM.crmTaskPut); route('POST', CB + '/tasks/:tid/status', CRM.crmTaskStatusPost)
route('GET', CB + '/insights', CRM.crmInsightsGet); route('GET', CB + '/config', CRM.crmConfigGet); route('PUT', CB + '/config', CRM.crmConfigPut)
route('GET', '/api/v2/ads/:id/mcoins', businessMcoinsGet)
route('GET', '/api/v2/ads/:id/mcoins/painel', businessMcoinsPainelGet)
route('POST', '/api/v2/ads/:id/mcoins', businessMcoinsPost)
route('GET', '/api/v2/market/quote', marketQuoteGet)
route('GET', '/api/v2/market/series', marketSeriesGet)
route('GET', '/api/v2/market/summary', marketSummaryGet)
route('GET', '/api/v2/market/alerts', marketAlertsGet)
route('POST', '/api/v2/market/alerts', marketAlertsPost)
route('GET', '/api/v2/fiscal', fiscalGet)
route('GET', '/api/appointments', appointmentsLegacyGet)
route('POST', '/api/appointments', appointmentsLegacyPost)
route('GET', '/api/v2/appointments/:id', apptGet)
route('GET', '/api/v2/item/:id', itemGet)
const LJ = () => import('./routes/lojas.js')
route('GET', '/api/v2/lojas/central', async (ctx: any) => (await LJ()).centralGet(ctx))
route('POST', '/api/v2/lojas/chaves', async (ctx: any) => (await LJ()).chavePost(ctx))
route('POST', '/api/v2/lojas/chaves/:id/revogar', async (ctx: any) => (await LJ()).chaveRevogarPost(ctx))
route('POST', '/api/v2/lojas/conectar', async (ctx: any) => (await LJ()).conectarPost(ctx))
route('POST', '/api/v2/lojas/conexoes/:id', async (ctx: any) => (await LJ()).conexaoPost(ctx))
route('GET', '/api/v2/lojas/pedidos', async (ctx: any) => (await LJ()).pedidosGet(ctx))
route('GET', '/api/v2/lojas/:bid/loja', async (ctx: any) => (await LJ()).lojaGet(ctx)) // central: informações e catálogo (só leitura) da loja escolhida
route('POST', '/api/v2/lojas/:bid/pedidos/:oid', async (ctx: any) => (await LJ()).pedidoStatusPost(ctx))
route('GET', '/api/v2/lojas/notificacoes', async (ctx: any) => (await LJ()).notificacoesGet(ctx))
route('POST', '/api/v2/lojas/notificacoes/lidas', async (ctx: any) => (await LJ()).notificacoesLidasPost(ctx))
route('PUT', '/api/v2/lojas/:bid/preferencias', async (ctx: any) => (await LJ()).preferenciasPut(ctx))
route('GET', '/api/v2/ads/:id/mensagem-pronta', async (ctx: any) => (await LJ()).mensagemProntaGet(ctx))
route('PUT', '/api/v2/ads/:id/mensagem-pronta', async (ctx: any) => (await LJ()).mensagemProntaPut(ctx))
route('GET', '/api/v2/compromissos/estatisticas', async (ctx: any) => (await import('./routes/items.js')).compromissosEstatisticasGet(ctx))
route('GET', '/api/v2/compromissos', async (ctx: any) => (await import('./routes/items.js')).compromissosGet(ctx))
route('POST', '/api/v2/appointments/:id/share', apptSharePost)
route('GET', '/api/v2/share/:token', sharePublicGet)
route('POST', '/api/v2/share/:token/consent', shareConsentPost)
route('GET', '/api/v2/appointments/:id/tracking', apptTrackingGet)
route('GET', '/api/v2/marketing', mktGet)
route('GET', '/api/panel/mkt-sistema', sysMktGet)
route('POST', '/api/panel/mkt-sistema', sysMktPost)
route('GET', '/api/panel/comercial', comercialPainelGet)
route('POST', '/api/panel/comercial', comercialPainelPost)
route('GET', '/api/v2/comercial', comercialMinhasGet)
route('POST', '/api/v2/comercial', comercialPost)
route('GET', '/api/v2/tickets', ticketsGet)
route('POST', '/api/v2/tickets', ticketsPost)
route('GET', '/api/v2/tickets/anexo/:id', ticketAttGet)
route('GET', '/api/v2/tickets/:id', ticketGet)
route('POST', '/api/v2/tickets/:id/messages', ticketMsgPost)
route('GET', '/api/panel/tickets/contador', adminTicketsCountGet)
route('GET', '/api/panel/tickets', adminTicketsGet)
route('GET', '/api/panel/tickets/:id', adminTicketGet)
route('POST', '/api/panel/tickets/:id', adminTicketPost)
route('POST', '/api/v2/marketing', mktPost)
route('GET', '/api/v2/marketing/c/:id', mktClickGet)
route('GET', '/api/v2/marketing/sair', mktUnsubGet)
route('GET', '/api/v2/marketing/img/:id', mktImgGet)
route('GET', '/api/v2/me/consents', myConsentsGet)
route('POST', '/api/v2/me/consents', myConsentsPost)
route('GET', '/api/v2/followups', followupsGet)
route('POST', '/api/panel/email', emailAdminPost)
route('POST', '/api/panel/mp-oauth-test', mpOauthTestPost)
route('GET', '/api/panel/diagnostico/tempos', chatTimingGet)
route('GET', '/api/mercadopago', mpUserGet)
route('POST', '/api/mercadopago', mpUserPost)
route('GET', '/api/mercadopago/oauth/callback', mpUserCallback)
route('POST', '/api/panel/followup-test', followupTestPost)
route('GET', '/api/panel/email/log', emailLogGet)
route('GET', '/api/v2/email/confirmar', emailConfirmGet)
route('GET', '/api/v2/email/sair', emailOptOutGet)
route('PUT', '/api/v2/ads/:id/email', bizEmailPut)
route('POST', '/api/v2/ads/:id/email', bizEmailPost)
route('GET', '/api/v2/followups/:id', followupGet)
route('PUT', '/api/v2/followups/:id', followupPut)
route('POST', '/api/v2/share/:token/save', shareSavePost)
route('GET', '/api/v2/usage', usageGet)
route('POST', '/api/v2/subscription', subscriptionPost)
route('GET', '/api/v2/subscription/pay', subscriptionPayGet)
route('GET', '/api/kb-offline', kbOfflineGet)
route('GET', '/api/v2/admin/kb', adminKbGet)
route('POST', '/api/v2/admin/kb', adminKbPost)
route('PUT', '/api/v2/me/location', myLocationPut)
route('POST', '/api/v2/geocode', geocodePost)
route('GET', '/api/v2/theme/:id', themeGet)
route('GET', '/api/v2/businesses/search', businessSearchGet)
const LX = () => import('./lib/lixeira-empresas.js')
route('POST', '/api/v2/ads/:id/excluir', async (ctx: any) => { const u = (await import('./lib/session.js')).requireUser(ctx); return (await LX()).excluir(u.id, Number(ctx.params.id), ctx.body?.confirmar) })
route('GET', '/api/v2/lixeira/empresas', async (ctx: any) => { const u = (await import('./lib/session.js')).requireUser(ctx); return { items: await (await LX()).listar(u.id), dias: (await LX()).DIAS_LIXEIRA } })
route('POST', '/api/v2/lixeira/empresas/:id/restaurar', async (ctx: any) => { const u = (await import('./lib/session.js')).requireUser(ctx); return (await LX()).restaurar(u.id, Number(ctx.params.id)) })
route('POST', '/api/v2/lixeira/empresas/:id/excluir-definitivo', async (ctx: any) => { const u = (await import('./lib/session.js')).requireUser(ctx); return (await LX()).excluirDefinitivo(u.id, Number(ctx.params.id), ctx.body?.confirmar) })
route('GET', '/api/v2/marketplace/produtos', async (ctx: any) => (await import('./routes/businesses.js')).marketplaceGet(ctx))
route('GET', '/api/v2/marketplace/servicos', async (ctx: any) => (await import('./routes/businesses.js')).marketplaceServicosGet(ctx)) // vitrine: aba Serviços (mesmas regras dos produtos)
route('GET', '/api/v2/vitrine/geo', async (ctx: any) => (await import('./routes/businesses.js')).vitrineGeoGet(ctx)) // vitrine pública: cidade/bairro do visitante sem conta
route('GET', '/api/v2/vitrine/imagem/:tipo/:id', async (ctx: any) => (await import('./routes/businesses.js')).vitrineImagemGet(ctx)) // prévia dos links compartilhados
route('POST', '/api/v2/chat/empresas', chatEmpresasPost)
route('GET', '/api/v2/businesses/cards', businessCardsGet)
route('POST', '/api/v2/businesses/:id/hit', businessHitPost)
route('GET', '/api/v2/ads/:id/report', reportGet)
route('POST', '/api/v2/ads/:id/report/ai', reportAiPost)
route('POST', '/api/v2/ads/:id/report/mei', reportMeiPost)
route('GET', '/api/v2/businesses/:id', businessGet)
route('POST', '/api/v2/businesses/:id/orders', orderPost)
route('GET', '/api/v2/businesses/:id/slots', slotsGet)
route('POST', '/api/v2/businesses/:id/bookings', bookingPost)
route('GET', '/api/v2/orders/mine', myOrdersGet)
route('GET', '/api/v2/counters', countersGet)
route('GET', '/api/v2/orders/:id/pay', orderPayGet)
route('POST', '/api/v2/orders/:id/pay', orderPayPost)
route('POST', '/api/v2/ads/:id/mp', storeMpPost)
route('GET', '/api/v2/ads/:id/products', productsGet)
route('POST', '/api/v2/ads/:id/products', productsPost)
route('GET', '/api/v2/ads/:id/menu-imports', menuImportList)
route('POST', '/api/v2/ads/:id/menu-imports', menuImportCreate)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/arquivos', menuImportFile)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/iniciar', menuImportStart)
route('GET', '/api/v2/ads/:id/menu-imports/:iid', menuImportGet)
route('PUT', '/api/v2/ads/:id/menu-imports/:iid', menuImportSave)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/publicar', menuImportPublish)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/retomar', menuImportRetry)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/cancelar', menuImportCancel)
route('POST', '/api/v2/ads/:id/menu-imports/:iid/reverter', menuImportRevert)
route('GET', '/api/v2/ads/:id/orders', businessOrdersGet)
route('GET', '/api/v2/pedidos/:id/itens/:i/foto', async (ctx: any) => (await import('./routes/businesses.js')).pedidoFotoGet(ctx)) // imagem de cada item nos painéis de pedidos (endereço assinado)
route('POST', '/api/v2/ads/:id/orders/:oid', businessOrderPost)
route('GET', '/api/v2/ads/plans', adsPlansGet)
route('GET', '/api/v2/ads/mine', adsMineGet)
route('GET', '/api/v2/ads/painel', adsPainelGet)
route('GET', '/api/v2/admin/ads-approval', adsApprovalGet)
route('PUT', '/api/v2/admin/ads-approval', adsApprovalPut)
route('GET', '/api/v2/ads/:id/modalidade', modalidadeGet)
route('POST', '/api/v2/ads/:id/modalidade', modalidadePost)
route('POST', '/api/v2/ads', adsPost)
route('PUT', '/api/v2/ads/:id', adsPut)
route('DELETE', '/api/v2/ads/:id', adsDelete)
route('POST', '/api/v2/ads/:id/pay', adsPayPost)
route('POST', '/api/v2/ads/:id/renew', adsRenewPost)
route('POST', '/api/v2/ads/cupom/verificar', adsCupomVerificarPost) // Cupons e Vouchers: prévia na página Anunciar
route('POST', '/api/v2/ads/:id/cupom', adsCupomPost) // aplicar / remover / ativar sem pagamento
route('GET', '/api/v2/admin/vouchers', adminVouchersGet)
route('POST', '/api/v2/admin/vouchers', adminVouchersPost)
route('GET', '/api/v2/admin/vouchers-historico', adminVouchersHistoricoGet)
route('GET', '/api/v2/admin/vouchers/:id', adminVoucherGet)
route('PUT', '/api/v2/admin/vouchers/:id', adminVoucherPut)
route('GET', '/api/v2/ads/:id/agent', agentGet)
route('PUT', '/api/v2/ads/:id/agent/opcoes', agentOpcoesPut)
route('GET', '/api/v2/ads/:id/links', linksGet)
route('PUT', '/api/v2/ads/:id/links', linksPut)
route('POST', '/api/v2/ads/:id/links', linksPost)
route('GET', '/api/v2/links/:slug', linksPublicGet)
route('POST', '/api/v2/links/:slug/clique', linksCliquePost)
route('PUT', '/api/v2/ads/:id/agent', agentPut)
route('PUT', '/api/v2/ads/:id/slug', agentSlugPut)
route('POST', '/api/v2/ads/:id/agent/pay', agentPayPost)
route('GET', '/api/v2/ads/:id/agent/pay', agentPayGet)
route('POST', '/api/v2/ads/:id/agent/cupom', agentCupomPost)
route('GET', '/api/v2/busca/cards', async (ctx: Ctx) => { const { requireUser } = await import('./lib/session.js'); const u = requireUser(ctx); return { items: await (await import('./modos/busca.js')).cards(u.id, String(ctx.query.get('ids') || '')) } }) // cards do modo Busca no chat (dados atuais)
route('GET', '/api/v2/apresentacao', async (ctx: Ctx) => (await import('./routes/apresentacao.js')).apresentacaoGet(ctx))
route('GET', '/api/v2/agent/:id', agentPublicGet)
route('POST', '/api/v2/agent/:id/chat', agentChatPost)
route('GET', '/api/v2/agent/:id/orders/:oid', agentOrderGet)
route('POST', '/api/v2/orders/:id/review', orderReviewPost)
route('GET', '/api/v2/reviews/mine', myReviewsGet)
route('GET', '/api/v2/admin/ratings', adminRatingsGet)
route('PUT', '/api/v2/admin/ratings/:id', adminRatingPut)
route('GET', '/api/v2/agent/:id/info', agentInfoGet)
route('POST', '/api/v2/agent/:id/order', agentOrderPost)
route('GET', '/api/v2/agent/:id/slots', agentSlotsGet)
route('POST', '/api/v2/agent/:id/booking', agentBookingPost)
// Permissões de Agendamento (pedidos agendados e solicitações de serviço com aprovação)
route('GET', '/api/v2/ads/:id/permissoes-agendamento', PA.permCfgGet)
route('PUT', '/api/v2/ads/:id/permissoes-agendamento', PA.permCfgPut)
route('POST', '/api/v2/ads/:id/permissoes-agendamento/pessoas', PA.permPessoasPost)
route('GET', '/api/v2/solicitacoes', PA.minhasEmpresasSolicitacoesGet)
route('GET', '/api/v2/businesses/:id/solicitacoes', PA.solicitacoesGet)
route('GET', '/api/v2/businesses/:id/solicitacoes/:oid/horarios', PA.solicitacaoHorariosGet)
route('POST', '/api/v2/businesses/:id/solicitacoes/:oid', PA.solicitacaoPost)
route('POST', '/api/v2/orders/:id/sugestao', PA.sugestaoClientePost)
route('POST', '/api/v2/agent/:id/orders/:oid/sugestao', PA.sugestaoAgentePost)
route('GET', '/api/v2/businesses/:id/agendamento', PA.permVisitanteGet)
route('GET', '/api/v2/businesses/:id/pedido-horarios', PA.pedidoHorariosGet)
route('GET', '/api/v2/agent/:id/agendamento', PA.agentePermGet)
route('GET', '/api/v2/agent/:id/pedido-horarios', PA.agentePedidoHorariosGet)
route('GET', '/api/v2/ads/:id/pay', adsPayStatusGet)
route('POST', '/api/mercadopago/webhook', mpWebhookPost)
route('GET', '/api/v2/admin/ads', adminAdsGet)
route('POST', '/api/v2/admin/ads/:id', adminAdsPost)
route('PUT', '/api/v2/fiscal', fiscalPut)

/** Módulos do sistema original cujo backend não estava no ZIP e ainda não foi reconstruído. */
export const NOT_RECONSTRUCTED: Record<string, string> = {
  '/api/billing': 'Planos e assinaturas', '/api/mercadopago': 'Pagamentos Mercado Pago', '/api/studio': 'Estúdio (vídeos)',
  '/api/fiscal': 'Calendário fiscal', '/api/das': 'DAS MEI', '/api/market': 'Mercado e investimentos', '/api/b3': 'Cotações B3',
  '/api/brain': 'Cérebro do chat (admin)', '/api/eleicoes': 'Eleições 2026', '/api/campanha': 'Campanha eleitoral',
  '/api/push': 'Notificações push', '/api/medications': 'Medicamentos', '/api/meals': 'Alimentação', '/api/training': 'Treinos',
  '/api/emails': 'E-mails', '/api/whatsapp': 'WhatsApp', '/api/mcp': 'Conexões MCP', '/api/images': 'Imagens',
  '/api/maps': 'Mapas', '/api/news': 'Notícias', '/api/labs': 'Recursos experimentais', '/api/spaces': 'Espaços compartilhados',
  '/api/ads': 'Anúncios', '/api/anunciar': 'Anuncie', '/api/appointments': 'Compartilhamento de compromissos', '/api/convite': 'Convites',
  '/api/tts': 'Voz natural', '/api/voice': 'Áudios de voz', '/api/avatar': 'Foto de perfil',
  '/api/kb-file': 'Base de conhecimento', '/api/kb-image': 'Base de conhecimento', '/api/kb-offline': 'Base de conhecimento',
  '/api/setup': 'Assistente de configuração', '/api/messages': 'Mensagens', '/api/visitante': 'Visitante', '/api/admin': 'Painel administrativo',
}
function notReconstructed(path: string): string | null {
  const key = Object.keys(NOT_RECONSTRUCTED).filter((k) => path === k || path.startsWith(k + '/') || path.startsWith(k + '?')).sort((a, b) => b.length - a.length)[0]
  return key ? NOT_RECONSTRUCTED[key] : null
}

const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN', // permite abrir módulos dentro do chat (mesmo domínio), bloqueia sites de fora
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), geolocation=(self), payment=(self), usb=(), microphone=(self), accelerometer=(self), gyroscope=(self), magnetometer=(self)',
}
const TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
}

type MetaPag = { titulo: string; descricao: string; imagem: string; url: string } | null
const escAttr = (t: string) => String(t).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
/** Prévia dos links compartilhados (Open Graph): título, descrição e imagem do conteúdo. */
const metaTags = (m: MetaPag) => (m ? `<title>${escAttr(m.titulo)}</title><meta name="description" content="${escAttr(m.descricao)}"><meta property="og:type" content="website"><meta property="og:site_name" content="Meu Assistente"><meta property="og:title" content="${escAttr(m.titulo)}"><meta property="og:description" content="${escAttr(m.descricao)}"><meta property="og:url" content="${escAttr(m.url)}">${m.imagem ? `<meta property="og:image" content="${escAttr(m.imagem)}">` : ''}<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${escAttr(m.titulo)}"><meta name="twitter:description" content="${escAttr(m.descricao)}">${m.imagem ? `<meta name="twitter:image" content="${escAttr(m.imagem)}">` : ''}` : '')
function serveStatic(req: IncomingMessage, res: ServerResponse, path: string, meta: MetaPag = null) {
  const root = config.staticDir
  let rel = decodeURIComponent(path)
  if (rel === '/painel' || rel === '/painel/' || rel === '/painel.html') { res.writeHead(302, { Location: '/admin' }); return res.end() }
  if (/^\/a\/\d+\/?$/.test(rel)) rel = '/agente.html'
  if (/^\/admin\/agentes\/?$/.test(rel)) rel = '/agentes.html'
  if (/^\/admin\/cerebro-central\/?$/.test(rel)) rel = '/cerebro-central.html' // Cérebro Central (a API exige administrador) // Fase 10: Central de Agentes (a API exige administrador autorizado)
  if (/^\/admin\/laboratorio\/?$/.test(rel)) rel = '/laboratorio.html' // Fase 9: Laboratório de Inteligência (a API exige administrador autorizado)
  if (/^\/execucoes\/?$/.test(rel)) rel = '/execucoes.html' // Fase 8: execuções do próprio usuário (a API exige sessão)
  if (/^\/previsoes\/?$/.test(rel)) rel = '/previsoes.html' // Fase 7: previsões e sugestões do próprio usuário (a API exige sessão)
  if (/^\/minha-memoria\/?$/.test(rel)) rel = '/memoria.html' // página "Minha memória" (só os dados do próprio usuário; a API exige sessão)
  if (/^\/c\/[\w-]{6,40}\/?$/.test(rel)) rel = '/compromisso.html' // convite de compromisso // página pública do agente de atendimento
  const file = normalize(join(root, rel))
  if (!file.startsWith(root + sep) && file !== root) { res.writeHead(400); return res.end() }
  let target = file
  let isFile = existsSync(target) && statSync(target).isFile()
  if (!isFile) {
    if (rel.startsWith('/assets/') || extname(rel)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...SECURITY_HEADERS }); return res.end('Não encontrado') }
    target = join(root, 'index.html') // rotas do app (SPA)
    isFile = existsSync(target)
    if (!isFile) { res.writeHead(500); return res.end('index.html ausente') }
  }
  const ext = extname(target)
  const cache = rel === '/assets/index-MUcZwl3l.js' ? 'no-cache' : rel.startsWith('/assets/') ? 'public, max-age=31536000, immutable'
    : ext === '.html' || rel === '/sw.js' || rel === '/manifest.webmanifest' ? 'no-cache' : 'public, max-age=86400'
  const headers: Record<string, string> = { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': cache, ...SECURITY_HEADERS }
  if (rel === '/sw.js') headers['Service-Worker-Allowed'] = '/'
  if (secureHsts()) headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
  if (target.endsWith('index.html')) {
    // Acrescenta as novas abas do painel administrativo (Módulos, IA, Fontes de mercado, Mercado Pago, Planos, Cérebro).
    let html = readFileSync(target, 'utf8'); if (meta) html = html.replace(/<title>[^<]*<\/title>/, metaTags(meta))
    html = html.replace('<head>', '<head><script>window.__MA_PUB=' + JSON.stringify(pub()) + ';window.__MA_INVITE_TPL=' + JSON.stringify(INVITE_TPL).replace(/</g, '\\u003c') + '</script><style>html:not(.ma-qb-ok) .chat-scroll .mt-7{visibility:hidden!important}html.ma-qb-off .chat-scroll .mt-7{display:none!important}</style><script>try{if(localStorage.getItem(\'ma-qb\')===\'off\')document.documentElement.classList.add(\'ma-qb-off\',\'ma-qb-ok\')}catch(e){}</script><script src="/ma-theme.js?v=1"></script><script src="/chat-stream-addon.js?v=5"></script><script src="/botoes-rapidos.js?v=2"></script><script src="/splash.js?v=3"></script>').replace('</body>', '<script src="/coin-art.js?v=4"></script><script src="/panel-addon.js?v=157" defer></script><script src="/coin-art.js?v=4"></script><script src="/menu-import-addon.js?v=4" defer></script><script src="/modules-addon.js?v=160" defer></script><script src="/chat-welcome-addon.js?v=2" defer></script><script src="/feedback-addon.js?v=2" defer></script><script src="/memoria-addon.js?v=1" defer></script><script src="/agenda-evolucao.js?v=1" defer></script><script src="/calendario-addon.js?v=4" defer></script><script src="/previsoes-addon.js?v=2" defer></script><script src="/vitrine-addon.js?v=3" defer></script></body>')
    res.writeHead(200, headers)
    return res.end(req.method === 'HEAD' ? undefined : html)
  }
  res.writeHead(200, headers)
  if (req.method === 'HEAD') return res.end()
  createReadStream(target).pipe(res)
}
const secureHsts = () => config.publicUrl.startsWith('https://')

async function handle(req: IncomingMessage, res: ServerResponse) {
  const url = new URL(req.url || '/', 'http://localhost')
  const path = url.pathname
  const method = (req.method || 'GET').toUpperCase()
  if (!path.startsWith('/api/')) {
    if (method !== 'GET' && method !== 'HEAD') { res.writeHead(405); return res.end() }
    // links públicos acessados pelo endereço antigo vão para o domínio oficial (mesmo caminho)
    const host = String(req.headers.host || '').split(':')[0]
    if (OLD_HOSTS.test(host) && /^\/(a\/\d+|g-[a-z0-9-]+|c\/[\w-]+|x\/empresa\/\d+)\/?$/.test(path) && new URL(pub()).hostname !== host) { res.writeHead(301, { Location: pub() + path + url.search }); return res.end() }
    const ga = /^\/a\/(\d+)\/?$/.exec(path)
    if (ga) { const sl = await (await import('./routes/businesses.js')).slugOfId(Number(ga[1])).catch(() => null); if (sl) { res.writeHead(301, { Location: `/${sl}${url.search}` }); return res.end() } }
    // endereço antigo /g-<nome> → novo /<nome> (301); uma empresa cujo nome começa com "g-" continua abrindo direto
    const gs = /^\/g-([a-z0-9-]{1,60})\/?$/.exec(path), gm = gs ? await import('./routes/businesses.js') : null
    if (gs && gm && !(await gm.idOfSlug('g-' + gs[1]).catch(() => null))) {
      const sl2 = await gm.idOfSlug(gs[1]).then((i) => (i ? gm.slugOfId(i) : null)).catch(() => null)
      if (sl2) { res.writeHead(301, { Location: `/${sl2}${url.search}` }); return res.end() }
    }
    // Página de apresentação (landing page): /conheca — página própria, com a prévia de compartilhamento no endereço oficial
    if (/^\/conheca\/?$/.test(path)) {
      const base = pub(), html = readFileSync(join(config.staticDir, 'conheca.html'), 'utf8').replace(/__PUB__/g, base.replace(/[<>"&]/g, ''))
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...SECURITY_HEADERS }); return res.end(req.method === 'HEAD' ? undefined : html)
    }
    // Página de Links da empresa: /<endereço-da-empresa>/links (a API confere plano, publicação e anúncio no ar)
    const pl = /^\/([a-z0-9][a-z0-9-]{0,59})\/links\/?$/.exec(path)
    if (pl && !RESERVED_SLUGS.has(pl[1])) {
      const html = readFileSync(join(config.staticDir, 'links.html'), 'utf8').replace('<head>', `<head><script>window.__MA_LINKS=${JSON.stringify(pl[1])}</script>`)
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...SECURITY_HEADERS }); return res.end(req.method === 'HEAD' ? undefined : html)
    }
    // endereço público do agente: /<nome-da-empresa> (nomes do sistema e arquivos existentes nunca são tomados)
    const ps = /^\/([a-z0-9][a-z0-9-]{0,59})\/?$/.exec(path)
    const slugPath = ps ? ps[1] : gs ? 'g-' + gs[1] : null
    if (slugPath && !RESERVED_SLUGS.has(slugPath) && !existsSync(join(config.staticDir, slugPath))) {
      const id = await (await import('./routes/businesses.js')).idOfSlug(slugPath).catch(() => null)
      if (!id && gs) { res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', ...SECURITY_HEADERS }); return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#000;color:#fff;padding:32px"><h1 style="font-size:20px">Atendimento não encontrado</h1><p style="color:#aaa">Confira o link com a empresa.</p></body>') }
      if (id) {
        const html = readFileSync(join(config.staticDir, 'agente.html'), 'utf8').replace('<head>', `<head><script>window.__MA_AGENT=${Number(id)}</script>`)
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...SECURITY_HEADERS }); return res.end(html)
      }
    }
    // vitrine e páginas de empresa/produto/serviço: prévia própria quando o link é compartilhado
    const meta = /^\/x\/empresas?(\/\d+)?\/?$/.test(path) ? await (await import('./routes/businesses.js')).metaVitrine(path, url.searchParams) : null
    return serveStatic(req, res, path, meta)
  }
  const ctx: Ctx = { req, res, method, path, url, query: url.searchParams, ip: clientIp(req), body: {}, cookies: parseCookies(req.headers.cookie), setCookies: [], params: {} }
  const extra: Record<string, string | string[]> = { ...SECURITY_HEADERS }
  try {
    // proteção CSRF: requisições que alteram dados precisam vir do próprio site
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin
      if (origin && new URL(origin).host !== req.headers.host && origin !== config.publicUrl && origin !== pub())
        throw new HttpError(403, 'Origem não permitida.', 'bad_origin')
    }
    const match = routes.find((r) => r.method === method && r.pattern.test(path))
    if (!match) {
      const mod = notReconstructed(path)
      if (mod) throw new HttpError(501, `O módulo "${mod}" ainda não foi reconstruído neste servidor.`, 'not_reconstructed')
      const exists = routes.some((r) => r.pattern.test(path))
      throw new HttpError(exists ? 405 : 404, exists ? 'Método não permitido.' : 'Rota não encontrada.', exists ? 'method_not_allowed' : 'not_found')
    }
    const m = match.pattern.exec(path)!
    match.keys.forEach((k, i) => (ctx.params[k] = decodeURIComponent(m[i + 1])))
    if (method !== 'GET' && method !== 'HEAD') {
      const ct = String(req.headers['content-type'] || '')
      if (ct.startsWith('multipart/')) { const mp = await readMultipart(req); ctx.body = mp.fields; (ctx as any).files = mp.files } else {
        const raw = await readBody(req)
        if (raw.length) {
          try { ctx.body = JSON.parse(raw.toString('utf8')) } catch { throw new HttpError(400, 'JSON inválido.', 'invalid_json') }
        }
      }
    }
    await loadSession(ctx)
    const data = await match.handler(ctx)
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    if (data && (data as any)._handled) return // a rota já escreveu a resposta (streaming)
    if (data && (data as any)._binary) {
      const bin = data as any
      res.writeHead(bin.status || 200, { ...(bin.data ? { 'Content-Type': bin.mime, 'Content-Length': bin.data.length } : {}), 'Cache-Control': 'private, max-age=3600', ...(bin.headers || {}), ...extra })
      res.end(bin.data || undefined)
      return
    }
    sendJson(res, 200, data ?? { ok: true }, extra)
  } catch (e: any) {
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    if (e instanceof HttpError && (e as any).attempts && (ctx as any).user && (ctx as any).user.role !== 'user') // administrador vê por que cada IA falhou
      e.message += ` [Detalhe para o administrador: ${((e as any).attempts as any[]).map((a) => `${a.nome}: ${a.msg}`).join(' | ')}]`
    if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message, ...(e.code ? { code: e.code } : {}), ...(e.field ? { field: e.field } : {}), ...((e as any).extra ? { info: (e as any).extra } : {}) }, extra)
    console.error(`[api] ${method} ${path}:`, e)
    sendJson(res, 500, { error: 'Algo deu errado no servidor.', code: 'server_error' }, extra)
  }
}

export function createApp() {
  return createServer((req, res) => { handle(req, res).catch((e) => { console.error(e); try { res.writeHead(500); res.end() } catch {} }) })
}
export const indexHtmlPresent = () => existsSync(join(config.staticDir, 'index.html')) && readFileSync(join(config.staticDir, 'index.html'), 'utf8').includes('$_TSR')
