// Recuperação da chave do cofre (credenciais do Mercado Pago, SMTP, chaves de IA…). SOMENTE LEITURA:
//  • não grava nada no banco, não gera chave, não altera nenhuma credencial;
//  • recebe na entrada padrão as chaves candidatas, uma por linha: "<origem>\t<valor>" (o script
//    deploy/scripts/recuperar-chave.sh junta: .env atual e antigos, backups/env-*, variáveis de contêineres antigos e a
//    vault-key guardada nos backups do banco);
//  • testa cada candidata (e variações de digitação: espaços, aspas, \r) contra TODAS as credenciais cifradas e mostra
//    quais abrem com qual — o relatório vai para a saída de erro e nunca mostra valores (só origem, tamanho e impressão);
//  • na saída padrão escreve apenas a recomendação: "APP_SECRET_ANTERIOR=<valores>" com as chaves que faltam (para o
//    script gravar no .env), ou nada.
// Códigos de saída: 0 = tudo já abre; 10 = chave(s) encontrada(s) e cobrem tudo; 11 = encontrou parte; 12 = não encontrou.
// Uso direto: docker compose exec -T app node dist/db/cofre-recuperar-cli.js < candidatos.txt
import { createDecipheriv, createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { connectFromEnv } from './connect.js'

type Cand = { origem: string; seed: string; key: Buffer; kid: string; ativa: boolean }
const derivar = (seed: string) => createHash('sha256').update(seed).digest()
const kidDe = (k: Buffer) => createHash('sha256').update(Buffer.concat([Buffer.from('ma-kid:'), k])).digest('hex').slice(0, 12)
const impressao = (seed: string) => createHash('sha256').update('impressao:' + seed).digest('hex').slice(0, 8)
const abre = (key: Buffer, sealed: string): boolean => {
  try {
    const m = /^v2:[a-f0-9]{12}:(.+)$/.exec(sealed), b = Buffer.from(m ? m[1] : sealed.slice(3), 'base64')
    const d = createDecipheriv('aes-256-gcm', key, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); Buffer.concat([d.update(b.subarray(28)), d.final()]); return true
  } catch { return false }
}
const SELADO = /^v(?:1|2:[a-f0-9]{12}):[A-Za-z0-9+/=]{24,}$/
function selados(v: unknown, caminho: string, out: { caminho: string; valor: string }[]) {
  if (typeof v === 'string') { if (SELADO.test(v)) out.push({ caminho, valor: v }); else if (/^[[{]/.test(v.trim())) { try { selados(JSON.parse(v), caminho, out) } catch { /* texto */ } } return }
  if (Array.isArray(v)) v.forEach((x, i) => selados(x, `${caminho}[${i}]`, out))
  else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) selados(x, caminho ? `${caminho}.${k}` : k, out)
}
const variacoes = (s: string) => { const t = s.replace(/\r/g, ''), tt = t.trim(), sem = tt.replace(/^(['"])(.*)\1$/, '$2'); return [...new Set([t, tt, sem, sem.trim()])].filter((x) => x.length >= 16) }

// produção: Postgres (DATABASE_URL). Sem DATABASE_URL e com SQLITE_FILE (só testes), abre o SQLite.
const db = !process.env.DATABASE_URL && process.env.SQLITE_FILE ? await (await import('./sqlite.js')).createSqlite(process.env.SQLITE_FILE) : await connectFromEnv()
const log = (s = '') => process.stderr.write(s + '\n')
try {
  // 1) todas as credenciais cifradas, com o lugar onde estão (nunca o valor)
  const achados: { lugar: string; caminho: string; valor: string; usada: boolean }[] = []
  const varre = (lugar: string, v: unknown, usada = true) => { const o: { caminho: string; valor: string }[] = []; selados(v, '', o); for (const x of o) achados.push({ lugar, caminho: x.caminho, valor: x.valor, usada }) }
  for (const r of await db.query<any>('SELECT key, value FROM app_config')) if (r.key !== 'vault-key') varre(`configuração "${r.key}"`, r.value)
  try { for (const r of await db.query<any>('SELECT business_id, provedor, dados FROM empresa_integracoes')) varre(`empresa #${r.business_id} — ${r.provedor}`, r.dados) } catch { /* versão sem a tabela */ }
  try { for (const r of await db.query<any>('SELECT user_id, key, value FROM user_modules')) varre(`usuário #${r.user_id} — ${r.key}`, r.value) } catch { /* sem a tabela */ }
  for (const r of await db.query<any>('SELECT id, data FROM businesses')) varre(`empresa #${r.id} — cópia antiga em businesses.data`, r.data, false)

  // 2) chaves que o servidor usa hoje (mesma regra do app) e candidatas recebidas
  const cands: Cand[] = []
  const add = (origem: string, seed: string, ativa = false) => { for (const s of variacoes(seed)) { const key = derivar(s), kid = kidDe(key), ex = cands.find((c) => c.kid === kid); if (ex) { ex.ativa ||= ativa; if (!ex.origem.includes(origem)) ex.origem += ` · ${origem}`; continue } cands.push({ origem: origem + (s !== seed ? ' (sem espaços/aspas)' : ''), seed: s, key, kid, ativa }) } }
  if ((process.env.APP_SECRET || '').length >= 16) add('APP_SECRET atual', process.env.APP_SECRET!, true)
  for (const x of String(process.env.APP_SECRET_ANTERIOR || '').trim().replace(/^(['"])(.*)\1$/, '$2').split(',').map((t) => t.trim()).filter((t) => t.length >= 16)) add('APP_SECRET_ANTERIOR atual', x, true)
  const vk = (await db.query<any>("SELECT value FROM app_config WHERE key = 'vault-key'"))[0]
  const vkv = vk ? String(typeof vk.value === 'string' && vk.value.startsWith('"') ? (() => { try { return JSON.parse(vk.value) } catch { return vk.value } })() : vk.value) : '' // SQLite: texto JSON; Postgres: já vem como texto
  if (vkv) add('chave do banco atual (vault-key)', vkv, true)
  let entrada = ''; try { entrada = readFileSync(0, 'utf8') } catch { /* sem entrada */ }
  for (const linha of entrada.split('\n')) { const i = linha.indexOf('\t'); if (i > 0) add(linha.slice(0, i).trim(), linha.slice(i + 1)) }

  // 3) quem abre o quê
  const usadas = achados.filter((a) => a.usada), abrePor = new Map<number, Cand[]>()
  achados.forEach((a, i) => { const m = /^v2:([a-f0-9]{12}):/.exec(a.valor); abrePor.set(i, cands.filter((c) => (!m || m[1] === c.kid) && abre(c.key, a.valor))) })
  const ilegiveisHoje = achados.map((a, i) => ({ a, i })).filter(({ i }) => !abrePor.get(i)!.some((c) => c.ativa))
  log('=== Cofre de credenciais: diagnóstico (somente leitura) ===')
  log(`Credenciais cifradas em uso: ${usadas.length}  ·  cópias antigas (businesses.data, não usadas mais): ${achados.length - usadas.length}`)
  log(`Chaves testadas: ${cands.length} (${cands.filter((c) => c.ativa).length} em uso hoje pelo servidor)`)
  for (const c of cands) { const n = achados.filter((_, i) => abrePor.get(i)!.includes(c)).length; log(`  ${c.ativa ? '[em uso]' : '[candidata]'} ${c.origem} — ${c.seed.length} caracteres, impressão ${impressao(c.seed)}, id ${c.kid}: abre ${n} credencial(is)`) }
  log('')
  const faltam = ilegiveisHoje.filter(({ a }) => a.usada)
  if (!faltam.length) {
    log(ilegiveisHoje.length ? `Todas as credenciais EM USO abrem. (${ilegiveisHoje.length} cópia(s) antiga(s) não usadas não abrem — não afetam nada.)` : 'Todas as credenciais abrem com as chaves atuais. Nada a recuperar.')
    process.exitCode = 0
  } else {
    log(`Credenciais em uso que NÃO abrem com as chaves atuais: ${faltam.length}`)
    for (const { a, i } of faltam) { const quem = abrePor.get(i)!; const kid = /^v2:([a-f0-9]{12}):/.exec(a.valor)?.[1]; log(`  - ${a.lugar}${a.caminho ? ' › ' + a.caminho : ''}${kid ? ` (cifrada com a chave id ${kid})` : ' (formato v1)'}: ${quem.length ? 'abre com ' + quem.map((c) => c.origem).join(' / ') : 'NENHUMA candidata abre'}`) }
    // menor conjunto de candidatas (gulosa) que cobre as ilegíveis
    const escolhidas: Cand[] = [], resto = new Set(faltam.map((f) => f.i))
    while (resto.size) { let best: Cand | null = null, bn = 0; for (const c of cands.filter((x) => !x.ativa && !escolhidas.includes(x))) { const n = [...resto].filter((i) => abrePor.get(i)!.includes(c)).length; if (n > bn) { bn = n; best = c } } if (!best) break; escolhidas.push(best); for (const i of [...resto]) if (abrePor.get(i)!.includes(best)) resto.delete(i) }
    const invalidas = escolhidas.filter((c) => /[,'\n]/.test(c.seed))
    log('')
    if (!escolhidas.length) { log('RESULTADO: nenhuma das chaves encontradas abre essas credenciais. Nada foi alterado.'); process.exitCode = 12 }
    else {
      log(`RESULTADO: ${resto.size ? 'encontrada(s) chave(s) para PARTE das credenciais' : 'encontrada(s) a(s) chave(s) que abrem TODAS as credenciais em uso'}: ${escolhidas.map((c) => c.origem + ' (impressão ' + impressao(c.seed) + ')').join('; ')}`)
      if (resto.size) log(`Continuam sem chave: ${resto.size} credencial(is) (lista acima, "NENHUMA candidata abre").`)
      if (invalidas.length) log('ATENÇÃO: uma chave tem vírgula, aspas simples ou quebra de linha e não pode ir em APP_SECRET_ANTERIOR automaticamente; coloque-a em APP_SECRET à mão.')
      const ok = escolhidas.filter((c) => !invalidas.includes(c))
      if (ok.length) process.stdout.write('APP_SECRET_ANTERIOR=' + ok.map((c) => c.seed).join(',') + '\n')
      process.exitCode = resto.size || invalidas.length ? 11 : 10
    }
  }
} finally { await db.close() }
