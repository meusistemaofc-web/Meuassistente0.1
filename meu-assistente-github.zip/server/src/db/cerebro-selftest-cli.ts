// Teste REAL do Cérebro Central na VPS (com internet): mecanismos de pesquisa ativos, leitura de uma página e
// embeddings configurados. Não cria conhecimentos; só usa o cache de páginas. Uso:
//   docker compose exec app npm run cerebro:selftest            (ou: node dist/db/cerebro-selftest-cli.js)
//   docker compose exec app npm run cerebro:selftest -- "seu assunto"
import { connectFromEnv } from './connect.js'
const d = await connectFromEnv()
const C = await import('../ai/cerebro/central.js'), W = await import('../ai/cerebro/web.js'), V = await import('../ai/cerebro/vetor.js')
const { q } = await import('./index.js'), { unseal } = await import('../lib/settings.js')
const assunto = process.argv.slice(2).join(' ').trim() || 'energia solar fotovoltaica'
const linhas: string[] = []; let falhas = 0
const ok = (t: string) => { linhas.push('  ✔ ' + t); console.log('  ✔ ' + t) }, mal = (t: string) => { falhas++; linhas.push('  ✘ ' + t); console.log('  ✘ ' + t) }
console.log(`Cérebro Central — teste real (assunto: "${assunto}")`)
await C.provedores() // cria os padrões se faltarem
const cfg = await C.cfg()
for (const p of await q('SELECT * FROM brain_provider_configs ORDER BY kind, id')) {
  const c = { provider: p.provider, base_url: p.base_url || '', key: p.api_key ? await unseal(p.api_key) : '', model: p.model || '', extra: p.extra ? JSON.parse(p.extra) : {}, timeoutMs: cfg.timeoutMs }
  const ativo = p.enabled === true || p.enabled === 1 || p.enabled === 't'
  if (!ativo) { console.log(`  · ${p.name}: desligado (não testado)`); continue }
  const t0 = Date.now()
  try {
    if (p.kind === 'busca') {
      const r = await W.buscar(assunto, c, 5)
      if (!r.length) { mal(`${p.name}: respondeu sem resultados`); continue }
      ok(`${p.name}: ${r.length} resultado(s) em ${Date.now() - t0} ms — ex.: ${r[0].titulo} (${r[0].url})`)
      for (const x of r.slice(0, 3)) {
        try { const pg = await W.lerPagina(x.url, { timeoutMs: cfg.timeoutMs, cacheHoras: 0 }); ok(`  leitura de ${x.url}: ${pg.texto.length} caracteres`); break }
        catch (e: any) { console.log(`    · ${x.url}: ${e.message}`) }
      }
    } else {
      const r = await V.embed(['teste do Cérebro Central', assunto], c)
      ok(`${p.name}: vetores de ${r.vetores[0].length} dimensões em ${Date.now() - t0} ms (${r.provider}/${r.model}); similaridade entre os dois textos ${V.cosseno(r.vetores[0], r.vetores[1]).toFixed(3)}`)
    }
  } catch (e: any) { mal(`${p.name}: ${e.message}`) }
}
const P = await import('../ai/provider.js'); const ia = await P.readyCount('conversa').catch(() => 0)
console.log(`  · IAs prontas para redigir respostas (Motor do chat): ${ia}`)
console.log(falhas ? `\n${falhas} falha(s). Veja as mensagens acima.` : '\nTudo funcionando.')
await d.close()
process.exit(falhas ? 1 : 0)
