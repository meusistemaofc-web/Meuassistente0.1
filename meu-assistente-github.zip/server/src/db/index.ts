// Camada de banco: interface pequena (query/tx) com adaptador PostgreSQL (produção)
// e adaptador SQLite embutido do Node (somente para os testes automatizados offline).
export type Row = Record<string, any>
export interface Db {
  query<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R[]>
  tx<T>(fn: (q: Db) => Promise<T>): Promise<T>
  exec(sql: string): Promise<void>
  close(): Promise<void>
  kind: 'postgres' | 'sqlite'
}

let current: Db | null = null
// Contador de consultas por requisição (indicador de desempenho): cada requisição que chama contarConsultas() recebe o
// seu próprio contador, isolado das outras pelo contexto assíncrono. Sem contador ativo, não custa nada.
import { AsyncLocalStorage } from 'node:async_hooks'
type Contador = { n: number; sql?: string[]; memo: Map<string, unknown> | null }
const CONTADOR = new AsyncLocalStorage<Contador>()
export function contarConsultas() { const s: Contador = { n: 0, memo: process.env.MEMO_REQUISICAO === '0' ? null : new Map(), ...(process.env.DIAG_CONSULTAS ? { sql: [] } : {}) }; CONTADOR.enterWith(s); return s }
/** Memória DA REQUISIÇÃO atual (null fora de uma requisição medida): leituras repetidas da mesma configuração numa só
 *  mensagem vão ao banco uma vez. Nada é compartilhado entre requisições — não há risco de dado desatualizado. */
export function memoRequisicao() { return CONTADOR.getStore()?.memo ?? null }
export function setDb(d: Db) {
  const orig = d.query.bind(d)
  d.query = ((sql: string, params?: unknown[]) => { const s = CONTADOR.getStore(); if (s) { s.n++; s.sql?.push(sql.replace(/\s+/g, ' ').slice(0, 70) + ' ' + JSON.stringify(params || []).slice(0, 50)) } return orig(sql, params) }) as Db['query']
  current = d
}
export function db(): Db {
  if (!current) throw new Error('Banco de dados não inicializado')
  return current
}
export async function one<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R | null> {
  const rows = await db().query<R>(sql, params)
  return rows[0] ?? null
}
export const q = <R extends Row = Row>(sql: string, params?: unknown[]) => db().query<R>(sql, params)

/** Valores JSON vêm como objeto (PostgreSQL JSONB) ou texto (SQLite). */
export function J<T = any>(v: unknown, fallback: T): T {
  if (v === null || v === undefined) return fallback
  if (typeof v === 'string') { try { return JSON.parse(v) as T } catch { return fallback } }
  return v as T
}
export const B = (v: unknown) => v === true || v === 1 || v === '1' || v === 't'
export const nowIso = () => new Date().toISOString()
export function isoOf(v: unknown): string | null {
  if (!v) return null
  if (v instanceof Date) return v.toISOString()
  const s = String(v)
  const d = new Date(s.includes('T') || s.endsWith('Z') ? s : s.replace(' ', 'T') + 'Z')
  return isNaN(d.getTime()) ? s : d.toISOString()
}
