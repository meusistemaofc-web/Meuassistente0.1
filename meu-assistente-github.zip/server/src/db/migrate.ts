import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { Db } from './index.js'

/** Aplica, em ordem, os arquivos migrations/NNN_*.sql ainda não registrados. Reprodutível e idempotente. */
export async function migrate(d: Db, dir: string, log: (m: string) => void = console.log): Promise<string[]> {
  await d.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`)
  const done = new Set((await d.query<{ version: string }>('SELECT version FROM schema_migrations')).map((r) => r.version))
  const files = readdirSync(dir).filter((f) => /^\d+_.*\.sql$/.test(f)).sort()
  const applied: string[] = []
  // proteção: antes de aplicar qualquer migração nova, copia todas as integrações das empresas para o histórico (backup
  // dentro do próprio banco, além do pg_dump do update.sh). Migrações nunca apagam nem recriam integrações.
  const pendentes = files.filter((f) => !done.has(f))
  if (pendentes.length) {
    try {
      const rows = await d.query<any>('SELECT business_id, provedor, versao, dados, status FROM empresa_integracoes')
      for (const r of rows) await d.query('INSERT INTO empresa_integracoes_historico (business_id, provedor, versao, dados, status, motivo, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7)', [r.business_id, r.provedor, r.versao, typeof r.dados === 'string' ? r.dados : JSON.stringify(r.dados), r.status, ('backup antes das migrações: ' + pendentes.join(', ')).slice(0, 200), new Date().toISOString()])
      if (rows.length) log(`[migrate] backup de ${rows.length} integração(ões) de empresas antes das migrações`)
    } catch { /* primeira instalação: a tabela de integrações ainda não existe */ }
  }
  for (const f of files) {
    if (done.has(f)) continue
    const sql = readFileSync(join(dir, f), 'utf8')
    await d.tx(async (t) => {
      await t.exec(sql)
      await t.query('INSERT INTO schema_migrations (version, applied_at) VALUES ($1, $2)', [f, new Date().toISOString()])
    })
    log(`[migrate] aplicada ${f}`)
    applied.push(f)
  }
  if (!applied.length) log('[migrate] banco já está atualizado')
  // dados que dependem de leitura (não cabem em SQL portável): modalidade exclusiva das empresas existentes
  await (await import('../lib/modalidade.js')).backfillModalidades(d, log)
  return applied
}
