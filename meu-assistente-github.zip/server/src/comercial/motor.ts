// Motor de Notificações Comerciais: roda no agendador do servidor (a cada 30 s), sem depender de ninguém conectado.
// Regras: uma sequência por campanha e alvo (nunca recomeça); confere a situação antes de cada envio e interrompe na hora
// em que o serviço é contratado; não envia fora do horário permitido nem mais de uma oferta comercial por intervalo mínimo;
// etapas atrasadas não se acumulam (vai só a mais recente). Tudo usa a central de notificações existente (notify).
import { createHmac, timingSafeEqual } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import { validTz, localTime } from '../lib/time.js'
import { CAMPANHAS, campanhaPorId } from './campanhas.js'
import type { CampanhaComercial, ConfigCampanha, Etapa } from './tipos.js'

export const GLOBAL_DEFAULT = { ativo: true, inicio: '08:00', fim: '21:00', intervaloMinHoras: 20 }
export async function cfgGlobal() { return { ...GLOBAL_DEFAULT, ...(await getConfig<any>('comercial_global', {})) } }
export async function salvarGlobal(b: any) {
  const atual = await cfgGlobal(), hm = (s: any, p: string) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(s)) ? String(s) : p)
  const novo = { ativo: b.ativo !== undefined ? b.ativo !== false : atual.ativo, inicio: hm(b.inicio, atual.inicio), fim: hm(b.fim, atual.fim), intervaloMinHoras: Math.max(1, Math.min(24 * 14, Math.round(Number(b.intervaloMinHoras ?? atual.intervaloMinHoras) || 20))) }
  if (novo.inicio >= novo.fim) throw Object.assign(new Error('O horário de início deve ser antes do fim.'), { status: 400 })
  await setConfig('comercial_global', novo); return novo
}

/* ---------- configuração de cada campanha (mensagens e intervalos editáveis) ---------- */
const lim = (s: any, n: number) => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, n)
function mesclar(c: CampanhaComercial, salvo: any): ConfigCampanha {
  const s = J<any>(salvo, {}), etapas = Array.isArray(s.etapas) ? s.etapas : []
  return {
    minimoVisualizacoes: Number.isFinite(Number(s.minimoVisualizacoes)) ? Math.max(0, Number(s.minimoVisualizacoes)) : c.padrao.minimoVisualizacoes,
    etapas: c.padrao.etapas.map((p) => { const e = etapas.find((x: any) => x && x.chave === p.chave) || {}; return { ...p, ...e, chave: p.chave, rotulo: p.rotulo } }),
  }
}
export async function estado(c: CampanhaComercial) {
  let r = await one('SELECT * FROM com_campanhas WHERE id = $1', [c.id])
  if (!r) { try { await q('INSERT INTO com_campanhas (id, ativo, config, ativada_em, atualizado_em) VALUES ($1,$2,$3,$4,$4)', [c.id, true, '{}', nowIso()]) } catch { /* criada em paralelo */ } r = await one('SELECT * FROM com_campanhas WHERE id = $1', [c.id]) }
  if (!r) throw new Error('campanha comercial indisponível')
  return { ativo: r.ativo === true || r.ativo === 1 || r.ativo === 't', ativadaEm: iso(r.ativada_em), config: mesclar(c, r.config), atualizadoEm: r.atualizado_em, atualizadoPor: r.atualizado_por ? Number(r.atualizado_por) : null }
}
/** Validação do que o administrador editou (não aceita etapa sem texto, intervalos fora de ordem nem campos enormes). */
export async function salvarCampanha(id: string, b: any, adminId: number) {
  const c = campanhaPorId(id); if (!c) throw Object.assign(new Error('Campanha não encontrada.'), { status: 404 })
  const st = await estado(c)
  const etapas: Etapa[] = st.config.etapas.map((e) => {
    const n = (Array.isArray(b.etapas) ? b.etapas : []).find((x: any) => x && x.chave === e.chave); if (!n) return e
    return { ...e, ativo: n.ativo !== undefined ? n.ativo !== false : e.ativo, atrasoHoras: n.atrasoHoras !== undefined ? Math.round(Number(n.atrasoHoras)) : e.atrasoHoras, titulo: n.titulo !== undefined ? lim(n.titulo, 90) : e.titulo, mensagem: n.mensagem !== undefined ? lim(n.mensagem, 400) : e.mensagem, mensagemComDados: n.mensagemComDados !== undefined ? lim(n.mensagemComDados, 400) : e.mensagemComDados, botao: n.botao !== undefined ? lim(n.botao, 30) : e.botao }
  })
  for (const e of etapas) {
    if (!Number.isFinite(e.atrasoHoras) || e.atrasoHoras < 0 || e.atrasoHoras > 24 * 90) throw Object.assign(new Error(`Intervalo inválido em "${e.rotulo}" (de 0 a 2160 horas).`), { status: 400 })
    if (e.ativo && (!e.titulo || !e.mensagem || !e.botao)) throw Object.assign(new Error(`Preencha título, mensagem e botão de "${e.rotulo}".`), { status: 400 })
  }
  const ord = etapas.map((e) => e.atrasoHoras); if (ord.some((v, i) => i && v <= ord[i - 1])) throw Object.assign(new Error('Cada etapa precisa acontecer depois da anterior.'), { status: 400 })
  const config = { etapas, minimoVisualizacoes: b.minimoVisualizacoes !== undefined ? Math.max(0, Math.round(Number(b.minimoVisualizacoes) || 0)) : st.config.minimoVisualizacoes }
  const ativo = b.ativo !== undefined ? b.ativo !== false : st.ativo
  // religar depois de desligada: só entram anúncios publicados a partir de agora (quem já estava inscrito continua de onde parou)
  const ativadaEm = ativo && !st.ativo ? nowIso() : st.ativadaEm
  await q('UPDATE com_campanhas SET ativo = $1, config = $2, ativada_em = $3, atualizado_em = $4, atualizado_por = $5 WHERE id = $6', [ativo, JSON.stringify(config), ativadaEm, nowIso(), adminId, id])
  return estado(c)
}

/* ---------- link do botão (assinado: só o dono da inscrição usa) ---------- */
const sig = (s: string) => createHmac('sha256', process.env.SETTINGS_KEY || process.env.SESSION_SECRET || 'meu-assistente-com').update('com:' + s).digest('hex').slice(0, 16)
export const token = (inscricao: number, etapa: number) => `${inscricao}.${etapa}.${sig(`${inscricao}.${etapa}`)}`
export function lerToken(t: string) {
  const m = /^(\d+)\.(\d+)\.([a-f0-9]{16})$/.exec(String(t || '')); if (!m) return null
  const a = Buffer.from(m[3]), b = Buffer.from(sig(`${m[1]}.${m[2]}`)); if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  return { inscricao: Number(m[1]), etapa: Number(m[2]) }
}

/* ---------- eventos ---------- */
export async function evento(i: any, tipo: string, etapa = -1, dados: any = {}, notificationId: number | null = null, em = nowIso()) {
  try { await q('INSERT INTO com_eventos (campanha, inscricao_id, business_id, owner_id, etapa, tipo, notification_id, dados, criado_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)', [i.campanha, Number(i.id), Number(i.business_id), Number(i.owner_id), etapa, tipo, notificationId, JSON.stringify(dados), em]); return true } catch { return false } // já registrado (um por etapa e tipo)
}
async function finalizar(i: any, status: string, motivo: string | null) {
  await q("UPDATE com_inscricoes SET status = $1, motivo = $2, finalizado_em = $3 WHERE id = $4 AND status = 'ativa'", [status, motivo, nowIso(), Number(i.id)])
}
/** datas do banco viram ISO (o PostgreSQL devolve Date; o SQLite, texto) */
export const iso = (v: any) => { const t = v instanceof Date ? v.getTime() : Date.parse(String(v)); return Number.isFinite(t) ? new Date(t).toISOString() : '' }
const preencher = (s: string, v: Record<string, string | number>) => s.replace(/\{(\w+)\}/g, (m, k) => (v[k] !== undefined ? String(v[k]) : m))

/** Conversão: o serviço foi contratado. Conta como conversão só se a pessoa já recebeu alguma mensagem da sequência. */
async function converter(i: any) {
  const envios = await q("SELECT etapa FROM com_eventos WHERE inscricao_id = $1 AND tipo = 'envio' ORDER BY etapa DESC", [Number(i.id)])
  if (!envios.length) { await finalizar(i, 'interrompida', 'ja_contratado'); await evento(i, 'interrupcao', -1, { motivo: 'ja_contratado' }); return }
  const clicou = await one("SELECT etapa FROM com_eventos WHERE inscricao_id = $1 AND tipo = 'clique' ORDER BY id DESC LIMIT 1", [Number(i.id)])
  await finalizar(i, 'convertida', null)
  await evento(i, 'conversao', Number(envios[0].etapa), { aposClique: !!clicou, etapaClique: clicou ? Number(clicou.etapa) : null })
}

/** Uma rodada do motor. Devolve um resumo (usado pelo painel e pelos testes). */
let rodando = false
export async function processar(now = new Date(), opts: { soCampanha?: string } = {}) {
  const out = { inscritas: 0, enviados: 0, convertidas: 0, interrompidas: 0, visualizacoes: 0 }
  if (rodando) return out
  rodando = true
  try {
    await registrarVisualizacoes(out)
    const G = await cfgGlobal()
    for (const c of CAMPANHAS) {
      if (opts.soCampanha && c.id !== opts.soCampanha) continue
      const st = await estado(c)
      if (!G.ativo || !st.ativo) { await conferirConversoes(c, out); continue } // desligada: não envia, mas a contratação ainda encerra a sequência
      if (await c.disponivel()) for (const a of await c.candidatos(st.ativadaEm)) if (await inscrever(c, a)) out.inscritas++
      await rodarInscricoes(c, st.config, G, now, out)
    }
  } finally { rodando = false }
  return out
}
export async function inscrever(c: CampanhaComercial, a: { businessId: number; ownerId: number; inicio: string }) {
  const chave = c.escopo === 'dono' ? `u:${a.ownerId}` : `b:${a.businessId}`
  if (await one('SELECT id FROM com_inscricoes WHERE campanha = $1 AND chave = $2', [c.id, chave])) return false
  const s = await c.situacao(a); if (s.convertido || s.parar) return false // já tem o serviço ou o anúncio não está no ar: nem começa
  try { await q('INSERT INTO com_inscricoes (campanha, chave, business_id, owner_id, status, inicio_em, proxima_etapa, criado_em) VALUES ($1,$2,$3,$4,$5,$6,0,$7)', [c.id, chave, a.businessId, a.ownerId, 'ativa', a.inicio, nowIso()]); return true } catch { return false }
}
async function conferirConversoes(c: CampanhaComercial, out: any) {
  for (const i of await q("SELECT * FROM com_inscricoes WHERE campanha = $1 AND status = 'ativa'", [c.id])) {
    if ((await c.situacao({ businessId: Number(i.business_id), ownerId: Number(i.owner_id) })).convertido) { await converter(i); out.convertidas++ }
  }
}
async function rodarInscricoes(c: CampanhaComercial, cfg: ConfigCampanha, G: any, now: Date, out: any) {
  const etapas = cfg.etapas
  for (const i of await q("SELECT * FROM com_inscricoes WHERE campanha = $1 AND status = 'ativa' ORDER BY id LIMIT 500", [c.id])) {
    const alvo = { businessId: Number(i.business_id), ownerId: Number(i.owner_id) }
    const s = await c.situacao(alvo)
    if (s.convertido) { await converter(i); out.convertidas++; continue }
    if (s.parar) { await finalizar(i, 'interrompida', s.parar); await evento(i, 'interrupcao', -1, { motivo: s.parar }); out.interrompidas++; continue }
    if (s.aguardar) continue
    const prox = Number(i.proxima_etapa) || 0, t0 = Date.parse(iso(i.inicio_em))
    const vencidas = etapas.map((e, idx) => ({ e, idx })).filter(({ e, idx }) => idx >= prox && e.ativo && t0 + e.atrasoHoras * 3600_000 <= now.getTime())
    if (!vencidas.length) { if (!etapas.some((e, idx) => idx >= prox && e.ativo)) await finalizar(i, 'concluida', null); continue }
    // horário permitido no fuso do dono
    const u = await one('SELECT settings, role FROM users WHERE id = $1', [alvo.ownerId]); if (!u) continue
    const hm = localTime(validTz(J<any>(u.settings, {}).timezone), now); if (hm < G.inicio || hm >= G.fim) continue
    // no máximo uma oferta comercial por intervalo mínimo, somando todas as campanhas
    const ult = await one("SELECT MAX(criado_em) AS t FROM com_eventos WHERE owner_id = $1 AND tipo = 'envio'", [alvo.ownerId])
    if (ult?.t && now.getTime() - Date.parse(iso(ult.t)) < G.intervaloMinHoras * 3600_000) continue
    const { e, idx } = vencidas[vencidas.length - 1] // só a mais recente: etapas atrasadas não se acumulam
    for (const v of vencidas.slice(0, -1)) await evento(i, 'pulada', v.idx, { motivo: 'substituida_pela_seguinte' })
    const vars = await c.variaveis({ ...alvo, inicio: iso(i.inicio_em) })
    const comDados = !!e.mensagemComDados && Number(vars.visualizacoes || 0) >= Math.max(1, cfg.minimoVisualizacoes)
    const titulo = preencher(e.titulo, vars), corpo = preencher(comDados ? e.mensagemComDados : e.mensagem, vars)
    const tk = token(Number(i.id), idx), ref = `com:${c.id}:${i.id}:${idx}`
    await notify(alvo.ownerId, { type: 'plan', title: titulo, body: corpo, link: `/x/sua-empresa?nc=${tk}`, ref })
    const n = await one('SELECT id FROM notifications WHERE user_id = $1 AND ref = $2', [alvo.ownerId, ref])
    await q('UPDATE com_inscricoes SET proxima_etapa = $1, ultimo_envio_em = $2 WHERE id = $3', [idx + 1, now.toISOString(), Number(i.id)])
    // sem a notificação gravada = a pessoa desligou as notificações no perfil: registra e não insiste
    if (n) { await evento(i, 'envio', idx, { etapa: e.chave, titulo, corpo, botao: e.botao, personalizada: comDados, vars }, Number(n.id), now.toISOString()); out.enviados++ }
    else await evento(i, 'bloqueado', idx, { etapa: e.chave, motivo: 'notificacoes_desligadas' }, null, now.toISOString())
  }
}
/** Visualização = a notificação foi aberta/marcada como lida na central de notificações. */
async function registrarVisualizacoes(out: any) {
  const rows = await q(`SELECT e.* FROM com_eventos e JOIN notifications n ON n.id = e.notification_id
    WHERE e.tipo = 'envio' AND n.read = $1 AND NOT EXISTS (SELECT 1 FROM com_eventos v WHERE v.inscricao_id = e.inscricao_id AND v.etapa = e.etapa AND v.tipo = 'visualizacao') LIMIT 500`, [true])
  for (const r of rows) if (await evento({ id: r.inscricao_id, campanha: r.campanha, business_id: r.business_id, owner_id: r.owner_id }, 'visualizacao', Number(r.etapa))) out.visualizacoes++
}

/* ---------- ações do dono (botão e "não quero receber") ---------- */
export async function clique(userId: number, t: string) {
  const k = lerToken(t); if (!k) return null
  const i = await one('SELECT * FROM com_inscricoes WHERE id = $1', [k.inscricao]); if (!i || Number(i.owner_id) !== userId) return null // isolamento: só o dono
  const c = campanhaPorId(i.campanha); if (!c) return null
  await evento(i, 'visualizacao', k.etapa); await evento(i, 'clique', k.etapa)
  await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND ref = $3', [true, userId, `com:${i.campanha}:${i.id}:${k.etapa}`])
  return { ...c.destino({ businessId: Number(i.business_id) }), ativa: i.status === 'ativa' }
}
export async function sair(userId: number, t: string) {
  const k = lerToken(t); if (!k) return false
  const i = await one('SELECT * FROM com_inscricoes WHERE id = $1', [k.inscricao]); if (!i || Number(i.owner_id) !== userId) return false
  if (i.status === 'ativa') { await finalizar(i, 'interrompida', 'recusou'); await evento(i, 'interrupcao', -1, { motivo: 'recusou' }) }
  return true
}
/** Notificações comerciais do próprio usuário (o app põe o botão embaixo de cada uma). */
export async function minhas(userId: number) {
  const rows = await q(`SELECT e.etapa, e.dados, e.notification_id, i.id AS insc, i.status FROM com_eventos e JOIN com_inscricoes i ON i.id = e.inscricao_id
    WHERE e.owner_id = $1 AND e.tipo = 'envio' ORDER BY e.id DESC LIMIT 50`, [userId])
  return rows.map((r: any) => { const d = J<any>(r.dados, {}); return { notificacao: Number(r.notification_id), titulo: d.titulo, botao: d.botao, t: token(Number(r.insc), Number(r.etapa)), ativa: r.status === 'ativa', convertida: r.status === 'convertida' } })
}

/** Inclui de uma vez os anúncios que já estavam no ar antes de a campanha ser ligada (a sequência começa agora). */
export async function incluirExistentes(id: string) {
  const c = campanhaPorId(id); if (!c) return 0
  let n = 0; for (const a of await c.candidatos((await estado(c)).ativadaEm, true)) if (await inscrever(c, a)) n++
  return n
}

/* ---------- resultados para o painel ---------- */
export async function resultados(c: CampanhaComercial) {
  const cnt = async (sql: string, p: any[]) => Number((await one(sql, p))?.n || 0)
  const st: Record<string, number> = {}
  for (const r of await q('SELECT status, COUNT(*) AS n FROM com_inscricoes WHERE campanha = $1 GROUP BY status', [c.id])) st[r.status] = Number(r.n)
  const mot: Record<string, number> = {}
  for (const r of await q("SELECT motivo, COUNT(*) AS n FROM com_inscricoes WHERE campanha = $1 AND status = 'interrompida' GROUP BY motivo", [c.id])) mot[r.motivo || 'outro'] = Number(r.n)
  const tipos = ['envio', 'visualizacao', 'clique', 'conversao']
  const porEtapa: any[] = []
  const conf = (await estado(c)).config
  for (let idx = 0; idx < conf.etapas.length; idx++) {
    const o: any = { etapa: conf.etapas[idx].chave, rotulo: conf.etapas[idx].rotulo }
    for (const t of tipos) o[t] = await cnt('SELECT COUNT(*) AS n FROM com_eventos WHERE campanha = $1 AND etapa = $2 AND tipo = $3', [c.id, idx, t])
    porEtapa.push(o)
  }
  const tot: any = {}; for (const t of tipos) tot[t] = await cnt('SELECT COUNT(*) AS n FROM com_eventos WHERE campanha = $1 AND tipo = $2', [c.id, t])
  const alcancados = await cnt("SELECT COUNT(DISTINCT inscricao_id) AS n FROM com_eventos WHERE campanha = $1 AND tipo = 'envio'", [c.id])
  const recentes = (await q('SELECT i.*, b.data FROM com_inscricoes i LEFT JOIN businesses b ON b.id = i.business_id WHERE i.campanha = $1 ORDER BY i.id DESC LIMIT 20', [c.id])).map((r: any) => ({ id: Number(r.id), empresa: J<any>(r.data, {}).empresa || `Empresa #${r.business_id}`, status: r.status, motivo: r.motivo, enviadas: Number(r.proxima_etapa) || 0, inicio: iso(r.inicio_em), ultimoEnvio: r.ultimo_envio_em ? iso(r.ultimo_envio_em) : null }))
  return { inscricoes: { total: Object.values(st).reduce((a, b) => a + b, 0), ativas: st.ativa || 0, convertidas: st.convertida || 0, concluidas: st.concluida || 0, interrompidas: st.interrompida || 0, motivos: mot }, enviados: tot.envio, visualizacoes: tot.visualizacao, cliques: tot.clique, conversoes: tot.conversao, alcancados, taxaConversao: alcancados ? Math.round((tot.conversao / alcancados) * 1000) / 10 : 0, porEtapa, recentes }
}
