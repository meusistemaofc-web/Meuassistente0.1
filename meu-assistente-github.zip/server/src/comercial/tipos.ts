// Motor de Notificações Comerciais: cada campanha oferece um serviço do Meu Assistente a quem ainda não o tem.
// Para criar uma campanha nova: implemente CampanhaComercial num arquivo próprio e acrescente-a em CAMPANHAS (campanhas.ts).
// O motor cuida do resto: inscrição única, intervalos, horário permitido, limite de frequência, registro de eventos,
// interrupção na conversão e resultados no painel.

export interface Etapa {
  /** identificador estável da etapa (ex.: publicacao, 24h) */
  chave: string
  /** rótulo exibido no painel */
  rotulo: string
  /** horas depois do início (publicação) */
  atrasoHoras: number
  ativo: boolean
  titulo: string
  /** mensagem padrão */
  mensagem: string
  /** mensagem usada quando há dados do anúncio (visualizações/contatos); vazia = usa a padrão */
  mensagemComDados: string
  /** texto do botão */
  botao: string
}
export interface ConfigCampanha {
  etapas: Etapa[]
  /** visualizações mínimas para usar a mensagem com dados */
  minimoVisualizacoes: number
}
export interface Alvo { businessId: number; ownerId: number; inicio: string }
export interface Situacao {
  /** o serviço oferecido já foi contratado: encerra a sequência (conversão se já recebeu alguma mensagem) */
  convertido?: boolean
  /** motivo para interromper de vez (ex.: anúncio reprovado, encerrado) */
  parar?: string
  /** motivo para só esperar (ex.: módulo desligado): não envia agora, não encerra */
  aguardar?: string
}
export interface CampanhaComercial {
  id: string
  nome: string
  descricao: string
  /** serviço oferecido (exibido no painel) */
  servico: string
  /** 'dono': uma sequência por dono (serviço da conta); 'empresa': uma por empresa */
  escopo: 'dono' | 'empresa'
  padrao: ConfigCampanha
  /** campanha disponível agora (ex.: módulo ligado pelo administrador) */
  disponivel(): Promise<boolean>
  /** alvos novos desde `desde` (ISO); incluirTodos traz também os anteriores */
  candidatos(desde: string, incluirTodos?: boolean): Promise<Alvo[]>
  /** conferido antes de cada envio e a cada rodada do motor */
  situacao(a: { businessId: number; ownerId: number }): Promise<Situacao>
  /** variáveis para as mensagens ({empresa}, {visualizacoes}…) */
  variaveis(a: { businessId: number; ownerId: number; inicio: string }): Promise<Record<string, string | number>>
  /** para onde o botão leva (o app abre a tela de contratação) */
  destino(a: { businessId: number }): { tela: string; businessId: number }
}
