// Campanhas comerciais registradas. Só entram aqui campanhas de serviços que existem de verdade no Meu Assistente.
import { q, one, J } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import type { CampanhaComercial } from './tipos.js'

const brl = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v)
/** Agente contratado = plano pago e dentro da validade (mesma regra do módulo do agente; ligar/desligar não muda a contratação). */
export const agenteContratado = (x: any, agora = Date.now()) => !!(x?.agente && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > agora)
/** Anúncio efetivamente publicado: no ar, dentro da validade e sem suspensão do administrador. */
export const anuncioNoAr = (b: any, agora = Date.now()) => b?.status === 'ativo' && !(b.expires_at && Date.parse(b.expires_at) < agora) && !J<any>(b.data, {}).revogado
const publicadoEm = (b: any) => { const v = J<any>(b.data, {}).aprovadoEm || b.created_at; return v instanceof Date ? v.toISOString() : String(v || '') }

export const agenteAtendimento: CampanhaComercial = {
  id: 'agente_atendimento',
  nome: 'Agente de Atendimento após a publicação do anúncio',
  descricao: 'Quando o anúncio de uma empresa vai ao ar e ela ainda não tem o Agente de Atendimento, mostra os benefícios do agente em uma sequência de notificações.',
  servico: 'Agente de Atendimento 24h',
  escopo: 'dono', // o agente é um por dono (o sistema não deixa criar um segundo): uma sequência por pessoa, mesmo com várias empresas
  padrao: {
    minimoVisualizacoes: 1,
    etapas: [
      { chave: 'publicacao', rotulo: 'Na publicação', atrasoHoras: 0, ativo: true, botao: 'Conhecer o agente',
        titulo: 'Seu anúncio está no ar! Que tal um atendente 24h?',
        mensagem: '{empresa} já aparece para clientes perto de você. Com o Agente de Atendimento, cada pergunta é respondida na hora, até de madrugada: ele apresenta seus produtos e serviços e encaminha pedidos.',
        mensagemComDados: '' },
      { chave: '24h', rotulo: '24 horas depois', atrasoHoras: 24, ativo: true, botao: 'Ativar meu agente',
        titulo: 'Clientes estão vendo {empresa}',
        mensagem: 'Quem encontra seu anúncio costuma ter dúvidas antes de comprar. O Agente de Atendimento responde preço, horário, entrega e formas de pagamento 24 horas por dia, sem você precisar parar o que está fazendo.',
        mensagemComDados: 'Seu anúncio já teve {visualizacoes} visualizações. Cada uma pode virar uma pergunta: o Agente de Atendimento responde na hora, 24 horas por dia, e mostra seus produtos para quem está interessado.' },
      { chave: '3d', rotulo: '3 dias depois', atrasoHoras: 72, ativo: true, botao: 'Contratar o agente',
        titulo: 'Não deixe clientes sem resposta',
        mensagem: 'Muita venda se perde quando a resposta demora. O agente de {empresa} esclarece dúvidas, apresenta o catálogo e identifica quem está pronto para comprar, a qualquer hora.',
        mensagemComDados: 'Em 3 dias, {empresa} teve {visualizacoes} visualizações e {contatos} contatos. Com o agente, ninguém fica esperando: ele responde, apresenta o catálogo e identifica oportunidades de venda a qualquer hora.' },
      { chave: '7d', rotulo: '7 dias depois', atrasoHoras: 168, ativo: true, botao: 'Ativar agora',
        titulo: 'Seu atendente que nunca fecha',
        mensagem: 'Uma semana de anúncio no ar. Por {preco} a cada {dias} dias, o Agente de Atendimento cuida das conversas de {empresa} 24 horas por dia, e você recebe os pedidos prontos.',
        mensagemComDados: 'Uma semana no ar e {visualizacoes} visualizações. Por {preco} a cada {dias} dias, o Agente de Atendimento atende esses clientes 24 horas por dia, responde dúvidas e encaminha os pedidos para você.' },
    ],
  },
  async disponivel() {
    const { modules } = await import('../lib/usermod.js')
    return !!(await modules()).agente
  },
  async candidatos(desde, incluirTodos = false) {
    const rows = await q("SELECT b.id, b.owner_id, b.status, b.expires_at, b.data, b.created_at FROM businesses b JOIN users u ON u.id = b.owner_id WHERE b.status = 'ativo' AND u.role = 'user' ORDER BY b.id")
    const t0 = Date.parse(desde) || 0
    return rows.filter((b: any) => anuncioNoAr(b) && (incluirTodos || Date.parse(publicadoEm(b)) >= t0)).map((b: any) => ({ businessId: Number(b.id), ownerId: Number(b.owner_id), inicio: incluirTodos && Date.parse(publicadoEm(b)) < t0 ? new Date().toISOString() : new Date(Date.parse(publicadoEm(b)) || Date.now()).toISOString() }))
  },
  async situacao({ businessId, ownerId }) {
    // o agente pode estar em qualquer empresa do dono
    const doDono = await q('SELECT id, status, expires_at, data FROM businesses WHERE owner_id = $1', [ownerId])
    if (doDono.some((b: any) => agenteContratado(J<any>(b.data, {})))) return { convertido: true }
    const b = doDono.find((r: any) => Number(r.id) === businessId)
    if (!b) return { parar: 'anuncio_removido' }
    if (b.status === 'recusado') return { parar: 'anuncio_reprovado' }
    if (!anuncioNoAr(b)) return { parar: 'anuncio_inativo' }
    if (!(await this.disponivel())) return { aguardar: 'modulo_desligado' }
    return {}
  },
  async variaveis({ businessId, ownerId, inicio }) {
    const b = await one('SELECT data FROM businesses WHERE id = $1', [businessId]); const x = J<any>(b?.data, {})
    const u = await one('SELECT name FROM users WHERE id = $1', [ownerId])
    const dia = String(inicio || '').slice(0, 10) || '1970-01-01'
    const st = await q('SELECT kind, SUM(n) AS n FROM business_stats WHERE business_id = $1 AND day >= $2 GROUP BY kind', [businessId, dia])
    const n = (k: string[]) => st.filter((r: any) => k.includes(r.kind)).reduce((s: number, r: any) => s + Number(r.n || 0), 0)
    const p = { preco: 39.9, dias: 30, ...(await getConfig<any>('agent_plan', {})) }
    return { empresa: x.empresa || 'Sua empresa', nome: String(u?.name || '').split(' ')[0], visualizacoes: n(['impressao', 'visita']), contatos: n(['whatsapp', 'instagram', 'link', 'mapa']), pedidos: n(['pedido']), preco: brl(Number(p.preco) || 0), dias: Number(p.dias) || 30 }
  },
  destino({ businessId }) { return { tela: 'agente', businessId } },
}

export const CAMPANHAS: CampanhaComercial[] = [agenteAtendimento]
export const campanhaPorId = (id: string) => CAMPANHAS.find((c) => c.id === id) || null
