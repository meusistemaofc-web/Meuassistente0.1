// Inteligência de Agenda e Funcionamento Empresarial: a IA entende horário, intervalos, feriados, exceções, bloqueios e reservas
// e responde com a disponibilidade REAL (o mesmo motor de agendamento das empresas: routes/businesses.ts → freeSlots).
// Consulta, calcula e sugere livremente; alterar expediente só pelo DONO da empresa, nunca no modo "manual",
// nunca cancelando reservas e sempre pedindo confirmação quando houver reservas afetadas. Sugestão nunca vira regra sozinha.
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import { modules } from '../lib/usermod.js'
import { notify } from '../lib/notify.js'
import { withLock } from '../lib/business-sync.js'
import * as K from '../lib/calendar.js'
import type { SessionUser } from '../lib/session.js'
import type { ToolDef } from './provider.js'

export const agendaIAOn = async () => (await getConfig<any>('agenda_ia', { ativo: true })).ativo !== false && (await modules()).empresas !== false
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
/** Reconhece, sem IA, conversa que exige conhecimento de agenda empresarial. */
export function isAgendaIAQuery(text: string) {
  const s = nrm(text)
  return /\b(feriado|feriadao|expediente|intervalo|almoco|janta|folga|horario de funcionamento|funcionamento|horarios? (livres?|disponiveis?|vagos?)|disponibilidade|bloquear (a )?agenda|bloqueio|fechar (a loja|a empresa|o dia|dia)|abrir (a loja|a empresa|no feriado|dia)|horario especial|agenda da empresa|vagas?)\b/.test(s)
    || /\b(abre|fecha|abrimos|fechamos|funciona)\b.*\b(hoje|amanha|sabado|domingo|segunda|terca|quarta|quinta|sexta|dia \d+|feriado)\b/.test(s)
}
async function mine(userId: number) {
  return (await q('SELECT * FROM businesses WHERE owner_id = $1 ORDER BY id', [userId])).filter((b) => b.status !== 'recusado' && b.status !== 'lixeira').map((b) => ({ b, x: J<any>(b.data, {}) }))
}
function pick(list: { b: any; x: any }[], nome?: string) {
  if (!list.length) return { erro: 'Você não tem empresa cadastrada.' }
  if (nome) { const n = nrm(nome), f = list.filter((e) => nrm(e.x.empresa || '').includes(n) || n.includes(nrm(e.x.empresa || ''))); if (f.length === 1) return { e: f[0] }; if (f.length > 1) return { erro: 'Mais de uma empresa combina: ' + f.map((e) => e.x.empresa).join(', ') } }
  if (list.length === 1) return { e: list[0] }
  return { erro: 'Qual empresa? ' + list.map((e) => e.x.empresa).join(', ') }
}
const dataOk = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s + 'T12:00:00Z'))
const fmtData = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}`
async function ordersOf(bid: number, from: string, to: string) {
  return (await q("SELECT id, data, status FROM orders WHERE business_id = $1 AND status IN ('novo','aceito')", [bid])).map((r) => ({ id: Number(r.id), status: r.status, d: J<any>(r.data, {}) }))
    .filter((o) => o.d.tipo === 'agendamento' && o.d.data >= from && o.d.data <= to).map((o) => ({ id: o.id, data: String(o.d.data), hora: String(o.d.hora), dur: Number(o.d.duracao) || 30, servico: String(o.d.servico || ''), status: o.status }))
}
export interface Alerta { tipo: 'decisao_feriado' | 'feriado_aplicado' | 'funcionamento_especial' | 'sem_intervalo' | 'conflito' | 'reorganizacao'; gravidade: 'alta' | 'media' | 'info'; data?: string; titulo: string; detalhe: string; sugestao?: string; acaoSugerida?: { acao: 'fechar' | 'abrir'; data: string }; precisaDecisao: boolean }
/** Alertas antecipados: feriados sem decisão, dias especiais, falta de intervalo, conflitos e oportunidades de reorganizar. */
export async function alertas(b: any, x: any, hoje: string, dias = 45): Promise<Alerta[]> {
  const cal = K.calendarioDe(x), out: Alerta[] = [], ate = K.addDays(hoje, dias), res = await ordersOf(Number(b.id), hoje, ate)
  const reservasEm = (d: string) => res.filter((r) => r.data === d)
  for (const f of K.proximosFeriados(hoje, dias, cal.feriadosProprios)) {
    const ef = K.diaEfetivo(x, f.data), md = f.data.slice(5), antes = cal.historico.filter((h) => h.nome === f.nome && h.data < f.data)
    const ate1 = Math.round((Date.parse(f.data + 'T12:00:00Z') - Date.parse(hoje + 'T12:00:00Z')) / 86400000), quando = ate1 === 0 ? 'hoje' : ate1 === 1 ? 'amanhã' : `em ${ate1} dias (${fmtData(f.data)})`
    const semanalFechado = !x.horarioCfg?.dias || !x.horarioCfg.dias[K.DIAS[new Date(f.data + 'T12:00:00Z').getUTCDay()]]?.ativo
    if (cal.decisoes[f.data] || cal.excecoes.some((e) => e.data === f.data)) { if (ef.origem !== 'semana') out.push({ tipo: 'feriado_aplicado', gravidade: 'info', data: f.data, titulo: `${f.nome} ${quando}: ${ef.aberto ? 'aberto' : 'fechado'}`, detalhe: ef.motivo, precisaDecisao: false }); continue }
    if (cal.decisoes[md] && cal.modo === 'automatico') { out.push({ tipo: 'feriado_aplicado', gravidade: 'info', data: f.data, titulo: `${f.nome} ${quando}: ${ef.aberto ? 'aberto' : 'fechado'} (regra recorrente que você autorizou)`, detalhe: ef.motivo, precisaDecisao: false }); continue }
    if (semanalFechado) continue
    const fechou = antes.filter((h) => h.acao === 'fechar').length, abriu = antes.filter((h) => h.acao === 'abrir' || h.acao === 'especial').length
    const sug = fechou > abriu ? `Nos anos anteriores você fechou no ${f.nome}. Quer fechar de novo?` : abriu > fechou ? `Nos anos anteriores você abriu no ${f.nome}. Quer abrir de novo?` : 'Quer abrir normalmente, fechar ou usar horário especial?'
    const n = reservasEm(f.data).length
    out.push({ tipo: 'decisao_feriado', gravidade: ate1 <= 7 ? 'alta' : 'media', data: f.data, titulo: `${f.nome} ${quando}: decisão pendente`, detalhe: `Hoje a empresa abriria normalmente (${ef.abre}–${ef.fecha}).${f.facultativo ? ' É ponto facultativo.' : ''}${n ? ` Já há ${n} agendamento(s) nesse dia.` : ''}`, sugestao: sug, acaoSugerida: fechou > abriu ? { acao: 'fechar', data: f.data } : { acao: 'abrir', data: f.data }, precisaDecisao: true })
  }
  for (let i = 0; i <= 14; i++) { const d = K.addDays(hoje, i), ef = K.diaEfetivo(x, d); if (ef.aberto && ef.origem !== 'semana' && !ef.feriado) out.push({ tipo: 'funcionamento_especial', gravidade: 'info', data: d, titulo: `Funcionamento especial em ${fmtData(d)}`, detalhe: `${ef.abre}–${ef.fecha}. ${ef.motivo}`, precisaDecisao: false }) }
  const longo = Object.values(x.horarioCfg?.dias || {}).some((d: any) => d?.ativo && K.toMin(d.fecha) - K.toMin(d.abre) >= 420)
  if (longo && !cal.intervalos.length) out.push({ tipo: 'sem_intervalo', gravidade: 'media', titulo: 'Nenhum intervalo de almoço/jantar cadastrado', detalhe: 'A agenda oferece horários durante todo o expediente, inclusive no horário de almoço.', sugestao: 'Diga o intervalo (ex.: "almoço das 12:00 às 13:00") para eu cadastrar.', precisaDecisao: true })
  for (const r of res) { // conflitos: reservas que ficaram em dia fechado, fora do expediente, em intervalo ou bloqueio
    const ef = K.diaEfetivo(x, r.data), s = K.toMin(r.hora), e = s + r.dur
    const bad = !ef.aberto ? 'o dia está fechado' : s < K.toMin(ef.abre!) || e > (K.toMin(ef.fecha!) > K.toMin(ef.abre!) ? K.toMin(ef.fecha!) : 1440) ? 'fica fora do expediente' : K.faixasIndisponiveis(ef).some(([a, z]) => s < z && e > a) ? 'cai em intervalo/bloqueio' : ''
    if (bad) out.push({ tipo: 'conflito', gravidade: 'alta', data: r.data, titulo: `Conflito: ${r.servico || 'agendamento'} ${fmtData(r.data)} às ${r.hora}`, detalhe: `Reserva #${r.id}: ${bad}.`, sugestao: 'Fale com o cliente para remarcar ou ajuste o calendário.', precisaDecisao: true })
  }
  for (let i = 0; i < 7; i++) { // oportunidades: janelas ociosas grandes entre reservas do mesmo dia
    const d = K.addDays(hoje, i), l = reservasEm(d).sort((a, c) => K.toMin(a.hora) - K.toMin(c.hora)), ef = K.diaEfetivo(x, d)
    for (let k = 0; k + 1 < l.length; k++) { const fim = K.toMin(l[k].hora) + l[k].dur, prox = K.toMin(l[k + 1].hora), pausa = ef.intervalos.reduce((a, it) => a + Math.max(0, Math.min(prox, K.toMin(it.fim)) - Math.max(fim, K.toMin(it.ini))), 0)
      if (prox - fim - pausa >= 120) out.push({ tipo: 'reorganizacao', gravidade: 'info', data: d, titulo: `Janela ociosa em ${fmtData(d)}`, detalhe: `${K.hhmm(fim)}–${K.hhmm(prox)} sem atendimento entre duas reservas.`, sugestao: 'Dá para oferecer esse horário em promoção ou propor ao cliente antecipar/adiar para compactar a agenda.', precisaDecisao: false }) }
  }
  return out.sort((a, c) => (a.data || '9').localeCompare(c.data || '9'))
}
const resumoCal = (x: any) => { const c = K.calendarioDe(x); return { modo: c.modo, intervalos: c.intervalos.map((i) => `${i.nome} ${i.ini}–${i.fim}`), excecoes: c.excecoes.length, bloqueios: c.bloqueios.length, feriadosProprios: c.feriadosProprios.length, passoMin: c.passoMin } }

export const AGENDA_TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'agenda_empresa_consultar', description: 'Consulta o funcionamento e os horários LIVRES reais de uma empresa do usuário em uma data (considera expediente, intervalos, feriados, exceções, bloqueios e reservas). Use antes de oferecer ou afirmar qualquer horário.', parameters: { type: 'object', properties: { empresa: { type: 'string' }, data: { type: 'string', description: 'AAAA-MM-DD' }, duracao_min: { type: 'number' }, servico: { type: 'string', description: 'nome do serviço (usa a duração dele)' } }, required: ['data'], additionalProperties: false } } },
  { type: 'function', function: { name: 'agenda_empresa_alertas', description: 'Lista alertas antecipados da agenda da empresa: feriados que pedem decisão, dias especiais, falta de intervalo, conflitos e oportunidades de reorganização.', parameters: { type: 'object', properties: { empresa: { type: 'string' }, dias: { type: 'number' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'agenda_empresa_decidir', description: 'Registra a decisão do DONO para uma data: abrir, fechar ou horário especial. Só chame quando o dono pedir explicitamente. Nunca cancela reservas; se houver reservas afetadas, mostre-as e só repita com confirmar=true depois que o dono confirmar. recorrente=true só se ele pedir "todos os anos".', parameters: { type: 'object', properties: { empresa: { type: 'string' }, data: { type: 'string', description: 'AAAA-MM-DD' }, acao: { type: 'string', enum: ['abrir', 'fechar', 'especial'] }, abre: { type: 'string', description: 'HH:MM (especial)' }, fecha: { type: 'string', description: 'HH:MM (especial)' }, motivo: { type: 'string' }, recorrente: { type: 'boolean' }, confirmar: { type: 'boolean' } }, required: ['data', 'acao'], additionalProperties: false } } },
  { type: 'function', function: { name: 'agenda_empresa_intervalo', description: 'Cadastra um intervalo (almoço, jantar…) no calendário da empresa quando o dono pedir.', parameters: { type: 'object', properties: { empresa: { type: 'string' }, nome: { type: 'string' }, inicio: { type: 'string', description: 'HH:MM' }, fim: { type: 'string', description: 'HH:MM' }, dias: { type: 'array', items: { type: 'number' }, description: '0=domingo … 6=sábado; vazio = todos os dias' } }, required: ['inicio', 'fim'], additionalProperties: false } } },
]
export const AGENDA_READ = new Set(['agenda_empresa_consultar', 'agenda_empresa_alertas'])
export const AGENDA_NAMES = new Set(AGENDA_TOOLS.map((t) => t.function.name))
/** Ferramentas e contexto só existem para quem tem empresa e com a capacidade ligada no painel. */
export async function agendaDisponivel(u: SessionUser) { return (await agendaIAOn()) && (await mine(u.id)).length > 0 }

async function save(bid: number, mut: (x: any) => void) {
  return withLock(`biz:${bid}`, async () => {
    const b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); if (!b) return null
    const x = J<any>(b.data, {}); mut(x)
    await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(x), nowIso(), bid]); return x
  })
}
export async function runAgendaTool(u: SessionUser, name: string, a: any, hoje: string): Promise<any> {
  if (!(await agendaIAOn())) return { ok: false, error: 'A capacidade Inteligência de Agenda está desligada pelo administrador.' }
  const p = pick(await mine(u.id), a.empresa); if (!p.e) return { ok: false, error: p.erro }
  const { b, x } = p.e, bid = Number(b.id), cal = K.calendarioDe(x)
  if (name === 'agenda_empresa_alertas') return { ok: true, empresa: x.empresa, modo: cal.modo, alertas: await alertas(b, x, hoje, Math.min(120, Math.max(7, Number(a.dias) || 45))) }
  if (name === 'agenda_empresa_consultar') {
    const data = String(a.data || ''); if (!dataOk(data)) return { ok: false, error: 'Data no formato AAAA-MM-DD.' }
    let dur = Math.round(Number(a.duracao_min) || 0), servico = ''
    if (a.servico) { const ps = (await q('SELECT data FROM products WHERE business_id = $1', [bid])).map((r) => J<any>(r.data, {})).filter((s) => s.tipo === 'servico' && nrm(s.nome).includes(nrm(a.servico))); if (ps[0]) { dur = Number(ps[0].duracao) || 30; servico = ps[0].nome } }
    if (!dur) dur = 30
    const { freeSlots, bookedRanges } = await import('../routes/businesses.js'), ef = K.diaEfetivo(x, data)
    const livres = await freeSlots(b, { duracao: dur }, data), ocupados = (await bookedRanges(b, data)).map(([s, e]) => `${K.hhmm(s)}–${K.hhmm(e)}`)
    return { ok: true, empresa: x.empresa, data, diaSemana: ef.diaSemana, aberto: ef.aberto, funcionamento: ef.aberto ? `${ef.abre}–${ef.fecha}` : 'fechado', origem: ef.origem, motivo: ef.motivo, feriado: ef.feriado ? `${ef.feriado.nome} (${ef.feriado.nivel})` : null, intervalos: ef.intervalos, bloqueios: ef.bloqueios, duracaoMin: dur, servico: servico || undefined, horariosLivres: livres, reservadosOuOcupados: ocupados,
      aviso: 'Ofereça SOMENTE os horários de horariosLivres; eles já respeitam fechamento, intervalos, bloqueios e reservas.' }
  }
  // alterações: só o dono, nunca no modo manual
  if (cal.modo === 'manual') return { ok: false, error: `O calendário de ${x.empresa} está no modo MANUAL: eu só consulto e sugiro. Para eu poder alterar, o dono escolhe "Inteligente" ou "Automático" em Sua empresa → Ajustes → Calendário e funcionamento.` }
  if (name === 'agenda_empresa_intervalo') {
    const ini = String(a.inicio || ''), fim = String(a.fim || ''), nm = String(a.nome || 'Intervalo').slice(0, 40)
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(ini) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(fim) || K.toMin(fim) <= K.toMin(ini)) return { ok: false, error: 'Horários inválidos (use HH:MM e fim depois do início).' }
    const dias = Array.isArray(a.dias) ? a.dias.map(Number).filter((n: number) => n >= 0 && n <= 6) : []
    const x2 = await save(bid, (xx) => { const c = K.calendarioDe(xx); c.intervalos = [...c.intervalos.filter((i) => !(i.nome === nm && i.ini === ini)), { id: Math.random().toString(36).slice(2, 9), nome: nm, ini, fim, dias: dias.length ? dias : null }]; xx.calendario = c })
    return { ok: true, empresa: x.empresa, intervalos: K.calendarioDe(x2).intervalos.map((i) => `${i.nome} ${i.ini}–${i.fim}`), aviso: 'A agenda já deixa de oferecer horários nesse intervalo. Reservas existentes não foram alteradas.' }
  }
  if (name === 'agenda_empresa_decidir') {
    const data = String(a.data || ''); if (!dataOk(data)) return { ok: false, error: 'Data no formato AAAA-MM-DD.' }
    if (data < hoje) return { ok: false, error: 'Essa data já passou.' }
    const acao = String(a.acao); if (!['abrir', 'fechar', 'especial'].includes(acao)) return { ok: false, error: 'Ação inválida.' }
    const abre = String(a.abre || ''), fecha = String(a.fecha || '')
    if (acao === 'especial' && !(/^([01]\d|2[0-3]):[0-5]\d$/.test(abre) && /^([01]\d|2[0-3]):[0-5]\d$/.test(fecha) && K.toMin(fecha) > K.toMin(abre))) return { ok: false, error: 'Para horário especial informe abre e fecha (HH:MM).' }
    const novo = { ...x, calendario: { ...cal, decisoes: { ...cal.decisoes, [data]: { acao, abre: acao === 'especial' ? abre : undefined, fecha: acao === 'especial' ? fecha : undefined } } } }
    const afetadas = (await ordersOf(bid, data, data)).filter((r) => { const ef = K.diaEfetivo(novo, data), s = K.toMin(r.hora), e = s + r.dur; return !ef.aberto || s < K.toMin(ef.abre!) || e > K.toMin(ef.fecha!) })
    if (afetadas.length && a.confirmar !== true) return { ok: false, precisaConfirmar: true, reservasAfetadas: afetadas.map((r) => ({ id: r.id, hora: r.hora, servico: r.servico })), aviso: 'Existem reservas nesse dia que ficariam em conflito. Mostre-as ao dono; eu NÃO cancelo reservas. Se ele confirmar mesmo assim, repita com confirmar=true e avise que ele precisa falar com esses clientes.' }
    const fer = K.feriadoDe(data, cal.feriadosProprios), recorrente = a.recorrente === true && cal.modo === 'automatico' && !!fer
    await save(bid, (xx) => {
      const c = K.calendarioDe(xx), key = recorrente ? data.slice(5) : data
      c.decisoes[key] = { acao: acao as any, abre: acao === 'especial' ? abre : undefined, fecha: acao === 'especial' ? fecha : undefined, recorrente, em: nowIso(), por: 'dono-via-chat', motivo: String(a.motivo || '').slice(0, 80) || undefined }
      c.historico = [...c.historico, { data, nome: fer?.nome || 'Data especial', acao, em: nowIso(), por: 'dono' }].slice(-80); xx.calendario = c
    })
    const ef = K.diaEfetivo(calendarioNovo(await one('SELECT data FROM businesses WHERE id = $1', [bid])), data)
    return { ok: true, empresa: x.empresa, data, resultado: ef.aberto ? `Aberto ${ef.abre}–${ef.fecha}` : 'Fechado', recorrente, aviso: (a.recorrente && !recorrente ? 'Só o modo Automático permite regra recorrente; salvei apenas para esta data. ' : '') + (afetadas.length ? 'Reservas afetadas continuam registradas: o dono precisa avisar os clientes.' : '') }
  }
  return { ok: false, error: 'Ferramenta desconhecida.' }
}
const calendarioNovo = (row: any) => J<any>(row?.data, {})

/** Contexto para a IA do chat: só quando a conversa é sobre agenda empresarial e o usuário tem empresa. */
export async function agendaContext(u: SessionUser, text: string, hoje: string) {
  if (!isAgendaIAQuery(text) || !(await agendaIAOn())) return ''
  const emp = await mine(u.id); if (!emp.length) return ''
  const linhas = emp.slice(0, 5).map(({ x }) => { const c = resumoCal(x); const fer = K.proximosFeriados(hoje, 30, K.calendarioDe(x).feriadosProprios).slice(0, 4).map((f) => `${f.nome} ${fmtData(f.data)}`).join(', ') || 'nenhum'; return `- ${x.empresa}: modo ${c.modo}; intervalos: ${c.intervalos.join('; ') || 'nenhum cadastrado'}; feriados nos próximos 30 dias: ${fer}.` })
  return ['INTELIGÊNCIA DE AGENDA (empresas do usuário):', ...linhas,
    'Regras: para disponibilidade use SEMPRE agenda_empresa_consultar (nunca calcule de cabeça) e ofereça só os horários que ela devolver; nunca ultrapasse o fechamento, atravesse intervalo ou conflite com reserva.',
    'Feriados: sugira, nunca decida sozinho. Só use agenda_empresa_decidir/intervalo quando o dono pedir de forma explícita e o modo não for manual; nunca cancele reservas; sugestões não viram regra permanente sem autorização dele.'].join('\n')
}
/** Resumo do calendário para o agente que atende os CLIENTES da empresa (somente leitura). */
export function calendarioParaAgente(x: any, hoje: string) {
  const c = K.calendarioDe(x), ef = K.diaEfetivo(x, hoje), partes: string[] = []
  if (c.intervalos.length) partes.push('Intervalos (sem atendimento): ' + c.intervalos.map((i) => `${i.nome} ${i.ini}–${i.fim}`).join('; '))
  const prox = K.proximosFeriados(hoje, 14, c.feriadosProprios).map((f) => { const e = K.diaEfetivo(x, f.data); return `${f.nome} ${fmtData(f.data)}: ${e.aberto ? `aberto ${e.abre}–${e.fecha}` : 'fechado'}` })
  if (prox.length) partes.push('Feriados nos próximos 14 dias: ' + prox.join('; '))
  if (ef.origem !== 'semana') partes.push(`Hoje: ${ef.motivo}.`)
  return partes.join(' ')
}
let lastTick = 0
/** Agendador: avisa o dono (uma vez por data) dos feriados e conflitos. Só empresas em modo inteligente/automático. Nunca altera nada. */
export async function tickAgendaIA(now = new Date()) {
  if (Date.now() - lastTick < 6 * 3600_000 || !(await agendaIAOn())) return 0
  lastTick = Date.now(); let n = 0
  const hoje = new Date(now.getTime() - 3 * 3600_000).toISOString().slice(0, 10)
  for (const b of await q("SELECT * FROM businesses WHERE status = 'ativo'")) {
    const x = J<any>(b.data, {}); if (K.calendarioDe(x).modo === 'manual') continue
    for (const al of await alertas(b, x, hoje, 21)) {
      if (!(al.tipo === 'conflito' || (al.tipo === 'decisao_feriado' && al.precisaDecisao))) continue
      await notify(Number(b.owner_id), { type: 'agenda', title: `${x.empresa}: ${al.titulo}`, body: [al.detalhe, al.sugestao].filter(Boolean).join(' '), link: '/x/sua-empresa', ref: `agenda-ia:${b.id}:${al.tipo}:${al.data || 'geral'}` }); n++
    }
  }
  return n
}
export const _resetTick = () => { lastTick = 0 }
export { resumoCal }
