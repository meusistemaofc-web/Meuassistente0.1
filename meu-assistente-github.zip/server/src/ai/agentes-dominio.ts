// FASE 10 — Arquitetura multiagente colaborativa (evolução da Fase 4, sem substituir nada).
// O agente principal continua sendo a interface com o usuário; o coordenador da Fase 4 (agentes.orquestrar) passou a contar com
// 7 AGENTES ESPECIALIZADOS DE DOMÍNIO — Comercial, Agendamentos, CRM, Financeiro, Administrativo, Marketing e Análise e Inteligência.
// Cada um reúne e analisa os dados do PRÓPRIO usuário/empresa pelos serviços que já existem (BI, CRM, agenda, finanças,
// solicitações, marketing, previsões da Fase 7, execuções da Fase 8) — de forma determinística, sem chamada de IA. Quando o pedido é
// complexo, os agentes de raciocínio com IA da Fase 4 (análise, vendas, planejamento, escrita, pesquisa) recebem esses achados,
// cada um só a fatia que pode ver. Situações complexas e decisórias passam por VALIDAÇÃO (proposta → crítica → verificação de dados
// → avaliação do coordenador), uma única rodada. Ações sugeridas pelos agentes seguem o nível de autonomia configurado (1 a 4) e
// SEMPRE pelo motor de execução da Fase 8 (níveis de confirmação/autorização, reversão e auditoria preservados).
import { createHash } from 'node:crypto'
import { getConfig } from '../lib/settings.js'
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import type { Exec } from './execucao.js'
import type { Montado } from './execucao-planos.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const brl = (n: number) => 'R$ ' + (Math.round(Number(n || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const addDias = (d: string, n: number) => { const x = new Date(d + 'T12:00:00Z'); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10) }
/** Lê um campo de um erro de origem desconhecida (catch) sem `any`: equivale a `e?.campo`. */
function campoErro(e: unknown, k: string): unknown { return typeof e === 'object' && e !== null && k in e ? (e as Record<string, unknown>)[k] : undefined }
const msgErro = (e: unknown, max: number) => String(campoErro(e, 'message') || e).slice(0, max)
const prazo = <T>(p: Promise<T>, ms: number) => Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(Object.assign(new Error('tempo esgotado'), { code: 'timeout' })), ms))])

/* ======================= catálogo ======================= */
export type Escopo = 'agenda_pessoal' | 'financas_pessoais' | 'empresa_vendas' | 'empresa_pedidos' | 'empresa_agenda' | 'crm' | 'marketing' | 'previsoes' | 'execucoes'
export const ESCOPO_NOME: Record<Escopo, string> = { agenda_pessoal: 'Agenda e tarefas pessoais', financas_pessoais: 'Finanças pessoais e contas', empresa_vendas: 'Vendas e faturamento da empresa', empresa_pedidos: 'Pedidos e operação da empresa', empresa_agenda: 'Agendamentos e solicitações da empresa', crm: 'CRM (clientes, leads, oportunidades)', marketing: 'Campanhas, consentimentos e cupons', previsoes: 'Previsões (Fase 7)', execucoes: 'Execuções automáticas (Fase 8)' }
export interface Coleta { fatos: string[]; sugestoes: { objetivo: string; motivo: string }[]; empresa?: number | null }
export interface Ctx { u: SessionUser; hoje: string; empresas: { id: number; nome: string }[]; pode: (e: Escopo) => boolean }
export interface AgenteDominio { id: string; nome: string; especialidade: string; responsabilidades: string[]; gatilho: RegExp; dominiosN2: string[]; perfilIA: string | null; escopos: Escopo[]; acoes: string[]; coletar: (c: Ctx) => Promise<Coleta | null> }

/* ---- formatos lidos do banco (colunas usadas + campos do JSON `data` que este módulo consulta) ---- */
interface ItemDados { time?: string; reminders?: unknown[]; kind?: string; amount?: number | string; dueDate?: string; due_date?: string }
type ItemRow = { id: number | string; day: string | null; status: string | null; data: unknown }
interface PedidoDados { tipo?: string; data?: string; pagamento?: string; pago?: boolean }
type PedidoRow = { status: string; data: unknown; created_at: string; updated_at?: string | null }
type StatusRow = { status: string }
type CampanhaRow = { status: string; enviados: number | string | null; cliques: number | string | null }
type CupomRow = { used_count: number | string | null; status: string; ends_at: string | null }
type EmpresaRow = { id: number | string; data: unknown }
type IdRow = { id: number | string }
type ContagemRow = { n: number | string }
type TarefaRow = { dominios: unknown; achados: unknown; decisoes: unknown; created_at: string }
/** Decisão registrada em agent_tasks.decisoes (o texto é o que vira memória compartilhada). */
export interface DecisaoTarefa { tipo?: string; texto?: string; [extra: string]: unknown }
/** Etapa registrada em agent_tasks.etapas (coleta, raciocínio, validação, consolidação). */
export interface EtapaTarefa { id: string; agente: string; tipo: string; depende: string[]; status: string; ms?: number; motivo?: string; [extra: string]: unknown }
interface AcaoRegistrada { agente: string; objetivo: string; autonomia: number; execucao?: Exec['id']; status?: string; erro?: string }

async function empresaResumo(c: Ctx, bid: number) { const B = await import('../lib/bi.js'); return B.resumo(c.u.id, bid, { periodo: 'mes' }) }
const itens = async (uid: number, tipo: string, extra = '', args: string[] = []) => (await q<ItemRow>(`SELECT id, day, status, data FROM items WHERE user_id = $1 AND type = $2 ${extra}`, [uid, tipo, ...args])).map((r) => ({ id: Number(r.id), day: r.day, status: r.status, ...J<ItemDados>(r.data, {}) }))
const ENCERRADO = ['cancelled', 'done']

export const DOMINIO: AgenteDominio[] = [
  { id: 'comercial', nome: 'Agente Comercial', especialidade: 'Vendas, oportunidades e produtos', responsabilidades: ['Atendimento de clientes', 'Identificação de oportunidades', 'Apresentação de produtos e serviços', 'Acompanhamento de vendas', 'Sugestões comerciais'],
    gatilho: /\b(vend\w*|faturamento|fatur\w*|pedidos?|ticket|produtos? (mais|que mais)|mais vendid\w*|oportunidad\w*|propostas?|comercia\w*|loja)\b/, dominiosN2: ['negocio'], perfilIA: 'vendas', escopos: ['empresa_vendas'], acoes: [],
    coletar: async (c) => {
      if (!c.pode('empresa_vendas') || !c.empresas.length) return null
      const fatos: string[] = []
      for (const e of c.empresas) {
        const r = await empresaResumo(c, e.id)
        fatos.push(`${e.nome} (${r.periodo.label}): faturamento ${brl(r.vendas.faturamento)} em ${r.vendas.vendasPagas} venda(s) paga(s); ticket médio ${r.vendas.ticketMedio != null ? brl(r.vendas.ticketMedio) : '—'}; pendente ${brl(r.vendas.pendente)}; cancelado ${brl(r.vendas.cancelado)}.`)
        fatos.push(`${e.nome}: pedidos ${r.pedidos.total} (${r.pedidos.pendentes} em aberto, ${r.pedidos.concluidos} concluídos); agendamentos ${r.agendamentos.total}.`)
        const top = [...(r.produtos.topProdutos || []), ...(r.produtos.topServicos || [])].slice(0, 3)
        if (top.length) fatos.push(`${e.nome}: mais pedidos — ${top.map((p) => `${p.nome} (${p.qtd}×)`).join(', ')}.`)
        if (r.semMovimento) fatos.push(`${e.nome}: sem movimento no período.`)
      }
      return { fatos, sugestoes: [] }
    } },
  { id: 'agendamentos', nome: 'Agente de Agendamentos', especialidade: 'Disponibilidade, solicitações, conflitos e aprovações', responsabilidades: ['Consultar disponibilidades', 'Criar solicitações', 'Verificar conflitos', 'Administrar aprovações', 'Gerenciar alterações e cancelamentos'],
    gatilho: /\b(agend\w*|agenda|compromissos?|horarios?|disponibilidade|reserv\w*|solicitac\w*|aprovac\w*|remarc\w*|conflit\w*)\b/, dominiosN2: ['agenda', 'agenda_empresa', 'tarefas'], perfilIA: null, escopos: ['agenda_pessoal', 'empresa_agenda'], acoes: ['lembretes_compromissos', 'concluir_passados'],
    coletar: async (c) => {
      const fatos: string[] = [], sugestoes: Coleta['sugestoes'] = []
      if (c.pode('agenda_pessoal')) {
        const prox = (await itens(c.u.id, 'appointment', 'AND day >= $3 AND day <= $4', [c.hoje, addDias(c.hoje, 7)])).filter((a) => !ENCERRADO.includes(a.status ?? ''))
        const semLembrete = prox.filter((a) => !(a.reminders || []).length)
        const porHora = new Map<string, number>(); for (const a of prox) if (a.time) porHora.set(`${a.day} ${a.time}`, (porHora.get(`${a.day} ${a.time}`) || 0) + 1)
        const conflitos = [...porHora.values()].filter((n) => n > 1).length
        const passados = (await itens(c.u.id, 'appointment', 'AND day < $3 AND day >= $4', [c.hoje, addDias(c.hoje, -60)])).filter((a) => !ENCERRADO.includes(a.status ?? '')).length
        fatos.push(`Agenda pessoal: ${prox.length} compromisso(s) nos próximos 7 dias${semLembrete.length ? `, ${semLembrete.length} sem lembrete` : ''}${conflitos ? `, ${conflitos} horário(s) com conflito` : ''}; ${passados} compromisso(s) passado(s) ainda em aberto.`)
        if (semLembrete.length) sugestoes.push({ objetivo: 'lembretes_compromissos', motivo: `${semLembrete.length} compromisso(s) da semana sem lembrete` })
        if (passados) sugestoes.push({ objetivo: 'concluir_passados', motivo: `${passados} compromisso(s) passado(s) em aberto` })
      }
      if (c.pode('empresa_agenda')) for (const e of c.empresas) {
        const rows = (await q<PedidoRow>("SELECT status, data, created_at FROM orders WHERE business_id = $1 AND status IN ('novo','aceito','aguardando_aprovacao','sugestao')", [e.id])).map((r) => ({ st: r.status, em: r.created_at, ...J<PedidoDados>(r.data, {}) })).filter((o) => o.tipo === 'agendamento')
        const sol = rows.filter((o) => o.st === 'aguardando_aprovacao'), sug = rows.filter((o) => o.st === 'sugestao'), conf = rows.filter((o) => o.st === 'aceito' && !!o.data && o.data >= c.hoje && o.data <= addDias(c.hoje, 7)), novos = rows.filter((o) => o.st === 'novo')
        const antiga = sol.length ? Math.round((Date.now() - Math.min(...sol.map((o) => Date.parse(o.em)))) / 3600e3) : 0
        fatos.push(`${e.nome}: ${conf.length} agendamento(s) confirmado(s) nos próximos 7 dias; ${novos.length} aguardando confirmação; ${sol.length} solicitação(ões) aguardando aprovação${sol.length ? ` (a mais antiga há ${antiga} h)` : ''}; ${sug.length} com novo horário sugerido aguardando o cliente.`)
      }
      return fatos.length ? { fatos, sugestoes } : null
    } },
  { id: 'crm', nome: 'Agente CRM', especialidade: 'Clientes, histórico de relacionamento e retornos', responsabilidades: ['Organizar informações de clientes', 'Identificar histórico de relacionamento', 'Acompanhar oportunidades', 'Detectar clientes que precisam de retorno'],
    gatilho: /\b(crm|clientes?|leads?|funil|relacionamento|retornos?|follow ?up|fideliz\w*|recorrent\w*|inativ\w*)\b/, dominiosN2: ['crm'], perfilIA: null, escopos: ['crm'], acoes: ['crm_acompanhamento'],
    coletar: async (c) => {
      if (!c.pode('crm') || !c.empresas.length) return null
      const fatos: string[] = [], sugestoes: Coleta['sugestoes'] = [], C = await import('../lib/crm.js')
      for (const e of c.empresas) {
        try {
          await C.acesso(c.u.id, e.id); const A = await C.CommercialIntelligenceService.analise(e.id)
          const n = (x: readonly unknown[] | null | undefined) => (x || []).length, nomes = (x: readonly { nome?: string | null; titulo?: string | null }[] | null | undefined) => (x || []).slice(0, 3).map((y) => y.nome || y.titulo).filter(Boolean).join(', ')
          fatos.push(`${e.nome}: ${n(A.leadsSemAcompanhamento)} lead(s) sem acompanhamento${n(A.leadsSemAcompanhamento) ? ` (${nomes(A.leadsSemAcompanhamento)})` : ''}; ${n(A.clientesParaRetorno)} cliente(s) pedindo retorno${n(A.clientesParaRetorno) ? ` (${nomes(A.clientesParaRetorno)})` : ''}; ${n(A.oportunidadesParadas)} oportunidade(s) parada(s); ${n(A.clientesRecorrentes)} cliente(s) recorrente(s).`)
          if (n(A.leadsSemAcompanhamento) + n(A.clientesParaRetorno) + n(A.oportunidadesParadas)) sugestoes.push({ objetivo: 'crm_acompanhamento', motivo: 'leads, clientes ou oportunidades sem acompanhamento' })
        } catch { /* sem CRM nessa empresa (plano/permissão) */ }
      }
      return fatos.length ? { fatos, sugestoes } : null
    } },
  { id: 'financeiro', nome: 'Agente Financeiro', especialidade: 'Valores, pagamentos, pendências e relatórios', responsabilidades: ['Analisar dados financeiros autorizados', 'Acompanhar pagamentos', 'Identificar pendências', 'Gerar relatórios', 'Auxiliar na organização financeira'],
    gatilho: /\b(financ\w*|gast\w*|despes\w*|receit\w*|pagament\w*|pagar|pagas?|contas?|saldo|dinheiro|caixa|lucro|margem|pendenc\w*|cobranc\w*|inadimpl\w*|faturamento|orcamento)\b/, dominiosN2: ['financas', 'negocio'], perfilIA: null, escopos: ['financas_pessoais', 'empresa_vendas'], acoes: ['relatorio_financeiro'],
    coletar: async (c) => {
      const fatos: string[] = [], sugestoes: Coleta['sugestoes'] = []
      if (c.pode('financas_pessoais')) {
        const m = c.hoje.slice(0, 7), mov = await itens(c.u.id, 'expense', 'AND day >= $3', [m + '-01'])
        const gasto = mov.filter((x) => x.kind === 'expense').reduce<number>((a, x) => a + (Number(x.amount) || 0), 0), receita = mov.filter((x) => x.kind === 'income').reduce<number>((a, x) => a + (Number(x.amount) || 0), 0)
        const contas = await itens(c.u.id, 'bill', "AND status = 'pending'"), vencidas = contas.filter((b) => b.day && b.day < c.hoje), semana = contas.filter((b) => b.day && b.day >= c.hoje && b.day <= addDias(c.hoje, 7))
        const soma = (x: readonly ItemDados[]) => x.reduce<number>((a, b) => a + (Number(b.amount) || 0), 0)
        fatos.push(`Finanças do mês (${m}): receitas ${brl(receita)}, despesas ${brl(gasto)}, saldo ${brl(receita - gasto)} em ${mov.length} lançamento(s).`)
        fatos.push(`Contas a pagar: ${contas.length} pendente(s); ${vencidas.length} vencida(s)${vencidas.length ? ` somando ${brl(soma(vencidas))}` : ''}; ${semana.length} vencendo em 7 dias${semana.length ? ` (${brl(soma(semana))})` : ''}.`)
        if (mov.length >= 3) sugestoes.push({ objetivo: 'relatorio_financeiro', motivo: 'há lançamentos suficientes no mês para um relatório' })
      }
      if (c.pode('empresa_vendas')) for (const e of c.empresas) {
        const r = await empresaResumo(c, e.id)
        const online = (await q<Pick<PedidoRow, 'data' | 'status'>>("SELECT data, status FROM orders WHERE business_id = $1 AND status NOT IN ('cancelado','recusado')", [e.id])).map((x) => J<PedidoDados>(x.data, {})).filter((d) => d.pagamento === 'online' && !d.pago).length
        fatos.push(`${e.nome}: recebido ${brl(r.vendas.faturamento)}; a receber ${brl(r.vendas.pendente)}; ${online} Pix online aguardando pagamento.`)
      }
      return fatos.length ? { fatos, sugestoes } : null
    } },
  { id: 'administrativo', nome: 'Agente Administrativo', especialidade: 'Operação, inconsistências e processos', responsabilidades: ['Monitorar operações', 'Identificar inconsistências', 'Organizar processos', 'Auxiliar na gestão da empresa'],
    gatilho: /\b(operac\w*|gest\w*|administr\w*|processos?|inconsistenc\w*|atras\w*|parad\w*|gargal\w*|monitor\w*|pendencias?|organiz\w*|rotina|o que (falta|esta parado|ta parado))\b/, dominiosN2: ['tarefas'], perfilIA: null, escopos: ['empresa_pedidos', 'agenda_pessoal', 'execucoes'], acoes: ['organizar_semana'],
    coletar: async (c) => {
      const fatos: string[] = [], sugestoes: Coleta['sugestoes'] = []
      if (c.pode('empresa_pedidos')) for (const e of c.empresas) {
        const rows = (await q<PedidoRow>("SELECT status, data, created_at, updated_at FROM orders WHERE business_id = $1 AND status IN ('novo','aceito','preparo','aguardando_aprovacao')", [e.id])).map((r) => ({ st: r.status, em: Date.parse(r.created_at), at: Date.parse(r.updated_at || r.created_at), ...J<PedidoDados>(r.data, {}) }))
        const h = (x: number) => (Date.now() - x) / 3600e3
        const semDecisao = rows.filter((o) => o.st === 'novo' && h(o.em) > 0.5 && !(o.pagamento === 'online' && !o.pago)).length
        const aceitosVelhos = rows.filter((o) => ['aceito', 'preparo'].includes(o.st) && o.tipo !== 'agendamento' && h(o.at) > 48).length
        const agPassados = rows.filter((o) => o.st === 'aceito' && o.tipo === 'agendamento' && o.data && o.data < c.hoje).length
        const solVelhas = rows.filter((o) => o.st === 'aguardando_aprovacao' && h(o.em) > 24).length
        const inc = semDecisao + aceitosVelhos + agPassados + solVelhas
        fatos.push(`${e.nome}: ${inc ? `${inc} ponto(s) de atenção` : 'operação sem pendências fora do prazo'}${semDecisao ? ` · ${semDecisao} pedido(s) novo(s) sem decisão há mais de 30 min` : ''}${aceitosVelhos ? ` · ${aceitosVelhos} pedido(s) aceito(s) há mais de 2 dias sem concluir` : ''}${agPassados ? ` · ${agPassados} agendamento(s) passado(s) não concluído(s)` : ''}${solVelhas ? ` · ${solVelhas} solicitação(ões) aguardando aprovação há mais de 24 h` : ''}.`)
      }
      if (c.pode('agenda_pessoal')) {
        const atrasadas = (await itens(c.u.id, 'task', "AND (status IS NULL OR status <> 'done')")).filter((t) => (t.dueDate || t.due_date || t.day) && String(t.dueDate || t.due_date || t.day) < c.hoje).length
        fatos.push(`Tarefas pessoais atrasadas: ${atrasadas}.`)
        if (atrasadas >= 2) sugestoes.push({ objetivo: 'organizar_semana', motivo: `${atrasadas} tarefa(s) atrasada(s)` })
      }
      if (c.pode('execucoes')) {
        const ex = await q<StatusRow>("SELECT status FROM executions WHERE user_id = $1 AND created_at >= $2", [c.u.id, new Date(Date.now() - 7 * 864e5).toISOString()]).catch((): StatusRow[] => [])
        const pend = ex.filter((x) => /^aguardando/.test(x.status)).length, falhas = ex.filter((x) => ['falhou', 'parcial', 'interrompida'].includes(x.status)).length
        if (pend || falhas) fatos.push(`Execuções automáticas (7 dias): ${pend} aguardando aprovação; ${falhas} com falha ou concluída em parte.`)
      }
      return fatos.length ? { fatos, sugestoes } : null
    } },
  { id: 'marketing', nome: 'Agente de Marketing', especialidade: 'Campanhas, desempenho e divulgação', responsabilidades: ['Criar campanhas', 'Analisar desempenho', 'Sugerir estratégias', 'Produzir conteúdos', 'Identificar oportunidades de divulgação'],
    gatilho: /\b(marketing|campanh\w*|divulg\w*|promoc\w*|anunci\w*|redes sociais|instagram|post\w*|conteudos?|cupo(m|ns)|publico|engajamento|alcance)\b/, dominiosN2: ['negocio'], perfilIA: 'escrita', escopos: ['marketing'], acoes: [],
    coletar: async (c) => {
      if (!c.pode('marketing') || !c.empresas.length) return null
      const fatos: string[] = []
      const cons = Number((await one<ContagemRow>("SELECT COUNT(*) AS n FROM marketing_consents WHERE owner_id = $1 AND status = 'ativo'", [c.u.id]).catch(() => null))?.n || 0)
      const camp = await q<CampanhaRow>('SELECT status, enviados, cliques FROM mkt_campaigns WHERE owner_id = $1 AND criada_em >= $2', [c.u.id, new Date(Date.now() - 30 * 864e5).toISOString()]).catch((): CampanhaRow[] => [])
      const env = camp.reduce((a: number, x) => a + Number(x.enviados || 0), 0), cli = camp.reduce((a: number, x) => a + Number(x.cliques || 0), 0)
      fatos.push(`Marketing: ${cons} cliente(s) autorizaram receber ofertas; ${camp.length} campanha(s) nos últimos 30 dias, ${env} envio(s) e ${cli} clique(s)${env ? ` (taxa de clique ${Math.round((cli / env) * 100)}%)` : ''}.`)
      for (const e of c.empresas) {
        const cp = await q<CupomRow>("SELECT used_count, status, ends_at FROM coupons WHERE business_id = $1", [e.id]).catch((): CupomRow[] => [])
        const ativos = cp.filter((x) => x.status === 'ativo' && (!x.ends_at || Date.parse(x.ends_at) > Date.now())).length
        fatos.push(`${e.nome}: ${ativos} cupom(ns) ativo(s); ${cp.reduce((a: number, x) => a + Number(x.used_count || 0), 0)} uso(s) no total.`)
      }
      return { fatos, sugestoes: [] }
    } },
  { id: 'inteligencia', nome: 'Agente de Análise e Inteligência', especialidade: 'Padrões, cruzamentos e antecipação', responsabilidades: ['Cruzar informações autorizadas', 'Identificar padrões', 'Produzir análises', 'Antecipar necessidades', 'Apoiar decisões estratégicas'],
    gatilho: /\b(analis\w*|padro(es|ao)|tendenc\w*|prev\w*|antecip\w*|estrateg\w*|decis\w*|decid\w*|cenario\w*|insights?|cruz\w*|diagnostic\w*|vale a pena)\b/, dominiosN2: [], perfilIA: 'analise', escopos: ['previsoes'], acoes: [],
    coletar: async (c) => {
      if (!c.pode('previsoes')) return null
      const r = await (await import('./preditivo-servico.js')).paraUsuario(c.u, { registrar: false }).catch(() => null)
      if (!r?.ativo || !r.sinais?.length) return { fatos: ['Previsões: nenhum sinal relevante agora (ou inteligência preditiva desligada).'], sugestoes: [] }
      return { fatos: r.sinais.slice(0, 5).map((s) => `${s.natureza === 'fato' ? 'FATO' : `ESTIMATIVA (${s.confianca}%)`}: ${s.titulo} — base: ${s.base}`), sugestoes: [] }
    } },
]
export const IDS_DOMINIO = DOMINIO.map((a) => a.id)
/** Que achados de domínio cada agente de RACIOCÍNIO (IA, Fase 4) pode ver — compartilhamento mínimo necessário. */
export const ACESSO_ACHADOS: Record<string, string[]> = {
  analise: IDS_DOMINIO, revisor: IDS_DOMINIO,
  vendas: ['comercial', 'financeiro', 'crm', 'marketing', 'inteligencia'],
  planejamento: ['agendamentos', 'administrativo', 'crm', 'financeiro', 'inteligencia'],
  escrita: ['marketing', 'agendamentos', 'crm'], // nunca vê valores financeiros
  pesquisa: [], // nunca vê dados do usuário
}

/* ======================= configuração (chave 'multiagente', compartilhada com a Fase 4) ======================= */
export const AUTONOMIA_NOME: Record<number, string> = { 1: 'Analisa e recomenda', 2: 'Prepara ações para aprovação', 3: 'Executa ações autorizadas', 4: 'Coordena operações completas dentro dos limites' }
export const F10_DEFAULT = {
  dominio: Object.fromEntries(IDS_DOMINIO.map((id) => [id, true])) as Record<string, boolean>,
  autonomia: Object.fromEntries(IDS_DOMINIO.map((id) => [id, 1])) as Record<string, number>,
  permissoes: {} as Record<string, Escopo[]>, // restrição por agente (nunca amplia além do padrão)
  debate: true,
  limites: { maxDominio: 4, maxChamadasIA: 4, diarioPorUsuario: 40, maxPassosN4: 20, coletaMs: 2500 },
  empresas: {} as Record<string, { agentes?: Record<string, boolean>; autonomiaMax?: number }>,
}
/** Formato salvo na chave 'multiagente' (compartilhada com a Fase 4, que guarda ali também agentesIA, maxAgentes, tempoMaxMs…). */
export interface F10Salvo { ativo?: boolean; debate?: boolean; dominio?: Record<string, boolean>; autonomia?: Record<string, number>; permissoes?: Record<string, Escopo[]>; limites?: Partial<LimitesF10>; empresas?: Record<string, EmpresaF10>; [outra: string]: unknown }
export type LimitesF10 = typeof F10_DEFAULT.limites
export type EmpresaF10 = { agentes?: Record<string, boolean>; autonomiaMax?: number }
/** Configuração efetiva (padrões + o que o administrador salvou). */
export type F10Cfg = Omit<typeof F10_DEFAULT, 'empresas'> & { empresas: Record<string, EmpresaF10>; ativo: boolean }
/** Alterações aceitas por validarF10 (a rota completa com ativo/agentesIA/maxAgentes/tempoMaxMs). */
export interface F10Patch { dominio?: Record<string, boolean>; autonomia?: Record<string, number>; permissoes?: Record<string, Escopo[]>; debate?: boolean; limites?: LimitesF10; [outra: string]: unknown }
export async function f10Cfg(): Promise<F10Cfg & F10Salvo> {
  const c = await getConfig<F10Salvo>('multiagente', {})
  return { ...F10_DEFAULT, ...c, dominio: { ...F10_DEFAULT.dominio, ...(c.dominio || {}) }, autonomia: { ...F10_DEFAULT.autonomia, ...(c.autonomia || {}) }, permissoes: { ...(c.permissoes || {}) }, limites: { ...F10_DEFAULT.limites, ...(c.limites || {}) }, empresas: { ...(c.empresas || {}) }, debate: c.debate !== false, ativo: c.ativo !== false }
}
/* ---- validação do que o administrador enviou (lista fechada). Erros viram 400 na rota. ---- */
const ehObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
function erro400(m: string): never { throw Object.assign(new Error(m), { status: 400 }) }
const NIVEIS_AUTONOMIA = [1, 2, 3, 4]
const FAIXA_LIMITES: Record<keyof LimitesF10, [number, number]> = { maxDominio: [1, 7], maxChamadasIA: [1, 8], diarioPorUsuario: [1, 1000], maxPassosN4: [1, 50], coletaMs: [500, 8000] }
const ehLimite = (k: string): k is keyof LimitesF10 => Object.prototype.hasOwnProperty.call(FAIXA_LIMITES, k)
/** Mapa { idDoAgente: boolean } — só agentes de domínio conhecidos. */
function mapaAgentes(v: unknown, msg: string): Record<string, boolean> {
  if (!ehObj(v)) erro400(msg)
  const out: Record<string, boolean> = {}
  for (const [k, x] of Object.entries(v)) { if (!IDS_DOMINIO.includes(k) || typeof x !== 'boolean') erro400(msg); out[k] = x }
  return out
}
/** Lista de escopos que só pode RESTRINGIR o que o agente já acessa (null = inválida). */
function escoposDe(v: unknown, permitidos: readonly Escopo[]): Escopo[] | null {
  if (!Array.isArray(v)) return null
  const out: Escopo[] = []
  for (const e of v as unknown[]) { const ok = permitidos.find((x) => x === e); if (!ok) return null; out.push(ok) }
  return out
}
export function validarF10(b: Record<string, unknown>, atual: F10Cfg): F10Patch {
  const out: F10Patch = {}
  if (b.dominio !== undefined) out.dominio = { ...atual.dominio, ...mapaAgentes(b.dominio, 'Agentes de domínio inválidos.') }
  if (b.autonomia !== undefined) {
    const msg = 'Nível de autonomia inválido (1 a 4).', v = b.autonomia
    if (!ehObj(v)) erro400(msg)
    const a: Record<string, number> = { ...atual.autonomia }
    for (const [k, x] of Object.entries(v)) { if (!IDS_DOMINIO.includes(k) || typeof x !== 'number' || !NIVEIS_AUTONOMIA.includes(x)) erro400(msg); a[k] = x }
    out.autonomia = a
  }
  if (b.permissoes !== undefined) {
    const v = b.permissoes
    if (!ehObj(v)) erro400('Permissões inválidas.')
    const p: Record<string, Escopo[]> = { ...atual.permissoes }
    for (const [k, x] of Object.entries(v)) { const ag = DOMINIO.find((a) => a.id === k), lista = ag ? escoposDe(x, ag.escopos) : null; if (!lista) erro400(`Permissões do agente ${k} inválidas (só é possível restringir o que ele já acessa).`); p[k] = lista }
    out.permissoes = p
  }
  if (b.debate !== undefined) { if (typeof b.debate !== 'boolean') erro400('Validação (debate) inválida.'); out.debate = b.debate }
  if (b.limites !== undefined && b.limites !== null) {
    const v = b.limites
    if (!ehObj(v)) erro400('Limites inválidos.')
    const L: LimitesF10 = { ...atual.limites }
    for (const [k, x] of Object.entries(v)) { if (!ehLimite(k) || typeof x !== 'number' || !Number.isInteger(x) || x < FAIXA_LIMITES[k][0] || x > FAIXA_LIMITES[k][1]) erro400(`Limite inválido: ${k}.`); L[k] = x }
    out.limites = L
  }
  return out
}
export function validarEmpresa(b: Record<string, unknown>): EmpresaF10 {
  const out: EmpresaF10 = {}
  if (b.agentes !== undefined) out.agentes = mapaAgentes(b.agentes, 'Agentes inválidos.')
  if (b.autonomiaMax !== undefined) { const x = b.autonomiaMax; if (typeof x !== 'number' || !NIVEIS_AUTONOMIA.includes(x)) erro400('Autonomia máxima inválida (1 a 4).'); out.autonomiaMax = x }
  return out
}

/* ======================= seleção ======================= */
const ANALITICO = /\b(analis\w*|relatorio|resumo|como (esta|estao|anda|andam|foi|foram)|situac\w*|panorama|diagnostic\w*|pendenc\w*|o que (preciso|falta|esta parado)|visao geral|desempenho|acompanh\w*)\b/
export const DECISORIO = /\b(vale a pena|devo|deveria|compensa|decid\w*|qual (a )?(melhor|mais indicad\w*) (opcao|escolha|decisao|caminho)|invest\w*|contrat\w*|riscos?)\b/
export function selecionarDominio(text: string, nivel: string, selIds: string[], cfg: Pick<F10Cfg, 'ativo' | 'dominio' | 'limites'>, permitidosEmpresa: (id: string) => boolean): AgenteDominio[] {
  if (!cfg.ativo || nivel === 'simples') return []
  const s = nrm(text)
  if (nivel === 'moderada' && !ANALITICO.test(s)) return [] // moderado só com pedido de análise/situação; o resto vai direto à IA principal
  // o pedido precisa citar a área do agente; o domínio reconhecido pelo núcleo (Nível 2) só desempata a prioridade
  const pts = DOMINIO.map((a) => { const g = (s.match(new RegExp(a.gatilho.source, 'g')) || []).length; return { a, g, p: g + (g && a.dominiosN2.some((d) => selIds.includes(d)) ? 0.5 : 0) } })
    .filter((x) => x.g > 0 && cfg.dominio[x.a.id] !== false && permitidosEmpresa(x.a.id))
  const intel = DOMINIO.find((a) => a.id === 'inteligencia')
  if (intel && nivel === 'complexa' && cfg.dominio.inteligencia !== false && permitidosEmpresa('inteligencia') && !pts.some((x) => x.a.id === 'inteligencia') && pts.length >= 2) pts.push({ a: intel, g: 0, p: 0.5 }) // cruzamento quando há 2+ áreas
  return pts.sort((x, y) => y.p - x.p).slice(0, cfg.limites.maxDominio).map((x) => x.a)
}

/* ======================= tarefas: registro, duplicidade, interrupção, memória compartilhada ======================= */
const RODANDO = new Map<number, { cancelar: boolean; userId: number; inicio: number }>()
export const emAndamento = () => [...RODANDO.entries()].map(([id, x]) => ({ id, userId: x.userId, desdeMs: Date.now() - x.inicio, cancelando: x.cancelar }))
export function interromper(id: number) { const x = RODANDO.get(id); if (!x) return false; x.cancelar = true; return true }
export const cancelada = (id: number | null) => !!(id && RODANDO.get(id)?.cancelar)
export async function empresasDoUsuario(uid: number, cfg: Pick<F10Cfg, 'empresas'>) {
  return ((await (await import('../db/index.js')).empresasAtivasDoDono(uid).catch(() => [])).slice(0, 3) as EmpresaRow[]).map((b) => ({ id: Number(b.id), nome: J<{ empresa?: string }>(b.data, {}).empresa || `Empresa #${b.id}`, cfg: cfg.empresas[String(b.id)] || {} }))
}
export interface Preparo { tarefa: number | null; agentes: { id: string; nome: string; ok: boolean; ms: number; fatos: number; motivo?: string }[]; achados: Record<string, string[]>; sugestoes: { agente: string; objetivo: string; motivo: string; autonomia: number }[]; memoria: { em: string; dominios: string[]; achados: Record<string, string[]>; decisoes: string[] }[]; limiteIA: boolean; reaproveitada: null | { notas: Record<string, string>; decisoes: string[] }; empresa: number | null }
export async function preparar(o: { u: SessionUser; text: string; nivel: string; selIds: string[]; convId?: string | null; hoje: string; sandbox?: boolean }): Promise<Preparo | null> {
  const cfg = await f10Cfg(); if (!cfg.ativo || o.sandbox) return null
  const emp = await empresasDoUsuario(o.u.id, cfg)
  const permitido = (id: string) => { const ag = DOMINIO.find((a) => a.id === id); if (!ag) return false; const soEmpresa = ag.escopos.every((e) => e.startsWith('empresa_') || e === 'crm' || e === 'marketing'); if (!soEmpresa) return true; return emp.some((e) => e.cfg.agentes?.[id] !== false) }
  const escolhidos = selecionarDominio(o.text, o.nivel, o.selIds, cfg, permitido)
  if (!escolhidos.length && o.nivel !== 'complexa') return null
  const chave = createHash('sha256').update(`${o.u.id}|${o.convId || ''}|${nrm(o.text).replace(/\s+/g, ' ').trim()}`).digest('hex').slice(0, 32)
  // mesma tarefa repetida em seguida (reenvio, clique duplo): reaproveita o resultado em vez de executar de novo
  const ja = await one<TarefaRow>("SELECT * FROM agent_tasks WHERE chave = $1 AND created_at >= $2 AND status IN ('concluida','parcial','reaproveitada') ORDER BY id DESC LIMIT 1", [chave, new Date(Date.now() - 90e3).toISOString()]).catch(() => null)
  const hojeIso = new Date(); hojeIso.setUTCHours(0, 0, 0, 0)
  const usadas = Number((await one<ContagemRow>('SELECT COUNT(*) AS n FROM agent_tasks WHERE user_id = $1 AND chamadas_ia > 0 AND created_at >= $2', [o.u.id, hojeIso.toISOString()]).catch(() => null))?.n || 0)
  const empresa = emp[0]?.id ?? null
  const ins = await q<IdRow>('INSERT INTO agent_tasks (user_id, business_id, conversation_id, chave, nivel, dominios, status, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id', [o.u.id, empresa, o.convId || null, chave, o.nivel, JSON.stringify(escolhidos.map((a) => a.id)), ja ? 'reaproveitada' : 'executando', nowIso()]).catch((): IdRow[] => [])
  const tarefa = ins[0]?.id ? Number(ins[0].id) : null
  if (tarefa && !ja) RODANDO.set(tarefa, { cancelar: false, userId: o.u.id, inicio: Date.now() })
  const out: Preparo = { tarefa, agentes: [], achados: {}, sugestoes: [], memoria: [], limiteIA: usadas >= cfg.limites.diarioPorUsuario, reaproveitada: null, empresa }
  if (ja) { const ach = J<Record<string, string[]>>(ja.achados, {}); out.reaproveitada = { notas: Object.fromEntries(Object.entries(ach).filter(([k]) => k.startsWith('ia:')).map(([k, v]) => [k.slice(3), v.join('\n')])), decisoes: J<DecisaoTarefa[]>(ja.decisoes, []).map((d) => d.texto || '').filter(Boolean) }; for (const [k, v] of Object.entries(ach)) if (!k.startsWith('ia:')) out.achados[k] = v; out.agentes = escolhidos.map((a) => ({ id: a.id, nome: a.nome, ok: true, ms: 0, fatos: (out.achados[a.id] || []).length, motivo: 'reaproveitado' })); return out }
  // memória compartilhada: tarefas anteriores do MESMO usuário (14 dias) com domínios em comum — continuidade entre execuções
  const ant = await q<TarefaRow>("SELECT dominios, achados, decisoes, created_at FROM agent_tasks WHERE user_id = $1 AND created_at >= $2 AND status IN ('concluida','parcial') ORDER BY id DESC LIMIT 12", [o.u.id, new Date(Date.now() - 14 * 864e5).toISOString()]).catch((): TarefaRow[] => [])
  const meus = new Set(escolhidos.map((a) => a.id))
  for (const r of ant) { const d = J<string[]>(r.dominios, []); if (!d.some((x) => meus.has(x))) continue; const ach = J<Record<string, string[]>>(r.achados, {}); out.memoria.push({ em: String(r.created_at).slice(0, 10), dominios: d, achados: Object.fromEntries(Object.entries(ach).filter(([k]) => !k.startsWith('ia:') && meus.has(k))), decisoes: J<DecisaoTarefa[]>(r.decisoes, []).map((x) => x.texto || '').filter(Boolean).slice(0, 2) }); if (out.memoria.length >= 2) break }
  // coleta em paralelo, cada agente com prazo próprio (um lento ou com erro não derruba os outros)
  const ctxDe = (a: AgenteDominio): Ctx => { const lim = cfg.permissoes[a.id]; return { u: o.u, hoje: o.hoje, empresas: emp.filter((e) => e.cfg.agentes?.[a.id] !== false), pode: (e) => a.escopos.includes(e) && (!lim || lim.includes(e)) } }
  await Promise.all(escolhidos.map(async (a) => {
    const t = Date.now()
    try { const r = await prazo(a.coletar(ctxDe(a)), cfg.limites.coletaMs); if (r && r.fatos.length) { out.achados[a.id] = r.fatos.slice(0, 8); const nivelAg = Math.min(cfg.autonomia[a.id] || 1, ...emp.map((e) => e.cfg.autonomiaMax || 4)); for (const s of r.sugestoes) if (a.acoes.includes(s.objetivo)) out.sugestoes.push({ agente: a.id, ...s, autonomia: nivelAg }) } out.agentes.push({ id: a.id, nome: a.nome, ok: true, ms: Date.now() - t, fatos: r?.fatos.length || 0, ...(r ? {} : { motivo: 'sem dados para este agente' }) }) }
    catch (e) { out.agentes.push({ id: a.id, nome: a.nome, ok: false, ms: Date.now() - t, fatos: 0, motivo: campoErro(e, 'code') === 'timeout' ? 'tempo esgotado' : msgErro(e, 80) }) }
  }))
  return out
}
/** Texto com os achados de domínio que um agente de raciocínio pode ver (+ memória compartilhada filtrada pelo mesmo acesso). */
export function achadosPara(agenteIA: string, p: Preparo | null): string {
  if (!p) return ''
  const pode = new Set(ACESSO_ACHADOS[agenteIA] || []), L: string[] = []
  for (const [id, f] of Object.entries(p.achados)) if (pode.has(id)) L.push(`Achados do ${DOMINIO.find((a) => a.id === id)?.nome || id} (dados reais, somente leitura):\n- ${f.join('\n- ')}`)
  const mem = p.memoria.map((m) => ({ ...m, achados: Object.fromEntries(Object.entries(m.achados).filter(([k]) => pode.has(k))) })).filter((m) => Object.keys(m.achados).length || m.decisoes.length)
  if (mem.length) L.push('Memória compartilhada (tarefas anteriores deste usuário — compare com os dados atuais):\n' + mem.map((m) => `- ${m.em}: ${Object.values(m.achados).flat().slice(0, 3).join(' | ')}${m.decisoes.length ? ' · decisão: ' + m.decisoes.join(' | ') : ''}`).join('\n'))
  return L.join('\n')
}
/** Bloco para a IA principal (consolidação): achados de todos os agentes de domínio e recomendações (nenhuma ação executada aqui). */
export function contextoDominio(p: Preparo | null): string {
  if (!p || !Object.keys(p.achados).length) return ''
  const L = ['ACHADOS DOS AGENTES ESPECIALIZADOS (dados reais do próprio usuário/empresa, somente leitura — use-os como base, cite os números exatamente e não invente além deles; NÃO mencione agentes):']
  for (const [id, f] of Object.entries(p.achados)) L.push(`[${DOMINIO.find((a) => a.id === id)?.nome || id}]\n- ${f.join('\n- ')}`)
  const rec = p.sugestoes.filter((s) => s.autonomia === 1)
  if (rec.length) L.push('Recomendações (só sugira; nada foi executado): ' + rec.map((s) => `${OBJ_NOME[s.objetivo] || s.objetivo} — ${s.motivo}`).join('; '))
  return L.join('\n')
}
const OBJ_NOME: Record<string, string> = { lembretes_compromissos: 'criar lembretes para os compromissos da semana', concluir_passados: 'marcar como concluídos os compromissos que já passaram', crm_acompanhamento: 'criar tarefas de acompanhamento no CRM', relatorio_financeiro: 'gerar o relatório financeiro do mês', organizar_semana: 'organizar a semana' }

/* ======================= validação (debate) — uma rodada, só quando vale a pena ======================= */
export function precisaValidar(text: string, nivel: string, notasIA: number, divergencias: number, cfg: Pick<F10Cfg, 'debate'>) { return !!cfg.debate && nivel === 'complexa' && notasIA >= 1 && (DECISORIO.test(nrm(text)) || divergencias > 0) }
/** Verificação de dados (determinística): números das contribuições que não aparecem nos dados nem nos achados. */
export function semBase(notas: Record<string, string>, fontes: string): string[] {
  const norm = (x: string) => x.replace(/[^\d,%]/g, '').replace(/,00$/, ''), F = new Set((fontes.match(/r\$\s?\d[\d.,]*|\d[\d.,]*\s?%/gi) || []).map(norm))
  const out: string[] = []
  for (const [ag, t] of Object.entries(notas)) for (const m of t.match(/r\$\s?\d[\d.,]*|\d[\d.,]*\s?%/gi) || []) if (!F.has(norm(m)) && !out.includes(m)) { out.push(`${m.trim()} (${ag})`); if (out.length >= 6) return out }
  return out
}

/* ======================= conclusão e ações (autonomia 1 a 4, sempre pelo motor da Fase 8) ======================= */
export async function concluir(tarefa: number | null, d: { status: string; etapas: EtapaTarefa[]; achados: Record<string, string[]>; notasIA: Record<string, string>; decisoes: DecisaoTarefa[]; chamadas: number; ms: number }) {
  if (!tarefa) return
  RODANDO.delete(tarefa)
  const ach: Record<string, string[]> = { ...d.achados }; for (const [k, v] of Object.entries(d.notasIA)) ach['ia:' + k] = [String(v).slice(0, 1400)]
  await q('UPDATE agent_tasks SET status = $1, etapas = $2, achados = $3, decisoes = $4, chamadas_ia = $5, ms = $6, finished_at = $7 WHERE id = $8', [d.status, JSON.stringify(d.etapas), JSON.stringify(ach), JSON.stringify(d.decisoes), d.chamadas, d.ms, nowIso(), tarefa]).catch((e: unknown) => console.error('[agentes]', campoErro(e, 'message')))
}
const PEDIDO_CANONICO: Record<string, string> = { lembretes_compromissos: 'crie lembretes para os compromissos da semana', concluir_passados: 'marque como concluídos os compromissos que já passaram', crm_acompanhamento: 'crie tarefas de acompanhamento para os leads', relatorio_financeiro: 'faça um relatório financeiro do mês', organizar_semana: 'organize minha semana' }
const COMPLETAS = new Set(['organizar_semana', 'relatorio_financeiro']) // operações completas (várias etapas / segundo plano): só no nível 4
/**
 * Depois da resposta: trata as ações sugeridas conforme o nível de autonomia.
 *  1 → nada (a recomendação já foi para a resposta) · 2 → prepara a execução e PEDE confirmação · 3 → executa as autorizadas (nível 1 da Fase 8;
 *  as que pedem confirmação/autorização ficam preparadas) · 4 → também operações completas, dentro do limite de etapas.
 * Exclusões, pagamentos e movimentações seguem SEMPRE a autorização explícita da Fase 8 (não há como pular).
 */
export async function agir(u: SessionUser, p: Preparo | null, convId: string, hoje: string, texto: string): Promise<string> {
  if (!p?.sugestoes.length || p.reaproveitada) return ''
  const cfg = await f10Cfg(), EP = await import('./execucao-planos.js'), linhas: string[] = [], acoes: AcaoRegistrada[] = []
  const s = p.sugestoes.filter((x) => x.autonomia >= 2).sort((a, b) => b.autonomia - a.autonomia)[0] // no máximo UMA ação por mensagem
  if (!s) return ''
  const obj = EP.OBJETIVOS.find((o) => o.id === s.objetivo); if (!obj) return ''
  const completa = COMPLETAS.has(s.objetivo), nivelMin = s.autonomia === 2 || (s.autonomia === 3 && completa) ? 2 : undefined
  try {
    const pedido = PEDIDO_CANONICO[s.objetivo] || texto, m: Montado = await obj.montar(u, nrm(pedido), hoje, pedido); if ('vazio' in m) return ''
    if (s.autonomia === 4 && m.plano.passos.length > cfg.limites.maxPassosN4) m.plano.nivelMinimo = 2 // além do limite definido: só com aprovação
    if (nivelMin) m.plano.nivelMinimo = nivelMin
    m.plano.conversationId = convId; m.plano.origin = 'agente:' + s.agente
    const EX = await import('./execucao.js'), { exec, repetida } = await EX.criarExecucao(u, m.plano)
    if (repetida) return ''
    const t = await EP.aposCriar(u, exec)
    acoes.push({ agente: s.agente, objetivo: s.objetivo, autonomia: s.autonomia, execucao: exec.id, status: exec.status })
    linhas.push(`${s.autonomia >= 3 && exec.status === 'na_fila' ? 'Também cuidei disto' : 'Também deixei pronto'} (${s.motivo}):\n${t}`)
  } catch (e) { acoes.push({ agente: s.agente, objetivo: s.objetivo, autonomia: s.autonomia, erro: msgErro(e, 120) }) }
  if (p.tarefa && acoes.length) await q('UPDATE agent_tasks SET acoes = $1 WHERE id = $2', [JSON.stringify(acoes), p.tarefa]).catch(() => {})
  return linhas.join('\n\n')
}
