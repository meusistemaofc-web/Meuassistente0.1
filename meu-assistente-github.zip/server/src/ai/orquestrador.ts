/* ORQUESTRAÇÃO CENTRAL — mapa único e VERIFICÁVEL da arquitetura de inteligência do Meu Assistente.
   Nada aqui substitui ou duplica um módulo: cada componente aponta para o código, as tabelas e a configuração que já
   existem, e o estado mostrado no painel vem de uma verificação real (configuração lida, tabela consultada, uso medido
   no rastreamento). Um componente só aparece "ativo" se a verificação passar; se a consulta falhar, aparece "com falha".

   Quem orquestra de fato cada mensagem do chat é routes/chat.ts → chatPostInner (pipeline abaixo, na ordem do código).
   Este arquivo descreve essa ordem, mede cada etapa (lib/timing.ts) e junta os rastros (brain_chat_traces +
   cognition_evals) para o painel Administração → Diagnóstico e Auditoria. */
import { q, one, J } from '../db/index.js'
import { getConfig } from '../lib/settings.js'

export type Secao = 'cerebro' | 'raciocinio' | 'provedores' | 'ferramentas' | 'execucao' | 'aprendizado' | 'preditiva' | 'diagnostico'
export const SECOES: Record<Secao, string> = {
  cerebro: 'Cérebro Central', raciocinio: 'Inteligência e Raciocínio', provedores: 'IAs e Provedores', ferramentas: 'Ferramentas e Integrações',
  execucao: 'Execução e Autonomia', aprendizado: 'Aprendizado e Evolução', preditiva: 'Inteligência Preditiva', diagnostico: 'Diagnóstico e Auditoria',
}
export type Estado = 'ativo' | 'sem_uso' | 'desligado' | 'atencao' | 'falha'
export interface Verificacao { estado: Estado; resumo: string; metricas: [string, string | number][] }
interface Componente {
  id: string; secao: Secao; nome: string; responsabilidade: string; naoFaz?: string
  arquivos: string[]; tabelas: string[]; config?: string; painel: string
  verificar: (j: Janela) => Promise<Verificacao>
}
interface Janela { d1: string; d7: string }

const n = async (sql: string, p: any[] = []) => Number((await one(sql, p))?.n || 0)
const fmt = (v: number) => v.toLocaleString('pt-BR')
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 100) + '%' : '—')
/** Estado a partir de ligado/desligado e uso recente (o mesmo critério para todos). */
const porUso = (ligado: boolean, usoRecente: number, resumoUso: string, resumoSem: string): Pick<Verificacao, 'estado' | 'resumo'> =>
  !ligado ? { estado: 'desligado', resumo: 'Desligado na configuração.' } : usoRecente > 0 ? { estado: 'ativo', resumo: resumoUso } : { estado: 'sem_uso', resumo: resumoSem }

export const COMPONENTES: Componente[] = [
  /* ---------------- Cérebro Central ---------------- */
  { id: 'biblioteca', secao: 'cerebro', nome: 'Biblioteca geral (Cérebro Central)',
    responsabilidade: 'Conhecimento geral com fontes, versões e revisão. É consultado antes de toda resposta de IA; quando falta conteúdo e a pergunta é geral, pesquisa, guarda e já usa a resposta.',
    naoFaz: 'Não guarda dados pessoais nem regras do app (isso é do Conhecimento operacional).',
    arquivos: ['ai/cerebro/central.ts', 'ai/cerebro/integracao.ts', 'ai/cerebro/vetor.ts', 'ai/cerebro/web.ts', 'ai/cerebro/motores.ts'], tabelas: ['knowledge_documents', 'knowledge_chunks', 'brain_chat_traces'], painel: '/admin/cerebro-central',
    async verificar(j) {
      const docs = await n("SELECT COUNT(*) AS n FROM knowledge_documents WHERE status IN ('aprovado','pendente','desatualizado')")
      const cons = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND consulted = $2', [j.d7, true])
      const usou = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND used_knowledge = $2', [j.d7, true])
      const CC = await (await import('./cerebro/central.js')).cfg(), ligado = CC.ativo !== false && CC.usarNoChat !== false
      const r = ligado && docs === 0 ? { estado: 'atencao' as Estado, resumo: 'A biblioteca está vazia: o chat consulta, mas não encontra nada.' } : porUso(ligado, cons, `Consultada ${fmt(cons)} vez(es) em 7 dias.`, 'Nenhuma consulta nos últimos 7 dias.')
      return { ...r, metricas: [['Conhecimentos na biblioteca', fmt(docs)], ['Consultas (7 dias)', fmt(cons)], ['Respostas que usaram o conhecimento', pct(usou, cons)], ['Consulta no chat', ligado ? 'ligada' : 'desligada']] }
    } },
  { id: 'operacional', secao: 'cerebro', nome: 'Conhecimento operacional e regras (Cérebro do chat)',
    responsabilidade: 'Conhecimentos e regras cadastrados no painel (entrega, horários, políticas do app) e respostas aprovadas que respondem SEM IA; regras executáveis cumpridas antes de qualquer motor.',
    naoFaz: 'Não pesquisa na internet; respostas aprendidas entram pendentes e só valem após aprovação.',
    arquivos: ['ai/brain.ts', 'ai/knowledge.ts', 'ai/rules.ts', 'ai/brain-usage.ts', 'ai/brain-conflicts.ts'], tabelas: ['brain_answers', 'brain_usage'], config: 'brain', painel: 'Cérebro Central → Conhecimento operacional',
    async verificar(j) {
      const B = await getConfig<any>('brain', {})
      const ativos = await n("SELECT COUNT(*) AS n FROM brain_answers WHERE status = 'ativo'")
      const pend = await n("SELECT COUNT(*) AS n FROM brain_answers WHERE status = 'pendente'")
      const uso = await n('SELECT COUNT(*) AS n FROM brain_usage WHERE created_at >= $1', [j.d7])
      return { ...porUso(B.cerebroPrimeiro !== false, uso, `Usado ${fmt(uso)} vez(es) em 7 dias.`, 'Nenhum uso nos últimos 7 dias.'), metricas: [['Itens ativos', fmt(ativos)], ['Aguardando revisão', fmt(pend)], ['Usos (7 dias)', fmt(uso)], ['Responder pelo cérebro primeiro', B.cerebroPrimeiro !== false ? 'sim' : 'não']] }
    } },
  { id: 'memoria', secao: 'cerebro', nome: 'Memória do usuário e da conversa',
    responsabilidade: 'Fatos e preferências do usuário (única fonte: memories), experiências de uso e o fio da conversa (referências, retomadas, agendamentos em partes).',
    arquivos: ['ai/memoria.ts', 'ai/memoria-evolutiva.ts', 'ai/convctx.ts'], tabelas: ['memories', 'experiences'], config: 'inteligencia.memoria', painel: 'Cérebro Central → Memória',
    async verificar(j) {
      const I = await getConfig<any>('inteligencia', {})
      const mem = await n('SELECT COUNT(*) AS n FROM memories WHERE active = $1', [true]), exp7 = await n('SELECT COUNT(*) AS n FROM experiences WHERE created_at >= $1', [j.d7])
      const novas = await n('SELECT COUNT(*) AS n FROM memories WHERE created_at >= $1', [j.d7])
      return { ...porUso(I.memoria !== false, novas + exp7, `${fmt(novas)} memória(s) e ${fmt(exp7)} experiência(s) novas em 7 dias.`, 'Nada novo guardado em 7 dias.'), metricas: [['Memórias ativas', fmt(mem)], ['Novas (7 dias)', fmt(novas)], ['Experiências (7 dias)', fmt(exp7)]] }
    } },
  /* ---------------- Inteligência e Raciocínio ---------------- */
  { id: 'cognicao', secao: 'raciocinio', nome: 'Leitura e avaliação de cada resposta (cognitivo)',
    responsabilidade: 'Lê a mensagem antes (intenção, lacunas, correções) e dá nota à resposta depois (precisão, coerência, ação confirmada).',
    arquivos: ['ai/cognition.ts', 'ai/classificar.ts'], tabelas: ['cognition_evals'], painel: 'Inteligência e Raciocínio → Cognição',
    async verificar(j) {
      const ev = await n('SELECT COUNT(*) AS n FROM cognition_evals WHERE created_at >= $1', [j.d7])
      const media = Math.round(Number((await one('SELECT AVG(overall) AS m FROM cognition_evals WHERE created_at >= $1', [j.d7]))?.m || 0))
      const r = porUso(true, ev, `${fmt(ev)} resposta(s) avaliada(s) em 7 dias.`, 'Nenhuma resposta avaliada em 7 dias.')
      return { ...(ev && media < 60 ? { estado: 'atencao' as Estado, resumo: `Nota média baixa (${media}/100) em 7 dias.` } : r), metricas: [['Avaliadas (7 dias)', fmt(ev)], ['Nota média', ev ? media + '/100' : '—']] }
    } },
  { id: 'nucleo', secao: 'raciocinio', nome: 'Núcleo avançado: contexto, planejamento, especialistas e autoverificação',
    responsabilidade: 'Prepara cada turno da IA (contexto, plano, especialistas, memória) e confere a resposta antes de entregar (autoverificação, autocorreção, conferência das ações no banco).',
    arquivos: ['ai/nucleo.ts', 'ai/planejador.ts', 'ai/especialistas.ts', 'ai/autoverificacao.ts', 'ai/politica.ts'], tabelas: ['assistant_plans'], config: 'inteligencia', painel: 'Inteligência e Raciocínio → Núcleo avançado',
    async verificar(j) {
      const I = { ativo: true, planejamento: true, especialistas: true, autoverificacao: true, ...(await getConfig<any>('inteligencia', {})) }
      const usos = await n("SELECT COUNT(*) AS n FROM cognition_evals WHERE created_at >= $1 AND level2 IS NOT NULL AND level2 <> ''", [j.d7])
      const planos = await n('SELECT COUNT(*) AS n FROM assistant_plans WHERE created_at >= $1', [j.d7])
      const desl = ['planejamento', 'especialistas', 'autoverificacao'].filter((k) => I[k] === false)
      const r = porUso(I.ativo !== false, usos, `Atuou em ${fmt(usos)} resposta(s) da IA em 7 dias.`, 'Não atuou em nenhuma resposta da IA em 7 dias.')
      return { ...(r.estado === 'ativo' && desl.length ? { estado: 'atencao' as Estado, resumo: r.resumo + ' Desligado: ' + desl.join(', ') + '.' } : r), metricas: [['Respostas com o núcleo (7 dias)', fmt(usos)], ['Planos criados (7 dias)', fmt(planos)], ['Partes desligadas', desl.length ? desl.join(', ') : 'nenhuma']] }
    } },
  { id: 'multiagente', secao: 'raciocinio', nome: 'Coordenação multiagente',
    responsabilidade: 'Só em pedidos complexos: o coordenador mobiliza agentes internos (pesquisa, análise, escrita…) e domínios; o usuário continua falando com um único assistente.',
    arquivos: ['ai/agentes.ts', 'ai/agentes-dominio.ts'], tabelas: ['agent_tasks'], config: 'inteligencia', painel: '/admin/agentes',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM agent_tasks WHERE created_at >= $1', [j.d7]), f = await n("SELECT COUNT(*) AS n FROM agent_tasks WHERE created_at >= $1 AND status = 'falhou'", [j.d7])
      const r = porUso(true, t, `${fmt(t)} coordenação(ões) em 7 dias.`, 'Nenhum pedido complexo coordenado em 7 dias (normal se não houve pedidos complexos).')
      return { ...(t && f / t > 0.3 ? { estado: 'atencao' as Estado, resumo: `${pct(f, t)} das coordenações falharam em 7 dias.` } : r), metricas: [['Coordenações (7 dias)', fmt(t)], ['Com falha', fmt(f)]] }
    } },
  { id: 'idioma_guia', secao: 'raciocinio', nome: 'Idioma e modo explicativo',
    responsabilidade: 'Escolhe o idioma de cada turno (preferência salva → pedido → idioma da mensagem) e responde "como faço…" com passos reais da interface, sem executar nada.',
    arquivos: ['ai/idioma.ts', 'ai/guia.ts'], tabelas: ['brain_chat_traces'], painel: 'Inteligência e Raciocínio → Idioma e explicações',
    async verificar(j) {
      const g = await n("SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND via IN ('guia','idioma')", [j.d7])
      const nPt = await n("SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND detail LIKE $2 AND detail NOT LIKE $3", [j.d7, '%"idioma":"%', '%"idioma":"pt"%'])
      return { ...porUso(true, g + nPt, `${fmt(g)} explicação(ões)/troca(s) de idioma e ${fmt(nPt)} resposta(s) em outro idioma em 7 dias.`, 'Sem uso registrado em 7 dias.'), metricas: [['Explicações e idioma (7 dias)', fmt(g)], ['Respostas fora do português (7 dias)', fmt(nPt)]] }
    } },
  { id: 'modos', secao: 'raciocinio', nome: 'Modos inteligentes (⚡)',
    responsabilidade: 'Conversas com um modo ativo (ex.: busca de produtos, marketing) são atendidas pelo modo, com o acesso conferido.',
    arquivos: ['modos/index.ts', 'modos/busca.ts', 'modos/marketing.ts'], tabelas: ['modo_memoria'], painel: 'Inteligência e Raciocínio → Modos',
    async verificar(j) {
      const u = await n("SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND via = 'modo'", [j.d7]), m = await n('SELECT COUNT(*) AS n FROM modo_memoria')
      return { ...porUso(true, u, `${fmt(u)} resposta(s) por modo em 7 dias.`, 'Nenhuma resposta por modo em 7 dias.'), metricas: [['Respostas por modo (7 dias)', fmt(u)], ['Memórias de modo guardadas', fmt(m)]] }
    } },
  /* ---------------- IAs e Provedores ---------------- */
  { id: 'provedores', secao: 'provedores', nome: 'Provedores de IA e roteamento com fallback',
    responsabilidade: 'Escolhe o provedor por tarefa e capacidade, troca para o próximo em caso de falha (fallback) e pausa quem falha repetidamente (disjuntor).',
    arquivos: ['ai/engine.ts', 'ai/registry.ts', 'ai/health.ts', 'ai/provider.ts', 'ai/adapters/*'], tabelas: [], config: 'ai_providers / ai_router', painel: 'IAs e Provedores → Provedores',
    async verificar() {
      const R = await import('./registry.js'), H = await import('./health.js')
      const ps = (await R.loadProviders()).filter((p) => p.ativo !== false)
      const prontos: string[] = []; for (const p of ps) if (await R.targetFor(p).catch(() => null)) prontos.push(p.nome || p.id)
      const rt = await H.runtime(), pausados = Object.keys(rt.breakers || {})
      const st = Object.values(rt.stats || {}) as any[], usos = st.reduce((a, s) => a + (s.uses || 0), 0), falhas = st.reduce((a, s) => a + (s.failures || 0), 0), fb = st.reduce((a, s) => a + (s.fallbacks || 0), 0)
      const estado: Estado = !prontos.length ? 'falha' : pausados.length >= prontos.length ? 'falha' : pausados.length ? 'atencao' : usos ? 'ativo' : 'sem_uso'
      const resumo = !prontos.length ? 'Nenhum provedor de IA configurado: o chat responde só com motores internos e o Cérebro.' : pausados.length ? `${pausados.length} provedor(es) pausado(s) por falhas: ${pausados.join(', ')}.` : `${prontos.length} provedor(es) pronto(s): ${prontos.join(', ')}.`
      return { estado, resumo, metricas: [['Prontos', prontos.length ? prontos.join(', ') : 'nenhum'], ['Chamadas registradas', fmt(usos)], ['Falhas', fmt(falhas)], ['Trocas por fallback', fmt(fb)], ['Pausados agora', pausados.length ? pausados.join(', ') : 'nenhum']] }
    } },
  { id: 'voz', secao: 'provedores', nome: 'Voz: transcrição e fala',
    responsabilidade: 'Ditado do microfone (áudio → texto no idioma falado) e voz natural das respostas.',
    arquivos: ['ai/tts.ts', 'routes/chat.ts (transcribePost)'], tabelas: [], config: 'modules.voz', painel: 'IAs e Provedores → Voz',
    async verificar() {
      const M = await getConfig<any>('modules', {}), on = M.voz !== false
      const whisper = !!process.env.WHISPER_URL, R = await import('./registry.js')
      const audio = (await R.loadProviders()).filter((p: any) => p.ativo !== false && p.modelo_audio && p.key).length
      return { estado: !on ? 'desligado' : whisper || audio ? 'ativo' : 'atencao', resumo: !on ? 'Módulo de voz desligado.' : whisper || audio ? 'Transcrição disponível.' : 'Sem serviço de transcrição configurado (WHISPER_URL ou chave com modelo de áudio).', metricas: [['Módulo de voz', on ? 'ligado' : 'desligado'], ['Whisper local', whisper ? 'configurado' : 'não'], ['Provedores com áudio', fmt(audio)]] }
    } },
  /* ---------------- Ferramentas e Integrações ---------------- */
  { id: 'ferramentas', secao: 'ferramentas', nome: 'Ferramentas reais do chat (para a IA)',
    responsabilidade: 'Ações e consultas que a IA pode chamar (agenda, finanças, tarefas, CRM, execuções…), sempre no banco real e com conferência do resultado.',
    arquivos: ['ai/assistant.ts (TOOLS)', 'ai/execucao-ia.ts'], tabelas: ['brain_chat_traces (detail.ferramentas)'], painel: 'Ferramentas e Integrações → Ferramentas',
    async verificar(j) {
      const { TOOLS } = await import('./assistant.js')
      const rs = await q("SELECT detail FROM brain_chat_traces WHERE created_at >= $1 AND detail LIKE $2", [j.d7, '%"ferramentas":[{%'])
      let ok = 0, falha = 0; const porNome = new Map<string, number>()
      for (const r of rs) for (const f of (J(r.detail, {} as any).ferramentas || [])) { porNome.set(f.n, (porNome.get(f.n) || 0) + 1); if (f.ok === false) falha++; else ok++ }
      const top = [...porNome].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${k} (${v})`).join(', ')
      const r = porUso(true, ok + falha, `${fmt(ok + falha)} chamada(s) em 7 dias.`, 'Nenhuma ferramenta chamada em 7 dias.')
      return { ...(ok + falha >= 5 && falha / (ok + falha) > 0.25 ? { estado: 'atencao' as Estado, resumo: `${pct(falha, ok + falha)} das chamadas falharam em 7 dias.` } : r), metricas: [['Ferramentas disponíveis', fmt(TOOLS.length)], ['Chamadas (7 dias)', fmt(ok + falha)], ['Com falha', fmt(falha)], ['Mais usadas', top || '—']] }
    } },
  { id: 'motores', secao: 'ferramentas', nome: 'Motores internos (sem IA)',
    responsabilidade: 'Respondem na hora, sem gastar IA: finanças, agenda e compromissos, lembretes, cálculo, módulos do app, cotações e atalhos.',
    arquivos: ['ai/finchat.ts', 'ai/agenda.ts', 'ai/appt.ts', 'lib/math.ts', 'lib/modcatalog.ts', 'ai/rules.ts'], tabelas: ['brain_chat_traces (via)'], painel: 'Ferramentas e Integrações → Motores internos',
    async verificar(j) {
      const rs = await q("SELECT via, COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND channel = 'chat' GROUP BY via", [j.d7])
      const VIAS = ['financeiro', 'agenda', 'motor_interno', 'calculo', 'memoria_conversa', 'regra', 'atalho', 'cerebro']
      const int = rs.filter((r: any) => VIAS.includes(r.via)).reduce((a: number, r: any) => a + Number(r.n), 0), tot = rs.reduce((a: number, r: any) => a + Number(r.n), 0)
      return { ...porUso(true, int, `${pct(int, tot)} das respostas do chat saíram sem IA em 7 dias.`, 'Nenhuma resposta interna em 7 dias.'), metricas: [['Respostas internas (7 dias)', fmt(int)], ['Do total do chat', pct(int, tot)]] }
    } },
  { id: 'pesquisa_web', secao: 'ferramentas', nome: 'Pesquisa na internet',
    responsabilidade: 'Só para perguntas gerais sem dados pessoais e quando a biblioteca não basta; o resultado vira conhecimento com fontes.',
    arquivos: ['ai/cerebro/web.ts', 'ai/cerebro/motores.ts'], tabelas: ['brain_web_cache', 'brain_motor_estado', 'brain_motor_uso'], config: 'brain_central', painel: '/admin/cerebro-central',
    async verificar(j) {
      const feitas = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND web_done = $2', [j.d7, true]), pedidas = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND web_needed = $2', [j.d7, true])
      const CC = await (await import('./cerebro/central.js')).cfg(), ligada = CC.ativo !== false && CC.usarNoChat !== false && (CC.aprenderNoChat !== false || CC.pesquisaNoChat === true) // mesma condição de integracao.ts → recuperar
      if (!ligada) return { estado: 'desligado', resumo: 'Pesquisa pelo chat desligada no Cérebro Central ("Aprender no chat" e "Pesquisa no chat"). O chat usa só o que a biblioteca já tem.', metricas: [['Pesquisas feitas (7 dias)', fmt(feitas)], ['Perguntas que precisavam', fmt(pedidas)], ['Pesquisa automática (painel do Cérebro)', CC.pesquisaAutomatica ? 'ligada' : 'desligada']] }
      const r = porUso(true, feitas, `${fmt(feitas)} pesquisa(s) em 7 dias.`, pedidas ? `${fmt(pedidas)} pergunta(s) precisaram de pesquisa, mas nenhuma foi feita (mecanismo desligado ou sem acesso).` : 'Nenhuma pergunta precisou de pesquisa em 7 dias.')
      return { ...(pedidas && !feitas ? { ...r, estado: 'atencao' as Estado } : r), metricas: [['Pesquisas feitas (7 dias)', fmt(feitas)], ['Perguntas que precisavam', fmt(pedidas)]] }
    } },
  { id: 'notificacoes', secao: 'ferramentas', nome: 'Notificações push',
    responsabilidade: 'Avisos no app e no aparelho (tarefas concluídas, lembretes, alertas), respeitando a permissão de cada usuário.',
    arquivos: ['lib/notify.ts', 'lib/push.ts'], tabelas: ['notifications', 'push_subscriptions'], painel: 'Ferramentas e Integrações → Integrações',
    async verificar(j) {
      const subs = await n('SELECT COUNT(*) AS n FROM push_subscriptions'), env = await n('SELECT COUNT(*) AS n FROM notifications WHERE created_at >= $1', [j.d7])
      const vapid = !!(await getConfig<any>('vapid', null))?.publicKey
      return { ...porUso(true, env, `${fmt(env)} aviso(s) em 7 dias.`, 'Nenhum aviso em 7 dias.'), metricas: [['Aparelhos inscritos', fmt(subs)], ['Avisos (7 dias)', fmt(env)], ['Chaves de push (VAPID)', vapid ? 'criadas' : 'serão criadas no 1º uso']] }
    } },
  /* ---------------- Execução e Autonomia ---------------- */
  { id: 'execucao', secao: 'execucao', nome: 'Execução de objetivos (autonomia operacional)',
    responsabilidade: 'Objetivo em linguagem natural → plano em etapas → aprovação conforme o nível de autonomia → execução com os serviços reais → conferência de cada resultado → relato.',
    arquivos: ['ai/execucao.ts', 'ai/execucao-planos.ts', 'ai/execucao-ia.ts'], tabelas: ['executions'], config: 'user_intel_prefs.autonomy', painel: 'Execução e Autonomia → Execuções',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM executions WHERE created_at >= $1', [j.d7])
      const ok = await n("SELECT COUNT(*) AS n FROM executions WHERE created_at >= $1 AND status = 'feito'", [j.d7]), f = await n("SELECT COUNT(*) AS n FROM executions WHERE created_at >= $1 AND status IN ('falhou','incerto')", [j.d7])
      const r = porUso(true, t, `${fmt(t)} execução(ões) em 7 dias.`, 'Nenhuma execução em 7 dias.')
      return { ...(t >= 3 && f / t > 0.3 ? { estado: 'atencao' as Estado, resumo: `${pct(f, t)} das execuções falharam em 7 dias.` } : r), metricas: [['Execuções (7 dias)', fmt(t)], ['Concluídas', fmt(ok)], ['Com falha', fmt(f)]] }
    } },
  { id: 'segundo_plano', secao: 'execucao', nome: 'Tarefas do chat em segundo plano',
    responsabilidade: 'Cada pedido do chat vira tarefa persistente: continua se o usuário sair, salva o resultado, avisa por push, permite tentar de novo e recupera tarefas interrompidas.',
    arquivos: ['lib/tarefas-chat.ts'], tabelas: ['chat_jobs'], painel: 'Execução e Autonomia → Segundo plano',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM chat_jobs WHERE created_at >= $1', [j.d1]), err = await n("SELECT COUNT(*) AS n FROM chat_jobs WHERE created_at >= $1 AND status = 'error'", [j.d1])
      const fila = await n("SELECT COUNT(*) AS n FROM chat_jobs WHERE status IN ('queued','pending')"), fora = await n('SELECT COUNT(*) AS n FROM chat_jobs WHERE created_at >= $1 AND segundo_plano = $2', [j.d1, true])
      const r = porUso(true, t, `${fmt(t)} pedido(s) nas últimas 24 h.`, 'Nenhum pedido nas últimas 24 h.')
      return { ...(t >= 5 && err / t > 0.2 ? { estado: 'atencao' as Estado, resumo: `${pct(err, t)} dos pedidos falharam nas últimas 24 h.` } : r), metricas: [['Pedidos (24 h)', fmt(t)], ['Terminaram fora da tela', fmt(fora)], ['Falharam', fmt(err)], ['Na fila agora', fmt(fila)]] }
    } },
  /* ---------------- Aprendizado e Evolução ---------------- */
  { id: 'aprendizado_continuo', secao: 'aprendizado', nome: 'Aprendizado contínuo (política versionada)',
    responsabilidade: 'Analisa notas, 👍/👎 e correções e propõe mudanças na política do assistente; cada mudança é testada, aprovada, versionada e pode ser revertida.',
    arquivos: ['ai/aprendizado.ts', 'ai/politica.ts', 'ai/feedback.ts', 'ai/avaliacao.ts'], tabelas: ['learning_proposals', 'learning_policy_versions', 'response_feedback'], config: 'aprendizado', painel: 'Aprendizado e Evolução → Aprendizado contínuo',
    async verificar(j) {
      const C = await getConfig<any>('aprendizado', {}), prop = await n("SELECT COUNT(*) AS n FROM learning_proposals WHERE status IN ('proposta','testada','gradual')")
      const vers = await n('SELECT COUNT(*) AS n FROM learning_policy_versions'), fb = await n('SELECT COUNT(*) AS n FROM response_feedback WHERE created_at >= $1', [j.d7])
      return { ...porUso(C.ativo !== false, fb + prop, `${fmt(fb)} avaliação(ões) 👍/👎 em 7 dias; ${fmt(prop)} proposta(s) aguardando.`, 'Sem avaliações nem propostas novas.'), metricas: [['Propostas aguardando decisão', fmt(prop)], ['Versões da política', fmt(vers)], ['Avaliações 👍/👎 (7 dias)', fmt(fb)]] }
    } },
  { id: 'aprendizagem_adaptativa', secao: 'aprendizado', nome: 'Aprendizagem adaptativa (por usuário)',
    responsabilidade: 'Correções e preferências de cada usuário viram aprendizados individuais (silenciosos), com revisão pelo administrador.',
    arquivos: ['ai/adaptive.ts'], tabelas: ['learnings'], painel: 'Aprendizado e Evolução → Aprendizados',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM learnings WHERE created_at >= $1', [j.d7]), rev = await n("SELECT COUNT(*) AS n FROM learnings WHERE review_status = 'pendente'")
      return { ...porUso(true, t, `${fmt(t)} aprendizado(s) novo(s) em 7 dias.`, 'Nenhum aprendizado novo em 7 dias.'), metricas: [['Novos (7 dias)', fmt(t)], ['Aguardando revisão', fmt(rev)]] }
    } },
  { id: 'laboratorio', secao: 'aprendizado', nome: 'Laboratórios (regras e testes isolados)',
    responsabilidade: 'Laboratório de IA: conversa do administrador que vira proposta de regra → testes → aprovação → publicação. Laboratório de Inteligência: desafios e baterias em ambiente isolado (usuário sintético).',
    naoFaz: 'Nada do laboratório chega aos usuários sem aprovação e publicação.',
    arquivos: ['ai/lab.ts', 'ai/laboratorio.ts', 'ai/laboratorio-agentes.ts', 'ai/laboratorio-painel.ts'], tabelas: ['lab_proposals', 'lab_runs', 'lab_challenges'], painel: 'Aprendizado e Evolução → Laboratório',
    async verificar(j) {
      const p = await n("SELECT COUNT(*) AS n FROM lab_proposals WHERE state NOT IN ('publicada','rejeitada','desativada')"), runs = await n('SELECT COUNT(*) AS n FROM lab_runs WHERE created_at >= $1', [j.d7]), des = await n('SELECT COUNT(*) AS n FROM lab_challenges WHERE active = $1', [true])
      return { ...porUso(true, runs + p, `${fmt(runs)} rodada(s) de teste em 7 dias; ${fmt(p)} proposta(s) em andamento.`, 'Nenhuma rodada nem proposta em andamento.'), metricas: [['Propostas em andamento', fmt(p)], ['Rodadas de teste (7 dias)', fmt(runs)], ['Desafios ativos', fmt(des)]] }
    } },
  /* ---------------- Inteligência Preditiva ---------------- */
  { id: 'preditiva', secao: 'preditiva', nome: 'Previsões e alertas antecipados',
    responsabilidade: 'Lê compromissos, contas, tarefas e hábitos e antecipa necessidades (conflitos, esquecimentos, recorrências), com confiança e validação.',
    arquivos: ['ai/preditivo.ts', 'ai/preditivo-servico.ts'], tabelas: ['predictions', 'predictive_alerts'], config: 'preditivo', painel: 'Inteligência Preditiva → Previsões',
    async verificar(j) {
      const C = await getConfig<any>('preditivo', {}), p = await n('SELECT COUNT(*) AS n FROM predictions WHERE created_at >= $1', [j.d7]), a = await n('SELECT COUNT(*) AS n FROM predictive_alerts WHERE created_at >= $1', [j.d7])
      const conf = await n("SELECT COUNT(*) AS n FROM predictions WHERE created_at >= $1 AND status = 'acertou'", [j.d7])
      return { ...porUso(C.ativo !== false, p + a, `${fmt(p)} previsão(ões) e ${fmt(a)} alerta(s) em 7 dias.`, 'Nenhuma previsão nem alerta em 7 dias.'), metricas: [['Previsões (7 dias)', fmt(p)], ['Acertaram', fmt(conf)], ['Alertas (7 dias)', fmt(a)]] }
    } },
  { id: 'proatividade', secao: 'preditiva', nome: 'Sugestões proativas no chat',
    responsabilidade: 'Oferece uma ajuda relacionada no fim da resposta quando faz sentido; respeita a preferência do usuário e mede a aceitação.',
    naoFaz: 'Não cria previsões (isso é das Previsões); só oferece e registra a resposta sim/não.',
    arquivos: ['ai/proativo.ts'], tabelas: ['proactive_log'], config: 'inteligencia.proatividade', painel: 'Inteligência Preditiva → Proatividade',
    async verificar(j) {
      const I = await getConfig<any>('inteligencia', {}), t = await n('SELECT COUNT(*) AS n FROM proactive_log WHERE created_at >= $1', [j.d7]), ac = await n('SELECT COUNT(*) AS n FROM proactive_log WHERE created_at >= $1 AND accepted = $2', [j.d7, true])
      return { ...porUso(I.proatividade !== false, t, `${fmt(t)} sugestão(ões) em 7 dias, ${pct(ac, t)} aceitas.`, 'Nenhuma sugestão em 7 dias.'), metricas: [['Sugestões (7 dias)', fmt(t)], ['Aceitas', pct(ac, t)]] }
    } },
  /* ---------------- Diagnóstico e Auditoria ---------------- */
  { id: 'rastreamento', secao: 'diagnostico', nome: 'Rastreamento das respostas',
    responsabilidade: 'Cada resposta do chat deixa um rastro: caminho (via), etapas e tempos, fontes, provedor, falhas e fallback, ferramentas, ações conferidas e nota.',
    arquivos: ['ai/cerebro/integracao.ts (finalizar)', 'lib/timing.ts', 'ai/orquestrador.ts'], tabelas: ['brain_chat_traces', 'cognition_evals'], painel: 'Diagnóstico e Auditoria → Rastreamento',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1', [j.d1]), det = await n('SELECT COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND detail IS NOT NULL', [j.d1])
      return { ...porUso(true, t, `${fmt(t)} resposta(s) rastreada(s) nas últimas 24 h.`, 'Nenhuma resposta nas últimas 24 h.'), metricas: [['Rastros (24 h)', fmt(t)], ['Com etapas e ferramentas', pct(det, t)]] }
    } },
  { id: 'auditoria', secao: 'diagnostico', nome: 'Auditoria administrativa',
    responsabilidade: 'Registro das ações de administradores (quem mudou o quê e quando).',
    arquivos: ['routes/admin.ts'], tabelas: ['audit_log'], painel: 'Diagnóstico e Auditoria → Auditoria',
    async verificar(j) {
      const t = await n('SELECT COUNT(*) AS n FROM audit_log WHERE created_at >= $1', [j.d7])
      return { ...porUso(true, t, `${fmt(t)} ação(ões) administrativa(s) em 7 dias.`, 'Nenhuma ação administrativa em 7 dias.'), metricas: [['Ações (7 dias)', fmt(t)]] }
    } },
]

/** Pipeline de cada mensagem do chat, NA ORDEM do código (routes/chat.ts → chatPostInner). `etapa` = nome medido em lib/timing.ts. */
export const PIPELINE = [
  { etapa: 'conversa_e_historico', nome: 'Entrada e contexto', faz: 'Anexos (áudio, foto, documento), conversa, histórico e leitura cognitiva da mensagem (intenção, correção, resposta sim/não).', componentes: ['cognicao', 'aprendizado_continuo'] },
  { etapa: null, nome: 'Permissões e limites', faz: 'Sessão do usuário, cota do plano, módulos ligados/desligados (ex.: Finanças, Voz, Imagens) — sem permissão, o caminho não é usado.', componentes: [] },
  { etapa: null, nome: 'Idioma, explicação e modos', faz: 'Idioma do turno; "como faço…" responde com passos reais sem executar; conversa com modo ativo vai para o modo.', componentes: ['idioma_guia', 'modos'] },
  { etapa: null, nome: 'Regras e aprendizados', faz: 'Regras executáveis do Cérebro, aprendizagem adaptativa e objetivos (planejar → aprovar → executar → conferir).', componentes: ['operacional', 'aprendizagem_adaptativa', 'execucao'] },
  { etapa: 'motores_internos', nome: 'Motores internos (sem IA)', faz: 'Cálculo, memória da conversa, finanças, agenda, módulos, lembretes — respondem na hora com dados reais.', componentes: ['motores', 'memoria'] },
  { etapa: 'atalhos', nome: 'Atalhos com dados reais', faz: 'Cotações e impostos sem gastar IA.', componentes: ['motores'] },
  { etapa: 'conhecimento', nome: 'Conhecimento operacional', faz: 'Respostas aprovadas e conhecimentos cadastrados respondem antes de qualquer IA.', componentes: ['operacional'] },
  { etapa: 'cerebro_central', nome: 'Cérebro Central', faz: 'Consulta obrigatória da biblioteca antes da IA; se faltar e a pergunta for geral, pesquisa e aprende.', componentes: ['biblioteca', 'pesquisa_web'] },
  { etapa: 'ia', nome: 'IA com ferramentas', faz: 'Núcleo prepara o turno (contexto, plano, especialistas, memória), o roteador escolhe o provedor com fallback, a IA usa ferramentas reais, o núcleo confere as ações no banco e autoverifica a resposta.', componentes: ['nucleo', 'multiagente', 'provedores', 'ferramentas', 'proatividade'] },
  { etapa: null, nome: 'Sem IA disponível (fallback)', faz: 'Se todos os provedores falharem, o Cérebro Central responde com o que já sabe (trecho + fonte) ou o pedido falha com aviso e "Tentar de novo".', componentes: ['biblioteca', 'segundo_plano'] },
  { etapa: 'gravacao_e_entrega', nome: 'Gravação, avaliação e rastro', faz: 'Grava a conversa, dá nota à resposta, registra o uso do conhecimento e o rastro completo.', componentes: ['cognicao', 'rastreamento'] },
]

/** Sobreposições encontradas na auditoria e como ficaram (só "resolvido" quando houve mudança real no código). */
export const SOBREPOSICOES = [
  { tema: 'Duas bases de conhecimento', achado: 'brain_answers (Cérebro do chat) e knowledge_documents (Cérebro Central) respondem antes da IA.', decisao: 'Mantidas, com papéis separados: operacional/regras do app (brain_answers) × conhecimento geral com fontes (biblioteca). A ordem no pipeline é fixa: operacional primeiro, biblioteca depois. Sem migração de dados.', status: 'documentado' },
  { tema: 'Respostas aprendidas em dois lugares', achado: 'A resposta da IA a pergunta geral vira item pendente em brain_answers e a pesquisa na internet vira documento na biblioteca.', decisao: 'Mantido: a primeira depende de aprovação do administrador; a segunda tem fontes. Fundir exige decisão sobre os itens já aprovados.', status: 'pendente' },
  { tema: 'Rastreamento espalhado', achado: 'Tempo por etapa só em memória (timing.ts), fontes em brain_chat_traces, nota em cognition_evals, ferramentas só dentro da resposta.', decisao: 'Unificado: o rastro de cada resposta passa a guardar etapas, ferramentas, ações conferidas, especialistas e sinais (coluna detail, migração 055) e o painel junta com a nota.', status: 'resolvido' },
  { tema: 'Dois "laboratórios"', achado: 'Laboratório de IA (propostas de regra) e Laboratório de Inteligência (testes isolados) com nomes parecidos e telas separadas.', decisao: 'Mantidos (funções diferentes) e agrupados na mesma seção do painel com nomes que dizem o que cada um faz.', status: 'resolvido' },
  { tema: 'Painel do cérebro misturado', achado: 'A aba "Cérebro e busca" juntava cérebro, cognição, núcleo, aprendizado, previsões e autonomia numa página só.', decisao: 'Separada nas seções da nova Administração; cada parte continua com a mesma tela e a mesma API.', status: 'resolvido' },
  { tema: 'Previsões × proatividade', achado: 'Ambas "antecipam", mas uma cria previsões/alertas e a outra só oferece ajuda no fim da resposta.', decisao: 'Mantidas com responsabilidades explícitas (ver cada componente).', status: 'documentado' },
]

const janela = (): Janela => ({ d1: new Date(Date.now() - 864e5).toISOString(), d7: new Date(Date.now() - 7 * 864e5).toISOString() })

/** Verifica todos os componentes (cada um isolado: a falha de um não derruba os outros). */
export async function verificarTudo() {
  const j = janela(), t0 = Date.now()
  const out = await Promise.all(COMPONENTES.map(async (c) => {
    const ti = Date.now()
    let v: Verificacao
    try { v = await c.verificar(j) } catch (e: any) { v = { estado: 'falha', resumo: 'A verificação falhou: ' + String(e?.message || e).slice(0, 160), metricas: [] } }
    return { id: c.id, secao: c.secao, nome: c.nome, responsabilidade: c.responsabilidade, naoFaz: c.naoFaz || '', arquivos: c.arquivos, tabelas: c.tabelas, config: c.config || '', painel: c.painel, ...v, ms: Date.now() - ti }
  }))
  return { verificadoEm: new Date().toISOString(), ms: Date.now() - t0, componentes: out }
}

/** Indicadores do chat (24 h e 7 dias) a partir dos rastros reais. */
export async function indicadores() {
  const j = janela()
  const linha = async (desde: string) => {
    // as cinco contagens numa consulta só (antes: cinco consultas na mesma tabela e no mesmo período)
    const c = await one("SELECT COUNT(*) AS tot, SUM(CASE WHEN sent_to_ai = $2 THEN 1 ELSE 0 END) AS ia, SUM(CASE WHEN failures IS NOT NULL AND failures <> '[]' THEN 1 ELSE 0 END) AS falhas, SUM(CASE WHEN via = 'cerebro_sem_ia' THEN 1 ELSE 0 END) AS semia, SUM(CASE WHEN used_knowledge = $2 THEN 1 ELSE 0 END) AS conh FROM brain_chat_traces WHERE created_at >= $1 AND channel = 'chat'", [desde, true])
    const tot = Number(c?.tot) || 0, ia = Number(c?.ia) || 0, falhas = Number(c?.falhas) || 0, semIA = Number(c?.semia) || 0, usouConh = Number(c?.conh) || 0
    const amostra = await q("SELECT detail, ms_total FROM brain_chat_traces WHERE created_at >= $1 AND channel = 'chat' ORDER BY id DESC LIMIT 2000", [desde])
    const tempos = amostra.map((x: any) => { const d = J(x.detail, null as any); return d && typeof d.totalMs === 'number' ? d.totalMs : x.ms_total != null ? Number(x.ms_total) : null }).filter((v: any): v is number => typeof v === 'number')
    const ms = tempos.length ? Math.round(tempos.reduce((a, b) => a + b, 0) / tempos.length) : 0
    const nota = Math.round(Number((await one('SELECT AVG(overall) AS m FROM cognition_evals WHERE created_at >= $1', [desde]))?.m || 0))
    return { respostas: tot, comIA: ia, semIA: tot - ia, falhas, fallbackCerebro: semIA, usouConhecimento: usouConh, tempoMedioMs: ms, notaMedia: nota || null }
  }
  const vias = await q("SELECT via, COUNT(*) AS n FROM brain_chat_traces WHERE created_at >= $1 AND channel = 'chat' GROUP BY via ORDER BY n DESC", [j.d7])
  const { resumoTempos } = await import('../lib/timing.js'), tempos = resumoTempos()
  return { h24: await linha(j.d1), d7: await linha(j.d7), porCaminho: vias.map((v: any) => ({ via: v.via || '—', n: Number(v.n) })), etapas: tempos.todas.etapas, medicoesEmMemoria: tempos.todas.mensagens }
}

/** Rastros unificados (rastro do Cérebro + etapas/ferramentas/ações + nota da resposta). */
export async function rastros(f: { limite?: number; via?: string; so?: 'falhas' | 'ia' | 'internas' | 'acoes' } = {}) {
  const w = ["t.channel = 'chat'"], p: any[] = []
  if (f.via) { p.push(f.via); w.push(`t.via = $${p.length}`) }
  if (f.so === 'falhas') w.push("t.failures IS NOT NULL AND t.failures <> '[]'")
  if (f.so === 'ia') { p.push(true); w.push(`t.sent_to_ai = $${p.length}`) }
  if (f.so === 'internas') { p.push(false); w.push(`t.sent_to_ai = $${p.length}`) }
  if (f.so === 'acoes') { p.push('%"feitas":["%'); w.push(`t.detail LIKE $${p.length}`) }
  p.push(Math.min(Math.max(Number(f.limite) || 40, 1), 200))
  const rs = await q(`SELECT t.*, e.overall AS nota, e.flags AS eval_flags, e.path AS eval_path FROM brain_chat_traces t LEFT JOIN cognition_evals e ON e.message_id = t.message_id AND t.message_id IS NOT NULL
    WHERE ${w.join(' AND ')} ORDER BY t.id DESC LIMIT $${p.length}`, p)
  return rs.map((x: any) => {
    const d = J(x.detail, null as any), docs = J(x.docs, [] as any[])
    return { id: Number(x.id), em: new Date(x.created_at).toISOString(), usuario: x.user_id ? Number(x.user_id) : null, conversa: x.conversation_id || null, mensagem: x.message_id ? Number(x.message_id) : null,
      pergunta: x.question, via: x.via || '', intencao: x.intent || '', tipo: d?.tipo || null, idioma: d?.idioma || null,
      fontes: docs.map((z: any) => ({ id: z.id, titulo: z.titulo, origem: z.origem })).slice(0, 6), fontesWeb: J(x.web_sources, [] as string[]).slice(0, 5),
      consultou: !!Number(x.consulted) || x.consulted === true, usouConhecimento: !!Number(x.used_knowledge) || x.used_knowledge === true,
      ia: !!Number(x.sent_to_ai) || x.sent_to_ai === true, provedor: x.provider || null, falhas: J(x.failures, [] as string[]),
      etapas: d?.etapas || null, ferramentas: d?.ferramentas || [], acoes: d?.acoes || null, especialistas: d?.especialistas || [], sinais: [...new Set([...(d?.sinais || []), ...J(x.eval_flags, [] as string[])])],
      multiagente: !!d?.multiagente, consultasBanco: d?.consultas ?? null, nota: x.nota != null ? Number(x.nota) : null, ms: d && typeof d.totalMs === 'number' ? d.totalMs : x.ms_total != null ? Number(x.ms_total) : null }
  })
}
