// Leitura LOCAL de comprovantes pela Central de Processamento de Arquivos e Mídias (OCR e regras no servidor,
// sem IA). Converte o resultado da central para o formato que o financeiro já usa (DocRead) e diz o que falta
// perguntar e o que precisa de revisão. Nunca inventa: campo não encontrado fica vazio e é perguntado.
import type { DocRead } from './docs.js'
import { processarNaCentral, centralConfigurada } from '../lib/central-midia.js'
import { getConfig } from '../lib/settings.js'

export type Politica = 'local_primeiro' | 'ia_primeiro' | 'so_local'
export async function politicaLeitura(): Promise<Politica> {
  const p = String((await getConfig<any>('leitura_local', {})).politica || 'local_primeiro')
  return (['local_primeiro', 'ia_primeiro', 'so_local'].includes(p) ? p : 'local_primeiro') as Politica
}

export interface DocLocal extends DocRead {
  origem: 'local' | 'local+ia' | 'ia'
  /** o que precisa ser perguntado antes de registrar (valor, data, direcao) */
  faltando: string[]
  /** campos lidos com confiança média/baixa: aparecem marcados para revisão */
  revisar: string[]
  /** categoria veio de uma sugestão por palavra-chave (sempre revisável) */
  categoriaSugerida: boolean
  /** sugestão de direção só pelo nome do titular (nunca decide sozinha) */
  direcaoSugerida: 'entrada' | 'saida' | null
  pagador: string
  recebedor: string
  tipoComprovante: string
  ocrConfianca: number | null
  motivosDirecao: string[]
  /** texto lido do comprovante (itens da nota, descrição): usado só para classificar, nunca mostrado */
  texto?: string
}

const sem = (s: string) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z\s]/g, ' ').replace(/\s+/g, ' ').trim()
const PART = new Set(['de', 'da', 'do', 'das', 'dos', 'e'])
/** O nome do comprovante é o do titular? Exige o primeiro nome e mais um sobrenome iguais (evita "Ana" = "Ana Paula"). */
export function mesmoTitular(titular: string, nome: string | undefined | null): boolean {
  const a = sem(titular).split(' ').filter((x) => x.length > 1 && !PART.has(x)), b = sem(nome || '').split(' ').filter((x) => x.length > 1 && !PART.has(x))
  if (!a.length || !b.length || a[0] !== b[0]) return false
  if (a.length === 1 || b.length === 1) return a.length === b.length
  return a.slice(1).some((x) => b.slice(1).includes(x))
}

export interface LeituraLocal { disponivel: boolean; motivo?: string; doc?: DocLocal }

/** Lê o comprovante na central. disponivel=false quando a central não está configurada/no ar (usa-se o caminho antigo). */
export async function lerComprovanteLocal(data: Buffer, mime: string, titular: string, userId: number): Promise<LeituraLocal> {
  if (!centralConfigurada()) return { disponivel: false, motivo: 'nao_configurada' }
  const ext = mime === 'application/pdf' ? 'pdf' : (mime.split('/')[1] || 'jpg').replace('jpeg', 'jpg')
  // o identificador vai só como número interno (registro da central); nome, e-mail e titular nunca saem do app
  const r = await processarNaCentral(data, `comprovante.${ext}`, mime, { cliente: `u${userId}`, interpretar: '0', tempoMs: 75_000 })
  if (!r.ok) {
    if (r.indisponivel) return { disponivel: false, motivo: r.codigo }
    return { disponivel: true, motivo: r.codigo, doc: vazio(r.codigo) } // arquivo recusado/corrompido: a central respondeu
  }
  const c: any = r.comprovante || null
  const legivel = r.texto.replace(/\s/g, '').length >= 15 || r.codigos.length > 0
  if (!c) return { disponivel: true, doc: { ...vazio(''), legivel, financeiro: false, ocrConfianca: r.ocr.confianca } }
  // direção: o texto decide; o nome do titular só confirma ou acusa conflito — sozinho, nunca decide
  const textual: 'entrada' | 'saida' | 'incerta' = ['entrada', 'saida'].includes(c.direcao) ? c.direcao : 'incerta'
  const titularPagou = mesmoTitular(titular, c.pagador), titularRecebeu = mesmoTitular(titular, c.recebedor)
  const pelotitular: 'entrada' | 'saida' | null = titularPagou && !titularRecebeu ? 'saida' : titularRecebeu && !titularPagou ? 'entrada' : null
  let direcao = textual
  const motivos: string[] = [...(c.direcao_motivos || [])]
  if (textual !== 'incerta' && pelotitular && pelotitular !== textual) { direcao = 'incerta'; motivos.push('o nome do titular contradiz o texto') }
  const conf = c.confianca_campos || {}
  const revisar = new Set<string>((c.revisar || []).filter((k: string) => k !== 'direcao'))
  if (direcao !== 'incerta' && conf.direcao !== 'alta' && !(pelotitular === direcao)) revisar.add('direcao')
  const faltando = [...(c.faltando || []).filter((k: string) => k !== 'direcao'), ...(direcao === 'incerta' ? ['direcao'] : [])]
  const ent = direcao === 'entrada'
  const tc = String(c.tipo || '')
  const tipo: DocRead['tipo'] = ent ? 'receita' : tc === 'boleto' ? 'pagamento' : tc === 'pix' || tc === 'transferencia' ? 'transferencia' : tc ? 'despesa' : ''
  const est = String(c.estabelecimento || (ent ? c.pagador : c.recebedor) || '')
  if (!est) revisar.add('estabelecimento')
  const doc: DocLocal = {
    legivel, financeiro: true, direcao, tipo, valor: typeof c.valor === 'number' && c.valor > 0 ? c.valor : null, data: c.data || null, hora: c.hora || null,
    estabelecimento: est.slice(0, 80), descricao: '', categoria: String(c.categoria || ''), forma_pagamento: String(c.forma_pagamento || ''),
    confianca: Number(c.confianca) || 0, resumo: '', origem: 'local', faltando: [...new Set(faltando)], revisar: [...revisar],
    categoriaSugerida: !!c.categoria, direcaoSugerida: direcao === 'incerta' ? pelotitular : null, pagador: String(c.pagador || ''), recebedor: String(c.recebedor || ''),
    tipoComprovante: tc, ocrConfianca: r.ocr.confianca, motivosDirecao: motivos, texto: r.texto.slice(0, 20000),
  }
  return { disponivel: true, doc }
}

function vazio(motivo: string): DocLocal {
  return { legivel: false, financeiro: false, direcao: 'incerta', tipo: '', valor: null, data: null, hora: null, estabelecimento: '', descricao: '', categoria: '', forma_pagamento: '', confianca: 0, resumo: motivo,
    origem: 'local', faltando: ['valor', 'data', 'direcao'], revisar: [], categoriaSugerida: false, direcaoSugerida: null, pagador: '', recebedor: '', tipoComprovante: '', ocrConfianca: null, motivosDirecao: [] }
}

/** Completa a leitura local com a da IA (nível 2 opcional): o que a central leu com confiança alta prevalece;
 *  o que só a IA trouxe entra marcado para revisão. */
export function combinar(local: DocLocal, ia: DocRead): DocLocal {
  const out: DocLocal = { ...local, origem: 'local+ia' }
  const rev = new Set(local.revisar)
  const pega = <K extends keyof DocRead>(k: K, nome: string) => { if ((out[k] === null || out[k] === '') && ia[k] !== null && ia[k] !== '') { (out as any)[k] = ia[k]; rev.add(nome) } }
  pega('valor', 'valor'); pega('data', 'data'); pega('hora', 'hora'); pega('estabelecimento', 'estabelecimento'); pega('forma_pagamento', 'forma_pagamento')
  if (!out.categoria && ia.categoria) { out.categoria = ia.categoria; out.categoriaSugerida = true; rev.add('categoria') }
  if (out.direcao === 'incerta' && ia.direcao !== 'incerta') { out.direcao = ia.direcao; out.tipo = ia.tipo || out.tipo; rev.add('direcao') }
  if (!out.legivel && ia.legivel) { out.legivel = true; out.financeiro = ia.financeiro }
  out.revisar = [...rev]
  out.faltando = [...(out.valor ? [] : ['valor']), ...(out.data ? [] : ['data']), ...(out.direcao === 'incerta' ? ['direcao'] : [])]
  return out
}
