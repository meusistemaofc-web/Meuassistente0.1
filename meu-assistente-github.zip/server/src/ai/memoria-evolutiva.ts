// MEMÓRIA EVOLUTIVA (Fase 5) — organiza e usa o que o assistente sabe de cada usuário, em camadas:
//   curto prazo ........ análise do turno, quadro dos agentes, memória da requisição (já existiam; não mudam)
//   conversação ........ contexto por conversa (convctx), histórico e planos (já existiam; não mudam)
//   longo prazo ........ tabela memories (fatos, pessoas, rotinas, metas)            ┐ agora com origem, versões,
//   preferências ....... memories do tipo "preference" + estilo das avaliações        ┘ contradição e "antiga"
//   experiências ....... tabela experiences (resultados de tarefas, planos, correções e avaliações) — NOVA, individual
// Recuperação por SIGNIFICADO (semantica.ts), associação (nomes e assunto em comum + conversas anteriores do mesmo
// usuário), limite de contexto, índice em cache invalidado quando a memória muda. Nada sai do servidor; nada de um
// usuário chega a outro; o usuário consulta, corrige, exporta e apaga tudo; a retenção é configurável por ele.
import { q, one, nowIso, J } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import * as S from './semantica.js'

const norm = (t: string) => S.nrm(t).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const dataBR = (iso: any) => { const s = String(iso || ''); return s.length >= 10 ? `${s.slice(8, 10)}/${s.slice(5, 7)}` : '' }
const PROTEGIDO = /(\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b|\b(?:\d[ -]?){13,19}\b|\b(senha|password|token|cvv)\b\S*\s*\S*)/gi

/* ======================= configurações do usuário (consentimento e retenção) ======================= */
export interface CfgMemoria { enabled: boolean; experiencias: boolean; associativa: boolean; retencao: { memoriasDias: number | null; experienciasDias: number } }
export function cfgUsuario(u: Pick<SessionUser, 'memory_settings'>): CfgMemoria {
  const m: any = u.memory_settings || {}
  return { enabled: m.enabled !== false, experiencias: m.experiencias !== false, associativa: m.associativa !== false, retencao: { memoriasDias: Number(m.retencao?.memoriasDias) || null, experienciasDias: Number(m.retencao?.experienciasDias) || 180 } }
}
export const camadaDe = (kind: string) => (kind === 'preference' ? 'preferencia' : 'longo_prazo')

/* ======================= índice por usuário (cache invalidado pela assinatura da tabela) ======================= */
interface MemDoc extends S.DocBase { camada: string; usos: number; status: string | null; atualizado: string }
const CACHE = new Map<number, { sig: string; ind: S.Indice<MemDoc> }>()
const STATS = { recuperacoes: 0, cacheAcertos: 0, ms: [] as number[] }
async function indiceMemorias(userId: number): Promise<{ ind: S.Indice<MemDoc>; doCache: boolean }> {
  const s = await one('SELECT COUNT(*) AS n, MAX(updated_at) AS m, MAX(id) AS i FROM memories WHERE user_id = $1 AND active = $2', [userId, true])
  const sig = `${s?.n}|${s?.m}|${s?.i}`, c = CACHE.get(userId)
  if (c && c.sig === sig) { CACHE.delete(userId); CACHE.set(userId, c); return { ind: c.ind, doCache: true } }
  const rows = await q('SELECT id, content, kind, use_count, status, updated_at FROM memories WHERE user_id = $1 AND active = $2 ORDER BY id DESC LIMIT 1000', [userId, true])
  const ind = S.indexar(rows.map((r: any) => ({ id: Number(r.id), texto: String(r.content), camada: camadaDe(r.kind), usos: Number(r.use_count || 0), status: r.status || null, atualizado: String(r.updated_at) })))
  CACHE.set(userId, { sig, ind }); if (CACHE.size > 300) CACHE.delete(CACHE.keys().next().value as number)
  return { ind, doCache: false }
}
export function limparCache(userId?: number) { if (userId == null) CACHE.clear(); else CACHE.delete(userId) }

/* ======================= recuperação contextual em camadas ======================= */
export interface Contexto { preferencias: string[]; fatos: string[]; associadas: string[]; experiencias: string[]; conversas: string[]; ids: number[]; meta: { ms: number; total: number; candidatos: number; doCache: boolean; caracteres: number } }
const vazio = (): Contexto => ({ preferencias: [], fatos: [], associadas: [], experiencias: [], conversas: [], ids: [], meta: { ms: 0, total: 0, candidatos: 0, doCache: false, caracteres: 0 } })
export async function contextualizar(u: SessionUser, o: { texto: string; historico?: string; convId?: string; limiteChars?: number; maxFatos?: number }): Promise<Contexto> {
  const cfg = cfgUsuario(u); if (!cfg.enabled) return vazio()
  const t0 = performance.now(), { ind, doCache } = await indiceMemorias(u.id), limite = o.limiteChars ?? 1800
  let achados = S.buscar(ind, o.texto, { k: Math.max(12, (o.maxFatos ?? 8) + 4) })
  if (achados.length < 3 && o.historico) { const extra = S.buscar(ind, o.texto + ' ' + o.historico, { k: 12, min: 1 }); const ja = new Set(achados.map((a) => a.doc.base.id)); achados = [...achados, ...extra.filter((a) => !ja.has(a.doc.base.id))] }
  achados = achados.map((a) => (a.doc.base.status === 'antiga' ? { ...a, score: a.score * 0.7 } : a)).sort((a, b) => b.score - a.score)
  const out = vazio(); out.meta.total = ind.N; out.meta.candidatos = achados.length; out.meta.doCache = doCache
  let usados = 0; const usar = (lista: string[], d: S.Doc<MemDoc>, rot = '') => { const t = rot + d.base.texto; if (usados + t.length > limite) return false; lista.push(t); usados += t.length; out.ids.push(d.base.id); return true }
  if (ind.N <= 12) { // poucas memórias: todas entram (comportamento anterior preservado), preferências primeiro
    for (const d of ind.docs.filter((x) => x.base.camada === 'preferencia')) usar(out.preferencias, d)
    for (const d of ind.docs.filter((x) => x.base.camada !== 'preferencia')) usar(out.fatos, d)
  } else {
    // preferências: as relevantes + as de comunicação (valem para qualquer resposta), até 4
    const prefs = [...achados.filter((a) => a.doc.base.camada === 'preferencia').map((a) => a.doc), ...ind.docs.filter((d) => d.base.camada === 'preferencia' && d.conc.has('comunicacao'))]
    for (const d of [...new Map(prefs.map((d) => [d.base.id, d])).values()].slice(0, 4)) usar(out.preferencias, d)
    for (const a of achados.filter((a) => a.doc.base.camada !== 'preferencia').slice(0, o.maxFatos ?? 8)) usar(out.fatos, a.doc)
    if (cfg.associativa) for (const a of S.associar(ind, achados.slice(0, 6), 3, o.texto)) if (!out.ids.includes(a.doc.base.id)) usar(out.associadas, a.doc)
  }
  if (cfg.experiencias) for (const e of await experienciasRelevantes(u.id, o.texto, 3)) { if (usados + e.length > limite) break; out.experiencias.push(e); usados += e.length }
  if (cfg.associativa && o.convId !== undefined) for (const c of await conversasRelacionadas(u.id, o.convId || '', o.texto, 2)) { if (usados + c.length > limite) break; out.conversas.push(c); usados += c.length }
  if (out.ids.length && ind.N > 12) void q(`UPDATE memories SET use_count = use_count + 1, last_used_at = $1, status = NULL WHERE user_id = $2 AND id IN (${out.ids.map((_, i) => '$' + (i + 3)).join(',')})`, [nowIso(), u.id, ...out.ids]).catch(() => {})
  out.meta.ms = Math.round((performance.now() - t0) * 10) / 10; out.meta.caracteres = usados
  STATS.recuperacoes++; if (doCache) STATS.cacheAcertos++; STATS.ms.push(out.meta.ms); if (STATS.ms.length > 500) STATS.ms.shift()
  return out
}
/** Busca do próprio usuário (página "Minha memória"): resultados com o MOTIVO de cada um. */
export async function pesquisar(userId: number, consulta: string) {
  const { ind } = await indiceMemorias(userId), a = S.buscar(ind, consulta, { k: 15, min: 0.5 })
  return a.map((x) => ({ id: x.doc.base.id, conteudo: x.doc.base.texto, camada: x.doc.base.camada, relevancia: Math.round(x.score * 10) / 10, motivos: x.motivos }))
}

/* ======================= experiências (individuais) ======================= */
const ROTULO: Record<string, string> = { create_appointment: 'Agendar', update_appointment: 'Alterar compromisso', create_task: 'Criar tarefa', create_reminder: 'Criar lembrete', register_transaction: 'Registrar lançamento', create_bill: 'Cadastrar conta', add_shopping_items: 'Lista de compras', create_note: 'Anotação', complete_task: 'Concluir tarefa', save_memory: 'Guardar memória' }
export const rotuloFerramenta = (n: string) => ROTULO[n] || (n.startsWith('crm_') ? 'CRM' : n.startsWith('agenda_empresa_') ? 'Agenda da empresa' : n.startsWith('negocio_') ? 'Análise do negócio' : n)
export async function registrarExperiencia(u: Pick<SessionUser, 'id' | 'memory_settings'>, e: { kind: 'tarefa' | 'plano' | 'correcao' | 'feedback'; tool?: string; outcome: string; summary: string; conversationId?: string; base?: string }) {
  const cfg = cfgUsuario(u); if (!cfg.enabled || !cfg.experiencias) return null
  const summary = String(e.summary || '').replace(PROTEGIDO, '[omitido]').replace(/\s+/g, ' ').trim().slice(0, 220); if (!summary) return null
  const concepts = [...new Set([...S.termos(summary + ' ' + String(e.base || '').replace(PROTEGIDO, '')), ...S.conceitosDe(S.termos(summary + ' ' + (e.base || '')))])].slice(0, 24)
  await q('INSERT INTO experiences (user_id, kind, tool, outcome, summary, concepts, conversation_id, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [u.id, e.kind, e.tool || null, e.outcome, summary, JSON.stringify(concepts), e.conversationId || null, nowIso()])
  // limite por usuário (desempenho): as 1000 mais recentes ficam
  await q('DELETE FROM experiences WHERE user_id = $1 AND id < (SELECT MIN(id) FROM (SELECT id FROM experiences WHERE user_id = $1 ORDER BY id DESC LIMIT 1000) t)', [u.id]).catch(() => {})
  return true
}
/** Registra o resultado das ferramentas de um turno (só ações; leituras não viram experiência). */
export async function experienciasDoTurno(u: SessionUser, done: { name: string; args?: any; result: any }[], somenteLeitura: Set<string>, convId: string, texto: string) {
  for (const d of done) {
    if (somenteLeitura.has(d.name)) continue
    const r = d.result || {}, obj = String(d.args?.title || d.args?.name || d.args?.description || d.args?.content || d.args?.query || '').slice(0, 60)
    const outcome = r.ok === true ? 'sucesso' : r.precisaConfirmar || r.conflito ? 'aguardando' : 'falha'
    await registrarExperiencia(u, { kind: 'tarefa', tool: d.name, outcome, summary: `${rotuloFerramenta(d.name)}${obj ? `: "${obj}"` : ''}${outcome === 'falha' && r.error ? ` — ${String(r.error).slice(0, 90)}` : outcome === 'aguardando' ? ' — aguardou confirmação' : ''}`, conversationId: convId, base: texto }).catch(() => {})
  }
}
const ROT_OUT: Record<string, string> = { sucesso: 'deu certo', falha: 'falhou', aguardando: 'aguardou confirmação', corrigido: 'o usuário corrigiu', aprovado: 'avaliada como útil', reprovado: 'avaliada como não útil' }
export async function experienciasRelevantes(userId: number, texto: string, k = 3): Promise<string[]> {
  const rows = await q('SELECT id, kind, tool, outcome, summary, concepts, created_at FROM experiences WHERE user_id = $1 ORDER BY id DESC LIMIT 300', [userId]).catch(() => [] as any[])
  if (!rows.length) return []
  const ind = S.indexar(rows.map((r: any) => ({ id: Number(r.id), texto: `${r.summary} ${J<string[]>(r.concepts, []).join(' ')}`, r })))
  return S.buscar(ind, texto, { k: 8, min: 0.2 }).filter((a) => suficiente(a, texto)).map((a) => ({ a, peso: a.score + (['falha', 'corrigido', 'reprovado'].includes(a.doc.base.r.outcome) ? 1 : 0) })).sort((x, y) => y.peso - x.peso).slice(0, k)
    .map(({ a }) => `${dataBR(a.doc.base.r.created_at)} · ${a.doc.base.r.summary} → ${ROT_OUT[a.doc.base.r.outcome] || a.doc.base.r.outcome}`)
}
/** Conjuntos pequenos (experiências, títulos de conversa) dão peso estatístico baixo mesmo a acertos reais: além da nota,
 *  vale ter 2+ termos distintos em comum, o mesmo assunto ou o mesmo nome próprio. Um único termo solto não basta. */
function suficiente(a: { score: number; motivos: string[]; doc: { toks: string[] } }, texto: string) {
  if (a.score >= 1.2 || a.motivos.some((m) => m.startsWith('conceito:') || m === 'nome')) return true
  const d = new Set(a.doc.toks); return new Set(S.termos(texto).filter((t) => d.has(t))).size >= 2
}
/** Conversas anteriores DO MESMO usuário com assunto parecido (só o título e a data). */
export async function conversasRelacionadas(userId: number, convId: string, texto: string, k = 2): Promise<string[]> {
  const rows = await q("SELECT id, title, updated_at FROM conversations WHERE user_id = $1 AND id <> $2 AND title IS NOT NULL ORDER BY updated_at DESC LIMIT 200", [userId, convId]).catch(() => [] as any[])
  const uteis = rows.filter((r: any) => String(r.title).trim().length > 3 && !/^(nova conversa|conversa|chat|sem t[ií]tulo)$/i.test(String(r.title).trim()))
  if (!uteis.length) return []
  const ind = S.indexar(uteis.map((r: any) => ({ id: 0, texto: String(r.title), r })))
  // títulos são curtos e poucos (o peso estatístico fica baixo): vale termo forte, mesmo assunto ou o mesmo nome próprio
  return S.buscar(ind, texto, { k: k * 3, min: 0.2 }).filter((a) => suficiente(a, texto)).slice(0, k).map((a) => `"${String(a.doc.base.r.title).slice(0, 80)}" (${dataBR(a.doc.base.r.updated_at)})`)
}

/* ======================= controle de atualização: versões, contradição, antigas, duplicatas ======================= */
export async function atualizarComHistorico(userId: number, id: number, novo: string, o: { motivo: string; conversa?: string | null }) {
  const m = await one('SELECT content, versions, created_at, updated_at FROM memories WHERE id = $1 AND user_id = $2', [id, userId]); if (!m) return false
  const conteudo = String(novo || '').trim().slice(0, 600); if (!conteudo || norm(conteudo) === norm(m.content)) return false
  const versoes = J<any[]>(m.versions, []); versoes.push({ conteudo: m.content, de: String(m.updated_at || m.created_at), ate: nowIso(), motivo: o.motivo, origem: o.conversa || null })
  await q('UPDATE memories SET content = $1, versions = $2, updated_at = $3, status = NULL, origin_conversation_id = COALESCE($4, origin_conversation_id) WHERE id = $5 AND user_id = $6', [conteudo, JSON.stringify(versoes.slice(-20)), nowIso(), o.conversa || null, id, userId])
  return true
}
export async function restaurarVersao(userId: number, id: number, indice: number) {
  const m = await one('SELECT versions FROM memories WHERE id = $1 AND user_id = $2', [id, userId]); const v = J<any[]>(m?.versions, [])
  if (!m || !v[indice]) return false
  return atualizarComHistorico(userId, id, v[indice].conteudo, { motivo: `restaurada a versão de ${dataBR(v[indice].de)}` })
}
/** Marca como "antiga" a memória sem uso há muito tempo (continua guardada e consultável; só perde prioridade). */
export async function marcarAntigas(dias = 180, userId?: number) {
  const corte = new Date(Date.now() - dias * 864e5).toISOString()
  await q(`UPDATE memories SET status = 'antiga' WHERE active = $1 AND status IS NULL AND COALESCE(last_used_at, updated_at) < $2${userId ? ' AND user_id = $3' : ''}`, userId ? [true, corte, userId] : [true, corte]).catch(() => {})
}
/** Une duplicatas do usuário: a mais recente fica; as outras entram no histórico dela (nada se perde). */
export async function organizar(userId: number) {
  const rows = await q('SELECT id, content, versions, created_at, updated_at FROM memories WHERE user_id = $1 AND active = $2 ORDER BY id DESC', [userId, true])
  const toks = rows.map((r: any) => new Set(S.termos(r.content))), unidos = new Set<number>(); let n = 0
  for (let i = 0; i < rows.length; i++) {
    if (unidos.has(i)) continue
    for (let j = i + 1; j < rows.length; j++) {
      if (unidos.has(j)) continue
      const A = toks[i], B = toks[j]; let c = 0; for (const x of A) if (B.has(x)) c++
      const sim = A.size + B.size - c ? c / (A.size + B.size - c) : 0
      if (norm(rows[i].content) === norm(rows[j].content) || (sim >= 0.85 && /\b(nao|nunca)\b/.test(S.nrm(rows[i].content)) === /\b(nao|nunca)\b/.test(S.nrm(rows[j].content)))) {
        const v = J<any[]>(rows[i].versions, []); v.push({ conteudo: rows[j].content, de: String(rows[j].created_at), ate: nowIso(), motivo: 'duplicata unida', origem: null }, ...J<any[]>(rows[j].versions, []))
        await q('UPDATE memories SET versions = $1 WHERE id = $2 AND user_id = $3', [JSON.stringify(v.slice(-20)), rows[i].id, userId]); rows[i].versions = JSON.stringify(v)
        await q('DELETE FROM memories WHERE id = $1 AND user_id = $2', [rows[j].id, userId]); unidos.add(j); n++
      }
    }
  }
  await marcarAntigas(180, userId); limparCache(userId)
  return { unidas: n }
}

/* ======================= privacidade: retenção, exportação, exclusão ======================= */
/** Retenção configurada POR USUÁRIO: experiências (padrão 180 dias) e, só se ele escolher, memórias sem uso. */
export async function aplicarRetencao() {
  let exp = 0, mem = 0
  for (const u of await q('SELECT id, memory_settings FROM users').catch(() => [] as any[])) {
    const c = cfgUsuario({ memory_settings: J<any>(u.memory_settings, {}) }), id = Number(u.id)
    const r1 = await q('DELETE FROM experiences WHERE user_id = $1 AND created_at < $2 RETURNING id', [id, new Date(Date.now() - c.retencao.experienciasDias * 864e5).toISOString()]).catch(() => [] as any[]); exp += r1.length
    if (c.retencao.memoriasDias) { const r2 = await q('DELETE FROM memories WHERE user_id = $1 AND COALESCE(last_used_at, updated_at) < $2 RETURNING id', [id, new Date(Date.now() - c.retencao.memoriasDias * 864e5).toISOString()]).catch(() => [] as any[]); mem += r2.length; if (r2.length) limparCache(id) }
  }
  await marcarAntigas(180)
  return { experienciasRemovidas: exp, memoriasRemovidas: mem }
}
export async function exportar(u: SessionUser) {
  const mems = await q('SELECT * FROM memories WHERE user_id = $1 ORDER BY id', [u.id]), exps = await q('SELECT kind, tool, outcome, summary, conversation_id, created_at FROM experiences WHERE user_id = $1 ORDER BY id', [u.id])
  const prefs = await one('SELECT style, proactive FROM user_intel_prefs WHERE user_id = $1', [u.id]).catch(() => null)
  const learn = await q("SELECT operation, kind, rule, scope, state, created_at FROM learnings WHERE user_id = $1 ORDER BY id", [u.id]).catch(() => [] as any[])
  const ctx = await q('SELECT conversation_id, estado, updated_at FROM conversation_context WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 200', [u.id]).catch(() => [] as any[])
  const mem = (r: any) => ({ id: Number(r.id), conteudo: r.content, tipo: r.kind, camada: camadaDe(r.kind), origem: r.source, conversaDeOrigem: r.origin_conversation_id || null, criadaEm: r.created_at, atualizadaEm: r.updated_at, ultimoUso: r.last_used_at || null, usos: Number(r.use_count || 0), ativa: r.active === true || r.active === 1, situacao: r.status || 'atual', versoesAnteriores: J<any[]>(r.versions, []) })
  return {
    geradoEm: nowIso(), configuracoes: cfgUsuario(u),
    camadas: {
      longoPrazo: mems.filter((r: any) => r.kind !== 'preference').map(mem), preferencias: mems.filter((r: any) => r.kind === 'preference').map(mem),
      preferenciasAprendidas: { estilo: J<any>(prefs?.style, {}), sugestoesProativas: prefs ? !(prefs.proactive === false || prefs.proactive === 0) : true, regras: learn },
      experiencias: exps, conversacao: ctx.map((r: any) => ({ conversa: r.conversation_id, estado: J<any>(r.estado, {}), atualizadoEm: r.updated_at })),
    },
  }
}

/* ======================= indicadores para o painel (só números) ======================= */
export async function indicadores() {
  const n = async (sql: string) => Number((await one(sql).catch(() => null))?.n || 0)
  const med = STATS.ms.length ? Math.round((STATS.ms.reduce((a, b) => a + b, 0) / STATS.ms.length) * 10) / 10 : null
  return {
    longoPrazo: await n("SELECT COUNT(*) AS n FROM memories WHERE active = TRUE AND kind <> 'preference'"), preferencias: await n("SELECT COUNT(*) AS n FROM memories WHERE active = TRUE AND kind = 'preference'"),
    antigas: await n("SELECT COUNT(*) AS n FROM memories WHERE status = 'antiga'"), comVersoes: await n("SELECT COUNT(*) AS n FROM memories WHERE versions IS NOT NULL AND versions <> '[]'"),
    experiencias: await n('SELECT COUNT(*) AS n FROM experiences'), usuariosComMemoria: await n('SELECT COUNT(DISTINCT user_id) AS n FROM memories'),
    recuperacoes: STATS.recuperacoes, msMedio: med, taxaCache: STATS.recuperacoes ? Math.round((STATS.cacheAcertos / STATS.recuperacoes) * 100) : null,
  }
}
