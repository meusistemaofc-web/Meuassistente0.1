// Agendamento inteligente pelo chat — complementa o motor de continuidade (convctx.ts), sem IA:
//  • extrai cliente, telefone, valor total, sinal (em % ou em R$), pagamento informado, observação e situação;
//  • calcula sinal e saldo pelas regras únicas de lib/appt-fin.ts (nunca confunde % com R$: número solto é ambíguo e é perguntado);
//  • com informação financeira ou ambiguidade, mostra um resumo e só grava depois do "sim";
//  • pagamento só é registrado como recebido quando o usuário diz que foi pago (na frase ou na confirmação);
//  • grava UM compromisso: a confirmação é consumida antes de gravar e o mesmo pedido não é gravado duas vezes.
import type { SessionUser } from '../lib/session.js'
import { aplicarFinanceiro, linhasFinanceiras, brl, r2 } from '../lib/appt-fin.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const numBR = (t: string) => { let x = String(t).trim(); if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(x)) x = x.replace(/\./g, ''); return Number(x.replace(',', '.')) }
const PARA = '\\s*(?:(?:de|:|=|no valor de|em|com)\\s*)?'

export interface Detalhes {
  cliente_nome?: string; cliente_telefone?: string; valor_total?: number; sinal_pct?: number; sinal?: number
  sinal_ambiguo?: number; pago?: 'sinal' | 'total' | number; observacao?: string; status?: 'confirmed'; semHorario?: boolean
}

/** Detalhes do agendamento ditos em linguagem natural (uma ou várias mensagens). Nunca inventa: o que não veio fica de fora. */
export function extrairDetalhes(texto: string): Detalhes {
  const out: Detalhes = {}
  let t = String(texto || '')
  // observação: tudo depois de "observação:" / "obs:" (fica fora das demais leituras)
  const om = t.match(/\b(?:observa[çc](?:[ãa]o|[õo]es)|obs\.?|anota[çc][ãa]o)\s*[:\-–]\s*([\s\S]+)$/i) || t.match(/\b(?:observa[çc][ãa]o|obs\.?)\s+(?:que\s+)?([\s\S]{3,})$/i)
  if (om) { out.observacao = om[1].trim().replace(/[.;\s]+$/, '').slice(0, 500); t = t.slice(0, om.index) }
  // telefone (só dígitos, 10 a 13); sai do texto para não virar valor
  const tm = t.match(/\b(?:telefone|tel\.?|fone|celular|cel\.?|whats(?:app)?|zap|contato)\b(?:\s+d[oa]\s+client[ea])?\s*[:\-]?\s*((?:\+?55\s*)?\(?\d{2}\)?[\s.-]*9?[\s.-]*\d{4}[\s.-]?\d{4})/i) || t.match(/((?:\+?55\s*)?\(\d{2}\)\s*9?\d{4}[-\s]?\d{4}|\b\d{2}\s?9\d{4}[-\s]?\d{4}\b)/)
  if (tm) { const dg = tm[1].replace(/\D/g, ''); if (dg.length >= 10 && dg.length <= 13) out.cliente_telefone = dg; t = t.replace(tm[0], ' ') }
  // cliente: "cliente José", "para o cliente José Silva", "nome do cliente: Ana"
  const cm = t.match(/\b(?:nome d[oa] client[ea]|client[ea])\s*[:\-]?\s*(?:é\s+|e\s+)?([A-Za-zÀ-ÿ][\wÀ-ÿ'-]+(?:\s+(?!(?:e|de|da|do|com|no|na|dia|telefone|tel|valor|sinal|para|pra)\b)[A-ZÀ-Ý][\wÀ-ÿ'-]+){0,2})/i)
  if (cm && !/^(novo|nova|que|vai|ja|já|pagou|quer)$/i.test(cm[1])) out.cliente_nome = cm[1].replace(/^./, (x) => x.toUpperCase()).slice(0, 120)
  const s = nrm(t)
  // sinal: "sinal de 50%", "50% de sinal", "sinal de R$ 80", "80 reais de entrada", "metade de sinal"
  const N = '(\\d{1,3}(?:\\.\\d{3})+(?:,\\d{1,2})?|\\d+(?:,\\d{1,2})?)'
  let sm = s.match(new RegExp(`\\b(?:sinal|entrada|adiantamento)${PARA}(r\\$\\s*)?${N}\\s*(%|por cento|reais|real)?`))
  let sinalTxt = sm ? sm[0] : ''
  if (sm) { const v = numBR(sm[2]); if (sm[3] === '%' || sm[3] === 'por cento') out.sinal_pct = v; else if (sm[1] || sm[3]) out.sinal = r2(v); else if (v > 100) out.sinal = r2(v); else out.sinal_ambiguo = v }
  else if ((sm = s.match(new RegExp(`(r\\$\\s*)?${N}\\s*(%|por cento|reais|real)?\\s*(?:de|como|do)\\s+(?:sinal|entrada|adiantamento)\\b`)))) {
    sinalTxt = sm[0]; const v = numBR(sm[2]); if (sm[3] === '%' || sm[3] === 'por cento') out.sinal_pct = v; else if (sm[1] || sm[3]) out.sinal = r2(v); else if (v > 100) out.sinal = r2(v); else out.sinal_ambiguo = v
  } else if (/\b(metade (de|do|como) (sinal|entrada)|(sinal|entrada) (de|da) metade)\b/.test(s)) out.sinal_pct = 50
  // valor total: "valor de R$ 200", "custa 200 reais", "total R$ 1.200,00", "por R$ 150"; ou o "R$" que não é do sinal
  const sv = s.replace(sinalTxt, ' ')
  const vm = sv.match(new RegExp(`\\b(?:valor(?: total)?|total|preco|custa|custo|cobr\\w*|fica(?:r)? (?:em|por)|por)${PARA}(?:e\\s+)?(r\\$\\s*)?${N}\\s*(reais|real)?(?!\\s*(?:%|h\\b|horas?|:|\\/))`)) || sv.match(new RegExp(`(r\\$)\\s*${N}()`)) || sv.match(new RegExp(`()${N}\\s*(reais)\\b`))
  if (vm) { const v = numBR(vm[2]); if (v > 0) out.valor_total = r2(v) }
  // pagamento já feito (só quando dito): "já pagou o sinal", "pagou tudo", "recebi R$ 50"
  if (/\b(ja pagou|pagou|foi pago|ja pago|recebi|recebemos|ja recebi|depositou|adiantou)\b/.test(s) && !/\b(vai pagar|ira pagar|nao pagou|ainda nao|pagar depois|vai dar)\b/.test(s)) {
    if (/\b(pagou tudo|pago tudo|pagou o total|pagou o valor (todo|total|inteiro)|ja esta pago|quitou)\b/.test(s)) out.pago = 'total'
    else if (/\b(sinal|entrada|adiantamento)\b/.test(s)) out.pago = 'sinal'
    else { const pm = s.match(new RegExp(`\\b(?:pagou|recebi|recebemos|depositou)${PARA}(r\\$\\s*)?${N}`)); if (pm) out.pago = r2(numBR(pm[2])) }
  }
  if (/\b(ja )?confirmad[oa]\b/.test(s) && !/\bnao confirmad/.test(s)) out.status = 'confirmed'
  if (/\b(sem (horario|hora)( definid[oa])?|dia (todo|inteiro)|qualquer horario|nao sei (o )?horario|horario a (definir|combinar))\b/.test(nrm(texto))) out.semHorario = true
  return out
}

/** Há algo além de serviço/data/hora (cliente, contato, valores, observação)? */
export const temDetalhes = (d: any) => ['cliente_nome', 'cliente_telefone', 'valor_total', 'sinal_pct', 'sinal', 'sinal_ambiguo', 'pago', 'observacao', 'status'].some((k) => d[k] !== undefined)
/** Precisa de confirmação: há valores, pagamento ou ambiguidade. */
export const precisaConfirmar = (d: any) => ['valor_total', 'sinal_pct', 'sinal', 'sinal_ambiguo', 'pago'].some((k) => d[k] !== undefined)

/** Campos financeiros normalizados (para gravar) — lança erro legível quando incoerentes. */
export function financeiroDe(c: any) {
  const d: any = {}
  if (c.valor_total !== undefined) d.valor_total = c.valor_total
  if (c.sinal_pct !== undefined) d.sinal_pct = c.sinal_pct
  else if (c.sinal !== undefined) d.sinal = c.sinal
  const f = aplicarFinanceiro({}, d)
  let pago: number | null = null
  if (c.pago === 'total') pago = f.valorTotal
  else if (c.pago === 'sinal') pago = f.sinal
  else if (typeof c.pago === 'number') pago = c.pago
  if (pago !== null) Object.assign(f, aplicarFinanceiro(f, { valor_pago: pago }))
  return f
}

/** Problema que impede salvar (pergunta objetiva), ou '' quando está tudo coerente. */
export function problemaFinanceiro(c: any): string {
  if (c.sinal_ambiguo !== undefined) return `O sinal de ${String(c.sinal_ambiguo).replace('.', ',')} é **${String(c.sinal_ambiguo).replace('.', ',')}%** do valor ou **${brl(c.sinal_ambiguo)}**? (responda "%" ou "reais")`
  if (c.sinal_pct !== undefined && c.valor_total === undefined) return `O sinal é de ${String(c.sinal_pct).replace('.', ',')}%. Qual é o valor total do serviço, para eu calcular o sinal em reais?`
  if (c.pago === 'total' && c.valor_total === undefined) return 'Qual foi o valor total pago?'
  if (c.pago === 'sinal' && c.sinal === undefined && c.sinal_pct === undefined) return 'De quanto foi o sinal pago?'
  try { financeiroDe(c) } catch (e: any) { return (e?.message || 'Os valores não batem.') + ' Pode corrigir?' }
  return ''
}

const fmtTel = (t: string) => { const d = t.replace(/^55(?=\d{10,11}$)/, ''); return d.replace(/^(\d{2})(\d{4,5})(\d{4})$/, '($1) $2-$3') }
/** Resumo para o usuário conferir antes de salvar. */
export function resumoConfirmacao(c: any, dataTxt: string): string {
  const L = [`Serviço: ${c.title}`, `Data: ${dataTxt}${c.time ? ' às ' + c.time : ' (sem horário definido)'}`]
  if (c.cliente_nome || c.person) L.push(`Cliente: ${c.cliente_nome || c.person}`)
  if (c.cliente_telefone) L.push(`Telefone: ${fmtTel(c.cliente_telefone)}`)
  if (c.location) L.push(`Local: ${c.location}`)
  let fin: any = {}; try { fin = financeiroDe(c) } catch { /* problema já perguntado */ }
  L.push(...linhasFinanceiras(fin))
  if (c.observacao) L.push(`Observação: ${c.observacao}`)
  L.push(`Situação: ${c.status === 'confirmed' ? 'Confirmado' : 'Agendado'}`)
  const pagoTxt = c.pago !== undefined && fin.valorPago ? `\n\nAo confirmar, também registro ${brl(fin.valorPago)} como **recebido** no financeiro.` : (fin.sinal ? '\n\nO sinal fica como **combinado** (não recebido). Se já foi pago, responda "sim, sinal pago".' : '')
  return `Confere antes de eu salvar:\n- ${L.join('\n- ')}${pagoTxt}\n\nPosso salvar? (sim / não, ou me diga o que corrigir)`
}

/** Resposta do usuário à confirmação. */
export function lerConfirmacao(text: string): 'sim' | 'sim_pago' | 'nao' | 'pct' | 'reais' | null {
  const s = nrm(text).replace(/[!.,]+/g, ' ').replace(/\s+/g, ' ').trim()
  if (/^(%|porcento|por cento|percentual|porcentagem|e porcentagem|em porcentagem|em %)$/.test(s) || /^\d+ ?%$/.test(s)) return 'pct'
  if (/^(reais|r\$|em reais|valor em reais|real|dinheiro|e em reais)$/.test(s)) return 'reais'
  if (/^(sim|s|pode|pode salvar|confirmo|confirma|confirmado|isso|ok|certo|salva|salvar|pode sim|tudo certo|correto|perfeito)\b/.test(s)) return /\b(sinal|entrada)\s+(ja\s+)?(foi\s+)?(pago|recebido)|\bja (pagou|recebi)|\bpago\b/.test(s) ? 'sim_pago' : 'sim'
  if (/^(sinal (ja )?(foi )?pago|ja pagou( o sinal)?|o sinal ja foi pago)$/.test(s)) return 'sim_pago'
  if (/^(nao|n|cancela|cancelar|esquece|deixa|desisto|nao quero)\b/.test(s) && s.split(' ').length <= 4) return 'nao'
  return null
}
export type { SessionUser }
