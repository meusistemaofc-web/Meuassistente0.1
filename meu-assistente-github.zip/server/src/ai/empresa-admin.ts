// Administrador conversacional da empresa ATIVA: o chat lê e altera configurações reais da empresa (perfil, horário,
// pedidos, entrega, frete grátis, pagamento, atendimento e produtos/variações) pelas ROTAS OFICIAIS do sistema — as mesmas
// validações e gravações das telas de "Sua empresa" —, confere cada alteração relendo o banco e só então responde.
//
// Regras de segurança:
//  • empresa = a ATIVA do usuário (empresa_contexto, a mesma do seletor "Trocar de empresa"); com uma empresa só, ela mesma.
//    Nunca a primeira da lista, a anterior ou outra vinculada: com várias e nenhuma ativa, o chat pede para escolher;
//  • empresa de outra conta (vínculo): mesma delegação do painel (vínculo válido, usuário comum, ações bloqueadas recusadas);
//  • produtos e variações só são procurados DENTRO da empresa ativa (id de outra empresa = não encontrado);
//  • nunca mexe em credenciais, tokens, chave Pix, Mercado Pago, plano, pagamento do anúncio ou exclusão da empresa;
//  • ações de impacto (pausar todos os pedidos, excluir produto, trocar nome/endereço, desligar o Pix automático) só depois
//    de confirmação explícita: a 1ª chamada devolve um código; a ação só roda quando a IA reenvia o código após o "sim".
import { q, one, J } from '../db/index.js'
import { HttpError } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import type { ToolDef } from './provider.js'

const nrm = (v: any) => String(v ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim()
const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',')
const DIAS = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'] as const
const DIA_NOME: Record<string, string> = { seg: 'segunda', ter: 'terça', qua: 'quarta', qui: 'quinta', sex: 'sexta', sab: 'sábado', dom: 'domingo' }

/* ---------- empresa ativa ---------- */
export interface Ativa { b: any; x: any; nome: string; propria: boolean }
export async function empresaAtiva(u: SessionUser): Promise<{ ok: true; e: Ativa } | { ok: false; erro: string; opcoes?: string[] }> {
  const proprias = await q("SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') ORDER BY id", [u.id])
  const vinc = await (await import('../lib/vinculos.js')).vinculadasValidas(u.id).catch(() => [] as any[])
  const todas = [...proprias.map((b: any) => ({ b, propria: true })), ...vinc.map((b: any) => ({ b, propria: false }))]
  const nomeDe = (b: any) => String(J<any>(b.data, {}).empresa || 'Empresa')
  if (!todas.length) return { ok: false, erro: 'Você não tem empresa cadastrada. As configurações de empresa pelo chat são para donos de empresa.' }
  const c = await one('SELECT business_id FROM empresa_contexto WHERE user_id = $1', [u.id])
  let esc = c?.business_id != null ? todas.find((t) => Number(t.b.id) === Number(c.business_id)) : undefined
  if (c?.business_id != null && !esc) { // a empresa escolhida deixou de valer (vínculo suspenso, lixeira, dono mudou): nunca cai em outra sozinho
    const V = await import('../lib/vinculos.js'), v = await V.validar(Number(u.id), Number(c.business_id)).catch(() => null), b0 = await one('SELECT data FROM businesses WHERE id = $1', [c.business_id])
    return { ok: false, erro: `A empresa ativa${b0 ? ` (${nomeDe(b0)})` : ''} não está disponível agora${v && !v.ok ? `: ${v.motivo}` : '.'} Nada foi alterado. Escolha outra empresa em Sua empresa → Trocar de empresa (ou diga qual).`, opcoes: todas.map((t) => nomeDe(t.b)) }
  }
  if (!esc && todas.length === 1) esc = todas[0]
  if (!esc) return { ok: false, erro: 'Você tem mais de uma empresa e nenhuma está selecionada como ativa. Diga qual empresa quer administrar (ou escolha em Sua empresa → Trocar de empresa).', opcoes: todas.map((t) => nomeDe(t.b)) }
  const { gestaoLiberada } = await import('../lib/painel-empresa.js')
  if (!gestaoLiberada(esc.b)) return { ok: false, erro: `O painel da ${nomeDe(esc.b)} ainda não está liberado (anúncio em análise, recusado ou revogado), então não consigo alterar as configurações dela.` }
  return { ok: true, e: { b: esc.b, x: J<any>(esc.b.data, {}), nome: nomeDe(esc.b), propria: esc.propria } }
}
/** O chat recebe as ferramentas quando o usuário tem alguma empresa (própria ou vinculada). */
export const empresaAdminDisponivel = async (u: SessionUser) => (await q("SELECT id FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') LIMIT 1", [u.id])).length > 0 || (await (await import('../lib/vinculos.js')).vinculadasValidas(u.id).catch(() => [])).length > 0

/* ---------- execução pela rota oficial ---------- */
export async function chamar(u: SessionUser, e: Ativa, method: string, path: string, body?: any): Promise<any> {
  const A = await import('../app.js'), r = A.rotaInterna(method, path)
  if (!r) throw new HttpError(500, 'Rota interna indisponível.', 'interno')
  let user: any = u
  if (!e.propria) { // empresa de outra conta: a mesma delegação do painel ("Trocar de empresa")
    const V = await import('../lib/vinculos.js'), esc = V.escopoEmpresa(method, path)
    if (!esc || esc.id !== String(e.b.id)) throw new HttpError(403, 'Esta ação não pode ser feita por vínculo.', 'vinculo_acao_bloqueada')
    if (esc.bloqueado) throw new HttpError(403, 'Esta ação só pode ser feita entrando na conta dona da empresa.', 'vinculo_acao_bloqueada')
    const v = await V.validar(Number(u.id), Number(e.b.id)); if (!v.ok) throw new HttpError(403, v.motivo, 'vinculo_' + v.codigo)
    user = V.usuarioDelegado(v.owner)
    if (method !== 'GET') await (await import('../lib/account.js')).audit(Number(u.id), 'vinculo.acao', Number(e.b.id), { metodo: method, rota: path.replace(/\d{6,}/g, '#'), via: 'chat' }).catch(() => {})
  }
  const url = new URL('http://interno' + path)
  const ctx: any = { req: { headers: {} }, res: null, method, path, url, query: url.searchParams, ip: 'chat', body: body || {}, cookies: {}, setCookies: [], params: r.params, user,
    session: { id: 'chat', user_id: Number(user.id), mfa_pending: false, recovery: false, reauth_at: null } }
  return r.handler(ctx)
}
export const dados = async (bid: number) => J<any>((await one('SELECT data FROM businesses WHERE id = $1', [bid]))?.data, {})

/* ---------- leitura (empresa_consultar) ---------- */
export async function produtos(bid: number) {
  const rows = await q('SELECT id, active, stock, data FROM products WHERE business_id = $1 ORDER BY id', [bid]) as any[]
  const CAT = await import('../lib/catalogo.js'), vm = await CAT.variantesDe(rows.map((r) => Number(r.id)))
  return rows.map((r) => { const d = J<any>(r.data, {}); return { id: Number(r.id), nome: String(d.nome || ''), tipo: d.tipo === 'servico' ? 'servico' : 'produto', ativo: r.active === true || r.active === 1 || r.active === 't', preco: Number(d.preco) || 0, oferta: d.oferta?.ativo ? Number(d.oferta.preco) : null, estoque: r.stock == null ? null : Number(r.stock), categoria: d.categoria || '', descricao: String(d.descricao || ''),
    variacoes: (vm.get(Number(r.id)) || []).map((v) => ({ id: v.id, rotulo: CAT.rotuloVariante(v), preco: v.preco, oferta: v.oferta?.ativo ? v.oferta.preco : null, estoque: v.estoque, disponivel: v.disponivel })) } })
}
function resumoEmpresa(e: Ativa, x: any) {
  const h = x.horarioCfg || {}, ent = x.entrega || {}, pg = x.pagamento || {}
  return { empresa: e.nome, id: Number(e.b.id), contaPropria: e.propria, descricao: x.sobre || x.texto || '', whatsapp: x.zap || '', instagram: x.insta || '', endereco: x.endereco || '', contato: x.contato || '', link: x.link || '',
    horario: { modo: h.modo || 'auto', texto: x.horario || '', dias: Object.fromEntries(DIAS.map((k) => [k, h.dias?.[k] ? `${h.dias[k].ativo ? 'aberto' : 'fechado'} ${h.dias[k].abre}-${h.dias[k].fecha}` : 'não configurado'])) },
    pedidos: h.modo === 'fechado' ? 'pausados (loja fechada)' : 'recebendo (conforme o horário)',
    entrega: { entrega: !!ent.entrega, retirada: ent.retirada !== false, taxa: Number(ent.taxa) || 0, modoTaxa: ent.modoTaxa || 'fixa', raioKm: Number(ent.raio ?? 3), pedidoMinimo: Number(ent.minimo) || 0, tempo: ent.tempo || '' },
    pagamento: { pix: !!pg.pix, chavePixCadastrada: !!pg.chavePix, pixNaEntrega: !!pg.pixentrega, dinheiro: !!pg.dinheiro, cartao: !!pg.cartao, pixAutomatico: !!pg.online },
    botaoWhatsapp: !!x.mensagemPronta?.ativo }
}

/* ---------- confirmações pendentes (ações de impacto) ---------- */
const pend = new Map<string, { uid: number; bid: number; acao: string; args: any; exp: number; resumo: string }>()
const novoCodigo = () => 'cf' + Math.random().toString(36).slice(2, 8)
function pedirConfirmacao(u: SessionUser, e: Ativa, acao: string, args: any, resumo: string) {
  for (const [k, v] of pend) if (v.exp < Date.now()) pend.delete(k)
  const codigo = novoCodigo(); pend.set(codigo, { uid: Number(u.id), bid: Number(e.b.id), acao, args, exp: Date.now() + 10 * 60_000, resumo })
  return { ok: false, precisaConfirmar: true, empresa: e.nome, confirmacao: codigo, resumo,
    aviso: `NÃO foi alterado ainda. Pergunte ao usuário, com estas palavras: "${resumo} Confirma?" Só se ele responder que sim, chame empresa_alterar de novo com confirmacao="${codigo}" (o resto dos campos é ignorado).` }
}
function ultimaPendente(uid: number) { let m: [string, any] | null = null; for (const [k, v] of pend) if (v.uid === uid && v.exp >= Date.now() && (!m || v.exp > m[1].exp)) m = [k, v]; return m }
const SIM = /^(sim|s|ok|okay|pode|pode sim|confirmo|confirmado|confirmar|isso|isso mesmo|claro|manda|manda ver|faz|faca|fazer|pode fazer|pode confirmar|sim pode confirmar|sim confirmo|sim pode|beleza|certo|positivo)( por favor)?$/
const NAO = /^(nao|n|nao obrigado|cancela|cancele|cancelar|deixa|deixa pra la|esquece|melhor nao|nao quero|nao cancele|nao pode|negativo|nao cancele nada)( por favor)?$|^nao,? cancele$/
/** Resposta curta do usuário ("sim" / "não", ou os botões Confirmar/Cancelar) a uma ação de impacto pendente DESTE usuário:
 *  executa ou cancela sem depender da IA lembrar do código. null = a mensagem não é resposta a uma confirmação pendente. */
export async function respostaConfirmacao(u: SessionUser, text: string, ultimaDoAssistente = ''): Promise<{ content: string } | null> {
  const t = nrm(text).replace(/^(sim|nao)\s+(sim|nao)\b/, '$1'), p = ultimaPendente(Number(u.id)); if (!p) return null
  if (!nrm(ultimaDoAssistente).includes(nrm(p[1].resumo).slice(0, 60))) return null // o "sim" só vale como resposta À pergunta de confirmação (a última mensagem do assistente)
  if (NAO.test(t)) { pend.delete(p[0]); return { content: 'Tudo bem, não alterei nada.' } }
  if (!SIM.test(t)) return null
  return { content: formatar(await runEmpresaTool(u, 'empresa_alterar', { confirmacao: p[0] }, text)) }
}
/** Texto da resposta a partir do resultado REAL (nunca afirma sucesso com ok:false). */
export function formatar(r: any): string {
  if (r?.ok) return r.semMudanca ? `Nada mudou: ${r.alteracao} da ${r.empresa} já estava assim.` : `Pronto! ${r.alteracao.charAt(0).toUpperCase() + r.alteracao.slice(1)} da ${r.empresa}: ${r.antes ? `${r.antes} → ` : ''}${r.depois}.${r.observacao ? ' ' + r.observacao : ''}`
  if (r?.precisaConfirmar) return `${r.resumo} Confirma?`
  return `Não alterei: ${r?.error || 'algo deu errado.'}${r?.opcoes ? ' Opções: ' + r.opcoes.join(', ') + '.' : ''}`
}
const SENSIVEIS = new Set(['pausar_pedidos', 'excluir_produto', 'alterar_nome', 'alterar_endereco'])

/* ---------- produtos: localizar e editar pela rota oficial ---------- */
type PV = { p: any; v: any | null }
export async function localizar(bid: number, produto: any, variacao: any): Promise<{ ok: true; alvo: PV } | { ok: false; erro: string; ambiguo?: boolean; opcoes?: string[] }> {
  const lista = await produtos(bid)
  const casa = (nome: string, termo: string) => { const n = nrm(nome), t = nrm(termo); if (!t) return 0; if (n === t) return 3; if (n.startsWith(t) || n.includes(' ' + t) || n.includes(t)) return 2; const ws = t.split(' ').filter((w) => w.length > 1); return ws.length && ws.every((w) => n.includes(w)) ? 1 : 0 }
  const melhor = <T,>(xs: T[], nome: (x: T) => string, termo: string) => { const sc = xs.map((x) => ({ x, s: casa(nome(x), termo) })).filter((y) => y.s > 0); const top = Math.max(0, ...sc.map((y) => y.s)); return sc.filter((y) => y.s === top).map((y) => y.x) }
  let ps: any[] = []
  const pid = Number(produto)
  if (Number.isInteger(pid) && pid > 0 && String(produto).trim() === String(pid)) ps = lista.filter((p) => p.id === pid)
  else if (String(produto || '').trim()) ps = melhor(lista, (p) => p.nome, String(produto))
  if (!ps.length && String(produto || '').trim()) { // "o produto dourado": pode ser o nome de uma variação
    const pares = lista.flatMap((p) => p.variacoes.map((v: any) => ({ p, v })))
    const vs = melhor(pares, (pv) => pv.v.rotulo, String(produto))
    if (vs.length === 1) return { ok: true, alvo: vs[0] }
    if (vs.length > 1) return { ok: false, ambiguo: true, erro: `Encontrei mais de uma opção para "${produto}". Qual delas?`, opcoes: vs.slice(0, 8).map((pv) => `${pv.p.nome} · ${pv.v.rotulo}`) }
  }
  if (!ps.length) return { ok: false, erro: String(produto || '').trim() ? `Não encontrei "${produto}" nos produtos da empresa ativa.` : 'Qual produto?', opcoes: lista.slice(0, 12).map((p) => p.nome) }
  if (ps.length > 1) return { ok: false, ambiguo: true, erro: `Há ${ps.length} produtos parecidos com "${produto}". Qual deles?`, opcoes: ps.slice(0, 8).map((p) => p.nome) }
  const p = ps[0]
  if (!variacao && variacao !== 0) return { ok: true, alvo: { p, v: null } }
  const vid = Number(variacao)
  const vs = Number.isInteger(vid) && vid > 0 && String(variacao).trim() === String(vid) ? p.variacoes.filter((v: any) => v.id === vid) : melhor(p.variacoes, (v: any) => v.rotulo, String(variacao))
  if (!p.variacoes.length) return { ok: false, erro: `${p.nome} não tem variações.` }
  if (!vs.length) return { ok: false, erro: `${p.nome} não tem a variação "${variacao}".`, opcoes: p.variacoes.map((v: any) => v.rotulo) }
  if (vs.length > 1) return { ok: false, ambiguo: true, erro: `Qual variação de ${p.nome}?`, opcoes: vs.map((v: any) => v.rotulo) }
  return { ok: true, alvo: { p, v: vs[0] } }
}
/** Corpo completo do produto como o formulário de edição manda (fotos por referência; nada se perde), para a rota oficial. */
export async function corpoProduto(u: SessionUser, e: Ativa, pid: number) {
  const f: any = await chamar(u, e, 'GET', `/api/v2/ads/${e.b.id}/products/${pid}`)
  const body: any = { id: pid, tipo: f.tipo, nome: f.nome, preco: f.preco, modoPreco: f.modoPreco, descricao: f.descricao || '', categoria: f.categoria || '', fotos: f.fotos || [], thumb: f.thumb, tags: f.tags || [], variacoes: f.variacoes || [], palavras: f.palavras || '', duracao: f.duracao, sinal: f.sinal }
  if ((f.variantes || []).some((v: any) => !v.base)) body.variantes = f.variantes.filter((v: any) => !v.base).map((v: any) => ({ id: v.id, nome: v.nome, cor: v.cor, tamanho: v.tamanho, modelo: v.modelo, preco: v.preco, oferta: v.oferta, estoque: v.estoque, disponivel: v.ativa, thumb: v.thumb, fotos: (v.fotos || []).map((_: any, i: number) => `keep:${v.id}:${i}`) }))
  return { f, body }
}
async function lerAlvo(bid: number, pid: number, vid: number | null) {
  const p = (await produtos(bid)).find((x) => x.id === pid); if (!p) return null
  return vid ? { p, v: p.variacoes.find((v: any) => v.id === vid) || null } : { p, v: null }
}

/* ---------- ferramentas ---------- */
const prodProps = { produto: { type: 'string', description: 'nome (ou id) do produto da empresa ativa, como o usuário disse; pode ser o nome de uma variação ("o dourado")' }, variacao: { type: 'string', description: 'variação (cor, tamanho, modelo), quando o produto tiver variações' } }
export const EMPRESA_TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'empresa_consultar', description: 'Lê as configurações REAIS da empresa ATIVA do usuário: perfil, contato, horário, se está recebendo pedidos, entrega, retirada, frete grátis, formas de pagamento, botão do WhatsApp e produtos (preço, oferta, estoque, variações, ativo). Use antes de alterar quando precisar saber o valor atual, e para responder "como está configurado…".', parameters: { type: 'object', properties: { busca: { type: 'string', description: 'filtra os produtos por nome (opcional)' } } } } },
  { type: 'function', function: { name: 'empresa_alterar', description: 'ALTERA de verdade uma configuração da empresa ATIVA (sempre a empresa ativa; nunca outra). Uma ação por chamada. Ações: alterar_descricao(texto), alterar_nome(texto), alterar_whatsapp(texto), alterar_instagram(texto), alterar_endereco(texto), alterar_contato(texto), alterar_horario(dias[], abre, fecha, outros_dias_fechados), pausar_pedidos, reativar_pedidos, configurar_entrega(entrega?, retirada?, taxa?, raio_km?, pedido_minimo?, tempo?), frete_gratis(ativo, valor_minimo), configurar_pagamento(pix?, dinheiro?, cartao?, pix_na_entrega?, pix_automatico?), botao_whatsapp(ativo), produto_preco(produto, variacao?, valor), produto_oferta(produto, variacao?, ativo, valor=preço promocional), produto_estoque(produto, variacao?, valor, operacao definir|somar|subtrair; valor null = não controlar), produto_ativar(produto), produto_pausar(produto), produto_variacao_disponivel(produto, variacao, ativo), produto_descricao(produto, texto), produto_categoria(produto, texto), produto_nome(produto, texto), excluir_produto(produto), trocar_empresa_ativa(texto=nome da empresa). Se faltar o valor ou o item, PERGUNTE antes. Nunca diga que alterou sem ok:true.', parameters: { type: 'object', properties: {
    acao: { type: 'string', enum: ['alterar_descricao', 'alterar_nome', 'alterar_whatsapp', 'alterar_instagram', 'alterar_endereco', 'alterar_contato', 'alterar_horario', 'pausar_pedidos', 'reativar_pedidos', 'configurar_entrega', 'frete_gratis', 'configurar_pagamento', 'botao_whatsapp', 'produto_preco', 'produto_oferta', 'produto_estoque', 'produto_ativar', 'produto_pausar', 'produto_variacao_disponivel', 'produto_descricao', 'produto_categoria', 'produto_nome', 'excluir_produto', 'trocar_empresa_ativa'] },
    ...prodProps, texto: { type: 'string' }, valor: { type: 'number', description: 'preço, preço promocional, estoque ou valor mínimo, conforme a ação' }, operacao: { type: 'string', enum: ['definir', 'somar', 'subtrair'] }, ativo: { type: 'boolean' },
    dias: { type: 'array', items: { type: 'string', enum: [...DIAS] }, description: 'dias de funcionamento (seg…dom)' }, abre: { type: 'string', description: 'HH:MM' }, fecha: { type: 'string', description: 'HH:MM' }, outros_dias_fechados: { type: 'boolean', description: 'padrão true: os dias não citados ficam fechados' },
    entrega: { type: 'boolean' }, retirada: { type: 'boolean' }, taxa: { type: 'number' }, raio_km: { type: 'number' }, pedido_minimo: { type: 'number' }, tempo: { type: 'string' }, valor_minimo: { type: 'number' },
    pix: { type: 'boolean' }, dinheiro: { type: 'boolean' }, cartao: { type: 'boolean' }, pix_na_entrega: { type: 'boolean' }, pix_automatico: { type: 'boolean' },
    confirmacao: { type: 'string', description: 'código devolvido quando a ação pediu confirmação; mande só depois do "sim" do usuário' } }, required: ['acao'] } } },
]
export const EMPRESA_NAMES = new Set(EMPRESA_TOOLS.map((t) => t.function.name))

export async function empresaContext(u: SessionUser): Promise<string> {
  const a = await empresaAtiva(u)
  const base = 'ADMINISTRAÇÃO DA EMPRESA PELO CHAT (ferramentas empresa_consultar e empresa_alterar): quando o usuário pedir para mudar algo da empresa/loja (horário, pedidos, entrega, retirada, taxa, frete grátis, pagamento, WhatsApp, descrição, preço, oferta, estoque, produto pausado/ativo…), EXECUTE com empresa_alterar — não diga que "faria" nem mande o usuário ao menu. Uma ação por chamada; várias mudanças = várias chamadas. Se o item ou o valor forem ambíguos ou faltarem (ex.: "aumente o preço do piercing" sem dizer qual nem quanto), pergunte antes. Se a ferramenta devolver precisaConfirmar, faça a pergunta indicada e só chame de novo com o código depois do "sim". Na resposta: diga o nome da empresa, o que mudou e o valor anterior → novo (quando útil); se ok:false, explique o motivo e nunca diga que mudou. Nunca altere chave Pix, Mercado Pago, tokens, plano ou pagamento do anúncio: oriente a fazer em Sua empresa.'
  const dicas = ' Mapa: "pausar o catálogo/loja" ou "parar os pedidos" = pausar_pedidos; "ativar os pedidos de novo" = reativar_pedidos; "deixar só retirada" = configurar_entrega(entrega=false, retirada=true); "frete grátis acima de R$ X" = frete_gratis; "ativar o WhatsApp como contato" = botao_whatsapp. Não existe "horário de retirada" separado: a retirada segue o horário de funcionamento — explique isso e ofereça mudar o horário de funcionamento. Para confirmar uma ação pendente depois do "sim", chame empresa_alterar com confirmacao igual ao código recebido (ou "sim").'
  return a.ok ? `${base}${dicas} EMPRESA ATIVA AGORA: ${a.e.nome}.` : `${base} SITUAÇÃO: ${a.erro}${a.opcoes ? ' Empresas: ' + a.opcoes.join(', ') + '.' : ''}`
}

const bool = (v: any) => v === true || v === false ? v : undefined
const hm = (t: any) => { const m = String(t ?? '').trim().match(/^(\d{1,2})(?::|h)?(\d{2})?$/i); if (!m) return null; const h = Number(m[1]), mi = Number(m[2] || 0); return h <= 23 && mi <= 59 ? `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}` : null }

export async function runEmpresaTool(u: SessionUser, name: string, a0: any, userText = ''): Promise<any> {
  const at = await empresaAtiva(u)
  if (name === 'empresa_alterar' && a0?.acao === 'trocar_empresa_ativa') return trocarEmpresa(u, String(a0.texto || a0.produto || ''))
  if (!at.ok) return { ok: false, error: at.erro, ...(at.opcoes ? { empresas: at.opcoes } : {}) }
  const e = at.e
  try {
    if (name === 'empresa_consultar') {
      const x = await dados(Number(e.b.id)), INC = await import('../lib/incentivos.js')
      const fg = (await INC.listar(Number(e.b.id))).filter((i: any) => i.beneficio === 'frete_gratis').map((i: any) => ({ nome: i.nome, valorMinimo: i.meta, ativo: i.ativo, situacao: INC.situacao(i) }))
      const busca = nrm(a0?.busca || ''), ps = (await produtos(Number(e.b.id))).filter((p) => !busca || nrm(p.nome).includes(busca) || p.variacoes.some((v: any) => nrm(v.rotulo).includes(busca)))
      return { ok: true, ...resumoEmpresa(e, x), freteGratis: fg, produtos: ps.slice(0, 40).map(({ descricao, ...p }) => ({ ...p, descricao: descricao.slice(0, 120) })), totalProdutos: ps.length }
    }
    if (name !== 'empresa_alterar') return { ok: false, error: 'Ferramenta desconhecida.' }
    let a = a0 || {}
    if (a.confirmacao) { // 2ª chamada, depois do "sim": vale o que foi resumido ao usuário, na MESMA empresa ativa
      const cod = pend.has(String(a.confirmacao)) ? String(a.confirmacao) : ultimaPendente(Number(u.id))?.[0] // a IA nem sempre guarda o código: vale a última pendência DESTE usuário…
      if (cod && String(a.confirmacao) !== cod && !SIM.test(nrm(userText))) return { ok: false, error: 'Só executo depois que o usuário confirmar com "sim". Pergunte de novo.' } // …e só com o "sim" dele nesta mensagem
      a = { ...a, confirmacao: cod || a.confirmacao }
      const p = pend.get(String(a.confirmacao))
      if (!p || p.uid !== Number(u.id) || p.exp < Date.now()) return { ok: false, error: 'A confirmação expirou ou não é válida. Peça a alteração de novo.' }
      if (p.bid !== Number(e.b.id)) { pend.delete(String(a.confirmacao)); return { ok: false, error: 'A empresa ativa mudou depois do pedido de confirmação; nada foi alterado. Peça de novo.' } }
      pend.delete(String(a.confirmacao)); a = { ...p.args, __confirmado: true }
    }
    return await alterar(u, e, a)
  } catch (err: any) {
    const msg = err instanceof HttpError ? err.message : 'Não consegui concluir a alteração agora.'
    if (!(err instanceof HttpError)) console.error('[empresa-chat]', err?.message || err)
    return { ok: false, empresa: e.nome, error: msg + ' Nada foi alterado.', abrir: '/x/sua-empresa' }
  }
}

async function trocarEmpresa(u: SessionUser, nome: string) {
  const proprias = await q("SELECT * FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira') ORDER BY id", [u.id])
  const vinc = await (await import('../lib/vinculos.js')).vinculadasValidas(u.id).catch(() => [] as any[])
  const todas = [...proprias, ...vinc].map((b: any) => ({ id: Number(b.id), nome: String(J<any>(b.data, {}).empresa || 'Empresa') }))
  const t = nrm(nome), achou = todas.filter((x) => nrm(x.nome) === t).length ? todas.filter((x) => nrm(x.nome) === t) : todas.filter((x) => t && nrm(x.nome).includes(t))
  if (achou.length !== 1) return { ok: false, error: achou.length ? 'Mais de uma empresa com esse nome. Qual delas?' : `Não encontrei a empresa "${nome}" entre as suas.`, empresas: (achou.length ? achou : todas).map((x) => x.nome) }
  const ctx: any = { user: u, session: { id: 'chat', user_id: u.id, mfa_pending: false, recovery: false }, body: { businessId: achou[0].id }, req: { headers: {} } }
  const r: any = await (await import('../lib/vinculos.js')).contextoPut(ctx)
  const ok = Number(r?.ativa) === achou[0].id
  return ok ? { ok: true, empresaAtiva: achou[0].nome, mensagem: `Agora a empresa ativa é ${achou[0].nome}. As próximas alterações valem só para ela.` } : { ok: false, error: 'Não consegui trocar a empresa ativa.' }
}

export async function alterar(u: SessionUser, e: Ativa, a: any): Promise<any> {
  const bid = Number(e.b.id), acao = String(a.acao || '')
  const resp = (campo: string, antes: any, depois: any, extra: any = {}) => ({ ok: true, verificado: true, empresa: e.nome, alteracao: campo, antes, depois, ...extra })
  const naoPersistiu = (campo: string) => ({ ok: false, empresa: e.nome, error: `A alteração de ${campo} não foi confirmada no banco de dados; considere que NÃO foi feita. Tente de novo ou abra Sua empresa.`, abrir: '/x/sua-empresa' })
  const putEmpresa = (body: any) => chamar(u, e, 'PUT', `/api/v2/ads/${bid}`, body)

  // ---------- perfil e contato ----------
  const perfil: Record<string, [string, string, number]> = { alterar_descricao: ['sobre', 'descrição', 200], alterar_nome: ['empresa', 'nome da empresa', 80], alterar_whatsapp: ['zap', 'WhatsApp', 15], alterar_instagram: ['insta', 'Instagram', 40], alterar_endereco: ['endereco', 'endereço', 160], alterar_contato: ['contato', 'contato', 80] }
  if (perfil[acao]) {
    const [k, rot, max] = perfil[acao], x0 = await dados(bid)
    let v = String(a.texto ?? '').trim(); if (k === 'zap') v = v.replace(/\D/g, ''); if (k === 'insta') v = v.replace(/^@/, '')
    if (!v) return { ok: false, error: `Qual ${rot} você quer colocar?` }
    if (k === 'zap' && (v.length < 10 || v.length > 13)) return { ok: false, error: 'Informe o WhatsApp com DDD (10 a 13 dígitos).' }
    if (v.length > max) return { ok: false, error: `O ${rot} pode ter até ${max} caracteres (o enviado tem ${v.length}).` }
    if (SENSIVEIS.has(acao) && !a.__confirmado) return pedirConfirmacao(u, e, acao, a, `Vou trocar o ${rot} da ${e.nome} de "${x0[k] || '(vazio)'}" para "${v}" — isso aparece para os clientes.`)
    await putEmpresa({ [k]: v })
    const x1 = await dados(bid); return String(x1[k] || '') === v ? resp(rot, x0[k] || '', x1[k]) : naoPersistiu(rot)
  }
  // ---------- horário e recebimento de pedidos ----------
  if (acao === 'alterar_horario') {
    const x0 = await dados(bid), ab = hm(a.abre), fe = hm(a.fecha), dias: string[] = Array.isArray(a.dias) ? a.dias.filter((d: any) => DIAS.includes(d)) : []
    if (!dias.length || !ab || !fe) return { ok: false, error: 'Diga os dias e o horário (ex.: segunda a sábado, das 9h às 18h).' }
    const atual = x0.horarioCfg?.dias || {}, fechaOutros = a.outros_dias_fechados !== false
    const novo = Object.fromEntries(DIAS.map((k) => [k, dias.includes(k) ? { ativo: true, abre: ab, fecha: fe } : fechaOutros ? { ativo: false, abre: atual[k]?.abre || ab, fecha: atual[k]?.fecha || fe } : (atual[k] || { ativo: false, abre: ab, fecha: fe })]))
    await putEmpresa({ horarioCfg: { modo: x0.horarioCfg?.modo === 'fechado' ? 'fechado' : 'auto', dias: novo } })
    const x1 = await dados(bid), ok = dias.every((k) => x1.horarioCfg?.dias?.[k]?.ativo && x1.horarioCfg.dias[k].abre === ab && x1.horarioCfg.dias[k].fecha === fe)
    return ok ? resp('horário de funcionamento', x0.horario || '(não configurado)', x1.horario, x1.horarioCfg?.modo === 'fechado' ? { observacao: 'Os pedidos continuam pausados (loja fechada) até você reativar.' } : {}) : naoPersistiu('horário')
  }
  if (acao === 'pausar_pedidos' || acao === 'reativar_pedidos') {
    const x0 = await dados(bid), h0 = x0.horarioCfg || { modo: 'auto', dias: {} }, temDias = DIAS.some((k) => h0.dias?.[k]?.ativo)
    const modo = acao === 'pausar_pedidos' ? 'fechado' : temDias ? 'auto' : 'aberto'
    if (h0.modo === modo) return resp('recebimento de pedidos', modo === 'fechado' ? 'pausado' : 'ativo', modo === 'fechado' ? 'pausado' : 'ativo', { semMudanca: true })
    if (acao === 'pausar_pedidos' && !a.__confirmado) return pedirConfirmacao(u, e, acao, a, `Vou pausar a ${e.nome}: a loja fica fechada e NENHUM cliente consegue fazer pedido até você reativar (pedidos já feitos continuam normais).`)
    await putEmpresa({ horarioCfg: { ...h0, modo, dias: h0.dias || {} } })
    const x1 = await dados(bid)
    return x1.horarioCfg?.modo === modo ? resp('recebimento de pedidos', h0.modo === 'fechado' ? 'pausado' : 'ativo', modo === 'fechado' ? 'pausado (loja fechada)' : modo === 'auto' ? `ativo, conforme o horário (${x1.horario})` : 'ativo (sempre aberta)') : naoPersistiu('recebimento de pedidos')
  }
  // ---------- entrega e retirada ----------
  if (acao === 'configurar_entrega') {
    const x0 = await dados(bid), e0 = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', modoTaxa: 'fixa', kmGratis: 0, taxaExcedente: 0, taxaKm: 0, ...(x0.entrega || {}) }
    const e1 = { ...e0 }
    if (bool(a.entrega) !== undefined) e1.entrega = a.entrega; if (bool(a.retirada) !== undefined) e1.retirada = a.retirada
    if (a.taxa != null) { if (!(Number(a.taxa) >= 0)) return { ok: false, error: 'Taxa de entrega inválida.' }; e1.taxa = Math.round(Number(a.taxa) * 100) / 100; if (e0.modoTaxa === 'km') return { ok: false, error: 'A taxa desta loja é calculada por distância (km). Ajuste os valores por km em Sua empresa → Entrega e pagamento.', abrir: '/x/sua-empresa' } }
    if (a.raio_km != null) { if (!(Number(a.raio_km) > 0 && Number(a.raio_km) <= 100)) return { ok: false, error: 'O raio de entrega precisa ser de 1 a 100 km.' }; e1.raio = Number(a.raio_km) }
    if (a.pedido_minimo != null) { if (!(Number(a.pedido_minimo) >= 0)) return { ok: false, error: 'Pedido mínimo inválido.' }; e1.minimo = Number(a.pedido_minimo) }
    if (a.tempo != null) e1.tempo = String(a.tempo).slice(0, 40)
    if (!e1.entrega && !e1.retirada) return { ok: false, error: 'A loja precisa ter pelo menos uma forma de receber (entrega ou retirada). Nada foi alterado.' }
    await putEmpresa({ entrega: e1 })
    const x1 = await dados(bid), g = x1.entrega || {}
    const ok = !!g.entrega === !!e1.entrega && (g.retirada !== false) === !!e1.retirada && Number(g.taxa) === Number(e1.taxa) && Number(g.raio) === Number(e1.raio) && Number(g.minimo) === Number(e1.minimo)
    const txt = (z: any) => `entrega ${z.entrega ? 'ligada' : 'desligada'}${z.entrega ? ` (taxa ${brl(z.taxa)}, até ${z.raio} km${z.minimo ? `, mínimo ${brl(z.minimo)}` : ''}${z.tempo ? `, ${z.tempo}` : ''})` : ''}; retirada ${z.retirada !== false ? 'ligada' : 'desligada'}`
    return ok ? resp('entrega e retirada', txt(e0), txt(g)) : naoPersistiu('entrega')
  }
  if (acao === 'frete_gratis') {
    const INC = await import('../lib/incentivos.js'), lista = (await INC.listar(bid)).filter((i: any) => i.beneficio === 'frete_gratis' && i.metaTipo === 'valor')
    if (a.ativo === false) {
      const ativos = lista.filter((i: any) => i.ativo); if (!ativos.length) return resp('frete grátis', 'desligado', 'desligado', { semMudanca: true })
      for (const i of ativos) await chamar(u, e, 'POST', `/api/v2/ads/${bid}/incentivos`, { action: 'status', id: i.id, ativo: false })
      const depois = (await INC.listar(bid)).filter((i: any) => i.beneficio === 'frete_gratis' && i.ativo)
      return depois.length ? naoPersistiu('frete grátis') : resp('frete grátis', ativos.map((i: any) => `acima de ${brl(i.meta)}`).join(', '), 'desligado')
    }
    const min = Math.round(Number(a.valor_minimo ?? a.valor) * 100) / 100
    if (!(min >= 1)) return { ok: false, error: 'A partir de qual valor de compra o frete fica grátis?' }
    const ex = lista.find((i: any) => Number(i.meta) === min) || lista[0], nome = `Frete grátis acima de ${brl(min)}`
    const corpo = { nome, metaTipo: 'valor', meta: min, beneficio: 'frete_gratis', ativo: true, combinaCupom: ex ? ex.combinaCupom : true, limiteCliente: ex ? ex.limiteCliente : 0, inicio: ex?.inicio || null, fim: ex?.fim || null, ...(ex ? { id: ex.id } : {}) }
    await chamar(u, e, 'POST', `/api/v2/ads/${bid}/incentivos`, corpo)
    const ag = (await INC.listar(bid)).find((i: any) => i.beneficio === 'frete_gratis' && i.ativo && Number(i.meta) === min)
    return ag ? resp('frete grátis', ex ? `${ex.ativo ? 'acima de' : 'desligado (era acima de'} ${brl(ex.meta)}${ex.ativo ? '' : ')'}` : 'não configurado', `acima de ${brl(min)} em produtos`, { observacao: 'Vale para pedidos com entrega.' }) : naoPersistiu('frete grátis')
  }
  // ---------- pagamento (só liga/desliga formas já previstas; nunca credenciais nem chave Pix) ----------
  if (acao === 'configurar_pagamento') {
    const x0 = await dados(bid), p0 = { pix: true, chavePix: '', mostrarChave: true, pixentrega: false, dinheiro: true, cartao: false, online: false, ...(x0.pagamento || {}) }, p1 = { ...p0 }
    const mapa: [string, string][] = [['pix', 'pix'], ['dinheiro', 'dinheiro'], ['cartao', 'cartao'], ['pix_na_entrega', 'pixentrega'], ['pix_automatico', 'online']]
    for (const [k, c] of mapa) if (bool(a[k]) !== undefined) (p1 as any)[c] = a[k]
    if (p1.online && !p0.online) { const B = await import('../routes/businesses.js'); if (!(await B.mpPronto(e.b))) return { ok: false, error: 'O Pix automático precisa do Mercado Pago da loja conectado. Conecte em Sua empresa → Recebimento; por segurança isso não é feito pelo chat.', abrir: '/x/sua-empresa' } }
    if (!p1.pix && !p1.dinheiro && !p1.cartao && !p1.pixentrega && !p1.online) return { ok: false, error: 'A loja precisa aceitar pelo menos uma forma de pagamento. Nada foi alterado.' }
    if (p0.online && !p1.online && !a.__confirmado) return pedirConfirmacao(u, e, acao, a, `Vou desligar o Pix automático da ${e.nome}: os clientes deixam de pagar online pelo app.`)
    await putEmpresa({ pagamento: p1 })
    const x1 = await dados(bid), g = { pix: true, dinheiro: true, ...(x1.pagamento || {}) }
    const ok = mapa.every(([, c]) => !!(g as any)[c] === !!(p1 as any)[c]) && String(g.chavePix || '') === String(p0.chavePix || '') // a chave Pix nunca muda por aqui
    const txt = (z: any) => [z.pix ? 'Pix na chave' : '', z.pixentrega ? 'Pix na entrega' : '', z.dinheiro ? 'dinheiro' : '', z.cartao ? 'cartão' : '', z.online ? 'Pix automático' : ''].filter(Boolean).join(', ') || 'nenhuma'
    return ok ? resp('formas de pagamento', txt(p0), txt(g)) : naoPersistiu('formas de pagamento')
  }
  if (acao === 'botao_whatsapp') {
    const x0 = await dados(bid); if (a.ativo !== false && !String(x0.zap || '').replace(/\D/g, '')) return { ok: false, error: 'A empresa ainda não tem WhatsApp cadastrado. Qual é o número (com DDD)?' }
    const MP = await import('../lib/mensagem-pronta.js'), c0 = MP.config(x0)
    await chamar(u, e, 'PUT', `/api/v2/ads/${bid}/mensagem-pronta`, { ativo: a.ativo !== false, texto: c0.texto, botao: c0.botao })
    const c1 = MP.config(await dados(bid))
    return c1.ativo === (a.ativo !== false) ? resp('botão "Chamar no WhatsApp" no catálogo', c0.ativo ? 'ligado' : 'desligado', c1.ativo ? 'ligado' : 'desligado') : naoPersistiu('botão do WhatsApp')
  }
  // ---------- produtos e variações ----------
  if (acao.startsWith('produto_') || acao === 'excluir_produto') {
    const precisaVar = ['produto_variacao_disponivel'].includes(acao)
    const loc = await localizar(bid, a.produto, a.variacao)
    if (!loc.ok) return { ok: false, ...(loc.ambiguo ? { ambiguo: true } : {}), error: loc.erro, ...(loc.opcoes ? { opcoes: loc.opcoes } : {}) }
    let { p, v } = loc.alvo
    const nomeItem = v ? `${p.nome} · ${v.rotulo}` : p.nome
    const porVariacao = ['produto_preco', 'produto_oferta', 'produto_estoque'].includes(acao) || precisaVar
    if (porVariacao && p.variacoes.length && !v) {
      if (p.variacoes.length === 1) v = p.variacoes[0]
      else return { ok: false, ambiguo: true, error: `${p.nome} tem variações, e cada uma tem o próprio ${acao === 'produto_estoque' ? 'estoque' : 'preço'}. Qual variação?`, opcoes: p.variacoes.map((x: any) => x.rotulo) }
    }
    if (acao === 'produto_ativar' || acao === 'produto_pausar') {
      const quer = acao === 'produto_ativar'; if (p.ativo === quer) return resp(`${p.nome}: ${quer ? 'ativo' : 'pausado'}`, quer ? 'ativo' : 'pausado', quer ? 'ativo' : 'pausado', { semMudanca: true })
      await chamar(u, e, 'POST', `/api/v2/ads/${bid}/products`, { action: 'toggle', id: p.id, ativo: quer })
      const d = await lerAlvo(bid, p.id, null); return d && d.p.ativo === quer ? resp(`${p.nome}`, p.ativo ? 'ativo no catálogo' : 'pausado', quer ? 'ativo no catálogo' : 'pausado (some do catálogo)') : naoPersistiu(p.nome)
    }
    if (acao === 'excluir_produto') {
      if (!a.__confirmado) return pedirConfirmacao(u, e, acao, { ...a, produto: String(p.id), variacao: undefined }, `Vou EXCLUIR "${p.nome}" do catálogo da ${e.nome}, com fotos e variações. Isso não pode ser desfeito (para só esconder, eu posso pausar).`)
      await chamar(u, e, 'POST', `/api/v2/ads/${bid}/products`, { action: 'delete', id: p.id })
      return (await lerAlvo(bid, p.id, null)) ? naoPersistiu('exclusão') : resp('produto excluído', p.nome, '(excluído)')
    }
    // edição pela rota oficial do formulário (corpo completo, fotos por referência)
    const { body } = await corpoProduto(u, e, p.id)
    const bv = v ? (body.variantes || []).find((x: any) => Number(x.id) === Number(v.id)) : null
    if (v && !bv) return { ok: false, error: 'Não encontrei a variação no cadastro atual.' }
    let campo = '', antes: any, esperado: (d: { p: any; v: any }) => boolean, depoisTxt: (d: { p: any; v: any }) => string
    if (acao === 'produto_preco') {
      const n = Math.round(Number(a.valor) * 100) / 100; if (!(n > 0 && n < 1e6)) return { ok: false, error: `Qual o novo preço de ${nomeItem}?` }
      campo = `preço de ${nomeItem}`; antes = brl(v ? v.preco : p.preco)
      const of = v ? bv.oferta : null
      if (v) { bv.preco = n; if (of?.ativo && Number(of.preco) >= n) return { ok: false, error: `${nomeItem} está em oferta por ${brl(of.preco)}, e o preço normal precisa ficar acima da oferta. Quer que eu desligue a oferta ou mude o preço promocional?` } }
      else body.preco = n
      esperado = (d) => Number((d.v || d.p).preco) === n; depoisTxt = () => brl(n)
    } else if (acao === 'produto_oferta') {
      if (a.ativo === false) { if (v) bv.oferta = { ativo: false, preco: bv.oferta?.preco || 0 }; else body.oferta = { ativo: false }; campo = `oferta de ${nomeItem}`; antes = (v ? v.oferta : p.oferta) != null ? `em oferta por ${brl(v ? v.oferta : p.oferta)}` : 'sem oferta'; esperado = (d) => (d.v || d.p).oferta == null; depoisTxt = () => 'sem oferta (preço normal)' }
      else {
        const n = Math.round(Number(a.valor) * 100) / 100, normal = v ? v.preco : p.preco
        if (!(n > 0)) return { ok: false, error: `Qual o preço promocional de ${nomeItem}? (o normal é ${brl(normal)})` }
        if (n >= normal) return { ok: false, error: `O preço promocional precisa ser menor que o normal (${brl(normal)}).` }
        if (v) bv.oferta = { ativo: true, preco: n }; else body.oferta = { ativo: true, preco: n }
        campo = `oferta de ${nomeItem}`; antes = (v ? v.oferta : p.oferta) != null ? `em oferta por ${brl(v ? v.oferta : p.oferta)}` : 'sem oferta'
        esperado = (d) => Number((d.v || d.p).oferta) === n; depoisTxt = () => `de ${brl(normal)} por ${brl(n)} (-${Math.round((1 - n / normal) * 100)}%)`
      }
    } else if (acao === 'produto_estoque') {
      const atual = v ? v.estoque : p.estoque
      let n: number | null
      if (a.valor === null || (a.valor === undefined && a.operacao === 'definir' && /n[aã]o controlar|sem controle|ilimitad/i.test(String(a.texto || '')))) n = null
      else {
        const val = Math.floor(Number(a.valor)); if (!(val >= 0)) return { ok: false, error: `Qual o estoque de ${nomeItem}? (agora: ${atual == null ? 'sem controle' : atual})` }
        const calc: number = a.operacao === 'somar' ? (atual ?? 0) + val : a.operacao === 'subtrair' ? (atual ?? 0) - val : val
        n = calc
        if (calc < 0) return { ok: false, error: `O estoque de ${nomeItem} é ${atual ?? 0}; não dá para tirar ${val} (ficaria negativo).` }
        if (calc > 1_000_000) return { ok: false, error: 'Estoque grande demais.' }
      }
      if (v) bv.estoque = n; else body.estoque = n
      campo = `estoque de ${nomeItem}`; antes = atual == null ? 'sem controle' : `${atual} un.`
      esperado = (d) => ((d.v || d.p).estoque ?? null) === n; depoisTxt = () => (n == null ? 'sem controle de estoque' : `${n} un.`)
    } else if (acao === 'produto_variacao_disponivel') {
      const quer = a.ativo !== false; bv.disponivel = quer; campo = `disponibilidade de ${nomeItem}`; antes = v.disponivel ? 'disponível' : 'indisponível'
      esperado = (d) => !!d.v && (d.v.disponivel === quer || (quer && d.v.estoque === 0)); depoisTxt = () => (quer ? 'disponível' : 'indisponível')
    } else if (acao === 'produto_descricao' || acao === 'produto_categoria' || acao === 'produto_nome') {
      const k = acao === 'produto_descricao' ? 'descricao' : acao === 'produto_categoria' ? 'categoria' : 'nome', lim = k === 'descricao' ? 600 : k === 'nome' ? 80 : 40
      const t = String(a.texto ?? '').trim(); if (!t) return { ok: false, error: `Qual ${k === 'descricao' ? 'a nova descrição' : k === 'nome' ? 'o novo nome' : 'a categoria'} de ${p.nome}?` }
      if (t.length > lim) return { ok: false, error: `Pode ter até ${lim} caracteres (o enviado tem ${t.length}).` }
      campo = `${k === 'descricao' ? 'descrição' : k} de ${p.nome}`; antes = (p as any)[k] || '(vazio)'; body[k] = t
      esperado = (d) => String((d.p as any)[k] || '') === t; depoisTxt = () => t
    } else return { ok: false, error: 'Ação de produto desconhecida.' }
    await chamar(u, e, 'POST', `/api/v2/ads/${bid}/products`, body)
    const d = await lerAlvo(bid, p.id, v ? v.id : null)
    return d && esperado!(d as any) ? resp(campo, antes, depoisTxt!(d as any), { produto: p.nome, ...(v ? { variacao: v.rotulo } : {}) }) : naoPersistiu(campo)
  }
  return { ok: false, error: 'Essa configuração ainda não pode ser alterada pelo chat. Abra Sua empresa para fazer por lá.', abrir: '/x/sua-empresa' }
}

/** Pedido de ALTERAÇÃO de configuração da empresa (verbo de comando + algo da loja). Quando é, o chat não deixa a frase cair
 *  nos atalhos de finanças, agenda pessoal, lembrete ou atalho de módulo ("R$ 25" não vira gasto; "19h30" não vira lembrete). */
const VERBO = /^(?:(?:por favor|favor|quero|eu quero|preciso|eu preciso|gostaria de|pode|voce pode|vc pode|consegue|vamos|agora)\s+)*(altere|altera|alterar|mude|muda|mudar|troque|troca|trocar|ative|ativa|ativar|desative|desativa|desativar|ligue|liga|ligar|desligue|desliga|desligar|pause|pausa|pausar|reative|reativa|reativar|coloque|coloca|colocar|ponha|bote|tire|tira|tirar|remova|remove|aumente|aumenta|aumentar|diminua|diminui|diminuir|reduza|defina|define|definir|atualize|atualiza|atualizar|deixe|deixa|configure|configura|ajuste|ajusta|zere|zera|exclua|exclui|apague|apaga|habilite|habilita|desabilite|desabilita|aceite|aceita|aceitar|pare|para de)\b/
const OBJ = /\b(preco|estoque|oferta|promocao|promocional|produto|produtos|variacao|frete|entrega|retirada|taxa|pix|pagamento|cartao|dinheiro|whatsapp|whats|zap|instagram|descricao|horario de funcionamento|funcionamento|catalogo|pedidos|loja|empresa|endereco|pedido minimo|raio)\b/
export function comandoEmpresa(text: string): boolean { const t = nrm(text); return VERBO.test(t) && OBJ.test(t) && !/\b(compromisso|agendamento|cliente)\b/.test(t) } // "altere o pagamento do compromisso de Santos" é da agenda, não da loja
