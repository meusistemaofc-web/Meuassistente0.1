// AVALIAÇÃO CONTÍNUA — (1) bateria automática de cenários que exercita cada capacidade (Nível 1 e Nível 2) sem IA;
// (2) indicadores de qualidade (notas internas, avaliações dos usuários, planos, autoverificação, proatividade,
// especialistas); (3) monitor de regressão que compara a última semana com a anterior e avisa os administradores.
import { q, one, nowIso, J } from '../db/index.js'
import { notify } from '../lib/notify.js'
import * as COG from './cognition.js'
import * as ESP from './especialistas.js'
import * as PLAN from './planejador.js'
import * as MEM from './memoria.js'
import * as AV from './autoverificacao.js'
import * as PRO from './proativo.js'
import * as N from './nucleo.js'
import * as FB from './feedback.js'

const hh = (...t: string[]) => t.map((c, i) => ({ role: i % 2 ? 'assistant' : 'user', content: c }))
const TODAS = ['create_task', 'create_appointment', 'create_reminder', 'add_shopping_items', 'create_note', 'register_transaction', 'create_bill', 'complete_task', 'save_memory', 'get_agenda', 'get_finance', 'crm_buscar_cliente', 'negocio_resumo', 'agenda_empresa_horarios'].map((name) => ({ function: { name } }))
export const FERRAMENTAS_TESTE = TODAS // ferramentas fictícias para testes isolados (Fase 6)
const PESSOAIS = TODAS.filter((t) => !/^(crm_|negocio_|agenda_empresa_)/.test(t.function.name))
type Caso = { id: string; area: string; descricao: string; ok: () => boolean }
export const BATERIA: Caso[] = [
  { id: 'ctx-continuacao', area: 'Raciocínio contextual', descricao: '"e amanhã?" continua a pergunta anterior', ok: () => { const a = COG.analisar('e amanhã?', hh('tenho reunião hoje?', 'Sim, às 14h')); return a.completude === 'eliptica' && /reunião hoje/.test(a.referenciaProvavel) } },
  { id: 'ctx-pronome', area: 'Raciocínio contextual', descricao: '"ele" é resolvido para a pessoa citada', ok: () => N.fioDaConversa(hh('Marque reunião com Pedro Alves amanhã', 'Feito.'), 'manda o endereço pra ele', COG.analisar('manda o endereço pra ele')).some((l) => /Pedro Alves/.test(l)) },
  { id: 'ctx-objeto', area: 'Raciocínio contextual', descricao: '"essa conta" aponta a conta citada antes', ok: () => N.fioDaConversa(hh('cadastra a conta de luz de 120 reais dia 10', 'Pronto, cadastrei a conta de luz.'), 'quando vence essa conta?', COG.analisar('quando vence essa conta?')).some((l) => /conta de luz/.test(l)) },
  { id: 'ctx-assunto', area: 'Raciocínio contextual', descricao: 'mudança de assunto é percebida', ok: () => N.fioDaConversa(hh('quanto gastei no mercado este mês', 'R$ 300', 'e na farmácia', 'R$ 50'), 'qual a capital da Austrália hoje em dia', COG.analisar('qual a capital da Austrália hoje em dia')).some((l) => /Assunto novo/.test(l)) },
  { id: 'ctx-lacuna', area: 'Raciocínio contextual', descricao: 'gasto sem valor pede o valor; valor já dito não é perguntado de novo', ok: () => COG.analisar('gastei no almoço').faltando.includes('o valor') && !COG.analisar('gastei no almoço', hh('foram 35 reais', 'ok')).faltando.length },
  { id: 'ctx-contradicao', area: 'Raciocínio contextual', descricao: 'horário diferente do dito antes vira confirmação', ok: () => COG.analisar('agenda reunião com João às 15h', hh('agenda reunião com João às 14h', 'feito')).contradicoes.length === 1 },
  { id: 'plan-decompor', area: 'Planejamento', descricao: 'pedido com 3 ações vira 3 etapas com ferramentas', ok: () => { const e = PLAN.decompor('agenda dentista amanhã às 10h, cria uma tarefa de levar o exame e me lembra de pagar a conta de luz'); return e.length === 3 && e.map((x) => x.ferramenta).join() === 'create_appointment,create_task,create_reminder' } },
  { id: 'plan-simples', area: 'Planejamento', descricao: 'pedido simples não gera plano', ok: () => PLAN.decompor('agenda dentista amanhã às 10h').length === 0 },
  { id: 'plan-prioridade', area: 'Planejamento', descricao: 'urgente vem primeiro, respeitando dependências', ok: () => { const e = PLAN.decompor('cria a tarefa revisar contrato e agenda reunião urgente hoje às 15h'); return e.length === 2 && PLAN.ordem(e)[0].ferramenta === 'create_appointment' } },
  { id: 'plan-execucao', area: 'Planejamento', descricao: 'etapas marcadas pelo retorno real das ferramentas', ok: () => { const p = PLAN.aplicarExecucao({ etapas: PLAN.decompor('agenda dentista amanhã às 10h e cria a tarefa levar exame'), status: 'ativo' }, [{ name: 'create_appointment', result: { ok: true } }, { name: 'create_task', result: { ok: false, error: 'limite atingido' } }]); return p.etapas[0].status === 'feito' && p.etapas[1].status === 'falhou' && /limite/.test(PLAN.resumoParcial(p, 'Agendei.')) } },
  { id: 'esp-financas', area: 'Especialistas', descricao: '"gastei 50 no mercado" aciona Finanças', ok: () => ESP.selecionar('gastei 50 no mercado', COG.analisar('gastei 50 no mercado'), PESSOAIS).principal === 'financas' },
  { id: 'esp-agenda', area: 'Especialistas', descricao: '"marca consulta" aciona Agenda', ok: () => ESP.selecionar('marca uma consulta amanhã às 9h', COG.analisar('marca uma consulta amanhã às 9h'), PESSOAIS).principal === 'agenda' },
  { id: 'esp-permissao', area: 'Especialistas', descricao: 'CRM só entra para quem tem as ferramentas do CRM', ok: () => !ESP.selecionar('como está o funil de clientes', COG.analisar('como está o funil de clientes'), PESSOAIS).ids.includes('crm') && ESP.selecionar('como está o funil de clientes', COG.analisar('como está o funil de clientes'), TODAS).ids.includes('crm') },
  { id: 'esp-acolhimento', area: 'Especialistas', descricao: 'desabafo aciona Acolhimento', ok: () => ESP.selecionar('estou muito cansado e desanimado', COG.analisar('estou muito cansado e desanimado'), PESSOAIS).principal === 'acolhimento' },
  { id: 'esp-continuacao', area: 'Especialistas', descricao: 'continuação mantém o especialista anterior', ok: () => ESP.selecionar('e amanhã?', COG.analisar('e amanhã?', hh('o que tenho hoje', 'nada')), PESSOAIS, ['agenda']).principal === 'agenda' },
  { id: 'esp-ferramentas', area: 'Especialistas', descricao: 'ferramentas do especialista vêm primeiro, nenhuma é removida', ok: () => { const s = ESP.selecionar('gastei 50 no mercado', COG.analisar('gastei 50 no mercado'), PESSOAIS), o = ESP.ordenarFerramentas(PESSOAIS, s); return o.length === PESSOAIS.length && s.ids.every(() => true) && ['register_transaction', 'create_bill', 'get_finance'].includes(o[0].function.name) } },
  { id: 'mem-unica', area: 'Memória', descricao: 'moradia é informação única (atualiza, não duplica)', ok: () => MEM.chaveUnica('moro em Recife') === 'moradia' && MEM.chaveUnica('Moro no Rio') === 'moradia' },
  { id: 'mem-parente', area: 'Memória', descricao: 'só o NOME de um parente é único', ok: () => MEM.chaveUnica('minha esposa se chama Ana') === 'parente:esposa' && MEM.chaveUnica('minha esposa gosta de pizza') === null },
  { id: 'mem-repeticao', area: 'Memória', descricao: 'frase longa já dita é detectada como repetição', ok: () => MEM.repetidas('Sua reunião com o Pedro está marcada para amanhã às 14h. Algo mais?', ['Sua reunião com o Pedro está marcada para amanhã às 14h.']).length === 1 },
  { id: 'auto-valor', area: 'Autoverificação', descricao: 'valor inventado é apontado; soma de valores é aceita', ok: () => AV.valoresDivergentes('Você gastou R$ 999,00.', '{"amount":120.5,"x":30}').length === 1 && AV.valoresDivergentes('Total de R$ 150,50.', '{"amount":120.5,"x":30}').length === 0 },
  { id: 'auto-completude', area: 'Autoverificação', descricao: 'pergunta não respondida é apontada', ok: () => AV.perguntasSemResposta('Quanto gastei no mercado? E quando vence o aluguel?', 'No mercado você gastou R$ 300.').length === 1 },
  { id: 'auto-acao', area: 'Autoverificação', descricao: 'ação afirmada sem ferramenta é corrigida; texto honesto não muda', ok: () => !/Agendei/.test(COG.revisarResposta('Pronto! Agendei para amanhã.', { exec: COG.execVazio() }).content) && COG.revisarResposta('Ainda não agendei. Qual horário?', { exec: COG.execVazio() }).content === 'Ainda não agendei. Qual horário?' },
  { id: 'qual-robotico', area: 'Qualidade', descricao: 'tom robótico perde nota de naturalidade', ok: () => COG.avaliar({ texto: 'oi', resposta: 'Como um assistente de IA, espero ter ajudado!', analise: COG.analisar('oi') }).naturalidade < 100 },
  { id: 'com-formato', area: 'Comunicação', descricao: '"resuma em tópicos" vira instrução de formato', ok: () => N.estiloPedido('resuma em tópicos o que tenho essa semana').length === 2 },
  { id: 'com-simples', area: 'Comunicação', descricao: '"explica como se eu fosse leigo" pede linguagem simples', ok: () => N.estiloPedido('me explica como se eu fosse leigo o que é CDI').some((l) => /simples/.test(l)) },
  { id: 'pro-optout', area: 'Proatividade', descricao: '"pare de me dar sugestões" desliga; "pode voltar a sugerir" religa', ok: () => PRO.DESLIGAR.test('pare de me dar sugestoes') && PRO.RELIGAR.test('pode voltar a sugerir') && !PRO.DESLIGAR.test('me de sugestoes de presente') },
  { id: 'exe-sensivel', area: 'Execução', descricao: 'ferramentas destrutivas exigem confirmação; as comuns não', ok: () => COG.ehSensivel('excluir_cliente') && !COG.ehSensivel('create_task') },
  { id: 'fb-motivos', area: 'Feedback', descricao: 'motivos de avaliação conhecidos', ok: () => ['incorreta', 'incompleta', 'muito_longa', 'muito_curta', 'nao_executou'].every((m) => m in FB.MOTIVOS) },
]
export async function rodarBateria(gravar = true) {
  const falhas: { id: string; area: string; descricao: string; erro?: string }[] = [], porArea: Record<string, { total: number; ok: number }> = {}
  for (const c of BATERIA) {
    let ok = false, erro: string | undefined
    try { ok = !!c.ok() } catch (e: any) { erro = String(e?.message || e).slice(0, 120) }
    porArea[c.area] = porArea[c.area] || { total: 0, ok: 0 }; porArea[c.area].total++; if (ok) porArea[c.area].ok++
    if (!ok) falhas.push({ id: c.id, area: c.area, descricao: c.descricao, ...(erro ? { erro } : {}) })
  }
  const r = { total: BATERIA.length, aprovados: BATERIA.length - falhas.length, falhas, porArea, em: nowIso() }
  if (gravar) await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['bateria', JSON.stringify(r), !falhas.length, nowIso()]).catch(() => {})
  return r
}

/* ---------- indicadores e regressão ---------- */
const med = (xs: number[]) => (xs.length ? Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) : null)
export async function indicadores() {
  const agora = Date.now(), sem = 7 * 864e5
  const ev = (await q('SELECT overall, scores, specialists, level2, feedback, created_at FROM cognition_evals ORDER BY id DESC LIMIT 5000').catch(() => [] as any[])) as any[]
  const idade = (r: any) => agora - Date.parse(String(r.created_at))
  const a = ev.filter((r) => idade(r) <= sem), b = ev.filter((r) => idade(r) > sem && idade(r) <= 2 * sem)
  const dims = ['precisao', 'coerencia', 'naturalidade', 'clareza', 'contexto', 'resolucao']
  const dim = (xs: any[], d: string) => med(xs.map((r) => Number(J<any>(r.scores, {})[d])).filter(Number.isFinite))
  const semanas = { atual: { n: a.length, geral: med(a.map((r) => Number(r.overall))), ...Object.fromEntries(dims.map((d) => [d, dim(a, d)])) }, anterior: { n: b.length, geral: med(b.map((r) => Number(r.overall))), ...Object.fromEntries(dims.map((d) => [d, dim(b, d)])) } }
  const porEsp = new Map<string, number[]>()
  for (const r of ev.slice(0, 2000)) for (const e of J<string[]>(r.specialists, []).slice(0, 1)) porEsp.set(e, [...(porEsp.get(e) || []), Number(r.overall)])
  const n2 = ev.slice(0, 2000).map((r) => J<any>(r.level2, null)).filter(Boolean)
  const planos = (await q('SELECT status FROM assistant_plans ORDER BY id DESC LIMIT 2000').catch(() => [] as any[])) as any[]
  const sug = (await q('SELECT kind, accepted FROM proactive_log ORDER BY id DESC LIMIT 2000').catch(() => [] as any[])) as any[]
  const respondidas = sug.filter((s) => s.accepted != null), aceitas = respondidas.filter((s) => s.accepted === true || s.accepted === 1 || s.accepted === 't')
  const bat = await one("SELECT result, ok, created_at FROM intel_runs WHERE kind = 'bateria' ORDER BY id DESC LIMIT 1").catch(() => null)
  return {
    semanas, feedback: await FB.resumo(),
    especialistas: [...porEsp].map(([id, v]) => ({ id, nome: ESP.especialista(id).nome, n: v.length, media: med(v) })).sort((x, y) => y.n - x.n),
    planos: { total: planos.length, concluidos: planos.filter((p) => p.status === 'concluido').length, ativos: planos.filter((p) => p.status === 'ativo').length, abandonados: planos.filter((p) => p.status === 'abandonado').length },
    autoverificacao: { verificadas: n2.filter((x) => x.autoverificacao).length, comProblema: n2.filter((x) => x.autoverificacao?.problemas?.length).length, revisadas: n2.filter((x) => x.autoverificacao?.revisada).length },
    proatividade: { sugestoes: sug.length, respondidas: respondidas.length, aceitas: aceitas.length, taxaAceite: respondidas.length ? Math.round((aceitas.length / respondidas.length) * 100) : null },
    bateria: bat ? { ...J<any>(bat.result, {}), ok: bat.ok === true || bat.ok === 1 || bat.ok === 't' } : null,
  }
}
export function alertasDe(ind: Awaited<ReturnType<typeof indicadores>>) {
  const A: string[] = [], s = ind.semanas
  if (s.atual.n >= 20 && s.anterior.n >= 20 && s.atual.geral != null && s.anterior.geral != null && s.anterior.geral - s.atual.geral >= 5) A.push(`Nota geral caiu de ${s.anterior.geral} para ${s.atual.geral} na última semana.`)
  for (const d of ['precisao', 'coerencia', 'naturalidade', 'clareza', 'contexto', 'resolucao']) { const x = (s.atual as any)[d], y = (s.anterior as any)[d]; if (s.atual.n >= 20 && s.anterior.n >= 20 && x != null && y != null && y - x >= 8) A.push(`${d} caiu de ${y} para ${x}.`) }
  const f = ind.feedback; if (f.n7d >= 20 && f.taxa7d != null && f.taxa7dAnterior != null && f.taxa7dAnterior - f.taxa7d >= 10) A.push(`Avaliações positivas caíram de ${f.taxa7dAnterior}% para ${f.taxa7d}%.`)
  if (ind.bateria && !ind.bateria.ok) A.push(`Bateria automática com ${ind.bateria.falhas?.length || 0} cenário(s) falhando.`)
  return A
}
/** Roda bateria + indicadores e avisa os administradores (uma vez por dia) se houver regressão. */
/* ---------- Fase 3: diagnóstico do corpus e desempenho de ponta a ponta ---------- */
/** Roda o corpus de diagnóstico (sintético) e guarda só os números e os ids das falhas. */
export async function rodarDiagnostico(gravar = true) {
  const D = await import('./diagnostico/executar.js'), r = D.diagnosticar()
  const resumo = { em: r.em, taxa: r.taxa, verificacoes: r.verificacoes, aprovadas: r.aprovadas, validacao: { taxa: r.validacao.taxa, verificacoes: r.validacao.verificacoes, aprovadas: r.validacao.aprovadas },
    porArea: r.porArea, falhas: [...r.falhas, ...r.validacao.falhas].map((f: any) => ({ id: f.id, area: f.area, componente: f.componente })), latenciaPorMensagemUs: Math.round(r.latencia.porMensagem.mediaUs / r.latencia.casos) }
  if (gravar) await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['diagnostico', JSON.stringify(resumo), resumo.falhas.length === 0, nowIso()]).catch(() => {})
  return resumo
}
/** Fotografia do desempenho real do chat (memória do processo: últimas 500 mensagens) para acompanhar ao longo do tempo. */
export async function fotografarDesempenho(gravar = true) {
  const T = await import('../lib/timing.js'), r: any = T.resumoTempos()
  const g = (x: any) => ({ mensagens: x.mensagens, totalMedia: x.totalMedia, totalP95: x.totalP95, consultasMedia: x.consultasMedia, consultasP95: x.consultasP95, etapas: Object.fromEntries(Object.entries(x.etapas || {}).filter(([k]) => k.startsWith('ia')).map(([k, v]: any) => [k, v.media])) })
  const f = { em: nowIso(), comIA: g(r.comIA), internas: g(r.internas) }
  if (gravar && (f.comIA.mensagens || f.internas.mensagens)) await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['desempenho', JSON.stringify(f), true, nowIso()]).catch(() => {})
  return f
}
const ultimoRun = async (kind: string, pular = 0) => { const r = await one(`SELECT result FROM intel_runs WHERE kind = $1 ORDER BY id DESC LIMIT 1 OFFSET ${pular}`, [kind]).catch(() => null); return r ? J<any>(r.result, null) : null }
export async function desempenhoEDiagnostico() {
  return { diagnostico: await ultimoRun('diagnostico'), diagnosticoAnterior: await ultimoRun('diagnostico', 1), desempenhoAgora: await fotografarDesempenho(false), desempenhoAnterior: await ultimoRun('desempenho') }
}
export function alertasFase3(x: Awaited<ReturnType<typeof desempenhoEDiagnostico>>) {
  const A: string[] = [], d = x.diagnostico, a = x.diagnosticoAnterior
  if (d && d.falhas?.length) A.push(`Diagnóstico com ${d.falhas.length} verificação(ões) falhando (${d.taxa}%; casos novos ${d.validacao?.taxa}%).`)
  if (d && a && a.taxa - d.taxa >= 1) A.push(`Acerto do diagnóstico caiu de ${a.taxa}% para ${d.taxa}%.`)
  const ag = x.desempenhoAgora?.comIA, an = x.desempenhoAnterior?.comIA
  if (ag?.mensagens >= 20 && ag.consultasMedia != null && ag.consultasMedia > 60) A.push(`Muitas consultas ao banco por mensagem com IA (${ag.consultasMedia}).`)
  if (ag?.mensagens >= 20 && an?.mensagens >= 20 && an.totalP95 > 0 && ag.totalP95 > an.totalP95 * 1.5 && ag.totalP95 - an.totalP95 > 1500) A.push(`Tempo de resposta (p95) subiu de ${an.totalP95} ms para ${ag.totalP95} ms.`)
  return A
}
export async function monitorar() {
  void import('./aprendizado.js').then((m) => m.vigiar()).catch((e) => console.error('[aprendizado] vigilância:', e?.message)) // Fase 6
  const cfg = await N.intelCfg(); if (!cfg.ativo || !cfg.monitor) return { alertas: [], pulado: true }
  await rodarBateria(true); await rodarDiagnostico(true)
  const anterior = await ultimoRun('desempenho'); await fotografarDesempenho(true)
  const ind = await indicadores(), f3 = await desempenhoEDiagnostico(), alertas = [...alertasDe(ind), ...alertasFase3({ ...f3, desempenhoAnterior: anterior })]
  await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['monitor', JSON.stringify({ alertas }), !alertas.length, nowIso()]).catch(() => {})
  if (alertas.length) {
    const dia = nowIso().slice(0, 10)
    for (const a of await q("SELECT id FROM users WHERE role IN ('admin','superadmin') AND status = 'active'").catch(() => [] as any[]))
      await notify(Number(a.id), { type: 'sistema', title: 'Inteligência: possível regressão', body: alertas.join(' '), link: '/admin', ref: `intel-regressao-${dia}` }).catch(() => {})
  }
  return { alertas }
}
export async function ultimosAlertas() { const r = await one("SELECT result, created_at FROM intel_runs WHERE kind = 'monitor' ORDER BY id DESC LIMIT 1").catch(() => null); return r ? { ...J<any>(r.result, {}), em: String(r.created_at) } : null }
