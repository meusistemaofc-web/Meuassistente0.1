// POLÍTICA APRENDIDA (Fase 6) — o que o aprendizado contínuo pode mudar no comportamento do assistente.
// Segurança por construção:
//  • só PARÂMETROS em lista fechada, com limites (nunca código, modelo, provedor, prompt livre ou permissões);
//  • textos de instrução vêm de um catálogo fixo (o feedback nunca vira texto de prompt → sem injeção);
//  • cada mudança é uma VERSÃO nova (com a versão-mãe): aprovar, liberar gradualmente, promover e reverter;
//  • versão padrão = comportamento idêntico ao de antes da Fase 6.
import { AsyncLocalStorage } from 'node:async_hooks'
import { createHash } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { fail } from '../lib/http.js'

export const AREAS = ['agenda', 'financas', 'tarefas', 'compras', 'memoria', 'crm', 'agenda_empresa', 'negocio', 'acolhimento', 'geral'] as const // = especialistas
export const AGENTES_IDS = ['pesquisa', 'analise', 'escrita', 'vendas', 'planejamento'] as const
export const ESTILOS = ['curta', 'detalhada', 'passos'] as const
/** Tipos de sinal preditivo (Fase 7) que podem ser silenciados por uma melhoria aprovada. */
export const TIPOS_PREDITIVOS = ['conflito', 'proximo', 'sem_contato', 'sem_horario', 'confirmar', 'esquecimento', 'acompanhamento', 'saldo_receber', 'duplicidade', 'situacao_desatualizada', 'tarefa_atrasada', 'lembrete_atrasado', 'plano_pendente', 'compra_recorrente', 'conta_vencendo', 'conta_atrasada', 'conta_recorrente', 'conta_sem_valor', 'ritmo_gastos', 'cliente_recorrente', 'retorno_cliente', 'cliente_sumido', 'procura', 'campanha', 'crm_lead', 'crm_parada', 'crm_retorno', 'crm_fechamento', 'pedido_recorrente']
/** Catálogo FIXO de orientações de uso de ferramentas (o aprendizado escolhe uma chave; nunca escreve o texto). */
export const DICAS: Record<string, string> = {
  confirmar_dados: 'Antes de usar esta ferramenta, confira se tem todos os dados obrigatórios; se faltar algo, pergunte só o que falta.',
  consultar_antes: 'Consulte os registros existentes antes de criar um novo, para não duplicar.',
  informar_falha: 'Se a ferramenta falhar, diga claramente o que não foi feito e como resolver; nunca afirme que concluiu.',
  usar_ferramenta: 'Quando o pedido for uma ação, execute com a ferramenta em vez de só explicar como fazer.',
  data_completa: 'Informe datas e horários por extenso (dia da semana, dia/mês e hora) ao confirmar.',
}
const ESTILO_TXT: Record<string, string> = {
  curta: 'respostas curtas e diretas (no máximo 3 frases, salvo pedido do usuário)',
  detalhada: 'respostas mais completas, explicando o porquê em partes curtas',
  passos: 'respostas organizadas em passos numerados',
}
export const POLITICA_PADRAO = {
  raciocinio: { planejarSempre: [] as string[], revisarSempre: [] as string[] },
  memoria: { limiteChars: 1800, maxFatos: 8 },
  agentes: { evitar: {} as Record<string, string[]> },
  ferramentas: { dicas: {} as Record<string, string> },
  qualidade: { estilo: {} as Record<string, string>, perguntarAntes: [] as string[] },
  preditivo: { silenciar: [] as string[] }, // Fase 7: tipos de alerta preditivo silenciados (muitos falsos alertas)
}
export type Politica = typeof POLITICA_PADRAO
const clone = <T>(x: T): T => JSON.parse(JSON.stringify(x))

/** Valida uma política inteira: só chaves conhecidas, valores do catálogo e limites. Lança erro legível. */
export function validarPolitica(p: any): Politica {
  const out = clone(POLITICA_PADRAO), bad = (m: string) => fail(400, 'Política inválida: ' + m, 'invalid')
  const lista = (v: any, ok: readonly string[], nome: string) => { if (!Array.isArray(v)) bad(nome); const r: string[] = [...new Set<string>(v.map(String))]; for (const x of r) if (!ok.includes(x)) bad(`${nome} (${x})`); return r }
  const r = p?.raciocinio || {}, m = p?.memoria || {}, a = p?.agentes || {}, f = p?.ferramentas || {}, ql = p?.qualidade || {}
  if (r.planejarSempre) out.raciocinio.planejarSempre = lista(r.planejarSempre, AREAS, 'planejarSempre')
  if (r.revisarSempre) out.raciocinio.revisarSempre = lista(r.revisarSempre, AREAS, 'revisarSempre')
  if (m.limiteChars !== undefined) { const n = Number(m.limiteChars); if (!Number.isInteger(n) || n < 800 || n > 4000) bad('limiteChars (800 a 4000)'); out.memoria.limiteChars = n }
  if (m.maxFatos !== undefined) { const n = Number(m.maxFatos); if (!Number.isInteger(n) || n < 3 || n > 16) bad('maxFatos (3 a 16)'); out.memoria.maxFatos = n }
  for (const [k, v] of Object.entries(a.evitar || {})) { if (!AREAS.includes(k as any)) bad('agentes.evitar ' + k); out.agentes.evitar[k] = lista(v, AGENTES_IDS, 'agentes ' + k) }
  for (const [k, v] of Object.entries(f.dicas || {})) { if (!/^[a-z_]{3,40}$/.test(k) || !(String(v) in DICAS)) bad('dica ' + k); out.ferramentas.dicas[k] = String(v) }
  for (const [k, v] of Object.entries(ql.estilo || {})) { if (!AREAS.includes(k as any) || !ESTILOS.includes(v as any)) bad('estilo ' + k); out.qualidade.estilo[k] = String(v) }
  if (ql.perguntarAntes) out.qualidade.perguntarAntes = lista(ql.perguntarAntes, AREAS, 'perguntarAntes')
  if (p?.preditivo?.silenciar) out.preditivo.silenciar = lista(p.preditivo.silenciar, TIPOS_PREDITIVOS, 'preditivo.silenciar')
  return out
}
export interface Mudanca { op: 'set' | 'add' | 'remove'; caminho: string; valor?: any }
/** Aplica UMA mudança (caminho em lista fechada) e valida o resultado. */
export function aplicarMudanca(base: Politica, m: Mudanca): Politica {
  const p: any = clone(base), partes = String(m.caminho || '').split('.')
  const CAMINHOS = /^(preditivo\.silenciar|raciocinio\.(planejarSempre|revisarSempre)|memoria\.(limiteChars|maxFatos)|agentes\.evitar\.[a-z_]+|ferramentas\.dicas\.[a-z_]+|qualidade\.(estilo\.[a-z_]+|perguntarAntes))$/
  if (!CAMINHOS.test(m.caminho)) fail(400, 'Caminho de política não permitido: ' + m.caminho, 'invalid')
  let o = p; for (const k of partes.slice(0, -1)) { o[k] = o[k] ?? {}; o = o[k] }
  const k = partes[partes.length - 1]
  if (m.op === 'set') o[k] = m.valor
  else if (m.op === 'add') { const cur = Array.isArray(o[k]) ? o[k] : []; o[k] = [...new Set([...cur, ...(Array.isArray(m.valor) ? m.valor : [m.valor])])] }
  else if (m.op === 'remove') { if (Array.isArray(o[k])) o[k] = o[k].filter((x: any) => !(Array.isArray(m.valor) ? m.valor : [m.valor]).includes(x)); else delete o[k] }
  else fail(400, 'Operação inválida.', 'invalid')
  return validarPolitica(p)
}
/** Diferenças legíveis entre duas políticas (painel e histórico). */
export function diferencas(a: Politica, b: Politica): string[] {
  const out: string[] = [], plano = (o: any, pre = ''): [string, any][] => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' && !Array.isArray(v) ? plano(v, pre + k + '.') : [[pre + k, v]]))
  const A = new Map(plano(a)), B = new Map(plano(b))
  for (const k of new Set([...A.keys(), ...B.keys()])) if (JSON.stringify(A.get(k) ?? null) !== JSON.stringify(B.get(k) ?? null)) out.push(`${k}: ${JSON.stringify(A.get(k) ?? null)} → ${JSON.stringify(B.get(k) ?? null)}`)
  return out
}

/* ---------- configuração, versões e liberação gradual ---------- */
export const APR_DEFAULT = { ativo: true, versaoAtiva: null as number | null, gradual: null as null | { versao: number; pct: number; desde: string }, minUsuarios: 3, minAmostra: 20, pararGradualEmRegressao: true }
export type AprCfg = typeof APR_DEFAULT
/** fresco = lê direto do banco (decisões do administrador e vigilância); sem ele, usa a memória da requisição (chat, mais rápido). */
export const aprCfg = async (fresco = false): Promise<AprCfg> => {
  if (!fresco) return { ...APR_DEFAULT, ...(await getConfig<any>('aprendizado', {})) }
  const r = await one('SELECT value FROM app_config WHERE key = $1', ['aprendizado']).catch(() => null)
  return { ...APR_DEFAULT, ...J<any>(r?.value ?? null, {}) }
}
export async function salvarCfg(p: Partial<AprCfg>) { const r = await one('SELECT value FROM app_config WHERE key = $1', ['aprendizado']).catch(() => null); const c = { ...J<any>(r?.value ?? null, {}), ...p, atualizadoEm: nowIso() }; await setConfig('aprendizado', c); limparCache(); return c as AprCfg }

let cache: { em: number; versoes: Map<number, Politica> } = { em: 0, versoes: new Map() }
export const limparCache = () => { cache = { em: 0, versoes: new Map() } }
export async function versao(id: number | null): Promise<Politica> {
  if (!id) return clone(POLITICA_PADRAO)
  if (Date.now() - cache.em > 30_000) cache = { em: Date.now(), versoes: new Map() }
  if (!cache.versoes.has(id)) { const r = await one('SELECT policy FROM learning_policy_versions WHERE id = $1', [id]).catch(() => null); cache.versoes.set(id, r ? validarPolitica(J<any>(r.policy, {})) : clone(POLITICA_PADRAO)) }
  return clone(cache.versoes.get(id)!)
}
export async function criarVersao(p: Politica, o: { parent: number | null; proposta?: number | null; nota?: string; por?: number | null }) {
  const pol = validarPolitica(p)
  const r = await one('INSERT INTO learning_policy_versions (policy, parent_id, proposal_id, note, created_by, created_at) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id', [JSON.stringify(pol), o.parent, o.proposta ?? null, (o.nota || '').slice(0, 300), o.por ?? null, nowIso()])
  return Number(r!.id)
}
/** Grupo de liberação gradual: estável por usuário (o mesmo usuário fica sempre no mesmo grupo enquanto durar o teste). */
export const balde = (userId: number, versao: number) => parseInt(createHash('sha256').update(`apr:${versao}:${userId}`).digest('hex').slice(0, 8), 16) % 100

const forcada = new AsyncLocalStorage<{ politica: Politica; versao: number | null; grupo: string }>()
/** Ambiente de experimentação: roda fn com uma política candidata, isolada da produção. */
export const comPolitica = <T>(p: Politica, fn: () => Promise<T>) => forcada.run({ politica: p, versao: null, grupo: 'experimento' }, fn)
/** Política que vale para este usuário agora (estável, ou a candidata se ele estiver no grupo da liberação gradual). */
export async function politicaPara(userId: number): Promise<{ politica: Politica; versao: number | null; grupo: 'estavel' | 'gradual' | 'experimento' | 'desligado' }> {
  const f = forcada.getStore(); if (f) return f as any
  const c = await aprCfg(); if (!c.ativo) return { politica: clone(POLITICA_PADRAO), versao: null, grupo: 'desligado' }
  if (c.gradual && balde(userId, c.gradual.versao) < c.gradual.pct) return { politica: await versao(c.gradual.versao), versao: c.gradual.versao, grupo: 'gradual' }
  return { politica: await versao(c.versaoAtiva), versao: c.versaoAtiva, grupo: 'estavel' }
}

/* ---------- aplicação no núcleo (só instruções do catálogo, só para a área do pedido) ---------- */
export function instrucoes(p: Politica, area: string | null, ferramentas: string[], temPlano: boolean): string[] {
  const L: string[] = [], a = area || 'geral'
  const est = p.qualidade.estilo[a]; if (est) L.push(`Aprendizado aprovado para este tipo de pedido: prefira ${ESTILO_TXT[est]}.`)
  if (p.qualidade.perguntarAntes.includes(a)) L.push('Aprendizado aprovado: neste tipo de pedido, se algum dado essencial estiver ambíguo, confirme com uma pergunta curta antes de agir.')
  if (p.raciocinio.planejarSempre.includes(a) && !temPlano) L.push('Aprendizado aprovado: antes de responder, organize mentalmente o pedido em etapas e confira se todas foram atendidas.')
  const dicas = [...new Set(ferramentas.map((f) => p.ferramentas.dicas[f]).filter(Boolean))]
  for (const d of dicas) L.push('Uso de ferramentas (aprendizado aprovado): ' + DICAS[d])
  return L
}
export const revisarSempre = (p: Politica, area: string | null) => p.raciocinio.revisarSempre.includes(area || 'geral')
export const agentesEvitados = (p: Politica, area: string | null) => p.agentes.evitar[area || 'geral'] || []

/* ---------- histórico ---------- */
export async function listarVersoes(limite = 30) {
  const c = await aprCfg(true), rows = await q('SELECT * FROM learning_policy_versions ORDER BY id DESC LIMIT $1', [limite]).catch(() => [] as any[])
  return (rows as any[]).map((r) => ({ id: Number(r.id), pai: r.parent_id == null ? null : Number(r.parent_id), proposta: r.proposal_id == null ? null : Number(r.proposal_id), nota: r.note || '', criadaEm: String(r.created_at), por: r.created_by == null ? null : Number(r.created_by), ativa: Number(r.id) === c.versaoAtiva, gradual: c.gradual?.versao === Number(r.id) ? c.gradual.pct : null, politica: validarPolitica(J<any>(r.policy, {})) }))
}
