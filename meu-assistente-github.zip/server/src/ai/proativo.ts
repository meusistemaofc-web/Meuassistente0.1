// INTELIGÊNCIA PROATIVA — no máximo UMA sugestão por resposta, só quando ajuda de verdade e nunca de forma invasiva:
// • depois de agendar: oferece um lembrete (se nenhum foi criado);
// • conta pendente vencendo em até 3 dias (uma vez por conta);
// • três ou mais tarefas paradas há mais de uma semana (no máximo a cada 3 dias).
// Limites: intervalo mínimo de 2 h entre sugestões não ligadas ao que acabou de ser feito; nada em desabafo,
// frustração, pressa ou quando a resposta já termina com uma pergunta; o usuário desliga dizendo "pare de sugerir".
import { q, one, nowIso, J, memoRequisicao } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import type { Analise } from './cognition.js'
import { listItems, serialize } from '../routes/items.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
export interface Prefs { proactive: boolean; style: { tamanho?: 'curto' | 'detalhado' } }
export async function prefsDe(userId: number): Promise<Prefs> {
  const m = memoRequisicao(), k = 'prefs:' + userId
  if (m?.has(k)) return structuredClone(m.get(k) as Prefs)
  const r = await one('SELECT proactive, style FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null)
  const p: Prefs = { proactive: r ? !(r.proactive === false || r.proactive === 0 || r.proactive === 'f' || r.proactive === 'false') : true, style: J<any>(r?.style, {}) }
  m?.set(k, p); return structuredClone(p)
}
export async function salvarPrefs(userId: number, p: Partial<Prefs>) {
  memoRequisicao()?.delete('prefs:' + userId)
  const atual = await prefsDe(userId), novo = { ...atual, ...p, style: p.style ?? atual.style }
  const ex = await one('SELECT user_id FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null)
  memoRequisicao()?.delete('prefs:' + userId)
  if (ex) await q('UPDATE user_intel_prefs SET proactive = $1, style = $2, updated_at = $3 WHERE user_id = $4', [novo.proactive, JSON.stringify(novo.style), nowIso(), userId])
  else await q('INSERT INTO user_intel_prefs (user_id, proactive, style, updated_at) VALUES ($1,$2,$3,$4)', [userId, novo.proactive, JSON.stringify(novo.style), nowIso()])
  return novo
}
export const DESLIGAR = /\b(para|pare|parar|chega) de (me )?(dar |fazer |mandar )?(sugest\w*|suger\w*|dicas)\b|\bnao quero (mais )?(sugest\w*|suger\w*|dicas)\b|\bsem (sugest\w*|suger\w*|dicas)\b/
export const RELIGAR = /\b(pode|volte a|voltar a|volta a) (me )?(dar |fazer |mandar )?(sugest\w*|suger\w*|dicas)\b|\b(quero|ativar|ative) (as )?(sugest\w*|suger\w*|dicas)\b/

/** Resposta do usuário à última sugestão desta conversa (aceitou/recusou) — indicador de utilidade. */
export async function registrarResposta(userId: number, convId: string, an: Analise) {
  if (an.tipo !== 'confirmacao' && an.tipo !== 'negacao') return
  const r = await one('SELECT id, created_at, accepted FROM proactive_log WHERE user_id = $1 AND conversation_id = $2 ORDER BY id DESC LIMIT 1', [userId, convId]).catch(() => null)
  if (!r || r.accepted != null || Date.now() - Date.parse(String(r.created_at)) > 30 * 60e3) return
  await q('UPDATE proactive_log SET accepted = $1 WHERE id = $2', [an.tipo === 'confirmacao', r.id])
  // sugestão preditiva: a resposta do usuário vira aceite ou dispensa (indicadores de recomendações aceitas)
  const k = await one('SELECT kind, ref FROM proactive_log WHERE id = $1', [r.id]).catch(() => null)
  if (k?.kind === 'previsao') await (await import('./preditivo-servico.js')).reagir(userId, String(k.ref), an.tipo === 'confirmacao' ? 'aceita' : 'dispensada').catch(() => {})
}

const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d),)/g, '.')
const addDias = (d: string, n: number) => new Date(Date.parse(d + 'T12:00:00Z') + n * 864e5).toISOString().slice(0, 10)
const quando = (dia: string, hoje: string) => (dia === hoje ? 'hoje' : dia === addDias(hoje, 1) ? 'amanhã' : `em ${dia.slice(8, 10)}/${dia.slice(5, 7)}`)

export interface Sugestao { texto: string; kind: string; ref: string }
const CACHE_PRED = new Map<number, { em: number; r: any }>() // análise preditiva para sugestões no chat (5 min)
export async function sugerir(u: SessionUser, o: { convId: string; an: Analise; done: { name: string; result: any }[]; texto: string; resposta: string; hoje: string }): Promise<Sugestao | null> {
  const p = await prefsDe(u.id); if (!p.proactive) return null
  if (o.an.tipo === 'desabafo' || ['frustrado', 'urgente', 'ansioso'].includes(o.an.emocao) || /\?\s*$/.test(o.resposta.replace(/⟦[^⟧]*⟧/g, '').trim())) return null
  const ja = async (kind: string, ref: string) => !!(await one('SELECT id FROM proactive_log WHERE user_id = $1 AND kind = $2 AND ref = $3', [u.id, kind, ref]).catch(() => null))
  // (a) acabou de agendar e não criou lembrete
  const ap = o.done.find((d) => d.name === 'create_appointment' && d.result?.ok === true)?.result?.created?.[0]
  if (ap && !o.done.some((d) => d.name === 'create_reminder' && d.result?.ok) && ap.time && !(Array.isArray(ap.reminders) && ap.reminders.length) && !(await ja('lembrete_compromisso', String(ap.id))))
    return { kind: 'lembrete_compromisso', ref: String(ap.id), texto: 'Quer que eu te lembre 1 hora antes desse compromisso?' }
  // limite de frequência para sugestões não ligadas ao que acabou de ser feito
  const ult = await one("SELECT created_at FROM proactive_log WHERE user_id = $1 AND kind <> 'lembrete_compromisso' ORDER BY id DESC LIMIT 1", [u.id]).catch(() => null)
  if (ult && Date.now() - Date.parse(String(ult.created_at)) < 2 * 3600e3) return null
  // (b) conta vencendo em até 3 dias
  const contas = (await listItems(u.id, 'bill', "AND status = 'pending' AND day >= $3 AND day <= $4 ORDER BY day LIMIT 5", [o.hoje, addDias(o.hoje, 3)]).catch(() => [])).map(serialize) as any[]
  const s = nrm(o.texto + ' ' + o.resposta)
  for (const c of contas) if (!(await ja('conta_vencendo', String(c.id))) && !s.includes(nrm(c.name || '').slice(0, 8)))
    return { kind: 'conta_vencendo', ref: String(c.id), texto: `Aproveitando: a conta "${c.name}" (${brl(c.amount)}) vence ${quando(String(c.dueDate), o.hoje)}. Quer que eu crie um lembrete?` }
  // (c) tarefas paradas
  const antigas = (await listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') AND created_at < $3", [new Date(Date.now() - 7 * 864e5).toISOString()]).catch(() => [])).length
  if (antigas >= 3) {
    const ultT = await one("SELECT created_at FROM proactive_log WHERE user_id = $1 AND kind = 'tarefas_paradas' ORDER BY id DESC LIMIT 1", [u.id]).catch(() => null)
    if (!ultT || Date.now() - Date.parse(String(ultT.created_at)) > 3 * 864e5) return { kind: 'tarefas_paradas', ref: o.hoje, texto: `Você tem ${antigas} tarefas abertas há mais de uma semana. Quer revisar quais ainda fazem sentido?` }
  }
  // (d) Fase 7: o sinal preditivo mais importante (preferências, horário, frequência e sem repetir o mesmo aviso)
  try {
    const PS = await import('./preditivo-servico.js'), c = CACHE_PRED.get(u.id), r = c && Date.now() - c.em < 300_000 ? c.r : await PS.paraUsuario(u)
    if (!c || c.r !== r) CACHE_PRED.set(u.id, { em: Date.now(), r }); if (CACHE_PRED.size > 2000) CACHE_PRED.clear()
    if (r.ativo && r.sinais.length) {
      const relevantes = r.sinais.filter((x: any) => x.urgencia !== 'baixa' && !s.includes(nrm(x.titulo).slice(0, 12)))
      const [esc] = await PS.escolher(u.id, relevantes, 'chat', 0, 1)
      if (esc) { await PS.registrarAlerta(u.id, esc, 'chat'); return { kind: 'previsao', ref: esc.chave, texto: 'Aproveitando: ' + PS.frase(esc) } }
    }
  } catch (e: any) { console.error('[preditivo] chat:', e?.message) }
  return null
}
export async function registrarSugestao(userId: number, convId: string, s: Sugestao) {
  await q('INSERT INTO proactive_log (user_id, kind, ref, conversation_id, created_at) VALUES ($1,$2,$3,$4,$5)', [userId, s.kind, s.ref, convId, nowIso()])
}
