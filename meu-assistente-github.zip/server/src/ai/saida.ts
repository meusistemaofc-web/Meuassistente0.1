// SAÍDA DA IA → USUÁRIO: o que o modelo devolve nunca chega cru ao chat.
// Modelos (principalmente os locais/menores ou quando trocam de provedor) às vezes:
//  • escrevem a chamada de ferramenta como TEXTO, em vez de usar o recurso de ferramentas: ```json {"name":…,"arguments":…}```,
//    <tool_call>{…}</tool_call>, <function=nome>{…}</function>, [TOOL_CALLS] […] — aqui isso vira chamada de verdade
//    (executada pelo mesmo caminho seguro das outras) e some do texto;
//  • respondem em JSON ({"resposta": "…"}) — o usuário vê só o texto;
//  • citam os marcadores internos do contexto ([C1], [C2]) ou nomes de ferramentas (create_task…) — removidos;
//  • acrescentam dados que não estão no conhecimento recuperado (telefones, prazos, valores) — em respostas baseadas na
//    Biblioteca, frases com números/e-mails/links que não aparecem em nenhuma fonte da conversa são retiradas.

export interface ChamadaTexto { id: string; type: 'function'; function: { name: string; arguments: string } }

const CAMPOS_TEXTO = ['resposta', 'answer', 'response', 'reply', 'content', 'text', 'texto', 'mensagem', 'message', 'output', 'final']
const parse = (s: string): any => { try { return JSON.parse(s) } catch { return undefined } }
/** Objetos JSON de primeiro nível dentro de um texto (balanceando chaves, respeitando strings). */
function objetosJson(t: string): { ini: number; fim: number; v: any }[] {
  const out: { ini: number; fim: number; v: any }[] = []
  for (let i = 0; i < t.length; i++) {
    if (t[i] !== '{' && t[i] !== '[') continue
    let d = 0, str = false, esc = false
    for (let j = i; j < t.length; j++) {
      const c = t[j]
      if (str) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') str = false; continue }
      if (c === '"') str = true
      else if (c === '{' || c === '[') d++
      else if (c === '}' || c === ']') { d--; if (d === 0) { const v = parse(t.slice(i, j + 1)); if (v !== undefined && typeof v === 'object') { out.push({ ini: i, fim: j + 1, v }); i = j } break } }
    }
  }
  return out
}
/** {"name","arguments"} / {"function":{…}} / {"tool","args"} / {"tool_name","parameters"} → chamada, se a ferramenta existir. */
function comoChamada(v: any, nomes: Set<string>): { name: string; args: any } | null {
  if (!v || typeof v !== 'object' || Array.isArray(v)) return null
  const f = v.function && typeof v.function === 'object' ? v.function : v
  const name = String(f.name ?? v.tool ?? v.tool_name ?? v.ferramenta ?? '').trim()
  if (!name || !nomes.has(name)) return null
  let args = f.arguments ?? f.parameters ?? v.args ?? v.arguments ?? v.parameters ?? v.argumentos ?? {}
  if (typeof args === 'string') args = parse(args) ?? {}
  return typeof args === 'object' && args ? { name, args } : null
}

/** Chamadas de ferramenta escritas como texto. Devolve as chamadas e o texto que sobra (sem o JSON), ou null. */
export function extrairChamadas(content: string, nomes: Set<string>): { calls: ChamadaTexto[]; resto: string } | null {
  const t = String(content || ''); if (!t || !/[{[]/.test(t) || !nomes.size) return null
  const achadas: { name: string; args: any }[] = []; let resto = t
  // <function=nome>{args}</function>
  resto = resto.replace(/<function=([a-z_]+)>\s*([\s\S]*?)\s*<\/function>/gi, (m, n, a) => { if (nomes.has(n)) { achadas.push({ name: n, args: parse(a) ?? {} }); return '' } return m })
  for (const o of objetosJson(resto).reverse()) { // de trás para frente: os índices continuam válidos ao recortar
    const lista = Array.isArray(o.v) ? o.v : [o.v], cs = lista.map((x: any) => comoChamada(x, nomes))
    if (cs.length && cs.every(Boolean)) { achadas.unshift(...(cs as any)); resto = resto.slice(0, o.ini) + resto.slice(o.fim) }
  }
  if (!achadas.length) return null
  resto = resto.replace(/<\/?tool_calls?>|\[TOOL_CALLS\]|```(?:json|tool_code|tool)?\s*```|```(?:json|tool_code|tool)?|```/gi, ' ').replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim()
  if (/^[\s:.,;!-]*$/.test(resto) || (resto.length <= 70 && /^(?:(?:claro|ok|okay|certo|beleza|perfeito|pronto|entendido)\s*[!,.]?\s*)?(?:vou|irei|deixa comigo|já vou|registrando|criando|agendando)?[^.!?\n]{0,50}[:.!]?$/i.test(resto) && /^(claro|ok|okay|certo|beleza|perfeito|pronto|entendido|vou|irei|deixa|já|registrando|criando|agendando)\b/i.test(resto))) resto = '' // só o "Claro! Vou registrar:" que antecedia o JSON
  return { calls: achadas.map((c, i) => ({ id: `txt_${Date.now().toString(36)}_${i}`, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args) } })), resto }
}

const NOME_FERRAMENTA = /\b(?:create|get|register|update|complete|add|save|registrar|executar|acompanhar|consultar|crm|negocio|agenda_empresa)_[a-z_]{2,}\b/
/** Texto final para o usuário: tira JSON, blocos de código de dados, marcadores [C1] e menções a ferramentas internas. */
export function limparSaida(content: string): string {
  let t = String(content || '').trim(); if (!t) return t
  // resposta inteira em JSON (ou num bloco ```json```): fica o campo de texto
  const semCerca = t.replace(/^```(?:json)?\s*([\s\S]*?)\s*```$/i, '$1').trim()
  if (/^[{[]/.test(semCerca)) {
    const v = parse(semCerca)
    if (v !== undefined) {
      const achar = (x: any): string => { if (typeof x === 'string') return x; if (!x || typeof x !== 'object') return ''; if (Array.isArray(x)) return x.map(achar).filter(Boolean).join('\n'); for (const k of CAMPOS_TEXTO) if (typeof x[k] === 'string' && x[k].trim()) return x[k]; for (const k of CAMPOS_TEXTO) if (x[k] && typeof x[k] === 'object') { const s = achar(x[k]); if (s) return s } return Object.values(x).filter((s) => typeof s === 'string' && (s as string).length > 15).join(' ') }
      t = achar(v).trim()
    }
  }
  // blocos ```json``` no meio da resposta: não são para o usuário
  t = t.replace(/```(?:json|tool_code|tool)\s*[\s\S]*?```/gi, '').replace(/<\/?tool_calls?>|\[TOOL_CALLS\]/gi, '')
  // marcadores internos do contexto da Biblioteca: [C1], [C1, C2], (C2), [C1][C3]
  t = t.replace(/\s*[[(]C\d+(?:\s*[,;e]\s*C?\d+)*[\])]/g, '')
  // frases que falam das ferramentas internas pelo nome
  if (NOME_FERRAMENTA.test(t)) t = t.split(/(?<=[.!?])\s+|\n/).filter((f) => !NOME_FERRAMENTA.test(f)).join(' ')
  return t.replace(/[ \t]{2,}/g, ' ').replace(/ +([,.!?])/g, '$1').replace(/\n{3,}/g, '\n\n').trim()
}

/** Respostas baseadas na Biblioteca: tira frases com dados específicos (números, e-mails, links) que não aparecem em
 *  nenhuma fonte desta conversa (conhecimento recuperado, pergunta, histórico, instruções). Devolve o texto e quantas saíram. */
export function semDadosInventados(resposta: string, fontes: string): { texto: string; removidas: number } {
  const base = String(fontes || ''), nums = new Set(base.match(/\d+/g) || []), baseMin = base.toLowerCase()
  const marcadores = /⟦[^⟧]*⟧/g, ms = String(resposta || '').match(marcadores) || []
  const frasesR = String(resposta || '').replace(marcadores, '').split(/(?<=[.!?])\s+|\n+/).map((f) => f.trim()).filter(Boolean)
  const inventada = (f: string) => {
    if ((f.match(/\d+/g) || []).some((n) => !nums.has(n))) return true
    if ((f.match(/[\w.+-]+@[\w-]+\.[\w.]+/g) || []).some((e) => !baseMin.includes(e.replace(/[.]+$/, '').toLowerCase()))) return true // sem o ponto final da frase
    if ((f.match(/https?:\/\/[^\s)]+/g) || []).some((u) => !base.includes(u.replace(/[.,;]+$/, '')))) return true
    return false
  }
  const ok = frasesR.filter((f) => !inventada(f))
  return { texto: (ok.join(' ') + (ms.length ? ' ' + ms.join(' ') : '')).trim(), removidas: frasesR.length - ok.length }
}

/** Texto que chega aos pedaços (streaming): o que tem cara de JSON ou de chamada de ferramenta não é mostrado na prévia
 *  (a mensagem final, já limpa, aparece no lugar). Um filtro novo por rodada da IA. */
export function filtrarStream(live?: { onDelta: (s: string) => void; onReset: () => void }) {
  if (!live?.onDelta) return undefined
  let buf = '', decidido = false, bloqueado = false
  const tecnico = /^\s*(\{|\[(?!\w)|```|<tool|<function|\[TOOL)/i, noMeio = /```(?:json|tool)|<tool_call>|<function=|\[TOOL_CALLS\]|\{\s*"(?:name|function|tool)"\s*:/i
  return (d: string) => {
    if (bloqueado) return
    buf += d
    if (!decidido) {
      if (buf.trim().length < 12 && /^\s*[{[`<]/.test(buf)) return // ainda não dá para saber: espera o começo
      if (!buf.trim()) return
      decidido = true
      if (tecnico.test(buf)) { bloqueado = true; return }
      live.onDelta(buf); return
    }
    if (noMeio.test(buf)) { bloqueado = true; live.onReset(); return } // apareceu no meio do texto: some da prévia
    live.onDelta(d)
  }
}
