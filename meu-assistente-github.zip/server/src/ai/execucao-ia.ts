// Fase 8 — as ferramentas que a IA já usava no chat passam pelo mesmo controle de autonomia do motor de execução:
//   • portaoNivel: nível 2 (confirmação) e 3 (autorização explícita) ANTES de executar; autonomia "cautelosa" do usuário;
//   • registrarTurno: cada turno com ações vira uma execução (EX-…) com etapas, nível e verificação no estado real.
import { q, one, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import * as EX from './execucao.js'

const LEITURA = /^(get_|acompanhar_execucao|crm_buscar|crm_historico|crm_oportunidades|crm_inteligencia|negocio_|agenda_empresa_consultar|agenda_empresa_alertas|executar_objetivo)/
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const pend = new Map<string, { t: number; nivel: number }>()
const canon = (a: any) => JSON.stringify(a ?? {}, Object.keys(a ?? {}).sort())
export async function portaoNivel(u: SessionUser, convId: string, name: string, a: any, userText: string): Promise<null | { ok: false; precisaConfirmar: true; nivel: number; aviso: string }> {
  if (LEITURA.test(name) || !(await EX.execCfg()).ativo) return null
  if (['agenda_empresa_decidir', 'crm_atualizar_etapa'].includes(name)) return null // estas já têm confirmação própria (não pergunta duas vezes)
  // valor pago só conta como pagamento quando o usuário falou em pagamento (senão a própria ferramenta o ignora)
  const aa = name === 'update_appointment' && a?.valor_pago !== undefined && !/\b(pag|receb|quit|deposit)/i.test(userText) ? { ...a, valor_pago: undefined } : a
  let nivel = EX.nivelFerramenta(name, aa)
  const cfgN = Number((await EX.execCfg()).niveis['ia:' + name] || 0); if (cfgN > nivel) nivel = cfgN as any
  if (nivel < 2 && (await EX.autonomia(u.id)) === 'cautelosa') nivel = 2
  const key = `${u.id}|${convId}|${name}|${canon(a)}`, agora = Date.now(), s = nrm(userText)
  for (const [k, x] of pend) if (agora - x.t > 600_000) pend.delete(k)
  // a confirmação vem em outra mensagem ("sim", "autorizo"): vale o nível que foi pedido na primeira vez
  const ant = pend.get(key); if (ant && ant.nivel > nivel) nivel = ant.nivel as any
  if (nivel < 2) return null
  const ok = nivel === 3 ? /\bautoriz/.test(s) : /^(sim|s|pode|ok|confirmo|confirma|isso|pode sim|claro|autorizo)\b/.test(s.trim())
  if (pend.has(key) && ok) { pend.delete(key); return null }
  pend.set(key, { t: agora, nivel })
  return { ok: false, precisaConfirmar: true, nivel, aviso: nivel === 3
    ? 'Operação de NÍVEL 3 (pagamento, valor recebido ou exclusão): ainda NÃO foi executada. Diga ao usuário exatamente o que será feito e peça que responda "autorizo". Só chame a ferramenta de novo depois disso.'
    : 'Alteração relevante (NÍVEL 2): ainda NÃO foi executada. Diga ao usuário, em uma frase, exatamente o que será alterado e peça um "sim". Só chame a ferramenta de novo depois da confirmação.' }
}
const ids = (r: any) => [...(Array.isArray(r?.created) ? r.created : []).map((c: any) => Number(c?.id)), ...(r?.updated?.id ? [Number(r.updated.id)] : [])].filter((n) => Number.isInteger(n) && n > 0)
/** Registra as ações (não leituras) de um turno da IA como uma execução, conferindo no banco o que foi gravado. */
export async function registrarTurno(u: SessionUser, convId: string, texto: string, done: { name: string; result: any; args?: any }[]) {
  const acoes = done.filter((d) => !LEITURA.test(d.name) && !d.result?.precisaConfirmar && !d.result?.deduped)
  if (!acoes.length) return null
  const steps: EX.Passo[] = []
  for (const [i, d] of acoes.entries()) {
    const ok = d.result?.ok !== false && !d.result?.error, alvo = ids(d.result)
    let verificado = false
    if (ok && alvo.length) { const r = await one(`SELECT COUNT(*) AS n FROM items WHERE user_id = $1 AND id IN (${alvo.map((_, k) => '$' + (k + 2)).join(',')})`, [u.id, ...alvo]).catch(() => null); verificado = Number(r?.n || 0) === alvo.length }
    else if (ok && /^crm_/.test(d.name)) verificado = true // serviços do CRM já validam e confirmam o registro na própria resposta
    steps.push({ n: i + 1, op: 'ia:' + d.name, rotulo: d.name.replace(/_/g, ' '), args: {}, depende: [], nivel: EX.nivelFerramenta(d.name, d.args), status: ok ? 'feito' : 'falhou', tentativas: 1, verificado, erro: ok ? undefined : String(d.result?.error || 'falhou').slice(0, 200), classe: ok ? undefined : 'validacao', resultado: alvo.length ? { ids: alvo } : undefined, inicio: nowIso(), fim: nowIso() })
  }
  const okV = steps.filter((s) => s.status === 'feito' && s.verificado).length, status = okV === steps.length ? 'concluida' : okV ? 'parcial' : 'falhou'
  const id = 'EX-' + Math.random().toString(16).slice(2, 8).toUpperCase().padEnd(6, '0'), agora = nowIso(), level = Math.max(...steps.map((s) => s.nivel))
  await q('INSERT INTO executions (id, user_id, conversation_id, origin, playbook, goal, steps, level, status, background, progress, idem_key, version, history, approved_by, started_at, finished_at, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$16,$16,$16)',
    [id, u.id, convId || null, 'ia', 'ia', texto.slice(0, 300), JSON.stringify(steps), level, status, false, 100, 'ia:' + id, 0, JSON.stringify([{ em: agora, evento: 'executada pela IA no chat', detalhe: `${okV} de ${steps.length} ação(ões) conferida(s) no sistema` }]), level > 1 ? 'usuario:confirmou' : null, agora]).catch((e) => console.error('[execução] registro:', e?.message))
  return id
}
