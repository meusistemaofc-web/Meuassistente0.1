// NÚCLEO DE INTELIGÊNCIA — NÍVEL 2. Coordena, a cada mensagem que chega à IA, os módulos novos sobre o Nível 1
// (cognition.ts), sem duplicar nada: fio da conversa, especialistas, planejamento, memória por relevância e
// comunicação ANTES; execução verificada, plano, autoverificação e proatividade DEPOIS.
// Cada capacidade tem chave própria (Painel → Cérebro → Inteligência avançada); tudo desligado = Nível 1 idêntico.
import { q, one } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import type { SessionUser } from '../lib/session.js'
import type { Analise, Exec } from './cognition.js'
import * as ESP from './especialistas.js'
import * as PLAN from './planejador.js'
import * as AV from './autoverificacao.js'
import * as PRO from './proativo.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const norm = (t: string) => nrm(t).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
type Msg = { role: string; content: string | null }
type Tool = { function: { name: string } }

export const INTEL_DEFAULT = { ativo: true, contexto: true, planejamento: true, especialistas: true, memoria: true, autoverificacao: true, autocorrecao: true, execucao: true, proatividade: true, comunicacao: true, monitor: true }
export type IntelCfg = typeof INTEL_DEFAULT & { atualizadoEm?: string }
export const intelCfg = async (): Promise<IntelCfg> => ({ ...INTEL_DEFAULT, ...(await getConfig<any>('inteligencia', {})) })

/* ======================= 1) RACIOCÍNIO CONTEXTUAL: o fio da conversa ======================= */
const NAO_NOME = new Set('Oi Ola Olá Pronto Claro Sim Não Nao Hoje Amanhã Amanha Ontem Quer Você Voce Seu Sua Meu Minha Aproveitando Andamento Perfeito Certo Ok Bom Boa Obrigado Obrigada Tudo Agora Depois Para Pra Com Isso Esse Essa Aqui Ainda Também Tambem Qual Quando Onde Como Quanto Quem Por Que Se Mas Então Entao Segunda Terça Terca Quarta Quinta Sexta Sábado Sabado Domingo Janeiro Fevereiro Março Abril Maio Junho Julho Agosto Setembro Outubro Novembro Dezembro Meu Assistente Nada Lembrete Tarefa Conta Compromisso Atenção Atencao Só So Uma Um Ela Ele Eu Lembre Anote Marque Agende Crie Cria Registre Ótimo Otimo Ah Eita Opa Show Valeu Tarefas Contas'.split(' '))
export function pessoasCitadas(msgs: Msg[]): string[] {
  const out: string[] = []
  for (const m of [...msgs].reverse()) {
    for (const x of String(m.content || '').replace(/⟦[^⟧]*⟧/g, '').matchAll(/(?:^|[^.!?\n]\s)((?:(?:Dr|Dra|Sr|Sra)\.?\s)?[A-ZÁÉÍÓÚÂÊÔÃÕ][a-záéíóúâêôãõç]{2,}(?:\s(?:da|de|do|dos|das)\s[A-ZÁÉÍÓÚ][a-záéíóúâêôãõç]+|\s[A-ZÁÉÍÓÚ][a-záéíóúâêôãõç]{2,})?)/g)) {
      const n = x[1].trim(); if (!NAO_NOME.has(n.split(' ')[0]) && !out.includes(n)) out.push(n)
    }
    if (out.length >= 4) break
  }
  return out
}
const OBJETOS: [RegExp, string, RegExp][] = [
  [/\b(?:d|n)?(?:essa|esta|aquela) conta\b/, 'conta', /\bconta\b/], [/\b(?:d|n)?(?:esse|este|aquele) (compromisso|horario)\b/, 'compromisso', /\b(compromisso|agend|reuniao|consulta)/],
  [/\b(?:d|n)?(?:essa|esta|aquela) (reuniao|consulta)\b/, 'reunião/consulta', /\b(reuniao|consulta)\b/], [/\b(?:d|n)?(?:essa|esta|aquela) tarefa\b/, 'tarefa', /\btarefa\b/],
  [/\b(?:d|n)?(?:esse|este|aquele) (gasto|lancamento|pagamento)\b/, 'lançamento', /\b(gasto|lancamento|pagamento|registrei)\b/], [/\b(?:d|n)?(?:esse|este|aquele) lembrete\b/, 'lembrete', /\blembrete\b/],
]
export function fioDaConversa(history: Msg[], text: string, an: Analise): string[] {
  const L: string[] = [], s = nrm(text), recentes = history.slice(-8)
  if (/\b(ele|ela|dele|dela|nele|nela|pra ele|pra ela|com ele|com ela)\b/.test(s)) {
    const p = pessoasCitadas(recentes); if (p.length) L.push(`"ele/ela" provavelmente se refere a ${p[0]} (citado(a) há pouco${p.length > 1 ? `; outras pessoas na conversa: ${p.slice(1, 3).join(', ')}` : ''}). Se houver dúvida real, pergunte.`)
  }
  for (const [re, nome, alvo] of OBJETOS) if (re.test(s)) {
    const m = [...recentes].reverse().find((x) => alvo.test(nrm(String(x.content || ''))))
    if (m) L.push(`"${s.match(re)![0]}" refere-se à ${nome} citada nesta mensagem anterior: "${String(m.content).replace(/⟦[^⟧]*⟧/g, '').replace(/\s+/g, ' ').slice(0, 140)}".`)
  }
  const users = history.filter((m) => m.role === 'user' && m.content).slice(-3)
  if (users.length >= 2 && !['continuacao', 'confirmacao', 'negacao', 'correcao', 'agradecimento', 'saudacao'].includes(an.tipo) && an.completude !== 'eliptica' && s.split(' ').length >= 4) {
    const t = new Set(norm(text).split(' ').filter((w) => w.length > 3)); let comum = 0
    for (const u of users) for (const w of norm(String(u.content)).split(' ')) if (w.length > 3 && t.has(w)) comum++
    if (!comum && !/\b(ele|ela|isso|esse|essa|aquele|aquela|tambem|ainda|mesmo)\b/.test(s)) L.push('Assunto novo: responda só a esta mensagem, sem misturar com o assunto anterior (a menos que o usuário ligue os dois).')
  }
  return L
}

/* ======================= 9) ADAPTAÇÃO COMUNICACIONAL ======================= */
export function estiloPedido(text: string): string[] {
  const s = nrm(text), L: string[] = []
  if (/\b(resuma|resume|resumo|resumir|em poucas palavras|tl;?dr)\b/.test(s)) L.push('Formato pedido: RESUMO — no máximo 3 frases ou 3 tópicos.')
  if (/\b(em topicos|em lista|liste|passo a passo|numerad\w*)\b/.test(s)) L.push('Formato pedido: tópicos/passos numerados, um por linha.')
  if (/\b(como se eu fosse (leigo|crianca|iniciante)|de forma simples|simplific\w*|sem termos tecnicos|explica facil|bem simples)\b/.test(s)) L.push('Linguagem pedida: simples, sem jargão, com um exemplo do dia a dia.')
  if (/\b(detalh\w*|aprofund\w*|completo|completa|em profundidade|explica melhor)\b/.test(s)) L.push('Profundidade pedida: pode aprofundar, organizando em partes curtas.')
  if (/\b(em uma frase|so a resposta|direto ao ponto|curto e grosso|responda curto|resposta curta)\b/.test(s)) L.push('Formato pedido: UMA frase, direto ao ponto.')
  if (/\b(formal|para (o|um|meu) cliente|e-?mail profissional|carta|oficio)\b/.test(s)) L.push('Registro pedido: formal e cordial (texto pronto para enviar).')
  return L
}

/* ======================= coordenação: ANTES da IA ======================= */
export interface Preparo { cfg: IntelCfg; sel: ESP.Selecao | null; plano: PLAN.Plano | null; planoNovo: boolean; contexto: string; tools: Tool[] | null; memorias: string[] | null; experiencias: string[]; memoriaMeta: any; prefs: PRO.Prefs | null; politica?: { politica: any; versao: number | null; grupo: string } | null }
export async function prepararTurno<T extends Tool>(u: SessionUser, text: string, history: Msg[], an: Analise, tools: T[], o: { convId: string; sandbox?: boolean; memoriaLigada?: boolean }): Promise<(Preparo & { tools: T[] | null }) | null> {
  const cfg = await intelCfg(); if (!cfg.ativo) return null
  const L: string[] = [], persiste = !o.sandbox && !!o.convId
  let prefs: PRO.Prefs | null = null
  if (persiste) {
    const s = nrm(text)
    if (PRO.DESLIGAR.test(s)) { await PRO.salvarPrefs(u.id, { proactive: false }); L.push('O usuário pediu para não receber mais sugestões: confirme em uma frase que não vai mais sugerir nada por conta própria (ele pode reativar dizendo "pode voltar a sugerir").') }
    else if (PRO.RELIGAR.test(s)) { await PRO.salvarPrefs(u.id, { proactive: true }); L.push('O usuário reativou as sugestões: confirme em uma frase.') }
    await PRO.registrarResposta(u.id, o.convId, an).catch(() => {})
    prefs = await PRO.prefsDe(u.id).catch(() => null)
  }
  if (cfg.contexto) L.push(...fioDaConversa(history, text, an))
  // especialistas (o turno anterior desta conversa ajuda em continuações)
  let sel: ESP.Selecao | null = null, ordenadas: T[] | null = null
  if (cfg.especialistas) {
    const ant = o.convId ? await one('SELECT specialists FROM cognition_evals WHERE conversation_id = $1 AND user_id = $2 ORDER BY id DESC LIMIT 1', [o.convId, u.id]).catch(() => null) : null
    let anterior: string[] = []; try { anterior = JSON.parse(String(ant?.specialists || '[]')) } catch { anterior = [] }
    sel = ESP.selecionar(text, an, tools, anterior); ordenadas = ESP.ordenarFerramentas(tools, sel); L.push(ESP.contextoCoordenacao(sel))
  }
  // planejamento: plano novo para pedidos com várias ações; senão, o plano em andamento desta conversa
  let plano: PLAN.Plano | null = null, planoNovo = false
  if (cfg.planejamento) {
    const etapas = PLAN.decompor(text)
    if (etapas.length >= 2) { plano = { etapas, status: 'ativo' }; planoNovo = true; if (persiste) plano = await PLAN.salvarPlano(u.id, o.convId, plano).catch(() => plano) }
    else if (persiste) {
      plano = await PLAN.planoAtivo(u.id, o.convId).catch(() => null)
      if (plano && an.tipo === 'negacao' && /\b(esquece|deixa|cancela|nao precisa)\b/.test(nrm(text))) { await PLAN.abandonar(u.id, o.convId); plano = null; L.push('O usuário desistiu do plano em andamento: não continue as etapas pendentes.') }
    }
    if (plano && PLAN.pendentes(plano).length) L.push(PLAN.contextoPlano(plano, planoNovo))
  }
  // memória por relevância (substitui o despejo das 50 mais novas; com poucas memórias, entram todas)
  // memória evolutiva (Fase 5): por significado e em camadas — preferências, longo prazo, associadas, experiências e
  // conversas anteriores do MESMO usuário, dentro de um limite de contexto (com poucas memórias, entram todas)
  // política aprendida (Fase 6): parâmetros aprovados pelo administrador — estável, ou a candidata no grupo da liberação gradual
  const POL = await import('./politica.js')
  const pol = await POL.politicaPara(u.id).catch(() => null)
  let memorias: string[] | null = null, experiencias: string[] = [], memoriaMeta: any = null
  if (cfg.memoria && o.memoriaLigada) {
    const ME = await import('./memoria-evolutiva.js')
    const mc = await ME.contextualizar(u, { texto: text, historico: history.filter((m) => m.role === 'user').slice(-2).map((m) => String(m.content || '')).join(' '), convId: o.sandbox ? undefined : o.convId, limiteChars: pol?.politica.memoria.limiteChars, maxFatos: pol?.politica.memoria.maxFatos }).catch((e) => { console.error('[memória]', e?.message); return null })
    if (mc) {
      memorias = [...mc.preferencias.map((p) => '(preferência) ' + p), ...mc.fatos, ...mc.associadas.map((a) => '(relacionada) ' + a)]
      experiencias = mc.experiencias; memoriaMeta = { ...mc.meta, camadas: { preferencias: mc.preferencias.length, fatos: mc.fatos.length, associadas: mc.associadas.length, experiencias: mc.experiencias.length, conversas: mc.conversas.length } }
      L.push('MEMÓRIA: as memórias listadas foram escolhidas por relevância (preferências, fatos e informações relacionadas) — use só as pertinentes; a mais recente vale sobre versões antigas; não repita ao usuário, sem necessidade, o que ele mesmo já disse.')
      if (mc.experiencias.length) L.push('EXPERIÊNCIAS ANTERIORES DESTE USUÁRIO (individuais; use para decidir melhor, sem citar sem necessidade):\n- ' + mc.experiencias.join('\n- '))
      if (mc.conversas.length) L.push('CONVERSAS ANTERIORES RELACIONADAS deste usuário (só mencione se ajudar): ' + mc.conversas.join('; '))
    }
  }
  if (cfg.comunicacao) {
    L.push(...estiloPedido(text))
    const t = prefs?.style?.tamanho
    if (t && !estiloPedido(text).length) L.push(t === 'curto' ? 'Preferência deste usuário (pelas avaliações dele): respostas mais CURTAS e diretas.' : 'Preferência deste usuário (pelas avaliações dele): respostas mais DETALHADAS, com explicação.')
  }
  if (cfg.execucao) L.push('EXECUÇÃO: use as ferramentas autorizadas para agir; confira o retorno de cada uma antes de afirmar que fez; se algo falhar, diga o que falhou e o que fazer a seguir.')
  if (pol) { const area = sel?.principal || 'geral', esp = ESP.especialista(area); L.push(...POL.instrucoes(pol.politica, area, tools.map((t) => t.function.name).filter((n) => esp.ferramentas(n)), !!(plano && PLAN.pendentes(plano).length))) }
  return { cfg, sel, plano, planoNovo, contexto: L.length ? 'NÚCLEO DE INTELIGÊNCIA (nível 2):\n' + L.join('\n') : '', tools: ordenadas, memorias, experiencias, memoriaMeta, prefs, politica: pol }
}

/* ======================= DEPOIS da IA: execução verificada, plano, autoverificação, proatividade ======================= */
/** Confere no banco se os registros que as ferramentas disseram ter criado existem mesmo. */
export async function verificarCriados(userId: number, done: { name: string; result: any }[]) {
  const ids = done.filter((d) => d.result?.ok === true && Array.isArray(d.result?.created)).flatMap((d) => d.result.created.map((c: any) => Number(c?.id))).filter((n) => Number.isInteger(n) && n > 0)
  if (!ids.length) return { conferidos: 0, faltando: 0 }
  const r = await one(`SELECT COUNT(*) AS n FROM items WHERE user_id = $1 AND id IN (${ids.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...ids]).catch(() => null)
  const n = Number(r?.n ?? ids.length); return { conferidos: n, faltando: Math.max(0, ids.length - n) }
}
export interface Conclusao { content: string; meta: any; flags: string[] }
export async function concluirTurno(o: {
  u: SessionUser; convId: string; an: Analise; texto: string; content: string; done: { name: string; result: any }[]; exec: Exec; msgs: Msg[]; history: Msg[]
  prep: Preparo; sandbox?: boolean; hoje: string; fim: number; somenteLeitura?: Set<string>; complete: (msgs: any[], tools: any[], opts: any) => Promise<any>; reconferir: (c: string) => string; clareza: (c: string) => number
}): Promise<Conclusao> {
  const { cfg } = o.prep, flags: string[] = [], meta: any = { especialistas: o.prep.sel?.ids || [], memorias: o.prep.memorias?.length ?? null, memoria: o.prep.memoriaMeta, ...(o.prep.politica ? { politica: { versao: o.prep.politica.versao, grupo: o.prep.politica.grupo } } : {}) }
  const POL = await import('./politica.js'), revisaSempre = !!o.prep.politica && POL.revisarSempre(o.prep.politica.politica, o.prep.sel?.principal || 'geral')
  let c = o.content
  if (cfg.execucao && !o.sandbox) {
    const v = await verificarCriados(o.u.id, o.done).catch(() => ({ conferidos: 0, faltando: 0 })); meta.verificacao = v
    if (v.faltando) { flags.push('registro_nao_confirmado'); c += `\n\nAtenção: não consegui confirmar ${v.faltando === 1 ? 'um dos registros' : `${v.faltando} registros`} no seu histórico. Confira em instantes; se não aparecer, me peça de novo.` }
  }
  let plano = o.prep.plano
  if (plano && cfg.planejamento) {
    plano = PLAN.aplicarExecucao(plano, o.done)
    if (!o.sandbox && o.convId && plano.id) await PLAN.salvarPlano(o.u.id, o.convId, plano).catch(() => {})
    meta.plano = { etapas: plano.etapas.length, feitas: plano.etapas.filter((e) => e.status === 'feito').length, falhas: plano.etapas.filter((e) => e.status === 'falhou').length, status: plano.status }
    if (o.done.length) { const parcial = PLAN.resumoParcial(plano, c); if (parcial) { c = `${c.trim()}\n\n${parcial}`; flags.push('plano_parcial_informado') } }
  }
  if (cfg.autoverificacao && (revisaSempre || AV.importante({ an: o.an, exec: o.exec, plano, especialistas: meta.especialistas, resposta: c, texto: o.texto }))) {
    const fontes = [...o.msgs.map((m) => String(m.content || '')), ...o.done.map((d) => JSON.stringify(d.result))].join(' ')
    const anteriores = o.history.filter((m) => m.role === 'assistant').slice(-6).map((m) => String(m.content || ''))
    const P = AV.verificar({ texto: o.texto, resposta: c, fontes, plano, especialistas: meta.especialistas, exec: o.exec, anteriores, clareza: o.clareza(c) })
    const av: any = { problemas: P.map((p) => p.tipo), revisada: false }
    c = AV.corrigirLocal(c, P, anteriores)
    const resta = o.fim - Date.now()
    if (AV.precisaRevisao(P) && cfg.autocorrecao && resta > 8000) {
      try {
        // conversa de revisão compacta e alternada (sem blocos de ferramenta, que alguns provedores recusam sem ferramentas declaradas)
        const dados = o.done.length ? `\n\nDados retornados pelas ferramentas neste pedido: ${JSON.stringify(o.done.map((d) => ({ ferramenta: d.name, resultado: d.result }))).slice(0, 3500)}` : ''
        const hist = o.history.slice(-4).filter((m) => (m.role === 'user' || m.role === 'assistant') && m.content).map((m) => ({ role: m.role, content: String(m.content) }))
        while (hist.length && hist[0].role === 'assistant') hist.shift()
        while (hist.length && hist[hist.length - 1].role === 'user') hist.pop()
        const rev = [o.msgs[0], ...hist, { role: 'user', content: o.texto + dados }, { role: 'assistant', content: c }, { role: 'user', content: AV.pedidoRevisao(P, await (async () => { const { turnoAtual, NOME_PT } = await import('./idioma.js'); const t = await turnoAtual(); return t && t.lang !== 'pt' ? NOME_PT[t.lang] : 'português do Brasil' })()) }]
        const r = await o.complete(rev, [], { allowEmpty: true, maxMs: Math.min(resta - 2000, 15000) })
        const nova = o.reconferir(String(r?.content || '').trim())
        if (nova) {
          const P2 = AV.verificar({ texto: o.texto, resposta: nova, fontes, plano, especialistas: meta.especialistas, exec: o.exec, anteriores, clareza: o.clareza(nova) })
          const graves = (x: AV.Problema[]) => x.filter((p) => ['incompleta', 'valor_divergente', 'pouco_clara'].includes(p.tipo)).length
          if (graves(P2) < graves(P)) { c = nova; av.revisada = true; av.restantes = P2.map((p) => p.tipo) }
        }
      } catch (e: any) { av.erroRevisao = String(e?.message || e).slice(0, 80) }
    }
    if (P.length) flags.push(...[...new Set(P.map((p) => 'auto_' + p.tipo))])
    meta.autoverificacao = av
  }
  // memória de experiências (Fase 5): resultado de cada ação e do plano — individual, sem texto da conversa além do objeto da ação
  if (cfg.memoria && !o.sandbox && o.convId && o.done.length) {
    const ME = await import('./memoria-evolutiva.js')
    await ME.experienciasDoTurno(o.u, o.done as any, o.somenteLeitura || new Set(), o.convId, o.texto).catch(() => {})
    if (plano && plano.etapas.length >= 2 && (plano.status === 'concluido' || plano.etapas.some((e) => e.status === 'falhou')))
      await ME.registrarExperiencia(o.u, { kind: 'plano', outcome: plano.status === 'concluido' ? 'sucesso' : 'falha', summary: `Pedido em ${plano.etapas.length} etapas (${plano.etapas.map((e) => e.acao).join(', ')}): ${plano.etapas.filter((e) => e.status === 'feito').length} feita(s)${plano.etapas.some((e) => e.status === 'falhou') ? ', ' + plano.etapas.filter((e) => e.status === 'falhou').map((e) => e.acao + ' falhou').join(', ') : ''}`, conversationId: o.convId, base: o.texto }).catch(() => {})
  }
  if (cfg.proatividade && !o.sandbox && o.convId) {
    const s = await PRO.sugerir(o.u, { convId: o.convId, an: o.an, done: o.done, texto: o.texto, resposta: c, hoje: o.hoje }).catch(() => null)
    if (s) { c = `${c.trim()}\n\n${s.texto}`; await PRO.registrarSugestao(o.u.id, o.convId, s).catch(() => {}); meta.sugestao = s.kind }
  }
  return { content: c, meta, flags }
}
