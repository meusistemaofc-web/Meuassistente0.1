import { useQuota } from '../lib/usage.js'
// Cérebro do chat: prompt de sistema + ferramentas que gravam registros reais no banco
// e geram os "cartões" exibidos pelo frontend (ChatCardView).
import { complete, run, readyCount, classifyTask, engineCfg, engineInstructions, type ChatMsg, type ToolDef } from './provider.js'
import { once, canon } from './once.js'
import { rid } from './types.js'
import type { SessionUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import { localDate, localTime, humanDate } from '../lib/time.js'
import { createItem, itemAction, serialize, listItems, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../routes/items.js'
import { addMemory, activeMemories, memSettings } from '../routes/memory.js'
import { HttpError } from '../lib/http.js'
import { db } from '../db/index.js'

const S = (description: string, properties: object, required: string[] = []): object => ({ type: 'object', properties, required, additionalProperties: false })
const FIN_TOOLS = ['register_transaction', 'create_bill', 'get_finance']
export const TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'create_task', description: 'Cria uma tarefa (algo a fazer).', parameters: S('', { title: { type: 'string' }, due_date: { type: 'string', description: 'AAAA-MM-DD' }, due_time: { type: 'string', description: 'HH:MM' }, priority: { type: 'string', enum: ['normal', 'high'] } }, ['title']) } },
  { type: 'function', function: { name: 'create_appointment', description: 'Agenda um compromisso com data (e horário, se houver).', parameters: S('', { title: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' }, time: { type: 'string', description: 'HH:MM' }, location: { type: 'string' }, person: { type: 'string' }, reminder_minutes: { type: 'integer' } }, ['title', 'date']) } },
  { type: 'function', function: { name: 'create_reminder', description: 'Cria um lembrete que avisa o usuário numa data/hora.', parameters: S('', { message: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' }, time: { type: 'string', description: 'HH:MM' }, recurrence: { type: 'string', enum: ['none', 'daily', 'weekly', 'monthly', 'yearly'] } }, ['message']) } },
  { type: 'function', function: { name: 'add_shopping_items', description: 'Adiciona itens à lista de compras.', parameters: S('', { items: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, quantity: { type: 'string' } }, required: ['name'] } } }, ['items']) } },
  { type: 'function', function: { name: 'create_note', description: 'Salva uma anotação.', parameters: S('', { content: { type: 'string' }, title: { type: 'string' } }, ['content']) } },
  { type: 'function', function: { name: 'register_transaction', description: `Registra um gasto (kind=expense; categorias: ${EXPENSE_CATEGORIES.join(', ')}) ou uma receita (kind=income; categorias: ${INCOME_CATEGORIES.join(', ')}).`, parameters: S('', { kind: { type: 'string', enum: ['expense', 'income'] }, amount: { type: 'number' }, description: { type: 'string' }, category: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' } }, ['kind', 'amount', 'description', 'category']) } },
  { type: 'function', function: { name: 'create_bill', description: 'Cadastra uma conta a pagar com vencimento.', parameters: S('', { name: { type: 'string' }, amount: { type: 'number' }, due_date: { type: 'string', description: 'AAAA-MM-DD' }, recurrence: { type: 'string', enum: ['none', 'weekly', 'monthly', 'yearly'] }, category: { type: 'string' } }, ['name', 'amount', 'due_date']) } },
  { type: 'function', function: { name: 'complete_task', description: 'Marca como concluída a tarefa pendente cujo título combina com o texto.', parameters: S('', { query: { type: 'string' } }, ['query']) } },
  { type: 'function', function: { name: 'save_memory', description: 'Guarda uma informação duradoura sobre o usuário quando ele pedir para lembrar (nunca senhas).', parameters: S('', { content: { type: 'string' }, kind: { type: 'string', enum: ['preference', 'fact', 'person', 'routine', 'goal'] } }, ['content']) } },
  { type: 'function', function: { name: 'get_agenda', description: 'Consulta compromissos, tarefas pendentes, lembretes e contas pendentes para responder perguntas.', parameters: S('', {}) } },
  { type: 'function', function: { name: 'get_finance', description: 'Consulta os lançamentos financeiros do mês atual.', parameters: S('', {}) } },
]

const CAT: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
function brl(n: number, cur = 'BRL') { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: cur }).format(n) }

export function cardFor(kind: string, s: any, today: string) {
  switch (kind) {
    case 'task': return { kind, id: s.id, label: `Tarefa · ${s.title}`, title: s.title, when: s.dueDate ? `${humanDate(s.dueDate, today)}${s.dueTime ? ` às ${s.dueTime}` : ''}` : undefined, meta: s.priority === 'high' ? ['Prioridade alta'] : [] }
    case 'appointment': return { kind, id: s.id, label: `Compromisso · ${s.title}`, title: s.title, when: `${humanDate(s.date, today)}${s.time ? ` às ${s.time}` : ''}`, meta: [s.location, s.person, s.time && s.reminderMinutes ? `Aviso ${s.reminderMinutes} min antes` : ''].filter(Boolean) }
    case 'reminder': return { kind, id: s.id, label: `Lembrete · ${s.message}`, title: s.message, when: `${humanDate(s.date, today)} às ${s.time}`, meta: s.recurrence !== 'none' ? [{ daily: 'Todo dia', weekly: 'Toda semana', monthly: 'Todo mês', yearly: 'Todo ano' }[s.recurrence as string]] : [] }
    case 'note': return { kind, id: s.id, label: 'Anotação', title: s.title || s.content.slice(0, 80) }
    case 'expense': return { kind: s.kind, id: s.id, label: `${s.kind === 'income' ? 'Receita' : 'Gasto'} · ${CAT[s.category] || s.category}`, title: s.description || CAT[s.category] || s.category, amount: s.amount, when: humanDate(s.date, today) }
    case 'bill': return { kind: 'bill', id: s.id, label: `Conta · ${s.name}`, title: s.name, amount: s.amount, when: `Vence ${humanDate(s.dueDate, today).toLowerCase()}` }
  }
  return null
}

/** Modo simulação do Laboratório de IA: `calls` recebe o que a IA tentaria executar; nenhuma ferramenta roda de verdade. */
export interface Sandbox { extraRules?: string; calls: { name: string; args: any }[] }
export async function runAssistant(u: SessionUser, history: ChatMsg[], text: string, live?: { onDelta: (s: string) => void; onReset: () => void }, convCtx = '', track?: import('./brain-usage.js').Uso[], sandbox?: Sandbox, convId = ''): Promise<{ content: string; cards: any[]; cog?: any }> {
  const s = settingsOf(u)
  const tz = s.timezone
  const today = localDate(tz)
  const mem = memSettings(u).enabled ? await activeMemories(u.id) : []
  const eng = await engineCfg()
  const finOn = (await (await import('../lib/usermod.js')).modules()).financas !== false
  const agenda = await import('./agenda-ia.js'), temAgenda = await agenda.agendaDisponivel(u).catch(() => false) // Inteligência de Agenda: só para donos de empresa e com a capacidade ligada
  const crmIA = await import('./crm-ia.js'), temCrm = await crmIA.crmDisponivel(u).catch(() => false) // CRM: só para donos de empresa com plano de loja e módulo ligado
  const negIA = await import('./negocio-ia.js'), temNeg = await negIA.negocioDisponivel(u).catch(() => false) // análise de negócio: só donos de empresa ativa (somente leitura)
  const tools = [...(finOn ? TOOLS : TOOLS.filter((t) => !FIN_TOOLS.includes(t.function.name))), ...(temAgenda ? agenda.AGENDA_TOOLS : []), ...(temCrm ? crmIA.CRM_TOOLS : []), ...(temNeg ? negIA.NEGOCIO_TOOLS : [])] // módulo Finanças desligado: a IA nem recebe as ferramentas de finanças
  const idt = await (await import('../lib/identity.js')).identity().catch(() => null)
  const brainCtx = (await (await import('./brain.js')).brainContext(text, track).catch(() => '')) + (sandbox?.extraRules ? `\n\nRegra em TESTE no Laboratório (trate como se já estivesse aprovada e siga-a):\n${sandbox.extraRules}` : '')
  const aprendCtx = sandbox ? '' : await (await import('./adaptive.js')).contextoIA(u, text, convId).catch(() => '') // aprendizados relevantes deste usuário (sem anunciar memória)
  const C = await import('./commercial.js'), comercialCtx = await C.commercialContext(u, text).catch(() => '')
  // Cérebro cognitivo: lê a intenção, o contexto, as lacunas e o tom ANTES de responder e orienta a IA (camada aditiva; o administrador pode desligar)
  const COG = await import('./cognition.js'), cogCfg = await COG.cogCfg().catch(() => ({ ...COG.COG_DEFAULT }))
  const an = cogCfg.ativo ? COG.analisar(text, history) : null
  const cogCtx = an ? await COG.contextoCognitivo(u, text, history, an, { convId, tools, foraDaJanela: history.slice(0, Math.max(0, history.length - eng.historico)), memoriaLigada: memSettings(u).enabled }).catch((e) => { console.error('[cognição]', e?.message); return '' }) : ''
  const system: ChatMsg = {
    role: 'system',
    content: [
      'Você é o "Meu Assistente", um assistente pessoal brasileiro que organiza a vida do usuário conversando.',
      'Responda em português do Brasil, de forma curta, calorosa e objetiva.',
      engineInstructions(eng),
      brainCtx,
      aprendCtx,
      C.HONESTIDADE,
      cogCtx,
      temAgenda ? await agenda.agendaContext(u, text, today).catch(() => '') : '',
      temCrm ? await crmIA.crmContext(u, text).catch(() => '') : '',
      temNeg ? await negIA.negocioContext(u).catch(() => '') : '',
      comercialCtx,
      convCtx ? 'Memória desta conversa (use para não perguntar de novo o que já foi dito): ' + convCtx : '',
      idt?.ativo ? `Seu criador: ${idt.nome}, ${idt.cargo}. Se perguntarem quem te criou, quem é o CEO ou quem é ${idt.nome}, responda com base nisto: ${String(idt.texto || '').replace(/\s+/g, ' ').slice(0, 900)}` : '',
      'Você TEM acesso aos dados financeiros do usuário pelas ferramentas get_finance e de registro: nunca diga que não tem acesso aos dados financeiros.',
      'Quando o usuário pedir para registrar algo (gasto, receita, conta, tarefa, compromisso, lembrete, compra, anotação), use as ferramentas — nunca diga que registrou sem chamar a ferramenta.',
      'Se faltar uma informação indispensável (ex.: a data de um compromisso ou o valor de um gasto), pergunte antes.',
      'Para perguntas sobre agenda ou finanças, consulte com get_agenda / get_finance antes de responder.',
      `Hoje é ${today} (${new Intl.DateTimeFormat('pt-BR', { weekday: 'long', timeZone: tz }).format(new Date())}), agora são ${localTime(tz)} no fuso ${tz}. Moeda: ${s.currency}.`,
      `Nome do usuário: ${u.name}.`,
      mem.length ? `Memórias que o usuário pediu para você lembrar:\n- ${mem.join('\n- ')}` : '',
    ].filter(Boolean).join('\n'),
  }
  const msgs: ChatMsg[] = [system, ...history.slice(-eng.historico), { role: 'user', content: text }]
  const cards: any[] = []
  let negCartao = '' // cartão ⟦neg:…⟧ da última consulta empresarial (anexado à resposta; o frontend o desenha com dados reais)
  const turn = rid(), done: { name: string; result: any }[] = []
  const lastBot = String([...history].reverse().find((m) => m.role === 'assistant')?.content || '')
  const cogMeta = (flags: string[] = [], ajustes: string[] = [], ferr = tools.length) => (an ? { cog: { analise: an, exec: COG.resumirExec(done, READ_ONLY, cards), ajustes, flags, ferramentas: ferr } } : {})
  // pergunta que pede informação atual: usa uma IA com pesquisa na web (ex.: Gemini com busca), se houver
  if (classifyTask(msgs) === 'pesquisa' && (await readyCount('pesquisa', ['pesquisa'])) > 0) {
    try { const r = await run(msgs, { task: 'pesquisa', grounding: true }); const c = String(r.message.content || '').trim(); if (c) return { content: c, cards, ...cogMeta([], [], 0) } } catch { /* segue para o fluxo normal */ }
  }
  // prazo TOTAL da IA nesta mensagem (todas as rodadas somadas): o usuário não fica esperando indefinidamente
  const prazoChat = Number((await (await import('../lib/settings.js')).getConfig<any>('ai_router', {})).prazoChatMs) || Number(process.env.CHAT_AI_DEADLINE_MS || 30000)
  const fim = Date.now() + prazoChat
  for (let round = 0; round < 5; round++) {
    let reply: ChatMsg
    if (round > 0) live?.onReset()
    const resta = fim - Date.now()
    if (resta < 2500) { const sum = summarizeDone(done, cards); if (sum) return { content: sum, cards, ...cogMeta() }; throw Object.assign(new Error('prazo da IA no chat esgotado'), { code: 'chat_deadline' }) }
    try { reply = await complete(msgs, tools, { allowEmpty: round > 0, onDelta: live?.onDelta, onReset: live?.onReset, maxMs: resta }) } // depois das ferramentas, uma resposta vazia não é motivo para trocar de IA
    catch (e: any) { const sum = summarizeDone(done, cards); if (sum) return { content: sum, cards, ...cogMeta() }; if (Date.now() >= fim - 1500) throw Object.assign(new Error('prazo da IA no chat esgotado'), { code: 'chat_deadline', cause: e }); throw e } // o que foi gravado nunca se perde nem se repete
    if (!reply.tool_calls?.length) {
      let out = C.guardExternalClaims((reply.content || '').trim() || 'Pronto.'), meta: any = {}
      if (an) { // confere a resposta antes de entregar: ação afirmada sem confirmação, link inventado, tom robótico
        const rv = COG.revisarResposta(out, { exec: COG.resumirExec(done, READ_ONLY, cards), fontes: msgs.map((m) => String(m.content || '')).join(' '), respostaAnterior: lastBot, guardaAcoes: cogCfg.guardaAcoes, humanizar: cogCfg.humanizar, propriaUrl: process.env.PUBLIC_URL })
        out = rv.content; meta = cogMeta(rv.flags, rv.ajustes)
      }
      return { content: (await import('./adaptive.js')).silenciar(out) + (negCartao ? ' ' + negCartao : ''), cards, ...meta }
    }
    msgs.push({ role: 'assistant', content: reply.content ?? null, tool_calls: reply.tool_calls })
    for (const call of reply.tool_calls) {
      let result: unknown
      try {
        const args = JSON.parse(call.function.arguments || '{}')
        // Laboratório (simulação): a ferramenta NÃO é executada; só registramos o que a IA tentaria fazer
        if (sandbox) { sandbox.calls.push({ name: call.function.name, args }); result = READ_ONLY.has(call.function.name) ? { ok: true, simulado: true, itens: [], aviso: 'Simulação: sem dados reais.' } : { ok: true, simulado: true, aviso: 'Simulação: nada foi gravado.' } }
        else result = await guarded(u, turn, call.function.name, args, today, cards, text, convId)
      } catch (e: any) {
        result = { ok: false, error: e instanceof HttpError ? e.message : 'Falha ao executar.' }
      }
      if (call.function.name.startsWith('negocio_') && (result as any)?.cartao) negCartao = String((result as any).cartao)
      done.push({ name: call.function.name, result })
      msgs.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result) })
    }
  }
  return { content: 'Fiz o que consegui com o seu pedido.', cards, ...cogMeta() }
}

const READ_ONLY = new Set(['get_agenda', 'get_finance', 'agenda_empresa_consultar', 'agenda_empresa_alertas', 'crm_buscar_cliente', 'crm_historico_cliente', 'crm_oportunidades', 'crm_inteligencia', 'negocio_resumo', 'negocio_comparar', 'negocio_analise'])
/** Execução única: se a IA que assumiu (fallback) repetir uma chamada já executada nesta conversa, devolve o resultado
 *  anterior em vez de gravar de novo. Pedidos idênticos reenviados em até 20 s também não duplicam o registro. */
async function guarded(u: SessionUser, turn: string, name: string, a: any, today: string, cards: any[], userText = '', convId = '') {
  const gate = await (await import('./cognition.js')).portaoSensivel(u, convId, name, a, userText).catch(() => null) // ação sensível/irreversível: só com confirmação explícita do usuário
  if (gate) return gate
  const key = name + ':' + canon(a)
  const exec = async () => { const before = cards.length; const res = await runTool(u, name, a, today, cards, userText, convId); return { res, added: cards.slice(before) } }
  const t = await once('t:' + turn, key, 600_000, async () => {
    if (READ_ONLY.has(name)) return { ...(await exec()), again: false }
    const r = await once('u:' + u.id, key, 20_000, exec)
    if (r.hit) cards.push(...r.value.added)
    return { res: r.value.res, added: [], again: r.hit }
  })
  const out: any = t.value.res
  return t.hit || t.value.again ? { ...(out && typeof out === 'object' ? out : { result: out }), deduped: true, aviso: 'Já executado: não repita esta ação.' } : out
}
function summarizeDone(done: { name: string; result: any }[], cards: any[]) {
  const ok = done.filter((d) => !READ_ONLY.has(d.name) && d.result?.ok === true)
  if (!ok.length) return ''
  const itens = cards.map((c) => c.title || c.label).filter(Boolean).slice(0, 6)
  return `Pronto! Já fiz o que você pediu${itens.length ? `: ${itens.join('; ')}` : ''}.`
}

async function runTool(u: SessionUser, name: string, a: any, today: string, cards: any[], userText = '', convId = '') {
  const make = async (type: string, data: any, cardKind = type) => {
    try { await useQuota(u, type) } catch (e: any) { if (e?.code === 'limit_reached') return { ok: false, error: e.message }; throw e }
    const rows = await db().tx((t) => createItem(u, type, data, t))
    const ser = rows.map(serialize) as any[]
    if (type === 'shopping') cards.push({ kind: 'shopping', label: 'Compras', title: ser.length === 1 ? ser[0].name : `${ser.length} itens`, items: ser.map((x) => x.name) })
    else { const c = cardFor(cardKind, ser[0], today); if (c) cards.push(c) }
    return { ok: true, created: ser }
  }
  if (FIN_TOOLS.includes(name) && (await (await import('../lib/usermod.js')).modules()).financas === false) return { ok: false, error: 'O módulo Finanças está desligado.' }
  if (name.startsWith('agenda_empresa_')) return (await import('./agenda-ia.js')).runAgendaTool(u, name, a, today)
  if (name.startsWith('crm_')) return (await import('./crm-ia.js')).runCrmTool(u, name, a)
  if (name.startsWith('negocio_')) return (await import('./negocio-ia.js')).runNegocioTool(u, name, a)
  switch (name) {
    case 'create_task': return make('task', a)
    case 'create_appointment': {
      // data e hora ditas pelo usuário (fuso local) valem mais que as calculadas pela IA: evita compromisso em dia/hora diferente
      const det = (await import('./convctx.js')).campos(userText, settingsOf(u).timezone)
      if (det.date) a.date = det.date
      if (det.time) a.time = det.time
      { // preferências aprendidas do usuário (confirmar/conferir antes de agendar); permissões e validações seguem valendo
        const LE = await import('./adaptive.js')
        if (await LE.exigeConfirmacao(u, 'agendamento', convId, userText).catch(() => false)) return { ok: false, precisaConfirmar: true, aviso: 'Antes de agendar, pergunte ao usuário, de forma natural e curta, se pode confirmar (data, horário e título). Só chame a ferramenta de novo depois do "sim". Não mencione memória nem preferências aprendidas.' }
        const gd = await LE.guardarAgendamento(u, convId, { date: a.date, time: a.time, title: a.title }).catch(() => ({} as any))
        if (gd.reply) return { ok: false, conflito: true, aviso: 'Não agende ainda. Responda ao usuário exatamente com esta orientação, de forma natural: ' + gd.reply }
      }
      return make('appointment', a)
    }
    case 'create_reminder': return make('reminder', a)
    case 'add_shopping_items': return make('shopping', a)
    case 'create_note': return make('note', a)
    case 'register_transaction': {
      // proteção: se o usuário está CORRIGINDO um lançamento ("errei, foi 60"), atualiza o existente e nunca cria outro
      const fix = userText ? await (await import('./finchat.js')).correctionFromText(u, userText).catch(() => null) : null
      if (fix) return { ok: /^Corrigido/.test(fix.content), correcao: true, mensagem: fix.content.replace(/⟦[^⟧]*⟧/g, '').trim(), aviso: 'Isto foi uma correção de um lançamento existente; nenhum lançamento novo foi criado. Repita a mensagem acima ao usuário.' }
      return make('expense', a)
    }
    case 'create_bill': return make('bill', a)
    case 'complete_task': {
      const qy = String(a.query || '').toLowerCase()
      const tasks = (await listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') ORDER BY id DESC")).filter((t) => String(t.data.title).toLowerCase().includes(qy))
      if (!tasks.length) return { ok: false, error: 'Nenhuma tarefa pendente encontrada com esse nome.' }
      await itemAction(u, 'task_status', 'task', tasks[0].id, { status: 'done' })
      cards.push({ kind: 'done', label: `Tarefa concluída`, title: tasks[0].data.title, headline: 'Tarefa concluída!' })
      return { ok: true, completed: tasks[0].data.title }
    }
    case 'save_memory': {
      const m = await addMemory(u.id, String(a.content || ''), a.kind, 'chat')
      cards.push({ kind: 'memory', label: 'Memória', title: m.content })
      return { ok: true }
    }
    case 'get_agenda': {
      const [ap, tk, rm, bl] = await Promise.all([
        listItems(u.id, 'appointment', 'AND day >= $3 ORDER BY day LIMIT 30', [today]),
        listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') ORDER BY id DESC LIMIT 30"),
        listItems(u.id, 'reminder', "AND status = 'pending' ORDER BY due_at LIMIT 30"),
        listItems(u.id, 'bill', "AND status = 'pending' ORDER BY day LIMIT 30"),
      ])
      return { today, appointments: ap.map(serialize), pendingTasks: tk.map(serialize), reminders: rm.map(serialize), pendingBills: bl.map(serialize) }
    }
    case 'get_finance': {
      const m = today.slice(0, 7)
      const rows = (await listItems(u.id, 'expense', 'AND day >= $3', [m + '-01'])).map(serialize) as any[]
      const spent = rows.filter((r) => r.kind === 'expense').reduce((x, r) => x + r.amount, 0)
      const income = rows.filter((r) => r.kind === 'income').reduce((x, r) => x + r.amount, 0)
      return { month: m, spent: brl(spent), income: brl(income), entries: rows.slice(0, 40) }
    }
  }
  return { ok: false, error: 'Ferramenta desconhecida.' }
}
