// Catálogo central das capacidades da inteligência do chat ("Cérebro do Chat" → Capacidades).
//
// REGRA DE OURO: todo conhecimento implementado em código, configuração ou cadastro precisa aparecer aqui.
//  - Conhecimentos de CÓDIGO ficam em CAPS abaixo (um registro por capacidade, com arquivos-fonte).
//    O teste `capacidades` do servidor falha se um arquivo de server/src/ai/*.ts não for citado por nenhum
//    registro nem estiver na lista de infraestrutura (INFRA): assim, conhecimento novo não fica escondido.
//  - Conhecimentos CADASTRADOS (tabela brain_answers: administrador, aprendizado, regras) entram sozinhos,
//    um a um, na categoria "Conhecimentos e regras cadastrados".
//  - O STATUS nunca é escrito à mão: é calculado agora a partir do estado real (módulos ligados, chaves, planos,
//    configurações). Quando algo não existe de fato, o status é "desenvolvimento" e aparece como tal.
import { q } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import { modules } from '../lib/usermod.js'

export type CapStatus = 'ativo' | 'inativo' | 'pendente' | 'desenvolvimento'
export const STATUS_ROTULO: Record<CapStatus, string> = { ativo: 'Ativo', inativo: 'Inativo', pendente: 'Pendente', desenvolvimento: 'Em desenvolvimento' }
export const STATUS_AJUDA: Record<CapStatus, string> = {
  ativo: 'Implementado e funcionando agora.',
  inativo: 'Implementado, mas desligado pelo administrador (módulo, chave geral ou modo).',
  pendente: 'Implementado, mas precisa de uma configuração ou de uma aprovação para valer.',
  desenvolvimento: 'Ainda não existe por completo: o chat não deve prometer isso.',
}
export const CATEGORIAS = [
  'Atendimento ao cliente', 'Agendamentos e gestão de serviços', 'Gestão financeira e pagamentos', 'Marketing e campanhas', 'Notificações push',
  'Vendas e estratégias comerciais', 'CRM e relacionamento com clientes', 'Pós-venda e fidelização', 'Gestão de clientes',
  'Regras de interpretação e execução de comandos', 'Catálogo, pedidos e empresas', 'Integrações e inteligência artificial', 'Segurança e honestidade',
  'Conhecimentos e regras cadastrados',
] as const
export type Categoria = (typeof CATEGORIAS)[number]

/** Estado real lido uma vez por consulta. */
export interface Estado {
  mod: Record<string, boolean>
  brain: { aprender: boolean; cerebroPrimeiro: boolean; fatos: boolean; modoIA: string }
  mktGlobal: boolean
  followup: boolean
  mpPronto: boolean
  ia: { texto: boolean; imagem: boolean; qtd: number }
  tts: boolean
  regrasAtivas: number
  pendentes: number
  pushInscritos: number
  moedas: { ativo: boolean; qtd: number; publicadas: number; adesao: boolean }
  cupons: { total: number; ativos: number; usados: number }
  lab: { total: number; publicadas: number; aguardando: number }
}
type Res = { status: CapStatus; motivo: string }
const ok = (motivo = 'Funcionando.'): Res => ({ status: 'ativo', motivo })
const off = (motivo: string): Res => ({ status: 'inativo', motivo })
const pend = (motivo: string): Res => ({ status: 'pendente', motivo })
const dev = (motivo: string): Res => ({ status: 'desenvolvimento', motivo })
const modulo = (e: Estado, k: string, nome: string): Res => (e.mod[k] ? ok(`Módulo "${nome}" ligado.`) : off(`Módulo "${nome}" desligado em Painel → Módulos.`))

export interface CapDef {
  id: string; nome: string; categoria: Categoria; descricao: string
  fonte: string[]            // arquivos que implementam (relativos a server/src ou frontend/public)
  conteudo: string[]         // o que o chat sabe/faz de fato
  limites?: string[]         // o que NÃO faz (transparência)
  estado: (e: Estado) => Res
}

export const CAPS: CapDef[] = [
  /* ---- Atendimento ---- */
  { id: 'atendimento-agente', nome: 'Agente de atendimento das empresas', categoria: 'Atendimento ao cliente', fonte: ['routes/businesses.ts', 'frontend/public/agente.html'],
    descricao: 'Atendente virtual de cada empresa, na página pública e no WhatsApp/chat da empresa, com o nome "Meu Assistente" por padrão (personalizável).',
    conteudo: ['Responde com os dados reais da empresa: catálogo, horário, endereço, formas de pagamento e entrega', 'Mostra atalhos rápidos (agendar, serviços, produtos, localização, horário, pagamento, WhatsApp) antes da primeira mensagem', 'Consulta o Cérebro (conhecimentos e regras do escopo "agentes") antes de chamar a IA', 'Recebe pedidos e agendamentos pelo chat'],
    limites: ['Só funciona para empresas com o plano do agente em vigor', 'Visitante sem login não executa regras que exigem usuário'], estado: (e) => modulo(e, 'agente', 'Agente') },
  { id: 'atendimento-playbook', nome: 'Boas práticas de atendimento', categoria: 'Atendimento ao cliente', fonte: ['ai/commercial.ts'],
    descricao: 'Roteiro de atendimento aplicado quando a conversa trata de atendimento, reclamação, retorno ou acompanhamento do cliente.',
    conteudo: ['Cumprimentar e entender a necessidade com 1 ou 2 perguntas', 'Apresentar a opção certa, não todas', 'Responder preço, prazo e pagamento só com dados cadastrados', 'Tratar reclamações com empatia e registrar o pedido de ajuda'], estado: () => ok('Orientação sempre disponível.') },
  { id: 'atendimento-cerebro', nome: 'Respostas pelo Cérebro (sem IA)', categoria: 'Atendimento ao cliente', fonte: ['ai/knowledge.ts', 'ai/brain.ts'],
    descricao: 'Recupera cláusulas dos conhecimentos cadastrados, avaliando condições numéricas (ex.: "acima de R$ 150"), e responde sem chamar IA.',
    conteudo: ['Divide o conhecimento em cláusulas e compara com a pergunta (radicais e sinônimos comerciais)', 'Avalia condições: acima de, abaixo de, até, a partir de', 'Usa o texto cadastrado: nada é inventado'],
    estado: (e) => e.brain.modoIA === 'sem_ia' ? ok('Modo "sem IA" ligado: o Cérebro responde sozinho.') : e.brain.cerebroPrimeiro ? ok('"Cérebro primeiro" ligado.') : off('"Cérebro primeiro" desligado em Cérebro e busca.') },
  { id: 'atendimento-laboratorio', nome: 'Laboratório de IA (administrador)', categoria: 'Atendimento ao cliente', fonte: ['ai/lab.ts', 'routes/lab.ts'],
    descricao: 'Ambiente exclusivo do administrador para corrigir e ensinar a IA: a correção vira uma proposta de regra que passa por análise, testes em simulação e aprovação antes de entrar no Cérebro.',
    conteudo: ['Chat do administrador, simulador sem efeito real e detecção de falhas (parcial, incompleta, informação ignorada, conflito)', 'Regras por categoria, estados de Rascunho a Publicada, versões, reversão e auditoria', 'Regra publicada vira diretriz ativa do Cérebro, usada pelo chat operacional'],
    limites: ['Regras orientam a IA; não executam ações financeiras ou administrativas por conta própria', 'Nada muda em produção sem aprovação e publicação explícitas do administrador', 'Diretrizes do Cérebro são globais (escopo chat/agentes), não por empresa'],
    estado: (e) => e.lab.total ? ok(`${e.lab.total} proposta(s), ${e.lab.publicadas} publicada(s), ${e.lab.aguardando} aguardando aprovação.`) : pend('Módulo pronto, nenhuma proposta criada ainda.') },
  { id: 'atendimento-contexto', nome: 'Memória da conversa', categoria: 'Atendimento ao cliente', fonte: ['ai/convctx.ts'],
    descricao: 'Guarda o assunto e as últimas ações da conversa para entender "remarca esse", "e o outro?" ou respostas curtas.',
    conteudo: ['Lembra o tópico e a pergunta pendente', 'Lembra o último compromisso, lançamento ou lembrete criado', 'Preenche dados que faltam com o contexto'], estado: () => ok() },
  { id: 'atendimento-memoria', nome: 'Memória do usuário', categoria: 'Atendimento ao cliente', fonte: ['routes/memory.ts', 'ai/assistant.ts'],
    descricao: 'Guarda preferências, fatos e rotinas que o usuário pede para lembrar, e as usa nas respostas.',
    conteudo: ['Ferramenta "save_memory" pedida pelo usuário', 'Usuário vê, edita e apaga em Perfil → Memória do assistente'], limites: ['Respeita a opção de memória desligada pelo usuário'], estado: (e) => e.brain.fatos ? ok('Fatos ligados.') : off('"Fatos" desligado em Cérebro e busca.') },

  /* ---- Agendamentos ---- */
  { id: 'agenda-chat', nome: 'Agenda, tarefas e compromissos pelo chat', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/appt.ts', 'ai/agenda.ts', 'ai/assistant.ts'],
    descricao: 'Cria, consulta, remarca e conclui compromissos, tarefas, anotações e lista de compras a partir de frases naturais.',
    conteudo: ['Interpreta datas, horas e períodos ("amanhã às 15h", "dia 20")', 'Pergunta o que faltar antes de criar', 'Consulta "o que tenho hoje/semana"'], estado: () => ok() },
  { id: 'agenda-lembretes', nome: 'Lembretes', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/appt.ts', 'ai/assistant.ts'],
    descricao: 'Cria lembretes que avisam o usuário na data e hora combinadas.', conteudo: ['Ferramenta create_reminder', 'Aviso por notificação no app'], estado: (e) => modulo(e, 'lembretes', 'Lembretes') },
  { id: 'agenda-reserva', nome: 'Reserva de horário nas empresas', categoria: 'Agendamentos e gestão de serviços', fonte: ['lib/business-sync.ts', 'routes/businesses.ts'],
    descricao: 'Todo agendamento feito pelo cliente cai na agenda do dono e bloqueia o horário contra reservas duplicadas.',
    conteudo: ['Registro automático na agenda administrativa', 'Bloqueio de horário com trava por empresa', 'Status do pedido acompanha o do compromisso'], estado: (e) => modulo(e, 'empresas', 'Empresas') },
  { id: 'agenda-sinal', nome: 'Agendamento com sinal pago', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/fin.ts', 'ai/finchat.ts'],
    descricao: 'Entende "agendar … cliente já pagou 50% de sinal": cria o compromisso, lança o sinal como entrada e deixa o saldo pendente, tudo na mesma mensagem.',
    conteudo: ['Identifica total, sinal e saldo (valor, porcentagem ou "metade")', 'Registra entrada financeira e a pendência a receber'], limites: ['Sem o valor do serviço, pergunta antes de lançar'], estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'servicos-catalogo', nome: 'Gestão de serviços e tipo de catálogo', categoria: 'Agendamentos e gestão de serviços', fonte: ['routes/businesses.ts', 'routes/ads.ts'],
    descricao: 'A empresa escolhe trabalhar com Produtos, Serviços ou Ambos; o chat, a página pública, pedidos e agendamentos respeitam a escolha.',
    conteudo: ['Cadastro de serviços com duração, preço fixo ou a combinar e fotos', 'Alterar o tipo depois não apaga nada (itens ficam ocultos)'], estado: (e) => modulo(e, 'empresas', 'Empresas') },

  /* ---- Financeiro ---- */
  { id: 'fin-lancamentos', nome: 'Lançamentos financeiros por texto', categoria: 'Gestão financeira e pagamentos', fonte: ['ai/fin.ts', 'ai/finchat.ts', 'ai/finsummary.ts'],
    descricao: 'Registra gastos e receitas, contas a pagar, transferências, pagamentos parciais e correções a partir de frases.',
    conteudo: ['Valor, categoria e subcategoria por dicionário editável', 'Forma de pagamento (Pix, cartão, dinheiro…)', 'Evita lançamento duplicado e aceita correção ("era 50, não 15")', 'Resumo do mês'], estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'fin-documentos', nome: 'Leitura de comprovantes e documentos', categoria: 'Gestão financeira e pagamentos', fonte: ['ai/docs.ts', 'ai/finchat.ts'],
    descricao: 'Lê foto/PDF de comprovante, boleto ou nota e propõe o lançamento com direção (entrada/saída) e valor.',
    conteudo: ['PDF com texto lido direto', 'Imagem lida por IA com visão ou, na falta dela, pelo OCR gratuito (OCR.space)', 'Pede confirmação quando a direção é incerta'],
    estado: (e) => !e.mod.financas ? off('Módulo "Finanças" desligado.') : e.ia.imagem ? ok('IA com visão disponível.') : pend('Sem IA com visão configurada: só PDF com texto e OCR gratuito.') },
  { id: 'fin-recebimentos', nome: 'Recebimentos de pedidos e agendamentos', categoria: 'Gestão financeira e pagamentos', fonte: ['lib/business-sync.ts', 'lib/pix.ts', 'routes/businesses.ts'],
    descricao: 'Todo pagamento efetivamente recebido gera uma única entrada no financeiro da empresa (sem duplicar).',
    conteudo: ['Pagamento online confirmado → entrada automática', 'Pedido concluído e pago na entrega → entrada automática', 'Idempotente: o mesmo pedido nunca lança duas vezes'],
    estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'fin-mercadopago', nome: 'Pagamentos online (Mercado Pago / Pix)', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/mpuser.ts', 'routes/panel.ts', 'lib/pix.ts'],
    descricao: 'Cobrança de planos e de pedidos por Pix e cartão via Mercado Pago.', conteudo: ['Modo teste e produção', 'Confirmação por webhook'],
    estado: (e) => e.mpPronto ? ok('Credenciais configuradas.') : pend('Configure as credenciais do Mercado Pago em Painel → Pagamentos.') },
  { id: 'fin-fiscal', nome: 'Apoio fiscal (MEI)', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/panel.ts', 'lib/panel-defaults.ts'],
    descricao: 'Parâmetros fiscais (salário mínimo e limite anual do MEI) usados em avisos e resumos.', conteudo: ['Limite anual e salário mínimo editáveis no painel'], limites: ['Não emite nota fiscal'], estado: (e) => modulo(e, 'fiscal', 'Fiscal') },
  { id: 'fin-mercado', nome: 'Cotações de mercado', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/market.ts', 'ai/intents.ts'],
    descricao: 'Cotações de criptomoedas e ações da B3 com fontes grátis e troca automática.', conteudo: ['Resposta imediata no chat (sem gastar IA) e no módulo Mercado'], estado: (e) => modulo(e, 'mercado', 'Mercado') },

  /* ---- Marketing ---- */
  { id: 'mkt-central', nome: 'Central de Marketing', categoria: 'Marketing e campanhas', fonte: ['lib/marketing.ts', 'routes/marketing.ts'],
    descricao: 'Campanhas segmentadas para clientes que autorizaram contato, com limites por plano, clique rastreado e descadastro.',
    conteudo: ['Campanhas e notificações por plano', 'Segmentação conforme o plano', 'Consentimento e link de saída', 'Resultados: enviados e cliques'],
    limites: ['O chat NÃO envia campanhas: ele orienta e, no painel, a empresa cria e dispara'], estado: (e) => e.mktGlobal ? ok('Chave geral do Marketing ligada.') : off('Chave geral do Marketing desligada pelo administrador.') },
  { id: 'mkt-playbook', nome: 'Estratégias de marketing', categoria: 'Marketing e campanhas', fonte: ['ai/commercial.ts'],
    descricao: 'Orientação de marketing: objetivo e público definidos, começar por quem autorizou, medir resultado, evitar excesso.',
    conteudo: ['Divulgar serviço, promover oferta, recuperar inativos, lembrar retorno, anunciar novidade', 'Estado real do Marketing (ligado/plano) entra no contexto'], estado: () => ok() },

  /* ---- Push ---- */
  { id: 'push-web', nome: 'Notificações push', categoria: 'Notificações push', fonte: ['lib/push.ts', 'routes/notifications.ts'],
    descricao: 'Web Push nativo (chaves VAPID geradas pelo sistema) para avisos do app e campanhas.', conteudo: ['Inscrição por aparelho', 'Avisos de lembretes, pedidos, chamados e campanhas'],
    estado: (e) => ok(`${e.pushInscritos} aparelho(s) inscrito(s).`) },
  { id: 'push-estrategia', nome: 'Orientação de push estratégico', categoria: 'Notificações push', fonte: ['ai/commercial.ts'],
    descricao: 'Sugere quando, a quem e com que texto usar push, respeitando permissões e sem excesso.', conteudo: ['Só para quem autorizou', 'Frequência moderada e mensagem útil'], limites: ['Não dispara push: só orienta'], estado: () => ok() },

  /* ---- Vendas ---- */
  { id: 'vendas-playbook', nome: 'Técnicas de vendas e conversão', categoria: 'Vendas e estratégias comerciais', fonte: ['ai/commercial.ts'],
    descricao: 'Descobrir a necessidade antes do preço, mostrar valor, tratar objeções, sugerir complemento e conduzir ao fechamento sem pressão.',
    conteudo: ['Playbook aplicado quando a conversa é sobre vendas', 'Números reais da visão de clientes entram quando existem'], estado: () => ok() },
  { id: 'vendas-agente', nome: 'Agente vendedor', categoria: 'Vendas e estratégias comerciais', fonte: ['ai/commercial.ts', 'routes/businesses.ts'],
    descricao: 'O agente da empresa entende a necessidade, sugere a opção do catálogo, monta o pedido e encaminha ao pagamento.',
    conteudo: ['Sugestão a partir do catálogo real', 'Carrinho, pedido e pagamento', 'Nunca inventa preço ou promoção'], estado: (e) => modulo(e, 'agente', 'Agente') },

  /* ---- CRM ---- */
  { id: 'crm-playbook', nome: 'Orientação de relacionamento (CRM)', categoria: 'CRM e relacionamento com clientes', fonte: ['ai/commercial.ts'],
    descricao: 'Perfis novo, recorrente, inativo e potencial e como agir com cada um.', conteudo: ['Inativo = sem comprar há mais de 60 dias', 'Novo = primeira compra nos últimos 30 dias'], estado: () => ok() },
  { id: 'crm-completo', nome: 'CRM completo (funil e negociações)', categoria: 'CRM e relacionamento com clientes', fonte: [],
    descricao: 'Módulo com funil, negociações e ficha do cliente. Ainda não existe no app.',
    conteudo: ['O chat é instruído a NÃO dizer que registrou clientes ou negociações em um CRM'], limites: ['Use a visão calculada em "Gestão de clientes"'],
    estado: (e) => e.mod.crm ? ok('Módulo CRM ligado.') : dev('Módulo de CRM completo ainda não implementado.') },

  /* ---- Pós-venda ---- */
  { id: 'posvenda-followup', nome: 'Follow-up pós-atendimento', categoria: 'Pós-venda e fidelização', fonte: ['lib/followup.ts'],
    descricao: 'Depois de um atendimento ou venda concluído, avisa o dono da empresa no prazo configurado para que ele entre em contato com o cliente.',
    conteudo: ['Prazo e mensagem personalizáveis (variáveis como {nome_cliente})', 'Aviso só ao dono'], limites: ['Nada é enviado ao cliente automaticamente'],
    estado: (e) => e.followup ? ok('Follow-up ligado.') : off('Follow-up desligado no painel.') },
  { id: 'posvenda-orientacao', nome: 'Orientação de pós-venda e fidelização', categoria: 'Pós-venda e fidelização', fonte: ['ai/commercial.ts'],
    descricao: 'Dicas de retorno, recompra, avaliação e relacionamento contínuo.', conteudo: ['Acompanhar o cliente depois da compra', 'Lembrar retorno e oferecer complemento'], estado: () => ok() },
  { id: 'posvenda-moedas', nome: 'Moedas de bônus (fidelização e desconto)', categoria: 'Pós-venda e fidelização', fonte: ['lib/coins.ts', 'routes/coins.ts'],
    descricao: 'Moeda digital própria de cada empresa: crédito promocional fechado para fidelizar e dar desconto em compras na empresa emissora.',
    conteudo: ['Biblioteca de 10 modelos visuais, personalização e vínculo por empresa', 'Carteira do cliente com saldo, histórico e regras', 'Desconto no pedido validando saldo; estorno se o pedido é recusado ou cancelado', 'Distribuição manual pelo administrador, com chave anti-duplicidade', 'Categoria "Moedas de bônus" no Mercado'],
    limites: ['Sem negociação, saque ou transferência', 'Desconto só em pedidos de produtos (agendamentos ainda não usam moedas)', 'O chat não distribui nem promete moedas: só o painel e as regras de adesão fazem isso'],
    estado: (e) => !e.moedas.ativo ? off('Sistema de moedas desligado no painel (Moedas de bônus).') : e.moedas.publicadas ? ok(`${e.moedas.publicadas} moeda(s) publicada(s).`) : pend('Sistema ligado, mas nenhuma moeda publicada ainda.') },
  { id: 'posvenda-cupons', nome: 'Cupons de desconto por empresa', categoria: 'Pós-venda e fidelização', fonte: ['lib/coupons.ts', 'routes/coupons.ts'],
    descricao: 'Cada empresa cria cupons promocionais (percentual ou valor fixo) com validade, quantidade, limite por cliente e produtos participantes, e os distribui por notificação, CRM ou área de cupons do cliente.',
    conteudo: ['Validação completa no pedido: ativo, validade, empresa certa, cliente autorizado, usos restantes, compra mínima e limite por cliente', 'Resgate registrado uma única vez por pedido; estorno se o pedido for recusado ou cancelado', 'Cupons exclusivos para clientes selecionados', 'Distribuição segmentada (novos, recorrentes, inativos, potenciais, quem comprou um produto) só por push para quem autorizou comunicações', 'Painel de resultados: distribuídos, usados, vendas com cupom, desconto concedido e conversão', 'Combinação com moedas de bônus conforme a regra de cada cupom'],
    limites: ['Vale em pedidos de produtos (agendamentos ainda não usam cupom)', 'O chat não cria, envia nem promete cupons: só o painel da empresa e do administrador fazem isso', 'Push respeita autorização do cliente, plano de Marketing e horário comercial; sem autorização o cupom só aparece na área do cliente'],
    estado: (e) => e.cupons.total ? ok(`${e.cupons.total} cupom(ns) criado(s), ${e.cupons.ativos} ativo(s), ${e.cupons.usados} uso(s) registrado(s).`) : pend('Módulo pronto, mas nenhuma empresa criou cupons ainda.') },
  { id: 'posvenda-adesao', nome: 'Adesão por compra (moedas automáticas)', categoria: 'Pós-venda e fidelização', fonte: ['lib/coins.ts', 'lib/business-sync.ts'],
    descricao: 'Concede moedas automaticamente depois da confirmação do pagamento, uma única vez por pedido, conforme regra e limites do administrador.',
    conteudo: ['Ex.: a cada R$ 100, 5 moedas', 'Valor mínimo, empresas participantes e limite por cliente'], limites: ['Nasce desativada'],
    estado: (e) => !e.moedas.ativo ? off('Sistema de moedas desligado.') : e.moedas.adesao ? ok('Adesão por compra ligada.') : off('Adesão por compra desativada (padrão).') },

  /* ---- Gestão de clientes ---- */
  { id: 'clientes-visao', nome: 'Visão calculada de clientes', categoria: 'Gestão de clientes', fonte: ['ai/commercial.ts'],
    descricao: 'Classifica clientes da empresa em novos, recorrentes, inativos e potenciais, direto dos pedidos, agendamentos, autorizações e cliques.',
    conteudo: ['Totais e nomes de exemplo', 'Últimas campanhas e cliques'], limites: ['Só existe para quem tem empresa cadastrada'], estado: (e) => modulo(e, 'empresas', 'Empresas') },
  { id: 'clientes-consentimento', nome: 'Autorizações de contato', categoria: 'Gestão de clientes', fonte: ['lib/marketing.ts', 'routes/marketing.ts'],
    descricao: 'Registra quem autorizou receber comunicações e permite sair a qualquer momento.', conteudo: ['Consentimento por empresa', 'Descadastro por link'], estado: (e) => e.mktGlobal ? ok() : off('Marketing desligado.') },

  /* ---- Regras ---- */
  { id: 'regras-executaveis', nome: 'Regras executáveis', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/rules.ts', 'ai/brain-usage.ts'],
    descricao: 'Regras do administrador que executam ações reais: recusar assunto, abrir módulo, abrir chamado, avisar administradores, acrescentar texto.',
    conteudo: ['Gatilho por frase, público, escopo e prioridade', 'Registro de cada uso'], estado: (e) => ok(`${e.regrasAtivas} regra(s) executável(is) ativa(s).`) },
  { id: 'regras-conflitos', nome: 'Detecção de conflitos e duplicidades', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/brain-conflicts.ts'],
    descricao: 'Compara o que será ativado com o que já vale: duplicado, contradição e regras incompatíveis.', conteudo: ['Mostra qual prevalece', 'Pede confirmação antes de ativar'], estado: () => ok() },
  { id: 'regras-aprendizado', nome: 'Aprendizado com revisão', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/brain.ts'],
    descricao: 'Respostas aprendidas nas conversas entram como pendentes e só valem depois de aprovadas.', conteudo: ['Aprovar, rejeitar, desativar e reativar', 'Histórico e versões'],
    estado: (e) => !e.brain.aprender ? off('Aprendizado desligado em Cérebro e busca.') : e.pendentes ? pend(`${e.pendentes} item(ns) aguardando aprovação.`) : ok() },
  { id: 'regras-comandos', nome: 'Respostas rápidas e cálculos sem IA', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/intents.ts', 'lib/math.ts', 'ai/engine.ts'],
    descricao: 'Responde na hora, sem gastar IA, a pedidos que tem certeza de entender: cotações, impostos/DAS, faturamento, busca de empresas e contas.', conteudo: ['Cotações de cripto e ações', 'Impostos e DAS do MEI', 'Faturamento', 'Busca de empresas por perto', 'Cálculos matemáticos'], estado: () => ok() },
  { id: 'regras-idempotencia', nome: 'Execução única de comandos', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/once.ts'],
    descricao: 'Evita executar duas vezes o mesmo comando (duplo toque, reenvio).', conteudo: ['Chave por conteúdo e janela de tempo'], estado: () => ok() },

  /* ---- Catálogo ---- */
  { id: 'catalogo-empresas', nome: 'Catálogo, pedidos e página pública', categoria: 'Catálogo, pedidos e empresas', fonte: ['routes/businesses.ts', 'routes/ads.ts', 'routes/items.ts'],
    descricao: 'Produtos e serviços com variações opcionais, fotos, carrinho, pedidos e página pública temática.', conteudo: ['Variações opcionais', 'Localização manual ou automática', 'Tema visual único da empresa'], estado: (e) => modulo(e, 'catalogo', 'Catálogo') },

  /* ---- Integrações e IA ---- */
  { id: 'ia-provedores', nome: 'Provedores de IA e roteamento', categoria: 'Integrações e inteligência artificial', fonte: ['ai/provider.ts', 'ai/registry.ts', 'ai/health.ts', 'ai/types.ts', 'ai/adapters/'],
    descricao: 'Vários provedores (Gemini, Claude, OpenAI, Groq, Ollama…) com fallback, tempo limite e proteção contra falhas repetidas.',
    conteudo: ['Escolha por prioridade, velocidade ou qualidade', 'Teste de cada IA e capacidades por provedor'],
    estado: (e) => e.brain.modoIA === 'sem_ia' ? off('Modo "sem IA" ligado.') : e.ia.qtd ? ok(`${e.ia.qtd} IA(s) pronta(s).`) : pend('Nenhuma IA configurada: o chat usa só o motor interno e o Cérebro.') },
  { id: 'ia-voz', nome: 'Voz: áudio para texto e leitura em voz alta', categoria: 'Integrações e inteligência artificial', fonte: ['ai/tts.ts', 'ai/docs.ts'],
    descricao: 'Transcreve áudios enviados e lê respostas em voz alta com cadeia de vozes.', conteudo: ['Transcrição por IA com áudio', 'Voz sintética com fallback'],
    estado: (e) => !e.mod.voz ? off('Módulo "Voz" desligado.') : e.tts ? ok() : off('Leitura em voz alta desligada.') },
  { id: 'ia-imagens', nome: 'Imagens no chat', categoria: 'Integrações e inteligência artificial', fonte: ['ai/docs.ts', 'ai/assistant.ts'],
    descricao: 'Entende fotos enviadas (comprovantes, documentos).', conteudo: ['Análise por IA com visão', 'OCR gratuito (OCR.space) como alternativa'],
    estado: (e) => !e.mod.imagens ? off('Módulo "Imagens" desligado.') : e.ia.imagem ? ok() : pend('Sem IA com visão: só OCR gratuito.') },
  { id: 'integ-geocode', nome: 'Endereço e localização', categoria: 'Integrações e inteligência artificial', fonte: ['lib/geocode.ts'],
    descricao: 'Converte endereço em coordenadas e o inverso, para o mapa da empresa.', conteudo: ['Endereço manual ou localização automática'], estado: () => ok() },
  { id: 'integ-whatsapp', nome: 'Atalho para WhatsApp', categoria: 'Integrações e inteligência artificial', fonte: ['frontend/public/agente.html'],
    descricao: 'Abre a conversa do cliente com a empresa no WhatsApp.', conteudo: ['Link direto wa.me'], limites: ['O sistema não envia mensagens de WhatsApp sozinho'], estado: () => ok() },

  /* ---- Segurança ---- */
  { id: 'seg-honestidade', nome: 'Honestidade sobre ações externas', categoria: 'Segurança e honestidade', fonte: ['ai/commercial.ts', 'ai/assistant.ts'],
    descricao: 'O chat nunca afirma que enviou campanhas, push, e-mails ou mensagens que não foram realmente executados.', conteudo: ['Instrução fixa no sistema', 'Filtro que remove frases de envio falso e acrescenta aviso'], estado: () => ok() },
  { id: 'seg-escopo', nome: 'Escopos e permissões das regras', categoria: 'Segurança e honestidade', fonte: ['ai/rules.ts'],
    descricao: 'Regras valem só para o público e o escopo escolhidos; visitante sem login não aciona ações que exigem usuário.', conteudo: ['Público: todos, donos, administradores', 'Escopo: chat, agentes ou ambos'], estado: () => ok() },
]

/** Arquivos de server/src/ai que são infraestrutura e não carregam "conhecimento" próprio (testados em run.ts). */
export const INFRA = ['capabilities.ts', 'types.ts', 'assets.ts', 'brain-usage.ts']

export interface CapOut { id: string; nome: string; categoria: string; descricao: string; status: CapStatus; statusRotulo: string; motivo: string; origem: 'codigo' | 'cadastro'; fonte: string[]; conteudo: string[]; limites: string[]; itemId?: number }

export async function coletarEstado(): Promise<Estado> {
  const mod = await modules()
  const b = await getConfig<any>('brain', {})
  const mk = await import('../lib/marketing.js')
  const fup = await getConfig<any>('followup', {})
  const mp = await getConfig<any>('mp', {})
  const tts = await getConfig<any>('tts', {})
  let ia = { texto: false, imagem: false, qtd: 0 }
  try {
    const R = await import('./registry.js')
    const alvos = (await Promise.all((await R.loadProviders()).filter((p) => p.ativo !== false).map((p) => R.targetFor(p).catch(() => null)))).filter(Boolean) as any[]
    ia = { texto: alvos.some((a) => a.caps.texto), imagem: alvos.some((a) => a.caps.imagem), qtd: alvos.length }
  } catch { /* sem registro de IA */ }
  const n = async (sql: string) => { try { return Number((await q(sql))[0]?.n) || 0 } catch { return 0 } }
  const coins = await (await import('../lib/coins.js')).coinsCfg()
  const tok = (m: any) => !!(m?.producao?.tok || m?.teste?.tok)
  return {
    mod: mod as Record<string, boolean>,
    brain: { aprender: b.aprender !== false, cerebroPrimeiro: b.cerebroPrimeiro !== false, fatos: b.fatos !== false, modoIA: b.modoIA || 'normal' },
    mktGlobal: await mk.mktOn(), followup: fup.ativo !== false, mpPronto: tok(mp), ia, tts: tts.ativo !== false,
    regrasAtivas: await n("SELECT COUNT(*) AS n FROM brain_answers WHERE nature = 'executavel' AND status = 'ativo'"),
    pendentes: await n("SELECT COUNT(*) AS n FROM brain_answers WHERE status = 'pendente'"),
    pushInscritos: await n('SELECT COUNT(*) AS n FROM push_subscriptions'),
    lab: { total: await n('SELECT COUNT(*) AS n FROM lab_proposals'), publicadas: await n("SELECT COUNT(*) AS n FROM lab_proposals WHERE state = 'publicada'"), aguardando: await n("SELECT COUNT(*) AS n FROM lab_proposals WHERE state = 'aguardando_aprovacao'") },
    cupons: { total: await n('SELECT COUNT(*) AS n FROM coupons'), ativos: await n("SELECT COUNT(*) AS n FROM coupons WHERE status = 'ativo'"), usados: await n("SELECT COUNT(*) AS n FROM coupon_redemptions WHERE status <> 'estornado'") },
    moedas: { ativo: coins.ativo, qtd: await n('SELECT COUNT(*) AS n FROM coins'), publicadas: await n("SELECT COUNT(*) AS n FROM coins WHERE status = 'ativa'"), adesao: coins.adesao.ativo },
  }
}

const mapaStatus = (s: string): CapStatus => s === 'ativo' ? 'ativo' : s === 'pendente' ? 'pendente' : 'inativo'
const NAT: Record<string, string> = { consulta: 'Consulta (informação)', diretriz: 'Diretriz (orienta a IA)', executavel: 'Regra executável', legado: 'Regra (cadastro antigo)' }

/** Catálogo completo: capacidades de código + cada conhecimento/regra cadastrado, sem duplicar ids. */
export async function catalogo(): Promise<{ itens: CapOut[]; resumo: Record<CapStatus, number>; porCategoria: { categoria: string; total: number; ativos: number }[]; duplicados: { titulo: string; ids: number[] }[] }> {
  const e = await coletarEstado()
  const itens: CapOut[] = CAPS.map((c) => { const r = c.estado(e); return { id: c.id, nome: c.nome, categoria: c.categoria, descricao: c.descricao, status: r.status, statusRotulo: STATUS_ROTULO[r.status], motivo: r.motivo, origem: 'codigo' as const, fonte: c.fonte, conteudo: c.conteudo, limites: c.limites || [] } })
  let rows: any[] = []
  try { rows = await q('SELECT id, question, answer, origin, kind, status, nature, scope, priority FROM brain_answers ORDER BY id DESC LIMIT 500') } catch { /* sem tabela */ }
  const vistos = new Map<string, number[]>()
  for (const r of rows) {
    const nat = r.nature || (r.kind === 'regra' ? 'legado' : 'consulta')
    const st = mapaStatus(String(r.status))
    const t = String(r.question || '').trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    if (st === 'ativo' || st === 'pendente') vistos.set(t, [...(vistos.get(t) || []), Number(r.id)])
    itens.push({ id: 'cadastro-' + r.id, itemId: Number(r.id), nome: String(r.question || '(sem título)').slice(0, 120), categoria: 'Conhecimentos e regras cadastrados', descricao: `${NAT[nat] || nat} · origem: ${r.origin || 'administrador'} · escopo: ${r.scope || 'chat'}`,
      status: st, statusRotulo: STATUS_ROTULO[st] + (r.status === 'rejeitado' ? ' (rejeitado)' : r.status === 'desativado' ? ' (desativado)' : ''), motivo: st === 'ativo' ? 'Em uso pelo chat.' : st === 'pendente' ? 'Aguardando aprovação do administrador.' : 'Não é usado pelo chat.', origem: 'cadastro', fonte: ['brain_answers'], conteudo: [String(r.answer || '').slice(0, 600)], limites: [] })
  }
  const resumo: Record<CapStatus, number> = { ativo: 0, inativo: 0, pendente: 0, desenvolvimento: 0 }
  for (const i of itens) resumo[i.status]++
  const porCategoria = CATEGORIAS.map((c) => { const l = itens.filter((i) => i.categoria === c); return { categoria: c as string, total: l.length, ativos: l.filter((i) => i.status === 'ativo').length } })
  const duplicados = [...vistos.entries()].filter(([, ids]) => ids.length > 1).map(([titulo, ids]) => ({ titulo, ids }))
  return { itens, resumo, porCategoria, duplicados }
}
