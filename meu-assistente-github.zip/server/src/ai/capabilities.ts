// Catálogo central das capacidades da inteligência do chat ("Cérebro do Chat" → Capacidades).
//
// REGRA DE OURO: todo conhecimento implementado em código, configuração ou cadastro precisa aparecer aqui.
//  - Conhecimentos de CÓDIGO ficam em CAPS abaixo (um registro por capacidade, com arquivos-fonte).
//    O teste `capacidades` do servidor falha se um arquivo de server/src/ai/*.ts não for citado por nenhum
//    registro nem estiver na lista de infraestrutura (INFRA): assim, conhecimento novo não fica escondido.
//  - Conhecimentos CADASTRADOS (tabela brain_answers: administrador, aprendizado, regras) entram sozinhos,
//    um a um, na categoria "Conhecimentos e regras cadastrados".
//  - O STATUS nunca é escrito à mão: é calculado agora a partir do estado real (módulos ligados, chaves, planos,
//    configurações). Quando algo não existe de fato, o status é "desenvolvimento" e aparece como tal.
import { q, one, J } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import { modules } from '../lib/usermod.js'

export type CapStatus = 'ativo' | 'inativo' | 'pendente' | 'desenvolvimento'
export const STATUS_ROTULO: Record<CapStatus, string> = { ativo: 'Ativo', inativo: 'Inativo', pendente: 'Pendente', desenvolvimento: 'Em desenvolvimento' }
export const STATUS_AJUDA: Record<CapStatus, string> = {
  ativo: 'Implementado e funcionando agora.',
  inativo: 'Implementado, mas desligado pelo administrador (módulo, chave geral ou modo).',
  pendente: 'Implementado, mas precisa de uma configuração ou de uma aprovação para valer.',
  desenvolvimento: 'Ainda não existe por completo: o chat não deve prometer isso.',
}
export const CATEGORIAS = [
  'Atendimento ao cliente', 'Agendamentos e gestão de serviços', 'Gestão financeira e pagamentos', 'Marketing e campanhas', 'Notificações push',
  'Vendas e estratégias comerciais', 'CRM e relacionamento com clientes', 'Pós-venda e fidelização', 'Gestão de clientes',
  'Regras de interpretação e execução de comandos', 'Catálogo, pedidos e empresas', 'Integrações e inteligência artificial', 'Segurança e honestidade',
  'Conhecimentos e regras cadastrados',
] as const
export type Categoria = (typeof CATEGORIAS)[number]

/** Estado real lido uma vez por consulta. */
export interface Estado {
  mod: Record<string, boolean>
  brain: { aprender: boolean; cerebroPrimeiro: boolean; fatos: boolean; modoIA: string }
  mktGlobal: boolean
  followup: boolean
  mpPronto: boolean
  whatsappEnvio?: boolean
  ia: { texto: boolean; imagem: boolean; qtd: number }
  tts: boolean
  regrasAtivas: number
  pendentes: number
  pushInscritos: number
  moedas: { ativo: boolean; qtd: number; publicadas: number; adesao: boolean }
  cupons: { total: number; ativos: number; usados: number }
  lab: { total: number; publicadas: number; aguardando: number }
  agendaIA: { ativo: boolean; empresas: number; inteligentes: number }
  aprendizagem: { ativo: boolean; total: number; usuarios: number }
  cognicao: { ativo: boolean; total: number; geral: number | null }
  intel: { cfg: Record<string, boolean>; bateria: { aprovados: number; total: number } | null; feedback: number }
  multiagente: { ativo: boolean; agentes: number }
}
type Res = { status: CapStatus; motivo: string }
const ok = (motivo = 'Funcionando.'): Res => ({ status: 'ativo', motivo })
const off = (motivo: string): Res => ({ status: 'inativo', motivo })
const pend = (motivo: string): Res => ({ status: 'pendente', motivo })
const dev = (motivo: string): Res => ({ status: 'desenvolvimento', motivo })
const modulo = (e: Estado, k: string, nome: string): Res => (e.mod[k] ? ok(`Módulo "${nome}" ligado.`) : off(`Módulo "${nome}" desligado em Painel → Módulos.`))

export interface CapDef {
  id: string; nome: string; categoria: Categoria; descricao: string
  fonte: string[]            // arquivos que implementam (relativos a server/src ou frontend/public)
  conteudo: string[]         // o que o chat sabe/faz de fato
  limites?: string[]         // o que NÃO faz (transparência)
  estado: (e: Estado) => Res
}

export const CAPS: CapDef[] = [
  /* ---- Atendimento ---- */
  { id: 'atendimento-agente', nome: 'Agente de atendimento das empresas', categoria: 'Atendimento ao cliente', fonte: ['routes/businesses.ts', 'frontend/public/agente.html'],
    descricao: 'Atendente virtual de cada empresa, na página pública e no WhatsApp/chat da empresa, com o nome "Meu Assistente" por padrão (personalizável).',
    conteudo: ['Responde com os dados reais da empresa: catálogo, horário, endereço, formas de pagamento e entrega', 'Mostra atalhos rápidos (agendar, serviços, produtos, localização, horário, pagamento, WhatsApp) antes da primeira mensagem', 'Consulta o Cérebro (conhecimentos e regras do escopo "agentes") antes de chamar a IA', 'Recebe pedidos e agendamentos pelo chat'],
    limites: ['Só funciona para empresas com o plano do agente em vigor', 'Visitante sem login não executa regras que exigem usuário'], estado: (e) => modulo(e, 'agente', 'Agente') },
  { id: 'atendimento-playbook', nome: 'Boas práticas de atendimento', categoria: 'Atendimento ao cliente', fonte: ['ai/commercial.ts'],
    descricao: 'Roteiro de atendimento aplicado quando a conversa trata de atendimento, reclamação, retorno ou acompanhamento do cliente.',
    conteudo: ['Cumprimentar e entender a necessidade com 1 ou 2 perguntas', 'Apresentar a opção certa, não todas', 'Responder preço, prazo e pagamento só com dados cadastrados', 'Tratar reclamações com empatia e registrar o pedido de ajuda'], estado: () => ok('Orientação sempre disponível.') },
  { id: 'cerebro-central', nome: 'Cérebro Central (biblioteca permanente)', categoria: 'Conhecimentos e regras cadastrados', fonte: ['ai/cerebro/central.ts', 'ai/cerebro/web.ts', 'ai/cerebro/motores.ts', 'ai/cerebro/vetor.ts', 'ai/cerebro/texto.ts', 'routes/cerebro.ts', 'frontend/public/cerebro-central.html'],
    descricao: 'Biblioteca de conhecimentos aprovados pelo administrador (com fontes, versões e confiabilidade), consultada por busca semântica e entregue ao chat quando a pergunta tem relação.',
    conteudo: ['Usa conhecimentos aprovados e, enquanto não são revisados, os aprendidos por pesquisa no chat que têm fontes e nenhuma contradição — sempre conhecimento comum a todos (nunca dados de usuários)', 'Cita as fontes quando usa o conhecimento', 'Quando a biblioteca não basta e a pergunta é geral (sem dados pessoais), pesquisa na internet durante a conversa — chaves "Aprender no chat" (ligada por padrão) e "Pesquisa no chat" do Cérebro Central'],
    limites: ['Não aprende sozinho com as conversas dos usuários', 'Não altera pesos de modelos de IA'], estado: () => ok('Disponível; o administrador liga, desliga e configura em Administração → Cérebro Central.') },
  { id: 'orquestracao-central', nome: 'Orquestração central e rastreamento das respostas', categoria: 'Integrações e inteligência artificial', fonte: ['ai/orquestrador.ts', 'routes/orquestracao.ts', 'routes/chat.ts', 'lib/timing.ts', 'frontend/public/panel-addon.js'],
    descricao: 'Mapa verificável da arquitetura de inteligência: estado real de cada componente (configuração, tabelas e uso medidos agora), ordem do pipeline do chat e rastro unificado de cada resposta (etapas e tempos, fontes, provedor e fallback, ferramentas, ações conferidas e nota).',
    conteudo: ['Administração → Visão Geral e Diagnóstico e Auditoria', 'Estado de cada componente: ativo, sem uso recente, desligado, atenção ou com falha', 'Rastreamento com filtros (com IA, sem IA, com ações, com falha)'],
    limites: ['Somente leitura: não liga nem desliga módulos', 'O resumo de tempo por etapa (Desempenho) zera quando o servidor reinicia; o rastro de cada resposta fica no banco'], estado: () => ok('Disponível para administradores.') },
  { id: 'atendimento-cerebro', nome: 'Respostas pelo Cérebro (sem IA)', categoria: 'Atendimento ao cliente', fonte: ['ai/knowledge.ts', 'ai/brain.ts'],
    descricao: 'Recupera cláusulas dos conhecimentos cadastrados, avaliando condições numéricas (ex.: "acima de R$ 150"), e responde sem chamar IA.',
    conteudo: ['Divide o conhecimento em cláusulas e compara com a pergunta (radicais e sinônimos comerciais)', 'Avalia condições: acima de, abaixo de, até, a partir de', 'Usa o texto cadastrado: nada é inventado'],
    estado: (e) => e.brain.modoIA === 'sem_ia' ? ok('Modo "sem IA" ligado: o Cérebro responde sozinho.') : e.brain.cerebroPrimeiro ? ok('"Cérebro primeiro" ligado.') : off('"Cérebro primeiro" desligado em Cérebro e busca.') },
  { id: 'atendimento-laboratorio', nome: 'Laboratório de IA (administrador)', categoria: 'Atendimento ao cliente', fonte: ['ai/lab.ts', 'routes/lab.ts'],
    descricao: 'Ambiente exclusivo do administrador para corrigir e ensinar a IA: a correção vira uma proposta de regra que passa por análise, testes em simulação e aprovação antes de entrar no Cérebro.',
    conteudo: ['Chat do administrador, simulador sem efeito real e detecção de falhas (parcial, incompleta, informação ignorada, conflito)', 'Regras por categoria, estados de Rascunho a Publicada, versões, reversão e auditoria', 'Regra publicada vira diretriz ativa do Cérebro, usada pelo chat operacional'],
    limites: ['Regras orientam a IA; não executam ações financeiras ou administrativas por conta própria', 'Nada muda em produção sem aprovação e publicação explícitas do administrador', 'Diretrizes do Cérebro são globais (escopo chat/agentes), não por empresa'],
    estado: (e) => e.lab.total ? ok(`${e.lab.total} proposta(s), ${e.lab.publicadas} publicada(s), ${e.lab.aguardando} aguardando aprovação.`) : pend('Módulo pronto, nenhuma proposta criada ainda.') },
  { id: 'atendimento-compreensao', nome: 'Compreensão pelo contexto', categoria: 'Atendimento ao cliente', fonte: ['ai/compreensao.ts'],
    descricao: 'Entende abreviações e erros de digitação, continuações curtas ("e quem criou?", "e ontem?"), respostas a pedidos de esclarecimento e o domínio da conversa para desambiguar nomes iguais.',
    conteudo: ['Corrige abreviações (qnto, hj, vc) e erros em palavras de comando, sem mexer em nomes, códigos ou links', 'Completa continuações com o assunto da conversa', 'Usa o assunto da conversa (carro, animal, futebol…) para escolher o sentido certo de um nome', 'Transforma "é bom?" sobre um nome em pedido de avaliação com fontes'], estado: () => ok() },
  { id: 'atendimento-contexto', nome: 'Memória da conversa', categoria: 'Atendimento ao cliente', fonte: ['ai/convctx.ts'],
    descricao: 'Guarda o assunto e as últimas ações da conversa para entender "remarca esse", "e o outro?" ou respostas curtas.',
    conteudo: ['Lembra o tópico e a pergunta pendente', 'Lembra o último compromisso, lançamento ou lembrete criado', 'Preenche dados que faltam com o contexto'], estado: () => ok() },
  { id: 'atendimento-memoria', nome: 'Memória do usuário', categoria: 'Atendimento ao cliente', fonte: ['routes/memory.ts', 'ai/assistant.ts'],
    descricao: 'Guarda preferências, fatos e rotinas que o usuário pede para lembrar, e as usa nas respostas.',
    conteudo: ['Ferramenta "save_memory" pedida pelo usuário', 'Usuário vê, edita e apaga em Perfil → Memória do assistente'], limites: ['Respeita a opção de memória desligada pelo usuário'], estado: (e) => e.brain.fatos ? ok('Fatos ligados.') : off('"Fatos" desligado em Cérebro e busca.') },

  /* ---- Agendamentos ---- */
  { id: 'agenda-chat', nome: 'Agenda, tarefas e compromissos pelo chat', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/appt.ts', 'ai/agenda.ts', 'ai/assistant.ts', 'ai/agendamento-chat.ts'],
    descricao: 'Cria, consulta, remarca e conclui compromissos, tarefas, anotações e lista de compras a partir de frases naturais.',
    conteudo: ['Interpreta datas, horas e períodos ("amanhã às 15h", "dia 20")', 'Pergunta o que faltar antes de criar', 'Consulta "o que tenho hoje/semana"', 'Agendamento com cliente, telefone, valor total, sinal (% ou R$), valor pago e observação, com conferência antes de salvar', 'Edita um compromisso existente só pelo identificador (nunca cria outro)'], estado: () => ok() },
  { id: 'agenda-lembretes', nome: 'Lembretes', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/appt.ts', 'ai/assistant.ts'],
    descricao: 'Cria lembretes que avisam o usuário na data e hora combinadas.', conteudo: ['Ferramenta create_reminder', 'Aviso por notificação no app'], estado: (e) => modulo(e, 'lembretes', 'Lembretes') },
  { id: 'agenda-reserva', nome: 'Reserva de horário nas empresas', categoria: 'Agendamentos e gestão de serviços', fonte: ['lib/business-sync.ts', 'routes/businesses.ts'],
    descricao: 'Todo agendamento feito pelo cliente cai na agenda do dono e bloqueia o horário contra reservas duplicadas.',
    conteudo: ['Registro automático na agenda administrativa', 'Bloqueio de horário com trava por empresa', 'Status do pedido acompanha o do compromisso'], estado: (e) => modulo(e, 'empresas', 'Empresas') },
  { id: 'agenda-ia', nome: 'Inteligência de Agenda e Funcionamento Empresarial', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/agenda-ia.ts', 'lib/calendar.ts', 'routes/agenda-ia.ts'],
    descricao: 'A IA entende expediente, intervalos, feriados (nacionais, estaduais e municipais), exceções, bloqueios e reservas e responde com a disponibilidade real do motor de agendamento das empresas.',
    conteudo: ['Horários livres que nunca passam do fechamento, atravessam intervalos ou colidem com reservas (ex.: 09h–12h: serviço de 60 min → 09h, 10h, 11h; de 120 min → 09h)', 'Alertas antecipados: feriados que pedem decisão, dias especiais, falta de intervalo, conflitos e janelas ociosas', 'Modos por empresa: manual (só consulta), inteligente (sugere e executa o que o dono pedir) e automático (aplica regras recorrentes que ele autorizou)', 'Aprende com as decisões anteriores do dono para sugerir, sem nunca transformar sugestão em regra', 'Disponível no chat do dono, no agente que atende clientes, no agendamento por conversa e nas notificações'],
    limites: ['Só o dono altera expediente, e nunca no modo manual; a IA nunca cancela reservas', 'Feriados estaduais e municipais precisam ser cadastrados pelo dono (os nacionais são calculados)', 'Não substitui o motor de agendamento, o financeiro nem o CRM: apenas o consulta'],
    estado: (e) => !e.mod.empresas ? off('Módulo "Empresas" desligado em Painel → Módulos.') : !e.agendaIA.ativo ? off('Desligada pelo administrador (chave desta capacidade).') : e.agendaIA.inteligentes ? ok(`${e.agendaIA.inteligentes} empresa(s) nos modos inteligente/automático.`) : pend('Pronta: nenhuma empresa saiu do modo manual ainda (o dono escolhe em Ajustes → Calendário).') },
  { id: 'aprendizagem-adaptativa', nome: 'Aprendizagem adaptativa e memória evolutiva', categoria: 'Integrações e inteligência artificial', fonte: ['ai/adaptive.ts', 'routes/learning.ts'],
    descricao: 'O sistema aprende com as correções e preferências de cada usuário, guarda de forma persistente e individual e usa nas próximas conversas para não repetir erros — sem treinar modelo e sem anunciar que está aprendendo.',
    conteudo: ['Reconhece correções ("sempre confirme antes de excluir", "consulte a disponibilidade antes de agendar") e as guarda com confiança, frequência e histórico', 'Diferencia correção pontual (só nesta conversa) de preferência permanente e pergunta de forma natural quando houver dúvida', 'Recupera só o que é relevante para a operação atual e aplica antes de executar (ex.: conferir a agenda antes de agendar)', 'Três camadas: contexto da conversa, memória individual e memória global (só muda com aprovação do administrador, pelo Laboratório de IA)', 'Cada pessoa revisa, edita, pausa ou exclui os próprios aprendizados em Aprendizados'],
    limites: ['Nunca substitui autenticação, permissões, validações financeiras ou regras de negócio; instruções para burlar a segurança são recusadas', 'Uma correção individual jamais altera o comportamento de outros usuários', 'Preferências inferidas só valem como sugestão até ganharem confiança'],
    estado: (e) => !e.aprendizagem.ativo ? off('Desligada pelo administrador (chave desta capacidade).') : e.aprendizagem.total ? ok(`${e.aprendizagem.total} aprendizado(s) ativo(s) de ${e.aprendizagem.usuarios} usuário(s).`) : pend('Pronta e ligada: ainda não houve correções para aprender.') },
  { id: 'saida-ia', nome: 'Saída da IA limpa e fiel ao conhecimento', categoria: 'Integrações e inteligência artificial', fonte: ['ai/saida.ts', 'ai/assistant.ts'],
    descricao: 'Nada do que o modelo devolve chega cru ao chat: chamadas de ferramenta escritas como texto viram ações de verdade, JSON e marcadores internos somem e, nas respostas baseadas na Biblioteca, dados sem fonte são retirados.',
    conteudo: ['Ferramentas: ```json {"name": …}```, <tool_call>, <function=…> e [TOOL_CALLS] escritos no texto são executados pelo caminho seguro de sempre (com confirmação e sem duplicar)', 'Formato: resposta em JSON vira só o texto; blocos de código de dados, [C1]/[C2] e nomes de ferramentas internas não aparecem', 'Fidelidade: em perguntas respondidas com a Biblioteca, frases com números, e-mails ou links que não estão em nenhuma fonte da conversa são retiradas (se não sobrar nada, responde direto pela Biblioteca)', 'Texto em tempo real (streaming): o que começa como JSON ou chamada de ferramenta não aparece na prévia; a mensagem final já vem limpa'],
    limites: ['Não confere fatos gerais respondidos sem a Biblioteca (só os dados das respostas baseadas nela)'], estado: () => ok('Sempre ativo em todas as respostas da IA no chat.') },
  { id: 'cerebro-cognitivo', nome: 'Cérebro cognitivo (inteligência conversacional avançada)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/cognition.ts', 'ai/assistant.ts', 'routes/cognition.ts'],
    descricao: 'Camada que envolve o pipeline de resposta já existente: lê a intenção e o contexto antes de responder, orienta a IA e confere a resposta antes de entregar — sem trocar modelos, serviços nem fluxos.',
    conteudo: ['Compreensão: intenção real (comando, pergunta, correção, continuação), mensagens incompletas ou informais, referências a falas anteriores', 'Raciocínio: detecta informação ausente, ambiguidades e contradições e faz uma pergunta curta e inteligente em vez de adivinhar', 'Memória contextual: usa o que já foi dito (inclusive fora da janela recente) para não perguntar de novo; dados pessoais duradouros só são guardados se o usuário quiser', 'Comunicação: acompanha o registro e o ritmo de cada usuário (formal/informal, curto/detalhado), com empatia e sem fórmulas prontas', 'Confiabilidade: nenhuma ação é afirmada sem confirmação da ferramenta, links não verificados são removidos e as capacidades citadas são só as reais', 'Operação: planeja pedidos em várias etapas, confere o resultado de cada uma e exige confirmação explícita para ações sensíveis ou irreversíveis', 'Qualidade: cada resposta recebe notas de precisão, coerência, naturalidade, clareza, contexto e resolução (só números; o texto da conversa não é guardado)'],
    limites: ['Funciona por regras e análise do texto, sem custo extra de IA: não substitui o modelo, apenas o orienta e confere', 'As notas são estimativas internas, não substituem a avaliação humana', 'Nunca altera autenticação, permissões, validações financeiras ou as regras do administrador'],
    estado: (e) => !e.cognicao.ativo ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência cognitiva).') : e.cognicao.total ? ok(`${e.cognicao.total} resposta(s) avaliada(s); nota média ${e.cognicao.geral ?? '—'}.`) : pend('Pronta e ligada: ainda não houve respostas para avaliar.') },
  { id: 'raciocinio-contextual', nome: 'Raciocínio contextual (fio da conversa)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/nucleo.ts'],
    descricao: 'Relaciona a mensagem com o histórico: resolve "ele/ela" para a pessoa citada, "essa conta" para a conta mencionada, percebe mudança de assunto e liga o pedido ao plano em andamento.',
    conteudo: ['Pessoas citadas nas últimas mensagens', 'Objetos citados (conta, compromisso, tarefa, lembrete, lançamento)', 'Mudança de assunto sem misturar temas'],
    limites: ['Funciona por análise do texto em português; em dúvida real, a IA pergunta'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.contexto ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'planejamento-inteligente', nome: 'Planejamento inteligente', categoria: 'Integrações e inteligência artificial', fonte: ['ai/planejador.ts'],
    descricao: 'Decompõe pedidos com várias ações em etapas, define prioridade e dependências, guarda o plano da conversa e acompanha o que foi feito, falhou ou aguarda confirmação, pelo retorno real das ferramentas.',
    conteudo: ['Etapas com ferramenta provável, prioridade e dependência', 'Plano retomado no turno seguinte (válido por 6 horas)', 'Andamento mostrado ao usuário quando o pedido fica parcial'],
    limites: ['Reconhece as ações das ferramentas existentes; pedidos sem ação clara seguem como resposta normal'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.planejamento ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'especialistas-dinamicos', nome: 'Especialistas dinâmicos com coordenação central', categoria: 'Integrações e inteligência artificial', fonte: ['ai/especialistas.ts'],
    descricao: 'Os domínios existentes (agenda, finanças, tarefas, compras, memória, Agenda da empresa, CRM, negócio, acolhimento) atuam como especialistas; o coordenador escolhe até 3 por mensagem, compartilha o contexto e prioriza as ferramentas certas sem remover nenhuma.',
    conteudo: ['Seleção pela mensagem, pela intenção e pelo turno anterior', 'Especialista só entra se o usuário tiver as ferramentas dele (permissões preservadas)', 'Nota média por especialista no painel'],
    limites: ['Não cria ferramentas novas: usa as que já existem'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.especialistas ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'idioma-inteligente', nome: 'Idioma inteligente e persistente', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/idioma.ts'],
    descricao: 'Responde no idioma em que o usuário escreve (português, inglês, espanhol, francês, italiano e alemão). Pedido permanente ("sempre me responda em inglês") vira preferência na memória do usuário e vale em todas as conversas até ele pedir outra coisa; pedido pontual ("responda isso em espanhol") vale só para aquela resposta.',
    conteudo: ['Detecção do idioma por mensagem; mensagens curtas sem sinal seguem o idioma recente da conversa', 'Preferência salva como memória (Perfil → Memória do assistente), visível e apagável', '"Responda no idioma em que eu escrever" apaga a preferência', 'Respostas dos motores internos são traduzidas preservando cartões e botões; a IA recebe a instrução de idioma'],
    limites: ['O idioma de uma mensagem isolada nunca vira preferência', 'A tradução das respostas internas depende de uma IA disponível; sem ela, a resposta sai em português'],
    estado: () => ok('Ligado e integrado ao chat.') },
  { id: 'modo-explicativo', nome: 'Modo explicativo e tipo do pedido', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/guia.ts'],
    descricao: 'Diferencia pedido de execução, pedido de explicação, pergunta geral e conversa. Perguntas como "como registro um gasto?" recebem passos curtos com as telas, botões e comandos reais do app (conferidos contra os módulos ligados), sem executar nada, e uma oferta para fazer pelo chat.',
    conteudo: ['Catálogo de recursos reais: gastos, receitas, contas, resumo, lembretes, compromissos, tarefas, compras, anotações, agenda, busca de produtos, pedidos, empresas, anúncios, plano, notificações, mercado, impostos, idioma, memória, anexos e Modos Inteligentes', 'Recurso desligado pelo administrador é informado como desligado', '"Sim" depois da oferta pede os dados que faltam ou já abre o fluxo (ex.: Modo Busca)', 'Explicação fora do catálogo vai para a IA com a lista de recursos reais e sem ferramentas de escrita'],
    limites: ['Não executa nada a partir de uma pergunta "como faço…"; só depois que o usuário pede'],
    estado: () => ok('Ligado e integrado ao chat.') },
  { id: 'memoria-inteligente', nome: 'Memória inteligente', categoria: 'Integrações e inteligência artificial', fonte: ['ai/memoria.ts'],
    descricao: 'Recupera as memórias relevantes para cada mensagem, atualiza em vez de duplicar quando a informação muda e evita repetir o que já foi dito.',
    conteudo: ['Relevância por assunto, uso e recência', 'Atualização de nome, cidade, trabalho, aniversário e nome de parentes', 'Duplicatas não são gravadas'],
    limites: ['Continua só guardando quando o usuário pede; senhas e dados sensíveis nunca'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.memoria ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'autoverificacao', nome: 'Autoverificação das respostas importantes', categoria: 'Integrações e inteligência artificial', fonte: ['ai/autoverificacao.ts'],
    descricao: 'Antes de entregar respostas importantes confere completude (várias perguntas), valores contra os dados das ferramentas, etapas que falharam e clareza; pode pedir uma revisão à IA dentro do prazo e só aceita se a nova versão for melhor.',
    conteudo: ['Perguntas sem resposta', 'Valores em R$ que não aparecem nos dados', 'Etapas falhas omitidas', 'Repetições desnecessárias removidas'],
    limites: ['A revisão pela IA usa uma chamada extra, só em respostas importantes e quando há tempo'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.autoverificacao ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'feedback-respostas', nome: 'Aprendizado por feedback (👍/👎)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/feedback.ts', 'routes/inteligencia.ts'],
    descricao: 'O usuário avalia cada resposta; preferências de tamanho valem só para ele; avaliações negativas viram oportunidades que o administrador envia ao Laboratório (testes e aprovação antes de valer).',
    conteudo: ['Motivos, comentário e compartilhamento opcional da conversa', 'Agrupamento por motivo, especialista e intenção', 'Proposta em rascunho no Laboratório de IA'],
    limites: ['Nada muda o comportamento geral sem aprovação no Laboratório'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.ativo ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'proatividade', nome: 'Inteligência proativa', categoria: 'Integrações e inteligência artificial', fonte: ['ai/proativo.ts'],
    descricao: 'Oferece no máximo uma sugestão útil por vez: lembrete após agendar, conta vencendo em até 3 dias, tarefas paradas há mais de uma semana.',
    conteudo: ['Intervalo mínimo de 2 horas', 'Nunca em desabafo, pressa ou frustração', 'O usuário desliga dizendo "pare de sugerir"'],
    limites: ['Sugestões são texto: o usuário decide se aceita'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.proatividade ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'avaliacao-continua', nome: 'Avaliação contínua e monitor de regressão', categoria: 'Integrações e inteligência artificial', fonte: ['ai/avaliacao.ts'],
    descricao: 'Bateria automática de cenários, indicadores de qualidade (notas, feedback, planos, autoverificação, sugestões, especialistas) e alerta aos administradores quando a qualidade cai.',
    conteudo: ['Comparação da última semana com a anterior', 'Bateria a cada 6 horas e sob demanda', 'Notificação diária em caso de regressão'],
    limites: ['Os alertas exigem volume mínimo de dados (20 respostas por semana)'],
    estado: (e) => !e.cognicao.ativo ? off('Depende do Cérebro cognitivo, que está desligado.') : !e.intel.cfg.ativo || !e.intel.cfg.monitor ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada).') : ok('Ligada e integrada ao chat.') },
  { id: 'multiagente', nome: 'Arquitetura multiagente (coordenador central)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/agentes.ts'],
    descricao: 'Coordenador central que avalia a complexidade do pedido e, só quando necessário, mobiliza agentes internos de pesquisa, análise, vendas, planejamento e escrita em até duas ondas, compartilhando um quadro com acesso controlado; a IA principal executa as ações e consolida tudo numa única resposta.',
    conteudo: ['Seleção inteligente: pedidos simples não acionam agentes; no máximo N por mensagem', 'Colaboração: a 2ª onda recebe as contribuições da 1ª; divergências entre agentes são detectadas e resolvidas na consolidação', 'Memória compartilhada com acesso controlado: cada agente vê só o que precisa; a pesquisa na web nunca recebe dados pessoais', 'Agentes só LEEM dados; gravar continua exclusivo do fluxo principal com as confirmações existentes', 'Prazo por mensagem, disjuntor por agente e resposta unificada (sem citar agentes)'],
    limites: ['Cada agente acionado é uma chamada extra de IA (em paralelo, dentro do prazo)', 'A pesquisa na web depende de uma IA com busca configurada'],
    estado: (e) => !e.multiagente.ativo ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada → Coordenação multiagente).') : ok(`${e.multiagente.agentes} agente(s) ligado(s); acionados só em pedidos complexos.`) },
  { id: 'memoria-evolutiva', nome: 'Memória evolutiva (camadas, significado e experiências)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/memoria-evolutiva.ts', 'ai/semantica.ts'],
    descricao: 'Memória em camadas (curto prazo, conversa, longo prazo, preferências e experiências) com recuperação por significado, associação entre informações e conversas do mesmo usuário, versões com origem e data, e privacidade controlada pelo próprio usuário.',
    conteudo: ['Recuperação por significado: radicais do português, conceitos ("pet" ↔ "cachorro"), erros de digitação e ranqueamento BM25 — local, sem enviar dados para fora', 'Associação: nomes e assunto em comum; títulos de conversas anteriores do mesmo usuário', 'Atualização sem perda: versões com data e motivo, contradição detectada, duplicatas unidas, memória "antiga" sem apagar', 'Experiências individuais: resultado de tarefas, planos, correções e avaliações — nunca viram conhecimento global', 'Privacidade: consentimento por camada, retenção escolhida pelo usuário, consulta, exportação, correção, restauração de versão e exclusão'],
    limites: ['Não usa modelo neural de embeddings: o significado vem de radicais, conceitos e similaridade — fortes no vocabulário do dia a dia', 'Índice em cache por processo (até 300 usuários), invalidado sempre que a memória muda'],
    estado: (e) => !e.intel.cfg.ativo || !e.intel.cfg.memoria ? off('Desligada pelo administrador (Painel → Cérebro → Inteligência avançada → Memória inteligente).') : ok('Ligada; cada usuário controla a própria memória em Perfil → Memória do assistente.') },
  { id: 'aprendizado-continuo', nome: 'Aprendizado contínuo (melhorias testadas e aprovadas)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/aprendizado.ts', 'ai/politica.ts'],
    descricao: 'Aprende com avaliações, correções, reclamações e falhas autorizadas: encontra padrões, compara estratégias, se autodiagnostica e propõe melhorias que só valem depois de testes isolados e aprovação do administrador, com liberação gradual e reversão.',
    conteudo: ['Coleta só de notas e rótulos (sem texto), respeitando o consentimento de cada usuário', 'Padrões ponderados por usuário, mínimo de usuários distintos e exclusão de contas suspeitas (contra feedback malicioso)', 'Comparação de estratégias (agentes, plano, revisão, memória) e de versões da política', 'Propostas em lista fechada: estilo por área, revisão, confirmação, memória, agentes, uso de ferramentas e regras (via Laboratório)', 'Ambiente isolado com precisão, naturalidade, velocidade, consistência e resolução antes × depois', 'Aprovação gradual ou total, promoção, reversão e restauração de qualquer versão; para sozinho em regressão'],
    limites: ['Não altera código, modelos nem parâmetros do provedor', 'Os testes isolados usam cenários sintéticos; o efeito real na satisfação é medido na liberação gradual'],
    estado: () => ok() },
  { id: 'inteligencia-preditiva', nome: 'Inteligência preditiva (antecipação de necessidades)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/preditivo.ts', 'ai/preditivo-servico.ts', 'routes/preditivo.ts'],
    descricao: 'Analistas de agenda, tarefas, finanças, clientes, problemas e hábitos olham o histórico do próprio usuário e antecipam conflitos, esquecimentos, confirmações, contas, retornos de clientes e oportunidades — sempre como sugestão, separando fato de estimativa.',
    conteudo: ['Compromissos: conflitos, sem contato ou horário, confirmar, risco de esquecimento, pós-atendimento e saldo a receber', 'Recorrências: contas, compras, gastos do mês e pedidos frequentes, com % de confiança e base', 'Clientes: recorrentes, retorno previsto, sem contato recente, padrões de procura e campanhas; CRM para o dono da empresa', 'Previsões conferidas depois (acertou/errou) e retroteste com o histórico', 'Avisos controlados: preferências, categorias, horário de silêncio, frequência e sem repetir'],
    limites: ['Nada é criado, alterado ou cancelado por causa de uma previsão', 'Estimativas só com padrão suficiente (ex.: 3 ocorrências); sem dados, diz que não há dados', 'Só os dados do próprio usuário; CRM só para o dono da empresa'],
    estado: () => ok() },
  { id: 'execucao-autonoma', nome: 'Autonomia operacional (planejar, executar e verificar)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/execucao.ts', 'ai/execucao-planos.ts', 'ai/execucao-ia.ts', 'routes/execucao.ts'],
    descricao: 'Entende objetivos do dia a dia, monta um plano com etapas e dependências, executa com os serviços que já existem, confere cada resultado no sistema e relata o que foi realmente feito — com níveis de autonomia, segundo plano e reversão.',
    conteudo: ['Níveis: 1 automático (consultas e operações reversíveis), 2 confirmação (alterações relevantes), 3 autorização explícita com o código da execução (exclusões e pagamentos)', 'Identificador único, proteção contra pedido repetido, controle de versão, validação, registro e reversão', 'Autorrecuperação: erro classificado, repetição só do que é seguro, alternativa segura, parada em risco de inconsistência', 'Segundo plano com progresso, cancelamento, retomada depois de queda e aviso ao terminar', 'As ferramentas que a IA já usava passam pelos mesmos níveis e ficam registradas'],
    limites: ['Executa só operações do catálogo (sobre os módulos existentes); não envia mensagens a terceiros', 'Exclusão é revertida recriando o registro (com novo identificador)'],
    estado: () => ok() },
  { id: 'agentes-especializados', nome: 'Arquitetura multiagente colaborativa (agentes especializados)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/agentes-dominio.ts', 'ai/agentes.ts', 'routes/agentes.ts', 'frontend/public/agentes.html'],
    descricao: 'Orquestrador central com 7 agentes especializados (Comercial, Agendamentos, CRM, Financeiro, Administrativo, Marketing, Análise e Inteligência) que reúnem e analisam os dados do próprio usuário/empresa sem custo de IA, colaboram com os agentes de raciocínio em pedidos complexos, validam decisões antes da resposta e agem conforme o nível de autonomia — tudo numa resposta única do assistente principal.',
    conteudo: ['Seleção econômica: só pedidos de análise ou complexos acionam agentes; cada um vê só a fatia de dados de que precisa', 'Validação em decisões complexas: proposta → crítica → verificação de números → avaliação (uma rodada)', 'Memória compartilhada entre execuções (achados e decisões do mesmo usuário), sem duplicar a memória global', 'Execução coordenada com dependências, prazos, reaproveitamento de pedido repetido, falha isolada, interrupção e limites de custo', 'Autonomia 1 a 4 por agente e teto por empresa; ações sempre pelo motor de execução (Fase 8), com reversão', 'Central de Agentes (/admin/agentes): agentes, estado, tarefas, histórico, falhas, consumo, permissões e empresas'],
    limites: ['Agentes de domínio leem só dados do próprio usuário e das empresas dele; nunca gravam', 'Pagamentos, exclusões e movimentações financeiras exigem sempre autorização explícita do usuário'],
    estado: () => ok('Disponível; configuração na Central de Agentes.') },
  { id: 'laboratorio-inteligencia', nome: 'Laboratório de Inteligência (pesquisa e evolução controlada)', categoria: 'Integrações e inteligência artificial', fonte: ['ai/laboratorio.ts', 'ai/laboratorio-agentes.ts', 'ai/laboratorio-painel.ts', 'routes/laboratorio.ts', 'frontend/public/laboratorio.html'],
    descricao: 'Centro administrativo para testar capacidades, simular conversas, criar especialistas, diagnosticar limitações, comparar versões e evoluir o assistente com aprovação, liberação gradual e reversão — sempre em ambiente isolado.',
    conteudo: ['Visão geral com métricas reais, estimativas e indicadores experimentais separados', 'Arena com 10 categorias de desafios e desafios personalizados (avaliação objetiva)', 'Simulador de conversas com avaliação de interpretação, memória, agentes, ferramentas, ambiguidade e precisão', 'Laboratório de agentes: teste, comparação, colaboração e especialistas novos em experimentação', 'Centro de diagnóstico e Central de melhorias (aprovar, rejeitar, editar e arquivar)', 'Experimentos atual × experimental nos mesmos cenários; desafios contínuos programados'],
    limites: ['Exclusivo de administradores com permissão; usa usuário sintético e dados fictícios', 'A avaliação é objetiva (critérios); a nota de naturalidade é uma estimativa interna', 'Nada muda em produção sem aprovação explícita'],
    estado: () => ok('Disponível para administradores autorizados em /admin/laboratorio.') },
  { id: 'agenda-sinal', nome: 'Agendamento com sinal pago', categoria: 'Agendamentos e gestão de serviços', fonte: ['ai/fin.ts', 'ai/finchat.ts'],
    descricao: 'Entende "agendar … cliente já pagou 50% de sinal": cria o compromisso, lança o sinal como entrada e deixa o saldo pendente, tudo na mesma mensagem.',
    conteudo: ['Identifica total, sinal e saldo (valor, porcentagem ou "metade")', 'Registra entrada financeira e a pendência a receber'], limites: ['Sem o valor do serviço, pergunta antes de lançar'], estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'servicos-catalogo', nome: 'Gestão de serviços e tipo de catálogo', categoria: 'Agendamentos e gestão de serviços', fonte: ['routes/businesses.ts', 'routes/ads.ts'],
    descricao: 'A empresa escolhe trabalhar com Produtos, Serviços ou Ambos; o chat, a página pública, pedidos e agendamentos respeitam a escolha.',
    conteudo: ['Cadastro de serviços com duração, preço fixo ou a combinar e fotos', 'Alterar o tipo depois não apaga nada (itens ficam ocultos)'], estado: (e) => modulo(e, 'empresas', 'Empresas') },

  /* ---- Financeiro ---- */
  { id: 'fin-lancamentos', nome: 'Lançamentos financeiros por texto', categoria: 'Gestão financeira e pagamentos', fonte: ['ai/fin.ts', 'ai/finchat.ts', 'ai/finsummary.ts', 'ai/classificar.ts'],
    descricao: 'Registra gastos e receitas, contas a pagar, transferências, pagamentos parciais e correções a partir de frases.',
    conteudo: ['Valor, categoria e subcategoria por dicionário editável', 'Forma de pagamento (Pix, cartão, dinheiro…)', 'Evita lançamento duplicado e aceita correção ("era 50, não 15")', 'Classifica despesas por produtos, estabelecimento e contexto (sem IA) e aprende com as correções de categoria de cada usuário', 'Corrige a categoria pelo chat ("a categoria dessa compra é mercado")', 'Resumo do mês'], estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'fin-documentos', nome: 'Leitura de comprovantes e documentos', categoria: 'Gestão financeira e pagamentos', fonte: ['ai/docs.ts', 'ai/finchat.ts', 'ai/leitura-local.ts'],
    descricao: 'Lê foto/PDF de comprovante, boleto ou nota e propõe o lançamento com direção (entrada/saída) e valor.',
    conteudo: ['PDF com texto lido direto', 'Leitura local no servidor (Central de Mídias), sem IA: mostra para confirmar, marca campos incertos e pergunta o que faltar', 'Imagem lida por IA com visão ou, na falta dela, pelo OCR gratuito (OCR.space)', 'Pede confirmação quando a direção é incerta'],
    estado: (e) => !e.mod.financas ? off('Módulo "Finanças" desligado.') : e.ia.imagem ? ok('IA com visão disponível.') : pend('Sem IA com visão configurada: só PDF com texto e OCR gratuito.') },
  { id: 'fin-recebimentos', nome: 'Recebimentos de pedidos e agendamentos', categoria: 'Gestão financeira e pagamentos', fonte: ['lib/business-sync.ts', 'lib/pix.ts', 'routes/businesses.ts'],
    descricao: 'Todo pagamento efetivamente recebido gera uma única entrada no financeiro da empresa (sem duplicar).',
    conteudo: ['Pagamento online confirmado → entrada automática', 'Pedido concluído e pago na entrega → entrada automática', 'Idempotente: o mesmo pedido nunca lança duas vezes'],
    estado: (e) => modulo(e, 'financas', 'Finanças') },
  { id: 'fin-mercadopago', nome: 'Pagamentos online (Mercado Pago / Pix)', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/mpuser.ts', 'routes/panel.ts', 'lib/pix.ts'],
    descricao: 'Cobrança de planos e de pedidos por Pix e cartão via Mercado Pago.', conteudo: ['Modo teste e produção', 'Confirmação por webhook'],
    estado: (e) => e.mpPronto ? ok('Credenciais configuradas.') : pend('Configure as credenciais do Mercado Pago em Painel → Pagamentos.') },
  { id: 'fin-fiscal', nome: 'Apoio fiscal (MEI)', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/panel.ts', 'lib/panel-defaults.ts'],
    descricao: 'Parâmetros fiscais (salário mínimo e limite anual do MEI) usados em avisos e resumos.', conteudo: ['Limite anual e salário mínimo editáveis no painel'], limites: ['Não emite nota fiscal'], estado: (e) => modulo(e, 'fiscal', 'Fiscal') },
  { id: 'fin-mercado', nome: 'Cotações de mercado', categoria: 'Gestão financeira e pagamentos', fonte: ['routes/market.ts', 'ai/intents.ts'],
    descricao: 'Cotações de criptomoedas e ações da B3 com fontes grátis e troca automática.', conteudo: ['Resposta imediata no chat (sem gastar IA) e no módulo Mercado'], estado: (e) => modulo(e, 'mercado', 'Mercado') },

  /* ---- Marketing ---- */
  { id: 'mkt-central', nome: 'Central de Marketing', categoria: 'Marketing e campanhas', fonte: ['lib/marketing.ts', 'routes/marketing.ts'],
    descricao: 'Campanhas segmentadas para clientes que autorizaram contato, com limites por plano, clique rastreado e descadastro.',
    conteudo: ['Campanhas e notificações por plano', 'Segmentação conforme o plano', 'Consentimento e link de saída', 'Resultados: enviados e cliques'],
    limites: ['O chat NÃO envia campanhas: ele orienta e, no painel, a empresa cria e dispara'], estado: (e) => e.mktGlobal ? ok('Chave geral do Marketing ligada.') : off('Chave geral do Marketing desligada pelo administrador.') },
  { id: 'mkt-playbook', nome: 'Estratégias de marketing', categoria: 'Marketing e campanhas', fonte: ['ai/commercial.ts'],
    descricao: 'Orientação de marketing: objetivo e público definidos, começar por quem autorizou, medir resultado, evitar excesso.',
    conteudo: ['Divulgar serviço, promover oferta, recuperar inativos, lembrar retorno, anunciar novidade', 'Estado real do Marketing (ligado/plano) entra no contexto'], estado: () => ok() },

  /* ---- Push ---- */
  { id: 'push-web', nome: 'Notificações push', categoria: 'Notificações push', fonte: ['lib/push.ts', 'routes/notifications.ts'],
    descricao: 'Web Push nativo (chaves VAPID geradas pelo sistema) para avisos do app e campanhas.', conteudo: ['Inscrição por aparelho', 'Avisos de lembretes, pedidos, chamados e campanhas'],
    estado: (e) => ok(`${e.pushInscritos} aparelho(s) inscrito(s).`) },
  { id: 'push-estrategia', nome: 'Orientação de push estratégico', categoria: 'Notificações push', fonte: ['ai/commercial.ts'],
    descricao: 'Sugere quando, a quem e com que texto usar push, respeitando permissões e sem excesso.', conteudo: ['Só para quem autorizou', 'Frequência moderada e mensagem útil'], limites: ['Não dispara push: só orienta'], estado: () => ok() },

  /* ---- Vendas ---- */
  { id: 'vendas-playbook', nome: 'Técnicas de vendas e conversão', categoria: 'Vendas e estratégias comerciais', fonte: ['ai/commercial.ts'],
    descricao: 'Descobrir a necessidade antes do preço, mostrar valor, tratar objeções, sugerir complemento e conduzir ao fechamento sem pressão.',
    conteudo: ['Playbook aplicado quando a conversa é sobre vendas', 'Números reais da visão de clientes entram quando existem'], estado: () => ok() },
  { id: 'vendas-agente', nome: 'Agente vendedor', categoria: 'Vendas e estratégias comerciais', fonte: ['ai/commercial.ts', 'routes/businesses.ts'],
    descricao: 'O agente da empresa entende a necessidade, sugere a opção do catálogo, monta o pedido e encaminha ao pagamento.',
    conteudo: ['Sugestão a partir do catálogo real', 'Carrinho, pedido e pagamento', 'Nunca inventa preço ou promoção'], estado: (e) => modulo(e, 'agente', 'Agente') },

  /* ---- CRM ---- */
  { id: 'crm-playbook', nome: 'Orientação de relacionamento (CRM)', categoria: 'CRM e relacionamento com clientes', fonte: ['ai/commercial.ts'],
    descricao: 'Perfis novo, recorrente, inativo e potencial e como agir com cada um.', conteudo: ['Inativo = sem comprar há mais de 60 dias', 'Novo = primeira compra nos últimos 30 dias'], estado: () => ok() },
  { id: 'crm-completo', nome: 'CRM completo (funil, oportunidades, tarefas e histórico)', categoria: 'CRM e relacionamento com clientes', fonte: ['ai/crm-ia.ts', 'lib/crm.ts', 'routes/crm.ts'],
    descricao: 'CRM de "Sua empresa" ligado ao chat: o dono consulta clientes, histórico, oportunidades e inteligência comercial, e registra observações, leads, oportunidades, etapas e tarefas conversando.',
    conteudo: ['Cadastro único de contatos reaproveitando clientes, pedidos e agendamentos (sem duplicar; telefone/e-mail com variações)', 'Funil configurável por empresa, oportunidades com histórico e motivos de perda', 'Tarefas com prazo, prioridade e lembrete nas notificações', 'Inteligência comercial com critério transparente e origem de cada item', 'Ações da IA validadas pelo serviço do CRM e registradas na auditoria (canal chat)'],
    limites: ['Só o dono da empresa (plano com loja) acessa os dados; dados de outra empresa nunca são lidos', 'Criar leads e mover etapas pelo chat podem ser desligados por empresa', 'A IA não envia mensagens a clientes: apenas registra e sugere'],
    estado: (e) => e.mod.crm === false ? off('Desligado pelo administrador (módulo "crm").') : ok('Disponível para empresas com plano de loja.') },
  { id: 'analista-negocio', nome: 'Analista de dados e movimentações da empresa', categoria: 'CRM e relacionamento com clientes', fonte: ['ai/negocio-ia.ts', 'lib/bi.ts', 'routes/bi.ts'],
    descricao: 'O dono pergunta no chat sobre vendas, faturamento, pedidos, clientes, acessos, agendamentos, produtos e desempenho e recebe números reais da própria empresa, com período, comparativos, cartões e sugestões.',
    conteudo: ['Faturamento (vendas pagas), bruto, pendente e cancelado diferenciados', 'Pedidos e agendamentos pendentes, concluídos e cancelados', 'Clientes novos e recorrentes, acessos e produtos/serviços mais pedidos', 'Comparativo entre períodos, melhor dia, horários de maior movimento', 'Tendências e sugestões com critério e números visíveis'],
    limites: ['Somente leitura: nunca altera pedidos, saldos ou lançamentos', 'Só o dono vê os dados da própria empresa (validado no servidor)', 'Visualizações por produto ainda não são registradas: "mais procurados" usa o que foi pedido', 'Sem dado ≠ zero: quando não há fonte, o chat diz que o dado não existe'],
    estado: () => ok('Disponível para donos de empresa ativa.') },

  /* ---- Pós-venda ---- */
  { id: 'posvenda-followup', nome: 'Follow-up pós-atendimento', categoria: 'Pós-venda e fidelização', fonte: ['lib/followup.ts'],
    descricao: 'Depois de um atendimento ou venda concluído, avisa o dono da empresa no prazo configurado para que ele entre em contato com o cliente.',
    conteudo: ['Prazo e mensagem personalizáveis (variáveis como {nome_cliente})', 'Aviso só ao dono'], limites: ['Nada é enviado ao cliente automaticamente'],
    estado: (e) => e.followup ? ok('Follow-up ligado.') : off('Follow-up desligado no painel.') },
  { id: 'posvenda-orientacao', nome: 'Orientação de pós-venda e fidelização', categoria: 'Pós-venda e fidelização', fonte: ['ai/commercial.ts'],
    descricao: 'Dicas de retorno, recompra, avaliação e relacionamento contínuo.', conteudo: ['Acompanhar o cliente depois da compra', 'Lembrar retorno e oferecer complemento'], estado: () => ok() },
  { id: 'posvenda-moedas', nome: 'MCoins (fidelização e desconto)', categoria: 'Pós-venda e fidelização', fonte: ['lib/coins.ts', 'routes/coins.ts'],
    descricao: 'Moeda digital própria de cada empresa: crédito promocional fechado para fidelizar e dar desconto em compras na empresa emissora.',
    conteudo: ['Biblioteca de 10 modelos visuais, personalização e vínculo por empresa', 'Carteira do cliente com saldo, histórico e regras', 'Desconto no pedido validando saldo; estorno se o pedido é recusado ou cancelado', 'Distribuição manual pelo administrador, com chave anti-duplicidade', 'Categoria "MCoins" no Mercado'],
    limites: ['Sem negociação, saque ou transferência', 'Desconto só em pedidos de produtos (agendamentos ainda não usam moedas)', 'O chat não distribui nem promete moedas: só o painel e as regras de adesão fazem isso'],
    estado: (e) => !e.moedas.ativo ? off('Sistema de moedas desligado no painel (MCoins).') : e.moedas.publicadas ? ok(`${e.moedas.publicadas} moeda(s) publicada(s).`) : pend('Sistema ligado, mas nenhuma moeda publicada ainda.') },
  { id: 'posvenda-cupons', nome: 'Cupons de desconto por empresa', categoria: 'Pós-venda e fidelização', fonte: ['lib/coupons.ts', 'routes/coupons.ts'],
    descricao: 'Cada empresa cria cupons promocionais (percentual ou valor fixo) com validade, quantidade, limite por cliente e produtos participantes, e os distribui por notificação, CRM ou área de cupons do cliente.',
    conteudo: ['Validação completa no pedido: ativo, validade, empresa certa, cliente autorizado, usos restantes, compra mínima e limite por cliente', 'Resgate registrado uma única vez por pedido; estorno se o pedido for recusado ou cancelado', 'Cupons exclusivos para clientes selecionados', 'Distribuição segmentada (novos, recorrentes, inativos, potenciais, quem comprou um produto) só por push para quem autorizou comunicações', 'Painel de resultados: distribuídos, usados, vendas com cupom, desconto concedido e conversão', 'Combinação com MCoins conforme a regra de cada cupom'],
    limites: ['Vale em pedidos de produtos (agendamentos ainda não usam cupom)', 'O chat não cria, envia nem promete cupons: só o painel da empresa e do administrador fazem isso', 'Push respeita autorização do cliente, plano de Marketing e horário comercial; sem autorização o cupom só aparece na área do cliente'],
    estado: (e) => e.cupons.total ? ok(`${e.cupons.total} cupom(ns) criado(s), ${e.cupons.ativos} ativo(s), ${e.cupons.usados} uso(s) registrado(s).`) : pend('Módulo pronto, mas nenhuma empresa criou cupons ainda.') },
  { id: 'posvenda-adesao', nome: 'Adesão por compra (moedas automáticas)', categoria: 'Pós-venda e fidelização', fonte: ['lib/coins.ts', 'lib/business-sync.ts'],
    descricao: 'Concede moedas automaticamente depois da confirmação do pagamento, uma única vez por pedido, conforme regra e limites do administrador.',
    conteudo: ['Ex.: a cada R$ 100, 5 moedas', 'Valor mínimo, empresas participantes e limite por cliente'], limites: ['Nasce desativada'],
    estado: (e) => !e.moedas.ativo ? off('Sistema de moedas desligado.') : e.moedas.adesao ? ok('Adesão por compra ligada.') : off('Adesão por compra desativada (padrão).') },

  /* ---- Gestão de clientes ---- */
  { id: 'clientes-visao', nome: 'Visão calculada de clientes', categoria: 'Gestão de clientes', fonte: ['ai/commercial.ts'],
    descricao: 'Classifica clientes da empresa em novos, recorrentes, inativos e potenciais, direto dos pedidos, agendamentos, autorizações e cliques.',
    conteudo: ['Totais e nomes de exemplo', 'Últimas campanhas e cliques'], limites: ['Só existe para quem tem empresa cadastrada'], estado: (e) => modulo(e, 'empresas', 'Empresas') },
  { id: 'clientes-consentimento', nome: 'Autorizações de contato', categoria: 'Gestão de clientes', fonte: ['lib/marketing.ts', 'routes/marketing.ts'],
    descricao: 'Registra quem autorizou receber comunicações e permite sair a qualquer momento.', conteudo: ['Consentimento por empresa', 'Descadastro por link'], estado: (e) => e.mktGlobal ? ok() : off('Marketing desligado.') },

  /* ---- Regras ---- */
  { id: 'regras-executaveis', nome: 'Regras executáveis', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/rules.ts', 'ai/brain-usage.ts'],
    descricao: 'Regras do administrador que executam ações reais: recusar assunto, abrir módulo, abrir chamado, avisar administradores, acrescentar texto.',
    conteudo: ['Gatilho por frase, público, escopo e prioridade', 'Registro de cada uso'], estado: (e) => ok(`${e.regrasAtivas} regra(s) executável(is) ativa(s).`) },
  { id: 'regras-conflitos', nome: 'Detecção de conflitos e duplicidades', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/brain-conflicts.ts'],
    descricao: 'Compara o que será ativado com o que já vale: duplicado, contradição e regras incompatíveis.', conteudo: ['Mostra qual prevalece', 'Pede confirmação antes de ativar'], estado: () => ok() },
  { id: 'regras-aprendizado', nome: 'Aprendizado com revisão', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/brain.ts'],
    descricao: 'Respostas aprendidas nas conversas entram como pendentes e só valem depois de aprovadas.', conteudo: ['Aprovar, rejeitar, desativar e reativar', 'Histórico e versões'],
    estado: (e) => !e.brain.aprender ? off('Aprendizado desligado em Cérebro e busca.') : e.pendentes ? pend(`${e.pendentes} item(ns) aguardando aprovação.`) : ok() },
  { id: 'regras-comandos', nome: 'Respostas rápidas e cálculos sem IA', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/intents.ts', 'lib/math.ts', 'ai/engine.ts'],
    descricao: 'Responde na hora, sem gastar IA, a pedidos que tem certeza de entender: cotações, impostos/DAS, faturamento, busca de empresas e contas.', conteudo: ['Cotações de cripto e ações', 'Impostos e DAS do MEI', 'Faturamento', 'Busca de empresas por perto', 'Cálculos matemáticos'], estado: () => ok() },
  { id: 'regras-idempotencia', nome: 'Execução única de comandos', categoria: 'Regras de interpretação e execução de comandos', fonte: ['ai/once.ts'],
    descricao: 'Evita executar duas vezes o mesmo comando (duplo toque, reenvio).', conteudo: ['Chave por conteúdo e janela de tempo'], estado: () => ok() },

  /* ---- Catálogo ---- */
  { id: 'catalogo-empresas', nome: 'Catálogo, pedidos e página pública', categoria: 'Catálogo, pedidos e empresas', fonte: ['routes/businesses.ts', 'routes/ads.ts', 'routes/items.ts'],
    descricao: 'Produtos e serviços com variações opcionais, fotos, carrinho, pedidos e página pública temática.', conteudo: ['Variações opcionais', 'Localização manual ou automática', 'Tema visual único da empresa'], estado: (e) => modulo(e, 'catalogo', 'Catálogo') },

  /* ---- Integrações e IA ---- */
  { id: 'ia-provedores', nome: 'Provedores de IA e roteamento', categoria: 'Integrações e inteligência artificial', fonte: ['ai/provider.ts', 'ai/registry.ts', 'ai/health.ts', 'ai/types.ts', 'ai/adapters/'],
    descricao: 'Vários provedores (Gemini, Claude, OpenAI, Groq, Ollama…) com fallback, tempo limite e proteção contra falhas repetidas.',
    conteudo: ['Escolha por prioridade, velocidade ou qualidade', 'Teste de cada IA e capacidades por provedor'],
    estado: (e) => e.brain.modoIA === 'sem_ia' ? off('Modo "sem IA" ligado.') : e.ia.qtd ? ok(`${e.ia.qtd} IA(s) pronta(s).`) : pend('Nenhuma IA configurada: o chat usa só o motor interno e o Cérebro.') },
  { id: 'ia-voz', nome: 'Voz: áudio para texto e leitura em voz alta', categoria: 'Integrações e inteligência artificial', fonte: ['ai/tts.ts', 'ai/docs.ts'],
    descricao: 'Transcreve áudios enviados e lê respostas em voz alta com cadeia de vozes.', conteudo: ['Transcrição por IA com áudio', 'Voz sintética com fallback'],
    estado: (e) => !e.mod.voz ? off('Módulo "Voz" desligado.') : e.tts ? ok() : off('Leitura em voz alta desligada.') },
  { id: 'ia-imagens', nome: 'Imagens no chat', categoria: 'Integrações e inteligência artificial', fonte: ['ai/docs.ts', 'ai/assistant.ts'],
    descricao: 'Entende fotos enviadas (comprovantes, documentos).', conteudo: ['Análise por IA com visão', 'OCR gratuito (OCR.space) como alternativa'],
    estado: (e) => !e.mod.imagens ? off('Módulo "Imagens" desligado.') : e.ia.imagem ? ok() : pend('Sem IA com visão: só OCR gratuito.') },
  { id: 'integ-geocode', nome: 'Endereço e localização', categoria: 'Integrações e inteligência artificial', fonte: ['lib/geocode.ts'],
    descricao: 'Converte endereço em coordenadas e o inverso, para o mapa da empresa.', conteudo: ['Endereço manual ou localização automática'], estado: () => ok() },
  { id: 'integ-whatsapp', nome: 'Atalho para WhatsApp', categoria: 'Integrações e inteligência artificial', fonte: ['frontend/public/agente.html'],
    descricao: 'Abre a conversa do cliente com a empresa no WhatsApp.', conteudo: ['Link direto wa.me'], limites: ['Conversas e campanhas não são enviadas pelo WhatsApp automaticamente; só o aviso de pedido novo para a própria empresa (abaixo)'], estado: () => ok() },
  { id: 'integ-whatsapp-pedidos', nome: 'Pedidos novos no WhatsApp da empresa', categoria: 'Integrações e inteligência artificial', fonte: ['lib/whatsapp-envio.ts', 'lib/recebimento-pedidos.ts'],
    descricao: 'A empresa escolhe receber os novos pedidos no painel, no WhatsApp cadastrado, ou nos dois. No WhatsApp chega o pedido completo.', conteudo: ['WhatsApp Cloud API (Meta), Evolution API ou Z-API, configurados pelo administrador', 'Um envio por pedido, sem duplicar', 'Falhou: tenta de novo e avisa no painel'],
    limites: ['Depende de um provedor de WhatsApp configurado no painel', 'Não muda o status do pedido'], estado: (e) => e.whatsappEnvio ? ok() : pend('Envio de WhatsApp não configurado (Painel → WhatsApp (envio)).') },

  /* ---- Segurança ---- */
  { id: 'seg-honestidade', nome: 'Honestidade sobre ações externas', categoria: 'Segurança e honestidade', fonte: ['ai/commercial.ts', 'ai/assistant.ts'],
    descricao: 'O chat nunca afirma que enviou campanhas, push, e-mails ou mensagens que não foram realmente executados.', conteudo: ['Instrução fixa no sistema', 'Filtro que remove frases de envio falso e acrescenta aviso'], estado: () => ok() },
  { id: 'seg-escopo', nome: 'Escopos e permissões das regras', categoria: 'Segurança e honestidade', fonte: ['ai/rules.ts'],
    descricao: 'Regras valem só para o público e o escopo escolhidos; visitante sem login não aciona ações que exigem usuário.', conteudo: ['Público: todos, donos, administradores', 'Escopo: chat, agentes ou ambos'], estado: () => ok() },
]

/** Arquivos de server/src/ai que são infraestrutura e não carregam "conhecimento" próprio (testados em run.ts). */
export const INFRA = ['capabilities.ts', 'types.ts', 'assets.ts', 'brain-usage.ts']

export interface CapOut { id: string; nome: string; categoria: string; descricao: string; status: CapStatus; statusRotulo: string; motivo: string; origem: 'codigo' | 'cadastro'; fonte: string[]; conteudo: string[]; limites: string[]; itemId?: number }

export async function coletarEstado(): Promise<Estado> {
  const mod = await modules()
  const b = await getConfig<any>('brain', {})
  const mk = await import('../lib/marketing.js')
  const fup = await getConfig<any>('followup', {})
  const mp = await getConfig<any>('mp', {})
  const tts = await getConfig<any>('tts', {})
  let ia = { texto: false, imagem: false, qtd: 0 }
  try {
    const R = await import('./registry.js')
    const alvos = (await Promise.all((await R.loadProviders()).filter((p) => p.ativo !== false).map((p) => R.targetFor(p).catch(() => null)))).filter(Boolean) as any[]
    ia = { texto: alvos.some((a) => a.caps.texto), imagem: alvos.some((a) => a.caps.imagem), qtd: alvos.length }
  } catch { /* sem registro de IA */ }
  const n = async (sql: string) => { try { return Number((await q(sql))[0]?.n) || 0 } catch { return 0 } }
  const coins = await (await import('../lib/coins.js')).coinsCfg()
  const tok = (m: any) => !!(m?.producao?.tok || m?.teste?.tok)
  return {
    mod: mod as Record<string, boolean>,
    brain: { aprender: b.aprender !== false, cerebroPrimeiro: b.cerebroPrimeiro !== false, fatos: b.fatos !== false, modoIA: b.modoIA || 'normal' },
    mktGlobal: await mk.mktOn(), followup: fup.ativo !== false, mpPronto: tok(mp), ia, tts: tts.ativo !== false,
    regrasAtivas: await n("SELECT COUNT(*) AS n FROM brain_answers WHERE nature = 'executavel' AND status = 'ativo'"),
    pendentes: await n("SELECT COUNT(*) AS n FROM brain_answers WHERE status = 'pendente'"),
    pushInscritos: await n('SELECT COUNT(*) AS n FROM push_subscriptions'),
    multiagente: await (async () => { const A = await import('./agentes.js'), c = await A.maCfg(); return { ativo: c.ativo, agentes: Object.values(c.agentes).filter(Boolean).length } })(),
    intel: await (async () => { const N = await import('./nucleo.js'), cfg: any = await N.intelCfg(), b: any = await one("SELECT result FROM intel_runs WHERE kind = 'bateria' ORDER BY id DESC LIMIT 1").catch(() => null), f: any = await one('SELECT COUNT(*) AS n FROM response_feedback').catch(() => null); let bat = null; try { bat = b ? JSON.parse(String(b.result)) : null } catch { bat = null } return { cfg, bateria: bat, feedback: Number(f?.n || 0) } })(),
    cognicao: await (async () => { const C = await import('./cognition.js'), r: any = await one('SELECT COUNT(*) AS n, AVG(overall) AS m FROM cognition_evals').catch(() => null); return { ativo: (await C.cogCfg()).ativo, total: Number(r?.n || 0), geral: r?.m == null ? null : Math.round(Number(r.m)) } })(),
    aprendizagem: await (async () => { const A = await import('./adaptive.js'), r: any = await one("SELECT COUNT(*) AS n, COUNT(DISTINCT user_id) AS u FROM learnings WHERE state = 'ativo'").catch(() => null); return { ativo: await A.globalOn(), total: Number(r?.n || 0), usuarios: Number(r?.u || 0) } })(),
    agendaIA: await (async () => { const rows = await q('SELECT data FROM businesses'); const K = await import('../lib/calendar.js'); return { ativo: (await getConfig<any>('agenda_ia', { ativo: true })).ativo !== false, empresas: rows.length, inteligentes: rows.filter((r: any) => { try { return K.calendarioDe(J<any>(r.data, {})).modo !== 'manual' } catch { return false } }).length } })(),
    lab: { total: await n('SELECT COUNT(*) AS n FROM lab_proposals'), publicadas: await n("SELECT COUNT(*) AS n FROM lab_proposals WHERE state = 'publicada'"), aguardando: await n("SELECT COUNT(*) AS n FROM lab_proposals WHERE state = 'aguardando_aprovacao'") },
    cupons: { total: await n('SELECT COUNT(*) AS n FROM coupons'), ativos: await n("SELECT COUNT(*) AS n FROM coupons WHERE status = 'ativo'"), usados: await n("SELECT COUNT(*) AS n FROM coupon_redemptions WHERE status <> 'estornado'") },
    whatsappEnvio: await (await import('../lib/whatsapp-envio.js')).configurado().catch(() => false),
    moedas: { ativo: coins.ativo, qtd: await n('SELECT COUNT(*) AS n FROM coins'), publicadas: await n("SELECT COUNT(*) AS n FROM coins WHERE status = 'ativa'"), adesao: coins.adesao.ativo },
  }
}

const mapaStatus = (s: string): CapStatus => s === 'ativo' ? 'ativo' : s === 'pendente' ? 'pendente' : 'inativo'
const NAT: Record<string, string> = { consulta: 'Consulta (informação)', diretriz: 'Diretriz (orienta a IA)', executavel: 'Regra executável', legado: 'Regra (cadastro antigo)' }

/** Catálogo completo: capacidades de código + cada conhecimento/regra cadastrado, sem duplicar ids. */
export async function catalogo(): Promise<{ itens: CapOut[]; resumo: Record<CapStatus, number>; porCategoria: { categoria: string; total: number; ativos: number }[]; duplicados: { titulo: string; ids: number[] }[] }> {
  const e = await coletarEstado()
  const itens: CapOut[] = CAPS.map((c) => { const r = c.estado(e); return { id: c.id, nome: c.nome, categoria: c.categoria, descricao: c.descricao, status: r.status, statusRotulo: STATUS_ROTULO[r.status], motivo: r.motivo, origem: 'codigo' as const, fonte: c.fonte, conteudo: c.conteudo, limites: c.limites || [] } })
  let rows: any[] = []
  try { rows = await q('SELECT id, question, answer, origin, kind, status, nature, scope, priority FROM brain_answers ORDER BY id DESC LIMIT 500') } catch { /* sem tabela */ }
  const vistos = new Map<string, number[]>()
  for (const r of rows) {
    const nat = r.nature || (r.kind === 'regra' ? 'legado' : 'consulta')
    const st = mapaStatus(String(r.status))
    const t = String(r.question || '').trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    if (st === 'ativo' || st === 'pendente') vistos.set(t, [...(vistos.get(t) || []), Number(r.id)])
    itens.push({ id: 'cadastro-' + r.id, itemId: Number(r.id), nome: String(r.question || '(sem título)').slice(0, 120), categoria: 'Conhecimentos e regras cadastrados', descricao: `${NAT[nat] || nat} · origem: ${r.origin || 'administrador'} · escopo: ${r.scope || 'chat'}`,
      status: st, statusRotulo: STATUS_ROTULO[st] + (r.status === 'rejeitado' ? ' (rejeitado)' : r.status === 'desativado' ? ' (desativado)' : ''), motivo: st === 'ativo' ? 'Em uso pelo chat.' : st === 'pendente' ? 'Aguardando aprovação do administrador.' : 'Não é usado pelo chat.', origem: 'cadastro', fonte: ['brain_answers'], conteudo: [String(r.answer || '').slice(0, 600)], limites: [] })
  }
  const resumo: Record<CapStatus, number> = { ativo: 0, inativo: 0, pendente: 0, desenvolvimento: 0 }
  for (const i of itens) resumo[i.status]++
  const porCategoria = CATEGORIAS.map((c) => { const l = itens.filter((i) => i.categoria === c); return { categoria: c as string, total: l.length, ativos: l.filter((i) => i.status === 'ativo').length } })
  const duplicados = [...vistos.entries()].filter(([, ids]) => ids.length > 1).map(([titulo, ids]) => ({ titulo, ids }))
  return { itens, resumo, porCategoria, duplicados }
}
