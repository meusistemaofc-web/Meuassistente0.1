// CÉREBRO COGNITIVO — camada de inteligência que envolve o pipeline de resposta que já existe (regras, motores internos,
// Cérebro, aprendizagem adaptativa, memória, ferramentas e IAs). Ela NÃO substitui nada: lê a mensagem antes, orienta a
// IA com o que importa (intenção, contexto, lacunas, contradições, tom, capacidades reais) e confere a resposta depois
// (ações não confirmadas, links inventados, tom robótico) e a avalia. Tudo é determinístico (sem custo de IA extra),
// por usuário (nada de uma pessoa chega a outra) e só guarda notas — nunca o texto das conversas.
import { q, one, nowIso, J } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import type { SessionUser } from '../lib/session.js'
import { operacoesDaMensagem } from './adaptive.js'
import { canon } from './once.js'

type Msg = { role: string; content: string | null }
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const norm = (t: string) => nrm(t).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set('a o os as um uma uns umas de da do das dos e ou em no na nos nas para pra por com sem que se ao aos como mais muito pouco sobre isso este esta esse essa ele ela eles elas voce voces seu sua seus suas ser estar ter tem foi sao ja nao sim quando onde qual quais quem porque pois entao tambem ate cada todo toda todos todas meu minha quero preciso favor'.split(' '))
const topicos = (t: string) => new Set(norm(t).split(' ').filter((w) => w.length > 3 && !STOP.has(w)))
const dice = (a: string, b: string) => { const A = new Set(a.split(' ').filter((w) => w.length > 2)), B = new Set(b.split(' ').filter((w) => w.length > 2)); if (!A.size || !B.size) return 0; let i = 0; for (const w of A) if (B.has(w)) i++; return (2 * i) / (A.size + B.size) }
const frases = (t: string) => String(t || '').split(/(?<=[.!?])\s+|\n+/).map((f) => f.trim()).filter(Boolean)
const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)

/* ======================= configuração (Painel → Cérebro) ======================= */
export const COG_DEFAULT = { ativo: true, humanizar: true, guardaAcoes: true, portaoSensivel: true }
export const cogCfg = async () => ({ ...COG_DEFAULT, ...(await getConfig<any>('cognition', {})) }) as typeof COG_DEFAULT & { atualizadoEm?: string }

/* ======================= 1–2) COMPREENSÃO: intenção, lacunas, ambiguidades, contradições ======================= */
export interface Slots { hora?: string; dia?: string; valor?: number }
export function slotsDe(text: string): Slots {
  const s = nrm(text), out: Slots = {}
  if (/\bmeio[- ]dia\b/.test(s)) out.hora = '12:00'
  else {
    const m = s.match(/\b(?:as|pelas|pras|para as|a partir das)\s*(\d{1,2})(?:[:h](\d{2}))?\s*(?:h|horas?)?\b/) || s.match(/\b(\d{1,2})[:h](\d{2})\b/) || s.match(/\b(\d{1,2})\s*h(?:oras?)?\b/)
    if (m) { let hh = Number(m[1]); const mm = Number(m[2] || 0); if (/\b(da tarde|a tarde|da noite|a noite)\b/.test(s) && hh < 12) hh += 12; if (hh <= 23 && mm <= 59) out.hora = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}` }
  }
  const d = s.match(/\b(depois de amanha|amanha|hoje|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/) || s.match(/\b(dia \d{1,2}(?:\/\d{1,2})?)\b/) || s.match(/\b(\d{1,2}\/\d{1,2})\b/)
  if (d) out.dia = d[1]
  const v = s.match(/r\$\s*(\d[\d.,]*)/) || s.match(/\b(\d+(?:[.,]\d+)?)\s*(?:reais|real|conto|pila)\b/)
  if (v) { const n = parseFloat(v[1].replace(/\.(?=\d{3}\b)/g, '').replace(',', '.')); if (Number.isFinite(n)) out.valor = n }
  return out
}

export type Tipo = 'saudacao' | 'agradecimento' | 'confirmacao' | 'negacao' | 'correcao' | 'comando' | 'pergunta' | 'desabafo' | 'continuacao' | 'outro'
export interface FatoDuradouro { categoria: string; trecho: string; sensivel: boolean; bloqueado: boolean }
export interface Analise {
  tipo: Tipo; registro: 'formal' | 'informal' | 'neutro'; emocao: 'neutra' | 'frustrado' | 'ansioso' | 'urgente' | 'animado'
  completude: 'completa' | 'incompleta' | 'eliptica'; extensao: 'curta' | 'detalhada'
  multiEtapa: boolean; etapas: number; ambiguidades: string[]; faltando: string[]; contradicoes: string[]
  referenciaProvavel: string; operacoes: string[]; fatos: FatoDuradouro[]
}
const INFORMAL = /\b(vc|vcs|blz|kk+|k{3,}|rs+|mano|mana|cara|tbm|tb|pq|vlw|valeu|eae|e ai|opa|fala|ta|to|ne|pra|q|oq|msm|mt|mto|hj|amg|amigao|brother|bora|top|pdc)\b/
const FORMAL = /\b(prezad[oa]s?|senhor[a]?|por gentileza|poderia|gostaria|cordialmente|atenciosamente|solicito|agradeco antecipadamente)\b/
const VERBO_IMP = /\b(agend(a|e|ar|ei)|marc(a|ar|que)|registr(a|ar|e)|anot(a|ar|e)|lembr(a|ar|e)|cri(a|ar|e)|adicion(a|ar|e)|cancel(a|ar|e)|exclu(i|ir|a)|apag(a|ar|ue)|mostr(a|ar|e)|list(a|ar|e)|mand(a|ar|e)|envi(a|ar|e)|ger(a|ar|e)|calcul(a|ar|e)|pag(a|ar|ue)|conclu(i|ir|a)|remarc(a|ar|que)|atualiz(a|ar|e)|busc(a|ar|ue)|procur(a|ar|e)|consult(a|ar|e)|abr(a|ir|e)|faz(er)?|fac(a|o)|resum(a|ir|e)|compar(a|ar|e)|analis(a|ar|e)|cadastr(a|ar|e)|lanc(a|ar|e)|mud(a|ar|e)|troc(a|ar|que)|alter(a|ar|e))\b/g
const REG_FIN = /\b(gastei|paguei|comprei|recebi|ganhei|vendi)\b/
const FATOS: { cat: string; re: RegExp; sensivel?: boolean }[] = [
  { cat: 'nome', re: /\b(meu nome e|me chamo|pode me chamar de)\s+\w+/ },
  { cat: 'local', re: /\b(moro (em|no|na|perto)|sou de|minha cidade e)\b/ },
  { cat: 'trabalho', re: /\b(trabalho (com|como|na|no|em|de|para)|minha profissao e|sou (advogad|medic|dentista|professor|engenheir|designer|programador|autonom|empresari|dono|vendedor|motorista|enfermeir|contador|arquitet|psicolog|estudante)\w*)/ },
  { cat: 'familia', re: /\bminh[ao]s? (esposa|marido|filh[oa]s?|mae|pai|irma[o]?|namorad[oa]|noiv[oa]|sogr[oa]|socio|socia)\b.*\b(se chama|chama|tem|e)\b/ },
  { cat: 'preferencia', re: /\b(prefiro|nao gosto de|gosto de|sempre (uso|quero|prefiro)|odeio|adoro)\b/ },
  { cat: 'saude', re: /\b(sou alergic\w*|alergia a|tenho (diabetes|hipertensao|asma|depressao|ansiedade)|estou gravida|sou gestante|faco tratamento)\b/, sensivel: true },
  { cat: 'data_pessoal', re: /\b(meu aniversario (e|eh)|nasci em)\b/ },
  { cat: 'rotina', re: /\b(toda (segunda|terca|quarta|quinta|sexta|sabado|domingo|manha|tarde|noite)|todo dia|toda semana)\b.*\b(eu|vou|tenho|treino|trabalho|saio|acordo)\b/ },
]
const TEMPORARIO = /\b(hoje|agora|neste momento|nesta semana|esta semana|essa semana|amanha|ontem|esta noite|essa noite)\b/
const BLOQUEADO = /(\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b|\b(?:\d[ -]?){13,19}\b|\b(senha|password|token|cvv|codigo de seguranca)\b)/
export function fatosDuradouros(text: string): FatoDuradouro[] {
  const out: FatoDuradouro[] = []
  for (const f of frases(text)) {
    const s = nrm(f), bloq = BLOQUEADO.test(s)
    if (bloq) { out.push({ categoria: 'dado_protegido', trecho: '', sensivel: true, bloqueado: true }); continue }
    if (TEMPORARIO.test(s)) continue // contexto passageiro: serve para esta conversa, não vira memória
    for (const x of FATOS) if (x.re.test(s)) { out.push({ categoria: x.cat, trecho: f.slice(0, 160), sensivel: !!x.sensivel, bloqueado: false }); break }
  }
  return out
}

export function analisar(text: string, hist: Msg[] = []): Analise {
  const raw = String(text || '').trim(), s = norm(raw), w = s.split(' ').filter(Boolean)
  const prev = hist.filter((m) => m.content), ultUser = [...prev].reverse().find((m) => m.role === 'user'), ultBot = [...prev].reverse().find((m) => m.role === 'assistant')
  const ehCmd = /^(pode|poderia|consegue|me ajuda|ajuda|quero|preciso|gostaria)\b/.test(s) || (s.match(VERBO_IMP) || []).length > 0 || REG_FIN.test(s)
  let tipo: Tipo = 'outro'
  if (/^(nao[ ,.!]*(o certo|na verdade|e |era |sao )|na verdade|corrigindo|correcao|errado|errei|me enganei|eu errei)\b/.test(s) || /\b(errei|me enganei|foi sem querer|digitei errado)\b/.test(s)) tipo = 'correcao'
  else if (w.length <= 5 && /^(sim|pode|isso|ok|certo|confirmo|combinado|fechado|beleza|blz|claro|positivo|manda ver|pode ser|vamos|bora|uhum|aham)\b/.test(s) && !(s.match(VERBO_IMP) || []).length) tipo = 'confirmacao'
  else if (w.length <= 6 && /^(nao|deixa|esquece|melhor nao|negativo|nada)\b/.test(s) && !/\b(funciona|funcionou|entende|entendeu|adianta|consigo|abre|carrega|aparece)\b/.test(s)) tipo = 'negacao'
  else if (w.length <= 5 && /^(oi|ola|bom dia|boa tarde|boa noite|e ai|eae|opa|fala|salve|hey|hello|oie)\b/.test(s)) tipo = 'saudacao'
  else if (w.length <= 8 && /^(obrigad\w*|valeu|vlw|brigad\w*|show|perfeito|otimo|muito bom|top|legal)\b/.test(s)) tipo = 'agradecimento'
  else if (/\b(estou|to|ando|me sinto) (muito |tao |super )?(mal|triste|ansios\w*|cansad\w*|desanimad\w*|estressad\w*|desesperad\w*|sobrecarregad\w*|sem forcas)\b/.test(s)) tipo = 'desabafo'
  else if (prev.length && w.length <= 8 && /^(e |mas |entao |tambem |alem disso|ah e |e se |ou )/.test(s)) tipo = 'continuacao'
  else if (ehCmd && !/^(qual|quais|quando|onde|como|quanto|quem|por que|porque|o que)\b/.test(s)) tipo = 'comando'
  else if (/\?\s*$/.test(raw) || /^(qual|quais|quando|onde|como|quanto|quem|por que|porque|o que|que horas|existe|tem |sera|posso|da pra|voce sabe)\b/.test(s)) tipo = 'pergunta'
  else if (ehCmd) tipo = 'comando'

  const registro: Analise['registro'] = FORMAL.test(s) ? 'formal' : INFORMAL.test(s) || /\p{Extended_Pictographic}/u.test(raw) ? 'informal' : 'neutro'
  const maius = raw.replace(/[^A-Za-zÀ-ÿ]/g, ''), caps = maius.length >= 8 && raw.replace(/[^A-ZÀ-Ý]/g, '').length / maius.length > 0.6
  let emocao: Analise['emocao'] = 'neutra'
  if (/\b(nao funciona|nao esta funcionando|de novo|ja falei|ja disse|pela \w+ vez|que droga|pessimo|horrivel|odeio|cansei|inutil|nao entende|nao entendeu|bugou|travou|nao adianta)\b/.test(s) || /!{2,}/.test(raw) || caps) emocao = 'frustrado'
  else if (/\b(urgente|urgencia|rapido|rapidinho|agora mesmo|o quanto antes|pra ontem|socorro|corre)\b/.test(s)) emocao = 'urgente'
  else if (/\b(preocupad\w*|ansios\w*|nervos\w*|medo|desesper\w*|aflit\w*)\b/.test(s)) emocao = 'ansioso'
  else if (/\b(adorei|amei|maravilhos\w*|incrivel|que otimo|uhul|aeee)\b/.test(s)) emocao = 'animado'

  const ops = operacoesDaMensagem(raw), slots = slotsDe(raw), antes = prev.filter((m) => m.role === 'user').slice(-6).map((m) => String(m.content))
  const antesSlots = antes.map(slotsDe)
  const jaTem = (k: keyof Slots) => !!slots[k] || antesSlots.some((x) => !!x[k])
  const faltando: string[] = []
  if (tipo === 'comando') {
    if (/\b(gastei|paguei|comprei|recebi|ganhei|vendi)\b/.test(s) && !/\d/.test(s) && !antes.some((t) => /\d/.test(t))) faltando.push('o valor')
    if (/\b(agend\w*|marc\w*|reserv\w*)\b/.test(s) && !/\b(cancel|desmarc|remarc)/.test(s)) { const d = jaTem('dia'), h = jaTem('hora'); if (!d && !h) faltando.push('o dia e o horário'); else if (!d) faltando.push('o dia'); else if (!h) faltando.push('o horário') }
    if (/\b(lembr\w*|me avis\w*)\b/.test(s) && !jaTem('dia') && !jaTem('hora') && !/\d+\s*(min|minutos|horas?)\b/.test(s)) faltando.push('quando devo avisar')
    if (/\b(cadastr\w*|cri[ae]\w*|adicion\w*)\b/.test(s) && /\b(conta|boleto|fatura)\b/.test(s) && !jaTem('dia') && !/\bvence\w*\s+(dia|em)\b/.test(s)) faltando.push('o vencimento')
  }
  const ambiguidades: string[] = []
  if (!prev.length && /\b(isso|esse|essa|esses|essas|aquele|aquela|aquilo|dele|dela|o mesmo|a mesma)\b/.test(s) && tipo !== 'confirmacao') ambiguidades.push('a mensagem fala de algo ("isso", "aquele"…), mas ainda não há assunto anterior na conversa')
  if (/\b(?:as|pelas|pras)\s*([1-9]|1[01])\b(?!\s*(?:h|:|horas?|da manha|da tarde|da noite|de manha|de tarde|de noite))/.test(nrm(raw)) && !/\b(da manha|da tarde|da noite|de manha|de tarde|de noite)\b/.test(s) && (ops.includes('agendamento') || ops.includes('lembrete'))) ambiguidades.push('horário sem período (manhã, tarde ou noite)')
  const contradicoes: string[] = []
  const troca = /\b(muda\w*|remarc\w*|troc\w*|na verdade|corrig\w*|errei|em vez|ao inves|agora e|passa\w* para|alter\w*|adi\w+|antecip\w*)\b/.test(s)
  if (!troca && tipo === 'comando') {
    const tp = topicos(raw)
    for (let i = antes.length - 1; i >= 0; i--) {
      const outro = topicos(antes[i]); let comum = false; for (const t of tp) if (outro.has(t)) { comum = true; break }
      if (!comum) continue
      const a = antesSlots[i]
      if (slots.hora && a.hora && slots.hora !== a.hora) contradicoes.push(`horário: antes ${a.hora}, agora ${slots.hora}`)
      if (slots.dia && a.dia && slots.dia !== a.dia) contradicoes.push(`dia: antes "${a.dia}", agora "${slots.dia}"`)
      if (slots.valor != null && a.valor != null && slots.valor !== a.valor) contradicoes.push(`valor: antes R$ ${a.valor}, agora R$ ${slots.valor}`)
      if (contradicoes.length) break
    }
  }
  const eliptica = prev.length > 0 && !['saudacao', 'agradecimento', 'confirmacao', 'negacao', 'correcao'].includes(tipo) && (tipo === 'continuacao' || (/\b(isso|esse|essa|esses|essas|aquele|aquela|aquilo|dele|dela|o mesmo|a mesma|ali)\b/.test(s) && w.length <= 6) || (w.length <= 2 && tipo === 'outro'))
  const incompleta = !eliptica && ((tipo === 'comando' && w.length <= 1) || /\b(de|para|pra|com|e|ou|que|do|da|no|na|as|um|uma)$/.test(s) || faltando.length > 0)
  const verbos = (s.match(VERBO_IMP) || []).length, enumer = (raw.match(/(^|\n)\s*(\d+[.)]|[-*•])\s+\S/g) || []).length
  const multi = (verbos >= 2 && /\b(e depois|em seguida|depois disso|tambem|alem disso|e ainda|e tambem| e )\b/.test(' ' + s + ' ')) || enumer >= 2 || (verbos >= 3)
  return {
    tipo, registro, emocao, completude: eliptica ? 'eliptica' : incompleta ? 'incompleta' : 'completa',
    extensao: /\b(explic\w*|detalh\w*|passo a passo|como funciona|compar\w*|por que|porque|resum\w*|analis\w*|me conte|descrev\w*|diferenca|vantagens|exemplo\w*)\b/.test(s) || w.length > 30 ? 'detalhada' : 'curta',
    multiEtapa: multi, etapas: Math.max(verbos, enumer), ambiguidades, faltando, contradicoes,
    referenciaProvavel: eliptica || /\b(isso|esse|essa|aquele|aquela|dele|dela|o mesmo|a mesma|la)\b/.test(s) ? [ultUser ? `última pergunta do usuário: "${String(ultUser.content).replace(/\s+/g, ' ').slice(0, 140)}"` : '', ultBot ? `sua última resposta: "${String(ultBot.content).replace(/⟦[^⟧]*⟧/g, '').replace(/\s+/g, ' ').slice(0, 140)}"` : ''].filter(Boolean).join('; ') : '',
    operacoes: ops, fatos: fatosDuradouros(raw),
  }
}

/* ======================= perfil de comunicação (só das mensagens do próprio usuário; nada é gravado) ======================= */
export interface Perfil { n: number; medio: number; emoji: boolean; informal: boolean; formal: boolean; conciso: boolean; detalhista: boolean }
export function perfilDe(hist: Msg[], atual = ''): Perfil {
  const us = [...hist.filter((m) => m.role === 'user' && m.content).slice(-12).map((m) => String(m.content)), atual].filter(Boolean), n = us.length || 1
  const medio = us.map((t) => norm(t).split(' ').filter(Boolean).length).reduce((a, b) => a + b, 0) / n
  const inf = us.filter((t) => INFORMAL.test(norm(t))).length, form = us.filter((t) => FORMAL.test(norm(t))).length
  return { n: us.length, medio: Math.round(medio * 10) / 10, emoji: us.some((t) => /\p{Extended_Pictographic}/u.test(t)), informal: inf >= Math.max(1, Math.ceil(n * 0.3)), formal: form >= Math.max(1, Math.ceil(n * 0.3)) && inf <= form, conciso: us.length >= 3 && medio <= 6, detalhista: us.length >= 3 && medio >= 25 }
}

/** O que o usuário já disse e ficou fora da janela de histórico enviada à IA — evita perguntar de novo. */
export function fatosDaConversa(fora: Msg[]): string {
  const linhas: string[] = []
  for (const m of fora.filter((x) => x.role === 'user' && x.content).slice(-10)) {
    const t = String(m.content).replace(/\s+/g, ' ').trim(); if (BLOQUEADO.test(nrm(t))) continue
    const sl = slotsDe(t)
    if (sl.dia || sl.hora || sl.valor != null || fatosDuradouros(t).some((f) => !f.bloqueado) || t.split(' ').length >= 6) linhas.push(`- "${t.slice(0, 110)}"`)
  }
  return linhas.slice(-6).join('\n')
}

/** Recorrência: quantas vezes ESTE usuário já fez um pedido parecido (outras conversas). */
export async function recorrencia(userId: number, convId: string, text: string): Promise<number> {
  const qn = norm(text); if (qn.split(' ').length < 3) return 0
  const rows = await q("SELECT content FROM messages WHERE user_id = $1 AND role = 'user' AND conversation_id <> $2 ORDER BY id DESC LIMIT 300", [userId, convId || '']).catch(() => [] as any[])
  return rows.filter((r: any) => dice(qn, norm(String(r.content))) >= 0.6).length
}
/** Quantas das últimas respostas o usuário corrigiu (aprendizado individual e leve: pede mais conferência). */
export async function correcoesRecentes(userId: number): Promise<number> {
  const rows = await q('SELECT corrected FROM cognition_evals WHERE user_id = $1 ORDER BY id DESC LIMIT 30', [userId]).catch(() => [] as any[])
  return rows.filter((r: any) => r.corrected === true || r.corrected === 1 || r.corrected === 't' || r.corrected === 'true').length
}

/* ======================= orientação ao modelo (entra no texto de sistema) ======================= */
const FERRAMENTAS: Record<string, string> = { create_task: 'criar tarefas', create_appointment: 'agendar compromissos', create_reminder: 'criar lembretes', add_shopping_items: 'lista de compras', create_note: 'salvar anotações', register_transaction: 'registrar gastos e receitas', create_bill: 'cadastrar contas a pagar', complete_task: 'concluir tarefas', save_memory: 'guardar memórias quando o usuário pedir', get_agenda: 'consultar a agenda', get_finance: 'consultar as finanças do mês' }
const GRUPOS: [string, string][] = [['agenda_empresa_', 'agenda e horários da empresa'], ['crm_', 'CRM da empresa'], ['negocio_', 'análise de desempenho da empresa']]
export function capacidadesReais(tools: { function: { name: string } }[]): string {
  const out = new Set<string>()
  for (const t of tools) { const n = t.function.name; const g = GRUPOS.find(([p]) => n.startsWith(p)); out.add(g ? g[1] : FERRAMENTAS[n] || n) }
  return [...out].join('; ')
}
export const CONFIABILIDADE = 'CONFIABILIDADE: separe o que é FATO (vem do cadastro, da conversa ou de uma ferramenta), HIPÓTESE (diga "provavelmente…") e SUGESTÃO (diga "uma ideia…"). Nunca invente dados, números, links, fontes, estudos ou funcionalidades. Se não souber ou faltar informação, diga com clareza e diga o que seria necessário. Só afirme que executou algo se a ferramenta retornou sucesso nesta conversa; se falhou, conte o que falhou, sem repetir às cegas. Antes de ações sensíveis ou irreversíveis (cancelar, excluir, enviar, pagar, alterar o que afeta clientes) peça confirmação explícita.'
export const NATURALIDADE = 'ESTILO: fale como uma pessoa atenciosa e competente. Sem "Como assistente de IA…", sem "Espero ter ajudado", sem repetir a pergunta do usuário, sem começar toda resposta do mesmo jeito. Pergunta simples → resposta direta; assunto complexo → organize em poucos passos claros.'

export async function contextoCognitivo(u: SessionUser, text: string, history: Msg[], an: Analise, o: { convId?: string; tools?: { function: { name: string } }[]; foraDaJanela?: Msg[]; memoriaLigada?: boolean } = {}): Promise<string> {
  const L: string[] = []
  L.push('RACIOCÍNIO ANTES DE RESPONDER (interno; não mostre): qual é a intenção real? o que o usuário já disse? falta algo indispensável? há ferramenta que resolve? a resposta é verdadeira e verificável?')
  if (an.completude === 'eliptica') L.push(`Mensagem curta que depende do que veio antes: trate como CONTINUAÇÃO e não peça para repetir.${an.referenciaProvavel ? ' Referência provável — ' + an.referenciaProvavel + '.' : ''}`)
  else if (an.referenciaProvavel && an.completude !== 'completa') L.push(`Referência provável — ${an.referenciaProvavel}.`)
  if (an.faltando.length) L.push(`Falta informação indispensável: ${an.faltando.join('; ')}. Pergunte SOMENTE isso, em uma pergunta curta (com uma sugestão quando fizer sentido) e só execute depois da resposta.`)
  if (an.ambiguidades.length) L.push(`Ambiguidade a esclarecer antes de agir: ${an.ambiguidades.join('; ')}.`)
  if (an.contradicoes.length) L.push(`Possível contradição ou troca em relação ao que o usuário disse antes (${an.contradicoes.join('; ')}): se não estiver claro se é outro registro ou uma mudança, confirme em uma frase antes de executar.`)
  if (an.tipo === 'correcao') L.push('O usuário está CORRIGINDO algo: reconheça em uma frase, aplique a correção e confirme o dado corrigido, sem se desculpar demais.')
  if (an.tipo === 'desabafo') L.push('O usuário está se abrindo sobre como se sente: acolha primeiro, com empatia genuína e frases simples; só depois, se couber, ofereça ajuda prática.')
  if (an.emocao === 'frustrado') L.push('O usuário parece frustrado: reconheça o problema com uma frase, não repita explicações que já falharam e vá direto à solução.')
  else if (an.emocao === 'urgente') L.push('O usuário tem pressa: resposta mínima e imediata; detalhes só se pedir.')
  else if (an.emocao === 'ansioso') L.push('O usuário parece preocupado: tom calmo e tranquilizador, sem prometer o que não pode garantir.')
  const p = perfilDe(history, text)
  const reg = an.registro !== 'neutro' ? an.registro : p.formal ? 'formal' : p.informal ? 'informal' : 'neutro'
  if (reg === 'informal') L.push('Tom: o usuário escreve de modo informal — fale leve e próximo, sem formalidade excessiva' + (p.emoji ? ' (pode usar um emoji ocasional)' : '') + '.')
  else if (reg === 'formal') L.push('Tom: o usuário escreve de modo formal — trate com cordialidade e correção, sem gírias.')
  if (an.extensao === 'curta' && (p.conciso || an.tipo === 'pergunta' || an.tipo === 'comando')) L.push('Tamanho: pedido simples — responda em 1 a 3 frases.')
  else if (an.extensao === 'detalhada') L.push('Tamanho: o assunto pede explicação — organize em poucos passos ou tópicos curtos, sem encher.')
  if (an.multiEtapa) L.push(`Pedido em várias etapas (~${an.etapas || 2}): planeje, execute em ordem chamando as ferramentas necessárias, confira o resultado de CADA uma e, no fim, diga com clareza o que foi feito e o que não foi.`)
  const duradouros = an.fatos.filter((f) => !f.bloqueado && !f.sensivel)
  if (duradouros.length && o.memoriaLigada) L.push(`O usuário compartilhou uma informação pessoal duradoura (${[...new Set(duradouros.map((f) => f.categoria))].join(', ')}). Use-a nesta conversa; só ofereça guardá-la na memória se ela for útil e de forma breve, sem insistir.`)
  if (an.fatos.some((f) => f.bloqueado || f.sensivel)) L.push('A mensagem traz dado sensível ou protegido (documento, cartão, senha ou saúde): não repita, não guarde na memória e use apenas o necessário para ajudar agora.')
  const fora = fatosDaConversa(o.foraDaJanela || []); if (fora) L.push(`Do começo desta conversa (já informado; não pergunte de novo):\n${fora}`)
  if (an.tipo === 'comando' && an.completude === 'completa' && text.length > 6) { const r = await recorrencia(u.id, o.convId || '', text).catch(() => 0); if (r >= 2) L.push(`Este usuário já fez pedido parecido ${r} vezes: depois de atender, ofereça (em uma frase) deixar isso automático ou recorrente, se existir recurso para isso.`) }
  if ((await correcoesRecentes(u.id).catch(() => 0)) >= 2) L.push('Este usuário corrigiu respostas suas recentemente: confirme o entendimento (data, valor, nome) em uma frase curta antes de executar.')
  if (o.tools?.length) L.push(`SUAS CAPACIDADES REAIS agora: ${capacidadesReais(o.tools)}. Não prometa nem diga que faz nada fora disso.`)
  L.push(CONFIABILIDADE, NATURALIDADE)
  return L.join('\n')
}

/* ======================= 6–7) CONFIABILIDADE e OPERAÇÃO: conferir a resposta antes de entregar ======================= */
export interface Exec { escritas: string[]; falhas: { name: string; erro: string }[]; pendentes: string[]; leituras: string[]; cartoes: number }
export const execVazio = (): Exec => ({ escritas: [], falhas: [], pendentes: [], leituras: [], cartoes: 0 })
export function resumirExec(done: { name: string; result: any }[], somenteLeitura: Set<string>, cards: any[] = []): Exec {
  const e = execVazio(); e.cartoes = cards.length
  for (const d of done) {
    if (somenteLeitura.has(d.name)) { e.leituras.push(d.name); continue }
    if (d.result?.ok === true) e.escritas.push(d.name)
    else if (d.result?.precisaConfirmar || d.result?.conflito) e.pendentes.push(d.name)
    else e.falhas.push({ name: d.name, erro: String(d.result?.error || 'não foi possível concluir').slice(0, 160) })
  }
  return e
}
const VERBOS_ACAO = '(agendei|registrei|criei|cadastrei|salvei|anotei|adicionei|lancei|marquei|conclui|cancelei|exclui|apaguei|atualizei|remarquei|paguei|guardei|programei|configurei|removi|alterei)'
const ACAO = new RegExp(`\\b${VERBOS_ACAO}\\b`)
const NEGADA = new RegExp(`\\b(nao|nem|nunca|ainda nao|sem)\\s+(?:\\w+\\s+){0,2}${VERBOS_ACAO}\\b`)
const ehClaim = (f: string) => { const n = nrm(f); return ACAO.test(n) && !NEGADA.test(n) }
const SEM_DADOS = /\b(segundo (estudos|pesquisas|especialistas)|estudos (mostram|comprovam|indicam)|pesquisas (mostram|indicam|comprovam)|comprovado cientificamente|de acordo com (a )?(oms|ibge|fgv|harvard|oecd))\b/i
const falaDeFalha = /(n[aã]o consegui|n[aã]o foi poss[ií]vel|falh|deu erro|n[aã]o deu certo|n[aã]o (salv|regist|agend|cri)ei)/i
const REPETIDOS = /^(claro|certo|entendi|perfeito|otimo|ótimo|excelente|combinado|ok|beleza|com certeza|sem problemas|pois nao|pois não)\b[!,.]?\s+/i
const hostDe = (u: string) => { try { return new URL(u).hostname.replace(/^www\./, '').toLowerCase() } catch { return '' } }
const ROBOTICO: RegExp[] = [/\bcomo (um|uma) (assistente|ia|intelig[eê]ncia artificial|modelo de linguagem)\b/i, /\bespero (ter )?ajudado\b/i, /\bestou aqui para (te )?ajudar\b/i, /\bfico feliz em ajudar\b/i, /\bsou apenas um\b/i, /\bqualquer d[úu]vida,? (estou|é só)\b/i, /\bem que posso (te )?ajudar hoje\b/i]

export interface Revisao { content: string; ajustes: string[]; flags: string[] }
/** Confere a resposta final: ação afirmada sem confirmação, falha omitida, link inventado e tom robótico. Texto honesto nunca é alterado. */
export function revisarResposta(content: string, o: { exec: Exec; fontes?: string; respostaAnterior?: string; guardaAcoes?: boolean; humanizar?: boolean; propriaUrl?: string }): Revisao {
  let c = String(content || ''); const ajustes: string[] = [], flags: string[] = []
  if (o.guardaAcoes !== false) {
    const sem = c.replace(/⟦[^⟧]*⟧/g, ''), confirmou = o.exec.escritas.length > 0 || o.exec.cartoes > 0 || /⟦(appt|fin|mod|neg|emp|loc):/.test(c)
    const temClaim = frases(sem).some(ehClaim)
    if (temClaim && !confirmou) {
      const resto = frases(c).filter((f) => !ehClaim(f.replace(/⟦[^⟧]*⟧/g, '')) && !/^(pronto|feito|tudo certo|tudo pronto|ok|beleza|certo|conclu[ií]do)[!. ]*$/i.test(f)).join(' ').trim()
      const nota = o.exec.falhas.length ? `Não consegui concluir isso: ${o.exec.falhas[0].erro.replace(/[.\s]+$/, '')}. Nada foi salvo. Quer que eu tente de novo?` : o.exec.pendentes.length ? 'Antes de fazer isso preciso da sua confirmação, então ainda não foi feito. Posso seguir?' : 'Ainda não tenho confirmação de que isso foi feito, então não registrei nada. Se quiser, me passe os detalhes e eu tento de novo.'
      c = `${resto ? resto + '\n\n' : ''}${nota}`; flags.push('acao_nao_confirmada'); ajustes.push('afirmação de ação sem confirmação foi substituída por um aviso honesto')
    } else if (confirmou && o.exec.falhas.length && o.exec.escritas.length && !falaDeFalha.test(sem)) {
      c = `${c.trim()}\n\nSó uma observação: ${o.exec.falhas.length === 1 ? 'uma das ações não foi concluída' : 'algumas ações não foram concluídas'} (${o.exec.falhas[0].erro.replace(/[.\s]+$/, '')}).`; flags.push('falha_omitida'); ajustes.push('falha parcial acrescentada à resposta')
    }
  }
  const urls = c.match(/https?:\/\/[^\s)\]>"'⟧]+/gi) || []
  if (urls.length) {
    const fontes = nrm(o.fontes || ''), proprio = hostDe(o.propriaUrl || '')
    const ruins = urls.filter((un) => { const h = hostDe(un); return h && !(fontes.includes(h) || (proprio && h === proprio)) })
    if (ruins.length) {
      const boas = (t: string) => (t.match(/https?:\/\/[^\s)\]>"'⟧]+/gi) || []).filter((un) => !ruins.includes(un))
      c = c.split('\n').map((l) => (ruins.some((un) => l.includes(un)) ? frases(l).map((f) => (!ruins.some((un) => f.includes(un)) ? f : boas(f).length ? ruins.reduce((t, un) => t.split(un).join('(link removido)'), f) : '')).filter(Boolean).join(' ') : l)).filter((l, i, arr) => l.trim() !== '' || (arr[i - 1] ?? '').trim() !== '').join('\n').trim()
      c = `${c ? c + '\n\n' : ''}Não incluí links porque não consigo confirmar que existem.`; flags.push('link_nao_verificado'); ajustes.push('link não verificado removido')
    }
  }
  if (SEM_DADOS.test(c) && !/\bfonte\b|https?:/.test(c)) flags.push('afirmacao_sem_fonte')
  if (o.humanizar !== false) {
    const antes = c
    c = c.replace(/^\s*Como (um|uma) (assistente|IA|intelig[eê]ncia artificial|modelo de linguagem)[^,.]*[,.]\s*/i, '')
    c = c.replace(/\s*(Espero (ter )?ajudado[.!]?|Qualquer d[úu]vida,? (estou|é só) [^.!?]*[.!?]?|Estou aqui para (te )?ajudar[^.!?]*[.!?]?|Fico feliz em ajudar[^.!?]*[.!?]?)\s*$/i, '')
    const ab = (o.respostaAnterior || '').match(REPETIDOS), at = c.match(REPETIDOS)
    if (ab && at && norm(ab[1]) === norm(at[1])) c = c.replace(REPETIDOS, '')
    if (c !== antes) { c = cap(c.trim()); ajustes.push('tom mais natural (sem fórmulas prontas)') }
  }
  return { content: c.trim() || String(content || '').trim(), ajustes, flags }
}

/* ======================= 7) portão para ações sensíveis ======================= */
const SENSIVEL = /(cancel|delet|exclu|apag|remov|zerar|limpar|disparar|enviar_|pagar_|transferir)/i
const JA_CONFIRMAM = new Set(['agenda_empresa_decidir', 'crm_atualizar_etapa']) // estas ferramentas já têm confirmação própria
export const ehSensivel = (name: string) => SENSIVEL.test(name) && !JA_CONFIRMAM.has(name)
const pendentes = new Map<string, number>()
/** Ferramenta sensível só roda depois que o usuário confirmou de forma explícita em uma mensagem posterior. null = liberada. */
export async function portaoSensivel(u: SessionUser, convId: string, name: string, args: any, userText: string): Promise<null | { ok: false; precisaConfirmar: true; aviso: string }> {
  if (!ehSensivel(name) || !(await cogCfg()).portaoSensivel) return null
  const key = `${u.id}|${convId}|${name}|${canon(args)}`, agora = Date.now()
  for (const [k, t] of pendentes) if (agora - t > 600_000) pendentes.delete(k)
  if (pendentes.has(key) && analisar(userText).tipo === 'confirmacao') { pendentes.delete(key); return null }
  pendentes.set(key, agora)
  return { ok: false, precisaConfirmar: true, aviso: 'Ação sensível: ainda NÃO foi executada. Diga ao usuário, em uma frase natural, exatamente o que será feito e peça um "sim" explícito. Só chame a ferramenta de novo depois da confirmação dele.' }
}

/* ======================= 8) CONTROLE DE QUALIDADE ======================= */
export interface Qualidade { precisao: number; coerencia: number; naturalidade: number; clareza: number; contexto: number; resolucao: number; geral: number; flags: string[] }
export interface AvalIn { texto: string; resposta: string; analise: Analise; exec?: Exec; hist?: Msg[]; ferramentas?: number; caminho?: string; flagsPrev?: string[] }
const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)))
export function avaliar(i: AvalIn): Qualidade {
  const flags = [...(i.flagsPrev || [])], r = String(i.resposta || '').replace(/⟦[^⟧]*⟧/g, '').trim(), rn = nrm(r), ex = i.exec || execVazio(), an = i.analise
  const ult = [...(i.hist || [])].reverse().find((m) => m.role === 'assistant')?.content || ''
  let precisao = 100, coerencia = 100, naturalidade = 100, clareza = 100, contexto = 100, resolucao = 100
  const f = (k: string) => { if (!flags.includes(k)) flags.push(k) }
  if (flags.includes('acao_nao_confirmada')) precisao -= 40
  if (flags.includes('falha_omitida')) { precisao -= 30; coerencia -= 20 }
  if (flags.includes('link_nao_verificado')) precisao -= 30
  if (flags.includes('afirmacao_sem_fonte')) precisao -= 15
  if (ex.falhas.length && !falaDeFalha.test(r) && !ex.escritas.length) { coerencia -= 25; f('falha_nao_reconhecida') }
  if (ult && norm(ult) === norm(r) && r.length > 12) { coerencia -= 25; f('resposta_repetida') }
  if (r.length > 40 && (rn.match(/\b(the|and|you|your|with|this|that|have|please)\b/g) || []).length >= 5 && !/\b(de|que|para|voce|com)\b/.test(rn)) { coerencia -= 30; f('idioma_fora_do_padrao') }
  for (const re of ROBOTICO) if (re.test(r)) { naturalidade -= 20; f('tom_robotico') }
  const ab = rn.match(REPETIDOS), prevAb = nrm(ult).match(REPETIDOS); if (ab && prevAb && norm(ab[1]) === norm(prevAb[1])) { naturalidade -= 15; f('abertura_repetida') }
  if ((r.match(/(^|\n)\s*([-*•]|\d+[.)])\s/g) || []).length >= 4 && an.extensao === 'curta' && an.tipo !== 'comando') { naturalidade -= 10; f('lista_desnecessaria') }
  if (!r) { clareza -= 60; resolucao -= 60; f('resposta_vazia') }
  if (an.extensao === 'curta' && r.length > 700 && an.tipo !== 'desabafo') { clareza -= 15; f('resposta_longa_demais') }
  const fr = frases(r); if (fr.length && r.split(/\s+/).length / fr.length > 38) { clareza -= 15; f('frases_longas') }
  if (r.length > 900 && !/\n/.test(r)) { clareza -= 10; f('bloco_unico') }
  const slotsConhecidos: Slots = Object.assign({}, ...[...(i.hist || []).filter((m) => m.role === 'user' && m.content).slice(-6).map((m) => slotsDe(String(m.content))), slotsDe(i.texto)])
  const pergunta = frases(r).filter((s) => /\?$/.test(s)).map(nrm).join(' ')
  if ((slotsConhecidos.dia && /\b(qual|que) (dia|data)\b|para que dia/.test(pergunta)) || (slotsConhecidos.hora && /\bque horas?\b|qual (o )?horario/.test(pergunta)) || (slotsConhecidos.valor != null && /\bqual (o )?valor\b|quanto (foi|custou)\b/.test(pergunta))) { contexto -= 25; f('perguntou_o_que_ja_sabia') }
  if (an.completude === 'eliptica' && /\b(como posso ajudar|do que voce esta falando|pode explicar melhor|nao entendi)\b/.test(rn)) { contexto -= 20; f('ignorou_contexto') }
  if (an.tipo === 'comando' && (i.ferramentas || 0) > 0 && i.caminho === 'ia' && !ex.escritas.length && !ex.leituras.length && !ex.cartoes && !/\?/.test(r)) { resolucao -= 20; f('comando_sem_acao') }
  if (i.caminho === 'ia' && (i.ferramentas || 0) > 0 && !ex.leituras.length && !ex.escritas.length && /\b(nao (sei|posso|consigo) (ajudar|responder)|nao tenho (essa )?(informacao|acesso))\b/.test(rn)) { resolucao -= 15; f('desvio_com_ferramentas') }
  if (an.tipo === 'pergunta' && r.length < 3) resolucao -= 40
  const nota = { precisao: clamp(precisao), coerencia: clamp(coerencia), naturalidade: clamp(naturalidade), clareza: clamp(clareza), contexto: clamp(contexto), resolucao: clamp(resolucao) }
  const geral = clamp(nota.precisao * 0.25 + nota.resolucao * 0.2 + nota.coerencia * 0.15 + nota.contexto * 0.15 + nota.clareza * 0.1 + nota.naturalidade * 0.15)
  return { ...nota, geral, flags }
}

export async function registrarAvaliacao(u: SessionUser, convId: string, messageId: number, caminho: string, an: Analise, ql: Qualidade, ajustes: string[]) {
  const { flags, geral, ...scores } = ql
  await q('INSERT INTO cognition_evals (user_id, conversation_id, message_id, path, intent, scores, overall, flags, adjustments, corrected, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',
    [u.id, convId || null, messageId || null, caminho.slice(0, 30), an.tipo, JSON.stringify(scores), geral, JSON.stringify(flags), JSON.stringify(ajustes), false, nowIso()])
}
/** Ponto único usado pelo chat: avalia a resposta entregue e guarda só as notas. Nunca derruba o envio. */
export async function avaliarERegistrar(u: SessionUser, convId: string, messageId: number, i: AvalIn & { ajustes?: string[] }) {
  if (!(await cogCfg()).ativo) return null
  const ql = avaliar(i); await registrarAvaliacao(u, convId, messageId, i.caminho || 'ia', i.analise, ql, i.ajustes || []); return ql
}
/** O usuário corrigiu a resposta anterior: marca a avaliação dela (sinal de aprendizado individual). */
export async function marcarCorrecao(convId: string, userId: number) {
  const r = await one('SELECT MAX(id) AS id FROM cognition_evals WHERE conversation_id = $1 AND user_id = $2', [convId, userId]).catch(() => null)
  if (r?.id) await q('UPDATE cognition_evals SET corrected = $1 WHERE id = $2', [true, Number(r.id)])
}

/* ======================= painel administrativo: números agregados (sem texto, sem nomes) ======================= */
export async function resumoAdmin() {
  const cfg = await cogCfg()
  const total = Number((await one('SELECT COUNT(*) AS n FROM cognition_evals').catch(() => ({ n: 0 })))?.n || 0)
  const rows = await q('SELECT user_id, path, intent, scores, overall, flags, adjustments, corrected, created_at FROM cognition_evals ORDER BY id DESC LIMIT 3000').catch(() => [] as any[])
  const med = (xs: number[]) => (xs.length ? Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) : null)
  const dims = ['precisao', 'coerencia', 'naturalidade', 'clareza', 'contexto', 'resolucao'], medias: Record<string, number | null> = {}
  const sc = rows.map((r: any) => J<any>(r.scores, {}))
  for (const d of dims) medias[d] = med(sc.map((s: any) => Number(s[d])).filter((n: number) => Number.isFinite(n)))
  const flags = new Map<string, number>(), caminhos = new Map<string, number[]>(), dias = new Map<string, number[]>(); let ajustes = 0, corrigidas = 0
  for (const r of rows as any[]) {
    for (const f of J<string[]>(r.flags, [])) flags.set(f, (flags.get(f) || 0) + 1)
    if (J<string[]>(r.adjustments, []).length) ajustes++
    if (r.corrected === true || r.corrected === 1 || r.corrected === 't' || r.corrected === 'true') corrigidas++
    const p = String(r.path || 'ia'); caminhos.set(p, [...(caminhos.get(p) || []), Number(r.overall)])
    const d = String(r.created_at).slice(0, 10); dias.set(d, [...(dias.get(d) || []), Number(r.overall)])
  }
  return {
    ativo: cfg.ativo, config: { ativo: cfg.ativo, humanizar: cfg.humanizar, guardaAcoes: cfg.guardaAcoes, portaoSensivel: cfg.portaoSensivel }, atualizadoEm: cfg.atualizadoEm || null,
    total, amostra: rows.length, usuarios: new Set((rows as any[]).map((r) => Number(r.user_id))).size, geral: med((rows as any[]).map((r) => Number(r.overall))), medias, ajustesAutomaticos: ajustes, corrigidasPeloUsuario: corrigidas,
    sinalizacoes: [...flags].sort((a, b) => b[1] - a[1]).slice(0, 12).map(([flag, n]) => ({ flag, n })),
    porCaminho: [...caminhos].map(([caminho, v]) => ({ caminho, n: v.length, media: med(v) })).sort((a, b) => b.n - a.n),
    tendencia: [...dias].sort((a, b) => a[0].localeCompare(b[0])).slice(-14).map(([dia, v]) => ({ dia, n: v.length, media: med(v) })),
  }
}
