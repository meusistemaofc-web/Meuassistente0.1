// Analista de negócios no Chat Principal: a IA responde com dados REAIS da empresa do dono por lib/bi.ts (somente leitura).
// Permissão e isolamento são validados no serviço (dono da empresa); a IA nunca recebe dados de outra empresa nem escreve nada.
import { settingsOf } from '../lib/account.js'
import * as B from '../lib/bi.js'
import { HttpError } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import type { ToolDef } from './provider.js'

const emp = { type: 'string', description: 'nome da empresa (só se o usuário tiver mais de uma)' }
const per = { type: 'string', enum: B.PERIODOS, description: 'período consultado; padrão "mes". "semana" = segunda até hoje' }
const de = { type: 'string', description: 'AAAA-MM-DD (use com periodo "personalizado")' }
const props = { empresa: emp, periodo: per, de, ate: { type: 'string', description: 'AAAA-MM-DD' } }
export const NEGOCIO_TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'negocio_resumo', description: 'Dados REAIS da empresa do usuário no período: faturamento (vendas pagas), bruto, pendente, cancelado, pedidos (pendentes/concluídos/cancelados), agendamentos, clientes novos e recorrentes, acessos, produtos e serviços mais pedidos, cupons/MCoins, receitas e despesas do módulo Finanças, melhor dia e horários de movimento. Use para "quanto vendi", "quantos pedidos pendentes", "como está minha empresa", "melhor dia de vendas".', parameters: { type: 'object', properties: props } } },
  { type: 'function', function: { name: 'negocio_comparar', description: 'Compara o período com o anterior (ou com outro intervalo) em faturamento, pedidos, clientes, agendamentos e visitas, com variação absoluta e percentual. Use para "compare esta semana com a passada".', parameters: { type: 'object', properties: { ...props, contra_de: { type: 'string', description: 'AAAA-MM-DD início do período de comparação (opcional)' }, contra_ate: { type: 'string', description: 'AAAA-MM-DD fim do período de comparação (opcional)' } } } } },
  { type: 'function', function: { name: 'negocio_analise', description: 'Análise do desempenho: tendências (alta/queda), alertas, oportunidades e sugestões, cada uma com o critério e os números usados. Use para "como está o desempenho", "o que posso melhorar".', parameters: { type: 'object', properties: props } } }
]
export const NEGOCIO_NAMES = new Set(NEGOCIO_TOOLS.map((t) => t.function.name))
export const NEGOCIO_READ = NEGOCIO_NAMES // somente leitura: pode repetir sem efeito colateral

const nrm = (s: any) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()
export const negocioDisponivel = async (u: SessionUser) => (await B.empresasBI(u.id)).length > 0
async function escolher(u: SessionUser, nome?: string) {
  const l = await B.empresasBI(u.id); if (!l.length) return { erro: 'Você não tem empresa ativa cadastrada. Os relatórios empresariais são só para donos de empresa.' }
  if (nome) { const m = l.filter((e) => nrm(e.nome).includes(nrm(nome))); if (m.length === 1) return { e: m[0] }; return { erro: `Não identifiquei a empresa "${nome}". Empresas: ${l.map((e) => e.nome).join(', ')}.` } }
  if (l.length === 1) return { e: l[0] }
  return { erro: `Qual empresa? ${l.map((e) => e.nome).join(', ')}.` }
}
/** O cartão do chat (⟦neg:…⟧) busca os mesmos números na API, então sempre mostra o dado real e atual. */
export const token = (bid: number, tipo: 'resumo' | 'comparar' | 'analise', p: B.Per | { periodo?: string; de?: string; ate?: string }) => `⟦neg:${bid}|${tipo}|${(p as any).id || (p as any).periodo || 'mes'}|${(p as any).de || ''}|${(p as any).ate || ''}⟧`

export async function runNegocioTool(u: SessionUser, name: string, a: any): Promise<any> {
  const p = await escolher(u, a.empresa); if (!p.e) return { ok: false, error: p.erro }
  const tz = settingsOf(u).timezone, spec = { periodo: a.periodo, de: a.de, ate: a.ate }
  try {
    if (name === 'negocio_resumo') { const r = B.publico(await B.resumo(u.id, p.e.id, spec, tz)); return { ok: true, ...r, serie: r.serie.length > 31 ? undefined : r.serie, cartao: token(p.e.id, 'resumo', { ...spec, periodo: r.periodo.id, de: spec.de, ate: spec.ate }) } }
    if (name === 'negocio_comparar') { const r = await B.comparar(u.id, p.e.id, { ...spec, contra: a.contra_de && a.contra_ate ? { de: a.contra_de, ate: a.contra_ate } : undefined }, tz); return { ok: true, ...r, cartao: token(p.e.id, 'comparar', spec) } }
    if (name === 'negocio_analise') { const r = await B.analise(u.id, p.e.id, spec, tz); return { ok: true, ...r, serie: undefined, cartao: token(p.e.id, 'analise', spec) } }
    return { ok: false, error: 'Ferramenta desconhecida.' }
  } catch (e: any) { return { ok: false, error: e instanceof HttpError ? e.message : 'Falha ao consultar os dados da empresa.' } }
}

/** Instruções curtas: números só das ferramentas, com período, sem inventar; "sem dados" ≠ zero. */
export async function negocioContext(u: SessionUser): Promise<string> {
  const l = await B.empresasBI(u.id); if (!l.length) return ''
  return 'ANÁLISE DE NEGÓCIO (ferramentas negocio_*): você é o analista da(s) empresa(s) do usuário: ' + l.slice(0, 5).map((e) => e.nome).join(', ') + '. Para vendas, faturamento, pedidos, clientes, acessos, agendamentos, produtos mais vendidos, finanças ou desempenho, CHAME a ferramenta e responda só com o que ela devolver. Sempre diga o período (label) e a empresa se houver mais de uma. Diferencie faturamento (vendas pagas), pendente e cancelado. Se um dado vier com disponivel:false, diga que ainda não há esse dado (não é zero). "Mais procurados" = mais pedidos/agendados; não há visualização por produto. Nunca estime nem invente números; sugestões devem vir de "tendencias" ou ser genéricas e identificadas como sugestão. Não repita o cartão: ele aparece sozinho abaixo da resposta.'
}
