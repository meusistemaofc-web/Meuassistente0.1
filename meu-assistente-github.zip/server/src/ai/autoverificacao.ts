// AUTOVERIFICAÇÃO — antes de entregar respostas IMPORTANTES (ações, finanças, negócio, pedidos em etapas, várias
// perguntas, respostas longas), confere completude, valores contra os dados das ferramentas, etapas omitidas,
// clareza e repetição. Problemas leves são corrigidos de forma determinística; problemas de conteúdo podem ganhar
// UMA revisão pela própria IA (sem ferramentas, dentro do prazo) — a versão revisada só é aceita se for melhor.
import type { Analise, Exec } from './cognition.js'
import type { Plano } from './planejador.js'
import { pendentes } from './planejador.js'
import { repetidas } from './memoria.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const STOP = new Set('qual quais quando onde como quanto quantos quantas quem porque por que voce pode poderia sobre esta esse essa isso minha meu tenho tem para pra com uma umas uns dos das que'.split(' '))
export interface Problema { tipo: 'incompleta' | 'valor_divergente' | 'etapa_omitida' | 'pouco_clara' | 'repeticao'; detalhe: string }

export function importante(o: { an: Analise; exec: Exec; plano: Plano | null; especialistas: string[]; resposta: string; texto: string }): boolean {
  return o.exec.escritas.length > 0 || o.exec.falhas.length > 0 || (o.plano?.etapas.length || 0) >= 2 || o.especialistas.some((e) => ['financas', 'negocio', 'crm', 'agenda_empresa'].includes(e))
    || o.an.tipo === 'comando' || o.resposta.length > 600 || (String(o.texto).match(/\?/g) || []).length >= 2
}

/** Números citados como dinheiro na resposta precisam existir nos dados (ou ser soma/diferença de dois deles). */
const numerosDe = (t: string) => {
  const out: number[] = []
  for (const m of String(t).matchAll(/(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/g)) {
    const raw = m[1]; const n = /,\d{1,2}$/.test(raw) || /\.\d{3}/.test(raw) ? parseFloat(raw.replace(/\./g, '').replace(',', '.')) : parseFloat(raw.replace(',', '.'))
    if (Number.isFinite(n)) out.push(Math.round(n * 100) / 100)
  }
  return out
}
export function valoresDivergentes(resposta: string, fontes: string): string[] {
  const citados = [...String(resposta).matchAll(/R\$\s?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/g)].map((m) => numerosDe(m[1])[0]).filter((n) => n != null)
  if (!citados.length) return []
  const base = [...new Set(numerosDe(fontes))].slice(0, 300), ok = new Set(base.map((n) => n.toFixed(2)))
  const conferem = (v: number) => { if (ok.has(v.toFixed(2))) return true; for (let i = 0; i < base.length; i++) for (let j = i; j < base.length; j++) { const s = base[i] + base[j], d = Math.abs(base[i] - base[j]); if (Math.abs(s - v) < 0.011 || Math.abs(d - v) < 0.011) return true } return false }
  return [...new Set(citados.filter((v) => !conferem(v)).map((v) => 'R$ ' + v.toFixed(2).replace('.', ',')))]
}
/** Várias perguntas na mesma mensagem: cada uma precisa ter sido tratada na resposta. */
export function perguntasSemResposta(texto: string, resposta: string): string[] {
  const perguntas = String(texto).split(/(?<=\?)/).map((x) => x.trim()).filter((x) => /\?$/.test(x) && x.length > 4)
  if (perguntas.length < 2) return []
  const r = nrm(resposta)
  return perguntas.filter((p) => { const ch = nrm(p).replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !STOP.has(w)); return ch.length > 0 && !ch.some((w) => r.includes(w.slice(0, Math.max(4, Math.min(6, w.length - 1))))) })
}

export function verificar(o: { texto: string; resposta: string; fontes: string; plano: Plano | null; especialistas: string[]; exec: Exec; anteriores: string[]; clareza?: number }): Problema[] {
  const P: Problema[] = []
  for (const q of perguntasSemResposta(o.texto, o.resposta)) P.push({ tipo: 'incompleta', detalhe: `a pergunta "${q.slice(0, 100)}" não foi respondida` })
  if (o.exec.leituras.length || o.especialistas.some((e) => ['financas', 'negocio'].includes(e))) for (const v of valoresDivergentes(o.resposta, o.fontes)) P.push({ tipo: 'valor_divergente', detalhe: `o valor ${v} não aparece nos dados consultados` })
  const pend = pendentes(o.plano), r = nrm(o.resposta)
  for (const e of pend) if (e.status === 'falhou' && !/(nao consegui|nao foi possivel|falh|erro)/.test(r)) P.push({ tipo: 'etapa_omitida', detalhe: `a etapa "${e.acao}" falhou e a resposta não diz isso` })
  if ((o.clareza ?? 100) < 70) P.push({ tipo: 'pouco_clara', detalhe: 'a resposta está longa ou confusa para o que foi pedido' })
  for (const f of repetidas(o.resposta, o.anteriores)) P.push({ tipo: 'repeticao', detalhe: `repete "${f.slice(0, 60)}…" já dito antes` })
  return P
}
/** Correções determinísticas (sem IA): tira frases repetidas sem perder o resto. */
export function corrigirLocal(resposta: string, P: Problema[], anteriores: string[]): string {
  if (!P.some((p) => p.tipo === 'repeticao')) return resposta
  const rep = new Set(repetidas(resposta, anteriores))
  const out = String(resposta).split(/(?<=[.!?])\s+/).filter((f) => !rep.has(f)).join(' ').trim()
  return out.length >= 12 ? out : resposta
}
/** Problemas que pedem revisão pela IA (conteúdo), não só limpeza. */
export const precisaRevisao = (P: Problema[]) => P.some((p) => ['incompleta', 'valor_divergente', 'pouco_clara'].includes(p.tipo))
export function pedidoRevisao(P: Problema[], idioma = 'português do Brasil'): string {
  return `[REVISÃO INTERNA — não é mensagem do usuário] Antes de entregar, corrija a resposta anterior: ${P.filter((p) => p.tipo !== 'repeticao').map((p) => p.detalhe).join('; ')}. Reescreva a resposta COMPLETA ao usuário, em ${idioma}, sem mencionar esta revisão, sem inventar dados (use só os números das ferramentas e da conversa) e mantendo o que estava correto. Se faltar dado para responder algo, diga isso com clareza.`
}
