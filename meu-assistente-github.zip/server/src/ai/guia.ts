// MODO EXPLICATIVO + INTELIGÊNCIA CONTEXTUAL do chat principal.
//
// • classificar(): separa PEDIDO DE EXECUÇÃO ("registra 50 no mercado"), PEDIDO DE EXPLICAÇÃO ("como registro um gasto?"),
//   PERGUNTA GERAL ("qual a capital da França?") e CONVERSA ("oi", "obrigado"), em português, inglês, espanhol, francês,
//   italiano e alemão.
// • Explicação sobre um recurso do app → resposta curta, natural e em passos, montada a partir do CATÁLOGO REAL (telas,
//   botões e comandos que existem de fato), conferido na hora contra a configuração (módulos ligados pelo administrador,
//   se o usuário tem empresa, memória ligada). Recurso desligado → diz que está desligado. Nada é executado.
// • Se o chat consegue fazer a ação, a resposta oferece ("Quer que eu registre agora?"); o "sim" seguinte é atendido:
//   pede os dados que faltam ou já abre o fluxo (ex.: Modo Busca).
// • Explicação sobre algo que não está no catálogo vai para a IA com a lista de funcionalidades reais e sem ferramentas
//   de escrita (contextoIA): ela explica o que existe e diz com honestidade quando o app não tem o recurso.
// Os textos são escritos em português; o chat traduz para o idioma da resposta (idioma.ts).
import type { SessionUser } from '../lib/session.js'
import { one } from '../db/index.js'
const totalMsgs = async (convId: string, userId: number) => Number((await one('SELECT COUNT(*) AS n FROM messages WHERE conversation_id = $1 AND user_id = $2', [convId, userId]))?.n || 0)

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[“”"]/g, '').replace(/\s+/g, ' ').trim()

// ---------- classificação do pedido ----------
export type TipoPedido = 'explicacao' | 'execucao' | 'geral' | 'conversa'
const ONDE_PT = /\bonde( (e|que))?( eu| a gente| se)? (vej[oa]|ver|fica|ficam|acesso|acessar|configur\w*|mud[oa]|mudar|alter\w*|troc[oa]|trocar|acompanh\w*|cadastr\w*|ativ\w*|deslig\w*|apag\w*)\b/
const COMO_PT = /\b(como|de que (jeito|forma|maneira))( (e|que) )?( eu| a gente| se| que)? (fa[cç]o|faz|fazer|posso|consigo|devo|uso|usar|utilizo|cri[oa]r?|cadastr\w*|registr\w*|agend\w*|marc\w*|lan[cç]\w*|anot\w*|adicion\w*|coloc\w*|vej[oa]|ver|acess\w*|ativ\w*|desativ\w*|lig[ao]|deslig\w*|apag\w*|exclu\w*|remov\w*|edit\w*|mud[oa]|mudar|alter\w*|troc\w*|configur\w*|compartilh\w*|busc\w*|procur\w*|encontr\w*|pe[cç]o|pedir|compr\w*|pag[oa]|pagar|cancel\w*|salv\w*|envi\w*|mand\w*|acompanh\w*|anunci\w*|ach[oa]|fica|ficam|funciona\w*|defin\w*|escolh\w*|recebo|receber|guard\w*|program\w*|reserv\w*)\b/
const COMO_OUTROS = [
  /\b(como funciona(m)?|pra que serve|para que serve|qual (e )?o passo a passo|passo a passo (para|pra|de)|o que (eu )?(preciso|tenho que|devo) fazer (para|pra)|me (ensina|explica|mostra) (a |como )|(tem|teria) como|da pra|e possivel|existe (alguma )?(forma|opcao|jeito) de)\b/,
  /\b(how (do|can|should|would) (i|we|you)|how to|how does .{1,40} work|where (do|can) i|can i|is it possible to|is there a way to|walk me through|teach me (how )?to|what do i (need|have) to do to|show me how)\b/,
  /\b(como (puedo|hago|se hace|registro|agendo|creo|veo|busco|anoto|uso|funciona|cambio|pido|compro)|donde (veo|esta|encuentro)|se puede|hay (alguna )?forma de|me explicas como)\b/,
  /\b(comment (je |puis-je|faire|on|ca marche|fonctionne|ajouter|creer)|ou (je )?(trouve|vois)|est-ce que je peux)\b/,
  /\b(come (faccio|posso|si fa|funziona)|dove (trovo|vedo)|posso (fare|usare|aggiungere|creare))\b/,
  /\b(wie (kann ich|mache ich|funktioniert|erstelle ich)|wo (finde|sehe) ich|kann ich)\b/,
]
const EXECUTA = /^(por favor |pfv |pode |me )?(registr\w*|anot\w*|agend\w*|marc\w*|cri[ea]\w*|adicion\w*|coloc\w*|lembr[ae]\w*|lanc\w*|salv\w*|apag\w*|exclu\w*|remov\w*|cancel\w*|mostr\w*|abr[ae]\w*|busc\w*|procur\w*|encontr\w*|ativ\w*|desativ\w*|gastei|paguei|recebi|comprei|quero (encontrar|comprar|agendar|marcar|registrar|anotar)|preciso (encontrar|comprar|agendar|marcar|registrar)|add|create|schedule|remind me|set a reminder|register|log|save|delete|cancel|find|show|i spent|i paid|i received|registra|recuerdame|agenda|crea|anota|guarda)\b/
const CONVERSA = /^(oi+|ola|ol[aá]|bom dia|boa tarde|boa noite|tudo bem|e ai|obrigad[oa]|valeu|beleza|blz|ok|okay|certo|tchau|ate (mais|logo)|hi|hello|hey|thanks|thank you|good (morning|afternoon|evening|night)|bye|hola|buenos dias|buenas (tardes|noches)|gracias|adios|bonjour|merci|salut|ciao|grazie|hallo|danke)\b[\s!.,?¿¡]*([a-z]+[\s!.,?¿¡]*){0,3}$/

const POLIDO = /^(tem como|teria como|da pra|daria pra|voce (pode|poderia|consegue)|vc (pode|consegue)|pode|poderia|consegue|can you|could you|would you|please|puedes|podrias|pourrais-tu|pouvez-vous|puoi|kannst du|konnen sie)\b/
const DETALHES = /\d|\b(hoje|amanha|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|semana que vem|today|tomorrow|tonight|monday|tuesday|wednesday|thursday|friday|saturday|sunday|next week|manana|lunes|martes|demain|domani|morgen)\b|:/
export function ehPedidoDeExplicacao(texto: string) {
  const s = nrm(texto); if (!s || s.length > 220) return false
  return COMO_PT.test(s) || ONDE_PT.test(s) || COMO_OUTROS.some((re) => re.test(s))
}
export function classificar(texto: string): TipoPedido {
  const s = nrm(texto)
  if (!s) return 'conversa'
  // pedido educado com os dados da ação ("tem como me lembrar de pagar a luz amanhã às 9h?", "can you remind me tomorrow at 9?")
  // é pedido para FAZER, não para explicar; "como eu registro…" (1ª pessoa) continua sendo explicação
  if (POLIDO.test(s) && DETALHES.test(s)) return 'execucao'
  if (ehPedidoDeExplicacao(texto)) return 'explicacao'
  if (CONVERSA.test(s)) return 'conversa'
  if (EXECUTA.test(s)) return 'execucao'
  return 'geral'
}

// ---------- catálogo real de funcionalidades ----------
interface Estado { mod: Record<string, boolean>; temEmpresa: boolean; memoria: boolean; modos: boolean }
interface Topico {
  id: string
  titulo: string // "registrar um gasto" — completa "Para …"
  termos: RegExp
  disponivel?: (e: Estado) => true | string // texto = motivo de não estar disponível
  passos: (e: Estado) => string[]
  chat?: string // frase de exemplo que o chat executa de verdade
  tela?: (e: Estado) => { rota: string; rotulo: string } | null
  oferta?: { pergunta: string; acao?: 'pergunta' | 'modo_busca'; convite: string } // o que fazer com o "sim"
}
// O menu é organizado por cada usuário (☰ → Módulos → Organizar módulos), então o primeiro passo é sempre o botão que abre a
// tela exata (vai junto na resposta); o caminho no menu é citado como ele vem por padrão.
const NA_PASTA = (tela: string) => `Toque em “Abrir ${tela}” aqui embaixo, ou abra o menu ☰ → Módulos → ${tela}.`
const FORA_DO_MENU = (tela: string) => `Toque em “Abrir ${tela}” aqui embaixo (para deixar ${tela} no menu ☰, use Módulos → Organizar módulos).`
const NO_MENU = (tela: string, botao = 'Abrir ' + tela) => `Abra o menu ☰ e toque em ${tela} (ou em “${botao}” aqui embaixo).`
const off = (nome: string) => `${nome} está desligado no momento pelo administrador do app, então não dá para usar agora.`
const fin = (e: Estado) => e.mod.financas !== false || off('O módulo Finanças')
const emp = (e: Estado) => (e.mod.empresas !== false && e.mod.catalogo !== false) || off('A área de empresas e lojas')

export const TOPICOS: Topico[] = [
  { id: 'idioma', titulo: 'mudar o idioma das respostas', termos: /\b(idioma|lingua|language|idiomas?|langue|sprache)\b/,
    passos: () => ['Escreva no chat, por exemplo: “sempre me responda em inglês” (ou espanhol, francês, italiano, alemão, português).', 'Eu guardo essa preferência na sua memória e passo a responder nesse idioma em todas as conversas.', 'Para voltar a responder no idioma em que você escrever, diga: “responda no idioma em que eu escrever”.'],
    tela: () => ({ rota: '/perfil', rotulo: 'Abrir Memória do assistente' }) },
  { id: 'memoria', titulo: 'fazer o assistente lembrar de algo sobre você', termos: /\b(memoria|lembr\w* (de )?que (eu|meu|minha|sou|tenho)|lembrar de mim|lembre (de )?mim|guardar (uma )?informac\w*|saber (sobre|de) mim|remember (things|me|that)|memory|recuerd\w* (de mi|que)|memoire|ricord\w* (di me|che))\b/,
    disponivel: (e) => e.memoria || 'A memória do assistente está desligada nas suas configurações. Ligue em Perfil → Memória do assistente para usar.',
    passos: () => ['Escreva no chat o que quer que eu guarde, por exemplo: “lembre que eu prefiro café sem açúcar”.', 'Para ver, editar ou apagar o que eu guardei, toque em “Abrir Memória do assistente” aqui embaixo (ou no menu ☰ → engrenagem de Configurações → Memória do assistente).'],
    tela: () => ({ rota: '/perfil', rotulo: 'Abrir Memória do assistente' }) },
  { id: 'anexos', titulo: 'enviar foto, documento ou áudio no chat', termos: /\b(foto|fotos|imagem|imagens|documento|pdf|arquivo|audio|voz|microfone|print|comprovante|nota fiscal|photo|picture|image|document|file|voice|audio|foto|imagen|archivo|fichier|immagine|bild|datei)\b/,
    disponivel: (e) => (e.mod.imagens !== false || e.mod.voz !== false) || off('O envio de fotos, documentos e áudio'),
    passos: (e) => [...(e.mod.imagens !== false ? ['Para foto ou PDF: toque no + (Anexar), à esquerda do campo de mensagem, e escolha o arquivo.'] : []), ...(e.mod.voz !== false ? ['Para áudio: toque no microfone 🎤, à direita do campo de mensagem, fale e envie.'] : []), 'Se quiser, escreva junto o que precisa (ex.: “registre este comprovante”): eu leio o conteúdo e respondo.'] },
  { id: 'modos', titulo: 'usar os Modos Inteligentes', termos: /\b(modos? (inteligentes?|de busca|consultor)|consultor de marketing|botao do raio|⚡|smart modes?)\b/,
    disponivel: (e) => e.modos || off('Os Modos Inteligentes'),
    passos: () => ['Toque no botão Modos inteligentes (⚡), ao lado do campo de mensagem.', 'Escolha o modo (por exemplo, Busca de produtos e serviços ou Consultor de Marketing).', 'Converse normalmente; para sair, toque no ⚡ de novo ou diga “sair do modo”.'] },
  { id: 'conta', titulo: 'cadastrar uma conta a pagar', termos: /\b(conta a pagar|contas a pagar|boleto|boletos|vencimento|conta de (luz|agua|internet|telefone|gas|aluguel)|fatura|bill|bills|factura|facture|bolletta|rechnung)\b/, disponivel: fin,
    passos: () => ['Toque em “Abrir Contas” aqui embaixo (ou abra Financeiro e escolha a aba Contas).', 'Toque em + Adicionar.', 'Preencha o nome da conta, o valor e o vencimento (dá para marcar se repete) e confirme.'],
    chat: 'conta de luz de 150 reais vence dia 10', tela: () => ({ rota: '/financeiro?tab=contas', rotulo: 'Abrir Contas' }),
    oferta: { pergunta: 'Certo! Me diga a conta, o valor e o vencimento, por exemplo: “conta de luz de 150 reais vence dia 10”.', convite: 'Quer que eu cadastre uma agora?' } },
  { id: 'receita', titulo: 'registrar uma receita (dinheiro que entrou)', termos: /\b(receita|receitas|recebimento|entrada de dinheiro|dinheiro que (entrou|recebi)|salario|income|ingreso|ingresos|revenu|entrata|einnahme)\b/, disponivel: fin,
    passos: () => [NA_PASTA('Financeiro'), 'Toque em + Adicionar e escolha Receita.', 'Preencha o valor, a descrição e a categoria e confirme.'],
    chat: 'recebi 2000 de salário', tela: () => ({ rota: '/financeiro', rotulo: 'Abrir Financeiro' }),
    oferta: { pergunta: 'Certo! Me diga quanto entrou e de onde, por exemplo: “recebi 2000 de salário”.', convite: 'Quer que eu registre uma agora?' } },
  { id: 'resumo', titulo: 'ver quanto você gastou', termos: /\b(quanto (eu )?gast\w*|resumo financeiro|meus gastos do mes|relatorio|extrato|saldo|how much (did )?i spen[dt]|cuanto gaste|combien j'ai depense)\b/, disponivel: fin,
    passos: () => [NA_PASTA('Financeiro'), 'O resumo do mês, os gráficos e os lançamentos ficam lá; use as setas para trocar de mês.'],
    chat: 'quanto gastei este mês?', tela: () => ({ rota: '/financeiro', rotulo: 'Abrir Financeiro' }) },
  { id: 'gasto', titulo: 'registrar um gasto', termos: /\b(gasto|gastos|despesa|despesas|lancamento|lancar|gastei|expense|expenses|spending|spent|gasto|gastos|depense|depenses|spesa|spese|ausgabe|ausgaben)\b/, disponivel: fin,
    passos: () => [NA_PASTA('Financeiro'), 'Toque em + Adicionar e escolha Gasto.', 'Preencha o valor, a descrição e a categoria e confirme.'],
    chat: 'gastei 35 no almoço', tela: () => ({ rota: '/financeiro', rotulo: 'Abrir Financeiro' }),
    oferta: { pergunta: 'Certo! Me diga o valor e com o que foi, por exemplo: “gastei 35 no almoço”.', convite: 'Quer que eu registre um agora?' } },
  { id: 'lembrete', titulo: 'criar um lembrete', termos: /\b(lembrete|lembretes|lembrar|me lembr\w*|aviso|alarme|despertador|remind\w*|recordatorio|recordar|rappel|promemoria|erinnerung)\b/,
    disponivel: (e) => e.mod.lembretes !== false || off('O módulo Lembretes'),
    passos: () => [NA_PASTA('Lembretes'), 'Toque em + Lembrete.', 'Escreva o que lembrar, escolha a data e o horário (e se repete) e confirme.'],
    chat: 'me lembra de pagar a luz amanhã às 9h', tela: () => ({ rota: '/agenda?tab=lembretes', rotulo: 'Abrir Lembretes' }),
    oferta: { pergunta: 'Certo! Me diga o que e quando, por exemplo: “me lembra de pagar a luz amanhã às 9h”.', convite: 'Quer que eu crie um agora?' } },
  { id: 'agenda', titulo: 'ver a sua agenda', termos: /\b(minha agenda|meu dia|o que (eu )?tenho (hoje|amanha)|ver (a |minha )?agenda|my (agenda|schedule|day)|mi agenda)\b/,
    passos: () => [FORA_DO_MENU('Meu Dia') + ' Lá fica o resumo de hoje: compromissos, tarefas, contas e lembretes.', 'Pelo chat é só perguntar, por exemplo: “o que tenho amanhã?”.'],
    chat: 'o que tenho amanhã?', tela: () => ({ rota: '/meu-dia', rotulo: 'Abrir Meu Dia' }) },
  { id: 'servico_loja', titulo: 'agendar um serviço numa empresa', termos: /\b(agend\w*|marc\w*|reserv\w*|book\w*|cita|reservar)\b.*\b(salao|barbearia|barbeiro|manicure|clinica|loja|empresa|servico|estetica|petshop|pet shop|consultorio|salon|barber|shop|business|tienda|peluqueria)\b/,
    disponivel: emp,
    passos: () => ['Escreva no chat o serviço que procura, por exemplo: “procuro manicure perto de mim”.', 'No cartão do serviço, toque em Agendar.', 'Escolha o dia e o horário e toque em Confirmar agendamento; ele aparece em Meus pedidos.'],
    chat: 'procuro manicure perto de mim', oferta: { pergunta: '', acao: 'modo_busca', convite: 'Quer que eu procure o serviço agora?' } },
  { id: 'compromisso', titulo: 'agendar um compromisso', termos: /\b(compromisso|compromissos|agend\w*|marcar|marco|consulta|reuniao|evento|appointment|appointments|meeting|schedule|cita|citas|reunion|rendez-vous|appuntamento|termin)\b/,
    passos: () => [FORA_DO_MENU('Compromissos'), 'Toque em + Compromisso.', 'Preencha o título, a data e o horário (pessoa, local e aviso antes são opcionais) e confirme.'],
    chat: 'dentista amanhã às 14h', tela: () => ({ rota: '/agenda?tab=compromissos', rotulo: 'Abrir Compromissos' }),
    oferta: { pergunta: 'Certo! Me diga o que é, o dia e o horário, por exemplo: “dentista amanhã às 14h”.', convite: 'Quer que eu agende um agora?' } },
  { id: 'tarefa', titulo: 'criar uma tarefa', termos: /\b(tarefa|tarefas|afazer|afazeres|to ?do|task|tasks|tarea|tareas|tache|taches|compito|aufgabe)\b/,
    passos: () => [FORA_DO_MENU('Tarefas'), 'Escreva a tarefa no campo Nova tarefa… e toque em +.', 'Depois, mude a situação para Em andamento ou Concluída quando avançar.'],
    chat: 'cria a tarefa enviar o orçamento', tela: () => ({ rota: '/agenda?tab=tarefas', rotulo: 'Abrir Tarefas' }),
    oferta: { pergunta: 'Certo! Qual é a tarefa? Por exemplo: “cria a tarefa enviar o orçamento até sexta”.', convite: 'Quer que eu crie uma agora?' } },
  { id: 'compras', titulo: 'usar a lista de compras', termos: /\b(lista de compras?|lista do mercado|lista de mercado|shopping list|grocery list|lista de la compra|liste de courses|lista della spesa|einkaufsliste)\b/,
    passos: () => [NA_PASTA('Compras'), 'Escreva os itens no campo Adicionar itens (separe por vírgula) e toque em +.', 'Toque no item para marcar como comprado.'],
    chat: 'adiciona leite, pão e café na lista de compras', tela: () => ({ rota: '/agenda?tab=compras', rotulo: 'Abrir Compras' }),
    oferta: { pergunta: 'Certo! Quais itens? Por exemplo: “adiciona leite, pão e café na lista de compras”.', convite: 'Quer que eu adicione itens agora?' } },
  { id: 'anotacao', titulo: 'fazer uma anotação', termos: /\b(anot\w*|nota|notas|ideia|ideias|bloco de notas|note|notes|apunte|apuntes|nota|appunti|notiz)\b/,
    passos: () => [NA_PASTA('Anotações'), 'Escreva no campo Escreva uma anotação… e toque em +.'],
    chat: 'anota: ideia de presente para a Ana', tela: () => ({ rota: '/agenda?tab=notas', rotulo: 'Abrir Anotações' }),
    oferta: { pergunta: 'Certo! O que eu anoto? Por exemplo: “anota: ideia de presente para a Ana”.', convite: 'Quer que eu anote algo agora?' } },
  { id: 'meus_pedidos', titulo: 'acompanhar seus pedidos', termos: /\b(meus pedidos|meu pedido|status do pedido|acompanh\w* (o |meu |um )?pedido|cancel\w* (o |meu |um )?pedido|my orders?|track (my )?order|mis pedidos|mes commandes)\b/, disponivel: emp,
    passos: () => [NO_MENU('Meus pedidos'), 'Cada pedido mostra a situação (enviado, aceito, em preparo, saiu para entrega ou pronto para retirar) e atualiza sozinho.', 'Para falar com a loja, use o botão de WhatsApp do pedido.'],
    tela: () => ({ rota: '/x/pedidos', rotulo: 'Abrir Meus pedidos' }) },
  { id: 'pedido', titulo: 'fazer um pedido numa loja', termos: /\b(fazer (um )?pedido|faco (um )?pedido|pedir (comida|delivery|numa loja|na loja)|compr\w* (numa|na|em uma|pela|de uma) loja|delivery|entrega em casa|place an order|order (food|from)|hacer un pedido|pedir a domicilio|passer (une )?commande)\b/, disponivel: emp,
    passos: () => ['Abra a loja (pelo chat, pela busca ou em Empresas perto de você).', 'Toque em + nos produtos e depois em Ver pedido.', 'Escolha Entrega (dá para tocar em “Usar minha localização atual”) ou Retirar no local, escolha a forma de pagamento e toque em Enviar pedido.', 'Acompanhe tudo em Meus pedidos.'],
    tela: () => ({ rota: '/x/empresas?modo=produtos', rotulo: 'Ver a vitrine' }) },
  { id: 'anunciar', titulo: 'cadastrar e anunciar a sua empresa', termos: /\b(anunci\w*|cadastr\w* (a |minha |uma )?(empresa|loja|negocio)|vender (no|pelo) app|minha (empresa|loja)|meu catalogo|meus produtos|advertise|list my business|my (business|store|shop)|mi (negocio|tienda)|mon entreprise)\b/,
    disponivel: (e) => e.mod.anuncios !== false || off('O módulo de anúncios'),
    passos: (e) => e.temEmpresa
      ? [NO_MENU('Sua empresa'), 'Lá você edita os dados, o catálogo (produtos e serviços), os pedidos, a página de links e os relatórios.']
      : [NO_MENU('Anunciar minha empresa', 'Anunciar minha empresa'), 'Escolha o plano, preencha os dados da empresa (nome, categoria, endereço, WhatsApp) e envie.', 'Depois da aprovação, a empresa aparece nas buscas e você gerencia tudo em Sua empresa.'],
    tela: (e) => (e.temEmpresa ? { rota: '/x/sua-empresa', rotulo: 'Abrir Sua empresa' } : { rota: '/x/anunciar', rotulo: 'Anunciar minha empresa' }) },
  { id: 'busca', titulo: 'buscar produtos e serviços', termos: /\b(busc\w*|procur\w*|encontr\w*|ach\w*|pesquis\w*|onde compr\w*|find|search|look for|buy|encontrar|buscar|chercher|trouver|cercare|trovare|suchen|finden)\b.*\b(produto|produtos|servico|servicos|loja|lojas|item|itens|coisa|algo|product|products|service|services|productos|servicios|produit|produits|prodotti|produkte)\b|\b(onde compr\w*|where (can i )?buy|donde comprar|ou acheter)\b/, disponivel: emp,
    passos: () => ['Escreva no chat o que procura, por exemplo: “quero encontrar bolo de chocolate” (pode incluir preço: “até 50 reais”).', 'Eu mostro os produtos e serviços das lojas parceiras com foto, preço, empresa e disponibilidade.', 'Toque em Comprar ou Agendar no cartão, ou em Catálogo para ver a loja inteira.'],
    chat: 'quero encontrar bolo de chocolate', tela: () => ({ rota: '/x/empresas?modo=produtos', rotulo: 'Ver a vitrine' }),
    oferta: { pergunta: '', acao: 'modo_busca', convite: 'Quer que eu procure algo agora?' } },
  { id: 'empresas', titulo: 'encontrar empresas perto de você', termos: /\b(empresa|empresas|loja|lojas|estabelecimento|comercio|restaurante|pizzaria|farmacia|perto de mim|por perto|nearby|near me|businesses|stores|cerca de mi|tiendas|pres de moi|vicino a me)\b/, disponivel: (e) => e.mod.empresas !== false || off('A área de empresas'),
    passos: () => [NO_MENU('Empresas perto de você'), 'Permita a localização (ou escolha o lugar) para ver quem atende na sua região.', 'Pelo chat também funciona: escreva, por exemplo, “pizzaria perto de mim”.'],
    chat: 'pizzaria perto de mim', tela: () => ({ rota: '/x/empresas', rotulo: 'Abrir Empresas perto de você' }) },
  { id: 'impostos', titulo: 'acompanhar impostos e o DAS do MEI', termos: /\b(imposto|impostos|das do mei|guia (do )?das|das mei|mei|faturamento anual|limite do mei)\b/, disponivel: (e) => e.mod.fiscal !== false || off('O módulo Impostos'),
    passos: () => [NO_MENU('Impostos e DAS'), 'Lá ficam o DAS do MEI, o faturamento e o limite anual.'],
    tela: () => ({ rota: '/x/impostos', rotulo: 'Abrir Impostos e DAS' }) },
  { id: 'plano', titulo: 'ver ou mudar o seu plano', termos: /\b(plano|planos|assinatura|assinar|limite|limites|upgrade|plan|subscription|suscripcion|abonnement|abbonamento|abo)\b/,
    passos: () => [NO_MENU('Meu plano'), 'Lá aparecem o seu plano, os limites de uso e as opções de assinatura.'],
    tela: () => ({ rota: '/x/planos', rotulo: 'Abrir Meu plano' }) },
  { id: 'notificacoes', titulo: 'ativar as notificações', termos: /\b(notificac\w*|notificar|push|alertas? no celular|notifications?|notificaciones|benachrichtigung\w*)\b/,
    passos: () => [NO_MENU('Notificações'), 'Permita as notificações quando o navegador ou o celular pedir; assim os lembretes chegam mesmo com o app fechado.'],
    tela: () => ({ rota: '/notificacoes', rotulo: 'Abrir Notificações' }) },
  { id: 'mercado', titulo: 'acompanhar cotações', termos: /\b(cotac\w*|dolar|euro|bitcoin|cripto\w*|bolsa|acoes|mercado financeiro|stocks?|crypto|exchange rate|cotizacion)\b/, disponivel: (e) => e.mod.mercado !== false || off('O módulo Mercado'),
    passos: () => [NO_MENU('Mercado'), 'Lá ficam as cotações de cripto e bolsa, os gráficos e os alertas.', 'Pelo chat também dá: pergunte, por exemplo, “quanto está o dólar?”.'],
    chat: 'quanto está o dólar?', tela: () => ({ rota: '/x/mercado', rotulo: 'Abrir Mercado' }) },
]

async function estado(u: SessionUser): Promise<Estado> {
  const { modules } = await import('../lib/usermod.js'), mod = await modules()
  const temEmpresa = !!(await one('SELECT id FROM businesses WHERE owner_id = $1 LIMIT 1', [u.id]).catch(() => null))
  const memoria = (await import('../routes/memory.js')).memSettings(u).enabled !== false
  const modos = await (await import('../modos/index.js')).modosLigados().catch(() => true)
  return { mod, temEmpresa, memoria, modos }
}
/** O tópico do catálogo de que a pergunta trata (o primeiro da lista, que vai do mais específico ao mais geral). */
export function topicoDe(texto: string): Topico | null {
  const s = nrm(texto)
  return TOPICOS.find((t) => t.termos.test(s)) || null
}

/** Resposta do modo explicativo (em português; o chat traduz). null: não é pedido de explicação sobre um recurso do app. */
export async function explicar(u: SessionUser, convId: string, texto: string): Promise<{ content: string; cards: any[]; topico: string } | null> {
  if (!ehPedidoDeExplicacao(texto)) return null
  const t = topicoDe(texto); if (!t) return null
  const e = await estado(u)
  const disp = t.disponivel ? t.disponivel(e) : true
  if (disp !== true) return { content: `${disp}`, cards: [], topico: t.id }
  const passos = t.passos(e), tela = t.tela ? t.tela(e) : null
  const linhas = [`Para ${t.titulo}:`, ...passos.map((p, i) => `${i + 1}. ${p}`)]
  const extra = [t.chat && !passos.some((p) => p.includes(t.chat!)) ? `Pelo chat é ainda mais rápido: é só escrever, por exemplo, “${t.chat}”.` : '', t.oferta ? t.oferta.convite : ''].filter(Boolean).join(' ')
  const content = linhas.join('\n') + (extra ? '\n\n' + extra : '') + (tela ? ` ⟦btn:${tela.rota}|${tela.rotulo}⟧` : '')
  // a oferta vale só para a PRÓXIMA mensagem: guarda quantas mensagens a conversa terá depois desta resposta (pergunta + resposta)
  if (t.oferta && convId) { const C = await import('./convctx.js'); const c = await C.getCtx(convId, u.id); (c as any).guia = { topico: t.id, em: Date.now(), n: (await totalMsgs(convId, u.id)) + 2 }; await C.saveCtx(convId, u.id, c) }
  return { content, cards: [], topico: t.id }
}

const SIM = /^(sim|s|pode|pode sim|pode ser|quero|quero sim|claro|bora|vamos|ok|okay|beleza|isso|faz|faca|manda|por favor|yes|yeah|yep|sure|please|go ahead|ok please|si|claro que si|dale|oui|d'accord|certo|ja|gerne)\b[\s!.,]*(por favor|please|pfv)?[\s!.]*$/
const NAO = /^(nao|n|agora nao|deixa|deixa pra la|depois|no|nope|not now|later|non|nein|ahora no)\b[\s!.,]*(obrigad[oa]|thanks|gracias|merci)?[\s!.]*$/
/** "sim"/"não" logo depois de uma explicação que ofereceu fazer a ação. */
export async function seguirOferta(u: SessionUser, convId: string, texto: string, hist: any[], body: any): Promise<{ content: string; cards: any[]; modo?: boolean } | null> {
  const s = nrm(texto)
  if (!convId || !(SIM.test(s) || NAO.test(s))) return null // só um "sim"/"não" pode responder à oferta (sem consulta extra nas demais mensagens)
  const C = await import('./convctx.js'); const c: any = await C.getCtx(convId, u.id); const g = c.guia
  if (!g) return null
  delete c.guia; await C.saveCtx(convId, u.id, c)
  if (Date.now() - Number(g.em || 0) > 30 * 60000 || (await totalMsgs(convId, u.id)) !== Number(g.n)) return null // houve outra conversa depois da oferta
  const t = TOPICOS.find((x) => x.id === g.topico); if (!t?.oferta) return null
  if (NAO.test(s)) return { content: 'Tudo bem! Quando precisar, é só me chamar.', cards: [] }
  if (t.oferta.acao === 'modo_busca') {
    const r = await (await import('../modos/index.js')).processar(u, convId, '⚡ Busca de produtos e serviços', hist, { ...body, modo: 'busca' }).catch(() => null)
    if (r) return { content: r.content, cards: [], modo: true }
    return { content: 'Me diga o que você procura, por exemplo: “quero encontrar bolo de chocolate”.', cards: [] }
  }
  return { content: t.oferta.pergunta, cards: [] }
}

/** Contexto para a IA conforme o tipo do pedido (explicação sem tópico do catálogo, pergunta geral, conversa). */
export async function contextoIA(u: SessionUser, tipo: TipoPedido): Promise<string> {
  if (tipo === 'explicacao') {
    const e = await estado(u)
    const lista = TOPICOS.filter((t) => !t.disponivel || t.disponivel(e) === true).map((t) => `- ${t.titulo}${t.chat ? ` (pelo chat: “${t.chat}”)` : ''}${t.tela ? ` — tela: ${t.tela(e)?.rotulo}` : ''}`).join('\n')
    return `TIPO DO PEDIDO: EXPLICAÇÃO. O usuário quer saber COMO fazer algo, não pediu para você fazer. Não execute nenhuma ação.\n` +
      `Se a dúvida for sobre o app, explique em até 5 passos curtos e numerados, usando SOMENTE as funcionalidades reais abaixo (telas pelo menu ☰ e comandos do chat). Se o recurso não estiver na lista, diga com honestidade que o app ainda não tem isso — não invente telas, botões ou recursos. Se o chat puder fazer a ação, ofereça fazer ao final.\n` +
      `Se a dúvida não for sobre o app (ex.: uma receita, um conceito), responda normalmente de forma curta.\n` +
      `Nunca mostre JSON, nomes de ferramentas, códigos internos ou termos técnicos.\nFuncionalidades reais disponíveis agora:\n${lista}`
  }
  if (tipo === 'geral') return 'TIPO DO PEDIDO: PERGUNTA GERAL. Responda direto ao que foi perguntado, em até 3 frases curtas, sem rodeios, sem listas desnecessárias e sem oferecer ações que não foram pedidas. Nunca mostre JSON, nomes de ferramentas ou códigos internos.'
  if (tipo === 'conversa') return 'TIPO DO PEDIDO: CONVERSA. Responda em uma frase, de forma calorosa e natural.'
  return ''
}
