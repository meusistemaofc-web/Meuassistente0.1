// Cérebro Central — vetores (embeddings) para busca semântica.
// • "local": vetor de 384 dimensões por "feature hashing" de radicais do português, pares de radicais e trigramas de
//   letras (tolerância a erros de digitação). Roda no próprio servidor, sem rede e sem IA — é SEMPRE calculado, então a
//   busca funciona mesmo com todos os provedores externos desligados. Captura proximidade lexical/morfológica (não
//   "entende" sinônimos distantes como um modelo neural).
// • "ollama": modelo de embeddings local do Ollama (ex.: nomic-embed-text), via /api/embed.
// • "gemini": text-embedding-004 (ou outro) via API oficial do Google, com a chave cifrada do painel.
// Os vetores ficam em knowledge_embeddings (JSON). Sem pgvector, a similaridade (cosseno) é calculada em memória.
import { createHash } from 'node:crypto'
import { termos, nrm } from '../semantica.js'

export const LOCAL = { provider: 'local', model: 'hash-384-v1', dim: 384 }
const h32 = (s: string) => createHash('md5').update(s).digest().readUInt32LE(0)
export function vetorLocal(texto: string): number[] {
  const v = new Array(LOCAL.dim).fill(0), t = termos(texto)
  const add = (k: string, w: number) => { const h = h32(k), i = h % LOCAL.dim; v[i] += (h & 0x80000000 ? -1 : 1) * w }
  const tf = new Map<string, number>(); for (const w of t) tf.set(w, (tf.get(w) || 0) + 1)
  for (const [w, n] of tf) { const peso = 1 + Math.log(n); add('w:' + w, peso); if (w.length >= 5) for (let i = 0; i + 3 <= w.length; i++) add('c:' + w.slice(i, i + 3), 0.25 * peso) }
  for (let i = 0; i + 1 < t.length; i++) add('b:' + t[i] + '_' + t[i + 1], 0.6)
  const norma = Math.sqrt(v.reduce((a, x) => a + x * x, 0)) || 1
  return v.map((x) => Math.round((x / norma) * 1e5) / 1e5)
}
export function cosseno(a: number[], b: number[]) {
  if (!a?.length || a.length !== b?.length) return 0
  let p = 0, na = 0, nb = 0; for (let i = 0; i < a.length; i++) { p += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
  return na && nb ? p / Math.sqrt(na * nb) : 0
}
export interface EmbCfg { provider: string; base_url?: string; key?: string; model?: string; timeoutMs?: number }
async function postJson(url: string, body: any, headers: Record<string, string>, timeoutMs: number) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), timeoutMs)
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body), signal: ac.signal })
    const txt = await r.text(); let j: any = null; try { j = JSON.parse(txt) } catch { /* resposta não-JSON */ }
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${String(j?.error?.message || j?.error || txt).slice(0, 160)}`)
    return j
  } catch (e: any) { throw new Error(e?.name === 'AbortError' ? `tempo esgotado (${timeoutMs} ms)` : e?.message || String(e)) } finally { clearTimeout(t) }
}
/** Gera vetores com o provedor indicado. Erros sobem (quem chama decide cair para o local). */
export async function embed(textos: string[], c: EmbCfg): Promise<{ vetores: number[][]; provider: string; model: string }> {
  const tm = c.timeoutMs || 20000
  if (c.provider === 'local') return { vetores: textos.map(vetorLocal), provider: LOCAL.provider, model: LOCAL.model }
  if (c.provider === 'ollama') {
    const url = String(c.base_url || 'http://localhost:11434').replace(/\/+$/, ''), model = c.model || 'nomic-embed-text'
    try { const j = await postJson(`${url}/api/embed`, { model, input: textos }, {}, tm); if (Array.isArray(j?.embeddings) && j.embeddings.length === textos.length) return { vetores: j.embeddings, provider: 'ollama', model } } catch (e: any) { if (!/404/.test(e.message)) throw e }
    const vs: number[][] = []; for (const t of textos) { const j = await postJson(`${url}/api/embeddings`, { model, prompt: t }, {}, tm); if (!Array.isArray(j?.embedding)) throw new Error('resposta sem vetor'); vs.push(j.embedding) } // versões antigas do Ollama
    return { vetores: vs, provider: 'ollama', model }
  }
  if (c.provider === 'gemini') {
    if (!c.key) throw new Error('chave de API não configurada')
    const url = String(c.base_url || 'https://generativelanguage.googleapis.com').replace(/\/+$/, ''), model = (c.model || 'text-embedding-004').replace(/^models\//, '')
    const j = await postJson(`${url}/v1beta/models/${model}:batchEmbedContents`, { requests: textos.map((t) => ({ model: `models/${model}`, content: { parts: [{ text: t.slice(0, 8000) }] } })) }, { 'x-goog-api-key': c.key }, tm)
    const vs = (j?.embeddings || []).map((e: any) => e.values); if (vs.length !== textos.length) throw new Error('resposta sem vetores')
    return { vetores: vs, provider: 'gemini', model }
  }
  throw new Error('provedor de embeddings desconhecido: ' + c.provider)
}
export const textoBusca = (t: string) => nrm(t).slice(0, 4000)
