// Cérebro Central — pesquisa na internet e leitura de páginas, com proteções:
// • mecanismos: SearXNG (metabusca, JSON), Google Programmable Search (API oficial, chave + cx) e Wikipédia (API pública);
// • leitura só de http/https, sem endereços internos (proteção contra SSRF), respeitando o robots.txt, com tempo
//   limite, limite de tamanho, só HTML/texto, até 3 redirecionamentos (cada um revalidado);
// • cache no banco (brain_web_cache) e limites diários de buscas e páginas (controle de custo);
// • fontes bloqueadas pelo administrador nunca são lidas.
import { lookup } from 'node:dns/promises'
import { isIP } from 'node:net'
import { q, one, nowIso } from '../../db/index.js'
import { getConfig, setConfig } from '../../lib/settings.js'
import { sha, htmlParaTexto } from './texto.js'

export const UA = 'MeuAssistente-CerebroCentral/1.0 (+https://meuassistente.chat)'
export interface Resultado { url: string; titulo: string; resumo: string; motor: string }
export interface Busca { provider: string; base_url?: string; key?: string; extra?: any; timeoutMs?: number }

/* ---------- limites diários (controle de custo) ---------- */
export async function consumir(tipo: 'buscas' | 'paginas', limite: number) {
  const dia = nowIso().slice(0, 10), u = await getConfig<any>('cerebro_uso', {})
  const atual = u.dia === dia ? u : { dia, buscas: 0, paginas: 0 }
  if ((atual[tipo] || 0) >= limite) throw new Error(`limite diário de ${tipo} atingido (${limite}). Ajuste em Configurações do Cérebro Central.`)
  atual[tipo] = (atual[tipo] || 0) + 1; await setConfig('cerebro_uso', atual); return atual
}
export async function usoHoje() { const dia = nowIso().slice(0, 10), u = await getConfig<any>('cerebro_uso', {}); return u.dia === dia ? { buscas: u.buscas || 0, paginas: u.paginas || 0 } : { buscas: 0, paginas: 0 } }

/* ---------- cache ---------- */
async function cacheGet(key: string, horas: number) {
  const r: any = await one('SELECT body, status, fetched_at FROM brain_web_cache WHERE key = $1', [key])
  if (!r || Date.parse(String(r.fetched_at)) < Date.now() - horas * 3600_000) return null
  return { body: String(r.body), status: Number(r.status) || 200 }
}
async function cachePut(key: string, kind: string, body: string, status: number) {
  await q('DELETE FROM brain_web_cache WHERE key = $1', [key])
  await q('INSERT INTO brain_web_cache (key, kind, body, status, fetched_at) VALUES ($1,$2,$3,$4,$5)', [key, kind, body.slice(0, 600_000), status, nowIso()])
}

/* ---------- rede segura ---------- */
const PRIV4 = [/^10\./, /^127\./, /^0\./, /^169\.254\./, /^192\.168\./, /^172\.(1[6-9]|2\d|3[01])\./, /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./, /^22[4-9]\.|^23\d\.|^24\d\.|^25[0-5]\./]
const privado = (ip: string) => isIP(ip) === 6 ? /^(::1|::|fe80:|fc|fd|::ffff:(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.))/i.test(ip) : PRIV4.some((re) => re.test(ip))
export const redeLocalPermitida = () => process.env.CEREBRO_PERMITIR_REDE_LOCAL === '1' // só para testes automatizados com servidores locais
export async function validarUrl(raw: string): Promise<URL> {
  let u: URL; try { u = new URL(raw) } catch { throw new Error('endereço inválido') }
  if (!/^https?:$/.test(u.protocol)) throw new Error('só http/https')
  if (u.username || u.password) throw new Error('endereço com credenciais não é permitido')
  if (!redeLocalPermitida()) {
    const host = u.hostname.replace(/^\[|\]$/g, '')
    if (/^(localhost|.*\.local|.*\.internal)$/i.test(host)) throw new Error('endereço interno bloqueado')
    const ips = isIP(host) ? [host] : (await lookup(host, { all: true }).catch(() => { throw new Error('domínio não encontrado') })).map((x) => x.address)
    if (ips.some(privado)) throw new Error('endereço interno bloqueado')
  }
  return u
}
async function baixar(url: string, o: { timeoutMs: number; maxBytes: number; aceitar: RegExp; headers?: Record<string, string> }): Promise<{ status: number; tipo: string; corpo: string; final: string }> {
  let atual = url
  for (let salto = 0; salto < 4; salto++) {
    const u = await validarUrl(atual), ac = new AbortController(), t = setTimeout(() => ac.abort(), o.timeoutMs)
    try {
      const r = await fetch(u, { redirect: 'manual', signal: ac.signal, headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml,application/json,text/plain;q=0.8', 'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.5', ...(o.headers || {}) } })
      if (r.status >= 300 && r.status < 400 && r.headers.get('location')) { atual = new URL(r.headers.get('location')!, u).href; continue }
      const tipo = r.headers.get('content-type') || ''
      if (r.ok && !o.aceitar.test(tipo)) throw new Error(`tipo de conteúdo não suportado (${tipo.split(';')[0] || 'desconhecido'})`)
      const reader = r.body?.getReader(); let total = 0; const partes: Uint8Array[] = []
      if (reader) for (;;) { const { done, value } = await reader.read(); if (done) break; total += value.length; if (total > o.maxBytes) { ac.abort(); break } partes.push(value) }
      return { status: r.status, tipo, corpo: Buffer.concat(partes).toString('utf8'), final: u.href }
    } catch (e: any) { throw new Error(e?.name === 'AbortError' ? `tempo esgotado (${o.timeoutMs} ms)` : e?.message || String(e)) } finally { clearTimeout(t) }
  }
  throw new Error('redirecionamentos demais')
}

/* ---------- robots.txt ---------- */
const robotsMem = new Map<string, { at: number; regras: { allow: string[]; disallow: string[] } }>()
export function regrasRobots(txt: string) {
  const grupos: { agentes: string[]; allow: string[]; disallow: string[] }[] = []; let g: any = null, ultimoFoiAgente = false
  for (const raw of txt.split(/\r?\n/)) {
    const l = raw.replace(/#.*/, '').trim(); if (!l) continue
    const [k, ...r] = l.split(':'); const key = k.trim().toLowerCase(), v = r.join(':').trim()
    if (key === 'user-agent') { if (!ultimoFoiAgente || !g) { g = { agentes: [], allow: [], disallow: [] }; grupos.push(g) } g.agentes.push(v.toLowerCase()); ultimoFoiAgente = true; continue }
    ultimoFoiAgente = false; if (!g) continue
    if (key === 'disallow' && v) g.disallow.push(v); if (key === 'allow' && v) g.allow.push(v)
  }
  const nosso = grupos.find((x) => x.agentes.some((a) => a !== '*' && UA.toLowerCase().includes(a))) || grupos.find((x) => x.agentes.includes('*'))
  return { allow: nosso?.allow || [], disallow: nosso?.disallow || [] }
}
export function permitidoPorRobots(path: string, r: { allow: string[]; disallow: string[] }) {
  const casa = (p: string) => { const re = new RegExp('^' + p.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\\\$$/, '$')); return re.test(path) }
  const a = r.allow.filter(casa).sort((x, y) => y.length - x.length)[0] || '', d = r.disallow.filter(casa).sort((x, y) => y.length - x.length)[0] || ''
  return !d || a.length >= d.length
}
async function robotsOk(u: URL, timeoutMs: number) {
  const k = u.origin, c = robotsMem.get(k)
  let regras = c && Date.now() - c.at < 6 * 3600_000 ? c.regras : null
  if (!regras) {
    try { const r = await baixar(`${u.origin}/robots.txt`, { timeoutMs: Math.min(timeoutMs, 6000), maxBytes: 300_000, aceitar: /text\/plain|text\/html|^$/ }); regras = r.status === 200 && !/text\/html/.test(r.tipo) ? regrasRobots(r.corpo) : { allow: [], disallow: [] } }
    catch { regras = { allow: [], disallow: [] } } // sem robots.txt acessível: permitido (padrão da web)
    robotsMem.set(k, { at: Date.now(), regras })
  }
  return permitidoPorRobots(u.pathname + u.search, regras)
}

/* ---------- mecanismos de busca ---------- */
export async function buscar(termo: string, c: Busca, limite: number): Promise<Resultado[]> {
  const tm = c.timeoutMs || 10000, base = String(c.base_url || '').replace(/\/+$/, '')
  if (c.provider === 'searxng') {
    if (!base) throw new Error('URL do SearXNG não configurada')
    const r = await baixar(`${base}/search?q=${encodeURIComponent(termo)}&format=json&language=pt-BR&safesearch=1`, { timeoutMs: tm, maxBytes: 2_000_000, aceitar: /json/ })
    if (r.status !== 200) throw new Error(`SearXNG respondeu HTTP ${r.status}${r.status === 403 ? ' (ative o formato json em settings.yml: search.formats)' : ''}`)
    const j = JSON.parse(r.corpo); return (j.results || []).slice(0, limite).map((x: any) => ({ url: String(x.url), titulo: String(x.title || ''), resumo: String(x.content || ''), motor: 'searxng' + (x.engine ? ':' + x.engine : '') }))
  }
  if (c.provider === 'google_cse') {
    const cx = c.extra?.cx; if (!c.key || !cx) throw new Error('chave de API e ID do mecanismo (cx) do Google são obrigatórios')
    const r = await baixar(`${base || 'https://www.googleapis.com'}/customsearch/v1?key=${encodeURIComponent(c.key)}&cx=${encodeURIComponent(cx)}&q=${encodeURIComponent(termo)}&num=${Math.min(10, limite)}&lr=lang_pt`, { timeoutMs: tm, maxBytes: 2_000_000, aceitar: /json/ })
    if (r.status !== 200) { let m = ''; try { m = JSON.parse(r.corpo).error.message } catch { /* */ } throw new Error(`Google respondeu HTTP ${r.status}${m ? ': ' + m : ''}`) }
    return (JSON.parse(r.corpo).items || []).slice(0, limite).map((x: any) => ({ url: String(x.link), titulo: String(x.title || ''), resumo: String(x.snippet || ''), motor: 'google' }))
  }
  if (c.provider === 'wikipedia') {
    const w = base || 'https://pt.wikipedia.org'
    const r = await baixar(`${w}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(termo)}&format=json&srlimit=${Math.min(10, limite)}&utf8=1`, { timeoutMs: tm, maxBytes: 1_000_000, aceitar: /json/ })
    if (r.status !== 200) throw new Error(`Wikipédia respondeu HTTP ${r.status}`)
    return (JSON.parse(r.corpo).query?.search || []).map((x: any) => ({ url: `${w}/wiki/${encodeURIComponent(String(x.title).replace(/ /g, '_'))}`, titulo: String(x.title), resumo: String(x.snippet || '').replace(/<[^>]+>/g, ''), motor: 'wikipedia' }))
  }
  throw new Error('mecanismo de busca desconhecido: ' + c.provider)
}

/** Lê uma página permitida e devolve o texto. Wikipédia é lida pela API oficial (texto puro, licença CC BY-SA). */
export async function lerPagina(url: string, o: { timeoutMs: number; cacheHoras: number; maxBytes?: number }): Promise<{ url: string; titulo: string; texto: string; status: number; cache: boolean }> {
  const key = 'p:' + sha(url), c = await cacheGet(key, o.cacheHoras)
  if (c) { const j = JSON.parse(c.body); return { ...j, status: c.status, cache: true } }
  const u = await validarUrl(url)
  const wiki = /(^|\.)wikipedia\.org$/.test(u.hostname) && u.pathname.startsWith('/wiki/') ? decodeURIComponent(u.pathname.slice(6)) : null
  let out: { url: string; titulo: string; texto: string }, status = 200
  if (wiki) {
    const r = await baixar(`${u.origin}/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1&format=json&titles=${encodeURIComponent(wiki)}`, { timeoutMs: o.timeoutMs, maxBytes: o.maxBytes || 1_500_000, aceitar: /json/ })
    status = r.status; if (r.status !== 200) throw new Error(`HTTP ${r.status}`)
    const pg: any = Object.values(JSON.parse(r.corpo).query?.pages || {})[0] || {}
    out = { url: u.href, titulo: String(pg.title || wiki), texto: String(pg.extract || '').replace(/\n==+\s*([^=]+?)\s*==+\n/g, '\n## $1\n') }
  } else {
    if (!(await robotsOk(u, o.timeoutMs))) throw new Error('o robots.txt do site não permite a leitura desta página')
    const r = await baixar(u.href, { timeoutMs: o.timeoutMs, maxBytes: o.maxBytes || 1_500_000, aceitar: /text\/html|application\/xhtml|text\/plain/ })
    status = r.status; if (r.status !== 200) throw new Error(`HTTP ${r.status}`)
    const h = /text\/plain/.test(r.tipo) ? { titulo: '', texto: r.corpo } : htmlParaTexto(r.corpo)
    out = { url: r.final, titulo: h.titulo, texto: h.texto }
  }
  await cachePut(key, 'pagina', JSON.stringify(out), status)
  return { ...out, status, cache: false }
}
export async function buscarComCache(termo: string, c: Busca, limite: number, cacheHoras: number, maxBuscasDia: number) {
  const key = 'b:' + sha(`${c.provider}|${c.base_url || ''}|${termo}|${limite}`), hit = await cacheGet(key, cacheHoras)
  if (hit) return { resultados: JSON.parse(hit.body) as Resultado[], cache: true }
  await consumir('buscas', maxBuscasDia)
  const resultados = await buscar(termo, c, limite)
  await cachePut(key, 'busca', JSON.stringify(resultados), 200)
  return { resultados, cache: false }
}
export const dominio = (url: string) => { try { return new URL(url).hostname.replace(/^www\./, '') } catch { return '' } }
const CONFIAVEIS = [/\.gov\.br$/, /\.gov$/, /\.edu(\.br)?$/, /\.jus\.br$/, /\.leg\.br$/, /(^|\.)wikipedia\.org$/, /(^|\.)who\.int$/, /(^|\.)ibge\.gov\.br$/, /(^|\.)bcb\.gov\.br$/, /(^|\.)developer\.mozilla\.org$/, /(^|\.)nodejs\.org$/, /(^|\.)python\.org$/, /(^|\.)postgresql\.org$/, /(^|\.)ai\.google\.dev$/, /(^|\.)sebrae\.com\.br$/]
export const dominioOficial = (d: string) => CONFIAVEIS.some((re) => re.test(d))
