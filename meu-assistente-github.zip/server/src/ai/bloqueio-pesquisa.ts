// BLOQUEIO ESTRUTURAL DE PESQUISA POR TURNO DO CHAT — o motor de prioridade (ai/prioridade.ts) decide, no começo da
// mensagem, se ela é uma OPERAÇÃO INTERNA (agenda, finanças, lembretes, tarefas, notas, contas…) ou a continuação de uma.
// Quando é, a pesquisa externa fica bloqueada NESTE turno, nas camadas mais baixas — não depende de prompt nem de a IA obedecer:
//  • engine.run: grounding desligado e a tarefa "pesquisa" vira conversa/agente (nenhum provedor com busca é escolhido);
//  • cerebro/web.ts buscar(): toda busca na internet (SearXNG, Google, Wikipedia, Tavily…) é recusada;
//  • agentes.ts: o agente de Pesquisa não é selecionado nem executa;
//  • cerebro/integracao.ts recuperar(): não pesquisa nem aprende, nem converte a frase em pergunta de conhecimento.
// O estado vive num AsyncLocalStorage aberto por mensagem (chat.ts) e termina com ela: nada vaza para outra mensagem, outra
// conversa ou outro usuário. Fora de um turno do chat (agendador, painel, testes de provedor) nada é bloqueado.
// Cada tentativa (permitida ou bloqueada) vira um evento do turno: vai para o rastro e é conferida pelos testes de regressão.
import { AsyncLocalStorage } from 'node:async_hooks'

export type TipoEvento = 'ia' | 'grounding' | 'busca_web' | 'agente_pesquisa' | 'cerebro_pesquisa'
export interface EventoPesquisa { tipo: TipoEvento; detalhe: string; bloqueado: boolean }
export interface EstadoTurno { bloqueada: boolean; motivo: string; prioridade: string; dominio: string | null; eventos: EventoPesquisa[]; texto: string; nivel?: number; modo?: string; global?: boolean }

const ALS = new AsyncLocalStorage<EstadoTurno>()

/* ---------- CHAVE GLOBAL do administrador (Administração → Raciocínio e Orquestração → Modos Inteligentes → Pesquisa na internet) ----------
   Desligada, NENHUMA camada busca na internet — chat, agente, modos inteligentes, roteamentos internos, busca por foto,
   imagens e pesquisa do Cérebro —, dentro ou fora de um turno do chat. É a mesma trava estrutural do bloqueio por turno
   (registrar → engine, cerebro/web.buscar, agentes, cerebro/integracao, assistant): nada depende de prompt.
   Lida da configuração 'pesquisa_internet' ({ ativo }) com cache curto; salvar no painel atualiza na hora. */
let GLOBAL = { ligada: true, em: 0 }
const TTL_GLOBAL = 3000
export async function internetPermitida(forcar = false): Promise<boolean> {
  if (!forcar && Date.now() - GLOBAL.em < TTL_GLOBAL) return GLOBAL.ligada
  // leitura direta (sem a memória por requisição de getConfig: o temporizador abaixo nasce dentro de uma requisição e herdaria a
  // memória dela, devolvendo um valor velho)
  try { const { one, J } = await import('../db/index.js'); const r = await one('SELECT value FROM app_config WHERE key = $1', ['pesquisa_internet']); const v = r ? (typeof r.value === 'string' ? J<any>(r.value, {}) : r.value) : {}; GLOBAL = { ligada: (v || {}).ativo !== false, em: Date.now() } }
  catch { GLOBAL = { ...GLOBAL, em: Date.now() } } // sem banco agora: mantém o último valor conhecido
  return GLOBAL.ligada
}
/** O painel acabou de salvar: vale imediatamente neste processo. */
export function definirInternetGlobal(ligada: boolean) { GLOBAL = { ligada, em: Date.now() } }
export const internetDesligada = () => !GLOBAL.ligada
// camadas síncronas (grounding, agentes) fora de um turno do chat: o valor se mantém atualizado sozinho (sem esperar uma busca)
if (process.env.NODE_ENV !== 'test' || process.env.PB_REFRESH === '1') { const t = setInterval(() => { internetPermitida(true).catch(() => {}) }, 5000); (t as any).unref?.(); setTimeout(() => { internetPermitida(true).catch(() => {}) }, 1500).unref?.() }
/** Últimos turnos (só em NODE_ENV=test): os testes de regressão conferem o que cada mensagem acionou. */
export const turnosTeste: EstadoTurno[] = []

/** Abre o escopo de UMA mensagem do chat. */
export async function noTurno<T>(texto: string, fn: () => Promise<T>): Promise<T> {
  const s: EstadoTurno = { bloqueada: false, motivo: '', prioridade: '', dominio: null, eventos: [], texto: String(texto || '').slice(0, 200) }
  if (process.env.NODE_ENV === 'test') { turnosTeste.push(s); if (turnosTeste.length > 500) turnosTeste.shift() }
  if (!(await internetPermitida())) { s.bloqueada = true; s.motivo = 'pesquisa na internet desativada pelo administrador'; s.global = true }
  return ALS.run(s, fn)
}
export const estadoTurno = () => ALS.getStore() || null
/** Marca o turno atual como operação interna: daqui em diante nenhuma camada pesquisa na internet. */
export function bloquearPesquisaNoTurno(motivo: string, prioridade: string, dominio: string | null) {
  const s = ALS.getStore(); if (!s) return
  s.bloqueada = true; if (!s.global) s.motivo = motivo; s.prioridade = prioridade; s.dominio = dominio
}
/** Registra a decisão do turno (hierarquia: nível 1 contexto · 2 recursos internos · 3 Cérebro · 4 pesquisa externa). */
export function anotarDecisao(prioridade: string, dominio: string | null, motivo: string, h?: { nivel?: number; modo?: string }) { const s = ALS.getStore(); if (s) { s.prioridade = prioridade; s.dominio = dominio; if (!s.global) s.motivo = motivo; if (h) { s.nivel = h.nivel; s.modo = h.modo } } }
export const pesquisaBloqueada = () => !!ALS.getStore()?.bloqueada || internetDesligada()
/** Registra uma tentativa (IA, grounding, busca, agente de pesquisa) e devolve se ela deve ser barrada. */
export function registrar(tipo: TipoEvento, detalhe = ''): boolean {
  const s = ALS.getStore(); if (!s) { const b = internetDesligada() && tipo !== 'ia'; if (b) console.warn(`[pesquisa] ${tipo} bloqueado: pesquisa na internet desativada pelo administrador`); return b }
  const bloqueado = (s.bloqueada || internetDesligada()) && tipo !== 'ia'
  s.eventos.push({ tipo, detalhe: String(detalhe).slice(0, 120), bloqueado })
  if (bloqueado) console.warn(`[prioridade] ${tipo} bloqueado: ${s.global || internetDesligada() ? 'pesquisa na internet desativada pelo administrador' : 'operação interna (' + s.motivo + ')'}`)
  return bloqueado
}
export class PesquisaBloqueada extends Error { code = 'pesquisa_bloqueada'; constructor() { super(internetDesligada() ? 'pesquisa na internet desativada pelo administrador' : 'pesquisa externa bloqueada: a mensagem é uma operação interna') } }
/** Resumo para o rastro do turno (diagnóstico e testes). */
export function resumoTurno() {
  const s = ALS.getStore(); if (!s) return null
  const n = (t: TipoEvento, b?: boolean) => s.eventos.filter((e) => e.tipo === t && (b === undefined || e.bloqueado === b)).length
  return { prioridade: s.prioridade, nivel: s.nivel ?? null, modo: s.modo ?? null, dominio: s.dominio, pesquisaBloqueada: s.bloqueada, motivo: s.motivo, ia: n('ia'), grounding: n('grounding', false), buscasWeb: n('busca_web', false), agentePesquisa: n('agente_pesquisa', false), barrados: s.eventos.filter((e) => e.bloqueado).length }
}

/* ---------- RESPOSTA COM A INTERNET DESLIGADA (chave global) ----------
   A pergunta depende do mundo de fora ("Quem foi Bob Marley?", "cotação de hoje", "pesquise…") e nada do que é interno
   (Cérebro Central, biblioteca, conhecimentos aprovados, memória) responde: em vez de falha ou aviso técnico, o chat conduz
   naturalmente para o que ele FAZ por aqui — agenda, lembretes, tarefas, notas e finanças (só os módulos ligados) —, sem
   mencionar internet, bloqueio ou administrador. Varia a frase e continua o assunto da conversa (compromisso, gasto…). */
const INTERNA = /\b(lembrete|lembretes|lembrar|compromisso|compromissos|agenda|agendar|agendamento|tarefa|tarefas|nota|notas|anotar|anotacao|gasto|gastos|despesa|despesas|receita|receitas|contas? a pagar|financ\w*|saldo|orcamento|aplicativo|app|meu assistente|assistente|voce (sabe|consegue|pode|faz)|vc (sabe|consegue|pode|faz)|o que (voce|vc) (faz|sabe)|como (eu )?(faco|crio|cadastro|adiciono|registro|marco|uso|apago|edito|vejo|altero|mudo)|como funciona)\b/
const sa = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
/** Pergunta sobre o próprio app/assistente ou sobre os dados do usuário: é interna (a IA responde normalmente). */
/** Cumprimento, agradecimento ou conversa sobre o próprio assistente ("oi, tudo bem?", "quem é você?"): não é pergunta de fora. */
const SOCIAL = /^(oi+|ola|e ai|eai|opa|hey|bom dia|boa tarde|boa noite|tudo (bem|bom|certo|joia)|como (vai|voce esta|vc esta|vc ta|voce ta)|obrigad[oa]|valeu|quem e voce|quem e vc|qual (e )?(o )?seu nome|voce e (um robo|uma ia|humano))\b/
export const perguntaInterna = (texto: string) => { const t = sa(texto).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); return INTERNA.test(t) || SOCIAL.test(t) || /^(oi|ola|bom dia|boa tarde|boa noite)\b.{0,25}$/.test(t) }
const CTX: [string, RegExp][] = [
  ['agenda', /\b(compromiss\w*|agend\w*|reuniao|reunioes|consulta marcada|horario)\b/],
  ['financeiro', /\b(gast\w*|despesa\w*|receita\w*|r\$|pagamento\w*|saldo|lancamento\w*|financ\w*)\b/],
  ['lembrete', /\b(lembrete\w*|lembr\w*)\b/],
  ['tarefa', /\b(tarefa\w*)\b/],
  ['nota', /\b(nota\b|notas|anot\w*)\b/],
]
const VARIANTES: Record<string, string[]> = {
  agenda: ['Voltando ao seu compromisso: quer que eu ajuste o horário, adicione um lembrete ou mostre como está sua agenda?', 'Sobre a sua agenda, posso remarcar, cancelar ou criar um novo compromisso. O que prefere?', 'Seguimos com o compromisso? Posso mudar o dia, o horário ou te avisar antes.'],
  financeiro: ['Voltando às suas finanças: quer registrar mais algum gasto, ver o resumo do mês ou cadastrar uma conta a pagar?', 'Sobre o seu controle financeiro, posso lançar uma despesa ou receita, ou te mostrar quanto já saiu este mês. Como prefere seguir?', 'Seguimos com as finanças? Posso registrar um valor, corrigir um lançamento ou mostrar o saldo do mês.'],
  lembrete: ['Voltando ao lembrete: quer mudar o horário, criar outro ou ver os próximos avisos?', 'Sobre os seus lembretes, posso criar, alterar ou apagar algum. O que deseja?'],
  tarefa: ['Voltando às suas tarefas: quer marcar alguma como concluída, criar uma nova ou ver o que está pendente?', 'Sobre as tarefas, posso adicionar, concluir ou listar as pendentes. Por onde seguimos?'],
  nota: ['Voltando às suas notas: quer anotar mais alguma coisa ou ver o que já está guardado?', 'Sobre as notas, posso criar uma nova ou procurar o que você já anotou. O que prefere?'],
}
function geral(fin: boolean, lemb: boolean): string[] {
  const lista = (xs: string[]) => (xs.length <= 1 ? xs.join('') : xs.slice(0, -1).join(', ') + ' e ' + xs[xs.length - 1])
  const coisas = lista(['compromissos', ...(lemb ? ['lembretes'] : []), 'tarefas', 'notas', ...(fin ? ['seu controle financeiro'] : [])])
  const areas = lista(['sua agenda', ...(lemb ? ['lembretes'] : []), 'tarefas', 'notas', ...(fin ? ['finanças'] : [])])
  const acoes = lista(['marcar um compromisso', 'anotar uma ideia', ...(lemb ? ['criar um lembrete'] : []), ...(fin ? ['registrar um gasto'] : [])]).replace(/ e ([^,]+)$/, ' ou $1')
  return [
    `Posso ajudar você com ${coisas}. O que deseja organizar?`,
    `Por aqui eu cuido ${areas.startsWith('sua ') ? 'da ' + areas.slice(4) : 'de ' + areas}. Quer começar por algum deles?`,
    `Que tal aproveitar para organizar algo? Posso ${acoes}.`,
    `Estou por aqui para facilitar seu dia: ${areas.replace(/^sua agenda/, 'agenda')}. Me diga o que precisa e eu já faço.`,
    `Posso te ajudar a planejar a semana, lembrar do que é importante${fin ? ' e acompanhar seus gastos' : ''}. O que vamos fazer agora?`,
  ]
}
export function respostaSemInternet(o: { texto: string; hist?: { role: string; content: string }[]; modulos?: Record<string, boolean>; semente?: string }): string {
  const mods = o.modulos || {}, fin = mods.financas !== false, lemb = mods.lembretes !== false
  const recentes = (o.hist || []).slice(-6).reverse()
  let dom: string | null = null
  for (const m of recentes) { const t = sa(m.content); const achou = CTX.find(([d, re]) => (d !== 'financeiro' || fin) && (d !== 'lembrete' || lemb) && re.test(t)); if (achou) { dom = achou[0]; break } }
  const opcoes = dom ? VARIANTES[dom] : geral(fin, lemb)
  let h = 2166136261; for (const ch of sa(o.texto) + '|' + (o.semente || '')) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0 }
  let i = h % opcoes.length
  const ultima = [...(o.hist || [])].reverse().find((m) => m.role === 'assistant')?.content || ''
  if (opcoes[i] === ultima.trim()) i = (i + 1) % opcoes.length // nunca repete a frase da resposta anterior
  return opcoes[i]
}
