// BLOQUEIO ESTRUTURAL DE PESQUISA POR TURNO DO CHAT — o motor de prioridade (ai/prioridade.ts) decide, no começo da
// mensagem, se ela é uma OPERAÇÃO INTERNA (agenda, finanças, lembretes, tarefas, notas, contas…) ou a continuação de uma.
// Quando é, a pesquisa externa fica bloqueada NESTE turno, nas camadas mais baixas — não depende de prompt nem de a IA obedecer:
//  • engine.run: grounding desligado e a tarefa "pesquisa" vira conversa/agente (nenhum provedor com busca é escolhido);
//  • cerebro/web.ts buscar(): toda busca na internet (SearXNG, Google, Wikipedia, Tavily…) é recusada;
//  • agentes.ts: o agente de Pesquisa não é selecionado nem executa;
//  • cerebro/integracao.ts recuperar(): não pesquisa nem aprende, nem converte a frase em pergunta de conhecimento.
// O estado vive num AsyncLocalStorage aberto por mensagem (chat.ts) e termina com ela: nada vaza para outra mensagem, outra
// conversa ou outro usuário. Fora de um turno do chat (agendador, painel, testes de provedor) nada é bloqueado.
// Cada tentativa (permitida ou bloqueada) vira um evento do turno: vai para o rastro e é conferida pelos testes de regressão.
import { AsyncLocalStorage } from 'node:async_hooks'

export type TipoEvento = 'ia' | 'grounding' | 'busca_web' | 'agente_pesquisa' | 'cerebro_pesquisa'
export interface EventoPesquisa { tipo: TipoEvento; detalhe: string; bloqueado: boolean }
export interface EstadoTurno { bloqueada: boolean; motivo: string; prioridade: string; dominio: string | null; eventos: EventoPesquisa[]; texto: string; nivel?: number; modo?: string }

const ALS = new AsyncLocalStorage<EstadoTurno>()
/** Últimos turnos (só em NODE_ENV=test): os testes de regressão conferem o que cada mensagem acionou. */
export const turnosTeste: EstadoTurno[] = []

/** Abre o escopo de UMA mensagem do chat. */
export function noTurno<T>(texto: string, fn: () => Promise<T>): Promise<T> {
  const s: EstadoTurno = { bloqueada: false, motivo: '', prioridade: '', dominio: null, eventos: [], texto: String(texto || '').slice(0, 200) }
  if (process.env.NODE_ENV === 'test') { turnosTeste.push(s); if (turnosTeste.length > 500) turnosTeste.shift() }
  return ALS.run(s, fn)
}
export const estadoTurno = () => ALS.getStore() || null
/** Marca o turno atual como operação interna: daqui em diante nenhuma camada pesquisa na internet. */
export function bloquearPesquisaNoTurno(motivo: string, prioridade: string, dominio: string | null) {
  const s = ALS.getStore(); if (!s) return
  s.bloqueada = true; s.motivo = motivo; s.prioridade = prioridade; s.dominio = dominio
}
/** Registra a decisão do turno (hierarquia: nível 1 contexto · 2 recursos internos · 3 Cérebro · 4 pesquisa externa). */
export function anotarDecisao(prioridade: string, dominio: string | null, motivo: string, h?: { nivel?: number; modo?: string }) { const s = ALS.getStore(); if (s) { s.prioridade = prioridade; s.dominio = dominio; s.motivo = motivo; if (h) { s.nivel = h.nivel; s.modo = h.modo } } }
export const pesquisaBloqueada = () => !!ALS.getStore()?.bloqueada
/** Registra uma tentativa (IA, grounding, busca, agente de pesquisa) e devolve se ela deve ser barrada. */
export function registrar(tipo: TipoEvento, detalhe = ''): boolean {
  const s = ALS.getStore(); if (!s) return false
  const bloqueado = s.bloqueada && tipo !== 'ia'
  s.eventos.push({ tipo, detalhe: String(detalhe).slice(0, 120), bloqueado })
  if (bloqueado) console.warn(`[prioridade] ${tipo} bloqueado: operação interna (${s.motivo})`)
  return bloqueado
}
export class PesquisaBloqueada extends Error { code = 'pesquisa_bloqueada'; constructor() { super('pesquisa externa bloqueada: a mensagem é uma operação interna') } }
/** Resumo para o rastro do turno (diagnóstico e testes). */
export function resumoTurno() {
  const s = ALS.getStore(); if (!s) return null
  const n = (t: TipoEvento, b?: boolean) => s.eventos.filter((e) => e.tipo === t && (b === undefined || e.bloqueado === b)).length
  return { prioridade: s.prioridade, nivel: s.nivel ?? null, modo: s.modo ?? null, dominio: s.dominio, pesquisaBloqueada: s.bloqueada, motivo: s.motivo, ia: n('ia'), grounding: n('grounding', false), buscasWeb: n('busca_web', false), agentePesquisa: n('agente_pesquisa', false), barrados: s.eventos.filter((e) => e.bloqueado).length }
}
