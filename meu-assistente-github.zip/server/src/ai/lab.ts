// Laboratório de IA (exclusivo de administradores): o administrador conversa, corrige e ensina; a correção vira uma PROPOSTA de regra
// que passa por análise, testes em modo simulação e aprovação explícita antes de chegar à produção (Cérebro, brain_answers).
// Nada aqui executa ação real: a simulação roda o mesmo assistente com as ferramentas desligadas; só PUBLICAR altera a produção.
// Estados: rascunho → em_analise → em_testes → aguardando_aprovacao → aprovada → publicada (ou rejeitada / desativada).
import { q, one, J, nowIso, isoOf } from '../db/index.js'
import { fail } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import * as B from './brain.js'
import { detectConflicts } from './brain-conflicts.js'
import { validateRule } from './rules.js'

export const CATEGORIAS = ['Agendamentos', 'Financeiro', 'Pagamentos', 'Clientes', 'Serviços', 'Produtos', 'Estoque', 'Empresas', 'Agenda', 'Lembretes', 'Automação', 'Atendimento'] as const
export const ESTADOS = ['rascunho', 'em_analise', 'em_testes', 'aguardando_aprovacao', 'aprovada', 'publicada', 'rejeitada', 'desativada'] as const
export const ESTADO_LABEL: Record<string, string> = { rascunho: 'Rascunho', em_analise: 'Em análise', em_testes: 'Em testes', aguardando_aprovacao: 'Aguardando aprovação', aprovada: 'Aprovada', publicada: 'Publicada', rejeitada: 'Rejeitada', desativada: 'Desativada' }
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const dice = (a: string, b: string) => { const wa = new Set(a.split(' ').filter((w) => w.length > 2)), wb = new Set(b.split(' ').filter((w) => w.length > 2)); if (!wa.size || !wb.size) return 0; let i = 0; for (const w of wa) if (wb.has(w)) i++; return (2 * i) / (wa.size + wb.size) }

/* ---------- interpretação da correção ---------- */
const CAT_KW: [string, RegExp][] = [
  ['Pagamentos', /\b(pagou|pagamento|pagar|sinal|pix|recebimento|recebeu|cobranca|entrada paga)\b/], ['Financeiro', /\b(financeir\w*|saldo|lancamento|despesa|receita|gasto|caixa|fluxo)\b/],
  ['Agendamentos', /\b(agendamento|agendar|agendou|horario marcado|reserva)\b/], ['Agenda', /\b(agenda|compromisso)\b/], ['Lembretes', /\b(lembrete|lembrar|avis[ae]r?)\b/],
  ['Estoque', /\b(estoque|inventario)\b/], ['Produtos', /\b(produto|produtos|cardapio|catalogo)\b/], ['Serviços', /\b(servico|servicos)\b/], ['Clientes', /\b(cliente|clientes)\b/],
  ['Empresas', /\b(empresa|empresas|loja)\b/], ['Automação', /\b(automatic\w*|automacao|automatizar)\b/], ['Atendimento', /\b(atendimento|atendente|responder|resposta)\b/],
]
export function classificar(texto: string): string {
  const t = norm(texto); let best = 'Atendimento', n = 0
  for (const [c, re] of CAT_KW) { const m = t.match(new RegExp(re.source, 'g'))?.length || 0; if (m > n) { n = m; best = c } }
  return best
}
/** A mensagem do administrador é uma correção/ensino (e não uma conversa qualquer)? */
export function pareceCorrecao(texto: string) {
  const t = norm(texto)
  return t.length >= 25 && /\b(sempre que|sempre|nunca|jamais|nao deve|nao deveria|deveria|isso nao deve|corrija|corrigir|errado|erro|esqueceu|nao registrou|nao criou|a partir de agora|de agora em diante|a regra|nova regra|ensine|aprenda|quando eu (disser|informar)|toda vez)\b/.test(t)
}
const NORMATIVA = /\b(sempre|nunca|jamais|deve|deveria|devem|nao deve|nao pode|registre|registrar|crie|criar|faca|fazer|vincule|atualize|pergunte|confirme|avise|antes de|a partir de agora|quando|se )\b/i
export interface Interpretacao { categoria: string; titulo: string; falha: string; quando: string; entao: string[]; restricoes: string[]; regra: string }
export function interpretarLocal(texto: string): Interpretacao {
  const limpo = String(texto || '').replace(/^["“”']+|["“”']+$/g, '').replace(/\s+/g, ' ').trim()
  const frases = limpo.split(/(?<=[.!?])\s+/).map((f) => f.trim()).filter(Boolean)
  const norms = frases.filter((f) => /\b(sempre|nunca|jamais|deve|deveria|devem|nao deve|a partir de agora|de agora em diante|toda vez)\b/i.test(norm(f)) || /^(registre|crie|vincule|atualize|pergunte|confirme)/i.test(norm(f)))
  const falhas = frases.filter((f) => !norms.includes(f))
  const regraFrases = norms.length ? norms : [limpo]
  const regraBruta = regraFrases.join(' ')
  const m = regraBruta.match(/(?:sempre que|toda vez que|quando|se)\s+(.+?)[,:]\s*(.+)/i)
  const quando = m ? m[1].trim().replace(/[.,;]$/, '') : ''
  const resto = m ? m[2].trim() : regraBruta
  const partes = resto.split(/\s*(?:,\s*|\se\s)(?=(?:registre|crie|vincule|atualize|pergunte|confirme|avise|envie|lance|marque|gere|salve|guarde)\b)/i).map((p) => p.replace(/[.;]+$/, '').trim()).filter(Boolean)
  const restricoes = frases.filter((f) => /\b(nao|nunca|jamais)\b/.test(norm(f)) && /\b(deve|pode|faca|fazer|registre|crie|execute)\b/.test(norm(f)) && norms.includes(f)).map((f) => f.replace(/[.]+$/, ''))
  const titulo = (quando ? `Quando ${quando}` : regraFrases[0].replace(/^(sempre|nunca)\s+/i, (x) => x)).replace(/^./, (c) => c.toUpperCase()).slice(0, 90)
  return { categoria: classificar(limpo), titulo, falha: falhas.join(' ').slice(0, 400), quando, entao: partes.length ? partes : [resto], restricoes, regra: regraBruta }
}
/** Texto da regra que vai para o Cérebro: curto, claro e com salvaguardas fixas (a regra orienta a IA; nunca executa por conta própria). */
export function montarRegra(i: Interpretacao) {
  const base = i.quando ? `Quando ${i.quando}: ${i.entao.join('; ')}.` : `${i.entao.join('; ')}.`
  const restr = i.restricoes.length ? ` Restrições: ${i.restricoes.join('; ')}.` : ''
  return `[${i.categoria}] ${base}${restr} Aplique somente quando o usuário pedir ou informar isso na conversa, use as ferramentas oficiais do sistema, não invente valores nem dados e peça o que faltar.`.slice(0, 1500)
}
const RISCO = /\b(ignor\w+ (as )?(regras|permiss\w+|seguranca)|sem (pedir )?(confirma\w+|permiss\w+|autoriza\w+)|burl\w+|senha|token|chave (de )?api|apague (tudo|todos)|exclua (tudo|todos)|delete|dados de outr\w+|de outros usuarios|desativ\w+ (a )?seguranca|transfir\w+ (dinheiro|valor)|libere acesso|acesso total)\b/
export function riscosDe(texto: string): string[] {
  const t = norm(texto), out: string[] = []
  if (RISCO.test(t)) out.push('A regra tenta contornar permissões/segurança, mexer em dados de outros usuários, credenciais ou apagar dados. Isso não é permitido no aprendizado.')
  if (/\b(automaticamente|sozinho|sem perguntar)\b/.test(t) && /\b(pague|transfira|cobre|exclua|apague|envie para todos)\b/.test(t)) out.push('Ação financeira/administrativa real automática não é permitida: a regra só pode orientar a IA quando o próprio usuário pedir.')
  return out
}

/* ---------- propostas ---------- */
const parseJ = (v: any, d: any) => J<any>(v, d)
export function propostaOut(r: any) {
  return { id: Number(r.id), categoria: r.category, titulo: r.title, falha: r.problem || '', correcao: r.correction || '', regra: r.rule_text, estruturada: parseJ(r.rule_json, {}), natureza: r.nature, escopo: r.scope, prioridade: Number(r.priority), estado: r.state, estadoLabel: ESTADO_LABEL[r.state] || r.state,
    itemCerebro: r.brain_item_id == null ? null : Number(r.brain_item_id), emProducao: !!r.live, textoEmProducao: r.published_text || null, versao: Number(r.version), riscos: parseJ(r.risks, []), parecidos: parseJ(r.similar, []), conflitos: parseJ(r.conflicts, []), testes: parseJ(r.tests, null),
    aprovadoPor: r.approved_by || null, aprovadoEm: isoOf(r.approved_at), publicadoEm: isoOf(r.published_at), criadoEm: isoOf(r.created_at), atualizadoEm: isoOf(r.updated_at) }
}
export async function evento(proposalId: number | null, kind: string, actor: string, detail: any = {}) {
  await q('INSERT INTO lab_events (proposal_id, kind, actor, detail, created_at) VALUES ($1,$2,$3,$4,$5)', [proposalId, kind, actor, JSON.stringify(detail).slice(0, 3000), nowIso()])
}
async function get(id: number) {
  const r = await one('SELECT * FROM lab_proposals WHERE id = $1', [id]); if (!r) fail(404, 'Proposta não encontrada.', 'not_found')
  const it = r!.brain_item_id != null ? await one('SELECT status FROM brain_answers WHERE id = $1', [r!.brain_item_id]) : null
  return { ...r!, live: it?.status === 'ativo', itemStatus: it?.status || null } as any
}
/** Mantém o Laboratório coerente quando o item foi aprovado/desativado pelo painel do Cérebro. */
async function sincronizar(r: any) {
  if (r.brain_item_id == null) return r
  if (r.itemStatus === 'ativo' && r.published_text == null && !['publicada'].includes(r.state) && ['aprovada', 'aguardando_aprovacao', 'em_testes', 'em_analise'].includes(r.state)) {
    await q("UPDATE lab_proposals SET state = 'publicada', published_text = rule_text, published_at = $1, updated_at = $1 WHERE id = $2", [nowIso(), r.id]); await evento(Number(r.id), 'publicada_pelo_cerebro', 'sistema', { nota: 'Aprovada diretamente no painel do Cérebro.' }); return get(Number(r.id))
  }
  if (r.itemStatus === 'desativado' && r.state === 'publicada') { await q("UPDATE lab_proposals SET state = 'desativada', updated_at = $1 WHERE id = $2", [nowIso(), r.id]); await evento(Number(r.id), 'desativada_pelo_cerebro', 'sistema', {}); return get(Number(r.id)) }
  return r
}
export async function listar(estado?: string) {
  const rows = await q('SELECT * FROM lab_proposals ORDER BY id DESC LIMIT 300'); const out: any[] = []
  for (const r of rows as any[]) { const x = await sincronizar(await get(Number(r.id))); if (!estado || x.state === estado) out.push(propostaOut(x)) }
  return out
}
export async function detalhe(id: number) {
  const r = await sincronizar(await get(id))
  const versoes = (await q('SELECT * FROM lab_versions WHERE proposal_id = $1 ORDER BY version DESC', [id])).map((v: any) => ({ versao: Number(v.version), regra: v.rule_text, versaoCerebro: v.brain_version == null ? null : Number(v.brain_version), por: v.actor, nota: v.note, testes: parseJ(v.tests, null), em: isoOf(v.created_at) }))
  const eventos = (await q('SELECT * FROM lab_events WHERE proposal_id = $1 ORDER BY id DESC LIMIT 200', [id])).map((e: any) => ({ tipo: e.kind, por: e.actor, detalhe: parseJ(e.detail, {}), em: isoOf(e.created_at) }))
  return { proposta: propostaOut(r), versoes, eventos }
}
export async function historicoGeral(limit = 100) {
  return (await q('SELECT e.*, p.title FROM lab_events e LEFT JOIN lab_proposals p ON p.id = e.proposal_id ORDER BY e.id DESC LIMIT $1', [limit])).map((e: any) => ({ propostaId: e.proposal_id == null ? null : Number(e.proposal_id), titulo: e.title || null, tipo: e.kind, por: e.actor, detalhe: parseJ(e.detail, {}), em: isoOf(e.created_at) }))
}
export async function resumo() {
  const n = async (w: string) => Number((await one(`SELECT COUNT(*) AS n FROM lab_proposals ${w}`))?.n || 0)
  return { total: await n(''), publicadas: await n("WHERE state = 'publicada'"), aguardando: await n("WHERE state = 'aguardando_aprovacao'"), rascunhos: await n("WHERE state IN ('rascunho','em_analise','em_testes')") }
}
const cleanScope = (s: any) => (['chat', 'agentes', 'todos'].includes(s) ? String(s) : 'chat')
export async function criar(actor: string, adminId: number, p: { texto?: string; categoria?: string; titulo?: string; falha?: string; regra?: string; escopo?: string; prioridade?: number; interpretacao?: Interpretacao; natureza?: string; regraExecutavel?: any }) {
  const original = String(p.texto || p.regra || '').trim().slice(0, 2000)
  if (original.length < 10 && !p.interpretacao) fail(400, 'Explique o que a IA deve fazer (mínimo 10 letras).', 'invalid', 'texto')
  const i = p.interpretacao || interpretarLocal(original)
  if (p.categoria && (CATEGORIAS as readonly string[]).includes(p.categoria)) i.categoria = p.categoria
  if (p.titulo) i.titulo = String(p.titulo).slice(0, 120)
  if (p.falha !== undefined) i.falha = String(p.falha).slice(0, 400)
  const regra = p.regra && p.regra.trim().length >= 10 && !p.interpretacao ? String(p.regra).trim().slice(0, 1500) : montarRegra(i)
  let natureza = 'diretriz'; let rj: any = { quando: i.quando, entao: i.entao, restricoes: i.restricoes }
  const escopo = cleanScope(p.escopo)
  if (p.natureza === 'executavel') { const v = validateRule(p.regraExecutavel, escopo); natureza = 'executavel'; rj = { ...rj, executavel: v } }
  const riscos = riscosDe(original + ' ' + regra)
  const prio = Math.min(100, Math.max(1, Math.round(Number(p.prioridade) || 80)))
  const r = await q('INSERT INTO lab_proposals (category, title, problem, correction, rule_text, rule_json, nature, scope, priority, state, risks, version, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$14) RETURNING id',
    [i.categoria, i.titulo, i.falha, original, regra, JSON.stringify(rj), natureza, escopo, prio, 'rascunho', JSON.stringify(riscos), 1, adminId, nowIso()])
  const id = Number(r[0].id)
  await evento(id, 'correcao', actor, { texto: original, falha: i.falha }); await evento(id, 'regra_criada', actor, { categoria: i.categoria, regra })
  return id
}
export async function editar(id: number, actor: string, p: any) {
  const r = await get(id)
  if (['rejeitada'].includes(r.state)) fail(409, 'Proposta rejeitada não pode ser editada. Crie outra.', 'invalid')
  const set: string[] = [], val: any[] = []; const put = (c: string, v: any) => { val.push(v); set.push(`${c} = $${val.length}`) }
  const regra = p.regra !== undefined ? String(p.regra).trim().slice(0, 1500) : r.rule_text
  if (regra.length < 10) fail(400, 'A regra precisa ter pelo menos 10 letras.', 'invalid', 'regra')
  if (p.regra !== undefined) put('rule_text', regra)
  if (p.titulo !== undefined) put('title', String(p.titulo).trim().slice(0, 120) || r.title)
  if (p.categoria !== undefined && (CATEGORIAS as readonly string[]).includes(p.categoria)) put('category', p.categoria)
  if (p.escopo !== undefined) put('scope', cleanScope(p.escopo))
  if (p.prioridade !== undefined) put('priority', Math.min(100, Math.max(1, Math.round(Number(p.prioridade)) || 80)))
  if (p.falha !== undefined) put('problem', String(p.falha).slice(0, 400))
  const riscos = riscosDe(regra); put('risks', JSON.stringify(riscos))
  // qualquer edição volta ao rascunho e limpa testes/aprovação: o que está em produção NÃO muda até publicar de novo
  put('state', 'rascunho'); put('tests', null); put('approved_by', null); put('approved_at', null); put('updated_at', nowIso()); put('version', Number(r.version) + 1)
  val.push(id); await q(`UPDATE lab_proposals SET ${set.join(', ')} WHERE id = $${val.length}`, val)
  await evento(id, 'editada', actor, { de: r.rule_text, para: regra, emProducaoContinuaIgual: r.live })
  return detalhe(id)
}

/* ---------- análise: parecidos, duplicidade e conflitos ---------- */
export async function analisar(id: number, actor: string) {
  const r = await get(id)
  if (['publicada', 'rejeitada', 'desativada'].includes(r.state) && !r.live) fail(409, 'Esta proposta não está em edição.', 'invalid')
  const cn = norm(r.rule_text)
  const itens = await q("SELECT id, question, answer, status, nature, kind FROM brain_answers WHERE status IN ('ativo','pendente') AND kind <> 'resposta' LIMIT 1500")
  const parecidos = (itens as any[]).filter((x) => Number(x.id) !== Number(r.brain_item_id)).map((x) => ({ id: Number(x.id), titulo: String(x.question), status: x.status, similaridade: Math.round(Math.max(dice(norm(x.question), norm(r.title)), dice(norm(x.answer).slice(0, 700), cn.slice(0, 700))) * 100) / 100 }))
    .filter((x) => x.similaridade >= 0.45).sort((a, b) => b.similaridade - a.similaridade).slice(0, 5)
  const duplicado = r.brain_item_id == null ? await B.findDuplicate(r.title, r.rule_text) : null
  let itemId: number | null = r.brain_item_id == null ? null : Number(r.brain_item_id), conflitos: any[] = []
  if (duplicado) { if (!parecidos.some((p) => p.id === duplicado)) parecidos.unshift({ id: duplicado, titulo: String((await one('SELECT question FROM brain_answers WHERE id = $1', [duplicado]))?.question || ''), status: 'ativo', similaridade: 1 }) }
  else if (itemId == null) {
    const nat = r.nature === 'executavel' ? { natureza: 'executavel', regra: parseJ(r.rule_json, {}).executavel } : { natureza: 'diretriz' }
    const a = await B.addKnowledge({ titulo: r.title, conteudo: r.rule_text, tipo: 'regra', origem: 'laboratorio', status: 'pendente', fonte: `laboratorio:${id}:${r.category}`, escopo: r.scope, prioridade: Number(r.priority), ...nat }, actor)
    if (a.ok && (a as any).id) itemId = Number((a as any).id); else if ((a as any).duplicado) parecidos.unshift({ id: Number((a as any).duplicado), titulo: '', status: 'ativo', similaridade: 1 })
  } else if (r.itemStatus === 'pendente') await B.updateItem(itemId, { titulo: r.title, conteudo: r.rule_text, escopo: r.scope, prioridade: Number(r.priority) }, actor)
  if (itemId != null) conflitos = (await detectConflicts(itemId).catch(() => [])).map((c) => ({ tipo: c.tipo, gravidade: c.gravidade, com: c.a === itemId ? c.b : c.a, titulos: c.titulos, motivo: c.motivo, prevalece: c.prevalece }))
  const riscos = riscosDe(r.rule_text)
  await q("UPDATE lab_proposals SET state = $1, brain_item_id = $2, similar = $3, conflicts = $4, risks = $5, updated_at = $6 WHERE id = $7", [r.live ? r.state : 'em_analise', itemId, JSON.stringify(parecidos), JSON.stringify(conflitos), JSON.stringify(riscos), nowIso(), id])
  if (r.live && r.state === 'rascunho') await q("UPDATE lab_proposals SET state = 'em_analise' WHERE id = $1", [id])
  await evento(id, 'analise', actor, { parecidos: parecidos.length, duplicadoDe: duplicado, conflitos: conflitos.length, riscos })
  return detalhe(id)
}

/* ---------- simulação (nenhum efeito real) ---------- */
const FERRAMENTA_LABEL: Record<string, string> = { create_task: 'Criaria uma tarefa', create_appointment: 'Criaria um agendamento', update_appointment: 'Alteraria um agendamento', create_reminder: 'Criaria um lembrete', add_shopping_items: 'Adicionaria itens à lista de compras', create_note: 'Salvaria uma anotação', register_transaction: 'Registraria uma movimentação financeira', create_bill: 'Cadastraria uma conta a pagar', complete_task: 'Concluiria uma tarefa', save_memory: 'Guardaria uma memória', get_agenda: 'Consultaria a agenda', get_finance: 'Consultaria o financeiro' }
const LEITURA = new Set(['get_agenda', 'get_finance'])
const ESPERADAS: [RegExp, string, string][] = [
  [/\b(registr\w+|lanc\w+)\b.*\b(pagamento|recebimento|receita|sinal|gasto|despesa|financeiro|entrada)\b|\b(pagamento|recebimento|receita|sinal)\b.*\b(registr\w+|lanc\w+)\b/, 'register_transaction', 'registrar a movimentação financeira'],
  [/\b(agend\w+|marc\w+ (um )?compromisso|compromisso)\b/, 'create_appointment', 'criar o agendamento/compromisso'], [/\b(lembrete|lembrar|avis\w+ (o )?usuario)\b/, 'create_reminder', 'criar o lembrete'],
  [/\b(crie|criar|registre)\b.*\btarefa\b/, 'create_task', 'criar a tarefa'], [/\b(conta a pagar|boleto)\b/, 'create_bill', 'cadastrar a conta a pagar'],
]
export function ferramentasEsperadas(regra: string) { const t = norm(regra); return ESPERADAS.filter(([re]) => re.test(t)).map(([, f, d]) => ({ ferramenta: f, descricao: d })) }
export interface Problema { tipo: 'parcial' | 'incompleta' | 'informacao_ignorada' | 'resultado_diferente' | 'conflito'; mensagem: string; sugestao: string }
/** Detecção automática de falhas: execução parcial, informação ignorada, operação incompleta, conflito e resultado diferente do pedido. */
export function avaliar(pedido: string, acoes: { name: string; args: any }[], resposta: string, regra: string, conflitos: any[] = []): Problema[] {
  const out: Problema[] = [], esp = ferramentasEsperadas(regra), escreveu = acoes.filter((a) => !LEITURA.has(a.name)), chamadas = new Set(acoes.map((a) => a.name))
  const faltam = esp.filter((e) => !chamadas.has(e.ferramenta))
  if (esp.length && faltam.length === esp.length) out.push({ tipo: 'incompleta', mensagem: `A regra manda ${faltam.map((f) => f.descricao).join(' e ')}, mas a IA não fez isso.`, sugestao: 'Deixe a regra mais direta (ex.: "chame a ferramenta de registro de receita") ou inclua um exemplo; teste de novo.' })
  else if (faltam.length) out.push({ tipo: 'parcial', mensagem: `Execução parcial: faltou ${faltam.map((f) => f.descricao).join(' e ')}.`, sugestao: 'Divida a regra em passos numerados e deixe explícito que todos devem ser feitos no mesmo pedido.' })
  if (/\b(registrei|agendei|criei|salvei|lancei|cadastrei|anotei)\b/.test(norm(resposta)) && !escreveu.length) out.push({ tipo: 'resultado_diferente', mensagem: 'A IA disse que fez algo, mas nenhuma ação foi executada.', sugestao: 'Reforce: "só diga que registrou depois de chamar a ferramenta".' })
  const dados = JSON.stringify(escreveu.map((a) => a.args)).replace(/\./g, ',')
  for (const m of String(pedido).matchAll(/r\$\s*(\d+(?:[.,]\d{1,2})?)/gi)) { const v = m[1].replace('.', ','); const alt = v.replace(/,00$/, ''); if (escreveu.length && !dados.includes(v) && !dados.includes(alt) && !JSON.stringify(escreveu.map((a) => a.args)).includes(String(Number(m[1].replace(',', '.'))))) out.push({ tipo: 'informacao_ignorada', mensagem: `O valor R$ ${m[1]} informado no pedido não aparece nas ações da IA.`, sugestao: 'Inclua na regra que o valor informado pelo usuário deve ser usado exatamente como foi dito.' }) }
  for (const c of conflitos) out.push({ tipo: 'conflito', mensagem: `Conflito com a regra #${c.com}: ${c.motivo}`, sugestao: 'Ajuste a prioridade, o escopo ou o texto de uma das regras antes de publicar.' })
  return out
}
export async function simular(u: SessionUser, texto: string, regraEmTeste: string | null, conflitos: any[] = [], regraParaAvaliar = '') {
  const t = String(texto || '').trim(); if (t.length < 3) fail(400, 'Escreva o comando a simular.', 'invalid', 'texto')
  const { runAssistant } = await import('./assistant.js'), { applyRules } = await import('./rules.js')
  const sb = { extraRules: regraEmTeste || undefined, calls: [] as { name: string; args: any }[] }
  let resposta = '', erro = ''
  try { resposta = (await runAssistant(u, [], t.slice(0, 1500), undefined, '', undefined, sb)).content } catch (e: any) { erro = e?.message || 'A IA não respondeu agora.' }
  const regras = await applyRules({ user: u, canal: 'chat', texto: t, dryRun: true }).catch(() => null)
  const acoes = sb.calls.map((c) => ({ ferramenta: c.name, leitura: LEITURA.has(c.name), resumo: FERRAMENTA_LABEL[c.name] || c.name, dados: c.args }))
  const problemas = erro ? [] : avaliar(t, sb.calls, resposta, regraParaAvaliar || regraEmTeste || '', conflitos)
  return { texto: t, resposta, erro, acoes, regrasExecutaveis: regras ? { simulado: regras.simulado, resposta: regras.reply } : null, problemas, semEfeitoReal: true }
}
export async function testar(u: SessionUser, id: number, actor: string, cenarios?: string[]) {
  const r = await get(id)
  if (!['em_analise', 'em_testes', 'rascunho'].includes(r.state)) fail(409, 'Só é possível testar uma proposta em edição.', 'invalid')
  if (parseJ(r.risks, []).length) fail(409, 'A proposta tem riscos de segurança e não pode ser testada nem publicada. Edite a regra.', 'risco')
  const rj = parseJ(r.rule_json, {})
  const lista = (cenarios && cenarios.length ? cenarios : [rj.quando ? String(rj.quando) : r.title]).map((s) => String(s).trim()).filter((s) => s.length >= 3).slice(0, 5)
  const rodadas: any[] = []
  for (const c of lista) { const s = await simular(u, c, r.rule_text, parseJ(r.conflicts, []), r.rule_text); rodadas.push({ cenario: c, resposta: s.resposta, erro: s.erro, acoes: s.acoes, problemas: s.problemas, ok: !s.erro && !s.problemas.length }) }
  const altos = parseJ(r.conflicts, []).filter((c: any) => c.gravidade === 'alta').length
  const res = { em: nowIso(), rodadas, aprovado: rodadas.every((x) => x.ok) && !altos, conflitosAltos: altos, semEfeitoReal: true }
  await q("UPDATE lab_proposals SET tests = $1, state = 'em_testes', updated_at = $2 WHERE id = $3", [JSON.stringify(res), nowIso(), id])
  await evento(id, 'testes', actor, { cenarios: lista.length, aprovado: res.aprovado, problemas: rodadas.flatMap((x) => x.problemas.map((p: Problema) => p.tipo)) })
  return detalhe(id)
}

/* ---------- aprovação e publicação ---------- */
export async function enviarParaAprovacao(id: number, actor: string, confirmar = false) {
  const r = await get(id); if (r.state !== 'em_testes') fail(409, 'Rode os testes antes de enviar para aprovação.', 'invalid')
  const t = parseJ(r.tests, null); if (!t) fail(409, 'Rode os testes antes de enviar para aprovação.', 'invalid')
  if (parseJ(r.risks, []).length) fail(409, 'Há riscos de segurança nesta proposta.', 'risco')
  if (!t.aprovado && !confirmar) return { ok: false, precisaConfirmar: true, motivo: 'Os testes encontraram problemas. Envie mesmo assim apenas se você revisou os resultados.', testes: t }
  await q("UPDATE lab_proposals SET state = 'aguardando_aprovacao', updated_at = $1 WHERE id = $2", [nowIso(), id]); await evento(id, 'enviada_para_aprovacao', actor, { testesAprovados: !!t.aprovado, forcado: !t.aprovado })
  return { ok: true, ...(await detalhe(id)) }
}
export async function aprovar(id: number, actor: string) {
  const r = await get(id); if (r.state !== 'aguardando_aprovacao') fail(409, 'Só se aprova uma proposta que está aguardando aprovação.', 'invalid')
  await q("UPDATE lab_proposals SET state = 'aprovada', approved_by = $1, approved_at = $2, updated_at = $2 WHERE id = $3", [actor, nowIso(), id]); await evento(id, 'aprovada', actor, {})
  return detalhe(id)
}
export async function rejeitar(id: number, actor: string, motivo: string) {
  const r = await get(id); if (['publicada', 'rejeitada'].includes(r.state) && r.live) fail(409, 'Regra publicada: desative ou reverta em vez de rejeitar.', 'invalid')
  if (r.itemStatus === 'pendente') await B.setStatus(Number(r.brain_item_id), 'reject', actor)
  await q("UPDATE lab_proposals SET state = 'rejeitada', updated_at = $1 WHERE id = $2", [nowIso(), id]); await evento(id, 'rejeitada', actor, { motivo: String(motivo || '').slice(0, 300) })
  return detalhe(id)
}
export async function publicar(id: number, actor: string, confirmar = false) {
  const r = await get(id); if (r.state !== 'aprovada') fail(409, 'Só se publica uma proposta aprovada.', 'invalid')
  if (parseJ(r.risks, []).length) fail(409, 'Há riscos de segurança nesta proposta.', 'risco')
  const rj = parseJ(r.rule_json, {})
  let brainVersion: number | null = null, itemId: number | null = r.brain_item_id == null ? null : Number(r.brain_item_id)
  const anterior = r.live ? String(r.published_text || '') : null
  if (itemId != null && r.itemStatus === 'ativo') { const u = await B.updateItem(itemId, { titulo: r.title, conteudo: r.rule_text, escopo: r.scope, prioridade: Number(r.priority) }, actor); if (!(u as any).ok) fail(409, 'Não foi possível atualizar a regra em produção.', 'invalid'); brainVersion = Number((u as any).versao || 0) || null }
  else {
    if (itemId == null) { const a: any = await B.addKnowledge({ titulo: r.title, conteudo: r.rule_text, tipo: 'regra', origem: 'laboratorio', status: 'pendente', fonte: `laboratorio:${id}:${r.category}`, escopo: r.scope, prioridade: Number(r.priority), natureza: r.nature === 'executavel' ? 'executavel' : 'diretriz', regra: rj.executavel }, actor); if (!a.ok) fail(409, a.duplicado ? `Já existe uma regra igual no Cérebro (#${a.duplicado}). Rejeite esta proposta ou edite o texto.` : 'Texto curto demais.', 'duplicado'); itemId = Number(a.id) }
    else if (r.itemStatus === 'pendente') await B.updateItem(itemId, { titulo: r.title, conteudo: r.rule_text, escopo: r.scope, prioridade: Number(r.priority) }, actor)
    const s: any = await B.setStatus(itemId, r.itemStatus === 'desativado' ? 'reactivate' : 'approve', actor, confirmar)
    if (s.precisaConfirmar) return { ok: false, precisaConfirmar: true, conflitos: s.conflitos }
    if (!s.ok) fail(409, s.motivo || 'Não foi possível publicar.', 'invalid')
    brainVersion = Number((await one('SELECT version FROM brain_answers WHERE id = $1', [itemId]))?.version || 1)
  }
  const ver = Number((await one('SELECT COALESCE(MAX(version),0) AS v FROM lab_versions WHERE proposal_id = $1', [id]))?.v || 0) + 1
  await q('INSERT INTO lab_versions (proposal_id, version, rule_text, brain_version, actor, note, tests, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)', [id, ver, r.rule_text, brainVersion, actor, anterior ? 'atualização de regra publicada' : 'primeira publicação', r.tests, nowIso()])
  await q("UPDATE lab_proposals SET state = 'publicada', brain_item_id = $1, published_text = $2, published_at = $3, updated_at = $3 WHERE id = $4", [itemId, r.rule_text, nowIso(), id])
  await evento(id, 'publicada', actor, { versaoAnterior: anterior, versaoAtual: r.rule_text, versaoCerebro: brainVersion, versaoLab: ver })
  return { ok: true, ...(await detalhe(id)) }
}
export async function desativar(id: number, actor: string) {
  const r = await get(id); if (!r.live) fail(409, 'Esta regra não está em produção.', 'invalid')
  await B.setStatus(Number(r.brain_item_id), 'deactivate', actor); await q("UPDATE lab_proposals SET state = 'desativada', updated_at = $1 WHERE id = $2", [nowIso(), id]); await evento(id, 'desativada', actor, {})
  return detalhe(id)
}
export async function reativar(id: number, actor: string) {
  const r = await get(id); if (r.state !== 'desativada' || r.itemStatus !== 'desativado') fail(409, 'Só é possível reativar uma regra desativada.', 'invalid')
  const s: any = await B.setStatus(Number(r.brain_item_id), 'reactivate', actor, true); if (!s.ok) fail(409, s.motivo || 'Não foi possível reativar.', 'invalid')
  // se havia edição pendente (texto diferente do publicado), a proposta volta a rascunho: a produção reativa com o texto publicado
  await q('UPDATE lab_proposals SET state = $1, updated_at = $2 WHERE id = $3', [String(r.rule_text) === String(r.published_text) ? 'publicada' : 'rascunho', nowIso(), id]); await evento(id, 'reativada', actor, {})
  return detalhe(id)
}
/** Volta a regra publicada para a versão anterior (cria nova versão; nada é apagado). */
export async function reverter(id: number, actor: string) {
  const r = await get(id); const vs = await q('SELECT * FROM lab_versions WHERE proposal_id = $1 ORDER BY version DESC LIMIT 2', [id])
  if (vs.length < 2 || r.itemStatus == null) fail(409, 'Não há versão anterior publicada para reverter.', 'invalid')
  const prev = vs[1] as any
  const u: any = await B.updateItem(Number(r.brain_item_id), { conteudo: prev.rule_text }, actor); if (!u.ok) fail(409, 'Não foi possível reverter em produção.', 'invalid')
  if (r.itemStatus === 'desativado') await B.setStatus(Number(r.brain_item_id), 'reactivate', actor, true)
  const ver = Number(vs[0].version) + 1
  await q('INSERT INTO lab_versions (proposal_id, version, rule_text, brain_version, actor, note, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [id, ver, prev.rule_text, Number(u.versao) || null, actor, `revertida para a versão ${prev.version}`, nowIso()])
  await q("UPDATE lab_proposals SET state = 'publicada', rule_text = $1, published_text = $1, tests = NULL, updated_at = $2 WHERE id = $3", [prev.rule_text, nowIso(), id])
  await evento(id, 'revertida', actor, { versaoAnterior: vs[0].rule_text, versaoAtual: prev.rule_text })
  return detalhe(id)
}

/* ---------- conversa ---------- */
export async function mensagens(adminId: number, limit = 60) {
  return (await q('SELECT * FROM lab_messages WHERE admin_id = $1 ORDER BY id DESC LIMIT $2', [adminId, limit])).reverse().map((m: any) => ({ id: Number(m.id), papel: m.role, texto: m.content, dados: parseJ(m.data, null), em: isoOf(m.created_at) }))
}
const guardar = (adminId: number, role: string, content: string, data?: any) => q('INSERT INTO lab_messages (admin_id, role, content, data, created_at) VALUES ($1,$2,$3,$4,$5)', [adminId, role, content.slice(0, 6000), data ? JSON.stringify(data).slice(0, 20000) : null, nowIso()])
async function interpretarComIA(texto: string): Promise<Interpretacao | null> {
  try {
    const { complete } = await import('./provider.js')
    const m = await complete([{ role: 'system', content: 'Você é o Laboratório de IA do Meu Assistente. O administrador descreveu uma correção. Responda SOMENTE um JSON: {"categoria":"uma de ' + CATEGORIAS.join('|') + '","titulo":"até 90 letras","falha":"o que deu errado","quando":"condição de disparo","entao":["passos"],"restricoes":["o que nunca fazer"]}' }, { role: 'user', content: texto }], undefined, { json: true, task: 'analise' })
    const { parseJsonLoose } = await import('./types.js'); const j = parseJsonLoose(String(m.content || '')); if (!j || typeof j !== 'object') return null
    const base = interpretarLocal(texto), arr = (v: any) => (Array.isArray(v) ? v.map((x) => String(x).trim()).filter(Boolean).slice(0, 8) : [])
    const entao = arr(j.entao); if (!entao.length) return null
    return { categoria: (CATEGORIAS as readonly string[]).includes(j.categoria) ? j.categoria : base.categoria, titulo: String(j.titulo || base.titulo).slice(0, 90), falha: String(j.falha || base.falha).slice(0, 400), quando: String(j.quando || '').slice(0, 200), entao, restricoes: arr(j.restricoes), regra: base.regra }
  } catch { return null }
}
async function conversar(u: SessionUser, texto: string, hist: { papel: string; texto: string }[]) {
  try {
    const { complete, engineCfg, engineInstructions } = await import('./provider.js')
    const brainCtx = await B.brainContext(texto, undefined, 'chat').catch(() => '')
    const sys = ['Você é o Laboratório de IA do Meu Assistente, falando com o ADMINISTRADOR. Ajude a testar comandos, achar erros e ensinar regras. Responda em português do Brasil, de forma curta e objetiva.',
      'Você NÃO executa ações reais aqui. Quando o administrador corrigir um comportamento, o sistema cria uma proposta de regra que passa por análise, testes e aprovação dele; explique isso se perguntarem. Nunca diga que já publicou ou salvou uma regra sem a aprovação explícita dele.',
      engineInstructions(await engineCfg()), brainCtx].filter(Boolean).join('\n')
    const m = await complete([{ role: 'system', content: sys }, ...hist.slice(-8).map((h) => ({ role: (h.papel === 'admin' ? 'user' : 'assistant') as 'user' | 'assistant', content: h.texto })), { role: 'user', content: texto }], undefined, {})
    return String(m.content || '').trim() || 'Estou aqui. Descreva uma correção, ou use o Simulador para testar um comando.'
  } catch { return 'A IA não respondeu agora, mas o Laboratório continua funcionando: descreva uma correção para eu criar uma proposta de regra ou use o Simulador.' }
}
export async function conversaAdmin(u: SessionUser, texto: string) {
  const t = String(texto || '').trim(); if (t.length < 2) fail(400, 'Escreva uma mensagem.', 'invalid', 'texto')
  const actor = `admin ${u.id}`, hist = await mensagens(u.id, 12)
  await guardar(u.id, 'admin', t)
  const sim = /^\s*(simul[ae]r?|teste[ar]?)\s*[:\-]\s*(.+)$/is.exec(t)
  if (sim) {
    const s = await simular(u, sim[2], null)
    const txt = `Simulação (nada foi gravado):\n${s.erro ? s.erro : s.resposta || '(sem resposta)'}${s.acoes.length ? '\nAções que a IA tentaria: ' + s.acoes.map((a) => a.resumo).join('; ') : ''}${s.problemas.length ? '\nProblemas: ' + s.problemas.map((p) => p.mensagem).join(' | ') : ''}`
    await guardar(u.id, 'ia', txt, { simulacao: s }); return { resposta: txt, simulacao: s, mensagens: await mensagens(u.id) }
  }
  if (pareceCorrecao(t)) {
    const ia = await interpretarComIA(t), id = await criar(actor, u.id, { texto: t, interpretacao: ia || interpretarLocal(t) })
    const d = await analisar(id, actor), p = d.proposta
    const linhas = [`Entendi. Criei a proposta #${id} (rascunho) na categoria ${p.categoria}.`, p.falha ? `Falha identificada: ${p.falha}` : '', `Regra estruturada: ${p.regra}`,
      p.parecidos.length ? `Regras parecidas já existentes: ${p.parecidos.map((x: any) => `#${x.id} ${x.titulo}`).join('; ')} — confira para não duplicar.` : 'Não encontrei regra parecida.',
      p.conflitos.length ? `Atenção, conflitos: ${p.conflitos.map((c: any) => c.motivo).join(' | ')}` : 'Sem conflitos com as regras ativas.',
      p.riscos.length ? `BLOQUEADA por segurança: ${p.riscos.join(' ')}` : 'Próximos passos: revise o texto, rode os testes (simulação, sem efeito real) e envie para sua aprovação. Nada muda em produção até você publicar.'].filter(Boolean)
    const txt = linhas.join('\n'); await guardar(u.id, 'ia', txt, { propostaId: id }); return { resposta: txt, propostaId: id, proposta: p, mensagens: await mensagens(u.id) }
  }
  const resp = await conversar(u, t, hist); await guardar(u.id, 'ia', resp); return { resposta: resp, mensagens: await mensagens(u.id) }
}
