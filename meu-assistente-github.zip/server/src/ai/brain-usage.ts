// Registro de uso do Cérebro: quando um conhecimento, diretriz ou regra foi usado e qual resposta/ação influenciou.
import { q, nowIso } from '../db/index.js'

export type UsoRole = 'consulta' | 'diretriz' | 'regra'
export interface Uso {
  itemId: number; version: number; role: UsoRole
  action: 'respondeu' | 'contexto_ia' | 'bloqueou' | 'abriu_modulo' | 'abriu_chamado' | 'notificou_admins' | 'anexou' | 'negado' | 'falhou' | 'suprimida'
  effect: string; result?: string
}
export interface UsoCtx { canal: 'chat' | 'agente' | 'painel'; userId?: number | null; businessId?: number | null; conversationId?: string | null; messageId?: number | null }

/** Grava o uso. Diretrizes que entram no contexto da IA são registradas uma vez por conversa/dia, para não encher o histórico. */
export async function registrarUso(usos: Uso[], c: UsoCtx) {
  if (!usos.length) return
  try {
    let jaHoje = new Set<number>()
    if (c.conversationId && usos.some((u) => u.role === 'diretriz')) {
      const ini = new Date(); ini.setHours(0, 0, 0, 0)
      const rows = await q("SELECT item_id FROM brain_usage WHERE conversation_id = $1 AND action = 'contexto_ia' AND role = 'diretriz' AND created_at >= $2", [c.conversationId, ini.toISOString()])
      jaHoje = new Set(rows.map((r: any) => Number(r.item_id)))
    }
    const vistos = new Set<string>()
    for (const u of usos) {
      if (u.role === 'diretriz' && jaHoje.has(u.itemId)) continue
      const k = `${u.itemId}:${u.action}`; if (vistos.has(k)) continue; vistos.add(k)
      await q(`INSERT INTO brain_usage (item_id, version, channel, user_id, business_id, conversation_id, message_id, role, action, effect, result, created_at)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [u.itemId, u.version, c.canal, c.userId ?? null, c.businessId ?? null, c.conversationId ?? null, c.messageId ?? null, u.role, u.action, String(u.effect || '').slice(0, 300), u.result ? String(u.result).slice(0, 300) : null, nowIso()])
      if (u.role !== 'diretriz' && (u.action === 'respondeu' || u.action === 'bloqueou' || u.action === 'abriu_modulo' || u.action === 'abriu_chamado' || u.action === 'notificou_admins' || u.action === 'anexou'))
        await q('UPDATE brain_answers SET uses = uses + 1 WHERE id = $1', [u.itemId]) // sem mexer em updated_at (não invalida o cache)
    }
  } catch (e: any) { console.error('[cérebro] registro de uso falhou:', e?.message) }
}
