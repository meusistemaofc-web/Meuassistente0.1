// Regras EXECUTÁVEIS do Cérebro: comportamento que o sistema realmente cumpre (não é texto para a IA "tentar" seguir).
// Cada ação está ligada a uma função real do sistema, valida o público/permissão e registra o resultado:
//   bloquear          → recusa o assunto com a mensagem cadastrada; nenhuma IA é chamada
//   abrir_modulo      → mostra o cartão do módulo (só se o módulo existe e está ligado no painel)
//   abrir_chamado     → cria um chamado de suporte de verdade (mesma função da Central de Ajuda, com limite por hora)
//   notificar_admins  → envia uma notificação real a todos os administradores ativos
//   anexar            → acrescenta um texto fixo ao fim das respostas (ex.: aviso legal)
// Ações que precisam de um usuário logado só valem no chat do usuário; no chat dos agentes de empresas valem bloquear e anexar.
import { fail } from '../lib/http.js'
import { q, one } from '../db/index.js'
import { MOD_CATALOG } from '../lib/modcatalog.js'
import { modules } from '../lib/usermod.js'
import { effectivePermissions } from '../lib/account.js'
import { notify } from '../lib/notify.js'
import type { SessionUser } from '../lib/session.js'
import type { Uso } from './brain-usage.js'

export const ACTIONS: Record<string, { label: string; terminal: boolean; precisaUsuario: boolean }> = {
  bloquear: { label: 'Recusar o assunto (sem IA)', terminal: true, precisaUsuario: false },
  abrir_modulo: { label: 'Abrir um módulo do app', terminal: true, precisaUsuario: true },
  abrir_chamado: { label: 'Abrir chamado de suporte', terminal: true, precisaUsuario: true },
  notificar_admins: { label: 'Avisar os administradores', terminal: false, precisaUsuario: true },
  anexar: { label: 'Acrescentar texto à resposta', terminal: false, precisaUsuario: false },
}
export const AUDIENCES = ['todos', 'empresas', 'admin'] as const
export const SCOPES = ['chat', 'agentes', 'todos'] as const
export const CHAMADO_CATS = ['duvida', 'problema', 'sugestao', 'solicitacao', 'outros']
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const txt = (v: any, n: number) => String(v ?? '').trim().slice(0, n)

export interface RegraValida { acao: string; gatilho: string[]; params: Record<string, any>; publico: string }
/** Valida o cadastro de uma regra executável. Só aceita ações reais, parâmetros válidos e coerentes com o escopo. */
export function validateRule(r: any, escopo: string): RegraValida {
  const acao = String(r?.acao || '')
  const A = ACTIONS[acao]; if (!A) fail(400, 'Escolha uma ação válida para a regra executável.', 'invalid')
  if (!(SCOPES as readonly string[]).includes(escopo)) fail(400, 'Escopo inválido.', 'invalid')
  if (escopo !== 'chat' && A.precisaUsuario) fail(400, `A ação "${A.label}" só funciona no chat do usuário logado. Use o escopo "Chat do usuário" ou outra ação.`, 'invalid')
  const gatilho = [...new Set((Array.isArray(r?.gatilho) ? r.gatilho : String(r?.gatilho || '').split(/[\n;]+/)).map((g: any) => norm(String(g))).filter((g: string) => g.length >= 3 && g.length <= 80))].slice(0, 20) as string[]
  if (!gatilho.length && acao !== 'anexar') fail(400, 'Informe ao menos uma frase-gatilho (ex.: "quero cancelar").', 'invalid')
  const publico = (AUDIENCES as readonly string[]).includes(r?.publico) ? String(r.publico) : 'todos'
  if (publico !== 'todos' && escopo !== 'chat') fail(400, 'Público restrito (empresas/administradores) só vale no chat do usuário logado.', 'invalid')
  const p = r?.params && typeof r.params === 'object' ? r.params : {}
  const params: Record<string, any> = {}
  if (acao === 'bloquear') params.mensagem = txt(p.mensagem, 300) || 'Esse assunto eu não posso tratar por aqui.'
  else if (acao === 'abrir_modulo') {
    const m = MOD_CATALOG.find((x) => x.key === String(p.modulo))
    if (!m || m.indisponivel) fail(400, 'Escolha um módulo existente e disponível do app.', 'invalid')
    params.modulo = m!.key; params.mensagem = txt(p.mensagem, 200)
  } else if (acao === 'abrir_chamado') {
    params.categoria = CHAMADO_CATS.includes(String(p.categoria)) ? String(p.categoria) : 'solicitacao'
    params.assunto = txt(p.assunto, 140) || 'Solicitação feita pelo chat'
    params.mensagem = txt(p.mensagem, 300) || 'Abri o chamado {protocolo} para você. Nossa equipe responde em breve.'
  } else if (acao === 'notificar_admins') params.titulo = txt(p.titulo, 100) || 'Aviso do Cérebro'
  else if (acao === 'anexar') { params.texto = txt(p.texto, 300); if (params.texto.length < 3) fail(400, 'Escreva o texto que será acrescentado às respostas.', 'invalid') }
  return { acao, gatilho, params, publico }
}

export interface RuleCtx { user: SessionUser | null; canal: 'chat' | 'agente'; texto: string; businessId?: number | null; conversationId?: string | null; dryRun?: boolean }
export interface RuleOutcome { reply: string | null; terminal: boolean; rodape: string[]; usos: Uso[]; viaRegra: boolean; simulado: string[] }

const dentro = (nt: string, frase: string) => ` ${nt} `.includes(` ${frase} `)
async function publicoOk(u: SessionUser | null, pub: string) {
  if (pub === 'todos') return true
  if (!u) return false
  if (pub === 'admin') return u.role === 'admin' || u.role === 'superadmin' || effectivePermissions(u).length > 0
  if (pub === 'empresas') return !!(await one('SELECT id FROM businesses WHERE owner_id = $1 LIMIT 1', [u.id]))
  return false
}
/** Avalia e EXECUTA as regras executáveis ativas que casam com a mensagem (por prioridade). Com dryRun nada é executado: só mostra o que aconteceria. */
export async function applyRules(c: RuleCtx): Promise<RuleOutcome> {
  const out: RuleOutcome = { reply: null, terminal: false, rodape: [], usos: [], viaRegra: false, simulado: [] }
  const K = await import('./knowledge.js')
  const escopos = c.canal === 'chat' ? ['chat', 'todos'] : ['agentes', 'todos']
  const regras = (await K.activeKnowledge()).filter((it) => it.nature === 'executavel' && it.rule_action && escopos.includes(it.scope)).sort((a, b) => b.priority - a.priority || a.id - b.id)
  if (!regras.length) return out
  const nt = norm(c.texto)
  for (const it of regras) {
    const A = ACTIONS[it.rule_action!]; if (!A) continue
    const gat: string[] = (() => { try { return JSON.parse(it.rule_trigger || '[]') } catch { return [] } })()
    const casou = it.rule_action === 'anexar' ? (!gat.length || gat.some((g) => dentro(nt, g))) : gat.some((g) => dentro(nt, g))
    if (!casou) continue
    const params: any = (() => { try { return JSON.parse(it.rule_params || '{}') } catch { return {} } })()
    const uso = (action: Uso['action'], effect: string, result?: string) => out.usos.push({ itemId: it.id, version: it.version, role: 'regra', action, effect, result })
    if (!(await publicoOk(c.user, it.rule_audience || 'todos'))) { uso('negado', `Regra "${it.titulo}" não executada: o público da regra é "${it.rule_audience}" e o usuário não tem esse perfil.`); continue }
    if (A.precisaUsuario && !c.user) { uso('negado', `Regra "${it.titulo}" não executada: a ação exige usuário logado.`); continue }
    if (A.terminal && out.terminal) { uso('suprimida', `Regra "${it.titulo}" não executada: outra regra de prioridade maior já decidiu esta mensagem.`); continue }
    const sim = !!c.dryRun
    try {
      if (it.rule_action === 'bloquear') { out.reply = String(params.mensagem || ''); out.terminal = true; uso('bloqueou', `Recusou o assunto e não chamou nenhuma IA ("${it.titulo}").`, out.reply) }
      else if (it.rule_action === 'abrir_modulo') {
        const m = MOD_CATALOG.find((x) => x.key === params.modulo)
        const mods = await modules()
        if (!m || m.indisponivel) { uso('falhou', `Módulo "${params.modulo}" não existe ou não está disponível.`); continue }
        if ((mods as any)[m.key] === false) { uso('negado', `Módulo ${m.label} desligado pelo administrador: regra "${it.titulo}" não executada.`); continue }
        out.reply = `${params.mensagem || `${m.label} — ${m.desc}`} ⟦mod:${m.key}⟧`; out.terminal = true; uso('abriu_modulo', `Mostrou o módulo ${m.label} ("${it.titulo}").`, m.route)
      } else if (it.rule_action === 'abrir_chamado') {
        out.terminal = true
        if (sim) { out.reply = String(params.mensagem).replace('{protocolo}', 'AJ-…'); out.simulado.push(`Abriria um chamado (${params.categoria}): "${params.assunto}"`); uso('abriu_chamado', `Simulação: abriria um chamado "${params.assunto}".`, 'simulado'); continue }
        const { criarChamado } = await import('../routes/tickets.js')
        const desc = `Chamado aberto automaticamente pela regra "${it.titulo}" a partir da mensagem do usuário:\n${c.texto}`
        try { const t: any = await criarChamado(c.user, { categoria: params.categoria, assunto: params.assunto, texto: desc }); out.reply = String(params.mensagem).replace('{protocolo}', t.protocolo); uso('abriu_chamado', `Abriu o chamado ${t.protocolo} ("${it.titulo}").`, t.protocolo) }
        catch (e: any) { out.reply = e?.message || 'Não consegui abrir o chamado agora.'; uso('falhou', `Chamado não aberto: ${e?.message || 'erro'}`) }
      } else if (it.rule_action === 'notificar_admins') {
        const adm = await q("SELECT id FROM users WHERE role IN ('admin','superadmin') AND status = 'active'")
        if (sim) { out.simulado.push(`Avisaria ${adm.length} administrador(es): "${params.titulo}"`); uso('notificou_admins', `Simulação: avisaria ${adm.length} administrador(es).`, 'simulado'); continue }
        const nome = String(c.user!.name || '').split(' ')[0]; let n = 0
        for (const a of adm) { await notify(Number(a.id), { type: 'brain_rule', title: String(params.titulo), body: `${nome}: ${c.texto.slice(0, 140)}`, link: '/admin?aba=cerebro', ref: `brain:${it.id}:${c.user!.id}:${Date.now()}:${a.id}` }); n++ }
        uso('notificou_admins', `Avisou ${n} administrador(es) ("${it.titulo}").`, String(n))
      } else if (it.rule_action === 'anexar') { out.rodape.push(String(params.texto)); uso('anexou', `Acrescentou o texto fixo da regra "${it.titulo}" à resposta.`) }
      if (sim) out.simulado.push(`Regra #${it.id} "${it.titulo}" (${A.label})`)
    } catch (e: any) { uso('falhou', `Erro ao executar "${it.titulo}": ${e?.message || 'falha'}`) }
  }
  out.viaRegra = out.terminal
  return out
}
