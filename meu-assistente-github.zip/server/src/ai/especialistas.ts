// ESPECIALISTAS DINÂMICOS — os domínios que JÁ existem (agenda pessoal, finanças, tarefas, compras, memória, Agenda IA da
// empresa, CRM, análise de negócio, acolhimento, conhecimento geral) viram especialistas. Um coordenador central escolhe
// de 1 a 3 por mensagem, monta um quadro de contexto compartilhado e prioriza as ferramentas certas — sem remover nenhuma
// (a IA continua podendo usar tudo o que podia antes). Nenhum especialista novo cria ferramentas próprias.
import type { Analise } from './cognition.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
type Tool = { function: { name: string } }

export interface Especialista {
  id: string; nome: string
  sinais: RegExp                       // palavras que indicam o domínio
  ops?: string[]                        // operações da aprendizagem adaptativa ligadas ao domínio
  ferramentas: (nome: string) => boolean
  precisaFerramenta?: boolean           // só entra se alguma ferramenta dele estiver disponível para o usuário
  instrucoes: string
}

export const ESPECIALISTAS: Especialista[] = [
  { id: 'agenda', nome: 'Agenda pessoal', sinais: /\b(agend\w*|compromisso\w*|reuni\w*|consulta\w*|horario\w*|agenda|marc(a|ar|ou|que)\b|remarc\w*|desmarc\w*|evento\w*)\b/, ops: ['agendamento'],
    ferramentas: (n) => ['create_appointment', 'update_appointment', 'get_agenda'].includes(n), precisaFerramenta: true,
    instrucoes: 'Agenda pessoal: confirme data e horário por extenso (ex.: "terça, 18/11, às 14h"); havendo dúvida de conflito, consulte get_agenda antes de marcar; nunca marque sem data. Para ALTERAR um compromisso existente use update_appointment com o id (de get_agenda) — nunca crie outro; sinal em % e em R$ são coisas diferentes.' },
  { id: 'financas', nome: 'Finanças', sinais: /\b(gast\w*|pagu\w*|receb\w*|dinheiro|saldo|financ\w*|boleto\w*|fatura\w*|reais|r\$|orcamento|economi\w*|despesa\w*|receita\w*|salario|pix|cartao|entrou|entrad\w*|ganhei|ganho\w*|conto|pila|uber|conta de (luz|agua|internet|telefone|gas))\b|r\$/, ops: ['financeiro'],
    ferramentas: (n) => ['register_transaction', 'create_bill', 'get_finance'].includes(n), precisaFerramenta: true,
    instrucoes: 'Finanças: valores sempre em R$ com centavos; nunca invente números — consulte get_finance; diferencie gasto, receita e conta a pagar; correção de valor atualiza o lançamento existente, nunca cria outro.' },
  { id: 'tarefas', nome: 'Tarefas e lembretes', sinais: /\b(tarefa\w*|lembr\w*|me avis\w*|pendenc\w*|a fazer|to-?do|conclu\w*|terminei|finalizei)\b/, ops: ['tarefa', 'lembrete'],
    ferramentas: (n) => ['create_task', 'create_reminder', 'complete_task'].includes(n), precisaFerramenta: true,
    instrucoes: 'Tarefas e lembretes: título curto e claro; lembrete sempre com quando avisar; ao concluir, cite qual tarefa foi concluída.' },
  { id: 'compras', nome: 'Lista de compras', sinais: /\b(lista de compras|compras|mercado|supermercado|feira|comprar|(na|da|pra|para a) lista)\b/, ops: ['compra'],
    ferramentas: (n) => n === 'add_shopping_items', precisaFerramenta: true,
    instrucoes: 'Compras: um item por entrada, com quantidade quando dita; não duplique itens já citados na mesma conversa.' },
  { id: 'memoria', nome: 'Memória pessoal', sinais: /\b(lembre que|lembra que|guarde|guarda isso|anote que|anota que|nao esqueca|meu nome e|me chamo|prefiro|minha preferencia|anotacao|anote|(guarda|salva|salve|grava|grave) (que|isso|essa|esse|ai))\b/,
    ferramentas: (n) => ['save_memory', 'create_note'].includes(n), precisaFerramenta: true,
    instrucoes: 'Memória: só guarde quando o usuário pedir ou concordar; se já existir algo parecido, atualize em vez de repetir; nunca guarde senhas, documentos ou dados de cartão.' },
  { id: 'agenda_empresa', nome: 'Agenda da empresa', sinais: /\b(horarios? da (empresa|loja)|minha (empresa|loja)|clientes? (marcad|agendad)|atendimento\w*|fech\w* (a )?agenda|abr\w* (a )?agenda|agenda da (empresa|loja)|disponibilidade|vagas?)\b/,
    ferramentas: (n) => n.startsWith('agenda_empresa_'), precisaFerramenta: true,
    instrucoes: 'Agenda da empresa: decisões que afetam clientes (fechar datas, cancelar) só com confirmação explícita do dono; mostre o impacto antes.' },
  { id: 'crm', nome: 'CRM', sinais: /\b(clientes?|lead\w*|funil|crm|contatos?|negociac\w*|follow\w*|retorno|prospect\w*|etapa)\b/,
    ferramentas: (n) => n.startsWith('crm_'), precisaFerramenta: true,
    instrucoes: 'CRM: identifique o cliente certo antes de alterar; ao mover etapa, diga de qual para qual; nunca envie mensagens em nome do usuário.' },
  { id: 'negocio', nome: 'Análise do negócio', sinais: /\b(faturamento|faturei|vendas|vendi|desempenho|indicador\w*|ticket medio|lucro|relatorio|metas?|resultado\w* da (loja|empresa)|como (esta|foi) (a|minha) (loja|empresa))\b/,
    ferramentas: (n) => n.startsWith('negocio_'), precisaFerramenta: true,
    instrucoes: 'Análise do negócio: use só números das ferramentas; compare com o período anterior quando houver; termine com 1 a 3 ações práticas.' },
  { id: 'acolhimento', nome: 'Acolhimento', sinais: /\b(triste|ansios\w*|cansad\w*|desanimad\w*|estressad\w*|sobrecarregad\w*|preocupad\w*|sozinh\w*|desabaf\w*)\b/,
    ferramentas: () => false,
    instrucoes: 'Acolhimento: ouça e valide o sentimento com frases simples; não minimize; só depois, se fizer sentido, ofereça ajuda prática (organizar o dia, um lembrete).' },
]
export const GERAL: Especialista = { id: 'geral', nome: 'Conhecimento geral', sinais: /$^/, ferramentas: () => false,
  instrucoes: 'Conhecimento geral: responda com clareza; se for informação que muda com o tempo e você não puder verificar, diga isso.' }

export interface Selecao { ids: string[]; principal: string; nomes: string[]; pontos: Record<string, number> }
/** Coordenador central: pontua cada especialista pela mensagem, pela intenção e pelo fio da conversa; escolhe até 3. */
export function selecionar(text: string, an: Analise, tools: Tool[], anterior: string[] = []): Selecao {
  const s = nrm(text), nomes = new Set(tools.map((t) => t.function.name)), pontos: Record<string, number> = {}
  for (const e of ESPECIALISTAS) {
    if (e.precisaFerramenta && ![...nomes].some((n) => e.ferramentas(n))) continue
    let p = (s.match(new RegExp(e.sinais.source, 'g')) || []).length * 2
    if (e.ops && an.operacoes.some((o) => e.ops!.includes(o))) p += 2
    if (e.id === 'acolhimento' && (an.tipo === 'desabafo' || an.emocao === 'ansioso')) p += 4
    if (e.id === 'agenda_empresa' && p > 0 && /\b(empresa|loja|clientes?|negocio|estabelecimento)\b/.test(s)) p += 3 // mais específico que a agenda pessoal
    if (e.id === 'financas' && /\d/.test(s) && /\b(gastei|paguei|recebi|ganhei|vendi|comprei)\b/.test(s)) p += 2
    if (p === 0 && anterior.includes(e.id) && (an.completude === 'eliptica' || an.tipo === 'continuacao' || an.tipo === 'confirmacao' || an.tipo === 'correcao')) p = 1 // continuação mantém o especialista do turno anterior
    if (p > 0) pontos[e.id] = p
  }
  const ids = Object.entries(pontos).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id]) => id)
  if (!ids.length) ids.push('geral')
  const por = (id: string) => ESPECIALISTAS.find((e) => e.id === id) || GERAL
  return { ids, principal: ids[0], nomes: ids.map((i) => por(i).nome), pontos }
}
export const especialista = (id: string) => ESPECIALISTAS.find((e) => e.id === id) || GERAL

/** Ferramentas dos especialistas escolhidos vêm primeiro (a IA tende a preferir as primeiras); nenhuma é removida. */
export function ordenarFerramentas<T extends Tool>(tools: T[], sel: Selecao): T[] {
  const rel = (t: T) => sel.ids.findIndex((id) => especialista(id).ferramentas(t.function.name))
  return [...tools].map((t, i) => ({ t, i, r: rel(t) })).sort((a, b) => (a.r < 0 ? 99 : a.r) - (b.r < 0 ? 99 : b.r) || a.i - b.i).map((x) => x.t)
}

/** Texto do coordenador para a IA: quem está atuando e as diretrizes de cada especialista. */
export function contextoCoordenacao(sel: Selecao): string {
  const L = [`COORDENAÇÃO DE ESPECIALISTAS: atuando agora — ${sel.nomes.map((n, i) => (i === 0 ? `${n} (principal)` : n)).join(', ')}. Responda como uma só voz, integrando o que cada um sabe.`]
  for (const id of sel.ids) L.push('- ' + especialista(id).instrucoes)
  return L.join('\n')
}
