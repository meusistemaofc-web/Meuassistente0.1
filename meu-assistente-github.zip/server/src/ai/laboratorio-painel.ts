// Fase 9 — Laboratório de Inteligência: visão geral, centro de diagnóstico, central de melhorias, controle de evolução e auditoria.
// Tudo aqui REAPROVEITA os indicadores e fluxos existentes (avaliação contínua, aprendizado contínuo, Laboratório de IA,
// multiagente, execução, saúde dos provedores) e só lê números agregados — nenhum texto de conversa de usuário.
// Cada métrica é marcada como REAL (medida no uso), ESTIMATIVA (nota automática interna) ou EXPERIMENTAL (cenários sintéticos).
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import * as POL from './politica.js'
import * as LB from './laboratorio.js'

type Tipo = 'real' | 'estimativa' | 'experimental'
const M = (id: string, nome: string, valor: number | null, unidade: string, tipo: Tipo, fonte: string, extra: Record<string, any> = {}) => ({ id, nome, valor, unidade, tipo, fonte, ...extra })
const ultimoRun = async (kind: string) => { const r = await one(`SELECT result, ok, created_at FROM intel_runs WHERE kind = $1 ORDER BY id DESC LIMIT 1`, [kind]).catch(() => null); return r ? { ...J<any>(r.result, {}), ok: r.ok === true || r.ok === 1 || r.ok === 't', em: String(r.created_at) } : null }

/* ======================= 1) painel central ======================= */
export async function painelCentral() {
  const AVAL = await import('./avaliacao.js'), N = await import('./nucleo.js'), COG = await import('./cognition.js'), AG = await import('./agentes.js'), EX = await import('./execucao.js'), H = await import('./health.js'), T = await import('../lib/timing.js'), APR = await import('./aprendizado.js'), PR = await import('./preditivo.js'), LA = await import('./laboratorio-agentes.js')
  const [intel, cog, ma, exc, pred, apr, lab] = await Promise.all([N.intelCfg(), COG.cogCfg(), AG.maCfg(), EX.execCfg(), PR.predCfg().catch(() => ({ ativo: true }) as any), POL.aprCfg(), LB.labCfg()])
  const ind = await AVAL.indicadores(), mult = await AG.indicadoresMultiagente(), exi = await EX.indicadores(), tempos: any = T.resumoTempos(), rt = await H.runtime().catch(() => ({ breakers: {} }) as any)
  const bat = await ultimoRun('bateria'), diag = await ultimoRun('diagnostico'), mon = await AVAL.ultimosAlertas()
  const componentes = [
    { id: 'nucleo', nome: 'Núcleo de inteligência', ligado: !!intel.ativo }, { id: 'cognicao', nome: 'Cérebro cognitivo', ligado: !!cog.ativo }, { id: 'multiagente', nome: 'Coordenação multiagente', ligado: !!ma.ativo },
    { id: 'memoria', nome: 'Memória por relevância', ligado: !!intel.memoria }, { id: 'autoverificacao', nome: 'Autoverificação', ligado: !!intel.autoverificacao }, { id: 'aprendizado', nome: 'Aprendizado contínuo', ligado: !!apr.ativo },
    { id: 'preditivo', nome: 'Inteligência preditiva', ligado: pred.ativo !== false }, { id: 'execucao', nome: 'Autonomia operacional', ligado: !!exc.ativo }, { id: 'laboratorio', nome: 'Laboratório', ligado: !!lab.ativo },
  ]
  const provedoresPausados = Object.keys(rt.breakers || {}).length
  const estado = !intel.ativo || !cog.ativo ? 'desligado' : provedoresPausados || (bat && !bat.ok) || (diag && diag.taxa < 100) ? 'atenção' : 'operacional'
  const s = ind.semanas as any
  const arena = (await q("SELECT score, created_at, kind FROM lab_runs WHERE kind IN ('arena','continuo') AND status = 'concluida' ORDER BY id DESC LIMIT 20").catch(() => [])) as any[]
  const ts = (await APR.turnos(30)).turnos
  const metricas = [
    M('aprovacao', 'Avaliações positivas dos usuários (7 dias)', ind.feedback.taxa7d, '%', 'real', `${ind.feedback.n7d} avaliação(ões) com 👍/👎`, { anterior: ind.feedback.taxa7dAnterior }),
    M('tempo', 'Tempo médio de resposta com IA', tempos.comIA?.mensagens ? tempos.comIA.totalMedia : null, 'ms', 'real', `últimas ${tempos.comIA?.mensagens || 0} mensagens deste servidor`, { p95: tempos.comIA?.totalP95 ?? null }),
    M('tarefas', 'Taxa de sucesso das tarefas executadas', exi.taxaSucesso, '%', 'real', `${exi.total} execução(ões) em 30 dias, conferidas no sistema`),
    M('agentes', 'Sucesso dos agentes acionados', mult.agentes.reduce((a: number, x: any) => a + x.acionamentos, 0) ? Math.round(mult.agentes.reduce((a: number, x: any) => a + (x.sucesso || 0) * x.acionamentos, 0) / mult.agentes.reduce((a: number, x: any) => a + x.acionamentos, 0)) : null, '%', 'real', `${mult.comAgentes} mensagem(ns) com agentes`),
    M('precisao', 'Precisão das respostas', s.atual.precisao, '/100', 'estimativa', `nota automática interna de ${s.atual.n} resposta(s) nos últimos 7 dias`, { anterior: s.anterior.precisao }),
    M('naturalidade', 'Naturalidade conversacional', s.atual.naturalidade, '/100', 'estimativa', `nota automática interna de ${s.atual.n} resposta(s) nos últimos 7 dias`, { anterior: s.anterior.naturalidade }),
    M('qualidade', 'Qualidade geral', s.atual.geral, '/100', 'estimativa', 'média das notas internas (precisão, coerência, naturalidade, clareza, contexto, resolução)', { anterior: s.anterior.geral }),
    M('sucesso', 'Sucesso das respostas (ponderado por usuário)', APR.taxaPorUsuario(ts, (t) => t.resultado === 'sucesso'), '%', 'estimativa', `${ts.length} resposta(s) em 30 dias — combina avaliações dos usuários e notas internas`),
    M('arena', 'Pontuação na Arena', arena[0] ? Number(arena[0].score) : null, '/100', 'experimental', 'cenários sintéticos do Laboratório (não é uso real)', { anterior: arena[1] ? Number(arena[1].score) : null }),
    M('bateria', 'Bateria automática do núcleo', bat ? Math.round((bat.aprovados / bat.total) * 100) : null, '%', 'experimental', bat ? `${bat.aprovados}/${bat.total} cenários · ${new Date(bat.em).toLocaleString('pt-BR')}` : 'ainda não rodou'),
    M('diagnostico', 'Diagnóstico do corpus', diag?.taxa ?? null, '%', 'experimental', diag ? `${diag.aprovadas}/${diag.verificacoes} verificações` : 'ainda não rodou'),
  ]
  const falhas = [
    ...(mon?.alertas || []).map((a: string) => ({ origem: 'monitor de regressão', texto: a, tipo: 'real' as Tipo })),
    ...(bat?.falhas || []).map((f: any) => ({ origem: 'bateria automática', texto: `${f.area}: ${f.descricao}`, tipo: 'experimental' as Tipo })),
    ...(diag?.falhas || []).slice(0, 10).map((f: any) => ({ origem: 'diagnóstico', texto: `${f.area} · ${f.componente} (${f.id})`, tipo: 'experimental' as Tipo })),
    ...exi.etapas.falhasPorClasse.map((f: any) => ({ origem: 'execução', texto: `${f.n} etapa(s) com falha: ${f.nome}`, tipo: 'real' as Tipo })),
    ...Object.entries(rt.breakers || {}).map(([id, b]: any) => ({ origem: 'provedores de IA', texto: `${id} pausado (${b.reason || b.kind || 'falhas seguidas'})`, tipo: 'real' as Tipo })),
    ...mult.agentes.filter((a: any) => a.pausado).map((a: any) => ({ origem: 'agentes', texto: `${a.nome} pausado pelo disjuntor`, tipo: 'real' as Tipo })),
  ]
  const lab9 = await LA.estatisticas()
  return {
    nucleo: { estado, componentes, provedoresPausados, ultimaBateria: bat ? { ok: bat.ok, em: bat.em } : null, ultimoDiagnostico: diag ? { taxa: diag.taxa, em: diag.em } : null },
    metricas,
    agentes: [...mult.agentes.map((a: any) => ({ id: a.id, nome: a.nome, acionamentos: a.acionamentos, sucesso: a.sucesso, msMedio: a.msMedio, pausado: a.pausado, tipo: 'real' })),
      ...Object.entries(lab9).filter(([k]) => k.startsWith('lab:')).map(([k, v]: any) => ({ id: k, nome: k.slice(4) + ' (laboratório)', ...v, tipo: 'real' }))],
    especialistas: ind.especialistas.map((e: any) => ({ ...e, tipo: 'estimativa' })),
    falhas,
    evolucao: { semanal: APR.evolucao(ts), arena: arena.reverse().map((r) => ({ em: String(r.created_at), nota: Number(r.score), tipo: r.kind })) },
    legenda: { real: 'medido no uso real (avaliações dos usuários, tempos, execuções conferidas)', estimativa: 'nota automática interna por resposta — útil para tendência, não é verdade absoluta', experimental: 'cenários sintéticos do laboratório, bateria e corpus — não envolvem usuários' },
    config: lab,
  }
}

/* ======================= 5) centro de diagnóstico ======================= */
export interface Achado { id: string; tipo: string; tipoNome: string; titulo: string; severidade: 'alta' | 'média' | 'baixa'; evidencia: string; fonte: Tipo; area: string; causa: string; sugestao: string; mudanca?: POL.Mudanca | null }
const TIPO_NOME: Record<string, string> = { inconsistencia: 'Respostas inconsistentes', interpretacao: 'Falhas de interpretação', recorrente: 'Erros recorrentes', memoria: 'Problemas de memória', execucao: 'Falhas de execução', desempenho: 'Gargalos de desempenho', agente: 'Agentes com baixo desempenho', qualidade: 'Qualidade das respostas' }
const CAUSA: Record<string, [string, string]> = {
  inconsistencia: ['Valores citados sem fonte ou contribuições divergentes entre agentes; a revisão automática nem sempre consegue corrigir.', 'Ativar a revisão automática sempre na área afetada (política: raciocinio.revisarSempre) e criar desafios de Arena com valores para acompanhar.'],
  interpretacao: ['Pedido elíptico/ambíguo ou contexto da conversa não aproveitado (o usuário precisou repetir ou corrigir).', 'Pedir confirmação dos dados ambíguos antes de agir na área (política: qualidade.perguntarAntes) e reforçar com desafios de interpretação contextual.'],
  recorrente: ['O mesmo problema aparece em várias semanas e para vários usuários — não é caso isolado.', 'Abrir uma proposta específica (regra no Laboratório de IA ou ajuste de parâmetro) e acompanhar a área nos desafios contínuos.'],
  memoria: ['Memórias relevantes não entram no contexto (limite de fatos/caracteres) ou não são consideradas na resposta.', 'Aumentar o número de memórias recuperadas (política: memoria.maxFatos) e testar com desafios de Memória antes de liberar.'],
  execucao: ['Ferramenta chamada com dados incompletos, permissão, limite do plano ou falha temporária.', 'Orientar a conferência dos dados antes da ferramenta (política: ferramentas.dicas) e revisar a validação da operação; falhas temporárias recorrentes indicam problema de infraestrutura.'],
  desempenho: ['Etapa lenta (modelo, agentes, ferramentas ou preparo) ou excesso de consultas ao banco por mensagem.', 'Investigar a etapa indicada: reduzir agentes acionados, usar o cache das configurações, revisar índices e o tempo dos provedores de IA. Correção técnica (código/infraestrutura) — não é automática.'],
  agente: ['Agente com tempo esgotado, contribuição vazia ou resultado pior que a resposta direta.', 'Testar o agente no Laboratório de agentes, ajustar as instruções numa cópia experimental e comparar; enquanto isso, a política pode evitá-lo na área (agentes.evitar).'],
  qualidade: ['Respostas longas, em bloco único ou com tom robótico na área.', 'Ajustar o estilo da área (política: qualidade.estilo) e medir com desafios de Comunicação.'],
}
const achado = (tipo: string, area: string, titulo: string, severidade: Achado['severidade'], evidencia: string, fonte: Tipo, mudanca: POL.Mudanca | null = null): Achado =>
  ({ id: `${tipo}|${area}|${titulo}`.slice(0, 160), tipo, tipoNome: TIPO_NOME[tipo] || tipo, titulo, severidade, evidencia, fonte, area, causa: CAUSA[tipo]?.[0] || '', sugestao: CAUSA[tipo]?.[1] || '', mudanca })
export async function diagnosticar(o: { gerar?: boolean; por?: string } = {}) {
  const APR = await import('./aprendizado.js'), AG = await import('./agentes.js'), EX = await import('./execucao.js'), T = await import('../lib/timing.js'), H = await import('./health.js'), LA = await import('./laboratorio-agentes.js')
  const cfg = await POL.aprCfg(), pol = await POL.versao(cfg.versaoAtiva), ts = (await APR.turnos(30)).turnos, A: Achado[] = []
  // autodiagnóstico da Fase 6 (por área): interpretação, execução, qualidade, satisfação, velocidade
  const MAPA: Record<string, string> = { 'execução': 'execucao', 'interpretação': 'interpretacao', qualidade: 'qualidade', velocidade: 'desempenho', operacional: 'agente', 'satisfação': 'interpretacao' }
  for (const d of await APR.autodiagnostico(ts, cfg.minAmostra)) {
    const tipo = MAPA[d.tipo] || 'qualidade', area = d.area
    const mud: POL.Mudanca | null = tipo === 'interpretacao' && APR.nomeArea(area) !== area && !pol.qualidade.perguntarAntes.includes(area) ? { op: 'add', caminho: 'qualidade.perguntarAntes', valor: area }
      : tipo === 'execucao' && /^[a-z_]{3,40}$/.test(area) && !APR.nomeArea(area).includes(' ') && area.includes('_') && !pol.ferramentas.dicas[area] ? { op: 'set', caminho: `ferramentas.dicas.${area}`, valor: 'confirmar_dados' }
      : tipo === 'qualidade' && APR.nomeArea(area) !== area && /naturalidade|clareza/.test(d.descricao) && pol.qualidade.estilo[area] !== 'curta' ? { op: 'set', caminho: `qualidade.estilo.${area}`, valor: 'curta' } : null
    A.push(achado(tipo, area, `${d.descricao} (${APR.nomeArea(area)})`, d.severidade, d.evidencia, tipo === 'execucao' || tipo === 'desempenho' ? 'real' : 'estimativa', mud))
  }
  // respostas inconsistentes: valores sem fonte na autoverificação e divergências entre agentes
  const l2 = ((await q('SELECT level2, specialists FROM cognition_evals WHERE level2 IS NOT NULL AND created_at >= $1 ORDER BY id DESC LIMIT 3000', [new Date(Date.now() - 30 * 864e5).toISOString()]).catch(() => [])) as any[]).map((r) => ({ l2: J<any>(r.level2, {}) || {}, area: J<string[]>(r.specialists, [])[0] || 'geral' }))
  const porArea = new Map<string, { n: number; div: number; mult: number; agDiv: number }>()
  for (const x of l2) { const s = porArea.get(x.area) || { n: 0, div: 0, mult: 0, agDiv: 0 }; s.n++; if ((x.l2.autoverificacao?.problemas || []).some((p: any) => (p?.tipo || p) === 'valor_divergente')) s.div++; if (x.l2.multiagente?.agentes?.length) { s.mult++; if (x.l2.multiagente.divergencias) s.agDiv++ } porArea.set(x.area, s) }
  for (const [area, s] of porArea) {
    if (s.n >= 10 && s.div / s.n >= 0.05) A.push(achado('inconsistencia', area, `Valores sem fonte nas respostas de ${APR.nomeArea(area)}`, s.div / s.n >= 0.15 ? 'alta' : 'média', `${s.div} de ${s.n} respostas com valor divergente na autoverificação`, 'estimativa', pol.raciocinio.revisarSempre.includes(area) ? null : { op: 'add', caminho: 'raciocinio.revisarSempre', valor: area }))
    if (s.mult >= 5 && s.agDiv / s.mult >= 0.3) A.push(achado('inconsistencia', area, `Agentes discordam com frequência em ${APR.nomeArea(area)}`, 'média', `${s.agDiv} de ${s.mult} coordenações com divergência entre agentes`, 'real'))
  }
  // erros recorrentes (vários usuários, várias semanas)
  for (const e of APR.padroes(ts, cfg.minUsuarios).erros.filter((x: any) => x.recorrente && x.global).slice(0, 6)) A.push(achado('recorrente', e.area, `“${e.nome}” se repete em ${APR.nomeArea(e.area)}`, (e.taxa || 0) >= 15 ? 'alta' : 'média', `${e.turnos} resposta(s), ${e.usuarios} usuário(s), ${e.taxa}% (por usuário), em semanas diferentes`, 'real'))
  // memória
  const perg = ts.filter((t) => t.problemas.includes('flag:perguntou_o_que_ja_sabia')).length
  if (ts.length >= 20 && perg / ts.length >= 0.03) A.push(achado('memoria', 'memoria', 'O assistente pergunta o que o usuário já informou', perg / ts.length >= 0.08 ? 'alta' : 'média', `${perg} de ${ts.length} respostas em 30 dias`, 'estimativa', pol.memoria.maxFatos < 16 ? { op: 'set', caminho: 'memoria.maxFatos', valor: Math.min(16, pol.memoria.maxFatos + 4) } : null))
  const diag = await ultimoRun('diagnostico'), memDiag = diag?.porArea?.['Memória'] || diag?.porArea?.memoria
  if (memDiag && memDiag.total && memDiag.ok < memDiag.total) A.push(achado('memoria', 'memoria', 'Diagnóstico de memória com falhas', 'média', `${memDiag.ok}/${memDiag.total} verificações do corpus`, 'experimental'))
  // execução (motor da Fase 8)
  const exi = await EX.indicadores()
  for (const f of exi.etapas.falhasPorClasse) if (f.n >= 3) A.push(achado('execucao', 'execucao:' + f.classe, `Etapas de execução falhando: ${f.nome}`, f.n >= 10 ? 'alta' : 'média', `${f.n} etapa(s) em 30 dias`, 'real'))
  for (const o2 of exi.porObjetivo) if (o2.total >= 5 && o2.falhas / o2.total >= 0.3) A.push(achado('execucao', 'objetivo:' + o2.playbook, `Objetivo "${o2.playbook}" falha com frequência`, 'média', `${o2.falhas} de ${o2.total} execuções`, 'real'))
  // gargalos de desempenho
  const tp: any = T.resumoTempos(), ia = tp.comIA
  if (ia?.mensagens >= 10) {
    const LIM: Record<string, number> = { iaModelo: 9000, iaAgentes: 7000, iaFerramentas: 4000, iaPreparo: 1500, iaConclusao: 4000 }
    for (const [k, v] of Object.entries(ia.etapas || {}) as any) if (LIM[k] && v.p95 > LIM[k]) A.push(achado('desempenho', k, `Etapa lenta: ${k.replace(/^ia/, '').toLowerCase()}`, v.p95 > LIM[k] * 1.6 ? 'alta' : 'média', `p95 de ${v.p95} ms (média ${v.media} ms) em ${ia.mensagens} mensagens`, 'real'))
    if (ia.consultasMedia != null && ia.consultasMedia > 45) A.push(achado('desempenho', 'banco', 'Muitas consultas ao banco por mensagem com IA', ia.consultasMedia > 60 ? 'alta' : 'média', `média de ${ia.consultasMedia} consultas (p95 ${ia.consultasP95})`, 'real'))
  }
  const st = (await H.loadStats().catch(() => ({}))) as Record<string, any>
  for (const [id, x] of Object.entries(st)) { const n = Number(x?.uses || 0) + Number(x?.failures || 0); if (n >= 20 && Number(x.failures) / n >= 0.2) A.push(achado('desempenho', 'provedor:' + id, `Provedor de IA "${id}" falhando`, Number(x.failures) / n >= 0.4 ? 'alta' : 'média', `${x.failures} falha(s) em ${n} chamadas`, 'real')) }
  // agentes com baixo desempenho (produção) e categorias fracas na Arena (experimental)
  const mult = await AG.indicadoresMultiagente()
  for (const a of mult.agentes) if (a.acionamentos >= 5 && (a.sucesso ?? 100) < 70) A.push(achado('agente', a.id, `Agente ${a.nome} com baixo sucesso`, (a.sucesso ?? 0) < 50 ? 'alta' : 'média', `${a.sucesso}% de ${a.acionamentos} acionamentos · ${Object.entries(a.falhas || {}).map(([k, v]) => `${k}: ${v}`).join(', ') || 'sem detalhe'}`, 'real'))
  for (const [k, v] of Object.entries(await LA.estatisticas())) if (k.startsWith('lab:') && v.acionamentos >= 5 && v.sucesso < 70) A.push(achado('agente', k, `Especialista do laboratório ${k.slice(4)} com baixo sucesso`, v.sucesso < 50 ? 'alta' : 'média', `${v.sucesso}% de ${v.acionamentos} acionamentos`, 'real'))
  const ult = await one("SELECT id, results FROM lab_runs WHERE kind IN ('arena','continuo') AND status = 'concluida' ORDER BY id DESC LIMIT 1").catch(() => null)
  if (ult) for (const [k, v] of Object.entries(J<any>(ult.results, {}).resumo?.porCategoria || {}) as any) if (v.total >= 2 && v.nota < 60) A.push(achado('qualidade', 'arena:' + k, `Arena: ${v.nome} abaixo do esperado`, v.nota < 40 ? 'alta' : 'baixa', `nota ${v.nota}/100 na rodada #${ult.id} (${v.aprovados}/${v.total} desafios)`, 'experimental'))
  const ordem = { alta: 0, média: 1, baixa: 2 }
  A.sort((a, b) => ordem[a.severidade] - ordem[b.severidade])
  let geradas: number[] = []
  if (o.gerar) geradas = await gerarPropostas(A.filter((a) => a.severidade !== 'baixa'), o.por || 'sistema')
  await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['lab_diagnostico', JSON.stringify({ achados: A.length, altas: A.filter((a) => a.severidade === 'alta').length, geradas: geradas.length }), !A.some((a) => a.severidade === 'alta'), nowIso()]).catch(() => {})
  return { em: nowIso(), achados: A, resumo: Object.fromEntries(Object.keys(TIPO_NOME).map((k) => [k, A.filter((a) => a.tipo === k).length])), tipos: TIPO_NOME, geradas, base: { respostas: ts.length, dias: 30 } }
}
const BENEFICIO: Record<string, string> = { inconsistencia: 'Menos valores sem fonte e respostas mais coerentes.', interpretacao: 'Menos correções e repetições pedidas pelo usuário.', recorrente: 'Elimina um problema que se repete para vários usuários.', memoria: 'O assistente para de perguntar o que já sabe.', execucao: 'Mais tarefas concluídas e conferidas na primeira tentativa.', desempenho: 'Respostas mais rápidas e menor custo por mensagem.', agente: 'Contribuições mais úteis dos agentes, sem atrasar a resposta.', qualidade: 'Respostas mais claras e naturais.' }
const RISCO: Record<string, string> = { inconsistencia: 'Revisão sempre ligada aumenta um pouco o tempo de resposta na área.', interpretacao: 'Perguntar mais pode deixar a conversa mais lenta para quem já deu todos os dados.', memoria: 'Mais memórias no contexto aumentam o custo e podem trazer informação irrelevante.', execucao: 'Conferência extra pode gerar perguntas a mais.', desempenho: 'Mudanças de infraestrutura exigem implantação controlada.', agente: 'Evitar agentes pode empobrecer respostas complexas da área.', qualidade: 'Respostas curtas podem omitir detalhes úteis.', recorrente: 'A correção pode afetar outros comportamentos da área.' }
async function gerarPropostas(achados: Achado[], por: string) {
  const out: number[] = []
  for (const a of achados.slice(0, 10)) {
    const fp = 'diag:' + a.id
    const ja = await one("SELECT id FROM lab_improvements WHERE fingerprint = $1 AND (status IN ('aberta','aprovada') OR updated_at >= $2)", [fp, new Date(Date.now() - 30 * 864e5).toISOString()]).catch(() => null)
    if (ja) continue
    const testes = a.mudanca ? 'Experimento isolado da política (cenários sintéticos, corpus, bateria, memórias fictícias) + Arena nas categorias da área + liberação gradual com vigilância.' : `Arena nas categorias relacionadas antes e depois da correção; acompanhar "${a.tipoNome}" no Centro de diagnóstico por 7 dias.`
    out.push(await LB.anotarMelhoria('diagnostico', null, { fingerprint: fp, title: a.titulo.slice(0, 160), problem: `${a.titulo}. Evidência: ${a.evidencia} (${a.fonte}).`, cause: a.causa, solution: a.sugestao + (a.mudanca ? ` Ajuste proposto: ${a.mudanca.op} ${a.mudanca.caminho}${a.mudanca.valor !== undefined ? ' = ' + JSON.stringify(a.mudanca.valor) : ''}.` : ''), benefits: BENEFICIO[a.tipo] || '', risks: RISCO[a.tipo] || '', tests: testes, test_result: JSON.stringify({ mudanca: a.mudanca || null, area: a.area, tipo: a.tipo, severidade: a.severidade }), status: 'aberta' }, por, 'gerada pelo Centro de diagnóstico'))
  }
  return out
}
const ultimoRun2 = ultimoRun

/* ======================= 6) central de melhorias ======================= */
const BENEF_KIND: Record<string, string> = { raciocinio: 'Respostas conferidas/planejadas onde mais erram.', memoria: 'Contexto do usuário mais bem aproveitado.', agentes: 'Menos atraso e menos ruído de agentes onde eles pioram o resultado.', ferramentas: 'Ações executadas com os dados certos e falhas comunicadas.', qualidade: 'Respostas no tamanho e no tom que os usuários preferem.', proatividade: 'Menos alertas inúteis.', regra: 'Comportamento corrigido conforme as avaliações.' }
const RISCO_KIND: Record<string, string> = { raciocinio: 'Pode aumentar o tempo de resposta da área.', memoria: 'Contexto maior custa mais e pode trazer ruído.', agentes: 'Pode empobrecer respostas complexas.', ferramentas: 'Pode gerar perguntas a mais antes de agir.', qualidade: 'Pode cortar detalhes úteis (ou alongar demais).', proatividade: 'Pode esconder um alerta verdadeiro.', regra: 'Uma regra ampla demais pode conflitar com outras.' }
function norm(o: any) { return { problema: '', causa: '', solucao: '', beneficios: '', riscos: '', testesNecessarios: '', resultadoTestes: null as any, ...o } }
async function anotacoes() { const m = new Map<string, any>(); for (const r of (await q('SELECT * FROM lab_improvements').catch(() => [])) as any[]) m.set(`${r.source}:${r.source_id ?? 'd' + r.id}`, r); return m }
const aplicar = (base: any, a: any) => !a ? base : { ...base, titulo: a.title || base.titulo, problema: a.problem || base.problema, causa: a.cause || base.causa, solucao: a.solution || base.solucao, beneficios: a.benefits || base.beneficios, riscos: a.risks || base.riscos, testesNecessarios: a.tests || base.testesNecessarios, testesLaboratorio: J<any>(a.test_result, null), arquivada: a.archived === true || a.archived === 1 || a.archived === 't', anotacoes: J<any[]>(a.history, []), editada: !!(a.problem || a.cause || a.solution || a.benefits || a.risks || a.tests) }
export async function melhorias(filtro: { estado?: string; origem?: string } = {}) {
  const APR = await import('./aprendizado.js'), L = await import('./lab.js'), LA = await import('./laboratorio-agentes.js'), an = await anotacoes(), out: any[] = []
  for (const p of await APR.listarPropostas()) {
    const fase = ['proposta', 'testada', 'reprovada'].includes(p.estado) ? 'aberta' : ['gradual', 'ativa'].includes(p.estado) ? 'aprovada' : p.estado === 'revertida' ? 'revertida' : 'rejeitada'
    const t = p.teste
    out.push(aplicar(norm({ origem: 'politica', origemNome: 'Aprendizado contínuo (política)', id: p.id, titulo: p.titulo, estado: p.estado, fase, criadaPor: p.criadaPor, criadaEm: p.criadaEm,
      problema: p.justificativa, causa: Object.entries(p.evidencia || {}).map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · '), solucao: `${p.mudanca.op} ${p.mudanca.caminho}${p.mudanca.valor !== undefined ? ' = ' + JSON.stringify(p.mudanca.valor) : ''}`,
      beneficios: BENEF_KIND[p.tipo] || '', riscos: RISCO_KIND[p.tipo] || '', testesNecessarios: 'Experimento isolado (cenários sintéticos, corpus, bateria e memórias fictícias) e, depois, liberação gradual com vigilância automática.',
      resultadoTestes: t ? { aprovado: !!t.aprovada, resumo: t.aprovada ? 'Aprovada nos testes isolados' : 'Reprovada: ' + (t.motivos || []).join('; '), antes: t.antes, depois: t.depois, em: t.em } : null,
      acoes: [...(['proposta', 'reprovada', 'testada'].includes(p.estado) ? ['testar'] : []), ...(p.estado === 'testada' ? ['aprovar_gradual', 'aprovar_total'] : []), ...(['proposta', 'testada', 'reprovada'].includes(p.estado) ? ['rejeitar'] : []), ...(p.estado === 'gradual' ? ['promover'] : []), ...(['gradual', 'ativa'].includes(p.estado) ? ['reverter'] : [])] }), an.get(`politica:${p.id}`)))
  }
  for (const p of await L.listar()) {
    const fase = ['rascunho', 'em_analise', 'em_testes', 'aguardando_aprovacao', 'aprovada'].includes(p.estado) ? 'aberta' : p.estado === 'publicada' ? 'aprovada' : p.estado === 'desativada' ? 'revertida' : 'rejeitada'
    const t = p.testes
    out.push(aplicar(norm({ origem: 'regra', origemNome: 'Laboratório de IA (regra)', id: p.id, titulo: p.titulo, estado: p.estadoLabel, fase, criadaEm: p.criadoEm,
      problema: p.falha || 'Correção ensinada por um administrador.', causa: p.correcao || '', solucao: p.regra, beneficios: 'O assistente passa a seguir a regra aprovada nas conversas.', riscos: [...(p.riscos || []), ...(p.conflitos || []).map((c: any) => `Conflito com a regra #${c.com}: ${c.motivo}`)].join(' ') || RISCO_KIND.regra,
      testesNecessarios: 'Análise de regras parecidas e conflitos + simulação com as ferramentas desligadas.', resultadoTestes: t ? { aprovado: !!t.aprovado, resumo: t.aprovado ? 'Simulação sem problemas' : 'Simulação com problemas', em: t.em } : null,
      acoes: [...(['rascunho', 'em_analise', 'em_testes'].includes(p.estado) ? ['testar'] : []), ...(p.estado === 'em_testes' ? ['enviar'] : []), ...(p.estado === 'aguardando_aprovacao' ? ['aprovar'] : []), ...(p.estado === 'aprovada' ? ['publicar'] : []), ...(p.emProducao ? ['desativar'] : []), ...(!['publicada', 'rejeitada', 'desativada'].includes(p.estado) ? ['rejeitar'] : [])] }), an.get(`regra:${p.id}`)))
  }
  const labAg = (await LA.visao()).laboratorio
  for (const x of labAg.filter((y: any) => ['aguardando', 'gradual'].includes(y.estado))) {
    out.push(aplicar(norm({ origem: 'agente', origemNome: 'Laboratório de agentes', id: x.id, titulo: `${x.base ? 'Nova versão do agente' : 'Novo especialista'}: ${x.nome}`, estado: x.estadoLabel, fase: x.estado === 'aguardando' ? 'aberta' : 'aprovada', criadaEm: x.criadoEm,
      problema: x.base ? `Ajuste das instruções do agente "${x.base}".` : `Especialista em ${x.papel}.`, causa: 'Criado no Laboratório de agentes.', solucao: x.instrucoes, beneficios: 'Contribuição especializada em pedidos complexos da área.', riscos: 'Mais tempo de resposta quando acionado; contribuição fraca pode confundir a resposta final.',
      testesNecessarios: 'Teste individual, comparação com o agente atual e colaboração (dados fictícios); depois, liberação gradual com vigilância automática.', resultadoTestes: x.ultimoTeste ? { aprovado: x.ultimoTeste.ok !== false, resumo: `Último teste (${x.ultimoTeste.tipo}) da v${x.ultimoTeste.versao}`, em: x.ultimoTeste.em } : null,
      acoes: x.estado === 'aguardando' ? ['aprovar_gradual', 'aprovar_total', 'rejeitar'] : ['promover', 'reverter'] }), an.get(`agente:${x.id}`)))
  }
  for (const r of ((await q("SELECT * FROM lab_improvements WHERE source = 'diagnostico' ORDER BY id DESC LIMIT 200").catch(() => [])) as any[])) {
    const tr = J<any>(r.test_result, {}) || {}
    out.push(aplicar(norm({ origem: 'diagnostico', origemNome: 'Centro de diagnóstico', id: Number(r.id), titulo: r.title, estado: r.status, fase: r.status === 'aberta' ? 'aberta' : r.status === 'aprovada' ? 'aprovada' : r.status, criadaEm: String(r.created_at), criadaPor: r.created_by,
      resultadoTestes: tr.experimento || tr.politica ? { aprovado: !!tr.aprovado, resumo: tr.resumo || '', em: tr.em } : null, mudanca: tr.mudanca || null,
      acoes: r.status === 'aberta' ? [...(tr.mudanca ? ['testar'] : []), 'aprovar', 'rejeitar'] : [] }), r))
  }
  if (filtro.estado === 'todas') filtro = { ...filtro, estado: undefined }
  const sai = out.filter((m) => (filtro.origem ? m.origem === filtro.origem : true) && (filtro.estado === 'arquivadas' ? m.arquivada : !m.arquivada) && (!filtro.estado || filtro.estado === 'arquivadas' || m.fase === filtro.estado))
  return { melhorias: sai.sort((a, b) => String(b.criadaEm).localeCompare(String(a.criadaEm))), contagem: { abertas: out.filter((m) => !m.arquivada && m.fase === 'aberta').length, aprovadas: out.filter((m) => !m.arquivada && m.fase === 'aprovada').length, arquivadas: out.filter((m) => m.arquivada).length, total: out.length } }
}
/** Ações da Central: cada uma é delegada ao módulo de origem (com as mesmas regras e validações de lá). */
export async function acaoMelhoria(admin: SessionUser, origem: string, id: number, acao: string, b: any = {}) {
  const actor = `admin ${admin.id}`, por = admin.name || 'administrador'
  if (!Number.isInteger(id) || id <= 0) fail(400, 'Proposta inválida.', 'invalid')
  if (acao === 'editar') {
    const campos: Record<string, any> = {}
    for (const [k, col] of [['titulo', 'title'], ['problema', 'problem'], ['causa', 'cause'], ['solucao', 'solution'], ['beneficios', 'benefits'], ['riscos', 'risks'], ['testesNecessarios', 'tests']] as const) if (b[k] !== undefined) campos[col] = String(b[k]).trim().slice(0, 2000)
    if (!Object.keys(campos).length) fail(400, 'Nada para editar.', 'invalid')
    if (LB.pareceDadoPessoal(Object.values(campos).join(' '))) fail(400, 'O texto parece conter um dado pessoal real.', 'dado_pessoal')
    if (origem === 'regra' && b.regra !== undefined) { const L = await import('./lab.js'); await L.editar(id, actor, { regra: String(b.regra) }) } // o texto da regra é editado no próprio Laboratório de IA (volta a precisar de testes)
    if (origem === 'diagnostico') { const ex = await one("SELECT id FROM lab_improvements WHERE id = $1 AND source = 'diagnostico'", [id]); if (!ex) fail(404, 'Proposta não encontrada.', 'not_found'); const ks = Object.keys(campos); await q(`UPDATE lab_improvements SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')}, updated_at = $${ks.length + 1} WHERE id = $${ks.length + 2}`, [...ks.map((k) => campos[k]), nowIso(), id]); return { ok: true } }
    await LB.anotarMelhoria(origem, id, campos, por, 'texto editado no Laboratório de Inteligência'); return { ok: true }
  }
  if (acao === 'arquivar' || acao === 'desarquivar') {
    const arq = acao === 'arquivar'
    if (arq) { const lista = (await melhorias({})).melhorias.find((m) => m.origem === origem && m.id === id); if (!lista) fail(404, 'Proposta não encontrada.', 'not_found'); if (lista!.fase === 'aprovada') fail(409, 'Uma melhoria em produção não pode ser arquivada: reverta antes.', 'invalid_state') }
    if (origem === 'diagnostico') { await q('UPDATE lab_improvements SET archived = $1, status = $2, updated_at = $3 WHERE id = $4', [arq, arq ? 'arquivada' : 'aberta', nowIso(), id]); return { ok: true } }
    await LB.anotarMelhoria(origem, id, { archived: arq }, por, arq ? 'arquivada' : 'desarquivada'); return { ok: true }
  }
  switch (origem) {
    case 'politica': {
      const APR = await import('./aprendizado.js')
      if (acao === 'testar') return APR.experimentar(id, admin)
      if (acao === 'aprovar_gradual') return APR.decidir(id, 'aprovar', admin, { modo: 'gradual', pct: b.pct, nota: b.nota })
      if (acao === 'aprovar_total') return APR.decidir(id, 'aprovar', admin, { modo: 'total', nota: b.nota })
      if (['rejeitar', 'promover', 'reverter'].includes(acao)) return APR.decidir(id, acao, admin, { nota: b.nota })
      break
    }
    case 'regra': {
      const L = await import('./lab.js')
      if (acao === 'testar') return L.testar(admin, id, actor)
      if (acao === 'enviar') return L.enviarParaAprovacao(id, actor, !!b.confirmar)
      if (acao === 'aprovar') return L.aprovar(id, actor)
      if (acao === 'publicar') return L.publicar(id, actor, !!b.confirmar)
      if (acao === 'desativar') return L.desativar(id, actor)
      if (acao === 'rejeitar') return L.rejeitar(id, actor, String(b.nota || b.motivo || 'rejeitada no Laboratório de Inteligência'))
      break
    }
    case 'agente': {
      const LA = await import('./laboratorio-agentes.js')
      if (acao === 'aprovar_gradual') return LA.decidir(admin, id, 'aprovar', { modo: 'gradual', pct: b.pct, nota: b.nota })
      if (acao === 'aprovar_total') return LA.decidir(admin, id, 'aprovar', { modo: 'total', nota: b.nota })
      if (['rejeitar', 'promover', 'reverter'].includes(acao)) return LA.decidir(admin, id, acao, { nota: b.nota })
      break
    }
    case 'diagnostico': {
      const r = await one("SELECT * FROM lab_improvements WHERE id = $1 AND source = 'diagnostico'", [id]); if (!r) fail(404, 'Proposta não encontrada.', 'not_found')
      if (r!.status !== 'aberta') fail(409, 'Esta proposta já foi decidida.', 'invalid_state')
      const tr = J<any>(r!.test_result, {}) || {}, hist = (n: string) => JSON.stringify([...J<any[]>(r!.history, []), { em: nowIso(), por, nota: n }].slice(-50))
      if (acao === 'testar') { // ajuste de política sugerido → vira proposta do aprendizado contínuo e passa pelo teste isolado de lá
        if (!tr.mudanca) fail(409, 'Esta proposta é uma correção técnica (sem ajuste automático de parâmetro): os testes necessários estão descritos nela.', 'invalid_state')
        const APR = await import('./aprendizado.js'), m = tr.mudanca, kind = String(m.caminho).split('.')[0] === 'preditivo' ? 'proatividade' : String(m.caminho).split('.')[0], fp = `${kind}|${JSON.stringify(m)}`
        const ja = await one("SELECT id FROM learning_proposals WHERE fingerprint = $1 AND status IN ('proposta','testada','reprovada','gradual','ativa')", [fp]).catch(() => null)
        const pid = ja ? Number(ja.id) : Number((await one('INSERT INTO learning_proposals (kind, title, rationale, evidence, change, fingerprint, status, created_by, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10) RETURNING id',
          [kind, String(r!.title).slice(0, 160), String(r!.problem).slice(0, 600), JSON.stringify({ diagnostico: id, area: tr.area }), JSON.stringify(m), fp, 'proposta', 'laboratorio', JSON.stringify([{ em: nowIso(), para: 'proposta', por, nota: `criada pelo Centro de diagnóstico (#${id})` }]), nowIso()]))!.id)
        const res: any = await APR.experimentar(pid, admin).catch((e: any) => ({ aprovada: false, motivos: [e?.message || 'falhou'] }))
        await q('UPDATE lab_improvements SET test_result = $1, history = $2, updated_at = $3 WHERE id = $4', [JSON.stringify({ ...tr, politica: pid, aprovado: !!res.aprovada, resumo: res.aprovada ? `Aprovada nos testes isolados — proposta #${pid} do aprendizado contínuo pronta para aprovação gradual.` : 'Reprovada: ' + (res.motivos || []).join('; '), em: nowIso() }), hist(`testada (proposta de política #${pid})`), nowIso(), id])
        return { ok: true, politica: pid, aprovada: !!res.aprovada, motivos: res.motivos || [] }
      }
      if (acao === 'aprovar') { await q("UPDATE lab_improvements SET status = 'aprovada', history = $1, updated_at = $2 WHERE id = $3", [hist(tr.politica ? `aprovada — a liberação segue pela proposta de política #${tr.politica}` : 'aprovada para implementação técnica (nenhuma alteração automática)'), nowIso(), id]); return { ok: true, estado: 'aprovada', observacao: tr.politica ? `A ativação acontece pela proposta #${tr.politica} (aprovação gradual na Central).` : 'Correção técnica aprovada: registre a implementação pela equipe. Nada muda sozinho em produção.' } }
      if (acao === 'rejeitar') { await q("UPDATE lab_improvements SET status = 'rejeitada', history = $1, updated_at = $2 WHERE id = $3", [hist('rejeitada' + (b.nota ? ': ' + String(b.nota).slice(0, 150) : '')), nowIso(), id]); return { ok: true, estado: 'rejeitada' } }
      break
    }
  }
  fail(400, 'Ação inválida para esta proposta.', 'invalid')
}

/* ======================= 8) controle de evolução global ======================= */
export async function evolucao() {
  const APR = await import('./aprendizado.js'), L = await import('./lab.js'), LA = await import('./laboratorio-agentes.js')
  const cfg = await POL.aprCfg(true), versoes = await POL.listarVersoes(20), ts = (await APR.turnos(30)).turnos, vig = await ultimoRun2('aprendizado')
  const props = await APR.listarPropostas(), lab = (await LA.visao()).laboratorio
  const linha: any[] = []
  for (const p of props) for (const h of p.historico || []) if (['gradual', 'ativa', 'revertida', 'rejeitada', 'testada', 'reprovada'].includes(h.para)) linha.push({ em: h.em, origem: 'política', titulo: `#${p.id} ${p.titulo}`, evento: h.para, por: h.por, nota: h.nota || '' })
  for (const e of await L.historicoGeral(60)) if (['publicada', 'desativada', 'revertida', 'aprovada', 'reativada'].includes(e.tipo)) linha.push({ em: e.em, origem: 'regra', titulo: `#${e.propostaId} ${e.titulo || ''}`, evento: e.tipo, por: e.por, nota: '' })
  for (const x of lab) for (const h of x.historico) if (/publicad|gradual|revertid|retirado|encerrada|promovido|aprovação/.test(h.evento)) linha.push({ em: h.em, origem: 'agente', titulo: x.nome, evento: h.evento, por: h.por, nota: h.nota || '' })
  linha.sort((a, b) => String(b.em).localeCompare(String(a.em)))
  const continuos = await Promise.all((await LB.agendas()).map(async (a) => ({ agenda: a, comparativo: await LB.comparativo(a.id) })))
  const regressoes = [
    ...(vig?.alertas || []).map((t: string) => ({ origem: 'política (vigilância)', texto: t })),
    ...continuos.filter((c) => c.comparativo.regressao).map((c) => ({ origem: 'desafios contínuos', texto: `${c.agenda.nome}: nota ${c.comparativo.anterior?.nota} → ${c.comparativo.ultima?.nota}${c.comparativo.quedas.length ? ' (' + c.comparativo.quedas.map((x) => x.nome).join(', ') + ')' : ''}` })),
    ...lab.filter((x: any) => ['gradual', 'publicado'].includes(x.estado) && x.producao && x.producao.acionamentos >= 10 && x.producao.sucesso < 60).map((x: any) => ({ origem: 'especialista', texto: `${x.nome}: ${x.producao.sucesso}% de sucesso em ${x.producao.acionamentos} acionamentos` })),
  ]
  return {
    politica: { versaoAtiva: cfg.versaoAtiva, gradual: cfg.gradual, pararGradualEmRegressao: cfg.pararGradualEmRegressao, versoes, resultadoPorVersao: APR.porVersao(ts), ultimaVigilancia: vig?.em || null },
    regras: { publicadas: (await L.listar('publicada')).map((p) => ({ id: p.id, titulo: p.titulo, versao: p.versao, publicadaEm: p.publicadoEm })) },
    agentes: lab.filter((x: any) => ['gradual', 'publicado'].includes(x.estado)).map((x: any) => ({ id: x.id, nome: x.nome, estado: x.estado, estadoLabel: x.estadoLabel, pct: x.pct, versao: x.emProducao, producao: x.producao })),
    continuos: continuos.map((c) => ({ id: c.agenda.id, nome: c.agenda.nome, tendencia: c.comparativo.tendencia, ultima: c.comparativo.ultima?.nota ?? null, delta: c.comparativo.delta })),
    regressoes, linhaDoTempo: linha.slice(0, 80),
    fluxo: ['Proposta (diagnóstico, aprendizado, experimento ou administrador)', 'Teste isolado (dados sintéticos)', 'Aprovação do administrador', 'Versão registrada', 'Liberação gradual (por usuário)', 'Monitoramento e vigilância', 'Promoção para todos ou reversão'],
    garantia: 'Nenhuma alteração experimental muda o comportamento dos usuários sozinha: só uma aprovação explícita de um administrador publica algo; a vigilância automática só age no sentido seguro (encerrar uma liberação gradual com regressão).',
  }
}

/* ======================= 10) auditoria ======================= */
export async function auditoria(limite = 100) {
  const rows = (await q("SELECT a.id, a.actor_id, a.action, a.target_id, a.details, a.created_at, u.name FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id WHERE a.action LIKE 'laboratorio.%' OR a.action LIKE 'lab.%' OR a.action LIKE 'aprendizado.%' ORDER BY a.id DESC LIMIT $1", [Math.max(1, Math.min(300, limite))]).catch(() => [])) as any[]
  return rows.map((r) => ({ id: Number(r.id), por: r.name || (r.actor_id == null ? 'sistema' : `admin ${r.actor_id}`), acao: r.action, alvo: r.target_id == null ? null : Number(r.target_id), detalhes: J<any>(r.details, {}), em: String(r.created_at) }))
}
