// APRENDIZADO POR FEEDBACK — o usuário avalia cada resposta (👍/👎, motivo, comentário). Dois efeitos, com regras claras:
// 1) PESSOAL e imediato: "muito longa"/"muito curta" ajustam o tamanho das respostas SÓ para quem avaliou (reversível).
// 2) GERAL e controlado: avaliações negativas viram OPORTUNIDADES no painel; o administrador as envia ao Laboratório
//    de IA, onde passam pelo fluxo que já existe (análise → testes → aprovação → publicação). Nada muda sozinho.
// Privacidade: o texto da conversa só é guardado quando o usuário marca "compartilhar esta conversa".
import { q, one, nowIso, J } from '../db/index.js'
import { fail } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import { prefsDe, salvarPrefs } from './proativo.js'

export const MOTIVOS: Record<string, string> = { incorreta: 'Informação incorreta', incompleta: 'Incompleta', nao_entendeu: 'Não entendeu o pedido', muito_longa: 'Longa demais', muito_curta: 'Curta demais', tom: 'Tom inadequado', nao_executou: 'Não fez o que pedi', outro: 'Outro' }
const yes = (v: unknown) => v === true || v === 1 || v === 't' || v === 'true'

/** Linha de response_feedback (colunas usadas neste módulo). */
type FeedbackRow = { id: number | string; user_id: number | string; message_id: number | string; rating: number | string; reasons: unknown; comment: string | null; shared: unknown; question_excerpt: string | null; answer_excerpt: string | null; snapshot: unknown; created_at: string }
/** Resumo da avaliação técnica (cognition_evals) guardado junto com o feedback. */
interface Snapshot { intencao?: string; caminho?: string; nota?: number; sinalizacoes?: string[]; especialistas?: string[] }
interface Exemplo { pergunta?: string | null; resposta?: string | null; comentario?: string | null }
/** Corpo enviado pelo app ao avaliar uma resposta. */
export interface FeedbackBody { messageId?: unknown; nota?: unknown; motivos?: unknown; comentario?: unknown; compartilhar?: unknown }

export async function registrar(u: SessionUser, b: FeedbackBody | null | undefined) {
  const messageId = Number(b?.messageId), nota = Number(b?.nota)
  if (!Number.isInteger(messageId) || messageId <= 0) fail(400, 'Mensagem inválida.', 'invalid', 'messageId')
  if (![1, -1, 0].includes(nota)) fail(400, 'Avaliação inválida.', 'invalid', 'nota')
  const m = await one('SELECT id, conversation_id, role, content FROM messages WHERE id = $1 AND user_id = $2', [messageId, u.id])
  if (!m || m.role !== 'assistant') fail(404, 'Resposta não encontrada.', 'not_found')
  const motivos = (Array.isArray(b?.motivos) ? (b.motivos as unknown[]) : []).map(String).filter((x) => x in MOTIVOS).slice(0, 4)
  const comentario = b?.comentario ? String(b.comentario).replace(/\s+/g, ' ').trim().slice(0, 500) : null
  const compartilhar = b?.compartilhar === true
  const now = nowIso()
  if (nota === 0) { await q('DELETE FROM response_feedback WHERE user_id = $1 AND message_id = $2', [u.id, messageId]); await q('UPDATE cognition_evals SET feedback = NULL WHERE message_id = $1 AND user_id = $2', [messageId, u.id]).catch(() => {}); return { ok: true, nota: 0, estilo: await recalcularEstilo(u.id) } }
  let pergunta: string | null = null, resposta: string | null = null
  if (compartilhar) {
    const pq = await one("SELECT content FROM messages WHERE user_id = $1 AND conversation_id = $2 AND role = 'user' AND id < $3 ORDER BY id DESC LIMIT 1", [u.id, m.conversation_id, messageId]).catch(() => null)
    pergunta = pq ? String(pq.content).slice(0, 400) : null; resposta = String(m.content || '').replace(/⟦[^⟧]*⟧/g, '').slice(0, 700)
  }
  const ev = await one('SELECT intent, path, flags, overall, specialists, scores FROM cognition_evals WHERE message_id = $1 AND user_id = $2', [messageId, u.id]).catch(() => null)
  const snapshot: Snapshot = ev ? { intencao: ev.intent, caminho: ev.path, nota: Number(ev.overall), sinalizacoes: J<string[]>(ev.flags, []), especialistas: J<string[]>(ev.specialists, []) } : {}
  const ex = await one('SELECT id FROM response_feedback WHERE user_id = $1 AND message_id = $2', [u.id, messageId])
  const motivosFinais = nota === 1 ? [] : motivos
  if (ex) await q('UPDATE response_feedback SET rating = $1, reasons = $2, comment = $3, shared = $4, question_excerpt = $5, answer_excerpt = $6, snapshot = $7, status = $8, updated_at = $9 WHERE id = $10',
    [nota, JSON.stringify(motivosFinais), comentario, compartilhar, pergunta, resposta, JSON.stringify(snapshot), 'novo', now, ex.id])
  else await q('INSERT INTO response_feedback (user_id, message_id, conversation_id, rating, reasons, comment, shared, question_excerpt, answer_excerpt, snapshot, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12)',
    [u.id, messageId, m.conversation_id, nota, JSON.stringify(motivosFinais), comentario, compartilhar, pergunta, resposta, JSON.stringify(snapshot), 'novo', now])
  await q('UPDATE cognition_evals SET feedback = $1 WHERE message_id = $2 AND user_id = $3', [nota, messageId, u.id]).catch(() => {})
  // memória de experiências (individual): avaliação do próprio usuário — motivos e assunto, nunca a resposta inteira
  const pq0 = await one("SELECT content FROM messages WHERE user_id = $1 AND conversation_id = $2 AND role = 'user' AND id < $3 ORDER BY id DESC LIMIT 1", [u.id, m.conversation_id, messageId]).catch(() => null)
  await (await import('./memoria-evolutiva.js')).registrarExperiencia(u, { kind: 'feedback', outcome: nota === 1 ? 'aprovado' : 'reprovado', summary: `Resposta ${nota === 1 ? 'útil' : 'não útil'}${motivosFinais.length ? ' (' + motivosFinais.map((x) => MOTIVOS[x]).join(', ') + ')' : ''}${snapshot.intencao ? ' · ' + snapshot.intencao : ''}`, conversationId: m.conversation_id, base: String(pq0?.content || '').slice(0, 200) }).catch(() => {})
  return { ok: true, nota, estilo: await recalcularEstilo(u.id) }
}
/** Preferência PESSOAL de tamanho, a partir das últimas avaliações do próprio usuário. */
export async function recalcularEstilo(userId: number) {
  const rows = await q<Pick<FeedbackRow, 'reasons'>>('SELECT reasons FROM response_feedback WHERE user_id = $1 AND rating = -1 ORDER BY id DESC LIMIT 20', [userId]).catch((): Pick<FeedbackRow, 'reasons'>[] => [])
  let longa = 0, curta = 0
  for (const r of rows) { const m = J<string[]>(r.reasons, []); if (m.includes('muito_longa')) longa++; if (m.includes('muito_curta')) curta++ }
  const tamanho = longa > curta ? 'curto' : curta > longa ? 'detalhado' : undefined
  const atual = await prefsDe(userId)
  if (atual.style.tamanho !== tamanho) await salvarPrefs(userId, { style: { ...atual.style, tamanho } })
  return { tamanho: tamanho || null }
}
export async function zerarEstilo(userId: number) {
  await q("UPDATE response_feedback SET reasons = '[]' WHERE user_id = $1 AND rating = -1 AND (reasons LIKE '%muito_longa%' OR reasons LIKE '%muito_curta%')", [userId])
  await salvarPrefs(userId, { style: {} }); return { tamanho: null }
}
export async function minhas(userId: number, ids: number[]) {
  const ok = ids.filter((n) => Number.isInteger(n) && n > 0).slice(0, 200)
  if (!ok.length) return {}
  const rows = await q<Pick<FeedbackRow, 'message_id' | 'rating'>>(`SELECT message_id, rating FROM response_feedback WHERE user_id = $1 AND message_id IN (${ok.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...ok])
  return Object.fromEntries(rows.map((r) => [String(r.message_id), Number(r.rating)]))
}

/* ---------- painel: indicadores e oportunidades de melhoria ---------- */
const chaveDe = (r: Pick<FeedbackRow, 'snapshot' | 'reasons'>) => { const s = J<Snapshot>(r.snapshot, {}), m = J<string[]>(r.reasons, []); return { motivo: m[0] || 'sem_motivo', especialista: (s.especialistas || [])[0] || 'geral', intencao: s.intencao || '—' } }
/** Agrupamento das avaliações negativas por motivo × especialista × intenção. */
type Grupo = ReturnType<typeof chaveDe> & { chave: string; motivoNome: string; n: number; usuarios: Set<number>; sinalizacoes: Map<string, number>; exemplos: Exemplo[]; ids: number[] }
export async function oportunidades() {
  const rows = await q<FeedbackRow>("SELECT * FROM response_feedback WHERE rating = -1 AND status = 'novo' ORDER BY id DESC LIMIT 1000").catch((): FeedbackRow[] => [])
  const grupos = new Map<string, Grupo>()
  for (const r of rows) {
    const c = chaveDe(r), k = `${c.motivo}|${c.especialista}|${c.intencao}`
    const g = grupos.get(k) || { chave: k, ...c, motivoNome: MOTIVOS[c.motivo] || 'Sem motivo informado', n: 0, usuarios: new Set<number>(), sinalizacoes: new Map<string, number>(), exemplos: [] as Exemplo[], ids: [] as number[] }
    g.n++; g.usuarios.add(Number(r.user_id)); g.ids.push(Number(r.id))
    for (const f of J<Snapshot>(r.snapshot, {}).sinalizacoes || []) g.sinalizacoes.set(f, (g.sinalizacoes.get(f) || 0) + 1)
    if (yes(r.shared) && g.exemplos.length < 3) g.exemplos.push({ pergunta: r.question_excerpt, resposta: r.answer_excerpt, comentario: r.comment })
    else if (!yes(r.shared) && r.comment && g.exemplos.length < 3) g.exemplos.push({ comentario: r.comment })
    grupos.set(k, g)
  }
  return [...grupos.values()].map((g) => ({ ...g, usuarios: g.usuarios.size, sinalizacoes: [...g.sinalizacoes].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([flag, n]) => ({ flag, n })) }))
    .sort((a, b) => b.usuarios - a.usuarios || b.n - a.n)
}
export async function resumo() {
  const rows = await q<Pick<FeedbackRow, 'rating' | 'created_at'>>('SELECT rating, created_at FROM response_feedback ORDER BY id DESC LIMIT 5000').catch((): Pick<FeedbackRow, 'rating' | 'created_at'>[] => [])
  const agora = Date.now(), sem = 7 * 864e5
  const taxa = (xs: readonly Pick<FeedbackRow, 'rating'>[]) => (xs.length ? Math.round((xs.filter((r) => Number(r.rating) === 1).length / xs.length) * 100) : null)
  const r7 = rows.filter((r) => agora - Date.parse(String(r.created_at)) <= sem), r14 = rows.filter((r) => { const d = agora - Date.parse(String(r.created_at)); return d > sem && d <= 2 * sem })
  return { total: rows.length, positivos: rows.filter((r) => Number(r.rating) === 1).length, negativos: rows.filter((r) => Number(r.rating) === -1).length, taxaPositiva: taxa(rows), taxa7d: taxa(r7), taxa7dAnterior: taxa(r14), n7d: r7.length }
}
/** Envia uma oportunidade ao Laboratório de IA como proposta em RASCUNHO (só vale depois de testes e aprovação). */
export async function enviarAoLaboratorio(admin: SessionUser, chave: string, nota = '') {
  const g = (await oportunidades()).find((x) => x.chave === chave); if (!g) fail(404, 'Oportunidade não encontrada (talvez já enviada).', 'not_found')
  const ESP: Record<string, string> = { agenda: 'Agendamentos', financas: 'Financeiro', tarefas: 'Lembretes', compras: 'Produtos', crm: 'Clientes', agenda_empresa: 'Agendamentos', negocio: 'Empresas' }
  const ex = g.exemplos.filter((e) => e.pergunta || e.comentario).slice(0, 3).map((e, i) => `Exemplo ${i + 1}: ${e.pergunta ? `pergunta "${String(e.pergunta).slice(0, 200)}"; ` : ''}${e.resposta ? `resposta "${String(e.resposta).slice(0, 240)}"; ` : ''}${e.comentario ? `comentário do usuário "${e.comentario}"` : ''}`).join('\n')
  const texto = `Avaliações negativas de ${g.usuarios} usuário(s) (${g.n} resposta(s)) — motivo: ${g.motivoNome}; especialista: ${g.especialista}; intenção: ${g.intencao}.${g.sinalizacoes.length ? ` Sinalizações internas mais comuns: ${g.sinalizacoes.map((s) => s.flag).join(', ')}.` : ''}\n${ex}${nota ? `\nObservação do administrador: ${String(nota).slice(0, 400)}` : ''}\nO assistente deve corrigir esse comportamento.`
  const lab = await import('./lab.js')
  const id = await lab.criar(`admin:${admin.name}`, admin.id, { texto, titulo: `Feedback: ${g.motivoNome} (${g.especialista})`.slice(0, 120), categoria: ESP[g.especialista] })
  const now = nowIso()
  for (const fid of g.ids) await q("UPDATE response_feedback SET status = 'proposto', lab_proposal_id = $1, updated_at = $2 WHERE id = $3", [id, now, fid])
  return { ok: true, propostaId: id, feedbacks: g.ids.length }
}
export async function descartar(chave: string) {
  const g = (await oportunidades()).find((x) => x.chave === chave); if (!g) fail(404, 'Oportunidade não encontrada.', 'not_found')
  const now = nowIso(); for (const fid of g.ids) await q("UPDATE response_feedback SET status = 'descartado', updated_at = $1 WHERE id = $2", [now, fid])
  return { ok: true, feedbacks: g.ids.length }
}
