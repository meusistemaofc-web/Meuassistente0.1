// Detecta duplicidades, contradições e regras executáveis incompatíveis entre os itens do Cérebro (ativos e pendentes).
// Não altera nada: devolve a lista para o administrador decidir. Quando dois itens divergem, informa qual prevalece (maior prioridade).
import { q } from '../db/index.js'

export interface Conflito { tipo: 'duplicado' | 'contradicao' | 'regra_incompativel'; gravidade: 'alta' | 'media'; a: number; b: number; titulos: [string, string]; motivo: string; prevalece: number | null }
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const dice = (a: string, b: string) => { const wa = new Set(a.split(' ').filter((w) => w.length > 2)), wb = new Set(b.split(' ').filter((w) => w.length > 2)); if (!wa.size || !wb.size) return 0; let i = 0; for (const w of wa) if (wb.has(w)) i++; return (2 * i) / (wa.size + wb.size) }
const stem = (w: string) => (w.length <= 4 ? w : w.replace(/(oes|aes)$/, 'ao').replace(/(es|s)$/, ''))
const STOP = new Set('a o os as um uma de da do das dos e ou em no na para por com sem que se ao como mais sobre'.split(' '))
const stems = (t: string) => new Set(norm(t).split(' ').filter((w) => w.length > 2 && !STOP.has(w)).map(stem))
const jaccard = (a: Set<string>, b: Set<string>) => { let i = 0; for (const x of a) if (b.has(x)) i++; return a.size + b.size - i ? i / (a.size + b.size - i) : 0 }
const nums = (t: string) => new Set((String(t).match(/\d+(?:[.,]\d+)?/g) || []).map((n) => String(Number(n.replace(',', '.')))))
const POS = /\b(sempre|pode|podem|permitid\w*|permitimos|gratuit\w*|gratis|aceitamos|aceita|obrigatori\w*)\b/
const NEG = /\b(nunca|jamais|nao pode|nao podem|proibid\w*|vedad\w*|nao aceitamos|nao aceita|nao fazemos|nao ha)\b/
const escopoCruza = (a: string, b: string) => a === b || a === 'todos' || b === 'todos'
const prioridade = (a: any, b: any) => (Number(a.priority) === Number(b.priority) ? null : Number(a.priority) > Number(b.priority) ? Number(a.id) : Number(b.id))
const trig = (r: any): string[] => { try { return JSON.parse(r.rule_trigger || '[]') } catch { return [] } }

/** Sem itemId: confere todos os pares; com itemId: só os pares que envolvem aquele item. */
export async function detectConflicts(itemId?: number): Promise<Conflito[]> {
  const rows: any[] = await q("SELECT id, user_id, question, answer, kind, nature, scope, priority, origin, reviewed, status, rule_action, rule_trigger, rule_params FROM brain_answers WHERE status IN ('ativo','pendente') ORDER BY id DESC LIMIT 1500")
  const alvo = itemId != null ? rows.find((r) => Number(r.id) === itemId) : null
  if (itemId != null && !alvo) return []
  // respostas aprendidas de usuários só entram na comparação quando são o próprio alvo (evita ruído)
  const pool = rows.filter((r) => (r.kind || 'resposta') !== 'resposta' || r.origin === 'admin' || (alvo && Number(r.id) === Number(alvo.id)))
  const out: Conflito[] = []
  const seen = new Set<string>()
  const par = (a: any, b: any) => {
    if (a.user_id != null && b.user_id != null && Number(a.user_id) !== Number(b.user_id)) return
    if (!escopoCruza(a.scope || 'chat', b.scope || 'chat')) return
    const key = [Number(a.id), Number(b.id)].sort().join('-'); if (seen.has(key)) return; seen.add(key)
    const ta = norm(a.question), tb = norm(b.question), ca = norm(a.answer).slice(0, 700), cb = norm(b.answer).slice(0, 700)
    const base = { a: Number(a.id), b: Number(b.id), titulos: [String(a.question), String(b.question)] as [string, string], prevalece: prioridade(a, b) }
    const exec = a.nature === 'executavel' && b.nature === 'executavel'
    if (exec) {
      const ga = trig(a), gb = trig(b)
      const cruzam = ga.some((x) => gb.some((y) => x === y || ` ${x} `.includes(` ${y} `) || ` ${y} `.includes(` ${x} `)))
      if (cruzam && a.rule_action !== 'anexar' && b.rule_action !== 'anexar') {
        const igual = a.rule_action === b.rule_action && String(a.rule_params) === String(b.rule_params)
        if (!igual) out.push({ ...base, tipo: 'regra_incompativel', gravidade: 'alta', motivo: `As duas regras disparam na mesma frase mas fazem coisas diferentes (${a.rule_action} × ${b.rule_action}).${base.prevalece ? ` Prevalece a #${base.prevalece} (maior prioridade).` : ' Têm a mesma prioridade: defina qual vale mais.'}` })
        else out.push({ ...base, tipo: 'duplicado', gravidade: 'media', motivo: 'Regras executáveis iguais (mesmo gatilho, ação e parâmetros).' })
      }
      return
    }
    if (a.nature === 'executavel' || b.nature === 'executavel') return
    if (ta === tb || (dice(ta, tb) >= 0.85 && dice(ca, cb) >= 0.7) || (ca.length > 40 && dice(ca, cb) >= 0.9)) { out.push({ ...base, tipo: 'duplicado', gravidade: 'media', motivo: 'Mesmo assunto e conteúdo praticamente igual.' }); return }
    if (jaccard(stems(a.question), stems(b.question)) >= 0.5 || dice(ta, tb) >= 0.6) {
      const na = nums(a.answer), nb = nums(b.answer)
      const soA = [...na].filter((x) => !nb.has(x)), soB = [...nb].filter((x) => !na.has(x))
      const pa = POS.test(ca) && NEG.test(cb), pb = NEG.test(ca) && POS.test(cb)
      if (pa || pb) out.push({ ...base, tipo: 'contradicao', gravidade: 'alta', motivo: `Dizem o oposto sobre o mesmo assunto (um afirma, o outro nega).${base.prevalece ? ` Prevalece a #${base.prevalece} (maior prioridade).` : ' Têm a mesma prioridade: revise.'}` })
      else if (na.size && nb.size && soA.length && soB.length) out.push({ ...base, tipo: 'contradicao', gravidade: 'media', motivo: `Valores diferentes para o mesmo assunto (${soA.slice(0, 3).join(', ')} × ${soB.slice(0, 3).join(', ')}).${base.prevalece ? ` Prevalece a #${base.prevalece} (maior prioridade).` : ' Têm a mesma prioridade: revise.'}` })
    }
  }
  if (alvo) { for (const r of pool) if (Number(r.id) !== Number(alvo.id)) par(alvo, r) }
  else for (let i = 0; i < pool.length; i++) for (let j = i + 1; j < pool.length && j < i + 400; j++) par(pool[i], pool[j])
  return out
}
