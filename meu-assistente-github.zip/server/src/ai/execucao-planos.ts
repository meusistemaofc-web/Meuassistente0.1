// PLANEJAMENTO AUTÔNOMO (Fase 8) — transforma objetivos em linguagem do dia a dia em planos de execução (etapas,
// dependências, prioridade e nível de autonomia) sobre o catálogo de operações, e conversa sobre eles no chat:
// confirmação ("sim"), autorização explícita ("autorizo EX-…"), andamento, cancelamento e "desfazer".
// O usuário não precisa conhecer módulos nem comandos: "crie lembretes para os compromissos de amanhã" basta.
import { q, J } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import * as EX from './execucao.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9$ ]/g, ' ').replace(/\s+/g, ' ').trim()
const addDias = (d: string, n: number) => new Date(Date.parse(d + 'T12:00:00Z') + n * 864e5).toISOString().slice(0, 10)
const dm = (d: string) => `${String(d).slice(8, 10)}/${String(d).slice(5, 7)}`
const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d),)/g, '.')
const SEM = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb']
const ds = (d: string) => SEM[new Date(d + 'T12:00:00Z').getUTCDay()]

async function itens(u: SessionUser, type: string, extra = '', p: any[] = []) { const { listItems, serialize } = await import('../routes/items.js'); return (await listItems(u.id, type as any, extra, p)).map(serialize) as any[] }
const ativo = (a: any) => !['cancelled', 'done', 'no_show'].includes(a.status || 'scheduled')

/* ---------- consultas (etapas de leitura que alimentam as seguintes) ---------- */
export async function consultar(u: SessionUser, tipo: string, hoje: string) {
  if (tipo === 'agenda') { const ap = (await itens(u, 'appointment', 'AND day >= $3 AND day <= $4', [hoje, addDias(hoje, 6)])).filter(ativo), tk = await itens(u, 'task', "AND (status IS NULL OR status <> 'done')"); return { compromissos: ap.length, tarefas: tk.length } }
  if (tipo === 'previsoes') { const r = await (await import('./preditivo-servico.js')).paraUsuario(u, { registrar: false }); return { sinais: r.sinais.length, urgentes: r.sinais.filter((s: any) => s.urgencia === 'alta').length } }
  if (tipo === 'financas') { const fx = await itens(u, 'expense', 'AND day >= $3', [hoje.slice(0, 7) + '-01']); return { lancamentos: fx.length } }
  return null
}
/* ---------- documentos gerados com os dados reais (viram uma NOTA: o módulo de documentos que já existe) ---------- */
export async function compor(u: SessionUser, modelo: string, hoje: string): Promise<{ title: string; content: string }> {
  if (modelo === 'plano_semana') {
    const ap = (await itens(u, 'appointment', 'AND day >= $3 AND day <= $4 ORDER BY day', [hoje, addDias(hoje, 6)])).filter(ativo).sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')))
    const tk = (await itens(u, 'task', "AND (status IS NULL OR status <> 'done')")).sort((a, b) => String(a.dueDate || '9').localeCompare(String(b.dueDate || '9')))
    const pv = (await (await import('./preditivo-servico.js')).paraUsuario(u, { registrar: false })).sinais.filter((s: any) => s.urgencia !== 'baixa').slice(0, 8)
    const L = [`Plano da semana — ${dm(hoje)} a ${dm(addDias(hoje, 6))}`, '', 'COMPROMISSOS']
    for (let i = 0; i < 7; i++) { const d = addDias(hoje, i), xs = ap.filter((a) => a.date === d); if (xs.length) L.push(`${ds(d)} ${dm(d)}: ${xs.map((a) => `${a.time || 's/ horário'} ${a.title}${a.clienteNome ? ' (' + a.clienteNome + ')' : ''}`).join(' · ')}`) }
    if (!ap.length) L.push('Nenhum compromisso nos próximos 7 dias.')
    L.push('', 'TAREFAS EM ABERTO'); for (const t of tk.slice(0, 15)) L.push(`- ${t.title}${t.dueDate ? ` (prazo ${dm(t.dueDate)}${t.dueDate < hoje ? ', atrasada' : ''})` : ''}`); if (!tk.length) L.push('Nenhuma tarefa em aberto.')
    L.push('', 'ATENÇÃO'); for (const s of pv) L.push(`- ${s.titulo} [${s.natureza === 'fato' ? 'fato' : `estimativa ${s.confianca}%`}]`); if (!pv.length) L.push('Nada urgente apontado pelas previsões.')
    return { title: `Plano da semana ${dm(hoje)}`, content: L.join('\n') }
  }
  if (modelo === 'relatorio_financeiro') {
    const mes = hoje.slice(0, 7), fx = await itens(u, 'expense', 'AND day >= $3 AND day <= $4', [mes + '-01', mes + '-31']), bl = await itens(u, 'bill', "AND status = 'pending' AND day <= $3", [addDias(hoje, 30)])
    const ent = fx.filter((f) => f.kind === 'income').reduce((a, f) => a + Number(f.amount), 0), sai = fx.filter((f) => f.kind !== 'income').reduce((a, f) => a + Number(f.amount), 0)
    const cat = new Map<string, number>(); for (const f of fx.filter((x) => x.kind !== 'income')) cat.set(f.category, (cat.get(f.category) || 0) + Number(f.amount))
    const L = [`Relatório financeiro — ${mes.slice(5)}/${mes.slice(0, 4)} (até ${dm(hoje)})`, '', `Entradas: ${brl(ent)}`, `Saídas: ${brl(sai)}`, `Saldo do mês: ${brl(ent - sai)}`, '', 'GASTOS POR CATEGORIA']
    for (const [c, v] of [...cat].sort((a, b) => b[1] - a[1])) L.push(`- ${c}: ${brl(v)} (${sai ? Math.round((v / sai) * 100) : 0}%)`); if (!cat.size) L.push('Nenhum gasto lançado neste mês.')
    L.push('', 'CONTAS A PAGAR (30 dias)'); for (const b of bl.slice(0, 15)) L.push(`- ${b.name}: ${b.amount ? brl(b.amount) : 'sem valor'} · vence ${dm(b.dueDate)}${b.dueDate < hoje ? ' (atrasada)' : ''}`); if (!bl.length) L.push('Nenhuma conta pendente.')
    L.push('', `${fx.length} lançamento(s) considerados. Valores lidos dos seus registros; nada foi alterado.`)
    return { title: `Relatório financeiro ${mes.slice(5)}/${mes.slice(0, 4)}`, content: L.join('\n') }
  }
  throw Object.assign(new Error('Modelo de documento desconhecido.'), { status: 400 })
}
EX.OPERACOES['documento.gerar'] = { id: 'documento.gerar', nome: 'Gerar documento com os dados', nivel: 1, reversivel: true, repetivel: false,
  executar: async (c, a) => { const d = await compor(c.u, a.modelo, c.hoje); const r = await EX.OPERACOES['documento.criar'].executar(c, d); return { ...r, titulo: d.title } },
  localizar: async (c, a) => { const d = await compor(c.u, a.modelo, c.hoje).catch(() => null); return d ? EX.OPERACOES['documento.criar'].localizar!(c, d) : null },
  verificar: async (c, _a, r) => EX.OPERACOES['documento.criar'].verificar(c, { content: '' }, r),
  desfazer: async (c, a, r) => EX.OPERACOES['documento.criar'].desfazer!(c, a, r) }

/* ---------- objetivos reconhecidos (linguagem do dia a dia → plano) ---------- */
type Montado = { plano: EX.NovoPlano } | { vazio: string }
interface Objetivo { id: string; nome: string; gatilho: RegExp; montar: (u: SessionUser, s: string, hoje: string, texto: string) => Promise<Montado | any> }
const periodo = (s: string, hoje: string): [string, string, string] => /\bhoje\b/.test(s) ? [hoje, hoje, 'de hoje'] : /\b(semana|proximos 7 dias|proximos dias)\b/.test(s) ? [hoje, addDias(hoje, 6), 'dos próximos 7 dias'] : [addDias(hoje, 1), addDias(hoje, 1), 'de amanhã']
export const OBJETIVOS: Objetivo[] = [
  { id: 'lembretes_compromissos', nome: 'Lembretes para compromissos', gatilho: /\b(cri\w*|coloc\w*|adicion\w*|ativ\w*|poe|ponha|bot\w*)\b.{0,25}\blembretes?\b.{0,30}\b(para|pra|em|nos|de) (todos )?(os )?(meus )?compromissos\b/,
    montar: async (u, s, hoje) => { const [de, ate, rot] = periodo(s, hoje)
      // compromisso sem horário que já ganhou o lembrete alternativo (às 08:00) não entra de novo
      const jaTem = new Set((await itens(u, 'reminder', "AND (status IS NULL OR status = 'pending')")).map((r) => `${r.message}|${r.date}`))
      const ap = (await itens(u, 'appointment', 'AND day >= $3 AND day <= $4', [de, ate])).filter((a) => ativo(a) && !(a.reminders || []).length && !(!a.time && jaTem.has(`Compromisso: ${a.title}|${a.date}`)))
      if (!ap.length) return { vazio: `Os compromissos ${rot} já têm lembrete (ou não há compromissos). Nada a fazer.` }
      return { plano: { playbook: 'lembretes_compromissos', goal: `Lembretes para os compromissos ${rot}`, chave: [de, ate], passos: ap.map((a) => ({ op: 'compromisso.lembrete', rotulo: `Lembrete 1 h antes: ${a.title} (${ds(a.date)} ${dm(a.date)}${a.time ? ' ' + a.time : ''})`, args: { id: a.id, minutos: 60, titulo: a.title, data: a.date } })) } } } },
  { id: 'concluir_passados', nome: 'Concluir compromissos que já passaram', gatilho: /\b(mar[cq]\w*|conclu\w*|finaliz\w*|fech\w*|atualiz\w*)\b.{0,40}\bcompromissos?\b.{0,25}\b(que )?(ja )?(passaram|passados|antigos|anteriores|atrasados)\b/,
    montar: async (u, _s, hoje) => { const ap = (await itens(u, 'appointment', 'AND day < $3 AND day >= $4', [hoje, addDias(hoje, -90)])).filter(ativo)
      if (!ap.length) return { vazio: 'Não há compromissos passados com situação em aberto. Nada a fazer.' }
      return { plano: { playbook: 'concluir_passados', goal: 'Marcar como concluídos os compromissos que já passaram', passos: ap.map((a) => ({ op: 'compromisso.situacao', rotulo: `Concluir: ${a.title} (${dm(a.date)})`, args: { id: a.id, status: 'done', versao: a.updatedAt } })) } } } },
  { id: 'organizar_semana', nome: 'Organizar a semana', gatilho: /\b(organiz\w*|planej\w*|monte?\w*)\b.{0,20}\b(a |minha )?semana\b/,
    montar: async (u, _s, hoje) => { const pv = (await (await import('./preditivo-servico.js')).paraUsuario(u, { registrar: false })).sinais.filter((x: any) => x.urgencia === 'alta' && x.acao).slice(0, 3)
      const passos: any[] = [{ op: 'consulta', rotulo: 'Ler agenda e tarefas da semana', args: { tipo: 'agenda' } }, { op: 'consulta', rotulo: 'Ler alertas e previsões', args: { tipo: 'previsoes' } }, { op: 'documento.gerar', rotulo: 'Criar o documento "Plano da semana" nas suas notas', args: { modelo: 'plano_semana' }, depende: [1, 2] }]
      for (const x of pv as any[]) passos.push({ op: 'tarefa.criar', rotulo: `Criar tarefa: ${x.acao.charAt(0).toUpperCase() + x.acao.slice(1)}`, args: { title: (x.acao.charAt(0).toUpperCase() + x.acao.slice(1)).slice(0, 120), due_date: hoje, notes: x.titulo }, depende: [2] })
      return { plano: { playbook: 'organizar_semana', goal: 'Organizar a semana', background: true, chave: hoje, passos } } } },
  { id: 'relatorio_financeiro', nome: 'Relatório financeiro do mês', gatilho: /\b(relatorio|balanco|fechamento)\b.{0,30}\b(financ\w*|gastos|contas|do mes)\b|\b(financ\w*|gastos)\b.{0,20}\b(relatorio|balanco)\b/,
    montar: async (_u, _s, hoje) => ({ plano: { playbook: 'relatorio_financeiro', goal: 'Relatório financeiro do mês', background: true, chave: hoje, passos: [{ op: 'consulta', rotulo: 'Ler os lançamentos do mês', args: { tipo: 'financas' } }, { op: 'documento.gerar', rotulo: 'Criar o documento "Relatório financeiro" nas suas notas', args: { modelo: 'relatorio_financeiro' }, depende: [1] }] } }) },
  { id: 'excluir_tarefas_concluidas', nome: 'Excluir tarefas concluídas', gatilho: /\b(apag\w*|exclu\w*|remov\w*|limp\w*|delet\w*)\b.{0,20}\btarefas\b.{0,15}\b(ja )?(concluidas|feitas|finalizadas|terminadas)\b/,
    montar: async (u) => { const tk = await itens(u, 'task', "AND status = 'done'"); if (!tk.length) return { vazio: 'Você não tem tarefas concluídas para apagar.' }
      return { plano: { playbook: 'excluir_tarefas_concluidas', goal: `Excluir ${tk.length} tarefa(s) concluída(s)`, passos: tk.slice(0, 50).map((t) => ({ op: 'tarefa.excluir', rotulo: `Excluir tarefa: ${t.title}`, args: { id: t.id } })) } } } },
  { id: 'excluir_compromissos_cancelados', nome: 'Excluir compromissos cancelados', gatilho: /\b(apag\w*|exclu\w*|remov\w*|limp\w*)\b.{0,20}\bcompromissos\b.{0,10}\bcancelados\b/,
    montar: async (u) => { const ap = (await itens(u, 'appointment')).filter((a) => a.status === 'cancelled'); if (!ap.length) return { vazio: 'Não há compromissos cancelados para apagar.' }
      return { plano: { playbook: 'excluir_compromissos_cancelados', goal: `Excluir ${ap.length} compromisso(s) cancelado(s)`, passos: ap.slice(0, 50).map((a) => ({ op: 'compromisso.excluir', rotulo: `Excluir: ${a.title} (${dm(a.date)})`, args: { id: a.id } })) } } } },
  { id: 'pagar_contas', nome: 'Marcar contas como pagas', gatilho: /\b(mar[cq]\w*|registr\w*|dar? baixa)\b.{0,40}\bcontas?\b.{0,60}\bcomo pagas?\b|\bdar? baixa (n|em|d)?[ao]s? contas?\b/,
    montar: async (u, s) => { const pend = await itens(u, 'bill', "AND status = 'pending'"); const alvo = pend.filter((b) => { const n = nrm(b.name); return n && new RegExp(`\\b${n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(s) })
      if (!alvo.length) return { vazio: pend.length ? `Não encontrei essas contas entre as pendentes (${pend.slice(0, 6).map((b) => b.name).join(', ')}). Diga o nome de cada uma.` : 'Você não tem contas pendentes.' }
      return { plano: { playbook: 'pagar_contas', goal: `Marcar como paga(s): ${alvo.map((b) => b.name).join(', ')}`, passos: alvo.map((b) => ({ op: 'conta.pagar', rotulo: `Pagar: ${b.name}${b.amount ? ' (' + brl(b.amount) + ')' : ''} · vence ${dm(b.dueDate)}`, args: { id: b.id } })) } } } },
  { id: 'crm_acompanhamento', nome: 'Tarefas de acompanhamento no CRM', gatilho: /\b(cri\w*|ger\w*)\b.{0,15}\btarefas?\b.{0,15}\b(de )?(acompanhamento|retorno|follow ?up|contato)\b.{0,30}\b(leads?|clientes|oportunidades)\b/,
    montar: async (u, _s, hoje) => {
      const passos: any[] = []
      for (const b of (await q('SELECT id, name FROM businesses WHERE owner_id = $1 LIMIT 3', [u.id]).catch(() => [])) as any[]) {
        try { const C = await import('../lib/crm.js'); await C.acesso(u.id, Number(b.id)); const A: any = await C.CommercialIntelligenceService.analise(Number(b.id))
          for (const x of (A.leadsSemAcompanhamento || []).slice(0, 10)) passos.push({ op: 'crm.tarefa', rotulo: `${b.name}: contato com o lead ${x.nome}`, args: { empresa: Number(b.id), titulo: `Contato com ${x.nome}`, contatoId: x.contatoId, tipo: 'contato', prazo: addDias(hoje, 1) } })
          for (const x of (A.clientesParaRetorno || []).slice(0, 10)) passos.push({ op: 'crm.tarefa', rotulo: `${b.name}: retorno com ${x.nome}`, args: { empresa: Number(b.id), titulo: `Retorno com ${x.nome}`, contatoId: x.contatoId, tipo: 'retorno', prazo: addDias(hoje, 1) } })
          for (const x of (A.oportunidadesParadas || []).slice(0, 10)) passos.push({ op: 'crm.tarefa', rotulo: `${b.name}: retomar "${x.titulo}"`, args: { empresa: Number(b.id), titulo: `Retomar negociação: ${x.titulo}`, oportunidadeId: x.oportunidadeId, tipo: 'acompanhamento', prazo: addDias(hoje, 1) } })
        } catch { /* sem plano/permissão de CRM nessa empresa */ }
      }
      if (!passos.length) return { vazio: 'Não encontrei leads, clientes ou oportunidades pedindo acompanhamento no CRM das suas empresas (ou você não tem acesso ao CRM).' }
      return { plano: { playbook: 'crm_acompanhamento', goal: 'Criar tarefas de acompanhamento no CRM', chave: hoje, passos } }
    } },
]
export function interpretar(texto: string) { const s = nrm(texto); return OBJETIVOS.find((o) => o.gatilho.test(s)) || null }
/** Planeja e (se nível 1) executa: pequeno = na hora; grande ou demorado = segundo plano com aviso ao terminar. */
export async function iniciar(u: SessionUser, o: Objetivo, texto: string, hoje: string, convId: string | null, origin = 'chat') {
  const m = await o.montar(u, nrm(texto), hoje, texto); if ('vazio' in m) return { texto: m.vazio, exec: null as EX.Exec | null }
  const p = m.plano; p.conversationId = convId; p.origin = origin; if (p.passos.length > 5) p.background = true
  const { exec, repetida } = await EX.criarExecucao(u, p)
  if (repetida) return { texto: `Esse pedido já foi feito há pouco (${exec.id}, ${STATUS[exec.status] || exec.status}). Não vou repetir para não duplicar. ⟦btn:/execucoes#${exec.id}|Ver execução⟧`, exec }
  return { texto: await depoisDeCriar(u, exec), exec }
}
export const STATUS: Record<string, string> = { aguardando_confirmacao: 'aguardando sua confirmação', aguardando_autorizacao: 'aguardando sua autorização', na_fila: 'na fila', executando: 'em andamento', cancelando: 'cancelando', concluida: 'concluída', parcial: 'concluída em parte', falhou: 'falhou', interrompida: 'interrompida', cancelada: 'cancelada', expirada: 'expirada', revertida: 'revertida' }
const marca = (s: EX.Passo) => (s.status === 'feito' ? (s.verificado ? '✓' : '?') : s.status === 'revertido' ? '↺' : s.status === 'pendente' || s.status === 'cancelado' ? '·' : '✗')
export function resumo(e: EX.Exec) {
  const L = e.steps.slice(0, 12).map((s) => `${marca(s)} ${s.rotulo}${s.status === 'feito' ? '' : s.status === 'pendente' ? '' : ` — ${s.status}${s.classe ? ' (' + (EX.CLASSE_NOME[s.classe] || s.classe) + ')' : ''}${s.erro && s.status !== 'cancelado' ? ': ' + s.erro : ''}`}`)
  if (e.steps.length > 12) L.push(`… e mais ${e.steps.length - 12} etapa(s)`)
  return L.join('\n')
}
async function depoisDeCriar(u: SessionUser, e: EX.Exec) {
  const plano = e.steps.slice(0, 12).map((s) => `${s.n}. ${s.rotulo}${s.nivel > 1 ? ` [${s.nivel === 3 ? 'autorização' : 'confirmação'}]` : ''}`).join('\n') + (e.steps.length > 12 ? `\n… e mais ${e.steps.length - 12}` : '')
  if (e.status === 'aguardando_autorizacao') return `Preparei o plano ${e.id} (${e.steps.length} etapa(s)):\n${plano}\n\nIsso inclui exclusão ou pagamento, então preciso da sua **autorização explícita**: responda "autorizo ${e.id}". Para desistir, diga "cancela".`
  if (e.status === 'aguardando_confirmacao') return `Preparei o plano ${e.id} (${e.steps.length} etapa(s)):\n${plano}\n\nPosso executar? Responda "sim" para confirmar ou "cancela" para desistir.`
  return iniciarExecucao(u, e)
}
/** Execução aprovada: em segundo plano (avisa ao terminar) ou na hora, sempre relatando o resultado VERIFICADO. */
export async function iniciarExecucao(u: SessionUser, e: EX.Exec) {
  if (e.background) { void EX.executar(u, e.id).catch((err) => console.error('[execução]', e.id, err?.message)); return `Comecei: ${e.goal.toLowerCase()} (${e.id}, ${e.steps.length} etapa(s)). Vou te avisar quando terminar — pode continuar usando o app. Para acompanhar, pergunte "como está a tarefa?" ou abra os detalhes. ⟦btn:/execucoes#${e.id}|Acompanhar⟧` }
  const f = await EX.executar(u, e.id), ok = f.steps.filter((s) => s.status === 'feito' && s.verificado).length
  const cab = f.status === 'concluida' ? `Pronto — ${f.id} concluída e conferida no sistema (${ok} de ${f.steps.length}):` : f.status === 'parcial' ? `Fiz uma parte — ${f.id}: ${ok} de ${f.steps.length} etapa(s) conferidas; o restante não foi concluído:` : f.status === 'interrompida' ? `Parei — ${f.id}: houve risco de inconsistência e interrompi as etapas seguintes (${ok} de ${f.steps.length} concluídas):` : `Não consegui — ${f.id}: nenhuma etapa foi concluída:`
  return `${cab}\n${resumo(f)}${f.status !== 'concluida' ? '\n\nO que foi feito está conferido; o resto você pode tentar de novo ou ajustar.' : ''} ⟦btn:/execucoes#${f.id}|Ver detalhes⟧`
}

/* ---------- conversa: aprovar, autorizar, cancelar, acompanhar e desfazer em linguagem natural ---------- */
const CODIGO = /\bEX-[0-9A-F]{6}\b/
const desfazerPendente = new Map<string, { id: string; em: number }>()
export async function responderChat(u: SessionUser, convId: string, texto: string, hist: { role: string; content: string }[], hoje: string): Promise<{ content: string; cards: any[] } | null> {
  const cfg = await EX.execCfg(); if (!cfg.ativo) return null
  const s = nrm(texto), ultima = [...hist].reverse().find((m) => m.role === 'assistant')?.content || '', cod = (texto.toUpperCase().match(CODIGO) || ultima.match(CODIGO) || [])[0]
  const R = (t: string) => ({ content: t, cards: [] })
  // 1) resposta a um plano que aguarda aprovação (a pergunta está na última mensagem do assistente)
  if (cod && /aguard|Posso executar|autoriza[çc][ãa]o expl[íi]cita|autorizo EX-/.test(ultima) && ultima.includes(cod)) {
    let e: EX.Exec; try { e = await EX.obter(u.id, cod) } catch { e = null as any }
    if (e && ['aguardando_confirmacao', 'aguardando_autorizacao'].includes(e.status)) {
      if (/^(nao|n|cancela\w*|desist\w*|deixa|esquece|para)\b/.test(s)) { await EX.cancelar(u, e.id); return R(`Tudo bem, cancelei o plano ${e.id}. Nada foi executado.`) }
      if (/\bautoriz\w*\b/.test(s)) {
        if (e.status === 'aguardando_confirmacao') { await EX.aprovar(u, e.id, 'confirmar'); return R(await iniciarExecucao(u, await EX.obter(u.id, e.id))) }
        if (!s.toUpperCase().includes(e.id.replace('-', ' ')) && !texto.toUpperCase().includes(e.id)) return R(`Para autorizar com segurança, repita o código: "autorizo ${e.id}".`)
        await EX.aprovar(u, e.id, 'autorizar'); return R(await iniciarExecucao(u, await EX.obter(u.id, e.id)))
      }
      if (/^(sim|s|pode|ok|confirmo|confirma|manda ver|faz|faca|isso|pode fazer|pode executar|beleza|claro)\b/.test(s)) {
        if (e.status === 'aguardando_autorizacao') return R(`Este plano inclui exclusão ou pagamento: um "sim" não basta. Se quiser mesmo, responda "autorizo ${e.id}".`)
        await EX.aprovar(u, e.id, 'confirmar'); return R(await iniciarExecucao(u, await EX.obter(u.id, e.id)))
      }
    }
  }
  // 2) confirmação de "desfazer"
  const dp = desfazerPendente.get(convId)
  if (dp && Date.now() - dp.em < 10 * 60e3 && /^(sim|s|pode|confirmo|ok|isso)\b/.test(s)) { desfazerPendente.delete(convId); const r = await EX.reverter(u, dp.id); return R(`Desfiz ${r.desfeitas} etapa(s) de ${dp.id}${r.semReversao ? `; ${r.semReversao} não têm como ser desfeitas` : ''}${r.falhas ? `; ${r.falhas} falharam` : ''}. ⟦btn:/execucoes#${dp.id}|Ver detalhes⟧`) }
  if (dp && /^(nao|n|deixa|esquece)\b/.test(s)) { desfazerPendente.delete(convId); return R('Certo, mantive tudo como está.') }
  const ultimaExec = async () => { const r = await (cod ? q('SELECT * FROM executions WHERE id = $1 AND user_id = $2', [cod, u.id]) : q('SELECT * FROM executions WHERE user_id = $1 AND (conversation_id = $2 OR conversation_id IS NULL) ORDER BY created_at DESC LIMIT 1', [u.id, convId])).catch(() => []); return (r as any[])[0] ? await EX.obter(u.id, String((r as any[])[0].id)) : null }
  // 3) andamento
  if (/\b(como (esta|ta|ficou|anda|vai)|andamento|status|ja terminou|terminou)\b.{0,25}\b(tarefa|execu\w*|operac\w*|plano|relatorio|organiza\w*|pedido)\b|\b(tarefa|execu\w*|operac\w*) (ja )?(terminou|acabou)\b/.test(s)) {
    const e = await ultimaExec(); if (!e) return null
    return R(`${e.id} — ${e.goal}: ${STATUS[e.status] || e.status}, ${e.progress}%.\n${resumo(e)} ⟦btn:/execucoes#${e.id}|Ver detalhes⟧`)
  }
  // 4) cancelar o que está rodando
  if (/^(cancel\w*|pare|para|interromp\w*)\b.{0,25}\b(tarefa|execu\w*|operac\w*|isso)\b/.test(s)) {
    const e = await ultimaExec(); if (!e || !['executando', 'na_fila', 'aguardando_confirmacao', 'aguardando_autorizacao'].includes(e.status)) return null
    const c: any = await EX.cancelar(u, e.id); return R(c?.status === 'cancelando' ? `Pedi para parar ${e.id}: a etapa em andamento termina e as próximas não serão feitas. O que já foi feito continua (dá para desfazer).` : `Cancelei ${e.id}. Nada mais será executado.`)
  }
  // 5) desfazer o que acabou de ser feito (pede confirmação)
  if (/^(desfa\w*|reverte\w*|volta (atras|como estava))\b/.test(s)) {
    const e = await ultimaExec(); if (!e || !EX.publico(e).podeReverter) return null
    desfazerPendente.set(convId, { id: e.id, em: Date.now() })
    return R(`Vou desfazer o que ${e.id} fez (${e.steps.filter((x) => x.status === 'feito').length} etapa(s): ${e.goal.toLowerCase()}). Confirma? (sim/não)`)
  }
  // 6) um objetivo novo
  const o = interpretar(texto); if (!o) return null
  return R((await iniciar(u, o, texto, hoje, convId)).texto)
}
export const _int = { desfazerPendente }
void J
