// Classificação de DESPESAS de comprovantes por evidências (funciona sem nenhuma IA).
// Ordem de decisão:
//   1) natureza dos PRODUTOS/serviços escritos no comprovante (itens da nota, descrição);
//   2) correção anterior do PRÓPRIO usuário para o mesmo estabelecimento (aprendizado isolado por conta);
//   3) ESTABELECIMENTO (nome e atividade: "supermercado", "auto posto", "drogaria"…);
//   4) CONTEXTO da transação (boleto de energia, palavras do dicionário do financeiro);
//   5) sem segurança → Outros.
// Usa SÓ as categorias que já existem no financeiro (e as subcategorias delas: "Mercado" é Alimentação › Mercado).
import { getUM, setUM } from '../lib/usermod.js'
import { catFromText, FIN_CATS } from './fin.js'

const nrm = (t: string) => ' ' + String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim() + ' '

export interface Classificacao {
  cat: string
  sub: string
  /** alta: evidência forte (vários produtos, atividade explícita ou correção do usuário); media: evidência única; baixa: nenhuma (Outros) */
  confianca: 'alta' | 'media' | 'baixa'
  /** de onde veio (uso interno/testes; NUNCA é mostrado ao usuário) */
  fonte: 'produtos' | 'aprendido' | 'estabelecimento' | 'contexto' | 'complemento' | 'nenhuma'
}

type Regra = { cat: string; sub: string; palavras: string[] }
// produtos e serviços (o que foi comprado)
const PRODUTOS: Regra[] = [
  { cat: 'alimentacao', sub: 'Mercado', palavras: ['arroz', 'feijao', 'acucar', 'farinha', 'macarrao', 'oleo de soja', 'oleo soja', 'azeite', 'leite', 'manteiga', 'margarina', 'iogurte', 'queijo', 'presunto', 'mortadela', 'ovos', 'ovo branco', 'carne', 'carne moida', 'patinho', 'alcatra', 'acem', 'costela', 'frango', 'file de peito', 'coxa', 'peixe', 'tilapia', 'linguica', 'salsicha', 'banana', 'maca', 'laranja', 'limao', 'mamao', 'melancia', 'abacaxi', 'uva', 'tomate', 'cebola', 'alho', 'batata', 'cenoura', 'alface', 'couve', 'cheiro verde', 'coentro', 'pimentao', 'chuchu', 'abobora', 'verdura', 'verduras', 'legume', 'legumes', 'fruta', 'frutas', 'hortifruti', 'pao de forma', 'pao frances', 'biscoito', 'bolacha', 'cafe em po', 'cafe po', 'achocolatado', 'sabao', 'detergente', 'amaciante', 'agua sanitaria', 'papel higienico', 'creme dental', 'sabonete', 'desinfetante', 'esponja', 'flocao', 'cuscuz', 'tapioca goma', 'goma de tapioca', 'sal refinado', 'tempero', 'extrato de tomate', 'molho de tomate', 'refrigerante 2l', 'agua mineral 1 5'] },
  { cat: 'combustivel', sub: 'Combustível', palavras: ['gasolina', 'gasolina comum', 'gasolina aditivada', 'etanol', 'alcool hidratado', 'diesel', 'diesel s10', 'gnv', 'combustivel', 'arla'] },
  { cat: 'saude', sub: 'Farmácia', palavras: ['medicamento', 'medicamentos', 'remedio', 'comprimido', 'comprimidos', 'capsula', 'capsulas', 'xarope', 'pomada', 'dipirona', 'paracetamol', 'ibuprofeno', 'amoxicilina', 'azitromicina', 'losartana', 'omeprazol', 'nimesulida', 'dorflex', 'neosaldina', 'buscopan', 'loratadina', 'generico', 'mg cx', 'ampola', 'soro fisiologico', 'curativo', 'esparadrapo'] },
  { cat: 'alimentacao', sub: 'Restaurante e lanches', palavras: ['refeicao', 'refeicoes', 'prato feito', 'prato executivo', 'marmita', 'marmitex', 'self service', 'a la carte', 'couvert', 'taxa de servico', 'gorjeta', 'x burguer', 'x tudo', 'hamburguer', 'pizza', 'lanche', 'sanduiche', 'porcao', 'espetinho', 'suco natural', 'combo'] },
  { cat: 'lazer', sub: 'Passeios e viagens', palavras: ['ingresso', 'ingressos', 'sessao', 'cinema', 'sala 3d', 'pipoca', 'show', 'teatro', 'espetaculo', 'parque'] },
]
// estabelecimento e atividade comercial (o nome costuma trazer a atividade)
const ESTABELECIMENTO: Regra[] = [
  { cat: 'alimentacao', sub: 'Mercado', palavras: ['supermercado', 'supermercados', 'super mercado', 'mercado', 'mercadinho', 'minimercado', 'mini mercado', 'mercearia', 'atacadao', 'atacadista', 'atacarejo', 'assai', 'hortifruti', 'sacolao', 'acougue', 'casa de carnes', 'frigorifico', 'comercio de alimentos', 'comercial de alimentos', 'carrefour', 'pao de acucar', 'extra hiper', 'hipermercado'] },
  { cat: 'combustivel', sub: 'Combustível', palavras: ['posto', 'auto posto', 'autoposto', 'combustiveis', 'combustivel', 'petroleo', 'ipiranga', 'shell', 'petrobras', 'br mania', 'derivados de petroleo'] },
  { cat: 'saude', sub: 'Farmácia', palavras: ['farmacia', 'farmacias', 'drogaria', 'drogarias', 'drogasil', 'droga raia', 'pague menos', 'pacheco', 'panvel', 'extrafarma', 'produtos farmaceuticos'] },
  { cat: 'saude', sub: 'Consultas e exames', palavras: ['clinica', 'laboratorio', 'hospital', 'odontologia', 'consultorio'] },
  { cat: 'alimentacao', sub: 'Restaurante e lanches', palavras: ['restaurante', 'lanchonete', 'pizzaria', 'hamburgueria', 'churrascaria', 'cafeteria', 'padaria e lanchonete', 'sorveteria', 'acaiteria', 'pastelaria', 'ifood', 'bar e restaurante', 'self service', 'galeteria', 'temakeria', 'sushi'] },
  { cat: 'lazer', sub: 'Passeios e viagens', palavras: ['cinema', 'cinemas', 'cinemark', 'kinoplex', 'cinepolis', 'uci', 'teatro', 'parque de diversoes', 'boliche', 'ingresso com', 'sympla', 'eventim'] },
]

function contar(texto: string, regras: Regra[]) {
  const t = nrm(texto), placar = new Map<string, { r: Regra; n: number }>()
  for (const r of regras) {
    const n = r.palavras.filter((w) => t.includes(' ' + w + ' ')).length
    if (n) { const k = r.cat + '|' + r.sub; const p = placar.get(k); placar.set(k, { r, n: (p?.n || 0) + n }) }
  }
  return [...placar.values()].sort((a, b) => b.n - a.n)
}

/** Remove sufixos societários e números: "MIX CONVIVER LTDA - ME 12.345" → "mix conviver". */
export function chaveEstabelecimento(s: string) {
  return nrm(s).replace(/^\s*(transferencia para|transferencia enviada para|recebido de|pagamento para|pagamento a|pix para|pix enviado para|compra em|compra no|compra na)\s/, ' ').replace(/\b(ltda|me|epp|eireli|s a|sa|cia|filial|matriz|loja|unidade|com|comercio|de|do|da|e)\b/g, ' ').replace(/\b\d+\b/g, ' ').replace(/\s+/g, ' ').trim()
}
// descrições que não identificam quem recebeu: não viram regra (seriam ambíguas)
const GENERICAS = /^(pix enviado|pix recebido|pagamento|recebimento|compra|venda|transferencia|transferencia enviada|transferencia recebida|pagamento de boleto|pagamento com cartao|gasto|despesa|nao identificado|outros|mercado|alimentacao|combustivel|saude|lazer|casa|compras|transporte|trabalho)$/

export async function aprendidoPara(userId: number, estabelecimento: string): Promise<{ cat: string; sub: string } | null> {
  const k = chaveEstabelecimento(estabelecimento); if (k.length < 3 || GENERICAS.test(k)) return null
  const mapa = (await getUM<any>(userId, 'cat_aprendizado', null))?.mapa || {}
  if (mapa[k]) return { cat: mapa[k].cat, sub: mapa[k].sub || '' }
  // mesma empresa escrita de outro jeito ("MIX CONVIVER" × "MIX CONVIVER CENTRO"): uma chave contém a outra, com 2+ palavras em comum
  for (const [ck, v] of Object.entries<any>(mapa)) {
    const a = ck.split(' '), b = k.split(' '), comum = a.filter((w) => w.length > 2 && b.includes(w)).length
    if (comum >= 2 && comum >= Math.min(a.length, b.length)) return { cat: v.cat, sub: v.sub || '' }
  }
  return null
}

/** Guarda a correção feita pelo usuário (só para ele). Uma correção nova substitui a anterior; nada antigo é alterado. */
export async function aprenderCorrecao(userId: number, estabelecimento: string, cat: string, sub: string, tipo: 'income' | 'expense' = 'expense') {
  const k = chaveEstabelecimento(estabelecimento)
  if (tipo !== 'expense' || k.length < 3 || GENERICAS.test(k) || !(FIN_CATS.expense as string[]).includes(cat) || cat === 'outros') return false
  const atual = (await getUM<any>(userId, 'cat_aprendizado', null)) || { mapa: {} }
  const mapa = atual.mapa || {}
  mapa[k] = { cat, sub: sub || '', vezes: (mapa[k]?.cat === cat ? Number(mapa[k].vezes || 0) : 0) + 1, em: new Date().toISOString() }
  // limite de tamanho: mantém as 300 associações mais recentes
  const ord = Object.entries<any>(mapa).sort((a, b) => String(b[1].em).localeCompare(String(a[1].em))).slice(0, 300)
  await setUM(userId, 'cat_aprendizado', { mapa: Object.fromEntries(ord) })
  return true
}

/** Classifica uma despesa a partir do que foi lido do comprovante. Nunca inventa: sem evidência, devolve Outros. */
export async function classificarDespesa(userId: number, e: { texto?: string; estabelecimento?: string; descricao?: string; tipoComprovante?: string; categoriaSugerida?: string }): Promise<Classificacao> {
  const est = String(e.estabelecimento || ''), texto = String(e.texto || '')
  // 1) produtos: o texto do comprovante SEM o nome do estabelecimento (para não contar o nome duas vezes)
  const corpo = [est ? texto.split(est).join(' ') : texto, e.descricao || ''].join('\n')
  const prod = contar(corpo, PRODUTOS)
  if (prod.length && (prod.length === 1 || prod[0].n >= prod[1].n * 2)) {
    return { cat: prod[0].r.cat, sub: prod[0].r.sub, confianca: prod[0].n >= 2 ? 'alta' : 'media', fonte: 'produtos' }
  }
  // 2) o próprio usuário já disse como classifica este estabelecimento
  const apr = est ? await aprendidoPara(userId, est) : null
  if (apr) return { ...apr, confianca: 'alta', fonte: 'aprendido' }
  // 3) estabelecimento / atividade comercial
  const es = contar(est + '\n' + (texto.match(/^.*(?:com[eé]rcio|atividade|cnae|raz[aã]o social).*$/gim) || []).join('\n'), ESTABELECIMENTO)
  if (es.length && (es.length === 1 || es[0].n > es[1].n)) return { cat: es[0].r.cat, sub: es[0].r.sub, confianca: 'alta', fonte: 'estabelecimento' }
  // 4) contexto: dicionário do financeiro sobre a descrição/estabelecimento (ex.: boleto de "energia", "internet")
  const ctx = catFromText([est, e.descricao || ''].join(' '), 'expense')
  if (ctx && ctx.cat !== 'outros') return { cat: ctx.cat, sub: ctx.sub, confianca: 'media', fonte: 'contexto' }
  // complemento (sugestão de outra leitura, quando houver): só vale como sugestão
  if (e.categoriaSugerida && (FIN_CATS.expense as string[]).includes(e.categoriaSugerida) && e.categoriaSugerida !== 'outros') return { cat: e.categoriaSugerida, sub: '', confianca: 'media', fonte: 'complemento' }
  return { cat: 'outros', sub: '', confianca: 'baixa', fonte: 'nenhuma' }
}

/** "A categoria dessa compra é mercado", "Isso foi uma compra de mercado", "Classifique essa despesa como alimentação",
 *  "Essa compra é combustível", "Mude a categoria para saúde" → o texto da categoria pedida (ou null). */
export function pedidoDeCategoria(text: string): string | null {
  const s = nrm(text).trim()
  const ref = '(?:(?:dessa|desta|dessa ultima|da ultima|do ultimo|deste|desse|da|do|essa|esta|esse|este|ultima|ultimo)\\s+)?(?:(?:compra|despesa|gasto|lancamento|transacao|pix|pagamento|comprovante|conta|saida)\\s+)?'
  const prep = '(?:(?:de|no|na|em|com|do|da|um|uma)\\s+)?'
  const pads = [
    new RegExp(`^(?:a\\s+)?categoria\\s+${ref}(?:e|eh|foi|era|seria|deve ser|correta e|certa e)\\s+${prep}(.+)$`),
    new RegExp(`^(?:isso|isto|essa|esta|esse|este)\\s+(?:(?:compra|despesa|gasto|lancamento|transacao|pix|pagamento)\\s+)?(?:foi|e|eh|era)\\s+(?:(?:uma|um)\\s+)?(?:(?:compra|despesa|gasto)\\s+)?${prep}(.+)$`),
    new RegExp(`^(?:classifi(?:que|ca|car)|categoriz(?:e|a|ar)|coloque|coloca|poe|ponha|bota|marque|marca|lance|lanca)\\s+${ref}(?:como|em|na categoria|na|no|para|pra)\\s+(.+)$`),
    new RegExp(`^(?:mude|muda|mudar|altere|altera|alterar|troque|troca|trocar|corrija|corrige)\\s+(?:a\\s+)?categoria\\s+${ref}(?:para|pra|por|como)\\s+(.+)$`),
    /^categoria\s+(?:para\s+|pra\s+)?([a-z ]{3,30})$/,
  ]
  for (const re of pads) {
    const m = re.exec(s)
    if (m && m[1]) {
      const alvo = m[1].replace(/\b(por favor|pfv|pf|obrigad[oa])\b/g, '').replace(/^(?:a|o|as|os)\s+/, '').trim()
      // só nomes curtos de categoria ("mercado", "alimentação", "farmácia"): frases longas não são pedido de categoria
      if (alvo && alvo.split(' ').length <= 3 && !/\d/.test(alvo)) return alvo
    }
  }
  return null
}
