// APRENDIZADO CONTÍNUO (Fase 6) — sobre o que já existe: notas por resposta (cognition_evals), 👍/👎 (response_feedback),
// experiências (Fase 5), Laboratório de IA (regras) e monitor de regressão. Nada aqui altera código, modelo ou provedor.
//
//  1 coleta ........ avaliações, correções, reclamações, falhas de ferramenta e resultados (só notas e rótulos, sem texto)
//  2 análise ....... padrões de erro/sucesso por área, ponderados POR USUÁRIO (um usuário não domina um padrão)
//  3 resultados .... comparação de estratégias (com/sem agentes, plano, revisão, memória) e de versões da política
//  4 autodiagnóstico limitações operacionais, falhas de execução e problemas de qualidade
//  5 propostas ..... mudanças da POLÍTICA APRENDIDA (lista fechada) ou regras enviadas ao Laboratório
//  6 experimento ... ambiente isolado: mesma bateria com a política atual e a candidata
//  7 comparação .... precisão, naturalidade, velocidade, consistência e resolução, antes × depois
//  8 aprovação ..... o administrador aprova (gradual ou total), rejeita, promove ou reverte
//  9 global ........ só sinais anônimos de quem consentiu; mínimo de usuários distintos; contas suspeitas fora
// 10 monitoramento . evolução semanal, histórico de versões, regressões (a liberação gradual para sozinha) e relatório
import { q, one, J, B, nowIso } from '../db/index.js'
import { fail } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import * as POL from './politica.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 1000) / 10 : null)
const DIA = 864e5

/* ======================= 1) COLETA ======================= */
/** Reclamação em texto sobre a resposta anterior ("você errou", "não era isso"). */
export const RECLAMACAO = /\b(voce errou|vc errou|ta errado|esta errado|errou de novo|nao era isso|nao foi isso que (eu )?pedi|nao e isso que eu pedi|nao funcionou|resposta ruim|pessima resposta|resposta pessima|voce nao entendeu|vc nao entendeu|nao me ajudou|nao ajudou em nada|que resposta (ruim|horrivel)|isso esta errado|de novo isso)\b/
export const ehReclamacao = (texto: string) => RECLAMACAO.test(nrm(texto).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' '))
/** Marca a avaliação da resposta anterior: corrigida + sinal "reclamacao" (só rótulo; o texto não é guardado). */
export async function marcarReclamacao(convId: string, userId: number) {
  const r = await one('SELECT id, flags FROM cognition_evals WHERE conversation_id = $1 AND user_id = $2 ORDER BY id DESC LIMIT 1', [convId, userId]).catch(() => null)
  if (!r) return false
  const flags = J<string[]>(r.flags, []); if (!flags.includes('reclamacao')) flags.push('reclamacao')
  await q('UPDATE cognition_evals SET corrected = $1, flags = $2 WHERE id = $3', [true, JSON.stringify(flags), Number(r.id)])
  return true
}
/** Consentimento para o aprendizado GLOBAL anônimo (padrão: sim; o usuário pode desligar a qualquer momento). */
export async function consentimento(userId: number) { const r = await one('SELECT contribute FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null); return !(r && r.contribute != null && !B(r.contribute)) }
export async function salvarConsentimento(userId: number, sim: boolean) {
  const ex = await one('SELECT user_id FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null)
  if (ex) await q('UPDATE user_intel_prefs SET contribute = $1, updated_at = $2 WHERE user_id = $3', [sim, nowIso(), userId])
  else await q('INSERT INTO user_intel_prefs (user_id, proactive, style, contribute, updated_at) VALUES ($1,$2,$3,$4,$5)', [userId, true, '{}', sim, nowIso()])
}

/* ---------- turnos (notas por resposta) com proteção contra contaminação ---------- */
const GRAVES = ['acao_nao_confirmada', 'falha_omitida', 'comando_sem_acao', 'registro_nao_confirmado', 'reclamacao']
export interface Turno { id: number; usuario: number; area: string; intent: string; nota: number; flags: string[]; problemas: string[]; resultado: 'sucesso' | 'falha' | 'neutro'; estrategia: Record<string, boolean>; agentes: string[]; ferramentas: { n: string; ok: boolean }[]; versao: number | null; grupo: string | null; ms: number | null; scores: Record<string, number>; em: number }
/** Usuários cujos sinais NÃO entram no aprendizado global: sem consentimento ou com padrão suspeito (avalanche de negativos). */
export async function excluidos(desde: string) {
  const sem = new Set<number>(((await q('SELECT user_id FROM user_intel_prefs WHERE contribute = $1', [false]).catch(() => [])) as any[]).map((r) => Number(r.user_id)))
  const fb = (await q('SELECT user_id, rating, created_at FROM response_feedback WHERE created_at >= $1', [desde]).catch(() => [])) as any[]
  const users = new Map<number, number>(((await q('SELECT id, created_at FROM users').catch(() => [])) as any[]).map((r) => [Number(r.id), Date.parse(String(r.created_at))]))
  const por = new Map<number, { neg: number; total: number; neg24: Map<string, number> }>()
  for (const r of fb) { const u = Number(r.user_id), x = por.get(u) || { neg: 0, total: 0, neg24: new Map() }; x.total++; if (Number(r.rating) === -1) { x.neg++; const d = String(r.created_at).slice(0, 10); x.neg24.set(d, (x.neg24.get(d) || 0) + 1) } por.set(u, x) }
  const suspeitos = new Map<number, string>()
  for (const [u, x] of por) {
    if ([...x.neg24.values()].some((n) => n >= 15)) suspeitos.set(u, 'avalanche de avaliações negativas no mesmo dia')
    else if (x.total >= 10 && x.neg === x.total) suspeitos.set(u, 'todas as avaliações negativas')
    else if (x.neg >= 10 && x.neg / x.total >= 0.8 && Date.now() - (users.get(u) || 0) < DIA) suspeitos.set(u, 'conta nova com muitas avaliações negativas')
  }
  return { semConsentimento: sem, suspeitos }
}
export async function turnos(dias = 30, o: { global?: boolean } = { global: true }): Promise<{ turnos: Turno[]; excluidos: { semConsentimento: number; suspeitos: number } }> {
  const desde = new Date(Date.now() - dias * DIA).toISOString()
  const ex = o.global ? await excluidos(desde) : { semConsentimento: new Set<number>(), suspeitos: new Map<number, string>() }
  const rows = (await q('SELECT id, user_id, message_id, path, intent, overall, scores, flags, corrected, specialists, feedback, level2, created_at FROM cognition_evals WHERE created_at >= $1 ORDER BY id DESC LIMIT 20000', [desde]).catch(() => [])) as any[]
  const motivos = new Map<string, string[]>()
  for (const r of (await q('SELECT user_id, message_id, reasons FROM response_feedback WHERE created_at >= $1', [desde]).catch(() => [])) as any[]) motivos.set(`${r.user_id}|${r.message_id}`, J<string[]>(r.reasons, []))
  const out: Turno[] = []
  for (const r of rows) {
    const u = Number(r.user_id); if (ex.semConsentimento.has(u) || ex.suspeitos.has(u)) continue
    const flags = J<string[]>(r.flags, []), l2 = J<any>(r.level2, {}) || {}, fbk = r.feedback == null ? null : Number(r.feedback), corr = B(r.corrected)
    const ferr: { n: string; ok: boolean }[] = Array.isArray(l2.ferramentas) ? l2.ferramentas.filter((f: any) => f && typeof f.n === 'string').map((f: any) => ({ n: f.n, ok: f.ok !== false })) : []
    const problemas = [...flags.map((f) => 'flag:' + f), ...(motivos.get(`${u}|${r.message_id}`) || []).map((m) => 'fb:' + m), ...(corr ? ['correcao'] : []), ...ferr.filter((f) => !f.ok).map((f) => 'ferramenta:' + f.n), ...(l2.plano?.falhas ? ['plano_falhou'] : [])]
    const grave = flags.some((f) => GRAVES.includes(f)) || ferr.some((f) => !f.ok)
    const resultado: Turno['resultado'] = fbk === -1 || corr || grave ? 'falha' : fbk === 1 || Number(r.overall) >= 75 ? 'sucesso' : 'neutro'
    const agentes = (l2.multiagente?.agentes || []).map((a: any) => a?.id).filter(Boolean)
    out.push({ id: Number(r.id), usuario: u, area: J<string[]>(r.specialists, [])[0] || 'geral', intent: String(r.intent || ''), nota: Number(r.overall), flags, problemas, resultado,
      estrategia: { multiagente: agentes.length > 0, plano: !!l2.plano, revisao: !!l2.autoverificacao?.revisada, memoria: Number(l2.memorias || 0) > 0 }, agentes, ferramentas: ferr,
      versao: l2.politica?.versao ?? null, grupo: l2.politica?.grupo ?? null, ms: typeof l2.ms === 'number' ? l2.ms : null, scores: J<any>(r.scores, {}), em: Date.parse(String(r.created_at)) })
  }
  return { turnos: out, excluidos: { semConsentimento: ex.semConsentimento.size, suspeitos: ex.suspeitos.size } }
}
/** Taxa ponderada POR USUÁRIO: cada usuário pesa 1, não importa quantas mensagens mandou (anti-contaminação). */
export function taxaPorUsuario(ts: Turno[], cond: (t: Turno) => boolean) {
  const por = new Map<number, { s: number; n: number }>()
  for (const t of ts) { const x = por.get(t.usuario) || { s: 0, n: 0 }; x.n++; if (cond(t)) x.s++; por.set(t.usuario, x) }
  if (!por.size) return null
  return Math.round(([...por.values()].reduce((a, x) => a + x.s / x.n, 0) / por.size) * 1000) / 10
}
const usuarios = (ts: Turno[]) => new Set(ts.map((t) => t.usuario)).size

/* ======================= 2) ANÁLISE DE EXPERIÊNCIAS ======================= */
const PROB_NOME: Record<string, string> = {
  'fb:incorreta': 'informação incorreta', 'fb:incompleta': 'resposta incompleta', 'fb:nao_entendeu': 'não entendeu o pedido', 'fb:muito_longa': 'resposta longa demais', 'fb:muito_curta': 'resposta curta demais', 'fb:tom': 'tom inadequado', 'fb:nao_executou': 'não executou a ação',
  correcao: 'usuário precisou corrigir', 'flag:reclamacao': 'reclamação do usuário', 'flag:acao_nao_confirmada': 'ação afirmada sem confirmação', 'flag:falha_omitida': 'falha omitida', 'flag:comando_sem_acao': 'pedido de ação sem ação',
  'flag:perguntou_o_que_ja_sabia': 'perguntou o que já sabia', 'flag:ignorou_contexto': 'ignorou o contexto', 'flag:frases_longas': 'frases longas', 'flag:bloco_unico': 'texto em bloco único', 'flag:tom_robotico': 'tom robótico', plano_falhou: 'plano com etapa que falhou',
}
export const nomeProblema = (p: string) => PROB_NOME[p] || (p.startsWith('ferramenta:') ? 'falha na ferramenta ' + p.slice(11) : p.replace(/^(flag|fb):/, ''))
export function padroes(ts: Turno[], minUsuarios = 3) {
  const porArea = new Map<string, Turno[]>(); for (const t of ts) porArea.set(t.area, [...(porArea.get(t.area) || []), t])
  const erros: any[] = [], sucessos: any[] = []
  for (const [area, xs] of porArea) {
    const cont = new Map<string, Turno[]>(); for (const t of xs) for (const p of new Set(t.problemas)) cont.set(p, [...(cont.get(p) || []), t])
    for (const [p, ys] of cont) {
      const us = usuarios(ys), semanas = new Set(ys.map((t) => Math.floor(t.em / (7 * DIA)))).size
      erros.push({ area, problema: p, nome: nomeProblema(p), turnos: ys.length, usuarios: us, taxa: taxaPorUsuario(xs, (t) => t.problemas.includes(p)), recorrente: semanas >= 2, global: us >= minUsuarios })
    }
    sucessos.push({ area, turnos: xs.length, usuarios: usuarios(xs), sucesso: taxaPorUsuario(xs, (t) => t.resultado === 'sucesso'), falha: taxaPorUsuario(xs, (t) => t.resultado === 'falha'), nota: Math.round(xs.reduce((a, t) => a + t.nota, 0) / xs.length) })
  }
  erros.sort((a, b) => Number(b.global) - Number(a.global) || b.usuarios - a.usuarios || (b.taxa || 0) - (a.taxa || 0))
  sucessos.sort((a, b) => b.turnos - a.turnos)
  return { erros, sucessos }
}

/* ======================= 3) APRENDIZADO POR RESULTADOS ======================= */
const ESTRATEGIA_NOME: Record<string, [string, string]> = { multiagente: ['com agentes especializados', 'resposta direta'], plano: ['com plano em etapas', 'sem plano'], revisao: ['com revisão automática', 'sem revisão'], memoria: ['com memórias', 'sem memórias'] }
export function estrategias(ts: Turno[], minAmostra = 20, minUsuarios = 3) {
  const out: any[] = []
  for (const area of new Set(ts.map((t) => t.area))) {
    const xs = ts.filter((t) => t.area === area)
    for (const k of Object.keys(ESTRATEGIA_NOME)) {
      const com = xs.filter((t) => t.estrategia[k]), sem = xs.filter((t) => !t.estrategia[k])
      if (!com.length || !sem.length) continue
      const a = taxaPorUsuario(com, (t) => t.resultado === 'sucesso')!, b = taxaPorUsuario(sem, (t) => t.resultado === 'sucesso')!
      const suficiente = com.length >= minAmostra && sem.length >= minAmostra && usuarios(com) >= minUsuarios && usuarios(sem) >= minUsuarios
      const dif = Math.round((a - b) * 10) / 10
      out.push({ area, estrategia: k, com: { nome: ESTRATEGIA_NOME[k][0], turnos: com.length, usuarios: usuarios(com), sucesso: a }, sem: { nome: ESTRATEGIA_NOME[k][1], turnos: sem.length, usuarios: usuarios(sem), sucesso: b }, diferenca: dif, suficiente,
        conclusao: !suficiente ? 'amostra insuficiente' : Math.abs(dif) < 10 ? 'sem diferença relevante' : dif > 0 ? `melhor ${ESTRATEGIA_NOME[k][0]}` : `melhor ${ESTRATEGIA_NOME[k][1]}`,
        agentesUsados: k === 'multiagente' ? [...new Set(com.flatMap((t) => t.agentes))] : undefined })
    }
  }
  return out.sort((a, b) => Number(b.suficiente) - Number(a.suficiente) || Math.abs(b.diferenca) - Math.abs(a.diferenca))
}
/** Resultado real de cada versão da política (pelo registro de cada resposta). */
export function porVersao(ts: Turno[]) {
  const m = new Map<string, Turno[]>(); for (const t of ts) { const k = t.versao == null ? 'padrão' : 'v' + t.versao; m.set(k, [...(m.get(k) || []), t]) }
  return [...m].map(([versao, xs]) => ({ versao, turnos: xs.length, usuarios: usuarios(xs), sucesso: taxaPorUsuario(xs, (t) => t.resultado === 'sucesso'), correcoes: taxaPorUsuario(xs, (t) => t.problemas.includes('correcao')), nota: Math.round(xs.reduce((a, t) => a + t.nota, 0) / xs.length), msMedio: media(xs.map((t) => t.ms).filter((x): x is number => x != null)) }))
}
const media = (xs: number[]) => (xs.length ? Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) : null)
const p95 = (xs: number[]) => (xs.length ? [...xs].sort((a, b) => a - b)[Math.min(xs.length - 1, Math.floor(xs.length * 0.95))] : null)

/* ======================= 4) AUTODIAGNÓSTICO ======================= */
export async function autodiagnostico(ts: Turno[], minAmostra = 20) {
  const D: { area: string; tipo: 'execução' | 'interpretação' | 'qualidade' | 'velocidade' | 'operacional' | 'satisfação'; severidade: 'alta' | 'média' | 'baixa'; descricao: string; evidencia: string }[] = []
  // falhas de execução por ferramenta
  const ferr = new Map<string, { n: number; f: number; us: Set<number> }>()
  for (const t of ts) for (const f of t.ferramentas) { const x = ferr.get(f.n) || { n: 0, f: 0, us: new Set() }; x.n++; if (!f.ok) { x.f++; x.us.add(t.usuario) } ferr.set(f.n, x) }
  for (const [n, x] of ferr) if (x.n >= 5 && x.f / x.n >= 0.2) D.push({ area: n, tipo: 'execução', severidade: x.f / x.n >= 0.4 ? 'alta' : 'média', descricao: `A ferramenta ${n} falhou em ${pct(x.f, x.n)}% das vezes`, evidencia: `${x.f} de ${x.n} usos · ${x.us.size} usuário(s)` })
  for (const area of new Set(ts.map((t) => t.area))) {
    const xs = ts.filter((t) => t.area === area); if (xs.length < 5) continue
    const tx = (p: string) => taxaPorUsuario(xs, (t) => t.problemas.includes(p)) || 0
    const interp = Math.max(tx('flag:perguntou_o_que_ja_sabia'), tx('flag:ignorou_contexto'), tx('fb:nao_entendeu'))
    if (interp >= 5) D.push({ area, tipo: 'interpretação', severidade: interp >= 15 ? 'alta' : 'média', descricao: 'Dificuldade de interpretação (contexto ignorado, pergunta repetida ou pedido não entendido)', evidencia: `${interp}% das respostas (por usuário) · ${xs.length} respostas` })
    const exec = Math.max(tx('flag:comando_sem_acao'), tx('flag:acao_nao_confirmada'), tx('flag:falha_omitida'))
    if (exec >= 5) D.push({ area, tipo: 'execução', severidade: exec >= 15 ? 'alta' : 'média', descricao: 'Pedidos de ação sem execução confirmada', evidencia: `${exec}% das respostas · ${xs.length} respostas` })
    for (const [k, nome] of [['naturalidade', 'naturalidade'], ['clareza', 'clareza']] as const) { const m = media(xs.map((t) => Number(t.scores?.[k])).filter((v) => isFinite(v))); if (m != null && m < 70) D.push({ area, tipo: 'qualidade', severidade: m < 55 ? 'alta' : 'média', descricao: `Nota de ${nome} baixa`, evidencia: `média ${m}/100 em ${xs.length} respostas` }) }
    const suc = taxaPorUsuario(xs, (t) => t.resultado === 'sucesso')
    if (xs.length >= minAmostra && suc != null && suc < 60) D.push({ area, tipo: 'satisfação', severidade: suc < 40 ? 'alta' : 'média', descricao: 'Taxa de sucesso baixa nesta área', evidencia: `${suc}% de sucesso (por usuário) · ${xs.length} respostas` })
  }
  const ms = ts.map((t) => t.ms).filter((x): x is number => x != null), lento = p95(ms)
  if (lento != null && ms.length >= 10 && lento > 15000) D.push({ area: 'geral', tipo: 'velocidade', severidade: lento > 25000 ? 'alta' : 'média', descricao: 'Respostas com IA lentas', evidencia: `p95 de ${lento} ms em ${ms.length} respostas` })
  try { const AG = await import('./agentes.js'); for (const a of AG.AGENTES) if (AG.pausado(a.id)) D.push({ area: a.id, tipo: 'operacional', severidade: 'média', descricao: `Agente ${a.nome} pausado pelo disjuntor (falhas seguidas)`, evidencia: 'disjuntor aberto agora' }) } catch { /* sem agentes */ }
  const diag = await one("SELECT result FROM intel_runs WHERE kind = 'diagnostico' ORDER BY id DESC LIMIT 1").catch(() => null)
  if (diag) { const r = J<any>(diag.result, {}); if (r.taxa != null && r.taxa < 100) D.push({ area: 'núcleo', tipo: 'qualidade', severidade: r.taxa < 95 ? 'alta' : 'baixa', descricao: 'O diagnóstico automático do núcleo encontrou falhas', evidencia: `${r.aprovadas}/${r.verificacoes} verificações (${r.taxa}%)` }) }
  const ordem = { alta: 0, média: 1, baixa: 2 }
  return D.sort((a, b) => ordem[a.severidade] - ordem[b.severidade])
}

/* ======================= 5) GERAÇÃO AUTOMÁTICA DE PROPOSTAS ======================= */
const FERRAMENTA_DA_AREA: Record<string, string> = { agenda: 'create_appointment', financas: 'register_transaction', tarefas: 'create_task', compras: 'add_shopping_items', crm: 'crm_criar_lead', agenda_empresa: 'agenda_empresa_horarios', memoria: 'save_memory' }
const AREA_NOME: Record<string, string> = { agenda: 'Agenda', financas: 'Finanças', tarefas: 'Tarefas', compras: 'Compras', memoria: 'Memória', crm: 'Clientes (CRM)', agenda_empresa: 'Agenda da empresa', negocio: 'Negócio', acolhimento: 'Acolhimento', geral: 'Conhecimento geral' }
export const nomeArea = (a: string) => AREA_NOME[a] || a
interface Candidata { kind: string; title: string; rationale: string; evidence: any; change: any }
function candidatas(pd: ReturnType<typeof padroes>, est: any[], pol: POL.Politica, cfg: POL.AprCfg): Candidata[] {
  const C: Candidata[] = [], ok = (e: any, minTaxa: number) => e.global && (e.taxa || 0) >= minTaxa
  const ev = (e: any) => ({ area: e.area, problema: e.nome, respostas: e.turnos, usuarios: e.usuarios, taxa: e.taxa, recorrente: e.recorrente })
  for (const e of pd.erros) {
    const A = nomeArea(e.area), ferr = FERRAMENTA_DA_AREA[e.area]
    if (['fb:muito_longa', 'flag:frases_longas', 'flag:bloco_unico'].includes(e.problema) && ok(e, 10) && pol.qualidade.estilo[e.area] !== 'curta')
      C.push({ kind: 'qualidade', title: `Respostas mais curtas em ${A}`, rationale: `${e.usuarios} usuários diferentes sinalizaram "${e.nome}" em ${A} (${e.taxa}% das respostas, ponderado por usuário).`, evidence: ev(e), change: { op: 'set', caminho: `qualidade.estilo.${e.area}`, valor: 'curta' } })
    if (e.problema === 'fb:muito_curta' && ok(e, 10) && pol.qualidade.estilo[e.area] !== 'detalhada')
      C.push({ kind: 'qualidade', title: `Respostas mais completas em ${A}`, rationale: `${e.usuarios} usuários acharam as respostas de ${A} curtas demais (${e.taxa}%).`, evidence: ev(e), change: { op: 'set', caminho: `qualidade.estilo.${e.area}`, valor: 'detalhada' } })
    if (['fb:incompleta', 'fb:incorreta'].includes(e.problema) && ok(e, 8) && !pol.raciocinio.revisarSempre.includes(e.area))
      C.push({ kind: 'raciocinio', title: `Revisão automática sempre em ${A}`, rationale: `"${e.nome}" em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários): conferir cada resposta antes de entregar.`, evidence: ev(e), change: { op: 'add', caminho: 'raciocinio.revisarSempre', valor: e.area } })
    if (['fb:nao_entendeu', 'flag:reclamacao', 'correcao', 'flag:ignorou_contexto'].includes(e.problema) && ok(e, 10) && !pol.qualidade.perguntarAntes.includes(e.area))
      C.push({ kind: 'qualidade', title: `Confirmar dados ambíguos antes de agir em ${A}`, rationale: `"${e.nome}" em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários).`, evidence: ev(e), change: { op: 'add', caminho: 'qualidade.perguntarAntes', valor: e.area } })
    if (e.problema === 'flag:perguntou_o_que_ja_sabia' && ok(e, 5) && pol.memoria.maxFatos < 16)
      C.push({ kind: 'memoria', title: 'Recuperar mais memórias relevantes por resposta', rationale: `O assistente perguntou o que o usuário já tinha dito em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários).`, evidence: ev(e), change: { op: 'set', caminho: 'memoria.maxFatos', valor: Math.min(16, pol.memoria.maxFatos + 4) } })
    if (e.problema === 'plano_falhou' && ok(e, 5) && !pol.raciocinio.planejarSempre.includes(e.area))
      C.push({ kind: 'raciocinio', title: `Planejar em etapas os pedidos de ${A}`, rationale: `Planos com etapa que falhou em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários).`, evidence: ev(e), change: { op: 'add', caminho: 'raciocinio.planejarSempre', valor: e.area } })
    if (e.problema.startsWith('ferramenta:') && e.global) { const t = e.problema.slice(11); if (/^[a-z_]{3,40}$/.test(t) && !pol.ferramentas.dicas[t]) C.push({ kind: 'ferramentas', title: `Conferir os dados antes de usar ${t}`, rationale: `A ferramenta ${t} falhou para ${e.usuarios} usuários (${e.turnos} vez(es)).`, evidence: ev(e), change: { op: 'set', caminho: `ferramentas.dicas.${t}`, valor: 'confirmar_dados' } }) }
    if (['flag:comando_sem_acao', 'fb:nao_executou'].includes(e.problema) && ok(e, 8) && ferr && !pol.ferramentas.dicas[ferr])
      C.push({ kind: 'ferramentas', title: `Executar a ação em ${A} em vez de explicar`, rationale: `"${e.nome}" em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários).`, evidence: ev(e), change: { op: 'set', caminho: `ferramentas.dicas.${ferr}`, valor: 'usar_ferramenta' } })
    if (['flag:acao_nao_confirmada', 'flag:falha_omitida'].includes(e.problema) && ok(e, 5) && ferr && !pol.ferramentas.dicas[ferr])
      C.push({ kind: 'ferramentas', title: `Informar falhas com clareza em ${A}`, rationale: `"${e.nome}" em ${e.taxa}% das respostas de ${A} (${e.usuarios} usuários).`, evidence: ev(e), change: { op: 'set', caminho: `ferramentas.dicas.${ferr}`, valor: 'informar_falha' } })
  }
  for (const s of est) if (s.estrategia === 'multiagente' && s.suficiente && s.diferenca <= -10 && s.agentesUsados?.length && !(pol.agentes.evitar[s.area] || []).length)
    C.push({ kind: 'agentes', title: `Responder direto (sem agentes) em ${nomeArea(s.area)}`, rationale: `Em ${nomeArea(s.area)}, a resposta direta teve ${s.sem.sucesso}% de sucesso contra ${s.com.sucesso}% com agentes (${s.com.turnos}+${s.sem.turnos} respostas).`, evidence: { area: s.area, com: s.com, sem: s.sem }, change: { op: 'set', caminho: `agentes.evitar.${s.area}`, valor: s.agentesUsados } })
  void cfg
  return C
}
const impressao = (c: { kind: string; change: any }) => `${c.kind}|${JSON.stringify(c.change)}`
/** Analisa, gera propostas novas (sem repetir as abertas nem as rejeitadas há menos de 30 dias) e devolve o resumo. */
export async function gerarPropostas(dias = 30) {
  const cfg = await POL.aprCfg(true), base = await POL.versao(cfg.versaoAtiva), { turnos: ts, excluidos: exc } = await turnos(dias)
  const pd = padroes(ts, cfg.minUsuarios), est = estrategias(ts, cfg.minAmostra, cfg.minUsuarios)
  const novas: number[] = []
  for (const c of candidatas(pd, est, base, cfg)) {
    try { POL.aplicarMudanca(base, c.change) } catch { continue } // só o que é permitido pela lista fechada
    const fp = impressao(c)
    const ja = await one("SELECT id FROM learning_proposals WHERE fingerprint = $1 AND (status IN ('proposta','testada','reprovada','gradual','ativa') OR (status = 'rejeitada' AND updated_at >= $2))", [fp, new Date(Date.now() - 30 * DIA).toISOString()]).catch(() => null)
    if (ja) continue
    const r = await one('INSERT INTO learning_proposals (kind, title, rationale, evidence, change, fingerprint, status, created_by, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id',
      [c.kind, c.title.slice(0, 160), c.rationale.slice(0, 600), JSON.stringify(c.evidence), JSON.stringify(c.change), fp, 'proposta', 'sistema', JSON.stringify([{ em: nowIso(), para: 'proposta', por: 'sistema', nota: 'gerada pela análise de experiências' }]), nowIso(), nowIso()])
    novas.push(Number(r!.id))
  }
  // Fase 7: alertas preditivos marcados como "não faz sentido" por vários usuários → proposta de silenciar aquele tipo
  const al = (await q("SELECT tipo, status, user_id FROM predictive_alerts WHERE created_at >= $1 AND status IN ('aceita','dispensada','falso')", [new Date(Date.now() - dias * DIA).toISOString()]).catch(() => [])) as any[]
  const porTipo = new Map<string, { n: number; falso: number; us: Set<number> }>(); for (const a of al) { const x = porTipo.get(a.tipo) || { n: 0, falso: 0, us: new Set() }; x.n++; if (a.status === 'falso') { x.falso++; x.us.add(Number(a.user_id)) } porTipo.set(a.tipo, x) }
  for (const [tipo, x] of porTipo) {
    if (x.n < 10 || x.falso / x.n < 0.5 || x.us.size < cfg.minUsuarios || base.preditivo.silenciar.includes(tipo) || !POL.TIPOS_PREDITIVOS.includes(tipo)) continue
    const c = { kind: 'proatividade', change: { op: 'add', caminho: 'preditivo.silenciar', valor: tipo } }, fp = impressao(c)
    if (await one("SELECT id FROM learning_proposals WHERE fingerprint = $1 AND (status IN ('proposta','testada','reprovada','gradual','ativa') OR (status = 'rejeitada' AND updated_at >= $2))", [fp, new Date(Date.now() - 30 * DIA).toISOString()]).catch(() => null)) continue
    const nome = (await import('./preditivo.js')).TIPOS[tipo] || tipo
    const r = await one('INSERT INTO learning_proposals (kind, title, rationale, evidence, change, fingerprint, status, created_by, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id',
      ['proatividade', `Silenciar alertas de "${nome}"`, `${x.us.size} usuários marcaram ${x.falso} de ${x.n} alertas de "${nome}" como "não faz sentido" (${Math.round((x.falso / x.n) * 100)}% de falsos alertas).`, JSON.stringify({ area: tipo, alertas: x.n, falsos: x.falso, usuarios: x.us.size }), JSON.stringify(c.change), fp, 'proposta', 'sistema', JSON.stringify([{ em: nowIso(), para: 'proposta', por: 'sistema', nota: 'gerada pelos falsos alertas da inteligência preditiva' }]), nowIso(), nowIso()])
    novas.push(Number(r!.id))
  }
  // regras de comportamento: oportunidades do feedback (com exemplos autorizados) seguem pelo Laboratório de IA já existente
  let regras = 0
  for (const g of (await (await import('./feedback.js')).oportunidades().catch(() => [] as any[])).filter((g: any) => g.usuarios >= cfg.minUsuarios).slice(0, 5)) {
    const c = { kind: 'regra', change: { op: 'laboratorio', chave: g.chave } }, fp = impressao(c)
    if (await one("SELECT id FROM learning_proposals WHERE fingerprint = $1 AND status NOT IN ('rejeitada','revertida')", [fp]).catch(() => null)) continue
    const r = await one('INSERT INTO learning_proposals (kind, title, rationale, evidence, change, fingerprint, status, created_by, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id',
      ['regra', `Nova regra de comportamento: ${g.motivoNome} (${nomeArea(g.especialista)})`.slice(0, 160), `${g.usuarios} usuários avaliaram negativamente (${g.n} respostas) por "${g.motivoNome}". Ao aprovar, vira proposta em rascunho no Laboratório de IA, que tem os próprios testes e aprovação.`, JSON.stringify({ area: g.especialista, usuarios: g.usuarios, respostas: g.n }), JSON.stringify(c.change), fp, 'proposta', 'sistema', JSON.stringify([{ em: nowIso(), para: 'proposta', por: 'sistema' }]), nowIso(), nowIso()])
    novas.push(Number(r!.id)); regras++
  }
  await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['aprendizado_analise', JSON.stringify({ turnos: ts.length, excluidos: exc, padroes: pd.erros.filter((e) => e.global).length, novas: novas.length, regras }), true, nowIso()]).catch(() => {})
  return { turnos: ts.length, excluidos: exc, padroesGlobais: pd.erros.filter((e) => e.global).length, novas, regras }
}

/* ======================= 6/7) EXPERIMENTAÇÃO ISOLADA E AVALIAÇÃO COMPARATIVA ======================= */
/** Cenários sintéticos por área (nenhum dado de usuário): o mesmo conjunto roda com a política atual e com a candidata. */
export const CENARIOS: { area: string; texto: string; complexo?: boolean }[] = [
  { area: 'agenda', texto: 'marca uma consulta amanhã às 9h' }, { area: 'agenda', texto: 'o que tenho na agenda essa semana?' },
  { area: 'financas', texto: 'gastei 50 no mercado' }, { area: 'financas', texto: 'quanto gastei com alimentação este mês?' },
  { area: 'tarefas', texto: 'me lembra de pagar a conta de luz sexta' }, { area: 'compras', texto: 'coloca arroz e feijão na lista de compras' },
  { area: 'memoria', texto: 'lembra que eu prefiro reuniões de manhã' }, { area: 'acolhimento', texto: 'estou muito cansado e desanimado hoje' },
  { area: 'geral', texto: 'qual a diferença entre CDI e Selic?' }, { area: 'geral', texto: 'me explica como funciona o imposto de renda' },
  { area: 'agenda', texto: 'analise minha agenda do mês, compare com o mês passado e monte um plano para organizar melhor meus compromissos', complexo: true },
  { area: 'financas', texto: 'analise meus gastos dos últimos meses, compare as categorias e monte uma estratégia para economizar', complexo: true },
]
async function medir(pol: POL.Politica) {
  return POL.comPolitica(pol, async () => {
    const COG = await import('./cognition.js'), NUC = await import('./nucleo.js'), AVAL = await import('./avaliacao.js'), AG = await import('./agentes.js'), EXE = await import('./diagnostico/executar.js'), C = await import('./diagnostico/corpus.js'), SEM = await import('./semantica.js')
    const u = { id: 0, name: 'Experimento', email: '', role: 'user', settings: {} } as unknown as SessionUser
    const tools = AVAL.FERRAMENTAS_TESTE as any[], porCenario: any[] = []
    for (const c of CENARIOS) {
      const an = COG.analisar(c.texto), ctxs: string[] = [], tempos: number[] = []
      for (let i = 0; i < 2; i++) { const t0 = performance.now(); const p = await NUC.prepararTurno(u, c.texto, [], an, tools, { convId: '', sandbox: true, memoriaLigada: false }); tempos.push(performance.now() - t0); ctxs.push(p?.contexto || '') }
      const p = await NUC.prepararTurno(u, c.texto, [], an, tools, { convId: '', sandbox: true, memoriaLigada: false })
      const area = p?.sel?.principal || 'geral', cx = AG.avaliarComplexidade(c.texto, an, p?.sel || null, p?.plano || null), mc = await AG.maCfg()
      const agentes = AG.selecionarAgentes(cx, { ...mc, ativo: true }).map((a) => a.id).filter((id) => !POL.agentesEvitados(pol, area).includes(id))
      porCenario.push({ texto: c.texto, area, contexto: ctxs[0], consistente: ctxs[0] === ctxs[1], ms: Math.round(((tempos[0] + tempos[1]) / 2) * 100) / 100, caracteres: ctxs[0].length, revisaoSempre: POL.revisarSempre(pol, area), agentes })
    }
    const dg = EXE.diagnosticar(), bat = await AVAL.rodarBateria(false)
    // recuperação de memória com os parâmetros da política (memórias fictícias do corpus)
    const ind = SEM.indexar(C.MEMORIAS_FICTICIAS.map((texto, i) => ({ id: i + 1, texto }))); let acertos = 0, esperados = 0, intrusos = 0, chars = 0
    for (const r of C.RECUPERACAO) { const top = SEM.buscar(ind, r.consulta, { k: pol.memoria.maxFatos }).map((a) => a.doc.base.texto); let soma = 0; const caben = top.filter((t) => (soma += t.length + 2) <= pol.memoria.limiteChars); chars += caben.join('; ').length; esperados += r.traz.length; acertos += r.traz.filter((t) => caben.includes(t)).length; intrusos += (r.naoTraz || []).filter((t) => caben.includes(t)).length }
    const ms = porCenario.map((x) => x.ms)
    // inteligência preditiva (Fase 7): cenário simulado com verdade conhecida, sob a política em teste
    const PS = await import('./preditivo-servico.js'), PR = await import('./preditivo.js'), cen = PS.cenarioSimulado(new Date().toISOString().slice(0, 10))
    const pred = await PR.analisar(cen.dados, { silenciar: (pol as any).preditivo?.silenciar || [] }), porTipoPred: Record<string, number> = {}; for (const s of pred.sinais) porTipoPred[s.tipo] = (porTipoPred[s.tipo] || 0) + 1
    // naturalidade/clareza: a nota interna avalia as instruções novas como se fossem resposta (não podem soar robóticas ou confusas)
    const nat = media(porCenario.map((x) => COG.avaliar({ texto: x.texto, resposta: x.contexto.split('\n').filter((l: string) => /Aprendizado aprovado|Uso de ferramentas/.test(l)).join(' ') || 'Certo.', analise: COG.analisar(x.texto) }).naturalidade))
    return {
      precisao: dg.taxa, validacao: dg.validacao.taxa, resolucao: pct(bat.aprovados, bat.total), naturalidade: nat, consistencia: pct(porCenario.filter((x) => x.consistente).length, porCenario.length),
      velocidadeMs: Math.round((ms.reduce((a, b) => a + b, 0) / ms.length) * 100) / 100, contextoMedio: Math.round(porCenario.reduce((a, x) => a + x.caracteres, 0) / porCenario.length),
      memoria: { recall: pct(acertos, esperados), intrusos, caracteres: chars }, cenarios: porCenario, preditivo: porTipoPred,
    }
  })
}
export async function experimentar(id: number, por?: SessionUser) {
  const p = await obter(id)
  if (!['proposta', 'testada', 'reprovada'].includes(p.status)) fail(409, 'Só propostas ainda não aprovadas podem ser testadas.', 'invalid_state')
  if (p.kind === 'regra') { // regra de comportamento: os testes acontecem no Laboratório de IA (simulação com as ferramentas desligadas)
    const res = { tipo: 'regra', aprovada: true, motivos: ['Regras de comportamento são testadas no Laboratório de IA depois de enviadas (simulação e aprovação próprias).'], em: nowIso() }
    await mudarEstado(p, 'testada', por, 'teste delegado ao Laboratório', { test_result: JSON.stringify(res) }); return res
  }
  const cfg = await POL.aprCfg(true), base = await POL.versao(cfg.versaoAtiva), cand = POL.aplicarMudanca(base, p.change)
  const t0 = Date.now(), antes = await medir(base), depois = await medir(cand)
  // isolamento: só a área alvo pode mudar; consistência: a mesma entrada dá sempre o mesmo resultado
  const alvo = String(p.evidence?.area || String(p.change.caminho).split('.')[2] || p.change.valor || '')
  const mudaram = depois.cenarios.filter((c: any, i: number) => c.contexto !== antes.cenarios[i].contexto || c.revisaoSempre !== antes.cenarios[i].revisaoSempre || JSON.stringify(c.agentes) !== JSON.stringify(antes.cenarios[i].agentes))
  const vazou = mudaram.filter((c: any) => !(c.area === alvo || p.kind === 'memoria' || p.kind === 'ferramentas') && !(p.kind === 'proatividade' && String(c.area) === 'preditivo:' + alvoPred))
  const alvoPred = p.kind === 'proatividade' ? String(p.change.valor) : ''
  const vazouPred = Object.keys({ ...antes.preditivo, ...depois.preditivo }).filter((t) => t !== alvoPred && (antes.preditivo[t] || 0) !== (depois.preditivo[t] || 0))
  const efeito = p.kind === 'proatividade' ? (depois.preditivo[alvoPred] || 0) < (antes.preditivo[alvoPred] || 0) : p.kind === 'memoria' ? depois.memoria.recall! >= antes.memoria.recall! : mudaram.length > 0 || p.kind === 'ferramentas'
  if (vazouPred.length) mudaram.push(...vazouPred.map((t) => ({ area: 'preditivo:' + t, texto: 'sinais preditivos do tipo ' + t })))
  const motivos: string[] = []
  if (depois.precisao < antes.precisao) motivos.push(`precisão caiu (${antes.precisao}% → ${depois.precisao}%)`)
  if ((depois.resolucao || 0) < (antes.resolucao || 0)) motivos.push(`resolução de tarefas caiu (${antes.resolucao}% → ${depois.resolucao}%)`)
  if ((depois.consistencia || 0) < 100) motivos.push('resultado inconsistente entre execuções iguais')
  if ((depois.naturalidade || 0) < (antes.naturalidade || 0) - 5) motivos.push(`naturalidade caiu (${antes.naturalidade} → ${depois.naturalidade})`)
  if (depois.velocidadeMs > antes.velocidadeMs * 1.5 + 2) motivos.push(`preparo mais lento (${antes.velocidadeMs} → ${depois.velocidadeMs} ms)`)
  if (p.kind === 'memoria' && depois.memoria.intrusos > antes.memoria.intrusos) motivos.push('memórias irrelevantes passaram a entrar')
  if (vazou.length) motivos.push(`afetou ${vazou.length} cenário(s) fora da área alvo`)
  if (!efeito) motivos.push('a mudança não teve efeito observável nos cenários da área')
  const metricas = (m: any) => ({ sinaisPreditivos: Object.values(m.preditivo as Record<string, number>).reduce((a, b) => a + b, 0), precisao: m.precisao, validacao: m.validacao, resolucao: m.resolucao, naturalidade: m.naturalidade, consistencia: m.consistencia, velocidadeMs: m.velocidadeMs, contextoMedio: m.contextoMedio, memoriaRecall: m.memoria.recall, memoriaCaracteres: m.memoria.caracteres })
  const res = { tipo: 'politica', aprovada: !motivos.length, motivos, antes: metricas(antes), depois: metricas(depois), cenariosAlterados: mudaram.map((c: any) => ({ area: c.area, texto: c.texto })), diferencas: POL.diferencas(base, cand), duracaoMs: Date.now() - t0, em: nowIso(),
    observacao: 'Ambiente isolado: cenários sintéticos, corpus de diagnóstico, bateria e memórias fictícias — nenhum usuário é afetado. O efeito real na satisfação é medido na liberação gradual.' }
  await mudarEstado(p, res.aprovada ? 'testada' : 'reprovada', por, res.aprovada ? 'aprovada nos testes isolados' : 'reprovada: ' + motivos.join('; '), { test_result: JSON.stringify(res) })
  return res
}

/* ======================= 8) APROVAÇÃO ADMINISTRATIVA ======================= */
const ser = (r: any) => ({ id: Number(r.id), tipo: r.kind, titulo: r.title, justificativa: r.rationale, evidencia: J<any>(r.evidence, {}), mudanca: J<any>(r.change, {}), estado: r.status, teste: J<any>(r.test_result, null), versao: r.version_id == null ? null : Number(r.version_id), criadaPor: r.created_by, decididaPor: r.decided_by == null ? null : Number(r.decided_by), decididaEm: r.decided_at || null, historico: J<any[]>(r.history, []), criadaEm: String(r.created_at), atualizadaEm: String(r.updated_at) })
async function obter(id: number) { if (!Number.isInteger(id) || id <= 0) fail(400, 'Proposta inválida.', 'invalid'); const r = await one('SELECT * FROM learning_proposals WHERE id = $1', [id]); if (!r) fail(404, 'Proposta não encontrada.', 'not_found'); const s = ser(r); return { ...s, kind: s.tipo, status: s.estado, change: s.mudanca, evidence: s.evidencia } }
async function mudarEstado(p: any, para: string, por: SessionUser | undefined, nota: string, extra: Record<string, any> = {}) {
  const hist = [...(p.historico || []), { em: nowIso(), de: p.status, para, por: por ? por.name || 'administrador' : 'sistema', nota: nota.slice(0, 300) }]
  const cols = { status: para, history: JSON.stringify(hist), updated_at: nowIso(), ...extra }, ks = Object.keys(cols)
  await q(`UPDATE learning_proposals SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')} WHERE id = $${ks.length + 1}`, [...ks.map((k) => (cols as any)[k]), p.id])
}
export async function listarPropostas(estado = '') { return ((await q(`SELECT * FROM learning_proposals ${estado ? 'WHERE status = $1' : ''} ORDER BY id DESC LIMIT 100`, estado ? [estado] : []).catch(() => [])) as any[]).map(ser) }
/** aprovar (gradual|total) · promover · rejeitar · reverter. Toda decisão fica no histórico da proposta e na auditoria. */
export async function decidir(id: number, acao: string, admin: SessionUser, o: { modo?: string; pct?: number; nota?: string } = {}) {
  const p = await obter(id), cfg = await POL.aprCfg(true), nota = String(o.nota || '').slice(0, 300), extra = { decided_by: admin.id, decided_at: nowIso() }
  if (acao === 'rejeitar') { if (!['proposta', 'testada', 'reprovada'].includes(p.status)) fail(409, 'Esta proposta já foi decidida.', 'invalid_state'); await mudarEstado(p, 'rejeitada', admin, nota || 'rejeitada pelo administrador', extra); return { ok: true, estado: 'rejeitada' } }
  if (acao === 'aprovar') {
    if (p.status !== 'testada') fail(409, p.status === 'reprovada' ? 'A proposta foi reprovada nos testes isolados e não pode ser aprovada.' : 'Teste a proposta no ambiente isolado antes de aprovar.', 'invalid_state')
    if (p.kind === 'regra') { const r = await (await import('./feedback.js')).enviarAoLaboratorio(admin, String(p.change.chave), nota); await mudarEstado(p, 'ativa', admin, `enviada ao Laboratório de IA como proposta #${r.propostaId} (lá passa por simulação e aprovação)`, extra); return { ok: true, estado: 'ativa', laboratorio: r.propostaId } }
    const modo = o.modo === 'total' ? 'total' : 'gradual', porc = Math.round(Number(o.pct ?? 20))
    if (modo === 'gradual' && (!Number.isInteger(porc) || porc < 5 || porc > 90)) fail(400, 'Liberação gradual: de 5% a 90% dos usuários.', 'invalid', 'pct')
    if (cfg.gradual) fail(409, 'Já existe uma melhoria em liberação gradual. Promova ou reverta antes de iniciar outra.', 'busy')
    const base = await POL.versao(cfg.versaoAtiva), nova = POL.aplicarMudanca(base, p.change)
    const v = await POL.criarVersao(nova, { parent: cfg.versaoAtiva, proposta: p.id, nota: p.titulo, por: admin.id })
    if (modo === 'total') await POL.salvarCfg({ versaoAtiva: v }); else await POL.salvarCfg({ gradual: { versao: v, pct: porc, desde: nowIso() } })
    await mudarEstado(p, modo === 'total' ? 'ativa' : 'gradual', admin, nota || (modo === 'total' ? 'ativada para todos' : `liberação gradual para ${porc}% dos usuários`), { ...extra, version_id: v })
    return { ok: true, estado: modo === 'total' ? 'ativa' : 'gradual', versao: v }
  }
  if (acao === 'promover') {
    if (p.status !== 'gradual' || cfg.gradual?.versao !== p.versao) fail(409, 'Só a melhoria em liberação gradual pode ser promovida.', 'invalid_state')
    await POL.salvarCfg({ versaoAtiva: p.versao, gradual: null }); await mudarEstado(p, 'ativa', admin, nota || 'promovida para todos os usuários', extra); return { ok: true, estado: 'ativa', versao: p.versao }
  }
  if (acao === 'reverter') return reverter(p, admin, nota || 'revertida pelo administrador')
  fail(400, 'Ação inválida.', 'invalid')
}
async function reverter(p: any, por: SessionUser | undefined, nota: string) {
  const cfg = await POL.aprCfg(true)
  if (p.status === 'gradual') { if (cfg.gradual?.versao === p.versao) await POL.salvarCfg({ gradual: null }); await mudarEstado(p, 'revertida', por, nota); return { ok: true, estado: 'revertida' } }
  if (p.status !== 'ativa') fail(409, 'Só melhorias ativas ou em liberação gradual podem ser revertidas.', 'invalid_state')
  if (p.kind === 'regra') { await mudarEstado(p, 'revertida', por, nota + ' (a regra no Laboratório deve ser desativada lá)'); return { ok: true, estado: 'revertida' } }
  if (cfg.versaoAtiva === p.versao) { const pai = (await one('SELECT parent_id FROM learning_policy_versions WHERE id = $1', [p.versao]))?.parent_id; await POL.salvarCfg({ versaoAtiva: pai == null ? null : Number(pai) }) }
  else { // houve melhorias depois desta: cria uma versão nova SEM esta mudança, mantendo as demais
    const atual = await POL.versao(cfg.versaoAtiva), mae = await POL.versao(((await one('SELECT parent_id FROM learning_policy_versions WHERE id = $1', [p.versao]))?.parent_id as any) ?? null)
    const ch = p.change, inv: POL.Mudanca = ch.op === 'add' ? { op: 'remove', caminho: ch.caminho, valor: ch.valor } : { op: 'set', caminho: ch.caminho, valor: ch.caminho.split('.').reduce((o: any, k: string) => o?.[k], mae) }
    const nova = inv.op === 'set' && inv.valor === undefined ? POL.aplicarMudanca(atual, { op: 'remove', caminho: ch.caminho }) : POL.aplicarMudanca(atual, inv)
    await POL.salvarCfg({ versaoAtiva: await POL.criarVersao(nova, { parent: cfg.versaoAtiva, nota: `reversão da proposta #${p.id}`, por: por?.id ?? null }) })
  }
  await mudarEstado(p, 'revertida', por, nota); return { ok: true, estado: 'revertida' }
}
/** Reativa qualquer versão anterior da política (reversão completa). */
export async function restaurarVersao(versao: number | null, admin: SessionUser) {
  if (versao != null && !(await one('SELECT id FROM learning_policy_versions WHERE id = $1', [versao]))) fail(404, 'Versão não encontrada.', 'not_found')
  const cfg = await POL.aprCfg(true); if (cfg.gradual) fail(409, 'Encerre a liberação gradual antes de restaurar uma versão.', 'busy')
  await POL.salvarCfg({ versaoAtiva: versao }); void admin; return { ok: true, versaoAtiva: versao }
}

/* ======================= 10) MONITORAMENTO CONTÍNUO ======================= */
/** Liberação gradual: compara o grupo da candidata com o estável; com regressão clara, encerra sozinha (volta à estável). */
export async function vigiar() {
  const cfg = await POL.aprCfg(true), alertas: string[] = []
  if (cfg.gradual) {
    const { turnos: ts } = await turnos(30), desde = Date.parse(cfg.gradual.desde)
    const cand = ts.filter((t) => t.em >= desde && t.grupo === 'gradual'), est = ts.filter((t) => t.em >= desde && t.grupo !== 'gradual')
    const a = taxaPorUsuario(cand, (t) => t.resultado === 'sucesso'), b = taxaPorUsuario(est, (t) => t.resultado === 'sucesso')
    if (a != null && b != null && cand.length >= cfg.minAmostra && est.length >= cfg.minAmostra && usuarios(cand) >= cfg.minUsuarios && b - a >= 10) {
      const msg = `Regressão na liberação gradual da versão v${cfg.gradual.versao}: sucesso ${a}% contra ${b}% da versão estável.`
      alertas.push(msg)
      if (cfg.pararGradualEmRegressao) {
        const p = await one('SELECT id FROM learning_proposals WHERE version_id = $1', [cfg.gradual.versao]).catch(() => null)
        if (p) await reverter(await obter(Number(p.id)), undefined, 'encerrada automaticamente: ' + msg); else await POL.salvarCfg({ gradual: null })
        alertas.push('A liberação gradual foi encerrada automaticamente; todos voltaram para a versão estável.')
      }
    }
  }
  if (cfg.versaoAtiva) { // versão ativa: compara 7 dias depois × 7 dias antes da ativação (só alerta; a reversão é decisão do administrador)
    const pr = await one("SELECT decided_at FROM learning_proposals WHERE version_id = $1 AND status = 'ativa'", [cfg.versaoAtiva]).catch(() => null)
    if (pr?.decided_at) {
      const t = Date.parse(String(pr.decided_at)), { turnos: ts } = await turnos(30)
      const dep = ts.filter((x) => x.em >= t && x.em < t + 7 * DIA), ant = ts.filter((x) => x.em < t && x.em >= t - 7 * DIA)
      const a = taxaPorUsuario(dep, (x) => x.resultado === 'sucesso'), b = taxaPorUsuario(ant, (x) => x.resultado === 'sucesso')
      if (a != null && b != null && dep.length >= cfg.minAmostra && ant.length >= cfg.minAmostra && b - a >= 10) alertas.push(`Possível regressão depois da versão v${cfg.versaoAtiva}: sucesso ${a}% contra ${b}% antes. Avalie reverter.`)
    }
  }
  await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['aprendizado', JSON.stringify({ alertas }), !alertas.length, nowIso()]).catch(() => {})
  return { alertas }
}
export function evolucao(ts: Turno[], semanas = 8) {
  const agora = Date.now(), out: any[] = []
  for (let i = semanas - 1; i >= 0; i--) {
    const fim = agora - i * 7 * DIA, ini = fim - 7 * DIA, xs = ts.filter((t) => t.em > ini && t.em <= fim)
    const ferr = xs.flatMap((t) => t.ferramentas)
    out.push({ semana: new Date(ini).toISOString().slice(0, 10), respostas: xs.length, usuarios: usuarios(xs), sucesso: taxaPorUsuario(xs, (t) => t.resultado === 'sucesso'), correcoes: taxaPorUsuario(xs, (t) => t.problemas.includes('correcao')), reclamacoes: taxaPorUsuario(xs, (t) => t.flags.includes('reclamacao')),
      nota: media(xs.map((t) => t.nota)), msMedio: media(xs.map((t) => t.ms).filter((x): x is number => x != null)), falhasFerramentas: pct(ferr.filter((f) => !f.ok).length, ferr.length) })
  }
  return out
}
export async function painel() {
  const cfg = await POL.aprCfg(true), { turnos: ts, excluidos: exc } = await turnos(30), pd = padroes(ts, cfg.minUsuarios)
  const ult = await one("SELECT result, created_at FROM intel_runs WHERE kind = 'aprendizado' ORDER BY id DESC LIMIT 1").catch(() => null)
  const consent = await one('SELECT COUNT(*) AS n FROM user_intel_prefs WHERE contribute = $1', [false]).catch(() => null)
  return {
    config: { ativo: cfg.ativo, versaoAtiva: cfg.versaoAtiva, gradual: cfg.gradual, minUsuarios: cfg.minUsuarios, minAmostra: cfg.minAmostra, pararGradualEmRegressao: cfg.pararGradualEmRegressao },
    coleta: { respostas: ts.length, usuarios: usuarios(ts), semConsentimento: Number(consent?.n || 0), excluidosSuspeitos: exc.suspeitos, sucesso: taxaPorUsuario(ts, (t) => t.resultado === 'sucesso') },
    padroes: { erros: pd.erros.slice(0, 15), sucessos: pd.sucessos.slice(0, 12) }, estrategias: estrategias(ts, cfg.minAmostra, cfg.minUsuarios).slice(0, 15), versoesResultado: porVersao(ts),
    autodiagnostico: await autodiagnostico(ts, cfg.minAmostra), propostas: await listarPropostas(), versoes: (await POL.listarVersoes(20)).map((v) => ({ ...v, diferencas: [] as string[] })),
    evolucao: evolucao(ts), alertas: J<any>(ult?.result, {}).alertas || [], ultimaVigilancia: ult?.created_at || null,
  }
}
export async function relatorio() {
  const P = await painel(), L: string[] = []
  const f = (v: any, s = '') => (v == null ? '—' : v + s)
  L.push('# Relatório de aprendizado contínuo', '', `Gerado em ${new Date().toLocaleString('pt-BR')}. Só dados agregados e anônimos (nenhum texto de conversa).`, '')
  L.push('## Coleta', `- Respostas analisadas (30 dias): ${P.coleta.respostas} · usuários: ${P.coleta.usuarios}`, `- Sucesso (ponderado por usuário): ${f(P.coleta.sucesso, '%')}`, `- Usuários que não autorizaram o aprendizado global: ${P.coleta.semConsentimento} · contas excluídas por padrão suspeito: ${P.coleta.excluidosSuspeitos}`, '')
  L.push('## Evolução semanal', '| Semana | Respostas | Sucesso | Correções | Reclamações | Nota | Tempo médio | Falhas de ferramentas |', '|---|---|---|---|---|---|---|---|')
  for (const s of P.evolucao) L.push(`| ${s.semana} | ${s.respostas} | ${f(s.sucesso, '%')} | ${f(s.correcoes, '%')} | ${f(s.reclamacoes, '%')} | ${f(s.nota)} | ${f(s.msMedio, ' ms')} | ${f(s.falhasFerramentas, '%')} |`)
  L.push('', '## Resultado por versão da política', '| Versão | Respostas | Usuários | Sucesso | Correções | Nota | Tempo médio |', '|---|---|---|---|---|---|---|')
  for (const v of P.versoesResultado) L.push(`| ${v.versao} | ${v.turnos} | ${v.usuarios} | ${f(v.sucesso, '%')} | ${f(v.correcoes, '%')} | ${f(v.nota)} | ${f(v.msMedio, ' ms')} |`)
  L.push('', '## Autodiagnóstico'); if (!P.autodiagnostico.length) L.push('- Nenhuma limitação relevante encontrada.'); for (const d of P.autodiagnostico) L.push(`- [${d.severidade}] ${d.tipo} · ${nomeArea(d.area)}: ${d.descricao} (${d.evidencia})`)
  L.push('', '## Padrões de erro (globais = vistos em vários usuários)'); for (const e of P.padroes.erros.slice(0, 10)) L.push(`- ${nomeArea(e.area)}: ${e.nome} — ${e.turnos} respostas, ${e.usuarios} usuário(s), ${f(e.taxa, '%')}${e.recorrente ? ', recorrente' : ''}${e.global ? '' : ' (local: abaixo do mínimo de usuários)'}`)
  L.push('', '## Estratégias comparadas'); for (const s of P.estrategias.slice(0, 10)) L.push(`- ${nomeArea(s.area)}: ${s.com.nome} ${f(s.com.sucesso, '%')} (${s.com.turnos}) × ${s.sem.nome} ${f(s.sem.sucesso, '%')} (${s.sem.turnos}) → ${s.conclusao}`)
  L.push('', '## Melhorias'); for (const p of P.propostas) L.push(`- #${p.id} [${p.estado}] ${p.titulo}${p.versao ? ` · versão v${p.versao}` : ''}${p.teste?.motivos?.length ? ` · testes: ${p.teste.motivos.join('; ')}` : ''}`)
  L.push('', '## Alertas'); if (!P.alertas.length) L.push('- Nenhuma regressão detectada.'); for (const a of P.alertas) L.push('- ' + a)
  return L.join('\n') + '\n'
}
