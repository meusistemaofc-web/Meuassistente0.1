// Conhecimento comercial integrado do chat: atendimento, marketing, vendas e relacionamento com clientes (CRM).
// Três peças, todas honestas e baseadas em dados reais:
//  1) playbook por tema (entra no texto de sistema só quando a conversa é comercial, sem inchar as outras);
//  2) estado REAL dos recursos (Marketing ligado? limites? público que autorizou? CRM existe?) + visão de clientes
//     calculada dos pedidos, agendamentos, consentimentos e cliques de campanhas da própria empresa;
//  3) trava: o assistente nunca diz que enviou campanha/notificação/mensagem — quem envia é a Central de Marketing.
import { q } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import { modules } from '../lib/usermod.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
export const INATIVO_DIAS = 60, NOVO_DIAS = 30

/* ---------- 1) playbook ---------- */
const PLAYBOOK: Record<string, string> = {
  atendimento: `ATENDIMENTO: acompanhe o cliente do primeiro contato ao pós-venda. (1) Cumprimente e entenda a necessidade com 1 ou 2 perguntas; (2) apresente a opção certa, não todas; (3) tire dúvidas de preço, prazo e forma de pagamento só com dados cadastrados; (4) feche com um próximo passo claro (pedido, agendamento, orçamento); (5) confirme tudo por escrito; (6) pós-venda: agradeça, confirme se deu certo e peça avaliação; (7) fidelize com lembrete de retorno e benefícios reais. Registre solicitações em aberto e retome quem ficou sem resposta.`,
  marketing: `MARKETING: toda ação tem objetivo (divulgar serviço, promover oferta, recuperar inativos, lembrar retorno, anunciar novidade) e público definido. Comece pelo público que JÁ autorizou comunicações; segmente por perfil e histórico (compradores, quem veio de convite, recém-chegados, inativos). Mensagem curta, uma ideia, um benefício claro, um chamado para ação e um link. Notificações push: poucas e relevantes, em horário comercial, sem repetir o mesmo cliente em menos de 20 horas (a plataforma já bloqueia), sempre respeitando quem desligou notificações. Teste variações, meça cliques e aprenda com o resultado antes de repetir.`,
  vendas: `VENDAS: descubra a necessidade antes de falar de preço; mostre valor (resultado para o cliente, não lista de características); trate objeções ("está caro", "vou pensar") com perguntas e alternativas, nunca com pressão; ofereça complemento ou opção superior só quando fizer sentido; crie urgência apenas com fatos verdadeiros (vaga limitada, prazo real da oferta); em orçamentos, retome em 24 a 48 horas; para quem pediu e não fechou, pergunte o que faltou. Oportunidades comuns: horários vagos na agenda, clientes que sempre compram e sumiram, pedidos grandes sem complemento, orçamentos parados, avaliações boas que viram prova social.`,
  crm: `RELACIONAMENTO (CRM): organize cada cliente por histórico (atendimentos, compras, agendamentos, interesses, negociações). Perfis: NOVO (primeira compra recente), RECORRENTE (voltou e está ativo), INATIVO (sem comprar há mais de ${INATIVO_DIAS} dias) e POTENCIAL (demonstrou interesse, autorizou contato ou clicou em campanha, mas ainda não comprou). Estratégia por perfil: novo → boas-vindas e pós-venda rápido; recorrente → reconhecimento, programa de retorno e indicação; inativo → mensagem pessoal de reencontro com motivo para voltar; potencial → dúvida respondida, facilitar o primeiro passo.`,
  integracao: `PROCESSO ÚNICO: Atendimento, Marketing, Vendas e CRM são um só ciclo. O histórico dos clientes diz quem merece qual campanha; a campanha gera cliques e interesse; o interesse vira conversa, venda ou agendamento; o resultado volta para o histórico do cliente e orienta a próxima ação. Ao aconselhar, conecte as etapas: quem é o público, qual objetivo, qual mensagem, como medir e o que fazer com quem responder.`,
}
const TEMAS: [string, RegExp][] = [
  ['atendimento', /\b(atend\w*|pos[- ]?venda|fideliz\w*|reclama\w*|solicita\w*|primeiro contato|retorno de cliente|follow[- ]?up|acompanhamento)\b/],
  ['marketing', /\b(marketing|campanha\w*|promo\w*|oferta\w*|divulg\w*|push|notifica\w*|anunci\w*|publicidade|cupom|desconto|novidade\w*|engaj\w*)\b/],
  ['vendas', /\b(vend\w*|conver\w*|negoci\w*|orcamento\w*|faturamento|lucro|fechar|fechamento|lead\w*|objec\w*|prospec\w*|aumentar (as )?vendas)\b/],
  ['crm', /\b(crm|clientes?|inativ\w*|recorrente\w*|potencia\w*|funil|carteira|relacionamento|historico do cliente|recuperar)\b/],
]
export const isCommercial = (text: string) => { const s = nrm(text); return TEMAS.some(([, re]) => re.test(s)) }
export function playbookFor(text: string) {
  const s = nrm(text), hit = TEMAS.filter(([, re]) => re.test(s)).map(([k]) => k)
  const keys = [...new Set([...hit, ...(hit.length > 1 || hit.includes('marketing') || hit.includes('crm') ? ['integracao'] : [])])]
  return keys.map((k) => PLAYBOOK[k]).join('\n')
}
/** Regras fixas de conduta, sempre no texto de sistema (uma linha): nunca afirmar ação externa que não aconteceu. */
export const HONESTIDADE = 'Você NÃO envia mensagens, notificações push, e-mails ou campanhas a clientes e não executa ações externas: nunca diga que enviou, disparou, programou ou notificou alguém. Você sugere o texto, o público e o melhor momento, e orienta o usuário a criar e disparar pela Central de Marketing (⟦btn:/x/marketing|Abrir a Central de Marketing⟧). Só afirme como feito o que uma ferramenta confirmou nesta conversa.'
export const AGENTE_VENDAS = 'Atendimento e vendas: entenda o que o cliente precisa antes de oferecer; sugira a opção mais adequada do catálogo e, quando fizer sentido, um complemento, sem pressionar; responda objeções com fatos cadastrados; conduza para o próximo passo (pedido, agendamento ou WhatsApp); depois do pedido, confirme o que foi registrado. Nunca prometa desconto, brinde, prazo ou ação (como "vou te enviar uma promoção") que não esteja nas informações da empresa, e nunca diga que enviou algo que você não enviou.'

/* ---------- 3) trava contra afirmar envios que não aconteceram ---------- */
const CLAIM = /\b(j[aá] (enviei|disparei|mandei|programei|agendei o envio|notifiquei)|enviei (a |as |uma |um |o |os )?(campanha|notifica\w+|mensagen\w+|promo\w+|e-?mail\w*|push)|disparei (a |as |uma |um )?(campanha|notifica\w+|mensagen\w+|promo\w+)|mandei (a |as |uma |um )?(campanha|notifica\w+|mensagen\w+|promo\w+)|notifiquei (os |seus |todos os )?clientes|programei (a |o )?(campanha|envio|disparo)|(campanha|notifica\w+|mensagen\w+|promo\w+) (foi|foram) (enviad\w+|disparad\w+|programad\w+))\b/i
export const NOTA_SEM_ENVIO = 'Atenção: eu não envio campanhas, notificações ou mensagens para clientes, então nada foi enviado. Posso preparar o texto e o público; para disparar, use a Central de Marketing. ⟦btn:/x/marketing|Abrir a Central de Marketing⟧'
/** Se a resposta da IA afirma um envio externo (e nenhuma ferramenta de envio existe), troca a afirmação por um aviso honesto. */
export function guardExternalClaims(content: string): string {
  if (!CLAIM.test(nrm(content).replace(/⟦[^⟧]*⟧/g, '')) && !CLAIM.test(content)) return content
  const limpo = content.split(/(?<=[.!?])\s+/).filter((f) => !CLAIM.test(f) && !CLAIM.test(nrm(f))).join(' ').trim()
  return `${limpo ? limpo + '\n\n' : ''}${NOTA_SEM_ENVIO}`
}

/* ---------- 2) estado real e visão de clientes ---------- */
export type VisaoClientes = { total: number; novos: number; recorrentes: number; inativos: number; potenciais: number; autorizados: number; inativosLista: string[]; potenciaisLista: string[]; campanhas: { titulo: string; enviados: number; cliques: number }[] }
export async function visaoClientes(ownerId: number): Promise<VisaoClientes | null> {
  const bs = await q('SELECT id FROM businesses WHERE owner_id = $1', [ownerId]); if (!bs.length) return null
  const ids = bs.map((b: any) => Number(b.id))
  const rows = (await q(`SELECT customer_id, status, total, created_at FROM orders WHERE business_id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')}) AND customer_id IS NOT NULL AND status NOT IN ('recusado','cancelado','aguardando_pagamento')`, ids)) as any[]
  const por = new Map<number, { n: number; ultima: number; primeira: number }>()
  for (const r of rows) { const c = Number(r.customer_id), t = Date.parse(r.created_at); const x = por.get(c) || { n: 0, ultima: 0, primeira: Infinity }; x.n++; x.ultima = Math.max(x.ultima, t); x.primeira = Math.min(x.primeira, t); por.set(c, x) }
  const agora = Date.now(), dia = 86400_000
  let novos = 0, recorrentes = 0, inativos = 0; const inativosIds: number[] = []
  for (const [c, x] of por) {
    if (agora - x.ultima > INATIVO_DIAS * dia) { inativos++; inativosIds.push(c) }
    else if (x.n >= 2) recorrentes++
    else if (agora - x.primeira <= NOVO_DIAS * dia) novos++
    else recorrentes++ // comprou uma vez e segue ativo: tratado como cliente ativo
  }
  const aut = (await q("SELECT user_id FROM marketing_consents WHERE owner_id = $1 AND status = 'ativo'", [ownerId])).map((r: any) => Number(r.user_id))
  const cliques = (await q('SELECT DISTINCT user_id FROM mkt_sends WHERE owner_id = $1 AND clicado_em IS NOT NULL', [ownerId])).map((r: any) => Number(r.user_id))
  const potIds = [...new Set([...aut, ...cliques])].filter((id) => !por.has(id) && id !== ownerId)
  const nomes = async (l: number[]) => l.length ? (await q(`SELECT id, name FROM users WHERE id IN (${l.slice(0, 5).map((_, i) => '$' + (i + 1)).join(',')})`, l.slice(0, 5))).map((u: any) => String(u.name || '').split(' ')[0]).filter(Boolean) : []
  const camp = (await q("SELECT titulo, enviados, cliques FROM mkt_campaigns WHERE owner_id = $1 AND status = 'concluida' ORDER BY id DESC LIMIT 3", [ownerId])).map((c: any) => ({ titulo: String(c.titulo), enviados: Number(c.enviados), cliques: Number(c.cliques) }))
  return { total: por.size, novos, recorrentes, inativos, potenciais: potIds.length, autorizados: aut.length, inativosLista: await nomes(inativosIds), potenciaisLista: await nomes(potIds), campanhas: camp }
}
/** Contexto de sistema desta mensagem: playbook do tema + o que está realmente ligado + números reais. Vazio se a conversa não é comercial. */
export async function commercialContext(u: SessionUser, text: string): Promise<string> {
  if (!isCommercial(text)) return ''
  const partes: string[] = [playbookFor(text)]
  let mktAtivo = false, crmAtivo = false
  try {
    const mk = await import('../lib/marketing.js'), m = await modules()
    crmAtivo = await (await import('./crm-ia.js')).crmDisponivel(u).catch(() => false)
    const pl = await mk.ownerPlan(u.id)
    mktAtivo = !!pl.limites.acesso && !!pl.business
    const v = await visaoClientes(u.id).catch(() => null)
    partes.push(mktAtivo
      ? `ESTADO REAL — Marketing: ATIVO para a empresa "${pl.business!.empresa}". Campanhas usadas ${pl.uso.campanhas}/${pl.limites.campanhasPeriodo}; notificações usadas ${pl.uso.notificacoes}/${pl.limites.notificacoesPeriodo}; segmentação ${pl.limites.segmentacao ? 'disponível' : 'não disponível neste plano'}; programar envios ${pl.limites.agendar ? 'disponível' : 'não disponível neste plano'}. Só recebe quem autorizou comunicações. Use as notificações push de forma estratégica, sem excesso.`
      : 'ESTADO REAL — Marketing: NÃO está disponível para este usuário (desligado pelo administrador, sem empresa ativa ou fora do plano). Não prometa campanhas nem push; dê dicas de divulgação manual e, se fizer sentido, cite que um plano com Marketing libera a Central.')
    partes.push(crmAtivo
      ? 'ESTADO REAL — CRM: ATIVO (funil, oportunidades, tarefas e ficha do cliente). Use as ferramentas crm_* para consultar e registrar; integre com Marketing e Atendimento.'
      : 'ESTADO REAL — CRM: NÃO disponível para este usuário (precisa de empresa ativa em plano com loja e módulo ligado). Não diga que registrou clientes ou negociações em um CRM. Use a "visão de clientes" abaixo, calculada dos pedidos, agendamentos, autorizações e cliques de campanha.')
    if (v) partes.push(`VISÃO DE CLIENTES (calculada agora; ${INATIVO_DIAS} dias sem comprar = inativo): ${v.total} cliente(s) com compras/agendamentos — ${v.novos} novo(s), ${v.recorrentes} ativo(s)/recorrente(s), ${v.inativos} inativo(s); ${v.potenciais} potencial(is) (autorizaram contato ou clicaram, sem compra); ${v.autorizados} autorizaram comunicações.${v.inativosLista.length ? ` Inativos (primeiros nomes): ${v.inativosLista.join(', ')}.` : ''}${v.potenciaisLista.length ? ` Potenciais: ${v.potenciaisLista.join(', ')}.` : ''}${v.campanhas.length ? ` Últimas campanhas: ${v.campanhas.map((c) => `"${c.titulo}" ${c.enviados} envios, ${c.cliques} cliques`).join('; ')}.` : ''} Use esses números como fatos; não invente outros.`)
    else partes.push('VISÃO DE CLIENTES: este usuário não tem empresa cadastrada, então não há dados de clientes. Dê orientação geral e não invente números.')
  } catch { /* sem contexto extra */ }
  return partes.filter(Boolean).join('\n')
}
