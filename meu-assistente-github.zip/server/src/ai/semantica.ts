// RECUPERAÇÃO SEMÂNTICA LOCAL (Fase 5) — encontra informações pelo SIGNIFICADO e pelo contexto, não só por palavra igual:
// • radicais do português ("cachorros", "cachorrinha" → "cachorr"; "consultas", "consultei" → "consult");
// • mapa de conceitos ("pet" ↔ "cachorro" ↔ "ração" ↔ "veterinário"; "carro" ↔ "oficina" ↔ "IPVA"…);
// • tolerância a erros de digitação (trigramas: "cachoro" ≈ "cachorro");
// • ranqueamento BM25 + nomes próprios em comum.
// Tudo roda no servidor, sem enviar dados para fora, em microssegundos. Usado pela memória evolutiva e pelo diagnóstico.

export const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const STOP = new Set(('a o os as um uma uns umas de da do das dos e ou em no na nos nas para pra pro por com sem que se ao aos como mais muito muita pouco sobre isso isto este esta esse essa eles elas ele ela eu tu voce voces seu sua seus suas meu minha meus minhas nosso nossa ser estar ter tem tenho foi era sao esta estao ja nao sim quando onde qual quais quem porque pois entao tambem ate cada todo toda todos todas me te lhe nos vos la ai aqui ali entre depois antes agora hoje ontem amanha sempre nunca bem mal so ainda vai vou fui ia num numa dum duma pelo pela pelos pelas lembre lembra lembrar guarde guarda anote anota sobre qualquer coisa algo alguem gosto gosta').split(' '))

/** Radical leve do português (inspirado no RSLP): plural, diminutivo, terminações verbais e vogal final. */
export function radical(w: string): string {
  let s = nrm(w).replace(/[^a-z0-9]/g, '')
  if (s.length <= 3 || /^\d+$/.test(s)) return s
  const troca = (suf: string, por: string, min = 3) => { if (s.endsWith(suf) && s.length - suf.length >= min) { s = s.slice(0, -suf.length) + por; return true } return false }
  troca('oes', 'ao') || troca('aes', 'ao') || troca('ais', 'al') || troca('eis', 'el') || troca('ns', 'm') || troca('res', 'r') || troca('zes', 'z') || (s.length > 4 && troca('s', '', 3))
  troca('zinho', '') || troca('zinha', '') || troca('inho', '', 4) || troca('inha', '', 4)
  troca('aram', '') || troca('eram', '') || troca('iram', '') || troca('ando', '') || troca('endo', '') || troca('indo', '') || troca('ava', '') || troca('ado', '') || troca('ada', '') || troca('ido', '') || troca('ida', '') || troca('ou', '') || troca('ei', '') || troca('ar', '', 4) || troca('er', '', 4) || troca('ir', '', 4)
  if (s.length > 4 && /[aeo]$/.test(s)) s = s.slice(0, -1)
  return s
}
export function termos(t: string): string[] { return nrm(t).replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w)).map(radical).filter((w) => w.length > 2) }
/** Nomes próprios (palavras com maiúscula fora do início da frase e nomes depois de "se chama/chamado"). */
export function nomesProprios(t: string): string[] {
  const out = new Set<string>()
  for (const m of String(t).matchAll(/(?:^|[^.!?\n]\s)([A-ZÁÉÍÓÚÂÊÔÃÕ][a-záéíóúâêôãõç]{2,})/g)) out.add(nrm(m[1]))
  for (const m of nrm(t).matchAll(/\b(?:se chama|chamad[oa]|nome (?:dele|dela|e))\s+([a-z]{3,})/g)) out.add(m[1])
  return [...out].filter((n) => !STOP.has(n))
}

/* ---------- conceitos (sinônimos e campo semântico do dia a dia) ---------- */
const CONCEITOS_TXT: Record<string, string> = {
  pet: 'pet pets animal animais cachorro cachorra cao caes cadela filhote gato gata felino racao veterinario veterinaria vacina vermifugo banho tosa coleira passear petshop',
  veiculo: 'carro carros veiculo automovel moto motocicleta oficina mecanico gasolina combustivel alcool etanol abastecer ipva licenciamento pneu revisao seguro multa estacionamento garagem uber',
  saude: 'medico medica consulta dentista exame exames remedio remedios hospital clinica alergia alergico alergica plano saude doenca tratamento cirurgia farmacia vacina psicologo terapia nutricionista',
  alimentacao: 'comida comer almoco jantar cafe lanche restaurante cardapio receita cozinhar mercado supermercado feira vegetariano vegetariana vegano vegana dieta fruta carne peixe sushi pizza doce',
  trabalho: 'trabalho trabalhar emprego escritorio chefe gerente colega reuniao cliente clientes empresa projeto salario carreira cargo profissao expediente plantao hospital',
  familia: 'familia esposa marido mulher filho filha filhos mae pai irmao irma avo avos tio tia primo prima sogra sogro neto neta namorado namorada noivo noiva casamento crianca criancas',
  dinheiro: 'dinheiro conta contas boleto fatura cartao banco pix gasto gastos despesa receita salario investimento poupanca divida emprestimo orcamento economia pagar pagamento',
  moradia: 'casa apartamento moro morar mora aluguel condominio luz agua internet gas mudanca bairro cidade vizinho reforma endereco',
  viagem: 'viagem viajar ferias hotel passagem voo aeroporto praia turismo mala passaporte hospedagem roteiro',
  estudo: 'escola faculdade universidade curso prova estudar estudo aula aulas ingles idioma professor professora trabalho escolar matricula enem',
  lazer: 'academia pilates futebol corrida treino treinar musica jazz rock filme filmes serie series livro livros leitura ler jogo jogos show teatro danca yoga',
  comunicacao: 'resposta respostas curta curtas longa longas detalhada detalhadas formal informal audio audios mensagem mensagens emoji emojis',
  rotina: 'rotina manha tarde noite acordar acordo dormir durmo horario horarios diariamente',
}
const CONCEITOS = new Map<string, Set<string>>() // radical → conceitos
for (const [c, lista] of Object.entries(CONCEITOS_TXT)) for (const w of lista.split(' ')) { const r = radical(w); if (r.length > 2) (CONCEITOS.get(r) || CONCEITOS.set(r, new Set()).get(r)!).add(c) }
export const conceitosDe = (toks: string[]) => { const s = new Set<string>(); for (const t of toks) for (const c of CONCEITOS.get(t) || []) s.add(c); return s }

const trigramas = (w: string) => { const s = `  ${w} `, out = new Set<string>(); for (let i = 0; i < s.length - 2; i++) out.add(s.slice(i, i + 3)); return out }
export function parecidas(a: string, b: string) { if (Math.abs(a.length - b.length) > 2) return 0; const A = trigramas(a), B = trigramas(b); let i = 0; for (const x of A) if (B.has(x)) i++; return (2 * i) / (A.size + B.size) }

/* ---------- índice BM25 ---------- */
export interface DocBase { id: number; texto: string; [k: string]: any }
export interface Doc<T extends DocBase = DocBase> { base: T; toks: string[]; tf: Map<string, number>; conc: Set<string>; nomes: Set<string>; len: number }
export interface Indice<T extends DocBase = DocBase> { docs: Doc<T>[]; df: Map<string, number>; cdf: Map<string, number>; avg: number; N: number; vocab: string[] }
export function indexar<T extends DocBase>(lista: T[]): Indice<T> {
  const docs = lista.map((base) => { const toks = termos(base.texto), tf = new Map<string, number>(); for (const t of toks) tf.set(t, (tf.get(t) || 0) + 1); return { base, toks, tf, conc: conceitosDe(toks), nomes: new Set(nomesProprios(base.texto)), len: toks.length || 1 } })
  const df = new Map<string, number>(), cdf = new Map<string, number>()
  for (const d of docs) { for (const t of d.tf.keys()) df.set(t, (df.get(t) || 0) + 1); for (const c of d.conc) cdf.set(c, (cdf.get(c) || 0) + 1) }
  return { docs, df, cdf, avg: docs.reduce((a, d) => a + d.len, 0) / Math.max(1, docs.length), N: docs.length, vocab: [...df.keys()].filter((t) => t.length >= 5) }
}
export interface Achado<T extends DocBase = DocBase> { doc: Doc<T>; score: number; motivos: string[] }
const idf = (n: number, N: number) => Math.log(1 + (N - n + 0.5) / (n + 0.5))
/** Busca por significado: termos (BM25) + conceitos + aproximação de digitação + nomes próprios. */
export function buscar<T extends DocBase>(ind: Indice<T>, consulta: string, o: { k?: number; min?: number } = {}): Achado<T>[] {
  if (!ind.N) return []
  const qt = [...new Set(termos(consulta))], qc = conceitosDe(qt), qn = new Set(nomesProprios(consulta).concat(nrm(consulta).split(/\W+/).filter((w) => w.length > 2)))
  // erros de digitação: termos da consulta que não existem no índice ganham o vizinho mais parecido do vocabulário
  const aprox = new Map<string, string>()
  for (const t of qt) if (!ind.df.has(t) && t.length >= 5) { let melhor = '', s = 0; for (const v of ind.vocab) { const x = parecidas(t, v); if (x > s) { s = x; melhor = v } } if (s >= 0.55) aprox.set(t, melhor) }
  const k1 = 1.2, b = 0.75, out: Achado<T>[] = []
  for (const d of ind.docs) {
    let score = 0; const motivos = new Set<string>()
    for (const t of qt) {
      const alvo = d.tf.has(t) ? t : aprox.get(t) && d.tf.has(aprox.get(t)!) ? aprox.get(t)! : ''
      if (!alvo) continue
      const f = d.tf.get(alvo)!, w = idf(ind.df.get(alvo) || 0, ind.N) * ((f * (k1 + 1)) / (f + k1 * (1 - b + (b * d.len) / ind.avg)))
      score += alvo === t ? w : w * 0.6; motivos.add(alvo === t ? 'termo' : 'aproximado')
    }
    for (const c of qc) if (d.conc.has(c)) { score += 0.9 * idf(ind.cdf.get(c) || 0, ind.N); motivos.add('conceito:' + c) }
    for (const n of d.nomes) if (qn.has(n)) { score += 2; motivos.add('nome') }
    if (score > 0) out.push({ doc: d, score, motivos: [...motivos] })
  }
  return out.filter((a) => a.score >= (o.min ?? 0.6)).sort((a, b) => b.score - a.score).slice(0, o.k ?? 10)
}
/** Associação: documentos ligados aos achados por um nome próprio em comum ou pelo mesmo assunto da pergunta. */
export function associar<T extends DocBase>(ind: Indice<T>, achados: Achado<T>[], max = 3, consulta = ''): Achado<T>[] {
  const ja = new Set(achados.map((a) => a.doc.base.id)), out: Achado<T>[] = []
  // ligação forte: um nome próprio em comum; ligação fraca: o MESMO assunto da pergunta (conceito da consulta) — nunca um assunto alheio
  const qc = conceitosDe(termos(consulta)), nomes = new Set(achados.flatMap((a) => [...a.doc.nomes])), conc = new Set([...qc].filter((c) => (ind.cdf.get(c) || 0) <= Math.max(2, ind.N / 3)))
  for (const d of ind.docs) {
    if (ja.has(d.base.id)) continue
    const porNome = [...d.nomes].filter((n) => nomes.has(n)), porConc = [...d.conc].filter((c) => conc.has(c))
    if (porNome.length) out.push({ doc: d, score: 3 + porNome.length, motivos: porNome.map((n) => 'nome:' + n) })
    else if (porConc.length) out.push({ doc: d, score: 1 + porConc.length * 0.5, motivos: porConc.map((c) => 'conceito:' + c) })
  }
  return out.sort((a, b) => b.score - a.score).slice(0, max)
}
