// PLANEJAMENTO INTELIGENTE — decompõe pedidos complexos em etapas (com ferramenta provável, prioridade e dependência),
// guarda o plano da conversa, marca o que foi feito/falhou/aguarda confirmação a partir do que as ferramentas
// REALMENTE retornaram, e retoma as etapas pendentes no turno seguinte. Determinístico: não chama IA.
import { q, one, nowIso, J } from '../db/index.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
export type StatusEtapa = 'pendente' | 'feito' | 'falhou' | 'aguardando'
export interface Etapa { n: number; acao: string; texto: string; ferramenta: string | null; prioridade: 'alta' | 'media' | 'baixa'; depende: number[]; status: StatusEtapa; verificado?: boolean; detalhe?: string }
export interface Plano { id?: number; etapas: Etapa[]; status: 'ativo' | 'concluido' | 'abandonado'; criadoEm?: string }

const MAPA: [RegExp, string, string][] = [
  // consultas primeiro: "quanto gastei hoje?" é pergunta, não um gasto a registrar
  [/\b(o que (eu )?tenho|minha agenda|meus compromissos|tenho algo)\b/, 'get_agenda', 'Consultar agenda'],
  [/\b(quanto (eu )?gastei|meus gastos|saldo|minhas financas|resumo financeiro)\b/, 'get_finance', 'Consultar finanças'],
  [/\b(gastei|paguei|comprei|recebi|ganhei|vendi|registr\w* (o |um )?(gasto|pagamento|receita|despesa)|lanc\w* (o |um )?(gasto|despesa|receita))\b/, 'register_transaction', 'Registrar lançamento'],
  [/\b(cadastr\w*|cri\w*|adicion\w*|anot\w*|registr\w*)\b.*\b(conta|boleto|fatura)\b|\b(conta|boleto|fatura)\b.*\b(vence|vencimento)\b/, 'create_bill', 'Cadastrar conta a pagar'],
  [/\b(remarc\w*|alter\w* (o |a )?(compromisso|agendamento|horario)|edit\w* (o |a )?(compromisso|agendamento)|mud\w* (o |a )?(compromisso|agendamento|horario) d[oa])\b/, 'update_appointment', 'Alterar compromisso existente'],
  [/\b(agend\w*|marc(a|ar|que)\b)\b|\b(reuniao|consulta|compromisso)\b.*\b(amanha|hoje|dia \d|segunda|terca|quarta|quinta|sexta|sabado|domingo|\d{1,2}h)\b/, 'create_appointment', 'Agendar compromisso'],
  [/\b(lembr\w*|me avis\w*|avisa\w*)\b/, 'create_reminder', 'Criar lembrete'],
  [/\b(conclu\w*|terminei|finalizei|marca (como )?feit\w*)\b/, 'complete_task', 'Concluir tarefa'],
  [/\b(tarefa\w*|to-?do|pendencia)\b/, 'create_task', 'Criar tarefa'],
  [/\b(lista de compras|comprar|compras|mercado|(na|da|pra|para a) lista)\b/, 'add_shopping_items', 'Adicionar à lista de compras'],
  [/\b(anot\w*|nota)\b/, 'create_note', 'Salvar anotação'],
]
const SEP = /\s*(?:;|\n+|\.\s+(?=[A-ZÀ-Ý])|,?\s+agora\s+(?=\S)|,?\s+e depois\s+|,?\s+depois disso\s+|,?\s+em seguida\s+|,?\s+depois\s+|,?\s+e tamb[eé]m\s+|,?\s+al[eé]m disso\s+|,?\s+e ainda\s+|,\s+(?=(?:e\s+)?(?:agend|marc|lembr|cri|cadastr|anot|registr|adicion|coloc|conclu|pagu|gastei|me avis|avis)))\s*/i
const ENUM = /^\s*(?:\d+[.)]|[-*•])\s+/

// fala ditada sem pontuação: "marca o dentista amanha as 10 cria uma tarefa ... e me lembra ..." — divide antes de cada verbo de ação
const VERBO_INICIO = /\s+(?=(?:me\s+)?(?:cria|crie|marca|marque|agende|lembra|lembre|anota|anote|registra|registre|cadastra|cadastre|coloca|coloque|bota|adiciona|adicione|avisa|avise)\b|agenda\s+(?:o|a|um|uma|pra|para|minha|meu)\b)/i
const E_ACAO = /\s+e\s+(?=(?:me\s+)?(?:agend|marc|lembr|cri|cadastr|anot|registr|adicion|coloc|conclu|avis|bot)|(?:quanto|o que|qual|quais|quando)\b|(?:outr[ao]|mais uma?)\b)/i
const REPETE = /^(outr[ao]|mais uma?)\b/i
/** Quebra o pedido em etapas. Só devolve plano quando há duas ou mais ações reconhecíveis. */
export function decompor(text: string): Etapa[] {
  const bruto = String(text || ''), mapeia = (x: string) => MAPA.some(([re]) => re.test(nrm(x)))
  let partes = bruto.split(SEP).map((p) => p.replace(ENUM, '').trim()).filter((p) => p.length > 2)
  partes = partes.flatMap((p) => { const m = p.split(VERBO_INICIO).map((x) => x.replace(/\s+e$/i, '').trim()).filter((x) => x.length > 2); return m.length > 1 && m.every(mapeia) ? m : [p] })
  // "agenda X e cria Y", "o que tenho amanhã e quanto gastei", "uma tarefa de X e outra de Y"
  partes = partes.flatMap((p) => { const m = p.split(E_ACAO); return m.length > 1 && m.every((x, i) => mapeia(x) || (i > 0 && REPETE.test(x.trim()))) ? m : [p] })
  const etapas: Etapa[] = []; let fimAnterior = 0
  for (const p of partes) {
    const s = nrm(p), m = MAPA.find(([re]) => re.test(s)) || (REPETE.test(p.trim()) && etapas.length ? MAPA.find(([, f]) => f === etapas[etapas.length - 1].ferramenta) : undefined)
    const ini = bruto.indexOf(p.slice(0, 24), fimAnterior), entre = nrm(ini >= 0 ? bruto.slice(fimAnterior, ini) : ''); if (ini >= 0) fimAnterior = ini + p.length
    if (!m) continue
    const urgente = /\b(urgente|agora|hoje|ja|imediat\w*|o quanto antes)\b/.test(s)
    const prioridade: Etapa['prioridade'] = urgente ? 'alta' : ['register_transaction', 'create_bill', 'create_appointment', 'create_reminder'].includes(m[1]) ? 'media' : 'baixa'
    const n = etapas.length + 1
    // dependência: o usuário disse "depois", "em seguida", "então" ou "agora" entre esta etapa e a anterior
    etapas.push({ n, acao: m[2], texto: p.slice(0, 140), ferramenta: m[1], prioridade, depende: n > 1 && /\b(depois|em seguida|entao|apos|agora)\b/.test(entre) ? [n - 1] : [], status: 'pendente' })
  }
  if (etapas.length < 2) return []
  return etapas
}
/** Ordem de execução sugerida: prioridade, respeitando dependências. */
export function ordem(etapas: Etapa[]): Etapa[] {
  const peso = { alta: 0, media: 1, baixa: 2 } as const, feito = new Set<number>(), out: Etapa[] = [], resto = [...etapas]
  while (resto.length) {
    const prontas = resto.filter((e) => e.depende.every((d) => feito.has(d))).sort((a, b) => peso[a.prioridade] - peso[b.prioridade] || a.n - b.n)
    const e = prontas[0] || resto[0]; out.push(e); feito.add(e.n); resto.splice(resto.indexOf(e), 1)
  }
  return out
}

/** Marca etapas a partir do que as ferramentas retornaram neste turno (sucesso, falha ou aguardando confirmação). */
export function aplicarExecucao(p: Plano, done: { name: string; result: any }[]): Plano {
  const etapas = p.etapas.map((e) => ({ ...e }))
  for (const d of done) {
    const e = etapas.find((x) => x.ferramenta === d.name && (x.status === 'pendente' || x.status === 'aguardando'))
    if (!e) continue
    const r = d.result || {}
    if (r.ok === true || (r.ok === undefined && !r.error)) { e.status = 'feito'; e.detalhe = undefined }
    else if (r.precisaConfirmar || r.conflito) e.status = 'aguardando'
    else { e.status = 'falhou'; e.detalhe = String(r.error || 'não foi possível concluir').slice(0, 140) }
  }
  const fim = etapas.every((e) => e.status === 'feito')
  return { ...p, etapas, status: fim ? 'concluido' : p.status }
}
export const pendentes = (p: Plano | null) => (p ? p.etapas.filter((e) => e.status !== 'feito') : [])

/** Texto para a IA: o plano a executar agora ou o plano em andamento desta conversa. */
export function contextoPlano(p: Plano, novo: boolean): string {
  const lista = ordem(p.etapas).map((e) => `${e.n}. [${e.status}] ${e.acao}: "${e.texto}"${e.ferramenta ? ` → ${e.ferramenta}` : ''} · prioridade ${e.prioridade}${e.depende.length ? ` · depois da etapa ${e.depende.join(', ')}` : ''}`)
  return (novo ? `PLANO (${p.etapas.length} etapas, na ordem sugerida): execute cada etapa com a ferramenta indicada, confira o resultado de cada uma e, no fim, informe com clareza o que foi feito e o que não foi.` : 'PLANO EM ANDAMENTO nesta conversa — continue pelas etapas pendentes (as já feitas não devem ser repetidas):') + '\n' + lista.join('\n')
}
/** Resumo curto para o usuário quando o plano ficou parcial neste turno (só o que a resposta ainda não disse). */
export function resumoParcial(p: Plano, resposta: string): string {
  const pend = pendentes(p); if (!pend.length || p.etapas.length < 2) return ''
  const r = nrm(resposta)
  const ditas = pend.filter((e) => r.includes(nrm(e.acao).split(' ')[0].slice(0, 6)) || (e.detalhe && r.includes(nrm(e.detalhe).slice(0, 18))))
  if (ditas.length === pend.length) return ''
  const linhas = p.etapas.map((e) => `${e.status === 'feito' ? '✓' : e.status === 'falhou' ? '✗' : e.status === 'aguardando' ? '…' : '○'} ${e.acao}${e.status === 'falhou' && e.detalhe ? ` — ${e.detalhe.replace(/[.\s]+$/, '')}` : e.status === 'aguardando' ? ' — aguardando sua confirmação' : e.status === 'pendente' ? ' — ainda não feito' : ''}`)
  return `Andamento do seu pedido:\n${linhas.join('\n')}`
}

/* ---------- persistência por conversa (válida por 6 horas) ---------- */
export async function planoAtivo(userId: number, convId: string): Promise<Plano | null> {
  if (!convId) return null
  const r = await one("SELECT * FROM assistant_plans WHERE user_id = $1 AND conversation_id = $2 AND status = 'ativo' ORDER BY id DESC LIMIT 1", [userId, convId]).catch(() => null)
  if (!r) return null
  if (Date.now() - Date.parse(String(r.updated_at)) > 6 * 3600e3) { await q("UPDATE assistant_plans SET status = 'abandonado', updated_at = $1 WHERE id = $2", [nowIso(), r.id]); return null }
  return { id: Number(r.id), etapas: J<Etapa[]>(r.steps, []), status: 'ativo', criadoEm: String(r.created_at) }
}
export async function salvarPlano(userId: number, convId: string, p: Plano): Promise<Plano> {
  const now = nowIso()
  if (p.id) { await q('UPDATE assistant_plans SET steps = $1, status = $2, updated_at = $3 WHERE id = $4 AND user_id = $5', [JSON.stringify(p.etapas), p.status, now, p.id, userId]); return p }
  await q("UPDATE assistant_plans SET status = 'abandonado', updated_at = $1 WHERE user_id = $2 AND conversation_id = $3 AND status = 'ativo'", [now, userId, convId])
  const r = await q('INSERT INTO assistant_plans (user_id, conversation_id, steps, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5) RETURNING id', [userId, convId, JSON.stringify(p.etapas), p.status, now])
  return { ...p, id: Number(r[0]?.id) }
}
export async function abandonar(userId: number, convId: string) { await q("UPDATE assistant_plans SET status = 'abandonado', updated_at = $1 WHERE user_id = $2 AND conversation_id = $3 AND status = 'ativo'", [nowIso(), userId, convId]) }
