// Fase 9 — Laboratório de Inteligência (exclusivo de administradores autorizados).
// Núcleo: usuário SINTÉTICO, desafios da Arena com avaliação objetiva, rodadas em segundo plano, experimentos
// (versão atual × experimental com os MESMOS cenários), simulador de conversas e desafios contínuos.
// Isolamento: tudo roda no modo simulação do assistente (nenhuma ferramenta executa de verdade), com o usuário sintético
// (id 0: nenhum dado real é lido) e com memórias/consultas fictícias do próprio cenário. A política, as instruções e os
// especialistas da variante experimental valem SÓ dentro da rodada (AsyncLocalStorage) — nunca para os usuários.
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from '../lib/http.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import type { SessionUser } from '../lib/session.js'
import * as POL from './politica.js'
import type { Agente } from './agentes.js'

/* ======================= configuração e usuário sintético ======================= */
export const LAB_DEFAULT = { ativo: true, continuo: true, maxDesafios: 40, maxSimultaneas: 2 }
export type LabCfg = typeof LAB_DEFAULT & { atualizadoEm?: string }
export const labCfg = async (): Promise<LabCfg> => ({ ...LAB_DEFAULT, ...(await getConfig<any>('laboratorio', {})) })
export async function salvarLabCfg(p: Partial<LabCfg>) {
  const c = await labCfg(), n: any = { ...c }
  if (p.ativo !== undefined) n.ativo = !!p.ativo
  if (p.continuo !== undefined) n.continuo = !!p.continuo
  if (p.maxDesafios !== undefined) { const v = Math.round(Number(p.maxDesafios)); if (!(v >= 5 && v <= 100)) fail(400, 'Desafios por rodada: de 5 a 100.', 'invalid', 'maxDesafios'); n.maxDesafios = v }
  if (p.maxSimultaneas !== undefined) { const v = Math.round(Number(p.maxSimultaneas)); if (!(v >= 1 && v <= 4)) fail(400, 'Rodadas simultâneas: de 1 a 4.', 'invalid', 'maxSimultaneas'); n.maxSimultaneas = v }
  n.atualizadoEm = nowIso(); await setConfig('laboratorio', n); return n as LabCfg
}
/** Usuário de teste: id 0 não pertence a ninguém — consultas reais voltam vazias; nada é gravado no modo simulação. */
export const USUARIO_LAB = { id: 0, email: 'laboratorio@sintetico.invalid', name: 'Usuário de teste', whatsapp: '', birthday: null, role: 'user', permissions: [], status: 'active', avatar_url: null, settings: {}, interaction: {}, chat_ui: {}, memory_settings: { enabled: false }, mfa_enabled: false, mfa_secret: null, mfa_pending_secret: null, backup_codes: [], password_hash: '', created_at: '2026-01-01T00:00:00.000Z', last_seen_at: null } as unknown as SessionUser

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
/** Experimentos usam dados sintéticos: e-mails, telefones, CPF e cartões reais são recusados. */
export function pareceDadoPessoal(t: string) {
  const s = String(t || '')
  const emails = [...s.matchAll(/[\w.+-]+@([\w-]+\.[\w.]+)/g)].filter((m) => !/(^|\.)(exemplo|example|teste|test|sintetico|invalid)(\.|$)/i.test(m[1]))
  return emails.length > 0 || /\b\d{3}\.\d{3}\.\d{3}-\d{2}\b|\b\d{11}\b/.test(s) || /\(?\b\d{2}\)?\s?9\d{4}-?\d{4}\b/.test(s) || /\b(?:\d{4}[ -]?){3}\d{4}\b/.test(s)
}
function exigirSintetico(...textos: string[]) { if (textos.some((t) => pareceDadoPessoal(t))) fail(400, 'O texto parece conter um dado pessoal real (e-mail, telefone, CPF ou cartão). No laboratório, use só dados fictícios.', 'dado_pessoal') }

/* ======================= desafios ======================= */
export const CATEGORIAS: Record<string, string> = {
  logica: 'Raciocínio lógico', contexto: 'Interpretação contextual', memoria: 'Memória', planejamento: 'Planejamento', problemas: 'Resolução de problemas',
  matematica: 'Matemática', financeiro: 'Interpretação financeira', comunicacao: 'Comunicação profissional', contradicoes: 'Identificação de contradições', execucao: 'Execução de tarefas',
}
export interface Criterio { tipo: 'contem' | 'nao_contem' | 'ferramenta' | 'sem_escrita' | 'pergunta' | 'numero' | 'itens' | 'max_palavras' | 'naturalidade'; valor?: any; args?: Record<string, any> }
export interface Contexto { historico?: { papel: 'usuario' | 'assistente'; texto: string }[]; memorias?: string[]; dados?: Record<string, any> }
export interface Desafio { id?: number; slug: string; categoria: string; titulo: string; prompt: string; contexto: Contexto; criterios: Criterio[]; origem: 'padrao' | 'personalizado'; ativo?: boolean }
export const TIPOS_CRITERIO: Record<string, string> = {
  contem: 'a resposta menciona', nao_contem: 'a resposta não menciona', ferramenta: 'usa a ferramenta', sem_escrita: 'não grava nada (só conversa/consulta)', pergunta: 'faz uma pergunta de esclarecimento',
  numero: 'apresenta o número', itens: 'organiza em pelo menos N itens', max_palavras: 'no máximo N palavras', naturalidade: 'naturalidade mínima (nota interna, estimativa)',
}
const LEITURA = new Set(['get_agenda', 'get_finance', 'get_previsoes', 'acompanhar_execucao', 'agenda_empresa_consultar', 'agenda_empresa_alertas', 'crm_buscar_cliente', 'crm_historico_cliente', 'crm_oportunidades', 'crm_inteligencia', 'negocio_resumo', 'negocio_comparar', 'negocio_analise'])
export const DADOS_PERMITIDOS = ['get_agenda', 'get_finance', 'get_previsoes']
const h = (...t: string[]) => t.map((texto, i) => ({ papel: (i % 2 ? 'assistente' : 'usuario') as 'usuario' | 'assistente', texto }))
const FIN = { ok: true, mes: 'mês atual', lancamentos: [{ tipo: 'gasto', categoria: 'Alimentação', descricao: 'Supermercado', valor: 320.5 }, { tipo: 'gasto', categoria: 'Alimentação', descricao: 'Restaurante', valor: 89.9 }, { tipo: 'gasto', categoria: 'Transporte', descricao: 'Aplicativo de transporte', valor: 45 }, { tipo: 'receita', categoria: 'Salário', descricao: 'Salário', valor: 3200 }], totais: { gastos: 455.4, receitas: 3200, saldo: 2744.6 } }
const D = (slug: string, categoria: string, titulo: string, prompt: string, criterios: Criterio[], contexto: Contexto = {}): Desafio => ({ slug, categoria, titulo, prompt, contexto, criterios, origem: 'padrao' })
/** Catálogo padrão: tudo fictício. Critérios objetivos (verificados no texto e nas ações que a IA TENTARIA fazer). */
export const DESAFIOS_PADRAO: Desafio[] = [
  D('log-silogismo', 'logica', 'Dedução simples', 'Todo cliente VIP tem desconto. A Carla é cliente VIP. A Carla tem desconto? Responda e explique em uma frase.', [{ tipo: 'contem', valor: 'sim|tem desconto' }, { tipo: 'sem_escrita' }]),
  D('log-ordem', 'logica', 'Ordenação', 'A reunião com Ana é às 9h, a com Bruno às 11h e a com Carla às 10h. Com quem é a segunda reunião do dia?', [{ tipo: 'contem', valor: 'carla' }, { tipo: 'sem_escrita' }]),
  D('log-comparacao', 'logica', 'Transitividade', 'Pedro é mais velho que João. João é mais velho que Maria. Quem é o mais novo dos três?', [{ tipo: 'contem', valor: 'maria' }, { tipo: 'sem_escrita' }]),
  D('ctx-confirmacao', 'contexto', 'Confirmação curta', 'sim, um dia antes', [{ tipo: 'ferramenta', valor: 'create_reminder' }], { historico: h('Vou viajar para Recife na sexta-feira.', 'Que bom! Quer que eu crie um lembrete para não esquecer de nada?') }),
  D('ctx-parcelas', 'contexto', 'Valor dito antes', 'quanto fica cada parcela?', [{ tipo: 'numero', valor: 600 }, { tipo: 'sem_escrita' }], { historico: h('Comprei uma geladeira de R$ 2.400 em 4 parcelas iguais.', 'Anotado! Quer que eu registre?') }),
  D('ctx-pronome', 'contexto', 'Referência a pessoa citada', 'me lembra de comprar o presente dela dois dias antes', [{ tipo: 'ferramenta', valor: 'create_reminder' }, { tipo: 'contem', valor: 'laura|presente' }], { historico: h('Minha filha se chama Laura e faz aniversário no dia 20.', 'Que lindo! Posso ajudar a organizar algo?') }),
  D('mem-alergia', 'memoria', 'Usa uma restrição lembrada', 'Vou num restaurante de frutos do mar hoje. Alguma dica?', [{ tipo: 'contem', valor: 'camarao|alergia|alergic' }], { memorias: ['O usuário é alérgico a camarão.'] }),
  D('mem-preferencia', 'memoria', 'Usa uma preferência lembrada', 'Qual o melhor horário para marcar a reunião com o fornecedor?', [{ tipo: 'contem', valor: 'manha' }], { memorias: ['O usuário prefere reuniões pela manhã.'] }),
  D('mem-fato', 'memoria', 'Recupera um fato', 'Como se chama o meu cachorro?', [{ tipo: 'contem', valor: 'thor' }, { tipo: 'sem_escrita' }], { memorias: ['O cachorro do usuário se chama Thor.'] }),
  D('pla-festa', 'planejamento', 'Plano em etapas', 'Quero organizar uma festa de aniversário para 20 pessoas daqui a 3 semanas. Monte um plano em etapas.', [{ tipo: 'itens', valor: 3 }]),
  D('pla-estudo', 'planejamento', 'Distribuir tarefas no tempo', 'Tenho uma prova em 10 dias com 5 capítulos para estudar. Como divido o estudo?', [{ tipo: 'itens', valor: 3 }, { tipo: 'contem', valor: 'capitulo' }]),
  D('pla-multi', 'planejamento', 'Pedido com três ações', 'Agenda dentista amanhã às 10h, cria a tarefa de levar o exame e me lembra de pagar a conta de luz na sexta.', [{ tipo: 'ferramenta', valor: 'create_appointment' }, { tipo: 'ferramenta', valor: 'create_task' }, { tipo: 'ferramenta', valor: 'create_reminder' }]),
  D('pro-celular', 'problemas', 'Diagnóstico passo a passo', 'Meu celular parou de carregar. O que posso verificar antes de levar na assistência?', [{ tipo: 'itens', valor: 3 }, { tipo: 'sem_escrita' }]),
  D('pro-orcamento', 'problemas', 'Gastos acima da renda', 'Gastei mais do que ganhei este mês. O que posso fazer?', [{ tipo: 'itens', valor: 2 }, { tipo: 'nao_contem', valor: 'como assistente de ia' }]),
  D('pro-atraso', 'problemas', 'Conta vencida', 'Esqueci de pagar uma conta que venceu ontem. O que eu faço agora?', [{ tipo: 'contem', valor: 'juros|multa|pagar|boleto' }, { tipo: 'sem_escrita' }]),
  D('mat-percentual', 'matematica', 'Porcentagem', 'Quanto é 15% de 240?', [{ tipo: 'numero', valor: 36 }]),
  D('mat-meses', 'matematica', 'Problema com divisão', 'Se eu guardar R$ 250 por mês, em quantos meses junto R$ 3.000?', [{ tipo: 'numero', valor: 12 }, { tipo: 'sem_escrita' }]),
  D('mat-divisao', 'matematica', 'Divisão com decimais', 'Quanto é 1250 dividido por 4?', [{ tipo: 'numero', valor: 312.5 }]),
  D('fin-categoria', 'financeiro', 'Soma por categoria', 'Quanto eu gastei com alimentação este mês?', [{ tipo: 'ferramenta', valor: 'get_finance' }, { tipo: 'numero', valor: 410.4 }, { tipo: 'sem_escrita' }], { dados: { get_finance: FIN } }),
  D('fin-gasto', 'financeiro', 'Registrar gasto com centavos', 'gastei 42,90 na farmácia', [{ tipo: 'ferramenta', valor: 'register_transaction', args: { kind: 'expense', amount: 42.9 } }]),
  D('fin-receita', 'financeiro', 'Receita x gasto', 'recebi 1.500 de um trabalho freelancer', [{ tipo: 'ferramenta', valor: 'register_transaction', args: { kind: 'income', amount: 1500 } }]),
  D('com-atraso', 'comunicacao', 'Aviso de atraso ao cliente', 'Escreva uma mensagem curta e educada para um cliente avisando que a entrega vai atrasar 2 dias.', [{ tipo: 'contem', valor: '2 dias|dois dias' }, { tipo: 'max_palavras', valor: 120 }, { tipo: 'naturalidade', valor: 70 }, { tipo: 'sem_escrita' }]),
  D('com-chefe', 'comunicacao', 'Pedido formal', 'Escreva um e-mail para o meu chefe pedindo para sair mais cedo na sexta por causa de uma consulta médica.', [{ tipo: 'contem', valor: 'sexta' }, { tipo: 'max_palavras', valor: 160 }, { tipo: 'naturalidade', valor: 70 }]),
  D('com-preco', 'comunicacao', 'Objeção de preço', 'Um cliente reclamou do preço. Como respondo sem dar desconto?', [{ tipo: 'nao_contem', valor: 'como assistente de ia|como uma ia' }, { tipo: 'naturalidade', valor: 70 }, { tipo: 'sem_escrita' }]),
  D('con-horario', 'contradicoes', 'Horário diferente do combinado', 'confirma minha reunião com o João às 16h amanhã', [{ tipo: 'pergunta' }, { tipo: 'contem', valor: '14' }], { historico: h('Agenda reunião com o João amanhã às 14h.', 'Pronto, agendei a reunião com o João para amanhã às 14h.') }),
  D('con-correcao', 'contradicoes', 'Correção de valor na mesma frase', 'Paguei a conta de luz de R$ 150, quer dizer, foram R$ 180. Registra o gasto.', [{ tipo: 'ferramenta', valor: 'register_transaction', args: { amount: 180 } }]),
  D('con-data', 'contradicoes', 'Data impossível', 'Me lembra da consulta no dia 30 de fevereiro.', [{ tipo: 'pergunta' }, { tipo: 'sem_escrita' }]),
  D('exe-tarefa', 'execucao', 'Criar tarefa', 'Cria uma tarefa: renovar a CNH até sexta.', [{ tipo: 'ferramenta', valor: 'create_task' }]),
  D('exe-compras', 'execucao', 'Lista de compras', 'Coloca leite, ovos e pão na lista de compras.', [{ tipo: 'ferramenta', valor: 'add_shopping_items' }]),
  D('exe-incompleto', 'execucao', 'Falta a data', 'Agenda uma reunião.', [{ tipo: 'pergunta' }, { tipo: 'sem_escrita' }]),
]

const desafioDe = (r: any): Desafio => ({ id: Number(r.id), slug: r.slug, categoria: r.category, titulo: r.title, prompt: r.prompt, contexto: J<Contexto>(r.context, {}), criterios: J<Criterio[]>(r.criteria, []), origem: r.origin === 'padrao' ? 'padrao' : 'personalizado', ativo: r.active === true || r.active === 1 || r.active === 't' })
/** Catálogo completo: padrão (código) + personalizados. Um personalizado com o mesmo slug de um padrão o substitui (cópia editada). */
export async function desafios(o: { todos?: boolean } = {}) {
  const rows = ((await q('SELECT * FROM lab_challenges ORDER BY id').catch(() => [])) as any[]).map(desafioDe)
  const porSlug = new Map(rows.map((d) => [d.slug, d]))
  const lista = [...DESAFIOS_PADRAO.map((d) => porSlug.get(d.slug) || { ...d, ativo: true }), ...rows.filter((d) => !DESAFIOS_PADRAO.some((p) => p.slug === d.slug))]
  return o.todos ? lista : lista.filter((d) => d.ativo !== false)
}
export function validarDesafio(b: any): Omit<Desafio, 'slug' | 'origem'> {
  const str = (v: any, min: number, max: number, campo: string, nome: string) => { const s = String(v ?? '').trim(); if (s.length < min || s.length > max) fail(400, `${nome}: de ${min} a ${max} caracteres.`, 'invalid', campo); return s }
  const categoria = String(b.categoria || ''); if (!CATEGORIAS[categoria]) fail(400, 'Categoria inválida.', 'invalid', 'categoria')
  const titulo = str(b.titulo, 3, 120, 'titulo', 'Título'), prompt = str(b.prompt, 3, 1500, 'prompt', 'Mensagem do usuário')
  const c = b.contexto || {}, historico = (Array.isArray(c.historico) ? c.historico : []).slice(0, 10).map((m: any) => ({ papel: m?.papel === 'assistente' ? 'assistente' : 'usuario', texto: String(m?.texto || '').trim().slice(0, 600) })).filter((m: any) => m.texto) as Contexto['historico']
  const memorias = (Array.isArray(c.memorias) ? c.memorias : []).map((m: any) => String(m || '').trim().slice(0, 300)).filter(Boolean).slice(0, 10)
  const dados: Record<string, any> = {}
  if (c.dados && typeof c.dados === 'object') for (const [k, v] of Object.entries(c.dados)) { if (!DADOS_PERMITIDOS.includes(k)) fail(400, `Consulta fictícia não permitida: ${k}.`, 'invalid', 'dados'); dados[k] = v }
  if (JSON.stringify(dados).length > 6000) fail(400, 'Dados fictícios grandes demais (máximo 6.000 caracteres).', 'invalid', 'dados')
  const criterios = (Array.isArray(b.criterios) ? b.criterios : []).slice(0, 10).map((x: any): Criterio => {
    const tipo = String(x?.tipo || '') as Criterio['tipo']; if (!TIPOS_CRITERIO[tipo]) fail(400, `Critério inválido: ${tipo}.`, 'invalid', 'criterios')
    const out: Criterio = { tipo }
    if (['contem', 'nao_contem'].includes(tipo)) out.valor = str(x.valor, 1, 200, 'criterios', 'Texto do critério')
    if (tipo === 'ferramenta') { out.valor = String(x.valor || ''); if (!/^[a-z_]{3,40}$/.test(out.valor)) fail(400, 'Nome de ferramenta inválido.', 'invalid', 'criterios'); if (x.args && typeof x.args === 'object') out.args = Object.fromEntries(Object.entries(x.args).slice(0, 5).map(([k, v]) => [String(k).slice(0, 40), typeof v === 'number' ? v : String(v).slice(0, 100)])) }
    if (['numero', 'itens', 'max_palavras', 'naturalidade'].includes(tipo)) { out.valor = Number(x.valor); if (!Number.isFinite(out.valor)) fail(400, 'O critério precisa de um número.', 'invalid', 'criterios') }
    return out
  })
  if (!criterios.length) fail(400, 'Inclua pelo menos um critério de avaliação.', 'invalid', 'criterios')
  exigirSintetico(titulo, prompt, ...(historico || []).map((m) => m.texto), ...memorias, JSON.stringify(dados))
  return { categoria, titulo, prompt, contexto: { historico, memorias, dados }, criterios }
}
export async function salvarDesafio(admin: SessionUser, b: any) {
  const v = validarDesafio(b), agora = nowIso()
  const slugBase = String(b.slug || '').trim()
  if (slugBase) { // edição: de um personalizado, ou cópia editada de um padrão
    const ex = await one('SELECT id FROM lab_challenges WHERE slug = $1', [slugBase])
    if (ex) { await q('UPDATE lab_challenges SET category = $1, title = $2, prompt = $3, context = $4, criteria = $5, updated_at = $6 WHERE id = $7', [v.categoria, v.titulo, v.prompt, JSON.stringify(v.contexto), JSON.stringify(v.criterios), agora, ex.id]); return { slug: slugBase } }
    if (!DESAFIOS_PADRAO.some((d) => d.slug === slugBase)) fail(404, 'Desafio não encontrado.', 'not_found')
    await q('INSERT INTO lab_challenges (slug, category, title, prompt, context, criteria, origin, active, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [slugBase, v.categoria, v.titulo, v.prompt, JSON.stringify(v.contexto), JSON.stringify(v.criterios), 'padrao', true, admin.id, agora])
    return { slug: slugBase }
  }
  const n = await one('SELECT COUNT(*) AS n FROM lab_challenges').catch(() => ({ n: 0 })); if (Number(n?.n || 0) >= 300) fail(409, 'Limite de 300 desafios personalizados.', 'limit')
  const slug = 'custom-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5)
  await q('INSERT INTO lab_challenges (slug, category, title, prompt, context, criteria, origin, active, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [slug, v.categoria, v.titulo, v.prompt, JSON.stringify(v.contexto), JSON.stringify(v.criterios), 'personalizado', true, admin.id, agora])
  return { slug }
}
export async function ativarDesafio(admin: SessionUser, slug: string, ativo: boolean) {
  const ex = await one('SELECT id FROM lab_challenges WHERE slug = $1', [slug])
  if (ex) { await q('UPDATE lab_challenges SET active = $1, updated_at = $2 WHERE id = $3', [ativo, nowIso(), ex.id]); return { ok: true } }
  const p = DESAFIOS_PADRAO.find((d) => d.slug === slug); if (!p) fail(404, 'Desafio não encontrado.', 'not_found')
  await q('INSERT INTO lab_challenges (slug, category, title, prompt, context, criteria, origin, active, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [slug, p!.categoria, p!.titulo, p!.prompt, JSON.stringify(p!.contexto), JSON.stringify(p!.criterios), 'padrao', ativo, admin.id, nowIso()])
  return { ok: true }
}

/* ======================= avaliação objetiva ======================= */
export function numerosDe(t: string): number[] {
  const out: number[] = []
  for (const m of String(t || '').matchAll(/\d[\d.,]*/g)) {
    const s = m[0].replace(/[.,]+$/, '')
    if (s.includes(',')) out.push(Number(s.replace(/\./g, '').replace(',', '.')))
    else if (/^\d{1,3}(\.\d{3})+$/.test(s)) out.push(Number(s.replace(/\./g, '')))
    else out.push(Number(s))
  }
  return out.filter(Number.isFinite)
}
const contemAlguma = (texto: string, alts: string) => alts.split('|').map((a) => nrm(a).trim()).filter(Boolean).some((a) => nrm(texto).includes(a))
const argsBatem = (args: any, esp: Record<string, any> = {}) => Object.entries(esp).every(([k, v]) => { const a = args?.[k]; if (typeof v === 'number') return Math.abs(Number(a) - v) < 0.011; return a != null && nrm(String(a)).includes(nrm(String(v))) })
export function descreverCriterio(c: Criterio) {
  const v = c.valor
  switch (c.tipo) {
    case 'contem': return `menciona “${String(v).split('|').join('” ou “')}”`
    case 'nao_contem': return `não menciona “${String(v).split('|').join('” nem “')}”`
    case 'ferramenta': return `usa ${v}${c.args ? ' com ' + Object.entries(c.args).map(([k, x]) => `${k}=${x}`).join(', ') : ''}`
    case 'numero': return `apresenta o número ${String(v).replace('.', ',')}`
    case 'itens': return `organiza em pelo menos ${v} itens`
    case 'max_palavras': return `no máximo ${v} palavras`
    case 'naturalidade': return `naturalidade ≥ ${v} (estimativa interna)`
    default: return TIPOS_CRITERIO[c.tipo] || c.tipo
  }
}
export async function avaliarCriterios(cr: Criterio[], prompt: string, resposta: string, calls: { name: string; args: any }[]) {
  const COG = await import('./cognition.js')
  const escritas = calls.filter((c) => !LEITURA.has(c.name)), out: { tipo: string; descricao: string; ok: boolean; detalhe?: string }[] = []
  for (const c of cr) {
    let ok = false, detalhe = ''
    switch (c.tipo) {
      case 'contem': ok = contemAlguma(resposta, String(c.valor)); break
      case 'nao_contem': ok = !contemAlguma(resposta, String(c.valor)); break
      case 'ferramenta': { const cs = calls.filter((x) => x.name === c.valor); ok = cs.some((x) => argsBatem(x.args, c.args)); if (!ok) detalhe = cs.length ? 'usou, mas com dados diferentes: ' + JSON.stringify(cs[0].args).slice(0, 160) : calls.length ? 'usou ' + calls.map((x) => x.name).join(', ') : 'nenhuma ferramenta'; break }
      case 'sem_escrita': ok = !escritas.length; if (!ok) detalhe = 'tentou gravar: ' + escritas.map((x) => x.name).join(', '); break
      case 'pergunta': ok = /\?/.test(resposta) && !escritas.length; if (!ok) detalhe = escritas.length ? 'agiu sem perguntar' : 'não perguntou'; break
      case 'numero': ok = numerosDe(resposta).some((n) => Math.abs(n - Number(c.valor)) < 0.011); break
      case 'itens': { const n = (resposta.match(/^\s*(\d+[.)º°-]|[-•*▪︎●])\s+\S/gm) || []).length; ok = n >= Number(c.valor); detalhe = `${n} item(ns)`; break }
      case 'max_palavras': { const n = resposta.split(/\s+/).filter(Boolean).length; ok = n <= Number(c.valor); detalhe = `${n} palavras`; break }
      case 'naturalidade': { const n = COG.avaliar({ texto: prompt, resposta, analise: COG.analisar(prompt) }).naturalidade; ok = n >= Number(c.valor); detalhe = `nota ${n}`; break }
    }
    out.push({ tipo: c.tipo, descricao: descreverCriterio(c), ok, ...(detalhe ? { detalhe } : {}) })
  }
  return out
}

/* ======================= variantes (atual × experimental) ======================= */
export interface Variante { nome?: string; tipo?: string; mudancas?: POL.Mudanca[]; instrucoes?: string; agentes?: number[] }
export interface VarMontada { nome: string; politica: POL.Politica; instrucoes: string; agentes: Agente[]; descricao: string[]; experimental: boolean }
export async function montarVariante(v: Variante | null): Promise<VarMontada> {
  const LA = await import('./laboratorio-agentes.js'), cfg = await POL.aprCfg(true), base = await POL.versao(cfg.versaoAtiva), pub = await LA.publicadosPara(0, true)
  if (!v) return { nome: 'Versão atual', politica: base, instrucoes: '', agentes: pub, descricao: ['Política, regras e especialistas em produção (sem liberações graduais).'], experimental: false }
  let pol = base
  const mud = (Array.isArray(v.mudancas) ? v.mudancas : []).slice(0, 5)
  for (const m of mud) pol = POL.aplicarMudanca(pol, m) // só a lista fechada de parâmetros (valida e recusa o resto)
  const instr = String(v.instrucoes || '').trim().slice(0, 1500)
  if (instr) { const L = await import('./lab.js'); const r = L.riscosDe(instr); if (r.length) fail(400, r.join(' '), 'risco'); exigirSintetico(instr) }
  const extras = Array.isArray(v.agentes) && v.agentes.length ? await LA.paraVariante(v.agentes.slice(0, 5).map(Number)) : []
  const agentes = [...pub.filter((p) => !extras.some((e) => e.id === p.id)), ...extras]
  if (!mud.length && !instr && !extras.length) fail(400, 'A variante experimental não muda nada: inclua instruções, um especialista ou um ajuste de parâmetro.', 'invalid')
  return { nome: String(v.nome || 'Versão experimental').slice(0, 80), politica: pol, instrucoes: instr, agentes, experimental: true,
    descricao: [...POL.diferencas(base, pol), ...(instr ? ['Instruções novas: ' + instr.slice(0, 160)] : []), ...extras.map((a) => `Especialista: ${a.nome} (v${(a as any).versaoLab})`)] }
}

/* ======================= execução isolada de um caso ======================= */
export interface Caso { slug: string; categoria: string; titulo: string; ok: boolean; nota: number; criterios: { tipo: string; descricao: string; ok: boolean; detalhe?: string }[]; resposta: string; acoes: { ferramenta: string; leitura: boolean; dados: any }[]; caminho: string; ms: number; erro?: string; qualidade?: any; agentes?: any[]; especialista?: string }
export async function executarCaso(d: Desafio, V: VarMontada, o: { trace?: boolean } = {}): Promise<Caso & { trace?: any }> {
  const t0 = Date.now(), { runAssistant } = await import('./assistant.js'), COG = await import('./cognition.js')
  const sb = { calls: [] as { name: string; args: any }[], extraRules: V.instrucoes || undefined, memorias: d.contexto.memorias || [], dados: d.contexto.dados || {}, agentes: V.agentes, trace: {} as any }
  const hist = (d.contexto.historico || []).map((m) => ({ role: m.papel === 'assistente' ? 'assistant' : 'user', content: m.texto })) as any[]
  let resposta = '', erro = '', caminho = 'ia', cog: any = null
  const conta: any = (await import('../lib/math.js')).solveMath(d.prompt) // mesma etapa determinística do chat: conta nunca vai para a IA
  if (conta) { resposta = String(conta.texto || conta.erro || ''); caminho = 'motor matemático' }
  else {
    try { const r = await POL.comPolitica(V.politica, () => runAssistant(USUARIO_LAB, hist, d.prompt, undefined, '', undefined, sb as any, '')); resposta = String(r.content || ''); cog = (r as any).cog || null }
    catch (e: any) { erro = String(e?.message || 'A IA não respondeu.').slice(0, 200) }
  }
  const criterios = erro ? d.criterios.map((c) => ({ tipo: c.tipo, descricao: descreverCriterio(c), ok: false, detalhe: 'sem resposta' })) : await avaliarCriterios(d.criterios, d.prompt, resposta, sb.calls)
  const okN = criterios.filter((c) => c.ok).length, nota = criterios.length ? Math.round((okN / criterios.length) * 100) : 0
  const ql = resposta ? COG.avaliar({ texto: d.prompt, resposta, analise: COG.analisar(d.prompt, hist) }) : null
  const out: Caso & { trace?: any } = { slug: d.slug, categoria: d.categoria, titulo: d.titulo, ok: !erro && okN === criterios.length, nota, criterios, resposta: resposta.slice(0, 1500), acoes: sb.calls.slice(0, 10).map((c) => ({ ferramenta: c.name, leitura: LEITURA.has(c.name), dados: c.args })), caminho, ms: Date.now() - t0,
    ...(erro ? { erro } : {}), qualidade: ql ? { geral: ql.geral, naturalidade: ql.naturalidade, clareza: ql.clareza, estimativa: true } : null, agentes: sb.trace.orquestracao?.agentes || [], especialista: cog?.n2?.especialistas?.[0] || undefined }
  if (o.trace) out.trace = { orquestracao: sb.trace.orquestracao || null, cog }
  return out
}
export function resumir(casos: Caso[]) {
  const porCategoria: Record<string, { nome: string; total: number; aprovados: number; nota: number }> = {}
  for (const c of casos) { const x = (porCategoria[c.categoria] ||= { nome: CATEGORIAS[c.categoria] || c.categoria, total: 0, aprovados: 0, nota: 0 }); x.total++; if (c.ok) x.aprovados++; x.nota += c.nota }
  for (const x of Object.values(porCategoria)) x.nota = Math.round(x.nota / x.total)
  return { total: casos.length, aprovados: casos.filter((c) => c.ok).length, nota: casos.length ? Math.round(casos.reduce((a, c) => a + c.nota, 0) / casos.length) : 0, msMedio: casos.length ? Math.round(casos.reduce((a, c) => a + c.ms, 0) / casos.length) : 0, porCategoria }
}
export function comparar(atual: Caso[], exp: Caso[]) {
  const pares = atual.map((a) => ({ a, b: exp.find((x) => x.slug === a.slug)! })).filter((p) => p.b)
  const ra = resumir(atual), rb = resumir(exp), delta = rb.nota - ra.nota
  const regressoes = pares.filter((p) => p.a.ok && !p.b.ok).map((p) => ({ slug: p.a.slug, titulo: p.a.titulo, categoria: p.a.categoria }))
  const melhorias = pares.filter((p) => !p.a.ok && p.b.ok).map((p) => ({ slug: p.a.slug, titulo: p.a.titulo, categoria: p.a.categoria }))
  const categorias = Object.keys({ ...ra.porCategoria, ...rb.porCategoria }).map((k) => ({ id: k, nome: CATEGORIAS[k] || k, atual: ra.porCategoria[k]?.nota ?? null, experimental: rb.porCategoria[k]?.nota ?? null }))
  return { atual: ra, experimental: rb, delta, regressoes, melhorias, categorias, conclusao: regressoes.length && delta <= 0 ? 'pior' : delta >= 5 && !regressoes.length ? 'melhor' : delta <= -5 ? 'pior' : 'equivalente',
    observacao: 'As respostas da IA variam um pouco de uma execução para outra: para decidir, prefira rodadas com repetições e diferenças de 5 pontos ou mais.' }
}

/* ======================= rodadas em segundo plano ======================= */
const CORRENDO = new Set<number>()
export const rodando = () => [...CORRENDO]
const ler = (r: any) => r && ({ id: Number(r.id), tipo: r.kind, rotulo: r.label, config: J<any>(r.config, {}), resultados: J<any>(r.results, {}), nota: r.score == null ? null : Number(r.score), total: Number(r.total), aprovados: Number(r.passed), estado: r.status, progresso: Number(r.progress), agenda: r.schedule_id == null ? null : Number(r.schedule_id), por: r.started_by == null ? null : Number(r.started_by), criadaEm: String(r.created_at), concluidaEm: r.finished_at ? String(r.finished_at) : null })
async function marcarInterrompidas() {
  const velhas = (await q("SELECT id, created_at FROM lab_runs WHERE status = 'executando'").catch(() => [])) as any[]
  for (const r of velhas) if (!CORRENDO.has(Number(r.id)) && Date.now() - Date.parse(String(r.created_at)) > 30 * 60_000) await q("UPDATE lab_runs SET status = 'interrompida', finished_at = $1 WHERE id = $2 AND status = 'executando'", [nowIso(), r.id]).catch(() => {})
}
export async function iniciarRodada(o: { tipo: 'arena' | 'continuo' | 'experimento'; rotulo: string; desafios: Desafio[]; variante?: Variante | null; repeticoes?: number; por: number | null; agenda?: number | null }) {
  const cfg = await labCfg(); if (!cfg.ativo) fail(409, 'O Laboratório está desligado no painel.', 'disabled')
  await marcarInterrompidas()
  const em = Number((await one("SELECT COUNT(*) AS n FROM lab_runs WHERE status = 'executando' AND kind IN ('arena','continuo','experimento')"))?.n || 0)
  if (em >= cfg.maxSimultaneas) fail(429, `Já há ${em} rodada(s) em andamento. Aguarde terminar.`, 'busy')
  const lista = o.desafios.slice(0, cfg.maxDesafios); if (!lista.length) fail(400, 'Escolha pelo menos um desafio.', 'invalid')
  const rep = Math.max(1, Math.min(3, Math.round(Number(o.repeticoes) || 1)))
  const varExp = o.tipo === 'experimento' ? await montarVariante(o.variante || null) : null // valida ANTES de criar a rodada
  if (o.tipo === 'experimento' && (!varExp || !varExp.experimental)) fail(400, 'Defina a versão experimental.', 'invalid')
  const config = { desafios: lista.map((d) => d.slug), repeticoes: rep, variante: o.tipo === 'experimento' ? { ...o.variante, descricao: varExp!.descricao } : null, isolamento: 'usuário sintético · dados fictícios · ferramentas simuladas' }
  const r = await one('INSERT INTO lab_runs (kind, label, config, results, total, passed, status, progress, schedule_id, started_by, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id',
    [o.tipo, o.rotulo.slice(0, 120), JSON.stringify(config), '{}', lista.length, 0, 'executando', 0, o.agenda ?? null, o.por, nowIso()])
  const id = Number(r!.id)
  void processar(id, o.tipo, lista, varExp, rep).catch((e) => console.error('[laboratório] rodada', id, e?.message))
  return id
}
async function rodarN(d: Desafio, V: VarMontada, n: number): Promise<Caso> {
  const xs: Caso[] = []; for (let i = 0; i < n; i++) xs.push(await executarCaso(d, V))
  if (n === 1) return xs[0]
  const nota = Math.round(xs.reduce((a, c) => a + c.nota, 0) / n), ok = xs.filter((c) => c.ok).length * 2 > n
  return { ...xs[0], nota, ok, ms: Math.round(xs.reduce((a, c) => a + c.ms, 0) / n), repeticoes: xs.map((c) => ({ ok: c.ok, nota: c.nota })) } as any
}
async function processar(id: number, tipo: string, lista: Desafio[], varExp: VarMontada | null, rep: number) {
  CORRENDO.add(id)
  try {
    const atual = await montarVariante(null), A: Caso[] = [], B: Caso[] = []
    for (const [i, d] of lista.entries()) {
      const st = await one('SELECT status FROM lab_runs WHERE id = $1', [id]); if (st?.status !== 'executando') return // interrompida pelo administrador
      A.push(await rodarN(d, atual, rep))
      if (varExp) B.push(await rodarN(d, varExp, rep))
      const parcial = varExp ? { atual: A, experimental: B } : { casos: A }
      await q('UPDATE lab_runs SET progress = $1, passed = $2, results = $3 WHERE id = $4', [Math.round(((i + 1) / lista.length) * 100), (varExp ? B : A).filter((c) => c.ok).length, JSON.stringify(parcial), id])
    }
    const resultados = varExp ? { atual: A, experimental: B, comparacao: comparar(A, B) } : { casos: A, resumo: resumir(A) }
    const fim = varExp ? resumir(B) : resumir(A)
    await q("UPDATE lab_runs SET status = 'concluida', progress = 100, score = $1, passed = $2, results = $3, finished_at = $4 WHERE id = $5 AND status = 'executando'", [fim.nota, fim.aprovados, JSON.stringify(resultados), nowIso(), id])
    if (tipo === 'continuo') await aposContinuo(id).catch((e) => console.error('[laboratório] relatório contínuo:', e?.message))
  } catch (e: any) {
    await q("UPDATE lab_runs SET status = 'falhou', results = $1, finished_at = $2 WHERE id = $3", [JSON.stringify({ erro: String(e?.message || e).slice(0, 300) }), nowIso(), id]).catch(() => {})
  } finally { CORRENDO.delete(id) }
}
export async function rodada(id: number) { await marcarInterrompidas(); const r = await one('SELECT * FROM lab_runs WHERE id = $1', [id]); if (!r) fail(404, 'Rodada não encontrada.', 'not_found'); return ler(r) }
export async function rodadas(tipos: string[], limite = 30) {
  await marcarInterrompidas()
  const rows = (await q(`SELECT id, kind, label, config, score, total, passed, status, progress, schedule_id, started_by, created_at, finished_at FROM lab_runs WHERE kind IN (${tipos.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY id DESC LIMIT ${Math.max(1, Math.min(200, limite))}`, tipos).catch(() => [])) as any[]
  return rows.map((r) => ({ ...ler({ ...r, results: '{}' }), resultados: undefined }))
}
export async function interromper(id: number) {
  const r = await q("UPDATE lab_runs SET status = 'interrompida', finished_at = $1 WHERE id = $2 AND status = 'executando'", [nowIso(), id]) as any
  void r; return rodada(id)
}
/** Arena: rodada com os desafios escolhidos (todos os ativos, por categoria ou por slug). */
export async function iniciarArena(admin: SessionUser, b: { categorias?: string[]; slugs?: string[]; rotulo?: string; repeticoes?: number }) {
  const todos = await desafios(), cats = Array.isArray(b.categorias) ? b.categorias.filter((c) => CATEGORIAS[c]) : [], slugs = Array.isArray(b.slugs) ? b.slugs.map(String) : []
  const lista = todos.filter((d) => (!cats.length || cats.includes(d.categoria)) && (!slugs.length || slugs.includes(d.slug)))
  return iniciarRodada({ tipo: 'arena', rotulo: String(b.rotulo || (cats.length === 1 ? 'Arena · ' + CATEGORIAS[cats[0]] : slugs.length === 1 ? 'Arena · ' + (lista[0]?.titulo || '') : 'Arena · todos os desafios')), desafios: lista, repeticoes: b.repeticoes, por: admin.id })
}
export async function iniciarExperimento(admin: SessionUser, b: { variante: Variante; categorias?: string[]; slugs?: string[]; rotulo?: string; repeticoes?: number }) {
  const todos = await desafios(), cats = Array.isArray(b.categorias) ? b.categorias.filter((c) => CATEGORIAS[c]) : [], slugs = Array.isArray(b.slugs) ? b.slugs.map(String) : []
  const lista = todos.filter((d) => (!cats.length || cats.includes(d.categoria)) && (!slugs.length || slugs.includes(d.slug)))
  return iniciarRodada({ tipo: 'experimento', rotulo: String(b.rotulo || b.variante?.nome || 'Experimento').slice(0, 120), desafios: lista, variante: b.variante, repeticoes: b.repeticoes, por: admin.id })
}

/* ======================= transformar um experimento em proposta (fluxos de aprovação existentes) ======================= */
const KIND_DO_CAMINHO = (c: string) => (c.startsWith('raciocinio') ? 'raciocinio' : c.startsWith('memoria') ? 'memoria' : c.startsWith('agentes') ? 'agentes' : c.startsWith('ferramentas') ? 'ferramentas' : c.startsWith('preditivo') ? 'proatividade' : 'qualidade')
export async function propostaDoExperimento(admin: SessionUser, runId: number) {
  const r = await rodada(runId); if (r.tipo !== 'experimento' || r.estado !== 'concluida') fail(409, 'Só um experimento concluído vira proposta.', 'invalid_state')
  const v = r.config.variante || {}, cmp = r.resultados.comparacao, mud = Array.isArray(v.mudancas) ? v.mudancas : []
  const evid = { laboratorio: runId, notaAtual: cmp?.atual?.nota, notaExperimental: cmp?.experimental?.nota, regressoes: cmp?.regressoes?.length || 0 }
  const criadas: any[] = []
  if (mud.length) { // parâmetro da política → Fase 6 (teste isolado próprio, aprovação, liberação gradual, vigilância e reversão)
    if (mud.length > 1) fail(400, 'Para virar proposta, o experimento deve mudar um parâmetro por vez (assim a reversão é exata).', 'invalid')
    const m = mud[0], cfg = await POL.aprCfg(true), base = await POL.versao(cfg.versaoAtiva); POL.aplicarMudanca(base, m)
    const kind = KIND_DO_CAMINHO(String(m.caminho)), fp = `${kind}|${JSON.stringify(m)}`
    const ja = await one("SELECT id FROM learning_proposals WHERE fingerprint = $1 AND status IN ('proposta','testada','reprovada','gradual','ativa')", [fp]).catch(() => null)
    let pid = ja ? Number(ja.id) : 0
    if (!pid) {
      const ins = await one('INSERT INTO learning_proposals (kind, title, rationale, evidence, change, fingerprint, status, created_by, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10) RETURNING id',
        [kind, String(v.nome || 'Ajuste vindo do Laboratório').slice(0, 160), `Experimento #${runId} no Laboratório: nota ${evid.notaAtual} (atual) → ${evid.notaExperimental} (experimental), ${evid.regressoes} regressão(ões).`, JSON.stringify(evid), JSON.stringify(m), fp, 'proposta', 'laboratorio', JSON.stringify([{ em: nowIso(), para: 'proposta', por: admin.name || 'administrador', nota: `criada a partir do experimento #${runId}` }]), nowIso()])
      pid = Number(ins!.id)
      await (await import('./aprendizado.js')).experimentar(pid, admin).catch(() => null) // os testes isolados da Fase 6 também precisam passar
    }
    criadas.push({ origem: 'politica', id: pid })
    await anotarMelhoria('politica', pid, { test_result: JSON.stringify({ laboratorio: runId, comparacao: resumoCmp(cmp) }) })
  }
  if (v.instrucoes) { // instruções → regra no Laboratório de IA (análise de conflitos, simulação, aprovação e publicação)
    const L = await import('./lab.js'), nid = await L.criar(`admin ${admin.id}`, admin.id, { regra: String(v.instrucoes), titulo: String(v.nome || 'Instrução vinda do Laboratório').slice(0, 90), falha: `Experimento #${runId}: nota ${evid.notaAtual} → ${evid.notaExperimental}.` } as any)
    await L.analisar(nid, `admin ${admin.id}`).catch(() => null)
    criadas.push({ origem: 'regra', id: nid })
    await anotarMelhoria('regra', nid, { test_result: JSON.stringify({ laboratorio: runId, comparacao: resumoCmp(cmp) }) })
  }
  if (Array.isArray(v.agentes) && v.agentes.length) { // especialistas → o próprio teste conta para a aprovação deles
    const LA = await import('./laboratorio-agentes.js')
    for (const aid of v.agentes) { await LA.registrarTeste(Number(aid), { tipo: 'experimento', rodada: runId, ...resumoCmp(cmp) }).catch(() => null); criadas.push({ origem: 'agente', id: Number(aid) }) }
  }
  if (!criadas.length) fail(400, 'Este experimento não tem o que propor.', 'invalid')
  return { ok: true, criadas }
}
const resumoCmp = (c: any) => c ? { notaAtual: c.atual?.nota, notaExperimental: c.experimental?.nota, delta: c.delta, regressoes: (c.regressoes || []).length, melhorias: (c.melhorias || []).length, conclusao: c.conclusao } : null
/** Anotação na Central de Melhorias (edição de texto, arquivamento, resultado de testes) sem tocar na tabela do módulo de origem. */
export async function anotarMelhoria(origem: string, sourceId: number | null, campos: Record<string, any>, por = 'sistema', nota = '') {
  const ex = sourceId != null ? await one('SELECT id, history FROM lab_improvements WHERE source = $1 AND source_id = $2', [origem, sourceId]) : null
  const agora = nowIso(), hist = (h: any) => JSON.stringify([...J<any[]>(h, []), ...(nota ? [{ em: agora, por, nota: nota.slice(0, 200) }] : [])].slice(-50))
  if (ex) { const ks = Object.keys(campos); await q(`UPDATE lab_improvements SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')}, history = $${ks.length + 1}, updated_at = $${ks.length + 2} WHERE id = $${ks.length + 3}`, [...ks.map((k) => campos[k]), hist(ex.history), agora, ex.id]); return Number(ex.id) }
  const cols = { source: origem, source_id: sourceId, created_by: por, history: hist('[]'), created_at: agora, updated_at: agora, ...campos }, ks = Object.keys(cols)
  const r = await one(`INSERT INTO lab_improvements (${ks.join(', ')}) VALUES (${ks.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING id`, ks.map((k) => (cols as any)[k]))
  return Number(r!.id)
}

/* ======================= simulador de conversas ======================= */
export async function analisarTurno(o: { texto: string; hist: any[]; resposta: string; calls: { name: string; args: any }[]; trace: any; memorias: string[]; dados: any; cog?: any }) {
  const COG = await import('./cognition.js'), ESP = await import('./especialistas.js'), AV = await import('./autoverificacao.js'), AVAL = await import('./avaliacao.js'), L = await import('./lab.js')
  const an = COG.analisar(o.texto, o.hist), sel = ESP.selecionar(o.texto, an, AVAL.FERRAMENTAS_TESTE as any)
  const escritas = o.calls.filter((c) => !LEITURA.has(c.name)), perguntou = /\?/.test(o.resposta)
  const ambigua = an.faltando.length > 0 || an.ambiguidades.length > 0 || an.contradicoes.length > 0
  const usadas = o.memorias.filter((m) => { const ws = nrm(m).split(/[^a-z0-9]+/).filter((w) => w.length >= 4 && !['usuario', 'prefere', 'gosta'].includes(w)); return ws.some((w) => nrm(o.resposta).includes(w)) })
  const fontes = JSON.stringify(o.dados || {}) + ' ' + o.texto + ' ' + o.hist.map((m) => m.content).join(' ') + ' ' + o.memorias.join(' ')
  const divergentes = AV.valoresDivergentes(o.resposta, fontes)
  const problemas = L.avaliar(o.texto, o.calls, o.resposta, '', []).filter((p) => p.tipo !== 'incompleta')
  // valor dito pelo usuário (sem "R$") que não aparece em nenhuma ação de gravação
  const ditos = [...String(o.texto).matchAll(/\d[\d.,]*(?!\s*(h\b|hs\b|horas?|min|:|\/|%))/gi)].flatMap((m) => numerosDe(m[0])).filter((n) => n >= 1)
  const nosArgs = numerosDe(JSON.stringify(escritas.map((c) => c.args)).replace(/"(\d+)\.(\d+)"/g, '"$1,$2"')).concat(escritas.flatMap((c) => Object.values(c.args || {}).filter((v) => typeof v === 'number') as number[]))
  if (escritas.length && ditos.length && !problemas.some((p) => p.tipo === 'informacao_ignorada') && !ditos.some((n) => nosArgs.some((a) => Math.abs(a - n) < 0.011)))
    problemas.push({ tipo: 'informacao_ignorada', mensagem: `O valor ${ditos.map((n) => String(n).replace('.', ',')).join(', ')} informado pelo usuário não aparece na ação que a IA tentaria gravar.`, sugestao: 'Use exatamente o valor que o usuário informou.' })
  const rev = COG.revisarResposta(o.resposta, { exec: COG.resumirExec(o.calls.map((c) => ({ name: c.name, result: { ok: true } })), LEITURA, []) })
  const ql = COG.avaliar({ texto: o.texto, resposta: o.resposta, analise: an, hist: o.hist })
  return {
    interpretacao: { tipo: an.tipo, completude: an.completude, registro: an.registro, emocao: an.emocao, etapas: an.etapas, operacoes: an.operacoes, referencia: an.referenciaProvavel || null },
    ambiguidade: { detectada: ambigua, faltando: an.faltando, ambiguidades: an.ambiguidades, contradicoes: an.contradicoes, tratada: ambigua ? perguntou && !escritas.length : null },
    memoria: { disponiveis: o.memorias.length, usadas },
    especialistas: { principal: sel.principal, nomes: sel.nomes },
    agentes: o.trace?.orquestracao ? { complexidade: o.trace.orquestracao.complexidade?.nivel, consultados: (o.trace.orquestracao.agentes || []).map((a: any) => ({ id: a.id, nome: a.nome, ok: a.ok, ms: a.ms, motivo: a.motivo })), divergencias: o.trace.orquestracao.divergencias || [] } : { complexidade: 'simples', consultados: [], divergencias: [] },
    ferramentas: o.calls.map((c) => ({ ferramenta: c.name, leitura: LEITURA.has(c.name), dados: c.args })),
    precisao: { valoresSemFonte: divergentes, problemas: problemas.map((p) => ({ tipo: p.tipo, mensagem: p.mensagem })), ajustesDaRevisao: rev.ajustes, ok: !divergentes.length && !problemas.length },
    qualidade: { geral: ql.geral, precisao: ql.precisao, naturalidade: ql.naturalidade, clareza: ql.clareza, contexto: ql.contexto, estimativa: true },
  }
}
export async function simular(admin: SessionUser, b: { sessao?: number; texto: string; memorias?: string[]; dados?: any; variante?: Variante | null }) {
  const cfg = await labCfg(); if (!cfg.ativo) fail(409, 'O Laboratório está desligado no painel.', 'disabled')
  const texto = String(b.texto || '').trim(); if (texto.length < 1 || texto.length > 1500) fail(400, 'Escreva a mensagem (até 1.500 caracteres).', 'invalid', 'texto')
  exigirSintetico(texto)
  let sid = Number(b.sessao || 0), sess: any = null
  if (sid) { sess = await one("SELECT * FROM lab_runs WHERE id = $1 AND kind = 'simulacao' AND started_by = $2", [sid, admin.id]); if (!sess) fail(404, 'Simulação não encontrada.', 'not_found') }
  else {
    const v = validarDesafio({ categoria: 'contexto', titulo: 'Simulação', prompt: texto, contexto: { memorias: b.memorias || [], dados: b.dados || {} }, criterios: [{ tipo: 'sem_escrita' }] })
    if (b.variante) await montarVariante(b.variante) // valida
    const r = await one('INSERT INTO lab_runs (kind, label, config, results, total, passed, status, progress, started_by, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id',
      ['simulacao', ('Simulação · ' + texto).slice(0, 120), JSON.stringify({ memorias: v.contexto.memorias, dados: v.contexto.dados, variante: b.variante || null }), JSON.stringify({ turnos: [] }), 0, 0, 'concluida', 100, admin.id, nowIso()])
    sid = Number(r!.id); sess = await one('SELECT * FROM lab_runs WHERE id = $1', [sid])
  }
  const conf = J<any>(sess.config, {}), res = J<any>(sess.results, { turnos: [] }), turnos: any[] = res.turnos || []
  if (turnos.length >= 20) fail(409, 'Limite de 20 mensagens por simulação. Comece outra.', 'limit')
  const hist = turnos.flatMap((t) => [{ role: 'user', content: t.texto }, { role: 'assistant', content: t.resposta }])
  const V = await montarVariante(conf.variante || null)
  const d: Desafio = { slug: 'sim', categoria: 'contexto', titulo: 'Simulação', prompt: texto, contexto: { historico: hist.map((m) => ({ papel: m.role === 'assistant' ? 'assistente' : 'usuario', texto: String(m.content) })), memorias: conf.memorias || [], dados: conf.dados || {} }, criterios: [], origem: 'personalizado' }
  const c = await executarCaso(d, V, { trace: true })
  const analise = c.erro ? null : await analisarTurno({ texto, hist, resposta: c.resposta, calls: c.acoes.map((a) => ({ name: a.ferramenta, args: a.dados })), trace: c.trace, memorias: conf.memorias || [], dados: conf.dados || {}, cog: c.trace?.cog })
  const turno = { n: turnos.length + 1, texto, resposta: c.resposta, erro: c.erro || null, caminho: c.caminho, ms: c.ms, analise, em: nowIso() }
  turnos.push(turno)
  await q('UPDATE lab_runs SET results = $1, total = $2 WHERE id = $3', [JSON.stringify({ turnos }), turnos.length, sid])
  return { sessao: sid, variante: V.nome, turno, semEfeitoReal: true }
}
export async function simulacoes(admin: SessionUser) {
  return ((await q("SELECT id, label, total, created_at FROM lab_runs WHERE kind = 'simulacao' AND started_by = $1 ORDER BY id DESC LIMIT 20", [admin.id]).catch(() => [])) as any[]).map((r) => ({ id: Number(r.id), rotulo: r.label, mensagens: Number(r.total), em: String(r.created_at) }))
}
export async function simulacao(admin: SessionUser, id: number) {
  const r = await one("SELECT * FROM lab_runs WHERE id = $1 AND kind = 'simulacao' AND started_by = $2", [id, admin.id]); if (!r) fail(404, 'Simulação não encontrada.', 'not_found')
  return { id, config: J<any>(r!.config, {}), turnos: J<any>(r!.results, {}).turnos || [] }
}

/* ======================= desafios contínuos ======================= */
const agendaDe = (r: any) => ({ id: Number(r.id), nome: r.name, categorias: J<string[]>(r.categories, []), horas: Number(r.every_hours), ativa: r.active === true || r.active === 1 || r.active === 't', ultimaRodada: r.last_run_id == null ? null : Number(r.last_run_id), proxima: String(r.next_run_at), criadaEm: String(r.created_at) })
export async function agendas() { return ((await q('SELECT * FROM lab_schedules ORDER BY id').catch(() => [])) as any[]).map(agendaDe) }
export async function salvarAgenda(admin: SessionUser, b: any) {
  const nome = String(b.nome || '').trim().slice(0, 80); if (nome.length < 3) fail(400, 'Dê um nome à avaliação (mín. 3 caracteres).', 'invalid', 'nome')
  const horas = Math.round(Number(b.horas)); if (!(horas >= 6 && horas <= 168)) fail(400, 'Frequência: de 6 em 6 horas até uma vez por semana (168 h).', 'invalid', 'horas')
  const cats = (Array.isArray(b.categorias) ? b.categorias : []).map(String).filter((c: string) => CATEGORIAS[c])
  const agora = nowIso(), id = Number(b.id || 0)
  if (id) { const ex = await one('SELECT id FROM lab_schedules WHERE id = $1', [id]); if (!ex) fail(404, 'Avaliação não encontrada.', 'not_found'); await q('UPDATE lab_schedules SET name = $1, categories = $2, every_hours = $3, active = $4, updated_at = $5 WHERE id = $6', [nome, JSON.stringify(cats), horas, b.ativa !== false, agora, id]); return id }
  if (Number((await one('SELECT COUNT(*) AS n FROM lab_schedules'))?.n || 0) >= 10) fail(409, 'Limite de 10 avaliações programadas.', 'limit')
  const r = await one('INSERT INTO lab_schedules (name, categories, every_hours, active, next_run_at, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING id', [nome, JSON.stringify(cats), horas, true, new Date(Date.now() + horas * 3600_000).toISOString(), admin.id, agora])
  void admin; return Number(r!.id)
}
export async function excluirAgenda(id: number) { await q('DELETE FROM lab_schedules WHERE id = $1', [id]); return { ok: true } }
export async function rodarAgenda(id: number, por: number | null) {
  const a = await one('SELECT * FROM lab_schedules WHERE id = $1', [id]); if (!a) fail(404, 'Avaliação não encontrada.', 'not_found')
  const ag = agendaDe(a), todos = await desafios(), lista = todos.filter((d) => !ag.categorias.length || ag.categorias.includes(d.categoria))
  const rid = await iniciarRodada({ tipo: 'continuo', rotulo: 'Contínuo · ' + ag.nome, desafios: lista, por, agenda: id })
  await q('UPDATE lab_schedules SET last_run_id = $1, next_run_at = $2, updated_at = $3 WHERE id = $4', [rid, new Date(Date.now() + ag.horas * 3600_000).toISOString(), nowIso(), id])
  return rid
}
/** Chamado periodicamente pelo servidor: roda as avaliações vencidas (uma de cada vez; nunca duas da mesma agenda). */
export async function rodarAgendadas() {
  const cfg = await labCfg(); if (!cfg.ativo || !cfg.continuo) return { rodou: [] as number[] }
  const vencidas = ((await q('SELECT * FROM lab_schedules WHERE active = $1 AND next_run_at <= $2 ORDER BY next_run_at LIMIT 3', [true, nowIso()]).catch(() => [])) as any[])
  const rodou: number[] = []
  for (const a of vencidas) {
    const emCurso = await one("SELECT id FROM lab_runs WHERE schedule_id = $1 AND status = 'executando'", [a.id]).catch(() => null); if (emCurso) continue
    try { rodou.push(await rodarAgenda(Number(a.id), null)) } catch (e: any) { if (e?.code !== 'busy') console.error('[laboratório] contínuo:', e?.message); break }
  }
  void (await import('./laboratorio-agentes.js')).vigiarAgentes().catch((e) => console.error('[laboratório] agentes:', e?.message))
  return { rodou }
}
/** Relatório comparativo: esta rodada × a anterior da mesma avaliação; queda relevante avisa os administradores. */
export async function comparativo(agendaId: number) {
  const runs = ((await q("SELECT id, score, results, created_at FROM lab_runs WHERE schedule_id = $1 AND status = 'concluida' ORDER BY id DESC LIMIT 30", [agendaId]).catch(() => [])) as any[])
  const serie = runs.map((r) => { const res = J<any>(r.results, {}); return { id: Number(r.id), em: String(r.created_at), nota: Number(r.score), porCategoria: Object.fromEntries(Object.entries(res.resumo?.porCategoria || {}).map(([k, v]: any) => [k, v.nota])), aprovados: res.resumo?.aprovados ?? null, total: res.resumo?.total ?? null } }).reverse()
  const ult = serie[serie.length - 1], ant = serie[serie.length - 2]
  const quedas = ult && ant ? Object.keys(ult.porCategoria).filter((k) => ant.porCategoria[k] != null && ant.porCategoria[k] - ult.porCategoria[k] >= 20).map((k) => ({ categoria: k, nome: CATEGORIAS[k] || k, de: ant.porCategoria[k], para: ult.porCategoria[k] })) : []
  const regressao = !!(ult && ant && (ant.nota - ult.nota >= 10 || quedas.length))
  const tendencia = serie.length >= 3 ? (ult.nota - serie[0].nota >= 5 ? 'melhorando' : serie[0].nota - ult.nota >= 5 ? 'piorando' : 'estável') : 'poucos dados'
  return { serie, ultima: ult || null, anterior: ant || null, delta: ult && ant ? ult.nota - ant.nota : null, quedas, regressao, tendencia }
}
async function aposContinuo(runId: number) {
  const r = await one('SELECT schedule_id FROM lab_runs WHERE id = $1', [runId]); if (!r?.schedule_id) return
  const c = await comparativo(Number(r.schedule_id)); if (!c.regressao) return
  const corpo = `Avaliação contínua #${runId}: nota ${c.anterior?.nota} → ${c.ultima?.nota}${c.quedas.length ? ' · quedas: ' + c.quedas.map((x) => `${x.nome} ${x.de}→${x.para}`).join(', ') : ''}.`
  for (const a of await q("SELECT id FROM users WHERE role IN ('admin','superadmin') AND status = 'active'").catch(() => [] as any[]))
    await notify(Number(a.id), { type: 'sistema', title: 'Laboratório: possível regressão', body: corpo, link: '/admin/laboratorio#continuos', ref: `lab-regressao-${runId}` }).catch(() => {})
}
/** Relatório em texto (Markdown) com o histórico de pontuações de uma avaliação contínua. */
export async function relatorioContinuo(agendaId: number) {
  const a = await one('SELECT * FROM lab_schedules WHERE id = $1', [agendaId]); if (!a) fail(404, 'Avaliação não encontrada.', 'not_found')
  const c = await comparativo(agendaId), cats = [...new Set(c.serie.flatMap((s) => Object.keys(s.porCategoria)))]
  const L = [`# Avaliação contínua: ${a!.name}`, '', `Gerado em ${new Date().toLocaleString('pt-BR')}. Indicadores EXPERIMENTAIS (cenários sintéticos; não são métricas reais de uso).`, '', `Tendência: **${c.tendencia}**${c.delta != null ? ` · última variação: ${c.delta > 0 ? '+' : ''}${c.delta} ponto(s)` : ''}${c.regressao ? ' · ⚠️ possível regressão' : ''}`, '',
    `| Rodada | Data | Nota | Aprovados | ${cats.map((k) => CATEGORIAS[k] || k).join(' | ')} |`, `|---|---|---|---|${cats.map(() => '---').join('|')}|`,
    ...c.serie.map((s) => `| #${s.id} | ${new Date(s.em).toLocaleString('pt-BR')} | ${s.nota} | ${s.aprovados ?? '—'}/${s.total ?? '—'} | ${cats.map((k) => s.porCategoria[k] ?? '—').join(' | ')} |`)]
  return L.join('\n') + '\n'
}
export { LEITURA as FERRAMENTAS_LEITURA }
