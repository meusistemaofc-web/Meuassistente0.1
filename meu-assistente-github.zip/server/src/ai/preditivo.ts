// INTELIGÊNCIA PREDITIVA (Fase 7) — antecipa necessidades a partir do histórico AUTORIZADO do próprio usuário.
// Arquitetura: analistas especializados (agenda, tarefas, finanças, clientes/comercial, problemas, recorrência) trabalham
// em paralelo sobre os MESMOS dados do usuário; o núcleo consolida (sem repetir), prioriza e devolve sinais com:
//   • natureza: FATO (lido direto dos registros) ou ESTIMATIVA (padrão do histórico) com % de confiança;
//   • base verificável (quantas ocorrências, de quando) e o que fazer — só como SUGESTÃO;
//   • lacunas: quando não há dados suficientes, diz isso em vez de inventar.
// Regras: nada é criado, alterado ou cancelado por causa de uma previsão; nunca mistura usuários; CRM só para o dono.
// Os analistas são funções puras sobre "Dados": a mesma lógica roda nos dados reais, no retroteste e nos cenários simulados.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import { fail } from '../lib/http.js'

export type Categoria = 'compromissos' | 'tarefas' | 'financas' | 'clientes' | 'problemas' | 'recorrencia'
export const CATEGORIAS: Record<Categoria, string> = { compromissos: 'Compromissos', tarefas: 'Tarefas e pendências', financas: 'Finanças', clientes: 'Clientes e vendas', problemas: 'Possíveis problemas', recorrencia: 'Hábitos e recorrências' }
export const TIPOS: Record<string, string> = {
  conflito: 'Conflito de horário', proximo: 'Compromisso próximo', sem_contato: 'Compromisso sem contato do cliente', sem_horario: 'Compromisso sem horário', confirmar: 'Confirmar com o cliente', esquecimento: 'Risco de esquecimento', acompanhamento: 'Acompanhamento depois do atendimento', saldo_receber: 'Saldo a receber',
  duplicidade: 'Possível duplicidade', situacao_desatualizada: 'Situação desatualizada', tarefa_atrasada: 'Tarefa atrasada', lembrete_atrasado: 'Lembrete vencido', plano_pendente: 'Próxima etapa de um plano', compra_recorrente: 'Compra recorrente',
  conta_vencendo: 'Conta vencendo', conta_atrasada: 'Conta atrasada', conta_recorrente: 'Conta recorrente prevista', conta_sem_valor: 'Conta sem valor', ritmo_gastos: 'Ritmo de gastos do mês',
  cliente_recorrente: 'Cliente recorrente', retorno_cliente: 'Retorno previsto de cliente', cliente_sumido: 'Cliente sem contato recente', procura: 'Padrão de procura', campanha: 'Oportunidade de campanha',
  crm_lead: 'Lead sem acompanhamento', crm_parada: 'Oportunidade parada', crm_retorno: 'Cliente para retorno (CRM)', crm_fechamento: 'Oportunidade perto do fechamento', pedido_recorrente: 'Pedido recorrente',
}
export interface Sinal {
  chave: string; analista: string; categoria: Categoria; tipo: string; titulo: string; detalhe: string
  natureza: 'fato' | 'estimativa'; confianca: number | null; base: string; urgencia: 'alta' | 'media' | 'baixa'
  acao?: string; ref?: { tipo: string; id: number }; previsao?: { kind: string; pkey: string; de: string; ate: string; payload: any }; prioridade?: number; tambem?: string[]
}
export interface Ap { id: number; title: string; date: string; time: string | null; duracaoMin?: number | null; endTime?: string | null; clienteNome?: string; clienteTelefone?: string; status?: string; reminders?: number[]; valorTotal?: number | null; valorPago?: number | null; restante?: number | null; createdAt: string }
export interface Dados {
  hoje: string; agoraMin: number; appointments: Ap[]; tasks: any[]; reminders: any[]; bills: any[]; finance: any[]; shopping: any[]; plans: { id: number; etapas: any[] }[]
  pedidos: { dia: string; intent: string; area: string; hora: number }[]; crm: { empresa: string; analise: any }[]
}

/* ---------- utilidades de data ---------- */
const DIA = 864e5
export const addDias = (d: string, n: number) => new Date(Date.parse(d + 'T12:00:00Z') + n * DIA).toISOString().slice(0, 10)
export const difDias = (a: string, b: string) => Math.round((Date.parse(a + 'T12:00:00Z') - Date.parse(b + 'T12:00:00Z')) / DIA)
const dm = (d: string) => `${d.slice(8, 10)}/${d.slice(5, 7)}`
const SEM = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado']
const diaSem = (d: string) => new Date(d + 'T12:00:00Z').getUTCDay()
const quando = (d: string, hoje: string) => (d === hoje ? 'hoje' : d === addDias(hoje, 1) ? 'amanhã' : `${SEM[diaSem(d)]}, ${dm(d)}`)
const min = (t: string | null | undefined) => (t && /^\d{2}:\d{2}/.test(t) ? Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5)) : null)
const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d),)/g, '.')
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const media = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / (xs.length || 1)
const desvio = (xs: number[]) => { const m = media(xs); return Math.sqrt(media(xs.map((x) => (x - m) ** 2))) }
const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, Math.round(n)))
const ativo = (a: Ap) => !['cancelled', 'done', 'no_show'].includes(a.status || 'scheduled')
/** Intervalo regular entre datas (≥3 ocorrências): média, desvio e confiança (quanto mais regular, mais confiável). */
function regularidade(datas: string[]) {
  const ds = [...new Set(datas)].sort(); if (ds.length < 3) return null
  const iv = ds.slice(1).map((d, i) => difDias(d, ds[i])).filter((x) => x > 0); if (iv.length < 2) return null
  const m = media(iv), sd = desvio(iv), cv = sd / m
  return { media: Math.round(m), desvio: Math.round(sd), ultima: ds[ds.length - 1], n: ds.length, confianca: clamp(92 - cv * 120 - (ds.length < 4 ? 10 : 0), 25, 90) }
}

/* ======================= ANALISTAS (funções puras) ======================= */
type Saida = { sinais: Sinal[]; lacunas: string[] }
export function analistaAgenda(d: Dados): Saida {
  const S: Sinal[] = [], L: string[] = [], h = d.hoje, fut = d.appointments.filter((a) => ativo(a) && a.date >= h && a.date <= addDias(h, 14))
  // conflitos: sobreposição no mesmo dia (duração informada ou 60 min)
  const porDia = new Map<string, Ap[]>(); for (const a of fut) if (a.time) porDia.set(a.date, [...(porDia.get(a.date) || []), a])
  for (const [dia, xs] of porDia) {
    const ord = [...xs].sort((a, b) => min(a.time)! - min(b.time)!)
    for (let i = 0; i < ord.length; i++) for (let j = i + 1; j < ord.length; j++) {
      const a = ord[i], b = ord[j], fimA = min(a.endTime) ?? min(a.time)! + (a.duracaoMin || 60)
      if (min(b.time)! < fimA && !(nrm(a.title) === nrm(b.title) && a.time === b.time)) S.push({ chave: `conflito:${a.id}:${b.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'conflito', titulo: `Conflito de horário ${quando(dia, h)}`, detalhe: `"${a.title}" às ${a.time}${a.duracaoMin ? ` (${a.duracaoMin} min)` : ' (duração não informada: considerei 60 min)'} e "${b.title}" às ${b.time}.`, natureza: a.duracaoMin || a.endTime ? 'fato' : 'estimativa', confianca: a.duracaoMin || a.endTime ? null : 75, base: 'horários cadastrados na sua agenda', urgencia: difDias(dia, h) <= 2 ? 'alta' : 'media', acao: `remarcar o compromisso "${b.title}" de ${dm(dia)}`, ref: { tipo: 'appointment', id: b.id } })
    }
  }
  for (const a of fut) {
    const dd = difDias(a.date, h), mi = min(a.time), faltaMin = dd === 0 && mi != null ? mi - d.agoraMin : null
    if (dd === 0 || (dd === 1 && (mi ?? 0) < 12 * 60)) S.push({ chave: `proximo:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'proximo', titulo: `${a.title} ${quando(a.date, h)}${a.time ? ' às ' + a.time : ''}`, detalhe: `${a.clienteNome ? `Cliente: ${a.clienteNome}. ` : ''}${faltaMin != null && faltaMin > 0 && faltaMin <= 180 ? `Começa em ${faltaMin < 60 ? faltaMin + ' min' : Math.round(faltaMin / 60) + ' h'}.` : ''}`.trim() || 'Próximo compromisso da agenda.', natureza: 'fato', confianca: null, base: 'sua agenda', urgencia: faltaMin != null && faltaMin > 0 && faltaMin <= 180 ? 'alta' : 'media', ref: { tipo: 'appointment', id: a.id } })
    if (a.clienteNome && !a.clienteTelefone && dd <= 7) S.push({ chave: `sem_contato:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'sem_contato', titulo: `Sem telefone do cliente em "${a.title}"`, detalhe: `${a.clienteNome} tem atendimento ${quando(a.date, h)} e não há telefone cadastrado para confirmar ou avisar.`, natureza: 'fato', confianca: null, base: 'cadastro do compromisso', urgencia: dd <= 2 ? 'media' : 'baixa', acao: `adicionar o telefone de ${a.clienteNome} no compromisso`, ref: { tipo: 'appointment', id: a.id } })
    if (!a.time && dd <= 3) S.push({ chave: `sem_horario:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'sem_horario', titulo: `"${a.title}" sem horário`, detalhe: `O compromisso de ${quando(a.date, h)} está sem horário, então não há aviso antes.`, natureza: 'fato', confianca: null, base: 'cadastro do compromisso', urgencia: 'media', acao: `definir o horário de "${a.title}"`, ref: { tipo: 'appointment', id: a.id } })
    if (a.clienteNome && (a.status || 'scheduled') === 'scheduled' && dd >= 1 && dd <= 2) S.push({ chave: `confirmar:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'confirmar', titulo: `Confirmar com ${a.clienteNome}`, detalhe: `"${a.title}" ${quando(a.date, h)}${a.time ? ' às ' + a.time : ''} ainda não está marcado como confirmado.${a.valorTotal && !a.valorPago ? ` Nenhum pagamento registrado (total ${brl(a.valorTotal)}).` : ''}`, natureza: 'fato', confianca: null, base: 'situação do compromisso', urgencia: dd === 1 ? 'media' : 'baixa', acao: `confirmar o horário com ${a.clienteNome}${a.clienteTelefone ? ' pelo WhatsApp' : ''}`, ref: { tipo: 'appointment', id: a.id } })
    // risco de esquecimento: ESTIMATIVA com critério explícito
    if (dd <= 2 && !(a.reminders || []).length) {
      const antigo = difDias(h, String(a.createdAt).slice(0, 10)), pontos = 40 + (antigo >= 7 ? 20 : 0) + (!a.time ? 10 : 0) + (a.clienteNome ? 5 : 0)
      if (pontos >= 55) S.push({ chave: `esquecimento:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'esquecimento', titulo: `Risco de esquecer "${a.title}"`, detalhe: `É ${quando(a.date, h)}, não tem lembrete${antigo >= 7 ? ` e foi marcado há ${antigo} dias` : ''}.`, natureza: 'estimativa', confianca: clamp(pontos, 0, 85), base: `critério: sem lembrete (40)${antigo >= 7 ? ' + marcado há mais de 7 dias (20)' : ''}${!a.time ? ' + sem horário (10)' : ''}${a.clienteNome ? ' + envolve cliente (5)' : ''}`, urgencia: dd <= 1 ? 'alta' : 'media', acao: `criar um lembrete para "${a.title}"`, ref: { tipo: 'appointment', id: a.id } })
    }
  }
  // depois do atendimento: acompanhamento, saldo a receber e situação desatualizada
  for (const a of d.appointments.filter((x) => x.date < h && x.date >= addDias(h, -10) && ativo(x))) {
    const dd = difDias(h, a.date)
    if (a.clienteNome && dd <= 3) S.push({ chave: `acompanhamento:${a.id}`, analista: 'agenda', categoria: 'compromissos', tipo: 'acompanhamento', titulo: `Pós-atendimento: ${a.clienteNome}`, detalhe: `"${a.title}" foi ${dd === 1 ? 'ontem' : `há ${dd} dias`}. Vale perguntar como foi e combinar o próximo passo.`, natureza: 'fato', confianca: null, base: 'compromisso realizado', urgencia: 'baixa', acao: `marcar "${a.title}" como concluído e falar com ${a.clienteNome}`, ref: { tipo: 'appointment', id: a.id } })
    if (a.valorTotal && (a.restante ?? 0) > 0) S.push({ chave: `saldo_receber:${a.id}`, analista: 'agenda', categoria: 'financas', tipo: 'saldo_receber', titulo: `Saldo a receber: ${brl(a.restante!)}`, detalhe: `${a.clienteNome ? a.clienteNome + ' · ' : ''}"${a.title}" em ${dm(a.date)}: pago ${brl(a.valorPago || 0)} de ${brl(a.valorTotal)}.`, natureza: 'fato', confianca: null, base: 'valores do compromisso', urgencia: dd >= 3 ? 'media' : 'baixa', acao: `registrar o pagamento restante de "${a.title}"`, ref: { tipo: 'appointment', id: a.id } })
  }
  if (!d.appointments.length) L.push('Agenda: nenhum compromisso cadastrado — sem dados para prever conflitos ou esquecimentos.')
  return { sinais: S, lacunas: L }
}
export function analistaTarefas(d: Dados): Saida {
  const S: Sinal[] = [], L: string[] = [], h = d.hoje
  const atrasadas = d.tasks.filter((t) => t.status !== 'done' && t.dueDate && t.dueDate < h)
  for (const t of atrasadas.slice(0, 5)) S.push({ chave: `tarefa_atrasada:${t.id}`, analista: 'tarefas', categoria: 'tarefas', tipo: 'tarefa_atrasada', titulo: `Tarefa atrasada: ${t.title}`, detalhe: `Prazo era ${dm(t.dueDate)} (${difDias(h, t.dueDate)} dia(s) atrás).`, natureza: 'fato', confianca: null, base: 'prazo da tarefa', urgencia: t.priority === 'high' ? 'alta' : 'media', acao: `concluir ou remarcar a tarefa "${t.title}"`, ref: { tipo: 'task', id: t.id } })
  for (const r of d.reminders.filter((x) => (x.status || 'pending') === 'pending' && x.date && x.date < addDias(h, -1)).slice(0, 3)) S.push({ chave: `lembrete_atrasado:${r.id}`, analista: 'tarefas', categoria: 'problemas', tipo: 'lembrete_atrasado', titulo: `Lembrete vencido: ${r.message}`, detalhe: `Era para ${dm(r.date)} e continua pendente.`, natureza: 'fato', confianca: null, base: 'lembrete cadastrado', urgencia: 'baixa', acao: `concluir ou adiar o lembrete "${r.message}"`, ref: { tipo: 'reminder', id: r.id } })
  for (const p of d.plans) { const prox = (p.etapas || []).find((e: any) => !['feito', 'falhou'].includes(e.status)); if (prox) S.push({ chave: `plano_pendente:${p.id}:${prox.n}`, analista: 'tarefas', categoria: 'tarefas', tipo: 'plano_pendente', titulo: `Próxima etapa: ${prox.acao}`, detalhe: `De um pedido em ${p.etapas.length} etapas: ${p.etapas.filter((e: any) => e.status === 'feito').length} feita(s).`, natureza: 'fato', confianca: null, base: 'plano em andamento no chat', urgencia: 'baixa', acao: String(prox.texto || prox.acao).slice(0, 120) }) }
  // compras recorrentes (estimativa): o mesmo item adicionado ≥3 vezes em 120 dias
  const porItem = new Map<string, { nome: string; datas: string[]; pendente: boolean }>()
  for (const s of d.shopping) { const k = nrm(s.name); if (!k) continue; const x = porItem.get(k) || { nome: s.name, datas: [] as string[], pendente: false }; x.datas.push(String(s.createdAt).slice(0, 10)); if (!s.done) x.pendente = true; porItem.set(k, x) }
  for (const [k, x] of porItem) {
    const r = regularidade(x.datas); if (!r || x.pendente || r.media < 3) continue
    const prev = addDias(r.ultima, r.media)
    if (prev <= addDias(h, 3) && prev >= addDias(h, -r.media)) S.push({ chave: `compra_recorrente:${k}`, analista: 'tarefas', categoria: 'recorrencia', tipo: 'compra_recorrente', titulo: `Hora de comprar ${x.nome}?`, detalhe: `Você costuma colocar "${x.nome}" na lista a cada ~${r.media} dias; a última vez foi em ${dm(r.ultima)}.`, natureza: 'estimativa', confianca: r.confianca, base: `${r.n} vezes na lista (intervalo médio ${r.media} dias, variação ±${r.desvio})`, urgencia: 'baixa', acao: `colocar ${x.nome} na lista de compras`, previsao: { kind: 'compra_recorrente', pkey: `compra:${k}:${prev}`, de: addDias(prev, -Math.max(3, r.desvio)), ate: addDias(prev, Math.max(5, r.desvio + 2)), payload: { item: x.nome, previsto: prev } } })
  }
  if (d.shopping.length && ![...porItem.values()].some((x) => x.datas.length >= 3)) L.push('Compras: ainda não há item repetido o bastante (3 vezes) para prever a próxima compra.')
  return { sinais: S, lacunas: L }
}
export function analistaFinancas(d: Dados): Saida {
  const S: Sinal[] = [], L: string[] = [], h = d.hoje
  for (const b of d.bills.filter((x) => (x.status || 'pending') === 'pending')) {
    const dd = difDias(b.dueDate, h)
    if (dd < 0 && dd >= -60) S.push({ chave: `conta_atrasada:${b.id}`, analista: 'financas', categoria: 'financas', tipo: 'conta_atrasada', titulo: `Conta atrasada: ${b.name}`, detalhe: `${b.amount ? brl(b.amount) + ', ' : ''}venceu em ${dm(b.dueDate)} e não está marcada como paga.`, natureza: 'fato', confianca: null, base: 'contas cadastradas', urgencia: 'alta', acao: `pagar ou marcar como paga a conta "${b.name}"`, ref: { tipo: 'bill', id: b.id } })
    else if (dd >= 0 && dd <= 3) S.push({ chave: `conta_vencendo:${b.id}`, analista: 'financas', categoria: 'financas', tipo: 'conta_vencendo', titulo: `${b.name} vence ${quando(b.dueDate, h)}`, detalhe: b.amount ? `Valor: ${brl(b.amount)}.` : 'Sem valor informado.', natureza: 'fato', confianca: null, base: 'contas cadastradas', urgencia: dd <= 1 ? 'alta' : 'media', acao: `lembrar de pagar "${b.name}"`, ref: { tipo: 'bill', id: b.id } })
    if (!b.amount && dd >= -5 && dd <= 10) S.push({ chave: `conta_sem_valor:${b.id}`, analista: 'financas', categoria: 'problemas', tipo: 'conta_sem_valor', titulo: `Conta sem valor: ${b.name}`, detalhe: 'Sem o valor, o resumo do mês fica incompleto.', natureza: 'fato', confianca: null, base: 'cadastro da conta', urgencia: 'baixa', acao: `informar o valor da conta "${b.name}"`, ref: { tipo: 'bill', id: b.id } })
  }
  // contas que se repetem todo mês pelo nome, sem estarem cadastradas como recorrentes (estimativa)
  const porNome = new Map<string, any[]>(); for (const b of d.bills.filter((x) => (x.recurrence || 'none') === 'none')) { const k = nrm(b.name); if (k) porNome.set(k, [...(porNome.get(k) || []), b]) }
  const mesAtual = h.slice(0, 7)
  for (const [k, bs] of porNome) {
    const meses = [...new Set(bs.map((b) => String(b.dueDate).slice(0, 7)))].sort(), anteriores = meses.filter((m) => m < mesAtual)
    if (anteriores.length < 2) continue
    const ultimos3 = [0, 1, 2].map((i) => { const dt = new Date(Date.parse(mesAtual + '-15T12:00:00Z')); dt.setUTCMonth(dt.getUTCMonth() - 1 - i); return dt.toISOString().slice(0, 7) })
    const presentes = ultimos3.filter((m) => meses.includes(m)).length; if (presentes < 2 || meses.includes(mesAtual)) continue
    const dias = bs.map((b) => Number(String(b.dueDate).slice(8, 10))), dia = Math.round(media(dias)), spread = Math.max(...dias) - Math.min(...dias)
    const prev = `${mesAtual}-${String(Math.min(dia, 28)).padStart(2, '0')}`; if (prev < addDias(h, -5) || prev > addDias(h, 20)) continue
    const vals = bs.map((b) => Number(b.amount) || 0).filter((v) => v > 0), conf = clamp((presentes / 3) * 90 - (spread > 6 ? 15 : 0), 30, 90)
    S.push({ chave: `conta_recorrente:${k}:${mesAtual}`, analista: 'financas', categoria: 'recorrencia', tipo: 'conta_recorrente', titulo: `${bs[0].name} deve vencer por volta de ${dm(prev)}`, detalhe: `Ela apareceu em ${presentes} dos últimos 3 meses (por volta do dia ${dia})${vals.length ? `, em média ${brl(media(vals))}` : ''}, e ainda não está cadastrada neste mês.`, natureza: 'estimativa', confianca: conf, base: `${bs.length} conta(s) com esse nome · meses: ${anteriores.slice(-3).map((m) => m.slice(5) + '/' + m.slice(2, 4)).join(', ')}`, urgencia: difDias(prev, h) <= 5 ? 'media' : 'baixa', acao: `cadastrar a conta "${bs[0].name}" deste mês (ou como recorrente)`, previsao: { kind: 'conta_recorrente', pkey: `conta:${k}:${mesAtual}`, de: addDias(prev, -7), ate: addDias(prev, 7), payload: { nome: bs[0].name, previsto: prev, valorMedio: vals.length ? Math.round(media(vals) * 100) / 100 : null } } })
  }
  // ritmo de gastos do mês por categoria (estimativa só com ≥2 meses completos de histórico)
  const gastos = d.finance.filter((f) => f.kind === 'expense' && f.amount > 0), diaMes = Number(h.slice(8, 10)), diasNoMes = new Date(Date.UTC(Number(h.slice(0, 4)), Number(h.slice(5, 7)), 0)).getUTCDate()
  const porCat = new Map<string, Map<string, number>>(); for (const g of gastos) { const m = String(g.date).slice(0, 7), c = g.category || 'outros'; const x = porCat.get(c) || new Map(); x.set(m, (x.get(m) || 0) + Number(g.amount)); porCat.set(c, x) }
  let semHistorico = 0
  for (const [cat, m] of porCat) {
    const ant = [...m.entries()].filter(([mm]) => mm < mesAtual).sort().slice(-3); if (ant.length < 2) { semHistorico++; continue }
    if (diaMes < 7) continue
    const atual = m.get(mesAtual) || 0, prev = (atual / diaMes) * diasNoMes, med = media(ant.map(([, v]) => v))
    if (prev > med * 1.25 && atual > 0) S.push({ chave: `ritmo_gastos:${cat}:${mesAtual}`, analista: 'financas', categoria: 'financas', tipo: 'ritmo_gastos', titulo: `Gastos com ${catNome(cat)} acima do normal`, detalhe: `No ritmo atual (${brl(atual)} até o dia ${diaMes}), o mês deve fechar perto de ${brl(prev)}, contra média de ${brl(med)} nos últimos ${ant.length} meses.`, natureza: 'estimativa', confianca: clamp(35 + (diaMes / diasNoMes) * 50 + (ant.length >= 3 ? 5 : 0), 35, 85), base: `gastos lançados em ${catNome(cat)} (${ant.length} meses de histórico) · projeção linear do mês`, urgencia: prev > med * 1.5 ? 'media' : 'baixa', acao: `ver os gastos de ${catNome(cat)} deste mês`, previsao: { kind: 'gasto_mes', pkey: `gasto:${nrm(cat)}:${mesAtual}`, de: `${mesAtual}-${String(diasNoMes).padStart(2, '0')}`, ate: addDias(`${mesAtual}-${String(diasNoMes).padStart(2, '0')}`, 3), payload: { categoria: cat, previsto: Math.round(prev * 100) / 100, media: Math.round(med * 100) / 100, mes: mesAtual } } })
  }
  if (porCat.size && semHistorico === porCat.size) L.push('Finanças: menos de 2 meses de gastos por categoria — ainda não dá para estimar o ritmo do mês.')
  if (!d.bills.length && !d.finance.length) L.push('Finanças: nenhuma conta ou lançamento — sem dados para prever.')
  return { sinais: S, lacunas: L }
}
export function analistaClientes(d: Dados): Saida {
  const S: Sinal[] = [], L: string[] = [], h = d.hoje
  const porCli = new Map<string, { nome: string; datas: string[]; servicos: string[]; tel?: string }>()
  for (const a of d.appointments.filter((x) => x.clienteNome && x.status !== 'cancelled')) { const k = nrm(a.clienteNome!); const x = porCli.get(k) || { nome: a.clienteNome!, datas: [], servicos: [] }; x.datas.push(a.date); x.servicos.push(a.title); if (a.clienteTelefone) x.tel = a.clienteTelefone; porCli.set(k, x) }
  const recorrentes = [...porCli.entries()].filter(([, x]) => new Set(x.datas.filter((dd) => dd <= h)).size >= 2)
  for (const [k, x] of recorrentes.slice(0, 20)) {
    const pass = [...new Set(x.datas.filter((dd) => dd <= h))].sort(), futuro = x.datas.some((dd) => dd > h), ult = pass[pass.length - 1], r = regularidade(pass)
    if (pass.length >= 3) S.push({ chave: `cliente_recorrente:${k}`, analista: 'clientes', categoria: 'clientes', tipo: 'cliente_recorrente', titulo: `${x.nome} é cliente recorrente`, detalhe: `${pass.length} atendimentos (último em ${dm(ult)}); serviço mais comum: ${moda(x.servicos)}.`, natureza: 'fato', confianca: null, base: 'compromissos com esse cliente', urgencia: 'baixa' })
    if (r && !futuro) {
      const prev = addDias(ult, r.media), atraso = difDias(h, prev)
      if (atraso >= -7 && atraso <= Math.max(10, r.desvio)) S.push({ chave: `retorno_cliente:${k}:${prev}`, analista: 'clientes', categoria: 'clientes', tipo: 'retorno_cliente', titulo: `${x.nome} deve voltar por volta de ${dm(prev)}`, detalhe: `Vem a cada ~${r.media} dias e ainda não tem horário marcado.${x.tel ? '' : ' Sem telefone cadastrado.'}`, natureza: 'estimativa', confianca: r.confianca, base: `${r.n} atendimentos · intervalo médio ${r.media} dias (±${r.desvio})`, urgencia: atraso >= 0 ? 'media' : 'baixa', acao: `oferecer um horário para ${x.nome}`, previsao: { kind: 'retorno_cliente', pkey: `retorno:${k}:${prev}`, de: addDias(prev, -Math.max(7, r.desvio)), ate: addDias(prev, Math.max(14, r.desvio * 2)), payload: { cliente: x.nome, previsto: prev } } })
      else if (atraso > Math.max(10, r.desvio) && difDias(h, ult) >= 30) S.push({ chave: `cliente_sumido:${k}`, analista: 'clientes', categoria: 'clientes', tipo: 'cliente_sumido', titulo: `${x.nome} está sem atendimento há ${difDias(h, ult)} dias`, detalhe: `Costumava voltar a cada ~${r.media} dias. Pode ser uma boa hora para um contato.`, natureza: 'estimativa', confianca: clamp(r.confianca - 10, 25, 80), base: `${r.n} atendimentos · intervalo médio ${r.media} dias`, urgencia: 'baixa', acao: `mandar uma mensagem para ${x.nome}` })
    } else if (!r && !futuro && pass.length === 2 && difDias(h, ult) >= 45) S.push({ chave: `cliente_sumido:${k}`, analista: 'clientes', categoria: 'clientes', tipo: 'cliente_sumido', titulo: `${x.nome} está sem atendimento há ${difDias(h, ult)} dias`, detalhe: 'Veio duas vezes e não voltou desde então.', natureza: 'fato', confianca: null, base: '2 atendimentos registrados', urgencia: 'baixa', acao: `mandar uma mensagem para ${x.nome}` })
  }
  // padrões de procura (fato) e oportunidade de campanha (estimativa) — só com volume suficiente (8 semanas, ≥20 atendimentos)
  const janela = d.appointments.filter((a) => a.status !== 'cancelled' && a.date <= h && a.date > addDias(h, -56))
  if (janela.length >= 20) {
    const cont = Array(7).fill(0); for (const a of janela) cont[diaSem(a.date)]++
    const ord = cont.map((n, i) => ({ n, i })).sort((a, b) => b.n - a.n), abertos = ord.filter((x) => x.n > 0)
    S.push({ chave: `procura:${h.slice(0, 7)}`, analista: 'clientes', categoria: 'clientes', tipo: 'procura', titulo: `Maior procura: ${SEM[ord[0].i]} e ${SEM[ord[1].i]}`, detalhe: `Nas últimas 8 semanas: ${ord.filter((x) => x.n).map((x) => `${SEM[x.i]} ${x.n}`).join(', ')}. Serviço mais pedido: ${moda(janela.map((a) => a.title))}.`, natureza: 'fato', confianca: null, base: `${janela.length} atendimentos em 8 semanas`, urgencia: 'baixa' })
    const vazio = abertos[abertos.length - 1]
    if (vazio && vazio.n <= ord[0].n / 3) S.push({ chave: `campanha:${SEM[vazio.i]}:${h.slice(0, 7)}`, analista: 'clientes', categoria: 'clientes', tipo: 'campanha', titulo: `Campanha para ${SEM[vazio.i]}`, detalhe: `${SEM[vazio.i]} teve ${vazio.n} atendimento(s) em 8 semanas, contra ${ord[0].n} na ${SEM[ord[0].i]}. Uma condição especial nesse dia pode equilibrar a agenda${recorrentes.length ? ` — comece pelos ${recorrentes.length} clientes recorrentes` : ''}.`, natureza: 'estimativa', confianca: 50, base: 'distribuição dos atendimentos por dia da semana (8 semanas)', urgencia: 'baixa', acao: `planejar uma campanha para ${SEM[vazio.i]}` })
  } else if (d.appointments.some((a) => a.clienteNome)) L.push(`Clientes: ${janela.length} atendimento(s) nas últimas 8 semanas — preciso de pelo menos 20 para apontar padrões de procura.`)
  // CRM da empresa (dono): a inteligência comercial já existente vira sinais com o critério dela
  for (const c of d.crm) {
    const A = c.analise || {}
    for (const x of (A.leadsSemAcompanhamento || []).slice(0, 3)) S.push({ chave: `crm_lead:${x.contatoId}`, analista: 'comercial', categoria: 'clientes', tipo: 'crm_lead', titulo: `Lead sem acompanhamento: ${x.nome}`, detalhe: `${c.empresa}: ${x.motivo}`, natureza: 'fato', confianca: null, base: 'CRM da empresa', urgencia: x.dias >= 14 ? 'media' : 'baixa', acao: `criar uma tarefa de contato com ${x.nome}` })
    for (const x of (A.oportunidadesParadas || []).slice(0, 3)) S.push({ chave: `crm_parada:${x.oportunidadeId}`, analista: 'comercial', categoria: 'clientes', tipo: 'crm_parada', titulo: `Oportunidade parada: ${x.titulo}`, detalhe: `${c.empresa} · ${x.cliente}: ${x.motivo}`, natureza: 'fato', confianca: null, base: 'CRM da empresa', urgencia: 'media', acao: `retomar a negociação "${x.titulo}"` })
    for (const x of (A.clientesParaRetorno || []).slice(0, 3)) S.push({ chave: `crm_retorno:${x.contatoId}`, analista: 'comercial', categoria: 'clientes', tipo: 'crm_retorno', titulo: `Cliente para retorno: ${x.nome}`, detalhe: `${c.empresa}: ${x.motivo}`, natureza: 'fato', confianca: null, base: 'CRM da empresa', urgencia: 'baixa', acao: `fazer contato com ${x.nome}` })
    for (const x of (A.proximasDoFechamento || []).slice(0, 3)) S.push({ chave: `crm_fechamento:${x.oportunidadeId}`, analista: 'comercial', categoria: 'clientes', tipo: 'crm_fechamento', titulo: `Perto de fechar: ${x.titulo}`, detalhe: `${c.empresa} · ${x.cliente}: ${x.motivo}`, natureza: x.previsao ? 'fato' : 'estimativa', confianca: x.previsao ? null : x.probabilidade, base: 'CRM da empresa (probabilidade informada na oportunidade)', urgencia: 'media', acao: `acompanhar a oportunidade "${x.titulo}"` })
  }
  return { sinais: S, lacunas: L }
}
const CATN: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
const catNome = (c: string) => (CATN[c] || c).toLowerCase()
const moda = (xs: string[]) => { const m = new Map<string, number>(); for (const x of xs) m.set(x, (m.get(x) || 0) + 1); return [...m].sort((a, b) => b[1] - a[1])[0]?.[0] || '—' }
export function analistaProblemas(d: Dados): Saida {
  const S: Sinal[] = [], h = d.hoje
  // possível duplicidade: mesmo serviço, dia e horário (e mesmo cliente, se houver)
  const vistos = new Map<string, Ap>()
  for (const a of d.appointments.filter((x) => ativo(x) && x.date >= addDias(h, -1))) {
    const k = `${nrm(a.title)}|${a.date}|${a.time || ''}|${nrm(a.clienteNome || '')}`, o = vistos.get(k)
    if (o) S.push({ chave: `duplicidade:${o.id}:${a.id}`, analista: 'problemas', categoria: 'problemas', tipo: 'duplicidade', titulo: `Possível compromisso duplicado: ${a.title}`, detalhe: `Há dois "${a.title}" em ${dm(a.date)}${a.time ? ' às ' + a.time : ''}${a.clienteNome ? ' com ' + a.clienteNome : ''}.`, natureza: 'estimativa', confianca: 80, base: 'mesmo serviço, dia, horário e cliente', urgencia: 'media', acao: `conferir os dois compromissos "${a.title}" de ${dm(a.date)}`, ref: { tipo: 'appointment', id: a.id } })
    else vistos.set(k, a)
  }
  // situação desatualizada: atendimento passado há mais de 3 dias ainda como agendado/confirmado
  const velhos = d.appointments.filter((a) => ativo(a) && a.date < addDias(h, -3) && a.date >= addDias(h, -60))
  if (velhos.length) S.push({ chave: `situacao_desatualizada:${h}`, analista: 'problemas', categoria: 'problemas', tipo: 'situacao_desatualizada', titulo: `${velhos.length} compromisso(s) passado(s) sem situação atualizada`, detalhe: `Exemplo: "${velhos[0].title}" de ${dm(velhos[0].date)} ainda aparece como ${velhos[0].status === 'confirmed' ? 'confirmado' : 'agendado'}. Atualizar ajuda os relatórios e as previsões.`, natureza: 'fato', confianca: null, base: 'situação dos compromissos', urgencia: 'baixa', acao: 'marcar como concluídos (ou cancelados) os compromissos que já passaram' })
  return { sinais: S, lacunas: [] }
}
export function analistaRecorrencia(d: Dados): Saida {
  const S: Sinal[] = [], L: string[] = [], h = d.hoje
  // solicitações recorrentes no chat: mesma área, mesmo dia da semana e período, em semanas diferentes
  const per = (hr: number) => (hr < 12 ? 'manhã' : hr < 18 ? 'tarde' : 'noite'), grupos = new Map<string, Set<string>>()
  for (const p of d.pedidos.filter((x) => x.area !== 'geral' && x.dia > addDias(h, -56))) { const k = `${p.area}|${diaSem(p.dia)}|${per(p.hora)}`, w = String(Math.floor(Date.parse(p.dia + 'T12:00:00Z') / (7 * DIA))); grupos.set(k, (grupos.get(k) || new Set()).add(w)) }
  const AREA: Record<string, string> = { agenda: 'a agenda', financas: 'as finanças', tarefas: 'as tarefas', compras: 'a lista de compras', crm: 'os clientes', negocio: 'o movimento da empresa', agenda_empresa: 'os horários da empresa' }
  for (const [k, ws] of [...grupos].sort((a, b) => b[1].size - a[1].size).slice(0, 3)) {
    if (ws.size < 3) continue
    const [area, ds, p] = k.split('|')
    S.push({ chave: `pedido_recorrente:${k}`, analista: 'recorrencia', categoria: 'recorrencia', tipo: 'pedido_recorrente', titulo: `Você costuma ver ${AREA[area] || area} ${SEM[Number(ds)]} de ${p}`, detalhe: `Aconteceu em ${ws.size} das últimas 8 semanas.`, natureza: 'estimativa', confianca: clamp((ws.size / 8) * 100, 30, 90), base: `${ws.size} semanas com o mesmo pedido, no mesmo dia e período`, urgencia: 'baixa', acao: `ver ${AREA[area] || area}` })
  }
  if (d.pedidos.length < 10) L.push('Hábitos: poucas conversas ainda para identificar pedidos recorrentes.')
  return { sinais: S, lacunas: L }
}
export const ANALISTAS: Record<string, (d: Dados) => Saida> = { agenda: analistaAgenda, tarefas: analistaTarefas, financas: analistaFinancas, clientes: analistaClientes, problemas: analistaProblemas, recorrencia: analistaRecorrencia }

/* ======================= NÚCLEO: consolida, remove repetição, prioriza ======================= */
const URG = { alta: 3, media: 2, baixa: 1 }
export function consolidar(saidas: Record<string, Saida>, o: { prioridades?: string[]; silenciar?: string[] } = {}) {
  const porChave = new Map<string, Sinal>(), porRef = new Map<string, Sinal>(), lacunas: string[] = []
  for (const [, s] of Object.entries(saidas)) {
    lacunas.push(...s.lacunas)
    for (const x of s.sinais) {
      if ((o.silenciar || []).includes(x.tipo) || porChave.has(x.chave)) continue
      // o mesmo registro apontado por analistas diferentes vira UM sinal (o mais urgente), citando os outros aspectos
      const rk = x.ref ? `${x.ref.tipo}:${x.ref.id}` : ''
      const outro = rk ? porRef.get(rk) : undefined
      if (outro && outro.tipo !== x.tipo && ['proximo', 'confirmar', 'esquecimento', 'sem_contato'].includes(x.tipo) && ['proximo', 'confirmar', 'esquecimento', 'sem_contato'].includes(outro.tipo)) {
        const [forte, fraco] = URG[x.urgencia] > URG[outro.urgencia] ? [x, outro] : [outro, x]
        forte.tambem = [...new Set([...(forte.tambem || []), TIPOS[fraco.tipo], ...(fraco.tambem || [])])]
        if (!forte.acao && fraco.acao) forte.acao = fraco.acao
        if (forte !== outro) { porChave.delete(outro.chave); porChave.set(forte.chave, forte); porRef.set(rk, forte) }
        continue
      }
      porChave.set(x.chave, x); if (rk && !porRef.has(rk)) porRef.set(rk, x)
    }
  }
  const sinais = [...porChave.values()].map((x) => ({ ...x, prioridade: URG[x.urgencia] * 30 + (x.natureza === 'fato' ? 20 : (x.confianca || 0) * 0.2) + ((o.prioridades || []).includes(x.categoria) ? 15 : 0) }))
  sinais.sort((a, b) => b.prioridade! - a.prioridade!)
  return { sinais, lacunas: [...new Set(lacunas)] }
}
/** Roda os analistas em paralelo (cada um isolado: a falha de um não derruba os outros) e consolida. */
export async function analisar(d: Dados, o: { prioridades?: string[]; silenciar?: string[]; desligados?: string[] } = {}) {
  const t0 = performance.now(), falhas: string[] = []
  const saidas = Object.fromEntries(await Promise.all(Object.entries(ANALISTAS).map(async ([n, f]) => { try { return [n, f(d)] } catch (e: any) { falhas.push(n); console.error('[preditivo] analista', n, e?.message); return [n, { sinais: [], lacunas: [] }] } }))) as Record<string, Saida>
  const c = consolidar(saidas, { prioridades: o.prioridades, silenciar: [...(o.silenciar || []), ...(o.desligados || [])] })
  return { ...c, falhas, ms: Math.round((performance.now() - t0) * 100) / 100, porAnalista: Object.fromEntries(Object.entries(saidas).map(([n, s]) => [n, s.sinais.length])) }
}

/* ======================= DADOS do próprio usuário (somente leitura) ======================= */
export async function carregarDados(u: SessionUser, o: { ate?: string } = {}): Promise<Dados> {
  const { listItems, serialize } = await import('../routes/items.js'), { settingsOf } = await import('../lib/account.js'), { localDate, localTime } = await import('../lib/time.js')
  const tz = settingsOf(u).timezone, corte = o.ate ? Date.parse(o.ate) : null
  const hoje = o.ate ? o.ate.slice(0, 10) : localDate(tz), hora = o.ate ? '12:00' : localTime(tz)
  const desde = addDias(hoje, -200), ok = (x: any) => corte == null || Date.parse(String(x.createdAt)) <= corte
  const L = async (t: any, extra = '', p: any[] = []) => (await listItems(u.id, t, extra, p).catch(() => [])).map(serialize).filter(ok) as any[]
  const [appointments, tasks, reminders, bills, finance, shopping] = await Promise.all([
    L('appointment', 'AND day >= $3', [desde]), L('task', "AND (status IS NULL OR status <> 'done')"), L('reminder', "AND (status IS NULL OR status = 'pending')"),
    L('bill', 'AND day >= $3', [desde]), L('expense', 'AND day >= $3', [addDias(hoje, -130)]), L('shopping', 'AND created_at >= $3', [new Date(Date.parse(hoje) - 120 * DIA).toISOString()]),
  ])
  const plans = o.ate ? [] : ((await q("SELECT id, steps FROM assistant_plans WHERE user_id = $1 AND status = 'ativo' ORDER BY id DESC LIMIT 3", [u.id]).catch(() => [])) as any[]).map((r) => ({ id: Number(r.id), etapas: J<any[]>(r.steps, []) }))
  const ev = ((await q('SELECT specialists, created_at FROM cognition_evals WHERE user_id = $1 AND created_at >= $2 ORDER BY id DESC LIMIT 2000', [u.id, new Date(Date.parse(hoje) - 60 * DIA).toISOString()]).catch(() => [])) as any[])
  const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' })
  const pedidos = ev.filter((r) => corte == null || Date.parse(String(r.created_at)) <= corte).map((r) => { const p = Object.fromEntries(fmt.formatToParts(new Date(String(r.created_at))).map((x) => [x.type, x.value])); return { dia: `${p.year}-${p.month}-${p.day}`, hora: Number(p.hour), intent: '', area: J<string[]>(r.specialists, [])[0] || 'geral' } })
  // CRM: só empresas de que o usuário é DONO e com acesso válido ao CRM
  const crm: Dados['crm'] = []
  if (!o.ate) for (const b of ((await q('SELECT id, name FROM businesses WHERE owner_id = $1 LIMIT 5', [u.id]).catch(() => [])) as any[])) {
    try { const C = await import('../lib/crm.js'); await C.acesso(u.id, Number(b.id)); crm.push({ empresa: String(b.name), analise: await C.CommercialIntelligenceService.analise(Number(b.id)) }) } catch { /* sem plano/permissão de CRM: não lê nada */ }
  }
  return { hoje, agoraMin: Number(hora.slice(0, 2)) * 60 + Number(hora.slice(3, 5)), appointments, tasks, reminders, bills, finance, shopping, plans, pedidos, crm }
}

/* ======================= configuração e preferências ======================= */
export const PRED_DEFAULT = { ativo: true, notificacoes: true, tiposDesligados: [] as string[], limiteDiarioGlobal: 5 }
export const predCfg = async () => ({ ...PRED_DEFAULT, ...(await (await import('../lib/settings.js')).getConfig<any>('preditivo', {})) }) as typeof PRED_DEFAULT
export const PREFS_DEFAULT = { ativo: true, categorias: { compromissos: true, tarefas: true, financas: true, clientes: true, problemas: true, recorrencia: true } as Record<string, boolean>, canais: { chat: true, notificacao: true }, frequencia: 'normal' as 'baixa' | 'normal' | 'alta', silencio: { de: '22:00', ate: '08:00' }, prioridades: [] as string[] }
export type PrefsPred = typeof PREFS_DEFAULT
export async function prefsPred(userId: number): Promise<PrefsPred> {
  const r = await one('SELECT predictive FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null), p = J<any>(r?.predictive ?? null, {})
  return { ...PREFS_DEFAULT, ...p, categorias: { ...PREFS_DEFAULT.categorias, ...(p.categorias || {}) }, canais: { ...PREFS_DEFAULT.canais, ...(p.canais || {}) }, silencio: { ...PREFS_DEFAULT.silencio, ...(p.silencio || {}) } }
}
export function validarPrefs(b: any, atual: PrefsPred): PrefsPred {
  const n: PrefsPred = structuredClone(atual)
  if (b.ativo !== undefined) { if (typeof b.ativo !== 'boolean') fail(400, 'Informe ativo: true ou false.', 'invalid', 'ativo'); n.ativo = b.ativo }
  for (const [k, v] of Object.entries(b.categorias || {})) { if (!(k in CATEGORIAS) || typeof v !== 'boolean') fail(400, 'Categoria inválida: ' + k, 'invalid', 'categorias'); n.categorias[k] = v as boolean }
  for (const [k, v] of Object.entries(b.canais || {})) { if (!['chat', 'notificacao'].includes(k) || typeof v !== 'boolean') fail(400, 'Canal inválido: ' + k, 'invalid', 'canais'); (n.canais as any)[k] = v }
  if (b.frequencia !== undefined) { if (!['baixa', 'normal', 'alta'].includes(b.frequencia)) fail(400, 'Frequência: baixa, normal ou alta.', 'invalid', 'frequencia'); n.frequencia = b.frequencia }
  if (b.silencio !== undefined) { const ok = (t: any) => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(t)); if (!ok(b.silencio?.de) || !ok(b.silencio?.ate)) fail(400, 'Horário de silêncio inválido (HH:MM).', 'invalid', 'silencio'); n.silencio = { de: b.silencio.de, ate: b.silencio.ate } }
  if (b.prioridades !== undefined) { if (!Array.isArray(b.prioridades) || b.prioridades.some((x: any) => !(x in CATEGORIAS))) fail(400, 'Prioridades inválidas.', 'invalid', 'prioridades'); n.prioridades = [...new Set<string>(b.prioridades)] }
  return n
}
export async function salvarPrefsPred(userId: number, p: PrefsPred) {
  const ex = await one('SELECT user_id FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null)
  if (ex) await q('UPDATE user_intel_prefs SET predictive = $1, updated_at = $2 WHERE user_id = $3', [JSON.stringify(p), nowIso(), userId])
  else await q('INSERT INTO user_intel_prefs (user_id, proactive, style, predictive, updated_at) VALUES ($1,$2,$3,$4,$5)', [userId, true, '{}', JSON.stringify(p), nowIso()])
}
