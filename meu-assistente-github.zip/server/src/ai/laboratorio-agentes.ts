// Fase 9 — Laboratório de agentes. Especialistas novos (ou versões experimentais dos agentes existentes) nascem em EXPERIMENTAÇÃO:
// só rodam dentro do laboratório, com o usuário sintético e dados fictícios. Chegam à produção apenas depois de
// testados (na versão atual do texto) e aprovados por um administrador — de forma gradual (por usuário) ou total — e
// podem ser revertidos a qualquer momento. Como todos os agentes internos, só LEEM o quadro: nunca executam ações.
import { createHash } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { fail } from '../lib/http.js'
import { notify } from '../lib/notify.js'
import type { SessionUser } from '../lib/session.js'
import * as AG from './agentes.js'

export const ACESSOS: Record<string, string> = { historico: 'Conversa recente', memorias: 'Memórias do usuário', dados: 'Dados do usuário (somente leitura)', notas: 'Contribuições dos outros agentes', experiencias: 'Experiências anteriores', previsoes: 'Previsões', comercial: 'Contexto comercial (empresa)' }
export const ESTADOS: Record<string, string> = { experimental: 'Em experimentação', aguardando: 'Aguardando aprovação', gradual: 'Liberação gradual', publicado: 'Em produção', arquivado: 'Arquivado' }
const MAX_PUBLICADOS = 10
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
interface Versao { versao: number; instrucoes: string; gatilhos: string[]; acesso: string[]; em: string; por: string; publicada?: boolean }
const ler = (r: any) => ({ id: Number(r.id), slug: r.slug, base: r.base_id || null, nome: r.name, papel: r.role, instrucoes: r.instructions, gatilhos: J<string[]>(r.triggers, []), acesso: J<string[]>(r.access, []), estado: r.status, estadoLabel: ESTADOS[r.status] || r.status, pct: Number(r.rollout_pct || 0), versao: Number(r.version), versoes: J<Versao[]>(r.versions, []), ultimoTeste: J<any>(r.last_test, null), historico: J<any[]>(r.history, []), criadoEm: String(r.created_at), atualizadoEm: String(r.updated_at) })
export type LabAgente = ReturnType<typeof ler>

/* ---------- produção: especialistas publicados (cache curto; invalidado em toda decisão) ---------- */
let cache = { em: 0, rows: [] as LabAgente[] }
export const limparCache = () => { cache = { em: 0, rows: [] } }
async function ativos() {
  if (Date.now() - cache.em < 60_000) return cache.rows
  const rows = ((await q("SELECT * FROM lab_agents WHERE status IN ('gradual','publicado')").catch(() => [])) as any[]).map(ler)
  cache = { em: Date.now(), rows }; return rows
}
const balde = (userId: number, id: number) => parseInt(createHash('sha256').update(`lab-agente:${id}:${userId}`).digest('hex').slice(0, 8), 16) % 100
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
function gatilhoDe(gs: string[]) { const ws = gs.map((g) => nrm(g).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()).filter((w) => w.length >= 3); return ws.length ? new RegExp(`\\b(${ws.map((w) => esc(w).replace(/ /g, '\\s+')).join('|')})\\w*`) : /$^/ }
export function paraAgente(x: LabAgente, v?: Versao): AG.Agente {
  const ver = v || { versao: x.versao, instrucoes: x.instrucoes, gatilhos: x.gatilhos, acesso: x.acesso } as Versao
  const base = x.base ? AG.AGENTES.find((a) => a.id === x.base) : null
  const ve = ver.acesso.filter((a) => ACESSOS[a]) as any
  return { id: base ? base.id : 'lab:' + x.slug, nome: base ? base.nome : x.nome, papel: base ? base.papel : x.papel, onda: base ? base.onda : 2, tarefa: base ? base.tarefa : 'analise', gatilho: base ? base.gatilho : gatilhoDe(ver.gatilhos), ve, instrucao: ver.instrucoes, base: x.base || undefined, versaoLab: ver.versao, labId: x.id } as any
}
/** Agentes do Laboratório que valem para este usuário: os publicados e, na liberação gradual, só o grupo sorteado (estável por usuário). */
export async function publicadosPara(userId: number, sandbox: boolean): Promise<AG.Agente[]> {
  const out: AG.Agente[] = []
  for (const x of await ativos()) {
    const pub = x.versoes.find((v) => v.publicada); if (!pub) continue
    if (x.estado === 'publicado' || (x.estado === 'gradual' && !sandbox && userId > 0 && balde(userId, x.id) < x.pct)) out.push(paraAgente(x, pub))
  }
  return out
}
/** Para experimentos: a versão em edição (rascunho) dos especialistas escolhidos. */
export async function paraVariante(ids: number[]) {
  const ok = ids.filter((n) => Number.isInteger(n) && n > 0); if (!ok.length) return []
  const rows = ((await q(`SELECT * FROM lab_agents WHERE id IN (${ok.map((_, i) => '$' + (i + 1)).join(',')}) AND status <> 'arquivado'`, ok)) as any[]).map(ler)
  if (rows.length !== ok.length) fail(404, 'Especialista do laboratório não encontrado (ou arquivado).', 'not_found')
  return rows.map((x) => paraAgente(x))
}

/* ---------- cadastro ---------- */
async function obter(id: number) { if (!Number.isInteger(id) || id <= 0) fail(400, 'Especialista inválido.', 'invalid'); const r = await one('SELECT * FROM lab_agents WHERE id = $1', [id]); if (!r) fail(404, 'Especialista não encontrado.', 'not_found'); return ler(r) }
async function validar(b: any, base: string | null) {
  const L = await import('./lab.js'), LB = await import('./laboratorio.js')
  const nome = String(b.nome ?? '').trim(), papel = String(b.papel ?? '').trim(), instrucoes = String(b.instrucoes ?? '').trim()
  if (nome.length < 3 || nome.length > 60) fail(400, 'Nome: de 3 a 60 caracteres.', 'invalid', 'nome')
  if (papel.length < 3 || papel.length > 80) fail(400, 'Papel: de 3 a 80 caracteres (ex.: "nutrição e saúde").', 'invalid', 'papel')
  if (instrucoes.length < 20 || instrucoes.length > 1500) fail(400, 'Instruções: de 20 a 1.500 caracteres.', 'invalid', 'instrucoes')
  const gatilhos = [...new Set((Array.isArray(b.gatilhos) ? b.gatilhos : String(b.gatilhos || '').split(/[,\n]/)).map((g: any) => String(g).trim().toLowerCase()).filter((g: string) => g.length >= 3 && g.length <= 30))].slice(0, 20) as string[]
  if (!base && !gatilhos.length) fail(400, 'Informe pelo menos uma palavra que aciona o especialista (mín. 3 letras).', 'invalid', 'gatilhos')
  const acesso = [...new Set((Array.isArray(b.acesso) ? b.acesso : []).map(String))] as string[]
  for (const a of acesso) if (!ACESSOS[a]) fail(400, `Acesso inválido: ${a}.`, 'invalid', 'acesso')
  const riscos = L.riscosDe(`${nome} ${papel} ${instrucoes}`); if (riscos.length) fail(400, riscos.join(' '), 'risco')
  if (/\b(ignore|desconsidere) (as )?(regras|instrucoes|orientacoes)( anteriores| do sistema)?\b/.test(nrm(instrucoes))) fail(400, 'As instruções não podem mandar ignorar as regras do sistema.', 'risco')
  if (LB.pareceDadoPessoal(`${nome} ${papel} ${instrucoes} ${gatilhos.join(' ')}`)) fail(400, 'O texto parece conter um dado pessoal real. Use só dados fictícios.', 'dado_pessoal')
  return { nome, papel, instrucoes, gatilhos, acesso }
}
const evento = (x: { historico: any[] }, por: string, ev: string, nota = '') => JSON.stringify([...x.historico, { em: nowIso(), evento: ev, por, nota: nota.slice(0, 300) }].slice(-100))
export async function criar(admin: SessionUser, b: any) {
  const v = await validar(b, null), agora = nowIso(), por = admin.name || 'administrador'
  const n = Number((await one("SELECT COUNT(*) AS n FROM lab_agents WHERE status <> 'arquivado'"))?.n || 0); if (n >= 40) fail(409, 'Limite de 40 especialistas no laboratório (arquive os que não usa).', 'limit')
  const slug = nrm(v.nome).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) + '-' + Date.now().toString(36).slice(-4)
  const r = await one('INSERT INTO lab_agents (slug, base_id, name, role, instructions, triggers, access, status, rollout_pct, version, versions, history, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$14) RETURNING id',
    [slug, null, v.nome, v.papel, v.instrucoes, JSON.stringify(v.gatilhos), JSON.stringify(v.acesso), 'experimental', 0, 1, JSON.stringify([{ versao: 1, ...v, em: agora, por }]), JSON.stringify([{ em: agora, evento: 'criado em experimentação', por }]), admin.id, agora])
  limparCache(); return obter(Number(r!.id))
}
/** Cópia experimental de um agente existente: ajustar instruções e acesso e comparar com o original antes de trocar. */
export async function clonar(admin: SessionUser, baseId: string) {
  const a = AG.AGENTES.find((x) => x.id === baseId); if (!a) fail(404, 'Agente não encontrado.', 'not_found')
  const agora = nowIso(), por = admin.name || 'administrador', v = { nome: `${a!.nome} (experimental)`, papel: a!.papel, instrucoes: a!.instrucao, gatilhos: [] as string[], acesso: [...a!.ve] }
  const r = await one('INSERT INTO lab_agents (slug, base_id, name, role, instructions, triggers, access, status, rollout_pct, version, versions, history, created_by, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$14) RETURNING id',
    [`${a!.id}-exp-${Date.now().toString(36).slice(-4)}`, a!.id, v.nome, v.papel, v.instrucoes, '[]', JSON.stringify(v.acesso), 'experimental', 0, 1, JSON.stringify([{ versao: 1, ...v, em: agora, por }]), JSON.stringify([{ em: agora, evento: `cópia experimental de "${a!.nome}"`, por }]), admin.id, agora])
  return obter(Number(r!.id))
}
/** Editar cria uma nova versão (rascunho). Em produção continua a versão publicada até a nova ser testada e aprovada. */
export async function editar(admin: SessionUser, id: number, b: any) {
  const x = await obter(id); if (x.estado === 'arquivado') fail(409, 'Desarquive o especialista para editar.', 'invalid_state')
  if (b.versao !== undefined && Number(b.versao) !== x.versao) fail(409, 'O especialista foi alterado por outra pessoa. Recarregue antes de editar.', 'conflict')
  const v = await validar({ nome: x.nome, papel: x.papel, instrucoes: x.instrucoes, gatilhos: x.gatilhos, acesso: x.acesso, ...Object.fromEntries(Object.entries(b || {}).filter(([, y]) => y !== undefined)) }, x.base), agora = nowIso(), por = admin.name || 'administrador', nv = x.versao + 1
  const estado = x.estado === 'aguardando' ? 'experimental' : x.estado // texto novo: a aprovação pedida valia para o texto anterior
  const r: any = await q('UPDATE lab_agents SET name = $1, role = $2, instructions = $3, triggers = $4, access = $5, version = $6, versions = $7, last_test = $8, status = $9, history = $10, updated_at = $11 WHERE id = $12 AND version = $13 RETURNING id',
    [v.nome, v.papel, v.instrucoes, JSON.stringify(v.gatilhos), JSON.stringify(v.acesso), nv, JSON.stringify([...x.versoes, { versao: nv, ...v, em: agora, por }].slice(-30)), null, estado, evento(x, por, `editado (v${nv})`, ['gradual', 'publicado'].includes(x.estado) ? `em produção continua a v${x.versoes.find((y) => y.publicada)?.versao}` : ''), agora, id, x.versao])
  if (!r?.length) fail(409, 'O especialista foi alterado por outra pessoa. Recarregue.', 'conflict')
  limparCache(); return obter(id)
}
export async function registrarTeste(id: number, resumo: any) {
  const x = await obter(id)
  await q('UPDATE lab_agents SET last_test = $1, history = $2, updated_at = $3 WHERE id = $4', [JSON.stringify({ ...resumo, versao: x.versao, em: nowIso() }), evento(x, 'laboratório', `teste (${resumo.tipo || 'individual'}) da v${x.versao}`), nowIso(), id])
}

/* ---------- testes: individual, comparação e colaboração (sempre sintéticos) ---------- */
interface Cenario { historico?: { papel: string; texto: string }[]; memorias?: string[]; dados?: Record<string, any> }
async function cenarioValido(prompt: string, c: Cenario) {
  const LB = await import('./laboratorio.js')
  const v = LB.validarDesafio({ categoria: 'contexto', titulo: 'Teste de agente', prompt, contexto: c || {}, criterios: [{ tipo: 'sem_escrita' }] })
  return v
}
async function resolver(ref: string | number): Promise<{ agente: AG.Agente; labId: number | null; rotulo: string }> {
  const s = String(ref)
  if (/^\d+$/.test(s)) { const x = await obter(Number(s)); if (x.estado === 'arquivado') fail(409, 'Especialista arquivado.', 'invalid_state'); return { agente: paraAgente(x), labId: x.id, rotulo: `${x.nome} · v${x.versao} (laboratório)` } }
  const a = AG.AGENTES.find((y) => y.id === s); if (!a) fail(404, `Agente "${s}" não encontrado.`, 'not_found')
  return { agente: a!, labId: null, rotulo: `${a!.nome} (em produção)` }
}
function quadro(prompt: string, v: Awaited<ReturnType<typeof cenarioValido>>, tipo: string): AG.Quadro {
  return { pedido: prompt, intencao: tipo, complexidade: 'complexa', dominios: [], plano: [], memorias: v.contexto.memorias || [], experiencias: [], dados: Object.fromEntries(Object.entries(v.contexto.dados || {}).map(([k, d]) => [k, JSON.stringify(d).slice(0, 2500)])), historico: (v.contexto.historico || []).map((m) => `${m.papel === 'assistente' ? 'Assistente' : 'Usuário'}: ${m.texto}`).join('\n'), comercial: '', notas: {} }
}
async function checar(texto: string, prompt: string, v: Awaited<ReturnType<typeof cenarioValido>>) {
  const AV = await import('./autoverificacao.js')
  const fontes = prompt + ' ' + JSON.stringify(v.contexto) , inventados = AV.valoresDivergentes(texto, fontes)
  const linhas = texto.split('\n').filter((l) => l.trim()).length
  return { valoresSemFonte: inventados, linhas, dentroDoLimite: linhas <= 12, falaComUsuario: /\b(ola|oi|espero ter ajudado|posso ajudar)\b/.test(nrm(texto)), ok: !inventados.length && linhas <= 12 && !/\b(ola|oi|espero ter ajudado|posso ajudar)\b/.test(nrm(texto)) }
}
async function registrarRodada(kind: string, rotulo: string, config: any, results: any, admin: SessionUser, nota: number | null, total: number, aprovados: number) {
  const r = await one('INSERT INTO lab_runs (kind, label, config, results, score, total, passed, status, progress, started_by, created_at, finished_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$11) RETURNING id',
    [kind, rotulo.slice(0, 120), JSON.stringify(config), JSON.stringify(results), nota, total, aprovados, 'concluida', 100, admin.id, nowIso()])
  return Number(r!.id)
}
export async function testar(admin: SessionUser, refs: (string | number)[], prompt: string, c: Cenario = {}) {
  const lista = [...new Set(refs.map(String))].slice(0, 4); if (!lista.length) fail(400, 'Escolha pelo menos um agente.', 'invalid')
  const v = await cenarioValido(prompt, c), COG = await import('./cognition.js'), tipo = COG.analisar(prompt).tipo
  const ags = await Promise.all(lista.map(resolver)), nomes = AG.mesclar(ags.map((a) => a.agente).filter((a) => !AG.AGENTES.includes(a)))
  const res = await Promise.all(ags.map(async (a) => { const r = await AG.contribuir(a.agente, quadro(v.prompt, v, tipo), v.prompt, 15000, nomes); return { ref: a.labId ?? a.agente.id, rotulo: a.rotulo, ok: r.ok, texto: r.texto, ms: r.ms, motivo: r.motivo || null, verificacao: r.ok ? await checar(r.texto, v.prompt, v) : null } }))
  const aprov = res.filter((r) => r.ok && r.verificacao?.ok).length
  const rid = await registrarRodada('agente', (lista.length > 1 ? 'Comparação · ' : 'Teste · ') + ags.map((a) => a.agente.nome).join(' × '), { agentes: lista, prompt: v.prompt, contexto: v.contexto }, { contribuicoes: res }, admin, Math.round((aprov / res.length) * 100), res.length, aprov)
  for (const [i, a] of ags.entries()) if (a.labId) await registrarTeste(a.labId, { tipo: lista.length > 1 ? 'comparacao' : 'individual', rodada: rid, ok: res[i].ok && !!res[i].verificacao?.ok })
  return { rodada: rid, contribuicoes: res, semEfeitoReal: true }
}
/** Colaboração: o assistente completo (modo simulação) com os agentes escolhidos forçados, inclusive os experimentais. */
export async function colaboracao(admin: SessionUser, refs: (string | number)[], prompt: string, c: Cenario = {}) {
  const lista = [...new Set(refs.map(String))].slice(0, 4); if (lista.length < 2) fail(400, 'Escolha de 2 a 4 agentes para testar a colaboração.', 'invalid')
  const v = await cenarioValido(prompt, c), LB = await import('./laboratorio.js'), ags = await Promise.all(lista.map(resolver))
  const atual = await LB.montarVariante(null), extras = ags.filter((a) => a.labId).map((a) => a.agente)
  const V = { ...atual, nome: 'Colaboração', agentes: [...atual.agentes.filter((p) => !extras.some((e) => e.id === p.id)), ...extras] }
  const { runAssistant } = await import('./assistant.js'), POL = await import('./politica.js')
  const sb = { calls: [] as any[], memorias: v.contexto.memorias || [], dados: v.contexto.dados || {}, agentes: V.agentes, forcarAgentes: ags.map((a) => a.agente.id), trace: {} as any }
  const hist = (v.contexto.historico || []).map((m) => ({ role: m.papel === 'assistente' ? 'assistant' : 'user', content: m.texto })) as any[]
  let resposta = '', erro = ''; const t0 = Date.now()
  try { resposta = String((await POL.comPolitica(V.politica, () => runAssistant(LB.USUARIO_LAB, hist, v.prompt, undefined, '', undefined, sb as any, ''))).content || '') } catch (e: any) { erro = String(e?.message || 'A IA não respondeu.').slice(0, 200) }
  const o = sb.trace.orquestracao || { agentes: [], notas: {}, divergencias: [] }
  const contribuicoes = ags.map((a) => { const st = (o.agentes || []).find((x: any) => x.id === a.agente.id); return { ref: a.labId ?? a.agente.id, rotulo: a.rotulo, ok: !!st?.ok, ms: st?.ms ?? null, motivo: st?.motivo || (st ? null : 'não foi acionado'), texto: o.notas?.[a.agente.id] || '' } })
  const AGm = await import('./agentes.js'), mencionaAgentes = AGm.unificar(resposta, ags.map((a) => a.agente.nome)).ajustou
  const okN = contribuicoes.filter((x) => x.ok).length
  const res = { resposta: resposta.slice(0, 2000), erro: erro || null, contribuicoes, divergencias: o.divergencias || [], respostaUnica: !mencionaAgentes, ms: Date.now() - t0, acoes: sb.calls.map((x: any) => ({ ferramenta: x.name, dados: x.args })) }
  const rid = await registrarRodada('colaboracao', 'Colaboração · ' + ags.map((a) => a.agente.nome).join(' + '), { agentes: lista, prompt: v.prompt, contexto: v.contexto }, res, admin, Math.round((okN / contribuicoes.length) * 100), contribuicoes.length, okN)
  for (const a of ags) if (a.labId) await registrarTeste(a.labId, { tipo: 'colaboracao', rodada: rid, ok: !erro && contribuicoes.find((x) => x.ref === a.labId)?.ok })
  return { rodada: rid, ...res, semEfeitoReal: true }
}

/* ---------- aprovação, publicação gradual e reversão ---------- */
export async function decidir(admin: SessionUser, id: number, acao: string, o: { modo?: string; pct?: number; versao?: number; nota?: string; confirmar?: boolean } = {}): Promise<any> {
  const x = await obter(id), por = admin.name || 'administrador', agora = nowIso(), nota = String(o.nota || '').slice(0, 300)
  const salvar = async (cols: Record<string, any>, ev: string) => {
    const ks = Object.keys(cols), r: any = await q(`UPDATE lab_agents SET ${ks.map((k, i) => `${k} = $${i + 1}`).join(', ')}, history = $${ks.length + 1}, updated_at = $${ks.length + 2} WHERE id = $${ks.length + 3} AND version = $${ks.length + 4} AND status = $${ks.length + 5} RETURNING id`,
      [...ks.map((k) => cols[k]), evento(x, por, ev, nota), agora, id, x.versao, x.estado])
    if (!r?.length) fail(409, 'O especialista mudou enquanto você decidia. Recarregue.', 'conflict')
    limparCache(); return obter(id)
  }
  const testado = x.ultimoTeste && Number(x.ultimoTeste.versao) === x.versao
  switch (acao) {
    case 'enviar': if (x.estado !== 'experimental') fail(409, 'Só um especialista em experimentação pode ser enviado para aprovação.', 'invalid_state'); if (!testado) fail(409, `Teste a versão atual (v${x.versao}) antes de enviar para aprovação.`, 'sem_teste')
      if (x.ultimoTeste.ok === false && !o.confirmar) return { ok: false, precisaConfirmar: true, motivo: 'O último teste desta versão encontrou problemas. Envie mesmo assim só se você revisou o resultado.' }
      return salvar({ status: 'aguardando' }, x.ultimoTeste.ok === false ? 'enviado para aprovação (com teste com problemas, confirmado)' : 'enviado para aprovação')
    case 'rejeitar': if (x.estado !== 'aguardando') fail(409, 'Não há aprovação pendente.', 'invalid_state'); return salvar({ status: 'experimental' }, 'aprovação recusada')
    case 'aprovar': {
      if (x.estado !== 'aguardando') fail(409, 'Envie para aprovação antes de aprovar.', 'invalid_state')
      if (!testado) fail(409, 'O último teste não é da versão atual.', 'sem_teste')
      if (x.base) { const outro = await one("SELECT id FROM lab_agents WHERE base_id = $1 AND status IN ('gradual','publicado') AND id <> $2", [x.base, id]); if (outro) fail(409, 'Já existe outra versão deste agente em produção. Reverta-a antes.', 'busy') }
      if (Number((await one("SELECT COUNT(*) AS n FROM lab_agents WHERE status IN ('gradual','publicado')"))?.n || 0) >= MAX_PUBLICADOS) fail(409, `Limite de ${MAX_PUBLICADOS} especialistas do laboratório em produção.`, 'limit')
      const total = o.modo === 'total', pct = Math.round(Number(o.pct ?? 20)); if (!total && !(pct >= 5 && pct <= 90)) fail(400, 'Liberação gradual: de 5% a 90% dos usuários.', 'invalid', 'pct')
      const versoes = x.versoes.map((v) => ({ ...v, publicada: v.versao === x.versao }))
      return salvar({ status: total ? 'publicado' : 'gradual', rollout_pct: total ? 100 : pct, versions: JSON.stringify(versoes) }, total ? `publicado para todos (v${x.versao})` : `liberação gradual para ${pct}% (v${x.versao})`)
    }
    case 'promover': if (x.estado !== 'gradual') fail(409, 'Só a liberação gradual pode ser promovida.', 'invalid_state'); return salvar({ status: 'publicado', rollout_pct: 100 }, 'promovido para todos')
    case 'reverter': if (!['gradual', 'publicado'].includes(x.estado)) fail(409, 'O especialista não está em produção.', 'invalid_state'); return salvar({ status: 'experimental', rollout_pct: 0, versions: JSON.stringify(x.versoes.map((v) => ({ ...v, publicada: false }))) }, 'retirado da produção (revertido)')
    case 'arquivar': if (!['experimental', 'aguardando'].includes(x.estado)) fail(409, 'Retire da produção antes de arquivar.', 'invalid_state'); return salvar({ status: 'arquivado' }, 'arquivado')
    case 'desarquivar': if (x.estado !== 'arquivado') fail(409, 'O especialista não está arquivado.', 'invalid_state'); return salvar({ status: 'experimental' }, 'desarquivado')
    case 'restaurar': { // uma versão anterior volta a ser o rascunho (precisa de teste e aprovação de novo)
      const v = x.versoes.find((y) => y.versao === Number(o.versao)); if (!v) fail(404, 'Versão não encontrada.', 'not_found')
      if (x.estado === 'arquivado') fail(409, 'Desarquive antes.', 'invalid_state')
      return editar(admin, id, { nome: x.nome, papel: x.papel, instrucoes: v!.instrucoes, gatilhos: v!.gatilhos, acesso: v!.acesso, versao: x.versao })
    }
  }
  fail(400, 'Ação inválida.', 'invalid')
}

/* ---------- visão do laboratório de agentes e vigilância ---------- */
export async function estatisticas() {
  const rows = (await q('SELECT level2, created_at FROM cognition_evals WHERE level2 IS NOT NULL ORDER BY id DESC LIMIT 3000').catch(() => [])) as any[]
  const por: Record<string, { acionamentos: number; ok: number; ms: number; desde: Record<string, number> }> = {}
  for (const r of rows) for (const a of J<any>(r.level2, {})?.multiagente?.agentes || []) { const x = (por[a.id] ||= { acionamentos: 0, ok: 0, ms: 0, desde: {} }); x.acionamentos++; if (a.ok) x.ok++; x.ms += Number(a.ms) || 0 }
  return Object.fromEntries(Object.entries(por).map(([k, x]) => [k, { acionamentos: x.acionamentos, sucesso: Math.round((x.ok / x.acionamentos) * 100), msMedio: Math.round(x.ms / x.acionamentos) }]))
}
export async function visao() {
  const ESP = await import('./especialistas.js'), AVAL = await import('./avaliacao.js'), cfg = await AG.maCfg(), st = await estatisticas(), ind = await AVAL.indicadores().catch(() => null)
  const lab = ((await q('SELECT * FROM lab_agents ORDER BY id DESC LIMIT 100').catch(() => [])) as any[]).map(ler)
  return {
    agentes: AG.AGENTES.map((a) => ({ id: a.id, nome: a.nome, papel: a.papel, onda: a.onda, acesso: a.ve, instrucoes: a.instrucao, ligado: cfg.agentes[a.id] !== false, pausado: AG.pausado(a.id), versaoLab: lab.find((x) => x.base === a.id && ['gradual', 'publicado'].includes(x.estado)) ? { id: lab.find((x) => x.base === a.id && ['gradual', 'publicado'].includes(x.estado))!.id } : null, producao: st[a.id] || null })),
    fluxo: AG.AGENTES_FLUXO, especialistas: ESP.ESPECIALISTAS.map((e) => ({ id: e.id, nome: e.nome, producao: ind?.especialistas.find((x: any) => x.id === e.id) || null })),
    laboratorio: lab.map((x) => ({ ...x, producao: st[x.base || 'lab:' + x.slug] || null, emProducao: x.versoes.find((v) => v.publicada)?.versao ?? null })),
    acessos: ACESSOS, estados: ESTADOS, multiagente: { ativo: cfg.ativo, maxAgentes: cfg.maxAgentes },
  }
}
/** Liberação gradual de especialista com resultado ruim em produção é encerrada sozinha (volta a experimental) e avisa. */
export async function vigiarAgentes() {
  const st = await estatisticas(), alertas: string[] = []
  for (const x of (await ativos())) {
    const s = st[x.base || 'lab:' + x.slug]; if (!s || s.acionamentos < 10) continue
    if (s.sucesso < 50) {
      if (x.estado === 'gradual') {
        await q("UPDATE lab_agents SET status = 'experimental', rollout_pct = 0, versions = $1, history = $2, updated_at = $3 WHERE id = $4 AND status = 'gradual'", [JSON.stringify(x.versoes.map((v) => ({ ...v, publicada: false }))), evento(x, 'sistema', 'liberação gradual encerrada automaticamente', `sucesso ${s.sucesso}% em ${s.acionamentos} acionamentos`), nowIso(), x.id])
        alertas.push(`O especialista "${x.nome}" teve ${s.sucesso}% de sucesso em ${s.acionamentos} acionamentos: a liberação gradual foi encerrada.`)
      } else alertas.push(`O especialista "${x.nome}" está com ${s.sucesso}% de sucesso em produção (${s.acionamentos} acionamentos). Avalie reverter.`)
    }
  }
  if (alertas.length) {
    limparCache()
    for (const a of await q("SELECT id FROM users WHERE role IN ('admin','superadmin') AND status = 'active'").catch(() => [] as any[]))
      await notify(Number(a.id), { type: 'sistema', title: 'Laboratório: especialista com resultado ruim', body: alertas.join(' '), link: '/admin/laboratorio#agentes', ref: `lab-agentes-${nowIso().slice(0, 10)}` }).catch(() => {})
  }
  return { alertas }
}
