// CRM no Chat Principal: a IA consulta e opera SOMENTE pelos serviços reais do CRM (lib/crm.ts), que validam empresa do dono,
// plano, permissões e regras de negócio e gravam auditoria (canal "chat"). Nada é decidido só por prompt.
import { q, one, J } from '../db/index.js'
import { modules } from '../lib/usermod.js'
import * as K from '../lib/crm.js'
import { HttpError } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'
import type { ToolDef } from './provider.js'

const emp = { type: 'string', description: 'nome da empresa (só se o usuário tiver mais de uma)' }
export const CRM_TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'crm_buscar_cliente', description: 'Procura clientes/leads no CRM da empresa por nome, telefone, e-mail ou empresa. Use para saber se a pessoa JÁ existe antes de criar qualquer lead.', parameters: { type: 'object', properties: { empresa: emp, busca: { type: 'string' } }, required: ['busca'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_historico_cliente', description: 'Ficha completa de um cliente/lead: dados, pedidos e agendamentos relacionados, oportunidades, tarefas e linha do tempo de relacionamento.', parameters: { type: 'object', properties: { empresa: emp, cliente: { type: 'string', description: 'nome, telefone, e-mail ou id do contato' } }, required: ['cliente'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_oportunidades', description: 'Lista oportunidades comerciais (abertas, ganhas ou perdidas) com etapa, valor e probabilidade, e os indicadores do funil.', parameters: { type: 'object', properties: { empresa: emp, situacao: { type: 'string', enum: ['aberta', 'ganha', 'perdida'] }, busca: { type: 'string' } }, additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_inteligencia', description: 'Análises comerciais com critérios transparentes: leads sem acompanhamento, oportunidades paradas, próximas do fechamento, clientes para retorno, recorrentes, motivos de perda e desempenho. Use para recomendar ações.', parameters: { type: 'object', properties: { empresa: emp }, additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_registrar_observacao', description: 'Registra uma observação ou interação (ligação, WhatsApp, reunião…) na ficha de um cliente existente. Só quando o usuário pedir.', parameters: { type: 'object', properties: { empresa: emp, cliente: { type: 'string' }, texto: { type: 'string' }, canal: { type: 'string', enum: ['ligacao', 'whatsapp', 'email', 'reuniao', 'presencial', 'outro'] } }, required: ['cliente', 'texto'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_criar_lead', description: 'Cadastra um lead/cliente no CRM. O sistema reaproveita o cadastro se já existir (telefone/e-mail iguais, mesmo com variações). Só quando o usuário pedir e a empresa permitir.', parameters: { type: 'object', properties: { empresa: emp, nome: { type: 'string' }, telefone: { type: 'string' }, email: { type: 'string' }, origem: { type: 'string' }, observacao: { type: 'string' } }, required: ['nome'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_criar_oportunidade', description: 'Cria uma oportunidade comercial para um cliente existente no funil.', parameters: { type: 'object', properties: { empresa: emp, cliente: { type: 'string' }, titulo: { type: 'string' }, valor: { type: 'number' }, previsao_fechamento: { type: 'string', description: 'AAAA-MM-DD' }, probabilidade: { type: 'number' } }, required: ['cliente', 'titulo'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_atualizar_etapa', description: 'Move uma oportunidade para outra etapa do funil (inclui concluir a venda ou marcar como perdida, que EXIGE o motivo). Só quando o usuário pedir e a empresa permitir.', parameters: { type: 'object', properties: { empresa: emp, oportunidade: { type: 'string', description: 'id ou parte do título' }, etapa: { type: 'string', description: 'nome da etapa de destino' }, motivo_perda: { type: 'string' } }, required: ['oportunidade', 'etapa'], additionalProperties: false } } },
  { type: 'function', function: { name: 'crm_criar_tarefa', description: 'Cria uma tarefa/acompanhamento do CRM (contato, retorno, proposta, confirmar, acompanhamento, reunião) para um cliente ou oportunidade, com prazo e prioridade.', parameters: { type: 'object', properties: { empresa: emp, titulo: { type: 'string' }, cliente: { type: 'string' }, prazo: { type: 'string', description: 'AAAA-MM-DD ou AAAA-MM-DDTHH:MM' }, prioridade: { type: 'string', enum: ['baixa', 'media', 'alta'] }, tipo: { type: 'string', enum: ['contato', 'retorno', 'proposta', 'confirmar', 'acompanhamento', 'reuniao', 'outra'] } }, required: ['titulo'], additionalProperties: false } } },
]
export const CRM_NAMES = new Set(CRM_TOOLS.map((t) => t.function.name))
export const CRM_READ = new Set(['crm_buscar_cliente', 'crm_historico_cliente', 'crm_oportunidades', 'crm_inteligencia'])

const nrm = (s: any) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()
/** Empresas do usuário onde o CRM está liberado (dono, ativa, plano com loja, módulo ligado). */
export async function empresasCrm(userId: number) {
  if ((await modules()).crm === false) return []
  const out: { id: number; nome: string }[] = []
  for (const b of await q("SELECT id, data FROM businesses WHERE owner_id = $1 AND status = 'ativo' ORDER BY id", [userId]) as any[]) { try { await K.acesso(userId, Number(b.id)); out.push({ id: Number(b.id), nome: J<any>(b.data, {}).empresa || `Empresa #${b.id}` }) } catch { /* sem CRM nesta empresa */ } }
  return out
}
export const crmDisponivel = async (u: SessionUser) => (await empresasCrm(u.id)).length > 0

async function escolher(u: SessionUser, nome?: string) {
  const l = await empresasCrm(u.id); if (!l.length) return { erro: 'Você não tem empresa com CRM disponível (precisa de empresa ativa em plano com loja).' }
  if (nome) { const m = l.filter((e) => nrm(e.nome).includes(nrm(nome))); if (m.length === 1) return { e: m[0] }; return { erro: `Não identifiquei a empresa "${nome}". Empresas: ${l.map((e) => e.nome).join(', ')}.` } }
  if (l.length === 1) return { e: l[0] }
  return { erro: `Qual empresa? ${l.map((e) => e.nome).join(', ')}.` }
}
async function acharContato(bid: number, ref: any) {
  const s = String(ref ?? '').trim(); if (!s) return { erro: 'Informe o cliente.' }
  if (/^\d{1,9}$/.test(s)) { try { return { c: await K.CustomerRelationshipService.obter(bid, Number(s)) } } catch { /* tenta como busca */ } }
  const l = await K.CustomerRelationshipService.listar(bid, { busca: s })
  if (l.length === 1) return { c: await K.CustomerRelationshipService.obter(bid, l[0].id) }
  if (!l.length) return { erro: `Nenhum cliente encontrado para "${s}". Pergunte se deseja cadastrar como lead.` }
  return { erro: `Mais de um cliente para "${s}": ${l.slice(0, 6).map((c) => `${c.nome} (#${c.id}${c.telefone ? ', ' + c.telefone : ''})`).join('; ')}. Peça para especificar.` }
}
const resumoContato = (c: any) => ({ id: c.id, nome: c.nome, tipo: c.tipo, telefone: c.telefone, email: c.email, origem: c.origem, categoria: c.categoria, etiquetas: c.etiquetas, responsavel: c.responsavel, compras: c.compras, recorrente: c.recorrente, oportunidadesAbertas: c.oportunidadesAbertas })

export async function runCrmTool(u: SessionUser, name: string, a: any): Promise<any> {
  const p = await escolher(u, a.empresa); if (!p.e) return { ok: false, error: p.erro }
  const bid = p.e.id, ator: K.Ator = { id: u.id, nome: u.name, via: 'chat' }, cfg = await K.config(bid)
  try {
    switch (name) {
      case 'crm_buscar_cliente': { const l = await K.CustomerRelationshipService.listar(bid, { busca: String(a.busca || '') }); return { ok: true, empresa: p.e.nome, total: l.length, clientes: l.slice(0, 10).map(resumoContato) } }
      case 'crm_historico_cliente': {
        const r = await acharContato(bid, a.cliente); if (!r.c) return { ok: false, error: r.erro }
        const f = await K.CustomerRelationshipService.perfil(bid, Number(r.c.id))
        return { ok: true, empresa: p.e.nome, contato: f.contato, compras: f.compras, pedidos: f.pedidos.slice(0, 10), oportunidades: f.oportunidades, tarefasAbertas: f.tarefas.filter((t) => t.situacao === 'aberta'), linhaDoTempo: f.linhaDoTempo.slice(0, 15) }
      }
      case 'crm_oportunidades': {
        const l = await K.OpportunityService.listar(bid, { situacao: a.situacao, busca: a.busca }), ind = await K.CommercialIntelligenceService.indicadores(bid)
        return { ok: true, empresa: p.e.nome, indicadores: { abertas: ind.oportunidadesAbertas, valorEmAberto: ind.valorOportunidades, ganhas: ind.negociacoesConcluidas, perdidas: ind.negociacoesPerdidas, conversaoPct: ind.taxaConversao }, oportunidades: l.slice(0, 15) }
      }
      case 'crm_inteligencia': { const an = await K.CommercialIntelligenceService.analise(bid); const cut = (l: any[]) => l.slice(0, 8); return { ok: true, empresa: p.e.nome, criterios: an.criterios, leadsSemAcompanhamento: cut(an.leadsSemAcompanhamento), oportunidadesParadas: cut(an.oportunidadesParadas), proximasDoFechamento: cut(an.proximasDoFechamento), clientesParaRetorno: cut(an.clientesParaRetorno), maiorProbabilidade: an.maiorProbabilidade, clientesRecorrentes: cut(an.clientesRecorrentes), motivosDePerda: cut(an.motivosDePerda), desempenho: an.desempenho } }
      case 'crm_registrar_observacao': {
        const r = await acharContato(bid, a.cliente); if (!r.c) return { ok: false, error: r.erro }
        await K.CustomerRelationshipService.registrar(bid, Number(r.c.id), { tipo: a.canal ? 'interacao' : 'observacao', canal: a.canal, texto: a.texto }, ator); return { ok: true, registrado: true, cliente: r.c.name }
      }
      case 'crm_criar_lead': {
        if (!cfg.iaCriarLeads) return { ok: false, error: 'O dono desativou a criação de leads pelo chat (Sua empresa → CRM → Configurações). Peça para cadastrar pelo painel.' }
        const r = await K.CustomerRelationshipService.salvar(bid, { nome: a.nome, telefone: a.telefone, email: a.email, origem: a.origem || 'chat', observacoes: a.observacao }, ator, 'chat')
        return { ok: true, reutilizado: r.reutilizado, contato: resumoContato(r.contato), aviso: r.reutilizado ? 'Já existia no CRM: o cadastro foi reaproveitado, nada foi duplicado.' : undefined }
      }
      case 'crm_criar_oportunidade': {
        const r = await acharContato(bid, a.cliente); if (!r.c) return { ok: false, error: r.erro }
        const o = await K.OpportunityService.criar(bid, { contatoId: Number(r.c.id), titulo: a.titulo, valor: a.valor, previsaoFechamento: a.previsao_fechamento, probabilidade: a.probabilidade }, ator); return { ok: true, oportunidade: o }
      }
      case 'crm_atualizar_etapa': {
        if (!cfg.iaMoverEtapas) return { ok: false, error: 'O dono desativou a movimentação de etapas pelo chat (Sua empresa → CRM → Configurações). Mova pelo painel.' }
        const ops = await K.OpportunityService.listar(bid, {}), s = String(a.oportunidade || '').trim()
        const m = /^\d+$/.test(s) ? ops.filter((o) => o.id === Number(s)) : ops.filter((o) => nrm(`${o.titulo} ${o.cliente}`).includes(nrm(s)))
        if (m.length !== 1) return { ok: false, error: m.length ? `Mais de uma oportunidade: ${m.slice(0, 5).map((o) => `#${o.id} ${o.titulo} (${o.cliente})`).join('; ')}.` : `Oportunidade "${s}" não encontrada.` }
        const et = (await K.SalesPipelineService.etapas(bid)).filter((e) => nrm(e.nome) === nrm(a.etapa) || nrm(e.nome).includes(nrm(a.etapa)))
        if (et.length !== 1) return { ok: false, error: `Etapa "${a.etapa}" não identificada. Etapas: ${(await K.SalesPipelineService.etapas(bid)).map((e) => e.nome).join(', ')}.` }
        const o = await K.OpportunityService.mover(bid, m[0].id, et[0].id, { motivoPerda: a.motivo_perda }, ator); return { ok: true, oportunidade: o }
      }
      case 'crm_criar_tarefa': {
        let cid: number | undefined; if (a.cliente) { const r = await acharContato(bid, a.cliente); if (!r.c) return { ok: false, error: r.erro }; cid = Number(r.c.id) }
        const t = await K.CRMTaskService.criar(bid, { titulo: a.titulo, contatoId: cid, prazo: a.prazo, prioridade: a.prioridade, tipo: a.tipo }, ator); return { ok: true, tarefa: t }
      }
    }
    return { ok: false, error: 'Ferramenta desconhecida.' }
  } catch (e: any) { return { ok: false, error: e instanceof HttpError ? e.message : 'Falha ao executar no CRM.' } }
}

/** Contexto curto e REAL para o chat quando a conversa é sobre clientes, vendas ou CRM. */
export async function crmContext(u: SessionUser, text: string): Promise<string> {
  const l = await empresasCrm(u.id); if (!l.length) return ''
  const linhas: string[] = ['CRM (ferramentas crm_*): você consulta e opera o CRM real das empresas do usuário. Antes de criar um lead, use crm_buscar_cliente para ver se já existe. Só registre/atualize quando o usuário pedir; ao mover para "perdida" peça o motivo; nunca diga que fez algo sem a ferramenta confirmar. Dados comerciais só pelas ferramentas.']
  if (/\b(crm|lead\w*|funil|oportunidade\w*|negocia\w*|clientes?|acompanhamento\w*|proposta\w*|vend\w*|retorn\w*)\b/i.test(nrm(text))) {
    for (const e of l.slice(0, 3)) { try { const i = await K.CommercialIntelligenceService.indicadores(e.id); linhas.push(`${e.nome}: ${i.totalClientes} cliente(s), ${i.novosLeads} lead(s) novo(s) em 30 dias, ${i.oportunidadesAbertas} oportunidade(s) aberta(s) (R$ ${i.valorOportunidades.toFixed(2).replace('.', ',')}), conversão ${i.taxaConversao}%, ${i.tarefasAtrasadas} tarefa(s) atrasada(s).`) } catch { /* ignora */ } }
  }
  return linhas.join('\n')
}
