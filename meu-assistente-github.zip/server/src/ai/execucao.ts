// MOTOR DE EXECUÇÃO (Fase 8) — coordena operações reais sobre os SERVIÇOS QUE JÁ EXISTEM (itens, compromissos, contas,
// tarefas, notas/documentos e CRM), sem duplicar módulos. Cada operação do catálogo declara:
//   nível de autonomia (1 automático · 2 confirmação · 3 autorização explícita), validação, execução, VERIFICAÇÃO no
//   estado real, como localizar o resultado depois de uma queda, se pode ser repetida sem efeito duplicado e como desfazer.
// Uma EXECUÇÃO (EX-XXXXXX) guarda plano, dependências, estado, progresso e histórico — por isso continua depois de
// interrupções. Segurança: identificador único, proteção contra pedido repetido, troca de estado com controle de versão,
// validação antes de executar, registro de cada evento, classificação de erros, repetição só do que é seguro, parada
// quando houver risco de inconsistência e reversão quando tecnicamente possível. Nunca declara concluído sem verificar.
import { randomBytes, createHash } from 'node:crypto'
import { q, one, J, B, nowIso, db } from '../db/index.js'
import { fail, HttpError } from '../lib/http.js'
import type { SessionUser } from '../lib/session.js'

export type Nivel = 1 | 2 | 3
export const NIVEL_NOME: Record<number, string> = { 1: 'Automático', 2: 'Precisa de confirmação', 3: 'Precisa de autorização explícita' }
export interface Passo { n: number; op: string; rotulo: string; args: any; depende: number[]; nivel: Nivel; status: 'pendente' | 'executando' | 'feito' | 'falhou' | 'bloqueado' | 'pulado' | 'cancelado' | 'incerto' | 'revertido'; tentativas: number; erro?: string; classe?: string; resultado?: any; verificado?: boolean; inicio?: string; fim?: string; desfeito?: boolean }
export interface Exec { id: string; userId: number; conversationId: string | null; origin: string; playbook: string; goal: string; steps: Passo[]; level: Nivel; status: string; background: boolean; progress: number; version: number; history: { em: string; evento: string; detalhe?: string }[]; approvedBy: string | null; startedAt: string | null; finishedAt: string | null; createdAt: string; updatedAt: string }
export interface Contexto { u: SessionUser; hoje: string; passo: Passo; exec: Exec }
export interface Operacao {
  id: string; nome: string; nivel: Nivel; reversivel: boolean; repetivel: boolean; critico?: boolean; modulo?: string
  validar?: (c: Contexto, a: any) => Promise<void>
  executar: (c: Contexto, a: any) => Promise<any>
  verificar: (c: Contexto, a: any, r: any) => Promise<boolean>
  localizar?: (c: Contexto, a: any) => Promise<any | null>
  desfazer?: (c: Contexto, a: any, r: any) => Promise<void>
  alternativa?: (c: Contexto, a: any, erro: Erro) => { op: string; args: any; motivo: string } | null
}

/* ======================= serviços existentes (sem duplicar) ======================= */
const IT = () => import('../routes/items.js')
const item = async (userId: number, id: number): Promise<any | null> => { const r = await one('SELECT * FROM items WHERE id = $1 AND user_id = $2', [id, userId]); return r ? { ...r, data: J<any>(r.data, {}) } : null }
const acao = async (u: SessionUser, action: string, type: string, id: number, d: any = {}) => { const { itemAction } = await IT(); return db().tx((t: any) => itemAction(u, action, type, id, d, t)) }
const criar = async (u: SessionUser, type: string, d: any) => { const { createItem, serialize } = await IT(); await (await import('../lib/usage.js')).useQuota(u, type); const rows = await db().tx((t: any) => createItem(u, type, d, t)); return rows.map(serialize)[0] as any }
const recemCriado = async (u: SessionUser, type: string, desde: string | undefined, campo: string, valor: string) => {
  const rows = (await q('SELECT * FROM items WHERE user_id = $1 AND type = $2 AND created_at >= $3 ORDER BY id DESC LIMIT 20', [u.id, type, desde || new Date(Date.now() - 36e5).toISOString()])) as any[]
  return rows.find((r) => String(J<any>(r.data, {})[campo] || '') === valor) || null
}
const instantaneo = (r: any) => ({ type: r.type, status: r.status, day: r.day, data: r.data })

export const OPERACOES: Record<string, Operacao> = {
  'compromisso.lembrete': { id: 'compromisso.lembrete', nome: 'Ativar lembrete de compromisso', nivel: 1, reversivel: true, repetivel: true,
    validar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r || r.type !== 'appointment') fail(404, 'Compromisso não encontrado.', 'not_found'); if (!r.data.time) fail(400, 'O compromisso não tem horário: não dá para avisar antes.', 'invalid') },
    executar: async (c, a) => { const r = await item(c.u.id, a.id); const antes = Number(r!.data.reminderMinutes || 0); await acao(c.u, 'appointment_update', 'appointment', a.id, { reminder_minutes: a.minutos, origem: 'automacao' }); return { id: a.id, antes } },
    verificar: async (c, a) => { const r = await item(c.u.id, a.id); return !!r && (r.data.reminders || []).includes(Number(a.minutos)) },
    desfazer: async (c, a, r) => { await acao(c.u, 'appointment_update', 'appointment', a.id, { reminder_minutes: r?.antes ?? 0, origem: 'reversao' }) },
    alternativa: (c, a, e) => (e.classe === 'validacao' && /sem horário|não tem horário/.test(e.mensagem) ? { op: 'lembrete.criar', args: { message: `Compromisso: ${a.titulo || 'compromisso'}`, date: a.data, time: '08:00' }, motivo: 'sem horário: lembrete às 08:00 do dia' } : null) },
  'lembrete.criar': { id: 'lembrete.criar', nome: 'Criar lembrete', nivel: 1, reversivel: true, repetivel: false,
    executar: async (c, a) => { const r = await criar(c.u, 'reminder', a); return { id: r.id } },
    localizar: async (c, a) => { const r = await recemCriado(c.u, 'reminder', c.passo.inicio, 'message', a.message); return r ? { id: Number(r.id) } : null },
    verificar: async (c, _a, r) => !!(await item(c.u.id, r?.id)),
    desfazer: async (c, _a, r) => { if (await item(c.u.id, r.id)) await acao(c.u, 'delete', 'reminder', r.id) } },
  'compromisso.situacao': { id: 'compromisso.situacao', nome: 'Alterar situação de compromisso', nivel: 2, reversivel: true, repetivel: true,
    validar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r || r.type !== 'appointment') fail(404, 'Compromisso não encontrado.', 'not_found'); if (a.versao && new Date(String(r.updated_at)).getTime() !== new Date(String(a.versao)).getTime()) fail(409, 'O compromisso mudou depois do planejamento.', 'conflict') },
    executar: async (c, a) => { const r = await item(c.u.id, a.id); await acao(c.u, 'appointment_update', 'appointment', a.id, { status: a.status, origem: 'automacao' }); return { id: a.id, antes: r!.status || 'scheduled' } },
    verificar: async (c, a) => (await item(c.u.id, a.id))?.status === a.status,
    desfazer: async (c, a, r) => { if (await item(c.u.id, a.id)) await acao(c.u, 'appointment_update', 'appointment', a.id, { status: r.antes, origem: 'reversao' }) } },
  'compromisso.excluir': { id: 'compromisso.excluir', nome: 'Excluir compromisso', nivel: 3, reversivel: true, repetivel: true, critico: true,
    validar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r || r.type !== 'appointment') fail(404, 'Compromisso não encontrado.', 'not_found') },
    executar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r) return { id: a.id, jaNaoExistia: true }; await acao(c.u, 'delete', 'appointment', a.id); return { id: a.id, copia: instantaneo(r) } },
    verificar: async (c, a) => !(await item(c.u.id, a.id)),
    desfazer: async (c, _a, r) => { if (r?.copia) { const n = await one('INSERT INTO items (user_id, type, status, day, due_at, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING id', [c.u.id, r.copia.type, r.copia.status, r.copia.day, null, JSON.stringify(r.copia.data), nowIso()]); r.restauradoComo = Number(n!.id) } } },
  'tarefa.criar': { id: 'tarefa.criar', nome: 'Criar tarefa', nivel: 1, reversivel: true, repetivel: false,
    executar: async (c, a) => ({ id: (await criar(c.u, 'task', a)).id }),
    localizar: async (c, a) => { const r = await recemCriado(c.u, 'task', c.passo.inicio, 'title', a.title); return r ? { id: Number(r.id) } : null },
    verificar: async (c, _a, r) => !!(await item(c.u.id, r?.id)),
    desfazer: async (c, _a, r) => { if (await item(c.u.id, r.id)) await acao(c.u, 'delete', 'task', r.id) } },
  'tarefa.concluir': { id: 'tarefa.concluir', nome: 'Concluir tarefa', nivel: 1, reversivel: true, repetivel: true,
    executar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r) fail(404, 'Tarefa não encontrada.', 'not_found'); await acao(c.u, 'task_status', 'task', a.id, { status: 'done' }); return { id: a.id, antes: r!.status || 'pending' } },
    verificar: async (c, a) => (await item(c.u.id, a.id))?.status === 'done',
    desfazer: async (c, a, r) => { if (await item(c.u.id, a.id)) await acao(c.u, 'task_status', 'task', a.id, { status: r.antes === 'done' ? 'pending' : r.antes }) } },
  'tarefa.excluir': { id: 'tarefa.excluir', nome: 'Excluir tarefa', nivel: 3, reversivel: true, repetivel: true, critico: true,
    executar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r) return { id: a.id, jaNaoExistia: true }; if (r.type !== 'task') fail(400, 'Não é uma tarefa.', 'invalid'); await acao(c.u, 'delete', 'task', a.id); return { id: a.id, copia: instantaneo(r) } },
    verificar: async (c, a) => !(await item(c.u.id, a.id)),
    desfazer: async (c, _a, r) => { if (r?.copia) { const n = await one('INSERT INTO items (user_id, type, status, day, due_at, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING id', [c.u.id, 'task', r.copia.status, r.copia.day, null, JSON.stringify(r.copia.data), nowIso()]); r.restauradoComo = Number(n!.id) } } },
  'documento.criar': { id: 'documento.criar', nome: 'Criar documento (nota)', nivel: 1, reversivel: true, repetivel: false,
    executar: async (c, a) => ({ id: (await criar(c.u, 'note', { title: a.title, content: a.content, pinned: !!a.pinned })).id }),
    localizar: async (c, a) => { const r = await recemCriado(c.u, 'note', c.passo.inicio, 'title', a.title); return r ? { id: Number(r.id) } : null },
    verificar: async (c, a, r) => { const x = await item(c.u.id, r?.id); return !!x && String(x.data.content || '').length >= Math.min(20, String(a.content || '').length) },
    desfazer: async (c, _a, r) => { if (await item(c.u.id, r.id)) await acao(c.u, 'delete', 'note', r.id) } },
  'conta.pagar': { id: 'conta.pagar', nome: 'Marcar conta como paga', nivel: 3, reversivel: true, repetivel: true, critico: true, modulo: 'financas',
    validar: async (c, a) => { const r = await item(c.u.id, a.id); if (!r || r.type !== 'bill') fail(404, 'Conta não encontrada.', 'not_found') },
    executar: async (c, a) => { const r = await item(c.u.id, a.id); if (r!.status === 'paid') return { id: a.id, jaPaga: true }; const x: any = await acao(c.u, 'pay_bill', 'bill', a.id); return { id: a.id, proxima: x?.next?.id || null } },
    verificar: async (c, a) => (await item(c.u.id, a.id))?.status === 'paid',
    desfazer: async (c, a, r) => { if (!r?.jaPaga) await acao(c.u, 'unpay_bill', 'bill', a.id) } },
  'crm.tarefa': { id: 'crm.tarefa', nome: 'Criar tarefa no CRM', nivel: 1, reversivel: true, repetivel: false, modulo: 'crm',
    validar: async (c, a) => { await (await import('../lib/crm.js')).acesso(c.u.id, a.empresa) },
    executar: async (c, a) => { const C = await import('../lib/crm.js'); const t: any = await C.CRMTaskService.criar(a.empresa, { titulo: a.titulo, contatoId: a.contatoId, oportunidadeId: a.oportunidadeId, tipo: a.tipo || 'acompanhamento', prazo: a.prazo, prioridade: 'media' }, { id: c.u.id, nome: c.u.name, via: 'chat' }); return { id: Number(t.id), empresa: a.empresa } },
    localizar: async (c, a) => { const r = await one('SELECT id FROM crm_tasks WHERE business_id = $1 AND title = $2 AND created_at >= $3 ORDER BY id DESC LIMIT 1', [a.empresa, a.titulo, c.passo.inicio || nowIso()]).catch(() => null); return r ? { id: Number(r.id), empresa: a.empresa } : null },
    verificar: async (_c, a, r) => !!(await one("SELECT id FROM crm_tasks WHERE id = $1 AND business_id = $2 AND status = 'aberta'", [r?.id, a.empresa]).catch(() => null)),
    desfazer: async (c, a, r) => { await (await import('../lib/crm.js')).CRMTaskService.situacao(a.empresa, r.id, 'cancelada', { id: c.u.id, nome: c.u.name, via: 'chat' }) } },
  'consulta': { id: 'consulta', nome: 'Consultar dados', nivel: 1, reversivel: false, repetivel: true,
    executar: async (c, a) => (await import('./execucao-planos.js')).consultar(c.u, a.tipo, c.hoje),
    verificar: async (_c, _a, r) => r != null },
}
/** Nível das ferramentas da IA (o chat continua igual; só ganham nível, registro e verificação). */
export function nivelFerramenta(name: string, a: any): Nivel {
  if (/^(get_|crm_buscar|crm_historico|crm_oportunidades|crm_inteligencia|negocio_|agenda_empresa_consultar|agenda_empresa_alertas)/.test(name)) return 1
  if (name === 'update_appointment') { if (a?.valor_pago !== undefined) return 3; if (['cancelled', 'no_show'].includes(a?.status) || a?.date !== undefined) return 2; return 1 }
  if (/(cancel|delet|exclu|apag|remov|pagar_|transferir)/i.test(name)) return 3
  if (/(enviar_|disparar|crm_atualizar_etapa|agenda_empresa_decidir)/i.test(name)) return 2
  return 1
}

/* ======================= configuração e preferências ======================= */
export const EXEC_DEFAULT = { ativo: true, segundoPlano: true, maxPorUsuario: 2, limitePassos: 50, niveis: {} as Record<string, Nivel> }
export const execCfg = async () => ({ ...EXEC_DEFAULT, ...(await (await import('../lib/settings.js')).getConfig<any>('execucao', {})) }) as typeof EXEC_DEFAULT
/** Nível efetivo: o do catálogo, elevado pelo administrador ou pela autonomia "cautelosa" do usuário. Nunca abaixo do mínimo da operação. */
export async function nivelEfetivo(userId: number, op: Operacao) {
  const cfg = await execCfg(), aut = await autonomia(userId)
  let n = Math.max(op.nivel, Number(cfg.niveis[op.id] || 0)) as Nivel
  if (aut === 'cautelosa' && n < 2 && op.id !== 'consulta') n = 2
  return n
}
export async function autonomia(userId: number): Promise<'padrao' | 'cautelosa'> {
  const m = (await import('../db/index.js')).memoRequisicao(), k = 'autonomia:' + userId
  if (m?.has(k)) return m.get(k) as any
  const r = await one('SELECT autonomy FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null), v = r?.autonomy === 'cautelosa' ? 'cautelosa' : 'padrao'
  m?.set(k, v); return v
}
export async function salvarAutonomia(userId: number, v: string) {
  (await import('../db/index.js')).memoRequisicao()?.delete('autonomia:' + userId)
  if (!['padrao', 'cautelosa'].includes(v)) fail(400, 'Autonomia: padrao ou cautelosa.', 'invalid', 'autonomia')
  const ex = await one('SELECT user_id FROM user_intel_prefs WHERE user_id = $1', [userId]).catch(() => null)
  if (ex) await q('UPDATE user_intel_prefs SET autonomy = $1, updated_at = $2 WHERE user_id = $3', [v, nowIso(), userId])
  else await q('INSERT INTO user_intel_prefs (user_id, proactive, style, autonomy, updated_at) VALUES ($1,$2,$3,$4,$5)', [userId, true, '{}', v, nowIso()])
}

/* ======================= execuções: criação, estado e concorrência ======================= */
const novoId = () => 'EX-' + randomBytes(4).toString('hex').toUpperCase().slice(0, 6)
const ler = (r: any): Exec => ({ id: r.id, userId: Number(r.user_id), conversationId: r.conversation_id || null, origin: r.origin, playbook: r.playbook, goal: r.goal, steps: J<Passo[]>(r.steps, []), level: Number(r.level) as Nivel, status: r.status, background: B(r.background), progress: Number(r.progress), version: Number(r.version), history: J<any[]>(r.history, []), approvedBy: r.approved_by || null, startedAt: r.started_at || null, finishedAt: r.finished_at || null, createdAt: String(r.created_at), updatedAt: String(r.updated_at) })
export async function obter(userId: number, id: string) { if (!/^EX-[0-9A-F]{6}$/.test(String(id))) fail(400, 'Identificador de execução inválido.', 'invalid', 'id'); const r = await one('SELECT * FROM executions WHERE id = $1 AND user_id = $2', [id, userId]); if (!r) fail(404, 'Execução não encontrada.', 'not_found'); return ler(r) }
/** Grava o novo estado SÓ se ninguém mudou a execução desde a leitura (versão); devolve false em caso de conflito. */
async function salvar(e: Exec, evento?: string, detalhe?: string) {
  if (evento) e.history = [...e.history, { em: nowIso(), evento, ...(detalhe ? { detalhe: detalhe.slice(0, 300) } : {}) }].slice(-200)
  const feitos = e.steps.filter((s) => ['feito', 'falhou', 'bloqueado', 'pulado', 'cancelado', 'revertido'].includes(s.status)).length
  e.progress = e.steps.length ? Math.round((feitos / e.steps.length) * 100) : 100
  const r = await q('UPDATE executions SET steps = $1, status = $2, progress = $3, history = $4, approved_by = $5, started_at = $6, finished_at = $7, updated_at = $8, version = $9 WHERE id = $10 AND version = $11 RETURNING id',
    [JSON.stringify(e.steps), e.status, e.progress, JSON.stringify(e.history), e.approvedBy, e.startedAt, e.finishedAt, nowIso(), e.version + 1, e.id, e.version])
  if (r.length === 1) { e.version++; return true }
  return false
}
/** Gravação do executor: se outra chamada mudou a execução (ex.: pedido de cancelamento), relê a versão, respeita o
 *  novo estado e mantém as etapas do executor (ele é quem as conhece) — nunca perde o pedido de cancelamento. */
async function salvarExecutor(e: Exec, evento?: string, detalhe?: string) {
  for (let i = 0; i < 5; i++) {
    if (await salvar(e, i ? undefined : evento, i ? undefined : detalhe)) return true
    const atual = await obter(e.userId, e.id), meus = e.history.filter((h) => !atual.history.some((x) => x.em === h.em && x.evento === h.evento))
    e.version = atual.version; e.history = [...atual.history, ...meus]
    if (atual.status === 'cancelando' && e.status === 'executando') e.status = 'cancelando'
  }
  return false
}
export interface NovoPlano { playbook: string; goal: string; passos: { op: string; rotulo: string; args: any; depende?: number[] }[]; conversationId?: string | null; origin?: string; background?: boolean; chave?: string; nivelMinimo?: Nivel } // nivelMinimo (Fase 10): agentes no nível 2 de autonomia PREPARAM a ação — mesmo operação automática passa a pedir confirmação
/** Cria a execução (ou devolve a mesma, se o pedido idêntico foi feito há menos de 10 minutos). */
export async function criarExecucao(u: SessionUser, p: NovoPlano): Promise<{ exec: Exec; repetida: boolean }> {
  const cfg = await execCfg(); if (!cfg.ativo) fail(409, 'A execução automática está desligada pelo administrador.', 'disabled')
  if (!p.passos.length) fail(400, 'Nada a executar.', 'invalid')
  if (p.passos.length > cfg.limitePassos) fail(400, `Pedido grande demais para uma execução (${p.passos.length} etapas; limite ${cfg.limitePassos}).`, 'invalid')
  const mods = await (await import('../lib/usermod.js')).modules()
  const steps: Passo[] = []
  for (const [i, s] of p.passos.entries()) {
    const op = OPERACOES[s.op]; if (!op) fail(400, 'Operação desconhecida: ' + s.op, 'invalid')
    if (op.modulo && (mods as any)[op.modulo] === false) fail(403, `O módulo ${op.modulo} está desligado pelo administrador.`, 'module_off')
    steps.push({ n: i + 1, op: s.op, rotulo: s.rotulo.slice(0, 200), args: s.args, depende: (s.depende || []).filter((d) => d >= 1 && d <= i), nivel: await nivelEfetivo(u.id, op), status: 'pendente', tentativas: 0 })
  }
  const idem = createHash('sha256').update(JSON.stringify({ u: u.id, p: p.playbook, k: p.chave ?? p.passos.map((s) => [s.op, s.args]) })).digest('hex').slice(0, 32)
  const ja = await one("SELECT * FROM executions WHERE user_id = $1 AND idem_key = $2 AND created_at >= $3 AND status NOT IN ('cancelada','expirada','falhou') ORDER BY created_at DESC LIMIT 1", [u.id, idem, new Date(Date.now() - 10 * 60e3).toISOString()]).catch(() => null)
  if (ja) return { exec: ler(ja), repetida: true }
  const level = Math.max(p.nivelMinimo || 1, ...steps.map((s) => s.nivel)) as Nivel, agora = nowIso(), id = novoId()
  const status = level === 3 ? 'aguardando_autorizacao' : level === 2 ? 'aguardando_confirmacao' : 'na_fila'
  const background = !!p.background && cfg.segundoPlano
  const hist = [{ em: agora, evento: 'planejada', detalhe: `${steps.length} etapa(s) · nível ${level} (${NIVEL_NOME[level]})` }]
  await q('INSERT INTO executions (id, user_id, conversation_id, origin, playbook, goal, steps, level, status, background, progress, idem_key, version, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$15)',
    [id, u.id, p.conversationId || null, p.origin || 'chat', p.playbook, p.goal.slice(0, 500), JSON.stringify(steps), level, status, background, 0, idem, 0, JSON.stringify(hist), agora])
  return { exec: await obter(u.id, id), repetida: false }
}
/** Confirmação (nível 2) ou autorização explícita (nível 3). Nível 3 NÃO aceita uma simples confirmação. */
export async function aprovar(u: SessionUser, id: string, tipo: 'confirmar' | 'autorizar') {
  const e = await obter(u.id, id)
  if (!['aguardando_confirmacao', 'aguardando_autorizacao'].includes(e.status)) fail(409, e.status === 'expirada' ? 'Este pedido expirou. Peça de novo.' : 'Esta execução não está aguardando aprovação.', 'invalid_state')
  if (Date.now() - Date.parse(e.createdAt) > 30 * 60e3) { e.status = 'expirada'; await salvar(e, 'expirada', 'sem aprovação em 30 minutos'); fail(409, 'Este pedido expirou (30 minutos sem aprovação). Peça de novo.', 'expired') }
  if (e.status === 'aguardando_autorizacao' && tipo !== 'autorizar') fail(403, `Esta operação exige autorização explícita: diga "autorizo ${e.id}".`, 'needs_authorization')
  e.status = 'na_fila'; e.approvedBy = tipo === 'autorizar' ? 'usuario:autorizou' : 'usuario:confirmou'
  if (!(await salvar(e, tipo === 'autorizar' ? 'autorizada' : 'confirmada'))) fail(409, 'A execução foi alterada ao mesmo tempo. Tente de novo.', 'conflict')
  return e
}
export async function cancelar(u: SessionUser, id: string) {
  for (let i = 0; i < 3; i++) {
    const e = await obter(u.id, id)
    if (['aguardando_confirmacao', 'aguardando_autorizacao', 'na_fila'].includes(e.status)) { e.status = 'cancelada'; e.finishedAt = nowIso(); for (const s of e.steps) if (s.status === 'pendente') s.status = 'cancelado'; if (await salvar(e, 'cancelada', 'pelo usuário')) return e; continue }
    if (e.status === 'executando') { e.status = 'cancelando'; if (await salvar(e, 'cancelamento pedido', 'para depois da etapa em andamento')) return e; continue }
    fail(409, 'Esta execução já terminou; use "reverter" para desfazer o que foi feito.', 'invalid_state')
  }
  fail(409, 'Não consegui cancelar agora (execução em uso). Tente de novo.', 'conflict')
}

/* ======================= erros: origem, classe e o que fazer ======================= */
export interface Erro { classe: 'validacao' | 'permissao' | 'conflito' | 'nao_encontrado' | 'transitorio' | 'limite' | 'desconhecido'; mensagem: string; repetir: boolean }
export function classificar(e: any): Erro {
  const m = String(e?.message || e || 'erro'), st = e instanceof HttpError ? (e as any).status : Number(e?.status || 0), code = String(e?.code || '')
  if (code === 'limit_reached') return { classe: 'limite', mensagem: m, repetir: false }
  if (st === 400 || code === 'invalid') return { classe: 'validacao', mensagem: m, repetir: false }
  if (st === 401 || st === 403 || code === 'forbidden' || code === 'module_off') return { classe: 'permissao', mensagem: m, repetir: false }
  if (st === 409 || code === 'conflict') return { classe: 'conflito', mensagem: m, repetir: false }
  if (st === 404 || code === 'not_found') return { classe: 'nao_encontrado', mensagem: m, repetir: false }
  if (st >= 500 || /SQLITE_BUSY|database is locked|ECONN|ETIMEDOUT|timeout|deadlock|could not serialize|temporar/i.test(m) || code === 'transient') return { classe: 'transitorio', mensagem: m, repetir: true }
  return { classe: 'desconhecido', mensagem: m, repetir: false }
}
export const CLASSE_NOME: Record<string, string> = { validacao: 'dados inválidos', permissao: 'sem permissão', conflito: 'conflito com outra alteração', nao_encontrado: 'registro não encontrado', transitorio: 'falha temporária', limite: 'limite do plano', desconhecido: 'erro inesperado' }
const espera = (ms: number) => new Promise((r) => setTimeout(r, ms))

/* ======================= execução, autorrecuperação e verificação ======================= */
const correndo = new Set<string>() // a mesma execução nunca roda em paralelo neste processo (o banco protege entre processos)
export async function executar(u: SessionUser, id: string): Promise<Exec> {
  if (correndo.has(id)) return obter(u.id, id)
  correndo.add(id)
  try {
    let e = await obter(u.id, id)
    if (e.status !== 'na_fila') return e
    e.status = 'executando'; e.startedAt = e.startedAt || nowIso()
    if (!(await salvar(e, 'iniciada'))) return obter(u.id, id) // outro processo pegou antes // outro processo pegou antes
    const { localDate } = await import('../lib/time.js'), { settingsOf } = await import('../lib/account.js'), hoje = localDate(settingsOf(u).timezone)
    let parar = false
    for (const s of e.steps) {
      // cancelamento pedido no meio: para entre etapas (as feitas continuam feitas; podem ser revertidas)
      const atual = await obter(u.id, id); if (atual.status === 'cancelando') { e.version = atual.version; e.history = atual.history; e.status = 'cancelando'; parar = true }
      if (parar) { if (s.status === 'pendente') s.status = 'cancelado'; continue }
      if (['feito', 'falhou', 'pulado', 'cancelado', 'revertido'].includes(s.status)) continue
      if (s.depende.some((d) => e.steps[d - 1]?.status !== 'feito')) { s.status = 'bloqueado'; s.erro = `depende da etapa ${s.depende.join(', ')}, que não foi concluída`; continue }
      await rodarPasso(u, e, s, hoje)
      await salvarExecutor(e, s.status === 'feito' ? 'etapa concluída' : 'etapa ' + s.status, `${s.n}. ${s.rotulo}${s.erro ? ' — ' + s.erro : ''}`)
      if (s.status !== 'feito' && (OPERACOES[s.op].critico || s.status === 'incerto')) { parar = true; e.history.push({ em: nowIso(), evento: 'interrompida', detalhe: 'risco de inconsistência: as etapas seguintes não foram executadas' }) }
    }
    const fim = await obter(u.id, id); e.version = fim.version; e.history = [...fim.history, ...e.history.filter((h) => !fim.history.some((x) => x.em === h.em && x.evento === h.evento))]
    const ok = e.steps.filter((s) => s.status === 'feito' && s.verificado).length, total = e.steps.length
    e.status = fim.status === 'cancelando' ? 'cancelada' : ok === total ? 'concluida' : parar && e.steps.some((s) => s.status === 'cancelado' || s.status === 'incerto') && fim.status !== 'cancelando' ? 'interrompida' : ok ? 'parcial' : 'falhou'
    e.finishedAt = nowIso(); await salvarExecutor(e, 'finalizada', `${ok} de ${total} etapa(s) concluída(s) e verificada(s)`)
    if (e.background) await (await import('../lib/notify.js')).notify(u.id, { type: 'execucao', title: e.status === 'concluida' ? 'Tarefa concluída' : 'Tarefa terminou com pendências', body: `${e.goal.slice(0, 80)} — ${ok} de ${total} etapa(s) concluída(s).`, link: '/execucoes#' + e.id, ref: 'exec:' + e.id }).catch(() => {})
    return e
  } finally { correndo.delete(id) }
}
async function rodarPasso(u: SessionUser, e: Exec, s: Passo, hoje: string) {
  const op = OPERACOES[s.op], c: Contexto = { u, hoje, passo: s, exec: e }
  // retomada depois de queda: o que estava "executando" pode ter acontecido — confere antes de repetir
  if (s.status === 'executando' || s.status === 'incerto') {
    const achado = op.localizar ? await op.localizar(c, s.args).catch(() => null) : null
    if (achado && (await op.verificar(c, s.args, achado).catch(() => false))) { s.resultado = achado; s.status = 'feito'; s.verificado = true; s.fim = nowIso(); return }
    if (!op.repetivel && !op.localizar) { s.status = 'incerto'; s.erro = 'a etapa foi interrompida e não dá para saber se aconteceu; não repeti para não duplicar'; return }
  }
  s.status = 'executando'; s.inicio = s.inicio || nowIso(); await salvarExecutor(e)
  for (let tentativa = 1; tentativa <= 3; tentativa++) {
    s.tentativas = tentativa
    try {
      if (op.validar) await op.validar(c, s.args)
      const r = await op.executar(c, s.args); s.resultado = r
      // verificação no estado real: sem confirmação, não é "feito"
      const ok = await op.verificar(c, s.args, r).catch(() => false)
      s.verificado = ok; s.status = ok ? 'feito' : 'falhou'; s.fim = nowIso()
      if (!ok) { s.erro = 'executou, mas a verificação no sistema não confirmou o resultado'; s.classe = 'desconhecido' }
      return
    } catch (err: any) {
      const x = classificar(err); s.erro = x.mensagem.slice(0, 200); s.classe = x.classe
      // repete só o que é seguro repetir (idempotente) e só falhas temporárias
      if (x.repetir && op.repetivel && tentativa < 3) { await espera(150 * tentativa); continue }
      if (x.repetir && !op.repetivel && op.localizar) { const achado = await op.localizar(c, s.args).catch(() => null); if (achado && (await op.verificar(c, s.args, achado).catch(() => false))) { s.resultado = achado; s.status = 'feito'; s.verificado = true; s.erro = undefined; return } }
      if (x.classe === 'nao_encontrado' && /excluir/.test(s.op)) { s.status = 'feito'; s.verificado = await op.verificar(c, s.args, null).catch(() => false); s.resultado = { jaNaoExistia: true }; s.erro = undefined; return }
      // alternativa segura declarada pela operação (ex.: sem horário → lembrete às 08:00 do dia)
      const alt = op.alternativa?.(c, s.args, x)
      if (alt && OPERACOES[alt.op] && OPERACOES[alt.op].nivel <= s.nivel) {
        try { const o2 = OPERACOES[alt.op], r2 = await o2.executar(c, alt.args); if (await o2.verificar(c, alt.args, r2)) { s.resultado = { alternativa: alt.op, motivo: alt.motivo, ...r2 }; s.status = 'feito'; s.verificado = true; s.erro = undefined; s.op = alt.op; s.args = alt.args; s.rotulo += ` (alternativa: ${alt.motivo})`; return } } catch { /* segue como falha */ }
      }
      s.status = 'falhou'; s.fim = nowIso(); return
    }
  }
}
/** Desfaz, na ordem inversa, as etapas concluídas que têm reversão segura. */
export async function reverter(u: SessionUser, id: string) {
  const e = await obter(u.id, id)
  if (!['concluida', 'parcial', 'interrompida', 'cancelada', 'falhou'].includes(e.status)) fail(409, 'Só execuções terminadas podem ser revertidas.', 'invalid_state')
  const { localDate } = await import('../lib/time.js'), { settingsOf } = await import('../lib/account.js'), hoje = localDate(settingsOf(u).timezone)
  let ok = 0, sem = 0, falhas = 0
  for (const s of [...e.steps].reverse()) {
    if (s.status !== 'feito' || s.desfeito) continue
    const op = OPERACOES[s.op]; if (!op.desfazer || !op.reversivel) { sem++; continue }
    try { await op.desfazer({ u, hoje, passo: s, exec: e }, s.args, s.resultado); s.desfeito = true; s.status = 'revertido'; ok++ } catch (err: any) { falhas++; s.erro = 'reversão falhou: ' + String(err?.message || err).slice(0, 150) }
  }
  e.status = falhas ? e.status : 'revertida'
  await salvar(e, 'reversão', `${ok} etapa(s) desfeita(s)${sem ? `, ${sem} sem reversão possível` : ''}${falhas ? `, ${falhas} falha(s)` : ''}`)
  return { exec: e, desfeitas: ok, semReversao: sem, falhas }
}

/* ======================= segundo plano: fila, retomada e limite por usuário ======================= */
export async function processarFila(max = 5) {
  const cfg = await execCfg(); if (!cfg.ativo) return 0
  // retomada: execução "executando" sem atualização há mais de 2 minutos (processo caiu) volta para a fila
  for (const r of (await q("SELECT * FROM executions WHERE status = 'executando' AND updated_at < $1", [new Date(Date.now() - 120e3).toISOString()]).catch(() => [])) as any[]) {
    const e = ler(r); if (correndo.has(e.id)) continue; e.status = 'na_fila'; await salvar(e, 'retomada', 'o processamento foi interrompido; continuando de onde parou')
  }
  const fila = (await q("SELECT id, user_id FROM executions WHERE status = 'na_fila' ORDER BY created_at LIMIT $1", [max * 3]).catch(() => [])) as any[]
  let n = 0
  for (const r of fila) {
    if (n >= max) break
    const ativos = Number((await one("SELECT COUNT(*) AS n FROM executions WHERE user_id = $1 AND status = 'executando'", [r.user_id]))?.n || 0); if (ativos >= cfg.maxPorUsuario) continue
    const ur = await one('SELECT * FROM users WHERE id = $1', [r.user_id]); if (!ur) continue
    const u = { id: Number(ur.id), name: ur.name, role: ur.role, email: ur.email, settings: J<any>(ur.settings, {}) } as unknown as SessionUser
    void executar(u, String(r.id)).catch((err) => console.error('[execução]', r.id, err?.message)); n++
  }
  return n
}

/* ======================= monitoramento (painel do administrador: só números) ======================= */
export async function indicadores() {
  const rows = ((await q('SELECT * FROM executions WHERE created_at >= $1 ORDER BY created_at DESC LIMIT 5000', [new Date(Date.now() - 30 * 864e5).toISOString()]).catch(() => [])) as any[]).map(ler)
  const fim = rows.filter((e) => ['concluida', 'parcial', 'falhou', 'interrompida'].includes(e.status)), pct = (a: number, b: number) => (b ? Math.round((a / b) * 1000) / 10 : null)
  const dur = fim.filter((e) => e.startedAt && e.finishedAt).map((e) => Date.parse(e.finishedAt!) - Date.parse(e.startedAt!))
  const passos = rows.flatMap((e) => e.steps), falhas: Record<string, number> = {}; for (const s of passos.filter((x) => x.status === 'falhou' || x.status === 'incerto')) falhas[s.classe || 'desconhecido'] = (falhas[s.classe || 'desconhecido'] || 0) + 1
  const porObjetivo = new Map<string, any>(); for (const e of rows) { const x = porObjetivo.get(e.playbook) || { playbook: e.playbook, total: 0, concluidas: 0, falhas: 0 }; x.total++; if (e.status === 'concluida') x.concluidas++; if (['falhou', 'parcial', 'interrompida'].includes(e.status)) x.falhas++; porObjetivo.set(e.playbook, x) }
  const exig = rows.filter((e) => e.level >= 2)
  return {
    config: await execCfg(), total: rows.length, concluidas: rows.filter((e) => e.status === 'concluida').length, pendentes: rows.filter((e) => ['aguardando_confirmacao', 'aguardando_autorizacao', 'na_fila', 'executando', 'cancelando'].includes(e.status)).length,
    falhas: rows.filter((e) => ['falhou', 'parcial', 'interrompida'].includes(e.status)).length, canceladas: rows.filter((e) => ['cancelada', 'expirada'].includes(e.status)).length, revertidas: rows.filter((e) => e.status === 'revertida').length,
    autorizacao: { exigiram: exig.length, confirmacao: rows.filter((e) => e.level === 2).length, autorizacaoExplicita: rows.filter((e) => e.level === 3).length, aprovadas: exig.filter((e) => e.approvedBy).length, recusadasOuExpiradas: exig.filter((e) => ['cancelada', 'expirada'].includes(e.status) && !e.approvedBy).length },
    tempoMedioMs: dur.length ? Math.round(dur.reduce((a, b) => a + b, 0) / dur.length) : null, taxaSucesso: pct(fim.filter((e) => e.status === 'concluida').length, fim.length),
    etapas: { total: passos.length, feitas: passos.filter((s) => s.status === 'feito').length, verificadas: passos.filter((s) => s.verificado).length, repetidas: passos.filter((s) => s.tentativas > 1).length, falhasPorClasse: Object.entries(falhas).map(([classe, n]) => ({ classe, nome: CLASSE_NOME[classe] || classe, n })) },
    segundoPlano: { naFila: rows.filter((e) => e.status === 'na_fila').length, executando: rows.filter((e) => e.status === 'executando').length, total: rows.filter((e) => e.background).length },
    porObjetivo: [...porObjetivo.values()].sort((a, b) => b.total - a.total), usuarios: new Set(rows.map((e) => e.userId)).size,
  }
}
/** Execução enxuta para o usuário (o próprio dono): estado, etapas, verificação e histórico. */
export const publico = (e: Exec) => ({ id: e.id, objetivo: e.goal, playbook: e.playbook, nivel: e.level, nivelNome: NIVEL_NOME[e.level], status: e.status, segundoPlano: e.background, progresso: e.progress, aprovadaPor: e.approvedBy, criadaEm: e.createdAt, iniciadaEm: e.startedAt, terminadaEm: e.finishedAt,
  etapas: e.steps.map((s) => ({ n: s.n, rotulo: s.rotulo, operacao: OPERACOES[s.op]?.nome || s.op, nivel: s.nivel, status: s.status, verificado: !!s.verificado, tentativas: s.tentativas, erro: s.erro || null, classe: s.classe ? CLASSE_NOME[s.classe] || s.classe : null, reversivel: !!OPERACOES[s.op]?.reversivel, depende: s.depende })),
  historico: e.history, podeReverter: ['concluida', 'parcial', 'interrompida', 'cancelada', 'falhou'].includes(e.status) && e.steps.some((s) => s.status === 'feito' && OPERACOES[s.op]?.reversivel) })
