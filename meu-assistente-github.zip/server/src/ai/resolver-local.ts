// RESOLVEDOR LOCAL DO CÉREBRO — resolve sem IA externa os pedidos de AÇÃO cuja estrutura é clara, usando as MESMAS
// ferramentas e validações da IA (nada paralelo):
//  • administração da empresa ativa (preço, oferta, estoque de produto/variação, pausar/ativar produto, formas de pagamento,
//    entrega/retirada, frete grátis, horário, pausar/reativar pedidos, descrição, botão do WhatsApp) → empresa_alterar;
//  • tarefa e lista de compras → create_task / add_shopping_items (pelo mesmo caminho protegido da IA: executarLocal).
// Quando usar:
//  • administração da empresa: PRIMEIRO (frase estruturada; economiza IA e é verificável); se o item não for achado, a IA tenta;
//  • tarefa e compras: só quando a IA falhar ou estiver fora do ar (a IA escreve títulos melhores).
// A resposta é montada só com o resultado REAL da ferramenta (nunca afirma o que não aconteceu). Determinístico: não chama IA.
import type { SessionUser } from '../lib/session.js'

const base = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[“”"']/g, '').replace(/\s+/g, ' ').trim()
const num = (v: string | undefined) => { if (!v) return undefined; const s = v.replace(/\s/g, ''), n = Number(/,\d{1,2}$/.test(s) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '')); return Number.isFinite(n) ? n : undefined }
const VAL = String.raw`(?:r\$\s*)?(\d{1,3}(?:\.\d{3})*(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)`
const ART = String.raw`(?:(?:o|a|os|as|do|da|dos|das|de|desse|dessa|deste|desta|meu|minha)\s+)*`
const limpaItem = (t: string) => t.replace(/^(?:o|a|os|as|do|da|dos|das|de|meu|minha|produto|item)\s+/g, '').replace(/^(?:o|a|os|as|produto)\s+/g, '').replace(/[.!?]+$/, '').trim()
const DIA: Record<string, string> = { segunda: 'seg', seg: 'seg', terca: 'ter', ter: 'ter', quarta: 'qua', qua: 'qua', quinta: 'qui', qui: 'qui', sexta: 'sex', sex: 'sex', sabado: 'sab', sab: 'sab', domingo: 'dom', dom: 'dom' }
const ORD = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom']
const hora = (h: string, m?: string) => `${String(Number(h)).padStart(2, '0')}:${m || '00'}`

/** Lê um comando de administração da empresa. null = não é (ou não é claro o bastante): a IA cuida. */
export function lerComandoEmpresa(texto: string): Record<string, any> | null {
  const t = base(texto).replace(/^(?:(?:por favor|favor|quero|eu quero|preciso|gostaria de|pode|voce pode|vc pode|consegue|agora)\s+)+/, '')
  let m: RegExpMatchArray | null
  // pedidos / loja / catálogo (pausar e reativar a loja inteira)
  // frete grátis
  if ((m = t.match(new RegExp(String.raw`frete gratis\b.*?\b(?:acima|a partir|para (?:compras|pedidos) acima|de compras acima)\s+(?:de\s+)?${VAL}`))) && !/^(?:desative|desativa|desligue|desliga|tire|remova|cancele)/.test(t)) return { acao: 'frete_gratis', ativo: true, valor_minimo: num(m[1]) }
  if (/^(?:desative|desativa|desligue|desliga|tire|tira|remova|remove|cancele|cancela)\b.*\bfrete gratis\b/.test(t)) return { acao: 'frete_gratis', ativo: false }
  // formas de pagamento (nunca chave Pix nem credenciais)
  if ((m = t.match(/^(ative|ativa|ativar|ligue|liga|habilite|habilita|aceite|aceita|aceitar|desative|desativa|desativar|desligue|desliga|desabilite|desabilita|tire|tira|remova|remove|pare de aceitar|nao aceite)\b.*?\b(pix na entrega|pix automatico|pix online|pix|dinheiro|cartao)\b/)) && !/\bchave\b/.test(t)) {
    const liga = /^(ative|ativa|ativar|ligue|liga|habilite|habilita|aceite|aceita|aceitar)/.test(m[1]), k = m[2] === 'pix na entrega' ? 'pix_na_entrega' : /pix (automatico|online)/.test(m[2]) ? 'pix_automatico' : m[2]
    return { acao: 'configurar_pagamento', [k]: liga }
  }
  // entrega e retirada
  if (/\b(?:apenas|so|somente) (?:a )?retirada\b/.test(t) && /\bentrega\b/.test(t)) return { acao: 'configurar_entrega', entrega: false, retirada: true }
  if ((m = t.match(new RegExp(String.raw`\btaxa de entrega\b.*?\b(?:para|pra|em)\s+${VAL}`)))) return { acao: 'configurar_entrega', taxa: num(m[1]) }
  if ((m = t.match(/^(ative|ativa|ativar|ligue|liga|desative|desativa|desativar|desligue|desliga)\s+(?:a\s+)?(entrega|retirada)(?:\s+no local)?$/))) return { acao: 'configurar_entrega', [m[2]]: /^(ative|ativa|ativar|ligue|liga)/.test(m[1]) }
  // horário de funcionamento: "segunda a sábado, das 9h às 18h"
  if (/\bhorario\b/.test(t) && /\bfuncionamento\b|\bloja\b|\bempresa\b|\batendimento\b/.test(t)) {
    const hm = t.match(/\bdas?\s+(\d{1,2})(?:[:h](\d{2}))?\s*h?\s+(?:as|a|ate)\s+(\d{1,2})(?:[:h](\d{2}))?/)
    const rg = t.match(/\b(?:de\s+)?(segunda|terca|quarta|quinta|sexta|sabado|domingo)(?:-feira)?\s+(?:a|ate)\s+(segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/)
    let dias: string[] = []
    if (rg) { const i = ORD.indexOf(DIA[rg[1]]), f = ORD.indexOf(DIA[rg[2]]); for (let k = i; ; k = (k + 1) % 7) { dias.push(ORD[k]); if (k === f || dias.length > 7) break } }
    else dias = [...new Set([...t.matchAll(/\b(segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/g)].map((x) => DIA[x[1]]))]
    if (/\btodos os dias\b|\btoda a semana\b/.test(t)) dias = [...ORD]
    if (hm && dias.length) return { acao: 'alterar_horario', dias, abre: hora(hm[1], hm[2]), fecha: hora(hm[3], hm[4]) }
    return null
  }
  // descrição da loja
  if ((m = texto.match(/descri[cç][aã]o\s+d[ao]\s+(?:minha\s+)?(?:loja|empresa)\s+(?:para|pra|como)\s*[:\-]?\s*["“]?(.+?)["”]?\s*$/i))) return { acao: 'alterar_descricao', texto: m[1].trim() }
  // botão do WhatsApp
  if (/\bwhats\w*\b/.test(t) && /\b(contato|botao|opcao)\b/.test(t)) return { acao: 'botao_whatsapp', ativo: !/^(desative|desativa|desligue|desliga|tire|tira|remova|remove|esconda)/.test(t) }
  // produtos: preço, oferta, estoque, pausar/ativar
  if ((m = t.match(new RegExp(String.raw`\bpreco\s+${ART}(.+?)(?:\s+(?:para|pra|por|em)\s+${VAL})?$`))) && /^(altere|altera|alterar|mude|muda|mudar|troque|troca|coloque|coloca|defina|define|atualize|atualiza|ajuste|ajusta|passe|passa|bote|bota|deixe|deixa|aumente|aumenta|diminua|diminui|reduza|reduz|baixe|baixa|suba|sobe)\b/.test(t)) {
    const v = num(m[2]); return { acao: 'produto_preco', produto: limpaItem(m[1]), ...(v != null ? { valor: v } : {}) }
  }
  if ((m = t.match(new RegExp(String.raw`^(?:coloque|coloca|ponha|poe|bote|bota|deixe|deixa)\s+${ART}(.+?)\s+em\s+(?:oferta|promocao)(?:\s+(?:por|a|de|com preco de)\s+${VAL})?$`)))) { const v = num(m[2]); return { acao: 'produto_oferta', produto: limpaItem(m[1]), ativo: true, ...(v != null ? { valor: v } : {}) } }
  if ((m = t.match(/^(?:tire|tira|remova|remove)\s+(.+?)\s+da\s+(?:oferta|promocao)$/))) return { acao: 'produto_oferta', produto: limpaItem(m[1]), ativo: false }
  if ((m = t.match(/\bestoque\s+(?:(?:do|da|de|dos|das)\s+)?(?:produto\s+)?(.+?)\s+(para|pra|em)\s+(\d+)(?:\s+unidades?)?$/)) && /^(altere|altera|mude|muda|troque|troca|coloque|coloca|defina|define|atualize|atualiza|ajuste|ajusta|deixe|deixa|aumente|aumenta|diminua|diminui|reduza|reduz|zere|zera|bote|bota)\b/.test(t)) {
    const op = m[2] === 'em' ? (/^(aumente|aumenta)/.test(t) ? 'somar' : /^(diminua|diminui|reduza|reduz)/.test(t) ? 'subtrair' : 'definir') : 'definir'
    return { acao: 'produto_estoque', produto: limpaItem(m[1]), valor: Number(m[3]), operacao: op }
  }
  if ((m = t.match(/^(?:zere|zera)\s+o\s+estoque\s+(?:(?:do|da|de)\s+)?(?:produto\s+)?(.+)$/))) return { acao: 'produto_estoque', produto: limpaItem(m[1]), valor: 0, operacao: 'definir' }
  if ((m = t.match(/^(?:pause|pausa|pausar|desative|desativa|desativar|esconda|esconde|oculte|oculta)\s+(?:o\s+|a\s+)?produto\s+(.+)$/))) return { acao: 'produto_pausar', produto: limpaItem(m[1]) }
  if ((m = t.match(/^(?:ative|ativa|ativar|reative|reativa|reativar|mostre|mostra|volte a mostrar)\s+(?:o\s+|a\s+)?produto\s+(.+)$/))) return { acao: 'produto_ativar', produto: limpaItem(m[1]) }
  // pedidos / loja / catálogo inteiros (o objeto vem logo depois do verbo: "pause meu catálogo", "ative novamente os pedidos")
  const OBJ_LOJA = String.raw`(?:\s+(?:novamente|de novo|agora))?\s+(?:(?:o|a|os|as|meu|minha|meus|minhas|todo o|todos os|o recebimento de|receber)\s+)*(?:catalogo|loja|pedidos)\b`
  if (new RegExp(String.raw`^(?:pause|pausa|pausar|feche|fecha|fechar|suspenda|suspende|desative|desativa|desativar|desligue|desliga|pare de receber|para de receber)` + OBJ_LOJA).test(t)) return { acao: 'pausar_pedidos' }
  if (new RegExp(String.raw`^(?:ative|ativa|ativar|reative|reativa|reativar|reabra|reabre|abra|abre|volte a|voltar a|ligue|liga|religue)` + OBJ_LOJA).test(t)) return { acao: 'reativar_pedidos' }
  return null
}

/** Administração da empresa sem IA. null = não é comando claro (ou o item não foi achado e a IA pode tentar). */
export async function resolverEmpresa(u: SessionUser, texto: string, o: { semIA?: boolean } = {}): Promise<{ content: string; resultado: any } | null> {
  const cmd = lerComandoEmpresa(texto); if (!cmd) return null
  if ('produto' in cmd && (!cmd.produto || /^(?:produto|item|esse|essa|este|esta|ele|ela)$/.test(cmd.produto))) return null // referência ao contexto: a IA (com histórico) resolve
  const EA = await import('./empresa-admin.js')
  if (!(await EA.empresaAdminDisponivel(u))) return null
  const r = await EA.runEmpresaTool(u, 'empresa_alterar', cmd, texto)
  if (!o.semIA && !r.ok && !r.ambiguo && !r.precisaConfirmar && /^N[aã]o encontrei/.test(String(r.error || ''))) return null // nome que a leitura literal não achou: a IA tenta entender
  return { content: EA.formatar(r) + (r?.precisaConfirmar ? ' ⟦conf:Sim, pode confirmar|Não, cancele⟧' : ''), resultado: r } // mesmos botões Confirmar/Cancelar do caminho da IA
}

/** Tarefa e lista de compras sem IA (quando a IA não está disponível). */
export function lerPedidoPessoal(texto: string): { ferramenta: 'create_task' | 'add_shopping_items'; args: any } | null {
  const orig = String(texto || '').trim().replace(/[.!?]+$/, ''), t = base(orig)
  let m = orig.match(/^(?:me\s+)?(?:cri[ae]|adicion[ae]|anot[ae]|coloc[ae]|faz|fa[cç]a|registr[ae]|bot[ae])?\s*(?:a[ií]\s+)?(?:uma\s+)?(?:nova\s+)?tarefa\s*(?:de|para|pra|:|-)?\s+(.{3,140})$/i)
  if (m && !/lista de compras/.test(t)) { const title = m[1].trim(); return { ferramenta: 'create_task', args: { title: title.charAt(0).toUpperCase() + title.slice(1) } } }
  m = orig.match(/^(?:me\s+)?(?:coloc[ae]|adicion[ae]|bot[ae]|p[oõ]e|ponha|inclu[ai]|acrescent[ae]|anot[ae])\s+(.+?)\s+n[ao]\s+(?:minha\s+)?lista(?:\s+de\s+(?:compras|mercado))?$/i) || orig.match(/^(?:preciso|tenho que)\s+comprar\s+(.+)$/i)
  if (m) {
    const items = m[1].split(/\s*,\s*|\s+e\s+/i).map((x) => x.trim().replace(/^(?:o|a|os|as|um|uma|uns|umas)\s+/i, '')).filter((x) => x && x.length <= 60).slice(0, 30)
      .map((x) => { const q = x.match(/^(\d+(?:[.,]\d+)?\s*(?:kg|g|l|ml|litros?|quilos?|un|unidades?|pacotes?|caixas?|duzias?|latas?|garrafas?)?)\s+(?:de\s+)?(.+)$/i); return q ? { name: q[2].charAt(0).toUpperCase() + q[2].slice(1), quantity: q[1].trim() } : { name: x.charAt(0).toUpperCase() + x.slice(1) } })
    if (items.length) return { ferramenta: 'add_shopping_items', args: { items } }
  }
  return null
}
export async function resolverPessoal(u: SessionUser, texto: string, convId: string): Promise<{ content: string; cards: any[] } | null> {
  const p = lerPedidoPessoal(texto); if (!p) return null
  const A = await import('./assistant.js'), { res, cards } = await A.executarLocal(u, p.ferramenta, p.args, texto, convId)
  const r: any = res
  if (r?.ok && Array.isArray(r.created) && r.created.length) { // confere que o registro existe de verdade antes de responder
    const nomes = r.created.map((x: any) => x.title || x.name).filter(Boolean)
    return { content: p.ferramenta === 'create_task' ? `Pronto! Criei a tarefa "${nomes[0]}".` : `Pronto! Coloquei na lista de compras: ${nomes.join(', ')}.`, cards }
  }
  if (r?.deduped) return { content: 'Isso já foi feito agora há pouco; não repeti.', cards: [] }
  return { content: `Não consegui ${p.ferramenta === 'create_task' ? 'criar a tarefa' : 'atualizar a lista de compras'}: ${String(r?.error || r?.aviso || 'tente de novo').slice(0, 200)}`, cards: [] }
}
