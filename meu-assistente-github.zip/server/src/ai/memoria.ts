// MEMÓRIA INTELIGENTE — aprimora a memória que já existe (tabela memories, Perfil → Memória do assistente):
// • recupera as memórias RELEVANTES para a mensagem (em vez de despejar as 50 mais novas em toda resposta);
// • ao guardar, identifica ATUALIZAÇÃO ("moro em Recife" substitui "moro em Fortaleza") e evita duplicata;
// • aponta frases que a resposta repetiria sem necessidade.
// Nada é guardado sem pedido do usuário: a gravação continua passando pela ferramenta save_memory.
import { q, nowIso } from '../db/index.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const norm = (t: string) => nrm(t).replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set('a o os as um uma de da do das dos e ou em no na nos nas para pra por com que se meu minha meus minhas eu ele ela sou tenho gosto mais muito nao sim isso esse essa quando onde como lembre lembra que guarde anote voce'.split(' '))
const palavras = (t: string) => new Set(norm(t).split(' ').filter((w) => w.length > 2 && !STOP.has(w)).map((w) => w.replace(/(s|es)$/, '')))
const jaccard = (a: Set<string>, b: Set<string>) => { if (!a.size || !b.size) return 0; let i = 0; for (const w of a) if (b.has(w)) i++; return i / (a.size + b.size - i) }

/** Categoria "única" de um fato: quando muda, a memória antiga deve ser ATUALIZADA (só pode haver um valor). */
const UNICAS: [string, RegExp][] = [
  ['nome', /\b(meu nome e|me chamo|pode me chamar de)\b/],
  ['moradia', /\b(moro (em|no|na)|minha cidade e|vivo em)\b/],
  ['trabalho', /\b(trabalho (como|na|no|em)|minha profissao e)\b/],
  ['aniversario', /\b(meu aniversario|nasci em)\b/],
  ['parente', /\bmeu (marido|pai|filho|irmao|namorado|noivo|socio|chefe)\b|\bminha (esposa|mae|filha|irma|namorada|noiva|socia|chefe)\b/],
]
export function chaveUnica(t: string): string | null {
  const s = nrm(t)
  for (const [k, re] of UNICAS) if (re.test(s) && (k !== 'parente' || /\b(se chama|chama|nome (dele|dela) e)\b/.test(s))) return k === 'parente' ? 'parente:' + (s.match(/\bminh?[ao]s? (\w+)/)?.[1] || s.match(/\bmeu (\w+)/)?.[1] || '') : k
  return null
}

export interface Comparacao { acao: 'nova' | 'duplicada' | 'atualizar'; id?: number; antiga?: string; motivo?: 'mesma informação' | 'informação única mudou' | 'contradição' | 'parecida' }
const NEGA = /\b(nao|nunca|jamais|deixei de|parei de|nem)\b/
const polaridade = (t: string) => NEGA.test(nrm(t))
/** Compara uma memória nova com as existentes do MESMO usuário (duplicata, informação única que mudou, contradição). */
export async function comparar(userId: number, conteudo: string): Promise<Comparacao> {
  const rows = await q('SELECT id, content FROM memories WHERE user_id = $1 AND active = $2 ORDER BY id DESC LIMIT 1000', [userId, true]).catch(() => [] as any[])
  const nova = palavras(conteudo), chave = chaveUnica(conteudo), pol = polaridade(conteudo)
  let melhor: { id: number; content: string; sim: number } | null = null
  for (const r of rows as any[]) { const sim = jaccard(nova, palavras(r.content)); if (!melhor || sim > melhor.sim) melhor = { id: Number(r.id), content: String(r.content), sim } }
  // mesma coisa com sinal trocado ("gosto de café" × "não gosto de café") é CONTRADIÇÃO: a mais nova vale, a antiga vira versão
  if (melhor && melhor.sim >= 0.6 && polaridade(melhor.content) !== pol) return { acao: 'atualizar', id: melhor.id, antiga: melhor.content, motivo: 'contradição' }
  if (melhor && (melhor.sim >= 0.85 || norm(melhor.content) === norm(conteudo))) return { acao: 'duplicada', id: melhor.id, antiga: melhor.content, motivo: 'mesma informação' }
  if (chave) { const mesma = (rows as any[]).find((r) => chaveUnica(r.content) === chave); if (mesma) return { acao: 'atualizar', id: Number(mesma.id), antiga: String(mesma.content), motivo: 'informação única mudou' } }
  if (melhor && melhor.sim >= 0.6) return { acao: 'atualizar', id: melhor.id, antiga: melhor.content, motivo: 'parecida' }
  return { acao: 'nova' }
}
/** Atualiza SEM perder a versão anterior (origem e datas preservadas no histórico da memória). */
export async function atualizarMemoria(userId: number, id: number, conteudo: string, motivo = 'atualizada pelo chat', conversa: string | null = null) {
  return (await import('./memoria-evolutiva.js')).atualizarComHistorico(userId, id, conteudo, { motivo, conversa })
}

// A recuperação de memórias relevantes passou para memoria-evolutiva.ts (Fase 5: por significado, em camadas, com cache).

/** Frases da resposta já ditas (iguais) nas últimas respostas: repetição desnecessária. */
export function repetidas(resposta: string, anteriores: string[]): string[] {
  const ja = new Set(anteriores.flatMap((a) => String(a || '').replace(/⟦[^⟧]*⟧/g, '').split(/(?<=[.!?])\s+|\n+/)).map(norm).filter((f) => f.length >= 40))
  return String(resposta || '').split(/(?<=[.!?])\s+|\n+/).filter((f) => norm(f).length >= 40 && ja.has(norm(f)))
}
