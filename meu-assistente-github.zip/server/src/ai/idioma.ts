// IDIOMA INTELIGENTE E PERSISTENTE do chat principal.
//
// • Detecta o idioma de cada mensagem (pt, en, es, fr, it, de) por palavras e sinais próprios de cada língua.
// • Responde no idioma da mensagem; mensagens sem idioma claro ("ok", "2+2", um nome) seguem o idioma recente da conversa.
// • Pedido PERMANENTE ("sempre me responda em inglês", "use espanhol daqui para frente", "I prefer English", "prefiero
//   español") vira preferência na memória persistente do usuário (Perfil → Memória do assistente) e vale em todas as
//   conversas até ele pedir outra coisa ("responda no idioma em que eu escrever" apaga a preferência).
// • Pedido PONTUAL ("responda isso em inglês", "in Spanish please") vale só para esta resposta e não é guardado.
// • O idioma de uma mensagem isolada NUNCA vira preferência.
// • Respostas dos motores internos (escritas em português) são traduzidas para o idioma da resposta, preservando os
//   marcadores ⟦…⟧ (cartões e botões) e a formatação; se a tradução falhar, a resposta original é mantida.
import { q, one, nowIso } from '../db/index.js'

export type Lang = 'pt' | 'en' | 'es' | 'fr' | 'it' | 'de'
export const LANGS: Lang[] = ['pt', 'en', 'es', 'fr', 'it', 'de']
/** Nome do idioma em português (memória, painel) e no próprio idioma (instrução para a IA). */
export const NOME_PT: Record<Lang, string> = { pt: 'português', en: 'inglês', es: 'espanhol', fr: 'francês', it: 'italiano', de: 'alemão' }
export const NOME_NATIVO: Record<Lang, string> = { pt: 'português do Brasil', en: 'English', es: 'español', fr: 'français', it: 'italiano', de: 'Deutsch' }

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')

// ---------- detecção ----------
const PALAVRAS: Record<Lang, string> = {
  pt: 'a e o as os me te se lhe nos em de que com um uma uns umas ate sem sobre entre nao voce vc voces eu meu minha meus minhas um uma uns umas para pra com por obrigado obrigada ola oi tudo bem esta estou isso esse essa isto tambem mas quanto quando onde qual quais do da dos das no na nos nas ao aos o os sim muito muita hoje amanha ontem fazer faco quero preciso posso pode tenho tem gastei gasto registra registrar registro lembre lembra lembrete agenda agendar agendo marcar bom boa dia tarde noite sou ele ela eles elas seu sua ja ainda depois agora entao comprar compra conta contas ajuda funciona consigo vejo onde nossa obrigadao beleza valeu tchau quantos quantas cade crio criar mes este estes isso aqui la buscar busco produto produtos servico servicos ajuda ajude ajudar organizar organiza semana ano proximo proxima ultimo ultima explique explica frase sobre favor coisa coisas gente fiz fez faz vai vou vamos foi era seria sera precisa quer queria gostaria acho sei saber dizer diga mande manda envie enviar pagar paguei conta resumo reuniao dentista amanha cedo tarde hora horas minutos dinheiro reais real cliente clientes empresa loja pedido pedidos comprei acabei ou como por dias dia so deve deveria devia pode podem ser estar ficar fica ficou mudar mudou mudaram antes cada todo todos toda todas outro outra outros mesmo mesma nada tudo algum alguma novo nova novos antigo antiga marcado marcada apagar apagado apagados apagou desligado ligado gratuito gratis existe existem consta constar sozinho perto longe aberto fechado',
  es: 'el los las del al y o a e de que en con un una sin sobre entre me te se le lo nos yo mi mis tu usted es esta estoy hola gracias que como donde cuando cual quiero puedo necesito tengo hoy manana ayer muy pero tambien bueno buenos buenas dias tardes noches eso este esto un una unos unas en con para por si hacer hago gaste recuerdame recuerda cita agendar compra cuenta ayuda funciona veo llamar quisiera podrias puedes dime hay cuanto cuantos adios vale mucho comprar busco buscar pastel gasto registro recordatorio creo cuentame dime cuenta curiosidad algo cosa cosas ahora aqui siempre nunca nada todo mas hay ser estar tiene tienes hacer cuando donde porque semana mes ano gracias quieres sabes mejor nuevo nueva',
  en: 'the a an and or is are am been being an into from about at by up out so if then than also just only very really will would there their they them he she his her our us its was were be to of in on for with you your i me my we it this that what how where when which who do does did can could would should please thanks thank hello hi hey good morning afternoon evening today tomorrow yesterday want need have has add remind reminder expense spent spend set up show find buy schedule appointment meeting create make bill list note help works use my am not dont im its whats there tell give get know think some any more fact facts fun time day week month year thing something anything let like love go come see look say ask call send read pay cost price much many new old best better why here now should could thank yes not about after before again every never always',
  fr: 'le la les des du un une et est je tu vous il elle nous ce cette que qui quoi comment ou pourquoi bonjour salut merci plait oui non avec pour dans sur pas suis etes avoir faire veux peux aujourdhui demain hier mon ma mes ton ta tes leur rendez aide fonctionne depense rappelle raconte dis dites donne quelque chose anecdote maintenant ici toujours jamais rien tout plus il y a etre fait faire semaine mois annee merci voudrais pouvez',
  it: 'il lo gli le un una e sono sei io tu lei noi voi che chi come dove quando perche ciao grazie per favore si no con in di da del della dello non ho hai voglio posso oggi domani ieri mio mia miei aiuto funziona spesa ricordami appuntamento raccontami dimmi dammi qualcosa cosa adesso ora qui sempre mai niente tutto piu essere fare settimana mese anno curiosita vorrei potresti',
  de: 'der die das den dem des ein eine einen und ist bin bist sind ich du sie wir ihr wie wo was wann warum hallo danke bitte ja nein mit fur in auf nicht habe hast mochte kann heute morgen gestern mein meine hilfe funktioniert ausgabe erinnere termin guten tag erzahl erzaehl sag gib etwas sache jetzt hier immer nie nichts alles mehr sein machen woche monat jahr kuriositat moechte mochte konnen konntest',
}
const SETS: Record<Lang, Set<string>> = Object.fromEntries(LANGS.map((l) => [l, new Set(PALAVRAS[l].split(/\s+/))])) as any
// quantos idiomas usam cada palavra: palavra compartilhada vale menos (ex.: "de", "que", "como")
const PESO = new Map<string, number>(); for (const l of LANGS) for (const w of SETS[l]) PESO.set(w, (PESO.get(w) || 0) + 1)

export interface Deteccao { lang: Lang | null; certeza: number; placar: Partial<Record<Lang, number>> }
/** Idioma da mensagem. `lang` é null quando não há sinal suficiente (mensagem curta, números, nomes próprios). */
export function detectar(texto: string): Deteccao {
  const bruto = String(texto || '').replace(/⟦[^⟧]*⟧/g, ' ').replace(/https?:\/\/\S+/g, ' ')
  const low = bruto.toLowerCase(), n = nrm(bruto)
  const toks = n.replace(/[’']/g, '').match(/[a-z]+/g) || []
  const sc: Record<Lang, number> = { pt: 0, en: 0, es: 0, fr: 0, it: 0, de: 0 }
  let unicos = 0
  for (const w of toks) { const k = PESO.get(w); if (!k) continue; for (const l of LANGS) if (SETS[l].has(w)) { sc[l] += 1 / k; if (k === 1 && (w.length >= 3 || w === "oi" || w === "hi")) unicos++ } } // palavra curta ("al", "y") sozinha não decide
  // sinais de escrita próprios de cada língua
  if (/[ãõ]/.test(low)) sc.pt += 2; if (/\wç[ãaõo]/.test(low) || /\b\w+ções?\b/.test(low)) sc.pt += 1.5; if (/(^|[^a-zà-ú])ça([^a-zà-ú]|$)/.test(low)) sc.fr += 1.5; if (/\bvoc[eê]\b|\bn[ãa]o\b/.test(low)) sc.pt += 1
  sc.pt += 0.7 * ((n.match(/[a-z]*(nh|lh)[a-z]*/g) || []).filter((w) => !/^(nh|lh)/.test(w)).length) // dígrafos só do português
  if (/[ñ¿¡]/.test(low)) sc.es += 2.5; if (/\b\w+ci[oó]n(es)?\b/.test(low)) sc.es += 1
  if (/[ßäöü]/.test(low)) sc.de += 2
  if (/\b(l|d|j|qu|n|c|s)['’][aeiouhé]/.test(low) || /[èëîœ]/.test(low)) sc.fr += 1.2
  if (/\b(i'm|don't|can't|it's|what's|i've|you're|let's)\b/.test(low)) sc.en += 1.5
  const ord = (Object.entries(sc) as [Lang, number][]).sort((a, b) => b[1] - a[1]), [l1, s1] = ord[0], s2 = ord[1][1]
  const placar = Object.fromEntries(ord.filter(([, v]) => v > 0)) as Partial<Record<Lang, number>>
  // decisão: vantagem clara sobre o 2º colocado; uma única palavra própria do idioma basta se nada aponta para outro
  const ok = (s1 >= 2 && s1 >= s2 * 1.8) || (s1 >= 1.5 && s1 >= s2 * 2.5) || (s1 >= 1 && s2 === 0 && unicos >= 1)
  return { lang: ok ? l1 : null, certeza: ok ? Math.min(1, (s1 - s2) / 3) : 0, placar }
}

// ---------- pedidos de idioma (permanente, pontual, apagar) ----------
const NOMES: [Lang, RegExp][] = [
  ['pt', /\b(portugues|portuguese|portugais|portoghese|portugiesisch|pt-br)\b/],
  ['en', /\b(ingles|english|anglais|inglese|englisch)\b/],
  ['es', /\b(espanhol|spanish|espanol|espagnol|spagnolo|spanisch|castelhano|castellano)\b/],
  ['fr', /\b(frances|french|francais|francese|franzosisch|franzoesisch)\b/],
  ['it', /\b(italiano|italian|italien|italienisch)\b/],
  ['de', /\b(alemao|german|aleman|allemand|tedesco|deutsch)\b/],
]
const PERMANENTE = /\b(sempre|daqui (pra|para) frente|daqui em diante|a partir de agora|de agora em diante|nas proximas conversas|em todas as conversas|por padrao|como padrao|prefiro|preferencia|always|from now on|going forward|by default|default|i prefer|i'd prefer|siempre|de ahora en adelante|a partir de ahora|prefiero|preferencia|toujours|desormais|a partir de maintenant|je prefere|d'ora in poi|da ora in poi|preferisco|immer|ab jetzt|von nun an|bevorzuge|lieber)\b/
const MUDAR_IDIOMA = /\b((mud[ae]r?|troc[ae]r?|alter[ae]r?|defin[ae]r?|coloc[ae]r?) (o )?idioma|change (the |your )?language|set (the |your )?language|switch (the language )?to|cambi(a|ar) (el )?idioma|change(z|r)? (la )?langue|cambia (la )?lingua|sprache (andern|aendern|wechseln))\b/
const VERBO = /\b(respond\w*|respond[ae]|fal[ae]|fala comigo|escrev\w*|convers\w*|us[ae]r?|idioma|lingua|answer|reply|respond|speak|talk|write|use|language|contesta\w*|habla\w*|escrib\w*|reponds?|repondre|parle\w*|ecri\w*|utilise\w*|langue|rispond\w*|parla\w*|scriv\w*|antwort\w*|sprich|schreib\w*|sprache)\b/
const PONTUAL = /\b(respond\w*|responda|responde|me responda|respondeme|reescreva|repita|explique|explica|me explique|me explica|diga|me diga|fale|escreva|mostre|answer|reply|respond|write|say|explain|tell me|repeat|contesta|contestame|escribe|dime|explicame|repite|reponds|reponde|ecris|explique-moi|rispondi|scrivi|spiegami|dimmi|antworte|schreib|erklar)\b/
const TRADUCAO = /\b(traduz\w*|traduc\w*|translat\w*|como se diz|como se fala|como se escreve|how do you say|what does .{1,40} mean|que significa|como se dice|comment dit-on|come si dice|wie sagt man)\b/
const APAGAR = /\b((responda|responde|fale|escreva|use) no (mesmo )?idioma (em )?que (eu )?(escrever|falar|usar|mandar)|no idioma da (minha )?mensagem|esque[cç]a (a )?(minha )?prefer[eê]ncia de idioma|(remov|apag|tir)\w* (a )?(minha )?prefer[eê]ncia de idioma|sem idioma fixo|nao tenho idioma preferido|reply in (the|whatever|whichever) language i (write|use|speak)|answer in (the|whatever|whichever) language i (write|use)|forget my language preference|no fixed language|responde en el idioma (en )?que (yo )?(escriba|hable)|olvida (mi )?preferencia de idioma|reponds dans la langue (dans laquelle|que) j|rispondi nella lingua in cui scrivo|antworte in der sprache,? in der ich schreibe)\b/

export interface PedidoIdioma { acao: 'definir' | 'apagar' | 'pontual'; lang?: Lang; resto: string }
/** Reconhece um pedido sobre o idioma das respostas. "Como se diz… em inglês?" e traduções NÃO são pedidos de idioma. */
export function pedidoDeIdioma(texto: string): PedidoIdioma | null {
  if (!nrm(texto).trim()) return null
  // a mensagem pode trazer o pedido E uma pergunta ("Always answer in English. What's 2+2?"): as regras olham só a(s) frase(s)
  // que falam do idioma; o restante é respondido em seguida
  const partes = String(texto).split(/(?<=[.!?;:])\s+|\n+/).filter((p) => p.trim()), relevante = (p: string) => NOMES.some(([, re]) => re.test(nrm(p))) || APAGAR.test(nrm(p)) || MUDAR_IDIOMA.test(nrm(p))
  const alvo = partes.filter(relevante), resto = partes.length > 1 && alvo.length < partes.length ? partes.filter((p) => !relevante(p)).join(' ').trim() : ''
  const frase = (alvo.length ? alvo.join(' ') : String(texto)).trim(), s = nrm(frase).replace(/\s+/g, ' ').trim()
  if (APAGAR.test(s)) return { acao: 'apagar', resto }
  const ach = NOMES.filter(([, re]) => re.test(s)); if (ach.length !== 1) return null // nenhum ou vários idiomas citados: não é pedido de idioma
  const lang = ach[0][0]
  if (TRADUCAO.test(s)) return null
  if (/\b(aula|curso|professor|professora|prova|livro|filme|serie|musica|cancao|class|course|teacher|lesson)s?\b/.test(s) && !VERBO.test(s.replace(/\b(aula|curso)\b.*/, ''))) return null // "aula de inglês amanhã" é compromisso
  if (/\?\s*$/.test(frase) && !MUDAR_IDIOMA.test(s) && !/\b(pode|podes|poderia|can you|could you|puedes|podrias|pourrais|puoi|kannst)\b/.test(s)) return null // "você fala inglês?" é pergunta, não pedido
  if (MUDAR_IDIOMA.test(s) || (PERMANENTE.test(s) && (VERBO.test(s) || /\b(prefiro|prefiero|prefer|preferisco|prefere|bevorzuge)\b/.test(s)))) return { acao: 'definir', lang, resto }
  // pontual: verbo de resposta + "em/in/en <idioma>" (ou "<idioma> please/por favor")
  if ((PONTUAL.test(s) && /\b(em|in|en|auf|na)\s+(\w+\s+)?\w+/.test(s)) || /\b(in|en)\s+\w+\s*(,\s*)?(please|por favor|pls|s'il (te|vous) plait|bitte|per favore)\b/.test(s) || /^\s*(in|en|em)\s+\w+[.!]?\s*$/.test(s)) return { acao: 'pontual', lang, resto: s.length > 60 ? String(texto) : resto }
  return null
}

// ---------- preferência persistente (memória do usuário) ----------
/** A preferência fica na memória do usuário (Perfil → Memória do assistente), como as demais: ele vê, edita e apaga. */
const TEXTO_MEMORIA = (l: Lang) => `Prefere que eu responda sempre em ${NOME_PT[l]} (idioma escolhido no chat).`
function langDoTexto(t: string): Lang | null { const s = nrm(t); for (const [l, re] of NOMES) if (re.test(s)) return l; return null }
// A memória é a fonte da verdade; uma cópia (chave "idioma" do usuário) entra na leitura em lote que o chat já faz a cada
// mensagem, para não custar uma consulta a mais. Mudanças na tela de Memória chamam sincronizar().
export async function preferencia(userId: number): Promise<Lang | null> {
  const { getUM } = await import('../lib/usermod.js')
  const v = await getUM<{ lang?: string } | null>(userId, 'idioma', null).catch(() => null)
  return v && LANGS.includes(v.lang as Lang) ? (v.lang as Lang) : null
}
async function gravarCopia(userId: number, lang: Lang | null) { await (await import('../lib/usermod.js')).setUM(userId, 'idioma', lang ? { lang, em: nowIso() } : {}) }
/** Recalcula a cópia a partir da memória (depois de editar, apagar ou restaurar memórias no Perfil). */
export async function sincronizar(userId: number) {
  const r = await one('SELECT content FROM memories WHERE user_id = $1 AND source = $2 AND active = $3 ORDER BY id DESC LIMIT 1', [userId, 'idioma', true]).catch(() => null)
  await gravarCopia(userId, r ? langDoTexto(String(r.content)) : null)
}
export async function salvarPreferencia(userId: number, lang: Lang, conversa: string | null = null) {
  const ant = await one('SELECT id, content FROM memories WHERE user_id = $1 AND source = $2 AND active = $3 ORDER BY id DESC LIMIT 1', [userId, 'idioma', true])
  if (ant) {
    if (langDoTexto(String(ant.content)) !== lang) {
      await (await import('./memoria-evolutiva.js')).atualizarComHistorico(userId, Number(ant.id), TEXTO_MEMORIA(lang), { motivo: 'idioma alterado pelo usuário no chat', conversa })
      await q('UPDATE memories SET kind = $1, source = $2 WHERE id = $3', ['preference', 'idioma', ant.id])
    }
    return gravarCopia(userId, lang)
  }
  const agora = nowIso()
  await q('INSERT INTO memories (user_id, content, kind, source, active, created_at, updated_at, origin_conversation_id) VALUES ($1, $2, $3, $4, $5, $6, $6, $7)', [userId, TEXTO_MEMORIA(lang), 'preference', 'idioma', true, agora, conversa])
  await gravarCopia(userId, lang)
}
export async function apagarPreferencia(userId: number) {
  await q('UPDATE memories SET active = $1, updated_at = $2 WHERE user_id = $3 AND source = $4 AND active = $5', [false, nowIso(), userId, 'idioma', true])
  await gravarCopia(userId, null)
}

// ---------- idioma da resposta neste turno ----------
export interface IdiomaTurno { lang: Lang; origem: 'pedido_pontual' | 'preferencia' | 'mensagem' | 'conversa' | 'padrao'; preferencia: Lang | null; detectado: Lang | null; pedido: PedidoIdioma | null }
/** Ordem: pedido pontual → preferência salva → idioma da mensagem → idioma recente da conversa → português. */
export async function idiomaDoTurno(userId: number, texto: string, hist: { role: string; content: string | null }[] = []): Promise<IdiomaTurno> {
  const pedido = pedidoDeIdioma(texto), pref = await preferencia(userId), det = detectar(texto).lang
  if (pedido?.acao === 'pontual' && pedido.lang) return { lang: pedido.lang, origem: 'pedido_pontual', preferencia: pref, detectado: det, pedido }
  if (pedido?.acao === 'definir' && pedido.lang) return { lang: pedido.lang, origem: 'preferencia', preferencia: pedido.lang, detectado: det, pedido }
  if (pref && pedido?.acao !== 'apagar') return { lang: pref, origem: 'preferencia', preferencia: pref, detectado: det, pedido }
  if (det) return { lang: det, origem: 'mensagem', preferencia: pedido?.acao === 'apagar' ? null : pref, detectado: det, pedido }
  for (const m of [...hist].reverse().filter((x) => x.role === 'user').slice(0, 4)) { const d = detectar(String(m.content || '')).lang; if (d) return { lang: d, origem: 'conversa', preferencia: null, detectado: null, pedido } }
  return { lang: 'pt', origem: 'padrao', preferencia: null, detectado: null, pedido }
}

/** Instrução de idioma para o prompt da IA. */
export function instrucaoIA(t: IdiomaTurno) {
  const l = t.lang, nome = NOME_NATIVO[l]
  const porque = t.origem === 'preferencia' ? `o usuário pediu para receber as respostas sempre em ${NOME_PT[l]} (preferência salva) — vale mesmo que ele escreva em outro idioma`
    : t.origem === 'pedido_pontual' ? `o usuário pediu esta resposta em ${NOME_PT[l]}` : `o usuário escreveu em ${NOME_PT[l]}`
  return `IDIOMA DA RESPOSTA: ${nome} (${l}). Responda SOMENTE em ${NOME_PT[l]}: ${porque}. Os conhecimentos e o contexto abaixo podem estar em português — use o conteúdo, mas escreva a resposta em ${NOME_PT[l]}. Não misture idiomas e não comente sobre o idioma.`
}

/** Idioma desta requisição (memória da requisição): a revisão interna e outros textos da IA o seguem sem receber parâmetro. */
export async function marcarTurno(t: IdiomaTurno) { try { (await import('../db/index.js')).memoRequisicao()?.set('idioma_turno', t) } catch { /* fora de requisição */ } }
export async function turnoAtual(): Promise<IdiomaTurno | null> { try { return ((await import('../db/index.js')).memoRequisicao()?.get('idioma_turno') as IdiomaTurno) || null } catch { return null } }

// ---------- confirmações (já no idioma pedido; sem IA) ----------
export const CONFIRMA: Record<Lang, string> = {
  pt: 'Combinado! A partir de agora vou responder sempre em português, em todas as conversas. Se quiser mudar, é só pedir.',
  en: "Got it! From now on I'll always reply in English, in every conversation. Just ask if you want to change it.",
  es: '¡Entendido! A partir de ahora te responderé siempre en español, en todas las conversaciones. Si quieres cambiarlo, solo pídelo.',
  fr: "C'est noté ! Désormais, je répondrai toujours en français, dans toutes nos conversations. Demande-moi si tu veux changer.",
  it: 'Fatto! D’ora in poi ti risponderò sempre in italiano, in tutte le conversazioni. Se vuoi cambiare, basta chiedere.',
  de: 'Alles klar! Ab jetzt antworte ich dir immer auf Deutsch, in allen Unterhaltungen. Sag einfach Bescheid, wenn du das ändern möchtest.',
}
export const APAGADA: Record<Lang, string> = {
  pt: 'Certo! Não tenho mais um idioma fixo: vou responder no idioma em que você escrever.',
  en: "Sure! I no longer use a fixed language: I'll reply in whatever language you write in.",
  es: '¡Claro! Ya no uso un idioma fijo: te responderé en el idioma en que escribas.',
  fr: "D'accord ! Je n'ai plus de langue fixe : je répondrai dans la langue dans laquelle tu écris.",
  it: 'Certo! Non uso più una lingua fissa: risponderò nella lingua in cui scrivi.',
  de: 'Klar! Ich nutze keine feste Sprache mehr: Ich antworte in der Sprache, in der du schreibst.',
}

// ---------- tradução das respostas dos motores internos ----------
const CACHE = new Map<string, string>()
/** Traduz uma resposta escrita em português para `lang`, preservando ⟦…⟧ (com o rótulo dos botões traduzido), markdown,
 *  números, valores e datas. Devolve null se a IA falhar ou devolver algo inválido (quem chama mantém o original). */
export async function traduzir(texto: string, lang: Lang, maxMs = 12000): Promise<string | null> {
  const t = String(texto || '')
  if (lang === 'pt' || !/[a-zà-ú]{3}/i.test(t.replace(/⟦[^⟧]*⟧/g, ''))) return null
  const ck = lang + '\u0001' + t; if (CACHE.has(ck)) return CACHE.get(ck)!
  const toks: string[] = [], rotulos: string[] = []
  const corpo = t.replace(/⟦[^⟧]*⟧/g, (m) => { toks.push(m); return `⟦${toks.length - 1}⟧` })
  toks.forEach((m, i) => { const r = m.match(/^⟦btn:[^|⟧]*\|([^⟧]*)⟧$/); if (r) rotulos.push(`${i}|${r[1]}`) })
  const prompt = `[TRADUÇÃO INTERNA → ${lang}]\nTraduza para ${NOME_PT[lang]} (${NOME_NATIVO[lang]}) o TEXTO de uma resposta de assistente pessoal. Regras: mantenha exatamente os marcadores ⟦0⟧, ⟦1⟧… onde estão; mantenha a formatação (negrito, listas, quebras de linha), números, valores em dinheiro, datas, horários, nomes próprios e textos entre aspas que o usuário precisa digitar no app só quando forem comandos de exemplo (traduza-os também para que funcionem no idioma). Traduza também cada RÓTULO de botão. Responda só com JSON: {"texto": "...", "rotulos": ["0|...", ...]}.\n\nTEXTO:\n${corpo}\n\nRÓTULOS:\n${rotulos.join('\n') || '(nenhum)'}`
  try {
    const { run } = await import('./engine.js')
    const r = await run([{ role: 'user', content: prompt }], { task: 'conversa', json: true, temperature: 0.1, parallel: 'off', ...({ maxMs } as any) })
    const j = JSON.parse(String(r.message.content || '').replace(/^```(json)?|```$/g, '').trim())
    let out = String(j?.texto || '').trim(); if (!out) return null
    for (let i = 0; i < toks.length; i++) if ((out.match(new RegExp(`⟦${i}⟧`, 'g')) || []).length !== 1) return null // marcador perdido ou duplicado: não arrisca
    const novos = new Map<number, string>(); for (const x of Array.isArray(j.rotulos) ? j.rotulos : []) { const m = String(x).match(/^(\d+)\|(.+)$/); if (m) novos.set(Number(m[1]), m[2].replace(/[⟦⟧|]/g, '').trim().slice(0, 40)) }
    out = out.replace(/⟦(\d+)⟧/g, (_, i) => { const orig = toks[Number(i)], nr = novos.get(Number(i)); return nr ? orig.replace(/\|[^⟧]*⟧$/, `|${nr}⟧`) : orig })
    if (CACHE.size > 300) CACHE.delete(CACHE.keys().next().value!); CACHE.set(ck, out)
    return out
  } catch { return null }
}
