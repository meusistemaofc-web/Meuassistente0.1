// MOTOR DE PRIORIDADE DE INTENÇÕES — decide, ANTES de qualquer IA, Cérebro ou pesquisa, o que a mensagem é:
//   1. pesquisa_explicita     "pesquise na internet…", "procure na web…", "quais as últimas notícias de…"  (o usuário pediu)
//   2. operacao               criar/consultar/alterar/cancelar na agenda, finanças, lembretes, tarefas, notas, listas, contas, empresa
//   3. continuacao_operacao   frase curta que continua a última ação desta conversa ("mude para 15h", "pode cancelar",
//                             "adicione uma observação", "corrija o valor") — resolvida sobre o registro citado
//   4. pesquisa_atual         informação atual/externa de verdade (cotação de hoje, notícias, previsão do tempo, placar)
//   5. conhecimento           pergunta geral → Cérebro primeiro; pesquisa automática só se ele não souber
//   6. conversa
// Operação e continuação BLOQUEIAM a pesquisa no turno (ai/bloqueio-pesquisa.ts). O classificador de pesquisa nunca
// sobrepõe uma operação válida: palavras como "pesquisa", "preço", "notícia" DENTRO de um pedido operacional
// ("anota que a pesquisa de satisfação ficou para sexta", "registre o preço do corte: 50") não viram pesquisa.
// Só usa sinais que já existem (a memória da conversa em ai/convctx.ts e os leitores determinísticos de agenda/finanças);
// não chama IA, não acessa a rede e não grava nada.
import type { ConvCtx } from './convctx.js'

export type Prioridade = 'operacao' | 'continuacao_operacao' | 'pesquisa_explicita' | 'pesquisa_atual' | 'conhecimento' | 'conversa'
export type Dominio = 'agenda' | 'financeiro' | 'lembrete' | 'tarefa' | 'nota' | 'conta' | 'lista' | 'empresa' | null
export interface Decisao {
  prioridade: Prioridade
  dominio: Dominio
  pesquisa: 'bloqueada' | 'permitida' | 'explicita' | 'atual'
  /** pergunta sem o comando de pesquisa ("pesquise na internet o que é X" → "o que é X") */
  consulta: string
  /** registro desta conversa a que a continuação se refere */
  alvo?: { tipo: string; id: number } | null
  motivo: string
}

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
const CORTESIA = String.raw`(?:(?:por favor|pfv|pf|agora|entao|e|ok|certo|beleza|tambem|so|apenas|pode|voce pode|vc pode|consegue|me|ai)\s+)*`

/* ---------- pesquisa pedida pelo usuário ---------- */
const PESQ_VERBO = new RegExp(String.raw`^${CORTESIA}(?:faca|faz|fazer)?\s*(?:uma\s+)?(?:pesquis[ae]r?|pesquisa|procur[ae]r?|busqu?e|buscar|busca|googl[ae]|d[aei] uma (?:olhada|pesquisada|buscada|googlada))\b`)
const NA_WEB = /\b(na internet|na web|no google|online|na rede|em sites?|nas noticias|fontes? (atuais|externas))\b/
const INTERNO = /\b(minhas?|meus?|nossa|nosso)\s+(agenda|compromissos?|agendamentos?|gastos?|despesas?|receitas?|lancamentos?|lembretes?|tarefas?|notas?|anotacoes|contas?|clientes?|pedidos?|produtos?|servicos?|vendas?|financas|financeiro|estoque|lista)\b|\b(na agenda|no financeiro|nos meus|nas minhas|no sistema|no app|no aplicativo|nos registros|no historico|na conversa)\b/
const NOTICIAS = /^(?:quais (?:sao )?)?(?:as )?(?:ultimas )?noticias\b|\b(ultimas noticias|noticias (de hoje|sobre|da|do|de))\b/
const COMPARE_PRECOS = /^(?:compare|compara|comparar)\b.*\b(precos?|valores?|lojas?|sites?|modelos?|planos?)\b|\b(preco atual|precos atuais|preco de mercado|quanto (esta|ta) custando)\b/

/* ---------- informação atual/externa ---------- */
const TEMPO_REAL = /\b(cotacao|cambio|placar|resultado do jogo|previsao do tempo|clima (de|em|hoje|amanha|agora)|vai chover|temperatura (em|de|hoje|agora)|ultimas noticias|noticias de hoje|preco atual|precos atuais|dolar hoje|euro hoje|bitcoin|ibovespa|bolsa hoje|quem ganhou|quem venceu)\b/

/* ---------- operações internas ---------- */
const VERBO_OP = new RegExp(String.raw`^${CORTESIA}(?:agend|mar(?:c|qu)|remar(?:c|qu)|desmar(?:c|qu)|cancel|registr|lan[cç]|anot|lembr|cri[ae]|cadastr|adicion|acrescent|inclu|colo(?:c|qu)|ponh|bot[ae]|mud|alter|tro(?:c|qu)|corrij|corrig|ajust|atualiz|exclu|apag|remov|modifi|edit|tir[ae]|conclu|finaliz|defin|pass[ae]|adi[ae]|antecip|salv|guard|mostr|list)\w*\b`)
const OBJETO_OP = /\b(compromissos?|agendamentos?|reuniao|consulta|horario|agenda|evento|visita|sessao|tarefas?|lembretes?|notas?|anotac\w*|lista( de compras)?|compras|gastos?|despesas?|receitas?|lancamentos?|contas? (de|da|do|a pagar)|conta|boletos?|vencimento|valor|saldo|categoria|descricao|cliente|telefone|celular|observac\w*|obs|produtos?|servicos?|estoque|pedidos?|cobranca|pix|data|dia|prazo)\b/
const DADO_OP = /\b(\d{1,2}\s*h\b|\d{1,2}[:h]\d{2}|as \d{1,2}\b|amanha|hoje|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|dia \d{1,2}|r\$|\d+\s*(reais|real|conto))\b/
const MOVIMENTO = /^(?:(?:hoje|ontem|agora)\s+)?(?:eu\s+)?(gastei|paguei|comprei|recebi|vendi|transferi|ganhei|depositei)\b/
const CONSULTA_PESSOAL = /\b(quanto (eu )?(gastei|recebi|devo|tenho|ganhei|vendi)|qual (e )?(o )?meu saldo|meu saldo|meus gastos|minhas (despesas|receitas|contas|tarefas|notas|anotacoes)|meus (compromissos|lembretes|agendamentos)|o que (eu )?tenho (hoje|amanha|depois de amanha|na agenda|essa semana|esta semana|marcado)|tenho (algum )?(compromisso|reuniao|consulta)|minha agenda|contas a pagar|o que (vence|esta vencendo)|que horas (e|sera) (a|o) (reuniao|consulta|compromisso))\b/

/* ---------- continuação curta da última ação ---------- */
const VERBO_CONT = new RegExp(String.raw`^${CORTESIA}(?:adicion|acrescent|inclu|colo(?:c|qu)|ponh|bot[ae]|mud|alter|tro(?:c|qu)|corrij|corrig|ajust|atualiz|modifi|edit|remar(?:c|qu)|pass[ae]|adi[ae]|antecip|cancel|desmar(?:c|qu)|exclu|apag|remov|tir[ae]|defin|marqu?e? como|conclu)\w*\b`)
const CONFIRMA = /^(?:(?:sim|ok|certo|isso)\s+)?(?:(?:e|eh) )?(?:esse|essa|isso|este|esta) mesm[oa]$|^(?:isso mesmo|exatamente|pode ser|pode sim|sim|nao|confirmo|confirma|pode salvar|pode cancelar|cancela|deixa|esquece|nao quero)$/
const SO_DADO = /^(?:(?:para|pra|as|às|no|na|dia)\s+)?(?:\d{1,2}\s*(?:h|horas?)(?:\s*\d{2})?|\d{1,2}[:h]\d{2}|amanha|hoje|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|dia \d{1,2}(?:\/\d{1,2})?|(?:r\$\s*)?\d+(?:[.,]\d{1,2})?\s*(?:reais|real)?)$/
const PERGUNTA_GERAL = /^(o que (e|sao|significa|foi)|como (funciona|surgiu|se faz)|quem (e|foi|sao)|qual (e|foi) (a|o) (capital|origem|historia|significado)|por que|porque|pra que serve|para que serve|explique|defina|me (explica|explique|fala sobre|conte)|voce sabe)\b/

const TIPO_DOMINIO: Record<string, Dominio> = { appointment: 'agenda', expense: 'financeiro', reminder: 'lembrete', task: 'tarefa', note: 'nota', bill: 'conta', shopping: 'lista' }
function dominioDoTexto(s: string): Dominio {
  if (/\b(lembrete|lembr|me avis)/.test(s)) return 'lembrete'
  if (/\btarefas?\b/.test(s)) return 'tarefa'
  if (/\b(nota|anotac\w*|anot[ae]|anota)\b/.test(s)) return 'nota'
  if (/\b(lista de compras|na lista|lista do mercado)\b/.test(s)) return 'lista'
  if (/\b(contas? (de|da|do|a pagar)|boletos?|vencimento|venc\w+)\b/.test(s)) return 'conta'
  if (/\b(gast|despes|receit|lancament|saldo|categoria|pagu|receb|compre|financ|pix|cobranca)\w*/.test(s)) return 'financeiro'
  if (/\b(agend|compromisso|reuniao|consulta|horario|agenda|evento|visita|sessao|remarc|desmarc|marc)\w*/.test(s)) return 'agenda'
  if (/\b(produto|servico|estoque|loja|empresa|catalogo|pedido)s?\b/.test(s)) return 'empresa'
  return null
}
/** Pergunta sem o comando de pesquisa. */
export function consultaSemComando(texto: string): string {
  const t = String(texto || '').trim()
  const r = t.replace(/^(?:(?:por favor|pfv|agora|ent[aã]o|e|ok|voc[eê] pode|vc pode|pode|consegue|me)\s+)*(?:fa[cç]a|faz|fazer)?\s*(?:uma\s+)?(?:pesquis[ae]r?|pesquisa|procur[ae]r?|busqu?e|buscar|busca|googl[ae]|d[aêe] uma (?:olhada|pesquisada|buscada|googlada))\s*/i, '')
    .replace(/^(?:(?:na internet|na web|no google|online|na rede|em sites?|para mim|pra mim|r[aá]pido)\s*[,:]?\s*)+/i, '')
    .replace(/^(?:sobre|por|a respeito de|acerca de|informa[cç][õo]es sobre|o seguinte)\s*[:,]?\s*/i, '')
    .replace(/\s+(?:na internet|na web|no google|online)\s*([?.!]*)$/i, '$1').trim()
  return r.length >= 3 ? r : t
}

export function decidir(texto: string, c: ConvCtx = {}, o: { agora?: number; janelaMin?: number } = {}): Decisao {
  const s = nrm(texto), palavras = s ? s.split(' ').length : 0, agora = o.agora ?? Date.now()
  const ult = [...(c.acoes || [])].reverse().find((a) => a && a.id && agora - new Date(a.em).getTime() < (o.janelaMin ?? 120) * 60_000) || null
  const alvo = ult ? { tipo: ult.tipo, id: Number(ult.id) } : null
  const base = (p: Prioridade, d: Dominio, motivo: string, extra: Partial<Decisao> = {}): Decisao => ({ prioridade: p, dominio: d, pesquisa: p === 'operacao' || p === 'continuacao_operacao' ? 'bloqueada' : p === 'pesquisa_explicita' ? 'explicita' : p === 'pesquisa_atual' ? 'atual' : 'permitida', consulta: String(texto || '').trim(), alvo: null, motivo, ...extra })
  if (!s) return base('conversa', null, 'mensagem vazia')

  // 1) pesquisa pedida explicitamente (verbo de pesquisa no começo) — sobre dados internos ("pesquise na minha agenda") é operação
  // o QUE pesquisar é o que vem logo depois do verbo: "pesquise na minha agenda…" é busca interna; "pesquise o preço de X e
  // compare com os meus gastos" é pedido misto (pesquisa externa + dados próprios) — fica com o orquestrador, sem forçar nada
  const resto = s.replace(PESQ_VERBO, '').trim(), inicio = resto.split(' ').slice(0, 6).join(' ')
  const OBJ_INT = /\b(compromissos?|agendamentos?|tarefas?|lembretes?|notas?|anotac\w*|gastos?|despesas?|lancamentos?|clientes?|pedidos?)\b/
  const objInterno = PESQ_VERBO.test(s) && (INTERNO.test(inicio) || OBJ_INT.test(inicio))
  if (PESQ_VERBO.test(s) && !objInterno && (INTERNO.test(s) || OBJ_INT.test(resto))) return base('conhecimento', null, 'pedido misto: pesquisa externa + dados próprios (o orquestrador decide)')
  const pedePesquisa = (PESQ_VERBO.test(s) || NOTICIAS.test(s) || COMPARE_PRECOS.test(s)) && !INTERNO.test(s)
  if (pedePesquisa && !(PESQ_VERBO.test(s) && !NA_WEB.test(s) && (VERBO_OP.test(resto) || objInterno))) {
    const consulta = PESQ_VERBO.test(s) ? consultaSemComando(texto) : String(texto).trim()
    return base('pesquisa_explicita', null, 'o usuário pediu pesquisa', { consulta, pesquisa: TEMPO_REAL.test(nrm(consulta)) || NOTICIAS.test(s) || COMPARE_PRECOS.test(s) ? 'atual' : 'explicita' })
  }

  if (objInterno && !NA_WEB.test(s)) return base('operacao', dominioDoTexto(s), 'busca nos próprios registros (não é pesquisa na internet)')

  // 2) pendência aberta nesta conversa (agendamento em partes, confirmação de cancelamento, campo que faltou)
  const pend = c.pendente
  if (pend && (CONFIRMA.test(s) || SO_DADO.test(s) || (VERBO_CONT.test(s) && !PERGUNTA_GERAL.test(s)) || (palavras <= 8 && !PERGUNTA_GERAL.test(s) && !TEMPO_REAL.test(s)))) {
    const tp = pend.tipo === 'agendamento' || pend.tipo === 'cancelar' || pend.tipo === 'editar_appt' ? 'agenda' : (TIPO_DOMINIO[String(pend.tipo || '').replace(/^editar_/, '')] || null)
    return base('continuacao_operacao', tp, `responde à pendência "${pend.tipo}" desta conversa`, { alvo: pend.id ? { tipo: 'appointment', id: Number(pend.id) } : alvo })
  }

  // 3) operação interna explícita
  if (MOVIMENTO.test(s) && /\d/.test(s)) return base('operacao', 'financeiro', 'registro financeiro (gastei/paguei/recebi + valor)')
  if (CONSULTA_PESSOAL.test(s)) return base('operacao', dominioDoTexto(s) || 'agenda', 'consulta dos próprios dados')
  if (VERBO_OP.test(s) && (OBJETO_OP.test(s) || DADO_OP.test(s) || /\bque\b/.test(s))) {
    // verbo de edição curto sem objeto novo, logo depois de uma ação desta conversa = continuação dessa ação
    const d = dominioDoTexto(s)
    if (alvo && VERBO_CONT.test(s) && palavras <= 14 && (!d || d === TIPO_DOMINIO[alvo.tipo] || /\b(o|a|esse|essa|desse|dessa|deste|desta)\s+(valor|horario|data|dia|cliente|telefone|observac\w*|descricao|categoria|vencimento|prazo|titulo|nome)\b/.test(s)) && !/\b(novo|nova|outro|outra|mais um|mais uma)\s+(compromisso|agendamento|lembrete|tarefa|nota|gasto|despesa|conta)\b/.test(s))
      return base('continuacao_operacao', TIPO_DOMINIO[alvo.tipo] || d, `continua a última ação desta conversa (${alvo.tipo} ${alvo.id})`, { alvo })
    return base('operacao', d || (alvo ? TIPO_DOMINIO[alvo.tipo] : null), 'pedido operacional (verbo de ação + objeto/dado)')
  }

  // 4) continuação curta sem objeto explícito ("pode cancelar", "é esse mesmo", "só altere o horário", "15h")
  if (alvo && palavras <= 14 && !PERGUNTA_GERAL.test(s) && (VERBO_CONT.test(s) || CONFIRMA.test(s) || SO_DADO.test(s) || /^(e|tambem|alem disso)\s+(o|a)\s+(telefone|valor|horario|cliente|observac\w*|descricao)\b/.test(s)))
    return base('continuacao_operacao', TIPO_DOMINIO[alvo.tipo] || null, `continua a última ação desta conversa (${alvo.tipo} ${alvo.id})`, { alvo })

  // 4b) verbo de edição curto sem registro desta conversa ("acrescente essa informação", "pode cancelar") continua sendo
  // um pedido operacional — nunca vira pergunta de conhecimento sobre o assunto anterior (o sistema pergunta qual registro)
  if (VERBO_CONT.test(s) && palavras <= 10 && !PERGUNTA_GERAL.test(s) && !/\?$/.test(String(texto).trim())) return base('operacao', dominioDoTexto(s), 'pedido de alteração sem registro citado nesta conversa')
  // confirmação curta ("é esse mesmo", "isso mesmo") não é pergunta: nada a pesquisar
  if (CONFIRMA.test(s)) return base('conversa', null, 'confirmação curta', { pesquisa: 'bloqueada' })

  // 5) informação atual/externa (não pessoal)
  if (TEMPO_REAL.test(s) && !INTERNO.test(s)) return base('pesquisa_atual', null, 'informação atual/externa')

  // 6) conhecimento × conversa
  if (/\?$/.test(String(texto).trim()) || PERGUNTA_GERAL.test(s) || /^(qual|quais|quem|quando|onde|quanto|quantos|quantas|como)\b/.test(s)) return base('conhecimento', null, 'pergunta (Cérebro primeiro; pesquisa só se ele não souber)')
  return base('conversa', null, 'sem operação nem pedido de pesquisa')
}
