// DIAGNÓSTICO DO NÚCLEO DE INTELIGÊNCIA (Fase 3) — roda o corpus sintético (nenhuma conversa de usuário) contra os
// componentes reais, sem IA e sem banco: acerto por área, cada falha com esperado × obtido, conjunto de VALIDAÇÃO
// (casos escritos depois das correções, para medir generalização) e latência de cada função.
// Usado pelo painel (Inteligência avançada → Diagnóstico), pelo monitor contínuo e pela suíte de testes.
import * as COG from '../cognition.js'
import * as ESP from '../especialistas.js'
import * as PLAN from '../planejador.js'
import * as N from '../nucleo.js'
import * as MEM from '../memoria.js'
import * as AV from '../autoverificacao.js'
import * as AG from '../agentes.js'
import * as SEM from '../semantica.js'
import { ENTRADAS, RESPOSTAS, VALIDACAO, VALIDACAO_RESPOSTAS, MEMORIAS_FICTICIAS, RECUPERACAO, type CasoEntrada, type CasoResposta } from './corpus.js'

const TOOLS_P = ['create_task', 'create_appointment', 'create_reminder', 'add_shopping_items', 'create_note', 'register_transaction', 'create_bill', 'complete_task', 'save_memory', 'get_agenda', 'get_finance'].map((name) => ({ function: { name } }))
const TOOLS_E = [...TOOLS_P, ...['crm_buscar_cliente', 'crm_atualizar_etapa', 'negocio_resumo', 'agenda_empresa_horarios', 'agenda_empresa_decidir'].map((name) => ({ function: { name } }))]
const eqSet = (a: string[], b: string[]) => a.length === b.length && a.every((x) => b.includes(x))

type Falha = { id: string; area: string; componente: string; esperado: any; obtido: any; texto: string }
function rodarEntrada(c: CasoEntrada, F: Falha[]) {
  const hist = c.hist || [], an = COG.analisar(c.texto, hist), ok: boolean[] = []
  const chk = (componente: string, cond: boolean, esperado: any, obtido: any) => { ok.push(cond); if (!cond) F.push({ id: c.id, area: c.area, componente, esperado, obtido, texto: c.texto }) }
  if (c.tipo !== undefined) chk('intenção', an.tipo === c.tipo, c.tipo, an.tipo)
  if (c.comp !== undefined) chk('completude', an.completude === c.comp, c.comp, an.completude)
  if (c.falta !== undefined) chk('lacunas', eqSet(an.faltando, c.falta), c.falta, an.faltando)
  if (c.amb !== undefined) chk('ambiguidade', (an.ambiguidades.length > 0) === c.amb, c.amb, an.ambiguidades)
  if (c.contra !== undefined) chk('contradição', (an.contradicoes.length > 0) === c.contra, c.contra, an.contradicoes)
  if (c.emo !== undefined) chk('emoção', an.emocao === c.emo, c.emo, an.emocao)
  if (c.reg !== undefined) chk('registro', an.registro === c.reg, c.reg, an.registro)
  if (c.esp || c.espInclui || c.espNao) {
    const sel = ESP.selecionar(c.texto, an, c.empresa ? TOOLS_E : TOOLS_P, c.anterior || [])
    if (c.esp) chk('especialista principal', sel.principal === c.esp, c.esp, sel.ids)
    if (c.espInclui) chk('especialistas incluídos', c.espInclui.every((x) => sel.ids.includes(x)), c.espInclui, sel.ids)
    if (c.espNao) chk('especialistas indevidos', !c.espNao.some((x) => sel.ids.includes(x)), c.espNao, sel.ids)
  }
  if (c.plano) { const e = PLAN.decompor(c.texto).map((x) => x.ferramenta); chk('plano', JSON.stringify(e) === JSON.stringify(c.plano), c.plano, e) }
  if (c.fio || c.fioNao) { const f = N.fioDaConversa(hist, c.texto, an).join(' | '); if (c.fio) chk('fio da conversa', c.fio.test(f), String(c.fio), f); if (c.fioNao) chk('fio sem erro', !c.fioNao.test(f), 'não ' + String(c.fioNao), f) }
  if (c.estilo !== undefined) { const e = N.estiloPedido(c.texto); chk('formato pedido', c.estilo === 0 ? e.length === 0 : e.length >= c.estilo, c.estilo, e) }
  if (c.chave !== undefined) { const k = MEM.chaveUnica(c.texto); chk('memória (informação única)', k === c.chave, c.chave, k) }
  if (c.nivel || c.agentes) {
    const sel = ESP.selecionar(c.texto, an, c.empresa ? TOOLS_E : TOOLS_P), et = PLAN.decompor(c.texto), cx = AG.avaliarComplexidade(c.texto, an, sel, et.length ? { etapas: et, status: 'ativo' } : null)
    const ags = AG.selecionarAgentes(cx, { ...AG.MA_DEFAULT, agentes: { ...AG.MA_DEFAULT.agentes } } as any).map((a) => a.id)
    if (c.nivel) chk('complexidade', cx.nivel === c.nivel, c.nivel, cx.nivel + ' ' + cx.pontos)
    if (c.agentes) chk('agentes acionados', ags.length === c.agentes.length && c.agentes.every((x) => ags.includes(x)), c.agentes, ags)
  }
  if (c.fatos) { const f = [...new Set(COG.fatosDuradouros(c.texto).map((x) => x.categoria))]; chk('fatos duradouros', eqSet(f, c.fatos), c.fatos, f) }
  return ok
}
function rodarResposta(c: CasoResposta, F: Falha[]) {
  const ok: boolean[] = [], chk = (componente: string, cond: boolean, esperado: any, obtido: any) => { ok.push(cond); if (!cond) F.push({ id: c.id, area: c.area, componente, esperado, obtido, texto: c.resposta }) }
  const exec = { ...COG.execVazio(), ...(c.exec || {}) }
  if (c.area === 'Confiabilidade' || c.area === 'Naturalidade') {
    const r = COG.revisarResposta(c.resposta, { exec, fontes: c.fontes || '', respostaAnterior: c.anterior })
    if (c.mudou !== undefined) chk('revisão alterou?', (r.content !== c.resposta) === c.mudou, c.mudou, r.content)
    if (c.contem) chk('conteúdo esperado', c.contem.test(r.content), String(c.contem), r.content)
    if (c.naoContem) chk('conteúdo removido', !c.naoContem.test(r.content), 'sem ' + String(c.naoContem), r.content)
    if (c.flags) chk('sinalizações', c.flags.every((f) => r.flags.includes(f)), c.flags, r.flags)
  } else if (c.area === 'Avaliação') {
    const q = COG.avaliar({ texto: c.texto || '', resposta: c.resposta, analise: COG.analisar(c.texto || '', c.hist || []), hist: c.hist, ferramentas: 8, caminho: 'ia' })
    if (c.flags) chk('sinalizações de qualidade', c.flags.every((f) => q.flags.includes(f)), c.flags, q.flags)
    if (c.semFlags) chk('sem sinalização indevida', !c.semFlags.some((f) => q.flags.includes(f)), 'sem ' + c.semFlags, q.flags)
  } else if (c.area === 'Autoverificação') {
    const P = AV.verificar({ texto: c.texto || '', resposta: c.resposta, fontes: c.fontes || '', plano: null, especialistas: c.especialistas || [], exec: { ...exec, leituras: c.especialistas?.includes('financas') ? ['get_finance'] : [] }, anteriores: [], clareza: 100 })
    const tipos = P.map((p) => p.tipo)
    if (c.problemas) chk('problemas detectados', c.problemas.every((t) => tipos.includes(t as any)), c.problemas, P.map((p) => p.detalhe))
    if (c.semProblemas) chk('sem falso problema', P.length === 0, 'nenhum', P.map((p) => p.detalhe))
  }
  return ok
}
function latencia() {
  const t = (fn: () => void, n = 40) => { const xs: number[] = []; for (let i = 0; i < n; i++) { const a = performance.now(); fn(); xs.push((performance.now() - a) * 1000) } xs.sort((a, b) => a - b); return { mediaUs: Math.round(xs.reduce((a, b) => a + b, 0) / xs.length), p95Us: Math.round(xs[Math.floor(xs.length * 0.95)]) } }
  const textos = ENTRADAS.map((c) => [c.texto, c.hist || []] as const)
  return {
    analisar: t(() => { for (const [x, hh] of textos) COG.analisar(x, hh) }),
    especialistas: t(() => { for (const [x, hh] of textos) ESP.selecionar(x, COG.analisar(x, hh), TOOLS_E) }),
    planejamento: t(() => { for (const [x] of textos) PLAN.decompor(x) }),
    fioDaConversa: t(() => { for (const [x, hh] of textos) N.fioDaConversa(hh, x, COG.analisar(x, hh)) }),
    revisarResposta: t(() => { for (const c of RESPOSTAS) COG.revisarResposta(c.resposta, { exec: COG.execVazio(), fontes: c.fontes || '' }) }),
    avaliar: t(() => { for (const c of RESPOSTAS) COG.avaliar({ texto: c.texto || '', resposta: c.resposta, analise: COG.analisar(c.texto || '') }) }),
    autoverificacao: t(() => { for (const c of RESPOSTAS) AV.verificar({ texto: c.texto || '', resposta: c.resposta, fontes: c.fontes || '', plano: null, especialistas: ['financas'], exec: COG.execVazio(), anteriores: [], clareza: 100 }) }),
    porMensagem: t(() => { for (const [x, hh] of textos) { const an = COG.analisar(x, hh); ESP.selecionar(x, an, TOOLS_E); PLAN.decompor(x); N.fioDaConversa(hh, x, an); N.estiloPedido(x) } }, 20),
    casos: textos.length, respostas: RESPOSTAS.length,
  }
}

export function diagnosticar() {
  const F: Falha[] = [], porArea: Record<string, { total: number; ok: number }> = {}, porComp: Record<string, { total: number; ok: number }> = {}
  const somar = (area: string, oks: boolean[], antes: number) => { porArea[area] ||= { total: 0, ok: 0 }; porArea[area].total += oks.length; porArea[area].ok += oks.filter(Boolean).length; return antes }
  for (const c of ENTRADAS) { const n = F.length, oks = rodarEntrada(c, F); somar(c.area, oks, n) }
  for (const c of RESPOSTAS) { const n = F.length, oks = rodarResposta(c, F); somar(c.area, oks, n) }
  { // recuperação semântica da memória (Fase 5)
    const ind = SEM.indexar(MEMORIAS_FICTICIAS.map((texto, i) => ({ id: i + 1, texto })))
    for (const c of RECUPERACAO) {
      const ach = SEM.buscar(ind, c.consulta, { k: 3 }), top = ach.map((a) => a.doc.base.texto), oks: boolean[] = []
      const chk = (componente: string, cond: boolean, esperado: any) => { oks.push(cond); if (!cond) F.push({ id: c.id, area: 'Recuperação semântica', componente, esperado, obtido: top, texto: c.consulta }) }
      chk('memória relevante encontrada', c.traz.every((t) => top.includes(t)), c.traz)
      if (c.naoTraz) chk('memória irrelevante fora', !c.naoTraz.some((t) => top.includes(t)), 'sem ' + c.naoTraz.join(', '))
      if (c.associa) chk('associação', [...top, ...SEM.associar(ind, ach, 3, c.consulta).map((a) => a.doc.base.texto)].includes(c.associa), c.associa)
      porArea['Recuperação semântica'] ||= { total: 0, ok: 0 }; porArea['Recuperação semântica'].total += oks.length; porArea['Recuperação semântica'].ok += oks.filter(Boolean).length
    }
  }
  const total = Object.values(porArea).reduce((a, b) => a + b.total, 0), ok = Object.values(porArea).reduce((a, b) => a + b.ok, 0)
  const FV: Falha[] = []; let vt = 0, vo = 0
  for (const c of VALIDACAO) { const oks = rodarEntrada(c, FV); vt += oks.length; vo += oks.filter(Boolean).length }
  for (const c of VALIDACAO_RESPOSTAS) { const oks = rodarResposta(c, FV); vt += oks.length; vo += oks.filter(Boolean).length }
  const validacao = { verificacoes: vt, aprovadas: vo, taxa: Math.round((vo / vt) * 1000) / 10, falhas: FV }
  for (const f of F) { porComp[f.componente] ||= { total: 0, ok: 0 }; porComp[f.componente].total++ }
  return { em: new Date().toISOString(), verificacoes: total, aprovadas: ok, taxa: Math.round((ok / total) * 1000) / 10, porArea, falhasPorComponente: porComp, falhas: F, validacao, latencia: latencia() }
}

