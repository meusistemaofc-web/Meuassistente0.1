import { config } from './config.js'
import { connectFromEnv } from './db/connect.js'
import { migrate } from './db/migrate.js'
import { createApp, indexHtmlPresent } from './app.js'
import { startScheduler } from './scheduler.js'
import { ensureSetupCode } from './routes/auth.js'

const d = await connectFromEnv()
if (process.env.AUTO_MIGRATE !== 'false') await migrate(d, config.migrationsDir)
await (await import('./lib/usermod.js')).modules().catch(() => {})
await (await import('./routes/kb.js')).seedKb().catch((e) => console.error('[kb] seed:', e?.message)) // materiais iniciais da Biblioteca de Sobrevivência // carrega os módulos ligados/desligados pelo administrador
if (!indexHtmlPresent()) console.warn(`[app] ATENÇÃO: frontend não encontrado em ${config.staticDir}`)
const code = await ensureSetupCode()
if (code) console.log(`[setup] Já existem contas e nenhum Administrador Principal. Código de configuração: ${code} (use em /configuracao-inicial)`)
void import('./lib/account.js').then((m) => m.refreshVoiceGlobal()).catch(() => {})
void import('./lib/invite.js').then((m) => m.refreshInvite()).catch(() => {})
void import('./lib/publicurl.js').then((m) => m.refreshPublicUrl()).catch(() => {})
if (config.schedulerEnabled) startScheduler()
void import('./lib/menu-import.js').then((m) => m.retomarPendentes())
// memória evolutiva: retenção configurada por cada usuário e marcação de memórias antigas (5 min após subir e 1×/dia)
{ const run = () => void import('./ai/memoria-evolutiva.js').then((m) => m.aplicarRetencao()).catch((e) => console.error('[memória] retenção:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 24 * 3600e3).unref() }, 300_000); t.unref() }
// avaliação contínua da inteligência: bateria automática + indicadores + alerta de regressão (90 s após subir e a cada 6 h)
{ const run = () => void import('./ai/avaliacao.js').then((m) => m.monitorar()).catch((e) => console.error('[inteligência] monitor:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 6 * 3600e3).unref() }, 90_000); t.unref() }
// Fase 7: avisos preditivos (respeitam preferências, horário de silêncio e limite diário) a cada hora; conferência das previsões 1x/dia
{ const run = () => void import('./ai/preditivo-servico.js').then((m) => m.rodarNotificacoes()).catch((e) => console.error('[preditivo] avisos:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 3600e3).unref() }, 120_000); t.unref() }
{ const run = () => void import('./ai/preditivo-servico.js').then((m) => m.avaliarPrevisoes()).catch((e) => console.error('[preditivo] conferência:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 24 * 3600e3).unref() }, 600_000); t.unref() }
// Fase 8: fila de execuções em segundo plano (e retomada das interrompidas)
{ const t = setInterval(() => void import('./ai/execucao.js').then((m) => m.processarFila()).catch((e) => console.error('[execução] fila:', e?.message)), 3000); t.unref() }
// Fase 9: desafios contínuos programados no Laboratório (e vigilância dos especialistas em liberação gradual)
{ const t = setInterval(() => void import('./ai/laboratorio.js').then((m) => m.rodarAgendadas()).catch((e) => console.error('[laboratório] agendadas:', e?.message)), 10 * 60_000); t.unref() }
;(await import('./ai/provider.js')).startAiMonitor() // monitor de saúde: recupera IAs em pausa sozinho
const server = createApp()
server.listen(config.port, config.host, () => console.log(`[app] Meu Assistente ouvindo em http://${config.host}:${config.port} (público: ${config.publicUrl})`))
const stop = async () => { await (await import('./ai/health.js')).flushStats().catch(() => {}); server.close(); await d.close().catch(() => {}); process.exit(0) }
process.on('SIGTERM', stop)
process.on('SIGINT', stop)
