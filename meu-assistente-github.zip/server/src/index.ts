import { config } from './config.js'
import { connectFromEnv } from './db/connect.js'
import { migrate } from './db/migrate.js'
import { createApp, indexHtmlPresent } from './app.js'
import { startScheduler } from './scheduler.js'
import { ensureSetupCode } from './routes/auth.js'

const d = await connectFromEnv()
if (process.env.AUTO_MIGRATE !== 'false') await migrate(d, config.migrationsDir)
await (await import('./lib/usermod.js')).modules().catch(() => {})
// integrações das empresas: copia para empresa_integracoes o que ainda está no formato antigo (sem apagar nada) e confere
// se todas as credenciais salvas abrem com as chaves atuais (APP_SECRET trocado/removido aparece aqui, sem perder dados)
await (await import('./lib/integracoes.js')).importarTodas().then((n) => { if (n) console.log(`[integrações] ${n} integração(ões) de empresas trazida(s) para a estrutura própria (originais mantidos)`) }).catch((e) => console.error('[integrações] importação:', e?.message))
await (await import('./lib/settings.js')).diagnosticoCofre().then((c) => { if (!c.ok) console.error('[cofre] ATENÇÃO:', c.mensagem) }).catch(() => {})
await (await import('./routes/kb.js')).seedKb().catch((e) => console.error('[kb] seed:', e?.message)) // materiais iniciais da Biblioteca de Sobrevivência // carrega os módulos ligados/desligados pelo administrador
if (!indexHtmlPresent()) console.warn(`[app] ATENÇÃO: frontend não encontrado em ${config.staticDir}`)
const code = await ensureSetupCode()
if (code) console.log(`[setup] Já existem contas e nenhum Administrador Principal. Código de configuração: ${code} (use em /configuracao-inicial)`)
void import('./lib/account.js').then((m) => m.refreshVoiceGlobal()).catch(() => {})
void import('./lib/invite.js').then((m) => m.refreshInvite()).catch(() => {})
void import('./lib/publicurl.js').then((m) => m.refreshPublicUrl()).catch(() => {})
if (config.schedulerEnabled) startScheduler()
if (config.schedulerEnabled) (await import('./ai/cerebro/central.js')).iniciarAgendador() // Cérebro Central: tarefas de estudo programadas (1 por minuto, no máximo)
void import('./lib/menu-import.js').then((m) => m.retomarPendentes())
// memória evolutiva: retenção configurada por cada usuário e marcação de memórias antigas (5 min após subir e 1×/dia)
{ const run = () => void import('./ai/memoria-evolutiva.js').then((m) => m.aplicarRetencao()).catch((e) => console.error('[memória] retenção:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 24 * 3600e3).unref() }, 300_000); t.unref() }
// avaliação contínua da inteligência: bateria automática + indicadores + alerta de regressão (90 s após subir e a cada 6 h)
{ const run = () => void import('./ai/avaliacao.js').then((m) => m.monitorar()).catch((e) => console.error('[inteligência] monitor:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 6 * 3600e3).unref() }, 90_000); t.unref() }
// Fase 7: avisos preditivos (respeitam preferências, horário de silêncio e limite diário) a cada hora; conferência das previsões 1x/dia
{ const run = () => void import('./ai/preditivo-servico.js').then((m) => m.rodarNotificacoes()).catch((e) => console.error('[preditivo] avisos:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 3600e3).unref() }, 120_000); t.unref() }
{ const run = () => void import('./ai/preditivo-servico.js').then((m) => m.avaliarPrevisoes()).catch((e) => console.error('[preditivo] conferência:', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 24 * 3600e3).unref() }, 600_000); t.unref() }
// Fase 8: fila de execuções em segundo plano (e retomada das interrompidas)
// lixeira de empresas: exclusão definitiva automática depois de 30 dias (a cada hora; e logo após iniciar)
{ const run = () => void import('./lib/lixeira-empresas.js').then(async (m) => { const n = await m.limparVencidas(); if (n) console.log(`[lixeira] ${n} empresa(s) excluída(s) definitivamente`) }).catch((e) => console.error('[lixeira]', e?.message)); const t = setTimeout(() => { run(); setInterval(run, 3600e3).unref() }, 60_000); t.unref() }
{ const t = setInterval(() => void import('./ai/execucao.js').then((m) => m.processarFila()).catch((e) => console.error('[execução] fila:', e?.message)), 3000); t.unref() }
// Fase 9: desafios contínuos programados no Laboratório (e vigilância dos especialistas em liberação gradual)
{ const t = setInterval(() => void import('./ai/laboratorio.js').then((m) => m.rodarAgendadas()).catch((e) => console.error('[laboratório] agendadas:', e?.message)), 10 * 60_000); t.unref() }
;(await import('./ai/provider.js')).startAiMonitor() // monitor de saúde: recupera IAs em pausa sozinho
const server = createApp()
;(await import('./lib/tarefas-chat.js')).iniciarVarredura() // tarefas do chat que o processo anterior deixou pela metade: encerra com aviso (pedido guardado)
server.listen(config.port, config.host, () => console.log(`[app] Meu Assistente ouvindo em http://${config.host}:${config.port} (público: ${config.publicUrl})`))
const stop = async () => { await (await import('./ai/health.js')).flushStats().catch(() => {}); server.close(); await d.close().catch(() => {}); process.exit(0) }
process.on('SIGTERM', stop)
process.on('SIGINT', stop)
