/* Agenda → Compromissos: visualização em CALENDÁRIO (a lista continua sendo a visualização padrão).
   Ícone discreto ao lado de "+ Compromisso". Usa os MESMOS compromissos do banco (GET /api/v2/compromissos?de=&ate=,
   só do usuário logado); abrir um compromisso usa o painel de detalhes que já existe (window.maApptDrawer).
   Não cria cadastro paralelo e não mexe em lembretes/notificações. */
(function(){
if(window.__maCal)return;window.__maCal=true;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const MESES=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const SEM=['D','S','T','Q','Q','S','S'];
const ST={scheduled:'',confirmed:'Confirmado',done:'Concluído',cancelled:'Cancelado',no_show:'Não compareceu'};
const ICO='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>';
const CHEV=d=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d<0?'M15 6l-6 6 6 6':'M9 6l6 6-6 6'}"/></svg>`;
const pad=n=>String(n).padStart(2,'0'),isoDe=(y,m,d)=>`${y}-${pad(m+1)}-${pad(d)}`;
const somaDias=(iso,n)=>{const d=new Date(iso+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)};

function css(){if(document.getElementById('ma-cal-css'))return;const s=document.createElement('style');s.id='ma-cal-css';s.textContent=`
.ma-cal-btn{display:inline-grid;place-items:center;width:36px;height:36px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 12%,transparent);background:transparent;color:var(--nx-ink-2,#bbb);cursor:pointer;transition:color .15s,background .15s;flex:none}
.ma-cal-btn:focus-visible{color:var(--nx-ink,#fff);background:color-mix(in srgb,var(--nx-ink,#fff) 6%,transparent);outline:none}
.ma-cal-btn:active{transform:scale(.96)}
.ma-cal{position:fixed;inset:0;z-index:110;background:var(--nx-canvas,#0b0b0d);color:var(--nx-ink,#f2f2f2);display:flex;flex-direction:column;animation:ma-cal-in .18s ease-out}
@keyframes ma-cal-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.ma-cal-in{width:100%;max-width:34rem;margin:0 auto;flex:1;display:flex;flex-direction:column;min-height:0;padding:max(14px,env(safe-area-inset-top)) 16px 0;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
/* com o gráfico de evolução acima, a tela inteira rola (a lista do dia não fica espremida) */
.ma-cal-top,.ma-cal-sem,.ma-cal-grid,.ma-cal-carr,.ma-evo{flex:none}
.ma-cal-top{display:flex;align-items:center;gap:8px;height:44px}
.ma-cal-ib{display:grid;place-items:center;width:38px;height:38px;border-radius:999px;border:0;background:transparent;color:var(--nx-ink-2,#bbb);cursor:pointer}

.ma-cal-mes{flex:1;text-align:center;font-size:16px;font-weight:600;letter-spacing:.01em;text-transform:capitalize}
.ma-cal-hoje{height:30px;padding:0 12px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);background:transparent;color:var(--nx-ink-2,#bbb);font-size:12.5px;font-weight:600;cursor:pointer}
.ma-cal-hoje[disabled]{opacity:.35;cursor:default}
.ma-cal-sem{display:grid;grid-template-columns:repeat(7,1fr);margin-top:10px;font-size:11px;color:var(--nx-ink-3,#888);text-align:center;letter-spacing:.06em}
.ma-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-top:6px;touch-action:pan-y}
.ma-cal-d{position:relative;aspect-ratio:1/1;max-height:52px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;border:0;border-radius:14px;background:transparent;color:inherit;font-size:14.5px;font-variant-numeric:tabular-nums;cursor:pointer;padding:0}
.ma-cal-d.fora{color:var(--nx-ink-3,#777);opacity:.45}

.ma-cal-d.hj span{color:var(--nx-accent,#7aa2ff);font-weight:700}
.ma-cal-d.sel{background:color-mix(in srgb,var(--nx-ink,#fff) 10%,transparent)}
.ma-cal-d.sel.hj{background:color-mix(in srgb,var(--nx-accent,#7aa2ff) 18%,transparent)}
.ma-cal-pts{display:flex;gap:3px;height:4px}
.ma-cal-pts i{width:4px;height:4px;border-radius:99px;background:var(--nx-ink-2,#bbb);opacity:.8}
.ma-cal-d.hj .ma-cal-pts i,.ma-cal-d.sel .ma-cal-pts i{background:var(--nx-accent,#7aa2ff);opacity:1}
.ma-cal-lst{flex:1 0 auto;min-height:120px;margin-top:14px;padding-bottom:max(18px,env(safe-area-inset-bottom));border-top:1px solid color-mix(in srgb,var(--nx-ink,#fff) 7%,transparent)}
.ma-cal-dia{padding:14px 2px 6px;font-size:12px;color:var(--nx-ink-3,#888);text-transform:uppercase;letter-spacing:.06em}
.ma-cal-it{display:flex;align-items:flex-start;gap:12px;width:100%;padding:11px 4px;border:0;border-radius:14px;background:transparent;color:inherit;text-align:left;cursor:pointer}
/* destaque ao passar o mouse só em quem tem mouse (no toque ele "grudaria" no dia tocado) */
@media (hover:hover){.ma-cal-btn:hover{color:var(--nx-ink,#fff);background:color-mix(in srgb,var(--nx-ink,#fff) 6%,transparent)}.ma-cal-ib:hover{background:color-mix(in srgb,var(--nx-ink,#fff) 6%,transparent);color:var(--nx-ink,#fff)}.ma-cal-d:hover{background:color-mix(in srgb,var(--nx-ink,#fff) 5%,transparent)}.ma-cal-it:hover{background:color-mix(in srgb,var(--nx-ink,#fff) 4%,transparent)}}
.ma-cal-h{width:48px;flex:none;font-size:14px;font-weight:600;font-variant-numeric:tabular-nums;padding-top:1px}
.ma-cal-h small{display:block;font-size:11px;font-weight:400;color:var(--nx-ink-3,#888)}
.ma-cal-t{flex:1;min-width:0}.ma-cal-t b{display:block;font-size:14.5px;font-weight:600;overflow-wrap:anywhere}
.ma-cal-t span{display:block;margin-top:2px;font-size:12.5px;color:var(--nx-ink-3,#888);overflow-wrap:anywhere}
.ma-cal-it.cx .ma-cal-t b{text-decoration:line-through;opacity:.6}
.ma-cal-vz{padding:22px 4px;font-size:13.5px;color:var(--nx-ink-3,#888)}
.ma-cal-carr{height:2px;margin-top:8px;border-radius:2px;background:linear-gradient(90deg,transparent,var(--nx-accent,#7aa2ff),transparent);background-size:200% 100%;animation:ma-cal-l 1s linear infinite;opacity:0;transition:opacity .2s}
.ma-cal-carr.on{opacity:.7}@keyframes ma-cal-l{from{background-position:100% 0}to{background-position:-100% 0}}
`;document.head.appendChild(s)}

/* ---------- ícone ao lado de "+ Compromisso" (página Agenda → Compromissos) ---------- */
function botaoCompromisso(){
  if(!/^\/agenda\b/.test(location.pathname))return null;
  return [...document.querySelectorAll('main button, button')].find(b=>!b.closest('.ma-cal')&&b.textContent.trim()==='Compromisso'&&b.querySelector('svg')&&b.parentElement&&/justify-end/.test(b.parentElement.className))||null;
}
function injetar(){
  const b=botaoCompromisso();if(!b)return;const pai=b.parentElement;
  if(pai.querySelector('.ma-cal-btn'))return;
  css();pai.style.gap='8px';pai.style.alignItems='center';
  const ic=document.createElement('button');ic.type='button';ic.className='ma-cal-btn';ic.setAttribute('aria-label','Ver calendário');ic.title='Calendário';ic.innerHTML=ICO;
  ic.onclick=()=>abrir();pai.insertBefore(ic,b);
}
new MutationObserver(()=>{clearTimeout(window.__maCalT);window.__maCalT=setTimeout(injetar,60)}).observe(document.documentElement,{childList:true,subtree:true});
document.addEventListener('DOMContentLoaded',injetar);setTimeout(injetar,300);

/* ---------- calendário ---------- */
let ov=null,est=null;
async function carregar(){
  // grade de 6 semanas: busca do primeiro ao último dia visível (dias do mês anterior/seguinte também mostram indicadores)
  const p=new Date(Date.UTC(est.ano,est.mes,1)),ini=somaDias(isoDe(est.ano,est.mes,1),-p.getUTCDay()),fim=somaDias(ini,41);
  const chave=ini+'|'+fim,seq=++est.seq;est.carregando=true;desenhar();
  try{const r=await fetch(`/api/v2/compromissos?de=${ini}&ate=${fim}`,{credentials:'include'});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Não foi possível carregar os compromissos.');
    if(seq!==est.seq)return;est.hoje=j.today||est.hoje;est.itens=j.compromissos||[];est.chave=chave;est.erro=''}
  catch(e){if(seq===est.seq)est.erro=e.message}
  finally{if(seq===est.seq){est.carregando=false;desenhar()}}
}
function porDia(){const m={};for(const a of est.itens)(m[a.date]=m[a.date]||[]).push(a);return m}
function desenhar(){
  if(!ov)return;const m=porDia(),hoje=est.hoje,p=new Date(Date.UTC(est.ano,est.mes,1)),ini=somaDias(isoDe(est.ano,est.mes,1),-p.getUTCDay());
  const dias=[];for(let i=0;i<42;i++)dias.push(somaDias(ini,i));
  const noMes=d=>Number(d.slice(5,7))-1===est.mes&&Number(d.slice(0,4))===est.ano;
  const ehMesAtual=hoje.slice(0,7)===isoDe(est.ano,est.mes,1).slice(0,7);
  const lista=(m[est.sel]||[]).filter(a=>a.date===est.sel);
  const dsel=new Date(est.sel+'T12:00:00Z'),tit=dsel.toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',timeZone:'UTC'});
  ov.querySelector('.ma-cal-mes').textContent=`${MESES[est.mes]} ${est.ano}`;
  ov.querySelector('.ma-cal-hoje').disabled=ehMesAtual&&est.sel===hoje;
  ov.querySelector('.ma-cal-carr').classList.toggle('on',!!est.carregando);
  ov.querySelector('.ma-cal-grid').innerHTML=dias.map(d=>{const n=(m[d]||[]).filter(a=>a.status!=='cancelled').length,c=(m[d]||[]).length;
    const rot=`${Number(d.slice(8))} de ${MESES[Number(d.slice(5,7))-1]}${c?`, ${c} compromisso${c>1?'s':''}`:''}`;
    return `<button type="button" class="ma-cal-d${noMes(d)?'':' fora'}${d===hoje?' hj':''}${d===est.sel?' sel':''}" data-d="${d}" aria-label="${esc(rot)}"${d===est.sel?' aria-pressed="true"':''}><span>${Number(d.slice(8))}</span><span class="ma-cal-pts">${c?Array.from({length:Math.min(3,Math.max(1,n||1))},()=>'<i></i>').join(''):''}</span></button>`}).join('');
  ov.querySelector('.ma-cal-lst').innerHTML=`<p class="ma-cal-dia">${esc(tit)}${est.sel===hoje?' · hoje':''}</p>`+(est.erro?`<p class="ma-cal-vz">${esc(est.erro)}</p>`:!lista.length?`<p class="ma-cal-vz">${est.carregando?'Carregando…':'Nenhum compromisso neste dia.'}</p>`:
    lista.map(a=>{const sub=[a.clienteNome,a.location,ST[a.status]].filter(Boolean).join(' · ');return `<button type="button" class="ma-cal-it${a.status==='cancelled'?' cx':''}" data-id="${a.id}"><span class="ma-cal-h">${a.time?esc(a.time):'—'}${a.endTime?`<small>até ${esc(a.endTime)}</small>`:a.time?'':'<small>sem hora</small>'}</span><span class="ma-cal-t"><b>${esc(a.title)}</b>${sub?`<span>${esc(sub)}</span>`:''}</span></button>`}).join(''));
  ov.querySelectorAll('.ma-cal-d').forEach(b=>b.onclick=()=>{const d=b.dataset.d;est.sel=d;if(!noMes(d)){est.ano=Number(d.slice(0,4));est.mes=Number(d.slice(5,7))-1;carregar()}else desenhar()});
  ov.querySelectorAll('.ma-cal-it').forEach(b=>b.onclick=()=>detalhe(Number(b.dataset.id)));
}
function mudarMes(n){let m=est.mes+n,a=est.ano;while(m<0){m+=12;a--}while(m>11){m-=12;a++}est.mes=m;est.ano=a;
  const ult=new Date(Date.UTC(a,m+1,0)).getUTCDate(),dia=Math.min(Number(est.sel.slice(8)),ult);est.sel=isoDe(a,m,dia);carregar()}
function irHoje(){const h=est.hoje;est.ano=Number(h.slice(0,4));est.mes=Number(h.slice(5,7))-1;est.sel=h;carregar()}
function detalhe(id){
  // painel de detalhes/edição que já existe; ao salvar, recarrega o calendário e avisa a lista
  if(typeof window.maApptDrawer==='function')window.maApptDrawer(id,()=>{est.mudou=true;carregar();evo();try{window.dispatchEvent(new Event('nexa:changed'))}catch(_){}})
  else location.href='/agenda?tab=compromissos';
}
function evo(){try{window.maEvo&&window.maEvo.atualizar()}catch(_){}}
function sincronizar(){if(ov&&document.visibilityState!=='hidden'){carregar();evo()}}
function fechar(){if(!ov)return;try{window.maEvo&&window.maEvo.desmontar()}catch(_){}ov.remove();ov=null;document.documentElement.style.overflow=est.ovAntes||'';window.removeEventListener('keydown',tecla);window.removeEventListener('focus',sincronizar);window.removeEventListener('nexa:changed',aoMudar);document.removeEventListener('visibilitychange',sincronizar);
  if(history.state&&history.state.maCal)history.back();
  // o que mudou dentro do calendário já está no banco: pede para a lista se atualizar
  if(est.mudou){try{window.dispatchEvent(new Event('nexa:changed'))}catch(_){}}}
function tecla(e){if(e.key==='Escape'&&!document.querySelector('.ma-sheet'))fechar();else if(e.key==='ArrowLeft'&&!document.querySelector('.ma-sheet'))mudarMes(-1);else if(e.key==='ArrowRight'&&!document.querySelector('.ma-sheet'))mudarMes(1)}
function aoMudar(){if(ov){carregar();evo()}}
async function abrir(){
  if(ov)return;css();
  const hojeLocal=(()=>{const d=new Date();return isoDe(d.getFullYear(),d.getMonth(),d.getDate())})();
  est={ano:Number(hojeLocal.slice(0,4)),mes:Number(hojeLocal.slice(5,7))-1,sel:hojeLocal,hoje:hojeLocal,itens:[],seq:0,carregando:true,erro:'',mudou:false,ovAntes:document.documentElement.style.overflow};
  ov=document.createElement('div');ov.className='ma-cal';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Calendário de compromissos');
  ov.innerHTML=`<div class="ma-cal-in"><div class="ma-cal-top"><button type="button" class="ma-cal-ib" data-x aria-label="Fechar calendário"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button><span style="font-size:15px;font-weight:600;margin-left:2px">Calendário</span><span style="flex:1"></span><button type="button" class="ma-cal-hoje" data-hoje>Hoje</button></div>
   <div class="ma-evo-slot"></div>
   <div class="ma-cal-top" style="margin-top:4px"><button type="button" class="ma-cal-ib" data-ant aria-label="Mês anterior">${CHEV(-1)}</button><p class="ma-cal-mes" aria-live="polite"></p><button type="button" class="ma-cal-ib" data-prox aria-label="Próximo mês">${CHEV(1)}</button></div>
   <div class="ma-cal-carr"></div><div class="ma-cal-sem" aria-hidden="true">${SEM.map(x=>`<span>${x}</span>`).join('')}</div><div class="ma-cal-grid"></div><div class="ma-cal-lst"></div></div>`;
  document.body.appendChild(ov);document.documentElement.style.overflow='hidden';
  // gráfico "Evolução da agenda" acima do calendário (agenda-evolucao.js)
  try{window.maEvo&&window.maEvo.montar(ov.querySelector('.ma-evo-slot'))}catch(_){}
  ov.querySelector('[data-x]').onclick=fechar;ov.querySelector('[data-hoje]').onclick=irHoje;ov.querySelector('[data-ant]').onclick=()=>mudarMes(-1);ov.querySelector('[data-prox]').onclick=()=>mudarMes(1);
  // deslizar para os lados troca o mês (celular)
  const g=ov.querySelector('.ma-cal-grid');let x0=null,y0=0;g.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;y0=e.touches[0].clientY},{passive:true});
  g.addEventListener('touchend',e=>{if(x0==null)return;const dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;x0=null;if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.5)mudarMes(dx<0?1:-1)},{passive:true});
  // botão "voltar" do celular fecha o calendário em vez de sair da página
  try{history.pushState({...(history.state||{}),maCal:true},'')}catch(_){}
  window.addEventListener('popstate',function pop(){window.removeEventListener('popstate',pop);if(ov){const h=history.state;if(!(h&&h.maCal)){const o=ov;ov=null;try{window.maEvo&&window.maEvo.desmontar()}catch(_){}o.remove();document.documentElement.style.overflow=est.ovAntes||'';window.removeEventListener('keydown',tecla);window.removeEventListener('focus',sincronizar);window.removeEventListener('nexa:changed',aoMudar);document.removeEventListener('visibilitychange',sincronizar);if(est.mudou){try{window.dispatchEvent(new Event('nexa:changed'))}catch(_){}}}}});
  window.addEventListener('keydown',tecla);window.addEventListener('focus',sincronizar);window.addEventListener('nexa:changed',aoMudar);document.addEventListener('visibilitychange',sincronizar);
  desenhar();await carregar();
  // a "data de hoje" vem do servidor (fuso do usuário); se for diferente do relógio do aparelho, ajusta a seleção
  if(est.hoje!==hojeLocal&&est.sel===hojeLocal){est.ano=Number(est.hoje.slice(0,4));est.mes=Number(est.hoje.slice(5,7))-1;est.sel=est.hoje;carregar()}
}
window.maCalendario={abrir,fechar};
})();
