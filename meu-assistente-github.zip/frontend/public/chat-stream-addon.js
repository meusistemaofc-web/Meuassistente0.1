/* Conversas robustas: cada envio ao chat ganha um id. O servidor processa o pedido mesmo se o app sair,
   minimizar ou perder a conexão; ao voltar, a resposta é recuperada pelo id (sem gerar duas vezes).
   Enquanto a resposta é gerada, o texto aparece em tempo real (streaming) numa bolha provisória. */
(function(){
if(window.__maChatJob)return;window.__maChatJob=true;
const nativeFetch=window.fetch.bind(window);
const KEY='ma-chat-jobs';
const uid=()=>'j'+Date.now().toString(36)+Math.random().toString(36).slice(2,12);
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}};
const save=l=>{try{localStorage.setItem(KEY,JSON.stringify(l.slice(-20)))}catch(e){}};
const remember=(id,txt)=>{const l=load().filter(x=>Date.now()-x.at<6*3600e3);l.push({id,at:Date.now(),txt:String(txt||'').slice(0,80)});save(l)};
const forget=id=>save(load().filter(x=>x.id!==id));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const visible=()=>new Promise(r=>{if(!document.hidden)return r();const f=()=>{if(!document.hidden){document.removeEventListener('visibilitychange',f);r()}};document.addEventListener('visibilitychange',f)});
const online=()=>new Promise(r=>{if(navigator.onLine)return r();addEventListener('online',()=>r(),{once:true})});
async function jobStatus(id){try{const r=await nativeFetch('/api/v2/chat/jobs/'+id,{credentials:'same-origin',cache:'no-store'});return r.ok?await r.json():{status:'unknown'}}catch(e){return{status:'offline'}}}
function asResponse(st){if(st.status==='done')return new Response(JSON.stringify(st.result),{status:200,headers:{'Content-Type':'application/json'}});return new Response(JSON.stringify({error:st.error||'Não consegui responder agora.',code:st.code||'ai_error'}),{status:st.httpStatus||502,headers:{'Content-Type':'application/json'}})}
/* bolha provisória com o texto chegando */
/* lista de mensagens da conversa (pai das linhas .msg-swipe); conversa ainda vazia: a própria área de rolagem */
function listaMsgs(){const sc=document.querySelector('.chat-scroll');if(!sc)return null;const r=sc.querySelector('.msg-swipe,[data-mid]');return r&&r.parentElement?r.parentElement:sc}
function liveBubble(id){
  let es=null,box=null,txt='',closed=false;
  const ensure=()=>{if(box&&box.isConnected)return box;const host=listaMsgs();if(!host)return null;
    box=document.createElement('div');box.className='ma-live';box.setAttribute('aria-live','polite');box.style.cssText='display:flex;justify-content:flex-start;padding:4px 16px 8px';box.innerHTML='<div class="glass" style="max-width:85%;border-radius:1.4rem;padding:12px 16px;font-size:15px;line-height:1.5;white-space:pre-wrap;color:var(--nx-ink)"></div>';host.appendChild(box);return box};
  const paint=()=>{const b=ensure();if(!b)return;b.firstChild.textContent=txt;b.removeAttribute('data-processando');const sc=document.querySelector('.chat-scroll');if(sc)sc.scrollTop=sc.scrollHeight};
  /* pedido demorado (pesquisa, análise…): sem texto ainda, mostra que está processando e que dá para sair */
  const espera=setTimeout(()=>{if(closed||txt)return;const b=ensure();if(!b)return;b.setAttribute('data-processando','');b.firstChild.innerHTML=procHtml('Processando seu pedido…')},4000);
  const start=setTimeout(()=>{if(closed||typeof EventSource==='undefined')return;try{es=new EventSource('/api/v2/chat/jobs/'+id+'/stream',{withCredentials:true});
    es.addEventListener('delta',e=>{try{txt+=JSON.parse(e.data)}catch(x){}if(txt.trim())paint()});
    es.addEventListener('reset',()=>{txt='';if(box)box.remove()});
    const end=()=>{try{es.close()}catch(x){}};es.addEventListener('done',end);es.addEventListener('error',()=>{if(es.readyState===2)end()})}catch(x){}},350);
  return{close(){closed=true;clearTimeout(start);clearTimeout(espera);try{es&&es.close()}catch(x){}if(box)box.remove()}};
}
async function recover(id,origErr){
  for(let k=0;k<200;k++){
    await visible();await online();
    const st=await jobStatus(id);
    if(st.status==='done'||st.status==='error'){forget(id);return asResponse(st)}
    if(st.status==='unknown'){forget(id);throw origErr} // o servidor não chegou a receber: segue o fluxo offline normal do app
    await sleep(k<10?800:2000);
  }
  throw origErr;
}
window.fetch=function(input,init){
  init=init||{};
  let url='',method='GET';
  try{url=new URL(typeof input==='string'?input:(input&&input.url)||'',location.href).pathname;method=String(init.method||(input&&input.method)||'GET').toUpperCase()}catch(e){}
  if(method!=='POST'||url!=='/api/chat')return nativeFetch(input,init);
  const id=uid();const h=new Headers(init.headers||(input instanceof Request?input.headers:undefined));h.set('X-Chat-Job',id);
  let body=init.body,conv='';try{const j=typeof body==='string'?JSON.parse(body):null;remember(id,j&&j.text);conv=j&&j.conversationId||''}catch(e){remember(id,'')}try{if(!conv&&body instanceof FormData)conv=String(body.get('conversationId')||'')}catch(e){}
  INF.set(id,{conv,fora:false});
  const ui=liveBubble(id);
  return new Promise((resolve,reject)=>{
    let done=false;const fin=(ok,v)=>{if(done)return;done=true;INF.delete(id);ui.close();document.removeEventListener('visibilitychange',onVis);ok?resolve(v):reject(v)};
    // voltou para o app com o pedido ainda pendurado: pergunta ao servidor
    const onVis=async()=>{if(document.hidden||done)return;await sleep(600);if(done)return;const st=await jobStatus(id);if(!done&&(st.status==='done'||st.status==='error')){forget(id);fin(true,asResponse(st))}};
    document.addEventListener('visibilitychange',onVis);
    nativeFetch(input,{...init,headers:h}).then(r=>{if(r.ok||r.status<500)forget(id);fin(true,r)},async err=>{
      if(done)return;
      if(!navigator.onLine){forget(id);return fin(false,err)} // sem internet: o app guarda a mensagem na fila offline, como antes
      try{fin(true,await recover(id,err))}catch(e){fin(false,e)}
    });
  });
};

/* ---------- Tarefas em segundo plano ----------
   Cada envio é uma tarefa no servidor (aguardando → processando → concluída/falhou) que continua mesmo se o usuário sair.
   • Saiu da tela (app em segundo plano, fechou, foi para outra página ou outra conversa): avisa o servidor, que manda uma
     notificação quando terminar; voltou antes do fim: cancela o aviso.
   • Na conversa, tarefas que não estão sendo acompanhadas por esta aba (começadas antes de sair, em outro aparelho, ou uma
     nova tentativa) aparecem com o estado real; ao concluir, a conversa é recarregada com o resultado salvo.
   • Falhou: mostra o motivo, "Tentar de novo" (o pedido ficou guardado no servidor) e "Descartar". */
const INF=window.__maChatInf||(window.__maChatInf=new Map());
// tarefas que a conversa aberta está mostrando (começadas antes de recarregar, em outra aba ou nova tentativa)
const VIG=new Map();
const marcar=(id,ativo)=>nativeFetch('/api/v2/chat/jobs/'+id+'/segundo-plano',{method:'POST',keepalive:true,credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({ativo})}).catch(()=>{});
const convAberta=()=>location.pathname==='/'?(new URLSearchParams(location.search).get('c')||''):null;
function avaliarSaida(){const ca=convAberta();for(const [id,j] of [...INF,...VIG]){const fora=document.hidden||ca===null||(!!ca&&!!j.conv&&ca!==j.conv);if(fora&&!j.fora){j.fora=true;marcar(id,true)}else if(!fora&&j.fora){j.fora=false;marcar(id,false)}}}
document.addEventListener('visibilitychange',avaliarSaida);addEventListener('pagehide',()=>{for(const [id,j] of [...INF,...VIG])if(!j.fora){j.fora=true;marcar(id,true)}});setInterval(avaliarSaida,1000);
const escH=t=>String(t==null?'':t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function permAviso(){try{if(!('Notification' in window))return'';if(Notification.permission==='granted')return'';return Notification.permission==='denied'?'<span class="ma-tf-sub">As notificações estão bloqueadas neste navegador: a resposta fica salva aqui na conversa.</span>':'<a href="/ativar-notificacoes" class="ma-tf-lk">Ative as notificações para receber o aviso</a>'}catch(e){return''}}
function procHtml(t){return `<span class="ma-tf-row"><span class="ma-tf-spin" aria-hidden="true"></span><span><b>${escH(t)}</b><span class="ma-tf-sub">Pode sair do chat: a resposta fica salva nesta conversa e você recebe um aviso quando terminar.</span>${permAviso()}</span></span>`}
(function(){if(document.getElementById('ma-tf-style'))return;const st=document.createElement('style');st.id='ma-tf-style';st.textContent=`.ma-tf{display:flex;justify-content:flex-start;padding:4px 16px 8px}#ma-tarefas.ma-tf-flut{position:fixed;left:0;right:0;z-index:30;max-width:760px;margin:0 auto}#ma-tarefas.ma-tf-flut .ma-tf>div{max-width:100%;background:var(--nx-surface-2,#15171c);box-shadow:0 8px 30px rgba(0,0,0,.35)}.ma-tf>div{max-width:85%;border-radius:1.4rem;padding:12px 16px;font-size:14.5px;line-height:1.45;color:var(--nx-ink)}
.ma-tf-row{display:flex;gap:10px;align-items:flex-start}.ma-tf-row b{font-weight:600}.ma-tf-sub{display:block;margin-top:3px;font-size:12.5px;color:var(--nx-ink-3,#999)}.ma-tf-lk{display:inline-block;margin-top:6px;font-size:12.5px;font-weight:600;color:var(--nx-accent,#5b8dff);text-decoration:underline;text-underline-offset:2px}
.ma-tf-spin{flex:none;width:16px;height:16px;margin-top:3px;border-radius:50%;border:2px solid var(--nx-accent,#5b8dff);border-right-color:transparent;animation:ma-tf-r .8s linear infinite}@keyframes ma-tf-r{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){.ma-tf-spin{animation:none}}
.ma-tf-fila{flex:none;width:9px;height:9px;margin-top:6px;border-radius:50%;background:var(--nx-ink-3,#888)}.ma-tf-err{flex:none;width:9px;height:9px;margin-top:6px;border-radius:50%;background:var(--nx-danger,#e5484d)}
.ma-tf-acts{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}.ma-tf-acts button{height:34px;padding:0 14px;border-radius:999px;font-size:13px;font-weight:600;border:1px solid var(--nx-line-strong,rgba(255,255,255,.18));background:transparent;color:var(--nx-ink)}.ma-tf-acts button.pri{background:var(--nx-accent,#2f6bff);border-color:transparent;color:#fff}`;document.head.appendChild(st)})();
let TFvistas=new Map(),TFt=null,TFconv=null;
function tfHost(){return listaMsgs()}
const tfVazia=()=>!document.querySelector('.chat-scroll .msg-swipe,.chat-scroll [data-mid]');
function tfCard(t){const tx=t.texto?`“${escH(t.texto.length>90?t.texto.slice(0,89)+'…':t.texto)}”`:'Seu pedido';const min=t.iniciadaEm?Math.max(0,Math.round((Date.now()-Date.parse(t.iniciadaEm))/60000)):0;
 if(t.estado==='aguardando')return `<span class="ma-tf-row"><span class="ma-tf-fila" aria-hidden="true"></span><span><b>Na fila</b> · ${tx}<span class="ma-tf-sub">Começa assim que terminar o pedido anterior. Pode sair: você recebe um aviso.</span></span></span>`;
 if(t.estado==='processando')return procHtml('Processando '+(t.texto?'“'+(t.texto.length>60?t.texto.slice(0,59)+'…':t.texto)+'”':'seu pedido')+(min>=1?` · há ${min} min`:''));
 return `<span class="ma-tf-row"><span class="ma-tf-err" aria-hidden="true"></span><span><b>Não consegui concluir</b> ${tx}<span class="ma-tf-sub">${escH(t.erro||'Ocorreu um erro ao processar.')}</span>${t.reenviarArquivo?'<span class="ma-tf-sub">Este pedido tinha um arquivo: envie de novo pelo chat.</span>':''}<span class="ma-tf-acts">${t.podeTentarDeNovo?'<button type="button" class="pri" data-tf-tentar>Tentar de novo</button>':''}<button type="button" data-tf-descartar>Descartar</button></span></span></span>`}
function tfPronto(){const ta=document.querySelector('textarea[data-composer-input]');if(!document.hidden&&!(ta&&ta.value.trim()))location.reload();else notice()}
async function tarefasSync(){clearTimeout(TFt);const c=convAberta();const box=document.getElementById('ma-tarefas');
 if(!c){if(box)box.remove();TFvistas=new Map();TFconv=null;return}
 if(TFconv!==c){TFconv=c;TFvistas=new Map()}
 let l=null;try{const r=await nativeFetch('/api/v2/chat/tarefas?c='+encodeURIComponent(c),{credentials:'same-origin',cache:'no-store'});if(r.ok)l=(await r.json()).tarefas||[]}catch(e){}
 if(!l){TFt=setTimeout(tarefasSync,5000);return}
 if(convAberta()!==c)return tarefasSync();
 // tarefa que estava na tela e terminou: mostra o resultado salvo
  for(const t of l)if(t.estado!=='aguardando'&&t.estado!=='processando')VIG.delete(t.id); // terminou com a pessoa olhando: sair agora não gera aviso
for(const t of l)if(t.estado==='concluida'&&['aguardando','processando'].includes(TFvistas.get(t.id))){TFvistas.set(t.id,'concluida');return tfPronto()}
 const vis=l.filter(t=>!INF.has(t.id)&&['aguardando','processando','falhou'].includes(t.estado));
 vis.forEach(t=>TFvistas.set(t.id,t.estado));
 // está vendo a tarefa na tela: não precisa de aviso; ao sair, avaliarSaida volta a pedir o aviso
 const ativas=new Set(vis.filter(t=>t.estado!=='falhou').map(t=>t.id));for(const id of [...VIG.keys()])if(VIG.get(id).conv===c&&!ativas.has(id))VIG.delete(id);
 for(const t of vis)if(ativas.has(t.id)){if(!VIG.has(t.id))VIG.set(t.id,{conv:c,fora:!!document.hidden});const fora=VIG.get(t.id).fora;if(t.segundoPlano!==fora)marcar(t.id,fora)}
 let el=document.getElementById('ma-tarefas');
 if(!vis.length){if(el)el.remove()}else{const host=tfHost();if(host){if(!el||!el.isConnected){el=document.createElement('div');el.id='ma-tarefas';el.setAttribute('aria-live','polite');host.appendChild(el)}else if(el.parentElement!==host||el.nextElementSibling)host.appendChild(el)
  el.classList.toggle('ma-tf-flut',tfVazia());if(el.classList.contains('ma-tf-flut')){const ci=document.querySelector('textarea.composer-input');const top=ci?(ci.closest('form')||ci.parentElement).getBoundingClientRect().top:innerHeight-120;el.style.bottom=Math.max(80,innerHeight-top+10)+'px'}else el.style.bottom=''
  const sig=vis.map(t=>t.id+t.estado+(t.erro||'')+(t.iniciadaEm?Math.round((Date.now()-Date.parse(t.iniciadaEm))/60000):'')).join('|');if(el.dataset.sig!==sig){el.dataset.sig=sig;el.innerHTML=vis.map(t=>`<div class="ma-tf" data-tarefa="${escH(t.id)}" data-estado="${t.estado}"><div class="glass">${tfCard(t)}</div></div>`).join('')
   el.querySelectorAll('[data-tf-tentar]').forEach(b=>b.onclick=async()=>{const id=b.closest('[data-tarefa]').dataset.tarefa;b.disabled=true;try{const r=await nativeFetch('/api/v2/chat/jobs/'+id+'/tentar',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'});if(!r.ok){const j=await r.json().catch(()=>({}));b.disabled=false;const s=b.closest('[data-tarefa]').querySelector('.ma-tf-sub');if(s)s.textContent=j.error||'Não foi possível tentar de novo agora.'}}catch(e){b.disabled=false}tarefasSync()});
   el.querySelectorAll('[data-tf-descartar]').forEach(b=>b.onclick=async()=>{const id=b.closest('[data-tarefa]').dataset.tarefa;b.disabled=true;await nativeFetch('/api/v2/chat/jobs/'+id+'/descartar',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{});TFvistas.delete(id);tarefasSync()})}}}
 TFt=setTimeout(tarefasSync,vis.some(t=>t.estado!=='falhou')||INF.size?2500:20000)}
let TFurl='';setInterval(()=>{if(location.href!==TFurl){TFurl=location.href;tarefasSync()}else if(document.getElementById('ma-tarefas')&&!document.getElementById('ma-tarefas').isConnected)tarefasSync()},1000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)tarefasSync()});
/* app reaberto depois de fechado: avisa se uma resposta ficou pronta enquanto estava fora */
async function checkOld(){
  const l=load();if(!l.length)return;
  for(const j of l){if(Date.now()-j.at<4000)continue;const st=await jobStatus(j.id);if(st.status==='pending')continue;forget(j.id);
    if(st.status==='done'&&st.result&&st.result.assistantMessage){const t=String(st.result.assistantMessage.content||'').replace(/⟦[^⟧]*⟧/g,'').trim().slice(0,40);if(t&&!document.body.innerText.includes(t.slice(0,25))){notice()}}}
}
function notice(){if(document.getElementById('ma-ready'))return;const b=document.createElement('button');b.id='ma-ready';b.type='button';b.textContent='Sua resposta ficou pronta · Ver';b.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:calc(96px + env(safe-area-inset-bottom,0px));z-index:200;border:0;border-radius:999px;padding:10px 18px;font:600 14px system-ui;color:#fff;background:#2f6bff;box-shadow:0 10px 30px -8px #000';b.onclick=()=>location.reload();document.body.appendChild(b);setTimeout(()=>b.remove(),15000)}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(checkOld,1200)});
addEventListener('online',()=>setTimeout(checkOld,1500));
if(document.readyState==='complete')setTimeout(checkOld,2500);else addEventListener('load',()=>setTimeout(checkOld,2500));
})();
