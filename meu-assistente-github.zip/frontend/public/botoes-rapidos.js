/* Meu Assistente · Botões rápidos do chat (visual compartilhado entre o chat e a prévia do painel).
   Lista vertical à esquerda, logo acima do campo de digitação: ícone de linha sem fundo (cinza discreto por padrão)
   e texto na cor do tema (branco no escuro). Cada botão pode ter cor própria de ícone e de texto (ex.: "Lojas" em azul).
   Configuração: painel administrativo → Botões do chat (no máximo 3). */
(function(){
if(window.MAQB)return;
const P=(d)=>d;
const ICONES={
 loja:['Loja',P('<path d="M4.5 10.2V18.5A2 2 0 0 0 6.5 20.5h11a2 2 0 0 0 2-2v-8.3"/><path d="M3.6 7.2 5 4.4a1.8 1.8 0 0 1 1.6-1h10.8a1.8 1.8 0 0 1 1.6 1l1.4 2.8a2.6 2.6 0 0 1-4.3 2.6 2.7 2.7 0 0 1-4.1 0 2.7 2.7 0 0 1-4.1 0 2.6 2.6 0 0 1-4.3-2.6Z"/>')],
 calendario:['Calendário',P('<rect x="3.5" y="5" width="17" height="15.5" rx="2.6"/><path d="M8 3v4M16 3v4M3.5 10h17"/><circle cx="9.6" cy="14" r="1" fill="currentColor" stroke="none"/><circle cx="14.4" cy="14" r="1" fill="currentColor" stroke="none"/><circle cx="9.6" cy="17.2" r="1" fill="currentColor" stroke="none"/><circle cx="14.4" cy="17.2" r="1" fill="currentColor" stroke="none"/>')],
 checklist:['Checklist',P('<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="m7 9 1.4 1.4L11 7.9M7 15.2l1.4 1.4 2.6-2.5M13.5 9.3h3.8M13.5 15.5h3.8"/>')],
 sino:['Sino',P('<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15Z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>')],
 carteira:['Carteira',P('<path d="M18.5 7V5.6A1.6 1.6 0 0 0 16.9 4H6A2.5 2.5 0 0 0 3.5 6.5v11A2.5 2.5 0 0 0 6 20h12.5a1.5 1.5 0 0 0 1.5-1.5V15.5"/><path d="M3.5 7h15.6A1.4 1.4 0 0 1 20.5 8.4V10h-4a2.75 2.75 0 0 0 0 5.5h4"/><circle cx="16.6" cy="12.75" r=".9" fill="currentColor" stroke="none"/>')],
 carrinho:['Carrinho',P('<circle cx="9.5" cy="19.5" r="1.3"/><circle cx="17" cy="19.5" r="1.3"/><path d="M3 4h2.3l2.2 10.6a1.6 1.6 0 0 0 1.6 1.3h8a1.6 1.6 0 0 0 1.6-1.2L20.5 8H6.3"/>')],
 busca:['Busca',P('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.3-4.3"/>')],
 grafico:['Gráfico',P('<path d="M4 4v14.5A1.5 1.5 0 0 0 5.5 20H20"/><path d="m7.5 15 3.5-4 3 2.6 5-6.1"/>')],
 moeda:['Moeda',P('<circle cx="12" cy="12" r="8.5"/><path d="M14.7 9.3c-.5-.9-1.5-1.4-2.7-1.4-1.5 0-2.7.8-2.7 2 0 2.8 5.6 1.4 5.6 4.2 0 1.3-1.2 2.1-2.9 2.1-1.3 0-2.3-.5-2.8-1.5M12 6.4v1.5M12 16.2v1.4"/>')],
 pedido:['Sacola',P('<path d="M5.2 8h13.6l-1 11.2a1.5 1.5 0 0 1-1.5 1.3H7.7a1.5 1.5 0 0 1-1.5-1.3Z"/><path d="M9 10.5V7a3 3 0 0 1 6 0v3.5"/>')],
 tarefa:['Tarefa',P('<circle cx="12" cy="12" r="8.5"/><path d="m8.5 12.2 2.4 2.3 4.6-4.8"/>')],
 recibo:['Recibo',P('<path d="M6 3.5h12V20.5l-2-1.3-2 1.3-2-1.3-2 1.3-2-1.3-2 1.3Z"/><path d="M9 8h6M9 11.5h6M9 15h3.5"/>')],
 chat:['Conversa',P('<path d="M20 15a2 2 0 0 1-2 2H8l-4 3.5V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2Z"/>')],
 estrela:['Estrela',P('<path d="m12 3.6 2.6 5.2 5.8.9-4.2 4.1 1 5.7-5.2-2.7-5.2 2.7 1-5.7-4.2-4.1 5.8-.9Z"/>')],
 local:['Local',P('<path d="M12 20.8s-6.5-5.6-6.5-10.9a6.5 6.5 0 0 1 13 0c0 5.3-6.5 10.9-6.5 10.9Z"/><circle cx="12" cy="9.9" r="2.3"/>')],
 relogio:['Relógio',P('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>')],
 casa:['Casa',P('<path d="M4 10.4 12 4l8 6.4v8.1a2 2 0 0 1-2 2h-3V15h-6v5.5H6a2 2 0 0 1-2-2Z"/>')],
 presente:['Presente',P('<rect x="3.5" y="8" width="17" height="4" rx="1"/><path d="M5 12v7a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 19v-7M12 8v12.5M12 8c-1-2.7-2.6-4-4.1-3.6C6.4 4.8 6.6 8 12 8Zm0 0c1-2.7 2.6-4 4.1-3.6 1.5.4 1.3 3.6-4.1 3.6Z"/>')]
};
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cor=v=>/^#[0-9a-f]{6}$/i.test(String(v||''))?String(v):'';
function svg(k){const i=ICONES[k]||ICONES.chat;return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${i[1]}</svg>`}
/** Um botão. Cores vazias = padrão (ícone cinza discreto, texto na cor do tema). */
function item(b){const ci=cor(b.corIcone),ct=cor(b.corTexto),st=(ci?`--qb-ic:${ci};`:'')+(ct?`--qb-tx:${ct};`:'');
 return `<button type="button" class="ma-qb-item${ct&&ct.toUpperCase()!=='#FFFFFF'?' ma-qb-forte':''}" data-qb-id="${esc(b.id||'')}" data-qb-cmd="${esc(b.comando||'')}"${st?` style="${st}"`:''}>${svg(b.icone)}<span>${esc(b.texto)}</span></button>`}
function html(items){return (items||[]).slice(0,3).map(item).join('')}
const CSS='.ma-qb-list{display:flex!important;flex-direction:column!important;flex-wrap:nowrap!important;align-items:flex-start!important;justify-content:flex-start!important;gap:1px!important;margin:auto 0 0!important;padding:16px 0 0!important;text-align:left;background:transparent!important;box-shadow:none!important;max-height:none;overflow:visible}'
 +'div:has(>.ma-qb-list){padding-bottom:0!important;margin-bottom:-10px!important}'
 +'.ma-qb-item{flex-shrink:0;display:inline-flex;align-items:center;justify-content:flex-start;gap:14px;height:42px;min-width:44px;max-width:100%;margin:0;padding:0 12px 0 16px;background:transparent!important;border:0!important;border-radius:12px;box-shadow:none!important;color:var(--qb-tx,var(--nx-ink,#fff));font:inherit;font-size:17px;font-weight:500;letter-spacing:-.01em;line-height:1.2;text-align:left;white-space:nowrap;cursor:pointer;-webkit-backdrop-filter:none;backdrop-filter:none;-webkit-tap-highlight-color:transparent;transition:opacity .15s}'
 +'.ma-qb-item>span{overflow:hidden;text-overflow:ellipsis}.ma-qb-item.ma-qb-forte{font-weight:600}'
 +'.ma-qb-item>svg{flex:none;width:24px;height:24px;color:var(--qb-ic,#8E8E93)}'
 +'@media(min-width:640px){.ma-qb-item{font-size:16px;height:40px;padding-left:4px}.ma-qb-item>svg{width:22px;height:22px}}'
 +'@media(hover:hover){.ma-qb-item:hover{opacity:.78}}.ma-qb-item:active{opacity:.55}'
 +'.ma-qb-item:focus-visible{outline:2px solid color-mix(in srgb,var(--nx-accent,#1677ff) 70%,transparent);outline-offset:2px}'
 +'@media(prefers-reduced-motion:reduce){.ma-qb-item{transition:none}}'
 /* tela inicial: os botões ficam numa área própria, ancorada embaixo (fora do fluxo), e não deslocam a logo */
 +'.ma-wel{position:relative}.ma-wel>.ma-qb-list{position:absolute!important;left:0;right:0;bottom:0;margin:0!important}.ma-wel-hero{position:relative}';
function estilo(){if(document.getElementById('ma-qb2-style'))return;const st=document.createElement('style');st.id='ma-qb2-style';st.textContent=CSS;(document.head||document.documentElement).appendChild(st)}
estilo();
window.MAQB={ICONES,svg,html,item,estilo,AZUL:'#1677FF'};
})();
