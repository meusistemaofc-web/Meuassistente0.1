/* Atalho para a página "Minha memória" dentro de Perfil → Memória do assistente (não altera nada da seção existente). */
(function(){
if(window.__maMem)return;window.__maMem=true;
function por(){
  const sec=document.querySelector('section#memoria');if(!sec||sec.querySelector('.ma-mem-link'))return;
  const a=document.createElement('a');a.href='/minha-memoria';a.className='ma-mem-link';
  a.setAttribute('aria-label','Abrir minha memória completa');
  a.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:10px;padding:14px 18px;border-radius:1.2rem;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);color:var(--nx-ink,#eee);text-decoration:none;font-size:14px;transition:transform .12s';
  a.innerHTML='<span><b style="display:block;font-weight:600">Abrir minha memória completa</b><span style="font-size:12px;color:var(--nx-ink-3,#999)">Camadas, busca por assunto, versões, experiências, exportar e retenção</span></span><span aria-hidden="true">→</span>';
  sec.appendChild(a);
}
let t=null;new MutationObserver(()=>{clearTimeout(t);t=setTimeout(por,200)}).observe(document.documentElement,{childList:true,subtree:true});por();
})();
