/* Meu Assistente · desenho das MCoins (SVG responsivo). Usado no painel, no Mercado, na carteira e no checkout.
   MaCoin.svg(modelo, {c1,c2,sym,logo,size}) → string SVG. O modelo vem do servidor (biblioteca de modelos). */
(function(){if(window.MaCoin)return;let uid=0;
/* ---------- animações (só transform/opacity; desligam com "reduzir movimento") ---------- */
const reduced=()=>{try{return window.matchMedia('(prefers-reduced-motion: reduce)').matches||document.documentElement.classList.contains('ma-reduce-motion')}catch(e){return false}};
(function(){if(document.getElementById('mc-anim'))return;const st=document.createElement('style');st.id='mc-anim';st.textContent=`
.mc3d{display:block;perspective:520px;line-height:0}
.mc3d-i{display:block;transform-style:preserve-3d;will-change:transform;animation:mc-tilt 7s ease-in-out infinite}
.mc3d svg .mc-sweep{transform-box:fill-box;animation:mc-sweep 5.2s ease-in-out infinite}
.mc3d svg .mc-light{animation:mc-light 4.4s ease-in-out infinite}
@keyframes mc-tilt{0%,100%{transform:rotateY(-18deg) rotateX(5deg)}50%{transform:rotateY(18deg) rotateX(-4deg)}}
@keyframes mc-sweep{0%,55%{transform:translateX(-90px) skewX(-22deg);opacity:0}62%{opacity:.5}100%{transform:translateX(200px) skewX(-22deg);opacity:0}}
@keyframes mc-light{0%,100%{opacity:.35}50%{opacity:.85}}
.mc-gain{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 18px);transform:translateX(-50%);z-index:300;width:min(92vw,360px);border-radius:22px;padding:14px 16px;display:flex;align-items:center;gap:14px;background:var(--nx-surface,#17181d);border:1px solid color-mix(in srgb,var(--mc-c,#f7d56a) 55%,transparent);box-shadow:0 18px 50px #0009,0 0 38px color-mix(in srgb,var(--mc-c,#f7d56a) 40%,transparent);animation:mc-in .5s cubic-bezier(.2,1.2,.3,1) both;color:var(--nx-ink,#fff)}
.mc-gain.out{animation:mc-out .35s ease both}
.mc-gain b{display:block;font-size:22px;line-height:1.1;letter-spacing:-.01em}
.mc-gain small{display:block;margin-top:3px;font-size:12.5px;opacity:.78;line-height:1.3}
.mc-ring{position:absolute;left:14px;top:50%;width:46px;height:46px;margin-top:-23px;border-radius:50%;border:2px solid var(--mc-c,#f7d56a);pointer-events:none;animation:mc-ring 1.1s ease-out both}
.mc-p{position:fixed;z-index:301;pointer-events:none;border-radius:50%;will-change:transform,opacity}
@keyframes mc-in{from{opacity:0;transform:translateX(-50%) translateY(-22px) scale(.92)}to{opacity:1;transform:translateX(-50%) translateY(0) scale(1)}}
@keyframes mc-out{to{opacity:0;transform:translateX(-50%) translateY(-14px) scale(.96)}}
@keyframes mc-ring{from{opacity:.9;transform:scale(.7)}to{opacity:0;transform:scale(2.3)}}
@media (prefers-reduced-motion: reduce){.mc3d-i,.mc3d svg .mc-sweep,.mc3d svg .mc-light,.mc-ring{animation:none!important}.mc-gain{animation:none!important}.mc-gain.out{opacity:0}}
html.ma-reduce-motion .mc3d-i,html.ma-reduce-motion .mc3d svg .mc-sweep,html.ma-reduce-motion .mc3d svg .mc-light,html.ma-reduce-motion .mc-ring,html.ma-reduce-motion .mc-gain{animation:none!important}
.mc-static .mc3d-i,.mc-static .mc-sweep,.mc-static .mc-light{animation:none!important}
`;document.head.appendChild(st)})();
/* saldo com transição numérica (instantâneo quando o movimento está reduzido) */
function countTo(el,from,to,ms){if(!el)return;from=Number(from)||0;to=Number(to)||0;ms=ms||900;if(reduced()||from===to||!window.requestAnimationFrame){el.textContent=String(to);return}const t0=performance.now(),d=to-from;el.setAttribute('data-counting','1');const step=t=>{const k=Math.min(1,(t-t0)/ms),e=1-Math.pow(1-k,3);el.textContent=String(Math.round(from+d*e));if(k<1)requestAnimationFrame(step);else{el.textContent=String(to);el.removeAttribute('data-counting')}};requestAnimationFrame(step)}
const lum=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(h||'');if(!m)return .5;const n=parseInt(m[1],16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;return (0.299*r+0.587*g+0.114*b)/255};
const poly=(n,r,rot)=>Array.from({length:n},(_,i)=>{const a=(Math.PI*2*i)/n+rot;return (50+r*Math.cos(a)).toFixed(2)+','+(50+r*Math.sin(a)).toFixed(2)}).join(' ');
const shape=(f,r,at)=>{
 if(f==='hexagono')return `<polygon points="${poly(6,r*1.04,-Math.PI/2)}" ${at}/>`;
 if(f==='octogono')return `<polygon points="${poly(8,r*1.04,Math.PI/8)}" ${at}/>`;
 if(f==='escudo'){const k=r/48,x=v=>(50+(v-50)*k).toFixed(2),y=v=>(50+(v-50)*k).toFixed(2);return `<path d="M${x(50)} ${y(2)} L${x(88)} ${y(14)} V${y(52)} C${x(88)} ${y(74)} ${x(70)} ${y(90)} ${x(50)} ${y(98)} C${x(30)} ${y(90)} ${x(12)} ${y(74)} ${x(12)} ${y(52)} V${y(14)} Z" ${at}/>`}
 return `<circle cx="50" cy="50" r="${r}" ${at}/>`};
function svg(m,o){o=o||{};const raw=svgRaw(m,o);return o.static?raw:`<span class="mc3d"><span class="mc3d-i">${raw}</span></span>`}
function svgRaw(m,o){o=o||{};m=m||{};const id='mc'+(++uid),c1=o.c1||m.c1||'#f7d56a',c2=o.c2||m.c2||'#b8860b',bd=m.borda||'#fff',f=m.forma||'redonda',ac=m.acabamento||'brilho',size=o.size||96;
 const custom=!!(o.c1||o.c2);let tx=m.texto||'#fff';if(custom&&ac!=='minimal'&&ac!=='fosco')tx=lum(c1)*.6+lum(c2)*.4>.55?'#1b1b1b':'#ffffff';
 const sym=String(o.sym||'').slice(0,6),fs=sym.length<=2?30:sym.length===3?24:sym.length===4?19:15,big=m.id==='simbolo';
 const content=o.logo&&(m.usaLogo||o.useLogo!==false&&m.usaLogo!==false&&o.logo)?`<clipPath id="${id}c"><circle cx="50" cy="50" r="24"/></clipPath><circle cx="50" cy="50" r="25.5" fill="#fff" opacity=".92"/><image href="${o.logo}" x="26" y="26" width="48" height="48" preserveAspectRatio="xMidYMid slice" clip-path="url(#${id}c)"/>`
  :`<text x="50" y="${big?60:58}" text-anchor="middle" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-weight="800" font-size="${big?fs*1.25:fs}" fill="${tx}" ${ac==='metalico'?`stroke="${bd}" stroke-opacity=".35" stroke-width=".6"`:''}>${sym.replace(/[<&>]/g,'')}</text>`;
 const inner=ac==='minimal'?`<rect/>`:'';
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="${size}" height="${size}" role="img" aria-label="Moeda ${sym}" style="display:block;max-width:100%;height:auto"><defs>
 <linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset=".55" stop-color="${ac==='fosco'?c1:c2}"/><stop offset="1" stop-color="${c2}"/></linearGradient>
 <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity=".18"/></linearGradient>
 <filter id="${id}n" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
 <filter id="${id}d" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity=".35"/></filter></defs>
 <g filter="url(#${id}d)">${ac==='minimal'?shape(f,46,`fill="${c1}" stroke="${bd}" stroke-width="3"`)+shape(f,38,`fill="none" stroke="${bd}" stroke-width="1" opacity=".5"`)
 :shape(f,48,`fill="${bd}"`)+shape(f,43,`fill="url(#${id}g)"`)+shape(f,36,`fill="none" stroke="${bd}" stroke-width="${ac==='neon'?1.6:1.2}" opacity=".6" ${ac==='neon'?`filter="url(#${id}n)"`:''}`)}
 ${ac==='metalico'||ac==='brilho'?shape(f,43,`fill="url(#${id}s)"`):''}${ac==='neon'?shape(f,43,`fill="none" stroke="${c1}" stroke-width="1" opacity=".8" filter="url(#${id}n)"`):''}
 ${ac==='metalico'?`<path d="M20 70 Q50 50 80 28" stroke="#fff" stroke-opacity=".28" stroke-width="4" fill="none" stroke-linecap="round"/>`:''}
 ${content}</g>${o.static?'':`<clipPath id="${id}k">${shape(f,43,'')}</clipPath><g clip-path="url(#${id}k)" pointer-events="none"><rect class="mc-light" x="0" y="0" width="100" height="100" fill="url(#${id}s)" opacity=".4"/><rect class="mc-sweep" x="0" y="-10" width="22" height="120" fill="#fff" opacity="0"/></g>`}</svg>`}
/* cartão do Mercado e da carteira (mesmo desenho usado na prévia do painel) */
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
function marketRow(c,m){return `<div class="flex w-full items-center gap-3"><div style="width:42px;flex:none">${svg(m||c.modeloInfo,{c1:c.cor1,c2:c.cor2,sym:c.simbolo,logo:c.logo,size:42})}</div><div class="min-w-0 flex-1"><p class="text-[15px] font-semibold">${c.simbolo}</p><p class="truncate text-xs text-ink-3">${(c.nome||'').replace(/[<>&]/g,'')}${c.empresa?' · '+String(c.empresa).replace(/[<>&]/g,''):''}</p></div><div class="w-32 text-right"><p class="text-[15px] font-semibold tabular">${brl(c.valorReferencia)}</p>${(()=>{const v=Number(c.variacao24h)||0;return `<p class="text-xs font-semibold tabular ${v>=0?'text-success':'text-danger'}" data-var24h title="Variação do valor de referência em 24 h">${(v>=0?'+':'')+v.toFixed(2).replace('.',',')}%</p>`})()}</div></div>`}
function walletCard(c,m){return `<div class="flex items-center gap-4 rounded-2xl p-4" style="background:linear-gradient(135deg,${c.cor1}33,${c.cor2}55);border:1px solid ${c.cor1}66"><div style="width:64px;flex:none">${svg(m||c.modeloInfo,{c1:c.cor1,c2:c.cor2,sym:c.simbolo,logo:c.logo,size:64})}</div><div class="min-w-0 flex-1"><p class="text-[13px] opacity-80">${(c.empresa||'Sua empresa').replace(/[<>&]/g,'')}</p><p class="text-[1.6rem] font-bold leading-none tabular"><span data-mc-saldo="${c.id}">${c.saldo!=null?c.saldo:0}</span> <span class="text-[14px] font-semibold">${c.simbolo}</span></p><p class="mt-1 text-[12px] opacity-80">≈ ${brl((c.saldo||0)*(c.desconto||0))} em desconto</p></div></div>`}
/* gráfico de evolução: distribuição acumulada x utilização acumulada (não é cotação) */
function chart(serie,h){h=h||150;const W=320,pad=6;if(!serie||!serie.length)return '';const mx=Math.max(1,...serie.map(p=>p.acumDistribuido)),X=i=>pad+(W-2*pad)*i/Math.max(1,serie.length-1),Y=v=>h-pad-(h-2*pad)*v/mx;
 const line=k=>serie.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p[k]).toFixed(1)).join(' ');
 return `<svg viewBox="0 0 ${W} ${h}" width="100%" role="img" aria-label="Evolução da distribuição e da utilização" style="display:block"><path d="${line('acumDistribuido')} L${X(serie.length-1)} ${h-pad} L${X(0)} ${h-pad} Z" fill="var(--nx-accent,#3b6cff)" opacity=".14"/><path d="${line('acumDistribuido')}" fill="none" stroke="var(--nx-accent,#3b6cff)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/><path d="${line('acumResgatado')}" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4 3" stroke-linecap="round"/></svg>
 <div class="mt-1 flex flex-wrap gap-4 text-[11.5px] text-ink-3"><span><i style="display:inline-block;width:14px;height:3px;background:var(--nx-accent,#3b6cff);vertical-align:middle"></i> Distribuídas (acumulado)</span><span><i style="display:inline-block;width:14px;border-top:2px dashed #f59e0b;vertical-align:middle"></i> Usadas em descontos (acumulado)</span></div>`}
/* ---------- recebimento de MCoins: destaque, partículas e aviso (uma vez por crédito) ---------- */
function celebrate(g){if(!g||!document.body)return;const old=document.querySelector('.mc-gain');if(old)old.remove();
 const c1=g.cor1||'#f7d56a',c2=g.cor2||'#b8860b',el=document.createElement('div');el.className='mc-gain';el.setAttribute('role','status');el.setAttribute('aria-live','polite');el.style.setProperty('--mc-c',c1);
 const txt=(g.motivo?'Motivo: '+String(g.motivo).replace(/[<>&]/g,''):(g.empresa?String(g.empresa).replace(/[<>&]/g,''):'Crédito na sua carteira'));
 el.innerHTML=`<span class="mc-ring"></span><div style="width:46px;flex:none">${svg(g.modelo,{c1,c2,sym:g.simbolo,logo:g.logo,size:46})}</div><div class="min-w-0"><b>+${Number(g.quantidade)||0} ${String(g.simbolo||'MCoins').replace(/[<>&]/g,'')}</b><small>Você recebeu MCoins${g.total>1?' ('+g.total+' créditos)':''}. ${txt}</small></div>`;
 document.body.appendChild(el);const close=()=>{el.classList.add('out');setTimeout(()=>el.remove(),380)};el.onclick=close;setTimeout(close,5200);
 if(!reduced()&&el.animate){const r=el.getBoundingClientRect(),cx=r.left+36,cy=r.top+r.height/2,cols=[c1,c2,'#fff'];
  for(let i=0;i<18;i++){const p=document.createElement('i'),sz=4+Math.random()*5,a=Math.PI*2*i/18+Math.random()*.4,d=46+Math.random()*60;p.className='mc-p';p.style.cssText=`left:${cx}px;top:${cy}px;width:${sz}px;height:${sz}px;background:${cols[i%3]};box-shadow:0 0 6px ${c1}`;document.body.appendChild(p);
   p.animate([{transform:'translate(0,0) scale(1)',opacity:1},{transform:`translate(${Math.cos(a)*d}px,${Math.sin(a)*d-16}px) scale(.2)`,opacity:0}],{duration:700+Math.random()*500,easing:'cubic-bezier(.15,.8,.3,1)',fill:'forwards'}).onfinish=()=>p.remove()}}}
/* vigia da carteira: busca créditos novos (leve, só quando a aba está visível) e anima saldo + aviso */
let wOff=0,wBusy=false;
async function vigiar(){if(wBusy||document.hidden||Date.now()<wOff)return;if(/^\/(entrar|cadastro|recuperar|conheca|convite|c\/|a\/)/.test(location.pathname))return;wBusy=true;
 try{const r=await fetch('/api/v2/coins/novas',{credentials:'same-origin'});if(r.status===401||r.status===403){wOff=Date.now()+300000;return}if(!r.ok)return;const n=(await r.json()).novas||[];if(!n.length)return;
  const por={};n.forEach(x=>{const k=por[x.moedaId]||(por[x.moedaId]={...x,quantidade:0,total:0,motivo:x.motivo});k.quantidade+=x.quantidade;k.total++;k.saldoApos=x.saldoApos;if(x.motivo)k.motivo=x.motivo;if(k.total>1&&x.motivo!==k.motivo)k.motivo=''});
  const det=Object.values(por).map(g=>({moedaId:g.moedaId,de:g.saldoApos-g.quantidade,para:g.saldoApos}));
  Object.values(por).forEach((g,i)=>setTimeout(()=>celebrate(g),i*900));
  try{window.dispatchEvent(new CustomEvent('ma:coins',{detail:det}))}catch(e){}
  setTimeout(()=>det.forEach(d=>{document.querySelectorAll('[data-mc-saldo="'+d.moedaId+'"]').forEach(el=>countTo(el,d.de,d.para))}),750);
  await fetch('/api/v2/coins/novas/vistas',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:n.map(x=>x.id)})})}
 catch(e){}finally{wBusy=false}}
setTimeout(vigiar,2500);setInterval(vigiar,40000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)vigiar()});window.addEventListener('focus',vigiar);
window.MaCoin={svg,marketRow,walletCard,chart,celebrate,countTo,reduced,vigiar};
})();
