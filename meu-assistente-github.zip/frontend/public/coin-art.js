/* Meu Assistente · desenho das moedas de bônus (SVG responsivo). Usado no painel, no Mercado, na carteira e no checkout.
   MaCoin.svg(modelo, {c1,c2,sym,logo,size}) → string SVG. O modelo vem do servidor (biblioteca de modelos). */
(function(){if(window.MaCoin)return;let uid=0;
const lum=h=>{const m=/^#?([0-9a-f]{6})$/i.exec(h||'');if(!m)return .5;const n=parseInt(m[1],16),r=(n>>16)&255,g=(n>>8)&255,b=n&255;return (0.299*r+0.587*g+0.114*b)/255};
const poly=(n,r,rot)=>Array.from({length:n},(_,i)=>{const a=(Math.PI*2*i)/n+rot;return (50+r*Math.cos(a)).toFixed(2)+','+(50+r*Math.sin(a)).toFixed(2)}).join(' ');
const shape=(f,r,at)=>{
 if(f==='hexagono')return `<polygon points="${poly(6,r*1.04,-Math.PI/2)}" ${at}/>`;
 if(f==='octogono')return `<polygon points="${poly(8,r*1.04,Math.PI/8)}" ${at}/>`;
 if(f==='escudo'){const k=r/48,x=v=>(50+(v-50)*k).toFixed(2),y=v=>(50+(v-50)*k).toFixed(2);return `<path d="M${x(50)} ${y(2)} L${x(88)} ${y(14)} V${y(52)} C${x(88)} ${y(74)} ${x(70)} ${y(90)} ${x(50)} ${y(98)} C${x(30)} ${y(90)} ${x(12)} ${y(74)} ${x(12)} ${y(52)} V${y(14)} Z" ${at}/>`}
 return `<circle cx="50" cy="50" r="${r}" ${at}/>`};
function svg(m,o){o=o||{};m=m||{};const id='mc'+(++uid),c1=o.c1||m.c1||'#f7d56a',c2=o.c2||m.c2||'#b8860b',bd=m.borda||'#fff',f=m.forma||'redonda',ac=m.acabamento||'brilho',size=o.size||96;
 const custom=!!(o.c1||o.c2);let tx=m.texto||'#fff';if(custom&&ac!=='minimal'&&ac!=='fosco')tx=lum(c1)*.6+lum(c2)*.4>.55?'#1b1b1b':'#ffffff';
 const sym=String(o.sym||'').slice(0,6),fs=sym.length<=2?30:sym.length===3?24:sym.length===4?19:15,big=m.id==='simbolo';
 const content=o.logo&&(m.usaLogo||o.useLogo!==false&&m.usaLogo!==false&&o.logo)?`<clipPath id="${id}c"><circle cx="50" cy="50" r="24"/></clipPath><circle cx="50" cy="50" r="25.5" fill="#fff" opacity=".92"/><image href="${o.logo}" x="26" y="26" width="48" height="48" preserveAspectRatio="xMidYMid slice" clip-path="url(#${id}c)"/>`
  :`<text x="50" y="${big?60:58}" text-anchor="middle" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-weight="800" font-size="${big?fs*1.25:fs}" fill="${tx}" ${ac==='metalico'?`stroke="${bd}" stroke-opacity=".35" stroke-width=".6"`:''}>${sym.replace(/[<&>]/g,'')}</text>`;
 const inner=ac==='minimal'?`<rect/>`:'';
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="${size}" height="${size}" role="img" aria-label="Moeda ${sym}" style="display:block;max-width:100%;height:auto"><defs>
 <linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset=".55" stop-color="${ac==='fosco'?c1:c2}"/><stop offset="1" stop-color="${c2}"/></linearGradient>
 <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity=".18"/></linearGradient>
 <filter id="${id}n" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
 <filter id="${id}d" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity=".35"/></filter></defs>
 <g filter="url(#${id}d)">${ac==='minimal'?shape(f,46,`fill="${c1}" stroke="${bd}" stroke-width="3"`)+shape(f,38,`fill="none" stroke="${bd}" stroke-width="1" opacity=".5"`)
 :shape(f,48,`fill="${bd}"`)+shape(f,43,`fill="url(#${id}g)"`)+shape(f,36,`fill="none" stroke="${bd}" stroke-width="${ac==='neon'?1.6:1.2}" opacity=".6" ${ac==='neon'?`filter="url(#${id}n)"`:''}`)}
 ${ac==='metalico'||ac==='brilho'?shape(f,43,`fill="url(#${id}s)"`):''}${ac==='neon'?shape(f,43,`fill="none" stroke="${c1}" stroke-width="1" opacity=".8" filter="url(#${id}n)"`):''}
 ${ac==='metalico'?`<path d="M20 70 Q50 50 80 28" stroke="#fff" stroke-opacity=".28" stroke-width="4" fill="none" stroke-linecap="round"/>`:''}
 ${content}</g></svg>`}
/* cartão do Mercado e da carteira (mesmo desenho usado na prévia do painel) */
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
function marketRow(c,m){return `<div class="flex w-full items-center gap-3"><div style="width:42px;flex:none">${svg(m||c.modeloInfo,{c1:c.cor1,c2:c.cor2,sym:c.simbolo,logo:c.logo,size:42})}</div><div class="min-w-0 flex-1"><p class="text-[15px] font-semibold">${c.simbolo}</p><p class="truncate text-xs text-ink-3">${(c.nome||'').replace(/[<>&]/g,'')}${c.empresa?' · '+String(c.empresa).replace(/[<>&]/g,''):''}</p></div><div class="w-32 text-right"><p class="text-[15px] font-semibold tabular">${brl(c.valorReferencia)}</p><p class="text-xs text-ink-3 tabular">${c.distribuidas||0} distribuídas</p></div></div>`}
function walletCard(c,m){return `<div class="flex items-center gap-4 rounded-2xl p-4" style="background:linear-gradient(135deg,${c.cor1}33,${c.cor2}55);border:1px solid ${c.cor1}66"><div style="width:64px;flex:none">${svg(m||c.modeloInfo,{c1:c.cor1,c2:c.cor2,sym:c.simbolo,logo:c.logo,size:64})}</div><div class="min-w-0 flex-1"><p class="text-[13px] opacity-80">${(c.empresa||'Sua empresa').replace(/[<>&]/g,'')}</p><p class="text-[1.6rem] font-bold leading-none tabular">${c.saldo!=null?c.saldo:0} <span class="text-[14px] font-semibold">${c.simbolo}</span></p><p class="mt-1 text-[12px] opacity-80">≈ ${brl((c.saldo||0)*(c.desconto||0))} em desconto</p></div></div>`}
/* gráfico de evolução: distribuição acumulada x utilização acumulada (não é cotação) */
function chart(serie,h){h=h||150;const W=320,pad=6;if(!serie||!serie.length)return '';const mx=Math.max(1,...serie.map(p=>p.acumDistribuido)),X=i=>pad+(W-2*pad)*i/Math.max(1,serie.length-1),Y=v=>h-pad-(h-2*pad)*v/mx;
 const line=k=>serie.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p[k]).toFixed(1)).join(' ');
 return `<svg viewBox="0 0 ${W} ${h}" width="100%" role="img" aria-label="Evolução da distribuição e da utilização" style="display:block"><path d="${line('acumDistribuido')} L${X(serie.length-1)} ${h-pad} L${X(0)} ${h-pad} Z" fill="var(--nx-accent,#3b6cff)" opacity=".14"/><path d="${line('acumDistribuido')}" fill="none" stroke="var(--nx-accent,#3b6cff)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/><path d="${line('acumResgatado')}" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4 3" stroke-linecap="round"/></svg>
 <div class="mt-1 flex flex-wrap gap-4 text-[11.5px] text-ink-3"><span><i style="display:inline-block;width:14px;height:3px;background:var(--nx-accent,#3b6cff);vertical-align:middle"></i> Distribuídas (acumulado)</span><span><i style="display:inline-block;width:14px;border-top:2px dashed #f59e0b;vertical-align:middle"></i> Usadas em descontos (acumulado)</span></div>`}
window.MaCoin={svg,marketRow,walletCard,chart};
})();
