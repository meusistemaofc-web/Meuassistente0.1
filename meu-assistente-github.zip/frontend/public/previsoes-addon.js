/* Fase 7 — atalho "Previsões e sugestões" em Configurações (Perfil) e "pedir no chat" a partir de uma sugestão:
   /?m=texto preenche a caixa do chat (o usuário revisa e envia; nada é enviado sozinho). */
(function(){
if(window.__maPrev)return;window.__maPrev=true;
function atalho(){
  if(location.pathname!=='/perfil'||document.querySelector('section#previsoes'))return;
  const ref=document.querySelector('section#compromissos')||document.querySelector('section#memoria');if(!ref)return;
  const sec=document.createElement('section');sec.id='previsoes';sec.className=ref.className;sec.setAttribute('aria-label','Previsões e sugestões');
  const h=(document.querySelector('section#memoria h2,section#memoria h3'));
  sec.innerHTML=`<${h?h.tagName.toLowerCase():'h2'} class="${h?h.className:''}">Previsões e sugestões</${h?h.tagName.toLowerCase():'h2'}>
  <a href="/previsoes" class="ma-prev-link" style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:10px;padding:14px 18px;border-radius:1.2rem;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);color:var(--nx-ink,#eee);text-decoration:none;font-size:14px">
  <span><b style="display:block;font-weight:600">Abrir previsões e sugestões</b><span style="font-size:12px;color:var(--nx-ink-3,#999)">Conflitos, esquecimentos, contas, retornos de clientes e recorrências — e como e quando avisar</span></span><span aria-hidden="true">→</span></a>`;
  ref.after(sec);
  if(location.hash==='#previsoes')setTimeout(()=>sec.scrollIntoView({block:'start'}),300);
}
// Fase 8: atalho "Minhas execuções" logo depois de "Previsões e sugestões"
function atalhoExec(){
  if(location.pathname!=='/perfil'||document.querySelector('section#execucoes'))return;
  const ref=document.querySelector('section#previsoes');if(!ref)return;
  const sec=ref.cloneNode(true);sec.id='execucoes';sec.setAttribute('aria-label','Minhas execuções');
  const h=sec.querySelector('h2,h3');if(h)h.textContent='Minhas execuções';
  const a=sec.querySelector('a');a.className='ma-exec-link';a.href='/execucoes';a.querySelector('b').textContent='Abrir minhas execuções';a.querySelector('span span').textContent='O que o assistente executou ou preparou, com o andamento, aprovações, cancelamento e desfazer';
  ref.after(sec);if(location.hash==='#execucoes')setTimeout(()=>sec.scrollIntoView({block:'start'}),300);
}
function preencher(){
  if(location.pathname!=='/')return;const m=new URLSearchParams(location.search).get('m');if(!m)return;
  const ta=document.querySelector('textarea.composer-input');if(!ta)return;
  const set=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;set.call(ta,m.slice(0,500));ta.dispatchEvent(new Event('input',{bubbles:true}));ta.focus();
  history.replaceState(null,'',location.pathname);
}
let t=null;new MutationObserver(()=>{clearTimeout(t);t=setTimeout(()=>{atalho();atalhoExec();preencher()},200)}).observe(document.documentElement,{childList:true,subtree:true});atalho();atalhoExec();preencher();
})();
