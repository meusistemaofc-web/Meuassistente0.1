/* Compromissos → Calendário: "Evolução da agenda" (gráfico interativo acima do calendário).
   Dados REAIS de GET /api/v2/compromissos/estatisticas (só do usuário logado, no fuso dele). Recolhível; lembra
   período, indicador e se está aberto (preferência só deste aparelho). Atualiza sozinho quando o calendário avisa
   que algo mudou (criar, concluir, cancelar) — window.maEvo.atualizar(). */
(function(){
if(window.maEvo)return;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LS={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:v}catch(_){return d}},set(k,v){try{localStorage.setItem(k,v)}catch(_){}}};
const PER=[['hoje','Hoje'],['7d','7 dias'],['30d','30 dias'],['90d','90 dias'],['12m','12 meses'],['personalizado','Personalizado']];
const IND=[['total','Total'],['concluidos','Concluídos'],['pendentes','Pendentes'],['cancelados','Cancelados'],['novos','Novos agendamentos']];
const NOME={total:'compromissos',concluidos:'concluídos',pendentes:'pendentes',cancelados:'cancelados',novos:'novos agendamentos'};
const UM={total:'compromisso',concluidos:'concluído',pendentes:'pendente',cancelados:'cancelado',novos:'novo agendamento'};
const qtd=(n,k)=>`${n} ${n===1?UM[k]:NOME[k]}`;
const nf=new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2});
const pctTxt=v=>v==null?'—':nf.format(v)+'%';
const varTxt=v=>v==null?'—':(v>0?'+':'')+nf.format(v)+'%';
const seta=v=>v==null||v===0?'':v>0?'▲':'▼';
const dBr=d=>d?`${d.slice(8,10)}/${d.slice(5,7)}/${d.slice(0,4)}`:'';
const reduz=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches}catch(_){return false}};

function css(){if(document.getElementById('ma-evo-css'))return;const s=document.createElement('style');s.id='ma-evo-css';s.textContent=`
.ma-evo{margin-top:6px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 8%,transparent);border-radius:18px;background:color-mix(in srgb,var(--nx-ink,#fff) 2.5%,transparent)}
.ma-evo-cab{display:flex;align-items:center;gap:10px;width:100%;padding:11px 14px;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer;border-radius:18px}
.ma-evo-cab b{font-size:13.5px;font-weight:600}
.ma-evo-res{flex:1;min-width:0;font-size:12px;color:var(--nx-ink-3,#888);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-variant-numeric:tabular-nums}
.ma-evo-cab svg{flex:none;color:var(--nx-ink-3,#888);transition:transform .2s}
.ma-evo[data-aberto="1"] .ma-evo-cab svg{transform:rotate(180deg)}
.ma-evo-corpo{padding:0 14px 14px}
.ma-evo[data-aberto="0"] .ma-evo-corpo{display:none}
.ma-evo-chips{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;padding-bottom:2px;-webkit-overflow-scrolling:touch}
.ma-evo-chips::-webkit-scrollbar{display:none}
.ma-evo-chip{flex:none;height:28px;padding:0 11px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 12%,transparent);background:transparent;color:var(--nx-ink-2,#bbb);font-size:12px;font-weight:500;cursor:pointer;white-space:nowrap}
.ma-evo-chip[aria-pressed="true"]{background:var(--nx-ink,#f2f2f2);color:var(--nx-canvas,#0b0b0d);border-color:transparent;font-weight:600}
.ma-evo-pers{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin-top:8px;font-size:12px;color:var(--nx-ink-3,#888)}
.ma-evo-pers input{height:30px;padding:0 8px;border-radius:10px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);background:transparent;color:inherit;font:inherit;font-size:12.5px;color-scheme:light dark;min-width:0}
.ma-evo-pers button{height:30px;padding:0 12px;border-radius:999px;border:0;background:var(--nx-ink,#f2f2f2);color:var(--nx-canvas,#0b0b0d);font-size:12px;font-weight:600;cursor:pointer}
.ma-evo-cards{display:grid;grid-template-columns:repeat(6,1fr);gap:6px;margin-top:10px}
/* 1ª linha: total e crescimento (os dois números principais); 2ª: as três taxas */
.ma-evo-card{grid-column:span 2;order:2}.ma-evo-card[data-card=total],.ma-evo-card[data-card=crescimento]{grid-column:span 3;order:1}
.ma-evo-card{padding:9px 9px;border-radius:13px;background:color-mix(in srgb,var(--nx-ink,#fff) 4%,transparent);min-width:0}
.ma-evo-card small{display:block;font-size:10.5px;color:var(--nx-ink-3,#888);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ma-evo-card strong{display:block;margin-top:2px;font-size:17px;font-weight:650;font-variant-numeric:tabular-nums;letter-spacing:-.01em}
.ma-evo-card span{display:block;margin-top:1px;font-size:10.5px;color:var(--nx-ink-3,#888);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-variant-numeric:tabular-nums}
.ma-evo-up,.ma-evo-card .ma-evo-up{color:color-mix(in srgb,#3fb37f 85%,var(--nx-ink,#fff))}.ma-evo-dn,.ma-evo-card .ma-evo-dn{color:color-mix(in srgb,#e5675f 85%,var(--nx-ink,#fff))}
.ma-evo-inds{display:flex;gap:4px;margin-top:12px;overflow-x:auto;scrollbar-width:none}
.ma-evo-inds::-webkit-scrollbar{display:none}
.ma-evo-ind{flex:none;height:26px;padding:0 9px;border-radius:8px;border:0;background:transparent;color:var(--nx-ink-3,#888);font-size:11.5px;font-weight:500;cursor:pointer;white-space:nowrap}
.ma-evo-ind[aria-pressed="true"]{background:color-mix(in srgb,var(--nx-ink,#fff) 9%,transparent);color:var(--nx-ink,#f2f2f2);font-weight:600}
.ma-evo-graf{position:relative;margin-top:6px;height:156px;touch-action:pan-y}
.ma-evo-graf svg{display:block;width:100%;height:100%;overflow:visible}
.ma-evo-graf .ln{fill:none;stroke:var(--nx-accent,#7aa2ff);stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.ma-evo-graf .ar{fill:url(#ma-evo-g);stroke:none}
.ma-evo-graf .an{fill:none;stroke:var(--nx-ink-3,#888);stroke-width:1.5;stroke-dasharray:3 4;opacity:.7}
.ma-evo-graf .gr{stroke:color-mix(in srgb,var(--nx-ink,#fff) 8%,transparent);stroke-width:1}
.ma-evo-graf .tx{fill:var(--nx-ink-3,#888);font-size:10px;font-variant-numeric:tabular-nums}
.ma-evo-graf .pt{fill:var(--nx-canvas,#0b0b0d);stroke:var(--nx-accent,#7aa2ff);stroke-width:2}
.ma-evo-graf .cx{stroke:color-mix(in srgb,var(--nx-ink,#fff) 30%,transparent);stroke-width:1}
.ma-evo-graf .hit{fill:transparent;cursor:pointer;outline:none}
.ma-evo-graf .ln.anim{animation:ma-evo-d .5s ease-out}
@keyframes ma-evo-d{from{stroke-dashoffset:var(--len)}to{stroke-dashoffset:0}}
.ma-evo-tip{position:absolute;top:0;z-index:2;min-width:150px;max-width:220px;padding:8px 10px;border-radius:12px;background:var(--nx-canvas,#0b0b0d);border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:11.5px;line-height:1.45;pointer-events:none;font-variant-numeric:tabular-nums}
.ma-evo-tip b{display:block;font-size:12px}
.ma-evo-tip em{font-style:normal;color:var(--nx-ink-3,#888)}
.ma-evo-leg{display:flex;flex-wrap:wrap;gap:4px 12px;margin-top:6px;font-size:11px;color:var(--nx-ink-3,#888)}
.ma-evo-leg i{display:inline-block;width:14px;height:0;border-top:2px solid var(--nx-accent,#7aa2ff);vertical-align:middle;margin-right:5px}
.ma-evo-leg i.a{border-top:1.5px dashed var(--nx-ink-3,#888)}
.ma-evo-leg label{display:inline-flex;align-items:center;gap:4px;cursor:pointer}
.ma-evo-cmp{margin-top:8px;font-size:12px;color:var(--nx-ink-2,#bbb);font-variant-numeric:tabular-nums}
.ma-evo-vz{padding:26px 0 18px;text-align:center;font-size:12.5px;color:var(--nx-ink-3,#888)}
.ma-evo-err{margin-top:10px;font-size:12.5px;color:var(--nx-ink-3,#888)}
.ma-evo-carr{opacity:.55;transition:opacity .2s}
@media (hover:hover){.ma-evo-cab:hover{background:color-mix(in srgb,var(--nx-ink,#fff) 3%,transparent)}.ma-evo-ind:hover,.ma-evo-chip:not([aria-pressed="true"]):hover{color:var(--nx-ink,#f2f2f2)}}
@media (prefers-reduced-motion:reduce){.ma-evo-graf .ln.anim{animation:none}.ma-evo-cab svg{transition:none}}
`;document.head.appendChild(s)}

let el=null,st=null;
function estado(){return{periodo:LS.get('ma-evo-p','30d'),ind:LS.get('ma-evo-i','total'),aberto:LS.get('ma-evo-aberto','1')!=='0',ant:LS.get('ma-evo-ant','1')!=='0',de:LS.get('ma-evo-de',''),ate:LS.get('ma-evo-ate',''),dados:null,erro:'',seq:0,carregando:false,anim:true,sel:-1}}
if(!PER.some(p=>p[0]===LS.get('ma-evo-p','30d')))LS.set('ma-evo-p','30d');

async function carregar(){
  if(!el)return;
  if(st.periodo==='personalizado'&&!(st.de&&st.ate)){st.dados=null;st.erro='';desenhar();return}
  const seq=++st.seq;st.carregando=true;desenhar(true);
  const qs=new URLSearchParams({periodo:st.periodo});if(st.periodo==='personalizado'){qs.set('de',st.de);qs.set('ate',st.ate)}
  try{const r=await fetch('/api/v2/compromissos/estatisticas?'+qs,{credentials:'include'});const j=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(j.error||'Não foi possível carregar a evolução da agenda.');if(seq!==st.seq)return;st.dados=j;st.erro='';st.sel=-1}
  catch(e){if(seq===st.seq)st.erro=e.message}
  finally{if(seq===st.seq){st.carregando=false;desenhar()}}
}

function resumo(){const d=st.dados;if(!d)return st.carregando?'Carregando…':'';const c=d.comparacao.total,v=c.variacao;
  return `${d.atual.total} compromisso${d.atual.total===1?'':'s'}${v!=null?` · ${seta(v)} ${varTxt(v)}`:''}`}
const TIT={total:'Total de compromissos',conclusao:'Taxa de conclusão',cancelamento:'Taxa de cancelamento',comparecimento:'Taxa de comparecimento (quando houver registro)',crescimento:'Crescimento ou redução em relação ao período anterior'};
function card(rot,val,sub,cls,key){return `<div class="ma-evo-card" data-card="${key}" title="${TIT[key]}"><small>${rot}</small><strong>${val}</strong><span${cls?` class="${cls}"`:''}>${sub}</span></div>`}
function cards(){const d=st.dados,a=d.atual,p=d.anterior,c=d.comparacao.total;
  const dif=c.variacao,cl=dif==null||dif===0?'':dif>0?'ma-evo-up':'ma-evo-dn';
  const cresc=c.anterior===0?(c.atual===0?'sem atividade':'sem base anterior'):`${c.atual} vs ${c.anterior}`;
  return card('Total',String(a.total),`anterior: ${p.total}`,'','total')
   +card('Conclusão',pctTxt(a.taxaConclusao),`${a.concluidos} concluído${a.concluidos===1?'':'s'}`,'','conclusao')
   +card('Cancelamento',pctTxt(a.taxaCancelamento),`${a.cancelados} cancelado${a.cancelados===1?'':'s'}`,'','cancelamento')
   +card('Comparecimento',pctTxt(a.taxaComparecimento),a.taxaComparecimento==null?'sem registro':`${a.naoCompareceu} não compareceu`,'','comparecimento')
   +card('vs período anterior',dif==null?'—':`<span class="${cl}" style="display:inline;font-size:inherit;margin:0">${seta(dif)} ${varTxt(dif)}</span>`,cresc,'','crescimento')}

// curva suave sem "passar" abaixo de zero (cúbica monotônica)
function caminho(P){if(!P.length)return'';if(P.length===1)return`M${P[0][0]},${P[0][1]}`;const n=P.length,dx=[],m=[],t=[];
  for(let i=0;i<n-1;i++){dx[i]=P[i+1][0]-P[i][0];m[i]=(P[i+1][1]-P[i][1])/(dx[i]||1)}
  t[0]=m[0];t[n-1]=m[n-2];for(let i=1;i<n-1;i++)t[i]=m[i-1]*m[i]<=0?0:(m[i-1]+m[i])/2;
  for(let i=0;i<n-1;i++){if(m[i]===0){t[i]=0;t[i+1]=0;continue}const a=t[i]/m[i],b=t[i+1]/m[i],h=a*a+b*b;if(h>9){const s=3/Math.sqrt(h);t[i]=s*a*m[i];t[i+1]=s*b*m[i]}}
  let d=`M${P[0][0].toFixed(1)},${P[0][1].toFixed(1)}`;for(let i=0;i<n-1;i++){const h=dx[i]/3;d+=`C${(P[i][0]+h).toFixed(1)},${(P[i][1]+t[i]*h).toFixed(1)} ${(P[i+1][0]-h).toFixed(1)},${(P[i+1][1]-t[i+1]*h).toFixed(1)} ${P[i+1][0].toFixed(1)},${P[i+1][1].toFixed(1)}`}return d}

function grafico(){
  if(!el||!st||!st.dados)return;const box=el.querySelector('.ma-evo-graf');if(!box)return;const d=st.dados,pts=d.pontos,k=st.ind;
  const W=Math.max(220,box.clientWidth||320),H=156,L=4,R=4,T=10,B=22;
  const vals=pts.map(p=>p[k]||0),antv=pts.map(p=>p.anterior?(p.anterior[k]||0):null);
  const max=Math.max(1,...vals,...(st.ant?antv.filter(v=>v!=null):[0])),teto=max<=4?max:Math.ceil(max/4)*4;
  const n=pts.length,x=i=>n===1?W/2:L+(W-L-R)*i/(n-1),y=v=>T+(H-T-B)*(1-v/teto);
  const P=vals.map((v,i)=>[x(i),y(v)]),PA=antv.map((v,i)=>v==null?null:[x(i),y(v)]).filter(Boolean);
  const linha=caminho(P),area=linha+` L${P[P.length-1][0].toFixed(1)},${y(0)} L${P[0][0].toFixed(1)},${y(0)}Z`;
  const rot=[0,Math.floor((n-1)/2),n-1].filter((v,i,a)=>a.indexOf(v)===i);
  const larg=n>1?(W-L-R)/(n-1):W;
  box.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(`Gráfico de ${NOME[k]} por período`)}"><defs><linearGradient id="ma-evo-g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--nx-accent,#7aa2ff)" stop-opacity=".18"/><stop offset="1" stop-color="var(--nx-accent,#7aa2ff)" stop-opacity="0"/></linearGradient></defs>
   <line class="gr" x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}"/><line class="gr" x1="0" x2="${W}" y1="${y(teto)}" y2="${y(teto)}" stroke-dasharray="2 4"/>
   <text class="tx" x="2" y="${y(teto)-3}">${teto}</text>
   ${st.ant&&PA.length?`<path class="an" d="${caminho(PA)}"/>`:''}
   <path class="ar" d="${area}"/><path class="ln${st.anim&&!reduz()?' anim':''}" d="${linha}"/>
   ${n<=31?P.map((p,i)=>`<circle class="pt" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="${vals[i]?3:0}"/>`).join(''):''}
   <line class="cx" data-cx x1="0" x2="0" y1="${T}" y2="${y(0)}" style="display:none"/><circle class="pt" data-cp r="4.5" style="display:none"/>
   ${rot.map(i=>`<text class="tx" x="${x(i).toFixed(1)}" y="${H-6}" text-anchor="${n===1?'middle':i===0?'start':i===n-1?'end':'middle'}">${esc(pts[i].rotulo)}</text>`).join('')}
   ${pts.map((p,i)=>`<rect class="hit" data-i="${i}" x="${Math.max(0,x(i)-larg/2).toFixed(1)}" y="0" width="${Math.max(8,larg).toFixed(1)}" height="${H}"/>`).join('')}
  </svg><div class="ma-evo-tip" role="status" style="display:none"></div>`;
  const ln=box.querySelector('.ln.anim');if(ln){const len=Math.ceil(ln.getTotalLength?ln.getTotalLength():W*2);ln.style.setProperty('--len',len);ln.style.strokeDasharray=len}
  st.anim=false;
  const mostrar=i=>{st.sel=i;const p=pts[i],tip=box.querySelector('.ma-evo-tip'),cx=box.querySelector('[data-cx]'),cp=box.querySelector('[data-cp]');
    cx.setAttribute('x1',P[i][0]);cx.setAttribute('x2',P[i][0]);cx.style.display='';cp.setAttribute('cx',P[i][0]);cp.setAttribute('cy',P[i][1]);cp.style.display='';
    const per=p.de===p.ate||d.grao==='hora'?(d.grao==='hora'?`${dBr(p.de)} · ${p.rotulo}`:dBr(p.de)):`${dBr(p.de)} a ${dBr(p.ate)}`;
    const vp=i>0?p.variacao:null,an=p.anterior;
    tip.innerHTML=`<b>${esc(per)}</b>${qtd(p[k],k)}${k==='total'?'':` <em>de ${p.total}</em>`}<br><em>Concluídos ${p.concluidos} · Pendentes ${p.pendentes} · Cancelados ${p.cancelados}${p.naoCompareceu?` · Não compareceu ${p.naoCompareceu}`:''}</em><br><em>Novos agendamentos ${p.novos}</em>${vp!=null?`<br>${seta(vp)} ${varTxt(vp)} <em>vs intervalo anterior</em>`:''}${an?`<br><em>Período anterior (${esc(an.rotulo)}): ${an[k]||0}</em>`:''}`;
    tip.style.display='';const tw=tip.offsetWidth;tip.style.left=Math.min(Math.max(0,P[i][0]-tw/2),W-tw)+'px';tip.style.top=(P[i][1]>H/2?0:H-tip.offsetHeight-B)+'px'};
  const esconder=()=>{st.sel=-1;box.querySelectorAll('.ma-evo-tip,[data-cx],[data-cp]').forEach(e=>e.style.display='none')};
  box.querySelectorAll('.hit').forEach(r=>{const i=Number(r.dataset.i);r.addEventListener('mouseenter',()=>mostrar(i));r.addEventListener('click',e=>{e.stopPropagation();mostrar(i)})});
  box.querySelector('svg').addEventListener('mouseleave',()=>{if(matchMedia('(hover:hover)').matches)esconder()});
  box.tabIndex=0;box.onkeydown=e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();e.stopPropagation();mostrar(Math.min(n-1,Math.max(0,(st.sel<0?(e.key==='ArrowRight'?-1:n):st.sel)+(e.key==='ArrowRight'?1:-1))))}else if(e.key==='Escape'&&st.sel>=0){e.stopPropagation();esconder()}};
  if(st.sel>=0&&st.sel<n)mostrar(st.sel);
}

function desenhar(soCarregando){
  if(!el)return;const d=st.dados;
  el.dataset.aberto=st.aberto?'1':'0';el.querySelector('.ma-evo-cab').setAttribute('aria-expanded',String(st.aberto));
  el.querySelector('.ma-evo-res').textContent=resumo();
  const corpo=el.querySelector('.ma-evo-corpo');corpo.classList.toggle('ma-evo-carr',!!st.carregando&&!!d);
  if(soCarregando&&d)return;
  const pers=st.periodo==='personalizado';
  corpo.innerHTML=`<div class="ma-evo-chips" role="group" aria-label="Período">${PER.map(([v,t])=>`<button type="button" class="ma-evo-chip" data-per="${v}" aria-pressed="${st.periodo===v}">${t}</button>`).join('')}</div>
   ${pers?`<form class="ma-evo-pers" data-pers><label>De <input type="date" name="de" value="${esc(st.de)}" required></label><label>até <input type="date" name="ate" value="${esc(st.ate)}" required></label><button type="submit">Aplicar</button></form>`:''}
   ${st.erro?`<p class="ma-evo-err">${esc(st.erro)}</p>`:!d?`<p class="ma-evo-vz">${pers?'Escolha as datas do período.':'Carregando…'}</p>`:
   `<div class="ma-evo-cards">${cards()}</div>
    <div class="ma-evo-inds" role="group" aria-label="Indicador do gráfico">${IND.map(([v,t])=>`<button type="button" class="ma-evo-ind" data-ind="${v}" aria-pressed="${st.ind===v}">${t}</button>`).join('')}</div>
    ${d.atual.total===0&&d.atual.novos===0&&d.anterior.total===0&&d.anterior.novos===0?`<p class="ma-evo-vz" data-vazio>Nenhum compromisso neste período nem no anterior.</p>`:`<div class="ma-evo-graf"></div>
    <div class="ma-evo-leg"><span><i></i>${dBr(d.de)}${d.de!==d.ate?` a ${dBr(d.ate)}`:''}</span><label><input type="checkbox" data-ant ${st.ant?'checked':''}><i class="a"></i>Período anterior</label></div>`}
    <p class="ma-evo-cmp" data-cmp>${comparacao()}</p>`}`;
  corpo.querySelectorAll('[data-per]').forEach(b=>b.onclick=()=>{st.periodo=b.dataset.per;LS.set('ma-evo-p',st.periodo);st.dados=null;st.anim=true;carregar()});
  corpo.querySelectorAll('[data-ind]').forEach(b=>b.onclick=()=>{st.ind=b.dataset.ind;LS.set('ma-evo-i',st.ind);st.anim=true;st.sel=-1;desenhar()});
  const f=corpo.querySelector('[data-pers]');if(f)f.onsubmit=e=>{e.preventDefault();const de=f.de.value,ate=f.ate.value;if(!de||!ate)return;st.de=de;st.ate=ate;LS.set('ma-evo-de',de);LS.set('ma-evo-ate',ate);st.dados=null;st.anim=true;carregar()};
  const ca=corpo.querySelector('[data-ant]');if(ca)ca.onchange=()=>{st.ant=ca.checked;LS.set('ma-evo-ant',st.ant?'1':'0');grafico()};
  if(d&&st.aberto)grafico();
}
function comparacao(){const d=st.dados,k=st.ind==='total'?'total':st.ind,c=d.comparacao[k]||null;
  const a=c?c.atual:d.atual[k],b=c?c.anterior:d.anterior[k],v=c?c.variacao:(b>0?Math.round((a-b)/b*10000)/100:null);
  const ant=`${dBr(d.anterior.de)}${d.anterior.de!==d.anterior.ate?` a ${dBr(d.anterior.ate)}`:''}`;
  if(v==null)return `${qtd(a,k)} · período anterior (${ant}): ${b}${b===0?' — sem base de comparação':''}`;
  const cl=v>0?'ma-evo-up':v<0?'ma-evo-dn':'';
  return `${qtd(a,k)} vs ${b} no período anterior (${ant}) · <span class="${cl}">${seta(v)} ${varTxt(v)}</span>`}

function montar(slot){
  if(!slot)return;css();st=estado();
  el=document.createElement('section');el.className='ma-evo';el.setAttribute('aria-label','Evolução da agenda');
  el.innerHTML=`<button type="button" class="ma-evo-cab" aria-expanded="true" aria-controls="ma-evo-corpo"><b>Evolução da agenda</b><span class="ma-evo-res"></span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button><div class="ma-evo-corpo" id="ma-evo-corpo"></div>`;
  slot.replaceWith(el);
  // tocar fora do gráfico esconde o detalhe do ponto
  el.addEventListener('click',e=>{if(st&&st.sel>=0&&!e.target.closest('.ma-evo-graf')){st.sel=-1;el.querySelectorAll('.ma-evo-tip,[data-cx],[data-cp]').forEach(x=>x.style.display='none')}});
  el.querySelector('.ma-evo-cab').onclick=()=>{st.aberto=!st.aberto;LS.set('ma-evo-aberto',st.aberto?'1':'0');st.anim=st.aberto;desenhar()};
  let rt=0;el.__ro=new ResizeObserver(()=>{clearTimeout(rt);rt=setTimeout(()=>{if(st&&st.dados&&st.aberto)grafico()},120)});el.__ro.observe(el);
  desenhar();carregar();
}
function atualizar(){if(el&&el.isConnected)carregar();else desmontar()}
function desmontar(){if(el&&el.__ro)el.__ro.disconnect();el=null;if(st)st.seq++}
window.maEvo={montar,atualizar,desmontar};
})();
