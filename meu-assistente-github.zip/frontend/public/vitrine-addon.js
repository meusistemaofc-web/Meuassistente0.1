/* Vitrine de Links: menu flutuante de atalhos "/" no chat. Busca determinística (sem IA), 100% local depois da primeira consulta.
   Só age quando o campo contém APENAS "/" + letras/números/-/_ (URL, código e texto comum nunca disparam). Enter só é interceptado
   com o menu aberto e uma opção marcada; fora disso a mensagem é enviada normalmente. O atalho nunca é enviado à IA. */
(function(){
if(window.__maVitrine)return;window.__maVitrine=true;
const RE=/^\/[a-z0-9_-]*$/i;
const norm=t=>String(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let LIST=null,LAT=0,CTX=null,menu=null,items=[],act=0,field=null,loading=null,blocked=0;
const agentId=()=>String(window.__MA_AGENT||(location.pathname.match(/^\/a\/(\d+)/)||[])[1]||'');
const canal=()=>agentId()?'agentes':'chat';
const qs=()=>'canal='+canal()+(agentId()?'&b='+agentId():'');
const isField=el=>el&&el.nodeType===1&&(el.matches('textarea.composer-input')||(el.id==='t'&&el.closest('#f')));
async function load(force){
  if(!force&&LIST&&Date.now()-LAT<60000)return LIST;
  if(blocked&&Date.now()-blocked<60000)return[];
  if(loading)return loading;
  loading=(async()=>{try{const r=await fetch('/api/v2/showcase?'+qs(),{credentials:'same-origin',cache:'no-store'});if(!r.ok){blocked=Date.now();LIST=[];return LIST}blocked=0;LIST=(await r.json()).itens||[];LAT=Date.now();return LIST}catch(e){return LIST||[]}finally{loading=null}})();
  return loading;
}
/* mesma regra do servidor: "/" = tudo; prefixo primeiro, depois trecho da palavra ou do título */
function search(list,tok){
  const t=norm(tok);if(t==='/'||!t)return list;const term=t.slice(1);
  const pre=list.filter(x=>norm(x.palavra).startsWith(t)),rest=list.filter(x=>!pre.includes(x)&&(norm(x.palavra).slice(1).includes(term)||norm(x.titulo).includes(term)));
  return pre.concat(rest);
}
function setValue(el,v){
  const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));
}
function css(){
  if(document.getElementById('ma-vit-css'))return;const s=document.createElement('style');s.id='ma-vit-css';
  s.textContent='.ma-vit-menu{position:fixed;z-index:2147483000;max-height:min(46vh,340px);overflow-y:auto;border-radius:1.3rem;padding:6px;background:var(--nx-surface,#141416);border:1px solid var(--nx-line-strong,#333);box-shadow:0 18px 50px rgba(0,0,0,.55);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)}'+
  '.ma-vit-menu [role=option]{display:flex;flex-direction:column;gap:1px;padding:9px 12px;border-radius:.9rem;cursor:pointer;color:var(--nx-ink,#fff)}.ma-vit-menu [role=option][aria-selected=true]{background:color-mix(in srgb,var(--nx-accent,#5b8dff) 22%,transparent)}'+
  '.ma-vit-menu b{font-size:14px}.ma-vit-menu small{font-size:12px;color:var(--nx-ink-3,#9a9aa2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ma-vit-empty{padding:10px 12px;font-size:13px;color:var(--nx-ink-3,#9a9aa2)}'+
  '.ma-vit-card{display:flex;justify-content:flex-start;padding:4px 16px 10px}.ma-vit-card>div{width:min(88%,360px);overflow:hidden;border-radius:1.4rem;border:1px solid var(--nx-line-strong,#333);background:var(--nx-surface,#141416);color:var(--nx-ink,#fff);box-shadow:0 10px 30px rgba(0,0,0,.35)}'+
  '.ma-vit-card img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#111}.ma-vit-card .b{padding:12px 14px 14px}.ma-vit-card h4{font-size:16px;font-weight:700;margin:0}.ma-vit-card p{margin:4px 0 0;font-size:13.5px;color:var(--nx-ink-2,#c4c4cc)}.ma-vit-card small{display:block;margin-top:6px;font-size:11.5px;color:var(--nx-ink-3,#9a9aa2)}'+
  '.ma-vit-card button{margin-top:12px;width:100%;height:42px;border-radius:999px;border:0;font-weight:600;font-size:14px;cursor:pointer;background:var(--nx-accent,#5b8dff);color:#fff}';
  document.head.appendChild(s);
}
function place(){
  if(!menu||!field)return;const host=field.closest('.glass-bar,#f')||field,r=host.getBoundingClientRect();
  menu.style.left=Math.max(8,r.left)+'px';menu.style.width=Math.min(r.width,window.innerWidth-16)+'px';menu.style.bottom=Math.max(8,window.innerHeight-r.top+8)+'px';
}
function close(){if(menu){menu.remove();menu=null}items=[];act=0}
function paint(){
  if(!menu){css();menu=document.createElement('div');menu.className='ma-vit-menu';menu.setAttribute('role','listbox');menu.setAttribute('aria-label','Atalhos');
    menu.addEventListener('pointerdown',e=>{e.preventDefault();const o=e.target.closest('[data-i]');if(o)pick(items[+o.dataset.i])});document.body.appendChild(menu)}
  menu.innerHTML=items.map((x,i)=>`<div role="option" data-i="${i}" aria-selected="${i===act}"><b>${esc(x.palavra)} · ${esc(x.titulo)}</b><small>${esc(x.descricao)}</small></div>`).join('');
  place();const a=menu.querySelector('[aria-selected=true]');if(a)a.scrollIntoView({block:'nearest'});
}
async function update(){
  if(!field)return;const v=field.value;
  if(!RE.test(v)){close();return}
  const list=await load();if(!field||field.value!==v)return;
  items=search(list,v);
  if(!items.length){close();return} // sem resultado: nada intercepta, a mensagem segue normal
  const ex=items.findIndex(x=>norm(x.palavra)===norm(v));act=ex>=0?ex:0;paint();
}
async function pick(x){
  if(!x||!field)return;const f=field;close();setValue(f,'');f.focus();
  try{const r=await fetch(`/api/v2/showcase/${x.id}?`+qs(),{credentials:'same-origin'});if(!r.ok)throw 0;showCard((await r.json()).card)}catch(e){LIST=null}
}
function showCard(c){
  css();const host=document.querySelector('.chat-scroll')||document.getElementById('chat');if(!host)return;
  const w=document.createElement('div');w.className='ma-vit-card';w.innerHTML=`<div>${c.imagem?`<img src="${esc(c.imagem)}" alt="" loading="lazy">`:''}<div class="b"><h4>${esc(c.titulo)}</h4><p>${esc(c.descricao)}</p><small>${esc(c.palavra)}</small><button type="button">Acessar</button></div></div>`;
  w.querySelector('button').onclick=()=>{const u=c.url;if(!/^https?:\/\//i.test(u))return;window.open(u,'_blank','noopener,noreferrer');try{fetch(`/api/v2/showcase/${c.id}/click?`+qs(),{method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:'{}'})}catch(e){}};
  host.appendChild(w);host.scrollTop=host.scrollHeight;const sc=document.getElementById('sc');if(sc)sc.scrollTop=sc.scrollHeight;w.scrollIntoView({block:'end'});
}
document.addEventListener('input',e=>{if(isField(e.target)){field=e.target;update()}},true);
document.addEventListener('focusin',e=>{if(isField(e.target)){field=e.target;if(RE.test(field.value))update()}});
document.addEventListener('focusout',e=>{if(isField(e.target))setTimeout(()=>{if(document.activeElement!==field)close()},150)});
document.addEventListener('keydown',e=>{
  if(!menu||!items.length||!isField(e.target)||e.isComposing)return;
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();act=(act+(e.key==='ArrowDown'?1:items.length-1))%items.length;paint()}
  else if(e.key==='Escape'){close()}
  else if((e.key==='Enter'&&!e.shiftKey)||e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();pick(items[act])}
},true);
/* botão de enviar: com o menu aberto e o texto igual a uma palavra-chave, abre o card em vez de enviar */
document.addEventListener('click',e=>{
  if(!menu||!field)return;const b=e.target.closest&&e.target.closest('button');if(!b||b.closest('.ma-vit-menu'))return;
  const root=field.closest('.glass-bar,#f');if(!root||!root.contains(b))return;
  const exact=items.find(x=>norm(x.palavra)===norm(field.value));if(exact&&/enviar|send/i.test((b.getAttribute('aria-label')||'')+b.id)){e.preventDefault();e.stopImmediatePropagation();pick(exact)}
},true);
window.addEventListener('resize',place);window.addEventListener('scroll',place,true);
window.__maVitrineReload=()=>{LIST=null;return load(true)};
})();
