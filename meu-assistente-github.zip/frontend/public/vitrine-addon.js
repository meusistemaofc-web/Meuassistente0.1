/* Vitrine de Links: menu flutuante de atalhos "/" no chat. Busca determinística (sem IA), 100% local depois da primeira consulta.
   Só age quando o campo contém APENAS "/" + letras/números/-/_ (URL, código e texto comum nunca disparam). Enter só é interceptado
   com o menu aberto e uma opção marcada; fora disso a mensagem é enviada normalmente. O atalho nunca é enviado à IA. */
(function(){
if(window.__maVitrine)return;window.__maVitrine=true;
const RE=/^\/[a-z0-9_-]*$/i;
const norm=t=>String(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let LIST=null,LAT=0,CTX=null,menu=null,items=[],act=0,field=null,loading=null,blocked=0;
const agentId=()=>String(window.__MA_AGENT||(location.pathname.match(/^\/a\/(\d+)/)||[])[1]||'');
const canal=()=>agentId()?'agentes':'chat';
const qs=()=>'canal='+canal()+(agentId()?'&b='+agentId():'');
const isField=el=>el&&el.nodeType===1&&(el.matches('textarea.composer-input')||(el.id==='t'&&el.closest('#f')));
async function load(force){
  if(!force&&LIST&&Date.now()-LAT<60000)return LIST;
  if(blocked&&Date.now()-blocked<60000)return[];
  if(loading)return loading;
  loading=(async()=>{try{const r=await fetch('/api/v2/showcase?'+qs(),{credentials:'same-origin',cache:'no-store'});if(!r.ok){blocked=Date.now();LIST=[];return LIST}blocked=0;LIST=(await r.json()).itens||[];LAT=Date.now();return LIST}catch(e){return LIST||[]}finally{loading=null}})();
  return loading;
}
/* mesma regra do servidor: "/" = tudo; prefixo primeiro, depois trecho da palavra ou do título */
function search(list,tok){
  const t=norm(tok);if(t==='/'||!t)return list;const term=t.slice(1);
  const pre=list.filter(x=>norm(x.palavra).startsWith(t)),rest=list.filter(x=>!pre.includes(x)&&(norm(x.palavra).slice(1).includes(term)||norm(x.titulo).includes(term)));
  return pre.concat(rest);
}
function setValue(el,v){
  const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));
}
function css(){
  if(document.getElementById('ma-vit-css'))return;const s=document.createElement('style');s.id='ma-vit-css';
  s.textContent='.ma-vit-menu{opacity:0;transform:translateY(8px) scale(.98);transform-origin:bottom center;transition:opacity .16s ease,transform .16s ease;pointer-events:none}.ma-vit-menu.in{opacity:1;transform:none;pointer-events:auto}@media(prefers-reduced-motion:reduce){.ma-vit-menu{transition:none}}'+
  '.ma-vit-menu{position:fixed;z-index:2147483000;max-height:min(46vh,340px);overflow-y:auto;border-radius:1.3rem;padding:6px;background:var(--nx-surface,#141416);border:1px solid var(--nx-line-strong,#333);box-shadow:0 18px 50px rgba(0,0,0,.55);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)}'+
  '.ma-vit-menu [role=option]{display:flex;flex-direction:column;gap:1px;padding:9px 12px;border-radius:.9rem;cursor:pointer;color:var(--nx-ink,#fff)}.ma-vit-menu [role=option][aria-selected=true]{background:color-mix(in srgb,var(--nx-accent,#5b8dff) 22%,transparent)}'+
  '.ma-vit-menu b{font-size:14px}.ma-vit-menu small{font-size:12px;color:var(--nx-ink-3,#9a9aa2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ma-vit-empty{padding:10px 12px;font-size:13px;color:var(--nx-ink-3,#9a9aa2)}'+
  '.ma-vit-card{display:flex;justify-content:flex-start;padding:4px 16px 10px}.ma-lc-row:not(.ma-lc-done)::after{content:"";display:block;height:120px;width:min(88%,360px);margin-left:auto;border-radius:1.4rem;background:rgba(255,255,255,.05)}.ma-vit-card>div{width:min(88%,360px);overflow:hidden;border-radius:1.4rem;border:1px solid var(--nx-line-strong,#333);background:var(--nx-surface,#141416);color:var(--nx-ink,#fff);box-shadow:0 10px 30px rgba(0,0,0,.35)}'+
  '.ma-vit-card img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#111}.ma-vit-card .b{padding:12px 14px 14px}.ma-vit-card h4{font-size:16px;font-weight:700;margin:0}.ma-vit-card p{margin:4px 0 0;font-size:13.5px;color:var(--nx-ink-2,#c4c4cc)}.ma-vit-card small{display:block;margin-top:6px;font-size:11.5px;color:var(--nx-ink-3,#9a9aa2)}'+
  '.ma-lc-row>*:not(.ma-vit-card){display:none!important}.ma-lc-row .ma-vit-card{display:flex;justify-content:flex-end;padding:0}.ma-vit-card[data-lc]{justify-content:flex-end}'+
  '.ma-vit-card button{margin-top:12px;width:100%;height:42px;border-radius:999px;border:0;font-weight:600;font-size:14px;cursor:pointer;background:var(--nx-accent,#5b8dff);color:#fff}';
  document.head.appendChild(s);
}
function place(){
  if(!menu||!field)return;const host=field.closest('.glass-bar,#f')||field,r=host.getBoundingClientRect();
  menu.style.left=Math.max(8,r.left)+'px';menu.style.width=Math.min(r.width,window.innerWidth-16)+'px';menu.style.bottom=Math.max(8,window.innerHeight-r.top+8)+'px';
}
function close(){if(menu){const m=menu;menu=null;m.classList.remove('in');m.style.pointerEvents='none';setTimeout(()=>m.remove(),180)}items=[];act=0}
function paint(){
  if(!menu){css();menu=document.createElement('div');menu.className='ma-vit-menu';menu.setAttribute('role','listbox');menu.setAttribute('aria-label','Atalhos');
    menu.addEventListener('pointerdown',e=>{e.preventDefault();const o=e.target.closest('[data-i]');if(o)pick(items[+o.dataset.i])});document.body.appendChild(menu);const m0=menu;requestAnimationFrame(()=>requestAnimationFrame(()=>m0.classList.add('in')))}
  menu.innerHTML=items.map((x,i)=>`<div role="option" data-i="${i}" aria-selected="${i===act}"><b>${esc(x.palavra)} · ${esc(x.titulo)}</b><small>${esc(x.descricao)}</small></div>`).join('');
  place();const a=menu.querySelector('[aria-selected=true]');if(a)a.scrollIntoView({block:'nearest'});
}
async function update(){
  if(!field)return;const v=field.value;
  if(!RE.test(v)){close();return}
  const list=await load();if(!field||field.value!==v)return;
  items=search(list,v);
  if(!items.length){close();return} // sem resultado: nada intercepta, a mensagem segue normal
  const ex=items.findIndex(x=>norm(x.palavra)===norm(v));act=ex>=0?ex:0;paint();
}
/* ---------- cartões como mensagens do histórico (tipo link_card) ----------
   No chat principal o cartão é gravado no servidor como mensagem do usuário, ligada ao id da conversa e à ordem cronológica; ao
   voltar à conversa, atualizar a página ou reabrir o app, ele vem do histórico oficial (GET /api/chat?c=). Em chat novo (ainda sem id)
   o cartão fica pendente e é gravado imediatamente ANTES do primeiro envio, preservando a ordem (cartão → pergunta → resposta). */
const LC=/^⟦lc:(\d+):([A-Za-z0-9-]{8,40})⟧$/;
const CARDS=new Map(),SESS={};let PENDING=[],INFLIGHT=[];
const remember=(cid,card,id)=>{if(!cid||!id)return;(SESS[cid]=SESS[cid]||[]).push({card,id:Number(id)})};
const newOp=()=>(window.crypto&&crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(36).slice(2)).replace(/[^A-Za-z0-9-]/g,'').slice(0,36).padEnd(8,'0');
function mountCard(c){
  css();const w=document.createElement('div');w.className='ma-vit-card';w.dataset.conv=conv();
  w.innerHTML=`<div>${c.imagem?`<img src="${esc(c.imagem)}" alt="" loading="lazy">`:''}<div class="b"><h4>${esc(c.titulo)}</h4><p>${esc(c.descricao)}</p><small>${esc(c.palavra)}</small><button type="button">Acessar</button></div></div>`;
  w.querySelector('button').onclick=()=>{const u=c.url;if(!/^https?:\/\//i.test(u))return;window.open(u,'_blank','noopener,noreferrer');try{fetch(`/api/v2/showcase/${c.linkId||c.id}/click?canal=chat`,{method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:'{}'})}catch(e){}};
  return w;
}
const listEl=()=>document.querySelector('.chat-scroll > div > .mt-auto')||document.querySelector('.chat-scroll > div')||document.querySelector('.chat-scroll');
function scrollEnd(){const s=document.querySelector('.chat-scroll');if(s)s.scrollTop=s.scrollHeight}
function syncWelcome(){const l=listEl(),root=l&&l.parentElement;if(!root||!root.classList.contains('mx-auto'))return;const live=!!l.querySelector('.ma-vit-card[data-lc]');[...root.children].forEach(c=>{if(c!==l&&c.classList.contains('flex-1')){if(live)c.style.display='none';else if(c.style.display==='none')c.style.display=''}})}
async function persist(convId,card){
  const p=(async()=>{try{const r=await fetch(`/api/v2/showcase/${card.id}/message`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({conversationId:convId,opId:card.opId})});if(!r.ok)return false;const j=await r.json();remember(convId,card,j.id);return true}catch(e){return false}})();
  INFLIGHT.push(p);p.finally(()=>{INFLIGHT=INFLIGHT.filter(x=>x!==p)});return p;
}
async function flush(convId){
  if(!convId)return;await Promise.all(INFLIGHT);const list=PENDING;PENDING=[];
  for(const c of list)await persist(convId,c);
}
async function pick(x){
  if(!x||!field)return;const f=field;close();setValue(f,'');f.focus();
  let card;try{const r=await fetch(`/api/v2/showcase/${x.id}?`+qs(),{credentials:'same-origin'});if(!r.ok)throw 0;card=(await r.json()).card}catch(e){LIST=null;return}
  if(agentId()){showCard(card);return} // agentes públicos (visitante sem login): cartão apenas da sessão
  card.opId=newOp();const w=mountCard(card);w.dataset.lc=card.opId;
  const l=listEl();if(!l)return;l.appendChild(w);syncWelcome();scrollEnd();w.scrollIntoView({block:'end'});
  const c=conv();if(c)persist(c,card);else PENDING.push(card);
}
function showCard(c){
  css();const host=document.querySelector('.chat-scroll')||document.getElementById('chat');if(!host)return;
  const w=mountCard(c);host.appendChild(w);host.scrollTop=host.scrollHeight;const sc=document.getElementById('sc');if(sc)sc.scrollTop=sc.scrollHeight;w.scrollIntoView({block:'end'});
}
/* mensagens link_card vindas do histórico oficial viram o cartão no lugar exato da mensagem */
/* O app guarda em memória as mensagens das conversas já abertas e não as recarrega ao voltar: cartões gravados nesta sessão
   são recolocados na posição certa (pelo id da mensagem no servidor) quando a conversa volta à tela. */
function restore(){
  const c=conv(),l=listEl();if(!c||!SESS[c]||!l)return;
  const rows=[...l.children].filter(e=>e.dataset&&e.dataset.mid&&/^\d+$/.test(e.dataset.mid));if(!rows.length)return;
  SESS[c].forEach(({card,id})=>{
    if(document.querySelector(`.ma-vit-card[data-lc="${card.opId}"],.ma-lc-row[data-lc-op="${card.opId}"]`))return;
    const w=mountCard(card);w.dataset.lc=card.opId;w.dataset.conv=c;const nxt=rows.find(e=>Number(e.dataset.mid)>id);nxt?l.insertBefore(w,nxt):l.appendChild(w);
  });
}
let loadingHist=0;
function scan(){
  watchConv();restore();
  document.querySelectorAll('.chat-scroll [data-mid]:not(.ma-lc-done)').forEach(row=>{
    const p=row.querySelector('.msg-bubble.bubble-user p');if(!p)return;const m=LC.exec((p.textContent||'').trim());if(!m)return;
    css();row.classList.add('ma-lc-row');
    const c=CARDS.get(String(row.dataset.mid));
    if(!c){if(!loadingHist&&conv()){loadingHist=1;fetch('/api/chat?c='+encodeURIComponent(conv()),{credentials:'same-origin'}).catch(()=>{}).finally(()=>{setTimeout(()=>{loadingHist=0;scan()},50)})}return}
    row.classList.add('ma-lc-done');row.dataset.lcOp=m[2];row.querySelectorAll('.ma-vit-card').forEach(n=>n.remove());
    const w=mountCard(c);row.appendChild(w);
    document.querySelectorAll(`.ma-vit-card[data-lc="${m[2]}"]`).forEach(n=>{if(!row.contains(n))n.remove()});syncWelcome();
  });
}
const _fetch=window.fetch.bind(window);
window.fetch=async function(input,init){
  let url='',method='GET';try{url=typeof input==='string'?input:input instanceof URL?input.href:(input&&input.url)||'';method=String((init&&init.method)||(input&&input.method)||'GET').toUpperCase()}catch(e){}
  let path='';try{path=new URL(url,location.origin).pathname}catch(e){}
  if(!agentId()&&method==='POST'&&path==='/api/chat'&&(PENDING.length||INFLIGHT.length)){
    let cid='';try{const b=init&&init.body;if(typeof b==='string')cid=JSON.parse(b).conversationId||'';else if(b&&typeof b.get==='function')cid=b.get('conversationId')||''}catch(e){}
    try{await flush(cid||conv())}catch(e){}
  }
  const res=await _fetch(input,init);
  if(method==='GET'&&path==='/api/chat'){res.clone().json().then(j=>{(j.messages||[]).forEach(m=>{if(m&&(m.type==='link_card'||LC.test(String(m.content||''))))CARDS.set(String(m.id),(m.cards||[])[0])});scan()}).catch(()=>{})}
  return res;
};
new MutationObserver(()=>{scan();syncWelcome()}).observe(document.documentElement,{childList:true,subtree:true});
document.addEventListener('input',e=>{if(isField(e.target)){field=e.target;update()}},true);
document.addEventListener('focusin',e=>{if(isField(e.target)){field=e.target;if(RE.test(field.value))update()}});
document.addEventListener('focusout',e=>{if(isField(e.target))setTimeout(()=>{if(document.activeElement!==field)close()},150)});
document.addEventListener('keydown',e=>{
  if(!menu||!items.length||!isField(e.target)||e.isComposing)return;
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();act=(act+(e.key==='ArrowDown'?1:items.length-1))%items.length;paint()}
  else if(e.key==='Escape'){close()}
  else if((e.key==='Enter'&&!e.shiftKey)||e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();pick(items[act])}
},true);
/* botão de enviar: com o menu aberto e o texto igual a uma palavra-chave, abre o card em vez de enviar */
document.addEventListener('click',e=>{
  if(!menu||!field)return;const b=e.target.closest&&e.target.closest('button');if(!b||b.closest('.ma-vit-menu'))return;
  const root=field.closest('.glass-bar,#f');if(!root||!root.contains(b))return;
  const exact=items.find(x=>norm(x.palavra)===norm(field.value));if(exact&&/enviar|send/i.test((b.getAttribute('aria-label')||'')+b.id)){e.preventDefault();e.stopImmediatePropagation();pick(exact)}
},true);
/* Acessos temporários: os cartões e o menu pertencem à conversa em que foram abertos. Ao abrir um novo chat ou outra conversa
   somem (sem deixar espaço); a 1ª mensagem de um chat novo só ganha o id da conversa, então não apaga. */
function conv(){return new URLSearchParams(location.search).get('c')||''}
let lastConv=conv();
function clearCards(){PENDING=[];document.querySelectorAll('.ma-vit-card[data-lc]').forEach(n=>{if(!n.closest('.ma-lc-done'))n.remove()});syncWelcome()}
function watchConv(){const c=conv();if(c===lastConv)return;const gained=lastConv===''&&c!=='';lastConv=c;if(gained){document.querySelectorAll('.ma-vit-card[data-conv=""]').forEach(n=>{n.dataset.conv=c});return}close();clearCards()}
setInterval(watchConv,150);window.addEventListener('popstate',watchConv);
window.addEventListener('resize',place);window.addEventListener('scroll',place,true);
window.__maVitrineReload=()=>{LIST=null;return load(true)};
})();
