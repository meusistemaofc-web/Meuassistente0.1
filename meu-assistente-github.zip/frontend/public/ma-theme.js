/* Meu Assistente · identidade visual da empresa (UMA fonte central).
   O tema salvo em businesses.data.tema (cor, fundo, layout, cantos) é resolvido AQUI e aplicado em todas as
   áreas comerciais: página do catálogo, janelas/cards (produto, carrinho, agendamento), chat do agente e
   componentes internos. Cada área só se registra (bind/layer); nenhuma guarda cores próprias. */
(function(){
if(window.MaTheme)return;
var DARK={'--nx-canvas':'#000','--nx-surface':'#101010','--nx-surface-2':'#161616','--nx-line':'#ffffff14','--nx-line-strong':'#ffffff26','--nx-ink':'#fff','--nx-ink-2':'#a3a3a3','--nx-ink-3':'#767676','--nx-danger':'#ff6f6f','--nx-success':'#2fd27a','--nx-glass':'linear-gradient(180deg, #161616b8, #0c0c0ca8)','--nx-glass-strong':'linear-gradient(180deg, #101010fa, #0a0a0afa)','--nx-glass-border':'#ffffff17','--nx-glass-highlight':'#ffffff0d','--nx-glass-shadow':'0 14px 44px -18px #000000d9','--nx-inset':'#ffffff09','--nx-glass-bar':'linear-gradient(180deg, #0c0c0ce0, #040404db)'};
var LIGHT={'--nx-canvas':'#f5f5f2','--nx-surface':'#ffffff','--nx-surface-2':'#ececea','--nx-line':'#e4e4e7','--nx-line-strong':'#d4d4d8','--nx-ink':'#17171b','--nx-ink-2':'#3f3f46','--nx-ink-3':'#71717a','--nx-danger':'#cf3d3d','--nx-success':'#17a35a','--nx-glass':'#ffffff','--nx-glass-strong':'#ffffff','--nx-glass-border':'#e4e4e7','--nx-glass-highlight':'#ffffffe6','--nx-glass-shadow':'0 1px 2px #0000000d','--nx-inset':'#ffffff','--nx-glass-bar':'#ffffff'};
var PRESETS={padrao:{nome:'Padrão',cor:'#3b6cff',fundo:'escuro',layout:'lista'},elegante:{nome:'Elegante',cor:'#c9a227',fundo:'escuro',layout:'lista'},vibrante:{nome:'Vibrante',cor:'#ff4d6d',fundo:'colorido',layout:'grade'},natural:{nome:'Natural',cor:'#2f9e5b',fundo:'claro',layout:'grade'},clean:{nome:'Clean',cor:'#111827',fundo:'claro',layout:'lista'}};
var CSS=[
'[data-ma-themed]{color:var(--nx-ink)}',
'html[data-ma-themed] body{background:var(--ma-bg,var(--nx-canvas))}',
'[data-ma-themed][data-ma-grad]{background:var(--ma-bg)}',
'[data-ma-themed] ::placeholder{color:var(--nx-ink-3);opacity:1}',
'[data-ma-themed] input,[data-ma-themed] select,[data-ma-themed] textarea{color:var(--nx-ink);-webkit-text-fill-color:var(--nx-ink)}',
'[data-ma-themed] .btn-send{color:var(--nx-accent-ink);background:linear-gradient(color-mix(in srgb,var(--nx-accent) 84%,#fff),var(--nx-accent));box-shadow:inset 0 1px #ffffff40,0 8px 26px -8px color-mix(in srgb,var(--nx-accent) 70%,transparent)}',
'[data-ma-themed] .bubble-user{color:var(--nx-accent-ink);background:linear-gradient(color-mix(in srgb,var(--nx-accent) 92%,#fff),var(--nx-accent));border:1px solid color-mix(in srgb,var(--nx-accent) 55%,#fff);box-shadow:inset 0 1px #ffffff29,0 10px 30px -14px color-mix(in srgb,var(--nx-accent) 65%,transparent)}',
'[data-ma-themed] .u a,[data-ma-themed] .bubble-user a{color:inherit}',
'[data-ma-themed] .lg,[data-ma-themed] .opt button.on,[data-ma-themed] .ma-fab>span,[data-ma-themed] .ma-nav button.on{color:var(--nx-accent-ink)}',
'[data-ma-themed] .opt button.on{background:var(--nx-accent);border-color:var(--nx-accent)}',
'[data-ma-themed] .ma-tag,[data-ma-themed] .pc .tag{color:var(--nx-ink);background:color-mix(in srgb,var(--nx-ink) 8%,transparent);border:1px solid color-mix(in srgb,var(--nx-ink) 12%,transparent)}',
'[data-ma-themed] .note{background:color-mix(in srgb,#f0b54a 18%,var(--nx-canvas));color:color-mix(in srgb,#f0b54a 70%,var(--nx-ink))}',
'.ma-reto .glass,.ma-reto .glass-strong,.ma-reto .glass-inset,.ma-reto .rich,.ma-reto .pc,.ma-reto .m,.ma-reto .ma-sheet-in,.ma-reto .ma-pc,.ma-reto img:not(.lg){border-radius:.5rem!important}',
'.ma-reto .btn-send,.ma-reto .bt,.ma-reto .bt2,.ma-reto .opt button,.ma-reto .fi,.ma-reto form,.ma-reto .chips button,.ma-reto .chips a,.ma-reto [data-cat],.ma-reto .ma-ico-btn{border-radius:.5rem!important}'
].join('\n');
function hex(c){c=String(c||'').replace('#','');return c.length===6?[parseInt(c.slice(0,2),16),parseInt(c.slice(2,4),16),parseInt(c.slice(4,6),16)]:[59,108,255]}
function ink(cor){var r=hex(cor);return (r[0]*299+r[1]*587+r[2]*114)/1000>=150?'#111827':'#ffffff'}
function norm(t){var o=t&&typeof t==='object'?t:{};var cor=/^#[0-9a-f]{6}$/i.test(String(o.cor))?String(o.cor).toLowerCase():'#3b6cff';return{preset:typeof o.preset==='string'&&o.preset?o.preset:'padrao',cor:cor,fundo:['escuro','claro','colorido'].indexOf(o.fundo)>=0?o.fundo:'escuro',layout:o.layout==='grade'?'grade':'lista',cantos:o.cantos==='reto'?'reto':'arredondado'}}
function resolve(t){var T=norm(t),mode=T.fundo==='claro'?'light':'dark',v=Object.assign({},mode==='light'?LIGHT:DARK);
 v['--nx-accent']=T.cor;v['--nx-accent-ink']=ink(T.cor);v['--nx-accent-soft']='color-mix(in srgb,'+T.cor+' 14%,transparent)';v['--nx-bubble']=T.cor;v['--nx-chart']=T.cor;
 var grad=T.fundo==='colorido';if(grad)v['--ma-bg']='radial-gradient(120% 60% at 50% 0%, '+T.cor+'55, var(--nx-canvas) 70%)';
 return{tema:T,mode:mode,vars:v,grad:grad,reto:T.cantos==='reto'}}
function injectCss(){if(document.getElementById('ma-theme-css'))return;var s=document.createElement('style');s.id='ma-theme-css';s.textContent=CSS;(document.head||document.documentElement).appendChild(s)}
function clear(el){var k=el.__maKeys||[];for(var i=0;i<k.length;i++)el.style.removeProperty(k[i]);el.__maKeys=[];el.classList.remove('ma-light','ma-reto');el.removeAttribute('data-ma-grad');el.removeAttribute('data-ma-themed');
 if(el.__maPrevTheme!==undefined){if(el.__maPrevTheme===null)el.removeAttribute('data-theme');else el.setAttribute('data-theme',el.__maPrevTheme);el.__maPrevTheme=undefined}el.style.colorScheme=''}
function paint(el,t,kind){if(!el||!el.style)return;injectCss();var r=resolve(t);clear(el);
 if(el.__maPrevTheme===undefined)el.__maPrevTheme=el.hasAttribute('data-theme')?el.getAttribute('data-theme'):null;
 el.setAttribute('data-theme',r.mode);el.setAttribute('data-ma-themed',kind||'layer');el.style.colorScheme=r.mode;
 var keys=Object.keys(r.vars);for(var i=0;i<keys.length;i++)el.style.setProperty(keys[i],r.vars[keys[i]]);el.__maKeys=keys;
 if(r.mode==='light')el.classList.add('ma-light');if(r.reto)el.classList.add('ma-reto');if(r.grad&&el!==document.documentElement)el.setAttribute('data-ma-grad','1');
 return r}
var roots=new Set(),listeners=[],M={current:null,bid:null,presets:PRESETS,norm:norm,resolve:resolve,ink:ink,paint:paint};
function cacheKey(b){return 'ma-tema:'+b}
M.cached=function(bid){try{var v=localStorage.getItem(cacheKey(bid));return v?norm(JSON.parse(v)):null}catch(e){return null}};
function live(){roots.forEach(function(el){if(!el.isConnected){roots.delete(el)}});return roots}
M.active=function(){var a=false;live().forEach(function(el){if(el.getAttribute('data-ma-themed')==='page')a=true});return a};
M.bind=function(el,kind){if(!el)return;roots.add(el);if(M.current)paint(el,M.current,kind||'page');else el.setAttribute('data-ma-themed',kind||'page');el.__maKind=kind||'page'};
/* janelas e camadas (modais, cards, painéis flutuantes) herdam o tema da empresa enquanto a página dela estiver aberta */
M.layer=function(el){if(!el||!M.current||!M.active())return false;roots.add(el);el.__maKind='layer';paint(el,M.current,'layer');return true};
M.unbind=function(el){roots.delete(el);if(el)clear(el)};
M.onChange=function(fn){listeners.push(fn)};
M.set=function(t,bid){var n=norm(t);if(bid!=null)M.bid=bid;var same=M.current&&JSON.stringify(M.current)===JSON.stringify(n);M.current=n;
 if(M.bid!=null){try{localStorage.setItem(cacheKey(M.bid),JSON.stringify(n))}catch(e){}}
 if(!same){live().forEach(function(el){paint(el,n,el.__maKind||'page')});listeners.forEach(function(f){try{f(n)}catch(e){}});try{window.dispatchEvent(new CustomEvent('ma:tema',{detail:n}))}catch(e){}}
 return n};
/* sincronização: quando a empresa salva o tema, todas as telas abertas (outras abas, iframes, chat do agente) atualizam */
var CH=null;try{if('BroadcastChannel' in window)CH=new BroadcastChannel('ma-tema')}catch(e){}
function receive(m){if(!m||m.bid==null||String(m.bid)!==String(M.bid))return;M.set(m.tema)}
M.broadcast=function(bid,tema){var n=norm(tema);try{localStorage.setItem(cacheKey(bid),JSON.stringify(n))}catch(e){}
 try{CH&&CH.postMessage({bid:bid,tema:n})}catch(e){}try{localStorage.setItem('ma-tema-sync',JSON.stringify({bid:bid,tema:n,t:Date.now()}))}catch(e){}receive({bid:bid,tema:n})};
if(CH)CH.onmessage=function(ev){receive(ev.data)};
window.addEventListener('storage',function(ev){if(ev.key==='ma-tema-sync'&&ev.newValue){try{receive(JSON.parse(ev.newValue))}catch(e){}}});
/* aparelhos diferentes: confere o tema salvo ao voltar para a tela e a cada 30 s (rota leve, sem contar visita) */
var watching=null;
M.watch=function(bid){if(watching&&watching.bid===bid)return;if(watching)clearInterval(watching.tm);var run=function(){if(document.hidden||!M.active())return;
  fetch('/api/v2/theme/'+bid,{credentials:'same-origin'}).then(function(r){return r.ok?r.json():null}).then(function(j){if(j&&j.tema&&String(M.bid)===String(bid))M.set(j.tema)}).catch(function(){})};
 watching={bid:bid,tm:setInterval(run,30000)};document.addEventListener('visibilitychange',run);window.addEventListener('focus',run)};
window.MaTheme=M;
})();
