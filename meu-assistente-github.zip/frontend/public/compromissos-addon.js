/* Configurações → Compromissos: lista dos compromissos do usuário com edição completa.
   Reaproveita o painel do compromisso do app (modules-addon → window.maApptDrawer): cada "Editar" abre AQUELE compromisso
   pelo identificador e salvar altera só ele. A lista é recarregada do servidor depois de cada alteração. */
(function(){
if(window.__maCompr)return;window.__maCompr=true;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=v=>Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const ST={scheduled:'Agendado',confirmed:'Confirmado',done:'Concluído',cancelled:'Cancelado',no_show:'Não compareceu'};
const api=async(u)=>{const r=await fetch(u,{credentials:'include'});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||j.message||'Não foi possível carregar.');return j};
let estado={periodo:'proximos',q:'',status:''},timer=null;
function css(){if(document.getElementById('ma-compr-css'))return;const s=document.createElement('style');s.id='ma-compr-css';s.textContent=`
#compromissos .mc-card{border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 12%,transparent);border-radius:1.4rem;overflow:hidden}
#compromissos .mc-row{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-top:1px solid color-mix(in srgb,var(--nx-ink,#fff) 8%,transparent)}
#compromissos .mc-row:first-child{border-top:0}
#compromissos .mc-when{width:64px;flex:none;text-align:right;font-variant-numeric:tabular-nums}
#compromissos .mc-when b{display:block;font-size:15px;font-weight:600}#compromissos .mc-when span{font-size:11px;color:var(--nx-ink-3,#999);text-transform:uppercase;letter-spacing:.04em}
#compromissos .mc-main{flex:1;min-width:0}#compromissos .mc-t{font-size:14.5px;font-weight:600;overflow-wrap:anywhere}
#compromissos .mc-s{margin-top:2px;font-size:12.5px;color:var(--nx-ink-3,#999);overflow-wrap:anywhere}
#compromissos .mc-pill{display:inline-block;margin-left:6px;padding:1px 8px;border-radius:999px;font-size:11px;font-weight:600;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 18%,transparent);vertical-align:1px}
#compromissos .mc-pill.bad{color:#ff8a8a;border-color:#ff8a8a55}#compromissos .mc-pill.ok{color:#5bd68a;border-color:#5bd68a55}
#compromissos .mc-ed{flex:none;height:34px;padding:0 14px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 18%,transparent);background:transparent;color:inherit;font-size:13px;cursor:pointer}
#compromissos .mc-bar{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}
#compromissos .mc-bar input,#compromissos .mc-bar select{height:38px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);background:transparent;color:inherit;padding:0 14px;font-size:13.5px;min-width:0}
#compromissos .mc-bar input{flex:1 1 180px}#compromissos .mc-bar select option{color:#111}
#compromissos .mc-tab{height:34px;padding:0 14px;border-radius:999px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);background:transparent;color:inherit;font-size:13px;cursor:pointer}
#compromissos .mc-tab[aria-pressed=true]{background:var(--nx-ink,#fff);color:var(--nx-bg,#000)}
#compromissos .mc-vazio{padding:22px 16px;text-align:center;font-size:13.5px;color:var(--nx-ink-3,#999)}`;document.head.appendChild(s)}
function linha(a,hoje){const d=new Date(a.date+'T12:00:00'),dia=a.date===hoje?'Hoje':d.toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit'}).replace('.','');
 const fin=[];if(a.valorTotal!=null)fin.push(brl(a.valorTotal));if(a.sinal!=null)fin.push('sinal '+brl(a.sinal)+(a.sinalPct!=null?` (${String(a.sinalPct).replace('.',',')}%)`:''));if(a.valorPago)fin.push('pago '+brl(a.valorPago));if(a.restante!=null&&a.valorPago)fin.push('restante '+brl(a.restante));
 const k=a.status==='cancelled'||a.status==='no_show'?'bad':a.status==='done'?'ok':'';
 return `<div class="mc-row" data-mc="${a.id}"><div class="mc-when"><b>${a.time?esc(a.time):'—'}</b><span>${esc(dia)}</span></div><div class="mc-main"><p class="mc-t">${esc(a.title)}<span class="mc-pill ${k}">${esc(ST[a.status]||'Agendado')}</span></p><p class="mc-s">${[a.clienteNome?esc(a.clienteNome):'',a.clienteTelefone?esc(String(a.clienteTelefone).replace(/^(\d{2})(\d{4,5})(\d{4})$/,'($1) $2-$3')):'',fin.join(' · ')].filter(Boolean).join(' · ')||'Sem cliente ou valores'}</p>${a.notes?`<p class="mc-s">${esc(a.notes).slice(0,140)}</p>`:''}</div><button type="button" class="mc-ed" data-mced="${a.id}" aria-label="Editar compromisso ${esc(a.title)} de ${esc(dia)}">Editar</button></div>`}
async function carregar(sec){const box=sec.querySelector('[data-mc-lista]');if(!box)return;box.innerHTML='<p class="mc-vazio">Carregando…</p>';
 try{const p=new URLSearchParams({periodo:estado.periodo,q:estado.q,status:estado.status});const r=await api('/api/v2/compromissos?'+p);
  box.innerHTML=r.compromissos.length?`<div class="mc-card">${r.compromissos.map(a=>linha(a,r.today)).join('')}</div>${r.total>r.compromissos.length?`<p class="mc-vazio">Mostrando ${r.compromissos.length} de ${r.total}. Use a busca para encontrar os demais.</p>`:''}`:`<p class="mc-vazio">${estado.q||estado.status?'Nenhum compromisso encontrado com esse filtro.':estado.periodo==='anteriores'?'Nenhum compromisso anterior.':'Nenhum compromisso agendado. Peça no chat, por exemplo: “agendar tatuagem dia 10 às 15h, cliente José, valor R$ 200, sinal de 50%”.'}</p>`;
  box.querySelectorAll('[data-mced]').forEach(b=>b.onclick=()=>{if(window.maApptDrawer)window.maApptDrawer(+b.dataset.mced,()=>carregar(sec));else location.href='/agenda?tab=compromissos'})}
 catch(e){box.innerHTML=`<p class="mc-vazio">${esc(e.message)}</p>`}}
function por(){if(location.pathname!=='/perfil')return;const mem=document.querySelector('section#memoria');if(!mem||document.querySelector('section#compromissos'))return;css();
 const sec=document.createElement('section');sec.id='compromissos';sec.className=mem.className;sec.setAttribute('aria-label','Compromissos');
 const h=mem.querySelector('h2,h3');sec.innerHTML=`<${h?h.tagName.toLowerCase():'h2'} class="${h?h.className:''}">Compromissos</${h?h.tagName.toLowerCase():'h2'}><p style="font-size:12.5px;color:var(--nx-ink-3,#999);margin:4px 2px 0">Veja e edite seus compromissos: data, horário, cliente, valores, sinal, observações e situação. Cada edição altera somente o compromisso escolhido.</p>
 <div class="mc-bar" role="group" aria-label="Período"><button type="button" class="mc-tab" data-per="proximos">Próximos</button><button type="button" class="mc-tab" data-per="anteriores">Anteriores</button><button type="button" class="mc-tab" data-per="todos">Todos</button></div>
 <div class="mc-bar"><input type="search" placeholder="Buscar por serviço, cliente ou telefone" aria-label="Buscar compromissos" data-mc-q><select aria-label="Situação" data-mc-st><option value="">Todas as situações</option>${Object.entries(ST).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></div>
 <div data-mc-lista></div>`;
 mem.after(sec);
 const tabs=()=>sec.querySelectorAll('[data-per]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.per===estado.periodo)));tabs();
 sec.querySelectorAll('[data-per]').forEach(b=>b.onclick=()=>{estado.periodo=b.dataset.per;tabs();carregar(sec)});
 sec.querySelector('[data-mc-q]').oninput=e=>{clearTimeout(timer);timer=setTimeout(()=>{estado.q=e.target.value.trim();carregar(sec)},300)};
 sec.querySelector('[data-mc-st]').onchange=e=>{estado.status=e.target.value;carregar(sec)};
 carregar(sec);
 if(location.hash==='#compromissos')setTimeout(()=>sec.scrollIntoView({block:'start'}),300)}
// alterações feitas no chat ou em outra tela atualizam a lista
window.addEventListener('nexa:changed',()=>{const s=document.querySelector('section#compromissos');if(s)carregar(s)});
let t=null;new MutationObserver(()=>{clearTimeout(t);t=setTimeout(por,200)}).observe(document.documentElement,{childList:true,subtree:true});por();
})();
