/* Avaliação das respostas do Chat Principal (👍/👎 discretos abaixo de cada resposta do assistente).
   👍 marca como útil (tocar de novo desfaz). 👎 abre um painel curto com motivos, comentário opcional e a opção —
   desligada por padrão — de compartilhar a conversa com a equipe. Nada muda no envio, no histórico ou nos anexos. */
(function(){
if(window.__maFb)return;window.__maFb=true;
let ativo=true,MOT=null;const notas={},pedidos=new Set();
const css=`.ma-fb{display:flex;gap:6px;align-items:center;padding:2px 0 4px 6px}
.ma-fb button{background:transparent;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);color:var(--nx-ink-3,#8a8a8f);border-radius:999px;width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .12s,color .15s,border-color .15s;padding:0}
.ma-fb button:active{transform:scale(.94)}.ma-fb button[aria-pressed=true]{color:var(--nx-accent,#3b82f6);border-color:currentColor}
.ma-fb .ma-fb-ok{font-size:12px;color:var(--nx-ink-3,#8a8a8f);margin-left:4px}
.msg-swipe.is-selecting .ma-fb,.msg-swipe.is-selecting .ma-fb-panel{display:none}
.ma-fb-panel{margin:2px 0 6px 6px;padding:10px 12px;border-radius:16px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);max-width:min(92%,460px);font-size:13px;color:var(--nx-ink,#eee);background:color-mix(in srgb,var(--nx-surface,#111) 70%,transparent)}
.ma-fb-panel p{margin:0 0 6px}.ma-fb-panel .ch{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}
.ma-fb-panel .ch button{background:transparent;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 18%,transparent);color:inherit;border-radius:999px;padding:4px 10px;font-size:12.5px;cursor:pointer;transition:transform .12s}
.ma-fb-panel .ch button:active{transform:scale(.97)}.ma-fb-panel .ch button[aria-pressed=true]{border-color:var(--nx-accent,#3b82f6);color:var(--nx-accent,#3b82f6)}
.ma-fb-panel textarea{width:100%;box-sizing:border-box;min-height:52px;resize:vertical;border-radius:12px;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 14%,transparent);background:transparent;color:inherit;padding:8px 10px;font:inherit;font-size:13px}
.ma-fb-panel label{display:flex;gap:8px;align-items:flex-start;margin:8px 0;font-size:12.5px;color:var(--nx-ink-2,#bbb)}
.ma-fb-panel .ac{display:flex;gap:8px;justify-content:flex-end}.ma-fb-panel .ac button{border-radius:999px;padding:6px 14px;font-size:13px;cursor:pointer;border:1px solid color-mix(in srgb,var(--nx-ink,#fff) 18%,transparent);background:transparent;color:inherit}
.ma-fb-panel .ac .env{background:var(--nx-accent,#3b82f6);border-color:transparent;color:#fff}`;
const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
const UP='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/></svg>';
const DOWN='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z"/></svg>';
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function api(url,opt){const r=await fetch(url,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opt});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Não foi possível salvar.');return j}
const linhas=()=>[...document.querySelectorAll('.chat-scroll .msg-swipe[data-mid]')].filter(r=>/^\d+$/.test(r.dataset.mid)&&r.querySelector('.msg-bubble.glass'));
function pintar(row){
  const id=row.dataset.mid;let bar=row.querySelector(':scope > .ma-fb');
  if(!ativo){if(bar)bar.remove();return}
  if(!(id in notas))return;
  if(!bar){bar=document.createElement('div');bar.className='ma-fb';bar.innerHTML=`<button type="button" data-fb="1" aria-label="Resposta útil" title="Resposta útil">${UP}</button><button type="button" data-fb="-1" aria-label="Resposta não ajudou" title="Não ajudou">${DOWN}</button><span class="ma-fb-ok" role="status"></span>`;row.appendChild(bar);
    bar.addEventListener('pointerdown',e=>e.stopPropagation());bar.addEventListener('touchstart',e=>e.stopPropagation(),{passive:true});
    bar.querySelector('[data-fb="1"]').onclick=e=>{e.stopPropagation();enviar(row,notas[id]===1?0:1,{})};
    bar.querySelector('[data-fb="-1"]').onclick=e=>{e.stopPropagation();if(notas[id]===-1){enviar(row,0,{});return}abrir(row)}}
  bar.querySelector('[data-fb="1"]').setAttribute('aria-pressed',String(notas[id]===1));bar.querySelector('[data-fb="-1"]').setAttribute('aria-pressed',String(notas[id]===-1));
}
function abrir(row){
  const id=row.dataset.mid;let p=row.querySelector(':scope > .ma-fb-panel');if(p){p.remove();return}
  p=document.createElement('div');p.className='ma-fb-panel';p.setAttribute('role','group');p.setAttribute('aria-label','Por que a resposta não ajudou?');
  p.innerHTML=`<p>O que não ficou bom?</p><div class="ch">${Object.entries(MOT||{}).map(([k,v])=>`<button type="button" data-m="${k}" aria-pressed="false">${esc(v)}</button>`).join('')}</div><textarea maxlength="500" placeholder="Quer contar mais? (opcional)"></textarea><label><input type="checkbox"> <span>Compartilhar esta pergunta e a resposta com a equipe para melhorar o assistente</span></label><div class="ac"><button type="button" class="can">Cancelar</button><button type="button" class="env">Enviar</button></div>`;
  row.appendChild(p);p.addEventListener('pointerdown',e=>e.stopPropagation());p.addEventListener('touchstart',e=>e.stopPropagation(),{passive:true});
  p.querySelectorAll('[data-m]').forEach(b=>b.onclick=e=>{e.stopPropagation();b.setAttribute('aria-pressed',String(b.getAttribute('aria-pressed')!=='true'))});
  p.querySelector('.can').onclick=e=>{e.stopPropagation();p.remove()};
  p.querySelector('.env').onclick=async e=>{e.stopPropagation();const motivos=[...p.querySelectorAll('[data-m][aria-pressed=true]')].map(b=>b.dataset.m);
    const ok=await enviar(row,-1,{motivos,comentario:p.querySelector('textarea').value.trim()||undefined,compartilhar:p.querySelector('input').checked});if(ok)p.remove()};
}
async function enviar(row,nota,extra){
  const id=row.dataset.mid,bar=row.querySelector(':scope > .ma-fb'),msg=bar&&bar.querySelector('.ma-fb-ok');
  try{const r=await api('/api/chat/feedback',{method:'POST',body:JSON.stringify({messageId:Number(id),nota,...extra})});notas[id]=r.nota;pintar(row);
    if(msg){msg.textContent=r.nota===0?'':r.nota===1?'Obrigado!':r.estilo&&r.estilo.tamanho==='curto'?'Obrigado! Vou ser mais breve com você.':r.estilo&&r.estilo.tamanho==='detalhado'?'Obrigado! Vou detalhar mais.':'Obrigado! Isso ajuda a melhorar.';clearTimeout(msg._t);msg._t=setTimeout(()=>{msg.textContent=''},4000)}return true}
  catch(err){if(msg)msg.textContent=err.message;return false}
}
let tmr=null;
async function varrer(){
  if(!document.querySelector('.chat-scroll'))return;const rows=linhas();const novos=rows.map(r=>r.dataset.mid).filter(id=>!(id in notas)&&!pedidos.has(id));
  if(novos.length){novos.forEach(id=>pedidos.add(id));try{const r=await api('/api/chat/feedback?ids='+novos.join(','));ativo=r.ativo!==false;MOT=r.motivos||MOT;novos.forEach(id=>{notas[id]=Number((r.avaliacoes||{})[id]||0)})}catch(e){}finally{novos.forEach(id=>pedidos.delete(id))}}
  linhas().forEach(pintar);
}
new MutationObserver(()=>{clearTimeout(tmr);tmr=setTimeout(varrer,250)}).observe(document.documentElement,{childList:true,subtree:true});
setTimeout(varrer,600);
})();
