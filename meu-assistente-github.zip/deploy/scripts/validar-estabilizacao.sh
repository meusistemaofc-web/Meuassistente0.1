#!/usr/bin/env bash
# Validação completa do deploy (build Docker → containers → logs → saúde → testes funcionais com conta real).
# NÃO altera .env, NÃO mexe em backups/ (só ACRESCENTA um backup novo antes de trocar o contêiner),
# preserva docker-compose.override.yml (o Docker Compose o aplica sozinho) e NÃO reaplica migrações:
# o app só aplica as que ainda não constam em schema_migrations (a 039 já registrada é pulada).
#
# Uso (na pasta do projeto, no servidor):
#   MA_EMAIL=voce@exemplo.com MA_SENHA='sua-senha' bash deploy/scripts/validar-estabilizacao.sh
# Opcional: SEM_BACKUP=1 (pula o backup prévio), MA_CODIGO=<2 fatores>, MA_LIMPAR=1 (apaga a conversa de teste).
set -uo pipefail
cd "$(dirname "$0")/../.."
etapa() { echo; echo "== $*"; }
pare() { echo; echo "INTERROMPIDO: $*"; echo "O contêiner que estava no ar NÃO foi substituído (se a falha foi antes da etapa 5)."; exit 1; }
[ -f .env ] || pare "arquivo .env não encontrado (este script não cria nem altera o .env)."
[ -f docker-compose.override.yml ] && echo "docker-compose.override.yml encontrado: será aplicado pelo Docker Compose (não é modificado)."
set -a; . ./.env; set +a
U="${POSTGRES_USER:-meuassistente}"; D="${POSTGRES_DB:-meuassistente}"; PORTA="${APP_PORT:-3000}"

etapa "1/8 Configuração do Docker Compose"
docker compose config -q || pare "docker compose config falhou."
echo "OK"

etapa "2/8 Build da imagem (instala dependências e compila o TypeScript em modo estrito)"
docker compose build app || pare "o build da imagem falhou — veja os erros do TypeScript acima."
echo "OK: imagem construída"

etapa "3/8 Estado do banco ANTES de subir a nova versão"
docker compose up -d db >/dev/null
for i in $(seq 1 30); do docker compose exec -T db pg_isready -U "$U" -d "$D" >/dev/null 2>&1 && break; sleep 2; done
docker compose exec -T db psql -U "$U" -d "$D" -tA -c "SELECT 'migrações registradas: ' || COUNT(*) || ' (última: ' || MAX(version) || ')' FROM schema_migrations" 2>/dev/null || echo "(schema_migrations ainda não existe — banco novo)"
for m in 021_laboratorio_ia.sql 039_modalidade_empresa.sql; do
  R=$(docker compose exec -T db psql -U "$U" -d "$D" -tA -c "SELECT COUNT(*) FROM schema_migrations WHERE version = '$m'" 2>/dev/null | tr -d '[:space:]')
  [ "$R" = "1" ] && echo "  $m: já aplicada (não será executada de novo)" || echo "  $m: pendente (será aplicada ao subir o app)"
done
docker compose exec -T db psql -U "$U" -d "$D" -tA -c "SELECT 'coluna businesses.modalidade: ' || CASE WHEN COUNT(*) > 0 THEN 'existe' ELSE 'não existe' END FROM information_schema.columns WHERE table_name = 'businesses' AND column_name = 'modalidade'" 2>/dev/null

etapa "4/8 Backup do banco antes de trocar o contêiner"
if [ "${SEM_BACKUP:-0}" = "1" ]; then echo "pulado (SEM_BACKUP=1)"; else bash deploy/scripts/backup.sh || pare "o backup falhou."; fi

etapa "5/8 Subindo a nova versão (só o app; o banco continua o mesmo)"
INICIO=$(date -u +%Y-%m-%dT%H:%M:%SZ)
docker compose up -d app || pare "docker compose up falhou."
CID=$(docker compose ps -q app)
ESTADO=""
for i in $(seq 1 60); do ESTADO=$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$CID" 2>/dev/null); [ "$ESTADO" = "healthy" ] && break; sleep 3; done
echo "estado do contêiner app: $ESTADO"

etapa "6/8 Logs desde a subida"
docker compose logs --no-color --since "$INICIO" app | tee /tmp/ma-validacao-logs.txt | grep -E "\[migrate\]|\[app\]|ERRO|Error|error" | head -40
if grep -qE "Consulta incompatível|syntax error|does not exist|already exists|Unhandled|FATAL" /tmp/ma-validacao-logs.txt; then echo "ATENÇÃO: há erros nos logs (arquivo completo: /tmp/ma-validacao-logs.txt)"; fi
docker compose ps

etapa "7/8 Saúde e endpoints principais"
bash deploy/scripts/smoke-test.sh "http://127.0.0.1:${PORTA}"; SMOKE=$?

etapa "8/8 Testes funcionais com conta real (login, sessão, módulos, chat com IA, histórico)"
if [ -n "${MA_EMAIL:-}" ] && [ -n "${MA_SENHA:-}" ]; then
  docker compose exec -T -e MA_EMAIL -e MA_SENHA -e MA_CODIGO="${MA_CODIGO:-}" -e MA_LIMPAR="${MA_LIMPAR:-}" -e MA_URL=http://127.0.0.1:3000 app node --input-type=module - < deploy/scripts/validar-funcional.mjs; FUNC=$?
else
  echo "pulado: defina MA_EMAIL e MA_SENHA para testar com uma conta real."; FUNC=2
fi

echo
echo "================ RESUMO ================"
echo "Build da imagem ............ OK"
echo "Contêiner app .............. $ESTADO"
echo "Smoke test ................. $([ $SMOKE -eq 0 ] && echo OK || echo FALHA)"
echo "Testes funcionais .......... $([ $FUNC -eq 0 ] && echo OK || ([ $FUNC -eq 2 ] && echo 'NÃO EXECUTADO' || echo FALHA))"
[ "$ESTADO" = "healthy" ] && [ $SMOKE -eq 0 ] && [ $FUNC -eq 0 ]
