#!/usr/bin/env bash
# Central de Processamento de Arquivos e Mídias — operação na VPS (não mexe no app, no banco nem no Whisper).
#
#   sudo bash deploy/scripts/central-midia.sh verificar   # só confere (Docker, memória, disco, contêineres, configuração)
#   sudo bash deploy/scripts/central-midia.sh testar      # constrói a imagem de TESTE e roda a suíte (não sobe nada)
#   sudo bash deploy/scripts/central-midia.sh instalar    # cria o token (se faltar) e sobe SÓ a central
#   sudo bash deploy/scripts/central-midia.sh estado      # situação e saúde da central
#   sudo bash deploy/scripts/central-midia.sh desativar   # para a central (o Meu Assistente segue normal)
#   sudo bash deploy/scripts/central-midia.sh remover     # rollback: remove o contêiner e a imagem da central
#
# Nada aqui apaga volumes, dados do banco ou outros contêineres.
set -euo pipefail
cd "$(dirname "$0")/../.."
SERVICO=central-midia
DC=(docker compose --profile midia)
cmd="${1:-ajuda}"

falha() { echo "ERRO: $*" >&2; exit 1; }
tem_env() { [ -f .env ] && grep -qE "^$1=.+" .env; }

verificar() {
  echo "== Docker";  docker --version && docker compose version || falha "Docker/Compose não encontrado."
  echo "== Arquivos"; [ -f docker-compose.yml ] && [ -f services/central-midia/Dockerfile ] || falha "Rode na pasta do projeto atualizado."
  [ -f .env ] || falha ".env não encontrado (o Meu Assistente já deveria estar instalado)."
  echo "== Configuração do Compose (sem a central e com a central)"
  docker compose config --services
  "${DC[@]}" config --services | grep -qx "$SERVICO" && echo "OK: serviço $SERVICO definido no perfil 'midia' (não sobe sozinho)."
  echo "== Contêineres em execução (nada será alterado)"; docker ps --format '  {{.Names}}  {{.Status}}  {{.Ports}}'
  echo "== Memória"; free -m || true
  livre=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)
  [ "$livre" -lt 1200 ] && echo "ATENÇÃO: só ${livre} MB livres. A central pode usar até 1 GB; considere manter MIDIA_CONCORRENCIA=1 ou liberar memória antes de instalar."
  echo "== Disco"; df -h . | tail -1
  livre_disco=$(df -Pm . | awk 'NR==2 {print $4}')
  [ "${livre_disco:-0}" -lt 3000 ] && echo "ATENÇÃO: menos de 3 GB livres; a imagem da central ocupa cerca de 1 GB."
  echo "== Porta: a central NÃO publica porta no servidor (só a rede interna do Compose usa 8095)."
  if tem_env MIDIA_TOKEN; then echo "OK: MIDIA_TOKEN definido no .env."; else echo "Pendente: MIDIA_TOKEN (o 'instalar' cria automaticamente)."; fi
  echo "Verificação concluída. Nada foi iniciado nem alterado."
}

testar() {
  echo "== Construindo a imagem de teste (roda a suíte durante o build; não inicia contêiner)"
  docker build --target teste -t meu-assistente-central-midia:teste services/central-midia
  echo "Testes da central aprovados."
  docker image rm meu-assistente-central-midia:teste >/dev/null 2>&1 || true
}

instalar() {
  verificar
  if ! tem_env MIDIA_TOKEN; then
    tok="$(openssl rand -hex 32)"
    cp .env ".env.antes-central-$(date +%Y%m%d%H%M%S)"   # cópia de segurança do .env
    printf '\n# Central de Processamento de Arquivos e Mídias\nMIDIA_TOKEN=%s\nMIDIA_URL=http://central-midia:8095\n' "$tok" >> .env
    chmod 600 .env
    echo "MIDIA_TOKEN e MIDIA_URL adicionados ao .env (cópia anterior guardada)."
  fi
  echo "== Subindo SOMENTE a central (--no-deps: app, banco e Whisper não são tocados)"
  "${DC[@]}" up -d --build --no-deps "$SERVICO"
  for i in $(seq 1 40); do
    st=$(docker inspect -f '{{.State.Health.Status}}' "$("${DC[@]}" ps -q "$SERVICO")" 2>/dev/null || echo "?")
    [ "$st" = "healthy" ] && { echo "Central no ar (healthy)."; break; }
    sleep 3; [ "$i" -eq 40 ] && falha "A central não ficou saudável. Veja: docker compose --profile midia logs --tail 80 $SERVICO"
  done
  estado
  echo "Para o app passar a usar a central na leitura de comprovantes: docker compose up -d --no-deps app (ver docs/LEITURA_LOCAL_COMPROVANTES.md)"
}

estado() {
  "${DC[@]}" ps "$SERVICO" || true
  id="$("${DC[@]}" ps -q "$SERVICO" 2>/dev/null || true)"
  if [ -n "$id" ]; then
    docker exec "$id" python -c "import urllib.request,json;print(json.load(urllib.request.urlopen('http://127.0.0.1:8095/saude',timeout=3)))" || true
    docker stats --no-stream --format '  memória: {{.MemUsage}}  CPU: {{.CPUPerc}}' "$id" || true
  else
    echo "A central não está em execução."
  fi
}

desativar() {
  "${DC[@]}" stop "$SERVICO" || true
  echo "Central parada. O Meu Assistente continua funcionando (o cliente trata a central como indisponível)."
}

remover() {
  "${DC[@]}" rm -sf "$SERVICO" || true
  docker image rm meu-assistente-central-midia:local >/dev/null 2>&1 || true
  echo "Central removida (contêiner e imagem). Nenhum volume ou dado foi apagado."
  echo "Opcional: apague as linhas MIDIA_TOKEN/MIDIA_URL do .env e rode 'docker compose up -d --no-deps app'."
}

case "$cmd" in
  verificar) verificar ;;
  testar) testar ;;
  instalar) instalar ;;
  estado) estado ;;
  desativar) desativar ;;
  remover) remover ;;
  *) sed -n '2,12p' "$0" ;;
esac
