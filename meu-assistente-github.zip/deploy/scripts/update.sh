#!/usr/bin/env bash
# Atualiza o Meu Assistente para uma nova versão dos arquivos (faz backup antes).
# Uso: sudo bash deploy/scripts/update.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
# Proteção das integrações: a atualização NUNCA cria nem substitui o .env (ele guarda a senha do banco e o APP_SECRET, a
# chave das credenciais das empresas). Se ele sumiu na troca de arquivos, para aqui em vez de subir com outro.
if [ ! -f .env ]; then
  echo "ERRO: o arquivo .env não está nesta pasta. Não substitua o .env ao atualizar os arquivos."
  echo "Restaure o .env anterior (há cópias em backups/env-*) e rode de novo. Nada foi alterado."
  ULT="$(ls -1t backups/env-* 2>/dev/null | head -1 || true)"; [ -n "$ULT" ] && echo "Cópia mais recente: $ULT  →  cp \"$ULT\" .env"
  exit 1
fi
# APP_SECRET diferente do usado antes: o app continua lendo as credenciais antigas se o valor anterior estiver em
# APP_SECRET_ANTERIOR. Avisa (não bloqueia) quando há cópia anterior do .env com outro APP_SECRET.
ULT="$(ls -1t backups/env-* 2>/dev/null | head -1 || true)"
if [ -n "$ULT" ]; then
  A="$(grep -E '^APP_SECRET=' "$ULT" | head -1 | cut -d= -f2-)"; B="$(grep -E '^APP_SECRET=' .env | head -1 | cut -d= -f2-)"
  if [ -n "$A" ] && [ "$A" != "$B" ] && ! grep -qE "^APP_SECRET_ANTERIOR=.*${A}" .env; then
    echo "AVISO: o APP_SECRET mudou desde o último backup ($ULT). Para as integrações continuarem abrindo, acrescente ao .env:"
    echo "  APP_SECRET_ANTERIOR=<valor antigo de APP_SECRET>   (está em $ULT)"
  fi
fi
bash deploy/scripts/backup.sh
if [ -d .git ]; then git pull --ff-only || echo "AVISO: git pull falhou; usando os arquivos atuais."; fi
docker compose up -d --build
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1 && break; sleep 3; done
docker image prune -f >/dev/null || true
bash deploy/scripts/smoke-test.sh
echo "Atualização concluída. As migrações do banco são aplicadas automaticamente ao iniciar."
