#!/usr/bin/env bash
# Recupera a chave que abre as credenciais salvas (Mercado Pago das empresas, SMTP, chaves de IA) quando o painel avisa
# "credenciais cifradas que o servidor não consegue abrir".
#
#   sudo bash deploy/scripts/recuperar-chave.sh                 → só procura e mostra o diagnóstico (não muda nada)
#   sudo bash deploy/scripts/recuperar-chave.sh --aplicar       → se encontrar, grava a chave em APP_SECRET_ANTERIOR
#   sudo bash deploy/scripts/recuperar-chave.sh /caminho/.env.antigo …   → inclui arquivos extras na procura
#
# Segurança: o banco nunca é alterado; nenhuma chave nova é gerada; nenhuma credencial é regravada; APP_SECRET não é
# tocado. Com --aplicar, o .env é copiado para backups/ antes e, se a conferência depois do reinício falhar, volta
# sozinho para a cópia. Os valores das chaves nunca aparecem na tela (só origem, tamanho e uma impressão curta).
set -uo pipefail
cd "$(dirname "$0")/../.."
APLICAR=0; EXTRAS=()
for a in "$@"; do if [ "$a" = "--aplicar" ]; then APLICAR=1; else EXTRAS+=("$a"); fi; done
[ -f .env ] || { echo "ERRO: .env não encontrado nesta pasta ($(pwd)). Rode o script dentro da pasta do Meu Assistente."; exit 1; }
umask 077; TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
C="$TMP/candidatos"; : > "$C"
add() { [ -n "${2:-}" ] && printf '%s\t%s\n' "$1" "$2" >> "$C"; return 0; }
le_env() { # arquivo, rótulo
  local f="$1" r="$2" l v k
  [ -r "$f" ] || return 0
  for k in APP_SECRET APP_SECRET_ANTERIOR; do
    while IFS= read -r l; do
      v="${l#*=}"; v="${v%$'\r'}"
      if [ "$k" = APP_SECRET_ANTERIOR ]; then v="${v#[\"\']}"; v="${v%[\"\']}"; IFS=',' read -ra P <<< "$v"; for x in "${P[@]}"; do add "$r ($k)" "$x"; done
      else add "$r ($k)" "$v"; fi
    done < <(grep -E "^[[:space:]]*(export[[:space:]]+)?$k=" "$f" 2>/dev/null || true)
  done
}
echo "Procurando chaves candidatas (somente leitura)…"
# 1) .env atual e cópias/versões anteriores nesta pasta
le_env .env ".env atual"
for f in .env.* backups/env-* "${EXTRAS[@]}"; do [ -f "$f" ] && [ "$f" != ".env.example" ] && le_env "$f" "$f"; done
# 2) outras instalações/versões do Meu Assistente no servidor (pastas antigas, cópias de deploy)
while IFS= read -r f; do [ "$(readlink -f "$f")" = "$(readlink -f .env)" ] || le_env "$f" "$f"; done < <(find /root /home /opt /srv /var/www -maxdepth 5 -type f \( -name ".env" -o -name ".env.*" -o -name "env-*" \) ! -name ".env.example" 2>/dev/null | xargs -r grep -l "APP_SECRET=" 2>/dev/null || true)
# 3) variáveis de ambiente de contêineres (inclusive parados/antigos) e da imagem
if command -v docker >/dev/null 2>&1; then
  for id in $(docker ps -aq 2>/dev/null); do
    nome="$(docker inspect -f '{{.Name}}' "$id" 2>/dev/null)"
    while IFS= read -r l; do case "$l" in APP_SECRET=*) add "contêiner $nome (APP_SECRET)" "${l#APP_SECRET=}";; APP_SECRET_ANTERIOR=*) IFS=',' read -ra P <<< "${l#APP_SECRET_ANTERIOR=}"; for x in "${P[@]}"; do add "contêiner $nome (APP_SECRET_ANTERIOR)" "$x"; done;; esac; done < <(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$id" 2>/dev/null)
  done
fi
# 4) a chave do banco (vault-key) gravada nos backups do banco (pg_dump): serve quando a linha foi perdida/trocada
for f in backups/*.sql.gz backups/*.sql "${EXTRAS[@]}"; do
  [ -f "$f" ] || continue
  case "$f" in *.gz) CAT="zcat";; *.sql) CAT="cat";; *) continue;; esac
  $CAT "$f" 2>/dev/null | grep -aE "^vault-key[[:space:]]|'vault-key'" | grep -oaE '[0-9a-f]{64}' | sort -u | while read -r v; do add "backup do banco $f (vault-key)" "$v"; done
done
echo "Candidatas encontradas: $(cut -f1 "$C" | wc -l) (os valores não são mostrados)."
echo
# 5) teste dentro do contêiner do app (lê o banco; não grava nada). As candidatas vão pela entrada padrão.
rodar() { if docker compose ps --status running app 2>/dev/null | grep -q app; then docker compose exec -T app node dist/db/cofre-recuperar-cli.js; else docker compose run --rm -T app node dist/db/cofre-recuperar-cli.js; fi; }
rodar < "$C" > "$TMP/recomendado"; RC=$?
echo
case $RC in
  0)  echo "Nada a recuperar: todas as credenciais em uso abrem com as chaves atuais."; exit 0;;
  10|11) ;;
  12) echo "A chave original NÃO foi encontrada em nenhum lugar deste servidor. Nada foi alterado."
      echo "Onde mais procurar: o .env de quem fez a instalação (cópia local, gerenciador de senhas, e-mail), o painel do"
      echo "provedor da VPS (variáveis/snapshots), ou um backup do banco de antes da troca. Achando, rode de novo passando"
      echo "o arquivo:  sudo bash deploy/scripts/recuperar-chave.sh /caminho/do/arquivo"; exit 12;;
  *)  echo "ERRO ao executar a verificação (código $RC). Nada foi alterado."; exit "$RC";;
esac
REC="$(grep -m1 '^APP_SECRET_ANTERIOR=' "$TMP/recomendado" | cut -d= -f2-)"
[ -n "$REC" ] || { echo "Chave encontrada, mas precisa ser colocada à mão (veja o aviso acima). Nada foi alterado."; exit "$RC"; }
if [ "$APLICAR" != 1 ]; then echo "Chave encontrada. Para gravá-la em APP_SECRET_ANTERIOR (com backup do .env), rode de novo com --aplicar."; exit "$RC"; fi
# 6) aplicar: backup do .env, acrescenta em APP_SECRET_ANTERIOR (mantém o que já existia), reinicia e confere
mkdir -p backups; BK="backups/env-antes-recuperacao-$(date +%Y%m%d-%H%M%S)"; cp -p .env "$BK"; chmod 600 "$BK"
ATUAL="$(grep -E '^APP_SECRET_ANTERIOR=' .env | tail -1 | cut -d= -f2- | sed -E "s/^['\"]//; s/['\"]$//")"
NOVO="$(printf '%s,%s' "$ATUAL" "$REC" | tr ',' '\n' | sed '/^$/d' | awk '!v[$0]++' | paste -sd, -)"
grep -vE '^APP_SECRET_ANTERIOR=' .env > "$TMP/env" || true
if printf '%s' "$NOVO" | grep -q "[[:space:]#\$\"'\\\`]"; then printf "APP_SECRET_ANTERIOR='%s'\n" "$NOVO" >> "$TMP/env"; else printf 'APP_SECRET_ANTERIOR=%s\n' "$NOVO" >> "$TMP/env"; fi # sem aspas quando possível (docker-compose antigo não remove aspas)
cat "$TMP/env" > .env
echo "APP_SECRET_ANTERIOR atualizado (backup do .env anterior: $BK). Reiniciando o app…"
docker compose up -d app >/dev/null
for i in $(seq 60); do docker compose exec -T app wget -qO- http://127.0.0.1:3000/api/health >/dev/null 2>&1 && break; sleep 2; done
: | rodar > /dev/null; RC2=$?
if [ "$RC2" = 0 ]; then echo; echo "OK: todas as credenciais em uso voltaram a abrir. Nenhum dado foi alterado no banco."; exit 0; fi
if [ "$RC" = 11 ]; then echo; echo "Recuperação PARCIAL aplicada: parte das credenciais voltou a abrir; as demais continuam sem chave (lista acima)."; exit 11; fi
echo "A conferência falhou (código $RC2). Voltando o .env para a cópia $BK…"; cp -p "$BK" .env; docker compose up -d app >/dev/null; exit 1
