// Validação FUNCIONAL do Meu Assistente com uma conta real (sem dependências: Node 22+, fetch nativo).
// Confere o CONTEÚDO das respostas (não só o status HTTP): login, sessão, persistência, módulos, chat com IA e histórico.
//
// Uso no servidor (a senha é lida do ambiente e nunca é gravada em arquivo):
//   MA_EMAIL=voce@exemplo.com MA_SENHA='sua-senha' node deploy/scripts/validar-funcional.mjs
//   (ou dentro do contêiner:  docker compose exec -T -e MA_EMAIL -e MA_SENHA app node - < deploy/scripts/validar-funcional.mjs)
// Variáveis opcionais: MA_URL (padrão http://127.0.0.1:3000), MA_CODIGO (código do autenticador, se a conta usa 2 fatores),
//   MA_LIMPAR=1 (apaga ao final SOMENTE a conversa de teste criada por este script).
// Dados criados: 1 conversa de teste com 1 pergunta ("Teste de validação do sistema…") e 1 resposta.
import { randomUUID } from 'node:crypto'

const URL_BASE = (process.env.MA_URL || 'http://127.0.0.1:3000').replace(/\/$/, '')
const EMAIL = process.env.MA_EMAIL || '', SENHA = process.env.MA_SENHA || '', CODIGO = process.env.MA_CODIGO || ''
let ok = 0, falhas = 0
const js = (v) => String(JSON.stringify(v) ?? v) // texto curto para o detalhe da falha (aceita undefined)
const encerrar = () => { console.log(`\nResultado: ${ok} OK, ${falhas} falha(s)`); process.exit(falhas ? 1 : 0) }
const passo = (nome, cond, detalhe = '') => { if (cond) { ok++; console.log(`  OK    ${nome}`) } else { falhas++; console.log(`  FALHA ${nome}${detalhe ? ' — ' + String(detalhe).slice(0, 300) : ''}`) } return cond }
class Cliente {
  jar = new Map()
  async req(metodo, caminho, corpo) {
    const r = await fetch(URL_BASE + caminho, { method: metodo, headers: { ...(corpo !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: corpo !== undefined ? js(corpo) : undefined })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), v = kv.slice(i + 1); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const texto = await r.text(); let body = texto; try { body = JSON.parse(texto) } catch { /* não é JSON */ }
    return { status: r.status, body }
  }
}

console.log(`Validação funcional em ${URL_BASE}`)
if (!EMAIL || !SENHA) { console.log('Defina MA_EMAIL e MA_SENHA (conta real para o teste).'); process.exit(2) }

// 1) backend e banco
const anon = new Cliente()
const h = await anon.req('GET', '/api/health')
passo('Backend responde e o banco é o PostgreSQL (/api/health)', h.status === 200 && h.body?.ok === true && h.body?.db === 'postgres', js(h.body))
const sem = await anon.req('GET', '/api/me')
passo('Rota protegida recusa quem não entrou (401 auth_required)', sem.status === 401 && sem.body?.code === 'auth_required', js(sem.body))

// 2) login e autenticação
const c = new Cliente()
const login = await c.req('POST', '/api/auth', { action: 'login', email: EMAIL, password: SENHA, ...(CODIGO ? { code: CODIGO } : {}) })
if (login.body?.code === 'mfa_required') { console.log('  A conta usa autenticação em 2 fatores: rode de novo com MA_CODIGO=<código do aplicativo>.'); process.exit(2) }
if (!passo('Login com a conta real', login.status === 200 && c.jar.size > 0, `${login.status} ${js(login.body)}`)) { console.log('  Sem login não há como validar o restante (confira e-mail/senha).'); encerrar() }
const me = await c.req('GET', '/api/me')
const perfil = me.body?.profile
passo('Sessão válida: /api/me devolve o perfil da conta que entrou', me.status === 200 && String(perfil?.email || '').toLowerCase() === EMAIL.toLowerCase(), js(me.body).slice(0, 200))

// 3) persistência da sessão (novo cliente só com o cookie, como ao recarregar a página)
const c2 = new Cliente(); c2.jar = new Map(c.jar)
await new Promise((r) => setTimeout(r, 1500))
const me2 = await c2.req('GET', '/api/me')
passo('Sessão persiste ao reabrir (mesmo cookie, mesma conta)', me2.status === 200 && me2.body?.profile?.id === perfil?.id, js(me2.body).slice(0, 200))

// 4) módulos e funcionalidades autorizadas (200 com o formato esperado, ou 403 de módulo desligado pelo administrador)
const feat = me.body?.plan?.features
passo('Módulos/recursos do plano carregados (/api/me.plan.features)', Array.isArray(feat) && feat.length > 0, js(me.body?.plan))
for (const [rota, chave] of [['/api/agenda', 'today'], ['/api/finance', 'entries'], ['/api/notifications', null], ['/api/v2/me/menu-pins', null], ['/api/conversations', 'conversations']]) {
  const r = await c.req('GET', rota)
  const desligado = r.status === 403 && /module|modulo|desativ/i.test(js(r.body))
  passo(`Acesso autorizado: ${rota}${desligado ? ' (módulo desligado pelo administrador)' : ''}`, desligado || (r.status === 200 && typeof r.body === 'object' && (!chave || chave in r.body)), `${r.status} ${js(r.body).slice(0, 200)}`)
}

// 5) chat: envio, resposta da IA e histórico
const conv = randomUUID(), pergunta = 'Teste de validação do sistema (pode ignorar). Responda apenas: OK.'
const t0 = Date.now()
const env = await c.req('POST', '/api/chat', { text: pergunta, conversationId: conv })
const resp = env.body?.assistantMessage
passo('Chat: mensagem enviada e gravada', env.status === 200 && env.body?.userMessage?.role === 'user' && env.body?.userMessage?.content === pergunta && env.body?.conversation?.id === conv, `${env.status} ${js(env.body).slice(0, 300)}`)
passo(`Chat: resposta da IA recebida (${Date.now() - t0} ms)`, resp?.role === 'assistant' && typeof resp?.content === 'string' && resp.content.trim().length > 0, js(resp).slice(0, 300))
if (resp?.content && /^Desculpe, a resposta está demorando/.test(resp.content)) passo('Chat: a IA respondeu dentro do prazo (não caiu na resposta de contingência)', false, resp.content)
const hist = await c2.req('GET', '/api/chat?c=' + conv)
const msgs = hist.body?.messages || []
passo('Histórico: a conversa reaberta traz a pergunta e a resposta, na ordem', hist.status === 200 && msgs.length >= 2 && msgs[0].role === 'user' && msgs[0].content === pergunta && msgs.some((m) => m.role === 'assistant' && m.id === resp?.id), js(hist.body).slice(0, 300))
const lista = await c2.req('GET', '/api/conversations')
passo('Histórico: a conversa aparece na lista de conversas', (lista.body?.conversations || []).some((x) => x.id === conv), js(lista.body).slice(0, 200))
const busca = await c2.req('GET', '/api/conversations?q=' + encodeURIComponent('Teste de validação'))
passo('Histórico: a busca encontra a conversa pelo conteúdo', (busca.body?.conversations || []).some((x) => x.id === conv), js(busca.body).slice(0, 200))

if (process.env.MA_LIMPAR === '1') { const d = await c.req('DELETE', '/api/conversations/' + conv); passo('Limpeza: conversa de teste apagada (só ela)', d.status === 200, js(d.body)) }
else console.log(`  (a conversa de teste ${conv} foi mantida; use MA_LIMPAR=1 para apagá-la automaticamente)`)

// 6) saída
const out = await c.req('POST', '/api/auth', { action: 'logout' })
const depois = await c.req('GET', '/api/me')
passo('Logout encerra a sessão', out.status === 200 && depois.status === 401, `${out.status}/${depois.status}`)

encerrar()
