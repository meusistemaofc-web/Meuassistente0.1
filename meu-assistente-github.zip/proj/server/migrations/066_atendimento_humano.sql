-- Atendimento humano (suporte) entre quem conversa com o AGENTE de uma empresa e a própria empresa.
-- Somente ADITIVA: nenhuma tabela ou coluna existente é alterada ou apagada. (Os chamados da Central de Ajuda — "tickets" —
-- continuam sendo usuário ↔ equipe da plataforma; estes são cliente ↔ empresa, isolados por business_id.)
--  • atendimentos: um chamado por pedido de atendimento. Quem abriu é um usuário logado (user_id) ou um visitante, que
--    recebe uma chave secreta só uma vez (guardamos apenas o SHA-256 dela em guest_hash).
--  • atendimento_mensagens: histórico completo (cliente, empresa e avisos do sistema como mudança de status).
--  • atendimento_anexos: imagens, PDF e documentos validados pelo conteúdo, servidos só por rotas autorizadas.
-- Reversão manual: DROP TABLE atendimento_anexos; DROP TABLE atendimento_mensagens; DROP TABLE atendimentos;
--                  DELETE FROM schema_migrations WHERE version = '066_atendimento_humano.sql';
CREATE TABLE IF NOT EXISTS atendimentos (
  id               BIGSERIAL PRIMARY KEY,
  protocolo        TEXT NOT NULL UNIQUE,
  business_id      BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id          BIGINT REFERENCES users(id) ON DELETE SET NULL,
  guest_hash       TEXT,
  nome             TEXT NOT NULL DEFAULT '',
  contato          TEXT NOT NULL DEFAULT '',
  motivo           TEXT NOT NULL DEFAULT '',
  status           TEXT NOT NULL DEFAULT 'aberto',      -- aberto | em_atendimento | atendido | encerrado
  empresa_nao_lidas INTEGER NOT NULL DEFAULT 0,
  cliente_nao_lidas INTEGER NOT NULL DEFAULT 0,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS atendimentos_biz ON atendimentos (business_id, updated_at);
CREATE INDEX IF NOT EXISTS atendimentos_user ON atendimentos (user_id, updated_at);
CREATE TABLE IF NOT EXISTS atendimento_mensagens (
  id             BIGSERIAL PRIMARY KEY,
  atendimento_id BIGINT NOT NULL REFERENCES atendimentos(id) ON DELETE CASCADE,
  autor          TEXT NOT NULL,                         -- cliente | empresa | sistema
  user_id        BIGINT,
  texto          TEXT NOT NULL DEFAULT '',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS atendimento_mensagens_a ON atendimento_mensagens (atendimento_id, id);
CREATE TABLE IF NOT EXISTS atendimento_anexos (
  id             BIGSERIAL PRIMARY KEY,
  mensagem_id    BIGINT NOT NULL REFERENCES atendimento_mensagens(id) ON DELETE CASCADE,
  atendimento_id BIGINT NOT NULL REFERENCES atendimentos(id) ON DELETE CASCADE,
  mime           TEXT NOT NULL,
  nome           TEXT NOT NULL DEFAULT 'arquivo',
  data           TEXT NOT NULL,                         -- base64 do arquivo validado
  tamanho        INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS atendimento_anexos_a ON atendimento_anexos (atendimento_id);
