-- Mercado de MCoins: cotação, histórico de preços e negociação POR MOEDA, habilitados individualmente pelo administrador.
-- Somente ADITIVA: moedas, carteiras (coin_balances), livro-razão (coin_ledger) e pedidos (coin_orders) continuam os mesmos;
-- nenhuma moeda existente vira negociável (sem linha em coin_markets = moeda só promocional, como antes).
--  • coin_markets: configuração de cada moeda (ligado, compras, vendas, pausa, liquidação, cotação, piso/teto e regras em JSON
--    validado no servidor) + "version" para atualização otimista da cotação (compras simultâneas nunca usam a mesma cotação);
--  • coin_prices: TODA mudança de cotação (abertura, compra, venda, ajuste do administrador), só inserção, encadeada por hash
--    (cada linha guarda o hash da anterior): qualquer alteração silenciosa do histórico é detectada na auditoria;
--  • coin_orders ganha "market" e a cotação antes/depois de cada negócio do mercado.
-- Reversão manual: DROP TABLE coin_markets; DROP TABLE coin_prices; (as colunas novas de coin_orders podem ficar: são opcionais)
--                  DELETE FROM schema_migrations WHERE version = '064_mcoins_mercado.sql';
CREATE TABLE IF NOT EXISTS coin_markets (
  coin_id        BIGINT PRIMARY KEY,
  enabled        BOOLEAN NOT NULL DEFAULT FALSE,
  buy_enabled    BOOLEAN NOT NULL DEFAULT FALSE,
  sell_enabled   BOOLEAN NOT NULL DEFAULT FALSE,
  paused         BOOLEAN NOT NULL DEFAULT FALSE,
  pause_reason   TEXT,
  settlement     TEXT NOT NULL DEFAULT 'manual',      -- manual (pagamento conferido pelo administrador) | simulada (sem pagamento)
  simulated_ack  BOOLEAN NOT NULL DEFAULT FALSE,      -- o administrador confirmou os efeitos do modo simulado
  price          NUMERIC(18,6) NOT NULL DEFAULT 0,
  initial_price  NUMERIC(18,6) NOT NULL DEFAULT 0,
  price_floor    NUMERIC(18,6) NOT NULL DEFAULT 0,
  price_ceiling  NUMERIC(18,6) NOT NULL DEFAULT 0,
  config         TEXT NOT NULL DEFAULT '{}',
  version        BIGINT NOT NULL DEFAULT 0,
  updated_by     BIGINT,
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS coin_prices (
  id          BIGSERIAL PRIMARY KEY,
  coin_id     BIGINT NOT NULL,
  price       NUMERIC(18,6) NOT NULL,
  prev_price  NUMERIC(18,6),
  reason      TEXT NOT NULL,                          -- abertura | compra | venda | ajuste
  order_id    BIGINT,
  qty         BIGINT,
  volume      NUMERIC(14,2),
  actor       TEXT,
  prev_hash   TEXT,
  hash        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS coin_prices_coin ON coin_prices (coin_id, id);
CREATE UNIQUE INDEX IF NOT EXISTS coin_prices_order ON coin_prices (order_id);
ALTER TABLE coin_orders ADD COLUMN market BOOLEAN;
ALTER TABLE coin_orders ADD COLUMN price_before NUMERIC(18,6);
ALTER TABLE coin_orders ADD COLUMN price_after NUMERIC(18,6);
CREATE INDEX IF NOT EXISTS coin_orders_coin ON coin_orders (coin_id, id);
