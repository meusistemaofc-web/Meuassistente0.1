-- Vinculação e troca rápida de empresas entre contas (estilo "trocar de conta"): o proprietário autenticado vincula à sua
-- sessão uma empresa de OUTRA conta Meu Assistente, depois de provar que tem acesso a ela (e-mail e senha, e 2FA se houver).
-- Somente ADITIVA: duas tabelas novas; nenhuma tabela existente é alterada. Nenhuma senha, token ou segredo é guardado aqui.
--  • empresa_vinculos: quem (user_id) pode operar qual empresa (business_id) de qual conta dona (owner_id). auth_stamp é uma
--    impressão da senha atual da conta dona (hash do hash): se a senha dela mudar, o vínculo é suspenso até ser refeito.
--    Apagar o vínculo NUNCA apaga a empresa, a conta dona ou os dados.
--  • empresa_contexto: última empresa escolhida por usuário (persiste após sair e entrar).
-- Reversão manual: DROP TABLE empresa_contexto; DROP TABLE empresa_vinculos; DELETE FROM schema_migrations WHERE version = '060_empresas_vinculadas.sql';
CREATE TABLE IF NOT EXISTS empresa_vinculos (
  id           BIGSERIAL PRIMARY KEY,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id  BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  auth_stamp   TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_used_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS empresa_vinculos_uq ON empresa_vinculos (user_id, business_id);
CREATE INDEX IF NOT EXISTS empresa_vinculos_biz ON empresa_vinculos (business_id);
CREATE TABLE IF NOT EXISTS empresa_contexto (
  user_id     BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  business_id BIGINT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
