-- Pesquisa na web multimotor (SearXNG, Tavily, Exa, Brave + Wikipédia e Google já existentes).
-- Somente ADITIVA: duas tabelas novas; nada existente é alterado ou apagado.
--  • brain_motor_estado: um registro por mecanismo (prioridade, limite diário, saúde: último erro, pausa automática, créditos)
--  • brain_motor_uso: consumo por mecanismo e por dia (buscas, erros, sem resultado, cache, latência)
-- Nenhuma chave de API é guardada aqui (as chaves ficam cifradas em brain_provider_configs ou em variáveis de ambiente).
-- Reversão manual: DROP TABLE brain_motor_uso; DROP TABLE brain_motor_estado; DELETE FROM schema_migrations WHERE version = '059_cerebro_motores.sql';
CREATE TABLE IF NOT EXISTS brain_motor_estado (
  provider         TEXT PRIMARY KEY,
  prioridade       INTEGER,
  limite_dia       INTEGER,
  falhas_seguidas  INTEGER NOT NULL DEFAULT 0,
  pausado_ate      TIMESTAMPTZ,
  ultimo_erro      TEXT,
  ultimo_erro_em   TIMESTAMPTZ,
  ultimo_ok_em     TIMESTAMPTZ,
  consumo_info     TEXT,
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS brain_motor_uso (
  provider      TEXT NOT NULL,
  dia           TEXT NOT NULL,
  buscas        INTEGER NOT NULL DEFAULT 0,
  erros         INTEGER NOT NULL DEFAULT 0,
  vazias        INTEGER NOT NULL DEFAULT 0,
  cache         INTEGER NOT NULL DEFAULT 0,
  ms_total      BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY (provider, dia)
);
