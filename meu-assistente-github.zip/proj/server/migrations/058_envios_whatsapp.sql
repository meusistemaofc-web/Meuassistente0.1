-- Envio automático dos novos pedidos para o WhatsApp da empresa (lib/whatsapp-envio.ts).
-- SOMENTE ADITIVA: cria uma tabela nova; nenhum dado existente é alterado.
-- Uma linha por pedido e tipo de envio (UNIQUE): o mesmo pedido nunca é enviado duas vezes, mesmo que o aviso seja
-- chamado de novo (pagamento confirmado duas vezes, reinício no meio do envio). A linha guarda o andamento do envio
-- (pendente → enviando → enviado | falhou | incerto), as tentativas e o identificador da mensagem no provedor.
-- O envio nunca altera o status do pedido.
-- Reversão manual: DROP TABLE envios_whatsapp; DELETE FROM schema_migrations WHERE version = '058_envios_whatsapp.sql';
CREATE TABLE IF NOT EXISTS envios_whatsapp (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  order_id      BIGINT NOT NULL,
  tipo          TEXT NOT NULL DEFAULT 'novo_pedido',
  destino       TEXT NOT NULL DEFAULT '',
  texto         TEXT NOT NULL DEFAULT '',
  status        TEXT NOT NULL DEFAULT 'pendente',
  tentativas    INTEGER NOT NULL DEFAULT 0,
  proxima_em    TIMESTAMPTZ,
  provedor      TEXT NOT NULL DEFAULT '',
  msg_id        TEXT NOT NULL DEFAULT '',
  erro          TEXT NOT NULL DEFAULT '',
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (order_id, tipo)
);
CREATE INDEX IF NOT EXISTS envios_whatsapp_status_idx ON envios_whatsapp (status, proxima_em);
CREATE INDEX IF NOT EXISTS envios_whatsapp_biz_idx ON envios_whatsapp (business_id, id);
