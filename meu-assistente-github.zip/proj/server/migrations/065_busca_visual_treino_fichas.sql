-- Busca visual de produtos (modo "Busca de produtos e serviços") e fichas visuais do "Treino e Acompanhamento".
-- Somente ADITIVA: nenhuma tabela ou coluna existente é alterada ou apagada.
--  • busca_visual: cada busca feita a partir de uma imagem — a descrição estruturada que a análise produziu (nunca a
--    imagem em si), as instruções entendidas, os resultados VERIFICADOS (nome, preço, loja, link, disponibilidade só quando
--    lidos da página do produto) e o que foi consultado. É o que o card do chat (⟦bv:id⟧) mostra, sempre do próprio dono.
--  • treino_exercicio_registros: o que a pessoa marcou em cada exercício num dia (concluído, carga, repetições feitas),
--    base do progresso diário/semanal e da evolução de carga por exercício. Um registro por pessoa, dia e exercício.
--  • treino_sessoes ganha "origem" (ficha = criada ao marcar exercícios na ficha; vazio = registrada pelo chat), para a
--    ficha só desfazer o que ela mesma criou.
-- Reversão manual: DROP TABLE busca_visual; DROP TABLE treino_exercicio_registros; (a coluna origem pode ficar: é opcional)
--                  DELETE FROM schema_migrations WHERE version = '065_busca_visual_treino_fichas.sql';
CREATE TABLE IF NOT EXISTS busca_visual (
  id              BIGSERIAL PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  conversation_id TEXT,
  analise         TEXT NOT NULL DEFAULT '{}',           -- descrição estruturada (produto, categoria, marca, modelo, cor, textos, códigos…)
  instrucao       TEXT NOT NULL DEFAULT '{}',           -- o que a pessoa pediu junto da imagem (exato, mais barato, semelhantes…)
  resultados      TEXT NOT NULL DEFAULT '[]',           -- resultados da internet já conferidos e ordenados
  parceiros       TEXT,                                 -- itens das lojas parceiras (ids do card ⟦bp⟧)
  status          TEXT NOT NULL DEFAULT 'concluida',    -- concluida | sem_resultados | falhou
  fontes          TEXT NOT NULL DEFAULT '{}',           -- o que foi usado (análise, pesquisa, páginas lidas) — sem chaves nem dados pessoais
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS busca_visual_user ON busca_visual (user_id, id);
CREATE TABLE IF NOT EXISTS treino_exercicio_registros (
  id             BIGSERIAL PRIMARY KEY,
  user_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plano_id       BIGINT REFERENCES treino_planos(id) ON DELETE SET NULL,
  data           TEXT NOT NULL,                         -- AAAA-MM-DD no fuso da pessoa
  dia_plano      INTEGER,                               -- 0=domingo … 6=sábado
  chave          TEXT NOT NULL,                         -- nome normalizado do exercício (une a evolução entre versões do plano)
  nome           TEXT NOT NULL,
  concluido      INTEGER NOT NULL DEFAULT 0,            -- 0/1
  carga_kg       NUMERIC(7,2),
  reps           TEXT,
  atualizado_em  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  criado_em      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS treino_ex_reg_dia ON treino_exercicio_registros (user_id, data, chave);
CREATE INDEX IF NOT EXISTS treino_ex_reg_chave ON treino_exercicio_registros (user_id, chave, data);
ALTER TABLE treino_sessoes ADD COLUMN origem TEXT;
