-- Mercado Pago: confirmação de pagamento processada UMA vez por pedido, mesmo com notificações repetidas, simultâneas ou
-- vindas do webhook e da consulta do cliente ao mesmo tempo. Quem insere a linha primeiro processa; os demais ignoram.
-- Se o processamento falhar no meio, a linha é removida e a próxima notificação (ou consulta) processa de novo.
-- Só ACRESCENTA uma tabela: nada existente é alterado. Não guarda tokens nem dados do pagador.
-- Reversão manual: DROP TABLE mp_pagamentos_processados; DELETE FROM schema_migrations WHERE version = '061_mp_pagamentos_processados.sql';
CREATE TABLE IF NOT EXISTS mp_pagamentos_processados (
  business_id   BIGINT NOT NULL,
  order_id      BIGINT NOT NULL,
  payment_id    TEXT NOT NULL,
  evento        TEXT NOT NULL,
  processado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (order_id, evento)
);
CREATE INDEX IF NOT EXISTS mp_pagamentos_processados_pay ON mp_pagamentos_processados (business_id, payment_id);
