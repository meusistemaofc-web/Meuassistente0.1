-- Aprendizado coletivo evolutivo (camada coletiva do Cérebro Central).
-- Somente ADITIVA: nenhuma tabela ou coluna existente é alterada ou apagada.
--  • collective_signals: experiências elegíveis já ABSTRAÍDAS (modelo da frase sem nomes, números, datas, valores ou
--    palavras fora do vocabulário comum + intenção confirmada). Nunca o texto da conversa. Ligadas ao usuário só para
--    apagar junto com a conta (ON DELETE CASCADE) ou quando ele retira o consentimento; nunca aparecem no painel.
--    Retenção: 90 dias.
--  • collective_knowledge: conhecimento consolidado (sem nenhum vínculo com usuários): modelo representativo,
--    intenção, quantos usuários distintos, confiabilidade, contradições, estado e histórico (para reverter).
-- Reversão manual: DROP TABLE collective_knowledge; DROP TABLE collective_signals;
--                  DELETE FROM schema_migrations WHERE version = '067_aprendizado_coletivo.sql';
CREATE TABLE IF NOT EXISTS collective_signals (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT REFERENCES users(id) ON DELETE CASCADE,
  template    TEXT NOT NULL DEFAULT '',
  intent      TEXT NOT NULL DEFAULT '',
  kind        TEXT NOT NULL DEFAULT 'acerto',   -- acerto | correcao | corrigido_para | bloqueado
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS collective_signals_tpl ON collective_signals (template, intent);
CREATE INDEX IF NOT EXISTS collective_signals_em ON collective_signals (created_at);
CREATE INDEX IF NOT EXISTS collective_signals_user ON collective_signals (user_id);
CREATE TABLE IF NOT EXISTS collective_knowledge (
  id             BIGSERIAL PRIMARY KEY,
  template       TEXT NOT NULL,
  intent         TEXT NOT NULL,
  category       TEXT NOT NULL DEFAULT '',
  origin         TEXT NOT NULL DEFAULT 'acertos',  -- acertos | correcoes | misto
  members        TEXT NOT NULL DEFAULT '[]',       -- variações (modelos) do mesmo agrupamento
  users          INTEGER NOT NULL DEFAULT 0,
  support        INTEGER NOT NULL DEFAULT 0,
  negatives      INTEGER NOT NULL DEFAULT 0,
  contradictions TEXT NOT NULL DEFAULT '[]',
  reliability    REAL NOT NULL DEFAULT 0,
  state          TEXT NOT NULL DEFAULT 'pendente', -- pendente | ativo | suspenso | rejeitado | removido
  manual         BOOLEAN NOT NULL DEFAULT FALSE,
  version        INTEGER NOT NULL DEFAULT 1,
  uses           INTEGER NOT NULL DEFAULT 0,
  history        TEXT NOT NULL DEFAULT '[]',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS collective_knowledge_chave ON collective_knowledge (template, intent);
CREATE INDEX IF NOT EXISTS collective_knowledge_estado ON collective_knowledge (state);
