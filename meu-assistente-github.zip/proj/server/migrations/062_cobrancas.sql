-- Cobranças avulsas criadas pelo chat ("crie uma cobrança de R$ 10"): Pix real do Mercado Pago gerado com a conexão da
-- PRÓPRIA empresa (empresa_integracoes / tokenLoja). Somente ADITIVA: uma tabela nova; nada existente é alterado.
-- Não guarda tokens nem dados do pagador (só o nome que o dono digitou, opcional).
--  • status: criando → pendente → pago | cancelado | recusado | expirado (ou falhou, quando o Mercado Pago não gerou o Pix).
--    "pago" só vem da consulta à API do Mercado Pago (webhook conferido ou consulta de status), nunca do aplicativo;
--  • idem_key: a mesma mensagem do chat (id do envio) nunca cria duas cobranças;
--  • link_token: link público da cobrança (QR Code e Copia e Cola para o cliente), aleatório e sem dados no endereço.
-- Reversão manual: DROP TABLE cobrancas; DELETE FROM schema_migrations WHERE version = '062_cobrancas.sql';
CREATE TABLE IF NOT EXISTS cobrancas (
  id             BIGSERIAL PRIMARY KEY,
  business_id    BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  created_by     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  valor          NUMERIC(12,2) NOT NULL,
  descricao      TEXT NOT NULL DEFAULT '',
  cliente        TEXT NOT NULL DEFAULT '',
  vencimento     TIMESTAMPTZ,
  expira_em      TIMESTAMPTZ,
  status         TEXT NOT NULL DEFAULT 'criando',
  mp_payment_id  TEXT,
  mp_status      TEXT,
  qr             TEXT NOT NULL DEFAULT '',
  qr_image       TEXT NOT NULL DEFAULT '',
  ticket_url     TEXT NOT NULL DEFAULT '',
  teste          BOOLEAN NOT NULL DEFAULT FALSE,
  link_token     TEXT NOT NULL,
  idem_key       TEXT NOT NULL,
  erro           TEXT NOT NULL DEFAULT '',
  pago_em        TIMESTAMPTZ,
  conferido_em   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS cobrancas_idem ON cobrancas (idem_key);
CREATE UNIQUE INDEX IF NOT EXISTS cobrancas_link ON cobrancas (link_token);
CREATE INDEX IF NOT EXISTS cobrancas_biz ON cobrancas (business_id, created_at);
CREATE INDEX IF NOT EXISTS cobrancas_pay ON cobrancas (business_id, mp_payment_id);
