-- Página "Descobrir" (Empresas perto de você): banners rotativos e interesses de cada usuário para a vitrine personalizada.
-- Somente ADITIVA: nenhuma tabela ou coluna existente é alterada ou apagada. As opções exibidas (Empresas, Produtos e
-- Serviços) e as chaves da personalização ficam em app_config ("descobrir").
--  • descobrir_banners: banners do topo, com imagem própria (servida por rota com cache), período, ordem, duração e destino
--    (empresa, produto, serviço, categoria ou link). Quem criou/alterou fica na auditoria.
--  • user_interests: perfil de interesse INDIVIDUAL — um peso por chave (empresa, produto, serviço, categoria, termo de busca),
--    com decaimento pela recência. Nunca é lido para outro usuário; apagar a conta apaga junto (ON DELETE CASCADE).
-- Reversão manual: DROP TABLE user_interests; DROP TABLE descobrir_banners;
--                  DELETE FROM schema_migrations WHERE version = '068_descobrir_banners_interesses.sql';
CREATE TABLE IF NOT EXISTS descobrir_banners (
  id            BIGSERIAL PRIMARY KEY,
  titulo        TEXT NOT NULL DEFAULT '',
  descricao     TEXT NOT NULL DEFAULT '',
  imagem        TEXT NOT NULL DEFAULT '',
  botao         TEXT NOT NULL DEFAULT '',
  destino_tipo  TEXT NOT NULL DEFAULT 'nenhum',   -- nenhum | empresa | produto | servico | categoria | link
  destino_valor TEXT NOT NULL DEFAULT '',
  inicio        TIMESTAMPTZ,
  fim           TIMESTAMPTZ,
  ordem         INTEGER NOT NULL DEFAULT 0,
  duracao       INTEGER NOT NULL DEFAULT 6,          -- segundos na tela antes de passar para o próximo
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS descobrir_banners_ordem ON descobrir_banners (ativo, ordem);
CREATE TABLE IF NOT EXISTS user_interests (
  user_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chave    TEXT NOT NULL,                            -- e:<empresa> p:<produto> s:<serviço> c:<categoria> t:<termo>
  peso     REAL NOT NULL DEFAULT 0,
  n        INTEGER NOT NULL DEFAULT 0,
  ultimo   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, chave)
);
