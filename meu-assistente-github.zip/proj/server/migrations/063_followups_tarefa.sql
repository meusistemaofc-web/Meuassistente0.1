-- Acompanhamentos (followups) integrados ao módulo Tarefas: cada acompanhamento pendente tem UMA tarefa real (items, type
-- 'task') do dono da empresa, que aparece em Tarefas → Pendentes. Somente ADITIVA: uma coluna nova, sem alterar dados.
-- Reversão manual: ALTER TABLE followups DROP COLUMN task_id; DELETE FROM schema_migrations WHERE version = '063_followups_tarefa.sql';
ALTER TABLE followups ADD COLUMN task_id BIGINT;
CREATE INDEX IF NOT EXISTS followups_task ON followups (task_id);
