# IA falsa compatível com OpenAI (chat/completions): grava cada pedido recebido (mensagens completas) em /tmp/fake_ai_log.jsonl
# e responde com um texto conceitual fixo (sem citar nada do usuário). Serve para ver EXATAMENTE o que o app manda à IA.
import json, sys, time, os
from http.server import BaseHTTPRequestHandler, HTTPServer
LOG = '/tmp/fake_ai_log.jsonl'
RESP = {'conceito': 'Memória guarda informações da conversa e dados salvos; conhecimento são os fatos disponíveis; raciocínio combina essas informações para responder; aprendizado (treinamento) ajusta os parâmetros do modelo antes do uso.',
        'gravidade': 'A gravidade é a atração entre massas; na relatividade geral, é a curvatura do espaço-tempo causada pela massa e energia.'}
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); b = json.loads(self.rfile.read(n) or b'{}')
        time.sleep(float(os.environ.get('FAKE_DELAY', '0')))  # latência de um provedor real (por chamada)
        with open(LOG, 'a') as f: f.write(json.dumps({'t': time.time(), 'path': self.path, 'stream': bool(b.get('stream')), 'messages': b.get('messages'), 'tools': [t.get('function', {}).get('name') for t in (b.get('tools') or [])]}, ensure_ascii=False) + '\n')
        ult = next((m.get('content') for m in reversed(b.get('messages') or []) if m.get('role') == 'user'), '') or ''
        txt = RESP['gravidade'] if 'gravidade' in str(ult).lower() else RESP['conceito']
        out = {'id': 'x', 'object': 'chat.completion', 'model': 'fake', 'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': txt}, 'finish_reason': 'stop'}], 'usage': {'prompt_tokens': 1, 'completion_tokens': 1}}
        if b.get('stream'):
            self.send_response(200); self.send_header('Content-Type', 'text/event-stream'); self.end_headers()
            self.wfile.write(('data: ' + json.dumps({'choices': [{'index': 0, 'delta': {'role': 'assistant', 'content': txt}}]}) + '\n\ndata: [DONE]\n\n').encode()); return
        d = json.dumps(out).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(d))); self.end_headers(); self.wfile.write(d)
    def do_GET(self):
        d = json.dumps({'data': [{'id': 'fake'}]}).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(d)
HTTPServer(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
