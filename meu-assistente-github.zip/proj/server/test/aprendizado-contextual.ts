// APRENDIZADO CONTEXTUAL — pelo USO REAL (padrões das ações) e por CONVERSA (perguntas curtas e oportunas), pelo app real
// (POST /api/chat, rotas reais, banco real; dublês de IA e de internet). Tempo simulado mudando as datas dos registros.
//   A. reconhecimento de padrões: 2 ocorrências = indício; confiança cresce; recência; hábito × recorrente × pontual;
//      padrões antigos perdem relevância; mudança de comportamento; títulos genéricos não viram padrão.
//   B. uso nas conversas: "agendar um serviço" ambíguo → pergunta com o que a pessoa costuma agendar (nada é criado antes da
//      resposta); vários serviços; "outro"; IA recebe só os padrões do domínio, como hipótese; pergunta conceitual sem padrões.
//   C. descoberta: usuário novo × parcial × consolidado; pergunta antes (pedido continua) e depois (ação já feita);
//      não repete, não empilha, respeita o ritmo; aprende das respostas e das ações; inferível não é perguntado.
//   D. persistência, isolamento entre usuários, chave de privacidade, painel (fila de revisão sem padrões).
// Uso: npm run test:aprendizado-contextual
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
process.env.SONDA_FERRAMENTAS = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, one, J, nowIso } = await import('../src/db/index.js')
const AU = await import('../src/ai/aprendizado-uso.js')
const DS = await import('../src/ai/descoberta.js')
const { localDate, addDays } = await import('../src/lib/time.js')
const HOJE = localDate('America/Sao_Paulo')

let ok = 0, falhas = 0
const erros: string[] = []
function check(cond: unknown, msg: string, det?: unknown) { if (cond) { ok++; console.log('    ✓', msg) } else { falhas++; erros.push(msg); console.log('    ✗', msg, det === undefined ? '' : '→ ' + JSON.stringify(det).slice(0, 400)) } }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
let nIp = 0; const fetch0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? fetch0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.6.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : fetch0(u, o)) as any
const DIA = 86400000, atras = (d: number) => new Date(Date.now() - d * DIA).toISOString()
class P {
  conv = crypto.randomUUID()
  constructor(public cli: InstanceType<typeof S.Cli>, public uid: number) {}
  async diga(f: string, conv = this.conv) {
    const i0 = S.chamadasIA.length
    const r = await this.cli.call('POST', '/api/chat', { text: f, conversationId: conv }); await sleep(120)
    const t = String(r.body?.assistantMessage?.content ?? '').replace(/⟦[^⟧]*⟧/g, '').trim()
    console.log(`  👤 ${f}\n  🤖 ${t.replace(/\n+/g, ' ⏎ ').slice(0, 220)}`)
    return { t, sys: S.chamadasIA.slice(i0).map((c) => c.system).join('\n') }
  }
  novaConversa() { this.conv = crypto.randomUUID() }
}
async function novo() { const cli = await S.novoUsuario(); const uid = Number((await q('SELECT id FROM users ORDER BY id DESC LIMIT 1'))[0].id); return new P(cli, uid) }
const appts = async (uid: number) => (await q("SELECT id, day, data FROM items WHERE user_id = $1 AND type = 'appointment' ORDER BY id", [uid])).map((r: any) => ({ ...r, d: J<any>(r.data, {}) }))
/** registro "real" com data de criação no passado (simula semanas de uso) */
async function semear(uid: number, type: string, data: any, diasAtras: number, day: string | null = null) {
  const em = atras(diasAtras); await q('INSERT INTO items (user_id, type, status, day, due_at, data, created_at, updated_at) VALUES ($1,$2,$3,$4,NULL,$5,$6,$6)', [uid, type, type === 'appointment' ? 'scheduled' : type === 'expense' ? 'done' : 'pending', day, JSON.stringify(data), em]); AU.marcarSujo(uid)
}
const padroesDe = async (uid: number) => (await q("SELECT context, rule, confidence, frequency, state, preference FROM learnings WHERE user_id = $1 AND kind = 'padrao_uso' ORDER BY confidence DESC", [uid])).map((r: any) => ({ ...r, p: J<any>(r.preference, {}) }))
/** "passa um dia" para o ritmo das perguntas de descoberta */
async function passarDias(uid: number, dias: number) {
  for (const r of await q("SELECT id, preference FROM learnings WHERE user_id = $1 AND kind = 'descoberta'", [uid]) as any[]) { const p = J<any>(r.preference, {}); if (p.perguntadoEm) p.perguntadoEm = new Date(new Date(p.perguntadoEm).getTime() - dias * DIA).toISOString(); await q('UPDATE learnings SET preference = $1 WHERE id = $2', [JSON.stringify(p), r.id]) }
}
const oc = (dom: any, chave: string, dias: number, dia: string | null = null) => ({ dom, chave, rotulo: chave.charAt(0).toUpperCase() + chave.slice(1), em: atras(dias), dia })

console.log('\n# A. Reconhecimento progressivo de padrões (cálculo)')
{ const n = (k: number, d = 1) => AU.analisar(Array.from({ length: k }, (_, i) => oc('servico_agenda', 'tatuagem', d + i)))[0]
  const p1 = n(1), p2 = n(2), p3 = n(3), p5 = n(5)
  check(p1.nivel === 'pontual', '1 ocorrência = evento pontual (não é padrão)', p1)
  check(p2.nivel === 'indicio' && p2.confianca >= 0.6 && p2.confianca < 0.75, `2 ocorrências = indício (confiança ${p2.confianca})`)
  check(p3.confianca > p2.confianca && p3.nivel === 'recorrente', `3 ocorrências = recorrente (confiança sobe para ${p3.confianca})`)
  check(p5.confianca > p3.confianca && p5.confianca <= 0.95, `5 ocorrências: confiança ${p5.confianca}, nunca 100%`)
  const velho = AU.analisar([oc('servico_agenda', 'tatuagem', 200), oc('servico_agenda', 'tatuagem', 210), oc('servico_agenda', 'tatuagem', 220)])[0]
  check(velho.nivel === 'antigo' && velho.confianca < 0.35, `3 ocorrências há 200+ dias perdem relevância (confiança ${velho.confianca})`)
  const qua = (s: number) => { const d = new Date(); d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() - 3 + 7) % 7) - 7 * s); return d.toISOString().slice(0, 10) }
  const hab = AU.analisar([0, 1, 2, 3].map((s) => oc('servico_agenda', 'pilates', 7 * s + 1, qua(s))))[0]
  check(hab.nivel === 'habito' && /quartas/.test(hab.regra), 'mesmo dia da semana em 4 semanas = hábito ("às quartas")', hab)
  const mesmoDia = AU.analisar([oc('servico_agenda', 'pilates', 1, qua(0)), oc('servico_agenda', 'pilates', 1, qua(0)), oc('servico_agenda', 'pilates', 1, qua(0))])[0]
  check(mesmoDia.nivel !== 'habito', '3 pedidos no mesmo dia não são hábito (falta tempo de observação)', mesmoDia.nivel)
  const mud = AU.analisar([...[150, 160, 170, 180, 190].map((d) => oc('servico_agenda', 'tatuagem', d)), ...[1, 3, 5].map((d) => oc('servico_agenda', 'barba', d))])
  check(mud[0].chave === 'barba' && mud.find((p) => p.chave === 'tatuagem')!.confianca < mud[0].confianca, 'mudança de comportamento: o novo (3 recentes) supera o antigo (5 há meses)', mud.map((p) => [p.chave, p.confianca, p.nivel]))
  check(AU.chaveDe('Reunião com João') === AU.chaveDe('Reunião com Ana') && AU.chaveDe('Serviço') === null && AU.chaveDe('Compromisso') === null, 'a pessoa não muda o tipo ("Reunião com João" = "Reunião com Ana"); títulos genéricos não viram padrão')
}

console.log('\n# B. Uso nas conversas: agendamento ambíguo')
const A = await novo()
{ await A.diga('agende uma tatuagem com o Pedro amanhã às 14h'); await A.diga('agende uma tatuagem com a Carla sexta às 10h')
  await AU.atualizar({ id: A.uid }) // recálculo sob demanda (as ações marcaram o usuário)
  let pd = await padroesDe(A.uid)
  check(pd.length === 1 && pd[0].context === 'servico_agenda:tatuagem' && pd[0].p.nivel === 'indicio' && pd[0].state === 'ativo', 'duas tatuagens pelo chat: indício gravado (learnings, padrao_uso)', pd)
  const n0 = (await appts(A.uid)).length; A.novaConversa()
  let r = await A.diga('Quero agendar um serviço para amanhã às 9h')
  check(/tatuagens/.test(r.t) && /também será uma tatuagem ou é outro serviço\?/.test(r.t) && (await appts(A.uid)).length === n0, 'pergunta com o que costuma agendar — e NADA é criado antes da resposta', r.t)
  check(/Nos seus últimos agendamentos/.test(r.t), 'com só um indício, fala como observação (não afirma "você costuma")')
  r = await A.diga('sim'); let ap = await appts(A.uid)
  check(ap.length === n0 + 1 && ap[ap.length - 1].d.title === 'Tatuagem' && ap[ap.length - 1].day === addDays(HOJE, 1) && ap[ap.length - 1].d.time === '09:00', '"sim" cria a tatuagem com a data e o horário pedidos', ap[ap.length - 1])
  pd = await padroesDe(A.uid); await AU.atualizar({ id: A.uid }, { forcar: true }); pd = await padroesDe(A.uid)
  check(pd[0].frequency === 3 && pd[0].p.nivel === 'recorrente' && Number(pd[0].confidence) >= 0.75, `confiança evolui com a nova ocorrência (3 → ${pd[0].confidence}, recorrente)`, pd[0])
  A.novaConversa(); r = await A.diga('quero agendar um horário dia 10 às 15h')
  check(/^Você costuma agendar tatuagens/.test(r.t), 'com confiança alta: "Você costuma agendar tatuagens…"', r.t)
  r = await A.diga('não, é um retoque'); ap = await appts(A.uid)
  check(ap[ap.length - 1].d.title === 'Retoque', '"não, é um retoque" → cria Retoque (o padrão não é imposto)')
  A.novaConversa(); await A.diga('quero agendar um serviço amanhã às 11h'); r = await A.diga('outro')
  check(/Qual serviço/.test(r.t), '"outro" sem dizer qual → pergunta só o serviço'); r = await A.diga('barba'); ap = await appts(A.uid)
  check(ap[ap.length - 1].d.title === 'Barba' && ap[ap.length - 1].d.time === '11:00', 'e cria o serviço dito, com os dados de antes')
  A.novaConversa(); r = await A.diga('agende uma tatuagem com o Leo amanhã às 18h')
  check(/Agendei "Tatuagem"/.test(r.t) && !/costuma/.test(r.t), 'pedido completo não é interrompido (o padrão só ajuda quando falta o serviço)')
}
{ console.log('\n## vários serviços recorrentes')
  const B = await novo()
  for (const [t, d] of [['Tatuagem', 3], ['Tatuagem', 6], ['Piercing', 2], ['Piercing', 5]] as const) await semear(B.uid, 'appointment', { title: t, time: '10:00' }, d, addDays(HOJE, -d))
  const r = await B.diga('preciso agendar um atendimento amanhã às 9h')
  check(/tatuagens e piercings|piercings e tatuagens/.test(r.t) && /um deles ou outro serviço/.test(r.t), 'dois serviços recorrentes: a pergunta traz os dois', r.t)
  await B.diga('vai ser piercing'); const ap = await appts(B.uid)
  check(ap[ap.length - 1].d.title === 'Piercing', 'a resposta escolhe entre eles')
  console.log('\n## padrões antigos perdem relevância, novos assumem')
  await q("UPDATE items SET created_at = $1 WHERE user_id = $2 AND type = 'appointment'", [atras(240), B.uid])
  for (const d of [1, 4]) await semear(B.uid, 'appointment', { title: 'Massagem', time: '15:00' }, d, addDays(HOJE, -d))
  await AU.atualizar({ id: B.uid }, { forcar: true })
  const pd = await padroesDe(B.uid), st = Object.fromEntries(pd.map((p: any) => [p.p.chave, p.state]))
  check(st.tatuagem === 'inativo' && st.piercing === 'inativo' && st.massagem === 'ativo', 'meses sem tatuagem/piercing: inativos; massagem nova: ativa', st)
  const hist = J<any[]>((await one("SELECT history FROM learnings WHERE user_id = $1 AND context = 'servico_agenda:tatuagem'", [B.uid]))?.history, [])
  check(hist.some((h) => h.acao === 'nivel' && h.para === 'antigo'), 'a mudança fica no histórico do padrão (nada é apagado)')
  B.novaConversa(); const r2 = await B.diga('quero agendar um serviço amanhã às 9h')
  check(/massagens/.test(r2.t) && !/tatuag|piercing/.test(r2.t), 'a pergunta agora usa o padrão atual (contexto antigo não domina)', r2.t)
}
{ console.log('\n## sem padrão: sem conclusão indevida')
  const C = await novo(); await semear(C.uid, 'appointment', { title: 'Tatuagem', time: '10:00' }, 2, addDays(HOJE, -2)) // 1 só
  const r = await C.diga('quero agendar um serviço amanhã às 9h')
  check(!/costuma|últimos agendamentos|tatuag/i.test(r.t), 'uma ocorrência só não vira suposição', r.t)
  check(!(await padroesDe(C.uid)).length, 'nada gravado como padrão')
}
{ console.log('\n## orquestrador / IA: só o domínio do pedido, como hipótese')
  const AD = await import('../src/ai/adaptive.js'), uA = { id: A.uid, memory_settings: {} } as any
  const blocoAg = await AD.contextoIA(uA, 'me sugere como distribuir meus agendamentos na semana', A.conv)
  check(/Padrões observados no uso/.test(blocoAg) && /HIPÓTESES/.test(blocoAg) && /Agenda com frequência: Tatuagem/.test(blocoAg) && blocoAg.split('\n').filter((l) => l.startsWith('- [')).length <= 4, 'bloco do orquestrador: só padrões de agenda, rotulados como hipótese, no máximo 4', blocoAg)
  check(!/Agenda com frequência/.test(await AD.contextoIA(uA, 'gastei 30 reais no mercado', A.conv)), 'pedido de finanças: os padrões de agenda não entram (só o domínio do pedido)')
  A.novaConversa(); const r = await A.diga('me sugere como distribuir meus agendamentos na semana')
  check(!r.sys || (/Padrões observados no uso/.test(r.sys) && /HIPÓTESES/.test(r.sys)), 'quando o pedido vai para a IA, o bloco vai junto', r.sys.slice(0, 200))
  const r2 = await A.diga('o que é uma agenda?')
  check(!/Padrões observados/.test(r2.sys), 'pergunta conceitual: nenhum padrão pessoal no prompt')
  const r3 = await A.diga('me explica a fotossíntese')
  check(!/Padrões observados/.test(r3.sys) && !/Tatuagem/.test(r3.sys), 'assunto sem relação: nada do histórico de uso')
}

console.log('\n# C. Descoberta conversacional')
{ console.log('\n## usuário novo: pergunta antes (o pedido continua) e depois (a ação já foi feita)')
  const N = await novo()
  check((await DS.nivel({ id: N.uid } as any)).nivel === 'novo', 'nível: novo')
  let r = await N.diga('Quero organizar meus compromissos')
  check(r.t === 'Claro! São compromissos pessoais, de trabalho ou os dois?', 'pergunta curta, integrada ao pedido', r.t)
  r = await N.diga('de trabalho')
  check(/^Certo, compromissos de trabalho\./.test(r.t) && /compromisso/.test(r.t.slice(32)), 'a resposta é guardada e o pedido ORIGINAL continua na mesma resposta', r.t)
  const mem = await q("SELECT content, source FROM memories WHERE user_id = $1", [N.uid])
  check(mem.some((m: any) => m.content === 'Compromissos: de trabalho.' && m.source === 'pergunta_contextual'), 'vira fato explícito (Minha memória), com a origem', mem)
  N.novaConversa(); r = await N.diga('quero organizar meus compromissos da semana')
  check(!/pessoais, de trabalho/.test(r.t), 'não pergunta de novo o que já sabe')
  // ritmo: logo depois, uma ação que poderia render outra pergunta → nada (nunca uma atrás da outra)
  r = await N.diga('agende um atendimento com a Bruna amanhã às 16h')
  check(/Agendei/.test(r.t) && !/com o quê\?/.test(r.t), 'ritmo: sem segunda pergunta no mesmo dia (a ação é feita normalmente)', r.t)
  await passarDias(N.uid, 2); N.novaConversa()
  r = await N.diga('agende um atendimento com a Lia amanhã às 17h')
  check(/^Pronto! Agendei/.test(r.t) && /Aliás, esses atendimentos são do seu trabalho com o quê\?/.test(r.t), 'depois da AÇÃO concluída: uma pergunta curta no fim (não interrompe)', r.t)
  check((await appts(N.uid)).some((a: any) => a.d.clienteNome === 'Lia'), 'o compromisso foi criado antes da pergunta')
  r = await N.diga('sou manicure')
  check(/manicure/.test(r.t) && (await q("SELECT 1 FROM memories WHERE user_id = $1 AND content = 'Trabalha com: manicure.'", [N.uid])).length === 1, 'aprende com a resposta (fato explícito)')
  N.novaConversa(); r = await N.diga('quero agendar um serviço amanhã às 10h')
  check(/de manicure ou de outro serviço\?/.test(r.t), 'o que aprendeu por conversa ajuda a interpretar o próximo pedido ambíguo', r.t)
  r = await N.diga('sim'); const ap = await appts(N.uid)
  check(ap[ap.length - 1].d.title === 'Manicure', 'e executa com menos idas e vindas')
}
{ console.log('\n## pergunta ignorada e respostas fora do assunto')
  const G = await novo()
  await G.diga('agende um atendimento com o Rui amanhã às 9h')
  let r = await G.diga('gastei 50 reais de gasolina')
  check(/Gasto registrado/.test(r.t), 'outro pedido no lugar da resposta: executado normalmente (a pergunta não trava nada)')
  check(!(await q("SELECT 1 FROM memories WHERE user_id = $1 AND content LIKE 'Trabalha com:%'", [G.uid])).length, 'nada é inventado a partir de uma mensagem que não respondia')
  await passarDias(G.uid, 2); G.novaConversa(); r = await G.diga('agende um atendimento com o Davi amanhã às 11h')
  check(!/com o quê\?/.test(r.t), 'pergunta ignorada não volta logo (espera 30 dias)', r.t)
  const E = await novo(); r = await E.diga('agende um atendimento com a Rita amanhã às 9h')
  check(/com o quê\?/.test(r.t), '(pergunta feita depois do agendamento)')
  r = await E.diga('troque o cliente para Marcos'); const ae = await appts(E.uid)
  check(ae[0]?.d.clienteNome === 'Marcos' && !(await q("SELECT 1 FROM memories WHERE user_id = $1", [E.uid])).length, 'um comando no lugar da resposta é EXECUTADO ("troque o cliente…") e não vira fato', [r.t, ae[0]?.d.clienteNome])
  const K = await novo(); await K.diga('agende um atendimento com a Ana amanhã às 9h'); r = await K.diga('ok')
  check(!(await q("SELECT 1 FROM memories WHERE user_id = $1", [K.uid])).length, '"ok" não vira resposta ("Trabalha com: ok" nunca)')
}
{ console.log('\n## hábito: o pedido repetido vira pergunta (uma vez) e a resposta confirma o padrão')
  const H = await novo()
  await semear(H.uid, 'reminder', { message: 'pagar a luz', time: '09:00' }, 30, addDays(HOJE, -30))
  await AU.atualizar({ id: H.uid }, { forcar: true }) // o uso passado já teria sido calculado (recálculo depois de cada turno)
  let r = await H.diga('me lembre de pagar a luz amanhã às 9h')
  check(/Vou te lembrar/.test(r.t) && /"pagar a luz" costuma se repetir/.test(r.t), '2º lembrete igual: lembra E pergunta se é rotina', r.t)
  r = await H.diga('sim, todo mês')
  const p = (await padroesDe(H.uid)).find((x: any) => x.context === 'lembrete:pagar a luz')
  check(p?.p.confirmado === true && Number(p.confidence) >= 0.85, 'a confirmação vira evidência explícita no padrão (confiança ≥ 0,85)', p)
  await passarDias(H.uid, 3); r = await H.diga('me lembre de pagar a luz dia 5 às 9h')
  check(!/costuma se repetir/.test(r.t), 'não pergunta de novo')
}
{ console.log('\n## usuário com contexto parcial e consolidado')
  const Pa = await novo()
  for (let i = 0; i < 15; i++) await semear(Pa.uid, 'expense', { kind: 'expense', amount: 10 + i, category: 'outros', subcategory: ['Mercado', 'Padaria', 'Uber'][i % 3] }, i + 1, addDays(HOJE, -(i + 1)))
  check((await DS.nivel({ id: Pa.uid } as any)).nivel === 'parcial', 'nível: parcial')
  let r = await Pa.diga('gastei 12 reais no mercado')
  check(/Gasto registrado/.test(r.t) && !/por categoria/.test(r.t), 'parcial: pergunta de pouca utilidade (finanças) não é feita', r.t)
  r = await Pa.diga('agende um atendimento com o Caio amanhã às 9h')
  check(/com o quê\?/.test(r.t), 'parcial: lacuna útil (atividade) ainda é perguntada', r.t)
  const Co = await novo()
  for (let i = 0; i < 8; i++) await semear(Co.uid, 'appointment', { title: i % 2 ? 'Corte' : 'Barba', time: '10:00', clienteNome: 'Cliente ' + i }, 3 * i + 1, addDays(HOJE, -(3 * i + 1)))
  for (let i = 0; i < 55; i++) await semear(Co.uid, 'expense', { kind: 'expense', amount: 5, category: 'outros', subcategory: 'Café' }, (i % 50) + 1, addDays(HOJE, -((i % 50) + 1)))
  check((await DS.nivel({ id: Co.uid } as any)).nivel === 'consolidado', 'nível: consolidado')
  r = await Co.diga('quero organizar meus compromissos')
  check(!/pessoais, de trabalho/.test(r.t), 'consolidado: sem pergunta de descoberta (e a natureza já é inferível pelos atendimentos)', r.t)
  r = await Co.diga('agende um corte com o Ivo amanhã às 14h')
  check(/Agendei/.test(r.t) && !/com o quê\?|costuma se repetir|por categoria|costuma agendar/.test(r.t), 'consolidado: executa direto, sem perguntas de descoberta', r.t)
  Co.novaConversa(); r = await Co.diga('agende um atendimento com o Ivo amanhã às 16h')
  check(/^Você costuma agendar (barbas e cortes|cortes e barbas)\./.test(r.t), 'consolidado: a dúvida que a EXECUÇÃO precisa (qual serviço) continua sendo perguntada, já com o contexto', r.t)
  const In = await novo()
  for (let i = 0; i < 3; i++) await semear(In.uid, 'appointment', { title: 'Sessão ' + i, time: '10:00', clienteNome: 'Cliente ' + i }, i + 1, addDays(HOJE, -(i + 1)))
  r = await In.diga('quero organizar meus compromissos')
  check(!/pessoais, de trabalho/.test(r.t), 'inferível pelas ações (atendimentos com clientes): não pergunta', r.t)
}

console.log('\n# D. Persistência, isolamento, privacidade e painel')
{ const outro = await novo()
  check((await AU.padroes({ id: outro.uid, memory_settings: {} } as any)).length === 0, 'padrões de um usuário nunca aparecem para outro')
  outro.novaConversa(); const r = await outro.diga('quero agendar um serviço amanhã às 9h')
  check(!/tatuag|massag|manicure/i.test(r.t), 'a pergunta de outro usuário não usa dados alheios', r.t)
  const lst = (await A.cli.call('GET', '/api/learning')).body.itens || []
  check(lst.some((x: any) => x.kind === 'padrao_uso' && /Tatuagem/.test(x.regra)) && !lst.some((x: any) => x.kind === 'descoberta'), 'a pessoa vê os próprios padrões em Aprendizados (e pode apagar); o controle das perguntas é interno')
  const fila = (await S.admin.call('GET', '/api/panel/aprendizagem/fila')).body.itens || []
  check(!fila.some((x: any) => x.kind === 'padrao_uso' || x.kind === 'descoberta'), 'fila de revisão do administrador sem padrões de uso nem perguntas')
  check((await outro.cli.call('GET', '/api/panel/aprendizagem/fila')).status === 403, 'só o administrador vê a fila')
  // chave de privacidade: aprendizado desligado pela pessoa → sem padrões e sem perguntas
  const Pv = await novo(); await Pv.cli.call('POST', '/api/memory', { action: 'settings', enabled: false })
  for (const d of [1, 2, 3]) await semear(Pv.uid, 'appointment', { title: 'Yoga', time: '08:00' }, d, addDays(HOJE, -d))
  const r2 = await Pv.diga('quero agendar um serviço amanhã às 9h'); const r3 = await Pv.diga('Quero organizar meus compromissos')
  check(!/yoga|costuma/i.test(r2.t) && !/pessoais, de trabalho/.test(r3.t) && !(await padroesDe(Pv.uid)).length, 'aprendizado desligado pela pessoa: nada é aprendido nem perguntado', [r2.t, r3.t])
  // persistência: os padrões ficam no banco (outro processo lê igual)
  const row = await one("SELECT user_id, confidence, frequency FROM learnings WHERE user_id = $1 AND kind = 'padrao_uso' AND context = 'servico_agenda:tatuagem'", [A.uid])
  check(row && Number(row.frequency) >= 4 && Number(row.user_id) === A.uid, 'persistido no banco, por usuário', row)
  // a pessoa PAUSA um padrão: deixa de ser usado e o recálculo não o reativa; reativado, volta
  const Y = await novo(); for (const d of [1, 2, 3]) await semear(Y.uid, 'appointment', { title: 'Drenagem', time: '07:00' }, d, addDays(HOJE, -d))
  await AU.atualizar({ id: Y.uid }, { forcar: true }); const py = (await Y.cli.call('GET', '/api/learning')).body.itens.find((x: any) => x.kind === 'padrao_uso')
  await Y.cli.call('POST', '/api/learning', { action: 'update', id: py.id, estado: 'pausado' }); await semear(Y.uid, 'appointment', { title: 'Drenagem', time: '07:00' }, 0, HOJE)
  let ry = await Y.diga('quero agendar um serviço amanhã às 9h')
  check(!/drenage/i.test(ry.t) && (await Y.cli.call('GET', '/api/learning')).body.itens.find((x: any) => x.id === py.id)?.estado === 'pausado', 'padrão pausado pela pessoa não é usado nem reativado pelo recálculo', ry.t)
  await Y.cli.call('POST', '/api/learning', { action: 'update', id: py.id, estado: 'ativo' }); Y.novaConversa(); ry = await Y.diga('quero agendar um serviço amanhã às 9h')
  check(/drenagens/.test(ry.t), 'reativado: volta a ajudar', ry.t)
  // a pessoa apaga um padrão em Aprendizados: ele não é mais usado nem recriado pelo recálculo
  const Z = await novo(); for (const d of [1, 2]) await semear(Z.uid, 'appointment', { title: 'Pilates', time: '07:00' }, d, addDays(HOJE, -d))
  await AU.atualizar({ id: Z.uid }, { forcar: true }); const pz = (await Z.cli.call('GET', '/api/learning')).body.itens.find((x: any) => x.kind === 'padrao_uso')
  await Z.cli.call('POST', '/api/learning', { action: 'delete', id: pz.id }); await semear(Z.uid, 'appointment', { title: 'Pilates', time: '07:00' }, 0, HOJE)
  const rz = await Z.diga('quero agendar um serviço amanhã às 9h')
  check(!/pilates/i.test(rz.t) && !(await Z.cli.call('GET', '/api/learning')).body.itens.some((x: any) => x.kind === 'padrao_uso'), 'padrão apagado pela pessoa não volta (nem com novas ocorrências)', rz.t)
  // apagar um registro: o padrão acompanha (nada de padrão de dado que não existe mais)
  await q("DELETE FROM items WHERE user_id = $1 AND type = 'appointment'", [A.uid]); await AU.atualizar({ id: A.uid }, { forcar: true })
  check((await padroesDe(A.uid)).every((p: any) => p.state === 'inativo'), 'registros apagados: os padrões ficam inativos')
}

console.log(`\nResultado: ${ok}/${ok + falhas} verificações aprovadas.`)
if (falhas) console.log('Falhas:\n - ' + erros.join('\n - '))
void nowIso
await S.fechar(); process.exit(falhas ? 1 : 0)
