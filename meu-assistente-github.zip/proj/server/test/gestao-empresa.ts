// TESTES — MODO "GESTÃO DA EMPRESA" (administrador conversacional) pelo fluxo real POST /api/chat.
// Interpretação (linguagem informal, erros de digitação, contexto), consulta × sugestão × alteração, prévia sem gravar,
// execução com persistência real, reajuste em lote, isolamento entre empresas e contas, nenhuma pesquisa na internet,
// modo que não se desliga com uma pergunta fora do assunto e regressão do chat comum.
// Uso: npm run test:gestao
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, one, J } = await import('../src/db/index.js')
const PB = await import('../src/ai/bloqueio-pesquisa.js')

let ok = 0, falhas = 0; const erros: string[] = []
const check = (c: unknown, m: string) => { if (c) { ok++; console.log('    ✓', m) } else { falhas++; erros.push(m); console.log('    ✗', m) } }
let nIp = 0; const f0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? f0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.8.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : f0(u, o)) as typeof fetch
const IMG = (c: string) => 'data:image/png;base64,' + Buffer.from('PNG' + c).toString('base64')
async function dono(nome: string, produtos: any[]) {
  const cli = await S.novoUsuario(), uid = Number((await q('SELECT id FROM users ORDER BY id DESC LIMIT 1'))[0].id)
  const bid = Number((await q("INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, expires_at, created_at, updated_at, modalidade) VALUES ($1,$2,'ativo','n4',$3,$4,$5,$5,'products') RETURNING id", [uid, 'AN-GT-' + Math.random().toString(36).slice(2, 8), JSON.stringify({ empresa: nome, categoria: 'Doceria', titulo: nome, texto: 'x', sobre: 'Doces caseiros', zap: '5511988887777', entrega: { entrega: true, retirada: true, taxa: 5, raio: 5 }, pagamento: { pix: true, dinheiro: true, cartao: true } }), new Date(Date.now() + 30 * 86400_000).toISOString(), new Date().toISOString()]))[0].id)
  for (const p of produtos) { const r = await cli.call('POST', `/api/v2/ads/${bid}/products`, p); if (r.status !== 200) throw new Error('produto: ' + JSON.stringify(r.body)) }
  return { cli, uid, bid }
}
const prods = async (bid: number) => Object.fromEntries((await q('SELECT id, active, stock, data FROM products WHERE business_id = $1', [bid])).map((r: any) => { const d = J<any>(r.data, {}); return [d.nome, { id: Number(r.id), preco: Number(d.preco), oferta: d.oferta?.ativo ? Number(d.oferta.preco) : null, categoria: d.categoria, descricao: d.descricao || '', ativo: r.active === true || r.active === 1, estoque: r.stock == null ? null : Number(r.stock) }] }))
const emp = async (bid: number) => J<any>((await one('SELECT data FROM businesses WHERE id = $1', [bid]))!.data, {})
type T = { resp: string; buscas: number; ia: number; bloq: boolean; prev: any }
async function fala(cli: any, conv: string, texto: string, extra: any = {}): Promise<T> {
  const n0 = PB.turnosTeste.length, b0 = S.buscas.length, i0 = S.chamadasIA.length
  const r = await cli.call('POST', '/api/chat', { text: texto, conversationId: conv, ...extra }); await new Promise((x) => setTimeout(x, 80))
  const resp = String(r.body?.assistantMessage?.content ?? JSON.stringify(r.body))
  const tk = /⟦gest:([^|⟧]+)\|([^⟧]+)⟧/.exec(resp), prev = tk ? (await cli.call('GET', `/api/v2/gestao/previa?c=${tk[1]}&p=${tk[2]}`)).body : null
  console.log(`  👤 ${texto}\n  🤖 ${resp.replace(/⟦[^⟧]*⟧/g, '').replace(/\n+/g, ' ⏎ ').slice(0, 150)}${prev ? `\n     prévia: ${prev.acao} ${prev.previa?.tipo === 'lote' ? prev.previa.itens.map((i: any) => `${i.nome} ${i.antes}→${i.depois}`).join(', ') : (prev.previa?.destaque || []).map((k: string) => `${k}=${JSON.stringify(prev.previa.depois[k])}`).join(' ')}` : ''}`)
  return { resp, buscas: S.buscas.length - b0, ia: S.chamadasIA.length - i0, bloq: !!PB.turnosTeste[n0]?.bloqueada, prev }
}
const semBusca = (t: T, m: string) => check(t.buscas === 0, `${m}: nenhuma pesquisa na internet`)

const A = await dono('Doceria Ana', [
  { nome: 'Brigadeiro', preco: 5, fotos: [IMG('B')], descricao: 'Chocolate ao leite', categoria: 'Doces' },
  { nome: 'Beijinho', preco: 5, fotos: [IMG('J')], categoria: 'Doces' },
  { nome: 'Torta de limão', preco: 40, fotos: [IMG('T')], categoria: 'Tortas' },
  { nome: 'Bolo de cenoura', preco: 35, fotos: [IMG('C')], categoria: 'Bolos' }])
const B = await dono('Doces da Bia', [{ nome: 'Brigadeiro', preco: 4, fotos: [IMG('Q')], categoria: 'Doces' }])
const conv = crypto.randomUUID()

console.log('\n# ativação e consultas (nada muda)')
let t = await fala(A.cli, conv, '⚡ Gestão da Empresa', { modo: 'gestao_empresa' }); check(/Doceria Ana/.test(t.resp), 'ativa na empresa conectada')
const antes = JSON.stringify(await prods(A.bid)) + JSON.stringify(await emp(A.bid))
for (const [f, re] of [['qual o preço do brigadeiro?', /Brigadeiro.*R\$ 5,00/], ['quais produtos eu tenho?', /4 itens/], ['como tá a entrega?', /Entrega: ligada.*taxa R\$ 5,00/], ['quais formas de pagamento eu aceito?', /Pix.*dinheiro.*cartão/i], ['tem algo em promoção?', /Nenhum produto/], ['qual meu whats?', /5511988887777/], ['a loja está recebendo pedidos?', /recebendo pedidos/]] as const) {
  t = await fala(A.cli, conv, f); check(re.test(t.resp), `consulta "${f}" responde com o dado real`); semBusca(t, f); check(!t.prev, `"${f}" não gera prévia`)
}
check(JSON.stringify(await prods(A.bid)) + JSON.stringify(await emp(A.bid)) === antes, 'consultas não alteram nada')

console.log('\n# alterações em linguagem natural (prévia → confirmar → banco)')
const casos: [string, string, (p: any, e: any) => boolean][] = [
  ['aumenta o brigadero pra 6 reais', 'produto_preco', (p) => p.Brigadeiro.preco === 6],
  ['o bolo de cenoura agora custa 38', 'produto_preco', (p) => p['Bolo de cenoura'].preco === 38],
  ['coloca a torta em promoção com 10% de desconto', 'produto_oferta', (p) => p['Torta de limão'].oferta === 36],
  ['acabou o beijinho', 'produto_estoque', (p) => p.Beijinho.estoque === 0],
  ['chegaram mais 12 beijinhos', 'produto_estoque', (p) => p.Beijinho.estoque === 12],
  ['muda a categoria do bolo de cenoura pra Doces', 'produto_categoria', (p) => p['Bolo de cenoura'].categoria === 'Doces'],
  ['muda a descrição do brigadeiro: feito com chocolate belga', 'produto_descricao', (p) => p.Brigadeiro.descricao === 'Feito com chocolate belga'],
  ['tira a torta do cardápio', 'produto_pausar', (p) => p['Torta de limão'].ativo === false],
  ['volta a vender a torta', 'produto_ativar', (p) => p['Torta de limão'].ativo === true],
  ['troca o whats pra (11) 97777-6666', 'alterar_whatsapp', (_p, e) => e.zap === '5511977776666'],
  ['agora a gente abre de segunda a sábado das 8h às 19h', 'alterar_horario', (_p, e) => e.horarioCfg?.dias?.seg?.abre === '08:00' && e.horarioCfg?.dias?.sab?.fecha === '19:00' && e.horarioCfg?.dias?.dom?.ativo === false],
  ['taxa de entrega 7 reais e pedido mínimo 30', 'configurar_entrega', (_p, e) => Number(e.entrega?.taxa) === 7 && Number(e.entrega?.minimo) === 30 && e.entrega?.retirada !== false],
  ['frete grátis acima de 120', 'frete_gratis', () => true],
  ['para de aceitar cartão', 'configurar_pagamento', (_p, e) => e.pagamento?.cartao === false && e.pagamento?.dinheiro === true],
  ['muda nosso endereço pra Rua das Flores, 100, Centro, São Paulo', 'alterar_endereco', (_p, e) => e.endereco === 'Rua das Flores, 100, Centro, São Paulo'],
]
for (const [f, acao, ver] of casos) {
  const p0 = JSON.stringify(await prods(A.bid)) + JSON.stringify(await emp(A.bid))
  t = await fala(A.cli, conv, f); check(t.prev?.acao === acao && t.prev?.status === 'pendente', `"${f}" → prévia ${acao}`); semBusca(t, f); check(t.bloq, `"${f}": pesquisa bloqueada no turno`)
  check(JSON.stringify(await prods(A.bid)) + JSON.stringify(await emp(A.bid)) === p0, `"${f}": nada gravado antes de confirmar`)
  const c = await fala(A.cli, conv, 'Confirmar alterações'); check(/Pronto/.test(c.resp), `"${f}": confirmado`)
  check(ver(await prods(A.bid), await emp(A.bid)), `"${f}": persistido no banco`)
}
const fg = (await (await import('../src/lib/incentivos.js')).listar(A.bid)).filter((i: any) => i.beneficio === 'frete_gratis' && i.ativo)
check(fg.length === 1 && Number(fg[0].meta) === 120, 'frete grátis acima de R$ 120 gravado')

console.log('\n# contexto da conversa')
t = await fala(A.cli, conv, 'qual o preço do bolo de cenoura?'); t = await fala(A.cli, conv, 'muda ele pra 40'); check(t.prev?.acao === 'produto_preco' && t.prev?.previa?.depois?.nome === 'Bolo de cenoura' && t.prev?.previa?.depois?.preco === 40, '"muda ele pra 40" usa o produto consultado antes')
await fala(A.cli, conv, 'Cancelar'); check((await prods(A.bid))['Bolo de cenoura'].preco === 38, 'cancelar não grava')
t = await fala(A.cli, conv, 'coloca o brigadeiro em promoção por 4,50'); await fala(A.cli, conv, 'Confirmar alterações')
t = await fala(A.cli, conv, 'e o beijinho também'); check(t.prev?.acao === 'produto_oferta' && t.prev?.previa?.depois?.nome === 'Beijinho' && t.prev?.previa?.depois?.oferta === 4.5, '"e o beijinho também" repete a oferta no outro produto')
await fala(A.cli, conv, 'Confirmar alterações'); check((await prods(A.bid)).Beijinho.oferta === 4.5 && (await prods(A.bid)).Brigadeiro.oferta === 4.5, 'oferta gravada nos dois')

console.log('\n# vários produtos e reajuste em grupo')
t = await fala(A.cli, conv, 'muda o brigadeiro pra 7 e a torta pra 45'); check(t.prev?.acao === 'produto_preco_lote' && t.prev.previa.itens.length === 2, 'dois produtos com valores próprios numa frase → uma prévia')
await fala(A.cli, conv, 'Confirmar alterações'); let ps = await prods(A.bid); check(ps.Brigadeiro.preco === 7 && ps['Torta de limão'].preco === 45, 'os dois preços gravados')
t = await fala(A.cli, conv, 'aumenta 10% todos os doces'); const lote = t.prev?.previa?.itens || []
check(t.prev?.acao === 'produto_preco_lote' && lote.length === 3 && lote.every((i: any) => Math.abs(i.depois - Math.round(i.antes * 110) / 100) < 0.011), 'reajuste de 10% em toda a categoria Doces (prévia com antes → depois)')
await fala(A.cli, conv, 'Confirmar alterações'); ps = await prods(A.bid); check(ps.Brigadeiro.preco === 7.7 && ps.Beijinho.preco === 5.5 && ps['Bolo de cenoura'].preco === 41.8 && ps['Torta de limão'].preco === 45, 'lote gravado só na categoria pedida')

console.log('\n# sugestão (não grava sem confirmar) e falta de dados')
const d0 = (await emp(A.bid)).sobre
t = await fala(A.cli, conv, 'sugira uma descrição melhor para a empresa'); check(t.prev?.acao === 'alterar_descricao' && /Sugestão/.test(t.resp) && (t.prev.previa.depois.descricao || '').length <= 200, 'sugestão vira prévia (até 200 caracteres)'); check((await emp(A.bid)).sobre === d0, 'sugestão não grava sozinha'); await fala(A.cli, conv, 'Cancelar')
t = await fala(A.cli, conv, 'que preço eu cobro no brigadeiro?'); check(!t.prev && /R\$ 7,70/.test(t.resp), 'pedido de opinião sobre preço: orienta com o preço atual, sem prévia')
t = await fala(A.cli, conv, 'muda o preço do bolo de cenoura'); check(/Qual o novo preço de Bolo de cenoura/.test(t.resp) && !t.prev, 'sem o valor: pergunta o valor')
t = await fala(A.cli, conv, 'aumenta o preço do picolé de uva pra 9'); check(!t.prev, 'produto inexistente: não altera nenhum outro'); semBusca(t, 'produto inexistente')
t = await fala(A.cli, conv, 'muda a chave pix'); check(/Sua empresa/.test(t.resp) && !t.prev, 'chave Pix nunca é alterada pelo chat')

console.log('\n# o modo não desliga nem pesquisa por engano')
t = await fala(A.cli, conv, 'quanto é 12 vezes 8?'); check((await one('SELECT modo FROM conversa_modos WHERE conversation_id = $1', [conv]))?.modo === 'gestao_empresa', 'pergunta fora do assunto: o chat comum responde e o modo continua ligado')
t = await fala(A.cli, conv, 'pesquise na internet o preço médio do brigadeiro'); check(t.buscas >= 1 && !t.prev, 'pesquisa pedida explicitamente continua funcionando')
t = await fala(A.cli, conv, 'muda o beijinho pra 6'); check(t.prev?.acao === 'produto_preco', 'depois disso, a gestão segue no mesmo modo'); await fala(A.cli, conv, 'Cancelar')
t = await fala(A.cli, conv, 'xpto preço blablabla'); check(/Não entendi exatamente/.test(t.resp) && t.buscas === 0, 'pedido de gestão não entendido: pergunta no modo (sem pesquisa e sem chat genérico)')

console.log('\n# isolamento entre empresas e contas')
check((await prods(B.bid)).Brigadeiro.preco === 4, 'a outra empresa (mesmo nome de produto) não foi tocada')
const convB = crypto.randomUUID(); await fala(B.cli, convB, '⚡ Gestão da Empresa', { modo: 'gestao_empresa' })
t = await fala(B.cli, convB, 'muda o brigadeiro pra 4,20'); check(t.prev?.empresa === 'Doces da Bia', 'cada dono só gerencia a própria empresa')
const tkA = /⟦gest:([^|⟧]+)\|([^⟧]+)⟧/.exec(t.resp)!
check((await A.cli.call('GET', `/api/v2/gestao/previa?c=${tkA[1]}&p=${tkA[2]}`)).status === 404, 'a prévia de outra conta não é visível')
await A.cli.call('POST', '/api/chat', { text: 'Confirmar alterações', conversationId: convB }); check((await prods(B.bid)).Brigadeiro.preco === 4, 'outra conta não confirma a prévia alheia')
await fala(B.cli, convB, 'Confirmar alterações'); check((await prods(B.bid)).Brigadeiro.preco === 4.2 && (await prods(A.bid)).Brigadeiro.preco === 7.7, 'confirmação grava só na empresa da prévia')
const X = await S.novoUsuario(); check(!((await X.call('GET', '/api/v2/modos')).body.modos || []).some((m: any) => m.id === 'gestao_empresa'), 'quem não tem empresa não vê o modo')

console.log('\n# chat comum (fora do modo) continua igual')
const c2 = crypto.randomUUID()
t = await fala(A.cli, c2, 'gastei 30 no mercado'); check(/30,00/.test(t.resp) && /Gasto registrado/.test(t.resp), 'gasto pessoal fora do modo')
t = await fala(A.cli, c2, 'aumenta o preço do beijinho para 6 reais'); semBusca(t, 'comando da empresa fora do modo'); check(t.bloq, 'comando da empresa fora do modo: pesquisa bloqueada')

await S.fechar()
console.log(`\n${falhas ? '❌' : '✅'} ${ok} verificações ok, ${falhas} falharam`)
if (falhas) { console.log(erros.map((e) => '  - ' + e).join('\n')); process.exit(1) }
process.exit(0)
