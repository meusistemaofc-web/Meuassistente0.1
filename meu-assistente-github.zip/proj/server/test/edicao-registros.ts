// EDIÇÃO DE REGISTROS PELO CHAT, em mensagens seguidas na MESMA conversa (fluxo real: POST /api/chat, dublês de IA e de internet).
// Confere no BANCO, a cada mensagem: só o campo pedido muda, o resto fica igual, nada é duplicado, a resposta mostra o que mudou
// e nada é afirmado sem o banco confirmar. Também: registro citado pelo nome (mesmo logo depois de outro), ambiguidade (pergunta
// qual), confirmação antes de cancelar/apagar, valor inválido (não finge), isolamento entre usuários e nenhuma pesquisa na
// internet nem IA em pedidos de edição.
// Uso: npm run test:edicao
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
process.env.SONDA_FERRAMENTAS = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, J } = await import('../src/db/index.js')
const PB = await import('../src/ai/bloqueio-pesquisa.js')
const { localDate, addDays } = await import('../src/lib/time.js')
const TZ = 'America/Sao_Paulo', HOJE = localDate(TZ), AMANHA = addDays(HOJE, 1)
const proxDia = (dow: number) => { for (let i = 1; i <= 7; i++) { const d = addDays(HOJE, i); const [y, m, dd] = d.split('-').map(Number); if (new Date(Date.UTC(y, m - 1, dd)).getUTCDay() === dow) return d } return '' }
const SEXTA = proxDia(5)

let ok = 0, falhas = 0
const erros: string[] = []
function check(cond: unknown, msg: string, det?: unknown) { if (cond) { ok++; console.log('    ✓', msg) } else { falhas++; erros.push(msg); console.log('    ✗', msg, det === undefined ? '' : '→ ' + JSON.stringify(det).slice(0, 400)) } }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
let nIp = 0; const fetch0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? fetch0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.7.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : fetch0(u, o)) as any
type T = { resp: string; buscas: number; ia: number; st: any }
class Conversa {
  conv = crypto.randomUUID()
  constructor(public cli: InstanceType<typeof S.Cli>, public uid: number) {}
  async diga(f: string): Promise<T> {
    const n0 = PB.turnosTeste.length, b0 = S.buscas.length, i0 = S.chamadasIA.length
    const r = await this.cli.call('POST', '/api/chat', { text: f, conversationId: this.conv }); await sleep(120)
    const resp = String(r.body?.assistantMessage?.content ?? '').replace(/⟦[^⟧]*⟧/g, '').trim()
    console.log(`  👤 ${f}\n  🤖 ${resp.replace(/\n+/g, ' ⏎ ').slice(0, 200)}`)
    return { resp, buscas: S.buscas.length - b0, ia: S.chamadasIA.length - i0, st: PB.turnosTeste[n0] }
  }
}
async function novo() { const cli = await S.novoUsuario(); const me = await cli.call('GET', '/api/me'); const uid = Number(me.body?.user?.id ?? me.body?.id ?? (await q('SELECT id FROM users ORDER BY id DESC LIMIT 1'))[0].id); return new Conversa(cli, uid) }
const itens = async (uid: number, tipo: string) => (await q('SELECT id, status, day, data FROM items WHERE user_id = $1 AND type = $2 ORDER BY id', [uid, tipo])).map((r: any) => ({ ...r, d: J<any>(r.data, {}) }))
const interno = (t: T, rot: string) => check(t.buscas === 0 && t.ia === 0 && t.st?.bloqueada, `${rot}: interno (sem pesquisa na internet e sem IA)`, { b: t.buscas, ia: t.ia, p: t.st?.prioridade })

console.log('\n# Cenário do pedido: criar um compromisso e alterá-lo em mensagens seguidas')
{ const c = await novo()
  let t = await c.diga('marque uma reunião com o João amanhã às 10h'); let a = await itens(c.uid, 'appointment')
  check(a.length === 1 && a[0].day === AMANHA && a[0].d.time === '10:00' && /Pronto/.test(t.resp), 'compromisso criado (amanhã 10h)')
  const id = a[0].id
  t = await c.diga('quero adicionar uma observação: levar o contrato'); a = await itens(c.uid, 'appointment')
  check(a.length === 1 && /levar o contrato/.test(a[0].d.notes) && a[0].d.time === '10:00' && a[0].day === AMANHA, 'observação gravada; data e horário preservados'); check(/Observa/.test(t.resp) && /levar o contrato/.test(t.resp), 'confirma mostrando a observação'); interno(t, 'observação')
  t = await c.diga('mude o horário para 14h'); a = await itens(c.uid, 'appointment')
  check(a[0].d.time === '14:00' && a[0].day === AMANHA && /levar o contrato/.test(a[0].d.notes), 'horário 14h; data e observação preservadas'); check(/10:00 → 14:00/.test(t.resp), 'confirma "Horário: 10:00 → 14:00"'); interno(t, 'horário')
  t = await c.diga('altere a data para sexta'); a = await itens(c.uid, 'appointment')
  check(a[0].day === SEXTA && a[0].d.time === '14:00', 'data → sexta; horário preservado', a[0].day); check(/Data:/.test(t.resp), 'confirma a data'); interno(t, 'data')
  t = await c.diga('me lembre uma hora antes'); a = await itens(c.uid, 'appointment')
  check(JSON.stringify(a[0].d.reminders) === '[60]' && a[0].day === SEXTA && a[0].d.time === '14:00', 'lembrete 1 h antes; data e horário preservados', a[0].d.reminders); check(/Lembrete:.*1 h antes/.test(t.resp), 'confirma o lembrete'); interno(t, 'lembrete do compromisso')
  check((await itens(c.uid, 'reminder')).length === 0, '"me lembre uma hora antes" não criou um lembrete solto')
  t = await c.diga('adicione o endereço Rua das Palmeiras, 50'); a = await itens(c.uid, 'appointment')
  check(a[0].d.location === 'Rua das Palmeiras, 50' && /levar o contrato/.test(a[0].d.notes), 'endereço gravado'); interno(t, 'endereço')
  t = await c.diga('troque o nome para Reunião do contrato'); a = await itens(c.uid, 'appointment')
  check(a[0].d.title === 'Reunião do contrato' && a[0].d.person === 'João', 'nome trocado; pessoa preservada'); interno(t, 'nome')
  t = await c.diga('coloque como prioridade'); a = await itens(c.uid, 'appointment')
  check(a[0].d.priority === 'high', 'prioridade alta gravada'); check(/Prioridade: normal → alta/.test(t.resp), 'confirma a prioridade'); interno(t, 'prioridade')
  t = await c.diga('quais os detalhes desse compromisso?')
  check(/Reunião do contrato/.test(t.resp) && /14:00/.test(t.resp) && /Rua das Palmeiras/.test(t.resp) && /levar o contrato/.test(t.resp) && /1 h antes/.test(t.resp) && /alta/.test(t.resp) && /João/.test(t.resp), 'detalhes lidos do banco, com tudo o que foi alterado', t.resp); interno(t, 'detalhes')
  a = await itens(c.uid, 'appointment')
  check(a.length === 1 && a[0].id === id && (a[0].d.historico || []).length >= 6, 'um único compromisso do começo ao fim, com histórico das alterações', (a[0].d.historico || []).length)
  t = await c.diga('cancele esse compromisso'); check(/Confirma cancelar/.test(t.resp) && (await itens(c.uid, 'appointment'))[0].status !== 'cancelled', 'cancelar pede confirmação antes')
  t = await c.diga('sim'); check((await itens(c.uid, 'appointment'))[0].status === 'cancelled' && /Cancelei/.test(t.resp), '"sim" cancela de verdade (sem apagar o registro)')
}

console.log('\n# Lembrete, tarefa, gasto e conta')
{ const c = await novo()
  await c.diga('me lembre de pagar a luz amanhã às 9h')
  let t = await c.diga('adiciona uma observação: conta da casa da praia'); let r = await itens(c.uid, 'reminder')
  check(/casa da praia/i.test(r[0].d.notes) && r[0].d.time === '09:00' && (await itens(c.uid, 'expense')).length === 0, 'lembrete: observação gravada (não vira correção de gasto); horário preservado'); interno(t, 'observação do lembrete')
  t = await c.diga('muda para 8h'); r = await itens(c.uid, 'reminder'); check(r[0].d.time === '08:00' && /casa da praia/i.test(r[0].d.notes), 'lembrete: horário 8h; observação preservada')
  await c.diga('crie uma tarefa de revisar o relatório')
  t = await c.diga('coloque como prioridade alta'); let k = await itens(c.uid, 'task'); check(k[0].d.priority === 'high' && /Prioridade: normal → alta/.test(t.resp), 'tarefa: prioridade alta'); interno(t, 'prioridade da tarefa')
  t = await c.diga('mude o lembrete da luz para 7h'); r = await itens(c.uid, 'reminder'); k = await itens(c.uid, 'task')
  check(r[0].d.time === '07:00' && k[0].d.priority === 'high' && !k[0].day, 'registro citado pelo nome ("lembrete da luz") mesmo depois da tarefa; a tarefa não mudou', { lem: r[0].d.time, tar: k[0].day })
  await c.diga('gastei 45 reais no mercado')
  t = await c.diga('apaga esse gasto'); check(/Confirma apagar/.test(t.resp) && (await itens(c.uid, 'expense')).length === 1, 'gasto: pede confirmação antes de apagar')
  t = await c.diga('não'); check((await itens(c.uid, 'expense')).length === 1 && /não alterei|não apaguei|mantive/i.test(t.resp), '"não": nada é apagado')
  await c.diga('apaga esse gasto'); t = await c.diga('sim')
  check((await itens(c.uid, 'expense')).length === 0 && /Apaguei/.test(t.resp), '"sim": apagado de verdade e confirmado')
  await c.diga('conta de luz de 120 reais vence dia 15')
  t = await c.diga('adicione uma observação: débito automático'); const b = await itens(c.uid, 'bill')
  check(/Débito automático/i.test(b[0]?.d.notes) && Number(b[0]?.d.amount) === 120, 'conta: observação gravada; valor preservado'); interno(t, 'observação da conta')
}

console.log('\n# Outro registro citado, ambiguidade, valor inválido e isolamento')
{ const c = await novo(), outra = await novo()
  await outra.diga('marque dentista dia 10 às 9h') // mesmo nome, outra pessoa
  await c.diga('marque dentista dia 10 às 9h'); await c.diga('marque reunião com a Ana amanhã às 15h')
  let t = await c.diga('mude o dentista para 11h'); let a = await itens(c.uid, 'appointment')
  const den = a.find((x: any) => x.d.title === 'Dentista'), reu = a.find((x: any) => x.d.title === 'Reunião')
  check(den?.d.time === '11:00' && reu?.d.time === '15:00', 'o citado ("dentista") muda, não o último criado', { den: den?.d.time, reu: reu?.d.time })
  check((await itens(outra.uid, 'appointment'))[0].d.time === '09:00', 'o dentista de outra pessoa não é tocado')
  t = await c.diga('quais os detalhes do dentista?'); check(/Dentista/.test(t.resp) && /11:00/.test(t.resp) && !/Reunião/.test(t.resp), 'detalhes do registro citado pelo nome'); interno(t, 'detalhes pelo nome')
  await c.diga('marque consulta com o Dr. Paulo dia 12 às 8h'); await c.diga('marque consulta com a Dra. Lia dia 14 às 9h'); await c.diga('crie uma tarefa de comprar papel')
  t = await c.diga('mude a consulta para 10h'); a = await itens(c.uid, 'appointment')
  check(/Qual deles|qual deles|Encontrei 2/.test(t.resp) && a.filter((x: any) => x.d.title === 'Consulta').every((x: any) => x.d.time !== '10:00'), 'dois registros com o mesmo nome: pergunta qual e não altera nada', t.resp)
  t = await c.diga('mude o horário do dentista para 27h'); a = await itens(c.uid, 'appointment')
  check(a.find((x: any) => x.d.title === 'Dentista')?.d.time === '11:00' && !/^Pronto/.test(t.resp), 'horário inválido: nada muda e não diz "Pronto"', t.resp)
}

console.log(`\nResultado: ${ok}/${ok + falhas} verificações aprovadas.`)
if (falhas) console.log('Falhas:\n - ' + erros.join('\n - '))
await S.fechar(); process.exit(falhas ? 1 : 0)
