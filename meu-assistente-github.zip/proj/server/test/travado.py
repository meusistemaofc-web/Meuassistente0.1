# Servidor que aceita a conexão e NUNCA responde (simula mecanismo de busca/provedor travado)
import socket, sys, threading, time
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('127.0.0.1', int(sys.argv[1]))); s.listen(50)
conns = []
while True:
    c, _ = s.accept(); conns.append(c)
