# Produto principal como 1ª opção + 3 fotos por produto, de ponta a ponta pela tela (celular):
# dono cadastra um produto com preço próprio (3 fotos; a 4ª não cabe) e duas variações; a lista mostra 1., 2., 3.;
# o preço do principal vale (mesmo maior que o das variações); cliente vê o principal primeiro no catálogo e no detalhe,
# adiciona o principal e uma variação, finaliza; servidor confere preço e estoque; agente público também mostra a ordem.
# Servidor: PORT=4376 SQLITE_FILE=/tmp/ma-opbase.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sqlite3, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
def abre_manual(pg):
    # Produtos e Serviços: o cadastro manual fica recolhido até tocar em "Cadastro manual" (no modo edição o formulário já vem aberto)
    if not pg.locator('#pn').is_visible() and pg.locator('[data-mim=manual]').count():
        pg.click('[data-mim=manual]'); pg.wait_for_selector('#pn', state='visible')

BASE = 'http://localhost:4376'; DBF = '/tmp/ma-opbase.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def png(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 240), cor).save(b, 'PNG'); return {'name': 'f.png', 'mimeType': 'image/png', 'buffer': b.getvalue()}
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: str(t).replace('\xa0', ' ')
def cat(pg, nome):
    if pg.locator('#pcs').count() and pg.locator('#pcs').is_visible():
        if pg.locator(f'#pcs option:text-is("{nome}")').count(): pg.select_option('#pcs', label=nome); return
        pg.select_option('#pcs', '__nova')
    pg.fill('#pc', nome)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Lia', 'whatsapp': '+55 11 94444-7777', 'email': 'lia.base@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Canecas da Lia', 'categoria': 'Presentes', 'titulo': 'Canecas', 'texto': 'Canecas', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'lia@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('#psave', timeout=10000, state='attached')
    if pg.locator('[data-mim=manual]').count() and not pg.locator('#psave').is_visible(): pg.click('[data-mim=manual]')
    # 1) fotos: até 3
    check('rótulo "Fotos (1 a 3)"', 'Fotos (1 a 3)' in pg.inner_text('body'))
    pg.set_input_files('#pf', [png((200, 30, 30)), png((30, 200, 30))]); pg.wait_for_timeout(900)
    check('2 fotos e ainda cabe mais uma (+ Foto)', pg.locator('#pfs img').count() == 2 and pg.locator('#pf').count() == 1)
    pg.set_input_files('#pf', [png((30, 30, 200)), png((200, 200, 30))]); pg.wait_for_timeout(900)
    check('3ª foto entra, a 4ª não (aviso) e o botão some', pg.locator('#pfs img').count() == 3 and pg.locator('#pf').count() == 0, pg.locator('#pfs img').count())
    # 2) produto principal + variações
    abre_manual(pg); pg.fill('#pn', 'Caneca Lisa'); cat(pg, 'Canecas'); pg.fill('#ppr', '59,90')
    for i, (cor, pr, rgb) in enumerate([('Azul', '49,90', (20, 60, 200)), ('Verde', '64,90', (20, 160, 60))]):
        pg.click('#pvadd'); pg.wait_for_selector(f'[data-var="{i}"] [data-vf=cor]')
        V = pg.locator(f'[data-var="{i}"]'); V.locator('[data-vf=cor]').fill(cor); V.locator('[data-vf=preco]').fill(pr)
        V.locator('[data-vfa]').set_input_files(png(rgb)); pg.wait_for_timeout(500)
    check('com variações, "Produto principal como 1ª opção" vem ligado', pg.get_attribute('[data-pob]', 'aria-checked') == 'true')
    check('o preço do produto principal continua visível e editável', pg.locator('#ppr').is_visible() and 'Preço do produto principal' in pg.inner_text('#ppr >> xpath=..'))
    pg.fill('#pobn', 'Branca'); pg.fill('#pest', '3'); pg.wait_for_timeout(200)
    lista = N(pg.inner_text('#pvlist'))
    check('lista numerada: 1. Branca (produto principal) R$ 59,90, 2. Azul, 3. Verde', lista.index('1. Branca') < lista.index('2. Azul') < lista.index('3. Verde') and 'produto principal' in lista and 'R$ 59,90' in lista and 'estoque 3' in lista, lista)
    pv = N(pg.inner_text('#pprev'))
    check('prévia: preço do principal (R$ 59,90), sem "A partir de", 3 opções', 'R$ 59,90' in pv and 'A partir de' not in pv and '3 opções' in pv, pv)
    pg.click('[data-pof]'); pg.fill('#popr', '52,00'); pg.wait_for_timeout(200)
    pv = N(pg.inner_text('#pprev'))
    check('oferta do principal na prévia (R$ 59,90 → R$ 52,00, OFERTA)', 'R$ 52,00' in pv and 'R$ 59,90' in pv and 'OFERTA' in pv, pv)
    pg.screenshot(path='/tmp/e2e/opbase_cadastro.png', full_page=True)
    pg.click('#psave'); pg.wait_for_timeout(2200)
    items = R.get(f'/api/v2/ads/{ID}/products').json()['items']; it = items[0] if items else None
    full = R.get(f"/api/v2/ads/{ID}/products/{it['id']}").json() if it else {}
    check('salvou: preço 59,90, 3 fotos, opção principal "Branca" e 2 variações', full.get('preco') == 59.9 and len(full.get('fotos', [])) == 3 and full.get('opcaoBase') and [v['rotulo'] for v in full['variantes']] == ['Branca', 'Azul', 'Verde'], (full.get('preco'), len(full.get('fotos', [])), [v['rotulo'] for v in full.get('variantes', [])]))
    db = sqlite3.connect(DBF); nv = db.execute('select count(*) from product_variants where product_id=?', (it['id'],)).fetchone()[0]
    check('no banco: 2 variações (o principal é o próprio produto)', nv == 2, nv)
    check('lista do dono mostra as 3 fotos do produto', len(it['fotos']) == 3)
    # 3) editar carrega tudo; salvar de novo não duplica
    pg.locator(f'[data-pe="{it["id"]}"]').click(); pg.wait_for_selector('[data-var="1"]')
    check('editar: 3 fotos, principal ligado com nome e 2 variações', pg.locator('#pfs img').count() == 3 and pg.get_attribute('[data-pob]', 'aria-checked') == 'true' and pg.input_value('#pobn') == 'Branca' and pg.locator('[data-var]').count() == 2 and pg.input_value('#ppr') in ('59,90', '59,9'), (pg.locator('#pfs img').count(), pg.input_value('#ppr')))
    pg.click('#psave'); pg.wait_for_timeout(1800)
    nv2 = sqlite3.connect(DBF).execute('select count(*) from product_variants where product_id=?', (it['id'],)).fetchone()[0]
    check('salvar de novo não transforma o principal em variação', nv2 == 2, nv2)
    check('formulário sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    # 4) cliente
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bia Cliente', 'whatsapp': '+55 11 95555-0202', 'email': 'bia.base@t.com', **U}, headers={'X-Forwarded-For': '10.6.6.7'}).ok
    pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector('[data-prod]', timeout=20000); pc.wait_for_timeout(800)
    cc = pc.locator(f'[data-prod="{it["id"]}"]'); ct = N(cc.inner_text())
    check('catálogo: preço do principal (R$ 52,00 de R$ 59,90), sem "A partir de"', 'R$ 52,00' in ct and 'R$ 59,90' in ct and 'A partir de' not in ct, ct)
    cc.click(); pc.wait_for_selector('[data-vgrupo=nome]', timeout=8000)
    ops = [x.inner_text() for x in pc.locator('[data-vgrupo=nome] button').all()]
    pr = lambda: N(pc.inner_text('[data-preco]'))
    check('detalhe: opções na ordem Branca, Azul, Verde e abre na Branca', ops == ['Branca', 'Azul', 'Verde'] and pc.get_attribute('[data-vgrupo=nome] button >> nth=0', 'aria-pressed') == 'true' and 'R$ 52,00' in pr(), (ops, pr()))
    check('principal: 3 fotos e "Últimas 3 unidades"', pc.locator('.ma-vthumbs img').count() == 3 and 'Últimas 3' in pc.inner_text('[data-disp]'), pc.inner_text('[data-disp]'))
    pc.screenshot(path='/tmp/e2e/opbase_detalhe.png')
    pc.click('#pp'); pc.wait_for_timeout(150); pc.click('#padd'); pc.wait_for_timeout(600)
    pc.locator(f'[data-prod="{it["id"]}"]').click(); pc.wait_for_selector('[data-vgrupo=nome]')
    pc.click('[data-vgrupo=nome] button >> nth=1'); pc.wait_for_timeout(200)
    check('trocar para Azul: R$ 49,90 e foto da variação', pr() == 'R$ 49,90' and pc.locator('.ma-vthumbs img').count() == 0)
    pc.click('#padd'); pc.wait_for_timeout(600)
    pc.locator(f'[data-prod="{it["id"]}"]').click(); pc.wait_for_selector('[data-vgrupo=nome]'); pc.wait_for_timeout(200)
    check('limite do principal respeita o estoque dele (já tem 2 de 3: não deixa aumentar)', pc.locator('#pp').is_disabled())
    pc.click('#padd'); pc.wait_for_timeout(700)  # a última unidade do principal (3 de 3)
    pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000)
    txt = N(pc.inner_text('[data-checkout]'))
    check('carrinho: principal (Branca) e Azul como itens distintos', pc.locator('[data-cart-item]').count() == 2 and 'Branca' in txt and 'Azul' in txt and 'R$ 156,00' in txt and 'R$ 49,90' in txt, txt[:400])
    pc.screenshot(path='/tmp/e2e/opbase_carrinho.png', full_page=True)
    pc.click('#cgo'); pc.wait_for_timeout(2500)
    o = C.request.get('/api/v2/orders/mine').json()['items'][0]
    check('pedido no servidor: Branca 3× R$ 52,00 (sem id de variação) + Azul R$ 49,90', o['total'] == 205.9 and [i.get('variante') for i in o['itens']] == ['Branca', 'Azul'] and not o['itens'][0].get('varianteId') and o['itens'][0]['preco'] == 52, (o['total'], o['itens']))
    st = sqlite3.connect(DBF).execute('select stock from products where id=?', (it['id'],)).fetchone()[0]
    check('estoque do produto principal baixou (3 → 0)', st == 0, st)
    # 5) agente público
    assert R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    db = sqlite3.connect(DBF); row = db.execute('select data from businesses where id=?', (ID,)).fetchone(); d = json.loads(row[0]); d.setdefault('agente', {})['expiresAt'] = (datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z'; db.execute('update businesses set data=? where id=?', (json.dumps(d), ID)); db.commit()
    G = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); pa = G.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto(f'/a/{ID}'); pa.wait_for_selector('#acts button', timeout=15000)
    if not pa.locator('#acts [data-a=cat]').count(): pa.click('#acts [data-a=mais]')
    pa.click('#acts [data-a=cat]'); pa.wait_for_selector('.pc', timeout=8000); pa.wait_for_timeout(400)
    card = pa.locator('.pc', has_text='Caneca Lisa'); card.locator('[data-pid]').click(); pa.wait_for_selector('.det [data-vid]', timeout=8000)
    aops = [x.inner_text() for x in pa.locator('.det [data-vid]').all()]
    check('agente: opções Branca, Azul, Verde; Branca esgotada (vendeu as 3) aparece indisponível e abre na Azul', aops == ['Branca', 'Azul', 'Verde'] and 'off' in (pa.get_attribute('.det [data-vid] >> nth=0', 'class') or '') and pa.get_attribute('.det [data-vid] >> nth=1', 'aria-pressed') == 'true', aops)
    check('sem rolagem horizontal (loja e agente)', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and pa.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)}')
