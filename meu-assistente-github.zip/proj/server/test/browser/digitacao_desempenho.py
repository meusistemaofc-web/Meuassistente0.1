# Digitação no chat com uma conversa longa aberta (24/11), com a CPU 6x mais lenta (celular de entrada/médio) e sem limitação.
# Mede pela tela real: custo dos observadores de página (MutationObserver) por tecla, tarefas longas, requisições disparadas
# enquanto se digita e a duração dos eventos de teclado (Event Timing API). Também confere que os complementos continuam
# funcionando (texto de exemplo do campo, resposta do chat com marcações tratadas) e que o texto chega inteiro.
# Servidor: PORT=4380 SQLITE_FILE=/tmp/perf.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, uuid, time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4380'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
INSTR = r"""(()=>{window.__perf={ev:[],lt:[],mo:0,moMs:0,fetch:[],on:false};
 new PerformanceObserver(l=>{for(const e of l.getEntries())if(window.__perf.on&&['keydown','keypress','input','keyup','beforeinput'].includes(e.name))window.__perf.ev.push(e.duration)}).observe({type:'event',durationThreshold:16,buffered:false});
 new PerformanceObserver(l=>{for(const e of l.getEntries())if(window.__perf.on)window.__perf.lt.push(e.duration)}).observe({type:'longtask',buffered:false});
 const MO=window.MutationObserver;window.MutationObserver=class extends MO{constructor(cb){super((m,o)=>{const t=performance.now();try{return cb(m,o)}finally{if(window.__perf.on){window.__perf.mo++;window.__perf.moMs+=performance.now()-t}}})}};
 const f=window.fetch;window.fetch=function(u,...a){if(window.__perf.on)window.__perf.fetch.push(String(u&&u.url||u).slice(0,80));return f.call(this,u,...a)};
 const X=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u,...a){if(window.__perf.on)window.__perf.fetch.push('xhr '+String(u).slice(0,80));return X.call(this,m,u,...a)}})()"""
TEXTO = 'Preciso lembrar de pagar o aluguel amanhã cedo, comprar pão, leite e café, e marcar o dentista para sexta às 15h. ' * 2
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, cpu in [('celular, CPU 6x mais lenta', {'width': 390, 'height': 844}, True, 6), ('computador', {'width': 1280, 'height': 900}, False, 1)]:
        print('==', nome)
        C = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Digita Rapido', 'whatsapp': '+55 11 9' + str(int(time.time() * 1000))[-8:], 'email': f'dig{int(time.time()*1000)}@t.com', **U}, headers={'X-Forwarded-For': '10.9.6.' + str(cpu)}).ok
        cv = str(uuid.uuid4())
        for i in range(60): C.request.post('/api/chat', data={'text': f'mensagem número {i} sobre o mercado, gastos e lembretes da semana, com bastante texto', 'conversationId': cv})
        pg = C.new_page(); pg.add_init_script(INSTR); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(2500)
        pg.click('[aria-label="Abrir menu"]'); pg.wait_for_timeout(800); pg.get_by_text('mensagem número 0', exact=False).first.click(); pg.wait_for_timeout(4000)
        check(f'{nome}: conversa longa aberta (60 trocas)', 'mensagem número 59' in pg.inner_text('body'))
        ta = pg.locator('textarea.composer-input'); ta.click(); pg.wait_for_timeout(1200)
        if cpu > 1: cdp = C.new_cdp_session(pg); cdp.send('Emulation.setCPUThrottlingRate', {'rate': cpu})
        pg.evaluate("window.__perf.on=true"); t0 = time.time(); pg.keyboard.type(TEXTO, delay=0); dt = time.time() - t0; pg.wait_for_timeout(1500)
        r = pg.evaluate("(window.__perf.on=false,window.__perf)")
        if cpu > 1: cdp.send('Emulation.setCPUThrottlingRate', {'rate': 1})
        n = len(TEXTO); m = {'ms_por_tecla': round(dt * 1000 / n, 1), 'observadores_ms_por_tecla': round(r['moMs'] / n, 2), 'tarefas_longas': len(r['lt']), 'eventos_lentos(>16ms)': len(r['ev']), 'evento_max_ms': max(r['ev'] or [0]), 'requisicoes': r['fetch']}
        print('   medido:', json.dumps(m, ensure_ascii=False))
        check(f'{nome}: o texto chega inteiro no campo', pg.input_value('textarea.composer-input') == TEXTO)
        check(f'{nome}: observadores da página custam menos de 0,5 ms por tecla', r['moMs'] / n < 0.5, m)
        check(f'{nome}: nenhuma requisição (IA, Cérebro, contadores…) enquanto se digita', not r['fetch'], r['fetch'])
        check(f'{nome}: nenhuma tarefa longa (> 50 ms) durante a digitação', not r['lt'], r['lt'][:5])
        check(f'{nome}: nenhum evento de teclado acima de 100 ms', max(r['ev'] or [0]) <= 100, m)
        # os complementos continuam funcionando: texto de exemplo personalizado volta ao apagar; envio e resposta normais
        ta.fill(''); pg.wait_for_timeout(500)
        check(f'{nome}: texto de exemplo do campo continua aplicado depois de digitar', pg.get_attribute('textarea.composer-input', 'placeholder') == 'Como posso ajudar você hoje?', pg.get_attribute('textarea.composer-input', 'placeholder'))
        n0 = pg.locator('.chat-scroll .bubble-user').count(); ta.fill('quanto é 12 * 7?'); pg.keyboard.press('Enter')
        pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .bubble-user').length>{n0}", timeout=8000); pg.wait_for_timeout(2500)
        corpo = pg.inner_text('.chat-scroll')
        check(f'{nome}: envio e resposta normais (sem marcações cruas na tela)', '84' in corpo and '⟦' not in corpo, corpo[-200:])
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
