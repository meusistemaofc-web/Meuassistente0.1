# "Tema do chat" no menu de três pontinhos (⋮) do chat, pela tela real: alterna Claro/Escuro na hora, usa o tema do app
# (configuração do usuário), persiste após recarregar, em outra conversa e em outro login; os demais itens do menu continuam;
# o campo de digitação fica legível nos dois temas (celular e computador).
# Servidor: run_srv.sh 4368 /tmp/ma-tema-b.db (banco novo)
import sys, json, re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4368'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def lum(rgb):
    v = [int(x) for x in re.findall(r'[\d.]+', rgb)[:3]]
    f = lambda c: (c / 255) / 12.92 if c / 255 <= 0.03928 else (((c / 255) + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(v[0]) + 0.7152 * f(v[1]) + 0.0722 * f(v[2])
def contraste(a, b):
    x, y = sorted([lum(a), lum(b)], reverse=True); return (x + 0.05) / (y + 0.05)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 860}, False)]:
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        email = f'tema.{nome}@t.com'
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Tema ' + nome, 'whatsapp': '+55 11 94444-' + ('3131' if mob else '3232'), 'email': email, **U}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        tema = lambda: pg.evaluate('document.documentElement.dataset.theme')
        def menu():
            pg.click('button[aria-label="Opções"]'); pg.wait_for_selector('[data-ma-tema]', timeout=8000); pg.wait_for_timeout(300)
            return pg.evaluate("()=>{const m=document.querySelector('[data-ma-tema]').parentElement;return [...m.children].map(x=>x.textContent.trim()).filter(Boolean)}")
        pg.fill('textarea[data-composer-input]', 'oi'); pg.locator('button[aria-label="Enviar"]').click()
        pg.wait_for_function("()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>=2", timeout=20000); pg.wait_for_timeout(800)
        t0 = tema(); itens = menu()
        check(f'{nome}: item "Tema do chat" no menu ⋮ com o tema atual, sem tirar os outros itens', any(i.startswith('Tema do chat') for i in itens) and any('Central de Ajuda' in i for i in itens) and any('Notifica' in i for i in itens) and any('Excluir' in i for i in itens), itens)
        check(f'{nome}: ícone sol/lua no item', pg.locator('[data-ma-tema] svg').count() >= 1)
        rot0 = pg.inner_text('[data-ma-tema-v]')
        pg.click('[data-ma-tema]'); pg.wait_for_timeout(900)
        t1 = tema(); alvo = 'light' if t0 != 'light' else 'dark'
        check(f'{nome}: tocar alterna o tema na hora (todo o chat)', t1 == alvo and pg.evaluate("localStorage.getItem('nexa-theme')") == alvo, (t0, t1))
        check(f'{nome}: o rótulo acompanha (Claro/Escuro)', pg.locator('[data-ma-tema-v]').count() == 0 or pg.inner_text('[data-ma-tema-v]') != rot0, rot0)
        pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        sett = R.get('/api/me').json()
        check(f'{nome}: salvo na conta do usuário', json.dumps(sett).find(f'"theme": "{alvo}"') >= 0 or json.dumps(sett).find(f'"theme":"{alvo}"') >= 0, json.dumps(sett)[:200])
        # contraste do campo de digitação no tema atual
        comp = pg.evaluate("""()=>{const c=document.querySelector('.ma-composer'),t=c&&c.querySelector('textarea');let bg=getComputedStyle(c).backgroundColor;return {bg,fg:getComputedStyle(t).color}}""")
        check(f'{nome}: campo de digitação legível no tema {alvo}', contraste(comp['fg'], comp['bg'] if 'rgba(0, 0, 0, 0)' not in comp['bg'] else ('rgb(255,255,255)' if alvo == 'light' else 'rgb(0,0,0)')) >= 4.5, comp)
        pg.screenshot(path=f'/tmp/e2e/tema_{nome}_{alvo}.png')
        # persistência: recarregar, nova conversa, novo login (limpando o navegador)
        pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        check(f'{nome}: continua após recarregar', tema() == alvo, tema())
        pg.goto('/?nova=1'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        check(f'{nome}: continua em outra conversa', tema() == alvo, tema())
        c2 = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert c2.request.post('/api/auth', data={'action': 'login', 'email': email, 'password': U['password']}).ok
        p2 = c2.new_page(); p2.goto('/'); p2.wait_for_selector('textarea.composer-input', timeout=20000); p2.wait_for_timeout(1200)
        check(f'{nome}: continua em um novo login (outro navegador)', p2.evaluate('document.documentElement.dataset.theme') == alvo, p2.evaluate('document.documentElement.dataset.theme'))
        c2.close()
        # volta ao tema anterior e confere o outro lado
        menu(); pg.click('[data-ma-tema]'); pg.wait_for_timeout(900); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        comp = pg.evaluate("""()=>{const c=document.querySelector('.ma-composer'),t=c&&c.querySelector('textarea');return {bg:getComputedStyle(c).backgroundColor,fg:getComputedStyle(t).color}}""")
        check(f'{nome}: alterna de volta ({t0}) e o campo segue legível', tema() == t0 and contraste(comp['fg'], comp['bg'] if 'rgba(0, 0, 0, 0)' not in comp['bg'] else ('rgb(255,255,255)' if t0 == 'light' else 'rgb(0,0,0)')) >= 4.5, (tema(), comp))
        pg.screenshot(path=f'/tmp/e2e/tema_{nome}_{t0}.png')
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
