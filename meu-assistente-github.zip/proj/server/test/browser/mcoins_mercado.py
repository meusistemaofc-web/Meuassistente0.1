# Mercado de MCoins pela tela real (celular e computador): o administrador liga o mercado de UMA moeda no painel (MCoins →
# detalhe da moeda → Mercado da moeda), a moeda aparece "Negociável" no Mercado, o cliente abre o detalhe (cotação, variação,
# gráfico 24h/7d/30d/90d com cotações registradas, máxima/mínima/abertura, volume, ofertas, histórico, alerta), compra com
# prévia (quantidade e "quanto gastar"), confirma, vê a carteira (preço médio, valor de referência) e vende; pausa bloqueia;
# moeda promocional continua sem mercado. Valores conferidos no banco.
# Servidor: run_srv.sh 4373 /tmp/ma-mkcoin.db (banco novo)
import sys, json, sqlite3, re
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4373'; DBF = '/tmp/ma-mkcoin.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def db(sql, a=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, a).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    A.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True, 'mercado': True})
    ID = A.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Loja Moeda', 'categoria': 'Loja', 'titulo': 'P', 'texto': 'x', 'zap': '5511999990000'}).json()['items'][0]['id']
    A.post('/api/panel/coins', data={'action': 'config', 'ativo': True})
    CID = A.post('/api/panel/coins', data={'action': 'create', 'businessId': ID, 'modelo': 'dourada', 'nome': 'Moeda Loja', 'simbolo': 'LOJ', 'quantidade': 10000, 'valorReferencia': 1, 'desconto': 0.5, 'finalidade': 'x'}).json()['moeda']['id']
    A.post('/api/panel/coins', data={'action': 'status', 'id': CID, 'status': 'ativa'})
    cli0 = b.new_context(base_url=BASE); C0 = cli0.request
    assert C0.post('/api/auth', data={'action': 'signup', 'name': 'Dona Promo', 'whatsapp': '+55 11 94444-1235', 'email': 'promo@t.com', **U}).ok
    ID2 = C0.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Loja Promo', 'categoria': 'Loja', 'titulo': 'P', 'texto': 'x', 'zap': '5511999990001'}).json()['items'][0]['id']
    PID = A.post('/api/panel/coins', data={'action': 'create', 'businessId': ID2, 'modelo': 'roxa', 'nome': 'Moeda Promo', 'simbolo': 'PRO', 'quantidade': 500, 'valorReferencia': 1, 'desconto': 1, 'finalidade': 'x'}).json()['moeda']['id']
    A.post('/api/panel/coins', data={'action': 'status', 'id': PID, 'status': 'ativa'})
    # 1) administrador liga o mercado pela tela
    pg = adm.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg, 'MCoins'); pg.wait_for_selector('[data-coin]', timeout=10000); pg.wait_for_timeout(500)
    pg.locator('[data-cd="%d"]' % CID).first.click() if pg.locator('[data-cd="%d"]' % CID).count() else pg.locator('[data-cd]').last.click()
    pg.wait_for_selector('[data-mk-admin]', timeout=10000)
    check('admin: seção "Mercado da moeda" com fórmula documentada e desligada por padrão', 'Desligado' in pg.inner_text('[data-mk-admin]') and 'impacto' in pg.inner_text('[data-mk-formula]'))
    box = pg.locator('[data-mk-admin]')
    for k in ['ligado', 'compras', 'vendas', 'simulacaoConfirmada']: box.locator(f'[data-mk="{k}"]').check()
    box.locator('[data-mkt="liquidacao"]').select_option('simulada')
    for k, v in [('precoInicial', '1,00'), ('piso', '0,50'), ('teto', '5,00'), ('intervaloSeg', '0'), ('taxaCompraPct', '1'), ('maxDetencaoPct', '50')]: box.locator(f'[data-mkn="{k}"]').fill(v)
    pg.click('#mkas'); pg.wait_for_function("document.querySelector('[data-mk-adm-cot]')&&document.querySelector('[data-mk-adm-cot]').innerText.includes('1,00')", timeout=10000)
    m = db('select enabled, buy_enabled, sell_enabled, settlement, price from coin_markets where coin_id=?', (CID,))
    check('admin: mercado salvo no banco (ligado, simulado, cotação inicial 1,00) e abertura no histórico', m and m[0][0] == 1 and m[0][3] == 'simulada' and float(m[0][4]) == 1.0 and db("select count(*) from coin_prices where coin_id=? and reason='abertura'", (CID,))[0][0] == 1, m)
    pg.screenshot(path='/tmp/e2e/mkcoin_admin.png', full_page=True)
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        email = f'cliente.{nome}@t.com'
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Cliente ' + nome, 'whatsapp': '+55 11 94444-' + ('2001' if mob else '2002'), 'email': email, **U}).ok
        uid = db('select id from users where email=?', (email,))[0][0]
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/mercado'); pg.wait_for_selector('#mk-tabs', timeout=15000); pg.wait_for_timeout(600)
        pg.click('[data-aba="bonus"]'); pg.wait_for_selector('[data-moeda]', timeout=10000); pg.wait_for_timeout(500)
        neg = pg.locator(f'[data-moeda="{CID}"] [data-negociavel]').count(); promo = pg.locator(f'[data-moeda="{PID}"] [data-negociavel]').count()
        check(f'{nome}: listagem marca só a moeda com mercado como "Negociável"', neg == 1 and promo == 0)
        pg.click(f'[data-moeda="{CID}"]'); pg.wait_for_selector('[data-mk-chart]', timeout=10000); pg.wait_for_timeout(400)
        t = N(pg.inner_text('[data-mk-det]'))
        check(f'{nome}: detalhe com símbolo, cotação, variação, gráfico, períodos e indicadores', all(x in t for x in ['LOJ', 'R$', 'no período', 'Máxima no período', 'Mínima no período', 'Abertura do período', 'Volume negociado', 'Oferta circulante', 'Oferta total', 'Comprar', 'Vender', 'Criar alerta', 'sem promessa de valorização']) and pg.locator('[data-mkr]').count() == 4, t[:400])
        # 2) compra com prévia (por valor) e confirmação
        pg.click('#mkbuy'); pg.wait_for_selector('#mk-dlg', timeout=5000)
        pg.click('[data-mkm="valor"]'); pg.fill('#mkq', '50,00'); pg.click('#mkok'); pg.wait_for_selector('[data-mk-previa]', timeout=8000)
        prev = N(pg.inner_text('[data-mk-previa]'))
        check(f'{nome}: prévia com quantidade, preço unitário, taxas, total e cotação depois', all(x in prev for x in ['Quantidade', 'Preço unitário', 'Taxas', 'Total', 'Cotação depois']), prev)
        pg.screenshot(path=f'/tmp/e2e/mkcoin_{nome}_previa.png')
        pg.click('#mkok'); pg.wait_for_selector('#mk-dlg', state='detached', timeout=10000); pg.wait_for_selector('[data-mk-pos]', timeout=10000); pg.wait_for_timeout(600)
        bal = db('select balance from coin_balances where coin_id=? and user_id=?', (CID, uid)); ords = db("select qty, net, status from coin_orders where user_id=? and market=1", (uid,))
        check(f'{nome}: compra registrada no banco (pedido concluído, saldo = quantidade, total ≤ R$ 50)', bal and len(ords) == 1 and ords[0][2] == 'concluida' and bal[0][0] == ords[0][0] and float(ords[0][1]) <= 50, (bal, ords))
        pos = N(pg.inner_text('[data-mk-pos]'))
        check(f'{nome}: posição com saldo, valor de referência e preço médio', str(bal[0][0]) in pos and 'Preço médio de aquisição' in pos and 'Valor de referência atual' in pos, pos)
        pg.screenshot(path=f'/tmp/e2e/mkcoin_{nome}_detalhe.png', full_page=True)
        # 3) venda
        pg.click('#mksell'); pg.wait_for_selector('#mk-dlg', timeout=5000); pg.fill('#mkq', '5'); pg.click('#mkok'); pg.wait_for_selector('[data-mk-previa]', timeout=8000)
        pg.click('#mkok'); pg.wait_for_selector('#mk-dlg', state='detached', timeout=10000); pg.wait_for_timeout(800)
        bal2 = db('select balance from coin_balances where coin_id=? and user_id=?', (CID, uid))[0][0]
        check(f'{nome}: venda reduz o saldo e entra no histórico de negócios', bal2 == bal[0][0] - 5 and pg.locator('[data-mk-rec]').count() == 1, bal2)
        # 4) gráfico de outro período e alerta
        pg.click('[data-mkr="7d"]'); pg.wait_for_selector('[data-mkr="7d"].btn-send', timeout=8000); pg.wait_for_timeout(300)
        check(f'{nome}: período 7 dias com gráfico de cotações registradas', pg.locator('[data-mk-chart]').count() == 1)
        pg.fill('#mk_v', '3,00'); pg.click('#mk_a'); pg.wait_for_timeout(800)
        al = R.get('/api/v2/market/alerts').json()['alerts']
        check(f'{nome}: alerta de cotação criado com o sistema de alertas existente', any(a['symbol'] == f'MC:{CID}' for a in al), al)
        # 5) carteira
        pg.goto('/x/carteira'); pg.wait_for_selector(f'[data-wmk="{CID}"]', timeout=10000)
        wt = N(pg.inner_text(f'[data-wmk="{CID}"]'))
        check(f'{nome}: carteira mostra cotação, valor de referência, preço médio, compras e vendas', all(x in wt for x in ['Cotação atual', 'Valor de referência do saldo', 'Preço médio de aquisição', 'Compra', 'Venda']), wt)
        pg.screenshot(path=f'/tmp/e2e/mkcoin_{nome}_carteira.png', full_page=True)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        c.close()
    # 6) pausa: o cliente vê o motivo e não consegue comprar
    pg = adm.new_page(); pg.goto('/admin'); pg.wait_for_timeout(1500); aba(pg, 'MCoins'); pg.wait_for_selector('[data-coin]', timeout=10000)
    pg.locator('[data-cd="%d"]' % CID).first.click() if pg.locator('[data-cd="%d"]' % CID).count() else pg.locator('[data-cd]').last.click()
    pg.wait_for_selector('[data-mk-admin]', timeout=10000); pg.locator('[data-mk="pausado"]').check(); pg.fill('[data-mkt="motivoPausa"]', 'Manutenção programada'); pg.click('#mkas'); pg.wait_for_timeout(1500)
    aud = N(pg.inner_text('[data-mk-aud]'))
    check('admin: integridade conferida (carteiras × livro-razão, cotações encadeadas)', 'conferida' in aud, aud)
    c = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True); R = c.request
    R.post('/api/auth', data={'action': 'login', 'email': 'cliente.celular@t.com', 'password': U['password']})
    pp = c.new_page(); pp.goto('/x/mercado'); pp.wait_for_selector('#mk-tabs', timeout=15000); pp.click('[data-aba="bonus"]'); pp.wait_for_selector(f'[data-moeda="{CID}"]', timeout=10000)
    pp.click(f'[data-moeda="{CID}"]'); pp.wait_for_selector('[data-mk-det] #mkbuy', timeout=10000)
    check('pausa: botão Comprar desativado com o motivo', pp.is_disabled('#mkbuy') and 'Manutenção programada' in pp.inner_text('[data-mk-motivo]'))
    # 7) moeda promocional continua como antes
    pp.keyboard.press('Escape'); pp.goto('/x/mercado'); pp.wait_for_selector('#mk-tabs', timeout=15000); pp.click('[data-aba="bonus"]'); pp.wait_for_selector(f'[data-moeda="{PID}"]', timeout=10000); pp.click(f'[data-moeda="{PID}"]'); pp.wait_for_timeout(1500)
    check('moeda promocional abre a página de crédito promocional (sem mercado)', 'valor de referência (fixo)' in pp.inner_text('body') and pp.locator('[data-mk-det]').count() == 0)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
