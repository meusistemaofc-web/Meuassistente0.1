# Botões "Sua empresa" e modos inteligentes (raio) com a identidade azul no tema claro, tema escuro sem mudança.
# Confere cores, contraste do texto (≥ 4,5:1), estado ativo do raio, foco e que o comportamento continua (abrir a área da
# empresa e o cartão de modos). Celular e computador.
# Servidor: run_srv.sh 4384 /tmp/ma-botoes.db (banco novo)
import sys, re, sqlite3
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4384'; DBF = '/tmp/ma-botoes.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def lum(rgb):
    v = [int(float(x)) for x in re.findall(r'[\d.]+', rgb)[:3]]
    f = lambda c: (c / 255) / 12.92 if c / 255 <= 0.03928 else (((c / 255) + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(v[0]) + 0.7152 * f(v[1]) + 0.0722 * f(v[2])
def ctr(a, b): x, y = sorted([lum(a), lum(b)], reverse=True); return (x + 0.05) / (y + 0.05)
EST = """s=>{const e=document.querySelector(s);if(!e)return null;const c=getComputedStyle(e);return {bg:c.backgroundColor,fg:c.color}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(base_url=BASE); A = adm.request
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', **U}).ok
    A.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono Botao', 'whatsapp': f'+55 11 94444-5{k}{k}{k}', 'email': f'botao{k}@t.com', **U}).ok
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Loja Botão {k}', 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}); assert r.ok
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (r.json()['items'][0]['id'],)); db.commit(); db.close()
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        for tema in ['light', 'dark']:
            R.patch('/api/me', data={'settings': {'theme': tema}})
            pg.goto('/'); pg.wait_for_selector('.ma-hdr-emp', timeout=20000); pg.wait_for_selector('.ma-modos-btn', timeout=20000); pg.wait_for_timeout(800)
            if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
            e = pg.evaluate(EST, '.ma-hdr-emp'); r = pg.evaluate(EST, '.ma-modos-btn')
            if tema == 'light':
                check(f'{nome}: claro — "Sua empresa" azul com texto legível', e['bg'] == 'rgb(37, 99, 235)' and ctr(e['bg'], e['fg']) >= 4.5, e)
                check(f'{nome}: claro — raio com fundo azul-claro e ícone azul (sem fundo escuro)', r['bg'] == 'rgb(232, 240, 255)' and ctr(r['bg'], r['fg']) >= 4.5, r)
                pg.screenshot(path=f'/tmp/e2e/botoes_{nome}_claro.png')
            else:
                check(f'{nome}: escuro — botões preservados (azul-marinho com azul vibrante)', e['bg'] == 'rgb(7, 17, 35)' and r['bg'] == 'rgb(7, 17, 35)' and e['fg'] == 'rgb(65, 124, 247)', (e, r))
            # comportamento preservado: o raio abre os modos; ao escolher um modo, fica ativo (azul sólido no claro)
            pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo]', timeout=8000)
            check(f'{nome}: {tema} — o raio continua abrindo os modos inteligentes', pg.locator('#ma-modos-card [data-modo]').count() >= 1)
            pg.locator('#ma-modos-card [data-modo="gestao_empresa"]').first.click()
            try: pg.wait_for_selector('.ma-modos-btn.on', timeout=15000)
            except Exception: pass
            pg.mouse.move(0, 0); pg.wait_for_timeout(300); ra = pg.evaluate(EST, '.ma-modos-btn.on')
            if tema == 'light': check(f'{nome}: claro — raio ativo em azul sólido com ícone branco', ra and ra['bg'] == 'rgb(37, 99, 235)' and ra['fg'] == 'rgb(255, 255, 255)', ra)
            else: check(f'{nome}: escuro — raio ativo como antes', ra and ra['bg'] == 'rgb(14, 32, 66)', ra)
            pg.goto('/?nova=1'); pg.wait_for_selector('.ma-hdr-emp', timeout=20000); pg.wait_for_timeout(500)
            pg.focus('.ma-hdr-emp'); pg.keyboard.press('Shift+Tab'); pg.keyboard.press('Tab'); pg.wait_for_timeout(200)
            fo = pg.evaluate("(()=>{const c=getComputedStyle(document.querySelector('.ma-hdr-emp'));return c.outlineStyle+' '+c.outlineColor})()")
            check(f'{nome}: {tema} — foco visível no "Sua empresa"', 'solid' in fo, fo)
            pg.click('.ma-hdr-emp'); pg.wait_for_selector('nav.ma-nav', timeout=20000)
            check(f'{nome}: {tema} — "Sua empresa" continua abrindo a área da empresa', pg.locator('nav.ma-nav').count() == 1)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
