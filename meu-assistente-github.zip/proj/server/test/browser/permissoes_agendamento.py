# Permissões de Agendamento pela tela real: dono configura (Sua empresa › Ajustes), cliente solicita serviço e agenda pedido,
# aprovador delegado decide (aprovar, recusar, sugerir, detalhes), cliente aceita o horário sugerido, visitante do agente acompanha a solicitação.
import json, sys, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4311'
DBF='/tmp/ma-teste.db'
IMG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
def dia(n):
    d=datetime.datetime.now(datetime.UTC).replace(tzinfo=None)-datetime.timedelta(hours=3)+datetime.timedelta(days=n); return d.strftime('%Y-%m-%d')
MOB={'viewport':{'width':390,'height':844},'base_url':BASE,'has_touch':True,'is_mobile':True}
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(**MOB); R=ctx.request
    assert R.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert R.put('/api/panel/modules',data={'agente':True,'catalogo':True,'empresas':True}).ok
    r=R.post('/api/v2/ads',data={'planId':'n4','empresa':'Studio Agulha','categoria':'Tatuagem','titulo':'Tattoo','texto':'x','zap':'5511999990000','tipo':'servicos','endereco':'Rua A, 10'}); assert r.ok, r.text()
    ID=r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}',data={'horarioCfg':{'modo':'aberto','dias':{k:{'ativo':True,'abre':'08:00','fecha':'20:00'} for k in ['dom','seg','ter','qua','qui','sex','sab']}},'pagamento':{'pix':True,'dinheiro':True},'entrega':{'retirada':True}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Fineline','preco':150,'tipo':'servico','modoPreco':'fixo','duracao':60,'categoria':'Tatuagem'}).ok
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    assert R.post(f'/api/v2/ads/{ID}/products',data={'nome':'Pomada','preco':30,'tipo':'produto','categoria':'Produtos','fotos':[IMG]}).ok
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'services','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    SV=[x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items'] if x['tipo']=='servico'][0]['id']
    db=sqlite3.connect(DBF); row=db.execute('select data, status from businesses where id=?',(ID,)).fetchone(); d=json.loads(row[0]); d['agente']={**(d.get('agente') or {}),'ativo':True,'expiresAt':(datetime.datetime.now(datetime.UTC).replace(tzinfo=None)+datetime.timedelta(days=30)).isoformat()+'Z'}
    db.execute("update businesses set data=?, status='ativo' where id=?",(json.dumps(d),ID)); db.commit(); db.close()
    cc=b.new_context(**MOB); C=cc.request
    assert C.post('/api/auth',data={'action':'signup','name':'Cliente Teste','whatsapp':'+55 11 96666-5555','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    fc=b.new_context(**MOB); F=fc.request
    sg=F.post('/api/auth',data={'action':'signup','name':'Funcionario Teste','whatsapp':'+55 11 95555-4444','email':'func@t.com','birthday':'1992-02-02','password':'Funcio@123','passwordConfirm':'Funcio@123'}); assert sg.ok, sg.text()
    errs=[]
    # ---------- dono: Sua empresa › Ajustes › Permissões de Agendamento ----------
    pg=ctx.new_page(); pg.on('pageerror',lambda e:errs.append('dono '+pg.url+' '+str(e)[:80]))
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('[data-nav]',has_text='Ajustes').first.click(); pg.wait_for_timeout(600)
    check('dono: opção "Permissões de Agendamento" nos Ajustes', pg.locator('button:has-text("Permissões de Agendamento")').count()>=1)
    pg.locator('button:has-text("Permissões de Agendamento")').first.click(); pg.wait_for_selector('#pa-ped',timeout=8000)
    check('duas opções independentes, desligadas por padrão', pg.get_attribute('[data-sw=ped]','aria-checked')=='false' and pg.get_attribute('[data-sw=srv]','aria-checked')=='false' and 'funcionam exatamente como hoje' in pg.inner_text('body'))
    pg.click('[data-sw=srv]'); pg.wait_for_timeout(200)
    check('ligar serviços mostra quem pode solicitar e reserva temporária', pg.locator('[data-pub^="servicos:"]').count()==3 and pg.locator('[data-num="servicos.reservaMin"]').count()==1 and 'Nada é confirmado automaticamente' in pg.inner_text('#pa-srv'))
    pg.click('[data-sw=ped]'); pg.wait_for_timeout(200)
    check('ligar pedidos mostra antecedência e limite de dias', pg.locator('[data-num="pedidos.antecedenciaMin"]').count()==1 and pg.locator('[data-num="pedidos.diasMax"]').count()==1)
    pg.select_option('[data-num="pedidos.antecedenciaMin"]','0'); pg.wait_for_timeout(200)
    check('aviso de alterações não salvas', 'Alterações não salvas' in pg.inner_text('body'))
    pg.click('#pa-save'); pg.wait_for_timeout(1200)
    cfg=R.get(f'/api/v2/ads/{ID}/permissoes-agendamento').json()['config']
    check('Salvar grava as duas opções no servidor', cfg['servicos']['ativo'] and cfg['pedidos']['ativo'] and cfg['pedidos']['antecedenciaMin']==0, cfg)
    pg.fill('[data-pin=aprovador]','naoexiste@t.com'); pg.click('[data-padd=aprovador]'); pg.wait_for_timeout(800)
    check('conta inexistente: erro claro', 'Não encontramos' in pg.inner_text('[data-perr=aprovador]'))
    pg.fill('[data-pin=aprovador]','func@t.com'); pg.click('[data-padd=aprovador]'); pg.wait_for_timeout(1000)
    box=pg.inner_text('[data-pbox=aprovador]')
    check('aprovador adicionado com contato mascarado', 'Funcionario Teste' in box and 'func@t.com' not in box, box)
    pg.screenshot(path='/tmp/e2e/permissoes_dono.png',full_page=True)
    # ---------- cliente: solicitar serviço pelo app ----------
    cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append('cli '+cp.url+' '+str(e)[:80]))
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-book]',timeout=10000)
    cp.locator('[data-book]').first.click(); cp.wait_for_selector('#bgo',timeout=8000)
    check('cliente: aviso de que a empresa confirma cada horário', 'Esta empresa confirma cada horário' in cp.inner_text('.ma-sheet') and cp.inner_text('#bgo').strip()=='Enviar solicitação')
    cp.locator('[data-dia]').nth(2).click(); cp.wait_for_selector('[data-h]',timeout=8000)
    cp.locator('[data-h]',has_text='10:00').first.click(); cp.fill('#bobs','Antebraço, 6 cm'); cp.click('#bgo'); cp.wait_for_timeout(1800)
    check('enviar leva a Meus pedidos com "Aguardando aprovação"', '/x/pedidos' in cp.url and 'Aguardando aprovação' in cp.inner_text('body') and 'ainda não está confirmado' in cp.inner_text('body'), cp.inner_text('body')[:300])
    mine=C.get('/api/v2/orders/mine').json()['items']; s1=[o for o in mine if o.get('solicitacao')][0]
    check('solicitação gravada com status aguardando_aprovacao e informações', s1['status']=='aguardando_aprovacao' and s1['obs']=='Antebraço, 6 cm' and s1['hora']=='10:00', s1)
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    # ---------- cliente: pedido agendado no checkout ----------
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-cat="Produtos"]',timeout=10000); cp.locator('[data-cat="Produtos"]').first.click(); cp.wait_for_selector('[data-add]',timeout=10000); cp.locator('[data-add]').first.click(); cp.wait_for_timeout(400)
    cp.locator('text=Ver pedido').first.click(); cp.wait_for_selector('#cquando',timeout=8000)
    check('checkout mostra "Quando" com Agora e Agendar', cp.locator('[data-qd=agora]').count()==1 and cp.locator('[data-qd=agendar]').count()==1)
    cp.click('[data-qd=agendar]'); cp.wait_for_selector('[data-agh]',timeout=8000)
    DIA_ESC=cp.locator('[data-agd]').nth(1).get_attribute('data-agd'); cp.locator('[data-agd]').nth(1).click(); cp.wait_for_selector('[data-agh]',timeout=8000)
    cp.locator('[data-agh]',has_text='15:00').first.click(); cp.fill('#czap','11 96666-5555'); cp.click('#cgo'); cp.wait_for_timeout(1800)
    ag=[o for o in C.get('/api/v2/orders/mine').json()['items'] if o.get('agendadoPara')]
    check('pedido agendado criado com dia e horário escolhidos', ag and ag[0]['agendadoPara']['hora']=='15:00' and ag[0]['agendadoPara']['data']==DIA_ESC, ag[:1])
    check('Meus pedidos mostra "Agendado para"', 'Agendado para' in cp.inner_text('body'))
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'services','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    # ---------- aprovador delegado ----------
    fp=fc.new_page(); fp.on('pageerror',lambda e:errs.append('func '+fp.url+' '+str(e)[:80]))
    fp.goto('/x/pedidos'); fp.wait_for_selector('[data-apv]',timeout=10000)
    check('aprovador: atalho "Solicitações para aprovar" em Meus pedidos', 'Studio Agulha' in fp.inner_text('[data-apv]'))
    fp.click('[data-apv]'); fp.wait_for_selector(f'[data-sol="{s1["id"]}"]',timeout=10000)
    it=fp.inner_text(f'[data-sol="{s1["id"]}"]')
    check('solicitação mostra cliente, serviço, data/hora, informações, envio e status', all(t in it for t in ['Cliente Teste','Fineline',s1['data'][8:10]+'/'+s1['data'][5:7],'10:00','Antebraço','enviada em','Aguardando aprovação']), it)
    check('ações: Aprovar, Sugerir outro horário, Recusar e Detalhes', fp.locator(f'[data-sol="{s1["id"]}"] [data-sa]').count()==4)
    fp.locator(f'[data-sol="{s1["id"]}"] [data-sa=detalhes]').click(); fp.wait_for_selector('.ma-sheet',timeout=5000)
    check('Detalhes mostra WhatsApp e histórico', 'WhatsApp' in fp.inner_text('.ma-sheet') and 'solicitado' in fp.inner_text('.ma-sheet'))
    fp.click('.ma-sheet-x'); fp.wait_for_timeout(300)
    fp.locator(f'[data-sol="{s1["id"]}"] [data-sa=sugerir]').click(); fp.wait_for_selector('[data-sh]',timeout=8000)
    check('sugestão avisa que só confirma se o cliente aceitar', 'só será confirmado se o cliente aceitar' in fp.inner_text('.ma-sheet'))
    check('o horário pedido não aparece como sugestão', fp.locator('[data-sh="10:00"]').count()==0)
    fp.locator('[data-sh="14:00"]').click(); fp.fill('#smsg','Às 10h já tenho cliente'); fp.click('#sgo'); fp.wait_for_timeout(1500)
    check('após sugerir: "Novo horário sugerido" aguardando o cliente', 'Novo horário sugerido' in fp.inner_text(f'[data-sol="{s1["id"]}"]') and 'aguardando o cliente' in fp.inner_text(f'[data-sol="{s1["id"]}"]'))
    check('sugestão não confirmou o agendamento', C.get('/api/v2/orders/mine').json()['items'][-1]['status']!='aceito' and [o for o in C.get('/api/v2/orders/mine').json()['items'] if o['id']==s1['id']][0]['status']=='sugestao')
    fp.screenshot(path='/tmp/e2e/permissoes_aprovador.png',full_page=True)
    # ---------- cliente aceita o novo horário ----------
    cp.goto('/x/pedidos'); cp.wait_for_selector(f'[data-sug="{s1["id"]}"]',timeout=10000)
    check('cliente vê a sugestão com mensagem', '14:00' in cp.inner_text(f'[data-sug="{s1["id"]}"]') and 'Às 10h já tenho cliente' in cp.inner_text(f'[data-sug="{s1["id"]}"]'))
    cp.click(f'[data-sga="{s1["id"]}"]'); cp.wait_for_timeout(1500)
    o1=[o for o in C.get('/api/v2/orders/mine').json()['items'] if o['id']==s1['id']][0]
    check('aceitar confirma no horário sugerido e guarda o original', o1['status']=='aceito' and o1['hora']=='14:00' and o1['dataOriginal']['hora']=='10:00', o1)
    check('Meus pedidos mostra "Confirmado" e o horário original', 'Confirmado' in cp.inner_text('body') and 'Horário pedido originalmente' in cp.inner_text('body'))
    # ---------- dono aprova e recusa pela tela ----------
    s2=C.post(f'/api/v2/businesses/{ID}/bookings',data={'servico':SV,'data':dia(3),'hora':'11:00'}).json()['order']['id']
    s3=C.post(f'/api/v2/businesses/{ID}/bookings',data={'servico':SV,'data':dia(3),'hora':'16:00'}).json()['order']['id']
    pg.goto(f'/x/solicitacoes?empresa={ID}'); pg.wait_for_selector(f'[data-sol="{s2}"]',timeout=10000)
    pg.locator(f'[data-sol="{s2}"] [data-sa=aprovar]').click(); pg.wait_for_timeout(1500)
    check('Aprovar tira da lista de pendentes', pg.locator(f'[data-sol="{s2}"]').count()==0)
    pg.locator(f'[data-sol="{s3}"] [data-sa=recusar]').click(); pg.wait_for_selector('#rgo',timeout=5000)
    pg.click('#rgo'); pg.wait_for_timeout(300)
    check('Recusar exige motivo', 'Informe o motivo' in pg.inner_text('.ma-sheet'))
    pg.fill('#rmot','Agenda cheia nesse dia'); pg.click('#rgo'); pg.wait_for_timeout(1500)
    pg.click('[data-flt=todas]'); pg.wait_for_timeout(1200)
    check('filtro "Todas": aprovada "Confirmado", recusada "Não aprovado" com motivo', 'Confirmado' in pg.inner_text(f'[data-sol="{s2}"]') and 'Não aprovado' in pg.inner_text(f'[data-sol="{s3}"]') and 'Agenda cheia' in pg.inner_text(f'[data-sol="{s3}"]'))
    st=[o for o in C.get('/api/v2/orders/mine').json()['items'] if o['id'] in (s2,s3)]
    check('servidor: aprovada = aceito, recusada = recusado', sorted(o['status'] for o in st)==['aceito','recusado'], [(o['id'],o['status']) for o in st])
    s4=C.post(f'/api/v2/businesses/{ID}/bookings',data={'servico':SV,'data':dia(4),'hora':'09:00'}).json()['order']['id']
    pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
    pg.locator('.ma-nav [data-nav=pedidos]').first.click(); pg.wait_for_selector('[data-solic]',timeout=8000)
    check('aba Pedidos do dono: pendente com "Responder solicitação" e pedido agendado com data', 'Solicitação aguardando sua aprovação' in pg.inner_text('body') and 'Pedido agendado para' in pg.inner_text('body'))
    pg.locator('[data-solic]').first.click(); pg.wait_for_timeout(1500)
    check('"Responder solicitação" abre o painel de aprovação', '/x/solicitacoes' in pg.url and pg.locator(f'[data-sol="{s4}"]').count()==1)
    dk=b.new_context(viewport={'width':1280,'height':900},base_url=BASE); dk.add_cookies(ctx.cookies()); dp=dk.new_page(); dp.goto(f'/x/solicitacoes?empresa={ID}'); dp.wait_for_selector(f'[data-sol="{s4}"]',timeout=10000)
    check('computador: painel sem rolagem horizontal', dp.evaluate('document.documentElement.scrollWidth-innerWidth')<=1); dp.screenshot(path='/tmp/e2e/permissoes_computador.png'); dk.close()
    # ---------- visitante no atendimento automático ----------
    gc=b.new_context(**MOB); gp=gc.new_page(); gp.on('pageerror',lambda e:errs.append('ag '+gp.url+' '+str(e)[:80]))
    gp.goto(f'/a/{ID}'); gp.wait_for_selector('#acts button',timeout=15000)
    gp.click('#acts [data-a=srv]'); gp.wait_for_selector('.rich [data-pid]',timeout=8000); gp.locator('.rich [data-pid]').first.click(); gp.wait_for_selector('#sgo',timeout=8000)
    check('agente: aviso de aprovação e botão "Enviar solicitação"', gp.locator('[data-solnote]').count()==1 and gp.inner_text('#sgo').strip()=='Enviar solicitação' and gp.locator('#spx').count()==0)
    gp.locator('.rich [data-d]').nth(5).click(); gp.wait_for_selector('#hs [data-h]',timeout=8000); gp.locator('#hs [data-h]',has_text='12:00').first.click()
    gp.fill('#sn','Visitante Ana'); gp.fill('#st','11 97777-2222'); gp.fill('#so','Primeira tatuagem'); gp.click('#sgo'); gp.wait_for_selector('[data-solic]',timeout=8000); gp.wait_for_selector('[data-sst]',timeout=8000)
    check('agente: mensagem clara de que ainda não está confirmado + cartão "Aguardando aprovação"', 'ainda não está confirmado' in gp.inner_text('body') and gp.get_attribute('[data-sst]','data-sst')=='aguardando_aprovacao')
    sid=int(gp.get_attribute('[data-solic]','data-solic'))
    gp.reload(); gp.wait_for_selector('[data-sst]',timeout=10000)
    check('agente: a solicitação continua acompanhada depois de recarregar', gp.locator(f'[data-solic="{sid}"]').count()==1)
    R.post(f'/api/v2/businesses/{ID}/solicitacoes/{sid}',data={'acao':'sugerir','data':dia(5),'hora':'17:00','mensagem':'Melhor no fim da tarde'})
    gp.click('[data-solic] [data-up]'); gp.wait_for_selector('[data-sr="1"]',timeout=8000)
    check('agente: "Atualizar situação" mostra o novo horário sugerido', '17:00' in gp.inner_text('[data-solic]') and 'Melhor no fim da tarde' in gp.inner_text('[data-solic]'))
    gp.click('[data-sr="1"]'); gp.wait_for_timeout(1500)
    check('agente: aceitar confirma (status "Confirmado")', gp.get_attribute('[data-sst]','data-sst')=='aceito' and 'Confirmado' in gp.inner_text('[data-solic]'))
    gp.screenshot(path='/tmp/e2e/permissoes_agente.png')
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    # carrinho do agente com pedido agendado
    gp.goto(f'/a/{ID}'); gp.wait_for_selector('#acts button',timeout=15000); gp.click('#acts [data-a=mais]'); gp.click('#acts [data-a=cat]'); gp.wait_for_selector('.rich [data-pid]',timeout=8000)
    gp.locator('.rich [data-pid]').first.click(); gp.wait_for_timeout(500)
    gp.locator('.chips [data-x=cart]').last.click(); gp.wait_for_selector('[data-q=agendar]',timeout=8000)
    check('agente: carrinho mostra "Quando" (Agora / Agendar)', gp.locator('[data-q=agora]').count()==1)
    gp.click('[data-q=agendar]'); gp.wait_for_selector('#cad [data-ad]',timeout=8000); gp.locator('#cad [data-ad]').nth(1).click(); gp.wait_for_selector('#cah [data-ah]',timeout=8000); gp.locator('#cah [data-ah]').nth(2).click()
    gp.fill('#cn','Visitante Ana'); gp.fill('#ct','11 97777-2222'); gp.click('#cgo'); gp.wait_for_timeout(1500)
    check('agente: pedido agendado pelo carrinho', 'agendado para' in gp.inner_text('body'), (gp.inner_text('#cerr') if gp.locator('#cerr').count() else '-', gp.inner_text('#chat')[-300:]))
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'services','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    # ---------- desligar volta ao fluxo antigo ----------
    R.put(f'/api/v2/ads/{ID}/permissoes-agendamento',data={'pedidos':{'ativo':False},'servicos':{'ativo':False}})
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-book]',timeout=10000); cp.locator('[data-book]').first.click(); cp.wait_for_selector('#bgo',timeout=8000)
    check('desligado: agendamento volta a "Confirmar agendamento", sem aviso de aprovação', cp.inner_text('#bgo').strip()=='Confirmar agendamento' and cp.locator('[data-perm-msg]').count()==0)
    assert R.post(f'/api/v2/ads/{ID}/modalidade',data={'modalidade':'products','confirmar':True}).ok  # modalidade exclusiva (troca confirmada)
    cp.goto(f'/x/empresa/{ID}'); cp.wait_for_selector('[data-cat="Produtos"]',timeout=10000); cp.locator('[data-cat="Produtos"]').first.click(); cp.wait_for_selector('[data-add]',timeout=10000); cp.locator('[data-add]').first.click(); cp.wait_for_timeout(400); cp.locator('text=Ver pedido').first.click(); cp.wait_for_selector('#cgo',timeout=8000)
    check('desligado: checkout sem "Quando"', cp.locator('#cquando').count()==0)
    errs=[e for e in errs if 'React error #418' not in e and not e.endswith(' Event')] # #418/Event: hidratação do app compilado em /x/sua-empresa — já existia antes desta mudança
    check('sem erros de JavaScript nas telas', not errs, errs[:8])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
sys.exit(0 if all(res) else 1)
