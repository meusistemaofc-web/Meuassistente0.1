# Dublê dos PAGAMENTOS Pix do Mercado Pago (o contêiner de testes não alcança api.mercadopago.com). Segue o contrato oficial
# de POST /v1/payments (payment_method_id=pix) e GET /v1/payments/{id}: o pagamento pertence à conta do Access Token que o
# criou (outra conta recebe 404), X-Idempotency-Key repetida devolve o mesmo pagamento, e point_of_interaction.transaction_data
# traz qr_code (BR Code EMV com CRC16 e o valor no campo 54), qr_code_base64 (PNG de um QR Code de verdade) e ticket_url.
# Controles do teste: /__aprovar?id=, /__modo?m=500|401|semqr|, /__log.  Uso: python3 mp_pagamentos_fake.py PORTA
import sys, json, base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import cv2
PORT = int(sys.argv[1])
CONTAS = {'TEST-loja-cobranca-a-1234567890': {'id': 71001, 'nickname': 'LOJA_COBRA_A', 'email': 'a@cobra.com', 'first_name': 'Ana', 'site_id': 'MLB'},
          'TEST-loja-cobranca-b-1234567890': {'id': 71002, 'nickname': 'LOJA_COBRA_B', 'email': 'b@cobra.com', 'first_name': 'Bia', 'site_id': 'MLB'}}
pays = {}; idem = {}; log = []; ST = {'modo': '', 'n': 0}
def crc16(s):
    c = 0xFFFF
    for ch in s.encode():
        c ^= ch << 8
        for _ in range(8): c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return '%04X' % c
def tlv(i, v): return i + '%02d' % len(v) + v
def brcode(valor, txid, nome):
    s = tlv('00', '01') + tlv('01', '12') + tlv('26', tlv('00', 'br.gov.bcb.pix') + tlv('25', 'qr.dubl-mercadopago.test/v2/' + txid)) + tlv('52', '0000') + tlv('53', '986') + tlv('54', '%.2f' % valor) + tlv('58', 'BR') + tlv('59', nome[:25]) + tlv('60', 'SAO PAULO') + tlv('62', tlv('05', '***')) + '6304'
    return s + crc16(s)
def qr_png(txt):
    m = cv2.QRCodeEncoder.create().encode(txt); img = cv2.resize(m, (m.shape[1] * 6, m.shape[0] * 6), interpolation=cv2.INTER_NEAREST)
    img = cv2.copyMakeBorder(img, 24, 24, 24, 24, cv2.BORDER_CONSTANT, value=255); ok, buf = cv2.imencode('.png', img); return base64.b64encode(buf.tobytes()).decode()
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def conta(self): return CONTAS.get((self.headers.get('Authorization') or '').replace('Bearer ', ''))
    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == '/__log': return self.send(200, log)
        if u.path == '/__modo': ST['modo'] = q.get('m', ''); return self.send(200, {'ok': True})
        if u.path == '/__aprovar':
            p = pays.get(q.get('id', ''));
            if not p: return self.send(404, {})
            p['status'] = 'approved'; p['status_detail'] = 'accredited'; return self.send(200, {'ok': True})
        if u.path == '/users/me':
            c = self.conta(); return self.send(200, c) if c else self.send(401, {'message': 'invalid access token'})
        if u.path.startswith('/v1/payments/'):
            c = self.conta(); p = pays.get(u.path.rsplit('/', 1)[1])
            if not c: return self.send(401, {'message': 'invalid access token'})
            return self.send(200, {k: v for k, v in p.items() if k != '_conta'}) if p and p['_conta'] == c['id'] else self.send(404, {'message': 'Payment not found'})
        return self.send(404, {})
    def do_POST(self):
        u = urlparse(self.path); n = int(self.headers.get('Content-Length') or 0); b = json.loads(self.rfile.read(n) or b'{}')
        if u.path != '/v1/payments': return self.send(404, {})
        c = self.conta(); k = (self.headers.get('Authorization') or '') + '|' + (self.headers.get('X-Idempotency-Key') or '')
        log.append({'idem': self.headers.get('X-Idempotency-Key'), 'conta': c and c['id'], 'valor': b.get('transaction_amount'), 'ref': b.get('external_reference'), 'notification_url': b.get('notification_url')})
        if not c or ST['modo'] == '401': return self.send(401, {'message': 'invalid access token'})
        if ST['modo'] == '500': return self.send(500, {'message': 'internal_error'})
        if k in idem: return self.send(200, {kk: v for kk, v in pays[idem[k]].items() if kk != '_conta'})
        ST['n'] += 1; pid = str(91000 + ST['n']); idem[k] = pid
        qr = brcode(float(b['transaction_amount']), pid, c['nickname'].replace('_', ' '))
        p = {'id': int(pid), 'status': 'pending', 'status_detail': 'pending_waiting_transfer', 'transaction_amount': b['transaction_amount'], 'currency_id': 'BRL', 'payment_method_id': 'pix',
             'external_reference': b.get('external_reference'), 'description': b.get('description'), 'date_of_expiration': b.get('date_of_expiration'), '_conta': c['id'],
             'point_of_interaction': {'type': 'PIX', 'transaction_data': {'qr_code': qr, 'qr_code_base64': qr_png(qr), 'ticket_url': f'https://www.mercadopago.com.br/payments/{pid}/ticket?caller_id={c["id"]}&hash=dubl'}}}
        pays[pid] = p; return self.send(201, {kk: v for kk, v in p.items() if kk != '_conta'})
ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
