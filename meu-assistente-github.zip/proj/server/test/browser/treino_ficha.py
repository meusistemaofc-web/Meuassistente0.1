# Treino e Acompanhamento — ficha visual no chat (celular e computador, tema escuro e claro): semana com os dias, grupos
# musculares, cartões dos exercícios com as ilustrações de início/fim (carregamento preguiçoso, cache longo, tema),
# séries/repetições/descanso/"Como fazer", marcar concluído e anotar carga (gravados no banco, progresso atualizado),
# dia futuro bloqueado, troca de exercício e carga pelo chat atualizando a ficha já aberta, sem rolagem lateral e sem erros.
# Servidor: PORT=4373 SQLITE_FILE=/tmp/ma-ficha.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE='http://localhost:4373'; DBF='/tmp/ma-ficha.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def db(sql,args=()):
    c=sqlite3.connect(DBF); r=c.execute(sql,args).fetchall(); c.commit(); c.close(); return r
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
def ultima(pg): return pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
def envia(pg,txt):
    n=pg.locator('.chat-scroll .msg-bubble').count()
    pg.locator('textarea.composer-input').fill(txt); pg.wait_for_timeout(150); pg.locator('[aria-label="Enviar"]').click()
    for _ in range(80):
        if pg.locator('.chat-scroll .msg-bubble').count()>=n+2: break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(900); return ultima(pg)
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Ficha','email':'admin@ficha.com','whatsapp':'+55 11 94444-7171',**U}).ok
    u=b.new_context(base_url=BASE); R=u.request
    assert R.post('/api/auth',data={'action':'signup','name':'Atleta Ficha','email':'atleta@ficha.com','whatsapp':'+55 11 94444-7272',**U}).ok
    cv='7a7a7a7a-0000-4111-8222-000000000001'
    for t in ['⚡ Treino e Acompanhamento','quero ganhar massa, sou iniciante','6','na academia','nenhuma']: R.post('/api/chat',data={'text':t,'conversationId':cv,'modo':'treino'})
    uid=db("select id from users where email='atleta@ficha.com'")[0][0]
    check('plano criado pelo chat (6 dias)', db("select count(*) from treino_planos where user_id=? and status='ativo'",(uid,))[0][0]==1)
    hoje=datetime.date.today(); dh=(hoje.isoweekday())%7  # 0=domingo
    st=u.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        svgs=[]; pg.on('response',lambda r: svgs.append((r.url,r.status,r.headers.get('cache-control',''))) if '/api/v2/treino/ilustracao/' in r.url else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(2000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
        r=envia(pg,'Meu treino'); pg.wait_for_selector('.chat-scroll .ma-tr .ma-trx',timeout=15000); pg.wait_for_timeout(1500)
        F=pg.locator('.chat-scroll .ma-tr').last
        k=F.evaluate("""f=>({dias:f.querySelectorAll('.ma-tr-sem button').length,pl:f.querySelectorAll('.ma-tr-sem button.pl').length,sel:(f.querySelector('.ma-tr-sem button.on')||{}).textContent,hj:!!f.querySelector('.ma-tr-sem button.hj.on'),
          grupos:[...f.querySelectorAll('.ma-tr-g')].map(x=>x.textContent),ex:f.querySelectorAll('.ma-trx').length,
          cartoes:[...f.querySelectorAll('.ma-trx')].map(a=>({n:a.querySelector('h5').textContent,m:a.querySelectorAll('.ma-trx-m span').length,p:a.querySelector('.ma-trx-m').textContent,img:a.querySelectorAll('.ma-trx-img img').length,lazy:[...a.querySelectorAll('.ma-trx-img img')].every(i=>i.loading==='lazy'),ok:a.querySelector('[data-tr-ok]')?1:0,kg:a.querySelector('[data-tr-kg]')?1:0,como:!!a.querySelector('details summary')})),
          txt:f.innerText})""")
        check(f'{nome}: resposta curta com o resumo e a ficha (sem marcadores visíveis)', 'Treino A' in r and '⟦' not in r and '⟦' not in k['txt'], r[:200])
        check(f'{nome}: semana com 7 dias, 6 de treino e o dia de hoje selecionado', k['dias']==7 and k['pl']==6 and (k['hj'] or dh==0), k)
        check(f'{nome}: exercícios agrupados por grupo muscular', len(k['grupos'])>=2 and k['ex']>=4, k['grupos'])
        check(f'{nome}: cada cartão tem nome, séries/repetições/descanso, concluir, carga e "Como fazer"', all(x['m']>=2 and '×' in x['p'] and 'descanso' in x['p'] and x['ok'] and x['kg'] and x['como'] for x in k['cartoes']), k['cartoes'][:2])
        check(f'{nome}: ilustrações de início e fim, carregamento preguiçoso', all(x['img'] in (1,2) and x['lazy'] for x in k['cartoes']) and sum(1 for x in k['cartoes'] if x['img']==2)>=3, k['cartoes'])
        F.locator('.ma-trx').first.scroll_into_view_if_needed(); pg.wait_for_timeout(1500)
        im=F.evaluate("f=>[...f.querySelectorAll('.ma-trx')].slice(0,2).flatMap(a=>[...a.querySelectorAll('.ma-trx-img img')]).map(i=>({w:i.naturalWidth,ok:i.classList.contains('ok'),src:i.getAttribute('src')}))")
        check(f'{nome}: as ilustrações carregam (SVG do servidor) com o tema atual e aparecem com transição', im and all(i['w']>0 and i['ok'] and ('&t=escuro' in i['src'] or '&t=claro' in i['src']) for i in im), im)
        check(f'{nome}: ilustração servida com cache longo (immutable)', svgs and all(s[1] in (200,304) for s in svgs) and any('immutable' in s[2] for s in svgs), svgs[:2])
        pg.screenshot(path=f'/tmp/e2e/treino_ficha_{nome}.png', full_page=False)
        F.screenshot(path=f'/tmp/e2e/treino_ficha_card_{nome}.png')
        # marcar concluído e anotar carga (só no 1º contexto, para o 2º ver o que ficou gravado)
        a0=F.locator('.ma-trx').first; n0=a0.locator('h5').inner_text()
        if nome=='celular' and dh!=0:
            a0.locator('[data-tr-ok]').click(); pg.wait_for_timeout(1500)
            reg=db("select concluido from treino_exercicio_registros where user_id=? and nome=?",(uid,n0))
            F=pg.locator('.chat-scroll .ma-tr').last; a0=F.locator('.ma-trx').first
            check(f'{nome}: marcar concluído grava e atualiza o cartão e o progresso', reg and reg[0][0]==1 and a0.locator('[data-tr-ok]').get_attribute('aria-pressed')=='true' and '1 de ' in F.inner_text(), (reg, F.inner_text()[:300]))
            a0.locator('[data-tr-kg]').fill('32,5'); a0.locator('[data-tr-kg]').press('Enter'); pg.wait_for_timeout(1600)
            reg=db("select carga_kg from treino_exercicio_registros where user_id=? and nome=?",(uid,n0)); F=pg.locator('.chat-scroll .ma-tr').last
            check(f'{nome}: carga anotada (vírgula) grava e aparece como "Última"', reg and float(reg[0][0])==32.5 and 'Última: 32,5 kg' in F.locator('.ma-trx').first.inner_text(), (reg, F.locator('.ma-trx').first.inner_text()))
            a0=F.locator('.ma-trx').first; a0.locator('[data-tr-kg]').fill('abc'); a0.locator('[data-tr-kg]').press('Enter'); pg.wait_for_timeout(700)
            check(f'{nome}: carga inválida não grava (aviso e valor anterior de volta)', float(db("select carga_kg from treino_exercicio_registros where user_id=? and nome=?",(uid,n0))[0][0])==32.5 and F.locator('.ma-trx').first.locator('[data-tr-kg]').input_value()=='32,5')
            # dia futuro: só leitura
            fut=F.evaluate("f=>{const b=[...f.querySelectorAll('.ma-tr-sem button.pl')].find(x=>!x.classList.contains('on')&&!x.classList.contains('hj')&&[...f.querySelectorAll('.ma-tr-sem button')].indexOf(x)>[...f.querySelectorAll('.ma-tr-sem button')].findIndex(y=>y.classList.contains('hj')));if(!b)return null;b.click();return true}")
            if fut:
                pg.wait_for_timeout(400); F=pg.locator('.chat-scroll .ma-tr').last
                check(f'{nome}: dia futuro abre os exercícios, mas não deixa marcar', 'ainda não chegou' in F.inner_text() and F.locator('[data-tr-ok]:disabled').count()==F.locator('[data-tr-ok]').count())
            # troca pelo chat: a ficha já aberta acompanha
            n1=F.evaluate("f=>{const h=f.querySelector('.ma-tr-sem button.hj');if(h)h.click();return true}"); pg.wait_for_timeout(300)
            alvo=pg.locator('.chat-scroll .ma-tr').first.locator('.ma-trx').nth(1).locator('h5').inner_text()
            r=envia(pg,f'troque o {alvo.lower()} por flexão de braço'); pg.wait_for_timeout(2500)
            primeira=pg.locator('.chat-scroll .ma-tr').first.inner_text()
            check(f'{nome}: troca pelo chat atualiza a ficha que já estava aberta', 'Troquei' in r and 'Flexão de braço' in primeira and alvo not in primeira, (r[:160], primeira[:400]))
            r=envia(pg,f'fiz {n0.lower()} com 35 kg'); pg.wait_for_timeout(2500)
            v=pg.locator('.chat-scroll .ma-tr').first.locator('.ma-trx',has=pg.locator('h5',has_text=n0)).first.locator('[data-tr-kg]').input_value()
            check(f'{nome}: carga dita no chat aparece na ficha aberta', 'Anotei' in r and v=='35', (r[:160], v))
        # sem rolagem lateral; tema claro troca as cores das ilustrações
        ov=pg.evaluate("()=>document.scrollingElement.scrollWidth-innerWidth"); check(f'{nome}: sem rolagem lateral', ov<=1, ov)
        pg.evaluate("()=>document.documentElement.setAttribute('data-theme','light')"); pg.wait_for_timeout(1200)
        cl=pg.evaluate("()=>[...document.querySelectorAll('.ma-trx-img img')].slice(0,6).map(i=>i.getAttribute('src'))")
        check(f'{nome}: tema claro usa as ilustrações claras', cl and all(s.endswith('&t=claro') for s in cl), cl[:2])
        pg.locator('.chat-scroll .ma-tr').last.locator('.ma-trx').first.scroll_into_view_if_needed(); pg.wait_for_timeout(1200)
        pg.screenshot(path=f'/tmp/e2e/treino_ficha_claro_{nome}.png', full_page=False)
        c.close()
    # isolamento: outra pessoa não vê a ficha nem marca nada
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Outra Pessoa','email':'outra@ficha.com','whatsapp':'+55 11 94444-7373',**U}).ok
    f=O.get('/api/v2/treino/ficha').json(); x=O.post('/api/v2/treino/registro',data={'chave':'agachamento livre','concluido':True})
    check('isolamento: outra pessoa não vê o plano nem marca exercícios', f.get('semPlano') is True and x.status==404)
    check('sem erros de página', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); import sys; sys.exit(0 if all(res) else 1)
