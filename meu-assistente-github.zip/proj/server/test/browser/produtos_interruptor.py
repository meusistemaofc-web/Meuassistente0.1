# Painel de produtos (Sua empresa → Produtos): interruptor ativo/inativo no canto superior direito do card (no lugar de "Pausar"),
# Editar · Duplicar · Excluir numa faixa própria, nada sobre nome/preço/descrição, telas pequenas, e o efeito real na vitrine
# pública: desligar oculta (cadastro intacto), religar devolve, recarregar mantém o estado. Celular (320 e 390 px) e computador.
# Servidor: PORT=4324 SQLITE_FILE=/tmp/ma-tgl.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, base64, os
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4324'; DBF = '/tmp/ma-tgl.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (300, 200), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
LOC = (-9.6658, -35.735)
# sobreposição: nenhuma caixa de ação (interruptor, Editar, Duplicar, Excluir) pode cruzar o nome ou a linha de preço/descrição
SOBRE = """(id)=>{const row=document.querySelector(`[data-prow="${id}"]`);const R=e=>e.getBoundingClientRect();
 const info=[row.querySelector('.ma-prow-nm'),row.querySelector('[data-plinha]')].map(R),acts=[...row.querySelectorAll('[data-pt],[data-pe],[data-pdup],[data-pdl]')].map(R);
 const cruza=(a,b)=>a.left<b.right-0.5&&b.left<a.right-0.5&&a.top<b.bottom-0.5&&b.top<a.bottom-0.5;
 return info.some(a=>acts.some(b=>cruza(a,b)))}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('celular 320', {'width': 320, 'height': 640}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); k = nome.replace(' ', '')
        D = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = D.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Tina', 'whatsapp': {'celular390': '+55 82 94441-0001', 'celular320': '+55 82 94442-0002', 'computador': '+55 82 94443-0003'}[k], 'email': f'tina.{k}@t.com', **U}, headers={'X-Forwarded-For': '10.7.0.' + str(vp['width'] % 250)}).ok
        if k == 'celular390': assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Loja da Tina {k}', 'categoria': 'Decoração', 'titulo': 'x', 'texto': 'x', 'zap': '5582999990000'}); assert r.ok, r.text(); ID = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', lat=?, lng=? where id=?", (LOC[0] + 0.002, LOC[1], ID)); db.commit(); db.close()
        assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        longo = 'Vaso de cerâmica artesanal esmaltado à mão com acabamento fosco e detalhes dourados ' + k
        assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': longo, 'preco': 189.9, 'categoria': 'Decoração de interiores', 'descricao': 'Feito à mão', 'fotos': [durl((150, 90, 60))], 'oferta': {'ativo': True, 'preco': 159.9}}).ok
        assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Almofada ' + k, 'preco': 49.9, 'categoria': 'Têxteis', 'fotos': [durl((60, 90, 150))]}).ok
        its = R.get(f'/api/v2/ads/{ID}/products').json()['items']; VASO = next(x['id'] for x in its if x['nome'].startswith('Vaso')); longo = next(x['nome'] for x in its if x['id'] == VASO); ALM = next(x['id'] for x in its if x['nome'].startswith('Almofada'))
        antes = sqlite3.connect(DBF).execute('select data from products where id=?', (VASO,)).fetchone()[0]
        V = b.new_context(base_url=BASE).request
        vit = lambda: [x['id'] for x in V.get(f'/api/v2/marketplace/produtos?lat={LOC[0]}&lng={LOC[1]}&por=40').json()['items']]
        pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.dismiss())
        def abrir():
            pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=produtos]', timeout=20000); pg.click('.ma-nav [data-nav=produtos]'); pg.wait_for_selector(f'[data-prow="{VASO}"]', timeout=15000); pg.wait_for_timeout(400)
        abrir()
        row = pg.locator(f'[data-prow="{VASO}"]'); sw = row.locator('[data-pt]')
        check(f'{nome}: "Pausar"/"Ativar" sumiram; interruptor no lugar, ligado', 'Pausar' not in row.inner_text() and sw.get_attribute('role') == 'switch' and sw.get_attribute('aria-checked') == 'true' and 'nx-switch' in sw.get_attribute('class'))
        g = pg.evaluate("""(id)=>{const row=document.querySelector(`[data-prow="${id}"]`),R=e=>e.getBoundingClientRect(),rr=R(row),s=R(row.querySelector('[data-pt]')),ac=R(row.querySelector('.ma-prow-ac')),nm=R(row.querySelector('.ma-prow-nm'));
          return {dir:Math.round(rr.right-s.right),topo:Math.round(s.top-rr.top),acima:s.bottom<=ac.top,acLarg:Math.round(ac.width),rowLarg:Math.round(rr.width),nmDireita:nm.right<=s.left,w:Math.round(s.width),h:Math.round(s.height)}}""", VASO)
        check(f'{nome}: interruptor compacto no canto superior direito, acima das ações', g['dir'] <= 20 and g['topo'] <= 18 and g['acima'] and g['nmDireita'] and g['w'] <= 44 and g['h'] <= 26, g)
        check(f'{nome}: Editar · Duplicar · Excluir numa faixa própria', [x.inner_text() for x in row.locator('.ma-prow-ac button').all()] == ['Editar', 'Duplicar', 'Excluir'] and g['acLarg'] >= g['rowLarg'] - 40, g)
        check(f'{nome}: nada sobrepõe nome, preço ou descrição (nome longo)', pg.evaluate(SOBRE, VASO) is False and pg.evaluate(SOBRE, ALM) is False)
        lin = row.locator('[data-plinha]').inner_text()
        check(f'{nome}: imagem e informações preservadas', row.locator('.ma-prow-img').count() == 1 and 'R$' in lin and 'OFERTA' in lin and 'Decoração de interiores' in lin, lin)
        tam = pg.evaluate("[...document.querySelectorAll('.ma-prow-ac button')].map(b=>b.getBoundingClientRect().height)")
        check(f'{nome}: área de toque das ações ≥ 36 px e sem rolagem lateral', min(tam) >= 36 and pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'), tam)
        if k in ('celular390', 'celular320', 'computador'): pg.screenshot(path=f'/tmp/e2e/tgl_{k}.png')
        # desligar
        sw.click(); pg.wait_for_function(f"()=>!document.querySelector('[data-prow=\"{VASO}\"] [data-pt]').hasAttribute('aria-busy')", timeout=10000); pg.wait_for_timeout(200)
        db = sqlite3.connect(DBF); act, dat = db.execute('select active, data from products where id=?', (VASO,)).fetchone(); db.close()
        check(f'{nome}: desligar → inativo no banco, cadastro (fotos, preço, oferta) intacto', act in (0, False) and dat == antes, act)
        check(f'{nome}: indicação discreta de desligado (sem botão "Ativar")', sw.get_attribute('aria-checked') == 'false' and 'off' in row.get_attribute('class') and row.locator('[data-pst]').inner_text() == 'Inativo' and 'Ativar' not in row.inner_text())
        check(f'{nome}: oculto da vitrine pública na hora', VASO not in vit() and ALM in vit())
        if k == 'celular390': pg.screenshot(path='/tmp/e2e/tgl_off.png')
        abrir(); row = pg.locator(f'[data-prow="{VASO}"]'); sw = row.locator('[data-pt]')
        check(f'{nome}: estado mantido ao recarregar', sw.get_attribute('aria-checked') == 'false' and row.locator('[data-pst]').inner_text() == 'Inativo')
        # reativar
        sw.click(); pg.wait_for_function(f"()=>!document.querySelector('[data-prow=\"{VASO}\"] [data-pt]').hasAttribute('aria-busy')", timeout=10000); pg.wait_for_timeout(200)
        check(f'{nome}: religar → ativo e de volta à vitrine', sw.get_attribute('aria-checked') == 'true' and row.locator('[data-pst]').inner_text() == 'Ativo' and VASO in vit())
        it = next(x for x in V.get(f'/api/v2/marketplace/produtos?lat={LOC[0]}&lng={LOC[1]}&por=40').json()['items'] if x['id'] == VASO)
        check(f'{nome}: volta igual (preço da oferta e foto)', it['preco'] == 159.9 and it['emOferta'] and it['foto'], it)
        # editar/duplicar continuam funcionando e o interruptor não abre nada
        row.locator('[data-pe]').click(); pg.wait_for_function("()=>/^Editar/.test((document.querySelector('[data-ptitulo]')||{}).textContent||'')", timeout=8000)  # o formulário de "Novo" já existe na página: espera o de edição
        check(f'{nome}: Editar abre o cadastro do item', pg.input_value('#pn') == longo)
        if k == 'celular390':
            abrir(); pg.locator(f'[data-prow="{ALM}"] [data-pdup]').click(); pg.wait_for_function("()=>/^Duplicar/.test((document.querySelector('[data-ptitulo]')||{}).textContent||'')", timeout=8000)
            check('Duplicar continua abrindo a cópia', 'Duplicar' in pg.inner_text('[data-ptitulo]'))
            abrir(); pg.locator(f'[data-prow="{ALM}"] [data-pdl]').click(); pg.wait_for_timeout(500)
            check('Excluir pede confirmação (cancelado: nada apagado)', pg.locator(f'[data-prow="{ALM}"]').count() == 1)
            # cliques rápidos: o estado final é o último pedido, sem inverter por conta própria
            s2 = pg.locator(f'[data-prow="{ALM}"] [data-pt]'); s2.click(); s2.click(force=True); pg.wait_for_timeout(1200)
            fin = sqlite3.connect(DBF).execute('select active from products where id=?', (ALM,)).fetchone()[0]
            check('clique duplo rápido não deixa a tela diferente do banco', (s2.get_attribute('aria-checked') == 'true') == bool(fin), (s2.get_attribute('aria-checked'), fin))
        D.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
sys.exit(0 if all(res) else 1)
