# Cobranças pelo chat + preenchimento do Anunciar + campo de cupom, de ponta a ponta no navegador (Chromium; celular emulado).
# Mercado Pago: dublê do contrato oficial de pagamentos Pix (mp_pagamentos_fake.py), com BR Code de verdade (CRC16) e QR Code
# de verdade (lido aqui com o OpenCV a partir da imagem mostrada no cartão).
# Servidor: MP_API_BASE=http://127.0.0.1:4396 PORT=4364 SQLITE_FILE=/tmp/ma-cob.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
# Dublê:    python3 test/browser/mp_pagamentos_fake.py 4396
import re, json, sqlite3, urllib.request, numpy as np, cv2
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4364'; FAKE = 'http://127.0.0.1:4396'; DBF = '/tmp/ma-cob.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def fk(p): return json.loads(urllib.request.urlopen(FAKE + p).read() or b'null')
def crc16(s):
    c = 0xFFFF
    for ch in s.encode():
        c ^= ch << 8
        for _ in range(8): c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return '%04X' % c
def tags(s):
    o = {}; i = 0
    while i < len(s): k = s[i:i+2]; n = int(s[i+2:i+4]); o[k] = s[i+4:i+4+n]; i += 4 + n
    return o
def db(sql, a=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, a).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
TOK_A = 'TEST-loja-cobranca-a-1234567890'; TOK_B = 'TEST-loja-cobranca-b-1234567890'
def enviar(pg, txt):
    ta = pg.locator('textarea[data-composer-input]'); ta.fill(txt); ta.press('Enter')
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True, permissions=['clipboard-read', 'clipboard-write']); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Wagner Oficina', 'whatsapp': '+55 11 94444-7171', 'email': 'dono.cob@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True, 'agente': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Oficina do Wagner', 'categoria': 'Serviços', 'titulo': 'x', 'texto': 'Consertos', 'zap': '11988887777', 'endereco': 'Rua A, 1, São Paulo - SP'}); assert r.ok, r.text()
    ID = [x for x in r.json()['items'] if x['empresa'] == 'Oficina do Wagner'][0]['id']
    db("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,))
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(900)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
    print('== sem conexão')
    enviar(pg, 'crie uma cobrança de R$ 10,00'); pg.wait_for_function("()=>/Mercado Pago conectada/.test(document.body.innerText)", timeout=25000); pg.wait_for_timeout(500)
    check('sem conexão: explica que precisa conectar e não mostra cartão, QR nem link', pg.locator('[data-cob-card]').count() == 0 and pg.locator('[data-cob-qr]').count() == 0 and db('select count(*) from cobrancas')[0][0] == 0 and not fk('/__log'))
    check('sem conexão: botão leva para Sua empresa', pg.locator('a[href="/x/sua-empresa"], button:has-text("Abrir Sua empresa")').count() >= 1)
    # conexão manual oficial (Access Token de teste conferido em /users/me)
    assert R.post(f'/api/v2/ads/{ID}/mp', data={'tok': TOK_A}).json().get('ok')
    print('== criação')
    enviar(pg, 'crie uma cobrança de 150 reais para João referente a revisão da moto')
    pg.wait_for_selector('[data-cob-card] [data-cob-qr]', timeout=25000); pg.wait_for_timeout(800)
    card = pg.locator('[data-cob-card]').last; txt = card.inner_text().replace('\xa0', ' '); cid = int(card.get_attribute('data-cob-card'))
    check('cartão: valor, descrição, cliente, status e validade', all(x in txt for x in ['R$ 150,00', 'revisão da moto', 'Para: João', 'Aguardando pagamento', 'Pix válido até', 'Ambiente de teste']), txt)
    row = db('select status, business_id, valor, mp_payment_id, link_token from cobrancas where id=?', (cid,))[0]
    lg = fk('/__log')[-1]
    check('cobrança gravada no banco e criada no Mercado Pago com o token desta empresa', row[0] == 'pendente' and row[1] == ID and float(row[2]) == 150 and row[3] and lg['conta'] == 71001 and lg['idem'] == f'cob-{cid}' and lg['ref'] == f'cob:{cid}' and lg['notification_url'].endswith(f'/api/mercadopago/webhook?store={ID}'), (row, lg))
    cc = card.locator('[data-cob-cc]').inner_text().strip()
    png = card.locator('[data-cob-qr]').screenshot(); img = cv2.imdecode(np.frombuffer(png, np.uint8), cv2.IMREAD_GRAYSCALE)
    lido = cv2.QRCodeDetector().detectAndDecode(img)[0]
    tg = tags(cc)
    check('QR Code da tela é lido e é exatamente o Pix Copia e Cola', lido == cc and len(cc) > 60, (lido[:60], cc[:60]))
    check('BR Code válido: CRC16 confere, valor 150.00, moeda 986, chave Pix (br.gov.bcb.pix)', crc16(cc[:-4]) == cc[-4:] and tg.get('54') == '150.00' and tg.get('53') == '986' and tags(tg['26']).get('00') == 'br.gov.bcb.pix', tg)
    card.locator('[data-cob-copiar]').click(); pg.wait_for_timeout(400)
    check('Copiar código Pix: área de transferência recebe o Copia e Cola', pg.evaluate('navigator.clipboard.readText()') == cc)
    card.locator('[data-cob-share]').click(); pg.wait_for_timeout(400); link = pg.evaluate('navigator.clipboard.readText()')
    check('Compartilhar link (sem compartilhamento nativo): copia o link público', re.search(r'/x/cobranca/[A-Za-z0-9_-]{20,}$', link) and row[4] in link, link)
    pg.evaluate("window.__shared=null;navigator.share=d=>{window.__shared=d;return Promise.resolve()}"); card.locator('[data-cob-share]').click(); pg.wait_for_timeout(300)
    sh = pg.evaluate('window.__shared')
    check('Compartilhar link (celular): abre o compartilhamento com texto e link', sh and sh['url'] == link and 'R$ 150,00' in sh['text'].replace('\xa0', ' '), sh)
    card.locator('[data-cob-ver]').click(); pg.wait_for_selector('[data-cob-publica] [data-cob-qr]', timeout=20000)
    check('Ver cobrança: abre a página da cobrança no app', 'R$ 150,00' in pg.inner_text('[data-cob-publica]').replace('\xa0', ' ') and '/x/cobranca/' in pg.url)
    pg.go_back(); pg.wait_for_selector(f'[data-cob-card="{cid}"]', timeout=20000); card = pg.locator(f'[data-cob-card="{cid}"]').last
    alvos = card.evaluate("e=>[...e.querySelectorAll('button,a')].map(b=>b.getBoundingClientRect().height)")
    check('botões com área de toque ≥ 44px e sem rolagem lateral', min(alvos) >= 43.5 and pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'), alvos)
    card.screenshot(path='/tmp/e2e/cobranca_cartao.png')
    print('== link público (cliente sem conta)')
    P = b.new_context(viewport={'width': 360, 'height': 780}, base_url=BASE, is_mobile=True, has_touch=True); pp = P.new_page(); pp.on('pageerror', lambda e: errs.append(str(e)))
    pp.goto(f'/x/cobranca/{row[4]}'); pp.wait_for_selector('[data-cob-publica] [data-cob-qr]', timeout=20000); pt = pp.inner_text('[data-cob-publica]').replace('\xa0', ' ')
    mp = pp.locator('[data-cob-mp]')
    check('página pública: valor, QR, Copia e Cola e "Abrir no Mercado Pago" (ticket do Mercado Pago)', 'R$ 150,00' in pt and pp.inner_text('[data-cob-cc]').strip() == cc and mp.count() == 1 and mp.get_attribute('href').startswith('https://www.mercadopago.com.br/payments/'), pt)
    check('página pública não mostra número interno nem dados da conta', '#' + str(cid) not in pt and 'TEST-' not in pp.content())
    print('== pagamento confirmado pelo webhook')
    api_pago = pg.evaluate(f"fetch('/api/v2/cobrancas/{cid}',{{method:'PUT',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{status:'pago'}})}}).then(r=>r.status)")
    enviar(pg, 'eu já paguei a cobrança, pode marcar como paga'); pg.wait_for_timeout(2500)
    check('o aplicativo e a mensagem do usuário não marcam como pago', api_pago >= 400 and db('select status from cobrancas where id=?', (cid,))[0][0] == 'pendente', api_pago)
    fk(f'/__aprovar?id={row[3]}')
    wh = urllib.request.urlopen(urllib.request.Request(f'{BASE}/api/mercadopago/webhook?store={ID}&data.id={row[3]}&type=payment', data=json.dumps({'type': 'payment', 'data': {'id': row[3]}}).encode(), headers={'Content-Type': 'application/json'}, method='POST')).status
    pg.wait_for_function(f"()=>{{const c=[...document.querySelectorAll('[data-cob-card=\"{cid}\"]')].pop();return c&&/Pagamento confirmado/.test(c.innerText)}}", timeout=25000)
    check('webhook confirmado na API: cartão do chat vira "Pago" sozinho', wh == 200 and db('select status from cobrancas where id=?', (cid,))[0][0] == 'pago' and pg.locator(f'[data-cob-card="{cid}"] [data-cob-qr]').count() == 0)
    pp.wait_for_function("()=>/Pagamento confirmado/.test(document.body.innerText)", timeout=25000)
    check('página pública também mostra "Pagamento confirmado"', pp.locator('[data-cob-qr]').count() == 0)
    fin = [json.loads(x[0]) for x in db("select data from items where type='expense'")]
    check('entrada lançada uma vez no Financeiro do dono', len([f for f in fin if f.get('source') == f'cobranca:{cid}']) == 1)
    enviar(pg, 'a cobrança foi paga?'); pg.wait_for_function("()=>/paga ✓/.test(document.body.innerText)", timeout=25000)
    check('consulta de status pelo chat', True)
    print('== falha da API e isolamento')
    fk('/__modo?m=500'); n0 = db('select count(*) from cobrancas')[0][0]; nc0 = pg.locator('[data-cob-card]').count()
    enviar(pg, 'gere um pix de 20 reais'); pg.wait_for_function("()=>/instável/.test(document.body.innerText)", timeout=25000); fk('/__modo?m=')
    check('Mercado Pago fora do ar: explica, sem QR nem link', db("select status from cobrancas order by id desc limit 1")[0][0] == 'falhou' and pg.locator('[data-cob-card="%d"]' % db('select max(id) from cobrancas')[0][0]).count() == 0)
    E = b.new_context(base_url=BASE); RE = E.request
    RE.post('/api/auth', data={'action': 'signup', 'name': 'Outra Dona', 'whatsapp': '+55 11 94444-7272', 'email': 'outra.cob@t.com', **U})
    check('outra conta não vê a cobrança', RE.get(f'/api/v2/cobrancas/{cid}').status == 404)
    pg.set_viewport_size({'width': 1280, 'height': 900}); pg.wait_for_timeout(400)
    check('computador: cartão sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    pg.set_viewport_size({'width': 320, 'height': 640}); pg.wait_for_timeout(400)
    check('celular pequeno: cartão sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    # ================= Anunciar: preenchimento automático; campo de cupom na etapa de pagamento =================
    print('== anunciar')
    assert R.post('/api/v2/admin/vouchers', data={'codigo': 'BLACKFRIDAY25', 'descricao': 'Black Friday', 'campanha': 'Black', 'tipo': 'percentual', 'percentual': 25, 'maxUsos': 10, 'maxPorUsuario': 1}).ok
    N = b.new_context(viewport={'width': 320, 'height': 640}, base_url=BASE, is_mobile=True, has_touch=True); RN = N.request
    assert RN.post('/api/auth', data={'action': 'signup', 'name': 'Bruna Costa', 'whatsapp': '+55 85 98888-1234', 'email': 'bruna.ad@t.com', **U}).ok
    # localização salva (no app real vem de "Perto de mim" com o geocodificador; aqui gravada direto porque o contêiner não tem internet)
    uid = db("select id from users where email='bruna.ad@t.com'")[0][0]; db("insert into user_modules (user_id, key, value) values (?, 'location', ?)", (uid, json.dumps({'lat': -3.73, 'lng': -38.52, 'label': 'Av. Beira Mar, 100, Fortaleza - CE', 'manual': True})))
    ap = N.new_page(); ap.on('pageerror', lambda e: errs.append(str(e)))
    def abrir():
        ap.goto('/x/anunciar'); ap.wait_for_selector('#adf [data-prefill]', timeout=20000); ap.wait_for_timeout(500)
        ap.locator('#adf label:has(input[name="planId"][value="n4"])').click(); ap.wait_for_timeout(800)
        return ap.evaluate("()=>Object.fromEntries([...document.querySelectorAll('#adf input[name]')].map(i=>[i.name,i.value]))")
    v = abrir()
    check('preenche nome, WhatsApp e endereço com os dados do perfil', v.get('contato') == 'Bruna Costa' and v.get('zap') == '5585988881234' and 'Av. Beira Mar, 100, Fortaleza - CE' in ap.inner_text('[data-end-antigo]'), v)
    check('aviso: preenchido do perfil, editável, não muda o cadastro', ap.locator('[data-prefill-aviso]').count() == 1 and 'não muda o seu cadastro' in ap.inner_text('[data-prefill-aviso]'))
    ap.fill('#adf input[name="zap"]', '5585977776666'); ap.fill('#adf input[name="contato"]', 'Bruna Doces')
    check('campos editáveis', ap.input_value('#adf input[name="zap"]') == '5585977776666' and ap.input_value('#adf input[name="contato"]') == 'Bruna Doces')
    me = RN.get('/api/me').json(); mes = json.dumps(me, ensure_ascii=False)
    check('editar o anúncio não altera o cadastro', 'Bruna Costa' in mes and '97777' not in mes and 'Bruna Doces' not in mes)
    RN.patch('/api/me', data={'profile': {'name': 'Bruna Costa Lima', 'whatsapp': '+55 85 96666-5555'}})
    v = abrir()
    check('perfil alterado: nova criação usa os dados novos', v.get('contato') == 'Bruna Costa Lima' and v.get('zap') == '5585966665555', v)
    check('"Seus dados": e-mail e telefone da conta preenchidos', v.get('respEmail') == 'bruna.ad@t.com' and v.get('respTel') == '(85) 96666-5555', v)
    check('"Atualizar também meus dados de perfil" escondido enquanto nada mudou', not ap.locator('[data-resp-perfil]').is_visible())
    ap.fill('#adf input[name="contato"]', 'Bruna C. Lima'); ap.wait_for_timeout(200)
    check('editar o nome mostra a opção discreta de atualizar o perfil (desmarcada)', ap.locator('[data-resp-perfil]').is_visible() and not ap.is_checked('[name=atualizarPerfil]'))
    check('primeira etapa sem "Tenho um cupom"', ap.locator('#adf [data-cup-abrir]').count() == 0)
    # cupom: agora na etapa de pagamento (Sua empresa)
    ad = RN.post('/api/v2/ads', data={'planId': 'n1', 'empresa': 'Doces da Bruna', 'categoria': 'Doces', 'titulo': 'Doces', 'texto': 'x'}); assert ad.ok, ad.text()
    ap.goto('/x/sua-empresa'); ap.wait_for_selector('[data-cupom-anuncio] [data-cup-abrir]', timeout=20000); ap.wait_for_timeout(500)
    ap.click('[data-cup-abrir]'); ap.click('[data-cup-cod]'); ap.keyboard.type('blackfriday25', delay=25)
    d = ap.evaluate("""()=>{const e=document.querySelector('[data-cup-cod]'),cs=getComputedStyle(e),r=e.getBoundingClientRect();return {v:e.value,w:r.width,sw:e.scrollWidth,cw:e.clientWidth,color:cs.color,fill:cs.webkitTextFillColor,bg:cs.backgroundColor,fs:cs.fontSize}}""")
    check('cupom: cada caractere visível ao digitar (campo inteiro, sem cortar o código)', d['v'] == 'BLACKFRIDAY25' and d['sw'] <= d['cw'] + 1 and d['w'] >= 200 and d['fs'] == '16px', d)
    def lum(c):
        n = [int(x) for x in re.findall(r'[\d.]+', c)[:3]]; f = lambda x: (x / 255) / 12.92 if x / 255 <= 0.03928 else (((x / 255) + 0.055) / 1.055) ** 2.4
        return 0.2126 * f(n[0]) + 0.7152 * f(n[1]) + 0.0722 * f(n[2])
    ct = (max(lum(d['fill']), lum(d['bg'])) + .05) / (min(lum(d['fill']), lum(d['bg'])) + .05)
    check(f'cupom: contraste do texto ≥ 4,5:1 (medido {ct:.1f}:1)', ct >= 4.5, d)
    ap.keyboard.press('Backspace'); ap.keyboard.press('Backspace'); ap.keyboard.type('25')
    ap.locator('[data-cup]').screenshot(path='/tmp/e2e/cupom_corrigido_320.png')
    check('cupom: apagar e editar funciona', ap.input_value('[data-cup-cod]') == 'BLACKFRIDAY25')
    ap.click('[data-cup-aplicar]'); ap.wait_for_timeout(2000); cm = ap.inner_text('[data-cupom-anuncio]')
    check('cupom: aplicar funciona e mostra o desconto', '25%' in cm or 'Cupom aplicado' in cm, cm)
    check('sem erros de JavaScript (fora o aviso #418 de hidratação já existente)', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
