# Galeria do detalhe do produto no catálogo (/x/empresa/:id → toque no produto), celular (toque) e computador (mouse):
#   - Foto principal INTEIRA: object-fit contain, sem corte nem distorção, com fotos de proporções diferentes (paisagem, retrato).
#   - Deslize horizontal (swipe) entre as fotos com rolagem suave (scroll-snap), pontinhos de posição e contador atualizando.
#   - Miniaturas selecionáveis levam à foto (sem recarregar o detalhe); setas só no computador; teclado (← →).
#   - Preço, variações e "Adicionar" continuam iguais; foto única = sem pontinhos/miniaturas; sem rolagem lateral da página.
# Servidor: PORT=4407 SQLITE_FILE=/tmp/ma-galprod.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, io, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4407'; DBF = '/tmp/ma-galprod.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
def foto(cor, w, h):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
F = [foto((200, 60, 60), 800, 400), foto((60, 120, 200), 300, 600), foto((60, 160, 90), 500, 500)]  # paisagem 2:1, retrato 1:2, quadrada
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Gal', 'whatsapp': '+55 11 94444-0701', 'email': 'admin.gal@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Loja', 'whatsapp': '+55 11 95555-0702', 'email': 'dona.gal@t.com', **U}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Loja da Galeria', 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5511955550702', 'tipo': 'produtos', 'endereco': 'Rua G, 7'}).json()['items'][0]['id']
    db("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}})
    mk = lambda d: [x for x in R.post(f'/api/v2/ads/{ID}/products', data=d).json()['items'] if x['nome'] == d['nome']][0]['id']
    P3 = mk({'nome': 'Luminária Arco', 'preco': 189.9, 'categoria': 'Casa', 'fotos': F, 'descricao': 'Três fotos com proporções diferentes.'})
    P1 = mk({'nome': 'Vaso Simples', 'preco': 39.9, 'categoria': 'Casa', 'fotos': [F[1]]})
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        c = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob); pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(f'/x/empresa/{ID}'); pg.wait_for_selector(f'[data-prod="{P3}"]', timeout=20000); pg.wait_for_timeout(600)
        pg.locator(f'[data-prod="{P3}"]').click(); pg.wait_for_selector('[data-gal] img', timeout=8000)
        pg.wait_for_function("[...document.querySelectorAll('[data-gal] img')].every(i=>i.complete&&i.naturalWidth>0)", timeout=8000); pg.wait_for_timeout(300)
        geo = pg.evaluate("""()=>[...document.querySelectorAll('[data-gal] img')].map(i=>{const r=i.getBoundingClientRect(),s=getComputedStyle(i),k=Math.min(r.width/i.naturalWidth,r.height/i.naturalHeight);
            return {fit:s.objectFit,nw:i.naturalWidth,nh:i.naturalHeight,bw:r.width,bh:r.height,vw:i.naturalWidth*k,vh:i.naturalHeight*k}})""")
        check(f'{nome}: fotos inteiras (contain), sem corte nem distorção, em paisagem, retrato e quadrada', len(geo) == 3 and all(g['fit'] == 'contain' and g['vw'] <= g['bw'] + .5 and g['vh'] <= g['bh'] + .5 for g in geo) and abs(geo[0]['vw'] / geo[0]['vh'] - 2) < .02 and abs(geo[1]['vw'] / geo[1]['vh'] - .5) < .02, geo)
        st = lambda: pg.evaluate("()=>({i:Math.round(document.querySelector('[data-gal]').scrollLeft/document.querySelector('[data-gal]').clientWidth),dots:[...document.querySelectorAll('[data-gal-dots] i')].findIndex(d=>d.classList.contains('on')),cont:document.querySelector('[data-gal-cont]').textContent,th:[...document.querySelectorAll('[data-fi]')].findIndex(t=>t.classList.contains('on')),vimg:document.querySelector('[data-vimg]').dataset.gi,snap:getComputedStyle(document.querySelector('[data-gal]')).scrollSnapType})")
        s0 = st(); check(f'{nome}: abre na 1ª foto com pontinhos, contador "1/3" e miniatura marcada; rolagem com encaixe (scroll-snap)', s0['i'] == 0 and s0['dots'] == 0 and s0['cont'] == '1/3' and s0['th'] == 0 and 'mandatory' in s0['snap'], s0)
        if mob:
            g = pg.locator('[data-gal]').bounding_box(); y = g['y'] + g['height'] / 2
            # deslize com o dedo: rolagem horizontal real do carrossel (o encaixe leva para a próxima foto)
            pg.evaluate("()=>document.querySelector('[data-gal]').scrollBy({left:document.querySelector('[data-gal]').clientWidth*0.7,behavior:'smooth'})")
            pg.wait_for_timeout(900); s1 = st()
            check(f'{nome}: deslizar vai para a 2ª foto e atualiza pontinhos, contador e miniatura', s1['i'] == 1 and s1['dots'] == 1 and s1['cont'] == '2/3' and s1['th'] == 1 and s1['vimg'] == '1', s1)
            check(f'{nome}: setas ocultas no toque', not pg.locator('[data-gal-next]').is_visible())
        else:
            pg.hover('[data-gal]'); pg.wait_for_timeout(300); pg.click('[data-gal-next]'); pg.wait_for_timeout(900); s1 = st()
            check(f'{nome}: seta "próxima" (no mouse) vai para a 2ª foto com transição suave', s1['i'] == 1 and s1['dots'] == 1 and s1['cont'] == '2/3' and pg.evaluate("getComputedStyle(document.querySelector('[data-gal]')).scrollBehavior") == 'smooth', s1)
            pg.focus('[data-gal]'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(900); s1b = st()
            check(f'{nome}: teclado (→) vai para a 3ª foto e a seta "próxima" some no fim', s1b['i'] == 2 and pg.is_disabled('[data-gal-next]'), s1b)
        det0 = pg.evaluate("document.querySelector('[data-detalhe]')")
        pg.click('[data-fi="0"]'); pg.wait_for_timeout(900); s2 = st()
        check(f'{nome}: miniatura leva à foto sem recarregar o detalhe', s2['i'] == 0 and s2['th'] == 0 and s2['cont'] == '1/3' and pg.evaluate("document.querySelector('[data-detalhe]')") == det0, s2)
        info = pg.evaluate("()=>({preco:document.querySelector('[data-preco]').innerText.replace(/\\u00a0/g,' '),add:!!document.querySelector('[data-detalhe] [data-addp], [data-detalhe] button.btn-send, .btn-send[data-addp]'),ow:document.documentElement.scrollWidth-innerWidth})")
        check(f'{nome}: preço e botão de adicionar intactos; página sem rolagem lateral', 'R$ 189,90' in info['preco'] and info['ow'] <= 1, info)
        ov = pg.evaluate("()=>{const a=document.querySelector('[data-gal-cont]').getBoundingClientRect();return [...document.querySelectorAll('button')].filter(b=>/fechar/i.test(b.getAttribute('aria-label')||'')).some(b=>{const r=b.getBoundingClientRect();return r.width&&!(r.right<a.left||r.left>a.right||r.bottom<a.top||r.top>a.bottom)})}")
        check(f'{nome}: contador não fica por cima do botão de fechar', not ov)
        pg.screenshot(path=f'/tmp/e2e/galeria_produto_{nome}.png')
        # adicionar continua funcionando
        btn = pg.locator('[data-detalhe] button:has-text("Adicionar"), button:has-text("Adicionar")').last
        if btn.count(): btn.click(); pg.wait_for_timeout(700)
        check(f'{nome}: adicionar ao pedido continua funcionando', pg.locator('.ma-cartbar').count() == 1 or 'Ver pedido' in pg.inner_text('body'))
        # produto com uma foto só: sem pontinhos, miniaturas ou setas
        pg.keyboard.press('Escape'); pg.wait_for_timeout(500)
        if pg.locator('[data-gal]').count(): pg.goto(f'/x/empresa/{ID}'); pg.wait_for_selector(f'[data-prod="{P1}"]', timeout=20000)
        pg.locator(f'[data-prod="{P1}"]').click(); pg.wait_for_selector('[data-gal] img', timeout=8000); pg.wait_for_timeout(400)
        check(f'{nome}: foto única sem pontinhos, contador, setas nem miniaturas (e inteira)', pg.locator('[data-gal-dots]').count() == 0 and pg.locator('[data-fi]').count() == 0 and pg.locator('[data-gal-next]').count() == 0 and pg.evaluate("getComputedStyle(document.querySelector('[data-gal] img')).objectFit") == 'contain')
        c.close()
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
