# Treinos: frequência interpretada como a pessoa pediu, progressão por fases e ficha modernizada.
#   - Pelo chat: "de segunda a sexta" = 5 dias (seg a sex, não "segunda e sexta"); "todos os dias" = 7; "dia sim, dia não"
#     = seg/qua/sex; "3 vezes por semana, de segunda a sexta" = 3 dias espaçados; "segunda e sexta" = 2 dias.
#   - Iniciante com 5 dias: 4 treinos + 1 "Recuperação ativa" (sem dois dias pesados iguais seguidos).
#   - Ficha (celular escuro / computador claro): frequência por extenso, fase do ciclo (semana X de 8, linha das fases),
#     etapas (Aquecimento → Treino principal → Para fechar), exercícios numerados com "séries × reps", ajuste da fase
#     ("+1 série nesta fase"), ilustrações v2 carregadas (início e final com trajetória), dia de recuperação sem campo
#     de carga, concluir continua funcionando, sem rolagem lateral e sem erros.
# Servidor: PORT=4405 SQLITE_FILE=/tmp/ma-trfreq.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4405'; DBF = '/tmp/ma-trfreq.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def envia(pg, txt):
    n = pg.locator('.chat-scroll .msg-bubble').count()
    pg.locator('textarea.composer-input').fill(txt); pg.wait_for_timeout(150); pg.locator('[aria-label="Enviar"]').click()
    for _ in range(80):
        if pg.locator('.chat-scroll .msg-bubble').count() >= n + 2: break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(900)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    adm = b.new_context(base_url=BASE); assert adm.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Freq', 'email': 'admin@freq.com', 'whatsapp': '+55 11 94444-8101', **U}).ok
    def plano(email, zap, falas):
        c = b.new_context(base_url=BASE); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Atleta ' + email.split('@')[0], 'email': email, 'whatsapp': zap, **U}).ok
        cv = '7b7b7b7b-0000-4111-8222-' + str(abs(hash(email)) % 10**12).zfill(12)
        ult = None
        for t in ['⚡ Treino e Acompanhamento'] + falas: ult = R.post('/api/chat', data={'text': t, 'conversationId': cv, 'modo': 'treino'}).json()
        uid = db('select id from users where email=?', (email,))[0][0]
        r = db("select plano from treino_planos where user_id=? and status='ativo'", (uid,))
        return c, uid, (json.loads(r[0][0]) if r else None), ult
    casos = [
        ('seg.sex@t.com', '+55 11 94444-8111', ['quero ganhar massa, sou iniciante', 'de segunda a sexta, 50 minutos', 'na academia', 'nenhuma'], [1, 2, 3, 4, 5], 'segunda a sexta = 5 dias (seg, ter, qua, qui, sex)'),
        ('todos@t.com', '+55 11 94444-8112', ['quero ganhar massa, treino há 3 anos', 'todos os dias', 'na academia', 'nenhuma'], [0, 1, 2, 3, 4, 5, 6], 'todos os dias = 7 dias'),
        ('alt@t.com', '+55 11 94444-8113', ['quero emagrecer, sou iniciante', 'dia sim, dia não', 'em casa sem equipamentos', 'nenhuma'], [1, 3, 5], 'dia sim, dia não = segunda, quarta e sexta'),
        ('tres@t.com', '+55 11 94444-8114', ['quero saúde, sou iniciante', '3 vezes por semana, de segunda a sexta', 'em casa sem equipamentos', 'nenhuma'], [1, 3, 5], '3 vezes entre segunda e sexta = 3 dias espaçados'),
        ('dois@t.com', '+55 11 94444-8115', ['quero ganhar força, sou iniciante', 'segunda e sexta', 'na academia', 'nenhuma'], [1, 5], 'segunda e sexta = só esses 2 dias'),
    ]
    ctx1 = None
    for email, zap, falas, esp, rot in casos:
        c, uid, pl, ult = plano(email, zap, falas)
        dias = sorted(d['dia'] for d in pl['dias']) if pl else None
        check(f'chat: {rot}', dias == sorted(esp), (dias, (ult or {}).get('reply', '')[:160] if isinstance(ult, dict) else ult))
        if email == 'seg.sex@t.com':
            ctx1, uid1 = c, uid
            tit = {d['dia']: d['titulo'] for d in pl['dias']}
            check('iniciante 5 dias: 4 treinos + Recuperação ativa na quarta (sem 2 dias pesados iguais seguidos)', 'Recuperação' in tit[3] and sum('Recuperação' in t for t in tit.values()) == 1, tit)
            rep = json.dumps(ult, ensure_ascii=False)
            check('resposta do chat diz a frequência por extenso e a evolução em fases', 'de segunda a sexta (5 dias)' in rep and 'Evolução em 8 semanas' in rep, rep[:300])
        else: c.close()
    # progressão: plano criado há 5 semanas → semana 6 (fase Progressão do iniciante: +1 série nos principais)
    ini = (datetime.date.today() - datetime.timedelta(weeks=5)).isoformat() + 'T10:00:00Z'
    db("update treino_planos set criado_em=? where user_id=? and status='ativo'", (ini, uid1))
    st = ctx1.storage_state(); ctx1.close()
    for i, (nome, vp, mob, tema) in enumerate([('celular', {'width': 390, 'height': 844}, True, 'dark'), ('computador', {'width': 1280, 'height': 900}, False, 'light')]):
        print('==', nome, tema)
        c = b.new_context(viewport=vp, base_url=BASE, storage_state=st, is_mobile=mob, has_touch=mob); c.request.patch('/api/me', data={'settings': {'theme': tema}})
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1500)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
        envia(pg, 'Meu treino'); pg.wait_for_selector('.chat-scroll .ma-tr .ma-trx', timeout=15000); pg.wait_for_timeout(1200)
        F = pg.locator('.chat-scroll .ma-tr').last
        F.locator('[data-tr-dia="1"]').click(); pg.wait_for_timeout(400)  # segunda (treino pesado)
        for a in range(2): F.locator('.ma-trx').nth(a).scroll_into_view_if_needed(); pg.wait_for_timeout(250)
        pg.wait_for_function("(()=>{const im=[...document.querySelectorAll('.chat-scroll .ma-tr')].pop().querySelectorAll('.ma-trx-img img');return im.length>=4&&[...im].slice(0,4).every(i=>i.complete&&i.naturalWidth>0)})()", timeout=10000)
        k = F.evaluate("""f=>({freq:(f.querySelector('[data-tr-freq]')||{}).textContent,fase:(f.querySelector('[data-tr-fase]')||{}).innerText,linha:f.querySelectorAll('.ma-tr-linha i').length,atual:[...f.querySelectorAll('.ma-tr-linha i')].findIndex(i=>i.classList.contains('atual')),
          etapas:[...f.querySelectorAll('.ma-tr-et')].map(e=>e.textContent),nums:[...f.querySelectorAll('.ma-trx-num')].map(n=>n.textContent),
          presc:[...f.querySelectorAll('[data-tr-presc]')].map(p=>p.textContent),aj:f.querySelectorAll('[data-tr-fase-aj]').length,
          imgs:[...f.querySelectorAll('.ma-trx-img img')].map(i=>({src:i.getAttribute('src'),w:i.naturalWidth})),grupos:[...f.querySelectorAll('.ma-tr-g')].map(g=>g.textContent)})""")
        check(f'{nome}: frequência por extenso na ficha', k['freq'] and 'de segunda a sexta (5 dias)' in k['freq'], k['freq'])
        check(f'{nome}: fase do ciclo (semana 6 de 8, Progressão) com a linha das 8 semanas', k['fase'] and 'Progressão' in k['fase'] and 'Semana 6 de 8' in k['fase'] and k['linha'] == 8 and k['atual'] == 5, (k['fase'], k['linha'], k['atual']))
        check(f'{nome}: etapas do treino (Aquecimento → Treino principal → Para fechar)', [e[1:] for e in k['etapas']] == ['Aquecimento', 'Treino principal', 'Para fechar'], k['etapas'])
        check(f'{nome}: exercícios numerados e agrupados por grupo muscular', k['nums'][:3] == ['1', '2', '3'] and len(k['grupos']) >= 2, (k['nums'], k['grupos']))
        check(f'{nome}: prescrição "séries × reps" e ajuste da fase nos principais (+1 série)', all('×' in x for x in k['presc']) and k['aj'] >= 1 and any('+1 série nesta fase' in x for x in k['presc']), k['presc'][:3])
        check(f'{nome}: ilustrações v2 (início e final) carregadas', len(k['imgs']) >= 4 and all('v=2' in x['src'] and x['w'] > 0 for x in k['imgs'][:4]), k['imgs'][:2])
        # dia de recuperação: leve, sem campo de carga e sem a caixa da fase
        F.locator('[data-tr-dia="3"]').click(); pg.wait_for_timeout(400)
        r = F.evaluate("f=>({t:f.querySelector('.ma-tr-dia h4').textContent,kg:f.querySelectorAll('[data-tr-kg]').length,fase:!!f.querySelector('[data-tr-fase]'),et:[...f.querySelectorAll('.ma-tr-et')].map(e=>e.textContent.slice(1))})")
        check(f'{nome}: quarta é Recuperação ativa (sem carga, sem fase)', 'Recuperação ativa' in r['t'] and r['kg'] == 0 and not r['fase'] and 'Recuperação' in r['et'], r)
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: sem rolagem lateral', ow <= 1, ow)
        F.locator('[data-tr-dia="1"]').click(); pg.wait_for_timeout(300)
        F.locator('.ma-trx').first.scroll_into_view_if_needed(); pg.wait_for_timeout(300)
        pg.screenshot(path=f'/tmp/e2e/treino_ficha_{nome}.png')
        c.close()
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
