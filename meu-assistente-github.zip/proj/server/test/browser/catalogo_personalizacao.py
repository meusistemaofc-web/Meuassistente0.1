# Personalização visual do catálogo + avaliações no Google, de ponta a ponta no navegador (Chromium; celular/tablet emulados):
# • catálogo publicado: logo à esquerda/centro/direita, formatos original/circular/arredondado (sem distorção, logo larga
#   encaixada), tamanho P/M/G e livre (limitado em tela pequena), botões retangular/arredondado/cápsula, preenchido/contorno,
#   compacto/padrão/grande; sem rolagem lateral; áreas de toque; carrinho continua funcionando;
# • editor (Sua empresa → Ajustes → Tema do catálogo): prévia é o CATÁLOGO REAL num quadro, muda na hora e NÃO salva sozinha;
#   salvar persiste no banco (outra sessão sem cache vê), recarregar mantém, "Restaurar padrão" pede confirmação e não
#   apaga logo, capa, produtos; outra empresa não é afetada;
# • avaliações: seção Reputação (link inválido recusado, salvar, testar abre o link, ativar, mensagem), cartão no chat
#   (avaliar aqui + "Avaliar também no Google" em nova aba com o link certo, clique contado, não vira avaliação),
#   Meus pedidos com o botão, e com o Google desligado a avaliação interna continua.
# Servidor: PORT=4362 SQLITE_FILE=/tmp/ma-pers.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, re, json, base64, sqlite3
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4362'; DBF = '/tmp/ma-pers.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def durl(cor, w=240, h=240):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
PAD = {'preset': 'padrao', 'cor': '#3b6cff', 'fundo': 'escuro', 'layout': 'lista', 'cantos': 'arredondado', 'logoPos': 'esquerda', 'logoForma': 'arredondado', 'logoTam': 64, 'botaoForma': 'capsula', 'botaoEstilo': 'preenchido', 'botaoTam': 'padrao'}
LINK = 'https://g.page/r/CpizzaTeste123/review'
MED = """()=>{const r=e=>{if(!e)return null;const x=e.getBoundingClientRect();return {l:x.left,r:x.right,t:x.top,b:x.bottom,w:x.width,h:x.height}};const q=s=>document.querySelector(s);
 const im=q('.ma-emp-logo img'),cs=im&&getComputedStyle(im),add=q('[data-add]'),bs=[...document.querySelectorAll('.btn-send')].filter(b=>b.offsetParent&&!b.matches('[data-cat]'));
 return {hd:r(q('.ma-emp-hd')),id:r(q('.ma-emp-id')),logo:r(im||q('.ma-emp-logo>span')),tx:r(q('.ma-emp-tx')),rad:cs&&cs.borderTopLeftRadius,fit:cs&&cs.objectFit,nat:im&&[im.naturalWidth,im.naturalHeight],
  larga:im&&im.classList.contains('ma-logo-larga'),sw:document.documentElement.scrollWidth,vw:innerWidth,
  add:add&&{r:r(add),rad:getComputedStyle(add).borderTopLeftRadius,bg:getComputedStyle(add).backgroundColor,bw:getComputedStyle(add).borderTopWidth},
  cats:[...document.querySelectorAll('[data-cat]')].map(c=>r(c).h),root:(q('[data-ma-catalogo]')||{}).dataset||null,
  alvos:bs.map(b=>Math.min(r(b).w,r(b).h)),nProd:document.querySelectorAll('[data-prod],[data-book]').length}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono Teste', 'whatsapp': '+55 11 94444-5151', 'email': 'dono.pers@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True, 'agente': True}).ok
    ids = []
    for emp, logo in [('Pizzaria Teste', durl((200, 60, 40))), ('Doceria Vizinha', durl((40, 120, 200)))]:
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': emp, 'categoria': 'Restaurantes', 'titulo': 'x', 'texto': 'Comida boa', 'zap': '11988887777', 'endereco': 'Rua A, 1, São Paulo - SP'}); assert r.ok, r.text()
        ids.append([x for x in r.json()['items'] if x['empresa'] == emp][0]['id'])
    ID, ID2 = ids
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id in (?,?)", (ID, ID2)); db.commit(); db.close()
    for i, cor in [(ID, (200, 60, 40)), (ID2, (40, 120, 200))]:
        assert R.put(f'/api/v2/ads/{i}', data={'logo': durl(cor), 'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}, 'categorias': ['Pizzas', 'Bebidas']}).ok
    for nome, preco, cat in [('Margherita', 45, 'Pizzas'), ('Calabresa', 49, 'Pizzas'), ('Guaraná', 12, 'Bebidas')]:
        assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': nome, 'preco': preco, 'categoria': cat, 'fotos': [durl((120, 90, 60))]}).ok
    assert R.post(f'/api/v2/ads/{ID2}/products', data={'nome': 'Brigadeiro', 'preco': 5, 'categoria': 'Pizzas', 'fotos': [durl((90, 50, 30))]}).ok
    assert R.put(f'/api/v2/ads/{ID2}', data={'tema': {**PAD, 'logoPos': 'esquerda'}}).ok
    prods0 = json.dumps(R.get(f'/api/v2/ads/{ID}/products').json()['items'], sort_keys=True)
    def tema(t): r = R.put(f'/api/v2/ads/{ID}', data={'tema': {**PAD, **t}}); assert r.ok, r.text()
    def abrir(pg, i=ID):
        pg.goto(f'/x/empresa/{i}'); pg.wait_for_selector('[data-prod]', timeout=20000); pg.wait_for_timeout(1200); return pg.evaluate(MED)
    # ================= catálogo publicado (visitante sem login, sem cache local) =================
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('celular pequeno', {'width': 320, 'height': 640}, True), ('tablet', {'width': 820, 'height': 1180}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        V = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pg = V.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        for pos in ['esquerda', 'centro', 'direita']:
            tema({'logoPos': pos}); d = abrir(pg)
            if pos == 'esquerda': ok = d['logo']['r'] <= d['tx']['l'] and abs(d['logo']['l'] - d['hd']['l']) < 40
            elif pos == 'centro': ok = abs((d['logo']['l'] + d['logo']['r']) / 2 - (d['hd']['l'] + d['hd']['r']) / 2) < 4 and d['tx']['t'] >= d['logo']['b'] - 1
            else: ok = d['logo']['l'] >= d['tx']['r'] and abs(d['logo']['r'] - d['hd']['r']) < 40
            check(f'{nome}: logo {pos}', ok and d['sw'] <= d['vw'] + 1, (d['logo'], d['tx'], d['hd'], d['sw'], d['vw']))
        for forma, rad in [('circular', '50%'), ('arredondado', '22%'), ('original', '0px')]:
            tema({'logoForma': forma, 'logoTam': 72}); d = abrir(pg)
            esperado = d['logo']['w'] * (0.5 if forma == 'circular' else 0.22) if forma != 'original' else 0
            rr = float(re.sub('[^0-9.]', '', d['rad'] or '0') or 0); rr = rr * d['logo']['w'] / 100 if '%' in (d['rad'] or '') else rr
            semDist = abs(d['logo']['w'] / d['logo']['h'] - d['nat'][0] / d['nat'][1]) < 0.03 if forma == 'original' else abs(d['logo']['w'] - d['logo']['h']) < 1
            check(f'{nome}: logo {forma} sem distorção', abs(rr - esperado) < 2 and semDist, (d['rad'], d['logo'], d['nat']))
        for tam in [56, 72, 96, 112]:
            tema({'logoTam': tam}); d = abrir(pg); alvo = min(tam, d['vw'] * 0.30)
            check(f'{nome}: logo {tam}px → {round(alvo)}px (limitada a 30% da tela)', abs(d['logo']['w'] - alvo) < 1.5 and d['sw'] <= d['vw'] + 1, (d['logo'], alvo))
        for forma, px in [('retangular', 7.2), ('arredondado', 14.4)]:
            tema({'botaoForma': forma}); d = abrir(pg)
            check(f'{nome}: botões {forma}', abs(float(d['add']['rad'].replace('px', '')) - px) < 0.6, d['add'])
        tema({'botaoForma': 'capsula'}); d = abrir(pg); check(f'{nome}: botões cápsula', float(d['add']['rad'].replace('px', '')) >= d['add']['r']['h'] / 2 - 0.5, d['add'])
        tema({'botaoEstilo': 'contorno'}); d = abrir(pg)
        check(f'{nome}: botões contorno (sem fundo, borda na cor do tema)', d['add']['bg'] in ('rgba(0, 0, 0, 0)', 'transparent') and float(d['add']['bw'].replace('px', '')) >= 1, d['add'])  # 1,5px vira 1px em telas de densidade 1
        for bt, h in [('compacto', 40), ('grande', 50)]:
            tema({'botaoTam': bt}); d = abrir(pg)
            check(f'{nome}: botões {bt} ({h}px) e categorias não esticam', abs(d['add']['r']['h'] - h) < 0.6 and len(set(round(x) for x in d['cats'])) == 1, (d['add'], d['cats']))
        tema({'botaoTam': 'compacto', 'botaoForma': 'retangular', 'botaoEstilo': 'contorno', 'logoPos': 'centro', 'logoTam': 112}); d = abrir(pg)
        check(f'{nome}: combinação extrema — área de toque ≥ 40px e sem rolagem lateral', d['alvos'] and min(d['alvos']) >= 39.5 and d['sw'] <= d['vw'] + 1, (d['alvos'], d['sw'], d['vw']))
        pg.locator('[data-add]').first.click(); pg.wait_for_timeout(700)
        check(f'{nome}: carrinho continua funcionando com o visual personalizado', pg.locator('.ma-cartbar').count() > 0 and pg.locator('.ma-cartbar').first.is_visible())
        if nome in ('celular', 'computador'): pg.screenshot(path=f'/tmp/e2e/catalogo_personalizado_{nome}.png')
        d2 = abrir(pg, ID2); check(f'{nome}: outra empresa não é afetada (logo à esquerda, cápsula)', d2['root'] and d2['root'].get('maLogoPos') == 'esquerda' and d2['root'].get('maBtnForma') == 'capsula', d2['root'])
        V.close()
    # logo larga (não quadrada) encaixada no formato, sem corte
    assert R.put(f'/api/v2/ads/{ID}', data={'logo': durl((30, 30, 30), 480, 160)}).ok
    V = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); pg = V.new_page()
    tema({'logoForma': 'circular', 'logoTam': 72}); d = abrir(pg)
    check('logo larga em formato circular: encaixada inteira (contain), sem corte nem distorção', d['larga'] and d['fit'] == 'contain' and abs(d['logo']['w'] - d['logo']['h']) < 1, d)
    tema({'logoForma': 'original', 'logoTam': 72}); d = abrir(pg)
    check('logo larga em formato original: inteira, sem corte nem distorção (contain; largura limitada a 2,6× a altura)', d['fit'] == 'contain' and 2.5 <= d['logo']['w'] / d['logo']['h'] <= 3.01 and d['sw'] <= d['vw'] + 1, (d['logo'], d['fit']))
    V.close(); assert R.put(f'/api/v2/ads/{ID}', data={'logo': durl((200, 60, 40))}).ok
    # ================= editor com prévia real =================
    print('== editor')
    assert R.put('/api/v2/empresas/contexto', data={'businessId': ID}).ok  # empresa escolhida no painel (o mesmo que o seletor de empresas faz)
    tema({}); pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    def editor():
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav', timeout=20000); pg.wait_for_timeout(800)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
        if pg.locator(f'[data-loja="{ID}"],[data-bid="{ID}"]').count(): pg.locator(f'[data-loja="{ID}"],[data-bid="{ID}"]').first.click(); pg.wait_for_timeout(600)
        if not pg.locator('[data-lt2="tema"]').count(): pg.locator('.ma-nav [data-nav="mais"], .ma-nav button:has-text("Ajustes"), .ma-nav a:has-text("Ajustes")').first.click()
        pg.wait_for_selector('[data-lt2="tema"]', timeout=15000); pg.click('[data-lt2="tema"]'); pg.wait_for_selector('#tprev-real', timeout=15000)
        fr = pg.frame_locator('#tprev-real'); fr.locator('[data-prod]').first.wait_for(timeout=20000); pg.wait_for_timeout(900)
        return pg.frames[-1] if len(pg.frames) > 1 else None
    def fmed():
        f = [x for x in pg.frames if '/x/empresa/' in x.url][0]; return f.evaluate(MED)
    editor()
    hdr = pg.evaluate("()=>[...document.querySelectorAll('h2')].map(h=>h.textContent)")
    check('editor organizado em Logo, Botões e Cores e layout', all(x in hdr for x in ['Logo', 'Botões', 'Cores e layout']), hdr)
    check('prévia é o catálogo real da empresa (quadro com /x/empresa/ID)', f'/x/empresa/{ID}' in pg.get_attribute('#tprev-real', 'src'))
    pg.click('[data-tk="logoPos"][data-tv="centro"]'); pg.wait_for_timeout(500); d = fmed()
    check('prévia: logo vai para o centro na hora', abs((d['logo']['l'] + d['logo']['r']) / 2 - (d['hd']['l'] + d['hd']['r']) / 2) < 4, (d['logo'], d['hd']))
    pg.click('[data-tk="logoForma"][data-tv="circular"]'); pg.click('[data-tam="96"]'); pg.click('[data-tk="botaoForma"][data-tv="retangular"]'); pg.click('[data-tk="botaoEstilo"][data-tv="contorno"]'); pg.wait_for_timeout(500); d = fmed()
    check('prévia: formato, tamanho e botões aplicados antes de salvar', d['rad'] == '50%' and abs(d['logo']['w'] - min(96, d['vw'] * .3)) < 1.5 and d['add']['rad'] == '7.2px' and float(d['add']['bw'].replace('px', '')) >= 1 and d['add']['bg'] in ('rgba(0, 0, 0, 0)', 'transparent'), d)
    pg.fill('#tl', '104'); pg.dispatch_event('#tl', 'input'); pg.wait_for_timeout(400)
    check('controle deslizante 48–112 com valor mostrado', pg.inner_text('#tlv') == '104 px' and pg.get_attribute('#tl', 'min') == '48' and pg.get_attribute('#tl', 'max') == '112')
    pub = b.new_context(base_url=BASE).request
    check('prévia NÃO salva: catálogo público continua com o padrão', pub.get(f'/api/v2/theme/{ID}').json()['tema']['logoPos'] == 'esquerda')
    pg.click('#tsave'); pg.wait_for_timeout(1200)
    t = pub.get(f'/api/v2/theme/{ID}').json()['tema']
    check('salvar: tema gravado no banco (visto por outra sessão, sem cache local)', t['logoPos'] == 'centro' and t['logoForma'] == 'circular' and t['logoTam'] == 104 and t['botaoForma'] == 'retangular' and t['botaoEstilo'] == 'contorno', t)
    editor()
    sel = pg.evaluate("()=>[...document.querySelectorAll('[data-tk][aria-checked=true]')].map(b=>b.dataset.tk+'='+b.dataset.tv)")
    check('recarregar: editor mostra o que foi salvo', all(x in sel for x in ['logoPos=centro', 'logoForma=circular', 'botaoForma=retangular', 'botaoEstilo=contorno']) and pg.input_value('#tl') == '104', sel)
    V = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE); pv = V.new_page(); d = abrir(pv)
    check('catálogo publicado aplica o tema salvo (novo navegador)', d['root'].get('maLogoPos') == 'centro' and d['root'].get('maLogoForma') == 'circular', d['root']); V.close()
    # sair e entrar: continua
    D2 = b.new_context(base_url=BASE); R2 = D2.request; R2.post('/api/auth', data={'action': 'login', 'email': 'dono.pers@t.com', 'password': U['password']})
    check('depois de sair e entrar de novo, o tema continua', [x for x in R2.get('/api/v2/ads/mine').json()['items'] if x['id'] == ID][0]['tema']['logoPos'] == 'centro'); D2.close()
    # restaurar padrão
    pg.click('#treset'); pg.wait_for_timeout(500)
    conf = pg.locator('#trok').count() > 0 and 'Não apaga sua logo' in pg.inner_text('body')
    pg.click('#trno'); pg.wait_for_timeout(400)
    check('restaurar pede confirmação e cancelar não muda nada', conf and pub.get(f'/api/v2/theme/{ID}').json()['tema']['logoPos'] == 'centro')
    pg.click('#treset'); pg.wait_for_timeout(400); pg.click('#trok'); pg.wait_for_timeout(1200)
    t = pub.get(f'/api/v2/theme/{ID}').json()['tema']; mine = [x for x in R.get('/api/v2/ads/mine').json()['items'] if x['id'] == ID][0]
    check('restaurar: visual volta ao padrão', all(t[k] == v for k, v in PAD.items()), t)
    check('restaurar: logo, produtos e dados da empresa preservados', mine['logo'] and '/imagem/logo?h=' in mine['logo'] and R.get(mine['logo']).headers.get('content-type','').startswith('image/png') and json.dumps(R.get(f'/api/v2/ads/{ID}/products').json()['items'], sort_keys=True) == prods0 and mine['empresa'] == 'Pizzaria Teste')
    check('outra empresa não foi tocada pelo editor', pub.get(f'/api/v2/theme/{ID2}').json()['tema']['logoPos'] == 'esquerda')
    pg.set_viewport_size({'width': 320, 'height': 640}); pg.wait_for_timeout(500)
    check('editor no celular pequeno: sem rolagem lateral e opções com área de toque ≥ 36px', pg.evaluate("()=>document.documentElement.scrollWidth<=innerWidth+1&&[...document.querySelectorAll('[data-tk],[data-tam]')].every(b=>b.getBoundingClientRect().height>=36)"))
    pg.set_viewport_size({'width': 390, 'height': 844})
    # empresa ainda não publicada: prévia com os mesmos componentes e estilos do catálogo (sem quadro), mudando na hora
    db = sqlite3.connect(DBF); db.execute("update businesses set status='pendente' where id=?", (ID2,)); db.commit()
    R.put('/api/v2/empresas/contexto', data={'businessId': ID2}); pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav', timeout=20000); pg.wait_for_timeout(800)
    if not pg.locator('[data-lt2="tema"]').count(): pg.locator('.ma-nav [data-nav="mais"], .ma-nav button:has-text("Ajustes"), .ma-nav a:has-text("Ajustes")').first.click()
    pg.wait_for_selector('[data-lt2="tema"]', timeout=15000); pg.click('[data-lt2="tema"]'); pg.wait_for_selector('#tprev', timeout=15000)
    sem = pg.locator('#tprev-real').count() == 0
    pg.click('[data-tk="logoPos"][data-tv="direita"]'); pg.click('[data-tk="botaoEstilo"][data-tv="contorno"]'); pg.wait_for_timeout(300)
    d = pg.evaluate("()=>{const p=document.querySelector('#tprev'),l=p.querySelector('.ma-emp-logo').getBoundingClientRect(),t=p.querySelector('.ma-emp-tx').getBoundingClientRect(),bt=p.querySelector('.btn-send.w-11')||p.querySelector('.btn-send');return {pos:p.dataset.maLogoPos,dir:l.left>=t.right,bg:getComputedStyle(bt).backgroundColor}}")
    check('empresa ainda não publicada: prévia com os componentes do catálogo muda na hora', sem and d['pos'] == 'direita' and d['dir'] and d['bg'] in ('rgba(0, 0, 0, 0)', 'transparent'), d)
    db.execute("update businesses set status='ativo' where id=?", (ID2,)); db.commit(); db.close(); R.put('/api/v2/empresas/contexto', data={'businessId': ID})
    # ================= avaliações: reputação no painel =================
    print('== reputação')
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav', timeout=20000); pg.wait_for_timeout(600)
    if not pg.locator('[data-lt2="reputacao"]').count(): pg.locator('.ma-nav [data-nav="mais"], .ma-nav button:has-text("Ajustes"), .ma-nav a:has-text("Ajustes")').first.click()
    pg.wait_for_selector('[data-lt2="reputacao"]', timeout=15000); pg.click('[data-lt2="reputacao"]'); pg.wait_for_selector('#rep_url', timeout=15000)
    check('Reputação mostra avaliações internas sempre ativas', 'Sempre ativas' in pg.inner_text('[data-rep-interna]'))
    pg.fill('#rep_url', 'https://facebook.com/pizzaria'); pg.click('#rep_salvar'); pg.wait_for_timeout(700)
    check('link de outro site é recusado com explicação', pg.inner_text('#rep_er').strip() != '' and R.get(f'/api/v2/ads/{ID}/reputacao').json()['reputacao']['google']['url'] == '', pg.inner_text('#rep_er'))
    pg.fill('#rep_url', LINK); pg.click('#rep_salvar'); pg.wait_for_timeout(900)
    check('link válido salvo para esta empresa', R.get(f'/api/v2/ads/{ID}/reputacao').json()['reputacao']['google']['url'] == LINK and R.get(f'/api/v2/ads/{ID2}/reputacao').json()['reputacao']['google']['url'] == '')
    D.route('https://g.page/**', lambda rt: rt.fulfill(body='<title>Google (dublê)</title>', content_type='text/html'))
    with pg.expect_popup() as pop: pg.click('#rep_testar')
    check('"Testar link" abre exatamente o link cadastrado', pop.value.url == LINK, pop.value.url); pop.value.close()
    pg.click('[data-sw="rep-ativo"]'); pg.wait_for_timeout(900)
    check('chave liga o convite do Google', R.get(f'/api/v2/ads/{ID}/reputacao').json()['reputacao']['google']['ativo'] is True)
    pg.fill('#rep_conv', 'Ganhe 10% de desconto avaliando!'); pg.click('#rep_csalvar'); pg.wait_for_timeout(700)
    check('mensagem com benefício é recusada', pg.inner_text('#rep_cer').strip() != '', pg.inner_text('#rep_cer'))
    pg.fill('#rep_conv', 'Como foi sua experiência com a {empresa}? Sua opinião ajuda outras pessoas.'); pg.click('#rep_csalvar'); pg.wait_for_timeout(800)
    check('mensagem neutra salva', 'opinião ajuda' in R.get(f'/api/v2/ads/{ID}/reputacao').json()['reputacao']['convite'])
    # ================= cliente: chat e Meus pedidos =================
    print('== cliente')
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); RC = C.request
    r = RC.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Ana', 'whatsapp': '+55 11 95555-6161', 'email': 'ana.pers@t.com', **U}); assert r.ok, r.text()
    prod = [x for x in R.get(f'/api/v2/ads/{ID}/products').json()['items']][0]
    def pedido():
        o = RC.post(f'/api/v2/businesses/{ID}/orders', data={'itens': [{'pid': prod['id'], 'qtd': 1, 'escolhas': {}}], 'modo': 'retirada', 'pagamento': 'dinheiro'}); assert o.ok, o.text(); oid = o.json()['order']['id']
        for st in ['aceito', 'preparo', 'pronto', 'concluido']: assert R.post(f'/api/v2/ads/{ID}/orders/{oid}', data={'status': st}).ok
        return oid
    oid = pedido()
    C.route('https://g.page/**', lambda rt: rt.fulfill(body='<title>Google (dublê)</title>', content_type='text/html'))
    cp = C.new_page(); cp.on('pageerror', lambda e: errs.append(str(e)))
    cp.goto('/'); cp.wait_for_selector('textarea.composer-input', timeout=20000); cp.wait_for_timeout(900)
    if cp.locator('button:has-text("Agora não")').count(): cp.locator('button:has-text("Agora não")').first.click()
    ta = cp.locator('textarea[data-composer-input]'); ta.fill('recebi meu pedido, quero avaliar'); ta.press('Enter')
    cp.wait_for_selector(f'[data-rev-card="{oid}"]', timeout=25000); cp.wait_for_timeout(500)
    card = cp.locator(f'[data-rev-card="{oid}"]'); txt = card.inner_text()
    check('chat: cartão de avaliação do pedido concluído, com avaliar aqui e o Google opcional', 'Pizzaria Teste' in txt and card.locator('[data-rev-chat]').count() == 1 and 'Avaliar também no Google' in txt, txt)
    g = card.locator('[data-google-aval]')
    check('botão do Google: link certo, nova aba, sem repassar dados', g.get_attribute('href') == LINK and g.get_attribute('target') == '_blank' and 'noopener' in (g.get_attribute('rel') or ''))
    falas = cp.inner_text('.chat-scroll') if cp.locator('.chat-scroll').count() else cp.inner_text('body')
    check('nada diz que a avaliação foi publicada no Google', not re.search(r'publicad[ao] no Google|avaliação (foi )?enviada ao Google', falas, re.I))
    n0 = R.get(f'/api/v2/ads/{ID}/reputacao').json(); rv0 = sqlite3.connect(DBF).execute('select count(*) from reviews').fetchone()[0]
    with cp.expect_popup() as pop: g.click()
    check('Google só abre no toque, no link da empresa', pop.value.url == LINK, pop.value.url); pop.value.close(); cp.wait_for_timeout(900)
    n1 = R.get(f'/api/v2/ads/{ID}/reputacao').json(); rv1 = sqlite3.connect(DBF).execute('select count(*) from reviews').fetchone()[0]
    check('toque contado como clique (não como avaliação)', n1['cliquesGoogle30d'] == n0['cliquesGoogle30d'] + 1 and rv1 == rv0, (n0['cliquesGoogle30d'], n1['cliquesGoogle30d'], rv0, rv1))
    card.locator('[data-rev-chat]').click(); cp.wait_for_selector('[data-aval-sheet]', timeout=8000); cp.click('[data-aval-sheet] [data-n="2"]'); cp.fill('#rvc', 'Demorou um pouco'); cp.click('#rvs'); cp.wait_for_timeout(1200)
    sh = cp.inner_text('[data-aval-sheet]') if cp.locator('[data-aval-sheet]').count() else ''
    check('nota baixa também recebe o mesmo convite neutro (sem filtrar insatisfeitos)', 'registrada no Meu Assistente' in sh and 'Avaliar também no Google' in sh, sh)
    row = sqlite3.connect(DBF).execute('select rating, comment, origem from reviews where order_id=?', (oid,)).fetchone()
    check('avaliação interna gravada (nota e comentário)', row == (2, 'Demorou um pouco', 'cliente'), row)
    cp.keyboard.press('Escape'); cp.wait_for_timeout(400)
    cp.goto('/x/pedidos'); cp.wait_for_timeout(2500)
    check('Meus pedidos: botão do Google com o link certo', cp.locator(f'[data-google-aval][href="{LINK}"]').count() >= 1)
    # Google desligado: interno continua
    R.put(f'/api/v2/ads/{ID}/reputacao', data={'ativo': False}); oid2 = pedido()
    cp.goto('/'); cp.wait_for_selector('textarea.composer-input', timeout=20000); cp.wait_for_timeout(700)
    ta = cp.locator('textarea[data-composer-input]'); ta.fill('quero avaliar meu pedido'); ta.press('Enter')
    cp.wait_for_selector(f'[data-rev-card="{oid2}"]', timeout=25000); cp.wait_for_timeout(500); card = cp.locator(f'[data-rev-card="{oid2}"]')
    check('Google desligado: cartão sem o botão do Google, avaliação interna disponível', card.locator('[data-google-aval]').count() == 0 and card.locator('[data-rev-chat]').count() == 1, card.inner_text())
    cp.set_viewport_size({'width': 320, 'height': 640}); cp.wait_for_timeout(400)
    check('cartão no celular pequeno sem rolagem lateral', cp.evaluate('()=>document.documentElement.scrollWidth<=innerWidth+1'))
    cp.screenshot(path='/tmp/e2e/avaliacao_chat.png')
    check('sem erros de JavaScript (fora o aviso #418 de hidratação já existente, filtrado como nos demais testes)', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
