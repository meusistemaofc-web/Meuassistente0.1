# Imagens da pesquisa DENTRO das respostas do chat, pela tela real (25/11). O app e o servidor são os reais; os PROVEDORES
# (API da Wikipédia/Wikimedia e SearXNG) são dublês locais que servem imagens PNG reais — sem internet nesta máquina,
# portanto isto NÃO comprova os provedores reais, e sim todo o caminho do app: decisão, busca, verificação, proxy
# assinado, renderização, atribuição, ampliação, falha de carregamento, histórico e responsividade (celular e computador).
# Servidor: CEREBRO_PERMITIR_REDE_LOCAL=1 PORT=4357 SQLITE_FILE=/tmp/ma-img.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
import json, re, sqlite3, struct, threading, time, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4357'; DB = '/tmp/ma-img.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def png(w, h, cor):  # PNG verdadeiro (gradiente), gerado aqui
    lin = b''.join(b'\x00' + bytes(sum(([min(255, cor[0] + x // 4), min(255, cor[1] + y // 4), cor[2]] for x in range(w)), [])) for y in range(h))
    ch = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(lin)) + ch(b'IEND', b'')
IMGS = {'tim1.png': png(480, 600, (40, 20, 90)), 'tim2.png': png(640, 420, (120, 30, 30)), 'tim3.png': png(600, 600, (20, 90, 60))}
class F(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def j(self, o):
        d = json.dumps(o).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(d))); self.end_headers(); self.wfile.write(d)
    def do_GET(self):
        u = urlparse(self.path); qs = {k: v[0] for k, v in parse_qs(u.query).items()}; b = f'http://127.0.0.1:{self.server.server_port}'
        if u.path.startswith('/img/'):
            d = IMGS.get(u.path[5:])
            if not d: self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header('Content-Type', 'image/png'); self.send_header('Content-Length', str(len(d))); self.end_headers(); self.wfile.write(d); return
        if u.path == '/w/api.php':
            if 'gsrsearch' in qs: return self.j({'query': {'pages': {'1': {'pageid': 1, 'index': 1, 'title': 'Tim Maia', 'fullurl': 'https://pt.wikipedia.org/wiki/Tim_Maia', 'pageimage': 'Tim_Maia_1972.jpg'}}}} if 'tim maia' in qs['gsrsearch'].lower() else {'query': {'pages': {}}})
            if qs.get('prop') == 'images': return self.j({'query': {'pages': {'1': {'title': 'Tim Maia', 'images': [{'title': 'Ficheiro:Tim Maia 1972.jpg'}, {'title': 'Ficheiro:Tim Maia no palco.jpg'}, {'title': 'Ficheiro:Flag of Brazil.svg'}]}}}})
            if qs.get('prop') == 'imageinfo':
                pages = {}
                for i, t in enumerate(qs.get('titles', '').split('|')):
                    n = t.replace('File:', ''); a = 'tim1.png' if '1972' in n else 'tim2.png'; w, h = (480, 600) if a == 'tim1.png' else (640, 420)
                    pages[str(-1 - i)] = {'title': 'Ficheiro:' + n, 'imageinfo': [{'url': f'{b}/img/{a}', 'thumburl': f'{b}/img/{a}', 'thumbwidth': w, 'thumbheight': h, 'width': w, 'height': h, 'mime': 'image/jpeg', 'descriptionurl': 'https://commons.wikimedia.org/wiki/File:' + n.replace(' ', '_'),
                        'extmetadata': {'Artist': {'value': 'Arquivo Nacional'}, 'LicenseShortName': {'value': 'Domínio público'}, 'LicenseUrl': {'value': 'https://creativecommons.org/publicdomain/mark/1.0/'}} if '1972' in n else {}}]}
                return self.j({'query': {'pages': pages}})
            return self.j({'query': {}})
        if u.path == '/search':
            if qs.get('categories') == 'images' and 'tim maia' in qs.get('q', '').lower():
                return self.j({'results': [{'img_src': f'{b}/img/tim3.png', 'url': 'https://musica.com.br/artistas/tim-maia', 'title': 'Tim Maia em 1980', 'resolution': '600 x 600', 'engine': 'google images'}]})
            return self.j({'results': []})
        self.send_response(404); self.end_headers()
fk = ThreadingHTTPServer(('127.0.0.1', 0), F); threading.Thread(target=fk.serve_forever, daemon=True).start(); FB = f'http://127.0.0.1:{fk.server_port}'
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    # administrador aponta Wikipédia e SearXNG para os dublês (pelo painel/API real)
    A = b.new_context(base_url=BASE).request; em = f'admimg.{int(time.time())}@t.com'
    assert A.post('/api/auth', data={'action': 'signup', 'name': 'Admin Imagens', 'whatsapp': '+55 11 94444-1212', 'email': em, **U}, headers={'X-Forwarded-For': '10.9.6.1'}).ok
    c = sqlite3.connect(DB); c.execute("UPDATE users SET role='superadmin' WHERE email=?", (em,)); c.commit(); c.close()
    A.post('/api/auth', data={'action': 'logout'}); assert A.post('/api/auth', data={'action': 'login', 'email': em, 'password': U['password']}, headers={'X-Forwarded-For': '10.9.6.1'}).ok
    pv = A.get('/api/brain/providers').json()['provedores']
    for x in pv:
        if x['provedor'] in ('wikipedia', 'searxng'): A.put(f"/api/brain/providers/{x['id']}", data={'url': FB, 'ativo': True})
        elif x.get('tipo') == 'busca': A.put(f"/api/brain/providers/{x['id']}", data={'ativo': False})
    for nome, vp, mob, k in [('celular (emulação iPhone no Chromium)', {'width': 390, 'height': 844}, True, 7), ('computador', {'width': 1280, 'height': 900}, False, 8)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, user_agent=('Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1' if mob else None)); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Img Teste', 'whatsapp': f'+55 11 93333-{k}{k}{k}{k}', 'email': f'img{k}.{int(time.time())}@t.com', **U}, headers={'X-Forwarded-For': f'10.9.5.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        externas = []; pg.on('request', lambda r: externas.append(r.url) if ('127.0.0.1:%d' % fk.server_port) in r.url else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        ta = pg.locator('textarea[data-composer-input]')
        def enviar(t):
            n = pg.locator('.chat-scroll .msg-bubble:not(.bubble-user)').count(); ta.click(); ta.fill(t); ta.press('Enter')
            pg.wait_for_function(f"document.querySelectorAll('.chat-scroll .msg-bubble:not(.bubble-user)').length>{n}", timeout=20000); pg.wait_for_timeout(1200)
            return pg.locator('.chat-scroll .msg-bubble:not(.bubble-user)').last
        bub = enviar('Quem foi Tim Maia?')
        pg.wait_for_timeout(1500); pg.screenshot(path=f'/tmp/imagens_chat_{k}.png')
        try: pg.wait_for_function("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble:not(.bubble-user)')].pop();const i=b&&b.querySelector('.ma-img-f.ok img');return i&&i.naturalWidth>0}", timeout=10000); ok = True
        except Exception: ok = False
        info = bub.evaluate("""b=>{const w=b.querySelector('.ma-img');if(!w)return null;const f=w.querySelector('.ma-img-f img'),r=f.getBoundingClientRect(),br=b.getBoundingClientRect(),txt=[...b.children].find(e=>e.tagName==='P'&&e.textContent.trim());
          return {nat:f.naturalWidth,src:f.getAttribute('src'),galeria:w.querySelectorAll('.ma-img-g .ma-img-f').length,legenda:w.querySelector('.ma-img-c').innerText,links:[...w.querySelectorAll('a')].map(a=>[a.href,a.rel]),
          antesDoTexto:!!txt&&!!(w.compareDocumentPosition(txt)&Node.DOCUMENT_POSITION_FOLLOWING),dentro:r.left>=br.left-1&&r.right<=br.right+1,largura:Math.round(r.width),altura:Math.round(r.height),texto:b.innerText.slice(0,200)}}""")
        check(f'{nome}: imagem principal carregada DENTRO da resposta', ok and info and info['nat'] > 0, info)
        if info:
            check(f'{nome}: vem do proxy assinado do servidor (nunca direto do site)', re.match(r'^/api/v2/imagens/ver\?u=[^&]+&s=[a-f0-9]{32}$', info['src']) and not externas, (info['src'], externas[:2]))
            check(f'{nome}: imagem no topo, antes do texto, sem estourar a bolha ({info["largura"]}×{info["altura"]} px)', info['antesDoTexto'] and info['dentro'] and info['altura'] <= 362, info)
            check(f'{nome}: galeria pequena com 2 imagens adicionais relevantes', info['galeria'] == 2, info)
            check(f'{nome}: legenda com origem, autor e licença informados pela fonte', 'Wikimedia Commons' in info['legenda'] and 'Arquivo Nacional' in info['legenda'] and 'Domínio público' in info['legenda'], info['legenda'])
            check(f'{nome}: links externos seguros (nova aba, noopener/noreferrer)', all('noopener' in r and 'noreferrer' in r for _, r in info['links']) and any('commons.wikimedia.org' in h for h, _ in info['links']), info['links'])
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        bub.locator('.ma-img > .ma-img-f').click(); pg.wait_for_selector('.ma-img-v img', timeout=3000)
        check(f'{nome}: toque amplia a imagem com a origem', pg.evaluate("(()=>{const v=document.querySelector('.ma-img-v');return !!v&&v.innerText.includes('Origem')&&v.querySelector('img').complete})()"))
        pg.keyboard.press('Escape') if not mob else pg.locator('.ma-img-v button').click(); pg.wait_for_timeout(200)
        check(f'{nome}: visualizador fecha', not pg.locator('.ma-img-v').count())
        b2 = enviar('Quantas horas tem 4 dias?')
        check(f'{nome}: pergunta de cálculo não traz imagem', b2.locator('.ma-img').count() == 0 and '96 horas' in b2.inner_text(), b2.inner_text()[:80])
        # histórico: recarregar mantém as imagens na conversa
        pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000)
        try: pg.wait_for_function("()=>{const i=document.querySelector('.chat-scroll .ma-img-f.ok img');return i&&i.naturalWidth>0}", timeout=10000); hist = True
        except Exception: hist = False
        check(f'{nome}: histórico preserva as imagens depois de recarregar', hist)
        # falha de carregamento (rede bloqueada para as imagens): oferece a página de origem, sem imagem quebrada
        pg.route('**/api/v2/imagens/ver*', lambda r: r.abort()); pg.reload(); pg.wait_for_selector('textarea.composer-input', timeout=20000)
        try: pg.wait_for_selector('.chat-scroll .ma-img-x', timeout=8000); fb = pg.evaluate("(()=>{const x=document.querySelector('.chat-scroll .ma-img-x');return {t:x.innerText,h:x.getAttribute('href'),thumbs:document.querySelectorAll('.chat-scroll .ma-img-g .ma-img-f').length,quebradas:[...document.querySelectorAll('.chat-scroll .ma-img img')].length}})()")
        except Exception: fb = None
        check(f'{nome}: imagem que não abre vira link para a página de origem', fb and 'abrir a página de origem' in fb['t'] and 'commons.wikimedia.org' in (fb['h'] or '') and fb['thumbs'] == 0 and fb['quebradas'] == 0, fb)
        pg.unroute('**/api/v2/imagens/ver*'); C.close()
    check('sem erros de JavaScript na página (fora o aviso #418 de hidratação, já conhecido)', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs[:3])
    b.close()
fk.shutdown()
print(f'{sum(res)}/{len(res)} verificações')
