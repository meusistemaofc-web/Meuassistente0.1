# Endereço da empresa por partes no cadastro do anúncio (celular): CEP preenche rua, bairro, cidade e UF; falta só o número;
# complemento e ponto de referência opcionais; CEP não encontrado e incompleto; validação; prévia; edição com endereço antigo
# (só texto) mostrando o aviso e mantendo-o; página pública com o ponto de referência.
# Servidor: CEP_URL=http://127.0.0.1:4419/ws/{cep}/json/ PORT=4377 SQLITE_FILE=/tmp/ma-end.db npx tsx test/serve-sqlite.ts
import json, sqlite3, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4377'; DBF = '/tmp/ma-end.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
CEPS = {'60150160': {'cep': '60150-160', 'logradouro': 'Avenida Santos Dumont', 'bairro': 'Aldeota', 'localidade': 'Fortaleza', 'uf': 'CE'},
        '01310100': {'cep': '01310-100', 'logradouro': 'Avenida Paulista', 'bairro': 'Bela Vista', 'localidade': 'São Paulo', 'uf': 'SP'}}
class H(BaseHTTPRequestHandler):  # fonte de CEP de teste (formato ViaCEP)
    def do_GET(self):
        cep = self.path.split('/')[2] if self.path.startswith('/ws/') else ''
        body = json.dumps(CEPS.get(cep, {'erro': True})).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
srv = HTTPServer(('127.0.0.1', 4419), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
MOB = {'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'base_url': BASE}
N = lambda t: str(t).replace('\xa0', ' ')
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(**MOB); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Rita', 'whatsapp': '+55 85 94444-1234', 'email': 'rita.end@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/anunciar'); pg.wait_for_selector('#adf', timeout=20000); pg.wait_for_timeout(800)
    pg.locator('label:has([name=planId][value=n4])').click(); pg.wait_for_timeout(300)
    E = lambda k: pg.locator(f'[data-end="{k}"]')
    check('campos de endereço: CEP, rua, número, complemento, bairro, cidade, UF e ponto de referência', all(E(k).is_visible() for k in ['cep', 'rua', 'numero', 'complemento', 'bairro', 'cidade', 'uf', 'referencia']))
    check('ponto de referência e complemento marcados como opcionais', 'Ponto de referência (opcional)' in pg.inner_text('[data-endbox]') and 'Complemento (opcional)' in pg.inner_text('[data-endbox]'))
    # CEP não encontrado e incompleto
    E('cep').fill('99999990'); pg.wait_for_function("document.querySelector('#cepmsg').textContent.length>0", timeout=8000); pg.wait_for_timeout(200)
    check('CEP não encontrado: mensagem clara (sem preencher nada)', 'Não encontramos esse CEP' in pg.inner_text('#cepmsg') and E('rua').input_value() == '', pg.inner_text('#cepmsg'))
    E('cep').fill('6015'); E('cep').blur(); pg.wait_for_timeout(200)
    check('CEP incompleto ao sair do campo: aviso', 'incompleto' in pg.inner_text('#cepmsg'))
    # CEP válido: digitação com máscara
    E('cep').fill(''); E('cep').press_sequentially('60150160', delay=30); pg.wait_for_function("/Falta só o número/.test(document.querySelector('#cepmsg').textContent)", timeout=8000)
    check('máscara do CEP (60150-160)', E('cep').input_value() == '60150-160', E('cep').input_value())
    check('CEP preencheu rua, bairro, cidade e UF', [E(k).input_value() for k in ['rua', 'bairro', 'cidade', 'uf']] == ['Avenida Santos Dumont', 'Aldeota', 'Fortaleza', 'CE'])
    check('foco vai para o número', pg.evaluate("document.activeElement.dataset.end") == 'numero')
    pg.screenshot(path='/tmp/e2e/end_cep.png', full_page=False)
    # validação: sem número
    for k, v in {'empresa': 'Café da Rita', 'categoria': 'Cafeteria', 'titulo': 'Café', 'texto': 'Café coado', 'contato': 'Rita', 'zap': '5585999990000'}.items(): pg.fill(f'[name={k}]', v)
    pg.locator('#adf button[type=submit]').click(); pg.wait_for_timeout(400)
    check('sem número: não envia e avisa', 'número' in pg.inner_text('#aderr') and pg.evaluate("document.activeElement.dataset.end") == 'numero', pg.inner_text('#aderr'))
    E('numero').fill('1789'); E('complemento').fill('Sala 4'); E('referencia').fill('Ao lado da farmácia'); pg.wait_for_timeout(200)
    check('UF aceita só letras maiúsculas', (E('uf').fill('ce1'), pg.wait_for_timeout(50), E('uf').input_value())[2] in ('CE',))
    check('sem rolagem horizontal no formulário', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    pg.locator('[data-endbox]').screenshot(path='/tmp/e2e/end_campos.png')
    pg.locator('#adf button[type=submit]').click(); pg.wait_for_timeout(2500)
    mine = R.get('/api/v2/ads/mine').json()['items']; ad = next((x for x in mine if x['empresa'] == 'Café da Rita'), None)
    check('salvou o endereço montado e as partes', ad and ad['endereco'] == 'Avenida Santos Dumont, 1789 - Sala 4, Aldeota, Fortaleza - CE, 60150-160' and ad['enderecoPartes']['numero'] == '1789' and ad['referencia'] == 'Ao lado da farmácia', ad and (ad['endereco'], ad.get('enderecoPartes')))
    ID = ad['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    # página pública com referência
    C = b.new_context(**MOB); pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto(f'/x/empresa/{ID}'); pc.wait_for_timeout(2500)
    if pc.locator('#locbtn').count(): pc.click('#locbtn'); pc.wait_for_timeout(500)
    body = N(pc.inner_text('#mapbox'))
    check('página da empresa: endereço e ponto de referência', 'Avenida Santos Dumont, 1789' in body and 'Ponto de referência: Ao lado da farmácia' in body, body[-600:])
    # edição: abre com os campos preenchidos; trocar o CEP atualiza rua/bairro/cidade/UF
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=15000); pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector(f'[data-edit="{ID}"]', timeout=8000); pg.click(f'[data-edit="{ID}"]'); pg.wait_for_selector('#adf', timeout=10000); pg.wait_for_timeout(500)
    check('editar: campos carregados (CEP, número, complemento, referência)', [E(k).input_value() for k in ['cep', 'numero', 'complemento', 'referencia']] == ['60150-160', '1789', 'Sala 4', 'Ao lado da farmácia'])
    E('cep').fill('01310100'); pg.wait_for_function("/Falta só o número/.test(document.querySelector('#cepmsg').textContent)", timeout=8000)
    E('numero').fill('1000'); E('complemento').fill(''); pg.locator('#adf button[type=submit]').click(); pg.wait_for_timeout(2500)
    ad = next(x for x in R.get('/api/v2/ads/mine').json()['items'] if x['id'] == ID)
    check('edição: novo CEP trocou o endereço inteiro', ad['endereco'] == 'Avenida Paulista, 1000, Bela Vista, São Paulo - SP, 01310-100', ad['endereco'])
    # cadastro antigo (só texto): aviso e mantém
    db = sqlite3.connect(DBF); row = db.execute('select data from businesses where id=?', (ID,)).fetchone(); d = json.loads(row[0]); d.pop('enderecoPartes', None); d['endereco'] = 'Rua Antiga, 50, Centro'; d['referencia'] = ''
    db.execute('update businesses set data=? where id=?', (json.dumps(d), ID)); db.commit(); db.close()
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=15000); pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector(f'[data-edit="{ID}"]', timeout=8000); pg.click(f'[data-edit="{ID}"]'); pg.wait_for_selector('#adf', timeout=10000); pg.wait_for_timeout(500)
    check('endereço antigo: aviso "Endereço salvo" e campos vazios', pg.locator('[data-end-antigo]').count() == 1 and 'Rua Antiga, 50, Centro' in pg.inner_text('[data-end-antigo]') and E('rua').input_value() == '')
    pg.fill('[name=texto]', 'Café coado na hora'); pg.locator('#adf button[type=submit]').click(); pg.wait_for_timeout(2000)
    ad = next(x for x in R.get('/api/v2/ads/mine').json()['items'] if x['id'] == ID)
    check('salvar sem preencher os campos mantém o endereço antigo', ad['endereco'] == 'Rua Antiga, 50, Centro' and ad['texto'] == 'Café coado na hora', ad['endereco'])
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs[:3])
    b.close()
srv.shutdown()
print(f'\n{sum(res)}/{len(res)}')
