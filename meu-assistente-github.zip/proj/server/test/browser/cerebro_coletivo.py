# Cérebro Central → "Aprendizado coletivo" (computador e celular): contagens reais (conferidas contra a API), conhecimento
# ativo / pendente com contradição / suspenso, histórico, suspender → reverter pela tela (chega ao servidor e volta), filtro
# por estado, consolidar agora, regras salvas e relidas, nenhum dado pessoal na tela, usuário comum sem acesso, sem rolagem
# lateral e sem erros de JavaScript.
# Servidor: PORT=4351 SQLITE_FILE=/tmp/ma-col.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, json, sqlite3, datetime as dt
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4351'; DB = '/tmp/ma-col.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
agora = dt.datetime.utcnow().isoformat() + 'Z'
H = lambda *x: json.dumps([{'em': agora, 'por': p, 'de': de, 'para': pa, 'motivo': m} for p, de, pa, m in x])
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Coletivo', 'whatsapp': '+55 11 94444-1351', 'email': 'admin.col@t.com', **U}).ok
    UC = b.new_context(base_url=BASE); assert UC.request.post('/api/auth', data={'action': 'signup', 'name': 'Usuária Comum', 'whatsapp': '+55 11 98888-1351', 'email': 'user.col@t.com', **U}, headers={'X-Forwarded-For': '10.8.8.9'}).ok
    con = sqlite3.connect(DB); c = con.cursor()
    ins = "INSERT INTO collective_knowledge (template, intent, category, origin, members, users, support, negatives, contradictions, reliability, state, manual, version, uses, history, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    c.execute(ins, ('poe na lista de afazeres {x}', 'tarefa.criar', 'Tarefas', 'acertos', json.dumps(['poe na lista de afazeres {x}', 'poe na lista de afazeres trocar a {x}']), 7, 7, 0, '[]', 0.82, 'ativo', 0, 1, 12, H(('consolidacao', None, 'ativo', '7 usuário(s) distintos')), agora, agora))
    c.execute(ins, ('anota pra {data} {x}', 'lembrete.criar', 'Lembretes', 'acertos', '[]', 3, 3, 3, json.dumps([{'intencao': 'nota.criar', 'usuarios': 3}]), 0.4, 'pendente', 0, 1, 0, H(('consolidacao', None, 'pendente', 'contradição')), agora, agora))
    c.execute(ins, ('me cobra {data} de {x}', 'lembrete.criar', 'Lembretes', 'correcoes', '[]', 4, 4, 0, '[]', 0.8, 'suspenso', 1, 2, 3, H(('consolidacao', None, 'ativo', '4 usuários'), ('admin #1', 'ativo', 'suspenso', 'suspender pelo administrador')), agora, agora))
    con.commit(); con.close()
    api = A.request.get('/api/brain/coletivo').json()
    check('API: 3 conhecimentos (1 ativo, 1 pendente, 1 suspenso)', api['totais']['conhecimentos'] == 3 and api['totais']['ativos'] == 1 and api['totais']['pendentes'] == 1 and api['totais']['suspensos'] == 1, api['totais'])
    r = UC.request.get('/api/brain/coletivo'); check('usuário comum não acessa (403)', r.status == 403, r.status)
    for nome, vp, mob in [('computador', {'width': 1280, 'height': 900}, False), ('celular', {'width': 390, 'height': 844}, True)]:
        print('==', nome)
        C = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob); C.add_cookies(A.cookies()); pg = C.new_page()
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/admin/cerebro-central#coletivo'); pg.wait_for_selector('#co_l', timeout=20000); pg.wait_for_timeout(300)
        check(f'{nome}: seção "Aprendizado coletivo" no menu do Cérebro Central e marcada', pg.get_attribute('nav.secoes a[href="#coletivo"]', 'aria-current') == 'page')
        t = pg.inner_text('#c'); tiles = {l[0]: l[1] for l in [[z.strip() for z in y.split('\n') if z.strip()] for y in pg.locator('.grid .tile').all_inner_texts()] if len(l) > 1}
        check(f'{nome}: contagens reais (ativos, pendentes, suspensos)', tiles.get('Conhecimentos ativos') == '1' and tiles.get('Pendentes de revisão') == '1' and tiles.get('Suspensos') == '1', tiles)
        check(f'{nome}: modelos anônimos, intenção, usuários distintos e confiabilidade', 'poe na lista de afazeres {x}' in t and 'Criar tarefa' in t and '7 usuário(s) distintos' in t and 'confiabilidade 82%' in t)
        check(f'{nome}: contradição destacada no pendente', 'Contradição: Criar nota (3 usuário(s))' in t, t)
        check(f'{nome}: categorias e origens', 'Tarefas' in t and 'Lembretes' in t and 'Correções dos usuários' in t)
        check(f'{nome}: nenhum dado pessoal (usuários, e-mails) na tela', 'Admin Coletivo' not in t and '@t.com' not in t and 'Usuária' not in t)
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.screenshot(path=f'/tmp/e2e/coletivo_{nome}.png', full_page=False)
        if nome == 'computador':
            card = pg.locator('[data-ck]').filter(has_text='poe na lista de afazeres')
            card.locator('[data-ca="suspender"]').click(); pg.wait_for_function("()=>[...document.querySelectorAll('[data-ck]')].some(x=>x.textContent.includes('poe na lista')&&x.textContent.includes('Suspenso'))", timeout=8000)
            st = [x for x in A.request.get('/api/brain/coletivo').json()['itens'] if x['modelo'].startswith('poe na lista')][0]
            check('suspender pela tela chega ao servidor (estado, versão, histórico do administrador)', st['estado'] == 'suspenso' and st['versao'] == 2 and st['manual'] and any('admin' in h['por'] for h in st['historico']), st)
            card = pg.locator('[data-ck]').filter(has_text='poe na lista de afazeres')
            card.locator('[data-ca="reverter"]').click(); pg.wait_for_function("()=>[...document.querySelectorAll('[data-ck]')].some(x=>x.textContent.includes('poe na lista')&&x.textContent.includes('Ativo'))", timeout=8000)
            st = [x for x in A.request.get('/api/brain/coletivo').json()['itens'] if x['modelo'].startswith('poe na lista')][0]
            check('reverter pela tela: volta a ativo', st['estado'] == 'ativo' and st['versao'] == 3, st)
            card = pg.locator('[data-ck]').filter(has_text='poe na lista de afazeres'); card.locator('details summary').click()
            check('histórico mostra as mudanças', 'revertido pelo administrador' in card.inner_text(), card.inner_text())
            pg.select_option('#co_e', 'pendente'); pg.wait_for_function("()=>document.querySelectorAll('[data-ck]').length===1", timeout=8000)
            check('filtro por estado (pendente)', 'anota pra {data} {x}' in pg.inner_text('#co_l'))
            pg.select_option('#co_e', ''); pg.wait_for_function("()=>document.querySelectorAll('[data-ck]').length===3", timeout=8000)
            pg.click('#co_cons'); pg.wait_for_function("()=>document.querySelector('#toast').textContent.includes('Consolidado')", timeout=8000)
            check('consolidar agora', 'Consolidado' in pg.inner_text('#toast'), pg.inner_text('#toast'))
            pg.wait_for_selector('#co_min', timeout=8000); pg.fill('#co_min', '5'); pg.click('[data-colk="usarNaIA"]'); pg.click('#co_ok'); pg.wait_for_timeout(700)
            cfg = A.request.get('/api/brain/coletivo').json()['config']
            check('regras salvas e relidas (mínimo 5 usuários, dica para a IA desligada)', cfg['minUsuarios'] == 5 and cfg['usarNaIA'] is False, cfg)
            check('tela mostra o mínimo salvo', pg.input_value('#co_min') == '5')
            A.request.put('/api/brain/coletivo/config', data={'minUsuarios': 3, 'usarNaIA': True})
        C.close()
    check('sem erros de JavaScript', not errs, errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
