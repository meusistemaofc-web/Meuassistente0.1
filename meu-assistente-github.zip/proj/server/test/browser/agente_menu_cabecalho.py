# Cabeçalho do agente da empresa: telefone à direita + menu ⋮ com SÓ o que existe para o cliente, com dados reais.
#   - Sem chamados abertos nem pedidos: o ⋮ nem aparece (nunca um menu vazio).
#   - Pedido feito pelo carrinho do agente → "Pedidos" aparece; abre o detalhe (itens, total, situação) e acompanha a
#     mudança de status feita pela empresa, sem recarregar; continua depois de recarregar (chave do navegador).
#   - Chamado aberto → "Atendimento" aparece e abre a conversa; encerrado pela empresa → a opção some.
#   - Conta logada: vê os próprios pedidos desta empresa (agente e catálogo) mesmo sem a chave; lista → detalhe → voltar.
#   - Segurança: outro visitante, chave errada ou pedido de outro cliente → nada.
#   - Teclado (setas, Esc), celular e computador, tema escuro e claro, sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4408 SQLITE_FILE=/tmp/ma-agmenu.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime, re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4408'; DBF = '/tmp/ma-agmenu.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
def ops(pg): return pg.locator('.hd-pop [data-hd-op]').evaluate_all('es=>es.map(e=>e.dataset.hdOp)') if pg.locator('.hd-pop').count() else []
def abre_menu(pg):
    pg.wait_for_selector('[data-hd-menu]', timeout=25000); pg.click('[data-hd-menu]'); pg.wait_for_selector('.hd-pop [data-hd-op]', timeout=5000); pg.wait_for_timeout(200)
def sem_lateral(pg): return pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Menu', 'whatsapp': '+55 11 94444-0201', 'email': 'admin.menu@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Rita Dona', 'whatsapp': '+55 85 95555-0202', 'email': 'rita.menu@t.com', **U}, headers={'X-Forwarded-For': '10.12.0.2'}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Doces da Rita', 'categoria': 'Doceria', 'titulo': 't', 'texto': 'x', 'zap': '5585955550202', 'tipo': 'produtos', 'endereco': 'Rua D, 40'}).json()['items'][0]['id']
    fim = (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat()
    db("update businesses set status='ativo', expires_at=? where id=?", (fim, ID))
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok and R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); d['agente']['expiresAt'] = fim.replace('+00:00', 'Z'); db('update businesses set data=? where id=?', (json.dumps(d), ID))
    r = R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Bolo de Pote', 'preco': 15.5, 'categoria': 'Doces', 'fotos': ['data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==']}); assert r.ok, r.text(); PID = [x for x in r.json()['items'] if x['nome'] == 'Bolo de Pote'][0]['id']
    def novo_pedido_api(ctx, idem):
        return ctx.request.post(f'/api/v2/agent/{ID}/order', data={'itens': [{'produto_id': PID, 'quantidade': 2}], 'modo': 'retirada', 'pagamento': 'dinheiro', 'nome': 'Cliente Conta', 'telefone': '85 98888-1212'}, headers={'X-Forwarded-For': idem})

    print('== visitante, celular, tema escuro')
    vc = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True, color_scheme='dark'); pg = vc.new_page(); pg.on('pageerror', lambda e: errs.append('visitante: ' + str(e)))
    pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button', timeout=20000); pg.wait_for_timeout(1800)
    g = pg.evaluate("""()=>{const hd=document.getElementById('hd'),r=e=>e.getBoundingClientRect(),t=hd.querySelector('.tel'),h=r(hd);return {tel:!!t,telNaDireita:t?h.right-r(t).right<12:false,dentro:t?r(t).right<=h.right:false,acts:!!hd.querySelector('[data-hd-acts] .tel'),menu:!!hd.querySelector('[data-hd-menu]'),nome:hd.querySelector('h1').textContent}}""")
    check('cabeçalho: nome da empresa e telefone no canto direito, dentro da barra', g['nome'] == 'Doces da Rita' and g['tel'] and g['acts'] and g['telNaDireita'] and g['dentro'], g)
    check('sem chamados nem pedidos: o menu ⋮ não aparece (nenhuma opção vazia)', not g['menu'], g)
    pg.screenshot(path='/tmp/e2e/agmenu_sem_opcoes.png', clip={'x': 0, 'y': 0, 'width': 390, 'height': 120})
    # pedido real pelo carrinho do agente
    if not pg.locator('#acts [data-a=cat]').count(): pg.click('#acts [data-a=mais]')
    pg.click('#acts [data-a=cat]'); pg.wait_for_selector('.pc', timeout=8000); pg.wait_for_timeout(400)
    pg.locator('.pc', has_text='Bolo de Pote').last.locator('[data-pid]').click(); pg.wait_for_timeout(900)
    if pg.locator('.det [data-go]').count(): pg.locator('.det [data-q="1"]').click(); pg.wait_for_timeout(150); pg.click('.det [data-go]'); pg.wait_for_timeout(900)
    else: pg.locator('.pc', has_text='Bolo de Pote').last.locator('[data-pid]').click(); pg.wait_for_timeout(900)
    pg.locator('button:has-text("Ver carrinho e finalizar")').last.click(); pg.wait_for_selector('#cgo', timeout=8000)
    pg.fill('#cn', 'Paula Visitante'); pg.fill('#ct', '85 98888-7777'); pg.click('#cgo')
    pg.wait_for_function("/Pedido #\\d+/.test(document.getElementById('chat').innerText)", timeout=10000)
    OID = int(re.search(r'Pedido #(\d+)', pg.inner_text('#chat')).group(1))
    ls = pg.evaluate(f"JSON.parse(localStorage.getItem('ma-pedidos-{ID}')||'[]')")
    check('pedido enviado pelo carrinho: chave guardada só neste navegador', any(x['id'] == OID and re.fullmatch(r'[a-f0-9]{16}', x['k']) for x in ls), ls)
    abre_menu(pg)
    check('menu ⋮ aparece com SÓ "Pedidos" (sem chamado aberto, sem "Atendimento")', ops(pg) == ['pedidos'], ops(pg))
    pop = pg.evaluate("""()=>{const p=document.querySelector('.hd-pop').getBoundingClientRect(),b=document.querySelector('[data-hd-menu]').getBoundingClientRect();return {dentro:p.left>=0&&p.right<=innerWidth,abaixo:p.top>=b.bottom,alinhado:Math.abs(p.right-b.right)<14,exp:document.querySelector('[data-hd-menu]').getAttribute('aria-expanded'),role:document.querySelector('.hd-pop').getAttribute('role'),foco:document.activeElement.dataset.hdOp}}""")
    check('menu: abaixo do botão, alinhado à direita, dentro da tela, role=menu, foco no 1º item', pop['dentro'] and pop['abaixo'] and pop['alinhado'] and pop['exp'] == 'true' and pop['role'] == 'menu' and pop['foco'] == 'pedidos', pop)
    check('"Pedidos" mostra o resumo real ("1 em andamento")', '1 em andamento' in pg.inner_text('.hd-pop'), pg.inner_text('.hd-pop'))
    pg.screenshot(path='/tmp/e2e/agmenu_pedidos_celular.png')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    check('Esc fecha o menu e devolve o foco ao ⋮', pg.locator('.hd-pop').count() == 0 and pg.evaluate("document.activeElement.hasAttribute('data-hd-menu')"))
    abre_menu(pg); pg.click('[data-hd-op=pedidos]'); pg.wait_for_selector(f'[data-pd-det="{OID}"]', timeout=8000); pg.wait_for_timeout(300)
    tx = pg.inner_text('[data-pd-ov]')
    check('Pedidos (1 pedido) abre direto o detalhe: itens, total, retirada, pagamento e situação "Novo"', f'Pedido #{OID}' in tx and '2× Bolo de Pote' in tx and 'R$ 31,00' in tx and 'Retirada no local' in tx and 'Dinheiro' in tx and pg.inner_text('[data-pd-st]') == 'Novo', tx)
    check('detalhe sem rolagem lateral', sem_lateral(pg))
    assert R.post(f'/api/v2/ads/{ID}/orders/{OID}', data={'status': 'aceito'}).ok
    try: pg.wait_for_function("(document.querySelector('[data-pd-st]')||{}).textContent==='Aceito'", timeout=22000); ok = True
    except Exception: ok = False
    check('a empresa aceita o pedido → o detalhe aberto atualiza sozinho para "Aceito"', ok, pg.inner_text('[data-pd-st]'))
    pg.screenshot(path='/tmp/e2e/agmenu_pedido_detalhe.png')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); check('Esc fecha o detalhe', pg.locator('[data-pd-ov]').count() == 0)
    pg.reload(); pg.wait_for_selector('#acts button', timeout=20000); abre_menu(pg)
    check('depois de recarregar, "Pedidos" continua (chave do navegador)', ops(pg) == ['pedidos'], ops(pg)); pg.keyboard.press('Escape')
    # chamado de atendimento
    pg.fill('#t', 'Quero falar com uma pessoa sobre meu pedido'); pg.click('#b'); pg.wait_for_selector('[data-at-form]', timeout=10000)
    pg.fill('[data-at-texto]', 'O bolo veio sem tampa.'); pg.fill('[data-at-nome]', 'Paula Visitante'); pg.click('[data-at-abrir]')
    pg.wait_for_selector('.at-ov [data-at-msgs] [data-autor=cliente]', timeout=10000); pg.wait_for_timeout(400); pg.locator('[data-at-x]').click(); pg.wait_for_timeout(600)
    abre_menu(pg)
    check('chamado aberto → "Atendimento" aparece (antes de "Pedidos")', ops(pg) == ['atendimento', 'pedidos'], ops(pg))
    check('não sobra o botão antigo "Atendimento" solto no topo', pg.locator('#hd [data-at-hd]').count() == 0)
    pg.keyboard.press('ArrowDown'); check('setas navegam entre as opções', pg.evaluate('document.activeElement.dataset.hdOp') == 'pedidos')
    pg.keyboard.press('ArrowDown'); check('setas dão a volta', pg.evaluate('document.activeElement.dataset.hdOp') == 'atendimento')
    pg.screenshot(path='/tmp/e2e/agmenu_dois_celular.png')
    pg.keyboard.press('Enter'); pg.wait_for_selector('.at-ov [data-at-msgs]', timeout=8000); pg.wait_for_timeout(300)
    check('"Atendimento" abre a conversa do chamado (módulo existente)', 'O bolo veio sem tampa' in pg.inner_text('.at-ov') and pg.inner_text('[data-at-st]') == 'Aberto')
    pg.locator('[data-at-x]').click(); pg.wait_for_timeout(300)
    aid = db('select id from atendimentos where business_id=? order by id desc limit 1', (ID,))[0][0]
    assert R.post(f'/api/v2/ads/{ID}/atendimentos/{aid}', multipart={'status': 'encerrado'}).ok
    pg.evaluate('window.maAtend.badge()'); pg.wait_for_timeout(1200); abre_menu(pg)
    check('empresa encerra o chamado → "Atendimento" some, "Pedidos" fica', ops(pg) == ['pedidos'], ops(pg)); pg.keyboard.press('Escape')
    check('celular: sem rolagem lateral', sem_lateral(pg))

    print('== segurança e contexto da empresa')
    k = [x for x in pg.evaluate(f"JSON.parse(localStorage.getItem('ma-pedidos-{ID}')||'[]')") if x['id'] == OID][0]['k']
    ov = b.new_context(base_url=BASE); OR = ov.request
    check('outro visitante sem chave: nenhum pedido', OR.get(f'/api/v2/agent/{ID}/pedidos').json()['items'] == [])
    check('chave errada para o mesmo pedido: nada', OR.get(f'/api/v2/agent/{ID}/pedidos?k={OID}.{"0"*16}').json()['items'] == [])
    sg = OR.get(f'/api/v2/agent/{ID}/pedidos?k={OID}.{k}').json()['items']
    check('com a chave certa: só aquele pedido, sem a chave nem o telefone na resposta', [x['id'] for x in sg] == [OID] and k not in json.dumps(sg) and '98888' not in json.dumps(sg), sg)
    ov.close()

    print('== cliente logado, computador, tema claro')
    cc = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE, color_scheme='light'); C = cc.request
    assert C.post('/api/auth', data={'action': 'signup', 'name': 'Carlos Conta', 'whatsapp': '+55 85 97777-0303', 'email': 'carlos.menu@t.com', **U}, headers={'X-Forwarded-For': '10.12.0.3'}).ok
    C.patch('/api/me', data={'settings': {'theme': 'light'}})
    o1 = novo_pedido_api(cc, '10.12.0.4').json()['pedido']
    o2 = C.post(f'/api/v2/businesses/{ID}/orders', data={'itens': [{'pid': PID, 'qtd': 1}], 'modo': 'retirada', 'pagamento': 'dinheiro', 'telefone': '85977770303', 'nome': 'Carlos Conta', 'idem': 'cat1'}).json()['order']['id']
    pc = cc.new_page(); pc.on('pageerror', lambda e: errs.append('logado: ' + str(e)))
    pc.goto(f'/a/{ID}'); pc.wait_for_selector('#acts button', timeout=20000)
    check('conta logada sem chave no navegador', pc.evaluate(f"localStorage.getItem('ma-pedidos-{ID}')") is None)
    abre_menu(pc)
    check('conta logada: "Pedidos" com os pedidos dela nesta empresa (agente e catálogo)', ops(pc) == ['pedidos'] and '2 em andamento' in pc.inner_text('.hd-pop'), pc.inner_text('.hd-pop'))
    pc.screenshot(path='/tmp/e2e/agmenu_computador.png', clip={'x': 0, 'y': 0, 'width': 1280, 'height': 260})
    pc.click('[data-hd-op=pedidos]'); pc.wait_for_selector('[data-pd-abre]', timeout=8000)
    ids = pc.locator('[data-pd-abre]').evaluate_all('es=>es.map(e=>+e.dataset.pdAbre)')
    check('vários pedidos: abre a lista, mais recente primeiro, sem o pedido do visitante', ids == [o2, o1] and OID not in ids, ids)
    pc.click(f'[data-pd-abre="{o1}"]'); pc.wait_for_selector(f'[data-pd-det="{o1}"]', timeout=5000)
    check('lista → detalhe do pedido escolhido', '2× Bolo de Pote' in pc.inner_text('[data-pd-ov]'))
    pc.click('[data-pd-volta]'); pc.wait_for_selector('[data-pd-abre]', timeout=5000); check('"‹" volta para a lista', pc.locator('[data-pd-abre]').count() == 2)
    pc.screenshot(path='/tmp/e2e/agmenu_lista_computador.png')
    pc.keyboard.press('Escape'); check('computador: sem rolagem lateral', sem_lateral(pc))
    assert R.post(f'/api/v2/ads/{ID}/orders/{o2}', data={'status': 'recusado', 'motivo': 'acabou'}).ok
    st = {x['id']: x['statusLabel'] for x in C.get(f'/api/v2/agent/{ID}/pedidos').json()['items']}
    check('situação vem do pedido real (recusado pela empresa)', st.get(o2) == 'Recusado' and st.get(o1) == 'Novo', st)
    cc.close(); vc.close()
    check('sem erros de JavaScript', not [e for e in errs if e.split(': ', 1)[-1] != 'Event' and 'React error #418' not in e], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
