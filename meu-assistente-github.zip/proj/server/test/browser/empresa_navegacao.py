# Navegação do menu da empresa (Início, Pedidos, Produtos, Ajustes) pela tela real, com rede de celular simulada
# (150 ms de latência, ~1,5 MB/s) e logo/capa reais (~0,5 MB): resposta imediata ao toque, sem "Carregando…" de tela cheia,
# menu preservado, sem baixar de novo a lista das empresas a cada troca (cache), troca rápida sem tela "atrasada",
# dados atualizados depois de uma alteração, outra conta isolada, celular e computador, tema claro e escuro.
# Servidor: run_srv.sh 4383 /tmp/ma-empnav.db (banco novo)
import sys, json, time, sqlite3, base64, os
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4383'; DBF = '/tmp/ma-empnav.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
PRONTO = """k=>{const o=document.querySelector('#ma-x');const novo=[...o.children].some(c=>!c.dataset.velho&&!c.matches('nav'));const b=document.querySelector('nav.ma-nav [data-nav="'+k+'"]');const bar=document.getElementById('ma-carga');return novo&&!/Carregando…/.test(o.innerText)&&b&&b.classList.contains('on')&&!(bar&&bar.classList.contains('on'))}"""
def dono(b, vp, mob, email, empresa, zap):
    c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono ' + empresa, 'whatsapp': zap, 'email': email, **U}).ok
    R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    bid = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (bid,)).fetchone()[0])
    d['logo'] = 'data:image/jpeg;base64,' + base64.b64encode(os.urandom(90000)).decode(); d['capa'] = 'data:image/jpeg;base64,' + base64.b64encode(os.urandom(300000)).decode()
    db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z', data=? where id=?", (json.dumps(d), bid)); db.commit(); db.close()
    for i in range(12): R.post(f'/api/v2/ads/{bid}/products', data={'nome': f'Produto {i}', 'preco': 10 + i, 'fotos': [IMG]})
    return c, R, bid
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 1), ('computador', {'width': 1280, 'height': 900}, False, 2)]:
        print('==', nome)
        c, R, BID = dono(b, vp, mob, f'nav{k}@t.com', f'Loja Nav {k}', f'+55 11 94444-6{k}{k}{k}')
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        cdp = c.new_cdp_session(pg); cdp.send('Network.enable'); cdp.send('Network.emulateNetworkConditions', {'offline': False, 'latency': 150, 'downloadThroughput': 1500 * 1024, 'uploadThroughput': 750 * 1024})
        reqs = []; pg.on('request', lambda r: reqs.append(r.url.replace(BASE, '').split('?')[0]) if '/api/' in r.url else None)
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('nav.ma-nav', timeout=30000); pg.wait_for_timeout(2500)
        tempos, ativos, cheia, mine = {}, [], [], []
        for aba in ['pedidos', 'produtos', 'mais', 'inicio', 'produtos', 'pedidos', 'mais', 'inicio']:
            pg.evaluate("()=>{const o=document.querySelector('#ma-x');[...o.children].forEach(c=>c.dataset.velho='1')}")
            n0 = len(reqs); t0 = time.time(); pg.locator(f'nav.ma-nav [data-nav="{aba}"]').click()
            pg.wait_for_function(f"()=>{{const b=document.querySelector('nav.ma-nav [data-nav=\"{aba}\"]');return b&&b.classList.contains('on')}}", timeout=5000); ativos.append(round((time.time() - t0) * 1000))
            # durante a troca: o menu continua na tela e não aparece "Carregando…" de página inteira
            cheia.append(pg.locator('nav.ma-nav').count() == 1 and 'Carregando…' not in pg.inner_text('#ma-x'))
            pg.wait_for_function(PRONTO, arg=aba, timeout=20000, polling=20); tempos.setdefault(aba, []).append(round((time.time() - t0) * 1000))
            pg.wait_for_timeout(400); mine.append(sum(1 for u in reqs[n0:] if u == '/api/v2/ads/mine'))
        print('    tempos (ms):', tempos, '· toque→menu ativo:', ativos)
        check(f'{nome}: o toque responde na hora (item ativo em ≤ 200 ms)', max(ativos) <= 200, ativos)
        check(f'{nome}: sem "Carregando…" de tela cheia; o menu fica na tela durante a troca', all(cheia), cheia)
        check(f'{nome}: cada tela fica pronta em ≤ 1,2 s em rede de celular', all(t <= 1200 for v in tempos.values() for t in v), tempos)
        check(f'{nome}: a lista das empresas (com logo e capa) não é baixada de novo a cada troca', sum(mine) <= 1, mine)
        logo = [u for u in reqs if '/imagem/logo' in u or '/imagem/capa' in u]
        check(f'{nome}: logo e capa vêm por endereço com cache (não embutidos no JSON)', len(set(logo)) >= 1 and len(logo) <= 4, logo)
        # troca rápida: só a última escolha vale
        for aba in ['pedidos', 'produtos', 'mais', 'inicio', 'produtos']: pg.locator(f'nav.ma-nav [data-nav="{aba}"]').click(); pg.wait_for_timeout(40)
        pg.wait_for_timeout(2500)
        on = pg.evaluate("[...document.querySelectorAll('nav.ma-nav [data-nav].on')].map(b=>b.dataset.nav)")
        check(f'{nome}: troca rápida termina na última opção tocada (sem tela atrasada por cima)', on == ['produtos'] and 'Produto 1' in pg.inner_text('#ma-x'), (on, pg.inner_text('#ma-x')[:120]))
        # alteração feita na tela: cache invalidado, dado novo na próxima troca
        pg.evaluate(f"window.__maApiFetch('/api/v2/ads/{BID}',{{method:'PUT',body:JSON.stringify({{empresa:'Loja Renomeada {k}'}})}})"); pg.wait_for_timeout(600)
        pg.locator('nav.ma-nav [data-nav="inicio"]').click(); pg.wait_for_function(PRONTO, arg='inicio', timeout=20000); pg.wait_for_timeout(300)
        check(f'{nome}: depois de uma alteração, a próxima tela já mostra o dado novo', f'Loja Renomeada {k}' in pg.inner_text('#ma-x'), pg.inner_text('#ma-x')[:200])
        # alteração feita em outro aparelho: entrar de novo na área da empresa busca tudo de novo
        R.put(f'/api/v2/ads/{BID}', data={'empresa': f'Loja Outro Aparelho {k}'})
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.goto('/x/sua-empresa'); pg.wait_for_selector('nav.ma-nav', timeout=30000); pg.wait_for_timeout(2000)
        check(f'{nome}: ao entrar de novo na área da empresa, os dados vêm atualizados', f'Loja Outro Aparelho {k}' in pg.inner_text('#ma-x'), pg.inner_text('#ma-x')[:200])
        # tema claro e escuro
        for tema in ['light', 'dark']:
            pg.evaluate(f"document.documentElement.dataset.theme='{tema}'"); pg.wait_for_timeout(300)
            pg.locator('nav.ma-nav [data-nav="produtos"]').click(); pg.wait_for_timeout(1500)
            pg.screenshot(path=f'/tmp/e2e/empnav_{nome}_{tema}.png')
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if mob: C1, BID1 = c, BID
        else: c.close()
    # outra empresa: não vê a logo nem a lista da primeira
    c2, R2, BID2 = dono(b, {'width': 390, 'height': 844}, True, 'nav3@t.com', 'Loja Nav 3', '+55 11 94444-6333')
    db = sqlite3.connect(DBF); db.execute("update businesses set status='analise' where id=?", (BID1,)); db.commit(); db.close()
    check('isolamento: outra conta não acessa a logo de empresa não publicada nem a vê na sua lista', R2.get(f'/api/v2/ads/{BID1}/imagem/logo').status == 404 and all(x['id'] != BID1 for x in R2.get('/api/v2/ads/mine').json()['items']))
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
