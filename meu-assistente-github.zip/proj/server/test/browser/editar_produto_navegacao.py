# Editar produto leva aos campos (24/11): em Sua empresa → Produtos, com uma lista longa, tocar em Editar de um item lá embaixo
# leva a tela até o formulário (no contêiner que rola de verdade, #ma-x), com o título e o Nome visíveis logo abaixo do
# cabeçalho fixo — nem escondidos sob ele, nem fora da tela. Confere itens diferentes (com fotos, variações, oferta, etiqueta,
# serviço), que o formulário traz os dados CERTOS de cada um, que salvar continua salvando sem perder nada, Duplicar e
# celular (390 e 320 px) e computador. Antes da correção a tela ficava parada no meio da lista.
# Servidor: PORT=4324 SQLITE_FILE=/tmp/ma-tgl.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, json, sqlite3, base64, os, time
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4324'; DBF = '/tmp/ma-tgl.db'; res = []
os.makedirs('/tmp/e2e', exist_ok=True)
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def durl(cor):
    b = io.BytesIO(); Image.new('RGB', (300, 200), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
# posição do formulário em relação ao contêiner que rola, ao cabeçalho fixo e à barra de baixo
POS = """()=>{const c=document.getElementById('ma-x'),f=c.querySelector('.mi-form'),h=c.querySelector('header.sticky'),n=f&&f.querySelector('#pn'),nav=document.querySelector('.ma-nav');if(!f)return null;
 const R=e=>e.getBoundingClientRect();return {ft:Math.round(R(f).top),hb:Math.round(R(h).bottom),nt:Math.round(n.getBoundingClientRect().top),nb:Math.round(n.getBoundingClientRect().bottom),vh:innerHeight,
 navTop:nav?Math.round(R(nav).top):innerHeight,st:Math.round(c.scrollTop),janela:Math.round(scrollY),titulo:(f.querySelector('[data-ptitulo]')||{}).textContent||'',nome:n.value,foco:document.activeElement===n}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob in [('celular 390', {'width': 390, 'height': 844}, True), ('celular 320', {'width': 320, 'height': 640}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome); k = nome.replace(' ', '')
        D = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = D.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Edna', 'whatsapp': {'celular390': '+55 82 93331-0001', 'celular320': '+55 82 93332-0002', 'computador': '+55 82 93333-0003'}[k], 'email': f'edna.{k}.{int(time.time())}@t.com', **U}, headers={'X-Forwarded-For': '10.7.1.' + str(len(k))}).ok
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Loja da Edna {k}', 'categoria': 'Variedades', 'titulo': 'x', 'texto': 'x', 'zap': '5582999990000'}); assert r.ok, r.text(); ID = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
        assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}, 'operacao': 'ambos'}).ok
        for i in range(14): assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': f'Item comum {i:02d}', 'preco': 10 + i, 'categoria': 'Diversos', 'fotos': [durl((20 * i % 255, 80, 120))]}).ok
        assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Camiseta estampada', 'preco': 59.9, 'categoria': 'Roupas', 'descricao': 'Algodão penteado', 'fotos': [durl((200, 40, 40)), durl((40, 200, 40))], 'oferta': {'ativo': True, 'preco': 49.9},
            'variacoes': [{'nome': 'Tamanho', 'opcoes': [{'nome': 'P', 'preco': 0, 'estoque': 3}, {'nome': 'M', 'preco': 0, 'estoque': 5}, {'nome': 'G', 'preco': 5, 'estoque': 2}]}]}).ok
        assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Caneca de porcelana', 'preco': 35, 'categoria': 'Cozinha', 'descricao': 'Caneca 300 ml', 'fotos': [durl((40, 40, 200))], 'estoque': 7}).ok
        its = R.get(f'/api/v2/ads/{ID}/products').json()['items']
        CAM = next(x['id'] for x in its if x['nome'] == 'Camiseta estampada'); CAN = next(x['id'] for x in its if x['nome'] == 'Caneca de porcelana')
        cam_antes = R.get(f'/api/v2/ads/{ID}/products/{CAM}').json()
        pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.dismiss())
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=produtos]', timeout=20000); pg.click('.ma-nav [data-nav=produtos]'); pg.wait_for_selector(f'[data-prow="{CAM}"]', timeout=15000); pg.wait_for_timeout(500)
        def editar(pid, sel='[data-pe]'):
            row = pg.locator(f'[data-prow="{pid}"]'); row.scroll_into_view_if_needed(); pg.wait_for_timeout(300)
            st0 = pg.evaluate("document.getElementById('ma-x').scrollTop"); row.locator(sel).click()
            pg.wait_for_selector('.mi-form [data-ptitulo]', timeout=10000)
            # espera por CONDIÇÃO (não por tempo): o formulário chegou logo abaixo do cabeçalho e a rolagem suave parou
            try: pg.wait_for_function("()=>{const c=document.getElementById('ma-x'),f=c.querySelector('.mi-form'),h=c.querySelector('header.sticky');if(!f)return false;const d=f.getBoundingClientRect().top-h.getBoundingClientRect().bottom;if(d<-1||d>40)return false;const a=c.scrollTop;return new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>r(c.scrollTop===a))))}", timeout=6000)
            except Exception: pass  # a medição abaixo mostra onde a tela ficou
            return st0, pg.evaluate(POS)
        # 1) item lá embaixo da lista (com variações, oferta e 2 fotos)
        st0, q = editar(CAM)
        visivel = q['ft'] >= q['hb'] - 1 and q['ft'] <= q['hb'] + 40 and q['nt'] >= q['hb'] and q['nb'] <= min(q['vh'], q['navTop'])
        check(f'{nome}: Editar no fim da lista leva a tela até o formulário (estava em {st0}px)', st0 > 300 and visivel, (st0, q))
        check(f'{nome}: título e Nome visíveis logo abaixo do cabeçalho fixo, sem nada cobrindo', q['titulo'].startswith('Editar') and q['nome'] == 'Camiseta estampada' and q['nt'] >= q['hb'], q)
        check(f'{nome}: rola o contêiner certo (#ma-x), não a janela', q['janela'] == 0 and q['st'] >= 0, q)
        form = pg.evaluate("()=>({preco:document.querySelector('#ppr').value,fotos:document.querySelectorAll('#pfs img').length,variacoes:(document.querySelector('#pv')||{}).value||document.querySelector('#pvbox')?.innerText||'',oferta:(document.querySelector('#popr')||{}).value||''})")
        check(f'{nome}: formulário com os dados certos do item (preço, 2 fotos, variações, oferta)', '59,9' in form['preco'] and form['fotos'] == 2 and 'P' in form['variacoes'] and 'G' in form['variacoes'] and '49,9' in form['oferta'], form)
        if not mob: check(f'{nome}: no computador o cursor já está no Nome', q['foco'], q)
        pg.screenshot(path=f'/tmp/e2e/editar_produto_{k}.png')
        # 2) outro item: carrega o formulário DELE e também posiciona
        pg.locator('#pcancel').click() if pg.locator('#pcancel').count() else None; pg.wait_for_timeout(400)
        st0, q2 = editar(CAN)
        check(f'{nome}: editar outro item abre o formulário dele, também posicionado', q2['nome'] == 'Caneca de porcelana' and q2['ft'] >= q2['hb'] - 1 and q2['ft'] <= q2['hb'] + 40, q2)
        # 3) salvar a edição (preço) continua salvando e não perde nada da camiseta nem da caneca
        pg.fill('#ppr', '37,50'); pg.click('#psave'); pg.wait_for_timeout(1800)
        can = R.get(f'/api/v2/ads/{ID}/products/{CAN}').json(); cam = R.get(f'/api/v2/ads/{ID}/products/{CAM}').json()
        check(f'{nome}: salvar grava o novo preço e mantém fotos, estoque e descrição', abs(float(can['preco']) - 37.5) < 0.01 and len(can['fotos']) == 1 and can.get('descricao') == 'Caneca 300 ml', can)
        cmp = lambda x: json.dumps({k2: x.get(k2) for k2 in ['nome', 'preco', 'fotos', 'variacoes', 'oferta', 'categoria', 'descricao', 'tags']}, sort_keys=True)
        check(f'{nome}: o outro item (variações, oferta, fotos) ficou intacto', cmp(cam) == cmp(cam_antes))
        # 4) abrir a camiseta e salvar sem mudar nada: variações, estoque por variação e oferta preservados
        st0, q3 = editar(CAM); pg.click('#psave'); pg.wait_for_timeout(1800)
        cam2 = R.get(f'/api/v2/ads/{ID}/products/{CAM}').json()
        check(f'{nome}: abrir e salvar sem mudar nada preserva variações (com estoque), oferta e fotos', cmp(cam2) == cmp(cam_antes), (cmp(cam2)[:300], cmp(cam_antes)[:300]))
        # 5) Duplicar também leva ao formulário
        st0, q4 = editar(CAN, '[data-pdup]')
        check(f'{nome}: Duplicar leva ao formulário preenchido', q4['titulo'].startswith('Duplicar') and 'Caneca' in q4['nome'] and q4['ft'] >= q4['hb'] - 1 and q4['ft'] <= q4['hb'] + 40, q4)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
        D.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
