# Microfone: TRANSCRIÇÃO EM TEMPO REAL NO CAMPO, com indicador "Ouvindo…", botão vermelho de PAUSA e envio durante a captura.
# Reconhecimento de fala simulado como no Chrome/Android (palavras chegam aos poucos). Os 11 testes pedidos, no celular e no
# computador:
#   1 clique no microfone inicia a captura na hora        2 "Ouvindo…" aparece DENTRO do campo (elemento próprio)
#   3 o texto aparece progressivamente no campo           4 o texto não é apagado nem duplicado enquanto chega
#   5 o botão vermelho de pausa substitui o microfone     6 pausar mantém o texto, não envia e restaura o microfone
#   7 o texto pode ser editado depois de pausar           8 enviar (azul) durante a captura envia o texto imediatamente
#   9 nenhuma mensagem é enviada duas vezes               10 permissão negada: aviso claro, botão volta ao normal
#  11 o chat continua normal (resposta chega; digitação comum) + sem erros de JavaScript
# Servidor: PORT=4393 SQLITE_FILE=/tmp/ma-mic-ouv.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4393'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
FAKE = r"""(()=>{window.__recs=[];window.__fila=[];window.__ritmo=200;window.__fimApos=0;window.__erroApos=0;
 class Rec{constructor(){this.lang='';this.continuous=false;this.interimResults=false;this._ok=false;this._t=[];this._w=[];window.__recs.push(this)}
  start(){if(window.__falhaInicio==='not-allowed'){setTimeout(()=>{this.onerror&&this.onerror({error:'not-allowed'});this.onend&&this.onend()},30);return}
   this._ok=true;this._ini=Date.now();window.__recAtivo=this;setTimeout(()=>{this.onstart&&this.onstart();this._tick()},30)}
  _emit(fin){const t=this._w.join(' ');window.__ultimoResultado=performance.now();this.onresult&&this.onresult({resultIndex:0,results:[{0:{transcript:t},isFinal:fin,length:1}]})}
  _tick(){if(!this._ok)return;if(window.__erroApos&&this._w.length>=window.__erroApos){window.__erroApos=0;this._ok=false;this.onerror&&this.onerror({error:'network'});setTimeout(()=>this.onend&&this.onend(),10);return}
   if(window.__fila.length){this._w.push(window.__fila.shift());this._emit(false);this._ult=Date.now()}
   else if(window.__fimApos&&this._w.length&&Date.now()-this._ult>window.__fimApos){this._emit(true);return this._fim()}
   this._t.push(setTimeout(()=>this._tick(),window.__ritmo))}
  _fim(){this._ok=false;this._t.forEach(clearTimeout);if(window.__recAtivo===this)window.__recAtivo=null;setTimeout(()=>this.onend&&this.onend(),15)}
  stop(){if(this._w.length)this._emit(true);this._fim()}
  abort(){window.__abortos=(window.__abortos||0)+1;this._fim()}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec;
 const oq=navigator.permissions.query.bind(navigator.permissions);navigator.permissions.query=d=>d&&d.name==='microphone'?Promise.resolve({get state(){return window.__permMic||'granted'},onchange:null}):oq(d)})()"""
VERMELHO = 'rgb(229, 72, 77)'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for k, (nome, vp, mob) in enumerate([('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]):
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, device_scale_factor=2, permissions=['microphone']); C.add_init_script(FAKE)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Ana Ouve', 'whatsapp': f'+55 11 95544-{k}{k}{k}{k}', 'email': f'ana{k}.ouv@t.com', **U}, headers={'X-Forwarded-For': f'10.7.4.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios = []
        pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1200)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        TA = 'textarea[data-composer-input]'; campo = lambda: pg.input_value(TA)
        MIC = '[data-ditado-estado]'
        estado = lambda: pg.get_attribute(MIC, 'data-ditado-estado')
        rotulo = lambda: pg.get_attribute(MIC, 'aria-label')
        fundo = lambda: pg.evaluate("getComputedStyle(document.querySelector('[data-ditado-estado]')).backgroundColor")
        caixa = lambda s: pg.evaluate(f"(()=>{{const e=document.querySelector('{s}');if(!e)return null;const b=e.getBoundingClientRect();return [Math.round(b.x),Math.round(b.y),Math.round(b.width),Math.round(b.height)]}})()")
        ind = lambda: pg.evaluate("(()=>{const e=document.querySelector('[data-ditado-indicador]');return e?{txt:e.textContent,estado:e.dataset.ditadoIndicador,vazio:e.classList.contains('is-vazio')}:null})()")
        fala = lambda t: pg.evaluate(f"window.__fila.push(...{t.split()!r})")
        ativos = lambda: pg.evaluate("window.__recs.filter(r=>r._ok).length")
        def espera(cond, t=6000):
            fim = time.time() + t / 1000
            while time.time() < fim:
                if pg.evaluate(cond): return True
                pg.wait_for_timeout(50)
            return False
        mic_parado = caixa(MIC); bg_parado = fundo()
        # 1) clique inicia a captura imediatamente
        t0 = time.time(); pg.click(MIC); pg.wait_for_function("document.querySelector('[data-ditado-estado]').dataset.ditadoEstado!=='inativo'", timeout=3000); dt = (time.time() - t0) * 1000
        check(f'{nome} 1: o clique no microfone inicia a captura na hora ({dt:.0f} ms)', dt < 500 and estado() in ('starting', 'listening'), (dt, estado()))
        espera("document.querySelector('[data-ditado-estado=listening]')")
        # 2) "Ouvindo…" dentro do campo
        i2 = ind(); dentro = pg.evaluate("(()=>{const a=document.querySelector('[data-ditado-indicador]').getBoundingClientRect(),c=document.querySelector('textarea[data-composer-input]').getBoundingClientRect();return a.left>=c.left&&a.right<=c.right&&a.top>=c.top&&a.bottom<=c.bottom})()")
        ph = pg.get_attribute(TA, 'placeholder')
        check(f'{nome} 2: indicador "Ouvindo…" discreto dentro do próprio campo (não é painel, modal nem placeholder)', i2 and i2['txt'] == 'Ouvindo' and i2['estado'] == 'ouvindo' and dentro and not ph and pg.locator('[role=dialog]').count() == 0, (i2, dentro, ph))
        if k == 0: pg.locator('.ma-composer').first.screenshot(path='/tmp/e2e/mic_ouvindo_vazio.png')
        # 5) botão vermelho de pausa no lugar do microfone
        espera(f"getComputedStyle(document.querySelector('[data-ditado-estado]')).backgroundColor==={VERMELHO!r}", 1500) # fim da transição de cor
        check(f'{nome} 5: botão VERMELHO de pausa no lugar do microfone (mesma posição e tamanho)', fundo() == VERMELHO and rotulo() == 'Pausar ditado' and caixa(MIC) == mic_parado and pg.locator(MIC + ' svg rect').count() == 2, (fundo(), rotulo(), caixa(MIC), mic_parado))
        check(f'{nome} 5b: o botão azul de enviar continua visível durante a captura', pg.locator('button[aria-label="Enviar"]').is_visible())
        # 3/4) texto progressivo, sem apagar nem duplicar
        frase = 'preciso marcar uma reunião com o fornecedor amanhã cedo'
        fala(frase); amostras = []
        for _ in range(30): amostras.append(campo()); pg.wait_for_timeout(70)
        espera(f"document.querySelector('{TA}').value.toLowerCase()==={frase.lower()!r}", 4000)
        seq = [a for j2, a in enumerate(amostras) if a and (j2 == 0 or a != amostras[j2 - 1])]
        check(f'{nome} 3: o texto aparece progressivamente no campo enquanto se fala ({len(seq)} atualizações)', len(seq) >= 4, seq[:5])
        prefixo = all(seq[j2 + 1].lower().startswith(seq[j2].lower()) for j2 in range(len(seq) - 1))
        check(f'{nome} 4: o texto já transcrito não é apagado nem duplicado', prefixo and campo().lower() == frase.lower() and campo().lower().count('fornecedor') == 1, (seq, campo()))
        i3 = ind(); sobrepoe = pg.evaluate("(()=>{const a=document.querySelector('[data-ditado-indicador]').getBoundingClientRect(),t=document.querySelector('textarea[data-composer-input]'),c=t.getBoundingClientRect();return a.bottom>c.top+parseFloat(getComputedStyle(t).paddingTop)+1})()")
        check(f'{nome} 2b: com texto no campo o indicador fica pequeno no canto, sem cobrir o texto', i3 and not i3['vazio'] and not sobrepoe, (i3, sobrepoe))
        if k == 0: pg.locator('.ma-composer').first.screenshot(path='/tmp/e2e/mic_ouvindo_texto.png')
        # 6) pausar: captura encerra, texto fica, nada é enviado, microfone volta ao normal
        n_env = len(envios); pg.click(MIC); pg.wait_for_timeout(500)
        check(f'{nome} 6: pausar interrompe a captura, mantém o texto e NÃO envia', ativos() == 0 and campo().lower() == frase.lower() and len(envios) == n_env, (ativos(), campo(), len(envios) - n_env))
        espera(f"getComputedStyle(document.querySelector('[data-ditado-estado]')).backgroundColor==={bg_parado!r}", 1500)
        check(f'{nome} 6b: depois de pausar o botão volta a ser o microfone normal e o indicador some', estado() == 'inativo' and rotulo() == 'Ditar mensagem' and fundo() == bg_parado and ind() is None, (estado(), rotulo(), fundo(), ind()))
        fala('palavra atrasada'); pg.wait_for_timeout(800)
        check(f'{nome} 6c: nada chega ao campo depois da pausa', 'atrasada' not in campo(), campo())
        # 7) editar depois de pausar
        pg.click(TA); pg.evaluate(f"(()=>{{const t=document.querySelector('{TA}');t.setSelectionRange(t.value.length,t.value.length)}})()"); pg.keyboard.type(' às 9h'); pg.wait_for_timeout(200)
        check(f'{nome} 7: o texto pode ser editado depois de pausar', campo().endswith('às 9h') and not pg.evaluate(f"document.querySelector('{TA}').readOnly"), campo())
        # 11a) envio normal do texto editado (o chat processa normalmente)
        n_env = len(envios); pg.locator('button[aria-label="Enviar"]').click(); pg.wait_for_timeout(1500)
        enviados = [x for x in envios[n_env:] if 'fornecedor' in x]
        check(f'{nome} 11: o texto editado é enviado uma vez e o chat segue normal', len(enviados) == 1 and 'às 9h' in enviados[0] and campo() == '', (enviados, campo()))
        # 8/9) enviar DURANTE a captura: encerra, envia o texto disponível, uma vez, sem esperar pausa
        pg.wait_for_timeout(1500); pg.click(MIC); espera("document.querySelector('[data-ditado-estado=listening]')")
        fala('qual o horário de funcionamento'); espera(f"document.querySelector('{TA}').value.includes('funcionamento')", 4000)
        n_env = len(envios); t1 = time.time(); pg.locator('button[aria-label="Enviar"]').click()
        pg.wait_for_function("document.querySelector('textarea[data-composer-input]').value===''", timeout=3000); dt = (time.time() - t1) * 1000
        pg.locator('button[aria-label="Enviar"]').click(force=True); pg.wait_for_timeout(1500)
        env = [x for x in envios[n_env:] if 'funcionamento' in x]
        check(f'{nome} 8: enviar durante a captura encerra a escuta e envia na hora ({dt:.0f} ms)', ativos() == 0 and dt < 1500 and len(env) >= 1 and estado() == 'inativo', (ativos(), dt, len(env), estado()))
        check(f'{nome} 9: a mensagem é enviada UMA vez (mesmo com clique repetido)', len(env) == 1 and len(envios) - n_env == 1, envios[n_env:])
        fala('texto fantasma'); pg.wait_for_timeout(700)
        check(f'{nome} 8b: depois do envio nenhum texto reaparece no campo', campo() == '' and ind() is None, campo())
        # 10) permissão negada
        pg.wait_for_timeout(1200); pg.fill(TA, 'fica aqui'); pg.evaluate("window.__falhaInicio='not-allowed';window.__permMic='denied'"); pg.click(MIC); pg.wait_for_timeout(900)
        aviso = pg.inner_text('[data-ditado-aviso]') if pg.locator('[data-ditado-aviso]').count() else ''
        check(f'{nome} 10: permissão negada → aviso claro, texto preservado, botão normal e sem "Ouvindo"', 'microfone' in aviso.lower() and campo() == 'fica aqui' and estado() in ('inativo', 'erro') and fundo() != VERMELHO and ind() is None, (aviso, campo(), estado(), fundo()))
        pg.evaluate("window.__falhaInicio='';window.__permMic='granted'")
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"\n{'FIM OK' if all(res) else 'FIM FALHOU'} {sum(res)}/{len(res)}")
