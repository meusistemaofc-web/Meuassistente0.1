# Relatórios com a imagem real dos itens vendidos, pela tela (Sua empresa → Relatórios), celular (escuro) e computador (claro):
#   - "Mais vendidos no período": imagem real do produto e do serviço (carregada, proporção preservada, sem corte), espaço
#     reservado padrão para item sem foto, nome, quantidade e valor batendo com a API; ordem por valor.
#   - Indicadores, gráficos e filtros de período preservados (7/30/90 dias); trocar o período mantém as imagens.
#   - Imagem quebrada vira espaço reservado sem mexer no layout; sem rolagem lateral; sem erros de JavaScript.
# Servidor: PORT=4404 SQLITE_FILE=/tmp/ma-relimg.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, io, base64, datetime
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4404'; DBF = '/tmp/ma-relimg.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
def foto(cor, w, h):  # imagens com proporções diferentes (paisagem e retrato) para conferir que não há distorção
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Rel', 'whatsapp': '+55 11 94444-0301', 'email': 'admin.rel@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
    for i, (nome, vp, mob, tema) in enumerate([('celular', {'width': 390, 'height': 844}, True, 'dark'), ('computador', {'width': 1280, 'height': 900}, False, 'light')]):
        print('==', nome, tema)
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona ' + nome, 'whatsapp': '+55 11 93333-' + ('5151' if mob else '5252'), 'email': f'rel.{nome}@t.com', **U}).ok
        R.patch('/api/me', data={'settings': {'theme': tema}})
        ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Ateliê {nome}', 'categoria': 'Ateliê', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}).json()['items'][0]['id']
        db("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,))
        def mk(d):
            r = R.post(f'/api/v2/ads/{ID}/products', data=d).json(); assert 'items' in r, r
            return [x for x in r['items'] if x['nome'] == d['nome']][0]['id']
        pBolo = mk({'nome': 'Bolo de cenoura', 'preco': 40, 'categoria': 'Bolos', 'fotos': [foto((200, 120, 40), 400, 200)]})  # paisagem 2:1
        pVaso = mk({'nome': 'Vaso de cerâmica', 'preco': 25, 'categoria': 'Casa', 'fotos': [foto((40, 110, 190), 150, 300)]})   # retrato 1:2
        # serviço já vendido (ex.: de antes de a empresa trocar o tipo de catálogo — o histórico de vendas continua valendo)
        db("insert into products (business_id, data, active) values (?,?,1)", (ID, json.dumps({'nome': 'Aula de pintura', 'tipo': 'servico', 'preco': 120, 'duracao': 60, 'categoria': 'Serviços', 'fotos': [foto((150, 60, 170), 300, 300)]})))
        sAula = db('select max(id) from products where business_id=?', (ID,))[0][0]
        owner = db('select owner_id from businesses where id=?', (ID,))[0][0]; agora = datetime.datetime.now(datetime.UTC).isoformat()
        def ped(total, data): db("insert into orders (business_id, customer_id, status, total, data, created_at, updated_at) values (?,?,'concluido',?,?,?,?)", (ID, owner, total, json.dumps({'pagamento': 'pix', **data}), agora, agora))
        ped(120, {'itens': [{'pid': pBolo, 'nome': 'Bolo de cenoura', 'qtd': 3, 'preco': 40}]})
        ped(50, {'itens': [{'pid': pVaso, 'nome': 'Vaso de cerâmica', 'qtd': 2, 'preco': 25}, {'nome': 'Embalagem presente', 'qtd': 1, 'preco': 8}]})
        ped(120, {'tipo': 'agendamento', 'servico': 'Aula de pintura', 'servicoId': sAula, 'data': '2026-11-20', 'hora': '10:00', 'itens': [{'nome': 'Aula de pintura', 'qtd': 1, 'preco': 120}]})
        api = R.get(f'/api/v2/ads/{ID}/report?dias=30').json()['vendas']
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('#hr_rel', timeout=20000); pg.click('#hr_rel'); pg.wait_for_selector('[data-rel-top] [data-rel-item]', timeout=10000)
        pg.wait_for_function("[...document.querySelectorAll('[data-rel-item] img')].every(i=>i.complete)", timeout=10000); pg.wait_for_timeout(300)
        itens = pg.evaluate("""[...document.querySelectorAll('[data-rel-item]')].map(e=>{const im=e.querySelector('img'),th=e.querySelector('.ma-oth'),r=th.getBoundingClientRect();
          return {nome:e.querySelector('.ma-rtop-nm').textContent,qtd:e.querySelector('[data-rel-qtd]').textContent,valor:e.querySelector('[data-rel-valor]').textContent.replace(/\\u00a0/g,' '),
            foto:th.dataset.oiFoto,nw:im?im.naturalWidth:0,nh:im?im.naturalHeight:0,fit:im?getComputedStyle(im).objectFit:null,w:r.width,h:r.height,ph:!!th.querySelector('svg')}})""")
        by = {x['nome']: x for x in itens}
        check(f'{nome}: lista "Mais vendidos" com os 4 itens na mesma ordem da API (por valor)', [x['nome'] for x in itens] == [t['nome'] for t in api['topProdutos']] and len(itens) == 4, ([x['nome'] for x in itens], [t['nome'] for t in api['topProdutos']]))
        brl = lambda v: 'R$ ' + f'{v:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
        check(f'{nome}: quantidade e valor de cada item batem com os dados', all(by[t['nome']]['valor'] == brl(t['valor']) and by[t['nome']]['qtd'].startswith(str(t['qtd']) + ' ') for t in api['topProdutos']), (itens, api['topProdutos']))
        check(f'{nome}: imagem REAL do produto e do serviço carregada (tamanho original)', (by['Bolo de cenoura']['nw'], by['Bolo de cenoura']['nh']) == (400, 200) and (by['Vaso de cerâmica']['nw'], by['Vaso de cerâmica']['nh']) == (150, 300) and by['Aula de pintura']['nw'] == 300, by)
        check(f'{nome}: imagem inteira, sem distorção nem corte (contain) em miniatura quadrada discreta', all(by[n]['fit'] == 'contain' and abs(by[n]['w'] - 44) < 1 and abs(by[n]['h'] - 44) < 1 for n in ['Bolo de cenoura', 'Vaso de cerâmica', 'Aula de pintura']), by)
        check(f'{nome}: item sem cadastro mostra o espaço reservado padrão do sistema', by['Embalagem presente']['foto'] == '0' and by['Embalagem presente']['nw'] == 0 and by['Embalagem presente']['ph'])
        check(f'{nome}: serviço identificado como venda ("1 venda")', by['Aula de pintura']['qtd'] == '1 venda')
        check(f'{nome}: indicadores e gráficos preservados', all(t.lower() in pg.inner_text('body').lower() for t in ['Faturamento', 'Ticket médio', 'Visitas por dia', 'Vendas por dia', 'Análise e MEI', 'Por pagamento']) and 'R$ 290,00' in pg.inner_text('body').replace('\xa0', ' '), pg.inner_text('#rel-vendas').replace('\xa0', ' ') + ' | ' + pg.inner_text('body').replace('\xa0', ' ')[600:1300])
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: sem rolagem lateral', ow <= 1, ow)
        pg.locator('[data-rel-top]').scroll_into_view_if_needed(); pg.screenshot(path=f'/tmp/e2e/relatorios_imagens_{nome}.png')
        # filtro de período: continua funcionando e as imagens permanecem
        pg.click('[data-rd="7"]'); pg.wait_for_selector('[data-rd="7"].btn-send', timeout=8000); pg.wait_for_selector('[data-rel-item] img', timeout=8000)
        check(f'{nome}: trocar o período (7 dias) mantém a lista com imagens', pg.locator('[data-rel-item]').count() == 4 and pg.locator('[data-rel-item] img').count() == 3)
        # imagem que falha ao carregar: vira espaço reservado sem mudar o layout
        hb = pg.locator('[data-rel-item]').first.bounding_box()['height']
        pg.evaluate("document.querySelector('[data-rel-item] img').src='/api/v2/pedidos/1/itens/0/foto?s=invalida'"); pg.wait_for_timeout(800)
        check(f'{nome}: imagem quebrada vira espaço reservado sem mexer no layout', pg.locator('[data-rel-item]').first.locator('.ma-oth').get_attribute('data-oi-foto') == '0' and abs(pg.locator('[data-rel-item]').first.bounding_box()['height'] - hb) < 1)
        th = pg.evaluate("document.documentElement.dataset.theme"); check(f'{nome}: tema {tema}', th == tema, th)
        c.close()
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
