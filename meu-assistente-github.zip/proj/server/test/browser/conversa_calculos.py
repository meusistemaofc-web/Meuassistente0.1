# Interpretação e cálculos pela TELA REAL do chat (25/11): conversões determinísticas, "E dois?" pelo contexto, correção,
# comentário informal e esclarecimento sem contexto. Confere o que aparece na bolha, que a resposta chega (sem ficar
# "processando"), que nada é enviado em dobro e quanto tempo cada resposta leva do clique até aparecer.
# Servidor: PORT=4349 SQLITE_FILE=/tmp/ma-calc.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4349'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 5), ('computador', {'width': 1280, 'height': 900}, False, 6)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Calc Teste', 'whatsapp': f'+55 11 95555-{k}{k}{k}{k}', 'email': f'calc{k}.{int(time.time())}@t.com', **U}, headers={'X-Forwarded-For': f'10.9.7.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios = []
        pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(400)
        ta = pg.locator('textarea[data-composer-input]')
        def bolhas(): return pg.evaluate("()=>[...document.querySelectorAll('[data-role=\"assistant\"], .msg-assistant, .bubble-assistant, [data-msg-role=\"assistant\"]')].map(e=>e.innerText.trim())")
        def enviar(t, espera):
            n = len(envios); antes = pg.inner_text('body'); t0 = time.time(); ta.click(); ta.fill(t); ta.press('Enter')
            ok = False
            while time.time() - t0 < 15:
                if espera in pg.inner_text('body').replace(antes, '', 1) or pg.inner_text('body').count(espera) > antes.count(espera): ok = True; break
                pg.wait_for_timeout(50)
            ms = int((time.time() - t0) * 1000); pg.wait_for_timeout(300)
            return ok, ms, len(envios) - n
        def novaConversa():
            pg.goto('/?nova=' + str(time.time())); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(600)
            bt = pg.locator('button[aria-label="Nova conversa"], button:has-text("Nova conversa")')
            if bt.count(): bt.first.click(); pg.wait_for_timeout(600)
        for t, esp in [('Quantas horas tem 4 dias?', '4 dias têm 96 horas.'), ('Quantas horas tem 1 dia?', '1 dia tem 24 horas.'), ('E dois?', 'Dois dias têm 48 horas.'), ('Digo dois dias tem quantas horas?', 'Dois dias têm 48 horas.'), ('Na verdade, 5 dias.', '5 dias têm 120 horas.'), ('Agora o dobro.', '10 dias têm 240 horas.'), ('E em minutos?', '10 dias têm 14.400 minutos.')]:
            ok, ms, n = enviar(t, esp)
            check(f'{nome}: "{t}" → "{esp}" na tela em {ms} ms, enviado {n}x', ok and n == 1 and ms < 4000, (ok, ms, n))
        novaConversa()
        ok, ms, n = enviar('E dois?', 'ainda não há um assunto anterior nesta conversa')
        check(f'{nome}: conversa nova, "E dois?" pede esclarecimento ({ms} ms)', ok and n == 1, (ok, ms, n))
        ok, ms, n = enviar('Amanhã vai ser corrido.', 'Amanhã vai ser corrido.')
        pg.wait_for_timeout(1500)
        corpo = pg.inner_text('body')
        check(f'{nome}: comentário informal tem resposta e nada de "Serviço Social"/consultas empresariais', 'Serviço Social' not in corpo and 'ainda não há um assunto anterior nesta conversa. Pode me dizer a pergunta completa?' in corpo, corpo[-300:])
        ok, ms, n = enviar('Quantas horas tem 3 dias?', '3 dias têm 72 horas.')
        check(f'{nome}: cálculo depois do comentário, sem contaminação ({ms} ms)', ok and n == 1, (ok, ms, n))
        check(f'{nome}: sem indicador de "processando" preso no fim', not pg.locator('.typing, .digitando, [data-thinking="true"], [aria-label="Pensando"]').count() or not pg.locator('.typing, .digitando, [data-thinking="true"], [aria-label="Pensando"]').first.is_visible())
        C.close()
    check('sem erros de JavaScript na página (fora o aviso #418 de hidratação, já conhecido)', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'{sum(res)}/{len(res)} verificações')
