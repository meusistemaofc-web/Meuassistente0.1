# Padrões de uso no painel (Aprendizado e Evolução → Aprendizados por usuário → aba "Padrões de uso"), pela tela real:
#   - o chat aprende pelo uso (3 tatuagens) e usa o padrão num pedido ambíguo, sem criar nada antes da resposta;
#   - o administrador vê os padrões observados de cada usuário (nível, confiança, estado), só leitura, separados da fila de
#     revisão das regras (que não recebe padrões); padrão pausado pela pessoa aparece como "Pausado pela pessoa";
#   - celular e computador, sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4411 SQLITE_FILE=/tmp/ma-aprpad.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4411'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900})
    assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Apr', 'whatsapp': '+55 11 94444-0711', 'email': 'admin.apr@t.com', **U}).ok
    st_admin = A.storage_state()
    C = b.new_context(base_url=BASE); R = C.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Tina Tatuadora', 'whatsapp': '+55 11 95566-0101', 'email': 'tina.apr@t.com', **U}, headers={'X-Forwarded-For': '10.5.4.1'}).ok
    conv = 'a1a1a1a1-0000-4000-8000-000000000001'
    for t in ['agende uma tatuagem com o Pedro amanhã às 14h', 'agende uma tatuagem com a Carla sexta às 10h', 'agende uma tatuagem com o Leo sábado às 11h']:
        assert R.post('/api/chat', data={'text': t, 'conversationId': conv}).ok
    r = R.post('/api/chat', data={'text': 'quero agendar um serviço amanhã às 9h', 'conversationId': 'b2b2b2b2-0000-4000-8000-000000000001'}).json()['assistantMessage']['content']
    check('chat usa o padrão no pedido ambíguo ("Você costuma agendar tatuagens…")', 'Você costuma agendar tatuagens' in r, r)
    for nome, vp, mob in [('computador', {'width': 1280, 'height': 900}, False), ('celular', {'width': 390, 'height': 844}, True)]:
        print('==', nome)
        X = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob, storage_state=st_admin)
        pg = X.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/admin'); pg.wait_for_timeout(2000); aba(pg, 'cb_aprendizados'); pg.wait_for_selector('#apr_rev [data-aprf="padroes"]', timeout=20000)
        check(f'{nome}: a fila de revisão de regras não mostra padrões de uso', pg.locator('#apr_rev [data-pad]').count() == 0 and 'Agenda com frequência' not in pg.inner_text('#apr_rev'))
        pg.click('#apr_rev [data-aprf="padroes"]'); pg.wait_for_selector('#apr_rev [data-pad]', timeout=10000); pg.wait_for_timeout(300)
        card = pg.locator('#apr_rev [data-pad]', has_text='Tatuagem')
        tx = card.inner_text() if card.count() else pg.inner_text('#apr_rev')
        check(f'{nome}: aba "Padrões de uso": usuário, padrão, nível e confiança', card.count() == 1 and 'Tina Tatuadora' in tx and 'Agenda com frequência: Tatuagem' in tx and 'Recorrente' in tx and 'confiança' in tx, tx[:300])
        check(f'{nome}: só leitura (sem Aprovar/Rejeitar para padrões)', card.locator('[data-ra]').count() == 0)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.locator('#apr_rev').screenshot(path=f'/tmp/e2e/padroes_uso_admin_{nome}.png')
        if nome == 'computador':
            pid = [x for x in R.get('/api/learning').json()['itens'] if x['kind'] == 'padrao_uso'][0]['id']
            R.post('/api/learning', data={'action': 'update', 'id': pid, 'estado': 'pausado'})
            pg.click('#apr_rev [data-aprf="padroes"]'); pg.wait_for_timeout(800)
            check(f'{nome}: pausado pela pessoa aparece como tal', 'Pausado pela pessoa' in pg.locator('#apr_rev [data-pad]', has_text='Tatuagem').inner_text())
            r = R.post('/api/chat', data={'text': 'quero agendar um serviço amanhã às 10h', 'conversationId': 'c3c3c3c3-0000-4000-8000-000000000001'}).json()['assistantMessage']['content']
            check('pausado: o chat não usa mais', 'tatuag' not in r.lower(), r)
        X.close()
    check('sem erros de JavaScript', not [e for e in errs if e != 'Event' and '#418' not in e], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
