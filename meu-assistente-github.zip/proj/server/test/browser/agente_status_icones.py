# Agente de atendimento (Sua empresa): estado reconhecido corretamente e ícones das opções.
#  • agente contratado noutra empresa no ar → tela mostra "Seu agente já está contratado", sem "não contratado" nem Ativar;
#    "Usar meu agente nesta empresa" traz o agente (no ar, mesmo prazo, sem cobrança)
#  • anúncio antigo encerrado → a empresa nova abre direto com o agente no ar
#  • sem agente → "Agente não contratado" e o botão Ativar
#  • ícones: Lojas Conectadas = chave (chave de conexão), Agente de atendimento = atendente com headset; sem ícone repetido
# Celular e computador.  Servidor: PORT=4355 SQLITE_FILE=/tmp/ma-agst.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, json
from playwright.sync_api import sync_playwright
BASE='http://localhost:4355'; DBF='/tmp/ma-agst.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
fut=lambda d:(datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=d)).isoformat()
def sql(q,a=()):
    db=sqlite3.connect(DBF); r=db.execute(q,a).fetchall(); db.commit(); db.close(); return r
def ativar(bid,status='ativo'): sql("update businesses set status=?, expires_at=? where id=?",(status,fut(30),bid))
def contratar(bid,nome):  # estado gravado quando o Pix do agente é aprovado (activateAgent)
    d=json.loads(sql('select data from businesses where id=?',(bid,))[0][0]); d['agente']={'nome':nome,'saudacao':'Olá!','instrucoes':'','tom':'amigavel','ativo':True,'expiresAt':fut(25),'lastPayment':'pix-123'}
    sql('update businesses set data=? where id=?',(json.dumps(d),bid))
CHAVE='M11.03 10.11 3.57 17.57'; HEADSET='M5.9 8.6a6.1 6.1 0 0 1 12.2 0'
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True,'agente':True}).ok
    def dono(nome,email,zap):
        c=b.new_context(base_url=BASE); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':zap,'email':email,'birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
        return c,R
    def empresa(R,nome,plano='n4'):
        r=R.post('/api/v2/ads',data={'planId':plano,'empresa':nome,'categoria':'Pizzaria','titulo':nome,'texto':'Forno a lenha','zap':'5511999990000','lat':-23.55,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
        bid=r.json()['items'][0]['id']; ativar(bid); return bid
    # dono 1: agente na Pizzaria (no ar) e abre a Lanchonete
    c1,R1=dono('Dona Ana','ana@t.com','+55 11 93330-1111'); P1=empresa(R1,'Pizzaria Bella'); L1=empresa(R1,'Lanchonete Bella','n2'); contratar(P1,'Bia')
    # dono 2: agente na empresa antiga (encerrada) e anúncio novo
    c2,R2=dono('Dono Beto','beto@t.com','+55 11 93330-2222'); V2=empresa(R2,'Barbearia Beto'); contratar(V2,'Leo'); sql("update businesses set status='encerrado' where id=?",(V2,)); N2=empresa(R2,'Barbearia Beto')
    # dono 3: sem agente
    c3,R3=dono('Dona Carla','carla@t.com','+55 11 93330-3333'); C3=empresa(R3,'Doceria Carla')
    def abrir_agente(ctx,bid,vp,mob):
        c=b.new_context(base_url=BASE,viewport=vp,has_touch=mob,is_mobile=mob); c.add_cookies(ctx.cookies()); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav',timeout=20000); pg.wait_for_timeout(500)
        if pg.locator(f'[data-sel="{bid}"]').count(): pg.locator(f'[data-sel="{bid}"]').first.click(); pg.wait_for_timeout(800)
        if not pg.locator('[data-agente]').count(): pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_timeout(800)
        row=pg.locator('[data-agente]').first; row.scroll_into_view_if_needed(); return c,pg,row
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        # ícones (dono 1, empresa com plano completo)
        c,pg,row=abrir_agente(c1,P1,vp,mob)
        ic=row.locator('svg').inner_html()
        check(f'{nome}: opção "Agente de atendimento" com ícone de atendente com headset', HEADSET in ic, ic[:120])
        lj=pg.locator('[data-lt2="lojas"]')
        if not lj.count(): pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_timeout(600); lj=pg.locator('[data-lt2="lojas"],[data-lt="lojas"]')
        check(f'{nome}: opção "Lojas Conectadas" com ícone de chave (chave de conexão)', lj.count()>0 and CHAVE in lj.first.locator('svg').inner_html(), lj.count())
        check(f'{nome}: ícones do menu válidos e sem repetição', pg.evaluate('window.__maIconErros')==[] and pg.evaluate("(()=>{const m=window.__maMenuIcones.MENU_AJUSTES;return m.lojas==='chave'&&m.agente==='headset'&&new Set(Object.values(m)).size===Object.values(m).length})()"))
        lj.first.scroll_into_view_if_needed(); pg.wait_for_timeout(200); pg.screenshot(path=f'/tmp/icones_{nome}.png')
        c.close()
        # agente no ar noutra empresa (Lanchonete)
        c,pg,row=abrir_agente(c1,L1,vp,mob)
        if nome=='celular': check('menu da Lanchonete diz onde o agente está contratado', 'Contratado em Pizzaria Bella' in row.inner_text(), row.inner_text())
        row.click(); pg.wait_for_selector('[data-ag-outra]',timeout=15000); t=pg.locator('#ma-x').inner_text()
        check(f'{nome}: agente em outra empresa é reconhecido ("Seu agente já está contratado", Pizzaria Bella)', 'Seu agente já está contratado' in t and 'Pizzaria Bella' in t, t[:300])
        check(f'{nome}: nada de "Agente não contratado" nem botão de Ativar/pagar', 'não contratado' not in t and pg.locator('#agpay2').count()==0, t[:200])
        pg.screenshot(path=f'/tmp/agente_outra_{nome}.png')
        if nome=='computador':
            pg.click('#agmv'); pg.wait_for_function("()=>/Agente no ar/.test(document.body.innerText)",timeout=10000)
            d1=json.loads(sql('select data from businesses where id=?',(P1,))[0][0]); d2=json.loads(sql('select data from businesses where id=?',(L1,))[0][0])
            check('"Usar meu agente nesta empresa": no ar aqui, com o mesmo nome e prazo, e saiu da outra', 'agente' not in d1 and d2['agente']['nome']=='Bia' and d2['agente']['lastPayment']=='pix-123' and 'Agente no ar' in pg.locator('#ma-x').inner_text())
        c.close()
        # anúncio antigo encerrado → empresa nova reconhece direto
        c,pg,row=abrir_agente(c2,N2,vp,mob); row.click(); pg.wait_for_function("()=>/Atendente virtual da sua empresa|Seu agente já está/.test(document.body.innerText)",timeout=15000); t=pg.locator('#ma-x').inner_text()
        check(f'{nome}: anúncio antigo encerrado → empresa nova abre com o agente no ar (sem pagar de novo)', 'Agente no ar' in t and 'não contratado' not in t and pg.locator('#agpay2').count()==0, t[:250])
        c.close()
        # sem agente → não contratado + Ativar
        c,pg,row=abrir_agente(c3,C3,vp,mob); row.click(); pg.wait_for_function("()=>/Atendente virtual da sua empresa/.test(document.body.innerText)",timeout=15000); t=pg.locator('#ma-x').inner_text()
        check(f'{nome}: sem agente → "Agente não contratado" e botão para ativar', 'Agente não contratado' in t and pg.locator('#agpay2').count()==1, t[:250])
        if nome=='celular': pg.screenshot(path='/tmp/agente_nao_contratado.png')
        c.close()
    # nenhum agente duplicado
    tot={}
    for (bid,data,owner) in sql('select id,data,owner_id from businesses'):
        if 'agente' in json.loads(data): tot[owner]=tot.get(owner,0)+1
    check('nenhum dono com dois agentes', all(v==1 for v in tot.values()), tot)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
