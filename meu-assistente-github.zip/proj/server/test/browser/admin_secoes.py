# Central "Inteligência do Chat" (celular e computador): o botão do topo mostra a central e a subseção; o menu tem 2 áreas
# (Inteligência do Chat com 7 subseções + Plataforma e Negócio), sem seções de inteligência soltas; nenhuma subaba repetida;
# Visão Geral com indicadores e componentes principais REAIS (conferidos contra a API); TODAS as subabas abrem sem erro;
# Resumo de Raciocínio e Orquestração reúne raciocínio, ferramentas e execução; "Cérebro e busca" separado; Rastreamento,
# Arquitetura; links antigos (?aba=, ?secao=ferramentas/execucao) e novos; a subaba aberta volta depois de recarregar; uma
# configuração salva por dentro da central chega ao servidor e volta; páginas próprias voltam para a central; teclado; sem
# rolagem lateral e sem erros de JavaScript.
# Servidor: PORT=4343 SQLITE_FILE=/tmp/ma-admsec.db npx tsx test/serve-sqlite.ts (banco novo)
import sys, re, uuid
from playwright.sync_api import sync_playwright
BASE='http://localhost:4343'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE); assert A.request.post('/api/auth',data={'action':'signup','name':'Admin Seções','whatsapp':'+55 11 94444-1311','email':'admin.sec@t.com',**U}).ok
    UC=b.new_context(base_url=BASE); assert UC.request.post('/api/auth',data={'action':'signup','name':'Usuária Seções','whatsapp':'+55 11 98888-1311','email':'user.sec@t.com',**U},headers={'X-Forwarded-For':'10.8.8.8'}).ok
    for t in ['quanto é 12 * 7?','gastei 30 no mercado','me explique o que é a fotossíntese']:
        r=UC.request.post('/api/chat',data={'text':t,'conversationId':str(uuid.uuid4())}); assert r.ok, (t,r.status)
    secs=A.request.get('/api/panel/orquestracao').json()
    for nome,vp,mob in [('computador',{'width':1280,'height':900},False),('celular',{'width':390,'height':844},True)]:
        print('==',nome)
        C=b.new_context(base_url=BASE,viewport=vp,is_mobile=mob,has_touch=mob); C.add_cookies(A.cookies()); pg=C.new_page()
        pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/admin'); pg.wait_for_selector('#orq_kpis',timeout=20000)
        topo=pg.inner_text('#ma-an-secao')
        check(f'{nome}: abre na central Inteligência do Chat · Visão Geral', 'Inteligência do Chat' in topo and 'Visão Geral' in topo and '1 de 7' in topo, topo)
        k=pg.inner_text('#orq_kpis')
        check(f'{nome}: indicadores reais do chat (3 respostas nas 24 h)', re.match(r'\s*3\s*Respostas',k) is not None, k[:120])
        check(f'{nome}: estado por área (6 áreas da central, além da Visão Geral)', pg.locator('#orq_secoes [data-ir-secao]').count()==6)
        princ=pg.evaluate("()=>[...document.querySelectorAll('#orq_principais [data-principal]')].map(b=>[b.dataset.principal,b.querySelector('.ma-pill')?b.querySelector('.ma-pill').innerText.trim():''])")
        ESTN={'ativo':'Ativo','sem_uso':'Sem uso recente','desligado':'Desligado','atencao':'Atenção','falha':'Com falha'}
        reais={c['id']:ESTN[c['estado']] for c in secs['componentes']}
        check(f'{nome}: componentes principais (Cérebro, raciocínio, provedores/fallback, voz, aprendizado, previsões…) com o estado REAL da API', len(princ)==9 and all(reais.get(i)==e for i,e in princ), princ)
        check(f'{nome}: orquestrador do chat com as etapas reais do pipeline', f"{len(secs['pipeline'])} etapas" in pg.inner_text('#orq_orquestrador'))
        check(f'{nome}: barra antiga de 35 abas escondida', pg.locator('div.glass.no-scrollbar').first.is_hidden())
        pg.click('#ma-an-secao'); pg.wait_for_selector('#ma-an-menu:not([hidden])')
        itens=pg.evaluate("()=>[...document.querySelectorAll('#ma-an-menu [data-secao]')].map(b=>[b.dataset.area,b.dataset.secao,b.querySelector('.t').innerText])")
        heads=[x.strip() for x in pg.locator('#ma-an-menu .ma-an-h').all_inner_texts()]
        check(f'{nome}: menu = Inteligência do Chat (7 subseções) + Plataforma e Negócio', [h.lower() for h in heads]==['inteligência do chat','plataforma e negócio'] and [i[2] for i in itens if i[0]=='chat']==['Visão Geral','Cérebro e Conhecimento','Raciocínio e Orquestração','IA, Provedores e Voz','Aprendizado e Evolução','Inteligência Preditiva','Diagnóstico e Auditoria'] and [i[1] for i in itens if i[0]=='plataforma']==['plataforma'], (heads,itens))
        check(f'{nome}: seções antigas soltas não existem mais (Ferramentas e Integrações, Execução e Autonomia)', not [i for i in itens if i[1] in ('ferramentas','execucao')] and not any(n in pg.inner_text('#ma-an-menu') for n in ['IAs e Provedores','Inteligência e Raciocínio','Ferramentas e Integrações','Execução e Autonomia']))
        cor=lambda cs:'bad' if any(c['estado']=='falha' for c in cs) else 'warn' if any(c['estado']=='atencao' for c in cs) else 'ok' if any(c['estado']=='ativo' for c in cs) else ''
        esper={a:cor([c for c in secs['componentes'] if c['area']==a]) for a in ['cerebro','raciocinio','provedores','aprendizado','preditiva','diagnostico']}
        vistos=pg.evaluate("()=>Object.fromEntries([...document.querySelectorAll('#ma-an-menu [data-area=\"chat\"]')].map(b=>[b.dataset.secao,(b.querySelector('.ma-an-dot').className.split(' ')[1]||'')]))")
        check(f'{nome}: cada subseção da central com o indicador do estado real dos seus componentes', all(vistos.get(a)==e for a,e in esper.items()), (esper,vistos))
        if nome=='celular': pg.screenshot(path='/tmp/e2e/admin_central_menu_celular.png')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
        check(f'{nome}: Esc fecha o menu e volta o foco ao botão', pg.locator('#ma-an-menu').is_hidden() and pg.evaluate("document.activeElement&&document.activeElement.id")=='ma-an-secao')
        if nome=='computador': pg.screenshot(path='/tmp/e2e/admin_central_visao_computador.png',full_page=True)
        # TODAS as subabas de todas as seções abrem sem erro
        mapa=pg.evaluate("()=>[...document.querySelectorAll('#ma-an-menu [data-secao]')].map(b=>b.dataset.secao)")
        falhas=[]; total=0
        for sec in mapa:
            pg.click('#ma-an-secao'); pg.click(f'#ma-an-menu [data-secao="{sec}"]'); pg.wait_for_timeout(500)
            subs=pg.evaluate("()=>[...document.querySelectorAll('#ma-adm-nav [data-sub]')].map(b=>b.dataset.sub)")
            if not subs: subs=['visao']
            for sb in subs:
                total+=1; n0=len(errs)
                if pg.locator(f'#ma-adm-nav [data-sub="{sb}"]').is_visible():  # seção com uma só subaba não mostra a fileira
                    pg.locator(f'#ma-adm-nav [data-sub="{sb}"]').click()
                pg.wait_for_timeout(900)
                sel=pg.evaluate("()=>{const b=document.querySelector('#ma-adm-nav [data-sub][aria-selected=\"true\"]');return b?b.dataset.sub:null}")
                vis=pg.evaluate("()=>{const h=document.getElementById('ma-admin-pane');if(h&&h.style.display!=='none'&&h.innerText.trim().length>20)return 'addon';let n=document.getElementById('ma-adm-nav').nextElementSibling;n=n&&n.nextElementSibling;while(n){if(n.id!=='ma-admin-pane'&&n.offsetParent&&n.getBoundingClientRect().height>20)return 'react';n=n.nextElementSibling}return ''}")
                novos=[e for e in errs[n0:] if '#418' not in e and e!='Event']
                if (sel!=sb and len(subs)>1) or not vis or novos: falhas.append((sec,sb,sel,vis,novos[:1]))
        check(f'{nome}: todas as {total} subabas abrem com conteúdo e sem erro', not falhas and total>=50, falhas[:4])
        todas=pg.evaluate("()=>{const out=[];for(const b of document.querySelectorAll('#ma-an-menu [data-secao]'))out.push(b.dataset.secao);return out}")
        chaves=[]
        for sec in todas:
            pg.click('#ma-an-secao'); pg.click(f'#ma-an-menu [data-secao="{sec}"]'); pg.wait_for_timeout(300)
            chaves+=pg.evaluate("()=>[...document.querySelectorAll('#ma-adm-nav [data-sub]')].map(b=>b.dataset.sub)") or ['visao']
        dup=sorted({k for k in chaves if chaves.count(k)>1})
        check(f'{nome}: nenhuma entrada duplicada ({len(chaves)} subabas, cada uma em um só lugar)', not dup, dup)
        # Resumo de seção: componentes verificados, detalhe expansível
        pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="raciocinio"]'); pg.wait_for_selector('[data-resumo="raciocinio"] .ma-cmp',timeout=10000)
        n_rac=len([c for c in secs['componentes'] if c['area']=='raciocinio'])
        check(f'{nome}: Resumo de Raciocínio e Orquestração reúne raciocínio, ferramentas e execução ({n_rac} componentes, 3 grupos)', n_rac==10 and pg.locator('[data-resumo="raciocinio"] .ma-cmp').count()==n_rac and pg.locator('[data-resumo="raciocinio"] [data-parte-resumo]').count()==3)
        pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="cerebro"]'); pg.wait_for_selector('[data-resumo="cerebro"] .ma-cmp',timeout=10000)
        check(f'{nome}: Cérebro e Conhecimento inclui a pesquisa na internet (busca e fontes)', pg.locator('[data-resumo="cerebro"] [data-cmp="pesquisa_web"]').count()==1)
        pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="raciocinio"]'); pg.wait_for_selector('[data-resumo="raciocinio"] .ma-cmp',timeout=10000)
        pg.locator('[data-resumo="raciocinio"] .ma-cmp summary').first.click(); pg.wait_for_timeout(200)
        check(f'{nome}: detalhe do componente abre (responsabilidade, números e código)', 'Código:' in pg.locator('[data-resumo="raciocinio"] .ma-cmp').first.inner_text())
        # "Cérebro e busca" separado: Cognição mostra só a cognição
        pg.click('#ma-adm-nav [data-sub="cb_cognicao"]'); pg.wait_for_selector('#cog_box',timeout=10000); pg.wait_for_timeout(600)
        check(f'{nome}: Cognição mostra só a sua parte da antiga página do cérebro', pg.locator('#cog_box').is_visible() and pg.locator('#n2_box').is_hidden() and pg.locator('#pd_box').is_hidden())
        # Rastreamento
        pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="diagnostico"]'); pg.click('#ma-adm-nav [data-sub="rastros"]'); pg.wait_for_selector('#rt_list .ma-tr',timeout=10000)
        check(f'{nome}: rastreamento lista as respostas', pg.locator('#rt_list .ma-tr').count()>=3)
        pg.locator('#rt_list .ma-tr summary').first.click(); pg.wait_for_timeout(200)
        tx=pg.locator('#rt_list .ma-tr').first.inner_text()
        check(f'{nome}: detalhe com etapas, provedor, fontes, ferramentas e ações', all(x in tx for x in ['Provedor','Fontes','Ferramentas','Ações']) and pg.locator('#rt_list .ma-tr').first.locator('.ma-bar').count()>=3, tx[:200])
        pg.click('[data-rtf="internas"]'); pg.wait_for_timeout(1200)
        vias=[x.strip() for x in pg.locator('#rt_list .ma-tr summary .ma-pill').all_inner_texts()]
        check(f'{nome}: filtro "Sem IA" não mostra respostas da IA', vias and 'IA' not in vias, vias)
        pg.click('#ma-adm-nav [data-sub="arquitetura"]'); pg.wait_for_selector('#arq_pipe li',timeout=10000)
        check(f'{nome}: Arquitetura com o pipeline (11 etapas) e as sobreposições', pg.locator('#arq_pipe li').count()==11 and pg.locator('#arq_sob .ma-cmp').count()>=5)
        if nome=='celular':
            pg.click('#ma-adm-nav [data-sub="rastros"]'); pg.wait_for_selector('#rt_list .ma-tr'); pg.locator('#rt_list .ma-tr summary').first.click(); pg.wait_for_timeout(300); pg.screenshot(path='/tmp/e2e/admin_secoes_rastro_celular.png')
            sw=pg.evaluate("()=>{const s=document.querySelector('.ma-an-sub');return s.scrollWidth>s.clientWidth}")
            check('celular: subabas em uma linha com rolagem lateral própria', sw)
        check(f'{nome}: sem rolagem lateral da página', pg.evaluate('document.documentElement.scrollWidth-innerWidth')<=1)
        # links antigos e novos
        pg.goto('/admin?aba=cerebro'); pg.wait_for_selector('#ma-adm-nav [data-sub="cb_conhecimento"][aria-selected="true"]',timeout=15000)
        check(f'{nome}: ?aba=cerebro (antigo "Cérebro e busca") abre Conhecimento operacional', 'Cérebro e Conhecimento' in pg.inner_text('#ma-an-secao'))
        for antigo,alvo in [('/admin?secao=ferramentas','res_raciocinio'),('/admin?secao=execucao','res_raciocinio'),('/admin?aba=res_ferramentas','res_raciocinio'),('/admin?aba=mp','mp'),('/admin?aba=lnk_agentes','lnk_agentes')]:
            pg.goto(antigo); ok=True
            try: pg.wait_for_selector(f'#ma-adm-nav [data-sub="{alvo}"][aria-selected="true"]',timeout=15000)
            except Exception: ok=False
            check(f'{nome}: link {antigo} abre {alvo}', ok)
        # estado de navegação preservado ao recarregar
        pg.goto('/admin'); pg.wait_for_selector('#ma-an-secao'); pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="aprendizado"]'); pg.click('#ma-adm-nav [data-sub="cb_aprendizados"]'); pg.wait_for_timeout(800)
        pg.reload(); ok=True
        try: pg.wait_for_selector('#ma-adm-nav [data-sub="cb_aprendizados"][aria-selected="true"]',timeout=15000)
        except Exception: ok=False
        check(f'{nome}: ao recarregar, volta para a subaba aberta (Aprendizado e Evolução → Aprendizados por usuário)', ok and 'Aprendizado e Evolução' in pg.inner_text('#ma-an-secao'))
        # configuração salva por dentro da central chega ao servidor (e é restaurada)
        if nome=='computador':
            antes=A.request.get('/api/panel').json()['modules'].get('agente')
            pg.click('#ma-an-secao'); pg.click('#ma-an-menu [data-secao="raciocinio"]'); pg.click('#ma-adm-nav [data-sub="agente"]'); pg.wait_for_selector('[data-sw="agon"]',timeout=10000)
            pg.click('[data-sw="agon"]'); pg.wait_for_timeout(1500)
            depois=A.request.get('/api/panel').json()['modules'].get('agente')
            pg.click('[data-sw="agon"]'); pg.wait_for_timeout(1500)
            volta=A.request.get('/api/panel').json()['modules'].get('agente')
            check('computador: configuração alterada dentro da central é salva no servidor e restaurada (Agente das empresas)', bool(antes)!=bool(depois) and bool(volta)==bool(antes), (antes,depois,volta))
            # páginas próprias (Cérebro Central, Agentes, Laboratório) voltam para a central
            for pag,alvo in [('/admin/cerebro-central','lnk_central'),('/admin/agentes','lnk_agentes'),('/admin/laboratorio','lnk_lab')]:
                pg.goto(pag); pg.wait_for_selector('a.voltar',timeout=15000)
                txt=pg.inner_text('a.voltar'); pg.click('a.voltar'); ok=True
                try: pg.wait_for_selector(f'#ma-adm-nav [data-sub="{alvo}"][aria-selected="true"]',timeout=15000)
                except Exception: ok=False
                check(f'computador: {pag} → "{txt.strip()}" volta para a subaba certa da central', ok and 'Inteligência do Chat' in txt)
        pg.goto('/admin?aba=moedas'); pg.wait_for_selector('#ma-adm-nav [data-sub="moedas"][aria-selected="true"]',timeout=15000)
        check(f'{nome}: ?aba=moedas abre MCoins em Plataforma e Negócio', 'Plataforma' in pg.inner_text('#ma-an-secao'))
        pg.goto('/admin?secao=diagnostico'); pg.wait_for_selector('[data-resumo="diagnostico"]',timeout=15000)
        check(f'{nome}: ?secao=diagnostico abre o Resumo do Diagnóstico', True)
        C.close()
    # usuário comum não vê a orquestração
    check('usuário comum não acessa a orquestração (403)', UC.request.get('/api/panel/orquestracao').status==403)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], [e for e in errs if '#418' not in e and e!='Event'][:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
