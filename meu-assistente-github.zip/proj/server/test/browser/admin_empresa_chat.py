# Administração da empresa pelo chat, pela tela real (celular): o dono pede uma alteração no chat e ela acontece na empresa
# ATIVA (conferida no banco); ação de impacto mostra os botões Confirmar/Cancelar e só executa com o toque em Confirmar.
# A IA é um dublê que chama a ferramenta pedida e responde só com o resultado dela (o servidor, as rotas e o banco são reais).
# Servidor: PORT=4353 SQLITE_FILE=/tmp/ma-admchat.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, base64, re
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4353'; DBF = '/tmp/ma-admchat.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor):
    b = io.BytesIO(); Image.new('RGB', (100, 100), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
def val(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchone(); db.close(); return r[0] if r else None
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono Mini', 'whatsapp': '+55 11 94444-5555', 'email': 'mini.adm@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Mini Isqueiros', 'categoria': 'Acessórios', 'titulo': 'Mini', 'texto': 'Isqueiros', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'dinheiro': True}, 'entrega': {'retirada': True}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Chaveiro', 'preco': 10, 'fotos': [img('teal')]}).ok
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
    bolhas = lambda: [N(t) for t in pg.locator('.chat-scroll .msg-bubble').all_inner_texts()]
    def enviar(t):
        n0 = len(bolhas()); pg.fill('textarea[data-composer-input]', t); pg.locator('button[aria-label="Enviar"]').click()
        pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_timeout(900)
        return bolhas()[-1]
    # 1) alteração simples: executa direto e responde com o resultado conferido
    t = enviar('Altere o preço do Chaveiro para R$ 12 xqz-emp {"acao":"produto_preco","produto":"Chaveiro","valor":12}')
    pr = json.loads(val("select data from products where business_id=?", ID))['preco']
    check('preço alterado pelo chat (resposta com antes → depois) e gravado', 'Pronto! Mini Isqueiros' in t and 'R$ 10,00 → R$ 12,00' in t and pr == 12, (t, pr))
    check('a frase com "R$" não virou lançamento financeiro', '⟦fin' not in t and val("select count(*) from items where type in ('expense','income')") in (0, None), t)
    # 2) ação de impacto: botões Confirmar / Cancelar; nada muda antes do toque
    t = enviar('Pause meu catálogo xqz-emp {"acao":"pausar_pedidos"}')
    modo = lambda: json.loads(val('select data from businesses where id=?', ID)).get('horarioCfg', {}).get('modo')
    check('pedir para pausar a loja mostra a pergunta e os botões Confirmar/Cancelar', 'Confirma?' in t and pg.locator('[data-conf] [data-conf-sim]').count() == 1 and pg.locator('[data-conf] [data-conf-nao]').count() == 1 and modo() == 'aberto', (t, modo()))
    pg.screenshot(path='/tmp/e2e/admchat_confirmar.png')
    n0 = len(bolhas()); pg.locator('[data-conf] [data-conf-sim]').last.click()
    pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_timeout(900)
    t = bolhas()[-1]
    check('tocar em Confirmar executa e confirma: loja pausada', 'Pronto!' in t and 'pausado' in t and modo() == 'fechado', (t, modo()))
    t = enviar('Ative novamente os pedidos xqz-emp {"acao":"reativar_pedidos"}')
    check('reativar os pedidos pelo chat', 'Pronto!' in t and modo() == 'aberto', (t, modo()))
    # 3) Cancelar: nada muda
    enviar('Pausa a loja xqz-emp {"acao":"pausar_pedidos"}')
    n0 = len(bolhas()); pg.locator('[data-conf] [data-conf-nao]').last.click()
    pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_timeout(900)
    check('tocar em Cancelar não altera nada', 'não alterei nada' in bolhas()[-1] and modo() == 'aberto', (bolhas()[-1], modo()))
    # 4) botão antigo (de uma pergunta que já passou) não executa
    usados = pg.evaluate("[...document.querySelectorAll('[data-conf] button')].every(b=>b.disabled)")
    n0 = len(bolhas()); pg.evaluate("(()=>{const b=document.querySelector('[data-conf] [data-conf-sim]');b.disabled=false;b.click()})()"); pg.wait_for_timeout(1800)
    check('botões já usados ficam desativados e um antigo (forçado) não executa', usados and modo() == 'aberto' and len(bolhas()) == n0, (usados, modo(), len(bolhas()) - n0))
    pg.screenshot(path='/tmp/e2e/admchat_fim.png')
    check('sem rolagem lateral e sem erros de JavaScript', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
