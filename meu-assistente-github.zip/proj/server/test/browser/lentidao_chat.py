# Experiência durante a lentidão (25/11): o indicador troca a etapa genérica por um aviso amigável quando a resposta passa do
# esperado (12 s: curto; 25 s: completo) e a resposta chega normalmente; sem resposta dentro do prazo do chat, a mensagem
# final é "Não consegui concluir sua resposta agora…" — sem provedor, tempo limite, falha técnica ou "nada foi salvo".
# Servidor: PORT=4365 SQLITE_FILE=/tmp/ma-lento.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4365'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
CURTO = 'Estou trabalhando nisso. Sua resposta pode demorar um pouco mais.'
LONGO = 'O chat está um pouco mais lento que o normal. Estou trabalhando na sua resposta. Aguarde um instante.'
TEC = ['provedor', 'tempo limite', 'timeout', 'Nada foi salvo', 'A IA não conseguiu']
with sync_playwright() as p:
    b = p.chromium.launch(); c = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = c.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Lento Teste', 'whatsapp': '+55 11 94444-8181', 'email': 'lento@t.com', **U}).ok
    pg = c.new_page(); pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(900)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click()
    ind = lambda: pg.evaluate("()=>{const e=[...document.querySelectorAll('.ma-ind-t')].pop();return e?e.textContent:''}")
    ta = pg.locator('textarea[data-composer-input]'); ta.fill('me responde isso devagar xqz-lento-28'); ta.press('Enter')
    pg.wait_for_timeout(5000); t5 = ind()
    pg.wait_for_timeout(9000); t14 = ind()
    pg.wait_for_timeout(13000); t27 = ind()
    check('no começo: etapa real (não o aviso de lentidão)', t5 and t5 not in (CURTO, LONGO), t5)
    check('passou de 12 s: aviso curto e amigável', t14 == CURTO, t14)
    check('passou de 25 s: aviso completo', t27 == LONGO, t27)
    pg.screenshot(path='/tmp/e2e/lentidao_aviso.png')
    pg.wait_for_function("()=>/demorou um pouco mais/.test(document.querySelector('.chat-scroll').innerText)", timeout=20000); pg.wait_for_timeout(800)
    check('a resposta lenta chega normalmente e o aviso some', 'demorou um pouco mais' in pg.inner_text('.chat-scroll') and not ind())
    ta.fill('outra pergunta bem demorada xqz-lento-60'); ta.press('Enter')
    pg.wait_for_function("()=>/Não consegui concluir sua resposta agora/.test(document.querySelector('.chat-scroll').innerText)", timeout=60000); pg.wait_for_timeout(500)
    txt = pg.inner_text('.chat-scroll')
    ult = txt[txt.rfind('Não consegui concluir'):]
    check('tempo esgotado: mensagem amigável, sem termos técnicos', 'Tente novamente daqui a alguns minutos' in ult and not any(x.lower() in ult.lower() for x in TEC), ult[:300])
    pg.screenshot(path='/tmp/e2e/lentidao_falha.png')
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações')
