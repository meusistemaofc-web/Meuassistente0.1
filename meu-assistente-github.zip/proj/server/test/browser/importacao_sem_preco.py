# Importar catálogo por TEXTO COLADO sem preço (o exemplo da pizzaria: nome numa linha, descrição na linha de baixo) pela tela
# Sua empresa → Produtos → Importar: 3 produtos separados com as descrições originais, sem categoria inventada (nada de
# "Sobremesas"), preço pendente destacado (nunca R$ 0,00), categoria vazia neutra (opcional), sugestão de categoria já usada
# pela loja, bloqueio de cadastro sem preço, "Confirmar todos com preço" e cadastro só depois de informar o preço.
# Celular (390 px) e computador. Servidor: PORT=4397 SQLITE_FILE=/tmp/ma-imsp.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import sqlite3, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4397'; DBF = '/tmp/ma-imsp.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
EXEMPLO = 'Mussarela\nMolho, mussarela, tomate e azeitonas.\n\n2 Queijos\nMolho, mussarela, requeijão e azeitonas.\n\n3 Queijos\nMolho, mussarela, requeijão, cheddar e azeitonas.'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Principal', 'whatsapp': '+55 11 90000-0001', 'email': 'admin.imsp@t.com', **U}, headers={'X-Forwarded-For': '10.7.0.1'}).ok
    A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    for k, (nome, vp, mob) in enumerate([('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]):
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': f'Paulo Pizza {k}', 'whatsapp': f'+55 85 97777-10{k}{k}', 'email': f'paulo{k}.imsp@t.com', **U}, headers={'X-Forwarded-For': f'10.7.1.{k}'}).ok
        ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Pizzaria do Paulo {k}', 'categoria': 'Pizzaria', 'titulo': 't', 'texto': 'x', 'zap': '5585977770000', 'tipo': 'produtos', 'endereco': 'Rua B, 20'}).json()['items'][0]['id']
        # a loja já tem a categoria "Pizzas" (vira SUGESTÃO para os itens parecidos — nunca aplicada sozinha)
        db("INSERT INTO products (business_id, data, active) VALUES (?, ?, 1)", (ID, json.dumps({'nome': 'Calabresa', 'preco': 45, 'categoria': 'Pizzas', 'descricao': 'Molho, mussarela, calabresa e cebola.', 'variacoes': [], 'fotos': []})))
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
        pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('[data-mim=ia]', timeout=10000)
        pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_colar', timeout=8000)
        pg.click('#mi_colar'); pg.fill('#mi_txt', EXEMPLO); pg.wait_for_timeout(200)
        check(f'{nome}: instrução do campo aceita lista sem preço', 'o preço é opcional' in pg.inner_text('#mi_txtbox'))
        pg.click('#mi_go'); pg.wait_for_selector('#mi_pub', timeout=30000); pg.wait_for_timeout(500)
        itens = pg.locator('.mi-item'); nomes = [itens.nth(i).locator('[data-f=nome]').input_value() for i in range(itens.count())]
        descs = [itens.nth(i).locator('[data-f=desc]').input_value() for i in range(itens.count())]
        check(f'{nome}: 3 produtos separados (Mussarela, 2 Queijos, 3 Queijos)', nomes == ['Mussarela', '2 Queijos', '3 Queijos'], nomes)
        check(f'{nome}: descrições originais, cada uma no seu produto', descs == ['Molho, mussarela, tomate e azeitonas.', 'Molho, mussarela, requeijão e azeitonas.', 'Molho, mussarela, requeijão, cheddar e azeitonas.'], descs)
        txt = pg.inner_text('#mi_body') if pg.locator('#mi_body').count() else pg.inner_text('body')
        precos = [itens.nth(i).locator('[data-f=preco]').input_value() for i in range(3)]
        check(f'{nome}: nenhum "Sobremesas" e nenhum R$ 0,00', 'Sobremesa' not in txt and all(x == '' for x in precos) and '0,00' not in ''.join(precos), [precos, txt[:200]])
        check(f'{nome}: preço pendente destacado em cada item ("Preço precisa ser informado")', pg.locator('.mi-pend[data-f=preco]').count() == 3 and pg.locator('[data-mi-pend]').count() == 3)
        cat = itens.nth(0).locator('[data-f=categoria]')
        check(f'{nome}: categoria vazia é neutra (placeholder "opcional", sem destaque de erro)', cat.input_value() == '' and 'opcional' in (cat.get_attribute('placeholder') or '') and 'mi-pend' not in (cat.get_attribute('class') or '') and pg.locator('.mi-pend[data-f=categoria]').count() == 0)
        check(f'{nome}: sem a caixa "Conferi este item" quando só falta o preço', pg.locator('[data-f=confirmado]').count() == 0)
        check(f'{nome}: contagem "3 sem preço" no topo e grupo "Sem categoria"', '3 sem preço' in txt and 'SEM CATEGORIA' in txt.upper())
        check(f'{nome}: sugestão de categoria já usada pela loja ("Pizzas"), não aplicada', pg.locator('[data-mi-sug]').count() >= 1 and 'Pizzas' in pg.locator('[data-mi-sug]').first.inner_text() and cat.input_value() == '')
        if k == 0: pg.locator('.mi-item').first.screenshot(path='/tmp/e2e/importacao_sem_preco_item.png')
        # seleciona tudo e tenta cadastrar sem preço: bloqueado com mensagem e foco no campo
        for i in range(3): itens.nth(i).locator('[data-f=selecionado]').check()
        pg.click('#mi_pub'); pg.wait_for_timeout(300)
        check(f'{nome}: cadastrar sem preço é barrado com mensagem clara', 'sem preço' in pg.inner_text('#mi_err') and not db('SELECT 1 FROM products WHERE business_id = ? AND data LIKE ?', (ID, '%Queijos%')))
        # usar a sugestão de categoria num item; informar os preços; "Confirmar todos com preço"
        pg.locator('[data-usar-cat]').first.click(); pg.wait_for_timeout(300); itens = pg.locator('.mi-item')
        for i, v in enumerate(['45,00', '49,90', '52,00']):
            f = pg.locator('.mi-item').nth(i).locator('[data-f=preco]'); f.fill(v); f.dispatch_event('change')
        pg.wait_for_timeout(300)
        check(f'{nome}: ao informar o preço o destaque some', pg.locator('.mi-pend[data-f=preco]').count() == 0, pg.locator('.mi-pend[data-f=preco]').count())
        pg.wait_for_timeout(1200); pg.click('#mi_cfa'); pg.wait_for_timeout(1200)
        check(f'{nome}: "Confirmar todos com preço" deixa os 3 prontos', 'Confirmar e cadastrar (3)' in pg.inner_text('#mi_pub'), pg.inner_text('#mi_pub'))
        pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver', timeout=20000)
        prods = [json.loads(r[0]) for r in db('SELECT data FROM products WHERE business_id = ? ORDER BY id', (ID,))]
        nv = {x['nome']: x for x in prods if x['nome'] != 'Calabresa'}
        check(f'{nome}: 3 produtos cadastrados com preço, descrição original e categoria só onde escolhida', sorted(nv) == ['2 Queijos', '3 Queijos', 'Mussarela'] and nv['Mussarela']['preco'] == 45 and nv['2 Queijos']['preco'] == 49.9 and nv['3 Queijos']['descricao'] == 'Molho, mussarela, requeijão, cheddar e azeitonas.' and all(x['preco'] > 0 for x in nv.values()) and not any((x.get('categoria') or '') == 'Sobremesas' for x in nv.values()), json.dumps(nv, ensure_ascii=False)[:400])
        check(f'{nome}: produto que já existia continua igual', any(x['nome'] == 'Calabresa' and x['preco'] == 45 for x in prods))
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
