# Recebimento de pedidos (painel OU WhatsApp), de ponta a ponta no navegador:
#   - a loja escolhe UMA forma em Entrega e pagamento (opções exclusivas, salva ao tocar, persiste ao recarregar);
#   - sem envio automático: o cliente conclui o pedido no catálogo e é levado ao WhatsApp CADASTRADO da loja com a mensagem
#     pronta (produtos, quantidades, valores e total); o pedido fica registrado;
#   - admin configura o provedor (Evolution API) e um pedido real chega sozinho ao WhatsApp da empresa, sem aviso no painel;
#   - chave global do admin: desligada, a opção some da tela da empresa e o servidor bloqueia; religada, volta a escolha.
# Celular e computador.
# Servidor: PORT=4353 SQLITE_FILE=/tmp/ma-receb.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, json, threading, re
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
import _admin
BASE='http://localhost:4353'; DBF='/tmp/ma-receb.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
MSGS=[]
class Evo(BaseHTTPRequestHandler):
    def do_POST(self):
        b=json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
        if self.headers.get('apikey')!='evo-chave-teste' or '/message/sendText/loja1' not in self.path: self.send_response(401); self.end_headers(); self.wfile.write(b'{}'); return
        MSGS.append(b); self.send_response(201); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps({'key':{'id':'E%d'%len(MSGS)}}).encode())
    def log_message(self,*a): pass
srv=HTTPServer(('127.0.0.1',4399),Evo); threading.Thread(target=srv.serve_forever,daemon=True).start()
PNG='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE,viewport={'width':1280,'height':900}); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Dona Pizzaria','whatsapp':'+55 11 93330-1111','email':'dono@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    r=O.post('/api/v2/ads',data={'planId':'n4','empresa':'Pizzaria Bella','categoria':'Pizzaria','titulo':'Pizzaria Bella','texto':'Forno a lenha','zap':'11 98765-4321','lat':-23.552,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); db.commit(); db.close()
    assert O.put(f'/api/v2/ads/{BID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'dinheiro':True},'entrega':{'retirada':True}}).ok
    r=O.post(f'/api/v2/ads/{BID}/products',data={'nome':'Pizza Margherita','preco':52.9,'categoria':'Pizzas','fotos':[PNG]}); PID=[x for x in r.json()['items'] if x['nome']=='Pizza Margherita'][0]['id']
    c0=b.new_context(base_url=BASE); C=c0.request
    assert C.post('/api/auth',data={'action':'signup','name':'Carlos Cliente','whatsapp':'+55 21 98888-7777','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    sess=o.cookies()
    def entrega(pg, espera=True):
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]',timeout=20000); pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector('[data-lt2=entrega]'); pg.click('[data-lt2=entrega]')
        if espera: pg.wait_for_selector('[data-rcb-box] [data-rcb="rcb-painel"]',timeout=15000); pg.wait_for_timeout(300)
        else: pg.wait_for_timeout(2500)
    op=lambda pg,k: pg.locator(f'[data-rcb="rcb-{k}"]')
    est=lambda pg: {k:op(pg,k).get_attribute('aria-checked') for k in ('painel','whatsapp')}
    print('== loja escolhe a forma (sem envio automático configurado)')
    pg=o.new_page(); pg.set_viewport_size({'width':390,'height':844}); pg.on('pageerror',lambda e:errs.append(str(e))); entrega(pg)
    check('a seção "Onde receber os novos pedidos" aparece com as duas formas como opções exclusivas (radio)', pg.locator('[data-rcb-tit]').count()==1 and pg.locator('[data-rcb-grupo][role=radiogroup] [role=radio]').count()==2)
    check('padrão: painel escolhido', est(pg)=={'painel':'true','whatsapp':'false'}, est(pg))
    check('WhatsApp disponível com o número cadastrado e explica que o cliente é levado ao WhatsApp', not op(pg,'whatsapp').is_disabled() and '+55 11 98765-4321' in pg.locator('[data-rcb-num]').inner_text() and 'cliente é levado' in pg.locator('[data-rcb-box]').inner_text())
    op(pg,'whatsapp').click(); pg.wait_for_function("()=>/Salvo/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
    check('escolher WhatsApp desmarca o painel (uma forma só) e salva na hora', est(pg)=={'painel':'false','whatsapp':'true'} and 'WhatsApp' in pg.locator('#rcbm').inner_text(), (est(pg),pg.locator('#rcbm').inner_text()))
    pg.reload(); entrega(pg); check('escolha persiste ao recarregar', est(pg)=={'painel':'false','whatsapp':'true'}, est(pg))
    pg.screenshot(path='/tmp/e2e/receb_whats_loja_celular.png'); pg.close()
    print('== cliente faz o pedido no catálogo e é levado ao WhatsApp da loja')
    cc=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True); cc.add_cookies(c0.cookies()); cp=cc.new_page(); cp.on('pageerror',lambda e:errs.append(str(e)))
    cp.goto(f'/x/empresa/{BID}'); cp.wait_for_selector('[data-add]',timeout=20000); cp.wait_for_timeout(1500)
    cp.locator('[data-add]').first.click(); cp.wait_for_timeout(1200); cp.locator('[data-add]').first.click(); cp.wait_for_timeout(1200)
    cp.get_by_text('Ver pedido').click(); cp.wait_for_selector('#cgo',timeout=10000); cp.wait_for_timeout(600)
    check('cliente: botão "Enviar pedido pelo WhatsApp"', 'Enviar pedido pelo WhatsApp' in cp.locator('#cgo').inner_text(), cp.locator('#cgo').inner_text())
    if cp.locator('#czap').count(): cp.locator('#czap').fill('(21) 98888-7777')
    cp.click('#cgo'); cp.wait_for_selector('[data-wa-pedido] [data-wa-enviar]',timeout=15000); cp.wait_for_timeout(400)
    href=cp.get_attribute('[data-wa-enviar]','href') or ''; import urllib.parse as up; txt=up.unquote(href.split('?text=')[1] if '?text=' in href else '')
    OIDc=int(cp.get_attribute('[data-wa-pedido]','data-wa-pedido'))
    check('cliente: link para o WhatsApp CADASTRADO da loja (wa.me/5511987654321)', href.startswith('https://wa.me/5511987654321?text='), href[:80])
    check('cliente: mensagem pronta com produto, quantidade, valores e total', '2 × Pizza Margherita' in txt and 'R$ 52,90 cada = R$ 105,80' in txt and '*Total: R$ 105,80*' in txt and f'#{OIDc}' in txt, txt[:300])
    stt=[x['status'] for x in O.get(f'/api/v2/ads/{BID}/orders').json()['items'] if x['id']==OIDc]
    check('o pedido fica registrado em Pedidos ("novo")', stt==['novo'], stt)
    cp.screenshot(path='/tmp/e2e/receb_whats_cliente_celular.png'); cc.close()
    print('== administrador configura o envio automático (aba WhatsApp)')
    ap=a.new_page(); ap.on('pageerror',lambda e:errs.append(str(e))); ap.goto('/admin'); _admin.aba(ap,'whatsapp'); ap.wait_for_selector('[data-wa-adm]',timeout=15000)
    check('admin: chave "Pedidos pelo WhatsApp para as empresas" ligada, com 1 empresa usando', ap.get_attribute('[data-sw="pedidos_whatsapp"]','aria-checked')=='true' and '1 empresa' in ap.locator('[data-pw-n]').inner_text(), ap.locator('[data-pw-cfg]').inner_text()[:200])
    check('admin: provedor ainda não configurado', 'Não configurado' in ap.locator('[data-wa-st]').inner_text())
    ap.select_option('#wa_p','evolution'); ap.fill('#wa_eu','http://127.0.0.1:4399'); ap.fill('#wa_ei','loja1'); ap.fill('#wa_ek','evo-chave-teste'); ap.fill('#wa_tn','11 91234-5678'); ap.click('#wa_t')
    ap.wait_for_function("()=>/enviada|Não foi/.test(document.querySelector('#wa_m').textContent)",timeout=15000)
    check('admin: "Salvar e enviar teste" envia de verdade ao provedor', 'enviada' in ap.locator('#wa_m').inner_text() and MSGS and MSGS[-1]['number']=='5511912345678', (ap.locator('#wa_m').inner_text(),MSGS[-1:]))
    check('admin: status "Configurado" e a chave não fica no campo', 'Configurado' in ap.locator('[data-wa-st]').inner_text() and ap.locator('#wa_ek').input_value()=='')
    for nome,vp in [('celular',{'width':390,'height':844}),('computador',{'width':1280,'height':900})]:
        print('== loja,',nome)
        c=b.new_context(base_url=BASE,viewport=vp,has_touch=nome=='celular',is_mobile=nome=='celular'); c.add_cookies(sess); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); entrega(pg)
        if nome=='celular':
            check('com envio automático: descrição muda e aparece "Enviar mensagem de teste"', 'automaticamente' in pg.locator('[data-rcb-box]').inner_text() and pg.locator('[data-rcb-teste]').count()==1)
            n0=len(MSGS); pg.click('[data-rcb-teste]'); pg.wait_for_function("()=>/enviada|Não foi/.test(document.querySelector('#rcbm').textContent)",timeout=10000)
            check('"Enviar mensagem de teste" chega no WhatsApp da empresa', len(MSGS)==n0+1 and MSGS[-1]['number']=='5511987654321', pg.locator('#rcbm').inner_text())
            n0=len(MSGS); r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID,'qtd':2}],'modo':'retirada','pagamento':'dinheiro','telefone':'21988887777','nome':'Carlos Cliente','idem':'b1'}); OID=r.json()['order']['id']
            pg.wait_for_timeout(900); txt=MSGS[-1]['text'] if len(MSGS)>n0 else ''
            check('pedido real chega sozinho no WhatsApp da empresa com itens, valores, cliente e retirada (sem link para o cliente)', len(MSGS)==n0+1 and MSGS[-1]['number']=='5511987654321' and f'#{OID}*' in txt and '2 × Pizza Margherita' in txt and 'R$ 105,80' in txt and 'Carlos Cliente' in txt and 'Retirada no local' in txt and 'whatsapp' not in r.json(), txt[:200])
            nt=O.get('/api/notifications').json(); tem=any(f'#{OID}' in (i.get('title') or '') for i in nt.get('items',[]))
            check('forma WhatsApp: nenhuma notificação do pedido no painel', not tem)
            pg.reload(); entrega(pg)
            check('"Últimos envios" mostra o pedido como enviado', f'Pedido #{OID}' in pg.locator('[data-rcb-envios]').inner_text() and 'Enviado' in pg.locator('[data-rcb-envios]').inner_text())
        ov=pg.evaluate("()=>document.documentElement.scrollWidth-innerWidth"); check(f'{nome}: sem rolagem lateral', ov<=1, ov)
        pg.locator('[data-rcb-box]').scroll_into_view_if_needed(); pg.wait_for_timeout(200); pg.locator('[data-rcb-box]').screenshot(path=f'/tmp/e2e/receb_{nome}.png')
        if nome=='computador':
            op(pg,'painel').click(); pg.wait_for_function("()=>/Salvo: você recebe os pedidos no painel/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
            check('computador: voltar para o painel (WhatsApp desmarcado)', est(pg)=={'painel':'true','whatsapp':'false'})
            n0=len(MSGS); r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID,'qtd':1}],'modo':'retirada','pagamento':'dinheiro','telefone':'21988887777','nome':'Carlos Cliente','idem':'b2'}); OID2=r.json()['order']['id']; pg.wait_for_timeout(800)
            nt=O.get('/api/notifications').json()
            check('forma painel: notificação no painel e nenhuma mensagem no WhatsApp (fluxo de sempre)', len(MSGS)==n0 and sum(1 for i in nt.get('items',[]) if f'#{OID2}' in (i.get('title') or ''))==1)
            op(pg,'whatsapp').click(); pg.wait_for_function("()=>/Salvo/.test(document.querySelector('#rcbm').textContent)",timeout=8000)
        c.close()
    print('== chave global do administrador')
    ap.click('[data-sw="pedidos_whatsapp"]'); ap.wait_for_function("()=>document.querySelector('[data-sw=\"pedidos_whatsapp\"]').getAttribute('aria-checked')==='false'",timeout=8000)
    ap.wait_for_function("()=>/Indisponível/.test((document.querySelector('[data-pw-st]')||{}).textContent||'')",timeout=8000)
    check('admin: desligar mostra "Indisponível" e grava', 'Indisponível' in ap.locator('[data-pw-st]').inner_text() and A.get('/api/panel').json()['pedidos_whatsapp']['ativo'] is False)
    ap.screenshot(path='/tmp/e2e/receb_whats_admin.png')
    c=b.new_context(base_url=BASE,viewport={'width':390,'height':844},has_touch=True,is_mobile=True); c.add_cookies(sess); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); entrega(pg,False)
    check('desligada: a opção some por completo das configurações da empresa', pg.locator('[data-rcb-box]').count()==0 and pg.locator('[data-rcb-tit]').count()==0 and 'Onde receber os novos pedidos' not in pg.inner_text('body'))
    check('desligada: o servidor bloqueia configurar', O.put(f'/api/v2/ads/{BID}/recebimento',data={'modo':'whatsapp'}).status==403)
    n0=len(MSGS); r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID,'qtd':1}],'modo':'retirada','pagamento':'dinheiro','telefone':'21988887777','nome':'Carlos Cliente','idem':'b3'}); OID3=r.json()['order']['id']; pg.wait_for_timeout(800)
    nt=O.get('/api/notifications').json()
    check('desligada: o pedido vai para o painel, sem WhatsApp', len(MSGS)==n0 and 'whatsapp' not in r.json() and sum(1 for i in nt.get('items',[]) if f'#{OID3}' in (i.get('title') or ''))==1)
    ap.click('[data-sw="pedidos_whatsapp"]'); ap.wait_for_function("()=>document.querySelector('[data-sw=\"pedidos_whatsapp\"]').getAttribute('aria-checked')==='true'",timeout=8000)
    entrega(pg); check('religada: a opção volta com a escolha guardada (WhatsApp)', est(pg)=={'painel':'false','whatsapp':'true'}, est(pg))
    c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
srv.shutdown()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
