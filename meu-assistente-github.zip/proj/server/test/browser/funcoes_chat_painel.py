# Administração → Motor do chat → Funcionalidades do chat, pela tela real:
#   - "Pesquisa na internet": desligar grava, mostra "Desativada" e vale na hora — o chat aberto (sem recarregar) responde ao
#     pedido de pesquisa sem consultar a internet e avisa; religar volta ao normal.
#   - "Modos do botão ⚡" um a um: desligar Busca e Treino tira os dois do ⚡ do usuário sem recarregar a página; os outros
#     continuam; a linha desligada fica esmaecida, com "Visível" indisponível e o contador "x de y ativos"; requisição direta
#     não ativa um modo desligado; todos desligados → o ⚡ some sozinho; religar → volta sozinho.
#   - Celular (escuro) e computador (claro), sem rolagem lateral, sem erros de JavaScript.
# Servidor: PORT=4406 SQLITE_FILE=/tmp/ma-funcchat.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, time
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4406'; DBF = '/tmp/ma-funcchat.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
MENU = '[role=dialog][aria-label="Modos inteligentes"]'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900}); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Funções', 'whatsapp': '+55 11 94444-0601', 'email': 'admin.func@t.com', **U}).ok
    A.request.patch('/api/me', data={'settings': {'theme': 'light'}})
    st_admin = A.storage_state()
    # usuário com o chat aberto no celular (tema escuro) — a página NÃO é recarregada durante o teste
    Uc = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
    assert Uc.request.post('/api/auth', data={'action': 'signup', 'name': 'Usuária Chat', 'whatsapp': '+55 11 94444-0602', 'email': 'usuaria.func@t.com', **U}).ok
    up = Uc.new_page(); up.on('pageerror', lambda e: errs.append('usuário: ' + str(e)))
    up.goto('/'); up.wait_for_selector('textarea.composer-input', timeout=20000); up.wait_for_timeout(3500)
    if up.locator('button:has-text("Agora não")').count(): up.locator('button:has-text("Agora não")').first.click()
    def menu_ids():
        up.locator('.ma-modos-btn').click()
        try: up.wait_for_selector(MENU + ' [data-modo]', timeout=8000)
        except Exception: up.screenshot(path='/tmp/e2e/dbg_fc2.png'); raise
        up.wait_for_timeout(500)
        ids = up.eval_on_selector_all(MENU + ' [data-modo]', 'es=>es.map(e=>e.dataset.modo).filter(Boolean)'); up.keyboard.press('Escape'); up.wait_for_timeout(200); return ids
    up.wait_for_selector('.ma-modos-btn', timeout=15000); ids0 = menu_ids()
    check('usuário: ⚡ com os modos disponíveis', len(ids0) >= 2 and 'busca' in ids0 and 'treino' in ids0, ids0)
    def envia(txt):
        n = up.locator('.chat-scroll .msg-bubble').count(); up.locator('textarea.composer-input').fill(txt); up.wait_for_timeout(150); up.locator('[aria-label="Enviar"]').click()
        for _ in range(80):
            if up.locator('.chat-scroll .msg-bubble').count() >= n + 2: break
            up.wait_for_timeout(250)
        up.wait_for_timeout(800); return up.locator('.chat-scroll').inner_text()[-700:]
    # ---------- administrador ----------
    pa = A.new_page(); pa.on('pageerror', lambda e: errs.append('admin: ' + str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(2500)
    if pa.locator('[data-pi-cfg]').count() == 0: aba(pa, 'motor')
    pa.wait_for_selector('[data-pi-cfg] [data-sw="pesquisa_internet"]', timeout=20000); pa.wait_for_timeout(500)
    ordem = pa.evaluate("()=>[...document.querySelectorAll('[data-pi-cfg],[data-modos-cfg],[data-modos-lista]')].map(e=>e.hasAttribute('data-pi-cfg')?'pi':e.hasAttribute('data-modos-cfg')?'geral':'lista')")
    check('painel: "Funcionalidades do chat" com Pesquisa na internet, chave dos modos e lista, nessa ordem', ordem == ['pi', 'geral', 'lista'] and 'Funcionalidades do chat' in pa.inner_text('body'), ordem)
    check('painel: pesquisa na internet ligada por padrão', pa.get_attribute('[data-sw="pesquisa_internet"]', 'aria-checked') == 'true' and 'Ativa' in pa.inner_text('[data-pi-status]'))
    pa.click('[data-sw="pesquisa_internet"]'); pa.wait_for_function("document.querySelector('[data-sw=\"pesquisa_internet\"]').getAttribute('aria-checked')==='false'&&document.querySelector('[data-pi-status]').innerText.includes('Desativada')", timeout=8000)
    check('desligar: grava (API e banco) e mostra "Desativada" com a explicação', A.request.get('/api/panel/public').json().get('pesquisa_internet') is False and json.loads(db("select value from app_config where key='pesquisa_internet'")[0][0])['ativo'] is False and 'nenhuma busca na internet' in pa.inner_text('[data-pi-desc]'))
    pa.screenshot(path='/tmp/e2e/funcoes_chat_painel_computador.png', full_page=False)
    resp = envia('pesquise na internet a história do carro Jaguar')
    try: up.wait_for_function("document.querySelector('.chat-scroll').innerText.includes('Sobre a história do carro Jaguar')", timeout=10000); resp = up.locator('.chat-scroll').inner_text()[-700:]
    except Exception: pass  # a resposta chega em fluxo; a versão final substitui a parcial
    check('chat aberto (sem recarregar): responde à pergunta normalmente, sem falar de bloqueio nem saudação genérica', 'Sobre a história do carro Jaguar' in resp and not any(x in resp.lower() for x in ['desativad', 'administrador', 'bloque', 'como posso ajudar']), resp[-300:])
    tr = [json.loads(r[0]) for r in db('select detail from brain_chat_traces order by id desc limit 5')]
    pr = next((t.get('prioridade') for t in tr if t.get('prioridade') and 'Jaguar' not in '' ), None)
    check('nenhuma busca feita no turno (rastro)', pr and pr.get('pesquisaBloqueada') and not pr.get('buscasWeb') and not pr.get('grounding'), pr)
    pa.click('[data-sw="pesquisa_internet"]'); pa.wait_for_function("document.querySelector('[data-sw=\"pesquisa_internet\"]').getAttribute('aria-checked')==='true'", timeout=8000)
    check('religar: volta a "Ativa"', A.request.get('/api/panel/public').json().get('pesquisa_internet') is True and 'Ativa' in pa.inner_text('[data-pi-status]'))
    # ---------- modos um a um ----------
    # a usuária (sem empresa) vê Busca e Treino; Marketing e Gestão são só para empresas. Desliga a Busca e a Gestão:
    for m in ['busca', 'gestao_empresa']:
        pa.click(f'[data-sw="ma_{m}"]'); pa.wait_for_function(f"document.querySelector('[data-modo-id=\"{m}\"]')?.dataset.modoAtivo==='false'", timeout=8000)
    cont = pa.inner_text('[data-modos-cont]'); total = pa.locator('[data-modo-id]').count()
    linha = pa.evaluate("()=>{const r=document.querySelector('[data-modo-id=\"busca\"]');return {op:getComputedStyle(r).opacity,vis:r.querySelector('[data-sw=\"mv_busca\"]').closest('[aria-disabled]')?.getAttribute('aria-disabled'),txt:r.innerText}}")
    check('painel: linhas desligadas esmaecidas, "Visível" indisponível e contador atualizado', float(linha['op']) < 1 and linha['vis'] == 'true' and 'Desativado' in linha['txt'] and cont == f'{total - 2} de {total} ativos', (linha, cont))
    ids1 = menu_ids()
    check('usuário (sem recarregar): a Busca some do ⚡ e o Treino continua', 'busca' not in ids1 and set(ids1) == set(ids0) - {'busca'} and 'treino' in ids1, (ids0, ids1))
    pa.locator('[data-modo-id="busca"]').scroll_into_view_if_needed(); pa.screenshot(path='/tmp/e2e/funcoes_chat_modos_computador.png')
    r = Uc.request.post('/api/chat', data={'text': 'quero encontrar uma bicicleta', 'conversationId': '7d7d7d7d-1111-4222-8333-444455556666', 'modo': 'busca'})
    check('requisição direta não ativa o modo desligado', r.ok and Uc.request.get('/api/v2/modos?c=7d7d7d7d-1111-4222-8333-444455556666').json()['ativo'] != 'busca')
    # todos desligados: o ⚡ some sozinho
    todos = pa.eval_on_selector_all('[data-modo-id]', 'es=>es.filter(e=>e.dataset.modoAtivo==="true").map(e=>e.dataset.modoId)')
    for m in todos:
        pa.click(f'[data-sw="ma_{m}"]'); pa.wait_for_function(f"document.querySelector('[data-modo-id=\"{m}\"]')?.dataset.modoAtivo==='false'", timeout=8000)
    t0 = time.time()
    try: up.wait_for_function("document.querySelectorAll('.ma-modos-btn').length===0", timeout=20000); sumiu = True
    except Exception: sumiu = False
    check(f'todos desligados: o ⚡ some do chat aberto sozinho ({time.time() - t0:.0f} s)', sumiu)
    up.screenshot(path='/tmp/e2e/funcoes_chat_sem_modos_celular.png')
    for m in pa.eval_on_selector_all('[data-modo-id]', 'es=>es.filter(e=>e.dataset.modoAtivo==="false").map(e=>e.dataset.modoId)'):
        pa.click(f'[data-sw="ma_{m}"]'); pa.wait_for_function(f"document.querySelector('[data-modo-id=\"{m}\"]')?.dataset.modoAtivo==='true'", timeout=8000)
    try: up.wait_for_selector('.ma-modos-btn', timeout=20000); voltou = True
    except Exception: voltou = False
    check('religar: o ⚡ volta sozinho com todos os modos', voltou and set(menu_ids()) == set(ids0))
    ow = up.evaluate('document.documentElement.scrollWidth-innerWidth'); check('chat sem rolagem lateral', ow <= 1, ow)
    # painel no celular (tema escuro)
    M = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, storage_state=st_admin); M.request.patch('/api/me', data={'settings': {'theme': 'dark'}})
    pm = M.new_page(); pm.on('pageerror', lambda e: errs.append('admin celular: ' + str(e))); pm.goto('/admin'); pm.wait_for_timeout(2500)
    if pm.locator('[data-pi-cfg]').count() == 0: aba(pm, 'motor')
    pm.wait_for_selector('[data-pi-cfg]', timeout=20000); pm.wait_for_timeout(600); pm.locator('[data-pi-cfg]').scroll_into_view_if_needed()
    ow = pm.evaluate('document.documentElement.scrollWidth-innerWidth'); bb = pm.locator('[data-sw="pesquisa_internet"]').bounding_box()
    check('painel no celular: sem rolagem lateral e chave à vista', ow <= 1 and bb and bb['x'] + bb['width'] <= 390, (ow, bb))
    pm.screenshot(path='/tmp/e2e/funcoes_chat_painel_celular.png')
    E = [e for e in errs if '#418' not in e and not e.endswith(': Event')]  # 'Event' = folha de fontes do Google sem rede no ambiente de teste
    check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
