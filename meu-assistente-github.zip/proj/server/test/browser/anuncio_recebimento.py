# Anunciar com "Seus dados" do perfil (completo/incompleto, editável, opção discreta de atualizar o perfil), sem cupom na
# 1ª etapa (cupom na etapa de pagamento) e Sua empresa → Entrega e pagamento com Pix direto (tipo de chave, validação,
# status, chave preservada ao desativar) e Mercado Pago em blocos separados, com o resumo do que o cliente vê.
# Celular (390 px) e computador. Servidor: PORT=4394 SQLITE_FILE=/tmp/ma-anrc.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import sqlite3, json
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4394'; DBF = '/tmp/ma-anrc.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Principal', 'whatsapp': '+55 11 90000-0001', 'email': 'admin.anrc@t.com', **U}, headers={'X-Forwarded-For': '10.6.0.1'}).ok # a 1ª conta é a administradora (publica sem pagamento)
    for k, (nome, vp, mob) in enumerate([('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]):
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = C.request
        email = f'carla{k}.anrc@t.com'
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Carla Mendes', 'whatsapp': f'+55 85 98888-12{k}{k}', 'email': email, **U}, headers={'X-Forwarded-For': f'10.6.1.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        abrir = lambda: (pg.goto('/x/anunciar'), pg.wait_for_selector('#adf [data-resp]', timeout=20000), pg.wait_for_timeout(1800), pg.wait_for_selector('#adf [data-resp] [name=respEmail]', timeout=20000)) # o app pode recarregar uma vez ao iniciar
        abrir()
        v = pg.evaluate("()=>Object.fromEntries([...document.querySelectorAll('#adf [data-resp] input[name]')].map(i=>[i.name,i.value]))")
        check(f'{nome}: "Seus dados" preenchidos do perfil (nome, e-mail, telefone)', v.get('contato') == 'Carla Mendes' and v.get('respEmail') == email and v.get('respTel') == f'(85) 98888-12{k}{k}', v)
        check(f'{nome}: sem "Tenho um cupom" na primeira etapa', pg.locator('#adf [data-cup-abrir]').count() == 0 and 'Tenho um cupom' not in pg.inner_text('#adf'))
        check(f'{nome}: opção de atualizar o perfil escondida enquanto nada mudou', not pg.locator('[data-resp-perfil]').is_visible())
        pg.fill('[name=respTel]', '85977776666'); pg.wait_for_timeout(200)
        check(f'{nome}: telefone editável (formatado) e a opção discreta aparece desmarcada', pg.input_value('[name=respTel]') == '(85) 97777-6666' and pg.locator('[data-resp-perfil]').is_visible() and not pg.is_checked('[name=atualizarPerfil]'))
        if k == 0: pg.locator('[data-resp]').screenshot(path='/tmp/e2e/anunciar_seus_dados.png')
        pg.locator('label:has([name=planId][value=n1])').click(); pg.wait_for_timeout(200)
        pg.fill('[name=empresa]', f'Bolos da Carla {k}'); pg.fill('[name=titulo]', 'Bolos caseiros'); pg.fill('[name=texto]', 'Encomendas')
        cat = pg.locator('[name=categoria]')
        if cat.evaluate('e=>e.tagName') == 'SELECT': cat.select_option(index=1)
        else: cat.fill('Confeitaria')
        pg.click('#adf button[type=submit]'); pg.wait_for_url('**/x/sua-empresa**', timeout=15000); pg.wait_for_timeout(1500); pg.goto('/x/sua-empresa'); pg.wait_for_selector('[data-cupom-anuncio] [data-cup-abrir]', timeout=20000)
        check(f'{nome}: "Continuar para o pagamento" leva à etapa de pagamento com o cupom', pg.locator('[data-cupom-anuncio] [data-cup-abrir]').is_visible())
        me = json.dumps(R.get('/api/me').json(), ensure_ascii=False)
        check(f'{nome}: sem marcar a opção, o perfil não muda', '97777' not in me and 'Carla Mendes' in me, me[:200])
        ad = [x for x in R.get('/api/v2/ads/mine').json()['items'] if x['empresa'] == f'Bolos da Carla {k}'][0]
        check(f'{nome}: o anúncio guarda os dados editados', ad.get('responsavel', {}).get('telefone') == '5585977776666' and ad['responsavel']['email'] == email, ad.get('responsavel'))
        # perfil incompleto: só o que falta é destacado
        db("update users set whatsapp='' where email=?", (email,)); abrir()
        falta = pg.evaluate("()=>[...document.querySelectorAll('#adf [data-falta]')].map(i=>i.name)")
        check(f'{nome}: perfil incompleto → só o telefone é pedido', falta == ['respTel'] and 'Falta seu telefone' in pg.inner_text('#adf [data-resp]'), falta)
        # empresa (Loja completa) → Entrega e pagamento
        bid = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Loja Carla {k}', 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5585999990000', 'respEmail': email, 'respTel': '85977776666', 'contato': 'Carla Mendes'}).json()['items'][0]['id']
        bid = [x for x in R.get('/api/v2/ads/mine').json()['items'] if x['empresa'] == f'Loja Carla {k}'][0]['id']
        db("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (bid,))
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=mais]', timeout=15000)
        if pg.locator(f'[data-sel="{bid}"]').count(): pg.click(f'[data-sel="{bid}"]'); pg.wait_for_timeout(1200)
        pg.click('.ma-nav [data-nav=mais]'); pg.wait_for_selector('[data-lt2=entrega]'); pg.click('[data-lt2=entrega]'); pg.wait_for_selector('#pk', timeout=15000); pg.wait_for_timeout(800)
        resumo = lambda: pg.inner_text('[data-pg-resumo]')
        st = lambda w: pg.inner_text(f'[data-pg-st="{w}"]')
        check(f'{nome}: Pix direto e Mercado Pago em blocos separados, com status', pg.locator('[data-pg-st="pix"]').count() == 1 and pg.locator('[data-pg-st="mp"]').count() == 1 and st('mp') == 'Não conectado', (st('pix'), st('mp')))
        pg.click('[data-pkt=cpf_cnpj]'); pg.fill('#pk', '111.111.111-11'); pg.wait_for_timeout(150)
        check(f'{nome}: CPF inválido avisado antes de salvar', 'CPF inválido' in pg.inner_text('#pkm'), pg.inner_text('#pkm'))
        pg.fill('#pk', '529.982.247-25'); pg.wait_for_timeout(150)
        check(f'{nome}: chave válida reconhecida', 'Chave válida' in pg.inner_text('#pkm'))
        pg.locator('#ma-x button:visible', has_text='Salvar entrega e pagamento').click(); pg.wait_for_timeout(1500)
        pgd = json.loads(db('select data from businesses where id=?', (bid,))[0][0])['pagamento']
        check(f'{nome}: chave salva no padrão e vinculada à empresa', pgd.get('chavePix') == '52998224725' and pgd.get('tipoChave') == 'cpf_cnpj' and pgd.get('pix') is True, pgd)
        check(f'{nome}: status "Ativo" e resumo do que o cliente vê', st('pix') == 'Ativo' and 'Pix direto (chave 52998224725)' in resumo(), (st('pix'), resumo()))
        if k == 0: pg.screenshot(path='/tmp/e2e/recebimento_pix.png', full_page=True)
        # desativar o Pix direto NÃO apaga a chave
        pg.click('[data-sw="p-pix"]'); pg.wait_for_timeout(150)
        check(f'{nome}: desativar muda o status na hora', st('pix') == 'Desativado' and 'Pix direto' not in resumo(), (st('pix'), resumo()))
        pg.locator('#ma-x button:visible', has_text='Salvar entrega e pagamento').click(); pg.wait_for_timeout(1500)
        pgd = json.loads(db('select data from businesses where id=?', (bid,))[0][0])['pagamento']
        check(f'{nome}: Pix direto desativado com a chave preservada', pgd.get('pix') is False and pgd.get('chavePix') == '52998224725', pgd)
        # nenhuma forma ativa: aviso claro
        for sw in ['p-dinheiro', 'p-cartao', 'p-pixentrega']:
            if pg.get_attribute(f'[data-sw="{sw}"]', 'aria-checked') == 'true': pg.click(f'[data-sw="{sw}"]')
        pg.wait_for_timeout(150)
        check(f'{nome}: sem nenhuma forma ativa, o resumo avisa', 'Nenhuma forma de pagamento ativa' in resumo(), resumo())
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"\n{'FIM OK' if all(res) else 'FIM FALHOU'} {sum(res)}/{len(res)}")
