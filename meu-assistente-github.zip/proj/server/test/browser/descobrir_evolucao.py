# Descobrir (Empresas perto de você) — controle pelo painel, banners rotativos e personalização por usuário; e a busca global
# da Administração. Celular (iPhone) e computador, banco e rotas reais.
#   A. painel: opções Empresas/Produtos/Serviços ligadas/desligadas → somem da tela e o servidor recusa (404); página se
#      reorganiza (uma opção só = rótulo, sem abas); não deixa desligar tudo; usuário comum não altera (403)
#   B. banners: criação pelo painel (busca global "banners" → tela → imagem enviada), período (fora do período não aparece),
#      ordem, rotação automática pelo tempo de cada banner, indicadores, destino (produto/categoria), sem distorção
#   C. personalização: dois usuários com interesses diferentes veem ordens diferentes; um não muda o do outro; usuário novo
#      fica na ordem geral; "Recomendado para você" × "Destaques perto de você"; diversidade; coleta pela tela (em lote)
#   D. busca global do painel: sinônimos, termos informais, erro de digitação, teclado, resultado abre a tela certa,
#      permissões (admin sem "Ver usuários" não encontra Usuários), 7 seções em Plataforma e Negócio, última seção lembrada
# Servidor: PORT=4352 SQLITE_FILE=/tmp/ma-dscev.db npx tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime, base64
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4352'; DBF = '/tmp/ma-dscev.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor, w=400, h=300, fmt='JPEG'):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, fmt, quality=70); return 'data:image/' + fmt.lower() + ';base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
PERTO = (-3.7319, -38.5267); ip = [0]
def conta(b, nome, email, vp=None, mob=False):
    ip[0] += 1; C = b.new_context(base_url=BASE, **({'viewport': vp, 'is_mobile': mob, 'has_touch': mob} if vp else {}))
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': nome, 'whatsapp': f'+55 85 95555-{1000 + ip[0]}', 'email': email, **U}, headers={'X-Forwarded-For': f'10.20.0.{ip[0]}'}).ok
    assert C.request.put('/api/v2/me/location', data={'lat': PERTO[0], 'lng': PERTO[1]}).ok
    return C
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); R = A.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Ana', 'whatsapp': '+55 85 94444-1234', 'email': 'ana.dscev@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    def loja(empresa, cat, dlat, servicos=False, R=R):
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': empresa, 'categoria': cat, 'titulo': f'{empresa} no seu bairro', 'texto': 'Qualidade e preço justo', 'zap': '5585999990000'}); assert r.ok, r.text()
        i = r.json()['items'][0]['id']
        assert R.put(f'/api/v2/ads/{i}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok
        if servicos: assert R.post(f'/api/v2/ads/{i}/modalidade', data={'modalidade': 'services', 'confirmar': True}).ok
        db = sqlite3.connect(DBF); d = json.loads(db.execute('select data from businesses where id=?', (i,)).fetchone()[0]); d['logo'] = img((240, 240, 240), 120, 120)
        db.execute("update businesses set status='ativo', expires_at=?, lat=?, lng=?, data=? where id=?", ((datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z', PERTO[0] + dlat, PERTO[1], json.dumps(d), i)); db.commit(); db.close()
        return i
    MODA = loja('Moda Perto', 'Roupas', 0.004); DOCE = loja('Doces da Bia', 'Doceria', 0.010); PET = loja('Empório Feliz', 'Mercearia', 0.015)
    DS = conta(b, 'Dona Sol', 'sol.salao@t.com'); RS = DS.request; SAL = loja('Salão Lumi', 'Beleza', 0.006, True, RS)
    def P(L, d, R=R):
        r = R.post(f'/api/v2/ads/{L}/products', data=d); assert r.ok, (d.get('nome'), r.text()[:300]); return r.json()
    pid = {}
    for k in range(5): pid[f'camiseta{k}'] = P(MODA, {'nome': f'Camiseta {k + 1}', 'preco': 40 + k, 'categoria': 'Camisetas', 'fotos': [img((40, 60, 150 + k * 10))]})
    for k in range(6): pid[f'doce{k}'] = P(DOCE, {'nome': f'Brigadeiro {k + 1}', 'preco': 5 + k, 'categoria': 'Doces', 'fotos': [img((180, 90 + k * 10, 120))]})
    for k in range(4): pid[f'pet{k}'] = P(PET, {'nome': f'Ração {k + 1}', 'preco': 60 + k, 'categoria': 'Rações', 'fotos': [img((120, 160, 60 + k * 10))]})
    for nm, pr in [('Corte feminino', 80), ('Escova', 45), ('Manicure', 35)]: P(SAL, {'tipo': 'servico', 'nome': nm, 'preco': pr, 'modoPreco': 'fixo', 'duracao': 40, 'categoria': 'Cabelo' if nm != 'Manicure' else 'Unhas', 'fotos': [img((200, 120, 160))]}, RS)
    db = sqlite3.connect(DBF); prods = {r[1]: r[0] for r in db.execute("select id, json_extract(data,'$.nome') from products")}; db.close()
    CAM1, BRIG1 = prods['Camiseta 1'], prods['Brigadeiro 1']

    print('== A. o que aparece (painel → servidor → tela)')
    cfg = R.get('/api/v2/descobrir').json()
    check('padrão: Empresas, Produtos e Serviços', cfg['modos'] == ['empresas', 'produtos', 'servicos'], cfg)
    X = conta(b, 'Xavier Comum', 'xavier@t.com')
    check('usuário comum não altera o painel (403)', X.request.put('/api/panel/descobrir', data={'empresas': False}).status == 403)
    check('não deixa desligar as três opções', R.put('/api/panel/descobrir', data={'empresas': False, 'produtos': False, 'servicos': False}).status == 400)
    assert R.put('/api/panel/descobrir', data={'empresas': False}).ok
    r1 = X.request.get('/api/v2/businesses/search?q=&pagina=1&por=8'); r2 = X.request.get('/api/v2/marketplace/produtos?ordem=relevancia')
    check('Empresas desligada: lista e busca de empresas recusadas por requisição direta (404)', r1.status == 404 and r2.ok, (r1.status, r2.status))
    check('Empresas desligada: recomendações de empresas também recusadas', X.request.get('/api/v2/descobrir/recomendados?modo=empresas').status == 404)
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        C = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob, storage_state=X.storage_state()); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/empresas?modo=empresas'); pg.wait_for_selector('[data-mk]', timeout=20000)
        check(f'{nome}: sem a aba Empresas — abre direto em Produtos (até por link com ?modo=empresas)', [x.inner_text() for x in pg.locator('[data-modo]').all()] == ['Produtos', 'Serviços'] and pg.get_attribute('[data-modo=produtos]', 'aria-selected') == 'true' and pg.locator('[data-feed]').count() == 0)
        C.close()
    assert R.put('/api/panel/descobrir', data={'produtos': False}).ok
    pg = X.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.goto('/x/empresas'); pg.wait_for_selector('[data-mk]', timeout=20000)
    check('só Serviços ligado: rótulo único, sem seletor, só serviços', pg.locator('[data-modo]').count() == 0 and pg.inner_text('[data-modo-unico]') == 'Serviços' and all(x.get_attribute('data-mk-tipo') == 'servico' for x in pg.locator('[data-mk]').all()))
    check('Produtos desligado: busca de produtos recusada (404)', X.request.get('/api/v2/marketplace/produtos').status == 404)
    assert R.put('/api/panel/descobrir', data={'empresas': True, 'produtos': True}).ok
    pg.goto('/x/empresas'); pg.wait_for_selector('[data-emp]', timeout=20000)
    check('religadas: as três abas voltam e a lista de empresas também', [x.inner_text() for x in pg.locator('[data-modo]').all()] == ['Empresas', 'Produtos', 'Serviços'])
    pg.close()

    print('== B. banners')
    adm = b.new_context(base_url=BASE, viewport={'width': 1280, 'height': 900}, storage_state=A.storage_state()); pa = adm.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_selector('#ma-an-q', timeout=20000)
    pa.fill('#ma-an-q', 'banners'); pa.wait_for_function("()=>/Banners da página/.test(document.getElementById('ma-an-res').textContent)", timeout=5000)
    check('busca global "banners" encontra a configuração na página Descobrir', 'Banners da página Descobrir' in pa.inner_text('#ma-an-res') and 'Plataforma e Negócio › Descobrir' in pa.inner_text('#ma-an-res'), pa.inner_text('#ma-an-res'))
    pa.keyboard.press('Enter'); pa.wait_for_selector('#dsc_novo', timeout=10000)
    check('resultado abre a tela Descobrir (seção e subaba certas)', 'Descobrir' in pa.inner_text('#ma-an-secao'))
    pa.click('#dsc_novo'); pa.wait_for_selector('[data-bform]')
    fp = '/tmp/e2e/banner1.png'; Image.new('RGB', (1500, 500), (230, 90, 60)).save(fp)
    pa.set_input_files('#bf_img', fp); pa.wait_for_timeout(500)
    pa.fill('#bf_t', 'Camisetas em oferta'); pa.fill('#bf_d', 'Só nesta semana'); pa.fill('#bf_b', 'Ver camiseta'); pa.select_option('#bf_dt', 'produto'); pa.fill('#bf_dv', str(CAM1)); pa.fill('#bf_o', '1'); pa.fill('#bf_s', '3')
    pa.click('#bf_ok'); pa.wait_for_selector('[data-banner]', timeout=8000)
    bs = R.get('/api/panel/descobrir').json()['banners']
    check('banner criado pela tela (imagem, título, destino produto, ordem, 3 s)', len(bs) == 1 and bs[0]['titulo'] == 'Camisetas em oferta' and bs[0]['destinoTipo'] == 'produto' and bs[0]['duracao'] == 3 and bs[0]['noAr'], bs)
    pa.screenshot(path='/tmp/e2e/dscev_admin_banners.png')
    r = R.post('/api/panel/descobrir/banners', data={'imagem': img((40, 120, 200), 1200, 400, 'PNG'), 'titulo': 'Doces artesanais', 'botao': 'Ver doces', 'destinoTipo': 'categoria', 'destinoValor': 'produtos|Doces', 'ordem': 2, 'duracao': 3})
    check('segundo banner (categoria) pela API do painel', r.ok, r.text()[:200])
    passado = (datetime.datetime.utcnow() - datetime.timedelta(days=1)).isoformat() + 'Z'
    assert R.post('/api/panel/descobrir/banners', data={'imagem': img((10, 10, 10), 900, 300), 'titulo': 'Encerrado', 'fim': passado, 'inicio': (datetime.datetime.utcnow() - datetime.timedelta(days=3)).isoformat() + 'Z', 'ordem': 0}).ok
    check('validação: destino inexistente e imagem inválida são recusados', R.post('/api/panel/descobrir/banners', data={'imagem': img((1, 1, 1)), 'destinoTipo': 'produto', 'destinoValor': '999999'}).status == 400 and R.post('/api/panel/descobrir/banners', data={'imagem': 'data:text/html;base64,PGI+', 'titulo': 'x'}).status == 400)
    pub = X.request.get('/api/v2/descobrir').json()['banners']
    check('público: só os banners no período, na ordem (encerrado fica de fora)', [x['titulo'] for x in pub] == ['Camisetas em oferta', 'Doces artesanais'] and pub[0]['link'] == f'/x/empresa/{MODA}?produto={CAM1}', pub)
    im = X.request.get(pub[0]['imagem'])
    check('imagem do banner servida com tipo e cache', im.ok and im.headers['content-type'].startswith('image/') and 'max-age' in im.headers.get('cache-control', ''))
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        C = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob, storage_state=X.storage_state()); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/x/empresas'); pg.wait_for_selector('[data-bn-box]', timeout=20000); pg.wait_for_timeout(300)
        bx = pg.locator('[data-bn-box]').bounding_box(); bar = pg.locator('.ma-dsc-bar').bounding_box()
        check(f'{nome}: banners no topo, acima das abas e da busca', bx['y'] + bx['height'] <= bar['y'] + 1, (bx, bar))
        geo = pg.evaluate("()=>{const s=document.querySelector('.ma-bn-s'),i=s.querySelector('img'),r=s.getBoundingClientRect();return {ar:r.width/r.height,fit:getComputedStyle(i).objectFit,w:r.width,vw:innerWidth}}")
        check(f'{nome}: imagem sem distorção (cobre a área, proporção {"2:1" if mob else "3:1"})', geo['fit'] == 'cover' and abs(geo['ar'] - (2 if mob else 3)) < 0.05, geo)
        check(f'{nome}: 2 slides com indicadores, o 1º marcado', pg.locator('.ma-bn-s').count() == 2 and pg.locator('[data-bn-i]').count() == 2 and pg.get_attribute('[data-bn-i="0"]', 'aria-current') == 'true')
        pg.mouse.move(5, 830 if mob else 880)
        pg.wait_for_function("()=>document.querySelector('[data-bn-i=\"1\"]').getAttribute('aria-current')==='true'", timeout=8000)
        check(f'{nome}: passa sozinho para o próximo no tempo do banner (3 s)', True)
        if mob: pg.screenshot(path='/tmp/e2e/dscev_banner_celular.png')
        else: pg.screenshot(path='/tmp/e2e/dscev_banner_pc.png')
        check(f'{nome}: sem rolagem horizontal', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        if mob:
            pg.click('[data-bn-i="0"]'); pg.wait_for_timeout(700); pg.click('.ma-bn-s[data-bn] >> nth=0'); pg.wait_for_url(f'**/x/empresa/{MODA}?produto={CAM1}*', timeout=10000)
            check('celular: tocar no banner leva ao produto vinculado', f'produto={CAM1}' in pg.url)
        C.close()
    assert R.put('/api/panel/descobrir', data={'produtos': False}).ok
    pub = X.request.get('/api/v2/descobrir').json()['banners']
    check('banner que leva a Produtos some quando Produtos é desligado', pub == [], pub)
    assert R.put('/api/panel/descobrir', data={'produtos': True}).ok

    print('== C. personalização por usuário')
    U1 = conta(b, 'Lia Moda', 'lia@t.com', {'width': 390, 'height': 844}, True); U2 = conta(b, 'Caio Doce', 'caio@t.com'); U3 = conta(b, 'Nina Nova', 'nina@t.com')
    ordem = lambda C, modo='produtos': [x['nome'] for x in C.request.get(f'/api/v2/marketplace/{modo}?ordem=relevancia&por=40').json()['items']]
    base = ordem(U3)
    check('usuário novo: ordem geral (igual à de um visitante)', base == ordem(X))
    # U1: pela tela — busca "camiseta", abre camisetas, entra na loja (eventos em lote)
    pg = U1.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/empresas?modo=produtos'); pg.wait_for_selector('[data-mk]', timeout=20000)
    pg.fill('#pqi', 'camiseta'); pg.press('#pqi', 'Enter'); pg.wait_for_timeout(900)
    for k in range(2):
        pg.locator('[data-mk] [data-mk-nome]').nth(k).click(); pg.wait_for_timeout(900); pg.go_back(); pg.wait_for_selector('[data-mk]', timeout=10000)
    pg.evaluate('()=>window.__maDscFlush&&window.__maDscFlush()'); pg.wait_for_timeout(800)
    db = sqlite3.connect(DBF); uid1 = db.execute("select id from users where email='lia@t.com'").fetchone()[0]; ks = [r[0] for r in db.execute('select chave from user_interests where user_id=?', (uid1,))]; db.close()
    check('coleta pela tela: busca, cliques e acesso à loja viram interesses DA Lia (em lote)', 't:camiseta' in ks and f'e:{MODA}' in ks and any(k.startswith('p:') for k in ks) and 'c:camisetas' in ks, ks)
    # U2: interesses em doces (API da coleta, como a tela faz)
    assert U2.request.post('/api/v2/descobrir/interacoes', data={'eventos': [{'t': 'clique', 'k': 'p', 'id': BRIG1, 'bid': DOCE, 'cat': 'Doces'}, {'t': 'carrinho', 'k': 'p', 'id': BRIG1, 'bid': DOCE, 'cat': 'Doces'}, {'t': 'busca', 'k': 'p', 'termo': 'brigadeiro'}]}).ok
    o1, o2 = ordem(U1), ordem(U2)
    check('Lia (camisetas): camisetas sobem para o topo', all(n.startswith('Camiseta') for n in o1[:5]), o1[:6])
    check('Caio (doces): brigadeiros sobem para o topo', all(n.startswith('Brigadeiro') for n in o2[:6]), o2[:6])
    check('isolamento: o histórico de um não muda a vitrine do outro nem a do usuário novo', ordem(U3) == base and o1 != o2)
    e1 = [x['empresa'] for x in U1.request.get('/api/v2/businesses/search?q=&pagina=1&por=8').json()['items']]
    check('lista de empresas da Lia começa pela loja que ela acessa', e1[0] == 'Moda Perto', e1)
    r1 = U1.request.get('/api/v2/descobrir/recomendados?modo=produtos').json(); r3 = U3.request.get('/api/v2/descobrir/recomendados?modo=produtos').json()
    check('"Recomendado para você" para quem já interagiu; "Destaques perto de você" para o novo', r1['titulo'] == 'Recomendado para você' and r1['personalizado'] and r3['titulo'] == 'Destaques perto de você' and not r3['personalizado'], (r1['titulo'], r3['titulo']))
    lojas = {}
    for it in r1['items']: lojas[it['empresa']['id']] = lojas.get(it['empresa']['id'], 0) + 1
    check('recomendações com diversidade (no máximo 2 por empresa) e com camisetas presentes', max(lojas.values()) <= 2 and any(it['nome'].startswith('Camiseta') for it in r1['items']) and len(lojas) >= 3, (lojas, [i['nome'] for i in r1['items']]))
    pg.goto('/x/empresas?modo=produtos'); pg.wait_for_selector('[data-rec]:not([hidden]) [data-rec-mk]', timeout=15000)
    check('celular: faixa "Recomendado para você" na tela, sem mexer na contagem da lista', 'Recomendado para você' in pg.inner_text('[data-rec]') and pg.locator('[data-mk]').count() == 15, pg.locator('[data-mk]').count())
    pg.screenshot(path='/tmp/e2e/dscev_recomendados.png')
    check('persistência: interesses continuam depois de nova sessão', ordem(U1)[:5] == o1[:5])
    assert U1.request.delete('/api/v2/descobrir/interacoes').ok
    check('a pessoa pode limpar o próprio histórico (volta à ordem geral)', ordem(U1) == base)
    assert R.put('/api/panel/descobrir', data={'personalizacao': False}).ok
    U2.request.post('/api/v2/descobrir/interacoes', data={'eventos': [{'t': 'clique', 'k': 'p', 'id': BRIG1}]})
    check('personalização desligada no painel: todos na ordem geral', ordem(U2) == base)
    assert R.put('/api/panel/descobrir', data={'personalizacao': True}).ok
    pg.close()

    print('== D. busca global do painel')
    pa.goto('/admin'); pa.wait_for_selector('#ma-an-q', timeout=20000); pa.wait_for_timeout(600)
    B = lambda q: pa.evaluate('q=>window.__maAdmBuscar(q)', q)
    casos = [('usuários', 'Usuários'), ('usuarois', 'Usuários'), ('IA', 'Provedores de IA'), ('voz', 'Voz natural'), ('anúncios', 'Anúncios'), ('publicidade', 'Anúncios'), ('pagamentos', 'Mercado Pago'), ('pix', 'Pix'), ('esconder modo', 'Mostrar ou esconder cada Modo Inteligente'), ('banner', 'Banners da página Descobrir'), ('aprendizado coletivo', 'Aprendizado coletivo'), ('cupom', 'Cupons de desconto'), ('tema escuro', 'Aparência')]
    for q, alvo in casos:
        t = [x['titulo'] for x in B(q)[:4]]
        check(f'busca "{q}" → {alvo}', alvo in t, t)
    ag = [x['titulo'] + ' | ' + x['caminho'] for x in B('agenda')]
    check('busca "agenda" → funções relacionadas (módulo de agenda)', any('Agenda' in x or 'Compromissos' in x for x in ag), ag)
    check('termo sem relação: nenhum resultado inventado', B('xyzw qwerty') == [])
    pa.keyboard.press('/'); check('atalho "/" foca a busca', pa.evaluate("document.activeElement.id") == 'ma-an-q')
    pa.keyboard.type('voz'); pa.wait_for_function("()=>/Voz natural/.test(document.getElementById('ma-an-res').textContent)", timeout=5000); t = pa.inner_text('#ma-an-res')
    check('resultado mostra nome, onde fica e descrição', 'Voz natural' in t and 'Inteligência do Chat › IA, Provedores e Voz' in t)
    pa.keyboard.press('Enter'); pa.wait_for_timeout(800)
    check('Enter abre a subaba Voz natural', pa.get_attribute('#ma-adm-nav [data-sub="voz"]', 'aria-selected') == 'true')
    pa.click('#ma-an-secao'); its = pa.locator('#ma-an-menu [data-area="plataforma"]').all_inner_texts()
    check('Plataforma e Negócio em 7 seções organizadas (antes 1 seção com 27 subabas)', len(its) == 7 and any('Descobrir' in x for x in its), its)
    pa.click('#ma-an-menu [data-secao="moedas"]'); pa.wait_for_timeout(700)
    check('cada seção abre a sua primeira subaba (Moedas → MCoins)', pa.get_attribute('#ma-adm-nav [data-sub="moedas"]', 'aria-selected') == 'true' and 'Moedas e Benefícios' in pa.inner_text('#ma-an-secao'))
    p2 = adm.new_page(); p2.goto('/admin'); p2.wait_for_selector('#ma-an-q', timeout=20000); p2.wait_for_timeout(900)
    check('a última seção acessada volta ao reabrir o painel', 'Moedas e Benefícios' in p2.inner_text('#ma-an-secao'), p2.inner_text('#ma-an-secao')); p2.close()
    pa.goto('/admin?aba=planos'); pa.wait_for_timeout(1200)
    check('link antigo ?aba=planos continua abrindo Planos de anúncio', pa.get_attribute('#ma-adm-nav [data-sub="planos"]', 'aria-selected') == 'true')
    # admin restrito: sem "Ver usuários"
    L = conta(b, 'Lara Restrita', 'lara.adm@t.com')
    db = sqlite3.connect(DBF); db.execute("update users set role='admin', permissions=? where email='lara.adm@t.com'", (json.dumps(['audit.view', 'panel.manage']),)); db.commit(); db.close()
    pl = L.new_page(); pl.goto('/admin'); pl.wait_for_selector('#ma-an-q', timeout=20000); pl.wait_for_timeout(900)
    tl = [x['tab'] for x in pl.evaluate('q=>window.__maAdmBuscar(q)', 'usuários')]; ta = [x['tab'] for x in pl.evaluate('q=>window.__maAdmBuscar(q)', 'anúncios')]
    check('permissões: admin sem "Ver usuários" e sem "Gerenciar anúncios" não recebe resultados que levam a essas telas', 'react:Usuários' not in tl and 'anuncios' not in ta and 'planos' in ta, (tl, ta))
    check('admin sem "Ver usuários" agora também chega ao painel (seções e busca)', pl.locator('#ma-an-secao').count() == 1 and pl.locator('#ma-an-menu [data-sub="react:Usuários"], #ma-adm-nav [data-sub="react:Usuários"]').count() == 0)
    pl.close()
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True)]:
        C = b.new_context(base_url=BASE, viewport=vp, is_mobile=mob, has_touch=mob, storage_state=A.storage_state()); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/admin'); pg.wait_for_selector('#ma-an-q', timeout=20000); pg.wait_for_timeout(500)
        qb = pg.locator('.ma-an-q').bounding_box()
        check('celular: busca visível sem abrir menu, largura total, campo de 16 px (sem zoom no iPhone)', qb['width'] > 330 and pg.evaluate("getComputedStyle(document.getElementById('ma-an-q')).fontSize") == '16px', qb)
        pg.fill('#ma-an-q', 'whats'); pg.wait_for_function("()=>/WhatsApp/.test(document.getElementById('ma-an-res').textContent)", timeout=5000); pg.screenshot(path='/tmp/e2e/dscev_busca_celular.png')
        rb = pg.locator('#ma-an-res').bounding_box()
        check('celular: resultados cabem na tela, sem rolagem lateral', rb['x'] >= 0 and rb['x'] + rb['width'] <= 391 and pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1, rb)
        pg.locator('#ma-an-res [data-ri]').first.click(); pg.wait_for_timeout(800)
        check('celular: tocar no resultado abre WhatsApp (envio)', pg.get_attribute('#ma-adm-nav [data-sub="whatsapp"]', 'aria-selected') == 'true')
        C.close()
    pa.screenshot(path='/tmp/e2e/dscev_admin.png')
    errs = [e for e in errs if 'React error #418' not in e and e != 'Event']
    check('sem erros de JavaScript', not errs, errs[:5])
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
