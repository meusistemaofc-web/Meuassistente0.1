# Microfone com transcrição DIRETO no campo de mensagem — correção definitiva (ditado do aparelho, tela real do chat).
# Reconhecimento de fala simulado como no Chrome/Android: palavras chegam aos poucos (resultados parciais), a sessão do
# navegador pode encerrar sozinha numa pausa e o app recomeça sem perder nem repetir texto. Verifica:
#  • o texto aparece no campo enquanto se fala (latência medida), sem campo/área de transcrição separada, com o indicador
#    discreto "Ouvindo…" dentro do campo; o campo NÃO fica bloqueado: dá para digitar/editar durante o ditado sem conflito nem duplicação;
#  • composição do teclado (IME) não é atropelada pela fala; pausar e retomar; interromper e retomar; texto anterior preservado;
#  • enviar durante o ditado encerra a captura e envia exatamente o campo, uma vez, sem texto "fantasma" depois;
#  • sair do chat / app em segundo plano encerra o microfone; dois toques rápidos não criam duas sessões;
#  • erro de reconhecimento no meio não apaga o texto; permissão negada → aviso;
#  • sem artefato visual: nada se desloca ao ativar o microfone,
#    o pulso do botão não passa do próprio botão; o indicador "Ouvindo…" é um elemento próprio dentro do campo (não o placeholder);
#    celular e computador, tema escuro e claro; sem erros de JavaScript.
# Servidor: PORT=4392 SQLITE_FILE=/tmp/ma-micc.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4392'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
FAKE = r"""(()=>{window.__recs=[];window.__fila=[];window.__ritmo=200;window.__fimApos=0;window.__erroApos=0;
 class Rec{constructor(){this.lang='';this.continuous=false;this.interimResults=false;this._ok=false;this._t=[];this._w=[];window.__recs.push(this)}
  start(){if(window.__falhaInicio==='not-allowed'){setTimeout(()=>{this.onerror&&this.onerror({error:'not-allowed'});this.onend&&this.onend()},30);return}
   this._ok=true;this._ini=Date.now();window.__recAtivo=this;setTimeout(()=>{this.onstart&&this.onstart();this._tick()},30)}
  _emit(fin){const t=this._w.join(' ');window.__ultimoResultado=performance.now();this.onresult&&this.onresult({resultIndex:0,results:[{0:{transcript:t},isFinal:fin,length:1}]})}
  _tick(){if(!this._ok)return;if(window.__erroApos&&this._w.length>=window.__erroApos){window.__erroApos=0;this._ok=false;this.onerror&&this.onerror({error:'network'});setTimeout(()=>this.onend&&this.onend(),10);return}
   if(window.__fila.length){this._w.push(window.__fila.shift());this._emit(false);this._ult=Date.now()}
   else if(window.__fimApos&&this._w.length&&Date.now()-this._ult>window.__fimApos){this._emit(true);return this._fim()}
   this._t.push(setTimeout(()=>this._tick(),window.__ritmo))}
  _fim(){this._ok=false;this._t.forEach(clearTimeout);if(window.__recAtivo===this)window.__recAtivo=null;setTimeout(()=>this.onend&&this.onend(),15)}
  stop(){if(this._w.length)this._emit(true);this._fim()}
  abort(){window.__abortos=(window.__abortos||0)+1;this._fim()}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec;
 const oq=navigator.permissions.query.bind(navigator.permissions);navigator.permissions.query=d=>d&&d.name==='microphone'?Promise.resolve({get state(){return window.__permMic||'granted'},onchange:null}):oq(d)})()"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for k, (nome, vp, mob, tema) in enumerate([('celular-escuro', {'width': 390, 'height': 844}, True, 'dark'), ('celular-claro', {'width': 390, 'height': 844}, True, 'light'), ('computador', {'width': 1280, 'height': 900}, False, 'dark')]):
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, device_scale_factor=2, permissions=['microphone']); C.add_init_script(FAKE)
        assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Mia Teste', 'whatsapp': f'+55 11 95533-{k}{k}{k}{k}', 'email': f'mia{k}.mc@t.com', **U}, headers={'X-Forwarded-For': f'10.7.3.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios, transc = [], []
        pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        pg.on('request', lambda r: transc.append(r.url) if '/api/transcribe' in r.url and 'diagnostico' not in r.url else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1200)
        pg.evaluate(f"document.documentElement.setAttribute('data-theme','{tema}')")
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        TA = 'textarea[data-composer-input]'; campo = lambda: pg.input_value(TA)
        mic = lambda: pg.locator('button[aria-label="Ditar mensagem"], button[aria-label="Pausar ditado"]').first
        estado = lambda: pg.get_attribute('[data-ditado-estado]', 'data-ditado-estado')
        fala = lambda t: pg.evaluate(f"window.__fila.push(...{t.split()!r})")
        ativos = lambda: pg.evaluate("window.__recs.filter(r=>r._ok).length")
        def espera(cond, t=6000):
            fim = time.time() + t / 1000
            while time.time() < fim:
                if pg.evaluate(cond): return True
                pg.wait_for_timeout(60)
            return False
        # 0) artefato visual: o campo vazio durante a escuta é idêntico ao campo vazio parado; nada se desloca
        caixa = lambda: pg.evaluate("()=>{const r=s=>{const e=document.querySelector(s);if(!e)return null;const b=e.getBoundingClientRect();return [Math.round(b.x),Math.round(b.y),Math.round(b.width),Math.round(b.height)]};return {ta:r('textarea[data-composer-input]'),env:r('button[aria-label=Enviar]'),mic:r('[data-ditado-estado]'),comp:r('.ma-composer')}}")
        reg = pg.locator(TA).bounding_box(); clip = {'x': reg['x'], 'y': reg['y'], 'width': reg['width'] - 2, 'height': reg['height']}
        pg.mouse.move(0, 0); antes_img = pg.screenshot(clip=clip); antes = caixa(); open(f'/tmp/e2e/mc_{k}_a.png','wb').write(antes_img)
        mic().click(); espera("document.querySelector('[data-ditado-estado=listening]')"); pg.wait_for_timeout(700)
        durante_img = pg.screenshot(clip=clip); durante = caixa(); open(f'/tmp/e2e/mc_{k}_b.png','wb').write(durante_img); ta = pg.evaluate(f"(()=>{{const t=document.querySelector('{TA}');return {{ro:t.readOnly,dis:t.disabled,ph:t.placeholder}}}})()")
        ind = pg.evaluate("()=>{const e=document.querySelector('[data-ditado-indicador]'),t=document.querySelector('textarea[data-composer-input]');if(!e)return null;const a=e.getBoundingClientRect(),c=t.getBoundingClientRect();return {txt:e.textContent,estado:e.dataset.ditadoIndicador,dentro:a.left>=c.left&&a.right<=c.right&&a.top>=c.top&&a.bottom<=c.bottom,vazio:e.classList.contains('is-vazio')}}")
        check(f'{nome}: indicador "Ouvindo" discreto DENTRO do campo (elemento próprio, não o placeholder)', ind and ind['txt'] == 'Ouvindo' and ind['estado'] == 'ouvindo' and ind['dentro'] and ind['vazio'] and 'Ouvindo' not in ta['ph'], (ind, ta))
        check(f'{nome}: fora o indicador, o campo não muda (sem traço nem linha)', antes_img != durante_img, 'esperado: só o indicador aparece')
        check(f'{nome}: o campo continua editável (não bloqueado) durante o ditado', not ta['ro'] and not ta['dis'], ta)
        check(f'{nome}: nada se desloca ao ativar o microfone (campo, botões e caixa nas mesmas posições)', antes == durante, (antes, durante))
        anel = pg.evaluate("()=>{const o=document.querySelector('.ma-mic-onda'),b=document.querySelector('[data-ditado-estado]');if(!o)return null;const a=o.getBoundingClientRect(),c=b.getBoundingClientRect(),cs=getComputedStyle(o);return {dentro:a.left>=c.left&&a.right<=c.right&&a.top>=c.top&&a.bottom<=c.bottom,anim:cs.animationName,esc:cs.transform,bg:getComputedStyle(b).backgroundColor}}")
        check(f'{nome}: botão do microfone vira pausa VERMELHA, com o pulso dentro do próprio botão', anel and anel['dentro'] and anel['anim'].startswith('ma-mic-onda') and anel['esc'] in ('none', '') and anel['bg'] == 'rgb(229, 72, 77)', anel)
        if k == 0: pg.locator('.ma-composer').first.screenshot(path='/tmp/e2e/mic_campo_ouvindo_escuro.png')
        if k == 1: pg.locator('.ma-composer').first.screenshot(path='/tmp/e2e/mic_campo_ouvindo_claro.png')
        # 1) texto progressivo no campo, com latência medida
        pg.evaluate("window.__lat=[];const t=document.querySelector('textarea[data-composer-input]');new MutationObserver(()=>{}).observe(t,{attributes:true});let ult='';setInterval(()=>{if(t.value!==ult){ult=t.value;window.__ultimoResultado&&window.__lat.push(performance.now()-window.__ultimoResultado)}},10)")
        fala('quero pesquisar produtos para minha loja'); amostras = []
        for _ in range(16): amostras.append(campo()); pg.wait_for_timeout(110)
        cresce = [a for j, a in enumerate(amostras) if a and (j == 0 or a != amostras[j - 1])]
        lat = pg.evaluate('window.__lat'); lat_max = max(lat) if lat else 999
        check(f'{nome}: o texto aparece no campo progressivamente enquanto se fala', len(cresce) >= 4 and all(len(cresce[j]) > len(cresce[j - 1]) for j in range(1, len(cresce))) and campo().lower() == 'quero pesquisar produtos para minha loja', cresce)
        check(f'{nome}: sem atraso perceptível (cada palavra chega ao campo em < 100 ms)', lat_max < 100, lat[:8])
        check(f'{nome}: nenhuma transcrição pelo servidor (sem upload de áudio) e nada enviado ao chat', not transc and not envios, (transc, len(envios)))
        # 2) digitar no meio do ditado: complementa sem duplicar; a fala seguinte entra depois do que foi digitado
        pg.locator(TA).focus(); pg.evaluate(f"(()=>{{const t=document.querySelector('{TA}');t.setSelectionRange(t.value.length,t.value.length)}})()"); pg.keyboard.type(' de roupas')
        pg.wait_for_timeout(150); fala('e acessórios femininos'); espera(f"document.querySelector('{TA}').value.includes('femininos')", 4000)
        v = campo()
        check(f'{nome}: dá para digitar durante o ditado; a fala continua depois do texto digitado, sem duplicar', v.lower() == 'quero pesquisar produtos para minha loja de roupas e acessórios femininos', v)
        # 3) composição do teclado (IME): a fala que chega durante a composição espera a composição terminar
        pg.evaluate(f"document.querySelector('{TA}').dispatchEvent(new CompositionEvent('compositionstart',{{bubbles:true}}))")
        fala('no centro'); pg.wait_for_timeout(700); durante_ime = campo()
        pg.evaluate(f"document.querySelector('{TA}').dispatchEvent(new CompositionEvent('compositionend',{{bubbles:true,data:''}}))"); pg.wait_for_timeout(400)
        check(f'{nome}: durante a composição do teclado o campo não é reescrito; ao terminar, a fala entra', durante_ime == v and campo().lower().endswith('femininos no centro'), (durante_ime, campo()))
        # 4) pausa curta em que o navegador encerra a sessão sozinho: recomeça sem perder nem repetir
        pg.evaluate('window.__fimApos=600'); pg.wait_for_timeout(1400); fala('da cidade'); espera(f"document.querySelector('{TA}').value.includes('cidade')", 4000)
        v = campo().lower()
        check(f'{nome}: pausa e retomada (o navegador encerrou a sessão; o app recomeçou) sem perder nem repetir', estado() == 'listening' and v.endswith('no centro da cidade') and v.count('quero pesquisar') == 1 and v.count('no centro') == 1 and len(pg.evaluate('window.__recs')) >= 2, (estado(), v))
        pg.evaluate('window.__fimApos=0')
        check(f'{nome}: nunca há duas escutas ao mesmo tempo', ativos() <= 1, ativos())
        # 5) parar (toque no microfone): texto fica, editável; retomar acrescenta no cursor
        mic().click(); espera("document.querySelector('[data-ditado-estado=inativo]')"); pg.wait_for_timeout(300)
        parado = campo(); pg.locator(TA).focus(); pg.evaluate(f"(()=>{{const t=document.querySelector('{TA}');t.setSelectionRange(t.value.length,t.value.length)}})()"); pg.keyboard.press('Backspace'); pg.keyboard.press('Backspace'); pg.keyboard.type('de.')
        check(f'{nome}: parar deixa o texto no campo e ele pode ser editado', estado() == 'inativo' and campo().endswith('cidade.') and ativos() == 0, (estado(), campo()))
        mic().click(); espera("document.querySelector('[data-ditado-estado=listening]')"); fala('Entrega rápida'); espera(f"document.querySelector('{TA}').value.includes('rápida')", 4000)
        check(f'{nome}: interromper e retomar: a nova fala é acrescentada, o texto anterior fica', campo().endswith('cidade. Entrega rápida') and campo().lower().count('quero pesquisar') == 1, campo())
        # 6) enviar durante o ditado: encerra a captura e envia exatamente o campo, uma vez; nada volta depois
        esperado = campo(); n_env = len(envios); pg.locator('button[aria-label="Enviar"]').click(); pg.wait_for_timeout(400); fala('palavra atrasada'); pg.wait_for_timeout(1500)
        msgs = [x for x in envios[n_env:] if 'Entrega' in x]
        check(f'{nome}: enviar durante o ditado envia exatamente o texto do campo (uma vez) e encerra a escuta', len(msgs) == 1 and esperado in msgs[0].encode().decode('unicode_escape', 'ignore') or len(msgs) == 1 and 'Entrega r' in msgs[0], (msgs, esperado))
        check(f'{nome}: depois de enviar, o campo fica vazio e o microfone desligado (sem texto fantasma)', campo() == '' and estado() == 'inativo' and ativos() == 0, (campo(), estado(), ativos()))
        # 7) dois toques rápidos: uma sessão só
        mic().click(); mic().click(); mic().click(); pg.wait_for_timeout(600)
        check(f'{nome}: toques repetidos não criam várias sessões', ativos() <= 1, ativos())
        if estado() == 'listening': mic().click(); pg.wait_for_timeout(300)
        # 8) erro no meio (rede): o texto já ditado fica, aviso discreto
        pg.fill(TA, ''); mic().click(); espera("document.querySelector('[data-ditado-estado=listening]')"); pg.evaluate('window.__erroApos=3'); fala('isso precisa ficar aqui mesmo'); pg.wait_for_timeout(1500)
        aviso = pg.inner_text('[data-ditado-aviso]') if pg.locator('[data-ditado-aviso]').count() else ''
        check(f'{nome}: erro de reconhecimento no meio: o texto dito fica e aparece um aviso discreto', campo().lower().startswith('isso precisa ficar') and estado() in ('inativo', 'erro') and aviso, (campo(), estado(), aviso))
        pg.evaluate('window.__fila=[]')
        # 9) chat por digitação continua igual
        pg.fill(TA, 'mensagem digitada normalmente'); n_env = len(envios); pg.locator('button[aria-label="Enviar"]').click(); pg.wait_for_timeout(1200)
        check(f'{nome}: chat por digitação intacto', len([x for x in envios[n_env:] if 'digitada normalmente' in x]) == 1 and campo() == '')
        # 10) sair do chat com o microfone ligado: microfone desligado (nada escondido)
        mic().click(); espera("document.querySelector('[data-ditado-estado=listening]')")
        pg.evaluate("history.pushState({},'','/agenda');dispatchEvent(new PopStateEvent('popstate'))"); pg.wait_for_timeout(1200)
        some = not pg.locator(TA).count()
        check(f'{nome}: sair do chat com o microfone ligado encerra a escuta', ativos() == 0, (some, ativos()))
        pg.evaluate("history.pushState({},'','/');dispatchEvent(new PopStateEvent('popstate'))"); pg.wait_for_timeout(1200)
        if k == 2:
            # 11) app em segundo plano: a escuta para e o texto fica
            pg.wait_for_selector(TA, timeout=10000); pg.fill(TA, ''); mic().click(); espera("document.querySelector('[data-ditado-estado=listening]')"); fala('texto antes de sair'); espera(f"document.querySelector('{TA}').value.includes('sair')", 4000)
            pg.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>'hidden'});document.dispatchEvent(new Event('visibilitychange'))"); pg.wait_for_timeout(500)
            check(f'{nome}: app em segundo plano encerra o microfone e mantém o texto', ativos() == 0 and campo().lower() == 'texto antes de sair', (ativos(), campo()))
            pg.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,get:()=>'visible'})")
            # 12) permissão negada: aviso, texto preservado
            pg.fill(TA, 'não apague'); pg.evaluate("window.__falhaInicio='not-allowed';window.__permMic='denied'"); mic().click(); pg.wait_for_timeout(900)
            aviso = pg.inner_text('[data-ditado-aviso]') if pg.locator('[data-ditado-aviso]').count() else ''
            check(f'{nome}: permissão negada → aviso de como liberar e o texto continua', 'microfone' in aviso.lower() and campo() == 'não apague' and estado() in ('inativo', 'erro'), (aviso, campo(), estado()))
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"\n{'FIM OK' if all(res) else 'FIM FALHOU'} {sum(res)}/{len(res)}")
