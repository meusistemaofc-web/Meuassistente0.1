# QR Code do catálogo (Sua empresa → "Seu catálogo tem link próprio" → Meu QR Code).
# A imagem gerada (prévia, PNG baixado, versão balcão, com e sem logo, cor da empresa boa ou de pouco contraste) é LIDA de
# verdade por um leitor de QR (OpenCV) e o link lido abre o catálogo certo sem login. Também testa:
#   - ampliar, copiar link, compartilhar a imagem e imprimir;
#   - Compartilhar intacto;
#   - cada empresa com o seu QR;
#   - celular e computador, tema claro e escuro, sem rolagem lateral.
# Servidor: PORT=4399 SQLITE_FILE=/tmp/ma-qr.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, base64, io, datetime
import numpy as np, cv2
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4399'; DBF = '/tmp/ma-qr.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
def ler(png_bytes, escala=1.0):
    im = Image.open(io.BytesIO(png_bytes)).convert('RGB')
    if escala != 1: im = im.resize((int(im.width * escala), int(im.height * escala)))
    return dec(np.array(im.convert('L'))), im.size
def dec(a):
    # dois leitores: o clássico do OpenCV e o "Aruco" (mais robusto, como os leitores das câmeras de celular); vale o que ler
    v = cv2.QRCodeDetector().detectAndDecode(a)[0]
    return v or cv2.QRCodeDetectorAruco().detectAndDecode(a)[0]
def foto_celular(png_bytes):
    # simula a câmera: QR menor, girado, com ruído e fundo — como uma foto do balcão
    # (uma foto 1200×1500 de celular com o impresso ocupando ~60% da largura, girado 8° e com ruído; tenta 3 enquadramentos como a câmera faz)
    src = Image.open(io.BytesIO(png_bytes)).convert('RGB'); lidos = []
    for larg, ang, x0 in ((720, 8, 220), (680, -6, 260), (760, 4, 200)):
        im = src.resize((larg, int(larg * src.height / src.width)))
        fundo = Image.new('RGB', (1200, 1500), (120, 110, 95)); fundo.paste(im.rotate(ang, expand=True, fillcolor=(120, 110, 95)), (x0, 120))
        a = np.array(fundo).astype(np.int16) + np.random.default_rng(1).integers(-18, 18, (1500, 1200, 3)); a = np.clip(a, 0, 255).astype(np.uint8)
        lidos.append(dec(cv2.cvtColor(a, cv2.COLOR_RGB2GRAY)))
    return next((v for v in lidos if v), '')
def logo_png():
    im = Image.new('RGB', (300, 300), (29, 78, 216)); d = ImageDraw.Draw(im); d.ellipse((60, 60, 240, 240), fill=(255, 255, 255)); d.rectangle((120, 110, 180, 190), fill=(29, 78, 216))
    b = io.BytesIO(); im.save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1986-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def ativar(ID, cor, logo=None):
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); d['tema'] = {**(d.get('tema') or {}), 'cor': cor}
    if logo: d['logo'] = logo
    db("update businesses set data=?, status='ativo', expires_at=? where id=?", (json.dumps(d), (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat(), ID))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin QR', 'whatsapp': '+55 11 93333-1000', 'email': 'admin.qr@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
    donos = []
    for k, (emp, cor, comLogo) in enumerate([('Doceria Bem Bom', '#1d4ed8', True), ('Ótica Clara Vista', '#f5e663', False)]):
        C = b.new_context(base_url=BASE); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': f'Dona {k}', 'whatsapp': f'+55 85 96666-20{k}{k}', 'email': f'dona{k}.qr@t.com', **U}, headers={'X-Forwarded-For': f'10.9.0.{k}'}).ok
        ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': emp, 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5585966660000', 'tipo': 'produtos', 'endereco': 'Rua C, 30'}).json()['items'][0]['id']
        ativar(ID, cor, logo_png() if comLogo else None)
        db("INSERT INTO products (business_id, data, active) VALUES (?, ?, 1)", (ID, json.dumps({'nome': f'Produto da {emp}', 'preco': 25, 'categoria': 'Geral', 'tipo': 'produto', 'fotos': [], 'variacoes': []}))); donos.append((emp, ID, C, comLogo)); C.close()
    site = A.request.get('/api/panel/public').json().get('site_url') or BASE
    for vez, (nome, vp, mob, tema) in enumerate([('celular', {'width': 390, 'height': 844}, True, 'dark'), ('computador', {'width': 1280, 'height': 900}, False, 'light')]):
        for emp, ID, _, comLogo in donos:
            if vez == 1 and not comLogo: continue
            print('==', nome, tema, emp)
            k = [d[0] for d in donos].index(emp)
            c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, color_scheme=tema, accept_downloads=True); c.grant_permissions(['clipboard-read', 'clipboard-write'], origin=BASE)
            assert c.request.post('/api/auth', data={'action': 'login', 'email': f'dona{k}.qr@t.com', 'password': U['password']}).ok
            pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('/x/sua-empresa'); pg.wait_for_selector(f'[data-qr="{ID}"]:visible', timeout=20000); pg.wait_for_selector(f'[data-share="{ID}"]:visible', timeout=10000); pg.wait_for_timeout(500)
            cq = pg.locator(f'[data-qr="{ID}"]:visible').first.evaluate("e=>{const c=e.closest('.glass-inset'),s=c&&c.querySelector('[data-share]');return [s?s.getBoundingClientRect().width>60&&s.textContent.trim()==='Compartilhar'?1:0:0,e.textContent.trim()]}")
            check(f'{nome}/{emp}: "Meu QR Code" no card do link, com o Compartilhar intacto', cq[0] >= 1 and 'Meu QR Code' in cq[1], cq)
            if vez == 0 and k == 0: pg.locator(f'[data-qr="{ID}"]:visible').first.evaluate("e=>e.closest('.glass-inset').scrollIntoView({block:'center'})"); pg.wait_for_timeout(200); pg.locator(f'[data-qr="{ID}"]').evaluate("e=>e.closest('.glass-inset')").__class__; pg.screenshot(path='/tmp/e2e/qr_card.png')
            pg.locator(f'[data-qr="{ID}"]:visible').first.click(); pg.wait_for_selector('[data-qr-sheet] [data-qr-img][src^="data:image/png"]', timeout=10000); pg.wait_for_timeout(300)
            url = f"{site.rstrip('/')}/x/empresa/{ID}"
            prev = base64.b64decode(pg.locator('[data-qr-img]').get_attribute('src').split(',', 1)[1]); v, tam = ler(prev)
            check(f'{nome}/{emp}: prévia lida por leitor de QR = link público do catálogo ({"com logo" if comLogo else "sem logo"})', v == url and tam == (1600, 1600), (v, url, tam))
            check(f'{nome}/{emp}: "foto" do QR (menor, girado, com ruído) também é lida', foto_celular(prev) == url)
            check(f'{nome}/{emp}: link visível e "Abrir" aponta para o catálogo', url.replace('https://', '').replace('http://', '') in pg.inner_text('[data-qr-url]') and pg.locator('[data-qr-sheet] a[target=_blank]').get_attribute('href') == url)
            pg.click('[data-qr-copiar]'); pg.wait_for_timeout(300)
            check(f'{nome}/{emp}: copiar link', pg.evaluate('navigator.clipboard.readText()') == url)
            if comLogo:
                pg.locator('[data-qr-logo]').uncheck(); pg.wait_for_timeout(250); v2, _ = ler(base64.b64decode(pg.locator('[data-qr-img]').get_attribute('src').split(',', 1)[1]))
                check(f'{nome}/{emp}: sem o logo continua lendo', v2 == url, v2); pg.locator('[data-qr-logo]').check(); pg.wait_for_timeout(250)
            with pg.expect_download() as dl: pg.click('[data-qr-baixar]')
            d = dl.value; png = open(d.path(), 'rb').read(); v, tam = ler(png)
            check(f'{nome}/{emp}: baixar PNG em alta resolução (1600×1600) e legível', d.suggested_filename.endswith('.png') and png[:8] == b'\x89PNG\r\n\x1a\n' and tam == (1600, 1600) and v == url, (d.suggested_filename, tam, v))
            peq = {w: ler(png, w / 1600)[0] == url for w in (300, 400, 600)}
            check(f'{nome}/{emp}: legível também reduzido (300, 400 e 600 px — como impresso em 2,5 a 5 cm)', sum(peq.values()) >= 2, peq)
            # versão para balcão
            pg.click('[data-qr-modo=balcao]'); pg.wait_for_timeout(300)
            with pg.expect_download() as dl: pg.click('[data-qr-baixar]')
            png2 = open(dl.value.path(), 'rb').read(); v, tam = ler(png2)
            check(f'{nome}/{emp}: versão para balcão (A6, 1240×1754) legível, arquivo "-balcao.png"', tam == (1240, 1754) and v == url and dl.value.suggested_filename.endswith('-balcao.png'), (tam, v))
            check(f'{nome}/{emp}: balcão lido em "foto" de celular', foto_celular(png2) == url)
            if vez == 0: Image.open(io.BytesIO(png2)).save(f'/tmp/e2e/qr_balcao_{k}.png'); Image.open(io.BytesIO(prev)).save(f'/tmp/e2e/qr_marca_{k}.png')
            # compartilhar a imagem pelos apps do aparelho (navigator.share com arquivo)
            pg.evaluate("""()=>{window.__sh=null;navigator.canShare=o=>!!(o&&o.files);navigator.share=async o=>{window.__sh={n:o.files&&o.files.length,t:o.files&&o.files[0].type,nome:o.files&&o.files[0].name,tam:o.files&&o.files[0].size,texto:o.text}}}""")
            pg.click('[data-qr-share]'); pg.wait_for_function('window.__sh', timeout=6000); sh = pg.evaluate('window.__sh')
            check(f'{nome}/{emp}: compartilhar envia a imagem PNG (com o link no texto)', sh and sh['n'] == 1 and sh['t'] == 'image/png' and sh['tam'] > 20000 and url in sh['texto'], sh)
            # imprimir: página própria com a imagem, sem a interface do app
            pg.evaluate("""()=>{window.__pr=0;const od=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,'contentWindow');Object.defineProperty(HTMLIFrameElement.prototype,'contentWindow',{configurable:true,get(){const w=od.get.call(this);try{w.print=()=>{window.__pr++;window.__prHtml=w.document.documentElement.outerHTML}}catch(e){}return w}})}""")
            pg.click('[data-qr-print]'); pg.wait_for_timeout(800); pr = pg.evaluate('[window.__pr, (window.__prHtml||"").slice(0,400)]')
            check(f'{nome}/{emp}: imprimir abre a versão de impressão (A6) com a imagem', pr[0] == 1 and '@page' in pr[1] and 'A6' in pr[1] and '<img' in pg.evaluate('window.__prHtml||""'), pr)
            # ampliar e fechar
            pg.click('[data-qr-ampliar]'); pg.wait_for_selector('[data-qr-zoom] img', timeout=3000)
            zb = pg.locator('[data-qr-zoom] img').bounding_box()
            check(f'{nome}/{emp}: visualização ampliada (QR grande na tela)', max(zb['width'], zb['height']) >= min(vp['width'], vp['height']) * .8, zb)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
            check(f'{nome}/{emp}: Esc fecha só o ampliado (o painel do QR continua)', pg.locator('[data-qr-zoom]').count() == 0 and pg.locator('[data-qr-sheet]').count() == 1)
            ow = pg.evaluate('()=>{const s=document.querySelector(".ma-sheet-in");return [s.scrollWidth-s.clientWidth, document.documentElement.scrollWidth-innerWidth]}')
            check(f'{nome}/{emp}: sem rolagem lateral ({vp["width"]} px, tema {tema})', ow[0] <= 1 and ow[1] <= 1, ow)
            if k == 0: pg.locator('.ma-sheet-in').screenshot(path=f'/tmp/e2e/qr_painel_{nome}_{tema}.png')
            c.close()
            # o link lido abre o catálogo certo, sem login, num aparelho qualquer
            anon = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True); ap = anon.new_page()
            ap.goto(url.replace(site.rstrip('/'), BASE)); ap.wait_for_timeout(2500); txt = ap.inner_text('body')
            outra = [d[0] for d in donos if d[0] != emp][0]
            check(f'{nome}/{emp}: link do QR abre o catálogo desta empresa sem login', emp in txt and f'Produto da {emp}' in txt and outra not in txt and '/login' not in ap.url and 'Entrar' not in txt[:200], (ap.url, txt[:200]))
            anon.close()
    ids = [d[1] for d in donos]; check('cada empresa tem o seu QR (links diferentes)', len(set(ids)) == 2)
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
