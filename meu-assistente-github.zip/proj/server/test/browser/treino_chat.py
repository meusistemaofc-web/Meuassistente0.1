# Treino e Acompanhamento (telas): opção no botão ⚡ com ícone, conversa gradual (uma pergunta por vez) até o plano salvo,
# plano formatado (títulos, negrito, listas), "Meu treino" em conversa nova sem ⚡, registro de treino concluído, lembrete,
# aviso da notificação abrindo /?treino=hoje (envia "Treino de hoje" sozinho), painel do ⚡ (ativo, visível, ordem) e o
# Chat normal/Busca intactos; celular e computador.
# Servidor: PORT=4350 SQLITE_FILE=/tmp/ma-treino.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4350'; DBF='/tmp/ma-treino.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def db(sql,args=()):
    c=sqlite3.connect(DBF); r=c.execute(sql,args).fetchall(); c.commit(); c.close(); return r
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
def ultima(pg): return pg.evaluate("()=>{const b=[...document.querySelectorAll('.chat-scroll .msg-bubble')].pop();return b?b.innerText:''}")
def espera(pg,txt,t=20000):
    for _ in range(t//250):
        if txt in ultima(pg): return True
        pg.wait_for_timeout(250)
    return False
def envia(pg,txt):
    n=pg.locator('.chat-scroll .msg-bubble').count()
    pg.locator('textarea.composer-input').fill(txt); pg.wait_for_timeout(150); pg.locator('[aria-label="Enviar"]').click()
    for _ in range(80):
        if pg.locator('.chat-scroll .msg-bubble').count()>=n+2 and not pg.locator('.ma-atividade, [data-etapa]').count(): break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(600); return ultima(pg)
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    adm=b.new_context(base_url=BASE); A=adm.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Treino','email':'admin@treino.com','whatsapp':'+55 11 94444-7777',**U}).ok
    st=adm.storage_state()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':860},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,storage_state=st,is_mobile=mob,has_touch=mob,device_scale_factor=2 if mob else 1); pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_selector('.ma-modos-btn',timeout=10000); pg.wait_for_timeout(2500)
        pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo="treino"]',timeout=8000)
        k=pg.evaluate("()=>{const c=document.getElementById('ma-modos-card'),t=c.querySelector('[data-modo=\"treino\"]');return {txt:c.innerText,svg:!!t.querySelector('svg'),ids:[...c.querySelectorAll('[data-modo]')].map(x=>x.dataset.modo)}}")
        check(f'{nome}: ⚡ mostra "Treino e Acompanhamento" com ícone, junto do Chat normal e da Busca', 'Treino e Acompanhamento' in k['txt'] and k['svg'] and k['ids'][0]=='' and 'busca' in k['ids'], k)
        pg.screenshot(path=f'/tmp/e2e/treino_seletor_{nome}.png')
        if nome=='celular':
            pg.click('#ma-modos-card [data-modo="treino"]')
            check(f'{nome}: abre a conversa com uma pergunta (objetivo), sem questionário', espera(pg,'objetivo') and ultima(pg).count('?')<=2, ultima(pg))
            r=envia(pg,'quero emagrecer, já treino há um tempo'); check(f'{nome}: aproveita o que foi dito e pergunta os dias', 'dias' in r and 'objetivo' not in r.lower(), r)
            r=envia(pg,'4 dias'); check(f'{nome}: pergunta onde treina', any(w in r.lower() for w in ['onde','academia','casa']), r)
            r=envia(pg,'em casa com halteres'); check(f'{nome}: pergunta limitações', any(w in r.lower() for w in ['dor','lesão','limita']), r)
            r=envia(pg,'nenhuma')
            pg.wait_for_selector('.chat-scroll .ma-tr .ma-trx',timeout=15000); pg.wait_for_timeout(600)
            check(f'{nome}: plano salvo, resumo formatado (dias em lista, negrito) e ficha visual com os exercícios', 'Montei e salvei' in r and pg.locator('.chat-scroll .msg-bubble').last.locator('strong').count()>=2 and pg.locator('.chat-scroll .msg-bubble').last.locator('.ma-md-li').count()>=4 and pg.locator('.chat-scroll .ma-tr').last.locator('.ma-trx').count()>=3 and '**' not in r and '## ' not in r and '⟦' not in r, r[:300])
            check(f'{nome}: plano no banco com 4 dias', db("select count(*) from treino_planos where status='ativo'")[0][0]==1, db('select id,status from treino_planos'))
            pg.screenshot(path=f'/tmp/e2e/treino_plano_{nome}.png', full_page=False)
            r=envia(pg,'me lembre de treinar às 6h30'); check(f'{nome}: lembretes reais criados na Agenda', '06:30' in r and db("select count(*) from items where type='reminder'")[0][0]==4, r)
        else:
            # nova conversa, sem ⚡: o plano salvo volta pelo pedido
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            r=envia(pg,'Meu treino'); check(f'{nome}: "Meu treino" em conversa nova recupera o plano salvo', 'Plano de emagrecimento' in r and 'segunda' in r.lower(), r[:300])
            r=envia(pg,'Marque meu treino como concluído'); check(f'{nome}: registro do treino concluído', 'Registrado' in r and db('select count(*) from treino_sessoes')[0][0]==1, r)
            r=envia(pg,'como estou indo nos treinos?'); check(f'{nome}: histórico com números reais', 'Total registrado: 1' in r, r)
            pg.screenshot(path=f'/tmp/e2e/treino_historico_{nome}.png')
            # aviso da notificação: /?treino=hoje abre e pede o treino do dia uma única vez
            pg.goto('/?treino=hoje'); pg.wait_for_selector('textarea.composer-input',timeout=20000)
            ok=False
            for _ in range(60):
                us=pg.evaluate("()=>[...document.querySelectorAll('.chat-scroll .msg-bubble')].map(x=>x.innerText)")
                if any('Treino de hoje' in x for x in us) and len(us)>=2: ok=True; break
                pg.wait_for_timeout(250)
            pg.wait_for_timeout(1500)
            check(f'{nome}: aviso do lembrete abre o treino do dia (sem repetir) e limpa o endereço', ok and 'treino=' not in pg.url and any(w in ultima(pg) for w in ['Hoje (','descanso']) and pg.evaluate("()=>[...document.querySelectorAll('.chat-scroll .msg-bubble')].filter(x=>x.innerText.trim().startsWith('Treino de hoje')).length")==1, (pg.url,ultima(pg)[:200]))
            # Chat normal intacto
            pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(1500)
            r=envia(pg,'qual a capital da França?'); check(f'{nome}: Chat normal continua (sem entrar no modo)', 'Treino' not in r and pg.locator('.ma-modos-btn.on').count()==0, r[:200])
        c.close()
    # painel: Motor do chat → Modos do botão ⚡
    ca=b.new_context(viewport={'width':1280,'height':900},base_url=BASE,storage_state=st); pa=ca.new_page(); pa.on('pageerror',lambda e:errs.append(str(e)))
    pa.goto('/admin'); pa.wait_for_timeout(3000)
    if pa.locator('[data-modos-lista]').count()==0: aba(pa,'modos')
    pa.wait_for_selector('[data-modos-lista] [data-modo-id="treino"]',timeout=20000); pa.wait_for_timeout(500)
    ids=lambda: pa.evaluate("()=>[...document.querySelectorAll('[data-modos-lista] [data-modo-id]')].map(x=>x.dataset.modoId)")
    check('painel: lista os modos com Ativo, Visível e setas de ordem', set(ids())>={'busca','treino','marketing'} and pa.locator('[data-sw="ma_treino"]').get_attribute('aria-checked')=='true' and pa.locator('[data-sw="mv_treino"]').get_attribute('aria-checked')=='true' and pa.locator('[data-modos-lista] [data-mo]').count()==2*len(ids()), ids())
    pa.screenshot(path='/tmp/e2e/treino_painel.png')
    ordem0=ids(); i=ordem0.index('treino'); pa.click(f'[data-modos-lista] [data-mo="{i}:-1"]'); pa.wait_for_timeout(1200)
    check('painel: subir muda a ordem e grava', ids().index('treino')==i-1 and [m['id'] for m in A.get('/api/v2/modos').json()['modos']].index('treino')==i-1, (ordem0,ids()))
    pa.click('[data-sw="mv_treino"]'); pa.wait_for_timeout(1200)
    check('painel: ocultar tira do ⚡', not any(m['id']=='treino' for m in A.get('/api/v2/modos').json()['modos']) and A.post('/api/chat',data={'text':'Meu treino','conversationId':'7f7f7f7f-0000-4111-8222-000000000001'}).json()['assistantMessage']['content'].find('Plano de emagrecimento')>=0)
    pa.click('[data-sw="mv_treino"]'); pa.wait_for_timeout(1000)
    pa.click('[data-sw="ma_treino"]'); pa.wait_for_timeout(1200)
    r=A.post('/api/chat',data={'text':'Meu treino','conversationId':'7f7f7f7f-0000-4111-8222-000000000002'}).json()['assistantMessage']['content']
    check('painel: desativar tira do ⚡ e o pedido vai para o chat normal', pa.locator('[data-sw="ma_treino"]').get_attribute('aria-checked')=='false' and not any(m['id']=='treino' for m in A.get('/api/v2/modos').json()['modos']) and 'Plano de emagrecimento' not in r, r[:200])
    pa.click('[data-sw="ma_treino"]'); pa.wait_for_timeout(1200)
    check('painel: reativar volta ao ⚡', any(m['id']=='treino' for m in A.get('/api/v2/modos').json()['modos']))
    # Busca segue funcionando pelo ⚡
    r=A.post('/api/chat',data={'text':'⚡ Busca','conversationId':'7f7f7f7f-0000-4111-8222-000000000003','modo':'busca'}).json()['assistantMessage']['content']
    check('Busca de produtos continua ativando pelo ⚡', 'O que você procura' in r, r[:200])
    check('sem erros de página', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); _sys.exit(0 if all(res) else 1)
