# Ditado PROGRESSIVO (28/11), pela tela real do chat — o que mudou nesta correção:
#   1. iPhone/Safari NO NAVEGADOR usam o reconhecimento ao vivo do aparelho (antes iam sempre para a captura por trechos, e o
#      texto só aparecia depois de cada pausa + ida ao servidor): as palavras entram no campo enquanto a pessoa fala.
#   2. O trecho PROVISÓRIO (ainda sendo reconhecido) tem destaque discreto; o confirmado fica normal; ao parar o destaque some.
#   3. Estados claros dentro do campo: "Ativando microfone" → "Ouvindo"; o texto fica no campo para revisar e enviar.
#   4. App instalado no iPhone (onde o reconhecimento do aparelho não roda): captura por trechos COM parciais — o texto
#      aparece ANTES de a pessoa parar de falar (provisório), sem duplicar, e enviar durante a fala manda o texto consolidado.
#   5. Parciais não gastam a cota do ditado (nada de "Muitas gravações").
# Simulações: reconhecimento de fala do navegador (contrato da Web Speech API), microfone do Chromium com tom contínuo e um
# Whisper falso que demora 250 ms por pedido. O app e o servidor são os reais.
# Servidor: WHISPER_URL=http://127.0.0.1:4399 PORT=4410 SQLITE_FILE=/tmp/ma-ditprog.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
import json, math, struct, wave, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4410'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
IPHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1'
# ---------- Whisper falso: cada pedido devolve as palavras "faladas" até agora (parcial cresce; o final fecha o trecho) ----------
W = {'falado': [], 'parciais': 0, 'finais': 0}
class Wh(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); self.rfile.read(n); time.sleep(0.25)
        b = json.dumps({'text': ' '.join(W['falado'])}).encode()
        self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)
threading.Thread(target=HTTPServer(('127.0.0.1', 4399), Wh).serve_forever, daemon=True).start()
WAV = '/tmp/ditado_tom_longo.wav'
with wave.open(WAV, 'w') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
    w.writeframes(b''.join(struct.pack('<h', int(14000 * math.sin(2 * math.pi * 330 * i / 16000))) for i in range(16000 * 12)))
FAKE = r"""(()=>{window.__recs=[];window.__fila=[];window.__fin=false;
 class Rec{constructor(){this._w=[];this._f=0;this._ok=false;window.__recs.push(this)}
  start(){this._ok=true;window.__rec=this;setTimeout(()=>{this.onstart&&this.onstart();this._tick()},400)}
  _emit(){const fin=this._w.slice(0,this._f).join(' '),pro=this._w.slice(this._f).join(' '),r=[];if(fin)r.push({0:{transcript:fin},isFinal:true,length:1});if(pro)r.push({0:{transcript:pro},isFinal:false,length:1});window.__tRes=performance.now();this.onresult&&this.onresult({resultIndex:0,results:r})}
  _tick(){if(!this._ok)return;if(window.__fila.length){this._w.push(window.__fila.shift());this._emit()}else if(window.__fin&&this._f<this._w.length){window.__fin=false;this._f=this._w.length;this._emit()}setTimeout(()=>this._tick(),120)}
  stop(){this._f=this._w.length;if(this._w.length)this._emit();this._ok=false;setTimeout(()=>this.onend&&this.onend(),15)}
  abort(){this._ok=false;setTimeout(()=>this.onend&&this.onend(),15)}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec;
 const oq=navigator.permissions.query.bind(navigator.permissions);navigator.permissions.query=d=>d&&d.name==='microphone'?Promise.resolve({state:'granted',onchange:null}):oq(d)})()"""
with sync_playwright() as p:
    b = p.chromium.launch(args=['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', f'--use-file-for-fake-audio-capture={WAV}']); errs = []
    def abre(ctx):
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        return pg
    def espera(pg, cond, t=8000):
        fim = time.time() + t / 1000
        while time.time() < fim:
            if pg.evaluate(cond): return True
            pg.wait_for_timeout(50)
        return False
    TA = 'textarea[data-composer-input]'
    MIC = 'button[aria-label="Ditar mensagem"], button[aria-label="Pausar ditado"]'

    print('== iPhone no Safari (navegador): reconhecimento ao vivo do aparelho')
    C = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, user_agent=IPHONE, permissions=['microphone']); C.add_init_script(FAKE)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Iara Teste', 'whatsapp': '+55 11 95544-0101', 'email': 'iara.dp@t.com', **U}, headers={'X-Forwarded-For': '10.7.9.1'}).ok
    pg = abre(C); transc = []; envios = []
    pg.on('request', lambda r: transc.append(r.url) if '/api/transcribe' in r.url and 'diagnostico' not in r.url else None)
    pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
    pg.locator(MIC).first.click()
    ativ = espera(pg, "document.querySelector('[data-ditado-indicador]')?.dataset.ditadoIndicador==='ativando'", 1500)
    check('"Ativando microfone" aparece na hora do toque', ativ and 'Ativando microfone' in pg.inner_text('[data-ditado-indicador]'), pg.evaluate("document.querySelector('[data-ditado-indicador]')?.innerText"))
    check('depois: "Ouvindo"', espera(pg, "document.querySelector('[data-ditado-indicador]')?.dataset.ditadoIndicador==='ouvindo'", 3000))
    check('iPhone no navegador usa o reconhecimento do aparelho (nada vai para /api/transcribe)', pg.evaluate('window.__recs.length') == 1 and not transc, (pg.evaluate('window.__recs.length'), transc))
    lat = []
    for wd in ['quero', 'marcar', 'uma', 'consulta']:
        pg.evaluate(f"window.__fila.push('{wd}')"); t0 = time.time()
        espera(pg, f"document.querySelector('{TA}').value.toLowerCase().endsWith('{wd}')", 2000); lat.append(round((time.time() - t0) * 1000))
    check(f'palavras aparecem no campo enquanto se fala, uma a uma (latência {lat} ms)', pg.input_value(TA).lower() == 'quero marcar uma consulta' and max(lat) < 600, (pg.input_value(TA), lat))
    mk = lambda: pg.evaluate("document.querySelector('[data-ditado-provisorio]')?.textContent||''")
    check('trecho provisório com destaque discreto (camada atrás do campo)', espera(pg, "(document.querySelector('[data-ditado-provisorio]')?.textContent||'').toLowerCase()==='quero marcar uma consulta'", 1500), mk())
    est = pg.evaluate("(()=>{const m=document.querySelector('[data-ditado-provisorio]'),c=getComputedStyle(m),e=m.parentElement,t=document.querySelector('"+TA+"');return {cor:c.color,fundo:c.backgroundColor,atras:getComputedStyle(e).zIndex,pe:getComputedStyle(e).pointerEvents,mesmaFonte:getComputedStyle(e).fontSize===getComputedStyle(t).fontSize}})()")
    check('destaque não cobre nem muda o texto (texto transparente, fundo suave, atrás do campo, sem capturar toques)', 'rgba(0, 0, 0, 0)' in est['cor'] and est['fundo'] != 'rgba(0, 0, 0, 0)' and est['pe'] == 'none' and est['mesmaFonte'], est)
    pg.screenshot(path='/tmp/e2e/ditado_provisorio_iphone.png')
    pg.evaluate('window.__fin=true'); pg.wait_for_timeout(500)
    check('ao confirmar, o destaque sai do texto confirmado', mk() == '', mk())
    pg.evaluate("window.__fila.push('amanhã')"); espera(pg, f"document.querySelector('{TA}').value.endsWith('amanhã')", 2000); espera(pg, "(document.querySelector('[data-ditado-provisorio]')?.textContent||'')==='amanhã'", 1500)
    check('nova fala: só ela fica provisória; o confirmado continua normal', mk() == 'amanhã' and pg.input_value(TA).lower() == 'quero marcar uma consulta amanhã', (mk(), pg.input_value(TA)))
    pg.locator(MIC).first.click(); pg.wait_for_timeout(600)
    check('parar: o texto fica no campo para revisão, sem destaque e sem indicador', pg.input_value(TA).lower() == 'quero marcar uma consulta amanhã' and mk() == '' and pg.locator('[data-ditado-indicador]').count() == 0, (pg.input_value(TA), mk(), pg.locator('[data-ditado-indicador]').count()))
    pg.fill(TA, ''); pg.locator(MIC).first.click(); espera(pg, "document.querySelector('[data-ditado-indicador]')?.dataset.ditadoIndicador==='ouvindo'", 3000)
    for wd in ['me', 'lembra', 'de', 'ligar']: pg.evaluate(f"window.__fila.push('{wd}')")
    espera(pg, f"document.querySelector('{TA}').value.toLowerCase()==='me lembra de ligar'", 3000); n0 = len(envios)
    pg.locator('[aria-label="Enviar"]').click(); pg.wait_for_timeout(1500)
    env = [e for e in envios[n0:] if 'me lembra de ligar' in e.lower()]
    check('enviar com o microfone ativo: encerra a escuta e envia o texto consolidado uma vez', len(env) == 1 and pg.evaluate('window.__recs.every(r=>!r._ok)'), envios[n0:])
    C.close()

    print('== app instalado no iPhone: captura por trechos com parciais')
    C = b.new_context(base_url=BASE, viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, user_agent=IPHONE, permissions=['microphone'])
    C.add_init_script(FAKE); C.add_init_script("Object.defineProperty(navigator,'standalone',{get:()=>true})")
    C.add_init_script("(()=>{window.__tx=[];const of=window.fetch;window.fetch=function(u,o){try{if(String(u).endsWith('/api/transcribe')&&o&&o.body instanceof FormData)window.__tx.push(o.body.get('parcial')==='1'?'parcial':'final')}catch(e){}return of.apply(this,arguments)}})()")
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Ravi Teste', 'whatsapp': '+55 11 95544-0202', 'email': 'ravi.dp@t.com', **U}, headers={'X-Forwarded-For': '10.7.9.2'}).ok
    pg = abre(C); pedidos = []; envios = []
    pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
    W['falado'] = []
    pg.locator(MIC).first.click()
    check('app instalado: "Ouvindo" com a captura por trechos (reconhecimento do aparelho não é usado)', espera(pg, "document.querySelector('[data-ditado-indicador]')?.dataset.ditadoIndicador==='ouvindo'", 5000) and pg.evaluate('window.__recs.length') == 0)
    W['falado'] = ['preciso', 'pagar']; t0 = time.time()
    ok1 = espera(pg, f"document.querySelector('{TA}').value.toLowerCase().includes('preciso pagar')", 5000); t1 = round(time.time() - t0, 1); pedidos = pg.evaluate('window.__tx')
    check(f'o texto aparece ANTES de parar de falar (parcial em {t1} s, com o tom ainda tocando)', ok1 and t1 < 2.5 and 'parcial' in pedidos and 'final' not in pedidos, (pg.input_value(TA), t1, pedidos[:6]))
    check('trecho em andamento marcado como provisório', espera(pg, "!!document.querySelector('[data-ditado-provisorio]')", 1500), pg.evaluate("document.querySelector('[data-ditado-provisorio]')?.textContent"))
    W['falado'] = ['preciso', 'pagar', 'a', 'conta', 'de', 'luz']
    check('o texto provisório cresce enquanto a pessoa continua falando', espera(pg, f"document.querySelector('{TA}').value.toLowerCase().includes('conta de luz')", 5000), pg.input_value(TA))
    pg.screenshot(path='/tmp/e2e/ditado_parcial_app_iphone.png')
    n0 = len(envios); pg.locator('[aria-label="Enviar"]').click()
    espera(pg, "document.querySelectorAll('.chat-scroll .msg-bubble').length>=1", 8000); pg.wait_for_timeout(1500)
    env = [e for e in envios[n0:] if 'conta de luz' in e.lower()]
    tx = json.loads(env[0]).get('text', '').lower() if env else ''
    pedidos = pg.evaluate('window.__tx')
    check('enviar durante a fala: transcreve o último trecho e envia o texto consolidado, uma vez, sem palavras repetidas', len(env) == 1 and tx.count('preciso pagar') == 1 and tx.endswith('conta de luz') and 'final' in pedidos, (envios[n0:], pedidos[-3:]))
    check('parciais não esgotam a cota (nenhum "Muitas gravações")', 'Muitas gravações' not in pg.inner_text('body') and pedidos.count('parcial') >= 2, pedidos)
    C.close()

    print('== servidor: parciais com cota própria')
    C = b.new_context(base_url=BASE); R = C.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Lia Teste', 'whatsapp': '+55 11 95544-0303', 'email': 'lia.dp@t.com', **U}, headers={'X-Forwarded-For': '10.7.9.3'}).ok
    with open(WAV, 'rb') as f: audio = f.read()[:16000 * 2 * 2 + 44]
    W['falado'] = ['teste', 'de', 'cota']
    rs = [R.post('/api/transcribe', multipart={'audio': {'name': 'fala.wav', 'mimeType': 'audio/wav', 'buffer': audio}, 'parcial': '1', 'sessao': 'cota1', 'parte': '0'}) for _ in range(130)]
    check('130 parciais da mesma fala: todas respondem (sem 429)', all(r.status == 200 for r in rs) and rs[0].json().get('parcial') is True and rs[0].json().get('text') == 'teste de cota', [r.status for r in rs if r.status != 200][:3])
    fin = R.post('/api/transcribe', multipart={'audio': {'name': 'fala.wav', 'mimeType': 'audio/wav', 'buffer': audio}, 'sessao': 'cota1', 'parte': '0'})
    check('depois delas, o trecho final ainda é transcrito (cota do ditado intacta)', fin.status == 200 and fin.json().get('text') == 'teste de cota', fin.status)
    sil = R.post('/api/transcribe', multipart={'audio': {'name': 'fala.wav', 'mimeType': 'audio/wav', 'buffer': audio[:44] + b'\x00' * 32000}, 'parcial': '1', 'sessao': 'cota1'})
    check('parcial de silêncio: texto vazio, sem erro', sil.status == 200 and sil.json().get('text') == '', sil.status)
    C.close()
    check('sem erros de JavaScript', not [e for e in errs if e != 'Event' and '#418' not in e], errs[:3])  # #418: aviso de hidratação já existente
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
