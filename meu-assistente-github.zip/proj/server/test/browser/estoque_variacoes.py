# Estoque por variação, de ponta a ponta pela tela (celular): loja pública (/x/empresa/:id) e agente de atendimento (/a/:id).
# Brinco Argola: Dourado · 8mm (2), Prata · 8mm (6), Rosé · 8mm (0 = esgotada); Pulseira sem variações (3); Chaveiro sem
# controle de estoque. Confere: limite exato de cada variação, "+" desabilitado no limite com a mensagem "Limite de N unidades
# disponíveis", troca de variação ajustando a quantidade, soma no carrinho, carrinho ajustado quando o estoque cai, tentativa de
# passar do estoque direto na API, pedido final e o estoque baixado; o mesmo no agente.
# Servidor: PORT=4352 SQLITE_FILE=/tmp/ma-estv.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import io, json, sys, sqlite3, datetime, base64, re
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4352'; DBF = '/tmp/ma-estv.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor):
    b = io.BytesIO(); Image.new('RGB', (120, 120), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
def sql(q, *a):
    db = sqlite3.connect(DBF); db.execute(q, a); db.commit(); db.close()
def val(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchone(); db.close(); return r[0] if r else None
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dona Vera', 'whatsapp': '+55 11 94444-4321', 'email': 'vera.estv@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Joias da Vera', 'categoria': 'Acessórios', 'titulo': 'Joias', 'texto': 'Joias', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'pix': True, 'chavePix': 'vera@pix.com', 'dinheiro': True}, 'entrega': {'retirada': True, 'entrega': False}}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Brinco Argola', 'categoria': 'Brincos', 'variantes': [
        {'cor': 'Dourado', 'tamanho': '8mm', 'preco': 59.9, 'fotos': [img('gold')], 'estoque': 2},
        {'cor': 'Prata', 'tamanho': '8mm', 'preco': 49.9, 'fotos': [img('silver')], 'estoque': 6},
        {'cor': 'Rosé', 'tamanho': '8mm', 'preco': 64.9, 'fotos': [img('pink')], 'estoque': 0}]}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Pulseira', 'categoria': 'Pulseiras', 'preco': 30, 'fotos': [img('navy')], 'estoque': 3}).ok
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Chaveiro', 'categoria': 'Pulseiras', 'preco': 10, 'fotos': [img('teal')]}).ok
    items = R.get(f'/api/v2/ads/{ID}/products').json()['items']
    br = next(x for x in items if x['nome'] == 'Brinco Argola'); pu = next(x for x in items if x['nome'] == 'Pulseira'); ch = next(x for x in items if x['nome'] == 'Chaveiro')
    VID = {v['cor']: v['id'] for v in br['variantes']}
    cad0 = val('select group_concat(data, "|") from product_variants where product_id=?', br['id'])
    C = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True)
    assert C.request.post('/api/auth', data={'action': 'signup', 'name': 'Bia Cliente', 'whatsapp': '+55 11 95555-0202', 'email': 'bia.estv@t.com', **U}, headers={'X-Forwarded-For': '10.6.7.7'}).ok
    pc = C.new_page(); pc.on('pageerror', lambda e: errs.append(str(e)))
    pc.goto(f'/x/empresa/{ID}'); pc.wait_for_selector('[data-prod]', timeout=20000); pc.wait_for_timeout(800)
    qtd = lambda: int(pc.inner_text('.ma-sheet-acoes .glass-inset span'))
    lim = lambda: N(pc.inner_text('[data-limite]')) if pc.locator('[data-limite]').count() else ''
    mais = lambda: pc.locator('#pp')
    def abrir():
        pc.locator(f'[data-prod="{br["id"]}"]').click(); pc.wait_for_selector('[data-vgrupo=cor]', timeout=8000)
    def cor(c): pc.click(f'[data-vgrupo=cor] [data-vv="{c}"]'); pc.wait_for_timeout(200)
    print('== loja: detalhe do produto')
    abrir(); cor('Dourado')
    check('Dourado · 8mm: mostra "Limite de 2 unidades disponíveis"', lim() == 'Limite de 2 unidades disponíveis', lim())
    mais().click(); pc.wait_for_timeout(150)
    check('Dourado: chega a 2 e o "+" fica desabilitado', qtd() == 2 and mais().is_disabled(), (qtd(), mais().is_disabled()))
    pc.evaluate("document.querySelector('#pp').disabled=false;document.querySelector('#pp').click()"); pc.wait_for_timeout(200)
    check('Dourado: forçar o "+" não passa de 2', qtd() == 2, qtd())
    cor('Prata')
    check('trocar para Prata usa o estoque da Prata (6), sem herdar o do Dourado', lim() == 'Limite de 6 unidades disponíveis' and qtd() == 2 and not mais().is_disabled(), (lim(), qtd()))
    for _ in range(6):
        if not mais().is_disabled(): mais().click(); pc.wait_for_timeout(80)
    check('Prata: chega a 6 e o "+" desabilita (não deixa 7)', qtd() == 6 and mais().is_disabled() and 'Adicionar' in pc.inner_text('#padd'), (qtd(), pc.inner_text('#padd')))
    pc.screenshot(path='/tmp/e2e/estv_prata_limite.png')
    cor('Dourado')
    check('voltar para Dourado ajusta a quantidade ao limite dele (6 → 2)', qtd() == 2 and mais().is_disabled(), qtd())
    cor('Rosé')
    check('Rosé (estoque 0): "Indisponível" e adicionar desabilitado', 'Indisponível' in pc.inner_text('[data-disp]') and pc.locator('#padd').is_disabled() and mais().is_disabled(), (pc.inner_text('[data-disp]'), pc.inner_text('#padd')))
    cor('Dourado'); mais().click(); pc.wait_for_timeout(150); pc.click('#padd'); pc.wait_for_timeout(900)
    abrir(); cor('Dourado')
    check('Dourado de novo: já tem as 2 no pedido → "Limite atingido" e não adiciona mais', pc.locator('#padd').is_disabled() and 'Limite atingido' in pc.inner_text('#padd') and 'já tem as 2 unidades' in lim(), (pc.inner_text('#padd'), lim()))
    cor('Prata'); [mais().click() or pc.wait_for_timeout(60) for _ in range(6) if not mais().is_disabled()]
    check('Prata continua independente (6) com o Dourado no carrinho', qtd() == 6 and lim() == 'Limite de 6 unidades disponíveis', (qtd(), lim()))
    pc.click('#padd'); pc.wait_for_timeout(900)
    abrir(); cor('Prata'); pc.wait_for_timeout(100)
    check('Prata adicionada de novo: soma com o carrinho e não deixa passar de 6', pc.locator('#padd').is_disabled() and 'já tem as 6 unidades' in lim(), lim())
    fechar = lambda: (pc.click('.ma-sheet-x') if pc.locator('.ma-sheet-x').count() else None, pc.wait_for_timeout(300))
    fechar()
    print('== loja: produto sem variações')
    for _ in range(4): pc.click(f'[data-add="{pu["id"]}"]'); pc.wait_for_timeout(450)
    for _ in range(5): pc.click(f'[data-add="{ch["id"]}"]'); pc.wait_for_timeout(250)
    print('== loja: carrinho')
    pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000); pc.wait_for_timeout(500)
    linha = lambda k: pc.locator(f'[data-cart-item="{k}"]')
    nq = lambda k: int(linha(k).locator('[data-cq-n]').inner_text()) if linha(k).count() else -1
    kD, kP = f'{br["id"]}-{VID["Dourado"]}', f'{br["id"]}-{VID["Prata"]}'
    check('carrinho: Dourado 2 e Prata 6 como itens separados, "+" desabilitado em ambos', nq(kD) == 2 and nq(kP) == 6 and linha(kD).locator('[data-cq="1"]').is_disabled() and linha(kP).locator('[data-cq="1"]').is_disabled(), (nq(kD), nq(kP)))
    check('carrinho mostra o limite da variação', 'Limite de 2 unidades disponíveis' in N(linha(kD).inner_text()) and 'Limite de 6 unidades disponíveis' in N(linha(kP).inner_text()))
    check('Pulseira (sem variações, estoque 3): a 4ª não entrou', nq(str(pu['id'])) == 3, nq(str(pu['id'])))
    check('Chaveiro (sem controle de estoque) aceita qualquer quantidade', nq(str(ch['id'])) == 5, nq(str(ch['id'])))
    pc.screenshot(path='/tmp/e2e/estv_carrinho.png', full_page=True)
    # tentativa de passar do estoque direto na API (sem a tela)
    r = pc.evaluate(f"""fetch('/api/v2/businesses/{ID}/orders',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{itens:[{{pid:{br['id']},vid:{VID['Prata']},qtd:7}}],modo:'retirada',pagamento:'dinheiro',telefone:'11988887777'}})}}).then(async r=>[r.status,await r.json()])""")
    check('API: pedido de 7 Prata (estoque 6) é recusado pelo servidor', r[0] == 409 and r[1].get('code') == 'sem_estoque' and r[1].get('info', {}).get('disponivel') == 6, r)
    r = pc.evaluate(f"""fetch('/api/v2/businesses/{ID}/orders',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{itens:[{{pid:{br['id']},vid:{VID['Dourado']},qtd:2}},{{pid:{br['id']},vid:{VID['Dourado']},qtd:1,obs:'x'}}],modo:'retirada',pagamento:'dinheiro',telefone:'11988887777'}})}}).then(async r=>[r.status,await r.json()])""")
    check('API: duas linhas do Dourado somando 3 (estoque 2) são recusadas', r[0] == 409, r)
    check('estoque intacto depois das recusas', val('select stock from product_variants where id=?', VID['Prata']) == 6 and val('select stock from product_variants where id=?', VID['Dourado']) == 2)
    # o estoque cai depois que o item já está no carrinho: ao abrir de novo, o carrinho é ajustado e o cliente é avisado
    sql('update product_variants set stock=3 where id=?', VID['Prata'])
    fechar()
    pc.locator('button:has-text("Ver pedido")').click(); pc.wait_for_selector('[data-checkout]', timeout=8000); pc.wait_for_timeout(500)
    av = N(pc.inner_text('[data-estoque-aviso]')) if pc.locator('[data-estoque-aviso]').count() else ''
    check('estoque da Prata caiu para 3: carrinho ajustado (6 → 3) e aviso claro', nq(kP) == 3 and 'Prata' in av and 'agora há 3 unidades' in av, (nq(kP), av))
    pc.screenshot(path='/tmp/e2e/estv_aviso.png', full_page=True)
    # finalizar: o pedido passa e o estoque de cada variação baixa só o que foi comprado
    pc.fill('#czap', '11988887777') if pc.locator('#czap').count() and not pc.input_value('#czap') else None
    if pc.locator('[data-pg=dinheiro]').count(): pc.click('[data-pg=dinheiro]'); pc.wait_for_timeout(200)
    pc.click('#cgo'); pc.wait_for_timeout(2500)
    o = C.request.get('/api/v2/orders/mine').json()['items']
    o = o[0] if o else {}
    q = {(i.get('variante') or i['nome']): i['qtd'] for i in o.get('itens', [])}
    check('pedido finalizado com Dourado 2, Prata 3, Pulseira 3', q.get('Dourado · 8mm') == 2 and q.get('Prata · 8mm') == 3 and q.get('Pulseira') == 3, q)
    check('estoques baixados por variação (Dourado 0, Prata 0, Rosé 0, Pulseira 0) e nunca negativos', [val('select stock from product_variants where id=?', VID[c]) for c in ('Dourado', 'Prata', 'Rosé')] == [0, 0, 0] and val('select stock from products where id=?', pu['id']) == 0 and val('select stock from products where id=?', br['id']) is None)
    # ---------- agente de atendimento ----------
    print('== agente de atendimento')
    sql('update product_variants set stock=2 where id=?', VID['Dourado']); sql('update product_variants set stock=6 where id=?', VID['Prata'])
    assert R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    d = json.loads(val('select data from businesses where id=?', ID)); d.setdefault('agente', {})['expiresAt'] = (datetime.datetime.now(datetime.UTC).replace(tzinfo=None) + datetime.timedelta(days=30)).isoformat() + 'Z'; sql('update businesses set data=? where id=?', json.dumps(d), ID)
    G = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); pa = G.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    pa.goto(f'/a/{ID}'); pa.wait_for_selector('#acts button', timeout=15000)
    if not pa.locator('#acts [data-a=cat]').count(): pa.click('#acts [data-a=mais]')
    pa.click('#acts [data-a=cat]'); pa.wait_for_selector('.pc', timeout=8000); pa.wait_for_timeout(400)
    if pa.locator('.opt [data-c="Brincos"]').count(): pa.click('.opt [data-c="Brincos"]'); pa.wait_for_timeout(300)
    def adet():
        pa.locator('.pc', has_text='Brinco Argola').last.locator('[data-pid]').click(); pa.wait_for_selector('.det [data-vgrupo=cor]', timeout=8000)
    acor = lambda c: (pa.click(f'.det [data-vgrupo=cor] [data-vv="{c}"]'), pa.wait_for_timeout(200))
    aq = lambda: int(pa.inner_text('.det [data-q="1"] >> xpath=preceding-sibling::b[1]'))
    amais = lambda: pa.locator('.det [data-q="1"]')
    alim = lambda: N(pa.inner_text('.det [data-limite]')) if pa.locator('.det [data-limite]').count() else ''
    adet(); acor('Dourado'); amais().click(); pa.wait_for_timeout(150)
    check('agente: Dourado chega a 2, "+" desabilitado e "Limite de 2 unidades disponíveis"', aq() == 2 and amais().is_disabled() and alim() == 'Limite de 2 unidades disponíveis', (aq(), alim()))
    acor('Prata'); [amais().click() or pa.wait_for_timeout(60) for _ in range(6) if not amais().is_disabled()]
    check('agente: Prata independente, para em 6', aq() == 6 and amais().is_disabled() and alim() == 'Limite de 6 unidades disponíveis', (aq(), alim()))
    acor('Rosé')
    check('agente: Rosé esgotada → Indisponível', pa.locator('.det [data-go]').is_disabled() and 'Indisponível' in pa.inner_text('.det [data-go]'))
    acor('Dourado'); amais().click(); pa.wait_for_timeout(150); pa.click('.det [data-go]'); pa.wait_for_timeout(900)
    adet(); acor('Dourado')
    check('agente: Dourado de novo → "Limite atingido" (2 já no carrinho)', pa.locator('.det [data-go]').is_disabled() and 'Limite atingido' in pa.inner_text('.det [data-go]'), pa.inner_text('.det [data-go]'))
    pa.click('.det .det-x') if pa.locator('.det .det-x').count() else None; pa.wait_for_timeout(300)
    sql('update product_variants set stock=1 where id=?', VID['Dourado'])  # estoque caiu com o item no carrinho
    pa.locator('button:has-text("Ver carrinho e finalizar")').last.click(); pa.wait_for_timeout(1200)
    ct = N(pa.inner_text('body'))
    check('agente: carrinho ajustado (2 → 1) e o cliente é avisado', 'agora há 1 unidade disponível' in ct and '1× Brinco Argola' in ct, ct[-300:])
    check('cadastro das variações intacto (preços, fotos, atributos)', val('select group_concat(data, "|") from product_variants where product_id=?', br['id']) == cad0)
    check('sem rolagem horizontal (loja e agente)', pc.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and pa.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
