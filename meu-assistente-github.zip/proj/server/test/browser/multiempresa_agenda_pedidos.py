# Agenda e Pedidos para quem tem várias empresas na conta. Cobre:
#   - Pedidos (Sua empresa → Pedidos): seletor "Todas as empresas" ou uma empresa; em "Todas", grupos separados por empresa
#     (logo e nome); etiqueta discreta em cada card; detalhes e ações sempre na empresa do próprio pedido; escolha lembrada.
#   - A segunda empresa é de OUTRA conta, vinculada pelo e-mail e senha dela (o caso real de várias empresas na conta).
#   - Agenda (lista e calendário): etiqueta da empresa em cada compromisso ligado a uma empresa; filtro Todas / empresa /
#     Pessoais; seções por empresa.
#   - Isolamento: compromisso apontando para empresa de OUTRA conta não mostra essa empresa; pedidos de outra empresa → 403/404.
#   - Celular e computador, sem rolagem lateral.
# Servidor: PORT=4400 SQLITE_FILE=/tmp/ma-multi.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4400'; DBF = '/tmp/ma-multi.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
ABERTO = {'modo': 'aberto', 'dias': {k: {'ativo': True, 'abre': '00:00', 'fecha': '23:59'} for k in ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']}}
def ativar(ID, logo=None):
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0])
    if logo: d['logo'] = logo
    db("update businesses set data=?, status='ativo', expires_at=? where id=?", (json.dumps(d), (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat(), ID))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Multi', 'whatsapp': '+55 11 94444-0001', 'email': 'admin.multi@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Dono Duas Lojas', 'whatsapp': '+55 85 95555-0002', 'email': 'dono.multi@t.com', **U}, headers={'X-Forwarded-For': '10.10.0.2'}).ok
    PZ = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Pizzaria Forno', 'categoria': 'Pizzaria', 'titulo': 't', 'texto': 'x', 'zap': '5585955550000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}).json()['items'][0]['id']
    # a segunda empresa é de outra conta (Bia) e foi VINCULADA à conta do dono (e-mail e senha da Bia) — o caso real de várias empresas
    BI = b.new_context(base_url=BASE); RB = BI.request
    assert RB.post('/api/auth', data={'action': 'signup', 'name': 'Bia Studio', 'whatsapp': '+55 85 95555-0009', 'email': 'bia.multi@t.com', **U}, headers={'X-Forwarded-For': '10.10.0.9'}).ok
    ST = RB.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Studio Beleza', 'categoria': 'Salão', 'titulo': 't', 'texto': 'x', 'zap': '5585955550001', 'tipo': 'servicos', 'endereco': 'Rua B, 20'}).json()['items'][0]['id']
    ativar(PZ, LOGO); ativar(ST)
    assert R.put(f'/api/v2/ads/{PZ}', data={'horarioCfg': ABERTO}).ok and RB.put(f'/api/v2/ads/{ST}', data={'horarioCfg': ABERTO}).ok
    tk = R.post('/api/v2/vinculos/autenticar', data={'email': 'bia.multi@t.com', 'password': U['password']}).json()['ticket']
    assert R.post('/api/v2/vinculos', data={'ticket': tk, 'businessIds': [ST]}).ok
    pid = [x for x in R.post(f'/api/v2/ads/{PZ}/products', data={'nome': 'Pizza grande', 'preco': 50, 'tipo': 'produto', 'fotos': [IMG]}).json()['items'] if x['nome'] == 'Pizza grande'][0]['id']
    sid = [x for x in RB.post(f'/api/v2/ads/{ST}/products', data={'tipo': 'servico', 'nome': 'Escova', 'preco': 70, 'modoPreco': 'fixo', 'duracao': 45, 'fotos': [IMG]}).json()['items'] if x['nome'] == 'Escova'][0]['id']
    Cc = b.new_context(base_url=BASE); C = Cc.request
    assert C.post('/api/auth', data={'action': 'signup', 'name': 'Cliente Ana', 'whatsapp': '+55 85 96666-0003', 'email': 'ana.multi@t.com', **U}, headers={'X-Forwarded-For': '10.10.0.3'}).ok
    for _ in range(2): assert C.post(f'/api/v2/businesses/{PZ}/orders', data={'itens': [{'pid': pid, 'qtd': 1, 'escolhas': {}}], 'modo': 'retirada', 'pagamento': 'dinheiro'}).ok
    dia = (datetime.date.today() + datetime.timedelta(days=2)).isoformat()
    hs = C.get(f'/api/v2/businesses/{ST}/slots?servico={sid}&data={dia}').json()['horarios']; rb = C.post(f'/api/v2/businesses/{ST}/bookings', data={'servico': sid, 'data': dia, 'hora': hs[0]}); assert rb.ok, rb.text()
    # agenda do dono: retirada agendada da Pizzaria (o vínculo com a empresa é o mesmo que o agendamento grava: data.businessId)
    # e um compromisso pessoal no mesmo dia
    pa = R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': 'Retirada pizza agendada', 'date': dia, 'time': '12:00'}}).json()['item']['id']
    dd = json.loads(db('select data from items where id=?', (pa,))[0][0]); dd.update({'businessId': PZ, 'source': 'pedido'}); db('update items set data=? where id=?', (json.dumps(dd), pa))
    assert R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': 'Dentista', 'date': dia, 'time': '18:00'}}).ok
    # outra conta com empresa própria; um compromisso do dono "apontando" para ela não pode revelar o nome dela
    O = b.new_context(base_url=BASE); RO = O.request
    assert RO.post('/api/auth', data={'action': 'signup', 'name': 'Outra Dona', 'whatsapp': '+55 85 97777-0004', 'email': 'outra.multi@t.com', **U}, headers={'X-Forwarded-For': '10.10.0.4'}).ok
    OUT = RO.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Empresa Secreta', 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5585977770000', 'tipo': 'produtos', 'endereco': 'Rua C'}).json()['items'][0]['id']
    it = R.post('/api/items', data={'action': 'create', 'type': 'appointment', 'data': {'title': 'Reunião X', 'date': dia, 'time': '20:00'}}).json()['item']['id']
    dd = json.loads(db('select data from items where id=?', (it,))[0][0]); dd['businessId'] = OUT; db('update items set data=? where id=?', (json.dumps(dd), it))
    # API
    ag = R.get('/api/agenda').json()['appointments']; byt = {a['title']: a for a in ag}
    check('API agenda: compromisso da Pizzaria identificado (nome, id e logo)', byt['Retirada pizza agendada'].get('empresa', {}).get('nome') == 'Pizzaria Forno' and byt['Retirada pizza agendada']['empresa']['logo'], [(a['title'], a.get('empresa')) for a in ag])
    agb = RB.get('/api/agenda').json()['appointments']
    check('API agenda (dona do Studio): agendamento real do cliente identificado com o Studio', any(a.get('empresa') and a['empresa']['nome'] == 'Studio Beleza' and 'Escova' in a['title'] for a in agb), [(a['title'], a.get('empresa')) for a in agb])
    check('API agenda: compromisso pessoal sem empresa', byt['Dentista'].get('empresa') is None)
    check('isolamento: empresa de outra conta não é revelada', byt['Reunião X'].get('empresa') is None and byt['Reunião X'].get('businessId') is None and 'Empresa Secreta' not in json.dumps(ag), byt['Reunião X'])
    cal = R.get(f'/api/v2/compromissos?de={dia}&ate={dia}').json()['compromissos']
    check('API calendário: mesma identificação', any(a.get('empresa') and a['empresa']['nome'] == 'Pizzaria Forno' for a in cal) and all('Empresa Secreta' not in json.dumps(a) for a in cal))
    check('isolamento: pedidos de empresa de outra conta (sem vínculo) são recusados, mesmo pedindo pelo cabeçalho', R.get(f'/api/v2/ads/{OUT}/orders').status in (403, 404) and R.get(f'/api/v2/ads/{OUT}/orders', headers={'X-MA-Empresa': str(OUT)}).status in (403, 404))
    ped_pz = R.get(f'/api/v2/ads/{PZ}/orders').json()['items']; ped_st = R.get(f'/api/v2/ads/{ST}/orders', headers={'X-MA-Empresa': str(ST)}).json()['items']
    check('pedidos ficam na empresa certa (2 na Pizzaria, 1 agendamento no Studio)', len(ped_pz) == 2 and len(ped_st) == 1 and ped_st[0]['tipo'] == 'agendamento', (len(ped_pz), len(ped_st)))
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob)
        assert c.request.post('/api/auth', data={'action': 'login', 'email': 'dono.multi@t.com', 'password': U['password']}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept('Sem massa'))
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]', timeout=20000); pg.wait_for_timeout(600)
        pg.evaluate("localStorage.removeItem('ma-ped-emp')")
        pg.click('.ma-nav [data-nav=pedidos]'); pg.wait_for_selector('[data-ped-emp]', timeout=15000); pg.wait_for_timeout(500)
        ativo = pg.locator('[data-ped-emp]').input_value(); n1 = pg.locator('[data-ped]').count()
        check(f'{nome}: seletor de empresa aparece (2 empresas) e começa na empresa ativa', ativo in (str(PZ), str(ST)) and pg.locator('[data-ped-emp] option').count() == 3, ativo)
        alvo = ST if ativo == str(PZ) else PZ
        bids = set(pg.locator('[data-ped]').evaluate_all('es=>es.map(e=>e.dataset.pedBid)'))
        check(f'{nome}: empresa específica mostra só os pedidos dela', bids == {ativo} and n1 == (2 if ativo == str(PZ) else 1), (bids, n1))
        pg.select_option('[data-ped-emp]', 'todas'); pg.wait_for_selector('[data-ped-grupo]', timeout=15000); pg.wait_for_timeout(500)
        grp = pg.locator('[data-ped-grupo]').evaluate_all('es=>es.map(e=>[e.dataset.pedGrupo,e.querySelectorAll("[data-ped]").length,[...e.querySelectorAll("[data-ped]")].every(x=>x.dataset.pedBid===e.dataset.pedGrupo),e.innerText.split("\\n")[0]])')
        check(f'{nome}: "Todas" separa por empresa (cada grupo só com os seus)', sorted((g[0], g[1]) for g in grp) == sorted([(str(PZ), 2), (str(ST), 1)]) and all(g[2] for g in grp), grp)
        check(f'{nome}: cabeçalho do grupo com logo (Pizzaria) e nome', pg.locator(f'[data-ped-grupo="{PZ}"] img').count() >= 1 and 'Pizzaria Forno' in pg.inner_text(f'[data-ped-grupo="{PZ}"]') and 'Studio Beleza' in pg.inner_text(f'[data-ped-grupo="{ST}"]'))
        tags = pg.locator('[data-ped-emp-tag]').evaluate_all('es=>es.map(e=>[e.dataset.pedEmpTag,e.querySelector(".truncate").textContent.trim(),e.closest("[data-ped]").dataset.pedBid])')
        check(f'{nome}: etiqueta discreta da empresa em cada card, coerente com o pedido', len(tags) == 3 and all(t[0] == t[2] for t in tags) and {t[1] for t in tags} == {'Pizzaria Forno', 'Studio Beleza'}, tags)
        pg.locator(f'[data-ped-grupo="{ST}"] [data-odet]').first.click(); pg.wait_for_selector('[data-pedido-det]', timeout=5000)
        det = pg.locator('[data-pedido-det]')
        check(f'{nome}: detalhes abrem o pedido da empresa certa (Studio, agendamento)', det.get_attribute('data-pedido-emp') == str(ST) and 'Studio Beleza' in det.inner_text() and 'Escova' in det.inner_text() and 'Agendamento' in det.inner_text())
        pg.locator('.ma-sheet-x').click(); pg.wait_for_timeout(300)
        # ação no grupo da Pizzaria: altera o pedido CERTO na empresa CERTA
        if nome == 'celular':
            oid = pg.locator(f'[data-ped-grupo="{PZ}"] [data-ped]').first.get_attribute('data-ped')
            pg.locator(f'[data-ped-grupo="{PZ}"] [data-os="aceito"]').first.click(); pg.wait_for_selector('[data-ped-grupo]', timeout=15000); pg.wait_for_timeout(600)
            st = {o['id']: o['status'] for o in R.get(f'/api/v2/ads/{PZ}/orders').json()['items']}
            check('celular: ação "Aceitar" vale para o pedido da Pizzaria (o do Studio não muda)', st[int(oid)] == 'aceito' and R.get(f'/api/v2/ads/{ST}/orders', headers={'X-MA-Empresa': str(ST)}).json()['items'][0]['status'] != 'aceito', st)
            check('celular: depois da ação, continua em "Todas as empresas" (escolha lembrada)', pg.locator('[data-ped-emp]').input_value() == 'todas')
            pg.screenshot(path='/tmp/e2e/multi_pedidos_celular.png', full_page=False)
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: Pedidos sem rolagem lateral', ow <= 1, ow)
        pg.select_option('[data-ped-emp]', str(alvo)); pg.wait_for_timeout(1500)
        bids = set(pg.locator('[data-ped]').evaluate_all('es=>es.map(e=>e.dataset.pedBid)'))
        check(f'{nome}: escolher outra empresa mostra só os dela', bids == {str(alvo)} and pg.locator('[data-ped-grupo]').count() == 0, bids)
        # Agenda (lista do app): etiquetas, filtro e seções por empresa
        pg.evaluate("localStorage.removeItem('ma-ag-emp');localStorage.removeItem('ma-cal-emp')")
        pg.goto('/agenda?tab=compromissos'); pg.wait_for_selector('[data-ag-emps]', timeout=20000); pg.wait_for_timeout(500)
        fs = pg.locator('[data-ag-emp-f]').evaluate_all('es=>es.map(e=>e.dataset.agEmpF)')
        check(f'{nome}: Agenda — filtro Todas / Pizzaria / Pessoais', fs == ['todas', str(PZ), 'pessoal'], fs)
        gr = pg.locator('[data-ag-grupo]').evaluate_all('es=>es.map(e=>[e.dataset.agGrupo,e.textContent])')
        check(f'{nome}: Agenda — "Todas" com seções por empresa (pessoais por último)', [g[0] for g in gr] == [str(PZ), 'pessoal'] and 'Pizzaria Forno' in gr[0][1], gr)
        tg = pg.locator('[data-ag-emp-tag]').all_inner_texts()
        check(f'{nome}: Agenda — etiqueta "Pizzaria Forno" no compromisso da empresa; pessoais sem etiqueta', tg == ['Pizzaria Forno'], tg)
        pg.click(f'[data-ag-emp-f="{PZ}"]'); pg.wait_for_timeout(300)
        its = pg.locator('[data-ag-item]').evaluate_all('es=>es.map(e=>e.dataset.agEmp)')
        check(f'{nome}: Agenda — filtro de uma empresa mostra só os dela', its and set(its) == {str(PZ)}, its)
        pg.click('[data-ag-emp-f="pessoal"]'); pg.wait_for_timeout(300)
        its = pg.locator('[data-ag-item]').evaluate_all('es=>es.map(e=>e.dataset.agEmp)')
        check(f'{nome}: Agenda — "Pessoais" mostra só os sem empresa', its and set(its) == {''} and 'Dentista' in pg.inner_text('main'), its)
        pg.reload(); pg.wait_for_selector('[data-ag-emps]', timeout=20000); pg.wait_for_timeout(400)
        check(f'{nome}: Agenda — filtro lembrado ao voltar', pg.locator('[data-ag-emp-f="pessoal"]').get_attribute('aria-pressed') == 'true')
        pg.click('[data-ag-emp-f="todas"]'); pg.wait_for_timeout(200)
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: Agenda sem rolagem lateral', ow <= 1, ow)
        if nome == 'celular': pg.screenshot(path='/tmp/e2e/multi_agenda_celular.png')
        # calendário: mesmo filtro e seções no dia
        pg.locator('.ma-cal-btn').click(); pg.wait_for_selector('.ma-cal-grid .ma-cal-d', timeout=10000); pg.wait_for_timeout(600)
        pg.click(f'.ma-cal-d[data-d="{dia}"]'); pg.wait_for_timeout(400)
        cg = pg.locator('[data-cal-grupo]').evaluate_all('es=>es.map(e=>e.dataset.calGrupo)')
        check(f'{nome}: calendário — dia separado por empresa (Pizzaria, Pessoais)', cg == [str(PZ), 'pessoal'], cg)
        check(f'{nome}: calendário — etiqueta da empresa no item', pg.locator(f'.ma-cal-it[data-emp-id="{PZ}"] [data-emp-tag]').count() == 1)
        pg.click(f'.ma-cal-emp[data-emp="{PZ}"]'); pg.wait_for_timeout(300)
        ids = pg.locator('.ma-cal-lst .ma-cal-it').evaluate_all('es=>es.map(e=>e.dataset.empId||"")')
        check(f'{nome}: calendário — filtro de empresa', ids and set(ids) == {str(PZ)}, ids)
        pg.locator(f'.ma-cal-it[data-emp-id="{PZ}"]').first.click(); pg.wait_for_selector('.ma-sheet', timeout=5000)
        check(f'{nome}: calendário — abre o detalhe do compromisso certo', 'Retirada pizza agendada' in pg.inner_text('.ma-sheet'))
        pg.locator('.ma-sheet-x').click(); pg.wait_for_timeout(200); pg.click('.ma-cal-emp[data-emp="todas"]')
        ow = pg.evaluate('document.querySelector(".ma-cal-in").scrollWidth-document.querySelector(".ma-cal-in").clientWidth'); check(f'{nome}: calendário sem rolagem lateral', ow <= 1, ow)
        if nome == 'celular': pg.screenshot(path='/tmp/e2e/multi_calendario_celular.png')
        c.close()
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
