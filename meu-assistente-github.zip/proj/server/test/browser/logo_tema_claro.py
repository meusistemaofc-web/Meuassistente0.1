# Logo do Meu Assistente no tema claro: só o símbolo "M" (PNG transparente), sem o quadrado preto; tema escuro sem mudança;
# a troca de tema atualiza a logo na hora. Tela inicial do chat, cabeçalho de páginas internas e menu lateral (celular e computador).
# Servidor: run_srv.sh 4371 /tmp/ma-logo-b.db (banco novo)
import sys
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4371'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
INFO = """()=>[...document.querySelectorAll('.nx-brand,.ma-brand-img')].filter(e=>{const r=e.getBoundingClientRect();return r.width>8&&r.right>0&&r.left<innerWidth&&r.bottom>0&&r.top<innerHeight}).map(e=>{const cs=getComputedStyle(e),img=e.tagName==='IMG'?e:e.querySelector('img'),r=e.getBoundingClientRect(),ri=img.getBoundingClientRect();
  return {bg:cs.backgroundColor,pad:cs.paddingTop,variante:e.dataset.variant||'img',src:img.getAttribute('src'),ok:img.complete&&img.naturalWidth>0,w:Math.round(r.width),h:Math.round(r.height),iw:Math.round(ri.width),ih:Math.round(ri.height),prop:Math.abs(ri.width/ri.height-img.naturalWidth/img.naturalHeight)<0.06,filtro:getComputedStyle(img).filter}})"""
transp = lambda l: l and all(x['bg'] in ('rgba(0, 0, 0, 0)', 'transparent') and x['pad'] == '0px' for x in l)
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 860}, False)]:
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Logo ' + nome, 'whatsapp': '+55 11 94444-' + ('6161' if mob else '6262'), 'email': f'logo.{nome}@t.com', **U}).ok
        assert R.patch('/api/me', data={'settings': {'theme': 'light'}}).ok
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1500)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
        l = pg.evaluate(INFO)
        check(f'{nome}: tema claro — logo da tela inicial só com o "M", sem quadrado preto', pg.evaluate('document.documentElement.dataset.theme') == 'light' and transp(l) and all(x['ok'] and x['prop'] for x in l), l)
        pg.screenshot(path=f'/tmp/e2e/logo_{nome}_inicio_claro.png')
        # menu lateral
        pg.locator('[aria-label="Abrir menu"]').first.click(); pg.wait_for_timeout(700)
        l = pg.evaluate(INFO); check(f'{nome}: tema claro — logo do menu lateral sem fundo preto', transp(l), l)
        pg.screenshot(path=f'/tmp/e2e/logo_{nome}_menu_claro.png'); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        # página interna (cabeçalho)
        pg.goto('/agenda'); pg.wait_for_timeout(2000)
        l = pg.evaluate(INFO); check(f'{nome}: tema claro — logo do cabeçalho das páginas sem fundo preto e com contorno para contraste', transp(l) and all('drop-shadow' in x['filtro'] for x in l if x['variante'] in ('principal', 'img')), l)
        pg.screenshot(path=f'/tmp/e2e/logo_{nome}_pagina_claro.png')
        # troca para o escuro: volta a apresentação de sempre (sem quadrado e sem o contorno do tema claro)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
        pg.click('button[aria-label="Opções"]'); pg.wait_for_selector('[data-ma-tema]', timeout=8000); pg.click('[data-ma-tema]'); pg.wait_for_timeout(900); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        l = pg.evaluate(INFO)
        check(f'{nome}: trocar para o escuro atualiza a logo na hora (apresentação escura preservada)', pg.evaluate('document.documentElement.dataset.theme') == 'dark' and transp(l) and all('15, 23, 42' not in x['filtro'] for x in l), l)
        pg.screenshot(path=f'/tmp/e2e/logo_{nome}_inicio_escuro.png')
        pg.click('button[aria-label="Opções"]'); pg.wait_for_selector('[data-ma-tema]', timeout=8000); pg.click('[data-ma-tema]'); pg.wait_for_timeout(900); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
        l = pg.evaluate(INFO); check(f'{nome}: de volta ao claro, sem o quadrado preto', pg.evaluate('document.documentElement.dataset.theme') == 'light' and transp(l), l)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
