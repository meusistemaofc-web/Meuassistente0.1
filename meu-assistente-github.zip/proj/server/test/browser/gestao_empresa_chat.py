# Modo inteligente "Gestão da Empresa", pela tela real (celular e computador): o dono liga o modo pelo ⚡, pede uma alteração e
# o chat mostra a PRÉVIA nativa (cartão do produto com foto, nome, descrição e preço antigo riscado → novo destacado; perfil da
# empresa) com Confirmar alterações / Editar novamente / Cancelar. Nada é gravado antes do Confirmar (conferido no banco).
# Sem IA: o modo interpreta os pedidos pelas regras locais; servidor, rotas e banco são reais.
# Servidor: run_srv.sh 4367 /tmp/ma-gestao.db (banco novo)
import io, json, sys, sqlite3, base64, re
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4367'; DBF = '/tmp/ma-gestao.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def img(cor):
    b = io.BytesIO(); Image.new('RGB', (160, 160), cor).save(b, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
def val(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchone(); db.close(); return r[0] if r else None
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Ana Doceira', 'whatsapp': '+55 11 94444-1111', 'email': 'ana.gest@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Doceria Ana', 'categoria': 'Doceria', 'titulo': 'Doceria', 'texto': 'Doces finos', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']
    db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
    assert R.post(f'/api/v2/ads/{ID}/products', data={'nome': 'Brigadeiro', 'preco': 5, 'descricao': 'Chocolate ao leite', 'fotos': [img('saddlebrown')]}).ok
    preco = lambda: json.loads(val("select data from products where business_id=? and json_extract(data,'$.nome')='Brigadeiro'", ID))['preco']
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
    bolhas = lambda: [N(t) for t in pg.locator('.chat-scroll .msg-bubble').all_inner_texts()]
    def espera(n0):
        pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_timeout(1200)
        return bolhas()[-1]
    def enviar(t):
        n0 = len(bolhas()); pg.fill('textarea[data-composer-input]', t); pg.locator('button[aria-label="Enviar"]').click(); return espera(n0)
    def tocar(sel):
        n0 = len(bolhas()); pg.locator(sel).last.click(); return espera(n0)
    # 1) o modo aparece no ⚡ para quem tem empresa
    pg.click('.ma-modos-btn'); pg.wait_for_selector('#ma-modos-card [data-modo]', timeout=8000); pg.wait_for_timeout(300)
    check('"Gestão da Empresa" aparece no ⚡ do dono', pg.locator('#ma-modos-card [data-modo="gestao_empresa"]').count() == 1, pg.inner_text('#ma-modos-card'))
    n0 = len(bolhas()); pg.click('#ma-modos-card [data-modo="gestao_empresa"]'); t = espera(n0)
    check('ativar o modo identifica a empresa', 'Gestão da Empresa' in t and 'Doceria Ana' in t, t)
    # 2) alteração de preço → prévia nativa, nada gravado
    enviar('altere o preço do Brigadeiro para R$ 6,50')
    card = pg.locator('.ma-gp').last
    pg.wait_for_timeout(600)
    info = pg.evaluate("""()=>{const c=[...document.querySelectorAll('.ma-gp')].pop();if(!c)return null;return {img:!!c.querySelector('img.ma-gp-img'),nome:c.querySelector('[data-gp-nome]')?.innerText,old:c.querySelector('.ma-gp-old')?.innerText,novo:c.querySelector('.ma-gp-new')?.innerText,desc:c.querySelector('[data-gp-desc]')?.innerText,bts:[...c.querySelectorAll('[data-gp]')].map(b=>b.innerText.trim())}}""")
    check('prévia do produto: foto, nome, descrição, preço antigo riscado e novo destacado', info and info['img'] and info['nome'] == 'Brigadeiro' and 'R$ 5,00' in N(info['old']) and 'R$ 6,50' in N(info['novo']) and 'Chocolate' in (info['desc'] or ''), info)
    check('ações Confirmar alterações / Editar novamente / Cancelar', info and info['bts'] == ['Confirmar alterações', 'Editar novamente', 'Cancelar'], info)
    check('nada foi gravado antes de confirmar', preco() == 5, preco())
    pg.screenshot(path='/tmp/e2e/gestao_previa_celular.png')
    # 3) Editar novamente → ajuste → nova prévia
    t = tocar('.ma-gp [data-gp="editar"]')
    check('Editar novamente pede o novo valor', 'como deve ficar' in t, t)
    enviar('7,90')
    nv = pg.evaluate("(()=>{const c=[...document.querySelectorAll('.ma-gp')].pop();return c&&c.querySelector('.ma-gp-new')?.innerText})()")
    antigos = pg.evaluate("[...document.querySelectorAll('.ma-gp')].slice(0,-1).every(c=>!c.querySelector('[data-gp]')||[...c.querySelectorAll('[data-gp]')].every(b=>b.disabled))")
    check('prévia atualizada com R$ 7,90 (a anterior não fica ativa)', 'R$ 7,90' in N(nv or '') and antigos and preco() == 5, (nv, antigos, preco()))
    # 4) Confirmar → grava e o cartão mostra "Salvo"
    t = tocar('.ma-gp [data-gp="sim"]')
    check('Confirmar grava de verdade e responde com o resultado', 'Pronto' in t and preco() == 7.9, (t, preco()))
    check('cartão da resposta mostra "Salvo" e não tem mais botões', pg.evaluate("(()=>{const c=[...document.querySelectorAll('.ma-gp')].pop();return c&&/Salvo/.test(c.innerText)&&!c.querySelector('[data-gp]')})()"))
    # 5) perfil da empresa → Cancelar
    sobre0 = json.loads(val('select data from businesses where id=?', ID)).get('sobre')
    enviar('mude a descrição da empresa para Doces artesanais feitos com carinho')
    emp = pg.evaluate("(()=>{const c=[...document.querySelectorAll('.ma-gp')].pop();return c&&{campo:!!c.querySelector('[data-gp-campo=descricao] .ma-gp-hl'),txt:c.innerText}})()")
    check('prévia do perfil da empresa com o campo novo destacado', emp and emp['campo'] and 'Doces artesanais' in emp['txt'], emp)
    pg.screenshot(path='/tmp/e2e/gestao_empresa_celular.png')
    t = tocar('.ma-gp [data-gp="nao"]')
    check('Cancelar não altera nada', 'cancelei' in t.lower() and json.loads(val('select data from businesses where id=?', ID)).get('sobre') == sobre0, t)
    check('celular: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    # 6) computador + tema claro: a prévia continua legível e proporcional
    pg.set_viewport_size({'width': 1280, 'height': 860}); pg.evaluate("document.documentElement.dataset.theme='light'"); pg.wait_for_timeout(500)
    enviar('altere o preço do Brigadeiro para R$ 8')
    w = pg.evaluate("(()=>{const c=[...document.querySelectorAll('.ma-gp')].pop().getBoundingClientRect();return c.width})()")
    check('computador: cartão com largura contida (≤ 420px)', 200 < w <= 421, w)
    pg.screenshot(path='/tmp/e2e/gestao_previa_desktop_claro.png')
    tocar('.ma-gp [data-gp="nao"]')
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    # 7) quem não tem empresa não vê o modo
    E = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE); RE = E.request
    assert RE.post('/api/auth', data={'action': 'signup', 'name': 'Sem Empresa', 'whatsapp': '+55 11 94444-2222', 'email': 'sem.gest@t.com', **U}).ok
    ids = [m['id'] for m in RE.get('/api/v2/modos').json().get('modos', [])]
    check('sem empresa: o modo não aparece', 'gestao_empresa' not in ids, ids)
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
