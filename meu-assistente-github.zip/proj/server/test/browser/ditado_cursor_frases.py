# Ditado integrado ao campo de mensagem (24/11), pela tela real do chat, com o reconhecimento de fala do navegador simulado
# (o mesmo contrato da Web Speech API: resultados parciais e finais, contínuo). O app é o real.
# Confere: texto digitado antes é preservado; o ditado entra NA POSIÇÃO DO CURSOR (antes e depois intactos); várias frases
# na mesma escuta e em escutas seguidas se acumulam; parciais não duplicam; nada é enviado sozinho e nada vai à IA durante a
# fala; editar depois e enviar manda o texto completo uma vez; permissão negada e erro de reconhecimento não apagam o texto.
# Servidor: PORT=4348 SQLITE_FILE=/tmp/ma-dav.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import re, time
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4348'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
# window.__frases: lista de frases ditas nesta escuta; cada frase chega palavra a palavra (parcial) e vira final ao terminar.
# Os resultados seguem o formato real: um resultado por frase, os anteriores finais e o atual parcial.
FAKE = r"""(()=>{class Rec{constructor(){this.continuous=false;this.interimResults=false;this._t=[]}
 start(){if(window.__falha==='not-allowed'){setTimeout(()=>{this.onerror&&this.onerror({error:'not-allowed'});this.onend&&this.onend()},30);return}
  if(window.__falha==='network'){setTimeout(()=>{this.onstart&&this.onstart();setTimeout(()=>{this.onerror&&this.onerror({error:'network'});this.onend&&this.onend()},120)},30);return}
  window.__recAtivo=this;this._ok=true;setTimeout(()=>this.onstart&&this.onstart(),20);
  const fr=(window.__frases||['teste']).map(f=>f.split(' '));let fi=0,wi=0;
  const tick=()=>{if(!this._ok)return;wi++;const res=[];for(let k=0;k<fi;k++)res.push({0:{transcript:(k?' ':'')+fr[k].join(' ')},isFinal:true,length:1});
   const fin=wi>=fr[fi].length;res.push({0:{transcript:(fi?' ':'')+fr[fi].slice(0,wi).join(' ')},isFinal:fin,length:1});
   this.onresult&&this.onresult({results:res,resultIndex:fi});if(fin){fi++;wi=0}if(fi<fr.length)this._t.push(setTimeout(tick,fin?600:120))};
  this._t.push(setTimeout(tick,120))}
 _fim(){this._ok=false;this._t.forEach(clearTimeout);setTimeout(()=>{this.onend&&this.onend();if(window.__recAtivo===this)window.__recAtivo=null},20)}
 stop(){this._fim()} abort(){this._fim()}}
 window.SpeechRecognition=Rec;window.webkitSpeechRecognition=Rec;
 const oq=navigator.permissions.query.bind(navigator.permissions);navigator.permissions.query=d=>d&&d.name==='microphone'?Promise.resolve({get state(){return window.__permMic||'granted'},onchange:null}):oq(d)})()"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob, k in [('celular', {'width': 390, 'height': 844}, True, 3), ('computador', {'width': 1280, 'height': 900}, False, 4)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, permissions=['microphone']); C.add_init_script(FAKE); R = C.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Cursor Teste', 'whatsapp': f'+55 11 96666-{k}{k}{k}{k}', 'email': f'cursor{k}.{int(time.time())}@t.com', **U}, headers={'X-Forwarded-For': f'10.9.8.{k}'}).ok
        pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        envios, ia = [], []
        pg.on('request', lambda r: envios.append(r.post_data or '') if r.url.endswith('/api/chat') and r.method == 'POST' else None)
        pg.on('request', lambda r: ia.append(r.url) if ('/api/transcribe' in r.url or '/api/chat' in r.url) else None)
        pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
        if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(400)
        ta = pg.locator('textarea[data-composer-input]'); campo = lambda: pg.input_value('textarea[data-composer-input]')
        mic = lambda: pg.locator('button[aria-label="Ditar mensagem"], button[aria-label="Pausar ditado"]').first
        def ditar(frases, parar=True, esperar=None):
            pg.evaluate(f"window.__falha=null;window.__frases={frases!r}")
            mic().click(); pg.wait_for_selector('[data-ditado-estado="listening"]', timeout=3000)
            amostras = []
            fim = time.time() + (esperar or (0.8 + sum(len(f.split()) * 0.13 + 0.6 for f in frases)))
            while time.time() < fim: amostras.append(campo()); pg.wait_for_timeout(60)
            if parar: mic().click(); pg.wait_for_selector('[data-ditado-estado="inativo"]', timeout=4000); pg.wait_for_timeout(300)
            return amostras
        # 1) texto digitado antes + cursor no FIM: o ditado entra depois, sem apagar nada
        ta.click(); ta.type('Comprar pão e leite.'); n_env = len(envios)
        ditar(['e também café'])
        check(f'{nome}: texto digitado antes é preservado e o ditado entra depois dele', campo() == 'Comprar pão e leite. e também café', campo())
        check(f'{nome}: nada é enviado sozinho ao terminar de falar', len(envios) == n_env, envios[n_env:])
        # 2) cursor no MEIO do texto: entra na posição do cursor; antes e depois intactos
        ta.fill('Lembrar reunião amanhã'); ta.click(); pg.evaluate("()=>{const t=document.querySelector('textarea[data-composer-input]');t.focus();t.setSelectionRange(7,7)}")
        am = ditar(['da'])
        check(f'{nome}: ditado inserido na posição do cursor (meio do texto)', campo() == 'Lembrar da reunião amanhã', campo())
        check(f'{nome}: durante a fala o texto ao redor nunca some', all(a.startswith('Lembrar') and a.endswith('reunião amanhã') for a in am if a), [a for a in am if a][:5])
        # 3) várias frases na MESMA escuta: acumulam, e parciais não duplicam
        ta.fill(''); am = ditar(['preciso pagar o aluguel', 'e ligar para o banco', 'depois do almoço'])
        final = campo()
        check(f'{nome}: três frases na mesma escuta ficam todas no campo, na ordem', final == 'Preciso pagar o aluguel e ligar para o banco depois do almoço', final)
        rep = [a for a in am if re.search(r'\b(\w{4,})\b(?:\s+\w+)*\s+\1\b', a or '') and 'o banco' not in a]
        palavras_dupl = [a for a in am if a and (a.lower().count('aluguel') > 1 or a.lower().count('banco') > 1 or a.lower().count('almoço') > 1)]
        check(f'{nome}: resultados parciais e finais não duplicam texto em nenhum momento', not palavras_dupl, palavras_dupl[:3])
        # 4) escutas seguidas acumulam no mesmo campo (a segunda começa onde o cursor ficou: no fim do ditado anterior)
        ditar(['e comprar ração'])
        check(f'{nome}: uma segunda escuta acrescenta ao que já foi ditado', campo() == 'Preciso pagar o aluguel e ligar para o banco depois do almoço e comprar ração', campo())
        # 5) editar à mão depois e enviar: vai o texto completo, uma vez
        ta.click(); pg.keyboard.press('End'); pg.keyboard.type(' hoje')
        txt = campo(); n_env = len(envios); pg.locator('button[aria-label="Enviar"]').first.click(); pg.wait_for_timeout(2500)
        enviados = envios[n_env:]
        check(f'{nome}: enviar manda o texto completo (ditado + digitado), uma única mensagem', len(enviados) == 1 and txt in enviados[0] and campo() == '', (txt, enviados))
        # 6) nada de IA/transcrição durante a fala: só a requisição do envio
        n_ia = len(ia); ditar(['anotar compromisso'], parar=False, esperar=1.2); durante = ia[n_ia:]
        mic().click(); pg.wait_for_timeout(500)
        check(f'{nome}: durante a fala nenhuma requisição ao chat/IA ou à transcrição', not durante, durante)
        # 7) permissão negada: mensagem clara e o texto do campo intacto
        ta.fill('texto que não pode sumir'); pg.evaluate("window.__falha='not-allowed';window.__permMic='denied'")
        mic().click(); pg.wait_for_timeout(1500)
        corpo = pg.inner_text('.ma-composer-wrap')
        check(f'{nome}: microfone negado: aviso claro e o texto continua no campo', campo() == 'texto que não pode sumir' and ('bloqueado' in corpo or 'Libere' in corpo), (campo(), corpo[:200]))
        # 8) erro de reconhecimento no meio: o texto continua
        pg.evaluate("window.__permMic='granted';window.__falha='network'"); mic().click(); pg.wait_for_timeout(1800)
        check(f'{nome}: falha de reconhecimento não apaga nem duplica o texto', campo() == 'texto que não pode sumir', campo())
        pg.screenshot(path=f'/tmp/e2e/ditado_cursor_{nome}.png')
        C.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}")
