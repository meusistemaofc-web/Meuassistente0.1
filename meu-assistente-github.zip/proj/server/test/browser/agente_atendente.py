# Atendente comercial do agente (tela real /a/:id, iPhone e computador): procura → refina (cor e tamanho) → "quero essa"
# coloca a variação certa no carrinho DA TELA → "ver carrinho" mostra o item → pedido enviado com a variação certa.
# Também: indicador "digitando…" enquanto responde, cards na ordem da resposta, complemento sugerido (1, sem insistir),
# o que não existe é dito com clareza, sem rolagem lateral e sem erros de JavaScript.
# Servidor: PORT=4354 SQLITE_FILE=/tmp/ma-atd.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4354'; DBF = '/tmp/ma-atd.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
FOTO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Atende', 'whatsapp': '+55 11 94444-0301', 'email': 'admin.atd@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Rosa Loja', 'whatsapp': '+55 85 95555-0302', 'email': 'rosa.atd@t.com', **U}, headers={'X-Forwarded-For': '10.13.0.2'}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Moda Rosa', 'categoria': 'Moda', 'titulo': 't', 'texto': 'x', 'zap': '5585955550302', 'tipo': 'produtos', 'endereco': 'Rua R, 10'}).json()['items'][0]['id']
    fim = (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat()
    db("update businesses set status='ativo', expires_at=? where id=?", (fim, ID))
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}, 'pagamento': {'dinheiro': True}, 'entrega': {'retirada': True}}).ok and R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); d['agente']['expiresAt'] = fim.replace('+00:00', 'Z'); db('update businesses set data=? where id=?', (json.dumps(d), ID))
    for it in [{'nome': 'Camiseta Básica', 'preco': 49.9, 'categoria': 'Roupas', 'fotos': [FOTO], 'variantes': [{'cor': 'Preta', 'tamanho': 'P', 'preco': 49.9}, {'cor': 'Preta', 'tamanho': 'M', 'preco': 49.9}, {'cor': 'Branca', 'tamanho': 'M', 'preco': 49.9}]},
               {'nome': 'Camiseta Estampada', 'preco': 69.9, 'categoria': 'Roupas', 'fotos': [FOTO], 'variantes': [{'cor': 'Preta', 'tamanho': 'G', 'preco': 69.9}, {'cor': 'Azul', 'tamanho': 'M', 'preco': 69.9}]},
               {'nome': 'Boné Aba Curva', 'preco': 39.9, 'categoria': 'Acessórios', 'fotos': [FOTO]}]:
        assert R.post(f'/api/v2/ads/{ID}/products', data=it).ok, it['nome']
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        print('==', nome)
        C = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); pg = C.new_page(); pg.on('pageerror', lambda e: errs.append(nome + ': ' + str(e)))
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button', timeout=20000); pg.wait_for_timeout(800)
        pg.evaluate("()=>{window.__digitou=0;new MutationObserver(()=>{if(document.querySelector('#chat .typing'))window.__digitou++}).observe(document.getElementById('chat'),{childList:true,subtree:true})}")
        def diga(t, espera_cards=None):
            n0 = pg.locator('#chat .m.a').count(); pg.fill('#t', t); pg.press('#t', 'Enter')
            pg.wait_for_function(f"document.querySelectorAll('#chat .m.a').length>{n0}&&!document.querySelector('#chat .typing')", timeout=15000); pg.wait_for_timeout(350)
            return pg.locator('#chat .m.a').last.inner_text()
        def ultimos_cards():
            return pg.evaluate("()=>{const r=[...document.querySelectorAll('#chat .car')].pop();return r?[...r.querySelectorAll('.pc')].map(c=>c.textContent.replace(/\s+/g,' ').trim()):[]}")
        t1 = diga('oi, vocês têm camiseta?')
        cs = ultimos_cards()
        check(f'{nome}: "vocês têm camiseta?" → cards reais das 2 camisetas', len(cs) == 2 and all('Camiseta' in c for c in cs), (t1, cs))
        check(f'{nome}: indicador "digitando…" aparece enquanto responde', pg.evaluate('window.__digitou') > 0)
        t2 = diga('tem na cor preta no tamanho M?'); cs = ultimos_cards()
        check(f'{nome}: refina a busca anterior (preta + M → só a Básica)', len(cs) == 1 and 'Básica' in cs[0], (t2, cs))
        t3 = diga('quero essa')
        check(f'{nome}: "quero essa" → confirma no carrinho com a variação', 'Coloquei 1× Camiseta Básica (Preta · M)' in t3, t3)
        cs = ultimos_cards()
        check(f'{nome}: sugere no máximo 1 complemento (o boné)', len(cs) <= 1 and (not cs or 'Boné' in cs[0]), cs)
        t4 = diga('ver carrinho')
        cart_txt = pg.inner_text('#chat')
        check(f'{nome}: o item está no carrinho DA TELA', 'Camiseta Básica' in cart_txt and pg.locator('#cgo').count() > 0, t4)
        t5 = diga('vocês vendem tênis?')
        check(f'{nome}: o que a loja não tem é dito com clareza', 'Não encontrei tênis' in t5, t5)
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        pg.screenshot(path=f'/tmp/e2e/atendente_{nome}.png')
        if nome == 'celular':
            diga('ver carrinho'); pg.wait_for_selector('#cgo', timeout=8000)
            pg.locator('#cn').last.fill('Paula Cliente'); pg.locator('#ct').last.fill('85 98888-7777'); pg.locator('#cgo').last.click()
            pg.wait_for_function("/Pedido #\\d+/.test(document.getElementById('chat').innerText)", timeout=10000)
            o = db('select data from orders where business_id=? order by id desc limit 1', (ID,))
            itens = json.loads(o[0][0]).get('itens', []) if o else []
            check('pedido enviado com a variação escolhida na conversa', any('Camiseta Básica' in i.get('nome', '') and 'Preta' in json.dumps(i, ensure_ascii=False) and 'M' in json.dumps(i, ensure_ascii=False) for i in itens), itens)
        C.close()
    check('sem erros de JavaScript', not errs, errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações')
import sys; sys.exit(0 if ok == len(res) else 1)
