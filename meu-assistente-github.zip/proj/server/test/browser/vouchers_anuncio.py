# Cupons e Vouchers da ativação de anúncios, de ponta a ponta pela tela:
# administrador cria cupons (manual, gratuito, lote) e consulta o histórico; usuário, no celular, usa o campo discreto
# "Tenho um cupom" na ETAPA DE PAGAMENTO (a página Anunciar não tem mais cupom): erro claro, desconto calculado, remover,
# gratuidade; cria o anúncio
# e ativa sem pagamento em Sua empresa; o benefício aparece no anúncio e no histórico do painel.
# Servidor: PORT=4311 SQLITE_FILE=/tmp/ma-ui.db npx tsx test/serve-sqlite.ts (banco novo)
import sys
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE = 'http://localhost:4311'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(viewport={'width': 1280, 'height': 900}, base_url=BASE)
    assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Teste', 'whatsapp': '+55 11 94444-1234', 'email': 'admin@t.com', 'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}).ok
    pa = A.new_page(); pa.on('pageerror', lambda e: errs.append(str(e)))
    # 1) painel: criar cupons
    pa.goto('/admin'); pa.wait_for_timeout(1500); aba(pa,'Cupons e Vouchers'); pa.wait_for_selector('[data-vcv]', timeout=10000)
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f')
    pa.fill('#vc_f [name=codigo]', 'bemvindo50'); pa.fill('#vc_f [name=campanha]', 'Boas-vindas'); pa.fill('#vc_f [name=descricao]', 'Parceria com a influenciadora Ana')
    pa.check('#vc_f [name=tipo][value=percentual]'); pa.fill('#vc_f [name=percentual]', '50'); pa.fill('#vc_f [name=maxUsos]', '10')
    pa.click('#vc_f button[type=submit]'); pa.wait_for_selector('[data-vc]', timeout=8000)
    t = pa.inner_text('#vc_corpo')
    check('cupom criado pelo painel aparece na lista', 'BEMVINDO50' in t and '50% de desconto' in t and 'Ativo' in t and '0/10' in t, t[:300])
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f')
    pa.fill('#vc_f [name=codigo]', 'GRATIS30'); pa.check('#vc_f [name=tipo][value=gratuito]')
    check('campo do período aparece só na modalidade gratuita', pa.locator('[data-vc-k=gratuito]').is_visible() and not pa.locator('[data-vc-k=percentual]').is_visible())
    pa.fill('#vc_f [name=pq]', '30'); pa.select_option('#vc_f [name=pu]', 'dias'); pa.click('#vc_f button[type=submit]'); pa.wait_for_timeout(1200)
    pa.click('[data-vcv=novo]'); pa.wait_for_selector('#vc_f')
    pa.fill('#vc_f [name=quantidade]', '3'); pa.fill('#vc_f [name=prefixo]', 'parc'); pa.fill('#vc_f [name=campanha]', 'Parceiros'); pa.check('#vc_f [name=tipo][value=vitalicio]'); pa.check('#vc_f [name=usoUnico]')
    pa.click('#vc_f button[type=submit]'); pa.wait_for_timeout(1500)
    check('lote de 3 códigos gerados automaticamente', pa.locator('[data-vc]', has_text='PARC-').count() == 3 and 'acesso vitalício' in pa.inner_text('#vc_corpo'))
    pa.select_option('#vc_c', 'Parceiros'); pa.wait_for_timeout(300)
    check('filtro por campanha', pa.locator('[data-vc]').count() == 3)
    pa.select_option('#vc_c', ''); pa.wait_for_timeout(300)
    pa.screenshot(path='/tmp/e2e/vouchers_painel.png', full_page=True)
    # 2) usuário no celular: página Anunciar com o campo discreto
    U = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, has_touch=True, is_mobile=True)
    assert U.request.post('/api/auth', data={'action': 'signup', 'name': 'Ana Barbearia', 'whatsapp': '+55 11 95555-0101', 'email': 'ana@t.com', 'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}, headers={'X-Forwarded-For': '10.4.4.4'}).ok
    pg = U.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/x/anunciar'); pg.wait_for_selector('#adf', timeout=20000); pg.wait_for_timeout(800)
    pg.locator('label:has([name=planId][value=n1])').click(); pg.wait_for_timeout(300)
    # 1ª etapa (Anunciar): SEM cupom — o cupom fica na etapa de pagamento
    check('Anunciar: sem a opção "Tenho um cupom" na primeira etapa', pg.locator('#adf [data-cup-abrir]').count() == 0 and pg.locator('[data-cup-area]').count() == 0 and 'Tenho um cupom' not in pg.inner_text('#adf'))
    check('sem rolagem horizontal na página Anunciar', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
    pg.fill('[name=empresa]', 'Barbearia da Ana'); pg.fill('[name=titulo]', 'Cortes e barba')
    cat = pg.locator('[name=categoria]')
    if cat.evaluate('e=>e.tagName') == 'SELECT': cat.select_option(index=1)
    else: cat.fill('Barbearia')
    pg.fill('[name=texto]', 'Atendimento com hora marcada')
    pg.click('#adf button[type=submit]'); pg.wait_for_timeout(2500)
    if '/x/sua-empresa' not in pg.url: print('   erro do formulário:', pg.inner_text('#aderr') if pg.locator('#aderr').count() else '')
    # 2ª etapa (pagamento, em Sua empresa): o cupom continua aqui
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('[data-cupom-anuncio]', timeout=20000); pg.wait_for_timeout(800)
    W = '[data-cupom-anuncio]'
    check('pagamento: "Tenho um cupom" fechado por padrão', pg.locator(f'{W} [data-cup-abrir]').is_visible() and not pg.locator(f'{W} [data-cup-cod]').is_visible())
    pg.click(f'{W} [data-cup-abrir]'); pg.wait_for_timeout(300)
    check('ao tocar, abre o campo com "Aplicar cupom"', pg.locator(f'{W} [data-cup-cod]').is_visible() and pg.locator(f'{W} [data-cup-aplicar]').inner_text().strip() == 'Aplicar cupom')
    pg.fill(f'{W} [data-cup-cod]', 'NAOEXISTE'); pg.click(f'{W} [data-cup-aplicar]'); pg.wait_for_timeout(900)
    check('código inválido: motivo claro', 'não encontrado' in pg.inner_text(f'{W} [data-cup-msg]'), pg.inner_text(f'{W} [data-cup-msg]'))
    pg.fill(f'{W} [data-cup-cod]', 'bemvindo50'); pg.click(f'{W} [data-cup-aplicar]'); pg.wait_for_selector(f'{W} [data-cup-ok]', timeout=8000); pg.wait_for_timeout(500)
    ok = pg.inner_text(f'{W} [data-cup-ok]').replace('\xa0', ' ')
    check('cupom aplicado no pagamento: desconto e valor atualizado', 'BEMVINDO50' in ok and 'R$ 29,90' in ok and 'R$ 14,95' in ok, ok)
    pg.screenshot(path='/tmp/e2e/vouchers_pagamento_celular.png', full_page=True)
    pg.click(f'{W} [data-cup-remover]'); pg.wait_for_timeout(1500)
    check('remover cupom volta ao campo discreto', pg.locator(f'{W} [data-cup-ok]').count() == 0 and pg.locator(f'{W} [data-cup-abrir]').is_visible())
    pg.click(f'{W} [data-cup-abrir]'); pg.fill(f'{W} [data-cup-cod]', 'gratis30'); pg.click(f'{W} [data-cup-aplicar]'); pg.wait_for_selector(f'{W} [data-cup-ok]', timeout=8000); pg.wait_for_timeout(800)
    check('gratuidade: "Seu anúncio ficará gratuito por 30 dias" e valor Grátis', 'gratuito por 30 dias' in pg.inner_text(f'{W} [data-cup-ok]') and 'Grátis' in pg.inner_text(f'{W} [data-cup-ok]'), pg.inner_text(f'{W} [data-cup-ok]'))
    box = pg.inner_text(W)
    check('Sua empresa mostra o cupom reservado e "Ativar sem pagamento" (sem Pix)', 'GRATIS30' in box and pg.locator('[data-cupativar]').count() == 1 and pg.locator('[data-paynow]').count() == 0, box)
    pg.screenshot(path='/tmp/e2e/vouchers_sua_empresa_celular.png', full_page=True)
    pg.click('[data-cupativar]'); pg.wait_for_timeout(2500)
    st = U.request.get('/api/v2/ads/mine').json()['items'][0]
    check('ativação gratuita enviada para aprovação, sem cobrança', st['status'] == 'analise' and st.get('pago') and not (st.get('payment') or {}).get('id'), (st['status'], st.get('payment')))
    # 3) administrador aprova; o benefício fica registrado no anúncio
    aid = st['id']; assert A.request.post(f'/api/v2/admin/ads/{aid}', data={'action': 'approve'}).ok
    pg.goto('/x/sua-empresa'); pg.wait_for_selector('[data-beneficio]', timeout=20000)
    check('anúncio no ar mostra o benefício do cupom', 'Cupom GRATIS30 · anúncio gratuito por 30 dias' in pg.inner_text('[data-beneficio]'), pg.inner_text('[data-beneficio]'))
    # 4) histórico no painel com filtro
    pa.goto('/admin'); pa.wait_for_timeout(1500); aba(pa,'Cupons e Vouchers'); pa.wait_for_selector('[data-vcv]')
    pa.click('[data-vcv=historico]'); pa.wait_for_selector('#vh_tot', timeout=8000)
    h = pa.inner_text('#vc_corpo').replace('\xa0', ' ')
    check('histórico: código, usuário, anúncio, data, benefício, economia e situação', 'GRATIS30' in h and 'Ana Barbearia' in h and 'Barbearia da Ana' in h and 'Resgatado' in h and 'economia R$ 29,90' in h and 'benefício aplicado' in h, h[:600])
    pa.fill('#vh_cod', 'bemvindo'); pa.click('#vh_ok'); pa.wait_for_timeout(1200)
    check('filtro por código no histórico', 'GRATIS30' not in pa.inner_text('#vc_corpo'))
    pa.click('[data-vcv=cupons]'); pa.wait_for_selector('[data-vc]')
    pa.locator('[data-vc]', has_text='GRATIS30').locator('[data-vc-det]').click(); pa.wait_for_selector('[data-vc-detalhe]')
    check('detalhe do cupom: quem resgatou e histórico', 'Ana Barbearia' in pa.inner_text('[data-vc-detalhe]') and 'beneficio_aplicado' in pa.inner_text('[data-vc-detalhe]'))
    pa.locator('[data-vc]', has_text='BEMVINDO50').locator('[data-vc-st=pausado]').click(); pa.wait_for_timeout(1200)
    check('pausar pelo painel', 'Pausado' in pa.locator('[data-vc]', has_text='BEMVINDO50').inner_text())
    pa.screenshot(path='/tmp/e2e/vouchers_historico.png', full_page=True)
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e != 'Event'], errs)
    b.close()
ok = sum(res); print(f'{ok}/{len(res)} verificações'); sys.exit(0 if ok == len(res) else 1)
