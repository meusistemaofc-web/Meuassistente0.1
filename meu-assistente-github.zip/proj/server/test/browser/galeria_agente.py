# Galeria de fotos dos produtos e serviços no chat do agente (/a/:id) e card "adicionado ao pedido".
# Galeria:
#   - produto com 1, 2 e 3 fotos — o máximo que o catálogo guarda — em proporções diferentes e serviço com 3 fotos;
#   - ordem do dono, capa primeiro, sem repetir;
#   - posição "1/4", pontos clicáveis, setas no computador, deslizar no celular (gesto de toque real);
#   - ampliada com zoom, navegação e fechamento, volta ao chat no mesmo ponto;
#   - tema escuro e claro.
# Card do carrinho: "Continuar" + "Ver carrinho e finalizar" inteiros, sem rolagem lateral, de 320 a 1280 px, e os dois funcionando.
# Servidor: PORT=4398 SQLITE_FILE=/tmp/ma-gal.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime, base64, io
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4398'; DBF = '/tmp/ma-gal.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def foto(cor, w, h):
    b = io.BytesIO(); Image.new('RGB', (w, h), cor).save(b, 'JPEG', quality=70); return 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
F1 = [foto((200, 40, 40), 800, 600)]
F2 = [foto((40, 160, 60), 800, 800), foto((40, 60, 200), 1200, 675)]
F4 = [foto((230, 180, 20), 600, 800), foto((20, 180, 200), 1600, 900), foto((150, 40, 160), 700, 700), foto((90, 90, 90), 500, 1000)]
FS = [foto((250, 120, 30), 900, 600), foto((30, 120, 250), 600, 900), foto((120, 250, 30), 800, 800)]
def agente_ativo(ID, fundo='escuro'):
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); d['agente']['expiresAt'] = (datetime.datetime.now(datetime.UTC).replace(tzinfo=None) + datetime.timedelta(days=30)).isoformat() + 'Z'
    d['tema'] = {**(d.get('tema') or {}), 'fundo': fundo}; db('update businesses set data=? where id=?', (json.dumps(d), ID))
GAL = """()=>{const g=document.querySelector('.det [data-gal]');if(!g)return null;const tr=g.querySelector('[data-gal-tr]');const ims=[...tr.querySelectorAll('img')];
  const a=g.querySelector('[data-gal-p="1"]');return {n:ims.length,src:ims.map(i=>i.getAttribute('src')),cont:(g.querySelector('[data-gal-n]')||{}).textContent||'',dots:document.querySelectorAll('.det [data-gal-ir]').length,
  on:[...document.querySelectorAll('.det [data-gal-ir]')].findIndex(b=>b.classList.contains('on')),setas:g.querySelectorAll('[data-gal-p]').length,setaVis:a?getComputedStyle(a).display!=='none':false,
  fit:ims.map(i=>getComputedStyle(i).objectFit),hs:ims.map(i=>Math.round(i.getBoundingClientRect().height)),bg:(()=>{const c=getComputedStyle(g).backgroundColor,n=(c.match(/[\\d.]+/g)||[]).map(Number).slice(0,3);return /srgb/.test(c)?n.reduce((a,x)=>a+x*255,0):n.reduce((a,x)=>a+x,0)})(),vimg:(g.querySelector('[data-vimg]')||{}).dataset?.galI}}"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); R = A.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Admin Galeria', 'whatsapp': '+55 11 94444-1200', 'email': 'admin.gal@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Empório Galeria', 'categoria': 'Loja', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}).json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}}).ok and R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    for nome, fs in [('Caneca Uma Foto', F1), ('Bolsa Duas Fotos', F2), ('Luminária Quatro Fotos', F4)]:
        rp = R.post(f'/api/v2/ads/{ID}/products', data={'nome': nome, 'preco': 59.9, 'tipo': 'produto', 'categoria': 'Casa', 'fotos': fs, 'descricao': 'Produto de teste.'}); assert rp.ok, rp.text()
    agente_ativo(ID)
    B2 = b.new_context(base_url=BASE); R2 = B2.request  # o agente é um por conta: o serviço é de outra empresária
    assert R2.post('/api/auth', data={'action': 'signup', 'name': 'Bia Studio', 'whatsapp': '+55 11 94444-1201', 'email': 'bia.gal@t.com', **U}, headers={'X-Forwarded-For': '10.8.0.2'}).ok
    R = R2
    SID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Studio Serviços', 'categoria': 'Beleza', 'titulo': 't', 'texto': 'x', 'zap': '5511999990001', 'tipo': 'servicos', 'endereco': 'Rua B, 20'}).json()['items'][0]['id']
    assert R.put(f'/api/v2/ads/{SID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}}).ok and R.put(f'/api/v2/ads/{SID}/agent', data={'ativo': True}).ok
    for nome in ['Corte feminino', 'Escova']:
        assert R.post(f'/api/v2/ads/{SID}/products', data={'nome': nome, 'preco': 90, 'tipo': 'servico', 'modoPreco': 'fixo', 'duracao': 60, 'categoria': 'Cabelo', 'fotos': FS if nome == 'Corte feminino' else [], 'descricao': 'Serviço.'}).ok
    agente_ativo(SID, 'claro')
    antes = db('select group_concat(data) from products')[0][0]
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 860}, False)]:
        print('==', nome)
        c = b.new_context(viewport=vp, base_url=BASE, has_touch=mob, is_mobile=mob); pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(f'/a/{ID}'); pg.wait_for_selector('#acts button', timeout=15000)
        pg.click('#acts [data-a=cat]'); pg.wait_for_selector('.rich .prods', timeout=8000); pg.wait_for_timeout(500)
        abrir = lambda nomep: (pg.locator(f'.rich .pc[aria-label="{nomep}"] .ph').last.click(), pg.wait_for_selector('.det [data-gal]', timeout=5000), pg.wait_for_timeout(350))
        sc0 = pg.evaluate('()=>{const s=document.scrollingElement;const m=document.querySelector("#msgs,.msgs,main");return [s.scrollTop,m?m.scrollTop:0]}')
        # 1 foto: experiência atual, sem posição/pontos/setas
        abrir('Caneca Uma Foto'); g = pg.evaluate(GAL)
        check(f'{nome}: 1 foto — sem "1/1", pontos ou setas', g['n'] == 1 and g['cont'] == '' and g['dots'] == 0 and g['setas'] == 0 and pg.locator('.det .det-ph img').count() == 1, g)
        pg.locator('.det-x').click(); pg.wait_for_timeout(250)
        # 2 fotos
        abrir('Bolsa Duas Fotos'); g = pg.evaluate(GAL)
        check(f'{nome}: 2 fotos — "1/2" e 2 pontos', g['n'] == 2 and g['cont'] == '1/2' and g['dots'] == 2 and g['on'] == 0, g)
        pg.locator('.det-x').click(); pg.wait_for_timeout(250)
        # 4 fotos, ordem do dono, capa primeiro, sem repetir, proporções diferentes sem corte
        abrir('Luminária Quatro Fotos'); g = pg.evaluate(GAL)
        info = [x for x in pg.request.get(f'/api/v2/agent/{ID}/info').json()['produtos'] if x['nome'] == 'Luminária Quatro Fotos'][0]
        check(f'{nome}: todas as fotos cadastradas (o catálogo guarda até 3) na ordem do dono, capa primeiro, sem repetir', g['n'] == len(info['fotos']) == 3 and g['src'] == info['fotos'] and g['src'][0] == info['foto'] and len(set(g['src'])) == 3 and g['cont'] == '1/3', (g['n'], len(info['fotos'])))
        check(f'{nome}: proporções diferentes mostradas inteiras (contain, mesma altura)', set(g['fit']) == {'contain'} and len(set(g['hs'])) == 1, (g['fit'], g['hs']))
        check(f'{nome}: tema escuro — fundo da galeria escuro', g['bg'] < 150, g['bg'])
        if mob:
            check('celular: setas escondidas (navegação por gesto)', not g['setaVis'], g)
            cdp = c.new_cdp_session(pg); bx = pg.locator('.det [data-gal-tr]').bounding_box()
            y, x0 = bx['y'] + bx['height'] / 2, bx['x'] + bx['width'] * .85  # gesto de toque real: dedo arrastando da direita para a esquerda
            cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': x0, 'y': y, 'id': 1}]})
            for k in range(1, 16): cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': x0 - k * 18, 'y': y, 'id': 1}]}); pg.wait_for_timeout(16)
            cdp.send('Input.dispatchTouchEvent', {'type': 'touchEnd', 'touchPoints': []})
            pg.wait_for_timeout(1100); g = pg.evaluate(GAL)
            check('celular: deslizar o dedo vai para a foto 2 ("2/3", ponto 2)', g['cont'] == '2/3' and g['on'] == 1 and g['vimg'] == '1', g)
        else:
            pg.locator('.det [data-gal]').hover(); pg.wait_for_timeout(250)
            check('computador: setas visíveis ao passar o mouse; "anterior" desativada na 1ª', g['setaVis'] and pg.locator('.det [data-gal-p="-1"]').is_disabled())
            pg.locator('.det [data-gal-p="1"]').click(); pg.wait_for_timeout(700); g = pg.evaluate(GAL)
            check('computador: seta "próxima" vai para "2/3"', g['cont'] == '2/3' and g['on'] == 1, g)
        pg.locator('.det [data-gal-ir="2"]').click(); pg.wait_for_timeout(700); g = pg.evaluate(GAL)
        check(f'{nome}: ponto 3 leva direto à última ("3/3"); "próxima" desativada', g['cont'] == '3/3' and g['on'] == 2 and pg.locator('.det [data-gal-p="1"]').is_disabled(), g)
        pg.locator('.det [data-gal-ir="1"]').click(); pg.wait_for_timeout(700)
        if nome == 'computador': pg.locator('.det [data-gal]').screenshot(path='/tmp/e2e/galeria_detalhe.png')
        # ampliada: abre na foto atual, zoom, navegação sem perder o zoom de vista, fecha e volta ao detalhe na mesma foto
        pg.locator('.det [data-gal-i="1"]').click(); pg.wait_for_selector('.galz', timeout=3000); pg.wait_for_timeout(400)
        zc = lambda: pg.evaluate("()=>{const z=document.querySelector('.galz');return z?{n:(z.querySelector('[data-gz-n]')||{}).textContent,zoom:z.classList.contains('zoom'),sl:z.querySelector('[data-gz-tr]').scrollLeft,w:z.querySelector('[data-gz-tr]').clientWidth,full:z.getBoundingClientRect().width===innerWidth}:null}")
        z = zc(); check(f'{nome}: tocar na foto abre a ampliada em tela cheia na mesma foto ("2/3")', z and z['n'] == '2/3' and z['full'] and round(z['sl'] / z['w']) == 1, z)
        im = pg.locator('.galz [data-gz-i="1"]').bounding_box()
        pg.mouse.dblclick(im['x'] + im['width'] / 2, im['y'] + im['height'] / 2); pg.wait_for_timeout(400)
        tf = pg.evaluate("()=>document.querySelector('.galz [data-gz-i=\"1\"]').style.transform")
        check(f'{nome}: toque/clique duplo amplia a foto (zoom)', zc()['zoom'] and 'scale(2.5)' in tf, tf)
        if mob: pg.evaluate("()=>document.querySelector('.galz [data-gz-ir=\"0\"]').click()")
        else: pg.locator('.galz [data-gz-p="-1"]').click()
        pg.wait_for_timeout(800); z = zc()
        check(f'{nome}: com zoom, ainda navega para outra foto ("1/3", zoom desfeito)', z['n'] == '1/3' and not z['zoom'], z)
        if mob: pg.go_back()
        else: pg.keyboard.press('Escape')
        pg.wait_for_timeout(500); g = pg.evaluate(GAL)
        check(f'{nome}: fechar a ampliada ({"voltar do celular" if mob else "Esc"}) volta ao detalhe na foto onde parou', pg.locator('.galz').count() == 0 and pg.locator('.det').count() == 1 and g['cont'] == '1/3', g)
        pg.locator('.det-x').click(); pg.wait_for_timeout(400)
        sc1 = pg.evaluate('()=>{const s=document.scrollingElement;const m=document.querySelector("#msgs,.msgs,main");return [s.scrollTop,m?m.scrollTop:0]}')
        check(f'{nome}: fechar o detalhe volta ao chat no mesmo ponto', pg.locator('.det').count() == 0 and abs(sc1[0] - sc0[0]) <= 2 and abs(sc1[1] - sc0[1]) <= 2 and pg.evaluate("document.body.style.overflow") == '', (sc0, sc1))
        # card "adicionado": Continuar + Ver carrinho e finalizar, inteiros, sem rolagem lateral, em várias larguras
        pg.locator('.rich .pc[aria-label="Caneca Uma Foto"] button').last.click(); pg.wait_for_selector('[data-addok]', timeout=5000)
        BT = """()=>{const bx=[...document.querySelectorAll('[data-addok]')].pop(),m=bx.parentElement.getBoundingClientRect(),r=bx.getBoundingClientRect(),bs=[...bx.querySelectorAll('button')];
          return {txt:bs.map(x=>x.textContent),ox:getComputedStyle(bx).overflowX,sw:bx.scrollWidth,cw:bx.clientWidth,dentro:bs.every(x=>{const q=x.getBoundingClientRect();return q.left>=r.left-1&&q.right<=r.right+1&&q.left>=m.left-1&&q.right<=m.right+1&&q.right<=innerWidth}),
          corta:bs.some(x=>x.scrollWidth>x.clientWidth+1),ws:bs.map(x=>Math.round(x.getBoundingClientRect().width)),tops:bs.map(x=>Math.round(x.getBoundingClientRect().top)),hs:bs.map(x=>Math.round(x.getBoundingClientRect().height)),
          prim:(x=>x.backgroundImage+'|'+x.backgroundColor)(getComputedStyle(bs[1])),sec:(x=>x.backgroundImage+'|'+x.backgroundColor)(getComputedStyle(bs[0])),pag:document.documentElement.scrollWidth-innerWidth}}"""
        larg = [320, 360, 390, 430] if mob else [768, 1024, 1280]; lados = {}
        for w in larg:
            pg.set_viewport_size({'width': w, 'height': vp['height']}); pg.wait_for_timeout(250); s = pg.evaluate(BT)
            lado = abs(s['tops'][0] - s['tops'][1]) <= 4
            check(f'{nome} {w}px: "Continuar" e "Ver carrinho e finalizar" inteiros, sem rolagem lateral nem corte ({"lado a lado" if lado else "empilhados"})',
                  s['txt'] == ['Continuar', 'Ver carrinho e finalizar'] and s['sw'] <= s['cw'] + 1 and s['dentro'] and not s['corta'] and s['pag'] <= 1 and max(s['hs']) <= 46, s)
            lados[w] = lado
            if lado: check(f'{nome} {w}px: "Continuar" menor que o botão principal', s['ws'][0] < s['ws'][1], s['ws'])
            else: check(f'{nome} {w}px: empilhados com o principal em cima', s['tops'][1] < s['tops'][0], s['tops'])
        pg.set_viewport_size(vp); pg.wait_for_timeout(200)
        if mob: check('celular: lado a lado a partir de 360 px (só empilha em telas bem estreitas)', lados[360] and lados[390] and lados[430], lados)
        else: check('computador: sempre lado a lado', all(lados.values()), lados)
        if mob: pg.locator('[data-addok]').last.screenshot(path='/tmp/e2e/card_adicionado_celular.png')
        check(f'{nome}: botão principal em destaque (cor diferente do secundário)', s['prim'] != s['sec'], (s['prim'], s['sec']))
        n0 = pg.locator('.rich .prods').count(); pg.locator('[data-addok] [data-x=cat]').last.click(); pg.wait_for_timeout(600)
        check(f'{nome}: "Continuar" volta ao catálogo', pg.locator('.rich .prods').count() > n0)
        pg.locator('[data-addok] [data-x=cart]').last.click(); pg.wait_for_timeout(800)
        check(f'{nome}: "Ver carrinho e finalizar" abre o carrinho com o item', 'Caneca Uma Foto' in pg.inner_text('body') and pg.locator('text=Como receber').count() >= 1)
        # serviço com várias fotos (tema claro)
        pg.goto(f'/a/{SID}'); pg.wait_for_selector('#acts button', timeout=15000)
        pg.click('#acts [data-a=srv]'); pg.wait_for_selector('.rich .prods', timeout=8000); pg.wait_for_timeout(400)
        abrir('Corte feminino'); g = pg.evaluate(GAL)
        check(f'{nome}: serviço com 3 fotos — galeria completa ("1/3", 3 pontos)', g['n'] == 3 and g['cont'] == '1/3' and g['dots'] == 3 and g['src'] == [x for x in pg.request.get(f'/api/v2/agent/{SID}/info').json()['produtos'] if x['nome'] == 'Corte feminino'][0]['fotos'], g)
        check(f'{nome}: tema claro — fundo da galeria claro', g['bg'] > 600, g['bg'])
        if nome == 'celular': pg.locator('.det-c').screenshot(path='/tmp/e2e/galeria_servico_claro.png')
        pg.locator('.det [data-gal-ir="2"]').click(); pg.wait_for_timeout(700)
        check(f'{nome}: serviço — ponto 3 leva à "3/3"', pg.evaluate(GAL)['cont'] == '3/3')
        pg.locator('.det-x').click(); pg.wait_for_timeout(200)
        sem = pg.locator('.rich .pc[aria-label="Escova"] .ph').last
        check(f'{nome}: serviço sem foto continua sem galeria', sem.locator('img').count() == 0)
        c.close()
    check('catálogo intacto (as fotos não foram alteradas)', db('select group_concat(data) from products')[0][0] == antes)
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
