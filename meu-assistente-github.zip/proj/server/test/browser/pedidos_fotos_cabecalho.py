# Pedidos: tocar/clicar a foto de um item abre a foto ampliada (camada escura, foto centralizada na proporção original,
# Fechar, Esc, tocar fora), sem abrir o pedido e sem mudar o layout da lista; vale na lista de Pedidos da loja e no
# detalhe do pedido (Esc fecha só a foto). Chat: o cabeçalho nunca mostra "Digitando…"/status durante o envio e não
# muda de tamanho; o indicador continua dentro da conversa. Celular, tablet e computador.
# Servidor: PORT=4352 SQLITE_FILE=/tmp/ma-pedfotos.db npx tsx test/serve-sqlite.ts (banco novo)
import sqlite3, datetime, base64, io
from PIL import Image
from playwright.sync_api import sync_playwright
BASE='http://localhost:4352'; DBF='/tmp/ma-pedfotos.db'
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
def png(w,h,cor):
    im=Image.new('RGB',(w,h),cor); [im.putpixel((x,h//2),(255,255,255)) for x in range(0,w,3)]
    bf=io.BytesIO(); im.save(bf,'PNG'); return 'data:image/png;base64,'+base64.b64encode(bf.getvalue()).decode()
F1,F2=png(1200,800,(200,40,40)),png(600,1000,(40,160,60))
ATRASA="""(()=>{const f=window.fetch;window.fetch=async(u,o)=>{const s=String(u&&u.url||u);if(/\\/api\\/chat(\\?|$)/.test(s)&&o&&o.method==='POST')await new Promise(r=>setTimeout(r,2500));return f(u,o)}})()"""
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Dono Doceria','whatsapp':'+55 11 93330-1111','email':'dono@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    r=O.post('/api/v2/ads',data={'planId':'n4','empresa':'Doceria Mel','categoria':'Doces','titulo':'Doceria Mel','texto':'Feito com carinho','zap':'5511999990000','lat':-23.552,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); db.commit(); db.close()
    assert O.put(f'/api/v2/ads/{BID}',data={'horarioCfg':{'modo':'aberto','dias':{}},'pagamento':{'dinheiro':True},'entrega':{'retirada':True}}).ok
    PID={}
    for it in [{'nome':'Bolo de chocolate','preco':45,'categoria':'Bolos','fotos':[F1]},{'nome':'Bolo de cenoura','preco':39,'categoria':'Bolos','fotos':[F2]}]:
        r=O.post(f'/api/v2/ads/{BID}/products',data=it); assert r.ok, r.text(); PID[it['nome']]=[x for x in r.json()['items'] if x['nome']==it['nome']][0]['id']
    c0=b.new_context(base_url=BASE); C=c0.request
    assert C.post('/api/auth',data={'action':'signup','name':'Cliente Pedido','whatsapp':'+55 11 96666-0001','email':'cli@t.com','birthday':'1991-04-04','password':'Cliente@123','passwordConfirm':'Cliente@123'}).ok
    r=C.post(f'/api/v2/businesses/{BID}/orders',data={'itens':[{'pid':PID['Bolo de chocolate'],'qtd':1},{'pid':PID['Bolo de cenoura'],'qtd':2}],'modo':'retirada','pagamento':'dinheiro'}); assert r.ok, r.text()
    sess=o.cookies()
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('tablet',{'width':820,'height':1180},True),('computador',{'width':1280,'height':860},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1); c.add_cookies(sess)
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=pedidos]',timeout=20000); pg.click('.ma-nav [data-nav=pedidos]')
        pg.wait_for_selector('[data-oitens] button.ma-oth[data-bp-zoom]',timeout=20000); pg.wait_for_timeout(600)
        th=pg.locator('[data-oitens] button.ma-oth[data-bp-zoom]').first
        bx=th.bounding_box(); check(f'{nome}: miniatura do item é um botão com o mesmo tamanho (44 px)', abs(bx['width']-44)<0.6 and abs(bx['height']-44)<0.6, bx)
        # layout: a linha do item mede o mesmo com o botão e com a miniatura antiga (span)
        lay=pg.evaluate("""()=>{const bt=document.querySelector('[data-oitens] button.ma-oth'),row=bt.closest('[data-oitem]'),lst=bt.closest('[data-oitens]');
          const m=()=>[row.getBoundingClientRect().height,lst.getBoundingClientRect().height,row.querySelector('.ma-oi-tx').getBoundingClientRect().left-row.getBoundingClientRect().left];
          const a=m();const sp=document.createElement('span');sp.className=bt.className;sp.setAttribute('style',bt.getAttribute('style'));sp.innerHTML=bt.innerHTML;bt.replaceWith(sp);const b2=m();sp.replaceWith(bt);return {a,b:b2}}""")
        check(f'{nome}: layout da lista de pedidos igual ao de antes (altura da linha, da lista e posição do texto)', all(abs(x-y)<0.6 for x,y in zip(lay['a'],lay['b'])), lay)
        lbl=th.get_attribute('aria-label'); check(f'{nome}: botão tem rótulo acessível', lbl and 'Bolo de chocolate' in lbl, lbl)
        # abrir (toque no celular/tablet, clique no computador)
        (th.tap() if mob else th.click()); pg.wait_for_selector('.ma-lb.on',timeout=3000); pg.wait_for_function("()=>{const i=document.querySelector('.ma-lb-st img');return i&&i.complete&&i.naturalWidth>0&&getComputedStyle(i).opacity==='1'}",timeout=5000); pg.wait_for_timeout(300)
        info=pg.evaluate("""()=>{const L=document.querySelector('.ma-lb'),i=L.querySelector('.ma-lb-st img'),st=L.querySelector('.ma-lb-st'),r=i.getBoundingClientRect(),s=st.getBoundingClientRect(),cs=getComputedStyle(L);
          return {bg:cs.backgroundColor,tr:cs.transitionDuration,trSt:getComputedStyle(st).transitionDuration,nw:i.naturalWidth,nh:i.naturalHeight,w:r.width,h:r.height,cx:r.left+r.width/2-(s.left+s.width/2),cy:r.top+r.height/2-(s.top+s.height/2),fit:getComputedStyle(i).objectFit,
            sheet:!!document.querySelector('.ma-sheet'),nome:L.querySelector('.ma-lb-n').textContent,dlg:L.getAttribute('role')+'/'+L.getAttribute('aria-modal'),foco:document.activeElement&&document.activeElement.className,vw:innerWidth,vh:innerHeight,z:+cs.zIndex}}""")
        check(f'{nome}: abre a camada escura sobre a tela (sem abrir o pedido)', 'rgba(4, 7, 14' in info['bg'] and not info['sheet'] and info['dlg']=='dialog/true', info)
        check(f'{nome}: foto original (1200×800), proporção preservada', info['nw']==1200 and info['nh']==800 and abs(info['w']/info['h']-1.5)<0.01 and info['fit']=='contain', info)
        check(f'{nome}: foto centralizada e maior que a miniatura', abs(info['cx'])<1.5 and abs(info['cy'])<1.5 and info['w']>min(info['vw'],1000)*0.6, info)
        check(f'{nome}: animação suave (camada e foto com transição)', info['tr'] not in ('0s','') and info['trSt'] not in ('0s',''), info)
        check(f'{nome}: foco no botão Fechar e título com o nome do item', 'ma-lb-x' in (info['foco'] or '') and info['nome']=='Bolo de chocolate', info)
        pg.screenshot(path=f'/tmp/pedfoto_{nome}.png')
        # fechar pelo botão
        x=pg.locator('.ma-lb-x'); (x.tap() if mob else x.click()); pg.wait_for_selector('.ma-lb',state='detached',timeout=2000)
        check(f'{nome}: botão Fechar fecha e devolve o foco à foto', pg.evaluate("()=>document.activeElement&&document.activeElement.matches('button.ma-oth')"))
        # fechar tocando fora da foto
        th=pg.locator('[data-oitens] button.ma-oth[data-bp-zoom]').nth(1); (th.tap() if mob else th.click()); pg.wait_for_selector('.ma-lb.on',timeout=3000); pg.wait_for_timeout(450)
        s=pg.locator('.ma-lb-st').bounding_box(); fx,fy=s['x']+12,s['y']+s['height']-14
        (pg.touchscreen.tap(fx,fy) if mob else pg.mouse.click(fx,fy)); pg.wait_for_selector('.ma-lb',state='detached',timeout=2500)
        check(f'{nome}: tocar fora da foto fecha', pg.locator('.ma-lb').count()==0)
        # tocar a própria foto não fecha
        th=pg.locator('[data-oitens] button.ma-oth[data-bp-zoom]').first; (th.tap() if mob else th.click()); pg.wait_for_selector('.ma-lb.on',timeout=3000); pg.wait_for_timeout(450)
        im=pg.locator('.ma-lb-st img').bounding_box(); (pg.touchscreen.tap(im['x']+im['width']/2,im['y']+im['height']/2) if mob else pg.mouse.click(im['x']+im['width']/2,im['y']+im['height']/2)); pg.wait_for_timeout(700)
        check(f'{nome}: tocar na foto não fecha', pg.locator('.ma-lb.on').count()==1)
        pg.keyboard.press('Escape'); pg.wait_for_selector('.ma-lb',state='detached',timeout=2000)
        # detalhe do pedido: foto ampliada por cima; Esc fecha só a foto
        d=pg.locator('[data-odet]').first; (d.tap() if mob else d.click()); pg.wait_for_selector('.ma-sheet [data-oitens] button.ma-oth[data-bp-zoom]',timeout=5000); pg.wait_for_timeout(500)
        t2=pg.locator('.ma-sheet button.ma-oth[data-bp-zoom]').first; (t2.tap() if mob else t2.click()); pg.wait_for_selector('.ma-lb.on',timeout=3000); pg.wait_for_timeout(300)
        z=pg.evaluate("()=>[+getComputedStyle(document.querySelector('.ma-lb')).zIndex,+getComputedStyle(document.querySelector('.ma-sheet')).zIndex||0]")
        check(f'{nome}: no detalhe do pedido a foto abre por cima', z[0]>z[1], z)
        pg.keyboard.press('Escape'); pg.wait_for_selector('.ma-lb',state='detached',timeout=2000); pg.wait_for_timeout(200)
        check(f'{nome}: Esc fecha só a foto (o detalhe do pedido continua aberto)', pg.locator('.ma-sheet').count()==1)
        c.close()
    # ---- cabeçalho do chat durante o envio ----
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':860},False)]:
        print('== chat',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); c.add_cookies(c0.cookies()); c.add_init_script(ATRASA)
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.goto('/'); pg.wait_for_selector('textarea.composer-input',timeout=20000); pg.wait_for_timeout(800)
        pg.evaluate("""()=>{window.__hd=[];const bar=document.querySelector('.nx-chat-header-bar'),hd=document.querySelector('.nx-chat-header');let ind=false;
          const f=()=>{const r=hd.getBoundingClientRect(),rb=bar.getBoundingClientRect();if(document.querySelector('.chat-scroll [role="status"][aria-label="Preparando a resposta"]'))ind=true;
            window.__hd.push({h:Math.round(r.height*10)/10,bh:Math.round(rb.height*10)/10,t:bar.innerText,st:bar.querySelectorAll('[role="status"]').length,ind});if(window.__hd.length<900)requestAnimationFrame(f)};requestAnimationFrame(f)}""")
        pg.fill('textarea.composer-input','oi, tudo bem?'); pg.keyboard.press('Enter')
        pg.wait_for_timeout(1200); meio=pg.evaluate("()=>({ind:!!document.querySelector('.chat-scroll [role=\"status\"][aria-label=\"Preparando a resposta\"]'),txt:(document.querySelector('.chat-scroll [role=\"status\"]')||{}).innerText||''})")
        pg.screenshot(path=f'/tmp/chat_cab_{nome}.png')
        pg.wait_for_function("()=>!document.querySelector('.chat-scroll [role=\"status\"][aria-label=\"Preparando a resposta\"]')",timeout=30000); pg.wait_for_timeout(400)
        hd=pg.evaluate('window.__hd')
        alt=sorted(set(x['h'] for x in hd)); altb=sorted(set(x['bh'] for x in hd))
        check(f'chat {nome}: o cabeçalho nunca mostra "Digitando…" nem status de processamento', not any('Digitando' in x['t'] or 'Analisando' in x['t'] or 'Pensando' in x['t'] for x in hd) and all(x['st']==0 for x in hd), [x for x in hd if x['st'] or 'Digitando' in x['t']][:2])
        check(f'chat {nome}: o cabeçalho não muda de tamanho durante o envio', len(alt)==1 and len(altb)==1, (alt,altb))
        check(f'chat {nome}: o indicador de processamento continua dentro da conversa', meio['ind'] and any(x['ind'] for x in hd), meio)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])  # #418: aviso de hidratação que já existia (igual aos outros testes)
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
