# Acompanhamentos integrados a Tarefas → Pendentes, pela tela real: um pedido concluído gera o acompanhamento E a tarefa
# "Acompanhar <cliente> — <serviço>" (motivo, cliente, serviço e data prevista); o cartão do chat aponta para a tarefa;
# Adiar / Concluir no chat mudam a MESMA tarefa (sem duplicar) e a página de Tarefas mostra o estado certo.
# Servidor: run_srv.sh 4369 /tmp/ma-fuptar.db (banco novo)
import io, json, sys, sqlite3, base64, re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4369'; DBF = '/tmp/ma-fuptar.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
N = lambda t: re.sub(r'\s+', ' ', str(t).replace('\xa0', ' ')).strip()
def val(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchone(); db.close(); return r[0] if r else None
def run(q, *a):
    db = sqlite3.connect(DBF); c = db.execute(q, a); db.commit(); i = c.lastrowid; db.close(); return i
TIT = 'Acompanhar Monalisa — Piercing argola'
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    D = b.new_context(viewport={'width': 390, 'height': 844}, base_url=BASE, is_mobile=True, has_touch=True); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Wes Tattoo', 'whatsapp': '+55 11 94444-7777', 'email': 'wes.fup@t.com', **U}).ok
    assert R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True}).ok
    r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Ivaslovck Studio', 'categoria': 'Estúdio de tatuagem e piercing', 'titulo': 'Studio', 'texto': 'Tattoo e piercing', 'zap': '5511999990000', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
    ID = r.json()['items'][0]['id']; uid = val('select owner_id from businesses where id=?', ID)
    run("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", ID)
    dados = {'tipo': 'pedido', 'modo': 'retirada', 'nome': 'Monalisa', 'telefone': '11988887777', 'itens': [{'nome': 'Piercing argola', 'qtd': 1, 'preco': 80}]}
    oid = run("insert into orders (business_id, customer_id, status, total, data, created_at, updated_at) values (?,?,?,?,?,datetime('now'),datetime('now'))", ID, uid, 'pronto', 80, json.dumps(dados))
    r = R.post(f'/api/v2/ads/{ID}/orders/{oid}', data={'status': 'concluido'}); assert r.ok, r.text()
    fid = val('select id from followups where order_id=?', oid); tid = val('select task_id from followups where id=?', fid)
    tarefas = lambda: [t for t in R.get('/api/agenda').json().get('tasks', []) if t['title'].startswith('Acompanhar Monalisa')]
    ts = tarefas()
    check('pedido concluído gera a tarefa em Tarefas → Pendentes (título, motivo, data prevista)', fid and tid and len(ts) == 1 and ts[0]['title'] == TIT and ts[0]['status'] == 'pending' and ts[0].get('dueDate') and 'cicatriza' in (ts[0].get('notes') or ''), ts)
    venc0 = ts[0]['dueDate'] if ts else None
    pg = D.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(1000)
    if pg.locator('button:has-text("Agora não")').count(): pg.locator('button:has-text("Agora não")').first.click(); pg.wait_for_timeout(300)
    n0 = pg.locator('.chat-scroll .msg-bubble').count()
    pg.fill('textarea[data-composer-input]', f'acompanhamento #{fid}'); pg.locator('button[aria-label="Enviar"]').click()
    pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_selector('[data-fup-tarefa]', timeout=10000); pg.wait_for_timeout(600)
    lk = N(pg.inner_text('[data-fup-tarefa]'))
    check('cartão do chat mostra o motivo e o link "Em Tarefas → Pendentes"', 'Em Tarefas → Pendentes' in lk and 'prevista para' in lk and pg.locator('.ma-pc', has_text='cicatrização').count() >= 1, lk)
    pg.screenshot(path='/tmp/e2e/fup_card_tarefa.png')
    # página de Tarefas: aparece uma única vez
    pg.goto('/agenda?tab=tarefas'); pg.wait_for_timeout(2500)
    qtd = pg.locator(f'text={TIT}').count()
    check('página Tarefas → Pendentes mostra a tarefa (uma vez)', qtd == 1, qtd)
    pg.screenshot(path='/tmp/e2e/fup_tarefas_pendentes.png')
    # adiar pelo chat: a MESMA tarefa muda de data
    pg.goto('/'); pg.wait_for_selector('textarea.composer-input', timeout=20000); pg.wait_for_timeout(800)
    n0 = pg.locator('.chat-scroll .msg-bubble').count()
    pg.fill('textarea[data-composer-input]', f'acompanhamento #{fid}'); pg.locator('button[aria-label="Enviar"]').click()
    pg.wait_for_function(f"()=>document.querySelectorAll('.chat-scroll .msg-bubble').length>={n0 + 2}", timeout=20000); pg.wait_for_timeout(1000)
    pg.locator('[data-fs="adiado"]').last.click(); pg.wait_for_timeout(1500)
    ts = tarefas()
    check('Adiar no chat muda a data da MESMA tarefa (sem duplicar)', len(ts) == 1 and ts[0]['id'] == tid and ts[0]['dueDate'] != venc0 and ts[0]['status'] == 'pending', (ts, venc0))
    pg.locator('[data-fs="concluido"]').last.click(); pg.wait_for_timeout(1500)
    ts = tarefas()
    check('Concluir no chat conclui a tarefa', len(ts) == 1 and ts[0]['status'] == 'done' and val('select status from followups where id=?', fid) == 'concluido', ts)
    check('o cartão passa a dizer "Concluída em Tarefas"', 'Concluída em Tarefas' in N(pg.locator('[data-fup-tarefa]').last.inner_text()))
    pg.goto('/agenda?tab=tarefas'); pg.wait_for_timeout(2500)
    vis = pg.evaluate(f"""()=>[...document.querySelectorAll('*')].filter(e=>e.children.length===0&&e.textContent.trim()==={json.dumps(TIT)}).map(e=>e.closest('li,article,div')?.innerText||'')""")
    check('em Tarefas a tarefa não está mais entre as pendentes', not any('Concluir' in v and 'Concluída' not in v for v in vis), vis)
    pg.screenshot(path='/tmp/e2e/fup_tarefas_concluida.png')
    check('sem rolagem lateral e sem erros de JavaScript', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1 and not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
