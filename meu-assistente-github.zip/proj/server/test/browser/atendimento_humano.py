# Atendimento humano de ponta a ponta, pela tela. Cobre:
#   - Cliente (visitante, página do agente): pedir para "falar com uma pessoa" → formulário no chat → abrir com print e PDF
#     → conversa dedicada.
#   - Empresa (Sua empresa): botão flutuante com contador → lista (cliente, motivo, status, última mensagem, anexos) →
#     conversa → ver imagem → responder com arquivo → status.
#   - O cliente vê a resposta sozinho (sem recarregar), responde, e o contador da empresa volta a subir; encerrar e reabrir.
#   - O menu ⋮ do topo do agente leva ao Atendimento e sinaliza as respostas novas.
#   - Celular e computador, tema escuro e claro, sem rolagem lateral; sem erros de JavaScript.
# Servidor: PORT=4402 SQLITE_FILE=/tmp/ma-atend.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, datetime, base64, io
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4402'; DBF = '/tmp/ma-atend.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:400]))
def db(sql, args=()):
    c = sqlite3.connect(DBF); r = c.execute(sql, args).fetchall(); c.commit(); c.close(); return r
def png(cor):
    b = io.BytesIO(); Image.new('RGB', (240, 160), cor).save(b, 'PNG'); return b.getvalue()
PDF = b'%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF'
U = {'birthday': '1985-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    A = b.new_context(base_url=BASE); assert A.request.post('/api/auth', data={'action': 'signup', 'name': 'Admin Atend', 'whatsapp': '+55 11 94444-0101', 'email': 'admin.atend@t.com', **U}).ok
    A.request.put('/api/panel/modules', data={'agente': True, 'catalogo': True, 'empresas': True})
    D = b.new_context(base_url=BASE); R = D.request
    assert R.post('/api/auth', data={'action': 'signup', 'name': 'Rita Dona', 'whatsapp': '+55 85 95555-0102', 'email': 'rita.atend@t.com', **U}, headers={'X-Forwarded-For': '10.11.0.2'}).ok
    ID = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': 'Doces da Rita', 'categoria': 'Doceria', 'titulo': 't', 'texto': 'x', 'zap': '5585955550102', 'tipo': 'produtos', 'endereco': 'Rua D, 40'}).json()['items'][0]['id']
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); db("update businesses set data=?, status='ativo', expires_at=? where id=?", (json.dumps(d), (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat(), ID))
    assert R.put(f'/api/v2/ads/{ID}', data={'horarioCfg': {'modo': 'aberto', 'dias': {}}}).ok and R.put(f'/api/v2/ads/{ID}/agent', data={'ativo': True}).ok
    d = json.loads(db('select data from businesses where id=?', (ID,))[0][0]); d['agente']['expiresAt'] = (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=30)).isoformat().replace('+00:00', 'Z'); db('update businesses set data=? where id=?', (json.dumps(d), ID))
    for vez, (nome, vp, mob, tema) in enumerate([('celular', {'width': 390, 'height': 844}, True, 'dark'), ('computador', {'width': 1280, 'height': 900}, False, 'light')]):
        print('==', nome, tema)
        # ---------- cliente (visitante) ----------
        cc = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, color_scheme=tema, accept_downloads=True); cl = cc.new_page(); cl.on('pageerror', lambda e: errs.append('cliente: ' + str(e)))
        cl.goto(f'/a/{ID}'); cl.wait_for_selector('#acts button', timeout=20000); cl.wait_for_timeout(500)
        cl.fill('#t', 'Quero falar com uma pessoa, minha encomenda veio amassada'); cl.click('#b')
        cl.wait_for_selector('[data-at-form]', timeout=10000); cl.wait_for_timeout(300)
        ult = cl.locator('#chat .m.a').evaluate_all('es=>es.map(e=>e.textContent)'); tx = cl.locator('[data-at-texto]').input_value()
        check(f'{nome}: o agente reconhece o pedido e abre o formulário no chat (sem pesquisa)', any('atendimento' in u.lower() and 'equipe' in u.lower() for u in ult) and tx.startswith('Quero falar'), (ult[-2:], tx))
        cl.fill('[data-at-texto]', f'Minha encomenda de brigadeiros veio amassada ({nome}).'); cl.fill('[data-at-nome]', f'Paula {nome}'); cl.fill('[data-at-contato]', '85 98888-7777')
        cl.set_input_files('[data-at-form] [data-at-file]', [{'name': 'caixa.png', 'mimeType': 'image/png', 'buffer': png((200, 60, 60))}, {'name': 'pedido.pdf', 'mimeType': 'application/pdf', 'buffer': PDF}])
        check(f'{nome}: anexos aparecem antes de enviar (2)', cl.locator('[data-at-form] [data-at-arq]').count() == 2)
        cl.click('[data-at-abrir]'); cl.wait_for_selector('.at-ov [data-at-msgs] [data-autor=cliente]', timeout=10000); cl.wait_for_timeout(800)
        prot = cl.inner_text('[data-at-prot]').split(' ·')[0]
        check(f'{nome}: chamado aberto — confirmação no chat e conversa dedicada com status "Aberto"', prot.startswith('AT-') and cl.inner_text('[data-at-st]') == 'Aberto' and 'Abri o atendimento' in cl.inner_text('#chat'), prot)
        check(f'{nome}: na conversa, a imagem enviada aparece (carregada com a chave) e o PDF como arquivo', cl.locator('.at-ov img[data-at-img]').evaluate('i=>i.naturalWidth') == 240 and 'pedido.pdf' in cl.inner_text('.at-ov'))
        ow = cl.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: conversa sem rolagem lateral', ow <= 1, ow)
        cl.screenshot(path=f'/tmp/e2e/atend_cliente_{nome}.png')
        aid = int(db('select id from atendimentos where protocolo=?', (prot,))[0][0])
        # ---------- empresa ----------
        ec = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, color_scheme=tema)
        assert ec.request.post('/api/auth', data={'action': 'login', 'email': 'rita.atend@t.com', 'password': U['password']}).ok
        ec.request.patch('/api/me', data={'settings': {'theme': tema}})  # tema do painel vem da preferência da conta (padrão escuro)
        em = ec.new_page(); em.on('pageerror', lambda e: errs.append('empresa: ' + str(e)))
        em.goto('/x/sua-empresa'); em.wait_for_selector('[data-atp-fab]', timeout=20000); em.wait_for_timeout(500)
        n0 = em.inner_text('[data-atp-n]')
        check(f'{nome}: botão flutuante com contador (1 chamado pendente)', n0 == '1', n0)
        fb = em.locator('[data-atp-fab]').bounding_box(); nav = em.locator('.ma-nav').bounding_box() if em.locator('.ma-nav').count() else None
        check(f'{nome}: botão não cobre a navegação inferior', not nav or fb['y'] + fb['height'] <= nav['y'] + 1 or fb['x'] >= nav['x'] + nav['width'], (fb, nav))
        em.click('[data-atp-fab]'); em.wait_for_selector(f'[data-atp-abre="{aid}"]', timeout=8000)
        li = em.inner_text(f'[data-atp-abre="{aid}"]')
        check(f'{nome}: lista com cliente, motivo, status, última mensagem e anexos', f'Paula {nome}' in li and 'amassada' in li and 'Aberto' in li and em.locator(f'[data-atp-abre="{aid}"] [data-atp-anexos="2"]').count() == 1 and em.locator(f'[data-atp-abre="{aid}"] [data-atp-nl]').count() == 1, li)
        em.click(f'[data-atp-abre="{aid}"]'); em.wait_for_selector('[data-atp-conv] [data-autor=cliente]', timeout=8000); em.wait_for_timeout(900)
        check(f'{nome}: empresa abre a conversa e vê a imagem do cliente', em.locator('[data-atp-conv] img[data-atp-img]').evaluate('i=>i.naturalWidth') == 240 and '85 98888-7777' in em.inner_text('[data-atp-sub]'))
        with em.expect_download() as dl: em.click('[data-atp-conv] [data-atp-doc]')
        check(f'{nome}: empresa baixa o PDF do cliente', open(dl.value.path(), 'rb').read().startswith(b'%PDF') and dl.value.suggested_filename == 'pedido.pdf')
        em.fill('[data-atp-txt]', 'Oi Paula! Sentimos muito. Vamos enviar outra caixa hoje.')
        em.set_input_files('[data-atp-file]', [{'name': 'cupom.png', 'mimeType': 'image/png', 'buffer': png((40, 160, 90))}])
        em.click('[data-atp-env]'); em.wait_for_selector('[data-atp-conv] [data-autor=empresa]', timeout=8000); em.wait_for_timeout(500)
        check(f'{nome}: resposta com arquivo enviada e status vira "Em atendimento"', em.inner_text('[data-atp-st]') == 'Em atendimento' and em.locator('[data-atp-conv] [data-autor=empresa] img').count() == 1)
        em.wait_for_timeout(600); check(f'{nome}: contador zera depois de responder', 'zero' in em.locator('[data-atp-fab]').get_attribute('class'))
        em.screenshot(path=f'/tmp/e2e/atend_empresa_{nome}.png')
        # ---------- cliente recebe sem recarregar, responde ----------
        cl.wait_for_selector('.at-ov [data-autor=empresa]', timeout=12000); cl.wait_for_timeout(600)
        check(f'{nome}: cliente vê a resposta e a imagem da empresa sozinho (sem recarregar)', 'outra caixa' in cl.inner_text('.at-ov') and cl.inner_text('[data-at-st]') == 'Em atendimento' and cl.locator('.at-ov [data-autor=empresa] img').evaluate('i=>i.naturalWidth') == 240)
        cl.fill('[data-at-txt]', 'Obrigada! Fico no aguardo.'); cl.click('[data-at-env]'); cl.wait_for_timeout(800)
        check(f'{nome}: mensagem do cliente aparece na conversa', 'Fico no aguardo' in cl.inner_text('.at-ov'))
        em.wait_for_selector('[data-atp-conv] [data-autor=cliente] >> text=Fico no aguardo', timeout=12000)
        check(f'{nome}: empresa recebe a nova mensagem com a conversa aberta (atualização automática)', True)
        em.click('[data-atp-st-set="atendido"]'); em.wait_for_timeout(700); check(f'{nome}: marcar como atendido', em.inner_text('[data-atp-st]') == 'Atendido')
        em.click('[data-atp-st-set="encerrado"]'); em.wait_for_timeout(700); check(f'{nome}: encerrar', em.inner_text('[data-atp-st]') == 'Encerrado')
        cl.wait_for_function("document.querySelector('[data-at-st]').textContent==='Encerrado'", timeout=12000); check(f'{nome}: cliente vê "Encerrado"', True)
        em.click('[data-atp-st-set="aberto"]'); em.wait_for_timeout(700); check(f'{nome}: reabrir', em.inner_text('[data-atp-st]') == 'Aberto')
        # botão do topo do agente com o número de respostas novas (depois de fechar a conversa)
        cl.wait_for_timeout(4600); cl.locator('[data-at-x]').click(); cl.wait_for_timeout(300)  # a conversa aberta já leu o aviso de reabertura
        em.fill('[data-atp-txt]', 'Saiu para entrega!'); em.click('[data-atp-env]'); em.wait_for_timeout(700)
        cl.evaluate('window.maAtend.badge()')
        try: cl.wait_for_function("!!document.querySelector('[data-hd-menu] i')", timeout=8000); cl.click('[data-hd-menu]'); cl.wait_for_selector('[data-hd-op=atendimento] em', timeout=4000); okb = cl.inner_text('[data-hd-op=atendimento] em') == '1'
        except Exception: okb = False
        check(f'{nome}: menu ⋮ do topo do agente sinaliza a resposta nova em "Atendimento"', okb, cl.evaluate("(document.querySelector('#hd')||{}).outerHTML")[:300])
        cl.keyboard.press('Escape'); cl.reload(); cl.wait_for_selector('[data-hd-menu]', timeout=15000); cl.click('[data-hd-menu]'); cl.click('[data-hd-op=atendimento]'); cl.wait_for_selector('.at-ov [data-at-msgs] [data-autor=empresa]', timeout=8000)
        check(f'{nome}: histórico preservado depois de recarregar (visitante, pela chave do navegador)', 'Saiu para entrega' in cl.inner_text('.at-ov') and 'brigadeiros' in cl.inner_text('.at-ov'))
        ow = em.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: painel sem rolagem lateral', ow <= 1, ow)
        cc.close(); ec.close()
    # 'Event' = folha de fontes do Google sem rede no ambiente de teste
    E = [e for e in errs if '#418' not in e and not e.endswith(': Event')]; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
