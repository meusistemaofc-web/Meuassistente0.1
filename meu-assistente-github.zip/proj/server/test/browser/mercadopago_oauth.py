# Mercado Pago (OAuth) de ponta a ponta no navegador: o dono toca em "Conectar minha conta Mercado Pago", é levado à
# autorização do Mercado Pago, autoriza e volta sozinho ao Meu Assistente; status Conectado / Desconectado / Erro na
# conexão, dados da conta, verificar, reconectar, desconectar; retorno sem sessão (celular: app do Mercado Pago).
# Servidor e dublê do Mercado Pago (o contêiner de testes não alcança mercadopago.com):
#   python3 test/browser/mercadopago_fake.py 4399 http://localhost:4311/api/mercadopago/oauth/callback pkce
#   MP_API_BASE=http://127.0.0.1:4399 MP_AUTH_BASE=http://127.0.0.1:4399 PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts
import sys, json, sqlite3, datetime, urllib.request
from playwright.sync_api import sync_playwright
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); from _admin import aba
BASE='http://localhost:4311'; FAKE='http://127.0.0.1:4399'; DBF='/tmp/ma-teste.db'; res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:300]))
U={'birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}
iso=lambda d:(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(days=d)).isoformat().replace('+00:00','Z')
fk=lambda path: json.loads(urllib.request.urlopen(FAKE+path).read())
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    A=b.new_context(base_url=BASE,viewport={'width':1280,'height':900}); RA=A.request
    assert RA.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com',**U}).ok
    RA.put('/api/panel/site',data={'url':'http://localhost:4311'})
    sistema=RA.get('/api/panel').json().get('mercadopago')
    # painel: aplicação do OAuth (separada das credenciais manuais do sistema), ambiente de teste e PKCE
    pa=A.new_page(); pa.on('pageerror',lambda e:errs.append(str(e))); pa.goto('/admin'); pa.wait_for_timeout(2500)
    aba(pa,'Mercado Pago'); pa.wait_for_selector('#mo_id',timeout=10000)
    check('painel: URL de redirecionamento exibida para cadastrar na aplicação', pa.locator('input[readonly]').first.input_value()=='http://localhost:4311/api/mercadopago/oauth/callback')
    pa.fill('#mo_id','1234567890123456'); pa.fill('#mo_sc','segredo-da-aplicacao-de-teste'); pa.select_option('#mo_amb','teste'); pa.check('#mo_pk')
    pa.click('#mo_t'); pa.wait_for_timeout(1500)
    check('painel: "Testar credenciais" valida a aplicação no Mercado Pago', 'Credenciais válidas' in pa.inner_text('#mo_m'), pa.inner_text('#mo_m'))
    cfg=RA.get('/api/panel').json()
    check('painel: PKCE e ambiente de teste salvos; credenciais manuais do sistema intactas', cfg['mp_oauth']['pkce'] is True and cfg['mp_oauth']['ambiente']=='teste' and cfg.get('mercadopago')==sistema and 'segredo-da-aplicacao' not in json.dumps(cfg))
    pa.screenshot(path='/tmp/e2e/mp_painel.png')
    db=sqlite3.connect(DBF)
    def dono(nome,email,ip,plano,empresa):
        c=b.new_context(base_url=BASE,viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2); R=c.request
        assert R.post('/api/auth',data={'action':'signup','name':nome,'whatsapp':'+55 11 95555-0'+ip,'email':email,**U},headers={'X-Forwarded-For':'10.7.7.'+ip}).ok
        i=R.post('/api/v2/ads',data={'planId':plano,'empresa':empresa,'categoria':'Doceria','titulo':'Doces','texto':'Doces artesanais','zap':'5511999990000'}).json()['items'][0]['id']
        db.execute("update businesses set status='ativo', expires_at=? where id=?",(iso(30),i)); db.commit(); return c,R,i
    D,RD,ID=dono('Dona Lu','lu@t.com','101','n4','Doceria da Lu')
    pg=D.new_page(); pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
    def abrir():
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(3500)
        if not pg.locator('[data-lt2="entrega"]').count(): pg.locator('.ma-nav button').last.click(); pg.wait_for_timeout(1200)
        pg.locator('[data-lt2="entrega"]').click(); pg.wait_for_selector('[data-mp-status]',timeout=15000)
    abrir()
    op=pg.inner_text('[data-mp-opcoes]')
    check('dono: "Desconectado" com as DUAS opções — Conexão automática (Recomendada) e Conexão manual — sem formulário aberto', pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='desconectado' and pg.locator('[data-mp-opcao]').count()==2 and 'Recomendada' in pg.inner_text('[data-mp-opcao="automatica"]') and pg.locator('[data-mp-oauth]').inner_text()=='Conectar automaticamente' and pg.locator('[data-mp-manual]').inner_text()=='Conectar manualmente' and pg.locator('#mpk').count()==0, op)
    lado=pg.evaluate("()=>{const a=document.querySelector('[data-mp-opcao=\"automatica\"]').getBoundingClientRect(),m=document.querySelector('[data-mp-opcao=\"manual\"]').getBoundingClientRect();return [Math.round(a.top),Math.round(m.top),document.documentElement.scrollWidth-innerWidth]}")
    check('celular: as duas opções uma sobre a outra, sem rolagem lateral', lado[1]>lado[0] and lado[2]<=1, lado)
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_desconectado.png')
    # 1) toca no botão → vai ao Mercado Pago (dublê) → autoriza → volta sozinho
    pg.route('**/authorization?**',lambda r: r.continue_(url=r.request.url+'&conta=loja1'))
    pg.click('[data-mp-oauth]'); pg.wait_for_url('**/x/sua-empresa**',timeout=15000); pg.wait_for_selector('[data-mp-aviso="ok"]',timeout=15000); pg.wait_for_timeout(800)
    lg=fk('/__log'); au=[x for x in lg if x['tipo']=='authorization'][-1]; tk=[x for x in lg if x['tipo']=='token' and x.get('grant_type')=='authorization_code'][-1]
    check('autorização oficial: client_id, response_type=code, platform_id=mp, state e PKCE S256', au['response_type']=='code' and au['platform_id']=='mp' and len(au['state'])>=32 and au.get('code_challenge_method')=='S256', au)
    check('retorno: código trocado por tokens no servidor (code_verifier, test_token e redirect_uri exato)', tk.get('test_token') in (True,'true') and len(tk.get('code_verifier',''))>=43 and tk['redirect_uri']=='http://localhost:4311/api/mercadopago/oauth/callback', tk)
    t=pg.inner_text('[data-mp-box]')
    check('dono: "Conectado" com os dados da conta (apelido, nome, e-mail mascarado, ID, ambiente de teste)', 'LOJADALU' in t and 'Lu Vendas' in t and 'lu***@exemplo.com' in t and '1001' in t and 'ambiente de teste' in t and 'renovação automática' in t, t)
    check('tokens nunca aparecem na tela', 'TEST-' not in pg.content() and 'TG-' not in pg.content())
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_conectado.png')
    pg.click('[data-mp-ver]'); pg.wait_for_timeout(1200); check('"Verificar conexão" confirma na API oficial', 'Conectado à conta LOJADALU' in pg.inner_text('#mpm'), pg.inner_text('#mpm'))
    # 2) celular: autoriza no app do Mercado Pago e volta em outro navegador (sem sessão) → conecta mesmo assim
    url=RD.post(f'/api/v2/ads/{ID}/mp',data={'action':'oauth'}).json()['url']
    X=b.new_context(base_url=BASE); px=X.new_page(); px.goto(url+'&conta=loja1'); px.wait_for_timeout(1500)
    ok=db.execute("select dados from empresa_integracoes where business_id=? and provedor='mercadopago'",(ID,)).fetchone()[0]; d=json.loads(ok)  # credenciais ficam na integração da empresa (migração 057)
    check('retorno em outro navegador (sem a sessão) também conecta a empresa certa', d.get('mpModo')=='oauth' and d.get('mpStatus')=='conectado' and d.get('mpUserId')==1001 and ('/entrar' in px.url or '/x/sua-empresa' in px.url), px.url)
    # 3) o dono revoga no Mercado Pago → "Erro na conexão" + Reconectar
    fk('/__revogar'); pg.click('[data-mp-ver]'); pg.wait_for_selector('[data-mp-status="erro"]',timeout=10000)
    check('autorização revogada: status "Erro na conexão", motivo e botão "Reconectar"', 'Erro na conexão' in pg.inner_text('[data-mp-box]') and pg.locator('[data-mp-erro]').count()==1 and 'Reconectar' in pg.locator('[data-mp-oauth]').inner_text())
    pg.locator('[data-mp-box]').scroll_into_view_if_needed(); pg.screenshot(path='/tmp/e2e/mp_erro.png')
    pg.click('[data-mp-oauth]'); pg.wait_for_url('**/x/sua-empresa**',timeout=15000); pg.wait_for_selector('[data-mp-status="conectado"]',timeout=15000)
    check('reconectar volta a "Conectado"', pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='conectado')
    # 4) cancelar no Mercado Pago mostra a mensagem certa e não derruba a conexão
    pg.unroute('**/authorization?**'); pg.route('**/authorization?**',lambda r: r.continue_(url=r.request.url+'&negar=1'))
    pg.click('[data-mp-trocar]'); pg.wait_for_selector('[data-mp-opcoes]')
    check('conectado: "Trocar conta ou forma de conexão" mostra as duas opções de novo', pg.locator('[data-mp-opcao]').count()==2 and pg.locator('[data-mp-oauth]').inner_text()=='Conectar outra conta')
    pg.click('[data-mp-oauth]'); pg.wait_for_selector('[data-mp-aviso="erro"]',timeout=15000)
    check('cancelou no Mercado Pago: aviso claro e a conta continua conectada', 'cancelou a autorização' in pg.inner_text('#mpm') and pg.locator('[data-mp-status]').get_attribute('data-mp-status')=='conectado')
    # 5) outra empresa conecta a própria conta; não usa a mesma conta de outra dona
    D2,RD2,ID2=dono('Dono Beto','beto@t.com','102','n4','Lanches do Beto')
    u2=RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'oauth'}).json()['url']; p2=D2.new_page(); p2.goto(u2+'&conta=loja1'); p2.wait_for_selector('[data-mp-aviso]',timeout=15000)
    check('a mesma conta Mercado Pago não fica vinculada a duas empresas de donos diferentes', 'já recebe por outra empresa' in p2.inner_text('#mpm') and p2.locator('[data-mp-status]').get_attribute('data-mp-status')=='desconectado', p2.inner_text('[data-mp-box]')[:300])
    u3=RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'oauth'}).json()['url']; p2.goto(u3+'&conta=loja2'); p2.wait_for_selector('[data-mp-status="conectado"]',timeout=15000)
    check('segunda empresa conectada à própria conta (BETOLANCHES)', 'BETOLANCHES' in p2.inner_text('[data-mp-box]'))
    check('isolamento: uma empresa não vê nem desconecta a conexão da outra', RD2.post(f'/api/v2/ads/{ID}/mp',data={'action':'status'}).status==404 and RD2.post(f'/api/v2/ads/{ID}/mp',data={'action':'remove'}).status==404)
    # 6) desconectar
    pg.unroute('**/authorization?**'); pg.click('[data-mp-off]'); pg.wait_for_selector('[data-mp-status="desconectado"]',timeout=10000)
    d=json.loads(db.execute("select dados from empresa_integracoes where business_id=? and provedor='mercadopago'",(ID,)).fetchone()[0]); d0=json.loads(db.execute('select data from businesses where id=?',(ID,)).fetchone()[0])
    check('desconectar: status "Desconectado" e tokens apagados só desta empresa', not d.get('mpTok') and not d.get('mpRefresh') and not d0.get('mpTok') and RD2.post(f'/api/v2/ads/{ID2}/mp',data={'action':'status'}).json()['mpStatus']=='conectado')
    # 6b) conexão MANUAL pela tela (outra empresa, outro dono): credencial recusada, credencial válida, troca e desconexão
    D4,RD4,ID4=dono('Dona Cris','cris3@t.com','104','n4','Bazar da Cris'); fk('/__manual?tok=APP_USR-crisbazar-manual-0001&conta=loja3')
    p4=D4.new_page(); p4.on('pageerror',lambda e:errs.append(str(e))); p4.on('dialog',lambda d:d.accept())
    p4.goto('/x/sua-empresa'); p4.wait_for_timeout(3500)
    if not p4.locator('[data-lt2="entrega"]').count(): p4.locator('.ma-nav button').last.click(); p4.wait_for_timeout(1200)
    p4.locator('[data-lt2="entrega"]').click(); p4.wait_for_selector('[data-mp-manual]',timeout=15000)
    p4.click('[data-mp-manual]'); p4.wait_for_selector('#mpk')
    f=p4.inner_text('[data-mp-form-manual]')
    check('manual: formulário pede só o Access Token (e a chave das notificações, opcional) e explica que a Public Key não é necessária', p4.locator('[data-mp-form-manual] input').count()==2 and 'Public Key não é necessária' in f and p4.get_attribute('#mpk','type')=='password', f[:200])
    p4.fill('#mpk','APP_USR-token-que-nao-existe-123'); p4.click('[data-mp-man]'); p4.wait_for_timeout(1500)
    check('manual: credencial recusada mostra o motivo e nada é conectado', 'recusou' in p4.inner_text('#mpm') and p4.locator('[data-mp-status]').get_attribute('data-mp-status')=='desconectado' and p4.input_value('#mpk')=='', p4.inner_text('#mpm'))
    p4.fill('#mpk','APP_USR-crisbazar-manual-0001'); p4.click('[data-mp-man]'); p4.wait_for_selector('[data-mp-status="conectado"]',timeout=15000)
    t4=p4.inner_text('[data-mp-box]')
    check('manual: conectado, com "Conexão manual", a conta conferida no Mercado Pago (CRISBAZAR, ID 3003) e o token só mascarado', 'conexão manual' in t4.lower() and 'CRISBAZAR' in t4 and '3003' in t4 and 'crisbazar-manual-0001' not in p4.content() and 'Conferindo' not in p4.inner_text('#mpm'), t4[:300])
    st=json.loads(db.execute("select dados from empresa_integracoes where business_id=? and provedor='mercadopago'",(ID4,)).fetchone()[0])
    ls=p4.evaluate("()=>JSON.stringify(localStorage)+JSON.stringify(sessionStorage)")
    check('manual: credencial cifrada no servidor e nada dela no navegador (localStorage/sessionStorage)', st.get('mpModo')=='manual' and st.get('mpUserId')==3003 and 'APP_USR' not in st.get('mpTok','') and 'crisbazar-manual' not in ls)
    p4.screenshot(path='/tmp/e2e/mp_manual_conectado_celular.png',full_page=False)
    p4.click('[data-mp-trocar]'); p4.click('[data-mp-manual]'); p4.wait_for_selector('#mpk'); fk('/__manual?tok=APP_USR-crisbazar-manual-0002&conta=loja3')
    p4.fill('#mpk','APP_USR-crisbazar-manual-0002'); p4.click('[data-mp-man]'); p4.wait_for_timeout(1800)
    st2=json.loads(db.execute("select dados from empresa_integracoes where business_id=? and provedor='mercadopago'",(ID4,)).fetchone()[0])
    check('manual: substituir as credenciais mantém a conexão e troca o token', st2.get('mpTok')!=st.get('mpTok') and p4.locator('[data-mp-status]').get_attribute('data-mp-status')=='conectado')
    # pendente: autorização automática iniciada e não concluída (fechou o Mercado Pago) → "Pendente", Continuar e Cancelar
    p4.click('[data-mp-off]'); p4.wait_for_selector('[data-mp-status="desconectado"]',timeout=10000)
    RD4.post(f'/api/v2/ads/{ID4}/mp',data={'action':'oauth'}); p4.reload(); p4.wait_for_timeout(3000)
    if not p4.locator('[data-mp-status]').count():
        if not p4.locator('[data-lt2="entrega"]').count(): p4.locator('.ma-nav button').last.click(); p4.wait_for_timeout(1200)
        p4.locator('[data-lt2="entrega"]').click()
    p4.wait_for_selector('[data-mp-status="pendente"]',timeout=15000)
    check('pendente: conexão automática iniciada e não concluída aparece como "Pendente", com Continuar e Cancelar', 'Pendente' in p4.inner_text('[data-mp-box]') and p4.locator('[data-mp-pendente="automatica"] [data-mp-oauth]').count()==1 and p4.locator('[data-mp-cancelar]').count()==1)
    p4.locator('[data-mp-box]').screenshot(path='/tmp/e2e/mp_pendente_celular.png')
    p4.click('[data-mp-cancelar]'); p4.wait_for_selector('[data-mp-status="desconectado"]',timeout=10000)
    check('pendente: Cancelar volta a "Desconectado" com as duas opções', p4.locator('[data-mp-opcao]').count()==2)
    # computador: as duas opções lado a lado
    W=b.new_context(base_url=BASE,viewport={'width':1280,'height':900}); W.add_cookies(D4.cookies()); pw=W.new_page(); pw.on('pageerror',lambda e:errs.append(str(e)))
    pw.goto('/x/sua-empresa'); pw.wait_for_timeout(3500)
    if not pw.locator('[data-lt2="entrega"]').count(): pw.locator('.ma-nav button').last.click(); pw.wait_for_timeout(1200)
    pw.locator('[data-lt2="entrega"]').click(); pw.wait_for_selector('[data-mp-opcao="manual"]',timeout=15000)
    lado=pw.evaluate("()=>{const a=document.querySelector('[data-mp-opcao=\"automatica\"]').getBoundingClientRect(),m=document.querySelector('[data-mp-opcao=\"manual\"]').getBoundingClientRect();return [Math.round(a.top),Math.round(m.top),Math.round(a.left),Math.round(m.left),document.documentElement.scrollWidth-innerWidth]}")
    check('computador: as duas opções lado a lado, sem rolagem lateral', lado[0]==lado[1] and lado[3]>lado[2] and lado[4]<=1, lado)
    pw.locator('[data-mp-box]').scroll_into_view_if_needed(); pw.screenshot(path='/tmp/e2e/mp_opcoes_computador.png'); W.close()
    # 7) plano sem acesso
    D3,RD3,ID3=dono('Dona Cris','cris@t.com','103','n1','Bazar da Cris')
    check('plano sem acesso: servidor bloqueia a conexão', RD3.post(f'/api/v2/ads/{ID3}/mp',data={'action':'oauth'}).status==403)
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e!='Event'], errs[:4])
    b.close()
print(f"FIM {'OK' if all(res) else 'FALHOU'} {sum(res)}/{len(res)}"); sys.exit(0 if all(res) else 1)
