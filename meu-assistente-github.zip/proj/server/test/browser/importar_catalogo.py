# Importar catálogo pela tela real (Sua empresa → Produtos → Importar catálogo), celular e computador:
# botão com ícone do sistema (sem emoji), colar um catálogo inteiro em texto, prévia com categorias, variações (tamanho/cor),
# detalhes (marca, volume, composição), editar/excluir antes de cadastrar, cadastro em lote, falha parcial com
# "Revisar e cadastrar os pendentes" sem duplicar, produtos reais sem foto e cadastro manual preservado. Regras locais (sem IA).
# Servidor: run_srv.sh 4372 /tmp/ma-catalogo.db (banco novo)
import json, sys, sqlite3, re
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4372'; DBF = '/tmp/ma-catalogo.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123'}
def rows(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchall(); db.close(); return r
TEXTO = """CAMISETAS
Camiseta Básica - Tamanhos: P, M, G - Cores: preta, branca - R$ 49,90
Material: 100% algodão
Vestido Midi R$ 159,90
Cores: preta, preta
Regata Dry R$ 39,90

COSMÉTICOS
Shampoo Hidratante 300ml R$ 32,90
Marca: Bela Flor
Kit Barba (shampoo + óleo + balm) R$ 99,90
Item de teste para excluir R$ 1,00"""
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for nome, vp, mob in [('celular', {'width': 390, 'height': 844}, True), ('computador', {'width': 1280, 'height': 900}, False)]:
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Loja ' + nome, 'whatsapp': '+55 11 94444-' + ('7171' if mob else '7272'), 'email': f'cat.{nome}@t.com', **U}).ok
        R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})  # só o primeiro (administrador) pode; os módulos valem para todos
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Moda {nome}', 'categoria': 'Loja de roupas', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
        ID = r.json()['items'][0]['id']
        db = sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", (ID,)); db.commit(); db.close()
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
        pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('[data-mim=ia]', timeout=10000)
        bt = pg.evaluate("(()=>{const b=document.querySelector('[data-mim=ia]');return {txt:b.innerText.trim(),svg:!!b.querySelector('svg'),emoji:/[\\u2728\\u{1F300}-\\u{1FAFF}]/u.test(b.innerText)}})()")
        check(f'{nome}: botão "Importar catálogo" com ícone do sistema e sem emoji', bt['txt'] == 'Importar catálogo' and bt['svg'] and not bt['emoji'], bt)
        pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_colar', timeout=8000)
        check(f'{nome}: opções Colar texto, Fotografar, Imagens/prints e PDF/DOCX', all(pg.locator(s).count() == 1 for s in ['#mi_colar', '#mi_cam', '#mi_img', '#mi_doc']))
        pg.click('#mi_colar'); pg.fill('#mi_txt', TEXTO); pg.wait_for_timeout(300)
        check(f'{nome}: área de texto aceita o catálogo e mostra o tamanho', pg.is_enabled('#mi_go') and 'caracteres' in pg.inner_text('#mi_txtn'))
        pg.screenshot(path=f'/tmp/e2e/catalogo_{nome}_colar.png')
        pg.click('#mi_go'); pg.wait_for_selector('#mi_pub', timeout=30000); pg.wait_for_timeout(600)
        corpo = pg.inner_text('#mi_body')
        check(f'{nome}: prévia com categorias e itens lidos (nada cadastrado ainda)', 'CAMISETAS' in corpo.upper() and 'COSMÉTICOS' in corpo.upper() and 'nada foi cadastrado ainda' in corpo and not rows('select id from products where business_id=?', ID), corpo[:200])
        cam = pg.locator('.mi-item', has=pg.locator('input[data-f=nome][value="Camiseta Básica"]'))
        chips = cam.locator('[data-mi-vars]').inner_text() if cam.locator('[data-mi-vars]').count() else ''
        check(f'{nome}: variações de tamanho e cor visíveis na prévia', 'Tamanho' in chips and 'P, M, G' in chips and 'Cor' in chips and 'preta' in chips, chips)
        sh = pg.locator('.mi-item', has=pg.locator('input[data-f=nome][value="Shampoo Hidratante 300ml"]'))
        check(f'{nome}: detalhes lidos (Marca) editáveis', 'Marca: Bela Flor' in sh.locator('textarea[data-f=atr]').input_value())
        # editar preço e excluir um item da importação
        pr = pg.locator('.mi-item', has=pg.locator('input[data-f=nome][value="Regata Dry"]')).locator('input[data-f=preco]'); pr.fill('42,50'); pr.dispatch_event('change')
        pg.locator('.mi-item', has=pg.locator('input[data-f=nome][value="Item de teste para excluir"]')).locator('[data-del]').click(); pg.wait_for_timeout(1500)
        pg.screenshot(path=f'/tmp/e2e/catalogo_{nome}_previa.png', full_page=True)
        pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver', timeout=30000); pg.wait_for_timeout(500)
        txt = pg.inner_text('#mi_body')
        check(f'{nome}: cadastro em lote com pendência informada (1 item com falha, os demais cadastrados)', 'com pendências' in txt and 'Vestido Midi' in txt and pg.locator('[data-mi-falhas]').count() == 1, txt[:300])
        prods = {json.loads(d)['nome']: json.loads(d) for (d,) in rows('select data from products where business_id=?', ID)}
        check(f'{nome}: produtos reais, sem foto, com preço editado e sem o item excluído', set(prods) == {'Camiseta Básica', 'Regata Dry', 'Shampoo Hidratante 300ml', 'Kit Barba'} and prods['Regata Dry']['preco'] == 42.5 and all(not p.get('fotos') for p in prods.values()), list(prods))
        pid = [i for (i, d) in rows('select id, data from products where business_id=?', ID) if json.loads(d)['nome'] == 'Camiseta Básica'][0]
        check(f'{nome}: camiseta com as variações reais do catálogo (3 tamanhos × 2 cores)', len(rows('select id from product_variants where product_id=?', pid)) == 6)
        pg.screenshot(path=f'/tmp/e2e/catalogo_{nome}_resultado.png')
        # retomar: só o pendente volta para a revisão; os cadastrados ficam travados
        pg.click('#mi_ret'); pg.wait_for_selector('#mi_pub', timeout=15000); pg.wait_for_timeout(500)
        check(f'{nome}: retomada mostra os já cadastrados travados e o pendente com o motivo', pg.locator('[data-mi-pub]').count() == 4 and pg.locator('[data-mi-falha]').count() == 1)
        ve = pg.locator('.mi-item', has=pg.locator('input[data-f=nome][value="Vestido Midi"]'))
        ve.locator('summary').click() if not ve.locator('textarea[data-f=var]').is_visible() else None
        va = ve.locator('textarea[data-f=var]'); va.fill('Cor: Preta; Vinho'); va.dispatch_event('change'); pg.wait_for_timeout(1200)
        pg.click('#mi_pub'); pg.wait_for_selector('#mi_ver', timeout=30000); pg.wait_for_timeout(500)
        nomes = [json.loads(d)['nome'] for (d,) in rows('select data from products where business_id=?', ID)]
        check(f'{nome}: pendente cadastrado sem duplicar os outros', 'Importação concluída com sucesso' in pg.inner_text('#mi_body') and len(nomes) == 5 and len(set(nomes)) == 5, nomes)
        # cadastro manual preservado
        pg.click('[data-mim=manual]'); pg.wait_for_selector('#psave', state='visible', timeout=8000)
        check(f'{nome}: cadastro manual continua disponível', pg.locator('#pn').is_visible() and pg.locator('#ppr').is_visible())
        check(f'{nome}: sem rolagem lateral', pg.evaluate('document.documentElement.scrollWidth-innerWidth') <= 1)
        c.close()
    check('sem erros de JavaScript', not [e for e in errs if '#418' not in e and e != 'Event'], errs[:3])
    b.close()
print(f'\nResultado: {sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
