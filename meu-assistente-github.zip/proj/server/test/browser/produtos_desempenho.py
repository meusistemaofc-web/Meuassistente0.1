# Aba Produtos com muitos produtos (fotos reais, variações): mede o tamanho da resposta, o tempo até a lista aparecer e as
# tarefas longas do navegador (travamento), no celular e no computador; confere que a tela continua funcionando
# (editar abre com as fotos originais, ativar/desativar, duplicar, excluir) e que nenhum dado foi perdido.
# Servidor: PORT=4354 SQLITE_FILE=/tmp/ma-prod.db npx tsx test/serve-sqlite.ts (banco novo)
# Uso: python3 produtos_desempenho.py [qtd_produtos] [--so-medir]
import sqlite3, datetime, base64, io, sys, random, time, json, re
from PIL import Image
from playwright.sync_api import sync_playwright
BASE='http://localhost:4354'; DBF='/tmp/ma-prod.db'; res=[]
N=int(sys.argv[1]) if len(sys.argv)>1 and sys.argv[1].isdigit() else 150
SO='--so-medir' in sys.argv
def check(n,ok,d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ')+n+('' if ok else ' → '+repr(d)[:400]))
random.seed(7)
def foto(w,h,seed):  # JPEG com ruído (comprime mal, como foto de celular reduzida): ~300-550 KB em base64
    im=Image.effect_noise((w,h),60+seed%40).convert('RGB'); bf=io.BytesIO(); im.save(bf,'JPEG',quality=82); return 'data:image/jpeg;base64,'+base64.b64encode(bf.getvalue()).decode()
FOTOS=[foto(640,640,i) for i in range(6)]
print('foto de teste:', round(len(FOTOS[0])/1024),'KB (base64)')
with sync_playwright() as p:
    b=p.chromium.launch(); errs=[]
    a=b.new_context(base_url=BASE); A=a.request
    assert A.post('/api/auth',data={'action':'signup','name':'Admin Teste','whatsapp':'+55 11 94444-1234','email':'admin@t.com','birthday':'1985-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    assert A.put('/api/panel/modules',data={'empresas':True,'anuncios':True,'catalogo':True}).ok
    o=b.new_context(base_url=BASE); O=o.request
    assert O.post('/api/auth',data={'action':'signup','name':'Dono Loja','whatsapp':'+55 11 93330-1111','email':'dono@t.com','birthday':'1990-01-01','password':'Senha@Forte123','passwordConfirm':'Senha@Forte123'}).ok
    r=O.post('/api/v2/ads',data={'planId':'n4','empresa':'Moda Bella','categoria':'Roupas','titulo':'Moda Bella','texto':'Roupas','zap':'5511999990000','lat':-23.55,'lng':-46.63,'raio':10,'tipo':'produtos'}); assert r.ok, r.text()
    BID=r.json()['items'][0]['id']
    db=sqlite3.connect(DBF); db.execute("update businesses set status='ativo', expires_at=? where id=?",((datetime.datetime.now(datetime.UTC)+datetime.timedelta(days=30)).isoformat(),BID)); db.commit(); db.close()
    t0=time.time()
    # 10 produtos pelo cadastro real (com e sem variações); os demais são cópias dessas linhas reais no banco (o cadastro
    # devolve a lista inteira a cada produto, o que tornaria a montagem de 150 produtos lenta demais)
    for i in range(10):
        it={'nome':f'Produto {i+1:03d}','preco':round(19.9+i,2),'categoria':['Camisetas','Calças','Vestidos','Acessórios'][i%4],'fotos':[FOTOS[i%6],FOTOS[(i+1)%6]]}
        if i%5==0: it['variantes']=[{'cor':c,'preco':round(29.9+i,2),'fotos':[FOTOS[(i+k)%6]]} for k,c in enumerate(['Azul','Preto','Branco'])]
        rr=O.post(f'/api/v2/ads/{BID}/products',data=it); assert rr.ok, rr.text()[:200]
    db=sqlite3.connect(DBF); base=db.execute('select id,data,active,stock,created_at,updated_at from products where business_id=? order by id',(BID,)).fetchall()
    cols=[r[1] for r in db.execute('pragma table_info(products)')]
    for i in range(10,N):
        pid0,data,act,stk,ca,ua=base[i%10]; d=json.loads(data); d['nome']=f'Produto {i+1:03d}'; d['preco']=round(19.9+i,2)
        cur=db.execute('insert into products (business_id,data,active,stock,created_at,updated_at) values (?,?,?,?,?,?)',(BID,json.dumps(d),act,stk,ca,ua)); nid=cur.lastrowid
        for vr in db.execute('select position,data,stock,created_at,updated_at from product_variants where product_id=?',(pid0,)).fetchall():
            db.execute('insert into product_variants (product_id,business_id,position,data,stock,created_at,updated_at) values (?,?,?,?,?,?,?)',(nid,BID)+tuple(vr))
    db.commit(); db.close()
    print(f'{N} produtos prontos em {time.time()-t0:.0f}s')
    rr=O.get(f'/api/v2/ads/{BID}/products'); tam=len(rr.body()); itens=rr.json()['items']
    print(f'GET /products: {tam/1024/1024:.1f} MB, {len(itens)} itens')
    for nome,vp,mob in [('celular',{'width':390,'height':844},True),('computador',{'width':1280,'height':900},False)]:
        print('==',nome)
        c=b.new_context(viewport=vp,base_url=BASE,has_touch=mob,is_mobile=mob); c.add_cookies(o.cookies())
        if mob: c.set_extra_http_headers({})
        pg=c.new_page(); pg.on('pageerror',lambda e:errs.append(str(e)))
        cdp=c.new_cdp_session(pg)
        if mob: cdp.send('Emulation.setCPUThrottlingRate',{'rate':4}); cdp.send('Network.enable'); cdp.send('Network.emulateNetworkConditions',{'offline':False,'latency':80,'downloadThroughput':1.5e6,'uploadThroughput':7.5e5})
        pg.goto('/x/sua-empresa'); pg.wait_for_selector('.ma-nav [data-nav=produtos]',timeout=30000); pg.wait_for_timeout(800)
        pg.evaluate("""()=>{window.__lt=[];try{new PerformanceObserver(l=>{for(const e of l.getEntries())window.__lt.push(e.duration)}).observe({type:'longtask',buffered:false})}catch(e){}}""")
        bytes_prod=[0]
        def on_resp(r):
            if re.search(r'/products(\?|$)',r.url) and r.request.method=='GET':
                try: bytes_prod[0]+=len(r.body())
                except Exception: pass
        pg.on('response',on_resp)
        # tempo medido DENTRO da página: do clique até a primeira linha da lista existir (sem o atraso do Playwright)
        pg.evaluate("""()=>{window.__t={};document.addEventListener('click',e=>{if(e.target.closest('[data-nav=produtos]'))window.__t.c=performance.now()},true);new MutationObserver((m,ob)=>{if(window.__t.c&&!window.__t.l&&document.querySelector('[data-prow]')){window.__t.l=performance.now();ob.disconnect()}}).observe(document.body,{childList:true,subtree:true})}""")
        t=time.time(); pg.click('.ma-nav [data-nav=produtos]')
        pg.wait_for_selector('[data-prow]',timeout=180000); t_pw=time.time()-t
        tt=pg.evaluate('window.__t'); t_lista=(tt['l']-tt['c'])/1000
        pg.evaluate("document.querySelector('[data-prow]').scrollIntoView()")
        pg.wait_for_function("()=>{const v=[...document.querySelectorAll('.ma-prow-img')].filter(i=>{const r=i.getBoundingClientRect();return r.bottom>0&&r.top<innerHeight});return v.length>0&&v.every(i=>i.complete&&i.naturalWidth>0)}",timeout=60000); t_fotos=time.time()-t
        carregadas=pg.evaluate("[...document.querySelectorAll('.ma-prow-img')].filter(i=>i.complete&&i.naturalWidth>0).length")
        pg.wait_for_timeout(600)
        lt=pg.evaluate('window.__lt'); maior=max(lt) if lt else 0; soma=sum(lt)
        # rolagem até o fim da lista (com muitos itens)
        t=time.time(); pg.evaluate("async()=>{for(let k=0;k<25;k++){scrollBy(0,innerHeight);await new Promise(r=>setTimeout(r,40))}}"); t_rola=time.time()-t
        lt2=pg.evaluate('window.__lt')[len(lt):]; maior2=max(lt2) if lt2 else 0
        linhas=pg.locator('[data-prow]').count()
        print(f'   fotos carregadas ao abrir: {carregadas} de {linhas if False else N}')
        print(f'   lista visível: {t_lista:.2f}s (na página; {t_pw:.2f}s com o atraso do Playwright) · primeiras fotos: {t_fotos:.2f}s · resposta: {bytes_prod[0]/1024/1024:.2f} MB · tarefas longas: {len(lt)} (maior {maior:.0f} ms, soma {soma:.0f} ms) · rolagem: maior tarefa {maior2:.0f} ms · linhas: {linhas}')
        if not SO:
            lim=3.0 if mob else 1.5
            check(f'{nome}: lista de {N} produtos aparece rápido (< {lim:.1f}s)', t_lista<lim, round(t_lista,2))
            check(f'{nome}: resposta da lista leve (< 1 MB)', bytes_prod[0]<1024*1024, round(bytes_prod[0]/1024/1024,2))
            check(f'{nome}: sem travamento (nenhuma tarefa > {600 if mob else 250} ms)', maior<(600 if mob else 250), round(maior))
            check(f'{nome}: rolagem fluida (nenhuma tarefa > {300 if mob else 150} ms)', maior2<(300 if mob else 150), round(maior2))
            check(f'{nome}: todos os {N} produtos listados', linhas==N, linhas)
            check(f'{nome}: fotos visíveis aparecem e as de fora da tela só carregam ao rolar', t_fotos<(6 if mob else 3) and carregadas<N/2, (round(t_fotos,2),carregadas))
            if nome=='computador':
                # editar: as fotos originais chegam só para o produto aberto
                pg.evaluate("scrollTo(0,0)"); alvo=itens[0]['id']
                pg.click(f'[data-pe="{alvo}"]'); pg.wait_for_selector('#pfs img',timeout=10000); pg.wait_for_timeout(300)
                src=pg.evaluate("[...document.querySelectorAll('#pfs img')].map(i=>i.getAttribute('src').length)")
                check('editar: o produto abre com as 2 fotos originais', len(src)==2 and min(src)>200_000, src)
                pg.click('#psave'); pg.wait_for_timeout(1500)
                depois=O.get(f'/api/v2/ads/{BID}/products/{alvo}').json() if O.get(f'/api/v2/ads/{BID}/products/{alvo}').ok else None
                db=sqlite3.connect(DBF); row=db.execute('select data from products where id=?',(alvo,)).fetchone(); db.close(); dd=json.loads(row[0])
                check('salvar sem mexer nas fotos mantém as fotos originais (nada perdido)', len(dd.get('fotos',[]))==2 and all(len(f)>200_000 for f in dd['fotos']), [len(f) for f in dd.get('fotos',[])])
                comv=[x for x in itens if x.get('variantes')][0]['id']
                pg.click(f'[data-pe="{comv}"]'); pg.wait_for_timeout(1200)
                db=sqlite3.connect(DBF); vfs=[json.loads(r[0]).get('fotos',[]) for r in db.execute('select data from product_variants where product_id=?',(comv,)).fetchall()]; db.close()
                pg.click('#psave'); pg.wait_for_timeout(1500)
                db=sqlite3.connect(DBF); vfs2=[json.loads(r[0]).get('fotos',[]) for r in db.execute('select data from product_variants where product_id=?',(comv,)).fetchall()]; db.close()
                check('salvar produto com variações mantém as fotos das variações', [len(x) for x in vfs]==[len(x) for x in vfs2] and all(len(f)>200_000 for x in vfs2 for f in x), ([len(x) for x in vfs],[len(x) for x in vfs2]))
                sw=pg.locator(f'[data-pt="{itens[3]["id"]}"]'); sw.scroll_into_view_if_needed(); sw.click(); pg.wait_for_timeout(1200)
                check('ativar/desativar continua funcionando na lista', pg.locator(f'[data-pt="{itens[3]["id"]}"]').get_attribute('aria-checked')=='false')
                pg.locator(f'[data-pt="{itens[3]["id"]}"]').click(); pg.wait_for_timeout(1200)
                cat=A.get(f'/api/v2/businesses/{BID}').json()
                check('vitrine pública continua com fotos dos produtos', len(cat.get('produtos',[]))==N and all((x.get('foto') or (x.get('fotos') or [None])[0]) for x in cat['produtos'][:10]))
        pg.screenshot(path=f'/tmp/produtos_{nome}.png'); c.close()
    if not SO: check('sem erros de JavaScript', not [e for e in errs if 'React error #418' not in e and e!='Event'], errs[:3])
    b.close()
if not SO: print(f'\n{sum(res)}/{len(res)} verificações aprovadas'); raise SystemExit(0 if all(res) else 1)
