# Produtos e Serviços com o cadastro manual recolhido, pela tela real (Sua empresa → Produtos), celular (escuro) e computador (claro):
#   - Ao entrar: nenhum campo do cadastro à mostra; barra com "+ Cadastro manual" em destaque e "Importar catálogo" /
#     "Histórico de importações" discretos; estado vazio com chamadas para cadastrar ou importar.
#   - Abrir pelo botão e pelo estado vazio, fechar pelo "Fechar" e pelo próprio botão; cadastrar (formulário recolhe e o item
#     aparece na lista); editar (abre já preenchido); persistência depois de recarregar.
#   - Importar catálogo e Histórico abrem em painel próprio com "Fechar".
#   - Sem rolagem lateral e sem nada atrás da navegação inferior; sem erros de JavaScript.
# Servidor: PORT=4403 SQLITE_FILE=/tmp/ma-precolhido.db node --experimental-sqlite --import tsx test/serve-sqlite.ts (banco novo)
import json, sqlite3, io
from PIL import Image
from playwright.sync_api import sync_playwright
BASE = 'http://localhost:4403'; DBF = '/tmp/ma-precolhido.db'; res = []
def check(n, ok, d=''):
    res.append(bool(ok)); print(('  ✔ ' if ok else '  ✘ ') + n + ('' if ok else ' → ' + repr(d)[:300]))
def rows(q, *a):
    db = sqlite3.connect(DBF); r = db.execute(q, a).fetchall(); db.commit(); db.close(); return r
U = {'birthday': '1990-01-01', 'password': 'Senha@Forte123', 'passwordConfirm': 'Senha@Forte123', 'acceptTerms': True}
vis = lambda pg, s: pg.locator(s).count() > 0 and pg.locator(s).first.is_visible()
with sync_playwright() as p:
    b = p.chromium.launch(); errs = []
    for i, (nome, vp, mob, tema) in enumerate([('celular', {'width': 390, 'height': 844}, True, 'dark'), ('computador', {'width': 1280, 'height': 900}, False, 'light')]):
        print('==', nome, tema)
        c = b.new_context(viewport=vp, base_url=BASE, is_mobile=mob, has_touch=mob, color_scheme=tema); R = c.request
        assert R.post('/api/auth', data={'action': 'signup', 'name': 'Loja ' + nome, 'whatsapp': '+55 11 93333-' + ('8181' if mob else '8282'), 'email': f'rec.{nome}@t.com', **U}).ok
        R.put('/api/panel/modules', data={'catalogo': True, 'empresas': True})
        r = R.post('/api/v2/ads', data={'planId': 'n4', 'empresa': f'Empório {nome}', 'categoria': 'Mercearia', 'titulo': 't', 'texto': 'x', 'zap': '5511999990000', 'tipo': 'produtos', 'endereco': 'Rua A, 10'}); assert r.ok, r.text()
        ID = r.json()['items'][0]['id']; rows("update businesses set status='ativo', expires_at='2099-01-01T00:00:00Z' where id=?", ID)
        R.patch('/api/me', data={'settings': {'theme': tema}})  # tema do painel vem da preferência da conta (padrão escuro)
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('dialog', lambda d: d.accept())
        def entrar():
            pg.goto('/x/sua-empresa'); pg.wait_for_timeout(1500)
            pg.locator('[data-lt2="produtos"],[data-lt="produtos"],button:has-text("Produtos")').first.click(); pg.wait_for_selector('[data-mi-bar]', timeout=10000); pg.wait_for_timeout(400)
        entrar()
        check(f'{nome}: ao entrar, o formulário de cadastro fica recolhido (nenhum campo à mostra)', not vis(pg, '#pn') and not vis(pg, '#ppr') and not vis(pg, '#pd'))
        bar = pg.evaluate("""(()=>{const q=s=>document.querySelector(s);const m=q('[data-mim=manual]'),ia=q('[data-mim=ia]'),h=q('[data-mim=hist]');
          return {m:m.innerText.trim(),exp:m.getAttribute('aria-expanded'),pri:m.classList.contains('mi-bar-pri'),ia:ia.classList.contains('mi-bar-sec'),h:h.classList.contains('mi-bar-sec'),
            bgM:getComputedStyle(m).backgroundColor+getComputedStyle(m).backgroundImage,bgI:getComputedStyle(ia).backgroundColor+getComputedStyle(ia).backgroundImage,send:m.classList.contains('btn-send')}})()""")
        check(f'{nome}: "+ Cadastro manual" em destaque; Importar e Histórico como ações discretas', bar['m'].replace('\n', ' ').endswith('Cadastro manual') and bar['exp'] == 'false' and bar['pri'] and bar['send'] and bar['ia'] and bar['h'] and bar['bgM'] != bar['bgI'], bar)
        geo = pg.evaluate("(()=>{const r=s=>document.querySelector(s).getBoundingClientRect();const b=r('[data-mi-bar]'),m=r('[data-mim=manual]'),v=r('[data-pvazio]');return {bh:b.height,mb:m.bottom,bb:b.bottom,vt:v.top}})()")
        check(f'{nome}: barra de ações inteira à vista, sem nada por cima (estado vazio abaixo dela)', geo['bh'] >= 40 and geo['mb'] <= geo['bb'] + 1 and geo['vt'] >= geo['bb'], geo)
        vz = pg.inner_text('[data-pvazio]') if pg.locator('[data-pvazio]').count() else ''
        check(f'{nome}: estado vazio com chamadas para cadastrar e importar', vz and pg.locator('[data-pvazio] [data-mi-go=manual]').count() == 1 and pg.locator('[data-pvazio] [data-mi-go=ia]').count() == 1, vz)
        if i == 0: pg.screenshot(path='/tmp/e2e/produtos_recolhido_vazio_celular.png')
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: sem rolagem lateral', ow <= 1, ow)
        # abrir pelo estado vazio e fechar pelo "Fechar"
        pg.click('[data-pvazio] [data-mi-go=manual]'); pg.wait_for_timeout(500)
        check(f'{nome}: estado vazio abre o cadastro manual (campo nome focado)', vis(pg, '#pn') and pg.evaluate("document.activeElement&&document.activeElement.id") == 'pn' and pg.get_attribute('[data-mim=manual]', 'aria-expanded') == 'true')
        pg.locator('[data-mi-fechar]:visible').first.click(); pg.wait_for_timeout(400)
        check(f'{nome}: "Fechar" recolhe o cadastro', not vis(pg, '#pn') and pg.get_attribute('[data-mim=manual]', 'aria-expanded') == 'false')
        # abrir e fechar pelo próprio botão
        pg.click('[data-mim=manual]'); pg.wait_for_timeout(400); a1 = vis(pg, '#pn')
        pg.click('[data-mim=manual]'); pg.wait_for_timeout(400)
        check(f'{nome}: o botão abre e fecha (alterna) o cadastro', a1 and not vis(pg, '#pn'))
        # importar e histórico em painel próprio
        pg.click('[data-mim=ia]'); pg.wait_for_selector('#mi_colar', timeout=8000)
        check(f'{nome}: "Importar catálogo" abre em painel com "Fechar", sem expor o cadastro', vis(pg, '.mi-painel [data-mi-fechar]') and not vis(pg, '#pn'))
        pg.click('.mi-painel [data-mi-fechar]'); pg.wait_for_timeout(300); check(f'{nome}: fechar a importação volta à lista', pg.locator('#mi_colar').count() == 0)
        pg.click('[data-mim=hist]'); pg.wait_for_timeout(1200)
        check(f'{nome}: "Histórico de importações" abre em painel com "Fechar"', vis(pg, '.mi-painel') and 'Histórico' in pg.inner_text('.mi-painel') and not vis(pg, '#pn'))
        pg.click('.mi-painel [data-mi-fechar]'); pg.wait_for_timeout(300)
        # cadastrar
        pg.click('[data-mim=manual]'); pg.wait_for_timeout(400)
        if i == 0: pg.screenshot(path='/tmp/e2e/produtos_recolhido_aberto_celular.png')
        pg.fill('#pn', 'Café torrado 500g'); pg.fill('#ppr', '32,90'); pg.fill('#pc', 'Cafés'); pg.fill('#pd', 'Torra média, grão moído.')
        bi = io.BytesIO(); Image.new('RGB', (240, 240), (120, 70, 30)).save(bi, 'PNG'); pg.set_input_files('#pf', {'name': 'cafe.png', 'mimeType': 'image/png', 'buffer': bi.getvalue()}); pg.wait_for_timeout(700)
        # o botão de salvar não pode ficar atrás da navegação inferior
        sv = pg.locator('#psave'); sv.evaluate("e=>e.scrollIntoView({block:'end'})"); pg.wait_for_timeout(300)
        bb = sv.bounding_box(); nav = pg.locator('.ma-nav').bounding_box() if pg.locator('.ma-nav').count() and pg.locator('.ma-nav').is_visible() else None
        check(f'{nome}: botão de salvar visível acima da navegação inferior', bb and (not nav or bb['y'] + bb['height'] <= nav['y'] + 1), (bb, nav))
        sv.click()
        try: pg.wait_for_selector('[data-prow]', timeout=10000)
        except Exception: pg.screenshot(path='/tmp/e2e/dbg_save.png'); print('DBG', pg.evaluate("[...document.querySelectorAll('[role=status],[role=alert],.toast,[data-toast]')].map(e=>e.textContent).join(' | ')"), pg.locator('[data-prow]').count(), pg.inner_text('body')[-600:])
        pg.wait_for_timeout(800)
        pr = [json.loads(d) for (d,) in rows('select data from products where business_id=?', ID)]
        check(f'{nome}: cadastro salvo com todos os campos; formulário recolhe e o item aparece na lista', len(pr) == 1 and pr[0]['nome'] == 'Café torrado 500g' and abs(float(pr[0]['preco']) - 32.9) < .001 and pr[0].get('categoria') == 'Cafés' and not vis(pg, '#pn') and 'Café torrado' in pg.inner_text('body') and pg.locator('[data-pvazio]').count() == 0, (pr, vis(pg, '#pn')))
        check(f'{nome}: lista com título e contagem', '1 produto cadastrado' in pg.inner_text('[data-plista-tit]'))
        # editar
        pg.locator('[data-pe]').first.click(); pg.wait_for_selector('#pn', state='visible', timeout=8000); pg.wait_for_timeout(400)
        check(f'{nome}: editar abre o formulário já preenchido', pg.input_value('#pn') == 'Café torrado 500g' and pg.input_value('#pd').startswith('Torra média'))
        pg.fill('#pn', 'Café torrado 1kg'); pg.fill('#ppr', '59,90')
        sv = pg.locator('#psave'); sv.scroll_into_view_if_needed(); sv.click(); pg.wait_for_timeout(1500)
        pr = [json.loads(d) for (d,) in rows('select data from products where business_id=?', ID)]
        check(f'{nome}: edição salva sem duplicar', len(pr) == 1 and pr[0]['nome'] == 'Café torrado 1kg' and abs(float(pr[0]['preco']) - 59.9) < .001, pr)
        # persistência
        entrar()
        check(f'{nome}: depois de recarregar, o item continua e o cadastro segue recolhido', 'Café torrado 1kg' in pg.inner_text('body') and not vis(pg, '#pn') and pg.locator('[data-pvazio]').count() == 0)
        pg.screenshot(path=f'/tmp/e2e/produtos_recolhido_lista_{nome}.png')
        ow = pg.evaluate('document.documentElement.scrollWidth-innerWidth'); check(f'{nome}: lista sem rolagem lateral', ow <= 1, ow)
        th = pg.evaluate("(()=>{const m=document.querySelector('[data-mim=hist]');return {t:document.documentElement.dataset.theme,c:getComputedStyle(m).color,bg:getComputedStyle(document.body).backgroundColor}})()")
        check(f'{nome}: tema {tema} aplicado e ações legíveis', th['t'] == tema and th['c'] != th['bg'], th)
        c.close()
    # 'Event' = folha de fontes do Google sem rede no ambiente de teste
    E = [e for e in errs if '#418' not in e and e != 'Event']; check('sem erros de JavaScript', not E, E[:3])
    b.close()
print(f'\n{sum(res)}/{len(res)} verificações OK'); raise SystemExit(0 if all(res) else 1)
