// Cenários de provedor: o 1º provedor falha de jeitos diferentes; o 2º responde. Mede tempo, resultado e o que ficou registrado.
import { DatabaseSync } from 'node:sqlite'
const BASE = process.env.BASE!, db = new DatabaseSync(process.env.SQLITE_FILE!); db.exec('PRAGMA busy_timeout=8000')
class Cli { jar = new Map<string,string>(); async call(m: string, p: string, b?: any) { const r = await fetch(BASE + p, { method: m, headers: { ...(b !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': '10.5.' + Math.floor(Math.random()*200) + '.' + Math.floor(Math.random()*200) }, body: b !== undefined ? JSON.stringify(b) : undefined }); for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v) } const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) } } catch { return { status: r.status, body: t } } } }
const a = new Cli(), em = 'cenadm' + Date.now() + '@auto-teste.com'
await a.call('POST', '/api/auth', { action: 'signup', name: 'Admin Cenarios', whatsapp: '+55 11 93131-' + String(Date.now()).slice(-4), email: em, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
db.prepare("UPDATE users SET role='superadmin' WHERE email=?").run(em); a.jar.clear(); await a.call('POST', '/api/auth', { action: 'login', email: em, password: 'Senha@Forte123' })
const B = process.env.B_URL!
for (const [nome, urlA] of JSON.parse(process.env.CENARIOS!)) {
  const items = [...(urlA ? [{ id: 'c-ia-a', nome: 'IA A', base_url: urlA, modelo: 'modelo-a', key: 'chave-a-123', texto: true, ativo: true }] : []), { id: 'c-ia-b', nome: 'IA B', base_url: B, modelo: 'modelo-b', key: 'chave-b-123', texto: true, ativo: !process.env.SEM_B }, { id: 'servidor', ativo: false }]
  const s = await a.call('PUT', '/api/panel/ai_providers', { items }); if (s.status !== 200) { console.log('config falhou', JSON.stringify(s.body).slice(0, 200)); continue }
  await a.call('PUT', '/api/panel/ai_router', { modo: 'prioridade' })
  const conv = crypto.randomUUID(), n0 = (db.prepare('SELECT COUNT(*) n FROM messages').get() as any).n
  const t0 = Date.now(), r = await a.call('POST', '/api/chat', { text: 'O que é um pitbull?', conversationId: conv }), ms = Date.now() - t0
  const msgs = db.prepare('SELECT role, substr(content,1,60) c FROM messages WHERE conversation_id = ? ORDER BY id').all(conv)
  const tr: any = db.prepare('SELECT via, provider, failures, detail FROM brain_chat_traces ORDER BY id DESC LIMIT 1').get(); let d: any = {}; try { d = JSON.parse(tr.detail) } catch {}
  console.log(`\n== ${nome}\n   ${r.status} em ${ms} ms · provedor=${tr?.provider} · resposta: ${String(r.body?.assistantMessage?.content || r.body?.error).slice(0, 110)}\n   falhas=${tr?.failures} ia=${JSON.stringify(d.ia || null)} motivo=${d.motivoTimeout || ''}\n   mensagens gravadas: ${JSON.stringify(msgs)}`)
}
