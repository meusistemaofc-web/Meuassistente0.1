// MODOS INTELIGENTES — controle do administrador por opção (inclusive a Pesquisa na internet), pelo app real (POST /api/chat,
// rotas reais, dublês de IA e de internet). Para CADA opção do botão ⚡ confere: some da lista do usuário, não ativa pelo ⚡
// (campo "modo"), nem sozinha pela mensagem, nem por rota/link direto (403 modo_desativado), o Cérebro não usa os dados; ligada de
// novo, volta a funcionar. Também: gravação no banco (app_config), permissões (só administrador) e a chave geral.
// Uso: npm run test:modos-admin
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, one, J } = await import('../src/db/index.js')
const PB = await import('../src/ai/bloqueio-pesquisa.js')

let ok = 0, falhas = 0
const erros: string[] = []
function check(cond: unknown, msg: string, det?: unknown) { if (cond) { ok++; console.log('    ✓', msg) } else { falhas++; erros.push(msg); console.log('    ✗', msg, det === undefined ? '' : '→ ' + JSON.stringify(det).slice(0, 300)) } }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
const A = S.admin
const cfg = async (k: string) => J<any>((await one('SELECT value FROM app_config WHERE key = $1', [k]))?.value, null)
const lista = async (c: InstanceType<typeof S.Cli>) => (await c.call('GET', '/api/v2/modos')).body
const ids = async (c: InstanceType<typeof S.Cli>) => ((await lista(c)).modos || []).map((m: any) => m.id)
const modoDaConversa = async (conv: string) => (await one('SELECT modo FROM conversa_modos WHERE conversation_id = $1', [conv]))?.modo || null
async function diga(c: InstanceType<typeof S.Cli>, conv: string, text: string, extra: any = {}) {
  const n0 = PB.turnosTeste.length, b0 = S.buscas.length
  const r = await c.call('POST', '/api/chat', { text, conversationId: conv, ...extra }); await sleep(120)
  return { status: r.status, txt: String(r.body?.assistantMessage?.content ?? ''), st: PB.turnosTeste[n0], buscas: S.buscas.slice(b0) }
}
const putModo = (id: string, v: any) => A.call('PUT', '/api/panel/modos_chat', { modos: { [id]: v } })

const u = await S.novoUsuario()

console.log('\n# Painel: todas as opções do ⚡ listadas, inclusive a Pesquisa na internet')
{ const p = (await A.call('GET', '/api/panel')).body
  const L = p.modos_chat?.modos || []
  check(['busca', 'pesquisa', 'treino', 'marketing', 'gestao_empresa'].every((x) => L.some((m: any) => m.id === x)), 'o painel lista cada opção (busca, pesquisa, treino, marketing, gestão)', L.map((m: any) => m.id))
  check(L.find((m: any) => m.id === 'pesquisa')?.ativo === true && p.pesquisa_internet?.ativo === true, 'Pesquisa na internet: ligada por padrão e igual à chave global')
  check(['busca', 'pesquisa', 'treino'].every((x) => 0 <= 0) && (await ids(u)).includes('pesquisa') && (await ids(u)).includes('busca') && (await ids(u)).includes('treino'), 'o usuário vê Busca, Pesquisa na internet e Treino no ⚡', await ids(u))
}

console.log('\n# Permissões: só o administrador muda')
check((await u.call('PUT', '/api/panel/modos_chat', { modos: { treino: { ativo: false } } })).status === 403, 'usuário comum não desliga um modo')
check((await u.call('PUT', '/api/panel/pesquisa_internet', { ativo: false })).status === 403, 'usuário comum não desliga a pesquisa')
check((await A.call('PUT', '/api/panel/pesquisa_internet', { ativo: 'nao' })).status === 400, 'valor inválido é recusado')
check((await ids(u)).includes('treino') && (await ids(u)).includes('pesquisa'), 'nada mudou depois das tentativas sem permissão')

/* rota/link direto de cada modo: [método, caminho, corpo] — ligado não pode dar 403; desligado dá 403 modo_desativado */
const ROTAS: Record<string, [string, string, any?][]> = {
  busca: [['GET', '/api/v2/busca/cards'], ['GET', '/api/v2/busca/visual/999']],
  treino: [['GET', '/api/v2/treino/ficha'], ['POST', '/api/v2/treino/registro', {}], ['GET', '/api/v2/treino/cargas?chave=supino'], ['GET', '/api/v2/treino/ilustracao/agachamento/ini.svg']],
  marketing: [['GET', '/api/v2/modos/propostas/999'], ['POST', '/api/v2/modos/propostas/999', { action: 'central' }]],
  gestao_empresa: [['GET', '/api/v2/gestao/previa?c=x&p=1']],
}
const NOME: Record<string, string> = { busca: 'Busca de produtos e serviços', treino: 'Treino e Acompanhamento', marketing: 'Consultor de Marketing', gestao_empresa: 'Gestão da Empresa' }
const AUTO: Record<string, string> = { busca: 'quero encontrar um tênis branco de corrida barato', treino: 'quero montar meu treino de academia' }
const rotasStatus = async (id: string) => Promise.all(ROTAS[id].map(async ([m, p, b]) => ({ p, ...(await u.call(m, p, b)) })))
for (const id of Object.keys(ROTAS)) {
  console.log(`\n# ${NOME[id]} (${id})`)
  const antes = await rotasStatus(id)
  check(antes.every((r) => r.body?.code !== 'modo_desativado'), 'ligado: as rotas próprias respondem (sem o bloqueio do modo)', antes.map((r) => [r.p, r.status, r.body?.code]))
  let r = await putModo(id, { ativo: false })
  check(r.status === 200 && (r.body.modos_chat?.modos || []).find((m: any) => m.id === id)?.ativo === false, 'administrador desliga')
  check((await cfg('modos_chat'))?.modos?.[id]?.ativo === false, 'gravado no banco (app_config.modos_chat)')
  check(!(await ids(u)).includes(id), 'some do ⚡ do usuário', await ids(u))
  check((await u.call('POST', '/api/v2/modos', { action: 'verificar', modo: id })).status === 404, 'verificação direta do modo: não existe')
  const conv = crypto.randomUUID(), t = await diga(u, conv, '⚡ ' + NOME[id], { modo: id })
  check(t.status === 200 && !(await modoDaConversa(conv)), 'pedido direto pelo campo "modo" (atalho/requisição) não liga o modo', t.txt.slice(0, 120))
  if (AUTO[id]) { const c2 = crypto.randomUUID(); await diga(u, c2, AUTO[id]); check(!(await modoDaConversa(c2)), 'a própria mensagem não liga o modo sozinho (orquestrador)') }
  const dep = await rotasStatus(id)
  check(dep.every((x) => x.status === 403 && x.body?.code === 'modo_desativado'), 'rotas e links diretos: 403 modo_desativado', dep.map((x) => [x.p, x.status, x.body?.code]))
  r = await putModo(id, { ativo: true })
  check(r.status === 200 && (await cfg('modos_chat'))?.modos?.[id]?.ativo === true, 'administrador liga de novo (gravado)')
  const vol = await rotasStatus(id)
  check(vol.every((x) => x.body?.code !== 'modo_desativado'), 'religado: as rotas voltam a responder', vol.map((x) => [x.p, x.status, x.body?.code]))
  if (id === 'busca' || id === 'treino') {
    check((await ids(u)).includes(id), 'religado: volta ao ⚡')
    const c3 = crypto.randomUUID(); const t3 = await diga(u, c3, '⚡ ' + NOME[id], { modo: id })
    check((await modoDaConversa(c3)) === id && t3.txt.length > 0, 'religado: o ⚡ liga o modo na conversa', t3.txt.slice(0, 100))
  } else check((await A.call('GET', '/api/panel')).body.modos_chat.modos.find((m: any) => m.id === id)?.ativo === true, 'religado: ativo no painel (aparece para quem tem acesso: empresa elegível)')
}

console.log('\n# Treino desligado: o Cérebro não usa o plano de treino')
{ await putModo('treino', { ativo: false }); const i0 = S.chamadasIA.length
  await diga(u, crypto.randomUUID(), 'me explica a fotossíntese em uma frase')
  const sys = S.chamadasIA.slice(i0).map((x) => x.system).join('\n')
  check(!/plano de treino ativo/i.test(sys), 'contexto do treino fora do prompt com o modo desligado')
  await putModo('treino', { ativo: true }) }

console.log('\n# Pesquisa na internet (opção do ⚡ ligada à chave global)')
{ const conv = crypto.randomUUID()
  let t = await diga(u, conv, '⚡ Pesquisa na internet', { modo: 'pesquisa' })
  check(/Pesquisa na internet ligada/.test(t.txt) && (await modoDaConversa(conv)) === 'pesquisa', 'ligada: o ⚡ liga o modo na conversa', t.txt.slice(0, 120))
  t = await diga(u, conv, 'qual a história da cooperativa tarvok?')
  check(t.st?.prioridade === 'pesquisa_explicita' && t.buscas.length > 0, 'com o modo ligado, a pergunta vai para a pesquisa (nível 4)', { p: t.st?.prioridade, b: t.buscas })
  t = await diga(u, conv, 'gastei 32 reais na padaria')
  const g = await q("SELECT data FROM items WHERE user_id = (SELECT id FROM users WHERE email = 'p1@sonda.com') AND type = 'expense'")
  check(t.buscas.length === 0 && g.some((x: any) => Number(J<any>(x.data, {}).amount) === 32), 'operação interna continua interna (gasto registrado, sem pesquisa)', { b: t.buscas, n: g.length })
  let r = await A.call('PUT', '/api/panel/pesquisa_internet', { ativo: false })
  check(r.status === 200 && (await cfg('pesquisa_internet'))?.ativo === false, 'administrador desliga a pesquisa (gravado no banco)')
  check(!(await ids(u)).includes('pesquisa'), 'desligada: some do ⚡', await ids(u))
  check((r.body.modos_chat?.modos || []).find((m: any) => m.id === 'pesquisa')?.ativo === false, 'o painel mostra a opção desligada')
  t = await diga(u, conv, 'e quando foi fundada a cooperativa tarvok?')
  check(t.buscas.length === 0, 'desligada: nenhuma busca mesmo na conversa que estava com o modo ligado', t.buscas)
  check(!/desativad|administrador|bloque|configura/i.test(t.txt), 'sem aviso de bloqueio para o usuário', t.txt.slice(0, 160))
  const c2 = crypto.randomUUID(); t = await diga(u, c2, '⚡ Pesquisa na internet', { modo: 'pesquisa' })
  check(!(await modoDaConversa(c2)) && t.buscas.length === 0, 'desligada: pedido direto pelo campo "modo" não liga', t.txt.slice(0, 100))
  t = await diga(u, c2, 'pesquise na internet sobre a cooperativa tarvok')
  check(t.buscas.length === 0, 'desligada: pedido explícito "pesquise na internet" também não pesquisa', t.buscas)
  r = await putModo('pesquisa', { ativo: true })
  check(r.status === 200 && (await cfg('pesquisa_internet'))?.ativo === true && (await ids(u)).includes('pesquisa'), 'ligar pela linha do modo liga a chave global (um só controle) e volta ao ⚡')
  const c3 = crypto.randomUUID(); await diga(u, c3, '⚡ Pesquisa na internet', { modo: 'pesquisa' }); t = await diga(u, c3, 'o que é o protocolo zyntra?')
  check(t.buscas.length > 0, 'religada: volta a pesquisar', t.buscas)
}

console.log('\n# Chave geral dos Modos Inteligentes')
{ let r = await A.call('PUT', '/api/panel/modos_chat', { ativo: false })
  const l = await lista(u)
  check(r.status === 200 && (await cfg('modos_chat'))?.ativo === false && l.habilitado === false && (l.modos || []).length === 0, 'desligada: o ⚡ some inteiro (gravado)')
  check((await u.call('GET', '/api/v2/treino/ficha')).status === 403, 'desligada: rotas dos modos bloqueadas')
  r = await A.call('PUT', '/api/panel/modos_chat', { ativo: true })
  check((await lista(u)).habilitado === true && (await ids(u)).length >= 3 && (await u.call('GET', '/api/v2/treino/ficha')).status !== 403, 'religada: tudo volta, com as escolhas de cada opção preservadas') }

console.log(`\nResultado: ${ok}/${ok + falhas} verificações aprovadas.`)
if (falhas) console.log('Falhas:\n - ' + erros.join('\n - '))
await S.fechar(); process.exit(falhas ? 1 : 0)
