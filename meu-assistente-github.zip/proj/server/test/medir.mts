// Mede cada pergunta no servidor real: tempo total, etapas (rastro do Cérebro), via e QUANTAS chamadas à IA cada uma gerou.
import { DatabaseSync } from 'node:sqlite'
import { readFileSync, existsSync } from 'node:fs'
const BASE = process.env.BASE!, db = new DatabaseSync(process.env.SQLITE_FILE!), LOG = '/tmp/fake_ai_log.jsonl'; db.exec('PRAGMA busy_timeout=8000')
class Cli { jar = new Map<string,string>(); async call(m: string, p: string, b?: any) { const r = await fetch(BASE + p, { method: m, headers: { ...(b !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': '10.6.' + Math.floor(Math.random()*200) + '.' + Math.floor(Math.random()*200) }, body: b !== undefined ? JSON.stringify(b) : undefined }); for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v) } const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) } } catch { return { status: r.status, body: t } } } }
const u = new Cli()
await u.call('POST', '/api/auth', { action: 'signup', name: 'Medir Teste', whatsapp: '+55 11 95454-' + String(Date.now()).slice(-4), email: 'medir' + Date.now() + '@auto-teste.com', birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
const linhas = () => existsSync(LOG) ? readFileSync(LOG, 'utf8').trim().split('\n').filter(Boolean).length : 0
const papel = (l: any) => { const s = String(l.messages?.[0]?.content || ''); return s.startsWith('Você é o "Meu Assistente"') ? 'principal' : s.slice(0, 50).replace(/\s+/g, ' ') }
const conv = process.env.MESMA_CONVERSA ? crypto.randomUUID() : ''
const out: any[] = []
for (const t of process.argv.slice(2)) {
  const n0 = linhas(), t0 = Date.now(), r = await u.call('POST', '/api/chat', { text: t, conversationId: conv || crypto.randomUUID() }), ms = Date.now() - t0
  const novas = existsSync(LOG) ? readFileSync(LOG, 'utf8').trim().split('\n').slice(n0).map((x) => JSON.parse(x)) : []
  const tr: any = db.prepare('SELECT via, result, intent, detail FROM brain_chat_traces ORDER BY id DESC LIMIT 1').get(); let d: any = {}; try { d = JSON.parse(tr?.detail || '{}') } catch {}
  out.push({ t, ms, status: r.status, via: tr?.via, chamadasIA: novas.length, papeis: novas.map(papel), etapas: d.etapas, resposta: String(r.body?.assistantMessage?.content || r.body?.error || '').slice(0, 120) })
  console.log(`\n>> ${t}\n   ${r.status} ${ms} ms via=${tr?.via} intent=${tr?.intent} result=${tr?.result} · IA: ${novas.length} chamada(s) ${JSON.stringify(novas.map(papel))}\n   etapas=${JSON.stringify(d.etapas)}\n   << ${String(r.body?.assistantMessage?.content || JSON.stringify(r.body)).slice(0, 140)}`)
}
if (process.env.SAIDA) (await import('node:fs')).writeFileSync(process.env.SAIDA, JSON.stringify(out, null, 1))
