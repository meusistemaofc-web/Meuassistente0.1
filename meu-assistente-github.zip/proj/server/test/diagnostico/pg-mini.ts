// Cliente MÍNIMO do protocolo do PostgreSQL (v3, consulta estendida com parâmetros em texto) para testar o app contra um
// Postgres real em ambientes sem o pacote "pg". Converte os tipos como o node-pg + db/postgres.ts fazem (BIGINT → número,
// TIMESTAMPTZ → ISO, JSON/JSONB → objeto, BOOL → boolean, DATE → Date) e envia parâmetros como o node-pg (objeto → JSON,
// Date → ISO, array → literal de array, boolean → true/false).
// Uso: createPgMini({ host, port, user, database }) devolve um Db (db/index.ts). Só para testes.
import { connect, type Socket } from 'node:net'
import type { Db, Row } from '../../src/db/index.js'

type Opts = { host: string; port: number; user: string; database: string }
const cstr = (s: string) => Buffer.concat([Buffer.from(s, 'utf8'), Buffer.from([0])])
const msg = (tipo: string, corpo: Buffer) => { const h = Buffer.alloc(5); h.write(tipo, 0, 'ascii'); h.writeInt32BE(corpo.length + 4, 1); return Buffer.concat([h, corpo]) }
const i16 = (n: number) => { const b = Buffer.alloc(2); b.writeInt16BE(n); return b }
const i32 = (n: number) => { const b = Buffer.alloc(4); b.writeInt32BE(n); return b }

function arrayLiteral(a: unknown[]): string {
  return '{' + a.map((v) => v == null ? 'NULL' : Array.isArray(v) ? arrayLiteral(v) : '"' + String(typeof v === 'object' ? JSON.stringify(v) : v).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"').join(',') + '}'
}
function preparar(v: unknown): string | null {
  if (v === null || v === undefined) return null
  if (Buffer.isBuffer(v)) return '\\x' + v.toString('hex')
  if (v instanceof Date) return v.toISOString()
  if (Array.isArray(v)) return arrayLiteral(v)
  if (typeof v === 'object') return JSON.stringify(v)
  return String(v)
}
function parseArray(s: string, conv: (x: string) => unknown): unknown[] {
  const out: unknown[] = []; let i = 1, cur = '', aspas = false, tinha = false
  for (; i < s.length - 1; i++) {
    const c = s[i]
    if (aspas) { if (c === '\\') cur += s[++i]; else if (c === '"') aspas = false; else cur += c }
    else if (c === '"') { aspas = true; tinha = true } else if (c === ',') { out.push(!tinha && cur === 'NULL' ? null : conv(cur)); cur = ''; tinha = false } else cur += c
  }
  if (s.length > 2) out.push(!tinha && cur === 'NULL' ? null : conv(cur))
  return out
}
function converter(oid: number, v: string): unknown {
  switch (oid) {
    case 20: case 21: case 23: case 26: case 700: case 701: return Number(v)
    case 16: return v === 't'
    case 114: case 3802: return JSON.parse(v)
    case 1184: return new Date(v).toISOString()
    case 1114: return new Date(v + 'Z').toISOString()
    case 1082: { const [y, m, d] = v.split('-').map(Number); return new Date(y, m - 1, d) }
    case 1005: case 1007: case 1016: case 1021: case 1022: return parseArray(v, Number)
    case 1009: case 1015: return parseArray(v, (x) => x)
    case 199: case 3807: return parseArray(v, (x) => JSON.parse(x))
    default: return v
  }
}
export class ErroPg extends Error { code?: string; detail?: string }

class Conexao {
  private sock!: Socket; private buf = Buffer.alloc(0); private esperando: ((m: { t: string; b: Buffer }) => void) | null = null; private fila: { t: string; b: Buffer }[] = []
  private trava: Promise<unknown> = Promise.resolve()
  constructor(private o: Opts) {}
  async abrir() {
    this.sock = connect(this.o.port, this.o.host)
    await new Promise<void>((ok, erro) => { this.sock.once('connect', () => ok()); this.sock.once('error', erro) })
    this.sock.on('data', (d) => { this.buf = Buffer.concat([this.buf, d]); this.drenar() })
    const corpo = Buffer.concat([i32(196608), cstr('user'), cstr(this.o.user), cstr('database'), cstr(this.o.database), Buffer.from([0])])
    this.sock.write(Buffer.concat([i32(corpo.length + 4), corpo]))
    for (;;) { const m = await this.ler(); if (m.t === 'E') throw this.erro(m.b); if (m.t === 'R' && m.b.readInt32BE(0) !== 0) throw new Error('pg-mini: só autenticação trust'); if (m.t === 'Z') return this }
  }
  private drenar() {
    while (this.buf.length >= 5) { const n = this.buf.readInt32BE(1); if (this.buf.length < n + 1) break; const m = { t: String.fromCharCode(this.buf[0]), b: this.buf.subarray(5, n + 1) }; this.buf = this.buf.subarray(n + 1); if (this.esperando) { const f = this.esperando; this.esperando = null; f(m) } else this.fila.push(m) }
  }
  private ler(): Promise<{ t: string; b: Buffer }> { const m = this.fila.shift(); if (m) return Promise.resolve(m); return new Promise((r) => (this.esperando = r)) }
  private erro(b: Buffer) { const f: Record<string, string> = {}; let i = 0; while (i < b.length && b[i] !== 0) { const k = String.fromCharCode(b[i]); const fim = b.indexOf(0, i + 1); f[k] = b.toString('utf8', i + 1, fim); i = fim + 1 } const e = new ErroPg(f.M || 'erro do Postgres'); e.code = f.C; e.detail = f.D; return e }
  private serial<T>(fn: () => Promise<T>): Promise<T> { const p = this.trava.then(fn, fn); this.trava = p.catch(() => null); return p }
  query(sql: string, params: unknown[] = []): Promise<any[]> {
    return this.serial(async () => {
      const vals = params.map(preparar)
      const bind = Buffer.concat([cstr(''), cstr(''), i16(0), i16(vals.length), ...vals.map((v) => v === null ? i32(-1) : Buffer.concat([i32(Buffer.byteLength(v)), Buffer.from(v, 'utf8')])), i16(0)])
      this.sock.write(Buffer.concat([msg('P', Buffer.concat([cstr(''), cstr(sql), i16(0)])), msg('B', bind), msg('D', Buffer.concat([Buffer.from('P'), cstr('')])), msg('E', Buffer.concat([cstr(''), i32(0)])), msg('S', Buffer.alloc(0))]))
      let campos: { nome: string; oid: number }[] = [], erro: ErroPg | null = null; const linhas: any[] = []
      for (;;) {
        const m = await this.ler()
        if (m.t === 'T') { const n = m.b.readInt16BE(0); let i = 2; campos = []; for (let k = 0; k < n; k++) { const fim = m.b.indexOf(0, i); const nome = m.b.toString('utf8', i, fim); i = fim + 1; const oid = m.b.readInt32BE(i + 6); i += 18; campos.push({ nome, oid }) } }
        else if (m.t === 'D') { const n = m.b.readInt16BE(0); let i = 2; const r: any = {}; for (let k = 0; k < n; k++) { const len = m.b.readInt32BE(i); i += 4; if (len < 0) r[campos[k].nome] = null; else { r[campos[k].nome] = converter(campos[k].oid, m.b.toString('utf8', i, i + len)); i += len } } linhas.push(r) }
        else if (m.t === 'E') erro = this.erro(m.b)
        else if (m.t === 'Z') { if (erro) throw erro; return linhas }
      }
    })
  }
  exec(sql: string): Promise<void> {
    return this.serial(async () => {
      this.sock.write(msg('Q', cstr(sql))); let erro: ErroPg | null = null
      for (;;) { const m = await this.ler(); if (m.t === 'E') erro = this.erro(m.b); else if (m.t === 'Z') { if (erro) throw erro; return } }
    })
  }
  fechar() { try { this.sock.write(msg('X', Buffer.alloc(0))); this.sock.end() } catch { /* já fechada */ } }
}

export async function createPgMini(o: Opts): Promise<Db> {
  const base = await new Conexao(o).abrir()
  const sobre = (c: Conexao): Db => ({ kind: 'postgres', query: <R extends Row>(s: string, p?: unknown[]) => c.query(s, p) as Promise<R[]>, exec: (s) => c.exec(s), tx: (fn) => fn(sobre(c)), close: async () => {} })
  return {
    ...sobre(base),
    async tx(fn) {
      const c = await new Conexao(o).abrir()
      try { await c.query('BEGIN'); const r = await fn(sobre(c)); await c.query('COMMIT'); return r } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e } finally { c.fechar() }
    },
    close: async () => base.fechar(),
  }
}
