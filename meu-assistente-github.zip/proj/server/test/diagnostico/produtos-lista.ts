// REGRESSÃO: lista leve da aba Produtos (fotos por endereço, sem base64) é equivalente ao produto completo e cada endereço
// devolve exatamente a foto original; salvar com endereços não perde fotos; só o dono vê. SQLite ou Postgres real (--pg porta).
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
const arg = (n: string) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : undefined }
const PG = arg('--pg')
for (const k of ['log', 'error', 'warn', 'info'] as const) { const o = console[k].bind(console); console[k] = (...a: any[]) => { if (process.env.MOSTRAR_LOGS) o(...a) } }
const saida = (s: string) => process.stdout.write(s + '\n')
const { setDb, q, J } = await import('../../src/db/index.js'), { migrate } = await import('../../src/db/migrate.js'), { config } = await import('../../src/config.js')
let d: any
if (PG) { const nome = 'pl_diag_' + Date.now(); execFileSync('/usr/lib/postgresql/16/bin/psql', ['-h', '127.0.0.1', '-p', PG, '-U', 'postgres', '-qc', `CREATE DATABASE ${nome}`]); d = await (await import('./pg-mini.js')).createPgMini({ host: '127.0.0.1', port: Number(PG), user: 'postgres', database: nome }); saida(`Banco: PostgreSQL real (porta ${PG})`) }
else { d = await (await import('../../src/db/sqlite.js')).createSqlite(join(mkdtempSync(join(tmpdir(), 'ma-pl-')), 'pl.db')); saida('Banco: SQLite') }
setDb(d); await migrate(d, config.migrationsDir, () => {})
const { createApp } = await import('../../src/app.js')
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port
class Cli { jar = new Map<string, string>()
  async call(method: string, path: string, body?: unknown, bin = false) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, { method, redirect: 'manual', headers: { 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: body === undefined ? undefined : JSON.stringify(body) })
    for (const c of r.headers.getSetCookie?.() || []) { const [kv] = c.split(';'); const [k, v] = kv.split('='); this.jar.set(k.trim(), v) }
    if (bin) return { status: r.status, buf: Buffer.from(await r.arrayBuffer()), tipo: r.headers.get('content-type'), cache: r.headers.get('cache-control') }
    const t = await r.text(); let j: any; try { j = JSON.parse(t) } catch { j = t } return { status: r.status, body: j }
  } }
const res: boolean[] = []
const check = (n: string, ok: unknown, det: unknown = '') => { res.push(!!ok); saida(`${ok ? '  ✔' : '  ✘'} ${n}${ok ? '' : ' → ' + JSON.stringify(det).slice(0, 600)}`) }
const cad = async (nome: string, email: string, zap: string) => { const c = new Cli(); const r = await c.call('POST', '/api/auth', { action: 'signup', name: nome, email, whatsapp: zap, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error(JSON.stringify(r.body)); return c }
const admin = await cad('Admin Sistema', 'admin@pl.com', '+55 11 94444-0001'); await admin.call('PUT', '/api/panel/modules', { empresas: true, anuncios: true, catalogo: true })
const dono = await cad('Dono Loja', 'dono@pl.com', '+55 11 94444-0002'), outro = await cad('Outra Pessoa', 'outra@pl.com', '+55 11 94444-0003')
const r0 = await dono.call('POST', '/api/v2/ads', { planId: 'n4', empresa: 'Moda Bella', categoria: 'Roupas', titulo: 'Moda Bella', texto: 'Roupas', zap: '5511999990000', lat: -23.55, lng: -46.63, raio: 10, tipo: 'produtos' })
const BID = r0.body.items[0].id; await q("UPDATE businesses SET status = 'ativo', expires_at = $1 WHERE id = $2", [new Date(Date.now() + 30 * 86400_000).toISOString(), BID])
const img = (seed: number, kb: number) => { const b = Buffer.alloc(kb * 1024); for (let i = 0; i < b.length; i++) b[i] = (i * 31 + seed * 97) & 255; b[0] = 0xff; b[1] = 0xd8; return 'data:image/jpeg;base64,' + b.toString('base64') }
const F = [img(1, 120), img(2, 200), img(3, 90), img(4, 150), img(5, 60), img(6, 80)]
const thumb = 'data:image/jpeg;base64,' + Buffer.alloc(3000, 7).toString('base64')
await dono.call('POST', `/api/v2/ads/${BID}/products`, { nome: 'Camiseta', preco: 49.9, categoria: 'Camisetas', fotos: [F[0], F[1]], thumb, oferta: { ativo: true, preco: 39.9 }, estoque: 5 })
await dono.call('POST', `/api/v2/ads/${BID}/products`, { nome: 'Vestido', preco: 0, categoria: 'Vestidos', fotos: [F[2]], variantes: [{ cor: 'Azul', preco: 120, fotos: [F[3], F[4]], estoque: 2 }, { cor: 'Preto', preco: 99.9, fotos: [F[5]], oferta: { ativo: true, preco: 89.9 } }] })
await dono.call('POST', `/api/v2/ads/${BID}/products`, { nome: 'Boné sem foto principal', preco: 0, categoria: 'Acessórios', variantes: [{ cor: 'Verde', preco: 30, fotos: [F[4]] }] })
const lista = (await dono.call('GET', `/api/v2/ads/${BID}/products`)).body.items
check('lista leve: nenhuma foto em base64 na resposta', !JSON.stringify(lista).includes('data:image/jpeg;base64,/9') && !JSON.stringify(lista).includes(F[0].slice(30, 90)), JSON.stringify(lista).length)
const tira = (p: any) => { const c = JSON.parse(JSON.stringify(p)); delete c.fotos; delete c.thumb; delete c.leve; if (c.destaque) delete c.destaque.foto; c.variantes = (c.variantes || []).map((v: any) => { delete v.fotos; delete v.thumb; delete v.temThumb; return v }); return c }
for (const p of lista) {
  const full = (await dono.call('GET', `/api/v2/ads/${BID}/products/${p.id}`)).body
  check(`"${p.nome}": todos os campos iguais ao produto completo (preço, oferta, destaque, estoque, variações)`, JSON.stringify(tira(p)) === JSON.stringify(tira(full)), { leve: tira(p), full: tira(full) })
  const pares: [string, string][] = [...(p.fotos || []).map((u: string, n: number) => [u, full.fotos[n]] as [string, string]), ...p.variantes.flatMap((v: any, k: number) => v.fotos.map((u: string, n: number) => [u, full.variantes[k].fotos[n]] as [string, string]))]
  let ok = pares.length > 0
  for (const [u, orig] of pares) { const r = await dono.call('GET', u, undefined, true); const b64 = 'data:' + r.tipo + ';base64,' + (r as any).buf.toString('base64'); if (r.status !== 200 || b64 !== orig) ok = false }
  check(`"${p.nome}": cada endereço de foto devolve exatamente a foto original (${pares.length})`, ok)
  const df = p.destaque?.foto, fdf = full.destaque?.foto
  if (df) { const r = await dono.call('GET', df, undefined, true); check(`"${p.nome}": foto de destaque aponta para a mesma foto`, 'data:' + r.tipo + ';base64,' + (r as any).buf.toString('base64') === fdf) }
}
check('miniatura do produto vai na lista (pequena); sem miniatura, a linha usa o endereço da foto', lista[0].thumb === thumb && lista[1].thumb === null && lista[2].thumb === null && /\/foto\/0\?/.test(lista[1].fotos[0]), lista.map((p: any) => p.thumb && p.thumb.length))
const u0 = lista[0].fotos[0], r1 = await dono.call('GET', u0, undefined, true)
check('foto com cache privado no navegador', /private/.test(String(r1.cache)) && /max-age=\d+/.test(String(r1.cache)), r1.cache)
check('outra pessoa não vê as fotos nem o produto da loja', (await outro.call('GET', u0, undefined, true)).status === 404 && (await outro.call('GET', `/api/v2/ads/${BID}/products/${lista[0].id}`)).status === 404)
// salvar mandando os ENDEREÇOS (como a lista leve tem): as fotos originais continuam
const v = lista[1]
await dono.call('POST', `/api/v2/ads/${BID}/products`, { id: v.id, nome: v.nome, preco: 0, categoria: v.categoria, fotos: v.fotos, variantes: v.variantes.map((x: any) => ({ id: x.id, cor: x.cor, preco: x.preco, fotos: x.fotos, oferta: x.oferta, estoque: x.estoque })) })
const depois = (await dono.call('GET', `/api/v2/ads/${BID}/products/${v.id}`)).body
check('salvar com endereços de foto não perde nenhuma foto (produto e variações)', depois.fotos[0] === F[2] && depois.variantes[0].fotos[0] === F[3] && depois.variantes[0].fotos[1] === F[4] && depois.variantes[1].fotos[0] === F[5], { f: depois.fotos.map((x: string) => x.length), v: depois.variantes.map((x: any) => x.fotos.map((y: string) => y.length)) })
// duplicar a partir de endereços (outro produto da mesma loja)
const dup = await dono.call('POST', `/api/v2/ads/${BID}/products`, { nome: 'Camiseta (cópia)', preco: 49.9, categoria: 'Camisetas', fotos: lista[0].fotos })
const novo = dup.body.items.find((x: any) => x.nome === 'Camiseta (cópia)'), nf = (await dono.call('GET', `/api/v2/ads/${BID}/products/${novo.id}`)).body
check('duplicar com endereços copia as fotos originais', nf.fotos[0] === F[0] && nf.fotos[1] === F[1])
const vit = (await new Cli().call('GET', `/api/v2/businesses/${BID}`)).body
check('vitrine pública inalterada (produtos com foto)', vit.produtos?.length === 4, vit.produtos?.length)
const f = res.filter((x) => !x).length
saida(`\nResultado: ${res.length - f}/${res.length} verificações aprovadas.`)
server.close(); await d.close(); process.exit(f ? 1 : 0)
