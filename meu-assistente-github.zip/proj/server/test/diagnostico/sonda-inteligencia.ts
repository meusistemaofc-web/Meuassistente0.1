// SONDA DE INTELIGÊNCIA DO CHAT — conversas sequenciais pelo FLUXO REAL (POST /api/chat), com:
//  • dublê de IA (API compatível com OpenAI) que registra o que recebe (prompt de sistema, histórico, ferramentas) e só
//    responde com o que estiver no contexto ([C1]… do Cérebro) — nunca inventa;
//  • dublê de internet (SearXNG + páginas) com homônimos, primeiro resultado irrelevante, páginas que se contradizem e
//    assunto que só aparece numa busca refeita.
// Uso: npx tsx test/diagnostico/sonda-inteligencia.ts [--json arquivo]   (imprime a transcrição e as observações)
import { createServer } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

export const chamadasIA: { system: string; mensagens: { role: string; content: string }[]; tools: string[] }[] = []
export const buscas: string[] = [], lidas: string[] = []
const blocosC = (sys: string) => [...sys.matchAll(/\[C(\d)\][^\n]*\n([\s\S]*?)(?=\n\[C\d\]|\n\n|$)/g)].map((m) => m[2].split('\n').filter((l) => !/^Fontes:/.test(l)).join(' ').replace(/\s*\[\d+\]/g, '').trim()).filter(Boolean)
const ai = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  const send = (o: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (req.method === 'GET') return send({ models: [{ name: 'dublê' }] })
  const j = JSON.parse(body || '{}'), msgs = (j.messages || []).map((m: any) => ({ role: m.role, content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }))
  const last = msgs[msgs.length - 1]?.content || '', sys = msgs[0]?.role === 'system' ? msgs[0].content : ''
  const interna = /^\[(REVISÃO INTERNA|TRADUÇÃO INTERNA|AGENTE:)/.test(last)
  if (!interna) chamadasIA.push({ system: sys, mensagens: msgs.slice(1), tools: (j.tools || []).map((t: any) => t.function?.name) })
  if (interna) return send({ choices: [{ message: { role: 'assistant', content: /^\[REVISÃO/.test(last) ? 'OK' : last.replace(/^\[[^\]]*\]\s*/, '') } }] })
  // SONDA_FERRAMENTAS=1 (test/roteamento.ts): como uma IA real, usa a ferramenta de criação de tarefa/nota/conta e depois confirma
  if (process.env.SONDA_FERRAMENTAS === '1' && Array.isArray(j.tools)) {
    const ult = j.messages?.[j.messages.length - 1], nomes = new Set(j.tools.map((t: any) => t.function?.name))
    if (ult?.role === 'tool') return send({ choices: [{ message: { role: 'assistant', content: /"ok":true/.test(String(ult.content)) ? 'Pronto! Já registrei.' : 'Não consegui registrar.' } }] })
    const u0 = String(ult?.content || ''), call = (name: string, args: any) => send({ choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'c' + Date.now(), type: 'function', function: { name, arguments: JSON.stringify(args) } }] } }] })
    let m: RegExpMatchArray | null
    if (nomes.has('create_task') && (m = u0.match(/\btarefa\s+(?:de|para|pra|:)?\s*(.{3,120})$/i))) return call('create_task', { title: m[1].charAt(0).toUpperCase() + m[1].slice(1) })
    if (nomes.has('create_note') && (m = u0.match(/^anot[ae]\s+(?:que\s+)?(.{3,300})$/i))) return call('create_note', { content: m[1].charAt(0).toUpperCase() + m[1].slice(1) })
    if (nomes.has('create_bill') && (m = u0.match(/\bconta de (\S+) de (\d+)\D+dia (\d{1,2})/i))) { const h = new Date(), mes = Number(m[3]) > h.getDate() ? h.getMonth() : h.getMonth() + 1, dt = new Date(Date.UTC(h.getFullYear(), mes, Number(m[3]))); return call('create_bill', { name: m[1].charAt(0).toUpperCase() + m[1].slice(1), amount: Number(m[2]), due_date: dt.toISOString().slice(0, 10) }) }
  }
  const c = blocosC(sys)
  const div = sys.match(/DIVERGEM: «([^»]+)» × «([^»]+)»/) // segue a instrução de divergência, como uma IA real
  const txt = div ? `As fontes divergem: uma diz "${div[1]}" e outra diz "${div[2]}".` : c.length ? `Pelo que consta: ${c[0]}` : /\bcapital\b.*\bfran/i.test(last) ? 'A capital da França é Paris.' : 'Não tenho essa informação confirmada.'
  return send({ choices: [{ message: { role: 'assistant', content: txt } }] })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))

// páginas: [título, corpo]
const PG: Record<string, [string, string]> = {
  '/zyntra/games': ['Zyntra Games — loja de jogos e consoles', '<p>A Zyntra Games vende consoles e jogos em Curitiba, com entrega em todo o país e parcelamento em até dez vezes.</p>'],
  '/zyntra/protocolo': ['Protocolo Zyntra de segurança hospitalar', '<p>O Protocolo Zyntra de segurança hospitalar é um conjunto de verificações aplicadas antes de cirurgias para evitar troca de pacientes e de procedimentos.</p><p>O Protocolo Zyntra foi criado pela enfermeira Helena Vasconcelos em 2011, no Hospital Santa Lúcia, e hoje é usado em mais de 300 hospitais.</p>'],
  '/jaguar/onca': ['Onça-pintada (jaguar)', '<p>A onça-pintada, também chamada de jaguar, é o maior felino das Américas e vive em florestas tropicais, pantanais e cerrados.</p><p>A onça-pintada caça capivaras, jacarés e veados, e é uma espécie ameaçada pela perda de habitat.</p>'],
  '/jaguar/carro': ['Jaguar F-Pace: avaliação do SUV de luxo', '<p>O Jaguar F-Pace é um SUV de luxo da montadora britânica Jaguar, com motor 2.0 turbo de 250 cv e tração integral.</p><p>Na avaliação, o Jaguar F-Pace se destacou pelo acabamento e pela estabilidade, mas o consumo de 8 km/l na cidade e o custo de manutenção alto pesam contra.</p>'],
  '/velnor/bolo': ['Receitas de bolo de cenoura fofinho', '<p>Bata as cenouras com os ovos e o óleo, misture com a farinha e asse por 40 minutos em forno médio.</p>'],
  '/velnor/norma': ['Norma Velnor de rotulagem de alimentos', '<p>A Norma Velnor de rotulagem de alimentos obriga fabricantes a informar alergênicos em destaque, com letras de no mínimo 4 milímetros, na parte frontal da embalagem.</p><p>A Norma Velnor entrou em vigor em março de 2019 e prevê multa para rótulos fora do padrão.</p>'],
  '/quarvel/doenca': ['Doença de Quarvel em gatos', '<p>A doença de Quarvel em gatos é uma inflamação crônica das gengivas que causa dor ao mastigar, mau hálito e perda de peso.</p><p>O tratamento da doença de Quarvel combina limpeza dentária sob anestesia e controle da dor indicado pelo veterinário.</p>'],
  '/tarvok/a': ['Cooperativa Tarvok: história', '<p>A Cooperativa Tarvok é uma cooperativa de agricultores familiares do interior do Paraná que comercializa mel e geleias.</p><p>A Cooperativa Tarvok foi fundada em 1998 por 40 famílias de apicultores.</p>'],
  '/tarvok/b': ['Cooperativa Tarvok completa 20 anos', '<p>A Cooperativa Tarvok, de agricultores familiares do Paraná, produz mel, geleias e própolis para todo o Sul do país.</p><p>A Cooperativa Tarvok foi fundada em 2004 por 25 famílias da região.</p>'],
}
const web = createServer(async (req, res) => {
  const u = new URL(req.url || '/', 'http://x'), base = `http://127.0.0.1:${(web.address() as any).port}`
  if (u.pathname === '/robots.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('User-agent: *\n') }
  if (u.pathname === '/search') {
    const qq = u.searchParams.get('q') || ''; buscas.push(qq)
    const R = (p: string, resumo = '') => ({ url: base + p, title: PG[p][0], content: resumo || PG[p][1].replace(/<[^>]+>/g, ' ').slice(0, 160), engine: 'duckduckgo' })
    const n = qq.toLowerCase()
    let out: any[] = []
    if (/zyntra/.test(n)) out = [R('/zyntra/games'), R('/zyntra/protocolo')]
    else if (/jaguar/.test(n)) out = /carro|suv|autom|ve[ií]culo|montadora/.test(n) ? [R('/jaguar/carro'), R('/jaguar/onca')] : [R('/jaguar/onca'), R('/jaguar/carro')]
    else if (/velnor/.test(n)) out = [R('/velnor/bolo', 'Receita fácil de bolo.'), R('/velnor/norma')]
    else if (/quarvel/.test(n)) out = /^(doen[cç]a de quarvel|quarvel)$/i.test(qq.trim()) || /doen[cç]a de quarvel( em gatos)?$/i.test(qq.trim()) ? [R('/quarvel/doenca')] : []
    else if (/tarvok/.test(n)) out = [R('/tarvok/a'), R('/tarvok/b')]
    res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ results: out }))
  }
  if (PG[u.pathname]) { lidas.push(u.pathname); const [t, b] = PG[u.pathname]; res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(`<!doctype html><html lang="pt-BR"><head><title>${t}</title></head><body><main><h1>${t}</h1>${b}</main></body></html>`) }
  res.writeHead(404); res.end('')
})
await new Promise<void>((r) => web.listen(0, '127.0.0.1', r))

const dir = mkdtempSync(join(tmpdir(), 'ma-sonda-'))
Object.assign(process.env, { NODE_ENV: 'test', PUBLIC_URL: 'http://localhost', AI_BASE_URL: `http://127.0.0.1:${(ai.address() as any).port}/v1`, AI_API_KEY: 'test-key', AI_MODEL: 'dublê', SCHEDULER_ENABLED: 'false', CEREBRO_PERMITIR_REDE_LOCAL: '1', STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public') })
const { createSqlite } = await import('../../src/db/sqlite.js'), { setDb, q } = await import('../../src/db/index.js'), { migrate } = await import('../../src/db/migrate.js'), { createApp } = await import('../../src/app.js'), { config } = await import('../../src/config.js')
const d = await createSqlite(join(dir, 'sonda.db')); setDb(d); await migrate(d, config.migrationsDir, () => {})
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port
export class Cli {
  jar = new Map<string, string>()
  async call(m: string, p: string, j?: unknown) {
    const r = await fetch(`http://127.0.0.1:${port}${p}`, { method: m, headers: { ...(j !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: j !== undefined ? JSON.stringify(j) : undefined })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const t = await r.text(); let b: any = t; try { b = JSON.parse(t) } catch { /* texto */ } return { status: r.status, body: b }
  }
}
export const admin = new Cli()
await admin.call('POST', '/api/auth', { action: 'signup', name: 'Admin Sonda', email: 'admin@sonda.com', whatsapp: '+55 11 94444-0303', birthday: '1985-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
const pv = (await admin.call('GET', '/api/brain/providers')).body.provedores, sx = pv.find((p: any) => p.provedor === 'searxng')
await admin.call('PUT', `/api/brain/providers/${sx.id}`, { url: `http://127.0.0.1:${(web.address() as any).port}`, ativo: true, papel: 'principal' })
for (const p of pv.filter((p: any) => p.tipo === 'busca' && p.id !== sx.id && p.ativo)) await admin.call('PUT', `/api/brain/providers/${p.id}`, { ativo: false })
let nUser = 0
export async function novoUsuario() { const c = new Cli(); nUser++; const r = await c.call('POST', '/api/auth', { action: 'signup', name: `Pessoa Sonda${nUser}`, email: `p${nUser}@sonda.com`, whatsapp: `+55 11 95555-${String(1000 + nUser)}`, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error(JSON.stringify(r.body)); return c }
export async function conversa(c: Cli, falas: string[], titulo: string, log = true) {
  const conv = crypto.randomUUID(), turnos: { fala: string; resposta: string; buscas: string[]; lidas: string[]; ia: (typeof chamadasIA)[number] | null }[] = []
  if (log) console.log(`\n### ${titulo}`)
  for (const f of falas) {
    const b0 = buscas.length, l0 = lidas.length, i0 = chamadasIA.length
    const r = await c.call('POST', '/api/chat', { text: f, conversationId: conv })
    const resp = String(r.body?.assistantMessage?.content ?? JSON.stringify(r.body).slice(0, 200))
    const t = { fala: f, resposta: resp, buscas: buscas.slice(b0), lidas: lidas.slice(l0), ia: chamadasIA.length > i0 ? chamadasIA[chamadasIA.length - 1] : null }
    turnos.push(t)
    if (log) { console.log(`  👤 ${f}\n  🤖 ${resp.replace(/⟦[^⟧]*⟧/g, '').replace(/\n+/g, ' ⏎ ').slice(0, 260)}`); if (t.buscas.length) console.log(`     🔎 buscas: ${t.buscas.map((x) => JSON.stringify(x)).join(' · ')}  📄 lidas: ${t.lidas.join(' ') || '—'}`); if (t.ia) console.log(`     🧠 IA recebeu: ${t.ia.mensagens.length} msg(s) de histórico+atual; conhecimentos: ${(t.ia.system.match(/\[C\d\] [^\n—]*/g) || []).join(' | ') || '—'}`) }
  }
  return turnos
}
export async function fechar() { server.close(); ai.close(); web.close(); await d.close() }

if (process.argv[1]?.endsWith('sonda-inteligencia.ts')) {
  const P = await novoUsuario()
  await conversa(P, ['O que é o Protocolo Zyntra?', 'e quem criou?', 'em que ano?'], '1. Continuação curta depois de uma pesquisa (coreferência)')
  await conversa(P, ['Estou pensando em comprar um carro para a família', 'o jaguar é bom?'], '2. Nome ambíguo com contexto (carro × animal)')
  await conversa(P, ['O que é jaguar?', 'o animal'], '3. Nome ambíguo sem contexto → pergunta → resposta curta')
  await conversa(P, ['O que é a Norma Velnor?'], '4. Primeiro resultado irrelevante')
  await conversa(P, ['Quais os sintomas da doença de Quarvel em gatos e como tratar?'], '5. Busca que precisa ser refeita (pergunta longa demais para o buscador)')
  await conversa(P, ['Quando foi fundada a Cooperativa Tarvok?'], '6. Fontes que se contradizem')
  await conversa(P, ['marca dentista', 'amanha', 'as 3 da tarde'], '7. Agendamento em partes, com respostas curtas e erro de digitação')
  await conversa(P, ['agenda uma reuniao com o joao', 'qual a capital da frança?', 'quinta as 10h'], '8. Mudança de assunto no meio de um agendamento')
  await conversa(P, ['gastei 30 conto no uber', 'qnto gastei hj?', 'e ontem?'], '9. Gíria, abreviações e continuação')
  await conversa(P, ['lenbra de pagar a luz amanha as 9', 'blz'], '10. Erro de digitação em lembrete + confirmação curta')
  await conversa(P, ['O que é o Protocolo Zyntra?', 'O que é o Protocolo Zyntra?'], '11. Mesma pergunta repetida (sem loop, sem pesquisar de novo)')
  await conversa(P, ['O que é o Protocolo Zyntra?', 'não, na verdade ele foi criado em 2012'], '12. Correção do usuário sobre um conhecimento usado')
  const t13 = await conversa(P, ['Quem criou o Protocolo Zyntra?'], '13. Nova conversa depois da correção (ressalva até a revisão)')
  console.log('     ressalva enviada à IA:', /RESSALVA — um usuário corrigiu/.test(t13[0].ia?.system || ''))
  await conversa(P, ['O que é o método Plimbex de estudo?'], '14. Assunto que ninguém sabe (lacuna)')
  const ind = (await admin.call('GET', '/api/brain/chat/indicadores?dias=1')).body
  console.log('\n### Painel: lacunas', JSON.stringify(ind.lacunas?.map((x: any) => x.pergunta)), '· ambíguas:', ind.perguntasAmbiguas)
  await fechar()
}
