// SONDA DE AUTONOMIA — o que o Cérebro resolve SEM nenhuma IA externa, pelo fluxo real do chat (POST /api/chat).
// Cada tarefa é conferida no BANCO (registro criado, valor alterado, nada alterado quando deveria perguntar) ou no conteúdo
// exato da resposta (número calculado, trecho do conhecimento aprovado). Nada é simulado: a "IA" aponta para um endereço
// fechado, como um provedor fora do ar, e o modo do Cérebro é o normal (o mesmo da produção).
// Servidor: E2E_AI_URL=http://127.0.0.1:9/v1 PORT=4360 SQLITE_FILE=/tmp/ma-auto.db node --experimental-sqlite --import tsx test/serve-sqlite.ts
// Uso: node --experimental-sqlite --import tsx test/diagnostico/autonomia.ts [rótulo] [--json arquivo]
import { DatabaseSync } from 'node:sqlite'
import { writeFileSync } from 'node:fs'
const BASE = process.env.BASE || 'http://127.0.0.1:4360', DBF = process.env.SQLITE_FILE || '/tmp/ma-auto.db'
const rotulo = process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 'sonda'
const jsonOut = (() => { const i = process.argv.indexOf('--json'); return i > 0 ? process.argv[i + 1] : '' })()
const db = new DatabaseSync(DBF)
const one = (sql: string, ...p: any[]) => db.prepare(sql).get(...p) as any
const all = (sql: string, ...p: any[]) => db.prepare(sql).all(...p) as any[]

class Cli {
  jar = new Map<string, string>()
  async call(method: string, path: string, body?: any, h: Record<string, string> = {}) {
    const r = await fetch(BASE + path, { method, headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), ...h }, body: body !== undefined ? JSON.stringify(body) : undefined })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const t = await r.text(); let j: any = t; try { j = JSON.parse(t) } catch { /* texto */ }
    return { status: r.status, body: j }
  }
}
const IMG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
const conta = (n: string, i: number) => ({ action: 'signup', name: n + ' Teste', whatsapp: `+55 11 9${String(4000 + i).padStart(4, '0')}-${String(1000 + i)}`, email: `${n.toLowerCase()}@auto-teste.com`, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })

const admin = new Cli(), dono = new Cli()
{ const r0 = await admin.call('POST', '/api/auth', conta('Admin', 1), { 'X-Forwarded-For': '10.50.0.1' }); if (r0.status !== 200) throw new Error('cadastro do administrador: ' + JSON.stringify(r0.body)) }
if ((await dono.call('POST', '/api/auth', conta('Dono', 2), { 'X-Forwarded-For': '10.50.0.2' })).status !== 200) throw new Error('cadastro do dono')
await admin.call('PUT', '/api/panel/modules', { catalogo: true, empresas: true })
// conhecimento aprovado na biblioteca (o administrador cadastra; vale para todos)
await admin.call('POST', '/api/panel/brain/knowledge', { action: 'add', titulo: 'Prazo de troca', conteudo: 'A troca de produtos pode ser pedida em até 7 dias corridos após o recebimento.', tipo: 'conhecimento', natureza: 'consulta' })
// empresa do dono, com produtos e variações
const ad = await dono.call('POST', '/api/v2/ads', { planId: 'n4', empresa: 'Mini Isqueiros', categoria: 'Acessórios', titulo: 'Mini', texto: 'Isqueiros', zap: '5511999990000', endereco: 'Rua A, 10' })
const EID = Number(ad.body.items[0].id)
db.prepare("UPDATE businesses SET status = 'ativo', expires_at = '2099-01-01T00:00:00Z' WHERE id = ?").run(EID)
await dono.call('PUT', `/api/v2/ads/${EID}`, { horarioCfg: { modo: 'aberto', dias: {} }, pagamento: { pix: true, chavePix: 'mini@pix.com', dinheiro: true }, entrega: { retirada: true, entrega: true, taxa: 5 } })
for (const p of [{ nome: 'Isqueiro Zippo', preco: 20, fotos: [IMG], estoque: 4 }, { nome: 'Piercing Argola', fotos: [IMG], variantes: [{ cor: 'Dourado', preco: 30, fotos: [IMG], estoque: 2 }, { cor: 'Prata', preco: 25, fotos: [IMG], estoque: 6 }] }, { nome: 'Piercing Nariz', preco: 15, fotos: [IMG] }])
  if ((await dono.call('POST', `/api/v2/ads/${EID}/products`, p)).status !== 200) throw new Error('produto ' + p.nome)
const uid = Number(one('SELECT id FROM users WHERE email = ?', 'dono@auto-teste.com').id)
const prod = (nome: string) => { const r = one("SELECT id, data, stock, active FROM products WHERE business_id = ? AND data LIKE ?", EID, `%"nome":"${nome}"%`); return { ...JSON.parse(r.data), id: r.id, estoque: r.stock, ativo: r.active === 1 } }
const vari = (cor: string) => { const r = one('SELECT stock, data FROM product_variants WHERE business_id = ? AND data LIKE ?', EID, `%"cor":"${cor}"%`); return { ...JSON.parse(r.data), estoque: r.stock } }
const emp = () => JSON.parse(one('SELECT data FROM businesses WHERE id = ?', EID).data)
const itens = (tipo: string) => all('SELECT id, data FROM items WHERE user_id = ? AND type = ?', uid, tipo).map((r) => ({ ...JSON.parse(r.data), id: r.id }))

type Caso = { id: string; area: string; msg: string; ok: (resp: string) => boolean; antes?: () => void }
const N = (s: string) => s.replace(/\s+/g, ' ')
const CASOS: Caso[] = [
  { id: 'fin-gasto', area: 'registro pessoal', msg: 'gastei 45 reais no mercado', ok: () => itens('expense').some((x) => Number(x.amount) === 45) },
  { id: 'lembrete', area: 'registro pessoal', msg: 'me lembra de pagar a luz amanhã às 9h', ok: () => itens('reminder').some((x) => /luz/i.test(x.message) && x.time === '09:00') },
  { id: 'compromisso', area: 'registro pessoal', msg: 'agendar dentista amanhã às 10h', ok: () => itens('appointment').some((x) => /dentista/i.test(x.title) && x.time === '10:00') },
  { id: 'tarefa', area: 'registro pessoal', msg: 'cria uma tarefa de revisar o contrato do aluguel', ok: () => itens('task').some((x) => /contrato/i.test(x.title)) },
  { id: 'compras', area: 'registro pessoal', msg: 'coloca leite e pão na lista de compras', ok: () => itens('shopping').length >= 2 },
  { id: 'consulta-gastos', area: 'consulta de dados', msg: 'quanto gastei este mês?', ok: (r) => /45,00/.test(r) },
  { id: 'consulta-agenda', area: 'consulta de dados', msg: 'o que tenho amanhã?', ok: (r, b) => /dentista/i.test(r) || ((m) => !!m && itens('appointment').some((x) => /dentista/i.test(x.title) && m.split(',').includes(String(x.id))))((String(b?.assistantMessage?.content || '').match(/⟦appts?:([\d,]+)⟧/) || [])[1]) }, // a agenda pode vir como cartão (⟦appts:ids⟧)
  { id: 'calculo', area: 'cálculo', msg: 'quanto é 15% de 240?', ok: (r) => /\b36\b/.test(r) },
  { id: 'conhecimento', area: 'conhecimento aprovado', msg: 'qual o prazo para trocar um produto?', ok: (r) => /7 dias/.test(r) },
  { id: 'emp-preco', area: 'administração da empresa', msg: 'Altere o preço do Isqueiro Zippo para R$ 27', ok: () => prod('Isqueiro Zippo').preco === 27 },
  { id: 'emp-estoque-var', area: 'administração da empresa', msg: 'Aumente o estoque do dourado para 10 unidades', ok: () => vari('Dourado').estoque === 10 && vari('Prata').estoque === 6 },
  { id: 'emp-estoque', area: 'administração da empresa', msg: 'muda o estoque do zippo para 12', ok: () => prod('Isqueiro Zippo').estoque === 12 },
  { id: 'emp-pix', area: 'administração da empresa', msg: 'Desative o pagamento via Pix', ok: () => emp().pagamento.pix === false && emp().pagamento.chavePix === 'mini@pix.com' },
  { id: 'emp-pausar-produto', area: 'administração da empresa', msg: 'Pause o produto Piercing Nariz', ok: () => prod('Piercing Nariz').ativo === false },
  { id: 'emp-oferta', area: 'administração da empresa', msg: 'Coloque o Isqueiro Zippo em oferta por R$ 22', ok: () => prod('Isqueiro Zippo').oferta?.preco === 22 },
  { id: 'emp-frete', area: 'administração da empresa', msg: 'Ative o frete grátis acima de R$ 100', ok: () => all('SELECT meta, ativo FROM cart_incentives WHERE business_id = ?', EID).some((i) => Number(i.meta) === 100 && i.ativo === 1) },
  { id: 'emp-retirada', area: 'administração da empresa', msg: 'Desative a entrega e deixe apenas retirada', ok: () => emp().entrega.entrega === false && emp().entrega.retirada !== false },
  { id: 'emp-horario', area: 'administração da empresa', msg: 'Mude meu horário de funcionamento para segunda a sábado, das 9h às 18h', ok: () => { const h = emp().horarioCfg; return h?.dias?.sab?.ativo && h.dias.seg.abre === '09:00' && h.dias.seg.fecha === '18:00' && !h.dias.dom.ativo } },
  { id: 'emp-ambiguo', area: 'administração da empresa', msg: 'Aumente o preço do piercing', ok: (r) => /qual|quais/i.test(r) && prod('Piercing Nariz').preco === 15 && vari('Dourado').preco === 30 },
  { id: 'emp-impacto-pergunta', area: 'administração da empresa', msg: 'Pause meu catálogo', ok: (r) => /Confirma/i.test(r) && emp().horarioCfg.modo !== 'fechado' }, // pergunta e NÃO pausa antes do "sim"
  { id: 'emp-impacto-sim', area: 'administração da empresa', msg: 'sim', ok: () => emp().horarioCfg.modo === 'fechado' },
  { id: 'emp-reativar', area: 'administração da empresa', msg: 'Ative novamente os pedidos', ok: () => emp().horarioCfg.modo !== 'fechado' },
]

const conv = 'aaaaaaaa-1111-4222-8333-' + String(Date.now()).slice(-12)
const res: { id: string; area: string; ok: boolean; via: string; ms: number; resposta: string }[] = []
for (const c of CASOS) {
  const t0 = Date.now(), r = await dono.call('POST', '/api/chat', { text: c.msg, conversationId: conv })
  const resp = N(String(r.body?.assistantMessage?.content || r.body?.error || '')).replace(/⟦[^⟧]*⟧/g, '').trim()
  const tr = one("SELECT via FROM brain_chat_traces ORDER BY id DESC LIMIT 1")
  let ok = false; try { ok = r.status === 200 && !!(c.ok as any)(resp, r.body) } catch { ok = false }
  res.push({ id: c.id, area: c.area, ok, via: String(tr?.via || '?'), ms: Date.now() - t0, resposta: resp.slice(0, 140) })
  console.log(`${ok ? '✔' : '✘'} [${c.area}] ${c.msg} → ${resp.slice(0, 110)}`)
}
const areas = [...new Set(res.map((r) => r.area))].map((a) => { const l = res.filter((r) => r.area === a); return { area: a, resolvidas: l.filter((r) => r.ok).length, total: l.length } })
const tot = res.filter((r) => r.ok).length
console.log(`\nSONDA DE AUTONOMIA (${rotulo}) — sem nenhuma IA externa: ${tot}/${res.length} tarefas resolvidas e conferidas no banco`)
for (const a of areas) console.log(`  ${a.area}: ${a.resolvidas}/${a.total}`)
if (jsonOut) writeFileSync(jsonOut, JSON.stringify({ rotulo, em: new Date().toISOString(), resolvidas: tot, total: res.length, areas, casos: res }, null, 2))
process.exit(0)
