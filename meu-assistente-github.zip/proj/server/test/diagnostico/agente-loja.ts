// DIAGNÓSTICO/REGRESSÃO: estado do agente de atendimento quando o dono tem mais de uma empresa (anúncio encerrado e
// recontratado, lixeira, duas modalidades). Pelo app real (createApp + rotas), SQLite ou Postgres real (--pg porta), com
// dublê do Mercado Pago (Pix do agente). Confere: a tela reconhece o agente contratado, nada de "não contratado" com
// "Você já tem um agente", nenhuma cobrança duplicada, configurações e período pago preservados, nenhum agente duplicado,
// link antigo continua abrindo. --so-reproduzir: só mostra o comportamento (sem asserções).
import { createServer } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'

const arg = (n: string) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : undefined }
const PG = arg('--pg'), SO = process.argv.includes('--so-reproduzir')
const logs: string[] = []
for (const k of ['log', 'error', 'warn', 'info'] as const) { const o = console[k].bind(console); console[k] = (...a: any[]) => { logs.push(a.map(String).join(' ')); if (process.env.MOSTRAR_LOGS) o(...a) } }
const saida = (s: string) => process.stdout.write(s + '\n')

const pix: any[] = []
const mp = createServer(async (req, res) => {
  let b = ''; for await (const c of req) b += c; const j = b ? JSON.parse(b) : {}
  const resp = (st: number, o: unknown) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (req.method === 'POST' && req.url === '/v1/payments') { const p = { id: 7000 + pix.length, status: 'pending', external_reference: j.external_reference, transaction_amount: j.transaction_amount }; pix.push(p); return resp(201, { ...p, point_of_interaction: { transaction_data: { qr_code: 'PIX', qr_code_base64: 'AA' } } }) }
  const m = /^\/v1\/payments\/(\d+)/.exec(req.url || ''); const p = m && pix.find((x) => String(x.id) === m[1]); if (p) return resp(200, p)
  resp(404, {})
})
await new Promise<void>((r) => mp.listen(0, '127.0.0.1', r)); process.env.MP_API_BASE = `http://127.0.0.1:${(mp.address() as any).port}`

const { setDb, q, one, J } = await import('../../src/db/index.js'), { migrate } = await import('../../src/db/migrate.js'), { config } = await import('../../src/config.js')
let d: any
if (PG) { const nome = 'ag_diag_' + Date.now(); execFileSync('/usr/lib/postgresql/16/bin/psql', ['-h', '127.0.0.1', '-p', PG, '-U', 'postgres', '-qc', `CREATE DATABASE ${nome}`]); d = await (await import('./pg-mini.js')).createPgMini({ host: '127.0.0.1', port: Number(PG), user: 'postgres', database: nome }); saida(`Banco: PostgreSQL real (porta ${PG})`) }
else { d = await (await import('../../src/db/sqlite.js')).createSqlite(join(mkdtempSync(join(tmpdir(), 'ma-ag-')), 'ag.db')); saida('Banco: SQLite') }
setDb(d); await migrate(d, config.migrationsDir, () => {})
const { createApp } = await import('../../src/app.js'), { setConfig, seal } = await import('../../src/lib/settings.js')
await setConfig('mercadopago', { modo: 'producao', producao: { tok: await seal('APP_USR-admin-token-1234567890') } })
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port
class Cli { jar = new Map<string, string>()
  async call(method: string, path: string, body?: unknown) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers: { 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: body === undefined ? undefined : JSON.stringify(body) })
    for (const c of r.headers.getSetCookie?.() || []) { const [kv] = c.split(';'); const [k, v] = kv.split('='); this.jar.set(k.trim(), v) }
    const t = await r.text(); let j: any; try { j = JSON.parse(t) } catch { j = t } return { status: r.status, body: j }
  } }
const cad = async (nome: string, email: string, zap: string) => { const c = new Cli(); const r = await c.call('POST', '/api/auth', { action: 'signup', name: nome, email, whatsapp: zap, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error('cadastro: ' + JSON.stringify(r.body)); return c }
const res: { n: string; ok: boolean }[] = []
const check = (n: string, ok: unknown, det: unknown = '') => { res.push({ n, ok: !!ok }); saida(`${ok ? '  ✔' : '  ✘'} ${n}${ok ? '' : ' → ' + JSON.stringify(det).slice(0, 500)}`) }
const mostra = (n: string, v: unknown) => saida(`  • ${n}: ${JSON.stringify(v).slice(0, 400)}`)

const admin = await cad('Admin Sistema', 'admin@ag.com', '+55 11 94444-0001')
await admin.call('PUT', '/api/panel/modules', { empresas: true, anuncios: true, catalogo: true, agente: true })
const futuro = (dias: number) => new Date(Date.now() + dias * 86400_000).toISOString()
async function empresa(c: Cli, nome: string, plano = 'n4', status = 'ativo') {
  const r = await c.call('POST', '/api/v2/ads', { planId: plano, empresa: nome, categoria: 'Pizzaria', titulo: nome, texto: 'Forno a lenha', zap: '11 98765-4321', lat: -23.55, lng: -46.63, raio: 10, tipo: 'produtos' })
  if (r.status !== 200) throw new Error('anúncio: ' + JSON.stringify(r.body))
  const id = r.body.items[0].id; await q('UPDATE businesses SET status = $1, expires_at = $2 WHERE id = $3', [status, futuro(30), id]); return Number(id)
}
const dados = async (id: number) => J<any>((await one('SELECT data FROM businesses WHERE id = $1', [id]))!.data, {})
/** agente contratado (pago) na empresa, como fica depois do Pix aprovado */
async function contratar(c: Cli, id: number, nome: string) {
  const s = await c.call('PUT', `/api/v2/ads/${id}/agent`, { nome, saudacao: 'Olá! Sou a Bia.', instrucoes: 'Sempre ofereça a borda recheada.', tom: 'divertido' })
  if (s.status !== 200) throw new Error('config: ' + JSON.stringify(s.body))
  const p = await c.call('POST', `/api/v2/ads/${id}/agent/pay`, {}); const pg = pix.find((x) => x.external_reference === `agent:${id}`); pg.status = 'approved'
  const g = await c.call('GET', `/api/v2/ads/${id}/agent/pay`); return { p, g }
}

// ---------------- Cenário A: anúncio encerrado (venceu) → dono contrata um anúncio novo → abre o agente na empresa nova
saida('\n== A. Agente contratado na empresa antiga; anúncio venceu e o dono contratou um anúncio novo')
const donoA = await cad('Dona Ana', 'ana@ag.com', '+55 11 94444-0002')
const A1 = await empresa(donoA, 'Pizzaria Bella')
const kA = await contratar(donoA, A1, 'Bia')
check('pré-condição: agente pago e no ar na empresa antiga', kA.g.body.status === 'approved' && (await donoA.call('GET', `/api/v2/ads/${A1}/agent`)).body.ativo, kA)
const linkA = (await donoA.call('GET', `/api/v2/ads/${A1}/agent`)).body.link
const ateA = (await dados(A1)).agente.expiresAt
await q("UPDATE businesses SET status = 'encerrado', expires_at = $1 WHERE id = $2", [new Date(Date.now() - 86400_000).toISOString(), A1]) // o anúncio venceu
const A2 = await empresa(donoA, 'Pizzaria Bella')
let gA = await donoA.call('GET', `/api/v2/ads/${A2}/agent`), pA = await donoA.call('PUT', `/api/v2/ads/${A2}/agent`, { nome: 'Bia', saudacao: 'Oi', instrucoes: '', tom: 'amigavel' })
if (SO) { mostra('tela do agente na empresa nova', { ativo: gA.body.ativo, agente: !!gA.body.agente, agenteAte: gA.body.agenteAte, mostra: gA.body.ativo ? 'Agente no ar' : gA.body.agenteAte ? '...' : 'Agente não contratado' }); mostra('salvar configuração na empresa nova', [pA.status, pA.body.error]) }
else {
  check('A: a tela da empresa nova reconhece o agente contratado (no ar, mesmo vencimento)', gA.status === 200 && gA.body.ativo === true && gA.body.agenteAte === ateA, gA.body)
  check('A: configurações preservadas (nome, saudação, instruções, tom)', gA.body.agente?.nome === 'Bia' && gA.body.agente?.saudacao === 'Olá! Sou a Bia.' && /borda recheada/.test(gA.body.agente?.instrucoes) && gA.body.agente?.tom === 'divertido', gA.body.agente)
  check('A: salvar a configuração na empresa nova funciona (sem "Você já tem um agente")', pA.status === 200 && pA.body.agente?.nome === 'Bia', pA.body)
  const xa1 = await dados(A1)
  check('A: um agente só (a empresa antiga não fica com outro) e histórico guardado na antiga', !xa1.agente && Array.isArray(xa1.agenteTransferido) && xa1.agenteTransferido[0]?.para === A2 && xa1.agenteTransferido[0]?.agente?.lastPayment, xa1.agenteTransferido)
  check('A: a tela não oferece contratar de novo (no ar → sem botão Ativar) e nenhum Pix novo foi gerado', gA.body.ativo === true && pix.filter((x) => x.external_reference === `agent:${A2}`).length === 0)
  const slugA = String(linkA).split('/').pop(), pub = await new Cli().call('GET', `/api/v2/agente/${encodeURIComponent(slugA)}`)
  const pubId = await (async () => { for (const r of await q('SELECT id, data FROM businesses')) { const x = J<any>((r as any).data, {}); if (x.slug === slugA || (x.slugsAntigos || []).includes(slugA)) return Number((r as any).id) } return 0 })()
  check('A: o link antigo do agente (já divulgado) abre o agente da empresa nova', pubId === A2, { slugA, pubId, A2 })
}

// ---------------- Cenário B: duas empresas no ar (modalidades diferentes); agente numa, painel aberto na outra
saida('\n== B. Duas empresas no ar; agente contratado na primeira, o dono abre o agente na segunda')
const donoB = await cad('Dono Beto', 'beto@ag.com', '+55 11 94444-0003')
const B1 = await empresa(donoB, 'Barbearia Beto', 'n4'), B2 = await empresa(donoB, 'Beto Lanches', 'n2')
await contratar(donoB, B1, 'Leo')
let gB = await donoB.call('GET', `/api/v2/ads/${B2}/agent`), pB = await donoB.call('PUT', `/api/v2/ads/${B2}/agent`, { nome: 'Outro', saudacao: '', instrucoes: '', tom: 'amigavel' })
if (SO) { mostra('tela do agente na segunda empresa', { ativo: gB.body.ativo, agente: !!gB.body.agente, agenteAte: gB.body.agenteAte }); mostra('salvar configuração na segunda empresa', [pB.status, pB.body.error]) }
else {
  check('B: a segunda empresa mostra que o agente já está contratado na outra (não "não contratado")', gB.status === 200 && gB.body.ativo === false && gB.body.outraEmpresa?.id === B1 && gB.body.outraEmpresa?.contratado === true && /Barbearia Beto/.test(gB.body.outraEmpresa?.empresa), gB.body.outraEmpresa)
  check('B: salvar na segunda empresa não cria um agente duplicado (409 explicando onde está)', pB.status === 409 && /Barbearia Beto/.test(pB.body.error) && !(await dados(B2)).agente, pB.body)
  const pix0 = pix.length, pay = await donoB.call('POST', `/api/v2/ads/${B2}/agent/pay`, {})
  check('B: não gera cobrança para a segunda empresa', pix.length === pix0 && pay.status >= 400, { pix: pix.length - pix0, r: pay.body })
  const mv = await donoB.call('POST', `/api/v2/ads/${B2}/agent/transferir`, {})
  const x1 = await dados(B1), x2 = await dados(B2)
  check('B: "Usar meu agente nesta empresa" transfere (mesmo vencimento, sem cobrança, configurações iguais)', mv.status === 200 && mv.body.ativo && !x1.agente && x2.agente?.nome === 'Leo' && x2.agente?.expiresAt && pix.length === pix0, mv.body)
  check('B: a primeira empresa passa a mostrar onde o agente está agora', (await donoB.call('GET', `/api/v2/ads/${B1}/agent`)).body.outraEmpresa?.id === B2)
}

// ---------------- Cenário C: agente não contratado (nenhuma empresa do dono tem agente)
saida('\n== C. Agente não contratado')
const donoC = await cad('Dona Carla', 'carla@ag.com', '+55 11 94444-0004')
const C1 = await empresa(donoC, 'Doceria Carla')
const gC = await donoC.call('GET', `/api/v2/ads/${C1}/agent`)
if (!SO) {
  check('C: sem agente em lugar nenhum → "não contratado", sem outra empresa', gC.status === 200 && !gC.body.ativo && !gC.body.agente && !gC.body.outraEmpresa, gC.body)
  const s = await donoC.call('PUT', `/api/v2/ads/${C1}/agent`, { nome: 'Lu', saudacao: '', instrucoes: '', tom: 'amigavel' }), pix0 = pix.length
  const p1 = await donoC.call('POST', `/api/v2/ads/${C1}/agent/pay`, {}), p2 = await donoC.call('POST', `/api/v2/ads/${C1}/agent/pay`, {})
  check('C: configura e gera UM Pix (tocar de novo reaproveita o mesmo)', s.status === 200 && pix.length === pix0 + 1 && p1.body.payment?.id && p1.body.payment?.id === p2.body.payment?.id, { n: pix.length - pix0 })
  pix.at(-1).status = 'approved'; await donoC.call('GET', `/api/v2/ads/${C1}/agent/pay`); await donoC.call('GET', `/api/v2/ads/${C1}/agent/pay`)
  const xc = await dados(C1)
  check('C: pago → no ar uma vez (confirmação repetida não estende o prazo de novo)', (await donoC.call('GET', `/api/v2/ads/${C1}/agent`)).body.ativo && Math.round((Date.parse(xc.agente.expiresAt) - Date.now()) / 86400_000) <= 31, xc.agente)
}
// ---------------- Cenário D: empresa antiga na lixeira com agente → empresa nova
saida('\n== D. Empresa com agente foi para a lixeira; o dono usa outra empresa')
const donoD = await cad('Dono Davi', 'davi@ag.com', '+55 11 94444-0005')
const D1 = await empresa(donoD, 'Açaí Davi'); await contratar(donoD, D1, 'Duda')
await donoD.call('DELETE', `/api/v2/ads/${D1}`).catch(() => null)
const stD1 = String((await one('SELECT status FROM businesses WHERE id = $1', [D1]))!.status)
if (stD1 !== 'lixeira') await q("UPDATE businesses SET status = 'lixeira', deleted_at = $1 WHERE id = $2", [new Date().toISOString(), D1])
const D2 = await empresa(donoD, 'Açaí Davi')
const gD = await donoD.call('GET', `/api/v2/ads/${D2}/agent`)
if (!SO) check('D: lixeira → o agente segue para a empresa em uso, com o período pago', gD.body.ativo === true && gD.body.agente?.nome === 'Duda', gD.body)
else mostra('tela do agente na empresa nova (antiga na lixeira)', { ativo: gD.body.ativo, agente: !!gD.body.agente })

// ---------------- Cenário E: Pix do agente gerado na empresa antiga, aprovado depois da mudança de empresa
saida('\n== E. Pix gerado na empresa antiga e aprovado depois que o agente foi para a empresa nova')
const donoE = await cad('Dona Eva', 'eva@ag.com', '+55 11 94444-0006')
const E1 = await empresa(donoE, 'Floricultura Eva')
await donoE.call('PUT', `/api/v2/ads/${E1}/agent`, { nome: 'Flora', saudacao: '', instrucoes: '', tom: 'amigavel' }); await donoE.call('POST', `/api/v2/ads/${E1}/agent/pay`, {})
const pe = pix.find((x) => x.external_reference === `agent:${E1}`)
await q("UPDATE businesses SET status = 'encerrado' WHERE id = $1", [E1]); const E2 = await empresa(donoE, 'Floricultura Eva')
const gE0 = await donoE.call('GET', `/api/v2/ads/${E2}/agent`)
pe.status = 'approved'
const porConsulta = await donoE.call('GET', `/api/v2/ads/${E2}/agent/pay`) // sem webhook: a tela consulta o pagamento
await new Cli().call('POST', `/api/mercadopago/webhook?data.id=${pe.id}`, { data: { id: String(pe.id) }, type: 'payment' }) // e o webhook chega depois (repetido)
const gE = await donoE.call('GET', `/api/v2/ads/${E2}/agent`)
if (!SO) check('E: o pagamento aprovado ativa o agente na empresa nova, pela consulta da tela e sem duplicar com o webhook', porConsulta.body.status === 'approved' && gE0.body.agente?.nome === 'Flora' && !gE0.body.ativo && gE.body.ativo === true && Math.round((Date.parse(gE.body.agenteAte) - Date.now()) / 86400_000) <= 31 && pix.filter((x) => String(x.external_reference).startsWith('agent:') && [`agent:${E1}`, `agent:${E2}`].includes(x.external_reference)).length === 1, { antes: gE0.body.ativo, depois: gE.body.ativo })

const f = res.filter((x) => !x.ok).length
if (!SO) saida(`\nResultado: ${res.length - f}/${res.length} verificações aprovadas.`)
server.close(); mp.close(); await d.close(); process.exit(f ? 1 : 0)
