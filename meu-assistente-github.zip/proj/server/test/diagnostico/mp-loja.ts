// DIAGNÓSTICO: Mercado Pago na configuração da loja (POST /api/v2/ads/:id/mp), pelo app real (createApp), em SQLite ou
// num Postgres real (--pg porta), com um dublê da API do Mercado Pago (/users/me). Reproduz os cenários de produção e
// confere: código HTTP, mensagem, persistência (recarregar = action 'status'), verificação da conexão, logs sem token.
// Uso: npx tsx test/diagnostico/mp-loja.ts [--pg 54329] [--mp-real]   (--mp-real usa api.mercadopago.com)
import { createServer } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'

const arg = (n: string) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : undefined }
const PG = arg('--pg'), MP_REAL = process.argv.includes('--mp-real')

// ---- logs: tudo o que o servidor escrever fica guardado para procurar tokens ----
const logs: string[] = []
for (const k of ['log', 'error', 'warn', 'info'] as const) { const o = console[k].bind(console); console[k] = (...a: any[]) => { logs.push(a.map((x) => (x instanceof Error ? x.stack || x.message : typeof x === 'string' ? x : JSON.stringify(x))).join(' ')); if (process.env.MOSTRAR_LOGS) o(...a) } }
const saida = (s: string) => process.stdout.write(s + '\n')

// ---- dublê da API do Mercado Pago ----
const tokensValidos = new Set(['APP_USR-1234567890123456-112115-0a1b2c3d4e5f60718293a4b5c6d7e8f9-123456789', 'TEST-1234567890123456-112115-0a1b2c3d4e5f60718293a4b5c6d7e8f9-987654321'])
const mp = createServer((req, res) => {
  const tok = String(req.headers.authorization || '').replace(/^Bearer /, '')
  if (req.url?.startsWith('/users/me')) { if (tokensValidos.has(tok)) { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ id: 123456789, nickname: 'LOJA_TESTE', email: 'loja@exemplo.com', site_id: 'MLB' })) } else { res.writeHead(401, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'invalid access token', status: 401 })) } return }
  res.writeHead(404); res.end('{}')
})
await new Promise<void>((r) => mp.listen(0, '127.0.0.1', r))
if (!MP_REAL) process.env.MP_API_BASE = `http://127.0.0.1:${(mp.address() as any).port}`

// ---- banco: SQLite novo ou um banco novo no Postgres real ----
const { setDb, q, one } = await import('../../src/db/index.js'), { migrate } = await import('../../src/db/migrate.js'), { config } = await import('../../src/config.js')
let d: any
if (PG) {
  const nome = 'mp_diag_' + Date.now()
  execFileSync('/usr/lib/postgresql/16/bin/psql', ['-h', '127.0.0.1', '-p', PG, '-U', 'postgres', '-qc', `CREATE DATABASE ${nome}`])
  d = await (await import('./pg-mini.js')).createPgMini({ host: '127.0.0.1', port: Number(PG), user: 'postgres', database: nome })
  saida(`Banco: PostgreSQL real (porta ${PG}, banco ${nome})`)
} else { d = await (await import('../../src/db/sqlite.js')).createSqlite(join(mkdtempSync(join(tmpdir(), 'ma-mp-')), 'mp.db')); saida('Banco: SQLite') }
setDb(d); await migrate(d, config.migrationsDir, () => {})
const { createApp } = await import('../../src/app.js')
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port

class Cli { jar = new Map<string, string>()
  async call(method: string, path: string, body?: unknown) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers: { 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: body === undefined ? undefined : JSON.stringify(body) })
    for (const c of r.headers.getSetCookie?.() || []) { const [kv] = c.split(';'); const [k, v] = kv.split('='); this.jar.set(k.trim(), v) }
    const t = await r.text(); let j: any; try { j = JSON.parse(t) } catch { j = t } return { status: r.status, body: j }
  } }
let n = 0, dono: Cli | null = null
async function lojaNova(status = 'ativo', plano = 'n4', data: Record<string, unknown> = {}) {
  n++
  if (!dono) { dono = new Cli(); const r = await dono.call('POST', '/api/auth', { action: 'signup', name: 'Dono Lojas', email: 'dono@mp.com', whatsapp: '+55 11 94444-1000', birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error('cadastro: ' + JSON.stringify(r.body)) }
  const c = dono, u = await one('SELECT id FROM users WHERE email = $1', ['dono@mp.com'])
  const exp = new Date(Date.now() + 30 * 86400_000).toISOString()
  const b = await one('INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, expires_at, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING id', [u!.id, 'P' + n, status, plano, JSON.stringify({ empresa: `Loja ${n}`, ...data }), exp, new Date().toISOString()])
  return { c, id: Number(b!.id) }
}
const mp_ = (L: { c: Cli; id: number }, body: unknown) => L.c.call('POST', `/api/v2/ads/${L.id}/mp`, body)
const TOK = MP_REAL ? (process.env.MP_TOKEN_TESTE || '') : [...tokensValidos][0]
const resultados: { cenario: string; ok: boolean; detalhe: string }[] = []
const registra = (cenario: string, ok: boolean, detalhe: unknown) => { resultados.push({ cenario, ok, detalhe: typeof detalhe === 'string' ? detalhe : JSON.stringify(detalhe).slice(0, 400) }); saida(`${ok ? '✔' : '✘'} ${cenario}\n    ${typeof detalhe === 'string' ? detalhe : JSON.stringify(detalhe).slice(0, 400)}`) }
const ultimosLogs = (desde: number) => logs.slice(desde).filter((l) => /\[api\]|erro|Error/i.test(l)).map((l) => l.split('\n').slice(0, 3).join(' | ')).join('\n      ')

// --mp-real: só os cenários que dependem da API oficial (o token vem de MP_TOKEN_TESTE e nunca é impresso)
if (MP_REAL) {
  if (!/^(APP_USR|TEST)-/.test(TOK)) { saida('Defina MP_TOKEN_TESTE com um Access Token (de preferência de teste) para usar --mp-real.'); process.exit(2) }
  const L = await lojaNova(), s1 = await mp_(L, { tok: TOK }), st = await mp_(L, { action: 'status' }), v = await mp_(L, { action: 'verificar' })
  registra('REAL. salvar o Access Token e conferir em api.mercadopago.com', s1.status === 200 && s1.body.verificado, { http: s1.status, message: s1.body.message || s1.body.error })
  registra('REAL. recarregar: continua salvo (mascarado)', st.body.mpLoja && /••••/.test(st.body.mpMasked || ''), { mpMasked: st.body.mpMasked })
  registra('REAL. verificar conexão', v.body.ok, v.body.message)
  const r = await mp_(L, { tok: 'APP_USR-0000000000000000-000000-ffffffffffffffffffffffffffffffff-000000000' })
  registra('REAL. token inválido é recusado pelo Mercado Pago e não substitui o válido', r.status === 400 && (await mp_(L, { action: 'verificar' })).body.ok, { http: r.status, erro: r.body.error })
  const vazou = logs.filter((l) => l.includes(TOK)); registra('REAL. logs sem o token', !vazou.length, `${logs.length} linhas verificadas`)
  const f = resultados.filter((x) => !x.ok).length; saida(`\nResultado: ${resultados.length - f}/${resultados.length}`); server.close(); mp.close(); await d.close(); process.exit(f ? 1 : 0)
}
// 1. Caminho normal
{ const L = await lojaNova(), l0 = logs.length
  const s = await mp_(L, { tok: TOK })
  registra('1. salvar Access Token (loja ativa, plano empresarial) e conferir no Mercado Pago', s.status === 200 && s.body.mpLoja && s.body.verificado, { http: s.status, resposta: s.body.error || { message: s.body.message, mpStatus: s.body.mpStatus, mpMasked: s.body.mpMasked }, logs: ultimosLogs(l0) })
  const r = await mp_(L, { action: 'status' })
  registra('1. recarregar a página: continua salvo', r.status === 200 && r.body.mpLoja && r.body.mpModo === 'manual', { mpLoja: r.body.mpLoja, mpModo: r.body.mpModo, mpMasked: r.body.mpMasked })
  const v = await mp_(L, { action: 'verificar' })
  registra('1. verificar conexão com o Mercado Pago', v.status === 200 && v.body.ok, { http: v.status, message: v.body.message })
  const t2 = await mp_(L, { tok: [...tokensValidos][1] })
  registra('1. trocar o token (segunda gravação: UPDATE com versão)', t2.status === 200 && /TEST-/.test(t2.body.mpMasked || '') , { http: t2.status, erro: t2.body.error, mpMasked: t2.body.mpMasked, logs: ultimosLogs(l0) })
  const sec = await mp_(L, { action: 'secret', secret: 'chave-secreta-webhook' })
  registra('1. salvar chave secreta do webhook', sec.status === 200 && sec.body.temChaveWebhook, { http: sec.status, erro: sec.body.error })
  const hist = await q('SELECT COUNT(*) AS n FROM empresa_integracoes_historico WHERE business_id = $1', [L.id])
  registra('1. histórico (backup das versões anteriores)', Number(hist[0].n) >= 2, { versoesNoHistorico: Number(hist[0].n) })
}
// 2. Token recusado pelo Mercado Pago: não grava e não substitui o token que funcionava
{ const L = await lojaNova(); await mp_(L, { tok: TOK })
  const s = await mp_(L, { tok: 'APP_USR-0000000000000000-000000-ffffffffffffffffffffffffffffffff-000000000' }), st = await mp_(L, { action: 'status' }), v = await mp_(L, { action: 'verificar' })
  registra('2. token recusado pelo Mercado Pago → 400 claro, e o token anterior continua valendo', s.status === 400 && /recusou/.test(s.body.error) && st.body.mpMasked === 'APP_US••••6789' && v.body.ok, { http: s.status, erro: s.body.error, depois: st.body.mpMasked, verificar: v.body.message }) }
// 2b. Public Key colada no lugar do Access Token; 2c. token colado com "Bearer " e quebra de linha
{ const L = await lojaNova(), pk = await mp_(L, { tok: 'APP_USR-1a2b3c4d-5e6f-4a7b-8c9d-0e1f2a3b4c5d' }), br = await mp_(L, { tok: `Bearer ${TOK}\n` })
  registra('2b. Public Key → explica que é preciso o Access Token', pk.status === 400 && /Public Key/.test(pk.body.error), { http: pk.status, erro: pk.body.error })
  registra('2c. token colado com "Bearer " e quebra de linha é aceito', br.status === 200 && br.body.verificado, { http: br.status, message: br.body.message }) }
// 3. Formato inválido
{ const L = await lojaNova(), s = await mp_(L, { tok: 'abc' })
  registra('3. formato inválido → 400 com mensagem', s.status === 400, { http: s.status, erro: s.body.error }) }
// 4. Loja aprovada pelo administrador, aguardando pagamento do anúncio (status "aprovado")
{ const L = await lojaNova('aprovado'), s = await mp_(L, { tok: TOK }), st = await mp_(L, { action: 'status' })
  registra('4. loja aprovada pelo administrador (aguardando pagamento) — salvar token e recarregar', s.status === 200 && st.body.permitido && st.body.mpLoja, { http: s.status, erro: s.body.error, permitido: st.body.permitido, mpLoja: st.body.mpLoja }) }
// 5. Loja ainda em análise (não aprovada) e plano sem recebimento: bloqueio legítimo, com o motivo certo
{ const L = await lojaNova('analise'), s = await mp_(L, { tok: TOK }), st = await mp_(L, { action: 'status' })
  registra('5. loja em análise → 403 dizendo que falta a aprovação do administrador', s.status === 403 && /aprova/.test(s.body.error) && /aprova/.test(st.body.motivoBloqueio || ''), { http: s.status, erro: s.body.error })
  const L2 = await lojaNova('ativo', 'n1'), s2 = await mp_(L2, { tok: TOK })
  registra('5b. plano sem recebimento → 403 com o motivo do plano', s2.status === 403 && /plano empresarial/.test(s2.body.error), { http: s2.status, erro: s2.body.error }) }
// 6. Token antigo (formato legado em businesses.data) e nova gravação
{ const { seal } = await import('../../src/lib/settings.js'); const velho = await seal('APP_USR-velho-1234567890-legado')
  const L = await lojaNova('ativo', 'n4', { mpTok: velho, mpSecret: await seal('segredo-velho') }), l0 = logs.length
  const st = await mp_(L, { action: 'status' }), s = await mp_(L, { tok: TOK })
  const dados = (await one('SELECT dados FROM empresa_integracoes WHERE business_id = $1 AND provedor = $2', [L.id, 'mercadopago']))
  const dd = typeof dados?.dados === 'string' ? JSON.parse(dados.dados) : dados?.dados
  registra('6. integração antiga (businesses.data) é importada e o token novo é salvo', st.body.mpLoja && s.status === 200, { status: st.status, salvar: s.status, erro: s.body.error, logs: ultimosLogs(l0) })
  registra('6. a chave secreta antiga do webhook é mantida ao trocar o token', !!dd?.mpSecret, { temMpSecret: !!dd?.mpSecret }) }
// 7. Cofre sem chave (APP_SECRET vazio e a chave do banco ausente, com credenciais cifradas existentes)
{ const S = await import('../../src/lib/settings.js'); const L = await lojaNova(), l0 = logs.length
  const { getConfig, setConfig } = await import('../../src/lib/settings.js'), antes = await getConfig<string>('vault-key', ''), env = process.env.APP_SECRET
  const atual = await mp_(L, { tok: TOK })
  await q("DELETE FROM app_config WHERE key = 'vault-key'"); delete process.env.APP_SECRET; S.recarregarCofre()
  const s = await mp_(L, { tok: TOK })
  const dd = await one('SELECT dados FROM empresa_integracoes WHERE business_id = $1', [L.id])
  registra('7. cofre sem chave → 503 com o motivo (não "Algo deu errado"); nada gravado', s.status === 503 && /chave de criptografia/.test(s.body.error) && atual.status === 200 && JSON.stringify(dd?.dados).includes('v2:'), { http: s.status, erro: s.body.error, logs: ultimosLogs(l0) })
  if (antes) await setConfig('vault-key', antes); if (env) process.env.APP_SECRET = env; S.recarregarCofre()
  const depois = await mp_(L, { action: 'verificar' })
  registra('7. com a chave restaurada, a credencial salva antes volta a funcionar', depois.body.ok, depois.body.message) }

// 8. Cenário de produção: sem APP_SECRET (chave do cofre guardada no banco), salvar, REINICIAR o servidor e salvar de novo
{ const S = await import('../../src/lib/settings.js'), env = process.env.APP_SECRET; delete process.env.APP_SECRET; S.recarregarCofre()
  const L = await lojaNova(), l0 = logs.length, k0 = await S.getConfig<string>('vault-key', '')
  const s1 = await mp_(L, { tok: TOK })
  S.recarregarCofre() // reinício: as chaves em memória são descartadas e relidas do banco
  const st = await mp_(L, { action: 'status' }), v = await mp_(L, { action: 'verificar' })
  const L2 = await lojaNova(), s2 = await mp_(L2, { tok: TOK })
  S.recarregarCofre(); const k1 = await S.getConfig<string>('vault-key', '')
  registra('8. sem APP_SECRET: a chave do cofre é lida do banco (não vem vazia)', k0.length >= 32 && k0 === k1, { tamanho: k0.length, mesmaDepoisDeReiniciar: k0 === k1 })
  registra('8. depois de reiniciar: o token salvo continua legível e a conexão é confirmada', s1.status === 200 && st.body.mpLoja && !st.body.credencialIlegivel && v.body.ok, { salvar: s1.status, credencialIlegivel: st.body.credencialIlegivel, verificar: v.body.message })
  registra('8. depois de reiniciar: salvar um novo Access Token funciona (antes: "Algo deu errado no servidor")', s2.status === 200 && s2.body.verificado, { http: s2.status, erro: s2.body.error, logs: ultimosLogs(l0) })
  if (env) process.env.APP_SECRET = env; S.recarregarCofre() }
// Logs: nenhum token pode aparecer
const vazou = logs.filter((l) => [...tokensValidos, 'APP_USR-velho', 'chave-secreta-webhook', 'APP_USR-0000000000000000'].some((t) => l.includes(t)))
registra('Logs do servidor não contêm tokens nem a chave secreta', vazou.length === 0, vazou.length ? vazou.slice(0, 3).join(' | ') : `${logs.length} linhas de log verificadas`)
// Banco: o token fica cifrado
const linhas = await q('SELECT dados FROM empresa_integracoes')
registra('Banco: tokens ficam cifrados (nenhum em texto puro)', !linhas.some((r: any) => (typeof r.dados === 'string' ? r.dados : JSON.stringify(r.dados)).includes('APP_USR-1234')), `${linhas.length} integrações verificadas`)

const falhas = resultados.filter((r) => !r.ok).length
saida(`\nResultado: ${resultados.length - falhas}/${resultados.length} cenários aprovados.`)
server.close(); mp.close(); await d.close()
process.exit(falhas ? 1 : 0)
