// Reproduz conversas reais no servidor: cada argumento é uma mensagem (separe conversas com "||"). Mostra resposta, via e etapas.
import { DatabaseSync } from 'node:sqlite'
const BASE = process.env.BASE!, db = new DatabaseSync(process.env.SQLITE_FILE!)
class Cli { jar = new Map<string,string>(); async call(m: string, p: string, b?: any) { const r = await fetch(BASE + p, { method: m, headers: { ...(b !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': '10.8.' + Math.floor(Math.random()*200) + '.' + Math.floor(Math.random()*200) }, body: b !== undefined ? JSON.stringify(b) : undefined }); for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v) } const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) } } catch { return { status: r.status, body: t } } } }
const u = new Cli(), n = 'casos' + Date.now()
await u.call('POST', '/api/auth', { action: 'signup', name: 'Wes Teste', whatsapp: '+55 11 93333-' + String(Date.now()).slice(-4), email: n + '@auto-teste.com', birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
if (process.env.EMPRESA) { const ad = await u.call('POST', '/api/v2/ads', { planId: 'n4', empresa: 'Estúdio Tatu', categoria: 'Tatuagem', titulo: 'x', texto: 'Tatuagens', zap: '5585999990000' }); db.prepare("UPDATE businesses SET status='ativo', expires_at='2099-01-01T00:00:00Z' WHERE id=?").run(ad.body.items[0].id) }
let CONV = crypto.randomUUID()
for (const t of process.argv.slice(2)) {
  if (t === '||') { CONV = crypto.randomUUID(); console.log('\n---- nova conversa'); continue }
  const t0 = Date.now(), r = await u.call('POST', '/api/chat', { text: t, conversationId: CONV }), ms = Date.now() - t0
  const tr: any = db.prepare('SELECT via, detail, result, retrieved FROM brain_chat_traces ORDER BY id DESC LIMIT 1').get()
  let d: any = {}; try { d = JSON.parse(tr?.detail || '{}') } catch {}
  console.log(`\n>> ${t}\n<< [${r.status} ${ms}ms via=${tr?.via} result=${tr?.result} rec=${tr?.retrieved} tipo=${d.tipo}] ${String(r.body?.assistantMessage?.content || JSON.stringify(r.body)).slice(0, 400)}`)
}
