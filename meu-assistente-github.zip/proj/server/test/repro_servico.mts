// Prova do caso 1: com um conhecimento "Serviço Social" na biblioteca, a frase informal recupera esse conhecimento?
import { DatabaseSync } from 'node:sqlite'
const BASE = process.env.BASE!, db = new DatabaseSync(process.env.SQLITE_FILE!)
class Cli { jar = new Map<string,string>(); async call(m: string, p: string, b?: any) { const r = await fetch(BASE + p, { method: m, headers: { ...(b !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': '10.7.' + Math.floor(Math.random()*200) + '.' + Math.floor(Math.random()*200) }, body: b !== undefined ? JSON.stringify(b) : undefined }); for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v) } const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) } } catch { return { status: r.status, body: t } } } }
const a = new Cli(), em = 'adm' + Date.now() + '@auto-teste.com'
const su = await a.call('POST', '/api/auth', { action: 'signup', name: 'Admin Teste', whatsapp: '+55 11 92222-' + String(Date.now()).slice(-4), email: em, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
console.log('signup', su.status, JSON.stringify(su.body).slice(0,200)); db.prepare("UPDATE users SET role='superadmin' WHERE email=?").run(em); a.jar.clear(); console.log('login', (await a.call('POST', '/api/auth', { action: 'login', email: em, password: 'Senha@Forte123' })).status)
const d = process.env.SEM_DOC ? { status: 0, body: {} } as any : await a.call('POST', '/api/brain/knowledge', { titulo: 'Serviço Social', conteudo: 'Serviço Social é uma profissão de nível superior que atua na garantia de direitos e no enfrentamento das expressões da questão social. O trabalho do assistente social envolve atendimento, orientação e encaminhamento de pessoas e famílias, no período da manhã ou da tarde, em instituições públicas e privadas.', palavrasChave: 'serviço social, assistente social, trabalho social' })
console.log('conhecimento', d.status, d.body?.status)
const CONV = crypto.randomUUID()
for (const t of process.argv.slice(2)) {
  const r = await a.call('POST', '/api/chat', { text: t, conversationId: CONV })
  const tr: any = db.prepare('SELECT intent, result, retrieved, docs FROM brain_chat_traces ORDER BY id DESC LIMIT 1').get()
  console.log(`>> ${t}\n<< ${String(r.body?.assistantMessage?.content).slice(0, 200)}\n   rastro: intent=${tr.intent} result=${tr.result} recuperados=${tr.retrieved} docs=${tr.docs}`)
}
