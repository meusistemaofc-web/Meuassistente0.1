// TESTES DE INTEGRAÇÃO — HIERARQUIA DE DECISÃO DO CHAT (fluxo real: POST /api/chat, dublês de IA e de internet)
//   1. contexto e continuidade  — complementos e correções SEM verbo de edição ("ah, é com a Dra. Ana", "na verdade é às 10h",
//                                 "foi no cartão") vão para o registro desta conversa; mudança de assunto não herda nada
//   2. recursos internos         — execução × consulta × sugestão: "devo marcar…?" e "posso marcar…?" NÃO executam; dados
//                                 próprios (clientes, contas, agenda) nunca vão para a internet
//   3. Cérebro Central           — pergunta geral: Cérebro primeiro, pesquisa só se ele não souber
//   4. pesquisa externa          — pedido explícito ou informação atual
// Também: persistência (o registro muda no banco, sem duplicar), isolamento entre usuários e conversas, e rastro da decisão.
// Uso: npm run test:hierarquia
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
process.env.SONDA_FERRAMENTAS = '1'
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, J } = await import('../src/db/index.js')
const PB = await import('../src/ai/bloqueio-pesquisa.js')
const { localDate, addDays } = await import('../src/lib/time.js')
const TZ = 'America/Sao_Paulo', HOJE = localDate(TZ), AMANHA = addDays(HOJE, 1)

let ok = 0, falhas = 0
const erros: string[] = []
function check(cond: unknown, msg: string) { if (cond) { ok++; console.log('    ✓', msg) } else { falhas++; erros.push(msg); console.log('    ✗', msg) } }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
type Turno = { fala: string; resp: string; st: import('../src/ai/bloqueio-pesquisa.js').EstadoTurno; buscas: string[]; ia: number; tools: string[][] }
const ESCRITA = /^(create_|add_|update_|delete_|registrar|cancel|marcar|mover|editar|criar|agendar|remarcar|concluir|set_)/
class Conversa {
  conv = crypto.randomUUID(); turnos: Turno[] = []
  constructor(public cli: InstanceType<typeof S.Cli>, public uid: number) {}
  async diga(fala: string): Promise<Turno> {
    const n0 = PB.turnosTeste.length, b0 = S.buscas.length, i0 = S.chamadasIA.length
    const r = await this.cli.call('POST', '/api/chat', { text: fala, conversationId: this.conv })
    await sleep(120)
    const resp = String(r.body?.assistantMessage?.content ?? JSON.stringify(r.body).slice(0, 200))
    const t: Turno = { fala, resp, st: PB.turnosTeste[n0], buscas: S.buscas.slice(b0), ia: S.chamadasIA.length - i0, tools: S.chamadasIA.slice(i0).map((c) => c.tools || []) }
    this.turnos.push(t)
    console.log(`  👤 ${fala}\n  🤖 ${resp.replace(/⟦[^⟧]*⟧/g, '').replace(/\n+/g, ' ⏎ ').slice(0, 170)}\n     [${t.st?.prioridade || '?'} · nível ${t.st?.nivel ?? '?'} ${t.st?.modo || ''}${t.st?.bloqueada ? ' · pesquisa BLOQUEADA' : ''} · buscas=${t.buscas.length} · IA=${t.ia}]`)
    return t
  }
}
let nIp = 0; const fetch0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? fetch0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.8.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : fetch0(u, o)) as typeof fetch
async function novo() { const cli = await S.novoUsuario(); const me = await cli.call('GET', '/api/me'); const uid = Number(me.body?.user?.id ?? me.body?.id ?? (await q('SELECT id FROM users ORDER BY id DESC LIMIT 1'))[0].id); return new Conversa(cli, uid) }
const itens = async (uid: number, tipo: string) => (await q('SELECT id, status, day, due_at, data FROM items WHERE user_id = $1 AND type = $2 ORDER BY id', [uid, tipo])).map((r: any) => ({ ...r, d: J<any>(r.data, {}) }))
const semWeb = (t: Turno, rot = '') => { check(t.st?.bloqueada, `${rot}"${t.fala}" → pesquisa externa bloqueada`); check(t.buscas.length === 0, `${rot}"${t.fala}" → nenhum buscador consultado`) }
const semEscrita = (t: Turno) => check(t.tools.every((ts) => !ts.some((n) => ESCRITA.test(n))), `"${t.fala}" → a IA recebeu só ferramentas de leitura`)
const nivel = (t: Turno, n: number, modo?: string) => check(t.st?.nivel === n && (!modo || t.st?.modo === modo), `"${t.fala}" → nível ${n}${modo ? ' / ' + modo : ''} (veio: ${t.st?.nivel} / ${t.st?.modo} — ${t.st?.motivo || ''})`)

/* ======================= 1. CONTEXTO E CONTINUIDADE ======================= */
console.log('\n# 1. CONTEXTO E CONTINUIDADE (complementos e correções sem verbo de edição)')
{ console.log('\n## compromisso + complementos'); const c = await novo()
  await c.diga('agenda dentista amanhã às 9h')
  const t1 = await c.diga('ah, é com a Dra. Ana'); semWeb(t1); nivel(t1, 1, 'complemento')
  const t2 = await c.diga('o endereço é Rua das Flores, 120'); semWeb(t2); nivel(t2, 1, 'complemento')
  const t3 = await c.diga('esqueci de dizer que é para levar os exames'); semWeb(t3)
  const t4 = await c.diga('na verdade é às 10h'); semWeb(t4); nivel(t4, 1, 'correcao')
  const a = await itens(c.uid, 'appointment'); const n = `${a[0]?.d.notes || ''} ${a[0]?.d.clienteNome || ''} ${a[0]?.d.local || ''}`
  check(a.length === 1, 'um único compromisso (complementos não criam outro)')
  check(/Dra\.? Ana/i.test(n), 'complemento "é com a Dra. Ana" gravado'); check(/Rua das Flores/i.test(n), 'endereço gravado'); check(/exames/i.test(n), '"levar os exames" gravado')
  check(a[0]?.d.time === '10:00' && a[0]?.day === AMANHA, 'correção do horário (10h) com a data preservada')
  check([t1, t2, t3, t4].every((t) => t.ia === 0), 'complementos resolvidos sem IA')
}
{ console.log('\n## gasto + complementos'); const c = await novo()
  await c.diga('gastei 50 no almoço')
  const t1 = await c.diga('foi no cartão de crédito'); semWeb(t1); nivel(t1, 1)
  const t2 = await c.diga('na verdade foram 45'); semWeb(t2); nivel(t2, 1, 'correcao')
  const t3 = await c.diga('era almoço com cliente'); semWeb(t3)
  const e = await itens(c.uid, 'expense'); check(e.length === 1, 'um único lançamento')
  check(/cr[ée]dito/i.test(`${e[0]?.d.method || ''} ${e[0]?.d.notes || ''}`), 'forma de pagamento: cartão de crédito'); check(Number(e[0]?.d.amount) === 45, 'valor corrigido para 45')
  check(/cliente/i.test(`${e[0]?.d.description || ''} ${e[0]?.d.notes || ''}`), 'complemento "almoço com cliente" gravado')
}
{ console.log('\n## lembrete + correção'); const c = await novo()
  await c.diga('me lembra de ligar para o João amanhã às 9h')
  const t = await c.diga('na verdade às 10h'); semWeb(t); nivel(t, 1, 'correcao')
  const r = await itens(c.uid, 'reminder'); check(r.length === 1 && r[0].d.time === '10:00' && r[0].day === AMANHA, 'lembrete → amanhã 10h (sem duplicar)')
}
{ console.log('\n## anotação e tarefa + complemento; agradecimento não altera nada'); const c = await novo()
  await c.diga('anota que a reunião com o fornecedor foi produtiva')
  const t1 = await c.diga('detalhe: o cliente aprovou o orçamento'); semWeb(t1); nivel(t1, 1, 'complemento')
  const n = await itens(c.uid, 'note'); check(n.length === 1 && /aprovou o or[çc]amento/i.test(n[0]?.d.content || ''), 'anotação complementada (sem criar outra)')
  await c.diga('agenda revisão do carro amanhã às 8h')
  const t2 = await c.diga('beleza, obrigado'); check(t2.st?.modo !== 'complemento' && t2.st?.modo !== 'correcao', 'agradecimento não vira complemento')
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && !(a[0].d.notes || '').trim(), 'compromisso sem alteração indevida')
}
{ console.log('\n## pedido educado executa; consulta financeira é interna'); const c = await novo()
  const t = await c.diga('tem como me lembrar de pagar a luz amanhã às 9h?'); semWeb(t); nivel(t, 2, 'execucao')
  const r = await itens(c.uid, 'reminder'); check(r.length === 1 && r[0].d.time === '09:00', 'lembrete criado')
  await c.diga('gastei 80 no mercado')
  const g = await c.diga('quanto gastei hoje?'); semWeb(g); nivel(g, 2, 'consulta'); check(/80/.test(g.resp), 'resposta com o dado real (R$ 80)')
}
{ console.log('\n## mudança de assunto não herda a última ação'); const c = await novo()
  await c.diga('agenda reunião com a Ana amanhã às 15h')
  const k = await c.diga('O que é o Protocolo Zyntra?'); check(!k.st?.bloqueada, 'pergunta geral: não fica presa à agenda'); nivel(k, 3)
  const g = await c.diga('gastei 30 no uber'); nivel(g, 2, 'execucao'); check((await itens(c.uid, 'expense')).length === 1, 'gasto novo registrado (não virou complemento da reunião)')
  const p = await c.diga('pesquise na internet a história do carro Jaguar'); nivel(p, 4); check(p.buscas.length > 0 || p.st?.eventos.some((e) => (e.tipo === 'busca_web' || e.tipo === 'cerebro_pesquisa') && !e.bloqueado), 'pesquisa explícita consultou a internet (mesmo com a última ação sendo um gasto)')
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '15:00' && !/zyntra|uber/i.test(a[0].d.notes || ''), 'reunião intacta')
  const v = await c.diga('na verdade a reunião é às 16h'); semWeb(v); const b = await itens(c.uid, 'appointment'); check(b[0]?.d.time === '16:00', 'volta ao assunto: correção da reunião (16h)')
}
{ console.log('\n## complemento sem ação recente: não adivinha nem pesquisa'); const c = await novo()
  const t = await c.diga('ah, é com a Dra. Ana'); semWeb(t)
  check((await itens(c.uid, 'appointment')).length === 0, 'nada criado nem alterado')
}

/* ======================= 2. RECURSOS INTERNOS: execução × consulta × sugestão ======================= */
console.log('\n# 2. RECURSOS INTERNOS (execução × consulta × sugestão)')
{ console.log('\n## sugestão e consulta não executam'); const c = await novo()
  await c.diga('agenda reunião com o time amanhã às 14h')
  const s1 = await c.diga('você acha que devo remarcar a reunião de amanhã?'); semWeb(s1); nivel(s1, 2, 'sugestao'); semEscrita(s1)
  const s2 = await c.diga('devo marcar o dentista amanhã às 9h?'); semWeb(s2); nivel(s2, 2, 'sugestao'); semEscrita(s2)
  const s3 = await c.diga('posso marcar algo amanhã às 15h?'); semWeb(s3); nivel(s3, 2, 'consulta')
  const s4 = await c.diga('qual o melhor horário para marcar o dentista essa semana?'); semWeb(s4); nivel(s4, 2, 'sugestao'); semEscrita(s4)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '14:00' && a[0].status !== 'cancelled', 'nenhum compromisso criado, remarcado ou cancelado')
  const x = await c.diga('agende o dentista amanhã às 9h'); nivel(x, 2, 'execucao'); check((await itens(c.uid, 'appointment')).length === 2, 'pedido de execução cria o compromisso')
}
{ console.log('\n## consultas internas nunca vão para a internet'); const c = await novo()
  await c.diga('agenda corte com o cliente Marcos amanhã às 11h'); await c.diga('coloque o telefone também: 11 97777-6666')
  for (const f of ['qual o telefone do cliente Marcos?', 'quando vence a conta de luz?', 'quantos pedidos minha loja teve hoje?', 'qual o meu plano?']) { const t = await c.diga(f); semWeb(t); nivel(t, 2, 'consulta'); semEscrita(t) }
}

/* ======================= 3 e 4. CÉREBRO CENTRAL e PESQUISA EXTERNA ======================= */
console.log('\n# 3/4. CÉREBRO CENTRAL e PESQUISA EXTERNA')
{ const c = await novo()
  const k = await c.diga('o que é o Protocolo Zyntra?'); nivel(k, 3); check(!k.st?.bloqueada, 'conhecimento: Cérebro primeiro, pesquisa só se ele não souber (permitida)')
  const d = await c.diga('qual a cotação do dólar hoje?'); nivel(d, 4); check(!d.st?.bloqueada, 'informação atual: pesquisa permitida')
  const e = await c.diga('pesquise na internet restaurantes japoneses'); nivel(e, 4); check(e.buscas.length > 0, 'pesquisa explícita usa os buscadores')
  const o = await c.diga('anota que a pesquisa de satisfação ficou para sexta'); semWeb(o); nivel(o, 2, 'execucao')
}

/* ======================= SEGURANÇA e PERSISTÊNCIA ======================= */
console.log('\n# SEGURANÇA e PERSISTÊNCIA')
{ const a = await novo(); await a.diga('agenda fisioterapia amanhã às 8h')
  const outraConv = new Conversa(a.cli, a.uid); const t = await outraConv.diga('na verdade é às 9h'); semWeb(t)
  check((await itens(a.uid, 'appointment'))[0]?.d.time === '08:00', 'complemento em OUTRA conversa não altera o registro desta')
  const b = await novo(); const tb = await b.diga('na verdade é às 9h'); semWeb(tb)
  check((await itens(a.uid, 'appointment'))[0]?.d.time === '08:00', 'outro usuário não altera o registro')
  const tr: any = (await q("SELECT detail FROM brain_chat_traces ORDER BY id DESC LIMIT 30")).map((r: any) => J<any>(r.detail, {})).find((d: any) => d?.prioridade?.nivel)
  check(tr && tr.prioridade.nivel && tr.prioridade.modo !== undefined, 'decisão (nível e modo) registrada no rastro do turno')
}

console.log(`\n${falhas ? '❌' : '✅'} ${ok} verificações ok, ${falhas} falharam`)
if (falhas) console.log(erros.map((e) => '  - ' + e).join('\n'))
process.exit(falhas ? 1 : 0)
