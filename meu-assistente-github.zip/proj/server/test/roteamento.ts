// TESTES DE REGRESSÃO — PRIORIDADE OPERACIONAL, CONTINUIDADE E CONTROLE DE PESQUISA (fluxo real: POST /api/chat)
// Cada sequência roda numa conversa nova, com um usuário novo, contra os dublês de IA (compatível com OpenAI) e de internet
// (SearXNG) de test/diagnostico/sonda-inteligencia.ts. Para cada mensagem é conferido:
//   • se a pesquisa externa foi bloqueada/permitida (motor de prioridade) e se algum buscador recebeu requisição;
//   • se houve grounding (IA com busca) ou agente de Pesquisa acionado; se houve chamada de IA desnecessária;
//   • no banco: o registro mudou de verdade, os outros dados foram preservados, nada foi duplicado.
// Uso: npm run test:roteamento
process.env.CEREBRO_PERMITIR_REDE_LOCAL = '1'
process.env.SONDA_FERRAMENTAS = '1' // o dublê de IA usa as ferramentas de criação (tarefa/nota/conta), como uma IA real
const S = await import('./diagnostico/sonda-inteligencia.js')
const { q, J } = await import('../src/db/index.js')
const PB = await import('../src/ai/bloqueio-pesquisa.js')
const { localDate, addDays } = await import('../src/lib/time.js')
const TZ = 'America/Sao_Paulo', HOJE = localDate(TZ), AMANHA = addDays(HOJE, 1)
const proxDia = (w: number) => { const cur = new Date(HOJE + 'T12:00:00Z').getUTCDay(); return addDays(HOJE, ((w - cur + 7) % 7) || 7) }

let ok = 0, falhas = 0
const erros: string[] = []
function check(cond: unknown, msg: string) { if (cond) { ok++; console.log('    ✓', msg) } else { falhas++; erros.push(msg); console.log('    ✗', msg) } }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

type Turno = { fala: string; resp: string; st: import('../src/ai/bloqueio-pesquisa.js').EstadoTurno; buscas: string[]; ia: number }
class Conversa {
  conv = crypto.randomUUID(); turnos: Turno[] = []
  constructor(public cli: InstanceType<typeof S.Cli>, public uid: number) {}
  async diga(fala: string): Promise<Turno> {
    const n0 = PB.turnosTeste.length, b0 = S.buscas.length, i0 = S.chamadasIA.length
    const r = await this.cli.call('POST', '/api/chat', { text: fala, conversationId: this.conv })
    await sleep(120) // pesquisa que segue em segundo plano termina aqui (fica atribuída a este turno)
    const resp = String(r.body?.assistantMessage?.content ?? JSON.stringify(r.body).slice(0, 200))
    const t: Turno = { fala, resp, st: PB.turnosTeste[n0], buscas: S.buscas.slice(b0), ia: S.chamadasIA.length - i0 }
    this.turnos.push(t)
    console.log(`  👤 ${fala}\n  🤖 ${resp.replace(/⟦[^⟧]*⟧/g, '').replace(/\n+/g, ' ⏎ ').slice(0, 170)}\n     [${t.st?.prioridade || '?'}${t.st?.bloqueada ? ' · pesquisa BLOQUEADA' : ''} · buscas=${t.buscas.length} · IA=${t.ia}${t.st?.eventos.some((e) => e.tipo === 'grounding' && !e.bloqueado) ? ' · GROUNDING' : ''}${t.st?.eventos.some((e) => e.tipo === 'agente_pesquisa' && !e.bloqueado) ? ' · AGENTE PESQUISA' : ''}]`)
    return t
  }
}
// cada sequência tem o próprio usuário; o limite de cadastros por rede (10/h) é contornado só no teste, com um IP de origem por cadastro
let nIp = 0; const fetch0 = globalThis.fetch
globalThis.fetch = ((u: any, o: any = {}) => /\/api\/auth$/.test(String(u)) && /"signup"/.test(String(o?.body || '')) ? fetch0(u, { ...o, headers: { ...(o.headers || {}), 'X-Forwarded-For': `10.9.${Math.floor(++nIp / 250)}.${nIp % 250}` } }) : fetch0(u, o)) as typeof fetch
async function novo() { const cli = await S.novoUsuario(); const me = await cli.call('GET', '/api/me'); const uid = Number(me.body?.user?.id ?? me.body?.id ?? (await q('SELECT id FROM users ORDER BY id DESC LIMIT 1'))[0].id); return new Conversa(cli, uid) }
const itens = async (uid: number, tipo: string) => (await q('SELECT id, status, day, due_at, data FROM items WHERE user_id = $1 AND type = $2 ORDER BY id', [uid, tipo])).map((r: any) => ({ ...r, d: J<any>(r.data, {}) }))
/** turno operacional: pesquisa bloqueada, nenhum buscador, nenhum grounding, nenhum agente de pesquisa */
function semPesquisa(t: Turno, rot = '') {
  check(t.st?.bloqueada, `${rot}"${t.fala}" → pesquisa bloqueada (${t.st?.prioridade})`)
  check(t.buscas.length === 0, `${rot}"${t.fala}" → nenhuma requisição a buscador`)
  check(!t.st?.eventos.some((e) => (e.tipo === 'grounding' || e.tipo === 'busca_web' || e.tipo === 'agente_pesquisa') && !e.bloqueado), `${rot}"${t.fala}" → sem grounding / agente de pesquisa`)
}
const semIA = (t: Turno) => check(t.ia === 0, `"${t.fala}" → resolvido sem chamada de IA`)

/* ============================== AGENDA ============================== */
console.log('\n# AGENDA')
{ console.log('\n## criar + observação'); const c = await novo()
  semPesquisa(await c.diga('agenda corte de cabelo com o João amanhã às 14h'))
  const t1 = await c.diga('adicione uma observação'); semPesquisa(t1); semIA(t1); check(/informa|observa/i.test(t1.resp), 'pergunta qual observação')
  const t2 = await c.diga('cliente prefere a máquina 2'); semPesquisa(t2); semIA(t2)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1, 'um único compromisso (sem duplicar)')
  check(/máquina 2/.test(a[0]?.d.notes || ''), 'observação gravada'); check(a[0]?.day === AMANHA && a[0]?.d.time === '14:00', 'data e horário preservados')
  const t3 = await c.diga('adicione uma observação: trazer foto de referência'); semIA(t3)
  const b = await itens(c.uid, 'appointment'); check(/máquina 2/.test(b[0]?.d.notes) && /foto de refer/.test(b[0]?.d.notes), 'observação acrescentada sem apagar a anterior')
}
{ console.log('\n## criar + horário'); const c = await novo()
  await c.diga('agenda reunião com a Ana sexta às 10h')
  const t = await c.diga('Mude para 15h'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '15:00', 'horário 15:00'); check(a[0]?.day === proxDia(5), 'data preservada (sexta)')
  const t2 = await c.diga('só altere o horário'); semPesquisa(t2); check(/hor[áa]rio/i.test(t2.resp), 'pergunta o novo horário')
  await c.diga('16h30'); const b = await itens(c.uid, 'appointment'); check(b.length === 1 && b[0].d.time === '16:30', 'horário 16:30 pela resposta curta')
  const t3 = await c.diga('É esse mesmo'); semPesquisa(t3); semIA(t3); check(/mantive/i.test(t3.resp), 'confirma sem alterar')
}
{ console.log('\n## criar + data'); const c = await novo()
  await c.diga('agenda dentista quinta às 9h')
  const t = await c.diga('altere para amanhã'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].day === AMANHA, 'data → amanhã'); check(a[0]?.d.time === '09:00', 'horário preservado')
}
{ console.log('\n## criar + valor'); const c = await novo()
  const t0 = await c.diga('agenda manicure com a Bia amanhã às 16h, valor R$ 50'); semPesquisa(t0)
  if (/sim|confirm|salvar/i.test(t0.resp)) await c.diga('sim')
  const t = await c.diga('corrija o valor para 60 reais'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1, 'um único compromisso'); check(Number(a[0]?.d.valorTotal ?? a[0]?.d.valor_total) === 60, 'valor total 60'); check(a[0]?.d.time === '16:00' && a[0]?.day === AMANHA, 'data/horário preservados')
  const t2 = await c.diga('corrija o valor'); semPesquisa(t2); check(/valor/i.test(t2.resp), 'sem o número: pergunta o valor')
  await c.diga('75'); const b = await itens(c.uid, 'appointment'); check(Number(b[0]?.d.valorTotal ?? b[0]?.d.valor_total) === 75, 'valor 75 pela resposta curta')
}
{ console.log('\n## criar + cliente'); const c = await novo()
  const t0 = await c.diga('agenda consulta amanhã às 11h com o Pedro'); semPesquisa(t0)
  check((await itens(c.uid, 'appointment')).length === 1, 'cria o compromisso (não responde como consulta da agenda)')
  const t = await c.diga('troque o cliente para Marcos'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && /Marcos/.test(a[0].d.clienteNome || ''), 'cliente → Marcos'); check(a[0]?.d.time === '11:00', 'horário preservado')
}
{ console.log('\n## criar + cancelar'); const c = await novo()
  await c.diga('agenda visita técnica amanhã às 8h'); const a0 = await itens(c.uid, 'appointment'); check(a0.length === 1 && /visita t[ée]cnica/i.test(a0[0].d.title), 'cria "Visita técnica"')
  const t = await c.diga('Pode cancelar'); semPesquisa(t); semIA(t); check(/confirma/i.test(t.resp), 'pede confirmação antes de cancelar')
  const t2 = await c.diga('sim'); semPesquisa(t2)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].status === 'cancelled', 'compromisso cancelado (sem apagar)')
}
{ console.log('\n## criar + telefone'); const c = await novo()
  await c.diga('agenda massagem com a Carla amanhã às 17h'); const a0 = await itens(c.uid, 'appointment'); check(a0.length === 1 && /massagem/i.test(a0[0].d.title), 'cria "Massagem" (não pergunta "qual é o compromisso")')
  const t = await c.diga('coloque o telefone também: 11 98888-7777'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a[0]?.d.clienteTelefone === '11988887777', 'telefone gravado'); check(a[0]?.d.time === '17:00', 'horário preservado')
}
{ console.log('\n## criar + pedidos vagos (acrescente essa informação / inclua mais um detalhe / modifique o agendamento)'); const c = await novo()
  await c.diga('agenda sessão de fotos com a Lia sábado às 10h')
  const t1 = await c.diga('acrescente essa informação'); semPesquisa(t1); semIA(t1); check(/informa/i.test(t1.resp), 'pergunta qual informação')
  await c.diga('levar figurino azul')
  const t2 = await c.diga('inclua mais um detalhe: estacionar na rua de trás'); semPesquisa(t2); semIA(t2)
  const t3 = await c.diga('Modifique o agendamento'); semPesquisa(t3); semIA(t3); check(/alterar/i.test(t3.resp), 'pergunta o que alterar')
  await c.diga('para as 11h')
  const a = await itens(c.uid, 'appointment'); check(a.length === 1, 'um único compromisso'); check(/figurino azul/.test(a[0]?.d.notes) && /rua de tr/.test(a[0]?.d.notes), 'as duas informações gravadas'); check(a[0]?.d.time === '11:00', 'horário 11:00')
}
{ console.log('\n## consultar + modificar'); const c0 = await novo()
  await c0.diga('agenda dentista amanhã às 9h')
  const c = new Conversa(c0.cli, c0.uid)
  const t0 = await c.diga('o que tenho amanhã?'); semPesquisa(t0); semIA(t0)
  const t = await c.diga('modifique o agendamento do dentista para 10h'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '10:00' && a[0].day === AMANHA, 'dentista → 10h, mesma data')
}
{ console.log('\n## pesquisa → modificar compromisso'); const c = await novo()
  await c.diga('agenda reunião com a Ana sexta às 10h')
  const p = await c.diga('O que é o Protocolo Zyntra?'); check(!p.st?.bloqueada, 'pergunta de conhecimento: pesquisa permitida')
  const t = await c.diga('mude a reunião com a Ana para 16h'); semPesquisa(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '16:00', 'reunião → 16h')
  check(!t.buscas.some((b) => /zyntra/i.test(b)), 'não herdou o assunto pesquisado')
}
{ console.log('\n## pesquisa → novo compromisso'); const c = await novo()
  await c.diga('O que é a Norma Velnor?')
  const t = await c.diga('agenda revisão do carro segunda às 9h'); semPesquisa(t); semIA(t)
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && /revis/i.test(a[0].d.title) && a[0].day === proxDia(1), 'cria "Revisão do carro" na segunda')
}
{ console.log('\n## continuações curtas logo depois de uma pesquisa (nenhuma pode pesquisar)'); const c0 = await novo()
  for (const f of ['adicione uma observação', 'Mude para 15h', 'altere para amanhã', 'corrija o valor', 'coloque o telefone também', 'acrescente essa informação', 'Modifique o agendamento', 'Pode cancelar', 'É esse mesmo', 'só altere o horário', 'inclua mais um detalhe']) {
    const c = new Conversa(c0.cli, c0.uid); await c.diga('O que é o Protocolo Zyntra?'); const t = await c.diga(f)
    semPesquisa(t, '[pós-pesquisa] '); check(!t.st?.eventos.some((e) => e.tipo === 'ia') || t.ia <= 1, `[pós-pesquisa] "${f}" → no máximo a IA principal (sem agentes)`)
  }
  check((await itens(c0.uid, 'appointment')).length === 0 && (await itens(c0.uid, 'expense')).length === 0, 'nenhum registro criado por engano')
}

/* ============================== FINANÇAS ============================== */
console.log('\n# FINANÇAS')
{ console.log('\n## gasto + categoria'); const c = await novo()
  await c.diga('gastei 50 de uber')
  const t = await c.diga('muda a categoria para alimentação'); semPesquisa(t); semIA(t)
  const e = await itens(c.uid, 'expense'); check(e.length === 1 && e[0].d.category === 'alimentacao', 'categoria → alimentação'); check(Number(e[0]?.d.amount) === 50, 'valor preservado')
}
{ console.log('\n## gasto + valor'); const c = await novo()
  await c.diga('gastei 30 no mercado')
  const t = await c.diga('corrija o valor para 35'); semPesquisa(t); semIA(t)
  const e = await itens(c.uid, 'expense'); check(e.length === 1 && Number(e[0].d.amount) === 35, 'valor 35 (mesmo lançamento)'); check(/mercado/i.test(e[0]?.d.description + ' ' + e[0]?.d.subcategory), 'descrição/categoria preservadas')
}
{ console.log('\n## receita + descrição (e o próximo gasto não herda nada)'); const c = await novo()
  await c.diga('recebi 1200 do cliente Paulo')
  const t = await c.diga('adiciona a descrição: pagamento do site'); semPesquisa(t); semIA(t)
  let e = await itens(c.uid, 'expense'); check(e.length === 1 && /pagamento do site/i.test(e[0].d.description), 'descrição gravada na receita'); check(Number(e[0]?.d.amount) === 1200 && e[0]?.d.kind === 'income', 'valor e tipo preservados')
  const t2 = await c.diga('gastei 12 de café'); semPesquisa(t2)
  e = await itens(c.uid, 'expense'); const cafe = e.find((x) => x.d.kind === 'expense')
  check(e.length === 2 && cafe && /caf/i.test(cafe.d.description) && Number(cafe.d.amount) === 12, 'novo gasto "Café" de 12 (sem herdar descrição pendente)')
  const t3 = await c.diga('adicione uma observação'); semPesquisa(t3); semIA(t3)
  await c.diga('pago no cartão da empresa')
  e = await itens(c.uid, 'expense'); const cafe2 = e.find((x) => x.id === cafe?.id); check(/cart[ãa]o da empresa/i.test(cafe2?.d.notes || ''), 'observação no último lançamento'); check(e.length === 2, 'nenhum lançamento a mais')
}
{ console.log('\n## saldo + gasto'); const c = await novo()
  const t0 = await c.diga('qual meu saldo?'); semPesquisa(t0); semIA(t0)
  const t = await c.diga('gastei 20 de lanche'); semPesquisa(t); semIA(t)
  check((await itens(c.uid, 'expense')).length === 1, 'gasto registrado')
}
{ console.log('\n## conta a pagar + vencimento'); const c = await novo()
  const t0 = await c.diga('cria uma conta de luz de 180 reais vencendo dia 10'); semPesquisa(t0) // criação: IA com a ferramenta create_bill (como antes)
  let b = await itens(c.uid, 'bill'); check(b.length === 1 && Number(b[0].d.amount) === 180 && /^\d{4}-\d{2}-10$/.test(b[0].day), 'conta cadastrada (180, dia 10)')
  const t = await c.diga('altere o vencimento para dia 15'); semPesquisa(t); semIA(t)
  b = await itens(c.uid, 'bill'); check(b.length === 1 && /^\d{4}-\d{2}-15$/.test(b[0].day) && Number(b[0].d.amount) === 180, 'vencimento dia 15, valor preservado')
}

/* ============================== LEMBRETES, TAREFAS, NOTAS ============================== */
console.log('\n# LEMBRETES, TAREFAS E NOTAS')
{ console.log('\n## lembrete + horário'); const c = await novo()
  await c.diga('gastei 40 no mercado') // um lançamento antes: "mude para 10h" NÃO pode virar correção financeira
  await c.diga('me lembra de ligar pro banco amanhã às 9h')
  const t = await c.diga('mude para 10h'); semPesquisa(t); semIA(t)
  const r = await itens(c.uid, 'reminder'); check(r.length === 1 && r[0].d.time === '10:00' && r[0].day === AMANHA, 'lembrete → amanhã 10h')
  check(new Date(r[0]?.due_at).getTime() === new Date(r[0]?.d.remindAt).getTime(), 'aviso reagendado (due_at)')
  const e = await itens(c.uid, 'expense'); check(e.length === 1 && Number(e[0].d.amount) === 40, 'lançamento financeiro intacto')
}
{ console.log('\n## tarefa + descrição'); const c = await novo()
  const t0 = await c.diga('cria uma tarefa de revisar o contrato'); semPesquisa(t0) // criação: IA com a ferramenta create_task
  const t = await c.diga('adiciona a descrição: conferir a cláusula 4'); semPesquisa(t); semIA(t)
  const k = await itens(c.uid, 'task'); check(k.length === 1 && /cl[áa]usula 4/.test(k[0].d.notes || ''), 'descrição na tarefa'); check(/revisar o contrato/i.test(k[0]?.d.title), 'título preservado')
  check((await itens(c.uid, 'expense')).length === 0, 'não virou lançamento financeiro')
}
{ console.log('\n## nota + informação'); const c = await novo()
  const t0 = await c.diga('anota que o fornecedor mudou de telefone'); semPesquisa(t0)
  const t = await c.diga('acrescente essa informação: novo número 3333-4444'); semPesquisa(t); semIA(t)
  const n = await itens(c.uid, 'note'); check(n.length === 1 && /fornecedor mudou/i.test(n[0].d.content) && /3333-4444/.test(n[0].d.content), 'informação acrescentada à nota (texto anterior preservado)')
  const t2 = await c.diga('anota que a pesquisa de satisfação ficou para sexta'); semPesquisa(t2); check(!t2.st?.eventos.some((e) => e.tipo === 'agente_pesquisa'), 'agente de Pesquisa nem é cogitado')
  check((await itens(c.uid, 'note')).length === 2, 'nova nota com a palavra "pesquisa" (sem pesquisar)')
}
{ console.log('\n## tarefa com a palavra "pesquisar" + prazo (sem pesquisa)'); const c = await novo()
  const t0 = await c.diga('cria uma tarefa de pesquisar fornecedores de embalagem'); semPesquisa(t0); check(!t0.st?.eventos.some((e) => e.tipo === 'agente_pesquisa'), 'agente de Pesquisa nem é cogitado')
  const t = await c.diga('coloca prazo para sexta'); semPesquisa(t); semIA(t)
  const k = await itens(c.uid, 'task'); check(k.length === 1 && k[0].day === proxDia(5), 'prazo → sexta'); check(/pesquisar fornecedores/i.test(k[0]?.d.title), 'título preservado')
}

{ console.log('\n## sem IA disponível: o resolvedor local cria tarefa, nota e conta (mesmas ferramentas)'); const c = await novo()
  const CO = await import('../src/ai/continuidade.js'), RL = await import('../src/ai/resolver-local.js')
  const u: any = (await import('../src/lib/session.js')).hydrateUser((await q('SELECT * FROM users WHERE id = $1', [c.uid]))[0])
  const r1 = await RL.resolverPessoal(u, 'cria uma tarefa de ligar para o contador sexta', c.conv); check(/Criei a tarefa "Ligar para o contador"/.test(r1?.content || ''), 'tarefa (sem IA): ' + r1?.content)
  const r2 = await RL.resolverPessoal(u, 'anota que a reunião de pais é dia 12', c.conv); check(/Anotado/.test(r2?.content || ''), 'nota (sem IA)')
  const r3 = await RL.resolverPessoal(u, 'cadastra uma conta de internet de 99,90 vencendo dia 20', c.conv); check(/Cadastrei a conta "Internet" de R\$ 99,90/.test(r3?.content || ''), 'conta (sem IA): ' + r3?.content)
  const k = await itens(c.uid, 'task'); check(k.length === 1 && k[0].day === proxDia(5), 'tarefa com prazo sexta'); check((await itens(c.uid, 'note')).length === 1 && (await itens(c.uid, 'bill')).length === 1, 'nota e conta gravadas uma vez')
  check(CO.lerNota('anota consulta amanhã às 9h') !== null, 'leitor de nota reconhece "anota …" (o compromisso é filtrado na criação)')
}

/* ============================== PESQUISA ============================== */
console.log('\n# PESQUISA')
{ console.log('\n## conceitual: Cérebro responde sem pesquisar de novo'); const c = await novo()
  const t1 = await c.diga('O que é o Protocolo Zyntra?'); check(!t1.st?.bloqueada, 'pesquisa permitida para conhecimento')
  const c2 = new Conversa(c.cli, c.uid); const t2 = await c2.diga('O que é o Protocolo Zyntra?')
  check(t2.buscas.length === 0, 'segunda vez: respondido pelo Cérebro, sem pesquisa'); check(/hospitalar|cirurgia/i.test(t2.resp), 'resposta com o conhecimento aprendido')
}
{ console.log('\n## informação atual'); const c = await novo()
  const docs0 = Number((await q('SELECT COUNT(*) AS n FROM knowledge_documents'))[0].n)
  const t = await c.diga('qual a cotação do dólar hoje?'); check(t.st?.prioridade === 'pesquisa_atual' && !t.st?.bloqueada, 'classificada como informação atual'); check(t.buscas.length >= 1, 'buscou na internet')
  check(Number((await q('SELECT COUNT(*) AS n FROM knowledge_documents'))[0].n) === docs0, 'cotação não vira conhecimento permanente')
}
{ console.log('\n## pesquisa explícita'); const c = await novo()
  const t = await c.diga('pesquise na internet o que é a Cooperativa Tarvok'); check(t.st?.prioridade === 'pesquisa_explicita', 'pesquisa explícita reconhecida'); check(t.buscas.length >= 1, 'buscou na internet')
  check(t.buscas.every((b) => !/pesquise|internet/i.test(b)), 'consulta sem o comando ("pesquise na internet")'); check(/Tarvok|cooperativa/i.test(t.resp), 'responde sobre a Tarvok')
  const t2 = await c.diga('qual a capital da França?'); check(t2.st?.prioridade !== 'pesquisa_explicita', 'mudança de assunto: não herda a pesquisa explícita'); check(!t2.buscas.some((b) => /tarvok/i.test(b)), 'não pesquisa o assunto anterior')
}
{ console.log('\n## pesquisa → operação'); const c = await novo()
  await c.diga('pesquise na internet o que é a Norma Velnor')
  const t = await c.diga('agenda reunião com o Paulo amanhã às 9h'); semPesquisa(t); semIA(t)
  check((await itens(c.uid, 'appointment')).length === 1, 'compromisso criado')
}
{ console.log('\n## operação → pesquisa explícita'); const c = await novo()
  await c.diga('agenda reunião com o Paulo amanhã às 9h')
  const t = await c.diga('pesquise na internet o que é a doença de Quarvel'); check(!t.st?.bloqueada && t.buscas.length >= 1, 'pesquisa explícita depois de uma operação funciona')
  const a = await itens(c.uid, 'appointment'); check(a.length === 1 && a[0].d.time === '09:00', 'compromisso intacto')
}

/* ============================== BLOQUEIO NAS CAMADAS BAIXAS ============================== */
console.log('\n# BLOQUEIO ESTRUTURAL (camadas baixas)')
{
  const E = await import('../src/ai/engine.js'), W = await import('../src/ai/cerebro/web.js'), AG = await import('../src/ai/agentes.js')
  await PB.noTurno('teste', async () => {
    PB.bloquearPesquisaNoTurno('teste', 'operacao', 'agenda')
    const i0 = S.chamadasIA.length
    await E.run([{ role: 'user', content: 'pesquise na web as últimas notícias' }], { task: 'pesquisa', grounding: true }).catch(() => null)
    const st = PB.estadoTurno()!
    check(st.eventos.some((e) => e.tipo === 'grounding' && e.bloqueado), 'engine.run: grounding barrado em turno operacional')
    check(S.chamadasIA.length === i0 + 1, 'engine.run: a IA responde sem busca (tarefa rebaixada)')
    let barrou = false; try { await W.buscar('teste', { provider: 'searxng', base_url: 'http://127.0.0.1:9' } as any, 3) } catch (e: any) { barrou = e?.code === 'pesquisa_bloqueada' }
    check(barrou, 'cerebro/web.buscar: busca na internet recusada')
    const r = await AG.contribuir(AG.AGENTES.find((a) => a.id === 'pesquisa')!, { pedido: 'x' } as any, 'x', 2000)
    check(!r.ok && /bloqueada/.test(r.motivo || ''), 'agente de Pesquisa: recusa em turno operacional')
  })
  await PB.noTurno('teste2', async () => {
    await E.run([{ role: 'user', content: 'oi' }], { task: 'pesquisa', grounding: true }).catch(() => null)
    check(PB.estadoTurno()!.eventos.some((e) => e.tipo === 'grounding' && !e.bloqueado), 'fora de operação: grounding continua permitido')
  })
}

await S.fechar()
console.log(`\n${falhas ? '❌' : '✅'} ${ok} verificações ok, ${falhas} falharam`)
if (falhas) { console.log(erros.map((e) => '  - ' + e).join('\n')); process.exit(1) }
process.exit(0)
