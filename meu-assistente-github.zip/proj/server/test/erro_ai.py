# IA que sempre falha com o status pedido (429, 500, 401…) — para testar o fallback
import sys, json
from http.server import BaseHTTPRequestHandler, HTTPServer
ST = int(sys.argv[2])
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length') or 0))
        d = json.dumps({'error': {'message': 'falha simulada ' + str(ST), 'type': 'x'}}).encode()
        self.send_response(ST); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(d))); self.end_headers(); self.wfile.write(d)
    do_GET = do_POST
HTTPServer(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
