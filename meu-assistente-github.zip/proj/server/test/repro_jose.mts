// Reproduz o caso: dona de empresa com um compromisso amanhã com o cliente José (com WhatsApp) faz uma pergunta conceitual.
import { DatabaseSync } from 'node:sqlite'
const BASE = process.env.BASE!, db = new DatabaseSync(process.env.SQLITE_FILE!)
class Cli { jar = new Map<string,string>(); async call(m: string, p: string, b?: any) { const r = await fetch(BASE + p, { method: m, headers: { ...(b !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), 'X-Forwarded-For': '10.9.9.' + Math.floor(Math.random()*200) }, body: b !== undefined ? JSON.stringify(b) : undefined }); for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v) } const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) } } catch { return { status: r.status, body: t } } } }
const u = new Cli(), n = 'Jose' + Date.now()
await u.call('POST', '/api/auth', { action: 'signup', name: 'Dona Tatu', whatsapp: '+55 11 94444-' + String(Date.now()).slice(-4), email: n.toLowerCase() + '@auto-teste.com', birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
const ad = await u.call('POST', '/api/v2/ads', { planId: 'n4', empresa: 'Estúdio Tatu', categoria: 'Tatuagem', titulo: 'x', texto: 'Tatuagens', zap: '5585999990000' })
db.prepare("UPDATE businesses SET status='ativo', expires_at='2099-01-01T00:00:00Z' WHERE id=?").run(ad.body.items[0].id)
const amanha = new Date(Date.now() + 86400e3 - 3 * 3600e3).toISOString().slice(0, 10)
const ap = await u.call('POST', '/api/items', { action: 'create', type: 'appointment', data: { title: 'Tatuagem', date: amanha, time: '19:30', cliente_nome: 'José', cliente_telefone: '85988887777', reminders: [] } })
console.log('compromisso', ap.status)
const CONV = 'cccccccc-1111-4222-8333-' + String(Date.now()).slice(-12)
for (const t of (process.argv.slice(2).length ? process.argv.slice(2) : ['Explique como memória, raciocínio, aprendizado e conhecimento se relacionam em uma inteligência artificial, sem confundir suas funções.'])) {
  const r = await u.call('POST', '/api/chat', { text: t, conversationId: CONV })
  console.log('\n>>', t, '\n<<', r.status, String(r.body?.assistantMessage?.content || JSON.stringify(r.body)).slice(0, 900))
  const tr: any = db.prepare('SELECT via, detail FROM brain_chat_traces ORDER BY id DESC LIMIT 1').get(); console.log('rastro via', tr?.via, String(tr?.detail || '').slice(0, 600))
}
