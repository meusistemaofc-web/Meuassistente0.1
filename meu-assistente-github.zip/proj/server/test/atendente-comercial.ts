// ATENDENTE COMERCIAL dos agentes das empresas (ai/atendente.ts + POST /api/v2/agent/:id/chat), pelo app real (createApp,
// rotas reais, SQLite). Dublê só da IA (para o que não é pedido comercial claro).
//   A. atender e procurar: "vocês têm camiseta?" → cards reais (foto, preço, variações), sem IA, em milissegundos
//   B. refinar sem recomeçar: cor → tamanho → preço; o que não existe é dito com as opções que existem
//   C. dúvidas: preço, opções; erro de digitação e mensagem curta
//   D. vender: "quero a primeira", "coloca 2 do boné", variação certa no carrinho, pergunta só o que falta, 1 complemento
//   E. dados reais: nada de outra loja, nada esgotado/inativo, nenhum preço inventado
//   F. continua na IA o que não é comercial (sem marcas internas na conversa enviada à IA); atendimento humano intacto
//   G. Cérebro Central: COMO os clientes pedem vira experiência anônima (loja.*), separada do assistente pessoal
//   H. velocidade
// Uso: npm run test:atendente
import { createServer } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const saida = (s: string) => process.stdout.write(s + '\n')
for (const k of ['log', 'info', 'warn'] as const) console[k] = () => {}
// ---- dublê da IA (OpenAI-compatível) ----
const iaMsgs: any[][] = []
const ia = createServer(async (req, res) => {
  let b = ''; for await (const c of req) b += c; const j = b ? JSON.parse(b) : {}; iaMsgs.push(j.messages || [])
  res.writeHead(200, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'Somos uma loja de bairro desde 2010 😊' } }] }))
})
await new Promise<void>((r) => ia.listen(0, '127.0.0.1', r))
const { setDb, q, one } = await import('../src/db/index.js'), { migrate } = await import('../src/db/migrate.js'), { config } = await import('../src/config.js')
const d = await (await import('../src/db/sqlite.js')).createSqlite(join(mkdtempSync(join(tmpdir(), 'ma-atd-')), 'atd.db'))
setDb(d); await migrate(d, config.migrationsDir, () => {})
const { setConfig } = await import('../src/lib/settings.js')
await setConfig('ai_providers', [{ id: 'atd', tipo: 'openai', nome: 'IA teste', base_url: `http://127.0.0.1:${(ia.address() as any).port}/v1`, modelo: 'm', key: '', caps: { texto: true, ferramentas: true }, texto: true, ativo: true }])
const { createApp } = await import('../src/app.js')
const server = createApp(); await new Promise<void>((r) => server.listen(0, '127.0.0.1', r)); const port = (server.address() as any).port
let nIp = 0
class Cli { jar = new Map<string, string>(); ip = `10.9.${Math.floor(++nIp / 200)}.${nIp % 200}`
  async call(method: string, path: string, body?: unknown) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers: { 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, 'X-Forwarded-For': this.ip, Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: body === undefined ? undefined : JSON.stringify(body) })
    for (const c of r.headers.getSetCookie?.() || []) { const [kv] = c.split(';'); const [k, v] = kv.split('='); this.jar.set(k.trim(), v) }
    const t = await r.text(); let j: any; try { j = JSON.parse(t) } catch { j = t } return { status: r.status, body: j }
  } }
const cad = async (nome: string, email: string, zap: string) => { const c = new Cli(); const r = await c.call('POST', '/api/auth', { action: 'signup', name: nome, email, whatsapp: zap, birthday: '1990-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' }); if (r.status !== 200) throw new Error(JSON.stringify(r.body)); return c }
const res: boolean[] = [], erros: string[] = []
const check = (n: string, ok: unknown, det: unknown = '') => { res.push(!!ok); if (!ok) erros.push(n); saida(`${ok ? '  ✔' : '  ✘'} ${n}${ok ? '' : ' → ' + (typeof det === 'string' ? det : JSON.stringify(det)).slice(0, 500)}`) }

const admin = await cad('Admin Sistema', 'admin@atd.com', '+55 11 94444-0001')
await admin.call('PUT', '/api/panel/modules', { empresas: true, anuncios: true, catalogo: true, agente: true })
async function loja(nome: string, email: string, zap: string, itens: any[]) {
  const dono = await cad('Dono ' + nome, email, zap)
  const r = await dono.call('POST', '/api/v2/ads', { planId: 'n4', empresa: nome, categoria: 'Moda', titulo: nome, texto: 'Loja de roupas', zap: '11 98765-4321', lat: -23.552, lng: -46.63, raio: 10, tipo: 'produtos' })
  if (r.status !== 200) throw new Error(JSON.stringify(r.body))
  const id = r.body.items.find((x: any) => x.empresa === nome).id
  await q("UPDATE businesses SET status = 'ativo', expires_at = $1 WHERE id = $2", [new Date(Date.now() + 30 * 864e5).toISOString(), id])
  await dono.call('PUT', `/api/v2/ads/${id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
  await dono.call('PUT', `/api/v2/ads/${id}/agent`, { nome: 'Lu', saudacao: 'Oi! Sou a Lu.' })
  const row = await one('SELECT data FROM businesses WHERE id = $1', [id]), x = JSON.parse(row.data); x.agente = { ...(x.agente || {}), ativo: true, expiresAt: new Date(Date.now() + 30 * 864e5).toISOString() }
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  const ids: Record<string, number> = {}
  for (const it of itens) { const p = await dono.call('POST', `/api/v2/ads/${id}/products`, it); if (p.status !== 200) throw new Error(it.nome + ' ' + JSON.stringify(p.body)); ids[it.nome] = p.body.items.find((i: any) => i.nome === it.nome).id }
  return { dono, id, ids }
}
const foto = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
const L = await loja('Loja Aurora', 'aurora@atd.com', '+55 11 94444-0002', [
  { nome: 'Camiseta Básica', preco: 49.9, categoria: 'Roupas', palavras: 'camisa, blusa', descricao: 'Camiseta 100% algodão, gola redonda.', fotos: [foto], variantes: [{ cor: 'Preta', tamanho: 'P', preco: 49.9 }, { cor: 'Preta', tamanho: 'M', preco: 49.9 }, { cor: 'Branca', tamanho: 'M', preco: 49.9 }] },
  { nome: 'Camiseta Estampada', preco: 69.9, categoria: 'Roupas', palavras: 'camisa', descricao: 'Estampa exclusiva, malha leve.', fotos: [foto], variantes: [{ cor: 'Preta', tamanho: 'G', preco: 69.9 }, { cor: 'Azul', tamanho: 'M', preco: 69.9 }] },
  { nome: 'Boné Aba Curva', preco: 39.9, categoria: 'Acessórios', palavras: 'chapeu, bone', descricao: 'Ajustável.', fotos: [foto] },
  { nome: 'Calça Jeans Slim', preco: 129.9, categoria: 'Roupas', palavras: 'calca', descricao: 'Jeans com elastano.', fotos: [foto], estoque: 0 },
])
const O = await loja('Loja Vizinha', 'vizinha@atd.com', '+55 11 94444-0003', [{ nome: 'Camiseta Polo Vizinha', preco: 89.9, categoria: 'Roupas', fotos: [foto] }])
const nomes = new Map<number, string>(); for (const [n, i] of Object.entries(L.ids)) nomes.set(i, n)
class Conversa {
  msgs: any[] = []; cart: number[] = []
  constructor(public cli: Cli, public bid = L.id) {}
  async diga(t: string) {
    this.msgs.push({ role: 'user', content: t }); const n0 = iaMsgs.length, t0 = performance.now()
    const r = await this.cli.call('POST', `/api/v2/agent/${this.bid}/chat`, { messages: this.msgs.slice(-12), carrinho: this.cart })
    const ms = performance.now() - t0, b = r.body || {}
    this.msgs.push({ role: 'assistant', content: String(b.reply || '') + (b.produtos?.length ? ' ⟦ids:' + b.produtos.map((p: any) => p.id).join(',') + '⟧' : '') })
    for (const c of b.carrinho || []) this.cart.push(Number(c.pid))
    saida(`    👤 ${t}\n    🤖 ${String(b.reply || b.error).replace(/\n+/g, ' ⏎ ').slice(0, 170)}${b.produtos?.length ? '  [' + b.produtos.map((p: any) => p.nome).join(' | ') + ']' : ''}${b.carrinho?.length ? '  🛒' + JSON.stringify(b.carrinho) : ''}`)
    return { ...b, status: r.status, ms, ia: iaMsgs.length > n0, nomes: (b.produtos || []).map((p: any) => p.nome) as string[] }
  }
}
const tempos: number[] = []

saida('\n== A. atender e procurar no catálogo real')
const c1 = new Conversa(new Cli())
let r = await c1.diga('oi, vocês têm camiseta?'); tempos.push(r.ms)
check('procura → cards REAIS das camisetas (sem a calça, sem outra loja)', r.status === 200 && r.nomes.length === 2 && r.nomes.every((n) => /Camiseta (Básica|Estampada)/.test(n)), r)
check('resolvido na hora, sem IA', !r.ia && r.atendente === 'loja.buscar', r)
check('cards com preço e foto do catálogo', r.produtos.every((p: any) => p.preco > 0 && p.foto))

saida('\n== B. refinar sem recomeçar')
r = await c1.diga('tem na cor preta?'); tempos.push(r.ms)
check('cor: refina a busca anterior (as duas têm preta)', r.atendente === 'loja.refinar' && r.nomes.length === 2 && /preto|preta/i.test(r.reply), r)
r = await c1.diga('e no tamanho M?'); tempos.push(r.ms)
check('tamanho: só a que tem PRETA E M (a Estampada preta é G)', r.nomes.length === 1 && r.nomes[0] === 'Camiseta Básica', r)
{ const cv = new Conversa(new Cli()); await cv.diga('vocês têm camiseta?'); r = await cv.diga('tem em verde?') }
check('o que não existe é dito com clareza, com as cores que existem', /Não temos/i.test(r.reply) && /pret|branc|azul/i.test(r.reply) && !/tamanho/.test(r.reply) && !r.ia, r)
const c1b = new Conversa(new Cli()); await c1b.diga('quero ver camisetas'); r = await c1b.diga('até 60 reais')
check('preço máximo: só a de R$ 49,90', r.nomes.length === 1 && r.nomes[0] === 'Camiseta Básica', r)
r = await c1b.diga('qual a mais barata?')
check('"a mais barata" ordena pelo preço', r.nomes[0] === 'Camiseta Básica', r)

saida('\n== C. dúvidas, erro de digitação e mensagem curta')
const c2 = new Conversa(new Cli())
r = await c2.diga('quanto custa o boné?'); tempos.push(r.ms)
check('preço real do boné, com o card', /R\$ 39,90/.test(r.reply) && r.nomes[0] === 'Boné Aba Curva' && r.atendente === 'loja.duvida' && !r.ia, r)
r = await new Conversa(new Cli()).diga('vcs tem camisseta')
check('erro de digitação ("camisseta") e abreviação ("vcs") entendidos', r.nomes.length === 2, r)
r = await new Conversa(new Cli()).diga('boné')
check('mensagem curta ("boné") mostra o produto', r.nomes[0] === 'Boné Aba Curva', r)
r = await new Conversa(new Cli()).diga('tem calça jeans?')
check('item esgotado não é oferecido: avisa que está esgotado', !r.nomes.includes('Calça Jeans Slim') && /Calça Jeans Slim está esgotad/.test(r.reply), r)
r = await new Conversa(new Cli()).diga('vocês vendem tênis?')
check('produto que a loja não tem: diz que não encontrou (não inventa), com a palavra do cliente', r.nomes.length === 0 && /Não encontrei tênis/.test(r.reply) && !r.ia, r)

saida('\n== D. vender: carrinho real, variação certa, complemento')
r = await c1.diga('quero a primeira'); tempos.push(r.ms)
const v = r.carrinho?.[0]
const varRow = v?.vid ? await one('SELECT data FROM product_variants WHERE id = $1', [v.vid]) : null, vd = varRow ? JSON.parse(varRow.data) : {}
check('"quero a primeira" (da última lista) → item no carrinho', r.atendente === 'loja.adicionar' && v && nomes.get(Number(v.pid)) === 'Camiseta Básica' && v.qtd === 1, r)
check('com a variação que o cliente pediu ao longo da conversa (preta M)', vd.cor === 'Preta' && vd.tamanho === 'M', vd)
check('oferece no máximo 1 complemento de outra categoria, sem insistir', r.nomes.length <= 1 && (!r.nomes.length || r.nomes[0] === 'Boné Aba Curva') && /Se quiser/.test(r.reply), r)
r = await c1.diga('coloca 2 do boné no carrinho')
check('"coloca 2 do boné" → 2 bonés no carrinho', r.carrinho?.[0] && nomes.get(Number(r.carrinho[0].pid)) === 'Boné Aba Curva' && r.carrinho[0].qtd === 2, r)
const c3 = new Conversa(new Cli()); r = await c3.diga('quero a camiseta básica')
check('falta escolher a variação: pergunta só isso (nada vai ao carrinho)', !r.carrinho && /Preta|Branca/.test(r.reply) && r.nomes[0] === 'Camiseta Básica', r)
r = await c3.diga('a branca')
check('responde a escolha → camiseta branca M no carrinho', r.carrinho?.[0] && nomes.get(Number(r.carrinho[0].pid)) === 'Camiseta Básica' && JSON.parse((await one('SELECT data FROM product_variants WHERE id = $1', [r.carrinho[0].vid])).data).cor === 'Branca', r)
const ok = await new Cli().call('POST', `/api/v2/agent/${L.id}/order`, { itens: [{ produto_id: L.ids['Boné Aba Curva'], quantidade: 2, opcoes: {} }], modo: 'retirada', pagamento: 'dinheiro', nome: 'Carla', telefone: '11 96666-2222' })
check('o pedido segue pelo fluxo de pedidos de sempre', ok.status === 200 && ok.body.pedido, ok.body)

saida('\n== E. só dados reais da empresa')
r = await new Conversa(new Cli()).diga('tem camiseta polo?')
check('não mostra produto de OUTRA loja', !r.nomes.some((n) => /Vizinha/.test(n)), r)
r = await new Conversa(new Cli(), O.id).diga('vocês têm camiseta?')
check('o agente da outra loja mostra só a dela', r.nomes.length === 1 && r.nomes[0] === 'Camiseta Polo Vizinha', r)
await L.dono.call('PUT', `/api/v2/ads/${L.id}/products/${L.ids['Camiseta Estampada']}/active`, { ativo: false }).catch(() => null)
await q('UPDATE products SET active = $1 WHERE id = $2', [false, L.ids['Camiseta Estampada']])
r = await new Conversa(new Cli()).diga('vocês têm camiseta?')
check('produto desativado pela empresa some do atendimento', r.nomes.length === 1 && r.nomes[0] === 'Camiseta Básica', r)
await q('UPDATE products SET active = $1 WHERE id = $2', [true, L.ids['Camiseta Estampada']])

saida('\n== F. o resto continua com a IA; atendimento humano intacto')
const c4 = new Conversa(new Cli()); await c4.diga('vocês têm camiseta?'); r = await c4.diga('qual é a história da loja?')
check('pergunta que não é do catálogo vai para a IA (com as ferramentas do agente)', r.ia && !r.atendente && /2010/.test(r.reply), r)
const enviados = JSON.stringify(iaMsgs[iaMsgs.length - 1])
check('a marca interna dos cards (⟦ids⟧) nunca vai para a IA', !/⟦ids/.test(enviados))
r = await new Conversa(new Cli()).diga('quero falar com uma pessoa')
check('"falar com uma pessoa" continua abrindo o atendimento humano', r.secao === 'atendimento', r)
r = await new Conversa(new Cli()).diga('onde fica a loja?')
check('localização/horário/pagamento continuam nos atalhos de sempre', r.secao === 'mapa', r)

saida('\n== G. Cérebro Central: aprendizado generalizável de atendimento')
const COL = await import('../src/ai/aprendizado-coletivo.js')
const clientes: Cli[] = []; for (let i = 0; i < 3; i++) clientes.push(await cad(['Ana Souza', 'Bruno Lima', 'Carla Dias'][i], `cli${i}@atd.com`, `+55 21 9888${i}-77${i}7`))
for (let i = 0; i < 3; i++) { const cv = new Conversa(clientes[i]); await cv.diga('vocês têm camiseta?'); await cv.diga('me separa a primeira') }
await COL.gravar(); const si = (await q("SELECT template, intent FROM collective_signals WHERE intent LIKE 'loja.%'")) as any[]
check('experiências de atendimento viram sinais anônimos (loja.*) de clientes com conta', si.length >= 6 && si.some((x) => x.intent === 'loja.adicionar') && si.every((x) => !/aurora|camiseta|bone/i.test(x.template)), si)
await COL.consolidar()
const k = (await q("SELECT * FROM collective_knowledge WHERE intent = 'loja.adicionar'")) as any[]
check('3 clientes distintos → conhecimento coletivo de atendimento ("me separa a primeira" = adicionar)', k.length >= 1 && k[0].state === 'ativo', k)
check('o assistente pessoal NUNCA usa intenções de loja', !COL.sugerir('me separa a primeira') && COL.sugerir('me separa a primeira', { escopo: 'loja' })?.intencao === 'loja.adicionar')
const anon0 = (await q("SELECT COUNT(*) AS n FROM collective_signals")) as any[]
await new Conversa(new Cli()).diga('vocês têm camiseta?'); await COL.gravar()
check('cliente sem conta (sem consentimento) não contribui', Number(((await q('SELECT COUNT(*) AS n FROM collective_signals')) as any[])[0].n) === Number(anon0[0].n))

saida('\n== H. velocidade')
const media = tempos.reduce((a, b) => a + b, 0) / tempos.length
check(`atendimento local rápido (média ${media.toFixed(0)} ms, máx ${Math.max(...tempos).toFixed(0)} ms)`, media < 400 && Math.max(...tempos) < 1500, tempos)

server.close(); ia.close()
const n = res.filter(Boolean).length
saida(`\n${n}/${res.length} verificações${erros.length ? '\nFALHAS:\n - ' + erros.join('\n - ') : ''}`)
process.exit(erros.length ? 1 : 0)
