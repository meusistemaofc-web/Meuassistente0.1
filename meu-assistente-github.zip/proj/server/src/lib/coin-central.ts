// Central de controle e comercialização das MCoins: chaves globais, política por moeda, permissões (usuário / empresa / grupo),
// compra, venda e transferência entre contas. Tudo nasce DESLIGADO e usa a MESMA carteira (coin_balances) e o MESMO livro-razão
// (coin_ledger) das MCoins: nenhuma carteira ou saldo é duplicado e o histórico anterior não é tocado.
//  • servidor decide: permissão, limites, preço, taxa, saldo e quem é o usuário vêm do servidor (o cliente só envia a intenção);
//  • atômico: cada operação (saldo, emissão, pedido e livro-razão) acontece numa única transação sob trava da moeda;
//  • idempotente: chave única por usuário (pedidos e transferências) + chave por lançamento no livro-razão;
//  • liquidação NÃO presume dinheiro real: "manual" = o administrador registra a liquidação feita fora do sistema;
//    "interna" = efeito imediato nas MCoins, sem cobrança/pagamento pelo app. Nenhum meio de pagamento é acionado aqui.
import { q, one, db, J, nowIso, isoOf } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'
import { audit } from './account.js'
import { notify } from './notify.js'
import * as C from './coins.js'

const num = (v: any) => Number(v) || 0
const r2 = (n: number) => Math.round(n * 100) / 100
const IDEM = /^[A-Za-z0-9:_.-]{8,80}$/
const tri = (v: any): boolean | null => (v === null || v === undefined ? null : v === true || v === 1 || v === 't' || v === '1')
const triSql = (v: any) => (v === true ? true : v === false ? false : null)

/* ---------- configuração global (separada da configuração antiga das moedas) ---------- */
export type Lim = { preco: number; taxaPct: number; taxaFixa: number; min: number; max: number; limiteDiario: number }
const L0 = (): Lim => ({ preco: 0, taxaPct: 0, taxaFixa: 0, min: 1, max: 1000, limiteDiario: 0 })
export const CENTRAL_DEFAULT = () => ({ compra: false, venda: false, transferencia: false, compartilhamento: false, acesso: { modo: 'todos' as 'todos' | 'selecionados' | 'grupos' }, comercial: { liquidacao: 'manual' as 'manual' | 'interna', compra: L0(), venda: L0(), transferencia: L0() } })
export type Central = ReturnType<typeof CENTRAL_DEFAULT>
export async function getCentral(): Promise<Central> {
  const c = await getConfig<any>('coins_central', {}), d = CENTRAL_DEFAULT()
  const lim = (k: 'compra' | 'venda' | 'transferencia'): Lim => ({ ...d.comercial[k], ...(c.comercial?.[k] || {}) })
  return { compra: c.compra === true, venda: c.venda === true, transferencia: c.transferencia === true, compartilhamento: c.compartilhamento === true,
    acesso: { modo: ['todos', 'selecionados', 'grupos'].includes(c.acesso?.modo) ? c.acesso.modo : 'todos' },
    comercial: { liquidacao: c.comercial?.liquidacao === 'interna' ? 'interna' : 'manual', compra: lim('compra'), venda: lim('venda'), transferencia: lim('transferencia') } }
}
/** Achata um objeto de configuração em chaves 'a.b.c' (usado para registrar na auditoria só o que mudou). */
const flat = (o: object, p = ''): Record<string, unknown> => Object.entries(o).reduce<Record<string, unknown>>((a, [k, v]: [string, unknown]) => (v && typeof v === 'object' ? { ...a, ...flat(v, p + k + '.') } : { ...a, [p + k]: v }), {})
export async function saveCentral(b: any, adminId: number) {
  const cur = await getCentral(), n = (v: any, d: number, lo: number, hi: number) => { if (v === undefined) return d; const x = Number(v); if (!isFinite(x) || x < lo || x > hi) fail(400, `Valor inválido (${lo} a ${hi}).`, 'invalid'); return x }
  const bool = (k: keyof Central) => (typeof b[k] === 'boolean' ? b[k] : cur[k])
  const lim = (k: 'compra' | 'venda' | 'transferencia'): Lim => { const i = b.comercial?.[k] || {}, c = cur.comercial[k], min = Math.floor(n(i.min, c.min, 1, 1e9)), max = Math.floor(n(i.max, c.max, 1, 1e9)); if (max < min) fail(400, 'O máximo por operação não pode ser menor que o mínimo.', 'invalid'); return { preco: r2(n(i.preco, c.preco, 0, 1e6)), taxaPct: r2(n(i.taxaPct, c.taxaPct, 0, 100)), taxaFixa: r2(n(i.taxaFixa, c.taxaFixa, 0, 1e6)), min, max, limiteDiario: Math.floor(n(i.limiteDiario, c.limiteDiario, 0, 1e9)) } }
  if (b.acesso?.modo !== undefined && !['todos', 'selecionados', 'grupos'].includes(b.acesso.modo)) fail(400, 'Modalidade de acesso inválida.', 'invalid')
  if (b.comercial?.liquidacao !== undefined && !['manual', 'interna'].includes(b.comercial.liquidacao)) fail(400, 'Modalidade de liquidação inválida.', 'invalid')
  const next: Central = { compra: bool('compra') as boolean, venda: bool('venda') as boolean, transferencia: bool('transferencia') as boolean, compartilhamento: bool('compartilhamento') as boolean,
    acesso: { modo: b.acesso?.modo ?? cur.acesso.modo }, comercial: { liquidacao: b.comercial?.liquidacao ?? cur.comercial.liquidacao, compra: lim('compra'), venda: lim('venda'), transferencia: lim('transferencia') } }
  const a = flat(cur), d = flat(next), mud = Object.keys(d).filter((k) => String(a[k]) !== String(d[k])).map((k) => ({ campo: k, de: a[k], para: d[k] }))
  if (mud.length) { await setConfig('coins_central', next); await audit(adminId, 'coins.central.config', null, { alteracoes: mud }) }
  return { config: next, alteracoes: mud.length }
}

/* ---------- política por moeda (só restringe) ---------- */
const MOD = ['compra', 'venda', 'transferencia', 'compartilhamento'] as const
export async function politicaMoeda(coinId: number) { const r = await one('SELECT * FROM coin_policies WHERE coin_id = $1', [coinId]); return Object.fromEntries(MOD.map((m) => [m, tri(r?.[m])])) as Record<(typeof MOD)[number], boolean | null> }
export async function salvarPolitica(coinId: number, b: any, adminId: number) {
  const c = await C.coinById(coinId); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  const cur = await politicaMoeda(coinId), nx: any = {}
  for (const m of MOD) nx[m] = b[m] === undefined ? cur[m] : b[m] === null ? null : b[m] === false ? false : null // só pode bloquear (false) ou herdar (null); nunca liga o que o global desligou
  const ex = await one('SELECT coin_id FROM coin_policies WHERE coin_id = $1', [coinId])
  if (ex) await q('UPDATE coin_policies SET compra=$1, venda=$2, transferencia=$3, compartilhamento=$4, updated_by=$5, updated_at=$6 WHERE coin_id=$7', [...MOD.map((m) => triSql(nx[m])), adminId, nowIso(), coinId])
  else await q('INSERT INTO coin_policies (coin_id, compra, venda, transferencia, compartilhamento, updated_by, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7)', [coinId, ...MOD.map((m) => triSql(nx[m])), adminId, nowIso()])
  for (const m of MOD) if (cur[m] !== nx[m]) await q('INSERT INTO coin_changes (coin_id, field, old_value, new_value, actor, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [coinId, 'política.' + m, String(cur[m] ?? 'herda'), String(nx[m] ?? 'herda'), 'admin ' + adminId, nowIso()])
  await audit(adminId, 'coins.central.politica', coinId, { de: cur, para: nx })
  return nx
}

/* ---------- grupos e permissões ---------- */
export const ACOES = ['comprar', 'vender', 'receber', 'transferir', 'compartilhar'] as const
type Acao = (typeof ACOES)[number]
const GLOBAL: Record<Acao, keyof Central | null> = { comprar: 'compra', vender: 'venda', receber: null, transferir: 'transferencia', compartilhar: 'compartilhamento' }
const POL: Record<Acao, (typeof MOD)[number] | null> = { comprar: 'compra', vender: 'venda', receber: null, transferir: 'transferencia', compartilhar: 'compartilhamento' }
export async function criarGrupo(nome: string, descricao: string, adminId: number) {
  nome = String(nome || '').trim().slice(0, 60); if (nome.length < 2) fail(400, 'Informe o nome do grupo.', 'invalid', 'nome')
  if (await one('SELECT id FROM coin_groups WHERE LOWER(name) = $1', [nome.toLowerCase()])) fail(409, 'Já existe um grupo com este nome.', 'exists')
  // RETURNING devolve o id do grupo recém-criado na mesma instrução (PostgreSQL e SQLite), sem depender de uma 2ª consulta que poderia vir vazia
  const [g] = await q<{ id: number | string }>('INSERT INTO coin_groups (name, description, created_by, created_at) VALUES ($1,$2,$3,$4) RETURNING id', [nome, String(descricao || '').slice(0, 200), adminId, nowIso()])
  if (!g) fail(500, 'Falha ao criar o grupo de moedas.', 'internal')
  await audit(adminId, 'coins.central.grupo.criar', Number(g.id), { nome }); return { id: Number(g.id), nome }
}
export async function listarGrupos() { const g = await q('SELECT id, name, description FROM coin_groups ORDER BY name') as any[]; return Promise.all(g.map(async (x) => ({ id: Number(x.id), nome: x.name, descricao: x.description || '', membros: Number((await one('SELECT COUNT(*) AS n FROM coin_group_members WHERE group_id = $1', [x.id]))?.n ?? 0) }))) }
export async function membrosGrupo(id: number) { return (await q('SELECT m.user_id, u.name, u.email FROM coin_group_members m LEFT JOIN users u ON u.id = m.user_id WHERE m.group_id = $1 ORDER BY u.name', [id]) as any[]).map((r) => ({ usuarioId: Number(r.user_id), nome: r.name || '', email: r.email || '' })) }
export async function alterarMembros(id: number, add: any[], remover: any[], adminId: number) {
  if (!(await one('SELECT id FROM coin_groups WHERE id = $1', [id]))) fail(404, 'Grupo não encontrado.', 'not_found')
  const ids = (l: any[]) => [...new Set((Array.isArray(l) ? l : []).map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 2000)
  for (const u of ids(add)) { if (!(await one("SELECT id FROM users WHERE id = $1 AND status = 'active'", [u]))) fail(404, `Usuário #${u} não existe ou está desativado.`, 'not_found'); await q('INSERT INTO coin_group_members (group_id, user_id, added_by, created_at) VALUES ($1,$2,$3,$4) ON CONFLICT (group_id, user_id) DO NOTHING', [id, u, adminId, nowIso()]) }
  for (const u of ids(remover)) await q('DELETE FROM coin_group_members WHERE group_id = $1 AND user_id = $2', [id, u])
  await audit(adminId, 'coins.central.grupo.membros', id, { adicionados: ids(add).length, removidos: ids(remover).length })
}
export async function excluirGrupo(id: number, adminId: number) { await q('DELETE FROM coin_group_members WHERE group_id = $1', [id]); await q("DELETE FROM coin_permissions WHERE scope_type = 'grupo' AND scope_id = $1", [id]); await q('DELETE FROM coin_groups WHERE id = $1', [id]); await audit(adminId, 'coins.central.grupo.excluir', id, {}) }

async function linhas(userId: number, coinId: number) {
  const emp = (await q('SELECT id FROM businesses WHERE owner_id = $1', [userId]) as any[]).map((r) => Number(r.id)), grp = (await q('SELECT group_id FROM coin_group_members WHERE user_id = $1', [userId]) as any[]).map((r) => Number(r.group_id))
  const rows = await q('SELECT * FROM coin_permissions WHERE coin_id IN (0, $1)', [coinId]) as any[]
  return rows.filter((r) => (r.scope_type === 'usuario' && Number(r.scope_id) === userId) || (r.scope_type === 'empresa' && emp.includes(Number(r.scope_id))) || (r.scope_type === 'grupo' && grp.includes(Number(r.scope_id))))
}
/** Permissão efetiva (sem as chaves globais): bloqueio explícito sempre vale; liberação depende da modalidade de acesso. */
export async function avaliar(userId: number, acao: Acao, coinId: number, modo?: string): Promise<{ ok: boolean; motivo: string }> {
  modo = modo || (await getCentral()).acesso.modo
  const rows = await linhas(userId, coinId)
  for (const alvo of [coinId, 0]) {
    const doNivel = rows.filter((r) => Number(r.coin_id) === alvo), usr = doNivel.find((r) => r.scope_type === 'usuario'), outros = doNivel.filter((r) => r.scope_type !== 'usuario')
    const u = tri(usr?.[acao]); if (u !== null) return u ? { ok: true, motivo: '' } : { ok: false, motivo: 'Esta ação foi bloqueada para a sua conta pelo administrador.' }
    const vs = outros.map((r) => tri(r[acao])).filter((v) => v !== null)
    if (vs.includes(false)) return { ok: false, motivo: 'Esta ação foi bloqueada para a sua empresa ou grupo pelo administrador.' }
    if (vs.includes(true) && modo !== 'selecionados') return { ok: true, motivo: '' }
  }
  return modo === 'todos' ? { ok: true, motivo: '' } : { ok: false, motivo: modo === 'grupos' ? 'Disponível apenas para empresas ou grupos liberados pelo administrador.' : 'Disponível apenas para usuários liberados pelo administrador.' }
}
/** Regra completa: usuário ativo + chave global + política da moeda + permissão. Nenhum cliente pode contorná-la. */
export async function pode(userId: number, coinId: number, acao: Acao): Promise<{ ok: boolean; motivo: string }> {
  const u = await one('SELECT status FROM users WHERE id = $1', [userId]); if (!u || u.status !== 'active') return { ok: false, motivo: 'Conta indisponível.' }
  const cfg = await getCentral(), g = GLOBAL[acao]
  if (g && !cfg[g]) return { ok: false, motivo: 'Esta modalidade não está disponível no momento.' }
  const p = POL[acao]; if (p && (await politicaMoeda(coinId))[p] === false) return { ok: false, motivo: 'Esta modalidade está desativada para esta moeda.' }
  return avaliar(userId, acao, coinId, cfg.acesso.modo)
}
const exigir = async (userId: number, coinId: number, acao: Acao) => { const r = await pode(userId, coinId, acao); if (!r.ok) fail(403, r.motivo, 'forbidden') }
const ESC = ['usuario', 'empresa', 'grupo']
export async function definirPermissao(b: any, adminId: number) {
  const tipo = String(b.tipo || ''); if (!ESC.includes(tipo)) fail(400, 'Tipo de destinatário inválido (usuário, empresa ou grupo).', 'invalid', 'tipo')
  const id = Number(b.id), coinId = Number(b.moedaId) || 0; if (!Number.isInteger(id) || id <= 0) fail(400, 'Identificador inválido.', 'invalid', 'id')
  const ok = tipo === 'usuario' ? await one('SELECT id FROM users WHERE id = $1', [id]) : tipo === 'empresa' ? await one("SELECT id FROM businesses WHERE id = $1 AND status <> 'institucional'", [id]) : await one('SELECT id FROM coin_groups WHERE id = $1', [id])
  if (!ok) fail(404, 'Destinatário da permissão não encontrado.', 'not_found'); if (coinId && !(await C.coinById(coinId))) fail(404, 'Moeda não encontrada.', 'not_found')
  const ex = await one('SELECT * FROM coin_permissions WHERE scope_type = $1 AND scope_id = $2 AND coin_id = $3', [tipo, id, coinId]), antes: any = {}, depois: any = {}
  for (const a of ACOES) { antes[a] = tri(ex?.[a]); const v = b.permissoes?.[a]; if (v !== undefined && v !== null && typeof v !== 'boolean') fail(400, 'Permissão inválida (true, false ou null).', 'invalid', a); depois[a] = v === undefined ? antes[a] : v }
  const nota = String(b.nota ?? ex?.note ?? '').slice(0, 200)
  if (ACOES.every((a) => depois[a] === null)) { if (ex) await q('DELETE FROM coin_permissions WHERE id = $1', [ex.id]) }
  else if (ex) await q('UPDATE coin_permissions SET comprar=$1, vender=$2, receber=$3, transferir=$4, compartilhar=$5, note=$6, updated_by=$7, updated_at=$8 WHERE id=$9', [...ACOES.map((a) => triSql(depois[a])), nota, adminId, nowIso(), ex.id])
  else await q('INSERT INTO coin_permissions (scope_type, scope_id, coin_id, comprar, vender, receber, transferir, compartilhar, note, updated_by, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)', [tipo, id, coinId, ...ACOES.map((a) => triSql(depois[a])), nota, adminId, nowIso()])
  await audit(adminId, 'coins.central.permissao', id, { tipo, moedaId: coinId, antes, depois, nota }); return { tipo, id, moedaId: coinId, permissoes: depois }
}
/** Lista administrativa: usuários (pesquisa por nome, e-mail ou identificador) com a permissão explícita e a efetiva; mais as regras de empresa/grupo. */
export async function listarPermissoes(f: { q?: string; moedaId?: number; limit?: number; offset?: number }) {
  const { buscarUsuarios } = await import('./coin-dist.js'), r = await buscarUsuarios({ q: f.q }, f.limit || 30, f.offset || 0), coinId = Number(f.moedaId) || 0, cfg = await getCentral()
  const usuarios = []
  const uids = r.usuarios.map((u: any) => Number(u.id)), explic = new Map((uids.length ? await q(`SELECT * FROM coin_permissions WHERE scope_type = 'usuario' AND coin_id = $1 AND scope_id IN (${uids.map((_, i) => '$' + (i + 2)).join(',')})`, [coinId, ...uids]) : []).map((x: any) => [Number(x.scope_id), x])) // em lote (antes: 1 por usuário)
  for (const u of r.usuarios) { const ex = explic.get(Number(u.id)), efetivo: any = {}; for (const a of ACOES) efetivo[a] = (await avaliar(u.id, a, coinId, cfg.acesso.modo)).ok
    usuarios.push({ ...u, permissoes: Object.fromEntries(ACOES.map((a) => [a, tri(ex?.[a])])), efetivo }) }
  const esc = await q("SELECT * FROM coin_permissions WHERE scope_type <> 'usuario' ORDER BY scope_type, scope_id") as any[]
  const nomes = async (t: string, id: number) => t === 'empresa' ? J<any>((await one('SELECT data FROM businesses WHERE id = $1', [id]))?.data, {}).empresa || `Empresa #${id}` : (await one('SELECT name FROM coin_groups WHERE id = $1', [id]))?.name || `Grupo #${id}`
  return { total: r.total, usuarios, escopos: await Promise.all(esc.map(async (e) => ({ tipo: e.scope_type, id: Number(e.scope_id), nome: await nomes(e.scope_type, Number(e.scope_id)), moedaId: Number(e.coin_id), permissoes: Object.fromEntries(ACOES.map((a) => [a, tri(e[a])])) }))) }
}
/** O que o usuário pode fazer em cada moeda (a carteira só mostra botões liberados). */
export async function capacidades(userId: number) {
  const cfg = await getCentral(), coins = (await C.listCoins(true)) as any[], hold = (await q('SELECT coin_id FROM coin_balances WHERE user_id = $1 AND balance > 0', [userId]) as any[]).map((r) => Number(r.coin_id))
  const out = []; for (const c of coins) { const o: any = { moedaId: c.id, codigo: c.codigo, simbolo: c.simbolo, nome: c.nome, saldo: await C.balanceOf(c.id, userId) }; for (const a of ['comprar', 'vender', 'transferir', 'compartilhar'] as Acao[]) o[a] = await pode(userId, c.id, a); if (hold.includes(c.id) || o.comprar.ok || o.vender.ok || o.transferir.ok) out.push(o) }
  return { global: { compra: cfg.compra, venda: cfg.venda, transferencia: cfg.transferencia, compartilhamento: cfg.compartilhamento }, liquidacao: cfg.comercial.liquidacao, moedas: out }
}

/* ---------- lançamentos no livro-razão existente ---------- */
const kindOk = ['compra', 'venda', 'venda_estorno', 'transf_saida', 'transf_entrada']
async function lancar(t: any, coinId: number, userId: number, kind: string, delta: number, idem: string, actor: string, nota: string, now: string) {
  if (!kindOk.includes(kind)) throw new Error('tipo de lançamento inválido')
  await t.query('INSERT INTO coin_balances (coin_id, user_id, balance, updated_at) VALUES ($1,$2,0,$3) ON CONFLICT (coin_id, user_id) DO NOTHING', [coinId, userId, now])
  if (delta > 0) await t.query('UPDATE coin_balances SET balance = balance + $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3', [delta, coinId, userId, now])
  else { const r = await t.query('UPDATE coin_balances SET balance = balance - $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3 AND balance >= $1 RETURNING balance', [-delta, coinId, userId, now]); if (!r.length) fail(409, 'Saldo de moedas insuficiente.', 'saldo_insuficiente') }
  const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coinId, userId]))[0]?.balance)
  await t.query('INSERT INTO coin_ledger (coin_id, user_id, kind, delta, balance_after, order_id, idem, actor, note, discount, created_at, issuer_business_id, linked_business_id) VALUES ($1,$2,$3,$4,$5,NULL,$6,$7,$8,NULL,$9,(SELECT business_id FROM coins WHERE id = $1),NULL)', [coinId, userId, kind, delta, saldo, idem, actor, nota, now])
  return { saldo, id: Number((await t.query('SELECT id FROM coin_ledger WHERE coin_id = $1 AND idem = $2', [coinId, idem]))[0].id) }
}
const emitir = async (t: any, coinId: number, qtd: number, now: string) => { const r = await t.query('UPDATE coins SET distributed = distributed + $1, updated_at = $3 WHERE id = $2 AND distributed + $1 <= total_supply RETURNING id', [qtd, coinId, now]); if (!r.length) fail(409, 'Não há MCoins disponíveis na emissão para esta operação.', 'sem_estoque') }
const devolver = async (t: any, coinId: number, qtd: number, now: string) => { const r = await t.query('UPDATE coins SET distributed = distributed - $1, updated_at = $3 WHERE id = $2 AND distributed - $1 >= redeemed RETURNING id', [qtd, coinId, now]); if (!r.length) fail(409, 'Não foi possível devolver as moedas à emissão (conferência de totais).', 'invalid') }
const codigo = (p: string) => `${p}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`

/* ---------- compra e venda ---------- */
function cotar(kind: 'compra' | 'venda', L: Lim, qtd: number) { const bruto = r2(L.preco * qtd), taxa = r2((bruto * L.taxaPct) / 100 + (qtd > 0 ? L.taxaFixa : 0)); return { precoUnitario: L.preco, bruto, taxa, total: kind === 'compra' ? r2(bruto + taxa) : Math.max(0, r2(bruto - taxa)) } }
async function limites(kind: 'compra' | 'venda' | 'transferencia', L: Lim, userId: number, coinId: number, qtd: number) {
  if (!Number.isInteger(qtd) || qtd < 1) fail(400, 'Informe uma quantidade inteira de MCoins.', 'invalid', 'quantidade')
  if (qtd < L.min || qtd > L.max) fail(400, `A quantidade deve ficar entre ${L.min} e ${L.max} MCoins por operação.`, 'limite', 'quantidade')
  if (L.limiteDiario > 0) { const hoje = nowIso().slice(0, 10)
    const rows = (kind === 'transferencia' ? await q("SELECT qty, created_at FROM coin_transfers WHERE from_user = $1 AND coin_id = $2 AND status = 'concluida'", [userId, coinId]) : await q("SELECT qty, created_at FROM coin_orders WHERE user_id = $1 AND coin_id = $2 AND kind = $3 AND status IN ('pendente','concluida')", [userId, coinId, kind])) as any[]
    const ja = rows.filter((r) => String(isoOf(r.created_at)).slice(0, 10) === hoje).reduce((a, r) => a + num(r.qty), 0); if (ja + qtd > L.limiteDiario) fail(400, `Limite diário de ${L.limiteDiario} MCoins atingido (já usado hoje: ${ja}).`, 'limite', 'quantidade') }
}
const pedOut = (o: any) => ({ id: Number(o.id), codigo: o.op_code, tipo: o.kind, moedaId: Number(o.coin_id), moedaCodigo: o.coin_code || '', usuarioId: Number(o.user_id), quantidade: num(o.qty), precoUnitario: num(o.unit_price), bruto: num(o.gross), taxa: num(o.fee), total: num(o.net), liquidacao: o.settlement, status: o.status, nota: o.note || '', resolvidoPor: o.resolved_by ? Number(o.resolved_by) : null, notaResolucao: o.resolved_note || '', resolvidoEm: o.resolved_at ? isoOf(o.resolved_at) : null, em: isoOf(o.created_at) })
export async function negociar(kind: 'compra' | 'venda', u: { id: number }, b: any) {
  const coin: any = await C.activeCoin(Number(b.moedaId))
  // moeda com mercado próprio: preço e regras são os do mercado da moeda (sem dois preços para a mesma moeda)
  if (await (await import('./coin-market.js')).negociavel(coin.id)) fail(409, 'Esta moeda é negociada pelo Mercado (cotação própria). Abra a moeda no Mercado para comprar ou vender.', 'usar_mercado')
  await exigir(u.id, coin.id, kind === 'compra' ? 'comprar' : 'vender')
  const cfg = await getCentral(), L = cfg.comercial[kind], qtd = Number(b.quantidade); await limites(kind, L, u.id, coin.id, qtd)
  const cot = cotar(kind, L, qtd), idem = String(b.idem || '').trim()
  if (idem) { const ja = await one('SELECT * FROM coin_orders WHERE user_id = $1 AND idem = $2', [u.id, idem]); if (ja) return { ok: true, duplicado: true, pedido: pedOut(ja) } }
  const resumo = { moeda: { id: coin.id, codigo: coin.codigo, simbolo: coin.simbolo, nome: coin.nome }, tipo: kind, quantidade: qtd, ...cot, liquidacao: cfg.comercial.liquidacao, saldoAtual: await C.balanceOf(coin.id, u.id), disponivelEmissao: coin.disponiveis }
  if (b.confirmar !== true) return { ok: true, previa: true, ...resumo }
  if (!IDEM.test(idem)) fail(400, 'Chave da operação inválida (8 a 80 caracteres: letras, números, : _ . -).', 'invalid', 'idem')
  if (kind === 'compra' && cfg.comercial.liquidacao === 'interna' && coin.disponiveis < qtd) fail(409, 'Não há MCoins disponíveis na emissão para esta compra.', 'sem_estoque')
  const op = codigo(kind === 'compra' ? 'MCC' : 'MCV'), imediata = cfg.comercial.liquidacao === 'interna', nota = String(b.nota || '').slice(0, 200)
  try {
    const r = await withLock(`coin:${coin.id}`, async () => {
      const dup = await one('SELECT * FROM coin_orders WHERE user_id = $1 AND idem = $2', [u.id, idem]); if (dup) return { dup }
      return db().tx(async (t) => {
        const now = nowIso(), st = imediata ? 'concluida' : 'pendente'
        await t.query('INSERT INTO coin_orders (op_code, kind, coin_id, coin_code, user_id, qty, unit_price, gross, fee, net, settlement, status, idem, note, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)', [op, kind, coin.id, coin.codigo || null, u.id, qtd, cot.precoUnitario, cot.bruto, cot.taxa, cot.total, cfg.comercial.liquidacao, st, idem, nota, now])
        const id = Number((await t.query('SELECT id FROM coin_orders WHERE op_code = $1', [op]))[0].id)
        if (kind === 'compra' && imediata) { await emitir(t, coin.id, qtd, now); const l = await lancar(t, coin.id, u.id, 'compra', qtd, `compra:${id}`, `usuario ${u.id}`, `Compra ${op}`, now); await t.query('UPDATE coin_orders SET ledger_id = $1, resolved_at = $2 WHERE id = $3', [l.id, now, id]) }
        if (kind === 'venda') { const l = await lancar(t, coin.id, u.id, 'venda', -qtd, `venda:${id}`, `usuario ${u.id}`, `Venda ${op}`, now); if (imediata) await devolver(t, coin.id, qtd, now); await t.query('UPDATE coin_orders SET ledger_id = $1, resolved_at = $2 WHERE id = $3', [l.id, imediata ? now : null, id]) }
        return { o: (await t.query('SELECT * FROM coin_orders WHERE id = $1', [id]))[0] }
      })
    })
    if ('dup' in r && r.dup) return { ok: true, duplicado: true, pedido: pedOut(r.dup) }
    const o = pedOut((r as any).o); await audit(u.id, `coins.${kind}`, coin.id, { operacao: op, quantidade: qtd, total: cot.total, status: o.status, liquidacao: cfg.comercial.liquidacao })
    return { ok: true, duplicado: false, pedido: o, saldo: await C.balanceOf(coin.id, u.id) }
  } catch (e: any) { try { await audit(u.id, `coins.${kind}.falha`, coin.id, { erro: String(e?.message || e).slice(0, 160), quantidade: qtd }) } catch { /* segue */ } throw e }
}
/** Administrador confirma (liquidação registrada fora do sistema) ou recusa um pedido pendente. Atômico e à prova de repetição. */
export async function resolverPedido(id: number, acao: string, nota: string, adminId: number) {
  if (!['confirmar', 'recusar'].includes(acao)) fail(400, 'Ação inválida.', 'invalid')
  const o: any = await one('SELECT * FROM coin_orders WHERE id = $1', [id]); if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const coinId = Number(o.coin_id), qtd = num(o.qty), uid = Number(o.user_id), n = String(nota || '').slice(0, 200)
  await withLock(`coin:${coinId}`, () => db().tx(async (t) => {
    const now = nowIso(), st = acao === 'confirmar' ? 'concluida' : 'recusada'
    if (acao === 'confirmar' && (o.market === true || o.market === 1 || o.market === 't')) { // negócio do mercado: crédito/devolução + movimento da cotação no momento da confirmação
      await (await import('./coin-market.js')).liquidar(t, o, `admin ${adminId}`, now)
      await t.query('UPDATE coin_orders SET resolved_by = $1, resolved_note = $2 WHERE id = $3', [adminId, n, id]); return
    }
    const r = await t.query("UPDATE coin_orders SET status = $1, resolved_by = $2, resolved_note = $3, resolved_at = $4 WHERE id = $5 AND status = 'pendente' RETURNING id", [st, adminId, n, now, id]); if (!r.length) fail(409, 'Este pedido já foi resolvido.', 'resolvido')
    if (o.kind === 'compra' && acao === 'confirmar') { await emitir(t, coinId, qtd, now); const l = await lancar(t, coinId, uid, 'compra', qtd, `compra:${id}`, `admin ${adminId}`, `Compra ${o.op_code}`, now); await t.query('UPDATE coin_orders SET ledger_id = $1 WHERE id = $2', [l.id, id]) }
    if (o.kind === 'venda') { if (acao === 'confirmar') await devolver(t, coinId, qtd, now); else await lancar(t, coinId, uid, 'venda_estorno', qtd, `venda:${id}:estorno`, `admin ${adminId}`, `Venda ${o.op_code} recusada`, now) }
  }))
  await audit(adminId, `coins.${o.kind}.${acao}`, coinId, { operacao: o.op_code, usuario: uid, quantidade: qtd, nota: n })
  try { await notify(uid, { type: 'coin', title: acao === 'confirmar' ? `${o.kind === 'compra' ? 'Compra' : 'Venda'} concluída` : `${o.kind === 'compra' ? 'Compra' : 'Venda'} recusada`, body: `${qtd} MCoins · ${o.op_code}${n ? ' · ' + n : ''}`, link: '/x/carteira', ref: `coin-ped:${o.op_code}:${acao}` }) } catch { /* segue */ }
  return pedOut((await one('SELECT * FROM coin_orders WHERE id = $1', [id])))
}
export async function cancelarPedido(userId: number, id: number) {
  const o: any = await one('SELECT * FROM coin_orders WHERE id = $1 AND user_id = $2', [id, userId]); if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  await withLock(`coin:${o.coin_id}`, () => db().tx(async (t) => {
    const now = nowIso(), r = await t.query("UPDATE coin_orders SET status = 'cancelada', resolved_at = $1, resolved_note = 'Cancelado pelo usuário' WHERE id = $2 AND status = 'pendente' RETURNING id", [now, id]); if (!r.length) fail(409, 'Só pedidos pendentes podem ser cancelados.', 'resolvido')
    if (o.kind === 'venda') await lancar(t, Number(o.coin_id), userId, 'venda_estorno', num(o.qty), `venda:${id}:estorno`, `usuario ${userId}`, `Venda ${o.op_code} cancelada`, now)
  }))
  await audit(userId, `coins.${o.kind}.cancelar`, Number(o.coin_id), { operacao: o.op_code }); return pedOut((await one('SELECT * FROM coin_orders WHERE id = $1', [id])))
}
export async function pedidosAdmin(status?: string) { const rows = await q(`SELECT o.*, u.name, u.email FROM coin_orders o LEFT JOIN users u ON u.id = o.user_id ${status ? 'WHERE o.status = $1' : ''} ORDER BY o.id DESC LIMIT 200`, status ? [status] : []) as any[]; return rows.map((r) => ({ ...pedOut(r), usuario: r.name || '', email: r.email || '' })) }
export async function meusPedidos(userId: number) { return { pedidos: (await q('SELECT * FROM coin_orders WHERE user_id = $1 ORDER BY id DESC LIMIT 50', [userId]) as any[]).map(pedOut), transferencias: await minhasTransferencias(userId) } }

/* ---------- transferência entre contas (pronta, desligada até autorização) ---------- */
const trfOut = (r: any, me?: number) => ({ id: Number(r.id), codigo: r.tx_code, moedaId: Number(r.coin_id), moedaCodigo: r.coin_code || '', origemId: Number(r.from_user), destinoId: Number(r.to_user), quantidade: num(r.qty), taxa: num(r.fee), status: r.status, nota: r.note || '', confirmadaEm: r.confirmed_at ? isoOf(r.confirmed_at) : null, em: isoOf(r.created_at), sentido: me == null ? undefined : Number(r.from_user) === me ? 'enviada' : 'recebida' })
const primeiroNome = (n: string) => { const p = String(n || '').trim().split(/\s+/); return p.length > 1 ? `${p[0]} ${p[p.length - 1][0]}.` : p[0] || '—' }
export async function transferir(u: { id: number }, b: any) {
  const coin: any = await C.activeCoin(Number(b.moedaId)); await exigir(u.id, coin.id, 'transferir')
  const to = Number(b.destinoId); if (!Number.isInteger(to) || to <= 0) fail(400, 'Informe a conta de destino.', 'invalid', 'destinoId'); if (to === u.id) fail(400, 'Não é possível transferir para a própria conta.', 'invalid', 'destinoId')
  const dest = await one("SELECT id, name FROM users WHERE id = $1 AND status = 'active'", [to]); if (!dest) fail(404, 'Conta de destino não encontrada.', 'not_found', 'destinoId')
  const rec = await pode(to, coin.id, 'receber'); if (!rec.ok) fail(403, 'A conta de destino não pode receber MCoins desta moeda.', 'forbidden', 'destinoId')
  const cfg = await getCentral(), L = cfg.comercial.transferencia, qtd = Number(b.quantidade); await limites('transferencia', L, u.id, coin.id, qtd)
  const taxa = Math.ceil((qtd * L.taxaPct) / 100) + Math.floor(L.taxaFixa), idem = String(b.idem || '').trim(), saldo = await C.balanceOf(coin.id, u.id)
  if (idem) { const ja = await one('SELECT * FROM coin_transfers WHERE from_user = $1 AND idem = $2', [u.id, idem]); if (ja) return { ok: true, duplicado: true, transferencia: trfOut(ja, u.id) } }
  const resumo = { moeda: { id: coin.id, codigo: coin.codigo, simbolo: coin.simbolo }, destino: { id: to, nome: primeiroNome(dest.name) }, quantidade: qtd, taxa, totalDebitado: qtd + taxa, saldoAtual: saldo, saldoApos: saldo - qtd - taxa }
  if (b.confirmar !== true) return { ok: true, previa: true, ...resumo }
  if (!IDEM.test(idem)) fail(400, 'Chave da operação inválida (8 a 80 caracteres: letras, números, : _ . -).', 'invalid', 'idem')
  if (saldo < qtd + taxa) fail(409, 'Saldo de moedas insuficiente.', 'saldo_insuficiente')
  const tx = codigo('MCX'), nota = String(b.nota || '').slice(0, 200)
  const r = await withLock(`coin:${coin.id}`, async () => {
    const dup = await one('SELECT * FROM coin_transfers WHERE from_user = $1 AND idem = $2', [u.id, idem]); if (dup) return { dup }
    return db().tx(async (t) => {
      const now = nowIso(); await t.query('INSERT INTO coin_transfers (tx_code, coin_id, coin_code, from_user, to_user, qty, fee, status, idem, note, confirmed_at, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$11)', [tx, coin.id, coin.codigo || null, u.id, to, qtd, taxa, 'concluida', idem, nota, now])
      const id = Number((await t.query('SELECT id FROM coin_transfers WHERE tx_code = $1', [tx]))[0].id)
      const out = await lancar(t, coin.id, u.id, 'transf_saida', -(qtd + taxa), `transf:${id}:saida`, `usuario ${u.id}`, `Transferência ${tx} para conta ${to}`, now)
      const inn = await lancar(t, coin.id, to, 'transf_entrada', qtd, `transf:${id}:entrada`, `usuario ${u.id}`, `Transferência ${tx} da conta ${u.id}`, now)
      if (taxa > 0) await devolver(t, coin.id, taxa, now) // a taxa volta para a emissão da moeda
      await t.query('UPDATE coin_transfers SET ledger_out = $1, ledger_in = $2 WHERE id = $3', [out.id, inn.id, id]); return { o: (await t.query('SELECT * FROM coin_transfers WHERE id = $1', [id]))[0] }
    })
  })
  if ('dup' in r && r.dup) return { ok: true, duplicado: true, transferencia: trfOut(r.dup, u.id) }
  await audit(u.id, 'coins.transferir', coin.id, { transacao: tx, destino: to, quantidade: qtd, taxa })
  try { await notify(to, { type: 'coin', title: `Você recebeu ${qtd} ${coin.simbolo}`, body: `Transferência ${tx}`, link: '/x/carteira', ref: `coin-trf:${tx}` }) } catch { /* segue */ }
  return { ok: true, duplicado: false, transferencia: trfOut((r as any).o, u.id), saldo: await C.balanceOf(coin.id, u.id) }
}
export async function minhasTransferencias(userId: number) { return (await q('SELECT * FROM coin_transfers WHERE from_user = $1 OR to_user = $1 ORDER BY id DESC LIMIT 50', [userId]) as any[]).map((r) => trfOut(r, userId)) }
export async function transferenciasAdmin() { const rows = await q('SELECT t.*, a.name AS an, b.name AS bn FROM coin_transfers t LEFT JOIN users a ON a.id = t.from_user LEFT JOIN users b ON b.id = t.to_user ORDER BY t.id DESC LIMIT 200') as any[]; return rows.map((r) => ({ ...trfOut(r), origem: r.an || '', destino: r.bn || '' })) }

/* ---------- visão geral administrativa ---------- */
export async function visao() {
  const cfg = await getCentral(), coins = (await C.listCoins()) as any[]
  const politicas = await Promise.all(coins.map(async (c) => ({ moedaId: c.id, codigo: c.codigo, nome: c.nome, simbolo: c.simbolo, status: c.status, ...(await politicaMoeda(c.id)) })))
  const cnt = async (sql: string) => Number((await one(sql))?.n ?? 0) // COUNT(*) sempre devolve 1 linha; sem linha = 0
  return { config: cfg, politicas, grupos: await listarGrupos(), resumo: { pedidosPendentes: await cnt("SELECT COUNT(*) AS n FROM coin_orders WHERE status = 'pendente'"), transferencias: await cnt('SELECT COUNT(*) AS n FROM coin_transfers'), permissoes: await cnt('SELECT COUNT(*) AS n FROM coin_permissions') }, aviso: 'Compra e venda de MCoins não presumem conversão em dinheiro real: a liquidação é definida aqui e deve respeitar as regras aplicáveis. Tudo permanece desligado até você ativar.' }
}
