// Identidade visual da empresa: UMA configuração central (businesses.data.tema), normalizada aqui e
// entregue igual ao catálogo, ao agente de atendimento e a qualquer tela comercial da empresa.
export type Tema = {
  preset: string; cor: string; fundo: 'escuro' | 'claro' | 'colorido'; layout: 'lista' | 'grade'; cantos: 'arredondado' | 'reto'
  /** personalização do catálogo (25/11): logo e botões — padrões = aparência que o catálogo já tinha */
  logoPos: 'esquerda' | 'centro' | 'direita'; logoForma: 'original' | 'circular' | 'arredondado'; logoTam: number
  botaoForma: 'retangular' | 'arredondado' | 'capsula'; botaoEstilo: 'preenchido' | 'contorno'; botaoTam: 'compacto' | 'padrao' | 'grande'
}
export const TEMA_PADRAO: Tema = { preset: 'padrao', cor: '#3b6cff', fundo: 'escuro', layout: 'lista', cantos: 'arredondado', logoPos: 'esquerda', logoForma: 'arredondado', logoTam: 64, botaoForma: 'capsula', botaoEstilo: 'preenchido', botaoTam: 'padrao' }
export const LOGO_TAM = { min: 48, max: 112 }

/** Aceita qualquer valor salvo (inclusive temas antigos incompletos) e devolve um tema sempre completo e válido. */
export function normalizeTema(t: any): Tema {
  const o = t && typeof t === 'object' ? t : {}
  return {
    preset: typeof o.preset === 'string' && /^[a-z0-9_-]{1,20}$/i.test(o.preset) ? o.preset : TEMA_PADRAO.preset,
    cor: /^#[0-9a-f]{6}$/i.test(String(o.cor)) ? String(o.cor).toLowerCase() : TEMA_PADRAO.cor,
    fundo: ['escuro', 'claro', 'colorido'].includes(o.fundo) ? o.fundo : TEMA_PADRAO.fundo,
    layout: o.layout === 'grade' ? 'grade' : 'lista',
    cantos: o.cantos === 'reto' ? 'reto' : 'arredondado',
    logoPos: ['esquerda', 'centro', 'direita'].includes(o.logoPos) ? o.logoPos : TEMA_PADRAO.logoPos,
    logoForma: ['original', 'circular', 'arredondado'].includes(o.logoForma) ? o.logoForma : TEMA_PADRAO.logoForma,
    logoTam: (o.logoTam === null || o.logoTam === undefined || o.logoTam === '' || !Number.isFinite(Number(o.logoTam))) ? TEMA_PADRAO.logoTam : Math.min(LOGO_TAM.max, Math.max(LOGO_TAM.min, Math.round(Number(o.logoTam)))), // fora da faixa → limitado (sem distorcer o layout)
    // empresas que já usavam cantos retos continuam com botões retos (nada muda sem o dono escolher)
    botaoForma: ['retangular', 'arredondado', 'capsula'].includes(o.botaoForma) ? o.botaoForma : o.cantos === 'reto' ? 'retangular' : 'capsula',
    botaoEstilo: o.botaoEstilo === 'contorno' ? 'contorno' : 'preenchido',
    botaoTam: ['compacto', 'padrao', 'grande'].includes(o.botaoTam) ? o.botaoTam : 'padrao',
  }
}
