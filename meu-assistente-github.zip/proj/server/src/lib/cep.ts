// CEP → endereço (rua, bairro, cidade, UF) para o cadastro da empresa. Fontes públicas oficiais de CEP, uma reserva da outra:
// ViaCEP e BrasilAPI. Nunca inventa: CEP sem resultado volta "não encontrado"; fonte fora do ar volta "indisponível" e o
// formulário continua aceitando o endereço digitado à mão. CEP_URL (com {cep}) troca as fontes (testes/instalação própria).

export interface EnderecoCep { cep: string; rua: string; bairro: string; cidade: string; uf: string; complemento: string }
export type ResultadoCep = ({ ok: true } & EnderecoCep) | { ok: false; motivo: 'invalido' | 'nao_encontrado' | 'indisponivel'; mensagem: string }

export const soDigitosCep = (v: unknown) => String(v ?? '').replace(/\D/g, '')
export const formatarCep = (v: unknown) => { const d = soDigitosCep(v); return d.length === 8 ? d.slice(0, 5) + '-' + d.slice(5) : '' }
const fontes = () => (process.env.CEP_URL ? process.env.CEP_URL.split(',') : ['https://viacep.com.br/ws/{cep}/json/', 'https://brasilapi.com.br/api/cep/v1/{cep}']).map((s) => s.trim()).filter(Boolean)
const c = (v: any, n = 80) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n)
const UFS = new Set('AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' '))

/** Resposta de uma fonte → endereço, "nao" (a fonte diz que o CEP não existe) ou null (fonte com problema). */
function ler(j: any, status: number, cep: string): EnderecoCep | 'nao' | null {
  if (status === 404 || status === 400 || (j && (j.erro === true || j.erro === 'true'))) return 'nao'
  if (!j || typeof j !== 'object' || status >= 300) return null
  const uf = c(j.uf ?? j.state, 2).toUpperCase(), cidade = c(j.localidade ?? j.city)
  if (!UFS.has(uf) || !cidade) return null
  return { cep: formatarCep(cep), rua: c(j.logradouro ?? j.street), bairro: c(j.bairro ?? j.neighborhood), cidade, uf, complemento: c(j.complemento, 60) }
}
const cache = new Map<string, { em: number; r: ResultadoCep }>()
const VALIDADE = 24 * 3600_000

export async function buscarCep(entrada: unknown): Promise<ResultadoCep> {
  const cep = soDigitosCep(entrada)
  if (cep.length !== 8 || /^(\d)\1{7}$/.test(cep)) return { ok: false, motivo: 'invalido', mensagem: 'CEP inválido: use os 8 números (ex.: 60150-160).' }
  const ok = cache.get(cep); if (ok && Date.now() - ok.em < VALIDADE) return ok.r
  let naoAchou = false
  for (const url of fontes()) {
    try {
      const r = await fetch(url.replace('{cep}', cep), { headers: { Accept: 'application/json', 'User-Agent': 'MeuAssistente/1.0' }, signal: AbortSignal.timeout(5000) })
      const j = await r.json().catch(() => null), e = ler(j, r.status, cep)
      if (e === 'nao') { naoAchou = true; continue }
      if (e) { const res: ResultadoCep = { ok: true, ...e }; cache.set(cep, { em: Date.now(), r: res }); if (cache.size > 5000) cache.delete(cache.keys().next().value!); return res }
    } catch (x: any) { console.warn(`[cep] fonte indisponível: ${new URL(url.replace('{cep}', cep)).host} (${String(x?.name || x?.message || x).slice(0, 60)})`) } // sem o CEP no log
  }
  if (naoAchou) { const res: ResultadoCep = { ok: false, motivo: 'nao_encontrado', mensagem: 'Não encontramos esse CEP. Confira os números ou preencha o endereço manualmente.' }; cache.set(cep, { em: Date.now() - VALIDADE + 3600_000, r: res }); return res }
  return { ok: false, motivo: 'indisponivel', mensagem: 'A busca de CEP está fora do ar agora. Preencha o endereço manualmente; ele é salvo normalmente.' }
}

/* ---------- endereço da empresa por partes ---------- */
export interface PartesEmpresa { cep: string; rua: string; numero: string; complemento: string; bairro: string; cidade: string; uf: string; referencia: string }
export const CAMPOS_ENDERECO: (keyof PartesEmpresa)[] = ['cep', 'rua', 'numero', 'complemento', 'bairro', 'cidade', 'uf', 'referencia']
/** Normaliza as partes enviadas pelo formulário (null = nada preenchido). Não valida obrigatoriedade. */
export function normalizarPartes(p: any): PartesEmpresa | null {
  if (!p || typeof p !== 'object') return null
  const out: PartesEmpresa = { cep: formatarCep(p.cep) || '', rua: c(p.rua), numero: c(p.numero, 12), complemento: c(p.complemento, 60), bairro: c(p.bairro, 60), cidade: c(p.cidade, 60), uf: c(p.uf, 2).toUpperCase(), referencia: c(p.referencia, 100) }
  return CAMPOS_ENDERECO.some((k) => out[k]) ? out : null
}
/** Mensagem do 1º problema do endereço por partes (ou ''). */
export function problemaPartes(p: PartesEmpresa, cepDigitado: unknown): string {
  if (soDigitosCep(cepDigitado) && !p.cep) return 'CEP inválido: use os 8 números (ex.: 60150-160).'
  if (p.rua.length < 3) return 'Informe a rua do endereço da empresa.'
  if (!p.numero) return 'Informe o número (ou "S/N" se não houver).'
  if (!p.bairro) return 'Informe o bairro.'
  if (!p.cidade) return 'Informe a cidade.'
  if (!UFS.has(p.uf)) return 'Informe a UF (ex.: CE, SP).'
  return ''
}
/** Linha única do endereço (como sempre foi guardado em `endereco`): "Rua X, 123 - Sala 2, Bairro, Cidade - UF, 60150-160".
 *  O ponto de referência fica fora (vai em `referencia`), para não atrapalhar mapa e rota. */
export const linhaEndereco = (p: PartesEmpresa) => [[p.rua, p.numero].filter(Boolean).join(', ') + (p.complemento ? ' - ' + p.complemento : ''), p.bairro, p.cidade ? p.cidade + (p.uf ? ' - ' + p.uf : '') : '', p.cep].filter(Boolean).join(', ').slice(0, 200)
/** Consultas ao mapa, da mais precisa para a mais ampla (sem complemento, que confunde o geocodificador). */
export const consultasMapa = (p: PartesEmpresa) => [...new Set([
  [[p.rua, p.numero].filter(Boolean).join(', '), p.bairro, p.cidade, p.uf].filter(Boolean).join(', '),
  [p.rua, p.cidade, p.uf].filter(Boolean).join(', '),
  p.cep ? `${p.cep}, ${p.cidade} ${p.uf}`.trim() : '',
].filter((x) => x.length >= 5))]
