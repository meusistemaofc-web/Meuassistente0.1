// REPUTAÇÃO E AVALIAÇÕES DA EMPRESA — integração com o Google por LINK (sem OAuth, sem API paga).
// • As avaliações INTERNAS continuam sendo as da tabela `reviews` (pedido/agendamento concluído → 1 avaliação), sem mudança.
// • O Google é um caminho EXTRA e voluntário: o dono cadastra o link oficial de avaliação do Perfil da Empresa; o cliente vê
//   "Avaliar também no Google" e só sai do app se tocar. Nada é publicado em nome do cliente e o app NUNCA diz que a
//   avaliação foi publicada (não há como confirmar): registra apenas o CLIQUE (business_stats, tipo "google_avaliacao").
// • Convite neutro: aparece para qualquer avaliação (não filtra só clientes satisfeitos) e sem benefício em troca.
// • Configuração individual de cada empresa (businesses.data.reputacao), editável só pelo dono.

export interface Reputacao { google: { url: string; ativo: boolean; tipo: '' | 'avaliacao' | 'perfil' }; convite: string }
export const CONVITE_PADRAO = 'Como foi sua experiência com {empresa}? Sua avaliação ajuda a empresa a melhorar e outras pessoas a escolher.'

/** Endereços aceitos: somente domínios oficiais do Google usados para avaliações e para o Perfil da Empresa/Maps. */
const HOSTS = /^(g\.page|maps\.app\.goo\.gl|goo\.gl|search\.google\.com|maps\.google\.com(\.br)?|(www\.)?google\.com(\.br)?|business\.google\.com)$/i
export function validarLinkGoogle(raw: string): { ok: true; url: string; tipo: 'avaliacao' | 'perfil'; aviso?: string } | { ok: false; erro: string } {
  const s = String(raw || '').trim()
  if (!s) return { ok: false, erro: 'Cole o link de avaliação da sua empresa no Google.' }
  if (s.length > 600) return { ok: false, erro: 'Link longo demais.' }
  let u: URL; try { u = new URL(/^https?:\/\//i.test(s) ? s : 'https://' + s) } catch { return { ok: false, erro: 'Isso não parece um link. Copie o link completo (começa com https://).' } }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return { ok: false, erro: 'O link precisa começar com https://.' }
  if (u.username || u.password) return { ok: false, erro: 'Link inválido.' }
  if (!HOSTS.test(u.hostname)) return { ok: false, erro: 'Use o link oficial do Google (g.page, maps.app.goo.gl, search.google.com ou google.com/maps).' }
  if (u.hostname === 'goo.gl' && !/^\/maps\//.test(u.pathname)) return { ok: false, erro: 'Esse link curto do Google não é do Maps. Use o link de avaliação do Perfil da Empresa.' }
  if (/^(www\.)?google\.com(\.br)?$/i.test(u.hostname) && !/^\/maps/.test(u.pathname) && !/[#&?](lrd|placeid)=/i.test(u.href) && !/^\/search/.test(u.pathname)) return { ok: false, erro: 'Esse endereço do Google não é de uma empresa. Use o link de avaliação do Perfil da Empresa.' }
  u.protocol = 'https:'
  // abre direto a janela de avaliação? (link "Pedir avaliações" do Perfil da Empresa: g.page/r/…/review ou writereview?placeid=)
  const direto = /\/review\/?$/i.test(u.pathname) || /writereview/i.test(u.pathname) || /[#&?]lrd=/i.test(u.href)
  return direto ? { ok: true, url: u.href, tipo: 'avaliacao' } : { ok: true, url: u.href, tipo: 'perfil', aviso: 'Este link abre o perfil da empresa; o cliente ainda precisa tocar em "Escrever avaliação". Para abrir direto a avaliação, use o link de "Pedir avaliações" do Perfil da Empresa.' }
}

/** Configuração normalizada (empresas antigas, sem nada salvo, ficam com o Google desligado e o convite padrão). */
export function reputacaoDe(x: any): Reputacao {
  const r = x?.reputacao || {}, g = r.google || {}
  const v = g.url ? validarLinkGoogle(String(g.url)) : null
  return { google: { url: v && v.ok ? v.url : '', ativo: !!(v && v.ok && g.ativo), tipo: v && v.ok ? v.tipo : '' }, convite: String(r.convite || '').trim().slice(0, 300) }
}
/** Texto do convite com o nome da empresa (sem promessa de benefício: o painel recusa textos assim). */
export const textoConvite = (rep: Reputacao, empresa: string) => (rep.convite || CONVITE_PADRAO).replace(/\{empresa\}/g, empresa || 'a empresa')
/** Regras do Google e boas práticas: convite neutro, sem recompensa e sem pedir só nota alta. */
export function conviteProibido(t: string): string | null {
  const s = String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
  if (/\b(desconto|cupom|brinde|gratis|premio|sorteio|cashback|moeda|ganhe|ganha|recompensa|beneficio)\b/.test(s)) return 'O convite não pode oferecer benefício em troca de avaliação (regra do Google).'
  if (/\b(5 estrelas|cinco estrelas|nota maxima|nota 5|so se gostou|apenas se gostou|se gostou)\b/.test(s)) return 'O convite precisa ser neutro: não peça nota alta nem convide só quem gostou.'
  return null
}

/* ---------- convite no chat do cliente ---------- */
// Situação apropriada identificada pela mensagem do próprio cliente (recebeu o pedido, foi atendido, quer avaliar): o
// assistente oferece avaliar o pedido/agendamento concluído mais recente que ainda não foi avaliado (sistema interno) e,
// se a empresa ativou, o botão opcional "Avaliar também no Google". Nada é enviado sem o cliente agir.
const SITUACAO = /\b(quero avaliar|queria avaliar|avaliar (a |o |essa |esta |minha |meu )?(loja|empresa|pedido|compra|atendimento|servi[cç]o|agendamento)|deixar (uma )?avalia[cç][aã]o|dar (uma )?nota (para|pra|a|ao|à)|recebi (o |meu |a minha |minha )?(pedido|encomenda|compra)|(meu |o )?pedido (chegou|foi entregue)|chegou (o |meu )?pedido|fui atendid[oa]|(o |meu )?(servi[cç]o|atendimento|agendamento) (foi |já foi |ja foi )?(conclu[ií]do|realizado|feito|encerrado))\b/i
export function situacaoDeAvaliacao(texto: string) { return SITUACAO.test(String(texto || '')) }
export async function conviteNoChat(userId: number, texto: string): Promise<{ content: string } | null> {
  if (!situacaoDeAvaliacao(texto)) return null
  const { q, J } = await import('../db/index.js')
  const desde = new Date(Date.now() - 45 * 86400_000).toISOString()
  const o = (await q(`SELECT o.id, o.data, b.data AS bdata FROM orders o JOIN businesses b ON b.id = o.business_id
    WHERE o.customer_id = $1 AND o.status = 'concluido' AND o.updated_at >= $2 AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.order_id = o.id) ORDER BY o.updated_at DESC LIMIT 1`, [userId, desde]))[0]
  if (!o) return /\b(quero|queria|deixar|dar)\b/i.test(texto) ? { content: 'Você não tem nenhum pedido ou agendamento concluído esperando avaliação agora. Assim que um for concluído, é só me pedir que eu abro a avaliação.' } : null
  const x = J<any>(o.bdata, {}), d = J<any>(o.data, {}), rep = reputacaoDe(x)
  return { content: `${textoConvite(rep, x.empresa || d.empresa || '')} ⟦rev:${Number(o.id)}⟧` }
}
