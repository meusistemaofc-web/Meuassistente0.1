// Conclusão automática de compromissos.
// Um compromisso pendente ("Agendado" ou "Confirmado") vira "Concluído" sozinho quando passa o LIMITE:
//   • com horário de término (endTime) ou duração (duracaoMin): término + 30 min de tolerância;
//   • só com horário de início (sem duração): início + 30 min (término de referência) + 30 min de tolerância;
//   • sem horário (dia inteiro): fim do dia no fuso do dono + 30 min.
// Regras:
//   • nunca antes do limite; cancelado, "não compareceu" e concluído não são tocados;
//   • o horário é sempre lido no fuso do dono do compromisso (configuração do usuário);
//   • a troca é atômica e condicionada ao status pendente (UPDATE … WHERE status IN (…)): duas execuções simultâneas não
//     duplicam o processamento nem sobrescrevem uma alteração feita pela pessoa no mesmo instante;
//   • fica registrado que foi automático (data.conclusaoAutomatica + histórico "automaticamente");
//   • a pessoa pode corrigir depois pela tela/chat; um compromisso já processado (ou corrigido) não é concluído de novo.
import { q, J } from '../db/index.js'
import { zonedToUtc, validTz } from './time.js'

export const TOLERANCIA_MIN = 30
export const DURACAO_REF_MIN = 30
const PENDENTES = ['scheduled', 'confirmed']

/** Instante (ms) a partir do qual o compromisso pode ser concluído automaticamente. */
export function limiteConclusao(day: string, d: { time?: string | null; endTime?: string | null; duracaoMin?: number | null; duration?: number | null }, tz: string): number | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day || ''))) return null
  const hhmm = (s: any) => typeof s === 'string' && /^\d{2}:\d{2}$/.test(s)
  if (!hhmm(d.time)) { // dia inteiro: depois que o dia acabou no fuso do dono
    const prox = new Date(Date.parse(day + 'T00:00:00Z') + 86400_000).toISOString().slice(0, 10)
    return new Date(zonedToUtc(prox, '00:00', tz)).getTime() + TOLERANCIA_MIN * 60_000
  }
  const ini = new Date(zonedToUtc(day, String(d.time), tz)).getTime()
  let fim: number
  if (hhmm(d.endTime) && String(d.endTime) > String(d.time)) fim = new Date(zonedToUtc(day, String(d.endTime), tz)).getTime()
  else if (Number(d.duracaoMin || d.duration) > 0) fim = ini + Number(d.duracaoMin || d.duration) * 60_000
  else fim = ini + DURACAO_REF_MIN * 60_000
  return fim + TOLERANCIA_MIN * 60_000
}

/** Pode entrar na conclusão automática? (ainda pendente, nunca processado, não desligado pela pessoa) */
export const elegivel = (status: string | null, d: any) => PENDENTES.includes(status || 'scheduled') && !d?.conclusaoAutomatica && d?.autoConcluir !== false

/** Varredura (chamada pelo agendador a cada 30 s). Devolve quantos foram concluídos. */
export async function concluirVencidos(now = new Date(), limite = 500): Promise<number> {
  const { getConfig } = await import('./settings.js')
  if ((await getConfig<any>('agenda_auto_concluir', { ativo: true })).ativo === false) return 0
  // candidatos: pendentes com dia até amanhã (UTC) — o limite exato é conferido no fuso de cada dono
  const amanha = new Date(now.getTime() + 86400_000).toISOString().slice(0, 10)
  const rows = await q(`SELECT i.id, i.user_id, i.day, i.status, i.data, u.settings FROM items i JOIN users u ON u.id = i.user_id
    WHERE i.type = 'appointment' AND (i.status IS NULL OR i.status IN ('scheduled','confirmed')) AND i.day IS NOT NULL AND i.day <= $1 ORDER BY i.day LIMIT ${Math.max(1, Math.min(2000, limite))}`, [amanha])
  let n = 0
  for (const r of rows as any[]) {
    const d = J<any>(r.data, {}); if (!elegivel(r.status, d)) continue
    const tz = validTz(J<any>(r.settings, {}).timezone), lim = limiteConclusao(String(r.day), d, tz)
    if (lim == null || now.getTime() < lim) continue // ainda dentro do horário + tolerância: não mexe
    const em = now.toISOString(), de = r.status || 'scheduled'
    const novo = { ...d, conclusaoAutomatica: { em, limite: new Date(lim).toISOString(), de, regra: d.endTime || Number(d.duracaoMin || d.duration) > 0 ? 'termino+30' : d.time ? 'inicio+30+30' : 'dia+30' },
      historico: [...(Array.isArray(d.historico) ? d.historico : []), { campo: 'situação', de: de === 'confirmed' ? 'Confirmado' : 'Agendado', para: 'Concluído', em, origem: 'automatico' }].slice(-50) }
    const up = await q(`UPDATE items SET status = 'done', due_at = NULL, data = $1, updated_at = $2 WHERE id = $3 AND type = 'appointment' AND (status IS NULL OR status IN ('scheduled','confirmed')) RETURNING id`, [JSON.stringify(novo), em, r.id])
    if (up.length) n++
  }
  if (n) console.log(`[agenda] ${n} compromisso(s) concluído(s) automaticamente`)
  return n
}
