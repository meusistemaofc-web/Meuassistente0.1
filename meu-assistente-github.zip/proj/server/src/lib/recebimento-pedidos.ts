// ONDE A EMPRESA RECEBE OS NOVOS PEDIDOS: painel do sistema OU WhatsApp da empresa (uma forma só).
//
// Chave GLOBAL do administrador (Plataforma → Comunicação → WhatsApp (envio) → "Pedidos pelo WhatsApp para as empresas"):
// config 'pedidos_whatsapp' = { ativo } (padrão: ligada). Desligada, a opção some da tela das empresas, o servidor recusa
// configurar/testar e TODO aviso vai para o painel (a escolha salva da empresa fica guardada para quando religar).
//
// Configuração por empresa em businesses.data.recebimentoPedidos = { painel, whatsapp } — exatamente um dos dois ligado
// (padrão: painel, o comportamento de sempre). Registro antigo com os dois ligados vale como WhatsApp (o que o dono escolheu
// a mais); o aviso de reserva no painel continua quando o WhatsApp falha.
//
// Regras:
//  • o pedido é SEMPRE gravado e aparece em Pedidos, com qualquer combinação — é lá que a empresa aceita, recusa e conclui;
//    o canal decide só para onde vai o AVISO de pedido novo;
//  • painel ligado → notificação no app (e push/e-mail conforme as preferências do dono), como antes;
//  • WhatsApp ligado → mensagem com o pedido completo para o WhatsApp cadastrado da empresa (lib/whatsapp-envio.ts);
//  • se o WhatsApp não puder ser confirmado (sem configuração, número inválido, falha), o aviso vai para o painel mesmo
//    com o painel desligado — nenhum pedido fica sem aviso;
//  • nenhum canal altera o status do pedido (nada é aceito ou concluído automaticamente);
//  • centrais de Lojas Conectadas continuam recebendo o repasse do aviso, qualquer que seja o canal.
import { one, q, J, nowIso } from '../db/index.js'
import { notify } from './notify.js'
import { HttpError } from './http.js'
import * as W from './whatsapp-envio.js'

export type Canais = { painel: boolean; whatsapp: boolean }
export const PADRAO: Canais = { painel: true, whatsapp: false }
export function canaisDe(data: unknown): Canais {
  const r = J<any>(data, {})?.recebimentoPedidos
  if (!r || typeof r !== 'object') return { ...PADRAO }
  return r.whatsapp === true ? { painel: false, whatsapp: true } : { ...PADRAO } // uma forma só
}
/** Chave global do administrador (cache curto; salvar no painel vale na hora). */
let GLB = { v: true, em: 0 }
export async function liberadoGlobal(): Promise<boolean> {
  if (Date.now() - GLB.em < 3000) return GLB.v
  const r = await one("SELECT value FROM app_config WHERE key = 'pedidos_whatsapp'"); const v = r ? (typeof r.value === 'string' ? J<any>(r.value, {}) : r.value) : {}
  GLB = { v: (v || {}).ativo !== false, em: Date.now() }; return GLB.v
}
export function definirGlobal(ativo: boolean) { GLB = { v: ativo, em: Date.now() } }
/** Canais que VALEM agora: com a chave global desligada, sempre o painel. */
export async function canaisEfetivos(data: unknown): Promise<Canais> { return (await liberadoGlobal()) ? canaisDe(data) : { ...PADRAO } }
export const RECURSO_OFF = 'O recebimento de pedidos pelo WhatsApp não está disponível no momento. Os pedidos continuam chegando pelo painel.'
type Aviso = { title: string; body?: string; link?: string; ref: string }

/** +55 11 98765-4321 (Brasil); outros países: +código e o número. */
export const fmtNumero = (d: string) => !d ? '' : /^55\d{10,11}$/.test(d) ? `+55 ${d.slice(2, 4)} ${d.slice(4, -4)}-${d.slice(-4)}` : '+' + d
/** Situação do recebimento para a tela da empresa (sem segredos). */
export async function situacao(b: any) {
  const x = J<any>(b.data, {}), habilitado = await liberadoGlobal(), canais = habilitado ? canaisDe(x) : { ...PADRAO }, numero = W.numeroWhats(x.zap)
  if (!habilitado) return { habilitado, canais, modo: 'painel' as const } // recurso desligado pelo administrador: nada mais é exposto
  return {
    habilitado, modo: canais.whatsapp ? 'whatsapp' as const : 'painel' as const, canais, numero: fmtNumero(numero), numeroCadastrado: String(x.zap || ''), numeroValido: !!numero,
    // como o pedido chega no WhatsApp: 'automatica' (o sistema envia, provedor configurado pelo administrador) ou 'cliente'
    // (sem provedor: ao concluir o pedido, o cliente é levado ao WhatsApp da empresa com a mensagem pronta)
    whatsappDisponivel: !!numero, entrega: (await W.configurado()) ? 'automatica' as const : 'cliente' as const, provedor: (await W.cfgPublica()).nomeProvedor,
    ultimosEnvios: (await W.ultimosEnvios(Number(b.id), 8)).map((e) => ({ pedido: e.orderId, status: e.status, erro: e.erro, em: e.atualizadoEm, tentativas: e.tentativas })),
  }
}
/** Grava os canais (só esta chave de businesses.data, relida na hora para não desfazer outra alteração). */
export async function salvar(b: any, body: any): Promise<Canais> {
  if (!(await liberadoGlobal())) throw new HttpError(403, RECURSO_OFF, 'recurso_desativado')
  // { modo: 'painel' | 'whatsapp' } (atual) ou { painel, whatsapp } (compatível) — exatamente uma forma
  const modo = body?.modo === 'painel' || body?.modo === 'whatsapp' ? body.modo : body?.painel === true && body?.whatsapp !== true ? 'painel' : body?.whatsapp === true && body?.painel !== true ? 'whatsapp' : ''
  if (!modo) throw new HttpError(400, body?.painel === true && body?.whatsapp === true ? 'Escolha apenas uma forma de receber os pedidos: painel ou WhatsApp.' : 'Escolha onde receber os pedidos: painel ou WhatsApp.', 'invalid', 'modo')
  const painel = modo === 'painel', whatsapp = modo === 'whatsapp'
  const x0 = J<any>(b.data, {})
  if (whatsapp && !W.numeroWhats(x0.zap)) throw new HttpError(400, 'Cadastre o WhatsApp da empresa (com DDD) para receber os pedidos por lá.', 'sem_numero')
  const fresh = await one('SELECT data FROM businesses WHERE id = $1', [b.id]), d = J<any>(fresh?.data, {})
  d.recebimentoPedidos = { painel, whatsapp, atualizadoEm: nowIso() }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { painel, whatsapp }
}

/** Aviso de PEDIDO NOVO (catálogo, atendimento automático, Pix aprovado). Chamado uma vez por pedido e evento. */
export async function avisarNovoPedido(bid: number, orderId: number, aviso: Aviso, opts: { esperarWhatsApp?: boolean } = {}) {
  const b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [bid]); if (!b) return
  const x = J<any>(b.data, {}), canais = await canaisEfetivos(x), owner = Number(b.owner_id), aviso1 = { type: 'order', link: '/x/sua-empresa', ...aviso }
  if (canais.painel) await notify(owner, aviso1)
  else { // painel desligado: as centrais de Lojas Conectadas continuam recebendo o repasse (como notify faria)
    const LC = await import('./lojas-conectadas.js'); const org = await LC.origemDe(aviso.ref).catch(() => null)
    if (org && owner === org.ownerId) await LC.repassarCentrais(org, aviso1).catch((e) => console.error('[lojas]', e?.message))
  }
  if (!canais.whatsapp) return
  // sem provedor de envio: quem leva o pedido ao WhatsApp é o próprio cliente (linkCliente); como não há confirmação de que
  // a mensagem foi enviada, o aviso de reserva vai para o app do dono (nenhum pedido fica sem aviso)
  if (!(await W.configurado())) { await notify(owner, { ...aviso1, body: `${aviso1.body || ''} · enviado pelo cliente no WhatsApp`.replace(/^ · /, '') }); return }
  const o = await one('SELECT id, total, data, created_at FROM orders WHERE id = $1', [orderId]); if (!o) return
  const link = (await import('./publicurl.js')).pub() + '/x/sua-empresa'
  avisos.set(orderId, aviso1) // para levar ao painel, se o WhatsApp falhar
  await W.enfileirar(Number(b.id), orderId, W.numeroWhats(x.zap), W.textoPedido(o, x.empresa, link), opts.esperarWhatsApp)
}
const avisos = new Map<number, any>()
// WhatsApp não confirmado → o pedido vai para o painel (mesmo com o painel desligado), sem duplicar o aviso (mesma ref)
W.aoFalhar(async (orderId) => {
  const o = await one('SELECT id, business_id, total, data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const b = await one('SELECT owner_id, data FROM businesses WHERE id = $1', [o.business_id]); if (!b) return
  const d = J<any>(o.data, {}), env = await W.envioDoPedido(orderId)
  const base = avisos.get(orderId) || { type: 'order', link: '/x/sua-empresa', ref: `order-new:${orderId}`, title: `Novo pedido #${orderId} · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente || ''} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'}` }
  avisos.delete(orderId)
  const motivo = env?.status === 'incerto' ? 'o WhatsApp não confirmou o envio' : 'não foi possível enviar ao WhatsApp'
  await notify(Number(b.owner_id), { ...base, body: `${base.body || ''} · ${motivo}`.replace(/^ · /, '') })
})

/** Pedido feito na forma WhatsApp sem provedor de envio: link para o CLIENTE mandar o pedido ao WhatsApp cadastrado da
 *  empresa, com a mensagem organizada (itens, quantidades, variações, valores e total). null = fluxo do painel/automático. */
export async function linkCliente(bid: number, orderId: number): Promise<{ url: string; numero: string } | null> {
  const b = await one('SELECT id, data FROM businesses WHERE id = $1', [bid]); if (!b) return null
  const x = J<any>(b.data, {}); if (!(await canaisEfetivos(x)).whatsapp || (await W.configurado())) return null
  const para = W.numeroWhats(x.zap), o = await one('SELECT id, total, data, created_at FROM orders WHERE id = $1 AND business_id = $2', [orderId, bid])
  if (!para || !o) return null
  return { url: `https://wa.me/${para}?text=${encodeURIComponent(W.textoPedido(o, x.empresa, ''))}`, numero: fmtNumero(para) }
}
