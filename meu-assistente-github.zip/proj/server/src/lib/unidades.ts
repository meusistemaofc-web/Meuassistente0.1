// Motor DETERMINÍSTICO de quantidades (sem IA): conversões de unidades e continuação de contas pela conversa.
// Complementa lib/math.ts (aritmética). Segue 6 passos: identifica a operação, os valores e as unidades, resolve por
// fator exato, VALIDA (conversão inversa) e devolve uma frase natural ("4 dias têm 96 horas.").
//  • conversões: tempo (milissegundo…semana), comprimento (mm…km), massa (mg…tonelada), volume (ml, litro);
//  • continuação: "E dois?", "Na verdade, 5 dias.", "Agora o dobro.", "E em minutos?" usam a ÚLTIMA conta da conversa
//    (uma mensagem de outro assunto no meio encerra o fio: a conta antiga não é reaproveitada);
//  • conferência: conferirTexto() corrige uma conversão errada escrita pela IA ("2 dias têm 24 horas").
// Fora do escopo de propósito (dependem de calendário, fuso ou regra especial): mês, ano, década, datas, fusos e horário de
// verão — ficam com a IA, sem cálculo simplista.
import { solveMath, fmtNum } from './math.js'

type Dim = 'tempo' | 'comprimento' | 'massa' | 'volume'
interface Unidade { id: string; dim: Dim; fator: number; sing: string; plur: string; fem: boolean; alias: string[] }
const U: Unidade[] = [
  { id: 'ms', dim: 'tempo', fator: 0.001, sing: 'milissegundo', plur: 'milissegundos', fem: false, alias: ['milissegundos', 'milissegundo', 'ms'] },
  { id: 's', dim: 'tempo', fator: 1, sing: 'segundo', plur: 'segundos', fem: false, alias: ['segundos', 'segundo', 'seg', 's'] },
  { id: 'min', dim: 'tempo', fator: 60, sing: 'minuto', plur: 'minutos', fem: false, alias: ['minutos', 'minuto', 'min'] },
  { id: 'h', dim: 'tempo', fator: 3600, sing: 'hora', plur: 'horas', fem: true, alias: ['horas', 'hora', 'hrs', 'hr', 'h'] },
  { id: 'd', dim: 'tempo', fator: 86400, sing: 'dia', plur: 'dias', fem: false, alias: ['dias', 'dia'] },
  { id: 'sem', dim: 'tempo', fator: 604800, sing: 'semana', plur: 'semanas', fem: true, alias: ['semanas', 'semana'] },
  { id: 'mm', dim: 'comprimento', fator: 0.001, sing: 'milímetro', plur: 'milímetros', fem: false, alias: ['milímetros', 'milimetros', 'milímetro', 'milimetro', 'mm'] },
  { id: 'cm', dim: 'comprimento', fator: 0.01, sing: 'centímetro', plur: 'centímetros', fem: false, alias: ['centímetros', 'centimetros', 'centímetro', 'centimetro', 'cm'] },
  { id: 'm', dim: 'comprimento', fator: 1, sing: 'metro', plur: 'metros', fem: false, alias: ['metros', 'metro', 'm'] },
  { id: 'km', dim: 'comprimento', fator: 1000, sing: 'quilômetro', plur: 'quilômetros', fem: false, alias: ['quilômetros', 'quilometros', 'quilômetro', 'quilometro', 'km'] },
  { id: 'mg', dim: 'massa', fator: 0.001, sing: 'miligrama', plur: 'miligramas', fem: false, alias: ['miligramas', 'miligrama', 'mg'] },
  { id: 'g', dim: 'massa', fator: 1, sing: 'grama', plur: 'gramas', fem: false, alias: ['gramas', 'grama', 'g'] },
  { id: 'kg', dim: 'massa', fator: 1000, sing: 'quilo', plur: 'quilos', fem: false, alias: ['quilogramas', 'quilograma', 'quilos', 'quilo', 'kg'] },
  { id: 't', dim: 'massa', fator: 1e6, sing: 'tonelada', plur: 'toneladas', fem: true, alias: ['toneladas', 'tonelada'] },
  { id: 'ml', dim: 'volume', fator: 0.001, sing: 'mililitro', plur: 'mililitros', fem: false, alias: ['mililitros', 'mililitro', 'ml'] },
  { id: 'l', dim: 'volume', fator: 1, sing: 'litro', plur: 'litros', fem: false, alias: ['litros', 'litro', 'l'] },
]
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
const ALIAS = U.flatMap((u) => u.alias.map((a) => ({ a, u }))).sort((x, y) => y.a.length - x.a.length)
const UN = `(${ALIAS.map((x) => esc(x.a)).join('|')})`
const unidade = (a: string) => ALIAS.find((x) => x.a === String(a || '').toLowerCase())?.u || null

// números por extenso (até milhares, com "e": "vinte e cinco", "cento e vinte"); "meia/meio" = 0,5
const NUM: Record<string, number> = { zero: 0, um: 1, uma: 1, dois: 2, duas: 2, 'três': 3, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, onze: 11, doze: 12, treze: 13, quatorze: 14, catorze: 14, quinze: 15, dezesseis: 16, dezessete: 17, dezoito: 18, dezenove: 19, vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50, sessenta: 60, setenta: 70, oitenta: 80, noventa: 90, cem: 100, cento: 100, duzentos: 200, duzentas: 200, trezentos: 300, trezentas: 300, quatrocentos: 400, quinhentos: 500, seiscentos: 600, setecentos: 700, oitocentos: 800, novecentos: 900, mil: 1000, meia: 0.5, meio: 0.5 }
const PAL = Object.keys(NUM).sort((a, b) => b.length - a.length).map(esc).join('|')
const QTD = `(\\d+(?:[.,]\\d+)?|(?:${PAL})(?:\\s+e\\s+(?:${PAL}))*)`
function valorDe(q: string): number | null {
  const s = String(q || '').trim().toLowerCase()
  if (/^\d/.test(s)) { const n = Number(s.replace(/\.(?=\d{3}\b)/g, '').replace(',', '.')); return isFinite(n) ? n : null }
  let total = 0, atual = 0
  for (const w of s.split(/\s+e\s+|\s+/)) { const v = NUM[w]; if (v === undefined) return null; if (v === 1000) { total += (atual || 1) * 1000; atual = 0 } else atual += v }
  return total + atual
}

export interface Conversao { tipo: 'conversao'; n: number; nTexto: string; de: Unidade; para: Unidade; valor: number }
export interface Conta { tipo: 'conta'; valor: number; expr: string }
type Estado = Conversao | Conta
export interface Resultado { expr: string; valor: number; texto: string; resposta: string; motivo: string; validado: boolean }

const BLOQUEIO = /\b(fuso|hor[aá]rio de ver[aã]o|calend[aá]rio|bissext\w*|m[eê]s|meses|anos?|d[eé]cadas?|s[eé]culos?|at[eé] (o )?dia|de hoje|daqui a|entre (os dias|o dia)|\d{1,2}\/\d{1,2})\b/i
const LIMPA = (t: string) => String(t || '').toLowerCase().replace(/[“”"']/g, '').replace(/^\s*(digo|tipo|ent[aã]o|ok|bom|olha|me diz|me diga|me fala|sabe me dizer|voc[eê] sabe)[,:]?\s+/, '').replace(/\s+/g, ' ').trim()
const plural = (n: number) => Math.abs(n) >= 2
const rotulo = (u: Unidade, n: number) => (plural(n) ? u.plur : u.sing)

/** Lê uma pergunta de conversão completa ("quantas horas tem 4 dias?", "dois dias tem quantas horas?", "3 h em minutos"). */
export function lerConversao(texto: string): Conversao | null {
  const s = LIMPA(texto); if (!s || BLOQUEIO.test(s) || s.length > 140) return null
  const V = '(?:tem|têm|teem|ha|há|cabem|cabe|d[aá]|d[aã]o|s[aã]o|[eé]|equivalem a|equivale a|correspondem a|corresponde a|existem|possui|possuem|fazem|faz)'
  const pad: [RegExp, (m: RegExpMatchArray) => [string | undefined, string, string]][] = [
    [new RegExp(`^(?:e\\s+)?quant[oa]s?\\s+${UN}\\s+(?:${V}\\s+)?(?:em\\s+)?(?:${QTD}\\s+)?${UN}\\s*[?.!]*$`, 'u'), (m) => [m[2], m[3], m[1]]],
    [new RegExp(`^(?:e\\s+)?${QTD}\\s+${UN}\\s+(?:${V}\\s+)?(?:quant[oa]s?|qtos|qtas)\\s+${UN}\\s*[?.!]*$`, 'u'), (m) => [m[1], m[2], m[3]]],
    [new RegExp(`^(?:(?:quanto (?:[eé]|d[aá]|fica)|converta|converter|converte|transforme|transformar|passe|passar|calcule)\\s+)?${QTD}\\s+${UN}\\s+(?:em|para|pra|pro)\\s+${UN}\\s*[?.!]*$`, 'u'), (m) => [m[1], m[2], m[3]]],
  ]
  for (const [re, f] of pad) {
    const m = s.match(re); if (!m) continue
    const [q, a, b] = f(m), de = unidade(a), para = unidade(b), n = q === undefined ? 1 : valorDe(q)
    if (!de || !para || de.dim !== para.dim || de.id === para.id || n === null || n < 0) return null
    return { tipo: 'conversao', n, nTexto: q === undefined ? (de.fem ? 'uma' : 'um') : q, de, para, valor: n * de.fator / para.fator }
  }
  return null
}

/** Resolve a conversão, VALIDA pela conta inversa e monta a frase. */
export function responder(c: Conversao): Resultado | null {
  const v = Math.round(c.n * c.de.fator / c.para.fator * 1e9) / 1e9
  const volta = v * c.para.fator / c.de.fator, validado = Math.abs(volta - c.n) <= 1e-9 * Math.max(1, Math.abs(c.n))
  if (!isFinite(v) || !validado) return null
  const nTxt = /^\d/.test(c.nTexto) ? fmtNum(c.n) : c.nTexto.replace(/^(um|dois)$/i, (w) => (c.de.fem ? (w === 'um' ? 'uma' : 'duas') : w))
  const sujeito = `${nTxt} ${rotulo(c.de, c.n)}`, contem = c.de.fator >= c.para.fator, verbo = contem ? (plural(c.n) ? 'têm' : 'tem') : (plural(c.n) ? 'equivalem a' : 'equivale a') // "4 dias têm 96 horas"; "250 gramas equivalem a 0,25 quilo"
  const fator = c.de.fator >= c.para.fator ? c.de.fator / c.para.fator : c.para.fator / c.de.fator, op = c.de.fator >= c.para.fator ? '×' : '÷'
  const resposta = `${sujeito.charAt(0).toUpperCase() + sujeito.slice(1)} ${verbo} ${fmtNum(v)} ${rotulo(c.para, v)}.`
  return { expr: `${fmtNum(c.n)} ${op} ${fmtNum(fator)}`, valor: v, texto: `${fmtNum(v)} ${rotulo(c.para, v)}`, resposta, motivo: `conversão ${c.de.id}→${c.para.id}`, validado }
}

/* ---------- continuação pela conversa ---------- */
const MULT: Record<string, number> = { 'o dobro': 2, 'a metade': 0.5, 'o triplo': 3, 'o quádruplo': 4, 'o quadruplo': 4 }
const ABRE = '(?:e|e se for(?:em)?|e pra|e para|e com|e no caso de|mas e|na verdade|digo|quer dizer|ou melhor|corrigindo|agora|e agora|ent[aã]o|e)'
/** A mensagem tem forma de continuação curta de uma conta ("E dois?", "Na verdade, 5 dias.", "Agora o dobro.")? */
export function formaDeContinuacao(texto: string) { return !!aplicar(texto, { tipo: 'conta', valor: 1, expr: '1' }, true) || !!aplicar(texto, { tipo: 'conversao', n: 1, nTexto: '1', de: U[4], para: U[3], valor: 24 }, true) }

function aplicar(texto: string, e: Estado, soForma = false): Estado | null {
  const s = LIMPA(texto).replace(/[,;]/g, ' ').replace(/\s+/g, ' ').trim()
  if (s.split(' ').length > 7) return null
  // "o dobro", "a metade"…
  const mm = s.match(new RegExp(`^(?:${ABRE}\\s+)?(o dobro|a metade|o triplo|o qu[aá]druplo)(?:\\s+disso)?\\s*[?.!]*$`, 'u'))
  if (mm) { const k = MULT[mm[1].replace('á', 'a')] ?? MULT[mm[1]]; if (e.tipo === 'conta') return { tipo: 'conta', valor: e.valor * k, expr: `${fmtNum(e.valor)} × ${fmtNum(k)}` }; const n = e.n * k; return { ...e, n, nTexto: fmtNum(n), valor: n * e.de.fator / e.para.fator } }
  // nova quantidade (com ou sem unidade): "e dois?", "na verdade, 5 dias", "e 3 semanas?"
  const mq = s.match(new RegExp(`^(?:${ABRE}\\s+)?(?:(?:e|s[oó]|apenas)\\s+)?${QTD}(?:\\s+${UN})?\\s*[?.!]*$`, 'u'))
  if (mq && e.tipo === 'conversao') {
    const n = valorDe(mq[1]); if (n === null) return null
    const u = mq[2] ? unidade(mq[2]) : e.de; if (!u || u.dim !== e.de.dim || u.id === e.para.id) return null
    return { tipo: 'conversao', n, nTexto: mq[1], de: u, para: e.para, valor: n * u.fator / e.para.fator }
  }
  // outra unidade de destino: "e em minutos?", "agora em segundos"
  const md = s.match(new RegExp(`^(?:${ABRE}\\s+)?(?:em|para|pra)\\s+${UN}\\s*[?.!]*$`, 'u'))
  if (md && e.tipo === 'conversao') { const u = unidade(md[1]); if (!u || u.dim !== e.de.dim || u.id === e.de.id) return null; return { ...e, para: u, valor: e.n * e.de.fator / u.fator } }
  // operação sobre o resultado anterior: "e vezes 3?", "agora mais 10", "dividido por 4"
  const mo = s.match(/^(?:(?:e|agora|e agora|entao|então)\s+)?(vezes|mais|menos|dividido por|multiplicado por)\s+(\d+(?:[.,]\d+)?)\s*[?.!]*$/)
  if (mo && !soForma) { const base = e.tipo === 'conta' ? e.valor : e.valor; const r: any = solveMath(`${String(base).replace('.', ',')} ${mo[1]} ${mo[2]}`); if (r && !r.erro) return { tipo: 'conta', valor: r.valor, expr: `${fmtNum(base)} ${mo[1]} ${mo[2]}` } }
  else if (mo && soForma) return { tipo: 'conta', valor: 0, expr: '' }
  return null
}

type Msg = { role: string; content: string | null }
/** Estado da última conta da conversa (só as mensagens da pessoa; um assunto diferente no meio encerra o fio). */
export function ultimaConta(hist: Msg[]): Estado | null {
  let e: Estado | null = null
  for (const m of hist.filter((x) => x.role === 'user' && x.content).slice(-6)) {
    const t = String(m.content), c = lerConversao(t)
    if (c) { e = c; continue }
    const r: any = solveMath(t); if (r && !r.erro) { e = { tipo: 'conta', valor: r.valor, expr: r.expr }; continue }
    const ap: Estado | null = e ? aplicar(t, e) : null
    e = ap // outra mensagem (outro assunto): o fio da conta acaba aqui
  }
  return e
}

/** Pergunta de quantidade desta mensagem — completa ou continuação da última conta da conversa. */
export function resolverQuantidade(texto: string, hist: Msg[] = []): (Resultado & { continuacao: boolean }) | null {
  const c = lerConversao(texto)
  if (c) { const r = responder(c); return r ? { ...r, continuacao: false } : null }
  const ant = ultimaConta(hist); if (!ant) return null
  const e = aplicar(texto, ant); if (!e) return null
  if (e.tipo === 'conversao') { const r = responder(e); return r ? { ...r, continuacao: true, motivo: r.motivo + ' (continuação da conta anterior)' } : null }
  return { expr: e.expr, valor: e.valor, texto: fmtNum(e.valor), resposta: `${e.expr.replace(/\*/g, '×')} = **${fmtNum(e.valor)}**`, motivo: 'operação sobre o resultado anterior', validado: true, continuacao: true }
}

/** Confere conversões que a IA escreveu ("2 dias têm 24 horas") e corrige o número errado. */
export function conferirTexto(texto: string): { texto: string; corrigidas: number } {
  let corrigidas = 0
  const re = new RegExp(`(?<![\\p{L}\\d])${QTD}\\s+${UN}\\s+(tem|têm|equivalem a|equivale a|correspondem a|corresponde a|são|=)\\s+(\\d+(?:[.,]\\d+)*)\\s+${UN}(?![\\p{L}])`, 'giu')
  const out = String(texto || '').replace(re, (todo, q, a, v, num, b) => {
    const de = unidade(a), para = unidade(b), n = valorDe(q)
    if (!de || !para || de.dim !== para.dim || n === null || BLOQUEIO.test(todo)) return todo
    const certo = Math.round(n * de.fator / para.fator * 1e9) / 1e9, dito = Number(String(num).replace(/\.(?=\d{3}\b)/g, '').replace(',', '.'))
    if (!isFinite(dito) || Math.abs(dito - certo) <= 1e-6 * Math.max(1, certo)) return todo
    corrigidas++; return todo.replace(new RegExp(`${esc(num)}(\\s+)${esc(b)}$`, 'i'), `${fmtNum(certo)}$1${rotulo(para, certo)}`)
  })
  return { texto: out, corrigidas }
}
