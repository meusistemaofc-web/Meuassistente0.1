// Logo e capa da empresa por ENDEREÇO (com cache no navegador) em vez de embutidos no JSON.
// Causa da lentidão ao trocar de opção no menu da empresa: /api/v2/ads/mine (chamado a cada troca) e /api/v2/empresas/contexto
// mandavam o logo e a capa em base64 dentro do JSON — com imagens reais, ~0,5 MB por chamada, baixados de novo a cada toque.
// Agora essas listas trazem "/api/v2/ads/:id/imagem/logo?h=<hash>" e a imagem é baixada uma vez e reaproveitada pelo cache
// (o hash muda quando a imagem muda). Nada muda no banco; salvar um formulário com o endereço não altera a imagem (o
// servidor só aceita data:image/ como imagem nova).
import { createHash } from 'node:crypto'
import type { Ctx } from './http.js'
import { fail } from './http.js'
import { one, J } from '../db/index.js'
import { requireUser } from './session.js'

const hash = (f: string) => createHash('sha1').update(`${f.length}|${f.slice(0, 4096)}|${f.slice(f.length >> 1, (f.length >> 1) + 2048)}|${f.slice(-4096)}`).digest('hex').slice(0, 12)
/** data:image/… → endereço com hash; qualquer outro valor (vazio, URL externa) fica como está. */
export function refImagem(bid: number, campo: 'logo' | 'capa', v: any) {
  return typeof v === 'string' && /^data:image\//i.test(v) ? `/api/v2/ads/${bid}/imagem/${campo}?h=${hash(v)}` : v
}
export async function adImagemGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id), campo = String(ctx.params.campo)
  if (!['logo', 'capa'].includes(campo) || !Number.isInteger(id)) fail(404, 'Imagem não encontrada.', 'not_found')
  const b = await one('SELECT id, owner_id, status, data FROM businesses WHERE id = $1', [id])
  if (!b || b.status === 'lixeira') fail(404, 'Imagem não encontrada.', 'not_found')
  // dono, conta com vínculo válido ou empresa publicada (logo e capa já são públicos no catálogo)
  if (Number(b!.owner_id) !== Number(u.id) && b!.status !== 'ativo') {
    const V = await import('./vinculos.js'); const vs = await V.vinculadasValidas(Number(u.id)).catch(() => [] as any[])
    if (!vs.some((x: any) => Number(x.id) === id)) fail(404, 'Imagem não encontrada.', 'not_found')
  }
  const f = String(J<any>(b!.data, {})[campo] || ''), m = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i.exec(f)
  if (!m) { if (/^https?:\/\//.test(f)) return { _binary: true, status: 302, headers: { Location: f } }; fail(404, 'Imagem não encontrada.', 'not_found') }
  return { _binary: true, mime: m![1], data: Buffer.from(m![2], 'base64'), headers: { 'Cache-Control': 'private, max-age=31536000, immutable', ETag: `"${hash(f)}"` } }
}
