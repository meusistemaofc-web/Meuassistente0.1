// Validade dos Pix gerados (Administração → Mercado Pago → Validade do Pix).
import { getConfig } from './settings.js'
export async function pixExpiry() {
  const min = Math.min(1440, Math.max(5, Number((await getConfig<any>('pix', {})).expiraMin) || 30))
  const at = new Date(Date.now() + min * 60_000)
  const br = new Date(at.getTime() - 3 * 3600_000).toISOString().replace('Z', '-03:00') // horário de Brasília, formato aceito pelo Mercado Pago
  return { iso: br, at: at.toISOString(), min }
}
export const pixValid = (p: any) => !!(p && p.qr && (!p.expiresAt || Date.parse(p.expiresAt) > Date.now() + 15_000))

// CHAVE PIX DA EMPRESA (recebimento direto dos clientes) — validação e formato padronizado dos 4 tipos do Banco Central:
// CPF/CNPJ (com dígitos verificadores), e-mail, telefone (+55DDDNÚMERO) e chave aleatória (EVP, formato UUID).
// Usada por Sua empresa → Entrega e pagamento (rota oficial PUT /api/v2/ads/:id). Só valida e formata; nunca é usada nas
// cobranças de anúncios da plataforma (essas seguem o checkout da plataforma).
export type TipoChavePix = 'cpf_cnpj' | 'email' | 'telefone' | 'aleatoria'
export const TIPOS_CHAVE_PIX: TipoChavePix[] = ['cpf_cnpj', 'email', 'telefone', 'aleatoria']

function dvOk(d: string, pesos: number[]) {
  const soma = pesos.reduce((s, p, i) => s + Number(d[i]) * p, 0), r = soma % 11
  return (r < 2 ? 0 : 11 - r) === Number(d[pesos.length])
}
export function cpfValido(v: string) {
  const d = String(v || '').replace(/\D/g, ''); if (d.length !== 11 || /^(\d)\1+$/.test(d)) return false
  const s = (n: number) => { let t = 0; for (let i = 0; i < n; i++) t += Number(d[i]) * (n + 1 - i); const r = (t * 10) % 11; return (r === 10 ? 0 : r) === Number(d[n]) }
  return s(9) && s(10)
}
export function cnpjValido(v: string) {
  const d = String(v || '').replace(/\D/g, ''); if (d.length !== 14 || /^(\d)\1+$/.test(d)) return false
  return dvOk(d, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]) && dvOk(d, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])
}
/** Descobre o tipo de uma chave já salva (empresas antigas guardavam só o texto). */
export function tipoProvavel(chave: string): TipoChavePix | null {
  const c = String(chave || '').trim(); if (!c) return null
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(c)) return 'aleatoria'
  if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(c)) return 'email'
  const d = c.replace(/\D/g, '')
  if (/^\+/.test(c) || (d.length >= 12 && d.startsWith('55') && !cnpjValido(d))) return 'telefone'
  if (cpfValido(d) || cnpjValido(d)) return 'cpf_cnpj'
  if (d.length === 10 || d.length === 11) return 'telefone'
  return null
}
/** Valida e devolve a chave no formato padrão; `erro` explica o que corrigir. */
export function normalizarChavePix(tipo: string, chave: string): { ok: true; tipo: TipoChavePix; chave: string } | { ok: false; erro: string } {
  const c = String(chave || '').trim()
  if (!c) return { ok: false, erro: 'Informe a chave Pix.' }
  switch (tipo) {
    case 'cpf_cnpj': { const d = c.replace(/\D/g, ''); if (d.length === 11) return cpfValido(d) ? { ok: true, tipo, chave: d } : { ok: false, erro: 'CPF inválido: confira os 11 números.' }; if (d.length === 14) return cnpjValido(d) ? { ok: true, tipo, chave: d } : { ok: false, erro: 'CNPJ inválido: confira os 14 números.' }; return { ok: false, erro: 'Informe um CPF (11 números) ou um CNPJ (14 números).' } }
    case 'email': { const e = c.toLowerCase(); return /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 77 ? { ok: true, tipo, chave: e } : { ok: false, erro: 'E-mail inválido para chave Pix.' } }
    case 'telefone': { let d = c.replace(/\D/g, ''); if (d.length === 10 || d.length === 11) d = '55' + d; if (!/^55\d{10,11}$/.test(d)) return { ok: false, erro: 'Telefone inválido: use DDD + número (ex.: (11) 98888-7777).' }; return { ok: true, tipo, chave: '+' + d } }
    case 'aleatoria': { const k = c.toLowerCase(); return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(k) ? { ok: true, tipo, chave: k } : { ok: false, erro: 'Chave aleatória inválida: são 32 letras/números no formato 8-4-4-4-12 (copie do app do banco).' } }
    default: return { ok: false, erro: 'Escolha o tipo da chave: CPF/CNPJ, e-mail, telefone ou chave aleatória.' }
  }
}
