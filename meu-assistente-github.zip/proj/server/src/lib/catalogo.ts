// Ofertas e variações de produtos (cor, tamanho, modelo…), preço de destaque, linhas de pedido e estoque.
// Regras centrais usadas pelo cadastro, pela loja, pelo agente de atendimento e pelos pedidos:
// • preço aplicado = preço promocional quando a oferta está ativa (sempre > 0 e < preço normal); senão o preço normal;
// • destaque do produto = MENOR preço aplicado entre as variações DISPONÍVEIS (disponível e com estoque); a foto do destaque é
//   a da variação escolhida; sem nenhuma disponível, o produto aparece indisponível e nunca como oferta;
// • o preço do pedido é sempre recalculado aqui no servidor (o navegador só manda produto, variação, opções e quantidade);
// • o pedido guarda uma "fotografia" do item (variação, atributos, imagem, preço normal, preço aplicado, promoção) — mudar
//   preços depois não altera pedidos já feitos;
// • estoque (quando controlado) é debitado de forma atômica (UPDATE … WHERE stock >= qtd) e devolvido uma única vez.
import { q, one, J, nowIso, db } from '../db/index.js'
import { fail, HttpError } from './http.js'
import { createHash } from 'node:crypto'

export const MAX_VARIANTES = 40, MAX_FOTOS_VAR = 4, ATRIBUTOS = [['cor', 'Cor'], ['tamanho', 'Tamanho'], ['modelo', 'Modelo']] as const
const r2 = (n: number) => Math.round(n * 100) / 100
const s = (v: any, n: number) => String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n)
const nrm = (v: any) => String(v ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()

/** Preço normal, preço aplicado, se está em oferta e o percentual de desconto (inteiro). */
export function precos(normal: number, oferta: any) {
  const n = r2(Number(normal) || 0), pr = oferta && oferta.ativo ? r2(Number(oferta.preco) || 0) : 0
  const em = pr > 0 && pr < n
  return { normal: n, aplicado: em ? pr : n, emOferta: em, desconto: em ? Math.round((1 - pr / n) * 100) : 0 }
}
/** Valida a oferta enviada pelo formulário (null = sem oferta). */
export function validarOferta(normal: number, o: any, rotulo = ''): { ativo: true; preco: number } | null {
  if (!o || !o.ativo) return null
  const pr = r2(Number(o.preco))
  if (!(pr > 0)) fail(400, `${rotulo}Informe o preço promocional (maior que zero).`, 'invalid', 'oferta')
  if (!(pr < r2(Number(normal) || 0))) fail(400, `${rotulo}O preço promocional deve ser menor que o preço normal.`, 'invalid', 'oferta')
  return { ativo: true, preco: pr }
}
/* ---------- Preço por quantidade (desconto progressivo) ----------
   Opcional por produto SEM variações: products.data.precoQtd = { ativo, faixas: [{ qtd, preco }] } — "a partir de qtd unidades,
   preco cada". A faixa de 1 unidade é o próprio preço do produto. Regras (as mesmas no cadastro, na loja, no carrinho e no pedido):
   • faixas com quantidade crescente (2 a 999) e preço decrescente, sempre > 0 e menor que o preço normal (no máximo 6 faixas);
   • a quantidade que conta é a soma do MESMO produto no pedido (linhas com observações diferentes somam juntas);
   • vale o menor preço entre a oferta (se houver) e a faixa alcançada — nunca os dois somados;
   • desligado (ou produto com variações / serviço): preço normal, exatamente como antes. As faixas ficam guardadas para religar. */
export const MAX_FAIXAS = 6, FAIXA_QTD_MAX = 999
export type Faixa = { qtd: number; preco: number }
/** Valida o que o formulário enviou. `undefined` = não mexe (mantém o salvo); devolve null quando não há nada a guardar. */
export function validarFaixas(normal: number, e: any): { ativo: boolean; faixas: Faixa[] } | null {
  if (!e || typeof e !== 'object') return null
  const ativo = e.ativo === true, n = r2(Number(normal) || 0)
  const brutas = (Array.isArray(e.faixas) ? e.faixas : []).filter((f: any) => f && (String(f.qtd ?? '').trim() !== '' || String(f.preco ?? '').trim() !== ''))
  if (brutas.length > MAX_FAIXAS) fail(400, `Use no máximo ${MAX_FAIXAS} faixas de preço por quantidade.`, 'invalid', 'precoQtd')
  const faixas: Faixa[] = []
  for (const [i, f] of brutas.entries()) {
    const rot = `Faixa ${i + 1}: `, qtd = Number(f.qtd), preco = r2(Number(f.preco))
    if (!(Number.isInteger(qtd) && qtd >= 2 && qtd <= FAIXA_QTD_MAX)) { if (!ativo) continue; fail(400, `${rot}a quantidade mínima deve ser um número inteiro de 2 a ${FAIXA_QTD_MAX} (1 unidade já usa o preço normal).`, 'invalid', 'precoQtd') }
    if (!(preco > 0)) { if (!ativo) continue; fail(400, `${rot}informe o preço por unidade (maior que zero).`, 'invalid', 'precoQtd') }
    if (!(preco < n)) { if (!ativo) continue; fail(400, `${rot}o preço por unidade deve ser menor que o preço normal (R$ ${n.toFixed(2).replace('.', ',')}).`, 'invalid', 'precoQtd') }
    faixas.push({ qtd, preco })
  }
  faixas.sort((a, b) => a.qtd - b.qtd)
  if (!ativo) { // desligado: só guarda o que é coerente (para religar depois), sem travar o cadastro
    const ok: Faixa[] = []; for (const f of faixas) if (!ok.length || (f.qtd > ok[ok.length - 1].qtd && f.preco < ok[ok.length - 1].preco)) ok.push(f)
    return ok.length ? { ativo: false, faixas: ok } : null
  }
  for (let i = 1; i < faixas.length; i++) {
    if (faixas[i].qtd === faixas[i - 1].qtd) fail(400, `Há duas faixas para ${faixas[i].qtd} unidades. Use quantidades diferentes.`, 'invalid', 'precoQtd')
    if (!(faixas[i].preco < faixas[i - 1].preco)) fail(400, `A faixa de ${faixas[i].qtd} unidades precisa ter preço menor que a de ${faixas[i - 1].qtd} unidades.`, 'invalid', 'precoQtd')
  }
  if (ativo && !faixas.length) fail(400, 'Adicione pelo menos uma faixa (ex.: a partir de 5 unidades) ou desligue o preço por quantidade.', 'invalid', 'precoQtd')
  return { ativo: true, faixas }
}
/** Faixas que valem agora (produto simples com o recurso ligado). Confere de novo as regras, para dados antigos/importados. */
export function faixasAtivas(p: any): Faixa[] {
  const c = p?.precoQtd; if (!c || !c.ativo || p.tipo === 'servico' || (p.variantes || []).length) return []
  const n = Number(p.preco) || 0, out: Faixa[] = []
  for (const f of (Array.isArray(c.faixas) ? c.faixas : []).map((x: any) => ({ qtd: Math.floor(Number(x.qtd)), preco: r2(Number(x.preco)) })).sort((a: Faixa, b: Faixa) => a.qtd - b.qtd)) {
    if (f.qtd >= 2 && f.preco > 0 && f.preco < n && (!out.length || (f.qtd > out[out.length - 1].qtd && f.preco < out[out.length - 1].preco))) out.push(f)
  }
  return out.slice(0, MAX_FAIXAS)
}
/** Faixa alcançada com `qtd` unidades (a de maior quantidade que não passa de qtd), ou null. */
export const faixaPara = (fs: Faixa[], qtd: number) => fs.reduce<Faixa | null>((a, f) => (qtd >= f.qtd ? f : a), null)
/** Tabela pública: 1 unidade (preço aplicado de hoje, com oferta) + faixas que realmente baixam o preço, com o % sobre o preço normal. */
export function tabelaQtd(p: any) {
  const fs = faixasAtivas(p); if (!fs.length) return []
  const pr = precos(p.preco, p.oferta), uteis = fs.filter((f) => f.preco < pr.aplicado)
  if (!uteis.length) return []
  return [{ qtd: 1, preco: pr.aplicado, desconto: pr.desconto }, ...uteis.map((f) => ({ qtd: f.qtd, preco: f.preco, desconto: Math.round((1 - f.preco / pr.normal) * 100) }))]
}

const estoqueIn = (v: any) => { if (v === null || v === undefined || v === '') return null; const n = Math.floor(Number(v)); if (!(n >= 0 && n <= 1_000_000)) fail(400, 'Estoque inválido: use um número inteiro (0 ou mais) ou deixe em branco para não controlar.', 'invalid', 'estoque'); return n }
export { estoqueIn as validarEstoque }

export interface Variante { id: number; nome: string; cor: string; tamanho: string; modelo: string; fotos: string[]; thumb: string | null; preco: number; oferta: { ativo: boolean; preco: number } | null; disponivel: boolean; estoque: number | null; ordem: number }
const varOut = (r: any): Variante => { const d = J<any>(r.data, {}); return { id: Number(r.id), nome: d.nome || '', cor: d.cor || '', tamanho: d.tamanho || '', modelo: d.modelo || '', fotos: Array.isArray(d.fotos) ? d.fotos : [], thumb: d.thumb || null, preco: Number(d.preco) || 0, oferta: d.oferta || null, disponivel: d.disponivel !== false, estoque: r.stock == null ? null : Number(r.stock), ordem: Number(r.position) || 0 } }
export const rotuloVariante = (v: { nome?: string; cor?: string; tamanho?: string; modelo?: string }) => v.nome || [v.cor, v.tamanho, v.modelo].filter(Boolean).join(' · ')
export const atributosDe = (v: any) => ATRIBUTOS.filter(([k]) => v[k]).map(([k, l]) => ({ chave: k, nome: l, valor: v[k] as string }))
const temEstoque = (e: number | null, qtd = 1) => e == null || e >= qtd
/** Recusa por falta de estoque com o limite atual do item (o app usa `info` para ajustar o carrinho). */
export function semEstoque(nome: string, disponivel: number, item: { pid: number; vid?: number | null }): never {
  const n = Math.max(0, Math.floor(Number(disponivel) || 0))
  const e: any = new HttpError(409, n > 0 ? `${nome}: ${n === 1 ? 'só resta 1 unidade' : `só restam ${n} unidades`} em estoque.` : `${nome} está esgotado.`, 'sem_estoque')
  e.extra = { pid: Number(item.pid), vid: item.vid ? Number(item.vid) : null, disponivel: n }
  throw e
}

/** Variações de vários produtos numa consulta só. */
export async function variantesDe(ids: number[]): Promise<Map<number, Variante[]>> {
  const m = new Map<number, Variante[]>(); if (!ids.length) return m
  const rows = await q(`SELECT * FROM product_variants WHERE product_id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY product_id, position, id`, ids)
  for (const r of rows as any[]) { const k = Number(r.product_id); m.set(k, [...(m.get(k) || []), varOut(r)]) }
  return m
}
/** Colunas SQL que trazem o JSON SEM as fotos e uma impressão digital de cada foto (tamanho + final), calculadas no próprio
 *  banco — a lista da aba Produtos não lê os ~300 KB de cada foto. SQLite (texto JSON) e PostgreSQL (JSONB). */
export function colunasSemFotos(kind: 'postgres' | 'sqlite', max: number): string {
  const fp = (i: number) => kind === 'postgres'
    ? `length(data->'fotos'->>${i}) || ':' || right(data->'fotos'->>${i}, 96) AS fp${i}`
    : `length(json_extract(data, '$.fotos[${i}]')) || ':' || substr(json_extract(data, '$.fotos[${i}]'), -96) AS fp${i}`
  const semFotos = kind === 'postgres' ? `(data - 'fotos') AS data` : `json_remove(data, '$.fotos') AS data`
  return [semFotos, ...Array.from({ length: max }, (_, i) => fp(i))].join(', ')
}
export const impressoes = (r: any, max: number): string[] => Array.from({ length: max }, (_, i) => r['fp' + i]).filter((x) => x != null && x !== '').map(String)
/** Variações sem as fotos (cada foto vira a sua impressão digital): para a lista leve da empresa. */
export async function variantesLeves(ids: number[], kind: 'postgres' | 'sqlite'): Promise<Map<number, Variante[]>> {
  const m = new Map<number, Variante[]>(); if (!ids.length) return m
  const rows = await q(`SELECT id, product_id, position, stock, ${colunasSemFotos(kind, MAX_FOTOS_VAR)} FROM product_variants WHERE product_id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')}) ORDER BY product_id, position, id`, ids)
  for (const r of rows as any[]) { const k = Number(r.product_id), v = varOut(r); v.fotos = impressoes(r, MAX_FOTOS_VAR); m.set(k, [...(m.get(k) || []), v]) }
  return m
}
/** Visão pública de uma variação (sem o número exato do estoque: só "últimas unidades" quando está acabando). */
function varPublica(v: Variante, dono: boolean) {
  const p = precos(v.preco, v.oferta), disp = v.disponivel && temEstoque(v.estoque)
  return { id: v.id, nome: v.nome, rotulo: rotuloVariante(v), cor: v.cor, tamanho: v.tamanho, modelo: v.modelo, atributos: atributosDe(v), fotos: v.fotos, thumb: v.thumb,
    preco: p.normal, precoAplicado: p.aplicado, emOferta: p.emOferta && disp, ofertaCadastrada: p.emOferta, desconto: p.desconto, oferta: v.oferta, disponivel: disp, ativa: v.disponivel,
    ...(dono ? { estoque: v.estoque } : { restantes: v.estoque != null && v.estoque > 0 && v.estoque <= 5 ? v.estoque : null }), esgotada: v.estoque === 0,
    maxQtd: v.estoque == null ? null : Math.max(0, v.estoque) } // limite de unidades desta variação (null = a loja não controla estoque dela)
}
/** Rótulo da opção principal quando o lojista não dá um nome. */
export const ROTULO_BASE = 'Padrão'
/** A opção principal (o próprio produto) no mesmo formato público das variações; id 0 = "sem variação". */
export function opcaoPrincipal(p: any, estoqueProduto: number | null, dono = false) {
  if (!p || !p.opcaoBase || p.tipo === 'servico' || !(Number(p.preco) > 0)) return null
  const pr = precos(p.preco, p.oferta), ativa = p.baseAtiva !== false, disp = ativa && temEstoque(estoqueProduto), rotulo = String(p.rotuloBase || '').trim() || ROTULO_BASE
  return { id: 0, base: true, nome: rotulo, rotulo, cor: '', tamanho: '', modelo: '', atributos: [], fotos: (p.fotos || []).filter(Boolean), thumb: p.thumb || null,
    preco: pr.normal, precoAplicado: pr.aplicado, emOferta: pr.emOferta && disp, ofertaCadastrada: pr.emOferta, desconto: pr.desconto, oferta: p.oferta || null, disponivel: disp, ativa,
    ...(dono ? { estoque: estoqueProduto } : { restantes: estoqueProduto != null && estoqueProduto > 0 && estoqueProduto <= 5 ? estoqueProduto : null }), esgotada: estoqueProduto === 0,
    maxQtd: estoqueProduto == null ? null : Math.max(0, estoqueProduto) }
}
/** Acrescenta ao produto: oferta calculada, variações (públicas ou do dono), destaque (menor preço disponível) e disponibilidade. */
export function comCatalogo(p: any, vars: Variante[] | undefined, estoqueProduto: number | null, dono = false) {
  const lista = (vars || []).map((v) => varPublica(v, dono))
  if (!lista.length) {
    const pr = p.tipo === 'servico' ? precos(p.preco, null) : precos(p.preco, p.oferta), disp = temEstoque(estoqueProduto)
    return { ...p, variantes: [], ...(dono ? { estoque: estoqueProduto } : { restantes: estoqueProduto != null && estoqueProduto > 0 && estoqueProduto <= 5 ? estoqueProduto : null }), esgotado: !disp,
      maxQtd: estoqueProduto == null ? null : Math.max(0, estoqueProduto),
      faixasQtd: p.tipo === 'servico' ? [] : tabelaQtd(p), // preço por quantidade (vazio = desligado)
      destaque: { preco: pr.aplicado, precoNormal: pr.normal, emOferta: pr.emOferta && disp, desconto: pr.desconto, aPartirDe: false, foto: (p.fotos || [])[0] || null, varianteId: null, disponivel: disp } }
  }
  // OPÇÃO PRINCIPAL: o produto cadastrado sem variação (preço, oferta, estoque e fotos do próprio produto) é a 1ª opção;
  // as variações vêm depois (2ª, 3ª…). Só para produtos salvos com `opcaoBase` (os antigos continuam como eram).
  const ob = opcaoPrincipal(p, estoqueProduto, dono)
  if (ob) lista.unshift(ob as any)
  const disp = lista.filter((v) => v.disponivel)
  if (ob) {
    // destaque = a opção principal (o preço cadastrado vale); se ela estiver indisponível, a de menor preço disponível
    const alvo: any = ob.disponivel ? ob : disp.length ? disp.reduce((a, v) => (v.precoAplicado < a.precoAplicado ? v : a), disp[0]) : ob
    const menorDisp = disp.length ? Math.min(...disp.map((v) => v.precoAplicado)) : alvo.precoAplicado
    return { ...p, variantes: lista, esgotado: !disp.length, faixasQtd: [], ...(dono ? { estoque: estoqueProduto } : {}),
      destaque: { preco: alvo.precoAplicado, precoNormal: alvo.preco, emOferta: !!disp.length && alvo.emOferta, desconto: disp.length && alvo.emOferta ? alvo.desconto : 0,
        aPartirDe: new Set(disp.map((v) => v.precoAplicado)).size > 1 && alvo.precoAplicado <= menorDisp, foto: (alvo.fotos || [])[0] || (p.fotos || [])[0] || null, varianteId: alvo.id, disponivel: !!disp.length } }
  }
  const base = disp.length ? disp : lista
  const menor = base.reduce((a, v) => ((disp.length ? v.precoAplicado : v.preco) < (disp.length ? a.precoAplicado : a.preco) ? v : a), base[0])
  const precosDisp = new Set(disp.map((v) => v.precoAplicado))
  return { ...p, variantes: lista, esgotado: !disp.length, faixasQtd: [],
    destaque: { preco: disp.length ? menor.precoAplicado : menor.preco, precoNormal: menor.preco, emOferta: !!disp.length && menor.emOferta, desconto: disp.length && menor.emOferta ? menor.desconto : 0,
      aPartirDe: precosDisp.size > 1, foto: menor.fotos[0] || (p.fotos || [])[0] || null, varianteId: menor.id, disponivel: !!disp.length } }
}
/** Enriquece linhas de `products` (já passadas por productOut) com variações, ofertas e destaque. */
export async function enriquecer(prods: any[], dono = false, variantesProntas?: Map<number, Variante[]>): Promise<any[]> {
  if (!prods.length) return prods
  const ids = prods.map((p) => Number(p.id)), vm = variantesProntas || await variantesDe(ids)
  const st = new Map((await q(`SELECT id, stock FROM products WHERE id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids) as any[]).map((r) => [Number(r.id), r.stock == null ? null : Number(r.stock)]))
  return prods.map((p) => comCatalogo(p, vm.get(Number(p.id)), st.get(Number(p.id)) ?? null, dono))
}

/* ---------- cadastro ---------- */
/** Normaliza e valida as variações enviadas pelo formulário. Fotos já salvas podem vir como "keep:<id>:<índice>" (não reenviadas). */
export async function prepararVariantes(productId: number | null, lista: any[], businessId?: number): Promise<{ id: number | null; data: any; stock: number | null; position: number }[]> {
  if (!Array.isArray(lista)) return []
  lista = lista.filter((v: any) => !(v && (v.base === true || (v.id === 0 && v.base !== false)))) // a opção principal é o próprio produto, nunca uma variação
  if (lista.length > MAX_VARIANTES) fail(400, `Um produto pode ter até ${MAX_VARIANTES} variações.`, 'invalid', 'variantes')
  const atuais = productId ? (await variantesDe([productId])).get(productId) || [] : []
  const porId = new Map(atuais.map((v) => [v.id, v])), vistas = new Set<string>()
  // fotos de OUTRO item da mesma empresa (duplicar produto): "keep:<id>:<n>" vale para variações da própria empresa
  const outras = [...new Set(lista.flatMap((v: any) => (Array.isArray(v?.fotos) ? v.fotos : []).map((f: any) => (typeof f === 'string' ? f.match(/^keep:(\d+):\d+$/) : null)).filter(Boolean).map((m: any) => Number(m[1]))))].filter((id) => !porId.has(id))
  if (outras.length && businessId) for (const r of await q(`SELECT * FROM product_variants WHERE business_id = $1 AND id IN (${outras.map((_, i) => '$' + (i + 2)).join(',')})`, [businessId, ...outras]) as any[]) { const v = varOut(r); porId.set(v.id, v) }
  return lista.map((v: any, i: number) => {
    const n = i + 1, rot = `Variação ${n}: `
    const nome = s(v.nome, 60), cor = s(v.cor, 40), tamanho = s(v.tamanho, 40), modelo = s(v.modelo, 60)
    if (!nome && !cor && !tamanho && !modelo) fail(400, `${rot}informe um nome ou pelo menos uma característica (cor, tamanho ou modelo).`, 'invalid', 'variantes')
    const chave = [nome, cor, tamanho, modelo].map(nrm).join('|'); if (vistas.has(chave)) fail(400, `${rot}já existe outra variação igual (${rotuloVariante({ nome, cor, tamanho, modelo })}).`, 'invalid', 'variantes'); vistas.add(chave)
    const preco = r2(Number(v.preco)); if (!(preco > 0 && preco < 1e6)) fail(400, `${rot}informe um preço válido (maior que zero).`, 'invalid', 'variantes')
    const oferta = validarOferta(preco, v.oferta, rot)
    const id = Number(v.id) > 0 && atuais.some((x) => x.id === Number(v.id)) ? Number(v.id) : null, antes = id ? porId.get(id)! : null
    const fotos: string[] = []; let thumbOrigem: string | null = null
    for (const f of Array.isArray(v.fotos) ? v.fotos : []) {
      if (typeof f !== 'string') continue
      const k = f.match(/^keep:(\d+):(\d+)$/)
      if (k) { const src = porId.get(Number(k[1])); const ff = src?.fotos[Number(k[2])]; if (ff) { if (!fotos.length && Number(k[2]) === 0) thumbOrigem = src!.thumb; fotos.push(ff) } continue }
      if (!f.startsWith('data:image/')) continue
      if (f.length >= 900_000) fail(400, `${rot}uma das fotos é muito grande. Escolha uma imagem menor (até ~600 KB).`, 'too_large', 'variantes')
      fotos.push(f)
    }
    if (fotos.length > MAX_FOTOS_VAR) fail(400, `${rot}use até ${MAX_FOTOS_VAR} fotos por variação.`, 'invalid', 'variantes')
    let thumb = typeof v.thumb === 'string' && v.thumb.startsWith('data:image/') && v.thumb.length < 40_000 ? v.thumb : null
    if (!thumb && antes && antes.fotos[0] === fotos[0]) thumb = antes.thumb // mesma foto principal: mantém a miniatura
    if (!thumb && thumbOrigem) thumb = thumbOrigem // foto principal reaproveitada (ex.: produto duplicado)
    if (!fotos.length) thumb = null
    return { id, position: i, stock: estoqueIn(v.estoque), data: { nome, cor, tamanho, modelo, fotos, thumb, preco, oferta, disponivel: v.disponivel !== false } }
  })
}
/** Grava as variações do produto: atualiza as existentes, cria as novas e remove as que saíram (pedidos antigos guardam a própria cópia). */
export async function gravarVariantes(dq: { query: (sql: string, p?: unknown[]) => Promise<any[]> }, productId: number, businessId: number, vs: Awaited<ReturnType<typeof prepararVariantes>>) {
  const now = nowIso(), manter: number[] = []
  for (const v of vs) {
    if (v.id) { await dq.query('UPDATE product_variants SET data = $1, stock = $2, position = $3, updated_at = $4 WHERE id = $5 AND product_id = $6', [JSON.stringify(v.data), v.stock, v.position, now, v.id, productId]); manter.push(v.id) }
    else { const r = await dq.query('INSERT INTO product_variants (product_id, business_id, position, data, stock, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6) RETURNING id', [productId, businessId, v.position, JSON.stringify(v.data), v.stock, now]); manter.push(Number(r[0].id)) }
  }
  const atuais = await dq.query('SELECT id FROM product_variants WHERE product_id = $1', [productId])
  for (const r of atuais) if (!manter.includes(Number(r.id))) await dq.query('DELETE FROM product_variants WHERE id = $1 AND product_id = $2', [Number(r.id), productId])
}

/* ---------- pedido ---------- */
/** Uma linha do pedido com o preço de AGORA, calculado no servidor. `unitPrice` aplica as opções/adicionais antigos sobre a base. */
/* ---------- Imagem dos itens do pedido ----------
   O pedido guarda só uma REFERÊNCIA estável da foto usada no momento da compra (`fotoRef`: impressão digital curta do arquivo),
   nunca uma cópia da imagem. A foto é buscada no cadastro do próprio item (produto/serviço da mesma empresa, variação escolhida):
   1) a foto com a mesma impressão digital (continua certa se o lojista reordenar fotos ou trocar a foto principal);
   2) se ela foi removida do cadastro: a miniatura gravada no pedido (pedidos de variação já guardavam) ou a foto atual do MESMO item;
   3) item apagado ou sem foto: nenhuma (o painel mostra um espaço reservado). Nunca usa foto de outro item. */
export const refFoto = (src: any): string | null => { const v = String(src || ''); return v ? createHash('sha256').update(v).digest('hex').slice(0, 16) : null }
type ItemFoto = { pid: number | null; vid: number | null; ref: string | null; salva: string | null }
/** Item `idx` do pedido → produto/serviço, variação e referência da foto (pedidos antigos sem referência também funcionam). */
export function itemFotoDe(d: any, idx: number): ItemFoto | null {
  const it = (d?.itens || [])[idx]; if (!it) return null
  if (d.tipo === 'agendamento') return { pid: Number(d.servicoId) || null, vid: null, ref: d.servicoFotoRef || null, salva: null }
  return { pid: Number(it.pid) || null, vid: it.varianteId != null ? Number(it.varianteId) : null, ref: it.fotoRef || null, salva: typeof it.foto === 'string' && it.foto ? it.foto : null }
}
/** Carrega, de uma vez, as fotos cadastradas dos itens citados nos pedidos (só itens da MESMA empresa de cada pedido). */
export async function fotosDosItens(pedidos: { business_id: any; data: any }[]) {
  const ids = new Set<number>()
  for (const o of pedidos) { const d = J<any>(o.data, {}); (d.itens || []).forEach((_: any, i: number) => { const f = itemFotoDe(d, i); if (f?.pid) ids.add(f.pid) }) }
  const prods = new Map<number, { bid: number; fotos: string[] }>(), lista = [...ids]
  if (lista.length) for (const r of await q(`SELECT id, business_id, data FROM products WHERE id IN (${lista.map((_, i) => '$' + (i + 1)).join(',')})`, lista) as any[]) prods.set(Number(r.id), { bid: Number(r.business_id), fotos: (J<any>(r.data, {}).fotos || []).filter(Boolean) })
  const vars = lista.length ? await variantesDe(lista) : new Map<number, Variante[]>()
  return { prods, vars }
}
/** A foto certa do item `idx` do pedido (ou null). */
export function fotoDoItem(o: { business_id: any; data: any }, idx: number, cache: Awaited<ReturnType<typeof fotosDosItens>>): string | null {
  const d = J<any>(o.data, {}), f = itemFotoDe(d, idx); if (!f) return null
  const p = f.pid ? cache.prods.get(f.pid) : null
  if (!p || p.bid !== Number(o.business_id)) return f.salva // item apagado (ou de outra empresa): só o que o pedido já guardava
  const vs = cache.vars.get(f.pid!) || [], v = f.vid != null ? vs.find((x) => Number(x.id) === f.vid) : null
  const daVar = v ? [...v.fotos, v.thumb].filter(Boolean) as string[] : []
  const todas = [...daVar, ...p.fotos, ...vs.filter((x) => x !== v).flatMap((x) => [...x.fotos, x.thumb].filter(Boolean) as string[])]
  if (f.ref) { const igual = todas.find((x) => refFoto(x) === f.ref); if (igual) return igual }
  return f.salva || daVar[0] || p.fotos[0] || null
}
/** Foto principal no momento do pedido (para a referência estável). */
export const fotoAtual = (p: any, v?: any) => (v && ((v.fotos || [])[0] || v.thumb)) || (p?.fotos || [])[0] || null

export function linhaPedido(p: any, it: { vid?: any; variante?: any; escolhas?: Record<string, number>; qtd: number; obs?: string; qtdTotal?: number }, unitPrice: (prod: any, esc: Record<string, number>, base?: number) => number) {
  const qtd = it.qtd, vars0 = (p.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[Number(it.escolhas?.[v.nome] ?? 0)]?.nome ?? ''}`)
  const vs: any[] = p.variantes || []
  if (vs.length) {
    const semVid = it.vid == null || it.vid === '' || Number(it.vid) === 0
    let v = semVid ? null : vs.find((x) => !x.base && Number(x.id) === Number(it.vid))
    if (!v && it.variante) { const w = nrm(it.variante); v = vs.find((x) => nrm(x.rotulo) === w || nrm(x.nome) === w) }
    if (!v && semVid) v = vs.find((x) => x.base) // sem variação escolhida = a opção principal (quando o produto tem)
    if (!v) fail(400, `Escolha a opção de ${p.nome} (${vs.filter((x) => x.disponivel).map((x) => x.rotulo).join(', ') || 'nenhuma disponível'}).`, 'variante_obrigatoria')
    if (!v.disponivel) fail(409, `${p.nome} · ${v.rotulo} está indisponível no momento.`, 'indisponivel')
    const lim = (p.__estoqueVar || {})[v.id]; if (lim != null && lim < qtd) semEstoque(`${p.nome} · ${v.rotulo}`, lim, { pid: p.id, vid: v.id }) // estoque DESTA variação (nunca o do produto ou de outra variação)
    const preco = unitPrice(p, it.escolhas || {}, v.precoAplicado), precoNormal = unitPrice(p, it.escolhas || {}, v.preco)
    if (v.base) { // opção principal: é o próprio produto (estoque e foto do produto; sem id de variação)
      return { pid: Number(p.id), nome: p.nome, varianteId: null, opcaoPrincipal: true, variante: v.rotulo, fotoRef: refFoto(fotoAtual(p)), vars: [v.rotulo, ...vars0], obs: s(it.obs, 140), qtd, precoNormal, preco,
        promocao: v.emOferta ? { tipo: 'oferta', escopo: 'produto', precoNormal: v.preco, precoPromocional: v.precoAplicado, desconto: v.desconto } : null }
    }
    return { pid: Number(p.id), nome: p.nome, varianteId: v.id, variante: v.rotulo, atributos: v.atributos.map((a: any) => ({ nome: a.nome, valor: a.valor })), foto: v.thumb || null, fotoRef: refFoto(fotoAtual(p, v)),
      vars: [...v.atributos.map((a: any) => `${a.nome}: ${a.valor}`), ...(v.nome && v.atributos.length ? [v.nome] : !v.atributos.length ? [v.rotulo] : []), ...vars0], obs: s(it.obs, 140), qtd, precoNormal, preco,
      promocao: v.emOferta ? { tipo: 'oferta', escopo: 'variacao', varianteId: v.id, precoNormal: v.preco, precoPromocional: v.precoAplicado, desconto: v.desconto } : null }
  }
  if (p.esgotado) fail(409, `${p.nome} está esgotado no momento.`, 'sem_estoque')
  const lim = p.__estoque; if (lim != null && lim < qtd) semEstoque(p.nome, lim, { pid: p.id })
  const pr = precos(p.preco, p.oferta)
  // preço por quantidade: conta a soma do mesmo produto no pedido; vale a faixa só se ela for menor que o preço de hoje (oferta)
  const total = Math.max(qtd, Math.floor(Number(it.qtdTotal) || 0)), fx = faixaPara(faixasAtivas(p), total), porQtd = !!fx && fx.preco < pr.aplicado
  const base = porQtd ? fx!.preco : pr.emOferta ? pr.aplicado : undefined
  const preco = unitPrice(p, it.escolhas || {}, base), precoNormal = unitPrice(p, it.escolhas || {})
  return { pid: Number(p.id), nome: p.nome, fotoRef: refFoto(fotoAtual(p)), vars: vars0, obs: s(it.obs, 140), qtd, precoNormal, preco,
    promocao: porQtd ? { tipo: 'quantidade', escopo: 'produto', faixa: fx!.qtd, qtdProduto: total, precoNormal: pr.normal, precoPromocional: fx!.preco, desconto: Math.round((1 - fx!.preco / pr.normal) * 100) }
      : pr.emOferta ? { tipo: 'oferta', escopo: 'produto', precoNormal: pr.normal, precoPromocional: pr.aplicado, desconto: pr.desconto } : null }
}
/** Carrega os produtos ativos da empresa com variações e o estoque exato (só para cálculo interno do pedido). */
export async function produtosParaPedido(businessId: number, productOut: (r: any) => any) {
  const rows = await q('SELECT * FROM products WHERE business_id = $1 AND active = $2', [businessId, true]) as any[]
  const prods = await enriquecer(rows.map(productOut), true)
  for (const p of prods) { p.__estoque = p.estoque ?? null; p.__estoqueVar = Object.fromEntries((p.variantes || []).map((v: any) => [v.id, v.estoque ?? null])) }
  return new Map(prods.map((p) => [Number(p.id), p]))
}

/** Soma do pedido por variação (ou produto sem variações): linhas repetidas do mesmo item contam juntas. */
function somasEstoque(linhas: any[]) {
  const somas = new Map<string, { tipo: 'v' | 'p'; id: number; qtd: number; nome: string; pid: number; vid: number | null }>()
  for (const l of linhas) { const k = l.varianteId ? `v${l.varianteId}` : `p${l.pid}`; const e = somas.get(k) || { tipo: l.varianteId ? 'v' as const : 'p' as const, id: Number(l.varianteId || l.pid), qtd: 0, nome: l.variante ? `${l.nome} · ${l.variante}` : l.nome, pid: Number(l.pid), vid: l.varianteId ? Number(l.varianteId) : null }; e.qtd += Math.max(0, Math.floor(Number(l.qtd) || 0)); somas.set(k, e) }
  return [...somas.values()].sort((x, y) => (x.tipo === y.tipo ? x.id - y.id : x.tipo < y.tipo ? -1 : 1)) // ordem fixa: duas compras simultâneas travam as linhas na mesma ordem (sem impasse)
}
/** Confere a SOMA do pedido contra o estoque de cada variação (antes de cupom, moedas e Pix): mensagem clara já na validação. */
export function conferirSomas(prods: Map<number, any>, linhas: any[]) {
  for (const e of somasEstoque(linhas)) {
    const p = prods.get(e.pid); if (!p) continue
    const lim = e.tipo === 'v' ? (p.__estoqueVar || {})[e.id] : p.__estoque
    if (lim != null && e.qtd > lim) semEstoque(e.nome, lim, { pid: e.pid, vid: e.vid })
  }
}
/** Débito do estoque de cada item, só se houver unidades: `UPDATE … SET stock = stock - n WHERE stock >= n` (nunca negativo).
 *  PostgreSQL: tudo numa transação (ou entra o pedido inteiro, ou nada; duas compras ao mesmo tempo não passam do estoque).
 *  SQLite (testes): mesma condição, desfazendo o que já foi debitado se um item faltar. */
async function debitar(lista: { tipo: 'v' | 'p'; id: number; qtd: number; nome?: string; pid?: number; vid?: number | null }[]) {
  const rodar = async (dq: { query: (sql: string, p?: unknown[]) => Promise<any[]> }) => {
    const feitas: { tipo: 'v' | 'p'; id: number; qtd: number }[] = []
    try {
      for (const e of lista) {
        if (!(e.qtd > 0)) continue
        const tab = e.tipo === 'v' ? 'product_variants' : 'products'
        const ctl = (await dq.query(`SELECT stock FROM ${tab} WHERE id = $1`, [e.id]))[0]; if (!ctl || ctl.stock == null) continue // não controla estoque
        const r = await dq.query(`UPDATE ${tab} SET stock = stock - $1 WHERE id = $2 AND stock IS NOT NULL AND stock >= $1 RETURNING stock`, [e.qtd, e.id])
        if (!r.length) { const ag = (await dq.query(`SELECT stock FROM ${tab} WHERE id = $1`, [e.id]))[0]; semEstoque(e.nome || 'Item', Number(ag?.stock) || 0, { pid: Number(e.pid ?? (e.tipo === 'p' ? e.id : 0)), vid: e.vid ?? (e.tipo === 'v' ? e.id : null) }) }
        feitas.push({ tipo: e.tipo, id: e.id, qtd: e.qtd })
      }
      return feitas
    } catch (x) { if (db().kind !== 'postgres') await devolverEstoque(feitas); throw x } // PostgreSQL: o ROLLBACK desfaz
  }
  return db().kind === 'postgres' ? db().tx(rodar) : rodar(db())
}
/** Débito atômico do estoque das linhas do pedido (quem controla estoque). Se faltar em qualquer item, nada fica debitado. */
export async function reservarEstoque(linhas: any[]): Promise<{ tipo: 'v' | 'p'; id: number; qtd: number }[]> {
  return debitar(somasEstoque(linhas))
}
/** Situação do carrinho no servidor (ao adicionar, ao abrir o carrinho e antes de finalizar): o limite atual de cada item.
 *  Não reserva nada; quem reserva é o pedido. Itens do mesmo produto e variação são somados. */
export function situacaoCarrinho(prods: Map<number, any>, itens: any[]) {
  const soma = new Map<string, number>()
  const chave = (it: any) => `${Number(it.pid)}:${Number(it.vid) || 0}`
  for (const it of itens) soma.set(chave(it), (soma.get(chave(it)) || 0) + Math.max(0, Math.floor(Number(it.qtd) || 0)))
  return [...soma.entries()].map(([k, qtd]) => {
    const [pid, vid] = k.split(':').map(Number), p = prods.get(pid)
    if (!p || p.tipo === 'servico') return { pid, vid: vid || null, qtd, disponivel: false, max: 0, ok: false, mensagem: 'Este produto não está mais disponível.' }
    const vs: any[] = p.variantes || []
    if (vs.length) {
      const v = vs.find((x) => Number(x.id) === vid) // vid 0 = opção principal (quando o produto tem)
      if (!v) return { pid, vid: vid || null, qtd, disponivel: false, max: 0, ok: false, mensagem: `Escolha de novo a opção de ${p.nome}.` }
      const lim = (p.__estoqueVar || {})[v.id], max = !v.disponivel ? 0 : lim == null ? null : Math.max(0, lim), nome = `${p.nome} · ${v.rotulo}`
      return { pid, vid, qtd, disponivel: max !== 0, max, ok: max == null || qtd <= max, mensagem: max === 0 ? `${nome} está indisponível.` : max != null && qtd > max ? `${nome}: limite de ${max} ${max === 1 ? 'unidade disponível' : 'unidades disponíveis'}.` : '' }
    }
    const lim = p.__estoque, max = p.esgotado ? 0 : lim == null ? null : Math.max(0, lim)
    return { pid, vid: null, qtd, disponivel: max !== 0, max, ok: max == null || qtd <= max, mensagem: max === 0 ? `${p.nome} está indisponível.` : max != null && qtd > max ? `${p.nome}: limite de ${max} ${max === 1 ? 'unidade disponível' : 'unidades disponíveis'}.` : '' }
  })
}
export async function devolverEstoque(res: { tipo: 'v' | 'p'; id: number; qtd: number }[]) {
  for (const e of res || []) await q(`UPDATE ${e.tipo === 'v' ? 'product_variants' : 'products'} SET stock = stock + $1 WHERE id = $2 AND stock IS NOT NULL`, [e.qtd, e.id])
}
/** Devolve o estoque reservado por um pedido (cancelado, recusado ou Pix não pago). Idempotente: marca o pedido. */
export async function devolverPedido(orderId: number) {
  const o = await one('SELECT data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const d = J<any>(o.data, {}); if (!Array.isArray(d.estoque) || !d.estoque.length || d.estoqueDevolvido) return
  // marca primeiro (condicional) para nunca devolver duas vezes em chamadas simultâneas
  const marcado = { ...d, estoqueDevolvido: nowIso() }
  const r = await q('UPDATE orders SET data = $1 WHERE id = $2 AND data = $3 RETURNING id', [JSON.stringify(marcado), orderId, typeof o.data === 'string' ? o.data : JSON.stringify(o.data)])
  if (!r.length) return
  await devolverEstoque(d.estoque)
}
/** Gerar um Pix novo para um pedido cuja reserva já voltou ao estoque (Pix vencido/recusado): reserva de novo, atomicamente,
 *  ANTES de cobrar. Sem estoque, recusa (o cliente não paga por algo que acabou). */
export async function reservarDeNovo(orderId: number) {
  const o = await one('SELECT data FROM orders WHERE id = $1', [orderId]); if (!o) return
  const d = J<any>(o.data, {}); if (!d.estoqueDevolvido || !Array.isArray(d.estoque) || !d.estoque.length) return
  const nomes = new Map<string, any>(); for (const l of d.itens || []) nomes.set(l.varianteId ? `v${l.varianteId}` : `p${l.pid}`, l)
  const lista = (d.estoque as any[]).map((e) => { const l = nomes.get(`${e.tipo}${e.id}`) || {}; return { ...e, nome: l.variante ? `${l.nome} · ${l.variante}` : l.nome || 'Item', pid: Number(l.pid) || 0, vid: e.tipo === 'v' ? Number(e.id) : null } })
    .sort((x, y) => (x.tipo === y.tipo ? x.id - y.id : x.tipo < y.tipo ? -1 : 1))
  const feitas = await debitar(lista)
  const marc = { ...d }; delete marc.estoqueDevolvido
  const r = await q('UPDATE orders SET data = $1 WHERE id = $2 AND data = $3 RETURNING id', [JSON.stringify({ ...marc, estoque: feitas.length ? feitas : d.estoque }), orderId, typeof o.data === 'string' ? o.data : JSON.stringify(o.data)])
  if (!r.length) await devolverEstoque(feitas) // outra chamada simultânea já reservou: não debita duas vezes
}
/** Pix pago depois que a reserva foi devolvida: debita de novo sem deixar negativo. Se faltar unidade (a venda já está paga),
 *  baixa o que houver e registra a falta no pedido para a loja resolver (devolver o dinheiro ou combinar a troca). */
export async function retomarPedido(orderId: number): Promise<{ nome: string; faltam: number }[]> {
  const o = await one('SELECT data FROM orders WHERE id = $1', [orderId]); if (!o) return []
  const d = J<any>(o.data, {}); if (!d.estoqueDevolvido || !Array.isArray(d.estoque)) return []
  delete d.estoqueDevolvido
  const falta: { nome: string; faltam: number }[] = []
  for (const e of d.estoque) {
    const tab = e.tipo === 'v' ? 'product_variants' : 'products'
    const ok = await q(`UPDATE ${tab} SET stock = stock - $1 WHERE id = $2 AND stock IS NOT NULL AND stock >= $1 RETURNING stock`, [e.qtd, e.id])
    if (ok.length) continue
    const ag = await one(`SELECT stock FROM ${tab} WHERE id = $1`, [e.id]); if (!ag || ag.stock == null) continue
    const tem = Math.max(0, Number(ag.stock) || 0)
    if (tem > 0) await q(`UPDATE ${tab} SET stock = stock - $1 WHERE id = $2 AND stock >= $1`, [tem, e.id])
    const l = (d.itens || []).find((x: any) => (e.tipo === 'v' ? Number(x.varianteId) === Number(e.id) : Number(x.pid) === Number(e.id) && !x.varianteId)) || {}
    falta.push({ nome: l.variante ? `${l.nome} · ${l.variante}` : l.nome || 'Item', faltam: Number(e.qtd) - tem })
  }
  if (falta.length) d.estoqueFaltando = falta
  await q('UPDATE orders SET data = $1 WHERE id = $2', [JSON.stringify(d), orderId])
  return falta
}
