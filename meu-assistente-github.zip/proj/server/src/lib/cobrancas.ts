// COBRANÇAS PELO CHAT ("crie uma cobrança de R$ 10,00", "gere um Pix de 150 reais", "cobrança de 80 reais para João").
// Usa a integração que já existe — a conexão Mercado Pago da PRÓPRIA empresa (empresa_integracoes, tokenLoja, renovação do
// OAuth, webhook da loja com assinatura) — e só acrescenta a tabela `cobrancas` (migração 062).
//
// Regras:
//  • empresa = a ATIVA do usuário (mesma regra do chat de administração: empresa_contexto; com uma só, ela mesma). Empresa de
//    outra conta (vínculo) não cobra: recebimento pelo Mercado Pago exige entrar na conta dona (mesma regra do painel);
//  • antes de qualquer coisa a conexão é conferida (token salvo, status conectado, plano/anúncio liberados). Sem conexão válida
//    NADA é gerado: nem cobrança, nem QR Code, nem link;
//  • o Pix é criado na API oficial (POST /v1/payments) com o token da empresa, X-Idempotency-Key fixa por cobrança e
//    notification_url do webhook da loja; QR Code, Copia e Cola e ticket_url são os que o Mercado Pago devolveu;
//  • "pago" só a partir da API do Mercado Pago (webhook conferido pela assinatura + consulta do pagamento com o token desta
//    empresa, ou consulta de status), com pagamento, referência, valor e empresa conferidos. Nunca por resposta do aplicativo
//    ou mensagem do usuário; a passagem para "pago" é atômica (uma vez só: aviso e lançamento no Financeiro não repetem);
//  • idempotência: a mesma mensagem do chat (id do envio) nunca cria duas cobranças; repetir o mesmo pedido em 2 minutos devolve
//    a cobrança já criada (a não ser que o usuário peça "outra"/"nova");
//  • credenciais nunca saem do servidor: o aplicativo recebe só valor, textos, QR Code, Copia e Cola, links e status.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from './session.js'
import { sha256, token } from './security.js'
import { pub } from './publicurl.js'

const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const nrm = (v: any) => String(v ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim()
export const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
export const VALOR_MAX = 100000

/* ---------- leitura do pedido ---------- */
const GERAR = /\b(cri[ae]r?|crie|cria|ger[ae]r?|gere|gera|fa[cz]a|fazer|faz|emit[ae]r?|emita|mand[ae]r?|mande|envi[ae]r?|envie|preciso de|quero|lan[cç]ar?|lance|nova|novo|outra|outro)\b/
const OBJ = /\b(cobranca|link de pagamento|link pra pagar|link para pagar|qr ?code (de|do) pix)\b/
export interface PedidoCobranca { valor: number | null; descricao: string; cliente: string; vencimento: Date | null; outra: boolean }
const NUM = String.raw`(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)`
function numero(s: string) { const t = s.includes(',') ? s.replace(/\./g, '').replace(',', '.') : (/^\d{1,3}(\.\d{3})+$/.test(s) ? s.replace(/\./g, '') : s); const n = Number(t); return Number.isFinite(n) ? Math.round(n * 100) / 100 : null }
/** Valor pedido: "R$ 10,00", "150 reais", "de 80", "1.250,50". Datas ("dia 30", "10/12") não viram valor. */
export function lerValor(texto: string): number | null {
  const t = nrm(texto)
  const ms = [new RegExp(String.raw`r\$\s*${NUM}`), new RegExp(String.raw`${NUM}\s*(?:reais|real|conto|contos|pila)\b`), new RegExp(String.raw`\b(?:de|no valor de|valor de|valor|por|em)\s+${NUM}(?![\d/:]|\s*(?:de\s+)?(?:dias?|horas?|h\b|min|%|x\b|vezes|parcelas?))`)]
  for (const m of ms) { const r = m.exec(t); if (r) { const n = numero(r[1]); if (n !== null) return n } }
  return null
}
function lerVencimento(texto: string, agora = new Date()): Date | null {
  const t = nrm(texto)
  const fimDoDia = (d: Date) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 23 + 3, 59, 0)) // 23:59 em Brasília (UTC−3)
  const hojeBr = new Date(agora.getTime() - 3 * 3600_000) // data civil de Brasília
  const base = (dias: number) => fimDoDia(new Date(Date.UTC(hojeBr.getUTCFullYear(), hojeBr.getUTCMonth(), hojeBr.getUTCDate() + dias)))
  if (!/\b(venc\w*|vence|ate|validade|valid[oa]|pagar ate|prazo|para pagar)\b/.test(t)) return null
  let m: RegExpExecArray | null
  if (/\b(venc\w*|vence|ate|prazo|valid\w*)\s+(para\s+)?hoje\b/.test(t)) return base(0)
  if (/\b(venc\w*|vence|ate|prazo|valid\w*)\s+(para\s+)?amanha\b/.test(t)) return base(1)
  if ((m = /\b(?:em|daqui a)\s+(\d{1,2})\s+dias?\b/.exec(t))) return base(Number(m[1]))
  if ((m = /\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/.exec(t))) {
    let y = m[3] ? Number(m[3]) : hojeBr.getUTCFullYear(); if (y < 100) y += 2000
    let d = new Date(Date.UTC(y, Number(m[2]) - 1, Number(m[1])))
    if (!m[3] && d.getTime() < Date.UTC(hojeBr.getUTCFullYear(), hojeBr.getUTCMonth(), hojeBr.getUTCDate())) d = new Date(Date.UTC(y + 1, Number(m[2]) - 1, Number(m[1])))
    return fimDoDia(d)
  }
  if ((m = /\bdia\s+(\d{1,2})\b/.exec(t))) {
    const dia = Number(m[1]); let d = new Date(Date.UTC(hojeBr.getUTCFullYear(), hojeBr.getUTCMonth(), dia))
    if (dia < hojeBr.getUTCDate()) d = new Date(Date.UTC(hojeBr.getUTCFullYear(), hojeBr.getUTCMonth() + 1, dia))
    return fimDoDia(d)
  }
  return null
}
const PARADA = String.raw`(?=\s*(?:[,.;]|$|\s(?:para|pra|pro|no valor|com vencimento|vencimento|vence|até|ate|válid|valid|de r\$|r\$|em \d)))`
export function lerPedido(texto: string): PedidoCobranca | null {
  const t = nrm(texto)
  if (/\b(pague[i]?|paguei|pagar com|vou pagar|quero pagar|chave pix|minha chave)\b/.test(t) && !/\bcobranca\b/.test(t)) return null
  const pixComValor = /\bpix\b/.test(t) && GERAR.test(t) && lerValor(texto) !== null
  const cobrarAlguem = /\bcobr(ar|e|a)\b/.test(t) && lerValor(texto) !== null && !/\b(quanto|como)\b/.test(t)
  const soComando = /^(uma |nova |outra )?(cobranca|pix)\b/.test(t) && lerValor(texto) !== null // "cobrança de corte de cabelo de R$ 40 para Carlos"
  if (!((GERAR.test(t) && OBJ.test(t)) || pixComValor || cobrarAlguem || soComando)) return null
  if (/\b(status|situacao|foi pag|ja pag|pagaram|pagou|minhas cobrancas|ultimas cobrancas|ultima cobranca|como (eu )?(crio|faco|gero)|o que e|cancel\w*|apag\w*|exclu\w*)\b/.test(t)) return null
  const valor = lerValor(texto)
  // cliente: "para João", "pra Maria Souza", "do cliente Pedro", "cobrar o João" — no texto original (mantém maiúsculas/acentos)
  const orig = String(texto || '').replace(/\s+/g, ' ').trim()
  let cliente = ''
  const mc = new RegExp(String.raw`\b(?:para|pra|pro|ao cliente|a cliente|do cliente|da cliente|cliente|cobrar (?:o|a)|cobre (?:o|a)|de cobran[cç]a (?:para|pra))\s+(?:o |a |os |as )?([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'.-]*(?:\s+(?!(?:referente|ref|pelo|pela|pelos|pelas|no|na|com|de|do|da|vencimento|vence|até|ate|valor|r\$|hoje|amanhã|amanha|dia|em|e)\b)[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'.-]*){0,3})`, 'i').exec(orig)
  if (mc && !/^(pagar|pagamento|hoje|amanh[aã]|dia|o|a|mim|eu|ele|ela|voce|você|r\$)$/i.test(mc[1])) cliente = mc[1].replace(/[.,;]+$/, '').slice(0, 80)
  // descrição: "referente a corte de cabelo", "pelo conserto", "de mensalidade", "descrição: ..."
  let descricao = ''
  const md = new RegExp(String.raw`(?:referente (?:a|ao|aos|às|as|à)|ref\.?|pel[oa]s?|descri[cç][aã]o:?|do servi[cç]o de|da compra de|motivo:?)\s+(.+?)` + PARADA, 'i').exec(orig)
  if (md) descricao = md[1].replace(/\s+(para|pra|pro)\s+.*$/i, '').replace(/[.,;]+$/, '').trim().slice(0, 120)
  if (!descricao) { const mx = /\b(?:cobran[cç]a|pix)\s+(?:de|da|do)\s+(?!r\$|\d)([A-Za-zÀ-ÿ][^,.;]{2,60}?)(?=\s+(?:de\s+)?(?:r\$|\d)|\s+(?:para|pra|no valor)|[,.;]|$)/i.exec(orig); if (mx && !/^(teste|pagamento)$/i.test(mx[1])) descricao = mx[1].trim() }
  return { valor, descricao, cliente, vencimento: lerVencimento(texto), outra: /\b(outra|outro|mais uma|nova cobranca|novo pix)\b/.test(t) }
}
/** Consulta de status pelo chat: "a cobrança foi paga?", "status da última cobrança", "minhas cobranças". */
export const pedidoDeStatus = (texto: string) => { const t = nrm(texto); return /\b(cobranca|cobrancas|pix que (eu )?(gerei|criei|mandei))\b/.test(t) && /\b(status|situacao|foi paga|ja (foi )?paga|pagaram|pagou|caiu|recebi|confirm\w*|minhas|ultimas?|como esta|como ta)\b/.test(t) && !/\b(cri[ae]|gere|gera|gerar|criar)\b/.test(t) }

/* ---------- conexão da empresa ---------- */
export type Conexao = { ok: true; b: any; x: any; nome: string; teste: boolean } | { ok: false; motivo: string; codigo: string }
export async function conexaoDaEmpresaAtiva(u: SessionUser): Promise<Conexao> {
  const EA = await import('../ai/empresa-admin.js'), at = await EA.empresaAtiva(u)
  if (!at.ok) return { ok: false, codigo: 'sem_empresa', motivo: at.erro.replace('As configurações de empresa pelo chat são para donos de empresa.', 'As cobranças pelo Mercado Pago são feitas pela empresa conectada.').replace('quer administrar', 'vai cobrar').replace('não consigo alterar as configurações dela', 'ainda não consigo gerar cobranças por ela') }
  const { b, x, nome, propria } = at.e
  if (!propria) return { ok: false, codigo: 'vinculo', motivo: `A ${nome} é de outra conta (empresa vinculada). Cobranças pelo Mercado Pago só podem ser geradas entrando na conta dona da empresa. Nenhuma cobrança foi criada.` }
  const M = await import('../routes/mpuser.js'), d = await M.mpDe(Number(b.id))
  const onde = 'Sua empresa → Ajustes → Entrega e pagamento → Pagamento automático'
  if (!d.mpTok) return { ok: false, codigo: 'mp_desconectado', motivo: `A ${nome} ainda não tem uma conta Mercado Pago conectada. Para gerar cobranças com Pix, conecte a conta em ${onde}. Nenhuma cobrança, QR Code ou link foi gerado.` }
  if (d.mpStatus === 'erro') return { ok: false, codigo: 'mp_erro', motivo: `A conexão da ${nome} com o Mercado Pago está com erro (autorização expirada, revogada ou credencial recusada). Reconecte em ${onde}. Nenhuma cobrança foi criada.` }
  if (d.mpStatus === 'pendente') return { ok: false, codigo: 'mp_pendente', motivo: `A conexão da ${nome} com o Mercado Pago ainda está pendente de confirmação. Conclua ou verifique a conexão em ${onde}. Nenhuma cobrança foi criada.` }
  const bl = await M.motivoBloqueio(b); if (bl) return { ok: false, codigo: bl.codigo, motivo: `${bl.mensagem} Nenhuma cobrança foi criada.` }
  return { ok: true, b, x, nome, teste: !!d.mpTeste }
}

/* ---------- criação ---------- */
export class ErroCobranca extends Error { constructor(msg: string, public codigo: string) { super(msg) } }
const DUP_MS = 2 * 60_000
/** Cria (ou devolve a já criada) e gera o Pix real no Mercado Pago. */
export async function criar(u: SessionUser, b: any, p: { valor: number; descricao?: string; cliente?: string; vencimento?: Date | null; outra?: boolean; envio?: string }, teste = false): Promise<{ c: any; existente: boolean }> {
  const valor = Math.round(Number(p.valor) * 100) / 100
  if (!(valor >= 0.01)) throw new ErroCobranca('Informe um valor maior que zero.', 'valor')
  if (valor > VALOR_MAX) throw new ErroCobranca(`O valor máximo por cobrança no chat é ${brl(VALOR_MAX)}.`, 'valor')
  const x = J<any>(b.data, {}), descricao = String(p.descricao || '').trim().slice(0, 120) || `Cobrança ${x.empresa || ''}`.trim(), cliente = String(p.cliente || '').trim().slice(0, 80)
  let venc = p.vencimento || null
  const agora = Date.now()
  if (venc && venc.getTime() < agora + 30 * 60_000) throw new ErroCobranca('O vencimento precisa ser pelo menos 30 minutos à frente.', 'vencimento')
  if (venc && venc.getTime() > agora + 30 * 86400_000) throw new ErroCobranca('O Pix pode vencer em no máximo 30 dias.', 'vencimento')
  const expira = venc || new Date(agora + 24 * 3600_000) // sem vencimento: o Pix vale 24 horas
  // idempotência: a mesma mensagem (id do envio) → a mesma cobrança; o mesmo pedido repetido em 2 minutos → a mesma cobrança
  const idem = p.envio ? sha256(`cob|${u.id}|${b.id}|${p.envio}`) : ''
  if (idem) { const ex = await one('SELECT * FROM cobrancas WHERE idem_key = $1', [idem]); if (ex) return { c: ex, existente: true } }
  if (!p.outra) {
    const desde = new Date(agora - DUP_MS).toISOString()
    const ex = (await q("SELECT * FROM cobrancas WHERE business_id = $1 AND created_by = $2 AND created_at >= $3 AND status IN ('criando','pendente','pago') ORDER BY id DESC LIMIT 5", [b.id, u.id, desde]))
      .find((c: any) => Number(c.valor) === valor && String(c.cliente) === cliente && String(c.descricao) === descricao)
    if (ex) return { c: ex, existente: true }
  }
  const linkTok = token(18), agoraIso = nowIso()
  let c: any
  try {
    c = (await q('INSERT INTO cobrancas (business_id, created_by, valor, descricao, cliente, vencimento, expira_em, status, teste, link_token, idem_key, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12) RETURNING *',
      [b.id, u.id, valor, descricao, cliente, p.vencimento ? p.vencimento.toISOString() : null, expira.toISOString(), 'criando', teste, linkTok, idem || sha256(`cob|${u.id}|${b.id}|${linkTok}`), agoraIso]))[0]
  } catch (e: any) { // corrida com o mesmo envio: a outra gravação venceu
    if (idem) { const ex = await one('SELECT * FROM cobrancas WHERE idem_key = $1', [idem]); if (ex) return { c: ex, existente: true } }
    throw e
  }
  return { c: await gerarPix(b, c), existente: false }
}
const brasilia = (d: Date) => new Date(d.getTime() - 3 * 3600_000).toISOString().replace('Z', '-03:00')
/** POST /v1/payments com o token da empresa. Falha → a cobrança fica "falhou" (sem QR, sem link) e o erro é explicado. */
export async function gerarPix(b: any, c: any) {
  const M = await import('../routes/mpuser.js'), tok = await M.tokenLoja(b)
  const falhou = async (erro: string, msg: string, codigo: string) => { await q('UPDATE cobrancas SET status = $1, erro = $2, updated_at = $3 WHERE id = $4', ['falhou', erro, nowIso(), c.id]); throw new ErroCobranca(msg, codigo) }
  if (!tok) return falhou('sem_token', 'A conexão com o Mercado Pago não está utilizável agora (autorização expirada ou revogada). Reconecte a conta em Sua empresa. Nenhuma cobrança foi gerada.', 'mp_erro')
  const x = J<any>(b.data, {})
  const body: any = { transaction_amount: Number(c.valor), description: `${c.descricao}${c.cliente ? ' · ' + c.cliente : ''}`.slice(0, 200), payment_method_id: 'pix',
    payer: { email: `cobranca${c.id}@clientes.meuassistente.app`, ...(c.cliente ? { first_name: String(c.cliente).split(' ')[0].slice(0, 40) } : {}) },
    date_of_expiration: brasilia(new Date(c.expira_em)), external_reference: `cob:${c.id}`, notification_url: `${pub()}/api/mercadopago/webhook?store=${b.id}`,
    statement_descriptor: String(x.empresa || '').replace(/[^A-Za-z0-9 ]/g, '').slice(0, 22) || undefined }
  let r: Response, j: any
  try { r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `cob-${c.id}` }, body: JSON.stringify(body), signal: AbortSignal.timeout(20_000) }); j = await r.json().catch(() => null) }
  catch { return falhou('sem_resposta', 'O Mercado Pago não respondeu agora. Nenhuma cobrança foi gerada: tente de novo em instantes.', 'mp_indisponivel') }
  if (r!.status === 401 || r!.status === 403) { void M.verificarLoja(b).catch(() => null); return falhou(`recusado_${r!.status}`, 'O Mercado Pago recusou a credencial da empresa (autorização expirada ou revogada). Verifique a conexão em Sua empresa → Ajustes → Entrega e pagamento. Nenhuma cobrança foi gerada.', 'mp_erro') }
  if (!r!.ok || !j?.id) {
    console.error(`[cobranças] empresa ${b.id}: Mercado Pago ${r!.status} ao gerar o Pix da cobrança ${c.id}:`, String(j?.message || j?.error || '').slice(0, 160)) // sem token, sem dados do pagador
    const pixDesabilitado = /pix|key|chave|collector|bank_transfer/i.test(String(j?.message || j?.cause?.[0]?.description || ''))
    return falhou(`mp_${r!.status}`, r!.status >= 500 || r!.status === 429 ? 'O Mercado Pago está instável agora. Nenhuma cobrança foi gerada: tente de novo em instantes.'
      : pixDesabilitado ? 'O Mercado Pago não gerou o Pix: confira se a conta tem uma chave Pix cadastrada e habilitada para receber. Nenhuma cobrança foi gerada.'
      : `O Mercado Pago não aceitou a cobrança (${String(j?.message || 'dados recusados').slice(0, 120)}). Nenhuma cobrança foi gerada.`, 'mp_recusou')
  }
  const td = j.point_of_interaction?.transaction_data || {}
  if (!td.qr_code) return falhou('sem_qr', 'O Mercado Pago criou o pagamento mas não devolveu o código Pix. Nenhuma cobrança foi enviada: tente de novo.', 'mp_sem_qr')
  const st = j.status === 'approved' ? 'pago' : mapStatus(j.status)
  await q('UPDATE cobrancas SET status = $1, mp_payment_id = $2, mp_status = $3, qr = $4, qr_image = $5, ticket_url = $6, conferido_em = $7, updated_at = $7 WHERE id = $8',
    [st === 'pago' ? 'pendente' : st, String(j.id), String(j.status || ''), String(td.qr_code), String(td.qr_code_base64 || ''), /^https:\/\//.test(String(td.ticket_url || '')) ? String(td.ticket_url) : '', nowIso(), c.id])
  const atual = (await one('SELECT * FROM cobrancas WHERE id = $1', [c.id]))!
  if (st === 'pago') await aplicarPagamento(b, j) // (improvável na criação, mas pelo mesmo caminho seguro)
  return (await one('SELECT * FROM cobrancas WHERE id = $1', [atual.id]))!
}
const mapStatus = (s: string) => (({ approved: 'pago', pending: 'pendente', in_process: 'pendente', authorized: 'pendente', rejected: 'recusado', cancelled: 'cancelado', refunded: 'estornado', charged_back: 'estornado', expired: 'expirado' } as Record<string, string>)[s] || 'pendente')

/* ---------- confirmação (webhook / consulta) ---------- */
/** Aplica o pagamento CONSULTADO NA API (nunca o corpo do webhook). Confere empresa, referência, id do pagamento e valor.
 *  Retorna false quando o pagamento não é de uma cobrança desta empresa. A passagem para "pago" acontece uma vez só. */
export async function aplicarPagamento(b: any, p: any): Promise<boolean> {
  const ref = String(p?.external_reference || ''), m = /^cob:(\d+)$/.exec(ref); if (!m) return false
  const c = await one('SELECT * FROM cobrancas WHERE id = $1 AND business_id = $2', [Number(m[1]), b.id])
  if (!c || String(c.mp_payment_id || '') !== String(p.id)) return false
  if (Math.abs(Number(p.transaction_amount) - Number(c.valor)) > 0.009) { console.error(`[cobranças] empresa ${b.id}: pagamento ${p.id} com valor diferente da cobrança ${c.id}; ignorado`); return false }
  const agora = nowIso()
  if (p.status === 'approved') {
    const ganhou = await q("UPDATE cobrancas SET status = 'pago', mp_status = 'approved', pago_em = $1, conferido_em = $1, updated_at = $1 WHERE id = $2 AND status <> 'pago' RETURNING id", [agora, c.id])
    if (ganhou.length) await efeitosDoPagamento(b, (await one('SELECT * FROM cobrancas WHERE id = $1', [c.id]))!)
    return true
  }
  const st = mapStatus(String(p.status || ''))
  await q("UPDATE cobrancas SET status = CASE WHEN status = 'pago' THEN status ELSE $1 END, mp_status = $2, conferido_em = $3, updated_at = $3 WHERE id = $4", [st, String(p.status || ''), agora, c.id])
  return true
}
async function efeitosDoPagamento(b: any, c: any) {
  const x = J<any>(b.data, {}), titulo = `Cobrança paga · ${brl(Number(c.valor))}`, corpo = `${x.empresa || 'Empresa'} · ${c.descricao}${c.cliente ? ' · ' + c.cliente : ''} · Pix confirmado pelo Mercado Pago`
  const N = await import('./notify.js')
  for (const uid of new Set([Number(b.owner_id), Number(c.created_by)])) await N.notify(uid, { type: 'order', title: titulo, body: corpo, link: '/', ref: `cobranca-paga:${c.id}:${uid}` }).catch((e: any) => console.error('[cobranças] aviso:', e?.message))
  // entrada no Financeiro do dono (uma vez: a origem cobranca:<id> é conferida antes)
  try {
    const ow = await one('SELECT * FROM users WHERE id = $1', [b.owner_id]); if (!ow) return
    const ja = (await q("SELECT id, data FROM items WHERE user_id = $1 AND type = 'expense' ORDER BY id DESC LIMIT 3000", [ow.id])).some((r: any) => J<any>(r.data, {}).source === `cobranca:${c.id}`)
    if (ja) return
    const { hydrateUser } = await import('./session.js'), { createItem } = await import('../routes/items.js'), { localDate } = await import('./time.js'), { settingsOf } = await import('./account.js')
    const user = hydrateUser(ow)
    await createItem(user, 'expense', { kind: 'income', amount: Number(c.valor), category: 'vendas', date: localDate(settingsOf(user).timezone), method: 'Pix (Mercado Pago)', source: `cobranca:${c.id}`, description: `Cobrança #${c.id} · ${x.empresa || 'Empresa'} · ${c.descricao}${c.cliente ? ' · ' + c.cliente : ''}` })
  } catch (e: any) { console.error('[cobranças] lançamento no Financeiro:', e?.message) }
}
/** Status atualizado: consulta o pagamento na API com o token da empresa (no máximo a cada 8 s por cobrança). */
export async function atualizar(c: any, forcar = false): Promise<any> {
  if (!c?.mp_payment_id || ['pago', 'falhou', 'estornado'].includes(c.status)) return c
  if (!forcar && c.conferido_em && Date.now() - Date.parse(c.conferido_em) < 8000) return c
  const b = await one('SELECT * FROM businesses WHERE id = $1', [c.business_id]); if (!b) return c
  const M = await import('../routes/mpuser.js'), tok = await M.tokenLoja(b); if (!tok) return c
  await q('UPDATE cobrancas SET conferido_em = $1 WHERE id = $2', [nowIso(), c.id])
  try {
    const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(c.mp_payment_id)}`, { headers: { Authorization: `Bearer ${tok}` }, signal: AbortSignal.timeout(10_000) })
    if (r.ok) { const p: any = await r.json().catch(() => null); if (p) await aplicarPagamento(b, p) }
  } catch { /* sem resposta agora: fica o último status conhecido */ }
  const atual = (await one('SELECT * FROM cobrancas WHERE id = $1', [c.id]))!
  if (atual.status === 'pendente' && atual.expira_em && Date.parse(atual.expira_em) < Date.now() - 60_000) { await q("UPDATE cobrancas SET status = 'expirado', updated_at = $1 WHERE id = $2 AND status = 'pendente'", [nowIso(), c.id]); return (await one('SELECT * FROM cobrancas WHERE id = $1', [c.id]))! }
  return atual
}

/* ---------- saída (nada de credencial) ---------- */
export const linkPublico = (c: any) => `${pub()}/x/cobranca/${c.link_token}`
export function visao(c: any, b: any, dono: boolean) {
  const x = J<any>(b?.data, {})
  return { id: Number(c.id), empresa: x.empresa || '', valor: Number(c.valor), descricao: c.descricao, cliente: c.cliente, status: c.status,
    vencimento: c.vencimento || null, expiraEm: c.expira_em || null, pagoEm: c.pago_em || null, criadaEm: c.created_at,
    qr: c.status === 'pendente' ? c.qr : '', qrImage: c.status === 'pendente' && c.qr_image ? `data:image/png;base64,${c.qr_image}` : '',
    link: linkPublico(c), mercadoPago: c.status === 'pendente' ? c.ticket_url || '' : '', teste: !!c.teste && c.teste !== 'false' && c.teste !== 0 ? true : false,
    ...(dono ? { pagamentoId: c.mp_payment_id || '', erro: c.status === 'falhou' ? c.erro : '' } : {}) }
}

/* ---------- chat ---------- */
export async function noChat(u: SessionUser, texto: string, envio = ''): Promise<{ content: string } | null> {
  if (pedidoDeStatus(texto)) {
    const con = await conexaoDaEmpresaAtiva(u); if (!con.ok && con.codigo === 'sem_empresa') return { content: con.motivo }
    const bid = con.ok ? con.b.id : null
    const rows = bid ? await q('SELECT * FROM cobrancas WHERE business_id = $1 AND created_by = $2 ORDER BY id DESC LIMIT 3', [bid, u.id]) : await q('SELECT c.* FROM cobrancas c JOIN businesses b ON b.id = c.business_id WHERE c.created_by = $1 AND b.owner_id = $1 ORDER BY c.id DESC LIMIT 3', [u.id])
    if (!rows.length) return { content: 'Você ainda não criou cobranças por aqui. Para criar, diga por exemplo: “crie uma cobrança de R$ 50,00 para Maria”.' }
    const um = /\b(minhas|ultimas)\b/.test(nrm(texto)) ? rows : rows.slice(0, 1), atuais = [] as any[]
    for (const c of um) atuais.push(await atualizar(c, true))
    const ST: Record<string, string> = { pago: 'paga ✓ (confirmado pelo Mercado Pago)', pendente: 'aguardando pagamento', expirado: 'expirada', cancelado: 'cancelada', recusado: 'recusada', falhou: 'não gerada', estornado: 'estornada', criando: 'sendo gerada' }
    return { content: atuais.map((c) => `Cobrança #${c.id} · ${brl(Number(c.valor))}${c.cliente ? ' · ' + c.cliente : ''}: ${ST[c.status] || c.status}. ⟦cob:${c.id}⟧`).join('\n') }
  }
  const p = lerPedido(texto); if (!p) return null
  const con = await conexaoDaEmpresaAtiva(u)
  if (!con.ok) return { content: con.motivo + (con.codigo.startsWith('mp_') ? ' ⟦btn:/x/sua-empresa|Abrir Sua empresa⟧' : '') }
  if (p.valor === null) return { content: `Qual o valor da cobrança? Diga, por exemplo: “crie uma cobrança de R$ 50,00${p.cliente ? ' para ' + p.cliente : ''}”.` }
  try {
    const { c, existente } = await criar(u, con.b, { ...p, valor: p.valor, envio }, con.teste)
    if (c.status === 'falhou') throw new ErroCobranca('Esta cobrança não foi gerada pelo Mercado Pago. Peça de novo para tentar outra vez.', 'falhou')
    const venc = c.vencimento ? ` · vence em ${new Date(Date.parse(c.vencimento) - 3 * 3600_000).toISOString().slice(0, 10).split('-').reverse().join('/')}` : ''
    return { content: `${existente ? 'Esta cobrança já tinha sido criada há instantes (não criei outra igual).' : `Cobrança criada na ${con.nome} pelo Mercado Pago${con.teste ? ' (ambiente de teste)' : ''}.`} ${brl(Number(c.valor))}${c.cliente ? ' para ' + c.cliente : ''} · ${c.descricao}${venc}. O pagamento é confirmado automaticamente quando o Mercado Pago avisar. ⟦cob:${c.id}⟧` }
  } catch (e: any) {
    if (e instanceof ErroCobranca) return { content: e.message }
    console.error('[cobranças] criar:', e?.message); return { content: 'Não consegui gerar a cobrança agora. Nenhuma cobrança foi enviada: tente de novo em instantes.' }
  }
}
