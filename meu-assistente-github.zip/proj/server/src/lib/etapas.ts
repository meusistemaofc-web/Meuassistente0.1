// Etapas reais de um envio do chat (o que o assistente está fazendo agora), para o indicador compacto do app.
//
// Quem processa marca a etapa no ponto em que ela de fato começa — etapa('internet') ao iniciar uma pesquisa, etapa('audio')
// ao transcrever, etapa('executando') ao rodar uma ação… — sem precisar receber nada por parâmetro: a etapa vale para o
// pedido em andamento (AsyncLocalStorage). Cada pedido publica a etapa atual no canal de eventos do envio (SSE "etapa"), na
// situação do envio e na lista de tarefas (tarefas em segundo plano ou abertas em outro aparelho).
// Os textos ficam AQUI (uma só fonte); o app só mostra. Etapa repetida não é republicada (sem troca à toa).
import { AsyncLocalStorage } from 'node:async_hooks'

export const TEXTOS = {
  fila: 'Na fila…',
  analisando: 'Analisando sua mensagem…',
  pensando: 'Pensando…',
  buscando: 'Buscando informações…',
  cerebro: 'Consultando o Cérebro Central…',
  internet: 'Pesquisando na internet…',
  documentos: 'Analisando documentos…',
  imagem: 'Lendo imagem…',
  audio: 'Transcrevendo áudio…',
  ferramentas: 'Consultando ferramentas…',
  organizando: 'Organizando informações…',
  planejando: 'Planejando etapas…',
  executando: 'Executando tarefa…',
  conferindo: 'Verificando as informações…',
  preparando: 'Preparando resposta…',
  digitando: 'Digitando…',
  // busca visual de produtos (foto no modo Busca)
  visual_analisando: 'Analisando imagem…',
  visual_identificando: 'Identificando produto…',
  visual_pesquisando: 'Buscando nas lojas…',
  visual_comparando: 'Comparando resultados…',
} as const
export type Etapa = keyof typeof TEXTOS
export interface EtapaAtual { e: Etapa; t: string; em: number }

const ALS = new AsyncLocalStorage<(e: Etapa) => void>()
/** Etapa atual de cada envio em andamento (por id da tarefa) — para quem consulta sem estar no canal de eventos. */
const ATUAL = new Map<string, EtapaAtual>()

/** Roda o processamento de um envio publicando suas etapas (aoMudar recebe só mudanças reais). */
export function comEtapas<T>(id: string, aoMudar: (x: EtapaAtual) => void, fn: () => Promise<T>): Promise<T> {
  let ultima: Etapa | null = null, acabou = false
  const marcar = (e: Etapa) => {
    if (acabou || e === ultima || !(e in TEXTOS)) return // trabalho que segue depois da resposta (ex.: pesquisa em segundo plano) não mexe mais no indicador
    ultima = e; const x = { e, t: TEXTOS[e], em: Date.now() }; ATUAL.set(id, x)
    try { aoMudar(x) } catch { /* quem escuta não derruba o processamento */ }
  }
  return ALS.run(marcar, async () => { try { return await fn() } finally { acabou = true; ATUAL.delete(id) } })
}
/** Marca a etapa do envio em andamento (fora de um envio, não faz nada). */
export function etapa(e: Etapa) { try { ALS.getStore()?.(e) } catch { /* nada */ } }
export const etapaAtual = (id: string): EtapaAtual | null => ATUAL.get(id) || null
/** Ferramenta da IA → etapa: busca (leitura de catálogo/empresas/produtos), consulta (outras leituras) ou execução (grava). */
export function etapaDaFerramenta(nome: string, somenteLeitura: boolean): Etapa {
  if (/pesquis|web|internet/.test(nome)) return 'internet'
  if (/busc|search|catalog|produto|vitrine|encontrar|procurar/.test(nome)) return 'buscando'
  if (/document|arquivo|pdf/.test(nome)) return 'documentos'
  return somenteLeitura ? 'ferramentas' : 'executando'
}
