// MERCADO DE MCOINS — cotação, gráfico, compra/venda e carteira POR MOEDA, sobre a estrutura que já existe:
// a MESMA carteira (coin_balances), o MESMO livro-razão (coin_ledger), os MESMOS pedidos (coin_orders), a MESMA emissão
// (coins.distributed/total_supply), as MESMAS permissões e bloqueios da Central de MCoins (coin_permissions/coin_policies)
// e a MESMA confirmação de pedidos pelo administrador (coin-central.resolverPedido). Nada de saldo paralelo.
//
// Habilitação: só moedas com linha em coin_markets E enabled = true são negociáveis. Moedas promocionais existentes ficam como
// estão (nenhuma conversão automática). A Central antiga (preço fixo global) deixa de negociar moedas com mercado ligado.
//
// FÓRMULA DA COTAÇÃO (impacto linear com liquidez virtual, limitado) — calculada SÓ no servidor:
//   impacto  = s × q ÷ L                      (s = sensibilidade 0–1, q = quantidade do negócio, L = liquidez em moedas)
//   compra:  P1 = P0 × (1 + impacto)          venda: P1 = P0 × (1 − impacto)
//   limites: |P1/P0 − 1| ≤ variação máxima por negócio; P1 dentro da faixa diária (cotação de 24 h atrás ± variação máx. diária);
//            P1 entre o piso e o teto da moeda (teto obrigatório → sem valorização infinita); a emissão total limita as compras.
//   preço do negócio = média entre P0 e P1 (fatiar um negócio grande em vários pequenos não barateia), arredondado em 4 casas;
//   bruto = preço × q; taxa = bruto × taxa% + taxa fixa; compra: total = bruto + taxa; venda: total = bruto − taxa.
//   Ida e volta (comprar e vender a mesma quantidade) sempre perde ~s²q²/2L² + taxas: não existe ciclo de lucro garantido.
// Proteções: permissão/bloqueio da Central, pausa, limites por negócio/dia, detenção máxima por conta (% da emissão), intervalo
// mínimo entre negócios da mesma conta, tolerância de variação entre a prévia e a confirmação, chave de idempotência,
// trava por moeda + transação + atualização otimista (version) da cotação, histórico de cotações encadeado por hash.
// Liquidação: "manual" = pedido fica pendente e o administrador confirma depois de conferir o pagamento feito FORA do app
// (a cotação só muda na confirmação); "simulada" = efeito imediato sem cobrança nem pagamento (valores de referência).
// Não há promessa de valorização: a cotação sobe e desce conforme os negócios registrados.
import { createHash } from 'node:crypto'
import { q, one, db, J, nowIso, isoOf } from '../db/index.js'
import { fail } from './http.js'
import { withLock } from './business-sync.js'
import { audit } from './account.js'
import * as C from './coins.js'

const num = (v: any) => Number(v) || 0
const r2 = (n: number) => Math.round(n * 100 + (n >= 0 ? 1e-7 : -1e-7)) / 100 // centavos, meio para cima (sem erro de ponto flutuante)
const r4 = (n: number) => Math.round(n * 1e4) / 1e4
const r6 = (n: number) => Math.round(n * 1e6) / 1e6
const tf = (v: any) => v === true || v === 1 || v === 't' || v === '1' || v === 'true'
const IDEM = /^[A-Za-z0-9:_.-]{8,80}$/

export interface Regras {
  sensibilidade: number; liquidez: number; varMaxOperacaoPct: number; varMaxDiaPct: number
  taxaCompraPct: number; taxaVendaPct: number; taxaFixa: number
  minOperacao: number; maxOperacao: number; limiteDiarioUsuario: number; maxDetencaoPct: number; intervaloSeg: number; toleranciaPct: number
}
export const REGRAS_PADRAO = (total: number): Regras => ({ sensibilidade: 0.5, liquidez: Math.max(1000, Math.round(total * 0.1)), varMaxOperacaoPct: 5, varMaxDiaPct: 20,
  taxaCompraPct: 0, taxaVendaPct: 0, taxaFixa: 0, minOperacao: 1, maxOperacao: 1000, limiteDiarioUsuario: 0, maxDetencaoPct: 10, intervaloSeg: 10, toleranciaPct: 2 })
const FAIXAS: Record<keyof Regras, [number, number, boolean]> = { // [mín, máx, inteiro]
  sensibilidade: [0, 1, false], liquidez: [1, 1e12, true], varMaxOperacaoPct: [0.01, 50, false], varMaxDiaPct: [0.01, 300, false],
  taxaCompraPct: [0, 20, false], taxaVendaPct: [0, 20, false], taxaFixa: [0, 1000, false],
  minOperacao: [1, 1e9, true], maxOperacao: [1, 1e9, true], limiteDiarioUsuario: [0, 1e12, true], maxDetencaoPct: [0.01, 100, false], intervaloSeg: [0, 86400, true], toleranciaPct: [0, 20, false],
}

export interface Mercado { coinId: number; ligado: boolean; compras: boolean; vendas: boolean; pausado: boolean; motivoPausa: string; liquidacao: 'manual' | 'simulada'; simulacaoConfirmada: boolean
  preco: number; precoInicial: number; piso: number; teto: number; regras: Regras; versao: number; atualizadoEm: string | null }
function mOut(r: any, total: number): Mercado {
  const base = REGRAS_PADRAO(total), cfg = J<any>(r.config, {}), regras = { ...base } as Regras
  for (const k of Object.keys(base) as (keyof Regras)[]) if (cfg[k] !== undefined && isFinite(Number(cfg[k]))) regras[k] = Number(cfg[k])
  return { coinId: Number(r.coin_id), ligado: tf(r.enabled), compras: tf(r.buy_enabled), vendas: tf(r.sell_enabled), pausado: tf(r.paused), motivoPausa: r.pause_reason || '', liquidacao: r.settlement === 'simulada' ? 'simulada' : 'manual', simulacaoConfirmada: tf(r.simulated_ack),
    preco: num(r.price), precoInicial: num(r.initial_price), piso: num(r.price_floor), teto: num(r.price_ceiling), regras, versao: num(r.version), atualizadoEm: isoOf(r.updated_at) }
}
export async function mercadoDe(coinId: number, d: any = null): Promise<Mercado | null> {
  const r = d ? (await d.query('SELECT * FROM coin_markets WHERE coin_id = $1', [coinId]))[0] : await one('SELECT * FROM coin_markets WHERE coin_id = $1', [coinId])
  if (!r) return null
  const c = await one('SELECT total_supply FROM coins WHERE id = $1', [coinId])
  return mOut(r, num(c?.total_supply))
}
/** Moeda negociável AGORA no mercado (ligado pelo administrador, moeda ativa, sistema de MCoins ligado). */
export async function negociavel(coinId: number) { const m = await mercadoDe(coinId); return !!m && m.ligado }

/* ---------- histórico de cotações (só inserção, encadeado por hash) ---------- */
const hashDe = (prev: string, coinId: number, price: number, reason: string, orderId: any, qty: any, at: string) => createHash('sha256').update([prev, coinId, price.toFixed(6), reason, orderId ?? '', qty ?? '', at].join('|')).digest('hex')
async function registrarPreco(t: any, coinId: number, price: number, prev: number | null, reason: string, extra: { orderId?: number; qty?: number; volume?: number; actor?: string }, now: string) {
  const ult = (await t.query('SELECT hash FROM coin_prices WHERE coin_id = $1 ORDER BY id DESC LIMIT 1', [coinId]))[0], ph = ult?.hash || ''
  const h = hashDe(ph, coinId, price, reason, extra.orderId, extra.qty, now)
  await t.query('INSERT INTO coin_prices (coin_id, price, prev_price, reason, order_id, qty, volume, actor, prev_hash, hash, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)',
    [coinId, r6(price), prev === null ? null : r6(prev), reason, extra.orderId ?? null, extra.qty ?? null, extra.volume ?? null, extra.actor || null, ph || null, h, now])
}
/** Confere a cadeia de hashes do histórico de cotações (detecta linha alterada, apagada ou inserida fora de ordem). */
export async function verificarHistorico(coinId: number) {
  const rows = await q('SELECT * FROM coin_prices WHERE coin_id = $1 ORDER BY id', [coinId]) as any[]; let prev = '', ultimo = 0
  for (const r of rows) {
    const at = isoOf(r.created_at) || String(r.created_at)
    if ((r.prev_hash || '') !== prev) return { ok: false, registros: rows.length, problema: `Registro #${r.id}: encadeamento quebrado (registro anterior alterado ou removido).` }
    if (hashDe(prev, coinId, num(r.price), r.reason, r.order_id === null || r.order_id === undefined ? undefined : Number(r.order_id), r.qty === null || r.qty === undefined ? undefined : Number(r.qty), at) !== r.hash) return { ok: false, registros: rows.length, problema: `Registro #${r.id}: conteúdo alterado depois de gravado.` }
    prev = r.hash; ultimo = num(r.price)
  }
  const m = await mercadoDe(coinId)
  if (m && rows.length && Math.abs(ultimo - m.preco) > 1e-6) return { ok: false, registros: rows.length, problema: 'A cotação atual não confere com o último registro do histórico.' }
  return { ok: true, registros: rows.length, problema: '' }
}
/** Referência da faixa diária: a cotação que valia 24 h atrás; se o mercado abriu depois disso, a primeira cotação registrada. */
async function referenciaDia(coinId: number, now: string, d: any = null) {
  const ini = new Date(Date.parse(now) - 86400_000).toISOString(), p = await precoEm(coinId, ini, d); if (p !== null) return p
  const sql = 'SELECT price FROM coin_prices WHERE coin_id = $1 ORDER BY id LIMIT 1', r = d ? (await d.query(sql, [coinId]))[0] : await one(sql, [coinId]); return r ? num(r.price) : null
}
async function precoEm(coinId: number, iso: string, d: any = null) {
  const sql = 'SELECT price FROM coin_prices WHERE coin_id = $1 AND created_at <= $2 ORDER BY id DESC LIMIT 1'
  const r = d ? (await d.query(sql, [coinId, iso]))[0] : await one(sql, [coinId, iso]); return r ? num(r.price) : null
}

/* ---------- cotação (pura: usada na prévia e no negócio) ---------- */
export function calcular(kind: 'compra' | 'venda', m: Mercado, qtd: number, ref24h: number | null) {
  const R = m.regras, P0 = m.preco, imp = (R.sensibilidade * qtd) / R.liquidez
  let P1 = kind === 'compra' ? P0 * (1 + imp) : P0 * (1 - imp)
  const op = R.varMaxOperacaoPct / 100; P1 = kind === 'compra' ? Math.min(P1, P0 * (1 + op)) : Math.max(P1, P0 * (1 - op))
  const ref = ref24h && ref24h > 0 ? ref24h : P0, dia = R.varMaxDiaPct / 100
  if (kind === 'compra') P1 = Math.min(P1, Math.max(P0, ref * (1 + dia))); else P1 = Math.max(P1, Math.min(P0, ref * (1 - dia)))
  if (m.teto > 0) P1 = Math.min(P1, Math.max(P0, m.teto)); P1 = Math.max(P1, Math.min(P0, m.piso), 0.0001)
  P1 = r6(P1)
  const unit = r4((P0 + P1) / 2), bruto = r2(unit * qtd), taxaPct = kind === 'compra' ? R.taxaCompraPct : R.taxaVendaPct
  const taxa = r2((bruto * taxaPct) / 100 + (qtd > 0 ? R.taxaFixa : 0)), total = kind === 'compra' ? r2(bruto + taxa) : Math.max(0, r2(bruto - taxa))
  return { precoAntes: P0, precoDepois: P1, precoUnitario: unit, bruto, taxa, taxaPct, taxaFixa: R.taxaFixa, total, variacaoPct: P0 > 0 ? Math.round(((P1 - P0) / P0) * 1e4) / 100 : 0, travadoNoLimite: Math.abs(P1 - (kind === 'compra' ? P0 * (1 + imp) : P0 * (1 - imp))) > 1e-9 }
}
/** "Quanto quero gastar": maior quantidade inteira cujo total (com taxas) cabe no valor. */
function qtdPorValor(m: Mercado, valor: number, ref24h: number | null) {
  let lo = 0, hi = Math.min(m.regras.maxOperacao, 1e9)
  while (lo < hi) { const mid = Math.ceil((lo + hi) / 2); if (calcular('compra', m, mid, ref24h).total <= valor) lo = mid; else hi = mid - 1 }
  return lo
}

/* ---------- regras de acesso ---------- */
async function permitido(userId: number, coinId: number, kind: 'compra' | 'venda'): Promise<{ ok: boolean; motivo: string }> {
  const u = await one('SELECT status FROM users WHERE id = $1', [userId]); if (!u || u.status !== 'active') return { ok: false, motivo: 'Conta indisponível.' }
  const Z = await import('./coin-central.js')
  // bloqueios explícitos da Central valem aqui também (política da moeda e permissões por usuário/empresa/grupo);
  // as chaves GLOBAIS de compra/venda da Central não ligam este mercado: ele é habilitado moeda a moeda
  const pol = await Z.politicaMoeda(coinId); if (pol[kind] === false) return { ok: false, motivo: 'Esta modalidade está desativada para esta moeda.' }
  const r = await Z.avaliar(userId, kind === 'compra' ? 'comprar' : 'vender', coinId, 'todos'); return r
}
export async function situacao(userId: number, coinId: number) {
  const cfg = await C.coinsCfg(), c: any = await C.coinById(coinId), m = await mercadoDe(coinId)
  const base = (motivo: string) => ({ compra: { ok: false, motivo }, venda: { ok: false, motivo } })
  if (!cfg.ativo) return base('O sistema de MCoins está desligado.')
  if (!c || c.status !== 'ativa') return base('Esta moeda está suspensa ou ainda não foi publicada.')
  if (!m || !m.ligado) return base('Esta moeda não tem mercado habilitado.')
  if (m.pausado) return base(`Negociações pausadas pelo administrador${m.motivoPausa ? ': ' + m.motivoPausa : '.'}`)
  const out: any = {}
  for (const k of ['compra', 'venda'] as const) {
    if (!(k === 'compra' ? m.compras : m.vendas)) { out[k] = { ok: false, motivo: k === 'compra' ? 'Compras bloqueadas pelo administrador.' : 'Vendas não autorizadas para esta moeda.' }; continue }
    out[k] = await permitido(userId, coinId, k)
  }
  return out as { compra: { ok: boolean; motivo: string }; venda: { ok: boolean; motivo: string } }
}

async function limitesDoUsuario(t: any, kind: 'compra' | 'venda', m: Mercado, coin: any, userId: number, qtd: number, now: string) {
  const R = m.regras
  if (!Number.isInteger(qtd) || qtd < 1) fail(400, 'Informe uma quantidade inteira de moedas.', 'invalid', 'quantidade')
  if (qtd < R.minOperacao || qtd > R.maxOperacao) fail(400, `A quantidade deve ficar entre ${R.minOperacao} e ${R.maxOperacao} moedas por negócio.`, 'limite', 'quantidade')
  const ult = (await t.query("SELECT created_at FROM coin_orders WHERE user_id = $1 AND coin_id = $2 AND market = TRUE AND status IN ('pendente','concluida') ORDER BY id DESC LIMIT 1", [userId, coin.id]))[0]
  if (ult && R.intervaloSeg > 0) { const dt = (Date.parse(now) - Date.parse(isoOf(ult.created_at) || now)) / 1000; if (dt < R.intervaloSeg) fail(429, `Aguarde ${Math.ceil(R.intervaloSeg - dt)} s entre um negócio e outro nesta moeda.`, 'intervalo') }
  if (R.limiteDiarioUsuario > 0) {
    const desde = new Date(Date.parse(now) - 86400_000).toISOString()
    const ja = num((await t.query("SELECT COALESCE(SUM(qty),0) AS n FROM coin_orders WHERE user_id = $1 AND coin_id = $2 AND kind = $3 AND market = TRUE AND status IN ('pendente','concluida') AND created_at >= $4", [userId, coin.id, kind, desde]))[0]?.n)
    if (ja + qtd > R.limiteDiarioUsuario) fail(400, `Limite de ${R.limiteDiarioUsuario} moedas em ${kind === 'compra' ? 'compras' : 'vendas'} a cada 24 h (já usado: ${ja}).`, 'limite', 'quantidade')
  }
  if (kind === 'compra') {
    const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coin.id, userId]))[0]?.balance)
    const pend = num((await t.query("SELECT COALESCE(SUM(qty),0) AS n FROM coin_orders WHERE user_id = $1 AND coin_id = $2 AND kind = 'compra' AND market = TRUE AND status = 'pendente'", [userId, coin.id]))[0]?.n)
    const maxConta = Math.floor((num(coin.total) * R.maxDetencaoPct) / 100)
    if (saldo + pend + qtd > maxConta) fail(400, `Cada conta pode ter no máximo ${maxConta} ${coin.simbolo} (${R.maxDetencaoPct}% da emissão). Você tem ${saldo}${pend ? ` + ${pend} em compras pendentes` : ''}.`, 'limite', 'quantidade')
    const disp = num((await t.query('SELECT total_supply - distributed AS d FROM coins WHERE id = $1', [coin.id]))[0]?.d)
    const reserv = num((await t.query("SELECT COALESCE(SUM(qty),0) AS n FROM coin_orders WHERE coin_id = $1 AND kind = 'compra' AND market = TRUE AND status = 'pendente'", [coin.id]))[0]?.n)
    if (qtd > disp - reserv) fail(409, `Não há moedas disponíveis na emissão para esta compra (disponíveis: ${Math.max(0, disp - reserv)}).`, 'sem_estoque')
  } else {
    const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coin.id, userId]))[0]?.balance)
    if (saldo < qtd) fail(409, `Saldo insuficiente: você tem ${saldo} ${coin.simbolo}.`, 'saldo_insuficiente')
  }
}

/* ---------- prévia e negócio ---------- */
async function precisa(userId: number, coinId: number, kind: 'compra' | 'venda') {
  const coin: any = await C.activeCoin(coinId), m = await mercadoDe(coinId)
  if (!m || !m.ligado) fail(404, 'Esta moeda não tem mercado habilitado.', 'sem_mercado')
  const s = await situacao(userId, coinId); if (!s[kind].ok) fail(403, s[kind].motivo, 'forbidden')
  return { coin, m: m! }
}
export async function cotar(userId: number, coinId: number, b: any) {
  const kind = b.tipo === 'venda' ? 'venda' : 'compra', { coin, m } = await precisa(userId, coinId, kind)
  const ref = await referenciaDia(coinId, nowIso())
  let qtd = Number(b.quantidade)
  if (kind === 'compra' && b.valor !== undefined && b.valor !== null && b.valor !== '') { const v = Number(b.valor); if (!(v > 0) || v > 1e9) fail(400, 'Informe um valor válido.', 'invalid', 'valor'); qtd = qtdPorValor(m, v, ref); if (qtd < 1) fail(400, 'Esse valor não compra nem 1 moeda (com as taxas).', 'invalid', 'valor') }
  if (!Number.isInteger(qtd) || qtd < 1) fail(400, 'Informe uma quantidade inteira de moedas.', 'invalid', 'quantidade')
  const c = calcular(kind, m, qtd, ref)
  return { tipo: kind, moeda: { id: coin.id, nome: coin.nome, simbolo: coin.simbolo }, quantidade: qtd, ...c, liquidacao: m.liquidacao, simulado: m.liquidacao === 'simulada', toleranciaPct: m.regras.toleranciaPct, saldoAtual: await C.balanceOf(coinId, userId),
    aviso: m.liquidacao === 'simulada' ? 'Modo simulado: nenhum pagamento é cobrado ou feito; os valores são de referência.' : kind === 'compra' ? 'O pedido fica pendente até o administrador confirmar o pagamento combinado fora do aplicativo.' : 'As moedas ficam reservadas até o administrador confirmar o pagamento da venda feito fora do aplicativo.' }
}
const opCode = (p: string) => `${p}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`
async function lancar(t: any, coinId: number, userId: number, kind: string, delta: number, idem: string, actor: string, nota: string, now: string) {
  await t.query('INSERT INTO coin_balances (coin_id, user_id, balance, updated_at) VALUES ($1,$2,0,$3) ON CONFLICT (coin_id, user_id) DO NOTHING', [coinId, userId, now])
  if (delta > 0) await t.query('UPDATE coin_balances SET balance = balance + $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3', [delta, coinId, userId, now])
  else { const r = await t.query('UPDATE coin_balances SET balance = balance - $1, updated_at = $4 WHERE coin_id = $2 AND user_id = $3 AND balance >= $1 RETURNING balance', [-delta, coinId, userId, now]); if (!r.length) fail(409, 'Saldo de moedas insuficiente.', 'saldo_insuficiente') }
  const saldo = num((await t.query('SELECT balance FROM coin_balances WHERE coin_id = $1 AND user_id = $2', [coinId, userId]))[0]?.balance)
  await t.query('INSERT INTO coin_ledger (coin_id, user_id, kind, delta, balance_after, order_id, idem, actor, note, discount, created_at, issuer_business_id, linked_business_id) VALUES ($1,$2,$3,$4,$5,NULL,$6,$7,$8,NULL,$9,(SELECT business_id FROM coins WHERE id = $1),NULL)', [coinId, userId, kind, delta, saldo, idem, actor, nota, now])
  return { saldo, id: Number((await t.query('SELECT id FROM coin_ledger WHERE coin_id = $1 AND idem = $2', [coinId, idem]))[0].id) }
}
/** Aplica o negócio na cotação (dentro da transação, com atualização otimista). Devolve a cotação antes/depois. */
async function moverPreco(t: any, coinId: number, kind: 'compra' | 'venda', qtd: number, orderId: number, volume: number, actor: string, now: string) {
  const m = (await mercadoDe(coinId, t))!, ref = await referenciaDia(coinId, now, t)
  const c = calcular(kind, m, qtd, ref)
  const u = await t.query('UPDATE coin_markets SET price = $1, version = version + 1, updated_at = $2 WHERE coin_id = $3 AND version = $4 RETURNING version', [c.precoDepois, now, coinId, m.versao])
  if (!u.length) fail(409, 'A cotação mudou durante o negócio. Tente de novo.', 'cotacao_mudou')
  await registrarPreco(t, coinId, c.precoDepois, m.preco, kind, { orderId, qty: qtd, volume, actor }, now)
  return c
}
export async function negociar(kind: 'compra' | 'venda', u: { id: number }, coinId: number, b: any) {
  const { coin, m } = await precisa(u.id, coinId, kind), idem = String(b.idem || '').trim()
  if (!IDEM.test(idem)) fail(400, 'Chave da operação inválida (8 a 80 caracteres: letras, números, : _ . -).', 'invalid', 'idem')
  const ja = await one('SELECT * FROM coin_orders WHERE user_id = $1 AND idem = $2', [u.id, idem]); if (ja) return { ok: true, duplicado: true, pedido: await pedidoOut(ja) }
  const qtd = Number(b.quantidade), esperado = Number(b.precoEsperado)
  if (!(esperado > 0)) fail(400, 'Faça a prévia antes de confirmar (cotação esperada ausente).', 'invalid', 'precoEsperado')
  const op = opCode(kind === 'compra' ? 'MCM' : 'MVM'), imediata = m.liquidacao === 'simulada'
  try {
    const r = await withLock(`coin:${coin.id}`, async () => {
      const dup = await one('SELECT * FROM coin_orders WHERE user_id = $1 AND idem = $2', [u.id, idem]); if (dup) return { dup }
      return db().tx(async (t) => {
        const now = nowIso(), mm = (await mercadoDe(coin.id, t))!
        if (!mm.ligado || mm.pausado || !(kind === 'compra' ? mm.compras : mm.vendas)) fail(409, 'As negociações desta moeda foram pausadas ou bloqueadas agora.', 'pausado')
        await limitesDoUsuario(t, kind, mm, coin, u.id, qtd, now)
        const ref = await referenciaDia(coin.id, now, t), cot = calcular(kind, mm, qtd, ref)
        if (Math.abs(cot.precoUnitario - esperado) / esperado > mm.regras.toleranciaPct / 100 + 1e-9) fail(409, `A cotação mudou desde a prévia (agora ${cot.precoUnitario.toFixed(4)} por moeda). Confira a nova prévia.`, 'cotacao_mudou')
        await t.query('INSERT INTO coin_orders (op_code, kind, coin_id, coin_code, user_id, qty, unit_price, gross, fee, net, settlement, status, idem, note, created_at, market, price_before, price_after) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,TRUE,$16,$17)',
          [op, kind, coin.id, coin.codigo || null, u.id, qtd, cot.precoUnitario, cot.bruto, cot.taxa, cot.total, imediata ? 'interna' : 'manual', 'pendente', idem, `Mercado · ${imediata ? 'simulado' : 'liquidação manual'}`, now, cot.precoAntes, null])
        const id = Number((await t.query('SELECT id FROM coin_orders WHERE op_code = $1', [op]))[0].id)
        if (kind === 'venda') { const l = await lancar(t, coin.id, u.id, 'venda', -qtd, `venda:${id}`, `usuario ${u.id}`, `Venda ${op} (mercado)`, now); await t.query('UPDATE coin_orders SET ledger_id = $1 WHERE id = $2', [l.id, id]) }
        if (imediata) await liquidar(t, { id, kind, coin_id: coin.id, user_id: u.id, qty: qtd, gross: cot.bruto, op_code: op }, `usuario ${u.id}`, now)
        return { o: (await t.query('SELECT * FROM coin_orders WHERE id = $1', [id]))[0] }
      })
    })
    if ('dup' in r && r.dup) return { ok: true, duplicado: true, pedido: await pedidoOut(r.dup) }
    const o = await pedidoOut((r as any).o)
    await audit(u.id, `coins.mercado.${kind}`, coin.id, { operacao: op, quantidade: qtd, unitario: o.precoUnitario, total: o.total, status: o.status, liquidacao: m.liquidacao })
    return { ok: true, duplicado: false, pedido: o, saldo: await C.balanceOf(coin.id, u.id), cotacao: (await mercadoDe(coin.id))!.preco }
  } catch (e: any) { try { await audit(u.id, `coins.mercado.${kind}.falha`, coin.id, { erro: String(e?.message || e).slice(0, 160), quantidade: qtd }) } catch { /* segue */ } throw e }
}
/** Efetiva um negócio do mercado: emissão/crédito (compra) ou devolução à emissão (venda) + movimento da cotação.
 *  Chamado na hora (simulado) ou quando o administrador confirma o pedido (manual, via resolverPedido). */
export async function liquidar(t: any, o: any, actor: string, now: string) {
  const id = Number(o.id), coinId = Number(o.coin_id), qtd = num(o.qty), uid = Number(o.user_id)
  const ok = await t.query("UPDATE coin_orders SET status = 'concluida', resolved_at = $1 WHERE id = $2 AND status = 'pendente' RETURNING id", [now, id]); if (!ok.length) fail(409, 'Este pedido já foi resolvido.', 'resolvido')
  if (o.kind === 'compra') {
    const e = await t.query('UPDATE coins SET distributed = distributed + $1, updated_at = $3 WHERE id = $2 AND distributed + $1 <= total_supply RETURNING id', [qtd, coinId, now]); if (!e.length) fail(409, 'Não há moedas disponíveis na emissão para esta compra.', 'sem_estoque')
    const l = await lancar(t, coinId, uid, 'compra', qtd, `compra:${id}`, actor, `Compra ${o.op_code} (mercado)`, now); await t.query('UPDATE coin_orders SET ledger_id = $1 WHERE id = $2', [l.id, id])
  } else {
    const e = await t.query('UPDATE coins SET distributed = distributed - $1, updated_at = $3 WHERE id = $2 AND distributed - $1 >= redeemed RETURNING id', [qtd, coinId, now]); if (!e.length) fail(409, 'Não foi possível devolver as moedas à emissão.', 'inconsistente')
  }
  const c = await moverPreco(t, coinId, o.kind, qtd, id, num(o.gross), actor, now)
  await t.query('UPDATE coin_orders SET price_before = $1, price_after = $2 WHERE id = $3', [c.precoAntes, c.precoDepois, id])
}

/* ---------- leitura ---------- */
async function pedidoOut(r: any) { return { id: Number(r.id), codigo: r.op_code, tipo: r.kind, moedaId: Number(r.coin_id), quantidade: num(r.qty), precoUnitario: num(r.unit_price), bruto: num(r.gross), taxa: num(r.fee), total: num(r.net), liquidacao: r.settlement === 'interna' ? 'simulada' : 'manual', status: r.status, cotacaoAntes: r.price_before == null ? null : num(r.price_before), cotacaoDepois: r.price_after == null ? null : num(r.price_after), em: isoOf(r.created_at), resolvidoEm: isoOf(r.resolved_at) } }
const RANGES: Record<string, number> = { '24h': 1, '7d': 7, '30d': 30, '90d': 90 }
export async function serie(coinId: number, range: string, m: Mercado) {
  const dias = RANGES[range] || 1, ini = new Date(Date.now() - dias * 86400_000).toISOString(), agora = nowIso()
  const rows = await q('SELECT price, created_at FROM coin_prices WHERE coin_id = $1 AND created_at > $2 ORDER BY id', [coinId, ini]) as any[]
  const antes = await precoEm(coinId, ini), pts: { t: string; v: number }[] = []
  // pontos reais: a cotação que valia no início do período (se já existia), cada mudança registrada e a cotação de agora
  if (antes !== null) pts.push({ t: ini, v: antes })
  for (const r of rows) pts.push({ t: isoOf(r.created_at)!, v: num(r.price) })
  if (pts.length) pts.push({ t: agora, v: m.preco })
  return pts
}
export async function detalhe(userId: number, coinId: number, range = '24h') {
  const cfg = await C.coinsCfg(), c: any = await C.coinById(coinId), m = await mercadoDe(coinId)
  if (!cfg.ativo || !c || c.status !== 'ativa' || !m || !m.ligado) fail(404, 'Esta moeda não tem mercado habilitado.', 'sem_mercado')
  const rg = RANGES[range] ? range : '24h', pts = await serie(coinId, rg, m!), vs = pts.map((p) => p.v)
  const ini = new Date(Date.now() - (RANGES[rg]) * 86400_000).toISOString()
  const vol = await one("SELECT COUNT(*) AS n, COALESCE(SUM(qty),0) AS q, COALESCE(SUM(gross),0) AS v FROM coin_orders WHERE coin_id = $1 AND market = TRUE AND status = 'concluida' AND resolved_at >= $2", [coinId, ini])
  const ref24 = await referenciaDia(coinId, nowIso())
  const recentes = (await q("SELECT kind, qty, unit_price, resolved_at FROM coin_orders WHERE coin_id = $1 AND market = TRUE AND status = 'concluida' ORDER BY resolved_at DESC, id DESC LIMIT 20", [coinId]) as any[]).map((r) => ({ tipo: r.kind, quantidade: num(r.qty), preco: num(r.unit_price), em: isoOf(r.resolved_at) }))
  return {
    moeda: { id: c.id, nome: c.nome, simbolo: c.simbolo, codigo: c.codigo || '', logo: c.logo, cor1: c.cor1, cor2: c.cor2, modeloInfo: c.modeloInfo, empresa: c.empresa, businessId: c.businessId, descricao: c.descricao, desconto: c.desconto },
    cotacao: m!.preco, variacao24h: ref24 && ref24 > 0 ? Math.round(((m!.preco - ref24) / ref24) * 1e4) / 100 : 0,
    periodo: { range: rg, pontos: pts, variacaoPct: vs.length && vs[0] > 0 ? Math.round(((vs[vs.length - 1] - vs[0]) / vs[0]) * 1e4) / 100 : 0, maxima: vs.length ? Math.max(...vs) : m!.preco, minima: vs.length ? Math.min(...vs) : m!.preco, abertura: vs.length ? vs[0] : m!.preco, negocios: num(vol?.n), volumeMoedas: num(vol?.q), volumeReais: r2(num(vol?.v)) },
    oferta: { total: c.total, circulante: c.emCirculacao, emitida: c.distribuidas, disponivel: c.disponiveis, utilizadaEmDescontos: c.utilizadas },
    recentes, situacao: await situacao(userId, coinId), posicao: await posicao(userId, coinId, m!.preco),
    regras: { liquidacao: m!.liquidacao, simulado: m!.liquidacao === 'simulada', taxaCompraPct: m!.regras.taxaCompraPct, taxaVendaPct: m!.regras.taxaVendaPct, taxaFixa: m!.regras.taxaFixa, minOperacao: m!.regras.minOperacao, maxOperacao: m!.regras.maxOperacao, limiteDiarioUsuario: m!.regras.limiteDiarioUsuario, maxDetencaoPct: m!.regras.maxDetencaoPct, piso: m!.piso, teto: m!.teto },
    alertaSimbolo: `MC:${c.id}`,
    aviso: `${m!.liquidacao === 'simulada' ? 'Cotação simulada e controlada pela plataforma: não representa um mercado real, ' : 'Cotação formada pelos negócios registrados no Meu Assistente, '}sem promessa de valorização ou lucro. ${c.desconto > 0 ? `Cada ${c.simbolo} continua valendo ${c.desconto.toFixed(2).replace('.', ',')} de desconto em ${c.empresa}.` : ''}`.trim(),
  }
}
/** Posição do usuário numa moeda (tudo vem do banco): saldo, adquirido no mercado, preço médio, valor de referência atual. */
export async function posicao(userId: number, coinId: number, preco: number) {
  const ords = await q("SELECT * FROM coin_orders WHERE user_id = $1 AND coin_id = $2 AND market = TRUE ORDER BY id", [userId, coinId]) as any[]
  let pos = 0, custo = 0, comprado = 0, vendido = 0, gasto = 0, recebido = 0
  for (const o of ords) { if (o.status !== 'concluida') continue; const qd = num(o.qty)
    if (o.kind === 'compra') { custo += num(o.net); pos += qd; comprado += qd; gasto += num(o.net) } else { const medio = pos > 0 ? custo / pos : 0; custo -= medio * Math.min(qd, pos); pos = Math.max(0, pos - qd); vendido += qd; recebido += num(o.net) } }
  const saldo = await C.balanceOf(coinId, userId), medio = pos > 0 ? r4(custo / pos) : 0
  return { saldo, adquiridoNoMercado: comprado, vendidoNoMercado: vendido, totalGasto: r2(gasto), totalRecebido: r2(recebido), precoMedio: medio, valorReferenciaAtual: r2(saldo * preco), variacaoPct: medio > 0 ? Math.round(((preco - medio) / medio) * 1e4) / 100 : null, operacoes: await Promise.all(ords.slice(-50).reverse().map(pedidoOut)) }
}
/** Listagem do Mercado: as moedas com mercado ligado mostram a cotação e a variação reais (das negociações). */
export async function resumoListagem(coinId: number) {
  const m = await mercadoDe(coinId); if (!m || !m.ligado) return null
  const ref = await referenciaDia(coinId, nowIso())
  const serie30 = (await q('SELECT price FROM coin_prices WHERE coin_id = $1 AND created_at >= $2 ORDER BY id', [coinId, new Date(Date.now() - 30 * 86400_000).toISOString()]) as any[]).map((r) => num(r.price))
  return { preco: m.preco, variacao24h: ref && ref > 0 ? Math.round(((m.preco - ref) / ref) * 1e4) / 100 : 0, pausado: m.pausado, serie: serie30.length ? [...serie30, m.preco] : [m.preco, m.preco] }
}
export async function carteira(userId: number) {
  const ids = (await q("SELECT DISTINCT coin_id FROM coin_orders WHERE user_id = $1 AND market = TRUE UNION SELECT coin_id FROM coin_balances WHERE user_id = $1", [userId]) as any[]).map((r) => Number(r.coin_id))
  const out: Record<number, any> = {}
  for (const id of ids) { const m = await mercadoDe(id); if (!m || !m.ligado) continue; out[id] = { cotacao: m.preco, pausado: m.pausado, ...(await posicao(userId, id, m.preco)) } }
  return out
}

/* ---------- administração (independente por moeda) ---------- */
const actorOf = (adminId: number) => `admin ${adminId}`
async function mudanca(coinId: number, campo: string, de: any, para: any, adminId: number) { if (String(de ?? '') !== String(para ?? '')) await q('INSERT INTO coin_changes (coin_id, field, old_value, new_value, actor, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [coinId, 'mercado.' + campo, String(de ?? ''), String(para ?? ''), actorOf(adminId), nowIso()]) }
export async function salvarConfig(coinId: number, b: any, adminId: number) {
  const c: any = await C.coinById(coinId); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  return withLock(`coin:${coinId}`, async () => {
    const cur = await mercadoDe(coinId), regras: Regras = { ...(cur?.regras || REGRAS_PADRAO(c.total)) }
    for (const k of Object.keys(FAIXAS) as (keyof Regras)[]) {
      if (b.regras?.[k] === undefined) continue; const v = Number(b.regras[k]), [lo, hi, int] = FAIXAS[k]
      if (!isFinite(v) || v < lo || v > hi || (int && !Number.isInteger(v))) fail(400, `Valor inválido em "${k}" (${lo} a ${hi}${int ? ', inteiro' : ''}).`, 'invalid', k)
      regras[k] = v
    }
    if (regras.maxOperacao < regras.minOperacao) fail(400, 'O máximo por negócio não pode ser menor que o mínimo.', 'invalid', 'maxOperacao')
    const bool = (k: string, d: boolean) => (typeof b[k] === 'boolean' ? b[k] : d)
    const ligado = bool('ligado', cur?.ligado ?? false), compras = bool('compras', cur?.compras ?? false), vendas = bool('vendas', cur?.vendas ?? false), pausado = bool('pausado', cur?.pausado ?? false)
    const liquidacao = b.liquidacao === undefined ? cur?.liquidacao || 'manual' : b.liquidacao === 'simulada' ? 'simulada' : b.liquidacao === 'manual' ? 'manual' : fail(400, 'Liquidação inválida (manual ou simulada).', 'invalid', 'liquidacao')
    const ack = bool('simulacaoConfirmada', cur?.simulacaoConfirmada ?? false)
    if (ligado && liquidacao === 'simulada' && !ack) fail(400, 'No modo simulado as moedas são creditadas SEM pagamento e continuam valendo desconto nas empresas. Confirme que entende isso para ligar o mercado neste modo.', 'confirmar_simulado', 'simulacaoConfirmada')
    const nv = (v: any, d: number) => { if (v === undefined || v === null || v === '') return d; const x = Number(v); if (!isFinite(x) || x < 0 || x > 1e9) fail(400, 'Valor de cotação inválido.', 'invalid'); return r6(x) }
    const precoInicial = nv(b.precoInicial, cur?.precoInicial || 0), piso = nv(b.piso, cur?.piso ?? 0), teto = nv(b.teto, cur?.teto ?? 0)
    if (ligado && !(precoInicial > 0)) fail(400, 'Defina a cotação inicial da moeda.', 'invalid', 'precoInicial')
    if (ligado && !(teto > 0)) fail(400, 'Defina o teto da cotação (limite máximo de valorização).', 'invalid', 'teto')
    if (teto > 0 && (teto < precoInicial || piso > precoInicial)) fail(400, 'A cotação inicial precisa ficar entre o piso e o teto.', 'invalid', 'teto')
    if (b.ofertaTotal !== undefined && Number(b.ofertaTotal) !== c.total) await C.updateCoin(coinId, { quantidade: b.ofertaTotal }, actorOf(adminId)) // mesma validação da moeda (não fica abaixo do distribuído)
    const motivo = String(b.motivoPausa ?? cur?.motivoPausa ?? '').slice(0, 160), now = nowIso()
    await db().tx(async (t) => {
      if (!cur) await t.query('INSERT INTO coin_markets (coin_id, enabled, buy_enabled, sell_enabled, paused, pause_reason, settlement, simulated_ack, price, initial_price, price_floor, price_ceiling, config, version, updated_by, updated_at, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10,$11,$12,0,$13,$14,$14)',
        [coinId, ligado, compras, vendas, pausado, motivo, liquidacao, ack, precoInicial, piso, teto, JSON.stringify(regras), adminId, now])
      else await t.query('UPDATE coin_markets SET enabled=$1, buy_enabled=$2, sell_enabled=$3, paused=$4, pause_reason=$5, settlement=$6, simulated_ack=$7, initial_price=$8, price_floor=$9, price_ceiling=$10, config=$11, updated_by=$12, updated_at=$13, version = version + 1 WHERE coin_id=$14',
        [ligado, compras, vendas, pausado, motivo, liquidacao, ack, precoInicial, piso, teto, JSON.stringify(regras), adminId, now, coinId])
      // abertura: a primeira cotação entra no histórico quando o mercado é ligado pela primeira vez
      const temHist = (await t.query('SELECT id FROM coin_prices WHERE coin_id = $1 LIMIT 1', [coinId]))[0]
      if (ligado && !temHist) { await t.query('UPDATE coin_markets SET price = $1 WHERE coin_id = $2', [precoInicial, coinId]); await registrarPreco(t, coinId, precoInicial, null, 'abertura', { actor: actorOf(adminId) }, now) }
      // a cotação vigente precisa respeitar piso/teto novos: o ajuste fica registrado no histórico
      const atual = num((await t.query('SELECT price FROM coin_markets WHERE coin_id = $1', [coinId]))[0]?.price)
      if (temHist && teto > 0 && (atual > teto || atual < piso)) { const novo = Math.min(teto, Math.max(piso, atual)); await t.query('UPDATE coin_markets SET price = $1, version = version + 1 WHERE coin_id = $2', [novo, coinId]); await registrarPreco(t, coinId, novo, atual, 'ajuste', { actor: actorOf(adminId) + ' (piso/teto)' }, now) }
    })
    const novo = (await mercadoDe(coinId))!
    for (const k of ['ligado', 'compras', 'vendas', 'pausado', 'liquidacao', 'precoInicial', 'piso', 'teto'] as const) await mudanca(coinId, k, cur ? (cur as any)[k] : '', (novo as any)[k], adminId)
    for (const k of Object.keys(regras) as (keyof Regras)[]) await mudanca(coinId, 'regra.' + k, cur?.regras[k] ?? '', regras[k], adminId)
    await audit(adminId, 'coins.mercado.config', coinId, { ligado: novo.ligado, compras: novo.compras, vendas: novo.vendas, pausado: novo.pausado, liquidacao: novo.liquidacao })
    return novo
  })
}
/** Ajuste manual da cotação pelo administrador (registrado no histórico, dentro do piso/teto). */
export async function ajustarCotacao(coinId: number, preco: any, motivo: any, adminId: number) {
  const v = Number(preco), why = String(motivo || '').trim().slice(0, 160)
  if (!(v > 0) || v > 1e9) fail(400, 'Informe uma cotação válida.', 'invalid', 'preco'); if (why.length < 5) fail(400, 'Informe o motivo do ajuste (fica no histórico).', 'invalid', 'motivo')
  return withLock(`coin:${coinId}`, () => db().tx(async (t) => {
    const m = await mercadoDe(coinId, t); if (!m || !m.ligado) fail(409, 'Ligue o mercado desta moeda antes de ajustar a cotação.', 'sem_mercado')
    if ((m!.teto > 0 && v > m!.teto) || v < m!.piso) fail(400, `A cotação precisa ficar entre ${m!.piso} e ${m!.teto}.`, 'invalid', 'preco')
    const now = nowIso(), u = await t.query('UPDATE coin_markets SET price = $1, version = version + 1, updated_at = $2, updated_by = $3 WHERE coin_id = $4 AND version = $5 RETURNING coin_id', [r6(v), now, adminId, coinId, m!.versao])
    if (!u.length) fail(409, 'A cotação mudou agora. Tente de novo.', 'cotacao_mudou')
    await registrarPreco(t, coinId, r6(v), m!.preco, 'ajuste', { actor: `${actorOf(adminId)}: ${why}` }, now)
    await t.query('INSERT INTO coin_changes (coin_id, field, old_value, new_value, actor, created_at) VALUES ($1,$2,$3,$4,$5,$6)', [coinId, 'mercado.cotação (ajuste)', String(m!.preco), String(r6(v)), `${actorOf(adminId)}: ${why}`, now])
    await audit(adminId, 'coins.mercado.ajuste', coinId, { de: m!.preco, para: r6(v), motivo: why })
    return { de: m!.preco, para: r6(v) }
  }))
}
/** Integridade: saldos × livro-razão, emissão × carteiras, negócios × lançamentos, cadeia de cotações. */
export async function auditoria(coinId: number) {
  const problemas: string[] = []
  const saldos = await q('SELECT b.user_id, b.balance, (SELECT COALESCE(SUM(delta),0) FROM coin_ledger l WHERE l.coin_id = b.coin_id AND l.user_id = b.user_id) AS soma FROM coin_balances b WHERE b.coin_id = $1', [coinId]) as any[]
  for (const s of saldos) if (num(s.balance) !== num(s.soma)) problemas.push(`Conta #${s.user_id}: saldo ${num(s.balance)} ≠ soma do livro-razão ${num(s.soma)}.`)
  const conc = await q("SELECT id, kind, ledger_id, price_after FROM coin_orders WHERE coin_id = $1 AND market = TRUE AND status = 'concluida'", [coinId]) as any[]
  for (const o of conc) { if (!o.ledger_id) problemas.push(`Negócio #${o.id}: sem lançamento no livro-razão.`); if (o.price_after == null) problemas.push(`Negócio #${o.id}: sem registro de cotação.`) }
  const reg = num((await one("SELECT COUNT(*) AS n FROM coin_prices WHERE coin_id = $1 AND reason IN ('compra','venda')", [coinId]))?.n)
  if (reg !== conc.length) problemas.push(`Negócios concluídos (${conc.length}) ≠ movimentos de cotação registrados (${reg}).`)
  const h = await verificarHistorico(coinId); if (!h.ok) problemas.push(h.problema)
  return { ok: !problemas.length, problemas, contasConferidas: saldos.length, negociosConferidos: conc.length, historico: h }
}
export async function painel(coinId: number) {
  const c: any = await C.stats(coinId); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  const m = await mercadoDe(coinId), agora = Date.now()
  const vol = async (dias: number) => { const r = await one("SELECT COUNT(*) AS n, COALESCE(SUM(qty),0) AS q, COALESCE(SUM(gross),0) AS v, COALESCE(SUM(fee),0) AS f FROM coin_orders WHERE coin_id = $1 AND market = TRUE AND status = 'concluida' AND resolved_at >= $2", [coinId, new Date(agora - dias * 86400_000).toISOString()]); return { negocios: num(r?.n), moedas: num(r?.q), reais: r2(num(r?.v)), taxas: r2(num(r?.f)) } }
  const transacoes = (await q("SELECT o.*, u.name, u.email FROM coin_orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.coin_id = $1 AND o.market = TRUE ORDER BY o.id DESC LIMIT 100", [coinId]) as any[])
  const participantes = (await q("SELECT o.user_id, u.name, u.email, COUNT(*) AS n, COALESCE(SUM(CASE WHEN o.kind = 'compra' THEN o.qty ELSE 0 END),0) AS comprou, COALESCE(SUM(CASE WHEN o.kind = 'venda' THEN o.qty ELSE 0 END),0) AS vendeu FROM coin_orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.coin_id = $1 AND o.market = TRUE AND o.status = 'concluida' GROUP BY o.user_id, u.name, u.email ORDER BY n DESC LIMIT 100", [coinId]) as any[])
  const historico = (await q('SELECT price, prev_price, reason, order_id, qty, volume, actor, created_at FROM coin_prices WHERE coin_id = $1 ORDER BY id DESC LIMIT 200', [coinId]) as any[]).map((r) => ({ cotacao: num(r.price), anterior: r.prev_price == null ? null : num(r.prev_price), motivo: r.reason, pedido: r.order_id ? Number(r.order_id) : null, quantidade: r.qty == null ? null : num(r.qty), volume: r.volume == null ? null : num(r.volume), quem: r.actor || '', em: isoOf(r.created_at) }))
  return { moeda: { id: c.id, nome: c.nome, simbolo: c.simbolo, total: c.total, distribuidas: c.distribuidas, disponiveis: c.disponiveis, emCirculacao: c.emCirculacao, desconto: c.desconto, status: c.status },
    mercado: m, padrao: REGRAS_PADRAO(c.total), volume: { h24: await vol(1), d7: await vol(7), total: await vol(36500) },
    pendentes: num((await one("SELECT COUNT(*) AS n FROM coin_orders WHERE coin_id = $1 AND market = TRUE AND status = 'pendente'", [coinId]))?.n),
    transacoes: await Promise.all(transacoes.map(async (o) => ({ ...(await pedidoOut(o)), usuarioId: Number(o.user_id), usuario: o.name || '', email: o.email || '' }))),
    participantes: participantes.map((p) => ({ usuarioId: Number(p.user_id), nome: p.name || '', email: p.email || '', negocios: num(p.n), comprou: num(p.comprou), vendeu: num(p.vendeu) })),
    historico, auditoria: await auditoria(coinId), formula: 'impacto = sensibilidade × quantidade ÷ liquidez; compra: P1 = P0 × (1 + impacto); venda: P1 = P0 × (1 − impacto); limitado pela variação máxima por negócio, pela faixa diária (cotação de 24 h atrás ± variação diária) e por piso/teto; preço do negócio = (P0 + P1) ÷ 2.' }
}
