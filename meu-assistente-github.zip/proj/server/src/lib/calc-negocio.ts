// Cálculos de negócio AUTOCONTIDOS: o usuário dá todos os números na própria mensagem (lucro por unidade, lucro líquido e margem,
// desconto, margem sobre custo). Duas funções:
//  • ehCalculoAutocontido(): a mensagem é só uma conta com números próprios → o chat NÃO consulta dados pessoais (finanças, DAS,
//    agenda, memórias, Cérebro), NÃO usa ferramentas e NÃO herda assunto de mensagens anteriores;
//  • resolverCalculoNegocio(): padrões conhecidos são resolvidos aqui, de forma exata e determinística (sem IA e sem arredondar
//    errado); o que não se encaixa com certeza devolve null e segue para a IA, que recebe só a mensagem atual.
const sem = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const NUM = String.raw`(\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?)`
const toNum = (raw: string) => Number(raw.replace(/\./g, '').replace(',', '.'))
const brl = (n: number) => 'R$ ' + n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
const pct = (n: number) => n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%'
const r2 = (n: number) => Math.round(n * 100) / 100

/** Mensagem que é uma conta com números próprios (e não um pedido sobre os dados da pessoa). */
export function ehCalculoAutocontido(text: string): boolean {
  const t = String(text || '').trim(); if (t.length < 25 || t.length > 1500) return false
  const s = sem(t)
  if ((s.match(/\d+(?:[.,]\d+)*/g) || []).length < 2) return false // precisa trazer os números (pelo menos dois)
  const pergunta = /\?\s*$/.test(t) || /\b(calcul\w*|quanto|quantos|quantas|qual (?:e|foi|seria|sera|fica|ficou|o|a)\b|lucro|margem|desconto|markup|percentual|porcentagem|ponto de equilibrio|preco de venda|valor final)\b/.test(s)
  if (!pergunta) return false
  // pedido sobre os dados da própria pessoa, registro ou agenda: NÃO é conta autocontida
  if (/\b(meu|minha|meus|minhas|nosso|nossa|nossos|nossas|saldo|extrato|agenda|compromisso\w*|lembr\w*|registr\w*|lanc\w*|anot\w*|salv\w*|agend\w*|cadastr\w*|marque|apague|exclu\w*|cancel\w*|deste mes|desse mes|este mes|esse mes|mes passado|ultimo mes|hoje|amanha|ontem)\b/.test(s)) return false
  if (/\bDAS\b/.test(t)) return false
  return true
}

const money = (re: string) => new RegExp(String.raw`(?:r\$\s*)?` + re, 'i')
/** Resolve com certeza os padrões conhecidos; qualquer dúvida → null (a IA responde, sem ferramentas e sem contexto antigo). */
export function resolverCalculoNegocio(text: string): string | null {
  const t = String(text || '').replace(/\s+/g, ' ').trim(), s = sem(t)

  // 1) compra e venda por unidade: investimento, receita, custo das vendidas e lucro bruto
  const cm = s.match(new RegExp(String.raw`\b(?:comprei|comprou|adquiri|investi em)\s+(\d+)\s+[^.?!]*?por\s+(?:r\$\s*)?${NUM}\s*(?:reais\s*)?cada`)), vm = s.match(new RegExp(String.raw`\b(?:vendi|vendeu)\s+(\d+)\s+[^.?!]*?por\s+(?:r\$\s*)?${NUM}\s*(?:reais\s*)?cada`))
  if (cm && vm) {
    const N = Number(cm[1]), C = toNum(cm[2]), M = Number(vm[1]), V = toNum(vm[2])
    if (N > 0 && M > 0 && M <= N && C >= 0 && V >= 0) {
      const inv = r2(N * C), rec = r2(M * V), custoV = r2(M * C), lucro = r2(rec - custoV), resto = N - M
      return [
        `**Investimento inicial:** ${N} × ${brl(C)} = **${brl(inv)}**`,
        `**Receita das ${M} vendas:** ${M} × ${brl(V)} = **${brl(rec)}**`,
        `**Custo das ${M} unidades vendidas:** ${M} × ${brl(C)} = **${brl(custoV)}**`,
        `**Lucro bruto das unidades vendidas:** ${brl(rec)} − ${brl(custoV)} = **${brl(lucro)}**`,
        ...(resto > 0 ? [`Ainda restam ${resto} unidade(s) em estoque, com custo de ${brl(r2(resto * C))}.`] : []),
      ].join('\n')
    }
  }

  // 2) lucro líquido e margem: faturamento menos todos os custos citados
  if (/\b(faturou|faturamento|receita|vendeu)\b/.test(s) && /\b(lucro liquido|margem)\b/.test(s)) {
    const fm = s.match(new RegExp(String.raw`\b(?:faturou|faturamento(?: de| foi de)?|receita(?: de| foi de)?|vendeu)\s*(?:r\$\s*)?${NUM}`))
    if (fm) {
      const F = toNum(fm[1]), resto = s.slice((fm.index || 0) + fm[0].length)
      const itens: { nome: string; v: number }[] = []
      for (const m of resto.matchAll(new RegExp(String.raw`(?:r\$\s*)?${NUM}\s*(?:reais\s*)?de\s+([a-z ]{3,30}?)(?=\s*(?:,|\.|;|\be\b|\?|$))`, 'g'))) itens.push({ nome: m[2].trim(), v: toNum(m[1]) })
      const ok = itens.length >= 1 && itens.every((i) => /\b(despesas?|impostos?|custos?|outros custos|gastos?|taxas?|salarios?|comissoes|comissao|aluguel|frete|fornecedores?|marketing)\b/.test(i.nome))
      // todo valor monetário da mensagem depois do faturamento precisa ter sido entendido; senão não arrisca
      const todos = [...resto.matchAll(new RegExp(String.raw`(?:r\$\s*)${NUM}`, 'g'))].length
      if (ok && F > 0 && todos === itens.length) {
        const total = r2(itens.reduce((a, i) => a + i.v, 0)), lucro = r2(F - total), margem = (lucro / F) * 100
        const cap = (x: string) => x.charAt(0).toUpperCase() + x.slice(1)
        return [
          `**Faturamento:** ${brl(F)}`,
          ...itens.map((i) => `− ${cap(i.nome)}: ${brl(i.v)}`),
          `**Total de custos:** ${brl(total)}`,
          `**Lucro líquido:** ${brl(F)} − ${brl(total)} = **${brl(lucro)}**`,
          `**Margem líquida:** ${brl(lucro)} ÷ ${brl(F)} = **${pct(margem)}**`,
        ].join('\n')
      }
    }
  }

  // 3) desconto: valor final e valor do desconto
  const dm = s.match(new RegExp(String.raw`(?:r\$\s*)${NUM}[^.?!%]*?\b(?:com|de)\s+(\d+(?:,\d+)?)\s*%\s*(?:de )?desconto`)) || s.match(new RegExp(String.raw`(\d+(?:,\d+)?)\s*%\s*(?:de )?desconto[^.?!]*?(?:r\$\s*)${NUM}`))
  if (dm && /\b(valor final|quanto (?:fica|ficou|vai ficar|pago|custa|sai)|preco final|desconto)\b/.test(s)) {
    const invert = /%\s*(?:de )?desconto/.test(dm[0]) && !/^r|^\d{1,3}(?:\.\d{3})/.test(dm[0].slice(0, 2)) && dm[0].indexOf('%') < dm[0].indexOf('r$')
    const P = invert ? toNum(dm[2]) : toNum(dm[1]), D = invert ? toNum(dm[1]) : toNum(dm[2])
    if (P > 0 && D > 0 && D < 100) { const desc = r2((P * D) / 100), fim = r2(P - desc); return [`**Preço original:** ${brl(P)}`, `**Desconto de ${D.toLocaleString('pt-BR')}%:** ${brl(P)} × ${D.toLocaleString('pt-BR')}% = **${brl(desc)}**`, `**Valor final:** ${brl(P)} − ${brl(desc)} = **${brl(fim)}**`].join('\n') }
  }

  // 4) margem sobre a venda e markup: custo e preço de venda
  if (/\b(margem|markup)\b/.test(s) && /\b(custo|custa|custou|compro|comprei|paguei)\b/.test(s) && /\b(vendo|vendi|venda|preco de venda)\b/.test(s)) {
    const cs = s.match(new RegExp(String.raw`\b(?:custo|custa|custou|compro|comprei|paguei)[^.?!\d]*?(?:r\$\s*)?${NUM}`)), vs = s.match(new RegExp(String.raw`\b(?:vendo|vendi|venda|preco de venda)[^.?!\d]*?(?:r\$\s*)?${NUM}`))
    if (cs && vs && (s.match(/r\$/g) || []).length <= 2) {
      const C = toNum(cs[1]), V = toNum(vs[1])
      if (C > 0 && V > 0) { const L = r2(V - C); return [`**Lucro por unidade:** ${brl(V)} − ${brl(C)} = **${brl(L)}**`, `**Margem de lucro (sobre a venda):** ${brl(L)} ÷ ${brl(V)} = **${pct((L / V) * 100)}**`, `**Markup (sobre o custo):** ${brl(L)} ÷ ${brl(C)} = **${pct((L / C) * 100)}**`].join('\n') }
    }
  }
  return null
}
