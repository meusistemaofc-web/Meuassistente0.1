// PÁGINA "DESCOBRIR" (Empresas perto de você): o que aparece, banners rotativos e personalização por usuário.
// Reaproveita a vitrine existente (routes/businesses.ts: lista de empresas, Produtos e Serviços) — aqui só ficam:
//  1 opções exibidas ....... Empresas, Produtos e Serviços ligados/desligados no painel (app_config "descobrir"); o que está
//                            desligado some da tela E é bloqueado no servidor (lista, busca, filtros, recomendações, banners)
//  2 banners ............... cadastro no painel (imagem, título, descrição, botão, destino, período, ordem, duração)
//  3 interesses ............ perfil INDIVIDUAL (user_interests): cliques, buscas, carrinho, agendamentos, acessos e contatos
//                            viram pesos por empresa, produto, serviço, categoria e termo, com decaimento pela recência
//  4 ordenação ............. relevância geral (proximidade, disponibilidade, qualidade do cadastro, oferta) + afinidade do
//                            próprio usuário; usuário novo/visitante = só a relevância geral
//  5 recomendações ......... "Recomendado para você" com diversidade (no máximo 2 por empresa, 3 por categoria), rodízio
//                            diário e espaço para novidades; usuário novo vê "Destaques perto de você"
import { q, one, nowIso, J, B, memoRequisicao } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'
import { fail } from './http.js'

export type Modo = 'empresas' | 'produtos' | 'servicos'
export const MODOS: Modo[] = ['empresas', 'produtos', 'servicos']
export interface Cfg { empresas: boolean; produtos: boolean; servicos: boolean; personalizacao: boolean; recomendacoes: boolean; banners: boolean }
export const CFG_PADRAO: Cfg = { empresas: true, produtos: true, servicos: true, personalizacao: true, recomendacoes: true, banners: true }
export async function cfg(): Promise<Cfg> { return { ...CFG_PADRAO, ...(await getConfig<Partial<Cfg>>('descobrir', {})) } }
export async function salvarCfg(x: any): Promise<Cfg> {
  const c = await cfg(), n: Cfg = { ...c }
  for (const k of Object.keys(CFG_PADRAO) as (keyof Cfg)[]) if (typeof x?.[k] === 'boolean') n[k] = x[k]
  if (!MODOS.some((m) => n[m])) fail(400, 'Deixe pelo menos uma opção ligada (Empresas, Produtos ou Serviços).', 'invalid')
  await setConfig('descobrir', n); return n
}
export const modosAtivos = (c: Cfg) => MODOS.filter((m) => c[m])
/** Bloqueio no servidor: categoria desligada no painel não responde nem por requisição direta. */
export async function exigirModo(m: Modo) { if (!(await cfg())[m]) fail(404, 'Esta opção não está disponível no momento.', 'desativado') }

/* ======================= banners ======================= */
const DESTINOS = ['nenhum', 'empresa', 'produto', 'servico', 'categoria', 'link']
const IMG = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=]+)$/
const txt = (v: any, max: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max)
const dataOk = (v: any) => { if (v == null || v === '') return null; const t = Date.parse(String(v)); if (!Number.isFinite(t)) fail(400, 'Data inválida.', 'invalid'); return new Date(t).toISOString() }
async function validarDestino(tipo: string, valor: string): Promise<string> {
  if (!DESTINOS.includes(tipo)) fail(400, 'Destino inválido.', 'invalid')
  if (tipo === 'nenhum') return ''
  if (tipo === 'link') { if (!/^(\/[^\s]*|https:\/\/[^\s]+)$/.test(valor) || /^\/\//.test(valor)) fail(400, 'Use um caminho do app (/x/…) ou um endereço https://.', 'invalid'); return valor.slice(0, 500) }
  if (tipo === 'categoria') { const [m, c] = valor.split('|'); if (!MODOS.includes(m as Modo) || !txt(c, 60)) fail(400, 'Escolha a aba e a categoria.', 'invalid'); return `${m}|${txt(c, 60)}` }
  const id = Math.floor(Number(valor)); if (!(id > 0)) fail(400, 'Informe o número (ID) do destino.', 'invalid')
  if (tipo === 'empresa') { if (!(await one('SELECT id FROM businesses WHERE id = $1', [id]))) fail(400, 'Empresa não encontrada.', 'invalid') }
  else { const p = await one('SELECT id, data FROM products WHERE id = $1', [id]); if (!p) fail(400, 'Produto ou serviço não encontrado.', 'invalid'); const sv = J<any>(p.data, {}).tipo === 'servico'; if (sv !== (tipo === 'servico')) fail(400, sv ? 'Esse ID é de um serviço.' : 'Esse ID é de um produto.', 'invalid') }
  return String(id)
}
export async function salvarBanner(id: number | null, x: any) {
  const atual = id ? await one('SELECT * FROM descobrir_banners WHERE id = $1', [id]) : null
  if (id && !atual) fail(404, 'Banner não encontrado.', 'not_found')
  let imagem = atual ? String(atual.imagem) : ''
  if (typeof x?.imagem === 'string' && x.imagem) {
    const m = x.imagem.match(IMG); if (!m) fail(400, 'Envie uma imagem PNG, JPG ou WEBP.', 'invalid')
    if (Buffer.byteLength(m![2], 'base64') > 1.4 * 1024 * 1024) fail(400, 'A imagem passa de 1,4 MB. Reduza e tente de novo.', 'invalid')
    imagem = x.imagem
  }
  if (!imagem) fail(400, 'Envie a imagem do banner.', 'invalid')
  const tipo = String(x?.destinoTipo ?? atual?.destino_tipo ?? 'nenhum'), valor = await validarDestino(tipo, txt(x?.destinoValor ?? atual?.destino_valor ?? '', 500))
  const inicio = x?.inicio !== undefined ? dataOk(x.inicio) : atual?.inicio || null, fim = x?.fim !== undefined ? dataOk(x.fim) : atual?.fim || null
  if (inicio && fim && Date.parse(fim) <= Date.parse(inicio)) fail(400, 'O fim precisa ser depois do início.', 'invalid')
  const v = { titulo: txt(x?.titulo ?? atual?.titulo, 80), descricao: txt(x?.descricao ?? atual?.descricao, 160), botao: txt(x?.botao ?? atual?.botao, 28), ordem: Math.max(0, Math.min(999, Math.floor(Number(x?.ordem ?? atual?.ordem ?? 0)) || 0)), duracao: Math.max(3, Math.min(30, Math.floor(Number(x?.duracao ?? atual?.duracao ?? 6)) || 6)), ativo: typeof x?.ativo === 'boolean' ? x.ativo : atual ? B(atual.ativo) : true }
  if (tipo !== 'nenhum' && !v.botao) v.botao = 'Ver mais'
  const now = nowIso()
  if (atual) await q('UPDATE descobrir_banners SET titulo=$1, descricao=$2, imagem=$3, botao=$4, destino_tipo=$5, destino_valor=$6, inicio=$7, fim=$8, ordem=$9, duracao=$10, ativo=$11, updated_at=$12 WHERE id=$13', [v.titulo, v.descricao, imagem, v.botao, tipo, valor, inicio, fim, v.ordem, v.duracao, v.ativo, now, id])
  else { const r = await one('INSERT INTO descobrir_banners (titulo, descricao, imagem, botao, destino_tipo, destino_valor, inicio, fim, ordem, duracao, ativo, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12) RETURNING id', [v.titulo, v.descricao, imagem, v.botao, tipo, valor, inicio, fim, v.ordem, v.duracao, v.ativo, now]); id = Number(r!.id) }
  return bannerAdmin(await one('SELECT * FROM descobrir_banners WHERE id = $1', [id]))
}
export async function excluirBanner(id: number) { const r = await one('SELECT id FROM descobrir_banners WHERE id = $1', [id]); if (!r) fail(404, 'Banner não encontrado.', 'not_found'); await q('DELETE FROM descobrir_banners WHERE id = $1', [id]) }
const imgUrl = (r: any) => `/api/v2/descobrir/banners/${r.id}/imagem?v=${encodeURIComponent(String(Date.parse(String(r.updated_at)) || 0))}`
const vigente = (r: any, agora = Date.now()) => B(r.ativo) && (!r.inicio || Date.parse(String(r.inicio)) <= agora) && (!r.fim || Date.parse(String(r.fim)) > agora)
function bannerAdmin(r: any) { return { id: Number(r.id), titulo: r.titulo, descricao: r.descricao, botao: r.botao, destinoTipo: r.destino_tipo, destinoValor: r.destino_valor, inicio: r.inicio || null, fim: r.fim || null, ordem: Number(r.ordem), duracao: Number(r.duracao), ativo: B(r.ativo), imagem: imgUrl(r), noAr: vigente(r), atualizadoEm: r.updated_at } }
export async function bannersAdmin() { return ((await q('SELECT * FROM descobrir_banners ORDER BY ordem, id')) as any[]).map(bannerAdmin) }
/** Banners no ar agora, com destino resolvido; destino em categoria desligada (ou item fora do ar) não aparece. */
export async function bannersPublicos(c: Cfg) {
  if (!c.banners) return []
  const rows = ((await q('SELECT id, titulo, descricao, botao, destino_tipo, destino_valor, inicio, fim, ordem, duracao, ativo, updated_at FROM descobrir_banners WHERE ativo = $1 ORDER BY ordem, id', [true])) as any[]).filter((r) => vigente(r))
  const out: any[] = []
  for (const r of rows) {
    const t = String(r.destino_tipo), v = String(r.destino_valor); let link: string | null = null
    if (t === 'empresa') { if (!c.empresas && !c.produtos && !c.servicos) continue; const b = await one("SELECT id FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(v)]); if (!b) continue; link = `/x/empresa/${v}` }
    else if (t === 'produto' || t === 'servico') { if (!c[t === 'produto' ? 'produtos' : 'servicos']) continue; const p = await one('SELECT business_id, active FROM products WHERE id = $1', [Number(v)]); if (!p || !B(p.active)) continue; link = `/x/empresa/${p.business_id}?${t}=${v}` }
    else if (t === 'categoria') { const [m, cat] = v.split('|'); if (!c[m as Modo]) continue; link = `/x/empresas?modo=${m}&categoria=${encodeURIComponent(cat)}` }
    else if (t === 'link') link = v
    out.push({ id: Number(r.id), titulo: r.titulo, descricao: r.descricao, botao: link ? r.botao || 'Ver mais' : '', link, externo: !!link && /^https:/.test(link), duracao: Number(r.duracao), imagem: imgUrl(r) })
  }
  return out
}
export async function imagemBanner(id: number): Promise<{ tipo: string; buf: Buffer } | null> {
  const r = await one('SELECT imagem FROM descobrir_banners WHERE id = $1', [id]); const m = r && String(r.imagem).match(IMG)
  return m ? { tipo: 'image/' + (m[1] === 'jpg' ? 'jpeg' : m[1]), buf: Buffer.from(m[2], 'base64') } : null
}

/* ======================= interesses (individuais) ======================= */
const MEIA_VIDA_DIAS = 14
const PESO: Record<string, number> = { clique: 1, acesso: 1.2, busca: 0.7, contato: 1.5, carrinho: 2.5, agendar: 3, pedido: 3 }
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set('de da do das dos e em no na para pra com sem um uma o a os as por mais perto'.split(' '))
export const decai = (peso: number, desdeMs: number) => peso * Math.pow(0.5, Math.max(0, desdeMs) / (MEIA_VIDA_DIAS * 864e5))
export interface Evento { t: string; k?: string; id?: number; bid?: number; cat?: string; termo?: string }
/** Eventos → pesos por chave (empresa, item, categoria, termo). Vários eventos do mesmo lote se somam. */
export function chavesDe(evs: Evento[]): Map<string, number> {
  const m = new Map<string, number>(), add = (k: string, w: number) => { if (k.length > 70) return; m.set(k, (m.get(k) || 0) + w) }
  for (const e of evs.slice(0, 40)) {
    const w = PESO[String(e?.t)]; if (!w) continue
    const id = Math.floor(Number(e.id)), bid = Math.floor(Number(e.bid)), cat = nrm(String(e.cat || '')).slice(0, 40)
    if (e.k === 'e' && id > 0) add('e:' + id, w)
    if ((e.k === 'p' || e.k === 's') && id > 0) add(e.k + ':' + id, w)
    if (bid > 0 && e.k !== 'e') add('e:' + bid, w * 0.5)
    if (cat) add('c:' + cat, w * 0.6)
    if (e.termo) for (const t of nrm(e.termo).split(' ').filter((x) => x.length >= 3 && !STOP.has(x)).slice(0, 4)) add('t:' + t, w)
  }
  return m
}
export async function registrar(userId: number, evs: Evento[], agora = Date.now()) {
  const c = await cfg(); if (!c.personalizacao) return 0
  const m = chavesDe(Array.isArray(evs) ? evs : []); if (!m.size) return 0
  const ks = [...m.keys()], ex = new Map(((await q(`SELECT chave, peso, n, ultimo FROM user_interests WHERE user_id = $1 AND chave IN (${ks.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...ks])) as any[]).map((r) => [String(r.chave), r]))
  const now = new Date(agora).toISOString()
  for (const [k, w] of m) {
    const r = ex.get(k)
    if (r) await q('UPDATE user_interests SET peso = $1, n = $2, ultimo = $3 WHERE user_id = $4 AND chave = $5', [decai(Number(r.peso), agora - Date.parse(String(r.ultimo))) + w, Number(r.n) + 1, now, userId, k])
    else await q('INSERT INTO user_interests (user_id, chave, peso, n, ultimo) VALUES ($1,$2,$3,$4,$5)', [userId, k, w, 1, now])
  }
  // limite por usuário: mantém os 400 interesses mais fortes (o resto já pesa quase nada)
  const tot = await one('SELECT COUNT(*) AS n FROM user_interests WHERE user_id = $1', [userId])
  if (Number(tot?.n || 0) > 500) { const corte = await one('SELECT peso FROM user_interests WHERE user_id = $1 ORDER BY peso DESC LIMIT 1 OFFSET 400', [userId]); if (corte) await q('DELETE FROM user_interests WHERE user_id = $1 AND peso <= $2', [userId, Number(corte.peso)]) }
  return m.size
}
export async function limpar(userId: number) { await q('DELETE FROM user_interests WHERE user_id = $1', [userId]) }
export interface Perfil { w: Map<string, number>; max: number; vazio: boolean; n: Map<string, number> }
/** Perfil do usuário (uma consulta por requisição). Visitante, personalização desligada ou sem histórico: perfil vazio. */
export async function perfil(userId: number | null | undefined, agora = Date.now()): Promise<Perfil> {
  const vazio: Perfil = { w: new Map(), max: 0, vazio: true, n: new Map() }
  if (!userId || !(await cfg()).personalizacao) return vazio
  const memo = memoRequisicao(), ch = 'descobrir:perfil:' + userId
  if (memo?.has(ch)) return memo.get(ch) as Perfil
  const rows = (await q('SELECT chave, peso, n, ultimo FROM user_interests WHERE user_id = $1 ORDER BY peso DESC LIMIT 400', [userId])) as any[]
  const w = new Map<string, number>(), n = new Map<string, number>(); let max = 0
  for (const r of rows) { const v = decai(Number(r.peso), agora - Date.parse(String(r.ultimo))); if (v < 0.05) continue; w.set(String(r.chave), v); n.set(String(r.chave), Number(r.n)); if (!String(r.chave).startsWith('t:') && v > max) max = v }
  const p: Perfil = { w, max, vazio: !w.size, n }; memo?.set(ch, p); return p
}
/** Afinidade 0..~1,5 de um item com o perfil (o próprio item, a empresa, a categoria e os termos que a pessoa buscou). */
export function afinidade(p: Perfil, it: { k: 'e' | 'p' | 's'; id: number; bid?: number; cat?: string; nome?: string }) {
  if (p.vazio || !p.max) return 0
  const g = (k: string) => p.w.get(k) || 0
  let a = g(it.k + ':' + it.id) + (it.k !== 'e' && it.bid ? g('e:' + it.bid) * 0.6 : 0) + (it.cat ? g('c:' + nrm(it.cat)) * 0.7 : 0)
  if (it.nome) for (const t of nrm(it.nome).split(' ')) if (t.length >= 3) a += g('t:' + t) * 0.5
  return Math.min(1.5, a / p.max)
}
/** Relevância geral (vale para todos, inclusive usuário novo): proximidade, disponibilidade, qualidade do cadastro, oferta. */
export function relevanciaGeral(it: { distancia?: number | null; aberto?: boolean; foto?: string | null; emOferta?: boolean; preco?: number | null; descricao?: string }) {
  const d = it.distancia == null ? 5 : Number(it.distancia)
  return 1 / (1 + d / 3) * 0.6 + (it.aberto ? 0.1 : 0) + (it.foto ? 0.15 : 0) + (it.emOferta ? 0.08 : 0) + (it.preco != null ? 0.04 : 0) + (it.descricao ? 0.03 : 0)
}
/** Rodízio diário estável por usuário (mesma ordem no dia; muda no dia seguinte). */
export function jitter(uid: number | null | undefined, id: number, dia = new Date().toISOString().slice(0, 10)) { let h = 2166136261; for (const ch of `${uid || 0}|${dia}|${id}`) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) } return ((h >>> 0) % 1000) / 1000 }
/** Escolhe recomendações com diversidade: no máximo 2 por empresa e 3 por categoria; ~1/4 das vagas para novidades
 *  (itens sem nenhuma interação da pessoa), para que empresas e itens novos também apareçam. */
export function diversificar<T extends { _s: number; _bid: number; _cat: string; _novo: boolean }>(ordenados: T[], max = 8): T[] {
  const out: T[] = [], porB = new Map<number, number>(), porC = new Map<string, number>(), novos = Math.max(1, Math.round(max / 4))
  const cabe = (x: T) => (porB.get(x._bid) || 0) < 2 && (porC.get(x._cat) || 0) < 3
  const poe = (x: T) => { out.push(x); porB.set(x._bid, (porB.get(x._bid) || 0) + 1); porC.set(x._cat, (porC.get(x._cat) || 0) + 1) }
  for (const x of ordenados) { if (out.length >= max - novos) break; if (cabe(x)) poe(x) }
  for (const x of ordenados) { if (out.length >= max) break; if (x._novo && !out.includes(x) && cabe(x)) poe(x) }
  for (const x of ordenados) { if (out.length >= max) break; if (!out.includes(x) && cabe(x)) poe(x) }
  return out
}
