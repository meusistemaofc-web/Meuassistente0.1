// Follow-up inteligente: depois de um atendimento/venda concluído, avisa o dono da empresa (e só ele)
// no prazo configurado, para que ELE entre em contato com o cliente. Nada é enviado ao cliente.
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig } from './settings.js'
import { notify } from './notify.js'

export const FUP_DEFAULT: any = { ativo: true, dias: 7, msgs: {} }
/** Mensagem personalizada do painel: {nome_cliente} {nome_empresa} {data_atendimento} {tipo_servico} {dias_sem_contato} */
export const fupText = (t: string, v: { cliente: string; empresa: string; data: string; servico: string; dias: number }) => String(t || '').replace(/\{nome_cliente\}/g, v.cliente).replace(/\{nome_empresa\}/g, v.empresa).replace(/\{data_atendimento\}/g, v.data).replace(/\{tipo_servico\}/g, v.servico).replace(/\{dias_sem_contato\}/g, String(v.dias)).trim()
export async function fupCfg(x: any) {
  const g = { ...FUP_DEFAULT, ...(await getConfig<any>('followup', {})) }
  const e = x?.followup || {}
  return { ativo: g.ativo !== false && e.ativo !== false, dias: Math.min(365, Math.max(1, Math.round(Number(e.dias ?? g.dias) || 7))) }
}
/** Pedido/agendamento concluído com cliente identificado → agenda o acompanhamento (uma vez por pedido). */
export async function scheduleFollowup(orderId: number) {
  const o = await one('SELECT * FROM orders WHERE id = $1', [orderId]); if (!o || o.status !== 'concluido') return null
  const b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [o.business_id]); if (!b) return null
  const x = J<any>(b.data, {}), d = J<any>(o.data, {}), cfg = await fupCfg(x)
  if (!cfg.ativo) return null
  let cliente = String(d.nome || d.cliente || '').trim(), contato = String(d.telefone || '').trim()
  if (!d.guest && Number(o.customer_id) !== Number(b.owner_id)) { const cu = await one('SELECT name, whatsapp FROM users WHERE id = $1', [o.customer_id]); cliente = cliente || String(cu?.name || ''); contato = contato || String(cu?.whatsapp || '') }
  if (!cliente) return null // sem cliente associado: não há quem acompanhar
  const servico = d.tipo === 'agendamento' ? String(d.servico || 'atendimento') : (d.itens || []).map((i: any) => `${i.qtd > 1 ? i.qtd + '× ' : ''}${i.nome}`).join(', ').slice(0, 200) || 'pedido'
  const concl = nowIso(), due = new Date(Date.now() + cfg.dias * 86400_000).toISOString()
  await q('INSERT INTO followups (business_id, owner_id, order_id, cliente, contato, servico, concluido_em, due_at, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$7,$7) ON CONFLICT (order_id) DO NOTHING',
    [b.id, b.owner_id, o.id, cliente.slice(0, 120), contato.slice(0, 40), servico, concl, due, 'agendado'])
  const fr = await one('SELECT id FROM followups WHERE order_id = $1', [o.id]); if (fr) await garantirTarefa(Number(fr.id)).catch((e) => console.error('[follow-up] tarefa:', e?.message)) // já aparece em Tarefas → Pendentes, com a data prevista
  return due
}
/** Agendador: avisa o dono quando chega o dia (uma notificação por prazo; adiar gera um novo prazo). */
export async function tickFollowups(now = new Date()) {
  await garantirTarefasAbertas().catch((e) => console.error('[follow-up] tarefas:', e?.message))
  const rows = await q("SELECT f.*, b.data AS bdata FROM followups f JOIN businesses b ON b.id = f.business_id WHERE f.status = 'agendado' AND f.due_at <= $1 LIMIT 200", [now.toISOString()])
  for (const f of rows) {
    const x = J<any>(f.bdata, {}), dias = Math.max(1, Math.round((now.getTime() - Date.parse(f.concluido_em)) / 86400_000))
    const g = (await getConfig<any>('followup', {})).msgs || {}, o = f.order_id ? await one('SELECT data FROM orders WHERE id = $1', [f.order_id]) : null
    const tipo = J<any>(o?.data, {}).tipo === 'agendamento' ? 'servico' : 'venda', reaviso = !!f.notified_at
    const tpl = (reaviso ? g.contato || g.atrasado : '') || g[tipo] || g.concluido || ''
    const custom = fupText(tpl, { cliente: f.cliente, empresa: x.empresa || '', data: new Date(f.concluido_em).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }), servico: f.servico, dias })
    await notify(Number(f.owner_id), { type: 'followup', title: `Acompanhamento: ${f.cliente}`, body: custom || `${f.servico} · há ${dias} dia${dias > 1 ? 's' : ''} · ${x.empresa || ''}`.trim(), link: `/?followup=${f.id}`, ref: `followup:${f.id}:${new Date(f.due_at).toISOString()}` })
    await q("UPDATE followups SET status = 'notificado', notified_at = $1, updated_at = $1 WHERE id = $2", [now.toISOString(), f.id])
  }
}
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
/** Mensagens prontas para o dono enviar, conforme o segmento e o serviço. */
export function suggestions(seg: string, cliente: string, servico: string, empresa: string, dias: number) {
  const n = cliente.split(' ')[0], s = nrm(seg + ' ' + servico), dd = `${dias} dia${dias > 1 ? 's' : ''}`, quando = dias <= 1 ? 'ontem' : `há ${dd}`
  if (/tatu|tattoo|piercing/.test(s)) return [
    `Oi, ${n}! Aqui é da ${empresa}. Passando para saber como está a cicatrização da sua tattoo. Está tudo certinho? Se tiver qualquer dúvida sobre os cuidados, é só me chamar. 🖤`,
    `Olá, ${n}! Já faz ${dd} da sua sessão (${servico}). Como ficou? Se quiser, me manda uma foto para eu conferir a cicatrização e agendar o retoque, se precisar.`,
    `Oi, ${n}! Obrigado por confiar na ${empresa}. Ficou feliz com o resultado? Sua opinião ajuda muito o nosso trabalho.`]
  if (/salao|barbear|cabel|estetic|unha|manicure|sobrancel|cilio|maqui|beleza|spa|massag/.test(s)) return [
    `Oi, ${n}! Aqui é da ${empresa}. Como você está gostando do resultado do seu ${servico}? 😊`,
    `Olá, ${n}! Já faz ${dd} do seu ${servico}. Quer deixar a manutenção agendada para manter tudo em dia? Tenho horários essa semana.`,
    `Oi, ${n}! Obrigado pela visita ${quando}. Se puder, conta pra gente o que achou do atendimento. 💜`]
  if (/clinic|odonto|dentist|saude|fisio|psico|nutri|medic|terapia|veterin|pet/.test(s)) return [
    `Olá, ${n}! Aqui é da ${empresa}. Passando para saber como você está depois do ${servico}. Ficou alguma dúvida ou desconforto?`,
    `Oi, ${n}! Já faz ${dd} do seu atendimento. Quer agendar o retorno para acompanharmos a evolução?`,
    `Olá, ${n}! Obrigado pela confiança na ${empresa}. Estamos à disposição se precisar de qualquer orientação.`]
  if (/pizza|restaur|lanch|hamburg|aca|sorvet|padar|doce|bolo|confeit|bar|cafe|comida|delivery|marmit/.test(s)) return [
    `Oi, ${n}! Aqui é da ${empresa}. O que você achou do seu pedido (${servico})? Sua opinião é muito importante pra gente! 😋`,
    `Olá, ${n}! Que tal repetir a dose? Hoje tem novidades no cardápio da ${empresa}. Posso te mandar as opções?`,
    `Oi, ${n}! Obrigado por pedir com a gente ${quando}. Se puder, deixa uma avaliação contando como foi. ⭐`]
  if (/oficina|mecan|auto|carro|moto|pneu|lava/.test(s)) return [
    `Olá, ${n}! Aqui é da ${empresa}. Como está o veículo depois do ${servico}? Está tudo funcionando bem?`,
    `Oi, ${n}! Já faz ${dd} do serviço. Lembre-se de fazer a revisão preventiva; quer que eu já deixe agendada?`,
    `Olá, ${n}! Obrigado pela confiança. Qualquer barulho ou dúvida, pode chamar.`]
  return [
    `Oi, ${n}! Aqui é da ${empresa}. Passando para saber se deu tudo certo com ${servico}. Ficou satisfeito(a)?`,
    `Olá, ${n}! Já faz ${dd} da sua compra/atendimento. Posso te ajudar com mais alguma coisa?`,
    `Oi, ${n}! Obrigado pela preferência. Se puder, conta pra gente como foi a sua experiência. 😊`]
}
/* ---------- integração com Tarefas (25/11) ----------
   Antes: o acompanhamento ficava só na tabela followups (aviso + cartão no chat) e nunca virava tarefa — por isso não
   aparecia em Tarefas → Pendentes. Agora cada acompanhamento em aberto tem UMA tarefa real do dono (items, type 'task'),
   ligada pelos dois lados (followups.task_id e data.followup da tarefa): concluir/adiar pelo chat atualiza a tarefa, e
   concluir/reabrir/excluir pela página Tarefas atualiza o acompanhamento. Nada é duplicado. */
export function motivo(seg: string, servico: string) {
  const s = nrm(seg + ' ' + servico)
  if (/tatu|tattoo|piercing/.test(s)) return 'Verificar cicatrização, solicitar foto e avaliar necessidade de retoque.'
  if (/salao|barbear|cabel|estetic|unha|manicure|sobrancel|cilio|maqui|beleza|spa|massag/.test(s)) return 'Saber se gostou do resultado e oferecer o agendamento da manutenção.'
  if (/clinic|odonto|dentist|saude|fisio|psico|nutri|medic|terapia|veterin|pet/.test(s)) return 'Perguntar como está depois do atendimento e oferecer o retorno.'
  if (/pizza|restaur|lanch|hamburg|aca|sorvet|padar|doce|bolo|confeit|bar|cafe|comida|delivery|marmit/.test(s)) return 'Perguntar o que achou do pedido e pedir a opinião do cliente.'
  return 'Entrar em contato para saber se deu tudo certo e abrir espaço para um novo atendimento.'
}
const diaLocal = (iso: string) => new Date(Date.parse(iso) - 3 * 3600_000).toISOString().slice(0, 10) // data de Brasília
const ABERTOS = ['agendado', 'notificado', 'pendente']
/** Tarefa do acompanhamento: devolve a existente (se ainda existir) ou cria UMA — corrida entre dois pedidos não duplica. */
export async function garantirTarefa(fid: number): Promise<number | null> {
  const f = await one('SELECT f.*, b.data AS bdata FROM followups f JOIN businesses b ON b.id = f.business_id WHERE f.id = $1', [fid]); if (!f || !ABERTOS.includes(String(f.status))) return f?.task_id ? Number(f.task_id) : null
  if (f.task_id) { const t = await one("SELECT id FROM items WHERE id = $1 AND user_id = $2 AND type = 'task'", [f.task_id, f.owner_id]); if (t) return Number(t.id) }
  const ow = await one('SELECT * FROM users WHERE id = $1', [f.owner_id]); if (!ow) return null
  const x = J<any>(f.bdata, {}), { hydrateUser } = await import('./session.js'), { createItem } = await import('../routes/items.js')
  const [it] = await createItem(hydrateUser(ow), 'task', { title: `Acompanhar ${f.cliente} — ${f.servico}`.slice(0, 300), due_date: diaLocal(f.due_at), notes: `${motivo(`${x.categoria || ''} ${x.tipo || ''}`, f.servico)}\nCliente: ${f.cliente}${f.contato ? ` · ${f.contato}` : ''}\nServiço: ${f.servico} (concluído em ${new Date(f.concluido_em).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })})\nEmpresa: ${x.empresa || ''}` })
  await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify({ ...it.data, followup: Number(f.id), origem: 'acompanhamento', empresaId: Number(f.business_id), empresa: x.empresa || '' }), it.id])
  const ganhou = await q('UPDATE followups SET task_id = $1, updated_at = $2 WHERE id = $3 AND (task_id IS NULL OR task_id = $4) RETURNING id', [it.id, nowIso(), f.id, f.task_id ?? -1])
  if (!ganhou.length) { await q('DELETE FROM items WHERE id = $1', [it.id]); const g = await one('SELECT task_id FROM followups WHERE id = $1', [f.id]); return g?.task_id ? Number(g.task_id) : null }
  return Number(it.id)
}
/** Acompanhamentos em aberto sem tarefa (criados antes da integração ou cuja tarefa sumiu): cria as tarefas que faltam. */
export async function garantirTarefasAbertas(ownerId?: number) {
  const rows = await q(`SELECT id FROM followups WHERE status IN ('agendado','notificado','pendente') AND task_id IS NULL${ownerId ? ' AND owner_id = $1' : ''} ORDER BY id LIMIT 300`, ownerId ? [ownerId] : [])
  for (const r of rows) await garantirTarefa(Number(r.id)).catch((e) => console.error('[follow-up] tarefa:', e?.message))
  return rows.length
}
/** Ação no ACOMPANHAMENTO (chat/rota) → a mesma tarefa. */
async function refletirNaTarefa(fid: number, st: 'concluido' | 'adiado' | 'pendente') {
  const tid = st === 'concluido' ? Number((await one('SELECT task_id FROM followups WHERE id = $1', [fid]))?.task_id || 0) || null : await garantirTarefa(fid); if (!tid) return
  const t = await one("SELECT * FROM items WHERE id = $1 AND type = 'task'", [tid]); if (!t) return
  const d = J<any>(t.data, {})
  if (st === 'concluido') await q("UPDATE items SET status = 'done', data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify({ ...d, completedAt: nowIso() }), nowIso(), tid])
  else { const f = await one('SELECT due_at FROM followups WHERE id = $1', [fid]); if (!f) return; await q("UPDATE items SET status = 'pending', day = $1, data = $2, updated_at = $3 WHERE id = $4", [diaLocal(f.due_at), JSON.stringify({ ...d, completedAt: null }), nowIso(), tid]) }
}
/** Ação na TAREFA (página Tarefas, chat) → o acompanhamento ligado. */
export async function aoMudarTarefa(it: { id: number; user_id: number; data: any }, acao: 'done' | 'pending' | 'in_progress' | 'excluida') {
  const fid = Number(it?.data?.followup || 0); if (!fid) return
  const f = await one('SELECT id, status FROM followups WHERE id = $1 AND owner_id = $2 AND task_id = $3', [fid, it.user_id, it.id]); if (!f) return
  if (acao === 'done') await q("UPDATE followups SET status = 'concluido', updated_at = $1 WHERE id = $2", [nowIso(), fid])
  else if (acao === 'excluida') await q("UPDATE followups SET status = 'cancelado', task_id = NULL, updated_at = $1 WHERE id = $2", [nowIso(), fid]) // excluída pelo dono: não volta sozinha
  else if (f.status === 'concluido') await q("UPDATE followups SET status = 'pendente', updated_at = $1 WHERE id = $2", [nowIso(), fid])
}
export async function followupView(id: number, ownerId: number) {
  const f = await one('SELECT f.*, b.data AS bdata FROM followups f JOIN businesses b ON b.id = f.business_id WHERE f.id = $1 AND f.owner_id = $2', [id, ownerId]); if (!f) return null
  const x = J<any>(f.bdata, {}), dias = Math.max(1, Math.round((Date.now() - Date.parse(f.concluido_em)) / 86400_000))
  const quando = new Date(f.concluido_em).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric' })
  const tarefa = ABERTOS.includes(String(f.status)) ? await garantirTarefa(Number(f.id)).catch(() => null) : (f.task_id ? Number(f.task_id) : null)
  const tr = tarefa ? await one('SELECT status, day FROM items WHERE id = $1', [tarefa]) : null
  return { tarefa: tr ? { id: tarefa, status: tr.status, vence: tr.day } : null, motivo: motivo(`${x.categoria || ''} ${x.tipo || ''}`, f.servico), id: Number(f.id), empresa: x.empresa || '', cliente: f.cliente, contato: f.contato || '', servico: f.servico, quando, dias, status: f.status, pedido: f.order_id ? Number(f.order_id) : null, mensagens: suggestions(`${x.categoria || ''} ${x.tipo || ''}`, f.cliente, f.servico, x.empresa || 'nossa empresa', dias) }
}

/* ---------- rotas (dono da empresa) ---------- */
import type { Ctx } from './http.js'
import { requireUser } from './session.js'
import { fail } from './http.js'
export async function followupGet(ctx: Ctx) { const u = requireUser(ctx); const v = await followupView(Number(ctx.params.id), u.id); if (!v) fail(404, 'Acompanhamento não encontrado.', 'not_found'); return v }
export async function followupsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const rows = await q("SELECT id, cliente, servico, status FROM followups WHERE owner_id = $1 AND status IN ('notificado','pendente') ORDER BY due_at DESC LIMIT 20", [u.id])
  return { items: rows.map((r) => ({ id: Number(r.id), cliente: r.cliente, servico: r.servico, status: r.status })) }
}
/** Concluído, adiado (novo prazo, avisa uma vez de novo) ou pendente (fica na lista, sem novo aviso). */
export async function followupPut(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id), st = String(ctx.body?.status || '')
  const f = await one('SELECT id FROM followups WHERE id = $1 AND owner_id = $2', [id, u.id]); if (!f) fail(404, 'Acompanhamento não encontrado.', 'not_found')
  if (st === 'concluido') await q("UPDATE followups SET status = 'concluido', updated_at = $1 WHERE id = $2", [nowIso(), id])
  else if (st === 'pendente') await q("UPDATE followups SET status = 'pendente', updated_at = $1 WHERE id = $2", [nowIso(), id])
  else if (st === 'adiado') { const dias = Math.min(60, Math.max(1, Math.round(Number(ctx.body?.dias) || 3))); await q("UPDATE followups SET status = 'agendado', due_at = $1, updated_at = $2 WHERE id = $3", [new Date(Date.now() + dias * 86400_000).toISOString(), nowIso(), id]); await refletirNaTarefa(id, 'adiado'); return { ...(await followupView(id, u.id)), ok: true, status: 'adiado', dias } }
  else fail(400, 'Situação inválida.', 'invalid')
  await refletirNaTarefa(id, st as any) // a MESMA tarefa em Tarefas: concluída sai de Pendentes; pendente continua lá
  return { ...(await followupView(id, u.id)), ok: true, status: st }
}
/** Conversa no chat: abrir um acompanhamento, listar pendentes e ajustar o prazo da empresa. */
export async function followupChat(u: { id: number }, text: string) {
  const s = nrm(text).replace(/[-_]/g, ' ').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
  let m = /^(?:ver )?acompanhamento #?(\d+)$/.exec(s)
  if (m) {
    const v = await followupView(Number(m[1]), u.id); if (!v) return null
    if (v.status === 'agendado' || v.status === 'notificado') await q("UPDATE followups SET status = 'pendente', updated_at = $1 WHERE id = $2 AND status = 'notificado'", [nowIso(), v.id])
    return { content: `Hora de acompanhar ${v.cliente}! ${v.dias === 1 ? 'Ontem' : `Há ${v.dias} dias`} (${v.quando}) a ${v.empresa} concluiu: ${v.servico}. É um bom momento para saber se deu tudo certo, mostrar cuidado e abrir espaço para um novo atendimento. Escolha uma mensagem abaixo, edite se quiser e envie você mesmo. ⟦fup:${v.id}⟧`, cards: [] }
  }
  if (/^(meus |ver )?(acompanhamentos|follow ?ups?)( pendentes)?$/.test(s)) {
    const r = await q("SELECT id FROM followups WHERE owner_id = $1 AND status IN ('notificado','pendente') ORDER BY due_at DESC LIMIT 5", [u.id])
    if (!r.length) return { content: 'Nenhum acompanhamento pendente agora. Quando um atendimento ou venda for concluído, eu aviso você no dia certo de falar com o cliente.', cards: [] }
    return { content: `Você tem ${r.length} acompanhamento${r.length > 1 ? 's' : ''} pendente${r.length > 1 ? 's' : ''}: ${r.map((x) => `⟦fup:${x.id}⟧`).join(' ')}`, cards: [] }
  }
  const own = await q('SELECT id, data FROM businesses WHERE owner_id = $1', [u.id])
  if (!own.length) return null
  m = /^(?:mudar |definir |configurar )?(?:o )?(?:prazo do )?(?:follow ?up|acompanhamento)s? (?:para |com |em )?(\d{1,3}) dias?$/.exec(s)
  const off = /^(desativar|desligar|parar) (o )?(follow ?up|acompanhamentos?)$/.test(s), on = /^(ativar|ligar) (o )?(follow ?up|acompanhamentos?)$/.test(s)
  if (m || off || on) {
    for (const b of own) { const x = J<any>(b.data, {}); x.followup = { ...(x.followup || {}), ...(m ? { dias: Math.min(365, Math.max(1, Number(m[1]))), ativo: true } : { ativo: on }) }; await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), b.id]) }
    return { content: m ? `Pronto! Vou avisar você ${m[1]} dias depois de cada atendimento ou venda concluída para acompanhar o cliente.` : on ? 'Follow-up ativado. Vou te lembrar de acompanhar os clientes depois de cada atendimento concluído.' : 'Follow-up desativado. Não vou mais gerar acompanhamentos para a sua empresa.', cards: [] }
  }
  return null
}
