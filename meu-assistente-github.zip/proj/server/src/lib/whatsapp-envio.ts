// ENVIO AUTOMÁTICO DE WHATSAPP (novos pedidos para o número da empresa).
//
// Quem envia: a conta de WhatsApp configurada pelo administrador do sistema (Painel → WhatsApp (envio)), por um destes
// provedores:
//   • cloud     — WhatsApp Business Cloud API oficial da Meta (graph.facebook.com/{versão}/{phone_number_id}/messages).
//                 Mensagem de texto livre só é entregue se o destinatário falou com o número nas últimas 24 h; fora disso
//                 a Meta exige um MODELO aprovado: se configurado, o envio cai automaticamente no modelo (2 variáveis:
//                 {{1}} = número do pedido, {{2}} = resumo do pedido em uma linha).
//   • evolution — Evolution API (POST {url}/message/sendText/{instância}, cabeçalho apikey).
//   • zapi      — Z-API (POST https://api.z-api.io/instances/{instância}/token/{token}/send-text, cabeçalho Client-Token).
// Para quem: o WhatsApp cadastrado da empresa (businesses.data.zap).
//
// Garantias (tabela envios_whatsapp, uma linha por pedido — UNIQUE(order_id, tipo)):
//   • nunca duplica: o mesmo pedido não é enfileirado duas vezes; o envio "reserva" a linha antes de chamar o provedor
//     (pendente → enviando), então duas rotinas nunca mandam a mesma mensagem; sem resposta do provedor (tempo esgotado ou
//     reinício no meio do envio) a linha fica "incerto" e NÃO é reenviada (a mensagem pode ter chegado);
//   • nunca perde: falha temporária (sem conexão, 429, 5xx) tenta de novo (1, 5, 15 e 60 min); falha definitiva, incerta
//     ou tentativas esgotadas → o pedido vai para o painel com notificação, mesmo que o dono tenha desligado o painel;
//   • nunca muda o status do pedido: este módulo só lê o pedido.
// Nenhum token sai em log ou resposta (ficam cifrados com settings.seal).
import { one, q, J, nowIso } from '../db/index.js'
import { getConfig, setConfig, seal, unseal } from './settings.js'

export type Provedor = 'cloud' | 'evolution' | 'zapi'
export const PROVEDORES: Record<Provedor, string> = { cloud: 'WhatsApp Cloud API (oficial da Meta)', evolution: 'Evolution API', zapi: 'Z-API' }
const ESPERAS_MIN = [1, 5, 15, 60]
const MAX_TENTATIVAS = ESPERAS_MIN.length + 1
const TEMPO_MS = () => Number(process.env.WHATSAPP_TIMEOUT_MS) || 15_000

/* ---------------------------------------------------------------- configuração (administrador) */
export async function cfgBruta(): Promise<any> { return await getConfig<any>('whatsapp_envio', {}) }
/** Configuração para o painel, sem segredos. */
export async function cfgPublica() {
  const c = await cfgBruta(), p = (c.provedor || '') as Provedor | ''
  return {
    provedor: p, nomeProvedor: p ? PROVEDORES[p] : '', configurado: await configurado(),
    cloud: { phoneNumberId: c.cloud?.phoneNumberId || '', temToken: !!c.cloud?.token, template: c.cloud?.template || '', idioma: c.cloud?.idioma || 'pt_BR', versao: c.cloud?.versao || 'v21.0' },
    evolution: { url: c.evolution?.url || '', instancia: c.evolution?.instancia || '', temApikey: !!c.evolution?.apikey },
    zapi: { instancia: c.zapi?.instancia || '', temToken: !!c.zapi?.token, temClientToken: !!c.zapi?.clientToken },
    provedores: Object.entries(PROVEDORES).map(([id, nome]) => ({ id, nome })),
  }
}
const s = (v: unknown, n: number) => String(v ?? '').trim().slice(0, n)
/** Grava a configuração (segredos só são trocados quando vierem preenchidos; clear=true apaga tudo). */
export async function salvarCfg(b: any) {
  const cur = await cfgBruta()
  if (b?.clear) { await setConfig('whatsapp_envio', {}); return cfgPublica() }
  const p = s(b?.provedor, 20)
  if (p && !(p in PROVEDORES)) throw new Error('Provedor de WhatsApp desconhecido.')
  const seg = async (novo: unknown, antigo: string) => (s(novo, 600) ? await seal(s(novo, 600)) : antigo || '')
  const url = s(b?.evolution?.url, 300).replace(/\/+$/, '')
  if (url && !/^https?:\/\//.test(url)) throw new Error('A URL da Evolution API precisa começar com http:// ou https://.')
  const pid = s(b?.cloud?.phoneNumberId, 40)
  if (pid && !/^\d{6,25}$/.test(pid)) throw new Error('O Phone Number ID da Meta tem só números.')
  const tpl = s(b?.cloud?.template, 120)
  if (tpl && !/^[a-z0-9_]+$/.test(tpl)) throw new Error('O nome do modelo da Meta usa só letras minúsculas, números e "_".')
  const next = {
    provedor: p,
    cloud: { phoneNumberId: pid, token: await seg(b?.cloud?.token, cur.cloud?.token), template: tpl, idioma: s(b?.cloud?.idioma, 10) || 'pt_BR', versao: /^v\d+\.\d+$/.test(s(b?.cloud?.versao, 8)) ? s(b?.cloud?.versao, 8) : (cur.cloud?.versao || 'v21.0') },
    evolution: { url, instancia: s(b?.evolution?.instancia, 120), apikey: await seg(b?.evolution?.apikey, cur.evolution?.apikey) },
    zapi: { instancia: s(b?.zapi?.instancia, 120), token: await seg(b?.zapi?.token, cur.zapi?.token), clientToken: await seg(b?.zapi?.clientToken, cur.zapi?.clientToken) },
  }
  await setConfig('whatsapp_envio', next)
  return cfgPublica()
}
/** Há um provedor com os dados obrigatórios preenchidos? */
export async function configurado(): Promise<boolean> {
  const c = await cfgBruta()
  if (c.provedor === 'cloud') return !!(c.cloud?.phoneNumberId && c.cloud?.token)
  if (c.provedor === 'evolution') return !!(c.evolution?.url && c.evolution?.instancia && c.evolution?.apikey)
  if (c.provedor === 'zapi') return !!(c.zapi?.instancia && c.zapi?.token)
  return false
}

/* ---------------------------------------------------------------- número e texto */
/** Número da empresa em formato internacional só com dígitos (Brasil: acrescenta 55). Vazio = inválido. */
export function numeroWhats(v: unknown): string {
  let d = String(v ?? '').replace(/\D/g, '')
  if (d.startsWith('00')) d = d.slice(2)
  if (d.length === 10 || d.length === 11) d = '55' + d
  return d.length >= 12 && d.length <= 15 ? d : ''
}
const brl = (v: unknown) => 'R$ ' + (Math.round((Number(v) || 0) * 100) / 100).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const PAG: Record<string, string> = { pix: 'Pix (chave da loja)', pixentrega: 'Pix na entrega/retirada', cartao: 'Cartão na entrega/retirada', dinheiro: 'Dinheiro', online: 'Pix automático (Mercado Pago)', local: 'No local', pix_online: 'Pix automático (Mercado Pago)' }
const dataBR = (iso: string) => { try { return new Date(iso).toLocaleString('pt-BR', { timeZone: process.env.TZ_EMPRESAS || 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) } catch { return iso } }
/** Texto completo do pedido para o WhatsApp da empresa: itens, quantidades, valores, cliente, entrega/retirada e pagamento. */
export function textoPedido(o: any, empresa: string, link: string): string {
  const d = J<any>(o.data, {}), L: string[] = []
  L.push(`🛒 *Novo pedido #${o.id}* — ${empresa || d.empresa || 'sua loja'}`)
  L.push(`Recebido em ${dataBR(o.created_at || nowIso())}${d.canal === 'agente' ? ' · pelo atendimento automático' : ''}`)
  if (d.agendadoPara) L.push(`📅 *Agendado para ${String(d.agendadoPara.data || '').split('-').reverse().join('/')} às ${d.agendadoPara.hora || ''}*`)
  L.push('', '*Itens*')
  for (const i of d.itens || []) {
    const q = Number(i.qtd) || 1, un = Number(i.preco), vars = (i.vars && i.vars.length ? i.vars.join(', ') : i.variante || '')
    L.push(`• ${q} × ${i.nome}${vars ? ` (${vars})` : ''}${Number.isFinite(un) && i.preco != null ? ` — ${brl(un)} cada = ${brl(un * q)}` : ''}`)
    if (i.obs) L.push(`   obs.: ${i.obs}`)
  }
  L.push('')
  if (d.subtotal != null) L.push(`Subtotal: ${brl(d.subtotal)}`)
  if (Number(d.taxa)) L.push(`Entrega: ${brl(d.taxa)}`)
  if (d.incentivo?.freteGratis) L.push(`Frete grátis (${d.incentivo.nome || 'incentivo'})`)
  if (Number(d.incentivo?.desconto)) L.push(`Desconto (${d.incentivo.nome || 'incentivo'}): − ${brl(d.incentivo.desconto)}`)
  if (Number(d.cupom?.desconto)) L.push(`Cupom ${d.cupom.codigo || ''}: − ${brl(d.cupom.desconto)}`)
  if (Number(d.moedas?.desconto)) L.push(`${d.moedas.qtd || ''} ${d.moedas.simbolo || 'MCoins'}: − ${brl(d.moedas.desconto)}`)
  L.push(`*Total: ${brl(o.total)}*`)
  L.push(`Pagamento: ${PAG[d.pagamento] || d.pagamento || '—'}${d.pago ? ' · *PAGO*' : d.pagamento === 'online' ? ' · aguardando confirmação' : ''}${d.troco ? ` · ${d.troco}` : ''}`)
  L.push('', '*Cliente*', `${d.cliente || '—'}${d.telefone ? ` · ${d.telefone}` : ''}`)
  if (d.modo === 'entrega') {
    const pa = d.enderecoPartes || {}
    L.push('', '*Entrega*', d.endereco || [pa.rua, pa.numero].filter(Boolean).join(', '))
    const extra = [pa.complemento, pa.bairro, pa.cidade].filter(Boolean).join(' · '); if (extra && !String(d.endereco || '').includes(extra)) L.push(extra)
    if (pa.referencia) L.push(`Referência: ${pa.referencia}`)
    if (d.entregaLoc?.lat != null) L.push(`Mapa: https://maps.google.com/?q=${d.entregaLoc.lat},${d.entregaLoc.lng}`)
  } else if (d.tipo !== 'agendamento') L.push('', '*Retirada no local*')
  if (d.obs) L.push('', `Observações: ${d.obs}`)
  if (link) L.push('', `Ver e atualizar o pedido: ${link}`)
  return L.join('\n').slice(0, 4000)
}
/** Resumo numa linha (variável {{2}} do modelo da Meta: sem quebras de linha nem tabulação). */
export function resumoLinha(o: any): string {
  const d = J<any>(o.data, {})
  const itens = (d.itens || []).map((i: any) => `${Number(i.qtd) || 1}x ${i.nome}`).join(', ')
  const ent = d.modo === 'entrega' ? `entrega: ${d.endereco || ''}` : 'retirada'
  return `${itens} | total ${brl(o.total)} | ${d.cliente || ''} ${d.telefone || ''} | ${ent} | pagamento: ${PAG[d.pagamento] || d.pagamento || ''}`.replace(/[\r\n\t]+/g, ' ').replace(/ {4,}/g, '   ').slice(0, 1000)
}

/* ---------------------------------------------------------------- provedores */
type Resultado = { ok: true; msgId: string; via: string } | { ok: false; temporario: boolean; incerto: boolean; erro: string }
async function chamar(url: string, init: RequestInit): Promise<{ r: Response | null; j: any; incerto: boolean; semConexao: boolean }> {
  try {
    const r = await fetch(url, { ...init, signal: AbortSignal.timeout(TEMPO_MS()) })
    const j: any = await r.json().catch(() => ({}))
    return { r, j, incerto: false, semConexao: false }
  } catch (e: any) {
    const tempo = e?.name === 'TimeoutError' || e?.name === 'AbortError'
    return { r: null, j: null, incerto: tempo, semConexao: !tempo } // tempo esgotado: o provedor pode ter enviado
  }
}
const resumoErro = (j: any, st: number) => String(j?.error?.message || j?.message || j?.error || j?.response?.message || `HTTP ${st}`).replace(/\s+/g, ' ').slice(0, 200)
const temporario = (st: number) => st === 429 || st >= 500
async function viaCloud(c: any, para: string, texto: string, o: any): Promise<Resultado> {
  const base = (process.env.WHATSAPP_CLOUD_BASE || 'https://graph.facebook.com').replace(/\/$/, ''), tok = await unseal(c.token || '')
  if (!tok) return { ok: false, temporario: false, incerto: false, erro: 'Token da Meta ilegível ou ausente.' }
  const url = `${base}/${c.versao || 'v21.0'}/${c.phoneNumberId}/messages`, h = { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' }
  const envia = async (body: any) => chamar(url, { method: 'POST', headers: h, body: JSON.stringify({ messaging_product: 'whatsapp', recipient_type: 'individual', to: para, ...body }) })
  let x = await envia({ type: 'text', text: { preview_url: false, body: texto } })
  // fora da janela de 24 h (131047) ou destinatário sem conversa: a Meta só aceita um modelo aprovado
  const foraJanela = (j: any) => [131047, 131026, 470].includes(Number(j?.error?.code)) || /24 ?h|re-?engagement|template/i.test(String(j?.error?.message || ''))
  if (x.r && !x.r.ok && foraJanela(x.j) && c.template) {
    x = await envia({ type: 'template', template: { name: c.template, language: { code: c.idioma || 'pt_BR' }, components: [{ type: 'body', parameters: [{ type: 'text', text: `#${o.id}` }, { type: 'text', text: resumoLinha(o) }] }] } })
    if (x.r?.ok) return { ok: true, msgId: String(x.j?.messages?.[0]?.id || ''), via: 'cloud:modelo' }
  }
  if (x.r?.ok) return { ok: true, msgId: String(x.j?.messages?.[0]?.id || ''), via: 'cloud' }
  if (!x.r) return { ok: false, temporario: x.semConexao, incerto: x.incerto, erro: x.incerto ? 'A Meta não respondeu a tempo.' : 'Sem conexão com a Meta.' }
  const extra = foraJanela(x.j) && !c.template ? ' (fora da janela de 24 h: configure um modelo aprovado no painel)' : ''
  return { ok: false, temporario: temporario(x.r.status), incerto: false, erro: resumoErro(x.j, x.r.status) + extra }
}
async function viaEvolution(c: any, para: string, texto: string): Promise<Resultado> {
  const key = await unseal(c.apikey || ''); if (!key) return { ok: false, temporario: false, incerto: false, erro: 'Chave da Evolution API ilegível ou ausente.' }
  const x = await chamar(`${c.url}/message/sendText/${encodeURIComponent(c.instancia)}`, { method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ number: para, text: texto }) })
  if (x.r?.ok) return { ok: true, msgId: String(x.j?.key?.id || x.j?.id || ''), via: 'evolution' }
  if (!x.r) return { ok: false, temporario: x.semConexao, incerto: x.incerto, erro: x.incerto ? 'A Evolution API não respondeu a tempo.' : 'Sem conexão com a Evolution API.' }
  return { ok: false, temporario: temporario(x.r.status), incerto: false, erro: resumoErro(x.j, x.r.status) }
}
async function viaZapi(c: any, para: string, texto: string): Promise<Resultado> {
  const tok = await unseal(c.token || ''), ct = await unseal(c.clientToken || ''); if (!tok) return { ok: false, temporario: false, incerto: false, erro: 'Token da Z-API ilegível ou ausente.' }
  const base = (process.env.ZAPI_BASE || 'https://api.z-api.io').replace(/\/$/, '')
  const x = await chamar(`${base}/instances/${encodeURIComponent(c.instancia)}/token/${encodeURIComponent(tok)}/send-text`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(ct ? { 'Client-Token': ct } : {}) }, body: JSON.stringify({ phone: para, message: texto }) })
  if (x.r?.ok && !x.j?.error) return { ok: true, msgId: String(x.j?.messageId || x.j?.zaapId || x.j?.id || ''), via: 'zapi' }
  if (!x.r) return { ok: false, temporario: x.semConexao, incerto: x.incerto, erro: x.incerto ? 'A Z-API não respondeu a tempo.' : 'Sem conexão com a Z-API.' }
  return { ok: false, temporario: temporario(x.r.status), incerto: false, erro: resumoErro(x.j, x.r.status) }
}
/** Envia um texto pelo provedor configurado (sem fila). Usado pela fila e pelo teste do painel. */
export async function enviarTexto(para: string, texto: string, o: any = { id: 0, data: '{}', total: 0 }): Promise<Resultado> {
  const c = await cfgBruta()
  if (!(await configurado())) return { ok: false, temporario: false, incerto: false, erro: 'O envio de WhatsApp não está configurado pelo administrador do sistema.' }
  if (c.provedor === 'cloud') return viaCloud(c.cloud, para, texto, o)
  if (c.provedor === 'evolution') return viaEvolution(c.evolution, para, texto)
  return viaZapi(c.zapi, para, texto)
}

/* ---------------------------------------------------------------- fila (um envio por pedido) */
const linha = (r: any) => r && ({ id: Number(r.id), businessId: Number(r.business_id), orderId: Number(r.order_id), destino: String(r.destino), status: String(r.status), tentativas: Number(r.tentativas) || 0, provedor: String(r.provedor || ''), erro: String(r.erro || ''), criadoEm: r.criado_em, atualizadoEm: r.atualizado_em, msgId: String(r.msg_id || '') })
export type Envio = ReturnType<typeof linha>
type Reserva = (orderId: number) => Promise<void>
let reservaPainel: Reserva = async () => {}
/** Quem leva o pedido ao painel quando o WhatsApp não pôde ser confirmado (registrado por lib/recebimento-pedidos.ts). */
export function aoFalhar(fn: Reserva) { reservaPainel = fn }

// o aviso de reserva é registrado por recebimento-pedidos.ts; depois de um reinício só este módulo pode estar carregado
async function levarAoPainel(orderId: number) { await import('./recebimento-pedidos.js'); await reservaPainel(orderId).catch((x) => console.error('[whatsapp] aviso no painel:', x?.message)) }
/** Enfileira o envio do pedido (idempotente: a segunda chamada devolve o mesmo envio) e já tenta enviar. */
export async function enfileirar(bid: number, orderId: number, destino: string, texto: string, esperar = false): Promise<Envio> {
  const agora = nowIso()
  try { await q('INSERT INTO envios_whatsapp (business_id, order_id, tipo, destino, texto, status, tentativas, criado_em, atualizado_em) VALUES ($1,$2,$3,$4,$5,$6,0,$7,$7)', [bid, orderId, 'novo_pedido', destino, texto, 'pendente', agora]) }
  catch (e) { const ex = await one("SELECT * FROM envios_whatsapp WHERE order_id = $1 AND tipo = 'novo_pedido'", [orderId]); if (ex) return linha(ex)!; throw e } // já existe: não duplica
  const r = linha(await one("SELECT * FROM envios_whatsapp WHERE order_id = $1 AND tipo = 'novo_pedido'", [orderId]))!
  const p = processar(r.id).catch((e) => console.error('[whatsapp] envio:', e?.message))
  if (esperar) await p
  return linha(await one('SELECT * FROM envios_whatsapp WHERE id = $1', [r.id]))!
}
/** Tenta enviar um envio pendente (reserva a linha antes; nunca envia a mesma linha duas vezes ao mesmo tempo). */
export async function processar(id: number): Promise<void> {
  const agora = nowIso()
  const pegou = await q("UPDATE envios_whatsapp SET status = 'enviando', tentativas = tentativas + 1, atualizado_em = $1 WHERE id = $2 AND status = 'pendente' AND (proxima_em IS NULL OR proxima_em <= $1) RETURNING id", [agora, id])
  if (!pegou.length) return
  const e = (await one('SELECT * FROM envios_whatsapp WHERE id = $1', [id]))!, o = await one('SELECT id, total, data, created_at FROM orders WHERE id = $1', [e.order_id])
  const prov = String((await cfgBruta()).provedor || '')
  const r: Resultado = !String(e.destino) ? { ok: false, temporario: false, incerto: false, erro: 'O WhatsApp cadastrado da empresa é inválido ou está vazio.' }
    : await enviarTexto(String(e.destino), String(e.texto), o || { id: e.order_id, data: '{}', total: 0 })
  if (r.ok) { await q("UPDATE envios_whatsapp SET status = 'enviado', msg_id = $1, provedor = $2, erro = '', atualizado_em = $3 WHERE id = $4", [r.msgId.slice(0, 200), r.via, nowIso(), id]); return }
  const tent = Number(e.tentativas) || 1
  if (r.temporario && !r.incerto && tent < MAX_TENTATIVAS) {
    const prox = new Date(Date.now() + ESPERAS_MIN[Math.min(tent - 1, ESPERAS_MIN.length - 1)] * 60_000).toISOString()
    await q("UPDATE envios_whatsapp SET status = 'pendente', proxima_em = $1, provedor = $2, erro = $3, atualizado_em = $4 WHERE id = $5", [prox, prov, r.erro, nowIso(), id])
    return
  }
  await q('UPDATE envios_whatsapp SET status = $1, provedor = $2, erro = $3, atualizado_em = $4 WHERE id = $5', [r.incerto ? 'incerto' : 'falhou', prov, r.erro, nowIso(), id])
  console.error(`[whatsapp] pedido #${e.order_id}: ${r.incerto ? 'sem confirmação do provedor' : 'não enviado'} (${r.erro}) — levado ao painel`)
  await levarAoPainel(Number(e.order_id))
}
/** Agendador: reenvia os pendentes vencidos e trata envios que ficaram presos (reinício no meio do envio). */
export async function processarPendentes(): Promise<number> {
  const agora = nowIso(), presos = new Date(Date.now() - 5 * 60_000).toISOString()
  for (const r of await q("SELECT id, order_id FROM envios_whatsapp WHERE status = 'enviando' AND atualizado_em < $1", [presos])) {
    const ok = await q("UPDATE envios_whatsapp SET status = 'incerto', erro = 'interrompido durante o envio (não reenviado para não duplicar)', atualizado_em = $1 WHERE id = $2 AND status = 'enviando' RETURNING id", [agora, (r as any).id])
    if (ok.length) await levarAoPainel(Number((r as any).order_id))
  }
  const pend = await q("SELECT id FROM envios_whatsapp WHERE status = 'pendente' AND (proxima_em IS NULL OR proxima_em <= $1) ORDER BY id LIMIT 50", [agora])
  for (const r of pend) await processar(Number((r as any).id))
  return pend.length
}
export async function envioDoPedido(orderId: number): Promise<Envio | null> { return linha(await one("SELECT * FROM envios_whatsapp WHERE order_id = $1 AND tipo = 'novo_pedido'", [orderId])) || null }
export async function ultimosEnvios(bid: number, n = 10): Promise<Envio[]> { return (await q('SELECT * FROM envios_whatsapp WHERE business_id = $1 ORDER BY id DESC LIMIT $2', [bid, n])).map(linha) as Envio[] }
