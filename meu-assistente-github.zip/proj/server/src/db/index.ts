// Camada de banco: interface pequena (query/tx) com adaptador PostgreSQL (produção)
// e adaptador SQLite embutido do Node (somente para os testes automatizados offline).
export type Row = Record<string, any>
export interface Db {
  query<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R[]>
  tx<T>(fn: (q: Db) => Promise<T>): Promise<T>
  exec(sql: string): Promise<void>
  close(): Promise<void>
  kind: 'postgres' | 'sqlite'
}

let current: Db | null = null
// Contador de consultas por requisição (indicador de desempenho): cada requisição que chama contarConsultas() recebe o
// seu próprio contador, isolado das outras pelo contexto assíncrono. Sem contador ativo, não custa nada.
import { AsyncLocalStorage } from 'node:async_hooks'
type Contador = { n: number; sql?: string[]; memo: Map<string, unknown> | null; diag?: boolean; pai?: Contador }
const CONTADOR = new AsyncLocalStorage<Contador>()
export function contarConsultas() { const s0 = CONTADOR.getStore(), pai = s0?.diag ? s0 : undefined // sempre um contador novo (memória própria); o de diagnóstico da requisição só recebe a soma
  const s: Contador = { n: 0, memo: process.env.MEMO_REQUISICAO === '0' ? null : new Map(), ...(process.env.DIAG_CONSULTAS ? { sql: [] } : {}), ...(pai ? { pai } : {}) }; CONTADOR.enterWith(s); return s }
/** Memória DA REQUISIÇÃO atual (null fora de uma requisição medida): leituras repetidas da mesma configuração numa só
 *  mensagem vão ao banco uma vez. Nada é compartilhado entre requisições — não há risco de dado desatualizado. */
export function memoRequisicao() { return CONTADOR.getStore()?.memo ?? null }
/** Contém um contarConsultas() (que usa enterWith) dentro de um escopo próprio: a memória e a contagem criadas lá dentro
 *  não vazam para quem chamou (ex.: o executor de tarefas do chat, que roda fora de uma requisição HTTP). */
/** Trabalho de fundo disparado DENTRO de uma requisição mas que não pertence a ela (gravações em lote, consolidação):
 *  roda sem o contador/memória da requisição, então não pesa na conta de consultas por mensagem. */
export function foraDaRequisicao<T>(fn: () => T): T { return CONTADOR.exit(fn) }
export function isolado<T>(fn: () => Promise<T>): Promise<T> { return CONTADOR.run(CONTADOR.getStore() as Contador, fn) }
/** Executa uma requisição num escopo próprio (AsyncLocalStorage.run, que termina junto com ela — nada vaza para outras
 *  requisições): memo = memória de leituras desta requisição; diag = conta as consultas (auditoria, DIAG_CONSULTAS_ROTA=1). */
export async function emEscopoDeRequisicao<T>(o: { memo: boolean; diag: boolean }, fn: () => Promise<T>): Promise<{ v: T; c: Contador | null }> {
  if (!o.memo && !o.diag) return { v: await fn(), c: null }
  const s: Contador = { n: 0, memo: o.memo && process.env.MEMO_REQUISICAO !== '0' ? new Map() : null, ...(o.diag ? { diag: true } : {}), ...(o.diag && process.env.DIAG_CONSULTAS ? { sql: [] } : {}) }
  return { v: await CONTADOR.run(s, fn), c: s }
}
/** Diagnóstico (DIAG_CONSULTAS_ROTA=1): conta as consultas de QUALQUER requisição, sem memória por requisição. */
export function setDb(d: Db) {
  const orig = d.query.bind(d)
  d.query = ((sql: string, params?: unknown[]) => { const s = CONTADOR.getStore(); if (s) { const linha = sql.replace(/\s+/g, ' ').slice(0, 70) + ' ' + JSON.stringify(params || []).slice(0, 50); s.n++; s.sql?.push(linha); if (s.pai) { s.pai.n++; s.pai.sql?.push(linha) } } return orig(sql, params) }) as Db['query']
  current = d
}
export function db(): Db {
  if (!current) throw new Error('Banco de dados não inicializado')
  return current
}
export async function one<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R | null> {
  const rows = await db().query<R>(sql, params)
  return rows[0] ?? null
}
export const q = <R extends Row = Row>(sql: string, params?: unknown[]) => db().query<R>(sql, params)

/** Valores JSON vêm como objeto (PostgreSQL JSONB) ou texto (SQLite). */
export function J<T = any>(v: unknown, fallback: T): T {
  if (v === null || v === undefined) return fallback
  if (typeof v === 'string') { try { return JSON.parse(v) as T } catch { return fallback } }
  return v as T
}
export const B = (v: unknown) => v === true || v === 1 || v === '1' || v === 't'
export const nowIso = () => new Date().toISOString()
export function isoOf(v: unknown): string | null {
  if (!v) return null
  if (v instanceof Date) return v.toISOString()
  const s = String(v)
  const d = new Date(s.includes('T') || s.endsWith('Z') ? s : s.replace(' ', 'T') + 'Z')
  return isNaN(d.getTime()) ? s : d.toISOString()
}
/** Empresas ativas do dono (id, data), lidas uma vez por requisição: o chat consulta isso em 3 módulos por mensagem
 *  (CRM, agentes de domínio e indicadores). Somente leitura; fora de requisição, consulta sempre. */
export async function empresasAtivasDoDono(userId: number): Promise<Row[]> {
  const m = memoRequisicao(), k = 'empresasDono:' + userId
  let r = m?.get(k) as Row[] | undefined
  if (!r) { r = await q("SELECT id, data FROM businesses WHERE owner_id = $1 AND status = 'ativo' ORDER BY id", [userId]); m?.set(k, r) }
  return r.map((x) => ({ ...x }))
}
