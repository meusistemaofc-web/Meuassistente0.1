import { etapa, comEtapas, etapaAtual } from '../lib/etapas.js'
import { randomBytes } from 'node:crypto'
import { proposeCorrection } from '../ai/brain.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { identityReply } from '../lib/identity.js'
import { financeSummary } from '../ai/finsummary.js'
import { moduleIntent } from '../lib/modcatalog.js'
import type { UpFile } from '../lib/multipart.js'
import { findLearnedAnswer, saveLearnedAnswer } from '../ai/brain.js'
import { transcribeAudio } from '../ai/docs.js'
import { documentReply } from '../ai/finchat.js'
import { requireModule, modules } from '../lib/usermod.js'
import { isAgendaQuery, agendaReply } from '../ai/agenda.js'
import { financeReply } from '../ai/finchat.js'
import { parseAppointment, parseReminder } from '../ai/appt.js'
import { cardFor } from '../ai/assistant.js'
import { createItem, serialize } from './items.js'
import { humanDate, localDate } from '../lib/time.js'
import { useQuota, refundQuota } from '../lib/usage.js'
import { maybeAd } from './businesses.js'
import { quickReply } from '../ai/intents.js'
import { applyRules } from '../ai/rules.js'
import { registrarUso, type Uso } from '../ai/brain-usage.js'
// /api/chat, /api/conversations — conversas com o assistente.
// Contrato reconstruído do componente de chat (index-MaCmp03.js): a resposta traz
// {conversation, userMessage, assistantMessage}; IDs de conversa são UUIDs gerados no aparelho.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, J, B, db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { runAssistant } from '../ai/assistant.js'
import type { ChatMsg } from '../ai/provider.js'
import { hashOf } from '../ai/once.js'

const CONV_ID = /^[A-Za-z0-9-]{8,64}$/
const convOut = (c: any) => c && ({ id: c.id, title: c.title, pinned: B(c.pinned), createdAt: c.created_at, updatedAt: c.updated_at })
/** Códigos internos (ex.: [rem:34]) nunca aparecem para o usuário. */
export const cleanCodes = (t: string) => String(t || '').replace(/\s*\[(?:rem|lem|lembrete|reminder|task|tarefa|appt|appointment|compromisso|bill|conta|exp|expense|gasto|note|nota|shop|shopping|item|id)\s*[:#]\s*\d+\]/gi, '').replace(/[ \t]+\n/g, '\n').trim()
const avisoTxt = (it: any) => { const r: number[] = Array.isArray(it.reminders) ? it.reminders : it.reminderMinutes > 0 ? [it.reminderMinutes] : []; if (!r.length) return 'Sem aviso antecipado.'; const f = (m: number) => m >= 1440 && m % 1440 === 0 ? `${m / 1440} dia${m >= 2880 ? 's' : ''}` : m >= 60 && m % 60 === 0 ? `${m / 60} hora${m >= 120 ? 's' : ''}` : `${m} minutos`; return `Vou te avisar ${[...r].sort((a, b) => b - a).map(f).join(' e ')} antes.` }
export const LINK_CARD = /^⟦lc:\d+:[A-Za-z0-9-]{8,40}⟧$/
function msgOut(m: any, byId?: Map<number, any>) {
  const replyTo = m.reply_to_id && byId?.get(Number(m.reply_to_id))
  return {
    id: Number(m.id), role: m.role, content: m.role === 'assistant' ? cleanCodes(m.content) : m.content, cards: J(m.cards, []), ...(LINK_CARD.test(String(m.content)) ? { type: 'link_card' } : {}), voiceMessageId: null, createdAt: m.created_at,
    replyToId: m.reply_to_id ? Number(m.reply_to_id) : null,
    ...(replyTo ? { replyTo: { id: Number(replyTo.id), role: replyTo.role, content: String(replyTo.content).slice(0, 200) } } : {}),
    ...(B(m.superseded) ? { superseded: true } : {}),
  }
}

export async function ensureConversation(u: SessionUser, id: string, firstText: string) {
  if (!CONV_ID.test(id)) fail(400, 'Conversa inválida.', 'invalid')
  const c = await one('SELECT * FROM conversations WHERE id = $1', [id])
  if (c) { if (Number(c.user_id) !== u.id) fail(404, 'Conversa não encontrada.', 'not_found'); return c }
  const now = nowIso()
  const title = firstText.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'
  await q('INSERT INTO conversations (id, user_id, title, pinned, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5)', [id, u.id, title, false, now])
  return one('SELECT * FROM conversations WHERE id = $1', [id])
}
async function history(convId: string, beforeId?: number): Promise<ChatMsg[]> {
  const rows = await q(`SELECT role, content FROM messages WHERE conversation_id = $1 AND superseded = $2 AND content NOT LIKE '⟦lc:%' ${beforeId ? 'AND id < $3' : ''} ORDER BY id DESC LIMIT 40`,
    beforeId ? [convId, false, beforeId] : [convId, false])
  // avisos de FALHA da IA (tempo esgotado, indisponível) ficam na conversa para o usuário, mas não vão como "resposta" ao modelo
  // na próxima mensagem (contaminavam o contexto: a IA repetia o aviso ou achava que já tinha respondido)
  return rows.reverse().filter((r) => !(r.role === 'assistant' && FALHA_IA.test(String(r.content || '')))).map((r) => ({ role: r.role, content: r.content }))
}
export const FALHA_IA = /^(Não consegui concluir sua resposta agora|Ainda estou terminando a pesquisa|A IA não conseguiu terminar a resposta dentro do tempo limite|Não consegui responder agora\. Tente de novo|Estou um pouco lento agora\.|Estou me recuperando de uma instabilidade)/
export async function insertMsg(u: SessionUser, convId: string, role: string, content: string, cards: any[] = [], replyTo: number | null = null) {
  if (role === 'assistant') content = cleanCodes(content)
  const r = await q('INSERT INTO messages (conversation_id, user_id, role, content, cards, reply_to_id, superseded, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
    [convId, u.id, role, content, JSON.stringify(cards), replyTo, false, nowIso()])
  return r[0]
}

const CHAT_CONFIG_KEYS = ['usage_plans', 'modules', 'adaptive', 'fin_dict', 'ceo_identity', 'brain', 'brain_stats', 'engine', 'agenda_ia', 'cognition', 'inteligencia', 'ai_router', 'ai-status', 'ai_providers', 'ad_frequency', 'execucao', 'preditivo', 'aprendizado', 'multiagente', 'cerebro_central']
const CHAT_UM_KEYS = ['idioma', 'doc_pending', 'doc_dup', 'fin_dup', 'fin_pending', 'fin_partial_confirm', 'fin_fix_pending', 'ad_state', 'lembrete_guia']
// cada mensagem num escopo próprio: a memória de leituras e o contador desta mensagem nunca vazam para a próxima
async function chatPostInner(ctx: Ctx, live?: { onDelta: (s: string) => void; onReset: () => void }) { const PB = await import('../ai/bloqueio-pesquisa.js'); return (await import('../db/index.js')).isolado(() => PB.noTurno(String((ctx.body as any)?.text || ''), () => chatPostInner0(ctx, live))) } // escopo do turno: bloqueio de pesquisa (ai/bloqueio-pesquisa.ts)
async function chatPostInner0(ctx: Ctx, live?: { onDelta: (s: string) => void; onReset: () => void }) {
  const T = (await import('../lib/timing.js')).timer(), CONS = (await import('../db/index.js')).contarConsultas(), reqId = globalThis.crypto.randomUUID().slice(0, 8) // id da requisição: liga o rastro do Cérebro ao log técnico
  const u = requireUser(ctx)
  // desempenho: configurações e estados que o chat sempre lê vêm em 2 consultas, em vez de ~22 (memória só desta requisição)
  await (await import('../lib/settings.js')).prefetchConfig(CHAT_CONFIG_KEYS).catch(() => {})
  await (await import('../lib/usermod.js')).prefetchUM(u.id, CHAT_UM_KEYS).catch(() => {})
  const b = ctx.body || {}
  delete (b as any).__anexo; delete (b as any).__fotoBusca // só o próprio servidor preenche (foto enviada no modo Gestão da Empresa / Busca)
  etapa('analisando')
  // anexos: áudio (transcrito), foto ou documento (lidos pelo Gemini), ou várias fotos enviadas antes em /api/images
  let pre: { content: string; cards: any[] } | null = null
  const files: UpFile[] = (ctx as any).files || []
  const audio = files.find((f) => f.field === 'audio'), doc = files.find((f) => f.field === 'image' || f.field === 'document')
  if (audio) { await requireModule('voz'); etapa('audio'); const tx = (await transcribeAudio(audio.data, audio.mime)).slice(0, 4000); if (!tx) fail(422, 'Não entendi o áudio. Tente falar de novo, mais perto do microfone.', 'audio_empty'); b.text = tx }
  else if (doc) {
    await requireModule('imagens')
    // tipo REAL pelos bytes (o navegador às vezes declara errado: "application/octet-stream", HEIC chamado de .jpg…)
    const real = (await import('../ai/visao.js')).examinar(doc.data)
    const mime = real ? real.mime : doc.mime === 'application/octet-stream' && /\.pdf$/i.test(doc.filename) ? 'application/pdf' : doc.mime
    // modo Busca: QUALQUER imagem vai para a busca visual, que confere o arquivo e explica o problema se não der para analisar
    const fotoBusca = doc.field === 'image' && (/^image\//.test(mime) || mime === 'application/octet-stream') && await (await import('../modos/busca.js')).usaFotoBusca(u.id, str(b.conversationId, 64), b.modo, str(b.text, 500)).catch(() => false)
    if (!fotoBusca && !/^(image\/(jpeg|png|webp|heic|heif)|application\/pdf)$/.test(mime)) fail(415, 'Envie uma foto (JPG, PNG) ou um PDF.', 'unsupported_file')
    // modo Gestão da Empresa ativo: a foto vai para a prévia do produto (não é lida como documento)
    if (/^image\/(jpeg|png|webp)$/.test(mime) && await (await import('../modos/gestao.js')).usaFoto(u.id, str(b.conversationId, 64), b.modo)) (b as any).__anexo = `data:${mime};base64,${doc.data.toString('base64')}`
    // modo Busca ativo (ou legenda "onde compro isso?" sem outro modo): o ARQUIVO ORIGINAL (bytes, não o nome) vai para a busca visual
    else if (fotoBusca) { (b as any).__anexo = `data:${mime};base64,${doc.data.toString('base64')}`; (b as any).__fotoBusca = true; if (b.modo === undefined) b.modo = 'busca' }
    else { etapa(mime === 'application/pdf' ? 'documentos' : 'imagem')
    pre = await documentReply(u, doc.data, mime, str(b.text, 500)) }
    b.text = str(b.text, 500) || (doc.field === 'image' ? '📷 Foto enviada' : `📄 ${doc.filename || 'Documento'}`)
  } else if (b.photos?.batchId) {
    await requireModule('imagens')
    const batch = takeBatch(String(b.photos.batchId), u.id)
    if (!batch.length) fail(400, 'As fotos expiraram. Envie de novo.', 'invalid')
    const f0 = batch[0]; let gest = /^image\/(jpeg|png|webp)$/.test(f0.mime) && await (await import('../modos/gestao.js')).usaFoto(u.id, str(b.conversationId, 64), b.modo)
    if (!gest && /^image\//.test(f0.mime) && await (await import('../modos/busca.js')).usaFotoBusca(u.id, str(b.conversationId, 64), b.modo, str(b.text, 500)).catch(() => false)) { gest = true; (b as any).__fotoBusca = true; if (b.modo === undefined) b.modo = 'busca' } // busca visual: a primeira foto é a do produto
    if (gest) (b as any).__anexo = `data:${f0.mime};base64,${f0.data.toString('base64')}`
    const outs: string[] = []; if (!gest) etapa('imagem')
    if (!gest) for (const f of batch) { try { outs.push((await documentReply(u, f.data, f.mime, str(b.text, 500))).content) } catch (e: any) { outs.push(`Foto ${f.position}: ${e?.message || 'não foi possível ler'}`) } }
    if (!gest) pre = { content: outs.map((c, i) => (batch.length > 1 ? `Foto ${batch[i].position}: ` : '') + c).join('\n'), cards: [] }
    b.text = str(b.text, 500) || `📷 ${batch.length} fotos enviadas`
  }
  const convId = str(b.conversationId, 64)

  if (b.forwardOf) {
    const src = await one('SELECT m.* FROM messages m WHERE m.id = $1 AND m.user_id = $2', [Number(b.forwardOf), u.id])
    if (!src) fail(404, 'Mensagem não encontrada.', 'not_found')
    await ensureConversation(u, convId, src!.content)
    await insertMsg(u, convId, src!.role, src!.content, J(src!.cards, []))
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
    return { ok: true }
  }

  // o texto como a pessoa escreveu (gravado na conversa) e o texto ENTENDIDO (abreviações e erros de digitação nas palavras
  // de comando corrigidos; continuações resolvidas pelo histórico mais abaixo) — só o entendido vai para os motores
  let textoOriginal = str(b.text, 8000)
  if (!textoOriginal) fail(400, 'Escreva uma mensagem.', 'invalid', 'text')
  const textoDigitado = textoOriginal, inicioTurno = nowIso() // o que a pessoa digitou (gravado na conversa) e o início do turno (ações deste turno)
  const CMP = await import('../ai/compreensao.js')
  let text = CMP.normalizar(textoOriginal).texto
  // CÁLCULO AUTOCONTIDO: os números estão na própria mensagem → nada de dados pessoais, histórico, memórias, Cérebro ou ferramentas (lib/calc-negocio.ts)
  const CALC = await import('../lib/calc-negocio.js'), calcAuto = !b.resendOf && CALC.ehCalculoAutocontido(textoOriginal)

  if (b.resendOf) {
    const orig = await one("SELECT * FROM messages WHERE id = $1 AND user_id = $2 AND role = 'user'", [Number(b.resendOf), u.id])
    if (!orig) fail(404, 'Mensagem não encontrada.', 'not_found')
    const later = await q('SELECT id FROM messages WHERE conversation_id = $1 AND id > $2 AND superseded = $3', [orig!.conversation_id, orig!.id, false])
    const rrU: Uso[] = []; const rr = await applyRules({ user: u, canal: 'chat', texto: text, conversationId: orig!.conversation_id }).catch(() => null); if (rr) rrU.push(...rr.usos)
    const histR = await history(orig!.conversation_id, Number(orig!.id))
    // reenvio também passa pelo motor de cálculo/quantidades (a conta nunca vai para a IA, nem no reenvio)
    const contaR: any = (await import('../lib/math.js')).solveMath(text) || (await import('../lib/unidades.js')).resolverQuantidade(textoOriginal, histR as any)
    const reply = rr?.terminal && rr.reply ? { content: rr.reply, cards: [] as any[] } : contaR && !contaR.erro ? { content: contaR.resposta || `${contaR.expr} = **${contaR.texto}**`, cards: [] as any[] } : await runAssistant(u, histR, text, undefined, '', rrU)
    if (rr?.rodape.length) reply.content += '\n\n' + [...new Set(rr.rodape)].join('\n')
    await q('UPDATE messages SET content = $1 WHERE id = $2', [textoOriginal, orig!.id])
    if (later.length) await q(`UPDATE messages SET superseded = $1 WHERE conversation_id = $2 AND id > $3`, [true, orig!.conversation_id, orig!.id])
    const am = await insertMsg(u, orig!.conversation_id, 'assistant', reply.content, reply.cards)
    await registrarUso(rrU, { canal: 'chat', userId: u.id, conversationId: orig!.conversation_id, messageId: Number(am.id) })
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), orig!.conversation_id])
    const conv = await one('SELECT * FROM conversations WHERE id = $1', [orig!.conversation_id])
    return { resent: true, superseded: later.map((r) => Number(r.id)), userMessage: msgOut({ ...orig, content: textoOriginal }), assistantMessage: msgOut(am), conversation: convOut(conv), usageAlert: null }
  }

  let conv = await ensureConversation(u, convId, textoOriginal)
  if (conv && conv.title === 'Nova conversa' && textoOriginal) { // conversa criada por um cartão de link: o título vem da primeira pergunta real
    const t = textoOriginal.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'; await q('UPDATE conversations SET title = $1 WHERE id = $2', [t, convId]); conv = { ...conv, title: t }
  }
  const replyToId = b.replyToId ? Number(b.replyToId) : null
  const hist = await history(convId)
  // DESCOBERTA (ai/descoberta.ts): resposta curta à pergunta de contexto feita antes — vira fato explícito e o pedido ORIGINAL
  // segue em seguida ("quero organizar meus compromissos" → "de trabalho" → a agenda organizada); outro pedido = não insiste
  let prefixoDescoberta = ''
  if (!pre && !(b as any).__fotoBusca && !b.modo) {
    const dr = await (await import('../ai/descoberta.js')).responder(u, convId, textoDigitado).catch((e) => { console.error('[descoberta]', e?.message); return null })
    if (dr?.original) { textoOriginal = dr.original; text = CMP.normalizar(dr.original).texto; prefixoDescoberta = dr.ack }
    else if (dr) pre = { content: dr.ack, cards: [] }
  }
  // resposta "sim"/"não" (ou os botões Confirmar/Cancelar) à pergunta de confirmação de uma ação de impacto na empresa ativa
  // (ex.: pausar a loja): executa ou cancela aqui, antes de qualquer outro motor, sem depender da IA lembrar do código
  if (!pre && !(b as any).__fotoBusca) { const rc = await (await import('../ai/empresa-admin.js')).respostaConfirmacao(u, textoOriginal || text, String([...hist].reverse().find((m: any) => m.role === 'assistant')?.content || '')).catch((e) => { console.error('[empresa-chat]', e?.message); return null }); if (rc) pre = { content: rc.content, cards: [] } }
  // COMPREENSÃO PELO CONTEXTO: "e ontem?" depois de uma consulta vira a consulta com o novo período (para os motores);
  // "e quem criou?" ganha o assunto da conversa; o domínio da conversa desambigua nomes (veja ai/compreensao.ts)
  // MOTOR DE PRIORIDADE (ai/prioridade.ts): operação interna e continuação vêm antes de qualquer pesquisa; nelas a pesquisa
  // externa fica BLOQUEADA neste turno em todas as camadas (IA com busca, agente de Pesquisa, Cérebro, buscadores)
  const PBq = await import('../ai/bloqueio-pesquisa.js')
  const PRI = (await import('../ai/prioridade.js')).decidir(text, await (await import('../ai/convctx.js')).getCtx(convId, u.id).catch(() => ({})))
  // MODO "PESQUISA NA INTERNET" (⚡): perguntas de conhecimento/atualidade viram pedido explícito de pesquisa (nível 4, com fontes);
  // operações e consultas aos próprios registros continuam internas. Desligado no painel, nada disso acontece.
  if (['conhecimento', 'conversa', 'pesquisa_atual'].includes(PRI.prioridade) && !/^⚡/.test(String(text).trim()) && await (await import('../modos/index.js')).pesquisaNaConversa(u, convId, b).catch(() => false))
    Object.assign(PRI, { prioridade: 'pesquisa_explicita', pesquisa: 'explicita', consulta: PRI.consulta || text, motivo: 'modo Pesquisa na internet ligado nesta conversa', nivel: 4, modo: 'pesquisa' })
  // CÉREBRO COLETIVO (ai/aprendizado-coletivo.ts): só quando a decisão local não reconheceu operação/consulta — frases
  // equivalentes de vários usuários (anônimas, consolidadas) dizem a intenção; nunca passa por cima do contexto individual
  const COLx = await import('../ai/aprendizado-coletivo.js')
  if (!/^⚡/.test(String(text).trim())) COLx.ajustarDecisao(textoOriginal, PRI)
  PBq.anotarDecisao(PRI.prioridade, PRI.dominio, PRI.motivo, { nivel: PRI.nivel, modo: PRI.modo })
  // FOTO NA BUSCA DE PRODUTOS: o turno É uma pesquisa de produto pedida pela pessoa — o texto "📷 Foto enviada" (ou a legenda curta)
  // não pode ser lido como continuação de operação e bloquear a pesquisa da própria busca visual
  const fotoBuscaTurno = !!(b as any).__fotoBusca && typeof (b as any).__anexo === 'string'
  if (PRI.pesquisa === 'bloqueada' && !fotoBuscaTurno) PBq.bloquearPesquisaNoTurno(PRI.motivo, PRI.prioridade, PRI.dominio)
  const pesqExp = PRI.prioridade === 'pesquisa_explicita', pesqAtual = PRI.pesquisa === 'atual'
  const operacional = PRI.prioridade === 'operacao' || PRI.prioridade === 'continuacao_operacao'
  // HIERARQUIA (ai/prioridade.ts): nível 2 de CONSULTA/SUGESTÃO sobre os próprios dados — usa os dados reais, nunca executa
  // (motores de criação/edição ficam de fora e a IA recebe só ferramentas de leitura) e nunca vai para a internet
  const interno = operacional || PRI.prioridade === 'consulta_interna', naoExec = !!PRI.somenteLeitura
  // nível 1: complemento/correção sem verbo de edição ("ah, é com a Dra. Ana", "na verdade foram 45") chega aos editores
  // existentes como o comando canônico equivalente ("troque o cliente para Dra. Ana", "corrija o valor para 45")
  if (PRI.canonico && !fotoBuscaTurno) text = PRI.canonico
  const RES = CMP.resolver(text, hist as any)
  if (RES.textoMotores !== text && !calcAuto) text = RES.textoMotores
  const COG = await import('../ai/cognition.js'), anCog = COG.analisar(text, hist) // leitura da mensagem (intenção, lacunas…): serve também à avaliação da resposta
  // resposta a uma sugestão proativa (sim/não) vale em qualquer caminho de resposta (IA, cérebro, motores internos)
  if (anCog.tipo === 'confirmacao' || anCog.tipo === 'negacao') void (await import('../ai/proativo.js')).registrarResposta(u.id, convId, anCog).catch(() => {})
  // Fase 6: reclamação em texto sobre a resposta anterior vira sinal de aprendizado (só o rótulo; o texto não é guardado)
  if (anCog.tipo !== 'correcao') { const APR = await import('../ai/aprendizado.js'); if (APR.ehReclamacao(text)) void APR.marcarReclamacao(convId, u.id).catch(() => {}) }
  if (anCog.tipo === 'correcao') { void COG.marcarCorrecao(convId, u.id).catch(() => {}); void (await import('../ai/memoria-evolutiva.js')).registrarExperiencia(u, { kind: 'correcao', outcome: 'corrigido', summary: `Correção do usuário: "${text.slice(0, 140)}"`, conversationId: convId, base: hist.filter((m: any) => m.role === 'user').slice(-1).map((m: any) => String(m.content || '')).join(' ') }).catch(() => {}) } // sinal de aprendizado individual
  T.mark('conversa_e_historico')
  let limitMsg: string | null = null
  try { await useQuota(u, 'chat') } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e }
  // IDIOMA: idioma da resposta deste turno (preferência salva → pedido pontual → idioma da mensagem → da conversa → português).
  // Pedido permanente ("sempre me responda em inglês") é salvo na memória do usuário; o idioma de uma mensagem isolada não.
  const IDI = await import('../ai/idioma.js'), GUIA = await import('../ai/guia.js')
  const idi: import('../ai/idioma.js').IdiomaTurno = await IDI.idiomaDoTurno(u.id, text, hist as any).catch((e) => { console.error('[idioma]', e?.message); return { lang: 'pt' as const, origem: 'padrao' as const, preferencia: null, detectado: null, pedido: null } })
  await IDI.marcarTurno(idi)
  // tipo do pedido: execução × explicação × pergunta geral × conversa (orienta o caminho e a IA)
  const tipoPedido = GUIA.classificar(text), soExplicar = tipoPedido === 'explicacao'
  let jaNoIdioma = false, prefixoIdioma = '', viaIdioma = false, viaGuia = false
  if (!pre && !limitMsg && idi.pedido && (idi.pedido.acao === 'definir' || idi.pedido.acao === 'apagar')) {
    const conf = idi.pedido.acao === 'definir' && idi.pedido.lang ? (await IDI.salvarPreferencia(u.id, idi.pedido.lang, convId), IDI.CONFIRMA[idi.pedido.lang]) : (await IDI.apagarPreferencia(u.id), IDI.APAGADA[idi.lang])
    if (idi.pedido.resto && idi.pedido.resto.split(/\s+/).length >= 3) prefixoIdioma = conf // a mensagem também tem uma pergunta: responde a ela (já no novo idioma)
    else { pre = { content: conf, cards: [] }; jaNoIdioma = true; viaIdioma = true }
  }
  // MODO EXPLICATIVO: "sim/não" à oferta feita na explicação anterior; "como faço…?" sobre um recurso real → passos (nada é executado)
  if (!pre && !limitMsg && !fotoBuscaTurno) { const so = await GUIA.seguirOferta(u, convId, text, hist, b).catch((e) => { console.error('[guia]', e?.message); return null }); if (so) { pre = { content: so.content, cards: [] }; viaGuia = true } }
  if (!pre && !limitMsg && soExplicar && !fotoBuscaTurno) { const g = await GUIA.explicar(u, convId, text).catch((e) => { console.error('[guia]', e?.message); return null }); if (g) { pre = { content: g.content, cards: [] }; viaGuia = true } }
  // Modos Inteligentes (botão ⚡ do campo de digitação): conversa com modo ativo é atendida pelo modo, com o acesso conferido aqui
  let viaModo = false, rastroModo: any = null, metaModo: any = null
  if (!pre && !limitMsg) { const md = await (await import('../modos/index.js')).processar(u, convId, fotoBuscaTurno ? textoOriginal : text, hist, b).catch((e) => { console.error('[modos]', e?.message); return null }); if (md) { pre = { content: md.content, cards: [] }; viaModo = true; rastroModo = (md as any).rastro || null; metaModo = (md as any).meta || null } }
  // DESCOBERTA antes da ação: o pedido depende de um contexto que ainda não se sabe nem se infere ("organizar meus compromissos")
  if (!pre && !limitMsg && !fotoBuscaTurno && !calcAuto && !prefixoDescoberta && !viaModo) { const pd = await (await import('../ai/descoberta.js')).antes(u, convId, textoOriginal).catch(() => null); if (pd) pre = { content: pd, cards: [] } }
  // a foto ia para a busca visual e o modo não a atendeu: diz o que falhou — nunca cai no chat comum com o texto "📷 Foto enviada"
  // (que viraria uma pesquisa sobre "foto enviada", sem a imagem)
  // complemento/correção sem nenhum registro desta conversa: pergunta só a qual registro se refere (sem IA e sem pesquisa)
  if (!pre && !limitMsg && !fotoBuscaTurno && PRI.esclarecer) pre = { content: PRI.esclarecer, cards: [] }
  if (!pre && !limitMsg && fotoBuscaTurno) { pre = { content: 'Não consegui levar sua foto para a busca de produtos agora: o modo Busca não está disponível nesta conversa. Escreva o nome ou descreva o produto (ex.: "tênis branco de corrida") que eu procuro, ou tente enviar a foto de novo em instantes.', cards: [] }; viaModo = true; metaModo = { modo: 'busca', visual: 'nao_encaminhada' } }
  // regras executáveis do Cérebro (cadastradas no painel): cumpridas pelo sistema antes de qualquer motor ou IA
  const usos: Uso[] = []; let viaRegra = false, rodape: string[] = []
  const finOn = (await modules()).financas !== false // módulo Finanças desligado no painel: o chat não lança nem resume finanças
  if (!pre && !limitMsg) {
    const rr = await applyRules({ user: u, canal: 'chat', texto: text, conversationId: convId }).catch((e) => { console.error('[regras]', e?.message); return null })
    if (rr) { usos.push(...rr.usos); rodape = rr.rodape; if (rr.terminal && rr.reply) { pre = { content: rr.reply, cards: [] }; viaRegra = true } }
  }
  // COBRANÇAS PELO CHAT (lib/cobrancas.ts): "crie uma cobrança de R$ 10", "gere um Pix de 150 reais", "a cobrança foi paga?" —
  // Pix real do Mercado Pago com a conexão da empresa ativa; sem conexão válida nada é gerado. O id do envio evita duplicidade.
  let viaCob = false
  if (!pre && !limitMsg && !naoExec) { const cb = await (await import('../lib/cobrancas.js')).noChat(u, textoOriginal || text, String(ctx.req.headers['x-chat-job'] || b.jobId || '')).catch((e) => { console.error('[cobranças]', e?.message); return null }); if (cb) { pre = { content: cb.content, cards: [] }; viaCob = true } }
  // Motor de Aprendizagem Adaptativa: correções/preferências viram aprendizado individual (silencioso); só responde quando a mensagem é só a correção
  if (!pre && !limitMsg) { const ob = await (await import('../ai/adaptive.js')).observar(u, convId, text, hist).catch((e) => { console.error('[aprendizagem]', e?.message); return null }); if (ob?.reply) pre = { content: ob.reply, cards: [] } }
  // Fase 8: objetivos em linguagem natural (planejar → aprovar → executar → verificar), aprovações, andamento e desfazer
  // ADMINISTRAÇÃO DA EMPRESA pelo chat ("altere o preço…", "desative o Pix"): vai direto para a IA com as ferramentas da empresa
  // ativa — planos, memória da conversa, finanças, agenda, lembrete e atalhos não reinterpretam a frase (R$ não vira gasto,
  // 19h30 não vira lembrete, "de novo" não repete a resposta anterior)
  const admEmp = !pre && !soExplicar && !naoExec && (await import('../ai/empresa-admin.js')).comandoEmpresa(textoOriginal || text) && await (await import('../ai/empresa-admin.js')).empresaAdminDisponivel(u).catch(() => false)
  if (admEmp && !pesqExp) PBq.bloquearPesquisaNoTurno('administração da empresa pelo chat', 'operacao', 'empresa') // gestão da empresa nunca vira pesquisa na internet
  // planos de execução: a consulta de andamento ("como está a tarefa?") é leitura e fica; sugestão nunca dispara um plano
  if (!pre && !limitMsg && !soExplicar && !admEmp && PRI.modo !== 'sugestao') { const { localDate } = await import('../lib/time.js'); const ex = await (await import('../ai/execucao-planos.js')).responderChat(u, convId, text, hist as any, localDate(settingsOf(u).timezone)).catch((e) => { console.error('[execução]', e?.message); return e?.status && e?.message ? { content: e.message, cards: [] } : null }); if (ex) pre = ex }
  // motor matemático interno: uma conta nunca vira lançamento, compromisso ou pergunta para IA
  const contaNeg = calcAuto ? CALC.resolverCalculoNegocio(textoOriginal) : null // lucro, margem e desconto exatos, sem IA
  // conversões de unidades e continuação da última conta da conversa ("E dois?", "Na verdade, 5 dias.", "Agora o dobro.") — determinístico e validado (lib/unidades.ts)
  const conta: any = (await import('../lib/math.js')).solveMath(text) || (contaNeg ? { erro: contaNeg } : null) || (!pre && !admEmp ? (await import('../lib/unidades.js')).resolverQuantidade(textoOriginal, hist as any) || (textoOriginal !== text ? (await import('../lib/unidades.js')).resolverQuantidade(text, hist as any) : null) : null)
  // memória da conversa: continua agendamentos em partes, entende referências e retomadas (sem IA)
  // continuidade de lembretes, tarefas, notas e contas (ai/continuidade.ts) e memória da conversa (compromissos): sem IA
  const contOp: any = operacional && !conta && !pre && !limitMsg && !calcAuto && !admEmp ? await (await import('../ai/continuidade.js')).responder(u, convId, PRI.canonico || textoOriginal || text, PRI).catch((e) => { console.error('[continuidade]', e?.message); return null }) : null
  const cx: any = contOp || (!conta && !pre && !limitMsg && !calcAuto && !admEmp && !pesqExp && !naoExec ? await (await import('../ai/convctx.js')).contextReply(u, convId, text, hist).catch((e) => { console.error('[contexto]', e?.message); return null }) : null)
  // resposta ao "Criar lembrete" (botão rápido): a mensagem seguinte é o lembrete, antes de finanças e agenda
  const UMx = await import('../lib/usermod.js')
  let guiaPr: any = null
  if (!pre && !limitMsg && !conta && !cx && !soExplicar && !naoExec && !parseReminder(text, settingsOf(u).timezone)) { const g = await UMx.getUM<any>(u.id, 'lembrete_guia', null); if (g && Date.now() - g.at < 10 * 60_000) guiaPr = parseReminder('me lembra de ' + text.trim().replace(/^(de |que )/i, ''), settingsOf(u).timezone) }
  // ADMINISTRAÇÃO DA EMPRESA pelo chat ("altere o preço…", "desative o Pix"): vai direto para a IA com as ferramentas da empresa
  // ativa — os atalhos de finanças, agenda, lembrete e módulos não interpretam a frase (R$ não vira gasto, 19h30 não vira lembrete)
  let fin: any = null
  if (pre) fin = pre
  else if (!limitMsg && !conta && !cx && !guiaPr && finOn && !soExplicar && !calcAuto && !admEmp && !pesqExp && !naoExec) { try { fin = await (await import('../ai/finchat.js')).appointmentWithDeposit(u, text) ?? await financeReply(u, text, convId) } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } }
  { const fid = Number((String(fin?.content || '').match(/⟦fin:(\d+)⟧/) || [])[1]); if (fid) await (await import('../ai/convctx.js')).lembrarAcao(convId, u.id, 'expense', fid, String(fin.content).replace(/⟦[^⟧]*⟧/g, '').slice(0, 120)).catch(() => {}) }
  let appt: any = null
  let modCard: any = null
  if (conta) modCard = { content: conta.erro || conta.resposta || `${conta.expr} = **${conta.texto}**`, cards: [] }
  if (cx) modCard = cx
  // RESOLVEDOR LOCAL do Cérebro: comando de administração com estrutura clara executa sem IA, pela mesma ferramenta e validações
  if (admEmp && !modCard && !pre && !limitMsg) { const rl = await (await import('../ai/resolver-local.js')).resolverEmpresa(u, textoOriginal || text).catch((e) => { console.error('[resolvedor local]', e?.message); return null }); if (rl) modCard = { content: rl.content, cards: [] } }
  if (!limitMsg && !fin && !conta && !cx && !guiaPr && !calcAuto && !admEmp && !pesqExp && isAgendaQuery(text)) appt = await agendaReply(u, text)
  // "e quem criou?" sobre outro assunto da conversa não é pergunta sobre o criador do app
  if (!limitMsg && !fin && !appt && !pre && !conta && !cx) { const idr = RES.seguimento && !/\b(te|voc[eê]|vc|o assistente|meu assistente|esse app|este app|o app|o aplicativo|o sistema|o conecta)\b/i.test(textoOriginal) ? null : await identityReply(text).catch(() => null); if (idr) modCard = { content: idr, cards: [] } }
  if (!limitMsg && !fin && !appt && !pre && !modCard) { const fu = await (await import('../lib/followup.js')).followupChat(u, text).catch(() => null); if (fu) modCard = fu }
  if (!limitMsg && !fin && !appt && !pre && !modCard && (/^(n[aã]o[,.!]?\s+(o certo|na verdade|[eé] |era |s[aã]o |foi )|na verdade[,: ]|corrigindo[,: ]|corre[cç][aã]o[,: ]|errado[,.!]\s|est[aá] errad|isso est[aá] errad|voc[eê] errou)/i.test(text.trim()) || anCog.tipo === 'correcao')) {
    const prevQ = [...hist].reverse().filter((m: any) => m.role === 'user')[0]?.content || ''
    const r = prevQ ? await proposeCorrection(String(prevQ), text, u.id).catch(() => null) : null
    // a resposta anterior usou conhecimentos do Cérebro Central? a correção fica anotada neles (revisão do administrador)
    // e, até a revisão, o chat responde sobre isso com a ressalva — o mesmo erro não volta como certeza
    const ult: any = await one("SELECT t.used_ids FROM brain_chat_traces t JOIN messages m ON m.id = t.message_id WHERE m.conversation_id = $1 AND m.role = 'assistant' ORDER BY m.id DESC LIMIT 1", [convId]).catch(() => null)
    const usados = J<number[]>(ult?.used_ids, []).filter((x) => Number(x) > 0), C2 = usados.length ? await import('../ai/cerebro/central.js') : null
    let marcados = 0; for (const id of usados.slice(0, 3)) if (await C2!.registrarContestacao(Number(id), text, 'usuário ' + u.id).catch(() => false)) marcados++
    if ((r && (r as any).ok) || marcados) modCard = { content: marcados ? 'Obrigado pela correção! Anotei no conhecimento que usei na resposta e ele fica marcado para revisão — até lá, eu respondo sobre isso com essa ressalva.' : 'Obrigado pela correção! Guardei essa informação no Cérebro para revisão, assim eu aprendo e não repito o erro.', cards: [] }
  }
  if (!limitMsg && !fin && !appt && !pre && !modCard && finOn && !calcAuto && !admEmp) { const fr = await financeSummary(u, text).catch(() => null); if (fr) modCard = fr }
  // "Criar lembrete" sem detalhes (botão rápido): pergunta o quê e quando; a próxima mensagem vira o lembrete
  if (!limitMsg && !fin && !appt && !pre && !modCard && /^(quero |eu quero |vamos |pode )?(criar|crie|cria|novo|nova|adicionar|adiciona|fazer|faz|definir|colocar|programar|marcar)( um| uma| o)?( novo)? lembrete[.!]?$/i.test(text.trim())) {
    await UMx.setUM(u.id, 'lembrete_guia', { at: Date.now() })
    modCard = { content: 'Do que você quer ser lembrado e quando? Escreva, por exemplo: “pagar a internet amanhã às 9h” ou “tomar remédio daqui a 2 horas”.', cards: [] }
  }
  if (!limitMsg && !fin && !appt && !pre && !modCard && !admEmp && !pesqExp) { const m = moduleIntent(text); if (m) modCard = { content: `${m.label} — ${m.desc} ⟦mod:${m.key}⟧`, cards: [] } }
  if (!limitMsg && !fin && !appt && !conta && !cx && !guiaPr && !soExplicar && !calcAuto && !admEmp && !pesqExp && !naoExec) { const pa = parseAppointment(text, settingsOf(u).timezone); if (pa) { try { const gd: any = await (await import('../ai/adaptive.js')).guardarAgendamento(u, convId, pa as any).catch(() => ({})); if (gd.reply) { appt = { content: gd.reply, cards: [] } } else { await useQuota(u, 'appointment'); const s = settingsOf(u); const AGd = await import('../ai/agendamento-chat.js'), det: any = AGd.extrairDetalhes(text); const rows = await db().tx((t: any) => createItem(u, 'appointment', { ...pa, location: '', reminder_minutes: undefined, ...AGd.camposAgenda({ ...det, cliente_nome: det.cliente_nome || pa.cliente_nome || undefined, cliente_telefone: det.cliente_telefone || pa.cliente_telefone || undefined }) }, t)); /* cliente, telefone, local, duração, responsável e observações ditos na frase vão para o compromisso (antes ficavam de fora) */ const it: any = serialize(rows[0]); await (await import('../ai/convctx.js')).lembrarAcao(convId, u.id, 'appointment', Number(it.id), `"${it.title}" ${it.date} ${it.time}`, it.title).catch(() => {}); appt = { content: `${gd.prefixo || ''}Pronto! Agendei "${it.title}"${it.clienteNome ? ` para ${it.clienteNome}` : ''} ${humanDate(it.date, localDate(s.timezone)).toLowerCase()} às ${it.time}. ${avisoTxt(it)} ⟦appt:${it.id}⟧`, cards: [] } } } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } } }
  // lembrete simples pela frase: cria na hora, sem IA, avisando exatamente no horário pedido
  if (!limitMsg && !fin && !appt && !modCard && !soExplicar && !calcAuto && !admEmp && !pesqExp && !naoExec) {
    const pr = parseReminder(text, settingsOf(u).timezone) || guiaPr
    if (guiaPr && pr === guiaPr) await UMx.setUM(u.id, 'lembrete_guia', null)
    if (pr) {
      try {
        await useQuota(u, 'reminder')
        const tz = settingsOf(u).timezone, agora = new Date(new Date().toLocaleString('en-US', { timeZone: tz }))
        let when = new Date(agora)
        if (pr.minutesFromNow != null) when = new Date(agora.getTime() + pr.minutesFromNow * 60000)
        else { const [h, m] = String(pr.time).split(':').map(Number); when.setHours(h, m, 0, 0); if (pr.dayOffset) when.setDate(when.getDate() + pr.dayOffset); else if (when.getTime() <= agora.getTime() - 30000) when.setDate(when.getDate() + 1) } // "amanhã"/"depois de amanhã": o dia pedido; sem dia: hoje, ou amanhã se o horário já passou
        const pad = (n: number) => String(n).padStart(2, '0'), date = `${when.getFullYear()}-${pad(when.getMonth() + 1)}-${pad(when.getDate())}`, time = `${pad(when.getHours())}:${pad(when.getMinutes())}`
        const { itemAction } = await import('./items.js'), { db } = await import('../db/index.js')
        const crLem: any = await db().tx((t: any) => itemAction(u, 'create', 'reminder', 0, { message: pr.message, date, time }, t))
        { const lid = Number(crLem?.created?.[0]?.id); if (lid) await (await import('../ai/convctx.js')).lembrarAcao(convId, u.id, 'reminder', lid, 'lembrete: ' + pr.message).catch(() => {}) } // alvo de "mude para 10h"
        const hoje = `${agora.getFullYear()}-${pad(agora.getMonth() + 1)}-${pad(agora.getDate())}`
        const amanha = (() => { const d = new Date(agora); d.setDate(d.getDate() + 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` })()
        const quando = date === hoje ? 'hoje' : date === amanha ? 'amanhã' : `em ${date.split('-').reverse().join('/')}`
        const oQue = pr.message === 'Lembrete' ? '' : ` de ${pr.message.charAt(0).toLowerCase() + pr.message.slice(1)}`
        modCard = { content: `Pronto! Vou te lembrar${oQue} ${quando} às ${time}.`, cards: [] }
      } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧' }
    }
  }
  T.mark('motores_internos')
  const quick = limitMsg || appt || fin || modCard || calcAuto || admEmp || pesqExp || operacional ? null : await quickReply(u, text).catch(() => null) // mercado, impostos: dados reais, sem gastar IA
  T.mark('atalhos')
  let learned: { answer: string; id: number } | null = null
  const usosAntesDaMemoria = usos.length
  // NATUREZA DA MENSAGEM (ai/escopo.ts): comentário/desabafo não busca resposta pronta nem conhecimento; continuação curta
  // sem nenhuma conversa anterior não tem interpretação confiável → pede esclarecimento em vez de adivinhar
  const ESCm = await import('../ai/escopo.js'), comentario = ESCm.ehComentario(textoOriginal)
  // convite de avaliação: o cliente diz que recebeu o pedido/foi atendido ou quer avaliar → avaliação interna (e Google, se a empresa ativou)
  /* situação de avaliação ("recebi meu pedido, quero avaliar") vem antes do pedido de esclarecimento: "recebi" ali não é valor recebido */
  const convAval = !limitMsg && !fin && !appt && !quick && !modCard && !calcAuto && !admEmp && !cx ? await (await import('../lib/reputacao.js')).conviteNoChat(u.id, textoOriginal).catch(() => null) : null
  const esclarecer = !limitMsg && !fin && !appt && !quick && !modCard && !calcAuto && !admEmp && !cx && !convAval && !pesqExp ? ESCm.pedidoDeEsclarecimento(textoOriginal, hist as any) : null
  if (!limitMsg && !fin && !appt && !quick && !modCard && !calcAuto && !admEmp && !comentario && !esclarecer && !convAval && !pesqExp && !pesqAtual && !operacional) {
    learned = await findLearnedAnswer(u, RES.seguimento ? RES.pergunta : text).catch(() => null)
    if (learned) usos.push({ itemId: learned.id, version: (learned as any).version || 1, role: 'consulta', action: 'respondeu', effect: 'Reutilizou uma resposta aprovada do Cérebro (sem IA)' })
    // conhecimento próprio (cadastrado ou aprendido) responde antes de qualquer IA
    if (!learned) { const bc = await getConfig<any>('brain', {}); if (bc.cerebroPrimeiro !== false) { const K = await import('../ai/knowledge.js'); if (!K.ehConsultaDePedidoReal(text)) { const k = await K.answerKnowledge(text, u.id, bc.modoIA === 'sem_ia' ? 0.5 : 0.6).catch((e) => { console.error('[cérebro] busca falhou:', e?.message); return null }); if (k) { learned = { answer: k.resposta, id: k.ids[0] }; usos.push(...K.usoDeConsulta(k, 'chat')) } } } }
  }
  // memória do Cérebro: resposta guardada que não cita o nome perguntado é de outro assunto (ex.: "capital da França"
  // para "capital da Austrália") — não responde; a pergunta segue para a consulta e a pesquisa
  if (learned && !(await import('../ai/cerebro/relevancia.js')).citaNomes(RES.pergunta, learned.answer)) { learned = null; usos.splice(usosAntesDaMemoria) }
  T.mark('conhecimento')
  const fromAi = !limitMsg && !fin && !appt && !quick && !learned && !modCard && !esclarecer && !convAval
  // CÉREBRO CENTRAL: consulta obrigatória antes da IA (biblioteca → suficiência → pesquisa e aprendizado, se a pergunta for geral)
  const INT = await import('../ai/cerebro/integracao.js')
  if (fromAi) etapa('cerebro')
  // NÍVEL DE PROCESSAMENTO (ai/escopo.ts): simples / contextual / complexo / ação / pesquisa / multimodal — ajusta quanto esperar
  const NIV = (await import('../ai/escopo.js')).nivelDoPedido(textoOriginal, { temArquivo: !!(b as any)?.files?.length || !!(b as any)?.image, temHistorico: hist.some((m: any) => m.role === 'user'), calculo: !!conta || calcAuto, tipoPedido })
  const rastro = fromAi && !calcAuto ? await INT.recuperar(pesqExp || pesqAtual ? PRI.consulta : RES.pergunta, { canal: 'chat', userId: u.id, pesquisar: !interno, consulta: operacional || pesqExp || pesqAtual ? undefined : RES.consulta || undefined, assunto: RES.assunto || undefined, dominio: RES.dominio, nivel: pesqExp || pesqAtual ? 'pesquisa' : NIV.nivel, forcarPesquisa: pesqExp || pesqAtual, tempoReal: pesqAtual }).catch((e) => { console.error('[cérebro central] consulta:', e?.message); return INT.rastroDireto(text, 'chat', u.id, 'falha_consulta') }) : null
  // IMAGENS DA PESQUISA (ai/cerebro/imagens.ts): o orquestrador decide se a pergunta se beneficia de imagens (pessoa, lugar,
  // animal, objeto, obra, "mostre fotos de…"); a busca visual roda EM PARALELO com a resposta, pelos mesmos provedores do painel
  const IMGm = await import('../ai/cerebro/imagens.js'), tImg = Date.now()
  const decImg = (fromAi || learned) && !calcAuto && !admEmp && !limitMsg ? IMGm.avaliar(RES.pergunta || textoOriginal, { escopo: ESCm.escopoDoTurno(textoOriginal, tipoPedido, hist.some((m: any) => m.role === 'user')).tipo, assunto: rastro?.assunto, decisao: rastro?.decisao }) : null
  const imgP = decImg?.visual ? IMGm.buscar(decImg.entidade, RES.pergunta || textoOriginal, { max: 4 }).catch((e: any) => ({ imagens: [], tentativas: [{ motor: 'imagens', status: 'erro', motivo: String(e?.message || e).slice(0, 160) }], cache: false, ms: Date.now() - tImg })) : null
  let imgDiag: any = decImg ? { decisao: decImg.visual ? 'pesquisar' : 'nao_pesquisar', motivo: decImg.motivo, ...(decImg.visual ? { entidade: decImg.entidade, tipo: decImg.tipo } : {}) } : null
  if (fromAi) T.mark('cerebro_central')
  let cerebroSemIA = false, falhaIA = '', iaFalhou: any = null // tentativas reais de cada IA quando a chamada falha (tempo esgotado, limite, chave, indisponível)
  void (async () => { try { const st = await getConfig<any>('brain_stats', { semIA: 0, comIA: 0 }); st[fromAi ? 'comIA' : 'semIA'] = (Number(st[fromAi ? 'comIA' : 'semIA']) || 0) + 1; await setConfig('brain_stats', st) } catch { /* estatística opcional */ } })()
  // FATO ESPECÍFICO (ai/cerebro/fatos.ts): "quantos anos tem…", "onde nasceu…", "qual a profissão…", "como ficou conhecido…"
  // com conhecimento recuperado sobre a entidade: responde só com o fato que responde (idade calculada), sem IA e sem o
  // mesmo resumo para todas as perguntas
  const fatoResp = rastro && !calcAuto && !limitMsg && !fin && !appt && !modCard && !quick && !learned && !esclarecer && !convAval && !rastro.sentidos?.length ? await INT.respostaPorFatos(rastro).catch((e) => { console.error('[cérebro central] fatos:', e?.message); return null }) : null
  if (fatoResp) cerebroSemIA = true
  const reply = limitMsg ? { content: limitMsg, cards: [] as any[] }
    : fin ? fin
    : appt ? appt
    : modCard ? modCard
    : quick ? { content: quick, cards: [] as any[] }
    : learned ? { content: learned.answer, cards: [] as any[] }
    : esclarecer ? { content: esclarecer, cards: [] as any[] }
    : convAval ? { content: convAval.content, cards: [] as any[] }
    : rastro?.sentidos?.length ? { content: INT.perguntaSentidos(rastro), cards: [] as any[] } // nome com mais de um sentido e a conversa não diz qual: pergunta
    : fatoResp ? { content: fatoResp, cards: [] as any[] }
    : await runAssistant(u, hist, text, live, calcAuto ? '' : [await (await import('../ai/convctx.js')).ctxParaIA(convId, u, !!RES.seguimento || isAgendaQuery(text)).catch(() => ''), CMP.notaParaIA(RES), (pesqExp || pesqAtual) && PBq.estadoTurno()?.global ? `[Como responder] Responda diretamente ao que a pessoa perguntou, com o seu conhecimento, o contexto da conversa e o Cérebro Central. Não diga que pesquisou nem que não pode pesquisar e não mencione internet, buscas, bloqueios ou configurações. Se for algo que muda com o tempo (preços, cotações, notícias), dê a melhor informação que você tem e diga apenas que pode ter mudado recentemente.` : '', naoExec ? `[Decisão do turno] Esta mensagem é uma ${PRI.modo === 'sugestao' ? 'SUGESTÃO/opinião' : 'CONSULTA'} sobre os dados do próprio usuário: responda com os dados reais (ferramentas de leitura), sem criar, alterar, cancelar ou registrar nada e sem pesquisar na internet. Se recomendar uma ação, pergunte se a pessoa quer que você a faça.` : ''].filter(Boolean).join('\n'), usos, undefined, convId, rastro, { idioma: idi, tipo: tipoPedido, autocontido: calcAuto, somenteLeitura: naoExec }).catch(async (e) => { await refundQuota(u, 'chat').catch(() => {}); falhaIA = String(e?.message || e).slice(0, 200)
      // provedores de IA indisponíveis: o Cérebro Central continua respondendo com o que já sabe (trecho + fonte)
      // ações de estrutura clara (empresa, tarefa, compras) seguem funcionando pelo resolvedor local, com o resultado real da ferramenta
      { const RL = await import('../ai/resolver-local.js'); const rl = (admEmp ? await RL.resolverEmpresa(u, textoOriginal || text, { semIA: true }).catch(() => null) : null) || (!calcAuto && !soExplicar ? await RL.resolverPessoal(u, text, convId).catch(() => null) : null); if (rl) { cerebroSemIA = true; return { content: rl.content, cards: (rl as any).cards || [], acoes: 1 } as any } }
      const semIA = INT.respostaSemIA(rastro); if (semIA) { cerebroSemIA = true; return { content: semIA, cards: [] as any[] } }
      // a pesquisa que seguiu em segundo plano pode ter terminado enquanto a IA falhava: o Cérebro relê a biblioteca (sem pesquisar
      // de novo) e responde com o que acabou de aprender, em vez de entregar só o aviso de falha
      if (rastro?.pesquisou && /pesquisa_em_andamento/.test(String(rastro.resultado))) { const r2 = await INT.recuperar(RES.pergunta, { canal: 'chat', userId: u.id, pesquisar: false, consulta: RES.consulta || undefined, assunto: RES.assunto || undefined, dominio: RES.dominio }).catch(() => null); const s2 = INT.respostaSemIA(r2); if (s2 && r2) { cerebroSemIA = true; rastro.itens = r2.itens; rastro.resultado = 'aprendido_em_segundo_plano'; return { content: s2, cards: [] as any[] } } }
      { const at = (e?.attempts || e?.cause?.attempts || []) as any[]; iaFalhou = { codigo: e?.code || e?.cause?.code || 'erro', motivo: String(e?.cause?.message || e?.message || '').slice(0, 160), tentativas: at.map((a) => ({ ia: a.nome, ok: a.ok, tipo: a.kind, ms: a.ms })) } }
      if (e?.code === 'chat_deadline') { const K = await import('../ai/knowledge.js'); const k = calcAuto ? null : await K.answerKnowledge(text, u.id, 0.6).catch(() => null); if (k) usos.push(...K.usoDeConsulta(k, 'chat')); const EG = await import('../ai/engine.js')
        // pesquisa em andamento (segue em segundo plano e fica guardada): avisa isso, em vez de "falhou" — a próxima tentativa aproveita o que já foi lido
        const emAndamento = !k && rastro?.pesquisou && /pesquisa_em_andamento/.test(String(rastro.resultado))
        return { content: k ? k.resposta : emAndamento ? 'Ainda estou terminando a pesquisa sobre isso. O que já encontrei fica guardado: tente novamente daqui a alguns minutos que a resposta sai mais rápido.' : EG.MSG_NAO_CONCLUIU, cards: [] as any[] } } // a resposta não pôde ser concluída, mas a busca de imagens (já verificadas) trouxe resultado: preserva o que foi encontrado,
      // com a mensagem amigável — o texto deixa claro que não é a resposta completa
      if (imgP && (await getConfig<any>('brain', {})).modoIA !== 'sem_ia') { const ri: any = await Promise.race([imgP, new Promise((ok) => setTimeout(() => ok(null), 1500))]); if (ri?.imagens?.length) return { content: (await import('../ai/engine.js')).MSG_NAO_CONCLUIU, cards: [] as any[] } }
      if ((await getConfig<any>('brain', {})).modoIA === 'sem_ia') return { content: 'Ainda não aprendi a responder isso sozinho. Estou no modo sem IAs externas: posso registrar gastos, compromissos, tarefas e lembretes, consultar sua agenda e finanças, abrir módulos e responder o que já está no meu Cérebro.', cards: [] as any[] }; throw e })
  T.mark(fromAi ? 'ia' : 'montar_resposta')
  etapa('preparando')
  { const tp = (reply as any)?.cog?.tempos; if (tp) for (const [k, v] of Object.entries(tp)) T.etapas['ia.' + k] = Math.round(Number(v)) } // subetapas da IA: preparo, modelo, ferramentas, conclusão
  // aprende a resposta da IA (perguntas gerais, sem efeitos colaterais); entra como PENDENTE e sem o texto fixo das regras
  if (fromAi && !cerebroSemIA && reply?.content) { const sx = INT.sintetizar(reply.content, rastro); if (sx.ajustou && rastro) { reply.content = sx.texto; rastro.sintetizado = true } } // síntese inteligente (proteção contra despejo)
  // FONTES: o corpo da resposta fica sem URLs, domínios, "Fonte:" ou "Segundo <site>"; as fontes que SUSTENTAM a resposta
  // (conhecimento realmente usado ou a pesquisa da IA) vão num marcador que o app mostra como ícones junto do horário
  // GRAFIA APROXIMADA (1 letra: "Felipe Tito" × "Felipe Titto"): a resposta diz qual entidade foi considerada — sempre, sem depender da IA
  if (fromAi && rastro && reply?.content && !fatoResp && !/^Considerei /.test(reply.content) && !FALHA_IA.test(reply.content.trim())) { const av = INT.avisoGrafia(rastro); if (av) reply.content = av + reply.content }
  if ((fromAi || learned) && reply?.content) {
    const REL = await import('../ai/cerebro/relevancia.js')
    const lf = REL.limparFontes(reply.content, rastro ? rastro.itens.flatMap((x) => x.fontes) : [])
    const texto = lf.texto || reply.content.replace(/⟦src[^⟧]*⟧/g, '').trim()
    const fontes = [...lf.fontes, ...INT.fontesDaResposta(texto, rastro, cerebroSemIA ? 'cerebro_sem_ia' : 'ia')]
    const mk = REL.marcador(fontes)
    if (lf.removeu || mk) reply.content = texto + (mk ? ' ' + mk : '')
  }
  if (fromAi && !cerebroSemIA && !calcAuto && !(reply as any)?.parcial && !(Number((reply as any)?.acoes) > 0) && !/Confirma\?\s*$/.test(String(reply?.content || '')) && !admEmp && reply?.content && !reply.cards?.length && idi.lang === 'pt' && tipoPedido !== 'explicacao') { // conta com números próprios e resposta interrompida nunca viram "conhecimento" // o Cérebro aprende em português; explicações saem do catálogo vivo
    saveLearnedAnswer(u, text, reply.content).catch(() => {})
  }
  // marcador de imagens só deste servidor (o da IA/página/usuário é descartado); a imagem entra DEPOIS do aprendizado (não vira texto aprendido)
  if ((fromAi || learned) && reply?.content && /⟦img:/.test(reply.content)) reply.content = IMGm.semMarcadores(reply.content)
  if (imgP && reply?.content && !limitMsg) {
    const espera = Math.max(150, Math.min(1200, 4500 - (Date.now() - tImg))) // a busca de imagens corre junto com a IA; com o texto pronto, espera no máximo 1,2 s a mais (imagem nunca segura a resposta)
    const r: any = await Promise.race([imgP, new Promise((ok) => setTimeout(() => ok(null), espera))])
    if (!r) imgDiag = { ...imgDiag, resultado: 'tempo_esgotado', ms: Date.now() - tImg }
    else {
      imgDiag = { ...imgDiag, resultado: r.imagens.length ? 'mostrou' : 'sem_imagem_relevante', n: r.imagens.length, cache: r.cache, ms: r.ms, motores: r.tentativas.map((x: any) => `${x.motor}:${x.status}${x.n !== undefined ? '(' + x.n + ')' : ''}`) }
      if (r.imagens.length) { const mk = await IMGm.marcador(r.imagens, decImg!.entidade); if (mk) reply.content = reply.content.trim() + (FALHA_IA.test(reply.content.trim()) ? '\n\nEnquanto isso, estas são as imagens que já encontrei sobre o assunto:' : '') + ' ' + mk } // resultado parcial preservado (imagem já verificada), sem apresentá-lo como resposta completa
    }
  }
  if (!limitMsg && reply?.content) void (await import('../ai/adaptive.js')).observarUso(u, convId, reply.content).catch(() => {}) // padrões de uso (preferências inferidas)
  // DESCOBERTA depois da ação: a ação deste turno já foi feita; no máximo uma pergunta curta que melhora as próximas
  if (!limitMsg && reply?.content && !viaModo && !calcAuto) { const pq = await (await import('../ai/descoberta.js')).depois(u, convId, reply.content, inicioTurno).catch(() => ''); if (pq) reply.content = reply.content.replace(/\s+$/, '') + '\n\n' + pq }
  if (rodape.length && !limitMsg && reply?.content) reply.content += '\n\n' + [...new Set(rodape)].join('\n') // regra executável "anexar"
  // cartões de compromisso, gasto e receita viram cartões premium (dados lidos do módulo real pelo id)
  if (Array.isArray(reply.cards)) { const keep: any[] = []; for (const c of reply.cards) { if (c && c.id && c.kind === 'appointment') { if (!/⟦appt:/.test(reply.content)) reply.content += ` ⟦appt:${c.id}⟧` } else if (c && c.id && (c.kind === 'expense' || c.kind === 'income')) { reply.content += ` ⟦fin:${c.id}⟧` } else keep.push(c) } reply.cards = keep }
  if (idi.lang !== 'pt' && !jaNoIdioma && !(fromAi && !cerebroSemIA) && reply?.content) { const tr = await IDI.traduzir(reply.content, idi.lang).catch(() => null); if (tr) reply.content = tr } // motores internos escrevem em português
  if (prefixoIdioma && reply?.content) reply.content = prefixoIdioma + '\n\n' + reply.content
  if (prefixoDescoberta && reply?.content) reply.content = prefixoDescoberta + ' ' + reply.content
  if (!limitMsg && !viaModo && !viaGuia && !viaIdioma && !/⟦(emp|loc|mkt)/.test(reply.content)) { const ad = await maybeAd(u).catch(() => null); if (ad) reply.content += ` ⟦ad:${ad}⟧` } // gera antes de gravar: se a IA falhar, nada fica pela metade
  const via = limitMsg ? 'limite' : viaCob ? 'cobranca' : viaIdioma ? 'idioma' : viaGuia ? 'guia' : viaModo ? 'modo' : viaRegra ? 'regra' : conta ? 'calculo' : cx ? 'memoria_conversa' : fin ? 'financeiro' : appt ? 'agenda' : modCard ? 'motor_interno' : quick ? 'atalho' : learned ? 'cerebro' : esclarecer ? 'esclarecimento' : convAval ? 'avaliacao' : fatoResp ? 'cerebro_fatos' : cerebroSemIA ? 'cerebro_sem_ia' : (reply as any)?.parcial ? 'ia_parcial' : 'ia'
  const um = await insertMsg(u, convId, 'user', textoDigitado, [], replyToId)
  const am = await insertMsg(u, convId, 'assistant', reply.content, reply.cards)
  if (!limitMsg) { const cg = (reply as any).cog; await COG.avaliarERegistrar(u, convId, Number(am.id), { idioma: idi.lang, texto: text, resposta: reply.content, analise: cg?.analise || anCog, exec: cg?.exec, hist, ferramentas: cg?.ferramentas ?? 0, caminho: via, flagsPrev: cg?.flags, ajustes: cg?.ajustes, especialistas: cg?.n2?.especialistas, n2: cg?.n2 }).catch((e) => console.error('[cognição] avaliação:', e?.message)) } // só notas e rótulos; o texto da conversa não é guardado
  if (!limitMsg) { const cg = (reply as any).cog, ex = cg?.exec; COLx.observar(u, convId, { texto: textoOriginal, ferramentasOk: ex ? [...(ex.escritas || []), ...(ex.leituras || [])] : [], falhas: ex?.falhas?.length || 0, tiposCriados: (await import('../ai/aprendizado-uso.js')).acoesDesde(u.id, inicioTurno).map((a: any) => a.type), correcao: anCog.tipo === 'correcao' }) } // camada coletiva: só modelo anônimo + intenção confirmada, gravado em lote fora da requisição
  await registrarUso(usos, { canal: 'chat', userId: u.id, conversationId: convId, messageId: Number(am.id) }) // quando e em qual resposta o conhecimento/regra foi usado
  if (!limitMsg) await INT.finalizar(rastro || rastroModo || INT.rastroDireto(text, 'chat', u.id, learned ? 'resposta_da_memoria' : 'acao_interna'), { resposta: reply.content, via, messageId: Number(am.id), conversationId: convId, falhas: falhaIA ? ['IA indisponível: ' + falhaIA] : [], memoria: learned ? [{ id: learned.id }] : metaModo?.conhecimento?.length ? metaModo.conhecimento.map((id: number) => ({ id })) : undefined, detalhe: (() => { const cg = (reply as any)?.cog, ex = cg?.exec; return { etapas: { ...T.etapas }, totalMs: Object.entries(T.etapas).filter(([k]) => !k.startsWith('ia.')).reduce((a, [, v]) => a + Number(v || 0), 0), tipo: tipoPedido, idioma: idi.lang, ferramentas: (cg?.n2?.ferramentas || []).slice(0, 12), acoes: ex ? { feitas: ex.escritas || [], verificacao: cg?.n2?.verificacao ?? null, pendentes: ex.pendentes || [], falhas: (ex.falhas || []).slice(0, 5), leituras: (ex.leituras || []).length } : null, especialistas: cg?.n2?.especialistas || [], sinais: (cg?.flags || []).slice(0, 10), multiagente: !!cg?.n2?.multiagente, consultas: CONS.n, req: reqId, nivel: NIV.nivel, nivelMotivo: NIV.motivo, ...(cg?.ia?.length ? { ia: cg.ia } : {}), ...(iaFalhou ? { iaFalhou, ...(iaFalhou.codigo === 'chat_deadline' ? { motivoTimeout: `prazo da IA no chat esgotado${iaFalhou.tentativas.length ? ': ' + iaFalhou.tentativas.map((t: any) => `${t.ia} ${t.ok ? 'ok' : t.tipo || 'falhou'} em ${t.ms} ms`).join('; ') : ' (nenhuma IA respondeu a tempo)'}` } : {}) } : {}), ...(rastro?.esperaPesquisaMs ? { esperaPesquisaMs: rastro.esperaPesquisaMs } : {}), ...(imgDiag ? { imagens: imgDiag } : {}), ...(cg?.contexto ? { contexto: cg.contexto } : {}), ...(cg?.n2?.sugestaoDiag ? { sugestao: cg.n2.sugestaoDiag } : {}), ...(cg?.n2 ? { memorias: { usadas: cg.n2.memorias ?? null, candidatas: cg.n2.memoria?.candidatos ?? null, escopo: cg.n2.memoria?.escopo || 'relevancia' } } : {}), ...(metaModo ? { modo: metaModo } : {}) } })() }).catch(() => null) // rastreamento real (painel do Cérebro Central)
  await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
  const byId = new Map<number, any>()
  if (replyToId) { const rt = await one('SELECT * FROM messages WHERE id = $1 AND user_id = $2', [replyToId, u.id]); if (rt) byId.set(replyToId, rt) }
  T.mark('gravacao_e_entrega')
  const med = T.finish(via, fromAi, text.length, CONS.n, reqId)
  // diagnóstico por turno: só identificadores, tempos e estados — nunca o texto, senhas, tokens, chaves ou dados pessoais
  console.log('[chat-turno] ' + JSON.stringify({ req: cleanJobId((ctx as any).req?.headers?.['x-chat-job']) || null, conv: convId.slice(0, 8), msgUsuario: Number(um.id), msgResposta: Number(am.id), via, ia: fromAi, autocontido: calcAuto, parcial: !!(reply as any)?.parcial, provedor: rastro?.provedor || null, cerebroMs: (med.etapas as any)?.cerebro_central ?? (med.etapas as any)?.cerebro ?? null, iaMs: (med.etapas as any)?.ia ?? null, totalMs: med.total, etapasMs: med.etapas, falhaIA: falhaIA ? falhaIA.slice(0, 120) : null }))
  if (CONS.sql) { const c = new Map<string, number>(); for (const x of CONS.sql) c.set(x, (c.get(x) || 0) + 1); console.log(`[consultas] ${CONS.n} via ${via}: ` + [...c].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${v}× ${k}`).join(' || ')) } // diagnóstico (DIAG_CONSULTAS=1)
  return { conversation: convOut({ ...conv, updated_at: nowIso() }), userMessage: msgOut(um, byId), assistantMessage: msgOut(am), usageAlert: null, ad: null }
}

/** Impede resposta duplicada: o mesmo pedido enquanto o primeiro ainda é processado (toque duplo, nova tentativa do
 *  aplicativo após demora) recebe a resposta do primeiro em vez de gerar outra mensagem e outros lançamentos. */
const inflight = new Map<string, { at: number; p: Promise<any> }>()
/* ---------- processamento persistente: cada envio vira um "pedido" com id; a geração continua no servidor
   mesmo se o app sair, minimizar ou perder a internet, e a resposta pode ser buscada depois pelo id ---------- */
interface Live { text: string; done: boolean; subs: Set<(ev: string, data: any) => void>; etapa?: { e: string; t: string } }
const lives = new Map<string, Live>()
const liveOf = (id: string) => { let l = lives.get(id); if (!l) { l = { text: '', done: false, subs: new Set() }; lives.set(id, l) } return l }
const emit = (id: string, ev: string, data: any) => { const l = lives.get(id); if (l) for (const f of l.subs) { try { f(ev, data) } catch { /* conexão fechada */ } } }
const jobRunning = new Map<string, Promise<any>>()
const cleanJobId = (v: any) => { const s = String(v || '').trim(); return /^[A-Za-z0-9_-]{8,80}$/.test(s) ? s : '' }

/* ---------- Ditado (microfone do chat): áudio → texto no campo de mensagem ----------
   O app grava, envia aqui só para TRANSCREVER e mostra o texto no campo para o usuário revisar/editar; ao tocar em enviar,
   o texto segue para o motor do chat como se tivesse sido digitado (o áudio não vai para o motor). O texto sai no idioma
   falado (sem forçar português) e o motor responde nesse idioma (idioma.ts). Nada é gravado: o áudio é descartado. */
// limite por pessoa: 40 ditados em 5 min. Ditado em trechos (o mesmo "sessao" manda uma frase por vez) conta UMA vez por sessão,
// com teto de 120 trechos por sessão e 400 requisições no total na janela
const DITADO_JANELA = 5 * 60000, DITADO_MAX = 40, DITADO_TRECHOS = 120, DITADO_TOTAL = 400, ditados = new Map<number, { t: number; s: string }[]>()
// parciais (texto provisório do trecho que a pessoa ainda está falando, ~1 por segundo): cota própria, nunca bloqueiam o ditado
const PARCIAIS_SESSAO = 400, PARCIAIS_TOTAL = 900, parciais = new Map<number, { t: number; s: string }[]>()
// frases que o Whisper costuma "ouvir" em gravações sem fala (legendas de vídeo): tratadas como silêncio
const FANTASMA = /^(legendas? (pela|por) comunidade amara\.org|obrigad[oa] por assistir!?|thanks? (you )?for watching!?|subt[ií]tulos? (realizados? )?por la comunidad de amara\.org|sous-titres? r[ée]alis[ée]s? par la communaut[ée] d'amara\.org|untertitel (im auftrag des zdf|der amara\.org-community)|sottotitoli (creati )?dalla comunit[aà] amara\.org|\[?(m[uú]sica|music|silence|sil[eê]ncio|aplausos|applause)\]?|\.+|…)$/i
/** WAV PCM 16 bits (o app converte a gravação antes de enviar): duração e pico, sem guardar nada. null = não é WAV PCM16. */
export function wavInfo(buf: Buffer): { ms: number; pico: number } | null {
  if (buf.length < 44 || buf.toString('ascii', 0, 4) !== 'RIFF' || buf.toString('ascii', 8, 12) !== 'WAVE') return null
  let pos = 12, canais = 0, taxa = 0, bits = 0, fmt = 0
  while (pos + 8 <= buf.length) {
    const id = buf.toString('ascii', pos, pos + 4), tam = buf.readUInt32LE(pos + 4), ini = pos + 8
    if (id === 'fmt ' && ini + 16 <= buf.length) { fmt = buf.readUInt16LE(ini); canais = buf.readUInt16LE(ini + 2); taxa = buf.readUInt32LE(ini + 4); bits = buf.readUInt16LE(ini + 14) }
    if (id === 'data') {
      if (fmt !== 1 || bits !== 16 || !canais || !taxa) return null
      const fim = Math.min(buf.length, ini + tam), n = Math.floor((fim - ini) / 2), passo = Math.max(1, Math.floor(n / 200000))
      let pico = 0
      for (let i = 0; i < n; i += passo) { const v = Math.abs(buf.readInt16LE(ini + i * 2)); if (v > pico) pico = v }
      return { ms: Math.round((n / canais / taxa) * 1000), pico: pico / 32768 }
    }
    pos = ini + tam + (tam % 2)
  }
  return null
}
/** Registro técnico do ditado no log do servidor: formato, tamanho, duração, resultado e tempo. Nunca o áudio nem o texto. */
function logDitado(dados: Record<string, string | number | boolean | undefined | null>) {
  console.log('[ditado] ' + Object.entries(dados).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => `${k}=${String(v).replace(/\s+/g, '_').slice(0, 120)}`).join(' '))
}
export async function transcribePost(ctx: Ctx) {
  const u = requireUser(ctx)
  const t0 = Date.now(), f = ((ctx as any).files as UpFile[] || []).find((x) => x.field === 'audio')
  const meta = { user: u.id, mime: f?.mime || '-', arquivo: f?.filename || '-', bytes: f?.data?.length || 0, gravado_ms: Number((ctx.body as any)?.duracaoMs) || undefined, motor: str((ctx.body as any)?.motor || (ctx.body as any)?.via || '', 20) || undefined }
  const recusa = (status: number, msg: string, code: string, extra: Record<string, any> = {}): never => { logDitado({ ...meta, ...extra, resultado: code, status, ms: Date.now() - t0 }); fail(status, msg, code) }
  try { await requireModule('voz') } catch (e: any) { logDitado({ ...meta, resultado: 'modulo_voz_desligado', status: e?.status }); throw e }
  // PARCIAL: só texto provisório; silêncio, trecho curto, cota ou falha devolvem texto vazio (a versão final do trecho é que vale)
  if (String((ctx.body as any)?.parcial || '') === '1') {
    const vazio = { ok: true, text: '', parcial: true }
    if (!f || !f.data?.length || f.data.length < 800) return vazio
    const mimeP = (/^application\/octet-stream/.test(f.mime) || !f.mime ? 'audio/webm' : f.mime).toLowerCase(); if (!/^audio\//.test(mimeP)) return vazio
    const wp = /wav/.test(mimeP) ? wavInfo(f.data) : null; if (wp && (wp.ms < 400 || wp.pico < 0.002)) return vazio
    const agora = Date.now(), ses = str((ctx.body as any)?.sessao, 64).replace(/[^\w-]/g, '') || 'p', l = (parciais.get(u.id) || []).filter((x) => agora - x.t < DITADO_JANELA)
    if (l.length >= PARCIAIS_TOTAL || l.filter((x) => x.s === ses).length >= PARCIAIS_SESSAO) return { ...vazio, limitado: true }
    l.push({ t: agora, s: ses }); parciais.set(u.id, l)
    const idiomaP = /^[a-z]{2}$/.test(String((ctx.body as any)?.idioma || '')) ? String((ctx.body as any).idioma) : undefined
    let tp = ''; try { tp = String(await transcribeAudio(f.data, mimeP, idiomaP) || '').replace(/\s+/g, ' ').trim().slice(0, 4000) } catch { return vazio }
    return tp && !FANTASMA.test(tp) ? { ok: true, text: tp, parcial: true } : vazio
  }
  if (!f || !f.data?.length) recusa(400, 'Nenhum áudio recebido. Toque no microfone e fale de novo.', 'audio_missing')
  const mime = (/^application\/octet-stream/.test(f!.mime) || !f!.mime ? 'audio/webm' : f!.mime).toLowerCase()
  if (!/^(audio\/|video\/(webm|mp4))/.test(mime)) recusa(415, 'Formato de áudio não suportado. Grave de novo pelo microfone do chat.', 'unsupported_file')
  if (f!.data.length < 800) recusa(422, 'Gravação muito curta. Toque no microfone e fale de novo.', 'audio_empty')
  // WAV (formato enviado pelo app): silêncio digital total = microfone mudo ou tomado por outro app; não vale gastar transcrição
  const wi = /wav/.test(mime) ? wavInfo(f!.data) : null
  if (wi && wi.ms < 300 && (ctx.body as any)?.via !== 'voice') recusa(422, 'Gravação muito curta. Toque no microfone e fale de novo.', 'audio_empty', { duracao_ms: wi.ms })
  if (wi && wi.pico < 0.002) recusa(422, 'O microfone não captou som. Confira se ele não está mudo ou em uso por outro app e tente de novo.', 'audio_silent', { duracao_ms: wi.ms, pico: wi.pico.toFixed(4) })
  const agora = Date.now(), lista = (ditados.get(u.id) || []).filter((x) => agora - x.t < DITADO_JANELA)
  const sessao = str((ctx.body as any)?.sessao, 64).replace(/[^\w-]/g, ''), chave = sessao || 'r' + agora + Math.random()
  const sessoes = new Set(lista.map((x) => x.s)), daSessao = sessao ? lista.filter((x) => x.s === sessao).length : 0
  if ((!sessoes.has(chave) && sessoes.size >= DITADO_MAX) || daSessao >= DITADO_TRECHOS || lista.length >= DITADO_TOTAL) recusa(429, 'Muitas gravações em pouco tempo. Aguarde um instante ou digite sua mensagem.', 'rate_limited')
  lista.push({ t: agora, s: chave }); ditados.set(u.id, lista)
  // idioma já detectado no 1º trecho da mesma fala: os seguintes vão com ele (trecho curto sem idioma às vezes sai em outra língua)
  const idiomaPedido = /^[a-z]{2}$/.test(String((ctx.body as any)?.idioma || '')) ? String((ctx.body as any).idioma) : undefined
  let texto = ''
  try { texto = String(await transcribeAudio(f!.data, mime, idiomaPedido) || '') }
  catch (e: any) { console.error('[ditado] transcrição falhou:', e?.message || e); recusa(503, 'Não consegui transcrever o áudio agora. Tente de novo ou digite sua mensagem.', 'transcribe_failed', { duracao_ms: wi?.ms, erro: e?.code || e?.name || 'erro' }) }
  texto = texto.replace(/\s+/g, ' ').trim().slice(0, 4000)
  if (!texto || FANTASMA.test(texto)) recusa(422, 'Não reconheci nenhuma fala. Tente falar mais perto do microfone.', 'audio_empty', { duracao_ms: wi?.ms, fantasma: !!texto })
  const { detectar } = await import('../ai/idioma.js')
  const idioma = detectar(texto).lang
  logDitado({ ...meta, duracao_ms: wi?.ms, resultado: 'ok', caracteres: texto.length, idioma, ms: Date.now() - t0 })
  return { ok: true, text: texto, idioma }
}
/* Diagnóstico do microfone enviado pelo app quando algo falha no aparelho (permissão, gravação vazia, rede, tempo esgotado…).
   Só campos técnicos, curtos e conhecidos; nunca áudio nem texto falado. Vai para o log do servidor (nada é gravado no banco). */
const DIAG_CAMPOS = ['evento', 'motor', 'fase', 'erro', 'status', 'code', 'mime', 'bytes', 'ms', 'pico', 'plataforma', 'navegador', 'instalado', 'seguro', 'permissao']
const diagJanela = new Map<string, number[]>()
export async function transcribeDiagPost(ctx: Ctx) {
  const chave = ctx.user ? 'u' + ctx.user.id : 'ip' + ctx.ip, agora = Date.now()
  const lista = (diagJanela.get(chave) || []).filter((t) => agora - t < 60000)
  if (lista.length >= 30) return { ok: true, ignorado: true } // no máximo 30 registros por minuto por usuário/IP
  lista.push(agora); diagJanela.set(chave, lista)
  if (diagJanela.size > 5000) for (const [k, v] of diagJanela) if (!v.some((t) => agora - t < 60000)) diagJanela.delete(k)
  const b = (ctx.body && typeof ctx.body === 'object' ? ctx.body : {}) as Record<string, any>
  const linha = DIAG_CAMPOS.filter((k) => b[k] !== undefined && b[k] !== null && b[k] !== '').map((k) => `${k}=${String(b[k]).replace(/[^\w.:/@+-]+/g, '_').slice(0, k === 'navegador' ? 60 : 40)}`)
  console.log(`[ditado:cliente] user=${ctx.user?.id ?? '-'} ` + linha.join(' '))
  return { ok: true }
}

/** Pedido guardado executado fora de uma requisição (Tentar de novo, lib/tarefas-chat.ts). */
export async function executarChat(ctx: Ctx) { return chatPostInner(ctx) }
/** O mesmo id de envio só pode repetir o MESMO pedido (mesma conversa e mesmo texto). */
function mesmoPedido(ex: any, b: any): boolean {
  try { const pj = JSON.parse(String(ex.payload || '{}')); return String(pj.text || '') === String(b.text || '').slice(0, 8000) && String(pj.conversationId || '') === String(b.conversationId || '') } catch { return true }
}
/** Uma mensagem por vez em cada conversa, na ordem de chegada: o histórico de cada turno inclui a resposta do anterior e as
 *  respostas nunca se misturam ou se gravam fora de ordem. Outras conversas e outros usuários seguem em paralelo. */
const filaConv = new Map<string, Promise<void>>()
async function travarConversa(userId: number, convId: unknown, aviso: () => void): Promise<() => void> {
  if (!convId) return () => {}
  const k = userId + '|' + String(convId), anterior = filaConv.get(k)
  let soltar!: () => void
  const minha = new Promise<void>((r) => { soltar = r }), cadeia = (anterior || Promise.resolve()).then(() => minha)
  filaConv.set(k, cadeia)
  if (anterior) { const t = setTimeout(aviso, 400); await Promise.race([anterior, new Promise<void>((r) => setTimeout(r, 150_000).unref?.())]); clearTimeout(t) }
  return () => { soltar(); if (filaConv.get(k) === cadeia) filaConv.delete(k) }
}
export async function chatPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const files: UpFile[] = (ctx as any).files || []
  const jobId0 = cleanJobId(ctx.req.headers['x-chat-job'] || b.jobId)
  if (jobId0) {
    const ex = await one('SELECT * FROM chat_jobs WHERE id = $1', [jobId0])
    if (ex && Number(ex.user_id) !== u.id) fail(409, 'Pedido inválido.', 'invalid')
    if (ex && !mesmoPedido(ex, b)) fail(409, 'Este identificador de envio já pertence a outra mensagem. Envie de novo.', 'job_conflict') // nunca devolve a resposta de outra pergunta
    if (ex && ex.status === 'done') return JSON.parse(ex.result) // repetição do mesmo envio: devolve a mesma resposta, sem gerar outra
    if (ex && ex.status === 'error') fail(Number(ex.error_status) || 502, ex.error || 'Não consegui responder agora.', ex.error_code || 'ai_error')
    const running = jobRunning.get(jobId0)
    if (running) return running
    if (ex && ['queued', 'pending'].includes(String(ex.status))) fail(409, 'Este pedido já está sendo processado. A resposta aparece na conversa quando ficar pronta.', 'em_andamento')
  }
  const key = [u.id, b.conversationId || '', b.resendOf || '', b.forwardOf || '', b.photos?.batchId || '', hashOf(String(b.text || '')), files.map((f) => f.field + hashOf(f.data)).join(',')].join('|')
  const now = Date.now(), ex = inflight.get(key)
  if (ex && now - ex.at < 120_000) return ex.p
  for (const [k, v] of inflight) if (now - v.at > 120_000) inflight.delete(k)
  // TAREFA PERSISTENTE (lib/tarefas-chat.ts): todo envio vira tarefa ligada ao usuário e à conversa — aguardando → processando
  // → concluída/falhou —, com o pedido guardado para tentar de novo; a fila limita o processamento simultâneo
  const jobId = jobId0 || ('s' + Date.now().toString(36) + randomBytes(6).toString('hex'))
  const TC = await import('../lib/tarefas-chat.js')
  const temTarefa = await TC.registrar(jobId, u.id, b, files.length > 0).then(() => true, (e) => { console.error('[tarefas] registrar:', e?.message); return false })
  // saiu da tela antes da resposta (fechou o app, perdeu a conexão): a tarefa continua e o usuário é avisado ao terminar
  const res0: any = (ctx as any).res
  if (temTarefa && res0?.on) res0.on('close', () => { if (!res0.writableFinished) void TC.marcarSegundoPlano(jobId, u.id, true).catch(() => {}) })
  const lv = jobId0 ? liveOf(jobId0) : null
  const live = lv ? { onDelta: (d: string) => { if (d && !lv.text.trim() && d.trim()) etapa('digitando'); lv.text += d; emit(jobId0, 'delta', d) }, onReset: () => { lv.text = ''; emit(jobId0, 'reset', '') } } : undefined
  // a geração não depende da conexão: se o app sair, ela termina e fica salva
  const p = (async () => {
    // ETAPAS REAIS: cada mudança vai para o canal do envio (SSE "etapa") e fica consultável pela situação/lista de tarefas
    const publicar = (x: { e: string; t: string }) => { if (lv) { lv.etapa = { e: x.e, t: x.t }; emit(jobId0, 'etapa', { e: x.e, t: x.t }) } }
    // fila: só aparece se a espera for real (não pisca "Na fila…" quando a vez é imediata)
    let naFila = true; const tFila = setTimeout(() => { if (naFila) publicar({ e: 'fila', t: 'Na fila…' }) }, 400)
    const soltar = await travarConversa(u.id, b.conversationId, () => publicar({ e: 'fila', t: 'Aguardando a mensagem anterior…' }))
    try { await TC.entrar(u.id) } catch (e) { soltar(); throw e }
    naFila = false; clearTimeout(tFila)
    let parar: (() => void) | null = null
    try {
      if (temTarefa) parar = await TC.iniciar(jobId)
      const res = await comEtapas(jobId, publicar, () => chatPostInner(ctx, live))
      if (temTarefa) await TC.concluir(jobId, res).catch((e) => console.error('[tarefas] concluir:', e?.message))
      if (lv) { lv.done = true; emit(jobId0, 'done', '') }
      return res
    } catch (e: any) {
      if (temTarefa) await TC.falhar(jobId, e).catch((x) => console.error('[tarefas] falhar:', x?.message))
      if (lv) { lv.done = true; emit(jobId0, 'error', e?.message || '') }
      throw e
    } finally { parar?.(); TC.sair(u.id); soltar() }
  })()
  p.catch(() => {})
  inflight.set(key, { at: now, p })
  jobRunning.set(jobId, p)
  const done = () => { if (inflight.get(key)?.p === p) inflight.delete(key); jobRunning.delete(jobId); if (jobId0) setTimeout(() => lives.delete(jobId0), 60_000) }
  p.then(done, done)
  return p
}
/** Situação de um envio: o app usa ao voltar para a tela ou quando a conexão caiu no meio. */
export async function chatJobGet(ctx: Ctx) {
  const u = requireUser(ctx), id = cleanJobId(ctx.params.id)
  const r = id ? await one('SELECT * FROM chat_jobs WHERE id = $1 AND user_id = $2', [id, u.id]) : null
  if (!r) return { status: 'unknown' }
  if (r.status === 'done') return { status: 'done', estado: 'concluida', result: JSON.parse(r.result) }
  if (r.status === 'error') return { status: 'error', error: r.error, code: r.error_code, httpStatus: Number(r.error_status) || 502 }
  const et = etapaAtual(id) || lives.get(id)?.etapa || null
  return { status: 'pending', estado: r.status === 'queued' ? 'aguardando' : 'processando', partial: lives.get(id)?.text || '', etapa: r.status === 'queued' ? { e: 'fila', t: 'Na fila…' } : et ? { e: et.e, t: et.t } : null }
}
/** Texto chegando em tempo real (Server-Sent Events). */
export async function chatJobStream(ctx: Ctx) {
  const u = requireUser(ctx), id = cleanJobId(ctx.params.id)
  if (!id) fail(400, 'Pedido inválido.', 'invalid')
  const res = ctx.res
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' })
  const send = (ev: string, data: any) => res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`)
  const r = await one('SELECT status, user_id FROM chat_jobs WHERE id = $1', [id])
  if (r && Number(r.user_id) !== u.id) { send('error', 'inválido'); res.end(); return { _handled: true } }
  if (r && !['pending', 'queued'].includes(String(r.status))) { send(r.status === 'done' ? 'done' : 'error', ''); res.end(); return { _handled: true } }
  const lv = liveOf(id)
  if (lv.etapa) send('etapa', lv.etapa)
  if (lv.text) send('delta', lv.text)
  if (lv.done) { send('done', ''); res.end(); return { _handled: true } }
  const sub = (ev: string, data: any) => { send(ev, data); if (ev === 'done' || ev === 'error') { lv.subs.delete(sub); res.end() } }
  lv.subs.add(sub)
  const ping = setInterval(() => res.write(': ping\n\n'), 15_000)
  const stop = setTimeout(() => { lv.subs.delete(sub); res.end() }, 180_000)
  ctx.req.on('close', () => { clearInterval(ping); clearTimeout(stop); lv.subs.delete(sub) })
  return { _handled: true }
}

export async function chatGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const id = ctx.query.get('c') || ''
  const conv = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [id, u.id])
  if (!conv) return { conversation: null, messages: [] }
  const rows = await q('SELECT * FROM messages WHERE conversation_id = $1 ORDER BY id', [id])
  const byId = new Map(rows.map((r) => [Number(r.id), r]))
  return { conversation: convOut(conv), messages: rows.map((m) => msgOut(m, byId)) }
}
export async function chatDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE user_id = $1', [u.id])
  return { ok: true }
}

export async function conversationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const term = str(ctx.query.get('q'), 100)
  const rows = term
    ? await q(`SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id = c.id
               WHERE c.user_id = $1 AND (c.title ILIKE $2 OR m.content ILIKE $2) ORDER BY c.updated_at DESC LIMIT 100`, [u.id, `%${term}%`])
    : await q('SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 200', [u.id])
  return { conversations: rows.map(convOut) }
}
export async function conversationPatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const c = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  if (!c) fail(404, 'Conversa não encontrada.', 'not_found')
  const b = ctx.body || {}
  const title = b.title !== undefined ? str(b.title, 120) || c!.title : c!.title
  const pinned = typeof b.pinned === 'boolean' ? b.pinned : B(c!.pinned)
  await q('UPDATE conversations SET title = $1, pinned = $2 WHERE id = $3', [title, pinned, c!.id])
  return { ok: true, conversation: convOut({ ...c, title, pinned }) }
}
export async function conversationDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  return { ok: true }
}

/* ---------- várias fotos: o app envia primeiro para /api/images e depois chama o chat com o lote ---------- */
const batches = new Map<string, { userId: number; at: number; files: { position: number; mime: string; data: Buffer }[] }>()
export function takeBatch(id: string, userId: number) { const b = batches.get(id); batches.delete(id); return b && b.userId === userId && Date.now() - b.at < 15 * 60_000 ? b.files.sort((x, y) => x.position - y.position) : [] }
export async function imagesPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('imagens')
  const id = str(ctx.body?.batchId, 64); if (!id) fail(400, 'Lote inválido.', 'invalid')
  const files: UpFile[] = ((ctx as any).files || []).filter((f: UpFile) => f.field === 'image')
  const pos = String(ctx.body?.position || '').split(',')
  const b = batches.get(id) || { userId: u.id, at: Date.now(), files: [] }
  if (b.userId !== u.id) fail(403, 'Lote inválido.', 'forbidden')
  for (const [i, f] of files.entries()) b.files.push({ position: Number(pos[i] || b.files.length + 1) || b.files.length + 1, mime: f.mime, data: f.data })
  b.files = b.files.slice(0, 10); batches.set(id, b)
  for (const [k, v] of batches) if (Date.now() - v.at > 15 * 60_000) batches.delete(k)
  return { results: files.map((_, i) => ({ ok: true, position: Number(pos[i] || i + 1) })) }
}

/* ---------- Tarefas em segundo plano (estados reais, saiu da tela, tentar de novo) ---------- */
export async function tarefasGet(ctx: Ctx) { const u = requireUser(ctx); const c = String(ctx.query.get('c') || '').slice(0, 64); return { tarefas: await (await import('../lib/tarefas-chat.js')).listar(u.id, c || undefined) } }
export async function tarefaSegundoPlanoPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); const est = await (await import('../lib/tarefas-chat.js')).marcarSegundoPlano(id, u.id, ctx.body?.ativo !== false); if (!est) fail(404, 'Tarefa não encontrada.', 'not_found'); return { ok: true, estado: est } }
export async function tarefaTentarPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); return { tarefa: await (await import('../lib/tarefas-chat.js')).tentarDeNovo(id, u.id) } }
export async function tarefaDescartarPost(ctx: Ctx) { const u = requireUser(ctx), id = cleanJobId(ctx.params.id); if (!id) fail(400, 'Pedido inválido.', 'invalid'); await (await import('../lib/tarefas-chat.js')).descartar(id, u.id); return { ok: true } }
