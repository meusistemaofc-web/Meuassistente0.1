// Proxy SEGURO das imagens de pesquisa mostradas no chat (ai/cerebro/imagens.ts).
// • Só abre endereços ASSINADOS por este servidor (HMAC): não é um proxy aberto — um link inventado ou editado recebe 403.
// • Cada salto revalidado contra SSRF (sem localhost, IP privado, link-local, credenciais na URL), sem cookies, tempo e
//   tamanho limitados, só JPEG/PNG/WebP/GIF/AVIF com assinatura binária conferida (nada de SVG/HTML disfarçado).
// • Resposta com nosniff, CSP "sandbox" e Cross-Origin-Resource-Policy: mesmo aberta direto no navegador, não executa nada.
// • Cache curto em memória (no servidor) e no navegador; as imagens não são gravadas no banco.
// • Exige sessão (as imagens aparecem nas conversas de quem está logado).
import type { Ctx } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as IMG from '../ai/cerebro/imagens.js'

export async function imagemVerGet(ctx: Ctx) {
  requireUser(ctx)
  const res = ctx.res, url = String(ctx.query.get('u') || ''), s = String(ctx.query.get('s') || '')
  const fim = (status: number, corpo?: Buffer, tipo = 'text/plain; charset=utf-8', idade = 0) => {
    res.writeHead(status, { 'Content-Type': tipo, 'Cache-Control': idade ? `private, max-age=${idade}, immutable` : 'no-store', 'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox", 'Cross-Origin-Resource-Policy': 'same-origin', 'Referrer-Policy': 'no-referrer', 'Content-Disposition': 'inline' })
    res.end(corpo || '')
  }
  if (!/^https?:\/\//i.test(url) || url.length > 2000 || !(await IMG.assinaturaValida(url, s))) return fim(403, Buffer.from('endereço de imagem não autorizado'))
  try { const im = await IMG.baixarImagem(url, { timeoutMs: 8000 }); return fim(200, im.dados, im.tipo, 86400) }
  catch (e: any) { return fim(502, Buffer.from('imagem indisponível')) }
}
