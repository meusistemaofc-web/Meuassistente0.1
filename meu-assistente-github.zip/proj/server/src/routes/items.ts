import { useQuota } from '../lib/usage.js'
// Registros pessoais (tarefas, compromissos, lembretes, compras, notas, lançamentos e contas).
// Contrato reconstruído de: agenda, financeiro, meu-dia, items.js e da fila offline do frontend
// (POST /api/items {action, type, id, data}; GET /api/agenda; GET /api/finance; GET /api/day).
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate, isTime, num } from '../lib/http.js'
import { one, q, J, nowIso, db, type Db } from '../db/index.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import { localDate, localTime, zonedToUtc, addDays, addMonths, nextOccurrence, humanDate } from '../lib/time.js'
import { APPT_STATUS, STATUS_LABEL, aplicarFinanceiro, resumoFinanceiro } from '../lib/appt-fin.js'

export const TYPES = ['task', 'appointment', 'reminder', 'shopping', 'note', 'expense', 'bill'] as const
export type ItemType = (typeof TYPES)[number]
export const EXPENSE_CATEGORIES = ['alimentacao', 'combustivel', 'casa', 'trabalho', 'compras', 'saude', 'transporte', 'lazer', 'outros']
export const INCOME_CATEGORIES = ['salario', 'servicos', 'vendas', 'outros']
const RECURRENCES = ['none', 'daily', 'weekly', 'monthly', 'yearly']

const pick = (d: any, ...keys: string[]) => { for (const k of keys) if (d?.[k] !== undefined && d?.[k] !== null && d?.[k] !== '') return d[k]; return undefined }

export interface ItemRow { id: number; user_id: number; type: ItemType; status: string | null; day: string | null; due_at: string | null; data: any; created_at: string; updated_at: string }
export const hydrate = (r: any): ItemRow => ({ ...r, id: Number(r.id), user_id: Number(r.user_id), data: J(r.data, {}) })

/** Formato de saída esperado pelo frontend para cada tipo. */
export function serialize(r: ItemRow) {
  const d = r.data
  const base = { id: r.id, createdAt: r.created_at, updatedAt: r.updated_at }
  switch (r.type) {
    case 'task': return { ...base, title: d.title, status: r.status || 'pending', priority: d.priority || 'normal', dueDate: r.day, dueTime: d.dueTime || null, area: d.area || null, notes: d.notes || null, completedAt: d.completedAt || null }
    case 'appointment': return { ...base, title: d.title, date: r.day, time: d.time || null, endTime: d.endTime || null, location: d.location || '', person: d.person || '', notes: d.notes || '', reminderMinutes: d.reminderMinutes ?? 0, reminders: Array.isArray(d.reminders) ? d.reminders : (d.reminderMinutes > 0 ? [d.reminderMinutes] : []), clienteNome: d.clienteNome || d.person || '', clienteTelefone: d.clienteTelefone || '', responsavel: d.responsavel || '', duracaoMin: d.duracaoMin || null, ...resumoFinanceiro(d), status: r.status || 'scheduled', statusLabel: STATUS_LABEL[r.status || 'scheduled'] || 'Agendado', historico: Array.isArray(d.historico) ? d.historico.slice(-15) : [], businessId: Number(d.businessId) || null, conclusaoAutomatica: d.conclusaoAutomatica ? { em: d.conclusaoAutomatica.em, corrigidaEm: d.conclusaoAutomatica.corrigidaEm || null } : null, sharedWith: !!d.shareToken }
    case 'reminder': return { ...base, message: d.message, remindAt: d.remindAt, snoozedUntil: d.snoozedUntil || null, status: r.status || 'pending', leadMinutes: d.leadMinutes || 0, recurrence: d.recurrence || 'none', date: d.date, time: d.time }
    case 'shopping': return { ...base, name: d.name, quantity: d.quantity || null, listName: d.listName || 'Compras', done: r.status === 'done' }
    case 'note': return { ...base, title: d.title || null, content: d.content, pinned: !!d.pinned, area: d.area || null }
    case 'expense': return { ...base, kind: d.kind === 'income' ? 'income' : 'expense', amount: d.amount, description: d.description || '', category: d.category || 'outros', date: r.day, subcategory: d.subcategory || null, method: d.method || null, time: d.time || null, notes: d.notes || null, movement: d.movement || null }
    case 'bill': return { ...base, name: d.name, amount: d.amount, dueDate: r.day, status: r.status || 'pending', category: d.category || 'casa', recurrence: d.recurrence || 'none', paidAt: d.paidAt || null, installmentCurrent: d.installmentCurrent || null, installmentTotal: d.installmentTotal || null, planId: null }
  }
}

export async function getItem(userId: number, type: string, id: number, t: Db = db()): Promise<ItemRow> {
  const rows = await t.query('SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [id, userId, type])
  if (!rows.length) fail(404, 'Registro não encontrado.', 'not_found')
  return hydrate(rows[0])
}
async function insert(t: Db, userId: number, type: ItemType, f: { status?: string | null; day?: string | null; dueAt?: string | null; data: object }) {
  const now = nowIso()
  // aprendizado pelo uso real (tela ou chat): recalcular os padrões no próximo uso; ocorrência gerada sozinha (próxima conta recorrente) não é ação da pessoa
  { const AUx = await import('../ai/aprendizado-uso.js'); AUx.marcarSujo(userId); if (!(f.data as any)?.prevId) AUx.registrarAcao(userId, type, f.data) }
  const rows = await t.query(
    `INSERT INTO items (user_id, type, status, day, due_at, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING *`,
    [userId, type, f.status ?? null, f.day ?? null, f.dueAt ?? null, JSON.stringify(f.data), now])
  return hydrate(rows[0])
}
async function update(t: Db, it: ItemRow, f: { status?: string | null; day?: string | null; dueAt?: string | null; data?: object }) {
  const rows = await t.query(
    `UPDATE items SET status = $1, day = $2, due_at = $3, data = $4, updated_at = $5 WHERE id = $6 AND user_id = $7 RETURNING *`,
    [f.status !== undefined ? f.status : it.status, f.day !== undefined ? f.day : it.day, f.dueAt !== undefined ? f.dueAt : it.due_at,
      JSON.stringify(f.data ?? it.data), nowIso(), it.id, it.user_id])
  if (rows.length !== 1) fail(404, 'Registro não encontrado.', 'not_found') // nunca atualiza outro registro nem mais de um
  return hydrate(rows[0])
}

function money(v: unknown, field = 'amount'): number {
  const n = num(v)
  if (n === null || n <= 0 || n > 1e10) fail(400, 'Informe um valor válido.', 'invalid', field)
  return Math.round(n! * 100) / 100
}

/** Cria um registro. Usado pela API e pelas ferramentas do chat. */
export async function createItem(u: SessionUser, type: string, d: any, t: Db = db()): Promise<ItemRow[]> {
  const s = settingsOf(u)
  const tz = s.timezone
  const today = localDate(tz)
  switch (type) {
    case 'task': {
      const title = str(pick(d, 'title', 'name'), 300)
      if (!title) fail(400, 'Informe a tarefa.', 'invalid', 'title')
      const due = pick(d, 'due_date', 'dueDate', 'date')
      if (due !== undefined && !isDate(due)) fail(400, 'Data inválida.', 'invalid', 'due_date')
      const dueTime = pick(d, 'due_time', 'dueTime', 'time')
      return [await insert(t, u.id, 'task', { status: 'pending', day: due || null, data: { title, priority: pick(d, 'priority') === 'high' ? 'high' : 'normal', dueTime: isTime(dueTime) ? dueTime : null, area: pick(d, 'area') || null, notes: str(pick(d, 'notes'), 2000) || null } })]
    }
    case 'appointment': {
      const title = str(pick(d, 'title'), 300)
      const date = pick(d, 'date')
      const time = pick(d, 'time')
      if (!title) fail(400, 'Informe o título.', 'invalid', 'title')
      if (!isDate(date)) fail(400, 'Informe a data do compromisso.', 'invalid', 'date')
      if (time !== undefined && !isTime(time)) fail(400, 'Horário inválido.', 'invalid', 'time')
      const rm = num(pick(d, 'reminder_minutes', 'reminderMinutes'))
      // padrão: dois avisos (24 h e 1 h antes); valor pedido no compromisso ou configurado pelo usuário é respeitado
      const reminders = rm !== null ? [Math.max(0, Math.min(10080, Math.round(rm)))].filter((x) => x > 0) : apptReminders(u)
      const reminderMinutes = reminders.length ? Math.min(...reminders) : 0
      const start = time ? zonedToUtc(date, time, tz) : null
      const dueAt = start ? nextApptDue(start, reminders, []) : null
      const st0 = pick(d, 'status'), status = APPT_STATUS.includes(st0) ? st0 : 'scheduled'
      return [await insert(t, u.id, 'appointment', { status, day: date, dueAt: ['cancelled', 'done', 'no_show'].includes(status) ? null : dueAt, data: { title, time: time || null, location: str(pick(d, 'location'), 200), person: str(pick(d, 'person'), 120), notes: str(pick(d, 'notes'), 2000), reminderMinutes, reminders, remindersSent: [], ...clientFields(d, u) } })]
    }
    case 'reminder': {
      const message = str(pick(d, 'message', 'title'), 500)
      if (!message) fail(400, 'Informe do que lembrar.', 'invalid', 'message')
      let date = pick(d, 'date')
      const time = pick(d, 'time') || s.defaultReminderTime || '09:00'
      if (date !== undefined && !isDate(date)) fail(400, 'Data inválida.', 'invalid', 'date')
      if (!isTime(time)) fail(400, 'Horário inválido.', 'invalid', 'time')
      if (!date) date = time <= localTime(tz) ? addDays(today, 1) : today
      const recurrence = RECURRENCES.includes(pick(d, 'recurrence')) ? pick(d, 'recurrence') : 'none'
      // lembrete simples avisa exatamente no horário pedido; antecedência só quando pedida no próprio lembrete
      const lb = num(pick(d, 'remind_before_minutes', 'leadMinutes'))
      const leadMinutes = lb === null ? 0 : Math.max(0, Math.min(10080, Math.round(lb)))
      const remindAt = zonedToUtc(date, time, tz)
      const dueAt = new Date(new Date(remindAt).getTime() - leadMinutes * 60_000).toISOString()
      return [await insert(t, u.id, 'reminder', { status: 'pending', day: date, dueAt, data: { message, date, time, recurrence, leadMinutes, remindAt } })]
    }
    case 'shopping': {
      const list: any[] = Array.isArray(d?.items) ? d.items : [{ name: pick(d, 'name'), quantity: pick(d, 'quantity') }]
      const listName = str(pick(d, 'list_name', 'listName'), 80) || 'Compras'
      const clean = list.map((i) => ({ name: str(i?.name, 120), quantity: str(i?.quantity, 40) || null })).filter((i) => i.name).slice(0, 100)
      if (!clean.length) fail(400, 'Informe ao menos um item.', 'invalid', 'items')
      const out: ItemRow[] = []
      for (const i of clean) out.push(await insert(t, u.id, 'shopping', { status: 'open', data: { ...i, listName } }))
      return out
    }
    case 'note': {
      const content = str(pick(d, 'content', 'text'), 10000)
      if (!content) fail(400, 'Escreva a anotação.', 'invalid', 'content')
      return [await insert(t, u.id, 'note', { data: { title: str(pick(d, 'title'), 200) || null, content, pinned: false, area: pick(d, 'area') || null } })]
    }
    case 'expense': {
      const kind = pick(d, 'kind') === 'income' ? 'income' : 'expense'
      const amount = money(pick(d, 'amount'))
      const date = pick(d, 'date') || today
      if (!isDate(date)) fail(400, 'Data inválida.', 'invalid', 'date')
      const cats = kind === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES
      const category = cats.includes(pick(d, 'category')) ? pick(d, 'category') : 'outros'
      const extra: any = {}
      for (const k of ['subcategory', 'method', 'time', 'notes', 'movement', 'source']) { const v = str(pick(d, k), 200); if (v) extra[k] = v }
      return [await insert(t, u.id, 'expense', { status: 'done', day: date, data: { kind, amount, description: str(pick(d, 'description'), 300), category, ...extra } })]
    }
    case 'bill': {
      const name = str(pick(d, 'name', 'description'), 200)
      if (!name) fail(400, 'Informe o nome da conta.', 'invalid', 'name')
      const amount = money(pick(d, 'amount'))
      const due = pick(d, 'due_date', 'dueDate', 'date')
      if (!isDate(due)) fail(400, 'Informe o vencimento.', 'invalid', 'due_date')
      const rec = pick(d, 'recurrence')
      const recurrence = ['none', 'weekly', 'monthly', 'yearly', 'installments'].includes(rec) ? rec : 'none'
      const total = recurrence === 'installments' ? Math.max(2, Math.min(120, Math.round(num(pick(d, 'installments', 'installment_total')) || 2))) : null
      const category = EXPENSE_CATEGORIES.includes(pick(d, 'category')) ? pick(d, 'category') : 'casa'
      return [await insert(t, u.id, 'bill', { status: 'pending', day: due, data: { name, amount, category, recurrence, installmentCurrent: total ? 1 : null, installmentTotal: total } })]
    }
  }
  fail(400, 'Tipo de registro inválido.', 'invalid_type')
  return []
}

/** Executa uma ação sobre um registro existente. */
export async function itemAction(u: SessionUser, action: string, type: string, id: number, d: any = {}, t: Db = db()) {
  if (action === 'create') return { created: await createItem(u, type, d, t) }
  if (!TYPES.includes(type as ItemType)) fail(400, 'Tipo de registro inválido.', 'invalid_type')
  if (!Number.isInteger(id) || id <= 0) fail(400, 'Registro inválido.', 'invalid')
  const it = await getItem(u.id, type, id, t)
  const tz = settingsOf(u).timezone
  switch (action) {
    case 'delete':
      await t.query('DELETE FROM items WHERE id = $1 AND user_id = $2', [id, u.id])
      if (it.type === 'task' && (it.data as any)?.followup) await (await import('../lib/followup.js')).aoMudarTarefa({ id: Number(it.id), user_id: u.id, data: it.data }, 'excluida').catch(() => {}) // acompanhamento ligado
      return { deleted: it }
    case 'task_status': {
      const st = ['pending', 'in_progress', 'done'].includes(d.status) ? d.status : fail(400, 'Situação inválida.', 'invalid', 'status')
      const up = await update(t, it, { status: st, data: { ...it.data, completedAt: st === 'done' ? nowIso() : null } })
      if ((it.data as any)?.followup) await (await import('../lib/followup.js')).aoMudarTarefa({ id: Number(it.id), user_id: u.id, data: it.data }, st).catch(() => {}) // concluir/reabrir na página Tarefas vale para o acompanhamento
      return { updated: up }
    }
    case 'shopping_toggle':
      return { updated: await update(t, it, { status: it.status === 'done' ? 'open' : 'done' }) }
    case 'note_pin':
      return { updated: await update(t, it, { data: { ...it.data, pinned: !it.data.pinned } }) }
    case 'reminder_done':
    case 'reminder_cancel':
      return { updated: await update(t, it, { status: 'done', dueAt: null }) }
    case 'reminder_snooze': {
      const minutes = Math.max(1, Math.min(10080, Math.round(num(d.minutes) || 15)))
      const until = new Date(Date.now() + minutes * 60_000).toISOString()
      return { updated: await update(t, it, { status: 'pending', dueAt: until, data: { ...it.data, snoozedUntil: until } }) }
    }
    case 'reminder_retry':
      return { updated: await update(t, it, { status: 'pending', dueAt: new Date(Date.now() + 60_000).toISOString() }) }
    case 'appointment_update': {
      // edição de UM compromisso: só o registro deste id e deste usuário (getItem acima já garantiu); nunca cria outro.
      // Proteção contra edição simultânea: se a tela enviou a versão que tinha aberta e o registro mudou depois, recusa.
      const esperado = d.expected_updated_at ?? d.expectedUpdatedAt
      if (esperado && new Date(String(esperado)).getTime() !== new Date(String(it.updated_at)).getTime()) fail(409, 'Este compromisso foi alterado em outro lugar enquanto você editava. Reabra para ver a versão atual.', 'conflict')
      const cur = it.data || {}, data: any = { ...cur }, em = nowIso(), hist: any[] = [], origem = str(d.origem, 20) || 'edicao'
      let day = it.day, status = it.status || 'scheduled'
      if (d.date !== undefined) { if (!isDate(d.date)) fail(400, 'Data inválida.', 'invalid', 'date'); day = d.date }
      if (d.time !== undefined) { if (d.time && !isTime(d.time)) fail(400, 'Horário inválido.', 'invalid', 'time'); data.time = d.time || null }
      for (const k of ['title', 'location', 'notes', 'person'] as const) if (d[k] !== undefined || (k === 'notes' && d.observacoes !== undefined)) data[k] = str(k === 'notes' ? (d.notes ?? d.observacoes) : d[k], k === 'notes' ? 2000 : 300)
      if (!data.title) fail(400, 'Informe o título.', 'invalid', 'title')
      if (d.status !== undefined) { if (!APPT_STATUS.includes(d.status)) fail(400, 'Situação inválida.', 'invalid', 'status'); status = d.status }
      if (d.priority !== undefined) { if (!['high', 'alta', 'normal'].includes(d.priority)) fail(400, 'Prioridade inválida.', 'invalid', 'priority'); if (d.priority === 'normal') delete data.priority; else data.priority = 'high' } // mesmo valor das tarefas ('high' | 'normal') // campo novo no JSON (sem migration)
      Object.assign(data, clientFields(d, u, data))
      if (d.reminder_minutes !== undefined || d.reminderMinutes !== undefined) { const v = Math.max(0, Math.min(10080, Math.round(Number(d.reminder_minutes ?? d.reminderMinutes) || 0))); data.reminders = v > 0 ? [v] : []; data.reminderMinutes = v }
      if (!Array.isArray(data.reminders)) data.reminders = data.reminderMinutes > 0 ? [data.reminderMinutes] : []
      // histórico: o que mudou, de → para, quando e por onde (tela, chat, IA)
      const ROT: Record<string, string> = { priority: 'prioridade', reminders: 'lembrete', title: 'serviço', time: 'horário', location: 'local', notes: 'observações', person: 'pessoa', clienteNome: 'cliente', clienteTelefone: 'telefone', responsavel: 'responsável', duracaoMin: 'duração', valorTotal: 'valor total', sinal: 'sinal', sinalPct: 'sinal (%)', valorPago: 'valor pago', reminderMinutes: 'aviso antes (min)' }
      for (const k of Object.keys(ROT)) if (JSON.stringify(cur[k] ?? null) !== JSON.stringify(data[k] ?? null) && !(cur[k] == null && data[k] === '')) hist.push({ campo: ROT[k], de: cur[k] ?? null, para: data[k] ?? null, em, origem })
      if (day !== it.day) hist.push({ campo: 'data', de: it.day, para: day, em, origem })
      if (status !== (it.status || 'scheduled')) hist.push({ campo: 'situação', de: STATUS_LABEL[it.status || 'scheduled'], para: STATUS_LABEL[status], em, origem })
      if (!hist.length) return { updated: it }
      data.historico = [...(Array.isArray(cur.historico) ? cur.historico : []), ...hist].slice(-50)
      const mudouHora = day !== it.day || (data.time || null) !== (cur.time || null) || d.reminder_minutes !== undefined || d.reminderMinutes !== undefined
      if (mudouHora) data.remindersSent = [] // avisos recomeçam só quando a data/hora/antecedência mudou
      // conclusão automática (lib/agenda-auto.ts): correção pela pessoa fica registrada e é respeitada — o compromisso não é
      // concluído de novo; remarcado para o futuro (ainda pendente), volta a valer a regra a partir do novo horário
      { const AA = await import('../lib/agenda-auto.js'), pend = ['scheduled', 'confirmed'].includes(status), lim = AA.limiteConclusao(day!, data, tz)
        if (cur.conclusaoAutomatica && status !== 'done' && !cur.conclusaoAutomatica.corrigidaEm) data.conclusaoAutomatica = { ...cur.conclusaoAutomatica, corrigidaEm: em, para: status }
        if (pend && lim != null && lim > Date.now()) { delete data.autoConcluir; if (data.conclusaoAutomatica) { data.historicoAuto = [...(Array.isArray(cur.historicoAuto) ? cur.historicoAuto : []), data.conclusaoAutomatica].slice(-5); delete data.conclusaoAutomatica } }
        else if (pend && status !== (it.status || 'scheduled')) data.autoConcluir = false }
      const start = data.time ? zonedToUtc(day!, data.time, tz) : null
      const ativo = !['cancelled', 'done', 'no_show'].includes(status)
      const dueAt = ativo && start ? nextApptDue(start, data.reminders, data.remindersSent || []) : null
      return { updated: await update(t, it, { day, dueAt, status, data }) }
    }
    case 'pay_bill': {
      if (it.status === 'paid') return { updated: it }
      const updated = await update(t, it, { status: 'paid', data: { ...it.data, paidAt: nowIso() } })
      // contas recorrentes geram a próxima ocorrência ao serem pagas
      const rec = it.data.recurrence
      let next: ItemRow | null = null
      if (rec === 'installments' && it.data.installmentCurrent < it.data.installmentTotal) {
        next = await insert(t, u.id, 'bill', { status: 'pending', day: addMonths(it.day!, 1), data: { ...it.data, paidAt: null, installmentCurrent: it.data.installmentCurrent + 1, prevId: it.id } })
      } else if (['weekly', 'monthly', 'yearly'].includes(rec) && !it.data.nextId) {
        next = await insert(t, u.id, 'bill', { status: 'pending', day: nextOccurrence(it.day!, rec), data: { ...it.data, paidAt: null, prevId: it.id } })
      }
      if (next) await update(t, updated, { data: { ...updated.data, nextId: next.id } })
      return { updated, next }
    }
    case 'unpay_bill': {
      if (it.data.nextId) {
        const nx = await t.query("SELECT id FROM items WHERE id = $1 AND user_id = $2 AND status = 'pending'", [it.data.nextId, u.id])
        if (nx.length) await t.query('DELETE FROM items WHERE id = $1', [it.data.nextId])
      }
      return { updated: await update(t, it, { status: 'pending', data: { ...it.data, paidAt: null, nextId: null } }) }
    }
    case 'update': {
      if (it.type === 'expense') {
        // lançamento financeiro: valida os campos, mantém a coluna "day" (usada por agenda e relatórios) igual à data,
        // guarda o histórico de cada alteração e não aceita campos internos vindos da tela
        const cur = it.data || {}, next: any = { ...cur }, hist: any[] = [], em = new Date().toISOString()
        const set = (k: string, v: any, label = k) => { if (v !== undefined && String(v) !== String(cur[k] ?? '')) { hist.push({ campo: label, de: cur[k] ?? null, para: v, em, origem: 'edicao' }); next[k] = v } }
        if (d.amount !== undefined) { const v = money(d.amount); set('amount', v, 'valor') }
        if (d.description !== undefined) { const v = str(d.description, 300); if (!v) fail(400, 'Informe a descrição.', 'invalid', 'description'); set('description', v, 'descricao') }
        if (d.category !== undefined) set('category', str(d.category, 40) || 'outros', 'categoria')
        if (d.subcategory !== undefined) set('subcategory', str(d.subcategory, 80), 'subcategoria')
        if (d.method !== undefined) set('method', str(d.method, 40), 'forma de pagamento')
        if (d.kind !== undefined) set('kind', d.kind === 'income' ? 'income' : 'expense', 'tipo')
        if (d.notes !== undefined || d.obs !== undefined) set('obs', str(d.obs ?? d.notes, 500), 'observacao')
        let day = it.day
        if (d.date !== undefined) { if (!isDate(d.date)) fail(400, 'Data inválida.', 'invalid', 'date'); if (d.date !== it.day) { hist.push({ campo: 'data', de: it.day, para: d.date, em, origem: 'edicao' }); day = d.date; next.date = d.date } }
        if (!hist.length) return { updated: it }
        next.historico = [...(Array.isArray(cur.historico) ? cur.historico : []), ...hist].slice(-30)
        return { updated: await update(t, it, { data: next, day }) }
      }
      // compromisso: a edição genérica passa pela mesma validação e histórico (nunca grava campos soltos)
      if (it.type === 'appointment') return itemAction(u, 'appointment_update', 'appointment', id, d, t)
      const data = { ...it.data, ...(typeof d === 'object' ? d : {}) }
      return { updated: await update(t, it, { data }) }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}

export async function itemsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const { action, type, id, data } = ctx.body || {}
  if (String(action) === 'create') await useQuota(u, String(type || ''))
  const r: any = await db().tx((t) => itemAction(u, String(action || ''), String(type || ''), Number(id), data || {}, t))
  return {
    ok: true,
    ...(r.created ? { items: r.created.map(serialize), item: serialize(r.created[0]) } : {}),
    ...(r.updated ? { item: serialize(r.updated) } : {}),
    ...(r.deleted ? { deleted: { type: r.deleted.type, id: r.deleted.id } } : {}),
  }
}

export async function listItems(userId: number, type: ItemType, extra = '', params: unknown[] = []) {
  const rows = await q(`SELECT * FROM items WHERE user_id = $1 AND type = $2 ${extra}`, [userId, type, ...params])
  return rows.map(hydrate)
}

export async function agendaGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const [tasks, appts, rems, shop, notes, bills] = await Promise.all([
    listItems(u.id, 'task', 'ORDER BY id DESC LIMIT 500'),
    listItems(u.id, 'appointment', 'AND day >= $3 AND day <= $4 ORDER BY day, id', [addDays(today, -1), addDays(today, 30)]),
    listItems(u.id, 'reminder', "AND status <> 'done' ORDER BY due_at"),
    listItems(u.id, 'shopping', 'ORDER BY id DESC LIMIT 300'),
    listItems(u.id, 'note', 'ORDER BY id DESC LIMIT 300'),
    listItems(u.id, 'bill', "AND status = 'pending' ORDER BY day"),
  ])
  const ns = notes.map(serialize) as any[]
  ns.sort((a, b) => Number(b.pinned) - Number(a.pinned))
  return {
    today, tz,
    tasks: tasks.map(serialize), appointments: await comEmpresas(u.id, appts.map(serialize)), reminders: rems.map(serialize),
    shopping: shop.map(serialize), notes: ns, bills: bills.map(serialize), sharedWithMe: [],
  }
}

/** Agenda de quem tem várias empresas: identifica a empresa de cada compromisso que veio de um agendamento/pedido.
 *  Só empresas que o usuário PODE ver (dele ou vinculadas e válidas); de outra empresa qualquer, a identificação não vai. */
export async function comEmpresas(userId: number, lista: any[]): Promise<any[]> {
  const ids = [...new Set(lista.map((a) => Number(a.businessId)).filter((n) => n > 0))]
  if (!ids.length) { for (const a of lista) a.empresa = null; return lista }
  const proprias = await q(`SELECT id, data FROM businesses WHERE owner_id = $1 AND id IN (${ids.map((_, i) => '$' + (i + 2)).join(',')})`, [userId, ...ids])
  const vinc = (await (await import('../lib/vinculos.js')).vinculadasValidas(userId)).filter((b: any) => ids.includes(Number(b.id)))
  const { refImagem } = await import('../lib/imagem-empresa.js'), m = new Map<number, any>()
  for (const b of [...proprias, ...vinc] as any[]) { const d = J<any>(b.data, {}); m.set(Number(b.id), { id: Number(b.id), nome: String(d.empresa || 'Empresa'), logo: d.logo ? refImagem(Number(b.id), 'logo', d.logo) : null }) }
  for (const a of lista) { a.empresa = m.get(Number(a.businessId)) || null; if (!a.empresa) a.businessId = null }
  return lista
}

function monthEnd(m: string) { return addDays(addMonths(m + '-01', 1), -1) }

export async function financeGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const qm = ctx.query.get('month')
  const month = qm && /^\d{4}-\d{2}$/.test(qm) && qm <= today.slice(0, 7) ? qm : today.slice(0, 7)
  const start = month + '-01', end = monthEnd(month)
  const entries = (await listItems(u.id, 'expense', 'AND day >= $3 AND day <= $4 ORDER BY day DESC, id DESC', [start, end])).map(serialize) as any[]
  const income = entries.filter((e) => e.kind === 'income').reduce((s, e) => s + e.amount, 0)
  const spentList = entries.filter((e) => e.kind === 'expense')
  const spent = spentList.reduce((s, e) => s + e.amount, 0)
  const bills = (await listItems(u.id, 'bill', 'ORDER BY day')).map(serialize) as any[]
  const pendingBills = bills.filter((b) => b.status === 'pending' && b.dueDate <= end)
  const paid = bills.filter((b) => b.status === 'paid' && ((b.paidAt && b.paidAt.slice(0, 7) === month) || b.dueDate.slice(0, 7) === month))
  const pendingAmount = pendingBills.reduce((s, b) => s + b.amount, 0)
  const paidAmount = paid.reduce((s, b) => s + b.amount, 0)
  const cats = new Map<string, number>()
  for (const e of spentList) cats.set(e.category, (cats.get(e.category) || 0) + e.amount)
  const byCategory = [...cats.entries()].map(([slug, total]) => ({ slug, total: Math.round(total * 100) / 100 })).sort((a, b) => b.total - a.total)
  const top = spentList.slice().sort((a, b) => b.amount - a.amount)[0] || null
  // série dos últimos 6 meses
  const first = addMonths(start, -5)
  const hist = (await listItems(u.id, 'expense', 'AND day >= $3 AND day <= $4', [first, end])).map(serialize) as any[]
  const series = Array.from({ length: 6 }, (_, i) => {
    const m = addMonths(first, i).slice(0, 7)
    const inM = hist.filter((e) => e.date.slice(0, 7) === m)
    return { month: m, spent: r2(inM.filter((e) => e.kind === 'expense').reduce((s, e) => s + e.amount, 0)), income: r2(inM.filter((e) => e.kind === 'income').reduce((s, e) => s + e.amount, 0)) }
  })
  return {
    month, today, entries, income: r2(income), spent: r2(spent), balance: r2(income - spent - pendingAmount),
    bills: { pendingAmount: r2(pendingAmount), paidAmount: r2(paidAmount), paid }, pendingBills, plans: {},
    series, byCategory, top,
  }
}
const r2 = (n: number) => Math.round(n * 100) / 100

/** /api/day — linha do tempo (compromissos, tarefas, contas, lembretes) num intervalo de datas. */
export async function dayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const overview = !ctx.query.get('from') && !ctx.query.get('to')
  let from = ctx.query.get('from') || today, to = ctx.query.get('to') || from
  if (!isDate(from) || !isDate(to) || to < from) fail(400, 'Período inválido.', 'invalid')
  if ((Date.parse(to) - Date.parse(from)) / 86400000 > 62) to = addDays(from, 62)
  const nowT = localTime(tz)
  const entries: any[] = []
  for (const a of await listItems(u.id, 'appointment', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(a)
    entries.push({ key: `appointment:${a.id}`, kind: 'appointment', id: a.id, day: s.date, time: s.time, title: s.title, detail: s.location || s.person || '', status: s.date < today || (s.date === today && s.time && s.time < nowT) ? 'done' : 'upcoming' })
  }
  for (const t of await listItems(u.id, 'task', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(t)
    entries.push({ key: `task:${t.id}`, kind: 'task', id: t.id, day: s.dueDate, time: s.dueTime, title: s.title, detail: '', status: s.status === 'done' ? 'done' : s.dueDate < today ? 'overdue' : 'pending' })
  }
  for (const b of await listItems(u.id, 'bill', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(b)
    entries.push({ key: `bill:${b.id}`, kind: 'bill', id: b.id, day: s.dueDate, time: null, title: s.name, amount: s.amount, status: s.status === 'paid' ? 'done' : s.dueDate < today ? 'overdue' : 'pending' })
  }
  for (const r of await listItems(u.id, 'reminder', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(r)
    entries.push({ key: `reminder:${r.id}`, kind: 'reminder', id: r.id, day: s.date, time: s.time, title: s.message, detail: '', status: s.status === 'done' ? 'done' : s.status === 'sent' ? 'pending' : s.snoozedUntil ? 'snoozed' : 'upcoming' })
  }
  entries.sort((a, b) => (a.day + (a.time || '99:99')).localeCompare(b.day + (b.time || '99:99')))
  const base = { from, to, today, tz, entries, unavailable: [] as string[] }
  if (!overview) return base
  // Visão "Meu Dia" (GET /api/day sem período): saudação, números do dia e prioridades
  const expenses = (await listItems(u.id, 'expense', 'AND day = $3 ORDER BY id DESC', [today])).map(serialize) as any[]
  const appointments = entries.filter((e) => e.kind === 'appointment')
  const openTasks = (await listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') AND (day IS NULL OR day <= $3) ORDER BY day, id", [today])).map(serialize) as any[]
  const pendingBills = (await listItems(u.id, 'bill', "AND status = 'pending' AND day <= $3 ORDER BY day", [today])).map(serialize) as any[]
  const priorities = [
    ...pendingBills.map((b) => ({ kind: 'bill', id: b.id, title: b.name, detail: b.dueDate < today ? 'Atrasada' : 'Vence hoje' })),
    ...openTasks.sort((a, b) => Number(b.priority === 'high') - Number(a.priority === 'high')).map((t) => ({ kind: 'task', id: t.id, title: t.title, detail: t.dueDate && t.dueDate < today ? 'Atrasada' : t.priority === 'high' ? 'Prioridade alta' : t.dueDate ? 'Para hoje' : 'Sem prazo' })),
    ...appointments.filter((a) => a.status === 'upcoming').map((a) => ({ kind: 'appointment', id: a.id, title: a.title, detail: a.time ? `Às ${a.time}` : 'Hoje' })),
  ].slice(0, 5)
  return {
    ...base, name: u.name, hour: Number(localTime(tz).slice(0, 2)),
    spentToday: r2(expenses.filter((e) => e.kind === 'expense').reduce((x, e) => x + e.amount, 0)),
    appointments, tasks: openTasks, expenses: expenses.filter((e) => e.kind === 'expense'), priorities,
  }
}

/** /api/summary — resumo do dia com números reais do banco. */
export async function summaryGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const s = settingsOf(u)
  const today = localDate(s.timezone)
  const spentRows = await listItems(u.id, 'expense', 'AND day = $3', [today])
  const spent = r2(spentRows.filter((e) => e.data.kind !== 'income').reduce((a, e) => a + Number(e.data.amount || 0), 0))
  const tasks = await listItems(u.id, 'task', '')
  const tasksDone = tasks.filter((t) => t.status === 'done' && String(t.data.completedAt || '').startsWith(today)).length
  const tasksPending = tasks.filter((t) => t.status !== 'done').length
  const appointments = (await listItems(u.id, 'appointment', 'AND day = $3', [today])).length
  const billsDue = (await listItems(u.id, 'bill', "AND status = 'pending' AND day <= $3", [today])).length
  const fmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: s.currency || 'BRL' })
  const text = `Resumo de ${humanDate(today, today).toLowerCase()}: você gastou ${fmt.format(spent)}, concluiu ${tasksDone} ${tasksDone === 1 ? 'tarefa' : 'tarefas'} e tem ${tasksPending} ${tasksPending === 1 ? 'pendência' : 'pendências'}. ` +
    `${appointments ? `Hoje há ${appointments} ${appointments === 1 ? 'compromisso' : 'compromissos'}. ` : ''}${billsDue ? `${billsDue} ${billsDue === 1 ? 'conta vence' : 'contas vencem'} até hoje.` : 'Nenhuma conta vencendo.'}`
  return { summary: { date: today, text, data: { spent, tasksDone, tasksPending, appointments, billsDue } } }
}

export { one }

/** Avisos de compromissos: 24 h e 1 h antes, salvo se o usuário escolheu outra antecedência no perfil. */
export function apptReminders(u: { settings?: any }) {
  const raw = (u as any).settings || {}
  if (raw.reminderLeadMinutes !== undefined && raw.reminderLeadMinutes !== null && raw.reminderLeadCustom === true) { const v = Math.round(Number(raw.reminderLeadMinutes)); return v > 0 ? [v] : [] }
  return [1440, 60]
}
/** Próximo aviso ainda não enviado e ainda no futuro (ou null). */
export function nextApptDue(startIso: string, reminders: number[], sent: number[]) {
  const st = new Date(startIso).getTime(), now = Date.now()
  const pend = (reminders || []).filter((m) => !(sent || []).includes(m)).map((m) => ({ m, at: st - m * 60_000 })).filter((x) => x.at > now - 60_000).sort((a, b) => a.at - b.at)
  return pend.length ? new Date(Math.max(pend[0].at, now)).toISOString() : null
}

/** Cliente do compromisso (nome, contato), responsável e valores. Telefone guardado só com dígitos. Nunca inventa: campo vazio fica vazio. */
function clientFields(d: any, u: any, cur: any = {}) {
  const out: any = {}
  const has = (k: string, k2: string) => d[k] !== undefined || d[k2] !== undefined
  if (has('cliente_nome', 'clienteNome') && (str(d.cliente_nome ?? d.clienteNome, 120) || cur.clienteNome !== undefined || !d.person)) out.clienteNome = str(d.cliente_nome ?? d.clienteNome, 120)
  else if (cur.clienteNome === undefined && d.person) out.clienteNome = str(d.person, 120) // nome vazio vindo junto com a pessoa não apaga o cliente
  // telefone: só dígitos e NACIONAL (DDD + número) — "+55 88 92151-5103" e "88921515103" são o mesmo contato (a tela e o convite recolocam o 55)
  if (has('cliente_telefone', 'clienteTelefone')) { const dg0 = String(d.cliente_telefone ?? d.clienteTelefone ?? '').replace(/\D/g, ''), dg = /^55\d{10,11}$/.test(dg0) ? dg0.slice(2) : dg0; out.clienteTelefone = dg.length >= 10 && dg.length <= 13 ? dg : '' }
  if (has('responsavel', 'responsavel')) out.responsavel = str(d.responsavel, 120)
  else if (cur.responsavel === undefined && !cur.title) out.responsavel = String(u?.name || '').trim().slice(0, 120)
  if (d.duracao_min !== undefined || d.duracaoMin !== undefined) { const n = Math.round(Number(d.duracao_min ?? d.duracaoMin)); out.duracaoMin = n > 0 && n <= 1440 ? n : null }
  // valor total, sinal (R$ ou %) e valor efetivamente pago: regras únicas em lib/appt-fin.ts
  if (['valor_total', 'valorTotal', 'sinal', 'sinal_valor', 'sinal_pct', 'sinalPct', 'valor_pago', 'valorPago'].some((k) => d[k] !== undefined)) Object.assign(out, aplicarFinanceiro(cur, d))
  return out
}

/** Configurações → Compromissos: lista do PRÓPRIO usuário (próximos, anteriores ou todos), com busca por serviço, cliente,
 *  telefone ou observação e filtro de situação. Somente leitura — a edição usa a ação appointment_update (por id). */
export async function compromissosGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const today = localDate(settingsOf(u).timezone), qp = (k: string) => String(ctx.query?.get(k) ?? '')
  // calendário: intervalo de datas (só leitura, só do próprio usuário; no máximo ~3 meses por consulta)
  const de = qp('de'), ate = qp('ate'), iso = /^\d{4}-\d{2}-\d{2}$/
  if (iso.test(de) && iso.test(ate) && de <= ate && !isNaN(Date.parse(de)) && !isNaN(Date.parse(ate)) && (Date.parse(ate) - Date.parse(de)) / 86400_000 <= 93) {
    const lista = (await listItems(u.id, 'appointment', 'AND day >= $3 AND day <= $4 ORDER BY day, id LIMIT 1000', [de, ate])).map(serialize) as any[]
    lista.sort((a, b) => a.date.localeCompare(b.date) || String(a.time || '99:99').localeCompare(String(b.time || '99:99')) || a.id - b.id)
    return { today, de, ate, total: lista.length, compromissos: await comEmpresas(u.id, lista) }
  }
  const periodo = ['proximos', 'anteriores', 'todos'].includes(qp('periodo')) ? qp('periodo') : 'proximos'
  const status = APPT_STATUS.includes(qp('status') as any) ? qp('status') : ''
  const where = periodo === 'proximos' ? 'AND day >= $3 ORDER BY day, id LIMIT 500' : periodo === 'anteriores' ? 'AND day < $3 ORDER BY day DESC, id DESC LIMIT 500' : 'ORDER BY day DESC, id DESC LIMIT 1000'
  let lista = (await listItems(u.id, 'appointment', where, periodo === 'todos' ? [] : [today])).map(serialize) as any[]
  if (status) lista = lista.filter((a) => a.status === status)
  const busca = qp('q').trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').slice(0, 80)
  if (busca) { const dg = busca.replace(/\D/g, ''); lista = lista.filter((a) => (`${a.title} ${a.clienteNome} ${a.notes} ${a.location}`).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(busca) || (dg.length >= 4 && String(a.clienteTelefone || '').includes(dg))) }
  return { today, periodo, total: lista.length, compromissos: await comEmpresas(u.id, lista.slice(0, 200)) }
}

/** Evolução da agenda (gráfico do calendário): estatísticas reais dos compromissos do próprio usuário, no fuso dele. */
export async function compromissosEstatisticasGet(ctx: Ctx) {
  const u = requireUser(ctx), qp = (k: string) => String(ctx.query?.get(k) ?? '')
  const { estatisticas } = await import('../lib/agenda-stats.js')
  return estatisticas(u.id, settingsOf(u).timezone, qp('periodo') || '30d', qp('de') || undefined, qp('ate') || undefined)
}
