// Financeiro → Mercado Pago: conexão real da conta do usuário pelo OAuth oficial do Mercado Pago e
// leitura dos pagamentos recebidos pela API oficial (/v1/payments/search). Nada é simulado.
// O administrador cadastra a aplicação (Client ID e Client Secret) em Painel → Mercado Pago.
import { randomBytes, createHash } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal } from '../lib/settings.js'
import { getUM, setUM } from '../lib/usermod.js'
import { pub } from '../lib/publicurl.js'
export { app as mpApp }
const API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const AUTH = () => (process.env.MP_AUTH_BASE || 'https://auth.mercadopago.com').replace(/\/$/, '')
const redirectUri = () => `${pub()}/api/mercadopago/oauth/callback`
async function app() { const c = await getConfig<any>('mp_oauth', {}); return { clientId: String(c.clientId || ''), clientSecret: await unseal(c.clientSecret || '').catch(() => ''), teste: c.ambiente === 'teste', pkce: c.pkce === true } }
export async function appConfigured() { const a = await app(); return !!(a.clientId && a.clientSecret) }
/** Chave secreta que assina as notificações de um pagamento desta empresa. O Mercado Pago assina com a chave da APLICAÇÃO
 *  dona da credencial usada para criar o pagamento: na conexão automática (OAuth) é a aplicação do Meu Assistente (chave do
 *  painel); na manual é a aplicação da própria empresa (chave que ela informou). A chave de uma nunca vale para a outra —
 *  antes, a manual sem chave própria caía na chave do sistema e as notificações verdadeiras eram descartadas. '' = sem validação
 *  de assinatura (o pagamento é sempre conferido na API com o token da própria empresa, nunca pelo corpo recebido). */
export async function segredoWebhookLoja(d: any): Promise<string> {
  if (d?.mpModo === 'oauth') return globalWebhookSecret()
  return d?.mpSecret ? unseal(d.mpSecret).catch(() => '') : ''
}
/** A mesma conta Mercado Pago já recebe por empresa de OUTRO dono (em qualquer modalidade)?
 *  25/11: deixou de BLOQUEAR a conexão. Cada empresa tem a própria integração (credencial cifrada por empresa em
 *  empresa_integracoes), cada cobrança/pedido é criado com o token da empresa dona e o webhook é conferido por empresa
 *  (?store=, consulta na API com o token dela, referência order:/cob: e id do pagamento conferidos com o registro DESTA
 *  empresa) — uma conta compartilhada não mistura pedidos. Quem tem o Access Token ou faz login no Mercado Pago (OAuth) prova
 *  que pode receber naquela conta; a exclusividade global impedia casos legítimos (franquias, sócios, várias contas do mesmo
 *  dono). Agora só fica registrado na auditoria (sem token) para rastreabilidade. */
export async function contaEmUsoPorOutroDono(bid: number, mpUserId: number | null, ownerId: number): Promise<boolean> {
  if (!mpUserId) return false
  const { q } = await import('../db/index.js')
  await (await import('../lib/integracoes.js')).importarTodas().catch(() => 0)
  for (const o of await q("SELECT i.dados, b.owner_id FROM empresa_integracoes i JOIN businesses b ON b.id = i.business_id WHERE i.provedor = 'mercadopago' AND i.business_id <> $1", [bid])) {
    const od = typeof o.dados === 'string' ? JSON.parse(o.dados || '{}') : (o.dados || {})
    const conta = Number(od.mpUserId || od.mpConta?.id) || 0
    if (od.mpTok && conta === Number(mpUserId) && Number(o.owner_id) !== Number(ownerId)) return true
  }
  return false
}
/** Auditoria (sem credenciais) quando a conta já está ligada a empresa de outro dono — informativo, não bloqueia. */
export async function registrarContaCompartilhada(bid: number, mpUserId: number | null, ownerId: number, userId: number) {
  try { if (await contaEmUsoPorOutroDono(bid, mpUserId, ownerId)) { const { audit } = await import('../lib/account.js'); await audit(userId, 'mp.conta_compartilhada', null, { business: bid, conta: mpUserId }) } } catch { /* auditoria é opcional */ }
}
/** Autorização automática iniciada e ainda não concluída (state guardado, não usado, dentro dos 15 minutos). */
export async function autorizacaoPendente(bid: number): Promise<string | null> {
  const { one } = await import('../db/index.js')
  const r = await one('SELECT criado_em FROM mp_oauth_estados WHERE business_id = $1 AND usado_em IS NULL AND criado_em > $2 ORDER BY criado_em DESC LIMIT 1', [bid, new Date(Date.now() - 15 * 60_000).toISOString()])
  return r ? new Date(r.criado_em instanceof Date ? r.criado_em : String(r.criado_em)).toISOString() : null
}
/** Notificação "mp-connect" da aplicação do sistema (tópico "Vinculação de aplicações"): quando um vendedor desvincula o Meu
 *  Assistente no Mercado Pago (application.deauthorized), as empresas conectadas pelo OAuth com aquela conta são conferidas
 *  NA API (/users/me com o token delas). O corpo da notificação não altera nada sozinho: só dispara a verificação real, que
 *  marca "Erro na conexão" se o token foi revogado. Assinatura validada com a chave da aplicação do sistema, quando definida. */
export async function mpConnectWebhook(ctx: Ctx) {
  const sec = await globalWebhookSecret(), id = String(ctx.query.get('data.id') || ctx.body?.data?.id || '')
  if (sec) {
    const sig = String(ctx.req.headers['x-signature'] || ''), rid = String(ctx.req.headers['x-request-id'] || '')
    const ts = /ts=([^,]+)/.exec(sig)?.[1]?.trim() || '', v1 = /v1=([^,]+)/.exec(sig)?.[1]?.trim() || ''
    const { createHmac, timingSafeEqual } = await import('node:crypto')
    const man = (id ? `id:${/^[a-z0-9]+$/i.test(id) ? id.toLowerCase() : id};` : '') + (rid ? `request-id:${rid};` : '') + (ts ? `ts:${ts};` : '')
    const calc = createHmac('sha256', sec).update(man).digest('hex')
    if (!v1 || v1.length !== calc.length || !timingSafeEqual(Buffer.from(v1), Buffer.from(calc))) fail(401, 'Assinatura inválida.', 'bad_signature')
  }
  const conta = Number(ctx.body?.user_id || ctx.query.get('user_id')) || 0, acao = String(ctx.body?.action || '')
  if (!conta || acao !== 'application.deauthorized') return { ok: true }
  const { q, J } = await import('../db/index.js'); let conferidas = 0
  for (const r of await q("SELECT business_id, dados FROM empresa_integracoes WHERE provedor = 'mercadopago'")) {
    const d = J<any>((r as any).dados, {}); if (d.mpModo !== 'oauth' || !d.mpTok || Number(d.mpUserId) !== conta) continue
    await verificarLoja({ id: Number((r as any).business_id) }).catch(() => null); conferidas++
  }
  console.error(`[mp-oauth] desvinculação recebida para uma conta; ${conferidas} empresa(s) conferida(s) na API`)
  return { ok: true }
}
/** Desiste de uma autorização automática em andamento (o retorno com aquele state passa a ser recusado). */
export async function cancelarAutorizacao(bid: number) { const { q } = await import('../db/index.js'); await q('UPDATE mp_oauth_estados SET usado_em = $1 WHERE business_id = $2 AND usado_em IS NULL', [new Date().toISOString(), bid]) }
export async function globalWebhookSecret() { const c = await getConfig<any>('mp_oauth', {}); return c.exigirAssinatura && c.webhookSecret ? await unseal(c.webhookSecret).catch(() => '') : '' }
/** Empresa pode configurar o recebimento pelo Mercado Pago? Plano empresarial (conforme o painel) e anúncio aprovado pelo
 *  administrador: 'ativo' (no ar, dentro da validade) ou 'aprovado' (aprovado, aguardando o pagamento da ativação — a loja
 *  já pode deixar o recebimento pronto; os clientes só pagam online quando ela entra no ar). Antes só 'ativo' passava, e a
 *  loja aprovada recebia "disponível só para plano empresarial ativo" mesmo tendo o plano certo. */
export async function planAllowed(b: any) { return !(await motivoBloqueio(b)) }
/** Por que a empresa não pode configurar (null = pode). Mensagem certa para cada caso. */
export async function motivoBloqueio(b: any): Promise<{ mensagem: string; codigo: string } | null> {
  if (!b) return { mensagem: 'Empresa não encontrada.', codigo: 'not_found' }
  if (!['ativo', 'aprovado'].includes(String(b.status))) return { mensagem: 'O recebimento pelo Mercado Pago é liberado depois que o administrador aprova o anúncio da empresa.', codigo: 'aguardando_aprovacao' }
  if (b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now()) return { mensagem: 'O plano da empresa venceu. Renove para voltar a receber pelo Mercado Pago.', codigo: 'plan_required' }
  if (!(await planoPermite(b))) return { mensagem: 'O recebimento pelo Mercado Pago está disponível só para empresas com plano empresarial ativo.', codigo: 'plan_required' }
  return null
}
async function planoPermite(b: any) {
  const c = await getConfig<any>('mp_oauth', {}); const ads: any[] = await getConfig<any[]>('ad_plans', [])
  const lista: string[] = Array.isArray(c.planos) && c.planos.length ? c.planos : (ads.length ? ads.filter((p) => Number(p.nivel) >= 4).map((p) => p.id) : ['n4'])
  return lista.includes(String(b.plan_id))
}
/** Confere um Access Token na API oficial (GET /users/me) ANTES de gravar. Nunca registra o token.
 *  ok=true: o Mercado Pago aceitou; recusado=true: 401/403 (token errado, revogado ou a Public Key);
 *  os dois falsos: sem resposta do Mercado Pago agora (rede/instabilidade). */
export async function validarToken(tok: string): Promise<{ ok: boolean; recusado: boolean; status: number; conta: any }> {
  try {
    const r = await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${tok}` }, signal: AbortSignal.timeout(10_000) })
    const j: any = await r.json().catch(() => ({}))
    if (r.ok && j && j.id) return { ok: true, recusado: false, status: r.status, conta: contaDe(j) }
    return { ok: false, recusado: r.status === 401 || r.status === 403 || r.status === 400, status: r.status, conta: null }
  } catch { return { ok: false, recusado: false, status: 0, conta: null } }
}
const mascara = (e: any) => (e ? String(e).replace(/^(.{2}).*(@.*)$/, '$1***$2') : '')
/** POST /oauth/token (contrato oficial). Ambiente de teste envia test_token=true; PKCE envia o code_verifier. */
async function tokenReq(body: Record<string, string>): Promise<{ ok: boolean; status: number; j: any; erro: string }> {
  const a = await app()
  try {
    const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ client_id: a.clientId, client_secret: a.clientSecret, ...body }) })
    const j: any = await r.json().catch(() => ({}))
    return { ok: r.ok && !!j.access_token, status: r.status, j, erro: r.ok && j.access_token ? '' : String(j.message || j.error_description || j.error || `HTTP ${r.status}`).slice(0, 200) }
  } catch (e: any) { return { ok: false, status: 0, j: {}, erro: 'sem conexão com o Mercado Pago' } }
}
/** Renova o token de acesso (grant_type=refresh_token). invalido=true quando o Mercado Pago recusa o refresh (revogado/expirado). */
export async function refreshToken(refresh: string): Promise<{ access: string; refresh: string; exp: number } | null> { const r = await renovar(refresh); return r.ok ? r.t : null }
export async function renovar(refresh: string): Promise<{ ok: true; t: { access: string; refresh: string; exp: number } } | { ok: false; invalido: boolean; erro: string }> {
  const a = await app(); if (!a.clientId || !a.clientSecret || !refresh) return { ok: false, invalido: false, erro: 'aplicação não configurada' }
  const r = await tokenReq({ grant_type: 'refresh_token', refresh_token: refresh })
  if (r.ok) return { ok: true, t: { access: r.j.access_token, refresh: r.j.refresh_token || refresh, exp: Date.now() + (Number(r.j.expires_in) || 15552000) * 1000 } }
  return { ok: false, invalido: r.status >= 400 && r.status < 500, erro: r.erro }
}
/** Valida Client ID/Secret no Mercado Pago (grant_type=client_credentials). */
export async function testApp() {
  const a = await app(); if (!a.clientId || !a.clientSecret) return { ok: false, mensagem: 'Preencha o Client ID e o Client Secret.' }
  const r = await tokenReq({ grant_type: 'client_credentials' })
  if (r.status === 0) return { ok: false, mensagem: 'Sem conexão com o Mercado Pago.' }
  return r.ok ? { ok: true, mensagem: `Credenciais válidas. URL de redirecionamento a cadastrar na aplicação: ${redirectUri()}${a.teste ? ' · ambiente de teste (homologação)' : ''}${a.pkce ? ' · PKCE ligado' : ''}.` } : { ok: false, mensagem: `O Mercado Pago recusou as credenciais (${r.status}${r.erro ? ': ' + r.erro : ''}).` }
}
/* ---------- pedido de autorização: state guardado no servidor (uso único, 15 min) ---------- */
const b64url = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
async function autorizacao(userId: number, bid: number | null) {
  const ap = await app(); if (!ap.clientId || !ap.clientSecret) fail(400, 'A conexão automática ainda não foi configurada pelo administrador do sistema (Painel → Mercado Pago → Aplicação Mercado Pago).', 'not_configured')
  if (!userId) fail(401, 'Entre para continuar.', 'auth_required')
  const { q } = await import('../db/index.js')
  await q('DELETE FROM mp_oauth_estados WHERE criado_em < $1', [new Date(Date.now() - 86400_000).toISOString()])
  const state = randomBytes(24).toString('hex'), verifier = ap.pkce ? b64url(randomBytes(48)) : ''
  await q('INSERT INTO mp_oauth_estados (state, user_id, business_id, verifier, criado_em) VALUES ($1,$2,$3,$4,$5)', [state, userId, bid, verifier ? await seal(verifier) : '', new Date().toISOString()])
  const qs = new URLSearchParams({ client_id: ap.clientId, response_type: 'code', platform_id: 'mp', state, redirect_uri: redirectUri() })
  if (verifier) { qs.set('code_challenge', b64url(createHash('sha256').update(verifier).digest())); qs.set('code_challenge_method', 'S256') }
  return `${AUTH()}/authorization?${qs.toString()}`
}
export async function businessAuthUrl(userId: number, bid: number) { return autorizacao(userId, bid) }

/* ---------- conexão da EMPRESA (tokens próprios, criptografados, só no servidor) ----------
 * Os dados ficam em empresa_integracoes (provedor "mercadopago"), não mais dentro de businesses.data: as ~30 rotinas
 * que regravam o JSON da empresa não conseguem mais desfazer um token renovado (ver lib/integracoes.ts). Toda gravação
 * é um "patch" aplicado sobre a versão mais recente, com versão conferida. */
export type StatusLoja = 'conectado' | 'desconectado' | 'erro' | 'pendente'
/** pendente = credencial manual salva que o Mercado Pago ainda não confirmou (sem resposta na hora); o agendador confere. */
export function statusLoja(d: any): StatusLoja {
  if (!d?.mpTok) return 'desconectado'
  if (d.mpStatus === 'erro') return 'erro'
  if (d.mpStatus === 'pendente') return 'pendente'
  if (d.mpModo === 'oauth' && Number(d.mpExp) && Date.now() > Number(d.mpExp) && !d.mpRefresh) return 'erro'
  return 'conectado'
}
/** Dados do Mercado Pago da empresa (formato de sempre: mpTok, mpRefresh, mpModo…). */
export async function mpDe(bid: number): Promise<any> { return (await import('../lib/integracoes.js')).dados(Number(bid), 'mercadopago') }
/** Aplica alterações na integração (sobre a versão mais recente). Limpar credenciais exige limpar=true. */
export async function gravarMp(bid: number, patch: Record<string, any> | ((d: any) => any), motivo: string, limpar = false) {
  const I = await import('../lib/integracoes.js')
  return I.atualizar(Number(bid), 'mercadopago', (cur) => (typeof patch === 'function' ? patch(cur) : { ...cur, ...patch }), motivo, { permitirLimpar: limpar })
}
/** Liga/desliga "pagamento online" da empresa (configuração da loja, fica em businesses.data). Só toca nesse campo. */
export async function pagamentoOnline(bid: number, on: boolean) {
  const { one, q, nowIso, J } = await import('../db/index.js')
  const r = await one('SELECT data FROM businesses WHERE id = $1', [bid]); if (!r) return
  const d = J<any>(r.data, {}); if (!!d.pagamento?.online === on) return
  d.pagamento = { ...(d.pagamento || {}), online: on }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), bid])
}
/** Credencial salva que não abre com as chaves atuais (APP_SECRET trocado/removido): nada foi apagado. */
export async function credencialIlegivel(d: any): Promise<boolean> { if (!d?.mpTok) return false; const { unsealInfo } = await import('../lib/settings.js'); return !(await unsealInfo(d.mpTok)).ok }
// uma renovação por empresa por vez: o Mercado Pago troca o refresh token a cada renovação, e duas ao mesmo tempo
// fariam a segunda ser recusada (e a conexão parecer revogada)
const renovando = new Map<number, Promise<{ ok: boolean; renovado: boolean; erro?: string }>>()
/** Renova o token da empresa (OAuth). force=false só renova quando faltam menos de 30 dias. Erros ficam no status. */
export function renovarLoja(b: any, force = false): Promise<{ ok: boolean; renovado: boolean; erro?: string }> {
  const bid = Number(b.id), em = renovando.get(bid); if (em) return em
  const pr = renovarLoja0(bid, force).finally(() => renovando.delete(bid)); renovando.set(bid, pr); return pr
}
async function renovarLoja0(bid: number, force: boolean): Promise<{ ok: boolean; renovado: boolean; erro?: string }> {
  const d = await mpDe(bid); if (d.mpModo !== 'oauth' || !d.mpTok) return { ok: true, renovado: false }
  if (!force && Number(d.mpExp) && Number(d.mpExp) - Date.now() > 30 * 86400_000) return { ok: true, renovado: false }
  const usado = d.mpRefresh || '', info = usado ? await (await import('../lib/settings.js')).unsealInfo(usado) : { ok: true, valor: '' }
  if (!info.ok) return { ok: false, renovado: false, erro: 'credencial salva não abre com a chave atual do servidor (nada foi apagado)' } // não marca erro: é a chave do servidor, não a conta
  const ref = info.valor
  if (!ref) { if (Number(d.mpExp) && Date.now() > Number(d.mpExp)) await gravarMp(bid, (c) => (c.mpRefresh === usado ? { ...c, mpStatus: 'erro', mpErro: 'A autorização expirou. Conecte a conta novamente.' } : c), 'autorização expirada'); return { ok: false, renovado: false, erro: 'sem refresh token' } }
  const r = await renovar(ref)
  if (r.ok) { const tok = await seal(r.t.access), rf = await seal(r.t.refresh); await gravarMp(bid, (c) => ({ ...c, mpTok: tok, mpRefresh: rf, mpExp: r.t.exp, mpStatus: 'conectado', mpErro: null, mpRenovadoEm: new Date().toISOString() }), 'token renovado'); return { ok: true, renovado: true } }
  // recusado: só marca erro se ninguém reconectou/renovou enquanto isso (a credencial ainda é a que foi usada)
  if (r.invalido) await gravarMp(bid, (c) => (c.mpRefresh === usado ? { ...c, mpStatus: 'erro', mpErro: 'O Mercado Pago não aceitou mais a autorização (revogada ou expirada). Conecte a conta novamente.' } : c), 'renovação recusada pelo Mercado Pago')
  return { ok: false, renovado: false, erro: r.erro }
}
/** Token da empresa para cobrar (renova antes de vencer). Vazio = sem conexão utilizável. */
export async function tokenLoja(b: any): Promise<string> {
  let d = await mpDe(Number(b.id)); if (!d.mpTok) return ''
  if (d.mpModo === 'oauth' && Number(d.mpExp) && Number(d.mpExp) - Date.now() < 30 * 86400_000 && d.mpRefresh) { await renovarLoja(b); d = await mpDe(Number(b.id)) }
  if (d.mpModo === 'oauth' && d.mpStatus === 'erro') return ''
  return unseal(d.mpTok).catch(() => '')
}
/** Pronto para cobrar online (conectado e sem erro). */
export async function mpPronto(bid: number): Promise<boolean> { const d = await mpDe(bid); return !!(d.mpTok && d.mpStatus !== 'erro') }
/** Confere a conexão na API oficial (/users/me); 401 tenta renovar uma vez; atualiza status e dados da conta. */
export async function verificarLoja(b: any): Promise<{ ok: boolean; mensagem: string }> {
  const bid = Number(b.id)
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    const d = await mpDe(bid), info = d.mpTok ? await (await import('../lib/settings.js')).unsealInfo(d.mpTok) : { ok: true, valor: '' }, tok = info.valor
    if (d.mpTok && !info.ok) return { ok: false, mensagem: 'A conexão está salva, mas a chave de criptografia do servidor mudou (APP_SECRET). Nada foi apagado: o administrador deve restaurar a chave anterior (APP_SECRET_ANTERIOR) e reiniciar.' }
    if (!tok) return { ok: false, mensagem: 'Nenhuma conta Mercado Pago conectada.' }
    let r: Response | null = null; try { r = await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${tok}` } }) } catch { r = null }
    if (!r) return { ok: false, mensagem: 'Sem conexão com o Mercado Pago agora. Tente de novo em instantes.' }
    const j: any = await r.json().catch(() => ({}))
    if (r.ok) {
      if (d.mpModo === 'oauth' && d.mpUserId && j.id && Number(j.id) !== Number(d.mpUserId)) { const e = 'A conta respondeu com outro usuário. Conecte novamente.'; await gravarMp(bid, (c) => (c.mpTok === d.mpTok ? { ...c, mpStatus: 'erro', mpErro: e } : c), 'verificação: outra conta'); return { ok: false, mensagem: e } }
      // manual conferida depois (estava pendente): só registra se a conta também recebe por empresa de outro dono (não bloqueia)
      if (d.mpModo !== 'oauth' && j.id && Number(d.mpUserId || d.mpConta?.id || 0) !== Number(j.id)) { const ow = await (await import('../db/index.js')).one('SELECT owner_id FROM businesses WHERE id = $1', [bid]); if (ow) await registrarContaCompartilhada(bid, Number(j.id), Number(ow.owner_id), Number(ow.owner_id)) }
      await gravarMp(bid, (c) => (c.mpTok === d.mpTok ? { ...c, mpStatus: 'conectado', mpErro: null, mpVerificadoEm: new Date().toISOString(), mpConta: contaDe(j, c.mpConta), mpUserId: c.mpModo === 'oauth' ? c.mpUserId : (Number(j.id) || c.mpUserId || null) } : c), 'verificação ok')
      return { ok: true, mensagem: `Conectado à conta ${j.nickname || mascara(j.email) || j.id}${/^TEST-/.test(tok) || d.mpTeste ? ' (ambiente de teste)' : ''}. Pronto para receber.` }
    }
    if ((r.status === 401 || r.status === 403) && d.mpModo === 'oauth' && tentativa === 0) { const rn = await renovarLoja(b, true); if (rn.ok) continue }
    if (r.status === 401 || r.status === 403) { const e = d.mpModo === 'oauth' ? 'O Mercado Pago recusou a autorização. Conecte a conta novamente.' : 'O Mercado Pago recusou o Access Token.'; await gravarMp(bid, (c) => (c.mpTok === d.mpTok ? { ...c, mpStatus: 'erro', mpErro: e } : c), 'verificação recusada'); return { ok: false, mensagem: e } }
    return { ok: false, mensagem: `O Mercado Pago respondeu ${r.status}. Tente de novo em instantes.` }
  }
  return { ok: false, mensagem: 'Não foi possível verificar agora.' }
}
const contaDe = (me: any, ant: any = {}) => ({ id: me.id ?? ant?.id ?? null, nickname: me.nickname || ant?.nickname || '', nome: [me.first_name, me.last_name].filter(Boolean).join(' ') || ant?.nome || '', email: mascara(me.email) || ant?.email || '', site: me.site_id || ant?.site || '' })
/** Renovação automática (agendador): empresas conectadas pelo OAuth com menos de 30 dias de validade. */
let ultimaRenovacao = 0
export async function renovarTodas(force = false) {
  if (!force && Date.now() - ultimaRenovacao < 6 * 3600_000) return { renovadas: 0, erros: 0 }
  ultimaRenovacao = Date.now()
  const { q } = await import('../db/index.js'), { J } = await import('../db/index.js'); let renovadas = 0, erros = 0
  await (await import('../lib/integracoes.js')).importarTodas().catch(() => 0)
  for (const r of await q("SELECT business_id, dados FROM empresa_integracoes WHERE provedor = 'mercadopago'")) {
    const d = J<any>((r as any).dados, {})
    if (d.mpTok && d.mpStatus === 'pendente') { await verificarLoja({ id: Number((r as any).business_id) }).catch(() => null); continue } // manual salva sem confirmação: confere na API
    if (d.mpModo !== 'oauth' || !d.mpTok || d.mpStatus === 'erro') continue
    if (Number(d.mpExp) && Number(d.mpExp) - Date.now() > 30 * 86400_000) continue
    const x = await renovarLoja({ id: Number((r as any).business_id) }); if (x.renovado) renovadas++; else if (!x.ok) erros++
  }
  return { renovadas, erros }
}
/** Desconectar (só por pedido explícito da empresa): apaga as credenciais desta empresa; a versão anterior fica no histórico. */
export function limparLoja(d: any) { for (const k of ['mpTok', 'mpSecret', 'mpRefresh', 'mpExp', 'mpUserId', 'mpConta', 'mpModo', 'mpStatus', 'mpErro', 'mpTeste', 'mpConectadoEm', 'mpRenovadoEm', 'mpVerificadoEm', 'mpUltimaFalha']) delete d[k]; return d }
type Conn = { access: string; refresh: string; userId: number | null; expiresAt: number; account: any; lastSyncAt?: string; status: string; test?: boolean }
const connOut = (c: Conn | null) => c ? { connected: c.status !== 'expired', status: c.status, account: c.account || null, lastSyncAt: c.lastSyncAt || null, syncPartial: false, test: !!c.test } : { connected: false, status: 'disconnected', account: null, lastSyncAt: null }
async function token(u: number): Promise<{ c: Conn; tok: string } | null> {
  const c = await getUM<Conn | null>(u, 'mp_user', null); if (!c) return null
  let tok = await unseal(c.access).catch(() => '')
  if (c.expiresAt && Date.now() > c.expiresAt - 86400_000 && c.refresh) { // renova antes de expirar
    const r = await renovar(await unseal(c.refresh).catch(() => ''))
    if (r.ok) { tok = r.t.access; c.access = await seal(r.t.access); c.refresh = await seal(r.t.refresh); c.expiresAt = r.t.exp; c.status = 'connected'; await setUM(u, 'mp_user', c) }
    else if (Date.now() > c.expiresAt || r.invalido) { c.status = 'expired'; await setUM(u, 'mp_user', c); return null }
  }
  return { c, tok }
}
const PER: Record<string, string> = { today: 'Hoje', yesterday: 'Ontem', last_7_days: 'Últimos 7 dias', this_week: 'Esta semana', this_month: 'Este mês', last_month: 'Mês passado', last_30_days: 'Últimos 30 dias', last_90_days: 'Últimos 90 dias', custom: 'Período escolhido' }
function range(period: string, from?: string, to?: string) {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), d0 = new Date(now); d0.setHours(0, 0, 0, 0)
  const day = 86400_000; let a = d0.getTime(), b = now.getTime()
  if (period === 'yesterday') { a -= day; b = d0.getTime() - 1 } else if (period === 'last_7_days') a -= 6 * day; else if (period === 'last_30_days') a -= 29 * day; else if (period === 'last_90_days') a -= 89 * day
  else if (period === 'this_week') a -= ((d0.getDay() + 6) % 7) * day; else if (period === 'this_month') a = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime()
  else if (period === 'last_month') { a = new Date(d0.getFullYear(), d0.getMonth() - 1, 1).getTime(); b = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime() - 1 }
  else if (period === 'custom' && from) { a = Date.parse(from + 'T00:00:00-03:00'); b = to ? Date.parse(to + 'T23:59:59-03:00') : b }
  const iso = (t: number) => new Date(t).toISOString().replace('Z', '-00:00')
  return { begin: iso(a), end: iso(b), label: PER[period] || PER.this_month }
}
const GROUP: Record<string, string> = { approved: 'approved', authorized: 'pending', pending: 'pending', in_process: 'pending', in_mediation: 'pending', rejected: 'rejected', cancelled: 'rejected', refunded: 'refunded', charged_back: 'refunded' }
const LABEL: Record<string, string> = { approved: 'Aprovado', authorized: 'Autorizado', pending: 'Pendente', in_process: 'Em análise', in_mediation: 'Em disputa', rejected: 'Recusado', cancelled: 'Cancelado', refunded: 'Reembolsado', charged_back: 'Estornado' }
export async function mpUserGet(ctx: Ctx) {
  const u = requireUser(ctx), q = ctx.query
  const t = await token(u.id)
  const base: any = { connection: connOut(t?.c || (await getUM<Conn | null>(u.id, 'mp_user', null))), balance: { reason: 'O Mercado Pago não disponibiliza o saldo da conta pela API para aplicações de terceiros. Consulte o saldo no app do Mercado Pago.' } }
  if (!t) return base
  const period = String(q.get('period') || 'this_month'), page = Math.max(1, Number(q.get('page')) || 1), status = String(q.get('status') || '')
  const r0 = range(period, q.get('from') || undefined, q.get('to') || undefined), limit = 30
  const url = `${API()}/v1/payments/search?sort=date_created&criteria=desc&range=date_created&begin_date=${encodeURIComponent(r0.begin)}&end_date=${encodeURIComponent(r0.end)}&limit=100&offset=0`
  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${t.tok}` } })
    if (r.status === 401) { t.c.status = 'expired'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c) } }
    const j: any = await r.json(); if (!r.ok) throw new Error(j.message || `Mercado Pago respondeu ${r.status}`)
    const all = (j.results || []).filter((p: any) => !t.c.userId || !p.collector_id || Number(p.collector_id) === Number(t.c.userId)) // só o que esta conta recebeu
    const sum = (f: (p: any) => boolean, k = 'transaction_amount') => Math.round(all.filter(f).reduce((a: number, p: any) => a + Number(p[k] || 0), 0) * 100) / 100
    const fees = (p: any) => (p.fee_details || []).reduce((a: number, f: any) => a + Number(f.amount || 0), 0)
    const appr = all.filter((p: any) => p.status === 'approved')
    const totals = { currency: 'BRL', gross: sum((p) => p.status === 'approved'), approvedCount: appr.length, fees: Math.round(appr.reduce((a: number, p: any) => a + fees(p), 0) * 100) / 100, net: 0, pendingCount: all.filter((p: any) => GROUP[p.status] === 'pending').length, pendingAmount: sum((p) => GROUP[p.status] === 'pending'), refundedCount: all.filter((p: any) => GROUP[p.status] === 'refunded').length, refundedAmount: sum((p) => GROUP[p.status] === 'refunded'), refundedPartial: Math.round(appr.reduce((a: number, p: any) => a + Number(p.transaction_amount_refunded || 0), 0) * 100) / 100, rejectedCount: all.filter((p: any) => GROUP[p.status] === 'rejected').length }
    totals.net = Math.round((totals.gross - totals.fees - totals.refundedPartial) * 100) / 100
    const list = all.filter((p: any) => !status || GROUP[p.status] === status)
    const payments = list.slice((page - 1) * limit, page * limit).map((p: any) => ({ id: String(p.id), description: p.description || '', paymentType: p.payment_type_id, method: p.payment_method_id, amount: Number(p.transaction_amount), currency: p.currency_id || 'BRL', feeTotal: Math.round(fees(p) * 100) / 100, net: Number(p.transaction_details?.net_received_amount ?? 0), status: p.status, statusLabel: LABEL[p.status] || p.status, statusDetail: p.status_detail, group: GROUP[p.status] || '', dateCreated: p.date_created, dateApproved: p.date_approved, payer: p.payer?.email ? { email: String(p.payer.email).replace(/^(.{2}).*(@.*)$/, '$1***$2') } : null, installments: p.installments, externalReference: p.external_reference || '' }))
    t.c.lastSyncAt = new Date().toISOString(); t.c.status = 'connected'; await setUM(u.id, 'mp_user', t.c)
    return { ...base, connection: connOut(t.c), period: { key: period, label: r0.label }, totals, payments, pages: Math.max(1, Math.ceil(list.length / limit)), page, truncated: (j.paging?.total || 0) > 100 }
  } catch (e: any) { t.c.status = 'error'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c), refreshError: String(e?.message || e).slice(0, 160) } }
}
export async function mpUserPost(ctx: Ctx) {
  const u = requireUser(ctx), a = String(ctx.body?.action || '')
  if (a === 'connect') {
    return { url: await autorizacao(u.id, null) }
  }
  if (a === 'disconnect') { await setUM(u.id, 'mp_user', null); return { connection: connOut(null) } }
  if (a === 'refresh' || a === 'sync') { const t = await token(u.id); return { connection: connOut(t?.c || null) } }
  fail(400, 'Ação inválida.', 'invalid')
}
/**
 * Volta do Mercado Pago (redirect_uri). Reconhece o pedido pelo state guardado no servidor (uso único, 15 min),
 * sem depender do cookie: no celular a autorização costuma voltar em outro navegador ou pelo app do Mercado Pago.
 * Troca o code por tokens no servidor, confere a conta (/users/me) e guarda tudo criptografado na empresa dona.
 */
export async function mpUserCallback(ctx: Ctx) {
  const { q, one } = await import('../db/index.js')
  const state = String(ctx.query.get('state') || '')
  const row = /^[a-f0-9]{32,64}$/.test(state) ? await one('SELECT * FROM mp_oauth_estados WHERE state = $1', [state]) : null
  const destino = (motivo: string, extra = '') => { const bid = row?.business_id ? Number(row.business_id) : 0; return bid ? `/x/sua-empresa?mp=${motivo === 'conectado' ? 'conectado' : 'erro'}${motivo === 'conectado' ? '' : '&motivo=' + motivo}&loja=${bid}${extra}` : `/financeiro?tab=mercadopago&mp=${motivo === 'conectado' ? 'conectado' : 'erro'}${motivo === 'conectado' ? '' : '&motivo=' + motivo}` }
  const go = (motivo: string, extra = '') => { ctx.res.writeHead(302, { Location: destino(motivo, extra), 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }); ctx.res.end(); return { _handled: true } }
  if (!row) return go('expirado')
  // uso único: marca antes de qualquer outra coisa (um segundo retorno com o mesmo state é recusado)
  await q('UPDATE mp_oauth_estados SET usado_em = $1 WHERE state = $2 AND usado_em IS NULL', [new Date().toISOString(), state])
  const marcado = await one('SELECT usado_em, criado_em FROM mp_oauth_estados WHERE state = $1', [state])
  if (row.usado_em || !marcado?.usado_em) return go('expirado')
  if (Date.now() - Date.parse(String(row.criado_em instanceof Date ? row.criado_em.toISOString() : row.criado_em)) > 15 * 60_000) return go('expirado')
  if (ctx.query.get('error')) return go(ctx.query.get('error') === 'access_denied' ? 'cancelado' : 'provedor')
  const userId = Number(row.user_id)
  if (ctx.user && Number(ctx.user.id) !== userId) return go('outra_sessao') // logado como outra pessoa neste navegador
  const code = String(ctx.query.get('code') || ''); if (!/^[\w.-]{1,300}$/.test(code)) return go('provedor')
  if (!(await appConfigured())) return go('nao_configurado')
  const bid = row.business_id ? Number(row.business_id) : 0
  let b: any = null
  if (bid) { b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [bid, userId]); if (!b) return go('empresa'); if (!(await planAllowed(b))) return go('plano') }
  const ap = await app(), verifier = row.verifier ? await unseal(row.verifier).catch(() => '') : ''
  const body: Record<string, string> = { grant_type: 'authorization_code', code, redirect_uri: redirectUri() }
  if (verifier) body.code_verifier = verifier
  if (ap.teste) body.test_token = 'true'
  const t = await tokenReq(body)
  if (!t.ok) { console.error('[mp-oauth] troca do código recusada:', t.status, t.erro); if (b) { const d = await mpDe(bid); if (d.mpTok) await gravarMp(bid, { mpUltimaFalha: { em: new Date().toISOString(), erro: t.erro } }, 'falha ao reconectar') } return go('provedor') }
  let me: any = {}; try { const r = await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${t.j.access_token}` } }); me = r.ok ? await r.json() : {} } catch { me = {} }
  const mpUserId = Number(t.j.user_id || me.id) || null
  const teste = ap.teste || /^TEST-/.test(t.j.access_token) || t.j.live_mode === false
  if (b) {
    // 25/11: a mesma conta Mercado Pago pode receber por empresas de donos diferentes (integração isolada por empresa); só registra
    await registrarContaCompartilhada(bid, mpUserId, Number(b.owner_id), userId)
    const d: any = {}
    Object.assign(d, { mpTok: await seal(t.j.access_token), mpRefresh: t.j.refresh_token ? await seal(t.j.refresh_token) : '', mpExp: Date.now() + (Number(t.j.expires_in) || 15552000) * 1000, mpUserId, mpModo: 'oauth', mpConta: contaDe({ ...me, id: me.id ?? mpUserId }), mpTeste: teste, mpStatus: 'conectado', mpErro: null, mpConectadoEm: new Date().toISOString(), mpRenovadoEm: null, mpVerificadoEm: me.id ? new Date().toISOString() : null })
    // conexão nova substitui a anterior inteira (a chave de webhook do modo manual não vale para a nova conta); a anterior fica no histórico
    await gravarMp(bid, () => d, 'conectado pelo Mercado Pago (OAuth)', true)
    await pagamentoOnline(bid, true)
    try { const { audit } = await import('../lib/account.js'); await audit(userId, 'mp.oauth.conectado', null, { business: bid, conta: mpUserId, teste }) } catch { /* auditoria é opcional */ }
    return go('conectado')
  }
  await setUM(userId, 'mp_user', { access: await seal(t.j.access_token), refresh: t.j.refresh_token ? await seal(t.j.refresh_token) : '', userId: mpUserId, expiresAt: Date.now() + (Number(t.j.expires_in) || 15552000) * 1000, account: { id: me.id || mpUserId, nickname: me.nickname || '', name: [me.first_name, me.last_name].filter(Boolean).join(' '), email: mascara(me.email) }, status: 'connected', test: teste })
  return go('conectado')
}
