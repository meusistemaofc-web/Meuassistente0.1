// Administração → Inteligência do Chat (Visão Geral e Diagnóstico e Auditoria): arquitetura de inteligência com estado REAL de cada componente,
// pipeline do chat, sobreposições auditadas, indicadores e rastreamento unificado das respostas (ai/orquestrador.ts).
// Somente leitura: nada aqui liga, desliga ou altera um módulo (isso continua nas telas de cada um).
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import * as O from '../ai/orquestrador.js'

const admin = (ctx: Ctx) => { const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden'); return u }

/** Mapa da arquitetura: componentes verificados agora, pipeline, sobreposições e indicadores do chat. */
export async function orquestracaoGet(ctx: Ctx) {
  admin(ctx)
  const [v, ind] = await Promise.all([O.verificarTudo(), O.indicadores().catch((e) => ({ erro: String(e?.message || e) }))])
  const cont: Record<string, number> = { ativo: 0, sem_uso: 0, desligado: 0, atencao: 0, falha: 0 }
  for (const c of v.componentes) cont[c.estado] = (cont[c.estado] || 0) + 1
  return { ...v, secoes: O.SECOES, areas: O.AREAS, contagem: cont, pipeline: O.PIPELINE, sobreposicoes: O.SOBREPOSICOES, indicadores: ind }
}

/** Rastros unificados das respostas do chat (filtros: via, so=falhas|ia|internas|acoes, limite). */
export async function orquestracaoRastrosGet(ctx: Ctx) {
  admin(ctx)
  const qy = { so: ctx.query.get('so') || '', via: ctx.query.get('via') || '', limite: ctx.query.get('limite') || '' }
  const so = ['falhas', 'ia', 'internas', 'acoes'].includes(String(qy.so)) ? (String(qy.so) as any) : undefined
  const via = /^[a-z_]{2,40}$/.test(String(qy.via || '')) ? String(qy.via) : undefined
  return { rastros: await O.rastros({ limite: Number(qy.limite) || 40, via, so }) }
}
