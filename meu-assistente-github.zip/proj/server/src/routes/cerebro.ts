// Cérebro Central — API. Tudo exige ADMINISTRADOR com a permissão "panel.manage" (ou o Administrador Principal),
// exceto as consultas de leitura (/api/brain/query, /knowledge, /categories, /status), que também aceitam um
// token de integração (Authorization: Bearer mab_…) gerado no painel — para aplicações conectadas.
// Toda alteração fica na auditoria (audit_log, ações "cerebro.*"). Nenhuma chave de API volta para o navegador.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'

const C = () => import('../ai/cerebro/central.js')
function admin(ctx: Ctx) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (!effectivePermissions(u).includes('panel.manage')) fail(403, 'Seu acesso de administrador não inclui o Cérebro Central. Peça ao Administrador Principal a permissão "Gerenciar o painel".', 'forbidden')
  return u
}
/** Leitura: administrador OU token de integração válido. */
async function leitor(ctx: Ctx): Promise<{ userId: number | null; via: 'admin' | 'token' }> {
  const h = String(ctx.req.headers.authorization || '')
  if (/^Bearer\s+mab_/i.test(h)) { if (!(await (await C()).tokenValido(h.replace(/^Bearer\s+/i, '').trim()))) fail(401, 'Token de integração inválido.', 'invalid_token'); return { userId: null, via: 'token' } }
  const u = admin(ctx); return { userId: u.id, via: 'admin' }
}
const b = (ctx: Ctx) => (ctx.body && typeof ctx.body === 'object' ? ctx.body : {}) as any
const id = (ctx: Ctx) => { const n = Number(ctx.params.id); if (!Number.isInteger(n) || n <= 0) fail(400, 'Identificador inválido.', 'invalid'); return n }
const quem = (u: { id: number; name?: string }) => `admin #${u.id}`

export const R: [string, string, (ctx: Ctx) => Promise<unknown>][] = [
  ['GET', '/api/brain/status', async (ctx) => { await leitor(ctx); return (await C()).status() }],
  ['GET', '/api/brain/categories', async (ctx) => { await leitor(ctx); return { categorias: await (await C()).categorias() } }],
  ['POST', '/api/brain/categories', async (ctx) => { const u = admin(ctx); const r = await (await C()).criarCategoria(b(ctx).nome, Number(b(ctx).pai) || undefined); await audit(u.id, 'cerebro.categoria', null, { nome: b(ctx).nome }); return { categorias: r } }],
  ['GET', '/api/brain/knowledge', async (ctx) => {
    const l = await leitor(ctx), qp = ctx.query
    const st = l.via === 'token' ? 'aprovado' : qp.get('status') || 'todos' // integrações só leem o que foi aprovado
    return (await C()).listar({ q: qp.get('q') || '', status: st, categoria: qp.get('categoria') || '', pagina: Number(qp.get('pagina')) || 1, porPagina: Number(qp.get('porPagina')) || 20 })
  }],
  ['GET', '/api/brain/knowledge/:id', async (ctx) => { const l = await leitor(ctx); const d = await (await C()).documento(id(ctx)); if (l.via === 'token' && d.status !== 'aprovado') fail(404, 'Conhecimento não encontrado.', 'not_found'); return d }],
  ['POST', '/api/brain/knowledge', async (ctx) => { const u = admin(ctx); const d = await (await C()).criarDocumento(b(ctx), quem(u)); await audit(u.id, 'cerebro.criar', d.id, { titulo: d.titulo }); return d }],
  ['PUT', '/api/brain/knowledge/:id', async (ctx) => { const u = admin(ctx); const d = await (await C()).editarDocumento(id(ctx), b(ctx), quem(u)); await audit(u.id, 'cerebro.editar', d.id, { versao: d.versao }); return d }],
  ['DELETE', '/api/brain/knowledge/:id', async (ctx) => { const u = admin(ctx); const r = await (await C()).excluirDocumento(id(ctx), quem(u)); await audit(u.id, 'cerebro.excluir', id(ctx), {}); return r }],
  ['POST', '/api/brain/knowledge/:id/review', async (ctx) => { const u = admin(ctx); const d = await (await C()).revisarDocumento(id(ctx), String(b(ctx).acao || ''), quem(u), String(b(ctx).nota || '')); await audit(u.id, 'cerebro.revisar', id(ctx), { acao: b(ctx).acao }); return d }],
  ['GET', '/api/brain/export', async (ctx) => { const u = admin(ctx); const e = await (await C()).exportar(); await audit(u.id, 'cerebro.exportar', null, { total: e.conhecimentos.length }); return e }],
  ['POST', '/api/brain/import', async (ctx) => { const u = admin(ctx); const r = await (await C()).importar(b(ctx), quem(u)); await audit(u.id, 'cerebro.importar', null, r); return r }],
  ['POST', '/api/brain/query', async (ctx) => {
    const l = await leitor(ctx), x = b(ctx)
    return (await C()).consultar(String(x.pergunta || ''), { modo: x.modo === 'biblioteca+internet' && l.via === 'admin' ? 'biblioteca+internet' : 'biblioteca', canal: l.via === 'token' ? 'api' : 'laboratorio', userId: l.userId, usarIA: x.usarIA !== false })
  }],
  ['POST', '/api/brain/compare', async (ctx) => {
    const u = admin(ctx), p = String(b(ctx).pergunta || ''), M = await C()
    const [so, com] = [await M.consultar(p, { modo: 'biblioteca', canal: 'laboratorio', userId: u.id, usarIA: b(ctx).usarIA !== false }), await M.consultar(p, { modo: 'biblioteca+internet', canal: 'laboratorio', userId: u.id, usarIA: b(ctx).usarIA !== false })]
    return { biblioteca: so, bibliotecaInternet: com }
  }],
  ['POST', '/api/brain/search', async (ctx) => {
    const u = admin(ctx), t = String(b(ctx).termo || '').trim(); if (t.length < 3) fail(400, 'Informe o que pesquisar.', 'invalid', 'termo')
    const passos: any[] = []; const r = await (await C()).pesquisarWeb(t, { passos, maxPaginas: Math.min(5, Number(b(ctx).paginas) || 3) })
    await audit(u.id, 'cerebro.pesquisar', null, { termo: t.slice(0, 120), paginas: r.extratos.length })
    return { termo: t, resultados: r.resultados.slice(0, 15), paginas: r.extratos.map((e) => ({ url: e.url, titulo: e.titulo, dominio: e.dominio, oficial: e.oficial, caracteres: e.texto.length, inicio: e.texto.slice(0, 600) })), erros: r.erros, passos }
  }],
  ['POST', '/api/brain/learn', async (ctx) => { const u = admin(ctx), x = b(ctx); const h = await (await C()).aprender(String(x.assunto || ''), { actor: quem(u), categoria: x.categoria || undefined, autoAprovar: typeof x.autoAprovar === 'boolean' ? x.autoAprovar : undefined, atualizarId: Number(x.atualizar) || undefined }); await audit(u.id, 'cerebro.estudar', h, { assunto: String(x.assunto).slice(0, 120) }); return { estudo: h } }],
  ['GET', '/api/brain/learn', async (ctx) => { admin(ctx); return { estudos: await (await C()).historico() } }],
  ['GET', '/api/brain/learn/:id', async (ctx) => { admin(ctx); return (await C()).historico(id(ctx)) }],
  ['GET', '/api/brain/jobs', async (ctx) => { admin(ctx); return { tarefas: await (await C()).tarefas() } }],
  ['POST', '/api/brain/jobs', async (ctx) => { const u = admin(ctx); const t = await (await C()).salvarTarefa(b(ctx), quem(u)); await audit(u.id, 'cerebro.tarefa', t.id, { assunto: t.assunto, modo: t.modo }); return t }],
  ['PUT', '/api/brain/jobs/:id', async (ctx) => { const u = admin(ctx); const t = await (await C()).salvarTarefa(b(ctx), quem(u), id(ctx)); await audit(u.id, 'cerebro.tarefa', t.id, b(ctx)); return t }],
  ['DELETE', '/api/brain/jobs/:id', async (ctx) => { const u = admin(ctx); await audit(u.id, 'cerebro.tarefa_excluir', id(ctx), {}); return (await C()).excluirTarefa(id(ctx)) }],
  ['POST', '/api/brain/jobs/:id/run', async (ctx) => { const u = admin(ctx); const h = await (await C()).executarTarefa(id(ctx), quem(u)); await audit(u.id, 'cerebro.tarefa_executar', id(ctx), { estudo: h }); return { estudo: h } }],
  ['GET', '/api/brain/sources', async (ctx) => { admin(ctx); return { fontes: await (await C()).fontes({ q: ctx.query.get('q') || '' }) } }],
  ['POST', '/api/brain/sources', async (ctx) => { const u = admin(ctx); const f = await (await C()).salvarFonte(b(ctx), quem(u)); await audit(u.id, 'cerebro.fonte', f.id, { url: f.url, confianca: f.confianca }); return f }],
  ['PUT', '/api/brain/sources/:id', async (ctx) => { const u = admin(ctx); const f = await (await C()).salvarFonte(b(ctx), quem(u), id(ctx)); await audit(u.id, 'cerebro.fonte', f.id, { confianca: f.confianca }); return f }],
  ['GET', '/api/brain/providers', async (ctx) => { admin(ctx); return { provedores: await (await C()).provedores() } }],
  ['PUT', '/api/brain/providers/:id', async (ctx) => { const u = admin(ctx); const x = b(ctx); const p = await (await C()).salvarProvedor(id(ctx), x); await audit(u.id, 'cerebro.provedor', id(ctx), { ...x, chave: x.chave !== undefined ? (x.chave ? '(alterada)' : '(removida)') : undefined }); return p }],
  ['POST', '/api/brain/providers/:id/test', async (ctx) => { const u = admin(ctx); const r = await (await C()).testarProvedor(id(ctx)); await audit(u.id, 'cerebro.provedor_teste', id(ctx), r); return r }],
  ['GET', '/api/brain/settings', async (ctx) => { admin(ctx); const M = await C(); return { ...M.publicoCfg(await M.cfg()), internetGlobal: await (await import('../ai/bloqueio-pesquisa.js')).internetPermitida(true) } }],
  ['PUT', '/api/brain/settings', async (ctx) => { const u = admin(ctx); const r = await (await C()).salvarCfg(b(ctx)); await audit(u.id, 'cerebro.configuracoes', null, b(ctx)); return r }],
  ['POST', '/api/brain/token', async (ctx) => { const u = admin(ctx); const M = await C(); if (b(ctx).revogar) { await M.revogarToken(); await audit(u.id, 'cerebro.token_revogado', null, {}); return { ok: true } } const t = await M.gerarToken(); await audit(u.id, 'cerebro.token_gerado', null, {}); return { token: t, aviso: 'Guarde agora: o token não será mostrado de novo.' } }],
  ['POST', '/api/brain/reindex', async (ctx) => { const u = admin(ctx); const r = await (await C()).reindexar(); await audit(u.id, 'cerebro.reindexar', null, r); return r }],
  ['GET', '/api/brain/logs', async (ctx) => { admin(ctx); return { consultas: await (await C()).registros() } }],
  // integração com o chat: rastreamento de cada resposta e indicadores de uso REAL do conhecimento
  ['GET', '/api/brain/chat/indicadores', async (ctx) => { admin(ctx); return (await import('../ai/cerebro/integracao.js')).indicadores(Number(ctx.query.get('dias')) || 30) }],
  ['GET', '/api/brain/chat/rastros', async (ctx) => { admin(ctx); const qp = ctx.query, u = qp.get('usou'); return { rastros: await (await import('../ai/cerebro/integracao.js')).rastros({ limite: Number(qp.get('limite')) || 100, canal: qp.get('canal') || '', usou: u === '1' ? true : u === '0' ? false : undefined }) } }],
]
