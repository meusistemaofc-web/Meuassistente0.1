// Rotas das cobranças criadas pelo chat (lib/cobrancas.ts). Nenhuma rota devolve credenciais do Mercado Pago.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { one } from '../db/index.js'
import { requireUser } from '../lib/session.js'

/** Cartão no chat (quem criou ou o dono da empresa): status atualizado na API do Mercado Pago. */
export async function cobrancaGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id); if (!Number.isInteger(id) || id <= 0) fail(404, 'Cobrança não encontrada.', 'not_found')
  const C = await import('../lib/cobrancas.js')
  const c0 = await one('SELECT c.* FROM cobrancas c JOIN businesses b ON b.id = c.business_id WHERE c.id = $1 AND (c.created_by = $2 OR b.owner_id = $2)', [id, u.id])
  if (!c0) fail(404, 'Cobrança não encontrada.', 'not_found')
  const c = await C.atualizar(c0, ctx.query.get('atualizar') === '1'), b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [c.business_id])
  return C.visao(c, b, true)
}
/** Página pública do link compartilhado (quem vai pagar): QR Code, Copia e Cola e status. Sem login, sem dados internos. */
export async function cobrancaPublicaGet(ctx: Ctx) {
  const t = String(ctx.params.token || ''); if (!/^[A-Za-z0-9_-]{16,40}$/.test(t)) fail(404, 'Cobrança não encontrada.', 'not_found')
  const C = await import('../lib/cobrancas.js'), c0 = await one('SELECT * FROM cobrancas WHERE link_token = $1', [t])
  if (!c0 || ['criando', 'falhou'].includes(c0.status)) fail(404, 'Cobrança não encontrada.', 'not_found')
  const c = await C.atualizar(c0), b = await one('SELECT id, owner_id, data FROM businesses WHERE id = $1', [c.business_id])
  return C.visao(c, b, false)
}
