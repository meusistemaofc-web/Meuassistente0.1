// Aprendizados do usuário (Motor de Aprendizagem Adaptativa): cada pessoa revisa, corrige, pausa e exclui os SEUS aprendizados.
// O administrador só vê números agregados e sugestões anônimas; promover uma sugestão cria apenas um RASCUNHO no Laboratório de IA.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import { getConfig, setConfig } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import * as A from '../ai/adaptive.js'

export async function learningGet(ctx: Ctx) {
  const u = requireUser(ctx)
  return { ativo: await A.globalOn(), memoriaLigada: u.memory_settings?.enabled !== false, global: await A.globalOn(), itens: await A.listar(u.id) }
}
export async function learningPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  switch (b.action) {
    case 'update': {
      const r = await A.atualizar(u.id, Number(b.id), { regra: b.regra !== undefined ? str(b.regra, 200) : undefined, estado: b.estado })
      if (!r) fail(400, 'Não foi possível alterar este item (texto vazio, não permitido ou não encontrado).', 'invalid')
      await audit(u.id, 'aprendizado.update', r.id, {}); return { ok: true, item: r }
    }
    case 'delete': await A.excluir(u.id, Number(b.id)); await audit(u.id, 'aprendizado.delete', Number(b.id), {}); return { ok: true }
    case 'delete_all': await A.excluirTodos(u.id); await audit(u.id, 'aprendizado.delete_all', null, {}); return { ok: true }
    case 'settings': fail(403, 'Aprendizados é controlado somente pelo administrador.', 'forbidden') // não há ativação individual
    // eslint-disable-next-line no-fallthrough
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}

const admin = (ctx: Ctx, write = false) => {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
export async function panelLearningGet(ctx: Ctx) { admin(ctx); return A.resumoAdmin() }
export async function panelLearningPut(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}
  if (b.action === 'promover') {
    const id = await A.promoverParaLaboratorio(u.id, String(b.operacao || ''), String(b.kind || ''))
    if (!id) fail(404, 'Sugestão não encontrada.', 'not_found')
    await audit(u.id, 'aprendizado.promover_laboratorio', Number(id), { operacao: b.operacao, kind: b.kind }); return { ok: true, propostaId: id }
  }
  if (typeof b.ativo !== 'boolean') fail(400, 'Informe ativo: true ou false.', 'invalid', 'ativo')
  const antes = await A.estadoGlobal(), ativo = b.ativo as boolean
  await setConfig('adaptive', { ...(await getConfig<Record<string, unknown>>('adaptive', {})), ativo, atualizadoEm: new Date().toISOString(), atualizadoPor: u.id, atualizadoPorNome: u.name || u.email || '' })
  await audit(u.id, 'aprendizagem.chave', null, { de: antes.ativo, para: ativo }); return { ok: true, ...(await A.estadoGlobal()) }
}

export async function panelLearningFila(ctx: Ctx) {
  admin(ctx); const g = (k: string, n: number) => str(ctx.query.get(k), n)
  return { itens: await A.filaRevisao({ status: g('status', 20), usuario: g('usuario', 80), operacao: g('operacao', 30), busca: g('busca', 80), tipo: g('tipo', 20) }), revisao: await A.contagemRevisao() }
}
export async function panelLearningRevisar(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, id = Number(ctx.params?.id)
  if (!['aprovar', 'rejeitar', 'editar', 'reabrir'].includes(b.action)) fail(400, 'Ação inválida.', 'invalid', 'action')
  const r = await A.revisar(u.id, id, b.action, { regra: b.regra, nota: b.nota })
  if (r === null) fail(404, 'Aprendizado não encontrado.', 'not_found')
  if (r === 'invalido') fail(400, 'Regra vazia, inalterada ou não permitida (não é possível afrouxar segurança, permissões ou validações).', 'invalid', 'regra')
  await audit(u.id, 'aprendizado.revisao.' + b.action, id, { usuario: r.usuarioId, regra: r.regra })
  if (b.action === 'rejeitar' || b.action === 'editar') await notify(r.usuarioId, { type: 'aprendizado', title: 'Preferência revisada', body: b.action === 'rejeitar' ? 'Uma preferência aprendida foi desativada pela administração.' : 'Uma preferência aprendida foi ajustada pela administração.', link: '/', ref: 'aprendizado:' + id + ':' + Date.now() }).catch((e) => console.error('notify', e))
  return { ok: true, item: r }
}
