// Rotas da página "Descobrir" (lib/descobrir.ts): configuração pública, banners, recomendações e interações;
// e a área do painel (Plataforma e Negócio → Descobrir). Sem módulos novos de vitrine: tudo reaproveita routes/businesses.ts.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { audit } from '../lib/account.js'
import * as D from '../lib/descobrir.js'

/* ---------- público ---------- */
export async function configGet(_ctx: Ctx) {
  const c = await D.cfg()
  return { modos: D.modosAtivos(c), banners: await D.bannersPublicos(c), personalizacao: c.personalizacao, recomendacoes: c.recomendacoes }
}
export async function bannerImagemGet(ctx: Ctx) {
  const img = await D.imagemBanner(Number(ctx.params.id)); if (!img) fail(404, 'Imagem não encontrada.', 'not_found')
  return { _binary: true, mime: img!.tipo, data: img!.buf, headers: { 'Cache-Control': 'public, max-age=86400' } }
}
// coleta de interações: em lote (a tela junta os eventos e envia de tempos em tempos); só do próprio usuário logado
const janela = new Map<number, { t: number; n: number }>()
export async function interacoesPost(ctx: Ctx) {
  const u = ctx.user; if (!u) return { ok: true, ignorado: true } // visitante: nada é guardado
  const evs = Array.isArray(ctx.body?.eventos) ? ctx.body.eventos.slice(0, 40) : []
  const now = Date.now(), j = janela.get(u.id) && now - janela.get(u.id)!.t < 60_000 ? janela.get(u.id)! : { t: now, n: 0 }
  if (j.n > 200) return { ok: true, limitado: true }
  j.n += evs.length; janela.set(u.id, j); if (janela.size > 20000) janela.clear()
  return { ok: true, chaves: await D.registrar(u.id, evs) }
}
export async function interacoesDelete(ctx: Ctx) { const u = ctx.user; if (!u) fail(401, 'Entre na sua conta.', 'login'); await D.limpar(u!.id); return { ok: true } }
/** "Recomendado para você" (ou "Destaques perto de você" para quem ainda não interagiu): diversidade + rodízio diário. */
export async function recomendadosGet(ctx: Ctx) {
  const c = await D.cfg(), modo = String(ctx.query.get('modo') || 'produtos') as D.Modo
  if (!D.MODOS.includes(modo)) fail(400, 'Modo inválido.', 'invalid')
  await D.exigirModo(modo)
  if (!c.recomendacoes) return { items: [], titulo: '', personalizado: false }
  const B = await import('./businesses.js'), uid = ctx.user?.id || null, pf = await D.perfil(uid)
  const qp = new URLSearchParams(ctx.query); for (const k of ['q', 'categoria', 'ofertas']) qp.delete(k)
  qp.set('pagina', '1'); qp.set('por', modo === 'empresas' ? '30' : '40'); qp.set('ordem', 'relevancia')
  const sub = { ...ctx, query: qp } as Ctx
  const r: any = modo === 'empresas' ? await B.businessSearchGet(sub) : await B.vitrineItens(sub, modo)
  if (r.needLocation) return { needLocation: true, items: [], titulo: '', personalizado: false }
  const lista: any[] = r.items || [], k = modo === 'empresas' ? 'e' : modo === 'servicos' ? 's' : 'p'
  const cands = lista.map((it: any, i: number) => {
    const bid = modo === 'empresas' ? Number(it.id) : Number(it.empresa?.id), chave = `${k}:${it.id}`
    const visto = pf.n.get(chave) || 0 // já muito visto pela pessoa: desce um pouco, para não repetir sempre os mesmos
    return { ...it, _s: (1 - i / Math.max(1, lista.length)) + D.jitter(uid, Number(it.id)) * 0.3 - (visto >= 5 ? 0.35 : 0), _bid: bid, _cat: String(it.categoria || ''), _novo: !pf.w.has(chave) && !pf.w.has('e:' + bid) }
  }).sort((a, b) => b._s - a._s)
  const items = D.diversificar(cands, 8).map(({ _s, _bid, _cat, _novo, ...x }: any) => x)
  return { items: items.length >= 3 ? items : [], titulo: pf.vazio ? 'Destaques perto de você' : 'Recomendado para você', personalizado: !pf.vazio }
}

/* ---------- painel (Plataforma e Negócio → Descobrir) ---------- */
const P = () => import('./panel.js')
export async function painelGet(ctx: Ctx) {
  await (await P()).requirePanel(ctx)
  const { one } = await import('../db/index.js')
  const pessoas = await one('SELECT COUNT(DISTINCT user_id) AS n, COUNT(*) AS k FROM user_interests')
  return { config: await D.cfg(), banners: await D.bannersAdmin(), personalizacao: { usuarios: Number(pessoas?.n || 0), interesses: Number(pessoas?.k || 0) } }
}
export async function painelPut(ctx: Ctx) { const u = await (await P()).requirePanel(ctx, true); const c = await D.salvarCfg(ctx.body || {}); await audit(u.id, 'descobrir.config', null, c); return { config: c } }
export async function bannerPost(ctx: Ctx) { const u = await (await P()).requirePanel(ctx, true); const b = await D.salvarBanner(null, ctx.body || {}); await audit(u.id, 'descobrir.banner_criar', b.id, { titulo: b.titulo }); return b }
export async function bannerPut(ctx: Ctx) { const u = await (await P()).requirePanel(ctx, true); const b = await D.salvarBanner(Number(ctx.params.id), ctx.body || {}); await audit(u.id, 'descobrir.banner_editar', b.id, { titulo: b.titulo, ativo: b.ativo }); return b }
export async function bannerDelete(ctx: Ctx) { const u = await (await P()).requirePanel(ctx, true); await D.excluirBanner(Number(ctx.params.id)); await audit(u.id, 'descobrir.banner_excluir', Number(ctx.params.id), {}); return { ok: true } }
