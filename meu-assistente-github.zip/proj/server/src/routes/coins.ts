// MCoins: painel do administrador, Mercado, carteira do cliente e consulta no checkout.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { audit, effectivePermissions } from '../lib/account.js'
import * as C from '../lib/coins.js'
import * as H from '../lib/coin-hub.js'
import * as D from '../lib/coin-dist.js'
import * as Z from '../lib/coin-central.js'
import * as MK from '../lib/coin-market.js'
import { buscar as buscarCodigo } from '../lib/coin-code.js'
import { ownBusiness } from './businesses.js'

function admin(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
const nm = (u: any) => `admin ${u.id}`

/** Painel: configuração, modelos, moedas (com números e relatório por empresa) e empresas disponíveis. */
export async function panelCoinsGet(ctx: Ctx) {
  admin(ctx)
  const moedas = await Promise.all((await C.listCoins()).map((c) => C.stats(c.id)))
  const emp = (await q("SELECT id, data, status FROM businesses WHERE status <> 'institucional' ORDER BY id DESC LIMIT 500")).map((b: any) => ({ id: Number(b.id), empresa: J<any>(b.data, {}).empresa || `Empresa #${b.id}`, status: b.status, temMoeda: moedas.some((m) => m.businessId === Number(b.id)) }))
  const iid = await H.institucionalId()
  return { config: await C.coinsCfg(), modelos: C.MODELOS, moedas, empresas: emp, institucional: { nome: H.NOME_INSTITUCIONAL, criada: !!iid, empresaId: iid, temMoeda: !!iid && moedas.some((m) => m.businessId === iid) },
    resumo: { moedas: moedas.length, ativas: moedas.filter((m) => m.status === 'ativa').length, distribuidas: moedas.reduce((a, m) => a + m.distribuidas, 0), emitidas: moedas.reduce((a, m) => a + m.total, 0), percentualDistribuido: C.pctDistribuido(moedas.reduce((a, m) => a + m.distribuidas, 0), moedas.reduce((a, m) => a + m.total, 0)), utilizadas: moedas.reduce((a, m) => a + m.utilizadas, 0), descontoReais: Math.round(moedas.reduce((a, m) => a + m.descontoConcedidoReais, 0) * 100) / 100 } }
}
export async function panelCoinGet(ctx: Ctx) {
  admin(ctx); const id = Number(ctx.params.id), c = await C.coinById(id); if (!c) fail(404, 'Moeda não encontrada.', 'not_found')
  return { moeda: await C.stats(id), serie: await C.series(id, Math.min(180, Math.max(7, Number(ctx.query.get('dias')) || 30))), historico: await C.ledger(id), saldos: await C.topBalances(id), alteracoes: await C.changes(id) }
}
export async function panelCoinsPost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}, actor = nm(u)
  switch (b.action) {
    case 'config': { const cfg = await C.saveCoinsCfg(b); await audit(u.id, 'coins.config', null, { ativo: cfg.ativo, adesao: cfg.adesao.ativo }); return { ok: true, config: cfg } }
    case 'link_criar': { const r = await H.criarVinculos(Number(b.coinId ?? b.id), b.empresas === 'todas' ? 'todas' : (Array.isArray(b.empresas) ? b.empresas.map(Number) : []), b, actor, u.id); await audit(u.id, 'coins.vinculo.criar', Number(b.coinId ?? b.id), { criados: r.criados.length, auto: b.aceiteAutomatico === true }); return { ok: true, ...r } }
    case 'link_ajustar': { const v = await H.ajustarVinculo(Number(b.id), b, actor); await audit(u.id, 'coins.vinculo.ajustar', v.id, { status: v.status }); return { ok: true, vinculo: v } }
    case 'create': { const c = await C.createCoin(b, actor, u.id); await audit(u.id, 'coins.create', c.id, { empresa: c.businessId }); return { ok: true, moeda: c } }
    case 'update': { const c = await C.updateCoin(Number(b.id), b, actor); await audit(u.id, 'coins.update', c.id, {}); return { ok: true, moeda: c } }
    case 'status': { const c = await C.setStatus(Number(b.id), String(b.status), actor); await audit(u.id, 'coins.status', c.id, { status: c.status }); return { ok: true, moeda: c } }
    case 'distribuir': {
      const email = String(b.email || '').trim().toLowerCase(), cli = await one('SELECT id FROM users WHERE LOWER(email) = $1', [email]); if (!cli) fail(404, 'Nenhum cliente com este e-mail.', 'not_found', 'email')
      const idem = String(b.idem || '').trim().slice(0, 60); if (!idem) fail(400, 'Informe uma chave da operação para evitar distribuição em duplicidade.', 'invalid', 'idem')
      const r = await C.distribuir(Number(b.id), Number(cli!.id), Math.floor(Number(b.quantidade)), 'admin:' + idem, u.id, String(b.nota || '').slice(0, 200))
      await audit(u.id, 'coins.distribuir', Number(b.id), { cliente: Number(cli!.id), quantidade: r.quantidade, duplicado: r.duplicado }); return { ...r }
    }
    case 'enviar_previa': return D.previa(b)
    case 'enviar': return D.enviar({ id: u.id, name: u.name }, b)
    default: fail(400, 'Ação inválida.', 'invalid')
  }
}
/** Enviar MCoins (admin): pesquisa de usuários e histórico das distribuições. */
export async function panelCoinSendUsersGet(ctx: Ctx) { admin(ctx, true); return D.buscarUsuarios({ q: ctx.query.get('q') || '' }, Number(ctx.query.get('limit')) || 30, Number(ctx.query.get('offset')) || 0) }
export async function panelCoinDistributionsGet(ctx: Ctx) { admin(ctx); return { operacoes: await D.historico(Number(ctx.query.get('limit')) || 100, Number(ctx.query.get('moeda')) || undefined) } }
export async function panelCoinDistributionGet(ctx: Ctx) { admin(ctx); return D.detalhe(Number(ctx.params.id)) }
/** Usuário: créditos novos (para comemorar uma vez) e confirmação de leitura. */
export async function coinsNewGet(ctx: Ctx) { const u = requireUser(ctx); return { novas: await D.novas(u.id) } }
export async function coinsNewSeenPost(ctx: Ctx) { const u = requireUser(ctx); return D.marcarVistas(u.id, ctx.body?.ids) }

/** Mercado: moedas publicadas, só quando o sistema está ligado e existe ao menos uma. */
export async function coinsMarketGet(ctx: Ctx) {
  requireUser(ctx)
  const cfg = await C.coinsCfg(); if (!cfg.ativo) return { visivel: false, itens: [] }
  const l = await C.listCoins(true); if (!l.length) return { visivel: false, itens: [] }
  const itens = await Promise.all(l.map(async (c) => { const st: any = await C.stats(c.id), mk = await MK.resumoListagem(c.id)
    // moeda com mercado habilitado: cotação e variação das negociações; as demais seguem como crédito promocional (valor de referência)
    if (mk) return { ...st, valorReferencia: mk.preco, variacao24h: mk.variacao24h, serie: mk.serie, negociavel: true, pausado: mk.pausado }
    return { ...st, variacao24h: await C.variacao24h(c.id, Number(st.valorReferencia) || 0), serie: (await C.series(c.id, 30)).map((p) => p.acumDistribuido), negociavel: false } }))
  return { visivel: true, itens }
}
export async function coinPublicGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.params.id), c: any = await C.coinById(id), cfg = await C.coinsCfg()
  if (!c || !cfg.ativo || c.status !== 'ativa') fail(404, 'Moeda indisponível.', 'not_found')
  const hist = (await C.ledger(id, 30)).map((h) => ({ tipo: h.tipo, quantidade: h.quantidade, em: h.em })) // sem dados de clientes
  return { moeda: await C.stats(id), serie: await C.series(id, 30), recentes: hist, meuSaldo: await C.balanceOf(id, u.id), regras: `1 ${c.simbolo} = R$ ${c.desconto.toFixed(2).replace('.', ',')} de desconto em compras na empresa ${c.empresa}. Crédito promocional: não é negociável, transferível nem sacável.` }
}
export async function coinsWalletGet(ctx: Ctx) { const u = requireUser(ctx); return { ativo: (await C.coinsCfg()).ativo, mercado: await MK.carteira(u.id), ...(await C.wallet(u.id)), central: await Z.capacidades(u.id) } }
/* ---------- Central de controle e comercialização (tudo validado no servidor) ---------- */
export async function panelCentralGet(ctx: Ctx) { admin(ctx); return Z.visao() }
export async function panelCentralPost(ctx: Ctx) {
  const u = admin(ctx, true), b = ctx.body || {}
  switch (b.action) {
    case 'config': return { ok: true, ...(await Z.saveCentral(b, u.id)) }
    case 'politica': return { ok: true, politica: await Z.salvarPolitica(Number(b.moedaId), b, u.id) }
    case 'permissao': return { ok: true, ...(await Z.definirPermissao(b, u.id)) }
    case 'grupo_criar': return { ok: true, grupo: await Z.criarGrupo(b.nome, b.descricao, u.id) }
    case 'grupo_membros': await Z.alterarMembros(Number(b.id), b.adicionar, b.remover, u.id); return { ok: true }
    case 'grupo_excluir': await Z.excluirGrupo(Number(b.id), u.id); return { ok: true }
    case 'pedido': return { ok: true, pedido: await Z.resolverPedido(Number(b.id), String(b.acao || ''), b.nota, u.id) }
    default: fail(400, 'Ação desconhecida.', 'invalid')
  }
}
export async function panelCentralPermissoesGet(ctx: Ctx) { admin(ctx); return Z.listarPermissoes({ q: ctx.query.get('q') || '', moedaId: Number(ctx.query.get('moeda')) || 0, limit: Number(ctx.query.get('limit')) || 30, offset: Number(ctx.query.get('offset')) || 0 }) }
export async function panelCentralGrupoGet(ctx: Ctx) { admin(ctx); return { membros: await Z.membrosGrupo(Number(ctx.params.id)) } }
export async function panelCentralPedidosGet(ctx: Ctx) { admin(ctx); return { pedidos: await Z.pedidosAdmin(ctx.query.get('status') || undefined), transferencias: await Z.transferenciasAdmin() } }
export async function panelCoinCodigoGet(ctx: Ctx) { admin(ctx); return { resultados: await buscarCodigo(ctx.query.get('q') || '') } }
export async function coinsCapacidadesGet(ctx: Ctx) { const u = requireUser(ctx); return Z.capacidades(u.id) }
export async function coinsOrdersGet(ctx: Ctx) { const u = requireUser(ctx); return Z.meusPedidos(u.id) }
export async function coinsBuyPost(ctx: Ctx) { const u = requireUser(ctx); return Z.negociar('compra', u, ctx.body || {}) }
export async function coinsSellPost(ctx: Ctx) { const u = requireUser(ctx); return Z.negociar('venda', u, ctx.body || {}) }
export async function coinsTransferPost(ctx: Ctx) { const u = requireUser(ctx); return Z.transferir(u, ctx.body || {}) }
export async function coinsOrderCancelPost(ctx: Ctx) { const u = requireUser(ctx); return { ok: true, pedido: await Z.cancelarPedido(u.id, Number(ctx.params.id)) } }
/** Checkout: a moeda da empresa e o saldo do cliente. */
export async function businessCoinGet(ctx: Ctx) {
  const u = requireUser(ctx), cfg = await C.coinsCfg(), c = await C.coinOfBusiness(Number(ctx.params.id))
  const aceitas = await Promise.all((await H.aceitas(Number(ctx.params.id))).map(async (a) => ({ id: a.coin.id, nome: a.coin.nome, simbolo: a.coin.simbolo, desconto: a.desconto, modelo: a.coin.modeloInfo, cor1: a.coin.cor1, cor2: a.coin.cor2, logo: a.coin.logo, emissora: a.coin.empresa, maxPct: a.maxPct, minCompra: a.minCompra, regras: a.regras, saldo: await C.balanceOf(a.coin.id, u.id) })))
  if (!cfg.ativo || !c || c.status !== 'ativa') return { moeda: null, aceitas }
  return { moeda: { id: c.id, nome: c.nome, simbolo: c.simbolo, desconto: c.desconto, modelo: c.modeloInfo, cor1: c.cor1, cor2: c.cor2, logo: c.logo }, saldo: await C.balanceOf(c.id, u.id), aceitas }
}

/** Painel: gestão central do Meu Assistente (emissão, vínculos, distribuição e movimentações com emissora e vinculada). */
export async function panelCoinsHubGet(ctx: Ctx) { admin(ctx); return H.resumo() }
export async function panelCoinLinkEventsGet(ctx: Ctx) { admin(ctx); return { eventos: await H.eventosDoVinculo(Number(ctx.params.id)) } }
/** Dono da empresa: vínculos recebidos e a resposta (aceitar, recusar, pausar, retomar). */
export async function businessMcoinsGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { sistemaLigado: (await C.coinsCfg()).ativo, vinculos: await H.vinculosDaEmpresa(Number(b.id)) } }
export async function businessMcoinsPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), body = ctx.body || {}, lid = Number(body.vinculo)
  const mine = await H.vinculosDaEmpresa(Number(b.id)); if (!mine.some((v) => v.id === lid)) fail(404, 'Vínculo não encontrado.', 'not_found')
  const v = await H.responder(u.id, lid, String(body.acao || '')); await audit(u.id, 'coins.vinculo.' + String(body.acao), lid, { empresa: Number(b.id) })
  return { ok: true, vinculo: v, vinculos: await H.vinculosDaEmpresa(Number(b.id)) }
}

/* ---------- Sua empresa > Ajustes > MCoins: painel de CONSULTA do proprietário ----------
   Só existe quando o administrador criou uma moeda para a empresa (moeda própria) ou vinculou uma moeda a ela
   (vínculo que não foi revogado). Criação e gestão das moedas continuam só no painel administrativo; aqui o dono
   acompanha números, histórico e regras (e responde aos vínculos, como antes). Nada é calculado "de mentira":
   tudo sai de coins, coin_links e coin_ledger. Dados pessoais de clientes (nome, e-mail, saldo) não são expostos. */
/** empresaTemMcoins para várias empresas de uma vez (2 consultas no total, em vez de 2 por empresa). */
export async function empresasComMcoins(ids: number[]): Promise<Set<number>> {
  const u = [...new Set(ids.filter((x) => x > 0))], out = new Set<number>(); if (!u.length) return out
  const ph = u.map((_, i) => '$' + (i + 1)).join(',')
  for (const r of await q(`SELECT DISTINCT business_id FROM coins WHERE business_id IN (${ph})`, u)) out.add(Number((r as any).business_id))
  for (const r of await q(`SELECT DISTINCT business_id FROM coin_links WHERE status <> 'revogado' AND business_id IN (${ph})`, u)) out.add(Number((r as any).business_id))
  return out
}
export async function empresaTemMcoins(businessId: number) {
  if (await one('SELECT 1 AS x FROM coins WHERE business_id = $1', [businessId])) return true
  return !!(await one("SELECT 1 AS x FROM coin_links WHERE business_id = $1 AND status <> 'revogado'", [businessId]))
}
const nInt = (v: any) => Math.round(Number(v) || 0)
export async function businessMcoinsPainelGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx); const bid = Number(b.id), cfg = await C.coinsCfg()
  const brl = (n: number) => `R$ ${Number(n || 0).toFixed(2).replace('.', ',')}`
  const moedas: any[] = []
  const propria: any = await C.coinOfBusiness(bid)
  if (propria) {
    const st: any = await C.stats(propria.id)
    const porTipo = await q('SELECT kind, COUNT(*) AS n, COALESCE(SUM(delta),0) AS d FROM coin_ledger WHERE coin_id = $1 GROUP BY kind', [propria.id])
    const k = (t: string) => { const r: any = (porTipo as any[]).find((x) => x.kind === t); return { vezes: nInt(r?.n), moedas: Math.abs(nInt(r?.d)) } }
    const hist = (await C.ledger(propria.id, 60)).map((h: any) => ({ tipo: h.tipo, quantidade: h.quantidade, pedido: h.pedido, desconto: h.desconto, em: h.em, onde: h.vinculada || '' }))
    const regras = [`1 ${st.simbolo} = ${brl(st.desconto)} de desconto nas compras em ${st.empresa}.`, 'Crédito promocional: não pode ser sacado nem trocado por dinheiro.']
    if (cfg.adesao?.ativo) regras.push(cfg.adesao.regra === 'fixa' ? `Clientes ganham ${cfg.adesao.moedasPorBloco} ${st.simbolo} por compra${cfg.adesao.minCompra ? ` a partir de ${brl(cfg.adesao.minCompra)}` : ''}.` : `Clientes ganham ${cfg.adesao.moedasPorBloco} ${st.simbolo} a cada ${brl(cfg.adesao.blocoValor)} em compras${cfg.adesao.minCompra ? ` (compra mínima ${brl(cfg.adesao.minCompra)})` : ''}.`)
    moedas.push({ tipo: 'propria', id: st.id, codigo: st.codigo, nome: st.nome, simbolo: st.simbolo, logo: st.logo, modelo: st.modeloInfo, cor1: st.cor1, cor2: st.cor2, descricao: st.descricao, finalidade: st.finalidade,
      emissora: st.empresa, situacao: st.status, valorReferencia: st.valorReferencia || null, descontoPorMoeda: st.desconto,
      numeros: { emitidas: st.total, distribuidas: st.distribuidas, utilizadas: st.utilizadas, disponiveis: st.disponiveis, emCirculacao: st.emCirculacao, detentores: st.detentores, descontoConcedido: st.descontoConcedidoReais },
      distribuicao: { distribuicoes: k('distribuicao'), adesao: k('adesao'), resgates: k('resgate'), estornos: k('estorno') },
      regras, historico: hist })
  }
  for (const v of (await H.vinculosDaEmpresa(bid)).filter((x: any) => x.status !== 'revogado')) {
    const st: any = await C.stats(v.moeda.id)
    const rows = await q("SELECT kind, delta, discount, order_id, created_at FROM coin_ledger WHERE coin_id = $1 AND linked_business_id = $2 ORDER BY id DESC", [v.moeda.id, bid])
    let usadas = 0, estornadas = 0, desc = 0, usos = 0
    for (const r of rows as any[]) { if (r.kind === 'resgate') { usadas += Math.abs(nInt(r.delta)); desc += Number(r.discount) || 0; usos++ } else if (r.kind === 'estorno') { estornadas += Math.abs(nInt(r.delta)); desc -= Number(r.discount) || 0; usos-- } }
    const dPor = v.desconto != null ? v.desconto : v.moeda.descontoPadrao
    const regras = [`Cada ${v.moeda.simbolo} dá ${brl(dPor)} de desconto nos pedidos da sua empresa.`, `Cobre até ${v.maxPct}% do valor dos itens${v.minCompra ? `, com compra mínima de ${brl(v.minCompra)}` : ''}.`, ...(v.regras ? [v.regras] : []), `Moeda emitida por ${v.moeda.emissora}: a empresa não emite nem distribui esta moeda.`]
    moedas.push({ tipo: 'vinculada', id: st.id, vinculoId: v.id, codigo: st.codigo, nome: st.nome, simbolo: st.simbolo, logo: st.logo, modelo: st.modeloInfo, cor1: st.cor1, cor2: st.cor2, descricao: st.descricao, finalidade: st.finalidade,
      emissora: v.moeda.emissora, situacao: st.status, vinculo: { status: v.status, pausadoPor: v.pausadoPor || null, aceitoEm: v.aceitoEm || null }, valorReferencia: st.valorReferencia || null, descontoPorMoeda: dPor,
      numeros: { recebidas: usadas, estornadas, liquidas: Math.max(0, usadas - estornadas), usos: Math.max(0, usos), descontoConcedido: Math.round(desc * 100) / 100, emCirculacao: st.emCirculacao },
      regras, historico: (rows as any[]).slice(0, 60).map((r) => ({ tipo: r.kind, quantidade: nInt(r.delta), pedido: r.order_id ? Number(r.order_id) : null, desconto: r.discount != null ? Number(r.discount) : null, em: new Date(r.created_at).toISOString() })) })
  }
  return { visivel: moedas.length > 0, sistemaLigado: cfg.ativo, empresa: J<any>(b.data, {}).empresa || '', moedas }
}

/* ---------- Mercado de MCoins (cotação, negociação e carteira por moeda) ---------- */
export async function coinMarketGet(ctx: Ctx) { const u = requireUser(ctx); return MK.detalhe(u.id, Number(ctx.params.id), String(ctx.query.get('range') || '24h')) }
export async function coinMarketQuotePost(ctx: Ctx) { const u = requireUser(ctx); return MK.cotar(u.id, Number(ctx.params.id), ctx.body || {}) }
export async function coinMarketBuyPost(ctx: Ctx) { const u = requireUser(ctx); return MK.negociar('compra', u, Number(ctx.params.id), ctx.body || {}) }
export async function coinMarketSellPost(ctx: Ctx) { const u = requireUser(ctx); return MK.negociar('venda', u, Number(ctx.params.id), ctx.body || {}) }
export async function panelCoinMarketGet(ctx: Ctx) { admin(ctx); return MK.painel(Number(ctx.params.id)) }
export async function panelCoinMarketPost(ctx: Ctx) {
  const u = admin(ctx, true), id = Number(ctx.params.id), b = ctx.body || {}
  if (b.action === 'ajustar') return { ok: true, ...(await MK.ajustarCotacao(id, b.preco, b.motivo, u.id)), painel: await MK.painel(id) }
  if (b.action === 'auditar') return MK.auditoria(id)
  await MK.salvarConfig(id, b, u.id); return { ok: true, painel: await MK.painel(id) }
}
