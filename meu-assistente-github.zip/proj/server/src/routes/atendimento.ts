// Atendimento humano (suporte) entre quem conversa com o AGENTE de uma empresa e a própria empresa.
//  • Abertura: pelo chat do agente (o agente reconhece "quero falar com uma pessoa", "abrir um chamado", "estou com um
//    problema"…), com a descrição e arquivos opcionais. Quem está logado fica ligado à conta; visitante recebe uma chave
//    secreta (só o SHA-256 dela fica no banco) que o navegador guarda para voltar ao chamado.
//  • Conversa: mensagens e anexos persistidos dos dois lados, status aberto → em atendimento → atendido/encerrado, reabrir.
//  • Painel da empresa: lista (todas as empresas da conta: próprias + vinculadas válidas), contador sem duplicidade
//    (chamados pendentes OU com mensagem não lida), conversa, status. Rotas da empresa passam por ownBusiness (dono ou
//    vínculo válido via X-MA-Empresa) — chamado de outra empresa nunca aparece.
//  • Anexos: tipo conferido pelo CONTEÚDO (não pela extensão), tamanho limitado, servidos só por rota autorizada com
//    nosniff e sandbox (documentos baixam como arquivo).
//  • Avisos: a empresa recebe notificação (central de notificações/push/e-mail conforme preferências) a cada chamado novo
//    e a cada mensagem; o cliente logado recebe as respostas da empresa.
import { randomBytes } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail, HttpError } from '../lib/http.js'
import { q, one, nowIso, J } from '../db/index.js'
import { sha256, rateLimit } from '../lib/security.js'
import { notify } from '../lib/notify.js'
import type { UpFile } from '../lib/multipart.js'

export const STATUS: Record<string, string> = { aberto: 'Aberto', em_atendimento: 'Em atendimento', atendido: 'Atendido', encerrado: 'Encerrado' }
export const MAX_ARQ = 4, MAX_BYTES = 5 * 1024 * 1024
const str = (v: any, n: number) => String(v ?? '').replace(/\u0000/g, '').replace(/\r\n?/g, '\n').trim().slice(0, n) // multipart dos navegadores manda quebras como CRLF

/* ---------- intenção (chat do agente) ---------- */
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const INTENCAO = [
  /\b(falar|conversar|tratar|atendimento|atender|contato|contatar)\b.{0,25}\b(pessoa|humano|humana|atendente|alguem|funcionari[oa]|gente de verdade|ser humano|responsavel|dono|dona|gerente|equipe|vendedor[a]?)\b/,
  /\b(atendimento|atendente|suporte) (humano|humana|pessoal|de verdade)\b/,
  /\babrir (um |uma )?(chamado|ticket|protocolo|reclamacao|solicitacao de suporte)\b/,
  /\b(quero|preciso de|queria|gostaria de) (um |uma )?(atendente|humano|suporte|ajuda humana)\b/,
  /\b(estou|to|tou|fiquei) com (um |uns |algum )?problema\b/, /\b(tenho|tive|deu|ocorreu|aconteceu) (um |algum )?problema\b/,
  /\b(fazer|registrar|abrir) (uma )?reclamacao\b/, /\bnao (estou|to) conseguindo resolver\b/, /\bme (passa|transfere|transfira|encaminha) (para|pra) (um |uma )?(pessoa|atendente|humano)\b/,
  /^(atendente|atendimento humano|humano|suporte|falar com atendente)[.!?]?$/,
]
/** "Quero falar com uma pessoa", "abrir um chamado", "estou com um problema"… — e não "não tem problema" ou pesquisas. */
export function pedeAtendimentoHumano(texto: string): boolean {
  const t = nrm(texto); if (!t || t.length > 400) return false
  if (/\b(nao tem|sem|nenhum) problema\b/.test(t) && !/\b(estou|tive|tenho) com\b/.test(t)) return false
  return INTENCAO.some((re) => re.test(t))
}

/* ---------- anexos: tipo pelo conteúdo ---------- */
const EXT_ZIP: Record<string, string> = { docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', odt: 'application/vnd.oasis.opendocument.text', ods: 'application/vnd.oasis.opendocument.spreadsheet' }
export function tipoDoArquivo(buf: Buffer, nome: string): string | null {
  const h = (n: number) => buf.subarray(0, n), ext = (String(nome).toLowerCase().match(/\.([a-z0-9]{2,5})$/) || [])[1] || ''
  if (h(8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png'
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg'
  if (h(4).toString('latin1') === 'GIF8') return 'image/gif'
  if (h(4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp'
  if (h(5).toString('latin1') === '%PDF-') return 'application/pdf'
  if (buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04 && EXT_ZIP[ext]) return EXT_ZIP[ext]
  if (['txt', 'csv', 'log'].includes(ext)) { const a = buf.subarray(0, 8192); if (a.includes(0)) return null; try { new TextDecoder('utf-8', { fatal: true }).decode(a.length < buf.length ? a.subarray(0, a.length - 4) : a) } catch { return null } return ext === 'csv' ? 'text/csv' : 'text/plain' }
  return null
}
export interface Arquivo { mime: string; nome: string; data: string; tamanho: number }
export function validarArquivos(files: UpFile[] | undefined): Arquivo[] {
  const fs = (files || []).filter((f) => f && f.data && f.data.length)
  if (fs.length > MAX_ARQ) fail(400, `Envie no máximo ${MAX_ARQ} arquivos por mensagem.`, 'invalid')
  return fs.map((f) => {
    if (f.data.length > MAX_BYTES) fail(400, `"${str(f.filename, 60)}" passa de 5 MB. Envie um arquivo menor.`, 'invalid')
    const mime = tipoDoArquivo(f.data, f.filename)
    if (!mime) fail(400, `"${str(f.filename, 60) || 'arquivo'}" não é um formato aceito. Envie imagens (JPG, PNG, WEBP, GIF), PDF, documentos (DOCX, XLSX, PPTX, ODT, ODS) ou texto (TXT, CSV).`, 'invalid')
    const nome = str(f.filename, 100).replace(/[\\/:*?"<>|\r\n]/g, '_') || 'arquivo'
    return { mime: mime!, nome, data: f.data.toString('base64'), tamanho: f.data.length }
  })
}

/* ---------- dados ---------- */
async function addMensagem(aid: number, autor: 'cliente' | 'empresa' | 'sistema', userId: number | null, texto: string, arqs: Arquivo[] = []) {
  const em = nowIso()
  await q('INSERT INTO atendimento_mensagens (atendimento_id, autor, user_id, texto, created_at) VALUES ($1,$2,$3,$4,$5)', [aid, autor, userId, texto, em])
  const m = await one('SELECT id FROM atendimento_mensagens WHERE atendimento_id = $1 ORDER BY id DESC LIMIT 1', [aid])
  for (const a of arqs) await q('INSERT INTO atendimento_anexos (mensagem_id, atendimento_id, mime, nome, data, tamanho) VALUES ($1,$2,$3,$4,$5,$6)', [m!.id, aid, a.mime, a.nome, a.data, a.tamanho])
  return Number(m!.id)
}
const resumo = (a: any) => ({ id: Number(a.id), protocolo: a.protocolo, businessId: Number(a.business_id), status: a.status, statusNome: STATUS[a.status] || a.status, nome: a.nome, motivo: a.motivo, criadoEm: a.created_at, atualizadoEm: a.updated_at })
async function completo(a: any, lado: 'cliente' | 'empresa', base: string) {
  const ms = await q('SELECT id, autor, texto, created_at FROM atendimento_mensagens WHERE atendimento_id = $1 ORDER BY id', [a.id])
  const ax = await q('SELECT id, mensagem_id, mime, nome, tamanho FROM atendimento_anexos WHERE atendimento_id = $1 ORDER BY id', [a.id])
  const b = await one('SELECT data FROM businesses WHERE id = $1', [a.business_id]), x = J<any>(b?.data, {})
  return {
    ...resumo(a), empresa: { id: Number(a.business_id), nome: String(x.empresa || 'Empresa') },
    ...(lado === 'empresa' ? { contato: a.contato, cliente: { nome: a.nome || 'Cliente', conta: !!a.user_id }, naoLidas: Number(a.empresa_nao_lidas) } : { naoLidas: Number(a.cliente_nao_lidas) }),
    mensagens: ms.map((m: any) => ({ id: Number(m.id), autor: m.autor, texto: m.texto, em: m.created_at,
      anexos: ax.filter((z: any) => Number(z.mensagem_id) === Number(m.id)).map((z: any) => ({ id: Number(z.id), nome: z.nome, mime: z.mime, tamanho: Number(z.tamanho), imagem: /^image\//.test(z.mime), url: `${base}/anexo/${z.id}` })) })),
  }
}
const protocolo = () => `AT-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${randomBytes(3).toString('hex').toUpperCase()}`
async function avisarEmpresa(bid: number, titulo: string, corpo: string, ref: string, aid: number) {
  const b = await one('SELECT owner_id, data FROM businesses WHERE id = $1', [bid]); if (!b) return
  const emp = String(J<any>(b.data, {}).empresa || 'sua empresa')
  await notify(Number(b.owner_id), { type: 'atendimento', title: `${titulo} — ${emp}`, body: corpo.slice(0, 160), link: `/x/sua-empresa?atendimento=${aid}&empresa=${bid}`, ref }).catch((e) => console.error('[atendimento] aviso:', e?.message))
}
function corpoDe(ctx: Ctx): { texto: string; files: UpFile[] } { return { texto: str(ctx.body?.texto, 4000), files: ((ctx as any).files || []) as UpFile[] } }

/* ---------- cliente (página do agente) ---------- */
const chaveDe = (ctx: Ctx) => String(ctx.req.headers['x-ma-chave'] || ctx.query?.get('k') || '').trim().slice(0, 100)
async function doCliente(ctx: Ctx): Promise<any> {
  const bid = Number(ctx.params.id), aid = Number(ctx.params.aid), k = chaveDe(ctx), uid = ctx.user ? Number(ctx.user.id) : 0
  const a = await one('SELECT * FROM atendimentos WHERE id = $1 AND business_id = $2', [aid, bid])
  const ok = a && ((uid && Number(a.user_id) === uid) || (k.length >= 32 && a.guest_hash && a.guest_hash === sha256(k)))
  if (!ok) fail(404, 'Atendimento não encontrado.', 'not_found')
  return a
}
export async function atendimentoAbrirPost(ctx: Ctx) {
  const bid = Number(ctx.params.id)
  const { agentBiz } = await import('./businesses.js'); const { b, x } = await agentBiz(bid, ctx) // empresa com agente no ar (o dono pode testar)
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim()
  const { texto, files } = corpoDe(ctx), u = ctx.user
  const nome = str(ctx.body?.nome, 80) || (u ? String(u.name || '') : ''), contato = str(ctx.body?.contato, 120)
  if (texto.length < 3 && !files.length) fail(400, 'Conte em poucas palavras o que aconteceu.', 'invalid', 'texto')
  if (!nome) fail(400, 'Informe seu nome para a empresa saber com quem está falando.', 'invalid', 'nome')
  const arqs = validarArquivos(files)
  // limite só conta aberturas válidas (um formulário com erro não "gasta" tentativas); por conta, ou por IP para visitantes
  if (!rateLimit(`atend:abrir:${bid}:${u ? 'u' + u.id : ip}`, 4, 60 * 60_000)) fail(429, 'Você abriu vários atendimentos seguidos. Continue pelo atendimento que já está aberto ou aguarde um pouco.', 'rate_limited')
  const chave = u ? '' : randomBytes(24).toString('hex'), p = protocolo(), em = nowIso(), motivo = (texto || 'Arquivo enviado').split(/\n/)[0].trim().slice(0, 140)
  await q('INSERT INTO atendimentos (protocolo, business_id, user_id, guest_hash, nome, contato, motivo, status, empresa_nao_lidas, cliente_nao_lidas, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$11)',
    [p, bid, u ? u.id : null, chave ? sha256(chave) : null, nome, contato, motivo, 'aberto', 1, 0, em])
  const a = await one('SELECT * FROM atendimentos WHERE protocolo = $1', [p])
  await addMensagem(Number(a!.id), 'cliente', u ? Number(u.id) : null, texto || '(arquivo)', arqs)
  await addMensagem(Number(a!.id), 'sistema', null, `Atendimento ${p} aberto. A equipe de ${x.empresa || 'atendimento'} vai responder por aqui.`)
  await avisarEmpresa(bid, 'Novo pedido de atendimento', `${nome}: ${motivo}`, `atend:${a!.id}:novo`, Number(a!.id))
  void b
  return { chave: chave || null, atendimento: await completo(a, 'cliente', `/api/v2/agent/${bid}/atendimentos`) }
}
export async function atendimentoClienteGet(ctx: Ctx) {
  const a = await doCliente(ctx)
  if (Number(a.cliente_nao_lidas)) await q('UPDATE atendimentos SET cliente_nao_lidas = 0 WHERE id = $1', [a.id])
  return completo({ ...a, cliente_nao_lidas: 0 }, 'cliente', `/api/v2/agent/${a.business_id}/atendimentos`)
}
/** Resumo leve para o botão "Atendimento" da página do agente: os chamados deste navegador/conta e quantas respostas novas. */
export async function atendimentosClienteGet(ctx: Ctx) {
  const bid = Number(ctx.params.id), uid = ctx.user ? Number(ctx.user.id) : 0
  const ks = String(ctx.query?.get('k') || '').split(',').map((s) => s.trim()).filter((s) => s.length >= 32).slice(0, 20).map(sha256)
  if (!uid && !ks.length) return { items: [] }
  const cond = [uid ? 'user_id = $2' : '', ks.length ? `guest_hash IN (${ks.map((_, i) => '$' + (i + 3)).join(',')})` : ''].filter(Boolean).join(' OR ')
  const rows = await q(`SELECT * FROM atendimentos WHERE business_id = $1 AND (${cond}) ORDER BY updated_at DESC LIMIT 20`, [bid, uid || 0, ...ks])
  return { items: rows.map((a: any) => ({ ...resumo(a), naoLidas: Number(a.cliente_nao_lidas) })) }
}
export async function atendimentoClienteMsgPost(ctx: Ctx) {
  const a = await doCliente(ctx), { texto, files } = corpoDe(ctx)
  if (!rateLimit(`atend:msg:c:${a.id}`, 30, 10 * 60_000)) fail(429, 'Muitas mensagens seguidas. Aguarde um pouco.', 'rate_limited')
  if (!texto && !files.length) fail(400, 'Escreva sua mensagem ou anexe um arquivo.', 'invalid')
  const arqs = validarArquivos(files)
  await addMensagem(Number(a.id), 'cliente', ctx.user ? Number(ctx.user.id) : null, texto || '(arquivo)', arqs)
  let status = a.status
  if (a.status === 'encerrado' || a.status === 'atendido') { status = 'aberto'; await addMensagem(Number(a.id), 'sistema', null, 'Atendimento reaberto pelo cliente.') }
  await q('UPDATE atendimentos SET status = $1, empresa_nao_lidas = empresa_nao_lidas + 1, updated_at = $2 WHERE id = $3', [status, nowIso(), a.id])
  const mid = (await one('SELECT MAX(id) AS m FROM atendimento_mensagens WHERE atendimento_id = $1 AND autor = $2', [a.id, 'cliente']))?.m
  await avisarEmpresa(Number(a.business_id), `Nova mensagem no atendimento ${a.protocolo}`, `${a.nome || 'Cliente'}: ${(texto || '(arquivo)').slice(0, 120)}`, `atend:${a.id}:msg:${mid}`, Number(a.id))
  return atendimentoClienteGet(ctx)
}
export async function atendimentoClienteAnexoGet(ctx: Ctx) { const z = await anexoDe(Number(ctx.params.anexo)); ctx.params.aid = String(z?.atendimento_id || 0); const a = await doCliente(ctx); return entregar(Number(ctx.params.anexo), Number(a.id)) }

/* ---------- empresa (painel) ---------- */
async function daEmpresa(ctx: Ctx) {
  const { ownBusiness } = await import('./businesses.js'); const { u, b } = await ownBusiness(ctx) // dono ou vínculo válido (X-MA-Empresa)
  return { u, b }
}
async function chamadoDaEmpresa(ctx: Ctx) {
  const { u, b } = await daEmpresa(ctx)
  const a = await one('SELECT * FROM atendimentos WHERE id = $1 AND business_id = $2', [Number(ctx.params.aid), b.id])
  if (!a) fail(404, 'Atendimento não encontrado.', 'not_found')
  return { u, b, a: a! }
}
const precisaAtencao = "(status = 'aberto' OR (empresa_nao_lidas > 0 AND status <> 'encerrado'))"
async function listar(bids: number[], status: string) {
  if (!bids.length) return []
  const st = STATUS[status] ? `AND a.status = '${status}'` : status === 'ativos' ? "AND a.status <> 'encerrado'" : ''
  const rows = await q(`SELECT a.*, (SELECT texto FROM atendimento_mensagens m WHERE m.atendimento_id = a.id AND m.autor <> 'sistema' ORDER BY m.id DESC LIMIT 1) AS ultima,
      (SELECT autor FROM atendimento_mensagens m WHERE m.atendimento_id = a.id AND m.autor <> 'sistema' ORDER BY m.id DESC LIMIT 1) AS ultimo_autor,
      (SELECT COUNT(*) FROM atendimento_anexos z WHERE z.atendimento_id = a.id) AS anexos
    FROM atendimentos a WHERE a.business_id IN (${bids.map((_, i) => '$' + (i + 1)).join(',')}) ${st} ORDER BY CASE WHEN a.status = 'aberto' OR a.empresa_nao_lidas > 0 THEN 0 ELSE 1 END, a.updated_at DESC LIMIT 200`, bids)
  return rows.map((a: any) => ({ ...resumo(a), cliente: { nome: a.nome || 'Cliente', conta: !!a.user_id }, contato: a.contato, naoLidas: Number(a.empresa_nao_lidas), anexos: Number(a.anexos), ultima: a.ultima ? { texto: String(a.ultima).slice(0, 140), autor: a.ultimo_autor } : null }))
}
async function contar(bids: number[]) {
  if (!bids.length) return { chamados: 0, pendentes: 0, naoLidas: 0 }
  const IN = `business_id IN (${bids.map((_, i) => '$' + (i + 1)).join(',')})`
  const r = (await q(`SELECT SUM(CASE WHEN ${precisaAtencao} THEN 1 ELSE 0 END) AS c, SUM(CASE WHEN status = 'aberto' THEN 1 ELSE 0 END) AS p, SUM(CASE WHEN status <> 'encerrado' THEN empresa_nao_lidas ELSE 0 END) AS n FROM atendimentos WHERE ${IN}`, bids))[0] || {}
  return { chamados: Number(r.c || 0), pendentes: Number(r.p || 0), naoLidas: Number(r.n || 0) }
}
/** Empresas cujo atendimento esta conta pode ver: as próprias e as vinculadas com vínculo válido. */
async function empresasDaConta(uid: number) {
  const proprias = await q("SELECT id, data FROM businesses WHERE owner_id = $1 AND status NOT IN ('lixeira','institucional')", [uid])
  const vinc = await (await import('../lib/vinculos.js')).vinculadasValidas(uid)
  const { refImagem } = await import('../lib/imagem-empresa.js'), vis = new Set<number>()
  return [...proprias, ...vinc].filter((b: any) => !vis.has(Number(b.id)) && vis.add(Number(b.id))).map((b: any) => { const d = J<any>(b.data, {}); return { id: Number(b.id), nome: String(d.empresa || 'Empresa'), logo: d.logo ? refImagem(Number(b.id), 'logo', d.logo) : null, vinculada: !proprias.some((p: any) => Number(p.id) === Number(b.id)) } })
}
/** Botão flutuante do painel: contador de TODAS as empresas da conta (sem somar duas vezes o mesmo chamado). */
export async function atendimentosContadorGet(ctx: Ctx) {
  const { requireUser } = await import('../lib/session.js'); const u = requireUser(ctx)
  const emps = await empresasDaConta(Number(u.id)); const c = await contar(emps.map((e) => e.id))
  const ult = emps.length ? await one(`SELECT MAX(updated_at) AS m FROM atendimentos WHERE business_id IN (${emps.map((_, i) => '$' + (i + 1)).join(',')})`, emps.map((e) => e.id)) : null
  return { ...c, empresas: emps.length, ultimo: ult?.m || null }
}
export async function atendimentosPainelGet(ctx: Ctx) {
  const { requireUser } = await import('../lib/session.js'); const u = requireUser(ctx)
  const emps = await empresasDaConta(Number(u.id)), so = Number(ctx.query?.get('empresa') || 0)
  const bids = so ? emps.filter((e) => e.id === so).map((e) => e.id) : emps.map((e) => e.id)
  const items = (await listar(bids, String(ctx.query?.get('status') || ''))).map((i) => ({ ...i, empresa: emps.find((e) => e.id === i.businessId) || null }))
  return { status: STATUS, empresas: emps, contador: await contar(emps.map((e) => e.id)), items }
}
export async function atendimentoEmpresaGet(ctx: Ctx) {
  const { a } = await chamadoDaEmpresa(ctx)
  if (Number(a.empresa_nao_lidas)) await q('UPDATE atendimentos SET empresa_nao_lidas = 0 WHERE id = $1', [a.id])
  return completo({ ...a, empresa_nao_lidas: 0 }, 'empresa', `/api/v2/ads/${a.business_id}/atendimentos`)
}
/** Responder (texto/arquivos) e/ou mudar o status: em_atendimento, atendido, encerrado ou aberto (reabrir). */
export async function atendimentoEmpresaPost(ctx: Ctx) {
  const { u, b, a } = await chamadoDaEmpresa(ctx), { texto, files } = corpoDe(ctx)
  const novo = STATUS[String(ctx.body?.status || '')] ? String(ctx.body.status) : null
  if (!texto && !files.length && !novo) fail(400, 'Escreva uma resposta, anexe um arquivo ou escolha um status.', 'invalid')
  const arqs = validarArquivos(files), deleg = (ctx as any).delegadoPor
  if (texto || arqs.length) await addMensagem(Number(a.id), 'empresa', Number(deleg?.id || u.id), texto || '(arquivo)', arqs)
  // responder um chamado novo já o coloca "em atendimento"; status escolhido explicitamente prevalece
  const status = novo || ((texto || arqs.length) && a.status === 'aberto' ? 'em_atendimento' : a.status)
  if (status !== a.status) await addMensagem(Number(a.id), 'sistema', null, status === 'aberto' ? 'Atendimento reaberto pela empresa.' : `Status: ${STATUS[status]}.`)
  const resp = !!(texto || arqs.length), mudou = status !== a.status
  await q('UPDATE atendimentos SET status = $1, empresa_nao_lidas = 0, cliente_nao_lidas = cliente_nao_lidas + $2, updated_at = $3 WHERE id = $4', [status, resp || mudou ? 1 : 0, nowIso(), a.id])
  if (a.user_id && (resp || mudou)) {
    const x = J<any>(b.data, {})
    await notify(Number(a.user_id), { type: 'atendimento_cliente', title: resp ? `${x.empresa || 'A empresa'} respondeu seu atendimento` : `Atendimento ${a.protocolo}: ${STATUS[status]}`, body: resp ? (texto || '(arquivo)').slice(0, 140) : `Status atualizado para ${STATUS[status]}.`, link: `/a/${b.id}?atendimento=${a.id}`, ref: `atend:${a.id}:cli:${Date.now()}` }).catch(() => null)
  }
  return atendimentoEmpresaGet(ctx)
}
export async function atendimentoEmpresaAnexoGet(ctx: Ctx) {
  const { b } = await daEmpresa(ctx), z = await anexoDe(Number(ctx.params.anexo))
  const a = z ? await one('SELECT id FROM atendimentos WHERE id = $1 AND business_id = $2', [z.atendimento_id, b.id]) : null
  if (!a) fail(404, 'Anexo não encontrado.', 'not_found')
  return entregar(Number(ctx.params.anexo), Number(a!.id))
}
async function anexoDe(id: number) { return id > 0 ? one('SELECT id, atendimento_id FROM atendimento_anexos WHERE id = $1', [id]) : null }
async function entregar(anexoId: number, aid: number) {
  const z = await one('SELECT * FROM atendimento_anexos WHERE id = $1 AND atendimento_id = $2', [anexoId, aid])
  if (!z) throw new HttpError(404, 'Anexo não encontrado.', 'not_found')
  const img = /^image\//.test(z.mime), pdf = z.mime === 'application/pdf', nome = encodeURIComponent(String(z.nome || 'arquivo'))
  return { _binary: true, data: Buffer.from(z.data, 'base64'), mime: z.mime, headers: { 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox", 'Content-Disposition': `${img || pdf ? 'inline' : 'attachment'}; filename*=UTF-8''${nome}`, 'Cache-Control': 'private, max-age=600' } }
}
