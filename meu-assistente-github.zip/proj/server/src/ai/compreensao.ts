// COMPREENSÃO DA MENSAGEM NO CONTEXTO DA CONVERSA — camada determinística (sem IA, sem custo) que fica antes dos motores
// do chat e do Cérebro Central. Ela não responde nada: devolve a mensagem "entendida".
//  1. normalizar(): abreviações e gírias de digitação ("qnto", "hj", "vc", "blz") e erros de digitação nas PALAVRAS DE
//     COMANDO ("lenbra", "agnda", "conpromisso") viram a forma correta — só para o processamento; a mensagem gravada
//     continua exatamente como a pessoa escreveu. Nomes próprios (com maiúscula) nunca são "corrigidos".
//  2. resolver(): usa o histórico para entender
//     • continuação curta ("e quem criou?", "em que ano?", "e o preço?", "e ele?") → pergunta completa com o assunto
//       da conversa ("quem criou o Protocolo Zyntra?");
//     • continuação de tempo de uma consulta ("quanto gastei hoje?" → "e ontem?") → "quanto gastei ontem?";
//     • resposta a um pedido de esclarecimento ("Jaguar pode ser… de qual você fala?" → "o carro") → assunto refinado;
//     • domínio da conversa (carro, animal, futebol, cidade…) para desambiguar nomes iguais ("o jaguar é bom?" numa
//       conversa sobre comprar carro = o carro, não o animal);
//     • pergunta de avaliação de um produto/nome ("é bom?", "vale a pena?") → consulta informativa ("avaliação …").
//  O assunto anterior nunca é inventado: sem assunto claro no histórico, a mensagem segue como veio.
import { termos } from './semantica.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
type Msg = { role: string; content: string | null }

/* ============================== 1. normalização ============================== */
// palavra inteira → forma correta (minúsculas, sem acento na chave)
const ABREV: Record<string, string> = {
  qnto: 'quanto', qto: 'quanto', qnt: 'quanto', qnta: 'quanta', qta: 'quanta', qntos: 'quantos', qtos: 'quantos', qntas: 'quantas', qtas: 'quantas',
  hj: 'hoje', hje: 'hoje', amnh: 'amanhã', amnha: 'amanhã', amanha: 'amanhã', dps: 'depois', dpois: 'depois', agr: 'agora', ontm: 'ontem',
  vc: 'você', vce: 'você', vcs: 'vocês', tb: 'também', tbm: 'também', tmb: 'também', oq: 'o que', oque: 'o que', msm: 'mesmo',
  mt: 'muito', mto: 'muito', mta: 'muita', mts: 'muitos', td: 'tudo', tdo: 'tudo', tds: 'todos', cmg: 'comigo', ctg: 'contigo',
  blz: 'beleza', vlw: 'valeu', obg: 'obrigado', obgd: 'obrigado', obgda: 'obrigada', pfv: 'por favor', pfvr: 'por favor', pls: 'por favor', plz: 'por favor',
  hrs: 'horas', hr: 'hora', smn: 'semana', nd: 'nada', ngm: 'ninguém', kd: 'cadê', mds: 'meu deus', ñ: 'não', nao: 'não', tah: 'tá',
  qdo: 'quando', qnd: 'quando', qndo: 'quando', cm: 'como', tava: 'estava', fds: 'fim de semana', aniver: 'aniversário', niver: 'aniversário',
}
// erros de digitação conhecidos nas palavras de comando curtas (lista fechada: palavras curtas parecidas são comuns em
// português — "quando"/"quanto", "gatos"/"gastos", "marcar"/"remarcar" — e nunca são trocadas por aproximação)
const ERROS: Record<string, string> = {
  lenbra: 'lembra', lembar: 'lembra', lebra: 'lembra', lenbre: 'lembre', lenbrar: 'lembrar', lembrar: 'lembrar', lenbrete: 'lembrete', lembete: 'lembrete', lebrete: 'lembrete', lenbretes: 'lembretes', lembrte: 'lembrete',
  agnda: 'agenda', ajenda: 'agenda', agneda: 'agenda', agenad: 'agenda', ajendar: 'agendar', agnedar: 'agendar', agendr: 'agendar', agnde: 'agende',
  despeza: 'despesa', despezas: 'despesas', dispesa: 'despesa', dispesas: 'despesas', dentsta: 'dentista', dentita: 'dentista', denstista: 'dentista',
  amanah: 'amanhã', amnha: 'amanhã', amahna: 'amanhã', amanhá: 'amanhã', reunao: 'reunião', renuiao: 'reunião', reuniõa: 'reunião',
  pagei: 'paguei', paguie: 'paguei', gasteii: 'gastei', recebii: 'recebi', tarfa: 'tarefa', trefa: 'tarefa', cancelr: 'cancelar', cancla: 'cancela',
}
// palavras de comando LONGAS: aceita 1 letra errada/trocada/faltando (risco baixo de virar outra palavra real)
const LONGAS = ['lembrete', 'lembretes', 'compromisso', 'compromissos', 'pagamento', 'pagamentos', 'consultas', 'aniversário', 'remarcar', 'cancelar', 'despesas', 'transferência']
const semAcento = (s: string) => nrm(s)
function distancia(a: string, b: string, max: number) { // Damerau-Levenshtein com corte
  if (Math.abs(a.length - b.length) > max) return max + 1
  const d: number[][] = Array.from({ length: a.length + 1 }, (_, i) => [i, ...new Array(b.length).fill(0)]); for (let j = 1; j <= b.length; j++) d[0][j] = j
  for (let i = 1; i <= a.length; i++) { let lin = max + 1; for (let j = 1; j <= b.length; j++) { const c = a[i - 1] === b[j - 1] ? 0 : 1; d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c); if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1); lin = Math.min(lin, d[i][j]) } if (lin > max) return max + 1 }
  return d[a.length][b.length]
}
const CORRETAS = new Set(['remarcar', 'cancelar', 'cancelou', 'cancelei', 'consultar', 'pagamentos', 'despesas'])
export interface Normalizado { texto: string; correcoes: { de: string; para: string }[] }
export function normalizar(texto: string): Normalizado {
  const correcoes: Normalizado['correcoes'] = []
  const sozinho = nrm(texto).trim().replace(/[!.?]+$/, '')
  if (/^(s|ss|sim sim)$/.test(sozinho)) return { texto: 'sim', correcoes: [{ de: texto.trim(), para: 'sim' }] }
  if (/^(n|nn)$/.test(sozinho)) return { texto: 'não', correcoes: [{ de: texto.trim(), para: 'não' }] }
  const bruto = String(texto ?? '')
  // código, links, e-mails e identificadores nunca são mexidos
  if (/[{};`<>]|=>|https?:\/\/|www\.|\w@\w|\b(function|const|let|return|import|select|insert)\b/i.test(bruto)) return { texto: bruto, correcoes }
  let i = 0
  const out = bruto.split(/(\s+)/).map((tok) => {
    if (!tok.trim()) return tok
    const m = tok.match(/^([¿¡"'“(]*)([A-Za-zÀ-ÿñ]+)([.,!?;:)"'”]*)$/) // só palavra pura (com pontuação em volta); "xqz-n2", "dobrar(n)", "R$30" ficam como estão
    const pos = i++
    if (!m) return tok
    const [, pre, w, pos2] = m, troca = (r: string) => pre + r + pos2, k = semAcento(w)
    if (/^[A-ZÁÉÍÓÚÂÊÔÃÕÇ]/.test(w) && pos > 0) return tok // nome próprio no meio da frase: nunca mexe
    if (k === 'pq') { const r = pos === 0 ? 'por que' : 'porque'; correcoes.push({ de: w, para: r }); return troca(r) }
    if (k === 'q' && pos <= 3) { correcoes.push({ de: w, para: 'que' }); return troca('que') }
    if (k === 'n' && pos <= 4) { correcoes.push({ de: w, para: 'não' }); return troca('não') }
    if (ABREV[k] && k !== 'nao' && k !== 'amanha') { correcoes.push({ de: w, para: ABREV[k] }); return troca(ABREV[k]) }
    if (ERROS[k]) { correcoes.push({ de: w, para: ERROS[k] }); return troca(ERROS[k]) }
    if (k.length >= 7 && !CORRETAS.has(k)) {
      for (const c of LONGAS) { const ck = semAcento(c); if (ck !== k && !ck.startsWith(k) && !k.startsWith(ck) && distancia(k, ck, 1) <= 1) { correcoes.push({ de: w, para: c }); return troca(c) } }
    }
    return tok
  }).join('')
  return { texto: out, correcoes }
}

/* ============================== 2. resolução pelo contexto ============================== */
const INTERROG = /^\s*(o que (é|e|são|sao|significa|foi|era)|o que|que (é|e)|como (funciona(m)?|surgiu|se faz)|qual (é|e|foi|era)|quais (são|sao|foram)|qual|quais|quem (é|e|foi|são|era)|quando (foi|é|e)|onde (fica|é|e)|por que|me fale (sobre|de|do|da)|fale (sobre|de|do|da)|explique|defina)\s+((o|a|os|as|um|uma)\s+)?/i
// palavras de "aspecto" (o que se quer saber) — sozinhas não identificam assunto
const ASPECTO = new Set(termos('quem criou criador criadora fez inventou inventor fundou fundador fundadora fundada fundado descobriu descobridor escreveu autor autora dono dona ano anos quando onde fica fica lugar local quanto custa custo preço preco valor como funciona serve para que bom boa ruim vale pena compensa presta confiável confiavel recomenda melhor pior tamanho altura peso idade população populacao habitantes história historia origem significado sintomas sintoma tratamento tratar causa causas cura benefícios beneficios riscos efeitos colaterais diferença diferenca tipos exemplo exemplos nome nomes data dia hora horário horario capital moeda língua lingua idioma clima mais sobre detalhes ele ela eles elas isso disso dele dela deles delas nele nela esse essa este esta tem têm tinha era foi ser são sao é e o a os as um uma de da do das dos em no na nos nas que qual quais e mas então entao também tambem ainda agora'))
const NOME_ORIG = (t: string): string[] => { // nomes com maiúscula (fora do início) e siglas, na grafia original
  const pal = String(t || '').replace(/[?!.,;:()"“”]/g, ' ').split(/\s+/).filter(Boolean), out: string[] = []; let atual: string[] = []
  const M = (x?: string) => !!x && /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]+/.test(x)
  pal.forEach((w, i) => {
    const sigla = /^[A-Z0-9]{2,}$/.test(w) && /[A-Z]/.test(w), abre = i === 0 && (M(pal[1]) || (/^(da|de|do|das|dos)$/.test(pal[1] || '') && M(pal[2])))
    if ((M(w) && (i > 0 || abre)) || sigla) { atual.push(w); return }
    if (atual.length && /^(da|de|do|das|dos|e|di|von|van)$/.test(w) && M(pal[i + 1])) { atual.push(w); return }
    if (atual.length && /^\d+[A-Za-z]{0,3}$/.test(w)) { atual.push(w); return } // "iPhone 15", "PlayStation 5"
    if (atual.length) { out.push(atual.join(' ')); atual = [] }
  })
  if (atual.length) out.push(atual.join(' '))
  return out
}
/** Assunto de uma pergunta: nomes citados ou, sem nomes, o trecho depois do interrogativo (sem o aspecto). */
export function assuntoDe(texto: string): string {
  const ns = NOME_ORIG(texto); if (ns.length) return ns.join(' ')
  const s = String(texto || '').trim().replace(/[?!.\s]+$/, '').replace(INTERROG, '').trim()
  const ws = s.replace(/^(e|mas e)\s+/i, '').split(/\s+/).filter((w) => { const tw = termos(w)[0]; return w && tw && !ASPECTO.has(tw) }) // sem palavras de ligação ("e", "o", "é") e sem aspecto
  return ws.length && ws.length <= 6 ? ws.join(' ') : ''
}
/** A mensagem tem assunto próprio? (além de aspecto, pronomes e palavras de ligação) */
export function temAssuntoProprio(texto: string) { if (NOME_ORIG(texto).length) return true; return termos(texto).some((t) => !ASPECTO.has(t) && t.length > 2) }

// domínios para desambiguar nomes iguais: palavras do histórico → termo acrescentado à consulta + vocabulário do sentido
export const DOMINIOS: { id: string; termo: string; gatilho: RegExp; vocab: RegExp }[] = [
  { id: 'veiculo', termo: 'carro', gatilho: /\b(carro|carros|suv|sedan|picape|moto|motos|veiculo|veiculos|automovel|montadora|dirigir|concessionaria|seminovo|0 ?km)\b/, vocab: /\b(carro|suv|sedan|picape|motor|montadora|ve[ií]culo|autom[oó]vel|cv|tra[cç][aã]o|consumo|km\/l|c[aâ]mbio|concession[aá]ria)\b/i },
  { id: 'animal', termo: 'animal', gatilho: /\b(animal|animais|bicho|bichos|felino|zoologico|especie|fauna|selvagem|natureza|ameacad[oa])\b/, vocab: /\b(animal|felino|esp[eé]cie|habitat|ca[cç]a|mam[ií]fero|predador|fauna|floresta)\b/i },
  { id: 'tecnologia', termo: 'tecnologia', gatilho: /\b(celular|smartphone|computador|notebook|aplicativo|app|software|programa|sistema operacional|tablet)\b/, vocab: /\b(celular|smartphone|computador|software|aplicativo|tela|processador|sistema)\b/i },
  { id: 'futebol', termo: 'futebol', gatilho: /\b(futebol|time|clube|campeonato|jogador|jogo|partida|torcida|gol|brasileirao)\b/, vocab: /\b(futebol|clube|time|campeonato|jogador|t[ií]tulo|est[aá]dio)\b/i },
  { id: 'lugar', termo: 'cidade', gatilho: /\b(cidade|viajar|viagem|turismo|praia|morar|mudar para|conhecer|hotel|passeio)\b/, vocab: /\b(cidade|munic[ií]pio|estado|popula[cç][aã]o|turismo|praia|capital)\b/i },
  { id: 'musica', termo: 'música', gatilho: /\b(musica|musicas|banda|cantor|cantora|album|show|cancao|rock|samba)\b/, vocab: /\b(m[uú]sica|banda|cantor|[aá]lbum|can[cç][aã]o|disco)\b/i },
  { id: 'empresa', termo: 'empresa', gatilho: /\b(empresa|marca|acoes|bolsa|investir|investimento|startup|companhia)\b/, vocab: /\b(empresa|companhia|marca|a[cç][oõ]es|fundada|sede|faturamento)\b/i },
  { id: 'comida', termo: 'receita', gatilho: /\b(receita|comida|cozinhar|prato|ingrediente|jantar|almoco|sobremesa)\b/, vocab: /\b(receita|ingrediente|forno|prato|cozinh)/i },
]
const AVALIACAO = /(?:^|\s)((?:[eé]|est[aá]|seria) (?:bom|boa|ruim|confi[aá]vel|melhor)|vale a pena|compensa|presta|recomenda|o que (?:voc[eê] )?acha)(?=$|[\s?!.,])/i
const TEMPO = /\b(hoje|ontem|anteontem|amanh[aã]|depois de amanh[aã]|esta semana|essa semana|nesta semana|nessa semana|semana passada|na semana passada|este m[eê]s|esse m[eê]s|neste m[eê]s|nesse m[eê]s|m[eê]s passado|no m[eê]s passado|este ano|esse ano|ano passado|(na |no )?(segunda|ter[cç]a|quarta|quinta|sexta|s[aá]bado|domingo)(-feira)?)\b/i
const CONSULTA_DE_DADO = /^\s*(quanto|quantos|quantas|qual|quais|o que|como|quando|onde|tenho|meus|minhas|mostra|mostre|lista|liste|ver|veja)\b/i

export interface Resolvido {
  /** texto para os motores do chat (agenda, finanças…): igual ao recebido, ou a consulta anterior com o novo período */
  textoMotores: string
  /** pergunta completa para a biblioteca, a pesquisa e a IA (com o assunto da conversa, quando é continuação) */
  pergunta: string
  /** consulta para o buscador (pode levar o termo do domínio e "avaliação") e assunto que as fontes precisam tratar */
  consulta: string; assunto: string; dominio: string | null
  seguimento: boolean; esclarecimento: boolean; avaliacao: boolean; motivo: string
}
/** Entende a mensagem com o histórico da conversa (veja o cabeçalho). */
export function resolver(texto: string, hist: Msg[]): Resolvido {
  const t = String(texto || '').trim(), s = nrm(t)
  const ant = hist.filter((m) => m.content).slice(-12)
  // o histórico guarda o que a pessoa escreveu ("qnto gastei hj?"): é normalizado do mesmo jeito
  const usuarios = ant.filter((m) => m.role === 'user').map((m) => normalizar(String(m.content)).texto), ultBot = [...ant].reverse().find((m) => m.role === 'assistant')?.content || ''
  const base: Resolvido = { textoMotores: t, pergunta: t, consulta: '', assunto: '', dominio: null, seguimento: false, esclarecimento: false, avaliacao: false, motivo: '' }
  // domínio da conversa (últimas mensagens da pessoa + a atual)
  const recentes = nrm([...usuarios.slice(-4), t].join(' \n '))
  const dom = DOMINIOS.find((d) => d.gatilho.test(recentes)) || null
  // 1) continuação de tempo de uma CONSULTA ("quanto gastei hoje?" → "e ontem?") — nunca repete um registro
  const mt = s.match(/^(e|mas e|e quanto a|e sobre)\s+(.{2,40}?)\s*\??$/)
  if (mt && TEMPO.test(mt[2]) && mt[2].replace(TEMPO, '').trim().length <= 3) { // "e ontem?" só continua uma CONSULTA; depois de um registro, segue como veio
    const fim = (r: Resolvido) => r
    const prev = [...usuarios].reverse().find((u) => CONSULTA_DE_DADO.test(nrm(u)) || /\?\s*$/.test(u))
    if (prev && !/^(gastei|paguei|comprei|recebi|ganhei|vendi|lembra|agend|marc|cria|anota|registr)/.test(nrm(prev).trim())) {
      const novo = mt[2].trim(), comTempo = TEMPO.test(prev) ? prev.replace(TEMPO, novo) : prev.replace(/[?\s]*$/, '') + ' ' + novo + '?'
      return fim({ ...base, textoMotores: comTempo, pergunta: comTempo, consulta: '', seguimento: true, motivo: `continuação de tempo de "${prev.slice(0, 60)}"` })
    }
    return base
  }
  // 2) resposta a um pedido de esclarecimento do próprio assistente ("… pode se referir a … De qual você fala?")
  if (/pode se referir a mais de uma coisa|de qual (voc[eê] )?(est[aá] falando|fala|quer saber)/i.test(ultBot) && s.split(/\s+/).length <= 6) {
    const orig = [...usuarios].reverse()[0] || '', ass = assuntoDe(orig) || assuntoDe(ultBot)
    const escolha = t.replace(/^(o|a|os|as|do|da|dos|das|sobre o|sobre a|é o|é a|e o|e a)\s+/i, '').replace(/[?.!]+$/, '')
    if (ass) { const p = `${orig.replace(/[?\s]*$/, '')} (${escolha})?`; return { ...base, pergunta: p, consulta: `${ass} ${escolha}`, assunto: ass, dominio: DOMINIOS.find((d) => d.gatilho.test(nrm(escolha)))?.id || null, seguimento: true, esclarecimento: true, motivo: `esclarecimento: "${escolha}" para "${ass}"` } }
  }
  // 3) continuação curta sem assunto próprio ("e quem criou?", "em que ano?", "e o preço?", "e ele?")
  const curta = s.split(/\s+/).length <= 8, comecaE = /^(e|mas e|e quanto|e sobre|e o|e a|e os|e as|e ele|e ela)\b/.test(s)
  const pronome = /\b(ele|ela|eles|elas|isso|disso|dele|dela|deles|delas|nele|nela|desse|dessa|deste|desta)\b/.test(s)
  // só um número/quantidade ("e dois?", "e 5?") não é pergunta sobre o assunto anterior (não vira "dois — Tim Maia"):
  // se continuar uma conta, o motor de quantidades resolve; senão a IA interpreta pelo histórico ou pergunta
  const soQuantidade = /^(e|mas e|e se for|agora|na verdade)?\s*(\d+(?:[.,]\d+)?|um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez|o dobro|a metade|o triplo)\s*[?.!]*$/.test(s)
  if (curta && usuarios.length && !soQuantidade && (comecaE || pronome || !temAssuntoProprio(t.replace(/^(e|mas e)\s+/i, ''))) && !/^(sim|nao|não|ok|beleza|blz|obrigad|valeu|oi|ola|bom dia|boa tarde|boa noite)\b/.test(s)) {
    for (const u of [...usuarios].reverse().slice(0, 4)) {
      if (!temAssuntoProprio(u.replace(/^(e|mas e)\s+/i, ''))) continue // a anterior também era continuação: o assunto está antes dela
      const ass = assuntoDe(u)
      if (!ass || nrm(t).includes(nrm(ass))) continue
      const sem = t.replace(/^(e|mas e)\s+/i, '').replace(/[?\s]*$/, '')
      const p = (pronome ? sem.replace(/\b(ele|ela|isso|disso|dele|dela|nele|nela|desse|dessa)\b/i, (w) => (/^d/.test(w) ? `de ${ass}` : /^n/.test(w) ? `em ${ass}` : ass)) : `${sem} ${/^(e|o|a)$/i.test(ass) ? '' : '— ' + ass}`).trim() + '?'
      const av = AVALIACAO.test(t)
      return { ...base, pergunta: p, consulta: av ? `${ass}${dom && !nrm(ass).includes(dom.termo) ? ' ' + dom.termo : ''} avaliação` : `${ass} ${sem.replace(/\b(ele|ela|isso|disso|dele|dela|nele|nela)\b/gi, '').trim()}`.trim(), assunto: ass, dominio: dom?.id || null, seguimento: true, avaliacao: av, motivo: `continuação do assunto "${ass}"` }
    }
  }
  // 4) avaliação de um nome/produto ("o jaguar é bom?") e domínio da conversa para o buscador
  const av = AVALIACAO.test(t), ass = assuntoDe(t.replace(AVALIACAO, ' ')) || ''
  if (av && ass) return { ...base, consulta: `${ass}${dom && !nrm(ass).includes(dom.termo) ? ' ' + dom.termo : ''} avaliação`, assunto: ass, dominio: dom?.id || null, avaliacao: true, motivo: `avaliação de "${ass}"${dom ? ` (domínio da conversa: ${dom.termo})` : ''}` }
  if (dom && ass && !dom.gatilho.test(nrm(t))) return { ...base, consulta: `${ass} ${dom.termo}`, assunto: ass, dominio: dom.id, motivo: `domínio da conversa: ${dom.termo}` }
  return base
}
/** Instrução curta para a IA quando a mensagem foi entendida pelo contexto (vai junto da memória da conversa). */
export function notaParaIA(r: Resolvido): string {
  if (!r.seguimento && !r.avaliacao && !r.dominio) return ''
  const partes = [r.seguimento ? `Esta mensagem continua a conversa: entenda como "${r.pergunta}"${r.assunto ? ` (assunto: ${r.assunto})` : ''}. Não troque de assunto nem pergunte de novo o que já foi dito.` : '']
  if (r.dominio) { const d = DOMINIOS.find((x) => x.id === r.dominio); if (d && r.assunto) partes.push(`Pelo contexto da conversa, "${r.assunto}" se refere ao sentido ligado a ${d.termo} — não confunda com outro significado do mesmo nome.`) }
  if (r.avaliacao) partes.push('É um pedido de avaliação: responda com prós e contras objetivos do que as fontes dizem, sem inventar notas ou preços.')
  return partes.filter(Boolean).join(' ')
}
