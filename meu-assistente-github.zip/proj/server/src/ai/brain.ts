// Cérebro: respostas aprendidas reutilizadas sem gastar IA.
// Similaridade simples por palavras (Dice) — suficiente para perguntas curtas em português.
import { q, one, nowIso } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import { BRAIN_DEFAULT } from '../lib/panel-defaults.js'
/** Configuração do Cérebro SEMPRE com os padrões: salvar só o "modo das IAs" não pode desligar o aprendizado nem o "Cérebro primeiro". */
const brainCfg = async () => ({ ...BRAIN_DEFAULT, ...(await getConfig<any>('brain', {})) }) as any
import type { SessionUser } from '../lib/session.js'
import { validateRule, SCOPES } from './rules.js'
import { detectConflicts, type Conflito } from './brain-conflicts.js'
import { invalidateKnowledge } from './knowledge.js'
import type { Uso } from './brain-usage.js'

const norm = (t: string) =>
  t.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

// perguntas que dependem do momento, de dados pessoais ou do contexto da conversa nunca são aprendidas nem reutilizadas
const VOLATIL = /\b(hoje|agora|amanha|ontem|semana|mes|ano|meu|minha|meus|minhas|eu|me|tenho|saldo|gastei|gasto|gastos|conta|contas|agenda|compromisso|compromissos|tarefa|tarefas|lembrete|horas|hora|data|dia|cotacao|dolar|euro|bitcoin|btc|preco|valor|tempo|clima|chuva|noticia|noticias|ultimo|ultima|atual|proximo|proxima|isso|esse|essa|isto|ele|ela|anterior|acima|aqui|perto)\b/
export const isVolatile = (t: string) => VOLATIL.test(norm(t))
function dice(a: string, b: string): number {
  if (!a || !b) return 0
  const wa = new Set(a.split(' ').filter(w => w.length > 2))
  const wb = new Set(b.split(' ').filter(w => w.length > 2))
  if (!wa.size || !wb.size) return 0
  let inter = 0
  for (const w of wa) if (wb.has(w)) inter++
  return (2 * inter) / (wa.size + wb.size)
}

/** Perguntas parecidas mas com NÚMEROS diferentes ("faturou 18.000" × "faturou 20.000") não têm a mesma resposta. */
const numerosDe = (t: string) => (String(t).match(/\d+(?:[.,]\d+)*/g) || []).map((n) => n.replace(/[.,]/g, '')).sort().join(',')
const mesmoNumeros = (a: string, b: string) => numerosDe(a) === numerosDe(b)
export async function findLearnedAnswer(u: SessionUser, text: string): Promise<{ answer: string; id: number; version: number } | null> {
  const cfg = await brainCfg()
  if (!cfg.aprender && !cfg.cerebroPrimeiro) return null

  const qn = norm(text)
  if (qn.length < 4 || VOLATIL.test(qn)) return null

  const rows = await q(
    `SELECT id, question_norm, answer, uses, version FROM brain_answers
     WHERE (user_id = $1 OR user_id IS NULL) AND score >= 0.6 AND status = 'ativo' AND kind = 'resposta'
     ORDER BY score DESC, uses DESC LIMIT 40`,
    [u.id]
  )

  let best: { id: number; sim: number; answer: string; version: number } | null = null
  const { mesmoAssunto } = await import('./cerebro/relevancia.js')
  for (const r of rows) {
    const sim = dice(qn, r.question_norm)
    if (sim >= 0.75 && (!best || sim > best.sim) && mesmoNumeros(qn, String(r.question_norm)) && mesmoAssunto(qn, String(r.question_norm))) { // letras parecidas não bastam: o assunto precisa ser o mesmo
      best = { id: Number(r.id), sim, answer: r.answer, version: Number(r.version || 1) }
    }
  }

  if (!best) return null

  return { answer: best.answer, id: best.id, version: best.version } // o uso é contado no registro de uso (não mexe no cache)
}

export async function saveLearnedAnswer(u: SessionUser, question: string, answer: string, origin = 'ia') {
  const cfg = await brainCfg()
  if (!cfg.aprender) return

  const qn = norm(question)
  if (VOLATIL.test(qn)) return
  if (qn.length < 5 || answer.length < 10 || answer.length > 2000) return
  if ((qn.match(/\d+/g) || []).length >= 2) return // pergunta com números próprios (conta): a resposta vale só para aqueles números
  // não aprende respostas de ferramentas/cartões ou com marcadores especiais
  if (/⟦|\[\[|registrad|agendad|gasto|receita|pagamento|transfer/.test(answer.toLowerCase())) return

  // O que o assistente aprende sozinho NÃO vale na hora: fica PENDENTE até o administrador aprovar (Painel → Cérebro).
  // Decisões já tomadas são respeitadas: aprovado não é sobrescrito; rejeitado/desativado não volta a ser proposto.
  const existing = await one('SELECT id, status FROM brain_answers WHERE question_norm = $1 AND kind = $2 AND (user_id = $3 OR user_id IS NULL) ORDER BY id DESC LIMIT 1', [qn, 'resposta', u.id])
  if (existing) {
    if (existing.status === 'pendente') await q('UPDATE brain_answers SET answer = $1, updated_at = $2 WHERE id = $3', [answer.slice(0, 2000), nowIso(), existing.id])
    return
  }
  if (await one("SELECT id FROM brain_answers WHERE question_norm = $1 AND status <> 'rejeitado' AND status <> 'desativado'", [qn])) return // já existe como conhecimento
  const r = await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, kind, status, source, priority, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, 0.8, 'resposta', 'pendente', 'conversa', 40, $6, $6) RETURNING id`,
    [u.id, question.slice(0, 500), qn, answer.slice(0, 2000), origin, nowIso()]
  )
  const id = Number(r[0]?.id); if (id) { await snapshot(id, 'proposto a partir de uma conversa', origin === 'ia' ? 'IA' : origin); await brainLog(id, 'proposto', `aprendido na conversa: ${question.slice(0, 120)}`, 'sistema') }
}

/** Respostas globais (admin) — opcional para o futuro */
export async function saveGlobalAnswer(question: string, answer: string) {
  const qn = norm(question)
  if (qn.length < 5) return
  await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, created_at, updated_at)
     VALUES (NULL, $1, $2, $3, 'admin', 0.9, $4, $4)
     ON CONFLICT DO NOTHING`,
    [question.slice(0, 500), qn, answer.slice(0, 2000), nowIso()]
  )
}

/* ======================= CÉREBRO PRÓPRIO (conhecimento permanente) ======================= */
export const KINDS = ['conhecimento', 'regra', 'instrucao', 'experiencia', 'resposta'] as const
const STOP = new Set('a o os as um uma uns umas de da do das dos e ou em no na nos nas para pra por com sem que se ao aos como mais muito pouco sobre isso este esta esse essa ele ela eles elas voce voces seu sua seus suas ser estar ter tem foi sao e ja nao sim quando onde qual quais quem porque pois entao tambem ate cada todo toda todos todas'.split(' '))
export const keywordsOf = (t: string) => [...new Set(norm(t).split(' ').filter((w) => w.length > 3 && !STOP.has(w)))].slice(0, 30)
export async function brainLog(itemId: number | null, action: string, detail: string, actor = 'sistema') {
  try { await q('INSERT INTO brain_history (item_id, action, detail, actor, created_at) VALUES ($1,$2,$3,$4,$5)', [itemId, action, String(detail || '').slice(0, 300), actor, nowIso()]) } catch { /* histórico é opcional */ }
}
/** Já existe algo igual ou quase igual? (evita duplicidade) */
export async function findDuplicate(title: string, content: string) {
  const tn = norm(title), cn = norm(content).slice(0, 600)
  const rows = await q("SELECT id, question_norm, answer, status FROM brain_answers WHERE kind <> 'resposta' AND status <> 'rejeitado'")
  for (const r of rows) {
    if (r.question_norm === tn) return Number(r.id)
    if (dice(tn, r.question_norm) >= 0.85 && dice(cn, norm(String(r.answer)).slice(0, 600)) >= 0.7) return Number(r.id)
    if (cn.length > 40 && dice(cn, norm(String(r.answer)).slice(0, 600)) >= 0.9) return Number(r.id)
  }
  return null
}
export const NATURES = ['consulta', 'diretriz', 'executavel'] as const
const clampPrio = (n: number, def = 50) => (Number.isFinite(n) ? Math.min(100, Math.max(1, Math.round(n))) : def)
/** Registra uma versão (conteúdo + quem mudou + motivo) do item. */
export async function snapshot(itemId: number, nota: string, actor: string) {
  const r = await one('SELECT question, answer, kind, nature, status, version FROM brain_answers WHERE id = $1', [itemId]); if (!r) return
  await q('INSERT INTO brain_versions (item_id, version, titulo, conteudo, kind, nature, status, changed_by, nota, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',
    [itemId, Number(r.version || 1), r.question, r.answer, r.kind, r.nature || null, r.status, String(actor || 'sistema').slice(0, 60), String(nota || '').slice(0, 200), nowIso()])
}
export async function addKnowledge(it: { titulo: string; conteudo: string; tipo?: string; origem?: string; status?: string; fonte?: string; natureza?: string; escopo?: string; prioridade?: number; regra?: any }, actor = 'sistema') {
  const titulo = String(it.titulo || '').trim().slice(0, 200), conteudo = String(it.conteudo || '').trim().slice(0, 4000)
  if (titulo.length < 3 || conteudo.length < 5) return { ok: false, motivo: 'curto demais' }
  const dup = await findDuplicate(titulo, conteudo)
  if (dup) return { ok: false, duplicado: dup, motivo: 'já existe' }
  let kind = (KINDS as readonly string[]).includes(String(it.tipo)) ? String(it.tipo) : 'conhecimento'
  const status = ['ativo', 'pendente'].includes(String(it.status)) ? String(it.status) : 'pendente'
  const natureza = (NATURES as readonly string[]).includes(String(it.natureza)) ? String(it.natureza) : null
  const escopo = (SCOPES as readonly string[]).includes(String(it.escopo)) ? String(it.escopo) : 'chat'
  let ra: string | null = null, rt: string | null = null, rp: string | null = null, rau: string | null = null
  if (natureza === 'executavel') { const v = validateRule(it.regra, escopo); ra = v.acao; rt = JSON.stringify(v.gatilho); rp = JSON.stringify(v.params); rau = v.publico; kind = 'regra' }
  const origem = String(it.origem || 'admin').slice(0, 40)
  const prio = clampPrio(Number(it.prioridade), origem === 'admin' ? 70 : 50)
  const r = await q(`INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, kind, status, source, keywords, nature, scope, priority, rule_action, rule_trigger, rule_params, rule_audience, created_at, updated_at) VALUES (NULL,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$17) RETURNING id`,
    [titulo, norm(titulo), conteudo, origem, status === 'ativo' ? 0.9 : 0.5, kind, status, String(it.fonte || '').slice(0, 200) || null, keywordsOf(titulo + ' ' + conteudo).join(' '), natureza, escopo, prio, ra, rt, rp, rau, nowIso()])
  const id = Number(r[0]?.id)
  await snapshot(id, status === 'ativo' ? 'criado e aprovado' : 'proposto', actor)
  await brainLog(id, status === 'ativo' ? 'aprendido' : 'proposto', `${kind}${natureza ? '/' + natureza : ''}: ${titulo}`, actor)
  invalidateKnowledge()
  const conflitos = await detectConflicts(id).catch(() => [] as Conflito[])
  return { ok: true, id, status, conflitos }
}
/** Edita um item. Mudou conteúdo/natureza/escopo/regra → nova VERSÃO (com cópia do que ficou). Só prioridade → sem nova versão. */
export async function updateItem(id: number, p: any, actor: string) {
  const row = await one('SELECT * FROM brain_answers WHERE id = $1', [id]); if (!row) return { ok: false, naoEncontrado: true as const }
  const titulo = String(p.titulo ?? '').trim().slice(0, 200) || row.question, conteudo = String(p.conteudo ?? '').trim().slice(0, 4000) || row.answer
  let kind = (KINDS as readonly string[]).includes(p.tipo) ? p.tipo : row.kind
  const natureza = p.natureza !== undefined ? ((NATURES as readonly string[]).includes(p.natureza) ? p.natureza : null) : (row.nature || null)
  const escopo = (SCOPES as readonly string[]).includes(p.escopo) ? p.escopo : (row.scope || 'chat')
  const prioridade = p.prioridade !== undefined ? clampPrio(Number(p.prioridade), Number(row.priority)) : Number(row.priority ?? 50)
  let ra: string | null = null, rt: string | null = null, rp: string | null = null, rau: string | null = null
  if (natureza === 'executavel') {
    const atual = { acao: row.rule_action, gatilho: (() => { try { return JSON.parse(row.rule_trigger || '[]') } catch { return [] } })(), params: (() => { try { return JSON.parse(row.rule_params || '{}') } catch { return {} } })(), publico: row.rule_audience }
    const v = validateRule(p.regra ?? atual, escopo); ra = v.acao; rt = JSON.stringify(v.gatilho); rp = JSON.stringify(v.params); rau = v.publico; kind = 'regra'
  }
  const mudou = titulo !== row.question || conteudo !== row.answer || kind !== row.kind || natureza !== (row.nature || null) || escopo !== (row.scope || 'chat') || ra !== (row.rule_action || null) || rt !== (row.rule_trigger || null) || rp !== (row.rule_params || null) || rau !== (row.rule_audience || null)
  const mudouPrio = prioridade !== Number(row.priority ?? 50)
  if (!mudou && !mudouPrio) return { ok: true, versao: Number(row.version || 1), semMudanca: true, conflitos: [] as Conflito[] }
  const versao = Number(row.version || 1) + (mudou ? 1 : 0)
  await q('UPDATE brain_answers SET question = $1, question_norm = $2, answer = $3, kind = $4, nature = $5, scope = $6, priority = $7, rule_action = $8, rule_trigger = $9, rule_params = $10, rule_audience = $11, keywords = $12, reviewed = $13, version = $14, updated_at = $15 WHERE id = $16',
    [titulo, norm(titulo), conteudo, kind, natureza, escopo, prioridade, ra, rt, rp, rau, keywordsOf(titulo + ' ' + conteudo).join(' '), true, versao, nowIso(), id])
  if (mudou) await snapshot(id, 'editado pelo administrador', actor)
  await brainLog(id, 'editado', `${titulo} (v${versao}${mudouPrio && !mudou ? ', prioridade ' + prioridade : ''})`, actor)
  invalidateKnowledge()
  return { ok: true, versao, conflitos: await detectConflicts(id).catch(() => [] as Conflito[]) }
}
/** Aprovar, rejeitar, desativar e reativar. Aprovar/reativar confere conflitos com o que já está ativo e pede confirmação. */
export async function setStatus(id: number, acao: 'approve' | 'reject' | 'deactivate' | 'reactivate', actor: string, confirmar = false) {
  const row = await one('SELECT * FROM brain_answers WHERE id = $1', [id]); if (!row) return { ok: false, naoEncontrado: true as const }
  if (acao === 'deactivate' && row.status !== 'ativo') return { ok: false, motivo: 'Só é possível desativar um item ativo.' }
  if (acao === 'reactivate' && row.status !== 'desativado') return { ok: false, motivo: 'Só é possível reativar um item desativado.' }
  if (acao === 'approve' || acao === 'reactivate') {
    const todos = await detectConflicts(id).catch(() => [] as Conflito[])
    const ids = [...new Set(todos.map((c) => (c.a === id ? c.b : c.a)))]
    const ativos = new Set<number>(); if (ids.length) for (const r2 of await q(`SELECT id FROM brain_answers WHERE status = 'ativo' AND id IN (${ids.map((_, i) => '$' + (i + 1)).join(',')})`, ids)) ativos.add(Number((r2 as any).id)) // em lote (antes: 1 por conflito)
    const conflitos = todos.filter((c) => ativos.has(c.a === id ? c.b : c.a))
    if (conflitos.length && !confirmar) return { ok: false, precisaConfirmar: true as const, conflitos }
  }
  const agora = nowIso(), ver = Number(row.version || 1)
  if (acao === 'approve' || acao === 'reactivate') {
    // aprovado passa a integrar a base comum: itens aprendidos de um usuário deixam de ser privados dele
    await q("UPDATE brain_answers SET status = 'ativo', reviewed = $1, score = 0.9, approved_by = $2, approved_at = $3, user_id = NULL, updated_at = $3 WHERE id = $4", [true, actor, agora, id])
  } else if (acao === 'reject') await q("UPDATE brain_answers SET status = 'rejeitado', updated_at = $1 WHERE id = $2", [agora, id])
  else await q("UPDATE brain_answers SET status = 'desativado', updated_at = $1 WHERE id = $2", [agora, id])
  await snapshot(id, ({ approve: 'aprovado', reject: 'rejeitado', deactivate: 'desativado', reactivate: 'reativado' })[acao], actor)
  await brainLog(id, ({ approve: 'aprovado', reject: 'rejeitado', deactivate: 'desativado', reactivate: 'reativado' })[acao], `${row.question} (v${ver})`, actor)
  invalidateKnowledge()
  return { ok: true }
}
/** Separa um texto (de documento, de outra IA, de anotações) em conhecimentos organizados, sem IA. */
export function splitKnowledge(texto: string): { titulo: string; conteudo: string; tipo: string }[] {
  const out: { titulo: string; conteudo: string; tipo: string }[] = []
  const blocos = String(texto || '').replace(/\r/g, '').split(/\n\s*\n|(?=\n#{1,4}\s)|(?=\n\d+[.)]\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ])/).map((b) => b.trim()).filter((b) => b.length > 15)
  for (const b of blocos) {
    const linhas = b.split('\n').map((l) => l.trim()).filter(Boolean)
    let titulo = linhas[0].replace(/^#{1,4}\s*|^\d+[.)]\s*|^[-*•]\s*/, '').replace(/[:：]\s*$/, '')
    let conteudo = linhas.slice(1).join(' ').replace(/^[-*•]\s*/gm, '').trim()
    if (!conteudo || titulo.length > 90) { // parágrafo corrido: título com as primeiras palavras
      conteudo = linhas.join(' ').replace(/^#{1,4}\s*/, '')
      titulo = conteudo.split(/(?<=[.!?])\s/)[0].split(' ').slice(0, 9).join(' ').replace(/[.,;:]$/, '')
    }
    const n = norm(b)
    const tipo = /^(sempre|nunca|jamais|nao (deve|pode|use|diga|fale|responda)|evite|e proibido|obrigatorio|regra)\b/.test(norm(titulo)) || /^(sempre|nunca|jamais|evite|nao (deve|pode))\b/.test(norm(conteudo)) ? 'regra'
      : /^(como|passo|para (criar|fazer|registrar|configurar)|instrucao|procedimento)\b/.test(norm(titulo)) ? 'instrucao'
      : /\b(aprendi|experiencia|percebemos|descobrimos|funcionou|nao funcionou)\b/.test(n) ? 'experiencia' : 'conhecimento'
    out.push({ titulo: titulo.slice(0, 200), conteudo: conteudo.slice(0, 4000), tipo })
  }
  return out.slice(0, 80)
}
/* ---------- recuperação do conhecimento próprio ----------
   CAUSA RAIZ corrigida: a busca só olhava kind IN ('conhecimento','instrucao','experiencia') e com palavras idênticas.
   Itens aprovados classificados como 'regra' (bastava o texto ter "sempre"/"nunca") ou cadastrados como resposta do
   administrador ('resposta') ficavam invisíveis, e variações como "atendem"×"atendimento" ou plural não casavam. */
const stem = (w: string) => w.length <= 4 ? w : w.replace(/(oes|aes)$/, 'ao').replace(/ais$/, 'al').replace(/eis$/, 'el').replace(/(ns)$/, 'm').replace(/(es|s)$/, '')
const casa = (a: string, b: string) => a === b || (a.length >= 5 && b.length >= 5 && a.slice(0, 5) === b.slice(0, 5))
const stems = (t: string) => [...new Set(keywordsOf(t).map(stem))]
function pontua(qs: string[], titulo: string, conteudo: string, qn: string, rq: string) {
  if (!qs.length) return 0
  const ts = stems(titulo), cs = stems(conteudo.slice(0, 2500))
  const emTitulo = qs.filter((w) => ts.some((x) => casa(w, x))).length
  const emTudo = qs.filter((w) => ts.some((x) => casa(w, x)) || cs.some((x) => casa(w, x))).length
  const cobTitulo = ts.length ? emTitulo / Math.min(qs.length, ts.length) : 0
  return 0.55 * cobTitulo + 0.45 * (emTudo / qs.length) + (rq && dice(qn, rq) >= 0.6 ? 0.25 : 0)
}
/** Busca em TODO conhecimento ativo (conhecimentos, instruções, experiências, regras e respostas do administrador). */
export async function findKnowledge(text: string, minScore = 0.5, userId: number | null = null): Promise<{ id: number; titulo: string; conteudo: string; score: number; tipo: string } | null> {
  const qs = stems(text); if (!qs.length) return null
  const rows = (await (await import('./knowledge.js')).activeKnowledge()).filter((it) => it.user_id == null || it.user_id === userId).map((it) => ({ id: it.id, user_id: it.user_id, question: it.titulo, answer: it.conteudo, question_norm: it.qn, kind: it.kind, origin: it.origin, reviewed: it.reviewed }))
  const qn = norm(text); let best: any = null
  for (const r of rows) {
    const k = r.kind || 'resposta'
    // respostas aprendidas automaticamente das IAs continuam só por pergunta quase idêntica (findLearnedAnswer);
    // aqui entram as do administrador e as revisadas, para não responder outro assunto parecido
    if (k === 'resposta' && !(r.origin === 'admin' || r.reviewed === true || (r.reviewed as any) === 1)) continue
    const sc = pontua(qs, String(r.question || ''), String(r.answer || ''), qn, String(r.question_norm || ''))
    if (!best || sc > best.score) best = { id: Number(r.id), titulo: r.question, conteudo: r.answer, score: Math.round(sc * 100) / 100, tipo: k }
  }
  return best && best.score >= minScore ? best : null
}
/** Diretrizes ativas (orientação de comportamento) e conhecimento relacionado: entram no texto de sistema das IAs.
 *  Regras EXECUTÁVEIS não entram aqui: elas são cumpridas pelo sistema (rules.ts), com ou sem IA. */
/** `cerebro`: consulta ao Cérebro Central já feita (chat: ai/cerebro/integracao.ts). Sem ela, o chat usa a consulta
 *  simples (laboratório) e o agente de atendimento, quando autorizado, recebe só conhecimento GERAL aprovado. */
export async function brainContext(text: string, track?: Uso[], canal: 'chat' | 'agente' = 'chat', o: { cerebro?: { contexto: string } | null; onRastro?: (r: any) => void } = {}) {
  try {
    const K = await import('./knowledge.js')
    const dir = (await K.activeKnowledge()).filter((r) => K.escopoOk(r, canal) && ['diretriz', 'legado'].includes(K.naturezaDe(r))).sort((a, b) => b.priority - a.priority || a.id - b.id).slice(0, 30)
    const regras = dir.map((r) => `- ${r.titulo}: ${r.conteudo.slice(0, 300)}`)
    for (const r of dir) track?.push({ itemId: r.id, version: r.version, role: 'diretriz', action: 'contexto_ia', effect: `Orientou a IA ao gerar a resposta (${canal}): "${r.titulo}"` })
    const k = await K.answerKnowledge(text, null, 0.3, { canal })
    if (k) for (const u of K.usoDeConsulta(k, canal)) track?.push({ ...u, action: 'contexto_ia', effect: `Serviu de base para a resposta da IA: "${k.titulo}"` })
    return [regras.length ? `Regras do Meu Assistente (siga sempre; a primeira tem mais prioridade):\n${regras.join('\n')}` : '',
      o.cerebro ? o.cerebro.contexto // Cérebro Central: consulta obrigatória feita antes (biblioteca permanente, sem dados de usuários)
        : canal === 'chat' ? await (await import('./cerebro/central.js')).contextoChat(text).catch(() => '')
        : await (async () => { const r = await (await import('./cerebro/integracao.js')).recuperar(text, { canal: 'agente', pesquisar: false, incluirNaoRevisados: false }); o.onRastro?.(r); return r.contexto })().catch(() => ''), // módulo autorizado: só conhecimento geral aprovado
      k ? `Conhecimento aprovado relacionado à pergunta ("${k.titulo}"). Responda com base nele, sem contradizer e sem acrescentar condições, valores, prazos ou formas de entrega/pagamento que não estejam aqui:\n${k.resposta}` : '',
      'Nunca invente informações comerciais (preços, taxas, fretes, prazos, horários, formas de pagamento, entrega ou retirada). Se a informação não estiver no conhecimento aprovado, diga que não tem essa informação cadastrada. Perguntas hipotéticas ("se eu comprar R$ 100...") são sobre as regras, não sobre um pedido real.'].filter(Boolean).join('\n\n')
  } catch { return '' }
}
/** Correção do usuário ("não, o certo é…") vira um aprendizado pendente para revisão. */
export async function proposeCorrection(question: string, correction: string, userId: number) {
  const c = correction.replace(/^(nao|não)[,.!]?\s*/i, '').replace(/^(na verdade|o certo (e|é)|corrigindo|correção|correcao|errado)[:,]?\s*/i, '').trim()
  if (c.length < 8 || !question) return null
  return addKnowledge({ titulo: question.slice(0, 200), conteudo: c, tipo: 'conhecimento', origem: 'correção do usuário', status: 'pendente', fonte: 'conversa' }, 'usuário ' + userId)
}
