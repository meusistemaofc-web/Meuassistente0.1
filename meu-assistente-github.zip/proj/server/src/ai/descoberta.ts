// DESCOBERTA CONVERSACIONAL — perguntas curtas e oportunas que completam o contexto de quem tem pouco histórico. Faz parte do
// Motor de Aprendizagem Adaptativa (ai/adaptive.ts) e usa o aprendizado pelo uso real (ai/aprendizado-uso.ts):
//   • nada de questionário nem entrevista: no máximo UMA pergunta, só quando há um gatilho real no pedido ou na ação que acabou
//     de ser feita, e ela vem junto da resposta (ou, se a resposta depende dela, antes — e o pedido continua em seguida);
//   • a execução vem primeiro: perguntas "depois" só são acrescentadas a uma ação já concluída; o pedido nunca fica parado;
//   • não pergunta o que já sabe (memórias explícitas), nem o que dá para inferir com confiança pelo uso (padrões fortes);
//   • nível de contexto: novo (pergunta o essencial), parcial (só lacunas úteis), consolidado (não faz perguntas de descoberta);
//   • ritmo: no máximo uma pergunta de descoberta a cada 24 h, nunca duas seguidas, cada lacuna no máximo 2 vezes (30 dias de
//     intervalo se a pessoa ignorou) e nunca de novo depois de respondida.
// Onde fica: respostas = fatos explícitos em `memories` (origem 'pergunta_contextual', a página Minha memória mostra e apaga);
// confirmação de hábito = o próprio padrão em `learnings` (aprendizado-uso.confirmar); controle das perguntas = `learnings`
// kind 'descoberta' (interno, fora da fila de revisão); pergunta aberta = contexto da conversa (`convctx.descoberta`).
import type { SessionUser } from '../lib/session.js'
import { q, one, J, nowIso } from '../db/index.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
const DIA = 86400000
export type Nivel = 'novo' | 'parcial' | 'consolidado'
type Gap = 'natureza_agenda' | 'atividade' | 'objetivo_financas' | 'habito'
const UTILIDADE: Record<Gap, number> = { natureza_agenda: 0.9, atividade: 0.8, habito: 0.7, objetivo_financas: 0.6 }
const COMANDO = /^(?:(?:por favor|pfv|agora|entao|e|eu|quero|queria|preciso|me|pode|voce pode|vc pode)\s+)*(?:agend|mar[cq]|remar[cq]|desmar[cq]|cancel|registr|lan[cç]|anot|lembr|cri[ae]|cadastr|adicion|acrescent|inclu|colo[cq]|mud|alter|tro[cq]|corrij|corrig|exclu|apag|remov|tir[ae]|pesquis|procur|bus[cq]|mostr|list|envi|mand|pag[aou]|pagu|abr[ae]|fech|fa[cz]|ped[ei]|ver\b|veja|confirm|ajust|atualiz|defin|pass[ae]|qual|quais|quanto|quando|onde|como|gastei|paguei|recebi|comprei|vendi)\w*/

/* ---------- nível de contexto ---------- */
export async function nivel(u: SessionUser): Promise<{ nivel: Nivel; fatos: number; padroesFortes: number; registros: number }> {
  const fatos = Number((await one("SELECT COUNT(*) AS n FROM memories WHERE user_id = $1 AND active = TRUE", [u.id]))?.n || 0)
  const registros = Number((await one("SELECT COUNT(*) AS n FROM items WHERE user_id = $1 AND created_at >= $2", [u.id, new Date(Date.now() - 180 * DIA).toISOString()]))?.n || 0)
  // padrões fortes só importam com algum contexto já acumulado (usuário novo não paga essa leitura)
  const padroesFortes = registros >= 6 ? (await (await import('./aprendizado-uso.js')).padroes(u, { minConf: 0.75, fresco: registros < 60 })).length : 0
  const n: Nivel = (fatos >= 3 && padroesFortes >= 2) || registros >= 60 || (padroesFortes >= 4 && fatos >= 1) ? 'consolidado' : registros < 10 && fatos < 2 && padroesFortes === 0 ? 'novo' : 'parcial'
  return { nivel: n, fatos, padroesFortes, registros }
}

/* ---------- controle das perguntas (learnings kind 'descoberta') ---------- */
type Controle = { id?: number; vezes: number; perguntadoEm: string | null; respondidaEm: string | null; valor: string | null; ignorada: number }
async function controle(u: SessionUser, chave: string): Promise<Controle> {
  const r: any = await one("SELECT id, preference FROM learnings WHERE user_id = $1 AND kind = 'descoberta' AND context = $2", [u.id, chave])
  return r ? { id: Number(r.id), ...J<any>(r.preference, {}) } : { vezes: 0, perguntadoEm: null, respondidaEm: null, valor: null, ignorada: 0 }
}
async function gravarControle(u: SessionUser, chave: string, c: Controle) {
  const pref = JSON.stringify({ vezes: c.vezes, perguntadoEm: c.perguntadoEm, respondidaEm: c.respondidaEm, valor: c.valor, ignorada: c.ignorada }), now = nowIso()
  if (c.id) await q('UPDATE learnings SET preference = $1, rule = $2, updated_at = $3 WHERE id = $4 AND user_id = $5', [pref, c.valor ? `Respondeu: ${c.valor}` : 'Pergunta de contexto', now, c.id, u.id])
  else await q("INSERT INTO learnings (user_id, operation, kind, context, rule, preference, scope, confidence, frequency, uses, state, history, created_at, updated_at) VALUES ($1,'geral','descoberta',$2,$3,$4,'permanente',0.5,1,0,'ativo','[]',$5,$5)", [u.id, chave, c.valor ? `Respondeu: ${c.valor}` : 'Pergunta de contexto', pref, now])
}
async function ultimaPergunta(u: SessionUser): Promise<number> {
  const rows = await q("SELECT preference FROM learnings WHERE user_id = $1 AND kind = 'descoberta'", [u.id])
  return Math.max(0, ...(rows as any[]).map((r) => { const p = J<any>(r.preference, {}); return p.perguntadoEm ? new Date(p.perguntadoEm).getTime() : 0 }))
}
const memoria = async (u: SessionUser, prefixo: string) => (await one("SELECT content FROM memories WHERE user_id = $1 AND active = TRUE AND content LIKE $2 ORDER BY id DESC LIMIT 1", [u.id, prefixo + '%']).catch(() => null))?.content as string | undefined

/** Vale a pena perguntar AGORA? Utilidade × nível × ritmo × o que já se sabe. */
async function vale(u: SessionUser, gap: Gap, chave: string, nv: Nivel): Promise<boolean> {
  const A = await import('./adaptive.js'); if (!(await A.ativo(u))) return false // aprendizado desligado (painel ou pela pessoa): nada de descoberta
  if (nv === 'consolidado') return false
  if (nv === 'parcial' && UTILIDADE[gap] < 0.7) return false
  const c = await controle(u, chave), agora = Date.now()
  if (c.respondidaEm || c.vezes >= 2) return false
  if (c.perguntadoEm && agora - new Date(c.perguntadoEm).getTime() < 30 * DIA) return false
  if (agora - (await ultimaPergunta(u)) < DIA) return false // nunca uma pergunta atrás da outra
  return true
}
async function abrir(u: SessionUser, convId: string, gap: Gap, chave: string, extra: Record<string, unknown> = {}) {
  const c = await controle(u, chave); c.vezes++; c.perguntadoEm = nowIso(); await gravarControle(u, chave, c)
  const CX = await import('./convctx.js'), ctx = await CX.getCtx(convId, u.id); (ctx as any).descoberta = { gap, chave, em: nowIso(), ...extra }; await CX.saveCtx(convId, u.id, ctx)
}

/* ---------- conhecido / inferível ---------- */
async function naturezaConhecida(u: SessionUser): Promise<string | null> {
  const m = await memoria(u, 'Compromissos:'); if (m) return m
  const ap = await q("SELECT data FROM items WHERE user_id = $1 AND type = 'appointment' ORDER BY id DESC LIMIT 30", [u.id])
  const comCliente = (ap as any[]).filter((r) => { const d = J<any>(r.data, {}); return d.clienteNome || d.clienteTelefone || d.valorTotal }).length
  return ap.length >= 3 && comCliente / ap.length >= 0.7 ? 'inferido: trabalho' : null // atendimentos com clientes: dá para inferir sem perguntar
}
async function atividadeConhecida(u: SessionUser): Promise<boolean> {
  if (await memoria(u, 'Trabalha com:')) return true
  const fatos = await q("SELECT content FROM memories WHERE user_id = $1 AND active = TRUE ORDER BY id DESC LIMIT 60", [u.id])
  if ((fatos as any[]).some((r) => /\b(sou|trabalho (?:com|como|de)|minha profiss|atuo como|tenho um[a]? (?:loja|estudio|salao|clinica|empresa))\b/.test(nrm(r.content)))) return true
  return (await (await import('./aprendizado-uso.js')).padroes(u, { dom: 'servico_agenda', minConf: 0.75 })).length > 0 // serviço recorrente já diz a atividade
}

/* ---------- ANTES: o pedido depende da resposta ("quero organizar meus compromissos") ---------- */
// só o pedido geral de organizar COMPROMISSOS/AGENDA (o exemplo do pedido); "organize minha semana", "reorganizar meus horários"
// e afins já têm execução própria (planos em segundo plano, sugestões da agenda) e nunca são interrompidos por uma pergunta
const ORGANIZAR = /^(?:(?:eu|quero|queria|preciso|gostaria de|me ajuda a|ajuda a|vamos|pode|por favor)\s+)*(?:organiz\w*|arrum\w*)\s+(?:os |as |meus |minhas |a |o )?(?:compromissos|agenda|minha agenda)\s*$/
export async function antes(u: SessionUser, convId: string, text: string): Promise<string | null> {
  if (!convId) return null
  const s = nrm(text)
  if (!ORGANIZAR.test(s) || s.split(' ').length > 14) return null
  if (await naturezaConhecida(u)) return null
  const nv = (await nivel(u)).nivel
  if (!(await vale(u, 'natureza_agenda', 'natureza_agenda', nv))) return null
  await abrir(u, convId, 'natureza_agenda', 'natureza_agenda', { original: String(text).slice(0, 500) })
  return 'Claro! São compromissos pessoais, de trabalho ou os dois?'
}

/* ---------- DEPOIS: a ação já foi feita; uma pergunta curta pode melhorar as próximas ---------- */
export async function depois(u: SessionUser, convId: string, resposta: string, desde: string): Promise<string> {
  if (!convId || /\?\s*(⟦[^⟧]*⟧\s*)*$/.test(String(resposta).trim())) return '' // a resposta já pergunta algo: nada de empilhar perguntas
  if (!/⟦(appt|fin):|Agendei|Vou te lembrar|[Rr]egistr|Criei|Cadastrei|Anotad|Já registrei|Pronto!/.test(resposta)) return '' // sem ação concluída neste turno: nem consulta o banco
  const novos = (await import('./aprendizado-uso.js')).acoesDesde(u.id, desde)
  if (!novos.length) return '' // só depois de uma AÇÃO concluída neste turno (registradas por createItem, sem consulta)
  // a conversa só é lida quando já há uma pergunta candidata (pendência ou pergunta aberta: nada de empilhar)
  const livre = async () => { const ctx: any = await (await import('./convctx.js')).getCtx(convId, u.id); return !ctx.descoberta && !ctx.pendente }
  const AU = await import('./aprendizado-uso.js')
  let nv: Nivel | null = null; const nivelAgora = async () => (nv ??= (await nivel(u)).nivel) // calculado só se houver candidata
  for (const r of novos as any[]) {
    const d = typeof r.data === 'string' ? J<any>(r.data, {}) : (r.data || {})
    // hábito: o 2º–4º pedido igual (lembrete, tarefa, conta) — é rotina ou foi coincidência? (uma consulta dirigida)
    if (['reminder', 'task', 'bill'].includes(r.type)) {
      const dom = r.type === 'reminder' ? 'lembrete' : r.type === 'task' ? 'tarefa' : 'conta', campo = (x: any) => r.type === 'reminder' ? x.message : r.type === 'task' ? x.title : x.name, ch = AU.chaveDe(campo(d))
      if (ch) {
        // contagem em memória (calculada com os padrões e atualizada a cada ação): sem consulta no turno; ainda não calculada
        // neste processo → a pergunta espera a próxima repetição (é opcional; nunca atrasa a resposta)
        const iguais = AU.contagem(u.id, dom as any, ch); if (iguais == null) continue
        if (iguais >= 2 && iguais <= 4 && !(await controle(u, `habito:${dom}:${ch}`)).perguntadoEm && await vale(u, 'habito', `habito:${dom}:${ch}`, await nivelAgora()) && await livre()) {
          await abrir(u, convId, 'habito', `habito:${dom}:${ch}`, { dom, ch })
          return `Esse ${dom === 'lembrete' ? 'lembrete' : dom === 'tarefa' ? 'tipo de tarefa' : 'pagamento'} de "${String(campo(d)).replace(/\s+(?:com|para|pra)\s+.*$/i, '').trim()}" costuma se repetir (toda semana, todo mês)?`
        }
      }
    }
    // atividade: atendimento com cliente e a atividade ainda desconhecida
    if (r.type === 'appointment' && (d.clienteNome || d.person) && !(await controle(u, 'atividade')).respondidaEm && await vale(u, 'atividade', 'atividade', await nivelAgora()) && !(await atividadeConhecida(u)) && await livre()) {
      await abrir(u, convId, 'atividade', 'atividade')
      return 'Aliás, esses atendimentos são do seu trabalho com o quê? Assim eu já entendo melhor os próximos pedidos.'
    }
    // finanças: a partir do 3º gasto, o jeito de acompanhar
    if (r.type === 'expense' && !(await controle(u, 'objetivo_financas')).perguntadoEm) {
      const n = Number((await one("SELECT COUNT(*) AS n FROM items WHERE user_id = $1 AND type = 'expense'", [u.id]))?.n || 0)
      if (n >= 3 && !(await memoria(u, 'Finanças:')) && await vale(u, 'objetivo_financas', 'objetivo_financas', await nivelAgora()) && await livre()) { await abrir(u, convId, 'objetivo_financas', 'objetivo_financas'); return 'Quer que eu acompanhe quanto você gasta por categoria ao longo do mês, ou prefere só registrar?' }
    }
  }
  return ''
}

/* ---------- RESPOSTA à pergunta aberta (mensagem seguinte) ---------- */
const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)
async function fato(u: SessionUser, convId: string, conteudo: string, kind = 'fact') {
  const { addMemory } = await import('../routes/memory.js')
  const prefixo = conteudo.split(':')[0] + ':'
  await q("UPDATE memories SET active = FALSE, updated_at = $1 WHERE user_id = $2 AND active = TRUE AND content LIKE $3", [nowIso(), u.id, prefixo + '%']) // a resposta nova substitui a anterior do mesmo assunto
  await addMemory(u.id, conteudo, kind, 'pergunta_contextual', convId || null)
}
/** null = a mensagem não responde (segue o fluxo normal e a pergunta é deixada de lado sem insistir). */
export async function responder(u: SessionUser, convId: string, text: string): Promise<{ ack: string; original?: string } | null> {
  if (!convId) return null
  const CX = await import('./convctx.js'), ctx: any = await CX.getCtx(convId, u.id), d = ctx.descoberta
  if (!d) return null
  const s = nrm(text), curta = s.split(' ').length <= 12
  const fecha = async (valor: string | null) => {
    delete ctx.descoberta; await CX.saveCtx(convId, u.id, ctx)
    const c = await controle(u, d.chave); if (valor) { c.respondidaEm = nowIso(); c.valor = valor } else c.ignorada++; await gravarControle(u, d.chave, c)
  }
  // agradecimento/confirmação solta não é resposta (nunca vira "Trabalha com: ok")
  if (/^(ok|okay|certo|beleza|blz|obrigad\w*|valeu|vlw|ta|ta bom|show|legal|entendi|perfeito|otimo|top|massa|kkk+|haha+)$/.test(s) || (d.gap === 'atividade' && /^(sim|s|nao|n|isso|pode|pode ser|claro|confirmo|confirma)$/.test(s))) { await fecha(null); return null }
  // passou muito tempo ou a mensagem é outro pedido: não insiste
  if (Date.now() - new Date(d.em).getTime() > 6 * 3600_000 || !curta) { await fecha(null); return null }
  if (d.gap === 'natureza_agenda') {
    const tr = /\b(trabalho|profission\w*|clientes?|servic\w*|empresa|negocio|atendimentos?)\b/.test(s), pe = /\b(pessoa\w*|particular\w*|familia|casa|vida pessoal)\b/.test(s)
    const v = /\b(os dois|ambos|as duas|tudo|dois|mist\w*)\b/.test(s) || (tr && pe) ? 'pessoais e de trabalho' : tr ? 'de trabalho' : pe ? 'pessoais' : null
    if (!v) { if (COMANDO.test(s)) { await fecha(null); return null } await fecha(null); return { ack: 'Tudo bem!', original: d.original } }
    await fato(u, convId, `Compromissos: ${v}.`); await fecha(v)
    return { ack: v === 'de trabalho' ? 'Certo, compromissos de trabalho.' : v === 'pessoais' ? 'Certo, compromissos pessoais.' : 'Certo, pessoais e de trabalho.', original: d.original }
  }
  if (d.gap === 'atividade') {
    if (COMANDO.test(s) || /^(nao|depois|agora nao|prefiro nao|deixa)\b/.test(s)) { await fecha(null); return /^(nao|depois|agora nao|prefiro nao|deixa)\b/.test(s) && s.split(' ').length <= 4 ? { ack: 'Sem problema!' } : null }
    const v = String(text).trim().replace(/^(?:eu\s+)?(?:sou|trabalho\s+(?:com|como|de)|atuo\s+(?:com|como)|com|de)\s+/i, '').replace(/^(?:um|uma|o|a)\s+/i, '').replace(/[.!]+$/, '').trim()
    if (!v || v.split(/\s+/).length > 8) { await fecha(null); return null }
    await fato(u, convId, `Trabalha com: ${v}.`); await fecha(v)
    return { ack: `Entendi, ${v.toLowerCase()}! Vou considerar isso nos próximos pedidos.` }
  }
  if (d.gap === 'objetivo_financas') {
    const ac = /\b(acompanh\w*|categori\w*|mes|mensal|controle|controlar|resumo|sim|quero)\b/.test(s), so = /\b(so registr\w*|apenas registr\w*|so anot\w*|so isso|nao precisa|nao)\b/.test(s)
    const v = so && !/\bsim\b/.test(s) ? 'só registrar os gastos' : ac ? 'acompanhar os gastos por categoria no mês' : null
    if (!v) { await fecha(null); return null }
    await fato(u, convId, `Finanças: prefere ${v}.`, 'preference'); await fecha(v)
    return { ack: v.startsWith('só') ? 'Combinado, só registro.' : 'Combinado! Vou acompanhar seus gastos por categoria ao longo do mês.' }
  }
  if (d.gap === 'habito') {
    const AU = await import('./aprendizado-uso.js')
    const sim = /^(sim|s|isso|e|eh|costuma|todo|toda|sempre|semanal\w*|mensal\w*|diari\w*|repete|com certeza|claro)\b/.test(s) || /\b(toda semana|todo mes|todo dia|todos os meses|toda segunda|toda sexta)\b/.test(s)
    const nao = /^(nao|n|foi so|so dessa|so desta|uma vez|pontual|coincid\w*|raramente)\b/.test(s)
    if (!sim && !nao) { await fecha(null); return null }
    await AU.atualizar(u, { forcar: true }); await AU.confirmar(u, d.dom, d.ch, sim); await fecha(sim ? (s.match(/\b(toda semana|todo mes|todo dia|semanal\w*|mensal\w*|diari\w*)\b/)?.[1] || 'sim') : 'não')
    return { ack: sim ? 'Anotado! Vou lembrar disso nas próximas vezes.' : 'Certo, fica como algo pontual.' }
  }
  await fecha(null); return null
}
