// ARQUITETURA MULTIAGENTE (Fase 4) — coordenador central + agentes internos que colaboram numa mesma solicitação.
// Reaproveita o que já existe: análise da mensagem (cognition), especialistas de domínio e plano (Nível 2), ferramentas
// SOMENTE-LEITURA (assistant.lerDados), motor de IA com rotas por tarefa ('analise', 'pesquisa' com busca, 'conversa'),
// contexto comercial (commercial.ts) e a autoverificação. O usuário continua falando com UM assistente: os agentes
// produzem contribuições internas, e a IA principal (que também é a EXECUÇÃO, com as ferramentas) consolida tudo.
// Seleção: só pedidos COMPLEXOS mobilizam agentes, no máximo N (padrão 3), em até duas ondas, com prazo e disjuntor.
import { etapa } from '../lib/etapas.js'
import { getConfig } from '../lib/settings.js'
import { q, J } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import type { Analise } from './cognition.js'
import type { Selecao } from './especialistas.js'
import type { Plano } from './planejador.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
type Msg = { role: string; content: string | null }
type Tool = { function: { name: string } }

export const MA_DEFAULT = { ativo: true, maxAgentes: 3, tempoMaxMs: 9000, agentes: { pesquisa: true, analise: true, escrita: true, vendas: true, planejamento: true } as Record<string, boolean> }
export type MaCfg = typeof MA_DEFAULT & { atualizadoEm?: string }
export const maCfg = async (): Promise<MaCfg> => { const c = await getConfig<any>('multiagente', {}); return { ...MA_DEFAULT, ...c, agentes: { ...MA_DEFAULT.agentes, ...(c.agentes || {}) } } }

/* ======================= agentes ======================= */
type Acesso = 'historico' | 'memorias' | 'dados' | 'notas' | 'comercial' | 'experiencias' | 'previsoes'
export interface Agente { id: string; nome: string; papel: string; onda: 1 | 2; tarefa: 'pesquisa' | 'analise' | 'conversa'; gatilho: RegExp; ve: Acesso[]; instrucao: string }
export const AGENTES: Agente[] = [
  { id: 'pesquisa', nome: 'Pesquisa e investigação', papel: 'pesquisa e investigação', onda: 1, tarefa: 'pesquisa', ve: [],
    gatilho: /\b(pesquis\w*|investig\w*|procur\w* na (internet|web)|busc\w* na (internet|web)|na internet|noticias?|ultimas? novidades|cotac\w*|preco atual|precos? (atuais|de mercado|medio)|tendencias?|concorrent\w*|o que (esta|ta) acontecendo|dados atuais|panorama)\b/,
    instrucao: 'Levante FATOS atuais e verificáveis sobre o tema, cada um com a fonte (nome do site). Se você não tiver acesso à web, responda exatamente "SEM ACESSO À PESQUISA" e não invente nada.' },
  { id: 'analise', nome: 'Análise e raciocínio', papel: 'análise e raciocínio', onda: 2, tarefa: 'analise', ve: ['dados', 'notas', 'historico', 'experiencias', 'previsoes'],
    gatilho: /\b(analis\w*|compar\w*|avali\w*|vale a pena|pros e contras|vantagens e desvantagens|diagnostic\w*|por que (minhas?|meus?|estou|esta|caiu|caiam|aument\w*)|qual (e |seria )?(a )?melhor (opcao|escolha|estrategia|caminho)|cenario\w*|riscos?|impacto|viabilidade|onde (posso|devo) (cortar|economizar|melhorar))\b/,
    instrucao: 'Analise a situação: o que os dados mostram, causas prováveis, riscos e a melhor opção com justificativa. Separe FATOS (dos dados) de HIPÓTESES. Não invente números.' },
  { id: 'vendas', nome: 'Vendas e negócios', papel: 'vendas e negócios', onda: 2, tarefa: 'analise', ve: ['dados', 'notas', 'comercial', 'experiencias', 'previsoes'],
    gatilho: /\b(vend\w*|propostas? comercia\w*|orcamentos? para clientes?|precific\w*|promoc\w*|marketing|campanha\w*|funil|leads?|convers(ao|oes)|ticket medio|faturamento|captar clientes|fidelizar|margem|clientes? (parad\w*|inativ\w*|novos?))\b/,
    instrucao: 'Olhe pelo lado comercial: oportunidades, argumentos, preço e margem, próximos passos com clientes. Use só os dados fornecidos. Nunca diga que enviou mensagens ou campanhas.' },
  { id: 'planejamento', nome: 'Planejamento e organização', papel: 'planejamento e organização', onda: 2, tarefa: 'analise', ve: ['dados', 'notas', 'memorias', 'experiencias', 'previsoes'],
    gatilho: /\b(planej\w*|organiz\w* (minha|meu|a|o)|cronograma|plano (de|para|completo)|estrategi\w*|metas?|prioriz\w*|rotina|como (comecar|me organizar))\b/,
    instrucao: 'Monte um plano em etapas numeradas, com prioridade e prazo sugerido; marque o que depende do usuário e o que o assistente pode fazer com as ferramentas (agenda, tarefas, lembretes).' },
  { id: 'escrita', nome: 'Escrita e comunicação', papel: 'escrita e comunicação', onda: 2, tarefa: 'conversa', ve: ['notas', 'memorias', 'historico'],
    gatilho: /\b(escrev\w*|redi[gj]\w*|redacao|texto (para|pra|sobre)|mensagem (para|pra)|e-?mail|post\b|legenda|carta|roteiro (de|para) (video|apresentacao)|discurso|bio\b|anuncio|comunicado)\b/,
    instrucao: 'Redija o texto pedido como rascunho pronto para uso, no tom certo para o destinatário, usando as contribuições como base. Não invente dados; deixe [campos] para o que faltar.' },
]
/** Agentes que já existem como etapas do fluxo (não fazem chamada extra): mostrados no painel e registrados na coordenação. */
export const AGENTES_FLUXO = [
  { id: 'execucao', nome: 'Execução de tarefas', desc: 'A IA principal com as ferramentas autorizadas (agenda, tarefas, finanças, CRM…) — única que grava, sempre com as confirmações existentes.' },
  { id: 'auditoria', nome: 'Auditoria e verificação', desc: 'Conferência do Nível 1 e autoverificação do Nível 2 + verificação de divergências entre agentes e de resposta fragmentada.' },
  { id: 'planejador', nome: 'Planejador de ações', desc: 'Planejamento determinístico de etapas com ferramentas (Nível 2), sem chamada extra de IA.' },
]

/* ======================= complexidade e seleção ======================= */
export interface Complexidade { nivel: 'simples' | 'moderada' | 'complexa'; pontos: number; motivos: string[]; candidatos: { id: string; pontos: number }[] }
export function avaliarComplexidade(text: string, an: Analise, sel: Selecao | null, plano: Plano | null, lista: Agente[] = AGENTES): Complexidade {
  const s = nrm(text), motivos: string[] = []; let p = 0
  if (['saudacao', 'agradecimento', 'confirmacao', 'negacao'].includes(an.tipo)) return { nivel: 'simples', pontos: 0, motivos: ['mensagem curta de conversa'], candidatos: [] }
  const candidatos = lista.map((a) => ({ id: a.id, pontos: (s.match(new RegExp(a.gatilho.source, 'g')) || []).length })).filter((c) => c.pontos > 0)
  if (sel?.ids.includes('negocio') || sel?.ids.includes('crm')) { const v = candidatos.find((c) => c.id === 'vendas'); if (v) v.pontos++ }
  if (text.length > 160) { p++; motivos.push('pedido longo') } if (text.length > 350) p++
  if ((text.match(/\?/g) || []).length >= 2) { p++; motivos.push('várias perguntas') }
  if ((plano?.etapas.length || 0) >= 3) { p += 2; motivos.push('várias ações') }
  const dominios = (sel?.ids || []).filter((x) => x !== 'geral').length; if (dominios >= 2) { p++; motivos.push('mais de um domínio') }
  if (candidatos.length) { p += Math.min(4, candidatos.reduce((a, c) => a + c.pontos, 0) + candidatos.length); motivos.push('pede ' + candidatos.map((c) => lista.find((a) => a.id === c.id)!.papel).join(', ')) }
  const nivel = candidatos.length >= 2 || p >= 5 ? 'complexa' : p >= 2 ? 'moderada' : 'simples'
  return { nivel, pontos: p, motivos, candidatos: candidatos.sort((a, b) => b.pontos - a.pontos) }
}
/** Só pedidos complexos mobilizam agentes; no máximo N, entre os ligados e fora do disjuntor. */
export function selecionarAgentes(c: Complexidade, cfg: MaCfg, lista: Agente[] = AGENTES): Agente[] {
  if (c.nivel !== 'complexa') return []
  return c.candidatos.filter((x) => cfg.agentes[x.id] !== false && !pausado(x.id)).slice(0, Math.max(0, Math.min(5, cfg.maxAgentes))).map((x) => lista.find((a) => a.id === x.id)!)
}
/** Fase 9: lista de agentes com os especialistas do Laboratório (novos ou versões que substituem um agente existente). */
export function mesclar(extras: Agente[] = []): Agente[] {
  if (!extras.length) return AGENTES
  const sub = new Map(extras.filter((e) => (e as any).base).map((e) => [(e as any).base as string, e]))
  return [...AGENTES.map((a) => { const x = sub.get(a.id); return x ? { ...a, instrucao: x.instrucao, nome: a.nome, papel: a.papel, ve: x.ve, versaoLab: (x as any).versaoLab } as Agente : a }), ...extras.filter((e) => !(e as any).base)]
}

/* ======================= disjuntor por agente (falhas seguidas pausam o agente por 10 min) ======================= */
const FALHAS = new Map<string, number[]>()
export function pausado(id: string) { const f = (FALHAS.get(id) || []).filter((t) => Date.now() - t < 600_000); FALHAS.set(id, f); return f.length >= 3 }
function falhou(id: string) { FALHAS.set(id, [...(FALHAS.get(id) || []), Date.now()]) }
export function zerarDisjuntores() { FALHAS.clear() }

/* ======================= quadro compartilhado (acesso controlado) ======================= */
const SENSIVEIS = /([\w.+-]+@[\w-]+\.[\w.]+|\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b|\(?\b\d{2}\)?\s?9?\d{4}-?\d{4}\b|\b(?:\d[ -]?){13,19}\b)/g
/** O que sai para a PESQUISA na web: só o pedido, sem e-mails, telefones, documentos, memórias ou dados do usuário. */
export const paraPesquisa = (text: string) => String(text).replace(SENSIVEIS, '[omitido]').slice(0, 500)
export interface Quadro { pedido: string; intencao: string; complexidade: string; dominios: string[]; plano: string[]; memorias: string[]; experiencias: string[]; dados: Record<string, string>; historico: string; comercial: string; notas: Record<string, string>; previsoes?: string[]; achados?: (agente: string) => string }
export function fatia(a: Agente, q: Quadro, nomes: Agente[] = AGENTES): string {
  const L = [`Pedido: ${a.id === 'pesquisa' ? paraPesquisa(q.pedido) : q.pedido}`, `Intenção: ${q.intencao} · complexidade ${q.complexidade}${q.dominios.length ? ' · domínios: ' + q.dominios.join(', ') : ''}`]
  if (q.plano.length && a.id !== 'pesquisa') L.push('Ações reconhecidas: ' + q.plano.join('; '))
  if (a.ve.includes('historico') && q.historico) L.push('Conversa recente:\n' + q.historico)
  if (a.ve.includes('memorias') && q.memorias.length) L.push('Memórias relevantes do usuário:\n- ' + q.memorias.slice(0, 8).join('\n- '))
  if (a.ve.includes('experiencias') && q.experiencias.length) L.push('Experiências anteriores deste usuário (individuais):\n- ' + q.experiencias.slice(0, 3).join('\n- '))
  if (a.ve.includes('dados')) for (const [k, v] of Object.entries(q.dados)) L.push(`Dados do usuário (${k}, somente leitura): ${v}`)
  if (a.ve.includes('comercial') && q.comercial) L.push('Contexto comercial:\n' + q.comercial.slice(0, 1500))
  if (a.ve.includes('previsoes') && q.previsoes?.length) L.push('Previsões deste usuário (FATO = registro; ESTIMATIVA = padrão, com confiança — não trate estimativa como fato):\n- ' + q.previsoes.slice(0, 6).join('\n- '))
  if (q.achados) { const t = q.achados(a.id); if (t) L.push(t) } // Fase 10: achados dos agentes de domínio — só os que este agente pode ver
  if (a.ve.includes('notas')) for (const [k, v] of Object.entries(q.notas)) L.push(`Contribuição de ${nomes.find((x) => x.id === k)?.papel || k}:\n${v}`)
  return L.join('\n')
}
const DADOS_POR_DOMINIO: Record<string, string[]> = { financas: ['get_finance'], agenda: ['get_agenda'], tarefas: ['get_agenda'], negocio: ['negocio_resumo'], crm: ['crm_oportunidades'], agenda_empresa: ['agenda_empresa_consultar'] }

/* ======================= divergências entre agentes ======================= */
const STOPL = new Set('de da do das dos e o a os as um uma em no na com para pra por que foi sao seu sua total valor cerca aproximadamente mes ano'.split(' '))
export function divergencias(notas: Record<string, string>, nomes: Agente[] = AGENTES): string[] {
  const porRotulo = new Map<string, Map<string, string>>(), out: string[] = []
  for (const [ag, txt] of Object.entries(notas)) {
    for (const m of nrm(txt).matchAll(/([a-z]{3,}(?:\s+[a-z]{3,})?)\s+(?:de|do|da|em|foi|e|:)?\s*(r\$\s?\d[\d.,]*|\d[\d.,]*\s?%)/g)) {
      const rot = m[1].split(' ').filter((w) => !STOPL.has(w)).pop(); if (!rot) continue
      const val = m[2].replace(/\s/g, ''); const mp = porRotulo.get(rot) || new Map(); if (!mp.has(ag)) mp.set(ag, val); porRotulo.set(rot, mp)
    }
  }
  for (const [rot, mp] of porRotulo) { const vals = new Set(mp.values()); if (mp.size >= 2 && vals.size >= 2) out.push(`${rot}: ${[...mp].map(([a, v]) => `${v.toUpperCase().replace('R$', 'R$ ')} (${nomes.find((x) => x.id === a)?.papel || a})`).join(' × ')}`) }
  const pos = Object.entries(notas).filter(([, t]) => /\b(vale a pena|recomendo|e viavel|compensa)\b/.test(nrm(t)) && !/\bnao (vale a pena|recomendo|e viavel|compensa)\b/.test(nrm(t))).map(([a]) => a)
  const neg = Object.entries(notas).filter(([, t]) => /\bnao (vale a pena|recomendo|e viavel|compensa)\b/.test(nrm(t))).map(([a]) => a)
  if (pos.length && neg.length) out.push(`recomendação: ${pos.join(', ')} a favor × ${neg.join(', ')} contra`)
  return out
}

/* ======================= orquestração ======================= */
export interface ResultadoAgente { id: string; nome: string; ok: boolean; ms: number; motivo?: string }
export interface Orquestracao { complexidade: Complexidade; agentes: ResultadoAgente[]; notas: Record<string, string>; divergencias: string[]; contexto: string; meta: any; dom?: any }
const comPrazo = <T>(p: Promise<T>, ms: number) => Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(Object.assign(new Error('tempo esgotado'), { code: 'timeout' })), Math.max(1, ms)))])

/** Uma contribuição de um agente sobre o quadro (usada pela orquestração e pelos testes individuais do Laboratório). */
export async function contribuir(a: Agente, q: Quadro, text: string, ms: number, nomes: Agente[] = AGENTES): Promise<{ ok: boolean; texto: string; ms: number; motivo?: string }> {
  const t = Date.now(), E = await import('./engine.js')
  if (a.tarefa === 'pesquisa' && (await import('./bloqueio-pesquisa.js')).registrar('agente_pesquisa', a.id)) return { ok: false, texto: '', ms: 0, motivo: 'pesquisa bloqueada: operação interna' }
  try {
    if (a.tarefa === 'pesquisa' && (await E.readyCount('pesquisa', ['pesquisa'])) === 0) return { ok: true, texto: 'SEM ACESSO À PESQUISA na web nesta instalação: não afirme fatos atuais; diga ao usuário que não foi possível pesquisar agora.', ms: Date.now() - t, motivo: 'sem pesquisa web configurada' }
    const msgs = [{ role: 'system', content: `Você é o especialista interno de ${a.papel} do "Meu Assistente". Você NÃO fala com o usuário: entregue uma contribuição curta (até 10 linhas) para o coordenador montar a resposta final. Use só o que está no quadro; não invente números, fontes ou fatos; marque hipóteses como hipóteses; português do Brasil; sem saudações.\n${a.instrucao}\n\nQUADRO COMPARTILHADO:\n${fatia(a, q, nomes)}` }, { role: 'user', content: `[AGENTE:${a.id}] ${a.id === 'pesquisa' ? paraPesquisa(text) : text}` }]
    const r = await comPrazo(E.run(msgs as any, { task: a.tarefa, maxMs: ms, temperature: 0.3, ...(a.tarefa === 'pesquisa' ? { grounding: true } : {}) }), ms + 300)
    const txt = String(r.message.content || '').trim()
    if (!txt) throw new Error('contribuição vazia')
    return { ok: true, texto: txt.slice(0, 1400), ms: Date.now() - t }
  } catch (e: any) { return { ok: false, texto: '', ms: Date.now() - t, motivo: e?.code === 'timeout' || Date.now() - t >= ms - 50 ? 'tempo esgotado' : String(e?.message || e).slice(0, 80) } }
}
/** Revisor crítico (Fase 10): analisa possíveis falhas da proposta — só em situações complexas e decisórias, uma rodada. */
export const REVISOR: Agente = { id: 'revisor', nome: 'Revisão crítica', papel: 'revisão crítica', onda: 2, tarefa: 'analise', ve: ['dados', 'notas'], gatilho: /$^/,
  instrucao: 'Você revisa as contribuições dos outros especialistas antes da resposta final: aponte falhas, riscos, premissas frágeis, contradições e números sem base nos dados. Responda em tópicos curtos. Se estiver tudo consistente, responda exatamente "SEM RESSALVAS".' }
export async function orquestrar(o: { u: SessionUser; text: string; history: Msg[]; an: Analise; sel: Selecao | null; plano: Plano | null; tools: Tool[]; today: string; fim: number; memorias: string[] | null; experiencias?: string[]; sandbox?: boolean; evitar?: string[]; extras?: Agente[]; forcar?: string[]; dados?: Record<string, any>; convId?: string | null }): Promise<Orquestracao | null> {
  const cfg = await maCfg(); if (!cfg.ativo && !o.forcar) return null
  // Fase 9: especialistas publicados pelo Laboratório (liberação gradual por usuário) — no laboratório, os da variante em teste
  const lista = mesclar(o.extras ?? (await (await import('./laboratorio-agentes.js')).publicadosPara(o.u.id, !!o.sandbox).catch(() => [])))
  // política aprendida (Fase 6): agentes que, nesta área, se mostraram piores que a resposta direta ficam de fora
  const t0 = Date.now(), cx = avaliarComplexidade(o.text, o.an, o.sel, o.plano, lista)
  let escolhidos = o.forcar ? o.forcar.map((id) => lista.find((a) => a.id === id)).filter((a): a is Agente => !!a) : selecionarAgentes(cx, cfg, lista).filter((a) => !(o.evitar || []).includes(a.id))
  // Fase 10: agentes especializados de domínio (coleta determinística, sem IA) + memória compartilhada + controle de duplicidade e de custo
  const DOM = await import('./agentes-dominio.js'), f10 = await DOM.f10Cfg()
  const dom = o.forcar ? null : await DOM.preparar({ u: o.u, text: o.text, nivel: cx.nivel, selIds: o.sel?.ids || [], convId: o.convId, hoje: o.today, sandbox: o.sandbox }).catch((e) => { console.error('[agentes-domínio]', e?.message); return null })
  if (dom?.limiteIA) escolhidos = [] // limite diário de tarefas com IA atingido: só os agentes de domínio (sem custo de IA)
  escolhidos = escolhidos.slice(0, f10.limites.maxChamadasIA)
  // operação interna (ai/prioridade.ts): o agente de Pesquisa nunca participa, nem por palavra-gatilho ("anota que a pesquisa…")
  if ((await import('./bloqueio-pesquisa.js')).pesquisaBloqueada()) escolhidos = escolhidos.filter((a) => a.tarefa !== 'pesquisa')
  if (escolhidos.length || dom?.agentes?.length) etapa('planejando') // pedido complexo: plano com agentes/coleta
  const base = { complexidade: cx, agentes: [] as ResultadoAgente[], notas: {} as Record<string, string>, divergencias: [] as string[] }
  const etapas: any[] = (dom?.agentes || []).map((a) => ({ id: 'coleta:' + a.id, agente: a.id, tipo: 'coleta', depende: [], status: a.ok ? (a.fatos ? 'ok' : 'sem dados') : 'falhou', ms: a.ms, ...(a.motivo ? { motivo: a.motivo } : {}) }))
  const decisoes: any[] = []; let chamadas = 0, validacao: any = null
  const ctxDom = DOM.contextoDominio(dom)
  const meta = (extra: any = {}) => ({ complexidade: cx.nivel, pontos: cx.pontos, agentes: base.agentes, divergencias: base.divergencias.length, ms: Date.now() - t0, ...(dom ? { tarefa: dom.tarefa, dominio: dom.agentes.map((a) => ({ id: a.id, ok: a.ok, ms: a.ms, fatos: a.fatos })), sugestoes: dom.sugestoes.map((s) => ({ agente: s.agente, objetivo: s.objetivo, autonomia: s.autonomia })), ...(dom.limiteIA ? { limite: 'diario' } : {}), ...(dom.reaproveitada ? { reaproveitada: true } : {}) } : {}), ...(validacao ? { validacao } : {}), ...extra })
  const fechar = async (status: string, contexto: string, extra: any = {}) => {
    const notasIA = Object.fromEntries(Object.entries(base.notas).filter(([k]) => k !== 'revisor'))
    await DOM.concluir(dom?.tarefa ?? null, { status: DOM.cancelada(dom?.tarefa ?? null) ? 'interrompida' : status, etapas: [...etapas, { id: 'consolidacao', agente: 'orquestrador', tipo: 'consolidacao', depende: etapas.map((e) => e.id), status: contexto ? 'ok' : 'pulado', ms: 0 }], achados: dom?.achados || {}, notasIA, decisoes, chamadas, ms: Date.now() - t0 })
    return { ...base, contexto, meta: meta(extra), dom } as Orquestracao
  }
  if (!escolhidos.length) return fechar(dom ? 'concluida' : 'concluida', ctxDom, dom?.limiteIA ? { pulado: 'limite diário de IA' } : {})
  // orçamento: os agentes usam no máximo ~35% do prazo da mensagem (a IA principal precisa do resto)
  const orc = Math.min(cfg.tempoMaxMs, Math.floor((o.fim - Date.now()) * 0.35))
  if (orc < 1500) return fechar('parcial', ctxDom, { pulado: 'sem tempo' }) // menos que isso não dá para um agente responder com qualidade
  const nomes = new Set(o.tools.map((t) => t.function.name))
  const q: Quadro = { pedido: o.text, intencao: o.an.tipo, complexidade: cx.nivel, dominios: (o.sel?.nomes || []).filter((n) => n !== 'Conhecimento geral'), plano: (o.plano?.etapas || []).map((e) => e.acao), memorias: o.memorias || [], experiencias: o.experiencias || [], dados: {}, historico: o.history.slice(-4).filter((m) => m.content).map((m) => `${m.role === 'user' ? 'Usuário' : 'Assistente'}: ${String(m.content).replace(/⟦[^⟧]*⟧/g, '').slice(0, 240)}`).join('\n'), comercial: '', notas: {}, achados: (id) => DOM.achadosPara(id, dom) }
  if (dom?.reaproveitada && Object.keys(dom.reaproveitada.notas).length) { // execução duplicada: reaproveita as contribuições, sem novas chamadas
    base.notas = dom.reaproveitada.notas; for (const id of Object.keys(base.notas)) { const a = lista.find((x) => x.id === id); base.agentes.push({ id, nome: a?.nome || id, ok: true, ms: 0, motivo: 'reaproveitado' }) }
    const ok = base.agentes.filter((a) => base.notas[a.id])
    return fechar('reaproveitada', [ctxDom, `COORDENAÇÃO MULTIAGENTE (interno — o usuário conversa só com você): pedido ${cx.nivel}. Componha UMA resposta coerente com as contribuições abaixo; NÃO mencione agentes nem este processo.`, ...ok.map((a) => `[${a.nome}]\n${base.notas[a.id]}`), ...dom.reaproveitada.decisoes.map((d) => 'VALIDAÇÃO: ' + d)].filter(Boolean).join('\n'))
  }
  // Execução (somente leitura): dados que os agentes da 2ª onda vão analisar — só ferramentas que o usuário já tem
  if (escolhidos.some((a) => a.ve.includes('dados'))) {
    const A = await import('./assistant.js'), quero = [...new Set((o.sel?.ids || []).flatMap((d) => DADOS_POR_DOMINIO[d] || []))].filter((n) => nomes.has(n)).slice(0, 3)
    await Promise.all(quero.map(async (n) => { try { const r = o.sandbox && o.dados ? o.dados[n] : await comPrazo(A.lerDados(o.u, n, {}, o.today), 2500); if (r !== undefined) q.dados[n] = JSON.stringify(r).slice(0, 2500) } catch { /* sem esses dados */ } })) // Fase 9: no laboratório, só os dados sintéticos do cenário
  }
  // Fase 7: a inteligência preditiva (analistas próprios, consolidados) alimenta os agentes que analisam e planejam
  if (escolhidos.some((a) => a.ve.includes('previsoes')) && !o.sandbox) { const r = await (await import('./preditivo-servico.js')).paraUsuario(o.u, { registrar: false }).catch(() => null); if (r?.sinais?.length) q.previsoes = r.sinais.slice(0, 6).map((s: any) => `${s.titulo} — ${s.natureza === 'fato' ? 'fato' : `estimativa ${s.confianca}%`} (${s.base})`) }
  if (escolhidos.some((a) => a.ve.includes('comercial'))) q.comercial = await (await import('./commercial.js')).commercialContext(o.u, o.text).catch(() => '')
  const coletas = etapas.map((e) => e.id)
  const rodar = async (a: Agente, ms: number, depende: string[]): Promise<void> => {
    chamadas++
    const r = await contribuir(a, q, o.text, ms, lista)
    etapas.push({ id: 'ia:' + a.id, agente: a.id, tipo: a.id === 'revisor' ? 'validacao' : 'raciocinio', depende, status: r.ok ? 'ok' : 'falhou', ms: r.ms, ...(r.motivo ? { motivo: r.motivo } : {}) })
    if (r.ok) { q.notas[a.id] = r.texto; base.agentes.push({ id: a.id, nome: a.nome, ok: true, ms: r.ms, ...(r.motivo ? { motivo: r.motivo } : {}) }) }
    else { falhou(a.id); base.agentes.push({ id: a.id, nome: a.nome, ok: false, ms: r.ms, motivo: r.motivo }) }
  }
  const onda1 = escolhidos.filter((a) => a.onda === 1), onda2 = escolhidos.filter((a) => a.onda === 2)
  if (onda1.length) await Promise.all(onda1.map((a) => rodar(a, onda2.length ? Math.floor(orc * 0.45) : orc, coletas)))
  const resta = orc - (Date.now() - t0)
  if (DOM.cancelada(dom?.tarefa ?? null)) { base.notas = q.notas; return fechar('interrompida', ctxDom, { interrompida: true }) } // interrupção pela Central de Agentes: nada novo começa
  if (onda2.length) { if (resta >= 1500) await Promise.all(onda2.map((a) => rodar(a, resta, [...coletas, ...onda1.map((x) => 'ia:' + x.id)]))); else for (const a of onda2) { base.agentes.push({ id: a.id, nome: a.nome, ok: false, ms: 0, motivo: 'sem tempo após a 1ª onda' }); etapas.push({ id: 'ia:' + a.id, agente: a.id, tipo: 'raciocinio', depende: coletas, status: 'pulado', ms: 0, motivo: 'sem tempo' }) } }
  base.notas = q.notas; base.divergencias = divergencias(q.notas, lista)
  const ok = base.agentes.filter((a) => a.ok && q.notas[a.id])
  // alternativa segura: se o raciocínio falhou mas há achados de domínio, a resposta sai com os dados (nada concluído é desfeito)
  if (!ok.length) return fechar(ctxDom ? 'parcial' : 'falhou', ctxDom, { semContribuicao: true })
  // Fase 10 — validação: proposta (contribuições) → crítica (revisor) → verificação dos números (determinística) → avaliação do coordenador
  let linhasValidacao: string[] = []
  if (DOM.precisaValidar(o.text, cx.nivel, ok.length, base.divergencias.length, f10) && !DOM.cancelada(dom?.tarefa ?? null)) {
    const fontes = Object.values(q.dados).join(' ') + ' ' + Object.values(dom?.achados || {}).flat().join(' ') + ' ' + o.text
    const sb = DOM.semBase(Object.fromEntries(ok.map((a) => [a.nome, q.notas[a.id]])), fontes)
    const tempo = orc - (Date.now() - t0)
    let critica = ''
    if (tempo >= 1500 && chamadas < f10.limites.maxChamadasIA + 1) { await rodar(REVISOR, tempo, ok.map((a) => 'ia:' + a.id)); critica = q.notas.revisor || '' }
    const semRessalvas = !critica || /SEM RESSALVAS/i.test(critica)
    validacao = { critica: critica ? (semRessalvas ? 'sem ressalvas' : 'com ressalvas') : 'não executada', semBase: sb.length, divergencias: base.divergencias.length }
    decisoes.push({ tipo: 'validacao', texto: `${semRessalvas ? 'proposta validada' : 'proposta com ressalvas'}${sb.length ? `; ${sb.length} número(s) sem base nos dados` : ''}${base.divergencias.length ? `; ${base.divergencias.length} divergência(s)` : ''}` })
    base.notas = Object.fromEntries(Object.entries(q.notas).filter(([k]) => k !== 'revisor'))
    q.notas = base.notas
    linhasValidacao = [`VALIDAÇÃO ANTES DE RESPONDER (interno): ${semRessalvas ? 'a revisão crítica não encontrou falhas relevantes.' : 'a revisão crítica apontou pontos a corrigir — trate-os na resposta:\n' + critica}`,
      ...(sb.length ? [`Números sem base nos dados (não os use como fato, ou diga que são estimativas): ${sb.join('; ')}`] : [])]
  }
  if (base.divergencias.length) decisoes.push({ tipo: 'divergencia', texto: `${base.divergencias.length} divergência(s) entregue(s) ao coordenador para resolver com os dados` })
  const contexto = [ctxDom, `COORDENAÇÃO MULTIAGENTE (interno — o usuário conversa só com você): pedido ${cx.nivel}${cx.motivos.length ? ' (' + cx.motivos.join('; ') + ')' : ''}. Especialistas internos consultados: ${ok.map((a) => a.nome).join(', ')}.`,
    'Componha UMA resposta coerente, na sua própria voz, integrando as contribuições abaixo. NÃO mencione agentes, especialistas internos ou este processo. Se o pedido tiver ações (agendar, registrar, criar), execute VOCÊ com as ferramentas — os especialistas não executam nada. Use só números que aparecem nos dados ou nas contribuições.',
    ...ok.map((a) => `[${a.nome}]\n${q.notas[a.id]}`),
    ...(base.divergencias.length ? [`DIVERGÊNCIAS ENTRE AS CONTRIBUIÇÕES (resolva antes de responder; prefira os dados das ferramentas e diga o que é incerto): ${base.divergencias.join('; ')}`] : []),
    ...linhasValidacao,
    ...(base.agentes.some((a) => !a.ok) ? [`Não ficaram prontas a tempo: ${base.agentes.filter((a) => !a.ok).map((a) => a.nome).join(', ')} — responda com o que há, sem inventar essa parte.`] : [])].filter(Boolean).join('\n')
  return fechar(base.agentes.some((a) => !a.ok) ? 'parcial' : 'concluida', contexto, { dados: Object.keys(q.dados) })
}

/* ======================= resposta unificada: sem fragmentação ======================= */
const FRAG: [RegExp, any][] = [
  [/\[(Pesquisa e investigação|Análise e raciocínio|Vendas e negócios|Planejamento e organização|Escrita e comunicação|AGENTE:[a-z]+)\]\s*/gi, ''],
  [/\b(segundo|de acordo com|conforme) (o|a|os|as) (agentes?|especialistas?)( internos?)?( de [^,.]+?)?,\s*/gi, ''],
  [/\b(o|a) (agente|especialista)( interno)? de ([^,.]+?) (sugere|recomenda|diz|indica|aponta)( que)?/gi, (_m: string, ...g: any[]) => 'a recomendação é' + (g[5] || '')],
  [/\b(meus|nossos) (agentes|especialistas internos)\b/gi, 'eu'],
]
export function unificar(content: string, extras: string[] = []): { content: string; ajustou: boolean } {
  let c = String(content || ''); const antes = c
  for (const [re, by] of FRAG) c = c.replace(re, by)
  for (const n of extras) if (n) c = c.split(`[${n}]`).join('').replace(/^\s+/, '') // Fase 9: nomes dos especialistas do Laboratório também não aparecem
  if (c !== antes) c = c.replace(/^\s*([a-zà-ý])/, (m) => m.toUpperCase()).replace(/([.!?]\s+)(a recomendação)/g, (_m, p1, p2) => p1 + 'A' + p2.slice(1))
  return { content: c, ajustou: c !== antes }
}

/* ======================= indicadores (só números; nada de texto de conversa) ======================= */
export async function indicadoresMultiagente() {
  const rows = (await q("SELECT level2, created_at FROM cognition_evals WHERE level2 IS NOT NULL ORDER BY id DESC LIMIT 3000").catch(() => [] as any[])) as any[]
  const ms = rows.map((r) => J<any>(r.level2, {})?.multiagente).filter(Boolean)
  const niveis: Record<string, number> = { simples: 0, moderada: 0, complexa: 0 }, por: Record<string, { acionamentos: number; ok: number; ms: number[]; falhas: Record<string, number> }> = {}
  let divergencias = 0, fragmentacao = 0, comAgentes = 0; const tempos: number[] = []
  for (const m of ms) {
    niveis[m.complexidade] = (niveis[m.complexidade] || 0) + 1
    if (m.agentes?.length) { comAgentes++; tempos.push(Number(m.ms) || 0) }
    if (m.divergencias) divergencias++
    if (m.fragmentacaoCorrigida) fragmentacao++
    for (const a of [...(m.agentes || []), ...(m.dominio || [])]) { const x = (por[a.id] ||= { acionamentos: 0, ok: 0, ms: [], falhas: {} }); x.acionamentos++; if (a.ok) x.ok++; else x.falhas[a.motivo || 'falha'] = (x.falhas[a.motivo || 'falha'] || 0) + 1; x.ms.push(Number(a.ms) || 0) }
  }
  const med = (xs: number[]) => (xs.length ? Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) : null)
  return {
    mensagens: ms.length, niveis, comAgentes, taxaComAgentes: ms.length ? Math.round((comAgentes / ms.length) * 100) : null, tempoMedioAgentesMs: med(tempos), divergencias, fragmentacaoCorrigida: fragmentacao,
    agentes: AGENTES.map((a) => { const x = por[a.id]; return { id: a.id, nome: a.nome, onda: a.onda, acionamentos: x?.acionamentos || 0, sucesso: x?.acionamentos ? Math.round((x.ok / x.acionamentos) * 100) : null, msMedio: x ? med(x.ms) : null, falhas: x?.falhas || {}, pausado: pausado(a.id) } }),
    fluxo: AGENTES_FLUXO,
    dominio: (await import('./agentes-dominio.js')).DOMINIO.map((a) => { const x = por[a.id]; return { id: a.id, nome: a.nome, acionamentos: x?.acionamentos || 0, sucesso: x?.acionamentos ? Math.round((x.ok / x.acionamentos) * 100) : null, msMedio: x ? med(x.ms) : null, falhas: x?.falhas || {} } }),
  }
}
