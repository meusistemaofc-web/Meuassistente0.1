// APRENDIZADO PELO USO REAL — parte do Motor de Aprendizagem Adaptativa (ai/adaptive.ts), sem memória paralela.
// Os padrões saem das AÇÕES efetivamente registradas por ESTE usuário (agenda, gastos, tarefas, lembretes, contas e vendas das
// empresas dele), e não de frases como "eu trabalho com tatuagem" (essas vão para `memories`, os fatos explícitos).
//
// Onde fica: tabela `learnings` (a mesma dos aprendizados por usuário), kind = 'padrao_uso', context = "<domínio>:<chave>".
//   rule        → frase curta ("Agenda com frequência: Tatuagem")
//   frequency   → quantas ocorrências reais
//   confidence  → evidência PONDERADA PELA RECÊNCIA (meia-vida de 45 dias): 1 ocorrência ≈ 0,42 · 2 ≈ 0,67 · 3 ≈ 0,81 · 5 ≈ 0,94
//   preference  → JSON { dom, chave, rotulo, nivel, n, peso, primeiro, ultimo, dias, periodo }
//   state       → 'ativo' (indício, recorrente ou hábito) | 'inativo' (perdeu relevância: o uso parou)
// Níveis: pontual (1 ocorrência, não é guardado) · indício (2+ ocorrências, confiança < 0,75) · recorrente (≥ 0,75) ·
// hábito (recorrente + regularidade: mesmo dia da semana ou intervalos parecidos) · antigo (confiança < 0,35 pelo tempo).
// Uso: hipótese, nunca fato. Interpreta pedidos ambíguos ("agendar um serviço") e orienta a IA só no domínio do pedido;
// nada é criado ou alterado com base só num padrão (sempre há confirmação).
import type { SessionUser } from '../lib/session.js'
import { q, J, nowIso } from '../db/index.js'

export type Dom = 'servico_agenda' | 'categoria_gasto' | 'tarefa' | 'lembrete' | 'conta' | 'produto_vendido'
export type Nivel = 'pontual' | 'indicio' | 'recorrente' | 'habito' | 'antigo'
export interface Padrao { id?: number; dom: Dom; chave: string; rotulo: string; nivel: Nivel; n: number; confianca: number; peso: number; primeiro: string; ultimo: string; dias: number; periodo?: string; regra: string; operacao: string }

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim()
const MEIA_VIDA = 45, JANELA_DIAS = 365
export const OPERACAO_DO_DOM: Record<Dom, string> = { servico_agenda: 'agendamento', categoria_gasto: 'financeiro', tarefa: 'tarefa', lembrete: 'lembrete', conta: 'financeiro', produto_vendido: 'geral' }
/** títulos genéricos não dizem nada sobre o uso ("Serviço", "Compromisso"): não viram padrão */
export const GENERICO = /^(servico|servicos|um servico|atendimento|agendamento|compromisso|horario|evento|sessao|tarefa|lembrete|conta|gasto|despesa|registro|algo|coisa|outros?|geral)$/
const DIAS = ['aos domingos', 'às segundas', 'às terças', 'às quartas', 'às quintas', 'às sextas', 'aos sábados']

/** chave do que se repete: o tipo, sem a pessoa ("Reunião com João" → "reuniao"; "Corte de cabelo" → "corte de cabelo") */
export function chaveDe(t: string): string | null {
  const s = nrm(String(t || '').replace(/\s+(?:com|para|pra|p\/)\s+.*$/i, '').replace(/\s+(?:d[oa]s?|de)\s+[A-ZÀ-Ý][\wÀ-ÿ]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ]+)?\s*$/, ''))
  if (!s || s.length < 3 || GENERICO.test(s)) return null
  return s.split(' ').slice(0, 4).join(' ')
}
const confDe = (peso: number) => Math.round(Math.min(0.95, 1 - Math.exp(-peso * 0.55)) * 100) / 100
const idadeDias = (iso: string, agora: number) => Math.max(0, (agora - new Date(iso).getTime()) / 86400000)

type Ocorrencia = { dom: Dom; chave: string; rotulo: string; em: string; dia: string | null }
async function ocorrencias(userId: number, agora: number): Promise<Ocorrencia[]> {
  const desde = new Date(agora - JANELA_DIAS * 86400000).toISOString(), out: Ocorrencia[] = []
  const rows = await q("SELECT type, status, day, data, created_at FROM items WHERE user_id = $1 AND type IN ('appointment','expense','task','reminder','bill') AND created_at >= $2 ORDER BY id DESC LIMIT 3000", [userId, desde])
  for (const r of rows as any[]) {
    const d = J<any>(r.data, {}), em = new Date(r.created_at).toISOString()
    let dom: Dom | null = null, txt = ''
    if (r.type === 'appointment') { dom = 'servico_agenda'; txt = d.title } // inclusive cancelados: o pedido existiu
    else if (r.type === 'expense') { if (d.kind === 'income') continue; dom = 'categoria_gasto'; txt = d.subcategory || d.category }
    else if (r.type === 'task') { dom = 'tarefa'; txt = d.title }
    else if (r.type === 'reminder') { dom = 'lembrete'; txt = d.message }
    else if (r.type === 'bill') { dom = 'conta'; txt = d.name }
    const ch = dom ? chaveDe(txt) : null
    if (dom && ch) out.push({ dom, chave: ch, rotulo: String(txt).replace(/\s+(?:com|para|pra)\s+.*$/i, '').trim().slice(0, 60), em, dia: r.day || null })
  }
  // vendas das empresas DESTE usuário (dono): produtos que mais saem
  const ped = await q('SELECT o.data, o.created_at FROM orders o JOIN businesses b ON b.id = o.business_id WHERE b.owner_id = $1 AND o.created_at >= $2 ORDER BY o.id DESC LIMIT 1500', [userId, desde]).catch(() => [])
  for (const o of ped as any[]) for (const it of (J<any>(o.data, {}).itens || []).slice(0, 20)) { const ch = chaveDe(it.nome); if (ch) out.push({ dom: 'produto_vendido', chave: ch, rotulo: String(it.nome).slice(0, 60), em: new Date(o.created_at).toISOString(), dia: null }) }
  return out
}
const FRASE: Record<Dom, (r: string) => string> = {
  servico_agenda: (r) => `Agenda com frequência: ${r}`, categoria_gasto: (r) => `Registra gastos de ${r} com frequência`, tarefa: (r) => `Cria tarefas de "${r}" com frequência`,
  lembrete: (r) => `Pede lembretes de "${r}" com frequência`, conta: (r) => `Tem a conta "${r}" com frequência`, produto_vendido: (r) => `Vende com frequência: ${r}`,
}
/** Agrupa as ocorrências e calcula frequência, recência, consistência e nível. Função pura (testável). */
export function analisar(oc: Ocorrencia[], agora = Date.now()): Padrao[] {
  const g = new Map<string, Ocorrencia[]>()
  for (const o of oc) { const k = o.dom + ':' + o.chave; g.set(k, [...(g.get(k) || []), o]) }
  const out: Padrao[] = []
  for (const [, L] of g) {
    const ord = [...L].sort((a, b) => a.em.localeCompare(b.em)), n = ord.length
    const peso = Math.round(ord.reduce((s, o) => s + Math.pow(0.5, idadeDias(o.em, agora) / MEIA_VIDA), 0) * 100) / 100
    const confianca = confDe(peso), ultimo = ord[n - 1].em, primeiro = ord[0].em, dias = Math.round(idadeDias(primeiro, agora) - idadeDias(ultimo, agora))
    // regularidade: mesmo dia da semana (pelo dia marcado) ou intervalos parecidos entre as ocorrências
    let periodo: string | undefined
    // hábito exige tempo: ao menos 3 semanas diferentes e 14 dias entre a primeira e a última (3 pedidos no mesmo dia não são hábito)
    const datas = ord.map((o) => o.dia ? new Date(o.dia + 'T12:00:00Z') : new Date(o.em)), semanas = new Set(datas.map((d) => Math.floor(d.getTime() / (7 * 86400000))))
    const vao = (Math.max(...datas.map((d) => d.getTime())) - Math.min(...datas.map((d) => d.getTime()))) / 86400000
    if (n >= 3 && semanas.size >= 3 && vao >= 14) {
      const ds = datas.map((d) => d.getUTCDay()), cont = new Map<number, number>()
      for (const d of ds) cont.set(d, (cont.get(d) || 0) + 1)
      const [dTop, nTop] = [...cont].sort((a, b) => b[1] - a[1])[0]
      const ints = ord.slice(1).map((o, i) => (new Date(o.em).getTime() - new Date(ord[i].em).getTime()) / 86400000).filter((x) => x > 0.5)
      const med = ints.length ? ints.reduce((s, x) => s + x, 0) / ints.length : 0, cv = ints.length >= 2 && med ? Math.sqrt(ints.reduce((s, x) => s + (x - med) ** 2, 0) / ints.length) / med : 9
      if (nTop / n >= 0.6) periodo = DIAS[dTop]
      else if (cv < 0.35 && med >= 5) periodo = med < 10 ? 'toda semana' : med < 20 ? 'a cada 2 semanas' : med < 40 ? 'todo mês' : undefined
    }
    const nivel: Nivel = n < 2 ? 'pontual' : confianca < 0.35 ? 'antigo' : confianca >= 0.6 && periodo && n >= 3 ? 'habito' : confianca >= 0.75 ? 'recorrente' : 'indicio'
    const rotulo = ord[n - 1].rotulo, dom = ord[0].dom
    out.push({ dom, chave: ord[0].chave, rotulo, nivel, n, confianca, peso, primeiro, ultimo, dias, periodo, regra: FRASE[dom](rotulo) + (nivel === 'habito' && periodo ? ` (${periodo})` : ''), operacao: OPERACAO_DO_DOM[dom] })
  }
  return out.sort((a, b) => b.confianca - a.confianca || b.n - a.n)
}

/* ---------- persistência (learnings) com recálculo sob demanda ---------- */
const sujo = new Set<number>(), calculadoEm = new Map<number, number>(), cacheAtivos = new Map<number, Padrao[]>() // padrões ativos já lidos (até a próxima ação)
const TTL = 10 * 60_000
/** Uma ação nova do usuário (tela ou chat): o próximo uso recalcula os padrões dele. */
/** A pessoa apagou/confirmou um padrão: vale na hora, inclusive no contexto da IA. */
export function invalidar(userId: number) { sujo.add(Number(userId)); cacheAtivos.delete(Number(userId)) }
export function marcarSujo(userId: number) { sujo.add(Number(userId)) } // o cache dos ativos continua valendo para o contexto da IA até o recálculo (que o substitui)
/** Ações recém-criadas (em memória, só para a pergunta de contexto do MESMO turno; sem consulta ao banco). */
const recentes = new Map<number, { type: string; data: any; em: number }[]>()
const contagens = new Map<number, Map<string, number>>() // quantas vezes cada coisa aconteceu (todas as chaves, inclusive as de 1 vez)
const DOM_DO_TIPO: Record<string, [Dom, (d: any) => string]> = { appointment: ['servico_agenda', (d) => d.title], task: ['tarefa', (d) => d.title], reminder: ['lembrete', (d) => d.message], bill: ['conta', (d) => d.name] }
/** Quantas vezes "isso" já aconteceu para o usuário, sem ir ao banco; null = ainda não calculado neste processo. */
export function contagem(userId: number, dom: Dom, chave: string): number | null { const c = contagens.get(Number(userId)); return c ? c.get(dom + ':' + chave) || 0 : null }
export function registrarAcao(userId: number, type: string, data: any) { { const c = contagens.get(Number(userId)), m = DOM_DO_TIPO[type], ch = m ? chaveDe(m[1](data || {})) : null; if (c && m && ch) c.set(m[0] + ':' + ch, (c.get(m[0] + ':' + ch) || 0) + 1) } const uid = Number(userId), l = (recentes.get(uid) || []).filter((x) => Date.now() - x.em < 60_000); l.push({ type, data, em: Date.now() }); recentes.set(uid, l.slice(-5)); if (recentes.size > 5000) recentes.clear() }
export function acoesDesde(userId: number, desde: string) { const t = new Date(desde).getTime() - 5; return (recentes.get(Number(userId)) || []).filter((x) => x.em >= t).reverse() }
const hist = (h: unknown, ev: object) => JSON.stringify([...J<any[]>(h, []), { em: nowIso(), ...ev }].slice(-30))
/** Recalcula e grava os padrões do usuário (só os dele). `agora` permite simular o tempo nos testes. */
export async function atualizar(u: Pick<SessionUser, 'id'>, o: { forcar?: boolean; agora?: number } = {}): Promise<Padrao[]> {
  const uid = Number(u.id), agora = o.agora ?? Date.now()
  if (!o.forcar && !sujo.has(uid) && agora - (calculadoEm.get(uid) || 0) < TTL) return cacheAtivos.get(uid) || lerAtivos(uid)
  sujo.delete(uid); calculadoEm.set(uid, agora)
  const oc = await ocorrencias(uid, agora), cont = new Map<string, number>(); for (const o of oc) cont.set(o.dom + ':' + o.chave, (cont.get(o.dom + ':' + o.chave) || 0) + 1); contagens.set(uid, cont); if (contagens.size > 5000) contagens.clear()
  const ps = analisar(oc, agora).filter((p) => p.n >= 2)
  const ex = await q("SELECT id, context, confidence, frequency, state, history, preference FROM learnings WHERE user_id = $1 AND kind = 'padrao_uso'", [uid])
  const porCtx = new Map((ex as any[]).map((r) => [String(r.context), r])), vistos = new Set<string>(), now = nowIso()
  for (const p of ps) {
    const ctx = p.dom + ':' + p.chave, r: any = porCtx.get(ctx), estado = p.nivel === 'antigo' ? 'inativo' : 'ativo'; vistos.add(ctx)
    if (r?.state === 'bloqueado' || r?.state === 'pausado') continue // apagado ou pausado pela pessoa: o recálculo não mexe
    // a confirmação da pessoa ("sim, todo mês" / "foi só desta vez") é relida na hora de gravar (nunca sobrescrita por um
    // recálculo concorrente) e vale sobre a estimativa: confirmado ≥ 0,85, negado ≤ 0,4
    const confirmado = r ? J<any>((await q('SELECT preference FROM learnings WHERE id = $1', [r.id]) as any[])[0]?.preference, {}).confirmado ?? null : null
    if (confirmado === true) p.confianca = Math.max(p.confianca, 0.85); else if (confirmado === false) p.confianca = Math.min(p.confianca, 0.4)
    const pref = JSON.stringify({ dom: p.dom, chave: p.chave, rotulo: p.rotulo, nivel: p.nivel, n: p.n, peso: p.peso, primeiro: p.primeiro, ultimo: p.ultimo, dias: p.dias, periodo: p.periodo || null, confirmado })
    if (!r) { await q("INSERT INTO learnings (user_id, operation, kind, context, rule, preference, scope, confidence, frequency, uses, state, history, created_at, updated_at) VALUES ($1,$2,'padrao_uso',$3,$4,$5,'permanente',$6,$7,0,$8,$9,$10,$10)", [uid, p.operacao, ctx, p.regra, pref, p.confianca, p.n, estado, JSON.stringify([{ em: now, acao: 'observado', nivel: p.nivel, n: p.n }]), now]); continue }
    const nivelAnt = J<any>(r.preference, {}).nivel
    if (Number(r.frequency) === p.n && Math.abs(Number(r.confidence) - p.confianca) < 0.01 && nivelAnt === p.nivel && r.state === estado) continue
    // grava preservando uma confirmação que tenha chegado depois da leitura acima (corrida com confirmar())
    await q("UPDATE learnings SET rule = $1, preference = $2, confidence = $3, frequency = $4, state = $5, history = $6, updated_at = $7 WHERE id = $8 AND preference NOT LIKE '%\"confirmado\":true%' AND preference NOT LIKE '%\"confirmado\":false%'", [p.regra, pref, p.confianca, p.n, estado, nivelAnt !== p.nivel ? hist(r.history, { acao: 'nivel', de: nivelAnt, para: p.nivel, n: p.n }) : r.history, now, r.id])
    if (confirmado !== null) await q('UPDATE learnings SET rule = $1, preference = $2, confidence = $3, frequency = $4, state = $5, updated_at = $6 WHERE id = $7', [p.regra, pref, p.confianca, p.n, estado, now, r.id]) // já confirmado: a confirmação vai junto
  }
  for (const [ctx, r] of porCtx) if (!vistos.has(ctx) && !['inativo', 'bloqueado', 'pausado'].includes((r as any).state)) await q("UPDATE learnings SET state = 'inativo', history = $1, updated_at = $2 WHERE id = $3", [hist((r as any).history, { acao: 'sem_ocorrencias' }), now, (r as any).id]) // registros apagados ou fora da janela
  return lerAtivos(uid)
}
async function lerAtivos(uid: number): Promise<Padrao[]> {
  const ps = await lerAtivosDb(uid); cacheAtivos.set(uid, ps); if (cacheAtivos.size > 5000) cacheAtivos.clear(); return ps
}
export function agendarRecalculo(u: Pick<SessionUser, 'id'>, ms = 800) { const uid = Number(u.id); if (sujo.has(uid) || !contagens.has(uid) || Date.now() - (calculadoEm.get(uid) || 0) >= TTL) { const t = setTimeout(() => { atualizar(u).catch(() => {}) }, ms); (t as any).unref?.() } }
const deLinha = (r: any): Padrao => { const p = J<any>(r.preference, {}); return { id: Number(r.id), dom: p.dom, chave: p.chave, rotulo: p.rotulo, nivel: p.nivel, n: Number(p.n), confianca: Number(r.confidence), peso: Number(p.peso), primeiro: p.primeiro, ultimo: p.ultimo, dias: Number(p.dias), periodo: p.periodo || undefined, regra: r.rule, operacao: r.operation, confirmado: p.confirmado ?? null } as Padrao }
async function lerAtivosDb(uid: number): Promise<Padrao[]> {
  const rows = await q("SELECT id, operation, rule, confidence, preference FROM learnings WHERE user_id = $1 AND kind = 'padrao_uso' AND state = 'ativo' ORDER BY confidence DESC, frequency DESC LIMIT 200", [uid])
  return (rows as any[]).map(deLinha)
}
/** Padrões ativos do usuário (só dele), opcionalmente de um domínio e acima de uma confiança. Respeita a chave do aprendizado. */
export async function padroes(u: SessionUser, o: { dom?: Dom; minConf?: number; fresco?: boolean } = {}): Promise<Padrao[]> {
  const A = await import('./adaptive.js'); if (!(await A.ativo(u))) return []
  const uid = Number(u.id)
  // fresco = false (contexto da IA em todo turno): usa o que já foi calculado e recalcula logo DEPOIS da resposta (sem
  // pesar na mensagem); decisões explícitas (pergunta do serviço, descoberta) pedem o cálculo atualizado
  let ps: Padrao[]
  if (o.fresco === false) {
    if (sujo.has(uid) || Date.now() - (calculadoEm.get(uid) || 0) >= TTL) { const t = setTimeout(() => { atualizar(u).catch(() => {}) }, 800); (t as any).unref?.() }
    ps = cacheAtivos.get(uid) || await lerAtivos(uid).catch(() => [] as Padrao[])
  } else ps = await atualizar(u).catch(() => [] as Padrao[])
  return ps.filter((p) => (!o.dom || p.dom === o.dom) && p.confianca >= (o.minConf ?? 0.5))
}
/** O usuário confirmou ("sim, toda semana") ou negou ("foi só desta vez") um padrão: vira evidência explícita. */
export async function confirmar(u: SessionUser, dom: Dom, chave: string, sim: boolean) {
  cacheAtivos.delete(Number(u.id))
  const r: any = (await q("SELECT id, preference, history, confidence FROM learnings WHERE user_id = $1 AND kind = 'padrao_uso' AND context = $2", [u.id, dom + ':' + chave]))[0]; if (!r) return
  const p = { ...J<any>(r.preference, {}), confirmado: sim }
  await q('UPDATE learnings SET preference = $1, confidence = $2, history = $3, updated_at = $4 WHERE id = $5', [JSON.stringify(p), sim ? Math.max(Number(r.confidence), 0.85) : Math.min(Number(r.confidence), 0.4), hist(r.history, { acao: sim ? 'confirmado_pelo_usuario' : 'negado_pelo_usuario' }), nowIso(), r.id])
}

/* ---------- uso nas conversas ---------- */
const DOM_DA_OPERACAO: Record<string, Dom[]> = { agendamento: ['servico_agenda'], financeiro: ['categoria_gasto', 'conta'], tarefa: ['tarefa'], lembrete: ['lembrete'], compra: [], exclusao: [], geral: [] }
const NIVEL_TXT: Record<Nivel, string> = { pontual: 'pontual', indicio: 'indício', recorrente: 'recorrente', habito: 'hábito', antigo: 'antigo' }
const quando = (iso: string) => { const d = Math.round(idadeDias(iso, Date.now())); return d <= 0 ? 'hoje' : d === 1 ? 'ontem' : `há ${d} dias` }
/** Bloco estruturado para o orquestrador/IA: só os padrões do DOMÍNIO do pedido (nunca o histórico inteiro), rotulados como hipótese. */
export async function contextoIA(u: SessionUser, ops: string[], linhas?: any[]): Promise<string> {
  const doms = [...new Set(ops.flatMap((o) => DOM_DA_OPERACAO[o] || []))]
  if (!doms.length) return ''
  // linhas = padrões que já vieram na consulta dos aprendizados do turno (adaptive.recuperar): nenhuma leitura extra
  const lidos = linhas ? linhas.map(deLinha).filter((p) => p.confianca >= 0.5) : null
  if (linhas) agendarRecalculo(u)
  const ps = (lidos || await padroes(u, { fresco: false })).filter((p) => doms.includes(p.dom)).sort((a, b) => b.confianca - a.confianca).slice(0, 4)
  if (!ps.length) return ''
  return 'Padrões observados no uso deste usuário (HIPÓTESES tiradas das ações dele, não fatos ditos por ele). Use só para interpretar um pedido ambíguo ou sugerir; antes de criar ou alterar algo com base neles, confirme com uma pergunta curta. Nunca diga que analisou o histórico:\n'
    + ps.map((p) => `- [${NIVEL_TXT[p.nivel]} · ${p.n} vezes · última ${quando(p.ultimo)}] ${p.regra}`).join('\n')
}

/* ---------- agendamento ambíguo ("quero agendar um serviço amanhã às 9h") ---------- */
const plural = (t: string) => { const w = t.toLowerCase(); if (/\s/.test(w)) return w; return /m$/.test(w) ? w.slice(0, -1) + 'ns' : /ao$/.test(w) ? w.slice(0, -2) + 'ões' : /[rz]$/.test(w) ? w + 'es' : /l$/.test(w) ? w.slice(0, -1) + 'is' : /s$/.test(w) ? w : w + 's' }
const artigo = (t: string) => /(a|gem|cao|ção|dade|agem)$/i.test(t.toLowerCase().split(' ')[0]) ? 'uma' : 'um'
const lista = (xs: string[]) => xs.length <= 1 ? xs.join('') : xs.slice(0, -1).join(', ') + ' e ' + xs[xs.length - 1]
/** Pergunta contextual quando o tipo do compromisso não foi dito. null = sem contexto suficiente (segue o fluxo normal). */
export async function perguntaServico(u: SessionUser): Promise<{ pergunta: string; opcoes: { rotulo: string; chave: string }[] } | null> {
  let ps = (await padroes(u, { dom: 'servico_agenda' })).slice(0, 3)
  const fatos: string[] = []
  if (!ps.length) { // sem padrão de uso: o que a própria pessoa disse ("Trabalha com: tatuagem") ajuda do mesmo jeito
    const m = (await q("SELECT content FROM memories WHERE user_id = $1 AND active = TRUE AND content LIKE 'Trabalha com:%' ORDER BY id DESC LIMIT 1", [u.id]).catch(() => []))[0] as any
    const v = m ? String(m.content).replace(/^Trabalha com:\s*/, '').replace(/[.!]+$/, '').trim() : ''
    if (v && v.length <= 40) fatos.push(v)
  }
  if (!ps.length && !fatos.length) return null
  if (ps.length) {
    // padrão bem mais forte que os outros: os fracos ficam de fora (equilíbrio entre conflitantes, sem lista longa)
    ps = ps.filter((p) => p.confianca >= ps[0].confianca - 0.3)
    const forte = ps[0].confianca >= 0.75, rot = ps.map((p) => plural(p.rotulo))
    const intro = forte ? `Você costuma agendar ${lista(rot)}.` : `Nos seus últimos agendamentos apareceram ${lista(rot)}.`
    const perg = ps.length === 1 ? `Esse agendamento também será ${artigo(ps[0].rotulo)} ${ps[0].rotulo.toLowerCase()} ou é outro serviço?` : 'Esse agendamento será um deles ou outro serviço?'
    return { pergunta: `${intro} ${perg}`, opcoes: ps.map((p) => ({ rotulo: p.rotulo, chave: p.chave })) }
  }
  return { pergunta: `Esse agendamento é de ${fatos[0].toLowerCase()} ou de outro serviço?`, opcoes: [{ rotulo: fatos[0].replace(/^./, (x) => x.toUpperCase()), chave: chaveDe(fatos[0]) || nrm(fatos[0]) }] }
}
/** Lê a resposta à pergunta acima. `title` = serviço escolhido; `outro` = pediu outro sem dizer qual. */
export function lerServico(text: string, opcoes: { rotulo: string; chave: string }[]): { title?: string; outro?: boolean } | null {
  const s = nrm(text)
  if (!s) return null
  const op = opcoes.find((o) => s.includes(o.chave) || s.includes(nrm(o.rotulo)) || s.includes(nrm(plural(o.rotulo))))
  if (op && !/\b(nao e|nao sera|outro|outra)\b/.test(s)) return { title: op.rotulo }
  if (/^(sim|isso|e sim|e|eh|sera|tambem|isso mesmo|exato|claro|pode ser|correto|certo|ok)\b/.test(s) && opcoes.length === 1 && s.split(' ').length <= 4) return { title: opcoes[0].rotulo }
  const livre = String(text).trim().replace(/^(?:n[ãa]o[,.]?\s*)?(?:(?:[ée]|ser[áa]|vai ser|eh)\s+)?(?:outr[oa]\s*(?:servi[çc]o)?[:,]?\s*)?(?:(?:um|uma|o|a)\s+)?/i, '').replace(/[.!]+$/, '').trim()
  if (/^(nao|outro|outra|outro servico|e outro|nenhum)$/.test(s) || !livre) return { outro: true }
  if (livre.split(/\s+/).length <= 6) return { title: livre.charAt(0).toUpperCase() + livre.slice(1) }
  return null
}
