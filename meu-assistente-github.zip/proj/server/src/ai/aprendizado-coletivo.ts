// APRENDIZADO COLETIVO EVOLUTIVO — a camada COLETIVA do Cérebro Central. Uma só arquitetura, duas camadas:
//   individual (já existia, não muda) .. learnings (correções e padrões de uso), memories, padrões de uso, descoberta
//   coletiva (este arquivo) ............ conhecimento GENERALIZÁVEL: "frases assim costumam significar esta ação"
//
//  1 experiência elegível .. só turnos em que uma ação foi CONFIRMADA por ferramenta/registro (ou corrigida pelo usuário):
//                            frase → intenção. Nunca a conversa, a resposta, nomes, números, datas, valores ou dados.
//  2 abstração ............. a frase vira um MODELO: tudo fora de um vocabulário comum de comandos vira lacuna
//                            ({nome}, {data}, {hora}, {valor}, {num}, {x}). Frases com dado sensível ou tentativa de
//                            manipulação ("ignore as instruções…") são descartadas/bloqueadas antes de qualquer gravação.
//  3 consentimento ......... só de quem permite contribuir (user_intel_prefs.contribute) e com a memória ligada; quem
//                            retira o consentimento tem as contribuições apagadas; apagar a conta apaga tudo (CASCADE).
//  4 consolidação .......... agrupa variações parecidas, separa casos isolados (menos de N usuários distintos) de padrões
//                            consistentes, calcula a confiabilidade (limite inferior de Wilson), detecta contradições
//                            (mesmo modelo, intenções diferentes), suspende sozinho o que passou a ser corrigido e nunca
//                            reativa o que o administrador rejeitou/removeu. Usuários suspeitos ficam fora.
//  5 uso ................... índice em memória (zero consultas por mensagem): ajuda a reconhecer a intenção de quem nunca
//                            usou o app (roteamento local, sem depender da IA externa) e entra como dica no contexto da
//                            IA. O contexto INDIVIDUAL e o da conversa sempre prevalecem: o coletivo só atua quando a
//                            decisão local não reconheceu nada.
//  6 governança ............ painel do Cérebro Central: contagens, pendentes, rejeitados, atualizados, removidos,
//                            confiabilidade, categorias, origem, histórico; revisar, suspender, remover e reverter.
import { q, one, nowIso, J, B, foraDaRequisicao } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'

export type Dominio = 'agenda' | 'financeiro' | 'lembrete' | 'tarefa' | 'nota' | 'conta' | 'lista' | 'loja'
export interface Intencao { nome: string; dominio: Dominio; prioridade: 'operacao' | 'consulta_interna'; categoria: string }
/** Catálogo FECHADO: nenhuma intenção fora daqui pode ser aprendida (ninguém "ensina" uma ação nova ao sistema). */
export const INTENCOES: Record<string, Intencao> = {
  'agenda.criar': { nome: 'Criar compromisso', dominio: 'agenda', prioridade: 'operacao', categoria: 'Compromissos' },
  'agenda.alterar': { nome: 'Alterar compromisso', dominio: 'agenda', prioridade: 'operacao', categoria: 'Compromissos' },
  'agenda.consultar': { nome: 'Consultar a agenda', dominio: 'agenda', prioridade: 'consulta_interna', categoria: 'Consultas' },
  'lembrete.criar': { nome: 'Criar lembrete', dominio: 'lembrete', prioridade: 'operacao', categoria: 'Lembretes' },
  'tarefa.criar': { nome: 'Criar tarefa', dominio: 'tarefa', prioridade: 'operacao', categoria: 'Tarefas' },
  'tarefa.concluir': { nome: 'Concluir tarefa', dominio: 'tarefa', prioridade: 'operacao', categoria: 'Tarefas' },
  'nota.criar': { nome: 'Criar nota', dominio: 'nota', prioridade: 'operacao', categoria: 'Notas' },
  'financeiro.registrar': { nome: 'Registrar gasto ou receita', dominio: 'financeiro', prioridade: 'operacao', categoria: 'Finanças' },
  'financeiro.consultar': { nome: 'Consultar finanças', dominio: 'financeiro', prioridade: 'consulta_interna', categoria: 'Consultas' },
  'conta.criar': { nome: 'Cadastrar conta a pagar', dominio: 'conta', prioridade: 'operacao', categoria: 'Finanças' },
  'lista.adicionar': { nome: 'Adicionar à lista de compras', dominio: 'lista', prioridade: 'operacao', categoria: 'Listas' },
  // atendimento comercial dos agentes das empresas (generalizável: COMO os clientes pedem, nunca o que uma loja vende)
  'loja.buscar': { nome: 'Procurar produto ou serviço', dominio: 'loja', prioridade: 'operacao', categoria: 'Atendimento comercial' },
  'loja.refinar': { nome: 'Refinar a busca (cor, tamanho, preço)', dominio: 'loja', prioridade: 'operacao', categoria: 'Atendimento comercial' },
  'loja.adicionar': { nome: 'Adicionar ao carrinho', dominio: 'loja', prioridade: 'operacao', categoria: 'Atendimento comercial' },
  'loja.duvida': { nome: 'Dúvida sobre preço ou opção', dominio: 'loja', prioridade: 'operacao', categoria: 'Atendimento comercial' },
  'loja.agendar': { nome: 'Agendar serviço', dominio: 'loja', prioridade: 'operacao', categoria: 'Atendimento comercial' },
}
/** Escopo de uso: a camada coletiva do assistente pessoal nunca usa intenções de loja, e o agente da empresa só usa as de loja. */
const escopoDe = (intent: string) => (intent.startsWith('loja.') ? 'loja' : 'assistente')
const DE_FERRAMENTA: Record<string, string> = { create_appointment: 'agenda.criar', update_appointment: 'agenda.alterar', get_agenda: 'agenda.consultar', create_reminder: 'lembrete.criar', create_task: 'tarefa.criar', complete_task: 'tarefa.concluir', create_note: 'nota.criar', register_transaction: 'financeiro.registrar', get_finance: 'financeiro.consultar', create_bill: 'conta.criar', add_shopping_items: 'lista.adicionar' }
const DE_TIPO: Record<string, string> = { appointment: 'agenda.criar', reminder: 'lembrete.criar', task: 'tarefa.criar', note: 'nota.criar', expense: 'financeiro.registrar', bill: 'conta.criar', shopping: 'lista.adicionar' }
const LEITURAS = new Set(['agenda.consultar', 'financeiro.consultar'])

/* ======================= configuração (app_config "aprendizado_coletivo") ======================= */
export interface Cfg { ativo: boolean; usarNoRoteamento: boolean; usarNaIA: boolean; minUsuarios: number; confAtivar: number; confRoteamento: number; retencaoDias: number; maxPorDia: number }
export const CFG_PADRAO: Cfg = { ativo: true, usarNoRoteamento: true, usarNaIA: true, minUsuarios: 3, confAtivar: 0.6, confRoteamento: 0.7, retencaoDias: 90, maxPorDia: 40 }
let cfgAtual: Cfg = { ...CFG_PADRAO }, cfgLidoEm = 0
export async function cfg(fresco = false): Promise<Cfg> {
  if (!fresco && Date.now() - cfgLidoEm < 60_000) return cfgAtual
  const r = await one("SELECT value FROM app_config WHERE key = 'aprendizado_coletivo'").catch(() => null)
  cfgAtual = { ...CFG_PADRAO, ...J<Partial<Cfg>>(r?.value, {}) }; cfgLidoEm = Date.now(); return cfgAtual
}
export async function salvarCfg(x: Partial<Cfg>): Promise<Cfg> {
  const c = await cfg(true), n: Cfg = { ...c }
  for (const k of ['ativo', 'usarNoRoteamento', 'usarNaIA'] as const) if (typeof x[k] === 'boolean') n[k] = x[k] as boolean
  const lim = (v: any, a: number, b: number) => Math.min(b, Math.max(a, Number(v)))
  if (x.minUsuarios != null && Number.isFinite(Number(x.minUsuarios))) n.minUsuarios = Math.round(lim(x.minUsuarios, 2, 50)) // 1 usuário nunca vira conhecimento coletivo
  if (x.confAtivar != null && Number.isFinite(Number(x.confAtivar))) n.confAtivar = lim(x.confAtivar, 0.5, 0.99)
  if (x.confRoteamento != null && Number.isFinite(Number(x.confRoteamento))) n.confRoteamento = lim(x.confRoteamento, 0.5, 0.99)
  if (x.retencaoDias != null && Number.isFinite(Number(x.retencaoDias))) n.retencaoDias = Math.round(lim(x.retencaoDias, 7, 365))
  const ex = await one("SELECT key FROM app_config WHERE key = 'aprendizado_coletivo'")
  if (ex) await q("UPDATE app_config SET value = $1 WHERE key = 'aprendizado_coletivo'", [JSON.stringify(n)])
  else await q("INSERT INTO app_config (key, value) VALUES ('aprendizado_coletivo', $1)", [JSON.stringify(n)])
  cfgAtual = n; cfgLidoEm = Date.now(); IDX = null; return n
}
const cfgEmFundo = () => { if (Date.now() - cfgLidoEm > 60_000) { cfgLidoEm = Date.now() - 50_000; foraDaRequisicao(() => void cfg(true).catch(() => {})) } return cfgAtual }

/* ======================= abstração (anonimização) ======================= */
const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
/** Dado sensível em qualquer ponto da frase: a experiência inteira é descartada (minimização). */
const SENSIVEL = /(@|https?:|www\.|\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b|\b(?:\d[ .-]?){11,19}\b|\b(senha|password|token|cvv|cpf|cnpj|rg|cartao|chave pix|codigo de seguranca)\b)/
/** Tentativa de manipular o aprendizado ou a IA: bloqueada (conta como rejeitada no painel, sem o texto). */
export const INJECAO = /(ignor\w* (as |todas as |suas )?(instruc|regra|orden|diretriz)|esquec\w* (tudo|as instruc|suas regras)|desconsider\w* (as |suas )?(instruc|regra)|system prompt|prompt do sistema|jailbreak|voce agora e |a partir de agora (voce|responda|sempre)|finja (que|ser)|aja como|modo (desenvolvedor|dev)|developer mode|<\s*\/?\s*script|\{\{|\bsudo\b|apague (todos|tudo)|aprenda (que|isso)|memorize que todos)/
const VOCAB = new Set((
  // ligação e pronomes
  'a o os as um uma uns umas de da do das dos e ou em no na nos nas num numa para pra pro pros pras por pelo pela com sem que se ao aos ' +
  'me te mim eu meu minha meus minhas seu sua seus suas isso isto esse essa este esta ai la aqui ate depois antes logo agora mais menos ' +
  'tambem so ja nao sim tipo coisa algo alguma algum favor por favor ola oi bom boa todo toda todos todas cada vez vezes de novo outra outro mesmo mesma ' +
  // verbos de comando (conjugações comuns)
  'marca marque marcar marcou marquei agenda agende agendar agendei agendou bota bote botar boto coloca coloque colocar coloquei poe ponha por ' +
  'anota anote anotar anotei lembra lembre lembrar lembrete avisa avise avisar cria crie criar adiciona adicione adicionar acrescenta acrescente ' +
  'inclui inclua incluir salva salve salvar registra registre registrar guarda guarde guardar muda mude mudar troca troque trocar altera altere alterar ' +
  'remarca remarque remarcar passa passe passar adia adie adiar empurra empurre joga joga cancela cancele cancelar desmarca desmarque desmarcar ' +
  'apaga apague apagar exclui exclua excluir tira tire tirar remove remova conclui conclua concluir terminei termina finaliza finalizei fiz feito feita ' +
  'pronto pronta paguei pagar paga pague gastei gastar comprei comprar recebi receber ganhei entrou saiu tenho tem tenha temos tinha quero queria ' +
  'preciso precisava precisa vou vai ir faz faca fazer ve veja ver mostra mostre mostrar lista liste listar pode poderia consegue ajuda deixa deixe ' +
  'qual quais quando quanto quanta quantos quantas como onde quem esta estou ficou fica hora marcado marcada foi era fui tava to ta sao vem ' +
  'encaixa encaixe encaixar separa separe separar reserva reserve reservar cobra cobre cobrar devendo deve devo torrei torrar esqueca esquecer deixar manda mande mandar joga jogue ' +
  // substantivos dos domínios
  'compromisso compromissos consulta consultas reuniao reunioes horario horarios agendamento agendamentos evento eventos encontro lembretes ' +
  'tarefa tarefas afazer afazeres nota notas anotacao anotacoes listas compras compra item itens mercado conta contas boleto boletos fatura ' +
  'despesa despesas gasto gastos receita receitas entrada saida pagamento pagamentos valor salario aluguel luz agua internet ' +
  'dia dias horas minuto minutos semana semanas mes meses manha tarde noite cedo inicio fim semanal mensal diario sempre ' +
  'carrinho sacola levar leva levo pega pegar pego cor cores tamanho tamanhos opcao opcoes preco precos barato barata caro cara entrega modelo modelos ' +
  'cliente clientes servico servicos corte cabelo barba medico dentista academia aula trabalho escola casa pessoal remedio financeiro financas ' +
  'carrinho levar levo compro adiciona adicione coloca cor cores tamanho modelo modelos opcao opcoes preco valor custa sai barato barata caro cara voces vcs vende vendem procuro procurando mostra mostre ver primeiro primeira segundo segunda ultimo ultima esse essa este esta ' +
  'preto preta branco branca azul vermelho vermelha verde amarelo amarela rosa cinza bege marrom pp p m g gg algodao couro jeans entrega frete pix cartao dinheiro'
).split(/\s+/).filter(Boolean))
const SLOT = /^\{(nome|data|hora|valor|num|periodo|x)\}$/
export const BLOQUEADO = '__bloqueado__'
/** Frase → modelo anônimo, ou null (inelegível) / BLOQUEADO (tentativa de manipulação). */
export function abstrair(texto: string): string | null {
  const orig = String(texto || '').trim(); if (!orig || orig.length > 240) return null
  const n0 = nrm(orig)
  if (INJECAO.test(n0)) return BLOQUEADO
  if (SENSIVEL.test(n0)) return null
  // nomes próprios (maiúscula fora do começo da frase) viram lacuna antes de normalizar
  const pal = orig.split(/\s+/).map((w, i) => (i > 0 && /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]{2,}/.test(w) ? ' {nome} ' : w)).join(' ')
  let s = nrm(pal)
  s = s.replace(/r\$\s*\d[\d.,]*|\b\d[\d.,]*\s*(reais|real|contos?|pila)\b/g, ' {valor} ')
  s = s.replace(/\b\d{1,2}:\d{2}\b|\b\d{1,2}\s*(h|hs|hrs?|horas?)(\s*\d{2})?\b|\bmeio[- ]dia\b|\bmeia[- ]noite\b/g, ' {hora} ')
  s = s.replace(/\b(dia )?\d{1,2}\/\d{1,2}(\/\d{2,4})?\b/g, ' {data} ').replace(/\b(n?esse|n?essa|n?este|n?esta|no|na|neste|nesta|deste|desta|do|da) (mes|semana|ano)( passad[oa])?\b|\b(mes|semana|ano) passad[oa]\b|\bultimos? \d+ dias\b/g, ' {periodo} ')
  s = s.replace(/\bdia \d{1,2}\b|\b(depois de amanha|amanha|hoje|ontem|anteontem)\b|\b(segunda|terca|quarta|quinta|sexta)(-| )?(feira)?\b|\b(sabado|domingo)\b|\b(semana|mes|ano) que vem\b|\bproxim[oa] (semana|mes|ano)\b|\b(janeiro|fevereiro|marco|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\b/g, ' {data} ')
  s = s.replace(/\b\d+\b/g, ' {num} ').replace(/[^a-z0-9{} ]/g, ' ')
  const toks: string[] = []
  // a 1ª palavra de um comando costuma ser o verbo (gíria incluída: "encaixa", "torrei"); fica se tiver forma de verbo e não
  // for nome próprio — o mínimo de usuários distintos (k-anonimato) impede que algo pessoal vire conhecimento
  const verbo1 = /^[a-z]{3,14}(a|e|ar|er|ir|ei|ou|i)$/
  s.split(/\s+/).filter(Boolean).forEach((t, i) => { const v = SLOT.test(t) ? t : VOCAB.has(t) || (i === 0 && verbo1.test(t) && !/^[A-ZÁÉÍÓÚÂÊÔÃÕÇ]/.test(orig)) ? t : '{x}'; if (toks[toks.length - 1] !== v || !SLOT.test(v)) toks.push(v) })
  const palavras = toks.filter((t) => !SLOT.test(t))
  if (palavras.length < 2 || toks.length > 18) return null
  return toks.join(' ')
}
/** Agrupamento: a CABEÇA do comando (até 3 palavras de conteúdo antes da primeira lacuna) + os "recipientes" citados
 *  (lista, afazeres, agenda, lembrete…). "põe na lista de afazeres {x}" e "põe na lista de afazeres trocar a {x}" são a
 *  mesma coisa; "põe na lista de compras {x}" não é. Sem cabeça (só lacunas), não agrupa. */
const FUNC = new Set('a o os as um uma uns umas de da do das dos e em no na nos nas num numa para pra pro pros pras por pelo pela com ao aos me te que se eu meu minha esse essa este esta isso ai la aqui por favor favor ola oi'.split(' '))
const RECIPIENTE = new Set('lista listas afazeres compras agenda agendamento compromisso compromissos lembrete lembretes tarefa tarefas nota notas anotacao anotacoes financeiro financas gasto gastos despesa despesas receita receitas'.split(' '))
/** Objetos do dia a dia: contam como conteúdo livre no agrupamento ("marca dentista {data}" ≈ "marca corte {data}"). */
const OBJETO = new Set('corte cabelo barba medico dentista academia aula trabalho escola casa remedio luz agua internet aluguel salario mercado boleto boletos fatura cliente clientes servico servicos reuniao reunioes consulta consultas encontro evento'.split(' '))
export function chave(tpl: string): string | null {
  const toks = tpl.split(' ').filter((t) => !FUNC.has(t)).map((t) => (OBJETO.has(t) ? '{x}' : t)), cab: string[] = []
  for (const t of toks) { if (SLOT.test(t)) { if (cab.length) break; continue } cab.push(t); if (cab.length === 3) break }
  if (!cab.length) return null
  return cab.join(' ') + '|' + [...new Set(toks.filter((t) => RECIPIENTE.has(t)))].sort().join(',')
}
/** Limite inferior de Wilson (z = 1): poucos usuários nunca dão confiabilidade alta. */
export function wilson(pos: number, n: number, z = 1) { if (!n) return 0; const p = pos / n, d = 1 + (z * z) / n; return Math.max(0, (p + (z * z) / (2 * n) - z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n))) / d) }

/* ======================= 1) coleta (em memória; gravação em lote fora da requisição) ======================= */
interface Sinal { uid: number; template: string; intent: string; kind: 'acerto' | 'correcao' | 'corrigido_para' | 'bloqueado' }
const BUF: Sinal[] = []
const ultimo = new Map<string, { uid: number; template: string | null; intent: string | null; em: number; corrigido: boolean }>()
const hoje = new Map<string, number>()
const STATS = { observados: 0, elegiveis: 0, descartados: 0, bloqueados: 0, sugestoes: 0, roteamentos: 0, consolidadoEm: null as string | null, consolidacaoMs: null as number | null }
let tmGravar: NodeJS.Timeout | null = null, tmConsolidar: NodeJS.Timeout | null = null
export interface Observacao { texto: string; ferramentasOk?: string[]; falhas?: number; tiposCriados?: string[]; intencoes?: string[]; correcao?: boolean; agora?: number }
/** Chamado ao fim de cada turno do chat. Síncrono e sem consulta ao banco: só decide e enfileira. */
export function observar(u: Pick<SessionUser, 'id'> & { memory_settings?: any }, convId: string, o: Observacao) {
  try {
    const c = cfgEmFundo(); if (!c.ativo) return
    if (u.memory_settings && (u.memory_settings as any).enabled === false) return // memória desligada: nada sai do usuário
    STATS.observados++
    const uid = Number(u.id), agora = o.agora ?? Date.now(), dia = new Date(agora).toISOString().slice(0, 10), chDia = uid + '|' + dia
    if ((hoje.get(chDia) || 0) >= c.maxPorDia) return // ninguém inunda o coletivo
    const push = (s: Sinal) => { BUF.push(s); hoje.set(chDia, (hoje.get(chDia) || 0) + 1); if (hoje.size > 20000) hoje.clear() }
    const prev = ultimo.get(convId), recente = prev && prev.uid === uid && agora - prev.em < 10 * 60_000 ? prev : null
    const tpl = abstrair(o.texto)
    const ints = [...new Set([...(o.ferramentasOk || []).map((f) => DE_FERRAMENTA[f]), ...(o.tiposCriados || []).map((t) => DE_TIPO[t]), ...(o.intencoes || []).filter((i) => !!INTENCOES[i])].filter(Boolean))] as string[]
    const escritas = ints.filter((i) => !LEITURAS.has(i)), intent = o.falhas ? null : escritas.length === 1 ? escritas[0] : !escritas.length && ints.length === 1 ? ints[0] : null
    // correção do usuário: a interpretação anterior estava errada (sinal negativo); se este turno executou a ação certa,
    // a frase ANTERIOR passa a apontar para ela (aprendizado com a correção)
    if (o.correcao && recente?.template && recente.intent) { push({ uid, template: recente.template, intent: recente.intent, kind: 'correcao' }); recente.corrigido = true }
    if (intent && recente?.corrigido && recente.template && recente.intent !== intent) { push({ uid, template: recente.template, intent, kind: 'corrigido_para' }); recente.corrigido = false }
    if (tpl === BLOQUEADO) { STATS.bloqueados++; push({ uid, template: '', intent: '', kind: 'bloqueado' }); ultimo.set(convId, { uid, template: null, intent: null, em: agora, corrigido: false }) }
    else if (tpl && intent && !o.correcao) { STATS.elegiveis++; push({ uid, template: tpl, intent, kind: 'acerto' }) }
    else if (!tpl) STATS.descartados++
    if (tpl !== BLOQUEADO && !o.correcao) ultimo.set(convId, { uid, template: tpl, intent, em: agora, corrigido: false })
    if (ultimo.size > 5000) ultimo.delete(ultimo.keys().next().value as string)
    if (BUF.length) agendarGravacao()
  } catch { /* o aprendizado coletivo nunca atrapalha o chat */ }
}
function agendarGravacao() {
  if (tmGravar) return
  foraDaRequisicao(() => { tmGravar = setTimeout(() => { tmGravar = null; void gravar().catch((e) => console.error('[coletivo] gravação:', e?.message)) }, 1500); tmGravar.unref?.() })
}
/** Grava o lote (só de quem consentiu) e agenda a consolidação. Exportado para os testes. */
export async function gravar(): Promise<number> {
  if (tmGravar) { clearTimeout(tmGravar); tmGravar = null }
  const lote = BUF.splice(0, BUF.length); if (!lote.length && !usosPend.size) return 0
  const AP = await import('./aprendizado.js'), ok = new Map<number, boolean>()
  for (const uid of new Set(lote.map((s) => s.uid))) ok.set(uid, await AP.consentimento(uid))
  let n = 0, now = nowIso()
  for (const s of lote) {
    if (!ok.get(s.uid)) continue
    await q('INSERT INTO collective_signals (user_id, template, intent, kind, created_at) VALUES ($1,$2,$3,$4,$5)', [s.uid, s.template, s.intent, s.kind, now]); n++
  }
  for (const [id, k] of usosPend) await q('UPDATE collective_knowledge SET uses = uses + $1 WHERE id = $2', [k, id]).catch(() => {})
  usosPend.clear()
  if (n && !tmConsolidar) foraDaRequisicao(() => { tmConsolidar = setTimeout(() => { tmConsolidar = null; void consolidar().catch((e) => console.error('[coletivo] consolidação:', e?.message)) }, 30_000); tmConsolidar.unref?.() })
  return n
}
/** O usuário retirou o consentimento: as contribuições dele saem do coletivo (e a consolidação recalcula sem elas). */
export async function retirarContribuicoes(userId: number) {
  for (let i = BUF.length - 1; i >= 0; i--) if (BUF[i].uid === Number(userId)) BUF.splice(i, 1)
  const r = await one('SELECT COUNT(*) AS n FROM collective_signals WHERE user_id = $1', [Number(userId)]).catch(() => null)
  await q('DELETE FROM collective_signals WHERE user_id = $1', [Number(userId)]).catch(() => {})
  if (Number(r?.n || 0) > 0) await consolidar({ revisarTodos: true }).catch((e) => console.error('[coletivo] reconsolidação:', e?.message))
}

/* ======================= 2) consolidação ======================= */
interface Hist { em: string; por: string; de: string | null; para: string; motivo: string }
export async function consolidar(o: { agora?: number; revisarTodos?: boolean } = {}): Promise<{ sinais: number; agrupamentos: number; isolados: number; consolidados: number; ativos: number; pendentes: number; contradicoes: number; suspensosAuto: number; ms: number }> {
  const t0 = Date.now(), c = await cfg(true), agora = o.agora ?? Date.now()
  const desde = new Date(agora - c.retencaoDias * 864e5).toISOString()
  await q('DELETE FROM collective_signals WHERE created_at < $1', [desde]) // retenção: sinais antigos saem; o conhecimento consolidado fica
  const AP = await import('./aprendizado.js'), ex = await AP.excluidos(desde)
  const rows = (await q('SELECT user_id, template, intent, kind FROM collective_signals WHERE created_at >= $1 ORDER BY id DESC LIMIT 50000', [desde])) as any[]
  // por modelo: usuários distintos por intenção (acertos + correções aplicadas) e usuários que corrigiram
  type G = { pos: Map<string, Set<number>>; neg: Map<string, Set<number>>; corr: Map<string, Set<number>>; usuarios: Set<number> }
  const porTpl = new Map<string, G>()
  for (const r of rows) {
    const uid = Number(r.user_id); if (!r.template || !INTENCOES[r.intent] || ex.semConsentimento.has(uid) || ex.suspeitos.has(uid)) continue
    const g = porTpl.get(r.template) || { pos: new Map(), neg: new Map(), corr: new Map(), usuarios: new Set() }; porTpl.set(r.template, g)
    const m = r.kind === 'correcao' ? g.neg : r.kind === 'corrigido_para' ? g.corr : g.pos
    const s = m.get(r.intent) || new Set(); s.add(uid); m.set(r.intent, s); g.usuarios.add(uid)
  }
  // agrupamento: variações muito parecidas (mesmo esqueleto) formam um só agrupamento; representante = o mais usado
  const existentes = (await q('SELECT * FROM collective_knowledge')) as any[]
  const tpls = [...porTpl.keys()].sort((a, b) => porTpl.get(b)!.usuarios.size - porTpl.get(a)!.usuarios.size)
  const grupos: { rep: string; chave: string; membros: string[] }[] = [], porChave = new Map<string, (typeof grupos)[number]>()
  for (const t of tpls) {
    const ch = chave(t) || '=' + t, g = porChave.get(ch)
    if (g) g.membros.push(t); else { const n = { rep: t, chave: ch, membros: [t] }; grupos.push(n); porChave.set(ch, n) }
  }
  let isolados = 0, consolidados = 0, contradicoes = 0, suspensosAuto = 0
  const now = new Date(agora).toISOString()
  const tocados = new Set<number>()
  for (const g of grupos) {
    const pos = new Map<string, Set<number>>(), neg = new Map<string, Set<number>>(), viaCorr = new Map<string, Set<number>>()
    const juntar = (dst: Map<string, Set<number>>, src: Map<string, Set<number>>) => { for (const [i, s] of src) { const d = dst.get(i) || new Set(); for (const u of s) d.add(u); dst.set(i, d) } }
    for (const m of g.membros) { const x = porTpl.get(m)!; juntar(pos, x.pos); juntar(pos, x.corr); juntar(viaCorr, x.corr); juntar(neg, x.neg) }
    // efetivos = usuários que confirmaram a intenção e NÃO a corrigiram depois
    const efetivos = (i: string, s: Set<number>) => [...s].filter((u) => !(neg.get(i) || new Set()).has(u)).length
    const ranking = [...pos.entries()].map(([i, s]) => ({ i, s, e: efetivos(i, s) })).sort((a, b) => b.e - a.e || b.s.size - a.s.size)
    if (!ranking.length || !ranking[0].e) continue
    const intent = ranking[0].i, us = ranking[0].s
    // conhecimento ATIVO deste mesmo agrupamento com outra intenção: os usuários passaram a indicar outra coisa → suspenso
    for (const r of existentes) {
      if (r.intent === intent || String(r.state) !== 'ativo' || (chave(String(r.template)) || '=' + r.template) !== g.chave || tocados.has(Number(r.id))) continue
      tocados.add(Number(r.id)); suspensosAuto++
      const hist = J<Hist[]>(r.history, []); hist.push({ em: now, por: 'consolidacao', de: 'ativo', para: 'suspenso', motivo: `contradição: correções dos usuários indicam "${INTENCOES[intent].nome}"` })
      await q('UPDATE collective_knowledge SET state = $1, manual = $2, version = $3, history = $4, updated_at = $5 WHERE id = $6', ['suspenso', false, Number(r.version) + 1, JSON.stringify(hist.slice(-40)), now, Number(r.id)])
    }
    const outros = ranking.slice(1).filter((x) => x.e >= Math.max(2, ranking[0].e * 0.3)).map((x) => [x.i, x.s] as [string, Set<number>])
    const negU = new Set<number>(neg.get(intent) || []); for (const x of ranking.slice(1)) if (x.e) for (const u of x.s) if (!us.has(u) && !(neg.get(x.i) || new Set()).has(u)) negU.add(u)
    const posN = [...us].filter((u) => !(neg.get(intent) || new Set()).has(u)).length
    const conf = Math.round(wilson(posN, posN + negU.size) * 1000) / 1000
    const linha = existentes.find((r) => r.intent === intent && (g.membros.includes(String(r.template)) || (chave(String(r.template)) || '=' + r.template) === g.chave))
    if (linha) tocados.add(Number(linha.id))
    if (us.size < c.minUsuarios && !linha) { isolados++; continue } // caso isolado: fica só como sinal, nunca vira conhecimento
    consolidados++
    const contr = outros.map(([i, s]) => ({ intencao: i, usuarios: s.size }))
    if (contr.length) contradicoes++
    const origem = (viaCorr.get(intent)?.size || 0) === 0 ? 'acertos' : (viaCorr.get(intent)!.size >= us.size ? 'correcoes' : 'misto')
    const proposto = contr.length ? 'pendente' : conf >= c.confAtivar && us.size >= c.minUsuarios ? 'ativo' : 'pendente'
    const membros = JSON.stringify(g.membros.slice(0, 20)), cat = INTENCOES[intent].categoria
    if (!linha) {
      const hist: Hist[] = [{ em: now, por: 'consolidacao', de: null, para: proposto, motivo: `${us.size} usuário(s) distintos · confiabilidade ${Math.round(conf * 100)}%${contr.length ? ' · contradição' : ''}` }]
      await q('INSERT INTO collective_knowledge (template, intent, category, origin, members, users, support, negatives, contradictions, reliability, state, manual, version, uses, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$16)',
        [g.rep, intent, cat, origem, membros, us.size, posN, negU.size, JSON.stringify(contr), conf, proposto, false, 1, 0, JSON.stringify(hist), now])
      continue
    }
    let estado = String(linha.state), motivo = ''
    const manual = B(linha.manual)
    if (estado === 'rejeitado' || estado === 'removido') { /* decisão do administrador: nunca reativado sozinho */ }
    else if (estado === 'ativo' && (conf < 0.4 || contr.length)) { estado = 'suspenso'; motivo = contr.length ? 'contradição detectada' : `confiabilidade caiu para ${Math.round(conf * 100)}% (correções)`; suspensosAuto++ }
    else if (!manual) { if (proposto !== estado) { estado = proposto; motivo = `${us.size} usuário(s) · confiabilidade ${Math.round(conf * 100)}%` } }
    const mudou = estado !== String(linha.state)
    const hist = J<Hist[]>(linha.history, []); if (mudou) hist.push({ em: now, por: 'consolidacao', de: String(linha.state), para: estado, motivo })
    await q('UPDATE collective_knowledge SET members = $1, users = $2, support = $3, negatives = $4, contradictions = $5, reliability = $6, origin = $7, state = $8, version = $9, history = $10, updated_at = $11, manual = $12 WHERE id = $13',
      [membros, us.size, posN, negU.size, JSON.stringify(contr), conf, origem, estado, Number(linha.version) + (mudou ? 1 : 0), JSON.stringify(hist.slice(-40)), now, mudou ? false : manual, Number(linha.id)])
  }
  // retirada de consentimento: o que ficou sem nenhuma contribuição deixa de valer (sem apagar o histórico)
  if (o.revisarTodos) for (const r of existentes) {
    if (tocados.has(Number(r.id)) || ['rejeitado', 'removido', 'suspenso'].includes(String(r.state))) continue
    const hist = J<Hist[]>(r.history, []); hist.push({ em: now, por: 'consolidacao', de: String(r.state), para: 'suspenso', motivo: 'contribuições retiradas (consentimento revogado)' })
    await q('UPDATE collective_knowledge SET users = 0, support = 0, state = $1, manual = $2, version = $3, history = $4, updated_at = $5 WHERE id = $6', ['suspenso', false, Number(r.version) + 1, JSON.stringify(hist.slice(-40)), now, Number(r.id)]); suspensosAuto++
  }
  IDX = null; await recarregar()
  const est = await contagens()
  STATS.consolidadoEm = now; STATS.consolidacaoMs = Date.now() - t0
  return { sinais: rows.length, agrupamentos: grupos.length, isolados, consolidados, ativos: est.ativo || 0, pendentes: est.pendente || 0, contradicoes, suspensosAuto, ms: Date.now() - t0 }
}

/* ======================= 3) recuperação por relevância (índice em memória) ======================= */
interface Item { id: number; rep: string; intent: string; conf: number; membros: string[] }
let IDX: { porTpl: Map<string, Item>; porChave: Map<string, Item>; itens: Item[]; em: number } | null = null, carregando = false
const usosPend = new Map<number, number>()
export async function recarregar() {
  carregando = true
  try {
    const rows = (await q("SELECT id, template, intent, members, reliability FROM collective_knowledge WHERE state = 'ativo'")) as any[]
    const porTpl = new Map<string, Item>(), porChave = new Map<string, Item>(), itens: Item[] = []
    for (const r of rows) {
      if (!INTENCOES[r.intent]) continue
      const membros = [...new Set([String(r.template), ...J<string[]>(r.members, [])])]
      const it: Item = { id: Number(r.id), rep: String(r.template), intent: String(r.intent), conf: Number(r.reliability), membros }
      itens.push(it)
      for (const m of membros) { const ja = porTpl.get(m); if (!ja || ja.conf < it.conf) porTpl.set(m, it); const ch = chave(m); if (ch) { const jc = porChave.get(ch); if (!jc || jc.conf < it.conf) porChave.set(ch, it) } }
    }
    IDX = { porTpl, porChave, itens, em: Date.now() }
  } finally { carregando = false }
}
export interface Sugestao { id: number; intencao: string; nome: string; dominio: Dominio; prioridade: 'operacao' | 'consulta_interna'; confiabilidade: number; semelhanca: number; modelo: string }
/** Conhecimento coletivo para esta frase (sem consulta ao banco). null = não há conhecimento suficiente. */
export function sugerir(texto: string, o: { min?: number; escopo?: 'loja' | 'assistente' } = {}): Sugestao | null {
  const c = cfgEmFundo(); if (!c.ativo) return null
  if ((!IDX || Date.now() - IDX.em > 60_000) && !carregando) foraDaRequisicao(() => void recarregar().catch(() => { carregando = false }))
  if (!IDX || !IDX.itens.length) return null
  const tpl = abstrair(texto); if (!tpl || tpl === BLOQUEADO) return null
  let best: Item | null = IDX.porTpl.get(tpl) || null, sem = best ? 1 : 0
  const esc = o.escopo || 'assistente'
  if (best && escopoDe(best.intent) !== esc) { best = null; sem = 0 }
  if (!best) { const ch = chave(tpl); if (ch) { best = IDX.porChave.get(ch) || null; sem = best ? 0.8 : 0 } }
  if (best && escopoDe(best.intent) !== esc) return null
  if (!best || best.conf < (o.min ?? c.confAtivar)) return null
  STATS.sugestoes++; usosPend.set(best.id, (usosPend.get(best.id) || 0) + 1)
  const I = INTENCOES[best.intent]
  return { id: best.id, intencao: best.intent, nome: I.nome, dominio: I.dominio, prioridade: I.prioridade, confiabilidade: best.conf, semelhanca: Math.round(sem * 100) / 100, modelo: best.rep }
}
/** Roteamento: só quando a decisão local NÃO reconheceu operação nem consulta (o individual/conversa prevalece). */
export function ajustarDecisao<D extends { prioridade: string; dominio: any; pesquisa: string; motivo: string; nivel: number; modo: string; esclarecer?: string }>(texto: string, d: D): Sugestao | null {
  const c = cfgEmFundo(); if (!c.ativo || !c.usarNoRoteamento) return null
  if (!['conversa', 'conhecimento', 'pesquisa_atual'].includes(d.prioridade) || d.esclarecer) return null
  const s = sugerir(texto, { min: c.confRoteamento }); if (!s) return null
  Object.assign(d, { prioridade: s.prioridade, dominio: s.dominio, pesquisa: 'bloqueada', nivel: 2, modo: s.prioridade === 'operacao' ? 'execucao' : 'consulta', motivo: `conhecimento coletivo: frases equivalentes de vários usuários significam "${s.nome}" (${Math.round(s.confiabilidade * 100)}%)` })
  STATS.roteamentos++; return s
}
/** Dica para a IA (apoio, nunca regra; o individual prevalece). */
export function contextoIA(texto: string): string {
  const c = cfgEmFundo(); if (!c.ativo || !c.usarNaIA) return ''
  const s = sugerir(texto); if (!s) return ''
  return `Conhecimento coletivo (anônimo, consolidado de vários usuários): pedidos escritos assim costumam significar "${s.nome}" (confiabilidade ${Math.round(s.confiabilidade * 100)}%). Use só como apoio para entender a intenção; o que este usuário disse, as preferências e os aprendizados DELE e o contexto desta conversa sempre prevalecem. Se houver dúvida real, pergunte.`
}

/* ======================= 4) governança (painel) ======================= */
async function contagens() { const r = (await q('SELECT state, COUNT(*) AS n FROM collective_knowledge GROUP BY state')) as any[]; return Object.fromEntries(r.map((x) => [String(x.state), Number(x.n)])) as Record<string, number> }
const publico = (r: any) => ({ id: Number(r.id), modelo: String(r.template), intencao: String(r.intent), nome: INTENCOES[r.intent]?.nome || r.intent, categoria: String(r.category), origem: String(r.origin), variacoes: J<string[]>(r.members, []).length, usuarios: Number(r.users), apoio: Number(r.support), negativos: Number(r.negatives), contradicoes: J<any[]>(r.contradictions, []).map((x) => ({ ...x, nome: INTENCOES[x.intencao]?.nome || x.intencao })), confiabilidade: Math.round(Number(r.reliability) * 100), estado: String(r.state), manual: B(r.manual), versao: Number(r.version), usos: Number(r.uses), historico: J<Hist[]>(r.history, []).slice(-12), criadoEm: r.created_at, atualizadoEm: r.updated_at })
export async function painel(f: { estado?: string; categoria?: string } = {}) {
  const c = await cfg(true), est = await contagens()
  const sinais = await one("SELECT COUNT(*) AS n, COUNT(DISTINCT template) AS m, SUM(CASE WHEN kind = 'bloqueado' THEN 1 ELSE 0 END) AS b, SUM(CASE WHEN kind = 'correcao' THEN 1 ELSE 0 END) AS c FROM collective_signals")
  const ws: string[] = [], ps: any[] = []
  if (f.estado && ['pendente', 'ativo', 'suspenso', 'rejeitado', 'removido'].includes(f.estado)) { ps.push(f.estado); ws.push(`state = $${ps.length}`) }
  if (f.categoria) { ps.push(f.categoria); ws.push(`category = $${ps.length}`) }
  const itens = ((await q(`SELECT * FROM collective_knowledge ${ws.length ? 'WHERE ' + ws.join(' AND ') : ''} ORDER BY updated_at DESC, id DESC LIMIT 200`, ps)) as any[]).map(publico)
  const todos = (await q('SELECT category, origin, reliability, state, updated_at, created_at, version FROM collective_knowledge')) as any[]
  const porCat: Record<string, number> = {}, porOrigem: Record<string, number> = {}; let somaConf = 0, nAt = 0, atualizados = 0
  for (const r of todos) { porCat[r.category] = (porCat[r.category] || 0) + 1; porOrigem[r.origin] = (porOrigem[r.origin] || 0) + 1; if (r.state === 'ativo') { somaConf += Number(r.reliability); nAt++ } if (Number(r.version) > 1) atualizados++ }
  return {
    config: c,
    totais: { conhecimentos: todos.length, ativos: est.ativo || 0, pendentes: est.pendente || 0, suspensos: est.suspenso || 0, rejeitados: est.rejeitado || 0, removidos: est.removido || 0, atualizados, confiabilidadeMedia: nAt ? Math.round((somaConf / nAt) * 100) : null, sinais: Number(sinais?.n || 0), padroesObservados: Number(sinais?.m || 0), bloqueados: Number(sinais?.b || 0), correcoes: Number(sinais?.c || 0) },
    porCategoria: porCat, porOrigem,
    uso: { ...STATS, observacao: 'Contadores desde o último reinício do servidor.' },
    itens,
    privacidade: 'Só modelos anônimos (sem nomes, números, datas, valores ou palavras fora do vocabulário comum) e contagens de usuários distintos. Nenhum texto de conversa, nenhum usuário identificado.',
  }
}
export type Acao = 'aprovar' | 'suspender' | 'rejeitar' | 'remover' | 'reativar' | 'reverter'
export async function revisar(id: number, acao: Acao, quem: string) {
  const r = await one('SELECT * FROM collective_knowledge WHERE id = $1', [id]); if (!r) throw Object.assign(new Error('Conhecimento coletivo não encontrado.'), { status: 404 })
  const hist = J<Hist[]>(r.history, []), atual = String(r.state)
  let novo: string
  if (acao === 'reverter') {
    const ult = [...hist].reverse().find((h) => h.de && h.para === atual)
    if (!ult || !ult.de) throw Object.assign(new Error('Não há versão anterior para reverter.'), { status: 400 })
    novo = ult.de
  } else novo = ({ aprovar: 'ativo', reativar: 'ativo', suspender: 'suspenso', rejeitar: 'rejeitado', remover: 'removido' } as Record<string, string>)[acao]
  if (!novo) throw Object.assign(new Error('Ação inválida.'), { status: 400 })
  hist.push({ em: nowIso(), por: quem, de: atual, para: novo, motivo: acao === 'reverter' ? 'revertido pelo administrador' : `${acao} pelo administrador` })
  await q('UPDATE collective_knowledge SET state = $1, manual = $2, version = $3, history = $4, updated_at = $5 WHERE id = $6', [novo, true, Number(r.version) + 1, JSON.stringify(hist.slice(-40)), nowIso(), id])
  IDX = null; await recarregar()
  return publico(await one('SELECT * FROM collective_knowledge WHERE id = $1', [id]))
}
/** Para os testes e o diagnóstico. */
export function _reiniciar() { BUF.length = 0; ultimo.clear(); hoje.clear(); usosPend.clear(); IDX = null; cfgLidoEm = 0; for (const k of Object.keys(STATS) as (keyof typeof STATS)[]) (STATS as any)[k] = typeof STATS[k] === 'number' ? 0 : null }
export const _estado = () => ({ buffer: BUF.length, indice: IDX ? IDX.itens.length : null, stats: { ...STATS } })
