// CONTINUIDADE OPERACIONAL (sem IA) — lembretes, tarefas, notas e contas a pagar criados/citados nesta conversa.
// Completa o que já existia para compromissos (ai/convctx.ts + ai/agenda-edicao.ts) e lançamentos (ai/finchat.ts):
//   "me lembra de ligar pro banco amanhã às 9h" → "mude para 10h"
//   "cria uma tarefa de revisar o contrato"    → "adiciona a descrição: cláusula 4" / "coloca prazo para sexta"
//   "anota que o fornecedor mudou de telefone" → "acrescente essa informação: novo número 3333-4444"
//   "cria uma conta de luz de 180 vencendo dia 10" → "altere o vencimento para dia 15"
// Regras: identifica UM registro (o último desta conversa, da memória de conversa — nunca de outra conversa ou pessoa);
// altera só o campo pedido, preserva o resto, relê o banco antes de dizer "pronto" e nunca cria um registro novo numa
// edição. O que faltar (ex.: "adicione uma observação" sem o texto) é perguntado e completado na mensagem seguinte.
import type { SessionUser } from '../lib/session.js'
import { q, one, J, nowIso } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { localDate, zonedToUtc } from '../lib/time.js'
import type { Decisao } from './prioridade.js'

type Resp = { content: string; cards: any[] } | null
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;]+/g, ' ').replace(/\s+/g, ' ').trim()
const R = (content: string): Resp => ({ content, cards: [] })
const dataBR = (iso: string | null | undefined) => iso ? String(iso).split('-').reverse().join('/') : '—'
const brl = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1)
const CANCELA_PENDENCIA = /^(deixa|esquece|cancela|nao|desisto|nada)\b/
const CONFIRMA_MESMO = /^(?:(?:sim|ok|certo)\s+)?(?:(?:e|eh)\s+)?(?:esse|essa|este|esta|isso) mesm[oa]$|^isso mesmo$|^exatamente$|^ta certo$|^pode ser$/

/** Texto depois de ":" ou de "que" ("acrescente essa informação: X", "anota que X"). */
function conteudoApos(text: string): string {
  const m = text.match(/:\s*(.{2,2000})$/s) || text.match(/\b(?:que|dizendo)\s+(.{2,2000})$/is)
  return m ? m[1].trim().replace(/[.!]+$/, '') : ''
}
async function camposData(text: string, tz: string) { return (await import('./convctx.js')).campos(text, tz) as { date?: string; time?: string } }

async function lembrar(convId: string, u: SessionUser, tipo: string, id: number, resumo: string) { await (await import('./convctx.js')).lembrarAcao(convId, u.id, tipo, id, resumo).catch(() => {}) }
async function pendencia(convId: string, u: SessionUser, p: any | null) {
  const CX = await import('./convctx.js'), c = await CX.getCtx(convId, u.id)
  if (p) c.pendente = p; else delete c.pendente
  await CX.saveCtx(convId, u.id, c)
}
async function item(u: SessionUser, tipo: string, id: number) { return one('SELECT id, type, status, day, due_at, data FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [id, u.id, tipo]) }
/** grava e relê: só confirma o que o banco mostra */
async function gravar(u: SessionUser, id: number, data: any, extra: { day?: string | null; due_at?: string | null; status?: string } = {}) {
  const sets = ['data = $1', 'updated_at = $2'], args: any[] = [JSON.stringify(data), nowIso()]
  for (const [k, v] of Object.entries(extra)) { if (v === undefined) continue; args.push(v); sets.push(`${k} = $${args.length}`) }
  args.push(id, u.id)
  await q(`UPDATE items SET ${sets.join(', ')} WHERE id = $${args.length - 1} AND user_id = $${args.length}`, args)
  return one('SELECT id, type, status, day, due_at, data FROM items WHERE id = $1 AND user_id = $2', [id, u.id])
}
const historico = (d: any, campo: string, de: any, para: any) => { d.historico = [...(Array.isArray(d.historico) ? d.historico : []), { campo, de: de ?? null, para, em: nowIso(), origem: 'chat' }].slice(-30) }

/* ======================= criação sem IA (tarefa, nota, conta a pagar) — só quando a IA falha ======================= */
const NOTA = /^(?:(?:por favor|pfv|agora|entao|e)\s+)*(?:anot[ae]|anota|cri[ae] (?:uma )?(?:nota|anotacao)|fa[cz]a? (?:uma )?(?:nota|anotacao)|salv[ae] (?:uma |como )?nota|registr[ae] (?:uma )?(?:nota|anotacao)|guard[ae] (?:uma )?nota)\b/
export function lerNota(text: string): { content: string; title: string | null } | null {
  const s = nrm(text); if (!NOTA.test(s)) return null
  let corpo = text.trim().replace(/^(?:(?:por favor|pfv|agora|ent[aã]o|e)\s+)*(?:anot[ae]|anota|cri[ae] (?:uma )?(?:nota|anota[cç][aã]o)|fa[cç]a? (?:uma )?(?:nota|anota[cç][aã]o)|salv[ae] (?:uma |como )?nota|registr[ae] (?:uma )?(?:nota|anota[cç][aã]o)|guard[ae] (?:uma )?nota)\s*/i, '')
  corpo = corpo.replace(/^(?:a[ií]\s+)?(?:que|isso|isto|o seguinte|:|-)\s*[:\-]?\s*/i, '').replace(/[.!]+$/, '').trim()
  if (corpo.length < 3) return null
  return { content: cap(corpo), title: null }
}
const CONTA = /^(?:(?:por favor|pfv|agora|entao|e)\s+)*(?:cri[ae]|cadastr[ae]|registr[ae]|adicion[ae]|anot[ae]|lan[cç][ae]|coloc[ae]|inclu[ai])\w*\s+(?:uma\s+)?(?:nova\s+)?conta\s+(?:a pagar\s+)?(?:de|da|do)\s+/i
export function lerConta(text: string, tz: string, campos: (t: string) => { date?: string }): { name: string; amount: number; due_date: string } | null {
  if (!CONTA.test(text)) return null
  const resto = text.replace(CONTA, '')
  const m = resto.match(/^(.{2,60}?)\s+(?:de|no valor de|com valor de|valor|por)\s+(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:reais|real)?\b(.*)$/i)
  if (!m) return null
  const venc = m[3].match(/\b(?:venc\w*|para|pra|no dia|dia)\b(.*)$/i)
  const due = venc ? campos(/\bdia\b|\bamanh|\bhoje|segunda|ter[cç]a|quarta|quinta|sexta|s[áa]bado|domingo|\d{1,2}\/\d{1,2}/i.test(venc[1]) ? venc[1].replace(/^\s*(?:no\s+|em\s+)?(\d{1,2})\b(?!\/)/, 'dia $1') : '') .date : undefined
  if (!due) return null
  let x = m[2]; if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(x)) x = x.replace(/\./g, ''); const amount = Number(x.replace(',', '.'))
  if (!(amount > 0)) return null
  return { name: cap(m[1].trim()), amount, due_date: due }
}

/** Criação sem IA (usada pelo resolvedor local quando a IA não está disponível; com IA, a criação segue pelas ferramentas). */
export async function criarSemIA(u: SessionUser, convId: string, text: string, pri: Pick<Decisao, 'dominio'>): Promise<Resp> {
  const tz = settingsOf(u).timezone, A = await import('./assistant.js')
  const exec = async (ferramenta: string, args: any) => { const { res, cards } = await A.executarLocal(u, ferramenta, args, text, convId); return { r: res as any, cards } }
  if (pri.dominio === 'tarefa') {
    const p = (await import('./resolver-local.js')).lerPedidoPessoal(text); if (!p || p.ferramenta !== 'create_task') return null
    const cd = await camposData(text, tz)
    let title = String(p.args.title).replace(/\s+(?:(?:para|pra|at[eé]|na|no)\s+)?(?:amanh[ãa]|hoje|depois de amanh[ãa]|segunda|ter[cç]a|quarta|quinta|sexta|s[áa]bado|domingo|dia \d{1,2}(?:\/\d{1,2})?)(?:\s+[àa]s\s+\d{1,2}(?:[:h]\d{2})?\s*h?)?\s*$/i, '').trim()
    const { r, cards } = await exec('create_task', { title: cap(title), ...(cd.date ? { due_date: cd.date } : {}), ...(cd.time ? { due_time: cd.time } : {}) })
    if (r?.deduped) return R('Essa tarefa acabou de ser criada; não criei outra.')
    const t = r?.created?.[0]; if (!r?.ok || !t) return R(`Não consegui criar a tarefa: ${String(r?.error || 'tente de novo')}. Nada foi gravado.`)
    return { content: `Pronto! Criei a tarefa "${t.title}"${t.dueDate ? ` com prazo ${dataBR(t.dueDate)}${t.dueTime ? ' às ' + t.dueTime : ''}` : ''}.`, cards }
  }
  if (pri.dominio === 'nota') {
    const n = lerNota(text); if (!n) return null
    // "anota que gastei 50" / "anota consulta amanhã às 9h" são lançamento e compromisso: ficam com os motores próprios
    if ((await import('./fin.js')).parseFinance(n.content, tz, [] as any)?.amount || (await import('./appt.js')).parseAppointment(n.content, tz) || (await import('./appt.js')).parseReminder(n.content, tz)) return null
    const { r, cards } = await exec('create_note', { content: n.content })
    if (r?.deduped) return R('Essa anotação acabou de ser salva; não salvei de novo.')
    const t = r?.created?.[0]; if (!r?.ok || !t) return R(`Não consegui salvar a anotação: ${String(r?.error || 'tente de novo')}. Nada foi gravado.`)
    return { content: `Anotado: "${t.content}".`, cards }
  }
  if (pri.dominio === 'conta') {
    const CX = await import('./convctx.js'), b = lerConta(text, tz, (t) => CX.campos(t, tz)); if (!b) return null
    if ((await import('../lib/usermod.js')).modules && (await (await import('../lib/usermod.js')).modules()).financas === false) return null
    const { r, cards } = await exec('create_bill', b)
    if (r?.deduped) return R('Essa conta acabou de ser cadastrada; não cadastrei de novo.')
    const t = r?.created?.[0]; if (!r?.ok || !t) return R(`Não consegui cadastrar a conta: ${String(r?.error || 'tente de novo')}. Nada foi gravado.`)
    return { content: `Pronto! Cadastrei a conta "${t.name}" de ${brl(t.amount)} com vencimento em ${dataBR(t.dueDate)}.`, cards }
  }
  return null
}

/* ======================= registro citado pelo nome · detalhes · exclusão ======================= */
const TIPOS_EDITAVEIS = ['appointment', 'reminder', 'task', 'bill', 'expense', 'note']
const ROTULO_TIPO: Record<string, string> = { appointment: 'o compromisso', reminder: 'o lembrete', task: 'a tarefa', bill: 'a conta', expense: 'o lançamento', note: 'a anotação' }
const nomeDe = (tipo: string, d: any) => String(d.title || d.message || d.name || d.description || (d.content ? String(d.content).slice(0, 60) : '') || 'registro')
/** Parte da frase que é o COMANDO: o conteúdo de uma observação, endereço ou nome novo nunca escolhe o registro. */
export const comandoDe = (text: string) => String(text || '').split(/:|\b(?:endere[çc]o|local|observa[çc](?:[ãa]o|[õo]es)|descri[çc][ãa]o|nome|t[ií]tulo|renome\w*)\b/i)[0]
const GENERICAS = new Set(['compromisso', 'compromissos', 'agendamento', 'lembrete', 'lembretes', 'tarefa', 'tarefas', 'conta', 'contas', 'gasto', 'gastos', 'despesa', 'lancamento', 'anotacao', 'nota', 'detalhes', 'detalhe', 'horario', 'prioridade', 'observacao', 'quais', 'mostre', 'altere', 'mude', 'troque', 'cancele', 'apague', 'esse', 'essa', 'desse', 'dessa', 'para', 'amanha', 'hoje', 'sexta', 'segunda', 'terca', 'quarta', 'quinta', 'sabado', 'domingo', 'minutos', 'horas', 'antes', 'com', 'que', 'uma', 'dos', 'das', 'nos', 'nas', 'pra', 'meu', 'minha', 'seu', 'sua', 'mais', 'por', 'ate', 'dia', 'mes', 'ano', 'hora', 'data', 'nome', 'valor', 'mude', 'muda', 'troca', 'passe', 'passa', 'altera'])
/** Registros DESTE usuário citados pelo nome/título/pessoa na frase (os mais citados primeiro). */
export async function citados(u: SessionUser, text: string, o: { tipos?: string[]; ativos?: boolean } = {}) {
  const tipos = o.tipos || ['appointment', 'reminder', 'task', 'bill'], fr = ' ' + nrm(comandoDe(text)) + ' '
  const pal = fr.trim().split(' ').filter((w) => w.length >= 3 && !GENERICAS.has(w) && !/^\d/.test(w))
  if (!pal.length) return []
  const rows: any[] = await q(`SELECT id, type, status, day, data FROM items WHERE user_id = $1 AND type IN (${tipos.map((_, i) => '$' + (i + 2)).join(',')}) ORDER BY id DESC LIMIT 400`, [u.id, ...tipos])
  const fim = ['cancelled', 'done', 'paid', 'no_show']
  const sc = rows.filter((r) => !o.ativos || !fim.includes(String(r.status))).map((r) => {
    const d = J<any>(r.data, {}), nomes = [nomeDe(r.type, d), d.person, d.clienteNome].filter(Boolean).map((x: string) => nrm(x))
    const ws = new Set(nomes.join(' ').split(' ').filter((w) => w.length >= 3 && !GENERICAS.has(w)))
    let n = 0; for (const w of pal) if (ws.has(w)) n++
    if (nomes.some((x) => x.length >= 4 && fr.includes(' ' + x + ' '))) n += 2
    return { r, n }
  }).filter((x) => x.n > 0)
  if (!sc.length) return []
  const max = Math.max(...sc.map((x) => x.n))
  return sc.filter((x) => x.n === max).map((x) => x.r)
}
const DIAS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado']
const quandoBR = (day: string | null, time?: string | null) => { if (!day) return '—'; const [y, m, d] = String(day).split('-').map(Number); const w = DIAS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()]; return `${w}, ${dataBR(day)}${time ? ' às ' + time : ''}` }
const antes = (v: number[]) => v.length ? v.map((n) => n % 1440 === 0 ? `${n / 1440} dia${n / 1440 > 1 ? 's' : ''}` : n % 60 === 0 ? `${n / 60} h` : `${n} min`).join(' e ') + ' antes' : 'sem aviso'
const SIT: Record<string, Record<string, string>> = {
  appointment: { scheduled: 'Agendado', confirmed: 'Confirmado', done: 'Concluído', cancelled: 'Cancelado', no_show: 'Não compareceu' },
  reminder: { pending: 'Ativo', done: 'Concluído ou cancelado' }, task: { pending: 'Pendente', in_progress: 'Em andamento', done: 'Concluída' },
  bill: { pending: 'A pagar', paid: 'Paga' }, expense: { done: 'Registrado' }, note: {},
}
/** Detalhes de UM registro, lidos agora do banco (nunca da memória da conversa). */
export async function mostrar(u: SessionUser, tipo: string, id: number): Promise<string | null> {
  const r: any = await one('SELECT id, type, status, day, due_at, data FROM items WHERE id = $1 AND user_id = $2', [id, u.id]); if (!r) return null
  const d = J<any>(r.data, {}), L: string[] = [], add = (rot: string, v: unknown) => { if (v !== undefined && v !== null && String(v).trim() !== '') L.push(`${rot}: ${v}`) }
  const sit = SIT[r.type]?.[r.status] || ''
  if (r.type === 'appointment') {
    const av = Array.isArray(d.reminders) ? d.reminders : d.reminderMinutes > 0 ? [d.reminderMinutes] : []
    add('Quando', quandoBR(r.day, d.time)); add('Com', d.clienteNome || d.person); add('Telefone', d.clienteTelefone ? String(d.clienteTelefone).replace(/^(\d{2})(\d{4,5})(\d{4})$/, '($1) $2-$3') : ''); add('Local', d.location)
    add('Duração', d.duracaoMin ? `${d.duracaoMin} min` : ''); add('Observações', d.notes); add('Prioridade', d.priority === 'high' ? 'alta' : ''); add('Lembrete', antes(av)); add('Valor', d.valorTotal != null ? brl(d.valorTotal) : ''); add('Situação', sit)
    return `**${d.title || 'Compromisso'}**\n- ${L.join('\n- ')} ⟦appt:${r.id}⟧`
  }
  if (r.type === 'reminder') { add('Quando', quandoBR(d.date || r.day, d.time)); add('Repetição', d.recurrence && d.recurrence !== 'none' ? d.recurrence : ''); add('Observações', d.notes); add('Situação', sit); return `**Lembrete: ${d.message}**\n- ${L.join('\n- ')}` }
  if (r.type === 'task') { add('Prazo', r.day ? quandoBR(r.day, d.dueTime) : 'sem prazo'); add('Prioridade', d.priority === 'high' ? 'alta' : 'normal'); add('Descrição', d.notes); add('Situação', sit); return `**Tarefa: ${d.title}**\n- ${L.join('\n- ')}` }
  if (r.type === 'bill') { add('Valor', brl(d.amount)); add('Vencimento', quandoBR(r.day)); add('Categoria', d.category); add('Observações', d.notes); add('Situação', sit); return `**Conta: ${d.name}**\n- ${L.join('\n- ')}` }
  if (r.type === 'expense') { add('Valor', brl(d.amount)); add('Data', quandoBR(r.day)); add('Categoria', d.subcategory || d.category); add('Pagamento', d.method); add('Observação', d.observacao || d.notes); return `**${d.kind === 'income' ? 'Receita' : 'Gasto'}: ${d.description || ''}**\n- ${L.join('\n- ')}` }
  if (r.type === 'note') return `**Anotação**\n${d.content}`
  return null
}
const TIPO_DE_DOM: Record<string, string> = { agenda: 'appointment', lembrete: 'reminder', tarefa: 'task', conta: 'bill', financeiro: 'expense', nota: 'note' }
async function detalhes(u: SessionUser, convId: string, text: string, pri: Decisao): Promise<Resp> {
  const CX = await import('./convctx.js'), c = await CX.getCtx(convId, u.id), tipoDom = pri.dominio ? TIPO_DE_DOM[pri.dominio] : ''
  const cit = await citados(u, text, { tipos: tipoDom ? [tipoDom] : undefined })
  let alvo: { tipo: string; id: number } | null = null
  if (cit.length === 1) alvo = { tipo: cit[0].type, id: Number(cit[0].id) }
  else if (cit.length > 1) {
    const ctxId = pri.alvo && cit.find((r: any) => Number(r.id) === pri.alvo!.id)
    if (ctxId) alvo = { tipo: ctxId.type, id: Number(ctxId.id) }
    else return R(`Encontrei ${cit.length} registros com esse nome:\n${cit.slice(0, 6).map((r: any, i: number) => { const d = J<any>(r.data, {}); return `${i + 1}. ${nomeDe(r.type, d)} — ${quandoBR(r.day, d.time || d.dueTime)}` }).join('\n')}\nDe qual você quer os detalhes?`)
  } else if (tipoDom && c.ultimos?.[tipoDom]) alvo = { tipo: tipoDom, id: Number(c.ultimos[tipoDom]) }
  else if (pri.alvo) alvo = pri.alvo
  if (!alvo) return null
  const m = await mostrar(u, alvo.tipo, alvo.id); if (!m) return R('Não encontrei esse registro (pode ter sido apagado). Nada foi alterado.')
  await lembrar(convId, u, alvo.tipo, alvo.id, 'consultado')
  return R(m)
}
const PEDE_EXCLUIR = /\b(apag\w*|exclu\w*|delet\w*|remov\w*|elimin\w*)\b/
const SIM = /^(?:sim|s|pode|pode sim|confirmo|confirma|isso|ok|claro|apaga|apague|pode apagar|exclui|exclua|pode excluir)\b/
async function pedirExclusao(u: SessionUser, convId: string, tipo: string, id: number): Promise<Resp> {
  const r: any = await item(u, tipo, id); if (!r) return R('Não encontrei esse registro. Nada foi alterado.')
  const d = J<any>(r.data, {})
  await pendencia(convId, u, { tipo: 'editar_item', item: tipo, id, falta: 'excluir' })
  return R(`Confirma apagar ${ROTULO_TIPO[tipo]} "${nomeDe(tipo, d)}"${tipo === 'expense' || tipo === 'bill' ? ` de ${brl(d.amount)}` : ''}? Isso não pode ser desfeito. (sim/não)`)
}
async function excluir(u: SessionUser, convId: string, tipo: string, id: number, text: string): Promise<Resp> {
  if (!SIM.test(nrm(text))) return R('Certo, não apaguei nada.')
  const r: any = await item(u, tipo, id); if (!r) return R('Esse registro já não existe. Nada foi alterado.')
  const { itemAction } = await import('../routes/items.js'), { db } = await import('../db/index.js')
  try { await db().tx((t: any) => itemAction(u, 'delete', tipo, id, {}, t)) } catch (e: any) { return R(`Não consegui apagar: ${e?.message || 'tente de novo'}. Nada foi alterado.`) }
  if (await item(u, tipo, id)) return R('Não consegui confirmar a exclusão no banco. Abra o registro para conferir.')
  return R(`Apaguei ${ROTULO_TIPO[tipo]} "${nomeDe(tipo, J<any>(r.data, {}))}".`)
}

/* ======================= edição do registro desta conversa ======================= */
const PERG: Record<string, string> = { prioridade: 'Qual prioridade? (alta ou normal)', observacao: 'Qual informação devo acrescentar?', descricao: 'Qual é a descrição?', horario: 'Para que horário?', data: 'Para que dia?', valor: 'Qual é o novo valor?', titulo: 'Qual é o novo nome?', qualquer: 'O que devo alterar?' }
const QUER_INFO = /\b(observac\w*|obs|informac\w*|detalhes?|descricao|nota|comentario|lembrete de que)\b/
const VERBO_ADD = /^(?:(?:por favor|pfv|agora|entao|e|so|tambem|pode|eu|quero|queria|gostaria de|preciso|vamos)\s+)*(?:adicion|acrescent|inclu|coloc|ponh|bot|anex|complement|escrev|insir)\w*/

async function editar(u: SessionUser, convId: string, tipo: string, id: number, text: string, falta?: string): Promise<Resp> {
  const tz = settingsOf(u).timezone, s = nrm(text), r = await item(u, tipo, id)
  if (!r) return null
  const d = J<any>(r.data, {}), cd = await camposData(text, tz), info = conteudoApos(text)
  const pedir = async (f: string, rotulo: string) => { await pendencia(convId, u, { tipo: 'editar_item', item: tipo, id, falta: f }); return R(`${PERG[f]}${rotulo ? ` (${rotulo})` : ''}`) }
  const resp = (L: string[], nome: string) => R(`Pronto! Atualizei ${nome}:\n- ${L.join('\n- ')}`)
  if (falta === 'excluir') return excluir(u, convId, tipo, id, text)
  // observação em lembrete e conta ("adicione uma observação: conta da casa da praia") — acrescenta, não apaga o que havia
  if ((tipo === 'reminder' || tipo === 'bill') && (falta === 'observacao' || (!falta && /\b(observac\w*|obs|informac\w*|nota|detalhes?|comentario)\b/.test(nrm(text.split(':')[0]))))) {
    const v = falta ? text.trim() : info; const nm = tipo === 'reminder' ? `lembrete "${d.message}"` : `conta "${d.name}"`
    if (!v) return pedir('observacao', nm)
    const nv = [d.notes, cap(v)].filter(Boolean).join('\n'); historico(d, 'observacao', d.notes, nv); d.notes = nv
    const nr = await gravar(u, id, d); if (J<any>(nr?.data, {}).notes !== nv) return R('Não consegui confirmar a alteração no banco. Nada foi afirmado.')
    await lembrar(convId, u, tipo, id, 'observação')
    return resp([`Observações: ${nv.replace(/\n/g, ' · ')}`], tipo === 'reminder' ? `o lembrete "${d.message}"` : `a conta "${d.name}"`)
  }

  if (tipo === 'reminder') {
    if (/\b(cancel|desmarc|apag|exclu|remov)/.test(s) && !falta) {
      const nr = await gravar(u, id, d, { status: 'done', due_at: null })
      return nr?.status === 'done' ? R(`Cancelei o lembrete "${d.message}".`) : R('Não consegui cancelar o lembrete agora. Nada foi alterado.')
    }
    let date = d.date || r.day, time = d.time
    if (falta === 'horario' || /\b(\d{1,2}\s*h|\d{1,2}[:h]\d{2}|as \d|horario|hora)\b/.test(s)) { if (cd.time) time = cd.time; else if (falta !== 'data') return pedir('horario', `lembrete "${d.message}"`) }
    if (cd.date && (falta === 'data' || /\b(para|pra|dia|amanha|hoje|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/.test(s))) date = cd.date
    const msgNova = /\b(texto|mensagem|assunto|o que)\b/.test(s) && info ? info : null
    if (date === (d.date || r.day) && time === d.time && !msgNova) return /\b(\d|amanha|hoje|dia)\b/.test(s) ? R(`O lembrete "${d.message}" já estava assim (${dataBR(date)} às ${time}); não mudei nada.`) : null
    const remindAt = zonedToUtc(date, time, tz), due = new Date(new Date(remindAt).getTime() - (Number(d.leadMinutes) || 0) * 60_000).toISOString()
    const L: string[] = []
    if (date !== (d.date || r.day)) { L.push(`Data: ${dataBR(d.date || r.day)} → ${dataBR(date)}`); historico(d, 'data', d.date, date) }
    if (time !== d.time) { L.push(`Horário: ${d.time} → ${time}`); historico(d, 'horario', d.time, time) }
    if (msgNova) { L.push(`Texto: ${d.message} → ${msgNova}`); historico(d, 'mensagem', d.message, msgNova); d.message = msgNova }
    Object.assign(d, { date, time, remindAt })
    const nr = await gravar(u, id, d, { day: date, due_at: due, status: 'pending' }), nd = J<any>(nr?.data, {})
    if (!nr || nd.time !== time || nr.day !== date) return R('Não consegui confirmar a alteração no banco. Nada foi afirmado — abra o lembrete para conferir.')
    await lembrar(convId, u, 'reminder', id, 'atualizado: ' + nd.message)
    return resp(L, `o lembrete "${nd.message}"`)
  }

  if (tipo === 'task') {
    const L: string[] = []; let day: string | null | undefined
    if (/\b(conclu|finaliz|feit[ao]|terminad[ao])\w*/.test(s) && !falta) {
      const nr = await gravar(u, id, { ...d, completedAt: nowIso() }, { status: 'done' })
      return nr?.status === 'done' ? R(`Marquei a tarefa "${d.title}" como concluída.`) : R('Não consegui concluir a tarefa agora. Nada foi alterado.')
    }
    const sc = nrm(comandoDe(text))
    if (falta === 'prioridade' || (!falta && /\b(prioridade|prioritari[oa]|urgente)\b/.test(sc))) {
      const nv = /\b(tir\w*|remov\w*|sem prioridade|normal|baixa)\b/.test(falta ? s : sc) ? 'normal' : 'high'
      if ((d.priority || 'normal') === nv) return R(`A tarefa "${d.title}" já estava com prioridade ${nv === 'high' ? 'alta' : 'normal'}; não mudei nada.`)
      L.push(`Prioridade: ${(d.priority || 'normal') === 'high' ? 'alta' : 'normal'} → ${nv === 'high' ? 'alta' : 'normal'}`); historico(d, 'prioridade', d.priority || 'normal', nv); d.priority = nv
    } else if (falta === 'observacao' || falta === 'descricao' || (VERBO_ADD.test(s) || /\b(descricao|observac\w*|detalhe)\b/.test(s)) && QUER_INFO.test(s)) {
      const v = falta ? text.trim() : info; if (!v) return pedir(/descricao/.test(s) ? 'descricao' : 'observacao', `tarefa "${d.title}"`)
      const nv = [d.notes, cap(v)].filter(Boolean).join('\n'); historico(d, 'descricao', d.notes, nv); d.notes = nv; L.push(`Descrição: ${cap(v)}`)
    } else if (falta === 'titulo' || /\b(titulo|nome|renome)\w*/.test(s)) {
      const v = falta ? text.trim() : (text.match(/\b(?:para|pra|:)\s*["“]?(.{2,200}?)["”]?\s*$/i)?.[1] || ''); if (!v) return pedir('titulo', `tarefa "${d.title}"`)
      L.push(`Nome: ${d.title} → ${cap(v)}`); historico(d, 'titulo', d.title, cap(v)); d.title = cap(v)
    } else {
      if (cd.date && (falta === 'data' || /\b(prazo|data|dia|para|pra|ate)\b/.test(s))) { if (cd.date !== r.day) { L.push(`Prazo: ${dataBR(r.day)} → ${dataBR(cd.date)}`); historico(d, 'prazo', r.day, cd.date); day = cd.date } }
      if (cd.time && (falta === 'horario' || /\b(hora|horario|as \d|\d{1,2}\s*h)\b/.test(s))) { if (cd.time !== d.dueTime) { L.push(`Horário: ${d.dueTime || '—'} → ${cd.time}`); historico(d, 'horario', d.dueTime, cd.time); d.dueTime = cd.time } }
      if (!L.length) { if (/\b(prazo|data|dia)\b/.test(s) && !cd.date) return pedir('data', `tarefa "${d.title}"`); if (/\b(hora|horario)\b/.test(s) && !cd.time) return pedir('horario', `tarefa "${d.title}"`); return null }
    }
    if (!L.length) return null
    const nr = await gravar(u, id, d, day !== undefined ? { day } : {}), nd = J<any>(nr?.data, {})
    if (!nr || nd.title !== d.title || (day !== undefined && nr.day !== day) || nd.notes !== d.notes || (nd.priority || 'normal') !== (d.priority || 'normal')) return R('Não consegui confirmar a alteração no banco. Nada foi afirmado — abra a tarefa para conferir.')
    await lembrar(convId, u, 'task', id, 'atualizada: ' + nd.title)
    return resp(L, `a tarefa "${nd.title}"`)
  }

  if (tipo === 'note') {
    if (/\b(titulo|nome)\b/.test(s) && !falta) {
      const v = text.match(/\b(?:para|pra|:)\s*["“]?(.{2,200}?)["”]?\s*$/i)?.[1]; if (!v) return pedir('titulo', 'anotação')
      historico(d, 'titulo', d.title, cap(v)); d.title = cap(v)
      const nr = await gravar(u, id, d); return J<any>(nr?.data, {}).title === d.title ? (await lembrar(convId, u, 'note', id, 'atualizada'), R(`Pronto! A anotação agora se chama "${d.title}".`)) : R('Não consegui confirmar a alteração no banco.')
    }
    const v = falta ? text.trim() : info || (VERBO_ADD.test(s) && !QUER_INFO.test(s) ? text.replace(/^(?:(?:por favor|pfv|agora|ent[aã]o|e|s[oó]|tamb[eé]m|pode)\s+)*(?:adicion|acrescent|inclu|coloc|ponh|bot|anex|complement|escrev|insir)\w*\s+(?:tamb[eé]m\s+)?(?:que\s+)?/i, '').trim() : '')
    if (!v || v.length < 2) { if (VERBO_ADD.test(s) || QUER_INFO.test(s)) return pedir('observacao', 'na anotação'); return null }
    const nv = `${d.content}\n${cap(v)}`; historico(d, 'conteudo', null, cap(v)); d.content = nv
    const nr = await gravar(u, id, d)
    if (J<any>(nr?.data, {}).content !== nv) return R('Não consegui confirmar a alteração no banco. Nada foi afirmado.')
    await lembrar(convId, u, 'note', id, 'atualizada')
    return R(`Pronto! Acrescentei à anotação: "${cap(v)}".`)
  }

  if (tipo === 'bill') {
    const L: string[] = []; let day: string | undefined
    if (cd.date && (falta === 'data' || /\b(venc\w*|data|dia|para|pra)\b/.test(s))) { if (cd.date !== r.day) { L.push(`Vencimento: ${dataBR(r.day)} → ${dataBR(cd.date)}`); historico(d, 'vencimento', r.day, cd.date); day = cd.date } }
    else if (/\b(venc\w*|data)\b/.test(s) && !falta) return pedir('data', `conta "${d.name}"`)
    const mv = (falta === 'valor' ? text : '').match(/(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/) || (/\b(valor|total|preco)\b/.test(s) ? s.match(/\b(?:para|pra|por|:|=)\s*(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/) : null)
    if (mv) { let x = mv[1]; if (/^\d{1,3}(\.\d{3})+/.test(x)) x = x.replace(/\./g, ''); const v = Number(x.replace(',', '.')); if (v > 0 && v !== Number(d.amount)) { L.push(`Valor: ${brl(d.amount)} → ${brl(v)}`); historico(d, 'valor', d.amount, v); d.amount = v } }
    else if (/\b(valor|total|preco)\b/.test(s) && !falta) return pedir('valor', `conta "${d.name}"`)
    if (/\b(cancel|exclu|apag|remov)/.test(s) && !L.length) return null // exclusão: fica com a tela/IA (ação irreversível)
    if (!L.length) return null
    const nr = await gravar(u, id, d, day ? { day } : {})
    if (!nr || (day && nr.day !== day) || Number(J<any>(nr.data, {}).amount) !== Number(d.amount)) return R('Não consegui confirmar a alteração no banco. Nada foi afirmado.')
    await lembrar(convId, u, 'bill', id, 'atualizada: ' + d.name)
    return resp(L, `a conta "${d.name}"`)
  }

  if (tipo === 'expense' && falta) { // resposta à pergunta "Qual informação devo acrescentar?" sobre um lançamento
    const campo = falta === 'descricao' ? 'descricao' : 'observacao'
    const FC = await import('./finchat.js')
    return FC.corrigirCampo(u, id, campo, text.trim())
  }
  return null
}

/** Ponto de entrada (chat.ts), só para mensagens que o motor de prioridade marcou como operação/continuação. */
export async function responder(u: SessionUser, convId: string, text: string, pri: Decisao): Promise<Resp> {
  if (!convId) return null
  if (pri.detalhes) return detalhes(u, convId, text, pri)
  const CX = await import('./convctx.js'), c = await CX.getCtx(convId, u.id), s = nrm(text)
  // resposta ao que perguntamos na mensagem anterior ("Qual informação devo acrescentar?")
  if (c.pendente?.tipo === 'editar_item') {
    const p = c.pendente
    if (CANCELA_PENDENCIA.test(s) && s.split(' ').length <= 4) { await pendencia(convId, u, null); return R('Tudo bem, não alterei nada.') }
    await pendencia(convId, u, null)
    const r = await editar(u, convId, p.item, Number(p.id), text, p.falta)
    if (r) return r
  }
  if (c.pendente) return null // agendamento em partes, confirmação de cancelamento…: ficam com a memória da conversa (convctx)
  const alvo = pri.alvo
  // pedido de alteração curto sem nenhum registro nesta conversa ("adicione uma observação" logo depois de uma pesquisa):
  // pergunta qual registro, sem IA e sem transformar a frase numa pergunta sobre o assunto anterior
  const corrFin = (await import('./fin.js')).parseCorrection(text) // "corrija para 75": correção financeira — o finchat responde (inclusive "não encontrei")
  if (pri.prioridade === 'operacao' && !alvo && !Object.keys(c.ultimos || {}).length && s.split(' ').length <= 7 && !(corrFin && (/^(valor|categoria|descricao|observacao)$/.test(corrFin.campo || '') || /^(r\$\s*)?\d+([.,]\d+)?(\s*reais)?$/.test(corrFin.novo))) && /^(?:(?:por favor|pfv|agora|entao|e|so|apenas|tambem|pode)\s+)*(?:adicion|acrescent|inclu|coloqu|coloc|ponh|bot|mud|alter|troqu|troc|corrij|corrig|ajust|atualiz|modifi|edit|remarqu|remarc|cancel|desmarqu|desmarc|exclu|apag|remov|tir)\w*\b/.test(s)
    && !/\b(lista|compras|tarefas?|lembretes?|notas?|anotac\w*|contas?|reuniao|compromissos?|consulta|dentista|gastos?|despesas?|receitas?)\b/.test(s) && !/\b(amanha|hoje|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b.*\b(as \d|\d{1,2}\s*h)\b/.test(s))
    return R('Não encontrei nesta conversa um compromisso, lançamento, lembrete, tarefa ou anotação para alterar. Qual registro você quer mudar? (ex.: "a reunião de sexta com a Ana" ou "o gasto do mercado de hoje")')
  // pedido de ALTERAÇÃO que cita um registro existente pelo nome ("mude o lembrete da luz para 7h"), sem ser continuação da
  // última ação: edita o citado (um só) ou pergunta qual (vários). Compromissos e lançamentos seguem com os editores próprios.
  if (pri.prioridade === 'operacao' && !pri.detalhes && /^(?:(?:por favor|pfv|agora|entao|e|so|pode|eu|quero|queria|gostaria de|preciso)\s+)*(?:mud|alter|troc|remarc|adi[ae]|antecip|pass[ae]|corrij|ajust|atualiz)\w*\b/.test(s)) {
    const tipos = pri.dominio && TIPO_DE_DOM[pri.dominio] && ['reminder', 'task', 'bill'].includes(TIPO_DE_DOM[pri.dominio]) ? [TIPO_DE_DOM[pri.dominio]] : ['reminder', 'task', 'bill']
    const cit = await citados(u, text, { tipos, ativos: true })
    if (cit.length === 1) return editar(u, convId, cit[0].type, Number(cit[0].id), text)
    if (cit.length > 1) return R(`Encontrei ${cit.length} registros com esse nome:\n${cit.slice(0, 6).map((r: any, i: number) => { const d = J<any>(r.data, {}); return `${i + 1}. ${nomeDe(r.type, d)} — ${quandoBR(r.day, d.time || d.dueTime)}` }).join('\n')}\nQual deles devo alterar? (diga o nome completo ou o dia)`)
  }
  if (pri.prioridade !== 'continuacao_operacao' || !alvo) return null
  // exclusão do registro desta conversa ("apaga esse gasto", "exclua essa tarefa"): pede confirmação e só então apaga pela ação
  // oficial (compromissos e lembretes têm o próprio "cancelar", que guarda o histórico)
  if (PEDE_EXCLUIR.test(nrm(comandoDe(text))) && ['expense', 'task', 'bill', 'note'].includes(alvo.tipo) && !pri.canonico && s.split(' ').length <= 10) {
    const cit = (await citados(u, text, { tipos: [alvo.tipo] })).filter((r: any) => Number(r.id) !== alvo.id)
    return pedirExclusao(u, convId, alvo.tipo, cit.length === 1 ? Number(cit[0].id) : alvo.id)
  }
  // "é esse mesmo": confirma sem mexer em nada
  if (CONFIRMA_MESMO.test(s)) {
    const r: any = await one('SELECT id, type, status, day, data FROM items WHERE id = $1 AND user_id = $2', [alvo.id, u.id])
    if (!r) return null
    const d = J<any>(r.data, {}), nome = r.type === 'appointment' ? CX.resumoAppt(r, settingsOf(u).timezone) : `"${d.title || d.message || d.name || d.description || d.content || 'registro'}"`
    return R(`Certo, mantive ${nome} como está.`)
  }
  // lançamento: "adicione uma observação" / "acrescente essa informação" sem o texto → pergunta e completa na próxima mensagem
  if (alvo.tipo === 'expense' && VERBO_ADD.test(s) && QUER_INFO.test(s) && !conteudoApos(text)) { await pendencia(convId, u, { tipo: 'editar_item', item: 'expense', id: alvo.id, falta: /descricao/.test(s) ? 'descricao' : 'observacao' }); return R(/descricao/.test(s) ? PERG.descricao : PERG.observacao) }
  // HIERARQUIA — nível 1: complemento/correção sem verbo de edição já resolvido para UM registro desta conversa
  // (ai/prioridade.ts → lerComplemento). Aplica NESSE registro, pelos editores oficiais (mesmas validações e histórico),
  // mesmo que outra ação tenha vindo depois ("na verdade a reunião é às 16h" depois de um gasto).
  if (pri.canonico && alvo.tipo === 'appointment') {
    const E = await import('./agenda-edicao.js'), tz = settingsOf(u).timezone
    const lm = E.lerMudancas(text, (t: string) => CX.campos(t, tz).date)
    if (lm.falta || !Object.keys(lm.campos).length) return null
    const r = await E.aplicar(u, alvo.id, lm.campos, tz)
    if (r.ok) await CX.lembrarAcao(convId, u.id, 'appointment', alvo.id, 'atualizado pelo chat')
    return R(r.content)
  }
  if (pri.canonico && alvo.tipo === 'expense') {
    const info = conteudoApos(text)
    if (VERBO_ADD.test(s) && QUER_INFO.test(s) && info) return (await import('./finchat.js')).corrigirCampo(u, alvo.id, /descricao/.test(s) ? 'descricao' : 'observacao', info)
    return null // valor, forma de pagamento e data: o finchat corrige o último lançamento desta conversa
  }
  // outro registro citado pelo nome ("mude o lembrete do remédio para 8h" logo depois de criar uma tarefa): o citado vale, não o
  // último; mais de um com o mesmo nome → pergunta qual (nunca escolhe às cegas). Compromissos: convctx/agenda-edicao faz o mesmo.
  if (!pri.canonico) {
    const cit = await citados(u, text, { tipos: ['reminder', 'task', 'bill', 'appointment'], ativos: true })
    if (cit.length && !cit.some((r: any) => Number(r.id) === alvo.id)) {
      if (cit.length > 1) return R(`Encontrei ${cit.length} registros com esse nome:\n${cit.slice(0, 6).map((r: any, i: number) => { const d = J<any>(r.data, {}); return `${i + 1}. ${nomeDe(r.type, d)} — ${quandoBR(r.day, d.time || d.dueTime)}` }).join('\n')}\nQual deles devo alterar? (diga o nome completo ou o dia)`)
      if (cit[0].type === 'appointment') return null
      return editar(u, convId, cit[0].type, Number(cit[0].id), text)
    }
  }
  if (!['reminder', 'task', 'note', 'bill'].includes(alvo.tipo)) return null // compromissos e lançamentos: convctx/agenda-edicao e finchat
  return editar(u, convId, alvo.tipo, alvo.id, text)
}
void localDate
