// MOTOR DE PRIORIDADE DE INTENÇÕES — HIERARQUIA DE DECISÃO DO CHAT (prioridade inteligente, não uma fila de consultas):
//   NÍVEL 1 · CONTEXTO E CONTINUIDADE — antes de tratar a mensagem como intenção nova: resposta a uma pendência, continuação,
//             COMPLEMENTO ("ah, é com a Dra. Ana", "o endereço é…", "foi no cartão") ou CORREÇÃO ("na verdade é às 10h",
//             "na verdade foram 45") do registro desta conversa. O complemento vira o comando canônico que os editores
//             existentes já entendem (convctx/agenda-edicao, finchat, continuidade) — nenhuma regra de edição duplicada.
//   NÍVEL 2 · RECURSOS INTERNOS — execução (agendar, lançar, lembrar…), CONSULTA dos próprios dados (agenda, clientes,
//             contas, pedidos, plano) e SUGESTÃO sobre eles ("devo remarcar…?", "qual o melhor horário…?"). Consulta e
//             sugestão NUNCA executam: os motores de criação ficam de fora e a IA recebe só ferramentas de leitura.
//   NÍVEL 3 · CÉREBRO CENTRAL — pergunta geral e conversa: conhecimento, memória e regras primeiro.
//   NÍVEL 4 · PESQUISA EXTERNA — pedido explícito de pesquisa ou informação atual; também quando o Cérebro não souber.
// Níveis 1 e 2 BLOQUEIAM a pesquisa externa no turno. Uma mensagem com intenção própria (pergunta geral, pedido de
// pesquisa, lançamento novo) muda de assunto naturalmente: a continuidade só vale para o que tem forma de complemento.
// Ordem dos tipos (compatível com os consumidores existentes):
//   1. pesquisa_explicita     "pesquise na internet…", "procure na web…", "quais as últimas notícias de…"  (o usuário pediu)
//   2. operacao               criar/consultar/alterar/cancelar na agenda, finanças, lembretes, tarefas, notas, listas, contas, empresa
//   3. continuacao_operacao   frase curta que continua a última ação desta conversa ("mude para 15h", "pode cancelar",
//                             "adicione uma observação", "corrija o valor") — resolvida sobre o registro citado
//   4. pesquisa_atual         informação atual/externa de verdade (cotação de hoje, notícias, previsão do tempo, placar)
//   5. conhecimento           pergunta geral → Cérebro primeiro; pesquisa automática só se ele não souber
//   6. conversa
// Operação e continuação BLOQUEIAM a pesquisa no turno (ai/bloqueio-pesquisa.ts). O classificador de pesquisa nunca
// sobrepõe uma operação válida: palavras como "pesquisa", "preço", "notícia" DENTRO de um pedido operacional
// ("anota que a pesquisa de satisfação ficou para sexta", "registre o preço do corte: 50") não viram pesquisa.
// Só usa sinais que já existem (a memória da conversa em ai/convctx.ts e os leitores determinísticos de agenda/finanças);
// não chama IA, não acessa a rede e não grava nada.
import type { ConvCtx } from './convctx.js'
import { parseCorrection } from './fin.js'

export type Prioridade = 'operacao' | 'continuacao_operacao' | 'consulta_interna' | 'pesquisa_explicita' | 'pesquisa_atual' | 'conhecimento' | 'conversa'
export type Nivel = 1 | 2 | 3 | 4
export type Modo = 'pendencia' | 'continuacao' | 'complemento' | 'correcao' | 'execucao' | 'consulta' | 'sugestao' | 'conhecimento' | 'conversa' | 'pesquisa'
export type Dominio = 'agenda' | 'financeiro' | 'lembrete' | 'tarefa' | 'nota' | 'conta' | 'lista' | 'empresa' | null
export interface Decisao {
  prioridade: Prioridade
  dominio: Dominio
  pesquisa: 'bloqueada' | 'permitida' | 'explicita' | 'atual'
  /** pergunta sem o comando de pesquisa ("pesquise na internet o que é X" → "o que é X") */
  consulta: string
  /** registro desta conversa a que a continuação se refere */
  alvo?: { tipo: string; id: number } | null
  motivo: string
  /** hierarquia: 1 contexto · 2 recursos internos · 3 Cérebro Central · 4 pesquisa externa */
  nivel: Nivel
  modo: Modo
  /** complemento/correção traduzido para o comando que os editores existentes entendem ("altere para 10h") */
  canonico?: string
  /** consulta ou sugestão: nada é executado neste turno (só leitura) */
  somenteLeitura?: boolean
  /** ambiguidade real: pergunta só o que falta (sem IA, sem pesquisa) */
  esclarecer?: string
  /** "quais os detalhes desse compromisso?": mostra o registro (do contexto ou citado pelo nome), sem executar nada */
  detalhes?: boolean
}

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
const CORTESIA = String.raw`(?:(?:por favor|pfv|pf|agora|entao|e|ok|certo|beleza|tambem|so|apenas|pode|voce pode|vc pode|consegue|voce consegue|vc consegue|poderia|voce poderia|vc poderia|tem como|da pra|da para|me|ai|eu|quero|queria|gostaria de|preciso|vamos|vou)\s+)*`

/* ---------- pesquisa pedida pelo usuário ---------- */
const PESQ_VERBO = new RegExp(String.raw`^${CORTESIA}(?:faca|faz|fazer)?\s*(?:uma\s+)?(?:pesquis[ae]r?|pesquisa|procur[ae]r?|busqu?e|buscar|busca|googl[ae]|d[aei] uma (?:olhada|pesquisada|buscada|googlada))\b`)
const NA_WEB = /\b(na internet|na web|no google|online|na rede|em sites?|nas noticias|fontes? (atuais|externas))\b/
const INTERNO = /\b(minhas?|meus?|nossa|nosso)\s+(agenda|compromissos?|agendamentos?|gastos?|despesas?|receitas?|lancamentos?|lembretes?|tarefas?|notas?|anotacoes|contas?|clientes?|pedidos?|produtos?|servicos?|vendas?|financas|financeiro|estoque|lista)\b|\b(na agenda|no financeiro|nos meus|nas minhas|no sistema|no app|no aplicativo|nos registros|no historico|na conversa)\b/
const NOTICIAS = /^(?:quais (?:sao )?)?(?:as )?(?:ultimas )?noticias\b|\b(ultimas noticias|noticias (de hoje|sobre|da|do|de))\b/
const COMPARE_PRECOS = /^(?:compare|compara|comparar)\b.*\b(precos?|valores?|lojas?|sites?|modelos?|planos?)\b|\b(preco atual|precos atuais|preco de mercado|quanto (esta|ta) custando)\b/

/* ---------- informação atual/externa ---------- */
const TEMPO_REAL = /\b(cotacao|cambio|placar|resultado do jogo|previsao do tempo|clima (de|em|hoje|amanha|agora)|vai chover|temperatura (em|de|hoje|agora)|ultimas noticias|noticias de hoje|preco atual|precos atuais|dolar hoje|euro hoje|bitcoin|ibovespa|bolsa hoje|quem ganhou|quem venceu)\b/

/* ---------- operações internas ---------- */
const VERBO_OP = new RegExp(String.raw`^${CORTESIA}(?:agend|mar(?:c|qu)|remar(?:c|qu)|desmar(?:c|qu)|cancel|registr|lan[cç]|anot|lembr|cri[ae]|cadastr|adicion|acrescent|inclu|colo(?:c|qu)|ponh|bot[ae]|mud|alter|tro(?:c|qu)|corrij|corrig|ajust|atualiz|exclu|apag|remov|modifi|edit|tir[ae]|conclu|finaliz|defin|pass[ae]|adi[ae]|antecip|salv|guard|mostr|list)\w*\b`)
const OBJETO_OP = /\b(compromissos?|agendamentos?|reuniao|consulta|horario|agenda|evento|visita|sessao|tarefas?|lembretes?|notas?|anotac\w*|lista( de compras)?|compras|gastos?|despesas?|receitas?|lancamentos?|contas? (de|da|do|a pagar)|conta|boletos?|vencimento|valor|saldo|categoria|descricao|cliente|telefone|celular|observac\w*|obs|produtos?|servicos?|estoque|pedidos?|cobranca|pix|data|dia|prazo)\b/
const DADO_OP = /\b(\d{1,2}\s*h\b|\d{1,2}[:h]\d{2}|as \d{1,2}\b|amanha|hoje|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|dia \d{1,2}|r\$|\d+\s*(reais|real|conto))\b/
const MOVIMENTO = /^(?:(?:hoje|ontem|agora)\s+)?(?:eu\s+)?(gastei|paguei|comprei|recebi|vendi|transferi|ganhei|depositei)\b/
const CONSULTA_PESSOAL = /\b(quanto (eu )?(gastei|recebi|devo|tenho|ganhei|vendi)|qual (e )?(o )?meu saldo|meu saldo|meus gastos|minhas (despesas|receitas|contas|tarefas|notas|anotacoes)|meus (compromissos|lembretes|agendamentos)|o que (eu )?tenho (hoje|amanha|depois de amanha|na agenda|essa semana|esta semana|marcado)|tenho (algum )?(compromisso|reuniao|consulta)|minha agenda|contas a pagar|o que (vence|esta vencendo)|que horas (e|sera) (a|o) (reuniao|consulta|compromisso))\b/

/* ---------- continuação curta da última ação ---------- */
const VERBO_CONT = new RegExp(String.raw`^${CORTESIA}(?:adicion|acrescent|inclu|colo(?:c|qu)|ponh|bot[ae]|mud|alter|tro(?:c|qu)|corrij|corrig|ajust|atualiz|modifi|edit|remar(?:c|qu)|pass[ae]|adi[ae]|antecip|cancel|desmar(?:c|qu)|exclu|apag|remov|tir[ae]|defin|marqu?e? como|conclu)\w*\b`)
const CONFIRMA = /^(?:(?:sim|ok|certo|isso)\s+)?(?:(?:e|eh) )?(?:esse|essa|isso|este|esta) mesm[oa]$|^(?:isso mesmo|exatamente|pode ser|pode sim|sim|nao|confirmo|confirma|pode salvar|pode cancelar|cancela|deixa|esquece|nao quero)$/
const SO_DADO = /^(?:(?:para|pra|as|às|no|na|dia)\s+)?(?:\d{1,2}\s*(?:h|horas?)(?:\s*\d{2})?|\d{1,2}[:h]\d{2}|amanha|hoje|depois de amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|dia \d{1,2}(?:\/\d{1,2})?|(?:r\$\s*)?\d+(?:[.,]\d{1,2})?\s*(?:reais|real)?)$/
const PERGUNTA_GERAL = /^(o que (e|sao|significa|foi)|como (funciona|surgiu|se faz)|quem (e|foi|sao)|qual (e|foi) (a|o) (capital|origem|historia|significado)|por que|porque|pra que serve|para que serve|explique|defina|me (explica|explique|fala sobre|conte)|voce sabe)\b/

const TIPO_DOMINIO: Record<string, Dominio> = { appointment: 'agenda', expense: 'financeiro', reminder: 'lembrete', task: 'tarefa', note: 'nota', bill: 'conta', shopping: 'lista' }
function dominioDoTexto(s: string): Dominio {
  if (/\b(lembrete|lembr|me avis)/.test(s)) return 'lembrete'
  if (/\btarefas?\b/.test(s)) return 'tarefa'
  if (/\b(nota|anotac\w*|anot[ae]|anota)\b/.test(s)) return 'nota'
  if (/\b(lista de compras|na lista|lista do mercado)\b/.test(s)) return 'lista'
  if (/\b(contas? (de|da|do|a pagar)|boletos?|vencimento|venc\w+)\b/.test(s)) return 'conta'
  if (/\b(gast|despes|receit|lancament|saldo|categoria|pagu|receb|compre|financ|pix|cobranca)\w*/.test(s)) return 'financeiro'
  if (/\b(agend|compromisso|reuniao|consulta|horario|agenda|evento|visita|sessao|remarc|desmarc|marc)\w*/.test(s)) return 'agenda'
  if (/\b(produto|servico|estoque|loja|empresa|catalogo|pedido)s?\b/.test(s)) return 'empresa'
  return null
}
/** Pergunta sem o comando de pesquisa. */
export function consultaSemComando(texto: string): string {
  const t = String(texto || '').trim()
  const r = t.replace(/^(?:(?:por favor|pfv|agora|ent[aã]o|e|ok|voc[eê] pode|vc pode|pode|consegue|me)\s+)*(?:fa[cç]a|faz|fazer)?\s*(?:uma\s+)?(?:pesquis[ae]r?|pesquisa|procur[ae]r?|busqu?e|buscar|busca|googl[ae]|d[aêe] uma (?:olhada|pesquisada|buscada|googlada))\s*/i, '')
    .replace(/^(?:(?:na internet|na web|no google|online|na rede|em sites?|para mim|pra mim|r[aá]pido)\s*[,:]?\s*)+/i, '')
    .replace(/^(?:sobre|por|a respeito de|acerca de|informa[cç][õo]es sobre|o seguinte)\s*[:,]?\s*/i, '')
    .replace(/\s+(?:na internet|na web|no google|online)\s*([?.!]*)$/i, '$1').trim()
  return r.length >= 3 ? r : t
}

/* ================= NÍVEL 1: complemento e correção sem verbo de edição =================
   Forma de complemento: marcador ("na verdade", "esqueci de dizer que", "detalhe:", "obs:"), cópula + preposição ("é com…",
   "foi no cartão", "é no consultório"), "o endereço/local/telefone é…". O tipo do dado escolhe o registro (o mais recente
   desta conversa que aceita esse dado): horário/dia → compromisso, lembrete, tarefa, conta; valor → lançamento, compromisso,
   conta; forma de pagamento → lançamento; pessoa/telefone → compromisso; informação livre → o último registro. */
const COPULA = String.raw`(?:e|eh|foi|era|sera|vai ser|fica|ficou|seria)`
const MARCA_CORR = /^(?:na verdade|corrigindo|correcao|errei|me enganei|desculpa(?: errei)?|melhor|nao(?: (?:e|foi|era) (?:isso|esse|essa))?)\b\s*/
const MARCA_INFO = /^(?:alem disso|tambem|so mais uma coisa|so uma coisa|mais uma coisa|detalhe|obs|observacao|importante|lembrando que|lembra que|so pra constar|esqueci de (?:dizer|falar|avisar|mencionar|colocar|contar)(?: que)?|ia esquecendo(?: que)?)\b\s*/
const FILLER = /^(?:ah|a|ops|opa|alias|ah sim|e ah|ah e|ok|certo)\b\s*/
const HORA_RE = /\b(\d{1,2})\s*(?:h|hs|horas?)\s*(\d{2})?\b|\b(\d{1,2}):(\d{2})\b|\bas (\d{1,2})\b/
const DIA_RE = /\b(depois de amanha|amanha|hoje|segunda|terca|quarta|quinta|sexta|sabado|domingo|dia \d{1,2}(?:\/\d{1,2})?)\b/
const METODO_RE = /\b(cartao de credito|cartao de debito|credito|debito|cartao|pix|dinheiro|boleto|transferencia)\b/
const TEL_RE = /(\(?\d{2}\)?\s*9?\d{4}[-\s]?\d{4})/
const ACEITA: Record<string, string[]> = { tempo: ['appointment', 'reminder', 'task', 'bill', 'expense'], valor: ['expense', 'appointment', 'bill'], metodo: ['expense'], pessoa: ['appointment'], telefone: ['appointment'], info: ['appointment', 'expense', 'task', 'note'] }
/** Texto original sem os marcadores do começo (preserva maiúsculas e acentos para gravar). */
function semMarcas(orig: string): string {
  let t = String(orig || '').trim()
  for (let i = 0; i < 6; i++) {
    const a = t
    t = t.replace(/^(?:ah|ops|opa|ali[aá]s|ah sim|ok|certo)\b[,!.:]?\s*/i, '').replace(/^(?:na verdade|corrigindo|corre[cç][aã]o|errei|me enganei|desculpa|melhor)\b[,!.:]?\s*/i, '')
      .replace(/^(?:al[eé]m disso|tamb[eé]m|s[oó] mais uma coisa|s[oó] uma coisa|mais uma coisa|detalhe|obs|observa[cç][aã]o|importante|lembrando que|lembra que|s[oó] pra constar|esqueci de (?:dizer|falar|avisar|mencionar|colocar|contar)(?: que)?|ia esquecendo(?: que)?)\b[,!.:]?\s*/i, '')
      .replace(/^e\s+(?=(?:é|e|eh|foi|era|será|vai ser|fica|o |a |com |no |na ))/i, '')
    if (t === a) break
  }
  return t.trim()
}
const capt = (x: string) => x ? x.charAt(0).toUpperCase() + x.slice(1) : x
/** Complemento/correção do registro desta conversa → comando canônico para os editores existentes. null = não é complemento. */
export function lerComplemento(texto: string, acoes: { tipo: string; id: number; em: string }[]): { tipo: 'complemento' | 'correcao'; dado: string; alvo: { tipo: string; id: number } | null; canonico: string | null; semAlvo?: boolean; perguntar?: boolean } | null {
  const orig = String(texto || '').trim(), s0 = nrm(orig)
  if (!s0 || s0.split(' ').length > 24 || /\?\s*$/.test(orig)) return null
  if (/^(qual|quais|quem|quando|onde|quanto|quantos|quantas|como|por que|porque|o que)\b/.test(s0) || PERGUNTA_GERAL.test(s0) || TEMPO_REAL.test(s0) || PESQ_VERBO.test(s0)) return null
  if (MOVIMENTO.test(s0) && /\d/.test(s0)) return null // lançamento novo, não complemento
  // "não…" só é complemento na forma "não, é às 10h"; "não foi X, foi Y", "não, o certo é…", "não faça…" (correção de
  // resposta, orientação ao assistente, contraste financeiro) continuam com os fluxos que já tratam disso
  if (/^nao\b/.test(s0) && !/^nao\s+(?:e|eh|sera|vai ser)\s+(?:as|a|no|na|em|com|dia|amanha|hoje|\d)/.test(s0)) return null
  if (/\b(o certo|o correto|a resposta|voce (?:errou|disse)|vc (?:errou|disse)|prefiro|quero que voce|me responda|responda)\b/.test(s0)) return null
  let s = s0, corr = false, info = false
  for (let i = 0; i < 6; i++) { const a = s; s = s.replace(FILLER, ''); if (MARCA_CORR.test(s)) { s = s.replace(MARCA_CORR, ''); corr = true } if (MARCA_INFO.test(s)) { s = s.replace(MARCA_INFO, ''); info = true } s = s.replace(/^e (?=(?:e|eh|foi|era|sera|vai ser|fica|o|a)\b)/, ''); if (s === a) break }
  if (VERBO_OP.test(s) && !corr && !info) return null // verbo de ação: fica com o fluxo de operação/continuação
  const agradece = /\b(obrigad\w*|valeu|isso mesmo|so isso|tudo bem|tudo certo|perfeito|otimo|legal|show)\b/.test(s)
  const ehEra = /^(?:era|eram) (?:um |uma |o |a |pra |para |de |do |da )?[a-z]{3,}/.test(s) && !agradece
  const forma = corr || info || ehEra || new RegExp(String.raw`^${COPULA}\s+(?:com|no|na|nos|nas|em|pra|para|pelo|pela|via|online|presencial|um|uma|o|a|as|\d)`).test(s) || /^o (?:endereco|local|lugar|telefone|contato|email|e-mail|valor|preco|horario|nome do cliente|cliente)\s+(?:e|eh|sera|fica|foi|vai ser)\b/.test(s) || /^(?:paguei|pago|pagamento)\s+(?:no|na|com|via|em|pelo)\b/.test(s)
  if (!forma) return null
  const resto = s.replace(new RegExp(String.raw`^${COPULA}\s+`), '')
  // classifica o dado
  const hora = resto.match(HORA_RE), dia = resto.match(DIA_RE), ano = /\b(19|20)\d{2}\b/.test(resto)
  const valorM = resto.match(/(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(reais|real|conto|contos)?/)
  const soValor = !!valorM && (/^(?:foram|foi|sao|era|eram|e)?\s*(?:r\$\s*)?\d+(?:[.,]\d{1,2})?\s*(?:reais|real|conto|contos)?$/.test(resto) || /r\$|\breais\b|\breal\b/.test(resto) || /^o (?:valor|preco)\b/.test(s))
  const metodo = resto.match(METODO_RE), tel = orig.match(TEL_RE), pessoa = resto.match(/^com (?:o |a |os |as )?((?:dr|dra|doutor|doutora|sr|sra|prof|professor|professora)\.? )?[a-z]/)
  let tipoDado: keyof typeof ACEITA = 'info'
  if (metodo && /\b(no|na|com|via|em|pelo|pela|de)\s+(?:o |a )?(cartao|credito|debito|pix|dinheiro|boleto|transferencia)/.test(' ' + resto) && !hora) tipoDado = 'metodo'
  else if (soValor && !hora && !dia && !ano) tipoDado = 'valor'
  else if ((hora || dia) && !ano && resto.split(' ').length <= 8) tipoDado = 'tempo'
  else if (tel && /\d{8,}/.test(tel[1].replace(/\D/g, ''))) tipoDado = 'telefone'
  else if (pessoa && resto.split(' ').length <= 6) tipoDado = 'pessoa'
  if (tipoDado === 'info' && (ano || agradece || !(corr || info || ehEra || /^o (?:endereco|local|lugar|contato|email|e-mail|cliente|nome do cliente)\b/.test(s) || new RegExp(String.raw`^${COPULA}\s+(?:no|na|em|pra|para|online|presencial|um|uma)\b`).test(s)))) return null // sem dado operacional: não é complemento de registro
  // registro alvo: o mais recente desta conversa que aceita esse tipo de dado (dica de domínio na frase tem prioridade)
  const dica = dominioDoTexto(s), DOM: Record<string, string> = { agenda: 'appointment', financeiro: 'expense', lembrete: 'reminder', tarefa: 'task', nota: 'note', conta: 'bill' }
  const aceitos = ACEITA[tipoDado].filter((t) => (!dica || !DOM[dica] || DOM[dica] === t) && !(t === 'expense' && tipoDado === 'tempo' && hora)) // lançamento não tem horário
  // a última ação é um lançamento e o leitor de correções financeiras entende a frase ("na verdade foi com lazer",
  // "na verdade foi ontem"): fica com o finchat, que já corrige o último lançamento desta conversa
  const ultima = acoes[acoes.length - 1]
  if (ultima?.tipo === 'expense' && !(dica && dica !== 'financeiro') && !(tipoDado === 'tempo' && hora) && tipoDado !== 'telefone' && parseCorrection(orig)) return { tipo: corr ? 'correcao' : 'complemento', dado: tipoDado, alvo: { tipo: 'expense', id: Number(ultima.id) }, canonico: null }
  const alvoA = [...acoes].reverse().find((a) => aceitos.includes(a.tipo)) || null
  const alvo = alvoA ? { tipo: alvoA.tipo, id: Number(alvoA.id) } : null
  const tipo = corr ? 'correcao' as const : 'complemento' as const
  // sem registro que aceite o dado: só pergunta quando o dado é claramente de agenda (horário, telefone); o resto segue os fluxos atuais
  if (!alvo) return tipoDado === 'info' || ano ? null : { tipo, dado: tipoDado, alvo: null, canonico: null, semAlvo: true, perguntar: !acoes.length && ((tipoDado === 'tempo' && !!hora) || tipoDado === 'telefone') }
  // texto do dado para o comando canônico
  const infoTxt = (() => { let t = semMarcas(orig).replace(/^(?:é|e|eh|foi|era|será|vai ser|fica|ficou)\s+/i, ''); const m = t.match(/^o (endere[cç]o|local|lugar|contato|e-?mail)\s+(?:é|e|eh|será|fica|foi|vai ser)\s+(.+)$/i); if (m) t = `${capt(m[1])}: ${m[2]}`; return capt(t.replace(/[.!]+$/, '')) })()
  const quando = () => { const d = dia ? dia[1] : '', h = hora ? (hora[1] ? `${hora[1]}h${hora[2] || ''}` : hora[3] ? `${hora[3]}:${hora[4]}` : `${hora[5]}h`) : ''; return [d, h ? (d ? 'às ' : '') + h : ''].filter(Boolean).join(' ') }
  const num = valorM ? valorM[1] : ''
  const metodoTxt = metodo ? ({ 'cartao de credito': 'cartão de crédito', 'cartao de debito': 'cartão de débito', credito: 'cartão de crédito', debito: 'cartão de débito', cartao: 'cartão', pix: 'pix', dinheiro: 'dinheiro', boleto: 'boleto', transferencia: 'transferência' } as Record<string, string>)[metodo[1]] : ''
  const pessoaTxt = (() => { const m = semMarcas(orig).replace(/^(?:é|e|eh|foi|será|vai ser)\s+/i, '').match(/^com\s+(?:o |a |os |as )?(.+)$/i); return m ? m[1].replace(/[.!]+$/, '').replace(/\b(Dra|Dr|Sra|Sr|Prof|Profa)\.\s*/gi, '$1 ').trim() : '' })()
  let canonico: string | null = null
  switch (alvo.tipo) {
    case 'appointment':
      canonico = tipoDado === 'tempo' ? `altere para ${quando()}` : tipoDado === 'valor' ? `corrija o valor para ${num} reais` : tipoDado === 'pessoa' ? `troque o cliente para ${pessoaTxt}` : tipoDado === 'telefone' ? `coloque o telefone também: ${tel![1]}` : `adicione uma observação: ${infoTxt}`; break
    case 'expense':
      canonico = tipoDado === 'valor' ? `corrija o valor para ${num}` : tipoDado === 'metodo' ? `corrija a forma de pagamento para ${metodoTxt}` : tipoDado === 'tempo' && dia ? `corrija a data para ${dia[1]}` : `adicione a observação: ${infoTxt}`; break
    case 'reminder': canonico = tipoDado === 'tempo' ? `mude para ${quando()}` : null; break
    case 'task': canonico = tipoDado === 'tempo' ? `mude o prazo para ${quando()}` : `adicione a descrição: ${infoTxt}`; break
    case 'note': canonico = `acrescente: ${infoTxt}`; break
    case 'bill': canonico = tipoDado === 'valor' ? `corrija o valor para ${num}` : tipoDado === 'tempo' ? `mude o vencimento para ${dia ? dia[1] : quando()}` : null; break
  }
  return canonico ? { tipo, dado: tipoDado, alvo, canonico } : null
}

/* ---------- antecedência do aviso do registro desta conversa ("me lembre uma hora antes", "avise 30 minutos antes") ---------- */
const NUM_PALAVRA: Record<string, number> = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, dez: 10, quinze: 15, vinte: 20, trinta: 30, quarenta: 40 }
export function lerAntecedencia(texto: string): number | null {
  const s = nrm(texto)
  if (!/\b(lembr\w*|avis\w*|notifi\w*|alert\w*|lembrete|aviso)\b/.test(s) || /\blembr\w*\s+(?:de|que|da|do)\s/.test(s)) return null
  const fim = String.raw`\s+(?:de\s+)?antes(?:\s+(?:dele|dela|disso|do compromisso|da reuniao|da consulta|do evento|do horario))?\s*$`
  if (new RegExp(String.raw`\bmeia hora${fim}`).test(s)) return 30
  const m = s.match(new RegExp(String.raw`\b(\d{1,4}|${Object.keys(NUM_PALAVRA).join('|')})\s*(min\w*|h|hs|horas?|dias?)${fim}`))
  if (!m) return null
  const n = /^\d+$/.test(m[1]) ? Number(m[1]) : NUM_PALAVRA[m[1]], un = m[2]
  const min = /^d/.test(un) ? n * 1440 : /^h/.test(un) ? n * 60 : n
  return min > 0 && min <= 10080 ? min : null
}
/* ---------- detalhes de um registro ("quais os detalhes desse compromisso?", "como ficou a reunião?") ---------- */
const DETALHES = /^(?:(?:e|entao|agora|me|por favor)\s+)*(?:quais (?:sao )?(?:os )?detalhes|(?:me )?(?:mostr\w*|exib\w*|diga|diz|fala|ver|veja|passa|passe)\s+(?:os |as )?(?:detalhes|informac\w+|dados)|(?:os )?detalhes|como (?:ficou|esta|e que ficou)|o que (?:tem|consta|ficou) n[oa])\b/
const DEMONSTR = /\b(desse|dessa|deste|desta|esse|essa|este|esta|dele|dela|isso)\b/
const NOME_REGISTRO = /\b(compromissos?|agendamentos?|reuniao|consulta|evento|visita|sessao|lembretes?|tarefas?|contas?|gastos?|despesas?|lancamentos?|anotac\w*|notas?)\b/

/* ================= NÍVEL 2: sugestão e consulta sobre os próprios dados (nada é executado) ================= */
const SUGESTAO = /^(?:(?:e |entao |hmm )?(?:voce|vc) (?:acha|recomenda|sugere|aconselha) (?:que )?|acha que |sera que |(?:eu )?(?:devo|deveria|preciso mesmo)\b|vale a pena\b|compensa\b|(?:e|seria) (?:melhor|bom|uma boa)\b|me (?:sugere|sugira|recomenda|recomende|aconselha|aconselhe|indica|indique|ajuda a (?:escolher|decidir))\b|(?:o que|qual) (?:voce |vc )?(?:sugere|recomenda|aconselha)\b|qual (?:e |seria )?(?:o |a )?melhor (?:horario|dia|data|hora|momento|forma|opcao|categoria|maneira|jeito|semana)\b|quando (?:e|seria) melhor\b|como (?:eu )?(?:posso|poderia) (?:economizar|organizar|reduzir|melhorar))/
const DISPONIVEL = /^(?:(?:eu )?posso (?:marcar|agendar|encaixar|colocar)|(?:eu )?consigo (?:encaixar|marcar algo)|da (?:pra|para) eu (?:encaixar|marcar)|(?:eu )?tenho (?:tempo|horario|vaga|espaco|algum horario)(?: livre)?|(?:eu )?(?:estou|to|fico|estarei) livre|tem (?:algum )?horario livre|(?:quais|qual) (?:os |o )?horarios? livres?|tenho algo marcado)\b/
const ENTIDADE_INTERNA = /\b(clientes?|do cliente|da cliente|meu plano|minha assinatura|meus modulos|modulos ativos|minhas configurac\w*|configurac\w* d[oa] (?:app|sistema|conta)|minha conta|minha loja|minha empresa|meus pedidos|pedidos (?:da|de|na) (?:minha )?loja|minha loja teve|estoque|meus produtos|meus servicos|meu catalogo|faturamento|minhas vendas|vendi|conta de (?:luz|agua|internet|telefone|gas|aluguel|condominio)|boletos?|fatura do cartao|vencimentos?|vence|minhas metas|meu orcamento|minha agenda|meus compromissos|meus lembretes|minhas tarefas|minhas notas|meu saldo|meus gastos|minhas despesas|meus agendamentos|reuniao|dentista|compromisso|agendamento|lembrete|tarefa)\b/
const PERGUNTA_INTERNA = /^(?:e )?(?:qual|quais|quando|quanto|quantos|quantas|onde|como (?:esta|estao|anda|andam)|tem|existe|ha|me (?:mostra|mostre|diga|diz|fala)|mostre|liste)\b/

export function decidir(texto: string, c: ConvCtx = {}, o: { agora?: number; janelaMin?: number } = {}): Decisao {
  const s = nrm(texto), palavras = s ? s.split(' ').length : 0, agora = o.agora ?? Date.now()
  const sCmd = String(texto || '').includes(':') ? nrm(String(texto).split(':')[0]) : s // "adicione uma observação: conta da praia" → o domínio vem de "adicione uma observação"

  const ult = [...(c.acoes || [])].reverse().find((a) => a && a.id && agora - new Date(a.em).getTime() < (o.janelaMin ?? 120) * 60_000) || null
  const alvo = ult ? { tipo: ult.tipo, id: Number(ult.id) } : null
  const base0 = (p: Prioridade, d: Dominio, motivo: string, extra: Partial<Decisao> = {}): any => ({ prioridade: p, dominio: d, pesquisa: p === 'operacao' || p === 'continuacao_operacao' || p === 'consulta_interna' ? 'bloqueada' : p === 'pesquisa_explicita' ? 'explicita' : p === 'pesquisa_atual' ? 'atual' : 'permitida', consulta: String(texto || '').trim(), alvo: null, motivo, ...extra })
  const NIVEL_DE: Record<Prioridade, Nivel> = { continuacao_operacao: 1, operacao: 2, consulta_interna: 2, conhecimento: 3, conversa: 3, pesquisa_explicita: 4, pesquisa_atual: 4 }
  const MODO_DE: Record<Prioridade, Modo> = { continuacao_operacao: 'continuacao', operacao: 'execucao', consulta_interna: 'consulta', conhecimento: 'conhecimento', conversa: 'conversa', pesquisa_explicita: 'pesquisa', pesquisa_atual: 'pesquisa' }
  const base = (p: Prioridade, d: Dominio, motivo: string, extra: Partial<Decisao> = {}): Decisao => ({ ...base0(p, d, motivo, extra), nivel: extra.nivel ?? NIVEL_DE[p], modo: extra.modo ?? MODO_DE[p] })
  if (!s) return base('conversa', null, 'mensagem vazia')

  // 1) pesquisa pedida explicitamente (verbo de pesquisa no começo) — sobre dados internos ("pesquise na minha agenda") é operação
  // o QUE pesquisar é o que vem logo depois do verbo: "pesquise na minha agenda…" é busca interna; "pesquise o preço de X e
  // compare com os meus gastos" é pedido misto (pesquisa externa + dados próprios) — fica com o orquestrador, sem forçar nada
  const resto = s.replace(PESQ_VERBO, '').trim(), inicio = resto.split(' ').slice(0, 6).join(' ')
  const OBJ_INT = /\b(compromissos?|agendamentos?|tarefas?|lembretes?|notas?|anotac\w*|gastos?|despesas?|lancamentos?|clientes?|pedidos?)\b/
  const objInterno = PESQ_VERBO.test(s) && (INTERNO.test(inicio) || OBJ_INT.test(inicio))
  if (PESQ_VERBO.test(s) && !objInterno && (INTERNO.test(s) || OBJ_INT.test(resto))) return base('conhecimento', null, 'pedido misto: pesquisa externa + dados próprios (o orquestrador decide)')
  const pedePesquisa = (PESQ_VERBO.test(s) || NOTICIAS.test(s) || COMPARE_PRECOS.test(s)) && !INTERNO.test(s)
  if (pedePesquisa && !(PESQ_VERBO.test(s) && !NA_WEB.test(s) && (VERBO_OP.test(resto) || objInterno))) {
    const consulta = PESQ_VERBO.test(s) ? consultaSemComando(texto) : String(texto).trim()
    return base('pesquisa_explicita', null, 'o usuário pediu pesquisa', { consulta, pesquisa: TEMPO_REAL.test(nrm(consulta)) || NOTICIAS.test(s) || COMPARE_PRECOS.test(s) ? 'atual' : 'explicita' })
  }

  if (objInterno && !NA_WEB.test(s)) return base('operacao', dominioDoTexto(s), 'busca nos próprios registros (não é pesquisa na internet)', { modo: 'consulta' })

  // 1b) DETALHES de um registro (desta conversa ou citado pelo nome): lê o banco e mostra; nada é executado, nada vai à internet
  if (DETALHES.test(s) && !TEMPO_REAL.test(s) && !NA_WEB.test(s) && (DEMONSTR.test(s) || NOME_REGISTRO.test(s) || (alvo && palavras <= 8)))
    return base('operacao', dominioDoTexto(s) || (alvo ? TIPO_DOMINIO[alvo.tipo] : null), 'detalhes de um registro (só leitura)', { alvo, modo: 'consulta', nivel: 2, somenteLeitura: true, detalhes: true })
  // 1c) "me lembre uma hora antes" logo depois de um compromisso desta conversa: antecedência do aviso DELE (não é lembrete novo)
  { const min = lerAntecedencia(texto), ap = [...(c.acoes || [])].reverse().find((a) => a && a.id && a.tipo === 'appointment' && agora - new Date(a.em).getTime() < (o.janelaMin ?? 120) * 60_000)
    if (min && ap) return base('continuacao_operacao', 'agenda', `antecedência do aviso do compromisso desta conversa (${min} min)`, { alvo: { tipo: 'appointment', id: Number(ap.id) }, canonico: `altere o lembrete para ${min} minutos antes`, modo: 'complemento' }) }

  // 2) pendência aberta nesta conversa (agendamento em partes, confirmação de cancelamento, campo que faltou)
  const pend = c.pendente
  if (pend && (CONFIRMA.test(s) || SO_DADO.test(s) || (VERBO_CONT.test(s) && !PERGUNTA_GERAL.test(s)) || (palavras <= 8 && !PERGUNTA_GERAL.test(s) && !TEMPO_REAL.test(s)))) {
    const tp = pend.tipo === 'agendamento' || pend.tipo === 'cancelar' || pend.tipo === 'editar_appt' ? 'agenda' : (TIPO_DOMINIO[String(pend.tipo || '').replace(/^editar_/, '')] || null)
    return base('continuacao_operacao', tp, `responde à pendência "${pend.tipo}" desta conversa`, { alvo: pend.id ? { tipo: 'appointment', id: Number(pend.id) } : alvo, modo: 'pendencia' })
  }

  // 2b) NÍVEL 1 — complemento/correção do registro desta conversa, sem verbo de edição
  const acoesJanela = (c.acoes || []).filter((a) => a && a.id && agora - new Date(a.em).getTime() < (o.janelaMin ?? 120) * 60_000)
  const cp = lerComplemento(texto, acoesJanela)
  if (cp?.alvo && !cp.canonico) return base('continuacao_operacao', TIPO_DOMINIO[cp.alvo.tipo] || null, `${cp.tipo} (${cp.dado}) do lançamento desta conversa (o leitor de correções financeiras aplica)`, { alvo: cp.alvo, modo: cp.tipo })
  if (cp?.alvo && cp.canonico) return base('continuacao_operacao', TIPO_DOMINIO[cp.alvo.tipo] || null, `${cp.tipo} (${cp.dado}) do registro desta conversa (${cp.alvo.tipo} ${cp.alvo.id}) → "${cp.canonico}"`, { alvo: cp.alvo, modo: cp.tipo, canonico: cp.canonico })
  // complemento com dado operacional mas sem registro desta conversa: continua sendo operacional (nunca vira pesquisa);
  // pergunta a qual registro só quando o dado é claramente de agenda (horário, telefone) e não houve nenhuma ação
  if (cp?.semAlvo && !cp.perguntar) return base('operacao', null, `${cp.tipo} (${cp.dado}) sem registro desta conversa (os motores atuais decidem; sem pesquisa)`, { modo: cp.tipo, nivel: 1 })
  if (cp?.semAlvo) return base('operacao', null, `${cp.tipo} (${cp.dado}) sem registro desta conversa a que se referir`, { modo: cp.tipo, nivel: 1, esclarecer: 'Não encontrei nesta conversa um compromisso, lançamento ou lembrete recente para ajustar. A qual registro essa informação se refere? (ex.: "a consulta de amanhã com o dentista")' })

  // 3) operação interna explícita
  if (MOVIMENTO.test(s) && /\d/.test(s)) return base('operacao', 'financeiro', 'registro financeiro (gastei/paguei/recebi + valor)')
  if (CONSULTA_PESSOAL.test(s) && !SUGESTAO.test(s)) return base('operacao', dominioDoTexto(s) || 'agenda', 'consulta dos próprios dados', { modo: 'consulta' })
  if (VERBO_OP.test(s) && (OBJETO_OP.test(s) || DADO_OP.test(s) || /\bque\b/.test(s))) {
    // verbo de edição curto sem objeto novo, logo depois de uma ação desta conversa = continuação dessa ação
    const d = dominioDoTexto(sCmd)
    if (alvo && VERBO_CONT.test(s) && palavras <= 14 && (!d || d === TIPO_DOMINIO[alvo.tipo] || /\b(o|a|esse|essa|desse|dessa|deste|desta)\s+(valor|horario|data|dia|cliente|telefone|observac\w*|descricao|categoria|vencimento|prazo|titulo|nome)\b/.test(s)) && !/\b(novo|nova|outro|outra|mais um|mais uma)\s+(compromisso|agendamento|lembrete|tarefa|nota|gasto|despesa|conta)\b/.test(s))
      return base('continuacao_operacao', TIPO_DOMINIO[alvo.tipo] || d, `continua a última ação desta conversa (${alvo.tipo} ${alvo.id})`, { alvo })
    return base('operacao', d || (alvo ? TIPO_DOMINIO[alvo.tipo] : null), 'pedido operacional (verbo de ação + objeto/dado)')
  }

  // 4) continuação curta sem objeto explícito ("pode cancelar", "é esse mesmo", "só altere o horário", "15h")
  if (alvo && palavras <= 14 && !PERGUNTA_GERAL.test(s) && (VERBO_CONT.test(s) || CONFIRMA.test(s) || SO_DADO.test(s) || /^(e|tambem|alem disso)\s+(o|a)\s+(telefone|valor|horario|cliente|observac\w*|descricao)\b/.test(s)))
    return base('continuacao_operacao', TIPO_DOMINIO[alvo.tipo] || null, `continua a última ação desta conversa (${alvo.tipo} ${alvo.id})`, { alvo })

  // 4b) verbo de edição curto sem registro desta conversa ("acrescente essa informação", "pode cancelar") continua sendo
  // um pedido operacional — nunca vira pergunta de conhecimento sobre o assunto anterior (o sistema pergunta qual registro)
  if (VERBO_CONT.test(s) && palavras <= 10 && !PERGUNTA_GERAL.test(s) && !/\?$/.test(String(texto).trim())) return base('operacao', dominioDoTexto(s), 'pedido de alteração sem registro citado nesta conversa')
  // confirmação curta ("é esse mesmo", "isso mesmo") não é pergunta: nada a pesquisar
  if (CONFIRMA.test(s)) return base('conversa', null, 'confirmação curta', { pesquisa: 'bloqueada' })

  // 4c) NÍVEL 2 — sugestão e consulta sobre os PRÓPRIOS dados: dados reais do sistema, sem executar e sem internet
  const refInterna = ENTIDADE_INTERNA.test(s) || INTERNO.test(s) || !!dominioDoTexto(s) || (DADO_OP.test(s) && /\b(marcar|agendar|remarcar|encaixar|pagar|lancar|cancelar)\b/.test(s))
  if (SUGESTAO.test(s) && refInterna && !NA_WEB.test(s)) return base('consulta_interna', dominioDoTexto(s), 'sugestão sobre os próprios dados (nada é executado)', { modo: 'sugestao', somenteLeitura: true })
  if (DISPONIVEL.test(s)) return base('consulta_interna', 'agenda', 'consulta de disponibilidade na agenda (nada é criado)', { modo: 'consulta', somenteLeitura: true })
  if (PERGUNTA_INTERNA.test(s) && ENTIDADE_INTERNA.test(s) && !TEMPO_REAL.test(s) && !NA_WEB.test(s)) return base('consulta_interna', dominioDoTexto(s), 'consulta dos próprios dados (clientes, contas, pedidos, plano…)', { modo: 'consulta', somenteLeitura: true })

  // 5) informação atual/externa (não pessoal)
  if (TEMPO_REAL.test(s) && !INTERNO.test(s)) return base('pesquisa_atual', null, 'informação atual/externa')

  // 6) conhecimento × conversa
  if (/\?$/.test(String(texto).trim()) || PERGUNTA_GERAL.test(s) || /^(qual|quais|quem|quando|onde|quanto|quantos|quantas|como)\b/.test(s)) return base('conhecimento', null, 'pergunta (Cérebro primeiro; pesquisa só se ele não souber)')
  return base('conversa', null, 'sem operação nem pedido de pesquisa')
}
