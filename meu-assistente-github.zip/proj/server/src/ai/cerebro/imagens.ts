// Cérebro Central — PESQUISA DE IMAGENS integrada à pesquisa do chat (não é um buscador à parte: usa os MESMOS provedores
// ativos do painel, os mesmos bloqueios de domínio, a mesma rede segura e o mesmo cache do Cérebro).
//
// 1. Decide SE vale mostrar imagens (avaliar): pessoas, lugares, monumentos, animais, plantas, objetos, veículos, obras,
//    "mostre imagens/fotos de…", "como é um…". Contas, conversa, comentários, pedidos operacionais e conceitos abstratos
//    ("o que é inflação") NÃO pesquisam imagens.
// 2. Pesquisa (buscar), na ordem: Wikipédia/Wikimedia (imagem principal do artigo + imagens do próprio artigo, com autor e
//    licença do Commons), SearXNG categoria "images" (se configurado) e Brave Images (se ativo e só quando os gratuitos não
//    trouxerem nada). Relevância: o artigo precisa tratar da entidade; resultados web precisam citar os NOMES e o núcleo
//    do assunto no título/página — palavra parecida sozinha não basta. Sem SVG, sem miniatura minúscula, sem domínio bloqueado.
// 3. Verifica DE VERDADE que cada imagem abre (tipo e assinatura binária) antes de mostrar; a que falha fica de fora.
// 4. Marcador ⟦img:…⟧ na resposta: o app mostra a imagem principal, uma galeria pequena, a origem e a atribuição.
//    As imagens passam SEMPRE pelo proxy do servidor (/api/v2/imagens/ver), que só busca endereços assinados por este
//    servidor (não é um proxy aberto), revalida cada salto contra SSRF, limita tamanho, tempo e formato e não repassa
//    cookies nem o IP do usuário aos sites (menos rastreamento).
// Nunca afirma que uma imagem é livre de direitos: mostra a licença/autor SOMENTE quando a fonte informa.
import { createHmac, timingSafeEqual, randomBytes } from 'node:crypto'
import * as W from './web.js'
import * as REL from './relevancia.js'
import { termos } from '../semantica.js'
import { sha } from './texto.js'
import { getConfig, setConfig } from '../../lib/settings.js'

export interface Imagem {
  url: string; thumb?: string; pagina: string; site: string; titulo: string; largura?: number; altura?: number; formato?: string
  autor?: string; licenca?: string; licencaUrl?: string; motor: string; principal?: boolean
}
export interface Decisao { visual: boolean; motivo: string; entidade: string; tipo: string }
export interface ResultadoImagens { imagens: Imagem[]; tentativas: { motor: string; status: string; n?: number; ms?: number; motivo?: string }[]; cache: boolean; ms: number }

/* ---------- 1. quando vale mostrar imagens ---------- */
const PEDE_IMAGEM = /\b(mostr\w*|ver|veja|quero ver|tem|manda|envie|busque|procure|pesquise)\b[^?]*\b(imagens?|fotos?|fotografias?|figuras?|ilustra[cç][aã]o|ilustra[cç][oõ]es)\b|^\s*(imagens?|fotos?)\s+d[aeo]s?\b/i
const VISUAL = /\b(animal|animais|bicho|ave|p[aá]ssaro|peixe|inseto|r[eé]ptil|mam[ií]fero|cachorro|c[aã]o|gato|cavalo|le[aã]o|tigre|on[cç]a|lobo|lobo-guar[aá]|raposa|urso|baleia|golfinho|tubar[aã]o|elefante|girafa|macaco|tucano|arara|papagaio|coruja|[aá]guia|cobra|jacar[eé]|tartaruga|borboleta|abelha|planta|flor|flores|[aá]rvore|orqu[ií]dea|cacto|ip[eê]|fruta|cidade|pa[ií]s|praia|ilha|montanha|vulc[aã]o|cachoeira|lago|rio|deserto|floresta|monumento|torre|ponte|castelo|pal[aá]cio|catedral|igreja|templo|pir[aâ]mide|est[aá]tua|museu|est[aá]dio|pr[eé]dio|arranha-c[eé]u|arquitetura|carro|carros|moto|motos|avi[aã]o|navio|trem|foguete|caminh[aã]o|ve[ií]culo|modelos?|ra[cç]as?|esp[eé]cies?|pintura|quadro|obra de arte|escultura|planeta|planetas|sistema solar|gal[aá]xia|estrela|lua|nebulosa|cometa|mineral|pedra|cristal|instrumento|guitarra|viol[aã]o|piano|roupa|vestido|traje|uniforme|bandeira|prato t[ií]pico|comida t[ií]pica)\b/i
const ABSTRATO = /\b(como (funciona|fazer|se faz|calcular|resolver|declarar|pagar|usar|configurar|instalar)|por que|porque|diferen[cç]a entre|significado|significa|defini[cç][aã]o|conceito|f[oó]rmula|lei|imposto|infla[cç][aã]o|juros|economia|pol[ií]tica|direito|regra|receita de|passo a passo|quanto custa|pre[cç]o|cota[cç][aã]o|not[ií]cia|resultado|placar|hor[aá]rio|tradu[cç][aã]o|traduz)\b/i
const QUEM = /^\s*(e\s+)?quem\s+(foi|é|e|era|s[aã]o|eram)\s+/i
const COMO_E = /^\s*(e\s+)?como\s+(é|e|era|s[aã]o|eram|fica)\s+(o|a|os|as|um|uma)?\s*/i
const PREFIXO = /^\s*(e\s+)?(quem\s+(foi|é|e|era|s[aã]o|eram)|como\s+(é|e|era|s[aã]o|eram|fica)|o\s+que\s+(é|e|foi|s[aã]o|eram?)|onde\s+(fica|ficam|est[aá]|é)|qual\s+(é|e|foi)|quais\s+(s[aã]o|foram)|(me\s+)?mostr\w*(\s+(umas?|algumas?))?(\s+(imagens?|fotos?|fotografias?|figuras?))?|(imagens?|fotos?)|fale\s+(sobre|de|do|da)|conte\s+sobre)\s+(d[aeo]s?\s+|sobre\s+)?/i
const ARTIGO = /^(o|a|os|as|um|uma|uns|umas)\s+/i
/** Assunto/entidade visual da pergunta ("Quem foi Tim Maia?" → "Tim Maia"; "Quais são os modelos de Ferrari?" → "modelos de Ferrari"). */
const CORTESIA = /^\s*(voc[eê]\s+)?(consegue|pode|poderia|daria|d[aá]\s+pra|d[aá]\s+para|tem\s+como|seria\s+poss[ií]vel)\s+(me\s+)?/i
export function entidade(pergunta: string): string {
  let s = String(pergunta || '').trim().replace(/[?!.…]+$/, '').replace(CORTESIA, '').replace(PREFIXO, '').replace(ARTIGO, '').trim()
  s = s.replace(/\s+(hoje|atualmente|agora|por favor|pra mim|para mim)$/i, '').trim()
  return s.slice(0, 80)
}
export function avaliar(pergunta: string, o: { escopo?: string; assunto?: string; decisao?: string } = {}): Decisao {
  const t = String(pergunta || '').trim(), ent = (entidade(t) || String(o.assunto || '')).trim()
  const nao = (motivo: string): Decisao => ({ visual: false, motivo, entidade: ent, tipo: '' })
  if (!t || t.length < 6) return nao('mensagem curta')
  if (o.escopo && ['operacional', 'comentario', 'continuacao'].includes(o.escopo) && !PEDE_IMAGEM.test(t)) return nao('pedido operacional, comentário ou continuação')
  if (o.decisao === 'perguntar') return nao('nome com mais de um sentido: antes é preciso saber qual')
  if (/\d\s*[-+*/x×÷^]\s*\d|\b(quant[oa]s?|calcule|converta)\b/i.test(t) && !PEDE_IMAGEM.test(t)) return nao('pergunta numérica')
  if (!ent || termos(ent).length === 0) return nao('sem assunto identificável')
  if (/^(fotos?|imagens?|figuras?|fotografias?|ilustra[cç](ão|ões|ao|oes))$/i.test(ent)) return nao('pediu imagem sem dizer de quê: a resposta pergunta o assunto')
  if (PEDE_IMAGEM.test(t)) return { visual: true, motivo: 'o usuário pediu imagens', entidade: ent, tipo: 'pedido' }
  if (ABSTRATO.test(t)) return nao('assunto abstrato ou informação textual')
  const temNome = REL.nomes(t).length > 0
  if (QUEM.test(t) && temNome) return { visual: true, motivo: 'pessoa ou personagem identificado pelo nome', entidade: ent, tipo: 'pessoa' }
  if (COMO_E.test(t) && (temNome || VISUAL.test(t))) return { visual: true, motivo: 'pergunta sobre a aparência', entidade: ent, tipo: 'aparencia' }
  if (VISUAL.test(t) && (temNome || /^\s*(e\s+)?(o que|qual|quais|onde)\b/i.test(t))) return { visual: true, motivo: 'assunto visual (lugar, animal, objeto, obra…)', entidade: ent, tipo: 'visual' }
  if (temNome && /^\s*(e\s+)?(o que (é|e|foi)|onde fica|onde est[aá]|fale sobre|conte sobre)\b/i.test(t)) return { visual: true, motivo: 'lugar, obra ou entidade com nome próprio', entidade: ent, tipo: 'nome' }
  return nao('a imagem não acrescenta à resposta')
}

/* ---------- assinatura dos endereços (o proxy só abre o que este servidor assinou) ---------- */
let chaveP: Promise<string> | null = null
function chave(): Promise<string> { // uma única leitura/criação, mesmo com várias assinaturas simultâneas
  if (!chaveP) chaveP = (async () => {
    const env = process.env.SETTINGS_KEY || process.env.SESSION_SECRET
    if (env) return 'img:' + env
    let k = await getConfig<string>('imagens_chave', '')
    if (!k) { k = randomBytes(24).toString('hex'); await setConfig('imagens_chave', k) } // persistente: o histórico continua abrindo as imagens
    return k
  })().catch((e) => { chaveP = null; throw e })
  return chaveP
}
export async function assinar(url: string) { return createHmac('sha256', await chave()).update('img|' + url).digest('hex').slice(0, 32) }
export async function assinaturaValida(url: string, s: string) {
  const a = Buffer.from(await assinar(url)), b = Buffer.from(String(s || ''))
  return a.length === b.length && timingSafeEqual(a, b)
}
export async function caminhoProxy(url: string) { return `/api/v2/imagens/ver?u=${encodeURIComponent(url)}&s=${await assinar(url)}` }

/* ---------- download seguro de imagem (proxy + verificação) ---------- */
const TIPOS = /^image\/(jpeg|jpg|pjpeg|png|webp|gif|avif)$/
/** Confere a assinatura binária: o conteúdo precisa SER a imagem que o cabeçalho diz (nada de HTML/script disfarçado). */
export function tipoReal(b: Buffer): string | null {
  if (b.length < 12) return null
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg'
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png'
  if (b.subarray(0, 4).toString('latin1') === 'GIF8') return 'image/gif'
  if (b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp'
  if (b.subarray(4, 8).toString('latin1') === 'ftyp' && /avif|avis/.test(b.subarray(8, 12).toString('latin1'))) return 'image/avif'
  return null
}
// cache EM MEMÓRIA, pequeno (as imagens não vão para o banco): até ~40 MB, 30 min, o mais antigo sai primeiro
const MEM = new Map<string, { tipo: string; dados: Buffer; em: number }>(); let memBytes = 0
const MEM_MAX = 40 * 1024 * 1024, MEM_TTL = 30 * 60_000
function memPut(url: string, v: { tipo: string; dados: Buffer }) {
  if (v.dados.length > 8 * 1024 * 1024) return
  const old = MEM.get(url); if (old) { memBytes -= old.dados.length; MEM.delete(url) }
  MEM.set(url, { ...v, em: Date.now() }); memBytes += v.dados.length
  for (const [k, x] of MEM) { if (memBytes <= MEM_MAX) break; MEM.delete(k); memBytes -= x.dados.length }
}
export function memGet(url: string) { const v = MEM.get(url); if (!v) return null; if (Date.now() - v.em > MEM_TTL) { MEM.delete(url); memBytes -= v.dados.length; return null } return v }
export const memStats = () => ({ itens: MEM.size, bytes: memBytes })
const emVoo = new Map<string, Promise<{ tipo: string; dados: Buffer }>>()
/** Baixa UMA imagem com as proteções do Cérebro: http/https, sem IP interno (cada redirecionamento revalidado), sem cookies,
 *  tempo limite, tamanho máximo, formato da lista e assinatura binária conferida. Downloads iguais simultâneos são um só. */
export function baixarImagem(url: string, o: { timeoutMs?: number; maxBytes?: number } = {}): Promise<{ tipo: string; dados: Buffer }> {
  const m = memGet(url); if (m) return Promise.resolve(m)
  const ja = emVoo.get(url); if (ja) return ja
  const p = (async () => {
    let atual = url
    for (let salto = 0; salto < 4; salto++) {
      const u = await W.validarUrl(atual), ac = new AbortController(), t = setTimeout(() => ac.abort(), o.timeoutMs || 8000)
      try {
        const r = await fetch(u, { redirect: 'manual', signal: ac.signal, credentials: 'omit', headers: { 'User-Agent': W.UA, Accept: 'image/avif,image/webp,image/png,image/jpeg,image/gif;q=0.9', Referer: '' } })
        if (r.status >= 300 && r.status < 400 && r.headers.get('location')) { atual = new URL(r.headers.get('location')!, u).href; continue }
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        const cab = (r.headers.get('content-type') || '').split(';')[0].trim().toLowerCase()
        if (!TIPOS.test(cab)) throw new Error(`formato não aceito (${cab || 'desconhecido'})`)
        const max = o.maxBytes || 6 * 1024 * 1024, tam = Number(r.headers.get('content-length') || 0); if (tam > max) throw new Error('imagem grande demais')
        const reader = r.body?.getReader(); let total = 0; const partes: Uint8Array[] = []
        if (reader) for (;;) { const { done, value } = await reader.read(); if (done) break; total += value.length; if (total > max) { ac.abort(); throw new Error('imagem grande demais') } partes.push(value) }
        const dados = Buffer.concat(partes), real = tipoReal(dados)
        if (!real) throw new Error('o conteúdo não é uma imagem válida')
        const v = { tipo: real, dados }; memPut(url, v); return v
      } catch (e: any) { throw new Error(e?.name === 'AbortError' ? 'tempo esgotado' : e?.message || String(e)) } finally { clearTimeout(t) }
    }
    throw new Error('redirecionamentos demais')
  })().finally(() => emVoo.delete(url))
  emVoo.set(url, p); return p
}

/* ---------- 2. provedores ---------- */
const limpa = (h: any) => String(h ?? '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/\s+/g, ' ').trim().slice(0, 160)
const RUIM_ARQUIVO = /(flag|bandeira|logo|icon|[ií]cone|s[ií]mbolo|coat[_ ]of[_ ]arms|bras[aã]o|\bmap\b|mapa|locator|location|signature|assinatura|commons-|wiki|question[_ ]book|ambox|edit-clear|disambig|padlock|crystal|nuvola|portal|stub|blank|placeholder|\.svg|\.tif)/i
const BOM_ARQUIVO = /\.(jpe?g|png|webp|gif)$/i
interface Cand extends Imagem { score: number }
/** Nome de arquivo da wiki sem prefixo e normalizado (a API devolve com espaços; pageimage vem com "_"; prefixo varia: File/Ficheiro/Arquivo). */
const nomeArq = (t: string) => { const n = String(t || '').replace(/^[^:]+:/, '').replace(/_/g, ' ').trim(); return n.charAt(0).toUpperCase() + n.slice(1) }

async function wikipedia(entPerg: string, pergunta: string, base: string, tm: number): Promise<Cand[]> {
  // "modelos de Ferrari", "raças de cachorro": o artigo é o da entidade ("Ferrari"); a pergunta inteira segue para a web
  const ent = entPerg.replace(/^(modelos?|ra[cç]as?|esp[eé]cies?|tipos?|fotos?|imagens?|exemplos?)\s+d[aeo]s?\s+/i, '').trim() || entPerg
  const api = (qs: string) => W.baixar(`${base}/w/api.php?format=json&utf8=1&${qs}`, { timeoutMs: tm, maxBytes: 1_500_000, aceitar: /json/ }).then((r) => { if (r.status !== 200) throw new Error(`Wikipédia HTTP ${r.status}`); return JSON.parse(r.corpo) })
  const j = await api(`action=query&redirects=1&generator=search&gsrsearch=${encodeURIComponent(ent)}&gsrlimit=4&prop=pageimages|pageprops|info&piprop=thumbnail|name|original&pithumbsize=960&inprop=url&ppprop=disambiguation`)
  const paginas = Object.values<any>(j.query?.pages || {}).sort((a, b) => (a.index || 0) - (b.index || 0))
  const art = paginas.find((p) => !p.pageprops?.hasOwnProperty('disambiguation') && REL.relevanciaResultado(ent, String(p.title), '').aceito && REL.citaNomes(ent, String(p.title)))
  if (!art) return []
  const arquivos: string[] = []
  if (art.pageimage) arquivos.push(nomeArq(art.pageimage))
  try { // imagens do próprio artigo: só as que citam a entidade no nome do arquivo (não pega foto de outra pessoa/lugar do texto)
    const ji = await api(`action=query&prop=images&imlimit=40&titles=${encodeURIComponent(art.title)}`)
    const nuc = termos(ent)
    for (const im of Object.values<any>(ji.query?.pages || {})[0]?.images || []) {
      const n = nomeArq(im.title); if (!BOM_ARQUIVO.test(n) || RUIM_ARQUIVO.test(n) || arquivos.includes(n)) continue
      const tn = termos(n.replace(/[_-]/g, ' ')), cob = nuc.filter((x) => tn.includes(x)).length; if (cob >= 1 && cob / nuc.length >= 0.5) arquivos.push(n)
      if (arquivos.length >= 6) break
    }
  } catch { /* só a imagem principal */ }
  if (!arquivos.length) return []
  const jf = await api(`action=query&prop=imageinfo&iiprop=url|size|mime|extmetadata&iiurlwidth=960&iiextmetadatafilter=Artist|LicenseShortName|LicenseUrl|ObjectName|ImageDescription&titles=${encodeURIComponent(arquivos.map((a) => 'File:' + a).join('|'))}`)
  const porNome = new Map<string, any>(); for (const p of Object.values<any>(jf.query?.pages || {})) porNome.set(nomeArq(p.title), p)
  const out: Cand[] = []
  arquivos.forEach((a, i) => {
    const p = porNome.get(a); const ii = p?.imageinfo?.[0]; if (!ii) return
    const mime = String(ii.mime || ''); if (!/^image\/(jpeg|png|webp|gif)$/.test(mime)) return
    if ((ii.width && ii.width < 200) || (ii.height && ii.height < 200)) return
    const md = ii.extmetadata || {}
    out.push({ url: String(ii.thumburl || ii.url), thumb: String(ii.thumburl || ii.url), pagina: String(ii.descriptionurl || art.fullurl), site: 'Wikimedia Commons', titulo: limpa(md.ObjectName?.value) || String(art.title),
      largura: Number(ii.thumbwidth || ii.width) || undefined, altura: Number(ii.thumbheight || ii.height) || undefined, formato: mime.split('/')[1],
      autor: limpa(md.Artist?.value) || undefined, licenca: limpa(md.LicenseShortName?.value) || undefined, licencaUrl: /^https?:\/\//.test(String(md.LicenseUrl?.value || '')) ? String(md.LicenseUrl.value) : undefined,
      motor: 'wikipedia', principal: i === 0 && !!art.pageimage, score: i === 0 ? 100 : 80 - i })
  })
  return out
}
function relevanteWeb(ent: string, titulo: string, pagina: string, texto = '') {
  let caminho = ''; try { const u = new URL(pagina); caminho = decodeURIComponent(u.pathname).replace(/[-_/+.]/g, ' ') } catch { /* */ }
  const tudo = `${titulo} ${texto} ${caminho}`
  if (!REL.citaNomes(ent, tudo)) return 0 // nomes citados ("Tim Maia", "Torre Eiffel") precisam aparecer
  const nuc = termos(ent); if (!nuc.length) return 0
  const tt = new Set(termos(tudo)), cob = nuc.filter((x) => tt.has(x)).length / nuc.length
  return cob >= 0.99 ? 60 : cob >= 0.66 ? 40 : 0 // palavra parecida sozinha não basta
}
const dim = (r: string) => { const m = String(r || '').match(/(\d{2,5})\s*[x×]\s*(\d{2,5})/); return m ? [Number(m[1]), Number(m[2])] : [] }
async function searxng(ent: string, base: string, tm: number): Promise<Cand[]> {
  const r = await W.baixar(`${base.replace(/\/+$/, '')}/search?q=${encodeURIComponent(ent)}&format=json&categories=images&language=pt-BR&safesearch=1`, { timeoutMs: tm, maxBytes: 3_000_000, aceitar: /json/ })
  if (r.status !== 200) throw new Error(`SearXNG respondeu HTTP ${r.status}${r.status === 403 ? ' (ative o formato json em settings.yml)' : ''}`)
  const out: Cand[] = []
  for (const x of (JSON.parse(r.corpo).results || []).slice(0, 30)) {
    const img = String(x.img_src || ''), pag = String(x.url || ''), titulo = limpa(x.title), [w, h] = dim(x.resolution)
    if (!/^https?:\/\//.test(img) || !/^https?:\/\//.test(pag) || /\.svg(\?|$)/i.test(img) || /svg/i.test(String(x.img_format || ''))) continue
    if ((w && w < 200) || (h && h < 200)) continue
    const s = relevanteWeb(ent, titulo, pag, limpa(x.content)); if (!s) continue
    out.push({ url: img, thumb: /^https?:\/\//.test(String(x.thumbnail_src || '')) ? String(x.thumbnail_src) : img, pagina: pag, site: W.dominio(pag), titulo, largura: w || undefined, altura: h || undefined, formato: String(x.img_format || '').toLowerCase() || undefined, motor: 'searxng' + (x.engine ? ':' + x.engine : ''), score: s + (w >= 600 ? 5 : 0) })
  }
  return out
}
async function braveImagens(ent: string, key: string, base: string, tm: number): Promise<Cand[]> {
  if (!key) throw new Error('chave do Brave não configurada')
  const r = await W.baixar(`${base || 'https://api.search.brave.com'}/res/v1/images/search?q=${encodeURIComponent(ent)}&count=20&safesearch=strict&country=BR&search_lang=pt-br`, { timeoutMs: tm, maxBytes: 3_000_000, aceitar: /json/, headers: { Accept: 'application/json', 'X-Subscription-Token': key } })
  if (r.status !== 200) throw new Error(W.redigir(`Brave Images respondeu HTTP ${r.status}`, [key]))
  const out: Cand[] = []
  for (const x of JSON.parse(r.corpo).results || []) {
    const img = String(x.properties?.url || ''), pag = String(x.url || ''), titulo = limpa(x.title), w = Number(x.properties?.width) || 0, h = Number(x.properties?.height) || 0
    if (!/^https?:\/\//.test(img) || !/^https?:\/\//.test(pag) || /\.svg(\?|$)/i.test(img) || (w && w < 200) || (h && h < 200)) continue
    const s = relevanteWeb(ent, titulo, pag); if (!s) continue
    out.push({ url: img, thumb: /^https?:\/\//.test(String(x.thumbnail?.src || '')) ? String(x.thumbnail.src) : img, pagina: pag, site: String(x.source || W.dominio(pag)), titulo, largura: w || undefined, altura: h || undefined, motor: 'brave', score: s })
  }
  return out
}

/* ---------- deduplicação ---------- */
/** Mesma imagem em tamanhos/endereços diferentes conta uma vez (miniaturas da Wikimedia, parâmetros de tamanho). */
export function chaveImagem(u: string) {
  try {
    const x = new URL(u); let p = decodeURIComponent(x.pathname).toLowerCase()
    const wm = p.match(/\/(?:thumb\/)?[0-9a-f]\/[0-9a-f]{2}\/([^/]+?)(?:\/\d+px-[^/]+)?$/); if (/upload\.wikimedia\.org$/.test(x.hostname) && wm) return 'wm:' + wm[1]
    p = p.replace(/[-_](\d{2,4}x\d{2,4}|scaled|thumb|small|medium|large)(?=\.\w+$)/g, '')
    return x.hostname.replace(/^www\./, '') + p
  } catch { return u }
}
export function deduplicar<T extends { url: string; pagina: string }>(xs: T[]): T[] {
  const vistos = new Set<string>(), out: T[] = []
  for (const x of xs) { const k = chaveImagem(x.url); if (vistos.has(k)) continue; vistos.add(k); out.push(x) }
  return out
}

/* ---------- 3. busca coordenada (provedores ativos do painel, cache, verificação) ---------- */
const emAndamento = new Map<string, Promise<ResultadoImagens>>()
export function buscar(ent: string, pergunta: string, o: { max?: number; timeoutMs?: number; verificar?: boolean } = {}): Promise<ResultadoImagens> {
  const k = sha(termos(ent).sort().join(' ') + '|' + (o.max || 4)), ja = emAndamento.get(k); if (ja) return ja
  const p = executar(ent, pergunta, o).finally(() => emAndamento.delete(k)); emAndamento.set(k, p); return p
}
async function executar(ent: string, pergunta: string, o: { max?: number; timeoutMs?: number; verificar?: boolean }): Promise<ResultadoImagens> {
  const t0 = Date.now(), max = Math.min(Math.max(o.max || 4, 1), 5), tentativas: ResultadoImagens['tentativas'] = []
  // busca de imagens na internet também obedece à chave global e ao bloqueio do turno (sem chamar nenhum provedor)
  { const PB = await import('../bloqueio-pesquisa.js'); await PB.internetPermitida(); if (PB.registrar('busca_web', 'imagens: ' + ent)) return { imagens: [], tentativas: [{ motor: 'internet', status: 'erro', motivo: 'pesquisa na internet desativada' } as any], cache: false, ms: 0 } }
  const C = await import('./central.js'), { linhas, bloqueados, cfg } = await C.linhasBuscaAtivas()
  // cache por assunto E pelos provedores em uso (trocar/ativar um provedor no painel não reaproveita resultado antigo);
  // "nenhuma imagem" vale só 1 h e falha de provedor nunca é guardada
  const ck = 'img:' + sha(termos(ent).sort().join(' ') + '|' + max + '|' + linhas.filter((l) => ['wikipedia', 'searxng', 'brave'].includes(l.provider)).map((l) => l.provider + '@' + (l.cfg.base_url || '')).sort().join(',')), hit = await W.cacheGet(ck, cfg.cacheHoras)
  if (hit) { const v = JSON.parse(hit.body); if (v.length || (await W.cacheGet(ck, 1))) return { imagens: v, tentativas: [{ motor: 'cache', status: 'cache' }], cache: true, ms: Date.now() - t0 } }
  const tm = Math.min(o.timeoutMs || 6000, cfg.timeoutMs), linha = (p: string) => linhas.find((l) => l.provider === p)
  const fora = (c: Cand) => bloqueados.has(W.dominio(c.pagina)) || bloqueados.has(W.dominio(c.url))
  const tentar = async (motor: string, f: () => Promise<Cand[]>) => { const t = Date.now(); try { const r = (await f()).filter((c) => !fora(c)); tentativas.push({ motor, status: r.length ? 'ok' : 'vazio', n: r.length, ms: Date.now() - t }); return r } catch (e: any) { tentativas.push({ motor, status: 'erro', ms: Date.now() - t, motivo: String(e?.message || e).slice(0, 160) }); return [] } }
  // gratuitos em paralelo (Wikipédia + SearXNG); o pago só se os gratuitos não trouxerem nada
  const wp = linha('wikipedia'), sx = linha('searxng'), br = linha('brave')
  const grupos = await Promise.all([
    wp ? tentar('wikipedia', () => wikipedia(ent, pergunta, String(wp.cfg.base_url || 'https://pt.wikipedia.org').replace(/\/+$/, ''), tm)) : (tentativas.push({ motor: 'wikipedia', status: 'pulado', motivo: 'desativado no painel' }), Promise.resolve([])),
    sx && sx.cfg.base_url ? tentar('searxng', () => searxng(ent, String(sx.cfg.base_url), tm)) : (tentativas.push({ motor: 'searxng', status: 'pulado', motivo: sx ? 'URL não configurada' : 'desativado ou não configurado' }), Promise.resolve([])),
  ])
  let cands = grupos.flat()
  if (!cands.length && br && br.cfg.key) { try { await W.consumir('buscas', cfg.maxBuscasDia); cands = await tentar('brave', () => braveImagens(ent, String(br.cfg.key), String(br.cfg.base_url || ''), tm)) } catch (e: any) { tentativas.push({ motor: 'brave', status: 'pulado', motivo: String(e?.message || e).slice(0, 120) }) } }
  cands = deduplicar(cands.sort((a, b) => b.score - a.score))
  // 4. verificação real: só entra imagem que abre de fato (e já fica no cache do proxy para abrir rápido no app)
  const escolhidas: Cand[] = []
  if (o.verificar === false) escolhidas.push(...cands.slice(0, max))
  else {
    const fila = cands.slice(0, max + 3), ok = await Promise.all(fila.map((c) => baixarImagem(c.url, { timeoutMs: Math.min(tm, 5000) }).then(() => true, (e) => { tentativas.push({ motor: c.motor, status: 'imagem_descartada', motivo: String(e?.message || e).slice(0, 100) }); return false })))
    fila.forEach((c, i) => { if (ok[i] && escolhidas.length < max) escolhidas.push(c) })
  }
  const imagens = escolhidas.map(({ score, ...x }, i) => ({ ...x, principal: i === 0 }))
  if (imagens.length || !tentativas.some((t) => t.status === 'erro')) await W.cachePut(ck, 'imagens', JSON.stringify(imagens), 200).catch(() => {})
  return { imagens, tentativas, cache: false, ms: Date.now() - t0 }
}

/* ---------- 4. marcador para o app ---------- */
const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64url')
/** ⟦img:…⟧ com os caminhos JÁ ASSINADOS do proxy e os dados de origem/atribuição. */
export async function marcador(imgs: Imagem[], ent: string): Promise<string> {
  if (!imgs.length) return ''
  const i = await Promise.all(imgs.slice(0, 4).map(async (x) => ({ s: await caminhoProxy(x.url), ...(x.thumb && x.thumb !== x.url ? { m: await caminhoProxy(x.thumb) } : {}), p: x.pagina, d: x.site, t: x.titulo, ...(x.autor ? { a: x.autor } : {}), ...(x.licenca ? { l: x.licenca } : {}), ...(x.licencaUrl ? { lu: x.licencaUrl } : {}), ...(x.largura && x.altura ? { w: x.largura, h: x.altura } : {}) })))
  return `⟦img:${b64(JSON.stringify({ e: ent.slice(0, 80), i }))}⟧`
}
/** Marcadores de imagem que não vieram deste servidor (texto da IA, páginas, usuário) são removidos. */
export const semMarcadores = (t: string) => String(t || '').replace(/⟦img:[^⟧]*⟧/g, '').trim()
