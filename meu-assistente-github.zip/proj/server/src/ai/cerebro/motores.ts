// Cérebro Central — pesquisa na web MULTIMOTOR (SearXNG, Tavily, Exa, Brave Search + Wikipédia e Google CSE).
// • catálogo dos mecanismos (gratuito/freemium, variáveis de ambiente, limite diário padrão);
// • credenciais: a chave cadastrada no painel (cifrada no banco) vale primeiro; sem ela, a variável de ambiente.
//   A chave NUNCA é devolvida ao navegador, gravada em log ou incluída em mensagens de erro (ver redigir());
// • escolha automática: gratuitos primeiro; dentro de cada faixa, o mais adequado ao tipo de pergunta; depois a prioridade do painel;
// • fallback: se o mecanismo falha, está pausado, estourou o limite ou não trouxe resultados satisfatórios, passa ao próximo;
// • sem pesquisa duplicada: a mesma pergunta (mesmas palavras relevantes) em andamento é compartilhada e o resultado fica em cache;
// • controle de uso: consumo por mecanismo/dia, limite diário individual, pausa automática após falhas (401/403, 429, 5xx).
import { q, one, nowIso, isoOf } from '../../db/index.js'
import * as W from './web.js'
import { sha } from './texto.js'

export type Custo = 'gratis' | 'freemium'
export interface DefMotor { id: string; nome: string; custo: Custo; exigeChave: boolean; exigeUrl: boolean; envChaves: string[]; envUrl?: string; envExtra?: Record<string, string>; prioridade: number; limiteDia: number | null; obs: string }
export const MOTORES: Record<string, DefMotor> = {
  searxng: { id: 'searxng', nome: 'SearXNG (metabusca própria)', custo: 'gratis', exigeChave: false, exigeUrl: true, envChaves: [], envUrl: 'SEARXNG_URL', prioridade: 10, limiteDia: null, obs: 'Instância própria: sem custo e sem chave. Exige o formato json habilitado em settings.yml (search.formats).' },
  wikipedia: { id: 'wikipedia', nome: 'Wikipédia (API pública)', custo: 'gratis', exigeChave: false, exigeUrl: false, envChaves: [], prioridade: 20, limiteDia: null, obs: 'API pública e gratuita; ótima para definições e conceitos, fraca para notícias e preços.' },
  brave: { id: 'brave', nome: 'Brave Search (API)', custo: 'freemium', exigeChave: true, exigeUrl: false, envChaves: ['BRAVE_SEARCH_API_KEY', 'BRAVE_API_KEY'], prioridade: 30, limiteDia: 60, obs: 'Índice próprio, bom para notícias, preços e assuntos recentes. O plano define limites e o direito de guardar resultados.' },
  tavily: { id: 'tavily', nome: 'Tavily (busca para IA)', custo: 'freemium', exigeChave: true, exigeUrl: false, envChaves: ['TAVILY_API_KEY'], prioridade: 40, limiteDia: 30, obs: 'Pensado para agentes de IA: trechos já resumidos. Cada busca básica consome créditos do plano.' },
  exa: { id: 'exa', nome: 'Exa (busca semântica)', custo: 'freemium', exigeChave: true, exigeUrl: false, envChaves: ['EXA_API_KEY'], prioridade: 50, limiteDia: 30, obs: 'Busca semântica/neural: boa para pesquisa conceitual e artigos. Cobrança por requisição.' },
  google_cse: { id: 'google_cse', nome: 'Google Programmable Search (API oficial)', custo: 'freemium', exigeChave: true, exigeUrl: false, envChaves: ['GOOGLE_CSE_API_KEY'], envExtra: { cx: 'GOOGLE_CSE_CX' }, prioridade: 60, limiteDia: 90, obs: 'Exige chave e ID do mecanismo (cx).' },
}
export const MOTORES_NOVOS = ['searxng', 'brave', 'tavily', 'exa']

/* ---------- credenciais (painel > ambiente) ---------- */
const env = (n?: string) => (n ? String(process.env[n] || '').trim() : '')
export interface Cred { key: string; base_url: string; extra: any; origemChave: 'painel' | 'ambiente' | null; origemUrl: 'painel' | 'ambiente' | 'padrao' | null }
export function credenciais(provider: string, painel: { key?: string; url?: string; extra?: any }): Cred {
  const d = MOTORES[provider]; const extra = { ...(painel.extra || {}) }
  let key = String(painel.key || '').trim(), origemChave: Cred['origemChave'] = key ? 'painel' : null
  if (!key && d) { for (const n of d.envChaves) if (env(n)) { key = env(n); origemChave = 'ambiente'; break } }
  if (d?.envExtra) for (const [k, n] of Object.entries(d.envExtra)) if (!extra[k] && env(n)) extra[k] = env(n)
  let url = String(painel.url || '').trim(), origemUrl: Cred['origemUrl'] = url ? 'painel' : null
  if (!url && d?.envUrl && env(d.envUrl)) { url = env(d.envUrl).replace(/\/+$/, ''); origemUrl = 'ambiente' }
  return { key, base_url: url, extra, origemChave, origemUrl }
}
/** Tem o que o mecanismo exige para funcionar (chave, URL, cx)? */
export function configurado(provider: string, c: Cred): string | null {
  const d = MOTORES[provider]; if (!d) return null
  if (d.exigeChave && !c.key) return 'sem chave de API (cadastre no painel ou na variável de ambiente)'
  if (d.exigeUrl && !c.base_url) return 'URL do serviço não configurada'
  if (provider === 'google_cse' && !c.extra?.cx) return 'falta o ID do mecanismo (cx)'
  return null
}
/** Na criação dos registros padrão: mecanismo com credencial já presente no ambiente nasce ligado (o painel pode desligar). */
export function nasceLigado(provider: string) { const c = credenciais(provider, {}); return !!MOTORES[provider] && provider !== 'wikipedia' && !configurado(provider, c) }

/* ---------- estado e consumo ---------- */
const hoje = () => nowIso().slice(0, 10)
export interface Estado { prioridade: number | null; limiteDia: number | null; falhasSeguidas: number; pausadoAte: string | null; ultimoErro: string | null; ultimoErroEm: string | null; ultimoOkEm: string | null; consumoInfo: any }
async function estadoDe(provider: string): Promise<Estado> {
  const r: any = await one('SELECT * FROM brain_motor_estado WHERE provider = $1', [provider])
  let info: any = null; try { info = r?.consumo_info ? JSON.parse(r.consumo_info) : null } catch { /* */ }
  return { prioridade: r?.prioridade == null ? null : Number(r.prioridade), limiteDia: r?.limite_dia == null ? null : Number(r.limite_dia), falhasSeguidas: Number(r?.falhas_seguidas) || 0, pausadoAte: isoOf(r?.pausado_ate), ultimoErro: r?.ultimo_erro || null, ultimoErroEm: isoOf(r?.ultimo_erro_em), ultimoOkEm: isoOf(r?.ultimo_ok_em), consumoInfo: info }
}
async function gravarEstado(provider: string, e: Partial<Record<string, any>>) {
  const campos = Object.keys(e), vals = Object.values(e)
  await q(`INSERT INTO brain_motor_estado (provider, ${campos.join(', ')}, updated_at) VALUES ($1, ${campos.map((_, i) => '$' + (i + 2)).join(', ')}, $${campos.length + 2}) ON CONFLICT (provider) DO UPDATE SET ${campos.map((c) => `${c} = EXCLUDED.${c}`).join(', ')}, updated_at = EXCLUDED.updated_at`, [provider, ...vals, nowIso()])
}
async function contar(provider: string, d: { buscas?: number; erros?: number; vazias?: number; cache?: number; ms?: number }) {
  await q('INSERT INTO brain_motor_uso (provider, dia, buscas, erros, vazias, cache, ms_total) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (provider, dia) DO UPDATE SET buscas = brain_motor_uso.buscas + EXCLUDED.buscas, erros = brain_motor_uso.erros + EXCLUDED.erros, vazias = brain_motor_uso.vazias + EXCLUDED.vazias, cache = brain_motor_uso.cache + EXCLUDED.cache, ms_total = brain_motor_uso.ms_total + EXCLUDED.ms_total',
    [provider, hoje(), d.buscas || 0, d.erros || 0, d.vazias || 0, d.cache || 0, d.ms || 0])
}
const usoDia = async (provider: string) => Number((await one('SELECT buscas FROM brain_motor_uso WHERE provider = $1 AND dia = $2', [provider, hoje()]))?.buscas) || 0
export async function salvarAjustes(provider: string, b: { prioridade?: number | null; limiteDia?: number | null; retomar?: boolean }) {
  if (!MOTORES[provider]) return
  const o: Record<string, any> = {}
  if (b.prioridade !== undefined) o.prioridade = b.prioridade === null ? null : Math.max(1, Math.min(999, Math.round(Number(b.prioridade)) || MOTORES[provider].prioridade))
  if (b.limiteDia !== undefined) o.limite_dia = b.limiteDia === null || String(b.limiteDia) === '' ? null : Math.max(0, Math.min(1_000_000, Math.round(Number(b.limiteDia)) || 0))
  if (b.retomar) { o.pausado_ate = null; o.falhas_seguidas = 0 }
  if (Object.keys(o).length) await gravarEstado(provider, o)
}
function pausaPara(e: { status: number; esperaS: number }, falhas: number): number {
  if (e.status === 401 || e.status === 403) return 30 * 60_000 // chave inválida: não adianta insistir
  if (e.status === 429 || e.status === 402 || e.status === 432 || e.status === 433) return Math.max(e.esperaS * 1000, 10 * 60_000) // limite do plano
  if (falhas >= 3) return Math.min(30, 2 ** (falhas - 3) * 2) * 60_000 // falhas seguidas: 2, 4, 8… até 30 min
  return 0
}
/** Registra o resultado de uma tentativa: consumo do dia, saúde (último erro/ok) e pausa automática. Nenhuma chave é gravada. */
async function registrar(provider: string, r: { ok: boolean; vazio?: boolean; ms: number; erro?: string; status?: number; esperaS?: number; info?: any; chaves?: (string | undefined)[] }) {
  await contar(provider, { buscas: 1, erros: r.ok ? 0 : 1, vazias: r.ok && r.vazio ? 1 : 0, ms: r.ms })
  const e = await estadoDe(provider)
  if (r.ok) await gravarEstado(provider, { falhas_seguidas: 0, pausado_ate: null, ultimo_ok_em: nowIso(), ...(r.info ? { consumo_info: JSON.stringify({ ...r.info, em: nowIso() }) } : {}) })
  else {
    const falhas = e.falhasSeguidas + 1, p = pausaPara({ status: r.status || 0, esperaS: r.esperaS || 0 }, falhas)
    await gravarEstado(provider, { falhas_seguidas: falhas, ultimo_erro: W.redigir(r.erro, r.chaves || []).slice(0, 300), ultimo_erro_em: nowIso(), pausado_ate: p ? new Date(Date.now() + p).toISOString() : null })
  }
}

/** Painel: uso, limite e saúde de cada mecanismo (sem nenhuma chave). */
export async function estatisticas(): Promise<Record<string, any>> {
  const mes = hoje().slice(0, 7), out: Record<string, any> = {}
  const uso = await q('SELECT provider, dia, buscas, erros, vazias, cache, ms_total FROM brain_motor_uso WHERE dia >= $1', [mes + '-01'])
  const estados = await q('SELECT provider FROM brain_motor_estado')
  const ids = new Set<string>([...Object.keys(MOTORES), ...estados.map((x: any) => String(x.provider))])
  for (const id of ids) {
    const meus = uso.filter((u: any) => u.provider === id), h: any = meus.find((u: any) => u.dia === hoje()) || {}, e = await estadoDe(id), d = MOTORES[id]
    const limite = e.limiteDia !== null ? e.limiteDia : (d?.limiteDia ?? null), buscasHoje = Number(h.buscas) || 0, todas = meus.reduce((s: number, u: any) => s + (Number(u.buscas) || 0), 0)
    out[id] = { hoje: { buscas: buscasHoje, erros: Number(h.erros) || 0, vazias: Number(h.vazias) || 0, cache: Number(h.cache) || 0 }, mes: { buscas: todas, erros: meus.reduce((s: number, u: any) => s + (Number(u.erros) || 0), 0), cache: meus.reduce((s: number, u: any) => s + (Number(u.cache) || 0), 0) },
      mediaMs: todas ? Math.round(meus.reduce((s: number, u: any) => s + (Number(u.ms_total) || 0), 0) / todas) : null, limiteDia: limite, limitePadrao: d?.limiteDia ?? null, prioridade: e.prioridade ?? d?.prioridade ?? 100,
      pausadoAte: e.pausadoAte && Date.parse(e.pausadoAte) > Date.now() ? e.pausadoAte : null, ultimoErro: e.ultimoErro, ultimoErroEm: e.ultimoErroEm, ultimoOkEm: e.ultimoOkEm, consumoInfo: e.consumoInfo }
  }
  return out
}

/* ---------- escolha automática ---------- */
const sem = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
export type Tipo = 'recente' | 'enciclopedico' | 'pesquisa' | 'local' | 'geral'
export function tipoDaPergunta(termo: string): Tipo[] {
  const t = sem(termo).trim(), out: Tipo[] = []
  if (/\b(hoje|agora|ontem|amanha|esta semana|ultim[ao]s?|recente(s|mente)?|atual(mente)?|noticias?|cotacao|preco|valor d[aoe]|placar|resultado d[aoe]|lancamento|202\d)\b/.test(t)) out.push('recente')
  if (/^(o que (e|sao|significa)|quem (foi|e|era|sao)|defina|definicao|historia d|significado d|conceito d|qual (e )?a capital)\b/.test(t)) out.push('enciclopedico')
  if (/\b(melhores?|artigos?|estudos?|pesquisas? sobre|compar(e|ar|acao)|similar(es)?|alternativas?|tendencias?|analise)\b/.test(t) || t.split(/\s+/).length >= 8) out.push('pesquisa')
  if (/\b(perto de|proximo a|onde comprar|restaurantes?|lojas?|endereco|telefone d[aoe]|horario d[aoe])\b/.test(t)) out.push('local')
  return out.length ? out : ['geral']
}
const ADEQ: Record<string, Partial<Record<Tipo, number>>> = {
  wikipedia: { enciclopedico: 3, recente: -3, local: -3, pesquisa: -1 },
  searxng: { recente: 1 },
  brave: { recente: 2, local: 2 },
  tavily: { pesquisa: 2, recente: 1, enciclopedico: 1 },
  exa: { pesquisa: 2, recente: -1, local: -2 },
  google_cse: { local: 1 },
}
export const adequacao = (provider: string, tipos: Tipo[]) => tipos.reduce((s, t) => s + (ADEQ[provider]?.[t] || 0), 0)

export interface Linha { id: number; provider: string; enabled: boolean; role: string; cfg: W.Busca }
export interface Elegivel { linha: Linha; def: DefMotor; ajuste: number; prioridade: number; usoHoje: number; limite: number | null }
export interface Tentativa { motor: string; nome: string; status: 'ok' | 'vazio' | 'insuficiente' | 'erro' | 'pulado' | 'cache'; n?: number; ms?: number; motivo?: string }
/** Ordena os mecanismos ativos: gratuitos antes dos pagos/freemium; dentro da faixa, o mais adequado à pergunta, depois a prioridade do painel.
 *  Mecanismo claramente inadequado (ex.: Wikipédia para notícias) vai para o fim — continua como último recurso. */
export async function ordenar(linhas: Linha[], termo: string): Promise<{ fila: Elegivel[]; pulados: Tentativa[] }> {
  const tipos = tipoDaPergunta(termo), fila: Elegivel[] = [], pulados: Tentativa[] = []
  const estados = new Map<string, Estado>(); for (const l of linhas) estados.set(l.provider, await estadoDe(l.provider))
  for (const l of linhas) {
    const def = MOTORES[l.provider]; if (!def) { fila.push({ linha: l, def: { id: l.provider, nome: l.provider, custo: 'freemium', exigeChave: false, exigeUrl: false, envChaves: [], prioridade: 90, limiteDia: null, obs: '' }, ajuste: 0, prioridade: 90, usoHoje: 0, limite: null }); continue }
    const e = estados.get(l.provider)!, falta = configurado(l.provider, credenciais(l.provider, { key: l.cfg.key, url: l.cfg.base_url, extra: l.cfg.extra }))
    if (falta) { pulados.push({ motor: l.provider, nome: def.nome, status: 'pulado', motivo: falta }); continue }
    if (e.pausadoAte && Date.parse(e.pausadoAte) > Date.now()) { pulados.push({ motor: l.provider, nome: def.nome, status: 'pulado', motivo: `pausado até ${e.pausadoAte.slice(11, 16)} UTC após falhas (${W.redigir(e.ultimoErro || '', [l.cfg.key]).slice(0, 100)})` }); continue }
    const limite = e.limiteDia !== null ? e.limiteDia : def.limiteDia, usado = await usoDia(l.provider)
    if (limite !== null && usado >= limite) { pulados.push({ motor: l.provider, nome: def.nome, status: 'pulado', motivo: `limite diário do mecanismo atingido (${usado}/${limite})` }); continue }
    fila.push({ linha: l, def, ajuste: adequacao(l.provider, tipos), prioridade: e.prioridade ?? def.prioridade, usoHoje: usado, limite })
  }
  const faixa = (x: Elegivel) => (x.ajuste <= -2 ? 2 : x.def.custo === 'gratis' ? 0 : 1)
  fila.sort((a, b) => faixa(a) - faixa(b) || b.ajuste - a.ajuste || a.prioridade - b.prioridade || (a.linha.role === 'principal' ? 0 : 1) - (b.linha.role === 'principal' ? 0 : 1) || a.linha.id - b.linha.id)
  return { fila, pulados }
}

/* ---------- consulta sem duplicidade ---------- */
const STOP = new Set(['de', 'da', 'do', 'das', 'dos', 'a', 'o', 'as', 'os', 'um', 'uma', 'que', 'e', 'em', 'no', 'na', 'nos', 'nas', 'para', 'por', 'com', 'ao', 'se', 'eh', 'qual', 'quais', 'como'])
export const consultaNormalizada = (t: string) => [...new Set(sem(t).replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w && !STOP.has(w)))].sort().join(' ')
/** URL canônica: sem www, parâmetros de rastreio, âncora e barra final — a mesma página vinda de motores diferentes vira uma só. */
export function urlCanonica(u: string) {
  try { const x = new URL(u); x.hash = ''; for (const k of [...x.searchParams.keys()]) if (/^(utm_|fbclid|gclid|ref$|ref_)/i.test(k)) x.searchParams.delete(k); x.hostname = x.hostname.replace(/^www\./, ''); return (x.origin + x.pathname.replace(/\/+$/, '') + x.search).toLowerCase() } catch { return String(u).toLowerCase() }
}
export function mesclar(grupos: { motor: string; itens: W.Resultado[] }[]): W.Resultado[] {
  const mapa = new Map<string, W.Resultado>(), ordem: string[] = []
  for (const g of grupos) for (const r of g.itens) {
    const k = urlCanonica(r.url), ex = mapa.get(k)
    if (!ex) { mapa.set(k, { ...r, motores: [g.motor] }); ordem.push(k) }
    else { if (!ex.motores!.includes(g.motor)) ex.motores!.push(g.motor); if (r.resumo.length > ex.resumo.length) ex.resumo = r.resumo; if (!ex.titulo && r.titulo) ex.titulo = r.titulo }
  }
  return ordem.map((k) => mapa.get(k)!)
}
const emVoo = new Map<string, Promise<Multi>>()
export interface Multi { resultados: W.Resultado[]; tentativas: Tentativa[]; usados: string[]; cache: boolean; compartilhada?: boolean }
export interface OpMulti { linhas: Linha[]; limite: number; timeoutMs: number; cacheHoras: number; maxBuscasDia: number; satisfatorio?: (r: W.Resultado[]) => boolean }

async function tentarUm(m: Elegivel, termo: string, o: OpMulti): Promise<W.Resultado[]> {
  const t0 = Date.now(), chaves = [m.linha.cfg.key]; let info: any = null
  await W.consumir('buscas', o.maxBuscasDia) // limite diário geral (todos os mecanismos): só conta quando vai mesmo à rede
  try {
    const r = await W.buscar(termo, { ...m.linha.cfg, timeoutMs: o.timeoutMs, onInfo: (i) => { info = { ...(info || {}), ...i } } }, o.limite)
    await registrar(m.linha.provider, { ok: true, vazio: !r.length, ms: Date.now() - t0, info, chaves }); return r
  } catch (e: any) {
    await registrar(m.linha.provider, { ok: false, ms: Date.now() - t0, erro: e?.message || String(e), status: e?.status, esperaS: e?.esperaS, chaves }); throw e
  }
}
/** Teste do painel: ignora pausa e limite do mecanismo, e a primeira resposta boa tira a pausa. */
export async function testar(provider: string, cfg: W.Busca, termo: string, timeoutMs: number) {
  const m: Elegivel = { linha: { id: 0, provider, enabled: true, role: 'alternativo', cfg }, def: MOTORES[provider], ajuste: 0, prioridade: 0, usoHoje: 0, limite: null }
  return tentarUm(m, termo, { linhas: [], limite: 3, timeoutMs, cacheHoras: 0, maxBuscasDia: 1_000_000 })
}

/** Pesquisa na web escolhendo o mecanismo: gratuitos primeiro, fallback automático, cache e sem duplicidade em andamento. */
export function pesquisar(termo: string, o: OpMulti): Promise<Multi> {
  const norm = consultaNormalizada(termo), chave = `${norm}|${o.limite}`
  const andamento = emVoo.get(chave); if (andamento) return andamento.then((r) => ({ ...r, compartilhada: true }))
  const p = executar(termo, norm, o).finally(() => emVoo.delete(chave)); emVoo.set(chave, p); return p
}
async function executar(termo: string, norm: string, o: OpMulti): Promise<Multi> {
  const ck = 'mm:' + sha(`${norm}|${o.limite}`), hit = o.cacheHoras > 0 ? await W.cacheGet(ck, o.cacheHoras) : null
  if (hit) { try { const j = JSON.parse(hit.body); for (const m of j.usados || []) await contar(m, { cache: 1 }); return { resultados: j.resultados, tentativas: [{ motor: (j.usados || [])[0] || 'cache', nome: 'cache', status: 'cache', n: j.resultados.length }], usados: j.usados || [], cache: true } } catch { /* cache corrompido: refaz */ } }
  const { fila, pulados } = await ordenar(o.linhas, termo), tentativas: Tentativa[] = [...pulados], grupos: { motor: string; itens: W.Resultado[] }[] = [], usados: string[] = []
  const bom = o.satisfatorio || ((r: W.Resultado[]) => r.length >= 2)
  let satisfeito = false
  for (const m of fila) {
    const t0 = Date.now()
    try {
      const itens = await tentarUm(m, termo, o)
      if (!itens.length) { tentativas.push({ motor: m.linha.provider, nome: m.def.nome, status: 'vazio', n: 0, ms: Date.now() - t0, motivo: 'sem resultados' }); continue }
      grupos.push({ motor: m.linha.provider, itens }); usados.push(m.linha.provider)
      const juntos = mesclar(grupos)
      if (bom(juntos)) { tentativas.push({ motor: m.linha.provider, nome: m.def.nome, status: 'ok', n: itens.length, ms: Date.now() - t0 }); satisfeito = true; break }
      tentativas.push({ motor: m.linha.provider, nome: m.def.nome, status: 'insuficiente', n: itens.length, ms: Date.now() - t0, motivo: 'resultados pouco relevantes: tentando o próximo mecanismo' })
    } catch (e: any) {
      const msg = W.redigir(e?.message || e, [m.linha.cfg.key])
      tentativas.push({ motor: m.linha.provider, nome: m.def.nome, status: 'erro', ms: Date.now() - t0, motivo: msg })
      if (/limite diário de buscas/.test(msg)) break // limite GERAL atingido: nenhum outro mecanismo de rede pode ser chamado hoje
    }
  }
  const resultados = mesclar(grupos)
  if (resultados.length && o.cacheHoras > 0) await W.cachePut(ck, 'busca-multi', JSON.stringify({ resultados, usados }), 200).catch(() => {})
  void satisfeito
  return { resultados, tentativas, usados, cache: false }
}
