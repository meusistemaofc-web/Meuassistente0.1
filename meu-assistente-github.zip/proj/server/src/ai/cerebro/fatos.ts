// CONHECIMENTO GRANULAR — fatos individualmente recuperáveis dentro do conhecimento que já existe (knowledge_documents).
// Sem tabela nova: o estudo (central.ts › executar) acrescenta ao conteúdo uma seção "Fatos identificados", com um fato
// por linha, rótulo fixo e as fontes [n]. Essa seção faz parte do texto que o administrador revisa, edita e aprova — a
// resposta sempre lê o conteúdo ATUAL (o que foi aprovado/editado), nunca uma cópia escondida.
//   - Nome completo: Felipe Titto Teixeira [1]
//   - Nascimento: 30 de março de 1986 [1][2]
//   - Local de nascimento: São Paulo [1]
//   - Profissão: ator, empresário e apresentador [1][2]
//   - Conhecido por: … [2]
//   - Empresas e negócios: … [1]
//   - Trajetória (2008): … [1]
//   - Relações: … [2]
//   - Divergência: data de nascimento — 30 de março de 1986 [1] × 1985 [2]
// Na pergunta, a INTENÇÃO (idade, ano, local, profissão, trajetória, empresas, como ficou conhecido, relações, história,
// o que não está confirmado) escolhe só os fatos que respondem; idade e intervalos são CALCULADOS a partir das datas
// guardadas; sem o fato, a resposta diz que não há a informação confirmada (nunca inventa).
import * as T from './texto.js'

export const SECAO = 'Fatos identificados (respostas específicas):'
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const DATA = /(\d{1,2})º?\s+de\s+(janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+(\d{4})/i
export interface Data { d?: number; m?: number; a: number }
export function lerData(s: string): Data | null {
  const m = DATA.exec(s); if (m) return { d: Number(m[1]), m: MESES.findIndex((x) => nrm(x) === nrm(m[2])) + 1, a: Number(m[3]) }
  const y = /\b(1[89]\d{2}|20\d{2})\b/.exec(s); return y ? { a: Number(y[1]) } : null
}
export const dataTxt = (x: Data) => (x.d && x.m ? `${x.d} de ${MESES[x.m - 1]} de ${x.a}` : String(x.a))
export interface Fato { tipo: string; valor: string; fontes: number[]; ano?: number }
const ROT: Record<string, string> = { nome: 'Nome completo', nascimento: 'Nascimento', local: 'Local de nascimento', morte: 'Morte', profissao: 'Profissão', conhecido: 'Conhecido por', empresas: 'Empresas e negócios', trajetoria: 'Trajetória', relacoes: 'Relações', divergencia: 'Divergência' }
const TIPO_DE_ROT = new Map(Object.entries(ROT).map(([k, v]) => [nrm(v), k]))

/* ---------- extração (no estudo) ---------- */
const PROF = /(?:^|\s)(?:é|foi|era)\s+(?:um|uma|o|a)\s+((?:[a-zà-ÿ-]+(?:,\s*|\s+e\s+|\s+)){0,10}?[a-zà-ÿ-]+(?:\s+(?:brasileir[oa]s?|portugu[eê]s[a]?|americano|americana|norte-americano|norte-americana|argentin[oa]|angolan[oa]))?)(?=[,.;]|\s+(?:que|conhecid|nascid|natural|famos|e\s+ex-))/i
const OCUP = /\b(ator|atriz|cantor|cantora|empres[aá]ri[oa]|apresentador|apresentadora|jornalista|pol[ií]tic[oa]|escritor|escritora|piloto|automobilista|jogador|jogadora|futebolista|treinador|m[uú]sic[oa]|compositor|compositora|modelo|influenciador|influenciadora|youtuber|m[eé]dic[oa]|advogad[oa]|engenheir[oa]|professor|professora|cientista|artista|diretor|diretora|produtor|produtora|investidor|investidora|atleta|lutador|lutadora|humorista|comediante|dubl|chef|cozinheir[oa]|dançarin[oa]|bailarin[oa]|pintor|pintora|fot[oó]graf[oa]|arquitet[oa]|economista|fil[oó]sof[oa]|historiador|historiadora|deputad[oa]|senador|senadora|prefeit[oa]|governador|governadora|presidente|empreendedor|empreendedora|ex-|personalidade|celebridade|repórter|locutor|locutora|radialista|roteirista|cineasta|youtuber|streamer|palestrante|coach|nutricionista|personal)/i
const CONHECIDO = /\b(?:ficou|tornou-se|se tornou|é|era|foi|ganhou)\s+(?:mais\s+|amplamente\s+|nacionalmente\s+)?(?:conhecid[oa]s?|famos[oa]s?|notoriedade|fama|projeção|popularidade)\b/i
const EMPRESA = /\b(fundou|fundador|fundadora|cofundador|cofundadora|s[oó]ci[oa]|dono\s+d|dona\s+d|propriet[aá]ri[oa]|CEO|investidor|investidora|empresa|empresas|neg[oó]cio|neg[oó]cios|marca\s+(?:pr[oó]pria|de)|franquia|startup|rede de|holding|empreendimento)\b/i
const RELACAO = /\b(filh[oa] d[eoa]|casad[oa]\s+com|casou(?:-se)?\s+com|marido|esposa|mulher\s+d[eoa]|namorad[oa]|namora|irm[aã]o\s+d[eoa]|irm[aã]\s+d[eoa]|pai\s+d[eoa]|m[aã]e\s+d[eoa]|sobrinh[oa]\s+d[eoa]|net[oa]\s+d[eoa]|prim[oa]\s+d[eoa]|tem\s+(?:dois|duas|tr[eê]s|um|uma|\d+)\s+filh)/i
const CARREIRA = /\b(conclu|gradu|estre|particip|atuou|atua|trabalh|lan[cç]|venc|conquist|integr|apresent|assin|ingress|come[cç]|inici|deixou|transferiu|fundou|criou|interpret|protagoniz|gravou|disput|eleit|nomead|assumiu|formou|estudou|venceu|ganhou|foi contratad|fez parte|estreou)/i
const ENTRE_PARENTESES = /^([^()]{2,90}?)\s*\(([^()]{4,220})\)\s+(?:é|foi|era)\s/
/** Fatos de um conjunto de páginas sobre a entidade. fontesIdx: número [n] de cada página (na lista de referências). */
export function extrair(entidade: string, paginas: { texto: string; titulo: string; n: number }[]): Fato[] {
  const out: Fato[] = []
  const add = (tipo: string, valor: string, n: number, ano?: number) => {
    valor = valor.replace(/\s+/g, ' ').replace(/\s*\[\d+\]/g, '').trim().replace(/[;,:\s]+$/, ''); if (valor.length < 2 || valor.length > 320) return
    const ex = out.find((f) => f.tipo === tipo && (nrm(f.valor) === nrm(valor) || (valor.length > 40 && T.semelhanca(f.valor, valor) >= 0.6)))
    if (ex) { if (!ex.fontes.includes(n)) ex.fontes.push(n); return }
    out.push({ tipo, valor, fontes: [n], ...(ano ? { ano } : {}) })
  }
  const ent = nrm(entidade).split(/\s+/).filter((w) => w.length > 2)
  for (const pg of paginas) {
    const texto = String(pg.texto || '').replace(/^#+\s.*$/gm, ' ').replace(/\s+/g, ' ').trim()
    const fs = T.frases(texto).map((f) => f.trim()).filter((f) => f.length >= 25 && f.length <= 500)
    // abertura: "Nome Completo (Cidade, 30 de março de 1986) é um ator, empresário e apresentador brasileiro."
    const ab = fs.slice(0, 4).find((f) => ent.every((w) => nrm(f).includes(w.slice(0, Math.max(3, w.length - 1))))) || fs[0] || ''
    const mp = ENTRE_PARENTESES.exec(ab)
    if (mp) {
      const nomeC = mp[1].trim(); if (nomeC.split(/\s+/).length >= 2 && nomeC.split(/\s+/).length <= 8 && /^[A-ZÀ-Ý]/.test(nomeC)) add('nome', nomeC, pg.n)
      const par = mp[2], partes = par.split(/\s+[–—-]\s+|;/)
      const dn = lerData(partes[0]); if (dn && /\d/.test(partes[0])) { add('nascimento', dataTxt(dn), pg.n); const loc = /^\s*([A-ZÀ-Ý][^,;()\d]{2,60}?)(?:,\s*([A-ZÀ-Ý][^,;()\d]{1,40}?))?,\s*\d/.exec(partes[0]); if (loc) add('local', loc[1].trim() + (loc[2] && !/^(SP|RJ|MG)$/.test(loc[2]) ? `, ${loc[2].trim()}` : ''), pg.n) }
      if (partes[1]) { const dm = lerData(partes[1]); if (dm) add('morte', dataTxt(dm), pg.n) }
    }
    for (const f of fs) {
      const fn = nrm(f), sobre = ent.some((w) => fn.includes(w.slice(0, Math.max(3, w.length - 1)))) || /^(ele|ela)\b/i.test(f)
      let m: RegExpExecArray | null
      if (/\bnasc(eu|ido|ida)\b/i.test(f) && sobre) {
        const d = lerData(f); if (d && (d.d || /nasceu em \d{4}|em \d{4}/i.test(f))) add('nascimento', dataTxt(d), pg.n)
        if ((m = /\bnasc(?:eu|ido|ida)\s+(?:em|na cidade de|no munic[ií]pio de)\s+([A-ZÀ-Ý][\wÀ-ÿ'.-]+(?:\s+(?:d[aoe]s?\s+)?[A-ZÀ-Ý][\wÀ-ÿ'.-]+){0,4})/.exec(f))) add('local', m[1], pg.n)
      }
      if (/\b(morreu|faleceu|morte)\b/i.test(f) && sobre) { const d = lerData(f); if (d && d.d) add('morte', dataTxt(d), pg.n) }
      if (sobre && (m = PROF.exec(f)) && OCUP.test(m[1]) && !/\bfilh[oa]\b/i.test(m[1])) add('profissao', m[1].replace(/\s+(brasileir[oa]s?|portugu[eê]s[a]?)$/i, '').trim(), pg.n)
      if (sobre && CONHECIDO.test(f)) add('conhecido', f, pg.n)
      if (sobre && EMPRESA.test(f) && !/\bnasc(eu|ido)\b/i.test(f)) add('empresas', f, pg.n)
      if (sobre && RELACAO.test(f)) add('relacoes', f, pg.n)
      const ano = /\b(19[5-9]\d|20[0-3]\d)\b/.exec(f)
      if (ano && sobre && CARREIRA.test(f) && !/\bnasc(eu|ido|ida)\b/i.test(f)) add('trajetoria', f, pg.n, Number(ano[1]))
    }
  }
  // limites (mais apoiados primeiro) e trajetória em ordem cronológica
  const porTipo = (t: string, max: number) => out.filter((f) => f.tipo === t).sort((a, b) => b.fontes.length - a.fontes.length).slice(0, max)
  const final = [...porTipo('nome', 1), ...['nascimento', 'local', 'morte', 'profissao'].flatMap((t) => porTipo(t, 3)), ...porTipo('conhecido', 3), ...porTipo('empresas', 4), ...porTipo('relacoes', 4), ...porTipo('trajetoria', 8).sort((a, b) => (a.ano || 0) - (b.ano || 0))]
  // divergência: o mesmo atributo com valores diferentes em fontes diferentes (data, local) — nenhum vira "certo"
  const res: Fato[] = []
  for (const t of ['nascimento', 'local', 'morte']) {
    const vs = final.filter((f) => f.tipo === t)
    const distintos = vs.filter((v, i) => !vs.slice(0, i).some((w) => compativelValor(t, w.valor, v.valor)))
    if (distintos.length >= 2) res.push({ tipo: 'divergencia', valor: `${ROT[t].toLowerCase()} — ${distintos.map((v) => `${v.valor} ${v.fontes.map((n) => `[${n}]`).join('')}`).join(' × ')}`, fontes: [...new Set(distintos.flatMap((v) => v.fontes))] })
  }
  const semDiv = final.filter((f) => !(['nascimento', 'local', 'morte'].includes(f.tipo) && res.some((d) => d.valor.startsWith(ROT[f.tipo].toLowerCase()))))
  // mesma data com e sem dia ("1986" e "30 de março de 1986"): fica a completa, somando as fontes
  for (const t of ['nascimento', 'morte']) { const vs = semDiv.filter((f) => f.tipo === t); const comp = vs.find((v) => /de/.test(v.valor)); if (comp) for (const v of vs) if (v !== comp && compativelValor(t, comp.valor, v.valor)) { comp.fontes = [...new Set([...comp.fontes, ...v.fontes])]; semDiv.splice(semDiv.indexOf(v), 1) } }
  return [...semDiv.filter((f, i, a) => !(['nascimento', 'local', 'morte', 'nome'].includes(f.tipo) && a.findIndex((g) => g.tipo === f.tipo) !== i)), ...res]
}
function compativelValor(t: string, a: string, b: string) {
  if (t === 'local') return nrm(a).split(',')[0].trim() === nrm(b).split(',')[0].trim()
  const x = lerData(a), y = lerData(b); if (!x || !y) return nrm(a) === nrm(b)
  return x.a === y.a && (!x.d || !y.d || (x.d === y.d && x.m === y.m))
}
export function secao(fatos: Fato[]): string {
  if (!fatos.length) return ''
  return `${SECAO}\n${fatos.map((f) => `- ${ROT[f.tipo]}${f.tipo === 'trajetoria' && f.ano ? ` (${f.ano})` : ''}: ${f.valor} ${f.fontes.sort((a, b) => a - b).map((n) => `[${n}]`).join('')}`).join('\n')}`
}

/* ---------- leitura (na pergunta) ---------- */
/** Fatos da seção do conteúdo ATUAL do conhecimento (o que o administrador revisou). null = conhecimento sem a seção. */
export function lerSecao(conteudo: string): Fato[] | null {
  const i = String(conteudo || '').indexOf(SECAO); if (i < 0) return null
  const out: Fato[] = []
  for (const l of String(conteudo).slice(i + SECAO.length).split('\n')) {
    const m = /^\s*-\s*([^:(]+?)(?:\s*\((\d{4})\))?:\s*(.+?)\s*((?:\[\d+\])*)\s*$/.exec(l); if (!m) { if (l.trim() && !/^\s*-/.test(l)) break; continue }
    const tipo = TIPO_DE_ROT.get(nrm(m[1].trim())); if (!tipo) continue
    out.push({ tipo, valor: m[3].trim(), fontes: [...m[4].matchAll(/\[(\d+)\]/g)].map((x) => Number(x[1])), ...(m[2] ? { ano: Number(m[2]) } : {}) })
  }
  return out
}
export type IntencaoFato = 'idade' | 'idade_em' | 'nascimento' | 'local' | 'profissao' | 'nome' | 'trajetoria' | 'empresas' | 'conhecido' | 'historia' | 'relacoes' | 'nao_confirmado' | 'tempo_carreira'
export function intencao(pergunta: string): IntencaoFato | null {
  const t = nrm(pergunta)
  if (/\b(nao (foram |estao |esta |foi )?confirmad|nao confirmad|ainda nao (se )?sabe|incert|divergen|duvidos|nao (tem|ha) certeza|sem confirmacao)/.test(t)) return 'nao_confirmado'
  if (/\bquantos anos\b.*\b(tinha|teria)\b.*\b(19|20)\d\d\b/.test(t)) return 'idade_em'
  if (/\b(ha quanto tempo|quanto tempo (de carreira|ele atua|ela atua|atua)|desde quando (ele |ela )?(atua|trabalha))\b/.test(t)) return 'tempo_carreira'
  if (/\b(quantos anos|qual (e |a )?(a )?idade|idade d[eoa]|tem que idade|quantos anos tem)\b/.test(t)) return 'idade'
  if (/\b(em que ano|que ano|qual (o |e o )?ano|ano de nascimento|data de nascimento|quando (ele |ela )?nasceu|quando e o aniversario|aniversario|dia (que|em que) nasceu)\b/.test(t)) return 'nascimento'
  if (/\b(onde (ele |ela )?nasceu|natural de onde|cidade natal|de onde (ele |ela )?(e|vem)|qual (a )?cidade (onde|em que) nasceu|nasceu onde|nasceu em que cidade)\b/.test(t)) return 'local'
  if (/\b(nome (verdadeiro|completo|real|de batismo|de registro)|como (ele |ela )?se chama de verdade)\b/.test(t)) return 'nome'
  if (/\b(como\b.{0,60}\b(ficou|se tornou|virou) (conhecid|famos)|por que (ele |ela )?(e|ficou|se tornou) (conhecid|famos)|(conhecid|famos)[oa] (por|pelo|pela|como)|o que (o |a )?(tornou|fez) (ele |ela )?famos)/.test(t)) return 'conhecido'
  if (/\b(empresa|empresas|negocio|negocios|marca|marcas|socio|socia|fundou|empreend|investimento|investe)\b/.test(t)) return 'empresas'
  if (/\b(trajetoria|carreira|o que (ele |ela )?(ja )?fez|principais (trabalhos|feitos)|percurso profissional)\b/.test(t)) return 'trajetoria'
  if (/\b(profissao|profissional|o que (ele |ela )?faz|com o que (ele |ela )?trabalha|trabalha com|ocupacao|qual (e )?(o )?trabalho|e (ator|cantor|empresario|piloto|jogador)\b)/.test(t)) return 'profissao'
  if (/\b(casad|esposa|marido|namorad|filhos?|filhas?|pais|pai|mae|irmao|irma|familia|parentes?)\b/.test(t)) return 'relacoes'
  if (/\b(historia|biografia|vida d[eoa]|conte (sobre|a historia))\b/.test(t)) return 'historia'
  return null
}
function hojeBr() { const d = new Date(Date.now() - 3 * 3600_000); return { a: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() } }
export function idade(n: Data, ate?: { a: number; m?: number; d?: number }): { min: number; max: number } {
  const h = ate || hojeBr()
  if (!n.d || !n.m || !h.m || !h.d) return { min: h.a - n.a - 1, max: h.a - n.a }
  const v = h.a - n.a - ((h.m < n.m || (h.m === n.m && h.d < n.d)) ? 1 : 0); return { min: v, max: v }
}
const lista = (xs: string[]) => xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} e ${xs[xs.length - 1]}`
const frase = (s: string) => { const x = s.trim(); return /[.!?…]$/.test(x) ? x : x + '.' }
/** Resposta só com os fatos que respondem à pergunta. null = a pergunta não é de um fato específico (segue o fluxo normal). */
export function responder(pergunta: string, nome: string, fatos: Fato[], o: { pendente?: boolean } = {}): string | null {
  const it = intencao(pergunta); if (!it) return null
  const de = (t: string) => fatos.filter((f) => f.tipo === t)
  const nasc = de('nascimento')[0], morte = de('morte')[0], div = de('divergencia')
  const nao = (o2: string) => `Não tenho ${o2} de ${nome} confirmad${/^a |^as /.test(o2) ? 'a' : 'o'} nas fontes estudadas.`
  const ressalva = o.pendente ? ' (segundo a pesquisa feita agora, ainda não revisada)' : ''
  const divDe = (r: string) => div.find((d) => d.valor.startsWith(r))
  let txt = ''
  switch (it) {
    case 'idade': case 'idade_em': {
      const dv = divDe('nascimento'); if (dv) { txt = `As fontes divergem sobre a data de nascimento de ${nome} (${dv.valor.replace(/^nascimento — /, '')}), então não dá para afirmar a idade com segurança.`; break }
      if (!nasc) { txt = `Não tenho a data de nascimento de ${nome} confirmada nas fontes estudadas, então não consigo dizer a idade sem inventar.`; break }
      const dn = lerData(nasc.valor)!
      if (it === 'idade_em') { const ano = Number(/\b(19|20)\d\d\b/.exec(nrm(pergunta).replace(/.*(tinha|teria)/, ''))?.[0]); const i = idade(dn, { a: ano }); txt = ano < dn.a ? `${nome} ainda não tinha nascido em ${ano} (nasceu em ${dataTxt(dn)}).` : `Em ${ano}, ${nome} tinha ${i.min === i.max ? i.min : `${i.min} ou ${i.max}`} anos (nasceu em ${dataTxt(dn)}).`; break }
      if (morte) { const dm = lerData(morte.valor)!, i = idade(dn, dm); txt = `${nome} morreu em ${dataTxt(dm)}, aos ${i.min === i.max ? i.min : `${i.min} ou ${i.max}`} anos (nasceu em ${dataTxt(dn)}).`; break }
      const i = idade(dn); txt = `${nome} tem ${i.min === i.max ? i.min : `${i.min} ou ${i.max}`} anos — nasceu em ${dataTxt(dn)}${i.min === i.max ? '' : ' (sem o dia exato, a idade pode variar em um ano)'}.`; break
    }
    case 'nascimento': { const dv = divDe('nascimento'); txt = dv ? `As fontes divergem sobre o nascimento de ${nome}: ${dv.valor.replace(/^nascimento — /, '')}.` : nasc ? `${nome} nasceu em ${nasc.valor}${de('local')[0] ? `, em ${de('local')[0].valor}` : ''}.` : nao('a data de nascimento'); break }
    case 'local': { const dv = divDe('local de nascimento'); const l = de('local')[0]; txt = dv ? `As fontes divergem sobre onde ${nome} nasceu: ${dv.valor.replace(/^local de nascimento — /, '')}.` : l ? `${nome} nasceu em ${l.valor}${nasc ? `, em ${nasc.valor}` : ''}.` : nao('o local de nascimento'); break }
    case 'nome': { const n = de('nome')[0]; txt = n ? `O nome completo é ${n.valor}.` : nao('o nome completo'); break }
    case 'profissao': { const p = de('profissao'); txt = p.length ? `${nome} é ${p[0].valor}.` : nao('a profissão'); break }
    case 'conhecido': { const c = de('conhecido'); txt = c.length ? c.slice(0, 2).map((x) => frase(x.valor)).join(' ') : nao('como ficou conhecido'); break }
    case 'empresas': { const e = de('empresas'); txt = e.length ? e.slice(0, 3).map((x) => frase(x.valor)).join(' ') : `Não encontrei empresas ou negócios de ${nome} confirmados nas fontes estudadas.`; break }
    case 'relacoes': { const r = de('relacoes'); txt = r.length ? r.slice(0, 3).map((x) => frase(x.valor)).join(' ') : `Não encontrei informações confirmadas sobre a família ou relações de ${nome} nas fontes estudadas.`; break }
    case 'trajetoria': { const t = de('trajetoria'); txt = t.length ? `Trajetória de ${nome}:\n${t.map((x) => `- ${x.ano ? x.ano + ': ' : ''}${frase(x.valor)}`).join('\n')}` : nao('a trajetória profissional'); break }
    case 'tempo_carreira': { const t = de('trajetoria').filter((x) => x.ano); if (!t.length) { txt = `Não tenho o início da carreira de ${nome} confirmado nas fontes estudadas.`; break } const ini = Math.min(...t.map((x) => x.ano!)), h = hojeBr().a; txt = `Pelo registro mais antigo encontrado (${ini}), ${nome} atua há cerca de ${h - ini} anos — primeiro marco: ${frase(t.find((x) => x.ano === ini)!.valor)}`; break }
    case 'historia': {
      const partes: string[] = []
      if (nasc) partes.push(`${nome} nasceu em ${nasc.valor}${de('local')[0] ? `, em ${de('local')[0].valor}` : ''}.`)
      if (de('profissao')[0]) partes.push(`É ${de('profissao')[0].valor}.`)
      if (de('conhecido')[0]) partes.push(frase(de('conhecido')[0].valor))
      const t = de('trajetoria'); if (t.length) partes.push(`Marcos da trajetória:\n${t.slice(0, 6).map((x) => `- ${x.ano ? x.ano + ': ' : ''}${frase(x.valor)}`).join('\n')}`)
      if (!partes.length) return null
      txt = partes.join(' ').replace(/ Marcos/, '\n\nMarcos'); break
    }
    case 'nao_confirmado': {
      const uma = fatos.filter((f) => f.tipo !== 'divergencia' && f.fontes.length <= 1), fontes = new Set(fatos.flatMap((f) => f.fontes))
      if (!div.length && !uma.length) { txt = `Todas as informações guardadas sobre ${nome} foram encontradas em mais de uma fonte.`; break }
      const ls: string[] = []
      for (const d of div) ls.push(`- Divergência: ${d.valor}`)
      if (fontes.size <= 1) ls.push(`- Tudo o que foi guardado sobre ${nome} vem de uma única fonte; nada foi confirmado por uma segunda fonte.`)
      else for (const f of uma.slice(0, 8)) ls.push(`- ${ROT[f.tipo]}${f.tipo === 'trajetoria' && f.ano ? ` (${f.ano})` : ''}: ${f.valor} — só uma fonte`)
      txt = `O que ainda não está confirmado sobre ${nome}:\n${ls.join('\n')}`; break
    }
  }
  if (!txt) return null
  if (o.pendente) txt = /\n/.test(txt) ? txt + '\n\n(Segundo a pesquisa feita agora, ainda não revisada pelo administrador.)' : txt.replace(/\.$/, '') + ressalva + '.'
  return txt
}
