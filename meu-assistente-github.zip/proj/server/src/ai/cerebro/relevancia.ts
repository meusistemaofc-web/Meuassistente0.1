// Cérebro do Chat — relevância das fontes e apresentação das fontes na resposta.
//
// 1. Relevância (antes de usar qualquer fonte): o assunto da pergunta é reduzido ao seu NÚCLEO (termos que identificam o
//    assunto, sem palavras genéricas como "história", "significado", "funciona") e aos NOMES citados ("Santos Dumont",
//    "TCP"). Um resultado de busca só é lido se o título (ou título + resumo) cobre o núcleo e traz os nomes; uma página
//    lida só é usada se o título e a abertura do texto tratam do assunto — páginas de desambiguação, listas e conteúdo
//    curto ficam de fora. Palavras parecidas sozinhas não bastam.
// 2. Frases úteis: só frases completas (começo e fim de frase, sem restos de menu, tabela, link ou referência) entram na
//    síntese; frases que começam com pronome ("Ele…", "Essa…") só entram junto da frase anterior, para não ficarem soltas.
// 3. Fontes na resposta: o corpo da resposta não leva URLs, domínios, "Fonte:", "Segundo <site>" nem listas de
//    referências — as fontes REALMENTE usadas vão num marcador ⟦src:…⟧ que o app mostra como ícones clicáveis junto do
//    horário. O marcador da IA com pesquisa (Gemini) leva um código do processo; marcadores escritos por terceiros
//    (texto de páginas, instruções injetadas) são descartados.
import { randomBytes } from 'node:crypto'
import { termos } from '../semantica.js'
import * as T from './texto.js'

/* ---------- 1. núcleo do assunto e nomes ---------- */
const INTERROGATIVA = /^\s*(o que (é|são|significa|foi|era)|o que|que é|como (funciona(m)?|surgiu|se faz|é feito|é feita|fazer)|qual (é|foi|era)|quais (são|foram)|qual|quais|quem (é|foi|são|era|inventou|criou|descobriu|escreveu|pintou|fundou)|quem|quando (foi|é|aconteceu|surgiu)|quando|onde (fica|é|nasceu|morreu)|onde|por que|porque|pra que serve|para que serve|explique|defina|significado de)\s+((o|a|os|as|um|uma)\s+)?/i
const GENERICOS = new Set(termos('história historia origem origens significado significa conceito definição definicao funciona funcionamento exemplo exemplos importância importancia principal principais característica características caracteristica caracteristicas tipo tipos vida biografia surgiu surgimento criado criada criou inventou inventor descobriu quem quando onde porque serve servem usado usada uso explicação explicacao resumo sobre coisa coisas forma formas modo maneira fica ficou aconteceu nasceu morreu feito feita fazer faço faco faz fazem fiz fazendo posso pode podem consigo preciso devo tenho tem ter existe existem'))
const PRONOMES = /^(ele|ela|eles|elas|isso|isto|esse|essa|esses|essas|este|esta|estes|estas|tal|tais|lá|la|também|tambem|além disso|alem disso|no entanto|porém|porem|assim|dessa forma|desse modo|nesse|nessa|neste|nesta|seu|sua|seus|suas)\b/i
/** Termos (radicais) que identificam o assunto da pergunta. */
export function nucleo(pergunta: string): string[] {
  const s = String(pergunta || '').trim().replace(/[?!.\s]+$/, '').replace(INTERROGATIVA, '')
  const t = [...new Set(termos(s))], n = t.filter((x) => !GENERICOS.has(x))
  return n.length ? n : t
}
/** Nomes citados na pergunta (sequências com maiúscula fora do início e siglas): cada nome é uma lista de radicais. */
export function nomes(pergunta: string): string[][] {
  const pal = String(pergunta || '').replace(/[?!.,;:()"“”]/g, ' ').split(/\s+/).filter(Boolean), out: string[][] = []
  let atual: string[] = []
  const fecha = () => { const t = termos(atual.join(' ')); if (t.length) out.push(t); atual = [] }
  pal.forEach((w, i) => {
    const sigla = /^[A-Z0-9]{2,}$/.test(w) && /[A-Z]/.test(w), maiusc = /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]+/.test(w)
    // 1ª palavra da frase só é nome quando abre um nome composto ("Santos Dumont", "Proclamação da República")
    const M = (x?: string) => !!x && /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]+/.test(x)
    const abreNome = i === 0 && (M(pal[1]) || (/^(da|de|do|das|dos)$/.test(pal[1] || '') && M(pal[2])))
    if ((maiusc && (i > 0 || abreNome)) || sigla) { atual.push(w); return }
    if (atual.length && /^(da|de|do|das|dos|e|di|von|van)$/.test(w)) { atual.push(w); return }
    if (atual.length) fecha()
  })
  if (atual.length) fecha()
  return out
}
/** ENTIDADE da pergunta (25/11): os nomes com maiúscula e, quando o usuário escreve tudo em minúsculas ("quem é felipe
 *  titto"), o sujeito de uma pergunta sobre alguém/algo nomeado ("quem é…", "quantos anos tem…", "onde nasceu…", "fale
 *  sobre…") — antes, sem maiúscula não havia nome, e meia correspondência ("Felipe") bastava: a pesquisa sobre "Felipe
 *  Tito/Titto" leu e respondeu sobre "Felipe Giaffone". Sujeito com artigo ("quem é o presidente…") é descrição, não nome. */
const SUJEITO = /^\s*(?:me\s+)?(?:fal[ae]|conte|conta|diga|explique)?\s*(?:(?:um\s+pouco\s+)?sobre\s+|(?:quem\s+(?:é|e|foi|era)|quem\s+s[aã]o|biografia\s+d[eoa]|hist[oó]ria\s+d[eoa]|vida\s+d[eoa]|idade\s+d[eoa]|quantos\s+anos\s+(?:tem|tinha)|qual\s+(?:é\s+)?a\s+idade\s+d[eoa]|onde\s+nasceu|quando\s+nasceu|em\s+que\s+ano\s+nasceu|qual\s+(?:é\s+)?a\s+profiss[aã]o\s+d[eoa]|o\s+que\s+faz|com\s+o\s+que\s+trabalha|como\s+(?:ficou|se\s+tornou)\s+(?:conhecid[oa]|famos[oa])|qual\s+(?:é\s+)?(?:a\s+)?trajet[oó]ria\s+d[eoa]|quais\s+(?:s[aã]o\s+)?as\s+empresas\s+d[eoa]|nome\s+(?:completo|verdadeiro)\s+d[eoa])\s+)(.+?)\s*[?!.]*\s*$/i
const ARTIGO = /^(o|a|os|as|um|uma|uns|umas|esse|essa|este|esta|aquele|aquela|meu|minha|seu|sua)\s/i
const PALAVRA_COMUM = /^(ele|ela|eles|elas|isso|isto|voc[eê]|vc|eu|n[oó]s|algu[eé]m|ningu[eé]m|tudo|nada|hoje|agora|mais|melhor|maior|primeiro|primeira|[uú]ltimo|[uú]ltima)$/i
/** Sujeito nomeado de uma pergunta em minúsculas ("quem é felipe titto" → "felipe titto"); '' quando não há. */
export function sujeito(pergunta: string): string {
  const m = SUJEITO.exec(String(pergunta || '').replace(/\s+/g, ' ')); if (!m) return ''
  const suj = m[1].replace(/[,;].*$/, '').replace(/\s+(e|ou)\s+(qual|quando|onde|como|quantos|o que|por que)\b.*$/i, '').trim()
  if (ARTIGO.test(suj)) return ''
  const pal = suj.split(/\s+/).filter(Boolean)
  return !pal.length || pal.length > 4 || pal.some((w) => PALAVRA_COMUM.test(w)) ? '' : suj
}
export function entidades(pergunta: string): string[][] {
  const ns = nomes(pergunta); if (ns.length) return ns
  const suj = sujeito(pergunta); if (!suj) return []
  const t = termos(suj); return t.length ? [t] : []
}
/** Nome da entidade para a BUSCA e o estudo, com maiúsculas ("felipe titto" → "Felipe Titto"), para que toda a cadeia
 *  (seleção de resultados, leitura, validação, fatos, título do conhecimento) trate o assunto como o nome pedido. */
export function nomeDaEntidade(pergunta: string): string {
  if (nomes(pergunta).length) return ''
  const suj = sujeito(pergunta); if (!suj) return ''
  return suj.split(/\s+/).map((w, i) => (/^(da|de|do|das|dos|e|di|von|van)$/i.test(w) && i > 0 ? w.toLowerCase() : w.charAt(0).toUpperCase() + w.slice(1))).join(' ')
}
/** Termo do NOME casa com o texto? Igual ou com a mesma raiz (0,85, como antes) ou com UMA letra de diferença em nomes
 *  de 4+ letras e mesma inicial (erro de digitação: "Tito" × "Titto") — marcado como grafia aproximada. */
const dist1 = (a: string, b: string) => { if (a === b) return true; if (Math.abs(a.length - b.length) > 1) return false; let i = 0, j = 0, d = 0; while (i < a.length && j < b.length) { if (a[i] === b[j]) { i++; j++; continue } if (++d > 1) return false; if (a.length > b.length) i++; else if (b.length > a.length) j++; else { i++; j++ } } return d + (a.length - i) + (b.length - j) <= 1 }
export function casaNome(x: string, t: Set<string>): { nota: number; aprox: boolean } {
  const c = T.casaTermo(x, t); if (c >= 0.85) return { nota: c, aprox: false }
  if (x.length >= 4) for (const d of t) if (d.length >= 4 && d[0] === x[0] && dist1(x, d)) return { nota: 0.85, aprox: true }
  return { nota: c, aprox: false }
}
const media = (n: string[], texto: string) => { if (!n.length) return 0; const t = new Set(termos(texto)); return n.reduce((a, x) => a + T.casaTermo(x, t), 0) / n.length }
const temNomes = (ns: string[][], texto: string) => { const t = new Set(termos(texto)); return ns.every((g) => g.every((x) => casaNome(x, t).nota >= 0.85)) }
/** O texto só cita a entidade com grafia aproximada (nenhuma forma exata)? */
export function grafiaAproximada(pergunta: string, texto: string) { const ns = entidades(pergunta); if (!ns.length) return false; const t = new Set(termos(texto)); return ns.some((g) => g.some((x) => casaNome(x, t).aprox)) }
/** A cobertura do NÚCLEO conta a entidade inteira: com nome, cada termo do nome precisa estar (com tolerância a 1 letra). */
const mediaEnt = (pergunta: string, n: string[], texto: string) => { const ns = entidades(pergunta); if (!ns.length) return media(n, texto); const t = new Set(termos(texto)), nomeT = new Set(ns.flat()); return n.reduce((a, x) => a + (nomeT.has(x) ? casaNome(x, t).nota : T.casaTermo(x, t)), 0) / Math.max(1, n.length) }
const DESAMB = /\(desambigua[cç][aã]o\)|pode(m)? (se )?referir(-se)? a|may refer to|p[aá]gina de desambigua|lista de\b|^lista\b/i
export interface Nota { aceito: boolean; nota: number; motivo: string; titulo: number; conteudo: number }
/** Resultado de busca (título + resumo): vale a leitura da página? */
export function relevanciaResultado(pergunta: string, titulo: string, resumo: string): Nota {
  const n = nucleo(pergunta), ns = entidades(pergunta)
  const ct = mediaEnt(pergunta, n, titulo), ca = mediaEnt(pergunta, n, `${titulo} ${resumo}`), nota = Math.round((0.6 * ct + 0.4 * ca) * 1000) / 1000
  if (DESAMB.test(`${titulo} ${String(resumo).slice(0, 200)}`)) return { aceito: false, nota, motivo: 'desambiguação ou lista', titulo: ct, conteudo: ca }
  if (ns.length && !temNomes(ns, `${titulo} ${resumo}`)) return { aceito: false, nota, motivo: 'não cita o nome perguntado', titulo: ct, conteudo: ca }
  const aceito = ct >= 0.5 || ca >= 0.75
  return { aceito, nota, motivo: aceito ? 'compatível' : 'título e resumo não tratam do assunto', titulo: ct, conteudo: ca }
}
/** Página lida: o título e a abertura do texto tratam do assunto da pergunta? */
export function relevanciaPagina(pergunta: string, titulo: string, texto: string): Nota {
  const n = nucleo(pergunta), ns = entidades(pergunta), lead = String(texto || '').slice(0, 2500)
  const ct = mediaEnt(pergunta, n, titulo), cl = mediaEnt(pergunta, n, lead), nota = Math.round((0.5 * ct + 0.5 * cl) * 1000) / 1000
  if (String(texto || '').replace(/\s+/g, ' ').length < 200) return { aceito: false, nota, motivo: 'conteúdo insuficiente', titulo: ct, conteudo: cl }
  if (DESAMB.test(`${titulo} ${lead.slice(0, 400)}`)) return { aceito: false, nota, motivo: 'desambiguação ou lista', titulo: ct, conteudo: cl }
  if (ns.length && !temNomes(ns, `${titulo} ${lead}`)) return { aceito: false, nota, motivo: 'não trata do nome perguntado', titulo: ct, conteudo: cl }
  const aceito = (ct >= 0.5 && cl >= 0.5) || cl >= 0.75
  return { aceito, nota, motivo: aceito ? 'compatível' : 'o texto não trata do assunto', titulo: ct, conteudo: cl }
}
/** Conhecimento da biblioteca (título + trecho) compatível com a pergunta? Evita usar um conhecimento só porque divide
 *  palavras com ela (ex.: "Santos Dumont" × "Santos Futebol Clube"). */
export function compativel(pergunta: string, titulo: string, trecho: string) {
  const n = nucleo(pergunta), ns = entidades(pergunta), txt = `${titulo} ${trecho}`
  if (ns.length) return temNomes(ns, txt) // nome citado: precisa estar no conhecimento
  return !n.length || media(n, txt) >= 0.34 // sem nome: a busca da biblioteca já pontua; aqui só barra o que não trata do assunto
}
/** O texto (resposta guardada, conhecimento) cita os nomes que a pergunta cita? Sem nome na pergunta, não há o que barrar. */
export function citaNomes(pergunta: string, texto: string) { const ns = entidades(pergunta); return !ns.length || temNomes(ns, texto) }
/** Duas perguntas tratam do MESMO assunto? (memória do Cérebro: "qual a capital da França" não responde "qual a capital
 *  da Austrália", por mais parecidas que sejam as letras). */
export function mesmoAssunto(a: string, b: string) { const na = nucleo(a), nb = nucleo(b); if (!na.length || !nb.length) return true; return media(na, b) >= 0.75 && media(nb, a) >= 0.75 }
/** Quanto uma frase trata do núcleo da pergunta (0 a 1). */
export const coberturaNucleo = (pergunta: string, frase: string) => media(nucleo(pergunta), frase)

/* ---------- 2. frases úteis e resposta natural ---------- */
const LIXO = /https?:\/\/|www\.|##|\||\{|\}|\[editar|ver também|refer[eê]ncias|cookies?\b|inscreva-se|clique aqui|leia (mais|tamb)|compartilh|todos os direitos|newsletter|publicidade|^\W*(menu|início|inicio|home)\b/i
export function fraseUtil(f: string) {
  const s = String(f || '').trim()
  if (s.length < 40 || s.length > 420) return false
  if (!/^[A-ZÁÉÍÓÚÂÊÔÃÕÇ0-9"“(]/.test(s) || !/[.!?…]["”)]?$/.test(s)) return false
  if (LIXO.test(s) || T.pareceInstrucao(s)) return false
  const dig = (s.match(/\d/g) || []).length; if (dig / s.length > 0.25) return false
  return true
}
export const comecaComPronome = (f: string) => PRONOMES.test(String(f || '').trim())
const linhasDeConteudo = (t: string) => String(t || '').split('\n').filter((l) => !/^\s*(Fontes:|Atenção —|\[\d+\]\s.*https?:\/\/)/.test(l.trim()))
/** Resposta curta e natural a partir de um conhecimento: as frases que tratam do assunto, na ordem original e completas
 *  (frase com pronome leva junto a anterior). null quando nenhuma frase trata do assunto. */
export function respostaNatural(pergunta: string, texto: string, max = 3): string | null {
  const fs = linhasDeConteudo(texto).flatMap((l) => T.frases(l.replace(/^\s*[-•*]\s*/, '').replace(/\s*\[(?:C|W|B)?\d+\]/g, '').trim())).map((f) => f.trim()).filter((f) => f.length > 25 && !LIXO.test(f) && !T.pareceInstrucao(f))
  if (!fs.length) return null
  const notas = fs.map((f, i) => ({ f, i, c: coberturaNucleo(pergunta, f) + (i === 0 ? 0.05 : 0) }))
  const uteis = notas.filter((x) => x.c > 0.05)
  if (!uteis.length) return null
  const sel = new Set(uteis.sort((a, b) => b.c - a.c || a.i - b.i).slice(0, max).map((x) => x.i))
  for (const i of [...sel]) if (comecaComPronome(fs[i]) && i > 0 && !sel.has(i - 1)) sel.add(i - 1)
  const out = [...sel].sort((a, b) => a - b).map((i) => fs[i]).join(' ').replace(/\s+/g, ' ').trim()
  return out ? out.charAt(0).toUpperCase() + out.slice(1) : null
}
export const NAO_CONFIRMADO = 'Não encontrei uma fonte confiável que responda isso com segurança, então prefiro não arriscar uma resposta. Se quiser, reformule a pergunta ou me dê mais detalhes do que procura.'

/* ---------- 3. fontes fora do corpo da resposta ---------- */
/** Código deste processo: só marcadores de fontes gerados pelo próprio servidor (IA com pesquisa) são aceitos. */
export const NONCE = randomBytes(6).toString('hex')
export interface Fonte { url: string; dominio: string }
export const dominioDe = (url: string) => { try { return new URL(url).hostname.replace(/^www\./, '') } catch { return '' } }
const pareceDominio = (s: string) => /^[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(String(s || '').trim())
const esc = (s: string) => String(s).replace(/[|~⟧%]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase())
const desc = (s: string) => { try { return decodeURIComponent(s) } catch { return s } }
/** Marcador das fontes (máx. 4, sem repetir) — o app troca por ícones junto do horário. */
export function marcador(fs: Fonte[], nonce = ''): string {
  const vistos = new Set<string>(), ok = fs.filter((f) => /^https?:\/\//i.test(f.url) && f.dominio && !vistos.has(f.url) && vistos.add(f.url)).slice(0, 4)
  return ok.length ? `⟦src${nonce ? '#' + nonce : ''}:${ok.map((f) => `${esc(f.dominio)}~${esc(f.url)}`).join('|')}⟧` : ''
}
const lerMarcador = (v: string): Fonte[] => v.split('|').map((x) => { const [d, u] = x.split('~'); return { dominio: desc(d || ''), url: desc(u || '') } }).filter((f) => /^https?:\/\//i.test(f.url) && f.dominio)
/** Fontes vindas da IA com pesquisa (ex.: Gemini): título do resultado costuma ser o domínio; o link abre a página. */
export function fontesDaPesquisa(itens: { uri?: string; title?: string }[]): string {
  return marcador(itens.filter((w) => w?.uri).map((w) => ({ url: String(w.uri), dominio: pareceDominio(String(w.title || '')) ? String(w.title).replace(/^www\./, '').toLowerCase() : dominioDe(String(w.uri)) })), NONCE)
}
const REF_LINHA = /^\s*(?:[-•*]|\d+[.)]|\[\d+\])?\s*(?:\*\*)?[^\n]{0,160}?(?:https?:\/\/\S+|\b[a-z0-9-]+(?:\.[a-z0-9-]+)+\b)\s*(?:\*\*)?\s*$/i
const TITULO_FONTES = /^\s*(?:\*\*|__)?\s*(fontes?|refer[êe]ncias|saiba mais|links? (úteis|uteis)|para saber mais)\s*(?:\*\*|__)?\s*:?\s*(?:\*\*|__)?\s*$/i
const FONTE_INLINE = /^\s*(?:\*\*|__)?\s*fontes?\s*(?:\*\*|__)?\s*:\s*(.+)$/i
const DOM_RE = '(?:[a-z0-9-]+\\.)+[a-z]{2,}(?:\\/[^\\s,;:)]*)?'
/** Tira do corpo as fontes escritas como texto (URLs, domínios, "Fonte:", "Segundo <site>", lista de referências,
 *  marcas [C1]/[1]) e devolve as fontes do servidor que vieram no marcador assinado. */
export function limparFontes(texto: string, urlsConhecidas: string[] = []): { texto: string; fontes: Fonte[]; removeu: boolean } {
  let t = String(texto || ''), removeu = false
  const fontes: Fonte[] = []
  t = t.replace(/⟦src#([a-f0-9]+):([^⟧]*)⟧/g, (_m, n, v) => { removeu = true; if (n === NONCE) fontes.push(...lerMarcador(v)); return '' })
  t = t.replace(/⟦src:[^⟧]*⟧/g, () => { removeu = true; return '' }) // marcador sem o código do servidor: escrito por terceiros
  // blocos e linhas de fontes
  const out: string[] = []; let emBloco = false
  for (const l of t.split('\n')) {
    if (TITULO_FONTES.test(l)) { emBloco = true; removeu = true; continue }
    if (emBloco) { if (!l.trim() || REF_LINHA.test(l)) { continue } emBloco = false }
    if (FONTE_INLINE.test(l)) { removeu = true; continue }
    if (/^\s*(?:[-•*]\s*)?(?:<)?https?:\/\/\S+(?:>)?\s*$/.test(l)) { removeu = true; continue }
    out.push(l)
  }
  t = out.join('\n')
  // citações no meio do texto
  const antes = t
  t = t.replace(new RegExp(`\\s*\\((?:fontes?|via|ref\\.?)\\s*:?\\s*[^)]*\\)`, 'gi'), '')
  t = t.replace(new RegExp(`\\s*\\((?:https?:\\/\\/\\S+|${DOM_RE})\\)`, 'gi'), '')
  t = t.replace(new RegExp(`(^|[\\n.!?]\\s*|,\\s*)(segundo|de acordo com|conforme|consoante|fonte:?)\\s+(?:o\\s+site\\s+|a\\s+p[aá]gina\\s+|o\\s+portal\\s+|a\\s+)?(?:https?:\\/\\/)?${DOM_RE}\\s*[,:–-]?\\s*`, 'gi'), (_m, pre) => pre)
  for (const u of urlsConhecidas) if (u) t = t.split(u).join('')
  t = t.replace(/\s*\[(?:C|W|B)?\d+\]/g, '')
  if (t !== antes) removeu = true
  t = t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/[ \t]{2,}/g, ' ').replace(/\s+([,.;:!?])/g, '$1').trim()
  if (removeu && t) t = t.charAt(0).toUpperCase() + t.slice(1)
  return { texto: t, fontes, removeu }
}
