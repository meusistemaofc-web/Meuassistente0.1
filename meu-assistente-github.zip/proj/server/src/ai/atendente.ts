// ATENDENTE COMERCIAL dos agentes das empresas — camada LOCAL e determinística, antes da IA (rápida e sem inventar nada).
// Usa SÓ o catálogo real da empresa (o mesmo que o agente já recebe) e a conversa (as últimas mensagens que a tela envia):
//   buscar ...... "vocês têm camiseta?", "procuro um tênis", "quero ver bolos" → cards reais com foto, preço e variações
//   refinar ..... "na cor preta", "tem em M?", "de algodão", "até 50 reais", "o mais barato" → REFINA a busca anterior
//                 (não recomeça o atendimento); o que não existe é dito com clareza, com as opções que existem
//   dúvida ...... "quanto custa o bolo de pote?", "a camiseta tem em G?" → resposta com os dados cadastrados
//   adicionar ... "quero essa", "coloca 2 do primeiro no carrinho", "vou levar a preta P" → itens REAIS no carrinho da tela
//                 (a tela executa com o carrinho existente), com a variação certa; se faltar escolher, pergunta só isso
//   complemento . depois de adicionar, sugere no máximo 1 item que combina (sem insistir, sem inventar oferta)
// O que não for reconhecido aqui segue o caminho de sempre (atalhos de seção, Cérebro, IA com as ferramentas do agente).
import * as COL from './aprendizado-coletivo.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9,. ]/g, ' ').replace(/\s+/g, ' ').trim()
const sing = (w: string) => (w.length > 4 && /oes$/.test(w) ? w.slice(0, -3) + 'ao' : w.length > 4 && /aes$/.test(w) ? w.slice(0, -3) + 'ao' : w.length > 4 && /is$/.test(w) ? w.slice(0, -2) + 'l' : w.length > 3 && /s$/.test(w) ? w.slice(0, -1) : w)
function lev(a: string, b: string) { if (Math.abs(a.length - b.length) > 2) return 9; const d = [...Array(b.length + 1).keys()]; for (let i = 1; i <= a.length; i++) { let p = d[0]; d[0] = i; for (let j = 1; j <= b.length; j++) { const t = d[j]; d[j] = Math.min(d[j] + 1, d[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t } } return d[b.length] }
const casa = (w: string, v: string) => w === v || (w.length >= 4 && v.startsWith(w)) || (v.length >= 4 && w.startsWith(v) && w.length - v.length <= 2) || (w.length >= 5 && lev(w, v) <= 1) || (w.length >= 8 && lev(w, v) <= 2)
const brl = (n: number) => 'R$ ' + Number(n).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')

const CORES = ['preto', 'preta', 'branco', 'branca', 'azul', 'vermelho', 'vermelha', 'verde', 'amarelo', 'amarela', 'rosa', 'roxo', 'roxa', 'lilas', 'cinza', 'bege', 'marrom', 'laranja', 'dourado', 'dourada', 'prateado', 'prateada', 'nude', 'vinho', 'creme', 'caramelo', 'grafite', 'off white', 'colorido', 'colorida', 'estampado', 'estampada']
const corBase = (c: string) => nrm(c).replace(/a$/, 'o').replace(/^branc[oa]$/, 'branco').replace('preta', 'preto').replace('vermelha', 'vermelho').replace('amarela', 'amarelo').replace('roxa', 'roxo').replace('dourada', 'dourado').replace('prateada', 'prateado').replace('colorida', 'colorido').replace('estampada', 'estampado')
const TAM = /\b(?:tamanho|tam|numero|num)\s+([a-z0-9]{1,3})\b|\b(pp|p|m|g|gg|xg|xgg|eg|egg|u|unico)\b(?=\s|$|[,.!?])/
const MATERIAIS = ['algodao', 'couro', 'jeans', 'linho', 'seda', 'malha', 'poliester', 'la', 'veludo', 'sintetico', 'madeira', 'inox', 'vidro', 'plastico', 'ceramica', 'chocolate', 'morango', 'baunilha', 'limao', 'coco', 'integral', 'vegano', 'vegana', 'sem gluten', 'sem lactose', 'diet', 'zero']
const PRECO_MAX = /\b(?:ate|no maximo|menos de|abaixo de|por ate|maximo)\s*(?:r\$\s*)?(\d+(?:[.,]\d{1,2})?)\s*(?:reais|real|conto|contos)?\b/
const BARATO = /\b(mais barat[oa]s?|mais em conta|mais economic[oa]s?|menor preco|baratinh[oa]s?|barat[oa]s?)\b/
const CARO = /\b(mais car[oa]s?|maior preco|premium|melhor (?:qualidade|opcao))\b/
const ADICIONAR = /\b(adiciona|adicione|adicionar|coloca|coloque|colocar|bota|bote|poe|ponha|inclui|inclua|separa|separe|manda|mande|me (?:ve|da|manda)|quero (?:esse|essa|este|esta|ess[ea]s|o primeiro|a primeira|o segundo|a segunda|o ultimo|a ultima|levar|comprar|pedir|(?:o|a|um|uma) (?!ver\b|saber\b|olhar\b|conhecer\b))|vou (?:querer|levar|pedir)|pode (?:colocar|adicionar|separar|mandar|ser)|fech[ao]|levo|compro|no (?:meu )?carrinho)\b/
const BUSCAR = /\b(tem|tens|teria|voces tem|vcs tem|vende|vendem|trabalha com|trabalham com|procuro|procurando|to procurando|estou procurando|quero ver|queria ver|mostra|mostre|me mostra|quero|queria|gostaria|preciso de|precisava de|busco|opcoes de|modelos de|algum|alguma|uns|umas)\b/
const PRECO_Q = /\b(quanto (?:custa|e|sai|fica|ta|esta)|qual (?:o )?(?:preco|valor)|preco d[oae]|valor d[oae])\b/
const ORDINAL: [RegExp, number][] = [[/\b(primeir[oa]|1[ºo]?|um)\b/, 0], [/\b(segund[oa]|2[ºo]?)\b/, 1], [/\b(terceir[oa]|3[ºo]?)\b/, 2], [/\b(quart[oa]|4[ºo]?)\b/, 3], [/\b(ultim[oa])\b/, -1]]
const NUM_PAL: Record<string, number> = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10 }
const GENERICAS = new Set('de da do das dos e em no na nos nas um uma uns umas o a os as para pra pro com sem por que qual quais quanto quanta tem tens voces vcs voce vc ai la aqui isso esse essa este esta esses essas quero queria gostaria preciso precisava procuro busco mostra mostre me ver opcoes opcao modelo modelos algum alguma alguns algumas tipo coisa coisas produto produtos item itens loja catalogo cardapio menu tambem mais menos muito pouco bem bom boa oi ola obrigado obrigada por favor sim nao ok certo cor tamanho numero valor preco custa sai fica ate reais real barato barata caro cara favor gostei legal show top manda coloca adiciona carrinho levar vou pode pedido comprar'.split(' '))

export interface Variante { id: number; rotulo?: string; cor?: string; tamanho?: string; modelo?: string; atributos?: { nome: string; valor: string }[]; disponivel?: boolean; preco?: number; precoAplicado?: number }
export interface Item { id: number; nome: string; categoria?: string; descricao?: string; palavras?: string; tipo?: string; preco?: number; destaque?: any; variantes?: Variante[]; variacoes?: any[]; esgotado?: boolean; modoPreco?: string }
export interface Msg { role: 'user' | 'assistant'; content: string }
export interface Filtros { cores: string[]; tamanho: string | null; materiais: string[]; precoMax: number | null; ordem: 'barato' | 'caro' | null }
export interface Resultado { acao: 'mostrar' | 'adicionar' | 'responder'; reply: string; ids: number[]; carrinho?: { pid: number; vid: number | null; qtd: number }[]; intencao: string; contexto: { termos: string[]; filtros: Filtros } }

const precoDe = (p: Item) => Number(p.destaque?.preco ?? p.preco ?? 0)
const textoItem = (p: Item) => nrm([p.nome, p.categoria, p.descricao, p.palavras].join(' '))
function vocab(prods: Item[]) { const s = new Set<string>(); for (const p of prods) for (const w of nrm([p.nome, p.categoria, p.palavras].join(' ')).split(' ')) if (w.length >= 3 && !GENERICAS.has(w)) s.add(sing(w)); return s }
/** Termos de produto da mensagem (o que existe no vocabulário do catálogo, com tolerância a erro de digitação). */
function termosDe(txt: string, voc: Set<string>) { const out: string[] = []; for (const w0 of nrm(txt).split(' ')) { const w = sing(w0); if (w.length < 3 || GENERICAS.has(w) || CORES.includes(w0) || MATERIAIS.includes(w0)) continue; if ([...voc].some((v) => casa(w, v))) out.push(w) } return [...new Set(out)] }
function filtrosDe(txt: string): Filtros {
  const s = nrm(txt), f: Filtros = { cores: [], tamanho: null, materiais: [], precoMax: null, ordem: null }
  for (const c of CORES) if (new RegExp(`\\b${c}\\b`).test(s)) f.cores.push(corBase(c))
  const t = s.match(TAM); if (t && !/\b(um|uma)\b/.test(t[0])) f.tamanho = (t[1] || t[2] || '').toUpperCase()
  for (const m of MATERIAIS) if (new RegExp(`\\b${m}\\b`).test(s)) f.materiais.push(m)
  const pm = s.match(PRECO_MAX); if (pm) f.precoMax = Number(pm[1].replace(',', '.'))
  if (BARATO.test(s)) f.ordem = 'barato'; else if (CARO.test(s)) f.ordem = 'caro'
  return f
}
const temFiltro = (f: Filtros) => !!(f.cores.length || f.tamanho || f.materiais.length || f.precoMax != null || f.ordem)
const juntar = (a: Filtros, b: Filtros): Filtros => ({ cores: b.cores.length ? b.cores : a.cores, tamanho: b.tamanho || a.tamanho, materiais: [...new Set([...a.materiais, ...b.materiais])], precoMax: b.precoMax ?? a.precoMax, ordem: b.ordem || a.ordem })
const corDaVar = (v: Variante) => [v.cor, v.rotulo, ...(v.atributos || []).map((a) => a.valor)].map((x) => corBase(String(x || ''))).join(' ')
const tamDaVar = (v: Variante) => [v.tamanho, ...(v.atributos || []).filter((a) => /tam|numer/i.test(a.nome)).map((a) => a.valor), v.rotulo].map((x) => nrm(String(x || '')).toUpperCase())
function varCombina(v: Variante, f: Filtros) {
  if (v.disponivel === false) return false
  if (f.cores.length && !f.cores.some((c) => new RegExp(`\\b${c}\\b`).test(corDaVar(v)))) return false
  if (f.tamanho && !tamDaVar(v).some((t) => t === f.tamanho || t.split(/[\s/,]+/).includes(f.tamanho!))) return false
  return true
}
function combina(p: Item, f: Filtros) {
  const vs = (p.variantes || []).filter((v) => v.disponivel !== false)
  if ((f.cores.length || f.tamanho) && vs.length) { if (!vs.some((v) => varCombina(v, f))) return false }
  else if (f.cores.length && !f.cores.some((c) => textoItem(p).split(' ').map(corBase).includes(c))) return false
  else if (f.tamanho && !vs.length) return false
  if (f.materiais.length && !f.materiais.every((m) => textoItem(p).includes(m))) return false
  if (f.precoMax != null && precoDe(p) > f.precoMax + 1e-9) return false
  return true
}
function pontuar(p: Item, termos: string[]) { if (!termos.length) return 1; const ws = nrm([p.nome, p.categoria, p.palavras, p.descricao].join(' ')).split(' ').map(sing), nome = nrm(p.nome).split(' ').map(sing); let s = 0; for (const t of termos) { if (nome.some((w) => casa(t, w))) s += 2; else if (ws.some((w) => casa(t, w))) s += 1 } return s }
function buscar(prods: Item[], termos: string[], f: Filtros) {
  let l = prods.filter((p) => !p.esgotado).map((p) => ({ p, s: pontuar(p, termos) })).filter((x) => x.s > 0)
  const max = Math.max(0, ...l.map((x) => x.s)); if (termos.length > 1) l = l.filter((x) => x.s >= Math.min(max, termos.length)) // várias palavras: o que bate com todas primeiro
  const base = l.map((x) => x.p), fil = base.filter((p) => combina(p, f))
  if (f.ordem === 'barato') fil.sort((a, b) => precoDe(a) - precoDe(b)); else if (f.ordem === 'caro') fil.sort((a, b) => precoDe(b) - precoDe(a))
  else fil.sort((a, b) => pontuar(b, termos) - pontuar(a, termos) || a.id - b.id)
  return { base, fil }
}
/** Contexto da conversa: o que o cliente procura e as preferências que ele já disse (cor, tamanho, material, preço). */
export function contexto(msgs: Msg[], prods: Item[]) {
  const voc = vocab(prods); let termos: string[] = [], f: Filtros = { cores: [], tamanho: null, materiais: [], precoMax: null, ordem: null }
  for (const m of msgs.filter((x) => x.role === 'user').slice(-6, -1)) { const t = termosDe(m.content, voc); if (t.length) { termos = t; f = filtrosDe(m.content) } else f = juntar(f, filtrosDe(m.content)) }
  return { termos, filtros: f, voc }
}
/** Ids dos itens mostrados por último (cards) — guardados pela tela como "⟦ids:1,2,3⟧" no fim da mensagem do assistente. */
function mostradosPorUltimo(msgs: Msg[]): number[] { for (const m of [...msgs].reverse()) { if (m.role !== 'assistant') continue; const x = String(m.content).match(/⟦ids:([\d,]+)⟧/); if (x) return x[1].split(',').map(Number).filter(Boolean) } return [] }
const lista = (xs: string[]) => (xs.length <= 1 ? xs.join('') : xs.slice(0, -1).join(', ') + ' e ' + xs[xs.length - 1])
const opcoesDe = (p: Item) => (p.variantes || []).filter((v) => v.disponivel !== false).map((v) => v.rotulo || [v.cor, v.tamanho].filter(Boolean).join(' ')).filter(Boolean)
const resumoPreco = (p: Item) => { const d = p.destaque; if (p.tipo === 'servico' && p.modoPreco === 'orcamento') return 'sob orçamento'; if (!d) return brl(Number(p.preco || 0)); return `${d.aPartirDe ? 'a partir de ' : ''}${brl(d.preco)}${d.emOferta && d.precoNormal ? ` (em oferta, de ${brl(d.precoNormal)})` : ''}` }
function qtdDe(s: string) { const m = s.match(/\b(\d{1,2})\s*(?:x|un|unidades?|pecas?|do|da|dos|das|de)?\b/); if (m && Number(m[1]) > 0 && Number(m[1]) < 50 && !/r\$|reais/.test(s)) return Number(m[1]); for (const [w, n] of Object.entries(NUM_PAL)) if (new RegExp(`\\b${w}\\b(?!\\s+(?:dessas?|desses?)?\\s*(?:mais|menos))`).test(s) && n > 1) return n; return 1 }
function complemento(prods: Item[], p: Item, ja: number[]) {
  const cands = prods.filter((x) => x.id !== p.id && !ja.includes(x.id) && !x.esgotado && x.tipo !== 'servico')
  const mesma = cands.filter((x) => (x.categoria || '') !== (p.categoria || '')) // algo que COMPLETA (outra categoria) vem antes de mais do mesmo
  const pal = new Set(nrm([p.palavras, p.categoria].join(' ')).split(' ').filter((w) => w.length >= 4))
  const rel = (mesma.length ? mesma : cands).map((x) => ({ x, s: nrm([x.palavras, x.categoria, x.descricao].join(' ')).split(' ').filter((w) => pal.has(w)).length + (x.destaque?.emOferta ? 0.5 : 0) })).sort((a, b) => b.s - a.s || precoDe(a.x) - precoDe(b.x))
  return rel[0]?.x || null
}

/** Entende a mensagem do cliente e, quando é um pedido comercial claro sobre o catálogo, resolve aqui (sem IA). */
export function atender(msgs: Msg[], prods: Item[], o: { carrinho?: number[] } = {}): Resultado | null {
  const ult = msgs[msgs.length - 1]; if (!ult || ult.role !== 'user' || !prods.length) return null
  const s = nrm(ult.content), ctx = contexto(msgs, prods), voc = ctx.voc
  const termos = termosDe(ult.content, voc), f0 = filtrosDe(ult.content), mostrados = mostradosPorUltimo(msgs)
  // a camada coletiva do Cérebro também ajuda a reconhecer a intenção comercial em frases informais (anônimo, consolidado)
  const col = COL.sugerir(ult.content, { escopo: 'loja' })
  // resposta a "Qual você prefere?" (variação de UM item que o cliente já quis): "a branca", "M", "a segunda" → escolha feita
  const ultAss = [...msgs].reverse().find((m) => m.role === 'assistant')?.content || ''
  const escolhendo = /Qual voc[eê] prefere\?/.test(ultAss) && mostrados.length === 1 && (temFiltro(f0) || ORDINAL.some(([re]) => re.test(s)) || s.split(' ').length <= 3)
  const querAdd = ADICIONAR.test(s) || col?.intencao === 'loja.adicionar' || escolhendo
  const querPreco = PRECO_Q.test(s)
  const refino = !termos.length && temFiltro(f0) && (ctx.termos.length > 0 || mostrados.length > 0)
  const contextoBase = { termos: termos.length ? termos : ctx.termos, filtros: termos.length ? f0 : juntar(ctx.filtros, f0) }
  // ---------- adicionar ao carrinho ----------
  if (querAdd) {
    let alvo: Item | null = null
    const ord = ORDINAL.find(([re]) => re.test(s.replace(/\b(um|uma)\s+(?:d[oae]s?|unidade)\b/, ''))) // "um do primeiro" ≠ ordinal "um"
    const ref = mostrados.map((id) => prods.find((p) => p.id === id)).filter(Boolean) as Item[]
    if (termos.length) { const r = buscar(prods, termos, juntar(contextoBase.filtros, f0)); alvo = (r.fil[0] || r.base[0]) || null; if (r.fil.length > 1 && !ord && pontuar(r.fil[0], termos) === pontuar(r.fil[1], termos)) { return { acao: 'mostrar', ids: r.fil.slice(0, 6).map((p) => p.id), intencao: 'loja.adicionar', contexto: contextoBase, reply: `Temos mais de uma opção de ${termos.join(' ')}. Qual delas você quer? Toque em Adicionar na que preferir 👇` } } }
    else if (escolhendo) alvo = ref[0]
    else if (ord && ref.length) alvo = ord[1] === -1 ? ref[ref.length - 1] : ref[ord[1]] || null
    else if (ref.length === 1) alvo = ref[0]
    else if (ref.length > 1 && temFiltro(f0)) alvo = ref.find((p) => combina(p, f0)) || null
    if (!alvo) {
      if (ref.length > 1) return { acao: 'mostrar', ids: ref.slice(0, 6).map((p) => p.id), intencao: 'loja.adicionar', contexto: contextoBase, reply: 'Claro! Qual destas você quer? Pode dizer "a primeira", "a segunda"… ou tocar em Adicionar 👇' }
      return null
    }
    if (alvo.tipo === 'servico') return { acao: 'mostrar', ids: [alvo.id], intencao: 'loja.agendar', contexto: contextoBase, reply: `${alvo.nome} é um serviço: toque em Agendar para escolher o dia e o horário 👇` }
    const fv = juntar(contextoBase.filtros, f0), vs = (alvo.variantes || []).filter((v) => v.disponivel !== false)
    let v: Variante | null = null
    if (vs.length === 1) v = vs[0]
    else if (vs.length > 1) { const ok = vs.filter((x) => varCombina(x, escolhendo ? f0 : fv)), oi = escolhendo && ord ? (ord[1] === -1 ? vs[vs.length - 1] : vs[ord[1]]) : null; if (oi) v = oi; else if (ok.length === 1) v = ok[0]; else if (ok.length > 1 && escolhendo) { const ok2 = ok.filter((x) => varCombina(x, fv)); if (ok2.length === 1) v = ok2[0] } if (v) { /* escolhida */ } else return { acao: 'mostrar', ids: [alvo.id], intencao: 'loja.adicionar', contexto: contextoBase, reply: `Ótima escolha! ${alvo.nome} tem ${ok.length ? 'estas opções' : 'as opções'}: ${lista((ok.length ? ok : vs).map((x) => x.rotulo || '').filter(Boolean))}. Qual você prefere?` } }
    if ((alvo.variacoes || []).length) return { acao: 'mostrar', ids: [alvo.id], intencao: 'loja.adicionar', contexto: contextoBase, reply: `${alvo.nome} tem escolhas a fazer (${lista((alvo.variacoes || []).map((x: any) => x.nome))}). Toque em Adicionar para escolher 👇` }
    const qtd = qtdDe(s), comp = complemento(prods, alvo, o.carrinho || [])
    return { acao: 'adicionar', ids: comp ? [comp.id] : [], carrinho: [{ pid: alvo.id, vid: v ? v.id : null, qtd }], intencao: 'loja.adicionar', contexto: contextoBase,
      reply: `Coloquei ${qtd}× ${alvo.nome}${v && v.rotulo && vs.length > 1 ? ` (${v.rotulo})` : ''} no seu carrinho ✅${comp ? ` Se quiser, ${comp.nome} combina bem e sai por ${resumoPreco(comp)} — é só tocar em Adicionar.` : ' Quer mais alguma coisa ou prefere finalizar?'}` }
  }
  // ---------- dúvida de preço / disponibilidade de um item ----------
  if (querPreco && (termos.length || mostrados.length)) {
    const alvo = termos.length ? buscar(prods, termos, { cores: [], tamanho: null, materiais: [], precoMax: null, ordem: null }).base[0] : prods.find((p) => p.id === mostrados[mostrados.length === 1 ? 0 : 0])
    if (alvo) { const op = opcoesDe(alvo); return { acao: 'mostrar', ids: [alvo.id], intencao: 'loja.duvida', contexto: contextoBase, reply: `${alvo.nome} sai por ${resumoPreco(alvo)}${op.length > 1 ? `. Opções: ${lista(op.slice(0, 6))}` : ''}${alvo.esgotado ? ' — mas está indisponível no momento.' : '.'}` } }
  }
  // ---------- buscar / refinar ----------
  if (termos.length && (BUSCAR.test(s) || temFiltro(f0) || s.split(' ').length <= 4) || refino) {
    const T = contextoBase.termos, F = contextoBase.filtros
    const r = T.length ? buscar(prods, T, F) : { base: mostrados.map((id) => prods.find((p) => p.id === id)!).filter(Boolean), fil: mostrados.map((id) => prods.find((p) => p.id === id)!).filter((p) => p && combina(p, F)) }
    if (F.ordem && !T.length) r.fil.sort((a, b) => (F.ordem === 'barato' ? precoDe(a) - precoDe(b) : precoDe(b) - precoDe(a)))
    const oque = T.map((t) => original(t, msgs)).join(' ') || 'essas opções', desc = [F.cores.length ? `na cor ${lista(F.cores.map((c) => corOriginal(c, msgs)))}` : '', F.tamanho ? `no tamanho ${F.tamanho}` : '', F.materiais.length ? `de ${lista(F.materiais)}` : '', F.precoMax != null ? `até ${brl(F.precoMax)}` : ''].filter(Boolean).join(', ')
    const esg = !r.base.length && T.length ? prods.filter((p) => p.esgotado && pontuar(p, T) > 0) : []
    if (esg.length) return { acao: 'responder', ids: [], intencao: 'loja.buscar', contexto: contextoBase, reply: `${lista(esg.slice(0, 3).map((p) => p.nome))} ${esg.length > 1 ? 'estão esgotados' : 'está esgotado'} no momento. Quer ver outras opções do catálogo?` }
    if (!r.base.length) return termos.length ? { acao: 'responder', ids: [], intencao: 'loja.buscar', contexto: contextoBase, reply: `Não encontrei ${oque} no nosso catálogo. Quer que eu mostre o que temos parecido? É só dizer o que procura ou pedir o catálogo.` } : null
    if (!r.fil.length) {
      const cores = [...new Set(r.base.flatMap((p) => (p.variantes || []).filter((v) => v.disponivel !== false).map((v) => v.cor).filter(Boolean) as string[]))], tams = [...new Set(r.base.flatMap((p) => (p.variantes || []).filter((v) => v.disponivel !== false).map((v) => v.tamanho).filter(Boolean) as string[]))]
      const alt = F.cores.length && cores.length ? ` Temos nas cores ${lista(cores.map((c) => c.toLowerCase()))}.` : F.tamanho && tams.length ? ` Temos nos tamanhos ${lista(tams)}.` : F.precoMax != null ? ` A opção mais em conta sai por ${brl(Math.min(...r.base.map(precoDe)))}.` : ''
      return { acao: 'mostrar', ids: r.base.slice(0, 6).map((p) => p.id), intencao: 'loja.refinar', contexto: contextoBase, reply: `Não temos ${oque} ${desc} no momento.${alt} Estas são as opções disponíveis 👇` }
    }
    const n = r.fil.length, ids = r.fil.slice(0, 8).map((p) => p.id)
    const reply = refino || (!termos.length && desc) ? `Separei ${n === 1 ? 'a opção' : `as ${n} opções`} ${desc || ''} 👇`.replace(/\s+👇/, ' 👇') : F.ordem === 'barato' ? `Do mais em conta para o mais caro, aqui estão ${n === 1 ? 'a opção' : `${n} opções`} de ${oque} 👇` : n === 1 ? `Temos sim! Olha ${r.fil[0].nome} por ${resumoPreco(r.fil[0])} 👇` : `Encontrei ${n} opções de ${oque}${desc ? ' ' + desc : ''} 👇 Quer que eu filtre por cor, tamanho ou preço?`
    return { acao: 'mostrar', ids, intencao: refino ? 'loja.refinar' : 'loja.buscar', contexto: contextoBase, reply }
  }
  // ---------- procura algo que o catálogo NÃO tem ("vocês vendem tênis?"): diz com clareza, sem inventar ----------
  const nt = s.match(NAO_TEM)
  if (nt && !NAO_PRODUTO.test(nt[2]) && nt[2].split(' ').length <= 3) {
    const o = original(nt[2], msgs).replace(/\b(ai|aqui|hoje|ainda|tambem)\b/g, '').trim()
    if (o.length >= 3) return { acao: 'responder', ids: [], intencao: 'loja.buscar', contexto: contextoBase, reply: `Não encontrei ${o} no nosso catálogo. Quer que eu mostre o que temos? É só pedir o catálogo ou dizer o que procura.` }
  }
  return null
}
/** A cor como o cliente disse ("preta", não "preto"). */
function corOriginal(c: string, msgs: Msg[]) { for (const m of [...msgs].reverse()) { if (m.role !== 'user') continue; const o = String(m.content).split(/[\s,.!?;:]+/).find((x) => CORES.includes(nrm(x)) && corBase(x) === c); if (o) return o.toLowerCase() } return c }
/** A palavra como o cliente escreveu ("calça", não "calca"), para responder sem tirar os acentos. */
function original(termo: string, msgs: Msg[]) {
  const ws = termo.split(' '), out: string[] = []
  for (const w of ws) { let achou = ''; for (const m of [...msgs].reverse()) { if (m.role !== 'user') continue; const o = String(m.content).split(/[\s,.!?;:]+/).find((x) => { const n = nrm(x); return n === w || sing(n) === w }); if (o) { achou = o.toLowerCase(); break } } out.push(achou || w) }
  return out.join(' ')
}
/** "vocês têm X?", "vendem X?", "trabalham com X?", "procuro X" — X curto e com cara de produto. */
const NAO_TEM = /^(?:oi|ola|bom dia|boa tarde|boa noite)?[, ]*(?:voces|vcs|voce|vc)?\s*(tem|tens|vende|vendem|trabalha com|trabalham com|procuro|estou procurando|to procurando)\s+(?:o |a |os |as |um |uma )?([a-z ]{3,30}?)\s*[?.!]?$/
/** O que NÃO é produto (pergunta da loja, que segue para os atalhos/IA): entrega, pagamento, horário, promoções… */
const NAO_PRODUTO = /\b(entrega|delivery|frete|pix|cartao|dinheiro|desconto|promoc|cupom|horario|aberto|estacionamento|wifi|garantia|troca|devolu|parcel|whats|telefone|instagram|site|loja fisica|endereco|vaga|emprego|nota fiscal|reserva|agenda|hora)\b/
