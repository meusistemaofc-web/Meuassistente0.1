import { pub } from '../lib/publicurl.js'
import { settingsOf } from '../lib/account.js'
// Interpretador do chat: responde na hora, com dados reais e sem gastar IA, pedidos de mercado,
// impostos/DAS e faturamento. Só age quando tem certeza; o resto segue para a IA normalmente.
import { config } from '../config.js'
import type { SessionUser } from '../lib/session.js'
import { modules, getUM, setUM } from '../lib/usermod.js'
import { quote } from '../routes/market.js'
import { fiscalState, FISCAL_USER_DEFAULT, type Fiscal } from '../routes/modules.js'
import { reconhecerBusca, respostaEmpresas } from '../routes/businesses.js'

const norm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const normMkt = (t: string) => norm(t).replace(/\b(cryptos?|criptos|criptomoedas?|cryptomoedas?|crypto ?moedas?|cripto ?moedas?)\b/g, 'cripto').replace(/\b(acao|acoes|papeis|papel)\b/g, 'acoes')
const FORTE: Record<string, string> = { bitcoin: 'BTC', btc: 'BTC', ethereum: 'ETH', ether: 'ETH', eth: 'ETH', solana: 'SOL', ripple: 'XRP', xrp: 'XRP', bnb: 'BNB', cardano: 'ADA', ada: 'ADA', dogecoin: 'DOGE', doge: 'DOGE', litecoin: 'LTC', ltc: 'LTC', stellar: 'XLM', xlm: 'XLM', tether: 'USDT', usdt: 'USDT', ibovespa: 'IBOV', ibov: 'IBOV', petrobras: 'PETR4', petr4: 'PETR4', vale3: 'VALE3', itau: 'ITUB4', itub4: 'ITUB4', bradesco: 'BBDC4', bbdc4: 'BBDC4', bbas3: 'BBAS3', 'banco do brasil': 'BBAS3', ambev: 'ABEV3', abev3: 'ABEV3', b3sa3: 'B3SA3', magalu: 'MGLU3', 'magazine luiza': 'MGLU3', mglu3: 'MGLU3', weg: 'WEGE3', wege3: 'WEGE3' }
const FRACO: Record<string, string> = { sol: 'SOL', vale: 'VALE3' }
export function findSym(t: string): string | null {
  const s = normMkt(t)
  for (const [k, v] of Object.entries(FORTE)) if (new RegExp('(^| )' + k + '( |$)').test(s)) return v
  const ctx = /\b(cripto|acoes|bolsa|cotac|preco|grafico|como esta|subiu|caiu)\b/.test(s) || /\b(SOL|VALE)\b/.test(t)
  if (ctx) for (const [k, v] of Object.entries(FRACO)) if (new RegExp('(^| )' + k + '( |$)').test(s)) return v
  const m = t.toUpperCase().match(/\b([A-Z]{4}(?:3|4|5|6|11))\b/)
  return m ? m[1] : null
}
const brl = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const pts = (n: number) => n.toLocaleString('pt-BR', { maximumFractionDigits: 0 }) + ' pontos'
const fdate = (iso: string) => iso.split('-').reverse().join('/')

export async function quickReply(u: SessionUser, text: string): Promise<string | null> {
  const s = normMkt(text), mods = await modules()
  // saudação simples: resposta imediata, sem esperar IA
  const g = text.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[!.?,\s]+$/g, '')
  if (/^(oi+|ola+|ola tudo bem|oi tudo bem|e ai|eai|opa|hey|hello|hi|bom dia|boa tarde|boa noite|tudo bem|tudo bom|salve|fala)( (assistente|meu assistente|tudo bem|tudo bom))?$/.test(g)) {
    const h = new Date(new Date().toLocaleString('en-US', { timeZone: settingsOf(u).timezone || 'America/Sao_Paulo' })).getHours()
    const saud = /bom dia/.test(g) ? 'Bom dia' : /boa tarde/.test(g) ? 'Boa tarde' : /boa noite/.test(g) ? 'Boa noite' : h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'
    const nome = String(u.name || '').split(' ')[0]
    const ops = ['Em que posso te ajudar?', 'O que vamos organizar agora?', 'Como posso ajudar hoje?']
    return `${saud}${nome ? ', ' + nome : ''}! ${/tudo (bem|bom)/.test(g) ? 'Tudo ótimo por aqui. ' : ''}${ops[new Date().getMinutes() % ops.length]}`
  }
  const money = /\b(gastei|paguei|comprei)\b/.test(s)
  const link = (p: string) => `${pub()}${p}`
  // alerta de preço
  const am = text.match(/(?:me avise|avise|alerta).*?(?:chegar|bater|atingir|cair|subir).*?r?\$?\s*(\d+(?:[.,]\d+)?)/i)
  const sym = findSym(text)
  if (am && sym && mods.mercado) {
    const v = Number(am[1].replace(/\./g, '').replace(',', '.'))
    let cur: number | null = null; try { cur = (await quote(sym)).price } catch {}
    const cond = cur !== null && v < cur ? 'abaixo' : 'acima'
    const list = await getUM<any[]>(u.id, 'market_alerts', [])
    list.unshift({ id: Math.random().toString(36).slice(2, 10), symbol: sym, cond, value: v, createdAt: new Date().toISOString(), firedAt: null })
    await setUM(u.id, 'market_alerts', list)
    return `Combinado! Te aviso quando ${sym} ${cond === 'acima' ? 'subir até' : 'cair até'} ${sym === 'IBOV' ? pts(v) : brl(v)}.${cur !== null ? ` Agora está em ${sym === 'IBOV' ? pts(cur) : brl(cur)}.` : ''}`
  }
  // cotação de um ativo
  if (sym && !money && mods.mercado) {
    try {
      const q = await quote(sym)
      const ch = q.change24h !== null ? `, ${q.change24h >= 0 ? 'alta' : 'queda'} de ${Math.abs(q.change24h).toFixed(2).replace('.', ',')}% em 24 horas` : ''
      return `${q.nome} (${sym}) está em ${sym === 'IBOV' ? pts(q.price) : brl(q.price)}${ch}. Fonte: ${q.source}. ⟦mkt:${sym}⟧`
    } catch { return `Não consegui buscar a cotação de ${sym} agora. Tente de novo em instantes.` }
  }
  // resumo do mercado
  const cat = /\bcripto\b/.test(s), bol = /\b(bolsa|acoes|ibovespa)\b/.test(s)
  const mq = /\bmercado\b/.test(s) && /(como esta|como anda|hoje|resumo|cotac|financeiro|cripto|bolsa|acoes|investimento)/.test(s) && !/(perto|proxim|mercadinho|supermercado|lista|compras)/.test(s)
  if ((cat || bol || mq) && !money && mods.mercado && s.split(' ').length <= 10) {
    const list = cat && !bol ? ['BTC', 'ETH', 'SOL', 'XRP'] : bol && !cat ? ['IBOV', 'PETR4', 'VALE3', 'ITUB4'] : ['BTC', 'ETH', 'IBOV', 'PETR4']
    const lines = await Promise.all(list.map(async (x) => { try { const q = await quote(x); return `• ${x}: ${x === 'IBOV' ? pts(q.price) : brl(q.price)}${q.change24h !== null ? ` (${q.change24h >= 0 ? '+' : ''}${q.change24h.toFixed(2).replace('.', ',')}%)` : ''}` } catch { return `• ${x}: indisponível` } }))
    return `Resumo do mercado agora:\n${lines.join('\n')} ⟦mktsum:${list.join(',')}⟧`
  }
  // empresas parceiras: a palavra-chave cadastrada (ou o ramo/nome) é um GATILHO de busca — sozinha ou numa frase de busca.
  // Comandos de outros recursos (mudar/cancelar/agendar compromisso, anotar, lembrar, lista, gastos, análises) seguem adiante.
  const nPal = s.split(' ').filter(Boolean).length
  if (mods.empresas && !money && nPal <= 20) {
    const ACAO = /\b(recebi|vendi|faturei|gastei|paguei|lembr\w*|lista|adicion\w*|anot\w*|mud\w*|alter\w*|remarc\w*|cancel\w*|desmarc\w*|exclu\w*|apag\w*|edit\w*|registr\w*|lanc\w*|agend\w*|marc\w*|cri\w*|analis\w*|relatorio\w*|resum\w*|compar\w*|estrateg\w*|vendas|faturamento|diagnostic\w*)\b/
    const BUSCA = /\b(onde|perto|proxim\w*|procur\w*|precis\w*|indic\w*|recomend\w*|alguem|empresa\w*|lugar\w*|quero|queria|gostaria|contrat\w*|encontr\w*|ach\w*|busc\w*|mostr\w*|conhec\w*|tem algu\w*)\b/
    if (!ACAO.test(s)) {
      const rec = await reconhecerBusca(text)
      const sig = s.split(' ').filter((w) => w.length >= 3).length
      // 1) a palavra/expressão quase sozinha ("Piercing", "banho e tosa"); 2) frase com intenção clara de procurar + palavra-chave/ramo
      if (rec && ((sig <= 3 && nPal <= 8) || (BUSCA.test(s) && rec.score >= 2)) && (rec.disponivel || rec.score >= 2)) {
        // resposta única (a mesma usada na atualização automática depois que a localização é autorizada)
        const r = await respostaEmpresas(u.id, text)
        return r.estado === 'empresas_encontradas' ? `${r.content}⟦q:${encodeURIComponent(text)}⟧` : r.content
      }
    }
  }
  if (!mods.fiscal) return null
  // DAS
  // "das" minúsculo é a preposição (de+as): "o lucro das unidades vendidas" NÃO é pergunta sobre o imposto. Vale a sigla DAS (maiúscula,
  // como a pessoa escreve) ou "das" com um contexto inequívoco de imposto/MEI ("meu das", "pagar o das", "guia do das"…).
  const dasSigla = /(?<![\p{L}\d])DAS(?![\p{L}\d])/u.test(text), dasFrase = /\b(meu|minha|proximo|proxima|pagar|paguei|pago|guia d[oe]|valor d[oe]|vencimento d[oe]|vence o|boleto d[oe]|emitir (?:o )?|gerar (?:o )?)\s+das\b(?!\s+(?:unidades|vendas|pessoas|coisas|contas|compras|despesas|receitas|lojas|mercadorias|produtos|encomendas|pecas|itens))/.test(s)
  const dasMinusc = /\b(?:qual|quanto|quando|cade|ver|veja|mostre|mostra)\s+(?:e\s+)?o\s+das\b/.test(s) || /\b(?:do|no) das\b(?!\s+(?:unidades|vendas|pessoas|coisas|contas|compras|despesas|receitas|lojas|produtos|itens))/.test(s) || /\bo das\b(?=\s+(?:de|do|desse|deste|vence|venceu|esta|ja|atrasado|em aberto)\b)/.test(s)
  if ((dasSigla || dasFrase || dasMinusc || /\b(imposto do mei|guia do mei)\b/.test(s)) && !/declara/.test(s)) {
    const f = await fiscalState(u.id)
    return f.proximo ? `Seu próximo DAS é de ${brl(f.das.total)} (competência ${f.proximo.nome}), com vencimento em ${fdate(f.proximo.venc)}.${f.perfil.avisos.das ? ` Vou te lembrar ${f.perfil.avisos.dias} dia(s) antes.` : ''}⟦btn:/x/impostos|Ver Impostos e DAS⟧` : `Todos os seus DAS do ano estão marcados como pagos. ⟦btn:/x/impostos|Ver Impostos e DAS⟧`
  }
  if (/\b(declaracao anual|dasn|declaracao do mei)\b/.test(s)) {
    const f = await fiscalState(u.id)
    return `A declaração anual do MEI (DASN-SIMEI) deve ser entregue até ${fdate(f.dasn.prazo)}, com o faturamento de ${f.dasn.anoBase}.${f.perfil.avisos.dasn ? ' O aviso já está ligado.' : ''}`
  }
  // receita (só com permissão)
  // só vira faturamento quando a frase é um relato com valor em reais ("recebi R$ 500", "vendi 300 reais") — "Vendi 8 por R$40 cada.
  // Quanto lucrei?" é uma conta, e o primeiro número solto (8) nunca é o valor.
  const rm = /\?|\b(quanto|quantos|quantas|qual|calcul\w*|lucro|margem|cada)\b/.test(s) ? null : s.match(/\b(recebi|vendi|faturei)\b[^0-9?]{0,30}?(?:r\$\s*)(\d+(?:[.,]\d{1,2})?)/) || s.match(/\b(recebi|vendi|faturei)\b[^0-9?]{0,30}?(\d+(?:[.,]\d{1,2})?)\s*(?:reais|real)\b/)
  if (rm) {
    const f: Fiscal = { ...FISCAL_USER_DEFAULT, ...(await getUM<Partial<Fiscal>>(u.id, 'fiscal', {})) } as Fiscal
    if (!f.consent) return null // sem permissão, a IA trata como receita comum
    const v = Number(rm[2].replace(',', '.')), k = new Date().toISOString().slice(0, 7)
    f.receitas = { ...f.receitas, [k]: Math.round(((Number(f.receitas[k]) || 0) + v) * 100) / 100 }
    await setUM(u.id, 'fiscal', f)
    const st = await fiscalState(u.id)
    return `Anotei ${brl(v)} no seu faturamento do MEI. No ano você está em ${brl(st.faturamento)}, ${Math.round(st.usoLimite * 100)}% do limite.`
  }
  return null
}
