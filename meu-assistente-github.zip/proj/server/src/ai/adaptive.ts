// AdaptiveLearningEngine — aprendizagem operacional individual, SEM treinar modelo e SEM depender só do prompt.
// Camadas: (1) contexto da conversa = conversation_context (convctx.ts, `correcoes`); (2) memória individual = tabela `learnings`
// (migração 023); (3) memória global = Cérebro/Laboratório de IA (só muda com aprovação do administrador — este arquivo apenas
// SUGERE, nunca grava lá sozinho). A memória orienta o comportamento; permissões, validações financeiras e regras de negócio
// continuam controlando a execução. Funciona sem IA: detecção, gravação, recuperação e prevenção são determinísticas.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import { getConfig } from '../lib/settings.js'
import { fail } from '../lib/http.js'
import type { ConvCtx } from './convctx.js'

/** Configuração global do aprendizado adaptativo (chave 'adaptive' do painel). */
interface AdaptiveCfg { ativo?: boolean; atualizadoEm?: string; atualizadoPor?: number; atualizadoPorNome?: string }
/** Campos usados de um compromisso (items.data). */
interface ApptData { time?: string; title?: string; location?: string }

export const OPERACOES = ['agendamento', 'exclusao', 'financeiro', 'lembrete', 'tarefa', 'compra', 'geral'] as const
export type Operacao = (typeof OPERACOES)[number]
export const KINDS = ['consultar_antes', 'confirmar_antes', 'considerar_intervalo', 'dispensar_consulta', 'dispensar_confirmacao', 'evitar', 'fazer_assim', 'estilo', 'preferencia_inferida'] as const
const OP_VERBO: Record<string, string> = { agendamento: 'agendar', exclusao: 'excluir', financeiro: 'registrar lançamentos', lembrete: 'criar lembretes', tarefa: 'criar tarefas', compra: 'alterar a lista de compras', geral: 'executar' }
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()

/* ---------- liga/desliga ---------- */
export async function globalOn() { return (await getConfig<AdaptiveCfg>('adaptive', {})).ativo !== false }
/** Aprende só se: chave global ligada, memória do usuário ligada e aprendizagem não desativada por ele (reaproveita memory_settings). */
/** Aprendizados é institucional: a chave global do administrador vale para todos (não há mais ativação individual); só a memória geral do usuário (privacidade) continua respeitada. */
export async function ativo(u: SessionUser) { return (await globalOn()) && u.memory_settings?.enabled !== false }
export async function estadoGlobal() { const c = await getConfig<AdaptiveCfg>('adaptive', {}); return { ativo: c.ativo !== false, atualizadoEm: c.atualizadoEm || null, atualizadoPor: c.atualizadoPor ? { id: Number(c.atualizadoPor), nome: String(c.atualizadoPorNome || '') } : null } }

/* ---------- classificação ---------- */
export function operacaoDe(text: string): Operacao {
  const t = norm(text)
  if (/\b(exclu\w*|apag\w*|delet\w*|remov\w*|cancel\w*|desmarc\w*)\b/.test(t)) return 'exclusao'
  if (/\b(gast\w*|despes\w*|receita\w*|lancament\w*|pagament\w*|financ\w*|cobranc\w*|sinal|boleto)\b/.test(t)) return 'financeiro'
  if (/\b(agend\w*|marc\w*|reserv\w*|compromiss\w*|horario\w*|disponibilidade|atendiment\w*|reuniao|reunioes|intervalo|almoco)\b/.test(t)) return 'agendamento'
  if (/\blembr\w*/.test(t)) return 'lembrete'
  if (/\btarefa\w*/.test(t)) return 'tarefa'
  if (/\b(compras?|lista de compras)\b/.test(t)) return 'compra'
  return 'geral'
}
/** Operações que a mensagem ATUAL do usuário pede (para recuperar só o que é relevante). */
export function operacoesDaMensagem(text: string): Operacao[] {
  const t = norm(text), out: Operacao[] = []
  if (/\b(agend\w*|marc\w*|marque|reserv\w*|compromiss\w*|reuniao|consulta|atendimento|horario\w*)\b/.test(t)) out.push('agendamento')
  if (/\b(exclu\w*|apag\w*|delet\w*|remov\w*|cancel\w*|desmarc\w*)\b/.test(t)) out.push('exclusao')
  if (/\b(gastei|paguei|recebi|despesa|receita|lancament\w*|pagament\w*|conta a pagar|cobranc\w*|sinal)\b/.test(t)) out.push('financeiro')
  if (/\b(lembr\w*|me avis\w*)\b/.test(t)) out.push('lembrete')
  if (/\btarefa\w*/.test(t)) out.push('tarefa')
  if (/\b(comprar|lista de compras)\b/.test(t)) out.push('compra')
  return out
}

/* ---------- segurança: nada de aprendizado que mexa em regras obrigatórias ---------- */
const INSEGURO = [
  /\b(ignor\w+|desconsider\w+|desative\w*|desligue|desabilit\w+|contorn\w+|burl\w+|pule|pular|dispense|dispensar)\b.*\b(seguranc\w*|autentic\w*|permiss\w*|senha\w*|validac\w*|login|autoriz\w*|regras? obrigatori\w*|2fa|mfa)\b/,
  /\bsem (pedir|exigir|validar|checar|conferir)\b.*\b(senha|autorizac\w*|permiss\w*|validac\w*)\b/,
  /\b(aprov\w+|pague|pagar|transfir\w+|libere)\b.*\b(automaticamente|sem confirmar|sem perguntar|sem validar)\b/,
  /\b(para todos (os )?(usuarios|clientes|contas)|todos os usuarios|para todo mundo|globalmente)\b/,
  /\b(senha|token|cvv|cartao de credito|codigo de seguranca)\b/,
]
export const inseguro = (text: string) => { const t = norm(text); return INSEGURO.some((re) => re.test(t)) }

/* ---------- detecção de correções e preferências ---------- */
export interface Detectado { operacao: Operacao; kind: string; escopo: 'permanente' | 'pontual' | 'ambigua'; regra: string; problema: string; preferencia: string; pura: boolean }
const CUE = [
  /\bnao faca (isso |mais )?(novamente|de novo|mais)\b/, /\bnao faca\b/, /\bda proxima vez\b/, /\b(daqui (pra|para) frente|a partir de agora|de agora em diante)\b/,
  /\b(sempre|nunca|jamais)\b.*\b(confirm\w*|consult\w*|(?:confer|confira)\w*|verific\w*|pergunt\w*|avis\w*|us[ae]\w*|registr\w*|consider\w*|lembr\w*|pe[cç]a\w*|mostr\w*)\b/,
  /\b(toda vez|sempre que)\b/, /\bantes de\b.*\b(consult\w*|(?:confer|confira)\w*|verific\w*|confirm\w*|pergunt\w*)\b/, /\b(consult\w*|(?:confer|confira)\w*|verific\w*|confirm\w*|pergunt\w*)\w*\b.*\bantes\b/,
  /\bvoce esqueceu\b/, /\besqueceu de\b/, /\bnao era isso\b/, /\bnao foi isso que\b/, /\b(seja|fale|responda) (mais )?(curto|curta|objetivo|objetiva|direto|direta|breve|detalhado|detalhada|formal|informal)\b/,
  /\bnao precisa mais\b/, /\bpode (agendar|fazer|executar|registrar) (direto|sem)\b/,
]
const PERMANENTE = /\b(sempre|nunca|jamais|toda vez|sempre que|a partir de agora|de agora em diante|daqui (pra|para) frente|da proxima vez|nao faca (isso |mais )?(novamente|de novo|mais)|nao precisa mais)\b/
const PONTUAL = /\b(dessa vez|desta vez|so agora|so hoje|so dessa|por enquanto|neste caso|nesse caso|apenas hoje)\b/
const REGRA_CONDICIONAL = /\bantes de\b.*\b(consult\w*|(?:confer|confira)\w*|verific\w*|confirm\w*|pergunt\w*)\b|\b(consult\w*|(?:confer|confira)\w*|verific\w*|confirm\w*|pergunt\w*)\w*\b.*\bantes\b/
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)
function limpar(text: string) { return cap(String(text || '').replace(/\s+/g, ' ').trim().replace(/[.!\s]+$/, '')).slice(0, 180) + '.' }

export function detectar(text: string): Detectado | null {
  const raw = String(text || '').trim()
  if (raw.length < 8 || raw.length > 400) return null
  const t = norm(raw)
  if (!CUE.some((re) => re.test(t))) return null
  let kind = '', op = operacaoDe(raw)
  if (/\b(nao precisa|pode|dispens\w*)\b.*\b(confirm\w*|pergunt\w*)\b|\bsem (confirmar|perguntar)\b/.test(t)) kind = 'dispensar_confirmacao'
  else if (/\b(nao precisa mais|dispens\w*)\b.*\b(consult\w*|(?:confer|confira)\w*|verific\w*)\b|\bpode (agendar|marcar) direto\b|\bsem (consultar|conferir|verificar)\b/.test(t)) kind = 'dispensar_consulta'
  else if (/\b(confirm\w*|pergunt\w*)\w*\b.*\b(comigo|antes)\b|\bantes de\b.*\b(confirm\w*|pergunt\w*)\b|\bme pergunt\w*\b/.test(t)) kind = 'confirmar_antes'
  else if (/\b(consult\w*|(?:confer|confira)\w*|verific\w*|cheque\w*|veja|olhe)\w*\b.*\b(disponibilidad\w*|horario\w*|agenda|conflito\w*)\b|\bantes de\b.*\b(consult\w*|(?:confer|confira)\w*|verific\w*)\b|\b(consult\w*|(?:confer|confira)\w*|verific\w*)\w*\b.*\bantes\b/.test(t)) kind = 'consultar_antes'
  else if (/\b(intervalo\w*|almoco|jantar)\b/.test(t)) kind = 'considerar_intervalo'
  else if (/\b(seja|fale|responda)\b/.test(t)) kind = 'estilo'
  else if (/\bnao faca\b|\bnao (crie|registre|marque|agende|envie|exclua|apague)\b/.test(t)) kind = 'evitar'
  else if (/\bda proxima vez\b|\b(faca|use|usa)\b/.test(t)) kind = 'fazer_assim'
  if (!kind) return null // "não era isso que eu queria": sem regra definida → o chat pergunta (sem gravar nada)
  if ((kind === 'consultar_antes' || kind === 'considerar_intervalo' || kind === 'dispensar_consulta') && op === 'geral') op = 'agendamento'
  if (kind === 'estilo') op = 'geral'
  const verbo = OP_VERBO[op] || 'executar'
  const escopo: Detectado['escopo'] = PONTUAL.test(t) ? 'pontual' : PERMANENTE.test(t) || REGRA_CONDICIONAL.test(t) || kind === 'estilo' ? 'permanente' : 'ambigua'
  const regra = kind === 'consultar_antes' ? (op === 'agendamento' ? 'Antes de agendar, conferir a disponibilidade de horários.' : `Antes de ${verbo}, conferir as informações disponíveis.`)
    : kind === 'confirmar_antes' ? `Antes de ${verbo}, pedir a confirmação do usuário.`
    : kind === 'considerar_intervalo' ? 'Ao agendar, considerar os intervalos (almoço/jantar) e não oferecer horários dentro deles.'
    : kind === 'dispensar_consulta' ? `Não é necessário conferir antes de ${verbo}.`
    : kind === 'dispensar_confirmacao' ? `Não é necessário pedir confirmação antes de ${verbo}.`
    : limpar(raw)
  const problema = /\besqueceu|nao era isso|nao foi isso|errou|erro\b/.test(t) ? limpar(raw) : ''
  const pura = !(/\b(agend\w*|marc\w*|marque)\b/.test(t) && /\b(amanha|hoje|\d{1,2}\s*(h|:)|dia \d+)\b/.test(t) && !REGRA_CONDICIONAL.test(t))
  return { operacao: op, kind, escopo, regra, problema, preferencia: kind === 'estilo' || kind === 'fazer_assim' ? limpar(raw) : '', pura }
}

/* ---------- respostas naturais (sem falar de memória) ---------- */
export function reconhecimento(d: Detectado) {
  const verbo = OP_VERBO[d.operacao] || 'executar'
  if (d.escopo === 'ambigua') return d.kind === 'considerar_intervalo' ? 'Verdade, vou considerar o intervalo. Quer que eu faça isso sempre daqui para frente ou só desta vez?' : 'Entendi! Isso vale só para esta vez ou para as próximas também?'
  const pont = d.escopo === 'pontual'
  switch (d.kind) {
    case 'consultar_antes': return d.operacao === 'agendamento' ? 'Entendi! Vou conferir a disponibilidade antes de seguir.' : 'Entendi! Vou conferir as informações antes de seguir.'
    case 'confirmar_antes': return `Combinado! Vou confirmar com você antes de ${verbo}.`
    case 'considerar_intervalo': return 'Entendi! Vou considerar os intervalos nos próximos horários.'
    case 'dispensar_consulta': case 'dispensar_confirmacao': return 'Certo! Então sigo direto, sem etapas extras.'
    case 'estilo': return 'Pode deixar! Vou responder desse jeito.'
    default: return pont ? 'Entendi, dessa vez farei assim.' : 'Entendi! Vou fazer assim daqui para frente.'
  }
}
/** Remove frases que anunciam memória/aprendizado (a aprendizagem é silenciosa). */
const ANUNCIO = /(aprendizado registrad\w+|registrei (isso|essa|esse|a|o) (preferencia|regra|correcao|aprendizado)|salv(ei|ado|o) (isso )?na (minha )?memoria|guardei (isso )?na (minha )?memoria|consultei (a )?minha memoria|segundo (a )?minha memoria|conforme (o que )?(voce )?(me )?(ensinou|corrigiu)( antes)?|como voce (ja )?me (corrigiu|pediu) (antes|da outra vez)|da outra vez que voce me corrigiu|estou aprendendo|vou me lembrar disso para sempre)/i
export function silenciar(text: string): string {
  const s = String(text || ''); if (!s) return s
  const partes = s.split(/(?<=[.!?])\s+/)
  const ok = partes.filter((p) => !ANUNCIO.test(norm(p)))
  return ok.length === partes.length ? s : ok.join(' ').trim() || 'Pronto!'
}

/* ---------- persistência (camada 2) ---------- */
/** Uma linha da tabela learnings (colunas usadas pelo serviço). */
type LearningRow = {
  id: number | string; user_id: number | string; business_id: number | string | null; conversation_id: string | null
  operation: string; kind: string; context: string | null; problem: string | null; correction: string | null; preference: string | null
  rule: string; scope: string; confidence: number | string; frequency: number | string; uses: number | string; state: string
  history: unknown; created_at: string; updated_at: string; last_used_at: string | null
  review_status: string | null; reviewed_at: string | null; review_note: string | null; original_rule: string | null
}
/** Evento do histórico de um aprendizado (criado, reforçado, revisado…). */
export interface HistoricoEvento { em: string; acao: string; [extra: string]: unknown }
export type Revisao = (typeof REVISOES)[number]
const ehRevisao = (v: unknown): v is Revisao => (REVISOES as readonly unknown[]).includes(v)
export interface Aprendizado {
  id: number; operacao: string; kind: string; regra: string; escopo: string; confianca: number; frequencia: number; usos: number; estado: string
  empresaId: number | null; contexto: string | null; problema: string | null; correcao: string | null; preferencia: string | null; conversaId: string | null
  criadoEm: string; atualizadoEm: string; ultimoUso: string | null; historico: HistoricoEvento[]
  /** revisão administrativa (fila de revisão do painel) */
  revisao: Revisao; revisadoEm: string | null; notaRevisao: string | null; regraOriginal: string | null
}
const out = (r: LearningRow): Aprendizado => ({ id: Number(r.id), operacao: r.operation, kind: r.kind, regra: r.rule, escopo: r.scope, confianca: Math.round(Number(r.confidence) * 100) / 100, frequencia: Number(r.frequency), usos: Number(r.uses), estado: r.state, empresaId: r.business_id == null ? null : Number(r.business_id), contexto: r.context, problema: r.problem, correcao: r.correction, preferencia: r.preference, conversaId: r.conversation_id, criadoEm: r.created_at, atualizadoEm: r.updated_at, ultimoUso: r.last_used_at, historico: J<HistoricoEvento[]>(r.history, []), revisao: ehRevisao(r.review_status) ? r.review_status : 'pendente', revisadoEm: r.reviewed_at || null, notaRevisao: r.review_note || null, regraOriginal: r.original_rule || null })
/** Relê o aprendizado depois de gravar; se ele não existe mais (excluído em paralelo), responde 404 em vez de quebrar. */
async function relerAprendizado(id: number | string): Promise<LearningRow> {
  const r = await one<LearningRow>('SELECT * FROM learnings WHERE id = $1', [id])
  if (!r) fail(404, 'Aprendizado não encontrado.', 'not_found')
  return r
}
const hist = (r: Pick<LearningRow, 'history'> | null, acao: string, extra: object = {}) => JSON.stringify([...J<HistoricoEvento[]>(r?.history, []), { em: nowIso(), acao, ...extra }].slice(-30))
const CONTRARIOS: Record<string, string> = { consultar_antes: 'dispensar_consulta', dispensar_consulta: 'consultar_antes', confirmar_antes: 'dispensar_confirmacao', dispensar_confirmacao: 'confirmar_antes' }
const MAX_POR_USUARIO = 200

async function empresaDoTexto(u: SessionUser, text: string): Promise<number | null> {
  const t = norm(text)
  for (const b of await q('SELECT id, data FROM businesses WHERE owner_id = $1', [u.id]).catch(() => [])) { const n = norm(J<{ empresa?: string }>(b.data, {}).empresa || ''); if (n.length >= 3 && t.includes(n)) return Number(b.id) }
  return null
}

export async function registrar(u: SessionUser, convId: string, d: Detectado, textoOriginal: string, contexto: { acao?: string; contexto?: string } = {}) {
  const emp = await empresaDoTexto(u, textoOriginal)
  const escopo = d.escopo === 'ambigua' ? 'candidato' : d.escopo
  const confianca = d.escopo === 'ambigua' ? 0.4 : 0.9
  const mesma = await one<LearningRow>("SELECT * FROM learnings WHERE user_id = $1 AND operation = $2 AND kind = $3 AND state = 'ativo' AND COALESCE(business_id,0) = $4 AND rule = $5 ORDER BY id DESC", [u.id, d.operacao, d.kind, emp || 0, d.regra])
  if (mesma) {
    const nf = Number(mesma.frequency) + 1, nc = Math.min(0.99, Math.max(Number(mesma.confidence), confianca) + 0.03)
    const esc = escopo === 'candidato' ? mesma.scope : mesma.scope === 'candidato' ? escopo : mesma.scope
    await q('UPDATE learnings SET frequency = $1, confidence = $2, scope = $3, history = $4, updated_at = $5 WHERE id = $6', [nf, nc, esc, hist(mesma, 'reforcado', { texto: textoOriginal.slice(0, 200) }), nowIso(), mesma.id])
    return out(await relerAprendizado(mesma.id))
  }
  const contr = CONTRARIOS[d.kind]
  if (contr && escopo !== 'candidato') for (const o of await q<LearningRow>("SELECT * FROM learnings WHERE user_id = $1 AND operation = $2 AND kind = $3 AND state = 'ativo' AND COALESCE(business_id,0) = $4", [u.id, d.operacao, contr, emp || 0])) {
    await q("UPDATE learnings SET state = 'substituido', history = $1, updated_at = $2 WHERE id = $3", [hist(o, 'substituido', { por: d.kind, texto: textoOriginal.slice(0, 200) }), nowIso(), o.id]) // a orientação explícita mais recente vence
  }
  if (Number((await one('SELECT COUNT(*) AS n FROM learnings WHERE user_id = $1', [u.id]))?.n || 0) >= MAX_POR_USUARIO) await q("DELETE FROM learnings WHERE id IN (SELECT id FROM learnings WHERE user_id = $1 AND state <> 'ativo' ORDER BY id LIMIT 20)", [u.id])
  const now = nowIso()
  const r = await q<LearningRow>('INSERT INTO learnings (user_id, business_id, conversation_id, operation, kind, context, action_done, problem, correction, preference, rule, scope, confidence, frequency, uses, state, history, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,1,0,$14,$15,$16,$16) RETURNING *',
    [u.id, emp, convId || null, d.operacao, d.kind, (contexto.contexto || '').slice(0, 300) || null, (contexto.acao || '').slice(0, 300) || null, d.problema || null, textoOriginal.slice(0, 300), d.preferencia || null, d.regra, escopo, confianca, 'ativo', JSON.stringify([{ em: now, acao: 'criado', escopo }]), now])
  return out(r[0])
}

/** Camada 1: correção também fica no contexto da conversa (só vale nela). */
async function nasConversa(u: SessionUser, convId: string, regra: string) {
  try { const C = await import('./convctx.js'), c: ConvCtx = await C.getCtx(convId, u.id); c.correcoes = [...(c.correcoes || []), regra].slice(-8); await C.saveCtx(convId, u.id, c) } catch { /* contexto é apoio */ }
}

/** Entrada do orquestrador: chamada ANTES dos motores. Devolve `reply` quando a mensagem é só uma correção/preferência. */
const RECUSA = 'Isso eu não consigo mudar: as regras de segurança, as permissões e as validações continuam valendo. De resto, posso ajustar do jeito que você preferir.'
export async function observar(u: SessionUser, convId: string, text: string, hist: { role: string; content: string | null }[] = []): Promise<{ reply: string | null; aprendido?: Aprendizado | null } | null> {
  if (!(await ativo(u))) return null
  const t = norm(text)
  // resposta a uma pergunta de esclarecimento ("vale sempre ou só desta vez?")
  const cand = convId ? await one<LearningRow>("SELECT * FROM learnings WHERE user_id = $1 AND conversation_id = $2 AND scope = 'candidato' AND state = 'ativo' ORDER BY id DESC", [u.id, convId]) : null
  if (cand && t.split(' ').length <= 12) {
    if (/\b(sempre|toda vez|daqui (pra|para) frente|para as proximas|vale sempre|as proximas|sim)\b/.test(t) && !/\b(so|apenas) (dessa|desta|agora)\b/.test(t)) {
      await q("UPDATE learnings SET scope = 'permanente', confidence = 0.88, history = $1, updated_at = $2 WHERE id = $3", [hist_(cand, 'confirmado_pelo_usuario'), nowIso(), cand.id])
      return { reply: 'Combinado! Vou seguir assim daqui para frente.' }
    }
    if (/\b(so|apenas) (dessa|desta|agora|hoje)\b|\bnao\b/.test(t)) {
      await q("UPDATE learnings SET scope = 'pontual', confidence = 0.9, history = $1, updated_at = $2 WHERE id = $3", [hist_(cand, 'so_desta_vez'), nowIso(), cand.id])
      return { reply: 'Certo, só desta vez.' }
    }
  }
  const d = detectar(text)
  if (!d && inseguro(text) && /\b(sempre|nunca|jamais|toda vez|daqui (pra|para) frente|a partir de agora|de agora em diante|da proxima vez|passe a)\b/.test(t)) return { reply: RECUSA } // instrução de segurança disfarçada de preferência
  if (!d) return null
  if (inseguro(text)) return { reply: RECUSA }
  if ((d.kind === 'dispensar_confirmacao' || d.kind === 'dispensar_consulta') && (d.operacao === 'financeiro' || d.operacao === 'exclusao')) return { reply: 'Nessa parte eu preciso manter a conferência, por segurança. Nas outras, posso seguir do seu jeito.' } // validações financeiras e exclusões não se dispensam
  const ultimaAcao = [...hist].reverse().find((m) => m.role === 'assistant' && m.content)?.content, ultimaMsg = [...hist].reverse().find((m) => m.role === 'user' && m.content)?.content
  const l = await registrar(u, convId, d, text, { acao: String(ultimaAcao || '').replace(/⟦[^⟧]*⟧/g, '').slice(0, 200), contexto: String(ultimaMsg || '').slice(0, 200) })
  await nasConversa(u, convId, d.regra)
  return { reply: d.pura ? reconhecimento(d) : null, aprendido: l }
}
const hist_ = (r: Pick<LearningRow, 'history'> | null, acao: string) => hist(r, acao)

/* ---------- recuperação contextual ---------- */
/** Aprendizados RELEVANTES para a mensagem (por operação, empresa, escopo, confiança e atualidade). Nunca carrega tudo. */
export async function recuperar(u: SessionUser, text: string, opts: { convId?: string; empresaId?: number | null; limite?: number; marcarUso?: boolean; padroes?: LearningRow[] } = {}): Promise<Aprendizado[]> {
  if (!(await ativo(u))) return []
  const ops = operacoesDaMensagem(text), lista: string[] = [...ops, 'geral']
  const rows = await q<LearningRow>(`SELECT * FROM learnings WHERE user_id = $1 AND state = 'ativo' AND review_status <> 'rejeitado' AND kind <> 'descoberta' AND operation IN (${lista.map((_, i) => '$' + (i + 2)).join(',')}) AND (scope = 'permanente' OR (scope = 'pontual' AND conversation_id = $${lista.length + 2}))`, [u.id, ...lista, opts.convId || '-'])
  // padrões de uso vêm na MESMA consulta (sem leitura extra no turno) e seguem à parte: não são regras
  if (opts.padroes) opts.padroes.push(...rows.filter((r) => r.kind === 'padrao_uso'))
  const agora = Date.now()
  const pontuado = rows.filter((r) => r.kind !== 'padrao_uso').map(out).filter((a) => !a.empresaId || a.empresaId === (opts.empresaId ?? a.empresaId)).map((a) => {
    const idadeDias = (agora - new Date(a.atualizadoEm).getTime()) / 86400000
    return { a, s: a.confianca * (1 - Math.min(0.4, idadeDias / 730)) + Math.min(0.1, a.frequencia * 0.02) }
  }).filter((x) => x.s >= 0.5 && !(x.a.operacao === 'geral' && ops.length && x.a.kind !== 'estilo'))
    .sort((x, y) => y.s - x.s).slice(0, opts.limite || 5).map((x) => x.a)
  if (pontuado.length && opts.marcarUso !== false) await q(`UPDATE learnings SET uses = uses + 1, last_used_at = $1 WHERE id IN (${pontuado.map((_, i) => '$' + (i + 2)).join(',')})`, [nowIso(), ...pontuado.map((a) => a.id)])
  return pontuado
}

/** Bloco para o prompt da IA: orienta o comportamento sem nunca mencionar a memória. */
export async function contextoIA(u: SessionUser, text: string, convId: string): Promise<string> {
  const linhasPadrao: LearningRow[] = []
  const ls = await recuperar(u, text, { convId, padroes: linhasPadrao }).catch(() => [])
  let corr: string[] = []
  try { corr = (await (await import('./convctx.js')).getCtx(convId, u.id)).correcoes || [] } catch { /* opcional */ }
  // padrões observados no uso real (ai/aprendizado-uso.ts): só os do domínio deste pedido, rotulados como hipótese
  const conceitual = (await import('./guia.js')).classificar(text) === 'explicacao' // "o que é uma agenda?": padrões pessoais não entram
  const pad = conceitual ? '' : await (await import('./aprendizado-uso.js')).contextoIA(u, operacoesDaMensagem(text), linhasPadrao).catch(() => '')
  // camada COLETIVA (ai/aprendizado-coletivo.ts, índice em memória): só entra quando não há nada individual — o que é
  // deste usuário (aprendizados, padrões, correções da conversa) sempre prevalece sobre o conhecimento de todos
  if (!ls.length && !corr.length) return pad || (conceitual ? '' : (await import('./aprendizado-coletivo.js')).contextoIA(text))
  const linhas = ls.map((a) => (a.kind === 'preferencia_inferida' ? `- (sugestão, só se ele não disser o contrário) ${a.regra}` : `- ${a.regra}`))
  for (const c of corr) if (!ls.some((a) => a.regra === c)) linhas.push(`- (nesta conversa) ${c}`)
  return (pad ? pad + '\n\n' : '') + `Preferências operacionais deste usuário — aplique-as naturalmente no fluxo. Permissões, validações financeiras e regras de negócio continuam valendo. NUNCA diga que está consultando memória, que aprendeu, que registrou ou que ele já corrigiu isso antes; apenas aja assim:\n${linhas.join('\n')}`
}

/* ---------- prevenção de erros recorrentes ---------- */
const HM = (m: number) => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0')
const toMin = (hm: string | undefined) => { const [h, m] = String(hm || '').split(':').map(Number); return Number.isFinite(h) ? h * 60 + (m || 0) : -1 }
const dm = (iso: string) => iso.slice(8, 10) + '/' + iso.slice(5, 7)
async function agendaDoDia(userId: number, date: string) {
  return (await q("SELECT id, status, data FROM items WHERE user_id = $1 AND type = 'appointment' AND day = $2", [userId, date])).filter((r) => r.status !== 'cancelled').map((r) => { const d = J<ApptData>(r.data, {}); return { t: String(d.time || ''), min: toMin(d.time), titulo: String(d.title || 'compromisso') } }).sort((a, b) => a.min - b.min)
}
async function regrasDe(u: SessionUser, operacao: string, convId: string, kinds: string[]) {
  if (!(await ativo(u))) return []
  const rows = await q<LearningRow>(`SELECT * FROM learnings WHERE user_id = $1 AND operation = $2 AND state = 'ativo' AND review_status <> 'rejeitado' AND confidence >= 0.6 AND kind IN (${kinds.map((_, i) => '$' + (i + 3)).join(',')}) AND (scope = 'permanente' OR (scope = 'pontual' AND conversation_id = $${kinds.length + 3}))`, [u.id, operacao, ...kinds, convId || '-'])
  if (rows.length) await q(`UPDATE learnings SET uses = uses + 1, last_used_at = $1 WHERE id IN (${rows.map((_, i) => '$' + (i + 2)).join(',')})`, [nowIso(), ...rows.map((r) => r.id)])
  return rows.map(out)
}
/** Antes de gravar um compromisso: se o usuário pediu "consulte a disponibilidade", confere a agenda dele. Não bloqueia sem motivo:
 *  horário livre → segue (com aviso natural); conflito/intervalo → propõe alternativas e NÃO grava. */
export async function guardarAgendamento(u: SessionUser, convId: string, c: { date?: string; time?: string; title?: string }): Promise<{ reply?: string; prefixo?: string }> {
  const regras = await regrasDe(u, 'agendamento', convId, ['consultar_antes', 'considerar_intervalo']).catch(() => [])
  if (!regras.length || !c.date) return {}
  const consulta = regras.some((r) => r.kind === 'consultar_antes'), intervalo = regras.some((r) => r.kind === 'considerar_intervalo')
  const ocup = await agendaDoDia(u.id, c.date), min = toMin(c.time || '')
  const livres = () => { const r: string[] = []; for (let m = 8 * 60; m <= 18 * 60 && r.length < 3; m += 60) { if (intervalo && m >= 12 * 60 && m < 14 * 60) continue; if (!ocup.some((o) => o.min >= 0 && Math.abs(o.min - m) < 60)) r.push(HM(m)) } return r }
  if (intervalo && min >= 12 * 60 && min < 14 * 60) return { reply: `Esse horário cai no intervalo de almoço. Posso marcar ${livres().join(', ') || 'em outro horário'} em ${dm(c.date)}. Qual prefere?` }
  const conf = min >= 0 ? ocup.find((o) => o.min >= 0 && Math.abs(o.min - min) < 60) : null
  if (consulta && conf) return { reply: `Conferi a agenda: em ${dm(c.date)} às ${conf.t} você já tem "${conf.titulo}". Tenho livre ${livres().join(', ') || 'outros horários'}. Qual prefere?` }
  return consulta ? { prefixo: 'Conferi a disponibilidade e está livre. ' } : {}
}
/** Quando o agendamento ainda está incompleto, a pergunta já traz a disponibilidade do dia (se o usuário pediu para conferir). */
export async function disponibilidadeNaPergunta(u: SessionUser, convId: string, c: { date?: string }): Promise<string> {
  const regras = await regrasDe(u, 'agendamento', convId, ['consultar_antes']).catch(() => [])
  if (!regras.length) return ''
  if (!c.date) return 'Claro! Vou conferir os horários disponíveis primeiro. '
  const ocup = await agendaDoDia(u.id, c.date)
  return `Claro! Vou conferir os horários disponíveis primeiro. ${ocup.length ? `Em ${dm(c.date)} você já tem: ${ocup.map((o) => `${o.t} ${o.titulo}`).join('; ')}.` : `Em ${dm(c.date)} sua agenda está livre.`} `
}
/** Ação que o usuário pediu para confirmar antes de executar (ex.: agendar, registrar). A mensagem "sim" libera. */
export async function exigeConfirmacao(u: SessionUser, operacao: string, convId: string, textoAtual: string): Promise<boolean> {
  if (/^(sim|pode|confirmo|isso|ok|certo|claro|pode sim|manda ver|fechado)\b/.test(norm(textoAtual))) return false
  return (await regrasDe(u, operacao, convId, ['confirmar_antes'])).length > 0
}

/* ---------- padrões de uso (preferências inferidas, confiança proporcional à repetição) ---------- */
export async function observarUso(u: SessionUser, convId: string, replyContent: string) {
  if (!(await ativo(u))) return
  { const AU = await import('./aprendizado-uso.js'); AU.marcarSujo(u.id); AU.agendarRecalculo(u, 250) } // a ação deste turno entra nos padrões logo depois da resposta (fora da mensagem)
  for (const m of String(replyContent || '').matchAll(/⟦appt:(\d+)⟧/g)) {
    const r = await one("SELECT data FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(m[1]), u.id]); const d = J<ApptData>(r?.data, {})
    if (!d.time) continue
    await inferir(u, convId, 'agendamento', `Costuma agendar compromissos por volta das ${String(d.time).slice(0, 2)}:00.`, `horario ${String(d.time).slice(0, 2)}`)
    if (d.location) await inferir(u, convId, 'agendamento', `Costuma marcar compromissos em: ${String(d.location).slice(0, 60)}.`, `local ${norm(d.location)}`)
  }
}
async function inferir(u: SessionUser, convId: string, operacao: string, regra: string, chave: string) {
  const ex = await one<LearningRow>("SELECT * FROM learnings WHERE user_id = $1 AND kind = 'preferencia_inferida' AND operation = $2 AND context = $3", [u.id, operacao, chave])
  if (ex) { const f = Number(ex.frequency) + 1; await q('UPDATE learnings SET frequency = $1, confidence = $2, history = $3, updated_at = $4 WHERE id = $5', [f, Math.min(0.85, 0.2 + 0.15 * f), hist(ex, 'observado'), nowIso(), ex.id]); return }
  const now = nowIso()
  await q("INSERT INTO learnings (user_id, conversation_id, operation, kind, context, rule, scope, confidence, frequency, uses, state, history, created_at, updated_at) VALUES ($1,$2,$3,'preferencia_inferida',$4,$5,'permanente',0.35,1,0,'ativo',$6,$7,$7)", [u.id, convId || null, operacao, chave, regra, JSON.stringify([{ em: now, acao: 'observado' }]), now])
}

/* ---------- gestão pelo próprio usuário ---------- */
export async function listar(userId: number) { return (await q<LearningRow>("SELECT * FROM learnings WHERE user_id = $1 AND state NOT IN ('substituido','bloqueado') AND kind <> 'descoberta' ORDER BY id DESC LIMIT 300", [userId])).map(out) } // padrões de uso aparecem (a pessoa vê e apaga); o estado das perguntas de descoberta é interno
export async function atualizar(userId: number, id: number, p: { regra?: string; estado?: string }) {
  const r = await one<LearningRow>('SELECT * FROM learnings WHERE id = $1 AND user_id = $2', [id, userId]); if (!r) return null
  const regra = p.regra !== undefined ? String(p.regra).trim().slice(0, 200) : r.rule
  if (!regra) return null
  if (p.regra !== undefined && inseguro(regra)) return null
  const estado = p.estado === 'ativo' || p.estado === 'pausado' ? p.estado : r.state
  await q('UPDATE learnings SET rule = $1, state = $2, history = $3, updated_at = $4 WHERE id = $5', [regra, estado, hist(r, p.regra !== undefined ? 'editado_pelo_usuario' : estado, { de: r.rule }), nowIso(), id])
  if (r.kind === 'padrao_uso') (await import('./aprendizado-uso.js')).invalidar(userId) // pausar/reativar um padrão vale na hora
  return out(await relerAprendizado(id))
}
// padrão de uso apagado pela pessoa fica BLOQUEADO (nunca mais usado nem recriado pelo recálculo); o resto é apagado de fato
export async function excluir(userId: number, id: number) { await q("UPDATE learnings SET state = 'bloqueado', updated_at = $1 WHERE id = $2 AND user_id = $3 AND kind = 'padrao_uso'", [nowIso(), id, userId]); await q("DELETE FROM learnings WHERE id = $1 AND user_id = $2 AND kind <> 'padrao_uso'", [id, userId]); (await import('./aprendizado-uso.js')).invalidar(userId) }
export async function excluirTodos(userId: number) { await q("UPDATE learnings SET state = 'bloqueado', updated_at = $1 WHERE user_id = $2 AND kind = 'padrao_uso'", [nowIso(), userId]); await q("DELETE FROM learnings WHERE user_id = $1 AND kind <> 'padrao_uso'", [userId]); (await import('./aprendizado-uso.js')).invalidar(userId) }

/* ---------- camada 3 (global): só SUGERE ao administrador; promover cria RASCUNHO no Laboratório (precisa de testes e aprovação) ---------- */
export async function sugestoesGlobais() {
  const rows = await q("SELECT operation, kind, rule, user_id FROM learnings WHERE state = 'ativo' AND scope = 'permanente' AND confidence >= 0.6 AND kind <> 'preferencia_inferida' AND kind <> 'estilo' AND kind NOT IN ('padrao_uso','descoberta')")
  const g = new Map<string, { operacao: string; kind: string; regra: string; usuarios: Set<number> }>()
  for (const r of rows) { const k = r.operation + '|' + r.kind; const e = g.get(k) || { operacao: r.operation, kind: r.kind, regra: r.rule, usuarios: new Set<number>() }; e.usuarios.add(Number(r.user_id)); g.set(k, e) }
  return [...g.values()].filter((e) => e.usuarios.size >= 2).map((e) => ({ operacao: e.operacao, kind: e.kind, regraModelo: e.regra, usuarios: e.usuarios.size })).sort((a, b) => b.usuarios - a.usuarios)
}
export async function promoverParaLaboratorio(adminId: number, operacao: string, kind: string) {
  const s = (await sugestoesGlobais()).find((x) => x.operacao === operacao && x.kind === kind)
  if (!s) return null
  const L = await import('./lab.js')
  return L.criar('administrador', adminId, { texto: `Regra sugerida por vários usuários: ${s.regraModelo}`, categoria: operacao === 'agendamento' ? 'Agendamentos' : operacao === 'financeiro' ? 'Financeiro' : 'Atendimento' })
}
/* ---------- revisão pelo administrador ---------- */
export const REVISOES = ['pendente', 'aprovado', 'rejeitado', 'editado'] as const
export async function filaRevisao(f: { status?: string; usuario?: string; operacao?: string; busca?: string; limite?: number; tipo?: string } = {}) {
  // padrões de uso e descoberta não são regras para revisar; tipo = 'padroes' mostra os padrões observados (auditoria, só leitura)
  const w: string[] = f.tipo === 'padroes' ? ["l.kind = 'padrao_uso'", "l.state <> 'bloqueado'"] : ["l.state <> 'substituido'", "l.kind NOT IN ('padrao_uso','descoberta')"], a: unknown[] = []
  if (f.tipo === 'padroes') f = { ...f, status: '' }
  const add = (sql: string, v: unknown) => { a.push(v); w.push(sql.replace('?', '$' + a.length)) }
  if (f.status && (REVISOES as readonly string[]).includes(f.status)) add('l.review_status = ?', f.status)
  if (f.operacao) add('l.operation = ?', f.operacao)
  if (f.usuario) { if (/^\d+$/.test(f.usuario)) add('l.user_id = ?', Number(f.usuario)); else { a.push('%' + f.usuario.toLowerCase() + '%'); w.push(`(LOWER(u.name) LIKE $${a.length} OR LOWER(u.email) LIKE $${a.length})`) } }
  if (f.busca) add('LOWER(l.rule) LIKE ?', '%' + f.busca.toLowerCase() + '%')
  const rows = await q<LearningRow & { user_name: string | null; user_email: string | null }>(`SELECT l.*, u.name AS user_name, u.email AS user_email FROM learnings l JOIN users u ON u.id = l.user_id WHERE ${w.join(' AND ')} ORDER BY (CASE WHEN l.review_status = 'pendente' THEN 0 ELSE 1 END), l.id DESC LIMIT ${Math.min(200, f.limite || 100)}`, a)
  return rows.map((r) => ({ ...out(r), usuario: { id: Number(r.user_id), nome: r.user_name || '', email: r.user_email || '' }, correcao: r.correction ? String(r.correction).slice(0, 160) : null }))
}
export async function contagemRevisao() {
  const rows = await q("SELECT review_status AS s, COUNT(*) AS n FROM learnings WHERE state <> 'substituido' AND kind NOT IN ('padrao_uso','descoberta') GROUP BY review_status")
  const o: Record<string, number> = { pendente: 0, aprovado: 0, rejeitado: 0, editado: 0 }
  for (const r of rows) o[r.s] = Number(r.n)
  return o
}
/** Revisão do administrador. 'editar' passa pela mesma validação de segurança; rejeitar interrompe o uso sem apagar o dado do usuário. */
export async function revisar(adminId: number, id: number, acao: 'aprovar' | 'rejeitar' | 'editar' | 'reabrir', p: { regra?: string; nota?: string } = {}) {
  const r = await one<LearningRow>('SELECT * FROM learnings WHERE id = $1', [id]); if (!r) return null
  const nota = p.nota ? String(p.nota).trim().slice(0, 300) : null
  let status: string, regra = r.rule, original = r.original_rule
  if (acao === 'editar') {
    regra = String(p.regra || '').trim().slice(0, 200)
    if (!regra || inseguro(regra)) return 'invalido' as const
    if (regra === r.rule) return 'invalido' as const
    original = original || r.rule; status = 'editado'
  } else status = acao === 'aprovar' ? 'aprovado' : acao === 'rejeitar' ? 'rejeitado' : 'pendente'
  await q('UPDATE learnings SET rule = $1, review_status = $2, reviewed_by = $3, reviewed_at = $4, review_note = $5, original_rule = $6, history = $7, updated_at = $4 WHERE id = $8',
    [regra, status, adminId, nowIso(), nota, original || null, hist(r, 'revisao_' + status, { por: adminId, de: acao === 'editar' ? r.rule : undefined }), id])
  const novo = out(await relerAprendizado(id))
  if (acao === 'editar') await nasConversa({ id: Number(r.user_id) } as SessionUser, r.conversation_id || '', regra).catch(() => {})
  return { ...novo, usuarioId: Number(r.user_id) }
}
export async function resumoAdmin() {
  const r = await one("SELECT COUNT(*) AS total, COUNT(DISTINCT user_id) AS usuarios FROM learnings WHERE state = 'ativo'")
  const porOp = await q("SELECT operation, COUNT(*) AS n FROM learnings WHERE state = 'ativo' GROUP BY operation")
  return { ...(await estadoGlobal()), revisao: await contagemRevisao(), total: Number(r?.total || 0), usuarios: Number(r?.usuarios || 0), porOperacao: Object.fromEntries(porOp.map((x) => [x.operation, Number(x.n)])), sugestoes: await sugestoesGlobais() }
}
