// Visão (leitura de imagens) no motor multi-IA: QUEM pode receber uma imagem e EM QUE FORMATO.
// Antes, a capacidade "imagem" vinha só do botão do painel: um modelo só de texto marcado como "lê imagens" recebia a foto e
// falhava, e um modelo com visão deixado sem a marca nunca era usado. Agora:
//  • o modelo é reconhecido pelo nome — com visão conhecida (Gemini, Claude 3+, GPT-4o/4.1/5, Llama 4, Llama 3.2 Vision, Qwen-VL,
//    Pixtral, Gemma 3, LLaVA…) ou SÓ TEXTO conhecido (DeepSeek, GPT-3.5, Llama 3.1/3.3, Mixtral, o1-mini/o3-mini…);
//  • a escolha explícita do administrador (caps.imagem) sempre vale;
//  • cada tipo de API só recebe os formatos e tamanhos que aceita (HEIC só no Gemini; Claude até 5 MB por imagem…);
//  • o tipo real do arquivo é conferido pelos bytes (não pelo nome nem pelo que o navegador declarou).
import type { Kind } from './types.js'

const VISAO = /(gemini|gemma-?3|claude-(3|sonnet|opus|haiku)|claude-[4-9]|gpt-4o|gpt-4\.1|gpt-4-turbo|gpt-4-vision|gpt-4\.5|gpt-5|chatgpt-4o|\bo1\b(?!-mini)|\bo1-(?!mini)|\bo3\b(?!-mini)|\bo3-(?!mini)|\bo4-mini|llama-?4|llama-?3\.2-?(11|90)b-?vision|vision|llava|bakllava|moondream|minicpm-?v|qwen[\d.]*-?vl|qvq|pixtral|mistral-(small|medium)-(3\.[1-9]|25|latest)|grok-(2-vision|4)|glm-?4\.?\d?v|internvl|phi-?(3\.5|4)-(vision|multimodal)|deepseek-vl|granite-vision|kimi-vl|nova-(lite|pro))/i
const SO_TEXTO = /(deepseek-(chat|reasoner|r1|v3|coder)|gpt-3\.5|text-davinci|\bo1-mini|\bo3-mini|llama-?3(\.1|\.3)?-?(8|70|405)b(?!.*vision)|llama3(\.1|\.3)?(:|$)|mixtral|mistral-(tiny|7b|nemo|large)|codestral|qwen[\d.]*-?(coder|\d+b)(?!.*vl)|qwq|gemma-?2|gemma-7b|command-r|phi-?3-(mini|medium)(?!.*vision)|kimi-k2|gpt-oss|llama-guard|whisper|embed)/i
/** true = o modelo enxerga imagens; false = só texto (conhecido); null = desconhecido (vale a marca do painel). */
export function visaoDoModelo(modelo: string): boolean | null {
  const m = String(modelo || '').toLowerCase().trim(); if (!m) return null
  if (VISAO.test(m)) return true
  if (SO_TEXTO.test(m)) return false
  return null
}
/** Formatos de imagem aceitos por tipo de API (documentação de cada serviço). */
export const MIMES: Record<Kind, string[]> = {
  gemini: ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'],
  anthropic: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  openai: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
}
/** Tamanho máximo de UMA imagem enviada embutida (bytes do arquivo). */
export const MAX_BYTES: Record<Kind, number> = { gemini: 18 * 1024 * 1024, anthropic: Math.floor(3.7 * 1024 * 1024) /* 5 MB depois do base64 */, openai: 19 * 1024 * 1024 }
export function aceita(kind: Kind, mime: string, bytes: number) { return MIMES[kind].includes(mime) && bytes <= MAX_BYTES[kind] }

/** Tipo real e dimensões pelos bytes. null = não é uma imagem reconhecível (arquivo corrompido, vazio ou outro formato). */
export function examinar(b: Buffer): { mime: string; largura: number | null; altura: number | null } | null {
  if (!b || b.length < 12) return null
  const asc = (i: number, n: number) => b.subarray(i, i + n).toString('latin1')
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) {
    for (let i = 2; i < b.length - 9;) {
      if (b[i] !== 0xff) { i++; continue }
      const m = b[i + 1]
      if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { mime: 'image/jpeg', altura: b.readUInt16BE(i + 5), largura: b.readUInt16BE(i + 7) }
      if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { i += 2; continue }
      i += 2 + b.readUInt16BE(i + 2)
    }
    return { mime: 'image/jpeg', largura: null, altura: null }
  }
  if (b.readUInt32BE(0) === 0x89504e47) return { mime: 'image/png', largura: b.length >= 24 ? b.readUInt32BE(16) : null, altura: b.length >= 24 ? b.readUInt32BE(20) : null }
  if (asc(0, 4) === 'RIFF' && asc(8, 4) === 'WEBP') {
    const t = asc(12, 4)
    if (t === 'VP8X' && b.length >= 30) return { mime: 'image/webp', largura: 1 + b.readUIntLE(24, 3), altura: 1 + b.readUIntLE(27, 3) }
    if (t === 'VP8 ' && b.length >= 30) return { mime: 'image/webp', largura: b.readUInt16LE(26) & 0x3fff, altura: b.readUInt16LE(28) & 0x3fff }
    if (t === 'VP8L' && b.length >= 25) { const v = b.readUInt32LE(21); return { mime: 'image/webp', largura: (v & 0x3fff) + 1, altura: ((v >> 14) & 0x3fff) + 1 } }
    return { mime: 'image/webp', largura: null, altura: null }
  }
  if (asc(0, 6) === 'GIF87a' || asc(0, 6) === 'GIF89a') return { mime: 'image/gif', largura: b.readUInt16LE(6), altura: b.readUInt16LE(8) }
  if (asc(4, 4) === 'ftyp') {
    const marca = asc(8, 4)
    if (/^(heic|heix|hevc|hevx|heim|heis)$/.test(marca)) return { mime: 'image/heic', largura: null, altura: null }
    if (/^(mif1|msf1|heif)$/.test(marca)) return { mime: 'image/heif', largura: null, altura: null }
    if (/^avi[fs]$/.test(marca)) return { mime: 'image/avif', largura: null, altura: null }
    return null
  }
  if (asc(0, 2) === 'BM' && b.length >= 26) return { mime: 'image/bmp', largura: b.readInt32LE(18), altura: Math.abs(b.readInt32LE(22)) }
  if (asc(0, 4) === 'II*\0' || asc(0, 4) === 'MM\0*') return { mime: 'image/tiff', largura: null, altura: null }
  return null
}
export const NOME_FORMATO: Record<string, string> = { 'image/heic': 'HEIC', 'image/heif': 'HEIF', 'image/avif': 'AVIF', 'image/bmp': 'BMP', 'image/tiff': 'TIFF', 'image/gif': 'GIF', 'image/jpeg': 'JPG', 'image/png': 'PNG', 'image/webp': 'WEBP' }
