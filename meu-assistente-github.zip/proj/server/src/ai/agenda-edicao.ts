// EDIÇÃO DE COMPROMISSOS PELO CHAT (sem IA) — "altere o valor do compromisso de Santos para 250", "troque o horário de Santos
// para 20h", "adicione o telefone desse cliente", "marque esse compromisso como concluído".
//  • identifica UM compromisso: pelo cliente citado ("de Santos") entre os compromissos DESTE usuário, ou pelo compromisso citado
//    nesta conversa ("esse", "desse cliente"); com mais de um candidato pergunta qual — nunca escolhe às cegas;
//  • altera pela ação oficial da agenda (itemAction 'appointment_update': mesmas validações, histórico e avisos da tela);
//  • relê o registro e só diz "Pronto" quando o banco confirma; o que faltar (ex.: o número do telefone) é perguntado.
import type { SessionUser } from '../lib/session.js'
import { q, J } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { localDate } from '../lib/time.js'
import { normalizarTelefone } from './agendamento-chat.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const VERBO = /^(?:(?:por favor|pfv|agora|entao|e|so|apenas|tambem|pode|voce pode|vc pode|eu|quero|queria|gostaria de|preciso|vamos)\s+)*(?:adicionar|colocar|incluir|acrescentar|definir|remarcar|corrigir|ajustar|renomeie|renomear|renomeia|modifique|modifica|modificar|edite|edita|editar|cancele|cancela|cancelar|desmarque|desmarca|tire|tira|remova|remove|altere|altera|alterar|mude|muda|mudar|troque|troca|trocar|atualize|atualiza|atualizar|coloque|coloca|ponha|poe|adicione|adiciona|acrescente|acrescenta|inclua|inclui|marque|marca|defina|define|passe|passa|remarque|remarca|registre|registra|corrija|corrige|ajuste|ajusta|bote|bota)\b/
const CAMPO = /\b(compromisso|agendamento|reuniao|consulta|dentista|exame|evento|sessao|visita|entrevista|aula|nome|titulo|prioridade|prioritari[oa]|urgente|lembrete|aviso|horario|hora|valor|total|telefone|celular|whats\w*|contato|numero|cliente|sinal|pagamento|pago|local|endereco|observac\w+|obs|duracao|responsavel|concluid[oa]|finalizad[oa]|confirmad[oa]|nao compareceu|faltou|situacao|status|data|dia)\b/
const STATUS: [RegExp, string, string][] = [[/\b(concluid[oa]|finalizad[oa]|feito|realizad[oa]|atendid[oa])\b/, 'done', 'Concluído'], [/\b(nao compareceu|faltou|no.?show)\b/, 'no_show', 'Não compareceu'], [/\bconfirmad[oa]\b/, 'confirmed', 'Confirmado'], [/\b(agendad[oa]|pendente)\b/, 'scheduled', 'Agendado']]
const brl = (n: number | null | undefined) => n == null ? '—' : 'R$ ' + Number(n).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const fmtTel = (t: string) => String(t || '').replace(/^(\d{2})(\d{4,5})(\d{4})$/, '($1) $2-$3') || '—'
const numBR = (t: string) => { let x = String(t).trim(); if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(x)) x = x.replace(/\./g, ''); return Number(x.replace(',', '.')) }
const VALOR = String.raw`(?:para|pra|por|em|de|:|=)\s*(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)(?!\s*(?:h\b|horas?|:\d|%))`

/** É pedido de alteração de compromisso existente? (não é criação, nem comando da empresa)
 *  `contexto`: a última ação desta conversa foi um compromisso — frases curtas sem o nome do campo ("altere para amanhã",
 *  "pode cancelar", "acrescente essa informação") valem como edição dele (o motor de prioridade já decidiu que é continuação). */
export function ehEdicao(text: string, contexto = false): boolean {
  const s = nrm(text)
  if (!VERBO.test(s) || (!CAMPO.test(s) && !contexto)) return false
  if (/\b(agende|agendar|agenda um|agenda uma|novo compromisso|nova consulta)\b/.test(s)) return false // criação
  if (/^(?:marque|marca)\b/.test(s) && !/\bcomo\b/.test(s)) return false // "marque uma reunião amanhã" = criar
  if (/\b(funcionamento|loja|catalogo|produto|estoque|frete|empresa|lista de compras|tarefa|lembrete)\b/.test(s)) return false
  if (contexto) return true
  return /\b(compromisso|agendamento|atendimento|sessao|tatuagem|consulta|horario|cliente|esse|desse|deste|este|dele|dela)\b/.test(s) || /\b(?:de|do|da)\s+[A-ZÀ-Ý]/.test(text)
}

/** O que mudar, só com o que foi dito. `falta` = o campo pedido sem o valor (ex.: "adicione o telefone" sem número). */
export function lerMudancas(text: string, dataDe: (t: string) => string | undefined = () => undefined): { campos: any; falta?: string; rotulos: string[] } {
  const s = nrm(text), campos: any = {}, rotulos: string[] = []
  for (const [re, st, rot] of STATUS) if (/\b(como|para|pra|status|situacao)\b/.test(s) && re.test(s)) { campos.status = st; rotulos.push('situação: ' + rot); break }
  if (/\bcomo cancelad[oa]\b|\bcancel|\bdesmarc/.test(s)) campos.cancelar = true
  // telefone
  const tm = text.match(/((?:\+?55\s*)?\(?\d{2}\)?[\s.-]*9?[\s.-]*\d{4}[\s.-]?\d{4})/)
  if (/\b(telefone|celular|whats\w*|contato|numero)\b/.test(s)) { const t = tm ? normalizarTelefone(tm[1]) : ''; if (t) campos.cliente_telefone = t; else return { campos: {}, falta: 'telefone', rotulos } }
  const semTel = tm ? s.replace(nrm(tm[1]), ' ') : s
  // valores: sinal, valor pago, valor total (nessa ordem: "valor pago" não é o total)
  let m: RegExpMatchArray | null
  if ((m = semTel.match(new RegExp(String.raw`\bsinal\b[^\d]{0,25}?${VALOR}\s*(%|por cento)?`)))) { if (m[2]) campos.sinal_pct = numBR(m[1]); else campos.sinal = numBR(m[1]) }
  else if ((m = semTel.match(new RegExp(String.raw`\b(?:valor pago|ja pagou|pagou|recebi|pago)\b[^\d]{0,20}?${VALOR}`)))) campos.valor_pago = numBR(m[1])
  else if ((m = semTel.match(new RegExp(String.raw`\b(?:valor(?: total)?|total|preco)\b[^\d]{0,40}?${VALOR}`)))) campos.valor_total = numBR(m[1])
  else if (/\b(valor|total|sinal)\b/.test(semTel)) return { campos: {}, falta: 'valor', rotulos }
  // horário e data (só quando o pedido fala deles)
  const antec = /\b(lembr\w*|avis\w*|lembrete|aviso)\b.*\bantes\b/.test(s) // "me avise 2 horas antes": antecedência, não horário nem data
  if (!antec && /\b(horario|hora|para as|pras|as \d|remarc)\b/.test(s) || /\bpara (?:as )?\d{1,2}(?:[:h]\d{2})?\s*h?\b/.test(semTel) && !campos.valor_total && !campos.sinal && !campos.valor_pago) {
    const t = semTel.match(/\b(?:para|pra|pras|as)\s*(?:as\s*)?(\d{1,2})(?:[:h](\d{2}))?\s*(?:h|horas?)?\b/) || semTel.match(/\b(\d{1,2})[:h](\d{2})\b/)
    if (t) { let hh = Number(t[1]); const mm = Number(t[2] || 0); if (/\b(da noite|a noite|da tarde|a tarde)\b/.test(s) && hh < 12) hh += 12; if (hh <= 23 && mm <= 59) campos.time = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}` }
    else if (/\b(horario|hora)\b/.test(s)) return { campos: {}, falta: 'horario', rotulos }
  }
  if (!antec && /\b(data|dia|remarc|amanha|hoje|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/.test(s) && /\b(para|pra)\b/.test(s)) {
    const dt = dataDe(text); if (dt) campos.date = dt
  }
  // local, observação, responsável, duração, nome do cliente
  if ((m = text.match(/\b(?:local|endere[çc]o)\b[^:]*?(?:para|pra|:)\s*(.{2,120}?)\s*$/i))) campos.location = m[1].replace(/[.!]+$/, '').trim()
  if ((m = text.match(/\bobserva[çc](?:[ãa]o|[õo]es)\b[^:]*?(?::|para|pra|que)\s*(.{2,500}?)\s*$/i))) campos.observacao = m[1].replace(/[.!]+$/, '').trim()
  if ((m = text.match(/\brespons[áa]vel\b[^:]*?(?:para|pra|:|é)\s*(?:o |a )?([A-Za-zÀ-ÿ][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+){0,2})/i))) campos.responsavel = m[1].replace(/^./, (x) => x.toUpperCase())
  if ((m = s.match(/\bduracao\b[^\d]{0,20}?(\d+(?:[.,]\d+)?)\s*(h|hs|horas?|min|minutos?)\b/))) { const v = Number(m[1].replace(',', '.')); campos.duracao_min = Math.round(/^h/.test(m[2]) ? v * 60 : v) }
  if ((m = text.match(/\bnome d[oa] client[ea]\b[^:]*?(?:para|pra|:|é)\s*([A-Za-zÀ-ÿ][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+){0,2})/i)) || (m = text.match(/\bclient[ea]\s+(?:para|pra|por|:)\s*(?:o |a )?([A-ZÀ-Ý][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+){0,2})/i))) campos.cliente_nome = m[1].replace(/^./, (x) => x.toUpperCase())
  // nome do compromisso ("troque o nome para Reunião do contrato", "renomeie para Dentista")
  if ((m = text.match(/\b(?:nome|t[ií]tulo)\b(?:\s+d[oa]\s+(?:compromisso|evento|reuni[aã]o|agendamento|consulta))?\s*(?:para|pra|por|:)\s*["“]?(.{2,120}?)["”]?\s*[.!]*$/i)) || (m = text.match(/^\s*(?:\S+\s+){0,3}?renome\w*\s+(?:\S+\s+){0,3}?(?:para|pra|como)\s+["“]?(.{2,120}?)["”]?\s*[.!]*$/i))) campos.title = m[1].trim().replace(/^./, (x) => x.toUpperCase())
  // prioridade (só no comando, não no texto da observação): "coloque como prioridade", "é urgente", "tire a prioridade"
  { const cmd = nrm(text.split(':')[0]); if (/\b(prioridade|prioritari[oa]|urgente)\b/.test(cmd) && campos.title === undefined) campos.priority = /\b(tir\w*|remov\w*|sem prioridade|prioridade normal|nao e (?:mais )?(?:prioridade|urgente)|normal)\b/.test(cmd) ? 'normal' : 'high' }
  // antecedência do aviso ("altere o lembrete para 60 minutos antes", "me avise 1 dia antes")
  { const cmd = nrm(text.split(':')[0]); const a = cmd.match(/\b(\d{1,5})\s*(min\w*|h|hs|horas?|dias?)\s+(?:de\s+)?antes\b/) || (/\bmeia hora\s+(?:de\s+)?antes\b/.test(cmd) ? ['', '30', 'min'] as any : null)
    if (a && /\b(lembr\w*|avis\w*|lembrete|aviso|notifica\w*|alerta)\b/.test(cmd)) { const n = Number(a[1]); campos.reminder_minutes = /^d/.test(a[2]) ? n * 1440 : /^h/.test(a[2]) ? n * 60 : n; delete campos.time }
    else if (/\b(sem lembrete|sem aviso|nao (?:me )?(?:lembr|avis)\w*)\b/.test(cmd)) campos.reminder_minutes = 0 }
  // endereço/local sem "para" nem ":" ("adicione o endereço Rua das Palmeiras, 50")
  if (campos.location === undefined && (m = text.match(/\b(?:adicion|coloc|inclu|acrescent|bot|ponh|p[oõ]e)\w*\s+(?:tamb[eé]m\s+)?(?:o\s+|um\s+)?(?:endere[çc]o|local)\s+(?:[eé]\s+|fica\s+)?(?!para\b|pra\b)(.{3,120}?)\s*[.!]*$/i))) campos.location = m[1].trim()
  // informação extra sem rótulo de campo: "acrescente essa informação: cliente vem de carro", "inclua mais um detalhe: trazer exames"
  if (campos.observacao === undefined && (m = text.match(/\b(?:informa[çc](?:[ãa]o|[õo]es)|detalhes?|nota|coment[áa]rio)\b[^:]{0,30}:\s*(.{2,500}?)\s*$/i))) campos.observacao = m[1].replace(/[.!]+$/, '').trim()
  if (!Object.keys(campos).length) {
    // campo pedido sem o valor: pergunta só o que falta
    if (/\b(observac\w+|obs|informac\w+|detalhes?|comentario)\b/.test(s)) return { campos: {}, falta: 'observacao', rotulos }
    if (/\b(data|dia)\b/.test(s) && !/\b(horario|hora)\b/.test(s)) return { campos: {}, falta: 'data', rotulos }
    if (/\bclient[ea]\b/.test(s) && !/\bnome\b.*\b(para|pra|:)/.test(s)) return { campos: {}, falta: 'cliente', rotulos }
    if (/^(?:(?:por favor|pfv|agora|entao|e|so|apenas|pode)\s+)*(?:modifi|edit|alter|mud)\w*\s+(?:o |a |esse |essa |este |esta )?(?:compromisso|agendamento|consulta|reuniao|evento|horario marcado)?\s*$/.test(s)) return { campos: {}, falta: 'qualquer', rotulos }
  }
  return { campos, rotulos }
}

/** Cliente citado ("de Santos", "do cliente Santos"). */
export function clienteCitado(text: string): string {
  const m = text.match(/\b(?:d[oa] client[ea]|client[ea]|de|do|da)\s+([A-ZÀ-Ý][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+)?)/)
  if (!m || /^(Amanh|Hoje|Segunda|Ter[çc]a|Quarta|Quinta|Sexta|S[áa]bado|Domingo|R\$|Pix)/i.test(m[1])) return ''
  return m[1]
}

/** Candidatos: compromissos DESTE usuário (não cancelados) do cliente citado; primeiro os de hoje em diante. */
export async function candidatos(u: SessionUser, cliente: string) {
  const hoje = localDate(settingsOf(u).timezone), alvo = nrm(cliente)
  const rows = await q("SELECT id, day, status, data FROM items WHERE user_id = $1 AND type = 'appointment' AND status <> 'cancelled' ORDER BY day, id", [u.id])
  const achou = rows.filter((r: any) => { const d = J<any>(r.data, {}), n = nrm(d.clienteNome || d.person || ''); return n && (n === alvo || n.split(' ').includes(alvo) || n.startsWith(alvo + ' ')) })
  const futuros = achou.filter((r: any) => r.day >= hoje)
  return futuros.length ? futuros : achou.slice(-3)
}

/** Aplica as mudanças pela ação oficial da agenda e confere no banco. */
export async function aplicar(u: SessionUser, id: number, campos: any, tz: string): Promise<{ ok: boolean; content: string; id: number }> {
  const { itemAction, serialize } = await import('../routes/items.js'), { db } = await import('../db/index.js')
  const antes = await q("SELECT id, day, status, data, updated_at, created_at, type FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [id, u.id])
  if (!antes[0]) return { ok: false, content: 'Não encontrei esse compromisso na sua agenda. Nada foi alterado.', id }
  const A: any = serialize({ ...antes[0], data: J<any>(antes[0].data, {}) } as any)
  const d: any = { ...campos, origem: 'chat' }
  if (campos.observacao !== undefined) { d.notes = [A.notes, campos.observacao].filter(Boolean).join(' · '); delete d.observacao } // acrescenta, não apaga o que havia
  try { await db().tx((t: any) => itemAction(u, 'appointment_update', 'appointment', id, d, t)) }
  catch (e: any) { return { ok: false, content: `Não alterei: ${e?.message || 'a agenda recusou a alteração'}`, id } }
  const dep = await q("SELECT id, day, status, data, updated_at, created_at, type FROM items WHERE id = $1 AND user_id = $2", [id, u.id])
  const B: any = serialize({ ...dep[0], data: J<any>(dep[0].data, {}) } as any)
  const L: string[] = [], dif = (rot: string, a: any, b: any, f = (x: any) => String(x ?? '—')) => { if (JSON.stringify(a ?? null) !== JSON.stringify(b ?? null)) L.push(`${rot}: ${f(a)} → ${f(b)}`) }
  dif('Data', A.date, B.date, (x) => String(x).split('-').reverse().join('/')); dif('Horário', A.time, B.time); dif('Cliente', A.clienteNome || null, B.clienteNome || null)
  dif('Telefone', A.clienteTelefone || null, B.clienteTelefone || null, fmtTel); dif('Local', A.location || null, B.location || null); dif('Duração', A.duracaoMin, B.duracaoMin, (x) => x ? x + ' min' : '—')
  dif('Responsável', A.responsavel || null, B.responsavel || null); dif('Valor total', A.valorTotal, B.valorTotal, brl); dif('Sinal', A.sinal, B.sinal, brl); dif('Valor pago', A.valorPago, B.valorPago, brl)
  dif('Situação', A.statusLabel, B.statusLabel); if (campos.observacao !== undefined && A.notes !== B.notes) L.push(`Observações: ${B.notes}`)
  // campos lidos do registro bruto (nome, prioridade e antecedência do aviso)
  const ra = J<any>(antes[0].data, {}), rb = J<any>(dep[0].data, {}), aviso = (x: any) => { const v = Array.isArray(x?.reminders) ? x.reminders : x?.reminderMinutes > 0 ? [x.reminderMinutes] : []; return v.length ? v.map((n: number) => n % 1440 === 0 ? `${n / 1440} dia${n / 1440 > 1 ? 's' : ''}` : n % 60 === 0 ? `${n / 60} h` : `${n} min`).join(' e ') + ' antes' : 'sem aviso' }
  dif('Nome', ra.title, rb.title); dif('Prioridade', ra.priority === 'high' ? 'alta' : 'normal', rb.priority === 'high' ? 'alta' : 'normal')
  if (campos.reminder_minutes !== undefined && aviso(ra) !== aviso(rb)) L.push(`Lembrete: ${aviso(ra)} → ${aviso(rb)}`)
  // confere que o pedido ficou gravado (nunca afirma o que o banco não mostra)
  const conf = (campos.title === undefined || rb.title === campos.title) && (campos.priority === undefined || (rb.priority === 'high' ? 'high' : 'normal') === campos.priority) && (campos.reminder_minutes === undefined || (campos.reminder_minutes > 0 ? JSON.stringify(rb.reminders) === JSON.stringify([campos.reminder_minutes]) : !(rb.reminders || []).length)) && (campos.location === undefined || rb.location === campos.location) && (campos.valor_total === undefined || B.valorTotal === campos.valor_total) && (campos.time === undefined || B.time === campos.time) && (campos.status === undefined || B.status === campos.status) && (campos.cliente_telefone === undefined || B.clienteTelefone === campos.cliente_telefone)
  if (!conf) return { ok: false, content: 'Não consegui confirmar a alteração no banco. Abra o compromisso para conferir — não vou afirmar que mudou.', id }
  const quem = B.clienteNome ? ` de ${B.clienteNome}` : ''
  if (!L.length) return { ok: true, content: `O compromisso "${B.title}"${quem} já estava assim; não mudei nada. ⟦appt:${id}⟧`, id }
  return { ok: true, content: `Pronto! Atualizei "${B.title}"${quem} (${B.date.split('-').reverse().join('/')}${B.time ? ' às ' + B.time : ''}):\n- ${L.join('\n- ')} ⟦appt:${id}⟧`, id }
}
const PERG: Record<string, string> = { telefone: 'Qual é o telefone do cliente?', valor: 'Qual é o novo valor?', horario: 'Para que horário?', data: 'Para que dia?', observacao: 'Qual informação devo acrescentar ao compromisso?', cliente: 'Qual é o nome do cliente?', qualquer: 'O que devo alterar? (horário, data, valor, cliente, telefone ou observação)' }
/** Compromissos futuros (não cancelados) cujo título aparece na frase ("modifique o agendamento do dentista para 10h"). */
export async function candidatosPorTitulo(u: SessionUser, text: string) {
  const hoje = localDate(settingsOf(u).timezone), s = ' ' + nrm(text) + ' '
  const rows = await q("SELECT id, day, status, data FROM items WHERE user_id = $1 AND type = 'appointment' AND status <> 'cancelled' AND day >= $2 ORDER BY day, id LIMIT 200", [u.id, hoje])
  return rows.filter((r: any) => { const t = nrm(J<any>(r.data, {}).title || ''); return t.length >= 4 && (s.includes(' ' + t + ' ') || t.split(' ').filter((w) => w.length >= 5).some((w) => s.includes(' ' + w + ' '))) })
}
export const perguntaFalta = (f: string) => PERG[f] || 'O que devo alterar?'
export const descreverOpcao = (r: any) => { const d = J<any>(r.data, {}); return `${String(r.day).split('-').reverse().join('/')}${d.time ? ' às ' + d.time : ''} — ${d.title}${d.clienteNome ? ' (' + d.clienteNome + ')' : ''}` }
