// Serviço da inteligência preditiva (Fase 7): previsões registradas e conferidas depois, proatividade CONTROLADA
// (preferências, frequência, horário de silêncio, sem repetição), reações do usuário, cenários simulados, retroteste
// com o histórico e indicadores agregados para o painel. Nunca altera registros do usuário.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import * as P from './preditivo.js'

const nrm = (t: string) => String(t ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const pct = (a: number, b: number) => (b ? Math.round((a / b) * 1000) / 10 : null)

/* ---------- análise para um usuário (preferências, chave global, política aprendida) ---------- */
export async function paraUsuario(u: SessionUser, o: { registrar?: boolean } = { registrar: true }) {
  const cfg = await P.predCfg(); if (!cfg.ativo) return { ativo: false, sinais: [] as P.Sinal[], lacunas: [] as string[], ms: 0, falhas: [] as string[], hoje: '' }
  const prefs = await P.prefsPred(u.id)
  const pol = await (await import('./politica.js')).politicaPara(u.id).catch(() => null)
  const dados = await P.carregarDados(u)
  const r = await P.analisar(dados, { prioridades: prefs.prioridades, silenciar: (pol?.politica as any)?.preditivo?.silenciar || [], desligados: cfg.tiposDesligados })
  const sinais = r.sinais.filter((s) => prefs.categorias[s.categoria] !== false)
  if (o.registrar !== false) await registrarPrevisoes(u.id, sinais).catch((e) => console.error('[preditivo] registrar:', e?.message))
  return { ativo: true, ...r, sinais, hoje: dados.hoje }
}
export async function registrarPrevisoes(userId: number, sinais: P.Sinal[]) {
  for (const s of sinais) if (s.previsao) {
    if (await one('SELECT id FROM predictions WHERE user_id = $1 AND pkey = $2', [userId, s.previsao.pkey]).catch(() => null)) continue
    await q('INSERT INTO predictions (user_id, kind, pkey, payload, confidence, expected_from, expected_to, status, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)', [userId, s.previsao.kind, s.previsao.pkey, JSON.stringify(s.previsao.payload), s.confianca, s.previsao.de, s.previsao.ate, 'aberta', nowIso()]).catch(() => {})
  }
}

/* ---------- conferência: a previsão aconteceu? (só com os dados do próprio usuário) ---------- */
export function verificar(kind: string, payload: any, de: string, ate: string, d: P.Dados): boolean | null {
  const dentro = (x: string) => x >= de && x <= ate, passou = d.hoje > ate
  if (kind === 'conta_recorrente') return d.bills.some((b) => nrm(b.name) === nrm(payload.nome) && dentro(String(b.dueDate))) ? true : passou ? false : null
  if (kind === 'retorno_cliente') return d.appointments.some((a) => nrm(a.clienteNome || '') === nrm(payload.cliente) && dentro(a.date) && a.status !== 'cancelled') ? true : passou ? false : null
  if (kind === 'compra_recorrente') return d.shopping.some((s) => nrm(s.name) === nrm(payload.item) && dentro(String(s.createdAt).slice(0, 10))) ? true : passou ? false : null
  if (kind === 'gasto_mes') { if (d.hoje <= de) return null; const tot = d.finance.filter((f) => f.kind === 'expense' && String(f.date).slice(0, 7) === payload.mes && (f.category || 'outros') === payload.categoria).reduce((a, f) => a + Number(f.amount), 0); return tot > payload.media * 1.1 }
  return null
}
/** Confere as previsões em aberto cujo prazo já começou (rotina diária). */
export async function avaliarPrevisoes(limiteUsuarios = 300) {
  const users = ((await q("SELECT DISTINCT user_id FROM predictions WHERE status = 'aberta' LIMIT $1", [limiteUsuarios]).catch(() => [])) as any[]).map((r) => Number(r.user_id))
  let acertos = 0, erros = 0
  for (const uid of users) {
    const ur = await one('SELECT * FROM users WHERE id = $1', [uid]).catch(() => null); if (!ur) continue
    const u = { id: uid, name: ur.name, role: ur.role, settings: J<any>(ur.settings, {}) } as unknown as SessionUser
    const d = await P.carregarDados(u).catch(() => null); if (!d) continue
    for (const p of (await q("SELECT * FROM predictions WHERE user_id = $1 AND status = 'aberta'", [uid])) as any[]) {
      if (String(p.expected_from) > d.hoje) continue
      const v = verificar(String(p.kind), J<any>(p.payload, {}), String(p.expected_from), String(p.expected_to), d); if (v === null) continue
      await q('UPDATE predictions SET status = $1, resolved_at = $2 WHERE id = $3', [v ? 'acertou' : 'errou', nowIso(), p.id]); v ? acertos++ : erros++
    }
  }
  return { usuarios: users.length, acertos, erros }
}

/* ---------- proatividade controlada ---------- */
const LIMITE: Record<string, number> = { baixa: 1, normal: 3, alta: 5 }
const emSilencio = (agoraMin: number, s: { de: string; ate: string }) => { const a = Number(s.de.slice(0, 2)) * 60 + Number(s.de.slice(3)), b = Number(s.ate.slice(0, 2)) * 60 + Number(s.ate.slice(3)); return a === b ? false : a < b ? agoraMin >= a && agoraMin < b : agoraMin >= a || agoraMin < b }
/** Quais sinais podem ser apresentados agora neste canal (sem repetir, sem exagerar, respeitando o usuário). */
export async function escolher(userId: number, sinais: P.Sinal[], canal: 'chat' | 'notificacao', agoraMin: number, max = 1) {
  const prefs = await P.prefsPred(userId), cfg = await P.predCfg()
  if (!prefs.ativo || !(prefs.canais as any)[canal]) return []
  if (canal === 'notificacao' && (!cfg.notificacoes || emSilencio(agoraMin, prefs.silencio))) return []
  const hist = (await q('SELECT ikey, canal, status, created_at FROM predictive_alerts WHERE user_id = $1 AND created_at >= $2', [userId, new Date(Date.now() - 30 * 864e5).toISOString()]).catch(() => [])) as any[]
  const hoje = hist.filter((h) => h.canal === canal && Date.now() - Date.parse(String(h.created_at)) < 864e5).length
  const limite = canal === 'notificacao' ? Math.min(LIMITE[prefs.frequencia] || 3, cfg.limiteDiarioGlobal) : (LIMITE[prefs.frequencia] || 3) + 1
  if (hoje >= limite) return []
  const espera = canal === 'notificacao' ? 7 : 3 // dias sem repetir o mesmo aviso no mesmo canal
  const out: P.Sinal[] = []
  for (const s of sinais) {
    if (canal === 'notificacao' && s.urgencia === 'baixa') continue
    const h = hist.filter((x) => x.ikey === s.chave)
    if (h.some((x) => ['dispensada', 'falso', 'aceita'].includes(x.status))) continue // o usuário já reagiu: não insiste
    if (h.some((x) => x.canal === canal && Date.now() - Date.parse(String(x.created_at)) < espera * 864e5)) continue
    out.push(s); if (out.length >= Math.min(max, limite - hoje)) break
  }
  return out
}
export async function registrarAlerta(userId: number, s: P.Sinal, canal: string) {
  await q('INSERT INTO predictive_alerts (user_id, ikey, tipo, categoria, natureza, confidence, urgencia, canal, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [userId, s.chave, s.tipo, s.categoria, s.natureza, s.confianca, s.urgencia, canal, 'apresentada', nowIso()])
}
/** Reação do usuário: aceita (útil/feito), dispensada, falso (não se aplica = falso alerta) ou adiar (volta depois). */
export async function reagir(userId: number, ikey: string, acao: string) {
  if (!['aceita', 'dispensada', 'falso', 'adiar'].includes(acao)) return { ok: false }
  const r = await one('SELECT id FROM predictive_alerts WHERE user_id = $1 AND ikey = $2 ORDER BY id DESC LIMIT 1', [userId, ikey]).catch(() => null)
  if (acao === 'adiar') { if (r) await q('UPDATE predictive_alerts SET created_at = $1, updated_at = $1 WHERE id = $2', [nowIso(), r.id]); return { ok: true } }
  if (r) await q('UPDATE predictive_alerts SET status = $1, updated_at = $2 WHERE id = $3', [acao, nowIso(), r.id])
  else { const [tipo] = ikey.split(':'); await q('INSERT INTO predictive_alerts (user_id, ikey, tipo, categoria, natureza, confidence, urgencia, canal, status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)', [userId, ikey, tipo, '-', '-', null, '-', 'pagina', acao, nowIso()]) }
  return { ok: true }
}
/** Texto curto de um sinal para o chat ou notificação (fato × estimativa sempre explícitos). */
export const rotulo = (s: P.Sinal) => (s.natureza === 'fato' ? 'Fato' : `Estimativa · ${s.confianca ?? '—'}% de confiança`)
/** Versão para o CHAT: separa o FATO (com a origem do dado) da SUGESTÃO e deixa claro que nada é feito sem confirmação. */
const ORIGEM: Record<string, string> = { compromissos: 'da sua agenda', clientes: 'dos seus clientes e agendamentos', financas: 'das suas finanças', tarefas: 'das suas tarefas', recorrencia: 'do seu histórico', problemas: 'dos seus registros' }
export function fraseChat(s: P.Sinal) {
  const origem = ORIGEM[s.categoria] || 'dos seus registros'
  const base = s.natureza === 'fato' ? `Dado ${origem}` : `Estimativa (${s.confianca ?? '—'}% de confiança, base: ${s.base})`
  return `Sugestão — ${base}: ${s.titulo}. ${s.detalhe}${s.tambem?.length ? ` (também: ${s.tambem.join(', ').toLowerCase()})` : ''}${s.acao ? `\nSe quiser, posso ajudar a ${s.acao} — só faço se você confirmar.` : ''}`
}
export function frase(s: P.Sinal) { return `${s.titulo}. ${s.detalhe}${s.tambem?.length ? ` (também: ${s.tambem.join(', ').toLowerCase()})` : ''} [${rotulo(s)}${s.natureza === 'estimativa' ? ` — base: ${s.base}` : ''}]${s.acao ? ` Quer que eu ajude a ${s.acao}?` : ''}` }
/** Rotina: avisos por notificação para usuários ativos (no máximo o limite diário de cada um). */
export async function rodarNotificacoes(limiteUsuarios = 500) {
  const cfg = await P.predCfg(); if (!cfg.ativo || !cfg.notificacoes) return { usuarios: 0, enviados: 0 }
  const users = (await q("SELECT * FROM users WHERE status = 'active' AND last_seen_at >= $1 ORDER BY last_seen_at DESC LIMIT $2", [new Date(Date.now() - 30 * 864e5).toISOString(), limiteUsuarios]).catch(() => [])) as any[]
  const { notify } = await import('../lib/notify.js'); let enviados = 0
  for (const ur of users) {
    try {
      const u = { id: Number(ur.id), name: ur.name, role: ur.role, settings: J<any>(ur.settings, {}) } as unknown as SessionUser
      const r = await paraUsuario(u); if (!r.ativo || !r.sinais.length) continue
      const { localTime } = await import('../lib/time.js'), { settingsOf } = await import('../lib/account.js'), hm = localTime(settingsOf(u).timezone)
      for (const s of await escolher(u.id, r.sinais, 'notificacao', Number(hm.slice(0, 2)) * 60 + Number(hm.slice(3, 5)), 2)) {
        await notify(u.id, { type: 'previsao', title: s.titulo, body: `${s.detalhe} (${rotulo(s)})`, link: '/previsoes', ref: `prev:${s.chave}:${r.hoje}` })
        await registrarAlerta(u.id, s, 'notificacao'); enviados++
      }
    } catch (e: any) { console.error('[preditivo] aviso:', e?.message) }
  }
  return { usuarios: users.length, enviados }
}

/* ---------- cenários simulados (verdade conhecida) e retroteste com o histórico ---------- */
export function cenarioSimulado(hoje: string): { dados: P.Dados; esperados: string[]; proibidos: string[] } {
  const A = P.addDias, criado = (n: number) => new Date(Date.parse(A(hoje, n) + 'T12:00:00Z')).toISOString()
  const ap = (id: number, o: Partial<P.Ap>): P.Ap => ({ id, title: 'Atendimento', date: hoje, time: '10:00', status: 'scheduled', reminders: [60], createdAt: criado(-2), ...o })
  const appointments: P.Ap[] = [
    ap(1, { title: 'Reunião com fornecedor', date: A(hoje, 1), time: '14:00', duracaoMin: 90 }), ap(2, { title: 'Dentista', date: A(hoje, 1), time: '15:00' }), // conflito
    ap(3, { title: 'Tatuagem', date: A(hoje, 2), time: '16:00', clienteNome: 'José' }), // sem contato + confirmar
    ap(4, { title: 'Consulta', date: A(hoje, 1), time: '09:00', reminders: [], createdAt: criado(-12) }), // esquecimento
    ap(5, { title: 'Corte', date: A(hoje, -1), time: '11:00', clienteNome: 'Ana', clienteTelefone: '85999990000', status: 'confirmed', valorTotal: 200, valorPago: 100, restante: 100 }), // acompanhamento + saldo
    ap(6, { title: 'Manicure', date: A(hoje, 3), time: '10:00', clienteNome: 'Bia', clienteTelefone: '85988887777' }), ap(7, { title: 'Manicure', date: A(hoje, 3), time: '10:00', clienteNome: 'Bia', clienteTelefone: '85988887777' }), // duplicidade
    ...[120, 90, 60, 30].map((n, i) => ap(20 + i, { title: 'Tatuagem', date: A(hoje, -n), time: '15:00', clienteNome: 'Carla', clienteTelefone: '85977776666', status: 'done' })), // retorno previsto
    ap(30, { title: 'Reunião tranquila', date: A(hoje, 9), time: '10:00', clienteNome: 'Davi', clienteTelefone: '85966665555', status: 'confirmed' }), // nada a dizer
  ]
  const mes = (n: number) => { const d = new Date(Date.parse(hoje.slice(0, 7) + '-15T12:00:00Z')); d.setUTCMonth(d.getUTCMonth() - n); return d.toISOString().slice(0, 7) }
  const diaInternet = String(Math.min(28, Number(hoje.slice(8, 10)) + 4)).padStart(2, '0')
  const bills = [
    { id: 40, name: 'Aluguel', amount: 1500, dueDate: A(hoje, -2), status: 'pending', recurrence: 'monthly' }, { id: 41, name: 'Luz', amount: 180, dueDate: A(hoje, 1), status: 'pending', recurrence: 'monthly' },
    ...[1, 2, 3].map((n) => ({ id: 50 + n, name: 'Internet', amount: 120, dueDate: `${mes(n)}-${diaInternet}`, status: 'paid', recurrence: 'none' })),
    { id: 60, name: 'Seguro', amount: 300, dueDate: `${mes(2)}-05`, status: 'paid', recurrence: 'none' }, // só uma vez: não é recorrente
  ]
  const finance = [...[1, 2, 3].flatMap((n) => [{ id: 70 + n, kind: 'expense', amount: 500, category: 'alimentacao', date: `${mes(n)}-10` }]),
    { id: 80, kind: 'expense', amount: Math.max(400, Number(hoje.slice(8, 10)) * 40), category: 'alimentacao', date: hoje.slice(0, 7) + '-02' }]
  const shopping = [40, 30, 20, 10].map((n, i) => ({ id: 90 + i, name: 'Café', done: true, createdAt: criado(-n) }))
  const tasks = [{ id: 100, title: 'Enviar orçamento', status: 'pending', priority: 'high', dueDate: A(hoje, -3) }, { id: 101, title: 'Organizar arquivos', status: 'pending', priority: 'normal', dueDate: A(hoje, 5) }]
  const dados: P.Dados = { hoje, agoraMin: 9 * 60, appointments, tasks, reminders: [], bills, finance, shopping, plans: [], pedidos: [], crm: [] }
  const esperados = ['conflito:1:2', 'sem_contato:3', 'confirmar:3', 'esquecimento:4', 'acompanhamento:5', 'saldo_receber:5', 'duplicidade:6:7', 'conta_atrasada:40', 'conta_vencendo:41', 'tarefa_atrasada:100', 'cliente_recorrente:carla', 'retorno_cliente:carla', 'compra_recorrente:cafe', 'conta_recorrente:internet']
  if (Number(hoje.slice(8, 10)) >= 7) esperados.push('ritmo_gastos:alimentacao')
  return { dados, esperados, proibidos: ['30', 'seguro', '101'] }
}
/** Valida o motor em cenários simulados: precisão (sinais certos), cobertura, falsos alertas, honestidade e velocidade. */
export async function validarCenarios(hoje: string) {
  const c = cenarioSimulado(hoje), r = await P.analisar(c.dados), porNome = Object.fromEntries(Object.entries(P.TIPOS).map(([k, v]) => [v, k]))
  // um sinal consolidado cobre também os aspectos que absorveu do mesmo registro (ex.: sem telefone + confirmar)
  const chaves = r.sinais.flatMap((s) => [s.chave, ...(s.tambem || []).map((n) => `${porNome[n]}:${s.ref?.id}`)])
  const achou = (e: string) => chaves.some((k) => k === e || k.startsWith(e + ':'))
  const encontrados = c.esperados.filter(achou), faltaram = c.esperados.filter((e) => !achou(e))
  const falsos = r.sinais.filter((s) => !c.esperados.some((e) => s.chave === e || s.chave.startsWith(e + ':')) && !['proximo', 'situacao_desatualizada'].includes(s.tipo))
  const proibidos = r.sinais.filter((s) => c.proibidos.some((p) => s.chave.endsWith(':' + p) || s.chave.includes(':' + p + ':')))
  const vazio = await P.analisar({ hoje, agoraMin: 600, appointments: [], tasks: [], reminders: [], bills: [], finance: [], shopping: [], plans: [], pedidos: [], crm: [] })
  const curto = await P.analisar({ ...c.dados, bills: c.dados.bills.filter((b) => b.name !== 'Internet' || b.id === 51), finance: c.dados.finance.filter((f) => f.id >= 80 || f.id === 71) })
  const estimativasOk = r.sinais.filter((s) => s.natureza === 'estimativa').every((s) => typeof s.confianca === 'number' && s.confianca >= 0 && s.confianca <= 100 && !!s.base)
  return {
    sinais: r.sinais.length, esperados: c.esperados.length, encontrados: encontrados.length, faltaram, falsos: falsos.map((s) => s.chave), proibidos: proibidos.map((s) => s.chave),
    precisao: pct(r.sinais.length - falsos.length, r.sinais.length), cobertura: pct(encontrados.length, c.esperados.length), ms: r.ms,
    honestidade: { semDadosSemSinais: vazio.sinais.length === 0 && vazio.lacunas.length > 0, historicoCurtoNaoPreve: !curto.sinais.some((s) => s.tipo === 'conta_recorrente' || s.tipo === 'ritmo_gastos') && curto.lacunas.some((l) => /2 meses/.test(l)), estimativasComConfianca: estimativasOk },
  }
}
/** Retroteste: volta N dias no tempo (só o que existia até lá), prevê, e confere com o que aconteceu depois. */
export async function retroteste(u: SessionUser, dias = 30) {
  const corte = new Date(Date.now() - dias * 864e5).toISOString()
  const antes = await P.carregarDados(u, { ate: corte }), r = await P.analisar(antes), agora = await P.carregarDados(u)
  const prevs = r.sinais.filter((s) => s.previsao), res = prevs.map((s) => ({ kind: s.previsao!.kind, confianca: s.confianca, ok: verificar(s.previsao!.kind, s.previsao!.payload, s.previsao!.de, s.previsao!.ate, agora) }))
  return { previsoes: res.length, acertos: res.filter((x) => x.ok === true).length, erros: res.filter((x) => x.ok === false).length, pendentes: res.filter((x) => x.ok === null).length, ms: r.ms, porTipo: res }
}

/* ---------- indicadores agregados (painel do administrador: só contagens) ---------- */
export async function indicadores() {
  const cfg = await P.predCfg(), desde = new Date(Date.now() - 30 * 864e5).toISOString()
  const al = (await q('SELECT tipo, categoria, natureza, urgencia, canal, status, user_id FROM predictive_alerts WHERE created_at >= $1', [desde]).catch(() => [])) as any[]
  const pr = (await q('SELECT kind, status, confidence FROM predictions WHERE created_at >= $1', [new Date(Date.now() - 120 * 864e5).toISOString()]).catch(() => [])) as any[]
  const porTipo = new Map<string, any>()
  for (const a of al) { const x = porTipo.get(a.tipo) || { tipo: a.tipo, nome: P.TIPOS[a.tipo] || a.tipo, apresentadas: 0, aceitas: 0, dispensadas: 0, falsos: 0, usuarios: new Set() }; x.apresentadas++; if (a.status === 'aceita') x.aceitas++; if (a.status === 'dispensada') x.dispensadas++; if (a.status === 'falso') x.falsos++; x.usuarios.add(Number(a.user_id)); porTipo.set(a.tipo, x) }
  const porKind = new Map<string, any>()
  for (const p of pr) { const x = porKind.get(p.kind) || { kind: p.kind, nome: P.TIPOS[p.kind] || p.kind, total: 0, acertou: 0, errou: 0, aberta: 0, conf: [] as number[] }; x.total++; x[p.status] = (x[p.status] || 0) + 1; if (p.confidence != null) x.conf.push(Number(p.confidence)); porKind.set(p.kind, x) }
  const avaliadas = pr.filter((p) => p.status === 'acertou' || p.status === 'errou')
  const ult = await one("SELECT result, created_at FROM intel_runs WHERE kind = 'preditivo_validacao' ORDER BY id DESC LIMIT 1").catch(() => null)
  const prefsOff = await one("SELECT COUNT(*) AS n FROM user_intel_prefs WHERE predictive LIKE '%\"ativo\":false%'").catch(() => null)
  return {
    config: cfg,
    alertas: { apresentados: al.length, aceitos: al.filter((a) => a.status === 'aceita').length, dispensados: al.filter((a) => a.status === 'dispensada').length, falsos: al.filter((a) => a.status === 'falso').length, urgentes: al.filter((a) => a.urgencia === 'alta').length, usuarios: new Set(al.map((a) => a.user_id)).size, porCanal: { chat: al.filter((a) => a.canal === 'chat').length, notificacao: al.filter((a) => a.canal === 'notificacao').length, pagina: al.filter((a) => a.canal === 'pagina').length }, taxaAceite: pct(al.filter((a) => a.status === 'aceita').length, al.length), taxaFalsos: pct(al.filter((a) => a.status === 'falso').length, al.length) },
    porTipo: [...porTipo.values()].map((x) => ({ ...x, usuarios: x.usuarios.size, taxaAceite: pct(x.aceitas, x.apresentadas), taxaFalsos: pct(x.falsos, x.apresentadas) })).sort((a, b) => b.apresentadas - a.apresentadas),
    previsoes: { total: pr.length, avaliadas: avaliadas.length, acertos: avaliadas.filter((p) => p.status === 'acertou').length, precisao: pct(avaliadas.filter((p) => p.status === 'acertou').length, avaliadas.length), abertas: pr.filter((p) => p.status === 'aberta').length,
      porTipo: [...porKind.values()].map((x) => ({ kind: x.kind, nome: x.nome, total: x.total, acertou: x.acertou || 0, errou: x.errou || 0, aberta: x.aberta || 0, precisao: pct(x.acertou || 0, (x.acertou || 0) + (x.errou || 0)), confiancaMedia: x.conf.length ? Math.round(x.conf.reduce((a: number, b: number) => a + b, 0) / x.conf.length) : null })) },
    usuariosQueDesligaram: Number(prefsOff?.n || 0), validacao: J<any>(ult?.result, null), validacaoEm: ult?.created_at || null,
  }
}
export async function validarTudo(admin?: SessionUser) {
  const hoje = new Date().toISOString().slice(0, 10), cen = await validarCenarios(hoje)
  // retroteste em até 20 usuários ativos (só agregados saem daqui)
  const users = (await q("SELECT * FROM users WHERE status = 'active' ORDER BY last_seen_at DESC LIMIT 20").catch(() => [])) as any[]
  let previsoes = 0, acertos = 0, erros = 0, ms: number[] = []
  for (const ur of users) { try { const r = await retroteste({ id: Number(ur.id), name: ur.name, role: ur.role, settings: J<any>(ur.settings, {}) } as any, 30); previsoes += r.previsoes; acertos += r.acertos; erros += r.erros; ms.push(r.ms) } catch { /* usuário sem dados */ } }
  const res = { em: nowIso(), cenarios: cen, retroteste: { usuarios: users.length, previsoes, acertos, erros, precisao: pct(acertos, acertos + erros), msMedio: ms.length ? Math.round((ms.reduce((a, b) => a + b, 0) / ms.length) * 100) / 100 : null, observacao: previsoes ? '' : 'Sem histórico suficiente para retroteste: as previsões precisam de pelo menos 2–3 ocorrências de um padrão.' }, por: admin?.id ?? null }
  await q('INSERT INTO intel_runs (kind, result, ok, created_at) VALUES ($1,$2,$3,$4)', ['preditivo_validacao', JSON.stringify(res), (cen.cobertura || 0) >= 90 && !cen.proibidos.length, nowIso()]).catch(() => {})
  return res
}
