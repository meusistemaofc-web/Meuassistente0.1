// Modo "Pesquisa na internet" (botão ⚡): com ele ligado na conversa, cada pergunta de conhecimento ou atualidade vai para a
// pesquisa externa (nível 4 da hierarquia), com as fontes. Operações e consultas aos próprios registros continuam internas
// (a prioridade de execução não muda). Não há motor novo: o chat só trata a mensagem como pedido explícito de pesquisa
// (veja routes/chat.ts → "modo Pesquisa na internet") e usa as mesmas camadas de busca de sempre.
// Controle: a chave global "Pesquisa na internet" do painel (Administração → Modos Inteligentes). Desligada, o modo não existe
// para ninguém: some do ⚡, não ativa por chamada direta e o chat não pesquisa em camada nenhuma (ai/bloqueio-pesquisa.ts).
import type { Modo } from './tipos.js'

export const pesquisaInternet: Modo = {
  id: 'pesquisa',
  nome: 'Pesquisa na internet',
  descricao: 'Busca informações atualizadas na web para cada pergunta e mostra as fontes.',
  icone: 'globo',
  ocultoSemAcesso: true,
  persistente: true,
  ferramentas: ['pesquisa_web'],
  async acesso() {
    const PB = await import('../ai/bloqueio-pesquisa.js')
    return (await PB.internetPermitida()) ? { liberado: true, codigo: 'ok', mensagem: '' } : { liberado: false, codigo: 'desativado', mensagem: '' }
  },
  async iniciar() {
    return { resposta: { content: 'Pesquisa na internet ligada nesta conversa. Pergunte o que quiser: eu busco informações atualizadas na web e mostro as fontes. Seus registros (agenda, finanças, lembretes…) continuam sendo atendidos aqui mesmo. Para voltar ao chat normal, toque em ⚡ → Chat normal.', cards: [] }, estado: { etapa: 'ativo' } }
  },
  // a resposta vem do chat comum, tratando a mensagem como pedido explícito de pesquisa; o modo continua ligado
  async responder() { return null },
}
