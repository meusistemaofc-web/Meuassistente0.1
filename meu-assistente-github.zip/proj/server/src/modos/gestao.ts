// MODO INTELIGENTE "GESTÃO DA EMPRESA" — o dono (ou quem tem vínculo válido) gerencia a empresa conversando, com PRÉVIA
// nativa no chat antes de salvar. Não é uma gestão paralela: lê e grava pelo administrador conversacional que já existe
// (ai/empresa-admin.ts → empresaAtiva, localizar, alterar, chamar), que usa as ROTAS OFICIAIS do painel (mesmas validações,
// permissões, vínculos, auditoria e isolamento entre empresas).
//
// Fluxo: pedido em linguagem natural → interpretação (regras locais; IA com as ferramentas oficiais como apoio) → PRÉVIA
// (antes × depois, valor alterado destacado) com Confirmar / Editar novamente / Cancelar → só no "Confirmar" a alteração é
// gravada → resposta com o resultado REAL lido do banco. Nada é gravado antes da confirmação; ações destrutivas (excluir)
// pedem a confirmação explícita na própria prévia. A proposta fica no estado do modo da conversa (conversa_modos).
import type { Modo, ContextoExec, EstadoModo, Resposta } from './tipos.js'
import type { SessionUser } from '../lib/session.js'
import { J, nowIso } from '../db/index.js'

const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim()
const brl = (n: number) => 'R$ ' + Number(n || 0).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.')
const num = (s: string) => { const t = String(s || '').replace(/[^\d.,]/g, ''); const v = Number(t.includes(',') ? t.replace(/\./g, '').replace(',', '.') : t); return Number.isFinite(v) ? Math.round(v * 100) / 100 : NaN }
const limpa = (s: string) => String(s || '').trim().replace(/^["“'«]|["”'»]$/g, '').replace(/[.!]+$/, '').trim()

export interface Card { nome?: string; preco?: number | null; oferta?: number | null; descricao?: string; categoria?: string; foto?: string | null; ativo?: boolean; tipo?: string
  empresa?: string; whatsapp?: string; endereco?: string; instagram?: string; contato?: string; logo?: string | null; horario?: string; pedidos?: string
  estoque?: string; entrega?: string; pagamento?: string; frete?: string; botao?: string }
export interface Previa { tipo: 'produto' | 'produto_novo' | 'empresa' | 'excluir_produto' | 'texto' | 'lote'; titulo: string; antes?: Card | null; depois: Card; destaque: string[]; aviso?: string; destrutiva?: boolean
  /** reajuste de vários produtos: um item por produto (antes → depois) */
  itens?: { nome: string; foto?: string | null; antes: number; depois: number }[] }
export interface Proposta { id: string; acao: string; args: any; previa: Previa; status: 'pendente' | 'confirmada' | 'cancelada' | 'falhou' | 'substituida'; resultado?: string; bid: number; empresa: string; criadaEm: string }

/* ---------- interpretação (regras locais) ---------- */
const VERB = String.raw`(?:altere|alterar|mude|mudar|muda|troque|trocar|coloque|colocar|ajuste|ajustar|atualize|atualizar|defina|definir|deixe|deixar|passe|passar)`
const DIA: Record<string, string> = { seg: 'seg', segunda: 'seg', ter: 'ter', terca: 'ter', qua: 'qua', quarta: 'qua', qui: 'qui', quinta: 'qui', sex: 'sex', sexta: 'sex', sab: 'sab', sabado: 'sab', dom: 'dom', domingo: 'dom' }
const ORD = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom']
const empresaAlvo = (s: string) => /^(a |da |minha |nossa )*(empresa|loja|perfil|negocio|estabelecimento)$/.test(nrm(s))
export function interpretar(texto: string, anexo = ''): { acao: string; args: any } | null {
  const t = String(texto || '').replace(/\s+/g, ' ').trim(), n = nrm(t)
  let m: RegExpExecArray | null
  // criar produto/serviço: "crie um produto Brigadeiro gourmet por R$ 6,50, descrição: chocolate belga"
  if ((m = /^(?:crie|criar|cadastre|cadastrar|adicione|adicionar|inclua|incluir|novo|nova)\s+(?:um\s+|uma\s+)?(?:novo\s+|nova\s+)?(produto|servi[cç]o)\s*:?\s*(.+)$/i.exec(t))) {
    const tipo = /produto/i.test(m[1]) ? 'produto' : 'servico'; let resto = m[2]
    const desc = /[,;]?\s*(?:com\s+)?(?:a\s+)?descri[cç][aã]o\s*:?\s*(.+)$/i.exec(resto); if (desc) resto = resto.slice(0, desc.index)
    const cat = /[,;]?\s*(?:na\s+)?categoria\s*:?\s*([^,;]+)/i.exec(resto); if (cat) resto = resto.replace(cat[0], '')
    const pr = /[,;]?\s*(?:por|a|de|custando|no valor de|valor|pre[cç]o)\s*:?\s*(?:r\$\s*)?(\d[\d.,]*)\s*(?:reais)?/i.exec(resto); if (pr) resto = resto.replace(pr[0], '')
    const nome = limpa(resto.replace(/^(chamad[oa]|com o nome|de nome)\s+/i, '').replace(/[,;]+$/, ''))
    return { acao: 'produto_criar', args: { tipo, nome, preco: pr ? num(pr[1]) : null, descricao: desc ? limpa(desc[1]) : '', categoria: cat ? limpa(cat[1]) : '', foto: anexo || '' } }
  }
  // preço / oferta de produto
  if ((m = new RegExp(String.raw`^${VERB}\s+(?:o\s+)?(?:pre[cç]o|valor)\s+d[oa]s?\s+(?:produto\s+|servi[cç]o\s+)?(.+?)\s+(?:para|pra|por|em)\s+(?:r\$\s*)?(\d[\d.,]*)`, 'i').exec(t))) return { acao: 'produto_preco', args: { produto: limpa(m[1]), valor: num(m[2]) } }
  if ((m = /^(?:o\s+)?(?:pre[cç]o|valor)\s+d[oa]s?\s+(.+?)\s+(?:agora\s+)?(?:[eé]|fica|passa a ser|vai ser)\s+(?:r\$\s*)?(\d[\d.,]*)/i.exec(t))) return { acao: 'produto_preco', args: { produto: limpa(m[1]), valor: num(m[2]) } }
  if ((m = /^(?:coloque|ponha|crie|fa[cç]a|ative|deixe)\s+(?:uma\s+|em\s+)?(?:oferta|promo[cç][aã]o)\s+(?:d[oa]\s+|n[oa]\s+|para\s+o\s+|para\s+a\s+)?(.+?)\s+(?:por|a|de|em)\s+(?:r\$\s*)?(\d[\d.,]*)/i.exec(t))) return { acao: 'produto_oferta', args: { produto: limpa(m[1]), valor: num(m[2]), ativo: true } }
  if ((m = /^(?:tire|remova|retire|encerre|desative)\s+a\s+(?:oferta|promo[cç][aã]o)\s+d[oa]\s+(.+)$/i.exec(t))) return { acao: 'produto_oferta', args: { produto: limpa(m[1]), ativo: false } }
  // nome
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+nome\s+d[oa]\s+(.+?)\s+para\s+(.+)$`, 'i').exec(t))) return empresaAlvo(m[1]) ? { acao: 'alterar_nome', args: { texto: limpa(m[2]) } } : { acao: 'produto_nome', args: { produto: limpa(m[1].replace(/^(produto|servi[cç]o)\s+/i, '')), texto: limpa(m[2]) } }
  if ((m = /^renomei?e\s+(?:o\s+)?(?:produto\s+|servi[cç]o\s+)?(.+?)\s+para\s+(.+)$/i.exec(t))) return { acao: 'produto_nome', args: { produto: limpa(m[1]), texto: limpa(m[2]) } }
  // descrição
  if ((m = new RegExp(String.raw`^${VERB}\s+a\s+descri[cç][aã]o\s+d[oa]\s+(.+?)\s+para\s*:?\s*(.+)$`, 'i').exec(t))) return empresaAlvo(m[1]) ? { acao: 'alterar_descricao', args: { texto: limpa(m[2]) } } : { acao: 'produto_descricao', args: { produto: limpa(m[1].replace(/^(produto|servi[cç]o)\s+/i, '')), texto: limpa(m[2]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+a\s+descri[cç][aã]o\s+(?:da\s+)?(?:minha\s+)?(?:empresa|loja)?\s*para\s*:?\s*(.+)$`, 'i').exec(t))) return { acao: 'alterar_descricao', args: { texto: limpa(m[1]) } }
  // contato e endereço
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+(?:whats\s*app|whatsapp|zap|telefone|celular|n[uú]mero)\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_whatsapp', args: { texto: limpa(m[1]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+endere[cç]o\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_endereco', args: { texto: limpa(m[1]) } }
  if ((m = new RegExp(String.raw`^${VERB}\s+o\s+instagram\s+(?:da\s+(?:minha\s+)?(?:empresa|loja)\s+)?para\s+(.+)$`, 'i').exec(t))) return { acao: 'alterar_instagram', args: { texto: limpa(m[1]) } }
  // categoria
  if ((m = /^(?:mude|mova|coloque|passe|troque)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+?)\s+(?:para|na|pra)\s+(?:a\s+)?categoria\s+(.+)$/i.exec(t))) return { acao: 'produto_categoria', args: { produto: limpa(m[1]), texto: limpa(m[2]) } }
  // foto do produto (com a foto anexada)
  if (anexo && (m = /(?:foto|imagem)\s+d[oa]\s+(?:produto\s+|servi[cç]o\s+)?(.+?)(?:\s+(?:por|com)\s+(?:esta|essa|a)\s+(?:foto|imagem).*)?$/i.exec(t))) return { acao: 'produto_foto', args: { produto: limpa(m[1].replace(/\s+(?:por|com)\s+.*$/, '')), foto: anexo } }
  // pedidos (loja)
  if (/^(?:pause|pausar|feche|fechar|suspenda|pare|parar)\s+(?:os\s+|a\s+|o\s+)?(?:pedidos|loja|catalogo)\b/.test(n)) return { acao: 'pausar_pedidos', args: {} }
  if (/^(?:reative|reativar|reabra|reabrir|abra|abrir|volte a receber|ative)\s+(?:os\s+|a\s+|o\s+)?(?:pedidos|loja|catalogo)\b/.test(n)) return { acao: 'reativar_pedidos', args: {} }
  // pausar / reativar / excluir produto
  if ((m = /^(?:pause|pausar|desative|desativar|esconda|esconder|oculte|ocultar|tire do ar|tirar do ar)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'produto_pausar', args: { produto: limpa(m[1]) } }
  if ((m = /^(?:reative|reativar|ative|ativar|mostre de novo|volte a vender|volte a mostrar|coloque de volta)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'produto_ativar', args: { produto: limpa(m[1]) } }
  if ((m = /^(?:exclua|excluir|apague|apagar|remova|remover|delete|deletar)\s+(?:o\s+|a\s+)?(?:produto\s+|servi[cç]o\s+)?(.+)$/i.exec(t))) return { acao: 'excluir_produto', args: { produto: limpa(m[1]) } }
  // horário: "abra de segunda a sexta das 9h às 18h"
  if (/hor[aá]rio|abr[ae]|funciona|atend/.test(n) && (m = /\b(seg\w*|ter\w*|qua\w*|qui\w*|sex\w*|sab\w*|dom\w*)\s+(?:a|ate)\s+(seg\w*|ter\w*|qua\w*|qui\w*|sex\w*|sab\w*|dom\w*).*?(\d{1,2})(?:h|:)?(\d{2})?\s*(?:as|a|ate|-)\s*(\d{1,2})(?:h|:)?(\d{2})?/.exec(n))) {
    const a = DIA[m[1].replace(/-feira$/, '').slice(0, 7)] || DIA[m[1].slice(0, 3)], b = DIA[m[2].replace(/-feira$/, '').slice(0, 7)] || DIA[m[2].slice(0, 3)]
    const i = ORD.indexOf(a), j = ORD.indexOf(b); if (i >= 0 && j >= i) return { acao: 'alterar_horario', args: { dias: ORD.slice(i, j + 1), abre: `${m[3].padStart(2, '0')}:${m[4] || '00'}`, fecha: `${m[5].padStart(2, '0')}:${m[6] || '00'}` } }
  }
  return null
}

/* ---------- entendimento flexível (linguagem informal, erros de digitação, contexto) ----------
   As regras acima cobrem as frases "de manual". Aqui o pedido é lido por partes — QUAL registro (produto pelo nome, com
   tolerância a erro de digitação; categoria; a empresa), QUAL campo e QUAL valor — em qualquer ordem, sem depender de uma
   frase fixa. Também separa CONSULTA ("qual o preço…?"), SUGESTÃO ("sugira uma descrição…") e ALTERAÇÃO. Tudo vira uma das
   ações oficiais de ai/empresa-admin.ts; nada é gravado aqui (a prévia e o Confirmar continuam obrigatórios). */
type ProdLista = { id: number; nome: string; preco: number; oferta: number | null; estoque: number | null; categoria: string; ativo: boolean; descricao: string; tipo: string; variacoes: any[] }
export type Entendido =
  | { tipo: 'acao'; acao: string; args: any }
  | { tipo: 'lote'; itens: { produto: number; valor: number }[]; regra: string }
  | { tipo: 'consulta'; produtos: ProdLista[]; topico: string }
  | { tipo: 'sugestao'; alvo: 'empresa' | 'produto'; campo: 'descricao' | 'preco'; produto?: ProdLista }
  | { tipo: 'faltou'; msg: string }
const nn = (s: string) => nrm(s).replace(/[^a-z0-9%$,.:@/ -]/g, ' ').replace(/\s+/g, ' ').trim()
const VALOR = String.raw`(\d{1,6}(?:[.,]\d{1,2})?)`
/** Valor em dinheiro citado na frase (não confunde com horário, %, km, unidades). */
export function dinheiro(t: string): number | null {
  const n = nn(t); let m: RegExpExecArray | null
  if ((m = new RegExp(String.raw`r\$\s*${VALOR}`).exec(n))) return num(m[1])
  if ((m = new RegExp(String.raw`${VALOR}\s*(?:reais|real|conto|contos|pila)\b`).exec(n))) return num(m[1])
  if ((m = new RegExp(String.raw`\b(?:pra|para|por|a|em|custa|custando|custar|fica|fique|ficar|sai|saindo|sair|vale|valendo|valor|preco|vai ser|passa a ser|agora e|e)\s+(?:de\s+)?${VALOR}(?![\d%]|\s*(?:%|por cento|h\b|hs?\b|horas|km|un\b|unidades|pecas|min))`).exec(n))) return num(m[1])
  if ((m = new RegExp(String.raw`^${VALOR}$`).exec(n))) return num(m[1])
  return null
}
const porcento = (t: string) => { const m = /(\d{1,3}(?:[.,]\d+)?)\s*(?:%|por cento)/.exec(nn(t)); return m ? num(m[1]) : null }
const arred = (v: number) => Math.round(v * 100) / 100
/** Produtos citados pelo nome (tolerante a erro de digitação/plural). Nomes contidos em outro citado saem ("bolo" × "bolo de cenoura"). */
export async function produtosCitados(t: string, lista: ProdLista[]): Promise<ProdLista[]> {
  const EA = await import('../ai/empresa-admin.js'), ws = EA.palavrasNome(t)
  const cheios = lista.filter((p) => { const pw = EA.palavrasNome(p.nome); return pw.length > 0 && pw.every((x) => ws.some((w) => EA.parecido(w, x))) })
  const sem = cheios.filter((p) => !cheios.some((o) => o !== p && EA.palavrasNome(o.nome).length > EA.palavrasNome(p.nome).length && EA.palavrasNome(p.nome).every((x) => EA.palavrasNome(o.nome).includes(x))))
  // só a palavra principal ("a torta" → Torta de limão) — mas não quando a frase qualifica outra coisa: "bolo de pote" não é
  // "Bolo de cenoura"; e só se essa palavra não for de outro produto já citado por inteiro
  const n = nn(t)
  const pri = lista.filter((p) => { if (sem.includes(p)) return false; const pw = EA.palavrasNome(p.nome), w0 = pw[0]; if (!w0 || w0.length < 4 || !ws.some((w) => EA.parecido(w, w0))) return false
    if (sem.some((o) => EA.palavrasNome(o.nome).some((x) => EA.parecido(x, w0)))) return false
    const q = new RegExp(String.raw`\b${w0.slice(0, Math.max(4, w0.length - 2))}\w*\s+(?:de|da|do|com)\s+([a-z]{3,})`).exec(n); return !q || /^(cardapio|catalogo|site|loja|vitrine|estoque|preco|valor|cliente|clientes|pedido|pedidos|promocao|oferta|desconto|semana|hoje|amanha|dia|mes)$/.test(q[1]) || pw.some((x) => EA.parecido(q[1], x)) })
  // a mesma palavra principal em vários produtos ("bolo" → Bolo de cenoura e Bolo de fubá) fica ambígua: vão todos (o modo pergunta qual)
  return [...sem, ...pri]
}
function categoriaCitada(t: string, lista: ProdLista[], parecido: (a: string, b: string) => boolean): string | null {
  const ws = nn(t).split(' '), cats = [...new Set(lista.map((p) => p.categoria).filter(Boolean))]
  return cats.find((c) => { const cw = nrm(c).split(' ').filter((x) => x.length >= 3); return cw.length && cw.every((x) => ws.some((w) => parecido(w, x))) }) || null
}
const PERGUNTA = /^(qual|quais|quanto|quantos|quantas|como (esta|ta|estao|tao|ficou|ficaram|e)|o que|oq|me (mostra|mostre|diz|diga|fala|fale|passa|lembra)|mostra|mostre|lista|liste|listar|ver|veja|tem |temos|ta |esta |estou |estamos |a gente (esta|ta)|que horas|onde|cade)\b/
const MUDA = /\b(alter|mud|troc|coloc|colo|bot[ae]|botar|ponh|ajust|atualiz|defin|deix|aument|sob[e]|suba|diminu|baix|reduz|reajust|corrij|corrig|tir[ae]|tirar|remov|ativ|desativ|lig[ae]|ligar|deslig|paus|reativ|fech|abr[ae]|abrir|zer|acrescent|adicion|inclu|renome|aceit|para de|pare de|esgot|acab|passa a|agora (custa|e|vale|sai)|vai custar|fica |fique|cobr)\w*/
const SUGERE = /\b(sugir\w*|sugest\w*|ideias?|me ajud\w* a (escrever|melhorar|criar|pensar)|melhor[ae] a descricao|melhorar a descricao|reescrev\w*|escrev\w* (uma|a) (nova )?descricao|cri[ae] uma descricao|faz(er)? uma descricao|que preco (eu )?(cobro|coloco|ponho)|quanto (eu )?(devo|deveria) cobrar)\b/
const DIAS_RE = String.raw`(seg\w*|ter\w*|qua\w*|qui\w*|sex\w*|sab\w*|dom\w*)`
function lerDias(n: string): string[] | null {
  if (/\b(todos os dias|todo dia|diariamente|de domingo a domingo|7 dias)\b/.test(n)) return [...ORD]
  const r = new RegExp(String.raw`\b${DIAS_RE}(?:-feira)?\s+(?:a|ate|-)\s+${DIAS_RE}`).exec(n)
  const d = (w: string) => DIA[w.replace(/-feira$/, '').slice(0, 7)] || DIA[w.slice(0, 3)]
  if (r) { const i = ORD.indexOf(d(r[1])), j = ORD.indexOf(d(r[2])); if (i >= 0 && j >= i) return ORD.slice(i, j + 1) }
  const lst = [...n.matchAll(new RegExp(String.raw`\b(segunda|terca|quarta|quinta|sexta|sabado|domingo|seg|ter|qua|qui|sex|sab|dom)\b`, 'g'))].map((m) => d(m[1])).filter(Boolean)
  if (/\bfim de semana\b/.test(n)) lst.push('sab', 'dom')
  return lst.length ? ORD.filter((x) => lst.includes(x)) : null
}
function lerHoras(n: string): { abre: string; fecha: string } | null {
  const m = /\b(?:das?\s+|de\s+)?(\d{1,2})(?:[:h](\d{2}))?\s*h?\s*(?:as|a|ate|-)\s*(\d{1,2})(?:[:h](\d{2}))?\s*h?\b/.exec(n.replace(/\b(segunda|terca|quarta|quinta|sexta|sabado|domingo)(-feira)?\s+(a|ate)\s+/g, ' '))
  if (!m) return null; const h1 = Number(m[1]), h2 = Number(m[3]); if (h1 > 23 || h2 > 24 || h1 >= h2 && !(h2 < 6)) return null
  return { abre: `${String(h1).padStart(2, '0')}:${m[2] || '00'}`, fecha: `${String(h2 === 24 ? 23 : h2).padStart(2, '0')}:${h2 === 24 ? '59' : m[4] || '00'}` }
}
/** Texto depois de "para / pra / : / =" (o novo valor de um campo de texto). */
const textoNovo = (t: string, campo: RegExp) => { const m = new RegExp(String.raw`(?:${campo.source})[^:]*?(?::|\bpara\b|\bpra\b|=|\bagora e\b|\bvai ser\b|\bpassa a ser\b)\s*(.+)$`, 'i').exec(t); const v = m ? limpa(m[m.length - 1]) : ''; return v ? v.charAt(0).toUpperCase() + v.slice(1) : '' }

export async function entender(u: SessionUser, e: { b: any }, texto: string, estado: EstadoModo): Promise<Entendido | null> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id), t = String(texto || '').replace(/\s+/g, ' ').trim(), n = nn(t)
  if (!n) return null
  const lista = (await EA.produtos(bid)) as ProdLista[]
  let citados = await produtosCitados(t, lista)
  const ultimo = estado.ultima as { acao: string; args: any; produto?: number } | undefined
  // "ele", "esse", "o mesmo", "também", só o valor → o produto da última alteração desta conversa
  const pronome = /\b(ele|ela|dele|dela|nele|nela|esse|essa|desse|dessa|este|esta|o mesmo|a mesma|tambem|igual)\b/.test(n)
  if (!citados.length && ultimo?.produto && (pronome || /^(e |agora |entao )?(pra|para|por)?\s*(r\$\s*)?\d/.test(n))) { const p = lista.find((x) => x.id === ultimo.produto); if (p) citados = [p] }
  const muda = MUDA.test(n), pergunta = (PERGUNTA.test(n) || /\?\s*$/.test(t)) && !/^(pode|consegue|da pra|voce pode|vc pode)\b/.test(n)

  // ---------- sugestão (nunca grava; vira prévia ou orientação) ----------
  if (SUGERE.test(n)) {
    if (/\b(preco|cobr\w*|valor|custar)\b/.test(n)) return { tipo: 'sugestao', alvo: citados.length ? 'produto' : 'empresa', campo: 'preco', produto: citados[0] }
    return { tipo: 'sugestao', alvo: citados.length === 1 ? 'produto' : 'empresa', campo: 'descricao', produto: citados[0] }
  }
  // ---------- consulta ----------
  if (pergunta && !(muda && /^(pode|consegue|da pra|quero|preciso)\b/.test(n))) {
    const topico = /\b(horario|abre|abrimos|fecha|fechamos|funciona|funcionamento|atende|atendimento)\b/.test(n) ? 'horario' : /\bendereco|onde fica|localiza/.test(n) ? 'endereco'
      : /\b(whats\w*|zap|telefone|celular|contato|numero)\b/.test(n) ? 'contato' : /\binsta\w*\b/.test(n) ? 'instagram' : /\b(entrega|delivery|retirada|taxa|raio|minimo|frete)\b/.test(n) ? 'entrega'
      : /\b(pagamento|pix|cartao|dinheiro|pagar)\b/.test(n) ? 'pagamento' : /\b(promoc\w*|oferta|desconto)\b/.test(n) ? 'ofertas' : /\b(estoque|acabando|esgotad\w*|unidades)\b/.test(n) ? 'estoque'
      : /\b(pedidos|aberta|aberto|fechada|fechado|recebendo)\b/.test(n) ? 'pedidos' : /\bdescricao|sobre\b/.test(n) && !citados.length ? 'descricao' : /\bcategorias?\b/.test(n) && !citados.length ? 'categorias'
      : /\b(produtos?|servicos?|cardapio|catalogo|itens|vendo|vendemos|tenho|temos)\b/.test(n) && !citados.length ? 'produtos' : citados.length ? 'produto' : /\b(empresa|loja|perfil|nome)\b/.test(n) ? 'empresa' : ''
    if (topico) return { tipo: 'consulta', produtos: citados, topico }
    if (!muda) return null
  }

  // ---------- recebimento de pedidos (loja aberta/fechada) ----------
  const horas = lerHoras(n), dias = lerDias(n)
  if (horas && dias && /\b(horario|abr\w*|funcion\w*|atend\w*|fech\w*|trabalh\w*|expediente)\b/.test(n)) return { tipo: 'acao', acao: 'alterar_horario', args: { dias, ...horas } }
  if (/\b(horario|funcionamento|expediente)\b/.test(n) && muda && (!horas || !dias)) return { tipo: 'faltou', msg: 'Diga os dias e o horário, por exemplo: "de segunda a sábado, das 8h às 19h".' }
  if (/\b(fech\w*|paus\w*|suspend\w*|par[ae]r?|desativ\w*|desliga\w*)\s+(?:a |o |os |as )?(?:minha |nossa )?(loja|pedidos|catalogo|cardapio|atendimento|delivery de hoje)\b|\bnao (vou|vamos) (atender|abrir|receber pedidos|trabalhar)\b|\b(fechad[oa]s?|sem atender) hoje\b|\bpara de receber pedidos\b/.test(n)) return { tipo: 'acao', acao: 'pausar_pedidos', args: {} }
  if (/\b(abr\w*|reabr\w*|reativ\w*|ativ\w*|liga\w*|liber\w*)\s+(?:a |o |os |as )?(?:minha |nossa )?(loja|pedidos|catalogo|cardapio|atendimento)\b|\bvolt\w* a (receber|atender|abrir|vender)\b(?! (o|a) )/.test(n) && !citados.length) return { tipo: 'acao', acao: 'reativar_pedidos', args: {} }

  // ---------- entrega, frete grátis, pagamento, botão do WhatsApp ----------
  if (/\bfrete gratis\b|\bentrega gratis acima\b/.test(n)) {
    if (/\b(tir\w*|remov\w*|desliga\w*|desativ\w*|acab\w*|encerr\w*|cancel\w*|sem frete gratis|nao (tem|quero) mais)\b/.test(n)) return { tipo: 'acao', acao: 'frete_gratis', args: { ativo: false } }
    const v = dinheiro(n) ?? (/\bacima de (\d+)/.exec(n) ? num(/\bacima de (\d+(?:[.,]\d{1,2})?)/.exec(n)![1]) : null)
    return v ? { tipo: 'acao', acao: 'frete_gratis', args: { ativo: true, valor_minimo: v } } : { tipo: 'faltou', msg: 'A partir de qual valor de compra o frete fica grátis? Ex.: "frete grátis acima de R$ 100".' }
  }
  const ent: any = {}
  if (/\b(so|somente|apenas|unicamente) (retirada|retirar|pra retirar|para retirar|no balcao|buscar)\b/.test(n)) Object.assign(ent, { entrega: false, retirada: true })
  else if (/\b(so|somente|apenas) (entrega|delivery)\b/.test(n)) Object.assign(ent, { entrega: true, retirada: false })
  else {
    if (/\b(nao (faz|faco|fazemos|vou fazer) mais|para(r)? de fazer|desliga\w*|desativ\w*|tir\w*|sem) (a |o )?(entrega|delivery)\b/.test(n)) ent.entrega = false
    else if (/\b(liga\w*|ativ\w*|comec\w* a fazer|passa\w* a fazer|faz\w*|volt\w* a fazer|habilit\w*) (a |o )?(entrega|delivery)\b/.test(n)) ent.entrega = true
    if (/\b(nao (aceita|tem) mais|desliga\w*|desativ\w*|tir\w*|sem) (a )?retirada\b/.test(n)) ent.retirada = false
    else if (/\b(liga\w*|ativ\w*|aceit\w*|habilit\w*|volt\w* a ter) (a )?retirada\b/.test(n)) ent.retirada = true
  }
  let m: RegExpExecArray | null
  if (/\btaxa\b/.test(n) && /\b(entrega|delivery|frete)\b|\btaxa\b/.test(n)) { if (/\b(sem taxa|zer\w* a taxa|taxa zero|tir\w* a taxa)\b/.test(n)) ent.taxa = 0; else { const v = dinheiro(n) ?? ((m = /taxa\D{0,30}?(\d{1,4}(?:[.,]\d{1,2})?)/.exec(n)) ? num(m[1]) : null); if (v != null) ent.taxa = v } }
  if ((m = /\b(?:pedido )?minimo\D{0,25}?(\d{1,5}(?:[.,]\d{1,2})?)/.exec(n))) ent.pedido_minimo = num(m[1])
  if ((m = /\b(?:raio|ate|distancia)\D{0,15}?(\d{1,3})\s*km\b/.exec(n))) ent.raio_km = Number(m[1])
  if ((m = /\btempo de entrega\D{0,20}?(\d{1,3}(?:\s*(?:a|-)\s*\d{1,3})?\s*(?:min\w*|h\w*))/.exec(n))) ent.tempo = m[1]
  if (Object.keys(ent).length) return { tipo: 'acao', acao: 'configurar_entrega', args: ent }
  if (/\bbotao\b.*\bwhats\w*|\bchamar no whats\w*/.test(n)) return { tipo: 'acao', acao: 'botao_whatsapp', args: { ativo: !/\b(tir\w*|desliga\w*|desativ\w*|remov\w*|esconde\w*|sem)\b/.test(n) } }
  const metodos: Record<string, RegExp> = { pix_na_entrega: /\bpix na entrega\b/, pix_automatico: /\bpix (automatico|online)\b/, cartao: /\b(cartao|credito|debito|maquininha)\b/, dinheiro: /\b(dinheiro|especie)\b/, pix: /\bpix\b(?! (na entrega|automatico|online))/ }
  const pagTxt = /\b(pagamento|aceit\w*|receb\w*|cobr\w*)\b/.test(n) || /\b(liga|desliga|ativa|desativa|tira|remove)\b/.test(n)
  const quais = Object.entries(metodos).filter(([, r]) => r.test(n)).map(([k]) => k)
  if (quais.length && pagTxt && !citados.length && !/\bchave\b/.test(n)) {
    const neg = /\b(para de aceitar|pare de aceitar|nao (aceit\w*|recebo|recebemos|quero)|deixa de aceitar|desliga\w*|desativ\w*|tir\w*|remov\w*|sem)\b/.test(n)
    return { tipo: 'acao', acao: 'configurar_pagamento', args: Object.fromEntries(quais.map((k) => [k, !neg])) }
  }
  if (/\bchave pix\b/.test(n) && muda) return { tipo: 'faltou', msg: 'Por segurança, a chave Pix e o Mercado Pago só são alterados em Sua empresa → Recebimento. ⟦btn:/x/sua-empresa|Abrir Sua empresa⟧' }

  // ---------- dados da empresa ----------
  const digitos = t.replace(/[^\d]/g, '')
  if (/\b(whats\w*|zap|telefone|celular|numero|fone)\b/.test(n) && digitos.length >= 10 && digitos.length <= 13 && muda && !citados.length) return { tipo: 'acao', acao: 'alterar_whatsapp', args: { texto: digitos } }
  if (/\b(insta\w*)\b/.test(n) && muda) { const h = /@([a-z0-9_.]{2,30})/i.exec(t)?.[1] || textoNovo(t, /insta\w*/i).replace(/^@/, '').split(' ')[0].toLowerCase(); if (h) return { tipo: 'acao', acao: 'alterar_instagram', args: { texto: h } } }
  if (/\bendereco\b|\b(nos )?mudamos (para|pra)\b|\bnova loja fica\b|\bagora (a loja )?fica (na|no|em)\b/.test(n) && (muda || /mudamos|fica/.test(n))) {
    const v = textoNovo(t, /endere[cç]o/i) || (/\b(?:mudamos|mudou) (?:para|pra) (.+)$/i.exec(t)?.[1] || /\bfica (?:na|no|em) (.+)$/i.exec(t)?.[1] || '').trim()
    return v.length >= 6 ? { tipo: 'acao', acao: 'alterar_endereco', args: { texto: limpa(v) } } : { tipo: 'faltou', msg: 'Qual o novo endereço? (rua, número, bairro e cidade)' }
  }
  if (/\bnome d[ao] (empresa|loja)\b|\b(empresa|loja) (agora )?(se )?chama\b|\brenome\w* a (empresa|loja)\b/.test(n)) { const v = textoNovo(t, /(?:nome d[ao] (?:empresa|loja)|chama|renome\w* a (?:empresa|loja))/i) || /\bchama\s+(.+)$/i.exec(t)?.[1] || ''; return v ? { tipo: 'acao', acao: 'alterar_nome', args: { texto: limpa(v) } } : { tipo: 'faltou', msg: 'Qual o novo nome da empresa?' } }
  if (/\bdescricao\b|\bsobre (a|nos)\b/.test(n) && !citados.length && muda) { const v = textoNovo(t, /descri[cç][aã]o|sobre (?:a|n[oó]s)/i); return v ? { tipo: 'acao', acao: 'alterar_descricao', args: { texto: v } } : { tipo: 'faltou', msg: 'Qual deve ser a nova descrição da empresa? Se quiser, peça "sugira uma descrição".' } }

  // ---------- produtos ----------
  // vários produtos com valores próprios: "brigadeiro 6 e torta 45", "o brigadeiro pra 6 e a torta pra 45"
  if (citados.length > 1 && !porcento(n) && muda) {
    const pedacos = t.split(/\s*(?:,|;|\be\b|\btambém\b)\s*/i).filter(Boolean), itens: { produto: number; valor: number }[] = []
    for (const pd of pedacos) { const ps = await produtosCitados(pd, lista), v = dinheiro(pd) ?? (/(\d{1,6}(?:[.,]\d{1,2})?)\s*$/.exec(nn(pd)) ? num(/(\d{1,6}(?:[.,]\d{1,2})?)\s*$/.exec(nn(pd))![1]) : null); if (ps.length === 1 && v != null && v > 0) itens.push({ produto: ps[0].id, valor: v }) }
    if (itens.length > 1 && new Set(itens.map((x) => x.produto)).size === itens.length) return { tipo: 'lote', itens, regra: 'valores informados' }
  }
  // reajuste em grupo: "aumenta 10% todos os doces", "baixa 2 reais de todos os bolos", "todos os produtos +5%"
  const todos = /\b(todos|todas|tudo|catalogo inteiro|todo o (catalogo|cardapio))\b/.test(n), cat = categoriaCitada(t, lista, (await import('../ai/empresa-admin.js')).parecido)
  const sobe = /\b(aument\w*|sob[ei]\w*|suba|reajust\w*|acrescent\w*|mais caro|\+)\b/.test(n) || /\+\s*\d/.test(n), desce = /\b(diminu\w*|baix\w*|reduz\w*|desconto de|menos|mais barato)\b/.test(n)
  const pc = porcento(n)
  if ((todos || (cat && !citados.length) || citados.length > 1) && (sobe || desce) && (pc != null || dinheiro(n) != null) && !/\b(promoc\w*|oferta)\b/.test(n)) {
    const alvo = citados.length > 1 ? citados : lista.filter((p) => !p.variacoes?.length && (todos && !cat ? true : nrm(p.categoria) === nrm(cat || '')))
    if (!alvo.length) return { tipo: 'faltou', msg: `Não encontrei produtos${cat ? ` na categoria ${cat}` : ''} para reajustar.` }
    const d = dinheiro(n), f = (pr: number) => arred(pc != null ? pr * (1 + (sobe ? 1 : -1) * pc / 100) : pr + (sobe ? 1 : -1) * (d || 0))
    const itens = alvo.map((p) => ({ produto: p.id, valor: f(p.preco) })).filter((x) => x.valor > 0)
    if (itens.length !== alvo.length) return { tipo: 'faltou', msg: 'Esse reajuste deixaria algum preço zerado ou negativo. Confira o valor.' }
    return { tipo: 'lote', itens, regra: `${sobe ? '+' : '−'}${pc != null ? `${pc}%` : brl(d || 0)}${cat ? ` em ${cat}` : todos ? ' em todo o catálogo' : ''}` }
  }

  // contexto: "e o da torta também" / "o mesmo pro bolo" → repete a última ação com o produto novo
  if (ultimo && /^(e |tambem |o mesmo|a mesma|faz o mesmo|igual)/.test(n) && citados.length === 1 && citados[0].id !== ultimo.produto && /^produto_/.test(ultimo.acao) && !dinheiro(n) && !pc)
    return { tipo: 'acao', acao: ultimo.acao, args: { ...ultimo.args, produto: String(citados[0].id), variacao: undefined } }

  if (citados.length > 1 && muda) return { tipo: 'faltou', msg: `Encontrei mais de um produto nessa frase (${citados.map((p) => p.nome).join(', ')}). Qual deles devo alterar?` }
  const p = citados[0]
  if (!p) return null
  const pid = String(p.id)
  // oferta / promoção
  if (/\b(promoc\w*|oferta|desconto|liquida\w*)\b/.test(n)) {
    if (/\b(tir\w*|remov\w*|acab\w*|encerr\w*|cancel\w*|desliga\w*|desativ\w*|sem promoc\w*|sem oferta|volt\w* (ao|pro) preco normal)\b/.test(n)) return { tipo: 'acao', acao: 'produto_oferta', args: { produto: pid, ativo: false } }
    const v = pc != null ? arred(p.preco * (1 - pc / 100)) : dinheiro(n)
    return v ? { tipo: 'acao', acao: 'produto_oferta', args: { produto: pid, valor: v, ativo: true } } : { tipo: 'faltou', msg: `Qual o preço da oferta de ${p.nome}? (o normal é ${brl(p.preco)}) Ex.: "por R$ 4,50" ou "10% de desconto".` }
  }
  // estoque
  if (/\b(acab\w*|esgot\w*|sem estoque|zer\w* o estoque|nao tem mais)\b/.test(n)) return { tipo: 'acao', acao: 'produto_estoque', args: { produto: pid, valor: 0, operacao: 'definir' } }
  if (/\b(estoque|unidades|un|pecas|chegou|chegaram|chegou mais|repus|repor|entrou|entraram)\b/.test(n)) {
    const q = /(\d{1,6})/.exec(n.replace(/r\$\s*\d+([.,]\d+)?/g, '')); if (!q) return { tipo: 'faltou', msg: `Quantas unidades de ${p.nome}? (agora: ${p.estoque == null ? 'sem controle' : p.estoque})` }
    const op = /\b(chegou|chegaram|repus|entrou|entraram|mais|soma|acrescent\w*|adicion\w*)\b/.test(n) ? 'somar' : /\b(vendi|saiu|sairam|tir\w*|menos|baix\w*)\b/.test(n) ? 'subtrair' : 'definir'
    return { tipo: 'acao', acao: 'produto_estoque', args: { produto: pid, valor: Number(q[1]), operacao: op } }
  }
  // pausar / reativar / excluir
  if (/\b(exclu\w*|apag\w*|delet\w*|remov\w* de vez|remov\w* definitivamente)\b/.test(n)) return { tipo: 'acao', acao: 'excluir_produto', args: { produto: pid } }
  if (/\b(tir\w*\b.*\b(do|da) (cardapio|catalogo|ar|site|loja|vitrine)|escond\w*|ocult\w*|nao vend\w* mais|paus\w*|desativ\w*|para de vender|pare de vender|indisponivel)\b/.test(n)) return { tipo: 'acao', acao: 'produto_pausar', args: { produto: pid } }
  if (/\b(volt\w* a vender|volt\w* (pro|para o) (cardapio|catalogo)|reativ\w*|ativ\w*|mostr\w* de novo|coloc\w* de volta|disponivel)\b/.test(n)) return { tipo: 'acao', acao: 'produto_ativar', args: { produto: pid } }
  // categoria, nome, descrição
  if (/\bcategoria\b/.test(n)) { const v = textoNovo(t, /categoria/i) || /\b(?:para|pra|na|em)\s+(?:a\s+)?categoria\s+(.+)$/i.exec(t)?.[1] || ''; return v ? { tipo: 'acao', acao: 'produto_categoria', args: { produto: pid, texto: limpa(v.replace(/^categoria\s+/i, '')) } } : { tipo: 'faltou', msg: `Qual a nova categoria de ${p.nome}?` } }
  if (/\b(nome|renome\w*|chamar|se chama)\b/.test(n)) { const v = textoNovo(t, /(?:nome|renome\w*|chamar|se chama)/i); if (v && nrm(v) !== nrm(p.nome)) return { tipo: 'acao', acao: 'produto_nome', args: { produto: pid, texto: v } } }
  if (/\bdescricao\b/.test(n)) { const v = textoNovo(t, /descri[cç][aã]o/i); return v ? { tipo: 'acao', acao: 'produto_descricao', args: { produto: pid, texto: v } } : { tipo: 'faltou', msg: `Qual a nova descrição de ${p.nome}? Se quiser, peça "sugira uma descrição para ${p.nome}".` } }
  // preço (absoluto ou relativo)
  const d = dinheiro(n)
  if (pc != null && (sobe || desce)) return { tipo: 'acao', acao: 'produto_preco', args: { produto: pid, valor: arred(p.preco * (1 + (sobe ? 1 : -1) * pc / 100)) } }
  if (d != null) {
    const relativo = (sobe || desce) && !/\b(pra|para|a|em)\s+(r\$\s*)?\d/.test(n.replace(/\b(sob\w*|aument\w*|baix\w*|diminu\w*|reduz\w*)\s+(em|mais)\b/, ''))
    const v = relativo ? arred(p.preco + (sobe ? d : -d)) : d
    if (!(v > 0)) return { tipo: 'faltou', msg: 'O preço precisa ficar acima de zero.' }
    if (v === p.preco && !p.variacoes?.length) return { tipo: 'faltou', msg: `${p.nome} já custa ${brl(p.preco)}. Nada a mudar.` }
    return { tipo: 'acao', acao: 'produto_preco', args: { produto: pid, valor: v } }
  }
  if (/\b(preco|valor|custa|cobr\w*)\b/.test(n) && muda) return { tipo: 'faltou', msg: `Qual o novo preço de ${p.nome}? (agora: ${brl(p.preco)})` }
  return null
}
/** Parece pedido de gestão (mesmo que não entendido)? Então o modo responde — nunca a pesquisa nem o chat genérico. */
export async function pareceGestao(e: { b: any }, texto: string): Promise<boolean> {
  const EA = await import('../ai/empresa-admin.js'), n = nn(texto)
  if (/\b(preco|precos|estoque|oferta|promoc\w*|produto|produtos|servico|servicos|cardapio|catalogo|categoria|loja|empresa|pedidos|entrega|delivery|retirada|frete|taxa|pagamento|pix|cartao|dinheiro|whats\w*|instagram|endereco|horario|funcionamento|descricao|vitrine|cliente[s]? da loja)\b/.test(n)) return true
  return (await produtosCitados(texto, (await EA.produtos(Number(e.b.id))) as ProdLista[])).length > 0
}

/** Resposta de consulta a partir dos dados REAIS da empresa ativa (nada é alterado). */
export async function responderConsulta(u: SessionUser, e: Ativa, c: { produtos: ProdLista[]; topico: string }): Promise<string> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id), x = await EA.dados(bid), r: any = await EA.runEmpresaTool(u, 'empresa_consultar', {})
  const linhaProd = (p: ProdLista) => `- **${p.nome}**: ${p.oferta != null ? `~~${brl(p.preco)}~~ ${brl(p.oferta)} (oferta)` : brl(p.preco)}${p.estoque != null ? ` · estoque ${p.estoque}` : ''}${p.categoria ? ` · ${p.categoria}` : ''}${p.ativo ? '' : ' · **pausado**'}${p.variacoes?.length ? ` · ${p.variacoes.length} variações` : ''}`
  const todos = (await EA.produtos(bid)) as ProdLista[], E = r?.entrega || {}, P = r?.pagamento || {}
  switch (c.topico) {
    case 'produto': return c.produtos.map(linhaProd).join('\n') + (c.produtos.length === 1 ? `\n\nQuer mudar algo? Ex.: "muda o ${c.produtos[0].nome} para R$ …".` : '')
    case 'produtos': return todos.length ? `Seu catálogo na ${e.nome} tem ${todos.length} ${todos.length === 1 ? 'item' : 'itens'}:\n${todos.slice(0, 30).map(linhaProd).join('\n')}${todos.length > 30 ? `\n…e mais ${todos.length - 30}.` : ''}` : `A ${e.nome} ainda não tem produtos. Quer criar? Ex.: "crie um produto Brigadeiro por R$ 5" (com a foto).`
    case 'ofertas': { const of = todos.filter((p) => p.oferta != null); return of.length ? `Em oferta agora:\n${of.map(linhaProd).join('\n')}` : 'Nenhum produto está em oferta agora.' }
    case 'estoque': { const es = (c.produtos.length ? c.produtos : todos).filter((p) => p.estoque != null); return es.length ? `Estoque:\n${es.sort((a, b) => (a.estoque ?? 0) - (b.estoque ?? 0)).map((p) => `- **${p.nome}**: ${p.estoque} un.${p.estoque === 0 ? ' (esgotado)' : ''}`).join('\n')}` : 'Nenhum produto tem controle de estoque ligado.' }
    case 'categorias': { const cs = [...new Set(todos.map((p) => p.categoria).filter(Boolean))]; return cs.length ? `Categorias: ${cs.join(', ')}.` : 'Os produtos ainda não têm categoria.' }
    case 'horario': return x.horario ? `Horário da ${e.nome}: ${x.horario}.${x.horarioCfg?.modo === 'fechado' ? ' (Os pedidos estão **pausados** agora.)' : ''}` : `A ${e.nome} ainda não tem horário configurado. Ex.: "abrimos de segunda a sábado das 8h às 18h".`
    case 'endereco': return x.endereco ? `Endereço: ${x.endereco}.` : 'O endereço ainda não foi cadastrado.'
    case 'contato': return `WhatsApp: ${x.zap || '(não cadastrado)'}${x.contato ? ` · Contato: ${x.contato}` : ''}.`
    case 'instagram': return x.insta ? `Instagram: @${x.insta}.` : 'O Instagram ainda não foi cadastrado.'
    case 'descricao': return x.sobre ? `Descrição atual: "${x.sobre}"` : 'A empresa ainda não tem descrição. Peça "sugira uma descrição" se quiser ajuda.'
    case 'pedidos': return x.horarioCfg?.modo === 'fechado' ? `Os pedidos da ${e.nome} estão **pausados** (loja fechada). Diga "reabra a loja" para voltar a receber.` : `A ${e.nome} está **recebendo pedidos**${x.horario ? ` conforme o horário (${x.horario})` : ''}.`
    case 'entrega': return `Entrega: ${E.entrega ? `ligada (taxa ${brl(E.taxa)}, até ${E.raioKm} km${E.pedidoMinimo ? `, mínimo ${brl(E.pedidoMinimo)}` : ''}${E.tempo ? `, ${E.tempo}` : ''})` : 'desligada'} · Retirada: ${E.retirada ? 'ligada' : 'desligada'}${(r?.freteGratis || []).filter((f: any) => f.ativo).length ? ` · Frete grátis acima de ${brl(r.freteGratis.find((f: any) => f.ativo).valorMinimo)}` : ''}.`
    case 'pagamento': return `Formas de pagamento: ${[P.pix ? 'Pix (chave)' : '', P.pixNaEntrega ? 'Pix na entrega' : '', P.dinheiro ? 'dinheiro' : '', P.cartao ? 'cartão' : '', P.pixAutomatico ? 'Pix automático (Mercado Pago)' : ''].filter(Boolean).join(', ') || 'nenhuma'}.`
    default: return `**${e.nome}**\n- Descrição: ${x.sobre || '—'}\n- WhatsApp: ${x.zap || '—'}\n- Endereço: ${x.endereco || '—'}\n- Horário: ${x.horario || '—'}\n- Pedidos: ${x.horarioCfg?.modo === 'fechado' ? 'pausados' : 'recebendo'}\n- Produtos: ${todos.length}`
  }
}
/** Sugestão: texto proposto (IA, com reserva determinística) — vira PRÉVIA; ou orientação de preço (nada muda). */
export async function sugerir(u: SessionUser, e: Ativa, s: { alvo: 'empresa' | 'produto'; campo: 'descricao' | 'preco'; produto?: ProdLista }): Promise<{ texto?: string; acao?: string; args?: any; msg?: string }> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id), x = await EA.dados(bid), todos = (await EA.produtos(bid)) as ProdLista[]
  if (s.campo === 'preco') {
    const p = s.produto; if (!p) return { msg: 'De qual produto você quer uma sugestão de preço?' }
    const mesmos = todos.filter((o) => o.id !== p.id && o.categoria && o.categoria === p.categoria && o.preco > 0), media = mesmos.length ? mesmos.reduce((a, b) => a + b.preco, 0) / mesmos.length : null
    return { msg: `**${p.nome}** está hoje por ${brl(p.preco)}${p.oferta != null ? ` (em oferta por ${brl(p.oferta)})` : ''}.${media ? ` Na categoria ${p.categoria}, a média dos seus outros itens é ${brl(media)}.` : ''} Para decidir, some o custo dos ingredientes/insumos, embalagem e a sua margem. Quando decidir, diga "muda o ${p.nome} para R$ …" e eu mostro a prévia — nada muda sem você confirmar.` }
  }
  const lim = s.alvo === 'empresa' ? 200 : 600, alvoNome = s.alvo === 'produto' ? s.produto!.nome : e.nome
  const base = s.alvo === 'produto' ? `Produto: ${s.produto!.nome}. Categoria: ${s.produto!.categoria || '—'}. Descrição atual: ${s.produto!.descricao || '—'}. Preço: ${brl(s.produto!.preco)}.` : `Empresa: ${e.nome}. Categoria: ${x.categoria || '—'}. Descrição atual: ${x.sobre || '—'}. Alguns produtos: ${todos.slice(0, 8).map((p) => p.nome).join(', ') || '—'}. Cidade/endereço: ${x.endereco || '—'}.`
  let texto = ''
  try {
    const P = await import('../ai/provider.js')
    if (await P.readyCount('conversa')) {
      const m: any = await P.complete([{ role: 'system', content: `Escreva UMA descrição curta e atraente, em português do Brasil, para o catálogo (até ${lim} caracteres). Use só os dados fornecidos; não invente prêmios, preços nem promessas. Responda apenas com o texto, sem aspas.` }, { role: 'user', content: base }], undefined, { task: 'conversa', maxMs: 15000 } as any)
      texto = String(m?.content || '').replace(/^["“]|["”]$/g, '').trim()
    }
  } catch { /* sem IA: sugestão pelos dados */ }
  if (!texto || texto.length < 15 || /n[aã]o tenho (essa )?informa|como (uma )?ia|n[aã]o posso/i.test(texto)) {
    texto = s.alvo === 'produto' ? `${s.produto!.nome}${s.produto!.categoria ? ` — ${s.produto!.categoria.toLowerCase()}` : ''} feito com capricho pela ${e.nome}.${s.produto!.descricao ? ' ' + s.produto!.descricao : ''} Peça já o seu!`
      : `${e.nome}${x.categoria ? ` — ${String(x.categoria).toLowerCase()}` : ''}${todos.length ? ` com ${todos.slice(0, 3).map((p) => p.nome.toLowerCase()).join(', ')}` : ''} e atendimento caprichado. Faça seu pedido!`
  }
  texto = texto.slice(0, lim).trim()
  return s.alvo === 'produto' ? { texto, acao: 'produto_descricao', args: { produto: String(s.produto!.id), texto } } : { texto, acao: 'alterar_descricao', args: { texto } }
}

/* ---------- apoio da IA (mesmas ferramentas oficiais) ---------- */
async function interpretarComIA(u: SessionUser, texto: string): Promise<{ acao: string; args: any } | null> {
  try {
    const P = await import('../ai/provider.js'); if (!(await P.readyCount('conversa'))) return null
    const EA = await import('../ai/empresa-admin.js')
    const tools = [...EA.EMPRESA_TOOLS.filter((x) => x.function.name === 'empresa_alterar'), { type: 'function' as const, function: { name: 'produto_criar', description: 'Cria um produto ou serviço novo no catálogo da empresa ativa.', parameters: { type: 'object', properties: { tipo: { type: 'string', enum: ['produto', 'servico'] }, nome: { type: 'string' }, preco: { type: 'number' }, descricao: { type: 'string' }, categoria: { type: 'string' } }, required: ['nome'] } } }]
    const m: any = await P.complete([{ role: 'system', content: 'Você traduz o pedido do dono da empresa em UMA chamada de ferramenta (empresa_alterar ou produto_criar), sem executar nada: a alteração só será salva depois que ele confirmar a prévia. Não invente valores que ele não disse. Se o pedido não for uma alteração da empresa, não chame ferramenta.' }, { role: 'user', content: String(texto).slice(0, 1000) }], tools as any, { temperature: 0.1 })
    const tc = (m?.tool_calls || [])[0]; if (!tc) return null
    const args = J<any>(tc.function?.arguments, {})
    if (tc.function?.name === 'produto_criar') return { acao: 'produto_criar', args: { tipo: args.tipo === 'servico' ? 'servico' : 'produto', nome: String(args.nome || ''), preco: Number.isFinite(Number(args.preco)) ? Number(args.preco) : null, descricao: String(args.descricao || ''), categoria: String(args.categoria || ''), foto: '' } }
    if (tc.function?.name === 'empresa_alterar' && args.acao && args.acao !== 'trocar_empresa_ativa') { const { acao, confirmacao, ...rest } = args; return { acao: String(acao), args: rest } }
  } catch { /* sem IA: segue pelas regras locais */ }
  return null
}

/* ---------- prévia (lida do banco, nada é gravado) ---------- */
const ROT_ACAO: Record<string, string> = { produto_preco_lote: 'Reajuste de preços', produto_estoque: 'Estoque', produto_variacao_disponivel: 'Disponibilidade', configurar_entrega: 'Entrega e retirada', frete_gratis: 'Frete grátis', configurar_pagamento: 'Formas de pagamento', botao_whatsapp: 'Botão do WhatsApp', produto_preco: 'Novo preço', produto_oferta: 'Oferta', produto_nome: 'Novo nome', produto_descricao: 'Nova descrição', produto_categoria: 'Nova categoria', produto_pausar: 'Pausar produto', produto_ativar: 'Reativar produto', produto_foto: 'Nova foto', produto_criar: 'Novo produto', excluir_produto: 'Excluir produto', alterar_descricao: 'Nova descrição da empresa', alterar_nome: 'Novo nome da empresa', alterar_whatsapp: 'Novo WhatsApp', alterar_endereco: 'Novo endereço', alterar_instagram: 'Novo Instagram', alterar_contato: 'Novo contato', alterar_horario: 'Novo horário', pausar_pedidos: 'Pausar pedidos', reativar_pedidos: 'Reativar pedidos' }
type Ativa = { b: any; x: any; nome: string; propria: boolean }
async function cardProduto(u: SessionUser, e: Ativa, pid: number): Promise<Card> {
  const EA = await import('../ai/empresa-admin.js'), f: any = await EA.chamar(u, e as any, 'GET', `/api/v2/ads/${e.b.id}/products/${pid}`)
  const lista = await EA.produtos(Number(e.b.id)), p = lista.find((x) => x.id === pid)
  return { nome: f.nome, preco: Number(f.preco) || 0, oferta: p?.oferta ?? null, descricao: f.descricao || '', categoria: f.categoria || '', foto: f.thumb || (f.fotos || [])[0] || null, ativo: p ? p.ativo : true, tipo: f.tipo, estoque: p?.estoque == null ? 'Sem controle' : `${p.estoque} un.` }
}
const txtEntrega = (z: any) => `${z.entrega ? `Entrega ligada (taxa ${brl(Number(z.taxa) || 0)}, até ${Number(z.raio ?? 3)} km${Number(z.minimo) ? `, mínimo ${brl(z.minimo)}` : ''}${z.tempo ? `, ${z.tempo}` : ''})` : 'Entrega desligada'} · Retirada ${z.retirada !== false ? 'ligada' : 'desligada'}`
const txtPag = (z: any) => [z.pix !== false ? 'Pix (chave)' : '', z.pixentrega ? 'Pix na entrega' : '', z.dinheiro !== false ? 'Dinheiro' : '', z.cartao ? 'Cartão' : '', z.online ? 'Pix automático' : ''].filter(Boolean).join(', ') || 'Nenhuma'
const cardEmpresa = (e: Ativa, x: any): Card => ({ entrega: txtEntrega({ retirada: true, entrega: false, ...(x.entrega || {}) }), pagamento: txtPag(x.pagamento || {}), botao: x.mensagemPronta?.ativo ? 'Ligado' : 'Desligado', empresa: x.empresa || e.nome, descricao: x.sobre || x.texto || '', whatsapp: x.zap || '', endereco: x.endereco || '', instagram: x.insta || '', contato: x.contato || '', logo: x.logo || null, horario: x.horario || '', pedidos: x.horarioCfg?.modo === 'fechado' ? 'Pausados' : 'Recebendo' })
export async function montarPrevia(u: SessionUser, e: Ativa, acao: string, args: any): Promise<{ ok: true; previa: Previa; args: any } | { ok: false; msg: string }> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id)
  const titulo = ROT_ACAO[acao] || 'Alteração'
  if (acao === 'produto_criar') {
    const nome = String(args.nome || '').trim(), preco = Number(args.preco)
    if (!nome) return { ok: false, msg: 'Qual o nome do novo produto? Ex.: "crie um produto Brigadeiro gourmet por R$ 6,50".' }
    if (!(preco > 0) && args.tipo !== 'servico') return { ok: false, msg: `Qual o preço de **${nome}**? Ex.: "por R$ 6,50".` }
    if (args.foto && String(args.foto).length >= 900_000) return { ok: false, msg: 'Essa foto é muito grande para o catálogo. Envie uma imagem menor (até ~600 KB).' }
    if (args.tipo !== 'servico' && !args.foto) return { ok: false, msg: `Para publicar **${nome}** no catálogo, envie uma foto do produto aqui na conversa (o catálogo exige foto nos produtos).`, }
    const existe = (await EA.produtos(bid)).find((p) => nrm(p.nome) === nrm(nome)); if (existe) return { ok: false, msg: `Já existe **${existe.nome}** no catálogo. Quer alterar esse produto? Ex.: "altere o preço do ${existe.nome} para R$ 10".` }
    return { ok: true, args, previa: { tipo: 'produto_novo', titulo, antes: null, depois: { nome, preco: preco > 0 ? preco : null, descricao: args.descricao || '', categoria: args.categoria || '', foto: args.foto || null, ativo: true, tipo: args.tipo }, destaque: ['nome', 'preco', 'descricao', 'foto'] } }
  }
  if (acao === 'produto_preco_lote') {
    const lista = await EA.produtos(bid), itens: NonNullable<Previa['itens']> = []
    for (const it of (args.itens || []) as { produto: number; valor: number }[]) { const p = lista.find((x) => x.id === Number(it.produto)); if (!p) return { ok: false, msg: 'Um dos produtos não está mais no catálogo; peça de novo.' }; if (p.variacoes?.length) return { ok: false, msg: `${p.nome} tem variações com preços próprios; ajuste esse item separadamente.` }; if (!(Number(it.valor) > 0)) return { ok: false, msg: `O novo preço de ${p.nome} precisa ser maior que zero.` }; if (p.oferta != null && Number(it.valor) <= p.oferta) return { ok: false, msg: `${p.nome} está em oferta por ${brl(p.oferta)}; o preço normal precisa ficar acima disso.` }; itens.push({ nome: p.nome, antes: p.preco, depois: Number(it.valor) }) }
    if (!itens.length) return { ok: false, msg: 'Não encontrei produtos para reajustar.' }
    if (itens.length > 60) return { ok: false, msg: 'São muitos produtos de uma vez (mais de 60). Faça por categoria.' }
    return { ok: true, args, previa: { tipo: 'lote', titulo: `${titulo}${args.regra ? ` (${args.regra})` : ''}`, antes: null, depois: {}, destaque: ['preco'], itens } }
  }
  if (acao.startsWith('produto_') || acao === 'excluir_produto') {
    const loc = await EA.localizar(bid, args.produto, args.variacao)
    if (!loc.ok) return { ok: false, msg: `${loc.erro}${loc.opcoes?.length ? '\n' + loc.opcoes.map((x) => `- ${x}`).join('\n') : ''}` }
    const pid = Number(loc.alvo.p.id), antes = await cardProduto(u, e, pid), depois: Card = { ...antes }, destaque: string[] = []
    const a2 = { ...args, produto: String(pid), ...(loc.alvo.v ? { variacao: String(loc.alvo.v.id) } : {}) }
    if (acao === 'produto_preco') { const v = Number(args.valor); if (!(v > 0)) return { ok: false, msg: 'Qual o novo preço? Ex.: "R$ 29,90".' }; if (loc.alvo.v) { depois.nome = `${antes.nome} · ${loc.alvo.v.rotulo}`; antes.nome = depois.nome; antes.preco = loc.alvo.v.preco } depois.preco = v; destaque.push('preco') }
    else if (acao === 'produto_oferta') { if (args.ativo === false) { depois.oferta = null; destaque.push('oferta') } else { const v = Number(args.valor); if (!(v > 0)) return { ok: false, msg: 'Qual o preço da oferta?' }; if (v >= Number(antes.preco)) return { ok: false, msg: `O preço da oferta (${brl(v)}) precisa ser menor que o preço normal (${brl(Number(antes.preco))}).` }; depois.oferta = v; destaque.push('oferta') } }
    else if (acao === 'produto_nome') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual o novo nome?' }; depois.nome = v.slice(0, 80); destaque.push('nome') }
    else if (acao === 'produto_descricao') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual a nova descrição?' }; if (v.length > 600) return { ok: false, msg: `A descrição do produto pode ter até 600 caracteres (esta tem ${v.length}).` }; depois.descricao = v; destaque.push('descricao') }
    else if (acao === 'produto_categoria') { const v = String(args.texto || '').trim(); if (!v) return { ok: false, msg: 'Qual a categoria?' }; depois.categoria = v.slice(0, 40); destaque.push('categoria') }
    else if (acao === 'produto_estoque') {
      const temVar = loc.alvo.p.variacoes?.length && !loc.alvo.v; if (temVar && loc.alvo.p.variacoes.length > 1) return { ok: false, msg: `${antes.nome} tem variações, e cada uma tem o próprio estoque. Qual variação?\n${loc.alvo.p.variacoes.map((v: any) => `- ${v.rotulo}`).join('\n')}` }
      const v0 = loc.alvo.v || (temVar ? loc.alvo.p.variacoes[0] : null), atual = v0 ? v0.estoque : loc.alvo.p.estoque, val = Math.floor(Number(args.valor))
      if (!(val >= 0)) return { ok: false, msg: `Quantas unidades de ${antes.nome}?` }
      const novo = args.operacao === 'somar' ? (atual ?? 0) + val : args.operacao === 'subtrair' ? (atual ?? 0) - val : val
      if (novo < 0) return { ok: false, msg: `O estoque de ${antes.nome} é ${atual ?? 0}; não dá para tirar ${val}.` }
      if (v0) { antes.nome = `${antes.nome} · ${v0.rotulo}`; depois.nome = antes.nome; a2.variacao = String(v0.id) }
      antes.estoque = atual == null ? 'Sem controle' : `${atual} un.`; depois.estoque = `${novo} un.${novo === 0 ? ' (esgotado)' : ''}`; destaque.push('estoque')
      a2.valor = novo; a2.operacao = 'definir' // a prévia mostra o número final; é ele que será gravado
    }
    else if (acao === 'produto_pausar') { depois.ativo = false; destaque.push('ativo') }
    else if (acao === 'produto_ativar') { depois.ativo = true; destaque.push('ativo') }
    else if (acao === 'produto_foto') { if (!args.foto) return { ok: false, msg: 'Envie a foto aqui na conversa junto com o pedido.' }; if (String(args.foto).length >= 900_000) return { ok: false, msg: 'Essa foto é muito grande para o catálogo. Envie uma imagem menor (até ~600 KB).' }; depois.foto = args.foto; destaque.push('foto') }
    else if (acao === 'excluir_produto') return { ok: true, args: a2, previa: { tipo: 'excluir_produto', titulo, antes, depois: { ...antes }, destaque: [], destrutiva: true, aviso: `Isso EXCLUI "${antes.nome}" do catálogo de forma definitiva (não dá para desfazer). Se quiser só tirar do ar por um tempo, peça para pausar.` } }
    else return { ok: false, msg: 'Não sei mostrar a prévia dessa alteração.' }
    if (acao === 'produto_pausar' && antes.ativo === false) return { ok: false, msg: `${antes.nome} já está pausado.` }
    if (acao === 'produto_ativar' && antes.ativo !== false) return { ok: false, msg: `${antes.nome} já está ativo no catálogo.` }
    return { ok: true, args: a2, previa: { tipo: 'produto', titulo, antes, depois, destaque } }
  }
  const x = await EA.dados(bid), antes = cardEmpresa(e, x), depois: Card = { ...antes }, destaque: string[] = []
  const tx = String(args.texto || '').trim()
  if (acao === 'alterar_descricao') { if (tx.length < 10) return { ok: false, msg: 'Escreva a nova descrição (pelo menos uma frase).' }; if (tx.length > 200) return { ok: false, msg: `A descrição da empresa pode ter até 200 caracteres (esta tem ${tx.length}). Quer encurtar? Se preferir, peça "sugira uma descrição".` }; depois.descricao = tx; destaque.push('descricao') }
  else if (acao === 'alterar_nome') { if (tx.length < 2) return { ok: false, msg: 'Qual o novo nome da empresa?' }; depois.empresa = tx.slice(0, 80); destaque.push('empresa') }
  else if (acao === 'alterar_whatsapp') { const d = tx.replace(/\D/g, ''); if (d.length < 10 || d.length > 13) return { ok: false, msg: 'Informe o WhatsApp com DDD. Ex.: (11) 98888-7777.' }; depois.whatsapp = d.length <= 11 ? '55' + d : d; args = { ...args, texto: depois.whatsapp }; destaque.push('whatsapp') } // grava o mesmo número da prévia (com 55)
  else if (acao === 'alterar_endereco') { if (tx.length < 6) return { ok: false, msg: 'Informe o endereço completo (rua, número, bairro e cidade).' }; depois.endereco = tx.slice(0, 200); destaque.push('endereco') }
  else if (acao === 'alterar_instagram') { depois.instagram = tx.replace(/^@/, '').slice(0, 60); destaque.push('instagram') }
  else if (acao === 'alterar_contato') { depois.contato = tx.slice(0, 80); destaque.push('contato') }
  else if (acao === 'alterar_horario') { const NOME: Record<string, string> = { seg: 'seg', ter: 'ter', qua: 'qua', qui: 'qui', sex: 'sex', sab: 'sáb', dom: 'dom' }; const ds: string[] = args.dias || []; depois.horario = `${ds.length === 7 ? 'Todos os dias' : `${NOME[ds[0]]} a ${NOME[ds[ds.length - 1]]}`}, ${args.abre}–${args.fecha} (demais dias fechados)`; destaque.push('horario') }
  else if (acao === 'configurar_entrega') {
    const e0 = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', modoTaxa: 'fixa', ...(x.entrega || {}) }, e1: any = { ...e0 }
    if (typeof args.entrega === 'boolean') e1.entrega = args.entrega; if (typeof args.retirada === 'boolean') e1.retirada = args.retirada
    if (args.taxa != null) { if (e0.modoTaxa === 'km') return { ok: false, msg: 'A taxa desta loja é calculada por distância (km). Ajuste os valores por km em Sua empresa → Entrega e pagamento.' }; e1.taxa = Number(args.taxa) }
    if (args.raio_km != null) { if (!(Number(args.raio_km) > 0 && Number(args.raio_km) <= 100)) return { ok: false, msg: 'O raio de entrega precisa ser de 1 a 100 km.' }; e1.raio = Number(args.raio_km) }
    if (args.pedido_minimo != null) e1.minimo = Number(args.pedido_minimo); if (args.tempo != null) e1.tempo = String(args.tempo)
    if (!e1.entrega && !e1.retirada) return { ok: false, msg: 'A loja precisa ter pelo menos uma forma de receber (entrega ou retirada).' }
    depois.entrega = txtEntrega(e1); if (depois.entrega === antes.entrega) return { ok: false, msg: `Já está assim: ${antes.entrega}.` }; destaque.push('entrega')
  }
  else if (acao === 'frete_gratis') {
    const INC = await import('../lib/incentivos.js'), fg = (await INC.listar(bid)).filter((i: any) => i.beneficio === 'frete_gratis' && i.metaTipo === 'valor'), at = fg.find((i: any) => i.ativo)
    antes.frete = at ? `Acima de ${brl(at.meta)}` : 'Desligado'
    if (args.ativo === false) { if (!at) return { ok: false, msg: 'O frete grátis já está desligado.' }; depois.frete = 'Desligado' }
    else { const v = Number(args.valor_minimo ?? args.valor); if (!(v >= 1)) return { ok: false, msg: 'A partir de qual valor de compra o frete fica grátis?' }; if (!(x.entrega || {}).entrega) return { ok: false, msg: 'Frete grátis só vale com entrega ligada. Quer ligar a entrega primeiro? Ex.: "liga a entrega com taxa de R$ 5".' }; depois.frete = `Acima de ${brl(v)} em produtos` }
    destaque.push('frete')
  }
  else if (acao === 'configurar_pagamento') {
    const p0 = { pix: true, dinheiro: true, cartao: false, pixentrega: false, online: false, ...(x.pagamento || {}) }, p1: any = { ...p0 }
    for (const [k, c] of [['pix', 'pix'], ['dinheiro', 'dinheiro'], ['cartao', 'cartao'], ['pix_na_entrega', 'pixentrega'], ['pix_automatico', 'online']] as const) if (typeof args[k] === 'boolean') p1[c] = args[k]
    if (!p1.pix && !p1.dinheiro && !p1.cartao && !p1.pixentrega && !p1.online) return { ok: false, msg: 'A loja precisa aceitar pelo menos uma forma de pagamento.' }
    if (p1.online && !p0.online) { const B = await import('../routes/businesses.js'); if (!(await B.mpPronto(e.b))) return { ok: false, msg: 'O Pix automático precisa do Mercado Pago da loja conectado. Conecte em Sua empresa → Recebimento (por segurança, isso não é feito pelo chat). ⟦btn:/x/sua-empresa|Abrir Sua empresa⟧' } }
    depois.pagamento = txtPag(p1); if (depois.pagamento === antes.pagamento) return { ok: false, msg: `As formas de pagamento já estão assim: ${antes.pagamento}.` }; destaque.push('pagamento')
  }
  else if (acao === 'botao_whatsapp') { const quer = args.ativo !== false; if (quer && !String(x.zap || '').replace(/\D/g, '')) return { ok: false, msg: 'A empresa ainda não tem WhatsApp cadastrado. Qual é o número (com DDD)?' }; depois.botao = quer ? 'Ligado' : 'Desligado'; if (depois.botao === antes.botao) return { ok: false, msg: `O botão do WhatsApp já está ${antes.botao.toLowerCase()}.` }; destaque.push('botao') }
  else if (acao === 'pausar_pedidos') { if (antes.pedidos === 'Pausados') return { ok: false, msg: 'Os pedidos já estão pausados.' }; depois.pedidos = 'Pausados'; destaque.push('pedidos') }
  else if (acao === 'reativar_pedidos') { if (antes.pedidos === 'Recebendo') return { ok: false, msg: 'A empresa já está recebendo pedidos.' }; depois.pedidos = 'Recebendo'; destaque.push('pedidos') }
  else return { ok: false, msg: 'Essa alteração ainda não tem prévia no modo Gestão da Empresa. Use Sua empresa → Ajustes para fazê-la.' }
  return { ok: true, args, previa: { tipo: 'empresa', titulo, antes, depois, destaque } }
}

/* ---------- execução (só depois do Confirmar) ---------- */
async function executar(u: SessionUser, e: Ativa, p: Proposta): Promise<{ ok: boolean; texto: string }> {
  const EA = await import('../ai/empresa-admin.js'), bid = Number(e.b.id)
  if (Number(p.bid) !== bid) return { ok: false, texto: 'A empresa ativa mudou depois da prévia; nada foi alterado. Peça de novo.' }
  if (p.acao === 'produto_criar') {
    const a = p.args, antes = (await EA.produtos(bid)).length
    await EA.chamar(u, e as any, 'POST', `/api/v2/ads/${bid}/products`, { tipo: a.tipo, nome: a.nome, preco: Number(a.preco) || 0, descricao: a.descricao || '', categoria: a.categoria || '', fotos: a.foto ? [a.foto] : [], ...(a.tipo === 'servico' ? { duracao: 30 } : {}) })
    const novo = (await EA.produtos(bid)).find((x) => nrm(x.nome) === nrm(a.nome))
    return novo && (await EA.produtos(bid)).length === antes + 1 ? { ok: true, texto: `Pronto! **${novo.nome}** foi publicado no catálogo da ${e.nome} por ${brl(novo.preco)}.` } : { ok: false, texto: 'O produto não apareceu no catálogo depois de salvar; considere que NÃO foi criado.' }
  }
  if (p.acao === 'produto_foto') {
    const { f, body } = await EA.corpoProduto(u, e as any, Number(p.args.produto))
    await EA.chamar(u, e as any, 'POST', `/api/v2/ads/${bid}/products`, { ...body, fotos: [p.args.foto, ...(body.fotos || []).slice(0, 1)], thumb: undefined })
    const depois: any = await EA.chamar(u, e as any, 'GET', `/api/v2/ads/${bid}/products/${p.args.produto}`)
    return (depois.fotos || [])[0] === p.args.foto ? { ok: true, texto: `Pronto! A foto de **${f.nome}** foi trocada no catálogo.` } : { ok: false, texto: 'A foto não foi confirmada no catálogo; considere que NÃO foi trocada.' }
  }
  if (p.acao === 'produto_preco_lote') { // um item por vez pela mesma ação oficial; cada um conferido no banco
    const ok: string[] = [], falhou: string[] = []
    const itens = p.args.itens as { produto: number; valor: number }[]
    for (let i = 0; i < itens.length; i++) { const it = itens[i], r = await EA.alterar(u, e as any, { acao: 'produto_preco', produto: String(it.produto), valor: it.valor, __confirmado: true }).catch((x: any) => ({ ok: false, error: String(x?.message || x) })); if (r?.ok) ok.push(`${r.produto || p.previa.itens?.[i]?.nome}: ${r.antes} → ${r.depois}`); else falhou.push(`${p.previa.itens?.[i]?.nome || 'item'}: ${String(r?.error || 'falhou').slice(0, 120)}`) }
    return { ok: ok.length > 0 && !falhou.length, texto: `${ok.length ? `Pronto! ${ok.length} ${ok.length === 1 ? 'preço atualizado' : 'preços atualizados'} na ${e.nome} (conferido no banco):\n${ok.map((x) => `- ${x}`).join('\n')}` : ''}${falhou.length ? `${ok.length ? '\n\n' : ''}Não alterei ${falhou.length}:\n${falhou.map((x) => `- ${x}`).join('\n')}` : ''}` }
  }
  const r = await EA.alterar(u, e as any, { ...p.args, acao: p.acao, __confirmado: true }) // a confirmação foi a própria prévia
  return { ok: !!r?.ok, texto: EA.formatar(r) }
}

/* ---------- modo ---------- */
const CONFIRMA = /^(confirmar( altera[cç][oõ]es)?|confirmo|confirma|sim|sim,? (pode )?(salvar|confirmar|publicar|excluir)|pode salvar|salvar|salva|publicar|publica|ok,? (pode )?salvar|excluir definitivamente|confirmar exclusao)$/
const CANCELA = /^(cancelar( altera[cç][oõ]es)?|cancela|cancele|n[aã]o|nao,? cancele|deixa|deixa pra l[aá]|esquece|desistir)$/
const EDITA = /^(editar( novamente)?|editar de novo|quero (editar|ajustar|mudar)|ajustar|corrigir|alterar a pr[eé]via)$/
const SAUDACAO_MODO = (nome: string, varias: boolean) => `🏪 **Gestão da Empresa** — ${nome}\n\nMe diga o que quer mudar e eu mostro uma **prévia** antes de salvar. Exemplos:\n- "altere o preço do Brigadeiro para R$ 6,50"\n- "crie um produto Bolo de pote por R$ 12, descrição: chocolate com morango" (envie a foto junto)\n- "mude a descrição da empresa para …"\n- "pause o produto Torta de limão" · "horário de segunda a sábado das 9h às 18h"${varias ? '\n\nVocê tem mais de uma empresa: para trocar, diga "gerenciar <nome da empresa>".' : ''}`
const rotuloEmpresa = async (u: SessionUser) => { const EA = await import('../ai/empresa-admin.js'); const a = await EA.empresaAtiva(u); return a }
const resposta = (content: string, meta?: any): Resposta => ({ content, cards: [], ...(meta ? { meta } : {}) })
const marca = (conv: string, id: string) => `⟦gest:${conv}|${id}⟧`
const novoId = () => 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)

async function propor(c: ContextoExec, e: Ativa, acao: string, args: any, estado: EstadoModo, pre = ''): Promise<{ resposta: Resposta; estado: EstadoModo }> {
  const pv = await montarPrevia(c.u, e, acao, args)
  if (!pv.ok) return { resposta: resposta(pv.msg), estado: { ...estado, etapa: 'aguardando', ...(acao === 'produto_criar' ? { rascunho: { acao, args } } : {}) } }
  const props: Proposta[] = ((estado.propostas as Proposta[]) || []).map((p) => (p.status === 'pendente' ? { ...p, status: 'substituida' as const } : p)).slice(-5)
  const p: Proposta = { id: novoId(), acao, args: pv.args, previa: pv.previa, status: 'pendente', bid: Number(e.b.id), empresa: e.nome, criadaEm: nowIso() }
  const txt = pv.previa.destrutiva ? `${pre}Confira antes: esta ação **exclui** um produto da ${e.nome}. Nada foi alterado ainda.` : `${pre}Confira a prévia na ${e.nome}. **Nada foi salvo ainda** — toque em Confirmar para salvar, Editar novamente para ajustar ou Cancelar.`
  const prodUlt = Number(pv.args?.produto) || undefined
  return { resposta: resposta(`${txt} ${marca(c.conversationId, p.id)}`, { gestao: { proposta: p.id, acao } }), estado: { ...estado, etapa: 'previa', propostas: [...props, p], atual: p.id, rascunho: null, ultima: { acao, args: pv.args, produto: prodUlt } } }
}
export const gestaoEmpresa: Modo = {
  id: 'gestao_empresa', nome: 'Gestão da Empresa', descricao: 'Altere produtos, serviços, preços, horários e dados da sua empresa conversando, com prévia antes de salvar.', icone: 'store', ocultoSemAcesso: true,
  persistente: true, // uma pergunta fora da empresa é respondida pelo chat comum sem desligar o modo
  ferramentas: ['empresa_consultar', 'empresa_alterar', 'produto_criar'],
  async acesso(u) {
    const EA = await import('../ai/empresa-admin.js')
    if (!(await EA.empresaAdminDisponivel(u))) return { liberado: false, codigo: 'sem_empresa', mensagem: 'Disponível para quem tem uma empresa vinculada.' }
    const a = await EA.empresaAtiva(u)
    return { liberado: true, codigo: 'ok', mensagem: '', ...(a.ok ? { businessId: Number(a.e.b.id) } : {}) }
  },
  async iniciar(c) {
    const a = await rotuloEmpresa(c.u)
    if (!a.ok) return { resposta: resposta(`🏪 **Gestão da Empresa**\n\n${a.erro}${a.opcoes ? '\n' + a.opcoes.map((x) => `- ${x}`).join('\n') + '\n\nDiga "gerenciar <nome da empresa>".' : ''}`), estado: { etapa: 'escolher_empresa', propostas: [] } }
    const { q } = await import('../db/index.js'), V = await import('../lib/vinculos.js')
    const n = Number((await q("SELECT COUNT(*) AS n FROM businesses WHERE owner_id = $1 AND status NOT IN ('institucional','lixeira')", [c.u.id]))[0]?.n || 0) + (await V.vinculadasValidas(c.u.id).catch(() => [] as any[])).length
    return { resposta: resposta(SAUDACAO_MODO(a.e.nome, n > 1)), estado: { etapa: 'aguardando', propostas: [] } }
  },
  async responder(c) {
    const r = await responderGestao(c)
    // pedido de gestão atendido pelo modo: nenhuma pesquisa na internet neste turno (bloqueio estrutural de ai/bloqueio-pesquisa.ts)
    if (r) (await import('../ai/bloqueio-pesquisa.js')).bloquearPesquisaNoTurno('modo Gestão da Empresa', 'operacao', 'empresa')
    return r
  },
}
async function responderGestao(c: ContextoExec): Promise<{ resposta: Resposta; estado: EstadoModo } | null> {
  {
    const EA = await import('../ai/empresa-admin.js'), t = String(c.texto || '').trim(), n = nrm(t).replace(/[!.?]+$/, '')
    const estado: EstadoModo = { ...(c.estado || { etapa: 'aguardando' }) }
    // trocar a empresa gerenciada (a mesma troca do seletor de empresas)
    const tr = /^(?:gerenciar|gerencie|trocar para|trocar de empresa para|usar a empresa|mudar para a empresa)\s+(?:a\s+empresa\s+)?(.+)$/i.exec(t)
    if (tr) { const r = await EA.runEmpresaTool(c.u, 'empresa_alterar', { acao: 'trocar_empresa_ativa', texto: tr[1] }); const a2 = await rotuloEmpresa(c.u); return { resposta: resposta(r?.ok ? `Pronto! Agora estou gerenciando a **${a2.ok ? a2.e.nome : tr[1]}**. O que você quer mudar?` : EA.formatar(r)), estado: { ...estado, etapa: 'aguardando', propostas: ((estado.propostas as Proposta[]) || []).map((p) => (p.status === 'pendente' ? { ...p, status: 'substituida' as const } : p)) } } }
    const at = await rotuloEmpresa(c.u); if (!at.ok) return { resposta: resposta(`${at.erro}${at.opcoes ? '\n' + at.opcoes.map((x) => `- ${x}`).join('\n') + '\n\nDiga "gerenciar <nome da empresa>".' : ''}`), estado }
    const e = at.e as Ativa
    const props = (estado.propostas as Proposta[]) || [], atual = props.find((p) => p.id === estado.atual && p.status === 'pendente')
    if (atual && CONFIRMA.test(n)) {
      if (atual.previa.destrutiva && !/excluir|confirm|sim/.test(n)) return { resposta: resposta('Para excluir, toque em Confirmar exclusão.'), estado }
      let r: { ok: boolean; texto: string }
      try { r = await executar(c.u, e, atual) } catch (x: any) { r = { ok: false, texto: `Não alterei: ${String(x?.message || 'algo deu errado').slice(0, 200)}` } }
      const novas = props.map((p) => (p.id === atual.id ? { ...p, status: (r.ok ? 'confirmada' : 'falhou') as Proposta['status'], resultado: r.texto } : p))
      return { resposta: resposta(`${r.texto}${r.ok ? '\n\nQuer ajustar mais alguma coisa?' : ''} ${marca(c.conversationId, atual.id)}`, { gestao: { proposta: atual.id, executada: r.ok } }), estado: { ...estado, etapa: 'aguardando', propostas: novas, atual: null } }
    }
    if (atual && CANCELA.test(n)) return { resposta: resposta(`Tudo bem, cancelei. Nada foi alterado na ${e.nome}. ${marca(c.conversationId, atual.id)}`), estado: { ...estado, etapa: 'aguardando', propostas: props.map((p) => (p.id === atual.id ? { ...p, status: 'cancelada' as const } : p)), atual: null } }
    if (atual && EDITA.test(n)) return { resposta: resposta(atual.acao === 'produto_criar' ? 'Certo! O que você quer mudar? Pode dizer, por exemplo: "preço 7,90", "nome Brigadeiro belga", "descrição: …", "categoria Doces" ou mandar outra foto.' : 'Certo! Me diga como deve ficar (ex.: o novo valor ou o novo texto).'), estado: { ...estado, etapa: 'editando' } }
    if (!atual && (CONFIRMA.test(n) || CANCELA.test(n) || EDITA.test(n))) { const ult = props[props.length - 1]; return { resposta: resposta(ult && ult.status === 'confirmada' ? 'Essa alteração já foi salva. Quer mudar mais alguma coisa?' : 'Não há nenhuma prévia aguardando confirmação. Me diga o que você quer mudar.'), estado } }
    // ajuste da prévia em aberto: "preço 7,90", "descrição: …", "nome …", só o valor/texto
    if (atual && (estado.etapa === 'editando' || /^(pre[cç]o|valor|nome|descri[cç][aã]o|categoria)\b/i.test(t) || (c.anexo && atual.acao === 'produto_criar'))) {
      const a = { ...atual.args }; let mudou = false
      const pr = /(?:pre[cç]o|valor)\s*:?\s*(?:r\$\s*)?(\d[\d.,]*)/i.exec(t) || (/^(?:r\$\s*)?(\d[\d.,]*)$/.exec(t))
      if (pr) { const v = num(pr[1]); if (atual.acao === 'produto_criar') a.preco = v; else if (['produto_preco', 'produto_oferta'].includes(atual.acao)) a.valor = v; mudou = true }
      const nm = /\bnome\s*:?\s*(.+?)(?:[,;]|$)/i.exec(t); if (nm) { if (atual.acao === 'produto_criar') a.nome = limpa(nm[1]); else if (['produto_nome', 'alterar_nome'].includes(atual.acao)) a.texto = limpa(nm[1]); mudou = true }
      const ds = /descri[cç][aã]o\s*:?\s*(.+)$/i.exec(t); if (ds) { if (atual.acao === 'produto_criar') a.descricao = limpa(ds[1]); else a.texto = limpa(ds[1]); mudou = true }
      const ct = /categoria\s*:?\s*(.+?)(?:[,;]|$)/i.exec(t); if (ct && atual.acao === 'produto_criar') { a.categoria = limpa(ct[1]); mudou = true }
      if (c.anexo && ['produto_criar', 'produto_foto'].includes(atual.acao)) { a.foto = c.anexo; mudou = true }
      if (!mudou && estado.etapa === 'editando' && ['produto_descricao', 'alterar_descricao', 'produto_nome', 'alterar_nome', 'alterar_endereco', 'alterar_whatsapp', 'produto_categoria'].includes(atual.acao)) { a.texto = limpa(t); mudou = true }
      if (mudou) return propor(c, e, atual.acao, a, { ...estado, etapa: 'aguardando' }, 'Prévia atualizada. ')
    }
    // pesquisa pedida explicitamente ("pesquise na internet o preço médio…"): é do chat comum (o modo continua ligado)
    if ((await import('../ai/prioridade.js')).decidir(t).prioridade === 'pesquisa_explicita') return null
    // 1) criação de produto (frase própria, antes de procurar um produto existente com nome parecido)
    const criar = interpretar(t, c.anexo || '')
    if (criar?.acao === 'produto_criar') { if (c.anexo) criar.args.foto = c.anexo; return propor(c, e, 'produto_criar', criar.args, estado) }
    // 2) entendimento flexível: consulta, sugestão, alteração (um item, vários, por categoria), dado faltando
    const en = await entender(c.u, e, t, estado).catch((x) => { console.error('[gestão] entender', x?.message); return null })
    // rascunho de produto esperando um dado (foto, preço, nome) — só se a mensagem não for outro pedido
    const rasc = estado.rascunho as any
    if (rasc && rasc.acao === 'produto_criar' && !criar && !(en && en.tipo !== 'faltou')) {
      const a = { ...rasc.args }, pr = /(?:r\$\s*)?(\d[\d.,]*)/.exec(t)
      if (c.anexo) a.foto = c.anexo; if (pr && !a.preco) a.preco = num(pr[1]); if (!a.nome && t && !pr && !c.anexo) a.nome = limpa(t)
      return propor(c, e, 'produto_criar', a, estado)
    }
    if (/^(o que (voce|vc) (pode|consegue) (fazer|mudar)|ajuda|exemplos?|como funciona)\b/.test(n)) return { resposta: resposta(SAUDACAO_MODO(e.nome, false)), estado }
    if (en?.tipo === 'consulta') {
      const txt = await responderConsulta(c.u, e, en)
      return { resposta: resposta(txt, { gestao: { consulta: en.topico } }), estado: { ...estado, ...(en.produtos.length === 1 ? { ultima: { acao: 'consulta', args: {}, produto: en.produtos[0].id } } : {}) } }
    }
    if (en?.tipo === 'sugestao') {
      const sg = await sugerir(c.u, e, en)
      if (sg.msg) return { resposta: resposta(sg.msg), estado: { ...estado, ...(en.produto ? { ultima: { acao: 'consulta', args: {}, produto: en.produto.id } } : {}) } }
      return propor(c, e, sg.acao!, sg.args, estado, `Sugestão de descrição (escrita a partir dos seus dados): "${sg.texto}"\n\n`)
    }
    if (en?.tipo === 'faltou') return { resposta: resposta(en.msg), estado }
    let it: { acao: string; args: any } | null = en?.tipo === 'acao' ? { acao: en.acao, args: en.args } : en?.tipo === 'lote' ? { acao: 'produto_preco_lote', args: { itens: en.itens, regra: en.regra } } : null
    if (!it) it = criar || interpretar(t, c.anexo || '')
    if (!it) it = await interpretarComIA(c.u, t)
    if (!it) {
      if (/^(oi|ola|bom dia|boa tarde|boa noite|obrigad|valeu|ok|beleza|blz|show|perfeito|otimo)\b/.test(n)) return { resposta: resposta(`Estou no modo Gestão da Empresa da **${e.nome}**. O que você quer ver ou mudar? Ex.: "qual o preço do …?", "muda o … para R$ …", "abrimos de segunda a sábado das 8h às 18h".`), estado }
      // parece gestão, mas não deu para saber o quê: pergunta aqui mesmo (nunca vai para a pesquisa na internet nem para o chat genérico)
      if (await pareceGestao(e, t)) return { resposta: resposta(`Não entendi exatamente o que mudar ou consultar na **${e.nome}**. Pode dizer de outro jeito? Por exemplo:\n- "qual o preço do Brigadeiro?" (consulta)\n- "muda o Brigadeiro para R$ 6" · "coloca a Torta em promoção por R$ 35" · "acabou o Bolo"\n- "aumenta 10% todos os Doces" · "só retirada" · "para de aceitar cartão"\n- "abrimos de segunda a sábado das 8h às 18h" · "fecha a loja hoje"`), estado }
      return null // não é da empresa (ex.: uma pergunta geral): o chat comum responde esta mensagem e o modo continua ligado
    }
    if (it.acao === 'produto_criar' && c.anexo) it.args.foto = c.anexo
    return propor(c, e, it.acao, it.args, estado)
  }
}
/** Prévia para o cartão ⟦gest:conversa|id⟧ (só o próprio usuário, só a sua conversa). */
export async function previaDaConversa(userId: number, conv: string, id: string) {
  const { one } = await import('../db/index.js')
  const r = await one("SELECT estado FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2 AND modo = 'gestao_empresa'", [conv, userId]); if (!r) return null
  const p = ((J<any>(r.estado, {}).propostas || []) as Proposta[]).find((x) => x.id === id); if (!p) return null
  return { id: p.id, acao: p.acao, status: p.status, empresa: p.empresa, previa: p.previa, resultado: p.resultado || '', atual: J<any>(r.estado, {}).atual === p.id }
}
/** A foto desta mensagem é para o modo Gestão da Empresa? (modo ligado agora pelo ⚡ ou já ativo na conversa) */
export async function usaFoto(userId: number, conv: string, modoPedido: unknown) {
  if (modoPedido === 'gestao_empresa') return true
  if (typeof modoPedido === 'string' || !conv) return false
  const { one } = await import('../db/index.js')
  return !!(await one("SELECT 1 AS x FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2 AND modo = 'gestao_empresa'", [conv, userId]))
}
