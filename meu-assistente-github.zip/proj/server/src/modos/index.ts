// Central de Modos Inteligentes: registro dos modos, estado por conversa e o motor que o chat consulta antes dos demais.
// Para criar um modo novo: implemente a interface Modo (tipos.ts) num arquivo próprio e acrescente-o em MODOS. Só entram
// aqui modos com capacidade real implementada; nada é exibido como disponível sem existir.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import type { ChatMsg } from '../ai/types.js'
import type { Modo, EstadoModo, Resposta } from './tipos.js'
import { consultorMarketing } from './marketing.js'
import { buscaProdutos } from './busca.js'
import { treinoAcompanhamento } from './treino.js'
import { gestaoEmpresa } from './gestao.js'

export const MODOS: Modo[] = [buscaProdutos, treinoAcompanhamento, consultorMarketing, gestaoEmpresa]
export const modoPorId = (id: string) => MODOS.find((m) => m.id === id) || null
/** Chave geral do painel (Motor do chat → Modos inteligentes). Desligada: o botão ⚡ some e o chat ignora qualquer modo. */
export async function modosLigados() { const { getConfig } = await import('../lib/settings.js'); return (await getConfig<any>('modos_chat', {})).ativo !== false }
/** Configuração de cada modo pelo administrador (Motor do chat → Modos do botão ⚡):
 *  ativo = o modo existe para os usuários (desligado: não aparece, não ativa por chamada direta nem sozinho);
 *  visivel = aparece no botão ⚡ (oculto, um modo ativo ainda atende quando a mensagem pede — ex.: "meu treino");
 *  ordem = posição no ⚡ (o "Chat normal" fica sempre em primeiro). Modos novos entram ativos, visíveis e no fim. */
export interface CfgModo { id: string; nome: string; descricao: string; ativo: boolean; visivel: boolean; ordem: number }
export async function cfgModos(): Promise<CfgModo[]> {
  const { getConfig } = await import('../lib/settings.js'); const c = (await getConfig<any>('modos_chat', {})).modos || {}
  return MODOS.map((m, i) => { const x = c[m.id] || {}; return { id: m.id, nome: m.nome, descricao: m.descricao, ativo: x.ativo !== false, visivel: x.visivel !== false, ordem: Number.isFinite(Number(x.ordem)) ? Number(x.ordem) : 100 + i } })
    .sort((a, b) => a.ordem - b.ordem).map((m, i) => ({ ...m, ordem: i + 1 }))
}
const modoAtivo = async (id: string) => (await cfgModos()).find((m) => m.id === id)?.ativo !== false
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim()

export async function estadoDe(conversationId: string, userId: number): Promise<{ modo: string; estado: EstadoModo } | null> {
  if (!conversationId) return null
  const r = await one('SELECT modo, estado FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2', [conversationId, userId])
  return r ? { modo: String(r.modo), estado: J<EstadoModo>(r.estado, { etapa: 'objetivo' }) } : null
}
async function salvar(conversationId: string, userId: number, modo: string, estado: EstadoModo) {
  const ex = await one('SELECT user_id FROM conversa_modos WHERE conversation_id = $1', [conversationId])
  if (ex && Number(ex.user_id) !== userId) return // conversa de outra pessoa: nunca grava
  if (ex) await q('UPDATE conversa_modos SET modo = $1, estado = $2, atualizado_em = $3 WHERE conversation_id = $4 AND user_id = $5', [modo, JSON.stringify(estado), nowIso(), conversationId, userId])
  else await q('INSERT INTO conversa_modos (conversation_id, user_id, modo, estado, atualizado_em) VALUES ($1,$2,$3,$4,$5)', [conversationId, userId, modo, JSON.stringify(estado), nowIso()])
}
export async function desativar(conversationId: string, userId: number) { await q('DELETE FROM conversa_modos WHERE conversation_id = $1 AND user_id = $2', [conversationId, userId]) }

/** Lista para o seletor: o que existe e se está liberado para este usuário (calculado no servidor). */
export async function listar(u: SessionUser, conversationId = '') {
  const internet = await (await import('../ai/bloqueio-pesquisa.js')).internetPermitida()
  if (!(await modosLigados())) return { habilitado: false, modos: [], ativo: null, internet }
  const est = await estadoDe(conversationId, u.id)
  const modos = [], cfg = await cfgModos()
  for (const cm of cfg) { if (!cm.ativo || !cm.visivel) continue; const m = modoPorId(cm.id); if (!m) continue; const a = await m.acesso(u); if (!a.liberado && m.ocultoSemAcesso) continue /* não elegível: nem aparece */; modos.push({ id: m.id, nome: m.nome, descricao: m.descricao, icone: m.icone, ...(m.exclusivo ? { exclusivo: m.exclusivo } : {}), liberado: a.liberado, codigo: a.codigo, mensagem: a.liberado ? null : a.mensagem, acao: a.liberado ? null : a.acao || null }) }
  return { habilitado: true, modos, ativo: est && modos.some((x) => x.id === est.modo) ? est.modo : null, internet }
}
const bloqueio = (m: Modo, msg: string, acao?: { rotulo: string; link: string }): Resposta => ({ content: `🔒 **${m.nome}**\n\n${msg}${acao ? ` ⟦btn:${acao.link}|${acao.rotulo}⟧` : ''}`, cards: [] })
const SAIR = /^(sair do modo|sair do consultor|voltar (ao|para o) chat (normal|comum)|desativar (o )?modo|modo normal|chat normal)\b/

/**
 * Chamado pelo chat antes dos motores comuns. Devolve a resposta do modo ou null (segue o chat tradicional).
 * body.modo: string com o id para ativar/manter, '' para voltar ao chat normal; ausente = usa o modo salvo da conversa.
 */
export async function processar(u: SessionUser, conversationId: string, texto: string, historico: ChatMsg[], body: any): Promise<(Resposta & { modo: string }) | null> {
  if (!conversationId) return null
  if (!(await modosLigados())) { if (await estadoDe(conversationId, u.id)) await desativar(conversationId, u.id); return null } // desligado no painel: chat normal
  const pedido = typeof body?.modo === 'string' ? body.modo.trim() : undefined
  let atual = await estadoDe(conversationId, u.id)
  if (pedido === '') { if (atual) await desativar(conversationId, u.id); return null }
  if (atual && SAIR.test(nrm(texto))) { await desativar(conversationId, u.id); const m = modoPorId(atual.modo); return { content: `Pronto, saí do modo ${m?.nome || ''} e voltei ao chat normal. ${m?.id === 'gestao_empresa' ? 'Nenhuma prévia pendente foi salva.' : 'Seu planejamento fica guardado para quando você voltar.'}`, cards: [], modo: '' } }
  let ativando = false
  if (pedido && (!atual || atual.modo !== pedido)) { if (!modoPorId(pedido) || !(await modoAtivo(pedido))) return null; ativando = true; atual = { modo: pedido, estado: { etapa: 'objetivo' } } }
  // ativação automática: a própria mensagem pede o que um modo faz (ex.: "quero encontrar…" → Busca). Só sem modo ativo e sem
  // escolha explícita no ⚡; o modo ainda pode recusar (responder → null) e então nada é ligado.
  let auto = false
  if (!atual && pedido === undefined) { const ativos = new Set((await cfgModos()).filter((x) => x.ativo).map((x) => x.id)); const d = MODOS.find((x) => ativos.has(x.id) && x.detectar && x.detectar(texto)); if (d) { atual = { modo: d.id, estado: { etapa: 'inicio' } }; auto = true } }
  if (!atual) return null
  const m = modoPorId(atual.modo); if (!m || !(await modoAtivo(m.id))) { await desativar(conversationId, u.id); return null } // desativado pelo administrador: a conversa volta ao chat normal
  // regras de acesso conferidas a cada mensagem (contratação pode vencer, ser suspensa ou mudar de plano a qualquer momento)
  const acesso = await m.acesso(u)
  if (!acesso.liberado) {
    // modo oculto para quem não é elegível: age como se não existisse (sem cadeado nem aviso) e o chat comum responde
    if (m.ocultoSemAcesso) { if (!ativando && !auto) await desativar(conversationId, u.id); return null }
    if (auto) return null; if (!ativando) await desativar(conversationId, u.id); return { ...bloqueio(m, acesso.mensagem, acesso.acao), modo: '' } }
  const ctx = { u, conversationId, texto, historico, estado: atual.estado, acesso, auto, anexo: typeof body?.__anexo === 'string' ? body.__anexo : undefined }
  const r = ativando && /^⚡/.test(texto.trim()) ? await m.iniciar(ctx) : await m.responder(ctx)
  if (!r) { if (!auto && !m.persistente) await desativar(conversationId, u.id); else if (ativando && m.persistente) await salvar(conversationId, u.id, m.id, atual.estado); return null } // "não é comigo": o chat comum responde esta mesma mensagem (modo persistente continua ligado)
  await salvar(conversationId, u.id, m.id, r.estado)
  return { ...r.resposta, modo: m.id }
}
