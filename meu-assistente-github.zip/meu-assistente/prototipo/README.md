# Protótipo aprovado do Meu Assistente

`index.html` é o protótipo navegável aprovado: interface idêntica ao app original, com todos os módulos novos funcionando **de forma simulada no navegador** (dados salvos só no aparelho, IAs, cotações e pagamentos simulados).

Ele é a referência visual e de comportamento para a implementação real no servidor (veja `docs/ESPECIFICACAO_MODULOS.md`). Abra o arquivo direto no navegador para testar, sem instalar nada.

Não publique este arquivo como sistema de produção: ele não tem login, banco nem segurança de servidor.
