'use strict';
/*
 * IA Gateway do Meu Assistente
 * - Recebe as chamadas de IA do sistema (formato OpenAI /v1/chat/completions)
 * - Texto  -> provedor escolhido no painel (padrão: Ollama local, sem limite)
 * - Imagem -> provedor escolhido no painel (padrão: Gemini grátis)
 * - Painel em /ia-admin para colar a chave e trocar modelos
 * Sem dependências: só Node 20+.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Readable } = require('stream');

const PORT = Number(process.env.PORT || 8790);
const DATA_DIR = process.env.DATA_DIR || '/data';
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const BASE = '/ia-admin';
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions';
const TIMEOUT_MS = Number(process.env.TIMEOUT_MS || 120000);
const MAX_BODY = 30 * 1024 * 1024;
const SESSION_MS = 12 * 3600 * 1000;

const DEFAULTS = {
  geminiKey: '',
  ollamaUrl: process.env.OLLAMA_URL || 'http://172.17.0.1:11434',
  image: { provider: 'gemini', geminiModel: 'gemini-flash-latest', ollamaModel: '' },
  text: { provider: 'ollama', geminiModel: 'gemini-flash-latest', ollamaModel: process.env.OLLAMA_TEXT_MODEL || 'qwen2.5:1.5b' },
  fallbackToOllama: true,
  limitMessage: 'O limite gratuito de leitura de imagens foi atingido por agora. Tente de novo mais tarde ou envie a mensagem por texto.'
};

/* ---------- configuração ---------- */
function loadConfig() {
  try {
    const s = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    return { ...DEFAULTS, ...s, image: { ...DEFAULTS.image, ...(s.image || {}) }, text: { ...DEFAULTS.text, ...(s.text || {}) } };
  } catch { return JSON.parse(JSON.stringify(DEFAULTS)); }
}
let config = loadConfig();
function saveConfig() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = CONFIG_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(config, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, CONFIG_FILE);
}
function mask(k) { return k ? k.slice(0, 4) + '••••••••' + k.slice(-4) : ''; }
function publicConfig() {
  const { geminiKey, ...rest } = config;
  return { ...rest, hasGeminiKey: !!geminiKey, geminiKeyMasked: mask(geminiKey) };
}

/* ---------- utilidades ---------- */
function log(...a) { console.log(new Date().toISOString(), ...a); }
function readBody(req, limit = MAX_BODY) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('grande demais'), { status: 413 })); req.destroy(); }
      else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function sendJson(res, status, obj, headers = {}) {
  const b = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(b), 'Cache-Control': 'no-store', ...headers });
  res.end(b);
}
function clientIp(req) {
  return String(req.headers['x-real-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0] || req.socket.remoteAddress || '').trim();
}

/* ---------- sessão do painel ---------- */
const sessions = new Map();
const fails = new Map();
function getCookie(req, name) {
  for (const p of String(req.headers.cookie || '').split(';')) {
    const i = p.indexOf('=');
    if (i > 0 && p.slice(0, i).trim() === name) return decodeURIComponent(p.slice(i + 1).trim());
  }
  return '';
}
function isAuthed(req) {
  const t = getCookie(req, 'iaadm'); const exp = t && sessions.get(t);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(t); return false; }
  return true;
}
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/* ---------- mensagens e imagens ---------- */
function toDataUrl(img, mime) {
  const s = String(img);
  return s.startsWith('data:') || s.startsWith('http') ? s : `data:${mime || 'image/jpeg'};base64,${s}`;
}
function normalizeMessages(messages) {
  return messages.map(m => {
    if (!m || typeof m !== 'object') return m;
    let content = m.content;
    if (Array.isArray(content)) {
      content = content.map(p => {
        if (!p || typeof p !== 'object') return p;
        if (p.type === 'image' && p.source && p.source.data) return { type: 'image_url', image_url: { url: toDataUrl(p.source.data, p.source.media_type) } };
        if (p.type === 'input_image' && p.image_url) return { type: 'image_url', image_url: { url: typeof p.image_url === 'string' ? p.image_url : p.image_url.url } };
        if (p.type === 'image_url' && typeof p.image_url === 'string') return { type: 'image_url', image_url: { url: p.image_url } };
        return p;
      });
    }
    if (Array.isArray(m.images) && m.images.length) {
      const parts = Array.isArray(content) ? content : (content ? [{ type: 'text', text: String(content) }] : []);
      for (const img of m.images) parts.push({ type: 'image_url', image_url: { url: toDataUrl(img) } });
      content = parts;
    }
    const { images, ...rest } = m;
    return { ...rest, content };
  });
}
function hasImage(messages) {
  return messages.some(m => m && Array.isArray(m.content) && m.content.some(p => p && p.type === 'image_url'));
}

const ALLOWED = {
  gemini: ['stream', 'temperature', 'max_tokens', 'top_p', 'stop', 'tools', 'tool_choice', 'response_format'],
  ollama: ['stream', 'temperature', 'max_tokens', 'top_p', 'stop', 'tools', 'tool_choice', 'response_format', 'seed', 'presence_penalty', 'frequency_penalty']
};
function buildBody(src, t, messages) {
  const b = { model: t.model, messages };
  for (const k of ALLOWED[t.name]) if (src[k] !== undefined) b[k] = src[k];
  return b;
}
function target(provider, kind) {
  const sec = config[kind];
  if (provider === 'gemini') {
    if (!config.geminiKey) return null;
    return { name: 'gemini', url: GEMINI_URL, key: config.geminiKey, model: sec.geminiModel || 'gemini-flash-latest' };
  }
  const model = sec.ollamaModel || (kind === 'text' ? config.text.ollamaModel : '');
  if (!model) return null;
  return { name: 'ollama', url: config.ollamaUrl.replace(/\/+$/, '') + '/v1/chat/completions', key: '', model };
}
async function callUpstream(t, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const r = await fetch(t.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(t.key ? { Authorization: `Bearer ${t.key}` } : {}) },
      body: JSON.stringify(body), signal: ctrl.signal
    });
    return { r, done: () => clearTimeout(timer) };
  } catch (e) { clearTimeout(timer); throw e; }
}
function friendly(res, stream, text) {
  const id = 'chatcmpl-' + crypto.randomUUID(); const created = Math.floor(Date.now() / 1000); const model = 'ia-gateway';
  if (stream) {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
    res.write(`data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: { role: 'assistant', content: text }, finish_reason: null }] })}\n\n`);
    res.write(`data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] })}\n\n`);
    return res.end('data: [DONE]\n\n');
  }
  sendJson(res, 200, { id, object: 'chat.completion', created, model, choices: [{ index: 0, message: { role: 'assistant', content: text }, finish_reason: 'stop' }], usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 } });
}

/* ---------- /v1/chat/completions ---------- */
async function handleChat(req, res) {
  let src;
  try { src = JSON.parse((await readBody(req)).toString('utf8') || '{}'); }
  catch (e) { return sendJson(res, e.status || 400, { error: { message: e.status === 413 ? 'Arquivo grande demais.' : 'JSON inválido.' } }); }

  const messages = normalizeMessages(Array.isArray(src.messages) ? src.messages : []);
  const kind = hasImage(messages) ? 'image' : 'text';
  const stream = !!src.stream;

  const chain = [];
  const primary = target(config[kind].provider, kind);
  if (primary) chain.push(primary);
  if (kind === 'text' && config.fallbackToOllama && (!primary || primary.name !== 'ollama')) {
    const fb = target('ollama', 'text'); if (fb) chain.push(fb);
  }
  if (!chain.length) {
    return friendly(res, stream, kind === 'image'
      ? 'A leitura de imagens ainda não está configurada. O administrador precisa colar a chave do Gemini no painel.'
      : 'A IA de texto não está configurada no painel.');
  }

  let lastStatus = 0;
  for (const t of chain) {
    let up;
    try { up = await callUpstream(t, buildBody(src, t, messages)); }
    catch (e) { log(kind, t.name, 'falha de conexão:', e.name === 'AbortError' ? 'tempo esgotado' : e.message); continue; }
    const { r, done } = up;
    if (!r.ok) {
      lastStatus = r.status;
      const txt = await r.text().catch(() => '');
      done(); log(kind, t.name, 'HTTP', r.status, txt.slice(0, 300)); continue;
    }
    log(kind, t.name, 'ok', t.model);
    res.writeHead(200, { 'Content-Type': r.headers.get('content-type') || (stream ? 'text/event-stream' : 'application/json'), 'Cache-Control': 'no-cache' });
    if (!r.body) { done(); return res.end(); }
    const s = Readable.fromWeb(r.body);
    s.on('end', done);
    s.on('error', () => { done(); res.end(); });
    res.on('close', () => { if (!s.destroyed) s.destroy(); });
    return s.pipe(res);
  }
  friendly(res, stream, lastStatus === 429 ? config.limitMessage
    : kind === 'image' ? 'Não consegui ler a imagem agora. Tente de novo em instantes.'
    : 'A IA não respondeu agora. Tente de novo em instantes.');
}

/* ---------- outras rotas /v1 vão direto para o Ollama ---------- */
async function passthrough(req, res, pathname, search) {
  try {
    const body = ['GET', 'HEAD'].includes(req.method) ? undefined : await readBody(req);
    const r = await fetch(config.ollamaUrl.replace(/\/+$/, '') + pathname + search, {
      method: req.method, headers: { 'Content-Type': req.headers['content-type'] || 'application/json' }, body
    });
    res.writeHead(r.status, { 'Content-Type': r.headers.get('content-type') || 'application/json' });
    if (!r.body) return res.end();
    Readable.fromWeb(r.body).pipe(res);
  } catch (e) { sendJson(res, 502, { error: { message: 'Ollama indisponível: ' + e.message } }); }
}

/* ---------- testes do painel ---------- */
async function testProvider(provider, key, model) {
  const t = provider === 'gemini'
    ? { name: 'gemini', url: GEMINI_URL, key: key || config.geminiKey, model: model || config.image.geminiModel || 'gemini-flash-latest' }
    : { name: 'ollama', url: config.ollamaUrl.replace(/\/+$/, '') + '/v1/chat/completions', key: '', model: model || config.text.ollamaModel };
  if (t.name === 'gemini' && !t.key) return { ok: false, message: 'Nenhuma chave do Gemini salva.' };
  const started = Date.now();
  try {
    const { r, done } = await callUpstream(t, { model: t.model, messages: [{ role: 'user', content: 'Responda só com a palavra OK.' }], max_tokens: 20 });
    const txt = await r.text(); done();
    const secs = ((Date.now() - started) / 1000).toFixed(1);
    if (!r.ok) {
      let msg = txt.slice(0, 250);
      if (r.status === 400 || r.status === 401 || r.status === 403) msg = 'Chave recusada ou modelo inválido. ' + msg;
      if (r.status === 429) msg = 'Limite gratuito atingido no momento. A chave funciona, mas está no limite.';
      if (r.status === 404) msg = 'Modelo não encontrado: ' + t.model;
      return { ok: false, message: `Erro ${r.status}. ${msg}` };
    }
    let answer = '';
    try { answer = JSON.parse(txt).choices[0].message.content; } catch {}
    return { ok: true, message: `Funcionando (${t.model}, ${secs}s). Resposta: ${String(answer).trim().slice(0, 60)}` };
  } catch (e) {
    return { ok: false, message: e.name === 'AbortError' ? 'Tempo esgotado.' : 'Sem conexão: ' + e.message };
  }
}

/* ---------- painel ---------- */
const MODEL_RE = /^[\w.:\/-]{0,100}$/;
async function handleAdmin(req, res, pathname) {
  const sub = pathname.slice(BASE.length) || '/';
  if (req.method === 'GET' && (sub === '/' || sub === '')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY' });
    return res.end(PAGE);
  }
  if (!sub.startsWith('/api/')) return sendJson(res, 404, { error: 'não encontrado' });
  const api = sub.slice(5);

  if (api === 'login' && req.method === 'POST') {
    const ip = clientIp(req); const f = fails.get(ip);
    if (f && f.until > Date.now()) return sendJson(res, 429, { error: 'Muitas tentativas. Aguarde 10 minutos.' });
    if (!ADMIN_PASSWORD) return sendJson(res, 500, { error: 'Senha do painel não definida no servidor (ADMIN_PASSWORD).' });
    let body = {}; try { body = JSON.parse((await readBody(req, 10000)).toString() || '{}'); } catch {}
    if (!safeEqual(body.password || '', ADMIN_PASSWORD)) {
      const n = (f && f.until > Date.now() ? 0 : (f ? f.count : 0)) + 1;
      fails.set(ip, { count: n, until: n >= 5 ? Date.now() + 600000 : 0 });
      log('login recusado', ip);
      return sendJson(res, 401, { error: 'Senha incorreta.' });
    }
    fails.delete(ip);
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, Date.now() + SESSION_MS);
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': `iaadm=${token}; Path=${BASE}; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_MS / 1000}` });
  }
  if (api === 'logout' && req.method === 'POST') {
    sessions.delete(getCookie(req, 'iaadm'));
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': `iaadm=; Path=${BASE}; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
  }

  if (!isAuthed(req)) return sendJson(res, 401, { error: 'Entre com a senha do painel.' });

  if (api === 'config' && req.method === 'GET') return sendJson(res, 200, publicConfig());

  if (api === 'config' && req.method === 'POST') {
    let b; try { b = JSON.parse((await readBody(req, 50000)).toString() || '{}'); } catch { return sendJson(res, 400, { error: 'Dados inválidos.' }); }
    const next = JSON.parse(JSON.stringify(config));
    if (b.clearGeminiKey) next.geminiKey = '';
    if (typeof b.geminiKey === 'string' && b.geminiKey.trim()) {
      const k = b.geminiKey.trim();
      if (k.length < 20 || k.length > 200 || /\s/.test(k)) return sendJson(res, 400, { error: 'A chave parece incompleta. Copie de novo no Google AI Studio.' });
      next.geminiKey = k;
    }
    for (const kind of ['image', 'text']) {
      const s = b[kind]; if (!s) continue;
      if (s.provider && !['gemini', 'ollama'].includes(s.provider)) return sendJson(res, 400, { error: 'Provedor inválido.' });
      for (const f of ['geminiModel', 'ollamaModel']) {
        if (s[f] !== undefined && !MODEL_RE.test(String(s[f]).trim())) return sendJson(res, 400, { error: 'Nome de modelo inválido: ' + s[f] });
      }
      next[kind] = {
        provider: s.provider || next[kind].provider,
        geminiModel: s.geminiModel !== undefined ? String(s.geminiModel).trim() : next[kind].geminiModel,
        ollamaModel: s.ollamaModel !== undefined ? String(s.ollamaModel).trim() : next[kind].ollamaModel
      };
    }
    if (typeof b.fallbackToOllama === 'boolean') next.fallbackToOllama = b.fallbackToOllama;
    if (typeof b.ollamaUrl === 'string' && b.ollamaUrl.trim()) {
      if (!/^https?:\/\/[\w.:-]+\/?$/.test(b.ollamaUrl.trim())) return sendJson(res, 400, { error: 'Endereço do Ollama inválido.' });
      next.ollamaUrl = b.ollamaUrl.trim();
    }
    if (typeof b.limitMessage === 'string' && b.limitMessage.trim()) next.limitMessage = b.limitMessage.trim().slice(0, 300);
    config = next; saveConfig(); log('configuração salva no painel');
    return sendJson(res, 200, publicConfig());
  }

  if (api === 'test' && req.method === 'POST') {
    let b = {}; try { b = JSON.parse((await readBody(req, 10000)).toString() || '{}'); } catch {}
    const model = typeof b.model === 'string' && MODEL_RE.test(b.model) ? b.model : '';
    return sendJson(res, 200, await testProvider(b.provider === 'gemini' ? 'gemini' : 'ollama', typeof b.key === 'string' ? b.key.trim() : '', model));
  }

  if (api === 'ollama-models' && req.method === 'GET') {
    try {
      const r = await fetch(config.ollamaUrl.replace(/\/+$/, '') + '/api/tags');
      const j = await r.json();
      return sendJson(res, 200, { models: (j.models || []).map(m => m.name) });
    } catch (e) { return sendJson(res, 200, { models: [], error: 'Ollama não respondeu: ' + e.message }); }
  }
  sendJson(res, 404, { error: 'não encontrado' });
}

/* ---------- servidor ---------- */
http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    const p = u.pathname;
    if (p === '/health') return sendJson(res, 200, { ok: true });
    if (p === BASE || p.startsWith(BASE + '/')) return await handleAdmin(req, res, p);
    if (req.method === 'POST' && /^\/v1\/chat\/completions\/?$/.test(p)) return await handleChat(req, res);
    if (p.startsWith('/v1/')) return await passthrough(req, res, p, u.search);
    sendJson(res, 404, { error: 'não encontrado' });
  } catch (e) {
    log('erro', e.message);
    if (!res.headersSent) sendJson(res, 500, { error: 'Erro interno.' }); else res.end();
  }
}).listen(PORT, '0.0.0.0', () => log(`IA Gateway na porta ${PORT}`));

/* ---------- página do painel ---------- */
const PAGE = String.raw`<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex">
<title>IA do Meu Assistente</title>
<style>
:root{
  --bg:#000;--panel:rgba(255,255,255,.045);--line:rgba(255,255,255,.09);
  --ink:#f4f6fb;--ink2:#a7adbb;--ink3:#6c7282;--blue:#5b8dff;--blue2:#3d6ff0;
  --ok:#4fd18b;--bad:#ff6b6b;
  color-scheme:dark;
}
*{box-sizing:border-box}
html,body{margin:0;background:var(--bg);color:var(--ink);
  font:16px/1.5 "SF Pro Text","Inter",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
body{padding:max(20px,env(safe-area-inset-top)) 18px max(32px,env(safe-area-inset-bottom))}
main{max-width:560px;margin:0 auto}
header{padding:28px 0 22px}
h1{font-size:30px;line-height:1.1;letter-spacing:-.02em;margin:0 0 8px;font-weight:700}
.sub{color:var(--ink2);margin:0}
section{border:1px solid var(--line);background:var(--panel);border-radius:22px;padding:20px;margin:0 0 14px}
h2{font-size:18px;margin:0 0 4px;font-weight:650}
.hint{color:var(--ink3);font-size:14px;margin:0 0 14px}
label{display:block;font-size:14px;color:var(--ink2);margin:14px 0 6px}
input[type=text],input[type=password],select{width:100%;background:#0a0a0c;color:var(--ink);
  border:1px solid var(--line);border-radius:14px;padding:13px 14px;font:inherit;outline:none}
input:focus,select:focus{border-color:rgba(91,141,255,.6);box-shadow:0 0 0 3px rgba(91,141,255,.18)}
.seg{display:grid;grid-template-columns:1fr 1fr;gap:6px;background:#0a0a0c;border:1px solid var(--line);border-radius:999px;padding:4px}
.seg button{border:0;border-radius:999px;padding:10px;background:transparent;color:var(--ink2);font:inherit;font-size:15px;cursor:pointer}
.seg button[aria-pressed=true]{background:var(--blue);color:#fff}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}
.btn{border:1px solid var(--line);background:rgba(255,255,255,.06);color:var(--ink);border-radius:999px;padding:11px 18px;font:inherit;font-size:15px;cursor:pointer}
.btn.primary{background:var(--blue);border-color:var(--blue);color:#fff;font-weight:600}
.btn:active{transform:scale(.97)}
.btn:focus-visible,.seg button:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
.key{font-family:ui-monospace,Menlo,monospace;font-size:14px;color:var(--ink2);margin:0 0 4px}
.status{font-size:14px;margin:10px 0 0;min-height:1.2em}
.status.ok{color:var(--ok)}.status.bad{color:var(--bad)}
.check{display:flex;gap:10px;align-items:flex-start;margin-top:16px;color:var(--ink2);font-size:15px}
.check input{width:20px;height:20px;accent-color:var(--blue);margin-top:2px}
.save{position:sticky;bottom:12px;display:flex;justify-content:space-between;align-items:center;gap:10px;
  background:rgba(10,10,14,.85);backdrop-filter:blur(14px);border:1px solid var(--line);border-radius:999px;padding:8px 8px 8px 18px}
.save .status{margin:0}
.hidden{display:none}
a{color:var(--blue)}
.login{margin-top:12vh}
</style>
</head>
<body>
<main>
  <div id="login" class="login hidden">
    <header><h1>IA do Meu Assistente</h1><p class="sub">Entre com a senha do painel de IA.</p></header>
    <section>
      <label for="pw">Senha</label>
      <input id="pw" type="password" autocomplete="current-password">
      <div class="row"><button class="btn primary" id="doLogin">Entrar</button></div>
      <p class="status bad" id="loginMsg"></p>
    </section>
  </div>

  <div id="app" class="hidden">
    <header>
      <h1>IA do Meu Assistente</h1>
      <p class="sub">Escolha qual IA responde às mensagens de texto e qual lê fotos e arquivos.</p>
    </header>

    <section>
      <h2>Chave do Gemini</h2>
      <p class="hint">Grátis, sem cartão. Crie em <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com</a> e cole aqui.</p>
      <p class="key" id="keyNow"></p>
      <label for="gkey">Nova chave</label>
      <input id="gkey" type="password" autocomplete="off" placeholder="Cole a chave aqui">
      <div class="row">
        <button class="btn" id="testGemini">Testar chave</button>
        <button class="btn hidden" id="clearKey">Remover chave</button>
      </div>
      <p class="status" id="geminiMsg"></p>
    </section>

    <section>
      <h2>Fotos e arquivos</h2>
      <p class="hint">O Ollama da sua VPS só lê imagens com um modelo de visão instalado, o que pede mais memória.</p>
      <div class="seg" data-kind="image">
        <button data-p="gemini">Gemini</button><button data-p="ollama">Ollama local</button>
      </div>
      <label for="imgGem">Modelo do Gemini</label>
      <input id="imgGem" type="text" placeholder="gemini-flash-latest">
      <label for="imgOll">Modelo de visão do Ollama</label>
      <input id="imgOll" type="text" list="ollList" placeholder="Nenhum instalado">
    </section>

    <section>
      <h2>Mensagens de texto</h2>
      <p class="hint">O Ollama local não tem limite de uso. O Gemini responde melhor, mas conta no limite diário.</p>
      <div class="seg" data-kind="text">
        <button data-p="ollama">Ollama local</button><button data-p="gemini">Gemini</button>
      </div>
      <label for="txtOll">Modelo do Ollama</label>
      <input id="txtOll" type="text" list="ollList" placeholder="qwen2.5:1.5b">
      <label for="txtGem">Modelo do Gemini</label>
      <input id="txtGem" type="text" placeholder="gemini-flash-latest">
      <label class="check"><input type="checkbox" id="fallback"> <span>Se o Gemini falhar ou atingir o limite, responder o texto pelo Ollama local</span></label>
      <div class="row"><button class="btn" id="testOllama">Testar Ollama</button></div>
      <p class="status" id="ollamaMsg"></p>
    </section>

    <section>
      <h2>Aviso de limite</h2>
      <p class="hint">Mensagem que o usuário vê quando o limite grátis de imagens acaba.</p>
      <input id="limitMsg" type="text">
      <label for="ollUrl">Endereço do Ollama</label>
      <input id="ollUrl" type="text">
      <div class="row"><button class="btn" id="logout">Sair do painel</button></div>
    </section>

    <div class="save">
      <p class="status" id="saveMsg"></p>
      <button class="btn primary" id="save">Salvar alterações</button>
    </div>
  </div>
  <datalist id="ollList"></datalist>
</main>
<script>
const B='/ia-admin/api/';
const $=id=>document.getElementById(id);
let state={image:{},text:{}};
async function api(path,opts={}){
  const r=await fetch(B+path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opts});
  let j={};try{j=await r.json()}catch(e){}
  if(r.status===401&&path!=='login'){show('login');throw new Error(j.error||'Entre de novo.')}
  if(!r.ok)throw new Error(j.error||('Erro '+r.status));
  return j;
}
function show(which){$('login').classList.toggle('hidden',which!=='login');$('app').classList.toggle('hidden',which!=='app');if(which==='login')$('pw').focus()}
function msg(id,text,ok){const el=$(id);el.textContent=text||'';el.className='status'+(ok===true?' ok':ok===false?' bad':'')}
function setSeg(kind,p){state[kind].provider=p;document.querySelectorAll('.seg[data-kind="'+kind+'"] button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.p===p)))}
function fill(c){
  state={image:{...c.image},text:{...c.text}};
  $('keyNow').textContent=c.hasGeminiKey?('Chave salva: '+c.geminiKeyMasked):'Nenhuma chave salva ainda.';
  $('clearKey').classList.toggle('hidden',!c.hasGeminiKey);
  $('imgGem').value=c.image.geminiModel||'';$('imgOll').value=c.image.ollamaModel||'';
  $('txtGem').value=c.text.geminiModel||'';$('txtOll').value=c.text.ollamaModel||'';
  $('fallback').checked=!!c.fallbackToOllama;$('limitMsg').value=c.limitMessage||'';$('ollUrl').value=c.ollamaUrl||'';
  setSeg('image',c.image.provider);setSeg('text',c.text.provider);
}
async function load(){
  try{fill(await api('config'));show('app');
    api('ollama-models').then(j=>{$('ollList').innerHTML=(j.models||[]).map(m=>'<option value="'+m.replace(/"/g,'')+'">').join('')}).catch(()=>{});
  }catch(e){show('login')}
}
document.querySelectorAll('.seg').forEach(seg=>seg.addEventListener('click',e=>{const b=e.target.closest('button');if(b)setSeg(seg.dataset.kind,b.dataset.p)}));
$('doLogin').onclick=async()=>{msg('loginMsg','');try{await api('login',{method:'POST',body:JSON.stringify({password:$('pw').value})});$('pw').value='';load()}catch(e){msg('loginMsg',e.message,false)}};
$('pw').addEventListener('keydown',e=>{if(e.key==='Enter')$('doLogin').click()});
$('logout').onclick=async()=>{await api('logout',{method:'POST'}).catch(()=>{});show('login')};
$('save').onclick=async()=>{
  msg('saveMsg','Salvando…');
  if(state.image.provider==='gemini'&&$('keyNow').textContent.startsWith('Nenhuma')&&!$('gkey').value.trim()){msg('saveMsg','Cole a chave do Gemini antes de salvar.',false);return}
  if(state.image.provider==='ollama'&&!$('imgOll').value.trim()){msg('saveMsg','Informe o modelo de visão do Ollama.',false);return}
  try{
    const c=await api('config',{method:'POST',body:JSON.stringify({
      geminiKey:$('gkey').value,
      image:{provider:state.image.provider,geminiModel:$('imgGem').value,ollamaModel:$('imgOll').value},
      text:{provider:state.text.provider,geminiModel:$('txtGem').value,ollamaModel:$('txtOll').value},
      fallbackToOllama:$('fallback').checked,limitMessage:$('limitMsg').value,ollamaUrl:$('ollUrl').value})});
    $('gkey').value='';fill(c);msg('saveMsg','Salvo.',true);
  }catch(e){msg('saveMsg',e.message,false)}
};
$('clearKey').onclick=async()=>{if(!confirm('Remover a chave do Gemini? A leitura de imagens para de funcionar.'))return;
  try{fill(await api('config',{method:'POST',body:JSON.stringify({clearGeminiKey:true})}));msg('geminiMsg','Chave removida.',true)}catch(e){msg('geminiMsg',e.message,false)}};
$('testGemini').onclick=async()=>{msg('geminiMsg','Testando…');try{const r=await api('test',{method:'POST',body:JSON.stringify({provider:'gemini',key:$('gkey').value,model:$('imgGem').value})});msg('geminiMsg',r.message,r.ok)}catch(e){msg('geminiMsg',e.message,false)}};
$('testOllama').onclick=async()=>{msg('ollamaMsg','Testando… (pode levar alguns segundos)');try{const r=await api('test',{method:'POST',body:JSON.stringify({provider:'ollama',model:$('txtOll').value})});msg('ollamaMsg',r.message,r.ok)}catch(e){msg('ollamaMsg',e.message,false)}};
load();
</script>
</body>
</html>`;
