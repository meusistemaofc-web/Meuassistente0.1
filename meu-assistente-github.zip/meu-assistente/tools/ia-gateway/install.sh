#!/bin/sh
# Instala/atualiza o IA Gateway do Meu Assistente na VPS
set -e
cd "$(dirname "$0")"
DIR="$(pwd)"
mkdir -p data
if [ ! -f .env ]; then
  printf "Crie uma senha para o painel de IA: "
  stty -echo 2>/dev/null || true; read -r PASS; stty echo 2>/dev/null || true; echo
  [ -n "$PASS" ] || { echo "Senha vazia. Rode de novo."; exit 1; }
  printf 'ADMIN_PASSWORD=%s\nOLLAMA_URL=http://172.17.0.1:11434\n' "$PASS" > .env
  chmod 600 .env
fi
chmod 700 data
docker rm -f ia-gateway >/dev/null 2>&1 || true
docker run -d --name ia-gateway --restart unless-stopped \
  -p 172.17.0.1:8790:8790 \
  -v "$DIR/server.js:/app/server.js:ro" -v "$DIR/data:/data" \
  --env-file .env --memory 160m \
  node:20-alpine node /app/server.js
sleep 3
docker logs --tail 5 ia-gateway
echo "Pronto. Teste: curl -s http://172.17.0.1:8790/health"
