/* Aplica a personalização da tela inicial do chat (saudação, título e subtítulo) definida no painel.
   Só mexe no texto de boas-vindas (fora das mensagens), com custo mínimo. */
(function(){
if(window.__maChatWelcome)return;window.__maChatWelcome=true;
async function apply(){
  let cfg;try{cfg=await (await fetch('/api/panel/public',{credentials:'same-origin'})).json()}catch(e){return}
  const W=cfg&&cfg.chat_welcome;if(!W)return;
  let busy=false;
  const walk=()=>{busy=false;
    if(location.pathname!=='/'&&!location.pathname.startsWith('/chat'))return;
    if(document.querySelector('.chat-scroll .msg-bubble'))return; // conversa aberta: não toca em nada
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);let n;
    while((n=walker.nextNode())){
      const el=n.parentElement;if(!el||el.closest('#ma-x,.ma-sheet,textarea,input,[contenteditable]'))continue;
      const t=(n.textContent||'').trim();
      const isHi=/^Olá,\s*[^!]{1,40}!$/.test(t),isT=t==='Fale comigo.',isS=t==='Eu organizo o resto.';
      if(!isHi&&!isT&&!isS)continue;
      if(!W.ativo){n.textContent='';continue}
      if(isHi&&W.saudacao){const nome=(t.match(/^Olá,\s*([^!]+)!$/)||[])[1]||'';n.textContent=W.saudacao.replace('{nome}',nome||'você')}
      if(isT&&W.titulo)n.textContent=W.titulo;
      if(isS&&W.subtitulo)n.textContent=W.subtitulo;
    }};
  walk();
  new MutationObserver(()=>{if(!busy){busy=true;requestAnimationFrame(walk)}}).observe(document.body,{childList:true,subtree:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
})();
