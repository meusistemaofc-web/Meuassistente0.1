/* Aplica personalização da tela inicial do chat (Olá / Fale comigo / subtítulo). */
(function(){
if(window.__maChatWelcome)return;window.__maChatWelcome=true;
async function apply(){
  if(!location.pathname.startsWith('/chat') && location.pathname!=='/' && !location.pathname.startsWith('/app'))return;
  let cfg;
  try{cfg=await (await fetch('/api/panel/public',{credentials:'same-origin'})).json()}catch{return}
  const W=cfg.chat_welcome;if(!W)return;
  const walk=()=>{
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);
    const nodes=[];let n;while(n=walker.nextNode())nodes.push(n);
    for(const node of nodes){
      const t=node.textContent||'';
      if(!W.ativo){
        if(/Olá,/.test(t)||t.includes('Fale comigo')||t.includes('Eu organizo o resto'))node.textContent='';
        continue;
      }
      if(/Olá,/.test(t)&&W.saudacao){
        const nome=(t.match(/Olá,\s*([^!]+)!/)||[])[1]||'';
        node.textContent=W.saudacao.replace('{nome}',nome||'você');
      }
      if(t.trim()==='Fale comigo.'&&W.titulo)node.textContent=W.titulo;
      if(t.trim()==='Eu organizo o resto.'&&W.subtitulo)node.textContent=W.subtitulo;
    }
  };
  walk();
  new MutationObserver(walk).observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
})();
