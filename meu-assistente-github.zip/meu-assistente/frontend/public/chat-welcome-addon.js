/* Tela inicial do chat: aplica o que o administrador definiu (mostrar ou esconder a saudação, o título e o
   subtítulo, ou trocar os textos). Age só no bloco de boas-vindas, nunca nas mensagens da conversa. */
(function(){
if(window.__maChatWelcome)return;window.__maChatWelcome=true;
let W=null,busy=false;
async function load(){try{const c=await (await fetch('/api/panel/public',{credentials:'same-origin',cache:'no-store'})).json();W=c&&c.chat_welcome||null}catch(e){W=null}}
function apply(){busy=false;if(!W)return;
  if(location.pathname!=='/'&&!location.pathname.startsWith('/chat'))return;
  document.querySelectorAll('h2').forEach(h2=>{
    const sub=h2.querySelector('span.bg-clip-text');if(!sub)return;
    if(h2.closest('.chat-scroll .msg-bubble,#ma-x,.ma-sheet'))return;
    const hello=h2.previousElementSibling&&h2.previousElementSibling.tagName==='P'?h2.previousElementSibling:null;
    if(!h2.dataset.maOrig){const t=[...h2.childNodes].find(n=>n.nodeType===3);h2.dataset.maOrig='1';h2.dataset.maTitle=t?t.textContent:'';if(hello)hello.dataset.maHello=hello.textContent}
    if(!W.ativo){h2.style.display='none';if(hello)hello.style.display='none';return}
    h2.style.display='';if(hello)hello.style.display='';
    const tn=[...h2.childNodes].find(n=>n.nodeType===3);
    if(tn&&W.titulo&&tn.textContent!==W.titulo)tn.textContent=W.titulo;
    if(W.subtitulo&&sub.textContent!==W.subtitulo)sub.textContent=W.subtitulo;
    if(hello&&W.saudacao){const nome=((hello.dataset.maHello||'').match(/^Olá,\s*([^!]+)!$/)||[])[1]||'';const v=W.saudacao.replace('{nome}',nome||'').replace(/,\s*!$/,'!').replace(/\s+!$/,'!').trim();if(hello.textContent!==v)hello.textContent=v}
  })}
const kick=()=>{if(!busy){busy=true;requestAnimationFrame(apply)}};
(async()=>{await load();kick();new MutationObserver(kick).observe(document.documentElement,{childList:true,subtree:true,characterData:true});document.addEventListener('visibilitychange',async()=>{if(!document.hidden){await load();kick()}})})();
})();
