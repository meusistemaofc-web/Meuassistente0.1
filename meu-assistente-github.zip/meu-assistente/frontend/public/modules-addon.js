/* Meu Assistente · telas novas dentro do app original: Mercado (/x/mercado) e Impostos e DAS (/x/impostos). */
(function(){
if(window.__maModulesAddon)return;window.__maModulesAddon=true;
const CSS=`#ma-x{position:fixed;inset:0;z-index:80;background:var(--nx-canvas);overflow-y:auto;-webkit-overflow-scrolling:touch}
.ma-bar{height:8px;border-radius:999px;background:var(--nx-surface-2);overflow:hidden}.ma-bar span{display:block;height:100%;border-radius:999px;background:var(--nx-accent)}.ma-bar span.bad{background:var(--nx-danger)}
.ma-pill{border-color:var(--nx-line-strong);color:var(--nx-ink-2)}.ma-pill.ok{color:var(--nx-success);border-color:color-mix(in srgb,var(--nx-success) 40%,transparent)}.ma-pill.warn{color:#f0b54a;border-color:rgba(240,181,74,.4)}.ma-pill.bad{color:var(--nx-danger);border-color:color-mix(in srgb,var(--nx-danger) 40%,transparent)}.ma-pill.info{color:var(--nx-accent);border-color:color-mix(in srgb,var(--nx-accent) 40%,transparent)}
.ma-sheet{position:fixed;inset:0;z-index:120;display:flex;align-items:flex-end;justify-content:center}.ma-sheet-bg{position:absolute;inset:0;background:#000000a0}.ma-sheet-in{position:relative;width:min(100%,34rem);max-height:90vh;overflow-y:auto;border-radius:1.8rem 1.8rem 0 0;padding-bottom:env(safe-area-inset-bottom,0px)}@media (min-width:48rem){.ma-sheet{align-items:center}.ma-sheet-in{border-radius:1.8rem}}
.ma-chart{display:block;touch-action:none}.ma-err{color:var(--nx-danger);font-size:13.5px;margin-top:8px}.ma-err:empty{display:none}
#ma-x-toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:200;background:var(--nx-ink);color:var(--nx-canvas);padding:11px 18px;border-radius:999px;font-size:14px;max-width:90vw;text-align:center}#ma-x-toast[hidden]{display:none}`;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const fmtP=(s,v)=>v==null?'—':s==='IBOV'?Number(v).toLocaleString('pt-BR',{maximumFractionDigits:0})+' pts':brl(v);
const pct=v=>v==null?'':(v>=0?'+':'')+Number(v).toFixed(2).replace('.',',')+'%';
const fdate=iso=>String(iso||'').split('-').reverse().join('/');
const BTN='inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 ';
const PRI=BTN+'btn-send hover:brightness-110',GHO=BTN+'border border-line-strong text-ink hover:bg-surface-2';
const INP='h-10 w-full rounded-xl border border-line bg-surface-2/60 px-3 text-[14px] tabular text-ink outline-none focus:border-accent/60';
const H2='mb-3 px-1 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3';
const card=i=>`<div class="glass rounded-[1.6rem] overflow-hidden"><div class="divide-y divide-line">${i}</div></div>`;
const row=(t,d,r)=>`<div class="flex items-center gap-4 px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${t}</p>${d?`<p class="mt-0.5 text-xs text-ink-3">${d}</p>`:''}</div>${r||''}</div>`;
const sw=(id,on,l)=>`<button type="button" role="switch" aria-checked="${!!on}" aria-label="${esc(l)}" data-sw="${id}" class="nx-switch"><span class="nx-switch-knob"></span></button>`;
const pill=(t,k)=>`<span class="ma-pill ${k||''} shrink-0 rounded-full border px-3 py-1 text-xs font-semibold">${t}</span>`;
function base(){if(!document.getElementById('ma-x-style')){const s=document.createElement('style');s.id='ma-x-style';s.textContent=CSS;document.head.appendChild(s)}if(!document.getElementById('ma-x-toast')){const t=document.createElement('div');t.id='ma-x-toast';t.setAttribute('role','status');t.hidden=true;document.body.appendChild(t)}}
let tt;function toast(m){base();const t=$('#ma-x-toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3200)}
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opts});let j={};try{j=await r.json()}catch(e){}if(r.status===401){location.href='/entrar?next='+encodeURIComponent(location.pathname+location.search);throw new Error('login')}if(!r.ok)throw new Error(j.error||('Erro '+r.status));return j}
let MODS=null;async function mods(){if(!MODS){try{MODS=(await api('/api/panel/public')).modules}catch(e){MODS={}}}return MODS}

/* ---------- casca da tela ---------- */
function shell(title,sub,body){return `<div class="mx-auto max-w-3xl px-4 pb-[calc(env(safe-area-inset-bottom)+3rem)] md:px-6"><header class="sticky top-0 z-20 pt-[calc(env(safe-area-inset-top)+0.6rem)]"><div class="glass-bar flex items-center gap-3 rounded-full px-3 py-2 md:px-4"><button type="button" id="ma-x-back" class="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-line-strong text-lg" aria-label="Voltar">←</button><div class="min-w-0 flex-1 leading-tight"><p class="truncate text-[15px] font-semibold">${title}</p><p class="text-[11.5px] text-ink-3">${sub}</p></div><img src="/brand/logo-principal-160.png?v=3" alt="" style="width:34px;height:24px;object-fit:contain"></div></header>${body}</div>`}
function overlay(){base();let o=$('#ma-x');if(!o){o=document.createElement('div');o.id='ma-x';document.body.appendChild(o)}return o}
function bindBack(o){$('#ma-x-back',o).onclick=()=>{if(history.length>1)history.back();else{history.replaceState({},'','/');close()}}}
function close(){const o=$('#ma-x');if(o)o.remove();closeSheet()}
function route(){const p=location.pathname;if(p==='/x/mercado')return viewMercado();if(p==='/x/impostos')return viewImpostos();close()}
addEventListener('popstate',route);
function go(href){history.pushState({},'',href);route()}

/* ---------- folha (sheet) ---------- */
let sheet=null;function openSheet(html){closeSheet();const w=document.createElement('div');w.className='ma-sheet';w.innerHTML=`<div class="ma-sheet-bg"></div><div class="ma-sheet-in glass-strong" role="dialog" aria-modal="true">${html}</div>`;document.body.appendChild(w);$('.ma-sheet-bg',w).onclick=closeSheet;sheet=w;return w}
function closeSheet(){if(sheet){sheet.remove();sheet=null}}

/* ---------- Mercado ---------- */
let aba='cripto';
function spark(pts,up){if(!pts||pts.length<2)return'';const mn=Math.min(...pts),mx=Math.max(...pts),w=72,h=26;const d=pts.map((v,i)=>(i?'L':'M')+(i*w/(pts.length-1)).toFixed(1)+' '+(h-(mx===mn?h/2:(v-mn)/(mx-mn)*h)).toFixed(1)).join(' ');return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true"><path d="${d}" fill="none" stroke="${up?'var(--nx-success)':'var(--nx-danger)'}" stroke-width="1.6"/></svg>`}
function chartSVG(pts,w,h){const vs=pts.map(p=>p.v),mn=Math.min(...vs),mx=Math.max(...vs),up=vs[vs.length-1]>=vs[0],col=up?'var(--nx-success)':'var(--nx-danger)';const X=i=>i*w/(pts.length-1),Y=v=>h-6-(mx===mn?.5:(v-mn)/(mx-mn))*(h-12);const d=pts.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p.v).toFixed(1)).join(' ');
 return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="none" class="ma-chart" role="img" aria-label="Gráfico de preço"><defs><linearGradient id="magr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".28"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><path d="${d} L${w} ${h} L0 ${h} Z" fill="url(#magr)"/><path d="${d}" fill="none" stroke="${col}" stroke-width="2" vector-effect="non-scaling-stroke"/><line class="ma-cur" x1="0" x2="0" y1="0" y2="${h}" stroke="var(--nx-ink-3)" stroke-dasharray="3 3" opacity="0"/></svg>`}
const fdt=(t,r)=>r==='24h'?new Date(t).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):new Date(t).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'});
async function openAtivo(it,range='24h'){
 const w=openSheet(`<div class="p-5"><p class="text-[13px] text-ink-3">${esc(it.nome)}</p><p class="text-[1.48rem] font-bold">${it.symbol}</p><p class="mt-2 text-[2rem] font-bold leading-none tabular">${fmtP(it.symbol,it.price)}</p><p id="mv" class="mt-1 text-[13.5px] font-semibold"></p><p id="mlb" class="mt-3 h-5 text-[12.5px] tabular text-ink-3">Carregando gráfico…</p><div id="mch" style="min-height:180px"></div><div id="mrange" class="mt-1 flex justify-between text-[11px] text-ink-3"></div>
 <div class="glass no-scrollbar mt-4 flex w-fit gap-1 rounded-full p-1">${['24h','7d','30d','90d'].map(k=>`<button type="button" data-rg="${k}" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${range===k?'btn-send':'text-ink-2'}">${k==='24h'?'24h':k.replace('d',' dias')}</button>`).join('')}</div>
 <div id="mst" class="mt-5 grid gap-1 text-sm"></div>
 <p class="${H2} mt-6">Criar alerta de preço</p><div class="flex gap-2"><select id="ma_c" class="${INP}" style="max-width:9rem"><option value="acima">Subir até</option><option value="abaixo">Cair até</option></select><input id="ma_v" inputmode="decimal" class="${INP}" placeholder="Valor"><button type="button" id="ma_a" class="${PRI} h-10 shrink-0">Criar</button></div>
 <p class="mt-4 text-xs text-ink-3">Não é recomendação de investimento.</p></div>`);
 $$('[data-rg]',w).forEach(b=>b.onclick=()=>openAtivo(it,b.dataset.rg));
 $('#ma_a',w).onclick=async()=>{const v=parseFloat($('#ma_v',w).value.replace(/\./g,'').replace(',','.'));if(!(v>0))return toast('Informe um valor.');try{await api('/api/v2/market/alerts',{method:'POST',body:JSON.stringify({symbol:it.symbol,cond:$('#ma_c',w).value,value:v})});toast('Alerta criado. Você recebe uma notificação.');closeSheet();viewMercado()}catch(e){toast(e.message)}};
 try{const s=await api(`/api/v2/market/series?s=${it.symbol}&range=${range}`);if(!w.isConnected)return;const pts=s.points,vs=pts.map(p=>p.v),vr=(vs[vs.length-1]-vs[0])/vs[0]*100;
  $('#mch',w).innerHTML=chartSVG(pts,340,180);$('#mrange',w).innerHTML=`<span>${fdt(pts[0].t,range)}</span><span>${fdt(pts[pts.length-1].t,range)}</span>`;
  const mv=$('#mv',w);mv.textContent=`${pct(vr)} no período`;mv.className='mt-1 text-[13.5px] font-semibold tabular '+(vr>=0?'text-success':'text-danger');
  $('#mst',w).innerHTML=[['Máxima',Math.max(...vs)],['Mínima',Math.min(...vs)],['Abertura',vs[0]]].map(([l,v])=>`<p class="flex justify-between"><span class="text-ink-3">${l} no período</span><span class="tabular text-ink-2">${fmtP(it.symbol,v)}</span></p>`).join('')+`<p class="flex justify-between"><span class="text-ink-3">Fonte</span><span class="text-ink-2">${esc(s.source)}</span></p>`;
  const lb=$('#mlb',w);lb.textContent='Arraste o dedo no gráfico para ver cada ponto';const svg=$('svg',w),line=$('.ma-cur',svg);
  const mvf=ev=>{const r=svg.getBoundingClientRect(),x=Math.max(0,Math.min(r.width,ev.clientX-r.left)),i=Math.round(x/r.width*(pts.length-1));line.setAttribute('x1',i*340/(pts.length-1));line.setAttribute('x2',i*340/(pts.length-1));line.setAttribute('opacity','1');lb.textContent=fmtP(it.symbol,pts[i].v)+' · '+fdt(pts[i].t,range)};
  svg.addEventListener('pointermove',mvf);svg.addEventListener('pointerdown',mvf);
 }catch(e){if(e.message!=='login')$('#mlb',w).textContent=e.message}
}
async function viewMercado(){
 const o=overlay();o.innerHTML=shell('Mercado','Criptomoedas e bolsa',`<p class="pt-8 text-sm text-ink-3">Carregando cotações…</p>`);bindBack(o);
 const m=await mods();if(m.mercado===false){o.innerHTML=shell('Mercado','Módulo desligado',`<p class="py-16 text-center text-sm text-ink-2">O administrador desligou este módulo.</p>`);bindBack(o);return}
 let sum,al;try{[sum,al]=await Promise.all([api('/api/v2/market/summary?cat='+aba),api('/api/v2/market/alerts')])}catch(e){if(e.message!=='login'){o.innerHTML=shell('Mercado','',`<p class="py-16 text-center text-sm text-danger">${esc(e.message)}</p>`);bindBack(o)}return}
 const src=(sum.items.find(i=>i.source)||{}).source;
 o.innerHTML=shell('Mercado','Criptomoedas e bolsa',`<section class="pb-5 pt-8"><h2 class="mb-2 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3">Mercado</h2><p class="font-display text-[2.3rem] leading-[1.03]">Cotações agora</p></section>
 <div class="glass no-scrollbar mb-4 flex w-fit gap-1 rounded-full p-1">${[['cripto','Criptomoedas'],['bolsa','Bolsa (B3)']].map(([k,l])=>`<button type="button" data-aba="${k}" class="flex h-9 items-center rounded-full px-4 text-[13px] font-semibold ${aba===k?'btn-send':'text-ink-2'}">${l}</button>`).join('')}</div>
 ${card(sum.items.map(c=>`<button type="button" data-s="${c.symbol}" class="flex w-full items-center gap-3 px-5 py-3.5 text-left hover:bg-surface-2"><div class="min-w-0 flex-1"><p class="text-[15px] font-semibold">${c.symbol}</p><p class="truncate text-xs text-ink-3">${esc(c.nome)}</p></div><div class="w-32 text-right"><p class="text-[15px] font-semibold tabular">${fmtP(c.symbol,c.price)}</p><p class="text-xs font-semibold tabular ${c.change24h>=0?'text-success':'text-danger'}">${pct(c.change24h)}</p></div></button>`).join(''))}
 <p class="mt-2 px-1 text-xs text-ink-3">${src?'Fonte: '+esc(src)+' · ':''}Toque em um ativo para ver o gráfico e criar alertas.</p>
 <h2 class="${H2} mt-8">Seus alertas</h2>${card(al.alerts.map(a=>row(`${a.symbol} ${a.cond==='acima'?'subir até':'cair até'} ${fmtP(a.symbol,a.value)}`,a.firedAt?'Disparado em '+new Date(a.firedAt).toLocaleString('pt-BR'):'Aguardando',`${pill(a.firedAt?'Disparado':'Ativo',a.firedAt?'ok':'info')}<button type="button" data-del="${a.id}" class="text-[13px] font-semibold text-danger">Excluir</button>`)).join('')||`<div class="px-5 py-5 text-sm text-ink-3">Nenhum alerta. Toque em um ativo ou diga no chat: “me avise se o bitcoin chegar a R$ 600.000”.</div>`)}`);
 bindBack(o);
 $$('[data-aba]',o).forEach(b=>b.onclick=()=>{aba=b.dataset.aba;viewMercado()});
 $$('[data-s]',o).forEach(b=>b.onclick=()=>openAtivo(sum.items.find(i=>i.symbol===b.dataset.s)));
 $$('[data-del]',o).forEach(b=>b.onclick=async()=>{try{await api('/api/v2/market/alerts',{method:'POST',body:JSON.stringify({action:'delete',id:b.dataset.del})});viewMercado()}catch(e){toast(e.message)}});
 const want=new URLSearchParams(location.search).get('s');if(want){const it=sum.items.find(i=>i.symbol===want.toUpperCase());if(it)openAtivo(it);else{try{const q=await api('/api/v2/market/quote?s='+want);openAtivo({symbol:q.symbol,nome:q.nome,price:q.price})}catch(e){}}history.replaceState({},'','/x/mercado')}
}

/* ---------- Impostos e DAS ---------- */
const ATV={comercio:'Comércio ou indústria',servicos:'Serviços',ambos:'Comércio e serviços',caminhoneiro:'Transportador autônomo de cargas'};
const MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
async function viewImpostos(st){
 const o=overlay();
 if(!st){o.innerHTML=shell('Impostos e DAS','MEI',`<p class="pt-8 text-sm text-ink-3">Carregando…</p>`);bindBack(o);const m=await mods();if(m.fiscal===false){o.innerHTML=shell('Impostos e DAS','Módulo desligado',`<p class="py-16 text-center text-sm text-ink-2">O administrador desligou este módulo.</p>`);bindBack(o);return}
  try{st=await api('/api/v2/fiscal')}catch(e){if(e.message!=='login'){o.innerHTML=shell('Impostos e DAS','',`<p class="py-16 text-center text-sm text-danger">${esc(e.message)}</p>`);bindBack(o)}return}}
 const F=st.perfil,d=st.das,y=new Date().getFullYear(),pc=Math.min(100,st.usoLimite*100),meses=Array.from({length:new Date().getMonth()+1},(_,m)=>`${y}-${String(m+1).padStart(2,'0')}`);
 const lim=st.faturamento>st.limite*1.2?'Você passou mais de 20% do limite: procure um contador.':st.faturamento>st.limite?'Você passou do limite do MEI. Até 20% acima, paga a diferença e vira microempresa no ano seguinte.':pc>=80?'Atenção: mais de 80% do limite usado.':'Dentro do limite do MEI.';
 o.innerHTML=shell('Impostos e DAS','MEI · '+ATV[F.atividade],`<section class="pb-6 pt-8"><h2 class="mb-2 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3">Próximo DAS</h2>
 ${st.proximo?`<p class="font-display text-[2.3rem] leading-[1.03] tabular">${brl(d.total)}</p><p class="mt-2 text-[15px] text-ink-2">Competência ${st.proximo.nome} · vence em ${fdate(st.proximo.venc)}${st.proximo.atrasado?' · <span class="text-danger">em atraso</span>':''}</p><div class="mt-4 flex flex-wrap gap-2"><button type="button" data-pg="${st.proximo.k}" data-v="1" class="${PRI}">Marcar como pago</button><a href="https://www8.receita.fazenda.gov.br/SimplesNacional/Aplicacoes/ATSPO/pgmei.app/Identificacao" target="_blank" rel="noopener" class="${GHO}">Gerar guia no PGMEI</a></div>`:`<p class="font-display text-[1.7rem] leading-tight">Tudo pago até agora.</p>`}
 <p class="mt-3 text-xs text-ink-3">INSS ${brl(d.inss)}${d.icms?' + ICMS '+brl(d.icms):''}${d.iss?' + ISS '+brl(d.iss):''} · salário mínimo ${brl(st.params.sm)}</p></section>
 <h2 class="${H2}">Usar meus dados</h2>${card(row('Permitir que o assistente use meus dados','Receitas que você contar no chat (“recebi 500 de um cliente”) entram no faturamento.',sw('consent',F.consent,'Permitir uso dos dados')))}
 <h2 class="${H2} mt-8">Faturamento ${y}</h2><div class="glass rounded-[1.6rem] p-5"><div class="flex items-end justify-between gap-3"><div><p class="text-[1.6rem] font-bold tabular">${brl(st.faturamento)}</p><p class="text-xs text-ink-3">de ${brl(st.limite)} permitidos</p></div><p class="text-[15px] font-semibold tabular ${pc>=80?'text-danger':'text-accent'}">${pc.toFixed(0)}%</p></div><div class="ma-bar mt-3"><span style="width:${pc}%" class="${pc>=80?'bad':''}"></span></div><p class="mt-2 text-xs ${pc>=80?'text-danger':'text-ink-3'}">${lim}</p>
 <div class="mt-4 grid grid-cols-3 gap-2">${meses.map(k=>`<label class="block"><span class="text-[11px] text-ink-3">${MES[+k.slice(5)-1]}</span><input data-rec="${k}" inputmode="decimal" class="${INP} mt-0.5" value="${F.receitas[k]?String(F.receitas[k]).replace('.',','):''}" placeholder="0"></label>`).join('')}</div><div class="mt-3"><button type="button" id="rsave" class="${GHO} h-10">Salvar faturamento</button></div></div>
 <h2 class="${H2} mt-8">Guias do ano</h2>${card(st.competencias.slice().reverse().map(c=>row('DAS '+c.nome+' · '+brl(d.total),'Vence '+fdate(c.venc),`${pill(c.pago?'Pago':c.atrasado?'Em atraso':'A pagar',c.pago?'ok':c.atrasado?'bad':'warn')}<button type="button" data-pg="${c.k}" data-v="${c.pago?0:1}" class="text-[13px] font-semibold text-ink-2">${c.pago?'Desfazer':'Pago'}</button>`)).join(''))}
 <h2 class="${H2} mt-8">Avisos</h2>${card(row('Lembrar do DAS',`Notificação ${F.avisos.dias} dia(s) antes do dia 20.`,sw('das',F.avisos.das,'DAS'))+row('Declaração anual (DASN-SIMEI)',`Entrega até ${fdate(st.dasn.prazo)}, faturamento de ${st.dasn.anoBase}.`,sw('dasn',F.avisos.dasn,'DASN'))+row('Imposto de Renda (pessoa física)','Aviso quando a Receita abrir o prazo.',sw('irpf',F.avisos.irpf,'IR')))}
 <h2 class="${H2} mt-8">Seu MEI</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-3"><label class="block"><span class="text-xs text-ink-3">Atividade</span><select id="f_atv" class="${INP} mt-1">${Object.entries(ATV).map(([k,l])=>`<option value="${k}" ${F.atividade===k?'selected':''}>${l}</option>`).join('')}</select></label><label class="block"><span class="text-xs text-ink-3">Mês de abertura (se abriu este ano)</span><input id="f_ab" type="month" class="${INP} mt-1" value="${esc(F.abertura)}"></label><label class="block"><span class="text-xs text-ink-3">Avisar quantos dias antes</span><input id="f_d" inputmode="numeric" class="${INP} mt-1" value="${F.avisos.dias}"></label><div class="md:col-span-3"><button type="button" id="fsave" class="${PRI} h-10">Salvar</button></div></div>
 <p class="mt-4 px-1 text-xs leading-relaxed text-ink-3">Estimativa para organização, com os valores definidos pelo administrador. Confirme sempre no Portal do Empreendedor ou com um contador.</p>`);
 bindBack(o);
 const save=async body=>{try{viewImpostos(await api('/api/v2/fiscal',{method:'PUT',body:JSON.stringify(body)}));toast('Salvo')}catch(e){toast(e.message)}};
 $$('[data-pg]',o).forEach(b=>b.onclick=()=>save({pago:{k:b.dataset.pg,value:b.dataset.v==='1'}}));
 $$('[data-sw]',o).forEach(b=>b.onclick=()=>{const k=b.dataset.sw;if(k==='consent')save({consent:!F.consent});else save({avisos:{[k]:!F.avisos[k]}})});
 $('#rsave',o).onclick=()=>{const r={};$$('[data-rec]',o).forEach(i=>{const v=parseFloat(i.value.replace(/\./g,'').replace(',','.'));r[i.dataset.rec]=isNaN(v)?0:v});save({receitas:r})};
 $('#fsave',o).onclick=()=>save({atividade:$('#f_atv',o).value,abertura:$('#f_ab',o).value,avisos:{dias:parseInt($('#f_d',o).value,10)}});
}

/* ---------- itens no menu lateral do app ---------- */
const ICON={mercado:'<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="m19 9-5 5-4-4-3 3"/>',impostos:'<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>'};
async function injectMenu(){
 const nav=$('nav.nx-menu');if(!nav||nav.querySelector('[data-ma-x]'))return;
 const sample=[...nav.querySelectorAll('a[href]')].find(a=>a.querySelector('.truncate')&&a.querySelector('svg'));if(!sample)return;
 const m=await mods();if(nav.querySelector('[data-ma-x]'))return;
 [['mercado','/x/mercado','Mercado'],['impostos','/x/impostos','Impostos e DAS']].forEach(([k,href,label])=>{if(m[k==='impostos'?'fiscal':'mercado']===false)return;
  const c=sample.cloneNode(true);c.dataset.maX=k;c.setAttribute('href',href);c.removeAttribute('aria-current');$('.truncate',c).textContent=label;
  const old=$('svg',c);old.outerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="${old.getAttribute('class')||''}" aria-hidden="true">${ICON[k]}</svg>`;
  c.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const x=document.querySelector('[aria-label="Fechar menu"]');if(x)x.click();go(href)},true);
  sample.parentElement.insertBefore(c,sample);
 });
}
new MutationObserver(()=>{injectMenu();if(location.pathname.startsWith('/x/')&&!$('#ma-x'))route()}).observe(document.documentElement,{childList:true,subtree:true});
document.addEventListener('click',e=>{const a=e.target.closest&&e.target.closest('a[href^="/x/"]');if(a&&!a.dataset.maX&&!e.defaultPrevented){e.preventDefault();go(a.getAttribute('href'))}},true);
if(location.pathname.startsWith('/x/'))route();
})();
