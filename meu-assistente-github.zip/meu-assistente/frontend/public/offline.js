// Contingency page (served by sw.js when a page isn't available offline): lists the
// app screens this device can open without connection, and retries when online.
;(function () {
  var NAMES = {
    '/': 'Chat',
    '/meu-dia': 'Meu Dia',
    '/agenda': 'Agenda',
    '/financeiro': 'Financeiro',
    '/mercado': 'Mercado',
    '/alimentacao': 'Agenda Alimentar',
    '/fiscal': 'Calendário Fiscal',
    '/notificacoes': 'Notificações',
    '/perfil': 'Configurações',
    '/organizar': 'Organização',
    '/treinos': 'Treinos',
    '/espaco': 'Espaço compartilhado',
    '/emails': 'E-mails automáticos',
    '/mapas': 'Mapas e Navegação',
  }
  document.getElementById('retry').addEventListener('click', function () {
    location.reload()
  })
  window.addEventListener('online', function () {
    location.reload()
  })
  if (!('caches' in window)) return
  caches.keys().then(function (keys) {
    var name = keys.filter(function (k) { return k.indexOf('nexa-pages-') === 0 }).sort().pop()
    if (!name) return
    return caches.open(name).then(function (cache) {
      return cache.keys().then(function (reqs) {
        var paths = reqs.map(function (r) { return new URL(r.url).pathname }).filter(function (p) { return NAMES[p] && p !== location.pathname })
        if (!paths.length) return
        var box = document.getElementById('pages')
        paths.sort().forEach(function (p) {
          var a = document.createElement('a')
          a.href = p
          a.textContent = NAMES[p]
          box.appendChild(a)
        })
        document.getElementById('list').hidden = false
      })
    })
  })
})()
