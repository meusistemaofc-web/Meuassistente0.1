/* Conversas robustas: cada envio ao chat ganha um id. O servidor processa o pedido mesmo se o app sair,
   minimizar ou perder a conexão; ao voltar, a resposta é recuperada pelo id (sem gerar duas vezes).
   Enquanto a resposta é gerada, o texto aparece em tempo real (streaming) numa bolha provisória. */
(function(){
if(window.__maChatJob)return;window.__maChatJob=true;
const nativeFetch=window.fetch.bind(window);
const KEY='ma-chat-jobs';
const uid=()=>'j'+Date.now().toString(36)+Math.random().toString(36).slice(2,12);
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}};
const save=l=>{try{localStorage.setItem(KEY,JSON.stringify(l.slice(-20)))}catch(e){}};
const remember=(id,txt)=>{const l=load().filter(x=>Date.now()-x.at<6*3600e3);l.push({id,at:Date.now(),txt:String(txt||'').slice(0,80)});save(l)};
const forget=id=>save(load().filter(x=>x.id!==id));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const visible=()=>new Promise(r=>{if(!document.hidden)return r();const f=()=>{if(!document.hidden){document.removeEventListener('visibilitychange',f);r()}};document.addEventListener('visibilitychange',f)});
const online=()=>new Promise(r=>{if(navigator.onLine)return r();addEventListener('online',()=>r(),{once:true})});
async function jobStatus(id){try{const r=await nativeFetch('/api/v2/chat/jobs/'+id,{credentials:'same-origin',cache:'no-store'});return r.ok?await r.json():{status:'unknown'}}catch(e){return{status:'offline'}}}
function asResponse(st){if(st.status==='done')return new Response(JSON.stringify(st.result),{status:200,headers:{'Content-Type':'application/json'}});return new Response(JSON.stringify({error:st.error||'Não consegui responder agora.',code:st.code||'ai_error'}),{status:st.httpStatus||502,headers:{'Content-Type':'application/json'}})}
/* bolha provisória com o texto chegando */
function liveBubble(id){
  let es=null,box=null,txt='',closed=false;
  const ensure=()=>{if(box&&box.isConnected)return box;const sc=document.querySelector('.chat-scroll');if(!sc)return null;const host=sc.querySelector('.msg-bubble')?sc.querySelector('.msg-bubble').closest('[data-message-id],[class*="msg-row"],li,div')?.parentElement||sc:sc;
    box=document.createElement('div');box.className='ma-live';box.setAttribute('aria-live','polite');box.style.cssText='display:flex;justify-content:flex-start;padding:4px 16px 8px';box.innerHTML='<div class="glass" style="max-width:85%;border-radius:1.4rem;padding:12px 16px;font-size:15px;line-height:1.5;white-space:pre-wrap;color:var(--nx-ink)"></div>';host.appendChild(box);return box};
  const paint=()=>{const b=ensure();if(!b)return;b.firstChild.textContent=txt;const sc=document.querySelector('.chat-scroll');if(sc)sc.scrollTop=sc.scrollHeight};
  const start=setTimeout(()=>{if(closed||typeof EventSource==='undefined')return;try{es=new EventSource('/api/v2/chat/jobs/'+id+'/stream',{withCredentials:true});
    es.addEventListener('delta',e=>{try{txt+=JSON.parse(e.data)}catch(x){}if(txt.trim())paint()});
    es.addEventListener('reset',()=>{txt='';if(box)box.remove()});
    const end=()=>{try{es.close()}catch(x){}};es.addEventListener('done',end);es.addEventListener('error',()=>{if(es.readyState===2)end()})}catch(x){}},350);
  return{close(){closed=true;clearTimeout(start);try{es&&es.close()}catch(x){}if(box)box.remove()}};
}
async function recover(id,origErr){
  for(let k=0;k<200;k++){
    await visible();await online();
    const st=await jobStatus(id);
    if(st.status==='done'||st.status==='error'){forget(id);return asResponse(st)}
    if(st.status==='unknown'){forget(id);throw origErr} // o servidor não chegou a receber: segue o fluxo offline normal do app
    await sleep(k<10?800:2000);
  }
  throw origErr;
}
window.fetch=function(input,init){
  init=init||{};
  let url='',method='GET';
  try{url=new URL(typeof input==='string'?input:(input&&input.url)||'',location.href).pathname;method=String(init.method||(input&&input.method)||'GET').toUpperCase()}catch(e){}
  if(method!=='POST'||url!=='/api/chat')return nativeFetch(input,init);
  const id=uid();const h=new Headers(init.headers||(input instanceof Request?input.headers:undefined));h.set('X-Chat-Job',id);
  let body=init.body;try{const j=typeof body==='string'?JSON.parse(body):null;remember(id,j&&j.text)}catch(e){remember(id,'')}
  const ui=liveBubble(id);
  return new Promise((resolve,reject)=>{
    let done=false;const fin=(ok,v)=>{if(done)return;done=true;ui.close();document.removeEventListener('visibilitychange',onVis);ok?resolve(v):reject(v)};
    // voltou para o app com o pedido ainda pendurado: pergunta ao servidor
    const onVis=async()=>{if(document.hidden||done)return;await sleep(600);if(done)return;const st=await jobStatus(id);if(!done&&(st.status==='done'||st.status==='error')){forget(id);fin(true,asResponse(st))}};
    document.addEventListener('visibilitychange',onVis);
    nativeFetch(input,{...init,headers:h}).then(r=>{if(r.ok||r.status<500)forget(id);fin(true,r)},async err=>{
      if(done)return;
      if(!navigator.onLine){forget(id);return fin(false,err)} // sem internet: o app guarda a mensagem na fila offline, como antes
      try{fin(true,await recover(id,err))}catch(e){fin(false,e)}
    });
  });
};
/* app reaberto depois de fechado: avisa se uma resposta ficou pronta enquanto estava fora */
async function checkOld(){
  const l=load();if(!l.length)return;
  for(const j of l){if(Date.now()-j.at<4000)continue;const st=await jobStatus(j.id);if(st.status==='pending')continue;forget(j.id);
    if(st.status==='done'&&st.result&&st.result.assistantMessage){const t=String(st.result.assistantMessage.content||'').replace(/⟦[^⟧]*⟧/g,'').trim().slice(0,40);if(t&&!document.body.innerText.includes(t.slice(0,25))){notice()}}}
}
function notice(){if(document.getElementById('ma-ready'))return;const b=document.createElement('button');b.id='ma-ready';b.type='button';b.textContent='Sua resposta ficou pronta · Ver';b.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:calc(96px + env(safe-area-inset-bottom,0px));z-index:200;border:0;border-radius:999px;padding:10px 18px;font:600 14px system-ui;color:#fff;background:#2f6bff;box-shadow:0 10px 30px -8px #000';b.onclick=()=>location.reload();document.body.appendChild(b);setTimeout(()=>b.remove(),15000)}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)setTimeout(checkOld,1200)});
addEventListener('online',()=>setTimeout(checkOld,1500));
if(document.readyState==='complete')setTimeout(checkOld,2500);else addEventListener('load',()=>setTimeout(checkOld,2500));
})();
