// Nexa service worker: offline app (Modo offline), web push and notification clicks.
// Push payload shape: PushPayload in src/server/push.ts.
// v7: official identity = the M logo (brand/, icons/ regenerated; drops the cached Olhos Luminosos icons).
// v8: Modo offline — pages cached per path (network first), hashed assets kept in their own cache,
//     fonts cached, contingency page (/offline.html), updates wait for the person's "Atualizar".
const VERSION = 'v9'
const CACHE = 'nexa-shell-' + VERSION
const PAGES = 'nexa-pages-' + VERSION
const ASSETS = 'nexa-assets-v2'
const FONTS = 'nexa-fonts-v1'
// Mapas e Navegação: the map's code (MapLibre, its worker, the screen) pinned by the page — never trimmed.
const PINNED = 'nexa-pinned-v1'
const KEEP = [CACHE, PAGES, ASSETS, FONTS, PINNED]
const ICON = '/icons/icon-192.png?v=3'
const BADGE = '/icons/badge-96.png?v=3'
const OFFLINE_PAGE = '/offline.html'
const SHELL = [
  '/manifest.webmanifest',
  OFFLINE_PAGE,
  '/offline.js',
  '/brand/logo-principal-160.png?v=3',
  '/brand/logo-principal.png?v=3',
  '/brand/logo-chat-160.png?v=3',
  '/favicon.ico?v=3',
  '/icons/favicon-32.png?v=3',
  ICON,
  BADGE,
]
const MAX_ASSETS = 400
const MAX_PAGES = 60
// Pages never kept: public invite links (their content belongs to the link) and the OAuth callback.
const NO_PAGE_CACHE = [/^\/convite\//, /^\/api\//, /^\/\.netlify\//, /^\/mcp\b/]

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE)
      await cache.addAll(SHELL).catch(() => {})
      // The chat (home) page, so the app opens without connection right after installing.
      await cachePage('/').catch(() => {})
      // First install: take over at once. An update waits until the person taps "Atualizar"
      // (or every tab of the app was closed), so a running screen never switches version mid-use.
      if (!self.registration.active) await self.skipWaiting()
    })(),
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('nexa-') && !KEEP.includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('message', (event) => {
  const msg = event.data || {}
  if (msg.type === 'skip-waiting') self.skipWaiting()
  // Mapas e Navegação: keep these build assets out of the trimmed cache (replaces the previous set).
  if (msg.type === 'pin' && Array.isArray(msg.urls)) {
    event.waitUntil(
      (async () => {
        // The page sends the map's own files first; earlier pins are kept (an older app version's
        // files go only when the cache passes 250 entries), so a later, smaller pin never drops them.
        const urls = msg.urls.slice(0, 250).filter((u) => typeof u === 'string' && new URL(u).origin === self.location.origin && new URL(u).pathname.startsWith('/assets/'))
        const cache = await caches.open(PINNED)
        const old = await cache.keys()
        const keep = new Set(urls.map((u) => new URL(u).href))
        const extra = old.filter((r) => !keep.has(r.url))
        const over = extra.length + keep.size - 250
        if (over > 0) await Promise.all(extra.slice(0, over).map((r) => cache.delete(r)))
        await Promise.all(urls.map(async (u) => (await cache.match(u)) || cache.add(u).catch(() => {})))
      })(),
    )
  }
  // The app (online) asks to keep its main screens for offline use.
  if (msg.type === 'warm' && Array.isArray(msg.paths)) {
    event.waitUntil(Promise.all(msg.paths.slice(0, 40).filter((p) => typeof p === 'string' && p.startsWith('/')).map((p) => cachePage(p).catch(() => {}))))
  }
})

const pageKey = (url) => new URL(url.pathname, self.location.origin).href

/** Fetches a page from the network and keeps it (and the scripts/styles it references). */
async function cachePage(path) {
  const url = new URL(path, self.location.origin)
  if (NO_PAGE_CACHE.some((re) => re.test(url.pathname))) return
  const res = await fetch(url.href, { credentials: 'same-origin', cache: 'no-store' })
  if (!res.ok || !(res.headers.get('content-type') || '').includes('text/html')) return
  const html = await res.clone().text()
  const pages = await caches.open(PAGES)
  await pages.put(pageKey(url), res)
  await trim(PAGES, MAX_PAGES)
  // The entry scripts/styles of THIS html: an offline open never mixes versions.
  const assets = [...new Set((html.match(/\/assets\/[A-Za-z0-9._\-\/]+\.(?:js|css|woff2?)/g) || []))]
  const store = await caches.open(ASSETS)
  await Promise.all(
    assets.map(async (a) => {
      if (await store.match(a)) return
      const r = await fetch(a).catch(() => null)
      if (r && r.ok) await store.put(a, r)
    }),
  )
}

async function trim(name, max) {
  const cache = await caches.open(name)
  const keys = await cache.keys()
  if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map((k) => cache.delete(k)))
}

self.addEventListener('fetch', (event) => {
  const req = event.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)

  // Google Fonts (Manrope): cache first, so text keeps its typeface offline.
  if (url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONTS).then(async (cache) => {
        const hit = await cache.match(req)
        if (hit) return hit
        const res = await fetch(req)
        if (res.ok || res.type === 'opaque') cache.put(req, res.clone())
        return res
      }),
    )
    return
  }

  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return
  // Connectivity probe (lib/offline/queue.ts): always the network.
  if (url.searchParams.has('probe')) return

  // Navigations: network first (always the current version online); offline = this page's
  // last copy, else the contingency page (never a blank screen).
  if (req.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const res = await fetch(req)
          if (res.ok && (res.headers.get('content-type') || '').includes('text/html') && !NO_PAGE_CACHE.some((re) => re.test(url.pathname))) {
            const copy = res.clone()
            caches.open(PAGES).then((c) => c.put(pageKey(url), copy).then(() => trim(PAGES, MAX_PAGES)))
          }
          return res
        } catch {
          const pages = await caches.open(PAGES)
          const hit = await pages.match(pageKey(url))
          if (hit) return hit
          return (await caches.match(OFFLINE_PAGE)) || new Response('<h1>Sem conexão</h1>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
        }
      })(),
    )
    return
  }

  // Hashed build assets never change: cache first (kept across app versions until trimmed).
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.open(ASSETS).then(async (cache) => {
        const hit = (await cache.match(req)) || (await caches.open(PINNED).then((p) => p.match(req)))
        if (hit) return hit
        const res = await fetch(req.url, { credentials: 'same-origin', cache: 'reload' })
        if (res.ok) {
          cache.put(req, res.clone()).then(() => trim(ASSETS, MAX_ASSETS))
        }
        return res
      }),
    )
    return
  }

  // Icons, brand files, images, manifest: stale-while-revalidate.
  if (url.pathname.startsWith('/icons/') || url.pathname.startsWith('/brand/') || url.pathname.startsWith('/images/') || url.pathname === '/manifest.webmanifest' || url.pathname === '/favicon.ico' || url.pathname === OFFLINE_PAGE || url.pathname === '/offline.js') {
    event.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const cached = await cache.match(req)
        const network = fetch(req)
          .then((res) => {
            if (res.ok) cache.put(req, res.clone())
            return res
          })
          .catch(() => cached || Response.error())
        return cached || network
      }),
    )
  }
})

self.addEventListener('push', (event) => {
  let data = {}
  try {
    data = event.data ? event.data.json() : {}
  } catch {
    data = { title: 'Meu Assistente', body: event.data ? event.data.text() : '' }
  }
  const title = data.title || 'Meu Assistente'
  const options = {
    body: data.body || '',
    tag: data.tag,
    renotify: !!data.tag,
    silent: !!data.silent,
    requireInteraction: !!data.requireInteraction,
    icon: ICON,
    badge: BADGE,
    timestamp: Date.now(),
    data: { url: data.url || '/', reminderId: data.reminderId || null, meal: data.meal || null, medication: data.medication || null },
    actions: Array.isArray(data.actions) ? data.actions : [],
  }
  if (data.vibrate) options.vibrate = [120, 60, 120]
  event.waitUntil(
    self.registration.showNotification(title, options).then(() => broadcast({ type: 'refresh' })),
  )
})

// The push service rotated/expired this device's subscription: subscribe again
// with the same VAPID key and store it, so reminders keep arriving.
self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil(
    (async () => {
      const keyRes = await fetch('/api/push', { credentials: 'same-origin' })
      if (!keyRes.ok) return
      const { publicKey } = await keyRes.json()
      const pad = '='.repeat((4 - (publicKey.length % 4)) % 4)
      const raw = atob((publicKey + pad).replace(/-/g, '+').replace(/_/g, '/'))
      const sub =
        (await self.registration.pushManager.getSubscription()) ||
        (await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(raw, (c) => c.charCodeAt(0)) }))
      await fetch('/api/push', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscription: sub.toJSON() }),
      })
    })().catch(() => {}),
  )
})

function broadcast(msg) {
  return self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => list.forEach((c) => c.postMessage(msg)))
}

// Opens (or focuses) the app on `url`. An open window routes in-app via a
// message, so the SPA keeps its state instead of reloading.
function openApp(raw) {
  // Only paths of this app: a link to another site is never opened from a notification.
  let url = '/'
  try {
    const u = new URL(raw || '/', self.location.origin)
    if (u.origin === self.location.origin) url = u.pathname + u.search + u.hash
  } catch (e) {}
  return self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    const client = list.find((c) => new URL(c.url).origin === self.location.origin)
    if (client) {
      client.postMessage({ type: 'navigate', url })
      return client.focus()
    }
    return self.clients.openWindow(url)
  })
}

// Action buttons work without opening the app: the device cookie rides along
// on same-origin requests, so /api/items authenticates as usual.
function reminderAction(id, action) {
  const body =
    action === 'done'
      ? { action: 'reminder_done', type: 'reminder', id }
      : { action: 'reminder_snooze', type: 'reminder', id, data: { minutes: 10 } }
  return fetch('/api/items', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  }).then((res) => {
    if (!res.ok) throw new Error(String(res.status))
    return broadcast({ type: 'refresh' })
  })
}

// Agenda Alimentar: "Feito" / "Adiar 15 min" on a meal reminder.
function mealAction(meal, action) {
  const body = action === 'meal_done' ? { action: 'meal.done', id: meal.id, day: meal.day } : { action: 'meal.snooze', id: meal.id, minutes: 15 }
  return fetch('/api/meals', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  }).then((res) => {
    if (!res.ok) throw new Error(String(res.status))
    return broadcast({ type: 'refresh' })
  })
}

// Medicamentos: "Tomei" / "Adiar 15 min" on a dose reminder (only the user's tap records a dose).
function medAction(med, action) {
  const body = action === 'med_taken' ? { action: 'dose.taken', id: med.id, day: med.day, time: med.time } : { action: 'dose.snooze', id: med.id, day: med.day, time: med.time, minutes: 15 }
  return fetch('/api/medications', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  }).then((res) => {
    if (!res.ok) throw new Error(String(res.status))
    return broadcast({ type: 'refresh' })
  })
}

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const data = event.notification.data || {}
  const url = data.url || '/'
  if (data.reminderId && (event.action === 'done' || event.action === 'snooze10')) {
    event.waitUntil(reminderAction(data.reminderId, event.action).catch(() => openApp(url)))
    return
  }
  if (data.meal && data.meal.id && (event.action === 'meal_done' || event.action === 'meal_snooze')) {
    event.waitUntil(mealAction(data.meal, event.action).catch(() => openApp(url)))
    return
  }
  if (data.medication && data.medication.id && (event.action === 'med_taken' || event.action === 'med_snooze')) {
    event.waitUntil(medAction(data.medication, event.action).catch(() => openApp(url)))
    return
  }
  event.waitUntil(openApp(url))
})
