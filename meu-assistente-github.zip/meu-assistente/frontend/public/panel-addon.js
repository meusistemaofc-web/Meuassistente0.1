/* Meu Assistente · novas abas dentro do painel administrativo original (/admin). */
(function(){
if(window.__maPanelAddon)return;window.__maPanelAddon=true;
const STYLE=`
.ma-err{color:var(--nx-danger);font-size:13.5px;margin-top:8px}.ma-err:empty{display:none}.ma-ok{color:var(--nx-success);font-size:13.5px;margin-top:8px}.ma-ok:empty{display:none}
.ma-pill{border-color:var(--nx-line-strong);color:var(--nx-ink-2)}.ma-pill.ok{color:var(--nx-success);border-color:color-mix(in srgb,var(--nx-success) 40%,transparent)}
.ma-pill.warn{color:#f0b54a;border-color:rgba(240,181,74,.4)}.ma-pill.bad{color:var(--nx-danger);border-color:color-mix(in srgb,var(--nx-danger) 40%,transparent)}
main section.grid{grid-template-columns:minmax(0,1fr)}
#toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:200;background:var(--nx-ink);color:var(--nx-canvas);padding:11px 18px;border-radius:999px;font-size:14px;max-width:90vw;text-align:center}#toast[hidden]{display:none}
.ma-kgrid{display:grid;gap:12px}@media (min-width:48rem){.ma-kgrid{grid-template-columns:1fr 7rem 5rem 11rem auto;align-items:end}}
`;
function ensureBase(){if(!document.getElementById('ma-addon-style')){const st=document.createElement('style');st.id='ma-addon-style';st.textContent=STYLE;document.head.appendChild(st)}
 if(!document.getElementById('toast')){const t=document.createElement('div');t.id='toast';t.setAttribute('role','status');t.hidden=true;document.body.appendChild(t)}}
ensureBase();

const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const BTN='inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 ';
const PRI=BTN+'btn-send hover:brightness-110',GHO=BTN+'border border-line-strong text-ink hover:bg-surface-2',DAN=BTN+'border border-line-strong text-danger hover:bg-surface-2';
const INP='h-10 w-full rounded-xl border border-line bg-surface-2/60 px-3 text-[14px] tabular text-ink outline-none focus:border-accent/60';
const H2='mb-3 px-1 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3';
const card=i=>`<div class="glass rounded-[1.6rem] overflow-hidden"><div class="divide-y divide-line">${i}</div></div>`;
const row=(t,d,r)=>`<div class="flex items-center gap-4 px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${t}</p>${d?`<p class="mt-0.5 text-xs text-ink-3">${d}</p>`:''}</div>${r||''}</div>`;
const sw=(id,on,l)=>`<button type="button" role="switch" aria-checked="${!!on}" aria-label="${esc(l)}" data-sw="${id}" class="nx-switch"><span class="nx-switch-knob"></span></button>`;
const pill=(t,k)=>`<span class="ma-pill ${k||''} shrink-0 rounded-full border px-3 py-1 text-xs font-semibold">${t}</span>`;
let tt;function toast(m){ensureBase();const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3500)}
let C=null,tab='',open='',HOST=null;
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opts});let j={};try{j=await r.json()}catch(e){}
 if(!r.ok)throw new Error(j.error||('Erro '+r.status));return j}
async function put(key,body){try{C=await api('/api/panel/'+key,{method:'PUT',body:JSON.stringify(body)});render();toast('Salvo');return true}catch(e){toast(e.message);return false}}
const TABS=[['anuncios','Anúncios'],['financas','Categorias financeiras'],['motor','Motor do chat'],['agente','Agente das empresas'],['menu','Menu do app'],['usos','Planos de uso'],['chatads','Anúncio no chat'],['biblioteca','Biblioteca SOS'],['links','Páginas e links'],['botoes','Botões do chat'],['modulos','Módulos'],['ia','IA'],['fontes','Fontes de mercado'],['mp','Mercado Pago'],['planos','Planos de anúncio'],['cerebro','Cérebro e busca'],['chatwelcome','Tela do chat']];
function render(){if(!HOST||!C)return;const p=HOST;({anuncios:pAds,financas:pFin,motor:pMotor,agente:pAgente,menu:pMenu,usos:pUsos,chatads:pChatAds,biblioteca:pKb,links:pLinks,botoes:pBotoes,modulos:pMod,ia:pIA,fontes:pFontes,mp:pMP,planos:pPlanos,cerebro:pBrain,chatwelcome:pChatWelcome})[tab](p);
 if(!C.canWrite)$$('button,input,select',p).forEach(x=>{x.disabled=true});}

const STA={pagamento:['Aguardando pagamento',''],analise:['Pago · aprovar','warn'],ajustes:['Ajustes pedidos','warn'],recusado:['Recusado','bad'],aprovado:['Aguardando pagamento',''],ativo:['No ar','ok'],encerrado:['Encerrado','']};
async function pAds(p){
 p.innerHTML='<p class="text-sm text-ink-3">Carregando anúncios…</p>';
 let L;try{L=await api('/api/v2/admin/ads')}catch(e){p.innerHTML=`<div class="glass rounded-[1.6rem] p-5 text-sm text-ink-2">${esc(e.message)}</div>`;return}
 const box=it=>{const st=STA[it.status]||[it.status,''];return `<div class="px-5 py-4"><div class="flex items-start gap-3">${it.logo?`<img src="${it.logo}" alt="" style="width:46px;height:46px;border-radius:.8rem;object-fit:cover">`:''}<div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${esc(it.empresa)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(it.categoria||'')} · ${it.plan?esc(it.plan.nome)+' · '+brl(it.plan.preco):''} · ${esc(it.owner.name)} (${esc(it.owner.email)})</p><p class="mt-0.5 text-xs text-ink-3">${esc(it.protocolo)}${it.expiresAt&&it.status==='ativo'?' · até '+new Date(it.expiresAt).toLocaleDateString('pt-BR'):''}</p></div>${pill(st[0],st[1])}</div>
  <p class="mt-2 text-[13.5px]"><b>${esc(it.titulo||'')}</b> ${esc(it.texto||'')}</p>${it.zap||it.insta?`<p class="mt-1 text-xs text-ink-3">${it.zap?'WhatsApp '+esc(it.zap):''} ${it.insta?'· @'+esc(it.insta):''}</p>`:''}${it.endereco?`<p class="mt-1 text-xs text-ink-3">${esc(it.endereco)} ${it.horario?'· '+esc(it.horario):''}</p>`:''}${it.motivo?`<p class="mt-1 text-xs text-danger">${esc(it.motivo)}</p>`:''}
  <div class="mt-3 flex flex-wrap gap-2" data-id="${it.id}">${['analise','ajustes'].includes(it.status)?`<button type="button" data-act="approve" class="${PRI} h-10">Aprovar e pôr no ar</button><button type="button" data-act="adjust" class="${GHO} h-10">Pedir ajustes</button><button type="button" data-act="reject" class="${DAN} h-10">Recusar</button>`:''}${it.status==='aprovado'||it.status==='pagamento'?`<button type="button" data-act="activate" class="${GHO} h-10">Marcar como pago e pôr no ar</button>`:''}${it.status==='ativo'?`<button type="button" data-act="end" class="${DAN} h-10">Encerrar</button>`:''}</div>
  <div data-mot="${it.id}" class="mt-2 hidden"><input class="${INP}" placeholder="Motivo (a empresa vê)"><div class="mt-2 flex gap-2"><button type="button" data-send class="${PRI} h-10">Enviar</button><button type="button" data-cancel class="${GHO} h-10">Voltar</button></div></div></div>`};
 const pend=L.items.filter(i=>['analise','ajustes'].includes(i.status)),outros=L.items.filter(i=>!['analise','ajustes'].includes(i.status));
 p.innerHTML=`<div><h2 class="${H2}">Pagos aguardando aprovação (${pend.length})</h2>${card(pend.map(box).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhuma proposta pendente.</div>')}<h2 class="${H2} mt-8">Todos os anúncios</h2>${card(outros.map(box).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhum anúncio ainda.</div>')}<p class="mt-3 px-1 text-xs text-ink-3">Os planos e preços ficam na aba Planos de anúncio; o recebimento por Pix usa as credenciais da aba Mercado Pago.</p></div>`;
 const send=async(id,action,motivo)=>{try{await api('/api/v2/admin/ads/'+id,{method:'POST',body:JSON.stringify({action,motivo})});toast('Feito. A empresa foi avisada.');pAds(p)}catch(e){toast(e.message)}};
 $$('[data-act]',p).forEach(b=>b.onclick=()=>{const id=b.parentElement.dataset.id,a=b.dataset.act;if(a==='adjust'||a==='reject'){const m=$(`[data-mot="${id}"]`,p);m.classList.remove('hidden');m.dataset.a=a;$('input',m).focus();$('[data-send]',m).onclick=()=>{const v=$('input',m).value.trim();if(!v)return toast('Informe o motivo.');send(id,m.dataset.a,v)};$('[data-cancel]',m).onclick=()=>m.classList.add('hidden')}else send(id,a)});
}


async function share(url,title){try{if(navigator.share){await navigator.share({title,url});return}}catch(e){if(e&&e.name==='AbortError')return}try{await navigator.clipboard.writeText(url);toast('Link copiado')}catch(e){prompt('Copie o link:',url)}}
function pLinks(p){const base=location.origin;const L=[['Apresentação do Meu Assistente','Página pública para conhecer o app e criar conta.','/conheca'],['Criar anúncio','Para empresas anunciarem (pede login).','/x/anunciar'],['Empresas perto de você','Lista de parceiros por localização (pede login).','/x/empresas']];
 p.innerHTML=`<div><h2 class="${H2}">Páginas e links para compartilhar</h2>${card(L.map(([t,d,path],i)=>`<div class="px-5 py-4"><p class="text-[15px] font-medium">${t}</p><p class="mt-0.5 text-xs text-ink-3">${d}</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">${esc(base+path)}</code><div class="mt-2 flex flex-wrap gap-2"><button type="button" data-cp="${i}" class="${GHO} h-10">Copiar link</button><button type="button" data-sh="${i}" class="${PRI} h-10">Compartilhar</button><a href="${esc(path)}" class="${GHO} h-10">Abrir</a></div></div>`).join(''))}
 <p class="mt-3 px-1 text-xs text-ink-3">Cada empresa com plano Página ou Loja tem o próprio link, que o dono copia em Sua empresa. Os planos de assinatura do próprio Meu Assistente (para usuários) ainda serão ligados ao Mercado Pago numa próxima etapa.</p></div>`;
 $$('[data-cp]',p).forEach(b=>b.onclick=async()=>{const u=base+L[+b.dataset.cp][2];try{await navigator.clipboard.writeText(u);toast('Link copiado')}catch(e){prompt('Copie o link:',u)}});
 $$('[data-sh]',p).forEach(b=>b.onclick=()=>share(base+L[+b.dataset.sh][2],L[+b.dataset.sh][0]));}
function pBotoes(p){const Q=C.quick_buttons;let items=Q.items.slice();
 const draw=()=>{p.innerHTML=`<div><h2 class="${H2}">Botões rápidos do chat</h2>${card(row('Mostrar botões rápidos','Sugestões na tela inicial do chat.',sw('qb',Q.enabled,'Mostrar botões rápidos'))+row('Usar a minha lista','Desligado: usa os botões originais do app.',sw('qc',Q.custom,'Usar a minha lista')))}
 <h2 class="${H2} mt-8">Sua lista (até 8)</h2>${card(items.map((t,i)=>`<div class="flex items-center gap-2 px-5 py-3"><input data-it="${i}" class="${INP}" value="${esc(t)}"><button type="button" data-up="${i}" class="${GHO} h-10 shrink-0" ${i?'':'disabled'}>↑</button><button type="button" data-rm="${i}" class="${DAN} h-10 shrink-0">×</button></div>`).join('')+(items.length<8?`<div class="px-5 py-3"><button type="button" id="qadd" class="${GHO} h-10">+ Novo botão</button></div>`:''))}
 <div class="mt-3"><button type="button" id="qsave" class="${PRI} h-10">Salvar botões</button></div><p class="mt-2 px-1 text-xs text-ink-3">Ao tocar, o botão envia o texto para o assistente, como se o usuário tivesse digitado.</p></div>`;
  const read=()=>{items=$$('[data-it]',p).map(i=>i.value.trim())};
  $$('[data-sw]',p).forEach(b=>b.onclick=()=>{read();if(b.dataset.sw==='qb')Q.enabled=!Q.enabled;else Q.custom=!Q.custom;draw()});
  $$('[data-rm]',p).forEach(b=>b.onclick=()=>{read();items.splice(+b.dataset.rm,1);draw()});
  $$('[data-up]',p).forEach(b=>b.onclick=()=>{read();const i=+b.dataset.up;[items[i-1],items[i]]=[items[i],items[i-1]];draw()});
  if($('#qadd',p))$('#qadd',p).onclick=()=>{read();items.push('');draw();const l=$$('[data-it]',p).pop();if(l)l.focus()};
  $('#qsave',p).onclick=()=>{read();put('quick_buttons',{enabled:Q.enabled,custom:Q.custom,items:items.filter(Boolean)})};};draw()}


async function pKb(p,edit){
 p.innerHTML='<p class="text-sm text-ink-3">Carregando materiais…</p>';
 let L;try{L=await api('/api/v2/admin/kb')}catch(e){p.innerHTML=`<div class="glass rounded-[1.6rem] p-5 text-sm text-ink-2">${esc(e.message)}</div>`;return}
 const ed=edit?L.items.find(x=>x.id===edit):null;
 p.innerHTML=`<div><h2 class="${H2}">Biblioteca de Sobrevivência</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">Os materiais ativos são <b class="text-ink">baixados automaticamente</b> pelo app quando ele abre com internet e ficam disponíveis <b class="text-ink">mesmo sem conexão</b>, na Central SOS e no chat.</div>
 ${card(L.items.map(d=>`<div class="px-5 py-4"><div class="flex items-start gap-3"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${esc(d.title)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(d.description||'')} · ${d.chunks} trecho(s) · versão ${d.version}${d.sos?' · Central SOS':''}</p></div>${pill(d.active?'Disponível':'Oculto',d.active?'ok':'')}</div><div class="mt-2 flex flex-wrap gap-3 text-[13px] font-semibold"><button type="button" data-ke="${d.id}" class="text-ink-2">Editar</button><button type="button" data-kt="${d.id}" class="text-ink-2">${d.active?'Ocultar':'Mostrar'}</button><button type="button" data-kd="${d.id}" class="text-danger">Excluir</button></div></div>`).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhum material cadastrado.</div>')}
 <h2 class="${H2} mt-8">${ed?'Editar material':'Cadastrar novo material'}</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5">
 <label class="block"><span class="text-xs text-ink-3">Título</span><input id="kt" class="${INP} mt-1" value="${esc(ed?ed.title:'')}" placeholder="Ex.: Abrigo no frio"></label>
 <label class="block"><span class="text-xs text-ink-3">Descrição curta</span><input id="kds" class="${INP} mt-1" value="${esc(ed?ed.description:'')}"></label>
 <label class="block"><span class="text-xs text-ink-3">Palavras-chave (separadas por vírgula)</span><input id="kk" class="${INP} mt-1" value="${esc(ed?ed.keywords.join(', '):'')}" placeholder="frio, abrigo, hipotermia"></label>
 <div class="flex items-center justify-between gap-3"><span class="text-[14px]">Mostrar na Central SOS</span>${sw('ksos',ed?ed.sos:true,'Central SOS')}</div>
 <label class="block"><span class="text-xs text-ink-3">Conteúdo. Use linhas começando com # para os títulos das seções.</span><textarea id="kc" rows="12" class="${INP} mt-1" style="height:auto;padding-top:10px;font-size:13.5px">${esc(ed?ed.content:'')}</textarea></label>
 <label class="block"><span class="text-xs text-ink-3">Ou envie um arquivo de texto (.txt ou .md)</span><input id="kf" type="file" accept=".txt,.md,text/plain,text/markdown" class="${INP} mt-1" style="height:auto;padding-top:8px"></label>
 <p class="ma-err" id="kerr"></p><div class="flex flex-wrap gap-2"><button type="button" id="ks" class="${PRI} h-10">${ed?'Salvar alterações':'Cadastrar material'}</button>${ed?`<button type="button" id="kx" class="${GHO} h-10">Cancelar</button>`:''}</div>
 <p class="text-xs text-ink-3">Revise sempre o conteúdo: em temas de saúde e segurança, oriente a procurar o 192, 193 ou a Defesa Civil (199).</p></div></div>`;
 let sos=ed?ed.sos:true;
 $('[data-sw="ksos"]',p).onclick=e=>{sos=!sos;e.currentTarget.setAttribute('aria-checked',sos)};
 $('#kf',p).onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>2e6)return toast('Arquivo muito grande (máx. 2 MB).');const r=new FileReader();r.onload=()=>{$('#kc',p).value=r.result;if(!$('#kt',p).value)$('#kt',p).value=f.name.replace(/\.[^.]+$/,'')};r.readAsText(f,'utf-8')};
 $('#ks',p).onclick=async()=>{try{await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({id:ed&&ed.id,title:$('#kt',p).value.trim(),description:$('#kds',p).value.trim(),keywords:$('#kk',p).value,sos,content:$('#kc',p).value})});toast('Material salvo. Os aparelhos baixam a nova versão sozinhos.');pKb(p)}catch(x){$('#kerr',p).textContent=x.message}};
 if($('#kx',p))$('#kx',p).onclick=()=>pKb(p);
 $$('[data-ke]',p).forEach(b=>b.onclick=()=>pKb(p,+b.dataset.ke));
 $$('[data-kt]',p).forEach(b=>b.onclick=async()=>{await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({action:'toggle',id:+b.dataset.kt})});pKb(p)});
 $$('[data-kd]',p).forEach(b=>b.onclick=async()=>{if(!confirm('Excluir este material de todos os aparelhos?'))return;await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({action:'delete',id:+b.dataset.kd})});pKb(p)});
}


const MENU_DEF=[['suaempresa','Sua empresa'],['empresas','Empresas perto de você'],['pedidos','Meus pedidos'],['o:Meu Dia','Meu Dia'],['o:Tarefas','Tarefas'],['o:Compromissos','Compromissos'],['o:Contas','Contas'],['mercado','Mercado'],['impostos','Impostos e DAS'],['planos','Meu plano'],['o:Cérebro do Chat','Cérebro do Chat'],['o:Anúncios e Parceiros','Anúncios e Parceiros'],['anunciar','Anunciar minha empresa']];
function pMenu(p){const saved=(C.menu&&C.menu.items)||[];let items=saved.filter(x=>MENU_DEF.some(d=>d[0]===x.key));MENU_DEF.forEach(([k,l])=>{if(!items.some(x=>x.key===k))items.push({key:k,label:l,visible:true})});
 const draw=()=>{p.innerHTML=`<div><h2 class="${H2}">Menu do app</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">Organize a ordem e oculte itens do menu lateral. <b class="text-ink">Ocultar não desliga a função</b>: o usuário continua usando pelo chat (ex.: “como está o bitcoin?”). Para desligar uma função de vez, use a aba Módulos.</div>${card(items.map((x,i)=>`<div class="flex items-center gap-2 px-5 py-3"><span class="min-w-0 flex-1 text-[14.5px] ${x.visible?'':'text-ink-3 line-through'}">${esc(x.label)}</span><button type="button" data-up="${i}" class="${GHO} h-9 shrink-0" ${i?'':'disabled'}>↑</button><button type="button" data-dn="${i}" class="${GHO} h-9 shrink-0" ${i<items.length-1?'':'disabled'}>↓</button>${sw('m'+i,x.visible,'Mostrar '+x.label)}</div>`).join(''))}<div class="mt-3"><button type="button" id="msave" class="${PRI} h-10">Salvar menu</button></div><p class="mt-2 px-1 text-xs text-ink-3">Administração sempre aparece por último para quem é administrador.</p></div>`;
  $$('[data-up]',p).forEach(b=>b.onclick=()=>{const i=+b.dataset.up;[items[i-1],items[i]]=[items[i],items[i-1]];draw()});
  $$('[data-dn]',p).forEach(b=>b.onclick=()=>{const i=+b.dataset.dn;[items[i+1],items[i]]=[items[i],items[i+1]];draw()});
  $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const i=+b.dataset.sw.slice(1);items[i].visible=!items[i].visible;draw()});
  $('#msave',p).onclick=()=>put('menu',{items})};draw()}
function pUsos(p){const U=JSON.parse(JSON.stringify(C.usage_plans)),K=C.usage_kinds;
 const limIn=(pref,lim)=>`<div class="grid grid-cols-2 gap-2 md:grid-cols-4">${Object.keys(K).map(k=>`<label class="block"><span class="text-[11px] text-ink-3">${esc(K[k])} / dia</span><input data-l="${pref}:${k}" inputmode="numeric" class="${INP} mt-1" value="${lim[k]===null||lim[k]===undefined?'':lim[k]}" placeholder="ilimitado"></label>`).join('')}</div>`;
 const draw=()=>{p.innerHTML=`<div><h2 class="${H2}">Planos de uso do Meu Assistente</h2>${card(row('Ativar limites e planos','Desligado: todos usam sem limite.',sw('uativo',U.ativo,'Ativar limites')))}
 <h2 class="${H2} mt-8">Uso grátis (sem plano)</h2><div class="glass rounded-[1.6rem] p-5"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="ufn" class="${INP} mt-1" value="${esc(U.free.nome)}"></label><p class="mt-3 mb-2 text-xs text-ink-3">Limite diário de cada função. Deixe vazio para ilimitado; 0 bloqueia.</p>${limIn('free',U.free.limites)}</div>
 <h2 class="${H2} mt-8">Planos mensais</h2>${U.plans.map((pl,i)=>`<div class="glass mb-3 rounded-[1.6rem] p-5"><div class="grid grid-cols-2 gap-3 md:grid-cols-4"><label class="block md:col-span-2"><span class="text-xs text-ink-3">Nome</span><input data-pn="${i}" class="${INP} mt-1" value="${esc(pl.nome)}"></label><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input data-pp="${i}" inputmode="decimal" class="${INP} mt-1" value="${String(pl.preco).replace('.',',')}"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input data-pd="${i}" inputmode="numeric" class="${INP} mt-1" value="${pl.dias}"></label></div><div class="mt-3">${limIn('p'+i,pl.limites)}</div><div class="mt-3 flex items-center justify-between"><span class="flex items-center gap-2 text-[13.5px]">Disponível ${sw('pa'+i,pl.ativo!==false,'Disponível')}</span><button type="button" data-prm="${i}" class="${DAN} h-9">Remover plano</button></div></div>`).join('')}
 <div class="flex flex-wrap gap-2"><button type="button" id="uadd" class="${GHO} h-10">+ Novo plano</button><button type="button" id="usave" class="${PRI} h-10">Salvar planos</button></div><p class="mt-3 px-1 text-xs text-ink-3">O usuário assina em Menu → Meu plano, paga por Pix (Mercado Pago do administrador) e o plano é liberado automaticamente pelos dias configurados. Administradores não têm limite.</p></div>`;
  const read=()=>{U.free.nome=$('#ufn',p).value.trim()||'Grátis';$$('[data-l]',p).forEach(i=>{const [pref,k]=i.dataset.l.split(':'),v=i.value.trim(),val=v===''?null:Math.max(0,parseInt(v,10)||0);if(pref==='free')U.free.limites[k]=val;else U.plans[+pref.slice(1)].limites[k]=val});U.plans.forEach((pl,i)=>{pl.nome=$(`[data-pn="${i}"]`,p).value.trim();pl.preco=parseFloat($(`[data-pp="${i}"]`,p).value.replace(',','.'))||0;pl.dias=parseInt($(`[data-pd="${i}"]`,p).value,10)||30})};
  $$('[data-sw]',p).forEach(b=>b.onclick=()=>{read();const k=b.dataset.sw;if(k==='uativo')U.ativo=!U.ativo;else{const i=+k.slice(2);U.plans[i].ativo=U.plans[i].ativo===false}draw()});
  $$('[data-prm]',p).forEach(b=>b.onclick=()=>{read();U.plans.splice(+b.dataset.prm,1);draw()});
  $('#uadd',p).onclick=()=>{read();U.plans.push({id:'',nome:'Novo plano',preco:9.9,dias:30,ativo:true,limites:{}});draw()};
  $('#usave',p).onclick=()=>{read();put('usage_plans',U)}};draw()}
function pChatAds(p){const F=C.ad_frequency;p.innerHTML=`<div><h2 class="${H2}">Anúncio dentro do chat</h2>${card(row('Mostrar anúncios no chat','Um cartão patrocinado de uma empresa ativa aparece entre as respostas.',sw('fa',F.ativo,'Mostrar anúncios')))}<div class="glass mt-4 grid grid-cols-2 gap-3 rounded-[1.6rem] p-5"><label class="block"><span class="text-xs text-ink-3">A cada quantas respostas</span><input id="fc" inputmode="numeric" class="${INP} mt-1" value="${F.cada}"></label><label class="block"><span class="text-xs text-ink-3">Intervalo mínimo (minutos)</span><input id="fi" inputmode="numeric" class="${INP} mt-1" value="${F.intervaloMin}"></label><p class="col-span-2 text-xs text-ink-3">Exemplo: 6 respostas e 30 minutos = no máximo um anúncio a cada 6 respostas e nunca antes de 30 minutos do anterior. Só aparecem empresas no alcance do usuário.</p><div class="col-span-2"><button type="button" id="fs" class="${PRI} h-10">Salvar</button></div></div></div>`;
 $('[data-sw="fa"]',p).onclick=e=>{F.ativo=!F.ativo;e.currentTarget.setAttribute('aria-checked',F.ativo)};
 $('#fs',p).onclick=()=>put('ad_frequency',{ativo:F.ativo,cada:parseInt($('#fc',p).value,10)||6,intervaloMin:parseInt($('#fi',p).value,10)||0})}


function pMotor(p){const E={...C.engine};const SL=[['naturalidade','Naturalidade','Robótico','Bem natural'],['criatividade','Criatividade','Previsível','Criativo'],['contexto','Interpretação do contexto','Só a última mensagem','Toda a conversa'],['autonomia','Autonomia nas respostas','Só o pedido','Proativo'],['precisao','Precisão','Flexível','Rigoroso']];
 p.innerHTML=`<div><h2 class="${H2}">Motor do chat</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">Ajuste o jeito de conversar do assistente. Vale para todos os usuários assim que você salvar; as funções (registrar gastos, agenda, lembretes) continuam iguais.</div>
 <div class="glass grid gap-5 rounded-[1.6rem] p-5">${SL.map(([k,l,a,b])=>`<label class="block"><div class="flex justify-between text-[14.5px]"><span>${l}</span><b id="v_${k}" class="tabular">${E[k]}</b></div><input type="range" min="0" max="100" step="5" data-sl="${k}" value="${E[k]}" class="mt-2 w-full" style="accent-color:var(--nx-accent)"><div class="flex justify-between text-[11px] text-ink-3"><span>${a}</span><span>${b}</span></div></label>`).join('')}
 <label class="block"><span class="text-xs text-ink-3">Personalidade</span><select id="ep" class="${INP} mt-1">${[['amigavel','Amigável'],['profissional','Profissional'],['divertido','Divertido'],['direto','Direto']].map(([k,l])=>`<option value="${k}" ${E.personalidade===k?'selected':''}>${l}</option>`).join('')}</select></label>
 <label class="block"><span class="text-xs text-ink-3">Orientações extras (opcional)</span><textarea id="et2" rows="3" class="${INP} mt-1" style="height:auto;padding-top:10px" placeholder="Ex.: chame o usuário pelo primeiro nome; use emojis com moderação.">${esc(E.personalidadeTexto||'')}</textarea></label>
 <div><button type="button" id="esave" class="${PRI} h-10">Salvar e aplicar</button></div></div></div>`;
 $$('[data-sl]',p).forEach(i=>i.oninput=()=>{E[i.dataset.sl]=+i.value;$('#v_'+i.dataset.sl,p).textContent=i.value});
 $('#esave',p).onclick=()=>put('engine',{...E,personalidade:$('#ep',p).value,personalidadeTexto:$('#et2',p).value.trim()})}
function pAgente(p){const A={...C.agent_plan},on=!!C.modules.agente;
 p.innerHTML=`<div><h2 class="${H2}">Agente de atendimento das empresas</h2>${card(row('Oferecer o agente às empresas','Desligado: a opção some de Sua empresa e os links ficam indisponíveis.',sw('agon',on,'Oferecer agente')))}
 <div class="glass mt-4 grid grid-cols-3 gap-3 rounded-[1.6rem] p-5"><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input id="agp" class="${INP} mt-1" value="${String(A.preco).replace('.',',')}"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input id="agd" class="${INP} mt-1" value="${A.dias}"></label><label class="block"><span class="text-xs text-ink-3">Mensagens/dia</span><input id="agl" class="${INP} mt-1" value="${A.limiteDia}"></label><p class="col-span-3 text-xs text-ink-3">A empresa configura o atendente em Sua empresa → Agente de atendimento, paga por Pix (seu Mercado Pago) e recebe um link para compartilhar com os clientes. O agente responde com base no catálogo, horário, entrega e pagamento da empresa.</p><div class="col-span-3"><button type="button" id="agsv" class="${PRI} h-10">Salvar plano do agente</button></div></div></div>`;
 $('[data-sw="agon"]',p).onclick=()=>put('modules',{agente:!on});
 $('#agsv',p).onclick=()=>put('agent_plan',{preco:parseFloat($('#agp',p).value.replace(',','.'))||39.9,dias:parseInt($('#agd',p).value,10)||30,limiteDia:parseInt($('#agl',p).value,10)||300})}


const FCAT={expense:[['alimentacao','Alimentação'],['combustivel','Combustível'],['casa','Casa'],['trabalho','Trabalho'],['compras','Compras'],['saude','Saúde'],['transporte','Transporte'],['lazer','Lazer'],['outros','Outros']],income:[['salario','Salário'],['servicos','Serviços'],['vendas','Vendas'],['outros','Outros']]};
function pFin(p){let L=((C.fin_dict||{}).items||[]).map(x=>({...x}));let tipo='expense';
 const draw=()=>{p.innerHTML=`<div><h2 class="${H2}">Categorias financeiras do chat</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">O chat já reconhece gastos, receitas, pagamentos e transferências nas categorias do sistema. Aqui você <b class="text-ink">acrescenta subcategorias e palavras</b> (ex.: “Clube do vinho” com “confraria”) e o motor passa a usar na hora, sem mexer no código.</div>
 ${card(L.map((x,i)=>`<div class="flex items-start gap-3 px-5 py-3.5"><div class="min-w-0 flex-1"><p class="text-[14.5px] font-medium">${esc(x.sub)} <span class="text-xs text-ink-3">· ${x.tipo==='income'?'Receita':'Gasto'} · ${esc((FCAT[x.tipo].find(c=>c[0]===x.cat)||[,x.cat])[1])}</span></p><p class="mt-0.5 text-xs text-ink-3">${esc(x.words.join(', '))}</p></div><button type="button" data-fr="${i}" class="${DAN} h-9 shrink-0">×</button></div>`).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhuma subcategoria extra ainda.</div>')}
 <h2 class="${H2} mt-8">Adicionar</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5"><div class="glass no-scrollbar flex w-fit gap-1 rounded-full p-1">${[['expense','Gasto'],['income','Receita']].map(([k,l])=>`<button type="button" data-ft="${k}" class="flex h-9 items-center rounded-full px-4 text-[13px] font-semibold ${tipo===k?'btn-send':'text-ink-2'}">${l}</button>`).join('')}</div>
 <label class="block"><span class="text-xs text-ink-3">Categoria do sistema</span><select id="fc" class="${INP} mt-1">${FCAT[tipo].map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select></label>
 <label class="block"><span class="text-xs text-ink-3">Subcategoria</span><input id="fs" class="${INP} mt-1" placeholder="Ex.: Clube do vinho"></label>
 <label class="block"><span class="text-xs text-ink-3">Palavras que o usuário pode usar (separadas por vírgula)</span><input id="fw" class="${INP} mt-1" placeholder="Ex.: confraria, clube do vinho"></label>
 <div class="flex flex-wrap gap-2"><button type="button" id="fa" class="${GHO} h-10">Adicionar à lista</button><button type="button" id="fsv" class="${PRI} h-10">Salvar categorias</button></div></div></div>`;
  $$('[data-ft]',p).forEach(b=>b.onclick=()=>{tipo=b.dataset.ft;draw()});
  $$('[data-fr]',p).forEach(b=>b.onclick=()=>{L.splice(+b.dataset.fr,1);draw()});
  $('#fa',p).onclick=()=>{const sub=$('#fs',p).value.trim(),words=$('#fw',p).value.split(',').map(w=>w.trim().toLowerCase()).filter(Boolean);if(!sub||!words.length)return toast('Preencha a subcategoria e pelo menos uma palavra.');L.push({tipo,cat:$('#fc',p).value,sub,words});draw()};
  $('#fsv',p).onclick=()=>put('fin_dict',{items:L})};draw()}

const MODS=[['catalogo','Lojas e pedidos','Catálogo e pedidos das empresas com plano Loja completa.'],['anuncios','Anúncios','Cartões patrocinados no chat e página Anunciar.'],['financas','Finanças','Gastos, contas e vencimentos.'],['lembretes','Lembretes','Avisos e compromissos.'],['imagens','Fotos e arquivos','Envio de imagens e comprovantes no chat.'],['voz','Voz do assistente','Mensagens de voz e Modo Voz (oculta os botões de voz para todos).'],['sugestoes','Botões rápidos do chat','Sugestões que aparecem na tela inicial do chat.'],['empresas','Empresas perto de você','Busca de empresas no chat e no menu.'],['fiscal','Impostos e DAS','DAS do MEI, limite e declarações.'],['mercado','Mercado','Cotações de cripto e bolsa, com alertas.']];
function pMod(p){p.innerHTML=`<div><h2 class="${H2}">Módulos globais</h2>${card(MODS.map(([k,n,d])=>row(n,d,sw(k,C.modules[k],n))).join(''))}<p class="mt-3 px-1 text-xs text-ink-3">Um módulo desligado some para todos os usuários conforme cada módulo for ligado ao servidor.</p></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('modules',{[b.dataset.sw]:!C.modules[b.dataset.sw]}))}
function provState(pv,rt){const b=rt&&rt.breakers&&rt.breakers[pv.id],st=rt&&rt.stats&&rt.stats[pv.id],t=st&&st.test;if(!pv.ativo)return['Desligada',''];if(pv.id!=='servidor'&&!pv.hasKey)return['Sem chave',''];if(b&&b.hard)return[b.kind==='auth'?'Chave recusada':'Modelo ou endereço inválido','bad'];if(b&&b.state==='open')return[(b.kind==='rate_limit'?'Limite atingido':'Em pausa')+' · volta em '+b.seconds+'s','warn'];if(b&&b.state==='half')return['Recuperando…','warn'];if(t&&!t.ok){const conv=(t.checks||[]).find(c=>c.cap==='texto');return conv&&conv.ok?['Pronta para conversa','ok']:['Teste com falhas','warn']}return['Pronta','ok']}
function aiItems(mod){return C.ai_providers.map(x=>{const o={id:x.id,nome:x.nome,base_url:x.base_url,modelo:x.modelo,modelo_audio:x.modelo_audio,tipo:x.tipo,caps:{...x.caps},texto:x.caps.texto,imagem:x.caps.imagem,ativo:x.ativo};return mod?mod(o)||o:o})}
const fN=n=>n>=1000?(n/1000).toFixed(1).replace('.',',')+' mil':String(n||0);
const fT=(r)=>(r.checks||[]).map(c=>`<p class="text-xs ${c.ok?'text-ink-2':'text-danger'}">${c.ok?'✔':'✘'} <b>${esc(c.label)}</b> — ${esc(c.detail)}${c.ms?' ('+(c.ms/1000).toFixed(1).replace('.',',')+' s)':''}</p>`).join('');
function pIA(p){const rt=C.ai_runtime,st=rt.stats||{},R=C.ai_router,day=rt.today,caps=C.ai_caps||[];
 const chip=(on,att,label)=>`<button type="button" ${att} data-on="${on?1:0}" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${on?'btn-send':'border border-line-strong text-ink-2'}">${label}</button>`;
 const num=(id,l,v,h)=>`<label class="block"><span class="text-xs text-ink-3">${l}</span><input id="${id}" inputmode="numeric" class="${INP} mt-1" value="${v}"><span class="text-[11px] text-ink-3">${h}</span></label>`;
 p.innerHTML=`<div><h2 class="${H2}">Motor multi-IA</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">Todas as IAs <b class="text-ink">ligadas e com chave</b> trabalham juntas: o motor escolhe a melhor para cada tarefa (conversa, imagens, PDFs, áudio, programação, pesquisa), troca na hora se uma falhar e compara respostas nas tarefas complexas. O botão <b class="text-ink">Testar</b> prova cada capacidade com uma requisição real — uma IA que falha numa capacidade deixa de ser escolhida para ela.</div>
 ${card(C.ai_providers.map((pv,i)=>{const [s,k]=provState(pv,rt),o=open===pv.id,ss=st[pv.id]||{uses:0,failures:0,tokensIn:0,tokensOut:0,lat:0,days:{},errors:[],byTask:{}},dd=(ss.days||{})[day]||{uses:0,failures:0,in:0,out:0},t=ss.test,custom=pv.id==='custom'||pv.id.startsWith('c-');
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium"><span class="tabular text-ink-3">${i+1}.</span> ${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(caps.filter(c=>pv.caps[c.id]).map(c=>c.label).join(', ')||'nenhuma capacidade')} · ${ss.uses} respostas · ${ss.failures} falhas${ss.lat?' · '+(ss.lat/1000).toFixed(1).replace('.',',')+' s':''}</p></button>${pill(s,k)}${sw('a:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><p class="text-xs text-ink-3">${esc(pv.onde)}</p>
   <div class="grid grid-cols-3 gap-2 text-center"><div class="glass rounded-2xl p-2"><p class="tabular text-[15px] font-semibold">${dd.uses}</p><p class="text-[11px] text-ink-3">respostas hoje</p></div><div class="glass rounded-2xl p-2"><p class="tabular text-[15px] font-semibold">${fN(dd.in+dd.out)}</p><p class="text-[11px] text-ink-3">tokens hoje</p></div><div class="glass rounded-2xl p-2"><p class="tabular text-[15px] font-semibold">${fN((ss.tokensIn||0)+(ss.tokensOut||0))}</p><p class="text-[11px] text-ink-3">tokens no total</p></div></div>
   ${pv.id!=='servidor'?`<label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':''}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave aqui'}"></label>
   ${custom?`<label class="block"><span class="text-xs text-ink-3">Tipo de API</span><select data-f="tipo" class="${INP} mt-1">${[['openai','Compatível com OpenAI'],['gemini','Google Gemini (nativa)'],['anthropic','Anthropic Claude (nativa)']].map(([a,b])=>`<option value="${a}" ${pv.tipo===a?'selected':''}>${b}</option>`).join('')}</select></label>`:`<p class="text-xs text-ink-3">API: ${pv.tipo==='gemini'?'Google Gemini (nativa)':pv.tipo==='anthropic'?'Anthropic Claude (nativa)':'compatível com OpenAI'}</p>`}
   <label class="block"><span class="text-xs text-ink-3">Endereço da API</span><input data-f="base_url" class="${INP} mt-1" value="${esc(pv.base_url)}" placeholder="https://…"></label>
   <label class="block"><span class="text-xs text-ink-3">Modelo</span><input data-f="modelo" class="${INP} mt-1" value="${esc(pv.modelo)}" placeholder="Nome do modelo no serviço"></label>
   ${pv.tipo==='openai'?`<label class="block"><span class="text-xs text-ink-3">Modelo de áudio (transcrição, opcional)</span><input data-f="modelo_audio" class="${INP} mt-1" value="${esc(pv.modelo_audio||'')}" placeholder="Ex.: whisper-1"></label>`:''}`:`<p class="text-xs text-ink-3">Configurada no arquivo .env da VPS (AI_BASE_URL e AI_MODEL).</p>`}
   <div><span class="text-xs text-ink-3">Para que esta IA pode ser usada</span><div class="mt-1 flex flex-wrap gap-2">${caps.map(c=>pv.id==='servidor'&&['documento','audio','pesquisa'].includes(c.id)?`<span class="rounded-full border border-line px-3 py-1.5 text-[12.5px] text-ink-3" title="O modelo do servidor não faz isso" style="opacity:.5;text-decoration:line-through">${c.label}</span>`:chip(pv.caps[c.id],`data-cap="${c.id}"`,c.label)).join('')}</div>${pv.id==='servidor'?`<p class="mt-2 text-[12px] leading-relaxed text-ink-3">A IA do servidor (Ollama da VPS) é a <b class="text-ink">reserva sem limite</b>: ótima para conversa, mas modelos pequenos não fazem leitura de documentos e áudio e costumam falhar ao chamar ferramentas. Quando ela falha em Ferramentas, as ações (registrar, agendar, pedir) vão automaticamente para as outras IAs.</p>`:''}</div>
   ${t?`<div class="grid gap-0.5"><p class="text-xs text-ink-3">Último teste real: ${new Date(t.at).toLocaleString('pt-BR')} — ${t.ok?'aprovada':'com falhas'}</p>${fT(t)}</div>`:''}
   ${(ss.errors||[]).length?`<div><p class="text-xs text-ink-3">Últimos erros</p>${ss.errors.slice(-3).reverse().map(e=>`<p class="text-xs text-danger">${new Date(e.at).toLocaleTimeString('pt-BR')} · ${esc(e.kind)} · ${esc(e.msg)}</p>`).join('')}</div>`:''}<p class="ma-ok" data-msg></p><div data-checks class="grid gap-0.5"></div>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10" ${i===0?'disabled':''}>Subir</button><button type="button" data-down class="${GHO} h-10" ${i===C.ai_providers.length-1?'disabled':''}>Descer</button>${['bad','warn'].includes(provState(pv,rt)[1])?`<button type="button" data-resume class="${GHO} h-10">Reativar</button>`:''}${pv.hasKey?`<button type="button" data-clear class="${DAN} h-10">Remover chave</button>`:''}</div></div>`:''}</div>`}).join(''))}
 <div class="mt-3 flex flex-wrap gap-2"><button type="button" id="aiall" class="${GHO} h-10">Testar todas as IAs ligadas</button><button type="button" id="aiadd" class="${GHO} h-10">Adicionar outra IA</button></div><p class="ma-ok mt-2" id="aiallmsg"></p><div id="aiallout" class="grid gap-1"></div>
 <p class="mt-2 px-1 text-xs text-ink-3">Toque no nome de uma IA para colar a chave, escolher o modelo, ligar capacidades, testar e mudar a prioridade (ordem da lista).</p>
 <h2 class="${H2} mt-8">Como o motor decide</h2><div class="glass grid gap-4 rounded-[1.6rem] p-5">
  <label class="block"><span class="text-xs text-ink-3">Critério de escolha</span><select id="rmodo" class="${INP} mt-1">${[['equilibrado','Equilibrado (tarefa, qualidade, velocidade e prioridade)'],['prioridade','Prioridade (segue a ordem da lista)'],['velocidade','Velocidade (a mais rápida)'],['qualidade','Qualidade (a mais indicada para a tarefa)']].map(([a,b])=>`<option value="${a}" ${R.modo===a?'selected':''}>${b}</option>`).join('')}</select></label>
  <div class="grid grid-cols-2 gap-3">${num('rto','Tempo máximo por IA (s)',Math.round(R.timeoutMs/1000),'Passou disso, outra assume')}${num('rpz','Prazo total da resposta (s)',Math.round(R.prazoMs/1000),'Soma de todas as tentativas')}${num('rtn','Novas tentativas',R.tentativas,'Só em erro temporário')}${num('rbf','Falhas para pausar a IA',R.breaker.falhas,'Circuit breaker')}${num('rbp','Pausa inicial (s)',R.breaker.pausaSeg,'Dobra a cada nova queda')}${num('rmx','IAs em paralelo (2 a 4)',R.paralelo.max,'Em tarefas complexas')}</div>
  <div><span class="text-xs text-ink-3">Consulta paralela (compara as respostas e escolhe a melhor)</span><div class="mt-1 flex flex-wrap gap-2">${chip(R.paralelo.ativo,'id="rpa"','Ligada')}${chip(R.paralelo.modo==='comparar','id="rpm"','Comparar e escolher')}${[['analise','Análises'],['codigo','Programação'],['pesquisa','Pesquisas'],['conversa','Conversa'],['contexto','Contexto longo']].map(([k,l])=>chip(R.paralelo.tarefas.includes(k),`data-pt="${k}"`,l)).join('')}</div><p class="mt-1 text-[11px] text-ink-3">Desligar “Comparar” usa a corrida: vale a primeira resposta válida. Nunca roda em paralelo quando há gravações (ferramentas), para não duplicar nada.</p></div>
  <div class="flex flex-wrap items-center gap-2">${chip(R.monitor.ativo,'id="rmo"','Monitor de saúde ligado')}<span class="text-xs text-ink-3">Testa IAs em pausa e reativa sozinho quando voltam.</span></div>
  <div><button type="button" id="rsave" class="${PRI} h-10">Salvar motor</button></div></div></div>`;
 const flip=b=>{const on=b.dataset.on!=='1';b.dataset.on=on?'1':'0';b.className=`flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${on?'btn-send':'border border-line-strong text-ink-2'}`;return on};
 $$('[data-pt],#rpa,#rpm,#rmo',p).forEach(b=>b.onclick=()=>flip(b));
 $('#rsave',p).onclick=()=>{const n=id=>parseFloat($('#'+id,p).value.replace(',','.'));put('ai_router',{modo:$('#rmodo',p).value,timeoutMs:n('rto')*1000,prazoMs:n('rpz')*1000,tentativas:n('rtn'),breaker:{falhas:n('rbf'),pausaSeg:n('rbp')},paralelo:{ativo:$('#rpa',p).dataset.on==='1',modo:$('#rpm',p).dataset.on==='1'?'comparar':'corrida',max:n('rmx'),tarefas:$$('[data-pt]',p).filter(b=>b.dataset.on==='1').map(b=>b.dataset.pt)},monitor:{ativo:$('#rmo',p).dataset.on==='1'}})};
 $('#aiall',p).onclick=async()=>{const m=$('#aiallmsg',p),o=$('#aiallout',p);m.className='ma-ok';m.textContent='Testando todas as IAs ligadas… pode levar alguns segundos.';o.innerHTML='';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'ai_all'})});const ids=Object.keys(r.results||{});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.ok?'Todas as IAs ligadas foram aprovadas.':'Algumas IAs falharam em alguma capacidade.';o.innerHTML=ids.map(id=>{const pv=C.ai_providers.find(x=>x.id===id)||{nome:id},x=r.results[id];return `<div class="glass rounded-2xl p-3"><p class="text-[13px] font-medium">${esc(pv.nome)} — ${x.ok?'aprovada':'com falhas'}</p>${x.checks.length?fT(x):`<p class="text-xs text-ink-3">${esc(x.message)}</p>`}</div>`}).join('')}catch(e){m.className='ma-err';m.textContent=e.message}};
 $('#aiadd',p).onclick=()=>{const nome=(prompt('Nome da nova IA (ex.: DeepSeek):')||'').trim();if(!nome)return;const id='c-'+Math.random().toString(36).slice(2,8);put('ai_providers',{items:[...aiItems().filter(x=>x.id!=='servidor'),{id,nome,base_url:'',modelo:'',tipo:'openai',texto:true,imagem:false,ativo:false},...aiItems().filter(x=>x.id==='servidor')]});open=id};
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box,i=C.ai_providers.findIndex(x=>x.id===id);
 $$('[data-cap]',box).forEach(b=>b.onclick=()=>{const k=b.dataset.cap;put('ai_providers',{items:aiItems(o=>o.id===id?{...o,caps:{...o.caps,[k]:!o.caps[k]}}:o)})});
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,...(f('base_url')?{base_url:f('base_url').value.trim(),modelo:f('modelo').value.trim(),key:f('key').value.trim(),...(f('tipo')?{tipo:f('tipo').value}:{}),...(f('modelo_audio')?{modelo_audio:f('modelo_audio').value.trim()}:{})}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box),c=$('[data-checks]',box);m.className='ma-ok';m.textContent='Testando com requisições reais… pode levar alguns segundos.';c.innerHTML='';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'ai',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message;c.innerHTML=fT(r)}catch(e){m.className='ma-err';m.textContent=e.message}};
 const mv=d=>{const it=aiItems(),j=i+d;[it[i],it[j]]=[it[j],it[i]];put('ai_providers',{items:it})};
 if($('[data-up]',box))$('[data-up]',box).onclick=()=>mv(-1);if($('[data-down]',box))$('[data-down]',box).onclick=()=>mv(1);
 if($('[data-resume]',box))$('[data-resume]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,resume:true}:o)});
 if($('[data-clear]',box))$('[data-clear]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,clearKey:true}:o)});
}
function mkItems(mod){return C.market_providers.map(x=>{const o={id:x.id,nome:x.nome,cat:x.cat,url:x.url,campo:x.campo,ativo:x.ativo};return mod?mod(o)||o:o})}
function pFontes(p){const st=C.market_status||{};
 const bloco=cat=>card(C.market_providers.filter(x=>x.cat===cat).map(pv=>{const ss=st[pv.id]||{uses:0,failures:0},s=!pv.ativo?['Desligada','']:pv.precisaChave&&!pv.hasKey?['Sem chave','']:['Pronta','ok'],o=open===pv.id;
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium">${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(pv.info)} · ${ss.uses} consultas · ${ss.failures} falhas</p></button>${pill(s[0],s[1])}${sw('m:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':pv.precisaChave?'':'(opcional)'}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave'}"></label>
   ${pv.custom?`<label class="block"><span class="text-xs text-ink-3">Endereço</span><input data-f="url" class="${INP} mt-1" value="${esc(pv.url)}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input data-f="campo" class="${INP} mt-1" value="${esc(pv.campo)}"></label>`:''}
   ${ss.lastError?`<p class="text-xs text-danger">Último erro: ${esc(ss.lastError)}</p>`:''}<p class="ma-ok" data-msg></p>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10">Subir</button>${pv.custom?`<button type="button" data-del class="${DAN} h-10">Excluir</button>`:''}</div></div>`:''}</div>`}).join(''));
 p.innerHTML=`<div><h2 class="${H2}">Fontes de mercado</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira fonte <b class="text-ink">pronta</b> de cada lista é usada. Se falhar ou atingir o limite, a próxima assume. As cotações ficam guardadas por 1 minuto para economizar o limite.</div>
 <h2 class="${H2}">Criptomoedas</h2>${bloco('cripto')}<h2 class="${H2} mt-8">Ações da B3</h2>${bloco('bolsa')}
 <h2 class="${H2} mt-8">Cadastrar nova fonte</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-2"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="nf_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Tipo</span><select id="nf_c" class="${INP} mt-1"><option value="cripto">Criptomoedas</option><option value="bolsa">Ações da B3</option></select></label>
 <label class="block md:col-span-2"><span class="text-xs text-ink-3">Endereço (use {SIMBOLO} e {chave})</span><input id="nf_u" class="${INP} mt-1" placeholder="https://api.exemplo.com/quote/{SIMBOLO}?key={chave}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input id="nf_f" class="${INP} mt-1" placeholder="data.price"></label><label class="block"><span class="text-xs text-ink-3">Chave (se precisar)</span><input id="nf_k" type="password" class="${INP} mt-1"></label>
 <div class="md:col-span-2"><button type="button" id="nf_add" class="${PRI} h-10">Cadastrar fonte</button></div></div></div>`;
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('market_providers',{items:mkItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 $('#nf_add',p).onclick=()=>put('market_providers',{items:[...mkItems(),{id:'c-'+Math.random().toString(36).slice(2,8),nome:$('#nf_n').value.trim(),cat:$('#nf_c').value,url:$('#nf_u').value.trim(),campo:$('#nf_f').value.trim(),key:$('#nf_k').value.trim(),ativo:true}]});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box;
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('market_providers',{items:mkItems(o=>o.id===id?{...o,key:f('key').value.trim(),...(f('url')?{url:f('url').value.trim(),campo:f('campo').value.trim()}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box);m.className='ma-ok';m.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'market',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message}catch(e){m.className='ma-err';m.textContent=e.message}};
 $('[data-up]',box).onclick=()=>{const it=mkItems(),i=it.findIndex(x=>x.id===id);let j=i-1;while(j>=0&&it[j].cat!==it[i].cat)j--;if(j<0)return;[it[i],it[j]]=[it[j],it[i]];put('market_providers',{items:it})};
 if($('[data-del]',box))$('[data-del]',box).onclick=()=>put('market_providers',{items:mkItems().filter(x=>x.id!==id)});
}
function pMP(p){const m=C.mercadopago.modo,c=C.mercadopago[m];
 p.innerHTML=`<div><h2 class="${H2}">Mercado Pago</h2><div class="glass no-scrollbar mb-4 flex w-fit gap-1 rounded-full p-1">${[['teste','Modo teste'],['producao','Produção']].map(([k,l])=>`<button type="button" data-m="${k}" class="flex h-9 items-center rounded-full px-4 text-[13px] font-semibold ${m===k?'btn-send':'text-ink-2'}">${l}</button>`).join('')}</div>
 <div class="glass rounded-[1.6rem] overflow-hidden"><div class="flex items-center gap-3 border-b border-line px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">Credenciais · ${m==='teste'?'Teste':'Produção'}</p><p class="mt-0.5 text-xs text-ink-3">Pegue em mercadopago.com.br/developers → Suas integrações → sua aplicação → Credenciais. Comece pelo modo teste.</p></div>${pill(c.tok.hasKey?'Salvas':'Não configurado',c.tok.hasKey?'ok':'warn')}</div>
 <div class="grid gap-3 px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Access Token ${c.tok.hasKey?'(salvo: '+esc(c.tok.keyMasked)+')':''}</span><input id="mp_tok" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${m==='teste'?'TEST-…':'APP_USR-…'}"></label>
 <label class="block"><span class="text-xs text-ink-3">Chave pública (opcional)</span><input id="mp_pub" class="${INP} mt-1" value="${esc(c.pub)}"><span class="mt-1 block text-[11.5px] text-ink-3">Só é usada para pagamento com cartão dentro do app. Para receber por Pix, basta o Access Token.</span></label>
 <label class="block"><span class="text-xs text-ink-3">Segredo dos webhooks ${c.seg.hasKey?'(salvo)':''}</span><input id="mp_seg" type="password" autocomplete="off" class="${INP} mt-1" placeholder="Opcional"></label>
 <label class="block"><span class="text-xs text-ink-3">Validade do Pix (minutos)</span><input id="mp_exp" inputmode="numeric" class="${INP} mt-1" value="${(C.pix||{}).expiraMin||30}"><span class="mt-1 block text-[11.5px] text-ink-3">Vale para anúncios, planos, agente e pedidos das lojas. Depois disso o cliente gera um novo Pix.</span></label><p class="ma-ok" id="mp_msg"></p><div class="flex flex-wrap gap-2"><button type="button" id="mp_s" class="${PRI} h-10">Salvar</button><button type="button" id="mp_t" class="${GHO} h-10">Testar conexão</button>${c.tok.hasKey?`<button type="button" id="mp_c" class="${DAN} h-10">Remover</button>`:''}</div></div></div>
 <div class="glass mt-4 rounded-[1.6rem] p-5"><p class="text-[15px] font-medium">URL de notificação (webhook)</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">${esc(C.webhookUrl)}</code><p class="mt-2 text-xs text-ink-3">O recebimento dos pagamentos entra na etapa de anúncios; as credenciais já ficam salvas e cifradas.</p></div></div>`;
 $$('[data-m]',p).forEach(b=>b.onclick=()=>put('mercadopago',{modo:b.dataset.m}));
 $('#mp_s',p).onclick=()=>put('mercadopago',{modo:m,[m]:{pub:$('#mp_pub').value.trim(),tok:$('#mp_tok').value.trim(),seg:$('#mp_seg').value.trim()}});
 if($('#mp_c',p))$('#mp_c',p).onclick=()=>put('mercadopago',{modo:m,[m]:{clear:true}});
 $('#mp_exp',p).onchange=e=>put('pix',{expiraMin:parseInt(e.target.value,10)||30});
 $('#mp_t',p).onclick=async()=>{const e=$('#mp_msg',p);e.className='ma-ok';e.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'mp',modo:m})});e.className=r.ok?'ma-ok':'ma-err';e.textContent=r.message}catch(x){e.className='ma-err';e.textContent=x.message}};
}
const NIVEL={1:'Anúncio',2:'Anúncio + contato',3:'Página da empresa',4:'Loja completa'};
function pPlanos(p){
 p.innerHTML=`<div><h2 class="${H2}">Planos de anúncio</h2>${card(C.ad_plans.map(k=>row(esc(k.nome)+' · '+brl(k.preco),k.dias+' dias · libera: '+NIVEL[k.nivel],`<button type="button" data-del="${esc(k.id)}" class="text-[13px] font-semibold text-danger">Remover</button>`)).join('')+`<div class="ma-kgrid px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="k_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input id="k_p" inputmode="decimal" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input id="k_d" inputmode="numeric" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Libera</span><select id="k_l" class="${INP} mt-1">${[1,2,3,4].map(n=>`<option value="${n}">${NIVEL[n]}</option>`).join('')}</select></label><button type="button" id="k_add" class="${PRI} h-10">Adicionar</button></div>`)}</div>`;
 $$('[data-del]',p).forEach(b=>b.onclick=()=>put('ad_plans',{items:C.ad_plans.filter(k=>k.id!==b.dataset.del)}));
 $('#k_add',p).onclick=()=>put('ad_plans',{items:[...C.ad_plans,{nome:$('#k_n').value.trim(),preco:parseFloat($('#k_p').value.replace(',','.')),dias:parseInt($('#k_d').value,10),nivel:+$('#k_l').value}]});
}
async function pBrain(p){
 const B=C.brain;
 p.innerHTML=`<div><h2 class="${H2}">Cérebro do chat</h2>${card(row('Aprender com as conversas','Guarda boas respostas das IAs para reutilizar.',sw('aprender',B.aprender,'Aprender'))+row('Responder pelo cérebro primeiro','Se já sabe a resposta, não chama nenhuma IA.',sw('cerebroPrimeiro',B.cerebroPrimeiro,'Cérebro primeiro'))+row('Guardar fatos sobre o usuário','“Meu nome é…”, “lembre que…”, preferências.',sw('fatos',B.fatos,'Fatos')))}
 <h2 class="${H2} mt-8">Respostas aprendidas</h2>
 <div class="glass rounded-[1.6rem] p-5">
  <div class="flex gap-2 mb-4"><input id="ba_q" class="${INP}" placeholder="Buscar pergunta ou resposta…" style="flex:1"><button type="button" id="ba_search" class="${GHO} h-10">Buscar</button></div>
  <div id="ba_list"><p class="text-sm text-ink-3">Carregando…</p></div>
 </div>
 <h2 class="${H2} mt-8">Busca de empresas e impostos</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-3"><label class="block"><span class="text-xs text-ink-3">Raio máximo da busca (km)</span><input id="s_r" class="${INP} mt-1" value="${C.search.raio}"></label><label class="block"><span class="text-xs text-ink-3">Salário mínimo (R$)</span><input id="f_sm" class="${INP} mt-1" value="${C.fiscal.sm}"></label><label class="block"><span class="text-xs text-ink-3">Limite anual do MEI (R$)</span><input id="f_l" class="${INP} mt-1" value="${C.fiscal.limite}"></label><div class="md:col-span-3"><button type="button" id="sf_s" class="${PRI} h-10">Salvar</button></div></div></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('brain',{[b.dataset.sw]:!B[b.dataset.sw]}));
 $('#sf_s',p).onclick=async()=>{if(await put('search',{raio:parseFloat($('#s_r').value.replace(',','.'))}))await put('fiscal',{sm:parseFloat($('#f_sm').value.replace(/\./g,'').replace(',','.'))})};
 const load=async(q='')=>{
  const el=$('#ba_list'); el.innerHTML='<p class="text-sm text-ink-3">Carregando…</p>';
  try{
   const j=await api('/api/panel/brain/answers?q='+encodeURIComponent(q));
   if(!j.answers.length){el.innerHTML='<p class="text-sm text-ink-3">Nenhuma resposta aprendida ainda.</p>';return}
   el.innerHTML=j.answers.map(a=>`<div class="border-b border-line py-3 last:border-0" data-id="${a.id}">
    <div class="flex items-start gap-3">
     <div class="min-w-0 flex-1">
      <p class="text-[14px] font-medium">${esc(a.question)}</p>
      <p class="mt-1 text-[13px] text-ink-2 whitespace-pre-wrap">${esc(a.answer)}</p>
      <p class="mt-1 text-[11px] text-ink-3">${a.uses} usos · score ${a.score.toFixed(2)} · ${a.origin} · ${a.userId?'usuário '+a.userId:'global'}</p>
     </div>
     <div class="flex flex-col gap-1 shrink-0">
      <button type="button" class="ba-edit text-[12px] font-semibold text-accent">Editar</button>
      <button type="button" class="ba-del text-[12px] font-semibold text-danger">Excluir</button>
     </div>
    </div>
   </div>`).join('');
   $$('.ba-edit',el).forEach(b=>b.onclick=async()=>{
    const id=b.closest('[data-id]').dataset.id, a=j.answers.find(x=>String(x.id)===id);
    const nq=prompt('Pergunta:',a.question); if(nq===null)return;
    const na=prompt('Resposta:',a.answer); if(na===null)return;
    try{await api('/api/panel/brain/answers/'+id,{method:'PUT',body:JSON.stringify({question:nq,answer:na})});toast('Atualizado');load(q)}catch(e){toast(e.message)}
   });
   $$('.ba-del',el).forEach(b=>b.onclick=async()=>{
    if(!confirm('Excluir esta resposta aprendida?'))return;
    const id=b.closest('[data-id]').dataset.id;
    try{await api('/api/panel/brain/answers/'+id,{method:'DELETE'});toast('Excluído');load(q)}catch(e){toast(e.message)}
   });
  }catch(e){el.innerHTML=`<p class="text-sm text-danger">${esc(e.message)}</p>`}
 };
 $('#ba_search',p).onclick=()=>load($('#ba_q').value.trim());
 $('#ba_q',p).onkeydown=e=>{if(e.key==='Enter')load($('#ba_q').value.trim())};
 load();
}


function pChatWelcome(p){
  const W = C.chat_welcome || {ativo:true,saudacao:'Olá, {nome}!',titulo:'Fale comigo.',subtitulo:'Eu organizo o resto.'};
  p.innerHTML = `<div><h2 class="${H2}">Tela inicial do chat</h2>
  ${card(
    row('Mostrar textos de boas-vindas','Desligue para esconder a saudação e os títulos.',sw('ativo',W.ativo,'Ativo')) +
    row('Saudação','Use {nome} para o nome do usuário.','') +
    `<div class="px-5 pb-4"><input id="cw_s" class="${INP}" value="${esc(W.saudacao)}" placeholder="Olá, {nome}!"></div>` +
    row('Título principal','','') +
    `<div class="px-5 pb-4"><input id="cw_t" class="${INP}" value="${esc(W.titulo)}" placeholder="Fale comigo."></div>` +
    row('Subtítulo','','') +
    `<div class="px-5 pb-4"><input id="cw_sub" class="${INP}" value="${esc(W.subtitulo)}" placeholder="Eu organizo o resto."></div>` +
    `<div class="px-5 pb-4"><button type="button" id="cw_save" class="${PRI} h-10">Salvar</button></div>`
  )}
  <p class="mt-3 px-1 text-xs text-ink-3">As alterações aparecem na tela inicial do chat (quando não há conversa aberta).</p></div>`;
  $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('chat_welcome',{[b.dataset.sw]:!W[b.dataset.sw]}));
  $('#cw_save',p).onclick=()=>put('chat_welcome',{
    ativo: W.ativo,
    saudacao: $('#cw_s').value.trim() || 'Olá, {nome}!',
    titulo: $('#cw_t').value.trim() || 'Fale comigo.',
    subtitulo: $('#cw_sub').value.trim() || 'Eu organizo o resto.'
  });
}

const TAB_ON='btn-send',TAB_OFF=['text-ink-2','hover:text-ink'];
let bar=null,loading=false;
function findBar(){return [...document.querySelectorAll('div.glass.no-scrollbar')].find(d=>[...d.querySelectorAll('button')].some(b=>b.textContent.trim()==='Usuários'))}
function reactContent(){const out=[];let n=bar&&bar.nextElementSibling;while(n){if(n.id!=='ma-admin-pane')out.push(n);n=n.nextElementSibling}return out}
async function activate(k){
 tab=k;open='';
 if(!C){try{loading=true;C=await api('/api/panel')}catch(e){toast(e.message);loading=false;return}loading=false}
 [...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON,...TAB_OFF);if(b.dataset.maTab===k)b.classList.add(TAB_ON);else b.classList.add(...TAB_OFF)}else{if(b.dataset.maWasOn===undefined)b.dataset.maWasOn=b.classList.contains(TAB_ON)?'1':'0';b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}});
 reactContent().forEach(n=>n.style.display='none');
 if(!HOST){HOST=document.createElement('section');HOST.id='ma-admin-pane';HOST.className='grid gap-4';}
 if(HOST.previousElementSibling!==bar)bar.after(HOST);
 HOST.style.display='';render();
}
function deactivate(){tab='';if(HOST)HOST.style.display='none';reactContent().forEach(n=>n.style.display='');if(bar)[...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}else if(b.dataset.maWasOn!==undefined){if(b.dataset.maWasOn==='1'){b.classList.add(TAB_ON);b.classList.remove(...TAB_OFF)}delete b.dataset.maWasOn}})}
function inject(){
 if(!location.pathname.startsWith('/admin'))return;
 ensureBase();
 const b=findBar();if(!b)return;
 if(b!==bar){bar=b;HOST=null}
 [...bar.querySelectorAll('button:not([data-ma-tab])')].forEach(b=>{if(/An[uú]ncios e Parceiros|Planos e assinaturas|Cérebro do Chat|Base de Conhecimento/.test(b.textContent))b.style.display='none'});
 if(bar.querySelector('[data-ma-tab]'))return;
 const sample=[...bar.querySelectorAll('button')].find(x=>!x.classList.contains(TAB_ON))||bar.querySelector('button');
 TABS.forEach(([k,l])=>{const nb=document.createElement('button');nb.type='button';nb.dataset.maTab=k;nb.className=(sample?sample.className:'flex h-9 shrink-0 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold transition').replace(/\bbtn-send\b/g,'')+' text-ink-2 hover:text-ink';nb.textContent=l;nb.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();activate(k)});bar.appendChild(nb)});
 bar.addEventListener('click',e=>{const t=e.target.closest('button');if(t&&!t.dataset.maTab&&tab)deactivate()},true);
 const want=new URLSearchParams(location.search).get('aba');if(want&&TABS.some(t=>t[0]===want)){history.replaceState(history.state,'',location.pathname);setTimeout(()=>activate(want),50)}
}
new MutationObserver(()=>inject()).observe(document.body,{childList:true,subtree:true});
setInterval(()=>{if(tab&&C&&tab==='ia'&&!open&&HOST&&HOST.isConnected)api('/api/panel').then(x=>{C=x;render()}).catch(()=>{})},15000);
inject();
})();
