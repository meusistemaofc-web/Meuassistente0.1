/* Meu Assistente · novas abas dentro do painel administrativo original (/admin). */
(function(){
if(window.__maPanelAddon)return;window.__maPanelAddon=true;
const STYLE=`
.ma-err{color:var(--nx-danger);font-size:13.5px;margin-top:8px}.ma-err:empty{display:none}.ma-ok{color:var(--nx-success);font-size:13.5px;margin-top:8px}.ma-ok:empty{display:none}
.ma-pill{border-color:var(--nx-line-strong);color:var(--nx-ink-2)}.ma-pill.ok{color:var(--nx-success);border-color:color-mix(in srgb,var(--nx-success) 40%,transparent)}
.ma-pill.warn{color:#f0b54a;border-color:rgba(240,181,74,.4)}.ma-pill.bad{color:var(--nx-danger);border-color:color-mix(in srgb,var(--nx-danger) 40%,transparent)}
main section.grid{grid-template-columns:minmax(0,1fr)}
#toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:200;background:var(--nx-ink);color:var(--nx-canvas);padding:11px 18px;border-radius:999px;font-size:14px;max-width:90vw;text-align:center}#toast[hidden]{display:none}
.ma-kgrid{display:grid;gap:12px}@media (min-width:48rem){.ma-kgrid{grid-template-columns:1fr 7rem 5rem 11rem auto;align-items:end}}
`;
function ensureBase(){if(!document.getElementById('ma-addon-style')){const st=document.createElement('style');st.id='ma-addon-style';st.textContent=STYLE;document.head.appendChild(st)}
 if(!document.getElementById('toast')){const t=document.createElement('div');t.id='toast';t.setAttribute('role','status');t.hidden=true;document.body.appendChild(t)}}
ensureBase();

const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const BTN='inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 ';
const PRI=BTN+'btn-send hover:brightness-110',GHO=BTN+'border border-line-strong text-ink hover:bg-surface-2',DAN=BTN+'border border-line-strong text-danger hover:bg-surface-2';
const INP='h-10 w-full rounded-xl border border-line bg-surface-2/60 px-3 text-[14px] tabular text-ink outline-none focus:border-accent/60';
const H2='mb-3 px-1 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3';
const card=i=>`<div class="glass rounded-[1.6rem] overflow-hidden"><div class="divide-y divide-line">${i}</div></div>`;
const row=(t,d,r)=>`<div class="flex items-center gap-4 px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${t}</p>${d?`<p class="mt-0.5 text-xs text-ink-3">${d}</p>`:''}</div>${r||''}</div>`;
const sw=(id,on,l)=>`<button type="button" role="switch" aria-checked="${!!on}" aria-label="${esc(l)}" data-sw="${id}" class="nx-switch"><span class="nx-switch-knob"></span></button>`;
const pill=(t,k)=>`<span class="ma-pill ${k||''} shrink-0 rounded-full border px-3 py-1 text-xs font-semibold">${t}</span>`;
let tt;function toast(m){ensureBase();const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3500)}
let C=null,tab='',open='',HOST=null;
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opts});let j={};try{j=await r.json()}catch(e){}
 if(!r.ok)throw new Error(j.error||('Erro '+r.status));return j}
async function put(key,body){try{C=await api('/api/panel/'+key,{method:'PUT',body:JSON.stringify(body)});render();toast('Salvo');return true}catch(e){toast(e.message);return false}}
const TABS=[['anuncios','Anúncios'],['biblioteca','Biblioteca SOS'],['links','Páginas e links'],['botoes','Botões do chat'],['modulos','Módulos'],['ia','IA'],['fontes','Fontes de mercado'],['mp','Mercado Pago'],['planos','Planos de anúncio'],['cerebro','Cérebro e busca']];
function render(){if(!HOST||!C)return;const p=HOST;({anuncios:pAds,biblioteca:pKb,links:pLinks,botoes:pBotoes,modulos:pMod,ia:pIA,fontes:pFontes,mp:pMP,planos:pPlanos,cerebro:pBrain})[tab](p);
 if(!C.canWrite)$$('button,input,select',p).forEach(x=>{x.disabled=true});}

const STA={analise:['Em análise','warn'],ajustes:['Ajustes pedidos','warn'],recusado:['Recusado','bad'],aprovado:['Aguardando pagamento',''],ativo:['No ar','ok'],encerrado:['Encerrado','']};
async function pAds(p){
 p.innerHTML='<p class="text-sm text-ink-3">Carregando anúncios…</p>';
 let L;try{L=await api('/api/v2/admin/ads')}catch(e){p.innerHTML=`<div class="glass rounded-[1.6rem] p-5 text-sm text-ink-2">${esc(e.message)}</div>`;return}
 const box=it=>{const st=STA[it.status]||[it.status,''];return `<div class="px-5 py-4"><div class="flex items-start gap-3">${it.logo?`<img src="${it.logo}" alt="" style="width:46px;height:46px;border-radius:.8rem;object-fit:cover">`:''}<div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${esc(it.empresa)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(it.categoria||'')} · ${it.plan?esc(it.plan.nome)+' · '+brl(it.plan.preco):''} · ${esc(it.owner.name)} (${esc(it.owner.email)})</p><p class="mt-0.5 text-xs text-ink-3">${esc(it.protocolo)}${it.expiresAt&&it.status==='ativo'?' · até '+new Date(it.expiresAt).toLocaleDateString('pt-BR'):''}</p></div>${pill(st[0],st[1])}</div>
  <p class="mt-2 text-[13.5px]"><b>${esc(it.titulo||'')}</b> ${esc(it.texto||'')}</p>${it.zap||it.insta?`<p class="mt-1 text-xs text-ink-3">${it.zap?'WhatsApp '+esc(it.zap):''} ${it.insta?'· @'+esc(it.insta):''}</p>`:''}${it.endereco?`<p class="mt-1 text-xs text-ink-3">${esc(it.endereco)} ${it.horario?'· '+esc(it.horario):''}</p>`:''}${it.motivo?`<p class="mt-1 text-xs text-danger">${esc(it.motivo)}</p>`:''}
  <div class="mt-3 flex flex-wrap gap-2" data-id="${it.id}">${['analise','ajustes'].includes(it.status)?`<button type="button" data-act="approve" class="${PRI} h-10">Aprovar</button><button type="button" data-act="adjust" class="${GHO} h-10">Pedir ajustes</button><button type="button" data-act="reject" class="${DAN} h-10">Recusar</button>`:''}${it.status==='aprovado'?`<button type="button" data-act="activate" class="${GHO} h-10">Marcar como pago e pôr no ar</button>`:''}${it.status==='ativo'?`<button type="button" data-act="end" class="${DAN} h-10">Encerrar</button>`:''}</div>
  <div data-mot="${it.id}" class="mt-2 hidden"><input class="${INP}" placeholder="Motivo (a empresa vê)"><div class="mt-2 flex gap-2"><button type="button" data-send class="${PRI} h-10">Enviar</button><button type="button" data-cancel class="${GHO} h-10">Voltar</button></div></div></div>`};
 const pend=L.items.filter(i=>['analise','ajustes'].includes(i.status)),outros=L.items.filter(i=>!['analise','ajustes'].includes(i.status));
 p.innerHTML=`<div><h2 class="${H2}">Aguardando análise (${pend.length})</h2>${card(pend.map(box).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhuma proposta pendente.</div>')}<h2 class="${H2} mt-8">Todos os anúncios</h2>${card(outros.map(box).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhum anúncio ainda.</div>')}<p class="mt-3 px-1 text-xs text-ink-3">Os planos e preços ficam na aba Planos de anúncio; o recebimento por Pix usa as credenciais da aba Mercado Pago.</p></div>`;
 const send=async(id,action,motivo)=>{try{await api('/api/v2/admin/ads/'+id,{method:'POST',body:JSON.stringify({action,motivo})});toast('Feito. A empresa foi avisada.');pAds(p)}catch(e){toast(e.message)}};
 $$('[data-act]',p).forEach(b=>b.onclick=()=>{const id=b.parentElement.dataset.id,a=b.dataset.act;if(a==='adjust'||a==='reject'){const m=$(`[data-mot="${id}"]`,p);m.classList.remove('hidden');m.dataset.a=a;$('input',m).focus();$('[data-send]',m).onclick=()=>{const v=$('input',m).value.trim();if(!v)return toast('Informe o motivo.');send(id,m.dataset.a,v)};$('[data-cancel]',m).onclick=()=>m.classList.add('hidden')}else send(id,a)});
}


async function share(url,title){try{if(navigator.share){await navigator.share({title,url});return}}catch(e){if(e&&e.name==='AbortError')return}try{await navigator.clipboard.writeText(url);toast('Link copiado')}catch(e){prompt('Copie o link:',url)}}
function pLinks(p){const base=location.origin;const L=[['Apresentação do Meu Assistente','Página pública para conhecer o app e criar conta.','/conheca'],['Criar anúncio','Para empresas anunciarem (pede login).','/x/anunciar'],['Empresas perto de você','Lista de parceiros por localização (pede login).','/x/empresas']];
 p.innerHTML=`<div><h2 class="${H2}">Páginas e links para compartilhar</h2>${card(L.map(([t,d,path],i)=>`<div class="px-5 py-4"><p class="text-[15px] font-medium">${t}</p><p class="mt-0.5 text-xs text-ink-3">${d}</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">${esc(base+path)}</code><div class="mt-2 flex flex-wrap gap-2"><button type="button" data-cp="${i}" class="${GHO} h-10">Copiar link</button><button type="button" data-sh="${i}" class="${PRI} h-10">Compartilhar</button><a href="${esc(path)}" class="${GHO} h-10">Abrir</a></div></div>`).join(''))}
 <p class="mt-3 px-1 text-xs text-ink-3">Cada empresa com plano Página ou Loja tem o próprio link, que o dono copia em Sua empresa. Os planos de assinatura do próprio Meu Assistente (para usuários) ainda serão ligados ao Mercado Pago numa próxima etapa.</p></div>`;
 $$('[data-cp]',p).forEach(b=>b.onclick=async()=>{const u=base+L[+b.dataset.cp][2];try{await navigator.clipboard.writeText(u);toast('Link copiado')}catch(e){prompt('Copie o link:',u)}});
 $$('[data-sh]',p).forEach(b=>b.onclick=()=>share(base+L[+b.dataset.sh][2],L[+b.dataset.sh][0]));}
function pBotoes(p){const Q=C.quick_buttons;let items=Q.items.slice();
 const draw=()=>{p.innerHTML=`<div><h2 class="${H2}">Botões rápidos do chat</h2>${card(row('Mostrar botões rápidos','Sugestões na tela inicial do chat.',sw('qb',Q.enabled,'Mostrar botões rápidos'))+row('Usar a minha lista','Desligado: usa os botões originais do app.',sw('qc',Q.custom,'Usar a minha lista')))}
 <h2 class="${H2} mt-8">Sua lista (até 8)</h2>${card(items.map((t,i)=>`<div class="flex items-center gap-2 px-5 py-3"><input data-it="${i}" class="${INP}" value="${esc(t)}"><button type="button" data-up="${i}" class="${GHO} h-10 shrink-0" ${i?'':'disabled'}>↑</button><button type="button" data-rm="${i}" class="${DAN} h-10 shrink-0">×</button></div>`).join('')+(items.length<8?`<div class="px-5 py-3"><button type="button" id="qadd" class="${GHO} h-10">+ Novo botão</button></div>`:''))}
 <div class="mt-3"><button type="button" id="qsave" class="${PRI} h-10">Salvar botões</button></div><p class="mt-2 px-1 text-xs text-ink-3">Ao tocar, o botão envia o texto para o assistente, como se o usuário tivesse digitado.</p></div>`;
  const read=()=>{items=$$('[data-it]',p).map(i=>i.value.trim())};
  $$('[data-sw]',p).forEach(b=>b.onclick=()=>{read();if(b.dataset.sw==='qb')Q.enabled=!Q.enabled;else Q.custom=!Q.custom;draw()});
  $$('[data-rm]',p).forEach(b=>b.onclick=()=>{read();items.splice(+b.dataset.rm,1);draw()});
  $$('[data-up]',p).forEach(b=>b.onclick=()=>{read();const i=+b.dataset.up;[items[i-1],items[i]]=[items[i],items[i-1]];draw()});
  if($('#qadd',p))$('#qadd',p).onclick=()=>{read();items.push('');draw();const l=$$('[data-it]',p).pop();if(l)l.focus()};
  $('#qsave',p).onclick=()=>{read();put('quick_buttons',{enabled:Q.enabled,custom:Q.custom,items:items.filter(Boolean)})};};draw()}


async function pKb(p,edit){
 p.innerHTML='<p class="text-sm text-ink-3">Carregando materiais…</p>';
 let L;try{L=await api('/api/v2/admin/kb')}catch(e){p.innerHTML=`<div class="glass rounded-[1.6rem] p-5 text-sm text-ink-2">${esc(e.message)}</div>`;return}
 const ed=edit?L.items.find(x=>x.id===edit):null;
 p.innerHTML=`<div><h2 class="${H2}">Biblioteca de Sobrevivência</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">Os materiais ativos são <b class="text-ink">baixados automaticamente</b> pelo app quando ele abre com internet e ficam disponíveis <b class="text-ink">mesmo sem conexão</b>, na Central SOS e no chat.</div>
 ${card(L.items.map(d=>`<div class="px-5 py-4"><div class="flex items-start gap-3"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${esc(d.title)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(d.description||'')} · ${d.chunks} trecho(s) · versão ${d.version}${d.sos?' · Central SOS':''}</p></div>${pill(d.active?'Disponível':'Oculto',d.active?'ok':'')}</div><div class="mt-2 flex flex-wrap gap-3 text-[13px] font-semibold"><button type="button" data-ke="${d.id}" class="text-ink-2">Editar</button><button type="button" data-kt="${d.id}" class="text-ink-2">${d.active?'Ocultar':'Mostrar'}</button><button type="button" data-kd="${d.id}" class="text-danger">Excluir</button></div></div>`).join('')||'<div class="px-5 py-5 text-sm text-ink-3">Nenhum material cadastrado.</div>')}
 <h2 class="${H2} mt-8">${ed?'Editar material':'Cadastrar novo material'}</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5">
 <label class="block"><span class="text-xs text-ink-3">Título</span><input id="kt" class="${INP} mt-1" value="${esc(ed?ed.title:'')}" placeholder="Ex.: Abrigo no frio"></label>
 <label class="block"><span class="text-xs text-ink-3">Descrição curta</span><input id="kds" class="${INP} mt-1" value="${esc(ed?ed.description:'')}"></label>
 <label class="block"><span class="text-xs text-ink-3">Palavras-chave (separadas por vírgula)</span><input id="kk" class="${INP} mt-1" value="${esc(ed?ed.keywords.join(', '):'')}" placeholder="frio, abrigo, hipotermia"></label>
 <div class="flex items-center justify-between gap-3"><span class="text-[14px]">Mostrar na Central SOS</span>${sw('ksos',ed?ed.sos:true,'Central SOS')}</div>
 <label class="block"><span class="text-xs text-ink-3">Conteúdo. Use linhas começando com # para os títulos das seções.</span><textarea id="kc" rows="12" class="${INP} mt-1" style="height:auto;padding-top:10px;font-size:13.5px">${esc(ed?ed.content:'')}</textarea></label>
 <label class="block"><span class="text-xs text-ink-3">Ou envie um arquivo de texto (.txt ou .md)</span><input id="kf" type="file" accept=".txt,.md,text/plain,text/markdown" class="${INP} mt-1" style="height:auto;padding-top:8px"></label>
 <p class="ma-err" id="kerr"></p><div class="flex flex-wrap gap-2"><button type="button" id="ks" class="${PRI} h-10">${ed?'Salvar alterações':'Cadastrar material'}</button>${ed?`<button type="button" id="kx" class="${GHO} h-10">Cancelar</button>`:''}</div>
 <p class="text-xs text-ink-3">Revise sempre o conteúdo: em temas de saúde e segurança, oriente a procurar o 192, 193 ou a Defesa Civil (199).</p></div></div>`;
 let sos=ed?ed.sos:true;
 $('[data-sw="ksos"]',p).onclick=e=>{sos=!sos;e.currentTarget.setAttribute('aria-checked',sos)};
 $('#kf',p).onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>2e6)return toast('Arquivo muito grande (máx. 2 MB).');const r=new FileReader();r.onload=()=>{$('#kc',p).value=r.result;if(!$('#kt',p).value)$('#kt',p).value=f.name.replace(/\.[^.]+$/,'')};r.readAsText(f,'utf-8')};
 $('#ks',p).onclick=async()=>{try{await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({id:ed&&ed.id,title:$('#kt',p).value.trim(),description:$('#kds',p).value.trim(),keywords:$('#kk',p).value,sos,content:$('#kc',p).value})});toast('Material salvo. Os aparelhos baixam a nova versão sozinhos.');pKb(p)}catch(x){$('#kerr',p).textContent=x.message}};
 if($('#kx',p))$('#kx',p).onclick=()=>pKb(p);
 $$('[data-ke]',p).forEach(b=>b.onclick=()=>pKb(p,+b.dataset.ke));
 $$('[data-kt]',p).forEach(b=>b.onclick=async()=>{await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({action:'toggle',id:+b.dataset.kt})});pKb(p)});
 $$('[data-kd]',p).forEach(b=>b.onclick=async()=>{if(!confirm('Excluir este material de todos os aparelhos?'))return;await api('/api/v2/admin/kb',{method:'POST',body:JSON.stringify({action:'delete',id:+b.dataset.kd})});pKb(p)});
}

const MODS=[['catalogo','Lojas e pedidos','Catálogo e pedidos das empresas com plano Loja completa.'],['anuncios','Anúncios','Cartões patrocinados no chat e página Anunciar.'],['financas','Finanças','Gastos, contas e vencimentos.'],['lembretes','Lembretes','Avisos e compromissos.'],['imagens','Fotos e arquivos','Envio de imagens e comprovantes no chat.'],['voz','Voz do assistente','Mensagens de voz e Modo Voz (oculta os botões de voz para todos).'],['sugestoes','Botões rápidos do chat','Sugestões que aparecem na tela inicial do chat.'],['empresas','Empresas perto de você','Busca de empresas no chat e no menu.'],['fiscal','Impostos e DAS','DAS do MEI, limite e declarações.'],['mercado','Mercado','Cotações de cripto e bolsa, com alertas.']];
function pMod(p){p.innerHTML=`<div><h2 class="${H2}">Módulos globais</h2>${card(MODS.map(([k,n,d])=>row(n,d,sw(k,C.modules[k],n))).join(''))}<p class="mt-3 px-1 text-xs text-ink-3">Um módulo desligado some para todos os usuários conforme cada módulo for ligado ao servidor.</p></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('modules',{[b.dataset.sw]:!C.modules[b.dataset.sw]}))}
function provState(pv,rt){const pz=rt&&rt.paused&&rt.paused[pv.id];if(!pv.ativo)return['Desligada',''];if(pv.id!=='servidor'&&!pv.hasKey)return['Sem chave',''];if(pz&&pz.expired)return['Chave recusada','bad'];if(pz&&pz.seconds>0)return['Pausada · volta em '+pz.seconds+'s','warn'];return['Pronta','ok']}
function aiItems(mod){return C.ai_providers.map(x=>{const o={id:x.id,nome:x.nome,base_url:x.base_url,modelo:x.modelo,texto:x.texto,imagem:x.imagem,ativo:x.ativo};return mod?mod(o)||o:o})}
function pIA(p){const st=C.ai_runtime.stats||{};
 p.innerHTML=`<div><h2 class="${H2}">Inteligências artificiais</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira IA <b class="text-ink">pronta</b> da lista responde no chat. Se ela atingir o limite, tiver a chave recusada ou falhar, a próxima assume na hora. Deixe a <b class="text-ink">IA do servidor</b> (Ollama da VPS) por último: ela não tem limite.</div>
 ${card(C.ai_providers.map((pv,i)=>{const [s,k]=provState(pv,C.ai_runtime),o=open===pv.id,ss=st[pv.id]||{uses:0,failures:0};
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium"><span class="tabular text-ink-3">${i+1}.</span> ${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${pv.texto?'Texto':''}${pv.texto&&pv.imagem?' e ':''}${pv.imagem?'imagens':''} · ${ss.uses} respostas · ${ss.failures} falhas</p></button>${pill(s,k)}${sw('a:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><p class="text-xs text-ink-3">${esc(pv.onde)}</p>
   ${pv.id!=='servidor'?`<label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':''}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave aqui'}"></label>
   <label class="block"><span class="text-xs text-ink-3">Endereço da API</span><input data-f="base_url" class="${INP} mt-1" value="${esc(pv.base_url)}" placeholder="https://…/v1"></label>
   <label class="block"><span class="text-xs text-ink-3">Modelo</span><input data-f="modelo" class="${INP} mt-1" value="${esc(pv.modelo)}" placeholder="Nome do modelo no serviço"></label>`:`<p class="text-xs text-ink-3">Configurada no arquivo .env da VPS (AI_BASE_URL e AI_MODEL).</p>`}
   <div class="flex flex-wrap gap-2"><button type="button" data-cap="texto" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${pv.texto?'btn-send':'border border-line-strong text-ink-2'}">Texto</button><button type="button" data-cap="imagem" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${pv.imagem?'btn-send':'border border-line-strong text-ink-2'}">Ler imagens</button></div>
   ${ss.lastError?`<p class="text-xs text-danger">Último erro: ${esc(ss.lastError)}</p>`:''}<p class="ma-ok" data-msg></p>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10" ${i===0?'disabled':''}>Subir</button><button type="button" data-down class="${GHO} h-10" ${i===C.ai_providers.length-1?'disabled':''}>Descer</button>${provState(pv,C.ai_runtime)[1]==='bad'||provState(pv,C.ai_runtime)[1]==='warn'?`<button type="button" data-resume class="${GHO} h-10">Reativar</button>`:''}${pv.hasKey?`<button type="button" data-clear class="${DAN} h-10">Remover chave</button>`:''}</div></div>`:''}</div>`}).join(''))}
 <p class="mt-3 px-1 text-xs text-ink-3">Toque no nome de uma IA para colar a chave, escolher o modelo, testar e mudar a ordem.</p></div>`;
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box,i=C.ai_providers.findIndex(x=>x.id===id);
 $$('[data-cap]',box).forEach(b=>b.onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,[b.dataset.cap]:!o[b.dataset.cap]}:o)}));
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,...(f('base_url')?{base_url:f('base_url').value.trim(),modelo:f('modelo').value.trim(),key:f('key').value.trim()}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box);m.className='ma-ok';m.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'ai',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message}catch(e){m.className='ma-err';m.textContent=e.message}};
 const mv=d=>{const it=aiItems(),j=i+d;[it[i],it[j]]=[it[j],it[i]];put('ai_providers',{items:it})};
 if($('[data-up]',box))$('[data-up]',box).onclick=()=>mv(-1);if($('[data-down]',box))$('[data-down]',box).onclick=()=>mv(1);
 if($('[data-resume]',box))$('[data-resume]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,resume:true}:o)});
 if($('[data-clear]',box))$('[data-clear]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,clearKey:true}:o)});
}
function mkItems(mod){return C.market_providers.map(x=>{const o={id:x.id,nome:x.nome,cat:x.cat,url:x.url,campo:x.campo,ativo:x.ativo};return mod?mod(o)||o:o})}
function pFontes(p){const st=C.market_status||{};
 const bloco=cat=>card(C.market_providers.filter(x=>x.cat===cat).map(pv=>{const ss=st[pv.id]||{uses:0,failures:0},s=!pv.ativo?['Desligada','']:pv.precisaChave&&!pv.hasKey?['Sem chave','']:['Pronta','ok'],o=open===pv.id;
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium">${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(pv.info)} · ${ss.uses} consultas · ${ss.failures} falhas</p></button>${pill(s[0],s[1])}${sw('m:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':pv.precisaChave?'':'(opcional)'}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave'}"></label>
   ${pv.custom?`<label class="block"><span class="text-xs text-ink-3">Endereço</span><input data-f="url" class="${INP} mt-1" value="${esc(pv.url)}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input data-f="campo" class="${INP} mt-1" value="${esc(pv.campo)}"></label>`:''}
   ${ss.lastError?`<p class="text-xs text-danger">Último erro: ${esc(ss.lastError)}</p>`:''}<p class="ma-ok" data-msg></p>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10">Subir</button>${pv.custom?`<button type="button" data-del class="${DAN} h-10">Excluir</button>`:''}</div></div>`:''}</div>`}).join(''));
 p.innerHTML=`<div><h2 class="${H2}">Fontes de mercado</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira fonte <b class="text-ink">pronta</b> de cada lista é usada. Se falhar ou atingir o limite, a próxima assume. As cotações ficam guardadas por 1 minuto para economizar o limite.</div>
 <h2 class="${H2}">Criptomoedas</h2>${bloco('cripto')}<h2 class="${H2} mt-8">Ações da B3</h2>${bloco('bolsa')}
 <h2 class="${H2} mt-8">Cadastrar nova fonte</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-2"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="nf_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Tipo</span><select id="nf_c" class="${INP} mt-1"><option value="cripto">Criptomoedas</option><option value="bolsa">Ações da B3</option></select></label>
 <label class="block md:col-span-2"><span class="text-xs text-ink-3">Endereço (use {SIMBOLO} e {chave})</span><input id="nf_u" class="${INP} mt-1" placeholder="https://api.exemplo.com/quote/{SIMBOLO}?key={chave}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input id="nf_f" class="${INP} mt-1" placeholder="data.price"></label><label class="block"><span class="text-xs text-ink-3">Chave (se precisar)</span><input id="nf_k" type="password" class="${INP} mt-1"></label>
 <div class="md:col-span-2"><button type="button" id="nf_add" class="${PRI} h-10">Cadastrar fonte</button></div></div></div>`;
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('market_providers',{items:mkItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 $('#nf_add',p).onclick=()=>put('market_providers',{items:[...mkItems(),{id:'c-'+Math.random().toString(36).slice(2,8),nome:$('#nf_n').value.trim(),cat:$('#nf_c').value,url:$('#nf_u').value.trim(),campo:$('#nf_f').value.trim(),key:$('#nf_k').value.trim(),ativo:true}]});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box;
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('market_providers',{items:mkItems(o=>o.id===id?{...o,key:f('key').value.trim(),...(f('url')?{url:f('url').value.trim(),campo:f('campo').value.trim()}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box);m.className='ma-ok';m.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'market',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message}catch(e){m.className='ma-err';m.textContent=e.message}};
 $('[data-up]',box).onclick=()=>{const it=mkItems(),i=it.findIndex(x=>x.id===id);let j=i-1;while(j>=0&&it[j].cat!==it[i].cat)j--;if(j<0)return;[it[i],it[j]]=[it[j],it[i]];put('market_providers',{items:it})};
 if($('[data-del]',box))$('[data-del]',box).onclick=()=>put('market_providers',{items:mkItems().filter(x=>x.id!==id)});
}
function pMP(p){const m=C.mercadopago.modo,c=C.mercadopago[m];
 p.innerHTML=`<div><h2 class="${H2}">Mercado Pago</h2><div class="glass no-scrollbar mb-4 flex w-fit gap-1 rounded-full p-1">${[['teste','Modo teste'],['producao','Produção']].map(([k,l])=>`<button type="button" data-m="${k}" class="flex h-9 items-center rounded-full px-4 text-[13px] font-semibold ${m===k?'btn-send':'text-ink-2'}">${l}</button>`).join('')}</div>
 <div class="glass rounded-[1.6rem] overflow-hidden"><div class="flex items-center gap-3 border-b border-line px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">Credenciais · ${m==='teste'?'Teste':'Produção'}</p><p class="mt-0.5 text-xs text-ink-3">Pegue em mercadopago.com.br/developers → Suas integrações → sua aplicação → Credenciais. Comece pelo modo teste.</p></div>${pill(c.tok.hasKey?'Salvas':'Não configurado',c.tok.hasKey?'ok':'warn')}</div>
 <div class="grid gap-3 px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Access Token ${c.tok.hasKey?'(salvo: '+esc(c.tok.keyMasked)+')':''}</span><input id="mp_tok" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${m==='teste'?'TEST-…':'APP_USR-…'}"></label>
 <label class="block"><span class="text-xs text-ink-3">Chave pública (opcional)</span><input id="mp_pub" class="${INP} mt-1" value="${esc(c.pub)}"><span class="mt-1 block text-[11.5px] text-ink-3">Só é usada para pagamento com cartão dentro do app. Para receber por Pix, basta o Access Token.</span></label>
 <label class="block"><span class="text-xs text-ink-3">Segredo dos webhooks ${c.seg.hasKey?'(salvo)':''}</span><input id="mp_seg" type="password" autocomplete="off" class="${INP} mt-1" placeholder="Opcional"></label>
 <p class="ma-ok" id="mp_msg"></p><div class="flex flex-wrap gap-2"><button type="button" id="mp_s" class="${PRI} h-10">Salvar</button><button type="button" id="mp_t" class="${GHO} h-10">Testar conexão</button>${c.tok.hasKey?`<button type="button" id="mp_c" class="${DAN} h-10">Remover</button>`:''}</div></div></div>
 <div class="glass mt-4 rounded-[1.6rem] p-5"><p class="text-[15px] font-medium">URL de notificação (webhook)</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">${esc(C.webhookUrl)}</code><p class="mt-2 text-xs text-ink-3">O recebimento dos pagamentos entra na etapa de anúncios; as credenciais já ficam salvas e cifradas.</p></div></div>`;
 $$('[data-m]',p).forEach(b=>b.onclick=()=>put('mercadopago',{modo:b.dataset.m}));
 $('#mp_s',p).onclick=()=>put('mercadopago',{modo:m,[m]:{pub:$('#mp_pub').value.trim(),tok:$('#mp_tok').value.trim(),seg:$('#mp_seg').value.trim()}});
 if($('#mp_c',p))$('#mp_c',p).onclick=()=>put('mercadopago',{modo:m,[m]:{clear:true}});
 $('#mp_t',p).onclick=async()=>{const e=$('#mp_msg',p);e.className='ma-ok';e.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'mp',modo:m})});e.className=r.ok?'ma-ok':'ma-err';e.textContent=r.message}catch(x){e.className='ma-err';e.textContent=x.message}};
}
const NIVEL={1:'Anúncio',2:'Anúncio + contato',3:'Página da empresa',4:'Loja completa'};
function pPlanos(p){
 p.innerHTML=`<div><h2 class="${H2}">Planos de anúncio</h2>${card(C.ad_plans.map(k=>row(esc(k.nome)+' · '+brl(k.preco),k.dias+' dias · libera: '+NIVEL[k.nivel],`<button type="button" data-del="${esc(k.id)}" class="text-[13px] font-semibold text-danger">Remover</button>`)).join('')+`<div class="ma-kgrid px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="k_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input id="k_p" inputmode="decimal" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input id="k_d" inputmode="numeric" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Libera</span><select id="k_l" class="${INP} mt-1">${[1,2,3,4].map(n=>`<option value="${n}">${NIVEL[n]}</option>`).join('')}</select></label><button type="button" id="k_add" class="${PRI} h-10">Adicionar</button></div>`)}</div>`;
 $$('[data-del]',p).forEach(b=>b.onclick=()=>put('ad_plans',{items:C.ad_plans.filter(k=>k.id!==b.dataset.del)}));
 $('#k_add',p).onclick=()=>put('ad_plans',{items:[...C.ad_plans,{nome:$('#k_n').value.trim(),preco:parseFloat($('#k_p').value.replace(',','.')),dias:parseInt($('#k_d').value,10),nivel:+$('#k_l').value}]});
}
function pBrain(p){const B=C.brain;
 p.innerHTML=`<div><h2 class="${H2}">Cérebro do chat</h2>${card(row('Aprender com as conversas','Guarda boas respostas das IAs para reutilizar.',sw('aprender',B.aprender,'Aprender'))+row('Responder pelo cérebro primeiro','Se já sabe a resposta, não chama nenhuma IA.',sw('cerebroPrimeiro',B.cerebroPrimeiro,'Cérebro primeiro'))+row('Guardar fatos sobre o usuário','“Meu nome é…”, “lembre que…”, preferências.',sw('fatos',B.fatos,'Fatos')))}
 <h2 class="${H2} mt-8">Busca de empresas e impostos</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-3"><label class="block"><span class="text-xs text-ink-3">Raio máximo da busca (km)</span><input id="s_r" class="${INP} mt-1" value="${C.search.raio}"></label><label class="block"><span class="text-xs text-ink-3">Salário mínimo (R$)</span><input id="f_sm" class="${INP} mt-1" value="${C.fiscal.sm}"></label><label class="block"><span class="text-xs text-ink-3">Limite anual do MEI (R$)</span><input id="f_l" class="${INP} mt-1" value="${C.fiscal.limite}"></label><div class="md:col-span-3"><button type="button" id="sf_s" class="${PRI} h-10">Salvar</button></div></div></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('brain',{[b.dataset.sw]:!B[b.dataset.sw]}));
 $('#sf_s',p).onclick=async()=>{if(await put('search',{raio:parseFloat($('#s_r').value.replace(',','.'))}))await put('fiscal',{sm:parseFloat($('#f_sm').value.replace(',','.')),limite:parseFloat($('#f_l').value.replace(/\./g,'').replace(',','.'))})};
}

const TAB_ON='btn-send',TAB_OFF=['text-ink-2','hover:text-ink'];
let bar=null,loading=false;
function findBar(){return [...document.querySelectorAll('div.glass.no-scrollbar')].find(d=>[...d.querySelectorAll('button')].some(b=>b.textContent.trim()==='Usuários'))}
function reactContent(){const out=[];let n=bar&&bar.nextElementSibling;while(n){if(n.id!=='ma-admin-pane')out.push(n);n=n.nextElementSibling}return out}
async function activate(k){
 tab=k;open='';
 if(!C){try{loading=true;C=await api('/api/panel')}catch(e){toast(e.message);loading=false;return}loading=false}
 [...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON,...TAB_OFF);if(b.dataset.maTab===k)b.classList.add(TAB_ON);else b.classList.add(...TAB_OFF)}else{if(b.dataset.maWasOn===undefined)b.dataset.maWasOn=b.classList.contains(TAB_ON)?'1':'0';b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}});
 reactContent().forEach(n=>n.style.display='none');
 if(!HOST){HOST=document.createElement('section');HOST.id='ma-admin-pane';HOST.className='grid gap-4';}
 if(HOST.previousElementSibling!==bar)bar.after(HOST);
 HOST.style.display='';render();
}
function deactivate(){tab='';if(HOST)HOST.style.display='none';reactContent().forEach(n=>n.style.display='');if(bar)[...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}else if(b.dataset.maWasOn!==undefined){if(b.dataset.maWasOn==='1'){b.classList.add(TAB_ON);b.classList.remove(...TAB_OFF)}delete b.dataset.maWasOn}})}
function inject(){
 if(!location.pathname.startsWith('/admin'))return;
 ensureBase();
 const b=findBar();if(!b)return;
 if(b!==bar){bar=b;HOST=null}
 [...bar.querySelectorAll('button:not([data-ma-tab])')].forEach(b=>{if(/An[uú]ncios e Parceiros|Planos e assinaturas|Cérebro do Chat|Base de Conhecimento/.test(b.textContent))b.style.display='none'});
 if(bar.querySelector('[data-ma-tab]'))return;
 const sample=[...bar.querySelectorAll('button')].find(x=>!x.classList.contains(TAB_ON))||bar.querySelector('button');
 TABS.forEach(([k,l])=>{const nb=document.createElement('button');nb.type='button';nb.dataset.maTab=k;nb.className=(sample?sample.className:'flex h-9 shrink-0 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold transition').replace(/\bbtn-send\b/g,'')+' text-ink-2 hover:text-ink';nb.textContent=l;nb.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();activate(k)});bar.appendChild(nb)});
 bar.addEventListener('click',e=>{const t=e.target.closest('button');if(t&&!t.dataset.maTab&&tab)deactivate()},true);
 const want=new URLSearchParams(location.search).get('aba');if(want&&TABS.some(t=>t[0]===want)){history.replaceState(history.state,'',location.pathname);setTimeout(()=>activate(want),50)}
}
new MutationObserver(()=>inject()).observe(document.body,{childList:true,subtree:true});
setInterval(()=>{if(tab&&C&&tab==='ia'&&!open&&HOST&&HOST.isConnected)api('/api/panel').then(x=>{C=x;render()}).catch(()=>{})},15000);
inject();
})();
