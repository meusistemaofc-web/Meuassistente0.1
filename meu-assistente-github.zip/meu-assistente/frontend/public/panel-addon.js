/* Meu Assistente · novas abas dentro do painel administrativo original (/admin). */
(function(){
if(window.__maPanelAddon)return;window.__maPanelAddon=true;
const STYLE=`
.ma-err{color:var(--nx-danger);font-size:13.5px;margin-top:8px}.ma-err:empty{display:none}.ma-ok{color:var(--nx-success);font-size:13.5px;margin-top:8px}.ma-ok:empty{display:none}
.ma-pill{border-color:var(--nx-line-strong);color:var(--nx-ink-2)}.ma-pill.ok{color:var(--nx-success);border-color:color-mix(in srgb,var(--nx-success) 40%,transparent)}
.ma-pill.warn{color:#f0b54a;border-color:rgba(240,181,74,.4)}.ma-pill.bad{color:var(--nx-danger);border-color:color-mix(in srgb,var(--nx-danger) 40%,transparent)}
main section.grid{grid-template-columns:minmax(0,1fr)}
#toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:200;background:var(--nx-ink);color:var(--nx-canvas);padding:11px 18px;border-radius:999px;font-size:14px;max-width:90vw;text-align:center}#toast[hidden]{display:none}
.ma-kgrid{display:grid;gap:12px}@media (min-width:48rem){.ma-kgrid{grid-template-columns:1fr 7rem 5rem 11rem auto;align-items:end}}
`;
function ensureBase(){if(!document.getElementById('ma-addon-style')){const st=document.createElement('style');st.id='ma-addon-style';st.textContent=STYLE;document.head.appendChild(st)}
 if(!document.getElementById('toast')){const t=document.createElement('div');t.id='toast';t.setAttribute('role','status');t.hidden=true;document.body.appendChild(t)}}
ensureBase();

const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const brl=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const BTN='inline-flex h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 ';
const PRI=BTN+'btn-send hover:brightness-110',GHO=BTN+'border border-line-strong text-ink hover:bg-surface-2',DAN=BTN+'border border-line-strong text-danger hover:bg-surface-2';
const INP='h-10 w-full rounded-xl border border-line bg-surface-2/60 px-3 text-[14px] tabular text-ink outline-none focus:border-accent/60';
const H2='mb-3 px-1 text-[0.72rem] font-semibold uppercase tracking-[0.16em] text-ink-3';
const card=i=>`<div class="glass rounded-[1.6rem] overflow-hidden"><div class="divide-y divide-line">${i}</div></div>`;
const row=(t,d,r)=>`<div class="flex items-center gap-4 px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">${t}</p>${d?`<p class="mt-0.5 text-xs text-ink-3">${d}</p>`:''}</div>${r||''}</div>`;
const sw=(id,on,l)=>`<button type="button" role="switch" aria-checked="${!!on}" aria-label="${esc(l)}" data-sw="${id}" class="nx-switch"><span class="nx-switch-knob"></span></button>`;
const pill=(t,k)=>`<span class="ma-pill ${k||''} shrink-0 rounded-full border px-3 py-1 text-xs font-semibold">${t}</span>`;
let tt;function toast(m){ensureBase();const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3500)}
let C=null,tab='',open='',HOST=null;
async function api(path,opts={}){const r=await fetch(path,{credentials:'same-origin',headers:{'Content-Type':'application/json'},...opts});let j={};try{j=await r.json()}catch(e){}
 if(!r.ok)throw new Error(j.error||('Erro '+r.status));return j}
async function put(key,body){try{C=await api('/api/panel/'+key,{method:'PUT',body:JSON.stringify(body)});render();toast('Salvo');return true}catch(e){toast(e.message);return false}}
const TABS=[['modulos','Módulos'],['ia','IA'],['fontes','Fontes de mercado'],['mp','Mercado Pago'],['planos','Planos de anúncio'],['cerebro','Cérebro e busca']];
function render(){if(!HOST||!C)return;const p=HOST;({modulos:pMod,ia:pIA,fontes:pFontes,mp:pMP,planos:pPlanos,cerebro:pBrain})[tab](p);
 if(!C.canWrite)$$('button,input,select',p).forEach(x=>{x.disabled=true});}
const MODS=[['catalogo','Lojas e pedidos','Catálogo e pedidos das empresas com plano Loja completa.'],['anuncios','Anúncios','Cartões patrocinados no chat e página Anunciar.'],['financas','Finanças','Gastos, contas e vencimentos.'],['lembretes','Lembretes','Avisos e compromissos.'],['imagens','Fotos e arquivos','Envio de imagens e comprovantes no chat.'],['voz','Voz','Mensagens de voz e Modo Voz.'],['fiscal','Impostos e DAS','DAS do MEI, limite e declarações.'],['mercado','Mercado','Cotações de cripto e bolsa, com alertas.']];
function pMod(p){p.innerHTML=`<div><h2 class="${H2}">Módulos globais</h2>${card(MODS.map(([k,n,d])=>row(n,d,sw(k,C.modules[k],n))).join(''))}<p class="mt-3 px-1 text-xs text-ink-3">Um módulo desligado some para todos os usuários conforme cada módulo for ligado ao servidor.</p></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('modules',{[b.dataset.sw]:!C.modules[b.dataset.sw]}))}
function provState(pv,rt){const pz=rt&&rt.paused&&rt.paused[pv.id];if(!pv.ativo)return['Desligada',''];if(pv.id!=='servidor'&&!pv.hasKey)return['Sem chave',''];if(pz&&pz.expired)return['Chave recusada','bad'];if(pz&&pz.seconds>0)return['Pausada · volta em '+pz.seconds+'s','warn'];return['Pronta','ok']}
function aiItems(mod){return C.ai_providers.map(x=>{const o={id:x.id,nome:x.nome,base_url:x.base_url,modelo:x.modelo,texto:x.texto,imagem:x.imagem,ativo:x.ativo};return mod?mod(o)||o:o})}
function pIA(p){const st=C.ai_runtime.stats||{};
 p.innerHTML=`<div><h2 class="${H2}">Inteligências artificiais</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira IA <b class="text-ink">pronta</b> da lista responde no chat. Se ela atingir o limite, tiver a chave recusada ou falhar, a próxima assume na hora. Deixe a <b class="text-ink">IA do servidor</b> (Ollama da VPS) por último: ela não tem limite.</div>
 ${card(C.ai_providers.map((pv,i)=>{const [s,k]=provState(pv,C.ai_runtime),o=open===pv.id,ss=st[pv.id]||{uses:0,failures:0};
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium"><span class="tabular text-ink-3">${i+1}.</span> ${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${pv.texto?'Texto':''}${pv.texto&&pv.imagem?' e ':''}${pv.imagem?'imagens':''} · ${ss.uses} respostas · ${ss.failures} falhas</p></button>${pill(s,k)}${sw('a:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><p class="text-xs text-ink-3">${esc(pv.onde)}</p>
   ${pv.id!=='servidor'?`<label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':''}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave aqui'}"></label>
   <label class="block"><span class="text-xs text-ink-3">Endereço da API</span><input data-f="base_url" class="${INP} mt-1" value="${esc(pv.base_url)}" placeholder="https://…/v1"></label>
   <label class="block"><span class="text-xs text-ink-3">Modelo</span><input data-f="modelo" class="${INP} mt-1" value="${esc(pv.modelo)}" placeholder="Nome do modelo no serviço"></label>`:`<p class="text-xs text-ink-3">Configurada no arquivo .env da VPS (AI_BASE_URL e AI_MODEL).</p>`}
   <div class="flex flex-wrap gap-2"><button type="button" data-cap="texto" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${pv.texto?'btn-send':'border border-line-strong text-ink-2'}">Texto</button><button type="button" data-cap="imagem" class="flex h-8 items-center rounded-full px-3 text-[12.5px] font-semibold ${pv.imagem?'btn-send':'border border-line-strong text-ink-2'}">Ler imagens</button></div>
   ${ss.lastError?`<p class="text-xs text-danger">Último erro: ${esc(ss.lastError)}</p>`:''}<p class="ma-ok" data-msg></p>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10" ${i===0?'disabled':''}>Subir</button><button type="button" data-down class="${GHO} h-10" ${i===C.ai_providers.length-1?'disabled':''}>Descer</button>${provState(pv,C.ai_runtime)[1]==='bad'||provState(pv,C.ai_runtime)[1]==='warn'?`<button type="button" data-resume class="${GHO} h-10">Reativar</button>`:''}${pv.hasKey?`<button type="button" data-clear class="${DAN} h-10">Remover chave</button>`:''}</div></div>`:''}</div>`}).join(''))}
 <p class="mt-3 px-1 text-xs text-ink-3">Toque no nome de uma IA para colar a chave, escolher o modelo, testar e mudar a ordem.</p></div>`;
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box,i=C.ai_providers.findIndex(x=>x.id===id);
 $$('[data-cap]',box).forEach(b=>b.onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,[b.dataset.cap]:!o[b.dataset.cap]}:o)}));
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('ai_providers',{items:aiItems(o=>o.id===id?{...o,...(f('base_url')?{base_url:f('base_url').value.trim(),modelo:f('modelo').value.trim(),key:f('key').value.trim()}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box);m.className='ma-ok';m.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'ai',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message}catch(e){m.className='ma-err';m.textContent=e.message}};
 const mv=d=>{const it=aiItems(),j=i+d;[it[i],it[j]]=[it[j],it[i]];put('ai_providers',{items:it})};
 if($('[data-up]',box))$('[data-up]',box).onclick=()=>mv(-1);if($('[data-down]',box))$('[data-down]',box).onclick=()=>mv(1);
 if($('[data-resume]',box))$('[data-resume]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,resume:true}:o)});
 if($('[data-clear]',box))$('[data-clear]',box).onclick=()=>put('ai_providers',{items:aiItems(o=>o.id===id?{...o,clearKey:true}:o)});
}
function mkItems(mod){return C.market_providers.map(x=>{const o={id:x.id,nome:x.nome,cat:x.cat,url:x.url,campo:x.campo,ativo:x.ativo};return mod?mod(o)||o:o})}
function pFontes(p){const st=C.market_status||{};
 const bloco=cat=>card(C.market_providers.filter(x=>x.cat===cat).map(pv=>{const ss=st[pv.id]||{uses:0,failures:0},s=!pv.ativo?['Desligada','']:pv.precisaChave&&!pv.hasKey?['Sem chave','']:['Pronta','ok'],o=open===pv.id;
  return `<div class="px-5 py-4"><div class="flex items-center gap-3"><button type="button" data-o="${pv.id}" class="min-w-0 flex-1 text-left"><p class="text-[15px] font-medium">${esc(pv.nome)}</p><p class="mt-0.5 text-xs text-ink-3">${esc(pv.info)} · ${ss.uses} consultas · ${ss.failures} falhas</p></button>${pill(s[0],s[1])}${sw('m:'+pv.id,pv.ativo,'Usar '+pv.nome)}</div>
  ${o?`<div class="mt-3 grid gap-3" data-box="${pv.id}"><label class="block"><span class="text-xs text-ink-3">Chave ${pv.hasKey?'(salva: '+esc(pv.keyMasked)+')':pv.precisaChave?'':'(opcional)'}</span><input data-f="key" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${pv.hasKey?'Cole outra para trocar':'Cole a chave'}"></label>
   ${pv.custom?`<label class="block"><span class="text-xs text-ink-3">Endereço</span><input data-f="url" class="${INP} mt-1" value="${esc(pv.url)}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input data-f="campo" class="${INP} mt-1" value="${esc(pv.campo)}"></label>`:''}
   ${ss.lastError?`<p class="text-xs text-danger">Último erro: ${esc(ss.lastError)}</p>`:''}<p class="ma-ok" data-msg></p>
   <div class="flex flex-wrap gap-2"><button type="button" data-save class="${PRI} h-10">Salvar</button><button type="button" data-test class="${GHO} h-10">Testar</button><button type="button" data-up class="${GHO} h-10">Subir</button>${pv.custom?`<button type="button" data-del class="${DAN} h-10">Excluir</button>`:''}</div></div>`:''}</div>`}).join(''));
 p.innerHTML=`<div><h2 class="${H2}">Fontes de mercado</h2><div class="glass mb-4 rounded-[1.6rem] p-5 text-sm leading-relaxed text-ink-2">A primeira fonte <b class="text-ink">pronta</b> de cada lista é usada. Se falhar ou atingir o limite, a próxima assume. As cotações ficam guardadas por 1 minuto para economizar o limite.</div>
 <h2 class="${H2}">Criptomoedas</h2>${bloco('cripto')}<h2 class="${H2} mt-8">Ações da B3</h2>${bloco('bolsa')}
 <h2 class="${H2} mt-8">Cadastrar nova fonte</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-2"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="nf_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Tipo</span><select id="nf_c" class="${INP} mt-1"><option value="cripto">Criptomoedas</option><option value="bolsa">Ações da B3</option></select></label>
 <label class="block md:col-span-2"><span class="text-xs text-ink-3">Endereço (use {SIMBOLO} e {chave})</span><input id="nf_u" class="${INP} mt-1" placeholder="https://api.exemplo.com/quote/{SIMBOLO}?key={chave}"></label><label class="block"><span class="text-xs text-ink-3">Caminho do preço</span><input id="nf_f" class="${INP} mt-1" placeholder="data.price"></label><label class="block"><span class="text-xs text-ink-3">Chave (se precisar)</span><input id="nf_k" type="password" class="${INP} mt-1"></label>
 <div class="md:col-span-2"><button type="button" id="nf_add" class="${PRI} h-10">Cadastrar fonte</button></div></div></div>`;
 $$('[data-o]',p).forEach(b=>b.onclick=()=>{open=open===b.dataset.o?'':b.dataset.o;render()});
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>{const id=b.dataset.sw.slice(2);put('market_providers',{items:mkItems(o=>o.id===id?{...o,ativo:!o.ativo}:o)})});
 $('#nf_add',p).onclick=()=>put('market_providers',{items:[...mkItems(),{id:'c-'+Math.random().toString(36).slice(2,8),nome:$('#nf_n').value.trim(),cat:$('#nf_c').value,url:$('#nf_u').value.trim(),campo:$('#nf_f').value.trim(),key:$('#nf_k').value.trim(),ativo:true}]});
 const box=$('[data-box]',p);if(!box)return;const id=box.dataset.box;
 $('[data-save]',box).onclick=()=>{const f=k=>$(`[data-f=${k}]`,box);put('market_providers',{items:mkItems(o=>o.id===id?{...o,key:f('key').value.trim(),...(f('url')?{url:f('url').value.trim(),campo:f('campo').value.trim()}:{})}:o)})};
 $('[data-test]',box).onclick=async()=>{const m=$('[data-msg]',box);m.className='ma-ok';m.textContent='Testando…';try{const r=await api('/api/panel/test',{method:'POST',body:JSON.stringify({kind:'market',id})});m.className=r.ok?'ma-ok':'ma-err';m.textContent=r.message}catch(e){m.className='ma-err';m.textContent=e.message}};
 $('[data-up]',box).onclick=()=>{const it=mkItems(),i=it.findIndex(x=>x.id===id);let j=i-1;while(j>=0&&it[j].cat!==it[i].cat)j--;if(j<0)return;[it[i],it[j]]=[it[j],it[i]];put('market_providers',{items:it})};
 if($('[data-del]',box))$('[data-del]',box).onclick=()=>put('market_providers',{items:mkItems().filter(x=>x.id!==id)});
}
function pMP(p){const m=C.mercadopago.modo,c=C.mercadopago[m];
 p.innerHTML=`<div><h2 class="${H2}">Mercado Pago</h2><div class="glass no-scrollbar mb-4 flex w-fit gap-1 rounded-full p-1">${[['teste','Modo teste'],['producao','Produção']].map(([k,l])=>`<button type="button" data-m="${k}" class="flex h-9 items-center rounded-full px-4 text-[13px] font-semibold ${m===k?'btn-send':'text-ink-2'}">${l}</button>`).join('')}</div>
 <div class="glass rounded-[1.6rem] overflow-hidden"><div class="flex items-center gap-3 border-b border-line px-5 py-4"><div class="min-w-0 flex-1"><p class="text-[15px] font-medium">Credenciais · ${m==='teste'?'Teste':'Produção'}</p><p class="mt-0.5 text-xs text-ink-3">Pegue em mercadopago.com.br/developers → Suas integrações → Credenciais.</p></div>${pill(c.tok.hasKey?'Salvas':'Não configurado',c.tok.hasKey?'ok':'warn')}</div>
 <div class="grid gap-3 px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Access Token ${c.tok.hasKey?'(salvo: '+esc(c.tok.keyMasked)+')':''}</span><input id="mp_tok" type="password" autocomplete="off" class="${INP} mt-1" placeholder="${m==='teste'?'TEST-…':'APP_USR-…'}"></label>
 <label class="block"><span class="text-xs text-ink-3">Chave pública</span><input id="mp_pub" class="${INP} mt-1" value="${esc(c.pub)}"></label>
 <label class="block"><span class="text-xs text-ink-3">Segredo dos webhooks ${c.seg.hasKey?'(salvo)':''}</span><input id="mp_seg" type="password" autocomplete="off" class="${INP} mt-1" placeholder="Opcional"></label>
 <div class="flex flex-wrap gap-2"><button type="button" id="mp_s" class="${PRI} h-10">Salvar</button>${c.tok.hasKey?`<button type="button" id="mp_c" class="${DAN} h-10">Remover</button>`:''}</div></div></div>
 <div class="glass mt-4 rounded-[1.6rem] p-5"><p class="text-[15px] font-medium">URL de notificação (webhook)</p><code class="mt-2 block truncate rounded-xl bg-surface-2 px-3 py-1.5 text-[12px] text-ink">${esc(C.webhookUrl)}</code><p class="mt-2 text-xs text-ink-3">O recebimento dos pagamentos entra na etapa de anúncios; as credenciais já ficam salvas e cifradas.</p></div></div>`;
 $$('[data-m]',p).forEach(b=>b.onclick=()=>put('mercadopago',{modo:b.dataset.m}));
 $('#mp_s',p).onclick=()=>put('mercadopago',{modo:m,[m]:{pub:$('#mp_pub').value.trim(),tok:$('#mp_tok').value.trim(),seg:$('#mp_seg').value.trim()}});
 if($('#mp_c',p))$('#mp_c',p).onclick=()=>put('mercadopago',{modo:m,[m]:{clear:true}});
}
const NIVEL={1:'Anúncio',2:'Anúncio + contato',3:'Página da empresa',4:'Loja completa'};
function pPlanos(p){
 p.innerHTML=`<div><h2 class="${H2}">Planos de anúncio</h2>${card(C.ad_plans.map(k=>row(esc(k.nome)+' · '+brl(k.preco),k.dias+' dias · libera: '+NIVEL[k.nivel],`<button type="button" data-del="${esc(k.id)}" class="text-[13px] font-semibold text-danger">Remover</button>`)).join('')+`<div class="ma-kgrid px-5 py-4"><label class="block"><span class="text-xs text-ink-3">Nome</span><input id="k_n" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Preço (R$)</span><input id="k_p" inputmode="decimal" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Dias</span><input id="k_d" inputmode="numeric" class="${INP} mt-1"></label><label class="block"><span class="text-xs text-ink-3">Libera</span><select id="k_l" class="${INP} mt-1">${[1,2,3,4].map(n=>`<option value="${n}">${NIVEL[n]}</option>`).join('')}</select></label><button type="button" id="k_add" class="${PRI} h-10">Adicionar</button></div>`)}</div>`;
 $$('[data-del]',p).forEach(b=>b.onclick=()=>put('ad_plans',{items:C.ad_plans.filter(k=>k.id!==b.dataset.del)}));
 $('#k_add',p).onclick=()=>put('ad_plans',{items:[...C.ad_plans,{nome:$('#k_n').value.trim(),preco:parseFloat($('#k_p').value.replace(',','.')),dias:parseInt($('#k_d').value,10),nivel:+$('#k_l').value}]});
}
function pBrain(p){const B=C.brain;
 p.innerHTML=`<div><h2 class="${H2}">Cérebro do chat</h2>${card(row('Aprender com as conversas','Guarda boas respostas das IAs para reutilizar.',sw('aprender',B.aprender,'Aprender'))+row('Responder pelo cérebro primeiro','Se já sabe a resposta, não chama nenhuma IA.',sw('cerebroPrimeiro',B.cerebroPrimeiro,'Cérebro primeiro'))+row('Guardar fatos sobre o usuário','“Meu nome é…”, “lembre que…”, preferências.',sw('fatos',B.fatos,'Fatos')))}
 <h2 class="${H2} mt-8">Busca de empresas e impostos</h2><div class="glass grid gap-3 rounded-[1.6rem] p-5 md:grid-cols-3"><label class="block"><span class="text-xs text-ink-3">Raio máximo da busca (km)</span><input id="s_r" class="${INP} mt-1" value="${C.search.raio}"></label><label class="block"><span class="text-xs text-ink-3">Salário mínimo (R$)</span><input id="f_sm" class="${INP} mt-1" value="${C.fiscal.sm}"></label><label class="block"><span class="text-xs text-ink-3">Limite anual do MEI (R$)</span><input id="f_l" class="${INP} mt-1" value="${C.fiscal.limite}"></label><div class="md:col-span-3"><button type="button" id="sf_s" class="${PRI} h-10">Salvar</button></div></div></div>`;
 $$('[data-sw]',p).forEach(b=>b.onclick=()=>put('brain',{[b.dataset.sw]:!B[b.dataset.sw]}));
 $('#sf_s',p).onclick=async()=>{if(await put('search',{raio:parseFloat($('#s_r').value.replace(',','.'))}))await put('fiscal',{sm:parseFloat($('#f_sm').value.replace(',','.')),limite:parseFloat($('#f_l').value.replace(/\./g,'').replace(',','.'))})};
}

const TAB_ON='btn-send',TAB_OFF=['text-ink-2','hover:text-ink'];
let bar=null,loading=false;
function findBar(){return [...document.querySelectorAll('div.glass.no-scrollbar')].find(d=>[...d.querySelectorAll('button')].some(b=>b.textContent.trim()==='Usuários'))}
function reactContent(){const out=[];let n=bar&&bar.nextElementSibling;while(n){if(n.id!=='ma-admin-pane')out.push(n);n=n.nextElementSibling}return out}
async function activate(k){
 tab=k;open='';
 if(!C){try{loading=true;C=await api('/api/panel')}catch(e){toast(e.message);loading=false;return}loading=false}
 [...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON,...TAB_OFF);if(b.dataset.maTab===k)b.classList.add(TAB_ON);else b.classList.add(...TAB_OFF)}else{if(b.dataset.maWasOn===undefined)b.dataset.maWasOn=b.classList.contains(TAB_ON)?'1':'0';b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}});
 reactContent().forEach(n=>n.style.display='none');
 if(!HOST){HOST=document.createElement('section');HOST.id='ma-admin-pane';HOST.className='grid gap-4';}
 if(HOST.previousElementSibling!==bar)bar.after(HOST);
 HOST.style.display='';render();
}
function deactivate(){tab='';if(HOST)HOST.style.display='none';reactContent().forEach(n=>n.style.display='');if(bar)[...bar.querySelectorAll('button')].forEach(b=>{if(b.dataset.maTab){b.classList.remove(TAB_ON);b.classList.add(...TAB_OFF)}else if(b.dataset.maWasOn!==undefined){if(b.dataset.maWasOn==='1'){b.classList.add(TAB_ON);b.classList.remove(...TAB_OFF)}delete b.dataset.maWasOn}})}
function inject(){
 if(!location.pathname.startsWith('/admin'))return;
 ensureBase();
 const b=findBar();if(!b)return;
 if(b!==bar){bar=b;HOST=null}
 if(bar.querySelector('[data-ma-tab]'))return;
 const sample=[...bar.querySelectorAll('button')].find(x=>!x.classList.contains(TAB_ON))||bar.querySelector('button');
 TABS.forEach(([k,l])=>{const nb=document.createElement('button');nb.type='button';nb.dataset.maTab=k;nb.className=(sample?sample.className:'flex h-9 shrink-0 items-center gap-1.5 rounded-full px-4 text-[13px] font-semibold transition').replace(/\bbtn-send\b/g,'')+' text-ink-2 hover:text-ink';nb.textContent=l;nb.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();activate(k)});bar.appendChild(nb)});
 bar.addEventListener('click',e=>{const t=e.target.closest('button');if(t&&!t.dataset.maTab&&tab)deactivate()},true);
}
new MutationObserver(()=>inject()).observe(document.body,{childList:true,subtree:true});
setInterval(()=>{if(tab&&C&&tab==='ia'&&!open&&HOST&&HOST.isConnected)api('/api/panel').then(x=>{C=x;render()}).catch(()=>{})},15000);
inject();
})();
