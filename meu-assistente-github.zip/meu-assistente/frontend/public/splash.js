/* Abertura animada (~2 s): a logo M oficial é revelada como se fosse desenhada — primeira subida, descida,
   segunda subida e descida final — e depois o chat aparece suavemente. A imagem da logo não é alterada:
   a animação é só uma máscara que vai revelando o desenho original. */
(function(){
  try{
    if(window.top!==window)return;                       // prévias do painel e módulos dentro do chat
    if(!/^\/($|chat|c\/?$|x\/|meu-dia|agenda|financeiro|perfil|notificacoes|organizar)/.test(location.pathname)&&location.pathname!=='/')return;
    // uma vez por abertura do app; se a página recarregar no meio da abertura, ela continua de onde parou
    var prev=Number(sessionStorage.getItem('ma-splash')||0),now=Date.now();
    if(prev&&now-prev>2600)return;
    if(!prev)sessionStorage.setItem('ma-splash',String(now));
    var elapsed=prev?now-prev:0;
  }catch(e){return}
  var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  var D=reduce?300:1900;
  var css='#ma-splash{position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;background:#000;transition:opacity .45s ease}'+
    '#ma-splash.out{opacity:0;pointer-events:none}'+
    '#ma-splash svg{width:min(62vw,300px);height:auto;overflow:visible}'+
    '#ma-splash .trace{stroke-dasharray:1;stroke-dashoffset:1;animation:maDraw '+D+'ms cubic-bezier(.55,.05,.35,1) -'+Math.min(elapsed,D)+'ms forwards}'+
    '#ma-splash .glow{opacity:0;animation:maGlow .6s ease '+(D-250-elapsed)+'ms forwards}'+
    '@keyframes maDraw{to{stroke-dashoffset:0}}@keyframes maGlow{to{opacity:1}}';
  var st=document.createElement('style');st.textContent=css;(document.head||document.documentElement).appendChild(st);
  var w=document.createElement('div');w.id='ma-splash';w.setAttribute('aria-hidden','true');
  // traçado do M na proporção da imagem oficial (640×457): pé esquerdo → 1º pico → vale → 2º pico → pé direito
  w.innerHTML='<svg viewBox="0 0 640 457" xmlns="http://www.w3.org/2000/svg"><defs><mask id="maM" maskUnits="userSpaceOnUse" x="-40" y="-40" width="720" height="540">'+
    '<rect x="-40" y="-40" width="720" height="540" fill="#000"/>'+
    '<path class="trace" pathLength="1" d="M48 420 C 80 300, 120 150, 168 108 C 210 72, 250 120, 280 190 C 310 260, 330 330, 368 338 C 410 345, 440 250, 470 170 C 495 105, 520 80, 548 102 C 575 130, 595 260, 612 420" fill="none" stroke="#fff" stroke-width="170" stroke-linecap="round" stroke-linejoin="round"/>'+
    '</mask></defs><image href="/brand/logo-principal.png?v=3" x="0" y="0" width="640" height="457" mask="url(#maM)"/>'+
    '<image class="glow" href="/brand/logo-principal.png?v=3" x="0" y="0" width="640" height="457"/></svg>';
  // o app pode recriar o <body> ao iniciar: a abertura volta para a tela até terminar
  var done=false,t0=Date.now();
  function keep(){if(done)return;if(!document.body){return setTimeout(keep,10)}if(!w.isConnected)document.body.appendChild(w);if(!st.isConnected)(document.head||document.documentElement).appendChild(st);requestAnimationFrame(keep)}
  keep();
  setTimeout(function(){w.classList.add('out');setTimeout(function(){done=true;w.remove();st.remove()},480)},Math.max(150,D+350-elapsed));
})();
