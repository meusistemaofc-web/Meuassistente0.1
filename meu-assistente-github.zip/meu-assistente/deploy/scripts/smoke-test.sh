#!/usr/bin/env bash
# Teste rápido do sistema já instalado (não cria dados). Uso: bash deploy/scripts/smoke-test.sh [URL]
URL="${1:-http://127.0.0.1:3000}"
ok=0; fail=0
check() { if eval "$2"; then echo "  OK   $1"; ok=$((ok+1)); else echo "  FALHA $1"; fail=$((fail+1)); fi; }
echo "Testando $URL"
check "API e banco PostgreSQL (/api/health)" "curl -fsS $URL/api/health | grep -q '\"db\":\"postgres\"'"
check "Autenticação (/api/auth)" "curl -fsS $URL/api/auth | grep -q 'firstAccount'"
check "Página inicial do app" "curl -fsS $URL/ | grep -q '\$_TSR'"
check "Rota do app (/agenda)" "curl -fsS $URL/agenda | grep -q 'index-MUcZwl3l.js'"
check "Arquivo principal do frontend" "curl -fsS -o /dev/null $URL/assets/index-MUcZwl3l.js"
check "Service worker (PWA)" "curl -fsS -o /dev/null $URL/sw.js"
check "Rota protegida exige login (401)" "[ \"\$(curl -s -o /dev/null -w '%{http_code}' $URL/api/me)\" = 401 ]"
echo "Resultado: $ok OK, $fail falha(s)"
[ "$fail" -eq 0 ]
