#!/usr/bin/env bash
# Atualiza o Meu Assistente para uma nova versão dos arquivos (faz backup antes).
# Uso: sudo bash deploy/scripts/update.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
bash deploy/scripts/backup.sh
if [ -d .git ]; then git pull --ff-only || echo "AVISO: git pull falhou; usando os arquivos atuais."; fi
docker compose up -d --build
for i in $(seq 1 40); do curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1 && break; sleep 3; done
docker image prune -f >/dev/null || true
bash deploy/scripts/smoke-test.sh
echo "Atualização concluída. As migrações do banco são aplicadas automaticamente ao iniciar."
