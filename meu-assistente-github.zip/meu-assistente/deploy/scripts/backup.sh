#!/usr/bin/env bash
# Backup do banco PostgreSQL (mantém os 14 mais recentes em ./backups).
# Uso: bash deploy/scripts/backup.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
set -a; . ./.env; set +a
mkdir -p backups
FILE="backups/meuassistente-$(date +%Y%m%d-%H%M%S).sql.gz"
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-meuassistente}" -d "${POSTGRES_DB:-meuassistente}" --no-owner | gzip > "$FILE"
[ -s "$FILE" ] || { echo "ERRO: backup vazio"; rm -f "$FILE"; exit 1; }
ls -1t backups/meuassistente-*.sql.gz | tail -n +15 | xargs -r rm -f
echo "Backup salvo em $FILE"
