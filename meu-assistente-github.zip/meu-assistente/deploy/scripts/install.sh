#!/usr/bin/env bash
# Instalação do Meu Assistente numa VPS Ubuntu (22.04/24.04) — ex.: Hostinger.
# Uso (dentro da pasta do projeto):  sudo bash deploy/scripts/install.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
ROOT="$(pwd)"
[ "$(id -u)" -eq 0 ] || { echo "Execute com sudo: sudo bash deploy/scripts/install.sh"; exit 1; }

echo "== 1/6 Pacotes do sistema (Docker, Nginx, Certbot)"
apt-get update -y
apt-get install -y ca-certificates curl nginx certbot python3-certbot-nginx openssl
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker nginx

echo "== 2/6 Configuração (.env)"
if [ ! -f .env ]; then
  cp .env.example .env
  read -rp "Domínio (ex.: meuassistente.com.br — deixe vazio para usar só o IP): " DOMAIN
  read -rp "Chave da API de IA (AI_API_KEY — pode deixar vazio e preencher depois): " AIKEY
  PW="$(openssl rand -hex 24)"
  sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=${PW}|" .env
  sed -i "s|^AI_API_KEY=.*|AI_API_KEY=${AIKEY}|" .env
  if [ -n "$DOMAIN" ]; then
    sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=https://${DOMAIN}|" .env
  else
    IP="$(curl -fsS https://api.ipify.org || hostname -I | awk '{print $1}')"
    sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=http://${IP}|" .env
  fi
  chmod 600 .env
  echo ".env criado (senha do banco gerada automaticamente)."
else
  echo ".env já existe — mantido."
  DOMAIN="$(grep '^PUBLIC_URL=' .env | sed -E 's|PUBLIC_URL=https?://||; s|/.*||')"
  [[ "$DOMAIN" =~ ^[0-9.]+$ ]] && DOMAIN=""
fi

echo "== 3/6 Subindo banco e aplicação (Docker)"
docker compose up -d --build

echo "== 4/6 Aguardando a aplicação responder"
for i in $(seq 1 60); do
  if curl -fsS http://127.0.0.1:3000/api/health >/dev/null 2>&1; then echo "Aplicação no ar."; break; fi
  sleep 3
  [ "$i" -eq 60 ] && { echo "A aplicação não respondeu. Veja: docker compose logs app"; exit 1; }
done

echo "== 5/6 Nginx"
CONF=/etc/nginx/sites-available/meu-assistente.conf
cp deploy/nginx/meu-assistente.conf "$CONF"
if [ -n "${DOMAIN:-}" ]; then sed -i "s/SEU_DOMINIO/${DOMAIN}/g" "$CONF"; else sed -i "s/server_name .*/server_name _;/" "$CONF"; fi
ln -sf "$CONF" /etc/nginx/sites-enabled/meu-assistente.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "== 6/6 HTTPS"
if [ -n "${DOMAIN:-}" ]; then
  read -rp "E-mail para o certificado HTTPS (Let's Encrypt): " CERTMAIL
  certbot --nginx -d "$DOMAIN" -d "www.$DOMAIN" --non-interactive --agree-tos -m "$CERTMAIL" --redirect \
    || certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$CERTMAIL" --redirect \
    || echo "AVISO: HTTPS não configurado. Confira se o domínio aponta para este servidor e rode: sudo certbot --nginx -d $DOMAIN"
else
  echo "Sem domínio: o site fica em HTTP pelo IP. Quando tiver um domínio, ajuste PUBLIC_URL no .env e rode este script de novo."
fi

# backup diário às 03:00
( crontab -l 2>/dev/null | grep -v 'meu-assistente-backup'; echo "0 3 * * * cd $ROOT && bash deploy/scripts/backup.sh >> $ROOT/backups/backup.log 2>&1 # meu-assistente-backup" ) | crontab -
mkdir -p backups

bash deploy/scripts/smoke-test.sh || true
echo
echo "Pronto! Acesse: $(grep '^PUBLIC_URL=' .env | cut -d= -f2)"
echo "A PRIMEIRA conta criada em /cadastro vira o Administrador Principal."
