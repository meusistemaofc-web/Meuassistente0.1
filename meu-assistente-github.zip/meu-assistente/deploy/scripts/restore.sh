#!/usr/bin/env bash
# Restaura um backup (SUBSTITUI todos os dados atuais).
# Uso: sudo bash deploy/scripts/restore.sh backups/meuassistente-AAAAMMDD-HHMMSS.sql.gz
set -euo pipefail
cd "$(dirname "$0")/../.."
FILE="${1:?Informe o arquivo de backup}"
[ -f "$FILE" ] || { echo "Arquivo não encontrado: $FILE"; exit 1; }
set -a; . ./.env; set +a
read -rp "Isto APAGA os dados atuais e restaura $FILE. Digite RESTAURAR para continuar: " OK
[ "$OK" = "RESTAURAR" ] || { echo "Cancelado."; exit 1; }
U="${POSTGRES_USER:-meuassistente}"; D="${POSTGRES_DB:-meuassistente}"
docker compose stop app
docker compose exec -T db psql -U "$U" -d postgres -c "DROP DATABASE IF EXISTS \"$D\";" -c "CREATE DATABASE \"$D\" OWNER \"$U\";"
gunzip -c "$FILE" | docker compose exec -T db psql -U "$U" -d "$D" -v ON_ERROR_STOP=1 >/dev/null
docker compose start app
echo "Restauração concluída."
