# Motor multi-IA do Meu Assistente

## Auditoria: por que o Gemini aparecia "pronto" e não respondia

| # | Causa encontrada | Correção |
|---|------------------|----------|
| 1 | `chat.ts` bloqueava toda mensagem com `aiConfigured()`, que só olhava o `.env`. Com o Gemini cadastrado só no painel, o chat devolvia 503 antes de tentar qualquer IA. | Portão removido: o motor decide. Mensagens que não precisam de IA (finanças, agenda, cotações) funcionam mesmo sem IA. |
| 2 | O botão **Testar** enviava só "Responda OK" **sem ferramentas**, e aceitava qualquer resposta (até vazia). O chat real envia 11 ferramentas. | O teste agora é real e valida cada capacidade (ver abaixo). |
| 3 | O Gemini era chamado pelo endereço de compatibilidade com a OpenAI. Ferramentas com `additionalProperties` e a ferramenta sem parâmetros (`get_agenda`) são recusadas pelo Gemini. | Adaptador **nativo** (`generateContent`) com limpeza do esquema, `systemInstruction`, `functionResponse` e assinatura de pensamento. |
| 4 | Chave inválida no Gemini volta como **HTTP 400** (`API key not valid`), não 401: nunca era reconhecida como "chave recusada". | Classificação de erros por provedor (`types.ts`). |
| 5 | Respostas bloqueadas (`SAFETY`), vazias ou com `MALFORMED_FUNCTION_CALL` eram entregues como sucesso. | Validação da resposta; inválida = falha → próxima IA. |
| 6 | Imagem, PDF e áudio usavam um caminho separado (`docs.ts`), só Gemini, sem fallback, sem estatística, sem teste. | Passam pelo mesmo motor, com fallback entre Gemini, Claude, OpenAI e Whisper (Groq/OpenAI). |
| 7 | Chave recusada pausava a IA "até nova chave", mas trocar a chave não reativava (só o botão Reativar). | A pausa é ligada à assinatura endereço+modelo+chave: mudou, reativa sozinha. |
| 8 | Estatísticas gravadas sem controle de concorrência. | Gravação serializada e agrupada. |
| 9 | Se a IA caísse **depois** de executar uma ferramenta, o erro subia, nada era salvo na conversa e o reenvio do usuário duplicava o lançamento. | Resposta de resgate ("Pronto! Já fiz…") e execução única. |

## Arquitetura (`server/src/ai/`)

- `adapters/openai.ts`, `gemini.ts`, `anthropic.ts` — um adaptador por API; todos devolvem o mesmo formato e os mesmos tipos de erro.
- `engine.ts` — roteador: classifica a tarefa, filtra por capacidade, pontua (prioridade, afinidade, qualidade, velocidade), faz fallback, consulta paralela, teste real e monitor.
- `health.ts` — circuit breaker, consumo (tokens, latência, erros por dia/tarefa), resultado dos testes.
- `registry.ts` — lê o painel, deduz tipo/capacidades, junta IAs novas a instalações antigas.
- `once.ts` — execução única. `assets.ts` — PNG/PDF/WAV de teste gerados em código.
- `provider.ts` — fachada: o resto do app continua importando `complete`.

### Tarefas e capacidades
Tarefas: conversa, agente (ferramentas), contexto, análise, programação, pesquisa, imagem, documento, áudio.
Capacidades por IA (ligáveis no painel): Conversa, Ferramentas, Imagens, Documentos, Áudio, Programação, Pesquisa.

### Fallback e tolerância a falhas
- Erro, tempo esgotado, 429, chave recusada, modelo inexistente, resposta vazia/bloqueada/malformada → a próxima IA assume na hora, com o mesmo contexto.
- Novas tentativas controladas: só após esgotar a lista e só para erros temporários (rede, 5xx, timeout), com espera curta variável e prazo total.
- **Circuit breaker** por IA: `fechado → aberto → meio-aberto`. Abre após N falhas (padrão 3) com pausa que dobra até um teto; 429 respeita `Retry-After`; chave/modelo inválidos ficam abertos até a configuração mudar.
- **Monitor** (a cada minuto): testa IAs em pausa e as reativa quando voltam.
- Se tudo falhar: erro 502 amigável; a cota diária do usuário é devolvida.

### Uso combinado
Em tarefas complexas (padrão: análise, programação, pesquisa) e **sem ferramentas**, 2–4 IAs respondem em paralelo; uma IA juíza escolhe a melhor (ou vale a primeira válida, no modo corrida). Relatórios de empresa usam isso.

### Continuidade
O histórico é neutro (`ChatMsg`); cada adaptador traduz na hora. Chamadas de ferramenta de uma IA são entendidas pela seguinte (ids, assinatura do Gemini, `tool_use` do Claude).

### Execução segura
- Mesma ferramenta + mesmos argumentos na mesma conversa → executada uma vez (resultado reaproveitado); vale também para o agente das empresas (pedido, agendamento, Pix).
- Pedido idêntico em até 20 s não grava de novo.
- Mesma mensagem enviada duas vezes enquanto a primeira processa → uma única resposta.
- Consulta paralela nunca roda com ferramentas.

## Teste real (botão Testar, "Testar todas")
Requisições reais, com validação da resposta:
Conversa (17 + 25 = 42) · Ferramentas (chama `registrar_codigo` com K7Q2, inclui ferramenta sem parâmetros, devolve o resultado e exige resposta) · Imagens (PNG com 4821) · Documentos (PDF com 7305) · Áudio (aceita o arquivo) · Programação · Pesquisa.
Uma capacidade reprovada reduz a prioridade da IA nessa tarefa até o próximo teste aprovado.

## Painel (Administração → IA)
Ligar/desligar, chave, endereço, modelo, tipo de API, modelo de áudio, capacidades, ordem (prioridade), teste por IA e geral, estado (pronta, em pausa, chave recusada…), consumo (respostas e tokens hoje/total), latência, últimos erros e ajustes do motor (critério, tempos, tentativas, breaker, paralelo, monitor). Dá para adicionar IAs extras (OpenAI-compatível, Gemini ou Claude).

## Limites conhecidos
- O ambiente de desenvolvimento não tinha rede: os adaptadores foram validados contra dublês rígidos que reproduzem as regras de cada API, não contra os serviços reais. **Rode "Testar todas" no painel depois de publicar.**
- Pesquisa na web só usa o Gemini (busca embutida) e apenas quando a chamada não tem ferramentas.
- Áudio `webm` pode não ser aceito pelo Gemini; mantenha uma IA com Whisper (Groq ou OpenAI) ligada.
