# Guia de Instalação na VPS Hostinger — Meu Assistente

Este guia parte do zero e não exige experiência com servidores. Cada comando pode ser copiado e colado.

## O que você precisa

- **VPS Hostinger** com **Ubuntu 22.04 ou 24.04** e pelo menos 2 GB de RAM.
  - No painel da Hostinger: VPS → Sistema operacional → Ubuntu.
- O **IP da VPS** e a **senha do root**, que aparecem no painel da Hostinger.
- *(Recomendado)* Um **domínio**, necessário para HTTPS e para o app ser instalado no celular.
- *(Para o chat funcionar)* Uma **chave de API de IA**, por exemplo da OpenAI (platform.openai.com → API keys).
- *(Para recuperação de senha)* Uma chave do **Resend** (resend.com).

## Passo 1 — Apontar o domínio (se tiver)

No painel onde você comprou o domínio (Hostinger → Domínios → DNS), crie:

| Tipo | Nome | Valor |
|---|---|---|
| A | @ | IP da sua VPS |
| A | www | IP da sua VPS |

A propagação pode levar de alguns minutos a algumas horas.

## Passo 2 — Enviar o projeto para a VPS

### Opção A: pelo GitHub (como você costuma fazer)

1. No GitHub, crie um repositório **privado** e envie o arquivo `MEU_ASSISTENTE_COMPLETO.zip` inteiro.
2. Na VPS, baixe o ZIP.
   - Se o repositório for privado, use o link "Download raw" com um token, ou deixe o repositório público só durante o download.
   - Também funciona usar o terminal do navegador da Hostinger.
3. Entre na VPS: no Windows, use o PowerShell; no Mac, o Terminal. Depois rode:

```bash
ssh root@IP_DA_VPS
apt-get update && apt-get install -y unzip curl
cd /opt
# baixe o zip para /opt (por exemplo):
curl -L -o MEU_ASSISTENTE_COMPLETO.zip "LINK_DO_ARQUIVO_NO_GITHUB"
unzip MEU_ASSISTENTE_COMPLETO.zip
cd MEU_ASSISTENTE_COMPLETO
```

### Opção B: enviar direto do seu computador

```bash
scp MEU_ASSISTENTE_COMPLETO.zip root@IP_DA_VPS:/opt/
ssh root@IP_DA_VPS
cd /opt && apt-get install -y unzip && unzip MEU_ASSISTENTE_COMPLETO.zip && cd MEU_ASSISTENTE_COMPLETO
```

## Passo 3 — Instalar tudo com um comando

```bash
sudo bash deploy/scripts/install.sh
```

O script vai perguntar:

1. **Domínio.** Exemplo: `meuassistente.com.br`. Deixe vazio se ainda não tiver.
2. **Chave da IA.** Pode deixar vazio e colocar depois.
3. **E-mail para o certificado HTTPS.** Só aparece se você informou um domínio.

O que o script faz sozinho:

- instala Docker, Nginx e Certbot
- cria o `.env` com uma senha forte para o banco
- sobe o PostgreSQL e o app
- configura o Nginx e o HTTPS
- agenda um **backup diário às 03:00**
- roda o teste rápido

No final, deve aparecer **"Resultado: 7 OK, 0 falha(s)"**.

## Passo 4 — Primeiro acesso

1. Abra `https://seudominio` ou `http://IP_DA_VPS`.
2. Vá em **Criar conta**. **A primeira conta vira o Administrador Principal**, com acesso ao painel em /admin.
3. Recomendado: em **Perfil → Segurança da conta**, ative a **verificação em duas etapas**.

## Passo 5 — Configurar IA e e-mail (se pulou)

```bash
cd /opt/MEU_ASSISTENTE_COMPLETO
nano .env
```

No editor:

1. Preencha `AI_API_KEY=...`. Se quiser outro provedor, ajuste também `AI_BASE_URL` e `AI_MODEL`; há exemplos no próprio arquivo.
2. Preencha `RESEND_API_KEY=...` e `MAIL_FROM=...`.
3. Salve com **Ctrl+O** e Enter, e saia com **Ctrl+X**.

Depois, reinicie o app:

```bash
docker compose up -d
```

## Se ainda não tinha domínio e comprou depois

1. Aponte o DNS (Passo 1).
2. No `.env`, troque `PUBLIC_URL=https://seudominio.com.br`.
3. Rode de novo o instalador:

```bash
sudo bash deploy/scripts/install.sh
```

## Atualizar para uma nova versão

1. Substitua os arquivos pela nova versão, mantendo o arquivo `.env` e a pasta `backups/`.
2. Rode:

```bash
sudo bash deploy/scripts/update.sh
```

O script faz um backup antes. As migrações do banco rodam sozinhas.

## Backup e restauração

```bash
bash deploy/scripts/backup.sh                    # backup manual → pasta backups/
ls backups/                                      # ver backups (os 14 mais recentes ficam guardados)
sudo bash deploy/scripts/restore.sh backups/meuassistente-AAAAMMDD-HHMMSS.sql.gz
```

Guarde também uma cópia dos backups **fora da VPS**, por exemplo baixando-os com `scp` de vez em quando.

## Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Site não abre | `docker compose ps` (os dois serviços devem estar "running") e `docker compose logs app` |
| "IA não configurada" no chat | Preencha `AI_API_KEY` no `.env` e rode `docker compose up -d` |
| HTTPS falhou | Confira o DNS e rode `sudo certbot --nginx -d seudominio.com.br` |
| Link de recuperação não chega | Configure o Resend. Sem ele, o link aparece em `docker compose logs app` |
| "Primeiro acesso: definir Administrador Principal" | Pegue o código em `docker compose logs app \| grep setup` ou com `docker compose exec app npm run create-admin-code` |
| Porta 80/443 bloqueada | No painel da Hostinger, em Firewall da VPS, libere as portas 22, 80 e 443 |

## Comandos úteis

```bash
cd /opt/MEU_ASSISTENTE_COMPLETO
docker compose ps            # situação
docker compose logs -f app   # logs ao vivo (Ctrl+C para sair)
docker compose restart app   # reiniciar o app
docker compose down          # parar tudo (os dados ficam guardados)
docker compose up -d         # ligar de novo
bash deploy/scripts/smoke-test.sh
```
