# Checklist — Publicação no GitHub e implantação na VPS

## Antes de enviar ao GitHub
- [ ] O repositório é **privado**.
- [ ] Não existe arquivo `.env` no ZIP (só o `.env.example`). Confira com `unzip -l MEU_ASSISTENTE_COMPLETO.zip | grep "\.env"`; deve aparecer apenas `.env.example`.
- [ ] Nenhuma chave real (IA, Resend, senha do banco) foi colocada em arquivos do projeto.
- [ ] Não há pastas `node_modules/`, `dist/` nem `backups/` no ZIP.
- [ ] Guardou uma cópia do `meuassistent-main.zip` original.

## Preparação da VPS
- [ ] Ubuntu 22.04/24.04 instalado, com pelo menos 2 GB de RAM.
- [ ] Portas 22, 80 e 443 liberadas no firewall da Hostinger.
- [ ] Domínio apontando para o IP (registros A de `@` e `www`), se for usar HTTPS.
- [ ] Chave de IA em mãos (opcional na instalação).
- [ ] Chave do Resend e e-mail remetente (opcional).

## Instalação
- [ ] Projeto descompactado em `/opt/MEU_ASSISTENTE_COMPLETO`.
- [ ] `sudo bash deploy/scripts/install.sh` concluído sem erro.
- [ ] `bash deploy/scripts/smoke-test.sh` mostrou **7 OK**, incluindo "API e banco PostgreSQL".
- [ ] O site abre pelo domínio com cadeado (HTTPS).
- [ ] O `.env` tem permissão restrita: `ls -l .env` deve mostrar `-rw-------`.

## Primeiro uso
- [ ] Criou a primeira conta, que virou o Administrador Principal.
- [ ] Ativou a verificação em duas etapas no Perfil.
- [ ] O chat respondeu e registrou um gasto de teste (requer `AI_API_KEY`).
- [ ] Criou uma tarefa na Agenda e um lembrete para daqui a 2 minutos, e a notificação apareceu.
- [ ] Recuperação de senha enviou o e-mail (requer Resend).
- [ ] Instalou o app no celular ("Adicionar à tela inicial"), o que requer HTTPS.

## Operação
- [ ] O backup diário está ativo: `crontab -l` deve mostrar `meu-assistente-backup`.
- [ ] Testou `bash deploy/scripts/backup.sh` e viu o arquivo em `backups/`.
- [ ] Copia os backups para fora da VPS periodicamente.
- [ ] Sabe atualizar com `sudo bash deploy/scripts/update.sh`.

## Pendências conhecidas (módulos não reconstruídos)
- [ ] Planos e Mercado Pago, fiscal/DAS, mercado/B3, estúdio, eleições, push, áudio/foto no chat, e-mails, WhatsApp, treinos, alimentação, remédios, mapas e espaços compartilhados. Veja docs/RELATORIO_RECONSTRUCAO.md, seção 4.
- [ ] Se ainda tiver acesso à Netlify, exporte os dados antigos (Netlify Blobs) para uma futura importação.
