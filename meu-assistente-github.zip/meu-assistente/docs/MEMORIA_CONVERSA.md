# Memória contextual por conversa

## Duas camadas
- **Memória geral do usuário**: Cérebro Próprio e memória do perfil (inalteradas).
- **Memória de cada conversa**: tabela `conversation_context` (migração 017), uma linha por conversa,
  sempre ligada ao dono da conversa. Guarda assunto atual, agendamento em andamento (campos já informados e o que falta),
  último registro citado e as últimas ações executadas. Conversas diferentes não se misturam.

## Motor (src/ai/convctx.ts) — funciona sem IA
- Agendamento em partes: "quero marcar uma reunião" → "amanhã" → "às 10h no escritório". Pergunta só o que falta.
- Referências: "aquela reunião", "que horas é aquele compromisso?", "remarca para as 11h", "cancela essa reunião" (com confirmação).
- Retomada: "sobre o que conversamos?", "quero continuar", "onde paramos" — mesmo dias depois (tudo vem do banco).
- "Conseguiu agendar?": confere o registro no banco antes de responder.
- Antes de gravar, procura o mesmo compromisso no mesmo dia e horário e não duplica.
- Só confirma depois de ler de volta o que foi salvo.

## Data e horário
- Datas relativas ("amanhã", "sexta", "dia 28") calculadas no fuso do usuário.
- Quando a IA cria o compromisso, a data e o horário ditos pelo usuário substituem os calculados pela IA
  (src/ai/assistant.ts, `create_appointment`). O cartão, a agenda e as consultas leem o mesmo registro.

## IA auxiliar
A IA (Ollama ou outra) recebe só um resumo da memória da conversa para não perguntar de novo; as ações não dependem dela.
