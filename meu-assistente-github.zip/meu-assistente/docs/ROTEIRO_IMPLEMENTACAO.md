# Situação e roteiro de implementação

## Funciona hoje no servidor (testado: 58/58 testes automáticos)
Cadastro, login, verificação em duas etapas, recuperação de senha, perfil, chat com IA (gastos, tarefas, compromissos, lembretes, compras, notas, contas), memória, agenda, financeiro, Meu Dia, notificações internas, modo offline, painel admin (Usuários e Atividades), backup e deploy com Docker.

## Aprovado no protótipo, a implementar no servidor
| Etapa | Conteúdo | Situação |
|---|---|---|
| 1a | **Painel** (`/painel`): módulos globais, várias IAs com troca automática **no chat real**, fontes de mercado grátis com troca automática e cotação real (`/api/v2/market/quote`), credenciais do Mercado Pago cifradas, planos de anúncio, ajustes do cérebro, raio de busca e parâmetros fiscais | **pronto** |
| 1b | Leitura de imagem, Cérebro (memória e respostas aprendidas), roteador de intenções, áudio | a fazer |
| 2 | Módulos globais, Mercado Pago, planos e anúncios, página Anunciar original | a fazer |
| 3 | Empresas, localização com permissão, lojas, produtos com fotos, pedidos, Sua empresa | a fazer |
| 4 | Impostos/DAS, Mercado com fontes grátis e alertas, push no celular | a fazer |
| 5 | Teste completo e publicação final | a fazer |

Cada etapa é entregue como atualização deste repositório, com testes automáticos e roteiro de checagem na VPS.
