# Situação e roteiro de implementação

## Funciona hoje no servidor (testado: 67/67 testes automáticos)
Cadastro, login, verificação em duas etapas, recuperação de senha, perfil, chat com IA (gastos, tarefas, compromissos, lembretes, compras, notas, contas), memória, agenda, financeiro, Meu Dia, notificações internas, modo offline, painel admin (Usuários e Atividades), backup e deploy com Docker.

## Aprovado no protótipo, a implementar no servidor
| Etapa | Conteúdo | Situação |
|---|---|---|
| 1a | **Novas abas no painel administrativo original** (`/admin`): módulos globais, várias IAs com troca automática **no chat real**, fontes de mercado grátis com troca automática e cotação real (`/api/v2/market/quote`), credenciais do Mercado Pago cifradas, planos de anúncio, ajustes do cérebro, raio de busca e parâmetros fiscais | **pronto** |
| 1b | Leitura de imagem, Cérebro (memória e respostas aprendidas), roteador de intenções, áudio | a fazer |
| 2 | **Anúncios**: criar anúncio escolhendo o plano (`/x/anunciar`), Sua empresa (`/x/sua-empresa`), aprovação na aba Anúncios do painel, pagamento Pix pelo Mercado Pago com confirmação automática (webhook `/api/mercadopago/webhook`) e avisos por notificação | **pronto** |
| 3 | **Empresas perto de você** (`/x/empresas`, pede localização), busca no chat por ramo e raio, página da empresa e **loja** (`/x/empresa/:id`) com produtos, fotos e variações, carrinho e pedido; **Meus pedidos** (`/x/pedidos`); painel da loja em Sua empresa (pedidos, produtos, entrega e pagamento); notificações a cada etapa | **pronto** |
| 4a | **Mercado** (`/x/mercado`: cotações reais, gráficos 24h/7/30/90 dias, alertas com notificação) e **Impostos e DAS** (`/x/impostos`: DAS pelo salário mínimo, faturamento e limite, guias, avisos), itens no menu do app e respostas no chat com dados reais | **pronto** |
| 4b | Notificações push no celular | a fazer |
| 5 | Teste completo e publicação final | a fazer |

Cada etapa é entregue como atualização deste repositório, com testes automáticos e roteiro de checagem na VPS.
