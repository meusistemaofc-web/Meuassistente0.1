# Situação e roteiro de implementação

## Funciona hoje no servidor (testado: 75/75 testes automáticos)
Cadastro, login, verificação em duas etapas, recuperação de senha, perfil, chat com IA (gastos, tarefas, compromissos, lembretes, compras, notas, contas), memória, agenda, financeiro, Meu Dia, notificações internas, modo offline, painel admin (Usuários e Atividades), backup e deploy com Docker.

## Aprovado no protótipo, a implementar no servidor
| Etapa | Conteúdo | Situação |
|---|---|---|
| 1a | **Novas abas no painel administrativo original** (`/admin`): módulos globais, várias IAs com troca automática **no chat real**, fontes de mercado grátis com troca automática e cotação real (`/api/v2/market/quote`), credenciais do Mercado Pago cifradas, planos de anúncio, ajustes do cérebro, raio de busca e parâmetros fiscais | **pronto** |
| 1b | Leitura de imagem, Cérebro (memória e respostas aprendidas), roteador de intenções, áudio | a fazer |
| 2 | **Anúncios**: criar anúncio escolhendo o plano (`/x/anunciar`), Sua empresa (`/x/sua-empresa`), pagamento Pix pelo Mercado Pago gerado na hora (QR Code e copia e cola), confirmação automática que envia para aprovação, aprovação na aba Anúncios do painel que coloca no ar (webhook `/api/mercadopago/webhook`) e avisos por notificação | **pronto** |
| 3 | **Empresas perto de você** (`/x/empresas`, pede localização), busca no chat por ramo e raio, página da empresa e **loja** (`/x/empresa/:id`) com produtos, fotos e variações, carrinho e pedido; **Meus pedidos** (`/x/pedidos`); painel da loja em Sua empresa (pedidos, produtos, entrega e pagamento); notificações a cada etapa | **pronto** |
| 4a | **Mercado** (`/x/mercado`: cotações reais, gráficos 24h/7/30/90 dias, alertas com notificação) e **Impostos e DAS** (`/x/impostos`: DAS pelo salário mínimo, faturamento e limite, guias, avisos), itens no menu do app e respostas no chat com dados reais | **pronto** |
| 4b | Notificações push no celular | a fazer |
| 3b | Painel: Páginas e links para compartilhar, Botões do chat (ocultar e criar), teste de conexão do Mercado Pago; Sua empresa no menu de quem anuncia com link do catálogo; página da empresa abre sem login; localização por endereço e raio do usuário; voz desligada some do app | **pronto** |
| 3c | **Biblioteca de Sobrevivência**: 6 materiais iniciais (água, primeiros socorros, enchentes, mochila, falta de energia, incêndio), baixados pelo app para uso sem internet (`/api/kb-offline`), e aba Biblioteca SOS no painel para cadastrar, editar, ocultar e excluir | **pronto** |
| 3d | Loja: **logo e capa** personalizáveis; pagamento **manual** (Pix pela chave, cartão ou dinheiro na entrega/retirada) e **automático** com o Mercado Pago da própria loja (Pix gerado no pedido, confirmação pelo webhook, pedido chega marcado como pago) | **pronto** |
| 3e | Chat com cartões (empresas com logo, descrição e botões; mercado com gráfico 24h/7/30/90 dias; botões no lugar de links), Sua empresa em formato de perfil com menu no rodapé, horário de funcionamento automático e botão abrir/fechar, contadores de pedidos no menu, aviso no topo, atualização puxando a tela sem erro | **pronto** |
| 5c | **Planos de uso**: limite diário grátis e por plano para chat, compromissos, tarefas, lembretes, gastos, contas, anotações e compras; assinatura por Pix com liberação automática (Menu → Meu plano); painel Planos de uso. Também: Menu do app (ordenar/ocultar sem desligar), Anúncio no chat com frequência configurável, ícones em Sua empresa | **pronto** |
| 3f | Anúncio encerrado mantém os dados e pode **subir novamente** escolhendo o plano; entrega **por km** (grátis até X km, taxa ao passar + valor por km); **Motor do chat** configurável (naturalidade, personalidade, criatividade, contexto, autonomia, precisão); **Agente de atendimento** das empresas com plano próprio, Pix e link público `/a/:id` | **pronto** |
| 3g | **Relatórios e acessos** em Sua empresa (impressões, visitas, contatos, pedidos, conversas do agente, faturamento, ticket, produtos, análise com IA, lançamento no MEI); **avisos de vencimento** de anúncio, agente e plano (7, 3, 1 dia antes, no dia, 1 e 3 dias depois); agente com horário detalhado | **pronto** |
| 5a | Voz com várias APIs grátis e troca automática (transcrição e fala) | a fazer |
| 5b | Planos de assinatura do Meu Assistente com Mercado Pago | a fazer |
| 5 | Teste completo e publicação final | a fazer |

Cada etapa é entregue como atualização deste repositório, com testes automáticos e roteiro de checagem na VPS.
