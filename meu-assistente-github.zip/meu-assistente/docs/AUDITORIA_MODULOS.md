# Auditoria de módulos (rotas chamadas pelo app × servidor)

Varredura automática de todas as chamadas `/api/...` do app (frontend compilado) contra as rotas do servidor.

## Corrigidos nesta etapa
- **Financeiro → Mercado Pago**: conexão real da conta pelo OAuth oficial (Client ID/Secret em Painel → Mercado Pago),
  pagamentos recebidos pela API oficial `/v1/payments/search`, renovação do token, desconexão. Sem dados simulados.
- **Financeiro → DAS** e **Calendário fiscal (/fiscal)**: abrem o módulo reconstruído **Impostos e DAS** (/x/impostos),
  com faturamento, limite anual, valores do DAS e lembretes reais.
- **/mercado, /planos, /anunciar**: abrem os módulos reconstruídos (/x/mercado, /x/planos, /x/anunciar).

## Ainda sem servidor (fora dos menus e do chat; o endereço direto volta ao chat com aviso)
Treinos, Alimentação, Estúdio (vídeos), Espaço (arquivos compartilhados), E-mails (leitor de caixa), Eleições/Campanha,
Integrações MCP, Mapas offline. Também: medicamentos e notícias (cartões antigos), WhatsApp do perfil, foto de perfil,
gravações de voz antigas, abas antigas do admin (billing, knowledge, labs, resources, whatsapp, eleições).
Cada um precisa de reconstrução própria (banco, APIs e telas); nenhum mostra tela de demonstração.
