# Cérebro por condições e velocidade do chat

## Causa raiz
1. **Conhecimento devolvido em bloco, sem avaliar condições.** A busca achava o conhecimento certo, mas devolvia o texto inteiro.
   Sem IA, "compra de R$ 100" recebia as quatro regras juntas; com IA, o modelo precisava interpretar o bloco e errava
   ("não consigo consultar detalhes da compra", porque tratava a pergunta hipotética como um pedido real).
2. **Variações de palavras não casavam.** "retirar pessoalmente" não encontrava "Retirada no estabelecimento"; sem conhecimento,
   a pergunta ia para a IA, que inventou que a loja era só online.
3. **Lentidão = caminho da IA.** O backend sem IA responde em dezenas de milissegundos. A demora vinha das perguntas que o Cérebro
   não resolvia e caíam na IA: até 25 s por tentativa, até 70 s no total e até 5 rodadas — com Ollama em CPU no VPS de 4 GB.
4. Cada mensagem relia até 5000 linhas do Cérebro do banco.

## Correção (src/ai/knowledge.ts — novo)
- Conhecimento dividido em **cláusulas**; pergunta comparada por palavra, radical, prefixo e **sinônimos comerciais**
  (entrega/frete/envio, retirada/buscar/pegar/pessoalmente, grátis/de graça/sem custo, prazo/quantos dias...).
- **Condições avaliadas**: "acima de", "mais de", "a partir de", "abaixo de", "menos de", "até", "entre X e Y" contra o valor da pergunta.
  Valor exatamente no limite sem regra → responde que o conhecimento não define esse caso e mostra as regras (não inventa).
- **Pergunta hipotética × pedido real**: "se eu comprar R$ 100" vai para as regras; "meu pedido #12 chegou?" não usa as regras.
- Resposta sempre com o **texto cadastrado**.
- **Cache** dos conhecimentos ativos com **índice invertido**; invalidado automaticamente quando qualquer item do Cérebro muda.
- Para a IA (quando chamada): recebe só as cláusulas já avaliadas e a proibição explícita de inventar informações comerciais.

## Velocidade
- Cérebro, cálculo, memória da conversa e motores internos respondem antes de qualquer IA.
- **Prazo total da IA por mensagem** (padrão 30 s, ajustável no painel em ai_router.prazoChatMs): ao estourar, responde com o conhecimento
  relacionado ou com uma mensagem honesta, sem deixar o usuário esperando.

## Rastreabilidade
Cada mensagem mede: conversa e histórico, interpretação e motores internos, atalhos, recuperação de conhecimento, IA, montagem,
gravação e entrega. Painel → Cérebro e busca → **Velocidade do chat** (média, p95, máximo, por origem e as 10 mais lentas).
Mensagens acima de 4 s também aparecem no log do servidor como `[chat lento]`.
