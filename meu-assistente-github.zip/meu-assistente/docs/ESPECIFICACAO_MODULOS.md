# Especificação técnica dos módulos — Meu Assistente

Referência visual e de comportamento: `prototipo/index.html`.
Base técnica: servidor Node.js 22 + TypeScript (`server/`), PostgreSQL 16, frontend original compilado (`frontend/public`).
Regra geral: **as telas que já existem no frontend original são reativadas implementando os contratos de API que elas chamam**; as telas que não existem no original (Sua empresa, loja da empresa, Fontes de mercado, Cérebro) entram como páginas novas com o mesmo CSS do original.

## 1. Papéis e acessos

| Papel | Quem | Acessa |
|---|---|---|
| `superadmin` | primeira conta criada | tudo, inclusive outros administradores |
| `admin` | criado pelo superadmin | abas do painel conforme permissões (`users.view`, `users.manage`, `audit.view`, `integrations.manage`, `interface.manage`, `brain.*`, `billing.manage`, `ads.manage`) |
| `user` | usuário comum | o próprio chat e dados; módulo **Sua empresa** quando for dono de um anúncio |
| dono de empresa | `user` com `businesses.owner_id = user.id` | painel da própria empresa (pedidos, produtos, detalhes, entrega/pagamento, registros) |
| visitante | sem login | Conheça, Anunciar, página pública e loja de empresas ativas |

Toda rota valida sessão (cookie HttpOnly), papel/permissão e propriedade do registro. Ações de administrador e de dono de empresa geram `audit_log`.

## 2. Módulos globais
- Tabela `app_config` chave `modules` → `{catalogo, anuncios, financas, lembretes, imagens, voz, fiscal, mercado}`.
- `GET /api/me` devolve os módulos ativos; o servidor recusa (403 `module_disabled`) chamadas de módulo desligado.
- Painel: aba **Módulos** (`interface.manage`).

## 3. Inteligência artificial com troca automática
- Tabela `ai_providers` (`id, name, kind[openai-compatible|gemini|ollama], base_url, model, api_key_enc, use_text, use_image, priority, enabled, status, cooldown_until, last_error, uses, failures`).
- Chaves cifradas com `APP_SECRET` (AES-256-GCM); a tela só mostra a chave mascarada.
- Ordem por `priority`. Falha 429 → `cooldown` 60 s; 401/403 → `status=expired` até nova chave; 5xx/timeout → `cooldown` 30 s; passa para a próxima.
- Mensagem com imagem só vai para provedores `use_image`.
- Rotas: `GET/POST /api/admin/ai` (listar, salvar, ordenar, testar, reativar).
- Referência pronta: `tools/ia-gateway/` (gateway funcional com o mesmo comportamento).

## 4. Cérebro do Chat (motor próprio)
- Tabelas `brain_facts` (memórias por usuário), `brain_answers` (pergunta, pergunta_normalizada, resposta, origem, usos, nota, revisada).
- Ordem de resposta do chat (motores): 1) fatos do usuário, 2) motores do app (empresas, mercado, impostos, finanças, lembretes, pedidos), 3) respostas aprendidas com similaridade ≥ 0,75, 4) IAs externas. A resposta da IA a perguntas gerais é guardada para reutilização.
- O cérebro é memória e conhecimento acumulado; não há retreino de modelo (inviável na KVM1 e vedado pelos termos dos provedores).
- Rotas: `GET/POST /api/admin/brain`, `GET/POST /api/memory` (já existe).

## 5. Interpretação do chat (roteador de intenções)
Executado no servidor antes de chamar qualquer IA:
1. Normalização (minúsculas, sem acentos; `crypto/criptos/criptomoedas` → `cripto`; `ação/ações` → `acoes`).
2. Alerta de preço (“me avise se X chegar a R$ Y”).
3. Mercado: ticker ou nome conhecido (BTC, bitcoin, PETR4…) → cotação + gráfico; `cripto`, `bolsa`, `ações`, “como está o mercado” → resumo; palavras ambíguas (sol, vale) só com contexto.
4. Impostos/DAS e declarações.
5. Receitas (“recebi/vendi/faturei”) — só com permissão do usuário.
6. Sua empresa (“pedidos da minha empresa”).
7. Busca de empresas por ramo (exige permissão de localização).
8. Finanças e lembretes (ferramentas da IA já reconstruídas).
Verbos de dinheiro (gastei, paguei, comprei) nunca disparam busca de empresas.

## 6. Mercado (cripto e B3) com fontes grátis e troca automática
- Tabela `market_providers` (`id, name, category[cripto|bolsa], url_template, price_path, api_key_enc, needs_key, priority, enabled, status, cooldown_until, last_error, uses, failures, custom`).
- Fontes padrão — cripto: CoinGecko (sem chave), CoinPaprika (sem chave), Binance dados públicos (sem chave), CoinCap (chave grátis); B3: brapi.dev (token grátis), Yahoo Finance (sem chave, não oficial), Alpha Vantage (chave grátis), Twelve Data (chave grátis).
- Fonte personalizada: URL com `{SIMBOLO}`, `{id}`, `{chave}` + caminho JSON do preço.
- Cache por ativo: 60 s (cotação) e 15 min (séries de 7/30/90 dias), para não gastar limites.
- Tabela `market_alerts` (usuário, ativo, condição, valor, disparado_em) verificada pelo agendador; dispara notificação.
- Rotas: `GET /api/market/quote?s=`, `GET /api/market/series?s=&range=24h|7d|30d|90d`, `GET /api/market/summary?cat=`, `GET/POST/DELETE /api/market/alerts`, `GET/POST /api/admin/market-providers`.
- A tela Mercado original é reativada com esses dados.

## 7. Impostos e DAS (MEI)
- Tabela `fiscal_profiles` (usuário, atividade, abertura, consentimento, avisos) e `fiscal_revenue` (usuário, mês, valor), `fiscal_das_paid`.
- Parâmetros ajustáveis pelo admin em `app_config.fiscal`: salário mínimo (2026: R$ 1.621), INSS 5% (12% transportador), ICMS R$ 1, ISS R$ 5, limite anual (R$ 81.000; verificar mudança prevista para 2027).
- Consentimento obrigatório para usar receitas do chat; revogável.
- Agendador: aviso N dias antes do dia 20; DASN-SIMEI em maio; IR quando configurado.
- Rotas: `GET/POST /api/fiscal`, `/api/das` (contratos do frontend original).

## 8. Anúncios, planos e Mercado Pago
- Tabelas `ad_plans` (nome, nível 1–4, dias, preço, ativo), `businesses` (dono, empresa, ramo, palavras, contatos, endereço, horário, sobre, logo, capa, lat, lng, alcance_km, plano, status[analise|ajustes|recusado|aprovado|ativo], vence_em, motivo, protocolo), `business_logs`.
- Níveis: 1 anúncio; 2 + WhatsApp/Instagram; 3 + página da empresa; 4 + loja e pedidos.
- Fluxo igual ao original: proposta → análise → aprovação → pagamento (Pix Mercado Pago) → ativo até `vence_em`.
- Mercado Pago: credenciais teste/produção cifradas em `app_config.mercadopago`; webhook `POST /api/mercadopago/webhook` validando assinatura (segredo); idempotência por `payment_id`.
- Rotas: `/api/anunciar` (contrato da página original), `/api/admin/ads`, `/api/admin/billing`, `/api/mercadopago`.
- Cartão patrocinado no chat: no máximo 1 por conversa, nunca no Modo Voz, sempre marcado “Anúncio”.

## 9. Empresas, lojas e pedidos
- Tabelas `products` (empresa, nome, descrição, categoria, preço, variações JSON, fotos [1–2], ativo), `orders` (número, empresa, cliente, itens JSON, subtotal, taxa, total, modo[entrega|retirada], endereço, pagamento, troco, status, motivo), `order_events`.
- Busca: Haversine em SQL, filtro `distância ≤ alcance_km da empresa` e `≤ raio máximo do admin`; só empresas `ativo` e dentro da validade; ordenação por distância.
- Localização do usuário só com permissão do navegador; sem permissão, o chat pede antes de buscar.
- Status do pedido: novo → aceito → em preparo → saiu para entrega | pronto para retirar → concluído; recusar/cancelar com motivo. Cada mudança notifica o cliente.
- Rotas: `GET /api/businesses/search?q=&lat=&lng=`, `GET /api/businesses/:id` (página pública), `POST /api/orders`, `GET/POST /api/my-business/*` (dono), `GET /api/admin/businesses`.
- Imagens: upload com limite de tamanho, conversão para WebP e armazenamento em disco (`/data/uploads`) ou S3/R2.

## 10. Notificações, áudio e offline
- Central de notificações: já reconstruída. Push no celular: `web-push` + chaves VAPID (`/api/push`).
- Áudio: transcrição por provedor configurável (Groq Whisper grátis com limite, ou whisper.cpp na VPS); `POST /api/transcribe`.
- Offline: o app original já guarda no aparelho e sincroniza por `POST /api/sync` (reconstruído).

## 11. Variáveis novas (.env)
`APP_SECRET` (cifrar chaves), `UPLOAD_DIR`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`. As chaves de IA, mercado e Mercado Pago são cadastradas no painel, não no .env.
