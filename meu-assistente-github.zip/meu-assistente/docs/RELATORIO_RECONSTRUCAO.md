# Relatório de Reconstrução — Meu Assistente

Data: 06/11/2026 · Entrada: `meuassistent-main.zip` (preservado intacto; nenhuma alteração no original).

## 1. Auditoria do ZIP original

### 1.1 O que existia
O ZIP tem 140 arquivos (6,4 MB) e contém **apenas o frontend já compilado**:

- `assets/` — 90 arquivos JavaScript/CSS gerados pelo Vite. É um app React 19 com TanStack Router/Start, com mapas MapLibre.
- `sw.js`, `offline.html`, `offline.js` e `manifest.webmanifest` — PWA com modo offline e push.
- `brand/`, `icons/`, `images/`, `favicon.ico` — identidade visual.
- `netlify.toml` — build (`vite build` → `dist/client`) e cabeçalhos de segurança.

### 1.2 O que NÃO existia (ausente)
- **Código-fonte** (`src/`), `package.json`, `vite.config`. O `netlify.toml` cita `src/server.ts` e `src/server/security/headers.ts`, que não estão no ZIP.
- **Todo o backend.** Ele era o servidor TanStack Start executado nas **Netlify Functions**.
- **`index.html`.** As páginas eram geradas no servidor (SSR), então não há página inicial estática.
- **Banco de dados.** As telas citam **Netlify Blobs** (armazenamento chave-valor, store `nexa-config`). Não havia Supabase nem PostgreSQL.
- **Funções agendadas** (lembretes, resumo diário) e o **Netlify AI Gateway** (IA).

### 1.3 Defeito grave no ZIP
Os 90 arquivos de `assets/` estavam com **nomes em minúsculas** (ex.: `index-muczwl3l.js`). O código importa os nomes com maiúsculas (ex.: `index-MUcZwl3l.js`). Num servidor Linux, isso faria **o app inteiro falhar com erro 404**.

**Corrigido:** os 90 arquivos foram renomeados a partir das referências encontradas no próprio código. Todas as 90 referências foram resolvidas, sem colisão e sem nenhum arquivo faltando.

### 1.4 Tamanho do sistema original
- 28 telas.
- Cerca de 50 grupos de endpoints `/api`.
- Mais de 100 ações diferentes.

Integrações citadas: ElevenLabs (voz), Resend (e-mail), Mercado Pago (planos), Gemini/AI Gateway, CoinGecko/B3, WhatsApp Oficial e MCP.

### 1.5 Dependências da Netlify encontradas

| Dependência | Substituição |
|---|---|
| Netlify Functions (servidor TanStack Start) | Servidor Node.js próprio (`server/src/app.ts`) |
| SSR do TanStack Start (sem `index.html`) | `frontend/public/index.html` com inicialização no navegador (testado) |
| Netlify Blobs (dados e `setup-code`) | PostgreSQL com migrações (`server/migrations`) |
| Netlify AI Gateway | Provedor configurável compatível com OpenAI (`AI_BASE_URL`/`AI_API_KEY`) |
| Scheduled Functions | Agendador interno a cada 30 s (`server/src/scheduler.ts`) |
| Variáveis de ambiente da Netlify | Arquivo `.env` (modelo em `.env.example`) |
| Cabeçalhos do `netlify.toml` | Enviados pelo servidor e pelo Nginx |
| `netlify blobs:get nexa-config setup-code` | Código exibido no log ou via `npm run create-admin-code` |

Restam no frontend compilado **textos** que citam a Netlify (por exemplo, a dica da tela "Configuração inicial"). Não foram alterados porque exigiriam editar o código compilado. **Nenhum deles é necessário para o funcionamento.**

## 2. Arquitetura nova

```
Navegador (PWA original) ──HTTPS──> Nginx (VPS) ──> app Node.js :3000 ──> PostgreSQL 16
                                                     │  ├─ API REST /api/*
                                                     │  ├─ arquivos do frontend + fallback de rotas
                                                     │  └─ agendador (lembretes/avisos)
                                                     └─> IA (API compatível com OpenAI) · Resend (e-mail)
```

- **Backend:** Node.js 22 + TypeScript, servidor HTTP nativo e uma única dependência (`pg`).
- **Segurança:**
  - senhas com hash **scrypt**
  - sessão em cookie **HttpOnly + SameSite=Lax** (Secure com HTTPS), com só o hash SHA-256 do token gravado no banco
  - verificação em duas etapas (TOTP + códigos de recuperação) e reconfirmação de senha para ações sensíveis
  - limite de tentativas, bloqueio de requisições de outra origem (CSRF) e validação de todos os campos
  - nenhum segredo no código
- **Banco:** tabelas `users`, `sessions`, `password_resets`, `app_config`, `conversations`, `messages`, `memories`, `items`, `notifications`, `audit_log`, `sync_ops` e `schema_migrations`. Têm chaves estrangeiras com exclusão em cascata, índices, restrições (CHECK) e migrações automáticas e idempotentes.
- **Contratos:** todas as rotas reconstruídas seguem exatamente o formato que o frontend compilado envia e espera. Esse formato foi lido do próprio código, incluindo erros no padrão `{error, code, field}` e códigos como `auth_required`, `reauth_required` e `account_disabled`.

## 3. O que foi reconstruído e funciona

| Módulo | Endpoints | Situação |
|---|---|---|
| Cadastro, login, logout, sessão | `GET/POST /api/auth` (`signup`, `login`, `logout`, `session`) | ✅ Testado |
| Verificação em duas etapas | `mfa_begin`, `mfa_enable`, `mfa_login`, `mfa_disable`, `mfa_backup_codes`, `reauth`, `security_status`, `security_policy` | ✅ Testado |
| Recuperação e troca de senha | `recover`, `recovery`, `password`, `sessions_end_others` | ✅ Testado (e-mail via Resend) |
| Administrador Principal | primeira conta automática + `setup` com código | ✅ Testado |
| Exclusão de conta | `delete_account` | ✅ Testado (apaga tudo em cascata) |
| Perfil e configurações | `GET/PATCH /api/me` | ✅ Testado |
| Chat com IA | `GET/POST/DELETE /api/chat`, `GET/PATCH/DELETE /api/conversations` | ✅ Testado: a IA grava gastos, tarefas, compromissos, lembretes, compras, notas e contas, conclui tarefas e mostra os cartões originais |
| Memória do assistente | `GET/POST /api/memory` | ✅ Testado (recusa senhas) |
| Agenda | `GET /api/agenda`, `POST /api/items` | ✅ Testado |
| Financeiro | `GET /api/finance` | ✅ Testado: saldo, categorias, série de 6 meses, contas recorrentes e parceladas |
| Meu Dia | `GET /api/day`, `GET /api/summary` | ✅ Testado |
| Notificações | `GET/POST /api/notifications` + agendador | ✅ Testado (lembretes recorrentes, avisos de compromisso, contas do dia) |
| Modo offline | `POST /api/sync` | ✅ Testado (idempotente) |
| Painel admin | `GET /api/admin`, `/api/admin/users`, `/api/admin/audit` | ✅ Testado (abas Usuários e Atividades) |
| Avatar do assistente | `GET /api/assistant-avatar` | ✅ |
| Saúde do sistema | `GET /api/health` | ✅ |

## 4. O que NÃO pôde ser recuperado (e por quê)

O código do servidor desses módulos não existia no ZIP. O frontend mostra o que é enviado, mas não as **regras de negócio**: cálculos fiscais, regras de cobrança, fontes de cotação, roteiros de vídeo e política de anúncios. Reconstruí-los "adivinhando" violaria a regra de não inventar implementações.

Por isso, esses endpoints respondem **501 `not_reconstructed`** com o nome do módulo. Os recursos correspondentes também ficam fora do plano informado ao app (`/api/me`), e a interface os trata como indisponíveis.

| Módulo | Endpoints | Alternativa técnica proposta |
|---|---|---|
| Planos, assinaturas e Mercado Pago | `/api/billing`, `/api/mercadopago`, `/api/admin/billing` | Reconstruir com a API de Assinaturas do Mercado Pago + webhook (precisa das regras dos planos e das credenciais) |
| Calendário fiscal e DAS MEI | `/api/fiscal`, `/api/das` | Precisa das regras fiscais que você quer aplicar |
| Mercado, carteira e B3 | `/api/market`, `/api/b3` | Integrar CoinGecko e um provedor de cotações B3 |
| Estúdio de vídeo | `/api/studio` | Precisa de provedores de imagem, voz e renderização |
| Eleições 2026 e campanha | `/api/eleicoes`, `/api/campanha`, `/api/admin/eleicoes` | Conteúdo e moderação específicos |
| Notificações push no celular | `/api/push` | Biblioteca `web-push` + chaves VAPID (a central de notificações já funciona) |
| Áudio, foto e voz | `/api/transcribe`, `/api/tts`, `/api/voice`, envio multipart no chat | Whisper/OpenAI Audio e ElevenLabs. O ditado e a voz do próprio aparelho continuam funcionando |
| E-mails, WhatsApp, MCP | `/api/emails`, `/api/whatsapp`, `/api/mcp` | Integrações externas com credenciais próprias |
| Treinos, alimentação, remédios | `/api/training`, `/api/meals`, `/api/medications` | Modelos de dados extensos, reconstruíveis numa próxima etapa |
| Mapas, notícias, base de conhecimento | `/api/maps`, `/api/news`, `/api/kb-*` | Precisam de fontes de dados externas |
| Espaços compartilhados, convites, anúncios, recursos experimentais | `/api/spaces`, `/api/convite`, `/api/appointments`, `/api/ads`, `/api/anunciar`, `/api/labs` | Reconstruíveis numa próxima etapa |
| Foto de perfil | `/api/avatar` | Armazenamento de arquivos (disco ou S3/R2) |
| Abas extras do admin | integrações, cérebro, planos, anúncios, espaços | Dependem dos módulos acima |

**Dados antigos:** os dados dos usuários estavam no Netlify Blobs da conta original e não vieram no ZIP. Se você ainda tiver acesso ao projeto pausado na Netlify, eles podem ser exportados com `netlify blobs:list` e `netlify blobs:get` e importados com um script de migração (a fazer, quando houver o arquivo exportado).

## 5. Arquivos criados ou alterados

**Alterados:**
- `frontend/public/assets/*`: somente renomeados para os nomes corretos. O conteúdo está intacto.
- `netlify.toml`: movido para `original/`.

**Criados:**
- `frontend/public/index.html`.
- Todo o diretório `server/`.
- `Dockerfile`, `docker-compose.yml`, `.env.example`, `.gitignore` e `.dockerignore`.
- `deploy/nginx/meu-assistente.conf` e `deploy/scripts/*.sh`.
- `docs/*`.

## 6. Observações conhecidas

- No primeiro carregamento, o console mostra o aviso "React #418". Ele acontece porque o app foi compilado para ser gerado no servidor. O React se corrige sozinho e a tela funciona normalmente, como confirmado nos testes no navegador.
- Os testes automáticos rodaram com o SQLite embutido do Node, porque o ambiente de construção não tinha PostgreSQL. O mesmo SQL roda no PostgreSQL. Na VPS, o `smoke-test.sh` confirma a conexão real com o PostgreSQL (ver RELATORIO_TESTES.md).
