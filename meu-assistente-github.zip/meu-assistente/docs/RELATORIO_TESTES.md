# Relatório de Testes — Meu Assistente

Data da execução: 06/11/2026. Todos os testes abaixo foram **executados de verdade**. Nenhum resultado foi marcado sem rodar.

## Ambiente de teste e limitações (leia primeiro)

- **Node.js 22**, servidor HTTP real do projeto, requisições HTTP reais com cookies (como o navegador faz).
- **Banco:** o ambiente de construção **não tinha PostgreSQL, Docker nem internet**. Os testes usaram o SQLite embutido do Node 22, que executa **o mesmo SQL das migrações**, com tradução automática de 6 diferenças de dialeto (`server/src/db/sqlite.ts`). O adaptador PostgreSQL (`server/src/db/postgres.ts`) **não foi executado aqui**. Ele é verificado na VPS pelo `deploy/scripts/smoke-test.sh`, que confirma `"db":"postgres"`.
- **IA:** sem internet, a IA externa foi substituída por um **dublê de teste**: um servidor local que fala o mesmo protocolo da OpenAI e devolve chamadas de ferramenta. Isso valida todo o caminho real: prompt, chamada da ferramenta, **gravação no banco** e cartão na tela. A qualidade das respostas de um modelo real só pode ser avaliada com a sua chave de IA.
- **Docker, Nginx e scripts de instalação:** sintaxe validada (`bash -n`). Não foi possível executá-los aqui (sem Docker e sem VPS). O `smoke-test.sh` foi executado contra o servidor de teste.
- **TypeScript:** `tsc --noEmit` passou sem erros em todo o código.

## 1. Testes automatizados da API — 53/53 aprovados

Comando: `cd server && npm test` (arquivo `server/test/run.ts`).

| # | Teste | Resultado |
|---|---|---|
| 1 | migrações aplicadas do zero (001_init.sql) | ✅ Aprovado |
| 2 | migrações são idempotentes (2ª execução não reaplica) | ✅ Aprovado |
| 3 | GET /api/health responde com banco conectado | ✅ Aprovado |
| 4 | frontend: / e rotas do app devolvem o index.html com o bootstrap | ✅ Aprovado |
| 5 | frontend: assets com nome em maiúsculas/minúsculas corretos (index-MUcZwl3l.js) | ✅ Aprovado |
| 6 | frontend: asset inexistente devolve 404 (não o index.html) | ✅ Aprovado |
| 7 | cabeçalhos de segurança presentes | ✅ Aprovado |
| 8 | rota inexistente → 404 JSON; módulo não reconstruído → 501 explícito | ✅ Aprovado |
| 9 | proteção CSRF: POST de outra origem é recusado | ✅ Aprovado |
| 10 | GET /api/auth sem contas → firstAccount=true | ✅ Aprovado |
| 11 | rotas protegidas sem sessão → 401 auth_required | ✅ Aprovado |
| 12 | cadastro valida campos (nome, WhatsApp, senha) com "field" | ✅ Aprovado |
| 13 | primeira conta vira Administrador Principal e redireciona para /admin | ✅ Aprovado |
| 14 | cookie de sessão é HttpOnly + SameSite=Lax e o token não é gravado em texto puro | ✅ Aprovado |
| 15 | segunda conta é usuário comum | ✅ Aprovado |
| 16 | e-mail duplicado é recusado | ✅ Aprovado |
| 17 | senha guardada com scrypt (sem texto puro) | ✅ Aprovado |
| 18 | logout encerra a sessão no servidor | ✅ Aprovado |
| 19 | login com senha errada → 401; correta → 200; action session ok | ✅ Aprovado |
| 20 | limite de tentativas de login (429) | ✅ Aprovado |
| 21 | 2FA: ativar com TOTP, login exige código, código de recuperação funciona uma vez | ✅ Aprovado |
| 22 | recuperar senha: token de uso único troca a senha e derruba sessões | ✅ Aprovado |
| 23 | alterar senha exige a senha atual | ✅ Aprovado |
| 24 | PATCH /api/me salva perfil, configurações e ignora chaves desconhecidas | ✅ Aprovado |
| 25 | plano expõe apenas recursos reconstruídos | ✅ Aprovado |
| 26 | criar tarefa, compromisso, lembrete, compras e nota | ✅ Aprovado |
| 27 | validação: compromisso sem data é recusado (field=date) | ✅ Aprovado |
| 28 | GET /api/agenda devolve todos os grupos no formato do frontend | ✅ Aprovado |
| 29 | ações: concluir tarefa, marcar compra, fixar nota, adiar e concluir lembrete, alterar compromisso | ✅ Aprovado |
| 30 | permissão: um usuário não altera nem vê registros de outro (404) | ✅ Aprovado |
| 31 | excluir registro | ✅ Aprovado |
| 32 | lançar gasto e receita, cadastrar conta mensal | ✅ Aprovado |
| 33 | valor inválido é recusado (field=amount) | ✅ Aprovado |
| 34 | GET /api/finance calcula receitas, despesas, saldo, categorias e série | ✅ Aprovado |
| 35 | pagar conta mensal gera a próxima ocorrência; desfazer remove | ✅ Aprovado |
| 36 | GET /api/day e /api/summary com dados reais | ✅ Aprovado |
| 37 | mensagem simples cria conversa e grava as duas mensagens | ✅ Aprovado |
| 38 | "gastei 35 no almoço" → IA chama ferramenta, grava gasto real e devolve cartão | ✅ Aprovado |
| 39 | compromisso e tarefa pelo chat ficam na agenda | ✅ Aprovado |
| 40 | "lembre que..." salva memória visível no Perfil | ✅ Aprovado |
| 41 | memória recusa senhas | ✅ Aprovado |
| 42 | histórico: GET /api/chat?c= devolve as mensagens; lista e busca de conversas | ✅ Aprovado |
| 43 | editar e reenviar mensagem substitui a resposta anterior | ✅ Aprovado |
| 44 | renomear, fixar e excluir conversa | ✅ Aprovado |
| 45 | envio de áudio/foto (multipart) → 501 explícito, sem simulação | ✅ Aprovado |
| 46 | fila offline: cria, conclui e é idempotente | ✅ Aprovado |
| 47 | lembrete vencido gera notificação; recorrente avança para o dia seguinte | ✅ Aprovado |
| 48 | marcar todas como lidas | ✅ Aprovado |
| 49 | usuário comum não acessa o painel | ✅ Aprovado |
| 50 | Administrador Principal lista, cria, edita e desativa usuários (com auditoria) | ✅ Aprovado |
| 51 | admin com só "users.view" não pode criar usuários | ✅ Aprovado |
| 52 | dados continuam após reiniciar servidor e banco | ✅ Aprovado |
| 53 | excluir conta apaga dados (cascata) e encerra sessão | ✅ Aprovado |

## 2. Testes no navegador com o app original — 11/11 aprovados

Navegador Chromium (headless) usando o frontend original + backend novo, tela de celular 390×844. Capturas em `docs/capturas-teste/`.

| # | Roteiro | Resultado |
|---|---|---|
| 1 | Cadastro mostra aviso de primeira conta (Administrador Principal) | ✅ Aprovado |
| 2 | Após cadastro: painel admin com aba Usuários | ✅ Aprovado |
| 3 | Chat: mensagem enviada e cartão "Gasto registrado" exibido | ✅ Aprovado |
| 4 | Agenda: tarefa criada pela interface aparece na lista | ✅ Aprovado |
| 5 | Financeiro: gasto do chat aparece no resumo do mês | ✅ Aprovado |
| 6 | Meu Dia carrega sem erro (prioridades, gastos de hoje) | ✅ Aprovado |
| 7 | Notificações carrega | ✅ Aprovado |
| 8 | Perfil carrega dados reais da conta | ✅ Aprovado |
| 9 | Sessão continua após recarregar a página | ✅ Aprovado |
| 10 | Após logout, tela protegida redireciona para /entrar | ✅ Aprovado |
| 11 | Login pela interface funciona | ✅ Aprovado |

**Erros HTTP observados no navegador:**

- `501` em `/api/tts`, `/api/kb-offline`, `/api/maps/tile`, `/api/whatsapp`, `/api/das` e `/api/billing`. São chamadas em segundo plano a **módulos não reconstruídos**. São esperadas, não quebram as telas e estão documentadas no RELATORIO_RECONSTRUCAO.md.
- `401` logo após o logout. É o comportamento correto: as telas protegidas recusam acesso e redirecionam para /entrar.

**Avisos no console:**

- `React #418` (diferença de hidratação, já que o app foi compilado para SSR): o React se corrige sozinho e as telas funcionam.
- `ERR_NAME_NOT_RESOLVED`: as fontes do Google ficaram bloqueadas pela falta de internet no ambiente de teste. Na VPS, carregam normalmente.

**Falhas encontradas e corrigidas durante os testes:**

1. A tela **Meu Dia** quebrava porque `GET /api/day` sem período deve devolver a visão do dia (saudação, gastos, prioridades). **Corrigido e retestado.**
2. **`/api/assistant-avatar`** não estava mapeado (erro 404). **Implementado.**
3. O cartão de gasto mostrava a categoria interna `alimentacao` em vez de "Alimentação". **Corrigido.**
4. O teste de exclusão de conta esbarrou no **limite de tentativas de login**, um comportamento correto do servidor. O roteiro do teste foi ajustado.

## 3. Funcionalidades efetivamente aprovadas

- Autenticação: cadastro, login, logout, sessões, verificação em duas etapas, recuperação e troca de senha, Administrador Principal, exclusão de conta.
- Chat com IA gravando registros reais, histórico, busca, edição/reenvio, renomear, fixar e excluir conversas.
- Agenda (tarefas, compromissos, lembretes, compras, notas), Financeiro (gastos, receitas, contas, recorrência), Meu Dia e resumo diário.
- Notificações e agendador, memória do assistente, sincronização offline.
- Painel admin (usuários, funções, permissões, desativação, auditoria).
- Isolamento entre contas, persistência após reinicialização, migrações reproduzíveis.

## 4. Testes que você deve rodar na VPS

1. `bash deploy/scripts/smoke-test.sh`: deve mostrar 7 OK, incluindo "API e banco PostgreSQL".
2. No navegador: crie a primeira conta, envie "gastei 20 reais no café" no chat (requer `AI_API_KEY`) e confira o cartão e o Financeiro.
3. Recuperação de senha com `RESEND_API_KEY` configurada (confira o e-mail recebido).
4. `bash deploy/scripts/backup.sh` e restauração num momento sem uso.
5. Opcional: `cd server && npm install && npm test` na VPS repete os 53 testes automáticos.
