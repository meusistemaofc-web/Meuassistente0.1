# Auditoria do Cérebro — conhecimentos aprovados não eram usados

## Fluxo rastreado
Cadastro (Painel → Cérebro: "Novo conhecimento", "Ensinar o Cérebro", "Respostas aprendidas")
→ tabela **brain_answers** (mesma tabela para painel e chat; colunas kind, status, keywords, question_norm)
→ aprovação (`status = 'ativo'`) → recuperação `findKnowledge()` (src/ai/brain.ts)
→ uso no chat (`chatPostInner`, src/routes/chat.ts) e no teste de independência (`brainTestPost`, src/routes/panel.ts).
Não há outra tabela de conhecimento; brain_history guarda só o histórico.

## Causa raiz (reproduzida antes da correção)
1. `findKnowledge()` só buscava `kind IN ('conhecimento','instrucao','experiencia')`. O "Ensinar o Cérebro" classificava como
   **regra** qualquer texto com "sempre/nunca/jamais" nas primeiras palavras — ex.: "O estúdio sempre atende…". Aprovado, ficava
   `status='ativo'`, mas **fora da busca**. Respostas cadastradas pelo administrador (`kind='resposta'`) também ficavam fora.
2. A busca exigia palavras idênticas: "atendem" × "atendimento", plurais e variações não casavam.
3. Editar uma resposta no painel mudava `question`, mas não `question_norm` nem `keywords`: a resposta editada deixava de ser achada.
4. Não existia motor de cálculo: "2 + 2" caía em "precisaria de IA".

## Correções
- src/ai/brain.ts — `findKnowledge()` busca em todo conhecimento ativo (inclusive regras e respostas do administrador/revisadas),
  com radical das palavras e prefixo comum; `splitKnowledge()` só marca "regra" quando o texto começa como instrução.
- src/routes/panel.ts — `brainAnswerPut()` atualiza question_norm e keywords; `brainTestPost()` testa o cálculo primeiro e usa o mesmo
  limiar do chat, informando quantos itens ativos foram consultados.
- src/lib/math.ts (novo) — motor matemático interno (analisador próprio, sem eval) ligado ao chat antes dos demais motores.
- src/routes/chat.ts — cálculo antes de finanças/agenda/IA; erros da busca registrados no log.

## Evidências (IA desligada — modo "Sem IA")
Teste automático "auditoria do Cérebro com IA desligada" (134/134): 2+2=4, 100−35=65, 12×8=96, 150÷5=30, 20% de 500=100,
mais 5 multiplicações aleatórias conferidas com o resultado calculado; conhecimento com "sempre" aprovado respondido no chat;
resposta editada encontrada; **0 chamadas de IA**; nenhuma conta virou lançamento.
