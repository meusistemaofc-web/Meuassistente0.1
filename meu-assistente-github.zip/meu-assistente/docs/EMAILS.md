# Central de e-mails — o que o administrador precisa configurar

Painel → **E-mails**. Nada é simulado: o botão **Testar conexão** conecta de verdade e **Enviar teste** manda um e-mail real.

## Opção 1 — SMTP (recomendado para começar)
Serve para **Hostinger Email**, **Postfix na própria VPS** ou qualquer SMTP.
- Hostinger Email: servidor `smtp.hostinger.com`, porta `465` (SSL) ou `587` (STARTTLS), usuário = o e-mail completo, senha = senha da caixa (hPanel → E-mails).
- Remetente: use um e-mail **do mesmo domínio** da caixa (ex.: `nao-responda@meuassistente.chat`).
- Limites: informe no painel os limites **do seu plano** (por hora e por dia). A fila nunca passa deles.

## Opção 2 — Hostinger Mail API
hPanel → **API** → criar token da Mail API. Cole o token, toque em **Testar conexão** e escolha a caixa listada
(`mailboxResourceId`). Envio: `POST https://api.mail.hostinger.com/api/v1/mailboxes/{id}/send`.
Observação: a Hostinger Reach é a ferramenta de **marketing** (campanhas); os e-mails automáticos do sistema
(recuperação de senha, pedidos) usam a Mail API ou o SMTP da caixa.

## Opção 3 — Resend
Coloque `RESEND_API_KEY` e `MAIL_FROM` no `.env` da VPS.

## DNS (entregabilidade)
Em Painel → E-mails → **Domínio**, toque em **Verificar**. Publique no DNS do domínio:
- **SPF**: `v=spf1 include:_spf.mail.hostinger.com ~all` (Hostinger) ou `v=spf1 ip4:IP_DA_VPS ~all` (Postfix próprio).
- **DKIM**: ative no hPanel (E-mails → Configurações DNS) ou OpenDKIM no Postfix; publique o TXT indicado.
- **DMARC**: `_dmarc` → `v=DMARC1; p=none; rua=mailto:dmarc@SEU_DOMINIO` (depois `p=quarantine`).

## Empresas
Sua empresa → Ajustes → **E-mails da empresa**: nome do remetente, e-mail para respostas e, opcionalmente, SMTP próprio
(os e-mails de pedidos saem pelo e-mail da empresa, com limites próprios).

## Status
"Aceito pelo provedor" = o servidor de envio recebeu a mensagem. A confirmação de entrega na caixa do destinatário
depende do provedor de destino e não é informada por SMTP.
