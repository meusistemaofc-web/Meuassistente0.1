# Cérebro: conhecimento, aprendizado e regras executáveis

## Três naturezas (Painel → Cérebro e busca → Novo conhecimento ou regra)
| Natureza | Para quê | Como é usada |
|---|---|---|
| **Consulta** | Informação (prazos, políticas, preços…) | O motor interno responde com o texto cadastrado, **sem IA**. Quando uma IA responde, o conhecimento relacionado entra como base. |
| **Diretriz** | Orientação de comportamento (tom, limites) | Entra nas instruções da IA. **Só tem efeito quando uma IA gera a resposta**; nunca é respondida como informação. |
| **Regra executável** | Comportamento garantido | O sistema **executa** uma ação real, com ou sem IA (abaixo). |

Itens criados antes desta versão (natureza vazia) continuam como eram: regras valem como consulta **e** como orientação para a IA. Nada foi alterado ou apagado.

## Regras executáveis (ações reais)
| Ação | Função real acionada | Validações |
|---|---|---|
| Recusar o assunto | Responde com a mensagem cadastrada; nenhuma IA é chamada | — |
| Abrir um módulo | Cartão do módulo do app | Módulo existe, está disponível e **ligado no painel** (senão: "negado", registrado) |
| Abrir chamado | Mesma função da Central de Ajuda (`criarChamado`): protocolo, mensagem inicial, aviso aos admins | Exige usuário logado; limite de 5 chamados/hora |
| Avisar administradores | Notificação a todos os admins ativos | Exige usuário logado |
| Acrescentar texto | Texto fixo ao fim das respostas (vazio = todas) | — |

- **Gatilho**: frases (uma por linha); dispara quando a mensagem contém a frase (sem acento/maiúsculas).
- **Quem pode acionar**: todos · donos de empresa · só administradores. Sem permissão: não executa e registra "negado".
- **Escopo**: Chat do usuário · Agentes das empresas · Ambos. No agente (visitante sem login) só valem *Recusar* e *Acrescentar texto*; o cadastro recusa as demais.
- **Prioridade (1–100)**: o administrador cria com 70; o aprendido, 40–50. Entre regras terminais que disparam juntas, vale a de maior prioridade; as outras são registradas como "suprimida".
- O **Teste de independência** do painel apenas **simula** regras (nada é criado nem enviado).

## Aprendizado automático
Respostas aprendidas nas conversas e correções do usuário entram como **pendentes**. Só depois de **aprovadas** passam a valer, e então se tornam parte da base comum (deixam de ser privadas do usuário). Rejeitado/desativado não é proposto de novo. Itens já ativos antes desta versão foram preservados.

## Conflitos, duplicidades e prioridade
Ao cadastrar, aprovar ou reativar, o sistema compara com o que está ativo: **duplicado**, **contradição** (valores diferentes ou afirma × nega) e **regras incompatíveis** (mesmo gatilho, ações diferentes). O administrador vê a lista, qual prevalece e confirma ou cancela (cancelar deixa pendente). Botão "Verificar agora" confere tudo. Na resposta, vale o item de maior prioridade e o registro de uso cita a disputa.

## Histórico, versão, status e uso
- **Status**: pendente · ativo · rejeitado · desativado. Editar, aprovar, rejeitar, desativar e reativar pelo painel; excluir continua existindo (prefira desativar).
- **Versão**: mudar conteúdo/natureza/escopo/regra cria nova versão (cópia da anterior em `brain_versions`); mudar só a prioridade não cria.
- **Origem**, quem aprovou e quando, e histórico de ações por item (Detalhes).
- **Uso** (`brain_usage`): cada vez que um item responde, bloqueia, abre módulo/chamado, avisa admins, anexa texto ou entra no contexto da IA, grava item, **versão**, canal, usuário, conversa, **mensagem influenciada**, efeito e resultado. Diretrizes no contexto da IA são registradas uma vez por conversa/dia.

## Migração `018_cerebro_regras.sql` (somente aditiva)
Novas colunas em `brain_answers` (nature, scope, priority, version, rule_*, approved_*) com padrões que preservam o comportamento; tabelas `brain_versions` (já com a versão 1 de tudo o que existia) e `brain_usage`. Nenhuma linha é apagada.

## Correções encontradas durante o trabalho
- Mudar só o "Modo das IAs" gravava a configuração do Cérebro sem os padrões e **desligava o aprendizado** e o "Cérebro primeiro" sem aviso.
- "até **30** dias" era lido como "até 3" (a expressão recuava dentro do número) e criava condição falsa.
- Respostas aprendidas valiam imediatamente, sem revisão.
- O chat lançava e resumia finanças (motor interno e ferramentas da IA) mesmo com o módulo "Finanças" desligado no painel; agora respeita o módulo.
- O agente das empresas não consultava o Cérebro.

## Limitações conhecidas
- Diretrizes dependem da IA: com IA desligada orientam nada (use regra executável).
- Gatilhos são por frase contida na mensagem (não há interpretação semântica).
