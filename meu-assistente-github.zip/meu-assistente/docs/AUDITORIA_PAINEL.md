# Auditoria do painel administrativo — erros de servidor após a atualização

## Causa raiz
Na reestruturação do Mercado Pago, o `GET /api/panel` (que TODAS as abas do painel carregam) passou a contar as empresas
conectadas com `SELECT COUNT(*) FROM businesses WHERE data LIKE '%"mpModo":"oauth"%'`.
No PostgreSQL da VPS a coluna `businesses.data` é **JSONB**, e `LIKE` em JSONB é erro
(`operator does not exist: jsonb ~~ unknown`). Resultado: HTTP 500 em `/api/panel` e falha ao abrir as opções do menu administrativo.
Os testes automáticos rodam em SQLite (que guarda JSON como texto e aceita o LIKE), por isso o erro não apareceu antes da publicação.

## Correção
- src/routes/panel.ts (`panelGet`, seção `mp_oauth`): a contagem é feita no código lendo `data` com o leitor de JSON do sistema.
- src/db/sqlite.ts (`pgStrict`): o ambiente de testes agora **recusa** `LIKE/ILIKE` em colunas que são JSONB no PostgreSQL,
  para que esse tipo de incompatibilidade quebre o teste antes de chegar ao servidor.

## Verificações feitas
- Varredura das consultas novas: nenhuma outra comparação de texto com JSONB; restrições CHECK (role, status, items.type) respeitadas;
  `ON CONFLICT` só em colunas com índice único; booleanos sempre por parâmetro.
- Migrações 013–016 conferidas (tabelas e colunas novas, sem renomear campos existentes).
- Permissões: `/api/panel` → 401 sem login, 403 para usuário comum, 200 para administrador.

## Testes aprovados (135/135)
Teste novo "auditoria do painel administrativo": chama **todas as 15 rotas GET** de `/api/panel*` e `/api/admin*` como administrador
(nenhuma com 404/5xx), confere as seções do painel e confirma que a proteção detecta a consulta antiga.
