// Testes de integração ponta a ponta: sobem o servidor HTTP real, executam as migrações e
// exercitam a API com cookies, como o navegador faz. Por não haver PostgreSQL no ambiente de
// build, o banco aqui é o SQLite embutido do Node (adaptador de teste). A IA externa é
// substituída por um servidor local compatível com a API da OpenAI (dublê de teste), que
// devolve chamadas de ferramenta — o que valida o caminho real de gravação no banco.
import { createServer } from 'node:http'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { writeFileSync } from 'node:fs'

const results: { name: string; ok: boolean; detail?: string }[] = []
async function test(name: string, fn: () => Promise<void>) {
  try { await fn(); results.push({ name, ok: true }); console.log('  ✔', name) }
  catch (e: any) { results.push({ name, ok: false, detail: e?.message }); console.log('  ✘', name, '→', e?.message) }
}
function assert(c: unknown, msg: string): asserts c { if (!c) throw new Error(msg) }

// ---------- dublê da IA (API compatível com OpenAI) ----------
let aiCalls = 0
const ai = createServer(async (req, res) => {
  let body = ''
  for await (const c of req) body += c
  aiCalls++
  const j = JSON.parse(body)
  const last = j.messages[j.messages.length - 1]
  const reply = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  if (req.headers.authorization !== 'Bearer test-key') { res.writeHead(401); return res.end('{}') }
  if (last.role === 'tool') return reply({ role: 'assistant', content: 'Pronto, registrei para você.' })
  const t = String(last.content).toLowerCase()
  const call = (name: string, args: object) => reply({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name, arguments: JSON.stringify(args) } }] })
  if (t.includes('gastei')) return call('register_transaction', { kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' })
  if (t.includes('tarefa')) return call('create_task', { title: 'Enviar orçamento', priority: 'high' })
  if (t.includes('lembre')) return call('save_memory', { content: 'Prefere respostas curtas', kind: 'preference' })
  if (t.includes('compromisso')) return call('create_appointment', { title: 'Dentista', date: '2099-01-10', time: '14:00', location: 'Centro' })
  return reply({ role: 'assistant', content: 'Olá! Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
const aiPort = (ai.address() as any).port

const dir = mkdtempSync(join(tmpdir(), 'ma-test-'))
const dbFile = join(dir, 'test.db')
Object.assign(process.env, {
  NODE_ENV: 'test', PUBLIC_URL: 'http://localhost', AI_BASE_URL: `http://127.0.0.1:${aiPort}/v1`, AI_API_KEY: 'test-key',
  AI_MODEL: 'dublê', SCHEDULER_ENABLED: 'false', STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public'),
})

const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const { tick } = await import('../src/scheduler.js')
const { totp } = await import('../src/lib/security.js')

async function boot() {
  const d = await createSqlite(dbFile)
  setDb(d)
  const applied = await migrate(d, config.migrationsDir, () => {})
  const server = createApp()
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r))
  return { d, server, port: (server.address() as any).port, applied }
}
let { d, server, port, applied } = await boot()

class Client {
  jar = new Map<string, string>()
  async call(method: string, path: string, json?: unknown, headers: Record<string, string> = {}) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { ...(json !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), ...headers },
      body: json !== undefined ? JSON.stringify(json) : undefined,
    })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const text = await r.text()
    let body: any = text
    try { body = JSON.parse(text) } catch {}
    return { status: r.status, body, headers: r.headers }
  }
  get = (p: string) => this.call('GET', p)
  post = (p: string, j: unknown = {}) => this.call('POST', p, j)
  auth = (action: string, extra: object = {}) => this.post('/api/auth', { action, ...extra })
}

const admin = new Client(), user = new Client(), anon = new Client()
const PW = 'Senha123forte'
const acct = (n: string) => ({ name: `${n} Silva`, whatsapp: '+55 11 98765-4321', email: `${n.toLowerCase()}@teste.com`, birthday: '1990-05-01', password: PW, passwordConfirm: PW })

console.log('\n== Infraestrutura')
await test('migrações aplicadas do zero (001_init.sql)', async () => { assert(applied.includes('001_init.sql'), 'migração não aplicada') })
await test('migrações são idempotentes (2ª execução não reaplica)', async () => { const again = await migrate(d, config.migrationsDir, () => {}); assert(again.length === 0, 'reaplicou') })
await test('GET /api/health responde com banco conectado', async () => { const r = await anon.get('/api/health'); assert(r.status === 200 && r.body.ok, JSON.stringify(r.body)) })
await test('frontend: / e rotas do app devolvem o index.html com o bootstrap', async () => {
  for (const p of ['/', '/entrar', '/agenda', '/convite/abc']) { const r = await anon.get(p); assert(r.status === 200 && String(r.body).includes('$_TSR'), `${p} → ${r.status}`) }
})
await test('frontend: assets com nome em maiúsculas/minúsculas corretos (index-MUcZwl3l.js)', async () => {
  const r = await anon.get('/assets/index-MUcZwl3l.js'); assert(r.status === 200, String(r.status))
  assert(String(r.headers.get('cache-control')).includes('immutable'), 'sem cache imutável')
})
await test('frontend: asset inexistente devolve 404 (não o index.html)', async () => { const r = await anon.get('/assets/nao-existe.js'); assert(r.status === 404, String(r.status)) })
await test('cabeçalhos de segurança presentes', async () => { const r = await anon.get('/api/health'); assert(r.headers.get('x-frame-options') === 'DENY' && r.headers.get('x-content-type-options') === 'nosniff', 'faltando') })
await test('rota inexistente → 404 JSON; módulo não reconstruído → 501 explícito', async () => {
  const a = await anon.get('/api/inexistente'); assert(a.status === 404 && a.body.code === 'not_found', JSON.stringify(a.body))
  const b = await anon.get('/api/market?history=1'); assert(b.status === 501 && b.body.code === 'not_reconstructed', JSON.stringify(b.body))
})
await test('proteção CSRF: POST de outra origem é recusado', async () => {
  const r = await anon.call('POST', '/api/auth', { action: 'login' }, { Origin: 'https://site-malicioso.com' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Autenticação')
await test('GET /api/auth sem contas → firstAccount=true', async () => { const r = await anon.get('/api/auth'); assert(r.body.firstAccount === true && r.body.setupNeeded === false, JSON.stringify(r.body)) })
await test('rotas protegidas sem sessão → 401 auth_required', async () => {
  for (const p of ['/api/me', '/api/agenda', '/api/finance', '/api/conversations', '/api/notifications']) { const r = await anon.get(p); assert(r.status === 401 && r.body.code === 'auth_required', p) }
})
await test('cadastro valida campos (nome, WhatsApp, senha) com "field"', async () => {
  let r = await anon.auth('signup', { ...acct('X'), name: 'Fulano' }); assert(r.status === 400 && r.body.field === 'name', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), whatsapp: '1234' }); assert(r.body.field === 'whatsapp', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), password: 'abcdefgh', passwordConfirm: 'abcdefgh' }); assert(r.body.field === 'password', JSON.stringify(r.body))
})
await test('primeira conta vira Administrador Principal e redireciona para /admin', async () => {
  const r = await admin.auth('signup', acct('Ana')); assert(r.status === 200 && r.body.redirect === '/admin', JSON.stringify(r.body))
  const me = await admin.get('/api/me'); assert(me.body.profile.role === 'superadmin', me.body.profile?.role)
})
await test('cookie de sessão é HttpOnly + SameSite=Lax e o token não é gravado em texto puro', async () => {
  const r = await user.auth('signup', acct('Bruno'))
  const c = r.headers.getSetCookie()[0]; assert(/HttpOnly/.test(c) && /SameSite=Lax/.test(c), c)
  const tok = user.jar.get('ma_session')!
  const rows = await d.query('SELECT id FROM sessions WHERE id = $1', [tok]); assert(rows.length === 0, 'token em texto puro no banco')
})
await test('segunda conta é usuário comum', async () => { const me = await user.get('/api/me'); assert(me.body.profile.role === 'user', me.body.profile.role) })
await test('e-mail duplicado é recusado', async () => { const r = await anon.auth('signup', acct('Bruno')); assert(r.status === 409 && r.body.field === 'email', JSON.stringify(r.body)) })
await test('senha guardada com scrypt (sem texto puro)', async () => {
  const [row] = await d.query('SELECT password_hash FROM users WHERE email = $1', ['bruno@teste.com']); assert(row.password_hash.startsWith('scrypt$') && !row.password_hash.includes(PW), 'hash inválido')
})
await test('logout encerra a sessão no servidor', async () => {
  const c = new Client(); await c.auth('login', { email: 'bruno@teste.com', password: PW })
  assert((await c.get('/api/me')).status === 200, 'login falhou')
  await c.auth('logout'); const r = await c.get('/api/me'); assert(r.status === 401, String(r.status))
})
await test('login com senha errada → 401; correta → 200; action session ok', async () => {
  const c = new Client()
  let r = await c.auth('login', { email: 'bruno@teste.com', password: 'errada123' }); assert(r.status === 401, String(r.status))
  r = await c.auth('login', { email: 'BRUNO@teste.com', password: PW }); assert(r.status === 200 && r.body.redirect === '/', JSON.stringify(r.body))
  r = await c.auth('session'); assert(r.status === 200, String(r.status))
})
await test('limite de tentativas de login (429)', async () => {
  const c = new Client(); let last = 0
  for (let i = 0; i < 10; i++) last = (await c.auth('login', { email: 'alvo@teste.com', password: 'x1234567' })).status
  assert(last === 429, String(last))
})
await test('2FA: ativar com TOTP, login exige código, código de recuperação funciona uma vez', async () => {
  const b = await user.auth('mfa_begin', { password: PW }); assert(b.body.secret && b.body.uri.startsWith('otpauth://'), JSON.stringify(b.body))
  const en = await user.auth('mfa_enable', { code: totp(b.body.secret) }); assert(en.body.backupCodes?.length === 10, JSON.stringify(en.body))
  const st = await user.auth('security_status'); assert(st.body.mfa.enabled && st.body.mfa.backupCodesLeft === 10, JSON.stringify(st.body))
  const c = new Client()
  const l = await c.auth('login', { email: 'bruno@teste.com', password: PW }); assert(l.body.mfaRequired === true, JSON.stringify(l.body))
  assert((await c.get('/api/me')).status === 401, 'sessão pendente não pode acessar')
  const bad = await c.auth('mfa_login', { code: '000000' }); assert(bad.status === 400, String(bad.status))
  const ok = await c.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(ok.status === 200, JSON.stringify(ok.body))
  assert((await c.get('/api/me')).status === 200, 'não entrou')
  const c2 = new Client(); await c2.auth('login', { email: 'bruno@teste.com', password: PW })
  const reuse = await c2.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(reuse.status === 400, 'código de recuperação reutilizado')
  const ok2 = await c2.auth('mfa_login', { code: totp(b.body.secret) }); assert(ok2.status === 200, 'TOTP recusado')
  const dis = await user.auth('mfa_disable', { password: PW, code: totp(b.body.secret) }); assert(dis.status === 200, JSON.stringify(dis.body))
})
await test('recuperar senha: token de uso único troca a senha e derruba sessões', async () => {
  const r = await anon.auth('recover', { email: 'bruno@teste.com' }); assert(r.status === 200 && r.body.message, JSON.stringify(r.body))
  // o link real vai por e-mail; no teste geramos um token conhecido direto no banco
  const { sha256 } = await import('../src/lib/security.js')
  const [u] = await d.query('SELECT id FROM users WHERE email = $1', ['bruno@teste.com'])
  await d.query('INSERT INTO password_resets (token_hash, user_id, expires_at, created_at) VALUES ($1,$2,$3,$4)', [sha256('tok-teste'), u.id, new Date(Date.now() + 3600e3).toISOString(), new Date().toISOString()])
  const c = new Client()
  const v = await c.auth('recovery', { token: 'tok-teste' }); assert(v.status === 200 && v.body.mfaRequired === false, JSON.stringify(v.body))
  assert((await c.get('/api/me')).status === 401, 'sessão de recuperação não deve acessar a API')
  const p = await c.auth('password', { password: 'NovaSenha456', passwordConfirm: 'NovaSenha456' }); assert(p.status === 200, JSON.stringify(p.body))
  assert((await user.get('/api/me')).status === 401, 'sessão antiga continuou ativa')
  const again = await new Client().auth('recovery', { token: 'tok-teste' }); assert(again.status === 400, 'token reutilizado')
  const l = await user.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'nova senha não funciona')
})
await test('alterar senha exige a senha atual', async () => {
  const r = await user.auth('password', { currentPassword: 'errada', password: 'Outra789x', passwordConfirm: 'Outra789x' }); assert(r.status === 400 && r.body.field === 'currentPassword', JSON.stringify(r.body))
})

console.log('\n== Perfil e configurações (/api/me)')
await test('PATCH /api/me salva perfil, configurações e ignora chaves desconhecidas', async () => {
  const r = await user.call('PATCH', '/api/me', { profile: { name: 'Bruno Souza' }, settings: { theme: 'light', timezone: 'America/Manaus', hack: 1 } })
  assert(r.body.profile.name === 'Bruno Souza' && r.body.settings.theme === 'light' && r.body.settings.timezone === 'America/Manaus' && !('hack' in r.body.settings), JSON.stringify(r.body.settings))
  await user.call('PATCH', '/api/me', { settings: { timezone: 'America/Sao_Paulo' } })
})
await test('plano expõe apenas recursos reconstruídos', async () => {
  const r = await user.get('/api/me'); assert(r.body.plan.features.includes('agenda') && !r.body.plan.features.includes('investments'), JSON.stringify(r.body.plan))
})

console.log('\n== Agenda, tarefas, lembretes, compras e notas (/api/items, /api/agenda)')
let taskId = 0, apptId = 0, remId = 0, shopId = 0, noteId = 0
await test('criar tarefa, compromisso, lembrete, compras e nota', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'task', data: { title: 'Comprar tinta' } }); taskId = r.body.item.id; assert(taskId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'Reunião', date: '2099-03-01', time: '10:30', location: 'Escritório', reminder_minutes: 15 } }); apptId = r.body.item.id; assert(apptId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Tomar água', date: '2099-03-01', time: '08:00', recurrence: 'daily' } }); remId = r.body.item.id; assert(r.body.item.remindAt === '2099-03-01T11:00:00.000Z', r.body.item.remindAt)
  r = await user.post('/api/items', { action: 'create', type: 'shopping', data: { items: [{ name: 'papel' }, { name: 'luvas' }] } }); shopId = r.body.items[0].id; assert(r.body.items.length === 2, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'note', data: { content: 'Senha do wi-fi do estúdio' } }); noteId = r.body.item.id; assert(noteId > 0, 'nota')
})
await test('validação: compromisso sem data é recusado (field=date)', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'X' } }); assert(r.status === 400 && r.body.field === 'date', JSON.stringify(r.body))
})
await test('GET /api/agenda devolve todos os grupos no formato do frontend', async () => {
  const r = await user.get('/api/agenda')
  for (const k of ['today', 'tz', 'tasks', 'appointments', 'reminders', 'shopping', 'notes', 'bills', 'sharedWithMe']) assert(k in r.body, `falta ${k}`)
  assert(r.body.tasks[0].title === 'Comprar tinta' && r.body.tasks[0].status === 'pending', 'tarefa')
  assert(r.body.shopping.some((s: any) => s.name === 'luvas' && s.listName === 'Compras' && s.done === false), 'compras')
})
await test('ações: concluir tarefa, marcar compra, fixar nota, adiar e concluir lembrete, alterar compromisso', async () => {
  await user.post('/api/items', { action: 'task_status', type: 'task', id: taskId, data: { status: 'done' } })
  await user.post('/api/items', { action: 'shopping_toggle', type: 'shopping', id: shopId })
  await user.post('/api/items', { action: 'note_pin', type: 'note', id: noteId })
  const sn = await user.post('/api/items', { action: 'reminder_snooze', type: 'reminder', id: remId, data: { minutes: 15 } }); assert(sn.body.item.snoozedUntil, 'snooze')
  const up = await user.post('/api/items', { action: 'appointment_update', type: 'appointment', id: apptId, data: { date: '2099-03-02', time: '11:00' } }); assert(up.body.item.date === '2099-03-02' && up.body.item.time === '11:00', JSON.stringify(up.body))
  const r = await user.get('/api/agenda')
  assert(r.body.tasks.find((t: any) => t.id === taskId).status === 'done', 'tarefa não concluída')
  assert(r.body.shopping.find((s: any) => s.id === shopId).done === true, 'compra não marcada')
  assert(r.body.notes.find((n: any) => n.id === noteId).pinned === true, 'nota não fixada')
})
await test('permissão: um usuário não altera nem vê registros de outro (404)', async () => {
  const r = await admin.post('/api/items', { action: 'delete', type: 'task', id: taskId }); assert(r.status === 404, String(r.status))
  const a = await admin.get('/api/agenda'); assert(!a.body.tasks.some((t: any) => t.id === taskId), 'vazamento entre contas')
})
await test('excluir registro', async () => {
  const r = await user.post('/api/items', { action: 'delete', type: 'note', id: noteId }); assert(r.status === 200, String(r.status))
  const a = await user.get('/api/agenda'); assert(!a.body.notes.some((n: any) => n.id === noteId), 'nota não excluída')
})

console.log('\n== Financeiro (/api/finance)')
let billId = 0
await test('lançar gasto e receita, cadastrar conta mensal', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: '45,90', description: 'Mercado', category: 'alimentacao' } }); assert(r.body.item.amount === 45.9, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'income', amount: 1000, description: 'Serviço', category: 'servicos' } }); assert(r.body.item.kind === 'income', 'receita')
  const today = (await user.get('/api/agenda')).body.today
  r = await user.post('/api/items', { action: 'create', type: 'bill', data: { name: 'Luz', amount: 180, due_date: today, recurrence: 'monthly', category: 'casa' } }); billId = r.body.item.id; assert(billId > 0, JSON.stringify(r.body))
})
await test('valor inválido é recusado (field=amount)', async () => { const r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: -3 } }); assert(r.body.field === 'amount', JSON.stringify(r.body)) })
await test('GET /api/finance calcula receitas, despesas, saldo, categorias e série', async () => {
  const r = await user.get('/api/finance')
  assert(r.body.income === 1000 && r.body.spent === 45.9, `${r.body.income}/${r.body.spent}`)
  assert(r.body.balance === Math.round((1000 - 45.9 - 180) * 100) / 100, String(r.body.balance))
  assert(r.body.byCategory[0].slug === 'alimentacao' && r.body.series.length === 6 && r.body.pendingBills.length === 1, JSON.stringify(r.body.byCategory))
})
await test('pagar conta mensal gera a próxima ocorrência; desfazer remove', async () => {
  const p = await user.post('/api/items', { action: 'pay_bill', type: 'bill', id: billId }); assert(p.body.item.status === 'paid', JSON.stringify(p.body))
  let [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill' AND status = 'pending'"); assert(Number(n.n) === 1, 'próxima conta não criada')
  await user.post('/api/items', { action: 'unpay_bill', type: 'bill', id: billId });
  [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill'"); assert(Number(n.n) === 1, 'próxima conta não removida')
})
await test('GET /api/day e /api/summary com dados reais', async () => {
  const today = (await user.get('/api/agenda')).body.today
  const r = await user.get(`/api/day?from=${today}&to=${today}`); assert(r.body.entries.some((e: any) => e.kind === 'bill'), JSON.stringify(r.body))
  const s = await user.get('/api/summary'); assert(s.body.summary.data.spent === 45.9 && s.body.summary.text.includes('45,90'), JSON.stringify(s.body))
})

console.log('\n== Chat com IA (/api/chat, /api/conversations, /api/memory)')
const conv = '11111111-2222-4333-8444-555555555555'
await test('mensagem simples cria conversa e grava as duas mensagens', async () => {
  const r = await user.post('/api/chat', { text: 'Oi, tudo bem?', conversationId: conv })
  assert(r.status === 200 && r.body.conversation.id === conv && r.body.userMessage.role === 'user' && r.body.assistantMessage.content.includes('Olá'), JSON.stringify(r.body))
})
await test('"gastei 35 no almoço" → IA chama ferramenta, grava gasto real e devolve cartão', async () => {
  const r = await user.post('/api/chat', { text: 'gastei 35 reais no almoço', conversationId: conv })
  const card = r.body.assistantMessage.cards[0]; assert(card?.kind === 'expense' && card.amount === 35, JSON.stringify(r.body.assistantMessage))
  const f = await user.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço' && e.amount === 35), 'gasto não gravado')
})
await test('compromisso e tarefa pelo chat ficam na agenda', async () => {
  await user.post('/api/chat', { text: 'marca compromisso no dentista', conversationId: conv })
  await user.post('/api/chat', { text: 'cria a tarefa enviar orçamento', conversationId: conv })
  const a = await user.get('/api/agenda')
  assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento' && t.priority === 'high'), 'tarefa')
  const day = await user.get('/api/day?from=2099-01-10&to=2099-01-10'); assert(day.body.entries.some((e: any) => e.title === 'Dentista'), 'compromisso')
})
await test('"lembre que..." salva memória visível no Perfil', async () => {
  await user.post('/api/chat', { text: 'lembre que prefiro respostas curtas', conversationId: conv })
  const m = await user.get('/api/memory'); assert(m.body.memories.some((x: any) => x.content === 'Prefere respostas curtas' && x.source === 'chat'), JSON.stringify(m.body))
})
await test('memória recusa senhas', async () => { const r = await user.post('/api/memory', { action: 'create', content: 'minha senha é 1234' }); assert(r.status === 400, String(r.status)) })
await test('histórico: GET /api/chat?c= devolve as mensagens; lista e busca de conversas', async () => {
  const r = await user.get(`/api/chat?c=${conv}`); assert(r.body.messages.length === 10, String(r.body.messages.length))
  const l = await user.get('/api/conversations'); assert(l.body.conversations[0].id === conv, 'lista')
  const s = await user.get('/api/conversations?q=dentista'); assert(s.body.conversations.length === 1, 'busca')
  const o = await admin.get(`/api/chat?c=${conv}`); assert(o.body.conversation === null, 'outra conta viu a conversa')
})
await test('editar e reenviar mensagem substitui a resposta anterior', async () => {
  const h = await user.get(`/api/chat?c=${conv}`)
  const first = h.body.messages.find((m: any) => m.role === 'user')
  const r = await user.post('/api/chat', { resendOf: first.id, conversationId: conv, text: 'Olá de novo' })
  assert(r.body.resent === true && r.body.superseded.length > 0 && r.body.userMessage.content === 'Olá de novo', JSON.stringify(r.body))
})
await test('renomear, fixar e excluir conversa', async () => {
  await user.call('PATCH', `/api/conversations/${conv}`, { title: 'Organização', pinned: true })
  let l = await user.get('/api/conversations'); assert(l.body.conversations[0].title === 'Organização' && l.body.conversations[0].pinned, 'renomear')
  const c2 = '99999999-2222-4333-8444-555555555555'
  await user.post('/api/chat', { text: 'oi', conversationId: c2 })
  await user.call('DELETE', `/api/conversations/${c2}`)
  l = await user.get('/api/conversations'); assert(!l.body.conversations.some((c: any) => c.id === c2), 'não excluiu')
})
await test('envio de áudio/foto (multipart) → 501 explícito, sem simulação', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: { Cookie: `ma_session=${user.jar.get('ma_session')}`, 'Content-Type': 'multipart/form-data; boundary=x' }, body: '--x--' })
  assert(r.status === 501, String(r.status))
})

console.log('\n== Sincronização offline (/api/sync)')
await test('fila offline: cria, conclui e é idempotente', async () => {
  const ops = [{ id: 'op-1', kind: 'create', type: 'task', data: { title: 'Feita offline' } }]
  const r = await user.post('/api/sync', { ops }); assert(r.body.results[0].status === 'done' && r.body.results[0].createdId > 0, JSON.stringify(r.body))
  const again = await user.post('/api/sync', { ops }); assert(again.body.results[0].createdId === r.body.results[0].createdId, 'duplicou')
  const done = await user.post('/api/sync', { ops: [{ id: 'op-2', kind: 'task_status', type: 'task', targetId: r.body.results[0].createdId, data: { status: 'done' } }] })
  assert(done.body.results[0].status === 'done', JSON.stringify(done.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'task' AND json_extract(data, '$.title') = 'Feita offline'"); assert(Number(n.n) === 1, 'duplicado')
})

console.log('\n== Notificações e agendador')
await test('lembrete vencido gera notificação; recorrente avança para o dia seguinte', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Pagar boleto', date: '2020-01-01', time: '09:00', recurrence: 'daily' } })
  await tick(new Date())
  const n = await user.get('/api/notifications'); assert(n.body.items.some((i: any) => i.title === 'Pagar boleto') && n.body.unread >= 1, JSON.stringify(n.body))
  const [row] = await d.query('SELECT day FROM items WHERE id = $1', [r.body.item.id]); assert(row.day === '2020-01-02', row.day)
  await tick(new Date()); const n2 = await user.get('/api/notifications?count=1'); assert(typeof n2.body.unread === 'number', 'contagem')
})
await test('marcar todas como lidas', async () => { const r = await user.post('/api/notifications', { all: true }); assert(r.body.unread === 0, JSON.stringify(r.body)) })

console.log('\n== Administração')
await test('usuário comum não acessa o painel', async () => {
  const r = await user.get('/api/admin'); assert(r.body.access === 'none', JSON.stringify(r.body))
  const u = await user.get('/api/admin/users'); assert(u.status === 403, String(u.status))
})
await test('Administrador Principal lista, cria, edita e desativa usuários (com auditoria)', async () => {
  const a = await admin.get('/api/admin'); assert(a.body.access === 'admin' && a.body.me.permissions.includes('users.manage'), JSON.stringify(a.body))
  const l = await admin.get('/api/admin/users?q=bruno'); assert(l.body.users.length === 1, JSON.stringify(l.body))
  const c = await admin.post('/api/admin/users', { action: 'create', name: 'Carla Dias', whatsapp: '+55 21 99999-0000', email: 'carla@teste.com', birthday: '1985-02-02', password: 'Inicial123', role: 'admin', permissions: ['users.view'] })
  assert(c.body.user.role === 'admin' && c.body.user.permissions.join() === 'users.view', JSON.stringify(c.body))
  const bruno = l.body.users[0]
  const s = await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'disabled' }); assert(s.body.user.status === 'disabled', 'status')
  assert((await user.get('/api/me')).status === 401, 'conta desativada continuou com sessão')
  const blocked = await new Client().auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(blocked.status === 403 && blocked.body.code === 'account_disabled', JSON.stringify(blocked.body))
  await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'active' })
  const au = await admin.get('/api/admin/audit'); assert(au.body.entries.some((e: any) => e.action === 'user.disable'), 'auditoria')
})
await test('admin com só "users.view" não pode criar usuários', async () => {
  const c = new Client(); await c.auth('login', { email: 'carla@teste.com', password: 'Inicial123' })
  const r = await c.post('/api/admin/users', { action: 'create', name: 'Teste Teste', whatsapp: '+5511988887777', email: 't@t.com', password: 'Abc12345' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Persistência após reinicialização')
const persisted = new Client()
await test('dados continuam após reiniciar servidor e banco', async () => {
  await new Promise<void>((r) => server.close(() => r()))
  await d.close()
  ;({ d, server, port } = await boot())
  const c = persisted; const l = await c.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'login após reinício')
  const a = await c.get('/api/agenda'); assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento'), 'tarefa perdida')
  const f = await c.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço'), 'gasto perdido')
  const h = await c.get(`/api/chat?c=${conv}`); assert(h.body.messages.length > 0, 'conversa perdida')
})

console.log('\n== Exclusão de conta')
await test('excluir conta apaga dados (cascata) e encerra sessão', async () => {
  const c = persisted // já autenticado no teste anterior (evita o limite de tentativas de login)
  const r = await c.post('/api/auth', { action: 'delete_account', password: 'NovaSenha456', confirm: 'EXCLUIR', acknowledge: true }); assert(r.status === 200, JSON.stringify(r.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items i JOIN users u ON u.id = i.user_id WHERE u.email = 'bruno@teste.com'"); assert(Number(n.n) === 0, 'sobrou dado')
  const [m] = await d.query('SELECT COUNT(*) AS n FROM messages'); assert(Number(m.n) === 0, 'mensagens não apagadas')
  assert((await c.get('/api/me')).status === 401, 'sessão continuou')
})

console.log('\n== Painel (módulos, IAs, fontes de mercado, Mercado Pago, planos)')
const mkSrv = createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ data: { price: 123.45 } })) })
await new Promise<void>((r) => mkSrv.listen(0, '127.0.0.1', r))
const mkPort = (mkSrv.address() as any).port
await test('painel exige administrador e não expõe chaves', async () => {
  const anon = new Client()
  assert((await anon.get('/api/panel')).status === 401, 'anônimo acessou')
  const g = await admin.get('/api/panel'); assert(g.status === 200 && g.body.canWrite === true, JSON.stringify(g.body).slice(0, 200))
  assert(g.body.ai_providers.some((p: any) => p.id === 'servidor') && g.body.ai_providers.every((p: any) => p.key === undefined), 'lista de IAs')
  const pub = await anon.get('/api/panel/public'); assert(pub.body.modules && pub.body.ad_plans.length === 4 && !JSON.stringify(pub.body).includes('tok'), 'público')
})
await test('módulos globais e planos são salvos e validados', async () => {
  const m = await admin.call('PUT', '/api/panel/modules', { mercado: false }); assert(m.body.modules.mercado === false && m.body.modules.fiscal === true, JSON.stringify(m.body.modules))
  const bad = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ nome: 'X', preco: -1, dias: 30, nivel: 1 }] }); assert(bad.status === 400, 'aceitou preço negativo')
  const ok = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ id: 'n1', nome: 'Básico', preco: 19.9, dias: 15, nivel: 1 }, { id: 'n4', nome: 'Loja', preco: 99, dias: 30, nivel: 4 }] })
  assert(ok.body.ad_plans.length === 2 && ok.body.ad_plans[0].preco === 19.9, JSON.stringify(ok.body.ad_plans))
  const r = await admin.call('PUT', '/api/panel/search', { raio: 500 }); assert(r.status === 400, 'raio inválido aceito')
})
await test('Mercado Pago guarda o token cifrado e devolve só mascarado', async () => {
  const s = await admin.call('PUT', '/api/panel/mercadopago', { modo: 'teste', teste: { pub: 'TEST-abc123456789', tok: 'TEST-1234567890-segredo-muito-longo' } })
  assert(s.body.mercadopago.teste.tok.hasKey && s.body.mercadopago.teste.tok.keyMasked.includes('••'), JSON.stringify(s.body.mercadopago))
  const raw = await d.query("SELECT value FROM app_config WHERE key = 'mercadopago'")
  assert(!String(raw[0].value).includes('segredo-muito-longo'), 'token gravado sem cifra')
  const bad = await admin.call('PUT', '/api/panel/mercadopago', { teste: { tok: 'chave-errada-123456' } }); assert(bad.status === 400, 'token inválido aceito')
})
await test('IA com troca automática: chave recusada é pausada e a próxima responde', async () => {
  const items = [{ id: 'c-falha', nome: 'IA com chave errada', base_url: `http://127.0.0.1:${aiPort}/v1`, modelo: 'duble', key: 'chave-errada-xyz', texto: true, ativo: true }, { id: 'servidor', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/ai_providers', { items }); assert(s.status === 200 && s.body.ai_providers[0].hasKey, JSON.stringify(s.body).slice(0, 300))
  const c = await admin.post('/api/chat', { text: 'oi, tudo bem?', conversationId: '99999999-2222-4333-8444-555555555555' }); assert(c.status === 200, 'chat falhou: ' + JSON.stringify(c.body))
  const g = await admin.get('/api/panel'); assert(g.body.ai_runtime.paused['c-falha']?.expired === true, JSON.stringify(g.body.ai_runtime))
  const t = await admin.post('/api/panel/test', { kind: 'ai', id: 'c-falha' }); assert(t.body.ok === false && /recusada/.test(t.body.message), JSON.stringify(t.body))
  const t2 = await admin.post('/api/panel/test', { kind: 'ai', id: 'servidor' }); assert(t2.body.ok === true, JSON.stringify(t2.body))
})
await test('fonte de mercado personalizada: cadastro, teste e cotação', async () => {
  const g = await admin.get('/api/panel')
  const items = [...g.body.market_providers.map((p: any) => ({ id: p.id, ativo: false })), { id: 'c-minha', nome: 'Minha API', cat: 'cripto', url: `http://127.0.0.1:${mkPort}/q/{SIMBOLO}`, campo: 'data.price', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/market_providers', { items }); assert(s.status === 200, JSON.stringify(s.body).slice(0, 300))
  const t = await admin.post('/api/panel/test', { kind: 'market', id: 'c-minha' }); assert(t.body.ok === true, JSON.stringify(t.body))
  const q = await admin.get('/api/v2/market/quote?s=btc'); assert(q.body.price === 123.45 && q.body.source === 'Minha API', JSON.stringify(q.body))
})
mkSrv.close()

await new Promise<void>((r) => server.close(() => r()))
await d.close()
ai.close()
rmSync(dir, { recursive: true, force: true })
const failed = results.filter((r) => !r.ok)
console.log(`\nResultado: ${results.length - failed.length}/${results.length} testes aprovados. Chamadas ao dublê da IA: ${aiCalls}`)
writeFileSync(join(process.cwd(), 'test', 'last-results.json'), JSON.stringify({ at: new Date().toISOString(), results }, null, 2))
process.exit(failed.length ? 1 : 0)
