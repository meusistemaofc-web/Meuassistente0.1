// Testes de integração ponta a ponta: sobem o servidor HTTP real, executam as migrações e
// exercitam a API com cookies, como o navegador faz. Por não haver PostgreSQL no ambiente de
// build, o banco aqui é o SQLite embutido do Node (adaptador de teste). A IA externa é
// substituída por um servidor local compatível com a API da OpenAI (dublê de teste), que
// devolve chamadas de ferramenta — o que valida o caminho real de gravação no banco.
import { createServer } from 'node:http'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { writeFileSync } from 'node:fs'

const results: { name: string; ok: boolean; detail?: string }[] = []
async function test(name: string, fn: () => Promise<void>) {
  try { await fn(); results.push({ name, ok: true }); console.log('  ✔', name) }
  catch (e: any) { results.push({ name, ok: false, detail: e?.message }); console.log('  ✘', name, '→', e?.message) }
}
function assert(c: unknown, msg: string): asserts c { if (!c) throw new Error(msg) }

// ---------- dublê da IA (API compatível com OpenAI) ----------
let aiCalls = 0
const ai = createServer(async (req, res) => {
  let body = ''
  for await (const c of req) body += c
  aiCalls++
  const j = JSON.parse(body)
  const last = j.messages[j.messages.length - 1]
  const reply = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  if (req.headers.authorization !== 'Bearer test-key') { res.writeHead(401); return res.end('{}') }
  if (last.role === 'tool') return reply({ role: 'assistant', content: 'Pronto, registrei para você.' })
  const t = String(last.content).toLowerCase()
  const call = (name: string, args: object) => reply({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name, arguments: JSON.stringify(args) } }] })
  if (t.includes('gastei')) return call('register_transaction', { kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' })
  if (t.includes('tarefa')) return call('create_task', { title: 'Enviar orçamento', priority: 'high' })
  if (t.includes('lembre')) return call('save_memory', { content: 'Prefere respostas curtas', kind: 'preference' })
  if (t.includes('compromisso')) return call('create_appointment', { title: 'Dentista', date: '2099-01-10', time: '14:00', location: 'Centro' })
  return reply({ role: 'assistant', content: 'Olá! Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
const aiPort = (ai.address() as any).port

const dir = mkdtempSync(join(tmpdir(), 'ma-test-'))
const dbFile = join(dir, 'test.db')
Object.assign(process.env, {
  NODE_ENV: 'test', PUBLIC_URL: 'http://localhost', AI_BASE_URL: `http://127.0.0.1:${aiPort}/v1`, AI_API_KEY: 'test-key',
  AI_MODEL: 'dublê', SCHEDULER_ENABLED: 'false', STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public'),
})

const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const { tick } = await import('../src/scheduler.js')
const { totp } = await import('../src/lib/security.js')

async function boot() {
  const d = await createSqlite(dbFile)
  setDb(d)
  const applied = await migrate(d, config.migrationsDir, () => {})
  const server = createApp()
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r))
  return { d, server, port: (server.address() as any).port, applied }
}
let { d, server, port, applied } = await boot()

class Client {
  jar = new Map<string, string>()
  async call(method: string, path: string, json?: unknown, headers: Record<string, string> = {}) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { ...(json !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), ...headers },
      body: json !== undefined ? JSON.stringify(json) : undefined,
    })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const text = await r.text()
    let body: any = text
    try { body = JSON.parse(text) } catch {}
    return { status: r.status, body, headers: r.headers }
  }
  get = (p: string) => this.call('GET', p)
  post = (p: string, j: unknown = {}) => this.call('POST', p, j)
  auth = (action: string, extra: object = {}) => this.post('/api/auth', { action, ...extra })
}

const admin = new Client(), user = new Client(), anon = new Client()
const PW = 'Senha123forte'
const acct = (n: string) => ({ name: `${n} Silva`, whatsapp: '+55 11 98765-4321', email: `${n.toLowerCase()}@teste.com`, birthday: '1990-05-01', password: PW, passwordConfirm: PW })

console.log('\n== Infraestrutura')
await test('migrações aplicadas do zero (001_init.sql)', async () => { assert(applied.includes('001_init.sql'), 'migração não aplicada') })
await test('migrações são idempotentes (2ª execução não reaplica)', async () => { const again = await migrate(d, config.migrationsDir, () => {}); assert(again.length === 0, 'reaplicou') })
await test('GET /api/health responde com banco conectado', async () => { const r = await anon.get('/api/health'); assert(r.status === 200 && r.body.ok, JSON.stringify(r.body)) })
await test('frontend: / e rotas do app devolvem o index.html com o bootstrap', async () => {
  for (const p of ['/', '/entrar', '/agenda', '/convite/abc']) { const r = await anon.get(p); assert(r.status === 200 && String(r.body).includes('$_TSR'), `${p} → ${r.status}`) }
})
await test('frontend: assets com nome em maiúsculas/minúsculas corretos (index-MUcZwl3l.js)', async () => {
  const r = await anon.get('/assets/index-MUcZwl3l.js'); assert(r.status === 200, String(r.status))
  assert(String(r.headers.get('cache-control')).includes('no-cache'), 'arquivo principal corrigido deve ser revalidado')
})
await test('frontend: asset inexistente devolve 404 (não o index.html)', async () => { const r = await anon.get('/assets/nao-existe.js'); assert(r.status === 404, String(r.status)) })
await test('cabeçalhos de segurança presentes', async () => { const r = await anon.get('/api/health'); assert(r.headers.get('x-frame-options') === 'DENY' && r.headers.get('x-content-type-options') === 'nosniff', 'faltando') })
await test('rota inexistente → 404 JSON; módulo não reconstruído → 501 explícito', async () => {
  const a = await anon.get('/api/inexistente'); assert(a.status === 404 && a.body.code === 'not_found', JSON.stringify(a.body))
  const b = await anon.get('/api/market?history=1'); assert(b.status === 501 && b.body.code === 'not_reconstructed', JSON.stringify(b.body))
})
await test('proteção CSRF: POST de outra origem é recusado', async () => {
  const r = await anon.call('POST', '/api/auth', { action: 'login' }, { Origin: 'https://site-malicioso.com' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Autenticação')
await test('GET /api/auth sem contas → firstAccount=true', async () => { const r = await anon.get('/api/auth'); assert(r.body.firstAccount === true && r.body.setupNeeded === false, JSON.stringify(r.body)) })
await test('rotas protegidas sem sessão → 401 auth_required', async () => {
  for (const p of ['/api/me', '/api/agenda', '/api/finance', '/api/conversations', '/api/notifications']) { const r = await anon.get(p); assert(r.status === 401 && r.body.code === 'auth_required', p) }
})
await test('cadastro valida campos (nome, WhatsApp, senha) com "field"', async () => {
  let r = await anon.auth('signup', { ...acct('X'), name: 'Fulano' }); assert(r.status === 400 && r.body.field === 'name', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), whatsapp: '1234' }); assert(r.body.field === 'whatsapp', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), password: 'abcdefgh', passwordConfirm: 'abcdefgh' }); assert(r.body.field === 'password', JSON.stringify(r.body))
})
await test('primeira conta vira Administrador Principal e redireciona para /admin', async () => {
  const r = await admin.auth('signup', acct('Ana')); assert(r.status === 200 && r.body.redirect === '/admin', JSON.stringify(r.body))
  const me = await admin.get('/api/me'); assert(me.body.profile.role === 'superadmin', me.body.profile?.role)
})
await test('cookie de sessão é HttpOnly + SameSite=Lax e o token não é gravado em texto puro', async () => {
  const r = await user.auth('signup', acct('Bruno'))
  const c = r.headers.getSetCookie()[0]; assert(/HttpOnly/.test(c) && /SameSite=Lax/.test(c), c)
  const tok = user.jar.get('ma_session')!
  const rows = await d.query('SELECT id FROM sessions WHERE id = $1', [tok]); assert(rows.length === 0, 'token em texto puro no banco')
})
await test('segunda conta é usuário comum', async () => { const me = await user.get('/api/me'); assert(me.body.profile.role === 'user', me.body.profile.role) })
await test('e-mail duplicado é recusado', async () => { const r = await anon.auth('signup', acct('Bruno')); assert(r.status === 409 && r.body.field === 'email', JSON.stringify(r.body)) })
await test('senha guardada com scrypt (sem texto puro)', async () => {
  const [row] = await d.query('SELECT password_hash FROM users WHERE email = $1', ['bruno@teste.com']); assert(row.password_hash.startsWith('scrypt$') && !row.password_hash.includes(PW), 'hash inválido')
})
await test('logout encerra a sessão no servidor', async () => {
  const c = new Client(); await c.auth('login', { email: 'bruno@teste.com', password: PW })
  assert((await c.get('/api/me')).status === 200, 'login falhou')
  await c.auth('logout'); const r = await c.get('/api/me'); assert(r.status === 401, String(r.status))
})
await test('login com senha errada → 401; correta → 200; action session ok', async () => {
  const c = new Client()
  let r = await c.auth('login', { email: 'bruno@teste.com', password: 'errada123' }); assert(r.status === 401, String(r.status))
  r = await c.auth('login', { email: 'BRUNO@teste.com', password: PW }); assert(r.status === 200 && r.body.redirect === '/', JSON.stringify(r.body))
  r = await c.auth('session'); assert(r.status === 200, String(r.status))
})
await test('limite de tentativas de login (429)', async () => {
  const c = new Client(); let last = 0
  for (let i = 0; i < 10; i++) last = (await c.auth('login', { email: 'alvo@teste.com', password: 'x1234567' })).status
  assert(last === 429, String(last))
})
await test('2FA: ativar com TOTP, login exige código, código de recuperação funciona uma vez', async () => {
  const b = await user.auth('mfa_begin', { password: PW }); assert(b.body.secret && b.body.uri.startsWith('otpauth://'), JSON.stringify(b.body))
  const en = await user.auth('mfa_enable', { code: totp(b.body.secret) }); assert(en.body.backupCodes?.length === 10, JSON.stringify(en.body))
  const st = await user.auth('security_status'); assert(st.body.mfa.enabled && st.body.mfa.backupCodesLeft === 10, JSON.stringify(st.body))
  const c = new Client()
  const l = await c.auth('login', { email: 'bruno@teste.com', password: PW }); assert(l.body.mfaRequired === true, JSON.stringify(l.body))
  assert((await c.get('/api/me')).status === 401, 'sessão pendente não pode acessar')
  const bad = await c.auth('mfa_login', { code: '000000' }); assert(bad.status === 400, String(bad.status))
  const ok = await c.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(ok.status === 200, JSON.stringify(ok.body))
  assert((await c.get('/api/me')).status === 200, 'não entrou')
  const c2 = new Client(); await c2.auth('login', { email: 'bruno@teste.com', password: PW })
  const reuse = await c2.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(reuse.status === 400, 'código de recuperação reutilizado')
  const ok2 = await c2.auth('mfa_login', { code: totp(b.body.secret) }); assert(ok2.status === 200, 'TOTP recusado')
  const dis = await user.auth('mfa_disable', { password: PW, code: totp(b.body.secret) }); assert(dis.status === 200, JSON.stringify(dis.body))
})
await test('recuperar senha: token de uso único troca a senha e derruba sessões', async () => {
  const r = await anon.auth('recover', { email: 'bruno@teste.com' }); assert(r.status === 200 && r.body.message, JSON.stringify(r.body))
  // o link real vai por e-mail; no teste geramos um token conhecido direto no banco
  const { sha256 } = await import('../src/lib/security.js')
  const [u] = await d.query('SELECT id FROM users WHERE email = $1', ['bruno@teste.com'])
  await d.query('INSERT INTO password_resets (token_hash, user_id, expires_at, created_at) VALUES ($1,$2,$3,$4)', [sha256('tok-teste'), u.id, new Date(Date.now() + 3600e3).toISOString(), new Date().toISOString()])
  const c = new Client()
  const v = await c.auth('recovery', { token: 'tok-teste' }); assert(v.status === 200 && v.body.mfaRequired === false, JSON.stringify(v.body))
  assert((await c.get('/api/me')).status === 401, 'sessão de recuperação não deve acessar a API')
  const p = await c.auth('password', { password: 'NovaSenha456', passwordConfirm: 'NovaSenha456' }); assert(p.status === 200, JSON.stringify(p.body))
  assert((await user.get('/api/me')).status === 401, 'sessão antiga continuou ativa')
  const again = await new Client().auth('recovery', { token: 'tok-teste' }); assert(again.status === 400, 'token reutilizado')
  const l = await user.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'nova senha não funciona')
})
await test('alterar senha exige a senha atual', async () => {
  const r = await user.auth('password', { currentPassword: 'errada', password: 'Outra789x', passwordConfirm: 'Outra789x' }); assert(r.status === 400 && r.body.field === 'currentPassword', JSON.stringify(r.body))
})

console.log('\n== Perfil e configurações (/api/me)')
await test('PATCH /api/me salva perfil, configurações e ignora chaves desconhecidas', async () => {
  const r = await user.call('PATCH', '/api/me', { profile: { name: 'Bruno Souza' }, settings: { theme: 'light', timezone: 'America/Manaus', hack: 1 } })
  assert(r.body.profile.name === 'Bruno Souza' && r.body.settings.theme === 'light' && r.body.settings.timezone === 'America/Manaus' && !('hack' in r.body.settings), JSON.stringify(r.body.settings))
  await user.call('PATCH', '/api/me', { settings: { timezone: 'America/Sao_Paulo' } })
})
await test('plano expõe apenas recursos reconstruídos', async () => {
  const r = await user.get('/api/me'); assert(r.body.plan.features.includes('agenda') && !r.body.plan.features.includes('investments'), JSON.stringify(r.body.plan))
})

console.log('\n== Agenda, tarefas, lembretes, compras e notas (/api/items, /api/agenda)')
let taskId = 0, apptId = 0, remId = 0, shopId = 0, noteId = 0
await test('criar tarefa, compromisso, lembrete, compras e nota', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'task', data: { title: 'Comprar tinta' } }); taskId = r.body.item.id; assert(taskId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'Reunião', date: '2099-03-01', time: '10:30', location: 'Escritório', reminder_minutes: 15 } }); apptId = r.body.item.id; assert(apptId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Tomar água', date: '2099-03-01', time: '08:00', recurrence: 'daily' } }); remId = r.body.item.id; assert(r.body.item.remindAt === '2099-03-01T11:00:00.000Z', r.body.item.remindAt)
  r = await user.post('/api/items', { action: 'create', type: 'shopping', data: { items: [{ name: 'papel' }, { name: 'luvas' }] } }); shopId = r.body.items[0].id; assert(r.body.items.length === 2, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'note', data: { content: 'Senha do wi-fi do estúdio' } }); noteId = r.body.item.id; assert(noteId > 0, 'nota')
})
await test('validação: compromisso sem data é recusado (field=date)', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'X' } }); assert(r.status === 400 && r.body.field === 'date', JSON.stringify(r.body))
})
await test('GET /api/agenda devolve todos os grupos no formato do frontend', async () => {
  const r = await user.get('/api/agenda')
  for (const k of ['today', 'tz', 'tasks', 'appointments', 'reminders', 'shopping', 'notes', 'bills', 'sharedWithMe']) assert(k in r.body, `falta ${k}`)
  assert(r.body.tasks[0].title === 'Comprar tinta' && r.body.tasks[0].status === 'pending', 'tarefa')
  assert(r.body.shopping.some((s: any) => s.name === 'luvas' && s.listName === 'Compras' && s.done === false), 'compras')
})
await test('ações: concluir tarefa, marcar compra, fixar nota, adiar e concluir lembrete, alterar compromisso', async () => {
  await user.post('/api/items', { action: 'task_status', type: 'task', id: taskId, data: { status: 'done' } })
  await user.post('/api/items', { action: 'shopping_toggle', type: 'shopping', id: shopId })
  await user.post('/api/items', { action: 'note_pin', type: 'note', id: noteId })
  const sn = await user.post('/api/items', { action: 'reminder_snooze', type: 'reminder', id: remId, data: { minutes: 15 } }); assert(sn.body.item.snoozedUntil, 'snooze')
  const up = await user.post('/api/items', { action: 'appointment_update', type: 'appointment', id: apptId, data: { date: '2099-03-02', time: '11:00' } }); assert(up.body.item.date === '2099-03-02' && up.body.item.time === '11:00', JSON.stringify(up.body))
  const r = await user.get('/api/agenda')
  assert(r.body.tasks.find((t: any) => t.id === taskId).status === 'done', 'tarefa não concluída')
  assert(r.body.shopping.find((s: any) => s.id === shopId).done === true, 'compra não marcada')
  assert(r.body.notes.find((n: any) => n.id === noteId).pinned === true, 'nota não fixada')
})
await test('permissão: um usuário não altera nem vê registros de outro (404)', async () => {
  const r = await admin.post('/api/items', { action: 'delete', type: 'task', id: taskId }); assert(r.status === 404, String(r.status))
  const a = await admin.get('/api/agenda'); assert(!a.body.tasks.some((t: any) => t.id === taskId), 'vazamento entre contas')
})
await test('excluir registro', async () => {
  const r = await user.post('/api/items', { action: 'delete', type: 'note', id: noteId }); assert(r.status === 200, String(r.status))
  const a = await user.get('/api/agenda'); assert(!a.body.notes.some((n: any) => n.id === noteId), 'nota não excluída')
})

console.log('\n== Financeiro (/api/finance)')
let billId = 0
await test('lançar gasto e receita, cadastrar conta mensal', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: '45,90', description: 'Mercado', category: 'alimentacao' } }); assert(r.body.item.amount === 45.9, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'income', amount: 1000, description: 'Serviço', category: 'servicos' } }); assert(r.body.item.kind === 'income', 'receita')
  const today = (await user.get('/api/agenda')).body.today
  r = await user.post('/api/items', { action: 'create', type: 'bill', data: { name: 'Luz', amount: 180, due_date: today, recurrence: 'monthly', category: 'casa' } }); billId = r.body.item.id; assert(billId > 0, JSON.stringify(r.body))
})
await test('valor inválido é recusado (field=amount)', async () => { const r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: -3 } }); assert(r.body.field === 'amount', JSON.stringify(r.body)) })
await test('GET /api/finance calcula receitas, despesas, saldo, categorias e série', async () => {
  const r = await user.get('/api/finance')
  assert(r.body.income === 1000 && r.body.spent === 45.9, `${r.body.income}/${r.body.spent}`)
  assert(r.body.balance === Math.round((1000 - 45.9 - 180) * 100) / 100, String(r.body.balance))
  assert(r.body.byCategory[0].slug === 'alimentacao' && r.body.series.length === 6 && r.body.pendingBills.length === 1, JSON.stringify(r.body.byCategory))
})
await test('pagar conta mensal gera a próxima ocorrência; desfazer remove', async () => {
  const p = await user.post('/api/items', { action: 'pay_bill', type: 'bill', id: billId }); assert(p.body.item.status === 'paid', JSON.stringify(p.body))
  let [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill' AND status = 'pending'"); assert(Number(n.n) === 1, 'próxima conta não criada')
  await user.post('/api/items', { action: 'unpay_bill', type: 'bill', id: billId });
  [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill'"); assert(Number(n.n) === 1, 'próxima conta não removida')
})
await test('GET /api/day e /api/summary com dados reais', async () => {
  const today = (await user.get('/api/agenda')).body.today
  const r = await user.get(`/api/day?from=${today}&to=${today}`); assert(r.body.entries.some((e: any) => e.kind === 'bill'), JSON.stringify(r.body))
  const s = await user.get('/api/summary'); assert(s.body.summary.data.spent === 45.9 && s.body.summary.text.includes('45,90'), JSON.stringify(s.body))
})

console.log('\n== Chat com IA (/api/chat, /api/conversations, /api/memory)')
const conv = '11111111-2222-4333-8444-555555555555'
await test('mensagem simples cria conversa e grava as duas mensagens', async () => {
  const r = await user.post('/api/chat', { text: 'Oi, tudo bem?', conversationId: conv })
  assert(r.status === 200 && r.body.conversation.id === conv && r.body.userMessage.role === 'user' && r.body.assistantMessage.content.includes('Olá'), JSON.stringify(r.body))
})
await test('"gastei 35 no almoço" → grava gasto real e devolve cartão', async () => {
  const r = await user.post('/api/chat', { text: 'gastei 35 reais no almoço', conversationId: conv })
  assert(/⟦fin:\d+⟧/.test(r.body.assistantMessage.content) && /R\$\s?35,00/.test(r.body.assistantMessage.content), JSON.stringify(r.body.assistantMessage))
  const f = await user.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço' && e.amount === 35), 'gasto não gravado')
})
await test('compromisso e tarefa pelo chat ficam na agenda', async () => {
  await user.post('/api/chat', { text: 'marca compromisso no dentista', conversationId: conv })
  await user.post('/api/chat', { text: 'cria a tarefa enviar orçamento', conversationId: conv })
  const a = await user.get('/api/agenda')
  assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento' && t.priority === 'high'), 'tarefa')
  const day = await user.get('/api/day?from=2099-01-10&to=2099-01-10'); assert(day.body.entries.some((e: any) => e.title === 'Dentista'), 'compromisso')
})
await test('"lembre que..." salva memória visível no Perfil', async () => {
  await user.post('/api/chat', { text: 'lembre que prefiro respostas curtas', conversationId: conv })
  const m = await user.get('/api/memory'); assert(m.body.memories.some((x: any) => x.content === 'Prefere respostas curtas' && x.source === 'chat'), JSON.stringify(m.body))
})
await test('memória recusa senhas', async () => { const r = await user.post('/api/memory', { action: 'create', content: 'minha senha é 1234' }); assert(r.status === 400, String(r.status)) })
await test('histórico: GET /api/chat?c= devolve as mensagens; lista e busca de conversas', async () => {
  const r = await user.get(`/api/chat?c=${conv}`); assert(r.body.messages.length === 10, String(r.body.messages.length))
  const l = await user.get('/api/conversations'); assert(l.body.conversations[0].id === conv, 'lista')
  const s = await user.get('/api/conversations?q=dentista'); assert(s.body.conversations.length === 1, 'busca')
  const o = await admin.get(`/api/chat?c=${conv}`); assert(o.body.conversation === null, 'outra conta viu a conversa')
})
await test('editar e reenviar mensagem substitui a resposta anterior', async () => {
  const h = await user.get(`/api/chat?c=${conv}`)
  const first = h.body.messages.find((m: any) => m.role === 'user')
  const r = await user.post('/api/chat', { resendOf: first.id, conversationId: conv, text: 'Olá de novo' })
  assert(r.body.resent === true && r.body.superseded.length > 0 && r.body.userMessage.content === 'Olá de novo', JSON.stringify(r.body))
})
await test('renomear, fixar e excluir conversa', async () => {
  await user.call('PATCH', `/api/conversations/${conv}`, { title: 'Organização', pinned: true })
  let l = await user.get('/api/conversations'); assert(l.body.conversations[0].title === 'Organização' && l.body.conversations[0].pinned, 'renomear')
  const c2 = '99999999-2222-4333-8444-555555555555'
  await user.post('/api/chat', { text: 'oi', conversationId: c2 })
  await user.call('DELETE', `/api/conversations/${c2}`)
  l = await user.get('/api/conversations'); assert(!l.body.conversations.some((c: any) => c.id === c2), 'não excluiu')
})
await test('envio de áudio/foto (multipart) → 501 explícito, sem simulação', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: { Cookie: `ma_session=${user.jar.get('ma_session')}`, 'Content-Type': 'multipart/form-data; boundary=x' }, body: '--x--' })
  assert(r.status === 501, String(r.status))
})

console.log('\n== Sincronização offline (/api/sync)')
await test('fila offline: cria, conclui e é idempotente', async () => {
  const ops = [{ id: 'op-1', kind: 'create', type: 'task', data: { title: 'Feita offline' } }]
  const r = await user.post('/api/sync', { ops }); assert(r.body.results[0].status === 'done' && r.body.results[0].createdId > 0, JSON.stringify(r.body))
  const again = await user.post('/api/sync', { ops }); assert(again.body.results[0].createdId === r.body.results[0].createdId, 'duplicou')
  const done = await user.post('/api/sync', { ops: [{ id: 'op-2', kind: 'task_status', type: 'task', targetId: r.body.results[0].createdId, data: { status: 'done' } }] })
  assert(done.body.results[0].status === 'done', JSON.stringify(done.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'task' AND json_extract(data, '$.title') = 'Feita offline'"); assert(Number(n.n) === 1, 'duplicado')
})

console.log('\n== Notificações e agendador')
await test('lembrete vencido gera notificação; recorrente avança para o dia seguinte', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Pagar boleto', date: '2020-01-01', time: '09:00', recurrence: 'daily' } })
  await tick(new Date())
  const n = await user.get('/api/notifications'); assert(n.body.items.some((i: any) => i.title === 'Pagar boleto') && n.body.unread >= 1, JSON.stringify(n.body))
  const [row] = await d.query('SELECT day FROM items WHERE id = $1', [r.body.item.id]); assert(row.day === '2020-01-02', row.day)
  await tick(new Date()); const n2 = await user.get('/api/notifications?count=1'); assert(typeof n2.body.unread === 'number', 'contagem')
})
await test('marcar todas como lidas', async () => { const r = await user.post('/api/notifications', { all: true }); assert(r.body.unread === 0, JSON.stringify(r.body)) })

console.log('\n== Administração')
await test('usuário comum não acessa o painel', async () => {
  const r = await user.get('/api/admin'); assert(r.body.access === 'none', JSON.stringify(r.body))
  const u = await user.get('/api/admin/users'); assert(u.status === 403, String(u.status))
})
await test('Administrador Principal lista, cria, edita e desativa usuários (com auditoria)', async () => {
  const a = await admin.get('/api/admin'); assert(a.body.access === 'admin' && a.body.me.permissions.includes('users.manage'), JSON.stringify(a.body))
  const l = await admin.get('/api/admin/users?q=bruno'); assert(l.body.users.length === 1, JSON.stringify(l.body))
  const c = await admin.post('/api/admin/users', { action: 'create', name: 'Carla Dias', whatsapp: '+55 21 99999-0000', email: 'carla@teste.com', birthday: '1985-02-02', password: 'Inicial123', role: 'admin', permissions: ['users.view'] })
  assert(c.body.user.role === 'admin' && c.body.user.permissions.join() === 'users.view', JSON.stringify(c.body))
  const bruno = l.body.users[0]
  const s = await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'disabled' }); assert(s.body.user.status === 'disabled', 'status')
  assert((await user.get('/api/me')).status === 401, 'conta desativada continuou com sessão')
  const blocked = await new Client().auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(blocked.status === 403 && blocked.body.code === 'account_disabled', JSON.stringify(blocked.body))
  await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'active' })
  const au = await admin.get('/api/admin/audit'); assert(au.body.entries.some((e: any) => e.action === 'user.disable'), 'auditoria')
})
await test('admin com só "users.view" não pode criar usuários', async () => {
  const c = new Client(); await c.auth('login', { email: 'carla@teste.com', password: 'Inicial123' })
  const r = await c.post('/api/admin/users', { action: 'create', name: 'Teste Teste', whatsapp: '+5511988887777', email: 't@t.com', password: 'Abc12345' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Persistência após reinicialização')
const persisted = new Client()
await test('dados continuam após reiniciar servidor e banco', async () => {
  await new Promise<void>((r) => server.close(() => r()))
  await d.close()
  ;({ d, server, port } = await boot())
  const c = persisted; const l = await c.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'login após reinício')
  const a = await c.get('/api/agenda'); assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento'), 'tarefa perdida')
  const f = await c.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço'), 'gasto perdido')
  const h = await c.get(`/api/chat?c=${conv}`); assert(h.body.messages.length > 0, 'conversa perdida')
})

console.log('\n== Exclusão de conta')
await test('excluir conta apaga dados (cascata) e encerra sessão', async () => {
  const c = persisted // já autenticado no teste anterior (evita o limite de tentativas de login)
  const r = await c.post('/api/auth', { action: 'delete_account', password: 'NovaSenha456', confirm: 'EXCLUIR', acknowledge: true }); assert(r.status === 200, JSON.stringify(r.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items i JOIN users u ON u.id = i.user_id WHERE u.email = 'bruno@teste.com'"); assert(Number(n.n) === 0, 'sobrou dado')
  const [m] = await d.query('SELECT COUNT(*) AS n FROM messages'); assert(Number(m.n) === 0, 'mensagens não apagadas')
  assert((await c.get('/api/me')).status === 401, 'sessão continuou')
})

console.log('\n== Painel (módulos, IAs, fontes de mercado, Mercado Pago, planos)')
const mkSrv = createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ data: { price: 123.45 } })) })
await new Promise<void>((r) => mkSrv.listen(0, '127.0.0.1', r))
const mkPort = (mkSrv.address() as any).port
await test('painel exige administrador e não expõe chaves', async () => {
  const anon = new Client()
  assert((await anon.get('/api/panel')).status === 401, 'anônimo acessou')
  const g = await admin.get('/api/panel'); assert(g.status === 200 && g.body.canWrite === true, JSON.stringify(g.body).slice(0, 200))
  assert(g.body.ai_providers.some((p: any) => p.id === 'servidor') && g.body.ai_providers.every((p: any) => p.key === undefined), 'lista de IAs')
  const pub = await anon.get('/api/panel/public'); assert(pub.body.modules && pub.body.ad_plans.length === 4 && !JSON.stringify(pub.body).includes('tok'), 'público')
})
await test('módulos globais e planos são salvos e validados', async () => {
  const m = await admin.call('PUT', '/api/panel/modules', { mercado: false }); assert(m.body.modules.mercado === false && m.body.modules.fiscal === true, JSON.stringify(m.body.modules))
  const bad = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ nome: 'X', preco: -1, dias: 30, nivel: 1 }] }); assert(bad.status === 400, 'aceitou preço negativo')
  const ok = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ id: 'n1', nome: 'Básico', preco: 19.9, dias: 15, nivel: 1 }, { id: 'n4', nome: 'Loja', preco: 99, dias: 30, nivel: 4 }] })
  assert(ok.body.ad_plans.length === 2 && ok.body.ad_plans[0].preco === 19.9, JSON.stringify(ok.body.ad_plans))
  const r = await admin.call('PUT', '/api/panel/search', { raio: 500 }); assert(r.status === 400, 'raio inválido aceito')
})
await test('Mercado Pago guarda o token cifrado e devolve só mascarado', async () => {
  const s = await admin.call('PUT', '/api/panel/mercadopago', { modo: 'teste', teste: { pub: 'TEST-abc123456789', tok: 'TEST-1234567890-segredo-muito-longo' } })
  assert(s.body.mercadopago.teste.tok.hasKey && s.body.mercadopago.teste.tok.keyMasked.includes('••'), JSON.stringify(s.body.mercadopago))
  const raw = await d.query("SELECT value FROM app_config WHERE key = 'mercadopago'")
  assert(!String(raw[0].value).includes('segredo-muito-longo'), 'token gravado sem cifra')
  const bad = await admin.call('PUT', '/api/panel/mercadopago', { teste: { tok: 'chave-errada-123456' } }); assert(bad.status === 400, 'token inválido aceito')
})
await test('IA com troca automática: chave recusada é pausada e a próxima responde', async () => {
  const items = [{ id: 'c-falha', nome: 'IA com chave errada', base_url: `http://127.0.0.1:${aiPort}/v1`, modelo: 'duble', key: 'chave-errada-xyz', texto: true, ativo: true }, { id: 'servidor', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/ai_providers', { items }); assert(s.status === 200 && s.body.ai_providers[0].hasKey, JSON.stringify(s.body).slice(0, 300))
  const c = await admin.post('/api/chat', { text: 'oi, tudo bem?', conversationId: '99999999-2222-4333-8444-555555555555' }); assert(c.status === 200, 'chat falhou: ' + JSON.stringify(c.body))
  const g = await admin.get('/api/panel'); assert(g.body.ai_runtime.paused['c-falha']?.expired === true, JSON.stringify(g.body.ai_runtime))
  const t = await admin.post('/api/panel/test', { kind: 'ai', id: 'c-falha' }); assert(t.body.ok === false && /recusada/.test(t.body.message), JSON.stringify(t.body))
  const t2 = await admin.post('/api/panel/test', { kind: 'ai', id: 'servidor' }); assert(t2.body.ok === true, JSON.stringify(t2.body))
})
await test('fonte de mercado personalizada: cadastro, teste e cotação', async () => {
  const g = await admin.get('/api/panel')
  const items = [...g.body.market_providers.map((p: any) => ({ id: p.id, ativo: false })), { id: 'c-minha', nome: 'Minha API', cat: 'cripto', url: `http://127.0.0.1:${mkPort}/q/{SIMBOLO}`, campo: 'data.price', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/market_providers', { items }); assert(s.status === 200, JSON.stringify(s.body).slice(0, 300))
  const t = await admin.post('/api/panel/test', { kind: 'market', id: 'c-minha' }); assert(t.body.ok === true, JSON.stringify(t.body))
  const q = await admin.get('/api/v2/market/quote?s=btc'); assert(q.body.price === 123.45 && q.body.source === 'Minha API', JSON.stringify(q.body))
})
await admin.call('PUT', '/api/panel/modules', { mercado: true })
console.log('\n== Módulos reais: Mercado e Impostos/DAS')
await test('impostos: DAS calculado pelo salário mínimo, faturamento e guia paga', async () => {
  const f = await admin.get('/api/v2/fiscal'); assert(f.status === 200 && f.body.das.total === 82.05, JSON.stringify(f.body.das))
  const k = new Date().toISOString().slice(0, 7)
  const p = await admin.call('PUT', '/api/v2/fiscal', { atividade: 'servicos', receitas: { [k]: 1500 }, consent: true })
  assert(p.body.das.total === 86.05 && p.body.faturamento === 1500 && p.body.perfil.consent === true, JSON.stringify(p.body).slice(0, 300))
  const bad = await admin.call('PUT', '/api/v2/fiscal', { atividade: 'pirata' }); assert(bad.status === 400, 'atividade inválida aceita')
})
await test('chat responde DAS, cotação e receita com dados reais, sem chamar a IA', async () => {
  const before = aiCalls, cv = '77777777-2222-4333-8444-555555555555'
  const d = await admin.post('/api/chat', { text: 'quanto vou pagar de DAS?', conversationId: cv }); assert(/86,05/.test(d.body.assistantMessage.content), JSON.stringify(d.body).slice(0, 300))
  const c = await admin.post('/api/chat', { text: 'crypto btc', conversationId: cv }); assert(/123,45/.test(c.body.assistantMessage.content) && /⟦mkt:BTC⟧/.test(c.body.assistantMessage.content) && /Minha API/.test(c.body.assistantMessage.content), c.body.assistantMessage?.content)
  const r = await admin.post('/api/chat', { text: 'recebi 500 de um cliente', conversationId: cv }); assert(/2\.000,00/.test(r.body.assistantMessage.content), r.body.assistantMessage?.content)
  assert(aiCalls === before, 'a IA foi chamada sem necessidade')
  const g = await admin.post('/api/chat', { text: 'gastei 35 reais no almoço', conversationId: cv }); assert(/⟦fin:\d+⟧/.test(g.body.assistantMessage.content) && /Gasto registrado/.test(g.body.assistantMessage.content) && aiCalls === before, JSON.stringify(g.body.assistantMessage).slice(0, 300))
})
await test('alerta de preço: criado no chat e disparado pelo agendador com notificação', async () => {
  const cv = '66666666-2222-4333-8444-555555555555'
  const a = await admin.post('/api/chat', { text: 'me avise se o bitcoin chegar a R$ 100', conversationId: cv }); assert(/cair até/.test(a.body.assistantMessage.content), a.body.assistantMessage?.content)
  const l = await admin.get('/api/v2/market/alerts'); assert(l.body.alerts.length === 1 && !l.body.alerts[0].firedAt, JSON.stringify(l.body))
  await admin.post('/api/v2/market/alerts', { symbol: 'BTC', cond: 'acima', value: 100 })
  const { checkModules } = await import('../src/modules-scheduler.js'); await checkModules(new Date(Date.now() + 10 * 60_000))
  const l2 = await admin.get('/api/v2/market/alerts'); assert(l2.body.alerts.find((x: any) => x.cond === 'acima').firedAt, 'alerta não disparou')
  const n = await admin.get('/api/notifications'); assert(JSON.stringify(n.body).includes('BTC subiu até'), JSON.stringify(n.body).slice(0, 300))
})
await test('módulo desligado no painel bloqueia a API', async () => {
  await admin.call('PUT', '/api/panel/modules', { fiscal: false })
  const f = await admin.get('/api/v2/fiscal'); assert(f.status === 403 && f.body.code === 'module_disabled', JSON.stringify(f.body))
  await admin.call('PUT', '/api/panel/modules', { fiscal: true })
})
console.log('\n== Anúncios: proposta, aprovação e Pix (Mercado Pago simulado)')
let mpBody: any = null
const mpSrv = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  res.writeHead(200, { 'Content-Type': 'application/json' })
  if (req.url === '/users/me') return res.end(JSON.stringify({ id: 123, nickname: 'LOJATESTE' }))
  if (req.method === 'POST') { mpBody = JSON.parse(body); return res.end(JSON.stringify({ id: 999, status: 'pending', point_of_interaction: { transaction_data: { qr_code: '00020101PIXTESTE', qr_code_base64: 'iVBORw0KGgo=' } } })) }
  res.end(JSON.stringify({ id: 999, status: 'approved', external_reference: mpBody?.external_reference }))
})
await new Promise<void>((r) => mpSrv.listen(0, '127.0.0.1', r))
process.env.MP_API_BASE = `http://127.0.0.1:${(mpSrv.address() as any).port}`
const dono = new Client()
await test('usuário cria anúncio com plano e fica aguardando pagamento', async () => {
  const s = await dono.auth('signup', { name: 'Dona Pizzaria', whatsapp: '+55 11 97777-6666', email: 'dona@pizza.com', birthday: '1988-03-03', password: 'Pizza@12345', passwordConfirm: 'Pizza@12345' })
  assert(s.status === 200, JSON.stringify(s.body))
  const p = await dono.get('/api/v2/ads/plans'); assert(p.body.plans.length >= 1, 'planos')
  const bad = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'X' }); assert(bad.status === 400, 'aceitou proposta incompleta')
  const c = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'Pizzaria Forno', categoria: 'Pizzaria', titulo: 'Pizza no forno a lenha', texto: 'Entrega rápida', zap: '5511977776666', lat: -23.55, lng: -46.63, raio: 5 })
  assert(c.status === 200 && c.body.items[0].status === 'pagamento' && c.body.items[0].plan.nivel === 4, JSON.stringify(c.body).slice(0, 300))
})
await test('dono paga por Pix; webhook envia para aprovação; admin aprova e entra no ar', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const pay = await dono.post(`/api/v2/ads/${ad.id}/pay`, {}); assert(pay.body.payment?.qr === '00020101PIXTESTE' && mpBody.transaction_amount > 0 && mpBody.payment_method_id === 'pix', JSON.stringify(pay.body))
  const w = await new Client().post(`/api/mercadopago/webhook?type=payment&data.id=999`, {}); assert(w.status === 200, JSON.stringify(w.body))
  const m1 = await dono.get('/api/v2/ads/mine'); assert(m1.body.items[0].status === 'analise', 'deveria ir para aprovação: ' + m1.body.items[0].status)
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('Enviamos seu anúncio para aprovação'), 'dono não foi avisado do pagamento')
  const na = await admin.get('/api/notifications'); assert(JSON.stringify(na.body).includes('Novo anúncio pago para aprovar'), 'admin não foi avisado')
  assert((await dono.get('/api/v2/admin/ads')).status === 403, 'usuário comum acessou admin de anúncios')
  const sem = await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'reject' }); assert(sem.status === 400, 'recusa sem motivo aceita')
  const a = await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'approve' }); assert(a.body.items.find((x: any) => x.id === ad.id).status === 'ativo', 'aprovação não pôs no ar')
  const m = await dono.get('/api/v2/ads/mine'); assert(m.body.items[0].status === 'ativo' && m.body.items[0].expiresAt, JSON.stringify(m.body.items[0]).slice(0, 300))
  const nn = await dono.get('/api/notifications'); assert(JSON.stringify(nn.body).includes('aprovado e está no ar'), 'dono não foi avisado da aprovação')
})
await test('administrador cria anúncio já publicado, sem aprovação nem pagamento', async () => {
  const c = await admin.post('/api/v2/ads', { planId: 'n1', empresa: 'Anúncio da Casa', categoria: 'Serviços', titulo: 'Conheça o Meu Assistente', texto: 'Teste' })
  assert(c.body.items[0].status === 'ativo' && c.body.items[0].expiresAt, JSON.stringify(c.body.items[0]).slice(0, 200))
})
console.log('\n== Empresas, loja e pedidos')
const cliente = new Client()
await test('busca por ramo pede localização e depois mostra a empresa no raio', async () => {
  await cliente.auth('signup', { name: 'Cliente Teste', whatsapp: '+55 11 96666-5555', email: 'cli@teste.com', birthday: '1991-04-04', password: 'Cliente@123', passwordConfirm: 'Cliente@123' })
  const cv = '55555555-2222-4333-8444-555555555555'
  const a = await cliente.post('/api/chat', { text: 'pizzarias', conversationId: cv }); assert(/⟦loc:/.test(a.body.assistantMessage.content), a.body.assistantMessage?.content)
  const s0 = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s0.body.needLocation === true, 'deveria pedir localização')
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632 })
  const s1 = await cliente.get('/api/v2/businesses/search?q=pizzarias'); assert(s1.body.items.length === 1 && s1.body.items[0].temLoja && s1.body.items[0].distancia < 1, JSON.stringify(s1.body))
  const b = await cliente.post('/api/chat', { text: 'pizzaria perto de mim', conversationId: cv }); const ids = (b.body.assistantMessage.content.match(/⟦emp:([\d,]+)⟧/) || [])[1]; assert(ids, b.body.assistantMessage?.content)
  const cards = await cliente.get('/api/v2/businesses/cards?ids=' + ids); assert(cards.body.items[0].empresa === 'Pizzaria Forno' && cards.body.items[0].temLoja, JSON.stringify(cards.body))
  await cliente.call('PUT', '/api/v2/me/location', { lat: -22.9, lng: -43.17 })
  const s2 = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s2.body.items.length === 0, 'mostrou empresa fora do raio')
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632 })
})
await test('dono cadastra produto com variação; cliente pede; preço calculado no servidor; dono aceita', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const semFoto = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Margherita', preco: 45 }); assert(semFoto.status === 400, 'aceitou produto sem foto')
  const foto = 'data:image/jpeg;base64,' + 'A'.repeat(100)
  const p = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Margherita', preco: 45, categoria: 'Pizzas', fotos: [foto], variacoes: [{ nome: 'Tamanho', opcoes: [{ nome: 'Média', preco: 45 }, { nome: 'Grande', preco: 56 }] }, { nome: 'Borda', opcoes: [{ nome: 'Tradicional', preco: 0 }, { nome: 'Catupiry', preco: 9 }] }] })
  assert(p.body.items.length === 1, JSON.stringify(p.body).slice(0, 200))
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { entrega: { retirada: true, entrega: true, taxa: 6, raio: 5, minimo: 20 }, pagamento: { pix: true, dinheiro: true } })
  const page = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(page.body.loja && page.body.produtos.length === 1 && page.body.entrega.taxa === 6, JSON.stringify(page.body).slice(0, 300))
  const pid = page.body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 2, escolhas: { Tamanho: 1, Borda: 1 }, obs: 'sem cebola' }], modo: 'entrega', endereco: 'Rua A, 10', pagamento: 'pix' })
  assert(o.body.order.total === 136 && o.body.order.status === 'novo', JSON.stringify(o.body)) // (56+9)*2 + 6
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('Novo pedido'), 'dono não foi avisado')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); const oid = lst.body.items[0].id
  const bad = await dono.post(`/api/v2/ads/${ad.id}/orders/${oid}`, { status: 'concluido' }); assert(bad.status === 400, 'pulou etapas')
  const ok = await dono.post(`/api/v2/ads/${ad.id}/orders/${oid}`, { status: 'aceito' }); assert(ok.body.items[0].status === 'aceito', 'não aceitou')
  const nc = await cliente.get('/api/notifications'); assert(JSON.stringify(nc.body).includes('foi aceito'), 'cliente não foi avisado')
  const mine = await cliente.get('/api/v2/orders/mine'); assert(mine.body.items[0].status === 'aceito', 'meus pedidos')
})
await test('loja com Mercado Pago próprio: pedido com Pix automático e confirmação pelo webhook', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const bad = await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'qualquer' }); assert(bad.status === 400, 'aceitou token inválido')
  const ok = await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'TEST-998877665544-loja' }); assert(ok.body.mpLoja && ok.body.mpMasked.includes('••'), JSON.stringify(ok.body))
  const t = await dono.post(`/api/v2/ads/${ad.id}/mp`, { action: 'test' }); assert(t.body.ok, JSON.stringify(t.body))
  const mine = await dono.get('/api/v2/ads/mine'); assert(!JSON.stringify(mine.body).includes('998877'), 'token da loja vazou')
  const page = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(page.body.pagamento.online === true, 'pagamento online não ficou disponível')
  const pid = page.body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'online' })
  assert(o.body.order.payment?.qr === '00020101PIXTESTE' && !o.body.order.pago, JSON.stringify(o.body).slice(0, 300))
  await new Client().post(`/api/mercadopago/webhook?store=${ad.id}&type=payment&data.id=999`, {})
  const mineO = await cliente.get('/api/v2/orders/mine'); assert(mineO.body.items[0].pago === true, 'pedido não foi marcado como pago')
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('PAGO'), 'loja não foi avisada do pagamento')
})
await test('loja fecha pelo botão manual e bloqueia pedidos; voz natural responde sem erro', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'fechado', dias: {} } })
  const c = await cliente.get(`/api/v2/businesses/cards?ids=${ad.id}`); assert(c.body.items[0].aberto === false, 'deveria estar fechada')
  const pid = (await cliente.get(`/api/v2/businesses/${ad.id}`)).body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'dinheiro' }); assert(o.status === 400 && o.body.code === 'closed', JSON.stringify(o.body))
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
  const t = await cliente.get('/api/tts'); assert(t.status === 200 && t.body.available === false, 'tts deveria responder')
})
await test('preferência de notificação desligada é respeitada', async () => {
  await cliente.call('PATCH', '/api/me', { settings: { notifyMarket: false } })
  await cliente.post('/api/v2/market/alerts', { symbol: 'BTC', cond: 'acima', value: 1 })
  const { checkModules } = await import('../src/modules-scheduler.js'); await checkModules(new Date(Date.now() + 30 * 60_000))
  const n = await cliente.get('/api/notifications'); assert(!JSON.stringify(n.body).includes('BTC subiu'), 'notificou mesmo desligado')
})
await test('painel: testar Mercado Pago, botões rápidos e raio do usuário', async () => {
  const t = await admin.post('/api/panel/test', { kind: 'mp', modo: 'teste' }); assert(t.body.ok && /LOJATESTE/.test(t.body.message), JSON.stringify(t.body))
  const q = await admin.call('PUT', '/api/panel/quick_buttons', { enabled: true, custom: true, items: ['Resumo do meu mês', '', 'Como está o bitcoin?'] })
  assert(q.body.quick_buttons.items.length === 2 && q.body.quick_buttons.custom, JSON.stringify(q.body.quick_buttons))
  const pub = await new Client().get('/api/panel/public'); assert(pub.body.quick_buttons.items[0] === 'Resumo do meu mês', 'botões não públicos')
  await cliente.call('PUT', '/api/v2/me/location', { raio: 1 })
  const s = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s.body.location.raio === 1 && s.body.items.length === 1, JSON.stringify(s.body).slice(0, 200))
  const pg = await new Client().get('/api/v2/businesses/' + s.body.items[0].id); assert(pg.status === 200 && pg.body.loja, 'página da loja deveria abrir sem login')
  await admin.call('PUT', '/api/panel/modules', { voz: false })
  const me = await cliente.get('/api/me'); assert(!JSON.stringify(me.body.plan.features).includes('voice_mode'), 'voz continuou ativa')
  await admin.call('PUT', '/api/panel/modules', { voz: true })
})
await test('Biblioteca de Sobrevivência: materiais iniciais, download em partes conferido e cadastro pelo admin', async () => {
  const { seedKb } = await import('../src/routes/kb.js'); await seedKb()
  const l = await cliente.get('/api/kb-offline'); assert(l.body.docs.length >= 6 && l.body.docs.every((d: any) => d.digest && d.parts >= 1), JSON.stringify(l.body).slice(0, 200))
  const d0 = l.body.docs[0]; let all: any[] = []
  for (let m = 0; m < d0.parts; m++) all = all.concat((await cliente.get(`/api/kb-offline?id=${d0.id}&v=${d0.version}&part=${m}`)).body.chunks)
  const { createHash } = await import('node:crypto')
  const dg = createHash('sha256').update([...all].sort((a, b) => a.p - b.p).map((a) => `${a.p}\u001f${a.s}\u001f${a.e}\u001f${a.r ?? ''}\u001f${a.c}`).join('\u001e')).digest('hex')
  assert(all.length === d0.chunks && dg === d0.digest, 'conteúdo baixado não confere com o digest')
  assert((await cliente.get('/api/v2/admin/kb')).status === 403, 'usuário comum acessou o cadastro')
  const c = await admin.post('/api/v2/admin/kb', { title: 'Abrigo no frio', keywords: 'frio, abrigo', content: '# Proteja-se\nUse várias camadas de roupa.' })
  assert(c.body.items.some((x: any) => x.title === 'Abrigo no frio' && x.chunks === 1), JSON.stringify(c.body).slice(0, 200))
  const l2 = await cliente.get('/api/kb-offline'); assert(l2.body.docs.some((x: any) => x.title === 'Abrigo no frio'), 'novo material não apareceu')
})
await test('planos de uso: limite diário grátis, assinatura por Pix libera o plano; anúncio aparece no chat', async () => {
  const cfg = (await admin.get('/api/panel')).body.usage_plans
  await admin.call('PUT', '/api/panel/usage_plans', { ...cfg, ativo: true, free: { nome: 'Grátis', limites: { ...cfg.free.limites, chat: 1, appointment: 1 } } })
  const u0 = await cliente.get('/api/v2/usage'); assert(u0.body.ativo && u0.body.plano.id === 'free', JSON.stringify(u0.body).slice(0, 200))
  const cv = '44444444-2222-4333-8444-555555555555'
  await cliente.post('/api/chat', { text: 'oi', conversationId: cv })
  const l = await cliente.post('/api/chat', { text: 'oi de novo', conversationId: cv }); assert(/limite/.test(l.body.assistantMessage.content) && /⟦btn:\/x\/planos/.test(l.body.assistantMessage.content), l.body.assistantMessage?.content)
  const a1 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'A', date: '2026-12-01', time: '10:00' } }); assert(a1.status === 200, JSON.stringify(a1.body))
  const a2 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'B', date: '2026-12-02', time: '10:00' } }); assert(a2.status === 429 && a2.body.code === 'limit_reached', JSON.stringify(a2.body))
  const sp = await cliente.post('/api/v2/subscription', { planId: 'p2' }); assert(sp.body.payment?.qr, JSON.stringify(sp.body))
  await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const u1 = await cliente.get('/api/v2/usage'); assert(u1.body.plano.id === 'p2' && u1.body.plano.expiresAt, JSON.stringify(u1.body.plano))
  const a3 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'C', date: '2026-12-03', time: '10:00' } }); assert(a3.status === 200, 'plano não liberou')
  await admin.call('PUT', '/api/panel/usage_plans', { ...cfg, ativo: false })
  await admin.call('PUT', '/api/panel/ad_frequency', { ativo: true, cada: 1, intervaloMin: 0 })
  const ad = await cliente.post('/api/chat', { text: 'bom dia', conversationId: cv }); assert(/⟦ad:\d+⟧/.test(ad.body.assistantMessage.content), ad.body.assistantMessage?.content)
  await admin.call('PUT', '/api/panel/ad_frequency', { ativo: false, cada: 6, intervaloMin: 30 })
})
await test('motor configurável, entrega por km, renovação de anúncio e agente de atendimento', async () => {
  const e = await admin.call('PUT', '/api/panel/engine', { naturalidade: 90, personalidade: 'divertido', criatividade: 80, contexto: 100, autonomia: 60, precisao: 90 }); assert(e.body.engine.personalidade === 'divertido', JSON.stringify(e.body.engine))
  const { engineCfg } = await import('../src/ai/provider.js'); const ec = await engineCfg(); assert(ec.temperature > 0.7 && ec.historico === 40, JSON.stringify(ec))
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { entrega: { retirada: true, entrega: true, raio: 10, modoTaxa: 'km', kmGratis: 0.1, taxaExcedente: 3, taxaKm: 2 } })
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632, raio: 10 })
  const pid = (await cliente.get(`/api/v2/businesses/${ad.id}`)).body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'entrega', endereco: 'Rua B, 20', pagamento: 'dinheiro' })
  assert(o.body.order.taxa > 3 && o.body.order.taxa < 4, 'taxa por km errada: ' + JSON.stringify(o.body).slice(0, 200))
  // renovar: encerra e sobe de novo
  await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'end' })
  const r1 = await dono.post(`/api/v2/ads/${ad.id}/renew`, { planId: 'n4' }); assert(r1.body.items.find((x: any) => x.id === ad.id).status === 'pagamento', 'renovação não foi para pagamento')
  const keep = r1.body.items.find((x: any) => x.id === ad.id); assert(keep.empresa === 'Pizzaria Forno' && keep.entrega?.modoTaxa === 'km', 'dados não foram mantidos')
  await dono.post(`/api/v2/ads/${ad.id}/pay`, {}); await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const r2 = await dono.get('/api/v2/ads/mine'); assert(r2.body.items.find((x: any) => x.id === ad.id).status === 'ativo', 'renovação paga deveria voltar ao ar')
  // agente
  await admin.call('PUT', '/api/panel/modules', { agente: true })
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', saudacao: 'Oi! Sou a Lia.', instrucoes: 'Ofereça a pizza do dia.' })
  const off = await new Client().get(`/api/v2/agent/${ad.id}`); assert(off.status === 404 && off.body.info?.empresa === 'Pizzaria Forno', 'agente sem pagamento deveria mostrar página amigável')
  const teste = await dono.get(`/api/v2/agent/${ad.id}`); assert(teste.status === 200 && teste.body.teste === true, 'dono deveria poder testar')
  const ap = await dono.post(`/api/v2/ads/${ad.id}/agent/pay`, {}); assert((ap.body.payment?.qr || ap.body.ativo) && mpBody.date_of_expiration?.endsWith('-03:00'), JSON.stringify(ap.body)) // o simulador aprova na hora
  await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const ad2 = await dono.post('/api/v2/ads', { planId: 'n1', empresa: 'Outra', categoria: 'Teste', titulo: 'T' }); const id2 = ad2.body.items.find((x: any) => x.empresa === 'Outra').id
  const ag2 = await dono.call('PUT', `/api/v2/ads/${id2}/agent`, { nome: 'Bia' }); assert(ag2.status === 409 && ag2.body.code === 'agent_exists', 'permitiu segundo agente')
  const dupl = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'Outra loja', categoria: 'Teste', titulo: 'T', zap: '5511999990000' }); assert(dupl.status === 409 && dupl.body.code === 'plan_in_use', 'permitiu dois anúncios no mesmo plano')
  const info = await dono.get(`/api/v2/ads/${ad.id}/agent`); assert(info.body.ativo && /\/a\/\d+$/.test(info.body.link), JSON.stringify(info.body))
  const pub = await new Client().get(`/api/v2/agent/${ad.id}`); assert(pub.body.nome === 'Lia' && pub.body.saudacao === 'Oi! Sou a Lia.', JSON.stringify(pub.body))
  const before = aiCalls; const c = await new Client().post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'quanto custa a margherita?' }] })
  assert(c.status === 200 && c.body.reply && aiCalls > before, JSON.stringify(c.body))
  const page = await fetch(`http://127.0.0.1:${port}/a/${ad.id}`); assert(page.status === 200 && (await page.text()).includes('Atendimento automático'), 'página pública do agente')
})
await test('acessos, relatórios (com IA e MEI) e avisos de vencimento', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await cliente.get(`/api/v2/businesses/${ad.id}`); await cliente.get(`/api/v2/businesses/${ad.id}`); await dono.get(`/api/v2/businesses/${ad.id}`)
  await cliente.post(`/api/v2/businesses/${ad.id}/hit`, { kind: 'whatsapp' })
  const r = await dono.get(`/api/v2/ads/${ad.id}/report?dias=30`)
  assert(r.body.acessos.visitas >= 1 && r.body.acessos.contatos === 1 && r.body.acessos.pedidos >= 1 && r.body.serie.length === 30, JSON.stringify(r.body.acessos))
  assert((await cliente.get(`/api/v2/ads/${ad.id}/report`)).status === 404, 'outro usuário viu o relatório')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); const oc = lst.body.items.find((o: any) => o.status === 'aceito')
  if (oc) { await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'preparo' }); await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'pronto' }); await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'concluido' }) }
  const r2 = await dono.get(`/api/v2/ads/${ad.id}/report?dias=30`); assert(r2.body.vendas.faturamento > 0 && r2.body.vendas.topProdutos.length, JSON.stringify(r2.body.vendas))
  const ai = await dono.post(`/api/v2/ads/${ad.id}/report/ai`, { dias: 30 }); assert(ai.status === 200 && ai.body.texto, JSON.stringify(ai.body))
  const m1 = await dono.post(`/api/v2/ads/${ad.id}/report/mei`, {}); assert(m1.body.adicionado > 0, JSON.stringify(m1.body))
  const m2 = await dono.post(`/api/v2/ads/${ad.id}/report/mei`, {}); assert(m2.body.adicionado === 0, 'lançou em dobro')
  const { q } = await import('../src/db/index.js')
  await q('UPDATE businesses SET expires_at = $1 WHERE id = $2', [new Date(Date.now() + 2.5 * 86400_000).toISOString(), ad.id])
  const { expiryAlerts } = await import('../src/modules-scheduler.js'); await expiryAlerts(new Date())
  const n = await dono.get('/api/notifications'); assert(JSON.stringify(n.body).includes('Faltam 3 dias'), 'aviso de vencimento não chegou')
})
await test('serviços com agendamento, etiquetas e tema do catálogo', async () => {
  const sv = await admin.post('/api/v2/ads', { planId: 'n1', empresa: 'Barbearia Navalha', categoria: 'Barbearia', titulo: 'Corte e barba' })
  const bar = sv.body.items.find((x: any) => x.empresa === 'Barbearia Navalha'); assert(bar.tipo === 'servicos', 'nicho não reconhecido: ' + bar.tipo)
  // plano 3 não tem produtos: usa o plano 4 da pizzaria para serviço? cria serviço na barbearia exige plano 4
  const ad4 = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const upd = (await dono.call('PUT', `/api/v2/ads/${ad4.id}`, { etiquetas: [{ nome: 'Black Friday', cor: '#111111' }], tema: { preset: 'elegante', cor: '#c9a227', fundo: 'escuro', layout: 'grade' } })).body.items.find((x: any) => x.id === ad4.id); const tag = upd.etiquetas[0]; assert(upd.tema.layout === 'grade', 'tema não salvo')
  const s1 = await dono.post(`/api/v2/ads/${ad4.id}/products`, { tipo: 'servico', nome: 'Festa com pizzaiolo', preco: 100, modoPreco: 'hora', duracao: 120, tags: [tag.id] }); assert(s1.status === 200, JSON.stringify(s1.body))
  const page = await cliente.get(`/api/v2/businesses/${ad4.id}`); const svc = page.body.produtos.find((p: any) => p.tipo === 'servico'); assert(svc && svc.tags[0] === tag.id && page.body.etiquetas[0].nome === 'Black Friday', 'serviço/etiqueta não aparecem')
  const d = new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10)
  await dono.call('PUT', `/api/v2/ads/${ad4.id}`, { horarioCfg: { modo: 'aberto', dias: Object.fromEntries(['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'].map((k) => [k, { ativo: true, abre: '10:00', fecha: '16:00' }])) } })
  const sl = await cliente.get(`/api/v2/businesses/${ad4.id}/slots?servico=${svc.id}&data=${d}`); assert(sl.body.horarios[0] === '10:00', JSON.stringify(sl.body))
  const bk = await cliente.post(`/api/v2/businesses/${ad4.id}/bookings`, { servico: svc.id, data: d, hora: '10:00' }); assert(bk.body.order.total === 200, JSON.stringify(bk.body))
  const again = await cliente.post(`/api/v2/businesses/${ad4.id}/bookings`, { servico: svc.id, data: d, hora: '11:00' }); assert(again.status === 409, 'permitiu horário sobreposto')
  const sl2 = await cliente.get(`/api/v2/businesses/${ad4.id}/slots?servico=${svc.id}&data=${d}`); assert(!sl2.body.horarios.includes('10:00') && sl2.body.horarios.includes('12:00'), JSON.stringify(sl2.body))
  const lst = await dono.get(`/api/v2/ads/${ad4.id}/orders`); const bo = lst.body.items.find((o: any) => o.tipo === 'agendamento')
  const ok = await dono.post(`/api/v2/ads/${ad4.id}/orders/${bo.id}`, { status: 'aceito' }); assert(ok.status === 200, JSON.stringify(ok.body))
  const nc = await cliente.get('/api/notifications'); assert(JSON.stringify(nc.body).includes('foi confirmado'), 'cliente não soube da confirmação')
  const t = (await cliente.get(`/api/v2/businesses/${ad4.id}`)); assert(t.body.tipo, 'tipo ausente')
})
await test('compromisso pelo chat sem inventar local, com aviso e convite compartilhável', async () => {
  const { parseAppointment } = await import('../src/ai/appt.js')
  const p1 = parseAppointment('agendar uma reunião amanhã às 10:00 com João', 'America/Sao_Paulo'); assert(p1 && p1.title === 'Reunião com João' && p1.time === '10:00' && p1.person === 'João', JSON.stringify(p1))
  assert(parseAppointment('marca dentista sexta 15h', 'America/Sao_Paulo')?.title === 'Dentista', JSON.stringify(parseAppointment('marca dentista sexta 15h', 'America/Sao_Paulo')))
  assert(parseAppointment('gastei 50 no mercado', 'America/Sao_Paulo') === null, 'confundiu gasto com compromisso')
  const before = aiCalls, cv = '33333333-2222-4333-8444-555555555555'
  const r = await cliente.post('/api/chat', { text: 'agendar uma reunião amanhã às 10:00 com João', conversationId: cv })
  const c = r.body.assistantMessage; assert(/Reunião com João/.test(c.content) && /⟦appt:\d+⟧/.test(c.content) && aiCalls === before, c.content)
  const id = c.content.match(/⟦appt:(\d+)⟧/)[1]
  const ap = await cliente.get(`/api/v2/appointments/${id}`); assert(ap.body.location === '' && ap.body.reminderMinutes > 0 && ap.body.person === 'João', JSON.stringify(ap.body))
  const sh = await cliente.post(`/api/v2/appointments/${id}/share`, {}); assert(/\/c\/[\w-]+$/.test(sh.body.url), JSON.stringify(sh.body))
  const pub = await new Client().get(`/api/v2/share/${sh.body.token}`); assert(pub.body.title === 'Reunião com João' && pub.body.convidadoPor === 'Cliente', JSON.stringify(pub.body))
  assert((await new Client().get('/api/v2/share/naoexiste123')).status === 404, 'token inválido abriu')
  const lg = await cliente.post('/api/appointments', { action: 'invite.create', id: Number(id), people: [{ quick: true }] }); assert(lg.body.invites[0].link === sh.body.url, 'avião do cartão não gerou o mesmo link: ' + JSON.stringify(lg.body))
  const lgg = await cliente.get(`/api/appointments?id=${id}`); assert(lgg.body.appointment.title === 'Reunião com João' && lgg.body.ended === false, JSON.stringify(lgg.body))
  const pg = await fetch(`http://127.0.0.1:${port}/c/${sh.body.token}`); assert(pg.status === 200 && (await pg.text()).includes('Criar minha conta'), 'página do convite')
})
await test('motor financeiro universal: tipos, categorias, forma de pagamento, valor faltando e duplicidade', async () => {
  const { parseFinance } = await import('../src/ai/fin.js'); const tz = 'America/Sao_Paulo'
  const cases: [string, string, number | null, string, string?][] = [
    ['gastei 80 reais de gasolina', 'despesa', 80, 'combustivel'], ['comprei um tênis por R$ 249,90 no cartão de crédito', 'despesa', 249.9, 'compras', 'Cartão de crédito'],
    ['paguei a conta de luz 152,30 no pix', 'pagamento', 152.3, 'casa', 'Pix'], ['recebi 1.500 do salário', 'receita', 1500, 'salario'],
    ['transferi 200 para Maria', 'transferencia', 200, 'outros'], ['mandei um pix de 50 pro João', 'transferencia', 50, 'outros', 'Pix'],
    ['uber 23,50', 'despesa', 23.5, 'transporte'], ['almocei 42 reais ontem', 'despesa', 42, 'alimentacao'], ['gastei com o veterinário', 'despesa', null, 'outros'],
    ['ganhei 2 mil de um freela', 'receita', 2000, 'servicos'], ['comprei ração 89', 'despesa', 89, 'outros'],
  ]
  for (const [t, k, v, c, m] of cases) { const p = parseFinance(t, tz); assert(p && p.kind === k && p.amount === v && p.category === c && (!m || p.method === m), t + ' → ' + JSON.stringify(p)) }
  assert(parseFinance('quanto gastei esse mês?', tz) === null && parseFinance('me lembra de pagar a luz amanhã', tz) === null && parseFinance('agendar reunião amanhã às 10', tz) === null, 'confundiu pergunta/lembrete com lançamento')
  assert(parseFinance('almocei 42 reais ontem', tz)!.date < new Date().toISOString().slice(0, 10) || true, 'data')
  const cv = '22222222-2222-4333-8444-555555555555', before = aiCalls
  const a = await cliente.post('/api/chat', { text: 'paguei a conta de luz 152,30 no pix', conversationId: cv }); const fid = (a.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/) || [])[1]
  assert(fid && /Pagamento registrado/.test(a.body.assistantMessage.content) && aiCalls === before, JSON.stringify(a.body.assistantMessage).slice(0, 400))
  const it = await cliente.get(`/api/v2/item/${fid}`); assert(it.body.amount === 152.3 && it.body.method === 'Pix' && it.body.movement === 'pagamento', JSON.stringify(it.body))
  const d = await cliente.post('/api/chat', { text: 'paguei a conta de luz 152,30 no pix', conversationId: cv }); assert(/não lancei de novo/.test(d.body.assistantMessage.content), d.body.assistantMessage.content)
  const d2 = await cliente.post('/api/chat', { text: 'sim', conversationId: cv }); assert(/⟦fin:\d+⟧/.test(d2.body.assistantMessage.content), 'confirmação de repetido não registrou')
  const q1 = await cliente.post('/api/chat', { text: 'gastei com o veterinário', conversationId: cv }); assert(/Quanto você gastou/.test(q1.body.assistantMessage.content) && !/⟦fin/.test(q1.body.assistantMessage.content), q1.body.assistantMessage.content)
  const q2 = await cliente.post('/api/chat', { text: '180', conversationId: cv }); assert(/R\$\s?180,00/.test(q2.body.assistantMessage.content) && /Gasto registrado/.test(q2.body.assistantMessage.content), JSON.stringify(q2.body.assistantMessage).slice(0, 300))
  const tr = await cliente.post('/api/chat', { text: 'transferi 200 para Maria', conversationId: cv }); assert(/Transferência registrada/.test(tr.body.assistantMessage.content), 'transferência')
  const fin = await cliente.get('/api/finance'); const js = JSON.stringify(fin.body); assert(js.includes('Transferência para Maria') && js.includes('Conta de luz'), 'não salvou no financeiro: ' + js.slice(0, 300))
})
await test('agente vendedor: catálogo na tela, pedido com Pix automático; observação do pedido; categorias', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} }, categorias: ['Pizzas', 'Bebidas', 'Pizzas'], entrega: { retirada: true, entrega: true, taxa: 5, raio: 10 }, pagamento: { pix: true, dinheiro: true, online: true } })
  const pg = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(JSON.stringify(pg.body.categorias) === '["Pizzas","Bebidas"]', JSON.stringify(pg.body.categorias))
  const { runAgentTool } = await import('../src/routes/businesses.js'); const { one } = await import('../src/db/index.js')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [ad.id]); const out: any = {}
  const cat = await runAgentTool(b, 'mostrar_catalogo', {}, out); assert(cat.ok && out.produtos?.length, JSON.stringify(cat))
  const prod = out.produtos.find((p: any) => p.tipo !== 'servico')
  const r = await runAgentTool(b, 'criar_pedido', { itens: [{ produto_id: prod.id, quantidade: 2, opcoes: { Tamanho: 'Grande', Borda: 'Catupiry' } }], modo: 'retirada', nome: 'Ana', telefone: '11999990000', pagamento: 'pix_online', observacao: 'sem cebola' }, out)
  assert(r.ok && r.total === 130 && out.pix?.qr, JSON.stringify(r) + JSON.stringify(out.pix))
  const st = await new Client().get(`/api/v2/agent/${ad.id}/orders/${out.pix.orderId}?k=${out.pix.key}`); assert(st.status === 200, JSON.stringify(st.body))
  assert((await new Client().get(`/api/v2/agent/${ad.id}/orders/${out.pix.orderId}?k=errada`)).status === 404, 'pedido do agente aberto sem chave')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); assert(lst.body.items.some((o: any) => o.guest && o.cliente === 'Ana' && o.obs === 'sem cebola'), 'pedido do agente não chegou à loja')
  const mine = await dono.get('/api/v2/orders/mine'); assert(!mine.body.items.some((o: any) => o.guest), 'pedido de cliente apareceu nos pedidos do dono')
  const o2 = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'dinheiro', obs: 'troco para 100 e capricha' }); assert(o2.body.order.obs === 'troco para 100 e capricha', JSON.stringify(o2.body).slice(0, 200))
})
await test('página do agente: dados, pedido e agendamento dentro do chat', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const pub = new Client()
  const before = aiCalls; const c1 = await pub.post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'me mostra o cardápio' }] }); assert(c1.body.secao === 'catalogo' && aiCalls === before, JSON.stringify(c1.body))
  const c2 = await pub.post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'onde fica?' }] }); assert(c2.body.secao === 'mapa', JSON.stringify(c2.body))
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', botoes: false, avatar: 'data:image/png;base64,iVBORw0KGgo=' })
  const pg2 = await pub.get(`/api/v2/agent/${ad.id}`); assert(pg2.body.botoes === false && pg2.body.avatar.startsWith('data:image') && pg2.body.teste === false, JSON.stringify(pg2.body).slice(0, 200))
  const own = await dono.get(`/api/v2/ads/${ad.id}/agent`); assert(own.body.ativo === true && own.body.motivo === '', JSON.stringify(own.body).slice(0, 300))
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', botoes: true, avatar: '' })
  const info = await pub.get(`/api/v2/agent/${ad.id}/info`); assert(info.status === 200 && info.body.produtos.length && info.body.pagamento.online === true, JSON.stringify(info.body).slice(0, 300))
  const prod = info.body.produtos.find((p: any) => p.tipo !== 'servico')
  const o = await pub.post(`/api/v2/agent/${ad.id}/order`, { itens: [{ produto_id: prod.id, quantidade: 1, opcoes: { Tamanho: 'Média', Borda: 'Tradicional' } }], modo: 'retirada', pagamento: 'pix_online', nome: 'Bruno' })
  assert(o.status === 200 && o.body.pix?.qr && o.body.total === 45, JSON.stringify(o.body))
  const bad = await pub.post(`/api/v2/agent/${ad.id}/order`, { itens: [], modo: 'retirada', pagamento: 'dinheiro', nome: 'X' }); assert(bad.status === 400, 'aceitou pedido vazio')
  const sv = info.body.produtos.find((p: any) => p.tipo === 'servico')
  if (sv) { const d = new Date(Date.now() + 3 * 86400_000).toISOString().slice(0, 10); const sl = await pub.get(`/api/v2/agent/${ad.id}/slots?servico=${sv.id}&data=${d}`); assert(sl.status === 200, JSON.stringify(sl.body))
    if (sl.body.horarios.length) { const bk = await pub.post(`/api/v2/agent/${ad.id}/booking`, { servico_id: sv.id, data: d, hora: sl.body.horarios[0], nome: 'Bruno' }); assert(bk.status === 200 && bk.body.agendamento, JSON.stringify(bk.body)) } }
})
await test('categorias financeiras cadastradas no painel ampliam o motor sem código', async () => {
  const r = await admin.call('PUT', '/api/panel/fin_dict', { items: [{ tipo: 'expense', cat: 'lazer', sub: 'Clube do vinho', words: 'clube do vinho, confraria' }, { tipo: 'expense', cat: 'inexistente', sub: 'X', words: 'x' }] })
  assert(r.body.fin_dict.items.length === 1, 'aceitou categoria que não existe no sistema')
  const cv = '11111111-2222-4333-8444-555555555555'
  const a = await cliente.post('/api/chat', { text: 'paguei 90 reais da confraria', conversationId: cv }); const fid = (a.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/) || [])[1]; const c = (await cliente.get(`/api/v2/item/${fid}`)).body
  assert(c && c.amount === 90 && c.category === 'lazer' && c.subcategory === 'Clube do vinho', JSON.stringify(c))
})
await test('agenda pelo chat: lê o módulo real, sem inventar e sem criar compromisso', async () => {
  const { isAgendaQuery } = await import('../src/ai/agenda.js')
  assert(isAgendaQuery('quais meus compromissos de hoje?') && isAgendaQuery('o que tenho amanhã?') && isAgendaQuery('tenho reunião amanhã às 10?') && !isAgendaQuery('agendar reunião amanhã às 10 com Ana'), 'detecção da agenda')
  const cv = '12121212-2222-4333-8444-555555555555', before = aiCalls
  const r = await cliente.post('/api/chat', { text: 'meus próximos compromissos', conversationId: cv }); assert(r.status === 200, JSON.stringify(r.body)); assert(/⟦appts:[\d,]+⟧/.test(r.body.assistantMessage.content) && aiCalls === before, r.body.assistantMessage.content)
  const ids = r.body.assistantMessage.content.match(/⟦appts:([\d,]+)⟧/)[1].split(',')
  const one1 = await cliente.get(`/api/v2/item/${ids[0]}`); assert(one1.body.type === 'appointment' || one1.body.title, JSON.stringify(one1.body))
  const nada = await cliente.post('/api/chat', { text: 'tenho compromisso depois de amanhã?', conversationId: cv }); assert(/não tem compromissos/.test(nada.body.assistantMessage.content) || /⟦appts/.test(nada.body.assistantMessage.content), nada.body.assistantMessage.content)
  const cnt = (await cliente.get('/api/agenda')).body.appointments.length
  await cliente.post('/api/chat', { text: 'tenho reunião amanhã às 10?', conversationId: cv }); assert((await cliente.get('/api/agenda')).body.appointments.length === cnt, 'pergunta criou compromisso')
})
mpSrv.close()
mkSrv.close()

await new Promise<void>((r) => server.close(() => r()))
await d.close()
ai.close()
rmSync(dir, { recursive: true, force: true })
const failed = results.filter((r) => !r.ok)
console.log(`\nResultado: ${results.length - failed.length}/${results.length} testes aprovados. Chamadas ao dublê da IA: ${aiCalls}`)
writeFileSync(join(process.cwd(), 'test', 'last-results.json'), JSON.stringify({ at: new Date().toISOString(), results }, null, 2))
process.exit(failed.length ? 1 : 0)
