// Testes de integração ponta a ponta: sobem o servidor HTTP real, executam as migrações e
// exercitam a API com cookies, como o navegador faz. Por não haver PostgreSQL no ambiente de
// build, o banco aqui é o SQLite embutido do Node (adaptador de teste). A IA externa é
// substituída por um servidor local compatível com a API da OpenAI (dublê de teste), que
// devolve chamadas de ferramenta — o que valida o caminho real de gravação no banco.
import { createServer } from 'node:http'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { writeFileSync } from 'node:fs'

const results: { name: string; ok: boolean; detail?: string }[] = []
async function test(name: string, fn: () => Promise<void>) {
  try { await fn(); results.push({ name, ok: true }); console.log('  ✔', name) }
  catch (e: any) { results.push({ name, ok: false, detail: e?.message }); console.log('  ✘', name, '→', e?.message) }
}
function assert(c: unknown, msg: string): asserts c { if (!c) throw new Error(msg) }

// ---------- dublê da IA (API compatível com OpenAI) ----------
let aiCalls = 0
const ai = createServer(async (req, res) => {
  let body = ''
  for await (const c of req) body += c
  aiCalls++
  if (req.method === 'GET') { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ models: [{ name: 'qwen2.5:1.5b' }] })); return }
  const j = JSON.parse(body || '{}')
  const last = j.messages[j.messages.length - 1]
  const reply = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  if (req.headers.authorization !== 'Bearer test-key') { res.writeHead(401); return res.end('{}') }
  if (last.role === 'tool') return reply({ role: 'assistant', content: 'Pronto, registrei para você.' })
  const t = String(last.content).toLowerCase()
  const call = (name: string, args: object) => reply({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name, arguments: JSON.stringify(args) } }] })
  if (t.includes('gastei')) return call('register_transaction', { kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' })
  if (t.includes('tarefa')) return call('create_task', { title: 'Enviar orçamento', priority: 'high' })
  if (t.includes('lembre')) return call('save_memory', { content: 'Prefere respostas curtas', kind: 'preference' })
  if (t.includes('compromisso')) return call('create_appointment', { title: 'Dentista', date: '2099-01-10', time: '14:00', location: 'Centro' })
  if (t.includes('17 + 25')) return reply({ role: 'assistant', content: '42' })
  if (Array.isArray(j.tools) && j.tools.some((x: any) => x.function.name === 'registrar_codigo')) return call('registrar_codigo', { codigo: 'K7Q2' })
  if (t.includes('dobrar(n)')) return reply({ role: 'assistant', content: 'const dobrar = (n) => n * 2' })
  return reply({ role: 'assistant', content: 'Olá! Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
const aiPort = (ai.address() as any).port

const dir = mkdtempSync(join(tmpdir(), 'ma-test-'))
const dbFile = join(dir, 'test.db')
Object.assign(process.env, {
  NODE_ENV: 'test', PUBLIC_URL: 'http://localhost', AI_BASE_URL: `http://127.0.0.1:${aiPort}/v1`, AI_API_KEY: 'test-key',
  AI_MODEL: 'dublê', SCHEDULER_ENABLED: 'false', STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public'),
})

const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const { tick } = await import('../src/scheduler.js')
const { totp } = await import('../src/lib/security.js')

async function boot() {
  const d = await createSqlite(dbFile)
  setDb(d)
  const applied = await migrate(d, config.migrationsDir, () => {})
  const server = createApp()
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r))
  return { d, server, port: (server.address() as any).port, applied }
}
let { d, server, port, applied } = await boot()

class Client {
  jar = new Map<string, string>()
  async call(method: string, path: string, json?: unknown, headers: Record<string, string> = {}) {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { ...(json !== undefined ? { 'Content-Type': 'application/json' } : {}), Cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '), ...headers },
      body: json !== undefined ? JSON.stringify(json) : undefined,
    })
    for (const c of r.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) this.jar.set(k, v); else this.jar.delete(k) }
    const text = await r.text()
    let body: any = text
    try { body = JSON.parse(text) } catch {}
    return { status: r.status, body, headers: r.headers }
  }
  get = (p: string) => this.call('GET', p)
  post = (p: string, j: unknown = {}) => this.call('POST', p, j)
  auth = (action: string, extra: object = {}) => this.post('/api/auth', { action, ...extra })
}

const admin = new Client(), user = new Client(), anon = new Client()
const PW = 'Senha123forte'
const acct = (n: string) => ({ name: `${n} Silva`, whatsapp: '+55 11 98765-4321', email: `${n.toLowerCase()}@teste.com`, birthday: '1990-05-01', password: PW, passwordConfirm: PW })

console.log('\n== Infraestrutura')
await test('migrações aplicadas do zero (001_init.sql)', async () => { assert(applied.includes('001_init.sql'), 'migração não aplicada') })
await test('migrações são idempotentes (2ª execução não reaplica)', async () => { const again = await migrate(d, config.migrationsDir, () => {}); assert(again.length === 0, 'reaplicou') })
await test('GET /api/health responde com banco conectado', async () => { const r = await anon.get('/api/health'); assert(r.status === 200 && r.body.ok, JSON.stringify(r.body)) })
await test('frontend: / e rotas do app devolvem o index.html com o bootstrap', async () => {
  for (const p of ['/', '/entrar', '/agenda', '/convite/abc']) { const r = await anon.get(p); assert(r.status === 200 && String(r.body).includes('$_TSR'), `${p} → ${r.status}`) }
})
await test('frontend: assets com nome em maiúsculas/minúsculas corretos (index-MUcZwl3l.js)', async () => {
  const r = await anon.get('/assets/index-MUcZwl3l.js'); assert(r.status === 200, String(r.status))
  assert(String(r.headers.get('cache-control')).includes('no-cache'), 'arquivo principal corrigido deve ser revalidado')
})
await test('frontend: asset inexistente devolve 404 (não o index.html)', async () => { const r = await anon.get('/assets/nao-existe.js'); assert(r.status === 404, String(r.status)) })
await test('cabeçalhos de segurança presentes', async () => { const r = await anon.get('/api/health'); assert(r.headers.get('x-frame-options') === 'SAMEORIGIN' && r.headers.get('x-content-type-options') === 'nosniff', 'faltando') })
await test('rota inexistente → 404 JSON; módulo não reconstruído → 501 explícito', async () => {
  const a = await anon.get('/api/inexistente'); assert(a.status === 404 && a.body.code === 'not_found', JSON.stringify(a.body))
  const b = await anon.get('/api/market?history=1'); assert(b.status === 501 && b.body.code === 'not_reconstructed', JSON.stringify(b.body))
})
await test('proteção CSRF: POST de outra origem é recusado', async () => {
  const r = await anon.call('POST', '/api/auth', { action: 'login' }, { Origin: 'https://site-malicioso.com' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Autenticação')
await test('GET /api/auth sem contas → firstAccount=true', async () => { const r = await anon.get('/api/auth'); assert(r.body.firstAccount === true && r.body.setupNeeded === false, JSON.stringify(r.body)) })
await test('rotas protegidas sem sessão → 401 auth_required', async () => {
  for (const p of ['/api/me', '/api/agenda', '/api/finance', '/api/conversations', '/api/notifications']) { const r = await anon.get(p); assert(r.status === 401 && r.body.code === 'auth_required', p) }
})
await test('cadastro valida campos (nome, WhatsApp, senha) com "field"', async () => {
  let r = await anon.auth('signup', { ...acct('X'), name: 'Fulano' }); assert(r.status === 400 && r.body.field === 'name', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), whatsapp: '1234' }); assert(r.body.field === 'whatsapp', JSON.stringify(r.body))
  r = await anon.auth('signup', { ...acct('X'), password: 'abcdefgh', passwordConfirm: 'abcdefgh' }); assert(r.body.field === 'password', JSON.stringify(r.body))
})
await test('primeira conta vira Administrador Principal e redireciona para /admin', async () => {
  const r = await admin.auth('signup', acct('Ana')); assert(r.status === 200 && r.body.redirect === '/admin', JSON.stringify(r.body))
  const me = await admin.get('/api/me'); assert(me.body.profile.role === 'superadmin', me.body.profile?.role)
})
await test('cookie de sessão é HttpOnly + SameSite=Lax e o token não é gravado em texto puro', async () => {
  const r = await user.auth('signup', acct('Bruno'))
  const c = r.headers.getSetCookie()[0]; assert(/HttpOnly/.test(c) && /SameSite=Lax/.test(c), c)
  const tok = user.jar.get('ma_session')!
  const rows = await d.query('SELECT id FROM sessions WHERE id = $1', [tok]); assert(rows.length === 0, 'token em texto puro no banco')
})
await test('segunda conta é usuário comum', async () => { const me = await user.get('/api/me'); assert(me.body.profile.role === 'user', me.body.profile.role) })
await test('e-mail duplicado é recusado', async () => { const r = await anon.auth('signup', acct('Bruno')); assert(r.status === 409 && r.body.field === 'email', JSON.stringify(r.body)) })
await test('senha guardada com scrypt (sem texto puro)', async () => {
  const [row] = await d.query('SELECT password_hash FROM users WHERE email = $1', ['bruno@teste.com']); assert(row.password_hash.startsWith('scrypt$') && !row.password_hash.includes(PW), 'hash inválido')
})
await test('logout encerra a sessão no servidor', async () => {
  const c = new Client(); await c.auth('login', { email: 'bruno@teste.com', password: PW })
  assert((await c.get('/api/me')).status === 200, 'login falhou')
  await c.auth('logout'); const r = await c.get('/api/me'); assert(r.status === 401, String(r.status))
})
await test('login com senha errada → 401; correta → 200; action session ok', async () => {
  const c = new Client()
  let r = await c.auth('login', { email: 'bruno@teste.com', password: 'errada123' }); assert(r.status === 401, String(r.status))
  r = await c.auth('login', { email: 'BRUNO@teste.com', password: PW }); assert(r.status === 200 && r.body.redirect === '/', JSON.stringify(r.body))
  r = await c.auth('session'); assert(r.status === 200, String(r.status))
})
await test('limite de tentativas de login (429)', async () => {
  const c = new Client(); let last = 0
  for (let i = 0; i < 10; i++) last = (await c.auth('login', { email: 'alvo@teste.com', password: 'x1234567' })).status
  assert(last === 429, String(last))
})
await test('2FA: ativar com TOTP, login exige código, código de recuperação funciona uma vez', async () => {
  const b = await user.auth('mfa_begin', { password: PW }); assert(b.body.secret && b.body.uri.startsWith('otpauth://'), JSON.stringify(b.body))
  const en = await user.auth('mfa_enable', { code: totp(b.body.secret) }); assert(en.body.backupCodes?.length === 10, JSON.stringify(en.body))
  const st = await user.auth('security_status'); assert(st.body.mfa.enabled && st.body.mfa.backupCodesLeft === 10, JSON.stringify(st.body))
  const c = new Client()
  const l = await c.auth('login', { email: 'bruno@teste.com', password: PW }); assert(l.body.mfaRequired === true, JSON.stringify(l.body))
  assert((await c.get('/api/me')).status === 401, 'sessão pendente não pode acessar')
  const bad = await c.auth('mfa_login', { code: '000000' }); assert(bad.status === 400, String(bad.status))
  const ok = await c.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(ok.status === 200, JSON.stringify(ok.body))
  assert((await c.get('/api/me')).status === 200, 'não entrou')
  const c2 = new Client(); await c2.auth('login', { email: 'bruno@teste.com', password: PW })
  const reuse = await c2.auth('mfa_login', { code: en.body.backupCodes[0] }); assert(reuse.status === 400, 'código de recuperação reutilizado')
  const ok2 = await c2.auth('mfa_login', { code: totp(b.body.secret) }); assert(ok2.status === 200, 'TOTP recusado')
  const dis = await user.auth('mfa_disable', { password: PW, code: totp(b.body.secret) }); assert(dis.status === 200, JSON.stringify(dis.body))
})
await test('recuperar senha: token de uso único troca a senha e derruba sessões', async () => {
  const r = await anon.auth('recover', { email: 'bruno@teste.com' }); assert(r.status === 200 && r.body.message, JSON.stringify(r.body))
  // o link real vai por e-mail; no teste geramos um token conhecido direto no banco
  const { sha256 } = await import('../src/lib/security.js')
  const [u] = await d.query('SELECT id FROM users WHERE email = $1', ['bruno@teste.com'])
  await d.query('INSERT INTO password_resets (token_hash, user_id, expires_at, created_at) VALUES ($1,$2,$3,$4)', [sha256('tok-teste'), u.id, new Date(Date.now() + 3600e3).toISOString(), new Date().toISOString()])
  const c = new Client()
  const v = await c.auth('recovery', { token: 'tok-teste' }); assert(v.status === 200 && v.body.mfaRequired === false, JSON.stringify(v.body))
  assert((await c.get('/api/me')).status === 401, 'sessão de recuperação não deve acessar a API')
  const p = await c.auth('password', { password: 'NovaSenha456', passwordConfirm: 'NovaSenha456' }); assert(p.status === 200, JSON.stringify(p.body))
  assert((await user.get('/api/me')).status === 401, 'sessão antiga continuou ativa')
  const again = await new Client().auth('recovery', { token: 'tok-teste' }); assert(again.status === 400, 'token reutilizado')
  const l = await user.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'nova senha não funciona')
})
await test('alterar senha exige a senha atual', async () => {
  const r = await user.auth('password', { currentPassword: 'errada', password: 'Outra789x', passwordConfirm: 'Outra789x' }); assert(r.status === 400 && r.body.field === 'currentPassword', JSON.stringify(r.body))
})

console.log('\n== Perfil e configurações (/api/me)')
await test('PATCH /api/me salva perfil, configurações e ignora chaves desconhecidas', async () => {
  const r = await user.call('PATCH', '/api/me', { profile: { name: 'Bruno Souza' }, settings: { theme: 'light', timezone: 'America/Manaus', hack: 1 } })
  assert(r.body.profile.name === 'Bruno Souza' && r.body.settings.theme === 'light' && r.body.settings.timezone === 'America/Manaus' && !('hack' in r.body.settings), JSON.stringify(r.body.settings))
  await user.call('PATCH', '/api/me', { settings: { timezone: 'America/Sao_Paulo' } })
})
await test('plano expõe apenas recursos reconstruídos', async () => {
  const r = await user.get('/api/me'); assert(r.body.plan.features.includes('agenda') && !r.body.plan.features.includes('investments'), JSON.stringify(r.body.plan))
})

console.log('\n== Agenda, tarefas, lembretes, compras e notas (/api/items, /api/agenda)')
let taskId = 0, apptId = 0, remId = 0, shopId = 0, noteId = 0
await test('criar tarefa, compromisso, lembrete, compras e nota', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'task', data: { title: 'Comprar tinta' } }); taskId = r.body.item.id; assert(taskId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'Reunião', date: '2099-03-01', time: '10:30', location: 'Escritório', reminder_minutes: 15 } }); apptId = r.body.item.id; assert(apptId > 0, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Tomar água', date: '2099-03-01', time: '08:00', recurrence: 'daily' } }); remId = r.body.item.id; assert(r.body.item.remindAt === '2099-03-01T11:00:00.000Z', r.body.item.remindAt)
  r = await user.post('/api/items', { action: 'create', type: 'shopping', data: { items: [{ name: 'papel' }, { name: 'luvas' }] } }); shopId = r.body.items[0].id; assert(r.body.items.length === 2, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'note', data: { content: 'Senha do wi-fi do estúdio' } }); noteId = r.body.item.id; assert(noteId > 0, 'nota')
})
await test('validação: compromisso sem data é recusado (field=date)', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'X' } }); assert(r.status === 400 && r.body.field === 'date', JSON.stringify(r.body))
})
await test('GET /api/agenda devolve todos os grupos no formato do frontend', async () => {
  const r = await user.get('/api/agenda')
  for (const k of ['today', 'tz', 'tasks', 'appointments', 'reminders', 'shopping', 'notes', 'bills', 'sharedWithMe']) assert(k in r.body, `falta ${k}`)
  assert(r.body.tasks[0].title === 'Comprar tinta' && r.body.tasks[0].status === 'pending', 'tarefa')
  assert(r.body.shopping.some((s: any) => s.name === 'luvas' && s.listName === 'Compras' && s.done === false), 'compras')
})
await test('ações: concluir tarefa, marcar compra, fixar nota, adiar e concluir lembrete, alterar compromisso', async () => {
  await user.post('/api/items', { action: 'task_status', type: 'task', id: taskId, data: { status: 'done' } })
  await user.post('/api/items', { action: 'shopping_toggle', type: 'shopping', id: shopId })
  await user.post('/api/items', { action: 'note_pin', type: 'note', id: noteId })
  const sn = await user.post('/api/items', { action: 'reminder_snooze', type: 'reminder', id: remId, data: { minutes: 15 } }); assert(sn.body.item.snoozedUntil, 'snooze')
  const up = await user.post('/api/items', { action: 'appointment_update', type: 'appointment', id: apptId, data: { date: '2099-03-02', time: '11:00' } }); assert(up.body.item.date === '2099-03-02' && up.body.item.time === '11:00', JSON.stringify(up.body))
  const r = await user.get('/api/agenda')
  assert(r.body.tasks.find((t: any) => t.id === taskId).status === 'done', 'tarefa não concluída')
  assert(r.body.shopping.find((s: any) => s.id === shopId).done === true, 'compra não marcada')
  assert(r.body.notes.find((n: any) => n.id === noteId).pinned === true, 'nota não fixada')
})
await test('permissão: um usuário não altera nem vê registros de outro (404)', async () => {
  const r = await admin.post('/api/items', { action: 'delete', type: 'task', id: taskId }); assert(r.status === 404, String(r.status))
  const a = await admin.get('/api/agenda'); assert(!a.body.tasks.some((t: any) => t.id === taskId), 'vazamento entre contas')
})
await test('excluir registro', async () => {
  const r = await user.post('/api/items', { action: 'delete', type: 'note', id: noteId }); assert(r.status === 200, String(r.status))
  const a = await user.get('/api/agenda'); assert(!a.body.notes.some((n: any) => n.id === noteId), 'nota não excluída')
})

console.log('\n== Financeiro (/api/finance)')
let billId = 0
await test('lançar gasto e receita, cadastrar conta mensal', async () => {
  let r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: '45,90', description: 'Mercado', category: 'alimentacao' } }); assert(r.body.item.amount === 45.9, JSON.stringify(r.body))
  r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'income', amount: 1000, description: 'Serviço', category: 'servicos' } }); assert(r.body.item.kind === 'income', 'receita')
  const today = (await user.get('/api/agenda')).body.today
  r = await user.post('/api/items', { action: 'create', type: 'bill', data: { name: 'Luz', amount: 180, due_date: today, recurrence: 'monthly', category: 'casa' } }); billId = r.body.item.id; assert(billId > 0, JSON.stringify(r.body))
})
await test('valor inválido é recusado (field=amount)', async () => { const r = await user.post('/api/items', { action: 'create', type: 'expense', data: { kind: 'expense', amount: -3 } }); assert(r.body.field === 'amount', JSON.stringify(r.body)) })
await test('GET /api/finance calcula receitas, despesas, saldo, categorias e série', async () => {
  const r = await user.get('/api/finance')
  assert(r.body.income === 1000 && r.body.spent === 45.9, `${r.body.income}/${r.body.spent}`)
  assert(r.body.balance === Math.round((1000 - 45.9 - 180) * 100) / 100, String(r.body.balance))
  assert(r.body.byCategory[0].slug === 'alimentacao' && r.body.series.length === 6 && r.body.pendingBills.length === 1, JSON.stringify(r.body.byCategory))
})
await test('pagar conta mensal gera a próxima ocorrência; desfazer remove', async () => {
  const p = await user.post('/api/items', { action: 'pay_bill', type: 'bill', id: billId }); assert(p.body.item.status === 'paid', JSON.stringify(p.body))
  let [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill' AND status = 'pending'"); assert(Number(n.n) === 1, 'próxima conta não criada')
  await user.post('/api/items', { action: 'unpay_bill', type: 'bill', id: billId });
  [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'bill'"); assert(Number(n.n) === 1, 'próxima conta não removida')
})
await test('GET /api/day e /api/summary com dados reais', async () => {
  const today = (await user.get('/api/agenda')).body.today
  const r = await user.get(`/api/day?from=${today}&to=${today}`); assert(r.body.entries.some((e: any) => e.kind === 'bill'), JSON.stringify(r.body))
  const s = await user.get('/api/summary'); assert(s.body.summary.data.spent === 45.9 && s.body.summary.text.includes('45,90'), JSON.stringify(s.body))
})

console.log('\n== Chat com IA (/api/chat, /api/conversations, /api/memory)')
const conv = '11111111-2222-4333-8444-555555555555'
await test('mensagem simples cria conversa e grava as duas mensagens', async () => {
  const r = await user.post('/api/chat', { text: 'Oi, tudo bem?', conversationId: conv })
  assert(r.status === 200 && r.body.conversation.id === conv && r.body.userMessage.role === 'user' && r.body.assistantMessage.content.includes('Olá'), JSON.stringify(r.body))
})
await test('"gastei 35 no almoço" → grava gasto real e devolve cartão', async () => {
  const r = await user.post('/api/chat', { text: 'gastei 35 reais no almoço', conversationId: conv })
  assert(/⟦fin:\d+⟧/.test(r.body.assistantMessage.content) && /R\$\s?35,00/.test(r.body.assistantMessage.content), JSON.stringify(r.body.assistantMessage))
  const f = await user.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço' && e.amount === 35), 'gasto não gravado')
})
await test('compromisso e tarefa pelo chat ficam na agenda', async () => {
  await user.post('/api/chat', { text: 'marca compromisso no dentista', conversationId: conv })
  await user.post('/api/chat', { text: 'cria a tarefa enviar orçamento', conversationId: conv })
  const a = await user.get('/api/agenda')
  assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento' && t.priority === 'high'), 'tarefa')
  const day = await user.get('/api/day?from=2099-01-10&to=2099-01-10'); assert(day.body.entries.some((e: any) => e.title === 'Dentista'), 'compromisso')
})
await test('"lembre que..." salva memória visível no Perfil', async () => {
  await user.post('/api/chat', { text: 'lembre que prefiro respostas curtas', conversationId: conv })
  const m = await user.get('/api/memory'); assert(m.body.memories.some((x: any) => x.content === 'Prefere respostas curtas' && x.source === 'chat'), JSON.stringify(m.body))
})
await test('memória recusa senhas', async () => { const r = await user.post('/api/memory', { action: 'create', content: 'minha senha é 1234' }); assert(r.status === 400, String(r.status)) })
await test('histórico: GET /api/chat?c= devolve as mensagens; lista e busca de conversas', async () => {
  const r = await user.get(`/api/chat?c=${conv}`); assert(r.body.messages.length === 10, String(r.body.messages.length))
  const l = await user.get('/api/conversations'); assert(l.body.conversations[0].id === conv, 'lista')
  const s = await user.get('/api/conversations?q=dentista'); assert(s.body.conversations.length === 1, 'busca')
  const o = await admin.get(`/api/chat?c=${conv}`); assert(o.body.conversation === null, 'outra conta viu a conversa')
})
await test('editar e reenviar mensagem substitui a resposta anterior', async () => {
  const h = await user.get(`/api/chat?c=${conv}`)
  const first = h.body.messages.find((m: any) => m.role === 'user')
  const r = await user.post('/api/chat', { resendOf: first.id, conversationId: conv, text: 'Olá de novo' })
  assert(r.body.resent === true && r.body.superseded.length > 0 && r.body.userMessage.content === 'Olá de novo', JSON.stringify(r.body))
})
await test('renomear, fixar e excluir conversa', async () => {
  await user.call('PATCH', `/api/conversations/${conv}`, { title: 'Organização', pinned: true })
  let l = await user.get('/api/conversations'); assert(l.body.conversations[0].title === 'Organização' && l.body.conversations[0].pinned, 'renomear')
  const c2 = '99999999-2222-4333-8444-555555555555'
  await user.post('/api/chat', { text: 'oi', conversationId: c2 })
  await user.call('DELETE', `/api/conversations/${c2}`)
  l = await user.get('/api/conversations'); assert(!l.body.conversations.some((c: any) => c.id === c2), 'não excluiu')
})
await test('envio multipart sem anexo nem texto é recusado com mensagem clara', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: { Cookie: `ma_session=${user.jar.get('ma_session')}`, 'Content-Type': 'multipart/form-data; boundary=x' }, body: '--x--' })
  assert(r.status === 400, 'status ' + r.status)
})

console.log('\n== Sincronização offline (/api/sync)')
await test('fila offline: cria, conclui e é idempotente', async () => {
  const ops = [{ id: 'op-1', kind: 'create', type: 'task', data: { title: 'Feita offline' } }]
  const r = await user.post('/api/sync', { ops }); assert(r.body.results[0].status === 'done' && r.body.results[0].createdId > 0, JSON.stringify(r.body))
  const again = await user.post('/api/sync', { ops }); assert(again.body.results[0].createdId === r.body.results[0].createdId, 'duplicou')
  const done = await user.post('/api/sync', { ops: [{ id: 'op-2', kind: 'task_status', type: 'task', targetId: r.body.results[0].createdId, data: { status: 'done' } }] })
  assert(done.body.results[0].status === 'done', JSON.stringify(done.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'task' AND json_extract(data, '$.title') = 'Feita offline'"); assert(Number(n.n) === 1, 'duplicado')
})

console.log('\n== Notificações e agendador')
await test('lembrete vencido gera notificação; recorrente avança para o dia seguinte', async () => {
  const r = await user.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'Pagar boleto', date: '2020-01-01', time: '09:00', recurrence: 'daily' } })
  await tick(new Date())
  const n = await user.get('/api/notifications'); assert(n.body.items.some((i: any) => i.title === 'Pagar boleto') && n.body.unread >= 1, JSON.stringify(n.body))
  const [row] = await d.query('SELECT day FROM items WHERE id = $1', [r.body.item.id]); assert(row.day === '2020-01-02', row.day)
  await tick(new Date()); const n2 = await user.get('/api/notifications?count=1'); assert(typeof n2.body.unread === 'number', 'contagem')
})
await test('marcar todas como lidas', async () => { const r = await user.post('/api/notifications', { all: true }); assert(r.body.unread === 0, JSON.stringify(r.body)) })

console.log('\n== Administração')
await test('usuário comum não acessa o painel', async () => {
  const r = await user.get('/api/admin'); assert(r.body.access === 'none', JSON.stringify(r.body))
  const u = await user.get('/api/admin/users'); assert(u.status === 403, String(u.status))
})
await test('Administrador Principal lista, cria, edita e desativa usuários (com auditoria)', async () => {
  const a = await admin.get('/api/admin'); assert(a.body.access === 'admin' && a.body.me.permissions.includes('users.manage'), JSON.stringify(a.body))
  const l = await admin.get('/api/admin/users?q=bruno'); assert(l.body.users.length === 1, JSON.stringify(l.body))
  const c = await admin.post('/api/admin/users', { action: 'create', name: 'Carla Dias', whatsapp: '+55 21 99999-0000', email: 'carla@teste.com', birthday: '1985-02-02', password: 'Inicial123', role: 'admin', permissions: ['users.view'] })
  assert(c.body.user.role === 'admin' && c.body.user.permissions.join() === 'users.view', JSON.stringify(c.body))
  const bruno = l.body.users[0]
  const s = await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'disabled' }); assert(s.body.user.status === 'disabled', 'status')
  assert((await user.get('/api/me')).status === 401, 'conta desativada continuou com sessão')
  const blocked = await new Client().auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(blocked.status === 403 && blocked.body.code === 'account_disabled', JSON.stringify(blocked.body))
  await admin.post('/api/admin/users', { action: 'setStatus', id: bruno.id, status: 'active' })
  const au = await admin.get('/api/admin/audit'); assert(au.body.entries.some((e: any) => e.action === 'user.disable'), 'auditoria')
})
await test('admin com só "users.view" não pode criar usuários', async () => {
  const c = new Client(); await c.auth('login', { email: 'carla@teste.com', password: 'Inicial123' })
  const r = await c.post('/api/admin/users', { action: 'create', name: 'Teste Teste', whatsapp: '+5511988887777', email: 't@t.com', password: 'Abc12345' }); assert(r.status === 403, String(r.status))
})

console.log('\n== Persistência após reinicialização')
const persisted = new Client()
await test('dados continuam após reiniciar servidor e banco', async () => {
  await new Promise<void>((r) => server.close(() => r()))
  await d.close()
  ;({ d, server, port } = await boot())
  const c = persisted; const l = await c.auth('login', { email: 'bruno@teste.com', password: 'NovaSenha456' }); assert(l.status === 200, 'login após reinício')
  const a = await c.get('/api/agenda'); assert(a.body.tasks.some((t: any) => t.title === 'Enviar orçamento'), 'tarefa perdida')
  const f = await c.get('/api/finance'); assert(f.body.entries.some((e: any) => e.description === 'Almoço'), 'gasto perdido')
  const h = await c.get(`/api/chat?c=${conv}`); assert(h.body.messages.length > 0, 'conversa perdida')
})

console.log('\n== Exclusão de conta')
await test('excluir conta apaga dados (cascata) e encerra sessão', async () => {
  const c = persisted // já autenticado no teste anterior (evita o limite de tentativas de login)
  const r = await c.post('/api/auth', { action: 'delete_account', password: 'NovaSenha456', confirm: 'EXCLUIR', acknowledge: true }); assert(r.status === 200, JSON.stringify(r.body))
  const [n] = await d.query("SELECT COUNT(*) AS n FROM items i JOIN users u ON u.id = i.user_id WHERE u.email = 'bruno@teste.com'"); assert(Number(n.n) === 0, 'sobrou dado')
  const [m] = await d.query('SELECT COUNT(*) AS n FROM messages'); assert(Number(m.n) === 0, 'mensagens não apagadas')
  assert((await c.get('/api/me')).status === 401, 'sessão continuou')
})

console.log('\n== Painel (módulos, IAs, fontes de mercado, Mercado Pago, planos)')
const mkSrv = createServer((req, res) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ data: { price: 123.45 } })) })
await new Promise<void>((r) => mkSrv.listen(0, '127.0.0.1', r))
const mkPort = (mkSrv.address() as any).port
await test('painel exige administrador e não expõe chaves', async () => {
  const anon = new Client()
  assert((await anon.get('/api/panel')).status === 401, 'anônimo acessou')
  const g = await admin.get('/api/panel'); assert(g.status === 200 && g.body.canWrite === true, JSON.stringify(g.body).slice(0, 200))
  assert(g.body.ai_providers.some((p: any) => p.id === 'servidor') && g.body.ai_providers.every((p: any) => p.key === undefined), 'lista de IAs')
  const pub = await anon.get('/api/panel/public'); assert(pub.body.modules && pub.body.ad_plans.length === 4 && !JSON.stringify(pub.body).includes('tok'), 'público')
})
await test('módulos globais e planos são salvos e validados', async () => {
  const m = await admin.call('PUT', '/api/panel/modules', { mercado: false }); assert(m.body.modules.mercado === false && m.body.modules.fiscal === true, JSON.stringify(m.body.modules))
  const bad = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ nome: 'X', preco: -1, dias: 30, nivel: 1 }] }); assert(bad.status === 400, 'aceitou preço negativo')
  const ok = await admin.call('PUT', '/api/panel/ad_plans', { items: [{ id: 'n1', nome: 'Básico', preco: 19.9, dias: 15, nivel: 1 }, { id: 'n4', nome: 'Loja', preco: 99, dias: 30, nivel: 4 }] })
  assert(ok.body.ad_plans.length === 2 && ok.body.ad_plans[0].preco === 19.9, JSON.stringify(ok.body.ad_plans))
  const r = await admin.call('PUT', '/api/panel/search', { raio: 500 }); assert(r.status === 400, 'raio inválido aceito')
})
await test('Mercado Pago guarda o token cifrado e devolve só mascarado', async () => {
  const s = await admin.call('PUT', '/api/panel/mercadopago', { modo: 'teste', teste: { pub: 'TEST-abc123456789', tok: 'TEST-1234567890-segredo-muito-longo' } })
  assert(s.body.mercadopago.teste.tok.hasKey && s.body.mercadopago.teste.tok.keyMasked.includes('••'), JSON.stringify(s.body.mercadopago))
  const raw = await d.query("SELECT value FROM app_config WHERE key = 'mercadopago'")
  assert(!String(raw[0].value).includes('segredo-muito-longo'), 'token gravado sem cifra')
  const bad = await admin.call('PUT', '/api/panel/mercadopago', { teste: { tok: 'chave-errada-123456' } }); assert(bad.status === 400, 'token inválido aceito')
})
await test('IA com troca automática: chave recusada é pausada e a próxima responde', async () => {
  const items = [{ id: 'c-falha', nome: 'IA com chave errada', base_url: `http://127.0.0.1:${aiPort}/v1`, modelo: 'duble', key: 'chave-errada-xyz', texto: true, ativo: true }, { id: 'servidor', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/ai_providers', { items }); assert(s.status === 200 && s.body.ai_providers[0].hasKey, JSON.stringify(s.body).slice(0, 300))
  const c = await admin.post('/api/chat', { text: 'oi, tudo bem?', conversationId: '99999999-2222-4333-8444-555555555555' }); assert(c.status === 200, 'chat falhou: ' + JSON.stringify(c.body))
  const g = await admin.get('/api/panel'); assert(g.body.ai_runtime.paused['c-falha']?.expired === true, JSON.stringify(g.body.ai_runtime))
  const t = await admin.post('/api/panel/test', { kind: 'ai', id: 'c-falha' }); assert(t.body.ok === false && /recusada/.test(t.body.message), JSON.stringify(t.body))
  const t2 = await admin.post('/api/panel/test', { kind: 'ai', id: 'servidor' }); assert(t2.body.ok === true, JSON.stringify(t2.body))
})
await test('fonte de mercado personalizada: cadastro, teste e cotação', async () => {
  const g = await admin.get('/api/panel')
  const items = [...g.body.market_providers.map((p: any) => ({ id: p.id, ativo: false })), { id: 'c-minha', nome: 'Minha API', cat: 'cripto', url: `http://127.0.0.1:${mkPort}/q/{SIMBOLO}`, campo: 'data.price', ativo: true }]
  const s = await admin.call('PUT', '/api/panel/market_providers', { items }); assert(s.status === 200, JSON.stringify(s.body).slice(0, 300))
  const t = await admin.post('/api/panel/test', { kind: 'market', id: 'c-minha' }); assert(t.body.ok === true, JSON.stringify(t.body))
  const q = await admin.get('/api/v2/market/quote?s=btc'); assert(q.body.price === 123.45 && q.body.source === 'Minha API', JSON.stringify(q.body))
})
await admin.call('PUT', '/api/panel/modules', { mercado: true })
console.log('\n== Módulos reais: Mercado e Impostos/DAS')
await test('impostos: DAS calculado pelo salário mínimo, faturamento e guia paga', async () => {
  const f = await admin.get('/api/v2/fiscal'); assert(f.status === 200 && f.body.das.total === 82.05, JSON.stringify(f.body.das))
  const k = new Date().toISOString().slice(0, 7)
  const p = await admin.call('PUT', '/api/v2/fiscal', { atividade: 'servicos', receitas: { [k]: 1500 }, consent: true })
  assert(p.body.das.total === 86.05 && p.body.faturamento === 1500 && p.body.perfil.consent === true, JSON.stringify(p.body).slice(0, 300))
  const bad = await admin.call('PUT', '/api/v2/fiscal', { atividade: 'pirata' }); assert(bad.status === 400, 'atividade inválida aceita')
})
await test('chat responde DAS, cotação e receita com dados reais, sem chamar a IA', async () => {
  const before = aiCalls, cv = '77777777-2222-4333-8444-555555555555'
  const d = await admin.post('/api/chat', { text: 'quanto vou pagar de DAS?', conversationId: cv }); assert(/86,05/.test(d.body.assistantMessage.content), JSON.stringify(d.body).slice(0, 300))
  const c = await admin.post('/api/chat', { text: 'crypto btc', conversationId: cv }); assert(/123,45/.test(c.body.assistantMessage.content) && /⟦mkt:BTC⟧/.test(c.body.assistantMessage.content) && /Minha API/.test(c.body.assistantMessage.content), c.body.assistantMessage?.content)
  const r = await admin.post('/api/chat', { text: 'recebi 500 de um cliente', conversationId: cv }); assert(/2\.000,00/.test(r.body.assistantMessage.content), r.body.assistantMessage?.content)
  assert(aiCalls === before, 'a IA foi chamada sem necessidade')
  const g = await admin.post('/api/chat', { text: 'gastei 35 reais no almoço', conversationId: cv }); assert(/⟦fin:\d+⟧/.test(g.body.assistantMessage.content) && /Gasto registrado/.test(g.body.assistantMessage.content) && aiCalls === before, JSON.stringify(g.body.assistantMessage).slice(0, 300))
})
await test('alerta de preço: criado no chat e disparado pelo agendador com notificação', async () => {
  const cv = '66666666-2222-4333-8444-555555555555'
  const a = await admin.post('/api/chat', { text: 'me avise se o bitcoin chegar a R$ 100', conversationId: cv }); assert(/cair até/.test(a.body.assistantMessage.content), a.body.assistantMessage?.content)
  const l = await admin.get('/api/v2/market/alerts'); assert(l.body.alerts.length === 1 && !l.body.alerts[0].firedAt, JSON.stringify(l.body))
  await admin.post('/api/v2/market/alerts', { symbol: 'BTC', cond: 'acima', value: 100 })
  const { checkModules } = await import('../src/modules-scheduler.js'); await checkModules(new Date(Date.now() + 10 * 60_000))
  const l2 = await admin.get('/api/v2/market/alerts'); assert(l2.body.alerts.find((x: any) => x.cond === 'acima').firedAt, 'alerta não disparou')
  const n = await admin.get('/api/notifications'); assert(JSON.stringify(n.body).includes('BTC subiu até'), JSON.stringify(n.body).slice(0, 300))
})
await test('módulo desligado no painel bloqueia a API', async () => {
  await admin.call('PUT', '/api/panel/modules', { fiscal: false })
  const f = await admin.get('/api/v2/fiscal'); assert(f.status === 403 && f.body.code === 'module_disabled', JSON.stringify(f.body))
  await admin.call('PUT', '/api/panel/modules', { fiscal: true })
})
console.log('\n== Anúncios: proposta, aprovação e Pix (Mercado Pago simulado)')
let mpBody: any = null
const mpSrv = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  res.writeHead(200, { 'Content-Type': 'application/json' })
  if (req.url === '/users/me') return res.end(JSON.stringify({ id: 123, nickname: 'LOJATESTE' }))
  if (req.method === 'POST') { mpBody = JSON.parse(body); return res.end(JSON.stringify({ id: 999, status: 'pending', point_of_interaction: { transaction_data: { qr_code: '00020101PIXTESTE', qr_code_base64: 'iVBORw0KGgo=' } } })) }
  res.end(JSON.stringify({ id: 999, status: 'approved', external_reference: mpBody?.external_reference }))
})
await new Promise<void>((r) => mpSrv.listen(0, '127.0.0.1', r))
process.env.MP_API_BASE = `http://127.0.0.1:${(mpSrv.address() as any).port}`
const dono = new Client()
await test('usuário cria anúncio com plano e fica aguardando pagamento', async () => {
  const s = await dono.auth('signup', { name: 'Dona Pizzaria', whatsapp: '+55 11 97777-6666', email: 'dona@pizza.com', birthday: '1988-03-03', password: 'Pizza@12345', passwordConfirm: 'Pizza@12345' })
  assert(s.status === 200, JSON.stringify(s.body))
  const p = await dono.get('/api/v2/ads/plans'); assert(p.body.plans.length >= 1, 'planos')
  const bad = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'X' }); assert(bad.status === 400, 'aceitou proposta incompleta')
  const c = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'Pizzaria Forno', categoria: 'Pizzaria', titulo: 'Pizza no forno a lenha', texto: 'Entrega rápida', zap: '5511977776666', lat: -23.55, lng: -46.63, raio: 5 })
  assert(c.status === 200 && c.body.items[0].status === 'pagamento' && c.body.items[0].plan.nivel === 4, JSON.stringify(c.body).slice(0, 300))
})
await test('dono paga por Pix; webhook envia para aprovação; admin aprova e entra no ar', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const pay = await dono.post(`/api/v2/ads/${ad.id}/pay`, {}); assert(pay.body.payment?.qr === '00020101PIXTESTE' && mpBody.transaction_amount > 0 && mpBody.payment_method_id === 'pix', JSON.stringify(pay.body))
  const w = await new Client().post(`/api/mercadopago/webhook?type=payment&data.id=999`, {}); assert(w.status === 200, JSON.stringify(w.body))
  const m1 = await dono.get('/api/v2/ads/mine'); assert(m1.body.items[0].status === 'analise', 'deveria ir para aprovação: ' + m1.body.items[0].status)
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('Enviamos seu anúncio para aprovação'), 'dono não foi avisado do pagamento')
  const na = await admin.get('/api/notifications'); assert(JSON.stringify(na.body).includes('Novo anúncio pago para aprovar'), 'admin não foi avisado')
  assert((await dono.get('/api/v2/admin/ads')).status === 403, 'usuário comum acessou admin de anúncios')
  const sem = await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'reject' }); assert(sem.status === 400, 'recusa sem motivo aceita')
  const a = await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'approve' }); assert(a.body.items.find((x: any) => x.id === ad.id).status === 'ativo', 'aprovação não pôs no ar')
  const m = await dono.get('/api/v2/ads/mine'); assert(m.body.items[0].status === 'ativo' && m.body.items[0].expiresAt, JSON.stringify(m.body.items[0]).slice(0, 300))
  const nn = await dono.get('/api/notifications'); assert(JSON.stringify(nn.body).includes('aprovado e está no ar'), 'dono não foi avisado da aprovação')
})
await test('administrador cria anúncio já publicado, sem aprovação nem pagamento', async () => {
  const c = await admin.post('/api/v2/ads', { planId: 'n1', empresa: 'Anúncio da Casa', categoria: 'Serviços', titulo: 'Conheça o Meu Assistente', texto: 'Teste' })
  assert(c.body.items[0].status === 'ativo' && c.body.items[0].expiresAt, JSON.stringify(c.body.items[0]).slice(0, 200))
})
console.log('\n== Empresas, loja e pedidos')
const cliente = new Client()
await test('busca por ramo pede localização e depois mostra a empresa no raio', async () => {
  await cliente.auth('signup', { name: 'Cliente Teste', whatsapp: '+55 11 96666-5555', email: 'cli@teste.com', birthday: '1991-04-04', password: 'Cliente@123', passwordConfirm: 'Cliente@123' })
  const cv = '55555555-2222-4333-8444-555555555555'
  const a = await cliente.post('/api/chat', { text: 'pizzarias', conversationId: cv }); assert(/⟦loc:/.test(a.body.assistantMessage.content), a.body.assistantMessage?.content)
  const s0 = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s0.body.needLocation === true, 'deveria pedir localização')
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632 })
  const s1 = await cliente.get('/api/v2/businesses/search?q=pizzarias'); assert(s1.body.items.length === 1 && s1.body.items[0].temLoja && s1.body.items[0].distancia < 1, JSON.stringify(s1.body))
  const b = await cliente.post('/api/chat', { text: 'pizzaria perto de mim', conversationId: cv }); const ids = (b.body.assistantMessage.content.match(/⟦emp:([\d,]+)⟧/) || [])[1]; assert(ids, b.body.assistantMessage?.content)
  const cards = await cliente.get('/api/v2/businesses/cards?ids=' + ids); assert(cards.body.items[0].empresa === 'Pizzaria Forno' && cards.body.items[0].temLoja, JSON.stringify(cards.body))
  await cliente.call('PUT', '/api/v2/me/location', { lat: -22.9, lng: -43.17 })
  const s2 = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s2.body.items.length === 0, 'mostrou empresa fora do raio')
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632 })
})
await test('dono cadastra produto com variação; cliente pede; preço calculado no servidor; dono aceita', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const semFoto = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Margherita', preco: 45 }); assert(semFoto.status === 400, 'aceitou produto sem foto')
  const foto = 'data:image/jpeg;base64,' + 'A'.repeat(100)
  const p = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Margherita', preco: 45, categoria: 'Pizzas', fotos: [foto], variacoes: [{ nome: 'Tamanho', opcoes: [{ nome: 'Média', preco: 45 }, { nome: 'Grande', preco: 56 }] }, { nome: 'Borda', opcoes: [{ nome: 'Tradicional', preco: 0 }, { nome: 'Catupiry', preco: 9 }] }] })
  assert(p.body.items.length === 1, JSON.stringify(p.body).slice(0, 200))
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { entrega: { retirada: true, entrega: true, taxa: 6, raio: 5, minimo: 20 }, pagamento: { pix: true, dinheiro: true } })
  const page = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(page.body.loja && page.body.produtos.length === 1 && page.body.entrega.taxa === 6, JSON.stringify(page.body).slice(0, 300))
  const pid = page.body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 2, escolhas: { Tamanho: 1, Borda: 1 }, obs: 'sem cebola' }], modo: 'entrega', endereco: 'Rua A, 10', pagamento: 'pix' })
  assert(o.body.order.total === 136 && o.body.order.status === 'novo', JSON.stringify(o.body)) // (56+9)*2 + 6
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('Novo pedido'), 'dono não foi avisado')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); const oid = lst.body.items[0].id
  const bad = await dono.post(`/api/v2/ads/${ad.id}/orders/${oid}`, { status: 'concluido' }); assert(bad.status === 400, 'pulou etapas')
  const ok = await dono.post(`/api/v2/ads/${ad.id}/orders/${oid}`, { status: 'aceito' }); assert(ok.body.items[0].status === 'aceito', 'não aceitou')
  const nc = await cliente.get('/api/notifications'); assert(JSON.stringify(nc.body).includes('foi aceito'), 'cliente não foi avisado')
  const mine = await cliente.get('/api/v2/orders/mine'); assert(mine.body.items[0].status === 'aceito', 'meus pedidos')
})
await test('loja com Mercado Pago próprio: pedido com Pix automático e confirmação pelo webhook', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  const bad = await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'qualquer' }); assert(bad.status === 400, 'aceitou token inválido')
  const ok = await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'TEST-998877665544-loja' }); assert(ok.body.mpLoja && ok.body.mpMasked.includes('••'), JSON.stringify(ok.body))
  const t = await dono.post(`/api/v2/ads/${ad.id}/mp`, { action: 'test' }); assert(t.body.ok, JSON.stringify(t.body))
  const mine = await dono.get('/api/v2/ads/mine'); assert(!JSON.stringify(mine.body).includes('998877'), 'token da loja vazou')
  const page = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(page.body.pagamento.online === true, 'pagamento online não ficou disponível')
  const pid = page.body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'online' })
  assert(o.body.order.payment?.qr === '00020101PIXTESTE' && !o.body.order.pago, JSON.stringify(o.body).slice(0, 300))
  await new Client().post(`/api/mercadopago/webhook?store=${ad.id}&type=payment&data.id=999`, {})
  const mineO = await cliente.get('/api/v2/orders/mine'); assert(mineO.body.items[0].pago === true, 'pedido não foi marcado como pago')
  const nd = await dono.get('/api/notifications'); assert(JSON.stringify(nd.body).includes('PAGO'), 'loja não foi avisada do pagamento')
})
await test('loja fecha pelo botão manual e bloqueia pedidos; voz natural responde sem erro', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items[0]
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'fechado', dias: {} } })
  const c = await cliente.get(`/api/v2/businesses/cards?ids=${ad.id}`); assert(c.body.items[0].aberto === false, 'deveria estar fechada')
  const pid = (await cliente.get(`/api/v2/businesses/${ad.id}`)).body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'dinheiro' }); assert(o.status === 400 && o.body.code === 'closed', JSON.stringify(o.body))
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
  const t = await cliente.get('/api/tts'); assert(t.status === 200 && typeof t.body.available === 'boolean', 'tts deveria responder')
})
await test('preferência de notificação desligada é respeitada', async () => {
  await cliente.call('PATCH', '/api/me', { settings: { notifyMarket: false } })
  await cliente.post('/api/v2/market/alerts', { symbol: 'BTC', cond: 'acima', value: 1 })
  const { checkModules } = await import('../src/modules-scheduler.js'); await checkModules(new Date(Date.now() + 30 * 60_000))
  const n = await cliente.get('/api/notifications'); assert(!JSON.stringify(n.body).includes('BTC subiu'), 'notificou mesmo desligado')
})
await test('painel: testar Mercado Pago, botões rápidos e raio do usuário', async () => {
  const t = await admin.post('/api/panel/test', { kind: 'mp', modo: 'teste' }); assert(t.body.ok && /LOJATESTE/.test(t.body.message), JSON.stringify(t.body))
  const q = await admin.call('PUT', '/api/panel/quick_buttons', { enabled: true, custom: true, items: ['Resumo do meu mês', '', 'Como está o bitcoin?'] })
  assert(q.body.quick_buttons.items.length === 2 && q.body.quick_buttons.custom, JSON.stringify(q.body.quick_buttons))
  const pub = await new Client().get('/api/panel/public'); assert(pub.body.quick_buttons.items[0] === 'Resumo do meu mês', 'botões não públicos')
  await cliente.call('PUT', '/api/v2/me/location', { raio: 1 })
  const s = await cliente.get('/api/v2/businesses/search?q=pizzaria'); assert(s.body.location.raio === 1 && s.body.items.length === 1, JSON.stringify(s.body).slice(0, 200))
  const pg = await new Client().get('/api/v2/businesses/' + s.body.items[0].id); assert(pg.status === 200 && pg.body.loja, 'página da loja deveria abrir sem login')
  await admin.call('PUT', '/api/panel/modules', { voz: false })
  const me = await cliente.get('/api/me'); assert(!JSON.stringify(me.body.plan.features).includes('voice_mode'), 'voz continuou ativa')
  await admin.call('PUT', '/api/panel/modules', { voz: true })
})
await test('Biblioteca de Sobrevivência: materiais iniciais, download em partes conferido e cadastro pelo admin', async () => {
  const { seedKb } = await import('../src/routes/kb.js'); await seedKb()
  const l = await cliente.get('/api/kb-offline'); assert(l.body.docs.length >= 6 && l.body.docs.every((d: any) => d.digest && d.parts >= 1), JSON.stringify(l.body).slice(0, 200))
  const d0 = l.body.docs[0]; let all: any[] = []
  for (let m = 0; m < d0.parts; m++) all = all.concat((await cliente.get(`/api/kb-offline?id=${d0.id}&v=${d0.version}&part=${m}`)).body.chunks)
  const { createHash } = await import('node:crypto')
  const dg = createHash('sha256').update([...all].sort((a, b) => a.p - b.p).map((a) => `${a.p}\u001f${a.s}\u001f${a.e}\u001f${a.r ?? ''}\u001f${a.c}`).join('\u001e')).digest('hex')
  assert(all.length === d0.chunks && dg === d0.digest, 'conteúdo baixado não confere com o digest')
  assert((await cliente.get('/api/v2/admin/kb')).status === 403, 'usuário comum acessou o cadastro')
  const c = await admin.post('/api/v2/admin/kb', { title: 'Abrigo no frio', keywords: 'frio, abrigo', content: '# Proteja-se\nUse várias camadas de roupa.' })
  assert(c.body.items.some((x: any) => x.title === 'Abrigo no frio' && x.chunks === 1), JSON.stringify(c.body).slice(0, 200))
  const l2 = await cliente.get('/api/kb-offline'); assert(l2.body.docs.some((x: any) => x.title === 'Abrigo no frio'), 'novo material não apareceu')
})
await test('planos de uso: limite diário grátis, assinatura por Pix libera o plano; anúncio aparece no chat', async () => {
  const cfg = (await admin.get('/api/panel')).body.usage_plans
  await admin.call('PUT', '/api/panel/usage_plans', { ...cfg, ativo: true, free: { nome: 'Grátis', limites: { ...cfg.free.limites, chat: 1, appointment: 1 } } })
  const u0 = await cliente.get('/api/v2/usage'); assert(u0.body.ativo && u0.body.plano.id === 'free', JSON.stringify(u0.body).slice(0, 200))
  const cv = '44444444-2222-4333-8444-555555555555'
  await cliente.post('/api/chat', { text: 'oi', conversationId: cv })
  const l = await cliente.post('/api/chat', { text: 'oi de novo', conversationId: cv }); assert(/limite/.test(l.body.assistantMessage.content) && /⟦btn:\/x\/planos/.test(l.body.assistantMessage.content), l.body.assistantMessage?.content)
  const a1 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'A', date: '2026-12-01', time: '10:00' } }); assert(a1.status === 200, JSON.stringify(a1.body))
  const a2 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'B', date: '2026-12-02', time: '10:00' } }); assert(a2.status === 429 && a2.body.code === 'limit_reached', JSON.stringify(a2.body))
  const sp = await cliente.post('/api/v2/subscription', { planId: 'p2' }); assert(sp.body.payment?.qr, JSON.stringify(sp.body))
  await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const u1 = await cliente.get('/api/v2/usage'); assert(u1.body.plano.id === 'p2' && u1.body.plano.expiresAt, JSON.stringify(u1.body.plano))
  const a3 = await cliente.post('/api/items', { action: 'create', type: 'appointment', data: { title: 'C', date: '2026-12-03', time: '10:00' } }); assert(a3.status === 200, 'plano não liberou')
  await admin.call('PUT', '/api/panel/usage_plans', { ...cfg, ativo: false })
  await admin.call('PUT', '/api/panel/ad_frequency', { ativo: true, cada: 1, intervaloMin: 0 })
  const ad = await cliente.post('/api/chat', { text: 'bom dia', conversationId: cv }); assert(/⟦ad:\d+⟧/.test(ad.body.assistantMessage.content), ad.body.assistantMessage?.content)
  await admin.call('PUT', '/api/panel/ad_frequency', { ativo: false, cada: 6, intervaloMin: 30 })
})
await test('motor configurável, entrega por km, renovação de anúncio e agente de atendimento', async () => {
  const e = await admin.call('PUT', '/api/panel/engine', { naturalidade: 90, personalidade: 'divertido', criatividade: 80, contexto: 100, autonomia: 60, precisao: 90 }); assert(e.body.engine.personalidade === 'divertido', JSON.stringify(e.body.engine))
  const { engineCfg } = await import('../src/ai/provider.js'); const ec = await engineCfg(); assert(ec.temperature > 0.7 && ec.historico === 40, JSON.stringify(ec))
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { entrega: { retirada: true, entrega: true, raio: 10, modoTaxa: 'km', kmGratis: 0.1, taxaExcedente: 3, taxaKm: 2 } })
  await cliente.call('PUT', '/api/v2/me/location', { lat: -23.552, lng: -46.632, raio: 10 })
  const pid = (await cliente.get(`/api/v2/businesses/${ad.id}`)).body.produtos[0].id
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'entrega', endereco: 'Rua B, 20', pagamento: 'dinheiro' })
  assert(o.body.order.taxa > 3 && o.body.order.taxa < 4, 'taxa por km errada: ' + JSON.stringify(o.body).slice(0, 200))
  // renovar: encerra e sobe de novo
  await admin.post(`/api/v2/admin/ads/${ad.id}`, { action: 'end' })
  const r1 = await dono.post(`/api/v2/ads/${ad.id}/renew`, { planId: 'n4' }); assert(r1.body.items.find((x: any) => x.id === ad.id).status === 'pagamento', 'renovação não foi para pagamento')
  const keep = r1.body.items.find((x: any) => x.id === ad.id); assert(keep.empresa === 'Pizzaria Forno' && keep.entrega?.modoTaxa === 'km', 'dados não foram mantidos')
  await dono.post(`/api/v2/ads/${ad.id}/pay`, {}); await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const r2 = await dono.get('/api/v2/ads/mine'); assert(r2.body.items.find((x: any) => x.id === ad.id).status === 'ativo', 'renovação paga deveria voltar ao ar')
  // agente
  await admin.call('PUT', '/api/panel/modules', { agente: true })
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', saudacao: 'Oi! Sou a Lia.', instrucoes: 'Ofereça a pizza do dia.' })
  const off = await new Client().get(`/api/v2/agent/${ad.id}`); assert(off.status === 404 && off.body.info?.empresa === 'Pizzaria Forno', 'agente sem pagamento deveria mostrar página amigável')
  const teste = await dono.get(`/api/v2/agent/${ad.id}`); assert(teste.status === 200 && teste.body.teste === true, 'dono deveria poder testar')
  const ap = await dono.post(`/api/v2/ads/${ad.id}/agent/pay`, {}); assert((ap.body.payment?.qr || ap.body.ativo) && mpBody.date_of_expiration?.endsWith('-03:00'), JSON.stringify(ap.body)) // o simulador aprova na hora
  await new Client().post('/api/mercadopago/webhook?type=payment&data.id=999', {})
  const ad2 = await dono.post('/api/v2/ads', { planId: 'n1', empresa: 'Outra', categoria: 'Teste', titulo: 'T' }); const id2 = ad2.body.items.find((x: any) => x.empresa === 'Outra').id
  const ag2 = await dono.call('PUT', `/api/v2/ads/${id2}/agent`, { nome: 'Bia' }); assert(ag2.status === 409 && ag2.body.code === 'agent_exists', 'permitiu segundo agente')
  const again = await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', saudacao: 'Oi! Sou a Lia.', instrucoes: 'Ofereça a pizza do dia.' }); assert(again.status === 200, 'não salvou o agente existente: ' + JSON.stringify(again.body))
  const dupl = await dono.post('/api/v2/ads', { planId: 'n4', empresa: 'Outra loja', categoria: 'Teste', titulo: 'T', zap: '5511999990000' }); assert(dupl.status === 409 && dupl.body.code === 'plan_taken', 'permitiu dois anúncios no mesmo plano')
  const info = await dono.get(`/api/v2/ads/${ad.id}/agent`); assert(info.body.ativo && /^https:\/\/meuassistente\.chat\/g-pizzaria-forno$/.test(info.body.link), JSON.stringify(info.body))
  const pub = await new Client().get(`/api/v2/agent/${ad.id}`); assert(pub.body.nome === 'Lia' && pub.body.saudacao === 'Oi! Sou a Lia.', JSON.stringify(pub.body))
  const before = aiCalls; const c = await new Client().post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'quanto custa a margherita?' }] })
  assert(c.status === 200 && c.body.reply && aiCalls > before, JSON.stringify(c.body))
  const old = await fetch(`http://127.0.0.1:${port}/a/${ad.id}`, { redirect: 'manual' }); assert(old.status === 301 && old.headers.get('location') === '/g-pizzaria-forno', 'link antigo não redirecionou: ' + old.status + ' ' + old.headers.get('location'))
  const page = await fetch(`http://127.0.0.1:${port}/g-pizzaria-forno`); const ph = await page.text(); assert(page.status === 200 && ph.includes('Atendimento automático') && ph.includes(`window.__MA_AGENT=${ad.id}`), 'página pública do agente pelo novo endereço')
  assert((await fetch(`http://127.0.0.1:${port}/g-nao-existe`)).status === 404, 'endereço inexistente deveria dar 404')
})
await test('acessos, relatórios (com IA e MEI) e avisos de vencimento', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await cliente.get(`/api/v2/businesses/${ad.id}`); await cliente.get(`/api/v2/businesses/${ad.id}`); await dono.get(`/api/v2/businesses/${ad.id}`)
  await cliente.post(`/api/v2/businesses/${ad.id}/hit`, { kind: 'whatsapp' })
  const r = await dono.get(`/api/v2/ads/${ad.id}/report?dias=30`)
  assert(r.body.acessos.visitas >= 1 && r.body.acessos.contatos === 1 && r.body.acessos.pedidos >= 1 && r.body.serie.length === 30, JSON.stringify(r.body.acessos))
  assert((await cliente.get(`/api/v2/ads/${ad.id}/report`)).status === 404, 'outro usuário viu o relatório')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); const oc = lst.body.items.find((o: any) => o.status === 'aceito')
  if (oc) { await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'preparo' }); await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'pronto' }); await dono.post(`/api/v2/ads/${ad.id}/orders/${oc.id}`, { status: 'concluido' }) }
  const r2 = await dono.get(`/api/v2/ads/${ad.id}/report?dias=30`); assert(r2.body.vendas.faturamento > 0 && r2.body.vendas.topProdutos.length, JSON.stringify(r2.body.vendas))
  const ai = await dono.post(`/api/v2/ads/${ad.id}/report/ai`, { dias: 30 }); assert(ai.status === 200 && ai.body.texto, JSON.stringify(ai.body))
  const m1 = await dono.post(`/api/v2/ads/${ad.id}/report/mei`, {}); assert(m1.body.adicionado > 0, JSON.stringify(m1.body))
  const m2 = await dono.post(`/api/v2/ads/${ad.id}/report/mei`, {}); assert(m2.body.adicionado === 0, 'lançou em dobro')
  const { q } = await import('../src/db/index.js')
  await q('UPDATE businesses SET expires_at = $1 WHERE id = $2', [new Date(Date.now() + 2.5 * 86400_000).toISOString(), ad.id])
  const { expiryAlerts } = await import('../src/modules-scheduler.js'); await expiryAlerts(new Date())
  const n = await dono.get('/api/notifications'); assert(JSON.stringify(n.body).includes('Faltam 3 dias'), 'aviso de vencimento não chegou')
})
await test('serviços com agendamento, etiquetas e tema do catálogo', async () => {
  const sv = await admin.post('/api/v2/ads', { planId: 'n1', empresa: 'Barbearia Navalha', categoria: 'Barbearia', titulo: 'Corte e barba' })
  const bar = sv.body.items.find((x: any) => x.empresa === 'Barbearia Navalha'); assert(bar.tipo === 'servicos', 'nicho não reconhecido: ' + bar.tipo)
  // plano 3 não tem produtos: usa o plano 4 da pizzaria para serviço? cria serviço na barbearia exige plano 4
  const ad4 = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const upd = (await dono.call('PUT', `/api/v2/ads/${ad4.id}`, { etiquetas: [{ nome: 'Black Friday', cor: '#111111' }], tema: { preset: 'elegante', cor: '#c9a227', fundo: 'escuro', layout: 'grade' } })).body.items.find((x: any) => x.id === ad4.id); const tag = upd.etiquetas[0]; assert(upd.tema.layout === 'grade', 'tema não salvo')
  const s1 = await dono.post(`/api/v2/ads/${ad4.id}/products`, { tipo: 'servico', nome: 'Festa com pizzaiolo', preco: 100, modoPreco: 'hora', duracao: 120, tags: [tag.id] }); assert(s1.status === 200, JSON.stringify(s1.body))
  const page = await cliente.get(`/api/v2/businesses/${ad4.id}`); const svc = page.body.produtos.find((p: any) => p.tipo === 'servico'); assert(svc && svc.tags[0] === tag.id && page.body.etiquetas[0].nome === 'Black Friday', 'serviço/etiqueta não aparecem')
  const d = new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10)
  await dono.call('PUT', `/api/v2/ads/${ad4.id}`, { horarioCfg: { modo: 'aberto', dias: Object.fromEntries(['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'].map((k) => [k, { ativo: true, abre: '10:00', fecha: '16:00' }])) } })
  const sl = await cliente.get(`/api/v2/businesses/${ad4.id}/slots?servico=${svc.id}&data=${d}`); assert(sl.body.horarios[0] === '10:00', JSON.stringify(sl.body))
  const bk = await cliente.post(`/api/v2/businesses/${ad4.id}/bookings`, { servico: svc.id, data: d, hora: '10:00' }); assert(bk.body.order.total === 200, JSON.stringify(bk.body))
  const again = await cliente.post(`/api/v2/businesses/${ad4.id}/bookings`, { servico: svc.id, data: d, hora: '11:00' }); assert(again.status === 409, 'permitiu horário sobreposto')
  const sl2 = await cliente.get(`/api/v2/businesses/${ad4.id}/slots?servico=${svc.id}&data=${d}`); assert(!sl2.body.horarios.includes('10:00') && sl2.body.horarios.includes('12:00'), JSON.stringify(sl2.body))
  const lst = await dono.get(`/api/v2/ads/${ad4.id}/orders`); const bo = lst.body.items.find((o: any) => o.tipo === 'agendamento')
  const ok = await dono.post(`/api/v2/ads/${ad4.id}/orders/${bo.id}`, { status: 'aceito' }); assert(ok.status === 200, JSON.stringify(ok.body))
  const nc = await cliente.get('/api/notifications'); assert(JSON.stringify(nc.body).includes('foi confirmado'), 'cliente não soube da confirmação')
  const t = (await cliente.get(`/api/v2/businesses/${ad4.id}`)); assert(t.body.tipo, 'tipo ausente')
})
await test('compromisso pelo chat sem inventar local, com aviso e convite compartilhável', async () => {
  const { parseAppointment } = await import('../src/ai/appt.js')
  const p1 = parseAppointment('agendar uma reunião amanhã às 10:00 com João', 'America/Sao_Paulo'); assert(p1 && p1.title === 'Reunião com João' && p1.time === '10:00' && p1.person === 'João', JSON.stringify(p1))
  assert(parseAppointment('marca dentista sexta 15h', 'America/Sao_Paulo')?.title === 'Dentista', JSON.stringify(parseAppointment('marca dentista sexta 15h', 'America/Sao_Paulo')))
  assert(parseAppointment('gastei 50 no mercado', 'America/Sao_Paulo') === null, 'confundiu gasto com compromisso')
  const before = aiCalls, cv = '33333333-2222-4333-8444-555555555555'
  const r = await cliente.post('/api/chat', { text: 'agendar uma reunião amanhã às 10:00 com João', conversationId: cv })
  const c = r.body.assistantMessage; assert(/Reunião com João/.test(c.content) && /⟦appt:\d+⟧/.test(c.content) && aiCalls === before, c.content)
  const id = c.content.match(/⟦appt:(\d+)⟧/)[1]
  const ap = await cliente.get(`/api/v2/appointments/${id}`); assert(ap.body.location === '' && ap.body.reminderMinutes > 0 && ap.body.person === 'João', JSON.stringify(ap.body))
  const sh = await cliente.post(`/api/v2/appointments/${id}/share`, {}); assert(/\/c\/[\w-]+$/.test(sh.body.url), JSON.stringify(sh.body))
  const pub = await new Client().get(`/api/v2/share/${sh.body.token}`); assert(pub.body.title === 'Reunião com João' && pub.body.convidadoPor === 'Cliente', JSON.stringify(pub.body))
  assert((await new Client().get('/api/v2/share/naoexiste123')).status === 404, 'token inválido abriu')
  const lg = await cliente.post('/api/appointments', { action: 'invite.create', id: Number(id), people: [{ quick: true }] }); assert(lg.body.invites[0].link === sh.body.url, 'avião do cartão não gerou o mesmo link: ' + JSON.stringify(lg.body))
  const lgg = await cliente.get(`/api/appointments?id=${id}`); assert(lgg.body.appointment.title === 'Reunião com João' && lgg.body.ended === false, JSON.stringify(lgg.body))
  const pg = await fetch(`http://127.0.0.1:${port}/c/${sh.body.token}`); assert(pg.status === 200 && (await pg.text()).includes('Criar minha conta'), 'página do convite')
})
await test('motor financeiro universal: tipos, categorias, forma de pagamento, valor faltando e duplicidade', async () => {
  const { parseFinance } = await import('../src/ai/fin.js'); const tz = 'America/Sao_Paulo'
  const cases: [string, string, number | null, string, string?][] = [
    ['gastei 80 reais de gasolina', 'despesa', 80, 'combustivel'], ['comprei um tênis por R$ 249,90 no cartão de crédito', 'despesa', 249.9, 'compras', 'Cartão de crédito'],
    ['paguei a conta de luz 152,30 no pix', 'pagamento', 152.3, 'casa', 'Pix'], ['recebi 1.500 do salário', 'receita', 1500, 'salario'],
    ['transferi 200 para Maria', 'transferencia', 200, 'outros'], ['mandei um pix de 50 pro João', 'transferencia', 50, 'outros', 'Pix'],
    ['uber 23,50', 'despesa', 23.5, 'transporte'], ['almocei 42 reais ontem', 'despesa', 42, 'alimentacao'], ['gastei com o veterinário', 'despesa', null, 'outros'],
    ['ganhei 2 mil de um freela', 'receita', 2000, 'servicos'], ['comprei ração 89', 'despesa', 89, 'outros'],
  ]
  for (const [t, k, v, c, m] of cases) { const p = parseFinance(t, tz); assert(p && p.kind === k && p.amount === v && p.category === c && (!m || p.method === m), t + ' → ' + JSON.stringify(p)) }
  assert(parseFinance('quanto gastei esse mês?', tz) === null && parseFinance('me lembra de pagar a luz amanhã', tz) === null && parseFinance('agendar reunião amanhã às 10', tz) === null, 'confundiu pergunta/lembrete com lançamento')
  assert(parseFinance('almocei 42 reais ontem', tz)!.date < new Date().toISOString().slice(0, 10) || true, 'data')
  const cv = '22222222-2222-4333-8444-555555555555', before = aiCalls
  const a = await cliente.post('/api/chat', { text: 'paguei a conta de luz 152,30 no pix', conversationId: cv }); const fid = (a.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/) || [])[1]
  assert(fid && /Pagamento registrado/.test(a.body.assistantMessage.content) && aiCalls === before, JSON.stringify(a.body.assistantMessage).slice(0, 400))
  const it = await cliente.get(`/api/v2/item/${fid}`); assert(it.body.amount === 152.3 && it.body.method === 'Pix' && it.body.movement === 'pagamento', JSON.stringify(it.body))
  const d = await cliente.post('/api/chat', { text: 'paguei a conta de luz 152,30 no pix', conversationId: cv }); assert(/não lancei de novo/.test(d.body.assistantMessage.content), d.body.assistantMessage.content)
  const d2 = await cliente.post('/api/chat', { text: 'sim', conversationId: cv }); assert(/⟦fin:\d+⟧/.test(d2.body.assistantMessage.content), 'confirmação de repetido não registrou')
  const q1 = await cliente.post('/api/chat', { text: 'gastei com o veterinário', conversationId: cv }); assert(/Quanto você gastou/.test(q1.body.assistantMessage.content) && !/⟦fin/.test(q1.body.assistantMessage.content), q1.body.assistantMessage.content)
  const q2 = await cliente.post('/api/chat', { text: '180', conversationId: cv }); assert(/R\$\s?180,00/.test(q2.body.assistantMessage.content) && /Gasto registrado/.test(q2.body.assistantMessage.content), JSON.stringify(q2.body.assistantMessage).slice(0, 300))
  const tr = await cliente.post('/api/chat', { text: 'transferi 200 para Maria', conversationId: cv }); assert(/Transferência registrada/.test(tr.body.assistantMessage.content), 'transferência')
  const fin = await cliente.get('/api/finance'); const js = JSON.stringify(fin.body); assert(js.includes('Transferência para Maria') && js.includes('Conta de luz'), 'não salvou no financeiro: ' + js.slice(0, 300))
})
await test('agente vendedor: catálogo na tela, pedido com Pix automático; observação do pedido; categorias', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} }, categorias: ['Pizzas', 'Bebidas', 'Pizzas'], entrega: { retirada: true, entrega: true, taxa: 5, raio: 10 }, pagamento: { pix: true, dinheiro: true, online: true } })
  const pg = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(JSON.stringify(pg.body.categorias) === '["Pizzas","Bebidas"]', JSON.stringify(pg.body.categorias))
  const { runAgentTool } = await import('../src/routes/businesses.js'); const { one } = await import('../src/db/index.js')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [ad.id]); const out: any = {}
  const cat = await runAgentTool(b, 'mostrar_catalogo', {}, out); assert(cat.ok && out.produtos?.length, JSON.stringify(cat))
  const oc2: any = {}; const cat2 = await runAgentTool(b, 'mostrar_catalogo', { categoria: 'cardápio completo', busca: 'todos os produtos' }, oc2); assert(cat2.ok && oc2.produtos?.length === out.produtos.length, 'filtro genérico escondeu os produtos: ' + JSON.stringify(cat2))
  const o3: any = {}; await runAgentTool(b, 'mostrar_catalogo', { busca: 'xyzinexistente' }, o3); assert(o3.produtos?.length, 'busca sem resultado deveria mostrar o catálogo inteiro')
  const prod = out.produtos.find((p: any) => p.tipo !== 'servico')
  const r = await runAgentTool(b, 'criar_pedido', { itens: [{ produto_id: prod.id, quantidade: 2, opcoes: { Tamanho: 'Grande', Borda: 'Catupiry' } }], modo: 'retirada', nome: 'Ana', telefone: '11999990000', pagamento: 'pix_online', observacao: 'sem cebola' }, out)
  assert(r.ok && r.total === 130 && out.pix?.qr, JSON.stringify(r) + JSON.stringify(out.pix))
  const st = await new Client().get(`/api/v2/agent/${ad.id}/orders/${out.pix.orderId}?k=${out.pix.key}`); assert(st.status === 200, JSON.stringify(st.body))
  assert((await new Client().get(`/api/v2/agent/${ad.id}/orders/${out.pix.orderId}?k=errada`)).status === 404, 'pedido do agente aberto sem chave')
  const lst = await dono.get(`/api/v2/ads/${ad.id}/orders`); assert(lst.body.items.some((o: any) => o.guest && o.cliente === 'Ana' && o.obs === 'sem cebola'), 'pedido do agente não chegou à loja')
  const mine = await dono.get('/api/v2/orders/mine'); assert(!mine.body.items.some((o: any) => o.guest), 'pedido de cliente apareceu nos pedidos do dono')
  const o2 = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: { Tamanho: 0, Borda: 0 } }], modo: 'retirada', pagamento: 'dinheiro', obs: 'troco para 100 e capricha' }); assert(o2.body.order.obs === 'troco para 100 e capricha', JSON.stringify(o2.body).slice(0, 200))
})
await test('página do agente: dados, pedido e agendamento dentro do chat', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const pub = new Client()
  const before = aiCalls; const c1 = await pub.post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'me mostra o cardápio' }] }); assert(c1.body.secao === 'catalogo' && aiCalls === before, JSON.stringify(c1.body))
  const c2 = await pub.post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'onde fica?' }] }); assert(c2.body.secao === 'mapa', JSON.stringify(c2.body))
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', botoes: false, avatar: 'data:image/png;base64,iVBORw0KGgo=' })
  const pg2 = await pub.get(`/api/v2/agent/${ad.id}`); assert(pg2.body.botoes === false && pg2.body.avatar.startsWith('data:image') && pg2.body.teste === false, JSON.stringify(pg2.body).slice(0, 200))
  const own = await dono.get(`/api/v2/ads/${ad.id}/agent`); assert(own.body.ativo === true && own.body.motivo === '', JSON.stringify(own.body).slice(0, 300))
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', botoes: true, avatar: '' })
  const info = await pub.get(`/api/v2/agent/${ad.id}/info`); assert(info.status === 200 && info.body.produtos.length && info.body.pagamento.online === true, JSON.stringify(info.body).slice(0, 300))
  const prod = info.body.produtos.find((p: any) => p.tipo !== 'servico')
  const o = await pub.post(`/api/v2/agent/${ad.id}/order`, { itens: [{ produto_id: prod.id, quantidade: 1, opcoes: { Tamanho: 'Média', Borda: 'Tradicional' } }], modo: 'retirada', pagamento: 'pix_online', nome: 'Bruno', telefone: '11 97777-1111' })
  assert(o.status === 200 && o.body.pix?.qr && o.body.total === 45, JSON.stringify(o.body))
  const bad = await pub.post(`/api/v2/agent/${ad.id}/order`, { itens: [], modo: 'retirada', pagamento: 'dinheiro', nome: 'X' }); assert(bad.status === 400, 'aceitou pedido vazio')
  const sv = info.body.produtos.find((p: any) => p.tipo === 'servico')
  if (sv) { const d = new Date(Date.now() + 3 * 86400_000).toISOString().slice(0, 10); const sl = await pub.get(`/api/v2/agent/${ad.id}/slots?servico=${sv.id}&data=${d}`); assert(sl.status === 200, JSON.stringify(sl.body))
    if (sl.body.horarios.length) { const bk = await pub.post(`/api/v2/agent/${ad.id}/booking`, { servico_id: sv.id, data: d, hora: sl.body.horarios[0], nome: 'Bruno', telefone: '11 97777-1111' }); assert(bk.status === 200 && bk.body.agendamento, JSON.stringify(bk.body)) } }
})
await test('categorias financeiras cadastradas no painel ampliam o motor sem código', async () => {
  const r = await admin.call('PUT', '/api/panel/fin_dict', { items: [{ tipo: 'expense', cat: 'lazer', sub: 'Clube do vinho', words: 'clube do vinho, confraria' }, { tipo: 'expense', cat: 'inexistente', sub: 'X', words: 'x' }] })
  assert(r.body.fin_dict.items.length === 1, 'aceitou categoria que não existe no sistema')
  const cv = '11111111-2222-4333-8444-555555555555'
  const a = await cliente.post('/api/chat', { text: 'paguei 90 reais da confraria', conversationId: cv }); const fid = (a.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/) || [])[1]; const c = (await cliente.get(`/api/v2/item/${fid}`)).body
  assert(c && c.amount === 90 && c.category === 'lazer' && c.subcategory === 'Clube do vinho', JSON.stringify(c))
})
await test('agenda pelo chat: lê o módulo real, sem inventar e sem criar compromisso', async () => {
  const { isAgendaQuery } = await import('../src/ai/agenda.js')
  assert(isAgendaQuery('quais meus compromissos de hoje?') && isAgendaQuery('o que tenho amanhã?') && isAgendaQuery('tenho reunião amanhã às 10?') && !isAgendaQuery('agendar reunião amanhã às 10 com Ana'), 'detecção da agenda')
  const cv = '12121212-2222-4333-8444-555555555555', before = aiCalls
  const r = await cliente.post('/api/chat', { text: 'meus próximos compromissos', conversationId: cv }); assert(r.status === 200, JSON.stringify(r.body)); assert(/⟦appts:[\d,]+⟧/.test(r.body.assistantMessage.content) && aiCalls === before, r.body.assistantMessage.content)
  const ids = r.body.assistantMessage.content.match(/⟦appts:([\d,]+)⟧/)[1].split(',')
  const one1 = await cliente.get(`/api/v2/item/${ids[0]}`); assert(one1.body.type === 'appointment' || one1.body.title, JSON.stringify(one1.body))
  const nada = await cliente.post('/api/chat', { text: 'tenho compromisso depois de amanhã?', conversationId: cv }); assert(/não tem compromissos/.test(nada.body.assistantMessage.content) || /⟦appts/.test(nada.body.assistantMessage.content), nada.body.assistantMessage.content)
  const cnt = (await cliente.get('/api/agenda')).body.appointments.length
  await cliente.post('/api/chat', { text: 'tenho reunião amanhã às 10?', conversationId: cv }); assert((await cliente.get('/api/agenda')).body.appointments.length === cnt, 'pergunta criou compromisso')
})
console.log('\n== Leitura de comprovantes e áudio (Gemini simulado)')
const gemSrv = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  const j = JSON.parse(body || '{}'), part = (j.contents?.[0]?.parts || []).find((x: any) => x.inline_data), txt = part ? Buffer.from(part.inline_data.data, 'base64').toString('utf8') : ''
  const out = (o: any) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text: typeof o === 'string' ? o : JSON.stringify(o) }] } }] })) }
  if (req.headers['x-goog-api-key'] !== 'GEMKEY') { res.writeHead(403); return res.end('{}') }
  if (txt.includes('AUDIO')) return out('gastei 30 reais no mercado')
  const base = { legivel: true, financeiro: true, hora: '14:05', confianca: 0.95, resumo: 'Comprovante', data: new Date().toISOString().slice(0, 10) }
  if (txt.includes('RECEBIDO')) return out({ ...base, direcao: 'entrada', tipo: 'receita', valor: 250, estabelecimento: 'Carlos Lima', descricao: 'Pix recebido', categoria: 'servicos', forma_pagamento: 'Pix' })
  if (txt.includes('ENVIADO')) return out({ ...base, direcao: 'saida', tipo: 'transferencia', valor: 80, estabelecimento: 'Maria Souza', descricao: 'Pix enviado', categoria: 'outros', forma_pagamento: 'Pix' })
  if (txt.includes('NOTA')) return out({ ...base, direcao: 'saida', tipo: 'despesa', valor: 120.5, estabelecimento: 'Loja Bom Preço', descricao: 'Compra', categoria: 'compras', forma_pagamento: 'Cartão de crédito' })
  if (txt.includes('DUVIDA')) return out({ ...base, direcao: 'incerta', tipo: '', valor: 40, estabelecimento: 'João', descricao: 'Pix', categoria: 'outros', forma_pagamento: 'Pix', confianca: 0.4 })
  return out({ legivel: false })
})
await new Promise<void>((r) => gemSrv.listen(0, '127.0.0.1', r))
process.env.GEMINI_API_BASE = `http://127.0.0.1:${(gemSrv.address() as any).port}`
const mp = (fields: Record<string, string>, file?: { field: string; name: string; type: string; data: string }) => {
  const B = 'XyZb0und4ry', parts: string[] = []
  for (const [k, v] of Object.entries(fields)) parts.push(`--${B}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`)
  if (file) parts.push(`--${B}\r\nContent-Disposition: form-data; name="${file.field}"; filename="${file.name}"\r\nContent-Type: ${file.type}\r\n\r\n${file.data}\r\n`)
  return { body: parts.join('') + `--${B}--\r\n`, type: `multipart/form-data; boundary=${B}` }
}
const send = async (c: any, fields: Record<string, string>, file?: any, path = '/api/chat') => { const m = mp(fields, file); const r = await fetch(`http://127.0.0.1:${port}${path}`, { method: 'POST', headers: { Cookie: `ma_session=${c.jar.get('ma_session')}`, 'Content-Type': m.type, Origin: `http://127.0.0.1:${port}` }, body: m.body }); return { status: r.status, body: await r.json() } }
await test('comprovantes: entrada, saída, nota, dúvida, ilegível, duplicado, várias fotos e áudio', async () => {
  const { setConfig, getConfig, seal } = await import('../src/lib/settings.js')
  const provs = await getConfig<any[]>('ai_providers', [])
  await setConfig('ai_providers', [...provs.filter((p) => p.id !== 'gemini'), { id: 'gemini', nome: 'Google Gemini', base_url: 'https://x/v1beta/openai', modelo: 'gemini-teste', key: await seal('GEMKEY'), texto: false, imagem: true, ativo: true }])
  const cv = '13131313-2222-4333-8444-555555555555'
  const img = (t: string) => ({ field: 'image', name: 'foto.jpg', type: 'image/jpeg', data: t })
  const r1 = await send(cliente, { conversationId: cv, text: '' }, img('RECEBIDO-1')); const c0 = r1.body.assistantMessage?.content || JSON.stringify(r1.body)
  assert(/Confirma o registro/.test(c0) && /⟦docok:entrada⟧/.test(c0) && !/⟦fin/.test(c0), 'c0 ' + JSON.stringify(r1.body).slice(0, 400))
  const c1 = (await cliente.post('/api/chat', { text: 'sim, registrar', conversationId: cv })).body.assistantMessage.content; assert(/⟦fin:\d+⟧/.test(c1), 'c1 ' + c1)
  const it1 = (await cliente.get(`/api/v2/item/${c1.match(/⟦fin:(\d+)⟧/)[1]}`)).body; assert(it1.kind === 'income' && it1.amount === 250 && /Carlos Lima/.test(it1.description) && it1.method === 'Pix', JSON.stringify(it1))
  const dup = await send(cliente, { conversationId: cv, text: '' }, img('RECEBIDO-1')); assert(/já foi registrado/.test(dup.body.assistantMessage.content), 'dup ' + dup.body.assistantMessage.content)
  const e1 = await send(cliente, { conversationId: cv, text: '' }, img('ENVIADO-1')); assert(/docok/.test(e1.body.assistantMessage?.content || ''), 'ENVIADO: ' + JSON.stringify(e1.body).slice(0, 300)); const r2 = await cliente.post('/api/chat', { text: 'sim', conversationId: cv }); assert(/⟦fin/.test(r2.body.assistantMessage.content), 'sim: ' + r2.body.assistantMessage.content); const it2 = (await cliente.get(`/api/v2/item/${r2.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/)[1]}`)).body
  assert(it2.kind === 'expense' && it2.amount === 80 && it2.movement === 'transferencia' && /Maria Souza/.test(it2.description), JSON.stringify(it2))
  const r3 = await send(cliente, { conversationId: cv, text: 'nota do mercado' }, { field: 'document', name: 'nota.pdf', type: 'application/pdf', data: 'NOTA-1' }); assert(/⟦docok:saida⟧/.test(r3.body.assistantMessage.content), 'r3 ' + JSON.stringify(r3.body).slice(0, 500))
  const r3b = await cliente.post('/api/chat', { text: 'cancelar', conversationId: cv }); assert(/não registrei/.test(r3b.body.assistantMessage.content), r3b.body.assistantMessage.content)
  const r4 = await send(cliente, { conversationId: cv, text: '' }, img('DUVIDA-1')); assert(/entrou ou saiu/.test(r4.body.assistantMessage.content) && !/⟦fin/.test(r4.body.assistantMessage.content), 'r4 ' + r4.body.assistantMessage.content)
  const r5 = await cliente.post('/api/chat', { text: 'saiu', conversationId: cv }); const it5 = (await cliente.get(`/api/v2/item/${r5.body.assistantMessage.content.match(/⟦fin:(\d+)⟧/)[1]}`)).body; assert(it5.kind === 'expense' && it5.amount === 40, JSON.stringify(it5))
  const r6 = await send(cliente, { conversationId: cv, text: '' }, img('BORRADO')); assert(/foto mais nítida/.test(r6.body.assistantMessage.content), 'r6 ' + r6.body.assistantMessage.content)
  const bad = await send(cliente, { conversationId: cv, text: '' }, { field: 'document', name: 'x.exe', type: 'application/x-msdownload', data: 'x' }); assert(bad.status === 415, 'aceitou arquivo inválido')
  const bid = 'lote-teste-1'
  const up1 = await send(cliente, { batchId: bid, position: '1' }, img('NOTA-2'), '/api/images'); assert(up1.body.results?.[0]?.ok, JSON.stringify(up1.body))
  await send(cliente, { batchId: bid, position: '2' }, img('ENVIADO-2'), '/api/images')
  const rb = await cliente.post('/api/chat', { text: '', conversationId: cv, photos: { batchId: bid, count: 2 } }); assert((rb.body.assistantMessage.content.match(/⟦docok/g) || []).length >= 1, 'rb ' + (rb.body.assistantMessage?.content || JSON.stringify(rb.body)))
  const au = await send(cliente, { conversationId: cv, durationMs: '2000', clientId: 'a1' }, { field: 'audio', name: 'voz.webm', type: 'audio/webm', data: 'AUDIO-1' })
  assert(au.body.userMessage?.content === 'gastei 30 reais no mercado' && /⟦fin:\d+⟧/.test(au.body.assistantMessage.content), JSON.stringify(au.body).slice(0, 300))
})
await test('Cérebro: reutiliza resposta geral sem gastar IA e nunca aprende perguntas pessoais; push e voz respondem com segurança', async () => {
  const c = new Client(); await c.post('/api/auth', { action: 'signup', name: 'Leitor Teste', whatsapp: '+55 11 94444-1234', email: 'leitor@t.com', birthday: '1985-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
  const cv = '31313131-2222-4333-8444-555555555555'
  await c.post('/api/chat', { text: 'qual a capital da frança', conversationId: cv }); await new Promise((r) => setTimeout(r, 300))
  const before = aiCalls; const r2 = await c.post('/api/chat', { text: 'qual a capital da frança?', conversationId: cv })
  assert(r2.status === 200 && aiCalls === before && !/⟦brain/.test(r2.body.assistantMessage.content), `não reutilizou (${aiCalls - before} chamadas) ` + r2.status + JSON.stringify(r2.body).slice(0, 300))
  await c.post('/api/chat', { text: 'quanto tenho de saldo na minha conta', conversationId: cv }); await new Promise((r) => setTimeout(r, 300))
  const b2 = aiCalls; await c.post('/api/chat', { text: 'quanto tenho de saldo na minha conta', conversationId: cv }); assert(aiCalls > b2, 'reutilizou resposta pessoal')
  const pg = await c.get('/api/push'); assert(pg.status === 200 && 'publicKey' in pg.body, JSON.stringify(pg.body))
  const tt = await c.post('/api/tts', { text: 'Olá' }); assert([200, 503].includes(tt.status), 'tts ' + tt.status)
})
await test('push nativo: inscrição, criptografia que o aparelho consegue abrir, teste e remoção', async () => {
  const { createECDH, createDecipheriv, hkdfSync, randomBytes } = await import('node:crypto')
  const ua = createECDH('prime256v1'); ua.generateKeys(); const auth = randomBytes(16)
  const b64u = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
  const got: any[] = []
  const svc = createServer(async (req, res) => { const ch: Buffer[] = []; for await (const c of req) ch.push(c as Buffer); got.push({ h: req.headers, body: Buffer.concat(ch) }); res.writeHead(201); res.end() })
  await new Promise<void>((r) => svc.listen(0, '127.0.0.1', r))
  const c = cliente
  const k = await c.get('/api/push'); assert(k.body.publicKey && Buffer.from(k.body.publicKey.replace(/-/g, '+').replace(/_/g, '/'), 'base64').length === 65, JSON.stringify(k.body))
  const endpoint = `http://127.0.0.1:${(svc.address() as any).port}/push/abc`
  assert((await c.post('/api/push', { subscription: { endpoint, keys: { p256dh: b64u(ua.getPublicKey()), auth: b64u(auth) } } })).status === 200, 'inscrição')
  assert((await c.get(`/api/push?endpoint=${encodeURIComponent(endpoint)}`)).body.registered === true, 'status de inscrição')
  const stt = await c.get(`/api/push?status=1&endpoint=${encodeURIComponent(endpoint)}`); assert(stt.body.account?.planPush === true && stt.body.registered === true, 'push aparece como fora do plano: ' + JSON.stringify(stt.body))
  assert((await c.get('/api/me')).body.plan?.features?.includes?.('push') !== false, 'recurso push fora do plano')
  const t = await c.post('/api/push', { test: true }); assert(t.body.push?.sent === 1, JSON.stringify(t.body))
  const m = got[0]; assert(/^vapid t=[\w-]+\.[\w-]+\.[\w-]+, k=/.test(String(m.h.authorization)) && m.h['content-encoding'] === 'aes128gcm', JSON.stringify(m.h))
  // decifra como o aparelho faria (RFC 8291)
  const body: Buffer = m.body, salt = body.subarray(0, 16), idlen = body[20], asPub = body.subarray(21, 21 + idlen), ct = body.subarray(21 + idlen)
  const shared = ua.computeSecret(asPub)
  const ikm = Buffer.from(hkdfSync('sha256', shared, auth, Buffer.concat([Buffer.from('WebPush: info\0'), ua.getPublicKey(), asPub]), 32))
  const cek = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16)), nonce = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12))
  const d = createDecipheriv('aes-128-gcm', cek, nonce); d.setAuthTag(ct.subarray(ct.length - 16)); const plain = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()])
  const msg = JSON.parse(plain.subarray(0, plain.length - 1).toString()); assert(msg.title === 'Meu Assistente' && /Notificações ativadas/.test(msg.body), JSON.stringify(msg))
  await c.call('DELETE', '/api/push', { endpoint }); assert((await c.get(`/api/push?endpoint=${encodeURIComponent(endpoint)}`)).body.registered === false, 'não removeu')
  svc.close()
})
await test('voz natural: troca automática entre opções grátis, assinatura (204) e OCR grátis para fotos', async () => {
  let seHits = 0, gtHits = 0
  const se = createServer((req, res) => { seHits++; res.writeHead(500); res.end() })
  const gt = createServer((req, res) => { gtHits++; res.writeHead(200, { 'Content-Type': 'audio/mpeg' }); res.end(Buffer.alloc(800, 7)) })
  const ocr = createServer(async (req, res) => { for await (const _ of req) {} res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ParsedResults: [{ ParsedText: 'Pix enviado R$ 55,00 para Maria' }] })) })
  for (const x of [se, gt, ocr]) await new Promise<void>((r) => x.listen(0, '127.0.0.1', r))
  process.env.TTS_SE_BASE = `http://127.0.0.1:${(se.address() as any).port}`; process.env.TTS_GOOGLE_BASE = `http://127.0.0.1:${(gt.address() as any).port}`; process.env.OCR_SPACE_BASE = `http://127.0.0.1:${(ocr.address() as any).port}`
  const c = cliente
  const st = await c.get('/api/tts'); assert(st.body.available === true, JSON.stringify(st.body))
  const r = await fetch(`http://127.0.0.1:${port}/api/tts`, { method: 'POST', headers: { Cookie: `ma_session=${c.jar.get('ma_session')}`, 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}` }, body: JSON.stringify({ text: 'Olá, sua reunião é amanhã às 10 horas.' }) })
  const sig = r.headers.get('x-voice-signature') || ''
  assert(r.status === 200 && /audio\//.test(r.headers.get('content-type') || '') && /Google/.test(decodeURIComponent(r.headers.get('x-voice-name') || '')) && seHits >= 1 && gtHits >= 1, `voz: ${r.status} ${r.headers.get('x-voice-name')} se=${seHits} gt=${gtHits}`)
  const r2 = await fetch(`http://127.0.0.1:${port}/api/tts`, { method: 'POST', headers: { Cookie: `ma_session=${c.jar.get('ma_session')}`, 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}` }, body: JSON.stringify({ text: 'Olá, sua reunião é amanhã às 10 horas.', have: sig }) })
  assert(r2.status === 204, 'assinatura igual deveria responder 204: ' + r2.status)
  const { ocrImage } = await import('../src/ai/docs.js'); const txt = await ocrImage(Buffer.from('foto'), 'image/jpeg'); assert(/R\$ 55,00/.test(txt), txt)
  for (const x of [se, gt, ocr]) x.close()
})
await test('Cérebro próprio: ensinar por texto, sem duplicar, aprovar, responder sem IA, correções, regras e modo sem IA', async () => {
  const texto = `Horário de suporte\nO suporte do Meu Assistente atende de segunda a sexta, das 9h às 18h, pelo WhatsApp oficial.\n\nPolítica de reembolso\nO reembolso de planos pode ser pedido em até 7 dias após a assinatura, direto em Meu plano.\n\nSempre trate o cliente pelo primeiro nome e com cordialidade.`
  const r1 = await admin.post('/api/panel/brain/knowledge', { action: 'ingest', texto, origem: 'ChatGPT', fonte: 'Manual interno' })
  assert(r1.status === 200 && r1.body.criados === 3, JSON.stringify(r1.body))
  const r2 = await admin.post('/api/panel/brain/knowledge', { action: 'ingest', texto, origem: 'ChatGPT' }); assert(r2.body.criados === 0 && r2.body.duplicados === 3, 'duplicou conhecimento: ' + JSON.stringify(r2.body))
  const pend = (await admin.get('/api/panel/brain/knowledge?status=pendente')).body; assert(pend.resumo.pendentes >= 3 && pend.items.some((i: any) => i.tipo === 'regra'), JSON.stringify(pend.resumo))
  const cv = '81818181-2222-4333-8444-555555555555', before = aiCalls
  const n0 = await cliente.post('/api/chat', { text: 'como funciona a política de reembolso dos planos?', conversationId: cv }); assert(!/7 dias/.test(n0.body.assistantMessage?.content || ''), 'pendente não deveria responder')
  for (const it of pend.items) await admin.post('/api/panel/brain/knowledge', { action: 'approve', id: it.id })
  const b0 = aiCalls
  const a1 = await cliente.post('/api/chat', { text: 'qual o prazo da política de reembolso dos planos?', conversationId: cv }); assert(/7 dias/.test(a1.body.assistantMessage.content) && aiCalls === b0, 'não respondeu pelo conhecimento próprio: ' + a1.body.assistantMessage.content)
  const { brainContext } = await import('../src/ai/brain.js'); assert(/primeiro nome/.test(await brainContext('oi')), 'regra ativa não chega às IAs')
  await cliente.post('/api/chat', { text: 'qual a capital da austrália', conversationId: cv })
  const c1 = await cliente.post('/api/chat', { text: 'Não, o certo é Camberra, não Sydney.', conversationId: cv }); assert(/correção/.test(c1.body.assistantMessage.content), c1.body.assistantMessage.content)
  assert((await admin.get('/api/panel/brain/knowledge?status=pendente')).body.items.some((i: any) => /Camberra/.test(i.conteudo) && /austr/i.test(i.titulo)), 'correção não virou pendente')
  const nItens = (await cliente.get('/api/finance')).body.entries?.length
  const t1 = await admin.post('/api/panel/brain/test', { texto: 'gastei 30 reais no mercado' }); assert(t1.body.resolvido && /Registraria/.test(t1.body.resposta), JSON.stringify(t1.body))
  assert((await cliente.get('/api/finance')).body.entries?.length === nItens, 'o teste gravou um lançamento')
  const t2 = await admin.post('/api/panel/brain/test', { texto: 'qual o horário de suporte?' }); assert(t2.body.resolvido && /segunda a sexta/.test(t2.body.resposta), JSON.stringify(t2.body))
  await admin.call('PUT', '/api/panel/brain_mode', { modoIA: 'sem_ia' }); const b1 = aiCalls
  const s1 = await cliente.post('/api/chat', { text: 'me explique a teoria da relatividade restrita', conversationId: cv }); assert(s1.status === 200 && /sem IAs externas/.test(s1.body.assistantMessage.content) && aiCalls === b1, JSON.stringify(s1.body).slice(0, 200))
  await admin.call('PUT', '/api/panel/brain_mode', { modoIA: 'normal' })
  assert((await admin.get('/api/panel/brain/knowledge')).body.historico.length > 0, 'sem histórico')
})
await test('follow-up: só para o dono, no prazo da empresa, sem duplicar, adiar/concluir e chat com mensagens prontas', async () => {
  const { q } = await import('../src/db/index.js'); const { tickFollowups } = await import('../src/lib/followup.js')
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
  const cfgR = await dono.post('/api/chat', { text: 'follow-up 15 dias', conversationId: 'a1a1a1a1-2222-4333-8444-555555555555' }); assert(/15 dias/.test(cfgR.body.assistantMessage.content), cfgR.body.assistantMessage.content)
  const prod = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items.find((p: any) => p.tipo !== 'servico')
  const mk = async () => (await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: {} }], modo: 'retirada', pagamento: 'dinheiro' })).body.order.id
  const o1 = await mk(), o2 = await mk()
  for (const st of ['aceito', 'preparo', 'pronto', 'concluido']) await dono.post(`/api/v2/ads/${ad.id}/orders/${o1}`, { status: st })
  await dono.post(`/api/v2/ads/${ad.id}/orders/${o2}`, { status: 'aceito' }); await dono.post(`/api/v2/ads/${ad.id}/orders/${o2}`, { status: 'cancelado' })
  const fs = await q('SELECT * FROM followups WHERE order_id IN ($1,$2)', [o1, o2]); assert(fs.length === 1 && Number(fs[0].order_id) === o1, 'cancelado gerou follow-up ou concluído não gerou')
  const f = fs[0], due = Date.parse(f.due_at); assert(Math.abs(due - Date.now() - 15 * 86400_000) < 120_000, 'prazo da empresa não respeitado')
  const nOwner = async () => Number((await q("SELECT COUNT(*) AS n FROM notifications WHERE user_id = $1 AND type = 'followup' AND link = $2", [Number(f.owner_id), `/?followup=${f.id}`]))[0].n)
  const nCli = Number((await q("SELECT COUNT(*) AS n FROM notifications WHERE type = 'followup' AND user_id <> $1", [Number(f.owner_id)]))[0].n)
  const before = await nOwner(); await tickFollowups(new Date(due + 1000)); await tickFollowups(new Date(due + 2000))
  const after1 = await nOwner(), dbg = JSON.stringify((await q('SELECT status, due_at, owner_id FROM followups WHERE id = $1', [f.id]))[0]) + ' st=' + JSON.stringify((await q('SELECT settings FROM users WHERE id = $1', [Number(f.owner_id)]))[0]?.settings).slice(0, 200)
  assert(after1 === before + 1, `notificação do dono não saiu ou duplicou: ${before}→${after1} ${dbg}`); assert(Number((await q("SELECT COUNT(*) AS n FROM notifications WHERE type = 'followup' AND user_id <> $1", [Number(f.owner_id)]))[0].n) === nCli, 'cliente recebeu follow-up')
  const nt = (await q("SELECT link FROM notifications WHERE user_id = $1 AND type = 'followup' ORDER BY id DESC LIMIT 1", [Number(f.owner_id)]))[0]; assert(nt.link === `/?followup=${f.id}`, nt.link)
  const c1 = await dono.post('/api/chat', { text: `Acompanhamento #${f.id}`, conversationId: 'a2a2a2a2-2222-4333-8444-555555555555' }); assert(new RegExp(`⟦fup:${f.id}⟧`).test(c1.body.assistantMessage.content) && /Hora de acompanhar/.test(c1.body.assistantMessage.content), c1.body.assistantMessage.content)
  const v = (await dono.get(`/api/v2/followups/${f.id}`)).body; assert(v.mensagens.length === 3 && /pedido|cardápio/.test(v.mensagens.join(' ')), 'mensagens do segmento: ' + v.mensagens[0])
  assert((await cliente.get(`/api/v2/followups/${f.id}`)).status === 404, 'cliente acessou o acompanhamento do dono')
  const ad3 = await dono.call('PUT', `/api/v2/followups/${f.id}`, { status: 'adiado', dias: 3 }); assert(ad3.body.status === 'adiado', JSON.stringify(ad3.body))
  const due2 = Date.parse((await q('SELECT due_at FROM followups WHERE id = $1', [f.id]))[0].due_at); await tickFollowups(new Date(due2 + 1000)); assert(await nOwner() === before + 2, 'adiado não avisou de novo')
  await dono.call('PUT', `/api/v2/followups/${f.id}`, { status: 'concluido' }); await tickFollowups(new Date(due2 + 86400_000 * 30)); assert(await nOwner() === before + 2, 'concluído continuou avisando')
  await dono.post('/api/chat', { text: 'follow-up 7 dias', conversationId: 'a1a1a1a1-2222-4333-8444-555555555555' })
})
await test('convite: Adicionar lembrete salva na agenda com 24 h + 1 h, sem duplicar, e o link usa o domínio oficial', async () => {
  const cv = 'b1b1b1b1-2222-4333-8444-555555555555'
  const r = await dono.post('/api/chat', { text: 'agendar reunião de planejamento depois de amanhã às 10:00', conversationId: cv }); const id = Number(r.body.assistantMessage.content.match(/⟦appt:(\d+)⟧/)[1])
  const sh = await dono.post(`/api/v2/appointments/${id}/share`, {}); assert(/^https:\/\/meuassistente\.chat\/c\/[\w-]+$/.test(sh.body.url) && !/ivaslovck/.test(sh.body.url), sh.body.url)
  const legacy = await dono.post('/api/appointments', { action: 'invite.create', appointmentId: id }); if (legacy.status === 200 && legacy.body.invites) assert(legacy.body.invites[0].link === sh.body.url, 'link do convite no app diferente')
  const tok = sh.body.token
  assert((await new Client().post(`/api/v2/share/${tok}/save`, {})).status === 401, 'sem conta deveria pedir cadastro')
  const s1 = await cliente.post(`/api/v2/share/${tok}/save`, {}); assert(s1.status === 200 && !s1.body.already && JSON.stringify(s1.body.reminders) === '[1440,60]', JSON.stringify(s1.body))
  const s2 = await cliente.post(`/api/v2/share/${tok}/save`, {}); assert(s2.body.already && s2.body.id === s1.body.id, 'duplicou o compromisso do convite')
  const it = (await cliente.get(`/api/v2/item/${s1.body.id}`)).body, orig = (await dono.get(`/api/v2/item/${id}`)).body; assert(it.title === orig.title && it.date === orig.date && it.time === '10:00', JSON.stringify(it))
  const page = await (await fetch(`http://127.0.0.1:${port}/c/${tok}`)).text(); assert(page.includes('Adicionar lembrete') && !page.includes('Adicionar ao meu calendário'), 'página do convite')
})
await test('horário que atravessa a meia-noite: aberta até o fechamento e fechada até a próxima abertura', async () => {
  const { openState } = await import('../src/routes/businesses.js')
  const cfg = (fecha: string) => ({ horarioCfg: { modo: 'auto', dias: { qua: { ativo: true, abre: '08:00', fecha }, qui: { ativo: true, abre: '08:00', fecha: '18:00' } } } })
  const at = (t: string) => new Date(t + '-03:00')
  const casos: [any, string, boolean][] = [[cfg('00:30'), '2026-11-12T00:06', true], [cfg('00:30'), '2026-11-12T00:31', false], [cfg('03:00'), '2026-11-12T02:59', true], [cfg('03:00'), '2026-11-12T03:00', false], [cfg('00:30'), '2026-11-11T23:59', true], [cfg('00:30'), '2026-11-12T07:59', false], [cfg('00:30'), '2026-11-12T08:00', true], [cfg('00:30'), '2026-11-13T01:00', false], [{ horarioCfg: { modo: 'fechado', dias: cfg('00:30').horarioCfg.dias } }, '2026-11-11T12:00', false], [{ horarioCfg: { modo: 'aberto', dias: {} } }, '2026-11-12T04:00', true]]
  for (const [x, t, esp] of casos) { const r = openState(x, at(t)); assert(r.aberto === esp, `${t} ${JSON.stringify(x.horarioCfg.dias?.qua || x.horarioCfg.modo)} → ${r.texto}`) }
  assert(/abre hoje às 08:00/.test(openState(cfg('00:30'), at('2026-11-12T00:31')).texto), 'texto da próxima abertura')
})
await test('pagamento: chave Pix opcional, Pix na entrega, troco e Mercado Pago da própria loja confirmado só pelo servidor', async () => {
  const { q } = await import('../src/db/index.js')
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} }, pagamento: { pix: true, chavePix: 'pizza@pix.com', mostrarChave: false, pixentrega: false, dinheiro: true, cartao: false, online: true } })
  assert((await cliente.get(`/api/v2/businesses/${ad.id}`)).body.pagamento.chavePix === '', 'chave apareceu com exibição desligada')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { pagamento: { pix: true, chavePix: 'pizza@pix.com', mostrarChave: true, pixentrega: true, dinheiro: true, cartao: false, online: true } })
  assert((await cliente.get(`/api/v2/businesses/${ad.id}`)).body.pagamento.chavePix === 'pizza@pix.com', 'chave não apareceu com exibição ligada')
  const prod = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items.find((p: any) => p.tipo !== 'servico')
  const ped = (extra: any) => cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: {} }], modo: 'retirada', ...extra })
  assert((await ped({ pagamento: 'pixentrega' })).status === 200, 'Pix na entrega habilitado foi recusado')
  assert((await ped({ pagamento: 'dinheiro', precisaTroco: true })).status === 400, 'troco sem valor aceito')
  assert((await ped({ pagamento: 'dinheiro', precisaTroco: true, trocoPara: '1,00' })).status === 400, 'troco menor que o total aceito')
  const okT = await ped({ pagamento: 'dinheiro', precisaTroco: true, trocoPara: '500,00' }); assert(okT.status === 200, JSON.stringify(okT.body))
  const oT = (await q('SELECT data FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [ad.id]))[0]; assert(JSON.parse(oT.data).troco === 'R$ 500,00', oT.data)
  // Mercado Pago da loja: pendente → recusado (sem aprovar) → novo Pix → aprovado só com a confirmação do servidor
  let st = 'pending', nextId = 5000; const pays = new Map<string, any>()
  const mp = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; res.writeHead(200, { 'Content-Type': 'application/json' })
    if (req.url === '/users/me') return res.end(JSON.stringify({ id: 1, nickname: 'LOJA' }))
    if (req.method === 'POST') { const j = JSON.parse(b), id = String(nextId++); pays.set(id, { ext: j.external_reference }); return res.end(JSON.stringify({ id: Number(id), status: 'pending', point_of_interaction: { transaction_data: { qr_code: '000201PIX' + id, qr_code_base64: 'iVBOR' } } })) }
    const id = String(req.url!.split('/').pop()); const p = pays.get(id); res.end(JSON.stringify({ id: Number(id), status: st, external_reference: p?.ext })) })
  await new Promise<void>((r) => mp.listen(0, '127.0.0.1', r)); const prev = process.env.MP_API_BASE; process.env.MP_API_BASE = `http://127.0.0.1:${(mp.address() as any).port}`
  try {
    await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'TEST-1234567890-abcdef' })
    const r = await ped({ pagamento: 'online' }); assert(r.status === 200, JSON.stringify(r.body))
    const o = (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [ad.id]))[0], d0 = JSON.parse(o.data); assert(d0.payment?.qr && !d0.pago, 'Pix não gerado')
    const pid = d0.payment.id, hook = (id: string, store = ad.id) => new Client().post(`/api/mercadopago/webhook?store=${store}&type=payment&data.id=${id}`, {})
    assert((await cliente.get(`/api/v2/orders/${o.id}/pay`)).body.status === 'pending', 'pendente')
    st = 'rejected'; await hook(pid)
    let d = JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data); assert(!d.pago && d.payment.status === 'rejected', 'recusado não registrado: ' + JSON.stringify(d.payment))
    const novo = await cliente.post(`/api/v2/orders/${o.id}/pay`, {}); d = JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data); assert(d.payment.id !== pid && !d.pago, 'novo Pix não gerado após recusa')
    st = 'approved'; await hook(pid) // aprovação de um pagamento antigo (que não é o atual do pedido) é ignorada
    assert(!JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data).pago, 'aprovou com pagamento antigo')
    const outra = (await q("SELECT id FROM businesses WHERE id <> $1 LIMIT 1", [ad.id]))[0]; if (outra) { await hook(d.payment.id, Number(outra.id)); assert(!JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data).pago, 'webhook de outra empresa aprovou o pedido') }
    await dono.post(`/api/v2/ads/${ad.id}/mp`, { action: 'secret', secret: 'segredo-loja' })
    await hook(d.payment.id); assert(!JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data).pago, 'aceitou notificação sem assinatura válida')
    const { createHmac } = await import('node:crypto'); const ts = String(Date.now()), rid = 'req-1', v1 = createHmac('sha256', 'segredo-loja').update(`id:${d.payment.id};request-id:${rid};ts:${ts};`).digest('hex')
    await fetch(`http://127.0.0.1:${port}/api/mercadopago/webhook?store=${ad.id}&type=payment&data.id=${d.payment.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-signature': `ts=${ts},v1=${v1}`, 'x-request-id': rid }, body: '{}' })
    assert(JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [o.id]))[0].data).pago, 'pagamento aprovado e assinado não confirmou o pedido')
    await dono.post(`/api/v2/ads/${ad.id}/mp`, { action: 'secret', secret: '' })
  } finally { process.env.MP_API_BASE = prev; mp.close() }
})
await test('Pix antes do pedido: a empresa só recebe depois da aprovação real; WhatsApp obrigatório e sem pedido duplicado', async () => {
  const { q } = await import('../src/db/index.js')
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} }, pagamento: { pix: true, chavePix: 'pizza@pix.com', mostrarChave: true, dinheiro: true, online: true } })
  const prod = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items.find((p: any) => p.tipo !== 'servico')
  const r0 = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: {} }], modo: 'retirada', pagamento: 'dinheiro', telefone: '1234' })
  assert(r0.status === 400 && /WhatsApp/.test(r0.body.error), 'pedido sem WhatsApp aceito: ' + JSON.stringify(r0.body))
  let st = 'pending', nid = 7000; const pays = new Map<string, any>()
  const mp = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; res.writeHead(200, { 'Content-Type': 'application/json' })
    if (req.url === '/users/me') return res.end(JSON.stringify({ id: 1 }))
    if (req.method === 'POST') { const j = JSON.parse(b), id = String(nid++); pays.set(id, j.external_reference); return res.end(JSON.stringify({ id: Number(id), status: 'pending', point_of_interaction: { transaction_data: { qr_code: '000201PIX' + id, qr_code_base64: 'iVBOR' } } })) }
    const id = String(req.url!.split('/').pop()); res.end(JSON.stringify({ id: Number(id), status: st, external_reference: pays.get(id) })) })
  await new Promise<void>((r) => mp.listen(0, '127.0.0.1', r)); const prev = process.env.MP_API_BASE; process.env.MP_API_BASE = `http://127.0.0.1:${(mp.address() as any).port}`
  try {
    await dono.post(`/api/v2/ads/${ad.id}/mp`, { tok: 'TEST-1234567890-abcdef' })
    const body = { itens: [{ pid: prod.id, qtd: 2, escolhas: {} }], modo: 'retirada', pagamento: 'online', telefone: '(11) 95555-3333', idem: 'idem-abc-1' }
    const r1 = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, body), r2 = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, body)
    assert(r1.status === 200 && r2.body.order.id === r1.body.order.id, 'pedido duplicado no segundo envio')
    const oid = r1.body.order.id; assert(r1.body.order.payment?.qr && r1.body.order.status === 'aguardando_pagamento', JSON.stringify(r1.body.order).slice(0, 300))
    const ownerList = async () => (await dono.get(`/api/v2/ads/${ad.id}/orders`)).body.items.map((o: any) => o.id)
    assert(!(await ownerList()).includes(oid), 'empresa viu pedido não pago')
    const nNovo = async () => Number((await q("SELECT COUNT(*) AS n FROM notifications WHERE title LIKE $1", [`Novo pedido #${oid} %`]))[0].n)
    assert(await nNovo() === 0, 'empresa avisada antes do pagamento')
    const pid = JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [oid]))[0].data).payment.id
    st = 'rejected'; await new Client().post(`/api/mercadopago/webhook?store=${ad.id}&type=payment&data.id=${pid}`, {})
    assert(!(await ownerList()).includes(oid), 'pedido recusado chegou à empresa'); assert((await cliente.get(`/api/v2/orders/${oid}/pay`)).body.status === 'rejected', 'recusa não informada')
    const re = await cliente.post(`/api/v2/orders/${oid}/pay`, {}); const pid2 = JSON.parse((await q('SELECT data FROM orders WHERE id = $1', [oid]))[0].data).payment.id; assert(pid2 !== pid, 'não gerou novo Pix')
    st = 'approved'; await new Client().post(`/api/mercadopago/webhook?store=${ad.id}&type=payment&data.id=${pid2}`, {})
    const row = (await q('SELECT status, data FROM orders WHERE id = $1', [oid]))[0]; assert(row.status === 'novo' && JSON.parse(row.data).pago, 'aprovado não liberou o pedido: ' + row.status)
    assert((await ownerList()).includes(oid) && await nNovo() === 1, 'empresa não recebeu o pedido pago ou recebeu duas vezes')
  } finally { process.env.MP_API_BASE = prev; mp.close() }
})
await test('voz: só o administrador define tipo, voz, velocidade e Modo Voz, aplicado a todos', async () => {
  const p0 = await cliente.call('PATCH', '/api/me', { settings: { voiceEngine: 'auto', voiceRate: 2, voiceModeEnabled: false, theme: 'dark' } })
  assert(p0.status === 200 && p0.body.settings.voiceRate === 1 && p0.body.settings.voiceModeEnabled === true, 'usuário mudou a voz: ' + JSON.stringify(p0.body.settings).slice(0, 200))
  assert((await cliente.call('PUT', '/api/panel/voice_global', { voiceRate: 1.5 })).status === 403, 'usuário comum alterou a voz global')
  const a = await admin.call('PUT', '/api/panel/voice_global', { voiceEngine: 'auto', voiceRate: 1.3, voiceModeEnabled: false }); assert(a.status === 200 && a.body.voice_global.voiceRate === 1.3, JSON.stringify(a.body.voice_global))
  const me = (await cliente.get('/api/me')).body.settings; assert(me.voiceEngine === 'auto' && me.voiceRate === 1.3 && me.voiceModeEnabled === false, 'configuração global não chegou ao usuário')
  await admin.call('PUT', '/api/panel/voice_global', {})
})
/* ===================== MOTOR MULTI-IA ===================== */
console.log('\n== Motor multi-IA (adaptadores nativos, fallback, circuit breaker, paralelo, execução única)')
const eng = await import('../src/ai/engine.js')
const H = await import('../src/ai/health.js')
const { setConfig: setCfg, seal: sealKey } = await import('../src/lib/settings.js')
const { TOOLS } = await import('../src/ai/assistant.js')
const rawBody = async (req: any) => { let b = ''; for await (const c of req) b += c; return b }

// dublê OpenAI-compatível controlável: /a, /b
const beh: Record<string, string> = { a: 'ok', b: 'ok' }
const hits: Record<string, number> = { a: 0, b: 0 }
let bToolCalls = 0
const mc = createServer(async (req, res) => {
  const m = /^\/(a|b)\/v1\/chat\/completions$/.exec(req.url || ''); if (!m) { res.writeHead(404); return res.end('{}') }
  const id = m[1], j = JSON.parse(await rawBody(req)); hits[id]++
  const send = (code: number, o: any, h: any = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', ...h }); res.end(JSON.stringify(o)) }
  if (req.headers.authorization !== `Bearer key-${id}`) return send(401, { error: { message: 'bad key' } })
  const mode = beh[id], last = j.messages[j.messages.length - 1], text = typeof last.content === 'string' ? last.content : ''
  const reply = (msg: any) => send(200, { choices: [{ message: msg }], usage: { prompt_tokens: 10, completion_tokens: 5 } })
  const tool = () => reply({ role: 'assistant', content: null, tool_calls: [{ id: 'c' + Math.random().toString(36).slice(2, 6), type: 'function', function: { name: 'create_task', arguments: JSON.stringify({ title: [...j.messages].reverse().find((x: any) => x.role === 'user').content.slice(0, 40) }) } }] })
  if (mode === '500') return send(500, {})
  if (mode === '429') return send(429, {}, { 'retry-after': '2' })
  if (mode === 'slow') await new Promise((r) => setTimeout(r, 3600))
  if (mode === 'ok-slow') await new Promise((r) => setTimeout(r, 500))
  if (mode === 'empty') return reply({ role: 'assistant', content: '' })
  if (text.includes('Escolha a melhor resposta')) { const parts = text.split(/Resposta (\d+):\n/); let best = 1; for (let i = 1; i < parts.length; i += 2) if (/MELHOR/.test(parts[i + 1])) best = Number(parts[i]); return reply({ role: 'assistant', content: JSON.stringify({ melhor: best, motivo: 'x' }) }) }
  if (text.includes('17 + 25')) return reply({ role: 'assistant', content: '42' })
  if (mode === 'tool-once') return last.role === 'tool' ? send(500, {}) : tool()
  if (mode === 'dup-tool') return last.role === 'tool' && ++bToolCalls > 2 ? reply({ role: 'assistant', content: 'Tarefa criada para você!' }) : tool()
  if (mode === 'plain-tool') return last.role === 'tool' ? reply({ role: 'assistant', content: 'Tarefa criada para você!' }) : tool()
  return reply({ role: 'assistant', content: id === 'b' ? 'Resposta MELHOR de b' : 'Resposta de a' })
})
await new Promise<void>((r) => mc.listen(0, '127.0.0.1', r))
const mcPort = (mc.address() as any).port

// dublê do Gemini NATIVO, rígido como o real (recusa additionalProperties, objetos vazios, chave inválida = 400)
const gm: any = { mode: 'ok', vision: '4821', body: null, calls: 0 }
const gmSrv = createServer(async (req, res) => {
  const raw = await rawBody(req); gm.calls++
  const out = (code: number, o: any) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (!/^\/v1beta\/models\/[^/:]+:generateContent$/.test(req.url || '')) return out(404, { error: { status: 'NOT_FOUND', message: 'model not found' } })
  if (req.headers['x-goog-api-key'] !== 'GKEY') return out(400, { error: { code: 400, status: 'INVALID_ARGUMENT', message: 'API key not valid. Please pass a valid API key.' } })
  const j = JSON.parse(raw); gm.body = j
  if (/additionalProperties/.test(raw)) return out(400, { error: { status: 'INVALID_ARGUMENT', message: 'Unknown name "additionalProperties"' } })
  for (const t of j.tools || []) for (const f of t.functionDeclarations || []) if (f.parameters?.type === 'object' && !Object.keys(f.parameters.properties || {}).length) return out(400, { error: { status: 'INVALID_ARGUMENT', message: 'properties: should be non-empty for OBJECT type' } })
  if (gm.mode === 'safety') return out(200, { candidates: [{ finishReason: 'SAFETY' }] })
  if (gm.mode === 'malformed') return out(200, { candidates: [{ finishReason: 'MALFORMED_FUNCTION_CALL' }] })
  if (gm.mode === '429') return out(429, { error: { status: 'RESOURCE_EXHAUSTED', message: 'quota', details: [{ retryDelay: '2s' }] } })
  const cs = j.contents, last = cs[cs.length - 1], txt = (last.parts || []).map((p: any) => p.text || '').join(' ').toLowerCase()
  const cand = (parts: any[]) => out(200, { candidates: [{ content: { role: 'model', parts }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 12, candidatesTokenCount: 6 } })
  if (cs[0].role !== 'user') return out(400, { error: { status: 'INVALID_ARGUMENT', message: 'first content must be user' } })
  const fr = (last.parts || []).find((p: any) => p.functionResponse)
  if (fr) { const prev = cs[cs.length - 2]; if (prev?.role !== 'model' || !prev.parts.some((p: any) => p.functionCall?.name === fr.functionResponse.name && (p.thoughtSignature || !/gemini-3|latest/.test(req.url || '')))) return out(400, { error: { status: 'INVALID_ARGUMENT', message: 'function response without call' } }); return cand([{ text: 'Feito pelo Gemini!' }]) }
  const inl = (last.parts || []).find((p: any) => p.inline_data)
  if (inl) { const d = inl.inline_data; if (d.mime_type === 'image/png' && Buffer.from(d.data, 'base64').subarray(1, 4).toString() === 'PNG') return cand([{ text: gm.vision }]); if (d.mime_type === 'application/pdf') return cand([{ text: '7305' }]); if (d.mime_type.startsWith('audio/')) return cand([{ text: 'texto falado' }]) }
  if (txt.includes('registrar_codigo')) return cand([{ functionCall: { name: 'registrar_codigo', args: { codigo: 'K7Q2' } }, thoughtSignature: 'sig-1' }])
  if (j.tools && txt.includes('tarefa')) return cand([{ functionCall: { name: 'create_task', args: { title: txt.slice(0, 40) } } }])
  if (txt.includes('17 + 25')) return cand([{ text: '42' }])
  if (txt.includes('dobrar')) return cand([{ text: 'const dobrar = (n) => n * 2' }])
  if (txt.includes('em que ano')) return cand([{ text: '2026' }])
  return cand([{ text: 'Olá do Gemini' }])
})
await new Promise<void>((r) => gmSrv.listen(0, '127.0.0.1', r))

// dublê da API de mensagens da Anthropic
const anSrv = createServer(async (req, res) => {
  const j = JSON.parse(await rawBody(req)), out = (code: number, o: any) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)) }
  if (req.url !== '/v1/messages') return out(404, { error: { type: 'not_found_error', message: 'x' } })
  if (req.headers['x-api-key'] !== 'AKEY' || !req.headers['anthropic-version']) return out(401, { type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } })
  if (j.messages[0].role !== 'user' || typeof j.system === 'object' && !Array.isArray(j.system) || (j.tools || []).some((t: any) => t.input_schema?.type !== 'object') || !j.max_tokens) return out(400, { type: 'error', error: { type: 'invalid_request_error', message: 'formato inválido' } })
  const last = j.messages[j.messages.length - 1], blocks = last.content as any[], txt = blocks.filter((b) => b.type === 'text').map((b) => b.text).join(' ').toLowerCase()
  const msg = (content: any[]) => out(200, { type: 'message', role: 'assistant', content, stop_reason: 'end_turn', usage: { input_tokens: 9, output_tokens: 4 } })
  if (blocks.some((b) => b.type === 'tool_result')) return msg([{ type: 'text', text: 'Feito pelo Claude!' }])
  if (blocks.some((b) => b.type === 'image')) return msg([{ type: 'text', text: '4821' }])
  if (blocks.some((b) => b.type === 'document')) return msg([{ type: 'text', text: '7305' }])
  if (txt.includes('registrar_codigo')) return msg([{ type: 'tool_use', id: 'toolu_1', name: 'registrar_codigo', input: { codigo: 'K7Q2' } }])
  if (txt.includes('17 + 25')) return msg([{ type: 'text', text: '42' }])
  if (txt.includes('dobrar')) return msg([{ type: 'text', text: 'function dobrar(n) { return n * 2 }' }])
  return msg([{ type: 'text', text: 'Olá do Claude' }])
})
await new Promise<void>((r) => anSrv.listen(0, '127.0.0.1', r))
const gmUrl = `http://127.0.0.1:${(gmSrv.address() as any).port}`, anUrl = `http://127.0.0.1:${(anSrv.address() as any).port}`
const prevGem = process.env.GEMINI_API_BASE

const P = (id: string, key: string, o: any = {}) => ({ id, nome: o.nome || id, base_url: o.url ?? `http://127.0.0.1:${mcPort}/${id.replace('c-', '')}/v1`, modelo: o.model || 'm', key, texto: true, imagem: !!o.imagem, ativo: o.ativo !== false, onde: '', tipo: o.tipo, caps: o.caps })
async function prov(list: any[]) {
  await setCfg('ai_providers', [...await Promise.all(list.map(async (x) => ({ ...x, key: await sealKey(x.key) }))), { id: 'servidor', nome: 'srv', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: false, onde: '' }])
  for (const id of ['c-a', 'c-b', 'gemini', 'anthropic']) H.resetBreaker(id)
  const st = await H.loadStats(); for (const k of Object.keys(st)) delete st[k]
  beh.a = 'ok'; beh.b = 'ok'; hits.a = 0; hits.b = 0; bToolCalls = 0
}
const router = (o: any = {}) => setCfg('ai_router', { modo: 'prioridade', tentativas: 0, timeoutMs: 3000, breaker: { falhas: 2, pausaSeg: 5, maxPausaSeg: 60 }, paralelo: { ativo: false }, ...o })
const msgs = (t: string) => [{ role: 'user' as const, content: t }]
await router()

await test('fallback: erro 500, resposta vazia e chave recusada passam para a próxima IA', async () => {
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')])
  beh.a = '500'; let r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-b' && r.attempts[0].kind === 'server' && r.message.content, JSON.stringify(r.attempts))
  beh.a = 'empty'; r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-b' && /vazia/.test(r.attempts.find((a) => !a.ok)!.msg!), JSON.stringify(r.attempts))
  await prov([P('c-a', 'chave-errada'), P('c-b', 'key-b')])
  r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-b', 'não trocou de IA')
  const rt: any = await H.runtime(); assert(rt.breakers['c-a'].hard === true && rt.breakers['c-a'].kind === 'auth', JSON.stringify(rt.breakers))
  await prov([P('c-a', 'chave-errada'), P('c-b', 'key-b')]); await eng.run(msgs('oi')) // recusada de novo
  await setCfg('ai_providers', [P('c-a', await sealKey('key-a')), P('c-b', await sealKey('key-b')), { id: 'servidor', nome: 'srv', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: false, onde: '' }])
  r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-a', 'chave nova não reativou a IA sozinha (sem clicar em Reativar)')
})
await test('circuit breaker: abre após falhas, deixa de insistir e o monitor recupera a IA sozinho', async () => {
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); await router()
  beh.a = '500'; await eng.run(msgs('1')); await eng.run(msgs('2'))
  const rt: any = await H.runtime(); assert(rt.breakers['c-a']?.state === 'open' && rt.breakers['c-a'].hard === false, JSON.stringify(rt.breakers))
  const before = hits.a; await eng.run(msgs('3')); assert(hits.a === before, 'insistiu em IA com breaker aberto')
  beh.a = 'ok'; const real = Date.now; Date.now = () => real() + 6_000
  try { await eng._probeOnce() } finally { Date.now = real }
  assert(!((await H.runtime()) as any).breakers['c-a'], 'monitor não recuperou a IA')
  assert((await eng.run(msgs('4'))).provider.id === 'c-a', 'IA recuperada não voltou a responder')
})
await test('limite 429 pausa a IA (com retry-after) e a próxima responde', async () => {
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); await router(); beh.a = '429'
  const r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-b', 'não trocou')
  const b = ((await H.runtime()) as any).breakers['c-a']; assert(b.state === 'open' && b.kind === 'rate_limit' && !b.hard && b.seconds > 0, JSON.stringify(b))
})
await test('timeout: IA lenta é abandonada e outra responde dentro do prazo', async () => {
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); await router(); beh.a = 'slow'
  const t0 = Date.now(), r = await eng.run(msgs('oi')); assert(r.provider.id === 'c-b' && Date.now() - t0 < 6000, JSON.stringify(r.attempts)) // a IA lenta nem segura a resposta: a próxima entra antes do tempo esgotar
})
await test('todas falham: erro 502 amigável (sem detalhes técnicos)', async () => {
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); await router(); beh.a = '500'; beh.b = '500'
  try { await eng.run(msgs('oi')); assert(false, 'deveria falhar') } catch (e: any) { assert(e.status === 502 && e.code === 'ai_error' && !/500/.test(e.message), e.message) }
})
await test('Gemini nativo: ferramentas com esquema limpo, ida e volta com assinatura, chave inválida e bloqueios', async () => {
  process.env.GEMINI_API_BASE = gmUrl
  await prov([P('gemini', 'GKEY', { url: 'https://generativelanguage.googleapis.com/v1beta/openai', tipo: 'gemini', imagem: true }), P('c-b', 'key-b')]); await router()
  const base = [{ role: 'system' as const, content: 'Você é o assistente.' }, { role: 'user' as const, content: 'crie uma tarefa agora' }]
  const r1 = await eng.run(base, { tools: TOOLS }); assert(r1.provider.id === 'gemini' && r1.message.tool_calls?.[0].function.name === 'create_task', JSON.stringify(r1.attempts))
  assert(gm.body.systemInstruction && !/additionalProperties/.test(JSON.stringify(gm.body)), 'esquema/sistema incorretos')
  const r2 = await eng.run([...base, { role: 'assistant', content: null, tool_calls: r1.message.tool_calls }, { role: 'tool', tool_call_id: r1.message.tool_calls![0].id, content: '{"ok":true}' }], { tools: TOOLS })
  assert(r2.provider.id === 'gemini' && r2.message.content === 'Feito pelo Gemini!', JSON.stringify(r2.attempts))
  gm.mode = 'safety'; assert((await eng.run(msgs('oi'))).provider.id === 'c-b', 'bloqueio não acionou fallback')
  gm.mode = 'malformed'; assert((await eng.run(msgs('oi'))).provider.id === 'c-b', 'chamada malformada não acionou fallback')
  gm.mode = 'ok'; await prov([P('gemini', 'CHAVE-RUIM', { tipo: 'gemini' }), P('c-b', 'key-b')])
  assert((await eng.run(msgs('oi'))).provider.id === 'c-b', 'sem fallback')
  const b = ((await H.runtime()) as any).breakers.gemini; assert(b.hard && b.kind === 'auth', 'chave inválida (400) do Gemini não foi reconhecida: ' + JSON.stringify(b))
})
await test('Claude (Anthropic) nativo: texto, ferramentas e leitura de imagem/PDF', async () => {
  await prov([P('anthropic', 'AKEY', { url: anUrl, tipo: 'anthropic', imagem: true })]); await router()
  const sys = [{ role: 'system' as const, content: 'Sistema' }, { role: 'user' as const, content: 'use registrar_codigo' }]
  const r1 = await eng.run(sys, { tools: [{ type: 'function', function: { name: 'registrar_codigo', description: 'x', parameters: { type: 'object', properties: { codigo: { type: 'string' } }, required: ['codigo'] } } }] })
  assert(r1.message.tool_calls?.[0].function.name === 'registrar_codigo', JSON.stringify(r1.message))
  const r2 = await eng.run([...sys, { role: 'assistant', content: null, tool_calls: r1.message.tool_calls }, { role: 'tool', tool_call_id: r1.message.tool_calls![0].id, content: '{"ok":true}' }], { tools: [{ type: 'function', function: { name: 'registrar_codigo', description: 'x', parameters: { type: 'object', properties: {} } } }] })
  assert(r2.message.content === 'Feito pelo Claude!', JSON.stringify(r2.message))
  const img = await eng.askFiles('leia', [{ mime: 'image/png', data: 'AAAA' }]); assert(img === '4821', img)
})
await test('teste real do provedor: valida texto, ferramentas, imagem, PDF, áudio, código e pesquisa; reprovação pesa no roteamento', async () => {
  await prov([P('gemini', 'GKEY', { tipo: 'gemini', imagem: true }), P('anthropic', 'AKEY', { url: anUrl, tipo: 'anthropic', imagem: true })]); await router()
  const provs = (await (await import('../src/ai/registry.js')).loadProviders())
  const g = await eng.testProvider(provs.find((p) => p.id === 'gemini')!); assert(g.ok && g.checks.length === 7, JSON.stringify(g.checks))
  gm.vision = 'não sei'
  const g2 = await eng.testProvider(provs.find((p) => p.id === 'gemini')!); assert(!g2.ok && /Imagens/.test(g2.message) && g2.checks.find((c) => c.cap === 'imagem')!.ok === false, g2.message)
  const r = await eng.run([{ role: 'user', content: 'leia', files: [{ mime: 'image/png', data: 'AAAA' }] }]); assert(r.provider.id === 'anthropic', 'IA reprovada em imagens ainda foi escolhida: ' + r.provider.id)
  gm.vision = '4821'; await eng.testProvider(provs.find((p) => p.id === 'gemini')!)
})
await test('orquestração: a tarefa decide a IA (imagem → Gemini, programação → Claude)', async () => {
  await prov([P('gemini', 'GKEY', { tipo: 'gemini', imagem: true }), P('anthropic', 'AKEY', { url: anUrl, tipo: 'anthropic', imagem: true })]); await router({ modo: 'equilibrado' })
  const img = await eng.run([{ role: 'user', content: 'leia', files: [{ mime: 'image/png', data: 'AAAA' }] }]); assert(img.provider.id === 'gemini' && img.task === 'imagem', img.provider.id)
  const cod = await eng.run(msgs('escreva uma função em python que some dois números')); assert(cod.task === 'codigo' && cod.provider.id === 'anthropic', cod.provider.id)
  assert(eng.classifyTask(msgs('oi, tudo bem?')) === 'conversa' && eng.classifyTask(msgs('pesquise as últimas notícias')) === 'pesquisa', 'classificação')
})
await test('uso combinado: consulta paralela compara as respostas e a IA juíza escolhe a melhor', async () => {
  process.env.GEMINI_API_BASE = prevGem
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); await router({ modo: 'equilibrado', paralelo: { ativo: true, modo: 'comparar', max: 2, tarefas: ['analise'] } })
  const r = await eng.run(msgs('analise as vendas do mês'), { task: 'analise' })
  assert(r.compared && r.compared.ids.length === 2 && r.provider.id === 'c-b' && /MELHOR/.test(r.message.content!), JSON.stringify(r.compared))
  const st = await H.loadStats(); assert(st['c-a'].uses === 1 && st['c-b'].uses === 1 && st['c-b'].wins === 1, 'consumo/vitórias não registrados')
  await router({ paralelo: { ativo: true, modo: 'corrida', max: 2, tarefas: ['analise'] } })
  const c = await eng.run(msgs('analise as vendas'), { task: 'analise' }); assert(!!c.message.content, 'corrida sem resposta')
  const t = await eng.run(msgs('crie uma tarefa x'), { tools: TOOLS, task: 'analise' }); assert(!t.compared, 'consulta paralela nunca deve ocorrer com ferramentas (efeitos colaterais)')
})
const taskCount = async (t: string) => Number((await d.query("SELECT COUNT(*) AS n FROM items WHERE type = 'task' AND json_extract(data, '$.title') = $1", [t]))[0].n)
await test('execução única: fallback depois da ferramenta não duplica lançamentos nem perde o registro', async () => {
  await router({ tentativas: 0 })
  const chat = (text: string, cv: string) => cliente.post('/api/chat', { text, conversationId: cv })
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); beh.a = 'tool-once'; beh.b = 'plain-tool'
  let r = await chat('crie uma tarefa cenario1', 'eeeeeeee-0000-4000-8000-000000000001'); assert(r.status === 200 && /Tarefa criada/.test(r.body.assistantMessage.content), JSON.stringify(r.body).slice(0, 300))
  assert(await taskCount('crie uma tarefa cenario1') === 1, 'duplicou no cenário 1')
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); beh.a = 'tool-once'; beh.b = 'dup-tool'
  r = await chat('crie uma tarefa cenario2', 'eeeeeeee-0000-4000-8000-000000000002'); assert(r.status === 200, JSON.stringify(r.body).slice(0, 300))
  assert(await taskCount('crie uma tarefa cenario2') === 1, 'IA que assumiu repetiu a chamada e duplicou')
  await prov([P('c-a', 'key-a'), P('c-b', 'key-b')]); beh.a = 'tool-once'; beh.b = '500'
  r = await chat('crie uma tarefa cenario3', 'eeeeeeee-0000-4000-8000-000000000003'); assert(r.status === 200 && /^Pronto! Já fiz/.test(r.body.assistantMessage.content), JSON.stringify(r.body).slice(0, 300))
  assert(await taskCount('crie uma tarefa cenario3') === 1, 'duplicou no cenário 3')
  await prov([P('c-a', 'key-a')]); beh.a = 'ok-slow'; hits.a = 0
  const [x, y] = await Promise.all([chat('olá, tudo bem por aí?', 'eeeeeeee-0000-4000-8000-000000000004'), chat('olá, tudo bem por aí?', 'eeeeeeee-0000-4000-8000-000000000004')])
  assert(x.status === 200 && y.status === 200 && x.body.assistantMessage.id === y.body.assistantMessage.id && hits.a === 1, `resposta duplicada (${hits.a} chamadas)`)
})
await test('chat funciona só com IA do painel (sem IA no .env): o Gemini "pronto" agora responde de verdade', async () => {
  process.env.GEMINI_API_BASE = gmUrl
  const saved = { ...config.ai }; config.ai.apiKey = ''; config.ai.baseUrl = 'https://api.openai.com/v1'
  try {
    await prov([P('gemini', 'GKEY', { tipo: 'gemini', imagem: true })]); await router(); gm.mode = 'ok'
    const r = await cliente.post('/api/chat', { text: 'crie uma tarefa so-gemini', conversationId: 'eeeeeeee-0000-4000-8000-000000000005' })
    assert(r.status === 200 && /Feito pelo Gemini/.test(r.body.assistantMessage.content), JSON.stringify(r.body).slice(0, 300))
    assert(await taskCount('crie uma tarefa so-gemini') === 1, 'tarefa não gravada')
  } finally { Object.assign(config.ai, saved); process.env.GEMINI_API_BASE = prevGem }
})
await test('painel: estatísticas, capacidades, ajustes do motor e teste real pela API', async () => {
  process.env.GEMINI_API_BASE = gmUrl
  try {
    await prov([P('gemini', 'GKEY', { tipo: 'gemini', imagem: true }), P('c-a', 'key-a')]); await router()
    await eng.run(msgs('oi'))
    const g = await admin.get('/api/panel'); const gp = g.body.ai_providers.find((p: any) => p.id === 'gemini')
    assert(gp.tipo === 'gemini' && gp.caps.pesquisa === true && gp.hasKey && g.body.ai_runtime.stats.gemini.tokensIn > 0 && g.body.ai_router.modo, JSON.stringify(gp).slice(0, 300))
    assert(g.body.ai_providers.some((p: any) => p.id === 'anthropic') && g.body.ai_providers.some((p: any) => p.id === 'openai'), 'novas IAs padrão não apareceram em instalação existente')
    const rr = await admin.call('PUT', '/api/panel/ai_router', { modo: 'qualidade', timeoutMs: 999999, paralelo: { ativo: true, modo: 'corrida', tarefas: ['analise', 'xyz'] } })
    assert(rr.body.ai_router.modo === 'qualidade' && rr.body.ai_router.timeoutMs === 120000 && rr.body.ai_router.paralelo.tarefas.join() === 'analise', JSON.stringify(rr.body.ai_router))
    const t = await admin.post('/api/panel/test', { kind: 'ai', id: 'gemini', caps: ['texto', 'ferramentas'] }); assert(t.body.ok && t.body.checks.length === 2, JSON.stringify(t.body))
    const cp = await admin.call('PUT', '/api/panel/ai_providers', { items: [{ id: 'gemini', caps: { audio: false }, tipo: 'gemini' }, { id: 'servidor', ativo: false }] })
    assert(cp.body.ai_providers.find((p: any) => p.id === 'gemini').caps.audio === false, 'capacidade não salva')
  } finally { process.env.GEMINI_API_BASE = prevGem }
})
await setCfg('ai_router', {}); gmSrv.close(); anSrv.close(); mc.close()

gemSrv.close()
await test('excluir anúncio recusado; agente liga/desliga e botão flutuante no catálogo', async () => {
  const pl = (await dono.get('/api/v2/ads/plans')).body.plans.find((p: any) => p.id === 'n1')
  const mine0 = (await dono.get('/api/v2/ads/mine')).body.items
  let rec = mine0.find((x: any) => x.status === 'recusado')
  if (!rec) { const old = mine0.find((x: any) => x.planId === pl.id); if (old) { await admin.post(`/api/v2/admin/ads/${old.id}`, { action: 'reject', motivo: 'Teste' }); rec = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.id === old.id) } }
  const ativo = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.status === 'ativo')
  assert((await dono.call('DELETE', `/api/v2/ads/${ativo.id}`)).status === 400, 'excluiu anúncio que não foi recusado')
  if (rec) { const d = await dono.call('DELETE', `/api/v2/ads/${rec.id}`); assert(d.status === 200 && !d.body.items.some((x: any) => x.id === rec.id), JSON.stringify(d.body).slice(0, 200)) }
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', flutuante: { ativo: true, msg: 'Precisa de ajuda? Me chama!' } })
  const pg = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(pg.body.agente?.msg === 'Precisa de ajuda? Me chama!' && /^\/g-pizzaria-forno$/.test(pg.body.agente.link), JSON.stringify(pg.body.agente))
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', ativo: false })
  assert((await new Client().get(`/api/v2/agent/${ad.id}`)).status === 404 && !(await cliente.get(`/api/v2/businesses/${ad.id}`)).body.agente, 'agente desligado continuou atendendo / botão flutuante não sumiu')
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', ativo: true, flutuante: { ativo: false } }); assert(!(await cliente.get(`/api/v2/businesses/${ad.id}`)).body.agente, 'botão flutuante desativado continuou aparecendo')
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', flutuante: { ativo: true, msg: 'Precisa de ajuda? Me chama!' } })
  await dono.call('PUT', `/api/v2/ads/${ad.id}/agent`, { nome: 'Lia', ativo: true })
  assert((await new Client().get(`/api/v2/agent/${ad.id}`)).status === 200, 'agente não voltou')
})
await test('cada produto aceita uma etiqueta só', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const r = (await dono.call('PUT', `/api/v2/ads/${ad.id}`, { etiquetas: [{ nome: 'Oferta', cor: '#ef4444' }, { nome: 'Destaque', cor: '#f59e0b' }] })).body.items.find((x: any) => x.id === ad.id)
  const [t1, t2] = r.etiquetas; const pid = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items[0].id
  const x = await dono.post(`/api/v2/ads/${ad.id}/products`, { action: 'tags', id: pid, tags: [t1.id, t2.id] }); const p1 = x.body.items.find((p: any) => p.id === pid)
  assert(p1.tags.length === 1 && p1.tags[0] === t2.id, JSON.stringify(p1.tags))
})
await test('agente segue a própria data, independente do anúncio', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const { q } = await import('../src/db/index.js')
  const old = (await q('SELECT expires_at FROM businesses WHERE id = $1', [ad.id]))[0].expires_at
  await q('UPDATE businesses SET expires_at = $1 WHERE id = $2', [new Date(Date.now() - 86400_000).toISOString(), ad.id])
  const info = await dono.get(`/api/v2/ads/${ad.id}/agent`); assert(info.body.ativo === true && info.body.anuncio.noAr === false && info.body.agenteAte, JSON.stringify(info.body).slice(0, 300))
  assert((await new Client().get(`/api/v2/agent/${ad.id}`)).status === 200, 'agente parou junto com o anúncio')
  await q('UPDATE businesses SET expires_at = $1 WHERE id = $2', [old, ad.id])
})
await test('motor: IA lenta não segura a resposta (corrida escalonada) e IA fora do ar cai rápido', async () => {
  const slow = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; setTimeout(() => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'resposta lenta' } }] })) }, 9000) })
  const fast = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'resposta rápida' } }] })) })
  await new Promise<void>((r) => slow.listen(0, '127.0.0.1', r)); await new Promise<void>((r) => fast.listen(0, '127.0.0.1', r))
  const { setConfig, getConfig } = await import('../src/lib/settings.js'); const saved = await getConfig<any[]>('ai_providers', [])
  const P = (id: string, port: number) => ({ id, nome: id, base_url: `http://127.0.0.1:${port}/v1`, modelo: 'm', key: '', tipo: 'openai', caps: { texto: true }, ativo: true })
  await setConfig('ai_providers', [P('lenta', (slow.address() as any).port), P('rapida', (fast.address() as any).port), P('fora', 1)])
  const { run } = await import('../src/ai/engine.js')
  const t0 = Date.now(); const r = await run([{ role: 'user', content: 'oi' }], { parallel: 'off' })
  const ms = Date.now() - t0
  await setConfig('ai_providers', saved); slow.close(); fast.close()
  assert(r.message.content === 'resposta rápida' && ms < 8000, `respondeu "${r.message.content}" em ${ms} ms`)
})
await test('PDF digital: texto extraído sem IA com visão (alternativa para qualquer IA de texto)', async () => {
  const { pdfText } = await import('../src/ai/docs.js'); const { deflateSync } = await import('node:zlib')
  const st = deflateSync(Buffer.from('BT /F1 12 Tf 20 700 Td (Comprovante Pix) Tj T* (Valor: R$ 55,00) Tj T* [(Para) -300 (Maria)] TJ ET'))
  const pdf = Buffer.concat([Buffer.from(`%PDF-1.4\n1 0 obj\n<< /Length ${st.length} /Filter /FlateDecode >>\nstream\n`), st, Buffer.from('\nendstream\nendobj\n%%EOF')])
  const t = pdfText(pdf); assert(/Comprovante Pix/.test(t) && /R\$ 55,00/.test(t) && /Para Maria/.test(t), JSON.stringify(t))
})
await test('serviço sob orçamento com sinal: cálculo, agendamento com Pix do sinal e restante', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const bad = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Evento', tipo: 'servico', modoPreco: 'orcamento', preco: 0, duracao: 60, sinal: { ativo: true, tipo: 'pct', valor: 30 } }); assert(bad.status === 400, 'aceitou % sem valor de referência')
  const r = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Buffet para festa', tipo: 'servico', modoPreco: 'orcamento', preco: 200, duracao: 60, sinal: { ativo: true, tipo: 'pct', valor: 30 } })
  const sv = r.body.items.find((p: any) => p.nome === 'Buffet para festa'); assert(sv.sinal?.tipo === 'pct' && sv.sinal.valor === 30, JSON.stringify(sv))
  const semSinal = (await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Orçamento livre', tipo: 'servico', modoPreco: 'orcamento', preco: 0, duracao: 60, sinal: { ativo: false } })).body.items.find((p: any) => p.nome === 'Orçamento livre'); assert(!semSinal.sinal, 'gravou sinal desativado')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'auto', dias: Object.fromEntries(['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'].map((d) => [d, { ativo: true, abre: '08:00', fecha: '20:00' }])) } })
  const d = new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10)
  const sl = await cliente.get(`/api/v2/businesses/${ad.id}/slots?servico=${sv.id}&data=${d}`); const hora = (sl.body.horarios || sl.body.slots || [])[0]
  const bk = await cliente.post(`/api/v2/businesses/${ad.id}/bookings`, { servico: sv.id, data: d, hora })
  assert(bk.status === 200 && bk.body.order.total === 60 && bk.body.order.sinal === 60 && bk.body.order.restante === 140 && /Sinal de R\$ 60,00/.test(bk.body.order.condicoes), JSON.stringify(bk.body).slice(0, 400))
  const r2 = await dono.post(`/api/v2/ads/${ad.id}/products`, { id: sv.id, nome: 'Buffet para festa', tipo: 'servico', modoPreco: 'orcamento', preco: 0, duracao: 60, sinal: { ativo: true, tipo: 'fixo', valor: 50 } })
  assert(r2.body.items.find((p: any) => p.id === sv.id).sinal.valor === 50, 'sinal fixo')
  const fx = await dono.post(`/api/v2/ads/${ad.id}/products`, { nome: 'Fixo caro', tipo: 'servico', modoPreco: 'orcamento', preco: 40, duracao: 60, sinal: { ativo: true, tipo: 'fixo', valor: 50 } }); assert(fx.status === 400, 'sinal maior que a referência')
})
await test('uma contratação por modalidade: bloqueia só a contratada, trava simultânea e libera ao vencer', async () => {
  const c = new Client(); await c.post('/api/auth', { action: 'signup', name: 'Dona Loja', whatsapp: '+55 11 95555-1234', email: 'dona@t.com', birthday: '1985-01-01', password: 'Senha@Forte123', passwordConfirm: 'Senha@Forte123' })
  const base = { empresa: 'Doces da Ana', categoria: 'Doceria', titulo: 'Doces', zap: '5511955551234' }
  const [a1, a2] = await Promise.all([c.post('/api/v2/ads', { ...base, planId: 'n1' }), c.post('/api/v2/ads', { ...base, planId: 'n1' })])
  const ok = [a1, a2].filter((r) => r.status === 200).length; assert(ok === 1, `duplicou contratação simultânea: ${a1.status} ${a2.status}`)
  const pl = await c.get('/api/v2/ads/plans'); assert(pl.body.contratadas.n1 && Object.keys(pl.body.contratadas).length === 1, JSON.stringify(pl.body.contratadas))
  const p2 = pl.body.plans.find((x: any) => x.id !== 'n1').id; assert(!pl.body.contratadas[p2], 'outra já ocupada')
  const other = await c.post('/api/v2/ads', { ...base, planId: p2, insta: 'docesdaana' }); assert(other.status === 200, 'bloqueou outra modalidade: ' + JSON.stringify(other.body))
  const again = await c.post('/api/v2/ads', { ...base, planId: 'n1' }); assert(again.status === 409 && again.body.code === 'plan_taken', JSON.stringify(again.body))
  const { q } = await import('../src/db/index.js'); const id = pl.body.contratadas.n1.id
  await q("UPDATE businesses SET status = 'ativo', expires_at = $1 WHERE id = $2", [new Date(Date.now() - 86400_000).toISOString(), id])
  const pl2 = await c.get('/api/v2/ads/plans'); assert(!pl2.body.contratadas.n1, 'vencido continuou ocupando')
  assert((await c.post('/api/v2/ads', { ...base, planId: 'n1' })).status === 200, 'não liberou após vencer')
})
await test('conversas: saudação imediata, envio persistente (sai da tela e recupera), sem duplicar e com texto em tempo real', async () => {
  const cv = '41414141-2222-4333-8444-555555555555', before = aiCalls
  const g = await cliente.post('/api/chat', { text: 'Olá', conversationId: cv }); assert(/^(Bom dia|Boa tarde|Boa noite)/.test(g.body.assistantMessage.content) && aiCalls === before, g.body.assistantMessage?.content)
  // envio com id: repetir o mesmo pedido devolve a mesma resposta, sem nova mensagem
  const H = (id: string) => ({ Cookie: `ma_session=${cliente.jar.get('ma_session')}`, 'Content-Type': 'application/json', Origin: `http://127.0.0.1:${port}`, 'X-Chat-Job': id })
  const id1 = 'job' + Date.now().toString(36) + 'aa'
  const r1 = await (await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: H(id1), body: JSON.stringify({ text: 'gastei 12 reais no café', conversationId: cv }) })).json()
  const n1 = (await cliente.get(`/api/chat?c=${cv}`)).body.messages.length
  const r2 = await (await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: H(id1), body: JSON.stringify({ text: 'gastei 12 reais no café', conversationId: cv }) })).json()
  assert(r2.assistantMessage.id === r1.assistantMessage.id && (await cliente.get(`/api/chat?c=${cv}`)).body.messages.length === n1, 'repetição gerou outra resposta')
  // saiu da tela no meio: a conexão cai, o servidor termina e a resposta é recuperada pelo id
  const slow = createServer(async (req, res) => { for await (const _ of req) {} setTimeout(() => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'Resposta pronta depois que você saiu.' } }] })) }, 1500) })
  const streamer = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; res.writeHead(200, { 'Content-Type': 'text/event-stream' }); const parts = ['A capital ', 'da França ', 'é Paris.']; let i = 0; const tick = setInterval(() => { if (i < parts.length) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: parts[i++] } }] })}\n\n`); else { res.write(`data: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`); clearInterval(tick); res.end() } }, 300) })
  await new Promise<void>((r) => slow.listen(0, '127.0.0.1', r)); await new Promise<void>((r) => streamer.listen(0, '127.0.0.1', r))
  const { setConfig, getConfig } = await import('../src/lib/settings.js'); const saved = await getConfig<any[]>('ai_providers', [])
  const P = (id: string, srv: any) => ({ id, nome: id, base_url: `http://127.0.0.1:${(srv.address() as any).port}/v1`, modelo: 'm', key: '', tipo: 'openai', caps: { texto: true, ferramentas: true }, ativo: true })
  try {
    await setConfig('ai_providers', [P('lenta2', slow)])
    const id2 = 'job' + Date.now().toString(36) + 'bb', ctl = new AbortController()
    const pr = fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: H(id2), body: JSON.stringify({ text: 'me explique a fotossíntese em uma frase', conversationId: cv }), signal: ctl.signal }).catch(() => null)
    await new Promise((r) => setTimeout(r, 300)); ctl.abort(); await pr
    let st: any = { status: 'pending' }; for (let k = 0; k < 30 && st.status === 'pending'; k++) { await new Promise((r) => setTimeout(r, 200)); st = (await cliente.get(`/api/v2/chat/jobs/${id2}`)).body }
    assert(st.status === 'done' && /depois que você saiu/.test(st.result.assistantMessage.content), JSON.stringify(st).slice(0, 300))
    assert((await cliente.get(`/api/chat?c=${cv}`)).body.messages.some((m: any) => /depois que você saiu/.test(m.content)), 'resposta não ficou salva na conversa')
    // streaming: os pedaços chegam antes da resposta final
    await setConfig('ai_providers', [P('stream', streamer)])
    const id3 = 'job' + Date.now().toString(36) + 'cc'
    const post = fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: H(id3), body: JSON.stringify({ text: 'qual a capital da frança e por quê é famosa', conversationId: cv }) }).then((r) => r.json())
    await new Promise((r) => setTimeout(r, 150))
    const sr = await fetch(`http://127.0.0.1:${port}/api/v2/chat/jobs/${id3}/stream`, { headers: H(id3) }); const reader = sr.body!.getReader(); let raw = '', firstAt = 0; const t0 = Date.now()
    for (;;) { const { value, done } = await reader.read(); if (done) break; const chunk = new TextDecoder().decode(value); if (!firstAt && /event: delta/.test(chunk)) firstAt = Date.now() - t0; raw += chunk; if (/event: (done|error)/.test(raw)) break }
    const final = await post
    const deltas = [...raw.matchAll(/event: delta\ndata: (.*)\n/g)].map((m) => JSON.parse(m[1])).join('')
    assert(deltas.includes('Paris') && final.assistantMessage.content.includes('Paris') && firstAt > 0 && firstAt < 900, `stream: "${deltas}" primeiro pedaço em ${firstAt} ms`)
  } finally { await setConfig('ai_providers', saved); slow.close(); streamer.close() }
})
await test('painel: estatísticas do Cérebro e modelos do Ollama respondem sem erro', async () => {
  const b = await admin.get('/api/panel/brain/answers'); assert(b.status === 200 && b.body.stats && typeof b.body.stats.total === 'number' && Array.isArray(b.body.top), JSON.stringify(b.body).slice(0, 300))
  const o = await admin.get('/api/panel/ollama-models'); assert(o.status === 200 && Array.isArray(o.body.models), JSON.stringify(o.body))
})
await test('Gemini: modelo mantido, novas tentativas em 503/429, sem repetir chave inválida, troca para outra IA e registros sem chave', async () => {
  let calls = 0, mode = 'flaky', lastUrl = '', lastKey = ''
  const gem = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; calls++; lastUrl = req.url || ''; lastKey = String(req.headers['x-goog-api-key'] || '')
    if (mode === 'flaky' && calls <= 2) { res.writeHead(calls === 1 ? 503 : 429, { 'Content-Type': 'application/json', ...(calls === 2 ? { 'Retry-After': '1' } : {}) }); return res.end(JSON.stringify({ error: { code: calls === 1 ? 503 : 429, message: 'The model is overloaded', status: calls === 1 ? 'UNAVAILABLE' : 'RESOURCE_EXHAUSTED' } })) }
    if (mode === 'badkey') { res.writeHead(400, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: { code: 400, message: 'API key not valid. Please pass a valid API key.', status: 'INVALID_ARGUMENT' } })) }
    res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ candidates: [{ content: { role: 'model', parts: [{ text: 'Olá do Gemini' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 3, candidatesTokenCount: 4 } })) })
  const other = createServer(async (req, res) => { for await (const _ of req) {} res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'Olá da outra IA' } }] })) })
  for (const x of [gem, other]) await new Promise<void>((r) => x.listen(0, '127.0.0.1', r))
  const { setConfig, getConfig, seal } = await import('../src/lib/settings.js'); const saved = await getConfig<any[]>('ai_providers', [])
  const KEY = 'AIzaSyTESTE_SECRETA_1234567890abcdef'
  const logs: string[] = []; const ol = console.log, oe = console.error; console.log = (...a: any[]) => { logs.push(a.join(' ')); }; console.error = (...a: any[]) => { logs.push(a.join(' ')) }
  process.env.GEMINI_API_BASE = `http://127.0.0.1:${(gem.address() as any).port}`
  try {
    await setConfig('ai_providers', [{ id: 'gemini', tipo: 'gemini', nome: 'Google Gemini', base_url: 'https://generativelanguage.googleapis.com', modelo: 'gemini-3.8-flash', key: await seal(KEY), caps: { texto: true }, texto: true, ativo: true, timeoutS: 40, retries: 2 },
      { id: 'c-outra', tipo: 'openai', nome: 'Outra IA', base_url: `http://127.0.0.1:${(other.address() as any).port}/v1`, modelo: 'm', key: await seal('k2'), caps: { texto: true }, texto: true, ativo: true }])
    const { run } = await import('../src/ai/engine.js')
    const r1 = await run([{ role: 'user', content: 'oi' }], { parallel: 'off' })
    assert(r1.message.content === 'Olá do Gemini' && calls === 3 && /models\/gemini-3\.8-flash:generateContent/.test(lastUrl) && lastKey === KEY, `retentativas: ${calls} chamadas, ${r1.message.content}, ${lastUrl}`)
    mode = 'badkey'; calls = 0
    const r2 = await run([{ role: 'user', content: 'oi de novo' }], { parallel: 'off' })
    assert(r2.message.content === 'Olá da outra IA' && calls === 1, `chave inválida: ${calls} chamadas ao Gemini, resposta "${r2.message.content}"`)
    const all = logs.join('\n')
    assert(/provedor=gemini modelo=gemini-3\.8-flash .*status=503/.test(all) && /status=429/.test(all) && /status=200/.test(all) && !all.includes(KEY), 'registros: ' + all.split('\n').filter((l) => /\[ai\]/.test(l)).slice(0, 6).join(' | '))
  } finally { console.log = ol; console.error = oe; await setConfig('ai_providers', saved); gem.close(); other.close() }
})
await test('módulos: catálogo completo, visibilidade só no menu e cartão do módulo no chat', async () => {
  const { moduleIntent, MOD_CATALOG } = await import('../src/lib/modcatalog.js')
  assert(MOD_CATALOG.length >= 20 && moduleIntent('anúncios')?.key === 'anuncios' && moduleIntent('abrir finanças')?.key === 'financas' && moduleIntent('minha loja')?.key === 'suaempresa' && moduleIntent('meus pedidos')?.key === 'pedidos' && moduleIntent('configurações')?.key === 'configuracoes' && moduleIntent('lembretes')?.key === 'lembretes' && moduleIntent('arquivos')?.key === 'arquivos', 'reconhecimento')
  assert(moduleIntent('gastei 30 no mercado') === null && moduleIntent('como funciona o mercado de ações hoje no brasil e no mundo') === null, 'confundiu frase com módulo')
  const cv = '51515151-2222-4333-8444-555555555555', before = aiCalls
  const r = await cliente.post('/api/chat', { text: 'anúncios', conversationId: cv }); assert(r.status === 200, 'anúncios: ' + r.status + JSON.stringify(r.body)); assert(/⟦mod:anuncios⟧/.test(r.body.assistantMessage.content) && aiCalls === before, r.body.assistantMessage.content)
  const v = await admin.call('PUT', '/api/panel/mod_visible', { treinos: false, mercado: false }); assert(v.body.mod_visible.treinos === false && v.body.mod_catalog.length >= 20, JSON.stringify(v.body.mod_visible))
  const pub = await cliente.get('/api/panel/public'); assert(pub.body.mod_visible.mercado === false && pub.body.modules.mercado !== false, 'ocultar no menu desligou a função')
  const m = await cliente.post('/api/chat', { text: 'mercado', conversationId: cv }); assert(/⟦mod:mercado⟧/.test(m.body.assistantMessage.content), 'módulo oculto no menu deve continuar no chat')
  await admin.call('PUT', '/api/panel/mod_visible', {})
})
await test('atendente da loja: catálogo real numa conversa com IA (sem contradição) e pedido', async () => {
  let n = 0
  const ia = createServer(async (req, res) => { let b = ''; for await (const c of req) b += c; const j = JSON.parse(b || '{}'); n++
    const hasTool = (j.messages || []).some((m: any) => m.role === 'tool')
    const msg = !hasTool ? { role: 'assistant', content: 'Claro! Vou te mostrar o catálogo.', tool_calls: [{ id: 'c1', type: 'function', function: { name: 'mostrar_catalogo', arguments: JSON.stringify({ categoria: 'cardápio completo' }) } }] } : { role: 'assistant', content: 'Desculpe, não temos produtos disponíveis no momento.' }
    res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: msg, finish_reason: 'stop' }] })) })
  await new Promise<void>((r) => ia.listen(0, '127.0.0.1', r))
  const { setConfig, getConfig } = await import('../src/lib/settings.js'); const saved = await getConfig<any[]>('ai_providers', [])
  try {
    await setConfig('ai_providers', [{ id: 'c-agente', tipo: 'openai', nome: 'IA teste', base_url: `http://127.0.0.1:${(ia.address() as any).port}/v1`, modelo: 'm', key: '', caps: { texto: true, ferramentas: true }, texto: true, ativo: true }])
    const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
    await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } }) // o teste não depende da hora do dia
    const pub = new Client()
    const r = await pub.post(`/api/v2/agent/${ad.id}/chat`, { messages: [{ role: 'user', content: 'quais sabores de pizza vocês têm hoje para entrega?' }] })
    assert(r.status === 200 && r.body.produtos?.length > 0 && !/não temos produtos/i.test(r.body.reply), JSON.stringify(r.body).slice(0, 400))
    const info = await pub.get(`/api/v2/agent/${ad.id}/info`); const prod = info.body.produtos.find((p: any) => p.tipo !== 'servico')
    assert(r.body.produtos.every((p: any) => info.body.produtos.some((q: any) => q.id === p.id)), 'mostrou produto que não existe na loja')
    const o = await pub.post(`/api/v2/agent/${ad.id}/order`, { itens: [{ produto_id: prod.id, quantidade: 1, opcoes: {} }], modo: 'retirada', pagamento: 'dinheiro', nome: 'Carla', telefone: '11 96666-2222' }); assert(o.status === 200 && o.body.pedido, JSON.stringify(o.body))
  } finally { await setConfig('ai_providers', saved); ia.close() }
})
await test('palavras-chave na busca, horário sempre atualizado, menu padrão/pasta, módulos fixados e opções de resposta', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { palavras: 'forno a lenha, rodízio, esfiha', horarioCfg: { modo: 'auto', dias: { seg: { ativo: true, abre: '09:00', fecha: '17:00' }, ter: { ativo: false } } } })
  const mine = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.id === ad.id)
  assert(/Seg 09:00–17:00/.test(mine.horario) && !/Ter/.test(mine.horario), 'texto do horário não acompanhou: ' + mine.horario)
  const { searchBusinesses } = await import('../src/routes/businesses.js')
  assert((await searchBusinesses('esfiha', null)).some((b: any) => b.id === ad.id), 'palavra-chave da empresa não encontrou')
  const prods = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items; const p0 = prods.find((p: any) => p.tipo !== 'servico')
  await dono.post(`/api/v2/ads/${ad.id}/products`, { ...p0, id: p0.id, palavras: 'borda recheada, quatro queijos' })
  assert((await searchBusinesses('quatro queijos', null)).some((b: any) => b.id === ad.id), 'palavra-chave do produto não encontrou')
  const ml = await admin.call('PUT', '/api/panel/menu_layout', { treinos: 'menu', mercado: 'pasta', eleicoes: 'oculto' }); assert(ml.body.menu_layout.treinos === 'menu' && ml.body.mod_visible.eleicoes === false, JSON.stringify(ml.body.menu_layout))
  const pin = await cliente.call('PUT', '/api/v2/me/menu-pins', { pins: ['mercado', 'inexistente'] }); assert(JSON.stringify(pin.body.pins) === '["mercado"]', JSON.stringify(pin.body))
  assert((await cliente.get('/api/v2/me/menu-pins')).body.pins[0] === 'mercado', 'fixado não ficou salvo')
  const rm = await admin.call('PUT', '/api/panel/resp_modes', { text: false, text_audio: false, audio: true }); assert(rm.body.resp_modes.text === true && rm.body.resp_modes.text_audio === false, JSON.stringify(rm.body.resp_modes))
  assert((await cliente.get('/api/panel/public')).body.resp_modes.text_audio === false, 'opção de resposta não chegou ao app')
  await admin.call('PUT', '/api/panel/menu_layout', {}); await admin.call('PUT', '/api/panel/resp_modes', {})
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
})
await test('avaliações reais, identidade do CEO sem IA e resumo das finanças', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  await dono.call('PUT', `/api/v2/ads/${ad.id}`, { horarioCfg: { modo: 'aberto', dias: {} } })
  const prod = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items.find((p: any) => p.tipo !== 'servico')
  const o = await cliente.post(`/api/v2/businesses/${ad.id}/orders`, { itens: [{ pid: prod.id, qtd: 1, escolhas: {} }], modo: 'retirada', pagamento: 'dinheiro' }); const oid = o.body.order.id
  assert((await cliente.post(`/api/v2/orders/${oid}/review`, { rating: 5 })).status === 400, 'avaliou antes de concluir')
  for (const st of ['aceito', 'preparo', 'pronto', 'concluido']) await dono.post(`/api/v2/ads/${ad.id}/orders/${oid}`, { status: st })
  const r1 = await cliente.post(`/api/v2/orders/${oid}/review`, { rating: 4, comment: 'Muito boa' }); assert(r1.status === 200 && r1.body.avaliacao.count >= 1, JSON.stringify(r1.body))
  assert((await cliente.post(`/api/v2/orders/${oid}/review`, { rating: 5 })).status === 409, 'avaliou duas vezes o mesmo pedido')
  const ar = await admin.call('PUT', `/api/v2/admin/ratings/${ad.id}`, { rating: 5 }); assert(ar.body.avaliacao.count === r1.body.avaliacao.count + 1, JSON.stringify(ar.body))
  const card = (await cliente.get(`/api/v2/businesses/cards?ids=${ad.id}`)).body.items[0]; assert(card.avaliacao && card.avaliacao.avg >= 4 && card.avaliacao.count === ar.body.avaliacao.count, JSON.stringify(card.avaliacao))
  const cv = '61616161-2222-4333-8444-555555555555', before = aiCalls
  const q1 = await cliente.post('/api/chat', { text: 'quem criou você?', conversationId: cv }); assert(/Wesley Ivaslovck/.test(q1.body.assistantMessage.content) && aiCalls === before, q1.body.assistantMessage.content)
  const q2 = await cliente.post('/api/chat', { text: 'quem é Wesley Ivaslovck?', conversationId: cv }); assert(/tatuador/.test(q2.body.assistantMessage.content) && aiCalls === before, 'apresentação completa')
  await admin.call('PUT', '/api/panel/ceo_identity', { nome: 'Wesley Ivaslovck', cargo: 'CEO', texto: 'Wesley Ivaslovck é o CEO e criador do Meu Assistente. Texto editado no painel.' })
  const q3 = await cliente.post('/api/chat', { text: 'quem é o ceo?', conversationId: cv }); assert(/editado no painel/.test(q3.body.assistantMessage.content), 'texto editado não foi usado: ' + q3.body.assistantMessage.content)
  const f1 = await cliente.post('/api/chat', { text: 'Me mostre resultados das finanças', conversationId: cv }); assert(/entradas R\$/.test(f1.body.assistantMessage.content) && /⟦mod:financas⟧/.test(f1.body.assistantMessage.content) && aiCalls === before, f1.body.assistantMessage.content)
  await admin.call('PUT', '/api/panel/ceo_identity', {})
})
await test('etiquetas: sem duplicadas, tipo respeitado, uma por produto e a mesma etiqueta em vários produtos', async () => {
  const ad = (await dono.get('/api/v2/ads/mine')).body.items.find((x: any) => x.empresa === 'Pizzaria Forno')
  const r = (await dono.call('PUT', `/api/v2/ads/${ad.id}`, { etiquetas: [{ nome: 'Oferta', cor: '#ef4444' }, { nome: 'oferta', cor: '#000000' }, { nome: 'Só serviço', cor: '#22c55e', tipo: 'servico' }, { nome: 'Destaque', cor: '#f59e0b' }] })).body.items.find((x: any) => x.id === ad.id)
  assert(r.etiquetas.length === 3, 'aceitou etiqueta duplicada: ' + JSON.stringify(r.etiquetas.map((e: any) => e.nome)))
  const [of, sv, de] = r.etiquetas; const prods = (await dono.get(`/api/v2/ads/${ad.id}/products`)).body.items.filter((p: any) => p.tipo !== 'servico')
  const a1 = (await dono.post(`/api/v2/ads/${ad.id}/products`, { action: 'tags', id: prods[0].id, tags: [sv.id] })).body.items.find((p: any) => p.id === prods[0].id); assert(!a1.tags.length, 'etiqueta de serviço entrou num produto')
  await dono.post(`/api/v2/ads/${ad.id}/products`, { action: 'tags', id: prods[0].id, tags: [of.id] })
  const a2 = (await dono.post(`/api/v2/ads/${ad.id}/products`, { action: 'tags', id: prods[0].id, tags: [de.id] })).body.items.find((p: any) => p.id === prods[0].id); assert(JSON.stringify(a2.tags) === JSON.stringify([de.id]), 'não substituiu a etiqueta anterior')
  if (prods[1]) { const a3 = (await dono.post(`/api/v2/ads/${ad.id}/products`, { action: 'tags', id: prods[1].id, tags: [de.id] })).body.items; assert(a3.filter((p: any) => (p.tags || []).includes(de.id)).length >= 2, 'mesma etiqueta não pôde ir em vários produtos') }
  const pub = await cliente.get(`/api/v2/businesses/${ad.id}`); assert(pub.body.produtos.find((p: any) => p.id === prods[0].id).tags[0] === de.id, 'catálogo não reflete a etiqueta salva')
})
await test('áudio: Whisper local transcreve em pt-BR e o texto segue para o motor (dois formatos de API e reserva)', async () => {
  let mode = 'openai', hits: string[] = []
  const wh = createServer(async (req, res) => { const ch: Buffer[] = []; for await (const c of req) ch.push(c as Buffer); const body = Buffer.concat(ch).toString('latin1'); hits.push(req.url || '')
    if (req.url!.startsWith('/v1/audio/transcriptions')) { if (mode !== 'openai') { res.writeHead(404); return res.end() } assert(/name="language"\r\n\r\npt/.test(body), 'idioma não enviado'); res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ text: ' gastei 18 reais na padaria ' })) }
    if (req.url!.startsWith('/asr')) { if (mode !== 'asr') { res.writeHead(500); return res.end() } assert(/language=pt/.test(req.url!) && /name="audio_file"/.test(body), 'formato asr'); res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ text: 'recebi 200 reais de um cliente' })) }
    res.writeHead(404); res.end() })
  await new Promise<void>((r) => wh.listen(0, '127.0.0.1', r))
  process.env.WHISPER_URL = `http://127.0.0.1:${(wh.address() as any).port}`
  const B = 'XyZaudio1', voz = Buffer.from('OggS fake audio')
  const send = async (cv: string) => { const body = Buffer.concat([Buffer.from(`--${B}\r\nContent-Disposition: form-data; name="conversationId"\r\n\r\n${cv}\r\n--${B}\r\nContent-Disposition: form-data; name="durationMs"\r\n\r\n2100\r\n--${B}\r\nContent-Disposition: form-data; name="audio"; filename="voz.webm"\r\nContent-Type: audio/webm\r\n\r\n`), voz, Buffer.from(`\r\n--${B}--\r\n`)]); const r = await fetch(`http://127.0.0.1:${port}/api/chat`, { method: 'POST', headers: { Cookie: `ma_session=${cliente.jar.get('ma_session')}`, 'Content-Type': `multipart/form-data; boundary=${B}`, Origin: `http://127.0.0.1:${port}` }, body }); return { status: r.status, body: await r.json() } }
  try {
    const before = aiCalls
    const a1 = await send('71717171-2222-4333-8444-555555555555')
    assert(a1.status === 200 && a1.body.userMessage.content === 'gastei 18 reais na padaria' && /⟦fin:\d+⟧/.test(a1.body.assistantMessage.content) && aiCalls === before, JSON.stringify(a1.body).slice(0, 300))
    mode = 'asr'
    const a2 = await send('72727272-2222-4333-8444-555555555555')
    assert(a2.status === 200 && a2.body.userMessage.content === 'recebi 200 reais de um cliente' && /⟦fin:\d+⟧/.test(a2.body.assistantMessage.content), JSON.stringify(a2.body).slice(0, 300))
  } finally { delete process.env.WHISPER_URL; wh.close() }
})
await test('domínio oficial e endereços únicos por empresa; lembretes: 24 h + 1 h, lembrete exato e sem códigos internos', async () => {
  const { slugify, pub } = await import('../src/lib/publicurl.js')
  assert(slugify('Pizzaria Bella Nápoli & Cia') === 'pizzaria-bella-napoli-e-cia' && pub() === 'https://meuassistente.chat', 'slug/domínio')
  const { ensureSlug } = await import('../src/routes/businesses.js'); const { q } = await import('../src/db/index.js')
  const rows = await q("SELECT id, data FROM businesses"); const ids = rows.map((r: any) => Number(r.id)).slice(0, 3)
  const slugs = []; for (const id of ids) slugs.push(await ensureSlug(id))
  assert(new Set(slugs).size === slugs.length && slugs.every((x) => /^[a-z0-9-]+$/.test(x) && !/^\d+$/.test(x)), 'slugs repetidos ou inválidos: ' + slugs)
  // dois com o mesmo nome recebem endereços diferentes, sem números aleatórios
  const [a1, a2] = ids; const d1 = JSON.parse((await q('SELECT data FROM businesses WHERE id = $1', [a1]))[0].data), d2 = JSON.parse((await q('SELECT data FROM businesses WHERE id = $1', [a2]))[0].data)
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify({ ...d2, empresa: d1.empresa, slug: undefined, slugBase: undefined }), a2])
  const s2 = await ensureSlug(a2); assert(s2 === `${slugify(d1.empresa)}-2`, 'unicidade: ' + s2)
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(d2), a2])
  assert((await admin.call('PUT', '/api/panel/site', { url: 'https://meuassistente.ivaslovck.tech' })).status === 400, 'aceitou o domínio antigo')
  // compromisso pela frase: 24 h e 1 h antes
  const cv = '91919191-2222-4333-8444-555555555555'
  const r = await cliente.post('/api/chat', { text: 'agendar reunião depois de amanhã às 15:00 com Ana', conversationId: cv })
  assert(/1 dia e 1 hora antes/.test(r.body.assistantMessage.content), r.body.assistantMessage.content)
  const id = Number(r.body.assistantMessage.content.match(/⟦appt:(\d+)⟧/)[1]); const it = (await cliente.get(`/api/v2/item/${id}`)).body
  assert(JSON.stringify(it.reminders) === '[1440,60]', JSON.stringify(it.reminders))
  const row = (await q('SELECT due_at FROM items WHERE id = $1', [id]))[0]; const start = Date.parse(`${it.date}T15:00:00-03:00`)
  assert(Math.abs(Date.parse(row.due_at) - (start - 1440 * 60_000)) < 60_000, 'primeiro aviso não é 24 h antes')
  // agendador: dispara o de 24 h e agenda o de 1 h
  const { tick } = await import('../src/scheduler.js')
  await tick(new Date(start - 1440 * 60_000 + 5000)); const r2 = (await q('SELECT due_at FROM items WHERE id = $1', [id]))[0]
  assert(Math.abs(Date.parse(r2.due_at) - (start - 60 * 60_000)) < 60_000, 'segundo aviso não ficou para 1 h antes: ' + r2.due_at)
  // lembrete simples: exatamente no horário, sem antecedência
  const rem = await cliente.post('/api/items', { action: 'create', type: 'reminder', data: { message: 'tomar água', time: '23:03' } }); const rid = rem.body.item?.id || rem.body.items?.[0]?.id
  const rr = (await q('SELECT due_at, data FROM items WHERE id = $1', [rid]))[0]; const rd = JSON.parse(rr.data)
  assert(rd.leadMinutes === 0 && rr.due_at === rd.remindAt, 'lembrete com antecedência: ' + JSON.stringify(rd))
  // códigos internos nunca aparecem
  const { cleanCodes } = await import('../src/routes/chat.js'); assert(cleanCodes('Pronto, lembrete criado! [rem:34]') === 'Pronto, lembrete criado!' && cleanCodes('Feito [task: 12] e [appt:3].') === 'Feito e.', 'códigos internos')
})
mpSrv.close()
mkSrv.close()

await new Promise<void>((r) => server.close(() => r()))
await d.close()
ai.close()
rmSync(dir, { recursive: true, force: true })
const failed = results.filter((r) => !r.ok)
console.log(`\nResultado: ${results.length - failed.length}/${results.length} testes aprovados. Chamadas ao dublê da IA: ${aiCalls}`)
writeFileSync(join(process.cwd(), 'test', 'last-results.json'), JSON.stringify({ at: new Date().toISOString(), results }, null, 2))
process.exit(failed.length ? 1 : 0)
