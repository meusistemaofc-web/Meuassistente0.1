// Sobe o servidor completo com banco SQLite de teste e um dublê local da IA, para os testes no navegador.
import { createServer } from 'node:http'
import { join } from 'node:path'
const ai = createServer(async (req, res) => {
  let body = ''; for await (const c of req) body += c
  const j = JSON.parse(body); const last = j.messages[j.messages.length - 1]
  const send = (m: object) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ choices: [{ message: m }] })) }
  if (last.role === 'tool') return send({ role: 'assistant', content: 'Pronto, registrei para você.' })
  if (/gastei/i.test(last.content)) return send({ role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'register_transaction', arguments: JSON.stringify({ kind: 'expense', amount: 35, description: 'Almoço', category: 'alimentacao' }) } }] })
  send({ role: 'assistant', content: 'Olá! Sou o Meu Assistente. Como posso ajudar?' })
})
await new Promise<void>((r) => ai.listen(0, '127.0.0.1', r))
Object.assign(process.env, { AI_BASE_URL: `http://127.0.0.1:${(ai.address() as any).port}/v1`, AI_API_KEY: 'k', PUBLIC_URL: 'http://localhost:' + (process.env.PORT || 4300), STATIC_DIR: join(process.cwd(), '..', 'frontend', 'public') })
const { createSqlite } = await import('../src/db/sqlite.js')
const { setDb } = await import('../src/db/index.js')
const { migrate } = await import('../src/db/migrate.js')
const { createApp } = await import('../src/app.js')
const { config } = await import('../src/config.js')
const d = await createSqlite(process.env.SQLITE_FILE || '/tmp/ma-e2e.db'); setDb(d)
await migrate(d, config.migrationsDir)
await (await import('../src/routes/kb.js')).seedKb()
createApp().listen(Number(process.env.PORT || 4300), '127.0.0.1', () => console.log('e2e server up'))
