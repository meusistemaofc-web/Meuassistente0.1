# Testes de navegador (Playwright + Chromium)

Complementam `npm test` (que cobre API, banco, motores e regras) verificando o que só aparece no navegador.

| Arquivo | O que comprova |
|---|---|
| `tema_catalogo_agente.py` | O tema da empresa (5 presets + cantos retos) vale no catálogo, na janela do produto e no chat do agente; ícones de contato; sincronização entre telas; sem resíduos ao trocar de tema. |
| `cerebro_painel.py` | Aba "Cérebro e busca": cadastrar, conflito com confirmação, regra executável criada pela tela e cumprida no chat, detalhes, desativar/reativar, conflitos e uso recente. |

## Como rodar
```bash
cd server
PORT=4311 SQLITE_FILE=/tmp/ma-teste.db npx tsx test/serve-sqlite.ts &   # servidor de teste (SQLite, IA de mentira)
pip install playwright && playwright install chromium
python3 test/browser/tema_catalogo_agente.py    # troque BASE no topo do arquivo se usar outra porta
python3 test/browser/cerebro_painel.py
```
Cada script cria o administrador (primeiro cadastro), a empresa e os dados de que precisa: use um banco **novo** a cada execução.
