-- Central de e-mails: fila com tentativas, prevenção de duplicidade e histórico de envio.
CREATE TABLE IF NOT EXISTS email_queue (
  id              BIGSERIAL PRIMARY KEY,
  business_id     BIGINT REFERENCES businesses(id) ON DELETE CASCADE,
  user_id         BIGINT REFERENCES users(id) ON DELETE SET NULL,
  kind            TEXT NOT NULL,
  to_addr         TEXT NOT NULL,
  subject         TEXT NOT NULL,
  html            TEXT NOT NULL,
  text            TEXT NOT NULL,
  dedupe_key      TEXT UNIQUE,
  status          TEXT NOT NULL DEFAULT 'pendente',
  attempts        INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_error      TEXT,
  provider        TEXT,
  provider_id     TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  sent_at         TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS email_queue_due ON email_queue (status, next_attempt_at);
CREATE INDEX IF NOT EXISTS email_queue_created ON email_queue (created_at);
