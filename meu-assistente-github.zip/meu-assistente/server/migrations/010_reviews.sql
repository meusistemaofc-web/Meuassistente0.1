-- Avaliações reais das empresas: clientes avaliam depois de pedido concluído ou agendamento realizado;
-- o administrador também pode atribuir nota (uma por administrador e empresa).
CREATE TABLE IF NOT EXISTS reviews (
  id          BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id     BIGINT REFERENCES users(id) ON DELETE SET NULL,
  order_id    BIGINT UNIQUE REFERENCES orders(id) ON DELETE SET NULL,
  origem      TEXT NOT NULL DEFAULT 'cliente',
  rating      INTEGER NOT NULL,
  comment     TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS reviews_business ON reviews (business_id);
