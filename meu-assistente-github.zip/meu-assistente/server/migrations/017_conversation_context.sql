-- Memória contextual de cada conversa: assunto, dados já informados, pergunta pendente, últimos registros e ações.
CREATE TABLE IF NOT EXISTS conversation_context (
  conversation_id TEXT PRIMARY KEY,
  user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  estado          TEXT NOT NULL DEFAULT '{}',
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS conversation_context_user ON conversation_context (user_id, updated_at);
