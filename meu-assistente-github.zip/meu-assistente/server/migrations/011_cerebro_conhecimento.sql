-- Cérebro próprio: a mesma tabela de respostas aprendidas passa a guardar também conhecimentos, regras,
-- instruções e experiências, com situação (ativo/pendente/rejeitado), origem e palavras-chave.
ALTER TABLE brain_answers ADD COLUMN kind TEXT NOT NULL DEFAULT 'resposta';
ALTER TABLE brain_answers ADD COLUMN status TEXT NOT NULL DEFAULT 'ativo';
ALTER TABLE brain_answers ADD COLUMN source TEXT;
ALTER TABLE brain_answers ADD COLUMN keywords TEXT;
CREATE INDEX IF NOT EXISTS brain_answers_kind_status ON brain_answers (kind, status);
-- histórico do que o cérebro aprendeu e de cada revisão
CREATE TABLE IF NOT EXISTS brain_history (
  id         BIGSERIAL PRIMARY KEY,
  item_id    BIGINT,
  action     TEXT NOT NULL,
  detail     TEXT,
  actor      TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS brain_history_created ON brain_history (created_at);
