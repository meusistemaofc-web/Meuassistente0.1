-- Follow-up inteligente: acompanhamento pós-atendimento avisado ao DONO da empresa (nunca ao cliente).
CREATE TABLE IF NOT EXISTS followups (
  id            BIGSERIAL PRIMARY KEY,
  business_id   BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  owner_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  order_id      BIGINT UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
  cliente       TEXT NOT NULL,
  contato       TEXT,
  servico       TEXT,
  concluido_em  TIMESTAMPTZ NOT NULL,
  due_at        TIMESTAMPTZ NOT NULL,
  status        TEXT NOT NULL DEFAULT 'agendado',
  notified_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS followups_due ON followups (status, due_at);
CREATE INDEX IF NOT EXISTS followups_owner ON followups (owner_id, status);
