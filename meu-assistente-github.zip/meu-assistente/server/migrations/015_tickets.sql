-- Central de Ajuda: chamados (tickets) com protocolo, histórico de mensagens e anexos.
CREATE TABLE IF NOT EXISTS tickets (
  id           BIGSERIAL PRIMARY KEY,
  protocolo    TEXT NOT NULL UNIQUE,
  user_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id  BIGINT,
  categoria    TEXT NOT NULL,
  assunto      TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'aberto',
  admin_unread BOOLEAN NOT NULL DEFAULT TRUE,
  user_unread  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS tickets_user ON tickets (user_id, updated_at);
CREATE INDEX IF NOT EXISTS tickets_status ON tickets (status, updated_at);
CREATE TABLE IF NOT EXISTS ticket_messages (
  id         BIGSERIAL PRIMARY KEY,
  ticket_id  BIGINT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  autor      TEXT NOT NULL,
  user_id    BIGINT,
  texto      TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ticket_messages_t ON ticket_messages (ticket_id, id);
CREATE TABLE IF NOT EXISTS ticket_attachments (
  id         BIGSERIAL PRIMARY KEY,
  message_id BIGINT NOT NULL REFERENCES ticket_messages(id) ON DELETE CASCADE,
  ticket_id  BIGINT NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  mime       TEXT NOT NULL,
  nome       TEXT,
  data       TEXT NOT NULL,
  tamanho    INTEGER NOT NULL DEFAULT 0
);
