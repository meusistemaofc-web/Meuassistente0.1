-- Meu Assistente — estrutura inicial (PostgreSQL 14+)
-- O sistema original guardava tudo no Netlify Blobs (chave-valor). Esta migração
-- cria um modelo relacional equivalente para os módulos reconstruídos.

CREATE TABLE IF NOT EXISTS app_config (
  key        TEXT PRIMARY KEY,
  value      JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id                  BIGSERIAL PRIMARY KEY,
  email               TEXT NOT NULL,
  name                TEXT NOT NULL,
  whatsapp            TEXT NOT NULL DEFAULT '',
  birthday            TEXT,
  password_hash       TEXT NOT NULL,
  role                TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin','superadmin')),
  permissions         JSONB NOT NULL DEFAULT '[]',
  status              TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disabled')),
  avatar_url          TEXT,
  settings            JSONB NOT NULL DEFAULT '{}',
  interaction         JSONB NOT NULL DEFAULT '{}',
  chat_ui             JSONB NOT NULL DEFAULT '{}',
  memory_settings     JSONB NOT NULL DEFAULT '{}',
  mfa_enabled         BOOLEAN NOT NULL DEFAULT FALSE,
  mfa_secret          TEXT,
  mfa_pending_secret  TEXT,
  backup_codes        JSONB NOT NULL DEFAULT '[]',
  origin              TEXT,
  source              TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at        TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_uq ON users (email);

CREATE TABLE IF NOT EXISTS sessions (
  id            TEXT PRIMARY KEY,            -- SHA-256 do token do cookie (o token nunca é gravado)
  user_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mfa_pending   BOOLEAN NOT NULL DEFAULT FALSE,
  recovery      BOOLEAN NOT NULL DEFAULT FALSE,
  reauth_at     TIMESTAMPTZ,
  user_agent    TEXT,
  ip            TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);

CREATE TABLE IF NOT EXISTS password_resets (
  token_hash  TEXT PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS conversations (
  id          TEXT PRIMARY KEY,              -- UUID gerado pelo app (contrato original)
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL DEFAULT 'Nova conversa',
  pinned      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS conversations_user_idx ON conversations (user_id, updated_at);

CREATE TABLE IF NOT EXISTS messages (
  id               BIGSERIAL PRIMARY KEY,
  conversation_id  TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id          BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role             TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content          TEXT NOT NULL,
  cards            JSONB NOT NULL DEFAULT '[]',
  reply_to_id      BIGINT,
  superseded       BOOLEAN NOT NULL DEFAULT FALSE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS messages_conv_idx ON messages (conversation_id, id);

CREATE TABLE IF NOT EXISTS memories (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  kind        TEXT NOT NULL DEFAULT 'fact',
  source      TEXT NOT NULL DEFAULT 'manual',
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  use_count   INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS memories_user_idx ON memories (user_id);

-- Registros pessoais: tarefas, compromissos, lembretes, compras, notas, lançamentos e contas.
CREATE TABLE IF NOT EXISTS items (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type        TEXT NOT NULL CHECK (type IN ('task','appointment','reminder','shopping','note','expense','bill')),
  status      TEXT,
  day         TEXT,                          -- data local AAAA-MM-DD (vencimento / data do evento)
  due_at      TIMESTAMPTZ,                   -- instante UTC do disparo (lembretes / compromissos)
  data        JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS items_user_type_idx ON items (user_id, type);
CREATE INDEX IF NOT EXISTS items_due_idx ON items (due_at);

CREATE TABLE IF NOT EXISTS notifications (
  id          BIGSERIAL PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type        TEXT NOT NULL,
  title       TEXT NOT NULL,
  body        TEXT,
  link        TEXT,
  ref         TEXT,
  read        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications (user_id, id);
CREATE UNIQUE INDEX IF NOT EXISTS notifications_ref_uq ON notifications (user_id, ref);

CREATE TABLE IF NOT EXISTS audit_log (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    BIGINT,
  action      TEXT NOT NULL,
  target_id   BIGINT,
  details     JSONB NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Operações feitas sem internet e sincronizadas depois (idempotência por id da operação).
CREATE TABLE IF NOT EXISTS sync_ops (
  op_id       TEXT PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  result      JSONB NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
