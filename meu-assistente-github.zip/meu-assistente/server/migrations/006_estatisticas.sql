-- Acessos das empresas por dia (impressões, visitas, cliques, conversas do agente, pedidos).
CREATE TABLE IF NOT EXISTS business_stats (
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  day         TEXT NOT NULL,
  kind        TEXT NOT NULL,
  n           INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (business_id, day, kind)
);
