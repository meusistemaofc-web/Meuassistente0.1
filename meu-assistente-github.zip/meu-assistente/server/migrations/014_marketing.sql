-- Acompanhamento de convites (quem ativou o lembrete) e Central de Marketing com consentimento separado.
CREATE TABLE IF NOT EXISTS invite_activations (
  id            BIGSERIAL PRIMARY KEY,
  token         TEXT NOT NULL,
  owner_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  owner_item_id BIGINT,
  guest_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  guest_item_id BIGINT,
  conta_nova    BOOLEAN NOT NULL DEFAULT FALSE,
  ativado_em    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (token, guest_id)
);
CREATE INDEX IF NOT EXISTS invite_act_owner ON invite_activations (owner_id, owner_item_id);
CREATE TABLE IF NOT EXISTS marketing_consents (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status      TEXT NOT NULL DEFAULT 'ativo',
  origem      TEXT NOT NULL,
  criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  revogado_em TIMESTAMPTZ,
  UNIQUE (owner_id, user_id)
);
CREATE TABLE IF NOT EXISTS mkt_campaigns (
  id            BIGSERIAL PRIMARY KEY,
  owner_id      BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id   BIGINT REFERENCES businesses(id) ON DELETE CASCADE,
  titulo        TEXT NOT NULL,
  mensagem      TEXT NOT NULL,
  link          TEXT,
  segmento      TEXT,
  status        TEXT NOT NULL DEFAULT 'agendada',
  agendada_para TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  total         INTEGER NOT NULL DEFAULT 0,
  enviados      INTEGER NOT NULL DEFAULT 0,
  push_ok       INTEGER NOT NULL DEFAULT 0,
  ignorados     INTEGER NOT NULL DEFAULT 0,
  cliques       INTEGER NOT NULL DEFAULT 0,
  erro          TEXT,
  criada_em     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  concluida_em  TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS mkt_camp_due ON mkt_campaigns (status, agendada_para);
CREATE TABLE IF NOT EXISTS mkt_sends (
  id          BIGSERIAL PRIMARY KEY,
  campaign_id BIGINT NOT NULL REFERENCES mkt_campaigns(id) ON DELETE CASCADE,
  owner_id    BIGINT NOT NULL,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status      TEXT NOT NULL,
  canal       TEXT,
  clicado_em  TIMESTAMPTZ,
  criado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (campaign_id, user_id)
);
CREATE INDEX IF NOT EXISTS mkt_sends_owner ON mkt_sends (owner_id, criado_em);
