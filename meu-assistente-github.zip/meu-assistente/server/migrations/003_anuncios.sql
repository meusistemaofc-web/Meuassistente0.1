-- Anúncios e empresas parceiras (proposta → aprovação → pagamento Pix → ativo até a data de vencimento).
CREATE TABLE IF NOT EXISTS businesses (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  protocolo   TEXT NOT NULL,
  status      TEXT NOT NULL,
  plan_id     TEXT NOT NULL,
  data        JSONB NOT NULL,
  lat         DOUBLE PRECISION,
  lng         DOUBLE PRECISION,
  payment_id  TEXT,
  expires_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS businesses_owner ON businesses (owner_id);
CREATE INDEX IF NOT EXISTS businesses_status ON businesses (status);
