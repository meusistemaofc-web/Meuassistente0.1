-- Cérebro: respostas aprendidas (reutilizadas sem gastar IA)
CREATE TABLE IF NOT EXISTS brain_answers (
  id            BIGSERIAL PRIMARY KEY,
  user_id       BIGINT REFERENCES users(id) ON DELETE CASCADE,
  question      TEXT NOT NULL,
  question_norm TEXT NOT NULL,
  answer        TEXT NOT NULL,
  origin        TEXT NOT NULL DEFAULT 'ia',
  uses          INTEGER NOT NULL DEFAULT 0,
  score         REAL NOT NULL DEFAULT 0,
  reviewed      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS brain_answers_user_norm ON brain_answers (user_id, question_norm);
CREATE INDEX IF NOT EXISTS brain_answers_user_score ON brain_answers (user_id, score DESC);
