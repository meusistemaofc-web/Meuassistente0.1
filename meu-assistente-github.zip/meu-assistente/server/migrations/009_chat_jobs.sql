-- Conversas processadas no servidor, independentes da tela: o app pode sair, perder a internet ou
-- recarregar e depois buscar a resposta pelo id do pedido (sem gerar duas vezes).
CREATE TABLE IF NOT EXISTS chat_jobs (
  id          TEXT PRIMARY KEY,
  user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status      TEXT NOT NULL DEFAULT 'pending',
  result      TEXT,
  error       TEXT,
  error_code  TEXT,
  error_status INTEGER,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS chat_jobs_user ON chat_jobs (user_id, created_at);
