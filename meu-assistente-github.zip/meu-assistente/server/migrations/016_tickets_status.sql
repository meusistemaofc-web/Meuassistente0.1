-- Central de Ajuda: status novo / em andamento / atendido / encerrado e "visualizado pelo administrador".
ALTER TABLE tickets ADD COLUMN admin_viewed_at TIMESTAMPTZ;
UPDATE tickets SET status = 'novo' WHERE status = 'aberto';
UPDATE tickets SET status = 'em_andamento' WHERE status = 'em_atendimento';
UPDATE tickets SET status = 'atendido' WHERE status = 'aguardando_usuario';
UPDATE tickets SET status = 'encerrado' WHERE status = 'resolvido';
