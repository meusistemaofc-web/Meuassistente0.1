-- Dados por usuário dos módulos novos (perfil fiscal, faturamento, DAS pagos, alertas de mercado).
CREATE TABLE IF NOT EXISTS user_modules (
  user_id    BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key        TEXT NOT NULL,
  value      JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, key)
);
