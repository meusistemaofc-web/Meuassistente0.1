// Adaptador de TESTE: executa o mesmo SQL do PostgreSQL no SQLite embutido do Node 22,
// traduzindo os poucos recursos de dialeto usados pelo projeto. NÃO é usado em produção.
import type { Db, Row } from './index.js'

/** Emula restrições do PostgreSQL que o SQLite aceitaria em silêncio (o banco real é PostgreSQL com colunas JSONB):
 *  comparar JSONB com texto via LIKE/ILIKE é erro no PostgreSQL ("operator does not exist: jsonb ~~ unknown"). */
const JSONB_COLS = /(^|[\s(,.])(data|settings|permissions|interaction|chat_ui|memory_settings|backup_codes|cards|details|result|value|chunks)\s+(NOT\s+)?I?LIKE\b/i
function pgStrict(sql: string) { if (JSONB_COLS.test(sql)) throw new Error('Consulta incompatível com PostgreSQL: LIKE/ILIKE em coluna JSONB → ' + sql.slice(0, 160)) }
function translate(sql: string): string {
  pgStrict(sql)
  return sql
    .replace(/BIGSERIAL PRIMARY KEY/gi, 'INTEGER PRIMARY KEY AUTOINCREMENT')
    .replace(/\bTIMESTAMPTZ\b/gi, 'TEXT')
    .replace(/\bJSONB\b/gi, 'TEXT')
    .replace(/DEFAULT now\(\)/gi, "DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
    .replace(/::[a-z]+(\[\])?/gi, '')
    .replace(/\bILIKE\b/gi, 'LIKE')
    .replace(/\bGREATEST\(/gi, 'MAX(')
    .replace(/\$(\d+)/g, '?$1')
}

export async function createSqlite(file = ':memory:'): Promise<Db> {
  const { DatabaseSync } = await import('node:sqlite')
  const conn = new DatabaseSync(file)
  conn.exec('PRAGMA foreign_keys = ON')
  const norm = (p: unknown[]) => p.map((v) => (typeof v === 'boolean' ? (v ? 1 : 0) : v === undefined ? null : v)) as any[]
  let depth = 0
  const self: Db = {
    kind: 'sqlite',
    async query<R extends Row>(sql: string, params: unknown[] = []) {
      const t = translate(sql)
      const st = conn.prepare(t)
      if (/^\s*(SELECT|WITH)|RETURNING/i.test(t)) return st.all(...norm(params)) as R[]
      st.run(...norm(params))
      return [] as R[]
    },
    async exec(sql: string) { conn.exec(translate(sql)) },
    async tx(fn) {
      if (depth > 0) return fn(self)
      depth++
      conn.exec('BEGIN')
      try { const r = await fn(self); conn.exec('COMMIT'); return r } catch (e) { conn.exec('ROLLBACK'); throw e } finally { depth-- }
    },
    async close() { conn.close() },
  }
  return self
}
