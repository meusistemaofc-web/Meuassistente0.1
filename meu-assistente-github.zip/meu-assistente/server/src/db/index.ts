// Camada de banco: interface pequena (query/tx) com adaptador PostgreSQL (produção)
// e adaptador SQLite embutido do Node (somente para os testes automatizados offline).
export type Row = Record<string, any>
export interface Db {
  query<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R[]>
  tx<T>(fn: (q: Db) => Promise<T>): Promise<T>
  exec(sql: string): Promise<void>
  close(): Promise<void>
  kind: 'postgres' | 'sqlite'
}

let current: Db | null = null
export function setDb(d: Db) { current = d }
export function db(): Db {
  if (!current) throw new Error('Banco de dados não inicializado')
  return current
}
export async function one<R extends Row = Row>(sql: string, params?: unknown[]): Promise<R | null> {
  const rows = await db().query<R>(sql, params)
  return rows[0] ?? null
}
export const q = <R extends Row = Row>(sql: string, params?: unknown[]) => db().query<R>(sql, params)

/** Valores JSON vêm como objeto (PostgreSQL JSONB) ou texto (SQLite). */
export function J<T = any>(v: unknown, fallback: T): T {
  if (v === null || v === undefined) return fallback
  if (typeof v === 'string') { try { return JSON.parse(v) as T } catch { return fallback } }
  return v as T
}
export const B = (v: unknown) => v === true || v === 1 || v === '1' || v === 't'
export const nowIso = () => new Date().toISOString()
export function isoOf(v: unknown): string | null {
  if (!v) return null
  if (v instanceof Date) return v.toISOString()
  const s = String(v)
  const d = new Date(s.includes('T') || s.endsWith('Z') ? s : s.replace(' ', 'T') + 'Z')
  return isNaN(d.getTime()) ? s : d.toISOString()
}
