import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { Db } from './index.js'

/** Aplica, em ordem, os arquivos migrations/NNN_*.sql ainda não registrados. Reprodutível e idempotente. */
export async function migrate(d: Db, dir: string, log: (m: string) => void = console.log): Promise<string[]> {
  await d.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`)
  const done = new Set((await d.query<{ version: string }>('SELECT version FROM schema_migrations')).map((r) => r.version))
  const files = readdirSync(dir).filter((f) => /^\d+_.*\.sql$/.test(f)).sort()
  const applied: string[] = []
  for (const f of files) {
    if (done.has(f)) continue
    const sql = readFileSync(join(dir, f), 'utf8')
    await d.tx(async (t) => {
      await t.exec(sql)
      await t.query('INSERT INTO schema_migrations (version, applied_at) VALUES ($1, $2)', [f, new Date().toISOString()])
    })
    log(`[migrate] aplicada ${f}`)
    applied.push(f)
  }
  if (!applied.length) log('[migrate] banco já está atualizado')
  return applied
}
