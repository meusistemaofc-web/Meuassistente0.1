import { connectFromEnv } from './connect.js'
import { migrate } from './migrate.js'
import { config } from '../config.js'

const d = await connectFromEnv()
try { await migrate(d, config.migrationsDir) } finally { await d.close() }
