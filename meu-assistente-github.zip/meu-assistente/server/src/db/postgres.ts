import pg from 'pg'
import type { Db, Row } from './index.js'

export function createPostgres(url: string): Db {
  // BIGINT/BIGSERIAL como número (os IDs do app são numéricos) e TIMESTAMPTZ como ISO-8601.
  pg.types.setTypeParser(20, (v) => Number(v))
  pg.types.setTypeParser(1184, (v) => new Date(v).toISOString())
  pg.types.setTypeParser(1114, (v) => new Date(v + 'Z').toISOString())
  const ssl = process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined
  const pool = new pg.Pool({ connectionString: url, max: Number(process.env.DATABASE_POOL_MAX || 10), ssl })
  pool.on('error', (e) => console.error('[db] erro no pool:', e.message))
  const wrap = (runner: { query: (s: string, p?: unknown[]) => Promise<{ rows: any[] }> }): Db => ({
    kind: 'postgres',
    async query<R extends Row>(sql: string, params: unknown[] = []) { return (await runner.query(sql, params)).rows as R[] },
    async exec(sql: string) { await runner.query(sql) },
    tx: async (fn) => fn(wrap(runner)),
    close: async () => {},
  })
  const base = wrap(pool)
  return {
    ...base,
    async tx(fn) {
      const client = await pool.connect()
      try {
        await client.query('BEGIN')
        const r = await fn(wrap(client))
        await client.query('COMMIT')
        return r
      } catch (e) {
        await client.query('ROLLBACK').catch(() => {})
        throw e
      } finally { client.release() }
    },
    close: () => pool.end(),
  }
}
