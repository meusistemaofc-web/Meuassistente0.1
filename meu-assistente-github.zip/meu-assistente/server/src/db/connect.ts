import { config } from '../config.js'
import { setDb, type Db } from './index.js'
import { createPostgres } from './postgres.js'

export async function connectFromEnv(): Promise<Db> {
  if (!config.databaseUrl) throw new Error('DATABASE_URL não definido. Copie .env.example para .env e preencha.')
  const d = createPostgres(config.databaseUrl)
  await d.query('SELECT 1')
  setDb(d)
  return d
}
