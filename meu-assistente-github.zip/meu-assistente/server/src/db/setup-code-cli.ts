// Mostra o código de configuração do Administrador Principal (substitui "netlify blobs:get nexa-config setup-code").
import { connectFromEnv } from './connect.js'
import { ensureSetupCode } from '../routes/auth.js'
const d = await connectFromEnv()
const code = await ensureSetupCode()
console.log(code ? `Código de configuração: ${code}` : 'Não é necessário: não há contas ainda (a primeira conta vira Administrador Principal) ou o Administrador Principal já existe.')
await d.close()
