// Catálogo de TODOS os módulos do Meu Assistente: usado pelo painel (visibilidade nos menus), pelo chat
// (reconhece "anúncios", "finanças", "minha loja"… e mostra o cartão do módulo) e pelo app.
export interface ModEntry { key: string; label: string; route: string; desc: string; words: string[]; grupo: string; menu?: string }
export const MOD_CATALOG: ModEntry[] = [
  { key: 'meudia', label: 'Meu Dia', route: '/meu-dia', desc: 'Resumo do dia: compromissos, tarefas, contas e lembretes.', words: ['meu dia', 'resumo do dia', 'meu resumo'], grupo: 'Organização', menu: 'o:Meu Dia' },
  { key: 'tarefas', label: 'Tarefas', route: '/agenda?tab=tarefas', desc: 'Lista de tarefas com prazos e prioridades.', words: ['tarefas', 'minhas tarefas', 'tarefa', 'afazeres', 'to do'], grupo: 'Organização', menu: 'o:Tarefas' },
  { key: 'compromissos', label: 'Compromissos', route: '/agenda?tab=compromissos', desc: 'Agenda de compromissos com convites e avisos.', words: ['compromissos', 'agenda'], grupo: 'Organização', menu: 'o:Compromissos' },
  { key: 'lembretes', label: 'Lembretes', route: '/agenda?tab=lembretes', desc: 'Avisos no horário certo, únicos ou repetidos.', words: ['lembretes', 'meus lembretes', 'lembrete'], grupo: 'Organização' },
  { key: 'organizar', label: 'Compras e anotações', route: '/organizar', desc: 'Listas de compras e anotações rápidas.', words: ['compras', 'lista de compras', 'anotacoes', 'notas', 'organizar', 'minhas notas'], grupo: 'Organização' },
  { key: 'financas', label: 'Finanças', route: '/financeiro', desc: 'Gastos, receitas, saldo e relatórios.', words: ['financas', 'financeiro', 'minhas financas', 'gastos', 'meus gastos', 'receitas', 'extrato', 'controle financeiro'], grupo: 'Dinheiro' },
  { key: 'contas', label: 'Contas a pagar', route: '/financeiro?tab=contas', desc: 'Contas, boletos e vencimentos.', words: ['contas', 'contas a pagar', 'boletos', 'vencimentos'], grupo: 'Dinheiro', menu: 'o:Contas' },
  { key: 'impostos', label: 'Impostos e DAS', route: '/x/impostos', desc: 'DAS do MEI, faturamento e limite anual.', words: ['impostos', 'das', 'mei', 'imposto'], grupo: 'Dinheiro', menu: 'impostos' },
  { key: 'mercado', label: 'Mercado', route: '/x/mercado', desc: 'Cotações de cripto e bolsa, gráficos e alertas.', words: ['mercado', 'cotacoes', 'bolsa', 'cripto', 'criptomoedas'], grupo: 'Dinheiro', menu: 'mercado' },
  { key: 'planos', label: 'Meu plano', route: '/x/planos', desc: 'Seu plano, limites de uso e assinatura.', words: ['meu plano', 'planos', 'assinatura', 'limites'], grupo: 'Conta', menu: 'planos' },
  { key: 'anuncios', label: 'Anúncios', route: '/x/anunciar', desc: 'Anuncie sua empresa no chat e na busca.', words: ['anuncios', 'anuncio', 'anunciar', 'meus anuncios', 'anunciar minha empresa'], grupo: 'Empresas', menu: 'anunciar' },
  { key: 'suaempresa', label: 'Sua empresa', route: '/x/sua-empresa', desc: 'Sua loja: catálogo, pedidos, agente e relatórios.', words: ['minha loja', 'sua loja', 'minha empresa', 'sua empresa', 'loja', 'meu catalogo', 'meus produtos'], grupo: 'Empresas', menu: 'suaempresa' },
  { key: 'empresas', label: 'Empresas perto de você', route: '/x/empresas', desc: 'Busque lojas e serviços por perto.', words: ['empresas', 'empresas perto', 'lojas perto', 'empresas perto de mim'], grupo: 'Empresas', menu: 'empresas' },
  { key: 'pedidos', label: 'Meus pedidos', route: '/x/pedidos', desc: 'Pedidos e agendamentos que você fez.', words: ['pedidos', 'meus pedidos', 'meus agendamentos'], grupo: 'Empresas', menu: 'pedidos' },
  { key: 'arquivos', label: 'Arquivos', route: '/espaco', desc: 'Seus arquivos, fotos e documentos guardados.', words: ['arquivos', 'meus arquivos', 'documentos', 'meus documentos', 'espaco'], grupo: 'Ferramentas' },
  { key: 'mapas', label: 'Mapas e GPS', route: '/mapas', desc: 'Mapa, localização e rotas, também offline.', words: ['mapas', 'mapa', 'gps'], grupo: 'Ferramentas' },
  { key: 'alimentacao', label: 'Alimentação', route: '/alimentacao', desc: 'Refeições e hábitos alimentares.', words: ['alimentacao', 'refeicoes', 'dieta'], grupo: 'Saúde' },
  { key: 'treinos', label: 'Treinos', route: '/treinos', desc: 'Registro e planejamento de treinos.', words: ['treinos', 'treino', 'academia'], grupo: 'Saúde' },
  { key: 'estudio', label: 'Estúdio', route: '/estudio', desc: 'Criação de conteúdos e textos.', words: ['estudio'], grupo: 'Ferramentas' },
  { key: 'emails', label: 'E-mails', route: '/emails', desc: 'Leitura e organização de e-mails.', words: ['emails', 'e-mails', 'email', 'caixa de entrada'], grupo: 'Ferramentas' },
  { key: 'integracoes', label: 'Integrações', route: '/integracoes', desc: 'Conexões com outros serviços.', words: ['integracoes', 'conexoes'], grupo: 'Conta' },
  { key: 'notificacoes', label: 'Notificações', route: '/notificacoes', desc: 'Avisos recebidos e preferências.', words: ['notificacoes', 'avisos', 'minhas notificacoes'], grupo: 'Conta' },
  { key: 'configuracoes', label: 'Configurações', route: '/perfil', desc: 'Perfil, voz, notificações e preferências.', words: ['configuracoes', 'configuracao', 'perfil', 'minha conta', 'meu perfil', 'ajustes', 'preferencias'], grupo: 'Conta' },
  { key: 'eleicoes', label: 'Eleições 2026', route: '/eleicoes', desc: 'Informações e enquetes das eleições.', words: ['eleicoes', 'eleicao'], grupo: 'Ferramentas' },
]
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
/** Reconhece quando a mensagem é o nome de um módulo ("anúncios", "abrir finanças", "minha loja"). */
export function moduleIntent(text: string): ModEntry | null {
  let s = nrm(text)
  if (s.split(' ').length > 6) return null
  s = s.replace(/^(quero |eu quero |pode |por favor )?(abrir|abre|abra|ir para|ir pro|ir pra|vai para|ver|mostrar|mostra|me mostra|acessar|entrar em|entrar no|entrar na|tela de|tela do|tela da)\s+/, '').replace(/^(o|a|os|as|meu|minha|meus|minhas|no|na|em)\s+/, '').trim()
  for (const m of MOD_CATALOG) for (const w of [...m.words].sort((a, b) => b.length - a.length)) if (s === nrm(w)) return m
  return null
}
