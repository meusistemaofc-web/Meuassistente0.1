// Web Push nativo (sem dependências): chaves VAPID (ES256) + criptografia aes128gcm (RFC 8291/8188),
// compatível com Chrome, Android, Safari/iPhone (app na tela inicial) e Firefox.
import { createECDH, createPrivateKey, createSign, hkdfSync, randomBytes, createCipheriv } from 'node:crypto'
import { q } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'

const b64u = (b: Buffer) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const unb64u = (s: string) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64')
const nowIso = () => new Date().toISOString()

interface Vapid { publicKey: string; privateKey: string; subject: string }
let cache: Vapid | null = null
export async function vapid(): Promise<Vapid> {
  if (cache) return cache
  let k = await getConfig<any>('vapid', null)
  const okKey = (x: any) => { try { return unb64u(String(x?.publicKey || '')).length === 65 && unb64u(String(x?.privateKey || '')).length === 32 } catch { return false } }
  if (!okKey(k)) {
    const e = createECDH('prime256v1'); e.generateKeys()
    k = { publicKey: b64u(e.getPublicKey()), privateKey: b64u(e.getPrivateKey()), subject: 'mailto:admin@meuassistente.app' }
    await setConfig('vapid', k)
  }
  cache = { subject: 'mailto:admin@meuassistente.app', ...k }
  return cache!
}
export async function getPublicKey() { return (await vapid()).publicKey }

function vapidAuth(endpoint: string, v: Vapid) {
  const pub = unb64u(v.publicKey), aud = new URL(endpoint).origin
  const head = b64u(Buffer.from(JSON.stringify({ typ: 'JWT', alg: 'ES256' })))
  const body = b64u(Buffer.from(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: v.subject })))
  const key = createPrivateKey({ key: { kty: 'EC', crv: 'P-256', d: v.privateKey, x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) }, format: 'jwk' })
  const sig = createSign('SHA256').update(`${head}.${body}`).sign({ key, dsaEncoding: 'ieee-p1363' })
  return `vapid t=${head}.${body}.${b64u(sig)}, k=${v.publicKey}`
}
/** Criptografa a mensagem para o aparelho (aes128gcm). */
export function encryptPayload(p256dh: string, auth: string, payload: string) {
  const ua = unb64u(p256dh), secret = unb64u(auth)
  const e = createECDH('prime256v1'); e.generateKeys(); const asPub = e.getPublicKey()
  const shared = e.computeSecret(ua)
  const ikm = Buffer.from(hkdfSync('sha256', shared, secret, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub]), 32))
  const salt = randomBytes(16)
  const cek = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16))
  const nonce = Buffer.from(hkdfSync('sha256', ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12))
  const c = createCipheriv('aes-128-gcm', cek, nonce)
  const ct = Buffer.concat([c.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), c.final(), c.getAuthTag()])
  const head = Buffer.alloc(21); salt.copy(head, 0); head.writeUInt32BE(4096, 16); head[20] = asPub.length
  return Buffer.concat([head, asPub, ct])
}

/** Garante a tabela de inscrições no formato certo (bancos que receberam uma versão antiga da tabela são corrigidos). */
let schemaOk = false
export async function ensurePushSchema(force = false) {
  if (schemaOk && !force) return
  const run = async (sql: string) => { try { await q(sql) } catch { /* coluna/índice já existe ou banco não suporta a forma */ } }
  await run(`CREATE TABLE IF NOT EXISTS push_subscriptions (id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, endpoint TEXT NOT NULL UNIQUE, p256dh TEXT NOT NULL, auth TEXT NOT NULL, user_agent TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW())`)
  for (const c of ['p256dh TEXT', 'auth TEXT', 'user_agent TEXT', 'created_at TIMESTAMPTZ DEFAULT NOW()', 'last_seen TIMESTAMPTZ DEFAULT NOW()']) await run(`ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS ${c}`)
  await run('CREATE UNIQUE INDEX IF NOT EXISTS push_sub_endpoint_u ON push_subscriptions (endpoint)')
  schemaOk = true
}
async function recreatePushTable() {
  try { await q('DROP TABLE IF EXISTS push_subscriptions') } catch { /* ignora */ }
  schemaOk = false; await ensurePushSchema(true)
}
export async function saveSubscription(userId: number, sub: any, ua?: string) {
  await ensurePushSchema()
  try { return await saveSub(userId, sub, ua) }
  catch (e: any) {
    console.error('[push] falha ao salvar inscrição, corrigindo a tabela:', e?.message || e)
    await ensurePushSchema(true)
    try { return await saveSub(userId, sub, ua) }
    catch (e2: any) { console.error('[push] tabela antiga incompatível, recriando:', e2?.message || e2); await recreatePushTable(); return await saveSub(userId, sub, ua) }
  }
}
async function saveSub(userId: number, sub: any, ua?: string) {
  if (!sub?.endpoint || !sub?.keys?.p256dh || !sub?.keys?.auth) return false
  // upsert atômico: o app pode enviar a mesma inscrição duas vezes ao mesmo tempo (ativar + sincronizar)
  const t = nowIso()
  await q(`INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, user_agent, created_at, last_seen) VALUES ($1,$2,$3,$4,$5,$6,$7)
    ON CONFLICT (endpoint) DO UPDATE SET user_id = EXCLUDED.user_id, p256dh = EXCLUDED.p256dh, auth = EXCLUDED.auth, user_agent = EXCLUDED.user_agent, last_seen = EXCLUDED.last_seen`,
    [userId, sub.endpoint, sub.keys.p256dh, sub.keys.auth, String(ua || '').slice(0, 300), t, t])
  return true
}
export async function removeSubscription(userId: number, endpoint?: string) {
  if (endpoint) await q('DELETE FROM push_subscriptions WHERE user_id = $1 AND endpoint = $2', [userId, endpoint])
  else await q('DELETE FROM push_subscriptions WHERE user_id = $1', [userId])
}
export async function isRegistered(userId: number, endpoint: string) { return (await q('SELECT id FROM push_subscriptions WHERE user_id = $1 AND endpoint = $2', [userId, endpoint])).length > 0 }

export async function sendToUser(userId: number, payload: { title: string; body?: string; url?: string; tag?: string; data?: any }) {
  const subs = await q('SELECT * FROM push_subscriptions WHERE user_id = $1', [userId])
  if (!subs.length) return { sent: 0, total: 0, errors: [] as string[] }
  const v = await vapid(), body = JSON.stringify({ title: payload.title, body: payload.body || '', url: payload.url || '/', tag: payload.tag, ...(payload.data || {}) })
  let sent = 0; const errors: string[] = []
  await Promise.all(subs.map(async (s: any) => {
    try {
      const r = await fetch(s.endpoint, { method: 'POST', headers: { Authorization: vapidAuth(s.endpoint, v), TTL: '86400', Urgency: 'normal', 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream' }, body: encryptPayload(s.p256dh, s.auth, body), signal: AbortSignal.timeout(10_000) })
      if (r.status === 404 || r.status === 410) { await q('DELETE FROM push_subscriptions WHERE endpoint = $1', [s.endpoint]); errors.push('inscrição expirada'); return }
      if (r.ok) { sent++; await q('UPDATE push_subscriptions SET last_seen = $1 WHERE endpoint = $2', [nowIso(), s.endpoint]) } else errors.push(`serviço de push respondeu ${r.status}`)
    } catch (e: any) { errors.push(e?.message || 'falha de rede') }
  }))
  return { sent, total: subs.length, errors }
}
