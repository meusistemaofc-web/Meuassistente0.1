// Web Push: VAPID + envio de notificações para dispositivos inscritos.
import webpush from 'web-push'
import { q, one, nowIso } from '../db/index.js'
import { getConfig, setConfig } from './settings.js'

let vapidReady = false

async function ensureVapid() {
  if (vapidReady) return
  let keys = await getConfig<any>('vapid', null)
  if (!keys?.publicKey || !keys?.privateKey) {
    const gen = webpush.generateVAPIDKeys()
    keys = { publicKey: gen.publicKey, privateKey: gen.privateKey, subject: 'mailto:admin@meuassistente.local' }
    await setConfig('vapid', keys)
  }
  webpush.setVapidDetails(keys.subject || 'mailto:admin@meuassistente.local', keys.publicKey, keys.privateKey)
  vapidReady = true
  return keys
}

export async function getPublicKey() {
  const keys = await ensureVapid()
  return keys.publicKey
}

export async function saveSubscription(userId: number, sub: any, ua?: string) {
  if (!sub?.endpoint || !sub?.keys?.p256dh || !sub?.keys?.auth) return
  const now = nowIso()
  await q(
    `INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, user_agent, created_at, last_seen)
     VALUES ($1, $2, $3, $4, $5, $6, $6)
     ON CONFLICT (endpoint) DO UPDATE SET user_id = $1, p256dh = $3, auth = $4, last_seen = $6`,
    [userId, sub.endpoint, sub.keys.p256dh, sub.keys.auth, ua || '', now]
  )
}

export async function sendToUser(userId: number, payload: { title: string; body?: string; url?: string; tag?: string; data?: any }) {
  await ensureVapid()
  const subs = await q('SELECT * FROM push_subscriptions WHERE user_id = $1', [userId])
  const body = JSON.stringify({
    title: payload.title,
    body: payload.body || '',
    url: payload.url || '/',
    tag: payload.tag,
    ...payload.data,
  })
  const results = await Promise.allSettled(subs.map(async (s) => {
    try {
      await webpush.sendNotification({
        endpoint: s.endpoint,
        keys: { p256dh: s.p256dh, auth: s.auth },
      }, body)
    } catch (e: any) {
      if (e.statusCode === 404 || e.statusCode === 410) {
        await q('DELETE FROM push_subscriptions WHERE endpoint = $1', [s.endpoint])
      }
      throw e
    }
  }))
  return { sent: results.filter(r => r.status === 'fulfilled').length, total: subs.length }
}
