// Validade dos Pix gerados (Administração → Mercado Pago → Validade do Pix).
import { getConfig } from './settings.js'
export async function pixExpiry() {
  const min = Math.min(1440, Math.max(5, Number((await getConfig<any>('pix', {})).expiraMin) || 30))
  const at = new Date(Date.now() + min * 60_000)
  const br = new Date(at.getTime() - 3 * 3600_000).toISOString().replace('Z', '-03:00') // horário de Brasília, formato aceito pelo Mercado Pago
  return { iso: br, at: at.toISOString(), min }
}
export const pixValid = (p: any) => !!(p && p.qr && (!p.expiresAt || Date.parse(p.expiresAt) > Date.now() + 15_000))
