// Central de e-mails do Meu Assistente: provedores reais (SMTP próprio/Hostinger Email, Hostinger Mail API, Resend),
// modelos com a identidade visual, fila com tentativas, sem duplicidade, histórico e remetente por empresa.
import { randomUUID, createHmac } from 'node:crypto'
import { resolveTxt } from 'node:dns/promises'
import { config } from '../config.js'
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig, seal, unseal } from './settings.js'
import { smtpSend, smtpVerify, SmtpError, type SmtpCfg } from './mail/smtp.js'
import { pub } from './publicurl.js'

export const KINDS: Record<string, { nome: string; padrao: boolean }> = {
  cadastro: { nome: 'Boas-vindas (cadastro)', padrao: true }, confirmacao: { nome: 'Confirmação de e-mail', padrao: true },
  recuperacao: { nome: 'Recuperação de senha', padrao: true }, seguranca: { nome: 'Alertas de segurança', padrao: true },
  notificacoes: { nome: 'Notificações por e-mail', padrao: false }, compromissos: { nome: 'Lembretes de compromissos', padrao: false },
  pedidos: { nome: 'Pedidos e agendamentos', padrao: true }, comunicados: { nome: 'Comunicados', padrao: true }, teste: { nome: 'Teste', padrao: true },
}
export const DEFAULT_CFG = {
  ativo: false, provedor: 'smtp', remetenteNome: 'Meu Assistente', remetenteEmail: '', responderPara: '',
  smtp: { host: '', port: 465, seguranca: 'ssl', usuario: '', senha: '' }, api: { token: '', mailboxId: '' },
  limiteHora: 50, limiteDia: 300, eventos: Object.fromEntries(Object.entries(KINDS).map(([k, v]) => [k, v.padrao])) as Record<string, boolean>,
}
export const TEMPLATES: Record<string, { assunto: string; corpo: string }> = {
  cadastro: { assunto: 'Bem-vindo(a) ao Meu Assistente, {{nome}}!', corpo: 'Olá, {{nome}}!\n\nSua conta foi criada. Agora é só conversar no chat para organizar compromissos, tarefas, lembretes e finanças.\n\n[Abrir o Meu Assistente]({{app}})' },
  confirmacao: { assunto: 'Confirme seu e-mail · Meu Assistente', corpo: 'Olá, {{nome}}!\n\nConfirme que este e-mail é seu para proteger sua conta e receber avisos importantes.\n\n[Confirmar e-mail]({{link}})\n\nSe não foi você, ignore esta mensagem.' },
  recuperacao: { assunto: 'Criar nova senha · Meu Assistente', corpo: 'Olá, {{nome}}.\n\nRecebemos um pedido para criar uma nova senha.\n\n[Criar nova senha]({{link}})\n\nO link vale por 1 hora. Se não foi você, ignore este e-mail — sua senha continua a mesma.' },
  seguranca: { assunto: 'Alerta de segurança · Meu Assistente', corpo: 'Olá, {{nome}}.\n\n{{mensagem}}\n\nSe não foi você, troque sua senha agora em [Recuperar acesso]({{app}}/recuperar).' },
  notificacoes: { assunto: '{{titulo}}', corpo: '{{mensagem}}\n\n[Ver no Meu Assistente]({{link}})' },
  compromissos: { assunto: 'Lembrete: {{titulo}}', corpo: 'Olá, {{nome}}!\n\n{{mensagem}}\n\n[Ver minha agenda]({{app}}/agenda?tab=compromissos)' },
  pedidos: { assunto: '{{titulo}} · {{empresa}}', corpo: 'Olá, {{nome}}!\n\n{{mensagem}}\n\n[Acompanhar]({{link}})' },
  comunicados: { assunto: '{{titulo}}', corpo: '{{mensagem}}' },
  teste: { assunto: 'Teste de envio · Meu Assistente', corpo: 'Este é um e-mail de teste enviado pela Central de E-mails do Meu Assistente.\n\nSe você recebeu, o envio está funcionando.' },
}
const EMAIL_RE = /^[^\s@<>"]+@[^\s@<>"]+\.[a-z]{2,}$/i
export const validEmail = (e: string) => EMAIL_RE.test(String(e || '').trim())
export async function mailCfg() { const c = await getConfig<any>('email', {}); return { ...DEFAULT_CFG, ...c, smtp: { ...DEFAULT_CFG.smtp, ...(c.smtp || {}) }, api: { ...DEFAULT_CFG.api, ...(c.api || {}) }, eventos: { ...DEFAULT_CFG.eventos, ...(c.eventos || {}) } } }
/** Configuração para a tela: credenciais nunca saem do servidor. */
export async function mailCfgPublic() { const c = await mailCfg(); return { ...c, smtp: { ...c.smtp, senha: '', temSenha: !!c.smtp.senha }, api: { ...c.api, token: '', temToken: !!c.api.token }, resendEnv: !!config.mail.resendKey } }

/* ---------- modelos e identidade visual ---------- */
const esc = (s: string) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!))
const fill = (t: string, v: Record<string, any>) => String(t || '').replace(/\{\{(\w+)\}\}/g, (_, k) => (v[k] ?? '') + '')
export function renderHtml(corpo: string, marca: { nome: string; cor?: string; logo?: string }, rodape = '') {
  const app = pub(), cor = /^#[0-9a-f]{6}$/i.test(marca.cor || '') ? marca.cor! : '#2f6bff'
  const blocos = String(corpo).split(/\n\s*\n/).map((p) => {
    const b = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(p.trim())
    if (b) return `<p style="margin:24px 0"><a href="${esc(b[2])}" style="display:inline-block;background:${cor};color:#fff;text-decoration:none;font-weight:600;padding:12px 22px;border-radius:999px">${esc(b[1])}</a></p>`
    return `<p style="margin:0 0 14px;line-height:1.6">${esc(p).replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '<a href="$2" style="color:' + cor + '">$1</a>').replace(/\n/g, '<br>')}</p>`
  }).join('')
  return `<!doctype html><html lang="pt-BR"><body style="margin:0;background:#0b0d12;padding:24px 12px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#e8eaf0"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td align="center"><table role="presentation" width="100%" style="max-width:560px;background:#12151c;border:1px solid #232733;border-radius:20px" cellspacing="0" cellpadding="0"><tr><td style="padding:24px 28px 8px"><img src="${esc(marca.logo || app + '/brand/logo-principal-160.png')}" alt="" width="44" style="vertical-align:middle;border-radius:10px"> <span style="font-size:17px;font-weight:700;vertical-align:middle;margin-left:8px">${esc(marca.nome)}</span></td></tr><tr><td style="padding:16px 28px 24px;font-size:15px">${blocos}</td></tr><tr><td style="padding:16px 28px 24px;border-top:1px solid #232733;font-size:12px;color:#8a90a0;line-height:1.5">${rodape || 'Enviado pelo Meu Assistente.'}</td></tr></table></td></tr></table></body></html>`
}
const toText = (corpo: string) => String(corpo).replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1: $2')
async function templateFor(kind: string, businessId: number | null) {
  const g = (await getConfig<any>('email_templates', {}))[kind] || {}
  let t = { ...TEMPLATES[kind] || TEMPLATES.notificacoes, ...g }
  if (businessId) { const b = await one('SELECT data FROM businesses WHERE id = $1', [businessId]); const e = J<any>(b?.data, {}).emailTemplates?.[kind]; if (e?.assunto || e?.corpo) t = { ...t, ...Object.fromEntries(Object.entries(e).filter(([, v]) => v)) } }
  return t as { assunto: string; corpo: string }
}

/* ---------- fila ---------- */
export interface MailJob { kind: string; to: string; vars?: Record<string, any>; userId?: number | null; businessId?: number | null; dedupe?: string; subject?: string; corpo?: string }
/** Coloca um e-mail na fila (sem duplicar pela chave) e tenta enviar logo em seguida. */
export async function enqueueMail(j: MailJob): Promise<{ queued: boolean; id?: number; motivo?: string }> {
  const c = await mailCfg()
  if (!validEmail(j.to)) return { queued: false, motivo: 'destinatário inválido' }
  if (j.kind !== 'teste' && c.eventos[j.kind] === false) return { queued: false, motivo: 'tipo de e-mail desligado no painel' }
  if (!c.ativo && j.kind !== 'teste') { // envios desligados: não acumula fila para disparar tudo depois (exceto empresa com SMTP próprio)
    let proprio = false; if (j.businessId) { const b = await one('SELECT data FROM businesses WHERE id = $1', [j.businessId]); proprio = !!J<any>(b?.data, {}).email?.smtpProprio }
    if (!proprio) return { queued: false, motivo: 'envios desativados no painel' }
  }
  if (j.userId && j.kind !== 'recuperacao' && j.kind !== 'seguranca' && j.kind !== 'confirmacao' && j.kind !== 'teste') { const u = await one('SELECT settings FROM users WHERE id = $1', [j.userId]); if (J<any>(u?.settings, {}).emailOptOut?.[j.kind]) return { queued: false, motivo: 'usuário pediu para não receber' } }
  let marca = { nome: c.remetenteNome || 'Meu Assistente', cor: '#2f6bff', logo: '' }
  if (j.businessId) { const b = await one('SELECT data FROM businesses WHERE id = $1', [j.businessId]); const x = J<any>(b?.data, {}); marca = { nome: x.empresa || marca.nome, cor: x.tema?.cor || marca.cor, logo: /^https?:/.test(x.logo || '') ? x.logo : '' } }
  const t = await templateFor(j.kind, j.businessId || null), vars = { app: pub(), empresa: marca.nome, ...j.vars }
  const corpo = fill(j.corpo || t.corpo, vars), subject = fill(j.subject || t.assunto, vars).replace(/\s+/g, ' ').trim().slice(0, 200)
  const sair = j.userId && !['recuperacao', 'seguranca', 'confirmacao', 'teste'].includes(j.kind) ? `${pub()}/api/v2/email/sair?u=${j.userId}&k=${j.kind}&s=${unsubSig(j.userId, j.kind)}` : ''
  const rodape = `${j.businessId ? `Enviado em nome de ${esc(marca.nome)} pelo Meu Assistente.` : 'Enviado pelo Meu Assistente.'}${sair ? ` <a href="${sair}" style="color:#8a90a0">Não quero mais receber este tipo de e-mail</a>.` : ''}`
  const html = renderHtml(corpo, marca, rodape), text = toText(corpo) + (sair ? `\n\nPara não receber mais: ${sair}` : '')
  try {
    await q('INSERT INTO email_queue (business_id, user_id, kind, to_addr, subject, html, text, dedupe_key, status, created_at, next_attempt_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)',
      [j.businessId || null, j.userId || null, j.kind, j.to.trim().toLowerCase(), subject, html, text, j.dedupe || null, 'pendente', nowIso()])
  } catch (e: any) { if (/unique|duplicate/i.test(String(e?.message))) return { queued: false, motivo: 'já enviado (duplicidade evitada)' }; throw e }
  const row = await one('SELECT id FROM email_queue WHERE to_addr = $1 ORDER BY id DESC LIMIT 1', [j.to.trim().toLowerCase()])
  void processQueue().catch((e) => console.error('[email] fila:', e?.message))
  return { queued: true, id: row ? Number(row.id) : undefined }
}
export const unsubSig = (uid: number, kind: string) => createHmac('sha256', process.env.SETTINGS_KEY || process.env.SESSION_SECRET || config.databaseUrl || 'meu-assistente').update(`sair:${uid}:${kind}`).digest('hex').slice(0, 24)

/* ---------- provedores reais ---------- */
async function providerFor(businessId: number | null) {
  const c = await mailCfg()
  if (businessId) { // empresa com remetente próprio (SMTP dela)
    const b = await one('SELECT data FROM businesses WHERE id = $1', [businessId]); const e = J<any>(b?.data, {}).email || {}
    if (e.smtpProprio && e.smtp?.host && e.remetenteEmail) return { nome: 'smtp-empresa', from: e.remetenteEmail, fromName: e.remetenteNome || J<any>(b?.data, {}).empresa, replyTo: e.responderPara || '', smtp: { ...e.smtp, senha: await unseal(e.smtp.senha || '') } as SmtpCfg, limites: { hora: Number(e.limiteHora) || 30, dia: Number(e.limiteDia) || 150 }, businessScope: businessId }
    const x = J<any>(b?.data, {})
    return { ...(await platformProvider(c)), fromName: e.remetenteNome || x.empresa || c.remetenteNome, replyTo: validEmail(e.responderPara) ? e.responderPara : validEmail(x.email || '') ? x.email : c.responderPara, businessScope: null }
  }
  return { ...(await platformProvider(c)), businessScope: null }
}
async function platformProvider(c: any) {
  const base = { from: c.remetenteEmail, fromName: c.remetenteNome, replyTo: c.responderPara, limites: { hora: Number(c.limiteHora) || 50, dia: Number(c.limiteDia) || 300 } }
  if (c.provedor === 'hostinger_api') return { ...base, nome: 'hostinger_api', api: { token: await unseal(c.api.token || ''), mailboxId: c.api.mailboxId } }
  if (c.provedor === 'resend') return { ...base, nome: 'resend', from: c.remetenteEmail || config.mail.from }
  return { ...base, nome: 'smtp', smtp: { ...c.smtp, port: Number(c.smtp.port) || 465, senha: await unseal(c.smtp.senha || '') } as SmtpCfg }
}
const encWord = (s: string) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${Buffer.from(s).toString('base64')}?=`)
const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64').replace(/.{76}/g, '$&\r\n')
export function buildMime(o: { from: string; fromName?: string; to: string; replyTo?: string; subject: string; html: string; text: string; unsub?: string }) {
  const bnd = 'ma_' + randomUUID().replace(/-/g, ''), dom = (o.from.split('@')[1] || 'meuassistente.chat')
  const h = [`From: ${o.fromName ? `"${encWord(o.fromName).replace(/"/g, '')}" ` : ''}<${o.from}>`, `To: <${o.to}>`, o.replyTo ? `Reply-To: <${o.replyTo}>` : '', `Subject: ${encWord(o.subject)}`, `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`, `Message-ID: <${randomUUID()}@${dom}>`, 'MIME-Version: 1.0', o.unsub ? `List-Unsubscribe: <${o.unsub}>` : '', `Content-Type: multipart/alternative; boundary="${bnd}"`].filter(Boolean)
  return `${h.join('\r\n')}\r\n\r\n--${bnd}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${b64(o.text)}\r\n--${bnd}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${b64(o.html)}\r\n--${bnd}--\r\n`
}
const HAPI = () => (process.env.HOSTINGER_MAIL_API_BASE || 'https://api.mail.hostinger.com').replace(/\/$/, '')
/** Envio real pelo provedor. Erros: permanent=true não tenta de novo (endereço/credencial/configuração). */
async function deliver(p: any, m: { to: string; subject: string; html: string; text: string; unsub?: string }) {
  if (!p.from || !validEmail(p.from)) throw new SmtpError('Remetente não configurado no painel (E-mails → Remetente).', 0, true)
  if (p.nome === 'smtp' || p.nome === 'smtp-empresa') {
    if (!p.smtp?.host) throw new SmtpError('Servidor SMTP não configurado.', 0, true)
    const r = await smtpSend({ ...p.smtp, heloName: p.from.split('@')[1] }, p.from, m.to, buildMime({ ...m, from: p.from, fromName: p.fromName, replyTo: p.replyTo }))
    return { id: r.resposta }
  }
  if (p.nome === 'hostinger_api') { // Hostinger Mail API: POST /api/v1/mailboxes/{mailboxResourceId}/send
    if (!p.api.token || !p.api.mailboxId) throw new SmtpError('Token ou caixa da Hostinger Mail API não configurados.', 0, true)
    const send = (body: any) => fetch(`${HAPI()}/api/v1/mailboxes/${encodeURIComponent(p.api.mailboxId)}/send`, { method: 'POST', headers: { Authorization: `Bearer ${p.api.token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    let r = await send({ to: [m.to], subject: m.subject, text: m.text, html: m.html })
    if (r.status === 422 || r.status === 400) { const t = await r.text().catch(() => ''); if (/html/i.test(t)) r = await send({ to: [m.to], subject: m.subject, text: m.text }); else throw new SmtpError('Hostinger Mail API recusou: ' + t.slice(0, 200), r.status, true) }
    if (r.status === 401 || r.status === 403) throw new SmtpError('Hostinger Mail API recusou o token (401/403).', r.status, true)
    if (r.status === 429) throw new SmtpError('Limite da Hostinger Mail API atingido (429). Nova tentativa mais tarde.', 429)
    if (!r.ok) throw new SmtpError(`Hostinger Mail API respondeu ${r.status}.`, r.status, r.status < 500)
    const j: any = await r.json().catch(() => ({})); return { id: String(j.id || j.messageId || j.data?.id || 'aceito') }
  }
  if (p.nome === 'resend') {
    if (!config.mail.resendKey) throw new SmtpError('RESEND_API_KEY não configurada no .env.', 0, true)
    const r = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${config.mail.resendKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: p.fromName ? `${p.fromName} <${p.from}>` : p.from, to: [m.to], reply_to: p.replyTo || undefined, subject: m.subject, html: m.html, text: m.text }) })
    if (!r.ok) throw new SmtpError(`Resend respondeu ${r.status}.`, r.status, r.status >= 400 && r.status < 500 && r.status !== 429)
    const j: any = await r.json().catch(() => ({})); return { id: String(j.id || 'aceito') }
  }
  throw new SmtpError('Provedor de e-mail desconhecido.', 0, true)
}
const BACKOFF = [60, 300, 1800, 7200, 21600] // segundos: 1 min, 5 min, 30 min, 2 h, 6 h
let busy = false
/** Processa a fila respeitando os limites configurados (por hora e por dia) de cada remetente. */
export async function processQueue(now = new Date()) {
  if (busy) return; busy = true
  try {
    const c = await mailCfg()
    const due = await q("SELECT * FROM email_queue WHERE status = 'pendente' AND next_attempt_at <= $1 ORDER BY id LIMIT 20", [now.toISOString()])
    for (const e of due) {
      const p: any = await providerFor(e.business_id ? Number(e.business_id) : null)
      const own = p.nome === 'smtp-empresa'
      if (!own && !c.ativo && e.kind !== 'teste') { await q("UPDATE email_queue SET last_error = $1 WHERE id = $2", ['Envios desativados no painel.', e.id]); continue }
      const scope = own ? 'business_id = ' + Number(e.business_id) : "(provider IS NULL OR provider <> 'smtp-empresa')"
      const h1 = Number((await q(`SELECT COUNT(*) AS n FROM email_queue WHERE status = 'enviado' AND sent_at >= $1 AND ${scope}`, [new Date(now.getTime() - 3600_000).toISOString()]))[0].n)
      const d1 = Number((await q(`SELECT COUNT(*) AS n FROM email_queue WHERE status = 'enviado' AND sent_at >= $1 AND ${scope}`, [new Date(now.getTime() - 86400_000).toISOString()]))[0].n)
      if (h1 >= p.limites.hora || d1 >= p.limites.dia) { await q('UPDATE email_queue SET next_attempt_at = $1, last_error = $2 WHERE id = $3', [new Date(now.getTime() + (d1 >= p.limites.dia ? 3600_000 : 600_000)).toISOString(), `Limite do provedor atingido (${h1}/${p.limites.hora} por hora, ${d1}/${p.limites.dia} por dia). Aguardando.`, e.id]); continue }
      const claim = await q("UPDATE email_queue SET status = 'enviando', attempts = attempts + 1 WHERE id = $1 AND status = 'pendente' RETURNING id", [e.id]).catch(() => [])
      if (Array.isArray(claim) && !claim.length) continue
      try {
        const unsub = (/href="([^"]*\/api\/v2\/email\/sair[^"]*)"/.exec(e.html) || [])[1]?.replace(/&amp;/g, '&')
        const r = await deliver(p, { to: e.to_addr, subject: e.subject, html: e.html, text: e.text, unsub })
        await q("UPDATE email_queue SET status = 'enviado', sent_at = $1, provider = $2, provider_id = $3, last_error = NULL WHERE id = $4", [nowIso(), p.nome, String(r.id || '').slice(0, 200), e.id])
      } catch (err: any) {
        const tent = Number(e.attempts) + 1, perm = err instanceof SmtpError && err.permanent
        const msg = String(err?.message || err).replace(/(senha|password|token)[^\s]*/gi, '$1***').slice(0, 300)
        if (perm || tent >= BACKOFF.length + 1) await q("UPDATE email_queue SET status = 'falhou', last_error = $1, provider = $2 WHERE id = $3", [msg, p.nome, e.id])
        else await q("UPDATE email_queue SET status = 'pendente', next_attempt_at = $1, last_error = $2, provider = $3 WHERE id = $4", [new Date(now.getTime() + BACKOFF[tent - 1] * 1000).toISOString(), msg, p.nome, e.id])
        console.error(`[email] envio #${e.id} (${e.kind}) falhou: ${msg}`)
      }
    }
  } finally { busy = false }
}
/** Compatibilidade: usado pela recuperação de senha antiga. */
export async function sendMail(to: string, subject: string, html: string, text: string) { const r = await enqueueMail({ kind: 'notificacoes', to, subject, corpo: text }); return { sent: r.queued } }

/* ---------- testes de conexão e DNS ---------- */
export async function testConnection(businessId: number | null = null) {
  const p: any = await providerFor(businessId)
  try {
    if (p.nome === 'smtp' || p.nome === 'smtp-empresa') { if (!p.smtp?.host) return { ok: false, mensagem: 'Preencha o servidor SMTP.' }; await smtpVerify(p.smtp); return { ok: true, mensagem: `Conectado e autenticado em ${p.smtp.host}:${p.smtp.port} (${p.smtp.seguranca.toUpperCase()}).` } }
    if (p.nome === 'hostinger_api') { const r = await fetch(`${HAPI()}/api/v1/me`, { headers: { Authorization: `Bearer ${p.api.token}` } }); const j: any = await r.json().catch(() => ({})); if (!r.ok) return { ok: false, mensagem: `A Hostinger Mail API respondeu ${r.status}. Confira o token (hPanel → API).` }; const caixas = (j.mailboxes || j.data?.mailboxes || j.data || []).map?.((m: any) => ({ id: m.resourceId || m.resource_id || m.id, email: m.email || m.address || m.name })) || []; return { ok: true, mensagem: `Token válido. ${caixas.length} caixa(s) disponível(is).`, caixas } }
    if (p.nome === 'resend') return { ok: !!config.mail.resendKey, mensagem: config.mail.resendKey ? 'Chave do Resend presente no .env (o teste real é enviar um e-mail).' : 'RESEND_API_KEY não está no .env.' }
  } catch (e: any) { return { ok: false, mensagem: String(e?.message || e) } }
  return { ok: false, mensagem: 'Provedor não reconhecido.' }
}
/** Verifica SPF, DMARC e DKIM do domínio do remetente nos registros DNS públicos. */
export async function checkDns(dominio: string, seletor = '') {
  const txt = async (n: string) => { try { return (await resolveTxt(n)).map((r) => r.join('')) } catch { return [] as string[] } }
  const spf = (await txt(dominio)).find((t) => /^v=spf1/i.test(t)) || ''
  const dmarc = (await txt('_dmarc.' + dominio)).find((t) => /^v=DMARC1/i.test(t)) || ''
  const sels = seletor ? [seletor] : ['default', 'hostingermail1', 'hostingermail2', 'hostingermail-a', 'hostingermail-b', 'mail', 'dkim', 'resend']
  let dkim = '', dkimSel = ''; for (const s of sels) { const t = (await txt(`${s}._domainkey.${dominio}`)).find((x) => /v=DKIM1|k=rsa|p=/i.test(x)); if (t) { dkim = t; dkimSel = s; break } }
  return { dominio, spf: spf || null, dmarc: dmarc || null, dkim: dkim ? { seletor: dkimSel, registro: dkim.slice(0, 120) + '…' } : null,
    dicas: [!spf ? `Crie um TXT em ${dominio}: v=spf1 include:_spf.mail.hostinger.com ~all (Hostinger Email) — ou o include do seu provedor; para o Postfix da VPS: v=spf1 ip4:IP_DA_VPS ~all.` : '', !dkim ? 'Ative o DKIM no painel do provedor (Hostinger: hPanel → E-mails → Configurações DNS) e publique o registro TXT indicado; no Postfix próprio use OpenDKIM.' : '', !dmarc ? `Crie um TXT em _dmarc.${dominio}: v=DMARC1; p=none; rua=mailto:dmarc@${dominio} (depois de validar, mude para p=quarantine).` : ''].filter(Boolean) }
}
export async function saveCfg(b: any) {
  const c = await mailCfg()
  const smtp = { host: String(b.smtp?.host ?? c.smtp.host).trim().slice(0, 120), port: Math.min(65535, Math.max(1, Number(b.smtp?.port ?? c.smtp.port) || 465)), seguranca: ['ssl', 'starttls', 'nenhuma'].includes(b.smtp?.seguranca) ? b.smtp.seguranca : c.smtp.seguranca, usuario: String(b.smtp?.usuario ?? c.smtp.usuario).trim().slice(0, 160), senha: b.smtp?.senha ? await seal(String(b.smtp.senha)) : c.smtp.senha }
  const api = { token: b.api?.token ? await seal(String(b.api.token).trim()) : c.api.token, mailboxId: String(b.api?.mailboxId ?? c.api.mailboxId).trim().slice(0, 80) }
  const remetenteEmail = String(b.remetenteEmail ?? c.remetenteEmail).trim().toLowerCase()
  if (remetenteEmail && !validEmail(remetenteEmail)) throw new Error('E-mail do remetente inválido.')
  const responderPara = String(b.responderPara ?? c.responderPara).trim().toLowerCase()
  if (responderPara && !validEmail(responderPara)) throw new Error('E-mail de resposta inválido.')
  const eventos = { ...c.eventos }; for (const k of Object.keys(KINDS)) if (b.eventos && k in b.eventos) eventos[k] = !!b.eventos[k]
  return { ativo: b.ativo === undefined ? c.ativo : !!b.ativo, provedor: ['smtp', 'hostinger_api', 'resend'].includes(b.provedor) ? b.provedor : c.provedor, remetenteNome: String(b.remetenteNome ?? c.remetenteNome).trim().slice(0, 80) || 'Meu Assistente', remetenteEmail, responderPara, smtp, api, limiteHora: Math.min(10000, Math.max(1, Math.round(Number(b.limiteHora ?? c.limiteHora) || 50))), limiteDia: Math.min(100000, Math.max(1, Math.round(Number(b.limiteDia ?? c.limiteDia) || 300))), eventos }
}

export const emailConfirmLink = (uid: number) => `${pub()}/api/v2/email/confirmar?u=${uid}&s=${unsubSig(uid, 'confirmar')}`
