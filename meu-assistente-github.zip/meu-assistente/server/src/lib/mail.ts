import { config } from '../config.js'

/** Envia e-mail via Resend (mesmo provedor do sistema original). Sem chave, registra no log do servidor. */
export async function sendMail(to: string, subject: string, html: string, text: string): Promise<{ sent: boolean }> {
  if (!config.mail.resendKey) {
    console.warn(`[mail] RESEND_API_KEY não configurada — e-mail NÃO enviado para ${to}. Assunto: ${subject}\n${text}`)
    return { sent: false }
  }
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${config.mail.resendKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: config.mail.from, to: [to], subject, html, text }),
  }).catch((e) => { console.error('[mail] falha de rede:', e.message); return null })
  if (!r || !r.ok) { console.error('[mail] Resend recusou o envio:', r?.status, await r?.text().catch(() => '')); return { sent: false } }
  return { sent: true }
}
