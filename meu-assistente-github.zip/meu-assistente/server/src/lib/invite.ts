// Mensagem de compartilhamento de compromissos (WhatsApp e outros): NÃO revela data, horário nem detalhes —
// eles ficam só dentro do link individual. Modelo editável no painel (Páginas e links → Convites).
import { getConfig } from './settings.js'
export const INVITE_DEFAULT = 'Olá, {nome_cliente}! {nome_proprietario} compartilhou um compromisso com você pelo Meu Assistente. Acesse o link para conferir os detalhes e ativar seu lembrete.\n\n{link}'
export let INVITE_TPL = INVITE_DEFAULT
export async function refreshInvite() { const c = await getConfig<any>('invite_msg', {}).catch(() => ({})); INVITE_TPL = String(c.texto || '').includes('{link}') ? c.texto : INVITE_DEFAULT; return INVITE_TPL }
export async function inviteText(nome: string, link: string, cliente = '') { await refreshInvite(); return render(INVITE_TPL, nome, link, cliente) }
/** {nome_cliente} vazio vira só "Olá!" — nunca inventa nome. */
export const render = (tpl: string, nome: string, link: string, cliente = '') => String(tpl).replace(/\{nome_proprietario\}/g, String(nome || 'um profissional').split(' ')[0]).replace(/\{link\}/g, link).replace(/,?\s*\{nome_cliente\}\s*!/g, cliente ? `, ${String(cliente).split(' ')[0]}!` : '!').replace(/\{nome_cliente\}/g, String(cliente || '').split(' ')[0])
