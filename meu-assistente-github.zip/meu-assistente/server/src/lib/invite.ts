// Mensagem de compartilhamento de compromissos (WhatsApp e outros): NÃO revela data, horário nem detalhes —
// eles ficam só dentro do link individual. Modelo editável no painel (Páginas e links → Convites).
import { getConfig } from './settings.js'
export const INVITE_DEFAULT = 'Olá! Você tem um compromisso agendado com {nome_proprietario}.\n\nPara conferir os detalhes do seu compromisso e não correr o risco de esquecer, acesse o link abaixo e ative gratuitamente seu lembrete pelo Meu Assistente.\n\n{link}\n\nSeu compromisso sempre em dia com o Meu Assistente!'
export let INVITE_TPL = INVITE_DEFAULT
export async function refreshInvite() { const c = await getConfig<any>('invite_msg', {}).catch(() => ({})); INVITE_TPL = String(c.texto || '').includes('{link}') ? c.texto : INVITE_DEFAULT; return INVITE_TPL }
export async function inviteText(nome: string, link: string) { await refreshInvite(); return render(INVITE_TPL, nome, link) }
export const render = (tpl: string, nome: string, link: string) => String(tpl).replace(/\{nome_proprietario\}/g, String(nome || 'um profissional').split(' ').slice(0, 2).join(' ')).replace(/\{link\}/g, link)
