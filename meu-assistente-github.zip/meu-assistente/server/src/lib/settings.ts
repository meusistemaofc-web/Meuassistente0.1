// Configurações persistentes (tabela app_config) e cofre para chaves secretas (AES-256-GCM).
import { createCipheriv, createDecipheriv, randomBytes, createHash } from 'node:crypto'
import { one, q, J, nowIso } from '../db/index.js'

export async function getConfig<T>(key: string, fallback: T): Promise<T> {
  const r = await one('SELECT value FROM app_config WHERE key = $1', [key])
  return r ? J<T>(r.value, fallback) : fallback
}
export async function setConfig(key: string, value: unknown) {
  const v = JSON.stringify(value)
  const ex = await one('SELECT key FROM app_config WHERE key = $1', [key])
  if (ex) await q('UPDATE app_config SET value = $1, updated_at = $2 WHERE key = $3', [v, nowIso(), key])
  else await q('INSERT INTO app_config (key, value, updated_at) VALUES ($1,$2,$3)', [key, v, nowIso()])
}

let vaultKey: Buffer | null = null
async function key(): Promise<Buffer> {
  if (vaultKey) return vaultKey
  const s = process.env.APP_SECRET || ''
  if (s.length >= 16) return (vaultKey = createHash('sha256').update(s).digest())
  // Sem APP_SECRET: gera uma chave aleatória uma única vez e guarda no banco.
  let k = await getConfig<string>('vault-key', '')
  if (!k) { k = randomBytes(32).toString('hex'); await setConfig('vault-key', k) }
  return (vaultKey = createHash('sha256').update(k).digest())
}
export async function seal(plain: string): Promise<string> {
  if (!plain) return ''
  const iv = randomBytes(12)
  const c = createCipheriv('aes-256-gcm', await key(), iv)
  const enc = Buffer.concat([c.update(plain, 'utf8'), c.final()])
  return 'v1:' + Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64')
}
export async function unseal(sealed: string): Promise<string> {
  if (!sealed || !sealed.startsWith('v1:')) return ''
  try {
    const b = Buffer.from(sealed.slice(3), 'base64')
    const d = createDecipheriv('aes-256-gcm', await key(), b.subarray(0, 12))
    d.setAuthTag(b.subarray(12, 28))
    return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8')
  } catch { return '' }
}
export const maskSecret = (s: string) => (s ? s.slice(0, 6) + '••••' + s.slice(-4) : '')
