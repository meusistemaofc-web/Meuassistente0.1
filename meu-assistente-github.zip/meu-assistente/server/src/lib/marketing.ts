// Acompanhamento de convites + Central de Marketing.
// Regras: lembrete ativado NUNCA é consentimento de marketing; consentimento é separado, opcional, com data e origem,
// revogável a qualquer momento. Cada dono só vê e alcança quem autorizou A ELE. Limites vêm do plano da empresa
// (editáveis no painel) e são conferidos no servidor a cada criação e a cada envio.
import { createHmac } from 'node:crypto'
import { q, one, J, nowIso } from '../db/index.js'
import { getConfig } from './settings.js'
import { notify } from './notify.js'
import { pub } from './publicurl.js'
import { fail } from './http.js'

export const MKT_DEFAULT: Record<string, any> = {
  _sem_plano: { acesso: false, campanhasPeriodo: 0, notificacoesPeriodo: 0, agendar: false, segmentacao: false, relatorios: false },
  n1: { acesso: false, campanhasPeriodo: 0, notificacoesPeriodo: 0, agendar: false, segmentacao: false, relatorios: false },
  n2: { acesso: true, campanhasPeriodo: 1, notificacoesPeriodo: 100, agendar: false, segmentacao: false, relatorios: false },
  n3: { acesso: true, campanhasPeriodo: 4, notificacoesPeriodo: 500, agendar: true, segmentacao: true, relatorios: true },
  n4: { acesso: true, campanhasPeriodo: 15, notificacoesPeriodo: 3000, agendar: true, segmentacao: true, relatorios: true },
}
export async function mktOn() { return (await getConfig<any>('mkt_global', {})).ativo !== false }
export async function mktPlans() { return { ...MKT_DEFAULT, ...(await getConfig<any>('mkt_plans', {})) } }
const sig = (s: string) => createHmac('sha256', process.env.SETTINGS_KEY || process.env.SESSION_SECRET || 'meu-assistente-mkt').update(s).digest('hex').slice(0, 20)

/* ---------- acompanhamento ---------- */
export async function recordActivation(token: string, ownerId: number, ownerItemId: number, guestId: number, guestItemId: number, shareCreatedAt: string) {
  const g = await one('SELECT created_at FROM users WHERE id = $1', [guestId])
  const novo = !!g && Date.parse(g.created_at) >= Date.parse(shareCreatedAt || '1970-01-01') // conta criada depois do convite
  try { await q('INSERT INTO invite_activations (token, owner_id, owner_item_id, guest_id, guest_item_id, conta_nova, ativado_em) VALUES ($1,$2,$3,$4,$5,$6,$7)', [token, ownerId, ownerItemId, guestId, guestItemId, novo, nowIso()]) } catch { /* já registrado */ }
}
/** O que o dono vê dentro do compromisso: só dados do próprio convite e do consentimento dado a ele. */
export async function trackingOf(ownerId: number, itemId: number) {
  const it = await one("SELECT id, status, data FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [itemId, ownerId]); if (!it) return null
  const d = J<any>(it.data, {})
  const acts = await q('SELECT a.*, u.name FROM invite_activations a JOIN users u ON u.id = a.guest_id WHERE a.owner_id = $1 AND a.owner_item_id = $2 ORDER BY a.ativado_em', [ownerId, itemId])
  const out = []
  for (const a of acts) {
    const c = await one('SELECT status, criado_em, revogado_em, origem FROM marketing_consents WHERE owner_id = $1 AND user_id = $2', [ownerId, a.guest_id])
    const gi = a.guest_item_id ? await one('SELECT status FROM items WHERE id = $1', [a.guest_item_id]) : null
    out.push({ nome: String(a.name || '').split(' ')[0] + (String(a.name || '').split(' ')[1] ? ' ' + String(a.name).split(' ')[1][0] + '.' : ''), criouConta: !!a.conta_nova, contaExistente: !a.conta_nova, lembreteAtivo: !!gi && gi.status !== 'cancelled', ativadoEm: a.ativado_em, marketing: c ? { status: c.status, desde: c.criado_em, revogadoEm: c.revogado_em, origem: c.origem } : { status: 'nao_autorizado' } })
  }
  return { compromisso: { id: Number(it.id), titulo: d.title, situacao: it.status === 'cancelled' ? 'cancelado' : it.status === 'done' ? 'concluido' : 'agendado' }, compartilhado: !!d.shareToken, convidados: out }
}
/* ---------- consentimento ---------- */
export async function setConsent(ownerId: number, userId: number, aceito: boolean, origem: string) {
  if (ownerId === userId) return { status: 'proprio' }
  const ex = await one('SELECT id, status FROM marketing_consents WHERE owner_id = $1 AND user_id = $2', [ownerId, userId])
  if (aceito) { if (ex) await q("UPDATE marketing_consents SET status = 'ativo', origem = $1, criado_em = $2, revogado_em = NULL WHERE id = $3", [origem.slice(0, 80), nowIso(), ex.id]); else await q("INSERT INTO marketing_consents (owner_id, user_id, status, origem, criado_em) VALUES ($1,$2,'ativo',$3,$4)", [ownerId, userId, origem.slice(0, 80), nowIso()]) }
  else if (ex) await q("UPDATE marketing_consents SET status = 'revogado', revogado_em = $1 WHERE id = $2", [nowIso(), ex.id])
  return { status: aceito ? 'ativo' : 'revogado' }
}
export const unsubLink = (ownerId: number, userId: number) => `${pub()}/api/v2/marketing/sair?o=${ownerId}&u=${userId}&s=${sig(`sair:${ownerId}:${userId}`)}`
export const checkUnsub = (o: number, u: number, s: string) => s === sig(`sair:${o}:${u}`)

/* ---------- plano, período e consumo (sempre calculados no servidor) ---------- */
export async function ownerPlan(ownerId: number) {
  const b = await one("SELECT * FROM businesses WHERE owner_id = $1 AND status = 'ativo' ORDER BY id DESC LIMIT 1", [ownerId])
  const P = await mktPlans(), pid = b && (!b.expires_at || Date.parse(b.expires_at) > Date.now()) ? String(b.plan_id) : '_sem_plano'
  const lim = { ...MKT_DEFAULT._sem_plano, ...(P[pid] || P._sem_plano) }
  if (!(await mktOn())) lim.acesso = false // desligada pelo administrador para todas as empresas
  const ads: any[] = await getConfig<any[]>('ad_plans', []), plano = ads.find((x) => x.id === pid)
  const dias = Number(plano?.dias) || 30, fim = b?.expires_at ? Date.parse(b.expires_at) : Date.now() + 30 * 86400_000
  const inicio = new Date(Math.min(Date.now(), fim - dias * 86400_000)).toISOString()
  const camp = Number((await q("SELECT COUNT(*) AS n FROM mkt_campaigns WHERE owner_id = $1 AND criada_em >= $2 AND status <> 'cancelada'", [ownerId, inicio]))[0].n)
  const notif = Number((await q("SELECT COUNT(*) AS n FROM mkt_sends WHERE owner_id = $1 AND criado_em >= $2 AND status = 'enviado'", [ownerId, inicio]))[0].n)
  return { business: b ? { id: Number(b.id), empresa: J<any>(b.data, {}).empresa, planId: pid } : null, limites: lim, periodo: { inicio, fim: new Date(fim).toISOString() }, uso: { campanhas: camp, notificacoes: notif } }
}
const upgrade = (msg: string) => fail(402, `${msg} Faça upgrade do plano da sua empresa para liberar mais.`, 'plan_limit')

/* ---------- público e segmentação ---------- */
export async function systemAudience() {
  return (await q("SELECT id, settings FROM users WHERE status = 'active'")).filter((u: any) => { const st = J<any>(u.settings, {}); return st.notificationsEnabled !== false && st.promoSistemaOptOut !== true }).map((u: any) => Number(u.id))
}
export async function createSystemCampaign(adminId: number, b: any) {
  const titulo = String(b.titulo || '').trim().slice(0, 80), mensagem = String(b.mensagem || '').trim().slice(0, 500)
  if (titulo.length < 3 || mensagem.length < 5) fail(400, 'Escreva o título e a mensagem.', 'invalid')
  const link = /^https?:\/\//.test(String(b.link || '')) || /^\/[\w/?=&.-]*$/.test(String(b.link || '')) ? String(b.link).slice(0, 300) : ''
  let quando = new Date(); if (b.agendarPara) { quando = new Date(b.agendarPara); if (isNaN(quando.getTime()) || quando.getTime() < Date.now() - 60_000) fail(400, 'Escolha uma data e hora futuras.', 'invalid') }
  const total = (await systemAudience()).length; if (!total) fail(400, 'Nenhum usuário com notificações ativas.', 'no_audience')
  await q('INSERT INTO mkt_campaigns (owner_id, business_id, titulo, mensagem, link, segmento, status, agendada_para, total, criada_em) VALUES ($1,NULL,$2,$3,$4,$5,$6,$7,$8,$9)', [adminId, titulo, mensagem, link, JSON.stringify({ sistema: true }), 'agendada', quando.toISOString(), total, nowIso()])
  const c = await one('SELECT * FROM mkt_campaigns WHERE owner_id = $1 ORDER BY id DESC LIMIT 1', [adminId])
  if (quando.getTime() <= Date.now() + 5000) void runCampaigns().catch((e) => console.error('[marketing]', e?.message))
  return c
}
export async function audience(ownerId: number, seg: any = {}) {
  let rows = await q("SELECT c.user_id, c.origem, c.criado_em FROM marketing_consents c JOIN users u ON u.id = c.user_id WHERE c.owner_id = $1 AND c.status = 'ativo' AND u.status = 'active'", [ownerId])
  if (seg.origem === 'convite') rows = rows.filter((r: any) => /^convite/.test(r.origem))
  if (seg.origem === 'pedido') rows = rows.filter((r: any) => /^pedido/.test(r.origem))
  if (seg.desdeDias > 0) rows = rows.filter((r: any) => Date.parse(r.criado_em) >= Date.now() - seg.desdeDias * 86400_000)
  if (seg.compradores) { const bs = await q('SELECT id FROM businesses WHERE owner_id = $1', [ownerId]); const ids = new Set<number>(); for (const b of bs) for (const o of await q("SELECT customer_id FROM orders WHERE business_id = $1 AND status = 'concluido'", [b.id])) ids.add(Number(o.customer_id)); rows = rows.filter((r: any) => ids.has(Number(r.user_id))) }
  return rows.map((r: any) => Number(r.user_id))
}
/* ---------- campanhas ---------- */
export async function createCampaign(ownerId: number, b: any) {
  const pl = await ownerPlan(ownerId), L = pl.limites
  if (!L.acesso || !pl.business) upgrade('A Central de Marketing não está disponível no plano atual.')
  if (pl.uso.campanhas >= L.campanhasPeriodo) upgrade(`Você já usou as ${L.campanhasPeriodo} campanhas deste período.`)
  const titulo = String(b.titulo || '').trim().slice(0, 80), mensagem = String(b.mensagem || '').trim().slice(0, 500)
  if (titulo.length < 3 || mensagem.length < 5) fail(400, 'Escreva o título e a mensagem da campanha.', 'invalid')
  const link = /^https?:\/\//.test(String(b.link || '')) ? String(b.link).slice(0, 300) : ''
  let quando = new Date(); if (b.agendarPara) { if (!L.agendar) upgrade('Programar campanhas não está disponível no plano atual.'); quando = new Date(b.agendarPara); if (isNaN(quando.getTime()) || quando.getTime() < Date.now() - 60_000) fail(400, 'Escolha uma data e hora futuras.', 'invalid') }
  const seg = L.segmentacao ? { origem: ['convite', 'pedido'].includes(b.segmento?.origem) ? b.segmento.origem : '', desdeDias: Math.max(0, Math.round(Number(b.segmento?.desdeDias) || 0)), compradores: !!b.segmento?.compradores } : {}
  if (!L.segmentacao && b.segmento && (b.segmento.origem || b.segmento.desdeDias || b.segmento.compradores)) upgrade('A segmentação de clientes não está disponível no plano atual.')
  const publico = await audience(ownerId, seg)
  if (!publico.length) fail(400, 'Nenhum cliente autorizou receber comunicações da sua empresa neste segmento ainda.', 'no_audience')
  if (pl.uso.notificacoes + publico.length > L.notificacoesPeriodo) upgrade(`Esta campanha teria ${publico.length} envios e restam ${Math.max(0, L.notificacoesPeriodo - pl.uso.notificacoes)} no período.`)
  await q('INSERT INTO mkt_campaigns (owner_id, business_id, titulo, mensagem, link, segmento, status, agendada_para, total, criada_em) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)', [ownerId, pl.business!.id, titulo, mensagem, link, JSON.stringify(seg), 'agendada', quando.toISOString(), publico.length, nowIso()])
  const c = await one('SELECT * FROM mkt_campaigns WHERE owner_id = $1 ORDER BY id DESC LIMIT 1', [ownerId])
  if (quando.getTime() <= Date.now() + 5000) void runCampaigns().catch((e) => console.error('[marketing]', e?.message))
  return c
}
/** Hora local entre 8h e 21h: campanhas não acordam ninguém. */
const horaBoa = (d = new Date()) => { const h = new Date(d.toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).getHours(); return h >= 8 && h < 21 }
let rodando = false
/** Agendador: executa campanhas devidas (mesmo com o dono desconectado), sem duplicar e respeitando limites. */
export async function runCampaigns(now = new Date(), forcarHorario = false) {
  if (rodando) return; rodando = true
  try {
    const due = await q("SELECT * FROM mkt_campaigns WHERE status IN ('agendada','enviando') AND agendada_para <= $1 ORDER BY id LIMIT 10", [now.toISOString()])
    for (const c of due) {
      if (!forcarHorario && !horaBoa(now)) { await q("UPDATE mkt_campaigns SET erro = $1 WHERE id = $2", ['Aguardando horário comercial (8h às 21h).', c.id]); continue }
      await q("UPDATE mkt_campaigns SET status = 'enviando', erro = NULL WHERE id = $1", [c.id])
      const sist = !!J<any>(c.segmento, {}).sistema
      const pl: any = sist ? { limites: { notificacoesPeriodo: Infinity }, uso: { notificacoes: 0 } } : await ownerPlan(Number(c.owner_id)), b = c.business_id ? await one('SELECT data FROM businesses WHERE id = $1', [c.business_id]) : null, empresa = sist ? 'Meu Assistente' : J<any>(b?.data, {}).empresa || 'Empresa parceira'
      if (!sist && !(await mktOn())) { await q("UPDATE mkt_campaigns SET status = 'cancelada', erro = $1 WHERE id = $2", ['Central de Marketing desligada pelo administrador.', c.id]); continue }
      const publico = sist ? await systemAudience() : await audience(Number(c.owner_id), J<any>(c.segmento, {}))
      let enviados = Number(c.enviados), push = Number(c.push_ok), ign = Number(c.ignorados), usados = pl.uso.notificacoes
      for (const uid of publico) {
        if (usados >= pl.limites.notificacoesPeriodo) { await q("UPDATE mkt_campaigns SET erro = $1 WHERE id = $2", ['Limite de notificações do plano atingido; parte do público não recebeu.', c.id]); break }
        const ja = await one('SELECT id FROM mkt_sends WHERE campaign_id = $1 AND user_id = $2', [c.id, uid]); if (ja) continue
        const u = await one('SELECT settings FROM users WHERE id = $1', [uid]); const st = J<any>(u?.settings, {})
        const recente = await one("SELECT id FROM mkt_sends WHERE owner_id = $1 AND user_id = $2 AND status = 'enviado' AND criado_em >= $3", [c.owner_id, uid, new Date(now.getTime() - 20 * 3600_000).toISOString()])
        if (st.notificationsEnabled === false || recente) { await q('INSERT INTO mkt_sends (campaign_id, owner_id, user_id, status, canal, criado_em) VALUES ($1,$2,$3,$4,$5,$6)', [c.id, c.owner_id, uid, st.notificationsEnabled === false ? 'ignorado_preferencia' : 'ignorado_frequencia', '', nowIso()]); ign++; continue }
        await q('INSERT INTO mkt_sends (campaign_id, owner_id, user_id, status, canal, criado_em) VALUES ($1,$2,$3,$4,$5,$6)', [c.id, c.owner_id, uid, 'enviado', 'app', nowIso()])
        const send = await one('SELECT id FROM mkt_sends WHERE campaign_id = $1 AND user_id = $2', [c.id, uid])
        const temPush = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [uid]).catch(() => [{ n: 0 }]))[0].n) > 0
        await notify(uid, { type: 'promo', title: `${empresa}: ${c.titulo}`, body: c.mensagem, link: `/?mkt=${send!.id}.${sig('c:' + send!.id)}`, ref: `mkt:${c.id}:${uid}` })
        enviados++; usados++; if (temPush) push++
      }
      await q("UPDATE mkt_campaigns SET status = 'concluida', enviados = $1, push_ok = $2, ignorados = $3, concluida_em = $4 WHERE id = $5", [enviados, push, ign, nowIso(), c.id])
    }
  } finally { rodando = false }
}
export async function clickRedirect(sendId: number, s: string) {
  if (s !== sig('c:' + sendId)) return '/'
  const r = await one('SELECT s.*, c.link FROM mkt_sends s JOIN mkt_campaigns c ON c.id = s.campaign_id WHERE s.id = $1', [sendId]); if (!r) return '/'
  if (!r.clicado_em) { await q('UPDATE mkt_sends SET clicado_em = $1 WHERE id = $2', [nowIso(), sendId]); await q('UPDATE mkt_campaigns SET cliques = cliques + 1 WHERE id = $1', [r.campaign_id]) }
  if (r.link) return r.link
  if (!r.business_id && !(await one('SELECT business_id FROM mkt_campaigns WHERE id = $1', [r.campaign_id]))?.business_id) return '/'
  const b = await one('SELECT business_id FROM mkt_campaigns WHERE id = $1', [r.campaign_id]); return b?.business_id ? `/x/empresa/${b.business_id}` : '/'
}
