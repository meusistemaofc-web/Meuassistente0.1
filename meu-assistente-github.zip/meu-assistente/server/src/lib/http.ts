import type { IncomingMessage, ServerResponse } from 'node:http'
import { config } from '../config.js'

export class HttpError extends Error {
  constructor(public status: number, message: string, public code?: string, public field?: string) { super(message) }
}
export const fail = (status: number, message: string, code?: string, field?: string): never => {
  throw new HttpError(status, message, code, field)
}

export interface Ctx {
  req: IncomingMessage
  res: ServerResponse
  method: string
  path: string
  url: URL
  query: URLSearchParams
  ip: string
  body: any
  rawBody?: Buffer
  cookies: Record<string, string>
  setCookies: string[]
  user?: import('./session.js').SessionUser
  session?: import('./session.js').SessionRow
  params: Record<string, string>
}

export function parseCookies(h?: string): Record<string, string> {
  const out: Record<string, string> = {}
  for (const part of (h || '').split(';')) {
    const i = part.indexOf('=')
    if (i < 0) continue
    const k = part.slice(0, i).trim()
    if (k) out[k] = decodeURIComponent(part.slice(i + 1).trim())
  }
  return out
}

export async function readBody(req: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const c of req) {
    size += (c as Buffer).length
    if (size > config.maxBodyBytes) throw new HttpError(413, 'Conteúdo grande demais.', 'payload_too_large')
    chunks.push(c as Buffer)
  }
  return Buffer.concat(chunks)
}

export function sendJson(res: ServerResponse, status: number, data: unknown, extraHeaders: Record<string, string | string[]> = {}) {
  const body = JSON.stringify(data)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extraHeaders,
  })
  res.end(body)
}

export function clientIp(req: IncomingMessage): string {
  if (config.trustProxy) {
    const xf = req.headers['x-forwarded-for']
    if (typeof xf === 'string' && xf) return xf.split(',')[0].trim()
    const xr = req.headers['x-real-ip']
    if (typeof xr === 'string' && xr) return xr
  }
  return req.socket.remoteAddress || ''
}

// Validações simples e reutilizáveis
export const str = (v: unknown, max = 500) => (typeof v === 'string' ? v.trim().slice(0, max) : '')
export const isDate = (v: unknown): v is string => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(Date.parse(v + 'T00:00:00Z'))
export const isTime = (v: unknown): v is string => typeof v === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(v)
export const num = (v: unknown): number | null => {
  const n = typeof v === 'string' ? Number(v.replace(',', '.')) : typeof v === 'number' ? v : NaN
  return Number.isFinite(n) ? n : null
}
