// Dados por usuário dos módulos novos, guardados em JSON (tabela user_modules).
import { one, q, J, nowIso } from '../db/index.js'
import { getConfig } from './settings.js'
import { MODULES_DEFAULT } from './panel-defaults.js'
import { fail } from './http.js'

export async function getUM<T>(userId: number, key: string, fallback: T): Promise<T> {
  const r = await one('SELECT value FROM user_modules WHERE user_id = $1 AND key = $2', [userId, key])
  return r ? J<T>(r.value, fallback) : fallback
}
export async function setUM(userId: number, key: string, value: unknown) {
  const v = JSON.stringify(value)
  const ex = await one('SELECT key FROM user_modules WHERE user_id = $1 AND key = $2', [userId, key])
  if (ex) await q('UPDATE user_modules SET value = $1, updated_at = $2 WHERE user_id = $3 AND key = $4', [v, nowIso(), userId, key])
  else await q('INSERT INTO user_modules (user_id, key, value, updated_at) VALUES ($1,$2,$3,$4)', [userId, key, v, nowIso()])
}
export let MOD_CACHE: Record<string, boolean> = { ...MODULES_DEFAULT }
export async function modules() { MOD_CACHE = { ...MODULES_DEFAULT, ...(await getConfig<Record<string, boolean>>('modules', {})) } as Record<string, boolean>; return MOD_CACHE }
export async function requireModule(name: string) { if (!(await modules())[name]) fail(403, 'Este módulo está desligado pelo administrador.', 'module_disabled') }
