// Identidade do assistente e do criador/CEO (editável no painel e guardada no banco).
// O chat responde por aqui mesmo sem nenhuma IA externa disponível.
import { getConfig } from './settings.js'

export const IDENTITY_DEFAULT = {
  ativo: true,
  nome: 'Wesley Ivaslovck',
  cargo: 'criador, idealizador, fundador e CEO do Conecta e do Meu Assistente',
  texto: `Wesley Ivaslovck é o criador, idealizador, fundador e CEO do Conecta e do Meu Assistente.

Empreendedor por natureza, Wesley construiu sua trajetória unindo criatividade e tecnologia. Além de empresário, é tatuador, uma profissão em que aprendeu na prática o valor do atendimento próximo, da organização da agenda e da gestão de um negócio próprio. Essa vivência o levou a desenvolver soluções digitais que resolvem problemas reais do dia a dia.

Como desenvolvedor de soluções digitais, Wesley acredita que a tecnologia deve simplificar a vida das pessoas. Sua visão é usar inovação, automação e inteligência artificial para facilitar a gestão de empresas — atendimento, catálogo, vendas, agendamentos e finanças — e a rotina de cada pessoa, com lembretes, compromissos, tarefas e controle financeiro em um só lugar.

O Meu Assistente nasceu dessa visão: um assistente inteligente, acessível e prático, criado para que qualquer pessoa ou empresa possa se organizar melhor e ganhar tempo.`,
}
export async function identity() { return { ...IDENTITY_DEFAULT, ...(await getConfig<any>('ceo_identity', {})) } }

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
/** Perguntas sobre quem criou o sistema, quem é o CEO ou quem é o Wesley. */
export function isIdentityQuestion(text: string, nome = IDENTITY_DEFAULT.nome) {
  const s = nrm(text), first = nrm(nome).split(' ')[0], full = nrm(nome)
  if (s.split(' ').length > 18) return false
  return new RegExp(`\\b(quem (te |o |a )?(criou|fez|desenvolveu|idealizou|inventou|programou|construiu|fundou)|quem (e|eh|sao) (o |a |os )?(seu |teu |o )?(criador|criadores|ceo|dono|fundador|desenvolvedor|idealizador|responsavel|presidente)|quem esta por tras|quem (e|eh) (o )?${first}|${full}|sobre o ${first}|sobre ${first}|(seu|teu) criador|criador do (meu assistente|conecta|app|aplicativo|sistema)|ceo do (meu assistente|conecta)|quem criou (o |esse |este )?(app|aplicativo|sistema|meu assistente|conecta|voce|vc))\\b`).test(s)
}
export async function identityReply(text: string) {
  const id = await identity()
  if (!id.ativo || !isIdentityQuestion(text, id.nome)) return null
  const s = nrm(text), quer = /\b(quem e|quem eh|sobre|me fale|conte|historia|trajetoria)\b/.test(s) && new RegExp(nrm(id.nome).split(' ')[0]).test(s)
  const paras = String(id.texto || '').split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean)
  // pergunta direta ("quem te criou?") → resposta curta; pergunta sobre a pessoa → apresentação completa
  return quer ? paras.join('\n\n') : `${paras[0] || `${id.nome} é ${id.cargo}.`}${paras[2] ? '\n\n' + paras[2] : ''}`
}
