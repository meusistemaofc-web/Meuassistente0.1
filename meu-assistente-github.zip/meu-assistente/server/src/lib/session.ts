import type { Ctx } from './http.js'
import { fail } from './http.js'
import { one, q, J, B, nowIso } from '../db/index.js'
import { sha256, token } from './security.js'
import { config, secureCookies } from '../config.js'

export const COOKIE = 'ma_session'
export interface SessionRow { id: string; user_id: number; mfa_pending: boolean; recovery: boolean; reauth_at: string | null }
export interface SessionUser {
  id: number; email: string; name: string; whatsapp: string; birthday: string | null; role: 'user' | 'admin' | 'superadmin'
  permissions: string[]; status: string; avatar_url: string | null; settings: any; interaction: any; chat_ui: any
  memory_settings: any; mfa_enabled: boolean; mfa_secret: string | null; mfa_pending_secret: string | null
  backup_codes: string[]; password_hash: string; created_at: string; last_seen_at: string | null
}

export function hydrateUser(r: any): SessionUser {
  return {
    ...r,
    permissions: J(r.permissions, []), settings: J(r.settings, {}), interaction: J(r.interaction, {}),
    chat_ui: J(r.chat_ui, {}), memory_settings: J(r.memory_settings, {}), backup_codes: J(r.backup_codes, []),
    mfa_enabled: B(r.mfa_enabled),
  }
}

function cookieHeader(value: string, maxAgeSec: number) {
  return [`${COOKIE}=${value}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSec}`, secureCookies() ? 'Secure' : ''].filter(Boolean).join('; ')
}

export async function createSession(ctx: Ctx, userId: number, opts: { mfaPending?: boolean; recovery?: boolean } = {}) {
  const t = token(32)
  const now = new Date()
  const days = opts.mfaPending || opts.recovery ? 1 / 48 : config.sessionDays // 30 min para sessões intermediárias
  const exp = new Date(now.getTime() + days * 86400_000)
  await q(
    `INSERT INTO sessions (id, user_id, mfa_pending, recovery, reauth_at, user_agent, ip, created_at, last_seen_at, expires_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$9)`,
    [sha256(t), userId, !!opts.mfaPending, !!opts.recovery, opts.mfaPending ? null : now.toISOString(),
      String(ctx.req.headers['user-agent'] || '').slice(0, 300), ctx.ip, now.toISOString(), exp.toISOString()],
  )
  ctx.setCookies.push(cookieHeader(t, Math.round(days * 86400)))
  return sha256(t)
}
export function clearSessionCookie(ctx: Ctx) { ctx.setCookies.push(cookieHeader('', 0)) }

export async function loadSession(ctx: Ctx): Promise<void> {
  const t = ctx.cookies[COOKIE]
  if (!t) return
  const row = await one(
    `SELECT s.id AS sid, s.mfa_pending, s.recovery, s.reauth_at, s.expires_at, s.last_seen_at AS s_seen, u.*
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = $1`, [sha256(t)])
  if (!row) return
  if (new Date(row.expires_at).getTime() < Date.now()) { await q('DELETE FROM sessions WHERE id = $1', [row.sid]); return }
  ctx.session = { id: row.sid, user_id: Number(row.id), mfa_pending: B(row.mfa_pending), recovery: B(row.recovery), reauth_at: row.reauth_at }
  ctx.user = hydrateUser(row)
  // atualiza "visto por último" no máximo a cada 5 minutos
  if (!row.s_seen || Date.now() - new Date(row.s_seen).getTime() > 300_000) {
    const n = nowIso()
    await q('UPDATE sessions SET last_seen_at = $1 WHERE id = $2', [n, row.sid])
    await q('UPDATE users SET last_seen_at = $1 WHERE id = $2', [n, row.id])
  }
}

/** Exige uma sessão completa (não pendente de 2FA nem de recuperação) e conta ativa. */
export function requireUser(ctx: Ctx): SessionUser {
  if (!ctx.user || !ctx.session || ctx.session.mfa_pending) fail(401, 'Entre para continuar.', 'auth_required')
  if (ctx.user!.status !== 'active') fail(401, 'Esta conta está desativada.', 'account_disabled')
  if (ctx.session!.recovery) fail(401, 'Defina a nova senha para continuar.', 'auth_required')
  return ctx.user!
}
export function requireReauth(ctx: Ctx) {
  const at = ctx.session?.reauth_at ? new Date(ctx.session.reauth_at).getTime() : 0
  if (Date.now() - at > 10 * 60_000) fail(403, 'Confirme sua senha para continuar.', 'reauth_required')
}
