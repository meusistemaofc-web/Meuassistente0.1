// Materiais iniciais da Biblioteca de Sobrevivência (orientações gerais; o administrador pode revisar e ampliar).
export const KB_SEED: { title: string; description: string; keywords: string[]; content: string }[] = [
  { title: 'Água segura para beber', description: 'Como tornar a água própria para consumo em emergências.', keywords: ['agua', 'beber', 'potavel', 'purificar', 'ferver', 'hipoclorito', 'cloro', 'filtrar'], content: `# Quando a água pode estar contaminada
Depois de enchentes, falta de abastecimento ou quando a origem é desconhecida (poço, rio, caixa d'água suja), trate a água antes de beber, cozinhar, escovar os dentes ou lavar alimentos.

# Antes de tratar: deixe a água limpa
Se a água estiver turva, deixe descansar em um recipiente limpo para a sujeira assentar e depois passe por um pano limpo, coador de papel ou filtro doméstico. Isso não mata germes: é só o primeiro passo.

# Fervura
Ferva a água por pelo menos 1 minuto depois que começar a borbulhar. Deixe esfriar com a panela tampada e guarde em recipiente limpo e fechado. É o método mais seguro quando há gás ou fogo disponível.

# Hipoclorito de sódio 2,5%
Use 2 gotas de hipoclorito de sódio a 2,5% para cada 1 litro de água. Misture e aguarde 30 minutos antes de consumir. O hipoclorito costuma ser distribuído gratuitamente em postos de saúde.
Água sanitária só pode ser usada se o rótulo disser que serve para tratar água de beber: sem perfume, sem alvejante extra, apenas hipoclorito de sódio. Siga a dose do rótulo.

# Guardar a água tratada
Use galões ou garrafas limpos, com tampa. Não encoste a mão na parte interna. Troque a água guardada periodicamente.

# Atenção
Em caso de dúvida sobre a segurança da água ou sintomas como diarreia, vômito e febre, procure o serviço de saúde. Em emergências, ligue 192 (SAMU).` },
  { title: 'Primeiros socorros básicos', description: 'O que fazer até a ajuda chegar.', keywords: ['primeiros socorros', 'socorro', 'ferimento', 'sangramento', 'queimadura', 'engasgo', 'desmaio', 'convulsao', 'rcp'], content: `# Números de emergência no Brasil
SAMU: 192. Bombeiros: 193. Polícia Militar: 190. Defesa Civil: 199. Diga onde você está, o que aconteceu e quantas pessoas precisam de ajuda.

# Antes de ajudar
Verifique se o local é seguro para você (trânsito, fogo, fios elétricos, água). Não se torne mais uma vítima. Use luvas ou um saco plástico nas mãos, se possível.

# Sangramento
Pressione o ferimento com um pano limpo, de forma firme e contínua. Se o pano encharcar, coloque outro por cima sem retirar o primeiro. Mantenha a pessoa deitada e aquecida e chame o 192.

# Queimaduras
Resfrie a área com água corrente em temperatura ambiente por cerca de 10 minutos. Não use gelo, pasta de dente, manteiga, pó de café ou outros produtos. Não estoure bolhas. Cubra com pano limpo e procure atendimento.

# Engasgo em adulto
Se a pessoa não consegue falar, tossir ou respirar: fique atrás dela, feche uma das mãos acima do umbigo, cubra com a outra mão e faça compressões rápidas para dentro e para cima até o objeto sair. Ligue 192.

# Desmaio
Deite a pessoa de costas e eleve as pernas. Afrouxe roupas apertadas. Se ela não acordar em pouco tempo, ligue 192.

# Convulsão
Afaste objetos ao redor, proteja a cabeça com algo macio e vire a pessoa de lado quando a crise passar. Não coloque nada na boca e não segure os movimentos. Ligue 192 se durar mais de 5 minutos ou se for a primeira crise.

# Parada cardíaca
Se a pessoa não responde e não respira normalmente: ligue 192 e comece compressões no centro do peito, com força e rapidez (100 a 120 por minuto), até a ajuda chegar. Fazer um curso de primeiros socorros ajuda muito.

# Atenção
Estas são orientações gerais. Sempre que possível, siga as instruções do atendente do 192.` },
  { title: 'Enchentes e alagamentos', description: 'Como se proteger antes, durante e depois.', keywords: ['enchente', 'alagamento', 'chuva', 'inundacao', 'deslizamento', 'tempestade', 'defesa civil'], content: `# Antes
Cadastre seu celular para alertas da Defesa Civil enviando seu CEP por SMS para 40199. Deixe documentos e remédios em sacos plásticos, em lugar alto. Combine com a família um ponto de encontro.

# Durante
Se a água começar a subir, desligue a energia elétrica e o gás. Vá para um lugar alto e seguro. Não atravesse ruas alagadas a pé ou de carro: a correnteza pode derrubar pessoas e arrastar veículos mesmo com pouca água. Fique longe de fios caídos e de encostas.

# Doenças
Evite contato com a água da enchente: ela pode transmitir leptospirose e outras doenças. Se precisar entrar, use botas e luvas. Procure atendimento se tiver febre, dor no corpo ou dor de cabeça nos dias seguintes.

# Depois
Só volte para casa quando as autoridades liberarem. Antes de religar a energia, verifique se a instalação está seca. Descarte alimentos que tiveram contato com a água. Limpe pisos e objetos com água sanitária diluída conforme o rótulo.

# Ajuda
Defesa Civil: 199. Bombeiros: 193. SAMU: 192.` },
  { title: 'Mochila de emergência', description: 'O que deixar pronto para sair às pressas.', keywords: ['mochila', 'kit de emergencia', 'kit de sobrevivencia', 'bolsa de fuga', 'preparar'], content: `# Para que serve
É uma mochila pronta para você sair de casa rapidamente em caso de enchente, incêndio, deslizamento ou outro desastre, com o necessário para os primeiros dias.

# Itens essenciais
Água: pelo menos 2 litros por pessoa por dia para beber. Alimentos que não estragam e não precisam de cozimento (barras, castanhas, enlatados com abertura fácil). Lanterna e pilhas extras. Carregador portátil (power bank). Rádio a pilha. Apito para pedir socorro.

# Saúde
Remédios de uso contínuo e cópias das receitas. Kit de primeiros socorros (gaze, esparadrapo, antisséptico, luvas). Máscaras, álcool em gel e itens de higiene.

# Documentos e dinheiro
Cópias de documentos em saco plástico fechado. Contatos importantes anotados em papel. Um pouco de dinheiro em espécie.

# Roupas e outros
Uma muda de roupa, agasalho e capa de chuva. Cobertor ou manta térmica. Canivete, fita adesiva e sacos de lixo. Itens para bebês, idosos e animais de estimação, se houver.

# Manutenção
Revise a mochila a cada 6 meses: troque a água, os alimentos e os remédios perto do vencimento.` },
  { title: 'Falta de energia e conservação de alimentos', description: 'Cuidados com geladeira, alimentos e geradores.', keywords: ['falta de energia', 'apagao', 'energia', 'geladeira', 'alimento', 'conservar', 'gerador', 'intoxicacao'], content: `# Geladeira e freezer
Mantenha as portas fechadas. Uma geladeira fechada conserva o frio por cerca de 4 horas. Um freezer cheio mantém a temperatura por cerca de 48 horas (24 horas se estiver pela metade).

# O que descartar
Carnes, leite, ovos, sobras e outros alimentos perecíveis que ficaram mais de 4 horas sem refrigeração devem ser descartados. Na dúvida, jogue fora: cheiro e aparência não garantem que o alimento está seguro.

# Geradores e fogareiros
Nunca use gerador, churrasqueira ou fogareiro dentro de casa ou em locais fechados: eles produzem monóxido de carbono, um gás sem cheiro que pode matar. Use sempre ao ar livre, longe de portas e janelas.

# Iluminação
Prefira lanternas a velas. Se usar velas, não as deixe acesas sem ninguém por perto e mantenha longe de cortinas e crianças.

# Remédios que precisam de geladeira
Alguns remédios, como insulina, perdem efeito fora da temperatura correta. Em caso de dúvida, pergunte ao farmacêutico ou ao serviço de saúde.` },
  { title: 'Incêndio em casa', description: 'Como agir para sair em segurança.', keywords: ['incendio', 'fogo', 'fumaca', 'queimada', 'extintor', 'panela', 'gas'], content: `# Primeiro: sair
Avise todos e saia imediatamente. Não pare para pegar objetos. Ligue 193 (Bombeiros) de fora do local.

# Fumaça
A fumaça é o maior perigo. Saia abaixado, perto do chão, cobrindo nariz e boca com um pano, de preferência úmido. Não use elevador.

# Portas
Antes de abrir uma porta, encoste o dorso da mão nela. Se estiver quente, não abra: procure outra saída. Se ficar preso, vede as frestas com panos e peça socorro pela janela.

# Fogo na panela
Nunca jogue água em óleo quente pegando fogo. Desligue o fogão, tampe a panela com a tampa ou um pano úmido e deixe esfriar.

# Vazamento de gás
Se sentir cheiro de gás, não acenda luzes, fósforos nem aparelhos. Feche o registro, abra portas e janelas e saia. Ligue para a distribuidora ou para o 193 de fora do local.

# Se a roupa pegar fogo
Pare, deite no chão e role, cobrindo o rosto com as mãos, até apagar.` },
]
