// Motor matemático interno (sem IA e sem eval): entende contas escritas em português e com símbolos.
// Ex.: "2 + 2", "100 - 35", "12 × 8", "150 ÷ 5", "20% de 500", "quanto é 3,5 vezes 4?", "raiz quadrada de 81", "(2+3)*4", "2^10".
type Tok = { t: 'n'; v: number } | { t: 'op'; v: string } | { t: '('; v: '(' } | { t: ')'; v: ')' }
const nrm = (s: string) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
/** Número no padrão brasileiro: "1.234,56" → 1234.56; "2,5" → 2.5; "1.5" → 1.5 */
function num(raw: string) { const s = raw.trim(); if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) return Number(s.replace(/\./g, '').replace(',', '.')); return Number(s.replace(',', '.')) }
/** Converte a frase em expressão; devolve null se não for uma conta. */
export function toExpression(text: string): string | null {
  if (/^\s*\d{1,2}:\d{2}\s*$/.test(text) || /\b\d{1,2}\/\d{1,2}(\/\d{2,4})?\b/.test(text) && !/[+*x×÷-]/.test(text)) return null // horário ou data, não conta
  let s = ' ' + nrm(text).replace(/[?!]+/g, ' ').replace(/\s+/g, ' ') + ' '
  s = s.replace(/^\s*(quanto (e|da|sao|fica|ficaria)|qual (e|o) (o )?(resultado|valor) de|calcule|calcula|calcular|me (diga|fala|da) quanto (e|da)|resolva|resolve|conta:?|faca a conta|faz a conta)\s+/, ' ')
  s = s.replace(/\s(igual a|igual|=)\s*$/, ' ').replace(/=\s*$/, ' ')
  // porcentagem: "20% de 500" → (20/100*500)
  s = s.replace(/(\d+(?:[.,]\d+)*)\s*(%|por ?cento)\s*(de|do|da|sobre)\s*(\d+(?:[.,]\d+)*)/g, (_, a, _p, _d, b) => ` ( ${a} / 100 * ${b} ) `)
  s = s.replace(/raiz quadrada (de|do|da)?\s*(\d+(?:[.,]\d+)*)/g, (_, _d, a) => ` sqrt ${a} `).replace(/raiz (de|do|da)\s*(\d+(?:[.,]\d+)*)/g, (_, _d, a) => ` sqrt ${a} `)
  s = s.replace(/(\d+(?:[.,]\d+)*)\s*ao quadrado/g, '$1 ^ 2').replace(/(\d+(?:[.,]\d+)*)\s*ao cubo/g, '$1 ^ 3').replace(/elevado (a|ao)/g, ' ^ ')
  s = s.replace(/\bmais\b/g, ' + ').replace(/\bmenos\b/g, ' - ').replace(/\b(vezes|multiplicado por)\b/g, ' * ').replace(/\b(dividido por|divido por|sobre)\b/g, ' / ')
  s = s.replace(/[×x✕]/g, (m, i, all) => (/\d\s*$/.test(all.slice(0, i)) && /^\s*[\d(]/.test(all.slice(i + 1)) ? ' * ' : m)).replace(/[÷:]/g, ' / ').replace(/[−–]/g, '-')
  s = s.replace(/%/g, ' / 100 ')
  const expr = s.trim()
  if (!/\d/.test(expr) || !/[-+*/^]|sqrt/.test(expr)) return null
  if (/[^0-9.,+\-*/^()\s]/.test(expr.replace(/sqrt/g, ''))) return null // sobrou palavra: não é uma conta pura
  return expr
}
function tokenize(e: string): Tok[] {
  const out: Tok[] = []; let i = 0
  while (i < e.length) {
    const c = e[i]
    if (c === ' ') { i++; continue }
    if (/\d/.test(c)) { let j = i; while (j < e.length && /[\d.,]/.test(e[j])) j++; out.push({ t: 'n', v: num(e.slice(i, j)) }); i = j; continue }
    if (e.startsWith('sqrt', i)) { out.push({ t: 'op', v: 'sqrt' }); i += 4; continue }
    if ('+-*/^'.includes(c)) { out.push({ t: 'op', v: c }); i++; continue }
    if (c === '(' || c === ')') { out.push({ t: c, v: c } as Tok); i++; continue }
    throw new Error('símbolo inválido')
  }
  return out
}
/** Analisador descendente recursivo: expr → termo (+|- termo)* ; termo → fator (*|/ fator)* ; fator → unário (^ fator)? */
function parse(tokens: Tok[]) {
  let p = 0
  const peek = () => tokens[p], eat = () => tokens[p++]
  const expr = (): number => { let v = term(); while (peek()?.t === 'op' && (peek()!.v === '+' || peek()!.v === '-')) { const o = eat()!.v; const r = term(); v = o === '+' ? v + r : v - r } return v }
  const term = (): number => { let v = power(); while (peek()?.t === 'op' && (peek()!.v === '*' || peek()!.v === '/')) { const o = eat()!.v; const r = power(); if (o === '/' && r === 0) throw new Error('divisão por zero'); v = o === '*' ? v * r : v / r } return v }
  const power = (): number => { const b = unary(); if (peek()?.t === 'op' && peek()!.v === '^') { eat(); const e = power(); return Math.pow(b, e) } return b }
  const unary = (): number => {
    const k = peek(); if (!k) throw new Error('expressão incompleta')
    if (k.t === 'op' && k.v === '-') { eat(); return -unary() }
    if (k.t === 'op' && k.v === '+') { eat(); return unary() }
    if (k.t === 'op' && k.v === 'sqrt') { eat(); const v = unary(); if (v < 0) throw new Error('raiz de número negativo'); return Math.sqrt(v) }
    if (k.t === 'n') { eat(); return k.v }
    if (k.t === '(') { eat(); const v = expr(); if (eat()?.t !== ')') throw new Error('parêntese sem fechar'); return v }
    throw new Error('expressão inválida')
  }
  const v = expr(); if (p !== tokens.length) throw new Error('expressão inválida'); return v
}
export const fmtNum = (v: number) => { const r = Math.round(v * 1e10) / 1e10; return r.toLocaleString('pt-BR', { maximumFractionDigits: 10 }) }
/** Resolve a conta da mensagem. Devolve null quando a mensagem não é uma conta. */
export function solveMath(text: string): { expr: string; valor: number; texto: string } | { erro: string } | null {
  const expr = toExpression(text); if (!expr) return null
  try { const v = parse(tokenize(expr)); if (!isFinite(v)) return { erro: 'O resultado não é um número finito.' }; const bonito = /%|por ?cento|raiz|quadrado|cubo|mais|menos|vezes|dividido/i.test(text) ? text.replace(/^\s*(quanto (é|e|dá|da|são|sao|fica)|calcule|calcula|resolva)\s+/i, '').replace(/[?=!]+\s*$/, '').trim() : expr.replace(/\*/g, '×').replace(/\//g, '÷').replace(/sqrt/g, '√').replace(/\s+/g, ' ').trim(); return { expr: bonito, valor: v, texto: fmtNum(v) } }
  catch (e: any) { return { erro: `Não consegui calcular: ${e?.message || 'expressão inválida'}.` } }
}
