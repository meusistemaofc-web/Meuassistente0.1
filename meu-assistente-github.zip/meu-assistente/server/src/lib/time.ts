// Utilidades de data/fuso horário sem bibliotecas externas (Intl).
export const DEFAULT_TZ = 'America/Sao_Paulo'
export function validTz(tz: unknown): string {
  if (typeof tz === 'string' && tz) { try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return tz } catch {} }
  return DEFAULT_TZ
}
function parts(d: Date, tz: string) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
  const o: Record<string, string> = {}
  for (const p of f.formatToParts(d)) o[p.type] = p.value
  return o
}
/** Data local (AAAA-MM-DD) num fuso. */
export function localDate(tz: string, d = new Date()): string { const p = parts(d, tz); return `${p.year}-${p.month}-${p.day}` }
export function localTime(tz: string, d = new Date()): string { const p = parts(d, tz); return `${p.hour}:${p.minute}` }
/** Converte data+hora locais de um fuso para um instante UTC (ISO). */
export function zonedToUtc(date: string, time: string, tz: string): string {
  const guess = new Date(`${date}T${time}:00Z`)
  const p = parts(guess, tz)
  const asIfUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second)
  const offset = asIfUtc - guess.getTime()
  const res = new Date(guess.getTime() - offset)
  // segunda passada corrige mudanças de horário de verão
  const p2 = parts(res, tz)
  const off2 = Date.UTC(+p2.year, +p2.month - 1, +p2.day, +p2.hour, +p2.minute, +p2.second) - res.getTime()
  return new Date(guess.getTime() - off2).toISOString()
}
export function addDays(date: string, n: number): string {
  const d = new Date(date + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10)
}
export function addMonths(date: string, n: number): string {
  const [y, m, d] = date.split('-').map(Number)
  const t = new Date(Date.UTC(y, m - 1 + n, 1))
  const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate()
  t.setUTCDate(Math.min(d, last))
  return t.toISOString().slice(0, 10)
}
export function nextOccurrence(date: string, recurrence: string): string | null {
  switch (recurrence) {
    case 'daily': return addDays(date, 1)
    case 'weekly': return addDays(date, 7)
    case 'monthly': return addMonths(date, 1)
    case 'yearly': return addMonths(date, 12)
    default: return null
  }
}
const WEEK = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado']
export function humanDate(date: string, today: string): string {
  if (date === today) return 'Hoje'
  if (date === addDays(today, 1)) return 'Amanhã'
  if (date === addDays(today, -1)) return 'Ontem'
  const d = new Date(date + 'T12:00:00Z')
  return `${WEEK[d.getUTCDay()]}, ${date.slice(8, 10)}/${date.slice(5, 7)}`
}
