// Valores iniciais das configurações do painel (iguais aos do protótipo aprovado).
export const MODULES_DEFAULT = { catalogo: true, anuncios: true, financas: true, lembretes: true, imagens: true, voz: true, sugestoes: true, fiscal: true, mercado: true, empresas: true }
export interface AiProvider { id: string; nome: string; base_url: string; modelo: string; key: string; texto: boolean; imagem: boolean; ativo: boolean; onde: string }
export const AI_DEFAULT: AiProvider[] = [
  { id: 'gemini', nome: 'Google Gemini', base_url: 'https://generativelanguage.googleapis.com/v1beta/openai', modelo: 'gemini-flash-latest', key: '', texto: true, imagem: true, ativo: true, onde: 'Chave grátis em aistudio.google.com' },
  { id: 'groq', nome: 'Groq', base_url: 'https://api.groq.com/openai/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave grátis em console.groq.com' },
  { id: 'openrouter', nome: 'OpenRouter', base_url: 'https://openrouter.ai/api/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave em openrouter.ai, use modelos com “:free”' },
  { id: 'mistral', nome: 'Mistral', base_url: 'https://api.mistral.ai/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Plano gratuito em console.mistral.ai' },
  { id: 'cerebras', nome: 'Cerebras', base_url: 'https://api.cerebras.ai/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave grátis em cloud.cerebras.ai' },
  { id: 'github', nome: 'GitHub Models', base_url: 'https://models.github.ai/inference', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Token da sua conta GitHub' },
  { id: 'custom', nome: 'Outra IA compatível com OpenAI', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: false, onde: 'Qualquer serviço no formato OpenAI (endereço + chave)' },
  { id: 'servidor', nome: 'IA do servidor (.env)', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'A IA definida no arquivo .env (por exemplo, o Ollama da VPS): sem limite' },
]
export interface MarketProvider { id: string; nome: string; cat: 'cripto' | 'bolsa'; url: string; campo: string; key: string; precisaChave: boolean; ativo: boolean; info: string; custom: boolean }
export const MARKET_DEFAULT: MarketProvider[] = [
  { id: 'coingecko', nome: 'CoinGecko', cat: 'cripto', url: 'https://api.coingecko.com/api/v3/simple/price?ids={id}&vs_currencies=brl&include_24hr_change=true', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave', custom: false },
  { id: 'coinpaprika', nome: 'CoinPaprika', cat: 'cripto', url: 'https://api.coinpaprika.com/v1/tickers/{paprika}?quotes=BRL', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave', custom: false },
  { id: 'binance', nome: 'Binance (dados públicos)', cat: 'cripto', url: 'https://api.binance.com/api/v3/ticker/24hr?symbol={SIMBOLO}BRL', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave · pares em real', custom: false },
  { id: 'brapi', nome: 'brapi.dev (B3)', cat: 'bolsa', url: 'https://brapi.dev/api/quote/{SIMBOLO}?token={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Token grátis em brapi.dev', custom: false },
  { id: 'yahoo', nome: 'Yahoo Finance', cat: 'bolsa', url: 'https://query1.finance.yahoo.com/v8/finance/chart/{SIMBOLO}.SA', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave · não oficial', custom: false },
  { id: 'alphavantage', nome: 'Alpha Vantage', cat: 'bolsa', url: 'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={SIMBOLO}.SA&apikey={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Chave grátis · 25 consultas por dia', custom: false },
  { id: 'twelvedata', nome: 'Twelve Data', cat: 'bolsa', url: 'https://api.twelvedata.com/quote?symbol={SIMBOLO}&exchange=BVMF&apikey={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Chave grátis · 800 consultas por dia', custom: false },
]
export const MP_DEFAULT = { modo: 'teste', teste: { pub: '', tok: '', seg: '' }, producao: { pub: '', tok: '', seg: '' } }
export const PLANS_DEFAULT = [
  { id: 'n1', nivel: 1, nome: 'Anúncio', dias: 30, preco: 29.9 },
  { id: 'n2', nivel: 2, nome: 'Anúncio + contato', dias: 30, preco: 49.9 },
  { id: 'n3', nivel: 3, nome: 'Página da empresa', dias: 30, preco: 79.9 },
  { id: 'n4', nivel: 4, nome: 'Loja completa', dias: 30, preco: 129.9 },
]
export const BRAIN_DEFAULT = { aprender: true, cerebroPrimeiro: true, fatos: true }
export const SEARCH_DEFAULT = { raio: 15 }
export const FISCAL_DEFAULT = { sm: 1621, limite: 81000 }
