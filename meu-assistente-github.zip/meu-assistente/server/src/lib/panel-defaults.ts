// Valores iniciais das configurações do painel (iguais aos do protótipo aprovado).
export const MODULES_DEFAULT = { catalogo: true, anuncios: true, financas: true, lembretes: true, imagens: true, voz: true, sugestoes: true, fiscal: true, mercado: true, empresas: true, agente: false }
export interface AiProvider { id: string; nome: string; base_url: string; modelo: string; key: string; texto: boolean; imagem: boolean; ativo: boolean; onde: string; tipo?: 'openai' | 'gemini' | 'anthropic'; caps?: Partial<Record<'texto' | 'ferramentas' | 'imagem' | 'documento' | 'audio' | 'codigo' | 'pesquisa', boolean>>; modelo_audio?: string }
export const AI_DEFAULT: AiProvider[] = [
  { id: 'gemini', tipo: 'gemini', nome: 'Google Gemini', base_url: 'https://generativelanguage.googleapis.com', modelo: 'gemini-flash-latest', key: '', texto: true, imagem: true, ativo: true, onde: 'Chave grátis em aistudio.google.com · lê imagens, PDFs e áudio e pesquisa na web' },
  { id: 'anthropic', tipo: 'anthropic', nome: 'Claude (Anthropic)', base_url: 'https://api.anthropic.com', modelo: 'claude-haiku-5-5', key: '', texto: true, imagem: true, ativo: true, onde: 'Chave em console.anthropic.com · forte em programação, análises e ferramentas' },
  { id: 'openai', tipo: 'openai', nome: 'OpenAI', base_url: 'https://api.openai.com/v1', modelo: 'gpt-4o-mini', modelo_audio: 'whisper-1', key: '', texto: true, imagem: true, ativo: true, onde: 'Chave em platform.openai.com · conversa, imagens e áudio (Whisper)' },
  { id: 'groq', tipo: 'openai', nome: 'Groq', base_url: 'https://api.groq.com/openai/v1', modelo: '', modelo_audio: 'whisper-large-v3-turbo', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave grátis em console.groq.com · muito rápida; transcreve áudio' },
  { id: 'openrouter', tipo: 'openai', nome: 'OpenRouter', base_url: 'https://openrouter.ai/api/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave em openrouter.ai, use modelos com “:free”' },
  { id: 'mistral', tipo: 'openai', nome: 'Mistral', base_url: 'https://api.mistral.ai/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Plano gratuito em console.mistral.ai' },
  { id: 'cerebras', tipo: 'openai', nome: 'Cerebras', base_url: 'https://api.cerebras.ai/v1', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Chave grátis em cloud.cerebras.ai' },
  { id: 'github', tipo: 'openai', nome: 'GitHub Models', base_url: 'https://models.github.ai/inference', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'Token da sua conta GitHub' },
  { id: 'custom', tipo: 'openai', nome: 'Outra IA compatível com OpenAI', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: false, onde: 'Qualquer serviço no formato OpenAI (endereço + chave)' },
  { id: 'servidor', tipo: 'openai', nome: 'IA do servidor (.env)', base_url: '', modelo: '', key: '', texto: true, imagem: false, ativo: true, onde: 'A IA definida no arquivo .env (por exemplo, o Ollama da VPS): sem limite' },
]
/** Motor multi-IA: como o roteador escolhe, combina e protege as IAs (Administração → IA → Motor). */
export const AI_ROUTER_DEFAULT = {
  modo: 'equilibrado' as 'equilibrado' | 'prioridade' | 'velocidade' | 'qualidade',
  timeoutMs: 25000, prazoMs: 70000, tentativas: 1,
  breaker: { falhas: 3, pausaSeg: 30, maxPausaSeg: 600 },
  paralelo: { ativo: true, modo: 'comparar' as 'comparar' | 'corrida', max: 2, tarefas: ['analise', 'codigo', 'pesquisa'] as string[] },
  monitor: { ativo: true, minutos: 5 },
}
export interface MarketProvider { id: string; nome: string; cat: 'cripto' | 'bolsa'; url: string; campo: string; key: string; precisaChave: boolean; ativo: boolean; info: string; custom: boolean }
export const MARKET_DEFAULT: MarketProvider[] = [
  { id: 'coingecko', nome: 'CoinGecko', cat: 'cripto', url: 'https://api.coingecko.com/api/v3/simple/price?ids={id}&vs_currencies=brl&include_24hr_change=true', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave', custom: false },
  { id: 'coinpaprika', nome: 'CoinPaprika', cat: 'cripto', url: 'https://api.coinpaprika.com/v1/tickers/{paprika}?quotes=BRL', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave', custom: false },
  { id: 'binance', nome: 'Binance (dados públicos)', cat: 'cripto', url: 'https://api.binance.com/api/v3/ticker/24hr?symbol={SIMBOLO}BRL', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave · pares em real', custom: false },
  { id: 'brapi', nome: 'brapi.dev (B3)', cat: 'bolsa', url: 'https://brapi.dev/api/quote/{SIMBOLO}?token={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Token grátis em brapi.dev', custom: false },
  { id: 'yahoo', nome: 'Yahoo Finance', cat: 'bolsa', url: 'https://query1.finance.yahoo.com/v8/finance/chart/{SIMBOLO}.SA', campo: '', key: '', precisaChave: false, ativo: true, info: 'Sem chave · não oficial', custom: false },
  { id: 'alphavantage', nome: 'Alpha Vantage', cat: 'bolsa', url: 'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={SIMBOLO}.SA&apikey={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Chave grátis · 25 consultas por dia', custom: false },
  { id: 'twelvedata', nome: 'Twelve Data', cat: 'bolsa', url: 'https://api.twelvedata.com/quote?symbol={SIMBOLO}&exchange=BVMF&apikey={chave}', campo: '', key: '', precisaChave: true, ativo: true, info: 'Chave grátis · 800 consultas por dia', custom: false },
]
export const MP_DEFAULT = { modo: 'teste', teste: { pub: '', tok: '', seg: '' }, producao: { pub: '', tok: '', seg: '' } }
export const PLANS_DEFAULT = [
  { id: 'n1', nivel: 1, nome: 'Anúncio', dias: 30, preco: 29.9 },
  { id: 'n2', nivel: 2, nome: 'Anúncio + contato', dias: 30, preco: 49.9 },
  { id: 'n3', nivel: 3, nome: 'Página da empresa', dias: 30, preco: 79.9 },
  { id: 'n4', nivel: 4, nome: 'Loja completa', dias: 30, preco: 129.9 },
]
export const BRAIN_DEFAULT = { aprender: true, cerebroPrimeiro: true, fatos: true }
export const SEARCH_DEFAULT = { raio: 15 }
export const FISCAL_DEFAULT = { sm: 1621, limite: 81000 }

export const CHAT_WELCOME_DEFAULT = {
  ativo: true,
  saudacao: 'Olá, {nome}!',
  titulo: 'Fale comigo.',
  subtitulo: 'Eu organizo o resto.',
}
