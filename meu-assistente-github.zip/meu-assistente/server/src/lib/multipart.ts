// Leitor simples de multipart/form-data (fotos, documentos e áudio enviados pelo chat).
import type { IncomingMessage } from 'node:http'
import { HttpError } from './http.js'
export interface UpFile { field: string; filename: string; mime: string; data: Buffer }
export const UPLOAD_MAX = Number(process.env.UPLOAD_MAX_BYTES || 15 * 1024 * 1024)
export async function readMultipart(req: IncomingMessage): Promise<{ fields: Record<string, string>; files: UpFile[] }> {
  const ct = String(req.headers['content-type'] || ''), m = ct.match(/boundary=(?:"([^"]+)"|([^;]+))/i)
  if (!m) throw new HttpError(400, 'Envio inválido.', 'invalid')
  const boundary = Buffer.from('--' + (m[1] || m[2]).trim())
  const chunks: Buffer[] = []; let size = 0
  for await (const c of req) { size += (c as Buffer).length; if (size > UPLOAD_MAX) throw new HttpError(413, `Arquivo grande demais (máximo ${Math.round(UPLOAD_MAX / 1024 / 1024)} MB).`, 'payload_too_large'); chunks.push(c as Buffer) }
  const buf = Buffer.concat(chunks), fields: Record<string, string> = {}, files: UpFile[] = []
  let pos = buf.indexOf(boundary)
  while (pos >= 0) {
    const start = pos + boundary.length
    if (buf.slice(start, start + 2).toString() === '--') break
    const next = buf.indexOf(boundary, start); if (next < 0) break
    const part = buf.slice(start + 2, next - 2) // tira \r\n do início e do fim
    const he = part.indexOf('\r\n\r\n'); if (he < 0) { pos = next; continue }
    const head = part.slice(0, he).toString('utf8'), body = part.slice(he + 4)
    const name = (head.match(/name="([^"]*)"/i) || [])[1], fn = (head.match(/filename="([^"]*)"/i) || [])[1]
    const mime = ((head.match(/content-type:\s*([^\r\n]+)/i) || [])[1] || 'application/octet-stream').trim()
    if (name) { if (fn !== undefined) files.push({ field: name, filename: fn, mime, data: body }); else fields[name] = body.toString('utf8') }
    pos = next
  }
  return { fields, files }
}
