// Planos de uso do Meu Assistente: limite diário grátis e limites por plano (configurados no painel).
import type { SessionUser } from './session.js'
import { getConfig } from './settings.js'
import { getUM, setUM } from './usermod.js'
import { fail } from './http.js'

export const USAGE_KINDS: Record<string, string> = { chat: 'Mensagens no chat', appointment: 'Compromissos', task: 'Tarefas', reminder: 'Lembretes', expense: 'Gastos e receitas', bill: 'Contas', note: 'Anotações', shopping: 'Itens de compras' }
export const USAGE_DEFAULT = {
  ativo: false,
  free: { nome: 'Grátis', limites: { chat: 30, appointment: 5, task: 10, reminder: 5, expense: 20, bill: 5, note: 10, shopping: 30 } as Record<string, number | null> },
  plans: [
    { id: 'p1', nome: 'Essencial', preco: 9.9, dias: 30, ativo: true, limites: { chat: 150, appointment: 30, task: 50, reminder: 30, expense: 100, bill: 30, note: 50, shopping: 100 } as Record<string, number | null> },
    { id: 'p2', nome: 'Completo', preco: 19.9, dias: 30, ativo: true, limites: { chat: null, appointment: null, task: null, reminder: null, expense: null, bill: null, note: null, shopping: null } as Record<string, number | null> },
  ],
}
export async function usageCfg() { const c = await getConfig<any>('usage_plans', {}); return { ...USAGE_DEFAULT, ...c, free: { ...USAGE_DEFAULT.free, ...(c.free || {}) }, plans: Array.isArray(c.plans) ? c.plans : USAGE_DEFAULT.plans } }
const today = () => new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10)

export async function planOf(u: SessionUser) {
  const cfg = await usageCfg()
  if (u.role !== 'user') return { id: 'admin', nome: 'Administrador', limites: {} as Record<string, number | null>, expiresAt: null, ilimitado: true, cfg }
  const sub = await getUM<any>(u.id, 'subscription', null)
  const p = sub && Date.parse(sub.expiresAt) > Date.now() ? cfg.plans.find((x: any) => x.id === sub.planId) : null
  if (p) return { id: p.id, nome: p.nome, limites: p.limites || {}, expiresAt: sub.expiresAt, ilimitado: false, cfg }
  return { id: 'free', nome: cfg.free.nome || 'Grátis', limites: cfg.free.limites || {}, expiresAt: null, ilimitado: false, cfg }
}
export async function usedToday(userId: number) { const u = await getUM<any>(userId, 'usage', null); return u && u.day === today() ? u.counts || {} : {} }
/** Confere o limite do dia e conta o uso. Lança 429 com mensagem amigável se passou do limite. */
export async function useQuota(u: SessionUser, kind: string, n = 1, block = true) {
  const p = await planOf(u)
  if (!p.cfg.ativo || p.ilimitado) return
  const counts = await usedToday(u.id), lim = p.limites[kind]
  if (block && lim !== null && lim !== undefined && (counts[kind] || 0) + n > lim)
    fail(429, `Você atingiu o limite de ${USAGE_KINDS[kind]?.toLowerCase() || kind} de hoje no plano ${p.nome} (${lim} por dia). Conheça os planos para liberar mais.`, 'limit_reached')
  counts[kind] = (counts[kind] || 0) + n
  await setUM(u.id, 'usage', { day: today(), counts })
}
