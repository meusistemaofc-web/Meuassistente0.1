import { q, nowIso } from '../db/index.js'

export async function notify(userId: number, n: { type: string; title: string; body?: string; link?: string; ref?: string }) {
  // "ref" evita notificações duplicadas do mesmo evento (índice único user_id+ref)
  if (n.ref) {
    const ex = await q('SELECT id FROM notifications WHERE user_id = $1 AND ref = $2', [userId, n.ref])
    if (ex.length) return
  }
  await q('INSERT INTO notifications (user_id, type, title, body, link, ref, read, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [userId, n.type, n.title, n.body ?? null, n.link ?? null, n.ref ?? null, false, nowIso()])
}
