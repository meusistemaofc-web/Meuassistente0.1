import { q, nowIso, J } from '../db/index.js'

const PREF: Record<string, string> = { reminder: 'notifyReminders', appointment: 'notifyAppointments', bill: 'notifyBills', task: 'notifyTasks', market: 'notifyMarket' }
export async function notify(userId: number, n: { type: string; title: string; body?: string; link?: string; ref?: string }) {
  // respeita as preferências do usuário (todas ligadas por padrão; ele pode desligar em Configurações)
  const u = await q('SELECT settings FROM users WHERE id = $1', [userId])
  const st = J<any>(u[0]?.settings, {})
  if (st.notificationsEnabled === false) return
  const key = PREF[n.type]
  if (key && st[key] === false) return
  // "ref" evita notificações duplicadas do mesmo evento (índice único user_id+ref)
  if (n.ref) {
    const ex = await q('SELECT id FROM notifications WHERE user_id = $1 AND ref = $2', [userId, n.ref])
    if (ex.length) return
  }
  await q('INSERT INTO notifications (user_id, type, title, body, link, ref, read, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [userId, n.type, n.title, n.body ?? null, n.link ?? null, n.ref ?? null, false, nowIso()])
  // também envia push se o dispositivo estiver inscrito
  try {
    const { sendToUser } = await import('./push.js')
    await sendToUser(userId, { title: n.title, body: n.body, url: n.link || '/' })
  } catch {}
}
