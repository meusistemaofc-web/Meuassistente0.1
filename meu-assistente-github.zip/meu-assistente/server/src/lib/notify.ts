import { q, nowIso, J } from '../db/index.js'

const PREF: Record<string, string> = { reminder: 'notifyReminders', appointment: 'notifyAppointments', bill: 'notifyBills', task: 'notifyTasks', market: 'notifyMarket' }
export async function notify(userId: number, n: { type: string; title: string; body?: string; link?: string; ref?: string }) {
  // respeita as preferências do usuário (todas ligadas por padrão; ele pode desligar em Configurações)
  const u = await q('SELECT settings FROM users WHERE id = $1', [userId])
  const st = J<any>(u[0]?.settings, {})
  if (st.notificationsEnabled === false) return
  const key = PREF[n.type]
  if (key && st[key] === false) return
  // "ref" evita notificações duplicadas do mesmo evento (índice único user_id+ref)
  if (n.ref) {
    const ex = await q('SELECT id FROM notifications WHERE user_id = $1 AND ref = $2', [userId, n.ref])
    if (ex.length) return
  }
  await q('INSERT INTO notifications (user_id, type, title, body, link, ref, read, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [userId, n.type, n.title, n.body ?? null, n.link ?? null, n.ref ?? null, false, nowIso()])
  // e-mail (se o tipo estiver ligado no painel e o usuário não tiver pedido para sair)
  void (async () => {
    const kind = n.type === 'order' ? 'pedidos' : n.type === 'appointment' ? 'compromissos' : ['reminder', 'bill', 'task', 'followup', 'market'].includes(n.type) ? 'notificacoes' : ''
    if (!kind) return
    const u = (await q('SELECT email, name FROM users WHERE id = $1', [userId]))[0]; if (!u?.email) return
    let businessId: number | null = null
    if (kind === 'pedidos') { const oid = /order[^:]*:(\d+)/.exec(n.ref || '')?.[1]; if (oid) businessId = Number((await q('SELECT business_id FROM orders WHERE id = $1', [Number(oid)]))[0]?.business_id) || null }
    const { enqueueMail } = await import('./mail.js')
    await enqueueMail({ kind, to: u.email, userId, businessId, vars: { nome: String(u.name || '').split(' ')[0], titulo: n.title, mensagem: [n.title, n.body].filter(Boolean).join(' — '), link: (await import('./publicurl.js')).pub() + (n.link || '/') }, dedupe: n.ref ? `n:${userId}:${n.ref}` : undefined })
  })().catch(() => {})
  // também envia push se o dispositivo estiver inscrito
  // em segundo plano: a resposta ao usuário não espera o serviço de push
  void import('./push.js').then((m) => m.sendToUser(userId, { title: n.title, body: n.body ?? undefined, url: n.link || '/', tag: n.ref ?? undefined })).catch(() => {})
}
