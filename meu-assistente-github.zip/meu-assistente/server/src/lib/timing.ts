// Rastreabilidade do tempo de cada mensagem do chat, por etapa. Guarda as últimas 500 medições em memória
// (sem custo de banco) e registra no log as mensagens lentas. O painel lê o resumo em /api/panel/diagnostico/tempos.
export interface Medicao { em: string; total: number; etapas: Record<string, number>; via: string; ia: boolean; texto: number }
const ULTIMAS: Medicao[] = []
const LENTA_MS = Number(process.env.CHAT_SLOW_MS || 4000)

export function timer() {
  const t0 = performance.now(); let last = t0; const etapas: Record<string, number> = {}
  return {
    /** Fecha a etapa atual com o nome dado (tempo desde a marca anterior). */
    mark(nome: string) { const n = performance.now(); etapas[nome] = Math.round((etapas[nome] || 0) + (n - last)); last = n },
    finish(via: string, ia: boolean, textLen: number) {
      const total = Math.round(performance.now() - t0)
      const m: Medicao = { em: new Date().toISOString(), total, etapas, via, ia, texto: textLen }
      ULTIMAS.push(m); if (ULTIMAS.length > 500) ULTIMAS.shift()
      if (total >= LENTA_MS) console.warn(`[chat lento] ${total} ms via ${via} · ` + Object.entries(etapas).map(([k, v]) => `${k}=${v}ms`).join(' '))
      return m
    },
    get etapas() { return etapas },
  }
}
const pct = (arr: number[], p: number) => { if (!arr.length) return 0; const s = [...arr].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))] }
/** Resumo: média, p95 e máximo do total e de cada etapa, separado entre respostas internas e com IA. */
export function resumoTempos() {
  const grupo = (lista: Medicao[]) => {
    const etapas: Record<string, number[]> = {}
    for (const m of lista) for (const [k, v] of Object.entries(m.etapas)) (etapas[k] ||= []).push(v)
    const tot = lista.map((m) => m.total)
    return { mensagens: lista.length, totalMedia: tot.length ? Math.round(tot.reduce((a, b) => a + b, 0) / tot.length) : 0, totalP95: pct(tot, 95), totalMax: tot.length ? Math.max(...tot) : 0,
      etapas: Object.fromEntries(Object.entries(etapas).map(([k, v]) => [k, { media: Math.round(v.reduce((a, b) => a + b, 0) / v.length), p95: pct(v, 95), max: Math.max(...v) }])) }
  }
  const porVia: Record<string, number> = {}; for (const m of ULTIMAS) porVia[m.via] = (porVia[m.via] || 0) + 1
  return { todas: grupo(ULTIMAS), internas: grupo(ULTIMAS.filter((m) => !m.ia)), comIA: grupo(ULTIMAS.filter((m) => m.ia)), porVia, maisLentas: [...ULTIMAS].sort((a, b) => b.total - a.total).slice(0, 10), limiteLentaMs: LENTA_MS }
}
export function limparTempos() { ULTIMAS.length = 0 }
