import { randomBytes, scrypt as _scrypt, timingSafeEqual, createHash, createHmac } from 'node:crypto'
import { promisify } from 'node:util'

const scrypt = promisify(_scrypt) as (pw: string, salt: Buffer, len: number, opts: object) => Promise<Buffer>
const N = 16384, R = 8, P = 1, LEN = 64

/** Hash de senha com scrypt (memória-intensivo), formato: scrypt$N$r$p$salt$hash */
export async function hashPassword(pw: string): Promise<string> {
  const salt = randomBytes(16)
  const key = await scrypt(pw, salt, LEN, { N, r: R, p: P, maxmem: 64 * 1024 * 1024 })
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${key.toString('base64')}`
}
export async function verifyPassword(pw: string, stored: string): Promise<boolean> {
  const [alg, n, r, p, salt, hash] = (stored || '').split('$')
  if (alg !== 'scrypt' || !salt || !hash) return false
  const expected = Buffer.from(hash, 'base64')
  const key = await scrypt(pw, Buffer.from(salt, 'base64'), expected.length, { N: Number(n), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024 })
  return key.length === expected.length && timingSafeEqual(key, expected)
}
export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex')
export const token = (bytes = 32) => randomBytes(bytes).toString('base64url')

/** Regras de senha idênticas às do frontend original. */
export function passwordProblem(pw: unknown): string | null {
  if (typeof pw !== 'string' || pw.length < 8) return 'A senha precisa ter pelo menos 8 caracteres.'
  if (!/[A-Za-zÀ-ÿ]/.test(pw) || !/\d/.test(pw)) return 'A senha precisa ter letras e números.'
  if (pw.length > 200) return 'Senha longa demais.'
  return null
}
export function whatsappProblem(v: unknown): string | null {
  const s = typeof v === 'string' ? v : ''
  const d = s.replace(/\D/g, '')
  if (!s.trim().startsWith('+') && d.length < 12) return 'Inclua o código do país e o DDD, ex.: +55 11 98765-4321.'
  if (d.length < 10 || d.length > 15) return 'Número de WhatsApp inválido.'
  return null
}
export const normWhatsapp = (v: string) => '+' + v.replace(/\D/g, '')

// ---- TOTP (RFC 6238) para a verificação em duas etapas ----
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
export function base32Encode(buf: Buffer): string {
  let bits = 0, value = 0, out = ''
  for (const b of buf) { value = (value << 8) | b; bits += 8; while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5 } }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31]
  return out
}
export function base32Decode(s: string): Buffer {
  const clean = s.replace(/=+$/, '').replace(/\s/g, '').toUpperCase()
  let bits = 0, value = 0
  const out: number[] = []
  for (const c of clean) {
    const i = B32.indexOf(c)
    if (i < 0) continue
    value = (value << 5) | i; bits += 5
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8 }
  }
  return Buffer.from(out)
}
export function totp(secret: string, at = Date.now(), step = 30): string {
  const counter = Math.floor(at / 1000 / step)
  const buf = Buffer.alloc(8)
  buf.writeBigUInt64BE(BigInt(counter))
  const h = createHmac('sha1', base32Decode(secret)).update(buf).digest()
  const o = h[h.length - 1] & 15
  const code = ((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000).toString()
  return code.padStart(6, '0')
}
export function verifyTotp(secret: string, code: string): boolean {
  if (!/^\d{6}$/.test(code)) return false
  const now = Date.now()
  return [-1, 0, 1].some((w) => totp(secret, now + w * 30000) === code)
}
export const newTotpSecret = () => base32Encode(randomBytes(20))
export function newBackupCodes(n = 10): string[] {
  return Array.from({ length: n }, () => {
    const s = randomBytes(5).toString('hex').toUpperCase()
    return `${s.slice(0, 5)}-${s.slice(5)}`
  })
}

// ---- Limite de tentativas em memória (login, recuperação) ----
const buckets = new Map<string, { n: number; reset: number }>()
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now()
  const b = buckets.get(key)
  if (!b || b.reset < now) { buckets.set(key, { n: 1, reset: now + windowMs }); return true }
  b.n++
  return b.n <= max
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k) }, 60_000).unref()
