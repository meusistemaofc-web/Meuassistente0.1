// Cliente SMTP próprio (sem dependências): SSL direto (465), STARTTLS (587) ou sem criptografia (só rede local),
// AUTH PLAIN/LOGIN, envio de uma mensagem MIME já montada. Usado com Hostinger Email, Postfix da VPS ou qualquer SMTP.
import net from 'node:net'
import tls from 'node:tls'
export interface SmtpCfg { host: string; port: number; seguranca: 'ssl' | 'starttls' | 'nenhuma'; usuario?: string; senha?: string; heloName?: string; timeoutMs?: number; rejectUnauthorized?: boolean }
export class SmtpError extends Error { constructor(message: string, public code = 0, public permanent = false) { super(message) } }

class Conn {
  private buf = ''; private waiters: ((l: string[]) => void)[] = []; private lines: string[] = []; private err: Error | null = null
  constructor(public sock: net.Socket, private timeoutMs: number) { this.attach(sock) }
  attach(s: net.Socket) {
    this.sock = s
    s.setEncoding('utf8')
    s.on('data', (d: string) => { this.buf += d; let i; while ((i = this.buf.indexOf('\r\n')) >= 0) { const line = this.buf.slice(0, i); this.buf = this.buf.slice(i + 2); this.lines.push(line); if (/^\d{3} /.test(line) || /^\d{3}$/.test(line)) { const all = this.lines; this.lines = []; this.waiters.shift()?.(all) } } })
    s.on('error', (e) => { this.err = e; const w = this.waiters.shift(); if (w) w(['000 ' + e.message]) })
    s.on('close', () => { const w = this.waiters.shift(); if (w) w(['000 conexão encerrada pelo servidor']) })
  }
  read(): Promise<{ code: number; text: string; lines: string[] }> {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new SmtpError('Tempo esgotado esperando o servidor SMTP.', 0)), this.timeoutMs)
      this.waiters.push((lines) => { clearTimeout(t); const last = lines[lines.length - 1] || '000'; resolve({ code: Number(last.slice(0, 3)) || 0, text: lines.map((l) => l.slice(4)).join(' '), lines }) })
    })
  }
  async cmd(line: string, expect: number[], what: string, secret = false) {
    this.sock.write(line + '\r\n')
    const r = await this.read()
    if (!expect.includes(r.code)) throw new SmtpError(`${what}: ${r.code} ${r.text}`.slice(0, 300) + (secret ? '' : ''), r.code, r.code >= 500)
    return r
  }
}
function connect(c: SmtpCfg): Promise<net.Socket> {
  return new Promise((resolve, reject) => {
    const opts: any = { host: c.host, port: c.port, servername: c.host, rejectUnauthorized: c.rejectUnauthorized !== false }
    const s = c.seguranca === 'ssl' ? tls.connect(opts, () => resolve(s)) : net.connect(c.port, c.host, () => resolve(s))
    s.once('error', (e: any) => reject(new SmtpError(`Não foi possível conectar em ${c.host}:${c.port} (${e.code || e.message}).`, 0)))
    s.setTimeout(c.timeoutMs || 20000, () => { s.destroy(); reject(new SmtpError('Tempo esgotado conectando ao servidor SMTP.', 0)) })
  })
}
/** Abre a conexão, cumprimenta, negocia TLS e autentica. Devolve a conexão pronta. */
async function open(c: SmtpCfg) {
  const conn = new Conn(await connect(c), c.timeoutMs || 20000)
  const hello = await conn.read(); if (hello.code !== 220) throw new SmtpError(`Servidor não aceitou a conexão: ${hello.code} ${hello.text}`, hello.code)
  const helo = c.heloName || 'meuassistente.local'
  let ehlo = await conn.cmd(`EHLO ${helo}`, [250], 'EHLO')
  if (c.seguranca === 'starttls') {
    if (!ehlo.lines.some((l) => /STARTTLS/i.test(l))) throw new SmtpError('O servidor não oferece STARTTLS nesta porta. Use SSL (porta 465).', 0, true)
    await conn.cmd('STARTTLS', [220], 'STARTTLS')
    const sec: net.Socket = await new Promise((resolve, reject) => { const t = tls.connect({ socket: conn.sock, servername: c.host, rejectUnauthorized: c.rejectUnauthorized !== false }, () => resolve(t)); t.once('error', (e) => reject(new SmtpError('Falha no TLS: ' + e.message, 0))) })
    conn.attach(sec)
    ehlo = await conn.cmd(`EHLO ${helo}`, [250], 'EHLO')
  }
  if (c.usuario) {
    const caps = ehlo.lines.join(' ').toUpperCase()
    if (/AUTH[ =][^\n]*PLAIN/.test(caps)) await conn.cmd('AUTH PLAIN ' + Buffer.from(`\0${c.usuario}\0${c.senha || ''}`).toString('base64'), [235], 'Autenticação', true)
    else if (/AUTH[ =][^\n]*LOGIN/.test(caps)) { await conn.cmd('AUTH LOGIN', [334], 'Autenticação'); await conn.cmd(Buffer.from(c.usuario).toString('base64'), [334], 'Usuário', true); await conn.cmd(Buffer.from(c.senha || '').toString('base64'), [235], 'Senha', true) }
    else throw new SmtpError('O servidor não oferece autenticação (AUTH) nesta conexão.', 0, true)
  }
  return conn
}
/** Testa conexão, TLS e login, sem enviar nada. */
export async function smtpVerify(c: SmtpCfg) { const conn = await open(c); try { await conn.cmd('QUIT', [221], 'QUIT').catch(() => {}) } finally { conn.sock.end() } return true }
/** Envia uma mensagem MIME para um destinatário. */
export async function smtpSend(c: SmtpCfg, from: string, to: string, mime: string) {
  const conn = await open(c)
  try {
    await conn.cmd(`MAIL FROM:<${from}>`, [250], 'Remetente')
    await conn.cmd(`RCPT TO:<${to}>`, [250, 251], 'Destinatário')
    await conn.cmd('DATA', [354], 'DATA')
    const body = mime.replace(/\r?\n/g, '\r\n').split('\r\n').map((l) => (l.startsWith('.') ? '.' + l : l)).join('\r\n')
    const r = await conn.cmd(body + '\r\n.', [250], 'Envio')
    await conn.cmd('QUIT', [221], 'QUIT').catch(() => {})
    return { aceito: true, resposta: r.text.slice(0, 200) }
  } finally { conn.sock.end() }
}
