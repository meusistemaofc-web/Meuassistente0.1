import type { SessionUser } from './session.js'
import { validTz } from './time.js'
import { q, nowIso } from '../db/index.js'
import { MOD_CACHE } from './usermod.js'

/** Recursos do plano que existem nesta reconstrução. Os demais ficam fora até serem reconstruídos. */
export const AVAILABLE_FEATURES = ['chat_text', 'text_voice', 'voice_mode', 'brain_memory', 'finance', 'agenda', 'push']

export const DEFAULT_SETTINGS = {
  theme: 'dark', timezone: 'America/Sao_Paulo', currency: 'BRL',
  replyMode: 'text', voiceAutoplay: false, voiceEngine: 'device', voiceName: '', voiceRate: 1,
  notificationsEnabled: true, pushEnabled: false,
  notifyReminders: true, notifyAppointments: true, notifyBills: true, notifyTasks: true, notifyMarket: true, soundEnabled: true, vibrationEnabled: true,
  dailySummaryTime: '21:00', notifySummary: true, defaultReminderTime: '09:00',
  reminderBeforeMinutes: 0, reminderLeadMinutes: 30,
  quietEnabled: false, quietStart: '22:00', quietEnd: '07:00',
  voiceModeEnabled: true, voiceModeSpeak: true, voiceKeepListening: false, voiceTranscripts: true,
  voiceWakePhrase: '', verifiedEmail: false, menuLayout: null,
}
export const ALLOWED_SETTINGS = new Set(Object.keys(DEFAULT_SETTINGS))

export const ALL_PERMISSIONS = ['users.view', 'users.manage', 'audit.view', 'panel.manage', 'ads.manage']
export const PERMISSION_CATALOG = [
  { id: 'users.view', label: 'Ver usuários' },
  { id: 'users.manage', label: 'Gerenciar usuários' },
  { id: 'audit.view', label: 'Ver atividades administrativas' },
  { id: 'ads.manage', label: 'Aprovar e gerenciar anúncios de empresas' },
  { id: 'panel.manage', label: 'Configurar módulos, IAs, fontes de mercado, Mercado Pago e planos' },
]
export function effectivePermissions(u: Pick<SessionUser, 'role' | 'permissions'>): string[] {
  if (u.role === 'superadmin') return [...ALL_PERMISSIONS]
  if (u.role === 'admin') return u.permissions.filter((p) => ALL_PERMISSIONS.includes(p))
  return []
}

export function settingsOf(u: SessionUser) {
  const s = { ...DEFAULT_SETTINGS, ...u.settings }
  s.timezone = validTz(s.timezone)
  return s
}
export function profileOf(u: SessionUser) {
  return { id: u.id, name: u.name, email: u.email, whatsapp: u.whatsapp, birthday: u.birthday, avatarUrl: u.avatar_url, role: u.role, createdAt: u.created_at }
}
export function meOf(u: SessionUser) {
  return {
    profile: profileOf(u),
    settings: settingsOf(u),
    interaction: u.interaction || {},
    chatUi: u.chat_ui || {},
    plan: { features: AVAILABLE_FEATURES.filter((f) => !(MOD_CACHE.voz === false && (f === 'text_voice' || f === 'voice_mode'))), required: false, current: null, usageAlert: null, limits: {}, usage: {} },
    spaces: { features: { enabled: false }, current: null },
    labs: [], labsApproved: [],
    elections: false, studio: false, email: false, mcp: false,
  }
}

export async function audit(actorId: number | null, action: string, targetId: number | null, details: object = {}) {
  await q('INSERT INTO audit_log (actor_id, action, target_id, details, created_at) VALUES ($1,$2,$3,$4,$5)',
    [actorId, action, targetId, JSON.stringify(details), nowIso()])
}
