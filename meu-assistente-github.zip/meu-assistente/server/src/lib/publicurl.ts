// Domínio oficial dos links públicos (assistentes das empresas, convites, catálogos, QR Codes, recuperação de
// senha e avisos de pagamento). Configurável no painel (Páginas e links); padrão: https://meuassistente.chat.
// Nunca usa o endereço antigo meuassistente.ivaslovck.tech.
import { getConfig } from './settings.js'
export const DEFAULT_PUBLIC = 'https://meuassistente.chat'
export const OLD_HOSTS = /(^|\.)ivaslovck\.tech$/i
let BASE = DEFAULT_PUBLIC
const clean = (u: string) => String(u || '').trim().replace(/\/+$/, '')
const valid = (u: string) => /^https?:\/\/[a-z0-9.-]+(:\d+)?$/i.test(u) && !OLD_HOSTS.test(new URL(u).hostname)
export const pub = () => BASE
export async function refreshPublicUrl() {
  const cfg = clean((await getConfig<any>('site', {}).catch(() => ({}))).url || '')
  const env = clean(process.env.PUBLIC_LINK_URL || '')
  BASE = valid(cfg) ? cfg : valid(env) ? env : DEFAULT_PUBLIC
  return BASE
}
/** Identificador amigável a partir do nome da empresa: "Pizzaria Bella Napoli" → "pizzaria-bella-napoli". */
export function slugify(nome: string) {
  return String(nome || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/&/g, ' e ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48).replace(/-+$/g, '') || 'empresa'
}
