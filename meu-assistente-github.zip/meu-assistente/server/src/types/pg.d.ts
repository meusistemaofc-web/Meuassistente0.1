// Declaração mínima do driver "pg" usada pelo projeto (evita depender de @types/pg).
declare module 'pg' {
  export interface QueryResult<R = any> { rows: R[]; rowCount: number | null }
  export interface PoolClient {
    query<R = any>(text: string, params?: unknown[]): Promise<QueryResult<R>>
    release(): void
  }
  export class Pool {
    constructor(opts: { connectionString?: string; max?: number; ssl?: unknown })
    query<R = any>(text: string, params?: unknown[]): Promise<QueryResult<R>>
    connect(): Promise<PoolClient>
    end(): Promise<void>
    on(event: 'error', cb: (err: Error) => void): void
  }
  export const types: { setTypeParser(oid: number, fn: (v: string) => unknown): void }
  const pg: { Pool: typeof Pool; types: typeof types }
  export default pg
}
