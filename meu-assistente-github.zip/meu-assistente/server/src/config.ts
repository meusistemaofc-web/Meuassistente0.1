import { readFileSync, existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

// Carrega .env (formato CHAVE=valor) sem dependências externas. Variáveis já definidas no ambiente prevalecem.
const here = dirname(fileURLToPath(import.meta.url))
const root = resolve(here, '..')
for (const p of [join(process.cwd(), '.env'), join(root, '.env'), join(root, '..', '.env')]) {
  if (!existsSync(p)) continue
  for (const line of readFileSync(p, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line)
    if (!m || line.trim().startsWith('#')) continue
    let v = m[2]
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1)
    if (process.env[m[1]] === undefined) process.env[m[1]] = v
  }
  break
}

const env = (k: string, d = '') => process.env[k] ?? d
export const config = {
  env: env('NODE_ENV', 'production'),
  port: Number(env('PORT', '3000')),
  host: env('HOST', '0.0.0.0'),
  publicUrl: env('PUBLIC_URL', 'http://localhost:3000').replace(/\/$/, ''),
  databaseUrl: env('DATABASE_URL'),
  sessionDays: Number(env('SESSION_DAYS', '30')),
  cookieSecure: env('COOKIE_SECURE', 'auto'), // auto = seguro quando PUBLIC_URL é https
  trustProxy: env('TRUST_PROXY', 'true') === 'true',
  staticDir: resolve(env('STATIC_DIR', join(root, '..', 'frontend', 'public'))),
  migrationsDir: resolve(env('MIGRATIONS_DIR', join(root, 'migrations'))),
  ai: {
    baseUrl: env('AI_BASE_URL', 'https://api.openai.com/v1').replace(/\/$/, ''),
    apiKey: env('AI_API_KEY'),
    model: env('AI_MODEL', 'gpt-4o-mini'),
    timeoutMs: Number(env('AI_TIMEOUT_MS', '45000')),
  },
  mail: {
    resendKey: env('RESEND_API_KEY'),
    from: env('MAIL_FROM', 'Meu Assistente <nao-responda@example.com>'),
  },
  setupCode: env('SETUP_CODE'),
  schedulerEnabled: env('SCHEDULER_ENABLED', 'true') === 'true',
  maxBodyBytes: Number(env('MAX_BODY_BYTES', String(2 * 1024 * 1024))),
}
export const secureCookies = () =>
  config.cookieSecure === 'true' || (config.cookieSecure === 'auto' && config.publicUrl.startsWith('https://'))
