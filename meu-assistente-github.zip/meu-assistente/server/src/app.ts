import { ticketsGet, ticketsPost, ticketAttGet, ticketGet, ticketMsgPost, adminTicketsGet, adminTicketGet, adminTicketPost } from './routes/tickets.js'
import { mktGet, mktPost, mktClickGet, mktUnsubGet, myConsentsGet, myConsentsPost } from './routes/marketing.js'
import { mpUserGet, mpUserPost, mpUserCallback } from './routes/mpuser.js'
import { INVITE_TPL } from './lib/invite.js'
import { emailAdminPost, emailLogGet, followupTestPost } from './routes/panel.js'
import { emailConfirmGet, emailOptOutGet } from './routes/me.js'
import { bizEmailPut, bizEmailPost } from './routes/businesses.js'
import { followupsGet, followupGet, followupPut } from './lib/followup.js'
import { menuPinsGet, menuPinsPut } from './routes/me.js'
// Servidor HTTP do Meu Assistente: API REST + arquivos do frontend (PWA) com fallback de SPA.
// Substitui o servidor TanStack Start que rodava nas Netlify Functions.
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { createReadStream, existsSync, statSync, readFileSync } from 'node:fs'
import { extname, join, normalize, sep } from 'node:path'
import { config } from './config.js'
import { readMultipart } from './lib/multipart.js'
import { pub, OLD_HOSTS } from './lib/publicurl.js'
import { fail, HttpError, parseCookies, readBody, sendJson, clientIp, type Ctx } from './lib/http.js'
import { loadSession } from './lib/session.js'
import { authGet, authPost } from './routes/auth.js'
import { meGet, mePatch } from './routes/me.js'
import { memoryGet, memoryPost } from './routes/memory.js'
import { notificationsGet, notificationsPost, pushGet, pushPost, pushDelete, pushDiagGet } from './routes/notifications.js'
import { itemsPost, agendaGet, financeGet, dayGet, summaryGet } from './routes/items.js'
import { chatJobGet, chatJobStream, imagesPost, chatPost, chatGet, chatDelete, conversationsGet, conversationPatch, conversationDelete } from './routes/chat.js'
import { adminGet, adminUsersGet, adminUsersPost, adminAuditGet } from './routes/admin.js'
import { syncPost } from './routes/sync.js'
import { panelGet, panelPut, panelPublicGet, panelTestPost, brainAnswersGet, brainKnowledgeGet, brainKnowledgePost, brainTestPost, brainAnswerPut, brainAnswerDelete, ttsPost, ttsStatusGet, ollamaModelsGet } from './routes/panel.js'
import { marketQuoteGet } from './routes/market.js'
import { itemGet } from './routes/appts.js'
import { shareConsentPost, apptTrackingGet, shareSavePost, apptGet, apptSharePost, sharePublicGet, appointmentsLegacyGet, appointmentsLegacyPost } from './routes/appts.js'
import { usageGet, subscriptionPost, subscriptionPayGet } from './routes/plans.js'
import { kbOfflineGet, adminKbGet, adminKbPost } from './routes/kb.js'
import { orderReviewPost, myReviewsGet, adminRatingsGet, adminRatingPut, agentOrderGet, agentInfoGet, agentOrderPost, agentSlotsGet, agentBookingPost } from './routes/businesses.js'
import { businessHitPost, reportGet, reportAiPost, reportMeiPost } from './routes/businesses.js'
import { orderPayPost, slotsGet, bookingPost } from './routes/businesses.js'
import { orderPayGet, storeMpPost, businessCardsGet, agentPut, agentGet, agentPayPost, agentPayGet, agentPublicGet, agentChatPost } from './routes/businesses.js'
import { myLocationPut, businessSearchGet, businessGet, productsGet, productsPost, orderPost, myOrdersGet, businessOrdersGet, businessOrderPost } from './routes/businesses.js'
import { adsRenewPost } from './routes/ads.js'
import { adsPlansGet, adsMineGet, adsPost, adsPut, adsDelete, adsPayPost, adsPayStatusGet, mpWebhookPost, adminAdsGet, adminAdsPost } from './routes/ads.js'
import { marketSeriesGet, marketSummaryGet, marketAlertsGet, marketAlertsPost, fiscalGet, fiscalPut } from './routes/modules.js'
import { db } from './db/index.js'

type Handler = (ctx: Ctx) => Promise<unknown>
const routes: { method: string; pattern: RegExp; keys: string[]; handler: Handler }[] = []
function route(method: string, path: string, handler: Handler) {
  const keys: string[] = []
  const pattern = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)' }) + '/?$')
  routes.push({ method, pattern, keys, handler })
}

route('GET', '/api/health', async () => { await db().query('SELECT 1'); return { ok: true, db: db().kind, time: new Date().toISOString() } })
route('GET', '/api/auth', authGet)
route('POST', '/api/auth', authPost)
route('GET', '/api/me', meGet)
route('PATCH', '/api/me', mePatch)
route('GET', '/api/memory', memoryGet)
route('POST', '/api/memory', memoryPost)
route('GET', '/api/notifications', notificationsGet)
route('POST', '/api/notifications', notificationsPost)
route('GET', '/api/push', pushGet)
route('POST', '/api/push', pushPost)
route('DELETE', '/api/push', pushDelete)
route('GET', '/api/push/diagnostico', pushDiagGet)
route('POST', '/api/items', itemsPost)
route('GET', '/api/agenda', agendaGet)
route('GET', '/api/finance', financeGet)
route('GET', '/api/day', dayGet)
route('GET', '/api/summary', summaryGet)
route('POST', '/api/sync', syncPost)
route('GET', '/api/chat', chatGet)
route('POST', '/api/chat', chatPost)
route('GET', '/api/v2/chat/jobs/:id', chatJobGet)
route('GET', '/api/v2/me/menu-pins', menuPinsGet)
route('PUT', '/api/v2/me/menu-pins', menuPinsPut)
route('GET', '/api/v2/chat/jobs/:id/stream', chatJobStream)
route('POST', '/api/images', imagesPost)
route('DELETE', '/api/chat', chatDelete)
route('GET', '/api/conversations', conversationsGet)
route('PATCH', '/api/conversations/:id', conversationPatch)
route('DELETE', '/api/conversations/:id', conversationDelete)
route('GET', '/api/assistant-avatar', async () => {
  const r = (await db().query("SELECT value FROM app_config WHERE key = 'assistant-avatar'"))[0]
  return { model: r ? String(r.value).replace(/"/g, '') : 'orb' }
})
route('GET', '/api/admin', adminGet)
route('GET', '/api/admin/users', adminUsersGet)
route('POST', '/api/admin/users', adminUsersPost)
route('GET', '/api/admin/audit', adminAuditGet)
route('GET', '/api/panel', panelGet)
route('GET', '/api/panel/public', panelPublicGet)
  route('GET', '/api/panel/ollama-models', ollamaModelsGet)
route('POST', '/api/panel/test', panelTestPost)
route('PUT', '/api/panel/:key', panelPut)
route('GET', '/api/panel/brain/answers', brainAnswersGet)
route('GET', '/api/panel/brain/knowledge', brainKnowledgeGet)
route('POST', '/api/panel/brain/knowledge', brainKnowledgePost)
route('POST', '/api/panel/brain/test', brainTestPost)
route('PUT', '/api/panel/brain/answers/:id', brainAnswerPut)
route('DELETE', '/api/panel/brain/answers/:id', brainAnswerDelete)
route('POST', '/api/tts', ttsPost)
route('GET', '/api/tts', ttsStatusGet)
route('GET', '/api/v2/market/quote', marketQuoteGet)
route('GET', '/api/v2/market/series', marketSeriesGet)
route('GET', '/api/v2/market/summary', marketSummaryGet)
route('GET', '/api/v2/market/alerts', marketAlertsGet)
route('POST', '/api/v2/market/alerts', marketAlertsPost)
route('GET', '/api/v2/fiscal', fiscalGet)
route('GET', '/api/appointments', appointmentsLegacyGet)
route('POST', '/api/appointments', appointmentsLegacyPost)
route('GET', '/api/v2/appointments/:id', apptGet)
route('GET', '/api/v2/item/:id', itemGet)
route('POST', '/api/v2/appointments/:id/share', apptSharePost)
route('GET', '/api/v2/share/:token', sharePublicGet)
route('POST', '/api/v2/share/:token/consent', shareConsentPost)
route('GET', '/api/v2/appointments/:id/tracking', apptTrackingGet)
route('GET', '/api/v2/marketing', mktGet)
route('GET', '/api/v2/tickets', ticketsGet)
route('POST', '/api/v2/tickets', ticketsPost)
route('GET', '/api/v2/tickets/anexo/:id', ticketAttGet)
route('GET', '/api/v2/tickets/:id', ticketGet)
route('POST', '/api/v2/tickets/:id/messages', ticketMsgPost)
route('GET', '/api/panel/tickets', adminTicketsGet)
route('GET', '/api/panel/tickets/:id', adminTicketGet)
route('POST', '/api/panel/tickets/:id', adminTicketPost)
route('POST', '/api/v2/marketing', mktPost)
route('GET', '/api/v2/marketing/c/:id', mktClickGet)
route('GET', '/api/v2/marketing/sair', mktUnsubGet)
route('GET', '/api/v2/me/consents', myConsentsGet)
route('POST', '/api/v2/me/consents', myConsentsPost)
route('GET', '/api/v2/followups', followupsGet)
route('POST', '/api/panel/email', emailAdminPost)
route('GET', '/api/mercadopago', mpUserGet)
route('POST', '/api/mercadopago', mpUserPost)
route('GET', '/api/mercadopago/oauth/callback', mpUserCallback)
route('POST', '/api/panel/followup-test', followupTestPost)
route('GET', '/api/panel/email/log', emailLogGet)
route('GET', '/api/v2/email/confirmar', emailConfirmGet)
route('GET', '/api/v2/email/sair', emailOptOutGet)
route('PUT', '/api/v2/ads/:id/email', bizEmailPut)
route('POST', '/api/v2/ads/:id/email', bizEmailPost)
route('GET', '/api/v2/followups/:id', followupGet)
route('PUT', '/api/v2/followups/:id', followupPut)
route('POST', '/api/v2/share/:token/save', shareSavePost)
route('GET', '/api/v2/usage', usageGet)
route('POST', '/api/v2/subscription', subscriptionPost)
route('GET', '/api/v2/subscription/pay', subscriptionPayGet)
route('GET', '/api/kb-offline', kbOfflineGet)
route('GET', '/api/v2/admin/kb', adminKbGet)
route('POST', '/api/v2/admin/kb', adminKbPost)
route('PUT', '/api/v2/me/location', myLocationPut)
route('GET', '/api/v2/businesses/search', businessSearchGet)
route('GET', '/api/v2/businesses/cards', businessCardsGet)
route('POST', '/api/v2/businesses/:id/hit', businessHitPost)
route('GET', '/api/v2/ads/:id/report', reportGet)
route('POST', '/api/v2/ads/:id/report/ai', reportAiPost)
route('POST', '/api/v2/ads/:id/report/mei', reportMeiPost)
route('GET', '/api/v2/businesses/:id', businessGet)
route('POST', '/api/v2/businesses/:id/orders', orderPost)
route('GET', '/api/v2/businesses/:id/slots', slotsGet)
route('POST', '/api/v2/businesses/:id/bookings', bookingPost)
route('GET', '/api/v2/orders/mine', myOrdersGet)
route('GET', '/api/v2/orders/:id/pay', orderPayGet)
route('POST', '/api/v2/orders/:id/pay', orderPayPost)
route('POST', '/api/v2/ads/:id/mp', storeMpPost)
route('GET', '/api/v2/ads/:id/products', productsGet)
route('POST', '/api/v2/ads/:id/products', productsPost)
route('GET', '/api/v2/ads/:id/orders', businessOrdersGet)
route('POST', '/api/v2/ads/:id/orders/:oid', businessOrderPost)
route('GET', '/api/v2/ads/plans', adsPlansGet)
route('GET', '/api/v2/ads/mine', adsMineGet)
route('POST', '/api/v2/ads', adsPost)
route('PUT', '/api/v2/ads/:id', adsPut)
route('DELETE', '/api/v2/ads/:id', adsDelete)
route('POST', '/api/v2/ads/:id/pay', adsPayPost)
route('POST', '/api/v2/ads/:id/renew', adsRenewPost)
route('GET', '/api/v2/ads/:id/agent', agentGet)
route('PUT', '/api/v2/ads/:id/agent', agentPut)
route('POST', '/api/v2/ads/:id/agent/pay', agentPayPost)
route('GET', '/api/v2/ads/:id/agent/pay', agentPayGet)
route('GET', '/api/v2/agent/:id', agentPublicGet)
route('POST', '/api/v2/agent/:id/chat', agentChatPost)
route('GET', '/api/v2/agent/:id/orders/:oid', agentOrderGet)
route('POST', '/api/v2/orders/:id/review', orderReviewPost)
route('GET', '/api/v2/reviews/mine', myReviewsGet)
route('GET', '/api/v2/admin/ratings', adminRatingsGet)
route('PUT', '/api/v2/admin/ratings/:id', adminRatingPut)
route('GET', '/api/v2/agent/:id/info', agentInfoGet)
route('POST', '/api/v2/agent/:id/order', agentOrderPost)
route('GET', '/api/v2/agent/:id/slots', agentSlotsGet)
route('POST', '/api/v2/agent/:id/booking', agentBookingPost)
route('GET', '/api/v2/ads/:id/pay', adsPayStatusGet)
route('POST', '/api/mercadopago/webhook', mpWebhookPost)
route('GET', '/api/v2/admin/ads', adminAdsGet)
route('POST', '/api/v2/admin/ads/:id', adminAdsPost)
route('PUT', '/api/v2/fiscal', fiscalPut)

/** Módulos do sistema original cujo backend não estava no ZIP e ainda não foi reconstruído. */
export const NOT_RECONSTRUCTED: Record<string, string> = {
  '/api/billing': 'Planos e assinaturas', '/api/mercadopago': 'Pagamentos Mercado Pago', '/api/studio': 'Estúdio (vídeos)',
  '/api/fiscal': 'Calendário fiscal', '/api/das': 'DAS MEI', '/api/market': 'Mercado e investimentos', '/api/b3': 'Cotações B3',
  '/api/brain': 'Cérebro do chat (admin)', '/api/eleicoes': 'Eleições 2026', '/api/campanha': 'Campanha eleitoral',
  '/api/push': 'Notificações push', '/api/medications': 'Medicamentos', '/api/meals': 'Alimentação', '/api/training': 'Treinos',
  '/api/emails': 'E-mails', '/api/whatsapp': 'WhatsApp', '/api/mcp': 'Conexões MCP', '/api/images': 'Imagens',
  '/api/maps': 'Mapas', '/api/news': 'Notícias', '/api/labs': 'Recursos experimentais', '/api/spaces': 'Espaços compartilhados',
  '/api/ads': 'Anúncios', '/api/anunciar': 'Anuncie', '/api/appointments': 'Compartilhamento de compromissos', '/api/convite': 'Convites',
  '/api/tts': 'Voz natural', '/api/transcribe': 'Transcrição de áudio', '/api/voice': 'Áudios de voz', '/api/avatar': 'Foto de perfil',
  '/api/kb-file': 'Base de conhecimento', '/api/kb-image': 'Base de conhecimento', '/api/kb-offline': 'Base de conhecimento',
  '/api/setup': 'Assistente de configuração', '/api/messages': 'Mensagens', '/api/visitante': 'Visitante', '/api/admin': 'Painel administrativo',
}
function notReconstructed(path: string): string | null {
  const key = Object.keys(NOT_RECONSTRUCTED).filter((k) => path === k || path.startsWith(k + '/') || path.startsWith(k + '?')).sort((a, b) => b.length - a.length)[0]
  return key ? NOT_RECONSTRUCTED[key] : null
}

const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN', // permite abrir módulos dentro do chat (mesmo domínio), bloqueia sites de fora
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), geolocation=(self), payment=(self), usb=(), microphone=(self), accelerometer=(self), gyroscope=(self), magnetometer=(self)',
}
const TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
}

function serveStatic(req: IncomingMessage, res: ServerResponse, path: string) {
  const root = config.staticDir
  let rel = decodeURIComponent(path)
  if (rel === '/painel' || rel === '/painel/' || rel === '/painel.html') { res.writeHead(302, { Location: '/admin' }); return res.end() }
  if (/^\/a\/\d+\/?$/.test(rel)) rel = '/agente.html'
  if (/^\/c\/[\w-]{6,40}\/?$/.test(rel)) rel = '/compromisso.html' // convite de compromisso // página pública do agente de atendimento
  const file = normalize(join(root, rel))
  if (!file.startsWith(root + sep) && file !== root) { res.writeHead(400); return res.end() }
  let target = file
  let isFile = existsSync(target) && statSync(target).isFile()
  if (!isFile) {
    if (rel.startsWith('/assets/') || extname(rel)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...SECURITY_HEADERS }); return res.end('Não encontrado') }
    target = join(root, 'index.html') // rotas do app (SPA)
    isFile = existsSync(target)
    if (!isFile) { res.writeHead(500); return res.end('index.html ausente') }
  }
  const ext = extname(target)
  const cache = rel === '/assets/index-MUcZwl3l.js' ? 'no-cache' : rel.startsWith('/assets/') ? 'public, max-age=31536000, immutable'
    : ext === '.html' || rel === '/sw.js' || rel === '/manifest.webmanifest' ? 'no-cache' : 'public, max-age=86400'
  const headers: Record<string, string> = { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': cache, ...SECURITY_HEADERS }
  if (rel === '/sw.js') headers['Service-Worker-Allowed'] = '/'
  if (secureHsts()) headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
  if (target.endsWith('index.html')) {
    // Acrescenta as novas abas do painel administrativo (Módulos, IA, Fontes de mercado, Mercado Pago, Planos, Cérebro).
    const html = readFileSync(target, 'utf8').replace('<head>', '<head><script>window.__MA_PUB=' + JSON.stringify(pub()) + ';window.__MA_INVITE_TPL=' + JSON.stringify(INVITE_TPL).replace(/</g, '\\u003c') + '</script><style>html:not(.ma-qb-ok) .chat-scroll .mt-7{visibility:hidden!important}html.ma-qb-off .chat-scroll .mt-7{display:none!important}</style><script>try{if(localStorage.getItem(\'ma-qb\')===\'off\')document.documentElement.classList.add(\'ma-qb-off\',\'ma-qb-ok\')}catch(e){}</script><script src="/chat-stream-addon.js?v=1"></script><script src="/splash.js?v=3"></script>').replace('</body>', '<script src="/panel-addon.js?v=112" defer></script><script src="/modules-addon.js?v=65" defer></script><script src="/chat-welcome-addon.js?v=2" defer></script></body>')
    res.writeHead(200, headers)
    return res.end(req.method === 'HEAD' ? undefined : html)
  }
  res.writeHead(200, headers)
  if (req.method === 'HEAD') return res.end()
  createReadStream(target).pipe(res)
}
const secureHsts = () => config.publicUrl.startsWith('https://')

async function handle(req: IncomingMessage, res: ServerResponse) {
  const url = new URL(req.url || '/', 'http://localhost')
  const path = url.pathname
  const method = (req.method || 'GET').toUpperCase()
  if (!path.startsWith('/api/')) {
    if (method !== 'GET' && method !== 'HEAD') { res.writeHead(405); return res.end() }
    // links públicos acessados pelo endereço antigo vão para o domínio oficial (mesmo caminho)
    const host = String(req.headers.host || '').split(':')[0]
    if (OLD_HOSTS.test(host) && /^\/(a\/\d+|g-[a-z0-9-]+|c\/[\w-]+|x\/empresa\/\d+)\/?$/.test(path) && new URL(pub()).hostname !== host) { res.writeHead(301, { Location: pub() + path + url.search }); return res.end() }
    const ga = /^\/a\/(\d+)\/?$/.exec(path)
    if (ga) { const sl = await (await import('./routes/businesses.js')).slugOfId(Number(ga[1])).catch(() => null); if (sl) { res.writeHead(301, { Location: `/g-${sl}${url.search}` }); return res.end() } }
    const gs = /^\/g-([a-z0-9-]{1,60})\/?$/.exec(path)
    if (gs) {
      const id = await (await import('./routes/businesses.js')).idOfSlug(gs[1]).catch(() => null)
      if (!id) { res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', ...SECURITY_HEADERS }); return res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#000;color:#fff;padding:32px"><h1 style="font-size:20px">Atendimento não encontrado</h1><p style="color:#aaa">Confira o link com a empresa.</p></body>') }
      const html = readFileSync(join(config.staticDir, 'agente.html'), 'utf8').replace('<head>', `<head><script>window.__MA_AGENT=${Number(id)}</script>`)
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', ...SECURITY_HEADERS }); return res.end(html)
    }
    return serveStatic(req, res, path)
  }
  const ctx: Ctx = { req, res, method, path, url, query: url.searchParams, ip: clientIp(req), body: {}, cookies: parseCookies(req.headers.cookie), setCookies: [], params: {} }
  const extra: Record<string, string | string[]> = { ...SECURITY_HEADERS }
  try {
    // proteção CSRF: requisições que alteram dados precisam vir do próprio site
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin
      if (origin && new URL(origin).host !== req.headers.host && origin !== config.publicUrl && origin !== pub())
        throw new HttpError(403, 'Origem não permitida.', 'bad_origin')
    }
    const match = routes.find((r) => r.method === method && r.pattern.test(path))
    if (!match) {
      const mod = notReconstructed(path)
      if (mod) throw new HttpError(501, `O módulo "${mod}" ainda não foi reconstruído neste servidor.`, 'not_reconstructed')
      const exists = routes.some((r) => r.pattern.test(path))
      throw new HttpError(exists ? 405 : 404, exists ? 'Método não permitido.' : 'Rota não encontrada.', exists ? 'method_not_allowed' : 'not_found')
    }
    const m = match.pattern.exec(path)!
    match.keys.forEach((k, i) => (ctx.params[k] = decodeURIComponent(m[i + 1])))
    if (method !== 'GET' && method !== 'HEAD') {
      const ct = String(req.headers['content-type'] || '')
      if (ct.startsWith('multipart/')) { const mp = await readMultipart(req); ctx.body = mp.fields; (ctx as any).files = mp.files } else {
        const raw = await readBody(req)
        if (raw.length) {
          try { ctx.body = JSON.parse(raw.toString('utf8')) } catch { throw new HttpError(400, 'JSON inválido.', 'invalid_json') }
        }
      }
    }
    await loadSession(ctx)
    const data = await match.handler(ctx)
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    if (data && (data as any)._handled) return // a rota já escreveu a resposta (streaming)
    if (data && (data as any)._binary) {
      const bin = data as any
      res.writeHead(bin.status || 200, { ...(bin.data ? { 'Content-Type': bin.mime, 'Content-Length': bin.data.length } : {}), 'Cache-Control': 'private, max-age=3600', ...(bin.headers || {}), ...extra })
      res.end(bin.data || undefined)
      return
    }
    sendJson(res, 200, data ?? { ok: true }, extra)
  } catch (e: any) {
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    if (e instanceof HttpError && (e as any).attempts && (ctx as any).user && (ctx as any).user.role !== 'user') // administrador vê por que cada IA falhou
      e.message += ` [Detalhe para o administrador: ${((e as any).attempts as any[]).map((a) => `${a.nome}: ${a.msg}`).join(' | ')}]`
    if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message, ...(e.code ? { code: e.code } : {}), ...(e.field ? { field: e.field } : {}), ...((e as any).extra ? { info: (e as any).extra } : {}) }, extra)
    console.error(`[api] ${method} ${path}:`, e)
    sendJson(res, 500, { error: 'Algo deu errado no servidor.', code: 'server_error' }, extra)
  }
}

export function createApp() {
  return createServer((req, res) => { handle(req, res).catch((e) => { console.error(e); try { res.writeHead(500); res.end() } catch {} }) })
}
export const indexHtmlPresent = () => existsSync(join(config.staticDir, 'index.html')) && readFileSync(join(config.staticDir, 'index.html'), 'utf8').includes('$_TSR')
