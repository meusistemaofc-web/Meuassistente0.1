// Servidor HTTP do Meu Assistente: API REST + arquivos do frontend (PWA) com fallback de SPA.
// Substitui o servidor TanStack Start que rodava nas Netlify Functions.
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { createReadStream, existsSync, statSync, readFileSync } from 'node:fs'
import { extname, join, normalize, sep } from 'node:path'
import { config } from './config.js'
import { fail, HttpError, parseCookies, readBody, sendJson, clientIp, type Ctx } from './lib/http.js'
import { loadSession } from './lib/session.js'
import { authGet, authPost } from './routes/auth.js'
import { meGet, mePatch } from './routes/me.js'
import { memoryGet, memoryPost } from './routes/memory.js'
import { notificationsGet, notificationsPost } from './routes/notifications.js'
import { itemsPost, agendaGet, financeGet, dayGet, summaryGet } from './routes/items.js'
import { chatPost, chatGet, chatDelete, conversationsGet, conversationPatch, conversationDelete } from './routes/chat.js'
import { adminGet, adminUsersGet, adminUsersPost, adminAuditGet } from './routes/admin.js'
import { syncPost } from './routes/sync.js'
import { panelGet, panelPut, panelPublicGet, panelTestPost } from './routes/panel.js'
import { marketQuoteGet } from './routes/market.js'
import { usageGet, subscriptionPost, subscriptionPayGet } from './routes/plans.js'
import { kbOfflineGet, adminKbGet, adminKbPost } from './routes/kb.js'
import { businessHitPost, reportGet, reportAiPost, reportMeiPost } from './routes/businesses.js'
import { orderPayPost, slotsGet, bookingPost } from './routes/businesses.js'
import { orderPayGet, storeMpPost, businessCardsGet, agentPut, agentGet, agentPayPost, agentPayGet, agentPublicGet, agentChatPost } from './routes/businesses.js'
import { myLocationPut, businessSearchGet, businessGet, productsGet, productsPost, orderPost, myOrdersGet, businessOrdersGet, businessOrderPost } from './routes/businesses.js'
import { adsRenewPost } from './routes/ads.js'
import { adsPlansGet, adsMineGet, adsPost, adsPut, adsPayPost, adsPayStatusGet, mpWebhookPost, adminAdsGet, adminAdsPost } from './routes/ads.js'
import { marketSeriesGet, marketSummaryGet, marketAlertsGet, marketAlertsPost, fiscalGet, fiscalPut } from './routes/modules.js'
import { db } from './db/index.js'

type Handler = (ctx: Ctx) => Promise<unknown>
const routes: { method: string; pattern: RegExp; keys: string[]; handler: Handler }[] = []
function route(method: string, path: string, handler: Handler) {
  const keys: string[] = []
  const pattern = new RegExp('^' + path.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)' }) + '/?$')
  routes.push({ method, pattern, keys, handler })
}

route('GET', '/api/health', async () => { await db().query('SELECT 1'); return { ok: true, db: db().kind, time: new Date().toISOString() } })
route('GET', '/api/auth', authGet)
route('POST', '/api/auth', authPost)
route('GET', '/api/me', meGet)
route('PATCH', '/api/me', mePatch)
route('GET', '/api/memory', memoryGet)
route('POST', '/api/memory', memoryPost)
route('GET', '/api/notifications', notificationsGet)
route('POST', '/api/notifications', notificationsPost)
route('POST', '/api/items', itemsPost)
route('GET', '/api/agenda', agendaGet)
route('GET', '/api/finance', financeGet)
route('GET', '/api/day', dayGet)
route('GET', '/api/summary', summaryGet)
route('POST', '/api/sync', syncPost)
route('GET', '/api/chat', chatGet)
route('POST', '/api/chat', chatPost)
route('DELETE', '/api/chat', chatDelete)
route('GET', '/api/conversations', conversationsGet)
route('PATCH', '/api/conversations/:id', conversationPatch)
route('DELETE', '/api/conversations/:id', conversationDelete)
route('GET', '/api/assistant-avatar', async () => {
  const r = (await db().query("SELECT value FROM app_config WHERE key = 'assistant-avatar'"))[0]
  return { model: r ? String(r.value).replace(/"/g, '') : 'orb' }
})
route('GET', '/api/admin', adminGet)
route('GET', '/api/admin/users', adminUsersGet)
route('POST', '/api/admin/users', adminUsersPost)
route('GET', '/api/admin/audit', adminAuditGet)
route('GET', '/api/panel', panelGet)
route('GET', '/api/panel/public', panelPublicGet)
route('POST', '/api/panel/test', panelTestPost)
route('PUT', '/api/panel/:key', panelPut)
route('GET', '/api/v2/market/quote', marketQuoteGet)
route('GET', '/api/v2/market/series', marketSeriesGet)
route('GET', '/api/v2/market/summary', marketSummaryGet)
route('GET', '/api/v2/market/alerts', marketAlertsGet)
route('POST', '/api/v2/market/alerts', marketAlertsPost)
route('GET', '/api/v2/fiscal', fiscalGet)
route('GET', '/api/v2/usage', usageGet)
route('POST', '/api/v2/subscription', subscriptionPost)
route('GET', '/api/v2/subscription/pay', subscriptionPayGet)
route('GET', '/api/kb-offline', kbOfflineGet)
route('GET', '/api/tts', async () => ({ available: false, maxChars: 0, playback: 'manual' }))
route('POST', '/api/tts', async () => fail(503, 'Voz natural indisponível: usando a voz do aparelho.', 'unavailable'))
route('GET', '/api/v2/admin/kb', adminKbGet)
route('POST', '/api/v2/admin/kb', adminKbPost)
route('PUT', '/api/v2/me/location', myLocationPut)
route('GET', '/api/v2/businesses/search', businessSearchGet)
route('GET', '/api/v2/businesses/cards', businessCardsGet)
route('POST', '/api/v2/businesses/:id/hit', businessHitPost)
route('GET', '/api/v2/ads/:id/report', reportGet)
route('POST', '/api/v2/ads/:id/report/ai', reportAiPost)
route('POST', '/api/v2/ads/:id/report/mei', reportMeiPost)
route('GET', '/api/v2/businesses/:id', businessGet)
route('POST', '/api/v2/businesses/:id/orders', orderPost)
route('GET', '/api/v2/businesses/:id/slots', slotsGet)
route('POST', '/api/v2/businesses/:id/bookings', bookingPost)
route('GET', '/api/v2/orders/mine', myOrdersGet)
route('GET', '/api/v2/orders/:id/pay', orderPayGet)
route('POST', '/api/v2/orders/:id/pay', orderPayPost)
route('POST', '/api/v2/ads/:id/mp', storeMpPost)
route('GET', '/api/v2/ads/:id/products', productsGet)
route('POST', '/api/v2/ads/:id/products', productsPost)
route('GET', '/api/v2/ads/:id/orders', businessOrdersGet)
route('POST', '/api/v2/ads/:id/orders/:oid', businessOrderPost)
route('GET', '/api/v2/ads/plans', adsPlansGet)
route('GET', '/api/v2/ads/mine', adsMineGet)
route('POST', '/api/v2/ads', adsPost)
route('PUT', '/api/v2/ads/:id', adsPut)
route('POST', '/api/v2/ads/:id/pay', adsPayPost)
route('POST', '/api/v2/ads/:id/renew', adsRenewPost)
route('GET', '/api/v2/ads/:id/agent', agentGet)
route('PUT', '/api/v2/ads/:id/agent', agentPut)
route('POST', '/api/v2/ads/:id/agent/pay', agentPayPost)
route('GET', '/api/v2/ads/:id/agent/pay', agentPayGet)
route('GET', '/api/v2/agent/:id', agentPublicGet)
route('POST', '/api/v2/agent/:id/chat', agentChatPost)
route('GET', '/api/v2/ads/:id/pay', adsPayStatusGet)
route('POST', '/api/mercadopago/webhook', mpWebhookPost)
route('GET', '/api/v2/admin/ads', adminAdsGet)
route('POST', '/api/v2/admin/ads/:id', adminAdsPost)
route('PUT', '/api/v2/fiscal', fiscalPut)

/** Módulos do sistema original cujo backend não estava no ZIP e ainda não foi reconstruído. */
export const NOT_RECONSTRUCTED: Record<string, string> = {
  '/api/billing': 'Planos e assinaturas', '/api/mercadopago': 'Pagamentos Mercado Pago', '/api/studio': 'Estúdio (vídeos)',
  '/api/fiscal': 'Calendário fiscal', '/api/das': 'DAS MEI', '/api/market': 'Mercado e investimentos', '/api/b3': 'Cotações B3',
  '/api/brain': 'Cérebro do chat (admin)', '/api/eleicoes': 'Eleições 2026', '/api/campanha': 'Campanha eleitoral',
  '/api/push': 'Notificações push', '/api/medications': 'Medicamentos', '/api/meals': 'Alimentação', '/api/training': 'Treinos',
  '/api/emails': 'E-mails', '/api/whatsapp': 'WhatsApp', '/api/mcp': 'Conexões MCP', '/api/images': 'Imagens',
  '/api/maps': 'Mapas', '/api/news': 'Notícias', '/api/labs': 'Recursos experimentais', '/api/spaces': 'Espaços compartilhados',
  '/api/ads': 'Anúncios', '/api/anunciar': 'Anuncie', '/api/appointments': 'Compartilhamento de compromissos', '/api/convite': 'Convites',
  '/api/tts': 'Voz natural', '/api/transcribe': 'Transcrição de áudio', '/api/voice': 'Áudios de voz', '/api/avatar': 'Foto de perfil',
  '/api/kb-file': 'Base de conhecimento', '/api/kb-image': 'Base de conhecimento', '/api/kb-offline': 'Base de conhecimento',
  '/api/setup': 'Assistente de configuração', '/api/messages': 'Mensagens', '/api/visitante': 'Visitante', '/api/admin': 'Painel administrativo',
}
function notReconstructed(path: string): string | null {
  const key = Object.keys(NOT_RECONSTRUCTED).filter((k) => path === k || path.startsWith(k + '/') || path.startsWith(k + '?')).sort((a, b) => b.length - a.length)[0]
  return key ? NOT_RECONSTRUCTED[key] : null
}

const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), geolocation=(self), payment=(self), usb=(), microphone=(self), accelerometer=(self), gyroscope=(self), magnetometer=(self)',
}
const TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
}

function serveStatic(req: IncomingMessage, res: ServerResponse, path: string) {
  const root = config.staticDir
  let rel = decodeURIComponent(path)
  if (rel === '/painel' || rel === '/painel/' || rel === '/painel.html') { res.writeHead(302, { Location: '/admin' }); return res.end() }
  if (/^\/a\/\d+\/?$/.test(rel)) rel = '/agente.html' // página pública do agente de atendimento
  const file = normalize(join(root, rel))
  if (!file.startsWith(root + sep) && file !== root) { res.writeHead(400); return res.end() }
  let target = file
  let isFile = existsSync(target) && statSync(target).isFile()
  if (!isFile) {
    if (rel.startsWith('/assets/') || extname(rel)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', ...SECURITY_HEADERS }); return res.end('Não encontrado') }
    target = join(root, 'index.html') // rotas do app (SPA)
    isFile = existsSync(target)
    if (!isFile) { res.writeHead(500); return res.end('index.html ausente') }
  }
  const ext = extname(target)
  const cache = rel === '/assets/index-MUcZwl3l.js' ? 'no-cache' : rel.startsWith('/assets/') ? 'public, max-age=31536000, immutable'
    : ext === '.html' || rel === '/sw.js' || rel === '/manifest.webmanifest' ? 'no-cache' : 'public, max-age=86400'
  const headers: Record<string, string> = { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': cache, ...SECURITY_HEADERS }
  if (rel === '/sw.js') headers['Service-Worker-Allowed'] = '/'
  if (secureHsts()) headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
  if (target.endsWith('index.html')) {
    // Acrescenta as novas abas do painel administrativo (Módulos, IA, Fontes de mercado, Mercado Pago, Planos, Cérebro).
    const html = readFileSync(target, 'utf8').replace('</body>', '<script src="/panel-addon.js?v=12" defer></script><script src="/modules-addon.js?v=17" defer></script></body>')
    res.writeHead(200, headers)
    return res.end(req.method === 'HEAD' ? undefined : html)
  }
  res.writeHead(200, headers)
  if (req.method === 'HEAD') return res.end()
  createReadStream(target).pipe(res)
}
const secureHsts = () => config.publicUrl.startsWith('https://')

async function handle(req: IncomingMessage, res: ServerResponse) {
  const url = new URL(req.url || '/', 'http://localhost')
  const path = url.pathname
  const method = (req.method || 'GET').toUpperCase()
  if (!path.startsWith('/api/')) {
    if (method !== 'GET' && method !== 'HEAD') { res.writeHead(405); return res.end() }
    return serveStatic(req, res, path)
  }
  const ctx: Ctx = { req, res, method, path, url, query: url.searchParams, ip: clientIp(req), body: {}, cookies: parseCookies(req.headers.cookie), setCookies: [], params: {} }
  const extra: Record<string, string | string[]> = { ...SECURITY_HEADERS }
  try {
    // proteção CSRF: requisições que alteram dados precisam vir do próprio site
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin
      if (origin && new URL(origin).host !== req.headers.host && origin !== config.publicUrl)
        throw new HttpError(403, 'Origem não permitida.', 'bad_origin')
    }
    const match = routes.find((r) => r.method === method && r.pattern.test(path))
    if (!match) {
      const mod = notReconstructed(path)
      if (mod) throw new HttpError(501, `O módulo "${mod}" ainda não foi reconstruído neste servidor.`, 'not_reconstructed')
      const exists = routes.some((r) => r.pattern.test(path))
      throw new HttpError(exists ? 405 : 404, exists ? 'Método não permitido.' : 'Rota não encontrada.', exists ? 'method_not_allowed' : 'not_found')
    }
    const m = match.pattern.exec(path)!
    match.keys.forEach((k, i) => (ctx.params[k] = decodeURIComponent(m[i + 1])))
    if (method !== 'GET' && method !== 'HEAD') {
      const ct = String(req.headers['content-type'] || '')
      if (ct.startsWith('multipart/')) { req.resume() } else {
        const raw = await readBody(req)
        if (raw.length) {
          try { ctx.body = JSON.parse(raw.toString('utf8')) } catch { throw new HttpError(400, 'JSON inválido.', 'invalid_json') }
        }
      }
    }
    await loadSession(ctx)
    const data = await match.handler(ctx)
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    sendJson(res, 200, data ?? { ok: true }, extra)
  } catch (e: any) {
    if (ctx.setCookies.length) extra['Set-Cookie'] = ctx.setCookies
    if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message, ...(e.code ? { code: e.code } : {}), ...(e.field ? { field: e.field } : {}), ...((e as any).extra ? { info: (e as any).extra } : {}) }, extra)
    console.error(`[api] ${method} ${path}:`, e)
    sendJson(res, 500, { error: 'Algo deu errado no servidor.', code: 'server_error' }, extra)
  }
}

export function createApp() {
  return createServer((req, res) => { handle(req, res).catch((e) => { console.error(e); try { res.writeHead(500); res.end() } catch {} }) })
}
export const indexHtmlPresent = () => existsSync(join(config.staticDir, 'index.html')) && readFileSync(join(config.staticDir, 'index.html'), 'utf8').includes('$_TSR')
