// Biblioteca de Sobrevivência: lista e partes para download offline (contrato do app original /api/kb-offline)
// e cadastro de materiais pelo administrador.
import { createHash } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { KB_SEED } from '../lib/kb-seed.js'

const PART = 120
interface Chunk { p: number; s: number; e: number; r?: string; c: string }
export function toChunks(content: string): Chunk[] {
  const out: Chunk[] = []; let sec = 0, head = '', buf = ''
  const flush = () => { const c = buf.trim(); if (c) out.push({ p: out.length, s: Math.max(1, sec), e: Math.max(1, sec), r: head || `parte ${Math.max(1, sec)}`, c }); buf = '' }
  for (const raw of String(content || '').replace(/\r/g, '').split('\n')) {
    const line = raw.trim()
    if (/^#{1,3}\s+/.test(line)) { flush(); sec++; head = line.replace(/^#+\s+/, '').slice(0, 120); continue }
    if (!line) { if (buf.length > 600) flush(); else if (buf) buf += '\n'; continue }
    if (!sec) sec = 1
    if ((buf + ' ' + line).length > 900) flush()
    buf += (buf && !buf.endsWith('\n') ? ' ' : '') + line
  }
  flush()
  return out
}
const digest = (chunks: Chunk[]) => createHash('sha256').update([...chunks].sort((a, b) => a.p - b.p).map((a) => `${a.p}\u001f${a.s}\u001f${a.e}\u001f${a.r ?? ''}\u001f${a.c}`).join('\u001e')).digest('hex')
const bool = (v: any) => v === true || v === 1 || v === 't' || v === 'true'
function meta(d: any) {
  const ch = J<Chunk[]>(d.chunks, [])
  return { id: Number(d.id), title: d.title, description: d.description || '', keywords: J<string[]>(d.keywords, []), kind: 'text', sos: bool(d.sos),
    version: Number(d.version), digest: digest(ch), parts: Math.max(1, Math.ceil(ch.length / PART)), chunks: ch.length, bytes: Buffer.byteLength(JSON.stringify(ch)) }
}
export async function seedKb() {
  const n = await one('SELECT COUNT(*) AS n FROM kb_docs')
  if (Number(n?.n || 0) > 0) return
  for (const d of KB_SEED) await q('INSERT INTO kb_docs (title, description, keywords, sos, active, version, chunks, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,1,$6,$7,$7)', [d.title, d.description, JSON.stringify(d.keywords), true, true, JSON.stringify(toChunks(d.content)), nowIso()])
}
export async function kbOfflineGet(ctx: Ctx) {
  requireUser(ctx)
  const id = ctx.query.get('id')
  if (id) {
    const d = await one('SELECT * FROM kb_docs WHERE id = $1 AND active = $2', [Number(id), true])
    if (!d) fail(404, 'Material não encontrado.', 'not_found')
    if (String(d!.version) !== String(ctx.query.get('v'))) fail(409, 'O material foi atualizado. Baixe de novo.', 'stale')
    const part = Math.max(0, Number(ctx.query.get('part')) || 0), ch = J<Chunk[]>(d!.chunks, [])
    return { chunks: ch.slice(part * PART, part * PART + PART) }
  }
  return { docs: (await q('SELECT * FROM kb_docs WHERE active = $1 ORDER BY sos DESC, id', [true])).map(meta) }
}
function requireKbAdmin(ctx: Ctx) { const u = requireUser(ctx); if (u.role === 'user' || !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão.', 'forbidden'); return u }
export async function adminKbGet(ctx: Ctx) {
  requireKbAdmin(ctx)
  return { items: (await q('SELECT * FROM kb_docs ORDER BY id')).map((d) => ({ ...meta(d), active: bool(d.active), content: J<Chunk[]>(d.chunks, []).map((c, i, a) => (i === 0 || a[i - 1].r !== c.r ? `# ${c.r}\n` : '') + c.c.replace(`${c.r}. `, '')).join('\n\n'), updatedAt: d.updated_at })) }
}
export async function adminKbPost(ctx: Ctx) {
  const u = requireKbAdmin(ctx), b = ctx.body || {}
  if (b.action === 'delete') { await q('DELETE FROM kb_docs WHERE id = $1', [Number(b.id)]); await audit(u.id, 'kb.delete', null, { id: b.id }); return adminKbGet(ctx) }
  if (b.action === 'toggle') { const d = await one('SELECT active FROM kb_docs WHERE id = $1', [Number(b.id)]); if (d) await q('UPDATE kb_docs SET active = $1, updated_at = $2 WHERE id = $3', [!bool(d.active), nowIso(), Number(b.id)]); return adminKbGet(ctx) }
  const title = str(b.title, 120), content = String(b.content || '').slice(0, 400_000)
  if (!title) fail(400, 'Informe o título.', 'invalid')
  const chunks = toChunks(content)
  if (!chunks.length) fail(400, 'Escreva ou envie o conteúdo do material.', 'invalid')
  const kw = (Array.isArray(b.keywords) ? b.keywords : String(b.keywords || '').split(',')).map((k: any) => str(k, 40).toLowerCase()).filter(Boolean).slice(0, 30)
  if (b.id) await q('UPDATE kb_docs SET title = $1, description = $2, keywords = $3, sos = $4, chunks = $5, version = version + 1, updated_at = $6 WHERE id = $7', [title, str(b.description, 300), JSON.stringify(kw), b.sos !== false, JSON.stringify(chunks), nowIso(), Number(b.id)])
  else await q('INSERT INTO kb_docs (title, description, keywords, sos, active, version, chunks, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,1,$6,$7,$7)', [title, str(b.description, 300), JSON.stringify(kw), b.sos !== false, true, JSON.stringify(chunks), nowIso()])
  await audit(u.id, b.id ? 'kb.update' : 'kb.create', null, { title })
  return adminKbGet(ctx)
}
