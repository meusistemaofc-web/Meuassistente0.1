// Registros pessoais (tarefas, compromissos, lembretes, compras, notas, lançamentos e contas).
// Contrato reconstruído de: agenda, financeiro, meu-dia, items.js e da fila offline do frontend
// (POST /api/items {action, type, id, data}; GET /api/agenda; GET /api/finance; GET /api/day).
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate, isTime, num } from '../lib/http.js'
import { one, q, J, nowIso, db, type Db } from '../db/index.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import { localDate, localTime, zonedToUtc, addDays, addMonths, nextOccurrence, humanDate } from '../lib/time.js'

export const TYPES = ['task', 'appointment', 'reminder', 'shopping', 'note', 'expense', 'bill'] as const
export type ItemType = (typeof TYPES)[number]
export const EXPENSE_CATEGORIES = ['alimentacao', 'combustivel', 'casa', 'trabalho', 'compras', 'saude', 'transporte', 'lazer', 'outros']
export const INCOME_CATEGORIES = ['salario', 'servicos', 'vendas', 'outros']
const RECURRENCES = ['none', 'daily', 'weekly', 'monthly', 'yearly']

const pick = (d: any, ...keys: string[]) => { for (const k of keys) if (d?.[k] !== undefined && d?.[k] !== null && d?.[k] !== '') return d[k]; return undefined }

export interface ItemRow { id: number; user_id: number; type: ItemType; status: string | null; day: string | null; due_at: string | null; data: any; created_at: string; updated_at: string }
const hydrate = (r: any): ItemRow => ({ ...r, id: Number(r.id), user_id: Number(r.user_id), data: J(r.data, {}) })

/** Formato de saída esperado pelo frontend para cada tipo. */
export function serialize(r: ItemRow) {
  const d = r.data
  const base = { id: r.id, createdAt: r.created_at, updatedAt: r.updated_at }
  switch (r.type) {
    case 'task': return { ...base, title: d.title, status: r.status || 'pending', priority: d.priority || 'normal', dueDate: r.day, dueTime: d.dueTime || null, area: d.area || null, notes: d.notes || null, completedAt: d.completedAt || null }
    case 'appointment': return { ...base, title: d.title, date: r.day, time: d.time || null, endTime: d.endTime || null, location: d.location || '', person: d.person || '', notes: d.notes || '', reminderMinutes: d.reminderMinutes ?? 0 }
    case 'reminder': return { ...base, message: d.message, remindAt: d.remindAt, snoozedUntil: d.snoozedUntil || null, status: r.status || 'pending', leadMinutes: d.leadMinutes || 0, recurrence: d.recurrence || 'none', date: d.date, time: d.time }
    case 'shopping': return { ...base, name: d.name, quantity: d.quantity || null, listName: d.listName || 'Compras', done: r.status === 'done' }
    case 'note': return { ...base, title: d.title || null, content: d.content, pinned: !!d.pinned, area: d.area || null }
    case 'expense': return { ...base, kind: d.kind === 'income' ? 'income' : 'expense', amount: d.amount, description: d.description || '', category: d.category || 'outros', date: r.day }
    case 'bill': return { ...base, name: d.name, amount: d.amount, dueDate: r.day, status: r.status || 'pending', category: d.category || 'casa', recurrence: d.recurrence || 'none', paidAt: d.paidAt || null, installmentCurrent: d.installmentCurrent || null, installmentTotal: d.installmentTotal || null, planId: null }
  }
}

export async function getItem(userId: number, type: string, id: number, t: Db = db()): Promise<ItemRow> {
  const rows = await t.query('SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [id, userId, type])
  if (!rows.length) fail(404, 'Registro não encontrado.', 'not_found')
  return hydrate(rows[0])
}
async function insert(t: Db, userId: number, type: ItemType, f: { status?: string | null; day?: string | null; dueAt?: string | null; data: object }) {
  const now = nowIso()
  const rows = await t.query(
    `INSERT INTO items (user_id, type, status, day, due_at, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$7) RETURNING *`,
    [userId, type, f.status ?? null, f.day ?? null, f.dueAt ?? null, JSON.stringify(f.data), now])
  return hydrate(rows[0])
}
async function update(t: Db, it: ItemRow, f: { status?: string | null; day?: string | null; dueAt?: string | null; data?: object }) {
  const rows = await t.query(
    `UPDATE items SET status = $1, day = $2, due_at = $3, data = $4, updated_at = $5 WHERE id = $6 RETURNING *`,
    [f.status !== undefined ? f.status : it.status, f.day !== undefined ? f.day : it.day, f.dueAt !== undefined ? f.dueAt : it.due_at,
      JSON.stringify(f.data ?? it.data), nowIso(), it.id])
  return hydrate(rows[0])
}

function money(v: unknown, field = 'amount'): number {
  const n = num(v)
  if (n === null || n <= 0 || n > 1e10) fail(400, 'Informe um valor válido.', 'invalid', field)
  return Math.round(n! * 100) / 100
}

/** Cria um registro. Usado pela API e pelas ferramentas do chat. */
export async function createItem(u: SessionUser, type: string, d: any, t: Db = db()): Promise<ItemRow[]> {
  const s = settingsOf(u)
  const tz = s.timezone
  const today = localDate(tz)
  switch (type) {
    case 'task': {
      const title = str(pick(d, 'title', 'name'), 300)
      if (!title) fail(400, 'Informe a tarefa.', 'invalid', 'title')
      const due = pick(d, 'due_date', 'dueDate', 'date')
      if (due !== undefined && !isDate(due)) fail(400, 'Data inválida.', 'invalid', 'due_date')
      const dueTime = pick(d, 'due_time', 'dueTime', 'time')
      return [await insert(t, u.id, 'task', { status: 'pending', day: due || null, data: { title, priority: pick(d, 'priority') === 'high' ? 'high' : 'normal', dueTime: isTime(dueTime) ? dueTime : null, area: pick(d, 'area') || null, notes: str(pick(d, 'notes'), 2000) || null } })]
    }
    case 'appointment': {
      const title = str(pick(d, 'title'), 300)
      const date = pick(d, 'date')
      const time = pick(d, 'time')
      if (!title) fail(400, 'Informe o título.', 'invalid', 'title')
      if (!isDate(date)) fail(400, 'Informe a data do compromisso.', 'invalid', 'date')
      if (time !== undefined && !isTime(time)) fail(400, 'Horário inválido.', 'invalid', 'time')
      const rm = num(pick(d, 'reminder_minutes', 'reminderMinutes'))
      const reminderMinutes = rm === null ? (time ? Number(s.reminderLeadMinutes) || 0 : 0) : Math.max(0, Math.min(10080, Math.round(rm)))
      const start = time ? zonedToUtc(date, time, tz) : null
      const dueAt = start && reminderMinutes > 0 ? new Date(new Date(start).getTime() - reminderMinutes * 60_000).toISOString() : null
      return [await insert(t, u.id, 'appointment', { status: 'scheduled', day: date, dueAt, data: { title, time: time || null, location: str(pick(d, 'location'), 200), person: str(pick(d, 'person'), 120), notes: str(pick(d, 'notes'), 2000), reminderMinutes } })]
    }
    case 'reminder': {
      const message = str(pick(d, 'message', 'title'), 500)
      if (!message) fail(400, 'Informe do que lembrar.', 'invalid', 'message')
      let date = pick(d, 'date')
      const time = pick(d, 'time') || s.defaultReminderTime || '09:00'
      if (date !== undefined && !isDate(date)) fail(400, 'Data inválida.', 'invalid', 'date')
      if (!isTime(time)) fail(400, 'Horário inválido.', 'invalid', 'time')
      if (!date) date = time <= localTime(tz) ? addDays(today, 1) : today
      const recurrence = RECURRENCES.includes(pick(d, 'recurrence')) ? pick(d, 'recurrence') : 'none'
      const lb = num(pick(d, 'remind_before_minutes', 'leadMinutes'))
      const leadMinutes = lb === null ? Number(s.reminderBeforeMinutes) || 0 : Math.max(0, Math.min(10080, Math.round(lb)))
      const remindAt = zonedToUtc(date, time, tz)
      const dueAt = new Date(new Date(remindAt).getTime() - leadMinutes * 60_000).toISOString()
      return [await insert(t, u.id, 'reminder', { status: 'pending', day: date, dueAt, data: { message, date, time, recurrence, leadMinutes, remindAt } })]
    }
    case 'shopping': {
      const list: any[] = Array.isArray(d?.items) ? d.items : [{ name: pick(d, 'name'), quantity: pick(d, 'quantity') }]
      const listName = str(pick(d, 'list_name', 'listName'), 80) || 'Compras'
      const clean = list.map((i) => ({ name: str(i?.name, 120), quantity: str(i?.quantity, 40) || null })).filter((i) => i.name).slice(0, 100)
      if (!clean.length) fail(400, 'Informe ao menos um item.', 'invalid', 'items')
      const out: ItemRow[] = []
      for (const i of clean) out.push(await insert(t, u.id, 'shopping', { status: 'open', data: { ...i, listName } }))
      return out
    }
    case 'note': {
      const content = str(pick(d, 'content', 'text'), 10000)
      if (!content) fail(400, 'Escreva a anotação.', 'invalid', 'content')
      return [await insert(t, u.id, 'note', { data: { title: str(pick(d, 'title'), 200) || null, content, pinned: false, area: pick(d, 'area') || null } })]
    }
    case 'expense': {
      const kind = pick(d, 'kind') === 'income' ? 'income' : 'expense'
      const amount = money(pick(d, 'amount'))
      const date = pick(d, 'date') || today
      if (!isDate(date)) fail(400, 'Data inválida.', 'invalid', 'date')
      const cats = kind === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES
      const category = cats.includes(pick(d, 'category')) ? pick(d, 'category') : 'outros'
      return [await insert(t, u.id, 'expense', { status: 'done', day: date, data: { kind, amount, description: str(pick(d, 'description'), 300), category } })]
    }
    case 'bill': {
      const name = str(pick(d, 'name', 'description'), 200)
      if (!name) fail(400, 'Informe o nome da conta.', 'invalid', 'name')
      const amount = money(pick(d, 'amount'))
      const due = pick(d, 'due_date', 'dueDate', 'date')
      if (!isDate(due)) fail(400, 'Informe o vencimento.', 'invalid', 'due_date')
      const rec = pick(d, 'recurrence')
      const recurrence = ['none', 'weekly', 'monthly', 'yearly', 'installments'].includes(rec) ? rec : 'none'
      const total = recurrence === 'installments' ? Math.max(2, Math.min(120, Math.round(num(pick(d, 'installments', 'installment_total')) || 2))) : null
      const category = EXPENSE_CATEGORIES.includes(pick(d, 'category')) ? pick(d, 'category') : 'casa'
      return [await insert(t, u.id, 'bill', { status: 'pending', day: due, data: { name, amount, category, recurrence, installmentCurrent: total ? 1 : null, installmentTotal: total } })]
    }
  }
  fail(400, 'Tipo de registro inválido.', 'invalid_type')
  return []
}

/** Executa uma ação sobre um registro existente. */
export async function itemAction(u: SessionUser, action: string, type: string, id: number, d: any = {}, t: Db = db()) {
  if (action === 'create') return { created: await createItem(u, type, d, t) }
  if (!TYPES.includes(type as ItemType)) fail(400, 'Tipo de registro inválido.', 'invalid_type')
  if (!Number.isInteger(id) || id <= 0) fail(400, 'Registro inválido.', 'invalid')
  const it = await getItem(u.id, type, id, t)
  const tz = settingsOf(u).timezone
  switch (action) {
    case 'delete':
      await t.query('DELETE FROM items WHERE id = $1 AND user_id = $2', [id, u.id])
      return { deleted: it }
    case 'task_status': {
      const st = ['pending', 'in_progress', 'done'].includes(d.status) ? d.status : fail(400, 'Situação inválida.', 'invalid', 'status')
      return { updated: await update(t, it, { status: st, data: { ...it.data, completedAt: st === 'done' ? nowIso() : null } }) }
    }
    case 'shopping_toggle':
      return { updated: await update(t, it, { status: it.status === 'done' ? 'open' : 'done' }) }
    case 'note_pin':
      return { updated: await update(t, it, { data: { ...it.data, pinned: !it.data.pinned } }) }
    case 'reminder_done':
    case 'reminder_cancel':
      return { updated: await update(t, it, { status: 'done', dueAt: null }) }
    case 'reminder_snooze': {
      const minutes = Math.max(1, Math.min(10080, Math.round(num(d.minutes) || 15)))
      const until = new Date(Date.now() + minutes * 60_000).toISOString()
      return { updated: await update(t, it, { status: 'pending', dueAt: until, data: { ...it.data, snoozedUntil: until } }) }
    }
    case 'reminder_retry':
      return { updated: await update(t, it, { status: 'pending', dueAt: new Date(Date.now() + 60_000).toISOString() }) }
    case 'appointment_update': {
      const data = { ...it.data }
      let day = it.day
      if (d.date !== undefined) { if (!isDate(d.date)) fail(400, 'Data inválida.', 'invalid', 'date'); day = d.date }
      if (d.time !== undefined) { if (d.time && !isTime(d.time)) fail(400, 'Horário inválido.', 'invalid', 'time'); data.time = d.time || null }
      for (const k of ['title', 'location', 'notes'] as const) if (d[k] !== undefined) data[k] = str(d[k], k === 'notes' ? 2000 : 300)
      if (!data.title) fail(400, 'Informe o título.', 'invalid', 'title')
      const start = data.time ? zonedToUtc(day!, data.time, tz) : null
      const dueAt = start && data.reminderMinutes > 0 ? new Date(new Date(start).getTime() - data.reminderMinutes * 60_000).toISOString() : null
      return { updated: await update(t, it, { day, dueAt, data }) }
    }
    case 'pay_bill': {
      if (it.status === 'paid') return { updated: it }
      const updated = await update(t, it, { status: 'paid', data: { ...it.data, paidAt: nowIso() } })
      // contas recorrentes geram a próxima ocorrência ao serem pagas
      const rec = it.data.recurrence
      let next: ItemRow | null = null
      if (rec === 'installments' && it.data.installmentCurrent < it.data.installmentTotal) {
        next = await insert(t, u.id, 'bill', { status: 'pending', day: addMonths(it.day!, 1), data: { ...it.data, paidAt: null, installmentCurrent: it.data.installmentCurrent + 1, prevId: it.id } })
      } else if (['weekly', 'monthly', 'yearly'].includes(rec) && !it.data.nextId) {
        next = await insert(t, u.id, 'bill', { status: 'pending', day: nextOccurrence(it.day!, rec), data: { ...it.data, paidAt: null, prevId: it.id } })
      }
      if (next) await update(t, updated, { data: { ...updated.data, nextId: next.id } })
      return { updated, next }
    }
    case 'unpay_bill': {
      if (it.data.nextId) {
        const nx = await t.query("SELECT id FROM items WHERE id = $1 AND user_id = $2 AND status = 'pending'", [it.data.nextId, u.id])
        if (nx.length) await t.query('DELETE FROM items WHERE id = $1', [it.data.nextId])
      }
      return { updated: await update(t, it, { status: 'pending', data: { ...it.data, paidAt: null, nextId: null } }) }
    }
    case 'update': {
      const data = { ...it.data, ...(typeof d === 'object' ? d : {}) }
      return { updated: await update(t, it, { data }) }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}

export async function itemsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const { action, type, id, data } = ctx.body || {}
  const r: any = await db().tx((t) => itemAction(u, String(action || ''), String(type || ''), Number(id), data || {}, t))
  return {
    ok: true,
    ...(r.created ? { items: r.created.map(serialize), item: serialize(r.created[0]) } : {}),
    ...(r.updated ? { item: serialize(r.updated) } : {}),
    ...(r.deleted ? { deleted: { type: r.deleted.type, id: r.deleted.id } } : {}),
  }
}

export async function listItems(userId: number, type: ItemType, extra = '', params: unknown[] = []) {
  const rows = await q(`SELECT * FROM items WHERE user_id = $1 AND type = $2 ${extra}`, [userId, type, ...params])
  return rows.map(hydrate)
}

export async function agendaGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const [tasks, appts, rems, shop, notes, bills] = await Promise.all([
    listItems(u.id, 'task', 'ORDER BY id DESC LIMIT 500'),
    listItems(u.id, 'appointment', 'AND day >= $3 AND day <= $4 ORDER BY day, id', [addDays(today, -1), addDays(today, 30)]),
    listItems(u.id, 'reminder', "AND status <> 'done' ORDER BY due_at"),
    listItems(u.id, 'shopping', 'ORDER BY id DESC LIMIT 300'),
    listItems(u.id, 'note', 'ORDER BY id DESC LIMIT 300'),
    listItems(u.id, 'bill', "AND status = 'pending' ORDER BY day"),
  ])
  const ns = notes.map(serialize) as any[]
  ns.sort((a, b) => Number(b.pinned) - Number(a.pinned))
  return {
    today, tz,
    tasks: tasks.map(serialize), appointments: appts.map(serialize), reminders: rems.map(serialize),
    shopping: shop.map(serialize), notes: ns, bills: bills.map(serialize), sharedWithMe: [],
  }
}

function monthEnd(m: string) { return addDays(addMonths(m + '-01', 1), -1) }

export async function financeGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const qm = ctx.query.get('month')
  const month = qm && /^\d{4}-\d{2}$/.test(qm) && qm <= today.slice(0, 7) ? qm : today.slice(0, 7)
  const start = month + '-01', end = monthEnd(month)
  const entries = (await listItems(u.id, 'expense', 'AND day >= $3 AND day <= $4 ORDER BY day DESC, id DESC', [start, end])).map(serialize) as any[]
  const income = entries.filter((e) => e.kind === 'income').reduce((s, e) => s + e.amount, 0)
  const spentList = entries.filter((e) => e.kind === 'expense')
  const spent = spentList.reduce((s, e) => s + e.amount, 0)
  const bills = (await listItems(u.id, 'bill', 'ORDER BY day')).map(serialize) as any[]
  const pendingBills = bills.filter((b) => b.status === 'pending' && b.dueDate <= end)
  const paid = bills.filter((b) => b.status === 'paid' && ((b.paidAt && b.paidAt.slice(0, 7) === month) || b.dueDate.slice(0, 7) === month))
  const pendingAmount = pendingBills.reduce((s, b) => s + b.amount, 0)
  const paidAmount = paid.reduce((s, b) => s + b.amount, 0)
  const cats = new Map<string, number>()
  for (const e of spentList) cats.set(e.category, (cats.get(e.category) || 0) + e.amount)
  const byCategory = [...cats.entries()].map(([slug, total]) => ({ slug, total: Math.round(total * 100) / 100 })).sort((a, b) => b.total - a.total)
  const top = spentList.slice().sort((a, b) => b.amount - a.amount)[0] || null
  // série dos últimos 6 meses
  const first = addMonths(start, -5)
  const hist = (await listItems(u.id, 'expense', 'AND day >= $3 AND day <= $4', [first, end])).map(serialize) as any[]
  const series = Array.from({ length: 6 }, (_, i) => {
    const m = addMonths(first, i).slice(0, 7)
    const inM = hist.filter((e) => e.date.slice(0, 7) === m)
    return { month: m, spent: r2(inM.filter((e) => e.kind === 'expense').reduce((s, e) => s + e.amount, 0)), income: r2(inM.filter((e) => e.kind === 'income').reduce((s, e) => s + e.amount, 0)) }
  })
  return {
    month, today, entries, income: r2(income), spent: r2(spent), balance: r2(income - spent - pendingAmount),
    bills: { pendingAmount: r2(pendingAmount), paidAmount: r2(paidAmount), paid }, pendingBills, plans: {},
    series, byCategory, top,
  }
}
const r2 = (n: number) => Math.round(n * 100) / 100

/** /api/day — linha do tempo (compromissos, tarefas, contas, lembretes) num intervalo de datas. */
export async function dayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const tz = settingsOf(u).timezone
  const today = localDate(tz)
  const overview = !ctx.query.get('from') && !ctx.query.get('to')
  let from = ctx.query.get('from') || today, to = ctx.query.get('to') || from
  if (!isDate(from) || !isDate(to) || to < from) fail(400, 'Período inválido.', 'invalid')
  if ((Date.parse(to) - Date.parse(from)) / 86400000 > 62) to = addDays(from, 62)
  const nowT = localTime(tz)
  const entries: any[] = []
  for (const a of await listItems(u.id, 'appointment', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(a)
    entries.push({ key: `appointment:${a.id}`, kind: 'appointment', id: a.id, day: s.date, time: s.time, title: s.title, detail: s.location || s.person || '', status: s.date < today || (s.date === today && s.time && s.time < nowT) ? 'done' : 'upcoming' })
  }
  for (const t of await listItems(u.id, 'task', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(t)
    entries.push({ key: `task:${t.id}`, kind: 'task', id: t.id, day: s.dueDate, time: s.dueTime, title: s.title, detail: '', status: s.status === 'done' ? 'done' : s.dueDate < today ? 'overdue' : 'pending' })
  }
  for (const b of await listItems(u.id, 'bill', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(b)
    entries.push({ key: `bill:${b.id}`, kind: 'bill', id: b.id, day: s.dueDate, time: null, title: s.name, amount: s.amount, status: s.status === 'paid' ? 'done' : s.dueDate < today ? 'overdue' : 'pending' })
  }
  for (const r of await listItems(u.id, 'reminder', 'AND day >= $3 AND day <= $4', [from, to])) {
    const s: any = serialize(r)
    entries.push({ key: `reminder:${r.id}`, kind: 'reminder', id: r.id, day: s.date, time: s.time, title: s.message, detail: '', status: s.status === 'done' ? 'done' : s.status === 'sent' ? 'pending' : s.snoozedUntil ? 'snoozed' : 'upcoming' })
  }
  entries.sort((a, b) => (a.day + (a.time || '99:99')).localeCompare(b.day + (b.time || '99:99')))
  const base = { from, to, today, tz, entries, unavailable: [] as string[] }
  if (!overview) return base
  // Visão "Meu Dia" (GET /api/day sem período): saudação, números do dia e prioridades
  const expenses = (await listItems(u.id, 'expense', 'AND day = $3 ORDER BY id DESC', [today])).map(serialize) as any[]
  const appointments = entries.filter((e) => e.kind === 'appointment')
  const openTasks = (await listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') AND (day IS NULL OR day <= $3) ORDER BY day, id", [today])).map(serialize) as any[]
  const pendingBills = (await listItems(u.id, 'bill', "AND status = 'pending' AND day <= $3 ORDER BY day", [today])).map(serialize) as any[]
  const priorities = [
    ...pendingBills.map((b) => ({ kind: 'bill', id: b.id, title: b.name, detail: b.dueDate < today ? 'Atrasada' : 'Vence hoje' })),
    ...openTasks.sort((a, b) => Number(b.priority === 'high') - Number(a.priority === 'high')).map((t) => ({ kind: 'task', id: t.id, title: t.title, detail: t.dueDate && t.dueDate < today ? 'Atrasada' : t.priority === 'high' ? 'Prioridade alta' : t.dueDate ? 'Para hoje' : 'Sem prazo' })),
    ...appointments.filter((a) => a.status === 'upcoming').map((a) => ({ kind: 'appointment', id: a.id, title: a.title, detail: a.time ? `Às ${a.time}` : 'Hoje' })),
  ].slice(0, 5)
  return {
    ...base, name: u.name, hour: Number(localTime(tz).slice(0, 2)),
    spentToday: r2(expenses.filter((e) => e.kind === 'expense').reduce((x, e) => x + e.amount, 0)),
    appointments, tasks: openTasks, expenses: expenses.filter((e) => e.kind === 'expense'), priorities,
  }
}

/** /api/summary — resumo do dia com números reais do banco. */
export async function summaryGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const s = settingsOf(u)
  const today = localDate(s.timezone)
  const spentRows = await listItems(u.id, 'expense', 'AND day = $3', [today])
  const spent = r2(spentRows.filter((e) => e.data.kind !== 'income').reduce((a, e) => a + Number(e.data.amount || 0), 0))
  const tasks = await listItems(u.id, 'task', '')
  const tasksDone = tasks.filter((t) => t.status === 'done' && String(t.data.completedAt || '').startsWith(today)).length
  const tasksPending = tasks.filter((t) => t.status !== 'done').length
  const appointments = (await listItems(u.id, 'appointment', 'AND day = $3', [today])).length
  const billsDue = (await listItems(u.id, 'bill', "AND status = 'pending' AND day <= $3", [today])).length
  const fmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: s.currency || 'BRL' })
  const text = `Resumo de ${humanDate(today, today).toLowerCase()}: você gastou ${fmt.format(spent)}, concluiu ${tasksDone} ${tasksDone === 1 ? 'tarefa' : 'tarefas'} e tem ${tasksPending} ${tasksPending === 1 ? 'pendência' : 'pendências'}. ` +
    `${appointments ? `Hoje há ${appointments} ${appointments === 1 ? 'compromisso' : 'compromissos'}. ` : ''}${billsDue ? `${billsDue} ${billsDue === 1 ? 'conta vence' : 'contas vencem'} até hoje.` : 'Nenhuma conta vencendo.'}`
  return { summary: { date: today, text, data: { spent, tasksDone, tasksPending, appointments, billsDue } } }
}

export { one }
