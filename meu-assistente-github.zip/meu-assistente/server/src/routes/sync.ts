// /api/sync — aplica a fila de alterações feitas sem conexão (modo offline do app).
import type { Ctx } from '../lib/http.js'
import { HttpError, fail } from '../lib/http.js'
import { q, one, J, nowIso, db } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { createItem, itemAction, getItem, TYPES } from './items.js'

export async function syncPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const ops = Array.isArray(ctx.body?.ops) ? ctx.body.ops.slice(0, 50) : fail(400, 'Lista de operações inválida.', 'invalid')
  const results: any[] = []
  for (const op of ops) {
    const id = String(op?.id || '').slice(0, 80)
    if (!id) continue
    const prev = await one('SELECT result FROM sync_ops WHERE op_id = $1 AND user_id = $2', [id, u.id])
    if (prev) { results.push({ id, ...J(prev.result, {}) }); continue }
    let r: any
    try {
      r = await db().tx(async (t) => {
        const type = String(op.type || '')
        const target = Number(op.targetId)
        switch (op.kind) {
          case 'create': { const rows = await createItem(u, type, op.data || {}, t); return { status: 'done', createdId: rows[0].id } }
          case 'task_status': await itemAction(u, 'task_status', 'task', target, op.data, t); return { status: 'done' }
          case 'reminder_done': await itemAction(u, 'reminder_done', 'reminder', target, {}, t); return { status: 'done' }
          case 'appointment_update': await itemAction(u, 'appointment_update', 'appointment', target, op.data, t); return { status: 'done' }
          case 'shopping_done': {
            const it = await getItem(u.id, 'shopping', target, t)
            const want = op.data?.done ? 'done' : 'open'
            if (it.status !== want) await itemAction(u, 'shopping_toggle', 'shopping', target, {}, t)
            return { status: 'done' }
          }
          case 'delete': {
            if (!TYPES.includes(type as any)) return { status: 'failed', error: 'Tipo inválido.' }
            await t.query('DELETE FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [target, u.id, type])
            return { status: 'done' }
          }
          default: return { status: 'failed', error: 'Este tipo de alteração ainda não é suportado pelo servidor reconstruído.' }
        }
      })
    } catch (e: any) {
      r = e instanceof HttpError ? { status: e.status === 404 ? 'failed' : 'failed', error: e.message } : { status: 'retry', error: 'Erro temporário.' }
    }
    if (r.status !== 'retry') await q('INSERT INTO sync_ops (op_id, user_id, result, created_at) VALUES ($1,$2,$3,$4)', [id, u.id, JSON.stringify(r), nowIso()])
    results.push({ id, ...r })
  }
  return { results }
}
