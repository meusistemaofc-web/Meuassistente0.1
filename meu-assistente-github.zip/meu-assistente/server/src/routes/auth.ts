import { pub } from '../lib/publicurl.js'
// /api/auth — reconstruído a partir das telas Entrar, Criar conta, Recuperar senha,
// Configuração inicial e Perfil → Segurança da conta (contrato: {action, ...campos}).
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate } from '../lib/http.js'
import { one, q, nowIso, J } from '../db/index.js'
import {
  hashPassword, verifyPassword, passwordProblem, whatsappProblem, normWhatsapp, sha256, token,
  newTotpSecret, verifyTotp, newBackupCodes, rateLimit,
} from '../lib/security.js'
import { createSession, clearSessionCookie, requireUser, hydrateUser, type SessionUser } from '../lib/session.js'
import { audit } from '../lib/account.js'
import { enqueueMail, emailConfirmLink } from '../lib/mail.js'
import { config } from '../config.js'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const normEmail = (e: unknown) => str(e, 254).toLowerCase()

async function counts() {
  const r = await one<{ total: number; supers: number }>(
    `SELECT COUNT(*) AS total, SUM(CASE WHEN role = 'superadmin' THEN 1 ELSE 0 END) AS supers FROM users`)
  return { total: Number(r?.total || 0), supers: Number(r?.supers || 0) }
}
async function getConfig<T>(key: string, fallback: T): Promise<T> {
  const r = await one('SELECT value FROM app_config WHERE key = $1', [key])
  return r ? J<T>(r.value, fallback) : fallback
}
async function setConfig(key: string, value: unknown) {
  const v = JSON.stringify(value)
  const ex = await one('SELECT key FROM app_config WHERE key = $1', [key])
  if (ex) await q('UPDATE app_config SET value = $1, updated_at = $2 WHERE key = $3', [v, nowIso(), key])
  else await q('INSERT INTO app_config (key, value, updated_at) VALUES ($1,$2,$3)', [key, v, nowIso()])
}

/** Código de configuração do Administrador Principal (substitui o item "setup-code" do Netlify Blobs). */
export async function ensureSetupCode(): Promise<string | null> {
  const { total, supers } = await counts()
  if (supers > 0 || total === 0) return null
  if (config.setupCode) return config.setupCode
  let code = await getConfig<string | null>('setup-code', null)
  if (!code) {
    code = token(9).toUpperCase().replace(/[^A-Z0-9]/g, 'X').slice(0, 12)
    await setConfig('setup-code', code)
  }
  return code
}

function validateAccount(b: any, requireAll = true) {
  const name = str(b.name, 120)
  if (name.length < 3 || !name.includes(' ')) fail(400, 'Informe seu nome completo (nome e sobrenome).', 'invalid', 'name')
  const wp = whatsappProblem(b.whatsapp)
  if (wp) fail(400, wp, 'invalid', 'whatsapp')
  const email = normEmail(b.email)
  if (!EMAIL_RE.test(email)) fail(400, 'Informe um e-mail válido.', 'invalid', 'email')
  const birthday = str(b.birthday, 10)
  if (requireAll && (!isDate(birthday) || birthday > new Date().toISOString().slice(0, 10) || birthday < '1900-01-01'))
    fail(400, 'Informe uma data de aniversário válida.', 'invalid', 'birthday')
  const pp = passwordProblem(b.password)
  if (pp) fail(400, pp, 'invalid', 'password')
  if (b.passwordConfirm !== undefined && b.password !== b.passwordConfirm) fail(400, 'As senhas não conferem.', 'invalid', 'passwordConfirm')
  return { name, whatsapp: normWhatsapp(String(b.whatsapp)), email, birthday: birthday || null, password: String(b.password) }
}

export async function createUser(a: { name: string; whatsapp: string; email: string; birthday: string | null; password: string },
  role: 'user' | 'admin' | 'superadmin', extra: { permissions?: string[]; origin?: string; source?: string } = {}) {
  const exists = await one('SELECT id FROM users WHERE email = $1', [a.email])
  if (exists) fail(409, 'Já existe uma conta com este e-mail.', 'email_taken', 'email')
  const now = nowIso()
  const rows = await q(
    `INSERT INTO users (email, name, whatsapp, birthday, password_hash, role, permissions, status, settings, origin, source, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,'active','{}',$8,$9,$10,$10) RETURNING id`,
    [a.email, a.name, a.whatsapp, a.birthday, await hashPassword(a.password), role, JSON.stringify(extra.permissions || []),
      extra.origin || null, extra.source || null, now])
  return Number(rows[0].id)
}

async function loadUser(id: number): Promise<SessionUser | null> {
  const r = await one('SELECT * FROM users WHERE id = $1', [id])
  return r ? hydrateUser(r) : null
}

/** Confere senha (+ código 2FA quando ativo). Usado por ações sensíveis. */
async function checkSecret(u: SessionUser, b: any, needCode = true) {
  if (!(await verifyPassword(String(b.password || ''), u.password_hash))) fail(400, 'Senha incorreta.', 'invalid_password', 'password')
  if (needCode && u.mfa_enabled) {
    const code = String(b.code || '').trim().toUpperCase()
    if (!code) fail(400, 'Informe o código do aplicativo autenticador.', 'mfa_required', 'code')
    if (!(await consumeMfaCode(u, code))) fail(400, 'Código inválido.', 'invalid_code', 'code')
  }
}
async function consumeMfaCode(u: SessionUser, code: string): Promise<boolean> {
  if (u.mfa_secret && verifyTotp(u.mfa_secret, code)) return true
  const h = sha256(code.replace(/\s/g, ''))
  if (u.backup_codes.includes(h)) {
    const rest = u.backup_codes.filter((c) => c !== h)
    await q('UPDATE users SET backup_codes = $1 WHERE id = $2', [JSON.stringify(rest), u.id])
    u.backup_codes = rest
    return true
  }
  return false
}

export async function authGet(_ctx: Ctx) {
  const { total, supers } = await counts()
  return { firstAccount: total === 0, setupNeeded: total > 0 && supers === 0 }
}

export async function authPost(ctx: Ctx) {
  const b = ctx.body || {}
  const action = String(b.action || '')
  switch (action) {
    case 'session': {
      if (!ctx.user || !ctx.session || ctx.session.mfa_pending || ctx.session.recovery) fail(401, 'Entre para continuar.', 'auth_required')
      if (ctx.user!.status !== 'active') fail(401, 'Esta conta está desativada.', 'account_disabled')
      return { ok: true }
    }

    case 'login': {
      const email = normEmail(b.email)
      if (!rateLimit(`login:${ctx.ip}`, 20, 15 * 60_000) || !rateLimit(`login:${email}`, 8, 15 * 60_000))
        fail(429, 'Muitas tentativas. Aguarde alguns minutos e tente de novo.', 'rate_limited')
      const row = await one('SELECT * FROM users WHERE email = $1', [email])
      const ok = row ? await verifyPassword(String(b.password || ''), row.password_hash) : await hashPassword('x').then(() => false)
      if (!row || !ok) fail(401, 'E-mail ou senha incorretos.', 'invalid_credentials')
      const u = hydrateUser(row)
      if (u.status !== 'active') fail(403, 'Esta conta está desativada. Fale com o administrador.', 'account_disabled')
      if (u.mfa_enabled) {
        await createSession(ctx, u.id, { mfaPending: true })
        return { mfaRequired: true }
      }
      await createSession(ctx, u.id)
      return { ok: true, redirect: '/' }
    }

    case 'mfa_login': {
      if (!ctx.user || !ctx.session || !(ctx.session.mfa_pending || ctx.session.recovery)) fail(401, 'Sessão expirada. Entre novamente.', 'auth_required')
      if (!rateLimit(`mfa:${ctx.session!.id}`, 6, 15 * 60_000)) fail(429, 'Muitas tentativas. Entre novamente.', 'rate_limited')
      const code = String(b.code || '').trim().toUpperCase()
      if (!(await consumeMfaCode(ctx.user!, code))) fail(400, 'Código inválido.', 'invalid_code', 'code')
      if (ctx.session!.recovery) { await q('UPDATE sessions SET mfa_pending = $1 WHERE id = $2', [false, ctx.session!.id]); return { ok: true } }
      await q('DELETE FROM sessions WHERE id = $1', [ctx.session!.id])
      await createSession(ctx, ctx.user!.id)
      return { ok: true, redirect: '/' }
    }

    case 'signup': {
      if (!rateLimit(`signup:${ctx.ip}`, 10, 60 * 60_000)) fail(429, 'Muitos cadastros a partir desta rede. Tente mais tarde.', 'rate_limited')
      const a = validateAccount(b)
      const { total } = await counts()
      const role = total === 0 ? 'superadmin' : 'user'
      const origin = ['eleicoes', 'campanha', 'convite'].includes(b.origin) ? b.origin : undefined
      const id = await createUser(a, role, { origin, source: str(b.source, 80) || undefined })
      if (role === 'superadmin') await audit(id, 'setup.first_account', id)
      await createSession(ctx, id)
      // boas-vindas e confirmação de e-mail (na fila; respeitam o que está ligado no painel)
      void enqueueMail({ kind: 'cadastro', to: a.email, userId: id, vars: { nome: String(a.name).split(' ')[0] }, dedupe: 'cadastro:' + id }).catch(() => {})
      void enqueueMail({ kind: 'confirmacao', to: a.email, userId: id, vars: { nome: String(a.name).split(' ')[0], link: emailConfirmLink(id) }, dedupe: 'confirmacao:' + id }).catch(() => {})
      return { ok: true, redirect: role === 'superadmin' ? '/admin' : '/' }
    }

    case 'logout': {
      if (ctx.session) await q('DELETE FROM sessions WHERE id = $1', [ctx.session.id])
      clearSessionCookie(ctx)
      return { ok: true }
    }

    case 'recover': {
      const email = normEmail(b.email)
      if (!EMAIL_RE.test(email)) fail(400, 'Informe um e-mail válido.', 'invalid', 'email')
      const message = 'Se existir uma conta com este e-mail, enviamos um link para criar uma nova senha. Ele vale por 1 hora.'
      if (!rateLimit(`recover:${ctx.ip}`, 10, 60 * 60_000) || !rateLimit(`recover:${email}`, 3, 60 * 60_000)) return { ok: true, message }
      const u = await one('SELECT id, name FROM users WHERE email = $1 AND status = $2', [email, 'active'])
      if (u) {
        const t = token(32)
        await q('INSERT INTO password_resets (token_hash, user_id, expires_at, created_at) VALUES ($1,$2,$3,$4)',
          [sha256(t), u.id, new Date(Date.now() + 3600_000).toISOString(), nowIso()])
        const link = `${pub()}/recuperar#recovery_token=${t}`
        await enqueueMail({ kind: 'recuperacao', to: email, userId: Number(u.id), vars: { nome: String(u.name).split(' ')[0], link }, dedupe: 'recuperacao:' + sha256(t).slice(0, 32) })
      }
      return { ok: true, message }
    }

    case 'recovery': {
      const t = String(b.token || '')
      const r = await one('SELECT * FROM password_resets WHERE token_hash = $1', [sha256(t)])
      if (!r || r.used_at || new Date(r.expires_at).getTime() < Date.now()) fail(400, 'Este link é inválido ou expirou.', 'invalid_token')
      await q('UPDATE password_resets SET used_at = $1 WHERE token_hash = $2', [nowIso(), r!.token_hash])
      const u = await loadUser(Number(r!.user_id))
      if (!u || u.status !== 'active') fail(400, 'Este link é inválido ou expirou.', 'invalid_token')
      const sid = await createSession(ctx, u!.id, { recovery: true })
      if (u!.mfa_enabled) await q('UPDATE sessions SET mfa_pending = $1 WHERE id = $2', [true, sid])
      return { ok: true, mfaRequired: u!.mfa_enabled }
    }

    case 'password': {
      if (!ctx.user || !ctx.session || ctx.session.mfa_pending) fail(401, 'Entre para continuar.', 'auth_required')
      const u = ctx.user!
      if (!ctx.session!.recovery) {
        if (!(await verifyPassword(String(b.currentPassword || ''), u.password_hash))) fail(400, 'Senha atual incorreta.', 'invalid_password', 'currentPassword')
      }
      const pp = passwordProblem(b.password)
      if (pp) fail(400, pp, 'invalid', 'password')
      if (b.password !== b.passwordConfirm) fail(400, 'As senhas não conferem.', 'invalid', 'passwordConfirm')
      await q('UPDATE users SET password_hash = $1, updated_at = $2 WHERE id = $3', [await hashPassword(b.password), nowIso(), u.id])
      await q('DELETE FROM sessions WHERE user_id = $1', [u.id])
      await createSession(ctx, u.id)
      await audit(u.id, 'auth.password_changed', u.id)
      void enqueueMail({ kind: 'seguranca', to: u.email, userId: Number(u.id), vars: { nome: String(u.name || '').split(' ')[0], mensagem: `A senha da sua conta foi alterada em ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}.` }, dedupe: 'senha:' + u.id + ':' + Date.now() }).catch(() => {})
      return { ok: true, signedIn: true }
    }

    case 'reauth': {
      const u = requireUser(ctx)
      if (!rateLimit(`reauth:${u.id}`, 10, 15 * 60_000)) fail(429, 'Muitas tentativas. Aguarde.', 'rate_limited')
      await checkSecret(u, b)
      await q('UPDATE sessions SET reauth_at = $1 WHERE id = $2', [nowIso(), ctx.session!.id])
      return { ok: true }
    }

    case 'security_status': {
      const u = requireUser(ctx)
      const policy = await getConfig('security-policy', { adminMfaRequired: false })
      return {
        mfa: { enabled: u.mfa_enabled, backupCodesLeft: u.backup_codes.length },
        adminMfaRequired: !!policy.adminMfaRequired,
        adminLocked: u.role !== 'user' && !!policy.adminMfaRequired && !u.mfa_enabled,
        superadmin: u.role === 'superadmin',
      }
    }

    case 'mfa_begin': {
      const u = requireUser(ctx)
      await checkSecret(u, b, false)
      const secret = newTotpSecret()
      await q('UPDATE users SET mfa_pending_secret = $1 WHERE id = $2', [secret, u.id])
      const label = encodeURIComponent(`Meu Assistente:${u.email}`)
      return { secret, uri: `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent('Meu Assistente')}&algorithm=SHA1&digits=6&period=30` }
    }
    case 'mfa_enable': {
      const u = requireUser(ctx)
      if (!u.mfa_pending_secret) fail(400, 'Comece a ativação novamente.', 'invalid')
      if (!verifyTotp(u.mfa_pending_secret!, String(b.code || ''))) fail(400, 'Código inválido. Confira o horário do celular e tente de novo.', 'invalid_code', 'code')
      const codes = newBackupCodes()
      await q('UPDATE users SET mfa_enabled = $1, mfa_secret = $2, mfa_pending_secret = NULL, backup_codes = $3 WHERE id = $4',
        [true, u.mfa_pending_secret, JSON.stringify(codes.map((c) => sha256(c))), u.id])
      await audit(u.id, 'auth.mfa_enabled', u.id)
      return { ok: true, backupCodes: codes }
    }
    case 'mfa_disable': {
      const u = requireUser(ctx)
      await checkSecret(u, b)
      await q("UPDATE users SET mfa_enabled = $1, mfa_secret = NULL, backup_codes = '[]' WHERE id = $2", [false, u.id])
      await audit(u.id, 'auth.mfa_disabled', u.id)
      return { ok: true }
    }
    case 'mfa_backup_codes': {
      const u = requireUser(ctx)
      if (!u.mfa_enabled) fail(400, 'A verificação em duas etapas não está ativa.', 'invalid')
      await checkSecret(u, b)
      const codes = newBackupCodes()
      await q('UPDATE users SET backup_codes = $1 WHERE id = $2', [JSON.stringify(codes.map((c) => sha256(c))), u.id])
      return { ok: true, backupCodes: codes }
    }
    case 'sessions_end_others': {
      const u = requireUser(ctx)
      await checkSecret(u, b)
      await q('DELETE FROM sessions WHERE user_id = $1 AND id <> $2', [u.id, ctx.session!.id])
      return { ok: true }
    }
    case 'security_policy': {
      const u = requireUser(ctx)
      if (u.role !== 'superadmin') fail(403, 'Apenas o Administrador Principal pode alterar esta política.', 'forbidden')
      await checkSecret(u, b)
      await setConfig('security-policy', { adminMfaRequired: !!b.adminMfaRequired })
      await audit(u.id, 'security.policy', null, { adminMfaRequired: !!b.adminMfaRequired })
      return { ok: true }
    }

    case 'setup': {
      const { total, supers } = await counts()
      if (supers > 0) fail(409, 'O Administrador Principal já foi definido.', 'setup_done')
      if (total === 0) fail(400, 'Ainda não há contas: crie a primeira conta pelo cadastro.', 'first_account')
      if (!rateLimit(`setup:${ctx.ip}`, 10, 60 * 60_000)) fail(429, 'Muitas tentativas.', 'rate_limited')
      const expected = await ensureSetupCode()
      if (!expected || String(b.code || '').trim().toUpperCase() !== expected.toUpperCase()) fail(400, 'Código de configuração inválido.', 'invalid_code', 'code')
      let id: number
      if (b.mode === 'existing') {
        const row = await one('SELECT * FROM users WHERE email = $1', [normEmail(b.email)])
        if (!row || !(await verifyPassword(String(b.password || ''), row.password_hash))) fail(401, 'E-mail ou senha incorretos.', 'invalid_credentials')
        id = Number(row!.id)
        await q("UPDATE users SET role = 'superadmin', status = 'active', updated_at = $1 WHERE id = $2", [nowIso(), id])
      } else {
        id = await createUser(validateAccount(b), 'superadmin')
      }
      await q("DELETE FROM app_config WHERE key = 'setup-code'")
      await audit(id, 'setup.superadmin', id)
      await createSession(ctx, id)
      return { ok: true, redirect: '/admin' }
    }

    case 'delete_account': {
      const u = requireUser(ctx)
      if (String(b.confirm || '').trim().toUpperCase() !== 'EXCLUIR' || !b.acknowledge) fail(400, 'Confirme digitando EXCLUIR.', 'invalid', 'confirm')
      if (!(await verifyPassword(String(b.password || ''), u.password_hash))) fail(400, 'Senha incorreta.', 'invalid_password', 'password')
      if (u.role === 'superadmin') {
        const others = await one<{ n: number }>("SELECT COUNT(*) AS n FROM users WHERE role = 'superadmin' AND id <> $1", [u.id])
        if (!Number(others?.n)) fail(409, 'Transfira a administração principal antes de excluir esta conta.', 'superadmin_last')
      }
      await q('DELETE FROM users WHERE id = $1', [u.id]) // ON DELETE CASCADE apaga todos os dados da conta
      await audit(u.id, 'account.deleted', u.id, { email: u.email })
      clearSessionCookie(ctx)
      return { ok: true }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}
