// Anúncios das empresas: proposta pelo usuário, aprovação pelo administrador, pagamento por Pix (Mercado Pago)
// e ativação automática pelo webhook. Os planos (níveis 1 a 4) vêm de Administração → Planos de anúncio.
import { createHmac, timingSafeEqual } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { getConfig, unseal } from '../lib/settings.js'
import { notify } from '../lib/notify.js'
import { requireModule } from '../lib/usermod.js'
import { PLANS_DEFAULT, MP_DEFAULT } from '../lib/panel-defaults.js'
import { config } from '../config.js'

const MP_API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const STATUS = ['analise', 'ajustes', 'recusado', 'aprovado', 'ativo', 'encerrado']
async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const out = (b: any, plan?: any) => {
  const d = J<any>(b.data, {})
  const expired = b.status === 'ativo' && b.expires_at && Date.parse(b.expires_at) < Date.now()
  return { id: Number(b.id), protocolo: b.protocolo, status: expired ? 'encerrado' : b.status, planId: b.plan_id, plan: plan || null, ...d, payment: d.payment ? { status: d.payment.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor } : null, lat: b.lat, lng: b.lng, expiresAt: b.expires_at, createdAt: b.created_at }
}
const clean = (v: unknown, n = 200) => str(v, n)
function fields(b: any) {
  const f: any = {
    empresa: clean(b.empresa, 80), categoria: clean(b.categoria, 60), tags: clean(b.tags, 200), titulo: clean(b.titulo, 70), texto: clean(b.texto, 180),
    link: clean(b.link, 300), zap: String(b.zap || '').replace(/\D/g, '').slice(0, 15), insta: clean(b.insta, 40).replace(/^@/, ''),
    endereco: clean(b.endereco, 160), horario: clean(b.horario, 80), sobre: clean(b.sobre, 600), contato: clean(b.contato, 80),
    raio: Math.min(100, Math.max(1, Number(b.raio) || 5)),
  }
  if (f.link && !/^https?:\/\/\S+\.\S+/.test(f.link)) fail(400, 'O link precisa começar com https://', 'invalid', 'link')
  if (typeof b.logo === 'string' && b.logo.startsWith('data:image/') && b.logo.length < 300_000) f.logo = b.logo
  if (typeof b.capa === 'string' && b.capa.startsWith('data:image/') && b.capa.length < 600_000) f.capa = b.capa
  if (b.entrega && typeof b.entrega === 'object') { const e = b.entrega; f.entrega = { retirada: e.retirada !== false, entrega: !!e.entrega, taxa: Math.max(0, Number(e.taxa) || 0), raio: Math.min(100, Math.max(0, Number(e.raio) || 3)), minimo: Math.max(0, Number(e.minimo) || 0), tempo: str(e.tempo, 40) } }
  if (b.pagamento && typeof b.pagamento === 'object') { const p = b.pagamento; f.pagamento = { pix: !!p.pix, chavePix: str(p.chavePix, 120), cartao: !!p.cartao, dinheiro: !!p.dinheiro } }
  return f
}
async function isAdsAdmin(ctx: Ctx) { const u = requireUser(ctx); if (u.role === 'user' || !effectivePermissions(u).includes('ads.manage')) fail(403, 'Sem permissão.', 'forbidden'); return u }
async function admins() { return (await q("SELECT id, role, permissions FROM users WHERE role IN ('admin','superadmin') AND status = 'active'")).map((r) => Number(r.id)) }

export async function adsPlansGet() { await requireModule('anuncios'); return { plans: await plans() } }
export async function adsMineGet(ctx: Ctx) {
  const u = requireUser(ctx); const ps = await plans()
  return { items: (await q('SELECT * FROM businesses WHERE owner_id = $1 ORDER BY id DESC', [u.id])).map((b) => out(b, ps.find((p) => p.id === b.plan_id))) }
}
export async function adsPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('anuncios')
  const b = ctx.body || {}, ps = await plans(), plan = ps.find((p) => p.id === b.planId)
  if (!plan) fail(400, 'Escolha um plano.', 'invalid', 'planId')
  const f = fields(b)
  if (!f.empresa || !f.categoria || !f.titulo) fail(400, 'Preencha o nome da empresa, o ramo e o título.', 'invalid')
  if (plan.nivel >= 2 && !f.zap && !f.insta) fail(400, 'Informe WhatsApp ou Instagram para este plano.', 'invalid')
  if (u.role === 'user' && (await q("SELECT id FROM businesses WHERE owner_id = $1 AND status IN ('analise','ajustes')", [u.id])).length >= 3) fail(400, 'Você já tem propostas em análise.', 'invalid')
  const lat = Number(b.lat), lng = Number(b.lng), hasLoc = isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)
  const protocolo = 'AN-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 8).toUpperCase()
  // administrador com permissão de anúncios publica direto, sem aprovação e sem pagamento
  const isAdmin = u.role !== 'user' && effectivePermissions(u).includes('ads.manage')
  f.registros = [{ t: isAdmin ? 'Publicado pelo administrador (sem pagamento)' : 'Proposta enviada para aprovação', q: nowIso() }]
  const exp = isAdmin ? new Date(Date.now() + (Number(plan.dias) || 30) * 86400_000).toISOString() : null
  await q('INSERT INTO businesses (owner_id, protocolo, status, plan_id, data, lat, lng, expires_at, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)',
    [u.id, protocolo, isAdmin ? 'ativo' : 'analise', plan.id, JSON.stringify(f), hasLoc ? lat : null, hasLoc ? lng : null, exp, nowIso()])
  if (!isAdmin) for (const a of await admins()) await notify(a, { type: 'ads', title: 'Nova proposta de anúncio', body: `${f.empresa} · plano ${plan.nome} · toque para analisar`, link: '/admin?aba=anuncios', ref: `ad-new:${protocolo}:${a}` })
  return adsMineGet(ctx)
}
export async function adsPut(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const d = { ...J<any>(b!.data, {}), ...fields({ ...J<any>(b!.data, {}), ...(ctx.body || {}) }) }
  d.registros = [{ t: 'Detalhes atualizados', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng), hasLoc = isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180
  const st = b!.status === 'ajustes' ? 'analise' : b!.status
  await q('UPDATE businesses SET data = $1, status = $2, lat = COALESCE($3, lat), lng = COALESCE($4, lng), updated_at = $5 WHERE id = $6', [JSON.stringify(d), st, hasLoc ? lat : null, hasLoc ? lng : null, nowIso(), b!.id])
  return adsMineGet(ctx)
}

/* ---------- pagamento Pix (Mercado Pago) ---------- */
async function mpToken() {
  const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }
  const tok = await unseal((mp[mp.modo] || {}).tok || '')
  return { tok, seg: await unseal((mp[mp.modo] || {}).seg || ''), modo: mp.modo }
}
async function activate(b: any, paymentId: string) {
  const ps = await plans(), plan = ps.find((p) => p.id === b.plan_id) || { dias: 30 }
  const d = J<any>(b.data, {}); d.payment = { ...(d.payment || {}), status: 'approved' }
  d.registros = [{ t: 'Pagamento confirmado · anúncio no ar', q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  const exp = new Date(Date.now() + plan.dias * 86400_000).toISOString()
  await q("UPDATE businesses SET status = 'ativo', expires_at = $1, payment_id = $2, data = $3, updated_at = $4 WHERE id = $5", [exp, paymentId, JSON.stringify(d), nowIso(), b.id])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Seu anúncio está no ar!', body: `${d.empresa} · até ${exp.slice(0, 10).split('-').reverse().join('/')}`, link: '/x/sua-empresa', ref: `ad-live:${b.id}:${paymentId}` })
}
async function mpGet(id: string, tok: string) {
  const r = await fetch(`${MP_API()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${tok}` } })
  if (!r.ok) throw new Error('MP ' + r.status)
  return r.json() as Promise<any>
}
export async function adsPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b!.status !== 'aprovado') fail(400, 'O pagamento fica disponível depois da aprovação.', 'invalid')
  const { tok } = await mpToken()
  if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador (Administração → Mercado Pago).', 'mp_not_configured')
  const plan = (await plans()).find((p) => p.id === b!.plan_id)
  if (!plan) fail(400, 'Plano não encontrado.', 'invalid')
  const d = J<any>(b!.data, {})
  if (d.payment?.id && d.payment.status === 'pending' && d.payment.qr) return { payment: { status: 'pending', qr: d.payment.qr, qrImage: d.payment.qrImage, valor: d.payment.valor } }
  const r = await fetch(`${MP_API()}/v1/payments`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `${b!.protocolo}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: plan.preco, description: `Anúncio Meu Assistente · ${plan.nome}`, payment_method_id: 'pix', payer: { email: u.email },
      external_reference: String(b!.id), notification_url: `${config.publicUrl}/api/mercadopago/webhook` }),
  })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp] erro ao criar Pix:', r.status, JSON.stringify(p)?.slice(0, 300)); fail(502, 'O Mercado Pago recusou a criação do Pix. Confira as credenciais no painel.', 'mp_error') }
  const td = p.point_of_interaction?.transaction_data || {}
  d.payment = { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', valor: plan.preco }
  await q('UPDATE businesses SET data = $1, payment_id = $2, updated_at = $3 WHERE id = $4', [JSON.stringify(d), String(p.id), nowIso(), b!.id])
  if (p.status === 'approved') await activate({ ...b, data: JSON.stringify(d) }, String(p.id))
  return { payment: { status: p.status, qr: d.payment.qr, qrImage: d.payment.qrImage, valor: plan.preco } }
}
export async function adsPayStatusGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  if (b!.status === 'ativo') return { status: 'approved' }
  const pid = J<any>(b!.data, {}).payment?.id
  if (!pid) return { status: 'none' }
  const { tok } = await mpToken()
  try { const p = await mpGet(pid, tok); if (p.status === 'approved' && String(p.external_reference) === String(b!.id)) { await activate(b, pid); return { status: 'approved' } } return { status: p.status } }
  catch { return { status: 'unknown' } }
}
export async function mpWebhookPost(ctx: Ctx) {
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const type = String(ctx.query.get('type') || ctx.body?.type || ctx.query.get('topic') || '')
  if (!id || (type && type !== 'payment')) return { ok: true }
  const { tok, seg } = await mpToken()
  if (seg) { // assinatura x-signature do Mercado Pago (quando o segredo foi configurado)
    const sig = String(ctx.req.headers['x-signature'] || ''), reqId = String(ctx.req.headers['x-request-id'] || '')
    const parts = Object.fromEntries(sig.split(',').map((s) => s.trim().split('=') as [string, string]))
    const expected = createHmac('sha256', seg).update(`id:${id};request-id:${reqId};ts:${parts.ts};`).digest('hex')
    if (!parts.v1 || parts.v1.length !== expected.length || !timingSafeEqual(Buffer.from(parts.v1), Buffer.from(expected))) fail(401, 'Assinatura inválida.', 'bad_signature')
  }
  if (!tok) return { ok: true }
  try {
    const p = await mpGet(id, tok) // a confirmação vem sempre da API do Mercado Pago, nunca do corpo recebido
    const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(p.external_reference)])
    if (b && p.status === 'approved' && b.status === 'aprovado') await activate(b, id)
  } catch (e: any) { console.error('[mp] webhook:', e?.message) }
  return { ok: true }
}

/* ---------- administração ---------- */
export async function adminAdsGet(ctx: Ctx) {
  await isAdsAdmin(ctx); const ps = await plans()
  const rows = await q('SELECT b.*, u.name AS owner_name, u.email AS owner_email FROM businesses b JOIN users u ON u.id = b.owner_id ORDER BY b.id DESC LIMIT 300')
  return { items: rows.map((b) => ({ ...out(b, ps.find((p) => p.id === b.plan_id)), owner: { name: b.owner_name, email: b.owner_email } })) }
}
export async function adminAdsPost(ctx: Ctx) {
  const u = await isAdsAdmin(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b) fail(404, 'Anúncio não encontrado.', 'not_found')
  const act = String(ctx.body?.action || ''), motivo = str(ctx.body?.motivo, 300)
  const d = J<any>(b!.data, {})
  const map: Record<string, [string, string, string]> = {
    approve: ['aprovado', 'Anúncio aprovado · aguardando pagamento', 'Seu anúncio foi aprovado! Faça o pagamento para colocá-lo no ar.'],
    adjust: ['ajustes', 'A equipe pediu ajustes: ' + motivo, 'A equipe pediu ajustes no seu anúncio: ' + motivo],
    reject: ['recusado', 'Anúncio recusado: ' + motivo, 'Seu anúncio foi recusado: ' + motivo],
  }
  if (act === 'activate') { await activate(b, 'manual-' + u.id); await audit(u.id, 'ads.activate', Number(b!.owner_id), { id: b!.id }); return adminAdsGet(ctx) }
  if (act === 'end') { await q("UPDATE businesses SET status = 'encerrado', updated_at = $1 WHERE id = $2", [nowIso(), b!.id]); return adminAdsGet(ctx) }
  const m = map[act]; if (!m) fail(400, 'Ação inválida.', 'invalid')
  if ((act === 'adjust' || act === 'reject') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  d.motivo = act === 'approve' ? '' : motivo
  d.registros = [{ t: m[1], q: nowIso() }, ...(d.registros || [])].slice(0, 80)
  await q('UPDATE businesses SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [m[0], JSON.stringify(d), nowIso(), b!.id])
  await notify(Number(b!.owner_id), { type: 'ads', title: m[2], body: d.empresa, link: '/x/sua-empresa', ref: `ad-${act}:${b!.id}:${Date.now()}` })
  await audit(u.id, 'ads.' + act, Number(b!.owner_id), { id: b!.id })
  return adminAdsGet(ctx)
}
export { STATUS }
