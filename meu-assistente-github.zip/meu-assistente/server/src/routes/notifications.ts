import { settingsOf } from '../lib/account.js'
// /api/notifications — central de notificações (lista, contagem, marcar como lida).
import type { Ctx } from '../lib/http.js'
import { q, one, B } from '../db/index.js'
import { requireUser } from '../lib/session.js'

async function unread(userId: number) {
  const r = await one<{ n: number }>('SELECT COUNT(*) AS n FROM notifications WHERE user_id = $1 AND read = $2', [userId, false])
  return Number(r?.n || 0)
}
export async function notificationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (ctx.query.get('count')) return { unread: await unread(u.id) }
  const rows = await q('SELECT * FROM notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 100', [u.id])
  return {
    unread: await unread(u.id),
    items: rows.map((r) => ({ id: Number(r.id), type: r.type, title: r.title, body: r.body, link: r.link, read: B(r.read), createdAt: r.created_at })),
  }
}
export async function notificationsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  if (b.all) await q('UPDATE notifications SET read = $1 WHERE user_id = $2', [true, u.id])
  else if (b.id) await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND id = $3', [true, u.id, Number(b.id)])
  return { ok: true, unread: await unread(u.id) }
}

import { getPublicKey, saveSubscription, sendToUser } from '../lib/push.js'
import { fail } from '../lib/http.js'

export async function pushGet(ctx: Ctx) {
  const u = requireUser(ctx), ep = String(ctx.query.get('endpoint') || '')
  const { getPublicKey, isRegistered } = await import('../lib/push.js')
  if (ctx.query.get('status')) {
    const st: any = settingsOf(u), devices = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [u.id]))[0]?.n || 0)
    return { registered: ep ? await isRegistered(u.id, ep) : false, account: { planPush: true, notificationsEnabled: st.notificationsEnabled !== false, pushEnabled: st.pushEnabled !== false, appointmentsEnabled: st.appointmentsEnabled !== false, devices } }
  }
  if (ep) return { registered: await isRegistered(u.id, ep) }
  return { publicKey: await getPublicKey() }
}
export async function pushPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.test) { const r = await sendToUser(u.id, { title: 'Meu Assistente', body: 'Notificações ativadas neste aparelho. Seus lembretes vão chegar aqui.', url: '/', tag: 'push-test' }); return { ok: true, push: r } }
  if (!b.subscription) fail(400, 'Inscrição inválida.', 'invalid')
  if (!(await saveSubscription(u.id, b.subscription, String(ctx.req.headers['user-agent'] || '')))) fail(400, 'Inscrição inválida.', 'invalid')
  return { ok: true }
}
export async function pushDelete(ctx: Ctx) {
  const u = requireUser(ctx); const { removeSubscription } = await import('../lib/push.js')
  await removeSubscription(u.id, ctx.body?.endpoint ? String(ctx.body.endpoint) : undefined); return { ok: true }
}

// Helper used by other modules to notify a user
export async function notifyPush(userId: number, title: string, body?: string, url?: string) {
  return sendToUser(userId, { title, body, url })
}
