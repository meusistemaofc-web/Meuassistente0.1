import { settingsOf } from '../lib/account.js'
// /api/notifications — central de notificações (lista, contagem, marcar como lida).
import type { Ctx } from '../lib/http.js'
import { q, one, B } from '../db/index.js'
import { requireUser } from '../lib/session.js'

async function unread(userId: number) {
  const r = await one<{ n: number }>('SELECT COUNT(*) AS n FROM notifications WHERE user_id = $1 AND read = $2', [userId, false])
  return Number(r?.n || 0)
}
export async function notificationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (ctx.query.get('count')) return { unread: await unread(u.id) }
  const rows = await q('SELECT * FROM notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 100', [u.id])
  return {
    unread: await unread(u.id),
    items: rows.map((r) => ({ id: Number(r.id), type: r.type, title: r.title, body: r.body, link: r.link, read: B(r.read), createdAt: r.created_at })),
  }
}
export async function notificationsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  if (b.all) await q('UPDATE notifications SET read = $1 WHERE user_id = $2', [true, u.id])
  else if (b.id) await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND id = $3', [true, u.id, Number(b.id)])
  return { ok: true, unread: await unread(u.id) }
}

import { getPublicKey, saveSubscription, sendToUser } from '../lib/push.js'
import { fail } from '../lib/http.js'

export async function pushGet(ctx: Ctx) { return safePush('pushGet', () => pushGet0(ctx)) }
async function pushGet0(ctx: Ctx) {
  const u = requireUser(ctx), ep = String(ctx.query.get('endpoint') || '')
  const { getPublicKey, isRegistered, ensurePushSchema } = await import('../lib/push.js')
  await ensurePushSchema()
  if (ctx.query.get('status')) {
    const st: any = settingsOf(u), devices = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [u.id]))[0]?.n || 0)
    return { registered: ep ? await isRegistered(u.id, ep) : false, account: { planPush: true, notificationsEnabled: st.notificationsEnabled !== false, pushEnabled: st.pushEnabled !== false, appointmentsEnabled: st.appointmentsEnabled !== false, devices } }
  }
  if (ep) return { registered: await isRegistered(u.id, ep) }
  return { publicKey: await getPublicKey() }
}
export async function pushPost(ctx: Ctx) { return safePush('pushPost', () => pushPost0(ctx)) }
async function pushPost0(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.test) { const r = await sendToUser(u.id, { title: 'Meu Assistente', body: 'Notificações ativadas neste aparelho. Seus lembretes vão chegar aqui.', url: '/', tag: 'push-test' }); return { ok: true, push: { ...r, delivered: r.sent, devices: r.total, expired: r.errors.filter((x: string) => /expirada/.test(x)).length } } }
  if (!b.subscription) fail(400, 'Inscrição inválida.', 'invalid')
  let ok = false
  try { ok = await saveSubscription(u.id, b.subscription, String(ctx.req.headers['user-agent'] || '')) } catch (e: any) { console.error('[push] não foi possível salvar a inscrição:', e?.message || e); fail(503, 'Não foi possível registrar este aparelho agora. Tente de novo em instantes.', 'push_unavailable') }
  if (!ok) fail(400, 'Inscrição inválida.', 'invalid')
  return { ok: true }
}
export async function pushDelete(ctx: Ctx) { return safePush('pushDelete', () => pushDelete0(ctx)) }
async function pushDelete0(ctx: Ctx) {
  const u = requireUser(ctx); const { removeSubscription } = await import('../lib/push.js')
  await removeSubscription(u.id, ctx.body?.endpoint ? String(ctx.body.endpoint) : undefined); return { ok: true }
}

// Helper used by other modules to notify a user
export async function notifyPush(userId: number, title: string, body?: string, url?: string) {
  return sendToUser(userId, { title, body, url })
}

/** Erros inesperados do push voltam com o motivo (sem dados sensíveis) em vez de "Algo deu errado no servidor". */
async function safePush<T>(nome: string, fn: () => Promise<T>): Promise<T> {
  try { return await fn() }
  catch (e: any) {
    if (e?.status && e.status < 500) throw e
    const motivo = String(e?.message || e).replace(/postgres(ql)?:\/\/\S+/gi, '[banco]').slice(0, 160)
    console.error(`[push] ${nome} falhou:`, e?.stack || e)
    fail(503, `Não foi possível ativar as notificações agora (${motivo}). Tente de novo em instantes.`, 'push_error')
    throw e
  }
}
/** Diagnóstico do push para o administrador: tabela, chaves VAPID e assinatura. */
export async function pushDiagGet(ctx: Ctx) {
  const u = requireUser(ctx); if (u.role === 'user') fail(403, 'Só para administradores.', 'forbidden')
  const out: any = {}
  const m = await import('../lib/push.js')
  try { await m.ensurePushSchema(true); out.tabela = 'ok' } catch (e: any) { out.tabela = 'erro: ' + e?.message }
  try { const k = await m.getPublicKey(); out.chave = k && k.length > 80 ? 'ok' : 'inválida' } catch (e: any) { out.chave = 'erro: ' + e?.message }
  try { const ep = 'https://diagnostico.invalid/' + Date.now(); await m.saveSubscription(u.id, { endpoint: ep, keys: { p256dh: 'BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM', auth: 'tBHItJI5svbpez7KI4CCXg' } }, 'diagnóstico'); await m.removeSubscription(u.id, ep); out.gravacao = 'ok' } catch (e: any) { out.gravacao = 'erro: ' + e?.message }
  try { m.encryptPayload('BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM', 'tBHItJI5svbpez7KI4CCXg', '{}'); out.criptografia = 'ok' } catch (e: any) { out.criptografia = 'erro: ' + e?.message }
  out.aparelhos = Number((await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = $1', [u.id]))[0]?.n || 0)
  return out
}
