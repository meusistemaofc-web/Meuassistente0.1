// /api/notifications — central de notificações (lista, contagem, marcar como lida).
import type { Ctx } from '../lib/http.js'
import { q, one, B } from '../db/index.js'
import { requireUser } from '../lib/session.js'

async function unread(userId: number) {
  const r = await one<{ n: number }>('SELECT COUNT(*) AS n FROM notifications WHERE user_id = $1 AND read = $2', [userId, false])
  return Number(r?.n || 0)
}
export async function notificationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (ctx.query.get('count')) return { unread: await unread(u.id) }
  const rows = await q('SELECT * FROM notifications WHERE user_id = $1 ORDER BY id DESC LIMIT 100', [u.id])
  return {
    unread: await unread(u.id),
    items: rows.map((r) => ({ id: Number(r.id), type: r.type, title: r.title, body: r.body, link: r.link, read: B(r.read), createdAt: r.created_at })),
  }
}
export async function notificationsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  if (b.all) await q('UPDATE notifications SET read = $1 WHERE user_id = $2', [true, u.id])
  else if (b.id) await q('UPDATE notifications SET read = $1 WHERE user_id = $2 AND id = $3', [true, u.id, Number(b.id)])
  return { ok: true, unread: await unread(u.id) }
}
