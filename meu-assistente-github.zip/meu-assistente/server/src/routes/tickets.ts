// Central de Ajuda (tickets): o usuário vê só os próprios chamados; administradores autorizados veem todos.
// Respostas e mudanças de status geram notificação interna (central + push quando ativo). Sem WhatsApp/e-mail nesta versão.
import { randomBytes } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { q, one, nowIso } from '../db/index.js'
import { notify } from '../lib/notify.js'
const CATS: Record<string, string> = { duvida: 'Dúvida', problema: 'Problema técnico', sugestao: 'Sugestão', solicitacao: 'Solicitação', outros: 'Outros' }
const STATUS: Record<string, string> = { aberto: 'Aberto', em_atendimento: 'Em atendimento', aguardando_usuario: 'Aguardando usuário', resolvido: 'Resolvido' }
const str = (v: any, n: number) => String(v ?? '').trim().slice(0, n)
const MAX_ANEXOS = 3, MAX_BYTES = 2_500_000
function anexosValidos(list: any): { mime: string; nome: string; data: string; tamanho: number }[] {
  const out: any[] = []
  for (const a of Array.isArray(list) ? list.slice(0, MAX_ANEXOS) : []) {
    const m = /^data:(image\/(png|jpe?g|webp|gif|heic));base64,([A-Za-z0-9+/=]+)$/.exec(String(a?.data || ''))
    if (!m) fail(400, 'Anexe apenas imagens (PNG, JPG, WEBP ou GIF).', 'invalid')
    const tam = Math.floor(m![3].length * 3 / 4); if (tam > MAX_BYTES) fail(400, 'Cada imagem pode ter no máximo 2,5 MB.', 'invalid')
    out.push({ mime: m![1], nome: str(a.nome, 80) || 'imagem', data: m![3], tamanho: tam })
  }
  return out
}
async function addMessage(ticketId: number, autor: 'user' | 'admin', userId: number, texto: string, anexos: any[]) {
  await q('INSERT INTO ticket_messages (ticket_id, autor, user_id, texto, created_at) VALUES ($1,$2,$3,$4,$5)', [ticketId, autor, userId, texto, nowIso()])
  const m = await one('SELECT id FROM ticket_messages WHERE ticket_id = $1 ORDER BY id DESC LIMIT 1', [ticketId])
  for (const a of anexos) await q('INSERT INTO ticket_attachments (message_id, ticket_id, mime, nome, data, tamanho) VALUES ($1,$2,$3,$4,$5,$6)', [m!.id, ticketId, a.mime, a.nome, a.data, a.tamanho])
}
async function full(t: any, admin = false) {
  const msgs = await q('SELECT m.*, u.name FROM ticket_messages m LEFT JOIN users u ON u.id = m.user_id WHERE m.ticket_id = $1 ORDER BY m.id', [t.id])
  const atts = await q('SELECT id, message_id, mime, nome, tamanho FROM ticket_attachments WHERE ticket_id = $1', [t.id])
  const u = admin ? await one('SELECT id, name, email FROM users WHERE id = $1', [t.user_id]) : null
  const b = admin && t.business_id ? await one('SELECT data FROM businesses WHERE id = $1', [t.business_id]) : null
  return { ...summary(t), ...(admin ? { usuario: u ? { id: Number(u.id), nome: u.name, email: u.email } : null, empresa: b ? JSON.parse(typeof b.data === 'string' ? b.data : JSON.stringify(b.data)).empresa || null : null } : {}),
    mensagens: msgs.map((m: any) => ({ id: Number(m.id), autor: m.autor, nome: m.autor === 'admin' ? 'Equipe Meu Assistente' : String(m.name || '').split(' ')[0], texto: m.texto, em: m.created_at, anexos: atts.filter((a: any) => Number(a.message_id) === Number(m.id)).map((a: any) => ({ id: Number(a.id), nome: a.nome, mime: a.mime, url: `/api/v2/tickets/anexo/${a.id}` })) })) }
}
const summary = (t: any) => ({ id: Number(t.id), protocolo: t.protocolo, categoria: t.categoria, categoriaNome: CATS[t.categoria] || t.categoria, assunto: t.assunto, status: t.status, statusNome: STATUS[t.status] || t.status, criadoEm: t.created_at, atualizadoEm: t.updated_at, naoLidoUsuario: !!(t.user_unread === true || t.user_unread === 1), naoLidoAdmin: !!(t.admin_unread === true || t.admin_unread === 1) })
async function isAdmin(u: any) { return u.role === 'superadmin' || u.role === 'admin' }

/* ---------- usuário ---------- */
export async function ticketsGet(ctx: Ctx) { const u = requireUser(ctx); return { categorias: CATS, items: (await q('SELECT * FROM tickets WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 100', [u.id])).map(summary) } }
export async function ticketsPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const categoria = CATS[b.categoria] ? b.categoria : fail(400, 'Escolha a categoria.', 'invalid', 'categoria')
  const assunto = str(b.assunto, 140), texto = str(b.descricao, 6000)
  if (assunto.length < 3) fail(400, 'Informe o assunto.', 'invalid', 'assunto')
  if (texto.length < 10) fail(400, 'Descreva com mais detalhes (pelo menos 10 caracteres).', 'invalid', 'descricao')
  const anexos = anexosValidos(b.anexos)
  const recentes = Number((await q('SELECT COUNT(*) AS n FROM tickets WHERE user_id = $1 AND created_at >= $2', [u.id, new Date(Date.now() - 3600_000).toISOString()]))[0].n)
  if (recentes >= 5) fail(429, 'Você abriu muitos chamados na última hora. Aguarde um pouco ou responda em um chamado existente.', 'rate_limited')
  const biz = await one("SELECT id FROM businesses WHERE owner_id = $1 ORDER BY id DESC LIMIT 1", [u.id])
  const protocolo = `AJ-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${randomBytes(3).toString('hex').toUpperCase()}`
  await q('INSERT INTO tickets (protocolo, user_id, business_id, categoria, assunto, status, admin_unread, user_unread, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9)', [protocolo, u.id, biz ? biz.id : null, categoria, assunto, 'aberto', true, false, nowIso()])
  const t = await one('SELECT * FROM tickets WHERE protocolo = $1', [protocolo])
  await addMessage(Number(t!.id), 'user', u.id, texto, anexos)
  return full(t)
}
async function ownTicket(ctx: Ctx) { const u = requireUser(ctx); const t = await one('SELECT * FROM tickets WHERE id = $1 AND user_id = $2', [Number(ctx.params.id), u.id]); if (!t) fail(404, 'Chamado não encontrado.', 'not_found'); return { u, t: t! } }
export async function ticketGet(ctx: Ctx) { const { t } = await ownTicket(ctx); if (t.user_unread) await q('UPDATE tickets SET user_unread = $1 WHERE id = $2', [false, t.id]); return full({ ...t, user_unread: false }) }
export async function ticketMsgPost(ctx: Ctx) {
  const { u, t } = await ownTicket(ctx), texto = str(ctx.body?.texto, 6000)
  if (texto.length < 2 && !(ctx.body?.anexos || []).length) fail(400, 'Escreva sua mensagem.', 'invalid')
  const anexos = anexosValidos(ctx.body?.anexos)
  const novo = t.status === 'resolvido' || t.status === 'aguardando_usuario' ? (t.status === 'resolvido' ? 'aberto' : 'em_atendimento') : t.status
  await addMessage(Number(t.id), 'user', u.id, texto || '(imagem)', anexos)
  await q('UPDATE tickets SET status = $1, admin_unread = $2, updated_at = $3 WHERE id = $4', [novo, true, nowIso(), t.id])
  return full(await one('SELECT * FROM tickets WHERE id = $1', [t.id]))
}
export async function ticketAttGet(ctx: Ctx) {
  const u = requireUser(ctx), a = await one('SELECT a.*, t.user_id FROM ticket_attachments a JOIN tickets t ON t.id = a.ticket_id WHERE a.id = $1', [Number(ctx.params.id)])
  if (!a || (Number(a.user_id) !== u.id && !(await isAdmin(u)))) fail(404, 'Anexo não encontrado.', 'not_found')
  return { _binary: true, data: Buffer.from(a!.data, 'base64'), mime: a!.mime, headers: { 'X-Content-Type-Options': 'nosniff' } }
}
/* ---------- administração ---------- */
async function requireAdmin(ctx: Ctx) { const u = requireUser(ctx); if (!(await isAdmin(u))) fail(403, 'Só para administradores.', 'forbidden'); return u }
export async function adminTicketsGet(ctx: Ctx) {
  await requireAdmin(ctx); const qs = ctx.query, cond: string[] = [], args: any[] = []
  if (qs.get('status')) { args.push(qs.get('status')); cond.push(`t.status = $${args.length}`) }
  if (qs.get('categoria')) { args.push(qs.get('categoria')); cond.push(`t.categoria = $${args.length}`) }
  if (qs.get('de')) { args.push(qs.get('de') + 'T00:00:00-03:00'); cond.push(`t.created_at >= $${args.length}`) }
  if (qs.get('ate')) { args.push(qs.get('ate') + 'T23:59:59-03:00'); cond.push(`t.created_at <= $${args.length}`) }
  if (qs.get('pendentes')) { args.push(true); cond.push(`t.admin_unread = $${args.length}`) }
  const rows = await q(`SELECT t.*, u.name, u.email FROM tickets t JOIN users u ON u.id = t.user_id ${cond.length ? 'WHERE ' + cond.join(' AND ') : ''} ORDER BY t.admin_unread DESC, t.updated_at DESC LIMIT 200`, args)
  const cont = await q('SELECT status, COUNT(*) AS n FROM tickets GROUP BY status'), novos = Number((await q('SELECT COUNT(*) AS n FROM tickets WHERE admin_unread = $1', [true]))[0].n)
  return { categorias: CATS, status: STATUS, naoRespondidos: novos, contagem: Object.fromEntries(cont.map((r: any) => [r.status, Number(r.n)])), items: rows.map((t: any) => ({ ...summary(t), usuario: { nome: t.name, email: t.email } })) }
}
export async function adminTicketGet(ctx: Ctx) { await requireAdmin(ctx); const t = await one('SELECT * FROM tickets WHERE id = $1', [Number(ctx.params.id)]); if (!t) fail(404, 'Chamado não encontrado.', 'not_found'); return full(t, true) }
/** Responder e/ou mudar o status. O usuário recebe notificação (e o contador dos três pontinhos sobe). */
export async function adminTicketPost(ctx: Ctx) {
  const u = await requireAdmin(ctx), b = ctx.body || {}
  const t = await one('SELECT * FROM tickets WHERE id = $1', [Number(ctx.params.id)]); if (!t) fail(404, 'Chamado não encontrado.', 'not_found')
  const texto = str(b.texto, 6000), novo = b.status && STATUS[b.status] ? b.status : null
  if (!texto && !novo) fail(400, 'Escreva uma resposta ou escolha um status.', 'invalid')
  const anexos = anexosValidos(b.anexos)
  if (texto) await addMessage(Number(t!.id), 'admin', u.id, texto, anexos)
  const status = novo || (texto && t!.status === 'aberto' ? 'em_atendimento' : t!.status)
  await q('UPDATE tickets SET status = $1, admin_unread = $2, user_unread = $3, updated_at = $4 WHERE id = $5', [status, false, true, nowIso(), t!.id])
  const msg = texto ? `Nova resposta no chamado ${t!.protocolo}` : `Chamado ${t!.protocolo}: ${STATUS[status]}`
  await notify(Number(t!.user_id), { type: 'support', title: msg, body: texto ? texto.slice(0, 140) : `Status atualizado para ${STATUS[status]}.`, link: `/x/ajuda/${t!.id}`, ref: `ticket:${t!.id}:${Date.now()}` })
  return full(await one('SELECT * FROM tickets WHERE id = $1', [t!.id]), true)
}
