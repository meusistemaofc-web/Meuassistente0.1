// Cotações reais de criptomoedas e ações da B3 com fontes grátis e troca automática (Administração → Fontes de mercado).
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig, setConfig, unseal } from '../lib/settings.js'
import { MARKET_DEFAULT, type MarketProvider } from '../lib/panel-defaults.js'

export const CRYPTO: Record<string, { gecko: string; paprika: string; nome: string }> = {
  BTC: { gecko: 'bitcoin', paprika: 'btc-bitcoin', nome: 'Bitcoin' }, ETH: { gecko: 'ethereum', paprika: 'eth-ethereum', nome: 'Ethereum' },
  SOL: { gecko: 'solana', paprika: 'sol-solana', nome: 'Solana' }, XRP: { gecko: 'ripple', paprika: 'xrp-xrp', nome: 'XRP' },
  BNB: { gecko: 'binancecoin', paprika: 'bnb-binance-coin', nome: 'BNB' }, ADA: { gecko: 'cardano', paprika: 'ada-cardano', nome: 'Cardano' },
  DOGE: { gecko: 'dogecoin', paprika: 'doge-dogecoin', nome: 'Dogecoin' }, LTC: { gecko: 'litecoin', paprika: 'ltc-litecoin', nome: 'Litecoin' },
  XLM: { gecko: 'stellar', paprika: 'xlm-stellar', nome: 'Stellar' }, USDT: { gecko: 'tether', paprika: 'usdt-tether', nome: 'Tether' },
}
const isStock = (s: string) => s === 'IBOV' || /^[A-Z]{4}(3|4|5|6|11)$/.test(s)
const cache = new Map<string, { at: number; v: Quote }>()
const pause = new Map<string, number>()
interface Quote { symbol: string; nome: string; price: number; change24h: number | null; source: string; tried: string[]; at: string }

function pick(obj: any, path: string) { return path.split('.').reduce((o, k) => (o == null ? undefined : o[/^\d+$/.test(k) ? Number(k) : k]), obj) }
function build(p: MarketProvider, sym: string, key: string) {
  const c = CRYPTO[sym]
  let u = p.url
  if (sym === 'IBOV') u = u.replace('{SIMBOLO}.SA', '%5EBVSP').replace('{SIMBOLO}', p.id === 'brapi' ? '%5EBVSP' : 'IBOV')
  return u.replace(/\{SIMBOLO\}/g, encodeURIComponent(sym)).replace(/\{simbolo\}/g, encodeURIComponent(sym.toLowerCase()))
    .replace(/\{id\}/g, c?.gecko || sym.toLowerCase()).replace(/\{paprika\}/g, c?.paprika || sym.toLowerCase()).replace(/\{chave\}/g, encodeURIComponent(key))
}
function parse(p: MarketProvider, sym: string, d: any): { price: number; change: number | null } | null {
  const n = (v: any) => (v === undefined || v === null || v === '' ? NaN : Number(String(v).replace('%', '')))
  let price = NaN, change: number | null = null
  switch (p.id) {
    case 'coingecko': { const x = d?.[CRYPTO[sym]?.gecko || '']; price = n(x?.brl); change = n(x?.brl_24h_change); break }
    case 'coinpaprika': price = n(d?.quotes?.BRL?.price); change = n(d?.quotes?.BRL?.percent_change_24h); break
    case 'binance': price = n(d?.lastPrice); change = n(d?.priceChangePercent); break
    case 'brapi': price = n(d?.results?.[0]?.regularMarketPrice); change = n(d?.results?.[0]?.regularMarketChangePercent); break
    case 'yahoo': { const m = d?.chart?.result?.[0]?.meta; price = n(m?.regularMarketPrice); const pc = n(m?.chartPreviousClose ?? m?.previousClose); change = pc ? ((price - pc) / pc) * 100 : null; break }
    case 'alphavantage': price = n(d?.['Global Quote']?.['05. price']); change = n(d?.['Global Quote']?.['10. change percent']); break
    case 'twelvedata': price = n(d?.close); change = n(d?.percent_change); break
    default: price = n(pick(d, p.campo))
  }
  if (!isFinite(price) || price <= 0) return null
  return { price, change: change !== null && isFinite(change) ? change : null }
}
export async function marketProviders(): Promise<MarketProvider[]> {
  const saved = await getConfig<MarketProvider[]>('market_providers', [])
  return saved.length ? saved : MARKET_DEFAULT
}
export async function fetchQuote(p: MarketProvider, sym: string): Promise<{ price: number; change: number | null }> {
  const key = await unseal(p.key)
  if (p.precisaChave && !key) throw Object.assign(new Error('sem chave'), { status: 0 })
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 8000)
  try {
    const r = await fetch(build(p, sym, key), { signal: ctl.signal, headers: { 'User-Agent': 'MeuAssistente/1.0', Accept: 'application/json' } })
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { status: r.status })
    const v = parse(p, sym, await r.json())
    if (!v) throw Object.assign(new Error('resposta sem preço'), { status: 0 })
    return v
  } finally { clearTimeout(t) }
}
export async function quote(symRaw: string): Promise<Quote> {
  const sym = symRaw.toUpperCase()
  const cat = CRYPTO[sym] ? 'cripto' : isStock(sym) ? 'bolsa' : null
  if (!cat) fail(400, 'Ativo não reconhecido.', 'invalid')
  const hit = cache.get(sym)
  if (hit && Date.now() - hit.at < 60_000) return hit.v
  const tried: string[] = []
  for (const p of await marketProviders()) {
    if (!p.ativo || p.cat !== cat || (pause.get(p.id) || 0) > Date.now()) continue
    try {
      const v = await fetchQuote(p, sym)
      const q: Quote = { symbol: sym, nome: CRYPTO[sym]?.nome || sym, price: v.price, change24h: v.change, source: p.nome, tried, at: new Date().toISOString() }
      cache.set(sym, { at: Date.now(), v: q }); void bumpStat(p.id, true, '')
      return q
    } catch (e: any) {
      if (e?.message === 'sem chave') continue
      pause.set(p.id, Date.now() + (e?.status === 429 ? 60_000 : 30_000))
      tried.push(p.nome); void bumpStat(p.id, false, e?.message || 'falha')
    }
  }
  fail(502, 'Nenhuma fonte de cotação respondeu agora.', 'market_unavailable')
  throw new Error('unreachable')
}
async function bumpStat(id: string, ok: boolean, err: string) {
  const s = await getConfig<Record<string, any>>('market-status', {})
  const x = s[id] || (s[id] = { uses: 0, failures: 0, lastError: '' })
  if (ok) x.uses++; else { x.failures++; x.lastError = err }
  await setConfig('market-status', s).catch(() => {})
}
export async function marketQuoteGet(ctx: Ctx) {
  requireUser(ctx)
  const s = str(ctx.query.get('s'), 12)
  if (!s) fail(400, 'Informe o ativo.', 'invalid')
  return quote(s)
}
