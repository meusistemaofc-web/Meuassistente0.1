// /api/me — perfil, configurações e plano da conta (contrato do provedor de sessão do frontend).
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate } from '../lib/http.js'
import { q, nowIso, one } from '../db/index.js'
import { requireUser, hydrateUser } from '../lib/session.js'
import { VOICE_KEYS } from '../lib/account.js'
import { meOf, ALLOWED_SETTINGS } from '../lib/account.js'
import { whatsappProblem, normWhatsapp } from '../lib/security.js'
import { validTz } from '../lib/time.js'

export async function meGet(ctx: Ctx) { return meOf(requireUser(ctx)) }

const bool = (o: any) => Object.fromEntries(Object.entries(o || {}).filter(([, v]) => typeof v === 'boolean'))

export async function mePatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  const sets: string[] = []
  const vals: unknown[] = []
  const add = (col: string, v: unknown) => { vals.push(v); sets.push(`${col} = $${vals.length}`) }
  if (b.profile && typeof b.profile === 'object') {
    const p = b.profile
    if (p.name !== undefined) {
      const name = str(p.name, 120)
      if (name.length < 3 || !name.includes(' ')) fail(400, 'Informe seu nome completo (nome e sobrenome).', 'invalid', 'name')
      add('name', name)
    }
    if (p.whatsapp !== undefined) {
      const wp = whatsappProblem(p.whatsapp)
      if (wp) fail(400, wp, 'invalid', 'whatsapp')
      add('whatsapp', normWhatsapp(String(p.whatsapp)))
    }
    if (p.birthday !== undefined) {
      if (p.birthday && !isDate(p.birthday)) fail(400, 'Data inválida.', 'invalid', 'birthday')
      add('birthday', p.birthday || null)
    }
  }
  if (b.settings && typeof b.settings === 'object') {
    const next: any = { ...u.settings }
    if (b.settings.reminderLeadMinutes !== undefined) next.reminderLeadCustom = true // o usuário escolheu a antecedência dos compromissos
    for (const [k, v] of Object.entries(b.settings)) {
      if (!ALLOWED_SETTINGS.has(k)) continue
      if ((VOICE_KEYS as readonly string[]).includes(k)) continue // voz é só do administrador (painel), para todos
      if (k === 'timezone') next[k] = validTz(v)
      else if (k === 'theme') next[k] = v === 'light' ? 'light' : 'dark'
      else if (['string', 'number', 'boolean'].includes(typeof v) || v === null || (k === 'menuLayout' && typeof v === 'object')) next[k] = v
    }
    add('settings', JSON.stringify(next))
  }
  if (b.interaction) add('interaction', JSON.stringify({ ...u.interaction, ...bool(b.interaction) }))
  if (b.chatUi) add('chat_ui', JSON.stringify({ ...u.chat_ui, ...bool(b.chatUi) }))
  if (sets.length) {
    add('updated_at', nowIso())
    vals.push(u.id)
    await q(`UPDATE users SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals)
  }
  const row = await one('SELECT * FROM users WHERE id = $1', [u.id])
  return meOf(hydrateUser(row))
}

/** Módulos que o usuário fixou no próprio menu (os demais ficam na pasta "Módulos"). */
export async function menuPinsGet(ctx: Ctx) { const u = requireUser(ctx); const { getUM } = await import('../lib/usermod.js'); return { pins: await getUM<string[]>(u.id, 'menu_pins', []) } }
export async function menuPinsPut(ctx: Ctx) {
  const u = requireUser(ctx); const { setUM } = await import('../lib/usermod.js'); const { MOD_CATALOG } = await import('../lib/modcatalog.js')
  const pins = (Array.isArray(ctx.body?.pins) ? ctx.body.pins : []).map(String).filter((k: string) => MOD_CATALOG.some((m) => m.key === k)).slice(0, 30)
  await setUM(u.id, 'menu_pins', pins); return { pins }
}
