// /api/me — perfil, configurações e plano da conta (contrato do provedor de sessão do frontend).
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate } from '../lib/http.js'
import { q, nowIso, one, J } from '../db/index.js'
import { requireUser, hydrateUser } from '../lib/session.js'
import { VOICE_KEYS } from '../lib/account.js'
import { meOf, ALLOWED_SETTINGS } from '../lib/account.js'
import { whatsappProblem, normWhatsapp } from '../lib/security.js'
import { validTz } from '../lib/time.js'

export async function meGet(ctx: Ctx) { return meOf(requireUser(ctx)) }

const bool = (o: any) => Object.fromEntries(Object.entries(o || {}).filter(([, v]) => typeof v === 'boolean'))

export async function mePatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  const sets: string[] = []
  const vals: unknown[] = []
  const add = (col: string, v: unknown) => { vals.push(v); sets.push(`${col} = $${vals.length}`) }
  if (b.profile && typeof b.profile === 'object') {
    const p = b.profile
    if (p.name !== undefined) {
      const name = str(p.name, 120)
      if (name.length < 3 || !name.includes(' ')) fail(400, 'Informe seu nome completo (nome e sobrenome).', 'invalid', 'name')
      add('name', name)
    }
    if (p.whatsapp !== undefined) {
      const wp = whatsappProblem(p.whatsapp)
      if (wp) fail(400, wp, 'invalid', 'whatsapp')
      add('whatsapp', normWhatsapp(String(p.whatsapp)))
    }
    if (p.birthday !== undefined) {
      if (p.birthday && !isDate(p.birthday)) fail(400, 'Data inválida.', 'invalid', 'birthday')
      add('birthday', p.birthday || null)
    }
  }
  if (b.settings && typeof b.settings === 'object') {
    const next: any = { ...u.settings }
    if (b.settings.reminderLeadMinutes !== undefined) next.reminderLeadCustom = true // o usuário escolheu a antecedência dos compromissos
    for (const [k, v] of Object.entries(b.settings)) {
      if (!ALLOWED_SETTINGS.has(k)) continue
      if ((VOICE_KEYS as readonly string[]).includes(k)) continue // voz é só do administrador (painel), para todos
      if (k === 'timezone') next[k] = validTz(v)
      else if (k === 'theme') next[k] = v === 'light' ? 'light' : 'dark'
      else if (['string', 'number', 'boolean'].includes(typeof v) || v === null || (k === 'menuLayout' && typeof v === 'object')) next[k] = v
    }
    add('settings', JSON.stringify(next))
  }
  if (b.interaction) add('interaction', JSON.stringify({ ...u.interaction, ...bool(b.interaction) }))
  if (b.chatUi) add('chat_ui', JSON.stringify({ ...u.chat_ui, ...bool(b.chatUi) }))
  if (sets.length) {
    add('updated_at', nowIso())
    vals.push(u.id)
    await q(`UPDATE users SET ${sets.join(', ')} WHERE id = $${vals.length}`, vals)
  }
  const row = await one('SELECT * FROM users WHERE id = $1', [u.id])
  return meOf(hydrateUser(row))
}

/** Módulos que o usuário fixou no próprio menu (os demais ficam na pasta "Módulos"). */
export async function menuPinsGet(ctx: Ctx) { const u = requireUser(ctx); const { getUM } = await import('../lib/usermod.js'); return { pins: await getUM<string[]>(u.id, 'menu_pins', []) } }
export async function menuPinsPut(ctx: Ctx) {
  const u = requireUser(ctx); const { setUM } = await import('../lib/usermod.js'); const { MOD_CATALOG } = await import('../lib/modcatalog.js')
  const pins = (Array.isArray(ctx.body?.pins) ? ctx.body.pins : []).map(String).filter((k: string) => MOD_CATALOG.some((m) => m.key === k)).slice(0, 30)
  await setUM(u.id, 'menu_pins', pins); return { pins }
}

/** Confirmação de e-mail (link assinado) e descadastro por tipo de e-mail (link assinado no rodapé). */
export async function emailConfirmGet(ctx: Ctx) {
  const { unsubSig } = await import('../lib/mail.js'), uid = Number(ctx.query.get('u')), s = String(ctx.query.get('s') || '')
  if (uid && s === unsubSig(uid, 'confirmar')) { const r = await one('SELECT settings FROM users WHERE id = $1', [uid]); if (r) { const st = { ...J<any>(r.settings, {}), verifiedEmail: true }; await q('UPDATE users SET settings = $1 WHERE id = $2', [JSON.stringify(st), uid]) } ctx.res.writeHead(302, { Location: '/?email_confirmado=1' }); ctx.res.end(); return { _handled: true } }
  ctx.res.writeHead(302, { Location: '/?email_confirmado=0' }); ctx.res.end(); return { _handled: true }
}
export async function emailOptOutGet(ctx: Ctx) {
  const { unsubSig, KINDS } = await import('../lib/mail.js'), uid = Number(ctx.query.get('u')), k = String(ctx.query.get('k') || ''), s = String(ctx.query.get('s') || '')
  const ok = !!uid && !!KINDS[k] && s === unsubSig(uid, k)
  if (ok) { const r = await one('SELECT settings FROM users WHERE id = $1', [uid]); if (r) { const st = J<any>(r.settings, {}); st.emailOptOut = { ...(st.emailOptOut || {}), [k]: true }; await q('UPDATE users SET settings = $1 WHERE id = $2', [JSON.stringify(st), uid]) } }
  ctx.res.writeHead(ok ? 200 : 400, { 'Content-Type': 'text/html; charset=utf-8' })
  ctx.res.end(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#0b0d12;color:#e8eaf0;padding:40px 20px;text-align:center"><h1 style="font-size:20px">${ok ? 'Pronto, você não vai mais receber este tipo de e-mail.' : 'Link inválido.'}</h1><p style="color:#8a90a0">${ok ? `Tipo: ${KINDS[k].nome}. E-mails de segurança e recuperação de senha continuam chegando.` : ''}</p><p><a href="/" style="color:#7aa2ff">Abrir o Meu Assistente</a></p></body>`)
  return { _handled: true }
}
