// /api/admin, /api/admin/users, /api/admin/audit — painel administrativo (abas Usuários e Atividades).
// As demais abas do painel original (integrações, planos, anúncios, cérebro, eleições...) dependem de
// módulos não reconstruídos; o servidor só concede as permissões das abas que funcionam de verdade.
import type { Ctx } from '../lib/http.js'
import { fail, str, isDate } from '../lib/http.js'
import { q, one, nowIso, J } from '../db/index.js'
import { requireUser, hydrateUser, type SessionUser } from '../lib/session.js'
import { effectivePermissions, PERMISSION_CATALOG, ALL_PERMISSIONS, audit } from '../lib/account.js'
import { createUser } from './auth.js'
import { passwordProblem, whatsappProblem, normWhatsapp, verifyPassword } from '../lib/security.js'

async function requireAdmin(ctx: Ctx, perm?: string): Promise<{ u: SessionUser; perms: string[] }> {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const pol = await one("SELECT value FROM app_config WHERE key = 'security-policy'")
  if (J<any>(pol?.value, {}).adminMfaRequired && !u.mfa_enabled) fail(403, 'Ative a verificação em duas etapas para usar o painel.', 'mfa_required')
  const perms = effectivePermissions(u)
  if (perm && !perms.includes(perm)) fail(403, 'Sem permissão para esta ação.', 'forbidden')
  return { u, perms }
}
const userOut = (r: any) => {
  const h = hydrateUser(r)
  return { id: h.id, name: h.name, email: h.email, whatsapp: h.whatsapp, birthday: h.birthday, role: h.role, status: h.status,
    permissions: effectivePermissions(h), createdAt: h.created_at, lastSeenAt: h.last_seen_at, mfaEnabled: h.mfa_enabled, plan: null }
}

export async function adminGet(ctx: Ctx) {
  const u = requireUser(ctx)
  if (u.role === 'user') return { access: 'none' }
  try {
    const { perms } = await requireAdmin(ctx)
    return { access: 'admin', me: { id: u.id, role: u.role, permissions: perms }, catalog: PERMISSION_CATALOG }
  } catch (e: any) {
    if (e?.code === 'mfa_required') return { access: 'none', code: 'mfa_required' }
    throw e
  }
}

export async function adminUsersGet(ctx: Ctx) {
  await requireAdmin(ctx, 'users.view')
  const term = str(ctx.query.get('q'), 100)
  const rows = term
    ? await q('SELECT * FROM users WHERE name ILIKE $1 OR email ILIKE $1 OR whatsapp ILIKE $1 ORDER BY id DESC LIMIT 200', [`%${term}%`])
    : await q('SELECT * FROM users ORDER BY id DESC LIMIT 200')
  return { users: rows.map(userOut) }
}

export async function adminUsersPost(ctx: Ctx) {
  const { u } = await requireAdmin(ctx, 'users.manage')
  const b = ctx.body || {}
  const target = b.id ? await one('SELECT * FROM users WHERE id = $1', [Number(b.id)]) : null
  if (b.action !== 'create' && !target) fail(404, 'Usuário não encontrado.', 'not_found')
  const t = target ? hydrateUser(target) : null
  // administradores comuns só gerenciam usuários comuns
  if (t && u.role !== 'superadmin' && t.role !== 'user') fail(403, 'Apenas o Administrador Principal gerencia administradores.', 'forbidden')
  const perms = (p: unknown) => (Array.isArray(p) ? p.filter((x) => ALL_PERMISSIONS.includes(x)) : [])
  switch (b.action) {
    case 'create': {
      const name = str(b.name, 120)
      if (name.length < 3 || !name.includes(' ')) fail(400, 'Informe o nome completo.', 'invalid', 'name')
      const wp = whatsappProblem(b.whatsapp); if (wp) fail(400, wp, 'invalid', 'whatsapp')
      const email = str(b.email, 254).toLowerCase()
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'Informe um e-mail válido.', 'invalid', 'email')
      if (b.birthday && !isDate(b.birthday)) fail(400, 'Data inválida.', 'invalid', 'birthday')
      const pp = passwordProblem(b.password); if (pp) fail(400, pp, 'invalid', 'password')
      const role = u.role === 'superadmin' && b.role === 'admin' ? 'admin' : 'user'
      const id = await createUser({ name, whatsapp: normWhatsapp(String(b.whatsapp)), email, birthday: b.birthday || null, password: b.password }, role, { permissions: role === 'admin' ? perms(b.permissions) : [] })
      await audit(u.id, 'user.create', id, { email, role })
      return { ok: true, user: userOut(await one('SELECT * FROM users WHERE id = $1', [id])) }
    }
    case 'update': {
      const name = str(b.name, 120) || t!.name
      const email = b.email !== undefined ? str(b.email, 254).toLowerCase() : t!.email
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fail(400, 'Informe um e-mail válido.', 'invalid', 'email')
      const dup = await one('SELECT id FROM users WHERE email = $1 AND id <> $2', [email, t!.id])
      if (dup) fail(409, 'Já existe uma conta com este e-mail.', 'email_taken', 'email')
      let whatsapp = t!.whatsapp
      if (b.whatsapp !== undefined) { const wp = whatsappProblem(b.whatsapp); if (wp) fail(400, wp, 'invalid', 'whatsapp'); whatsapp = normWhatsapp(String(b.whatsapp)) }
      if (b.birthday && !isDate(b.birthday)) fail(400, 'Data inválida.', 'invalid', 'birthday')
      await q('UPDATE users SET name = $1, email = $2, whatsapp = $3, birthday = $4, updated_at = $5 WHERE id = $6', [name, email, whatsapp, b.birthday || t!.birthday, nowIso(), t!.id])
      await audit(u.id, 'user.update', t!.id)
      break
    }
    case 'setStatus': {
      if (t!.role === 'superadmin') fail(400, 'O Administrador Principal não pode ser desativado.', 'invalid')
      if (t!.id === u.id) fail(400, 'Você não pode desativar a própria conta.', 'invalid')
      const status = b.status === 'disabled' ? 'disabled' : 'active'
      await q('UPDATE users SET status = $1, updated_at = $2 WHERE id = $3', [status, nowIso(), t!.id])
      if (status === 'disabled') await q('DELETE FROM sessions WHERE user_id = $1', [t!.id])
      await audit(u.id, status === 'disabled' ? 'user.disable' : 'user.enable', t!.id)
      break
    }
    case 'setRole': {
      if (u.role !== 'superadmin') fail(403, 'Apenas o Administrador Principal altera funções.', 'forbidden')
      if (t!.role === 'superadmin') fail(400, 'Use a transferência de administração principal.', 'invalid')
      const role = b.role === 'admin' ? 'admin' : 'user'
      await q('UPDATE users SET role = $1, permissions = $2, updated_at = $3 WHERE id = $4', [role, JSON.stringify(role === 'admin' ? perms(b.permissions) : []), nowIso(), t!.id])
      await audit(u.id, 'user.role', t!.id, { role })
      break
    }
    case 'transferPrincipal': {
      if (u.role !== 'superadmin') fail(403, 'Apenas o Administrador Principal pode transferir.', 'forbidden')
      if (!(await verifyPassword(String(b.password || ''), u.password_hash))) fail(400, 'Senha incorreta.', 'invalid_password', 'password')
      if (str(b.confirmEmail, 254).toLowerCase() !== t!.email) fail(400, 'O e-mail de confirmação não confere.', 'invalid', 'confirmEmail')
      if (t!.status !== 'active') fail(400, 'A conta de destino está desativada.', 'invalid')
      await q("UPDATE users SET role = 'superadmin', updated_at = $1 WHERE id = $2", [nowIso(), t!.id])
      await q("UPDATE users SET role = 'admin', permissions = $1, updated_at = $2 WHERE id = $3", [JSON.stringify(ALL_PERMISSIONS), nowIso(), u.id])
      await audit(u.id, 'user.transfer_principal', t!.id)
      break
    }
    default: fail(400, 'Ação desconhecida.', 'unknown_action')
  }
  return { ok: true, user: userOut(await one('SELECT * FROM users WHERE id = $1', [t!.id])) }
}

export async function adminAuditGet(ctx: Ctx) {
  await requireAdmin(ctx, 'audit.view')
  const rows = await q(`SELECT a.*, u.name AS actor_name, u.email AS actor_email FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.id DESC LIMIT 200`)
  return { entries: rows.map((r) => ({ id: Number(r.id), action: r.action, targetId: r.target_id ? Number(r.target_id) : null, details: J(r.details, {}), createdAt: r.created_at, actorName: r.actor_name, actorEmail: r.actor_email })) }
}
