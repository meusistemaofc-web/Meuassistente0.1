import { randomBytes } from 'node:crypto'
// Empresas parceiras: busca por ramo e distância (com permissão de localização), página da empresa,
// loja com produtos/variações e pedidos (plano Loja completa) que chegam em Sua empresa.
import type { Ctx } from '../lib/http.js'
import { fail, str, HttpError } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { config } from '../config.js'
import { pixExpiry, pixValid } from '../lib/pix.js'
import { notify } from '../lib/notify.js'
import { getUM, setUM, requireModule, modules } from '../lib/usermod.js'
import { PLANS_DEFAULT, SEARCH_DEFAULT } from '../lib/panel-defaults.js'

const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set(['perto', 'proximo', 'proxima', 'quero', 'procuro', 'onde', 'tem', 'uma', 'um', 'mim', 'aqui', 'minha', 'meu', 'de', 'da', 'do', 'com', 'para', 'tem', 'algum', 'alguma', 'uns', 'umas', 'os', 'as', 'no', 'na'])
/* ---------- estatísticas de acesso ---------- */
const seen = new Set<string>()
const dayBR = () => new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10)
export async function hit(bid: number, kind: string, viewer?: string | number | null, ownerId?: number | null) {
  try {
    if (ownerId != null && viewer != null && String(viewer) === String(ownerId)) return // o dono não conta
    const day = dayBR()
    if (viewer != null && kind !== 'agente' && kind !== 'pedido') { const k = `${bid}:${kind}:${viewer}:${day}`; if (seen.has(k)) return; if (seen.size > 200000) seen.clear(); seen.add(k) }
    await q('INSERT INTO business_stats (business_id, day, kind, n) VALUES ($1,$2,$3,1) ON CONFLICT (business_id, day, kind) DO UPDATE SET n = business_stats.n + 1', [bid, day, kind])
  } catch (e: any) { console.error('[stats]', e?.message) }
}
/** Taxa de entrega: fixa, ou por distância (grátis até X km; acima, taxa de saída + valor por km excedente). */
export function deliveryFee(E: any, km: number) {
  if (E.modoTaxa !== 'km') return Number(E.taxa) || 0
  if (km <= (Number(E.kmGratis) || 0)) return 0
  return Math.round(((Number(E.taxaExcedente) || 0) + (Number(E.taxaKm) || 0) * (km - (Number(E.kmGratis) || 0))) * 100) / 100
}
export function distKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371, t = (x: number) => (x * Math.PI) / 180, dl = t(b.lat - a.lat), dn = t(b.lng - a.lng)
  const h = Math.sin(dl / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dn / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}
async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const nivelOf = (ps: any[], id: string) => (ps.find((p) => p.id === id) || {}).nivel || 1
async function activeRows() { return q("SELECT * FROM businesses WHERE status = 'ativo' AND (expires_at IS NULL OR expires_at > $1)", [nowIso()]) }
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']
const SERV_RE = /(barbear|salao|salão|cabel|manicure|pedicure|unha|estetic|estétic|clinic|clínic|consult|dentist|odonto|psicolog|terap|fisio|nutri|medic|médic|veterin|pet ?shop|banho e tosa|personal|academia|aula|curso|advog|contab|oficina|mecanic|mecânic|tatu|tattoo|piercing|fotograf|massag|spa|depila|sobrancel|cilios|cílios|maquiag|lavagem|lava ?jato|eletricist|encanad|diarista|limpeza|conserto|assistencia|assistência|studio|estúdio)/i
export const nicheType = (x: any) => x.tipo || (SERV_RE.test(`${x.categoria || ''} ${x.tags || ''}`) ? 'servicos' : 'produtos')
export function openState(x: any): { aberto: boolean; texto: string } {
  const h = x.horarioCfg
  if (!h) return { aberto: true, texto: x.horario || '' }
  if (h.modo === 'aberto') return { aberto: true, texto: 'Aberto agora' }
  if (h.modo === 'fechado') return { aberto: false, texto: 'Fechado no momento' }
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }))
  const d = h.dias?.[DIAS[now.getDay()]], hm = now.getHours() * 60 + now.getMinutes()
  const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
  if (!d || !d.ativo) return { aberto: false, texto: 'Fechado hoje' }
  const ab = toMin(d.abre), fe = toMin(d.fecha), dentro = fe > ab ? hm >= ab && hm < fe : hm >= ab || hm < fe
  return { aberto: dentro, texto: dentro ? `Aberto até ${d.fecha}` : `Fechado · abre ${hm < ab ? 'hoje' : ''} às ${d.abre}`.replace('  ', ' ') }
}
function card(b: any, n: number, d: number | null) {
  const x = J<any>(b.data, {}), st = openState(x)
  return { id: Number(b.id), empresa: x.empresa, categoria: x.categoria, titulo: x.titulo, texto: x.texto, logo: x.logo || null, nivel: n, distancia: d,
    zap: n >= 2 ? x.zap || null : null, insta: n >= 2 ? x.insta || null : null, link: x.link || null, temPagina: n >= 3, temLoja: n >= 4, capa: x.capa || null, aberto: st.aberto, situacao: st.texto }
}
export function matches(q0: string, b: any) {
  const words = norm(q0).split(' ').filter((w) => w.length >= 3 && !STOP.has(w))
  if (!words.length) return true
  const x = J<any>(b.data, {}), kw = norm(`${x.categoria} ${x.tags} ${x.empresa}`).split(' ')
  const forms = (w: string) => [w, w.replace(/s$/, ''), w.replace(/(ria|rias)$/, '')]
  return words.some((w) => forms(w).some((f) => f.length >= 3 && kw.some((k) => k === f || k.startsWith(f) || (f.startsWith(k) && k.length >= 4))))
}
export async function searchBusinesses(text: string, loc: { lat: number; lng: number; raio?: number | null } | null) {
  const ps = await plans(), admMax = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(admMax, loc?.raio || admMax)
  const out: any[] = []
  for (const b of await activeRows()) {
    if (!matches(text, b)) continue
    const raio = Math.min(max, Number(J<any>(b.data, {}).raio) || 5)
    const d = loc && b.lat != null ? distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) : null
    if (loc && (d === null || d > raio)) continue
    out.push(card(b, nivelOf(ps, b.plan_id), d === null ? null : Math.round(d * 10) / 10)); (out[out.length - 1] as any)._owner = Number(b.owner_id)
  }
  return out.sort((a, b) => (a.distancia ?? 1e9) - (b.distancia ?? 1e9)).slice(0, 30)
}
const locOk = (lat: number, lng: number) => isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

export async function myLocationPut(ctx: Ctx) {
  const u = requireUser(ctx), lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng)
  if (ctx.body?.clear) { await setUM(u.id, 'location', null); return { ok: true } }
  const old = await getUM<any>(u.id, 'location', null)
  const raio = Number(ctx.body?.raio) >= 1 && Number(ctx.body?.raio) <= 100 ? Number(ctx.body.raio) : old?.raio || null
  if (ctx.body?.raio && !ctx.body?.endereco && !isFinite(lat) && old) { await setUM(u.id, 'location', { ...old, raio }); return { ok: true, location: { ...old, raio } } }
  if (typeof ctx.body?.endereco === 'string' && ctx.body.endereco.trim().length >= 3) {
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(ctx.body.endereco.trim()), { headers: { 'User-Agent': 'MeuAssistente/1.0 (contato pelo app)', 'Accept-Language': 'pt-BR' } }).catch(() => null)
    const j: any = r && r.ok ? await r.json().catch(() => []) : []
    if (!j[0]) fail(400, 'Não encontrei esse endereço. Tente com bairro e cidade.', 'invalid')
    const loc = { lat: Number(j[0].lat), lng: Number(j[0].lon), at: nowIso(), raio, label: String(j[0].display_name || '').split(',').slice(0, 3).join(','), manual: true }
    await setUM(u.id, 'location', loc); return { ok: true, location: loc }
  }
  if (!locOk(lat, lng)) fail(400, 'Localização inválida.', 'invalid')
  const loc = { lat, lng, at: nowIso(), raio, label: 'Localização atual', manual: false }
  await setUM(u.id, 'location', loc); return { ok: true, location: loc }
}
export async function userLocation(userId: number) {
  const l = await getUM<any>(userId, 'location', null)
  return l && (l.manual || Date.now() - Date.parse(l.at) < 7 * 86400_000) ? { lat: l.lat, lng: l.lng, raio: l.raio || null, label: l.label || '' } : null
}
export async function businessSearchGet(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const lat = Number(ctx.query.get('lat')), lng = Number(ctx.query.get('lng'))
  const loc = locOk(lat, lng) ? { lat, lng } : await userLocation(u.id)
  if (!loc) return { needLocation: true, items: [] }
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15
  const items = await searchBusinesses(str(ctx.query.get('q'), 80), loc as any)
  for (const it of items) await hit(it.id, 'impressao', u.id, it._owner)
  items.forEach((it: any) => delete it._owner)
  return { needLocation: false, location: { label: (loc as any).label || 'Localização atual', raio: Math.min(adm, (loc as any).raio || adm), max: adm }, items }
}

/* ---------- página pública e produtos ---------- */
function productOut(p: any) { const d = J<any>(p.data, {}); return { id: Number(p.id), active: !!(p.active === true || p.active === 1 || p.active === 't'), ...d } }
export function unitPrice(prod: any, escolhas: Record<string, number>) {
  let base = Number(prod.preco) || 0, extra = 0
  for (const v of prod.variacoes || []) {
    const o = v.opcoes?.[Number(escolhas?.[v.nome] ?? 0)]
    if (!o) fail(400, `Escolha uma opção de ${v.nome}.`, 'invalid')
    const pr = Number(o.preco) || 0
    if (pr >= (Number(prod.preco) || 0) * 0.5 && pr > 0) base = pr; else extra += pr
  }
  return Math.round((base + extra) * 100) / 100
}
export async function businessGet(ctx: Ctx) {
  const u = ctx.user || null; await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const ps = await plans()
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) fail(404, 'O anúncio desta empresa não está ativo.', 'not_found')
  const n = nivelOf(ps, b!.plan_id); if (n < 3) fail(404, 'Esta empresa não tem página própria.', 'not_found')
  const x = J<any>(b!.data, {}), loc = u ? await userLocation(u.id) : null
  await hit(Number(b!.id), 'visita', u ? u.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b!.owner_id))
  const loja = n >= 4 && (await modules()).catalogo !== false
  const prods = loja ? (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b!.id, true])).map(productOut) : []
  return { ...card(b, n, loc && b!.lat != null ? Math.round(distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) * 10) / 10 : null),
    endereco: x.endereco, horario: x.horario, sobre: x.sobre, capa: x.capa || null, lat: b!.lat, lng: b!.lng, loja, produtos: prods,
    tema: x.tema || null, tipo: nicheType(x), etiquetas: x.etiquetas || [], categorias: x.categorias || [], dias: x.horarioCfg?.dias || null,
    entrega: loja ? { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', modoTaxa: 'fixa', kmGratis: 0, taxaExcedente: 0, taxaKm: 0, ...(x.entrega || {}) } : null,
    pagamento: loja ? (() => { const pg = { pix: true, chavePix: '', cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }; pg.online = !!(pg.online && x.mpTok); return pg })() : null }
}
async function ownBusiness(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  return { u, b: b! }
}
export async function productsGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { items: (await q('SELECT * FROM products WHERE business_id = $1 ORDER BY id', [b.id])).map(productOut) } }
export async function productsPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  if (nivelOf(await plans(), b.plan_id) < 4) fail(403, 'Produtos fazem parte do plano Loja completa.', 'forbidden')
  const it = ctx.body || {}
  if (it.action === 'delete') { await q('DELETE FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); return productsGet(ctx) }
  if (it.action === 'tags') { const p = await one('SELECT data FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) { const d = J<any>(p.data, {}); d.tags = (Array.isArray(it.tags) ? it.tags : []).map((t: any) => str(t, 12)).filter(Boolean).slice(0, 5); await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), Number(it.id)]) } return productsGet(ctx) }
  if (it.action === 'toggle') { const p = await one('SELECT active FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) await q('UPDATE products SET active = $1 WHERE id = $2', [!(p.active === true || p.active === 1), Number(it.id)]); return productsGet(ctx) }
  const nome = str(it.nome, 80), tipo = it.tipo === 'servico' ? 'servico' : 'produto', modoPreco = ['fixo', 'hora', 'consulta', 'orcamento'].includes(it.modoPreco) ? it.modoPreco : 'fixo'
  const preco = modoPreco === 'orcamento' ? Math.max(0, Number(it.preco) || 0) : Number(it.preco)
  if (!nome || !(preco >= 0 && preco < 1e6)) fail(400, 'Preencha o nome e um preço válido.', 'invalid')
  const fotos = (Array.isArray(it.fotos) ? it.fotos : []).filter((f: any) => typeof f === 'string' && f.startsWith('data:image/') && f.length < 450_000).slice(0, 2)
  if (!fotos.length && tipo === 'produto') fail(400, 'Adicione pelo menos uma foto do produto.', 'invalid')
  const duracao = tipo === 'servico' ? Math.min(600, Math.max(10, Math.round(Number(it.duracao) || 30))) : 0
  const tags = (Array.isArray(it.tags) ? it.tags : []).map((t: any) => str(t, 12)).filter(Boolean).slice(0, 5)
  const variacoes = (Array.isArray(it.variacoes) ? it.variacoes : []).slice(0, 6).map((v: any) => ({ nome: str(v.nome, 40), opcoes: (Array.isArray(v.opcoes) ? v.opcoes : []).slice(0, 12).map((o: any) => ({ nome: str(o.nome, 40), preco: Math.max(0, Number(o.preco) || 0) })).filter((o: any) => o.nome) })).filter((v: any) => v.nome && v.opcoes.length)
  const data = JSON.stringify({ nome, preco: Math.round(preco * 100) / 100, descricao: str(it.descricao, 600), categoria: str(it.categoria, 40) || (tipo === 'servico' ? 'Serviços' : 'Outros'), fotos, variacoes, tipo, modoPreco, duracao, tags })
  if (it.id) await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3 AND business_id = $4', [data, nowIso(), Number(it.id), b.id])
  else await q('INSERT INTO products (business_id, data, active, created_at, updated_at) VALUES ($1,$2,$3,$4,$4)', [b.id, data, true, nowIso()])
  return productsGet(ctx)
}

/* ---------- pedidos ---------- */
const NEXT: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['preparo', 'cancelado'], preparo: ['saiu', 'pronto', 'cancelado'], saiu: ['concluido', 'cancelado'], pronto: ['concluido', 'cancelado'] }
const NEXT_AG: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['concluido', 'cancelado'] }
const MSG: Record<string, string> = { aceito: 'foi aceito', preparo: 'está em preparo', saiu: 'saiu para entrega', pronto: 'está pronto para retirar', concluido: 'foi concluído', recusado: 'foi recusado', cancelado: 'foi cancelado' }
const orderOut = (o: any) => ({ id: Number(o.id), businessId: Number(o.business_id), status: o.status, total: Number(o.total), ...J<any>(o.data, {}), createdAt: o.created_at, updatedAt: o.updated_at })
export async function orderPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b || b.status !== 'ativo' || nivelOf(await plans(), b.plan_id) < 4) fail(404, 'Esta loja não está recebendo pedidos.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode fazer pedido na sua própria loja.', 'invalid')
  if (!openState(J<any>(b!.data, {})).aberto) fail(400, 'A loja está fechada agora. Veja o horário de funcionamento.', 'closed')
  const x = J<any>(b!.data, {}), E = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  P.online = !!(P.online && x.mpTok)
  const body = ctx.body || {}, itens: any[] = Array.isArray(body.itens) ? body.itens.slice(0, 50) : []
  if (!itens.length) fail(400, 'Seu pedido está vazio.', 'invalid')
  const prods = new Map((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2', [b!.id, true])).map((p) => [Number(p.id), J<any>(p.data, {})]))
  const linhas = itens.map((it) => {
    const p = prods.get(Number(it.pid)); if (!p || p.tipo === 'servico') fail(400, 'Um dos produtos não está mais disponível.', 'invalid')
    const qtd = Math.min(99, Math.max(1, Math.floor(Number(it.qtd) || 1))), preco = unitPrice(p, it.escolhas || {})
    const vars = (p!.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[Number(it.escolhas?.[v.nome] ?? 0)].nome}`)
    return { pid: Number(it.pid), nome: p!.nome, vars, obs: str(it.obs, 140), qtd, preco }
  })
  const sub = Math.round(linhas.reduce((a, l) => a + l.preco * l.qtd, 0) * 100) / 100
  const modo = body.modo === 'entrega' ? 'entrega' : 'retirada'
  if (modo === 'entrega' && !E.entrega) fail(400, 'Esta loja não faz entregas.', 'invalid')
  if (modo === 'retirada' && !E.retirada) fail(400, 'Esta loja não tem retirada no local.', 'invalid')
  if (E.minimo && sub < E.minimo) fail(400, `Pedido mínimo: R$ ${Number(E.minimo).toFixed(2).replace('.', ',')}.`, 'invalid')
  const endereco = modo === 'entrega' ? str(body.endereco, 200) : ''
  if (modo === 'entrega' && endereco.length < 6) fail(400, 'Informe o endereço de entrega.', 'invalid')
  if (modo === 'entrega' && b!.lat != null) { const loc = await userLocation(u.id); if (loc && distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) > Number(E.raio || 3)) fail(400, 'Seu endereço está fora da área de entrega desta loja.', 'invalid') }
  const pag = ['pix', 'cartao', 'dinheiro', 'online'].includes(body.pagamento) && P[body.pagamento] ? body.pagamento : null
  if (!pag) fail(400, 'Escolha uma forma de pagamento aceita pela loja.', 'invalid')
  let taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0
  if (modo === 'entrega' && E.modoTaxa === 'km') { const loc = await userLocation(u.id); if (!loc || b!.lat == null) fail(400, 'Para calcular a entrega por distância, ative sua localização em Empresas perto de você.', 'need_location'); taxa = deliveryFee(E, distKm(loc!, { lat: Number(b!.lat), lng: Number(b!.lng) })) }
  const total = Math.round((sub + taxa) * 100) / 100
  const data = { itens: linhas, subtotal: sub, taxa, modo, endereco, pagamento: pag, obs: str(body.obs, 300), troco: pag === 'dinheiro' ? str(body.troco, 20) : '', cliente: str(body.nome, 80) || u.name, telefone: str(body.telefone, 30) || u.whatsapp, empresa: x.empresa, motivo: '' }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, 'novo', total, JSON.stringify(data), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  if (pag === 'online') { // Pix automático pelo Mercado Pago da própria loja
    try { await createOrderPix(b, o, u.email, total) }
    catch (e: any) { await q("UPDATE orders SET status = 'cancelado', updated_at = $1 WHERE id = $2", [nowIso(), o.id]); fail(502, 'Não foi possível gerar o Pix da loja agora. Escolha outra forma de pagamento.', 'mp_error') }
    o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!
  }
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  if (pag !== 'online') await notify(Number(b!.owner_id), { type: 'order', title: `Novo pedido #${o.id} · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente} · ${modo === 'entrega' ? 'entrega' : 'retirada'}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  return { order: orderOut(o) }
}
export async function myOrdersGet(ctx: Ctx) { const u = requireUser(ctx); return { items: (await q('SELECT * FROM orders WHERE customer_id = $1 ORDER BY id DESC LIMIT 60', [u.id])).map(orderOut).filter((o: any) => !o.guest).slice(0, 50) } }
export async function businessOrdersGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { items: (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 200', [b.id])).map(orderOut) } }
export async function businessOrderPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), b.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const to = String(ctx.body?.status || ''), motivo = str(ctx.body?.motivo, 200)
  const ag = J<any>(o!.data, {}).tipo === 'agendamento'
  if (!((ag ? NEXT_AG : NEXT)[o!.status] || []).includes(to)) fail(400, 'Mudança de situação inválida.', 'invalid')
  if ((to === 'recusado' || to === 'cancelado') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  const d = { ...J<any>(o!.data, {}), motivo }
  await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [to, JSON.stringify(d), nowIso(), o!.id])
  if (!J<any>(o!.data, {}).guest) await notify(Number(o!.customer_id), { type: 'order', title: ag ? `Agendamento #${o!.id} ${to === 'aceito' ? 'foi confirmado' : MSG[to]}` : `Pedido #${o!.id} ${MSG[to]}`, body: `${d.empresa}${motivo ? ' · ' + motivo : ''}`, link: '/x/pedidos', ref: `order:${o!.id}:${to}` })
  return businessOrdersGet(ctx)
}

/* ---------- Mercado Pago da loja (pagamento automático dos pedidos) ---------- */
const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
async function storeToken(b: any) { return unseal(J<any>(b.data, {}).mpTok || '') }
async function createOrderPix(b: any, o: any, email: string, total: number) {
  const tok = await storeToken(b); if (!tok) throw new Error('sem token')
  const exp = await pixExpiry()
  const x = J<any>(b.data, {})
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `order-${o.id}` },
    body: JSON.stringify({ transaction_amount: total, description: `Pedido #${o.id} · ${x.empresa}`, payment_method_id: 'pix', payer: { email: email || `pedido${o.id}@clientes.meuassistente.app` }, date_of_expiration: exp.iso, external_reference: `order:${o.id}`, notification_url: `${config.publicUrl}/api/mercadopago/webhook?store=${b.id}` }) })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp-loja] Pix:', r.status, JSON.stringify(p)?.slice(0, 200)); throw new Error('mp') }
  const td = p.point_of_interaction?.transaction_data || {}
  const d = { ...J<any>(o.data, {}), payment: { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }, pago: p.status === 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
}
async function markOrderPaid(o: any) {
  const d = J<any>(o.data, {}); if (d.pago) return
  d.pago = true; d.payment = { ...(d.payment || {}), status: 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [o.business_id])
  if (b) await notify(Number(b.owner_id), { type: 'order', title: `Novo pedido #${o.id} · PAGO · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'} · Pix confirmado`, link: '/x/sua-empresa', ref: `order-paid:${o.id}` })
  if (!d.guest) await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} confirmado`, body: d.empresa, link: '/x/pedidos', ref: `order-paid-c:${o.id}` })
}
async function checkOrderPayment(o: any) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment?.id) return d.pago ? 'approved' : 'none'
  const b = await one('SELECT * FROM businesses WHERE id = $1', [o.business_id]); if (!b) return 'none'
  const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(d.payment.id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
  const p: any = await r.json().catch(() => ({}))
  if (r.ok && p.status === 'approved' && String(p.external_reference) === `order:${o.id}`) { await markOrderPaid(o); return 'approved' }
  return p.status || 'unknown'
}
export async function orderPayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown'), d = J<any>(o!.data, {})
  return { status: st, payment: d.payment ? { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt } : null, expirado: !d.pago && !pixValid(d.payment), total: Number(o!.total) }
}
export async function orderPayPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const d = J<any>(o!.data, {}); if (d.pago) return orderPayGet(ctx)
  if (['cancelado', 'recusado', 'concluido'].includes(o!.status)) fail(400, 'Este pedido não aceita mais pagamento.', 'invalid')
  if (!pixValid(d.payment)) { const b = await one('SELECT * FROM businesses WHERE id = $1', [o!.business_id]); await createOrderPix(b, o, u.email, Number(o!.total)) }
  return orderPayGet(ctx)
}
export async function storeWebhook(ctx: Ctx) {
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.query.get('store'))])
  if (!id || !b) return { ok: true }
  try {
    const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
    const p: any = await r.json()
    const oid = String(p.external_reference || '').replace('order:', '')
    const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(oid), b.id])
    if (o && p.status === 'approved') await markOrderPaid(o)
  } catch (e: any) { console.error('[mp-loja] webhook:', e?.message) }
  return { ok: true }
}
export async function storeMpPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, d = J<any>(b.data, {})
  if (body.action === 'test') {
    const tok = await storeToken(b); if (!tok) return { ok: false, message: 'Salve o Access Token da sua conta Mercado Pago antes de testar.' }
    try { const r = await fetch(`${MPB()}/users/me`, { headers: { Authorization: `Bearer ${tok}` } }); const j: any = await r.json().catch(() => ({}))
      if (!r.ok) return { ok: false, message: r.status === 401 || r.status === 403 ? 'O Mercado Pago recusou o Access Token.' : 'Erro ' + r.status + ' no Mercado Pago.' }
      return { ok: true, message: `Conectado à conta ${j.nickname || j.email || j.id}${tok.startsWith('TEST-') ? ' (modo teste)' : ''}. Pronto para receber.` }
    } catch (e: any) { return { ok: false, message: 'Sem conexão com o Mercado Pago.' } }
  }
  if (body.action === 'remove') { delete d.mpTok; d.pagamento = { ...(d.pagamento || {}), online: false } }
  else {
    const tok = String(body.tok || '').trim()
    if (!/^(APP_USR|TEST)-[\w-]{10,}$/.test(tok)) fail(400, 'O Access Token começa com APP_USR- (produção) ou TEST- (teste).', 'invalid')
    d.mpTok = await seal(tok); d.pagamento = { ...(d.pagamento || {}), online: true }
  }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, mpLoja: !!d.mpTok, mpMasked: d.mpTok ? maskSecret(await unseal(d.mpTok)) : '' }
}

/** Cartões das empresas para o chat (imagem, descrição e botões conforme o plano). */
export async function businessCardsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const ids = String(ctx.query.get('ids') || '').split(',').map(Number).filter((n) => n > 0).slice(0, 12)
  if (!ids.length) return { items: [] }
  const ps = await plans(), loc = await userLocation(u.id), out: any[] = []
  for (const id of ids) {
    const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [id])
    if (!b || (b.expires_at && Date.parse(b.expires_at) < Date.now())) continue
    out.push(card(b, nivelOf(ps, b.plan_id), loc && b.lat != null ? Math.round(distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) * 10) / 10 : null))
    await hit(id, 'impressao', u.id, Number(b.owner_id))
  }
  return { items: out }
}

/** Escolhe um anúncio para aparecer no chat conforme a frequência definida no painel. */
export async function maybeAd(u: { id: number }) {
  const cfg = { ativo: true, cada: 6, intervaloMin: 30, ...(await getConfig<any>('ad_frequency', {})) }
  if (!cfg.ativo || !(await modules()).anuncios) return null
  const st = await getUM<any>(u.id, 'ad_state', { n: 0, at: 0 }); st.n = (st.n || 0) + 1
  if (st.n < Math.max(1, Number(cfg.cada) || 6) || Date.now() - (st.at || 0) < (Number(cfg.intervaloMin) || 0) * 60_000) { await setUM(u.id, 'ad_state', st); return null }
  const loc = await userLocation(u.id), rows = (await activeRows()).filter((b) => Number(b.owner_id) !== u.id && (!loc || b.lat == null || distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) <= (Number(J<any>(b.data, {}).raio) || 5)))
  if (!rows.length) { await setUM(u.id, 'ad_state', st); return null }
  const pick = rows[Math.floor(Math.random() * rows.length)]
  await setUM(u.id, 'ad_state', { n: 0, at: Date.now() })
  await hit(Number(pick.id), 'impressao', u.id, Number(pick.owner_id))
  return Number(pick.id)
}

/* ---------- Agente de atendimento da empresa (plano próprio, link público) ---------- */
const agentHits = new Map<string, number[]>()
async function agentPlan() { return { preco: 39.9, dias: 30, limiteDia: 300, ...(await getConfig<any>('agent_plan', {})) } }
const agentOn = (x: any) => !!(x.agente && x.agente.expiresAt && Date.parse(x.agente.expiresAt) > Date.now() && x.agente.ativo !== false)
export async function agentPut(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const outro = (await q('SELECT id, data FROM businesses WHERE owner_id = $1 AND id <> $2', [u.id, b.id])).find((r) => J<any>(r.data, {}).agente)
  if (outro) fail(409, `Você já tem um agente de atendimento (${J<any>(outro.data, {}).empresa}). Cada conta pode ter um agente.`, 'agent_exists')
  const d = J<any>(b.data, {}), a = ctx.body || {}
  d.agente = { ...(d.agente || {}), nome: str(a.nome, 40) || 'Atendente', saudacao: str(a.saudacao, 300), instrucoes: str(a.instrucoes, 2000), tom: ['amigavel', 'profissional', 'divertido', 'direto'].includes(a.tom) ? a.tom : 'amigavel', ativo: a.ativo !== false }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(b.id)
}
async function agentInfo(id: number) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [id]); const x = J<any>(b!.data, {}), p = await agentPlan()
  return { agente: x.agente || null, ativo: agentOn(x), link: `${config.publicUrl}/a/${id}`, plano: { preco: p.preco, dias: p.dias }, payment: x.agente?.payment || null }
}
export async function agentGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return agentInfo(Number(b.id)) }
async function adminTok() { const { MP_DEFAULT } = await import('../lib/panel-defaults.js'); const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }; return unseal((mp[mp.modo] || {}).tok || '') }
export async function agentPayPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx); await requireModule('agente')
  const d = J<any>(b.data, {}); if (!d.agente) fail(400, 'Configure o agente antes de pagar.', 'invalid')
  const p = await agentPlan()
  if (u.role !== 'user') { await activateAgent(Number(b.id), 'admin-' + Date.now()); return agentInfo(Number(b.id)) } // administrador: sem pagamento
  if (pixValid(d.agente.payment)) return agentInfo(Number(b.id))
  const exp = await pixExpiry(), tok = await adminTok(); if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador.', 'mp_not_configured')
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `agent-${b.id}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: p.preco, description: `Agente de atendimento · ${d.empresa}`, payment_method_id: 'pix', payer: { email: u.email }, date_of_expiration: exp.iso, external_reference: `agent:${b.id}`, notification_url: `${config.publicUrl}/api/mercadopago/webhook` }) })
  const j: any = await r.json().catch(() => null); if (!r.ok || !j?.id) fail(502, 'Não foi possível gerar o Pix agora.', 'mp_error')
  const td = j.point_of_interaction?.transaction_data || {}
  d.agente.payment = { id: String(j.id), valor: p.preco, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '', expiresAt: exp.at }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return agentInfo(Number(b.id))
}
export async function activateAgent(bid: number, paymentId: string) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [bid]); if (!b) return
  const d = J<any>(b.data, {}), p = await agentPlan(); if (!d.agente || d.agente.lastPayment === paymentId) return
  const base = d.agente.expiresAt && Date.parse(d.agente.expiresAt) > Date.now() ? Date.parse(d.agente.expiresAt) : Date.now()
  d.agente = { ...d.agente, expiresAt: new Date(base + p.dias * 86400_000).toISOString(), lastPayment: paymentId, payment: null }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), bid])
  await notify(Number(b.owner_id), { type: 'ads', title: 'Seu agente de atendimento está no ar!', body: `Compartilhe o link: ${config.publicUrl}/a/${bid}`, link: '/x/sua-empresa', ref: `agent:${bid}:${paymentId}` })
}
export async function agentPayGet(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), d = J<any>(b.data, {})
  if (agentOn(d) && !d.agente?.payment) return { status: 'approved' }
  const pid = d.agente?.payment?.id; if (!pid) return { status: 'none' }
  try { const r = await fetch(`${MPB()}/v1/payments/${pid}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json()
    if (j.status === 'approved' && j.external_reference === `agent:${b.id}`) { await activateAgent(Number(b.id), pid); return { status: 'approved' } } return { status: j.status } } catch { return { status: 'unknown' } }
}
async function agentBiz(id: number, ctx?: Ctx) {
  const b = await one('SELECT * FROM businesses WHERE id = $1', [id]); const x = b ? J<any>(b.data, {}) : null
  const dono = !!(ctx?.user && b && Number(b.owner_id) === ctx.user.id)
  if (b && x && dono && x.agente) return { b, x, teste: !agentOn(x) || b.status !== 'ativo' } // o dono pode testar antes de colocar no ar
  if (!b || !x || !(await modules()).agente || !agentOn(x) || b.status !== 'ativo') {
    const err: any = new HttpError(404, 'O atendimento automático desta empresa está pausado no momento.', 'not_found')
    err.extra = b && x ? { empresa: x.empresa, logo: x.logo || null, zap: x.zap || null, loja: b.status === 'ativo' ? `${config.publicUrl}/x/empresa/${b.id}` : null } : null
    throw err
  }
  return { b, x, teste: false }
}
export async function agentPublicGet(ctx: Ctx) {
  const { b, x, teste } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x)
  return { teste, nome: x.agente.nome, saudacao: x.agente.saudacao || `Olá! Sou ${x.agente.nome}, da ${x.empresa}. Como posso ajudar?`, empresa: x.empresa, categoria: x.categoria, logo: x.logo || null, aberto: st.aberto, situacao: st.texto, loja: `${config.publicUrl}/x/empresa/${b.id}`, zap: x.zap || null }
}
export async function agentChatPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b, x, teste } = await agentBiz(id, ctx)
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= 12) fail(429, 'Muitas mensagens seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
  const p = await agentPlan(), day = new Date().toISOString().slice(0, 10), cnt = x.agente.uso?.dia === day ? x.agente.uso.n : 0
  if (cnt >= p.limiteDia) fail(429, 'O atendimento automático atingiu o limite de hoje. Fale com a empresa pelo WhatsApp.', 'limit_reached')
  const msgs = (Array.isArray(ctx.body?.messages) ? ctx.body.messages : []).slice(-12).map((m: any) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: str(m.content, 600) })).filter((m: any) => m.content)
  if (!msgs.length || msgs[msgs.length - 1].role !== 'user') fail(400, 'Envie uma mensagem.', 'invalid')
  const prods = (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id LIMIT 60', [id, true])).map(productOut)
  const ps = await plans(), n = nivelOf(ps, b.plan_id), st = openState(x), E = { ...(x.entrega || {}) }, P = { ...(x.pagamento || {}) }
  const { complete, engineCfg, engineInstructions } = await import('../ai/provider.js')
  const eng = await engineCfg()
  const sys = [
    `Você é ${x.agente.nome}, atendente virtual da empresa "${x.empresa}" (${x.categoria}). Atenda clientes em português do Brasil, de forma natural, educada e objetiva, ajudando a tirar dúvidas e a vender.`,
    engineInstructions({ ...eng, personalidade: x.agente.tom || eng.personalidade, personalidadeTexto: '' }),
    'Use SOMENTE as informações abaixo. Não invente preços, produtos, prazos ou políticas. Se não souber, diga que vai verificar e ofereça o WhatsApp da empresa.',
    `Sobre: ${x.sobre || x.texto || ''}`, x.horarioCfg?.dias ? `Horário de funcionamento: ${['seg', 'ter', 'qua', 'qui', 'sex', 'sab', 'dom'].map((k) => { const d = x.horarioCfg.dias[k]; return `${k} ${d?.ativo ? d.abre + '–' + d.fecha : 'fechado'}` }).join(', ')}.` : (x.horario ? `Horário: ${x.horario}` : ''), x.endereco ? `Endereço: ${x.endereco}` : '', `Situação agora: ${st.texto || (st.aberto ? 'aberto' : 'fechado')}.`,
    n >= 4 ? `Pedidos: o cliente faz o pedido pela loja online: ${config.publicUrl}/x/empresa/${id}` : '', x.zap ? `WhatsApp: https://wa.me/${x.zap}` : '',
    E.entrega ? `Entrega: até ${E.raio || 3} km; ${E.modoTaxa === 'km' ? `grátis até ${E.kmGratis || 0} km, depois R$ ${E.taxaExcedente || 0} + R$ ${E.taxaKm || 0} por km` : `taxa R$ ${E.taxa || 0}`}${E.tempo ? `; tempo ${E.tempo}` : ''}.` : 'Somente retirada no local.',
    `Pagamento: ${[P.online ? 'Pix pelo app' : '', P.pix ? 'Pix' : '', P.cartao ? 'cartão na entrega/retirada' : '', P.dinheiro ? 'dinheiro' : ''].filter(Boolean).join(', ') || 'combinar com a empresa'}.`,
    prods.length ? `Catálogo (use o id nas ferramentas):\n${prods.map((p: any) => `- [id ${p.id}] ${p.tipo === 'servico' ? '(serviço ' + (p.duracao || 30) + ' min, ' + ({ fixo: 'valor fixo', hora: 'por hora', consulta: 'consulta', orcamento: 'sob orçamento' } as any)[p.modoPreco || 'fixo'] + ') ' : ''}${p.nome}: R$ ${Number(p.preco).toFixed(2).replace('.', ',')}${(p.variacoes || []).length ? ' (' + p.variacoes.map((v: any) => v.nome + ': ' + v.opcoes.map((o: any) => o.nome + (o.preco ? ' R$ ' + o.preco : '')).join('/')).join('; ') + ')' : ''}${p.descricao ? ' – ' + String(p.descricao).slice(0, 120) : ''}`).join('\n')}` : '',
    x.agente.instrucoes ? `Instruções da empresa: ${x.agente.instrucoes}` : '',
  ].filter(Boolean).join('\n')
  const out: any = {}, conv: any[] = [{ role: 'system', content: sys + '\nVocê pode usar ferramentas: mostrar_catalogo (mostra fotos e preços na tela), criar_pedido, horarios_livres e agendar_servico. Antes de criar pedido ou agendamento, confirme itens/opções, retirada ou entrega (com endereço), forma de pagamento e o nome do cliente. Quando gerar Pix, diga que o QR Code apareceu na tela. Datas de hoje: ' + new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })).toISOString().slice(0, 10) + '.' }, ...msgs]
  let m: any = null
  for (let round = 0; round < 4; round++) {
    m = await complete(conv as any, AG_TOOLS as any)
    if (!m.tool_calls?.length) break
    conv.push({ role: 'assistant', content: m.content ?? null, tool_calls: m.tool_calls })
    for (const call of m.tool_calls) { let res: any; try { res = await runAgentTool(b, call.function.name, JSON.parse(call.function.arguments || '{}'), out) } catch (e: any) { res = { ok: false, erro: e?.message || 'falha' } } conv.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(res) }) }
    m = null
  }
  if (!m) m = { content: out.pix ? 'Pronto! Gerei o Pix: o QR Code e o código copia e cola estão logo abaixo.' : 'Pronto!' }
  if (!teste) { x.agente.uso = { dia: day, n: cnt + 1 }; await hit(id, 'agente', null) }
  await q('UPDATE businesses SET data = $1 WHERE id = $2', [JSON.stringify(x), id])
  return { reply: String(m.content || '').trim() || 'Desculpe, pode repetir?', produtos: out.produtos || null, pix: out.pix || null, secao: out.secao || null }
}

export async function businessHitPost(ctx: Ctx) {
  const kind = String(ctx.body?.kind || ''); if (!['whatsapp', 'instagram', 'link', 'compartilhar', 'mapa'].includes(kind)) return { ok: true }
  const b = await one('SELECT id, owner_id FROM businesses WHERE id = $1', [Number(ctx.params.id)]); if (!b) return { ok: true }
  await hit(Number(b.id), kind, ctx.user ? ctx.user.id : String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || 'anon'), Number(b.owner_id))
  return { ok: true }
}
/* ---------- relatórios da empresa ---------- */
async function reportData(bid: number, dias: number) {
  const since = new Date(Date.now() - dias * 86400_000), sinceDay = since.toISOString().slice(0, 10)
  const st = await q('SELECT day, kind, n FROM business_stats WHERE business_id = $1 AND day >= $2', [bid, sinceDay])
  const tot: Record<string, number> = {}, porDia: Record<string, any> = {}
  for (const r of st) { tot[r.kind] = (tot[r.kind] || 0) + Number(r.n); (porDia[r.day] ||= {})[r.kind] = Number(r.n) }
  const orders = (await q('SELECT * FROM orders WHERE business_id = $1 AND created_at >= $2', [bid, since.toISOString()])).map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total), day: String(o.created_at).slice(0, 10) }))
  const ok = orders.filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status)))
  const fat = Math.round(ok.reduce((a, o) => a + o.total, 0) * 100) / 100
  const porPag: Record<string, number> = {}, prod: Record<string, { qtd: number; valor: number }> = {}
  for (const o of ok) { porPag[o.pagamento] = Math.round(((porPag[o.pagamento] || 0) + o.total) * 100) / 100; for (const i of o.itens || []) { const p = (prod[i.nome] ||= { qtd: 0, valor: 0 }); p.qtd += i.qtd; p.valor = Math.round((p.valor + i.qtd * i.preco) * 100) / 100 } }
  for (const o of orders) { (porDia[o.day] ||= {}).vendas = Math.round(((porDia[o.day].vendas || 0) + (ok.includes(o) ? o.total : 0)) * 100) / 100 }
  const serie = Array.from({ length: dias }, (_, i) => { const d = new Date(Date.now() - (dias - 1 - i) * 86400_000).toISOString().slice(0, 10); return { day: d, ...(porDia[d] || {}) } })
  return { dias, acessos: { impressoes: tot.impressao || 0, visitas: tot.visita || 0, contatos: (tot.whatsapp || 0) + (tot.instagram || 0) + (tot.link || 0) + (tot.mapa || 0), compartilhamentos: tot.compartilhar || 0, conversasAgente: tot.agente || 0, pedidos: tot.pedido || 0 },
    vendas: { pedidos: orders.length, concluidos: ok.length, cancelados: orders.filter((o) => ['cancelado', 'recusado'].includes(o.status)).length, faturamento: fat, ticket: ok.length ? Math.round((fat / ok.length) * 100) / 100 : 0, taxasEntrega: Math.round(ok.reduce((a, o) => a + (o.taxa || 0), 0) * 100) / 100, porPagamento: porPag, topProdutos: Object.entries(prod).sort((a, b) => b[1].valor - a[1].valor).slice(0, 5).map(([nome, v]) => ({ nome, ...v })) }, serie }
}
export async function reportGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return reportData(Number(b.id), Math.min(365, Math.max(1, Number(ctx.query.get('dias')) || 30))) }
export async function reportAiPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), x = J<any>(b.data, {}), dias = Math.min(365, Math.max(1, Number(ctx.body?.dias) || 30))
  const r = await reportData(Number(b.id), dias), f = await (await import('./modules.js')).fiscalState((ctx.user as any).id).catch(() => null)
  const { complete } = await import('../ai/provider.js')
  const m = await complete([{ role: 'system', content: 'Você é um analista de negócios que ajuda pequenos empreendedores brasileiros. Escreva em português, de forma clara e prática, com no máximo 12 linhas: resumo do período, o que entrou (faturamento, pedidos), destaques (produtos, forma de pagamento), alcance (impressões, visitas, contatos, conversão de visitas em pedidos) e 3 recomendações objetivas. Use SOMENTE os números fornecidos; não invente. Se houver dados do MEI, comente o uso do limite anual e lembre do DAS/declaração quando fizer sentido. Não dê conselho contábil definitivo.' },
    { role: 'user', content: JSON.stringify({ empresa: x.empresa, periodoDias: dias, ...r, serie: undefined, mei: f ? { faturamentoAno: f.faturamento, limite: f.limite, proximoDAS: f.proximo, valorDAS: f.das.total, declaracaoAte: f.dasn.prazo } : null }) }] as any)
  return { texto: String(m.content || '').trim() }
}
export async function reportMeiPost(ctx: Ctx) {
  const { u, b } = await ownBusiness(ctx), mes = /^\d{4}-\d{2}$/.test(String(ctx.body?.mes)) ? String(ctx.body.mes) : new Date().toISOString().slice(0, 7)
  const rows = await q('SELECT * FROM orders WHERE business_id = $1', [b.id])
  const valor = Math.round(rows.filter((o) => String(o.created_at).slice(0, 7) === mes).map((o) => ({ ...J<any>(o.data, {}), status: o.status, total: Number(o.total) })).filter((o) => o.status === 'concluido' || (o.pagamento === 'online' && o.pago && !['cancelado', 'recusado'].includes(o.status))).reduce((a, o) => a + o.total, 0) * 100) / 100
  const d = J<any>(b.data, {}); d.meiLancado = d.meiLancado || {}; const ja = Number(d.meiLancado[mes] || 0), diff = Math.round((valor - ja) * 100) / 100
  if (diff <= 0) return { ok: true, adicionado: 0, mes, message: 'O faturamento deste mês já está lançado no MEI.' }
  const { FISCAL_USER_DEFAULT } = await import('./modules.js')
  const fz: any = { ...FISCAL_USER_DEFAULT, ...(await getUM<any>(u.id, 'fiscal', {})) }; fz.receitas = { ...(fz.receitas || {}), [mes]: Math.round(((Number(fz.receitas?.[mes]) || 0) + diff) * 100) / 100 }
  await setUM(u.id, 'fiscal', fz); d.meiLancado[mes] = valor
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, adicionado: diff, mes, message: `R$ ${diff.toFixed(2).replace('.', ',')} lançados no faturamento do MEI (${mes.split('-').reverse().join('/')}).` }
}

/* ---------- agendamentos de serviços ---------- */
const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`
export function servicePrice(s: any) { return s.modoPreco === 'orcamento' ? 0 : s.modoPreco === 'hora' ? Math.round((Number(s.preco) || 0) * ((Number(s.duracao) || 60) / 60) * 100) / 100 : Number(s.preco) || 0 }
async function freeSlots(b: any, svc: any, date: string) {
  const x = J<any>(b.data, {}), dias = x.horarioCfg?.dias
  const dow = DIAS[new Date(date + 'T12:00:00').getDay()], d = dias ? dias[dow] : { ativo: true, abre: '08:00', fecha: '18:00' }
  if (!d || !d.ativo) return []
  const dur = Number(svc.duracao) || 30, ab = toMin(d.abre), fe = toMin(d.fecha) > ab ? toMin(d.fecha) : 24 * 60
  const busy = (await q("SELECT data FROM orders WHERE business_id = $1 AND status IN ('novo','aceito')", [b.id])).map((r) => J<any>(r.data, {})).filter((o) => o.tipo === 'agendamento' && o.data === date).map((o) => [toMin(o.hora), toMin(o.hora) + (Number(o.duracao) || 30)])
  const nowBR = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), today = nowBR.toISOString().slice(0, 10), nowMin = nowBR.getHours() * 60 + nowBR.getMinutes() + 30
  const out: string[] = []
  for (let t = ab; t + dur <= fe; t += Math.min(dur, 30)) { if (date === today && t < nowMin) continue; if (busy.some(([s, e]) => t < e && t + dur > s)) continue; out.push(hhmm(t)) }
  return out
}
export async function slotsGet(ctx: Ctx) {
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2', [Number(ctx.query.get('servico')), b!.id]); if (!p) fail(404, 'Serviço não encontrado.', 'not_found')
  const date = String(ctx.query.get('data') || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) fail(400, 'Data inválida.', 'invalid')
  return { horarios: await freeSlots(b, J<any>(p!.data, {}), date) }
}
export async function bookingPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [Number(ctx.params.id)]); if (!b) fail(404, 'Empresa indisponível.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode agendar na sua própria empresa.', 'invalid')
  const p = await one('SELECT * FROM products WHERE id = $1 AND business_id = $2 AND active = $3', [Number(ctx.body?.servico), b!.id, true]); if (!p) fail(400, 'Serviço indisponível.', 'invalid')
  const s = J<any>(p!.data, {}), date = String(ctx.body?.data || ''), hora = String(ctx.body?.hora || '')
  if (!(await freeSlots(b, s, date)).includes(hora)) fail(409, 'Esse horário acabou de ser ocupado. Escolha outro.', 'slot_taken')
  const x = J<any>(b!.data, {}), total = servicePrice(s)
  const data = { tipo: 'agendamento', servico: s.nome, servicoId: Number(p!.id), modoPreco: s.modoPreco, duracao: s.duracao, data: date, hora, obs: str(ctx.body?.obs, 300), cliente: str(ctx.body?.nome, 80) || u.name, telefone: str(ctx.body?.telefone, 30) || u.whatsapp, empresa: x.empresa, itens: [{ nome: s.nome, qtd: 1, preco: total, vars: [] }], pagamento: 'local', modo: 'agendamento', motivo: '' }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, 'novo', total, JSON.stringify(data), nowIso()])
  const o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  await hit(Number(b!.id), 'pedido', u.id, Number(b!.owner_id))
  await notify(Number(b!.owner_id), { type: 'order', title: `Novo agendamento #${o.id}: ${s.nome}`, body: `${data.cliente} · ${date.split('-').reverse().join('/')} às ${hora}`, link: '/x/sua-empresa', ref: `booking:${o.id}` })
  return { order: { id: Number(o.id), status: 'novo', total, ...data } }
}

/* ---------- agente vendedor: mostra catálogo, cria pedidos e agendamentos, gera Pix ---------- */
const AG_TOOLS = [
  { type: 'function', function: { name: 'mostrar_catalogo', description: 'Mostra ao cliente os produtos/serviços (com foto e preço) na tela. Use quando ele quiser ver o cardápio, o catálogo ou opções.', parameters: { type: 'object', properties: { categoria: { type: 'string' }, busca: { type: 'string' } } } } },
  { type: 'function', function: { name: 'mostrar_secao', description: 'Mostra na tela, dentro do chat, uma seção da empresa: mapa (localização e como chegar), horario, pagamento (formas de pagamento e entrega) ou carrinho.', parameters: { type: 'object', properties: { secao: { type: 'string', enum: ['mapa', 'horario', 'pagamento', 'carrinho'] } }, required: ['secao'] } } },
  { type: 'function', function: { name: 'criar_pedido', description: 'Cria o pedido do cliente depois que ele confirmou itens, forma de recebimento e pagamento. Gera Pix automático se ele escolher pix_online.', parameters: { type: 'object', properties: { itens: { type: 'array', items: { type: 'object', properties: { produto_id: { type: 'number' }, quantidade: { type: 'number' }, opcoes: { type: 'object', description: 'nome da variação → nome da opção escolhida' } }, required: ['produto_id'] } }, modo: { type: 'string', enum: ['retirada', 'entrega'] }, endereco: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string' }, pagamento: { type: 'string', enum: ['pix_online', 'pix', 'dinheiro', 'cartao'] }, observacao: { type: 'string' } }, required: ['itens', 'modo', 'nome', 'pagamento'] } } },
  { type: 'function', function: { name: 'horarios_livres', description: 'Lista horários livres de um serviço numa data (AAAA-MM-DD).', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' } }, required: ['servico_id', 'data'] } } },
  { type: 'function', function: { name: 'agendar_servico', description: 'Agenda um serviço depois que o cliente confirmou data, horário e nome. pagar_pix=true gera Pix quando o serviço tem valor.', parameters: { type: 'object', properties: { servico_id: { type: 'number' }, data: { type: 'string' }, hora: { type: 'string' }, nome: { type: 'string' }, telefone: { type: 'string' }, observacao: { type: 'string' }, pagar_pix: { type: 'boolean' } }, required: ['servico_id', 'data', 'hora', 'nome'] } } },
]
async function guestOrder(b: any, data: any, total: number, wantPix: boolean) {
  const key = randomBytes(8).toString('hex')
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b.id, b.owner_id, 'novo', total, JSON.stringify({ ...data, guest: true, guestKey: key, canal: 'agente' }), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 1', [b.id]))[0]
  let pix: any = null
  if (wantPix && total > 0 && J<any>(b.data, {}).mpTok) { try { await createOrderPix(b, o, '', total); o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!; const d = J<any>(o.data, {}); pix = { qr: d.payment.qr, qrImage: d.payment.qrImage, expiresAt: d.payment.expiresAt, valor: total, orderId: Number(o.id), key } } catch { pix = null } }
  await hit(Number(b.id), 'pedido', null)
  await notify(Number(b.owner_id), { type: 'order', title: `${data.tipo === 'agendamento' ? 'Novo agendamento' : 'Novo pedido'} #${o.id} pelo agente · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente}${data.telefone ? ' · ' + data.telefone : ''}${pix ? ' · Pix gerado' : ''}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  return { id: Number(o.id), key, pix }
}
export async function runAgentTool(b: any, name: string, a: any, out: any) {
  const x = J<any>(b.data, {}), prods = (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut)
  if (name === 'mostrar_catalogo') {
    const t = nrm(`${a.categoria || ''} ${a.busca || ''}`).trim()
    const list = prods.filter((p: any) => !t || nrm(`${p.nome} ${p.categoria} ${p.descricao}`).includes(t)).slice(0, 10)
    out.produtos = list.map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', foto: (p.fotos || [])[0] || null, categoria: p.categoria }))
    return { ok: true, mostrados: out.produtos.map((p: any) => `${p.nome} (id ${p.id})`) }
  }
  if (name === 'mostrar_secao') { out.secao = ['mapa', 'horario', 'pagamento', 'carrinho'].includes(a.secao) ? a.secao : 'mapa'; return { ok: true, mostrado: out.secao } }
  if (!openState(x).aberto && name !== 'horarios_livres') return { ok: false, erro: 'A empresa está fechada agora; não é possível concluir pedidos neste momento.' }
  if (name === 'criar_pedido') {
    const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
    const linhas: any[] = []
    for (const it of Array.isArray(a.itens) ? a.itens.slice(0, 30) : []) {
      const p: any = prods.find((y: any) => y.id === Number(it.produto_id)); if (!p || p.tipo === 'servico') return { ok: false, erro: `Produto ${it.produto_id} não existe no catálogo.` }
      const esc: Record<string, number> = {}
      for (const v of p.variacoes || []) { const want = nrm(String(it.opcoes?.[v.nome] || '')); const i = v.opcoes.findIndex((o: any) => nrm(o.nome) === want); esc[v.nome] = i >= 0 ? i : 0 }
      const qtd = Math.min(50, Math.max(1, Math.floor(Number(it.quantidade) || 1))), preco = unitPrice(p, esc)
      linhas.push({ pid: p.id, nome: p.nome, qtd, preco, vars: (p.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[esc[v.nome]].nome}`), obs: '' })
    }
    if (!linhas.length) return { ok: false, erro: 'O pedido está sem itens.' }
    const modo = a.modo === 'entrega' ? 'entrega' : 'retirada'
    if (modo === 'entrega' && !E.entrega) return { ok: false, erro: 'A loja não faz entrega; ofereça retirada.' }
    if (modo === 'entrega' && String(a.endereco || '').length < 6) return { ok: false, erro: 'Peça o endereço completo de entrega.' }
    if (modo === 'entrega' && E.modoTaxa === 'km') return { ok: false, erro: 'A taxa desta loja é por distância: oriente o cliente a finalizar pelo link da loja para calcular a entrega.' }
    const sub = Math.round(linhas.reduce((s2, l) => s2 + l.preco * l.qtd, 0) * 100) / 100
    if (E.minimo && sub < E.minimo) return { ok: false, erro: `Pedido mínimo de R$ ${E.minimo}.` }
    const pg = a.pagamento === 'pix_online' ? 'online' : a.pagamento
    if (!['online', 'pix', 'dinheiro', 'cartao'].includes(pg) || (pg === 'online' ? !(P.online && x.mpTok) : !P[pg])) return { ok: false, erro: `Forma de pagamento indisponível. Aceitas: ${[P.online && x.mpTok ? 'pix_online' : '', P.pix ? 'pix' : '', P.dinheiro ? 'dinheiro' : '', P.cartao ? 'cartao' : ''].filter(Boolean).join(', ')}.` }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0, total = Math.round((sub + taxa) * 100) / 100
    const r = await guestOrder(b, { itens: linhas, subtotal: sub, taxa, modo, endereco: modo === 'entrega' ? str(a.endereco, 200) : '', pagamento: pg, obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, motivo: '' }, total, pg === 'online')
    if (r.pix) out.pix = r.pix
    return { ok: true, pedido: r.id, total, pix_gerado: !!r.pix, mensagem: r.pix ? 'Pix gerado e mostrado na tela; o cliente pode pagar pelo QR Code ou copia e cola.' : 'Pedido enviado para a loja.' }
  }
  if (name === 'horarios_livres' || name === 'agendar_servico') {
    const sv: any = prods.find((y: any) => y.id === Number(a.servico_id) && y.tipo === 'servico'); if (!sv) return { ok: false, erro: 'Serviço não encontrado.' }
    const date = String(a.data || ''); if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, erro: 'Data no formato AAAA-MM-DD.' }
    const livres = await freeSlots(b, sv, date)
    if (name === 'horarios_livres') return { ok: true, livres: livres.slice(0, 24) }
    if (!livres.includes(String(a.hora))) return { ok: false, erro: 'Horário indisponível.', livres: livres.slice(0, 12) }
    if (!String(a.nome || '').trim()) return { ok: false, erro: 'Pergunte o nome do cliente.' }
    const total = servicePrice(sv)
    const r = await guestOrder(b, { tipo: 'agendamento', servico: sv.nome, servicoId: sv.id, modoPreco: sv.modoPreco, duracao: sv.duracao, data: date, hora: String(a.hora), obs: str(a.observacao, 300), cliente: str(a.nome, 80), telefone: str(a.telefone, 30), empresa: x.empresa, itens: [{ nome: sv.nome, qtd: 1, preco: total, vars: [] }], pagamento: a.pagar_pix ? 'online' : 'local', modo: 'agendamento', motivo: '' }, total, !!a.pagar_pix)
    if (r.pix) out.pix = r.pix
    return { ok: true, agendamento: r.id, total, pix_gerado: !!r.pix }
  }
  return { ok: false, erro: 'Ferramenta desconhecida.' }
}
export async function agentOrderGet(ctx: Ctx) {
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), Number(ctx.params.id)])
  const d = o ? J<any>(o.data, {}) : null
  if (!o || !d.guest || d.guestKey !== String(ctx.query.get('k') || '')) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown')
  return { status: o!.status, pago: st === 'approved' || !!d.pago }
}

/* ---------- página do agente: tudo dentro do chat (catálogo, mapa, horário, pagamento, pedido, agendamento, Pix) ---------- */
function agentLimit(ctx: Ctx, id: number, max = 20) {
  const ip = String(ctx.req.headers['x-forwarded-for'] || ctx.req.socket.remoteAddress || '').split(',')[0].trim(), key = `act:${id}:${ip}`, now = Date.now()
  const hits = (agentHits.get(key) || []).filter((t) => now - t < 60_000); if (hits.length >= max) fail(429, 'Muitas ações seguidas. Aguarde um minuto.', 'rate_limited'); hits.push(now); agentHits.set(key, hits)
}
export async function agentInfoGet(ctx: Ctx) {
  const { b, x } = await agentBiz(Number(ctx.params.id), ctx), st = openState(x), ps = await plans(), n = nivelOf(ps, b.plan_id)
  const prods = n >= 4 ? (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b.id, true])).map(productOut).map((p: any) => ({ id: p.id, nome: p.nome, preco: p.preco, descricao: p.descricao || '', categoria: p.categoria || 'Outros', foto: (p.fotos || [])[0] || null, variacoes: p.variacoes || [], tipo: p.tipo || 'produto', modoPreco: p.modoPreco || 'fixo', duracao: p.duracao || 0, tags: p.tags || [] })) : []
  const E: any = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, chavePix: '', cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  return { empresa: x.empresa, categoria: x.categoria, sobre: x.sobre || x.texto || '', endereco: x.endereco || '', lat: b.lat, lng: b.lng, aberto: st.aberto, situacao: st.texto, dias: x.horarioCfg?.dias || null, horario: x.horario || '',
    loja: n >= 4, produtos: prods, categorias: x.categorias || [], etiquetas: x.etiquetas || [], zap: x.zap || null, insta: x.insta || null,
    entrega: { retirada: E.retirada !== false, entrega: !!E.entrega && E.modoTaxa !== 'km', porKm: E.modoTaxa === 'km', taxa: Number(E.taxa) || 0, raio: E.raio, minimo: Number(E.minimo) || 0, tempo: E.tempo || '' },
    pagamento: { online: !!(P.online && x.mpTok), pix: !!P.pix, chavePix: P.chavePix || '', cartao: !!P.cartao, dinheiro: !!P.dinheiro } }
}
export async function agentOrderPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'criar_pedido', ctx.body || {}, out)
  if (!r.ok) fail(400, r.erro || 'Não foi possível criar o pedido.', 'invalid')
  return { ...r, pix: out.pix || null }
}
export async function agentSlotsGet(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 40)
  const r: any = await runAgentTool(b, 'horarios_livres', { servico_id: Number(ctx.query.get('servico')), data: String(ctx.query.get('data') || '') }, {})
  if (!r.ok) fail(400, r.erro, 'invalid'); return { horarios: r.livres }
}
export async function agentBookingPost(ctx: Ctx) {
  const id = Number(ctx.params.id), { b } = await agentBiz(id, ctx); agentLimit(ctx, id, 8)
  const out: any = {}, r: any = await runAgentTool(b, 'agendar_servico', ctx.body || {}, out)
  if (!r.ok) fail(400, r.erro || 'Não foi possível agendar.', 'invalid')
  return { ...r, pix: out.pix || null }
}
