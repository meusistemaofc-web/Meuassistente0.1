// Empresas parceiras: busca por ramo e distância (com permissão de localização), página da empresa,
// loja com produtos/variações e pedidos (plano Loja completa) que chegam em Sua empresa.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J, nowIso } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { config } from '../config.js'
import { notify } from '../lib/notify.js'
import { getUM, setUM, requireModule, modules } from '../lib/usermod.js'
import { PLANS_DEFAULT, SEARCH_DEFAULT } from '../lib/panel-defaults.js'

const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
const STOP = new Set(['perto', 'proximo', 'proxima', 'quero', 'procuro', 'onde', 'tem', 'uma', 'um', 'mim', 'aqui', 'minha', 'meu', 'de', 'da', 'do', 'com', 'para', 'tem', 'algum', 'alguma', 'uns', 'umas', 'os', 'as', 'no', 'na'])
export function distKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371, t = (x: number) => (x * Math.PI) / 180, dl = t(b.lat - a.lat), dn = t(b.lng - a.lng)
  const h = Math.sin(dl / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dn / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(h))
}
async function plans(): Promise<any[]> { const p = await getConfig<any[]>('ad_plans', []); return p.length ? p : PLANS_DEFAULT }
const nivelOf = (ps: any[], id: string) => (ps.find((p) => p.id === id) || {}).nivel || 1
async function activeRows() { return q("SELECT * FROM businesses WHERE status = 'ativo' AND (expires_at IS NULL OR expires_at > $1)", [nowIso()]) }
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab']
export function openState(x: any): { aberto: boolean; texto: string } {
  const h = x.horarioCfg
  if (!h) return { aberto: true, texto: x.horario || '' }
  if (h.modo === 'aberto') return { aberto: true, texto: 'Aberto agora' }
  if (h.modo === 'fechado') return { aberto: false, texto: 'Fechado no momento' }
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }))
  const d = h.dias?.[DIAS[now.getDay()]], hm = now.getHours() * 60 + now.getMinutes()
  const toMin = (t: string) => { const [a, b] = String(t || '0:0').split(':').map(Number); return a * 60 + (b || 0) }
  if (!d || !d.ativo) return { aberto: false, texto: 'Fechado hoje' }
  const ab = toMin(d.abre), fe = toMin(d.fecha), dentro = fe > ab ? hm >= ab && hm < fe : hm >= ab || hm < fe
  return { aberto: dentro, texto: dentro ? `Aberto até ${d.fecha}` : `Fechado · abre ${hm < ab ? 'hoje' : ''} às ${d.abre}`.replace('  ', ' ') }
}
function card(b: any, n: number, d: number | null) {
  const x = J<any>(b.data, {}), st = openState(x)
  return { id: Number(b.id), empresa: x.empresa, categoria: x.categoria, titulo: x.titulo, texto: x.texto, logo: x.logo || null, nivel: n, distancia: d,
    zap: n >= 2 ? x.zap || null : null, insta: n >= 2 ? x.insta || null : null, link: x.link || null, temPagina: n >= 3, temLoja: n >= 4, capa: x.capa || null, aberto: st.aberto, situacao: st.texto }
}
export function matches(q0: string, b: any) {
  const words = norm(q0).split(' ').filter((w) => w.length >= 3 && !STOP.has(w))
  if (!words.length) return true
  const x = J<any>(b.data, {}), kw = norm(`${x.categoria} ${x.tags} ${x.empresa}`).split(' ')
  const forms = (w: string) => [w, w.replace(/s$/, ''), w.replace(/(ria|rias)$/, '')]
  return words.some((w) => forms(w).some((f) => f.length >= 3 && kw.some((k) => k === f || k.startsWith(f) || (f.startsWith(k) && k.length >= 4))))
}
export async function searchBusinesses(text: string, loc: { lat: number; lng: number; raio?: number | null } | null) {
  const ps = await plans(), admMax = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15, max = Math.min(admMax, loc?.raio || admMax)
  const out: any[] = []
  for (const b of await activeRows()) {
    if (!matches(text, b)) continue
    const raio = Math.min(max, Number(J<any>(b.data, {}).raio) || 5)
    const d = loc && b.lat != null ? distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) : null
    if (loc && (d === null || d > raio)) continue
    out.push(card(b, nivelOf(ps, b.plan_id), d === null ? null : Math.round(d * 10) / 10))
  }
  return out.sort((a, b) => (a.distancia ?? 1e9) - (b.distancia ?? 1e9)).slice(0, 30)
}
const locOk = (lat: number, lng: number) => isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0)

export async function myLocationPut(ctx: Ctx) {
  const u = requireUser(ctx), lat = Number(ctx.body?.lat), lng = Number(ctx.body?.lng)
  if (ctx.body?.clear) { await setUM(u.id, 'location', null); return { ok: true } }
  const old = await getUM<any>(u.id, 'location', null)
  const raio = Number(ctx.body?.raio) >= 1 && Number(ctx.body?.raio) <= 100 ? Number(ctx.body.raio) : old?.raio || null
  if (ctx.body?.raio && !ctx.body?.endereco && !isFinite(lat) && old) { await setUM(u.id, 'location', { ...old, raio }); return { ok: true, location: { ...old, raio } } }
  if (typeof ctx.body?.endereco === 'string' && ctx.body.endereco.trim().length >= 3) {
    const r = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=' + encodeURIComponent(ctx.body.endereco.trim()), { headers: { 'User-Agent': 'MeuAssistente/1.0 (contato pelo app)', 'Accept-Language': 'pt-BR' } }).catch(() => null)
    const j: any = r && r.ok ? await r.json().catch(() => []) : []
    if (!j[0]) fail(400, 'Não encontrei esse endereço. Tente com bairro e cidade.', 'invalid')
    const loc = { lat: Number(j[0].lat), lng: Number(j[0].lon), at: nowIso(), raio, label: String(j[0].display_name || '').split(',').slice(0, 3).join(','), manual: true }
    await setUM(u.id, 'location', loc); return { ok: true, location: loc }
  }
  if (!locOk(lat, lng)) fail(400, 'Localização inválida.', 'invalid')
  const loc = { lat, lng, at: nowIso(), raio, label: 'Localização atual', manual: false }
  await setUM(u.id, 'location', loc); return { ok: true, location: loc }
}
export async function userLocation(userId: number) {
  const l = await getUM<any>(userId, 'location', null)
  return l && (l.manual || Date.now() - Date.parse(l.at) < 7 * 86400_000) ? { lat: l.lat, lng: l.lng, raio: l.raio || null, label: l.label || '' } : null
}
export async function businessSearchGet(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const lat = Number(ctx.query.get('lat')), lng = Number(ctx.query.get('lng'))
  const loc = locOk(lat, lng) ? { lat, lng } : await userLocation(u.id)
  if (!loc) return { needLocation: true, items: [] }
  const adm = (await getConfig<any>('search', SEARCH_DEFAULT)).raio || 15
  return { needLocation: false, location: { label: (loc as any).label || 'Localização atual', raio: Math.min(adm, (loc as any).raio || adm), max: adm }, items: await searchBusinesses(str(ctx.query.get('q'), 80), loc as any) }
}

/* ---------- página pública e produtos ---------- */
function productOut(p: any) { const d = J<any>(p.data, {}); return { id: Number(p.id), active: !!(p.active === true || p.active === 1 || p.active === 't'), ...d } }
export function unitPrice(prod: any, escolhas: Record<string, number>) {
  let base = Number(prod.preco) || 0, extra = 0
  for (const v of prod.variacoes || []) {
    const o = v.opcoes?.[Number(escolhas?.[v.nome] ?? 0)]
    if (!o) fail(400, `Escolha uma opção de ${v.nome}.`, 'invalid')
    const pr = Number(o.preco) || 0
    if (pr >= (Number(prod.preco) || 0) * 0.5 && pr > 0) base = pr; else extra += pr
  }
  return Math.round((base + extra) * 100) / 100
}
export async function businessGet(ctx: Ctx) {
  const u = ctx.user || null; await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  const ps = await plans()
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) fail(404, 'O anúncio desta empresa não está ativo.', 'not_found')
  const n = nivelOf(ps, b!.plan_id); if (n < 3) fail(404, 'Esta empresa não tem página própria.', 'not_found')
  const x = J<any>(b!.data, {}), loc = u ? await userLocation(u.id) : null
  const loja = n >= 4 && (await modules()).catalogo !== false
  const prods = loja ? (await q('SELECT * FROM products WHERE business_id = $1 AND active = $2 ORDER BY id', [b!.id, true])).map(productOut) : []
  return { ...card(b, n, loc && b!.lat != null ? Math.round(distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) * 10) / 10 : null),
    endereco: x.endereco, horario: x.horario, sobre: x.sobre, capa: x.capa || null, lat: b!.lat, lng: b!.lng, loja, produtos: prods,
    entrega: loja ? { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, tempo: '', ...(x.entrega || {}) } : null,
    pagamento: loja ? (() => { const pg = { pix: true, chavePix: '', cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }; pg.online = !!(pg.online && x.mpTok); return pg })() : null }
}
async function ownBusiness(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [Number(ctx.params.id), u.id])
  if (!b) fail(404, 'Empresa não encontrada.', 'not_found')
  return { u, b: b! }
}
export async function productsGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { items: (await q('SELECT * FROM products WHERE business_id = $1 ORDER BY id', [b.id])).map(productOut) } }
export async function productsPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  if (nivelOf(await plans(), b.plan_id) < 4) fail(403, 'Produtos fazem parte do plano Loja completa.', 'forbidden')
  const it = ctx.body || {}
  if (it.action === 'delete') { await q('DELETE FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); return productsGet(ctx) }
  if (it.action === 'toggle') { const p = await one('SELECT active FROM products WHERE id = $1 AND business_id = $2', [Number(it.id), b.id]); if (p) await q('UPDATE products SET active = $1 WHERE id = $2', [!(p.active === true || p.active === 1), Number(it.id)]); return productsGet(ctx) }
  const nome = str(it.nome, 80), preco = Number(it.preco)
  if (!nome || !(preco >= 0 && preco < 1e6)) fail(400, 'Preencha o nome e um preço válido.', 'invalid')
  const fotos = (Array.isArray(it.fotos) ? it.fotos : []).filter((f: any) => typeof f === 'string' && f.startsWith('data:image/') && f.length < 450_000).slice(0, 2)
  if (!fotos.length) fail(400, 'Adicione pelo menos uma foto do produto.', 'invalid')
  const variacoes = (Array.isArray(it.variacoes) ? it.variacoes : []).slice(0, 6).map((v: any) => ({ nome: str(v.nome, 40), opcoes: (Array.isArray(v.opcoes) ? v.opcoes : []).slice(0, 12).map((o: any) => ({ nome: str(o.nome, 40), preco: Math.max(0, Number(o.preco) || 0) })).filter((o: any) => o.nome) })).filter((v: any) => v.nome && v.opcoes.length)
  const data = JSON.stringify({ nome, preco: Math.round(preco * 100) / 100, descricao: str(it.descricao, 600), categoria: str(it.categoria, 40) || 'Outros', fotos, variacoes })
  if (it.id) await q('UPDATE products SET data = $1, updated_at = $2 WHERE id = $3 AND business_id = $4', [data, nowIso(), Number(it.id), b.id])
  else await q('INSERT INTO products (business_id, data, active, created_at, updated_at) VALUES ($1,$2,$3,$4,$4)', [b.id, data, true, nowIso()])
  return productsGet(ctx)
}

/* ---------- pedidos ---------- */
const NEXT: Record<string, string[]> = { novo: ['aceito', 'recusado'], aceito: ['preparo', 'cancelado'], preparo: ['saiu', 'pronto', 'cancelado'], saiu: ['concluido', 'cancelado'], pronto: ['concluido', 'cancelado'] }
const MSG: Record<string, string> = { aceito: 'foi aceito', preparo: 'está em preparo', saiu: 'saiu para entrega', pronto: 'está pronto para retirar', concluido: 'foi concluído', recusado: 'foi recusado', cancelado: 'foi cancelado' }
const orderOut = (o: any) => ({ id: Number(o.id), businessId: Number(o.business_id), status: o.status, total: Number(o.total), ...J<any>(o.data, {}), createdAt: o.created_at, updatedAt: o.updated_at })
export async function orderPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('empresas')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.params.id)])
  if (!b || b.status !== 'ativo' || nivelOf(await plans(), b.plan_id) < 4) fail(404, 'Esta loja não está recebendo pedidos.', 'not_found')
  if (Number(b!.owner_id) === u.id) fail(400, 'Você não pode fazer pedido na sua própria loja.', 'invalid')
  if (!openState(J<any>(b!.data, {})).aberto) fail(400, 'A loja está fechada agora. Veja o horário de funcionamento.', 'closed')
  const x = J<any>(b!.data, {}), E = { retirada: true, entrega: false, taxa: 0, raio: 3, minimo: 0, ...(x.entrega || {}) }, P: any = { pix: true, cartao: false, dinheiro: true, online: false, ...(x.pagamento || {}) }
  P.online = !!(P.online && x.mpTok)
  const body = ctx.body || {}, itens: any[] = Array.isArray(body.itens) ? body.itens.slice(0, 50) : []
  if (!itens.length) fail(400, 'Seu pedido está vazio.', 'invalid')
  const prods = new Map((await q('SELECT * FROM products WHERE business_id = $1 AND active = $2', [b!.id, true])).map((p) => [Number(p.id), J<any>(p.data, {})]))
  const linhas = itens.map((it) => {
    const p = prods.get(Number(it.pid)); if (!p) fail(400, 'Um dos produtos não está mais disponível.', 'invalid')
    const qtd = Math.min(99, Math.max(1, Math.floor(Number(it.qtd) || 1))), preco = unitPrice(p, it.escolhas || {})
    const vars = (p!.variacoes || []).map((v: any) => `${v.nome}: ${v.opcoes[Number(it.escolhas?.[v.nome] ?? 0)].nome}`)
    return { pid: Number(it.pid), nome: p!.nome, vars, obs: str(it.obs, 140), qtd, preco }
  })
  const sub = Math.round(linhas.reduce((a, l) => a + l.preco * l.qtd, 0) * 100) / 100
  const modo = body.modo === 'entrega' ? 'entrega' : 'retirada'
  if (modo === 'entrega' && !E.entrega) fail(400, 'Esta loja não faz entregas.', 'invalid')
  if (modo === 'retirada' && !E.retirada) fail(400, 'Esta loja não tem retirada no local.', 'invalid')
  if (E.minimo && sub < E.minimo) fail(400, `Pedido mínimo: R$ ${Number(E.minimo).toFixed(2).replace('.', ',')}.`, 'invalid')
  const endereco = modo === 'entrega' ? str(body.endereco, 200) : ''
  if (modo === 'entrega' && endereco.length < 6) fail(400, 'Informe o endereço de entrega.', 'invalid')
  if (modo === 'entrega' && b!.lat != null) { const loc = await userLocation(u.id); if (loc && distKm(loc, { lat: Number(b!.lat), lng: Number(b!.lng) }) > Number(E.raio || 3)) fail(400, 'Seu endereço está fora da área de entrega desta loja.', 'invalid') }
  const pag = ['pix', 'cartao', 'dinheiro', 'online'].includes(body.pagamento) && P[body.pagamento] ? body.pagamento : null
  if (!pag) fail(400, 'Escolha uma forma de pagamento aceita pela loja.', 'invalid')
  const taxa = modo === 'entrega' ? Number(E.taxa) || 0 : 0, total = Math.round((sub + taxa) * 100) / 100
  const data = { itens: linhas, subtotal: sub, taxa, modo, endereco, pagamento: pag, troco: pag === 'dinheiro' ? str(body.troco, 20) : '', cliente: str(body.nome, 80) || u.name, telefone: str(body.telefone, 30) || u.whatsapp, empresa: x.empresa, motivo: '' }
  await q('INSERT INTO orders (business_id, customer_id, status, total, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6)', [b!.id, u.id, 'novo', total, JSON.stringify(data), nowIso()])
  let o = (await q('SELECT * FROM orders WHERE business_id = $1 AND customer_id = $2 ORDER BY id DESC LIMIT 1', [b!.id, u.id]))[0]
  if (pag === 'online') { // Pix automático pelo Mercado Pago da própria loja
    try { await createOrderPix(b, o, u.email, total) }
    catch (e: any) { await q("UPDATE orders SET status = 'cancelado', updated_at = $1 WHERE id = $2", [nowIso(), o.id]); fail(502, 'Não foi possível gerar o Pix da loja agora. Escolha outra forma de pagamento.', 'mp_error') }
    o = (await one('SELECT * FROM orders WHERE id = $1', [o.id]))!
  }
  if (pag !== 'online') await notify(Number(b!.owner_id), { type: 'order', title: `Novo pedido #${o.id} · R$ ${total.toFixed(2).replace('.', ',')}`, body: `${data.cliente} · ${modo === 'entrega' ? 'entrega' : 'retirada'}`, link: '/x/sua-empresa', ref: `order-new:${o.id}` })
  return { order: orderOut(o) }
}
export async function myOrdersGet(ctx: Ctx) { const u = requireUser(ctx); return { items: (await q('SELECT * FROM orders WHERE customer_id = $1 ORDER BY id DESC LIMIT 50', [u.id])).map(orderOut) } }
export async function businessOrdersGet(ctx: Ctx) { const { b } = await ownBusiness(ctx); return { items: (await q('SELECT * FROM orders WHERE business_id = $1 ORDER BY id DESC LIMIT 200', [b.id])).map(orderOut) } }
export async function businessOrderPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(ctx.params.oid), b.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const to = String(ctx.body?.status || ''), motivo = str(ctx.body?.motivo, 200)
  if (!(NEXT[o!.status] || []).includes(to)) fail(400, 'Mudança de situação inválida.', 'invalid')
  if ((to === 'recusado' || to === 'cancelado') && !motivo) fail(400, 'Informe o motivo.', 'invalid')
  const d = { ...J<any>(o!.data, {}), motivo }
  await q('UPDATE orders SET status = $1, data = $2, updated_at = $3 WHERE id = $4', [to, JSON.stringify(d), nowIso(), o!.id])
  await notify(Number(o!.customer_id), { type: 'order', title: `Pedido #${o!.id} ${MSG[to]}`, body: `${d.empresa}${motivo ? ' · ' + motivo : ''}`, link: '/x/pedidos', ref: `order:${o!.id}:${to}` })
  return businessOrdersGet(ctx)
}

/* ---------- Mercado Pago da loja (pagamento automático dos pedidos) ---------- */
const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
async function storeToken(b: any) { return unseal(J<any>(b.data, {}).mpTok || '') }
async function createOrderPix(b: any, o: any, email: string, total: number) {
  const tok = await storeToken(b); if (!tok) throw new Error('sem token')
  const x = J<any>(b.data, {})
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `order-${o.id}` },
    body: JSON.stringify({ transaction_amount: total, description: `Pedido #${o.id} · ${x.empresa}`, payment_method_id: 'pix', payer: { email }, external_reference: `order:${o.id}`, notification_url: `${config.publicUrl}/api/mercadopago/webhook?store=${b.id}` }) })
  const p: any = await r.json().catch(() => null)
  if (!r.ok || !p?.id) { console.error('[mp-loja] Pix:', r.status, JSON.stringify(p)?.slice(0, 200)); throw new Error('mp') }
  const td = p.point_of_interaction?.transaction_data || {}
  const d = { ...J<any>(o.data, {}), payment: { id: String(p.id), status: p.status, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '' }, pago: p.status === 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
}
async function markOrderPaid(o: any) {
  const d = J<any>(o.data, {}); if (d.pago) return
  d.pago = true; d.payment = { ...(d.payment || {}), status: 'approved' }
  await q('UPDATE orders SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), o.id])
  const b = await one('SELECT owner_id FROM businesses WHERE id = $1', [o.business_id])
  if (b) await notify(Number(b.owner_id), { type: 'order', title: `Novo pedido #${o.id} · PAGO · R$ ${Number(o.total).toFixed(2).replace('.', ',')}`, body: `${d.cliente} · ${d.modo === 'entrega' ? 'entrega' : 'retirada'} · Pix confirmado`, link: '/x/sua-empresa', ref: `order-paid:${o.id}` })
  await notify(Number(o.customer_id), { type: 'order', title: `Pagamento do pedido #${o.id} confirmado`, body: d.empresa, link: '/x/pedidos', ref: `order-paid-c:${o.id}` })
}
async function checkOrderPayment(o: any) {
  const d = J<any>(o.data, {}); if (d.pago || !d.payment?.id) return d.pago ? 'approved' : 'none'
  const b = await one('SELECT * FROM businesses WHERE id = $1', [o.business_id]); if (!b) return 'none'
  const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(d.payment.id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
  const p: any = await r.json().catch(() => ({}))
  if (r.ok && p.status === 'approved' && String(p.external_reference) === `order:${o.id}`) { await markOrderPaid(o); return 'approved' }
  return p.status || 'unknown'
}
export async function orderPayGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const o = await one('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [Number(ctx.params.id), u.id])
  if (!o) fail(404, 'Pedido não encontrado.', 'not_found')
  const st = await checkOrderPayment(o).catch(() => 'unknown'), d = J<any>(o!.data, {})
  return { status: st, payment: d.payment ? { qr: d.payment.qr, qrImage: d.payment.qrImage } : null, total: Number(o!.total) }
}
export async function storeWebhook(ctx: Ctx) {
  const id = String(ctx.query.get('data.id') || ctx.body?.data?.id || ctx.query.get('id') || '')
  const b = await one('SELECT * FROM businesses WHERE id = $1', [Number(ctx.query.get('store'))])
  if (!id || !b) return { ok: true }
  try {
    const r = await fetch(`${MPB()}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${await storeToken(b)}` } })
    const p: any = await r.json()
    const oid = String(p.external_reference || '').replace('order:', '')
    const o = await one('SELECT * FROM orders WHERE id = $1 AND business_id = $2', [Number(oid), b.id])
    if (o && p.status === 'approved') await markOrderPaid(o)
  } catch (e: any) { console.error('[mp-loja] webhook:', e?.message) }
  return { ok: true }
}
export async function storeMpPost(ctx: Ctx) {
  const { b } = await ownBusiness(ctx), body = ctx.body || {}, d = J<any>(b.data, {})
  if (body.action === 'test') {
    const tok = await storeToken(b); if (!tok) return { ok: false, message: 'Salve o Access Token da sua conta Mercado Pago antes de testar.' }
    try { const r = await fetch(`${MPB()}/users/me`, { headers: { Authorization: `Bearer ${tok}` } }); const j: any = await r.json().catch(() => ({}))
      if (!r.ok) return { ok: false, message: r.status === 401 || r.status === 403 ? 'O Mercado Pago recusou o Access Token.' : 'Erro ' + r.status + ' no Mercado Pago.' }
      return { ok: true, message: `Conectado à conta ${j.nickname || j.email || j.id}${tok.startsWith('TEST-') ? ' (modo teste)' : ''}. Pronto para receber.` }
    } catch (e: any) { return { ok: false, message: 'Sem conexão com o Mercado Pago.' } }
  }
  if (body.action === 'remove') { delete d.mpTok; d.pagamento = { ...(d.pagamento || {}), online: false } }
  else {
    const tok = String(body.tok || '').trim()
    if (!/^(APP_USR|TEST)-[\w-]{10,}$/.test(tok)) fail(400, 'O Access Token começa com APP_USR- (produção) ou TEST- (teste).', 'invalid')
    d.mpTok = await seal(tok); d.pagamento = { ...(d.pagamento || {}), online: true }
  }
  await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
  return { ok: true, mpLoja: !!d.mpTok, mpMasked: d.mpTok ? maskSecret(await unseal(d.mpTok)) : '' }
}

/** Cartões das empresas para o chat (imagem, descrição e botões conforme o plano). */
export async function businessCardsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const ids = String(ctx.query.get('ids') || '').split(',').map(Number).filter((n) => n > 0).slice(0, 12)
  if (!ids.length) return { items: [] }
  const ps = await plans(), loc = await userLocation(u.id), out: any[] = []
  for (const id of ids) {
    const b = await one("SELECT * FROM businesses WHERE id = $1 AND status = 'ativo'", [id])
    if (!b || (b.expires_at && Date.parse(b.expires_at) < Date.now())) continue
    out.push(card(b, nivelOf(ps, b.plan_id), loc && b.lat != null ? Math.round(distKm(loc, { lat: Number(b.lat), lng: Number(b.lng) }) * 10) / 10 : null))
  }
  return { items: out }
}
