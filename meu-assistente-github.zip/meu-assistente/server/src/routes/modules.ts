// Módulos novos do sistema real: Mercado (cotações, gráficos, alertas) e Impostos/DAS do MEI.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig } from '../lib/settings.js'
import { FISCAL_DEFAULT } from '../lib/panel-defaults.js'
import { getUM, setUM, requireModule } from '../lib/usermod.js'
import { quote, CRYPTO, marketProviders } from './market.js'

/* ---------- Mercado ---------- */
export const WATCH = { cripto: ['BTC', 'ETH', 'SOL', 'XRP', 'BNB', 'ADA', 'DOGE', 'LTC', 'XLM', 'USDT'], bolsa: ['IBOV', 'PETR4', 'VALE3', 'ITUB4', 'BBDC4', 'BBAS3', 'ABEV3', 'B3SA3', 'MGLU3', 'WEGE3'] }
export const NOMES: Record<string, string> = { IBOV: 'Ibovespa', PETR4: 'Petrobras PN', VALE3: 'Vale ON', ITUB4: 'Itaú Unibanco PN', BBDC4: 'Bradesco PN', BBAS3: 'Banco do Brasil ON', ABEV3: 'Ambev ON', B3SA3: 'B3 ON', MGLU3: 'Magazine Luiza ON', WEGE3: 'WEG ON' }
const isStock = (s: string) => s === 'IBOV' || /^[A-Z]{4}(3|4|5|6|11)$/.test(s)
const seriesCache = new Map<string, { at: number; v: any }>()

async function getJson(url: string) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 9000)
  try { const r = await fetch(url, { signal: ctl.signal, headers: { 'User-Agent': 'MeuAssistente/1.0', Accept: 'application/json' } }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json() }
  finally { clearTimeout(t) }
}
export async function series(symRaw: string, range: string) {
  const sym = symRaw.toUpperCase()
  if (!['24h', '7d', '30d', '90d'].includes(range)) fail(400, 'Período inválido.', 'invalid')
  const key = sym + ':' + range, hit = seriesCache.get(key)
  if (hit && Date.now() - hit.at < (range === '24h' ? 5 : 15) * 60_000) return hit.v
  const days = { '24h': 1, '7d': 7, '30d': 30, '90d': 90 }[range]!
  const tries: { nome: string; run: () => Promise<{ t: number; v: number }[]> }[] = []
  if (CRYPTO[sym]) {
    tries.push({ nome: 'CoinGecko', run: async () => (await getJson(`https://api.coingecko.com/api/v3/coins/${CRYPTO[sym].gecko}/market_chart?vs_currency=brl&days=${days}`)).prices.map((p: number[]) => ({ t: p[0], v: p[1] })) })
    const iv = { '24h': ['30m', 48], '7d': ['4h', 42], '30d': ['12h', 60], '90d': ['1d', 90] }[range] as [string, number]
    tries.push({ nome: 'Binance', run: async () => (await getJson(`https://api.binance.com/api/v3/klines?symbol=${sym}BRL&interval=${iv[0]}&limit=${iv[1]}`)).map((k: any[]) => ({ t: Number(k[0]), v: Number(k[4]) })) })
  } else if (isStock(sym)) {
    const y = sym === 'IBOV' ? '%5EBVSP' : sym + '.SA'
    const yr = { '24h': ['1d', '5m'], '7d': ['5d', '30m'], '30d': ['1mo', '1d'], '90d': ['3mo', '1d'] }[range] as [string, string]
    tries.push({ nome: 'Yahoo Finance', run: async () => { const r = (await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${y}?range=${yr[0]}&interval=${yr[1]}`)).chart.result[0]; return r.timestamp.map((t: number, i: number) => ({ t: t * 1000, v: r.indicators.quote[0].close[i] })).filter((p: any) => p.v != null) } })
  } else fail(400, 'Ativo não reconhecido.', 'invalid')
  const provs = await marketProviders()
  for (const tr of tries) {
    const p = provs.find((x) => x.nome.startsWith(tr.nome.split(' ')[0]))
    if (p && !p.ativo) continue
    try { const pts = await tr.run(); if (pts.length > 1) { const v = { symbol: sym, range, source: tr.nome, points: pts }; seriesCache.set(key, { at: Date.now(), v }); return v } } catch { /* próxima */ }
  }
  fail(502, 'Não consegui buscar o gráfico agora.', 'market_unavailable')
}
export async function marketSeriesGet(ctx: Ctx) { requireUser(ctx); await requireModule('mercado'); return series(str(ctx.query.get('s'), 12), str(ctx.query.get('range'), 4) || '24h') }
export async function marketSummaryGet(ctx: Ctx) {
  requireUser(ctx); await requireModule('mercado')
  const cat = ctx.query.get('cat') === 'bolsa' ? 'bolsa' : 'cripto'
  const items = await Promise.all(WATCH[cat].map(async (s) => { try { const q = await quote(s); return { ...q, nome: NOMES[s] || q.nome } } catch { return { symbol: s, nome: NOMES[s] || CRYPTO[s]?.nome || s, price: null, change24h: null, source: null } } }))
  return { cat, items }
}
interface Alert { id: string; symbol: string; cond: 'acima' | 'abaixo'; value: number; createdAt: string; firedAt: string | null }
export async function marketAlertsGet(ctx: Ctx) { const u = requireUser(ctx); await requireModule('mercado'); return { alerts: await getUM<Alert[]>(u.id, 'market_alerts', []) } }
export async function marketAlertsPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('mercado')
  const b = ctx.body || {}
  let list = await getUM<Alert[]>(u.id, 'market_alerts', [])
  if (b.action === 'delete') list = list.filter((a) => a.id !== b.id)
  else {
    const symbol = str(b.symbol, 12).toUpperCase(), value = Number(b.value)
    if (!CRYPTO[symbol] && !isStock(symbol)) fail(400, 'Ativo não reconhecido.', 'invalid')
    if (!(value > 0 && value < 1e9)) fail(400, 'Informe um valor válido.', 'invalid')
    if (list.filter((a) => !a.firedAt).length >= 20) fail(400, 'Limite de 20 alertas ativos.', 'invalid')
    list.unshift({ id: Math.random().toString(36).slice(2, 10), symbol, cond: b.cond === 'abaixo' ? 'abaixo' : 'acima', value, createdAt: new Date().toISOString(), firedAt: null })
  }
  await setUM(u.id, 'market_alerts', list)
  return { alerts: list }
}

/* ---------- Impostos e DAS (MEI) ---------- */
export interface Fiscal { atividade: string; abertura: string; consent: boolean; avisos: { das: boolean; dias: number; dasn: boolean; irpf: boolean }; receitas: Record<string, number>; pagos: Record<string, boolean>; init?: boolean }
export const FISCAL_USER_DEFAULT: Fiscal = { atividade: 'comercio', abertura: '', consent: false, avisos: { das: true, dias: 3, dasn: true, irpf: true }, receitas: {}, pagos: {} }
const ym = (y: number, m: number) => `${y}-${String(m + 1).padStart(2, '0')}`
const MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
export function dasValor(atividade: string, sm: number) {
  const inss = Math.round(sm * (atividade === 'caminhoneiro' ? 0.12 : 0.05) * 100) / 100
  const icms = ['comercio', 'ambos', 'caminhoneiro'].includes(atividade) ? 1 : 0
  const iss = ['servicos', 'ambos'].includes(atividade) ? 5 : 0
  return { inss, icms, iss, total: Math.round((inss + icms + iss) * 100) / 100 }
}
export function competencias(f: Fiscal, now = new Date()) {
  const y = now.getFullYear(), out: { k: string; nome: string; venc: string }[] = []
  const ini = f.abertura && f.abertura.startsWith(String(y)) ? parseInt(f.abertura.slice(5), 10) - 1 : 0
  for (let m = ini; m <= now.getMonth(); m++) out.push({ k: ym(y, m), nome: `${MES[m]}/${y}`, venc: new Date(Date.UTC(y, m + 1, 20)).toISOString().slice(0, 10) })
  return out
}
export async function fiscalState(userId: number) {
  const params = { ...FISCAL_DEFAULT, ...(await getConfig('fiscal', {})) }
  const f: Fiscal = { ...FISCAL_USER_DEFAULT, ...(await getUM<Partial<Fiscal>>(userId, 'fiscal', {})) } as Fiscal
  f.avisos = { ...FISCAL_USER_DEFAULT.avisos, ...(f.avisos || {}) }
  const today = new Date().toISOString().slice(0, 10)
  if (!f.init) { for (const c of competencias(f)) if (c.venc < today) f.pagos[c.k] = true; f.init = true; await setUM(userId, 'fiscal', f) }
  const das = dasValor(f.atividade, params.sm)
  const comps = competencias(f).map((c) => ({ ...c, pago: !!f.pagos[c.k], atrasado: !f.pagos[c.k] && c.venc < today }))
  const y = new Date().getFullYear()
  const fat = Object.entries(f.receitas).filter(([k]) => k.startsWith(String(y))).reduce((a, [, v]) => a + Number(v || 0), 0)
  const limite = f.abertura && f.abertura.startsWith(String(y)) ? (params.limite / 12) * (12 - parseInt(f.abertura.slice(5), 10) + 1) : params.limite
  const dasnAno = new Date() > new Date(Date.UTC(y, 4, 31, 23)) ? y + 1 : y
  return { perfil: f, params, das, competencias: comps, proximo: comps.find((c) => !c.pago) || null, faturamento: fat, limite, usoLimite: limite ? fat / limite : 0, dasn: { prazo: `${dasnAno}-05-31`, anoBase: dasnAno - 1 } }
}
export async function fiscalGet(ctx: Ctx) { const u = requireUser(ctx); await requireModule('fiscal'); return fiscalState(u.id) }
export async function fiscalPut(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('fiscal')
  const b = ctx.body || {}
  const f: Fiscal = { ...FISCAL_USER_DEFAULT, ...(await getUM<Partial<Fiscal>>(u.id, 'fiscal', {})) } as Fiscal
  if (b.atividade !== undefined) { if (!['comercio', 'servicos', 'ambos', 'caminhoneiro'].includes(b.atividade)) fail(400, 'Atividade inválida.', 'invalid'); f.atividade = b.atividade }
  if (b.abertura !== undefined) { if (b.abertura && !/^\d{4}-(0[1-9]|1[0-2])$/.test(b.abertura)) fail(400, 'Mês de abertura inválido.', 'invalid'); f.abertura = b.abertura || ''; f.init = false }
  if (typeof b.consent === 'boolean') f.consent = b.consent
  if (b.avisos) { const a = b.avisos; f.avisos = { das: typeof a.das === 'boolean' ? a.das : f.avisos.das, dasn: typeof a.dasn === 'boolean' ? a.dasn : f.avisos.dasn, irpf: typeof a.irpf === 'boolean' ? a.irpf : f.avisos.irpf, dias: Number.isInteger(a.dias) && a.dias >= 0 && a.dias <= 15 ? a.dias : f.avisos.dias } }
  if (b.receitas && typeof b.receitas === 'object') for (const [k, v] of Object.entries(b.receitas)) { if (!/^\d{4}-\d{2}$/.test(k)) continue; const n = Number(v); if (!n || n < 0) delete f.receitas[k]; else if (n < 1e8) f.receitas[k] = Math.round(n * 100) / 100 }
  if (b.pago && /^\d{4}-\d{2}$/.test(b.pago.k)) f.pagos[b.pago.k] = !!b.pago.value
  await setUM(u.id, 'fiscal', f)
  return fiscalState(u.id)
}
export { MES }
