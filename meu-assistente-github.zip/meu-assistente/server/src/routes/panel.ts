import { nowIso } from '../db/index.js'
import { config } from '../config.js'
// /api/panel — configurações do painel administrativo (módulos, IAs, fontes de mercado, Mercado Pago,
// planos de anúncio, cérebro, busca, parâmetros fiscais). Chaves secretas ficam cifradas e só voltam mascaradas.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { getConfig, setConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { MODULES_DEFAULT, AI_DEFAULT, AI_ROUTER_DEFAULT, MARKET_DEFAULT, MP_DEFAULT, PLANS_DEFAULT, BRAIN_DEFAULT, SEARCH_DEFAULT, FISCAL_DEFAULT, type AiProvider, type MarketProvider } from '../lib/panel-defaults.js'
import { aiRuntime, aiResume, testProvider, loadProviders, routerCfg } from '../ai/provider.js'
import { capsOf, kindOf } from '../ai/registry.js'
import { CAPS, CAP_LABEL, type Cap } from '../ai/types.js'
import { fetchQuote, marketProviders } from './market.js'
import { modules } from '../lib/usermod.js'
import { usageCfg, USAGE_KINDS } from '../lib/usage.js'
import { ENGINE_DEFAULT } from '../ai/provider.js'

async function requirePanel(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const pol = await one("SELECT value FROM app_config WHERE key = 'security-policy'")
  if (J<any>(pol?.value, {}).adminMfaRequired && !u.mfa_enabled) fail(403, 'Ative a verificação em duas etapas para usar o painel.', 'mfa_required')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
const isUrl = (v: string, httpsOnly = false) => (httpsOnly ? /^https:\/\/[^\s]+$/ : /^https?:\/\/[^\s]+$/).test(v)
const bool = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d)
const money = (v: unknown) => { const n = Number(v); return isFinite(n) && n >= 0 && n < 1e6 ? Math.round(n * 100) / 100 : null }
async function secret(incoming: unknown, old: string, clear?: unknown): Promise<string> {
  if (clear === true) return ''
  const s = typeof incoming === 'string' ? incoming.trim() : ''
  if (!s || s.includes('••')) return old || ''
  if (s.length < 8 || s.length > 400 || /\s/.test(s)) fail(400, 'A chave parece incompleta. Copie de novo no site do serviço.', 'invalid')
  return seal(s)
}
async function masked(sealed: string) { const p = await unseal(sealed); return { hasKey: !!p, keyMasked: maskSecret(p) } }

async function load() {
  const ai = await loadProviders()
  const mk = await getConfig<MarketProvider[]>('market_providers', [])
  return {
    modules: { ...MODULES_DEFAULT, ...(await getConfig('modules', {})) },
    ai_providers: ai,
    ai_router: await routerCfg(),
    market_providers: mk.length ? mk : MARKET_DEFAULT,
    mercadopago: { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) },
    ad_plans: (await getConfig<any[]>('ad_plans', [])).length ? await getConfig<any[]>('ad_plans', []) : PLANS_DEFAULT,
    brain: { ...BRAIN_DEFAULT, ...(await getConfig('brain', {})) },
    search: { ...SEARCH_DEFAULT, ...(await getConfig('search', {})) },
    fiscal: { ...FISCAL_DEFAULT, ...(await getConfig('fiscal', {})) },
    usage_plans: await usageCfg(),
    fin_dict: { items: [], ...(await getConfig<any>('fin_dict', {})) },
    pix: { expiraMin: 30, ...(await getConfig<any>('pix', {})) },
    engine: { ...ENGINE_DEFAULT, ...(await getConfig<any>('engine', {})) },
    agent_plan: { preco: 39.9, dias: 30, limiteDia: 300, ...(await getConfig<any>('agent_plan', {})) },
    ad_frequency: { ativo: true, cada: 6, intervaloMin: 30, ...(await getConfig<any>('ad_frequency', {})) },
    menu: { items: [], ...(await getConfig<any>('menu', {})) },
    quick_buttons: { enabled: true, custom: false, items: ['Quero organizar meu dia de hoje', 'Gastei 80 reais de gasolina', 'Me lembra da reunião amanhã às 9h', 'A conta de internet vence dia 15, 99 reais'], ...(await getConfig<any>('quick_buttons', {})) },
    chat_welcome: { ... (await import('../lib/panel-defaults.js')).CHAT_WELCOME_DEFAULT, ...(await getConfig<any>('chat_welcome', {})) },
  }
}

export async function panelGet(ctx: Ctx) {
  const u = await requirePanel(ctx)
  const c = await load()
  const mp = c.mercadopago
  const mpOut: any = { modo: mp.modo }
  for (const m of ['teste', 'producao']) {
    const x = mp[m] || {}
    mpOut[m] = { pub: x.pub || '', tok: await masked(x.tok), seg: await masked(x.seg) }
  }
  return {
    canWrite: effectivePermissions(u).includes('panel.manage'),
    modules: c.modules,
    ai_providers: await Promise.all(c.ai_providers.map(async (p) => ({ ...p, key: undefined, tipo: kindOf(p), caps: capsOf(p), modelo_audio: p.modelo_audio || '', ...(await masked(p.key)) }))),
    ai_router: c.ai_router, ai_caps: CAPS.map((k) => ({ id: k, label: CAP_LABEL[k] })),
    ai_runtime: await aiRuntime(),
    market_providers: await Promise.all(c.market_providers.map(async (p) => ({ ...p, key: undefined, ...(await masked(p.key)) }))),
    market_status: await getConfig('market-status', {}),
    mercadopago: mpOut,
    ad_plans: c.ad_plans, brain: c.brain, search: c.search, fiscal: c.fiscal, quick_buttons: c.quick_buttons, usage_plans: c.usage_plans, usage_kinds: USAGE_KINDS, fin_dict: c.fin_dict, pix: c.pix, engine: c.engine, agent_plan: c.agent_plan, ad_frequency: c.ad_frequency, menu: c.menu,
    chat_welcome: c.chat_welcome,
    mkt_plans: await (await import('../lib/marketing.js')).mktPlans(),
    mkt_global: { ativo: await (await import('../lib/marketing.js')).mktOn() },
    mp_oauth: await (async () => { const o = await getConfig<any>('mp_oauth', {}); const P = (await import('../lib/publicurl.js')).pub(); return { clientId: o.clientId || '', temSecret: !!o.clientSecret, temWebhookSecret: !!o.webhookSecret, exigirAssinatura: !!o.exigirAssinatura, ambiente: o.ambiente || 'producao', planos: o.planos || [], redirectUri: P + '/api/mercadopago/oauth/callback', webhookUrl: P + '/api/mercadopago/webhook', status: o.clientId && o.clientSecret ? 'configurado' : 'pendente', lojasConectadas: (await q('SELECT data FROM businesses')).filter((r: any) => J<any>(r.data, {}).mpModo === 'oauth').length } })(), // data é JSONB no PostgreSQL: contar no código (LIKE em JSONB derrubava o GET /api/panel)
    invite_msg: { texto: await (await import('../lib/invite.js')).refreshInvite(), padrao: (await import('../lib/invite.js')).INVITE_DEFAULT },
    email: await (await import('../lib/mail.js')).mailCfgPublic(), email_templates: { ...(await import('../lib/mail.js')).TEMPLATES, ...(await getConfig<any>('email_templates', {})) }, email_kinds: (await import('../lib/mail.js')).KINDS,
    voice_global: await (await import('../lib/account.js')).refreshVoiceGlobal(),
    followup: { ativo: true, dias: 7, ...(await getConfig<any>('followup', {})) },
    site: { url: (await import('../lib/publicurl.js')).pub(), salvo: (await getConfig<any>('site', {})).url || '' },
    site_url: (await import('../lib/publicurl.js')).pub(), mod_visible: await getConfig<any>('mod_visible', {}), menu_layout: await getConfig<any>('menu_layout', {}), resp_modes: { text: true, text_audio: true, audio: true, ...(await getConfig<any>('resp_modes', {})) }, ui_size: { menu: 'm', botoes: 'm', ...(await getConfig<any>('ui_size', {})) }, mod_catalog: (await import('../lib/modcatalog.js')).MOD_CATALOG.map(({ words, ...m }) => m),
    ceo_identity: await (await import('../lib/identity.js')).identity(),
    tts: await (await import('../ai/tts.js')).ttsCfg(), ocr: { ativo: (await getConfig<any>('ocr', {})).ativo !== false, temChave: !!(await getConfig<any>('ocr', {})).key },
    baseUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
    webhookUrl: (await import('../lib/publicurl.js')).pub() + '/api/mercadopago/webhook',
  }
}

/** Configuração pública (sem segredos) usada pelo app e pelo chat. */
export async function panelPublicGet() {
  const c = await load()
  const { MOD_CATALOG } = await import('../lib/modcatalog.js')
  return { modules: c.modules, ad_plans: c.ad_plans, search: c.search, fiscal: c.fiscal, quick_buttons: c.quick_buttons, menu: c.menu, agent_plan: c.agent_plan, chat_welcome: c.chat_welcome, mod_visible: await getConfig<any>('mod_visible', {}), menu_layout: await getConfig<any>('menu_layout', {}), resp_modes: { text: true, text_audio: true, audio: true, ...(await getConfig<any>('resp_modes', {})) }, ui_size: { menu: 'm', botoes: 'm', ...(await getConfig<any>('ui_size', {})) }, mod_catalog: MOD_CATALOG.map(({ words, ...m }) => m) }
}

export async function panelPut(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const key = ctx.params.key
  const b = ctx.body || {}
  const cur: any = await load()
  let next: any
  switch (key) {
    case 'modules': {
      next = { ...cur.modules }
      for (const k of Object.keys(MODULES_DEFAULT)) next[k] = bool(b[k], next[k])
      break
    }
    case 'ai_providers': {
      if (!Array.isArray(b.items) || b.items.length > 30) fail(400, 'Lista inválida.', 'invalid')
      const old = new Map<string, AiProvider>(cur.ai_providers.map((p: AiProvider) => [p.id, p]))
      next = []
      for (const it of b.items) {
        const id = str(it.id, 40)
        if (!/^[a-z0-9-]{2,40}$/.test(id)) fail(400, 'Identificador inválido.', 'invalid')
        const base = old.get(id) || AI_DEFAULT.find((p) => p.id === id)
        if (!base && !id.startsWith('c-')) fail(400, 'IA desconhecida.', 'invalid')
        const url = str(it.base_url ?? base?.base_url, 300)
        if (id !== 'servidor' && url && !isUrl(url)) fail(400, 'Endereço da IA inválido.', 'invalid')
        const modelo = str(it.modelo ?? base?.modelo, 100)
        if (modelo && !/^[\w.:\/@-]+$/.test(modelo)) fail(400, 'Nome de modelo inválido.', 'invalid')
        const tipo = ['openai', 'gemini', 'anthropic'].includes(it.tipo) ? it.tipo : (base as any)?.tipo || kindOf({ id, base_url: url })
        const mAudio = str(it.modelo_audio ?? (base as any)?.modelo_audio, 100)
        if (mAudio && !/^[\w.:\/@-]+$/.test(mAudio)) fail(400, 'Nome do modelo de áudio inválido.', 'invalid')
        let caps: Record<string, boolean> | undefined = (base as any)?.caps
        if (it.caps && typeof it.caps === 'object') { caps = { ...(caps || {}) }; for (const k of CAPS) if (typeof it.caps[k] === 'boolean') caps[k] = it.caps[k] }
        const texto = bool(it.texto ?? it.caps?.texto, base?.texto ?? true), imagem = bool(it.imagem ?? it.caps?.imagem, base?.imagem ?? false)
        if (caps) { caps.texto = texto; caps.imagem = imagem }
        const tS = it.timeoutS !== undefined ? Math.min(180, Math.max(0, Math.round(Number(it.timeoutS) || 0))) : (base as any)?.timeoutS, rt = it.retries !== undefined ? Math.min(4, Math.max(0, Math.round(Number(it.retries) || 0))) : (base as any)?.retries
        next.push({ id, tipo, nome: str(it.nome ?? base?.nome, 60) || id, base_url: url, modelo, modelo_audio: mAudio, caps, texto, imagem, ...(tS !== undefined ? { timeoutS: tS } : {}), ...(rt !== undefined ? { retries: rt } : {}),
          ativo: bool(it.ativo, base?.ativo ?? true), onde: base?.onde || 'IA cadastrada por você', key: await secret(it.key, base?.key || '', it.clearKey) })
        if (it.resume) aiResume(id)
      }
      if (!next.some((p: AiProvider) => p.id === 'servidor')) next.push({ ...AI_DEFAULT.find((p) => p.id === 'servidor')! })
      break
    }
    case 'ai_router': {
      const num = (v: unknown, d: number, lo: number, hi: number) => { const n = Number(v); return isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d }
      const cr = cur.ai_router, p = b.paralelo || {}, bk = b.breaker || {}, mo = b.monitor || {}
      next = {
        modo: ['equilibrado', 'prioridade', 'velocidade', 'qualidade'].includes(b.modo) ? b.modo : cr.modo,
        timeoutMs: num(b.timeoutMs, cr.timeoutMs, 3000, 120000), prazoMs: num(b.prazoMs, cr.prazoMs, 5000, 180000), tentativas: Math.round(num(b.tentativas, cr.tentativas, 0, 3)),
        breaker: { falhas: Math.round(num(bk.falhas, cr.breaker.falhas, 1, 20)), pausaSeg: num(bk.pausaSeg, cr.breaker.pausaSeg, 5, 3600), maxPausaSeg: num(bk.maxPausaSeg, cr.breaker.maxPausaSeg, 10, 86400) },
        paralelo: { ativo: bool(p.ativo, cr.paralelo.ativo), modo: p.modo === 'corrida' ? 'corrida' : p.modo === 'comparar' ? 'comparar' : cr.paralelo.modo, max: Math.round(num(p.max, cr.paralelo.max, 2, 4)),
          tarefas: Array.isArray(p.tarefas) ? p.tarefas.filter((x: unknown) => ['conversa', 'agente', 'contexto', 'analise', 'codigo', 'pesquisa'].includes(String(x))) : cr.paralelo.tarefas },
        monitor: { ativo: bool(mo.ativo, cr.monitor.ativo), minutos: Math.round(num(mo.minutos, cr.monitor.minutos, 1, 120)) },
      }
      break
    }
    case 'market_providers': {
      if (!Array.isArray(b.items) || b.items.length > 40) fail(400, 'Lista inválida.', 'invalid')
      const old = new Map<string, MarketProvider>(cur.market_providers.map((p: MarketProvider) => [p.id, p]))
      next = []
      for (const it of b.items) {
        const id = str(it.id, 40)
        const base = old.get(id) || MARKET_DEFAULT.find((p) => p.id === id)
        const custom = !base || base.custom
        if (!/^[a-z0-9-]{2,40}$/.test(id) || (!base && !id.startsWith('c-'))) fail(400, 'Fonte inválida.', 'invalid')
        const url = custom ? str(it.url, 400) : base!.url
        if (custom && !isUrl(url, process.env.NODE_ENV !== 'test')) fail(400, 'O endereço da fonte precisa começar com https://', 'invalid')
        const campo = custom ? str(it.campo, 120) : ''
        if (custom && !/^[\w.]+$/.test(campo)) fail(400, 'Informe o caminho do preço, por exemplo data.price', 'invalid')
        next.push({ id, nome: custom ? str(it.nome, 60) || id : base!.nome, cat: it.cat === 'bolsa' ? 'bolsa' : it.cat === 'cripto' ? 'cripto' : base!.cat, url, campo,
          precisaChave: custom ? false : base!.precisaChave, ativo: bool(it.ativo, base?.ativo ?? true), info: custom ? 'Fonte cadastrada por você' : base!.info, custom,
          key: await secret(it.key, base?.key || '', it.clearKey) })
      }
      break
    }
    case 'mercadopago': {
      next = { modo: b.modo === 'producao' ? 'producao' : 'teste', teste: { ...cur.mercadopago.teste }, producao: { ...cur.mercadopago.producao } }
      for (const m of ['teste', 'producao']) {
        const x = b[m]; if (!x) continue
        const pub = str(x.pub, 200)
        if (pub && !/^(APP_USR|TEST)-[\w-]{10,}$/.test(pub)) fail(400, 'A chave pública começa com TEST- ou APP_USR-.', 'invalid')
        if (typeof x.tok === 'string' && x.tok.trim() && !x.tok.includes('••') && !/^(APP_USR|TEST)-[\w-]{10,}$/.test(x.tok.trim())) fail(400, 'O Access Token começa com TEST- ou APP_USR-.', 'invalid')
        next[m] = { pub: x.clear ? '' : pub, tok: await secret(x.tok, next[m].tok, x.clear), seg: await secret(x.seg, next[m].seg, x.clear) }
      }
      break
    }
    case 'ad_plans': {
      if (!Array.isArray(b.items) || !b.items.length || b.items.length > 12) fail(400, 'Cadastre de 1 a 12 planos.', 'invalid')
      next = b.items.map((it: any) => {
        const preco = money(it.preco), dias = Number(it.dias), nivel = Number(it.nivel)
        const nome = str(it.nome, 60)
        if (!nome || preco === null || !(dias >= 1 && dias <= 365) || ![1, 2, 3, 4].includes(nivel)) fail(400, 'Plano inválido: confira nome, preço, dias e nível.', 'invalid')
        return { id: /^[\w-]{1,30}$/.test(String(it.id)) ? String(it.id) : 'p' + Math.random().toString(36).slice(2, 8), nome, preco, dias: Math.round(dias), nivel }
      })
      break
    }
    case 'quick_buttons': {
      const items = (Array.isArray(b.items) ? b.items : []).map((x: unknown) => str(x, 80)).filter(Boolean).slice(0, 8)
      next = { enabled: bool(b.enabled, cur.quick_buttons.enabled), custom: bool(b.custom, cur.quick_buttons.custom), items }
      break
    }
    case 'usage_plans': {
      const lim = (o: any) => { const r: Record<string, number | null> = {}; for (const k of Object.keys(USAGE_KINDS)) { const v = o?.[k]; r[k] = v === null || v === '' || v === undefined ? null : Math.max(0, Math.min(100000, Math.floor(Number(v)) || 0)) } return r }
      const plans = (Array.isArray(b.plans) ? b.plans : []).slice(0, 10).map((p: any, i: number) => ({ id: str(p.id, 20) || 'p' + (i + 1) + Date.now().toString(36).slice(-3), nome: str(p.nome, 40) || 'Plano', preco: Math.max(0.01, Math.round((Number(p.preco) || 0) * 100) / 100), dias: Math.min(365, Math.max(1, Math.floor(Number(p.dias) || 30))), ativo: p.ativo !== false, limites: lim(p.limites) }))
      next = { ativo: bool(b.ativo, false), free: { nome: str(b.free?.nome, 40) || 'Grátis', limites: lim(b.free?.limites) }, plans }
      break
    }
    case 'ad_frequency': next = { ativo: bool(b.ativo, true), cada: Math.min(100, Math.max(1, Math.floor(Number(b.cada)) || 6)), intervaloMin: Math.min(1440, Math.max(0, Math.floor(Number(b.intervaloMin)) || 0)) }; break
    case 'menu': next = { items: (Array.isArray(b.items) ? b.items : []).slice(0, 30).map((x: any) => ({ key: str(x.key, 40), label: str(x.label, 60), visible: x.visible !== false })).filter((x: any) => x.key) }; break
    case 'engine': { const n = (v: any, d: number) => Math.max(0, Math.min(100, Math.round(Number(v ?? d)))); next = { naturalidade: n(b.naturalidade, 75), personalidade: ['amigavel', 'profissional', 'divertido', 'direto'].includes(b.personalidade) ? b.personalidade : 'amigavel', personalidadeTexto: str(b.personalidadeTexto, 600), criatividade: n(b.criatividade, 45), contexto: n(b.contexto, 70), autonomia: n(b.autonomia, 55), precisao: n(b.precisao, 80) }; break }
    case 'agent_plan': next = { preco: Math.max(0.01, Math.round((Number(b.preco) || 39.9) * 100) / 100), dias: Math.min(365, Math.max(1, Math.floor(Number(b.dias)) || 30)), limiteDia: Math.min(100000, Math.max(10, Math.floor(Number(b.limiteDia)) || 300)) }; break
    case 'pix': next = { expiraMin: Math.min(1440, Math.max(5, Math.floor(Number(b.expiraMin)) || 30)) }; break
    case 'fin_dict': {
      const { FIN_CATS } = await import('../ai/fin.js')
      next = { items: (Array.isArray(b.items) ? b.items : []).slice(0, 300).map((e: any) => ({ tipo: e.tipo === 'income' ? 'income' : 'expense', cat: str(e.cat, 30), sub: str(e.sub, 40), words: (Array.isArray(e.words) ? e.words : String(e.words || '').split(',')).map((w: any) => str(w, 40).toLowerCase()).filter((w: string) => w.length >= 2).slice(0, 40) })).filter((e: any) => e.sub && e.words.length && (FIN_CATS as any)[e.tipo].includes(e.cat)) }
      break
    }
    case 'chat_welcome': next = {
      ativo: bool(b.ativo, cur.chat_welcome.ativo),
      saudacao: str(b.saudacao ?? cur.chat_welcome.saudacao, 80),
      titulo: str(b.titulo ?? cur.chat_welcome.titulo, 80),
      subtitulo: str(b.subtitulo ?? cur.chat_welcome.subtitulo, 120),
    }; break
    case 'tts': {
      const ok = ['openai', 'gemini', 'streamelements', 'google']
      next = { ativo: b.ativo !== false, ordem: (Array.isArray(b.ordem) ? b.ordem : ok).filter((x: any) => ok.includes(x)), vozOpenai: str(b.vozOpenai, 20) || 'nova', vozGemini: str(b.vozGemini, 20) || 'Kore', vozSE: str(b.vozSE, 20) || 'Vitoria', maxChars: Math.min(5000, Math.max(200, Math.floor(Number(b.maxChars)) || 3000)) }
      break
    }
    case 'mod_visible': { const { MOD_CATALOG } = await import('../lib/modcatalog.js'); next = {}; for (const m of MOD_CATALOG) if (b[m.key] === false) next[m.key] = false; break }
    case 'resp_modes': next = { text: true, text_audio: b.text_audio !== false, audio: b.audio !== false }; break // "Texto" fica sempre disponível
    case 'ui_size': { const ok = (v: any) => (['p', 'm', 'g'].includes(v) ? v : 'm'); next = { menu: ok(b.menu), botoes: ok(b.botoes) }; break }
    case 'ceo_identity': { const { IDENTITY_DEFAULT: D } = await import('../lib/identity.js'); next = { ativo: b.ativo !== false, nome: str(b.nome, 80) || D.nome, cargo: str(b.cargo, 200) || D.cargo, texto: str(b.texto, 6000) || D.texto }; break } // campo vazio volta ao texto institucional padrão
    case 'voice_global': {
      const { VOICE_DEFAULT, refreshVoiceGlobal } = await import('../lib/account.js')
      next = { ...VOICE_DEFAULT, voiceEngine: b.voiceEngine === 'auto' ? 'auto' : 'device', voiceName: str(b.voiceName, 80), voiceRate: Math.min(2, Math.max(0.5, Math.round((Number(b.voiceRate) || 1) * 10) / 10)), voiceModeEnabled: b.voiceModeEnabled !== false, voiceModeSpeak: b.voiceModeSpeak !== false, voiceKeepListening: b.voiceKeepListening === true, voiceTranscripts: b.voiceTranscripts !== false, voiceWakePhrase: str(b.voiceWakePhrase, 60) }
      await setConfig('voice_global', next); await refreshVoiceGlobal(); break
    }
    case 'email': try { next = await (await import('../lib/mail.js')).saveCfg(b) } catch (e: any) { fail(400, e.message, 'invalid') } break
    case 'email_templates': { const { TEMPLATES } = await import('../lib/mail.js'); next = {}; for (const k of Object.keys(TEMPLATES)) if (b[k] && (b[k].assunto || b[k].corpo)) next[k] = { assunto: str(b[k].assunto, 200), corpo: str(b[k].corpo, 8000) }; break }
    case 'followup': { const msgs: any = {}; for (const k of ['concluido', 'servico', 'venda', 'contato', 'atrasado']) if (typeof b.msgs?.[k] === 'string') msgs[k] = str(b.msgs[k], 400); next = { ativo: b.ativo !== false, dias: Math.min(365, Math.max(1, Math.round(Number(b.dias) || 7))), msgs: { ...((await getConfig<any>('followup', {})).msgs || {}), ...msgs } }; break }
    case 'invite_msg': { const t = str(b.texto, 1200); if (t && !t.includes('{link}')) fail(400, 'O modelo precisa ter {link}.', 'invalid'); if (/\{(data|hora|horario|local)\}/i.test(t)) fail(400, 'Por privacidade, a mensagem não pode mostrar data, horário ou local.', 'invalid'); next = { texto: t }; await setConfig('invite_msg', next); await (await import('../lib/invite.js')).refreshInvite(); break }
    case 'mp_oauth': { const cur0 = await getConfig<any>('mp_oauth', {}); const cid = str(b.clientId, 60); if (cid && !/^\d{6,20}$/.test(cid)) fail(400, 'O Client ID do Mercado Pago tem só números.', 'invalid'); next = { clientId: cid || (b.clear ? '' : cur0.clientId || ''), clientSecret: b.clientSecret ? await seal(String(b.clientSecret).trim()) : b.clear ? '' : cur0.clientSecret || '', webhookSecret: b.webhookSecret ? await seal(String(b.webhookSecret).trim()) : b.clear ? '' : cur0.webhookSecret || '', exigirAssinatura: b.exigirAssinatura === undefined ? !!cur0.exigirAssinatura : !!b.exigirAssinatura, ambiente: ['teste', 'producao'].includes(b.ambiente) ? b.ambiente : cur0.ambiente || 'producao', planos: Array.isArray(b.planos) ? b.planos.map(String).slice(0, 20) : cur0.planos || [] }; break }
    case 'mkt_global': next = { ativo: b.ativo !== false }; break
    case 'mkt_plans': { const { MKT_DEFAULT } = await import('../lib/marketing.js'); next = {}; for (const [k, v] of Object.entries<any>(b || {})) { if (!/^[\w-]{1,30}$/.test(k) || !v || typeof v !== 'object') continue; next[k] = { acesso: !!v.acesso, campanhasPeriodo: Math.max(0, Math.min(10000, Math.round(Number(v.campanhasPeriodo) || 0))), notificacoesPeriodo: Math.max(0, Math.min(1000000, Math.round(Number(v.notificacoesPeriodo) || 0))), agendar: !!v.agendar, segmentacao: !!v.segmentacao, relatorios: !!v.relatorios } }; void MKT_DEFAULT; break }
    case 'site': {
      const u0 = String(b.url || '').trim().replace(/\/+$/, '')
      if (u0 && !/^https?:\/\/[a-z0-9.-]+(:\d+)?$/i.test(u0)) fail(400, 'Informe só o endereço, por exemplo https://meuassistente.chat', 'invalid')
      if (/ivaslovck\.tech/i.test(u0)) fail(400, 'Use o domínio oficial atual, não o endereço antigo.', 'invalid')
      next = { url: u0 }; await setConfig('site', next); await (await import('../lib/publicurl.js')).refreshPublicUrl(); break
    }
    case 'menu_layout': {
      // onde cada módulo aparece por padrão: menu principal, pasta "Módulos" (o usuário escolhe se fixa) ou oculto
      const { MOD_CATALOG } = await import('../lib/modcatalog.js'); next = {}; const vis: any = {}
      for (const m of MOD_CATALOG) { const v = b[m.key]; if (['menu', 'pasta', 'oculto'].includes(v)) next[m.key] = v; if (v === 'oculto') vis[m.key] = false }
      await setConfig('mod_visible', vis)
      break
    }
    case 'ocr': next = { ativo: b.ativo !== false, key: str(b.key, 60) }; break
    case 'brain_mode': next = { ...(await getConfig<any>('brain', {})), modoIA: ['normal', 'so_ollama', 'sem_ia'].includes(b.modoIA) ? b.modoIA : 'normal' }; await setConfig('brain', next); break
    case 'brain': next = { ...cur.brain, aprender: bool(b.aprender, cur.brain.aprender), cerebroPrimeiro: bool(b.cerebroPrimeiro, cur.brain.cerebroPrimeiro), fatos: bool(b.fatos, cur.brain.fatos) }; break
    case 'search': { const r = Number(b.raio); if (!(r >= 1 && r <= 100)) fail(400, 'Use um raio entre 1 e 100 km.', 'invalid'); next = { raio: r }; break }
    case 'fiscal': {
      const sm = money(b.sm), lim = money(b.limite)
      if (!sm || !lim) fail(400, 'Informe salário mínimo e limite válidos.', 'invalid')
      next = { sm, limite: lim }; break
    }
    default: fail(404, 'Configuração desconhecida.', 'not_found')
  }
  await setConfig(key, next)
  if (key === 'modules') await modules()
  await audit(u.id, 'panel.update', null, { key })
  return panelGet(ctx)
}

export async function panelTestPost(ctx: Ctx) {
  await requirePanel(ctx, true)
  const b = ctx.body || {}
  if (b.kind === 'ai') {
    const c = await load()
    const p = c.ai_providers.find((x: AiProvider) => x.id === b.id)
    if (!p) fail(404, 'IA não encontrada.', 'not_found')
    const only = Array.isArray(b.caps) ? (b.caps.filter((k: unknown) => (CAPS as string[]).includes(String(k))) as Cap[]) : undefined
    return testProvider(p!, only?.length ? only : undefined)
  }
  if (b.kind === 'ai_all') {
    const c = await load()
    const out: Record<string, any> = {}
    for (const p of c.ai_providers as AiProvider[]) if (p.ativo) { const r = await testProvider(p); if (r.checks.length || p.id !== 'servidor') out[p.id] = r }
    return { ok: Object.values(out).every((r: any) => r.ok), results: out }
  }
  if (b.kind === 'market') {
    const p = (await marketProviders()).find((x) => x.id === b.id)
    if (!p) fail(404, 'Fonte não encontrada.', 'not_found')
    const sym = p!.cat === 'cripto' ? 'BTC' : 'PETR4'
    try { const v = await fetchQuote(p!, sym); return { ok: true, message: `Funcionando: ${sym} = R$ ${v.price.toLocaleString('pt-BR', { maximumFractionDigits: 2 })}` } }
    catch (e: any) { return { ok: false, message: e?.message === 'sem chave' ? 'Esta fonte precisa de chave.' : 'Falhou: ' + (e?.message || 'erro') } }
  }
  if (b.kind === 'mp') {
    const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }, modo = b.modo === 'producao' ? 'producao' : b.modo === 'teste' ? 'teste' : mp.modo
    const tok = await unseal((mp[modo] || {}).tok || '')
    if (!tok) return { ok: false, message: 'Salve o Access Token deste modo antes de testar.' }
    try {
      const r = await fetch(`${(process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')}/users/me`, { headers: { Authorization: `Bearer ${tok}` } })
      const j: any = await r.json().catch(() => ({}))
      if (r.status === 401 || r.status === 403) return { ok: false, message: 'O Mercado Pago recusou o Access Token. Copie de novo em Suas integrações → Credenciais.' }
      if (!r.ok) return { ok: false, message: 'O Mercado Pago respondeu com erro ' + r.status + '.' }
      const isTest = tok.startsWith('TEST-')
      return { ok: true, message: `Conectado à conta ${j.nickname || j.email || j.id} (${isTest ? 'modo teste: os pagamentos são simulados' : 'produção: pagamentos reais'}). Pronto para gerar Pix.` }
    } catch (e: any) { return { ok: false, message: 'Sem conexão com o Mercado Pago: ' + (e?.message || 'erro') } }
  }
  fail(400, 'Teste inválido.', 'invalid')
}

// ─── Cérebro: gerenciamento das respostas aprendidas ───

export async function brainAnswersGet(ctx: Ctx) {
  await requirePanel(ctx)
  const term = str(ctx.query.get('q'), 100).toLowerCase()
  const limit = Math.min(200, Math.max(10, Number(ctx.query.get('limit')) || 80))
  const rows = await q(
    `SELECT id, user_id, question, answer, origin, uses, score, reviewed, created_at, updated_at
     FROM brain_answers
     WHERE ($1 = '' OR question ILIKE '%'||$1||'%' OR answer ILIKE '%'||$1||'%')
     ORDER BY updated_at DESC LIMIT $2`,
    [term, limit]
  )
  const answers = rows.map(r => ({
    id: Number(r.id), userId: r.user_id ? Number(r.user_id) : null,
    question: r.question, answer: r.answer, origin: r.origin,
    uses: Number(r.uses), score: Number(r.score), reviewed: !!r.reviewed,
    createdAt: r.created_at, updatedAt: r.updated_at
  }))
  // estatísticas de aprendizado (SQL do PostgreSQL; se o banco não suportar, devolve só o básico em vez de quebrar a tela)
  let stats: any = null, trend: any[] = [], top: any[] = []
  try {
    stats = await one(`SELECT 
      COUNT(*)::int as total,
      COALESCE(AVG(score),0) as avg_score,
      COALESCE(SUM(uses),0)::int as total_uses,
      COUNT(*) FILTER (WHERE reviewed)::int as reviewed,
      COUNT(*) FILTER (WHERE score >= 0.8)::int as high_score,
      COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '7 days')::int as last_7d
     FROM brain_answers`)
    trend = await q(`
      SELECT to_char(d, 'YYYY-MM-DD') as day, COALESCE(cnt, 0)::int as count
      FROM generate_series(CURRENT_DATE - INTERVAL '29 days', CURRENT_DATE, '1 day') d
      LEFT JOIN (
        SELECT date_trunc('day', created_at)::date as day, COUNT(*)::int as cnt
        FROM brain_answers
        WHERE created_at > CURRENT_DATE - INTERVAL '29 days'
        GROUP BY 1
      ) t ON t.day = d
      ORDER BY d
    `)
    top = await q(`
      SELECT question, uses, score, origin
      FROM brain_answers
      WHERE uses > 0
      ORDER BY uses DESC, score DESC
      LIMIT 10
    `)

  } catch {
    const all = await q('SELECT score, uses, reviewed, question, origin FROM brain_answers')
    stats = { total: all.length, avg_score: all.length ? all.reduce((a: number, r: any) => a + Number(r.score || 0), 0) / all.length : 0, total_uses: all.reduce((a: number, r: any) => a + Number(r.uses || 0), 0), reviewed: all.filter((r: any) => r.reviewed === true || r.reviewed === 1).length, high_score: all.filter((r: any) => Number(r.score) >= 0.8).length, last_7d: 0 }
    top = all.filter((r: any) => Number(r.uses) > 0).sort((a: any, b: any) => Number(b.uses) - Number(a.uses)).slice(0, 10)
  }
  if (stats) for (const k of ['total', 'avg_score', 'total_uses', 'reviewed', 'high_score', 'last_7d']) stats[k] = Number(stats[k]) || 0
  return { 
    answers, 
    stats: stats || { total: 0, avg_score: 0, total_uses: 0, reviewed: 0, high_score: 0, last_7d: 0 },
    trend: trend.map(r => ({ day: r.day, count: Number(r.count) })),
    top: top.map(r => ({ question: r.question, uses: Number(r.uses), score: Number(r.score), origin: r.origin }))
  }
}

export async function brainAnswerPut(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const id = Number(ctx.params?.id)
  const b = ctx.body || {}
  const row = await one('SELECT * FROM brain_answers WHERE id = $1', [id])
  if (!row) fail(404, 'Resposta não encontrada.', 'not_found')
  const question = b.question !== undefined ? str(b.question, 500) : row!.question
  const answer = b.answer !== undefined ? str(b.answer, 2000) : row!.answer
  const reviewed = typeof b.reviewed === 'boolean' ? b.reviewed : row!.reviewed
  if (!question.trim() || !answer.trim()) fail(400, 'Pergunta e resposta são obrigatórias.', 'invalid')
  // a pergunta editada também atualiza a forma normalizada e as palavras-chave (antes ficavam as antigas e a resposta editada não era mais encontrada)
  const B0 = await import('../ai/brain.js')
  await q('UPDATE brain_answers SET question = $1, answer = $2, reviewed = $3, updated_at = $5, question_norm = $6, keywords = $7 WHERE id = $4',
    [question, answer, reviewed, id, new Date().toISOString(), question.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(), B0.keywordsOf(question + ' ' + answer).join(' ')])
  await audit(u.id, 'brain.update', id, { question: question.slice(0, 80) })
  return { ok: true }
}

export async function brainAnswerDelete(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const id = Number(ctx.params?.id)
  const r = await q('DELETE FROM brain_answers WHERE id = $1 RETURNING id', [id])
  if (!r.length) fail(404, 'Resposta não encontrada.', 'not_found')
  await audit(u.id, 'brain.delete', id, {})
  return { ok: true }
}

export async function ttsStatusGet(ctx: Ctx) {
  requireUser(ctx)
  const { ttsCfg } = await import('../ai/tts.js'); const c = await ttsCfg()
  return { available: !!c.ativo && c.ordem.length > 0, maxChars: c.maxChars, playback: 'manual', providers: c.ordem }
}
export async function ttsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  const { synthesize, ttsCfg, ttsSignature } = await import('../ai/tts.js'); const c = await ttsCfg()
  if (!c.ativo) fail(503, 'A voz natural está desligada pelo administrador.', 'unavailable')
  let text = typeof b.text === 'string' ? str(b.text, 4000) : ''
  if (!text && b.messageId) { const m = await one('SELECT content FROM messages WHERE id = $1 AND user_id = $2', [Number(b.messageId), u.id]); text = m?.content || '' }
  if (!text && b.preview) text = 'Olá! Esta é a voz natural do Meu Assistente. Posso ler suas respostas em voz alta.'
  if (!text.trim()) fail(400, 'Nenhum texto para falar.', 'invalid')
  if (text.length > c.maxChars) fail(413, 'Resposta longa demais para a voz natural.', 'too_long')
  const sig = ttsSignature(text, c.ordem)
  if (b.have && b.have === sig) return { _binary: true, status: 204, mime: '', data: null }
  const r = await synthesize(text)
  if (!r) fail(503, 'A voz natural não respondeu agora: usando a voz do aparelho.', 'unavailable')
  return { _binary: true, mime: r!.mime, data: r!.audio, headers: { 'X-Voice-Name': encodeURIComponent(`${r!.provider} · ${r!.voice}`), 'X-Voice-Signature': sig } }
}

export async function ollamaModelsGet(ctx: Ctx) {
  await requirePanel(ctx)
  const base = config.ai.baseUrl.replace(/\/v1\/?$/, '')
  if (!base || !/localhost|127\.0\.0\.1|ollama|:11434/.test(base)) return { models: [], note: 'IA local não parece ser Ollama.' }
  try {
    const r = await fetch(base + '/api/tags', { signal: AbortSignal.timeout(4000) })
    if (!r.ok) return { models: [], note: 'Não consegui consultar o Ollama.' }
    const j: any = await r.json()
    const models = (j.models || []).map((m: any) => ({ name: m.name, size: m.size, modified: m.modified_at }))
    return { models, current: config.ai.model }
  } catch { return { models: [], note: 'Ollama não respondeu.' } }
}

/* ---------- Cérebro próprio ---------- */
export async function brainKnowledgeGet(ctx: Ctx) {
  await requirePanel(ctx)
  const st = String(ctx.query.get('status') || ''), kd = String(ctx.query.get('kind') || ''), qq = String(ctx.query.get('q') || '').toLowerCase()
  const all = await q('SELECT id, user_id, question, answer, origin, uses, score, reviewed, kind, status, source, created_at, updated_at FROM brain_answers ORDER BY updated_at DESC LIMIT 1000')
  const count = (f: (r: any) => boolean) => all.filter(f).length
  const items = all.filter((r: any) => (!st || r.status === st) && (!kd || r.kind === kd) && (!qq || (String(r.question) + ' ' + String(r.answer)).toLowerCase().includes(qq))).slice(0, 200)
    .map((r: any) => ({ id: Number(r.id), titulo: r.question, conteudo: r.answer, origem: r.origin, tipo: r.kind || 'resposta', status: r.status || 'ativo', usos: Number(r.uses) || 0, fonte: r.source || '', global: r.user_id == null, criado: r.created_at, atualizado: r.updated_at }))
  let hist: any[] = []; try { hist = await q('SELECT item_id, action, detail, actor, created_at FROM brain_history ORDER BY id DESC LIMIT 40') } catch { /* sem histórico */ }
  const bs = await getConfig<any>('brain_stats', { semIA: 0, comIA: 0 })
  return {
    resumo: { conhecimentos: count((r) => r.kind === 'conhecimento' && r.status === 'ativo'), regras: count((r) => r.kind === 'regra' && r.status === 'ativo'), instrucoes: count((r) => r.kind === 'instrucao' && r.status === 'ativo'), experiencias: count((r) => r.kind === 'experiencia' && r.status === 'ativo'), respostas: count((r) => (r.kind || 'resposta') === 'resposta' && r.status === 'ativo'), pendentes: count((r) => r.status === 'pendente'), rejeitados: count((r) => r.status === 'rejeitado') },
    autonomia: { semIA: Number(bs.semIA) || 0, comIA: Number(bs.comIA) || 0 },
    modoIA: (await getConfig<any>('brain', {})).modoIA || 'normal',
    items, historico: hist.map((h: any) => ({ item: h.item_id != null ? Number(h.item_id) : null, acao: h.action, detalhe: h.detail, quem: h.actor, em: h.created_at })),
  }
}
export async function brainKnowledgePost(ctx: Ctx) {
  const u = await requirePanel(ctx, true), b = ctx.body || {}
  const B = await import('../ai/brain.js'), actor = 'admin ' + u.id
  if (b.action === 'add') { const r = await B.addKnowledge({ titulo: b.titulo, conteudo: b.conteudo, tipo: b.tipo, origem: 'admin', status: 'ativo', fonte: b.fonte }, actor); if (!r.ok) fail(400, r.duplicado ? 'Já existe um conhecimento igual ou muito parecido no Cérebro.' : 'Preencha título e conteúdo.', 'invalid'); return r }
  if (b.action === 'ingest') {
    const texto = str(b.texto, 60000); if (texto.length < 20) fail(400, 'Cole um texto com pelo menos algumas frases.', 'invalid')
    let blocos = B.splitKnowledge(texto), via = 'motor próprio'
    if (b.organizarComIA) { // a IA (Ollama ou outra) só ajuda a organizar; se falhar, fica a separação do motor próprio
      try {
        const { run } = await import('../ai/engine.js')
        const r = await run([{ role: 'user', content: 'Organize o texto abaixo em conhecimentos objetivos para a memória de um assistente. Não invente nada. Responda SOMENTE com JSON: {"itens":[{"titulo":"assunto curto","conteudo":"informação completa e correta","tipo":"conhecimento|regra|instrucao|experiencia"}]}\n\nTEXTO:\n' + texto.slice(0, 12000) }], { json: true, parallel: 'off' })
        const raw = String(r.message.content || ''), j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        if (Array.isArray(j.itens) && j.itens.length) { blocos = j.itens.slice(0, 80).map((x: any) => ({ titulo: String(x.titulo || ''), conteudo: String(x.conteudo || ''), tipo: String(x.tipo || 'conhecimento') })); via = 'IA auxiliar (' + r.provider.nome + ')' }
      } catch { /* mantém o motor próprio */ }
    }
    const res = { criados: 0, duplicados: 0, ignorados: 0, via }
    for (const k of blocos) { const r = await B.addKnowledge({ ...k, origem: str(b.origem, 40) || 'conteúdo', status: b.aprovar ? 'ativo' : 'pendente', fonte: str(b.fonte, 200) }, actor); if (r.ok) res.criados++; else if ((r as any).duplicado) res.duplicados++; else res.ignorados++ }
    await B.brainLog(null, 'ensinado', `${res.criados} itens de "${str(b.fonte, 60) || str(b.origem, 40) || 'texto'}" (${via})`, actor)
    return res
  }
  const id = Number(b.id); const row = await one('SELECT * FROM brain_answers WHERE id = $1', [id]); if (!row) fail(404, 'Item não encontrado.', 'not_found')
  if (b.action === 'approve') { await q("UPDATE brain_answers SET status = 'ativo', reviewed = $1, score = 0.9, updated_at = $2 WHERE id = $3", [true, nowIso(), id]); await B.brainLog(id, 'aprovado', row!.question, actor); return { ok: true } }
  if (b.action === 'reject') { await q("UPDATE brain_answers SET status = 'rejeitado', updated_at = $1 WHERE id = $2", [nowIso(), id]); await B.brainLog(id, 'rejeitado', row!.question, actor); return { ok: true } }
  if (b.action === 'update') {
    const titulo = str(b.titulo, 200) || row!.question, conteudo = str(b.conteudo, 4000) || row!.answer, tipo = (B.KINDS as readonly string[]).includes(b.tipo) ? b.tipo : row!.kind
    await q('UPDATE brain_answers SET question = $1, question_norm = $2, answer = $3, kind = $4, keywords = $5, reviewed = $6, updated_at = $7 WHERE id = $8', [titulo, titulo.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(), conteudo, tipo, B.keywordsOf(titulo + ' ' + conteudo).join(' '), true, nowIso(), id])
    await B.brainLog(id, 'editado', titulo, actor); return { ok: true }
  }
  if (b.action === 'delete') { await q('DELETE FROM brain_answers WHERE id = $1', [id]); await B.brainLog(id, 'excluído', row!.question, actor); return { ok: true } }
  fail(400, 'Ação inválida.', 'invalid')
}
/** Teste de independência: o que o Meu Assistente resolve sozinho, sem nenhuma IA e sem gravar nada. */
export async function brainTestPost(ctx: Ctx) {
  const u = await requirePanel(ctx), text = str(ctx.body?.texto, 500)
  if (!text) fail(400, 'Escreva uma mensagem para testar.', 'invalid')
  const tz = 'America/Sao_Paulo'
  const tryIt = async (via: string, fn: () => Promise<string | null | undefined>) => { try { const r = await fn(); return r ? { resolvido: true, via, resposta: r } : null } catch { return null } }
  const steps: Array<() => Promise<any>> = [
    () => tryIt('Cálculo (motor matemático interno)', async () => { const m: any = (await import('../lib/math.js')).solveMath(text); return m ? (m.erro || `${m.expr} = ${m.texto}`) : null }),
    () => tryIt('Identidade do criador', async () => (await import('../lib/identity.js')).identityReply(text)),
    () => tryIt('Registro financeiro (motor próprio)', async () => { const p = (await import('../ai/fin.js')).parseFinance(text, tz); return p ? (p.amount ? `Registraria: ${({ despesa: 'gasto', receita: 'receita', pagamento: 'pagamento', transferencia: 'transferência' } as any)[p.kind]} de R$ ${p.amount.toFixed(2).replace('.', ',')} · ${p.description} · ${p.category}${p.method ? ' · ' + p.method : ''}` : `Perguntaria o valor de: ${p.description}`) : null }),
    () => tryIt('Agenda (motor próprio)', async () => (await import('../ai/agenda.js')).isAgendaQuery(text) ? 'Consultaria a agenda real e mostraria os compromissos.' : null),
    () => tryIt('Compromisso (motor próprio)', async () => { const { parseAppointment } = await import('../ai/appt.js'); const p: any = parseAppointment(text, tz); return p ? `Agendaria: ${p.title} em ${p.date}${p.time ? ' às ' + p.time : ''}` : null }),
    () => tryIt('Resumo financeiro (motor próprio)', async () => (await import('../ai/finsummary.js')).isFinanceSummary(text) ? 'Mostraria entradas, saídas e saldo reais do período.' : null),
    () => tryIt('Módulo do app', async () => { const m = (await import('../lib/modcatalog.js')).moduleIntent(text); return m ? `Abriria o cartão do módulo ${m.label}.` : null }),
    () => tryIt('Resposta rápida (motor próprio)', async () => (await import('../ai/intents.js')).quickReply(u, text)),
    () => tryIt('Resposta aprendida (Cérebro)', async () => (await (await import('../ai/brain.js')).findLearnedAnswer(u, text))?.answer),
    () => tryIt('Conhecimento próprio (Cérebro)', async () => { const k = await (await import('../ai/brain.js')).findKnowledge(text, 0.5, u.id); return k ? `${k.conteudo}` : null }),
  ]
  for (const s of steps) { const r = await s(); if (r) return r }
  return { resolvido: false, via: 'ainda sem conhecimento aprovado sobre isso', resposta: 'O Cérebro próprio ainda não sabe responder isso (itens pendentes só valem depois de aprovados). Ensine em “Ensinar o Cérebro” ou deixe uma IA ativa.' }
}

/* ---------- Central de e-mails (administrador) ---------- */
export async function emailAdminPost(ctx: Ctx) {
  const u = await requirePanel(ctx, true), b = ctx.body || {}, M = await import('../lib/mail.js')
  if (b.action === 'testar') return M.testConnection(null)
  if (b.action === 'enviar_teste') { const to = String(b.to || u.email); const r = await M.enqueueMail({ kind: 'teste', to, dedupe: 'teste:' + Date.now() }); if (!r.queued) fail(400, 'Não foi para a fila: ' + r.motivo, 'invalid'); await new Promise((res) => setTimeout(res, 1500)); return { ok: true, id: r.id, envio: await one('SELECT status, last_error, provider, provider_id FROM email_queue WHERE id = $1', [r.id]) } }
  if (b.action === 'dns') { const c = await M.mailCfg(); const dom = String(b.dominio || c.remetenteEmail.split('@')[1] || '').trim().toLowerCase(); if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(dom)) fail(400, 'Informe o domínio do remetente.', 'invalid'); return M.checkDns(dom, String(b.seletor || '').trim()) }
  if (b.action === 'reenviar') { await q("UPDATE email_queue SET status = 'pendente', next_attempt_at = $1, last_error = NULL WHERE id = $2 AND status = 'falhou'", [nowIso(), Number(b.id)]); void M.processQueue(); return { ok: true } }
  if (b.action === 'comunicado') {
    const titulo = str(b.titulo, 150), msg = str(b.mensagem, 6000); if (!titulo || !msg) fail(400, 'Escreva o título e a mensagem.', 'invalid')
    const ref = Date.now().toString(36); let n = 0
    for (const r of await q("SELECT id, email, name FROM users WHERE status = 'active' AND email IS NOT NULL LIMIT 5000")) { const x = await M.enqueueMail({ kind: 'comunicados', to: r.email, userId: Number(r.id), vars: { nome: String(r.name || '').split(' ')[0], titulo, mensagem: msg }, dedupe: `com:${ref}:${r.id}` }); if (x.queued) n++ }
    return { ok: true, naFila: n, aviso: 'Os e-mails saem aos poucos, respeitando os limites por hora e por dia do provedor.' }
  }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function emailLogGet(ctx: Ctx) {
  await requirePanel(ctx)
  const st = String(ctx.query.get('status') || '')
  const rows = await q(`SELECT id, business_id, kind, to_addr, subject, status, attempts, last_error, provider, provider_id, created_at, sent_at FROM email_queue ${st ? 'WHERE status = $1' : ''} ORDER BY id DESC LIMIT 100`, st ? [st] : [])
  const cont = await q('SELECT status, COUNT(*) AS n FROM email_queue GROUP BY status')
  return { items: rows.map((r: any) => ({ ...r, id: Number(r.id), to_addr: String(r.to_addr).replace(/^(.{2}).*(@.*)$/, '$1***$2') })), contagem: Object.fromEntries(cont.map((r: any) => [r.status, Number(r.n)])) }
}

/** Testa a mensagem de follow-up: envia uma notificação de exemplo ao próprio administrador. */
export async function followupTestPost(ctx: Ctx) {
  const u = await requirePanel(ctx, true), { fupText } = await import('../lib/followup.js')
  const msgs = ctx.body?.msgs || (await getConfig<any>('followup', {})).msgs || {}
  const body = fupText(msgs.concluido || msgs.servico || msgs.venda || '', { cliente: 'Maria Souza', empresa: 'Minha Loja', data: new Date().toLocaleDateString('pt-BR'), servico: 'Corte de cabelo', dias: 7 }) || 'Acompanhamento de exemplo: Maria Souza · Corte de cabelo · há 7 dias'
  await (await import('../lib/notify.js')).notify(u.id, { type: 'followup', title: 'Teste · Acompanhamento: Maria Souza', body, link: '/', ref: 'followup-test:' + Date.now() })
  return { ok: true, body }
}

export async function mpOauthTestPost(ctx: Ctx) { await requirePanel(ctx, true); return (await import('./mpuser.js')).testApp() }
