// /api/panel — configurações do painel administrativo (módulos, IAs, fontes de mercado, Mercado Pago,
// planos de anúncio, cérebro, busca, parâmetros fiscais). Chaves secretas ficam cifradas e só voltam mascaradas.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { effectivePermissions, audit } from '../lib/account.js'
import { getConfig, setConfig, seal, unseal, maskSecret } from '../lib/settings.js'
import { MODULES_DEFAULT, AI_DEFAULT, AI_ROUTER_DEFAULT, MARKET_DEFAULT, MP_DEFAULT, PLANS_DEFAULT, BRAIN_DEFAULT, SEARCH_DEFAULT, FISCAL_DEFAULT, type AiProvider, type MarketProvider } from '../lib/panel-defaults.js'
import { aiRuntime, aiResume, testProvider, loadProviders, routerCfg } from '../ai/provider.js'
import { capsOf, kindOf } from '../ai/registry.js'
import { CAPS, CAP_LABEL, type Cap } from '../ai/types.js'
import { fetchQuote, marketProviders } from './market.js'
import { modules } from '../lib/usermod.js'
import { usageCfg, USAGE_KINDS } from '../lib/usage.js'
import { ENGINE_DEFAULT } from '../ai/provider.js'
import { config } from '../config.js'

async function requirePanel(ctx: Ctx, write = false) {
  const u = requireUser(ctx)
  if (u.role === 'user') fail(403, 'Área exclusiva dos administradores.', 'forbidden')
  const pol = await one("SELECT value FROM app_config WHERE key = 'security-policy'")
  if (J<any>(pol?.value, {}).adminMfaRequired && !u.mfa_enabled) fail(403, 'Ative a verificação em duas etapas para usar o painel.', 'mfa_required')
  if (write && !effectivePermissions(u).includes('panel.manage')) fail(403, 'Sem permissão para alterar o painel.', 'forbidden')
  return u
}
const isUrl = (v: string, httpsOnly = false) => (httpsOnly ? /^https:\/\/[^\s]+$/ : /^https?:\/\/[^\s]+$/).test(v)
const bool = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d)
const money = (v: unknown) => { const n = Number(v); return isFinite(n) && n >= 0 && n < 1e6 ? Math.round(n * 100) / 100 : null }
async function secret(incoming: unknown, old: string, clear?: unknown): Promise<string> {
  if (clear === true) return ''
  const s = typeof incoming === 'string' ? incoming.trim() : ''
  if (!s || s.includes('••')) return old || ''
  if (s.length < 8 || s.length > 400 || /\s/.test(s)) fail(400, 'A chave parece incompleta. Copie de novo no site do serviço.', 'invalid')
  return seal(s)
}
async function masked(sealed: string) { const p = await unseal(sealed); return { hasKey: !!p, keyMasked: maskSecret(p) } }

async function load() {
  const ai = await loadProviders()
  const mk = await getConfig<MarketProvider[]>('market_providers', [])
  return {
    modules: { ...MODULES_DEFAULT, ...(await getConfig('modules', {})) },
    ai_providers: ai,
    ai_router: await routerCfg(),
    market_providers: mk.length ? mk : MARKET_DEFAULT,
    mercadopago: { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) },
    ad_plans: (await getConfig<any[]>('ad_plans', [])).length ? await getConfig<any[]>('ad_plans', []) : PLANS_DEFAULT,
    brain: { ...BRAIN_DEFAULT, ...(await getConfig('brain', {})) },
    search: { ...SEARCH_DEFAULT, ...(await getConfig('search', {})) },
    fiscal: { ...FISCAL_DEFAULT, ...(await getConfig('fiscal', {})) },
    usage_plans: await usageCfg(),
    fin_dict: { items: [], ...(await getConfig<any>('fin_dict', {})) },
    pix: { expiraMin: 30, ...(await getConfig<any>('pix', {})) },
    engine: { ...ENGINE_DEFAULT, ...(await getConfig<any>('engine', {})) },
    agent_plan: { preco: 39.9, dias: 30, limiteDia: 300, ...(await getConfig<any>('agent_plan', {})) },
    ad_frequency: { ativo: true, cada: 6, intervaloMin: 30, ...(await getConfig<any>('ad_frequency', {})) },
    menu: { items: [], ...(await getConfig<any>('menu', {})) },
    quick_buttons: { enabled: true, custom: false, items: ['Quero organizar meu dia de hoje', 'Gastei 80 reais de gasolina', 'Me lembra da reunião amanhã às 9h', 'A conta de internet vence dia 15, 99 reais'], ...(await getConfig<any>('quick_buttons', {})) },
    chat_welcome: { ... (await import('../lib/panel-defaults.js')).CHAT_WELCOME_DEFAULT, ...(await getConfig<any>('chat_welcome', {})) },
  }
}

export async function panelGet(ctx: Ctx) {
  const u = await requirePanel(ctx)
  const c = await load()
  const mp = c.mercadopago
  const mpOut: any = { modo: mp.modo }
  for (const m of ['teste', 'producao']) {
    const x = mp[m] || {}
    mpOut[m] = { pub: x.pub || '', tok: await masked(x.tok), seg: await masked(x.seg) }
  }
  return {
    canWrite: effectivePermissions(u).includes('panel.manage'),
    modules: c.modules,
    ai_providers: await Promise.all(c.ai_providers.map(async (p) => ({ ...p, key: undefined, tipo: kindOf(p), caps: capsOf(p), modelo_audio: p.modelo_audio || '', ...(await masked(p.key)) }))),
    ai_router: c.ai_router, ai_caps: CAPS.map((k) => ({ id: k, label: CAP_LABEL[k] })),
    ai_runtime: await aiRuntime(),
    market_providers: await Promise.all(c.market_providers.map(async (p) => ({ ...p, key: undefined, ...(await masked(p.key)) }))),
    market_status: await getConfig('market-status', {}),
    mercadopago: mpOut,
    ad_plans: c.ad_plans, brain: c.brain, search: c.search, fiscal: c.fiscal, quick_buttons: c.quick_buttons, usage_plans: c.usage_plans, usage_kinds: USAGE_KINDS, fin_dict: c.fin_dict, pix: c.pix, engine: c.engine, agent_plan: c.agent_plan, ad_frequency: c.ad_frequency, menu: c.menu,
    chat_welcome: c.chat_welcome,
    tts: await (await import('../ai/tts.js')).ttsCfg(), ocr: { ativo: (await getConfig<any>('ocr', {})).ativo !== false, temChave: !!(await getConfig<any>('ocr', {})).key },
    baseUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
    webhookUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, '') + '/api/mercadopago/webhook',
  }
}

/** Configuração pública (sem segredos) usada pelo app e pelo chat. */
export async function panelPublicGet() {
  const c = await load()
  return { modules: c.modules, ad_plans: c.ad_plans, search: c.search, fiscal: c.fiscal, quick_buttons: c.quick_buttons, menu: c.menu, agent_plan: c.agent_plan, chat_welcome: c.chat_welcome }
}

export async function panelPut(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const key = ctx.params.key
  const b = ctx.body || {}
  const cur: any = await load()
  let next: any
  switch (key) {
    case 'modules': {
      next = { ...cur.modules }
      for (const k of Object.keys(MODULES_DEFAULT)) next[k] = bool(b[k], next[k])
      break
    }
    case 'ai_providers': {
      if (!Array.isArray(b.items) || b.items.length > 30) fail(400, 'Lista inválida.', 'invalid')
      const old = new Map<string, AiProvider>(cur.ai_providers.map((p: AiProvider) => [p.id, p]))
      next = []
      for (const it of b.items) {
        const id = str(it.id, 40)
        if (!/^[a-z0-9-]{2,40}$/.test(id)) fail(400, 'Identificador inválido.', 'invalid')
        const base = old.get(id) || AI_DEFAULT.find((p) => p.id === id)
        if (!base && !id.startsWith('c-')) fail(400, 'IA desconhecida.', 'invalid')
        const url = str(it.base_url ?? base?.base_url, 300)
        if (id !== 'servidor' && url && !isUrl(url)) fail(400, 'Endereço da IA inválido.', 'invalid')
        const modelo = str(it.modelo ?? base?.modelo, 100)
        if (modelo && !/^[\w.:\/@-]+$/.test(modelo)) fail(400, 'Nome de modelo inválido.', 'invalid')
        const tipo = ['openai', 'gemini', 'anthropic'].includes(it.tipo) ? it.tipo : (base as any)?.tipo || kindOf({ id, base_url: url })
        const mAudio = str(it.modelo_audio ?? (base as any)?.modelo_audio, 100)
        if (mAudio && !/^[\w.:\/@-]+$/.test(mAudio)) fail(400, 'Nome do modelo de áudio inválido.', 'invalid')
        let caps: Record<string, boolean> | undefined = (base as any)?.caps
        if (it.caps && typeof it.caps === 'object') { caps = { ...(caps || {}) }; for (const k of CAPS) if (typeof it.caps[k] === 'boolean') caps[k] = it.caps[k] }
        const texto = bool(it.texto ?? it.caps?.texto, base?.texto ?? true), imagem = bool(it.imagem ?? it.caps?.imagem, base?.imagem ?? false)
        if (caps) { caps.texto = texto; caps.imagem = imagem }
        next.push({ id, tipo, nome: str(it.nome ?? base?.nome, 60) || id, base_url: url, modelo, modelo_audio: mAudio, caps, texto, imagem,
          ativo: bool(it.ativo, base?.ativo ?? true), onde: base?.onde || 'IA cadastrada por você', key: await secret(it.key, base?.key || '', it.clearKey) })
        if (it.resume) aiResume(id)
      }
      if (!next.some((p: AiProvider) => p.id === 'servidor')) next.push({ ...AI_DEFAULT.find((p) => p.id === 'servidor')! })
      break
    }
    case 'ai_router': {
      const num = (v: unknown, d: number, lo: number, hi: number) => { const n = Number(v); return isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d }
      const cr = cur.ai_router, p = b.paralelo || {}, bk = b.breaker || {}, mo = b.monitor || {}
      next = {
        modo: ['equilibrado', 'prioridade', 'velocidade', 'qualidade'].includes(b.modo) ? b.modo : cr.modo,
        timeoutMs: num(b.timeoutMs, cr.timeoutMs, 3000, 120000), prazoMs: num(b.prazoMs, cr.prazoMs, 5000, 180000), tentativas: Math.round(num(b.tentativas, cr.tentativas, 0, 3)),
        breaker: { falhas: Math.round(num(bk.falhas, cr.breaker.falhas, 1, 20)), pausaSeg: num(bk.pausaSeg, cr.breaker.pausaSeg, 5, 3600), maxPausaSeg: num(bk.maxPausaSeg, cr.breaker.maxPausaSeg, 10, 86400) },
        paralelo: { ativo: bool(p.ativo, cr.paralelo.ativo), modo: p.modo === 'corrida' ? 'corrida' : p.modo === 'comparar' ? 'comparar' : cr.paralelo.modo, max: Math.round(num(p.max, cr.paralelo.max, 2, 4)),
          tarefas: Array.isArray(p.tarefas) ? p.tarefas.filter((x: unknown) => ['conversa', 'agente', 'contexto', 'analise', 'codigo', 'pesquisa'].includes(String(x))) : cr.paralelo.tarefas },
        monitor: { ativo: bool(mo.ativo, cr.monitor.ativo), minutos: Math.round(num(mo.minutos, cr.monitor.minutos, 1, 120)) },
      }
      break
    }
    case 'market_providers': {
      if (!Array.isArray(b.items) || b.items.length > 40) fail(400, 'Lista inválida.', 'invalid')
      const old = new Map<string, MarketProvider>(cur.market_providers.map((p: MarketProvider) => [p.id, p]))
      next = []
      for (const it of b.items) {
        const id = str(it.id, 40)
        const base = old.get(id) || MARKET_DEFAULT.find((p) => p.id === id)
        const custom = !base || base.custom
        if (!/^[a-z0-9-]{2,40}$/.test(id) || (!base && !id.startsWith('c-'))) fail(400, 'Fonte inválida.', 'invalid')
        const url = custom ? str(it.url, 400) : base!.url
        if (custom && !isUrl(url, process.env.NODE_ENV !== 'test')) fail(400, 'O endereço da fonte precisa começar com https://', 'invalid')
        const campo = custom ? str(it.campo, 120) : ''
        if (custom && !/^[\w.]+$/.test(campo)) fail(400, 'Informe o caminho do preço, por exemplo data.price', 'invalid')
        next.push({ id, nome: custom ? str(it.nome, 60) || id : base!.nome, cat: it.cat === 'bolsa' ? 'bolsa' : it.cat === 'cripto' ? 'cripto' : base!.cat, url, campo,
          precisaChave: custom ? false : base!.precisaChave, ativo: bool(it.ativo, base?.ativo ?? true), info: custom ? 'Fonte cadastrada por você' : base!.info, custom,
          key: await secret(it.key, base?.key || '', it.clearKey) })
      }
      break
    }
    case 'mercadopago': {
      next = { modo: b.modo === 'producao' ? 'producao' : 'teste', teste: { ...cur.mercadopago.teste }, producao: { ...cur.mercadopago.producao } }
      for (const m of ['teste', 'producao']) {
        const x = b[m]; if (!x) continue
        const pub = str(x.pub, 200)
        if (pub && !/^(APP_USR|TEST)-[\w-]{10,}$/.test(pub)) fail(400, 'A chave pública começa com TEST- ou APP_USR-.', 'invalid')
        if (typeof x.tok === 'string' && x.tok.trim() && !x.tok.includes('••') && !/^(APP_USR|TEST)-[\w-]{10,}$/.test(x.tok.trim())) fail(400, 'O Access Token começa com TEST- ou APP_USR-.', 'invalid')
        next[m] = { pub: x.clear ? '' : pub, tok: await secret(x.tok, next[m].tok, x.clear), seg: await secret(x.seg, next[m].seg, x.clear) }
      }
      break
    }
    case 'ad_plans': {
      if (!Array.isArray(b.items) || !b.items.length || b.items.length > 12) fail(400, 'Cadastre de 1 a 12 planos.', 'invalid')
      next = b.items.map((it: any) => {
        const preco = money(it.preco), dias = Number(it.dias), nivel = Number(it.nivel)
        const nome = str(it.nome, 60)
        if (!nome || preco === null || !(dias >= 1 && dias <= 365) || ![1, 2, 3, 4].includes(nivel)) fail(400, 'Plano inválido: confira nome, preço, dias e nível.', 'invalid')
        return { id: /^[\w-]{1,30}$/.test(String(it.id)) ? String(it.id) : 'p' + Math.random().toString(36).slice(2, 8), nome, preco, dias: Math.round(dias), nivel }
      })
      break
    }
    case 'quick_buttons': {
      const items = (Array.isArray(b.items) ? b.items : []).map((x: unknown) => str(x, 80)).filter(Boolean).slice(0, 8)
      next = { enabled: bool(b.enabled, cur.quick_buttons.enabled), custom: bool(b.custom, cur.quick_buttons.custom), items }
      break
    }
    case 'usage_plans': {
      const lim = (o: any) => { const r: Record<string, number | null> = {}; for (const k of Object.keys(USAGE_KINDS)) { const v = o?.[k]; r[k] = v === null || v === '' || v === undefined ? null : Math.max(0, Math.min(100000, Math.floor(Number(v)) || 0)) } return r }
      const plans = (Array.isArray(b.plans) ? b.plans : []).slice(0, 10).map((p: any, i: number) => ({ id: str(p.id, 20) || 'p' + (i + 1) + Date.now().toString(36).slice(-3), nome: str(p.nome, 40) || 'Plano', preco: Math.max(0.01, Math.round((Number(p.preco) || 0) * 100) / 100), dias: Math.min(365, Math.max(1, Math.floor(Number(p.dias) || 30))), ativo: p.ativo !== false, limites: lim(p.limites) }))
      next = { ativo: bool(b.ativo, false), free: { nome: str(b.free?.nome, 40) || 'Grátis', limites: lim(b.free?.limites) }, plans }
      break
    }
    case 'ad_frequency': next = { ativo: bool(b.ativo, true), cada: Math.min(100, Math.max(1, Math.floor(Number(b.cada)) || 6)), intervaloMin: Math.min(1440, Math.max(0, Math.floor(Number(b.intervaloMin)) || 0)) }; break
    case 'menu': next = { items: (Array.isArray(b.items) ? b.items : []).slice(0, 30).map((x: any) => ({ key: str(x.key, 40), label: str(x.label, 60), visible: x.visible !== false })).filter((x: any) => x.key) }; break
    case 'engine': { const n = (v: any, d: number) => Math.max(0, Math.min(100, Math.round(Number(v ?? d)))); next = { naturalidade: n(b.naturalidade, 75), personalidade: ['amigavel', 'profissional', 'divertido', 'direto'].includes(b.personalidade) ? b.personalidade : 'amigavel', personalidadeTexto: str(b.personalidadeTexto, 600), criatividade: n(b.criatividade, 45), contexto: n(b.contexto, 70), autonomia: n(b.autonomia, 55), precisao: n(b.precisao, 80) }; break }
    case 'agent_plan': next = { preco: Math.max(0.01, Math.round((Number(b.preco) || 39.9) * 100) / 100), dias: Math.min(365, Math.max(1, Math.floor(Number(b.dias)) || 30)), limiteDia: Math.min(100000, Math.max(10, Math.floor(Number(b.limiteDia)) || 300)) }; break
    case 'pix': next = { expiraMin: Math.min(1440, Math.max(5, Math.floor(Number(b.expiraMin)) || 30)) }; break
    case 'fin_dict': {
      const { FIN_CATS } = await import('../ai/fin.js')
      next = { items: (Array.isArray(b.items) ? b.items : []).slice(0, 300).map((e: any) => ({ tipo: e.tipo === 'income' ? 'income' : 'expense', cat: str(e.cat, 30), sub: str(e.sub, 40), words: (Array.isArray(e.words) ? e.words : String(e.words || '').split(',')).map((w: any) => str(w, 40).toLowerCase()).filter((w: string) => w.length >= 2).slice(0, 40) })).filter((e: any) => e.sub && e.words.length && (FIN_CATS as any)[e.tipo].includes(e.cat)) }
      break
    }
    case 'chat_welcome': next = {
      ativo: bool(b.ativo, cur.chat_welcome.ativo),
      saudacao: str(b.saudacao ?? cur.chat_welcome.saudacao, 80),
      titulo: str(b.titulo ?? cur.chat_welcome.titulo, 80),
      subtitulo: str(b.subtitulo ?? cur.chat_welcome.subtitulo, 120),
    }; break
    case 'tts': {
      const ok = ['openai', 'gemini', 'streamelements', 'google']
      next = { ativo: b.ativo !== false, ordem: (Array.isArray(b.ordem) ? b.ordem : ok).filter((x: any) => ok.includes(x)), vozOpenai: str(b.vozOpenai, 20) || 'nova', vozGemini: str(b.vozGemini, 20) || 'Kore', vozSE: str(b.vozSE, 20) || 'Vitoria', maxChars: Math.min(5000, Math.max(200, Math.floor(Number(b.maxChars)) || 3000)) }
      break
    }
    case 'ocr': next = { ativo: b.ativo !== false, key: str(b.key, 60) }; break
    case 'brain': next = { aprender: bool(b.aprender, cur.brain.aprender), cerebroPrimeiro: bool(b.cerebroPrimeiro, cur.brain.cerebroPrimeiro), fatos: bool(b.fatos, cur.brain.fatos) }; break
    case 'search': { const r = Number(b.raio); if (!(r >= 1 && r <= 100)) fail(400, 'Use um raio entre 1 e 100 km.', 'invalid'); next = { raio: r }; break }
    case 'fiscal': {
      const sm = money(b.sm), lim = money(b.limite)
      if (!sm || !lim) fail(400, 'Informe salário mínimo e limite válidos.', 'invalid')
      next = { sm, limite: lim }; break
    }
    default: fail(404, 'Configuração desconhecida.', 'not_found')
  }
  await setConfig(key, next)
  if (key === 'modules') await modules()
  await audit(u.id, 'panel.update', null, { key })
  return panelGet(ctx)
}

export async function panelTestPost(ctx: Ctx) {
  await requirePanel(ctx, true)
  const b = ctx.body || {}
  if (b.kind === 'ai') {
    const c = await load()
    const p = c.ai_providers.find((x: AiProvider) => x.id === b.id)
    if (!p) fail(404, 'IA não encontrada.', 'not_found')
    const only = Array.isArray(b.caps) ? (b.caps.filter((k: unknown) => (CAPS as string[]).includes(String(k))) as Cap[]) : undefined
    return testProvider(p!, only?.length ? only : undefined)
  }
  if (b.kind === 'ai_all') {
    const c = await load()
    const out: Record<string, any> = {}
    for (const p of c.ai_providers as AiProvider[]) if (p.ativo) { const r = await testProvider(p); if (r.checks.length || p.id !== 'servidor') out[p.id] = r }
    return { ok: Object.values(out).every((r: any) => r.ok), results: out }
  }
  if (b.kind === 'market') {
    const p = (await marketProviders()).find((x) => x.id === b.id)
    if (!p) fail(404, 'Fonte não encontrada.', 'not_found')
    const sym = p!.cat === 'cripto' ? 'BTC' : 'PETR4'
    try { const v = await fetchQuote(p!, sym); return { ok: true, message: `Funcionando: ${sym} = R$ ${v.price.toLocaleString('pt-BR', { maximumFractionDigits: 2 })}` } }
    catch (e: any) { return { ok: false, message: e?.message === 'sem chave' ? 'Esta fonte precisa de chave.' : 'Falhou: ' + (e?.message || 'erro') } }
  }
  if (b.kind === 'mp') {
    const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }, modo = b.modo === 'producao' ? 'producao' : b.modo === 'teste' ? 'teste' : mp.modo
    const tok = await unseal((mp[modo] || {}).tok || '')
    if (!tok) return { ok: false, message: 'Salve o Access Token deste modo antes de testar.' }
    try {
      const r = await fetch(`${(process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')}/users/me`, { headers: { Authorization: `Bearer ${tok}` } })
      const j: any = await r.json().catch(() => ({}))
      if (r.status === 401 || r.status === 403) return { ok: false, message: 'O Mercado Pago recusou o Access Token. Copie de novo em Suas integrações → Credenciais.' }
      if (!r.ok) return { ok: false, message: 'O Mercado Pago respondeu com erro ' + r.status + '.' }
      const isTest = tok.startsWith('TEST-')
      return { ok: true, message: `Conectado à conta ${j.nickname || j.email || j.id} (${isTest ? 'modo teste: os pagamentos são simulados' : 'produção: pagamentos reais'}). Pronto para gerar Pix.` }
    } catch (e: any) { return { ok: false, message: 'Sem conexão com o Mercado Pago: ' + (e?.message || 'erro') } }
  }
  fail(400, 'Teste inválido.', 'invalid')
}

// ─── Cérebro: gerenciamento das respostas aprendidas ───

export async function brainAnswersGet(ctx: Ctx) {
  await requirePanel(ctx)
  const term = str(ctx.query.get('q'), 100).toLowerCase()
  const limit = Math.min(200, Math.max(10, Number(ctx.query.get('limit')) || 80))
  const rows = await q(
    `SELECT id, user_id, question, answer, origin, uses, score, reviewed, created_at, updated_at
     FROM brain_answers
     WHERE ($1 = '' OR question ILIKE '%'||$1||'%' OR answer ILIKE '%'||$1||'%')
     ORDER BY updated_at DESC LIMIT $2`,
    [term, limit]
  )
  const answers = rows.map(r => ({
    id: Number(r.id), userId: r.user_id ? Number(r.user_id) : null,
    question: r.question, answer: r.answer, origin: r.origin,
    uses: Number(r.uses), score: Number(r.score), reviewed: !!r.reviewed,
    createdAt: r.created_at, updatedAt: r.updated_at
  }))
  // estatísticas de aprendizado
  const stats = await one(`SELECT 
    COUNT(*)::int as total,
    COALESCE(AVG(score),0) as avg_score,
    COALESCE(SUM(uses),0)::int as total_uses,
    COUNT(*) FILTER (WHERE reviewed)::int as reviewed,
    COUNT(*) FILTER (WHERE score >= 0.8)::int as high_score,
    COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '7 days')::int as last_7d
   FROM brain_answers`)
  const trend = await q(`
    SELECT to_char(d, 'YYYY-MM-DD') as day, COALESCE(cnt, 0)::int as count
    FROM generate_series(CURRENT_DATE - INTERVAL '29 days', CURRENT_DATE, '1 day') d
    LEFT JOIN (
      SELECT date_trunc('day', created_at)::date as day, COUNT(*)::int as cnt
      FROM brain_answers
      WHERE created_at > CURRENT_DATE - INTERVAL '29 days'
      GROUP BY 1
    ) t ON t.day = d
    ORDER BY d
  `)
  const top = await q(`
    SELECT question, uses, score, origin
    FROM brain_answers
    WHERE uses > 0
    ORDER BY uses DESC, score DESC
    LIMIT 10
  `)
  return { 
    answers, 
    stats: stats || { total: 0, avg_score: 0, total_uses: 0, reviewed: 0, high_score: 0, last_7d: 0 },
    trend: trend.map(r => ({ day: r.day, count: Number(r.count) })),
    top: top.map(r => ({ question: r.question, uses: Number(r.uses), score: Number(r.score), origin: r.origin }))
  }
}

export async function brainAnswerPut(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const id = Number(ctx.params?.id)
  const b = ctx.body || {}
  const row = await one('SELECT * FROM brain_answers WHERE id = $1', [id])
  if (!row) fail(404, 'Resposta não encontrada.', 'not_found')
  const question = b.question !== undefined ? str(b.question, 500) : row!.question
  const answer = b.answer !== undefined ? str(b.answer, 2000) : row!.answer
  const reviewed = typeof b.reviewed === 'boolean' ? b.reviewed : row!.reviewed
  if (!question.trim() || !answer.trim()) fail(400, 'Pergunta e resposta são obrigatórias.', 'invalid')
  await q('UPDATE brain_answers SET question = $1, answer = $2, reviewed = $3, updated_at = $5 WHERE id = $4',
    [question, answer, reviewed, id, new Date().toISOString()])
  await audit(u.id, 'brain.update', id, { question: question.slice(0, 80) })
  return { ok: true }
}

export async function brainAnswerDelete(ctx: Ctx) {
  const u = await requirePanel(ctx, true)
  const id = Number(ctx.params?.id)
  const r = await q('DELETE FROM brain_answers WHERE id = $1 RETURNING id', [id])
  if (!r.length) fail(404, 'Resposta não encontrada.', 'not_found')
  await audit(u.id, 'brain.delete', id, {})
  return { ok: true }
}

export async function ttsStatusGet(ctx: Ctx) {
  requireUser(ctx)
  const { ttsCfg } = await import('../ai/tts.js'); const c = await ttsCfg()
  return { available: !!c.ativo && c.ordem.length > 0, maxChars: c.maxChars, playback: 'manual', providers: c.ordem }
}
export async function ttsPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  const { synthesize, ttsCfg, ttsSignature } = await import('../ai/tts.js'); const c = await ttsCfg()
  if (!c.ativo) fail(503, 'A voz natural está desligada pelo administrador.', 'unavailable')
  let text = typeof b.text === 'string' ? str(b.text, 4000) : ''
  if (!text && b.messageId) { const m = await one('SELECT content FROM messages WHERE id = $1 AND user_id = $2', [Number(b.messageId), u.id]); text = m?.content || '' }
  if (!text && b.preview) text = 'Olá! Esta é a voz natural do Meu Assistente. Posso ler suas respostas em voz alta.'
  if (!text.trim()) fail(400, 'Nenhum texto para falar.', 'invalid')
  if (text.length > c.maxChars) fail(413, 'Resposta longa demais para a voz natural.', 'too_long')
  const sig = ttsSignature(text, c.ordem)
  if (b.have && b.have === sig) return { _binary: true, status: 204, mime: '', data: null }
  const r = await synthesize(text)
  if (!r) fail(503, 'A voz natural não respondeu agora: usando a voz do aparelho.', 'unavailable')
  return { _binary: true, mime: r!.mime, data: r!.audio, headers: { 'X-Voice-Name': encodeURIComponent(`${r!.provider} · ${r!.voice}`), 'X-Voice-Signature': sig } }
}

export async function ollamaModelsGet(ctx: Ctx) {
  await requirePanel(ctx)
  const base = config.ai.baseUrl.replace(/\/v1\/?$/, '')
  if (!base || !/localhost|127\.0\.0\.1|ollama|:11434/.test(base)) return { models: [], note: 'IA local não parece ser Ollama.' }
  try {
    const r = await fetch(base + '/api/tags', { signal: AbortSignal.timeout(4000) })
    if (!r.ok) return { models: [], note: 'Não consegui consultar o Ollama.' }
    const j: any = await r.json()
    const models = (j.models || []).map((m: any) => ({ name: m.name, size: m.size, modified: m.modified_at }))
    return { models, current: config.ai.model }
  } catch { return { models: [], note: 'Ollama não respondeu.' } }
}
