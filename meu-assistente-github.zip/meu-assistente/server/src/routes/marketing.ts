// Central de Marketing (dono da empresa) e privacidade (cliente).
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { q, one, J } from '../db/index.js'
import * as M from '../lib/marketing.js'
export async function mktGet(ctx: Ctx) {
  const u = requireUser(ctx), pl = await M.ownerPlan(u.id)
  const consent = await q("SELECT c.origem, c.criado_em, c.status, u.name FROM marketing_consents c JOIN users u ON u.id = c.user_id WHERE c.owner_id = $1 ORDER BY c.criado_em DESC LIMIT 300", [u.id])
  const camps = await q('SELECT * FROM mkt_campaigns WHERE owner_id = $1 ORDER BY id DESC LIMIT 50', [u.id])
  return { ...pl, publico: { autorizados: consent.filter((c: any) => c.status === 'ativo').length, revogados: consent.filter((c: any) => c.status !== 'ativo').length, convite: consent.filter((c: any) => c.status === 'ativo' && /^convite/.test(c.origem)).length, pedido: consent.filter((c: any) => c.status === 'ativo' && /^pedido/.test(c.origem)).length },
    clientes: pl.limites.relatorios ? consent.map((c: any) => ({ nome: String(c.name || '').split(' ')[0], origem: /^convite/.test(c.origem) ? 'convite de compromisso' : /^pedido/.test(c.origem) ? 'pedido' : c.origem, desde: c.criado_em, status: c.status })) : [],
    campanhas: camps.map((c: any) => ({ id: Number(c.id), titulo: c.titulo, mensagem: c.mensagem, link: c.link, status: c.status, agendadaPara: c.agendada_para, criadaEm: c.criada_em, concluidaEm: c.concluida_em, total: c.total, enviados: c.enviados, pushOk: pl.limites.relatorios ? c.push_ok : null, ignorados: c.ignorados, cliques: pl.limites.relatorios ? c.cliques : null, erro: c.erro, segmento: J<any>(c.segmento, {}) })),
    modelos: [{ titulo: 'Novidade na casa', mensagem: 'Temos novidade esperando por você! Toque para conferir.' }, { titulo: 'Oferta da semana', mensagem: 'Só esta semana: condição especial para clientes. Toque para ver.' }, { titulo: 'Horários disponíveis', mensagem: 'Abrimos novos horários. Garanta o seu antes que acabem!' }] }
}
export async function mktPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  if (b.action === 'criar') { const c: any = await M.createCampaign(u.id, b); return { ok: true, campanha: { id: Number(c.id), status: c.status, total: c.total, agendadaPara: c.agendada_para } } }
  if (b.action === 'cancelar') { const r = await q("UPDATE mkt_campaigns SET status = 'cancelada' WHERE id = $1 AND owner_id = $2 AND status = 'agendada' RETURNING id", [Number(b.id), u.id]); if (!r.length) fail(400, 'Só campanhas ainda não enviadas podem ser canceladas.', 'invalid'); return { ok: true } }
  if (b.action === 'publico') { const pl = await M.ownerPlan(u.id); return { total: (await M.audience(u.id, pl.limites.segmentacao ? b.segmento || {} : {})).length } }
  fail(400, 'Ação inválida.', 'invalid')
}
export async function mktClickGet(ctx: Ctx) { const [id, s] = String(ctx.params.id || '').split('.'); const to = await M.clickRedirect(Number(id), String(s || ctx.query.get('s') || '')); return { to } }
export async function mktUnsubGet(ctx: Ctx) {
  const o = Number(ctx.query.get('o')), uid = Number(ctx.query.get('u')), ok = M.checkUnsub(o, uid, String(ctx.query.get('s') || ''))
  if (ok) await M.setConsent(o, uid, false, 'descadastro')
  ctx.res.writeHead(ok ? 200 : 400, { 'Content-Type': 'text/html; charset=utf-8' })
  ctx.res.end(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#0b0d12;color:#e8eaf0;padding:40px 20px;text-align:center"><h1 style="font-size:20px">${ok ? 'Pronto, você não vai mais receber ofertas desta empresa.' : 'Link inválido.'}</h1><p><a href="/" style="color:#7aa2ff">Abrir o Meu Assistente</a></p></body>`)
  return { _handled: true }
}
/** Cliente: ver e cancelar as autorizações de ofertas que deu. */
export async function myConsentsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const rows = await q("SELECT c.owner_id, c.origem, c.criado_em, c.status, b.data FROM marketing_consents c LEFT JOIN businesses b ON b.owner_id = c.owner_id AND b.status = 'ativo' WHERE c.user_id = $1 ORDER BY c.criado_em DESC", [u.id])
  const vist = new Set<number>(); const out: any[] = []
  for (const r of rows) { if (vist.has(Number(r.owner_id))) continue; vist.add(Number(r.owner_id)); const ow = await one('SELECT name FROM users WHERE id = $1', [r.owner_id]); out.push({ ownerId: Number(r.owner_id), nome: J<any>(r.data, {}).empresa || String(ow?.name || '').split(' ')[0], status: r.status, desde: r.criado_em, origem: r.origem }) }
  return { items: out }
}
export async function myConsentsPost(ctx: Ctx) { const u = requireUser(ctx); return M.setConsent(Number(ctx.body?.ownerId), u.id, ctx.body?.aceito === true, ctx.body?.aceito ? 'perfil' : 'perfil') }
