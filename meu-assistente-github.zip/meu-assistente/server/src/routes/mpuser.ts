// Financeiro → Mercado Pago: conexão real da conta do usuário pelo OAuth oficial do Mercado Pago e
// leitura dos pagamentos recebidos pela API oficial (/v1/payments/search). Nada é simulado.
// O administrador cadastra a aplicação (Client ID e Client Secret) em Painel → Mercado Pago.
import { randomBytes } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig, seal, unseal } from '../lib/settings.js'
import { getUM, setUM } from '../lib/usermod.js'
import { pub } from '../lib/publicurl.js'
export { app as mpApp }
const API = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
const AUTH = () => (process.env.MP_AUTH_BASE || 'https://auth.mercadopago.com').replace(/\/$/, '')
const redirectUri = () => `${pub()}/api/mercadopago/oauth/callback`
async function app() { const c = await getConfig<any>('mp_oauth', {}); return { clientId: String(c.clientId || ''), clientSecret: await unseal(c.clientSecret || '').catch(() => '') } }
export async function appConfigured() { const a = await app(); return !!(a.clientId && a.clientSecret) }
export async function globalWebhookSecret() { const c = await getConfig<any>('mp_oauth', {}); return c.exigirAssinatura && c.webhookSecret ? await unseal(c.webhookSecret).catch(() => '') : '' }
/** Empresa pode receber pelo Mercado Pago? (plano empresarial ativo, conforme o painel) */
export async function planAllowed(b: any) {
  if (!b || b.status !== 'ativo' || (b.expires_at && Date.parse(b.expires_at) < Date.now())) return false
  const c = await getConfig<any>('mp_oauth', {}); const ads: any[] = await getConfig<any[]>('ad_plans', [])
  const lista: string[] = Array.isArray(c.planos) && c.planos.length ? c.planos : (ads.length ? ads.filter((p) => Number(p.nivel) >= 4).map((p) => p.id) : ['n4'])
  return lista.includes(String(b.plan_id))
}
/** Renova o token de acesso (grant_type=refresh_token) com as credenciais da aplicação. */
export async function refreshToken(refresh: string): Promise<{ access: string; refresh: string; exp: number } | null> {
  const a = await app(); if (!a.clientId || !a.clientSecret || !refresh) return null
  const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: a.clientId, client_secret: a.clientSecret, grant_type: 'refresh_token', refresh_token: refresh }) }).catch(() => null)
  const j: any = r ? await r.json().catch(() => ({})) : {}
  return r && r.ok && j.access_token ? { access: j.access_token, refresh: j.refresh_token || refresh, exp: Date.now() + (Number(j.expires_in) || 15552000) * 1000 } : null
}
/** Valida Client ID/Secret no Mercado Pago (grant_type=client_credentials). */
export async function testApp() {
  const a = await app(); if (!a.clientId || !a.clientSecret) return { ok: false, mensagem: 'Preencha o Client ID e o Client Secret.' }
  try { const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: a.clientId, client_secret: a.clientSecret, grant_type: 'client_credentials' }) }); const j: any = await r.json().catch(() => ({}))
    return r.ok && j.access_token ? { ok: true, mensagem: `Credenciais válidas${/^TEST-/.test(j.access_token) ? ' (ambiente de teste)' : ''}. A conexão automática das empresas está pronta.` } : { ok: false, mensagem: `O Mercado Pago recusou as credenciais (${r.status}${j.message ? ': ' + j.message : ''}).` } }
  catch { return { ok: false, mensagem: 'Sem conexão com o Mercado Pago.' } }
}
export async function businessAuthUrl(userId: number, bid: number) {
  const ap = await app(); if (!ap.clientId || !ap.clientSecret) fail(400, 'A conexão automática ainda não foi configurada pelo administrador. Use "Prefiro configurar manualmente".', 'not_configured')
  const state = randomBytes(16).toString('hex'); await setUM(userId, 'mp_oauth_state', { state, at: Date.now(), bid })
  return `${AUTH()}/authorization?client_id=${encodeURIComponent(ap.clientId)}&response_type=code&platform_id=mp&state=${state}&redirect_uri=${encodeURIComponent(redirectUri())}`
}
type Conn = { access: string; refresh: string; userId: number | null; expiresAt: number; account: any; lastSyncAt?: string; status: string; test?: boolean }
const connOut = (c: Conn | null) => c ? { connected: c.status !== 'expired', status: c.status, account: c.account || null, lastSyncAt: c.lastSyncAt || null, syncPartial: false, test: !!c.test } : { connected: false, status: 'disconnected', account: null, lastSyncAt: null }
async function token(u: number): Promise<{ c: Conn; tok: string } | null> {
  const c = await getUM<Conn | null>(u, 'mp_user', null); if (!c) return null
  let tok = await unseal(c.access).catch(() => '')
  if (c.expiresAt && Date.now() > c.expiresAt - 86400_000 && c.refresh) { // renova antes de expirar
    const a = await app(); const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: a.clientId, client_secret: a.clientSecret, grant_type: 'refresh_token', refresh_token: await unseal(c.refresh) }) })
    const j: any = await r.json().catch(() => ({}))
    if (r.ok && j.access_token) { tok = j.access_token; c.access = await seal(j.access_token); if (j.refresh_token) c.refresh = await seal(j.refresh_token); c.expiresAt = Date.now() + (Number(j.expires_in) || 15552000) * 1000; c.status = 'connected'; await setUM(u, 'mp_user', c) }
    else if (Date.now() > c.expiresAt) { c.status = 'expired'; await setUM(u, 'mp_user', c); return null }
  }
  return { c, tok }
}
const PER: Record<string, string> = { today: 'Hoje', yesterday: 'Ontem', last_7_days: 'Últimos 7 dias', this_week: 'Esta semana', this_month: 'Este mês', last_month: 'Mês passado', last_30_days: 'Últimos 30 dias', last_90_days: 'Últimos 90 dias', custom: 'Período escolhido' }
function range(period: string, from?: string, to?: string) {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' })), d0 = new Date(now); d0.setHours(0, 0, 0, 0)
  const day = 86400_000; let a = d0.getTime(), b = now.getTime()
  if (period === 'yesterday') { a -= day; b = d0.getTime() - 1 } else if (period === 'last_7_days') a -= 6 * day; else if (period === 'last_30_days') a -= 29 * day; else if (period === 'last_90_days') a -= 89 * day
  else if (period === 'this_week') a -= ((d0.getDay() + 6) % 7) * day; else if (period === 'this_month') a = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime()
  else if (period === 'last_month') { a = new Date(d0.getFullYear(), d0.getMonth() - 1, 1).getTime(); b = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime() - 1 }
  else if (period === 'custom' && from) { a = Date.parse(from + 'T00:00:00-03:00'); b = to ? Date.parse(to + 'T23:59:59-03:00') : b }
  const iso = (t: number) => new Date(t).toISOString().replace('Z', '-00:00')
  return { begin: iso(a), end: iso(b), label: PER[period] || PER.this_month }
}
const GROUP: Record<string, string> = { approved: 'approved', authorized: 'pending', pending: 'pending', in_process: 'pending', in_mediation: 'pending', rejected: 'rejected', cancelled: 'rejected', refunded: 'refunded', charged_back: 'refunded' }
const LABEL: Record<string, string> = { approved: 'Aprovado', authorized: 'Autorizado', pending: 'Pendente', in_process: 'Em análise', in_mediation: 'Em disputa', rejected: 'Recusado', cancelled: 'Cancelado', refunded: 'Reembolsado', charged_back: 'Estornado' }
export async function mpUserGet(ctx: Ctx) {
  const u = requireUser(ctx), q = ctx.query
  const t = await token(u.id)
  const base: any = { connection: connOut(t?.c || (await getUM<Conn | null>(u.id, 'mp_user', null))), balance: { reason: 'O Mercado Pago não disponibiliza o saldo da conta pela API para aplicações de terceiros. Consulte o saldo no app do Mercado Pago.' } }
  if (!t) return base
  const period = String(q.get('period') || 'this_month'), page = Math.max(1, Number(q.get('page')) || 1), status = String(q.get('status') || '')
  const r0 = range(period, q.get('from') || undefined, q.get('to') || undefined), limit = 30
  const url = `${API()}/v1/payments/search?sort=date_created&criteria=desc&range=date_created&begin_date=${encodeURIComponent(r0.begin)}&end_date=${encodeURIComponent(r0.end)}&limit=100&offset=0`
  try {
    const r = await fetch(url, { headers: { Authorization: `Bearer ${t.tok}` } })
    if (r.status === 401) { t.c.status = 'expired'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c) } }
    const j: any = await r.json(); if (!r.ok) throw new Error(j.message || `Mercado Pago respondeu ${r.status}`)
    const all = (j.results || []).filter((p: any) => !t.c.userId || !p.collector_id || Number(p.collector_id) === Number(t.c.userId)) // só o que esta conta recebeu
    const sum = (f: (p: any) => boolean, k = 'transaction_amount') => Math.round(all.filter(f).reduce((a: number, p: any) => a + Number(p[k] || 0), 0) * 100) / 100
    const fees = (p: any) => (p.fee_details || []).reduce((a: number, f: any) => a + Number(f.amount || 0), 0)
    const appr = all.filter((p: any) => p.status === 'approved')
    const totals = { currency: 'BRL', gross: sum((p) => p.status === 'approved'), approvedCount: appr.length, fees: Math.round(appr.reduce((a: number, p: any) => a + fees(p), 0) * 100) / 100, net: 0, pendingCount: all.filter((p: any) => GROUP[p.status] === 'pending').length, pendingAmount: sum((p) => GROUP[p.status] === 'pending'), refundedCount: all.filter((p: any) => GROUP[p.status] === 'refunded').length, refundedAmount: sum((p) => GROUP[p.status] === 'refunded'), refundedPartial: Math.round(appr.reduce((a: number, p: any) => a + Number(p.transaction_amount_refunded || 0), 0) * 100) / 100, rejectedCount: all.filter((p: any) => GROUP[p.status] === 'rejected').length }
    totals.net = Math.round((totals.gross - totals.fees - totals.refundedPartial) * 100) / 100
    const list = all.filter((p: any) => !status || GROUP[p.status] === status)
    const payments = list.slice((page - 1) * limit, page * limit).map((p: any) => ({ id: String(p.id), description: p.description || '', paymentType: p.payment_type_id, method: p.payment_method_id, amount: Number(p.transaction_amount), currency: p.currency_id || 'BRL', feeTotal: Math.round(fees(p) * 100) / 100, net: Number(p.transaction_details?.net_received_amount ?? 0), status: p.status, statusLabel: LABEL[p.status] || p.status, statusDetail: p.status_detail, group: GROUP[p.status] || '', dateCreated: p.date_created, dateApproved: p.date_approved, payer: p.payer?.email ? { email: String(p.payer.email).replace(/^(.{2}).*(@.*)$/, '$1***$2') } : null, installments: p.installments, externalReference: p.external_reference || '' }))
    t.c.lastSyncAt = new Date().toISOString(); t.c.status = 'connected'; await setUM(u.id, 'mp_user', t.c)
    return { ...base, connection: connOut(t.c), period: { key: period, label: r0.label }, totals, payments, pages: Math.max(1, Math.ceil(list.length / limit)), page, truncated: (j.paging?.total || 0) > 100 }
  } catch (e: any) { t.c.status = 'error'; await setUM(u.id, 'mp_user', t.c); return { ...base, connection: connOut(t.c), refreshError: String(e?.message || e).slice(0, 160) } }
}
export async function mpUserPost(ctx: Ctx) {
  const u = requireUser(ctx), a = String(ctx.body?.action || '')
  if (a === 'connect') {
    const ap = await app(); if (!ap.clientId || !ap.clientSecret) fail(400, 'A integração ainda não foi configurada pelo administrador do sistema (Painel → Mercado Pago → Conexão das contas dos usuários).', 'not_configured')
    const state = randomBytes(16).toString('hex'); await setUM(u.id, 'mp_oauth_state', { state, at: Date.now() })
    return { url: `${AUTH()}/authorization?client_id=${encodeURIComponent(ap.clientId)}&response_type=code&platform_id=mp&state=${state}&redirect_uri=${encodeURIComponent(redirectUri())}` }
  }
  if (a === 'disconnect') { await setUM(u.id, 'mp_user', null); return { connection: connOut(null) } }
  if (a === 'refresh' || a === 'sync') { const t = await token(u.id); return { connection: connOut(t?.c || null) } }
  fail(400, 'Ação inválida.', 'invalid')
}
/** Volta do Mercado Pago com o código de autorização: troca por tokens (no servidor) e guarda criptografado. */
export async function mpUserCallback(ctx: Ctx) {
  const u = ctx.user
  const st = u ? await getUM<any>(u.id, 'mp_oauth_state', null) : null; if (u) await setUM(u.id, 'mp_oauth_state', null)
  const go = (q: string) => { ctx.res.writeHead(302, { Location: st?.bid ? `/x/sua-empresa?${q}&loja=${st.bid}` : `/financeiro?tab=mercadopago&${q}` }); ctx.res.end(); return { _handled: true } }
  if (!u) return go('mp=erro&motivo=state')
  if (ctx.query.get('error')) return go('mp=erro&motivo=denied')
  if (!st || st.state !== ctx.query.get('state') || Date.now() - st.at > 15 * 60_000) return go('mp=erro&motivo=state')
  const code = String(ctx.query.get('code') || ''); if (!code) return go('mp=erro&motivo=invalid')
  const ap = await app(); if (!ap.clientId || !ap.clientSecret) return go('mp=erro&motivo=not_configured')
  const r = await fetch(`${API()}/oauth/token`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: ap.clientId, client_secret: ap.clientSecret, grant_type: 'authorization_code', code, redirect_uri: redirectUri() }) })
  const j: any = await r.json().catch(() => ({})); if (!r.ok || !j.access_token) return go('mp=erro&motivo=provider')
  const me: any = await (await fetch(`${API()}/users/me`, { headers: { Authorization: `Bearer ${j.access_token}` } })).json().catch(() => ({}))
  if (st.bid) { // conta da EMPRESA: tokens próprios, guardados criptografados só no servidor
    const { q, one, nowIso } = await import('../db/index.js')
    const b = await one('SELECT * FROM businesses WHERE id = $1 AND owner_id = $2', [st.bid, u.id]); if (!b || !(await planAllowed(b))) return go('mp=erro&motivo=invalid')
    const d = typeof b.data === 'string' ? JSON.parse(b.data) : (b.data || {})
    Object.assign(d, { mpTok: await seal(j.access_token), mpRefresh: j.refresh_token ? await seal(j.refresh_token) : '', mpExp: Date.now() + (Number(j.expires_in) || 15552000) * 1000, mpUserId: Number(j.user_id || me.id) || null, mpModo: 'oauth', mpConta: { nickname: me.nickname || '', email: me.email ? String(me.email).replace(/^(.{2}).*(@.*)$/, '$1***$2') : '' } })
    d.pagamento = { ...(d.pagamento || {}), online: true }
    await q('UPDATE businesses SET data = $1, updated_at = $2 WHERE id = $3', [JSON.stringify(d), nowIso(), b.id])
    return go('mp=conectado')
  }
  await setUM(u.id, 'mp_user', { access: await seal(j.access_token), refresh: j.refresh_token ? await seal(j.refresh_token) : '', userId: Number(j.user_id || me.id) || null, expiresAt: Date.now() + (Number(j.expires_in) || 15552000) * 1000, account: { id: me.id || j.user_id, nickname: me.nickname || '', name: [me.first_name, me.last_name].filter(Boolean).join(' '), email: me.email ? String(me.email).replace(/^(.{2}).*(@.*)$/, '$1***$2') : '' }, status: 'connected', test: /^TEST-/.test(j.access_token) })
  return go('mp=conectado')
}
