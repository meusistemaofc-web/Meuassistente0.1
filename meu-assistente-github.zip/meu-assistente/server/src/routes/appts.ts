// Compartilhar um compromisso: link público que mostra só aquele compromisso e convida a pessoa para o Meu Assistente.
import { randomBytes } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { setUM } from '../lib/usermod.js'
import { config } from '../config.js'

async function ownAppt(ctx: Ctx) {
  const u = requireUser(ctx)
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(ctx.params.id), u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  return { u, r: r! }
}
const view = (r: any) => { const d = J<any>(r.data, {}); return { id: Number(r.id), title: d.title, date: r.day, time: d.time || null, endTime: d.endTime || null, location: d.location || '', person: d.person || '', notes: d.notes || '', reminderMinutes: d.reminderMinutes ?? 0 } }
export async function apptGet(ctx: Ctx) { const { r } = await ownAppt(ctx); return view(r) }
export async function apptSharePost(ctx: Ctx) {
  const { u, r } = await ownAppt(ctx)
  const d = J<any>(r.data, {})
  let token = d.shareToken
  if (!token) {
    token = randomBytes(9).toString('base64url')
    d.shareToken = token
    await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r.id])
    await setUM(u.id, 'share:' + token, { itemId: Number(r.id) })
  }
  return { url: `${config.publicUrl}/c/${token}`, token }
}
export async function sharePublicGet(ctx: Ctx) {
  const token = String(ctx.params.token || '').slice(0, 40)
  const s = await one('SELECT user_id, value FROM user_modules WHERE key = $1', ['share:' + token])
  if (!s) fail(404, 'Este convite não existe ou foi removido.', 'not_found')
  const v = J<any>(s!.value, {})
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(v.itemId), Number(s!.user_id)])
  if (!r || J<any>(r.data, {}).shareToken !== token) fail(404, 'Este compromisso foi removido.', 'not_found')
  const owner = await one('SELECT name FROM users WHERE id = $1', [s!.user_id])
  const it = view(r); delete (it as any).id
  return { ...it, notes: '', convidadoPor: String(owner?.name || '').split(' ')[0] || 'Alguém', app: config.publicUrl }
}

/* ---------- contrato do app original: janela "Compartilhar compromisso" (ícone de avião no cartão) ---------- */
async function ensureToken(u: { id: number }, r: any) {
  const d = J<any>(r.data, {}); if (d.shareToken) return d.shareToken
  const token = randomBytes(9).toString('base64url'); d.shareToken = token
  await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r.id]); await setUM(u.id, 'share:' + token, { itemId: Number(r.id) })
  return token
}
export async function appointmentsLegacyGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.query.get('id'))
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [id, u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  const a = view(r), end = new Date(`${a.date}T${a.endTime || a.time || '23:59'}:00-03:00`)
  const d = J<any>(r!.data, {})
  return { appointment: a, organizerName: u.name, ended: Date.now() > end.getTime(), participants: d.shareToken ? [{ id: 1, name: 'Link de convite', contact: '', personal: false, status: 'invited', statusLabel: 'Link ativo', link: `${config.publicUrl}/c/${d.shareToken}` }] : [], invites: [], settings: {}, reminders: [] }
}
export async function appointmentsLegacyPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(b.id), u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  if (b.action === 'invite.create') { const token = await ensureToken(u, r); return { ok: true, invites: [{ link: `${config.publicUrl}/c/${token}`, existing: false }] } }
  if (b.action === 'invite.remove') { const d = J<any>(r!.data, {}); if (d.shareToken) { await q('DELETE FROM user_modules WHERE user_id = $1 AND key = $2', [u.id, 'share:' + d.shareToken]); delete d.shareToken; await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r!.id]) } return { ok: true } }
  if (b.action === 'cancel') { await q('DELETE FROM items WHERE id = $1 AND user_id = $2', [r!.id, u.id]); return { ok: true } }
  return { ok: true }
}
