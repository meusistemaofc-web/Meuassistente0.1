import { nowIso } from '../db/index.js'
import { pub } from '../lib/publicurl.js'
// Compartilhar um compromisso: link público que mostra só aquele compromisso e convida a pessoa para o Meu Assistente.
import { randomBytes } from 'node:crypto'
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { q, one, J } from '../db/index.js'
import { requireUser } from '../lib/session.js'
import { setUM } from '../lib/usermod.js'
import { config } from '../config.js'

async function ownAppt(ctx: Ctx) {
  const u = requireUser(ctx)
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(ctx.params.id), u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  return { u, r: r! }
}
const view = (r: any) => { const d = J<any>(r.data, {}); return { id: Number(r.id), title: d.title, date: r.day, time: d.time || null, endTime: d.endTime || null, location: d.location || '', person: d.person || '', notes: d.notes || '', reminderMinutes: d.reminderMinutes ?? 0 } }
export async function itemGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const r = await one('SELECT * FROM items WHERE id = $1 AND user_id = $2', [Number(ctx.params.id), u.id])
  if (!r) fail(404, 'Item não encontrado.', 'not_found')
  const { serialize, hydrate } = await import('./items.js'); return { type: r!.type, ...serialize(hydrate(r)) }
}
export async function apptGet(ctx: Ctx) { const { r } = await ownAppt(ctx); return view(r) }
export async function apptSharePost(ctx: Ctx) {
  const { u, r } = await ownAppt(ctx)
  const d = J<any>(r.data, {})
  let token = d.shareToken
  if (!token) {
    token = randomBytes(9).toString('base64url')
    d.shareToken = token
    await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r.id])
    await setUM(u.id, 'share:' + token, { itemId: Number(r.id), createdAt: nowIso() })
  }
  const { inviteText } = await import('../lib/invite.js')
  return { url: `${pub()}/c/${token}`, token, mensagem: await inviteText(u.name, `${pub()}/c/${token}`, d.clienteNome || d.person || ''), telefone: d.clienteTelefone ? (String(d.clienteTelefone).length <= 11 ? '55' + d.clienteTelefone : d.clienteTelefone) : '' }
}
export async function sharePublicGet(ctx: Ctx) {
  const token = String(ctx.params.token || '').slice(0, 40)
  const s = await one('SELECT user_id, value FROM user_modules WHERE key = $1', ['share:' + token])
  if (!s) fail(404, 'Este convite não existe ou foi removido.', 'not_found')
  const v = J<any>(s!.value, {})
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(v.itemId), Number(s!.user_id)])
  if (!r || J<any>(r.data, {}).shareToken !== token) fail(404, 'Este compromisso foi removido.', 'not_found')
  const owner = await one('SELECT name FROM users WHERE id = $1', [s!.user_id])
  const it: any = view(r); delete it.id
  const dd = J<any>(r!.data, {})
  // página pública: serviço, cliente (o próprio convidado), data e horário; telefone e observações internas NUNCA saem daqui
  delete it.person; delete it.clienteTelefone; delete it.valorTotal; delete it.sinal; delete it.responsavel
  return { ...it, notes: '', servico: dd.title || '', cliente: dd.clienteNome || dd.person || '', convidadoPor: String(owner?.name || '').split(' ')[0] || 'Alguém', app: pub() }
}

/* ---------- contrato do app original: janela "Compartilhar compromisso" (ícone de avião no cartão) ---------- */
async function ensureToken(u: { id: number }, r: any) {
  const d = J<any>(r.data, {}); if (d.shareToken) return d.shareToken
  const token = randomBytes(9).toString('base64url'); d.shareToken = token
  await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r.id]); await setUM(u.id, 'share:' + token, { itemId: Number(r.id), createdAt: nowIso() })
  return token
}
export async function appointmentsLegacyGet(ctx: Ctx) {
  const u = requireUser(ctx), id = Number(ctx.query.get('id'))
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [id, u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  const a = view(r), end = new Date(`${a.date}T${a.endTime || a.time || '23:59'}:00-03:00`)
  const d = J<any>(r!.data, {})
  return { appointment: a, organizerName: u.name, ended: Date.now() > end.getTime(), participants: d.shareToken ? [{ id: 1, name: 'Link de convite', contact: '', personal: false, status: 'invited', statusLabel: 'Link ativo', link: `${pub()}/c/${d.shareToken}` }] : [], invites: [], settings: {}, reminders: [] }
}
export async function appointmentsLegacyPost(ctx: Ctx) {
  const u = requireUser(ctx), b = ctx.body || {}
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(b.id), u.id])
  if (!r) fail(404, 'Compromisso não encontrado.', 'not_found')
  if (b.action === 'invite.create') { const token = await ensureToken(u, r); return { ok: true, invites: [{ link: `${pub()}/c/${token}`, existing: false }] } }
  if (b.action === 'invite.remove') { const d = J<any>(r!.data, {}); if (d.shareToken) { await q('DELETE FROM user_modules WHERE user_id = $1 AND key = $2', [u.id, 'share:' + d.shareToken]); delete d.shareToken; await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(d), r!.id]) } return { ok: true } }
  if (b.action === 'cancel') { await q('DELETE FROM items WHERE id = $1 AND user_id = $2', [r!.id, u.id]); return { ok: true } }
  return { ok: true }
}

/** "Adicionar lembrete" na página do convite: salva o compromisso na agenda de quem abriu (uma vez só por convite). */
export async function shareSavePost(ctx: Ctx) {
  const u = requireUser(ctx), token = String(ctx.params.token || '').slice(0, 40)
  const s = await one('SELECT user_id, value FROM user_modules WHERE key = $1', ['share:' + token])
  if (!s) fail(404, 'Este convite não existe ou foi removido.', 'not_found')
  const v = J<any>(s!.value, {})
  const r = await one("SELECT * FROM items WHERE id = $1 AND user_id = $2 AND type = 'appointment'", [Number(v.itemId), Number(s!.user_id)])
  if (!r || J<any>(r.data, {}).shareToken !== token) fail(404, 'Este compromisso foi removido.', 'not_found')
  if (Number(s!.user_id) === u.id) return { ok: true, id: Number(r!.id), already: true, own: true, reminders: J<any>(r!.data, {}).reminders || [] }
  // já salvo antes por este usuário? não duplica
  for (const it of await q("SELECT id, data FROM items WHERE user_id = $1 AND type = 'appointment'", [u.id])) if (J<any>(it.data, {}).fromInvite === token) return { ok: true, id: Number(it.id), already: true, reminders: J<any>(it.data, {}).reminders || [] }
  const d = J<any>(r!.data, {})
  const { itemAction } = await import('./items.js')
  const { db } = await import('../db/index.js')
  const res: any = await db().tx((t) => itemAction(u, 'create', 'appointment', 0, { title: d.title, date: r!.day, time: d.time || undefined, location: d.location || '', person: d.person || '', notes: '' }, t))
  const it = res.created[0]
  const data = { ...J<any>(it.data, {}), fromInvite: token, endTime: d.endTime || null }
  await q('UPDATE items SET data = $1 WHERE id = $2', [JSON.stringify(data), it.id])
  await (await import('../lib/marketing.js')).recordActivation(token, Number(s!.user_id), Number(r!.id), u.id, Number(it.id), String(v.createdAt || v.created || d.sharedAt || ''))
  return { ok: true, id: Number(it.id), already: false, reminders: data.reminders || [] }
}

/** Consentimento SEPARADO e opcional para receber ofertas do dono do compromisso. */
export async function shareConsentPost(ctx: Ctx) {
  const u = requireUser(ctx), token = String(ctx.params.token || '').slice(0, 40)
  const s = await one('SELECT user_id FROM user_modules WHERE key = $1', ['share:' + token]); if (!s) fail(404, 'Convite não encontrado.', 'not_found')
  const M = await import('../lib/marketing.js')
  return M.setConsent(Number(s!.user_id), u.id, ctx.body?.aceito === true, 'convite:' + token)
}
export async function apptTrackingGet(ctx: Ctx) {
  const u = requireUser(ctx); const t = await (await import('../lib/marketing.js')).trackingOf(u.id, Number(ctx.params.id))
  if (!t) fail(404, 'Compromisso não encontrado.', 'not_found'); return t
}
