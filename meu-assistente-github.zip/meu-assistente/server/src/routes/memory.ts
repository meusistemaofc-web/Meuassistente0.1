// /api/memory — memórias do assistente (Perfil → Memória do assistente).
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, B } from '../db/index.js'
import { requireUser, type SessionUser } from '../lib/session.js'

const KINDS = ['preference', 'fact', 'person', 'routine', 'goal']
export const memSettings = (u: SessionUser) => ({ enabled: u.memory_settings.enabled !== false, summaries: u.memory_settings.summaries === true })
const ser = (r: any) => ({ id: Number(r.id), content: r.content, kind: r.kind, source: r.source, active: B(r.active), useCount: Number(r.use_count), createdAt: r.created_at, updatedAt: r.updated_at, purpose: null })
const SECRET_RE = /(senha|password|token|cart[aã]o de cr[eé]dito|cvv|pin\b)/i

export async function addMemory(userId: number, content: string, kind = 'fact', source = 'manual') {
  const c = content.trim().slice(0, 600)
  if (!c) fail(400, 'Escreva a memória.', 'invalid', 'content')
  if (SECRET_RE.test(c)) fail(400, 'Por segurança, senhas e credenciais não são guardadas na memória.', 'secret_rejected', 'content')
  const now = nowIso()
  const r = await q('INSERT INTO memories (user_id, content, kind, source, active, use_count, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,0,$6,$6) RETURNING *',
    [userId, c, KINDS.includes(kind) ? kind : 'fact', source, true, now])
  return ser(r[0])
}
export async function activeMemories(userId: number): Promise<string[]> {
  return (await q('SELECT content FROM memories WHERE user_id = $1 AND active = $2 ORDER BY id DESC LIMIT 50', [userId, true])).map((r) => r.content)
}

export async function memoryGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const rows = await q('SELECT * FROM memories WHERE user_id = $1 ORDER BY id DESC', [u.id])
  return { available: true, ...memSettings(u), memories: rows.map(ser) }
}
export async function memoryPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  switch (b.action) {
    case 'create': return { ok: true, memory: await addMemory(u.id, str(b.content, 600), b.kind, 'manual') }
    case 'update': {
      const m = await one('SELECT * FROM memories WHERE id = $1 AND user_id = $2', [Number(b.id), u.id])
      if (!m) fail(404, 'Memória não encontrada.', 'not_found')
      const content = b.content !== undefined ? str(b.content, 600) : m!.content
      if (!content) fail(400, 'Escreva a memória.', 'invalid', 'content')
      if (SECRET_RE.test(content)) fail(400, 'Por segurança, senhas e credenciais não são guardadas na memória.', 'secret_rejected', 'content')
      const active = typeof b.active === 'boolean' ? b.active : B(m!.active)
      await q('UPDATE memories SET content = $1, active = $2, updated_at = $3 WHERE id = $4', [content, active, nowIso(), m!.id])
      return { ok: true }
    }
    case 'delete':
      await q('DELETE FROM memories WHERE id = $1 AND user_id = $2', [Number(b.id), u.id])
      return { ok: true }
    case 'delete_all':
      await q('DELETE FROM memories WHERE user_id = $1', [u.id])
      return { ok: true }
    case 'settings': {
      const next = { ...u.memory_settings }
      if (typeof b.enabled === 'boolean') next.enabled = b.enabled
      if (typeof b.summaries === 'boolean') next.summaries = b.summaries
      await q('UPDATE users SET memory_settings = $1 WHERE id = $2', [JSON.stringify(next), u.id])
      return { ok: true }
    }
  }
  fail(400, 'Ação desconhecida.', 'unknown_action')
}
