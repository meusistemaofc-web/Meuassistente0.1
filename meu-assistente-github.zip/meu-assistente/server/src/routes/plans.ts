// Assinatura dos planos de uso (Pix pelo Mercado Pago do administrador) e resumo de uso do dia.
import type { Ctx } from '../lib/http.js'
import { fail } from '../lib/http.js'
import { requireUser } from '../lib/session.js'
import { getConfig, unseal } from '../lib/settings.js'
import { getUM, setUM } from '../lib/usermod.js'
import { notify } from '../lib/notify.js'
import { MP_DEFAULT } from '../lib/panel-defaults.js'
import { config } from '../config.js'
import { planOf, usedToday, usageCfg, USAGE_KINDS } from '../lib/usage.js'

const MPB = () => (process.env.MP_API_BASE || 'https://api.mercadopago.com').replace(/\/$/, '')
async function adminTok() { const mp = { ...MP_DEFAULT, ...(await getConfig<any>('mercadopago', {})) }; return unseal((mp[mp.modo] || {}).tok || '') }
export async function usageGet(ctx: Ctx) {
  const u = requireUser(ctx), p = await planOf(u)
  return { ativo: p.cfg.ativo, plano: { id: p.id, nome: p.nome, expiresAt: p.expiresAt, limites: p.limites }, usado: await usedToday(u.id), kinds: USAGE_KINDS,
    planos: p.cfg.plans.filter((x: any) => x.ativo !== false).map((x: any) => ({ id: x.id, nome: x.nome, preco: x.preco, dias: x.dias, limites: x.limites })), pagamento: (await getUM<any>(u.id, 'sub_payment', null)) }
}
export async function activateSub(userId: number, planId: string, paymentId: string) {
  const cfg = await usageCfg(), p = cfg.plans.find((x: any) => x.id === planId); if (!p) return
  const cur = await getUM<any>(userId, 'subscription', null)
  const base = cur && cur.planId === planId && Date.parse(cur.expiresAt) > Date.now() ? Date.parse(cur.expiresAt) : Date.now()
  const expiresAt = new Date(base + (Number(p.dias) || 30) * 86400_000).toISOString()
  await setUM(userId, 'subscription', { planId, expiresAt, paymentId })
  await setUM(userId, 'sub_payment', null)
  await notify(userId, { type: 'plan', title: `Plano ${p.nome} ativado!`, body: `Válido até ${expiresAt.slice(0, 10).split('-').reverse().join('/')}`, link: '/x/planos', ref: `sub:${userId}:${paymentId}` })
}
export async function subscriptionPost(ctx: Ctx) {
  const u = requireUser(ctx), cfg = await usageCfg(), p = cfg.plans.find((x: any) => x.id === ctx.body?.planId && x.ativo !== false)
  if (!p) fail(400, 'Escolha um plano.', 'invalid')
  const tok = await adminTok(); if (!tok) fail(503, 'O recebimento ainda não foi configurado pelo administrador.', 'mp_not_configured')
  const r = await fetch(`${MPB()}/v1/payments`, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `sub-${u.id}-${Date.now()}` },
    body: JSON.stringify({ transaction_amount: p.preco, description: `Meu Assistente · plano ${p.nome}`, payment_method_id: 'pix', payer: { email: u.email }, external_reference: `sub:${u.id}:${p.id}`, notification_url: `${config.publicUrl}/api/mercadopago/webhook` }) })
  const j: any = await r.json().catch(() => null)
  if (!r.ok || !j?.id) fail(502, 'Não foi possível gerar o Pix agora.', 'mp_error')
  const td = j.point_of_interaction?.transaction_data || {}
  const pay = { id: String(j.id), planId: p.id, valor: p.preco, qr: td.qr_code || '', qrImage: td.qr_code_base64 || '' }
  await setUM(u.id, 'sub_payment', pay)
  if (j.status === 'approved') await activateSub(u.id, p.id, String(j.id))
  return { payment: pay }
}
export async function subscriptionPayGet(ctx: Ctx) {
  const u = requireUser(ctx), pay = await getUM<any>(u.id, 'sub_payment', null)
  if (!pay) return { status: 'none' }
  try { const r = await fetch(`${MPB()}/v1/payments/${pay.id}`, { headers: { Authorization: `Bearer ${await adminTok()}` } }); const j: any = await r.json()
    if (j.status === 'approved' && j.external_reference === `sub:${u.id}:${pay.planId}`) { await activateSub(u.id, pay.planId, pay.id); return { status: 'approved' } }
    return { status: j.status } } catch { return { status: 'unknown' } }
}
