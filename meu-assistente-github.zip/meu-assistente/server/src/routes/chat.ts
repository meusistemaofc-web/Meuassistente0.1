import { financeReply } from '../ai/finchat.js'
import { parseAppointment } from '../ai/appt.js'
import { cardFor } from '../ai/assistant.js'
import { createItem, serialize } from './items.js'
import { humanDate, localDate } from '../lib/time.js'
import { useQuota } from '../lib/usage.js'
import { maybeAd } from './businesses.js'
import { quickReply } from '../ai/intents.js'
// /api/chat, /api/conversations — conversas com o assistente.
// Contrato reconstruído do componente de chat (index-DU-7__VK.js): a resposta traz
// {conversation, userMessage, assistantMessage}; IDs de conversa são UUIDs gerados no aparelho.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, J, B, db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { runAssistant } from '../ai/assistant.js'
import { aiConfigured, type ChatMsg } from '../ai/provider.js'

const CONV_ID = /^[A-Za-z0-9-]{8,64}$/
const convOut = (c: any) => c && ({ id: c.id, title: c.title, pinned: B(c.pinned), createdAt: c.created_at, updatedAt: c.updated_at })
function msgOut(m: any, byId?: Map<number, any>) {
  const replyTo = m.reply_to_id && byId?.get(Number(m.reply_to_id))
  return {
    id: Number(m.id), role: m.role, content: m.content, cards: J(m.cards, []), voiceMessageId: null, createdAt: m.created_at,
    replyToId: m.reply_to_id ? Number(m.reply_to_id) : null,
    ...(replyTo ? { replyTo: { id: Number(replyTo.id), role: replyTo.role, content: String(replyTo.content).slice(0, 200) } } : {}),
    ...(B(m.superseded) ? { superseded: true } : {}),
  }
}

async function ensureConversation(u: SessionUser, id: string, firstText: string) {
  if (!CONV_ID.test(id)) fail(400, 'Conversa inválida.', 'invalid')
  const c = await one('SELECT * FROM conversations WHERE id = $1', [id])
  if (c) { if (Number(c.user_id) !== u.id) fail(404, 'Conversa não encontrada.', 'not_found'); return c }
  const now = nowIso()
  const title = firstText.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'
  await q('INSERT INTO conversations (id, user_id, title, pinned, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5)', [id, u.id, title, false, now])
  return one('SELECT * FROM conversations WHERE id = $1', [id])
}
async function history(convId: string, beforeId?: number): Promise<ChatMsg[]> {
  const rows = await q(`SELECT role, content FROM messages WHERE conversation_id = $1 AND superseded = $2 ${beforeId ? 'AND id < $3' : ''} ORDER BY id DESC LIMIT 40`,
    beforeId ? [convId, false, beforeId] : [convId, false])
  return rows.reverse().map((r) => ({ role: r.role, content: r.content }))
}
async function insertMsg(u: SessionUser, convId: string, role: string, content: string, cards: any[] = [], replyTo: number | null = null) {
  const r = await q('INSERT INTO messages (conversation_id, user_id, role, content, cards, reply_to_id, superseded, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
    [convId, u.id, role, content, JSON.stringify(cards), replyTo, false, nowIso()])
  return r[0]
}

export async function chatPost(ctx: Ctx) {
  const u = requireUser(ctx)
  if (String(ctx.req.headers['content-type'] || '').startsWith('multipart/'))
    fail(501, 'Envio de áudio, fotos e arquivos ainda não foi reconstruído neste servidor. Envie a mensagem por texto.', 'not_reconstructed')
  const b = ctx.body || {}
  const convId = str(b.conversationId, 64)

  if (b.forwardOf) {
    const src = await one('SELECT m.* FROM messages m WHERE m.id = $1 AND m.user_id = $2', [Number(b.forwardOf), u.id])
    if (!src) fail(404, 'Mensagem não encontrada.', 'not_found')
    await ensureConversation(u, convId, src!.content)
    await insertMsg(u, convId, src!.role, src!.content, J(src!.cards, []))
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
    return { ok: true }
  }

  const text = str(b.text, 8000)
  if (!text) fail(400, 'Escreva uma mensagem.', 'invalid', 'text')
  if (!aiConfigured()) fail(503, 'O assistente de IA ainda não foi configurado no servidor (defina AI_API_KEY no arquivo .env).', 'ai_not_configured')

  if (b.resendOf) {
    const orig = await one("SELECT * FROM messages WHERE id = $1 AND user_id = $2 AND role = 'user'", [Number(b.resendOf), u.id])
    if (!orig) fail(404, 'Mensagem não encontrada.', 'not_found')
    const later = await q('SELECT id FROM messages WHERE conversation_id = $1 AND id > $2 AND superseded = $3', [orig!.conversation_id, orig!.id, false])
    const reply = await runAssistant(u, await history(orig!.conversation_id, Number(orig!.id)), text)
    await q('UPDATE messages SET content = $1 WHERE id = $2', [text, orig!.id])
    if (later.length) await q(`UPDATE messages SET superseded = $1 WHERE conversation_id = $2 AND id > $3`, [true, orig!.conversation_id, orig!.id])
    const am = await insertMsg(u, orig!.conversation_id, 'assistant', reply.content, reply.cards)
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), orig!.conversation_id])
    const conv = await one('SELECT * FROM conversations WHERE id = $1', [orig!.conversation_id])
    return { resent: true, superseded: later.map((r) => Number(r.id)), userMessage: msgOut({ ...orig, content: text }), assistantMessage: msgOut(am), conversation: convOut(conv), usageAlert: null }
  }

  const conv = await ensureConversation(u, convId, text)
  const replyToId = b.replyToId ? Number(b.replyToId) : null
  const hist = await history(convId)
  let limitMsg: string | null = null
  try { await useQuota(u, 'chat') } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e }
  let fin: any = null
  if (!limitMsg) { try { fin = await financeReply(u, text) } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } }
  let appt: any = null
  if (!limitMsg && !fin) { const pa = parseAppointment(text, settingsOf(u).timezone); if (pa) { try { await useQuota(u, 'appointment'); const s = settingsOf(u); const rows = await db().tx((t: any) => createItem(u, 'appointment', { ...pa, location: '', reminderMinutes: Number((s as any).reminderLeadMinutes) || 30 }, t)); const it: any = serialize(rows[0]); appt = { content: `Pronto! Agendei "${it.title}" para ${humanDate(it.date, localDate(s.timezone)).toLowerCase()} às ${it.time}. Vou te avisar ${it.reminderMinutes} minutos antes. ⟦appt:${it.id}⟧`, cards: [cardFor('appointment', it, localDate(s.timezone))] } } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } } }
  const quick = limitMsg || appt || fin ? null : await quickReply(u, text).catch(() => null) // mercado, impostos: dados reais, sem gastar IA
  const reply = limitMsg ? { content: limitMsg, cards: [] as any[] } : fin ? fin : appt ? appt : quick ? { content: quick, cards: [] as any[] } : await runAssistant(u, hist, text)
  if (!appt) { const ac = (reply.cards || []).find((c: any) => c && c.kind === 'appointment' && c.id); if (ac && !/⟦appt:/.test(reply.content)) reply.content += ` ⟦appt:${ac.id}⟧` }
  if (!limitMsg && !/⟦(emp|loc|mkt)/.test(reply.content)) { const ad = await maybeAd(u).catch(() => null); if (ad) reply.content += ` ⟦ad:${ad}⟧` } // gera antes de gravar: se a IA falhar, nada fica pela metade
  const um = await insertMsg(u, convId, 'user', text, [], replyToId)
  const am = await insertMsg(u, convId, 'assistant', reply.content, reply.cards)
  await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
  const byId = new Map<number, any>()
  if (replyToId) { const rt = await one('SELECT * FROM messages WHERE id = $1 AND user_id = $2', [replyToId, u.id]); if (rt) byId.set(replyToId, rt) }
  return { conversation: convOut({ ...conv, updated_at: nowIso() }), userMessage: msgOut(um, byId), assistantMessage: msgOut(am), usageAlert: null, ad: null }
}

export async function chatGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const id = ctx.query.get('c') || ''
  const conv = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [id, u.id])
  if (!conv) return { conversation: null, messages: [] }
  const rows = await q('SELECT * FROM messages WHERE conversation_id = $1 ORDER BY id', [id])
  const byId = new Map(rows.map((r) => [Number(r.id), r]))
  return { conversation: convOut(conv), messages: rows.map((m) => msgOut(m, byId)) }
}
export async function chatDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE user_id = $1', [u.id])
  return { ok: true }
}

export async function conversationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const term = str(ctx.query.get('q'), 100)
  const rows = term
    ? await q(`SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id = c.id
               WHERE c.user_id = $1 AND (c.title ILIKE $2 OR m.content ILIKE $2) ORDER BY c.updated_at DESC LIMIT 100`, [u.id, `%${term}%`])
    : await q('SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 200', [u.id])
  return { conversations: rows.map(convOut) }
}
export async function conversationPatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const c = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  if (!c) fail(404, 'Conversa não encontrada.', 'not_found')
  const b = ctx.body || {}
  const title = b.title !== undefined ? str(b.title, 120) || c!.title : c!.title
  const pinned = typeof b.pinned === 'boolean' ? b.pinned : B(c!.pinned)
  await q('UPDATE conversations SET title = $1, pinned = $2 WHERE id = $3', [title, pinned, c!.id])
  return { ok: true, conversation: convOut({ ...c, title, pinned }) }
}
export async function conversationDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  return { ok: true }
}
