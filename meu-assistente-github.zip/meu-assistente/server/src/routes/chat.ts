import type { UpFile } from '../lib/multipart.js'
import { transcribeAudio } from '../ai/docs.js'
import { documentReply } from '../ai/finchat.js'
import { requireModule } from '../lib/usermod.js'
import { isAgendaQuery, agendaReply } from '../ai/agenda.js'
import { financeReply } from '../ai/finchat.js'
import { parseAppointment } from '../ai/appt.js'
import { cardFor } from '../ai/assistant.js'
import { createItem, serialize } from './items.js'
import { humanDate, localDate } from '../lib/time.js'
import { useQuota } from '../lib/usage.js'
import { maybeAd } from './businesses.js'
import { quickReply } from '../ai/intents.js'
// /api/chat, /api/conversations — conversas com o assistente.
// Contrato reconstruído do componente de chat (index-DU-7__VK.js): a resposta traz
// {conversation, userMessage, assistantMessage}; IDs de conversa são UUIDs gerados no aparelho.
import type { Ctx } from '../lib/http.js'
import { fail, str } from '../lib/http.js'
import { q, one, nowIso, J, B, db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { requireUser, type SessionUser } from '../lib/session.js'
import { runAssistant } from '../ai/assistant.js'
import { aiConfigured, type ChatMsg } from '../ai/provider.js'

const CONV_ID = /^[A-Za-z0-9-]{8,64}$/
const convOut = (c: any) => c && ({ id: c.id, title: c.title, pinned: B(c.pinned), createdAt: c.created_at, updatedAt: c.updated_at })
function msgOut(m: any, byId?: Map<number, any>) {
  const replyTo = m.reply_to_id && byId?.get(Number(m.reply_to_id))
  return {
    id: Number(m.id), role: m.role, content: m.content, cards: J(m.cards, []), voiceMessageId: null, createdAt: m.created_at,
    replyToId: m.reply_to_id ? Number(m.reply_to_id) : null,
    ...(replyTo ? { replyTo: { id: Number(replyTo.id), role: replyTo.role, content: String(replyTo.content).slice(0, 200) } } : {}),
    ...(B(m.superseded) ? { superseded: true } : {}),
  }
}

async function ensureConversation(u: SessionUser, id: string, firstText: string) {
  if (!CONV_ID.test(id)) fail(400, 'Conversa inválida.', 'invalid')
  const c = await one('SELECT * FROM conversations WHERE id = $1', [id])
  if (c) { if (Number(c.user_id) !== u.id) fail(404, 'Conversa não encontrada.', 'not_found'); return c }
  const now = nowIso()
  const title = firstText.replace(/\s+/g, ' ').trim().slice(0, 60) || 'Nova conversa'
  await q('INSERT INTO conversations (id, user_id, title, pinned, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$5)', [id, u.id, title, false, now])
  return one('SELECT * FROM conversations WHERE id = $1', [id])
}
async function history(convId: string, beforeId?: number): Promise<ChatMsg[]> {
  const rows = await q(`SELECT role, content FROM messages WHERE conversation_id = $1 AND superseded = $2 ${beforeId ? 'AND id < $3' : ''} ORDER BY id DESC LIMIT 40`,
    beforeId ? [convId, false, beforeId] : [convId, false])
  return rows.reverse().map((r) => ({ role: r.role, content: r.content }))
}
async function insertMsg(u: SessionUser, convId: string, role: string, content: string, cards: any[] = [], replyTo: number | null = null) {
  const r = await q('INSERT INTO messages (conversation_id, user_id, role, content, cards, reply_to_id, superseded, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *',
    [convId, u.id, role, content, JSON.stringify(cards), replyTo, false, nowIso()])
  return r[0]
}

export async function chatPost(ctx: Ctx) {
  const u = requireUser(ctx)
  const b = ctx.body || {}
  // anexos: áudio (transcrito), foto ou documento (lidos pelo Gemini), ou várias fotos enviadas antes em /api/images
  let pre: { content: string; cards: any[] } | null = null
  const files: UpFile[] = (ctx as any).files || []
  const audio = files.find((f) => f.field === 'audio'), doc = files.find((f) => f.field === 'image' || f.field === 'document')
  if (audio) { await requireModule('voz'); const tx = (await transcribeAudio(audio.data, audio.mime)).slice(0, 4000); if (!tx) fail(422, 'Não entendi o áudio. Tente falar de novo, mais perto do microfone.', 'audio_empty'); b.text = tx }
  else if (doc) {
    await requireModule('imagens')
    const mime = doc.mime === 'application/octet-stream' && /\.pdf$/i.test(doc.filename) ? 'application/pdf' : doc.mime
    if (!/^(image\/(jpeg|png|webp|heic|heif)|application\/pdf)$/.test(mime)) fail(415, 'Envie uma foto (JPG, PNG) ou um PDF.', 'unsupported_file')
    pre = await documentReply(u, doc.data, mime, str(b.text, 500))
    b.text = str(b.text, 500) || (doc.field === 'image' ? '📷 Foto enviada' : `📄 ${doc.filename || 'Documento'}`)
  } else if (b.photos?.batchId) {
    await requireModule('imagens')
    const batch = takeBatch(String(b.photos.batchId), u.id)
    if (!batch.length) fail(400, 'As fotos expiraram. Envie de novo.', 'invalid')
    const outs: string[] = []
    for (const f of batch) { try { outs.push((await documentReply(u, f.data, f.mime, str(b.text, 500))).content) } catch (e: any) { outs.push(`Foto ${f.position}: ${e?.message || 'não foi possível ler'}`) } }
    pre = { content: outs.map((c, i) => (batch.length > 1 ? `Foto ${batch[i].position}: ` : '') + c).join('\n'), cards: [] }
    b.text = str(b.text, 500) || `📷 ${batch.length} fotos enviadas`
  }
  const convId = str(b.conversationId, 64)

  if (b.forwardOf) {
    const src = await one('SELECT m.* FROM messages m WHERE m.id = $1 AND m.user_id = $2', [Number(b.forwardOf), u.id])
    if (!src) fail(404, 'Mensagem não encontrada.', 'not_found')
    await ensureConversation(u, convId, src!.content)
    await insertMsg(u, convId, src!.role, src!.content, J(src!.cards, []))
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
    return { ok: true }
  }

  const text = str(b.text, 8000)
  if (!text) fail(400, 'Escreva uma mensagem.', 'invalid', 'text')
  if (!aiConfigured()) fail(503, 'O assistente de IA ainda não foi configurado no servidor (defina AI_API_KEY no arquivo .env).', 'ai_not_configured')

  if (b.resendOf) {
    const orig = await one("SELECT * FROM messages WHERE id = $1 AND user_id = $2 AND role = 'user'", [Number(b.resendOf), u.id])
    if (!orig) fail(404, 'Mensagem não encontrada.', 'not_found')
    const later = await q('SELECT id FROM messages WHERE conversation_id = $1 AND id > $2 AND superseded = $3', [orig!.conversation_id, orig!.id, false])
    const reply = await runAssistant(u, await history(orig!.conversation_id, Number(orig!.id)), text)
    await q('UPDATE messages SET content = $1 WHERE id = $2', [text, orig!.id])
    if (later.length) await q(`UPDATE messages SET superseded = $1 WHERE conversation_id = $2 AND id > $3`, [true, orig!.conversation_id, orig!.id])
    const am = await insertMsg(u, orig!.conversation_id, 'assistant', reply.content, reply.cards)
    await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), orig!.conversation_id])
    const conv = await one('SELECT * FROM conversations WHERE id = $1', [orig!.conversation_id])
    return { resent: true, superseded: later.map((r) => Number(r.id)), userMessage: msgOut({ ...orig, content: text }), assistantMessage: msgOut(am), conversation: convOut(conv), usageAlert: null }
  }

  const conv = await ensureConversation(u, convId, text)
  const replyToId = b.replyToId ? Number(b.replyToId) : null
  const hist = await history(convId)
  let limitMsg: string | null = null
  try { await useQuota(u, 'chat') } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e }
  let fin: any = null
  if (pre) fin = pre
  else if (!limitMsg) { try { fin = await financeReply(u, text) } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } }
  let appt: any = null
  if (!limitMsg && !fin && isAgendaQuery(text)) appt = await agendaReply(u, text)
  if (!limitMsg && !fin && !appt) { const pa = parseAppointment(text, settingsOf(u).timezone); if (pa) { try { await useQuota(u, 'appointment'); const s = settingsOf(u); const rows = await db().tx((t: any) => createItem(u, 'appointment', { ...pa, location: '', reminderMinutes: Number((s as any).reminderLeadMinutes) || 30 }, t)); const it: any = serialize(rows[0]); appt = { content: `Pronto! Agendei "${it.title}" para ${humanDate(it.date, localDate(s.timezone)).toLowerCase()} às ${it.time}. Vou te avisar ${it.reminderMinutes} minutos antes. ⟦appt:${it.id}⟧`, cards: [] } } catch (e: any) { if (e?.code === 'limit_reached') limitMsg = e.message + ' ⟦btn:/x/planos|Ver planos⟧'; else throw e } } }
  const quick = limitMsg || appt || fin ? null : await quickReply(u, text).catch(() => null) // mercado, impostos: dados reais, sem gastar IA
  const reply = limitMsg ? { content: limitMsg, cards: [] as any[] } : fin ? fin : appt ? appt : quick ? { content: quick, cards: [] as any[] } : await runAssistant(u, hist, text)
  // cartões de compromisso, gasto e receita viram cartões premium (dados lidos do módulo real pelo id)
  if (Array.isArray(reply.cards)) { const keep: any[] = []; for (const c of reply.cards) { if (c && c.id && c.kind === 'appointment') { if (!/⟦appt:/.test(reply.content)) reply.content += ` ⟦appt:${c.id}⟧` } else if (c && c.id && (c.kind === 'expense' || c.kind === 'income')) { reply.content += ` ⟦fin:${c.id}⟧` } else keep.push(c) } reply.cards = keep }
  if (!limitMsg && !/⟦(emp|loc|mkt)/.test(reply.content)) { const ad = await maybeAd(u).catch(() => null); if (ad) reply.content += ` ⟦ad:${ad}⟧` } // gera antes de gravar: se a IA falhar, nada fica pela metade
  const um = await insertMsg(u, convId, 'user', text, [], replyToId)
  const am = await insertMsg(u, convId, 'assistant', reply.content, reply.cards)
  await q('UPDATE conversations SET updated_at = $1 WHERE id = $2', [nowIso(), convId])
  const byId = new Map<number, any>()
  if (replyToId) { const rt = await one('SELECT * FROM messages WHERE id = $1 AND user_id = $2', [replyToId, u.id]); if (rt) byId.set(replyToId, rt) }
  return { conversation: convOut({ ...conv, updated_at: nowIso() }), userMessage: msgOut(um, byId), assistantMessage: msgOut(am), usageAlert: null, ad: null }
}

export async function chatGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const id = ctx.query.get('c') || ''
  const conv = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [id, u.id])
  if (!conv) return { conversation: null, messages: [] }
  const rows = await q('SELECT * FROM messages WHERE conversation_id = $1 ORDER BY id', [id])
  const byId = new Map(rows.map((r) => [Number(r.id), r]))
  return { conversation: convOut(conv), messages: rows.map((m) => msgOut(m, byId)) }
}
export async function chatDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE user_id = $1', [u.id])
  return { ok: true }
}

export async function conversationsGet(ctx: Ctx) {
  const u = requireUser(ctx)
  const term = str(ctx.query.get('q'), 100)
  const rows = term
    ? await q(`SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversation_id = c.id
               WHERE c.user_id = $1 AND (c.title ILIKE $2 OR m.content ILIKE $2) ORDER BY c.updated_at DESC LIMIT 100`, [u.id, `%${term}%`])
    : await q('SELECT * FROM conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT 200', [u.id])
  return { conversations: rows.map(convOut) }
}
export async function conversationPatch(ctx: Ctx) {
  const u = requireUser(ctx)
  const c = await one('SELECT * FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  if (!c) fail(404, 'Conversa não encontrada.', 'not_found')
  const b = ctx.body || {}
  const title = b.title !== undefined ? str(b.title, 120) || c!.title : c!.title
  const pinned = typeof b.pinned === 'boolean' ? b.pinned : B(c!.pinned)
  await q('UPDATE conversations SET title = $1, pinned = $2 WHERE id = $3', [title, pinned, c!.id])
  return { ok: true, conversation: convOut({ ...c, title, pinned }) }
}
export async function conversationDelete(ctx: Ctx) {
  const u = requireUser(ctx)
  await q('DELETE FROM conversations WHERE id = $1 AND user_id = $2', [ctx.params.id, u.id])
  return { ok: true }
}

/* ---------- várias fotos: o app envia primeiro para /api/images e depois chama o chat com o lote ---------- */
const batches = new Map<string, { userId: number; at: number; files: { position: number; mime: string; data: Buffer }[] }>()
export function takeBatch(id: string, userId: number) { const b = batches.get(id); batches.delete(id); return b && b.userId === userId && Date.now() - b.at < 15 * 60_000 ? b.files.sort((x, y) => x.position - y.position) : [] }
export async function imagesPost(ctx: Ctx) {
  const u = requireUser(ctx); await requireModule('imagens')
  const id = str(ctx.body?.batchId, 64); if (!id) fail(400, 'Lote inválido.', 'invalid')
  const files: UpFile[] = ((ctx as any).files || []).filter((f: UpFile) => f.field === 'image')
  const pos = String(ctx.body?.position || '').split(',')
  const b = batches.get(id) || { userId: u.id, at: Date.now(), files: [] }
  if (b.userId !== u.id) fail(403, 'Lote inválido.', 'forbidden')
  for (const [i, f] of files.entries()) b.files.push({ position: Number(pos[i] || b.files.length + 1) || b.files.length + 1, mime: f.mime, data: f.data })
  b.files = b.files.slice(0, 10); batches.set(id, b)
  for (const [k, v] of batches) if (Date.now() - v.at > 15 * 60_000) batches.delete(k)
  return { results: files.map((_, i) => ({ ok: true, position: Number(pos[i] || i + 1) })) }
}
