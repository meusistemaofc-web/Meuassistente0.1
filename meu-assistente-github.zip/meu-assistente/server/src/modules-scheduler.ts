// Avisos dos módulos novos: alertas de preço do mercado e lembretes do DAS / declaração anual do MEI.
import { q, J } from './db/index.js'
import { notify } from './lib/notify.js'
import { modules, setUM } from './lib/usermod.js'
import { quote } from './routes/market.js'
import { fiscalState } from './routes/modules.js'

let lastMarket = 0, lastFiscal = ''
export async function checkModules(now = new Date()) {
  const mods = await modules()
  if (mods.mercado && now.getTime() - lastMarket >= 5 * 60_000) {
    lastMarket = now.getTime()
    const rows = await q("SELECT user_id, value FROM user_modules WHERE key = 'market_alerts'")
    for (const r of rows) {
      const list = J<any[]>(r.value, []); let changed = false
      for (const a of list) {
        if (a.firedAt) continue
        let price: number; try { price = (await quote(a.symbol)).price } catch { continue }
        if ((a.cond === 'acima' && price >= a.value) || (a.cond === 'abaixo' && price <= a.value)) {
          a.firedAt = now.toISOString(); changed = true
          await notify(Number(r.user_id), { type: 'market', title: `${a.symbol} ${a.cond === 'acima' ? 'subiu até' : 'caiu até'} o valor do seu alerta`, body: `Agora: ${price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`, link: `/x/mercado?s=${a.symbol}`, ref: `alert:${a.id}` })
        }
      }
      if (changed) await setUM(Number(r.user_id), 'market_alerts', list)
    }
  }
  const day = now.toISOString().slice(0, 10)
  if (mods.fiscal && lastFiscal !== day && now.getUTCHours() >= 12) { // uma vez por dia, a partir das 9h (Brasília)
    lastFiscal = day
    const rows = await q("SELECT user_id FROM user_modules WHERE key = 'fiscal'")
    for (const r of rows) {
      const uid = Number(r.user_id), st = await fiscalState(uid), av = st.perfil.avisos
      if (av.das && st.proximo) {
        const diff = Math.round((Date.parse(st.proximo.venc) - Date.parse(day)) / 86400_000)
        if (diff === av.dias || diff === 0) await notify(uid, { type: 'fiscal', title: diff === 0 ? 'O DAS vence hoje' : `O DAS vence em ${diff} dia(s)`, body: `Competência ${st.proximo.nome} · ${st.das.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`, link: '/x/impostos', ref: `das:${st.proximo.k}:${diff}` })
      }
      if (av.dasn && (day.endsWith('-05-01') || day.endsWith('-05-25'))) await notify(uid, { type: 'fiscal', title: 'Declaração anual do MEI', body: `Entregue a DASN-SIMEI até 31/05 (faturamento de ${st.dasn.anoBase}).`, link: '/x/impostos', ref: `dasn:${day}` })
    }
  }
}
