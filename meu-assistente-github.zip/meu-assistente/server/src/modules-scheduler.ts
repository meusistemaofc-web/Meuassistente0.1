// Avisos dos módulos novos: alertas de preço do mercado e lembretes do DAS / declaração anual do MEI.
import { q, J } from './db/index.js'
import { notify } from './lib/notify.js'
import { modules, setUM } from './lib/usermod.js'
import { quote } from './routes/market.js'
import { fiscalState } from './routes/modules.js'

let lastMarket = 0, lastFiscal = '', lastExpiry = ''
export async function checkModules(now = new Date()) {
  const mods = await modules()
  const dday = now.toISOString().slice(0, 10)
  if (lastExpiry !== dday && now.getUTCHours() >= 12) { lastExpiry = dday; await expiryAlerts(now).catch((e) => console.error('[scheduler] vencimentos:', e?.message)) }
  if (mods.mercado && now.getTime() - lastMarket >= 5 * 60_000) {
    lastMarket = now.getTime()
    const rows = await q("SELECT user_id, value FROM user_modules WHERE key = 'market_alerts'")
    for (const r of rows) {
      const list = J<any[]>(r.value, []); let changed = false
      for (const a of list) {
        if (a.firedAt) continue
        let price: number; try { price = (await quote(a.symbol)).price } catch { continue }
        if ((a.cond === 'acima' && price >= a.value) || (a.cond === 'abaixo' && price <= a.value)) {
          a.firedAt = now.toISOString(); changed = true
          await notify(Number(r.user_id), { type: 'market', title: `${a.symbol} ${a.cond === 'acima' ? 'subiu até' : 'caiu até'} o valor do seu alerta`, body: `Agora: ${price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`, link: `/x/mercado?s=${a.symbol}`, ref: `alert:${a.id}` })
        }
      }
      if (changed) await setUM(Number(r.user_id), 'market_alerts', list)
    }
  }
  const day = now.toISOString().slice(0, 10)
  if (mods.fiscal && lastFiscal !== day && now.getUTCHours() >= 12) { // uma vez por dia, a partir das 9h (Brasília)
    lastFiscal = day
    const rows = await q("SELECT user_id FROM user_modules WHERE key = 'fiscal'")
    for (const r of rows) {
      const uid = Number(r.user_id), st = await fiscalState(uid), av = st.perfil.avisos
      if (av.das && st.proximo) {
        const diff = Math.round((Date.parse(st.proximo.venc) - Date.parse(day)) / 86400_000)
        if (diff === av.dias || diff === 0) await notify(uid, { type: 'fiscal', title: diff === 0 ? 'O DAS vence hoje' : `O DAS vence em ${diff} dia(s)`, body: `Competência ${st.proximo.nome} · ${st.das.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`, link: '/x/impostos', ref: `das:${st.proximo.k}:${diff}` })
      }
      if (av.dasn && (day.endsWith('-05-01') || day.endsWith('-05-25'))) await notify(uid, { type: 'fiscal', title: 'Declaração anual do MEI', body: `Entregue a DASN-SIMEI até 31/05 (faturamento de ${st.dasn.anoBase}).`, link: '/x/impostos', ref: `dasn:${day}` })
    }
  }
}

/** Avisos de vencimento: 7, 3 e 1 dia antes, no dia, e 1 e 3 dias depois (se não renovou). */
const STEPS: [number, (n: string) => [string, string]][] = [
  [7, (n) => [`${n} vence em 7 dias`, 'Renove com antecedência e continue aparecendo para quem está perto, sem interrupção.']],
  [3, (n) => [`Faltam 3 dias: ${n}`, 'Renove agora para não perder clientes nem pedidos.']],
  [1, (n) => [`Último dia amanhã: ${n}`, 'Amanhã sai do ar. Renove hoje em poucos segundos com Pix.']],
  [0, (n) => [`${n} vence hoje`, 'Renove agora para não ficar fora do ar.']],
  [-1, (n) => [`${n} está fora do ar`, 'Seus clientes não estão encontrando você. Seus dados estão salvos: renove e volte na hora.']],
  [-3, (n) => [`Volte ao ar: ${n}`, 'Já são 3 dias fora do ar. Renove e recupere seus clientes — tudo continua salvo.']],
]
const daysLeft = (iso: string, now: Date) => Math.ceil((Date.parse(iso) - now.getTime()) / 86400_000)
async function stepNotify(uid: number, iso: string, name: string, link: string, refBase: string, now: Date) {
  const d = daysLeft(iso, now); const st = STEPS.find(([k]) => k === d); if (!st) return
  const [title, body] = st[1](name)
  await notify(uid, { type: 'expiry', title, body, link, ref: `${refBase}:${iso.slice(0, 10)}:${d}` })
}
export async function expiryAlerts(now = new Date()) {
  for (const b of await q("SELECT id, owner_id, status, expires_at, data FROM businesses WHERE expires_at IS NOT NULL AND status IN ('ativo','encerrado')")) {
    const x = J<any>(b.data, {}); await stepNotify(Number(b.owner_id), String(b.expires_at), `Seu anúncio "${x.empresa}"`, '/x/sua-empresa', `exp-ad:${b.id}`, now)
    if (x.agente?.expiresAt) await stepNotify(Number(b.owner_id), x.agente.expiresAt, `O agente de atendimento de "${x.empresa}"`, '/x/sua-empresa', `exp-ag:${b.id}`, now)
  }
  for (const r of await q("SELECT user_id, value FROM user_modules WHERE key = 'subscription'")) {
    const s2 = J<any>(r.value, null); if (s2?.expiresAt) await stepNotify(Number(r.user_id), s2.expiresAt, 'Seu plano do Meu Assistente', '/x/planos', `exp-sub:${r.user_id}`, now)
  }
}
