// Cérebro: respostas aprendidas reutilizadas sem gastar IA.
// Similaridade simples por palavras (Dice) — suficiente para perguntas curtas em português.
import { q, one, nowIso } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import type { SessionUser } from '../lib/session.js'

const norm = (t: string) =>
  t.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

function dice(a: string, b: string): number {
  if (!a || !b) return 0
  const wa = new Set(a.split(' ').filter(w => w.length > 2))
  const wb = new Set(b.split(' ').filter(w => w.length > 2))
  if (!wa.size || !wb.size) return 0
  let inter = 0
  for (const w of wa) if (wb.has(w)) inter++
  return (2 * inter) / (wa.size + wb.size)
}

export async function findLearnedAnswer(u: SessionUser, text: string): Promise<{ answer: string; id: number } | null> {
  const cfg = await getConfig<any>('brain', { aprender: true, cerebroPrimeiro: true, fatos: true })
  if (!cfg.aprender && !cfg.cerebroPrimeiro) return null

  const qn = norm(text)
  if (qn.length < 4) return null

  const rows = await q(
    `SELECT id, question_norm, answer, uses FROM brain_answers
     WHERE (user_id = $1 OR user_id IS NULL) AND score >= 0.6
     ORDER BY score DESC, uses DESC LIMIT 40`,
    [u.id]
  )

  let best: { id: number; sim: number; answer: string } | null = null
  for (const r of rows) {
    const sim = dice(qn, r.question_norm)
    if (sim >= 0.75 && (!best || sim > best.sim)) {
      best = { id: Number(r.id), sim, answer: r.answer }
    }
  }

  if (!best) return null

  await q('UPDATE brain_answers SET uses = uses + 1, updated_at = $1 WHERE id = $2', [nowIso(), best.id])
  return { answer: best.answer, id: best.id }
}

export async function saveLearnedAnswer(u: SessionUser, question: string, answer: string, origin = 'ia') {
  const cfg = await getConfig<any>('brain', { aprender: true })
  if (!cfg.aprender) return

  const qn = norm(question)
  if (qn.length < 5 || answer.length < 10 || answer.length > 2000) return
  // não aprende respostas de ferramentas/cartões ou com marcadores especiais
  if (/⟦|\[\[|registrad|agendad|gasto|receita|pagamento|transfer/.test(answer.toLowerCase())) return

  // evita duplicata quase idêntica
  const existing = await one(
    'SELECT id FROM brain_answers WHERE user_id = $1 AND question_norm = $2',
    [u.id, qn]
  )
  if (existing) {
    await q('UPDATE brain_answers SET answer = $1, uses = uses + 1, score = GREATEST(score, 0.8), updated_at = $2 WHERE id = $3',
      [answer, nowIso(), existing.id])
    return
  }

  await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, 0.8, $6, $6)`,
    [u.id, question.slice(0, 500), qn, answer.slice(0, 2000), origin, nowIso()]
  )
}

/** Respostas globais (admin) — opcional para o futuro */
export async function saveGlobalAnswer(question: string, answer: string) {
  const qn = norm(question)
  if (qn.length < 5) return
  await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, created_at, updated_at)
     VALUES (NULL, $1, $2, $3, 'admin', 0.9, $4, $4)
     ON CONFLICT DO NOTHING`,
    [question.slice(0, 500), qn, answer.slice(0, 2000), nowIso()]
  )
}
