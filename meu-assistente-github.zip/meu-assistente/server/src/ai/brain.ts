// Cérebro: respostas aprendidas reutilizadas sem gastar IA.
// Similaridade simples por palavras (Dice) — suficiente para perguntas curtas em português.
import { q, one, nowIso } from '../db/index.js'
import { getConfig } from '../lib/settings.js'
import type { SessionUser } from '../lib/session.js'

const norm = (t: string) =>
  t.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()

// perguntas que dependem do momento, de dados pessoais ou do contexto da conversa nunca são aprendidas nem reutilizadas
const VOLATIL = /\b(hoje|agora|amanha|ontem|semana|mes|ano|meu|minha|meus|minhas|eu|me|tenho|saldo|gastei|gasto|gastos|conta|contas|agenda|compromisso|compromissos|tarefa|tarefas|lembrete|horas|hora|data|dia|cotacao|dolar|euro|bitcoin|btc|preco|valor|tempo|clima|chuva|noticia|noticias|ultimo|ultima|atual|proximo|proxima|isso|esse|essa|isto|ele|ela|anterior|acima|aqui|perto)\b/
export const isVolatile = (t: string) => VOLATIL.test(norm(t))
function dice(a: string, b: string): number {
  if (!a || !b) return 0
  const wa = new Set(a.split(' ').filter(w => w.length > 2))
  const wb = new Set(b.split(' ').filter(w => w.length > 2))
  if (!wa.size || !wb.size) return 0
  let inter = 0
  for (const w of wa) if (wb.has(w)) inter++
  return (2 * inter) / (wa.size + wb.size)
}

export async function findLearnedAnswer(u: SessionUser, text: string): Promise<{ answer: string; id: number } | null> {
  const cfg = await getConfig<any>('brain', { aprender: true, cerebroPrimeiro: true, fatos: true })
  if (!cfg.aprender && !cfg.cerebroPrimeiro) return null

  const qn = norm(text)
  if (qn.length < 4 || VOLATIL.test(qn)) return null

  const rows = await q(
    `SELECT id, question_norm, answer, uses FROM brain_answers
     WHERE (user_id = $1 OR user_id IS NULL) AND score >= 0.6 AND status = 'ativo' AND kind = 'resposta'
     ORDER BY score DESC, uses DESC LIMIT 40`,
    [u.id]
  )

  let best: { id: number; sim: number; answer: string } | null = null
  for (const r of rows) {
    const sim = dice(qn, r.question_norm)
    if (sim >= 0.75 && (!best || sim > best.sim)) {
      best = { id: Number(r.id), sim, answer: r.answer }
    }
  }

  if (!best) return null

  await q('UPDATE brain_answers SET uses = uses + 1, updated_at = $1 WHERE id = $2', [nowIso(), best.id])
  return { answer: best.answer, id: best.id }
}

export async function saveLearnedAnswer(u: SessionUser, question: string, answer: string, origin = 'ia') {
  const cfg = await getConfig<any>('brain', { aprender: true })
  if (!cfg.aprender) return

  const qn = norm(question)
  if (VOLATIL.test(qn)) return
  if (qn.length < 5 || answer.length < 10 || answer.length > 2000) return
  // não aprende respostas de ferramentas/cartões ou com marcadores especiais
  if (/⟦|\[\[|registrad|agendad|gasto|receita|pagamento|transfer/.test(answer.toLowerCase())) return

  // evita duplicata quase idêntica
  const existing = await one(
    'SELECT id FROM brain_answers WHERE user_id = $1 AND question_norm = $2',
    [u.id, qn]
  )
  if (existing) {
    await q('UPDATE brain_answers SET answer = $1, uses = uses + 1, score = GREATEST(score, 0.8), updated_at = $2 WHERE id = $3',
      [answer, nowIso(), existing.id])
    return
  }

  await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, 0.8, $6, $6)`,
    [u.id, question.slice(0, 500), qn, answer.slice(0, 2000), origin, nowIso()]
  )
}

/** Respostas globais (admin) — opcional para o futuro */
export async function saveGlobalAnswer(question: string, answer: string) {
  const qn = norm(question)
  if (qn.length < 5) return
  await q(
    `INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, created_at, updated_at)
     VALUES (NULL, $1, $2, $3, 'admin', 0.9, $4, $4)
     ON CONFLICT DO NOTHING`,
    [question.slice(0, 500), qn, answer.slice(0, 2000), nowIso()]
  )
}

/* ======================= CÉREBRO PRÓPRIO (conhecimento permanente) ======================= */
export const KINDS = ['conhecimento', 'regra', 'instrucao', 'experiencia', 'resposta'] as const
const STOP = new Set('a o os as um uma uns umas de da do das dos e ou em no na nos nas para pra por com sem que se ao aos como mais muito pouco sobre isso este esta esse essa ele ela eles elas voce voces seu sua seus suas ser estar ter tem foi sao e ja nao sim quando onde qual quais quem porque pois entao tambem ate cada todo toda todos todas'.split(' '))
export const keywordsOf = (t: string) => [...new Set(norm(t).split(' ').filter((w) => w.length > 3 && !STOP.has(w)))].slice(0, 30)
export async function brainLog(itemId: number | null, action: string, detail: string, actor = 'sistema') {
  try { await q('INSERT INTO brain_history (item_id, action, detail, actor, created_at) VALUES ($1,$2,$3,$4,$5)', [itemId, action, String(detail || '').slice(0, 300), actor, nowIso()]) } catch { /* histórico é opcional */ }
}
/** Já existe algo igual ou quase igual? (evita duplicidade) */
export async function findDuplicate(title: string, content: string) {
  const tn = norm(title), cn = norm(content).slice(0, 600)
  const rows = await q("SELECT id, question_norm, answer, status FROM brain_answers WHERE kind <> 'resposta' AND status <> 'rejeitado'")
  for (const r of rows) {
    if (r.question_norm === tn) return Number(r.id)
    if (dice(tn, r.question_norm) >= 0.85 && dice(cn, norm(String(r.answer)).slice(0, 600)) >= 0.7) return Number(r.id)
    if (cn.length > 40 && dice(cn, norm(String(r.answer)).slice(0, 600)) >= 0.9) return Number(r.id)
  }
  return null
}
export async function addKnowledge(it: { titulo: string; conteudo: string; tipo?: string; origem?: string; status?: string; fonte?: string }, actor = 'sistema') {
  const titulo = String(it.titulo || '').trim().slice(0, 200), conteudo = String(it.conteudo || '').trim().slice(0, 4000)
  if (titulo.length < 3 || conteudo.length < 5) return { ok: false, motivo: 'curto demais' }
  const dup = await findDuplicate(titulo, conteudo)
  if (dup) return { ok: false, duplicado: dup, motivo: 'já existe' }
  const kind = (KINDS as readonly string[]).includes(String(it.tipo)) ? String(it.tipo) : 'conhecimento'
  const status = ['ativo', 'pendente'].includes(String(it.status)) ? String(it.status) : 'pendente'
  await q(`INSERT INTO brain_answers (user_id, question, question_norm, answer, origin, score, kind, status, source, keywords, created_at, updated_at) VALUES (NULL,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$10)`,
    [titulo, norm(titulo), conteudo, String(it.origem || 'admin').slice(0, 40), status === 'ativo' ? 0.9 : 0.5, kind, status, String(it.fonte || '').slice(0, 200) || null, keywordsOf(titulo + ' ' + conteudo).join(' '), nowIso()])
  const row = await one('SELECT id FROM brain_answers WHERE question_norm = $1 ORDER BY id DESC LIMIT 1', [norm(titulo)])
  await brainLog(row ? Number(row.id) : null, status === 'ativo' ? 'aprendido' : 'proposto', `${kind}: ${titulo}`, actor)
  return { ok: true, id: row ? Number(row.id) : null, status }
}
/** Separa um texto (de documento, de outra IA, de anotações) em conhecimentos organizados, sem IA. */
export function splitKnowledge(texto: string): { titulo: string; conteudo: string; tipo: string }[] {
  const out: { titulo: string; conteudo: string; tipo: string }[] = []
  const blocos = String(texto || '').replace(/\r/g, '').split(/\n\s*\n|(?=\n#{1,4}\s)|(?=\n\d+[.)]\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ])/).map((b) => b.trim()).filter((b) => b.length > 15)
  for (const b of blocos) {
    const linhas = b.split('\n').map((l) => l.trim()).filter(Boolean)
    let titulo = linhas[0].replace(/^#{1,4}\s*|^\d+[.)]\s*|^[-*•]\s*/, '').replace(/[:：]\s*$/, '')
    let conteudo = linhas.slice(1).join(' ').replace(/^[-*•]\s*/gm, '').trim()
    if (!conteudo || titulo.length > 90) { // parágrafo corrido: título com as primeiras palavras
      conteudo = linhas.join(' ').replace(/^#{1,4}\s*/, '')
      titulo = conteudo.split(/(?<=[.!?])\s/)[0].split(' ').slice(0, 9).join(' ').replace(/[.,;:]$/, '')
    }
    const n = norm(b)
    const tipo = /^(sempre|nunca|nao (deve|pode)|evite|e proibido|obrigatorio|regra)\b/.test(norm(titulo + ' ' + conteudo)) || /\b(sempre|nunca|jamais)\b/.test(n.slice(0, 60)) ? 'regra'
      : /^(como|passo|para (criar|fazer|registrar|configurar)|instrucao|procedimento)\b/.test(norm(titulo)) ? 'instrucao'
      : /\b(aprendi|experiencia|percebemos|descobrimos|funcionou|nao funcionou)\b/.test(n) ? 'experiencia' : 'conhecimento'
    out.push({ titulo: titulo.slice(0, 200), conteudo: conteudo.slice(0, 4000), tipo })
  }
  return out.slice(0, 80)
}
/** Busca no conhecimento próprio (conhecimentos e instruções ativos) para responder sem IA. */
export async function findKnowledge(text: string, minScore = 0.34): Promise<{ id: number; titulo: string; conteudo: string; score: number } | null> {
  const kw = keywordsOf(text); if (kw.length < 1) return null
  const rows = await q("SELECT id, question, answer, keywords, question_norm FROM brain_answers WHERE status = 'ativo' AND kind IN ('conhecimento','instrucao','experiencia') LIMIT 2000")
  let best: any = null
  for (const r of rows) {
    const ks = new Set(String(r.keywords || '').split(' ').filter(Boolean)), tk = new Set(keywordsOf(r.question))
    let hit = 0, tHit = 0; for (const w of kw) { if (ks.has(w)) hit++; if (tk.has(w)) tHit++ }
    const score = (hit / kw.length) * 0.6 + (tk.size ? tHit / Math.max(kw.length, tk.size) : 0) * 0.4 + (dice(norm(text), r.question_norm) >= 0.6 ? 0.3 : 0)
    if (!best || score > best.score) best = { id: Number(r.id), titulo: r.question, conteudo: r.answer, score }
  }
  return best && best.score >= minScore && kw.length >= 1 ? best : null
}
/** Regras e instruções ativas e conhecimentos relacionados: entram no texto de sistema das IAs. */
export async function brainContext(text: string) {
  try {
    const regras = (await q("SELECT question, answer FROM brain_answers WHERE status = 'ativo' AND kind = 'regra' ORDER BY id LIMIT 30")).map((r) => `- ${r.question}: ${String(r.answer).slice(0, 300)}`)
    const k = await findKnowledge(text, 0.25)
    return [regras.length ? `Regras do Meu Assistente (siga sempre):\n${regras.join('\n')}` : '', k ? `Conhecimento próprio relacionado ("${k.titulo}"): ${String(k.conteudo).slice(0, 1200)}` : ''].filter(Boolean).join('\n\n')
  } catch { return '' }
}
/** Correção do usuário ("não, o certo é…") vira um aprendizado pendente para revisão. */
export async function proposeCorrection(question: string, correction: string, userId: number) {
  const c = correction.replace(/^(nao|não)[,.!]?\s*/i, '').replace(/^(na verdade|o certo (e|é)|corrigindo|correção|correcao|errado)[:,]?\s*/i, '').trim()
  if (c.length < 8 || !question) return null
  return addKnowledge({ titulo: question.slice(0, 200), conteudo: c, tipo: 'conhecimento', origem: 'correção do usuário', status: 'pendente', fonte: 'conversa' }, 'usuário ' + userId)
}
