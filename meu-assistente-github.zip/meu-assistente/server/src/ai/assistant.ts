import { useQuota } from '../lib/usage.js'
// Cérebro do chat: prompt de sistema + ferramentas que gravam registros reais no banco
// e geram os "cartões" exibidos pelo frontend (ChatCardView).
import { complete, engineCfg, engineInstructions, type ChatMsg, type ToolDef } from './provider.js'
import type { SessionUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import { localDate, localTime, humanDate } from '../lib/time.js'
import { createItem, itemAction, serialize, listItems, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../routes/items.js'
import { addMemory, activeMemories, memSettings } from '../routes/memory.js'
import { HttpError } from '../lib/http.js'
import { db } from '../db/index.js'

const S = (description: string, properties: object, required: string[] = []): object => ({ type: 'object', properties, required, additionalProperties: false })
export const TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'create_task', description: 'Cria uma tarefa (algo a fazer).', parameters: S('', { title: { type: 'string' }, due_date: { type: 'string', description: 'AAAA-MM-DD' }, due_time: { type: 'string', description: 'HH:MM' }, priority: { type: 'string', enum: ['normal', 'high'] } }, ['title']) } },
  { type: 'function', function: { name: 'create_appointment', description: 'Agenda um compromisso com data (e horário, se houver).', parameters: S('', { title: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' }, time: { type: 'string', description: 'HH:MM' }, location: { type: 'string' }, person: { type: 'string' }, reminder_minutes: { type: 'integer' } }, ['title', 'date']) } },
  { type: 'function', function: { name: 'create_reminder', description: 'Cria um lembrete que avisa o usuário numa data/hora.', parameters: S('', { message: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' }, time: { type: 'string', description: 'HH:MM' }, recurrence: { type: 'string', enum: ['none', 'daily', 'weekly', 'monthly', 'yearly'] } }, ['message']) } },
  { type: 'function', function: { name: 'add_shopping_items', description: 'Adiciona itens à lista de compras.', parameters: S('', { items: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, quantity: { type: 'string' } }, required: ['name'] } } }, ['items']) } },
  { type: 'function', function: { name: 'create_note', description: 'Salva uma anotação.', parameters: S('', { content: { type: 'string' }, title: { type: 'string' } }, ['content']) } },
  { type: 'function', function: { name: 'register_transaction', description: `Registra um gasto (kind=expense; categorias: ${EXPENSE_CATEGORIES.join(', ')}) ou uma receita (kind=income; categorias: ${INCOME_CATEGORIES.join(', ')}).`, parameters: S('', { kind: { type: 'string', enum: ['expense', 'income'] }, amount: { type: 'number' }, description: { type: 'string' }, category: { type: 'string' }, date: { type: 'string', description: 'AAAA-MM-DD' } }, ['kind', 'amount', 'description', 'category']) } },
  { type: 'function', function: { name: 'create_bill', description: 'Cadastra uma conta a pagar com vencimento.', parameters: S('', { name: { type: 'string' }, amount: { type: 'number' }, due_date: { type: 'string', description: 'AAAA-MM-DD' }, recurrence: { type: 'string', enum: ['none', 'weekly', 'monthly', 'yearly'] }, category: { type: 'string' } }, ['name', 'amount', 'due_date']) } },
  { type: 'function', function: { name: 'complete_task', description: 'Marca como concluída a tarefa pendente cujo título combina com o texto.', parameters: S('', { query: { type: 'string' } }, ['query']) } },
  { type: 'function', function: { name: 'save_memory', description: 'Guarda uma informação duradoura sobre o usuário quando ele pedir para lembrar (nunca senhas).', parameters: S('', { content: { type: 'string' }, kind: { type: 'string', enum: ['preference', 'fact', 'person', 'routine', 'goal'] } }, ['content']) } },
  { type: 'function', function: { name: 'get_agenda', description: 'Consulta compromissos, tarefas pendentes, lembretes e contas pendentes para responder perguntas.', parameters: S('', {}) } },
  { type: 'function', function: { name: 'get_finance', description: 'Consulta os lançamentos financeiros do mês atual.', parameters: S('', {}) } },
]

const CAT: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
function brl(n: number, cur = 'BRL') { return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: cur }).format(n) }

function cardFor(kind: string, s: any, today: string) {
  switch (kind) {
    case 'task': return { kind, id: s.id, label: `Tarefa · ${s.title}`, title: s.title, when: s.dueDate ? `${humanDate(s.dueDate, today)}${s.dueTime ? ` às ${s.dueTime}` : ''}` : undefined, meta: s.priority === 'high' ? ['Prioridade alta'] : [] }
    case 'appointment': return { kind, id: s.id, label: `Compromisso · ${s.title}`, title: s.title, when: `${humanDate(s.date, today)}${s.time ? ` às ${s.time}` : ''}`, meta: [s.location, s.person, s.time && s.reminderMinutes ? `Aviso ${s.reminderMinutes} min antes` : ''].filter(Boolean) }
    case 'reminder': return { kind, id: s.id, label: `Lembrete · ${s.message}`, title: s.message, when: `${humanDate(s.date, today)} às ${s.time}`, meta: s.recurrence !== 'none' ? [{ daily: 'Todo dia', weekly: 'Toda semana', monthly: 'Todo mês', yearly: 'Todo ano' }[s.recurrence as string]] : [] }
    case 'note': return { kind, id: s.id, label: 'Anotação', title: s.title || s.content.slice(0, 80) }
    case 'expense': return { kind: s.kind, id: s.id, label: `${s.kind === 'income' ? 'Receita' : 'Gasto'} · ${CAT[s.category] || s.category}`, title: s.description || CAT[s.category] || s.category, amount: s.amount, when: humanDate(s.date, today) }
    case 'bill': return { kind: 'bill', id: s.id, label: `Conta · ${s.name}`, title: s.name, amount: s.amount, when: `Vence ${humanDate(s.dueDate, today).toLowerCase()}` }
  }
  return null
}

export async function runAssistant(u: SessionUser, history: ChatMsg[], text: string): Promise<{ content: string; cards: any[] }> {
  const s = settingsOf(u)
  const tz = s.timezone
  const today = localDate(tz)
  const mem = memSettings(u).enabled ? await activeMemories(u.id) : []
  const eng = await engineCfg()
  const system: ChatMsg = {
    role: 'system',
    content: [
      'Você é o "Meu Assistente", um assistente pessoal brasileiro que organiza a vida do usuário conversando.',
      'Responda em português do Brasil, de forma curta, calorosa e objetiva.',
      engineInstructions(eng),
      'Quando o usuário pedir para registrar algo (gasto, receita, conta, tarefa, compromisso, lembrete, compra, anotação), use as ferramentas — nunca diga que registrou sem chamar a ferramenta.',
      'Se faltar uma informação indispensável (ex.: a data de um compromisso ou o valor de um gasto), pergunte antes.',
      'Para perguntas sobre agenda ou finanças, consulte com get_agenda / get_finance antes de responder.',
      `Hoje é ${today} (${new Intl.DateTimeFormat('pt-BR', { weekday: 'long', timeZone: tz }).format(new Date())}), agora são ${localTime(tz)} no fuso ${tz}. Moeda: ${s.currency}.`,
      `Nome do usuário: ${u.name}.`,
      mem.length ? `Memórias que o usuário pediu para você lembrar:\n- ${mem.join('\n- ')}` : '',
    ].filter(Boolean).join('\n'),
  }
  const msgs: ChatMsg[] = [system, ...history.slice(-eng.historico), { role: 'user', content: text }]
  const cards: any[] = []
  for (let round = 0; round < 5; round++) {
    const reply = await complete(msgs, TOOLS)
    if (!reply.tool_calls?.length) return { content: (reply.content || '').trim() || 'Pronto.', cards }
    msgs.push({ role: 'assistant', content: reply.content ?? null, tool_calls: reply.tool_calls })
    for (const call of reply.tool_calls) {
      let result: unknown
      try {
        const args = JSON.parse(call.function.arguments || '{}')
        result = await runTool(u, call.function.name, args, today, cards)
      } catch (e: any) {
        result = { ok: false, error: e instanceof HttpError ? e.message : 'Falha ao executar.' }
      }
      msgs.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result) })
    }
  }
  return { content: 'Fiz o que consegui com o seu pedido.', cards }
}

async function runTool(u: SessionUser, name: string, a: any, today: string, cards: any[]) {
  const make = async (type: string, data: any, cardKind = type) => {
    try { await useQuota(u, type) } catch (e: any) { if (e?.code === 'limit_reached') return { ok: false, error: e.message }; throw e }
    const rows = await db().tx((t) => createItem(u, type, data, t))
    const ser = rows.map(serialize) as any[]
    if (type === 'shopping') cards.push({ kind: 'shopping', label: 'Compras', title: ser.length === 1 ? ser[0].name : `${ser.length} itens`, items: ser.map((x) => x.name) })
    else { const c = cardFor(cardKind, ser[0], today); if (c) cards.push(c) }
    return { ok: true, created: ser }
  }
  switch (name) {
    case 'create_task': return make('task', a)
    case 'create_appointment': return make('appointment', a)
    case 'create_reminder': return make('reminder', a)
    case 'add_shopping_items': return make('shopping', a)
    case 'create_note': return make('note', a)
    case 'register_transaction': return make('expense', a)
    case 'create_bill': return make('bill', a)
    case 'complete_task': {
      const qy = String(a.query || '').toLowerCase()
      const tasks = (await listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') ORDER BY id DESC")).filter((t) => String(t.data.title).toLowerCase().includes(qy))
      if (!tasks.length) return { ok: false, error: 'Nenhuma tarefa pendente encontrada com esse nome.' }
      await itemAction(u, 'task_status', 'task', tasks[0].id, { status: 'done' })
      cards.push({ kind: 'done', label: `Tarefa concluída`, title: tasks[0].data.title, headline: 'Tarefa concluída!' })
      return { ok: true, completed: tasks[0].data.title }
    }
    case 'save_memory': {
      const m = await addMemory(u.id, String(a.content || ''), a.kind, 'chat')
      cards.push({ kind: 'memory', label: 'Memória', title: m.content })
      return { ok: true }
    }
    case 'get_agenda': {
      const [ap, tk, rm, bl] = await Promise.all([
        listItems(u.id, 'appointment', 'AND day >= $3 ORDER BY day LIMIT 30', [today]),
        listItems(u.id, 'task', "AND (status IS NULL OR status <> 'done') ORDER BY id DESC LIMIT 30"),
        listItems(u.id, 'reminder', "AND status = 'pending' ORDER BY due_at LIMIT 30"),
        listItems(u.id, 'bill', "AND status = 'pending' ORDER BY day LIMIT 30"),
      ])
      return { today, appointments: ap.map(serialize), pendingTasks: tk.map(serialize), reminders: rm.map(serialize), pendingBills: bl.map(serialize) }
    }
    case 'get_finance': {
      const m = today.slice(0, 7)
      const rows = (await listItems(u.id, 'expense', 'AND day >= $3', [m + '-01'])).map(serialize) as any[]
      const spent = rows.filter((r) => r.kind === 'expense').reduce((x, r) => x + r.amount, 0)
      const income = rows.filter((r) => r.kind === 'income').reduce((x, r) => x + r.amount, 0)
      return { month: m, spent: brl(spent), income: brl(income), entries: rows.slice(0, 40) }
    }
  }
  return { ok: false, error: 'Ferramenta desconhecida.' }
}
