// TTS multi-provedor: tenta OpenAI TTS primeiro, estrutura pronta para outros.
// Retorna buffer de áudio (mp3) ou null se nenhum provedor disponível.
import { getConfig } from '../lib/settings.js'
import { loadProviders } from './provider.js'

interface TtsResult { audio: Buffer; mime: string; provider: string }

export async function synthesize(text: string, voice = 'alloy'): Promise<TtsResult | null> {
  const clean = text.replace(/⟦.*?⟧/g, '').replace(/\[\[.*?\]\]/g, '').trim().slice(0, 4000)
  if (!clean) return null

  const providers = await loadProviders()
  // Prioridade: OpenAI com chave
  const openai = providers.find(p => p.tipo === 'openai' && p.key && p.ativo && (p.base_url.includes('openai.com') || p.id === 'openai'))
  if (openai) {
    try {
      const key = openai.key // já descriptografada no loadProviders? verificar
      // loadProviders retorna key cifrada; precisamos unseal
      const { unseal } = await import('../lib/settings.js')
      const apiKey = await unseal(openai.key)
      if (!apiKey) return null
      const base = openai.base_url.replace(/\/$/, '')
      const r = await fetch(`${base}/audio/speech`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'tts-1', input: clean, voice, response_format: 'mp3' }),
      })
      if (r.ok) {
        const buf = Buffer.from(await r.arrayBuffer())
        if (buf.length > 100) return { audio: buf, mime: 'audio/mpeg', provider: openai.nome || 'OpenAI' }
      }
    } catch {}
  }

  // Fallback futuro: Google Cloud TTS, ElevenLabs, etc.
  return null
}
