// Voz natural com várias opções e troca automática. Ordem: OpenAI (chave) → Gemini (chave grátis do
// AI Studio) → StreamElements (grátis, sem chave, voz Vitória pt-BR) → Google Tradutor (grátis, sem chave).
// Se todas falharem, o app usa a voz do próprio aparelho.
import { createHash } from 'node:crypto'
import { getConfig } from '../lib/settings.js'
import { loadProviders, targetFor } from './registry.js'

export interface TtsResult { audio: Buffer; mime: string; provider: string; voice: string }
export const TTS_DEFAULT = { ativo: true, ordem: ['openai', 'gemini', 'streamelements', 'google'], vozOpenai: 'nova', vozGemini: 'Kore', vozSE: 'Vitoria', maxChars: 3000 }
export async function ttsCfg() { return { ...TTS_DEFAULT, ...(await getConfig<any>('tts', {})) } }
const SE = () => (process.env.TTS_SE_BASE || 'https://api.streamelements.com').replace(/\/$/, '')
const GT = () => (process.env.TTS_GOOGLE_BASE || 'https://translate.google.com').replace(/\/$/, '')
const cache = new Map<string, TtsResult>()

export function cleanForSpeech(t: string) {
  return String(t || '').replace(/⟦[^⟧]*⟧/g, ' ').replace(/\[\[.*?\]\]/g, ' ').replace(/https?:\/\/\S+/g, ' ').replace(/[*_#`>|~]/g, '').replace(/R\$\s?/g, 'R$ ').replace(/\s+/g, ' ').trim()
}
function chunks(text: string, max: number) {
  const out: string[] = []; let cur = ''
  for (const part of text.split(/(?<=[.!?;:,])\s+/)) {
    const p = part.length > max ? part.match(new RegExp(`.{1,${max}}(\\s|$)`, 'g')) || [part.slice(0, max)] : [part]
    for (const x of p) { if ((cur + ' ' + x).trim().length > max) { if (cur) out.push(cur.trim()); cur = x } else cur = (cur + ' ' + x).trim() }
  }
  if (cur) out.push(cur.trim()); return out.filter(Boolean)
}
function wav(pcm: Buffer, rate = 24000) {
  const h = Buffer.alloc(44); h.write('RIFF', 0); h.writeUInt32LE(36 + pcm.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(rate, 24); h.writeUInt32LE(rate * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(pcm.length, 40)
  return Buffer.concat([h, pcm])
}
const get = async (url: string, init: RequestInit = {}, ms = 15000) => { const r = await fetch(url, { ...init, signal: AbortSignal.timeout(ms) }); if (!r.ok) throw new Error(`status ${r.status}`); const b = Buffer.from(await r.arrayBuffer()); if (b.length < 200) throw new Error('áudio vazio'); return { b, type: r.headers.get('content-type') || '' } }

async function viaOpenAI(text: string, cfg: any): Promise<TtsResult | null> {
  for (const p of await loadProviders()) {
    if (!p.ativo || !/openai\.com/.test(p.base_url || '') && p.id !== 'openai') continue
    const t = await targetFor(p); if (!t || !t.key) continue
    const { b } = await get(`${t.url.replace(/\/$/, '')}/audio/speech`, { method: 'POST', headers: { Authorization: `Bearer ${t.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'gpt-4o-mini-tts', input: text, voice: cfg.vozOpenai, response_format: 'mp3' }) }, 25000)
    return { audio: b, mime: 'audio/mpeg', provider: 'OpenAI', voice: cfg.vozOpenai }
  }
  return null
}
async function viaGemini(text: string, cfg: any): Promise<TtsResult | null> {
  for (const p of await loadProviders()) {
    if (!p.ativo || p.id !== 'gemini') continue
    const t = await targetFor(p); if (!t || !t.key) continue
    const r = await fetch(`${t.url.replace(/\/$/, '')}/v1beta/models/gemini-2.5-flash-preview-tts:generateContent`, { method: 'POST', signal: AbortSignal.timeout(30000), headers: { 'x-goog-api-key': t.key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: `Leia em português do Brasil, com naturalidade: ${text}` }] }], generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: cfg.vozGemini } } } } }) })
    if (!r.ok) throw new Error(`Gemini ${r.status}`)
    const j: any = await r.json(), d = j?.candidates?.[0]?.content?.parts?.find((x: any) => x.inlineData)?.inlineData
    if (!d?.data) throw new Error('Gemini sem áudio')
    const rate = Number(String(d.mimeType || '').match(/rate=(\d+)/)?.[1]) || 24000
    return { audio: wav(Buffer.from(d.data, 'base64'), rate), mime: 'audio/wav', provider: 'Gemini', voice: cfg.vozGemini }
  }
  return null
}
async function viaStreamElements(text: string, cfg: any): Promise<TtsResult> {
  const parts = chunks(text, 450), bufs: Buffer[] = []
  for (const c of parts) bufs.push((await get(`${SE()}/kappa/v2/speech?voice=${encodeURIComponent(cfg.vozSE)}&text=${encodeURIComponent(c)}`)).b)
  return { audio: Buffer.concat(bufs), mime: 'audio/mpeg', provider: 'StreamElements', voice: cfg.vozSE }
}
async function viaGoogle(text: string): Promise<TtsResult> {
  const parts = chunks(text, 190), bufs: Buffer[] = []
  for (const [i, c] of parts.entries()) bufs.push((await get(`${GT()}/translate_tts?ie=UTF-8&tl=pt-BR&client=tw-ob&total=${parts.length}&idx=${i}&textlen=${c.length}&q=${encodeURIComponent(c)}`, { headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://translate.google.com/' } })).b)
  return { audio: Buffer.concat(bufs), mime: 'audio/mpeg', provider: 'Google', voice: 'pt-BR' }
}
export async function synthesize(text: string): Promise<(TtsResult & { tried: string[] }) | null> {
  const cfg = await ttsCfg(), clean = cleanForSpeech(text).slice(0, cfg.maxChars)
  if (!clean || !cfg.ativo) return null
  const key = createHash('sha1').update(clean + '|' + cfg.ordem.join(',')).digest('hex')
  const hit = cache.get(key); if (hit) return { ...hit, tried: [] }
  const tried: string[] = []
  for (const id of cfg.ordem) {
    try {
      const r = id === 'openai' ? await viaOpenAI(clean, cfg) : id === 'gemini' ? await viaGemini(clean, cfg) : id === 'streamelements' ? await viaStreamElements(clean, cfg) : id === 'google' ? await viaGoogle(clean) : null
      if (!r) continue
      cache.set(key, r); if (cache.size > 60) cache.delete(cache.keys().next().value!)
      return { ...r, tried }
    } catch (e: any) { tried.push(`${id}: ${e?.message || 'falhou'}`); console.error(`[voz] ${id} falhou: ${e?.message}`) }
  }
  return null
}
export const ttsSignature = (text: string, ordem: string[]) => createHash('sha1').update(cleanForSpeech(text) + '|' + ordem.join(',')).digest('hex').slice(0, 16)
