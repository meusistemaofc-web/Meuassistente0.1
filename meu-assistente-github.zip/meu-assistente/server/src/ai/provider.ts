// Cliente de IA compatível com a API "chat/completions" da OpenAI, com VÁRIOS provedores e troca
// automática: a primeira IA pronta da lista (Administração → IA) responde; limite (429) pausa 60 s,
// chave recusada (401/403) pausa até nova chave, erro/tempo esgotado pausa 30 s, e a próxima assume.
// Sem provedores cadastrados, usa a IA definida no .env (AI_BASE_URL/AI_API_KEY/AI_MODEL).
import { config } from '../config.js'
import { HttpError } from '../lib/http.js'
import { getConfig, setConfig, unseal } from '../lib/settings.js'
import type { AiProvider } from '../lib/panel-defaults.js'

export interface ChatMsg {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string | null
  tool_calls?: { id: string; type: 'function'; function: { name: string; arguments: string } }[]
  tool_call_id?: string
}
export interface ToolDef { type: 'function'; function: { name: string; description: string; parameters: object } }
interface Target { id: string; nome: string; url: string; key: string; model: string }

export const aiConfigured = () => !!config.ai.apiKey || /localhost|127\.0\.0\.1|172\.17\.|ollama|:11434/.test(config.ai.baseUrl)

const pause = new Map<string, { until: number; expired: boolean; error: string }>()
let stats: Record<string, { uses: number; failures: number; lastError: string; lastAt: string }> | null = null
async function loadStats() { if (!stats) stats = await getConfig('ai-status', {}); return stats! }
function record(id: string, ok: boolean, error = '') {
  void (async () => {
    const s = await loadStats()
    const x = s[id] || (s[id] = { uses: 0, failures: 0, lastError: '', lastAt: '' })
    if (ok) x.uses++; else { x.failures++; x.lastError = error }
    x.lastAt = new Date().toISOString()
    await setConfig('ai-status', s).catch(() => {})
  })()
}
export async function aiRuntime() {
  return { stats: await loadStats(), paused: Object.fromEntries([...pause].map(([k, v]) => [k, { ...v, seconds: Math.max(0, Math.ceil((v.until - Date.now()) / 1000)) }])) }
}
export function aiResume(id: string) { pause.delete(id) }

const envTarget = (): Target => ({ id: 'servidor', nome: 'IA do servidor', url: config.ai.baseUrl, key: config.ai.apiKey, model: config.ai.model })
export async function targetFor(p: AiProvider): Promise<Target | null> {
  if (p.id === 'servidor') return aiConfigured() ? envTarget() : null
  const key = await unseal(p.key)
  if (!key || !p.base_url || !p.modelo) return null
  return { id: p.id, nome: p.nome, url: p.base_url.replace(/\/$/, ''), key, model: p.modelo }
}
async function chain(image: boolean): Promise<Target[]> {
  const provs = await getConfig<AiProvider[]>('ai_providers', [])
  if (!provs.length) return aiConfigured() ? [envTarget()] : []
  const out: Target[] = []
  for (const p of provs) {
    if (!p.ativo || (image ? !p.imagem : !p.texto)) continue
    const ps = pause.get(p.id)
    if (ps && (ps.expired || ps.until > Date.now())) continue
    const t = await targetFor(p)
    if (t) out.push(t)
  }
  return out
}

export async function callOne(t: Target, messages: ChatMsg[], tools?: ToolDef[], temperature = 0.4): Promise<ChatMsg> {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), config.ai.timeoutMs)
  try {
    const r = await fetch(`${t.url}/chat/completions`, {
      method: 'POST', signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', ...(t.key ? { Authorization: `Bearer ${t.key}` } : {}) },
      body: JSON.stringify({ model: t.model, messages, ...(tools?.length ? { tools, tool_choice: 'auto' } : {}), temperature }),
    })
    const data: any = await r.json().catch(() => null)
    if (!r.ok || !data?.choices?.[0]?.message) {
      const err: any = new Error(`HTTP ${r.status}`); err.status = r.status; err.detail = JSON.stringify(data)?.slice(0, 300); throw err
    }
    return data.choices[0].message as ChatMsg
  } finally { clearTimeout(timer) }
}

export async function complete(messages: ChatMsg[], tools?: ToolDef[], opts: { image?: boolean; temperature?: number } = {}): Promise<ChatMsg> {
  const targets = await chain(!!opts.image)
  if (!targets.length) throw new HttpError(503, 'Nenhuma IA está pronta. Cadastre uma chave em Administração → IA (painel) ou configure AI_API_KEY no .env.', 'ai_not_configured')
  let last = ''
  for (const t of targets) {
    try {
      const m = await callOne(t, messages, tools, opts.temperature ?? (await engineCfg()).temperature)
      pause.delete(t.id); record(t.id, true)
      return m
    } catch (e: any) {
      const st = e?.status
      const msg = e?.name === 'AbortError' ? 'tempo esgotado' : st ? `erro ${st}` : (e?.message || 'falha de conexão')
      if (st === 429) pause.set(t.id, { until: Date.now() + 60_000, expired: false, error: 'Limite atingido (429)' })
      else if ((st === 401 || st === 403) && t.id !== 'servidor') pause.set(t.id, { until: Infinity, expired: true, error: 'Chave recusada (' + st + ')' })
      else pause.set(t.id, { until: Date.now() + 30_000, expired: false, error: msg })
      record(t.id, false, msg)
      console.error(`[ai] ${t.nome} falhou (${msg}) ${e?.detail || ''} → tentando a próxima`)
      last = msg
    }
  }
  throw new HttpError(502, last === 'tempo esgotado' ? 'O serviço de IA demorou demais para responder.' : 'Nenhuma IA respondeu agora. Tente de novo em instantes.', 'ai_error')
}

/* ---------- comportamento do motor (Administração → Motor do chat) ---------- */
export const ENGINE_DEFAULT = { naturalidade: 75, personalidade: 'amigavel', personalidadeTexto: '', criatividade: 45, contexto: 70, autonomia: 55, precisao: 80 }
export async function engineCfg() {
  const { getConfig } = await import('../lib/settings.js')
  const c = { ...ENGINE_DEFAULT, ...(await getConfig<any>('engine', {})) }
  return { ...c, temperature: Math.round((0.1 + (c.criatividade / 100) * 0.8) * 100) / 100, historico: Math.round(6 + (c.contexto / 100) * 34) }
}
const PERS: Record<string, string> = { amigavel: 'acolhedor, próximo e simpático, como um amigo organizado', profissional: 'cordial, claro e profissional, sem informalidade excessiva', divertido: 'bem-humorado e leve, com toques de humor quando cabe', direto: 'direto ao ponto, sem rodeios, com frases curtas' }
export function engineInstructions(c: any) {
  const nat = c.naturalidade >= 70 ? 'Converse de forma natural e fluida, como uma pessoa real: varie as aberturas, não comece todas as respostas do mesmo jeito, não repita frases prontas e evite listas quando uma frase resolve.' : c.naturalidade >= 40 ? 'Seja natural, mas mantenha respostas organizadas.' : 'Prefira respostas objetivas e padronizadas.'
  const ctx = c.contexto >= 60 ? 'Use o histórico da conversa: entenda referências como "isso", "aquele", "o de ontem", retome o que já foi dito e não pergunte de novo o que o usuário já informou.' : 'Considere principalmente a última mensagem.'
  const aut = c.autonomia >= 70 ? 'Seja proativo: quando fizer sentido, sugira o próximo passo útil (ex.: oferecer um lembrete para um compromisso).' : c.autonomia >= 40 ? 'Sugira próximos passos só quando forem claramente úteis.' : 'Faça apenas o que foi pedido, sem sugestões extras.'
  const pre = c.precisao >= 70 ? 'Nunca invente dados: se não souber ou faltar informação, diga ou pergunte. Confirme valores, datas e horários registrados.' : 'Seja cuidadoso com datas e valores.'
  return [`Personalidade: ${PERS[c.personalidade] || PERS.amigavel}.`, c.personalidadeTexto ? `Orientação do administrador: ${String(c.personalidadeTexto).slice(0, 600)}` : '', nat, ctx, aut, pre, 'Entenda a intenção mesmo com erros de digitação, gírias ou frases incompletas.'].filter(Boolean).join('\n')
}
