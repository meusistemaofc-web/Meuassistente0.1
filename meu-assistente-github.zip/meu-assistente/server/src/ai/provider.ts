// Fachada do motor multi-IA. O código do aplicativo continua importando daqui (complete, engineCfg…);
// toda a inteligência (adaptadores, roteamento, fallback, circuit breaker) está em engine.ts e adapters/.
import { getConfig } from '../lib/settings.js'
import * as H from './health.js'

export type { ChatMsg, ToolDef, Task, Cap } from './types.js'
export { complete, run, askFiles, transcribe, testProvider, startAiMonitor, classifyTask, validateMessage, readyCount } from './engine.js'
export { aiConfigured, targetFor, loadProviders, routerCfg } from './registry.js'

export const aiRuntime = H.runtime
export const aiResume = H.resetBreaker

/* ---------- comportamento do motor (Administração → Motor do chat) ---------- */
export const ENGINE_DEFAULT = { naturalidade: 75, personalidade: 'amigavel', personalidadeTexto: '', criatividade: 45, contexto: 70, autonomia: 55, precisao: 80 }
export async function engineCfg() {
  const c = { ...ENGINE_DEFAULT, ...(await getConfig<any>('engine', {})) }
  return { ...c, temperature: Math.round((0.1 + (c.criatividade / 100) * 0.8) * 100) / 100, historico: Math.round(6 + (c.contexto / 100) * 34) }
}
const PERS: Record<string, string> = { amigavel: 'acolhedor, próximo e simpático, como um amigo organizado', profissional: 'cordial, claro e profissional, sem informalidade excessiva', divertido: 'bem-humorado e leve, com toques de humor quando cabe', direto: 'direto ao ponto, sem rodeios, com frases curtas' }
export function engineInstructions(c: any) {
  const nat = c.naturalidade >= 70 ? 'Converse de forma natural e fluida, como uma pessoa real: varie as aberturas, não comece todas as respostas do mesmo jeito, não repita frases prontas e evite listas quando uma frase resolve.' : c.naturalidade >= 40 ? 'Seja natural, mas mantenha respostas organizadas.' : 'Prefira respostas objetivas e padronizadas.'
  const ctx = c.contexto >= 60 ? 'Use o histórico da conversa: entenda referências como "isso", "aquele", "o de ontem", retome o que já foi dito e não pergunte de novo o que o usuário já informou.' : 'Considere principalmente a última mensagem.'
  const aut = c.autonomia >= 70 ? 'Seja proativo: quando fizer sentido, sugira o próximo passo útil (ex.: oferecer um lembrete para um compromisso).' : c.autonomia >= 40 ? 'Sugira próximos passos só quando forem claramente úteis.' : 'Faça apenas o que foi pedido, sem sugestões extras.'
  const pre = c.precisao >= 70 ? 'Nunca invente dados: se não souber ou faltar informação, diga ou pergunte. Confirme valores, datas e horários registrados.' : 'Seja cuidadoso com datas e valores.'
  return [`Personalidade: ${PERS[c.personalidade] || PERS.amigavel}.`, c.personalidadeTexto ? `Orientação do administrador: ${String(c.personalidadeTexto).slice(0, 600)}` : '', nat, ctx, aut, pre, 'Entenda a intenção mesmo com erros de digitação, gírias ou frases incompletas.'].filter(Boolean).join('\n')
}
