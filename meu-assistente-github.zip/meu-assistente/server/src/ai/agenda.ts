// Consulta da agenda pelo chat: sempre lê o módulo real de compromissos (nunca inventa).
import type { SessionUser } from '../lib/session.js'
import { q, J } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { localDate } from '../lib/time.js'
const nrm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
function addDays(iso: string, n: number) { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
export function isAgendaQuery(text: string) {
  const s = nrm(text)
  const topic = /\b(agenda|compromissos?|reunio(es)?|reuniao|eventos?|consultas?|agendad[oa]s?|marcad[oa]s?)\b/.test(s) || /\bo que (eu )?tenho\b/.test(s)
  const ask = /\?|\b(tenho|quais|qual|o que|mostra|mostrar|ver|veja|lista|listar|como esta|tem algum|existe|hoje|amanha|semana|mes|meus|minhas|minha)\b|\bproxim/.test(s)
  const create = /\b(agendar|agende|marca(r)?|marque|crie|criar|adiciona(r)?|anota(r)?|lembra(r)?|cancela|desmarca)\b/.test(s) && !/\b(agendad|marcad)/.test(s)
  return topic && ask && !create
}
export async function agendaReply(u: SessionUser, text: string) {
  const s = nrm(text), tz = settingsOf(u).timezone, today = localDate(tz)
  let from = today, to = today, label = 'hoje'
  if (/depois de amanha/.test(s)) { from = to = addDays(today, 2); label = 'depois de amanhã' }
  else if (/\bamanha\b/.test(s)) { from = to = addDays(today, 1); label = 'amanhã' }
  else if (/\b(semana|7 dias)\b/.test(s)) { to = addDays(today, 6); label = 'nos próximos 7 dias' }
  else if (/\b(mes|30 dias)\b/.test(s)) { to = addDays(today, 30); label = 'nos próximos 30 dias' }
  else if (/\b(proxim|futur|agendad|marcad)/.test(s) || !/\bhoje\b/.test(s) && !/o que (eu )?tenho/.test(s)) { to = addDays(today, 60); label = 'próximos' }
  const rows = await q("SELECT * FROM items WHERE user_id = $1 AND type = 'appointment' AND day >= $2 AND day <= $3 ORDER BY day", [u.id, from, to])
  const list = rows.map((r) => ({ id: Number(r.id), day: String(r.day), time: J<any>(r.data, {}).time || '' })).sort((a, b) => (a.day + a.time).localeCompare(b.day + b.time))
  const nowT = new Date(new Date().toLocaleString('en-US', { timeZone: tz })).toTimeString().slice(0, 5)
  const vis = (label === 'próximos' ? list.filter((x) => x.day > today || !x.time || x.time >= nowT) : list).slice(0, 8)
  if (!vis.length) return { content: label === 'próximos' ? 'Você não tem compromissos marcados daqui pra frente.' : `Você não tem compromissos ${label}.`, cards: [] }
  const n = vis.length, intro = label === 'próximos' ? (n === 1 ? 'Seu próximo compromisso:' : `Seus próximos ${n} compromissos:`) : `${label.charAt(0).toUpperCase() + label.slice(1)} você tem ${n === 1 ? '1 compromisso' : n + ' compromissos'}:`
  return { content: `${intro} ⟦appts:${vis.map((x) => x.id).join(',')}⟧`, cards: [] }
}
