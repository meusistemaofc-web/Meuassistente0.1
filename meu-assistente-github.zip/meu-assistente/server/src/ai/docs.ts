// Leitura inteligente de comprovantes, notas, recibos e áudio com o Gemini configurado no painel.
import { getConfig, unseal } from '../lib/settings.js'
import { HttpError } from '../lib/http.js'
const GEM = () => (process.env.GEMINI_API_BASE || 'https://generativelanguage.googleapis.com').replace(/\/$/, '')
export async function geminiTarget() {
  const provs = await getConfig<any[]>('ai_providers', [])
  const p = provs.find((x) => x.id === 'gemini' && x.ativo !== false)
  const key = p ? await unseal(p.key || '') : ''
  if (!key) return null
  return { key, model: String(p.modelo || 'gemini-flash-latest').replace(/^models\//, '') }
}
async function gemini(parts: any[], json: boolean) {
  const t = await geminiTarget()
  if (!t) throw new HttpError(503, 'A leitura de imagens, documentos e áudio usa o Google Gemini: cadastre a chave em Administração → IA → Google Gemini.', 'gemini_not_configured')
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 45_000)
  try {
    const r = await fetch(`${GEM()}/v1beta/models/${encodeURIComponent(t.model)}:generateContent`, { method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': t.key },
      body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { temperature: 0.1, ...(json ? { responseMimeType: 'application/json' } : {}) } }) })
    const j: any = await r.json().catch(() => null)
    if (r.status === 401 || r.status === 403) throw new HttpError(503, 'O Gemini recusou a chave cadastrada. Confira em Administração → IA.', 'gemini_key')
    if (r.status === 429) throw new HttpError(503, 'O Gemini atingiu o limite gratuito agora. Tente de novo em alguns minutos.', 'gemini_limit')
    if (!r.ok) throw new HttpError(502, 'O Gemini não conseguiu analisar o arquivo agora.', 'gemini_error')
    return String(j?.candidates?.[0]?.content?.parts?.map((x: any) => x.text || '').join('') || '').trim()
  } catch (e: any) { if (e instanceof HttpError) throw e; throw new HttpError(502, 'Não consegui falar com o Gemini agora. Tente novamente.', 'gemini_error') }
  finally { clearTimeout(tm) }
}
export interface DocRead { legivel: boolean; financeiro: boolean; direcao: 'entrada' | 'saida' | 'incerta'; tipo: 'receita' | 'despesa' | 'pagamento' | 'transferencia' | ''; valor: number | null; data: string | null; hora: string | null; estabelecimento: string; descricao: string; categoria: string; forma_pagamento: string; confianca: number; resumo: string }
export async function analyzeDocument(data: Buffer, mime: string, titular: string, caption: string): Promise<DocRead> {
  const prompt = `Você lê documentos financeiros brasileiros (comprovantes Pix/TED/boleto, notas fiscais, recibos, cupons, prints de banco) para o app Meu Assistente.
O TITULAR da conta é: "${titular}". Decida a DIREÇÃO do dinheiro pela perspectiva do titular:
- Comprovante em que o titular é pagador/origem, "Pix enviado", "Transferência enviada", "Pagamento efetuado", compra, boleto pago, nota/cupom fiscal de compra → "saida".
- Comprovante em que o titular é recebedor/destino, "Pix recebido", "Transferência recebida", "Você recebeu", nota fiscal de venda emitida pelo titular, recibo de valor recebido → "entrada".
- Se não der para saber com segurança quem pagou e quem recebeu → "incerta". Nunca chute.
Não invente: campos que não aparecem ficam null ou "". Valor em número (ex.: 152.3). Data AAAA-MM-DD, hora HH:MM (24h).
tipo: "receita" (entrada), "despesa" (compra/nota de compra), "pagamento" (conta, boleto, fatura, serviço pago), "transferencia" (Pix/TED enviado a pessoa).
categoria (use exatamente uma): saída → alimentacao, combustivel, casa, trabalho, compras, saude, transporte, lazer, outros; entrada → salario, servicos, vendas, outros.
forma_pagamento: Pix, Cartão de crédito, Cartão de débito, Dinheiro, Boleto, Transferência, TED/DOC ou "".
estabelecimento: nome da loja (saída) ou de quem pagou ao titular (entrada); para Pix enviado, o nome do recebedor.
${caption ? `Mensagem do usuário junto do arquivo: "${caption}".` : ''}
Responda SOMENTE com JSON: {"legivel":bool,"financeiro":bool,"direcao":"entrada|saida|incerta","tipo":"","valor":number|null,"data":string|null,"hora":string|null,"estabelecimento":"","descricao":"","categoria":"","forma_pagamento":"","confianca":0-1,"resumo":"frase curta descrevendo o documento"}`
  const out = await gemini([{ text: prompt }, { inline_data: { mime_type: mime, data: data.toString('base64') } }], true)
  let j: any; try { j = JSON.parse(out.replace(/^```(?:json)?|```$/g, '').trim()) } catch { j = { legivel: false } }
  const v = Number(j.valor)
  return { legivel: !!j.legivel, financeiro: !!j.financeiro, direcao: ['entrada', 'saida'].includes(j.direcao) ? j.direcao : 'incerta', tipo: ['receita', 'despesa', 'pagamento', 'transferencia'].includes(j.tipo) ? j.tipo : '',
    valor: v > 0 && v < 1e9 ? Math.round(v * 100) / 100 : null, data: /^\d{4}-\d{2}-\d{2}$/.test(String(j.data)) ? j.data : null, hora: /^\d{2}:\d{2}/.test(String(j.hora)) ? String(j.hora).slice(0, 5) : null,
    estabelecimento: String(j.estabelecimento || '').slice(0, 80), descricao: String(j.descricao || '').slice(0, 160), categoria: String(j.categoria || ''), forma_pagamento: String(j.forma_pagamento || '').slice(0, 40), confianca: Math.max(0, Math.min(1, Number(j.confianca) || 0)), resumo: String(j.resumo || '').slice(0, 300) }
}
export async function transcribeAudio(data: Buffer, mime: string) {
  return gemini([{ text: 'Transcreva fielmente este áudio em português do Brasil. Responda só com o texto falado, sem comentários.' }, { inline_data: { mime_type: mime.split(';')[0] || 'audio/webm', data: data.toString('base64') } }], false)
}
