// Leitura inteligente de comprovantes, notas, recibos e áudio. Usa o MOTOR MULTI-IA: a melhor IA que
// enxerga imagens/PDFs (ou transcreve áudio) responde e, se falhar, outra assume (Gemini, Claude, OpenAI, Groq…).
import { askFiles, transcribe, run } from './engine.js'
import { inflateSync } from 'node:zlib'
import { parseJsonLoose } from './types.js'
export interface DocRead { legivel: boolean; financeiro: boolean; direcao: 'entrada' | 'saida' | 'incerta'; tipo: 'receita' | 'despesa' | 'pagamento' | 'transferencia' | ''; valor: number | null; data: string | null; hora: string | null; estabelecimento: string; descricao: string; categoria: string; forma_pagamento: string; confianca: number; resumo: string }
export async function analyzeDocument(data: Buffer, mime: string, titular: string, caption: string): Promise<DocRead> {
  const prompt = `Você lê documentos financeiros brasileiros (comprovantes Pix/TED/boleto, notas fiscais, recibos, cupons, prints de banco) para o app Meu Assistente.
O TITULAR da conta é: "${titular}". Decida a DIREÇÃO do dinheiro pela perspectiva do titular:
- Comprovante em que o titular é pagador/origem, "Pix enviado", "Transferência enviada", "Pagamento efetuado", compra, boleto pago, nota/cupom fiscal de compra → "saida".
- Comprovante em que o titular é recebedor/destino, "Pix recebido", "Transferência recebida", "Você recebeu", nota fiscal de venda emitida pelo titular, recibo de valor recebido → "entrada".
- Se não der para saber com segurança quem pagou e quem recebeu → "incerta". Nunca chute.
Não invente: campos que não aparecem ficam null ou "". Valor em número (ex.: 152.3). Data AAAA-MM-DD, hora HH:MM (24h).
tipo: "receita" (entrada), "despesa" (compra/nota de compra), "pagamento" (conta, boleto, fatura, serviço pago), "transferencia" (Pix/TED enviado a pessoa).
categoria (use exatamente uma): saída → alimentacao, combustivel, casa, trabalho, compras, saude, transporte, lazer, outros; entrada → salario, servicos, vendas, outros.
forma_pagamento: Pix, Cartão de crédito, Cartão de débito, Dinheiro, Boleto, Transferência, TED/DOC ou "".
estabelecimento: nome da loja (saída) ou de quem pagou ao titular (entrada); para Pix enviado, o nome do recebedor.
${caption ? `Mensagem do usuário junto do arquivo: "${caption}".` : ''}
Responda SOMENTE com JSON: {"legivel":bool,"financeiro":bool,"direcao":"entrada|saida|incerta","tipo":"","valor":number|null,"data":string|null,"hora":string|null,"estabelecimento":"","descricao":"","categoria":"","forma_pagamento":"","confianca":0-1,"resumo":"frase curta descrevendo o documento"}`
  let out = ''
  // uma IA que diz "ilegível" não encerra a leitura: o motor passa para a próxima IA com visão e, por fim, para o OCR
  try { out = await askFiles(prompt, [{ mime, data: data.toString('base64') }], { json: true, validate: (m) => { try { const j = parseJsonLoose(String(m.content || '')); if (!j || typeof j !== 'object' || !('legivel' in j)) return 'JSON sem campos'; return j.legivel === false ? 'ilegível para esta IA' : null } catch { return 'JSON inválido' } } }) }
  catch (e: any) {
    // sem IA que leia o arquivo (ou todas falharam): PDF digital tem texto embutido; foto passa pelo OCR grátis → qualquer IA de texto, até o Ollama, interpreta
    const txt = mime === 'application/pdf' ? pdfText(data) : await ocrImage(data, mime).catch(() => '')
    console.error(`[comprovante] leitura direta falhou (${e?.message || e}); texto alternativo: ${txt.length} caracteres`)
    if (txt.replace(/\s/g, '').length < 20) {
      if (/ilegível|inadequada|JSON/.test(String(e?.message || '') + JSON.stringify(e?.attempts || []))) return { legivel: false, financeiro: false, direcao: 'incerta', tipo: '', valor: null, data: null, hora: null, estabelecimento: '', descricao: '', categoria: '', forma_pagamento: '', confianca: 0, resumo: '' }
      throw e
    }
    const r = await run([{ role: 'user', content: prompt + '\n\nTEXTO EXTRAÍDO DO ARQUIVO (pode ter quebras estranhas):\n' + txt.slice(0, 6000) }], { json: true, parallel: 'off', validate: (m) => { try { const j = parseJsonLoose(String(m.content || '')); return j && typeof j === 'object' && 'legivel' in j ? null : 'JSON sem campos' } catch { return 'JSON inválido' } } })
    out = String(r.message.content || '')
  }
  let j: any; try { j = parseJsonLoose(out) } catch { j = { legivel: false } }
  const v = Number(j.valor)
  return { legivel: !!j.legivel, financeiro: !!j.financeiro, direcao: ['entrada', 'saida'].includes(j.direcao) ? j.direcao : 'incerta', tipo: ['receita', 'despesa', 'pagamento', 'transferencia'].includes(j.tipo) ? j.tipo : '',
    valor: v > 0 && v < 1e9 ? Math.round(v * 100) / 100 : null, data: /^\d{4}-\d{2}-\d{2}$/.test(String(j.data)) ? j.data : null, hora: /^\d{2}:\d{2}/.test(String(j.hora)) ? String(j.hora).slice(0, 5) : null,
    estabelecimento: String(j.estabelecimento || '').slice(0, 80), descricao: String(j.descricao || '').slice(0, 160), categoria: String(j.categoria || ''), forma_pagamento: String(j.forma_pagamento || '').slice(0, 40), confianca: Math.max(0, Math.min(1, Number(j.confianca) || 0)), resumo: String(j.resumo || '').slice(0, 300) }
}
export async function transcribeAudio(data: Buffer, mime: string) {
  // 1º Whisper local (serviço "whisper" do docker-compose, sem custo e sem internet); se não estiver disponível, segue o caminho atual
  const local = await whisperLocal(data, mime).catch((e) => { console.error('[whisper] local indisponível:', e?.message || e); return '' })
  if (local) return local
  return transcribe(data, mime)
}
/** Whisper local: aceita a API compatível com OpenAI (/v1/audio/transcriptions) ou a do whisper-asr-webservice (/asr). */
async function whisperLocal(data: Buffer, mime: string): Promise<string> {
  const base = String(process.env.WHISPER_URL || '').replace(/\/+$/, '')
  if (!base) return ''
  const ext = (String(mime).split('/')[1] || 'webm').split(';')[0].replace('mpeg', 'mp3').replace('x-m4a', 'm4a')
  const file = () => new Blob([new Uint8Array(data)], { type: mime || 'audio/webm' })
  const timeout = Math.max(10, Number(process.env.WHISPER_TIMEOUT_S) || 90) * 1000
  const t0 = Date.now()
  const done = (txt: string, via: string) => { console.log(`[whisper] local ${via} ok em ${Date.now() - t0} ms (${txt.length} caracteres)`); return txt.trim() }
  // API compatível com OpenAI (faster-whisper-server, speaches, LocalAI…)
  try {
    const fd = new FormData(); fd.append('file', file(), 'voz.' + ext); fd.append('model', process.env.WHISPER_MODEL || 'whisper-1'); fd.append('language', 'pt'); fd.append('response_format', 'json')
    const r = await fetch(base + '/v1/audio/transcriptions', { method: 'POST', body: fd, signal: AbortSignal.timeout(timeout) })
    if (r.ok) { const j: any = await r.json().catch(() => null); if (j && typeof j.text === 'string') return done(j.text, 'openai') }
  } catch { /* tenta o outro formato */ }
  // whisper-asr-webservice (onerahmet/openai-whisper-asr-webservice)
  const fd = new FormData(); fd.append('audio_file', file(), 'voz.' + ext)
  const r = await fetch(base + '/asr?task=transcribe&language=pt&output=json&encode=true', { method: 'POST', body: fd, signal: AbortSignal.timeout(timeout) })
  if (!r.ok) throw new Error('Whisper local respondeu ' + r.status)
  const raw = await r.text(); let txt = raw
  try { const j = JSON.parse(raw); txt = typeof j.text === 'string' ? j.text : Array.isArray(j.segments) ? j.segments.map((x: any) => x.text).join(' ') : raw } catch { /* resposta em texto puro */ }
  return done(String(txt || ''), 'asr')
}

/** Extrai o texto de PDFs digitais (boletos, notas e comprovantes gerados por sistema), sem depender de IA com visão. */
export function pdfText(buf: Buffer): string {
  const raw = buf.toString('latin1'), out: string[] = []
  const re = /<<([^]*?)>>\s*stream\r?\n/g; let m: RegExpExecArray | null
  while ((m = re.exec(raw))) {
    const start = m.index + m[0].length, end = raw.indexOf('endstream', start); if (end < 0) break
    let body = buf.subarray(start, end)
    if (/FlateDecode/.test(m[1])) { try { body = inflateSync(body) } catch { continue } } else if (/Filter/.test(m[1])) continue
    const s = body.toString('latin1')
    const un = (t: string) => t.replace(/\\([nrtbf()\\])/g, (_, c) => ({ n: '\n', r: '', t: ' ', b: '', f: '', '(': '(', ')': ')', '\\': '\\' } as any)[c]).replace(/\\(\d{3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)))
    for (const t of s.matchAll(/\[((?:\\.|[^\]])*)\]\s*TJ|\(((?:\\.|[^\\)])*)\)\s*(?:Tj|'|")|(T\*|Td|TD|ET)/g)) {
      if (t[3]) { out.push('\n'); continue }
      if (t[2] !== undefined) out.push(un(t[2]))
      else if (t[1] !== undefined) out.push([...t[1].matchAll(/\(((?:\\.|[^\\)])*)\)|(-?\d+(?:\.\d+)?)/g)].map((x) => x[1] !== undefined ? un(x[1]) : Number(x[2]) < -200 ? ' ' : '').join(''))
    }
    re.lastIndex = end
  }
  return out.join('').replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim()
}

/** OCR grátis (OCR.space) para fotos quando nenhuma IA com visão está disponível: o texto lido vai para qualquer IA de texto. */
export async function ocrImage(data: Buffer, mime: string): Promise<string> {
  const { getConfig } = await import('../lib/settings.js')
  const cfg = { ativo: true, key: '', ...(await getConfig<any>('ocr', {})) }
  if (!cfg.ativo || !/^image\//.test(mime)) return ''
  const fd = new FormData()
  fd.append('base64Image', `data:${mime};base64,${data.toString('base64')}`); fd.append('language', 'por'); fd.append('OCREngine', '2'); fd.append('scale', 'true')
  const r = await fetch((process.env.OCR_SPACE_BASE || 'https://api.ocr.space') + '/parse/image', { method: 'POST', headers: { apikey: cfg.key || process.env.OCR_SPACE_KEY || 'helloworld' }, body: fd, signal: AbortSignal.timeout(30000) })
  const j: any = await r.json().catch(() => null)
  return String((j?.ParsedResults || []).map((x: any) => x.ParsedText || '').join('\n')).trim()
}
