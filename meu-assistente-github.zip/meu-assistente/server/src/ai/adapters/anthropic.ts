// Adaptador nativo da API de mensagens da Anthropic (Claude).
import { AiError, httpError, netError, type Adapter, type ChatMsg, type Target } from '../types.js'

const idOk = (s: string) => String(s || '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64) || 'call_x'
function toWire(messages: ChatMsg[]) {
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).filter(Boolean).join('\n\n')
  const out: { role: 'user' | 'assistant'; content: any[] }[] = []
  const push = (role: 'user' | 'assistant', blocks: any[]) => { if (!blocks.length) return; const l = out[out.length - 1]; if (l && l.role === role) l.content.push(...blocks); else out.push({ role, content: blocks }) }
  for (const m of messages) {
    if (m.role === 'system') continue
    if (m.role === 'assistant') {
      const b: any[] = []; if (m.content) b.push({ type: 'text', text: m.content })
      for (const c of m.tool_calls || []) { let input: any = {}; try { input = JSON.parse(c.function.arguments || '{}') } catch { /* vazio */ } b.push({ type: 'tool_use', id: idOk(c.id), name: c.function.name, input }) }
      push('assistant', b); continue
    }
    if (m.role === 'tool') { push('user', [{ type: 'tool_result', tool_use_id: idOk(m.tool_call_id || ''), content: m.content || '' }]); continue }
    const b: any[] = []
    for (const f of m.files || []) b.push(f.mime === 'application/pdf' ? { type: 'document', source: { type: 'base64', media_type: f.mime, data: f.data } } : { type: 'image', source: { type: 'base64', media_type: f.mime, data: f.data } })
    b.push({ type: 'text', text: m.content || ' ' })
    push('user', b)
  }
  if (!out.length || out[0].role === 'assistant') out.unshift({ role: 'user', content: [{ type: 'text', text: 'Continue a conversa.' }] })
  return { system, messages: out }
}

export const anthropicAdapter: Adapter = {
  kind: 'anthropic',
  async chat(t: Target, r) {
    const w = toWire(r.messages)
    const body: any = { model: t.model, max_tokens: 4096, messages: w.messages, temperature: Math.min(1, r.temperature), ...(w.system ? { system: w.system } : {}) }
    if (r.tools?.length) body.tools = r.tools.map((x: any) => ({ name: x.function.name, description: x.function.description, input_schema: (x.function.parameters as any)?.type ? x.function.parameters : { type: 'object', properties: {} } }))
    let res: Response
    try { res = await fetch(`${t.url}/v1/messages`, { method: 'POST', signal: r.signal, headers: { 'Content-Type': 'application/json', 'x-api-key': t.key, 'anthropic-version': '2023-06-01' }, body: JSON.stringify(body) }) } catch (e) { throw netError(e) }
    const j: any = await res.json().catch(() => null)
    if (!res.ok) throw httpError(res.status, j, res.headers)
    if (j?.stop_reason === 'refusal') throw new AiError('blocked', 'Resposta recusada pelo provedor')
    const blocks: any[] = Array.isArray(j?.content) ? j.content : []
    if (!blocks.length && j?.type !== 'message') throw new AiError('invalid_response', 'Resposta inesperada', 200, 0, JSON.stringify(j)?.slice(0, 300))
    const text = blocks.filter((b) => b.type === 'text').map((b) => b.text).join('')
    const calls = blocks.filter((b) => b.type === 'tool_use').map((b) => ({ id: String(b.id), type: 'function' as const, function: { name: String(b.name), arguments: JSON.stringify(b.input || {}) } }))
    return { message: { role: 'assistant', content: text || null, ...(calls.length ? { tool_calls: calls } : {}) } as ChatMsg, finish: j.stop_reason, usage: j.usage ? { in: Number(j.usage.input_tokens) || 0, out: Number(j.usage.output_tokens) || 0 } : undefined }
  },
}
