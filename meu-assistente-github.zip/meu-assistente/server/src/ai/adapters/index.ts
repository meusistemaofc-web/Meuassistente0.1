import type { Adapter, Kind } from '../types.js'
import { openaiAdapter } from './openai.js'
import { geminiAdapter } from './gemini.js'
import { anthropicAdapter } from './anthropic.js'
const A: Record<Kind, Adapter> = { openai: openaiAdapter, gemini: geminiAdapter, anthropic: anthropicAdapter }
export const adapterFor = (k: Kind): Adapter => A[k] || openaiAdapter
