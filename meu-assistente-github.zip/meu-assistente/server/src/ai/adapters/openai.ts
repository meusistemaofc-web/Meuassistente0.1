// Adaptador para serviços no formato "chat/completions" (OpenAI, Groq, Mistral, Cerebras, OpenRouter,
// GitHub Models, Ollama/servidor e qualquer outro compatível).
import { AiError, httpError, netError, rid, readSSE, type Adapter, type ChatMsg, type Target } from '../types.js'

function toWire(messages: ChatMsg[]) {
  return messages.map((m) => {
    const o: any = { role: m.role, content: m.content }
    if (m.tool_calls?.length) o.tool_calls = m.tool_calls.map((c) => ({ id: c.id, type: 'function', function: { name: c.function.name, arguments: c.function.arguments || '{}' } }))
    if (m.tool_call_id) o.tool_call_id = m.tool_call_id
    if (m.files?.length && m.role === 'user') {
      const parts: any[] = [{ type: 'text', text: m.content || '' }]
      for (const f of m.files) {
        const url = `data:${f.mime};base64,${f.data}`
        if (f.mime.startsWith('image/')) parts.push({ type: 'image_url', image_url: { url } })
        else if (f.mime === 'application/pdf') parts.push({ type: 'file', file: { filename: 'documento.pdf', file_data: url } })
      }
      o.content = parts
    }
    return o
  })
}

export const openaiAdapter: Adapter = {
  kind: 'openai',
  async chat(t: Target, r) {
    let res: Response
    try {
      res = await fetch(`${t.url}/chat/completions`, {
        method: 'POST', signal: r.signal,
        headers: { 'Content-Type': 'application/json', ...(t.key ? { Authorization: `Bearer ${t.key}` } : {}) },
        body: JSON.stringify({ model: t.model, messages: toWire(r.messages), ...(r.tools?.length ? { tools: r.tools, tool_choice: 'auto' } : {}), temperature: r.temperature, ...(r.onDelta ? { stream: true } : {}) }),
      })
    } catch (e) { throw netError(e) }
    // streaming: o texto chega aos pedaços (para o usuário ver a resposta começando na hora)
    if (r.onDelta && res.ok && /event-stream/.test(res.headers.get('content-type') || '')) {
      let text = '', finish = ''; const calls: any[] = []
      try {
        await readSSE(res, (j) => {
          const ch = j?.choices?.[0]; if (!ch) return
          const d = ch.delta || {}
          if (typeof d.content === 'string' && d.content) { text += d.content; r.onDelta!(d.content) }
          for (const tc of d.tool_calls || []) { const k = Number(tc.index) || 0; const c = (calls[k] ||= { id: tc.id || 'call_' + rid(), type: 'function', function: { name: '', arguments: '' } }); if (tc.id) c.id = tc.id; if (tc.function?.name) c.function.name += tc.function.name; if (tc.function?.arguments) c.function.arguments += tc.function.arguments }
          if (ch.finish_reason) finish = ch.finish_reason
        })
      } catch (e) { throw netError(e) }
      if (finish === 'content_filter') throw new AiError('blocked', 'Resposta bloqueada pelo filtro do provedor')
      const tc = calls.filter(Boolean).map((c) => ({ ...c, function: { ...c.function, arguments: c.function.arguments || '{}' } }))
      return { message: { role: 'assistant', content: text || null, ...(tc.length ? { tool_calls: tc } : {}) } as ChatMsg, finish }
    }
    const data: any = await res.json().catch(() => null)
    if (!res.ok) throw httpError(res.status, data, res.headers)
    const ch = data?.choices?.[0]
    if (!ch?.message) throw new AiError('invalid_response', 'Resposta sem mensagem', res.status, 0, JSON.stringify(data)?.slice(0, 300))
    if (ch.finish_reason === 'content_filter') throw new AiError('blocked', 'Resposta bloqueada pelo filtro do provedor')
    const m = ch.message
    const calls = Array.isArray(m.tool_calls) ? m.tool_calls.map((c: any) => ({ id: String(c.id || 'call_' + rid()), type: 'function' as const, function: { name: String(c.function?.name || ''), arguments: typeof c.function?.arguments === 'string' ? c.function.arguments : JSON.stringify(c.function?.arguments ?? {}) } })) : undefined
    const message: ChatMsg = { role: 'assistant', content: typeof m.content === 'string' ? m.content : Array.isArray(m.content) ? m.content.map((x: any) => x?.text || '').join('') : null, ...(calls?.length ? { tool_calls: calls } : {}) }
    return { message, finish: ch.finish_reason, usage: data.usage ? { in: Number(data.usage.prompt_tokens) || 0, out: Number(data.usage.completion_tokens) || 0 } : undefined }
  },
  async transcribe(t, data, mime, signal) {
    const model = t.modelAudio || (/groq/.test(t.url) ? 'whisper-large-v3-turbo' : /openai\.com/.test(t.url) ? 'whisper-1' : '')
    if (!model) throw new AiError('config', 'Defina o modelo de áudio desta IA.')
    const fd = new FormData()
    const ext = /ogg/.test(mime) ? 'ogg' : /mp4|m4a|aac/.test(mime) ? 'm4a' : /mpeg|mp3/.test(mime) ? 'mp3' : /wav/.test(mime) ? 'wav' : 'webm'
    fd.append('file', new Blob([new Uint8Array(data)], { type: mime.split(';')[0] || 'audio/webm' }), `audio.${ext}`)
    fd.append('model', model); fd.append('language', 'pt'); fd.append('response_format', 'json')
    let res: Response
    try { res = await fetch(`${t.url}/audio/transcriptions`, { method: 'POST', signal, headers: t.key ? { Authorization: `Bearer ${t.key}` } : {}, body: fd }) } catch (e) { throw netError(e) }
    const j: any = await res.json().catch(() => null)
    if (!res.ok) throw httpError(res.status, j, res.headers)
    return { text: String(j?.text || '').trim() }
  },
}
