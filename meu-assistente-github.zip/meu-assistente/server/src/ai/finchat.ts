// Liga o motor financeiro ao chat: pergunta só o que falta, evita duplicidade e grava no módulo financeiro.
import type { SessionUser } from '../lib/session.js'
import { db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { getUM, setUM } from '../lib/usermod.js'
import { useQuota } from '../lib/usage.js'
import { createItem, serialize } from '../routes/items.js'
import { humanDate, localDate } from '../lib/time.js'
import { parseFinance, parseAmount, finFingerprint, parsePartial, parseRemainder, type FinParsed } from './fin.js'
import { getConfig } from '../lib/settings.js'
import { createHash } from 'node:crypto'
import { analyzeDocument } from './docs.js'
import { FIN_CATS } from './fin.js'

const CAT: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
const HEAD = { despesa: 'Gasto registrado!', receita: 'Receita registrada!', pagamento: 'Pagamento registrado!', transferencia: 'Transferência registrada!' }
const brl = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const nrm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim()

export async function save(u: SessionUser, p: FinParsed) {
  await useQuota(u, 'expense')
  const rows = await db().tx((t: any) => createItem(u, 'expense', { kind: p.tipo, amount: p.amount, description: p.description, category: p.category, date: p.date, subcategory: p.sub, method: p.method || '', time: p.time || '', notes: p.obs, movement: p.kind, source: 'chat' }, t))
  const it: any = serialize(rows[0]), tz = settingsOf(u).timezone
  const recent = (await getUM<any[]>(u.id, 'fin_recent', [])).filter((r) => Date.now() - r.at < 3600_000).slice(-19)
  recent.push({ fp: finFingerprint(p), at: Date.now(), id: it.id }); await setUM(u.id, 'fin_recent', recent)
  const catL = CAT[it.category] || it.category, when = `${humanDate(it.date, localDate(tz))}${p.time ? ` às ${p.time}` : ''}`
  const card = { kind: p.tipo, id: it.id, label: `${p.tipo === 'income' ? 'Receita' : 'Gasto'} · ${catL}`, headline: HEAD[p.kind], title: it.description, amount: it.amount, when, meta: [p.sub && p.sub !== it.description && p.sub !== catL ? p.sub : '', p.method || '', p.obs ? `Obs.: ${p.obs}` : ''].filter(Boolean) }
  let mei = ''
  if (p.tipo === 'income') { try { const f: any = await getUM<any>(u.id, 'fiscal', null); if (f?.consent) { const k = p.date.slice(0, 7); f.receitas = { ...(f.receitas || {}), [k]: Math.round(((Number(f.receitas?.[k]) || 0) + p.amount!) * 100) / 100 }; await setUM(u.id, 'fiscal', f); const st = await (await import('../routes/modules.js')).fiscalState(u.id); mei = ` Também somei ao faturamento do MEI: no ano você está em ${brl(st.faturamento)}, ${Math.round(st.usoLimite * 100)}% do limite.` } } catch {} }
  const verbo = { despesa: 'Gasto registrado', receita: 'Receita registrada', pagamento: 'Pagamento registrado', transferencia: 'Transferência registrada' }[p.kind]
  const cl = [catL !== it.description ? catL : '', p.sub && p.sub !== it.description && p.sub !== catL ? p.sub : ''].filter(Boolean).join(' › ')
  void card
  return { content: `${verbo}: ${brl(it.amount)} · ${it.description}${cl ? ` (${cl})` : ''}${p.method ? ` · ${p.method}` : ''}, ${when.toLowerCase()}.${mei} ⟦fin:${it.id}⟧`, cards: [] }
}

/** Retorna a resposta pronta quando a mensagem é uma movimentação financeira; senão null (segue para os outros motores). */
export async function financeReply(u: SessionUser, text: string): Promise<{ content: string; cards: any[] } | null> {
  const tz = settingsOf(u).timezone, t = nrm(text), extra = ((await getConfig<any>('fin_dict', {})).items || []) as any[]
  // comprovante com direção incerta: o usuário diz se entrou ou saiu
  const dp = await getUM<any>(u.id, 'doc_pending', null)
  if (dp && Date.now() - dp.at < 30 * 60_000) {
    const ent = /^(entrou|entrada|recebi|recebido|e entrada|foi entrada|dinheiro que entrou)\b/.test(t), sai = /^(saiu|saida|paguei|enviei|pago|e saida|foi saida|mandei|gastei|comprei)\b/.test(t)
    if (/^(nao|cancel[a-z]*|deixa|esquece|ignora)\b/.test(t)) { await setUM(u.id, 'doc_pending', null); return { content: 'Tudo bem, não registrei esse comprovante.', cards: [] } }
    if (dp.ready && /^(sim|pode|registra|registrar|confirmo|confirmar|ok|isso|lanca|lancar)\b/.test(t)) { await setUM(u.id, 'doc_pending', null); const r = await save(u, dp.p); await rememberDoc(u, dp.hash); return r }
    if (ent || sai) {
      await setUM(u.id, 'doc_pending', null)
      const p: FinParsed = { ...dp.p, kind: ent ? 'receita' : (dp.p.kindSaida || 'despesa'), tipo: ent ? 'income' : 'expense', category: ent ? (FIN_CATS.income.includes(dp.p.catEntrada) ? dp.p.catEntrada : 'outros') : (FIN_CATS.expense.includes(dp.p.catSaida) ? dp.p.catSaida : 'outros') }
      if (!p.amount) { await setUM(u.id, 'fin_pending', { p, at: Date.now() }); return { content: 'Qual foi o valor?', cards: [] } }
      const r = await save(u, p); await rememberDoc(u, dp.hash); return r
    }
  }
  const dd = await getUM<any>(u.id, 'doc_dup', null)
  if (dd && Date.now() - dd.at < 10 * 60_000) {
    await setUM(u.id, 'doc_dup', null)
    if (/^(sim|pode|registra|registrar|lanca|lancar|confirmo|isso|quero)\b/.test(t)) return documentReply(u, Buffer.from(dd.b64, 'base64'), dd.mime, dd.caption, true)
  }
  // confirmação de lançamento repetido
  const dup = await getUM<any>(u.id, 'fin_dup', null)
  if (dup && Date.now() - dup.at < 5 * 60_000) {
    await setUM(u.id, 'fin_dup', null)
    if (/^(sim|pode|registra|registrar|lanca|lancar|confirmo|isso|quero)\b/.test(t)) return save(u, dup.p)
    if (/^(nao|cancela|deixa|esquece)\b/.test(t)) return { content: 'Tudo bem, não registrei de novo.', cards: [] }
  }
  // completar um lançamento que ficou sem valor
  const pend = await getUM<any>(u.id, 'fin_pending', null)
  if (pend && Date.now() - pend.at < 10 * 60_000) {
    if (/^(nao|cancela|deixa|esquece)\b/.test(t)) { await setUM(u.id, 'fin_pending', null); return { content: 'Tudo bem, não registrei.', cards: [] } }
    const v = parseAmount(text), again = parseFinance(text, tz, extra)
    if (v && (!again || !again.amount || t.split(' ').length <= 4)) { await setUM(u.id, 'fin_pending', null); return save(u, { ...pend.p, amount: v }) }
  }
  // pagamento parcial: registra só o recebido; o saldo fica pendente e vinculado ao serviço
  const pc = await getUM<any>(u.id, 'fin_partial_confirm', null)
  if (pc && Date.now() - pc.at < 10 * 60_000) {
    if (/^(nao|cancela|deixa|esquece)\b/.test(t)) { await setUM(u.id, 'fin_partial_confirm', null); return { content: 'Tudo bem, não registrei nada.', cards: [] } }
    const v = parseAmount(text)
    if (v !== null && t.split(' ').length <= 6) { await setUM(u.id, 'fin_partial_confirm', null); return savePartial(u, { ...pc.p, recebido: v, pendente: Math.max(0, Math.round((pc.p.total - v) * 100) / 100), duvida: '' }, tz) }
    if (/^(sim|isso|confirmo|correto|certo|pode)\b/.test(t) && !pc.p.duvida) { await setUM(u.id, 'fin_partial_confirm', null); return savePartial(u, pc.p, tz) }
  }
  const pp = parsePartial(text)
  if (pp) {
    if (pp.duvida) { await setUM(u.id, 'fin_partial_confirm', { p: pp, at: Date.now() }); return { content: `${pp.duvida} Quanto você recebeu agora? (o total contratado é ${brl(pp.total)})`, cards: [] } }
    return savePartial(u, pp, tz)
  }
  const rem = parseRemainder(text)
  if (rem) { const r = await receiveRemainder(u, rem.valor, tz); if (r) return r }
  const p = parseFinance(text, tz, extra)
  if (!p) return null
  if (!p.amount) {
    await setUM(u.id, 'fin_pending', { p, at: Date.now() })
    const o = { despesa: 'Quanto você gastou', receita: 'Quanto você recebeu', pagamento: 'Qual foi o valor pago', transferencia: 'Qual foi o valor da transferência' }[p.kind]
    return { content: `${o}${p.description && !/^(Gasto|Recebimento|Transferência)$/.test(p.description) ? ` em ${p.description.toLowerCase()}` : ''}?`, cards: [] }
  }
  const fp = finFingerprint(p), recent = await getUM<any[]>(u.id, 'fin_recent', [])
  const same = recent.find((r) => r.fp === fp && Date.now() - r.at < 3 * 60_000)
  if (same) { await setUM(u.id, 'fin_dup', { p, at: Date.now() }); return { content: `Você já registrou ${brl(p.amount)} em ${p.description.toLowerCase()} agora há pouco, então não lancei de novo. Se foi outro lançamento igual, responda "sim" que eu registro.`, cards: [] } }
  return save(u, p)
}

/* ---------- comprovantes, notas e recibos (Gemini) ---------- */
async function rememberDoc(u: SessionUser, hash: string) { if (!hash) return; const l = (await getUM<any[]>(u.id, 'doc_hashes', [])).filter((x) => Date.now() - x.at < 120 * 86400_000).slice(-199); l.push({ h: hash, at: Date.now() }); await setUM(u.id, 'doc_hashes', l) }
const METH = ['Pix', 'Cartão de crédito', 'Cartão de débito', 'Dinheiro', 'Boleto', 'Transferência', 'TED/DOC']
export async function documentReply(u: SessionUser, data: Buffer, mime: string, caption: string, force = false): Promise<{ content: string; cards: any[] }> {
  const hash = createHash('sha256').update(data).digest('hex')
  if (!force && (await getUM<any[]>(u.id, 'doc_hashes', [])).some((x) => x.h === hash)) {
    if (data.length < 4_000_000) await setUM(u.id, 'doc_dup', { b64: data.toString('base64'), mime, caption, at: Date.now() })
    return { content: 'Esse mesmo comprovante já foi registrado antes, então não lancei de novo. Se for um lançamento diferente, responda "sim" que eu registro.', cards: [] }
  }
  const r = await analyzeDocument(data, mime, u.name, caption)
  if (!r.legivel) return { content: 'Não consegui ler esse arquivo com segurança. Envie uma foto mais nítida, bem iluminada e sem cortes, ou me diga o valor e o que foi.', cards: [] }
  if (!r.financeiro) return { content: r.resumo ? `${r.resumo}${/[.!?]$/.test(r.resumo) ? '' : '.'} Não encontrei uma movimentação financeira para registrar.` : 'Li o arquivo, mas não encontrei uma movimentação financeira para registrar.', cards: [] }
  const tz = settingsOf(u).timezone, today = localDate(tz)
  const saidaKind: FinParsed['kind'] = r.tipo === 'pagamento' ? 'pagamento' : r.tipo === 'transferencia' ? 'transferencia' : 'despesa'
  const quem = r.estabelecimento
  const base: any = { amount: r.valor, sub: '', date: r.data && r.data <= today ? r.data : today, time: r.hora, method: METH.find((m) => m.toLowerCase() === r.forma_pagamento.toLowerCase()) || (r.forma_pagamento ? r.forma_pagamento : null), obs: ['Lido de comprovante', r.descricao && r.descricao !== quem ? r.descricao : ''].filter(Boolean).join(' · '), person: '', kindSaida: saidaKind, catEntrada: r.categoria, catSaida: r.categoria }
  const descOf = (ent: boolean) => (quem ? (ent ? `Recebido de ${quem}` : saidaKind === 'transferencia' ? `Transferência para ${quem}` : quem) : r.descricao || (ent ? 'Recebimento' : 'Pagamento')).slice(0, 120)
  if (r.direcao === 'incerta' || r.confianca < 0.6) {
    await setUM(u.id, 'doc_pending', { p: { ...base, description: descOf(false) }, at: Date.now(), hash })
    return { content: `Li um comprovante${r.valor ? ` de R$ ${r.valor.toFixed(2).replace('.', ',')}` : ''}${quem ? ` com ${quem}` : ''}${r.data ? ` em ${r.data.split('-').reverse().join('/')}` : ''}, mas não tenho certeza da direção. Esse dinheiro entrou ou saiu da sua conta? Responda "entrou" ou "saiu".`, cards: [] }
  }
  const ent = r.direcao === 'entrada'
  const p: FinParsed = { ...base, kind: ent ? 'receita' : saidaKind, tipo: ent ? 'income' : 'expense', category: ent ? (FIN_CATS.income.includes(r.categoria) ? r.categoria : 'outros') : (FIN_CATS.expense.includes(r.categoria) ? r.categoria : 'outros'), description: ent ? descOf(true) : descOf(false) }
  if (!p.amount) { await setUM(u.id, 'fin_pending', { p, at: Date.now() }); await rememberDoc(u, hash); return { content: `Li o comprovante${quem ? ` de ${quem}` : ''}, mas o valor não está legível. Qual foi o valor?`, cards: [] } }
  // não registra sozinho: mostra o que leu e pede confirmação
  await setUM(u.id, 'doc_pending', { p, at: Date.now(), hash, ready: true })
  const CATN: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
  const linha = [`${ent ? 'Entrada' : 'Saída'} de R$ ${p.amount.toFixed(2).replace('.', ',')}`, p.description, p.date.split('-').reverse().join('/') + (p.time ? ' às ' + p.time : ''), p.method || '', CATN[p.category] || p.category].filter(Boolean).join(' · ')
  return { content: `Li o comprovante: ${linha}. Confirma o registro no seu financeiro? ⟦docok:${ent ? 'entrada' : 'saida'}⟧`, cards: [] }
}

/* ---------- recebimentos parciais e saldos a receber ---------- */
type Receb = { id: string; descricao: string; pessoa: string; total: number; recebido: number; pendente: number; itens: number[]; criado: number; quitado?: number }
async function savePartial(u: SessionUser, pp: { total: number; recebido: number; pendente: number; descricao: string; pessoa: string }, tz: string) {
  const id = 'rc' + Date.now().toString(36)
  let itemId: number | null = null, txt = ''
  if (pp.recebido > 0) {
    const desc = `${pp.descricao}${pp.pessoa ? ` · ${pp.pessoa}` : ''} (entrada)`
    const r = await save(u, { kind: 'receita', tipo: 'income', amount: pp.recebido, category: 'servicos', sub: 'Serviços prestados', description: desc, date: localDate(tz), time: null, method: null, obs: `Total contratado ${brl(pp.total)} · saldo pendente ${brl(pp.pendente)}`, person: pp.pessoa } as any)
    itemId = Number(/⟦fin:(\d+)⟧/.exec(r.content)?.[1]) || null; txt = r.content.replace(/⟦fin:\d+⟧/, '').trim()
  }
  const lista = await getUM<Receb[]>(u.id, 'fin_receber', [])
  if (pp.pendente > 0) { lista.push({ id, descricao: pp.descricao, pessoa: pp.pessoa, total: pp.total, recebido: pp.recebido, pendente: pp.pendente, itens: itemId ? [itemId] : [], criado: Date.now() }); await setUM(u.id, 'fin_receber', lista.slice(-200)) }
  return { content: `Total contratado: ${brl(pp.total)} · Receita recebida: ${brl(pp.recebido)} · Saldo pendente: ${brl(pp.pendente)}.${pp.pendente > 0 ? ` Quando o cliente pagar o restante, é só me avisar (ex.: "o cliente pagou o restante") que eu registro sem duplicar.` : ''}${itemId ? ` ⟦fin:${itemId}⟧` : ''}`, cards: [] }
}
async function receiveRemainder(u: SessionUser, valor: number | null, tz: string) {
  const lista = await getUM<Receb[]>(u.id, 'fin_receber', [])
  const abertos = lista.filter((r) => r.pendente > 0.009)
  if (!abertos.length) { const ult = lista.filter((r) => r.quitado).slice(-1)[0]; return ult && Date.now() - (ult.quitado || 0) < 7 * 86400_000 ? { content: `O saldo de ${ult.descricao.toLowerCase()} já foi recebido (total ${brl(ult.total)}), então não registrei de novo.`, cards: [] } : null }
  const r = abertos[abertos.length - 1], v = valor ?? r.pendente
  if (v > r.pendente + 0.009) { await setUM(u.id, 'fin_partial_confirm', null); return { content: `O saldo pendente de ${r.descricao.toLowerCase()} é ${brl(r.pendente)}, mas você informou ${brl(v)}. Quanto foi recebido agora?`, cards: [] } }
  const res = await save(u, { kind: 'receita', tipo: 'income', amount: v, category: 'servicos', sub: 'Serviços prestados', description: `${r.descricao}${r.pessoa ? ` · ${r.pessoa}` : ''} (${v >= r.pendente - 0.009 ? 'restante' : 'parcela'})`, date: localDate(tz), time: null, method: null, obs: `Referente ao total de ${brl(r.total)}`, person: r.pessoa } as any)
  const id = Number(/⟦fin:(\d+)⟧/.exec(res.content)?.[1]) || null
  r.recebido = Math.round((r.recebido + v) * 100) / 100; r.pendente = Math.max(0, Math.round((r.total - r.recebido) * 100) / 100); if (id) r.itens.push(id); if (r.pendente <= 0.009) r.quitado = Date.now()
  await setUM(u.id, 'fin_receber', lista)
  return { content: `Recebimento registrado: ${brl(v)} de ${r.descricao.toLowerCase()}. Recebido no total: ${brl(r.recebido)} de ${brl(r.total)}${r.pendente > 0 ? ` · ainda falta ${brl(r.pendente)}` : ' · serviço quitado ✓'}.${id ? ` ⟦fin:${id}⟧` : ''}`, cards: [] }
}
export async function receivablesOf(userId: number) { return (await getUM<Receb[]>(userId, 'fin_receber', [])).filter((r) => r.pendente > 0.009) }
