// Liga o motor financeiro ao chat: pergunta só o que falta, evita duplicidade e grava no módulo financeiro.
import type { SessionUser } from '../lib/session.js'
import { db } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { getUM, setUM } from '../lib/usermod.js'
import { useQuota } from '../lib/usage.js'
import { createItem, serialize } from '../routes/items.js'
import { humanDate, localDate } from '../lib/time.js'
import { parseFinance, parseAmount, finFingerprint, type FinParsed } from './fin.js'
import { getConfig } from '../lib/settings.js'

const CAT: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
const HEAD = { despesa: 'Gasto registrado!', receita: 'Receita registrada!', pagamento: 'Pagamento registrado!', transferencia: 'Transferência registrada!' }
const brl = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const nrm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim()

async function save(u: SessionUser, p: FinParsed) {
  await useQuota(u, 'expense')
  const rows = await db().tx((t: any) => createItem(u, 'expense', { kind: p.tipo, amount: p.amount, description: p.description, category: p.category, date: p.date, subcategory: p.sub, method: p.method || '', time: p.time || '', notes: p.obs, movement: p.kind, source: 'chat' }, t))
  const it: any = serialize(rows[0]), tz = settingsOf(u).timezone
  const recent = (await getUM<any[]>(u.id, 'fin_recent', [])).filter((r) => Date.now() - r.at < 3600_000).slice(-19)
  recent.push({ fp: finFingerprint(p), at: Date.now(), id: it.id }); await setUM(u.id, 'fin_recent', recent)
  const catL = CAT[it.category] || it.category, when = `${humanDate(it.date, localDate(tz))}${p.time ? ` às ${p.time}` : ''}`
  const card = { kind: p.tipo, id: it.id, label: `${p.tipo === 'income' ? 'Receita' : 'Gasto'} · ${catL}`, headline: HEAD[p.kind], title: it.description, amount: it.amount, when, meta: [p.sub && p.sub !== it.description && p.sub !== catL ? p.sub : '', p.method || '', p.obs ? `Obs.: ${p.obs}` : ''].filter(Boolean) }
  let mei = ''
  if (p.tipo === 'income') { try { const f: any = await getUM<any>(u.id, 'fiscal', null); if (f?.consent) { const k = p.date.slice(0, 7); f.receitas = { ...(f.receitas || {}), [k]: Math.round(((Number(f.receitas?.[k]) || 0) + p.amount!) * 100) / 100 }; await setUM(u.id, 'fiscal', f); const st = await (await import('../routes/modules.js')).fiscalState(u.id); mei = ` Também somei ao faturamento do MEI: no ano você está em ${brl(st.faturamento)}, ${Math.round(st.usoLimite * 100)}% do limite.` } } catch {} }
  const verbo = { despesa: 'Gasto registrado', receita: 'Receita registrada', pagamento: 'Pagamento registrado', transferencia: 'Transferência registrada' }[p.kind]
  const cl = [catL !== it.description ? catL : '', p.sub && p.sub !== it.description && p.sub !== catL ? p.sub : ''].filter(Boolean).join(' › ')
  void card
  return { content: `${verbo}: ${brl(it.amount)} · ${it.description}${cl ? ` (${cl})` : ''}${p.method ? ` · ${p.method}` : ''}, ${when.toLowerCase()}.${mei} ⟦fin:${it.id}⟧`, cards: [] }
}

/** Retorna a resposta pronta quando a mensagem é uma movimentação financeira; senão null (segue para os outros motores). */
export async function financeReply(u: SessionUser, text: string): Promise<{ content: string; cards: any[] } | null> {
  const tz = settingsOf(u).timezone, t = nrm(text), extra = ((await getConfig<any>('fin_dict', {})).items || []) as any[]
  // confirmação de lançamento repetido
  const dup = await getUM<any>(u.id, 'fin_dup', null)
  if (dup && Date.now() - dup.at < 5 * 60_000) {
    await setUM(u.id, 'fin_dup', null)
    if (/^(sim|pode|registra|registrar|lanca|lancar|confirmo|isso|quero)\b/.test(t)) return save(u, dup.p)
    if (/^(nao|cancela|deixa|esquece)\b/.test(t)) return { content: 'Tudo bem, não registrei de novo.', cards: [] }
  }
  // completar um lançamento que ficou sem valor
  const pend = await getUM<any>(u.id, 'fin_pending', null)
  if (pend && Date.now() - pend.at < 10 * 60_000) {
    if (/^(nao|cancela|deixa|esquece)\b/.test(t)) { await setUM(u.id, 'fin_pending', null); return { content: 'Tudo bem, não registrei.', cards: [] } }
    const v = parseAmount(text), again = parseFinance(text, tz, extra)
    if (v && (!again || !again.amount || t.split(' ').length <= 4)) { await setUM(u.id, 'fin_pending', null); return save(u, { ...pend.p, amount: v }) }
  }
  const p = parseFinance(text, tz, extra)
  if (!p) return null
  if (!p.amount) {
    await setUM(u.id, 'fin_pending', { p, at: Date.now() })
    const o = { despesa: 'Quanto você gastou', receita: 'Quanto você recebeu', pagamento: 'Qual foi o valor pago', transferencia: 'Qual foi o valor da transferência' }[p.kind]
    return { content: `${o}${p.description && !/^(Gasto|Recebimento|Transferência)$/.test(p.description) ? ` em ${p.description.toLowerCase()}` : ''}?`, cards: [] }
  }
  const fp = finFingerprint(p), recent = await getUM<any[]>(u.id, 'fin_recent', [])
  const same = recent.find((r) => r.fp === fp && Date.now() - r.at < 3 * 60_000)
  if (same) { await setUM(u.id, 'fin_dup', { p, at: Date.now() }); return { content: `Você já registrou ${brl(p.amount)} em ${p.description.toLowerCase()} agora há pouco, então não lancei de novo. Se foi outro lançamento igual, responda "sim" que eu registro.`, cards: [] } }
  return save(u, p)
}
