// Reconhece pedidos de compromisso ("agendar uma reunião amanhã às 10:00 com João") e agenda direto,
// sem depender da IA e sem inventar local.
import { localDate } from '../lib/time.js'
const nrm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const WD = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado']
function addDays(iso: string, n: number) { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
export function parseAppointment(text: string, tz: string) {
  const s = nrm(text)
  if (!/\b(agend|marc|marque|reuni|compromisso|consulta|encontro)/.test(s)) return null
  if (/\b(lembr|me avise|tarefa|conta |gastei|paguei|cancel|desmarc|remarc|apag|exclu)/.test(s)) return null
  const tm = s.match(/\b(?:as|às|a partir das|pelas)\s*(\d{1,2})(?:[:h](\d{2}))?\s*(?:h|horas?)?\b/) || s.match(/\b(\d{1,2})[:h](\d{2})\b/) || s.match(/\b(\d{1,2})\s*h\b/)
  const meio = /\bmeio[- ]dia\b/.test(s)
  if (!tm && !meio) return null
  let hh = meio ? 12 : Number(tm![1]), mm = meio ? 0 : Number(tm![2] || 0)
  if (/\b(da tarde|a tarde|da noite|a noite)\b/.test(s) && hh < 12) hh += 12
  if (hh > 23 || mm > 59) return null
  const today = localDate(tz); let date: string | null = null
  if (/depois de amanha/.test(s)) date = addDays(today, 2)
  else if (/\bamanha\b/.test(s)) date = addDays(today, 1)
  else if (/\bhoje\b/.test(s)) date = today
  else { const w = WD.findIndex((d) => new RegExp(`\\b${d}(-feira)?\\b`).test(s)); if (w >= 0) { const cur = new Date(today + 'T12:00:00Z').getUTCDay(); date = addDays(today, ((w - cur + 7) % 7) || 7) }
    else { const dm = s.match(/\bdia\s+(\d{1,2})(?:\/(\d{1,2}))?/); if (dm) { const [y, m] = today.split('-').map(Number); let mo = dm[2] ? Number(dm[2]) : m, yr = y; let iso = `${yr}-${String(mo).padStart(2, '0')}-${String(Number(dm[1])).padStart(2, '0')}`; if (!dm[2] && iso < today) { mo = m === 12 ? 1 : m + 1; yr = m === 12 ? y + 1 : y; iso = `${yr}-${String(mo).padStart(2, '0')}-${String(Number(dm[1])).padStart(2, '0')}` } if (!isNaN(Date.parse(iso))) date = iso } } }
  if (!date) return null
  const pm = text.match(/\bcom\s+(?:o |a |os |as |dr\.? |dra\.? )?([A-ZÀ-Ý][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+)?)/)
  const person = pm ? pm[1].trim() : ''
  let kind = /reuni/.test(s) ? 'Reunião' : /consulta/.test(s) ? 'Consulta' : /encontro/.test(s) ? 'Encontro' : ''
  if (!kind) {
    const m = text.match(/\b(?:agend\w*|marc\w*|marque)\s+(?:uma?|o|a|meu|minha)?\s*([^,.;!?]+?)(?=\s+(?:para\s+)?(?:hoje|amanh[ãa]|depois|dia|segunda|ter[çc]a|quarta|quinta|sexta|s[áa]bado|domingo|[àa]s|ao|com|$))/i)
    kind = m && m[1] && m[1].trim().length > 1 ? m[1].trim().replace(/^\w/, (c) => c.toUpperCase()) : 'Compromisso'
  }
  const title = person && !new RegExp(person, 'i').test(kind) ? `${kind} com ${person}` : kind
  return { title: title.slice(0, 120), date, time: `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`, person }
}
