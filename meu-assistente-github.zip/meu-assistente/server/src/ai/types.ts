// Tipos compartilhados do motor multi-IA.
export type Kind = 'openai' | 'gemini' | 'anthropic'
export type Cap = 'texto' | 'ferramentas' | 'imagem' | 'documento' | 'audio' | 'codigo' | 'pesquisa'
export const CAPS: Cap[] = ['texto', 'ferramentas', 'imagem', 'documento', 'audio', 'codigo', 'pesquisa']
export const CAP_LABEL: Record<Cap, string> = { texto: 'Conversa', ferramentas: 'Ferramentas', imagem: 'Imagens', documento: 'Documentos', audio: 'Áudio', codigo: 'Programação', pesquisa: 'Pesquisa' }
export type Task = 'conversa' | 'agente' | 'contexto' | 'analise' | 'codigo' | 'pesquisa' | 'imagem' | 'documento' | 'audio'

export interface FilePart { mime: string; data: string /* base64 */ }
export interface ChatMsg {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string | null
  tool_calls?: { id: string; type: 'function'; function: { name: string; arguments: string }; extra_content?: any }[]
  tool_call_id?: string
  files?: FilePart[] // anexos (imagem, PDF, áudio) enviados junto desta mensagem
}
export interface ToolDef { type: 'function'; function: { name: string; description: string; parameters: object } }

export interface Target {
  id: string; nome: string; kind: Kind; url: string; key: string; model: string; modelAudio: string
  caps: Record<Cap, boolean>; sig: string; reserva: boolean
}
export interface ChatReq { messages: ChatMsg[]; tools?: ToolDef[]; temperature: number; json?: boolean; grounding?: boolean; signal: AbortSignal }
export interface ChatRes { message: ChatMsg; usage?: { in: number; out: number }; finish?: string; grounded?: boolean }
export interface Adapter {
  kind: Kind
  chat(t: Target, r: ChatReq): Promise<ChatRes>
  transcribe?(t: Target, data: Buffer, mime: string, signal: AbortSignal): Promise<{ text: string; usage?: { in: number; out: number } }>
}

export type ErrKind = 'timeout' | 'rate_limit' | 'auth' | 'config' | 'bad_request' | 'server' | 'network' | 'invalid_response' | 'blocked'
/** Erro padronizado: todo adaptador traduz as falhas do seu provedor para estas categorias. */
export class AiError extends Error {
  constructor(public kind: ErrKind, message: string, public status?: number, public retryAfterMs?: number, public detail?: string) { super(message) }
}
export const HARD: ErrKind[] = ['auth', 'config'] // só se resolvem trocando a configuração (ou quando o monitor confirma a recuperação)
export const TRANSIENT: ErrKind[] = ['timeout', 'network', 'server']

export function httpError(status: number, body: any, headers?: Headers): AiError {
  const e0 = Array.isArray(body) ? body[0] : body
  const em = e0?.error?.message || e0?.message || (typeof e0?.error === 'string' ? e0.error : '') || ''
  const es = String(e0?.error?.status || e0?.error?.type || e0?.error?.code || '')
  const detail = (em || JSON.stringify(body || '')).slice(0, 300)
  let ra = Number(headers?.get('retry-after')) * 1000 || 0
  const rd = /"retryDelay"\s*:\s*"(\d+(?:\.\d+)?)s"/.exec(JSON.stringify(body || ''))
  if (!ra && rd) ra = Math.ceil(Number(rd[1]) * 1000)
  const low = (em + ' ' + es).toLowerCase()
  // o Gemini devolve chave inválida como 400 INVALID_ARGUMENT, não como 401
  if (status === 401 || status === 403 || /api key not valid|api_key_invalid|invalid api key|incorrect api key|invalid x-api-key|permission_denied|has not been used in project|unauthenticated/.test(low)) return new AiError('auth', `Chave recusada (${status})`, status, 0, detail)
  if (status === 429 || /resource_exhausted|rate.?limit|quota/.test(es.toLowerCase())) return new AiError('rate_limit', 'Limite de requisições atingido (429)', status, ra, detail)
  if (status === 404) return new AiError('config', 'Modelo ou endereço não encontrado (404)', status, 0, detail)
  if (status === 400 || status === 422) return new AiError('bad_request', `Requisição recusada (${status})`, status, 0, detail)
  if (status === 408 || status === 504) return new AiError('timeout', `Tempo esgotado no serviço (${status})`, status, 0, detail)
  if (status >= 500 || status === 529) return new AiError('server', `Serviço indisponível (${status})`, status, ra, detail)
  return new AiError('server', `Erro ${status}`, status, ra, detail)
}
export function netError(e: any): AiError {
  if (e instanceof AiError) return e
  if (e?.name === 'AbortError' || e?.name === 'TimeoutError') return new AiError('timeout', 'Tempo esgotado')
  return new AiError('network', 'Falha de conexão', undefined, 0, String(e?.cause?.code || e?.message || e).slice(0, 200))
}
export const rid = () => Math.random().toString(36).slice(2, 10)
export function parseJsonLoose(s: string): any {
  const t = String(s || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```$/i, '').trim()
  try { return JSON.parse(t) } catch { const m = /\{[\s\S]*\}/.exec(t); if (m) return JSON.parse(m[0]); throw new Error('json') }
}
