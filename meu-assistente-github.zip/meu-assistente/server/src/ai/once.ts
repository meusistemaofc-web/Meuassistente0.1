// Execução única: impede que a troca de IA (ou um reenvio do aplicativo) repita lançamentos financeiros,
// agendamentos ou pedidos. A mesma chave dentro da janela devolve o resultado da primeira execução.
import { createHash } from 'node:crypto'
const cache = new Map<string, { at: number; ms: number; p: Promise<any> }>()
export function canon(v: any): string {
  if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']'
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}'
  return JSON.stringify(v ?? null)
}
export const hashOf = (s: string | Buffer) => createHash('sha1').update(s).digest('hex').slice(0, 20)
export async function once<T>(scope: string, key: string, ms: number, fn: () => Promise<T>): Promise<{ value: T; hit: boolean }> {
  const now = Date.now()
  if (cache.size > 500) for (const [k, v] of cache) if (now - v.at > v.ms) cache.delete(k)
  const k = scope + '|' + key, ex = cache.get(k)
  if (ex && now - ex.at < ex.ms) return { value: await ex.p, hit: true }
  const p = fn(); cache.set(k, { at: now, ms, p })
  try { return { value: await p, hit: false } } catch (e) { cache.delete(k); throw e }
}
