// Motor universal de movimentações financeiras do chat: entende receitas, despesas, pagamentos e transferências
// em linguagem natural, classifica nas categorias do sistema (com subcategorias) e nunca inventa valores.
// Para ampliar, basta acrescentar palavras ao dicionário abaixo (FIN_DICT); nenhuma regra por tipo de gasto.
import { localDate } from '../lib/time.js'

export type FinKind = 'despesa' | 'receita' | 'pagamento' | 'transferencia'
const nrm = (t: string) => t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')

/** Categoria do sistema → subcategoria → palavras. As categorias são as mesmas do módulo financeiro. */
export const FIN_DICT: { tipo: 'expense' | 'income'; cat: string; sub: string; words: string[] }[] = []
const add = (tipo: 'expense' | 'income', cat: string, subs: Record<string, string[]>) => { for (const [sub, words] of Object.entries(subs)) FIN_DICT.push({ tipo, cat, sub, words: words.map(nrm) }) }
add('expense', 'alimentacao', { Mercado: ['mercado', 'supermercado', 'feira', 'hortifruti', 'acougue', 'padaria', 'atacadao', 'sacolao'], 'Restaurante e lanches': ['restaurante', 'almoco', 'almocei', 'jantar', 'jantei', 'lanche', 'lanchei', 'lanchonete', 'pizza', 'hamburguer', 'ifood', 'delivery', 'cafe', 'sorvete', 'marmita', 'acai', 'pastel', 'churrasco', 'bar ', 'cerveja', 'refrigerante', 'comida'] })
add('expense', 'combustivel', { Combustível: ['gasolina', 'abasteci', 'abastecer', 'combustivel', 'etanol', 'alcool no carro', 'diesel', 'posto', 'gnv'] })
add('expense', 'transporte', { 'App de transporte': ['uber', ' 99 ', 'taxi', 'indrive', 'corrida'], 'Transporte público': ['onibus', 'metro', 'trem', 'passagem', 'bilhete unico', 'brt'], 'Estacionamento e pedágio': ['estacionamento', 'pedagio', 'zona azul'], 'Veículo': ['mecanico', 'oficina', 'pneu', 'revisao', 'troca de oleo', 'lava jato', 'lavagem do carro', 'ipva', 'licenciamento', 'seguro do carro', 'multa'] })
add('expense', 'casa', { Aluguel: ['aluguel'], Condomínio: ['condominio'], Energia: ['conta de luz', 'energia', ' luz'], Água: ['conta de agua', 'agua e esgoto', 'saneamento'], 'Internet e telefone': ['internet', 'telefone', 'plano de celular', 'wi-fi', 'wifi', 'recarga'], Gás: ['gas', 'botijao'], Manutenção: ['reforma', 'material de construcao', 'encanador', 'eletricista', 'conserto', 'pintor'], Limpeza: ['produtos de limpeza', 'diarista', 'faxina', 'lavanderia'] })
add('expense', 'saude', { Farmácia: ['farmacia', 'remedio', 'medicamento', 'drogaria'], 'Consultas e exames': ['consulta', 'medico', 'dentista', 'exame', 'psicologo', 'terapia', 'fisioterapia', 'hospital', 'clinica'], 'Plano de saúde': ['plano de saude', 'convenio'], 'Academia e esporte': ['academia', 'personal', 'crossfit', 'pilates', 'natacao'] })
add('expense', 'lazer', { Assinaturas: ['netflix', 'spotify', 'amazon prime', 'disney', 'hbo', 'max ', 'youtube premium', 'globoplay', 'deezer', 'assinatura'], 'Passeios e viagens': ['cinema', 'show', 'teatro', 'ingresso', 'passeio', 'viagem', 'hotel', 'pousada', 'parque', 'balada', 'festa'], Jogos: ['jogo', 'game', 'steam', 'playstation', 'xbox'] })
add('expense', 'compras', { 'Roupas e calçados': ['roupa', 'camisa', 'camiseta', 'calca', 'tenis', 'sapato', 'vestido', 'blusa', 'bermuda', 'chinelo', 'bolsa'], Eletrônicos: ['celular novo', 'fone', 'notebook', 'computador', 'televisao', ' tv', 'carregador', 'tablet'], 'Casa e decoração': ['movel', 'sofa', 'cama', 'colchao', 'decoracao', 'utensilio', 'panela', 'eletrodomestico'], Presentes: ['presente'], 'Beleza e cuidados': ['salao', 'cabeleireiro', 'barbeiro', 'barbearia', 'manicure', 'perfume', 'maquiagem', 'cosmetico', 'shampoo'] , 'Compras online': ['shopee', 'mercado livre', 'amazon', 'shein', 'aliexpress', 'magalu'] })
add('expense', 'trabalho', { 'Material de trabalho': ['material de escritorio', 'ferramenta', 'equipamento', 'impressao', 'papelaria'], 'Impostos e taxas': ['das', 'imposto', 'taxa', 'tarifa bancaria', 'anuidade'] })
add('expense', 'outros', { Educação: ['curso', 'faculdade', 'mensalidade', 'escola', 'livro', 'material escolar', 'apostila'], Pets: ['pet', 'racao', 'veterinario', 'banho e tosa', 'cachorro', 'gato'], Doações: ['doacao', 'dizimo', 'oferta na igreja'], Empréstimo: ['emprestei', 'emprestimo', 'parcela do emprestimo'] })
add('income', 'salario', { Salário: ['salario', 'holerite', 'pagamento do mes', 'decimo terceiro', '13o', 'ferias', 'adiantamento'] })
add('income', 'servicos', { 'Serviços prestados': ['servico', 'freela', 'freelance', 'cliente', 'consultoria', 'diaria', 'trabalho extra', 'bico', 'comissao'] })
add('income', 'vendas', { Vendas: ['vendi', 'venda', 'vendas'] })
add('income', 'outros', { Rendimentos: ['rendimento', 'juros', 'dividendo', 'cashback'], Reembolso: ['reembolso', 'devolveram', 'estorno', 'devolucao'], 'Presente/ajuda': ['mesada', 'ajuda', 'presente'], Aluguel: ['aluguel recebido', 'recebi o aluguel'] })

const VERB = {
  receita: /\b(recebi|ganhei|entrou|entraram|caiu|cairam|me pagaram|me pagou|me transferiram|me mandaram|faturei|vendi|rendeu|recebimento|ganho)\b/,
  transferencia: /\b(transferi|transferencia|mandei (um )?pix|enviei (um )?pix|fiz (um )?pix|passei (um )?pix|mandei|enviei)\b/,
  pagamento: /\b(paguei|pago|quitei|pagamento d[aeo]|acertei|liquidei)\b/,
  despesa: /\b(gastei|gasto|comprei|compra|custou|saiu|torrei|desembolsei|investi|abasteci|almocei|jantei|lanchei|tomei|fui (ao|no|na)|botei)\b/,
}
const NOT = /\b(quanto|quais|qual|resumo|relatorio|extrato|saldo|como esta|me lembr|lembrete|vou pagar|tenho que|preciso pagar|vence|vencimento|agendar|cancel|apag|exclu|desfaz|remov|edita|corrig)\b/
const NUMW: Record<string, number> = { um: 1, uma: 1, dois: 2, duas: 2, tres: 3, quatro: 4, cinco: 5, seis: 6, sete: 7, oito: 8, nove: 9, dez: 10, vinte: 20, trinta: 30, quarenta: 40, cinquenta: 50, sessenta: 60, setenta: 70, oitenta: 80, noventa: 90, cem: 100, duzentos: 200, trezentos: 300, quinhentos: 500 }

export function parseAmount(raw: string): number | null {
  const s = nrm(raw).replace(/r\$\s*/g, 'r$')
  let m = s.match(/(?:r\$)?\s?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(mil|k)?\b/g)
  const cands: number[] = []
  for (const tok of m || []) {
    const x = tok.match(/(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(mil|k)?/)!
    let v = x[1].includes(',') || /\.\d{3}/.test(x[1]) ? Number(x[1].replace(/\./g, '').replace(',', '.')) : Number(x[1])
    if (x[2]) v *= 1000
    const ctx = s.slice(Math.max(0, s.indexOf(tok) - 1), s.indexOf(tok) + tok.length + 8)
    if (/\b(as|às|dia)\s*$/.test(s.slice(0, s.indexOf(tok)).trim().slice(-4)) || /^\s*\d+\s*(h|horas?|hrs?|min)\b/.test(ctx.slice(1)) || /\d+[:h]\d{2}/.test(tok)) continue
    if (v > 0) cands.push(v)
  }
  if (!cands.length) { const w = s.match(/\b(um|uma|dois|duas|tres|quatro|cinco|seis|sete|oito|nove|dez|vinte|trinta|quarenta|cinquenta|sessenta|setenta|oitenta|noventa|cem|duzentos|trezentos|quinhentos)\s+(reais|real|conto|contos|pila)\b/); if (w) cands.push(NUMW[w[1]]) }
  if (!cands.length) return null
  const withCur = (s.match(/r\$\s?([\d.,]+)/) || s.match(/([\d.,]+)\s*(reais|real|conto|contos|pila)/))
  if (withCur) { const v = withCur[1].includes(',') || /\.\d{3}/.test(withCur[1]) ? Number(withCur[1].replace(/\./g, '').replace(',', '.')) : Number(withCur[1]); if (v > 0) return Math.round(v * 100) / 100 }
  return Math.round(cands[0] * 100) / 100
}
function addDays(iso: string, n: number) { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
const WD = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado']
function parseDate(s: string, tz: string) {
  const today = localDate(tz)
  if (/\banteontem\b/.test(s)) return addDays(today, -2)
  if (/\bontem\b/.test(s)) return addDays(today, -1)
  const dm = s.match(/\bdia\s+(\d{1,2})(?:\/(\d{1,2}))?/) || s.match(/\b(\d{1,2})\/(\d{1,2})(?:\/\d{2,4})?\b/)
  if (dm) { const [y, m] = today.split('-').map(Number); const mo = dm[2] ? Number(dm[2]) : m; let iso = `${y}-${String(mo).padStart(2, '0')}-${String(Number(dm[1])).padStart(2, '0')}`; if (iso > today) iso = `${y - (dm[2] ? 1 : 0)}-${String(dm[2] ? mo : (m === 1 ? 12 : m - 1)).padStart(2, '0')}-${String(Number(dm[1])).padStart(2, '0')}`; if (!isNaN(Date.parse(iso))) return iso }
  const w = WD.findIndex((d) => new RegExp(`\\b(n[ao] |n[ao] ultim[ao] )?${d}(-feira)?\\b`).test(s)); if (w >= 0) { const cur = new Date(today + 'T12:00:00Z').getUTCDay(); return addDays(today, -(((cur - w + 7) % 7) || 7)) }
  return today
}
const METHODS: [RegExp, string][] = [[/\bpix\b/, 'Pix'], [/\b(cartao de credito|no credito|credito)\b/, 'Cartão de crédito'], [/\b(cartao de debito|no debito|debito)\b/, 'Cartão de débito'], [/\bcartao\b/, 'Cartão'], [/\b(dinheiro|especie|em maos)\b/, 'Dinheiro'], [/\bboleto\b/, 'Boleto'], [/\b(vale refeicao|vale alimentacao|\bvr\b|\bva\b)\b/, 'Vale-refeição'], [/\btransferencia\b/, 'Transferência'], [/\bted\b|\bdoc\b/, 'TED/DOC']]

export interface FinParsed { kind: FinKind; tipo: 'expense' | 'income'; amount: number | null; category: string; sub: string; description: string; date: string; time: string | null; method: string | null; obs: string; person: string }

export const FIN_CATS = { expense: ['alimentacao', 'combustivel', 'casa', 'trabalho', 'compras', 'saude', 'transporte', 'lazer', 'outros'], income: ['salario', 'servicos', 'vendas', 'outros'] }
export function parseFinance(text: string, tz: string, extra: { tipo: 'expense' | 'income'; cat: string; sub: string; words: string[] }[] = []): FinParsed | null {
  const s = ' ' + nrm(text).replace(/[!?.]+$/, '') + ' '
  if (NOT.test(s) || /\?\s*$/.test(text)) return null
  let kind: FinKind | null = VERB.receita.test(s) ? 'receita' : VERB.transferencia.test(s) && !VERB.pagamento.test(s) ? 'transferencia' : VERB.pagamento.test(s) ? 'pagamento' : VERB.despesa.test(s) ? 'despesa' : null
  // "mandei" sozinho só é transferência quando há destinatário ou pix
  if (kind === 'transferencia' && !/\b(pix|transfer|para|pra|pro)\b/.test(s)) kind = null
  const dict = [...extra.map((e) => ({ ...e, words: e.words.map(nrm) })), ...FIN_DICT]
  const hit = dict.sort((a, b) => Math.max(...b.words.map((w) => w.length)) - Math.max(...a.words.map((w) => w.length))).find((e) => (kind === 'receita' ? e.tipo === 'income' : kind ? e.tipo === 'expense' : true) && e.words.some((w) => s.includes(w.startsWith(' ') || w.endsWith(' ') ? w : ` ${w}`) || s.includes(` ${w.trim()} `)))
  const amount = parseAmount(text)
  if (!kind) { if (hit && amount && hit.tipo === 'expense' && s.trim().split(' ').length <= 6) kind = 'despesa'; else return null }
  const tipo = kind === 'receita' ? 'income' : 'expense'
  const tm = s.match(/\b(?:as|às)\s*(\d{1,2})(?:[:h](\d{2}))?\s*h?\b/)
  const time = tm && Number(tm[1]) < 24 ? `${String(Number(tm[1])).padStart(2, '0')}:${String(Number(tm[2] || 0)).padStart(2, '0')}` : null
  const method = (METHODS.find(([re]) => re.test(s)) || [null, null])[1]
  const pm = text.match(/\b(?:para|pra|pro|ao|à|a|do|da|de)\s+([A-ZÀ-Ý][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+)?)/)
  const person = pm && !/^(Pix|Uber|Netflix|Spotify|Ifood|Shopee|Amazon)$/i.test(pm[1]) ? pm[1] : ''
  const om = text.match(/\b(?:obs:?|observa[cç][aã]o:?|porque|pois)\s+(.{3,120})$/i)
  // descrição: o objeto da frase, sem valor, data, horário e forma de pagamento (limites de palavra com acentos)
  const W = (alts: string) => new RegExp(`(?<![\\p{L}\\d])(?:${alts})(?![\\p{L}\\d])`, 'giu')
  let desc = text.replace(/\b(?:obs:?|observa[cç][aã]o:?|porque|pois)\s+.+$/i, '')
    .replace(/r\$\s*[\d.,]+/gi, ' ').replace(W('[\\d.,]+\\s*(?:reais|real|conto|contos|pila|mil|k)'), ' ').replace(W('\\d+(?:[.,]\\d{1,2})?'), ' ')
    .replace(W('hoje|ontem|anteontem|agora|dia\\s+\\d{1,2}(?:/\\d{1,2})?|[àa]s\\s*\\d{1,2}(?:[:h]\\d{2})?h?|(?:no|via|pelo|com)\\s+pix|no\\s+cart[aã]o(?:\\s+de\\s+(?:cr[eé]dito|d[eé]bito))?|no\\s+(?:cr[eé]dito|d[eé]bito)|(?:em|no)\\s+dinheiro|no\\s+boleto|de\\s+manh[aã]|[àa]\\s+tarde|[àa]\\s+noite'), ' ')
    .replace(W('eu|j[aá]|acabei de|gastei|gasto|comprei|custou|saiu|torrei|paguei|quitei|recebi|ganhei|entrou|caiu|transferi|mandei|enviei|fiz|passei|reais|real|pix'), ' ')
    .replace(/\s+/g, ' ').trim()
  const CONN = W('um|uma|uns|umas|o|a|os|as|no|na|nos|nas|em|com|por|pelo|pela|de|do|da|dos|das|para|pra|pro|e')
  for (let k = 0; k < 4; k++) desc = desc.replace(new RegExp('^' + CONN.source + '\\s*', 'iu'), '').replace(new RegExp('\\s*' + CONN.source + '$', 'iu'), '').trim()
  if (desc.length > 60) desc = desc.slice(0, 60).replace(/\s\S*$/, '')
  if (!desc || desc.length < 2) desc = hit ? hit.sub : kind === 'transferencia' ? 'Transferência' : kind === 'receita' ? 'Recebimento' : 'Gasto'
  if (kind === 'transferencia') desc = person ? `Transferência para ${person}` : desc && !/^transfer/i.test(desc) ? `Transferência: ${desc}` : 'Transferência'
  desc = desc.charAt(0).toUpperCase() + desc.slice(1)
  let category = hit ? hit.cat : 'outros', sub = hit ? hit.sub : ''
  if (!hit) sub = kind === 'transferencia' ? 'Transferência' : kind === 'receita' && method === 'Pix' ? 'Pix recebido' : desc // nova classificação, vinda das palavras do usuário
  return { kind, tipo, amount, category, sub, description: desc.slice(0, 120), date: parseDate(s, tz), time, method, obs: om ? om[1].trim() : '', person }
}
export const finFingerprint = (p: FinParsed) => [p.tipo, p.amount, p.category, nrm(p.description), p.date].join('|')

/* ---------- pagamento parcial: total contratado × recebido agora × saldo pendente (determinístico) ---------- */
export interface Partial { total: number; recebido: number; pendente: number; descricao: string; pessoa: string; duvida: string }
const MONEY = /(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(%|reais|real|conto|contos|mil)?/gi
const toNum = (raw: string, suf = '') => { let n = raw.includes(',') ? Number(raw.replace(/\./g, '').replace(',', '.')) : /^\d{1,3}(\.\d{3})+$/.test(raw) ? Number(raw.replace(/\./g, '')) : Number(raw); if (/mil/i.test(suf)) n *= 1000; return Math.round(n * 100) / 100 }
/** Encontra valores e o papel de cada um pelo contexto próximo (antes do número). */
export function parsePartial(text: string): Partial | null {
  const s = ' ' + nrm(text) + ' '
  // só receitas de serviço/venda; "eu paguei/dei de entrada" é outra situação
  if (/\b(eu )?(paguei|dei de entrada|dei entrada|gastei|comprei|parcelei)\b/.test(s) && !/\b(cliente|me pagou|recebi)\b/.test(s)) return null
  const temCtxReceita = /\b(cliente|me pagou|pagou|recebi|entrada|sinal|adiant|cobrei|servico|trabalho|tatuagem|orcamento|encomenda|projeto|venda|vendi)\b/.test(s)
  const temParcial = /\b(entrada|sinal|metade|adiant\w*|restante|resto|outros|outra parte|saldo|falta|faltam|pagara|vai pagar|depois|quando (finalizar|terminar|concluir|entregar|acabar)|no final|na entrega|parcela)\b/.test(s)
  if (!temCtxReceita || !temParcial) return null
  const vals: { v: number; pct: boolean; ctx: string; pos: number }[] = []
  let m: RegExpExecArray | null; MONEY.lastIndex = 0
  const low = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  while ((m = MONEY.exec(low))) {
    const raw = m[1], suf = m[2] || '', antes = low.slice(Math.max(0, m.index - 3), m.index)
    const isMoney = /r\$\s*$/.test(low.slice(Math.max(0, m.index - 4), m.index)) || /reais|real|conto|mil/.test(suf) || suf === '%' || /r\$/.test(m[0])
    if (!isMoney && !(Number(raw.replace(',', '.')) >= 10)) continue // números soltos pequenos (dias, horas) não são valores
    if (/\d{1,2}[\/:]$/.test(antes) || /^[\/:]\d/.test(low.slice(m.index + m[0].length))) continue // datas e horários
    vals.push({ v: toNum(raw, suf), pct: suf === '%', ctx: low.slice(Math.max(0, m.index - 45), m.index), pos: m.index })
  }
  if (!vals.length) return null
  const R = { total: /(custa|custou|cobr\w*|valor total|total|preco|orcamento|fechei por|fechou por|ficou em|ficou por|(?:servico|trabalho|tatuagem|tattoo|projeto|consulta|corte|sessao|encomenda|pedido|reforma|conserto|evento|aula|venda) de|de r\$|por r\$)\s*(de\s*)?(r\$)?\s*$/, rec: /(pagou|me pagou|recebi|deu|depositou|adiantou|transferiu|mandou|pix de|ja pagou|entrada de|sinal de)\s*(com\s*)?(de\s*)?(r\$)?\s*$/, pen: /(pagara|vai pagar|falta|faltam|restante|resto|outros|outras|saldo|depois|faltando|receber)\s*(os\s*|as\s*|de\s*)?(outros\s*)?(r\$)?\s*$/ }
  let total = 0, recebido = 0, pendente = 0, pct = 0
  for (const x of vals) {
    const c = x.ctx.trim() + ' '
    if (x.pct) { if (/entrada|sinal|adiant|pagou|recebi/.test(low.slice(x.pos, x.pos + 30) + c)) pct = x.v; continue }
    if (R.total.test(c.trimEnd()) && !total) total = x.v
    else if (R.pen.test(c.trimEnd()) && !pendente) pendente = x.v
    else if (R.rec.test(c.trimEnd()) && !recebido) recebido = x.v
    else if (/entrada|sinal/.test(low.slice(x.pos, x.pos + 25)) && !recebido) recebido = x.v // "R$ 100 de entrada"
    else if (/quando|depois|restante|final/.test(low.slice(x.pos, x.pos + 40)) && !pendente) pendente = x.v
  }
  if (pct && total && !recebido) recebido = Math.round(total * pct) / 100
  if (/\bmetade\b/.test(s) && total && !recebido) recebido = Math.round(total * 50) / 100
  if (!total && recebido && pendente) total = Math.round((recebido + pendente) * 100) / 100
  if (total && recebido && !pendente) pendente = Math.round((total - recebido) * 100) / 100
  if (total && pendente && !recebido) recebido = Math.round((total - pendente) * 100) / 100
  if (!(total > 0) || !(recebido >= 0)) return null
  let duvida = ''
  if (recebido > total + 0.009) duvida = `O valor recebido (R$ ${recebido.toFixed(2)}) é maior que o total (R$ ${total.toFixed(2)}).`
  else if (Math.abs(recebido + pendente - total) > 0.009) duvida = `Os valores não fecham: total R$ ${total.toFixed(2)}, recebido R$ ${recebido.toFixed(2)} e pendente R$ ${pendente.toFixed(2)}.`
  else if (!recebido && !/\b(nao pagou|nada|ainda nao)\b/.test(s)) duvida = 'Não ficou claro quanto foi recebido agora.'
  // descrição a partir das palavras do usuário (sem inventar)
  const dm = text.match(/\b(servi[cç]o|trabalho|tatuagem|tattoo|corte|consulta|projeto|encomenda|pedido|reforma|conserto|evento|sess[aã]o|aula|venda)(\s+(?:de|do|da)\s+[A-Za-zÀ-ÿ][\wÀ-ÿ ]{1,35}?)?(?=\s*(?:[,.;!]|custa|custou|ficou|por|de r\$|de\s+\d|r\$|que|e o|o cliente|a cliente|$))/i)
  const descricao = dm ? (dm[1].charAt(0).toUpperCase() + dm[1].slice(1).toLowerCase() + (dm[2] || '').replace(/\s+/g, ' ')).trim() : 'Serviço'
  const pm = text.match(/\b(?:cliente|o|a)\s+([A-ZÀ-Ý][a-zà-ÿ]+(?:\s+[A-ZÀ-Ý][a-zà-ÿ]+)?)\s+(?:pagou|me pagou|deu|adiantou)/)
  return { total, recebido, pendente: Math.max(0, pendente), descricao, pessoa: pm && !/^(Cliente|Ele|Ela)$/.test(pm[1]) ? pm[1] : '', duvida }
}
/** "O cliente pagou o restante", "recebi os outros 100 do serviço", "quitou o saldo" */
export function parseRemainder(text: string): { valor: number | null; ref: string } | null {
  const s = ' ' + nrm(text) + ' '
  if (!/\b(restante|resto|saldo|outros|outra parte|segunda parte|quitou|quitar|finalizou e pagou|pagou o que faltava|o que faltava)\b/.test(s)) return null
  if (!/\b(pagou|recebi|quitou|me pagou|depositou|caiu|entrou|transferiu)\b/.test(s)) return null
  if (/\b(eu paguei|paguei)\b/.test(s)) return null
  return { valor: parseAmount(text), ref: s }
}
