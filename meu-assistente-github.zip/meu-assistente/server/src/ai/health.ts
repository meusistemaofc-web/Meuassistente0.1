// Saúde dos provedores: circuit breaker, estatísticas (consumo, latência, erros) e resultado dos testes.
import { getConfig, setConfig } from '../lib/settings.js'
import { AiError, HARD, TRANSIENT, type Cap } from './types.js'

export interface BreakerCfg { falhas: number; pausaSeg: number; maxPausaSeg: number }
export interface CheckRes { cap: string; label: string; ok: boolean; ms: number; detail: string }
export interface TestRes { at: string; ok: boolean; ms: number; sig: string; checks: CheckRes[] }
export interface Stat {
  uses: number; failures: number; lastError: string; lastAt: string; lastOkAt: string; lat: number
  tokensIn: number; tokensOut: number; wins: number; fallbacks: number
  byTask: Record<string, { uses: number; failures: number }>
  days: Record<string, { uses: number; failures: number; in: number; out: number }>
  errors: { at: string; kind: string; msg: string; task: string }[]
  test?: TestRes
}
const blank = (): Stat => ({ uses: 0, failures: 0, lastError: '', lastAt: '', lastOkAt: '', lat: 0, tokensIn: 0, tokensOut: 0, wins: 0, fallbacks: 0, byTask: {}, days: {}, errors: [] })

interface B { state: 'closed' | 'open' | 'half'; kind: string; reason: string; until: number; fails: number; trips: number; hard: boolean; sig: string; probing: boolean; since: number }
const br = new Map<string, B>()
let stats: Record<string, Stat> | null = null
let dirty = false, timer: NodeJS.Timeout | null = null

export async function loadStats() {
  if (stats) return stats
  const raw = await getConfig<Record<string, Partial<Stat>>>('ai-status', {})
  stats = {}
  for (const [k, v] of Object.entries(raw || {})) stats[k] = { ...blank(), ...v }
  return stats
}
const day = () => new Date().toISOString().slice(0, 10)
async function S(id: string) { const s = await loadStats(); return s[id] || (s[id] = blank()) }
function touch() {
  dirty = true
  if (timer) return
  timer = setTimeout(() => { timer = null; void flushStats() }, 3000); timer.unref?.()
}
export async function flushStats() {
  if (!dirty || !stats) return
  dirty = false
  await setConfig('ai-status', stats).catch(() => {})
}

const get = (id: string, sig: string): B => {
  let b = br.get(id)
  if (!b || b.sig !== sig) { b = { state: 'closed', kind: '', reason: '', until: 0, fails: 0, trips: 0, hard: false, sig, probing: false, since: 0 }; br.set(id, b) }
  return b
}
export function resetBreaker(id: string) { br.delete(id) }
/** 'ok' = pode usar; 'probe' = pausa terminou, uma requisição de prova libera o provedor; 'blocked' = fora do ar. */
export function gate(id: string, sig: string, now = Date.now()): 'ok' | 'probe' | 'blocked' {
  const b = get(id, sig)
  if (b.state === 'closed') return 'ok'
  if (b.hard) return 'blocked'
  if (now >= b.until) { if (b.probing) return 'blocked'; return 'probe' }
  return 'blocked'
}
export function beginProbe(id: string, sig: string) { const b = get(id, sig); if (b.state !== 'closed') { b.state = 'half'; b.probing = true } }
export function info(id: string, sig: string) { const b = get(id, sig); return { state: b.state, hard: b.hard, until: b.until } }
/** Último recurso: provedores em pausa branda, do que volta primeiro ao que volta por último. */
export function softBlocked(id: string, sig: string) { const b = get(id, sig); return b.state !== 'closed' && !b.hard ? b.until : null }

export async function success(id: string, sig: string, ms: number, task: string, usage?: { in: number; out: number }, fallback = false) {
  const b = get(id, sig); b.state = 'closed'; b.fails = 0; b.trips = 0; b.hard = false; b.kind = ''; b.reason = ''; b.probing = false; b.until = 0
  const s = await S(id), d = (s.days[day()] ||= { uses: 0, failures: 0, in: 0, out: 0 }), t = (s.byTask[task] ||= { uses: 0, failures: 0 })
  s.uses++; d.uses++; t.uses++; s.lastAt = s.lastOkAt = new Date().toISOString(); s.lat = s.lat ? Math.round(s.lat * 0.7 + ms * 0.3) : ms
  if (usage) { s.tokensIn += usage.in; s.tokensOut += usage.out; d.in += usage.in; d.out += usage.out }
  if (fallback) s.fallbacks++
  for (const k of Object.keys(s.days).sort().slice(0, -7)) delete s.days[k]
  touch()
}
export async function failure(id: string, sig: string, e: AiError, task: string, cfg: BreakerCfg) {
  const b = get(id, sig), now = Date.now(), wasHalf = b.state === 'half'
  b.probing = false; b.fails++; b.kind = e.kind; b.reason = e.message
  const backoff = Math.min(cfg.maxPausaSeg, cfg.pausaSeg * 2 ** Math.min(b.trips, 6)) * 1000
  if (HARD.includes(e.kind)) { b.state = 'open'; b.hard = true; b.until = Infinity; b.trips++ }
  else if (e.kind === 'rate_limit') { b.state = 'open'; b.hard = false; b.trips++; b.until = now + Math.min(cfg.maxPausaSeg * 1000, Math.max(e.retryAfterMs || 0, 60_000 * Math.min(b.trips, 4))); b.since = b.since || now }
  else if (wasHalf || b.fails >= cfg.falhas) { b.state = 'open'; b.hard = false; b.trips++; b.until = now + backoff; b.since = b.since || now }
  const s = await S(id), d = (s.days[day()] ||= { uses: 0, failures: 0, in: 0, out: 0 }), t = (s.byTask[task] ||= { uses: 0, failures: 0 })
  s.failures++; d.failures++; t.failures++; s.lastError = e.message + (e.detail ? ` — ${e.detail.slice(0, 120)}` : ''); s.lastAt = new Date().toISOString()
  s.errors.push({ at: s.lastAt, kind: e.kind, msg: s.lastError.slice(0, 200), task }); s.errors = s.errors.slice(-15)
  touch()
}
export async function addWin(id: string) { (await S(id)).wins++; touch() }
export async function recordTest(id: string, t: TestRes) { (await S(id)).test = t; touch(); await flushStats() }

/** Qualidade recente (0–1) com prior bayesiano: poucos dados não derrubam nem inflam a nota. */
export function quality(s?: Stat) { return s ? (s.uses + 3) / (s.uses + s.failures + 4) : 0.75 }
export function speed(s?: Stat) { return s && s.lat ? 1 / (1 + s.lat / 5000) : 0.7 }
/** Capacidade reprovada no último teste (com a mesma configuração): o roteador evita o provedor nessa tarefa. */
export function capFailed(s: Stat | undefined, cap: Cap, sig: string) { const t = s?.test; return !!t && t.sig === sig && t.checks.some((c) => c.cap === cap && !c.ok) }

export async function runtime() {
  const st = await loadStats(), now = Date.now()
  const breakers: Record<string, any> = {}
  for (const [id, b] of br) if (b.state !== 'closed') breakers[id] = { state: b.state, kind: b.kind, reason: b.reason, hard: b.hard, expired: b.hard && b.kind === 'auth', seconds: b.hard ? null : Math.max(0, Math.ceil((b.until - now) / 1000)), trips: b.trips }
  return { stats: st, breakers, paused: Object.fromEntries(Object.entries(breakers).map(([k, v]) => [k, { ...v }])), today: day() }
}
export const isTransient = (e: AiError) => TRANSIENT.includes(e.kind)
