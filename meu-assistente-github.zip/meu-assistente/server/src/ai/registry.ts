// Lista de provedores configurados: mescla padrões novos em instalações antigas, deduz tipo e capacidades
// e monta o "alvo" (endereço, chave decifrada, modelo) de cada IA pronta.
import { createHash } from 'node:crypto'
import { config } from '../config.js'
import { getConfig, unseal } from '../lib/settings.js'
import { AI_DEFAULT, AI_ROUTER_DEFAULT, type AiProvider } from '../lib/panel-defaults.js'
import { CAPS, type Cap, type Kind, type Target } from './types.js'

export const aiConfigured = () => !!config.ai.apiKey || /localhost|127\.0\.0\.1|172\.17\.|ollama|:11434/.test(config.ai.baseUrl)
const isLocal = (u: string) => /localhost|127\.0\.0\.1|172\.17\.|ollama|:11434/.test(u)

export function kindOf(p: Pick<AiProvider, 'id' | 'base_url' | 'tipo'>): Kind {
  if (p.tipo === 'openai' || p.tipo === 'gemini' || p.tipo === 'anthropic') return p.tipo
  if (p.id === 'gemini' || /generativelanguage\.googleapis\.com/.test(p.base_url || '')) return 'gemini'
  if (p.id === 'anthropic' || /api\.anthropic\.com/.test(p.base_url || '')) return 'anthropic'
  return 'openai'
}
/** Capacidades: padrão do tipo, ajustado pelos botões antigos (texto/imagem) e pelas escolhas do administrador. */
export function capsOf(p: AiProvider, kind = kindOf(p)): Record<Cap, boolean> {
  const img = !!p.imagem
  const base: Record<Cap, boolean> = kind === 'gemini'
    ? { texto: true, ferramentas: true, imagem: img, documento: img, audio: img, codigo: true, pesquisa: true }
    : kind === 'anthropic'
      ? { texto: true, ferramentas: true, imagem: img, documento: img, audio: false, codigo: true, pesquisa: false }
      : { texto: true, ferramentas: true, imagem: img, documento: img && /openai\.com/.test(p.base_url || ''), audio: !!p.modelo_audio || /groq|openai\.com/.test(p.base_url || ''), codigo: true, pesquisa: false }
  const out = { ...base, texto: p.texto !== false }
  for (const c of CAPS) if (typeof p.caps?.[c] === 'boolean') out[c] = p.caps[c]!
  return out
}
export async function loadProviders(): Promise<AiProvider[]> {
  const stored = await getConfig<AiProvider[]>('ai_providers', [])
  if (!stored.length) return AI_DEFAULT.map((x) => ({ ...x }))
  const def = new Map(AI_DEFAULT.map((d) => [d.id, d]))
  const out = stored.map((p) => { const d = def.get(p.id); return { ...(d ? { tipo: d.tipo, modelo_audio: d.modelo_audio } : {}), ...p, ...(d ? { onde: d.onde } : {}) } as AiProvider })
  const missing = AI_DEFAULT.filter((d) => !stored.some((p) => p.id === d.id))
  if (missing.length) { const si = out.findIndex((p) => p.id === 'servidor'); out.splice(si < 0 ? out.length : si, 0, ...missing.map((m) => ({ ...m }))) }
  return out
}
export async function routerCfg() {
  const c = await getConfig<any>('ai_router', {})
  const num = (v: any, d: number, min: number, max: number) => { const n = Number(v); return isFinite(n) ? Math.min(max, Math.max(min, n)) : d }
  const D = AI_ROUTER_DEFAULT
  return {
    modo: (['equilibrado', 'prioridade', 'velocidade', 'qualidade'].includes(c.modo) ? c.modo : D.modo) as typeof D.modo,
    timeoutMs: num(c.timeoutMs, D.timeoutMs, 3000, 120000), prazoMs: num(c.prazoMs, D.prazoMs, 5000, 180000), tentativas: Math.round(num(c.tentativas, D.tentativas, 0, 3)),
    breaker: { falhas: Math.round(num(c.breaker?.falhas, D.breaker.falhas, 1, 20)), pausaSeg: num(c.breaker?.pausaSeg, D.breaker.pausaSeg, 5, 3600), maxPausaSeg: num(c.breaker?.maxPausaSeg, D.breaker.maxPausaSeg, 10, 86400) },
    paralelo: { ativo: typeof c.paralelo?.ativo === 'boolean' ? c.paralelo.ativo : D.paralelo.ativo, modo: (c.paralelo?.modo === 'corrida' ? 'corrida' : 'comparar') as 'comparar' | 'corrida', max: Math.round(num(c.paralelo?.max, D.paralelo.max, 2, 4)), tarefas: Array.isArray(c.paralelo?.tarefas) ? c.paralelo.tarefas.map(String) : D.paralelo.tarefas },
    monitor: { ativo: typeof c.monitor?.ativo === 'boolean' ? c.monitor.ativo : D.monitor.ativo, minutos: Math.round(num(c.monitor?.minutos, D.monitor.minutos, 1, 120)) },
  }
}
export async function targetFor(p: AiProvider): Promise<Target | null> {
  const kind = kindOf(p), caps = capsOf(p, kind)
  const sig = (parts: string[]) => createHash('sha1').update(parts.join('|')).digest('hex').slice(0, 16)
  if (p.id === 'servidor') {
    if (!aiConfigured()) return null
    const url = config.ai.baseUrl, key = config.ai.apiKey, model = config.ai.model
    return { id: 'servidor', nome: p.nome || 'IA do servidor', kind: 'openai', url, key, model, modelAudio: '', caps: { ...caps, documento: false, audio: false, pesquisa: false, imagem: !!p.imagem }, sig: sig(['openai', url, model, key]), reserva: true }
  }
  const key = await unseal(p.key)
  let url = String(p.base_url || '').replace(/\/+$/, '')
  if (kind === 'gemini') url = url || 'https://generativelanguage.googleapis.com'
  if (kind === 'anthropic') url = (url || 'https://api.anthropic.com').replace(/\/v1$/, '')
  if ((!key && !isLocal(url)) || !url || !p.modelo) return null
  return { id: p.id, nome: p.nome, kind, url, key, model: p.modelo, modelAudio: p.modelo_audio || '', caps, sig: sig([kind, url, p.modelo, key, p.modelo_audio || '']), reserva: false }
}
