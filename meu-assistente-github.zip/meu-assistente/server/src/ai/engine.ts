// MOTOR MULTI-IA: escolhe a melhor IA para cada tarefa, troca de provedor sem interromper o usuário,
// compara respostas em paralelo quando isso agrega qualidade e se protege com circuit breaker.
// Cada provedor fala pelo seu próprio adaptador (OpenAI-compatível, Gemini nativo, Claude).
import { config } from '../config.js'
import { HttpError } from '../lib/http.js'
import type { AiProvider } from '../lib/panel-defaults.js'
import { adapterFor } from './adapters/index.js'
import * as H from './health.js'
import { digitsPng, textPdf, toneWav } from './assets.js'
import { loadProviders, routerCfg, targetFor } from './registry.js'
import { AiError, CAP_LABEL, TRANSIENT, netError, parseJsonLoose, type Cap, type ChatMsg, type FilePart, type Target, type Task, type ToolDef } from './types.js'

/* ---------- que capacidades cada tarefa exige e qual IA costuma ser melhor nela ---------- */
const NEED: Record<Task, Cap[]> = { conversa: ['texto'], agente: ['texto', 'ferramentas'], contexto: ['texto'], analise: ['texto'], codigo: ['texto'], pesquisa: ['texto'], imagem: ['imagem'], documento: ['documento'], audio: ['audio'] }
const PREFER: Partial<Record<Task, Cap>> = { codigo: 'codigo', pesquisa: 'pesquisa' }
const AFF_KIND: Record<string, Partial<Record<Task, number>>> = {
  gemini: { imagem: 1, documento: 1, audio: 1, pesquisa: 1, contexto: 0.9, analise: 0.8, conversa: 0.75, agente: 0.75, codigo: 0.7 },
  anthropic: { codigo: 1, analise: 1, agente: 0.95, contexto: 0.95, conversa: 0.85, documento: 0.9, imagem: 0.85, pesquisa: 0.4 },
  openai: { agente: 0.8, codigo: 0.8, analise: 0.8, conversa: 0.8, imagem: 0.8, audio: 0.85, documento: 0.75, contexto: 0.75, pesquisa: 0.4 },
}
const AFF_ID: Record<string, Partial<Record<Task, number>>> = {
  openai: { agente: 0.9, codigo: 0.9, analise: 0.9, conversa: 0.85, imagem: 0.85, audio: 0.9, documento: 0.8, contexto: 0.8 },
  groq: { conversa: 0.85, agente: 0.7, audio: 0.95, codigo: 0.7, analise: 0.65, contexto: 0.6 },
  cerebras: { conversa: 0.8, agente: 0.65, codigo: 0.7, analise: 0.6 },
  servidor: { conversa: 0.65, agente: 0.5, codigo: 0.45, analise: 0.45, contexto: 0.5 },
}
const affinity = (t: Target, task: Task) => AFF_ID[t.id]?.[task] ?? AFF_KIND[t.kind]?.[task] ?? 0.55

export function classifyTask(messages: ChatMsg[], tools?: ToolDef[]): Task {
  const files = messages.flatMap((m) => m.files || [])
  if (files.some((f) => f.mime.startsWith('audio/'))) return 'audio'
  if (files.some((f) => f.mime === 'application/pdf')) return 'documento'
  if (files.some((f) => f.mime.startsWith('image/'))) return 'imagem'
  const last = [...messages].reverse().find((m) => m.role === 'user')?.content || ''
  if (/```|\b(c[óo]digo|fun[çc][ãa]o|script|javascript|typescript|python|sql|bug|stack ?trace|regex|programa[çc][ãa]o|api rest|compilar)\b/i.test(last)) return 'codigo'
  if (!tools?.length && /\b(pesquis[ae]|busque na (web|internet)|[úu]ltimas not[íi]cias|not[íi]cias de hoje|previs[ãa]o do tempo)\b/i.test(last)) return 'pesquisa'
  if (tools?.length) return 'agente'
  if (last.length > 1500 || messages.length > 24 || /\b(analis[ae]|compare|resum[ae]|relat[óo]rio|estrat[ée]gia)\b/i.test(last)) return messages.length > 24 ? 'contexto' : 'analise'
  return 'conversa'
}
function filesNeeds(messages: ChatMsg[]): Cap[] {
  const out = new Set<Cap>()
  for (const f of messages.flatMap((m) => m.files || [])) { if (f.mime.startsWith('image/')) out.add('imagem'); else if (f.mime === 'application/pdf') out.add('documento') }
  return [...out]
}

/* ---------- validação da resposta ---------- */
export function validateMessage(m: ChatMsg, o: { tools?: ToolDef[]; json?: boolean; allowEmpty?: boolean } = {}): string | null {
  if (m.tool_calls?.length) {
    const names = new Set((o.tools || []).map((t) => t.function.name))
    for (const c of m.tool_calls) {
      if (!c.function.name) return 'chamada de ferramenta sem nome'
      if (names.size && !names.has(c.function.name)) return `ferramenta inexistente (${c.function.name})`
      try { const a = JSON.parse(c.function.arguments || '{}'); if (!a || typeof a !== 'object' || Array.isArray(a)) return 'argumentos da ferramenta inválidos' } catch { return 'argumentos da ferramenta inválidos' }
    }
    return null
  }
  const t = String(m.content || '').trim()
  if (!t) return o.allowEmpty ? null : 'resposta vazia'
  if (o.json) { try { parseJsonLoose(t) } catch { return 'JSON inválido' } }
  return null
}

/* ---------- escolha dos candidatos ---------- */
interface Cand { t: Target; score: number; probe: boolean }
interface Pool { ready: Cand[]; soft: Target[]; configured: number }
async function pool(task: Task, need: Cap[], exclude: Set<string>, extra?: (t: Target) => boolean): Promise<Pool> {
  const cfg = await routerCfg(), st = await H.loadStats(), prefer = PREFER[task]
  const eligible: { t: Target; p: AiProvider }[] = []
  let configured = 0
  for (const p of await loadProviders()) {
    if (!p.ativo || exclude.has(p.id)) continue
    const t = await targetFor(p)
    if (!t || !need.every((c) => t.caps[c]) || (extra && !extra(t))) continue
    configured++; eligible.push({ t, p })
  }
  const ready: Cand[] = [], soft: Target[] = []
  const k = Math.max(1, eligible.length)
  eligible.forEach(({ t }, i) => {
    const g = H.gate(t.id, t.sig)
    if (g === 'blocked') { if (H.softBlocked(t.id, t.sig) !== null) soft.push(t); return }
    const s = st[t.id], pri = 1 - i / k, aff = affinity(t, task), qua = H.quality(s), spd = H.speed(s)
    const w = { equilibrado: [0.15, 0.55, 0.2, 0.1], prioridade: [0.8, 0.1, 0.1, 0], velocidade: [0.2, 0.1, 0.1, 0.6], qualidade: [0.1, 0.5, 0.35, 0.05] }[cfg.modo]
    let score = w[0] * pri + w[1] * aff + w[2] * qua + w[3] * spd
    if (prefer && t.caps[prefer]) score += 0.1
    for (const c of need) if (H.capFailed(s, c, t.sig)) score *= 0.35 // reprovada no último teste real
    if (g === 'probe') score *= 0.8
    if (t.reserva && cfg.modo !== 'prioridade') score -= 0.25
    ready.push({ t, score, probe: g === 'probe' })
  })
  ready.sort((a, b) => b.score - a.score)
  // uma IA que não conseguiu chamar ferramentas no teste real não recebe ações (registrar, agendar…) se houver outra apta
  if (need.includes('ferramentas' as Cap)) { const ok = ready.filter((c) => !H.capFailed(st[c.t.id], 'ferramentas' as Cap, c.t.sig)); if (ok.length && ok.length < ready.length) ready.splice(0, ready.length, ...ok) }
  soft.sort((a, b) => (H.softBlocked(a.id, a.sig) || 0) - (H.softBlocked(b.id, b.sig) || 0))
  return { ready, soft, configured }
}

/* ---------- uma tentativa em um provedor ---------- */
export interface Attempt { id: string; nome: string; ok: boolean; kind?: string; msg?: string; ms: number }
interface Leg<T> { run: (t: Target, signal: AbortSignal) => Promise<T>; check: (r: T, t: Target) => string | null; usage?: (r: T) => { in: number; out: number } | undefined }
const CANCEL = 'cancelado'
async function attempt<T>(t: Target, leg: Leg<T>, cfg: Awaited<ReturnType<typeof routerCfg>>, deadline: number, outer?: AbortSignal, lat = 0): Promise<{ value: T; ms: number }> {
  const ctl = new AbortController()
  // tempo por provedor: proporcional à latência real medida (falha rápido quando a IA trava), limitado ao máximo do painel
  const base = t.reserva ? Math.max(cfg.timeoutMs, config.ai.timeoutMs) : cfg.timeoutMs
  const adaptive = lat > 0 ? Math.max(6000, Math.min(base, Math.round(lat * 3 + 3000))) : base
  const limit = Math.max(2000, Math.min(adaptive, deadline - Date.now()))
  const timer = setTimeout(() => ctl.abort(), limit)
  const onAbort = () => ctl.abort(); outer?.addEventListener('abort', onAbort)
  const t0 = Date.now()
  try {
    const value = await leg.run(t, ctl.signal)
    const bad = leg.check(value, t)
    if (bad) throw new AiError('invalid_response', `Resposta inadequada: ${bad}`)
    return { value, ms: Date.now() - t0 }
  } catch (e) {
    if (outer?.aborted) throw new AiError('network', CANCEL, undefined, 0, CANCEL)
    throw netError(e)
  } finally { clearTimeout(timer); outer?.removeEventListener('abort', onAbort) }
}

export interface Orchestrated<T> { value: T; target: Target; ms: number; attempts: Attempt[]; others: { value: T; target: Target; ms: number }[] }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
function allFailed(attempts: Attempt[], configured: number): HttpError {
  if (!configured) return new HttpError(503, 'Nenhuma IA está pronta para esta tarefa. Cadastre uma chave em Administração → IA (painel) ou configure AI_API_KEY no .env.', 'ai_not_configured')
  const last = attempts[attempts.length - 1]
  const msg = !attempts.length ? 'Estou me recuperando de uma instabilidade. Tente de novo em instantes.' : attempts.every((a) => a.kind === 'timeout') ? 'Estou um pouco lento agora. Pode tentar de novo em instantes?' : 'Não consegui responder agora. Tente de novo em instantes.'
  const e = new HttpError(502, msg, 'ai_error'); (e as any).attempts = attempts; (e as any).last = last; return e
}

export async function orchestrate<T>(task: Task, need: Cap[], leg: Leg<T>, o: { maxMs?: number; exclude?: string[]; parallel?: 'comparar' | 'corrida' | 'off'; extra?: (t: Target) => boolean } = {}): Promise<Orchestrated<T>> {
  const cfg = await routerCfg(), deadline = Date.now() + (o.maxMs ?? cfg.prazoMs)
  const attempts: Attempt[] = [], skip = new Set(o.exclude || []), transient = new Set<string>()
  let configured = 0
  const fail = async (t: Target, e: AiError, ms: number) => {
    if (e.detail === CANCEL) return
    attempts.push({ id: t.id, nome: t.nome, ok: false, kind: e.kind, msg: e.message + (e.detail ? ` — ${e.detail.slice(0, 160)}` : ''), ms })
    await H.failure(t.id, t.sig, e, task, cfg.breaker)
    console.error(`[ai] ${t.nome} falhou na tarefa ${task} (${e.kind}: ${e.message}) ${e.detail || ''}`)
    if (TRANSIENT.includes(e.kind)) transient.add(t.id)
  }
  for (let pass = 0; pass <= cfg.tentativas; pass++) {
    const pl = await pool(task, need, new Set([...skip].filter((id) => !(pass > 0 && transient.has(id)))), o.extra)
    configured = Math.max(configured, pl.configured)
    let list = pl.ready.map((c) => c.t)
    if (pass > 0) list = list.filter((t) => transient.has(t.id))
    if (!list.length && pass === 0) list = pl.soft // último recurso: tenta quem volta primeiro
    if (!list.length) break
    // consulta paralela: compara respostas de várias IAs (só quando não há efeitos colaterais)
    if (pass === 0 && o.parallel && o.parallel !== 'off' && list.length >= 2 && pl.ready.length >= 2) {
      const group = list.slice(0, cfg.paralelo.max), ctl = new AbortController()
      for (const t of group) { const c = pl.ready.find((x) => x.t.id === t.id); if (c?.probe) H.beginProbe(t.id, t.sig) }
      const results: { value: T; target: Target; ms: number }[] = []
      await new Promise<void>((resolve) => {
        let pending = group.length
        for (const t of group) {
          attempt(t, leg, cfg, deadline, ctl.signal).then(async (r) => {
            await H.success(t.id, t.sig, r.ms, task, leg.usage?.(r.value), false)
            attempts.push({ id: t.id, nome: t.nome, ok: true, ms: r.ms }); results.push({ value: r.value, target: t, ms: r.ms })
            if (o.parallel === 'corrida') { ctl.abort(); resolve() }
          }).catch(async (e) => { await fail(t, netError(e), 0) }).finally(() => { if (--pending === 0) resolve() })
        }
      })
      if (results.length) { const [first, ...others] = results; return { ...first, attempts, others } }
      for (const t of group) skip.add(t.id)
      list = list.filter((t) => !skip.has(t.id))
      if (!list.length) break
    }
    // corrida escalonada: começa pela melhor IA; se ela demorar mais que o normal dela, a próxima entra em paralelo
    // (sem esperar o tempo esgotar). A primeira resposta válida vence e as outras são canceladas — nada é duplicado,
    // porque só uma resposta é usada e as ações só rodam depois.
    const stl = await H.loadStats(), latOf = (t: Target) => stl[t.id]?.lat || 0
    const hedgeMs = (t: Target) => { const l = latOf(t); return l ? Math.max(2500, Math.min(t.reserva ? 20000 : 9000, Math.round(l * 1.8))) : (t.reserva ? 12000 : 4500) }
    const won = await new Promise<{ value: T; target: Target; ms: number } | null>((resolve) => {
      let idx = 0, active = 0, done = false
      const ctl = new AbortController()
      const launch = () => {
        if (done) return
        if (idx >= list.length || Date.now() >= deadline) { if (active === 0) resolve(null); return }
        const t = list[idx++]; active++
        if (pl.ready.find((c) => c.t.id === t.id)?.probe) H.beginProbe(t.id, t.sig)
        const t0 = Date.now(), hedge = setTimeout(() => { if (!done && active < 2) launch() }, hedgeMs(t))
        attempt(t, leg, cfg, deadline, ctl.signal, latOf(t)).then(async (r) => {
          clearTimeout(hedge); if (done) return
          done = true; ctl.abort()
          await H.success(t.id, t.sig, r.ms, task, leg.usage?.(r.value), attempts.some((a) => !a.ok))
          attempts.push({ id: t.id, nome: t.nome, ok: true, ms: r.ms }); resolve({ value: r.value, target: t, ms: r.ms })
        }).catch(async (e) => {
          clearTimeout(hedge); active--
          if (done) return
          await fail(t, netError(e), Date.now() - t0); skip.add(t.id)
          launch()
          if (active === 0 && (idx >= list.length || Date.now() >= deadline)) resolve(null)
        })
      }
      launch()
    })
    if (won) return { ...won, attempts, others: [] }
    if (!transient.size || Date.now() >= deadline - 1500) break
    await sleep(Math.min(900, 350 + Math.random() * 500)) // espera curta e variável antes da nova tentativa controlada
  }
  throw allFailed(attempts, configured)
}

/* ---------- API de conversa ---------- */
export interface RunOpts { task?: Task; tools?: ToolDef[]; temperature?: number; json?: boolean; grounding?: boolean; parallel?: 'auto' | 'off' | 'comparar' | 'corrida'; validate?: (m: ChatMsg) => string | null; allowEmpty?: boolean; maxMs?: number }
export interface RunRes { message: ChatMsg; provider: { id: string; nome: string; kind: string }; ms: number; attempts: Attempt[]; task: Task; compared?: { ids: string[]; winner: string } }

export async function run(messages: ChatMsg[], opts: RunOpts = {}): Promise<RunRes> {
  const cfg = await routerCfg()
  const task = opts.task || classifyTask(messages, opts.tools)
  const need = [...new Set<Cap>([...NEED[task], ...filesNeeds(messages), ...(opts.tools?.length ? (['ferramentas'] as Cap[]) : [])])]
  const temperature = opts.temperature ?? 0.4
  const mode = opts.tools?.length ? 'off' : opts.parallel === 'comparar' || opts.parallel === 'corrida' ? opts.parallel : opts.parallel === 'off' ? 'off' : cfg.paralelo.ativo && cfg.paralelo.tarefas.includes(task) ? cfg.paralelo.modo : 'off'
  const leg: Leg<{ message: ChatMsg; usage?: { in: number; out: number }; grounded?: boolean }> = {
    run: (t, signal) => adapterFor(t.kind).chat(t, { messages, tools: opts.tools, temperature, json: opts.json, grounding: opts.grounding ?? task === 'pesquisa', signal }),
    check: (r) => validateMessage(r.message, { tools: opts.tools, json: opts.json, allowEmpty: opts.allowEmpty }) || opts.validate?.(r.message) || null,
    usage: (r) => r.usage,
  }
  const o = await orchestrate(task, need, leg, { maxMs: opts.maxMs, parallel: mode })
  let pick = { value: o.value, target: o.target, ms: o.ms }, compared: RunRes['compared']
  if (o.others.length) {
    const all = [pick, ...o.others]
    const best = mode === 'comparar' ? await judge(messages, all, cfg).catch(() => 0) : 0
    pick = all[best] || all[0]; await H.addWin(pick.target.id)
    compared = { ids: all.map((x) => x.target.id), winner: pick.target.id }
  }
  return { message: pick.value.message, provider: { id: pick.target.id, nome: pick.target.nome, kind: pick.target.kind }, ms: pick.ms, attempts: o.attempts, task, compared }
}

/** Compara respostas de várias IAs: uma delas atua como juíza e escolhe a melhor (falhou? vale a de maior pontuação). */
async function judge(messages: ChatMsg[], all: { value: { message: ChatMsg }; target: Target }[], cfg: Awaited<ReturnType<typeof routerCfg>>): Promise<number> {
  const q = [...messages].reverse().find((m) => m.role === 'user')?.content || ''
  const prompt = `Pergunta do usuário:\n${q.slice(0, 3000)}\n\n${all.map((a, i) => `Resposta ${i + 1}:\n${String(a.value.message.content || '').slice(0, 5000)}`).join('\n\n')}\n\nEscolha a melhor resposta (correta, completa, clara, fiel ao pedido e sem invenções). Responda SOMENTE com JSON: {"melhor": <número da resposta>, "motivo": "<frase curta>"}`
  const judgeMsgs: ChatMsg[] = [{ role: 'system', content: 'Você avalia respostas de assistentes de IA com rigor e imparcialidade.' }, { role: 'user', content: prompt }]
  const t = all[0].target
  const r = await attempt(t, { run: (tt, signal) => adapterFor(tt.kind).chat(tt, { messages: judgeMsgs, temperature: 0, json: true, signal }), check: (x) => validateMessage(x.message, { json: true }) }, cfg, Date.now() + 20000)
  const n = Number(parseJsonLoose(String(r.value.message.content)).melhor)
  return n >= 1 && n <= all.length ? n - 1 : 0
}

/** Compatível com o código antigo: devolve só a mensagem. */
export async function complete(messages: ChatMsg[], tools?: ToolDef[], opts: Omit<RunOpts, 'tools'> & { image?: boolean } = {}): Promise<ChatMsg> {
  return (await run(messages, { ...opts, tools, task: opts.task || (opts.image ? 'imagem' : undefined) })).message
}

/* ---------- arquivos e áudio ---------- */
/** Lê imagem/PDF com a melhor IA que enxerga (Gemini, Claude, OpenAI…), com fallback entre elas. */
export async function askFiles(prompt: string, files: FilePart[], o: { json?: boolean; validate?: (m: ChatMsg) => string | null } = {}): Promise<string> {
  const r = await run([{ role: 'user', content: prompt, files }], { temperature: 0.1, json: o.json, validate: o.validate, parallel: 'off' })
  return String(r.message.content || '').trim()
}
export async function transcribe(data: Buffer, mime: string): Promise<string> {
  const r = await orchestrate('audio', ['audio'], { run: (t, s) => adapterFor(t.kind).transcribe!(t, data, mime, s), check: () => null, usage: (x) => x.usage }, { extra: (t) => !!adapterFor(t.kind).transcribe })
  return r.value.text
}
/** Quantas IAs estão prontas para a tarefa (sem fazer requisição). */
export async function readyCount(task: Task = 'conversa', extra: Cap[] = []) { const p = await pool(task, [...NEED[task], ...extra], new Set()); return p.configured }

/* ---------- teste REAL de cada provedor ---------- */
const friendly = (e: AiError) => e.kind === 'auth' ? 'Chave recusada pelo serviço.' : e.kind === 'rate_limit' ? 'A chave funciona, mas está no limite agora.' : e.kind === 'config' ? 'Modelo ou endereço não encontrado.' : e.kind === 'timeout' ? 'Tempo esgotado.' : e.kind === 'blocked' ? 'Resposta bloqueada pelo provedor.' : `Falhou: ${e.message}${e.detail ? ` (${e.detail.slice(0, 120)})` : ''}`
const PING_TOOLS: ToolDef[] = [
  { type: 'function', function: { name: 'registrar_codigo', description: 'Registra um código informado pelo usuário.', parameters: { type: 'object', properties: { codigo: { type: 'string', description: 'O código' } }, required: ['codigo'], additionalProperties: false } } },
  { type: 'function', function: { name: 'consultar_agenda', description: 'Consulta a agenda do usuário (sem parâmetros).', parameters: { type: 'object', properties: {}, required: [], additionalProperties: false } } },
]
export async function testProvider(p: AiProvider, only?: Cap[]): Promise<{ ok: boolean; message: string; ms: number; checks: H.CheckRes[] }> {
  const t = await targetFor(p)
  if (!t) return { ok: false, message: p.id === 'servidor' ? 'A IA do .env não está configurada.' : 'Salve a chave, o endereço e o modelo antes de testar.', ms: 0, checks: [] }
  const cfg = await routerCfg(), ad = adapterFor(t.kind), t0 = Date.now()
  const chat = (messages: ChatMsg[], extra: { tools?: ToolDef[]; grounding?: boolean } = {}) => attempt(t, { run: (tt, signal) => ad.chat(tt, { messages, temperature: 0.1, signal, ...extra }), check: () => null }, cfg, Date.now() + 40000)
  const checks: H.CheckRes[] = []
  const hs: { err: AiError | null } = { err: null }
  const step = async (cap: Cap, fn: () => Promise<string>) => {
    if (only && !only.includes(cap)) return
    if (!t.caps[cap]) return
    if (cap === 'audio' && !ad.transcribe) return
    if (hs.err) return // chave recusada, limite ou serviço fora do ar: não adianta insistir nas demais capacidades
    const s = Date.now()
    try { const detail = await fn(); checks.push({ cap, label: CAP_LABEL[cap], ok: true, ms: Date.now() - s, detail }) }
    catch (e) { const ae = netError(e); if (ae.kind !== 'bad_request' && ae.kind !== 'invalid_response') hs.err = ae; checks.push({ cap, label: CAP_LABEL[cap], ok: false, ms: Date.now() - s, detail: friendly(ae) }) }
  }
  const must = (c: boolean, why: string) => { if (!c) throw new AiError('invalid_response', why) }
  await step('texto', async () => {
    const r = await chat([{ role: 'user', content: 'Quanto é 17 + 25? Responda só com o número.' }])
    must(/\b42\b/.test(String(r.value.message.content || '')), `resposta inesperada: "${String(r.value.message.content || '').slice(0, 60)}"`); return 'respondeu corretamente'
  })
  await step('ferramentas', async () => {
    const base: ChatMsg[] = [{ role: 'system', content: 'Use as ferramentas quando pedido.' }, { role: 'user', content: 'Chame a ferramenta registrar_codigo com o codigo K7Q2.' }]
    const r1 = await chat(base, { tools: PING_TOOLS }), call = r1.value.message.tool_calls?.[0]
    must(!!call && call.function.name === 'registrar_codigo', 'não chamou a ferramenta pedida')
    must(/k7q2/i.test(String(JSON.parse(call!.function.arguments || '{}').codigo || '')), 'argumentos da ferramenta incorretos')
    const r2 = await chat([...base, { role: 'assistant', content: r1.value.message.content ?? null, tool_calls: r1.value.message.tool_calls }, { role: 'tool', tool_call_id: call!.id, content: JSON.stringify({ ok: true }) }], { tools: PING_TOOLS })
    must(!!String(r2.value.message.content || '').trim() || !!r2.value.message.tool_calls?.length, 'sem resposta após o resultado da ferramenta'); return 'chamada e retorno da ferramenta ok'
  })
  await step('imagem', async () => {
    const r = await chat([{ role: 'user', content: 'Quais números aparecem nesta imagem? Responda só com os dígitos.', files: [{ mime: 'image/png', data: digitsPng('4821').toString('base64') }] }])
    must(/4\D*8\D*2\D*1/.test(String(r.value.message.content || '')), `não leu a imagem: "${String(r.value.message.content || '').slice(0, 60)}"`); return 'leu a imagem'
  })
  await step('documento', async () => {
    const r = await chat([{ role: 'user', content: 'Qual é o número do código neste PDF? Responda só com o número.', files: [{ mime: 'application/pdf', data: textPdf('CODIGO 7305').toString('base64') }] }])
    must(/7305/.test(String(r.value.message.content || '')), `não leu o PDF: "${String(r.value.message.content || '').slice(0, 60)}"`); return 'leu o PDF'
  })
  await step('audio', async () => {
    await attempt(t, { run: (tt, signal) => ad.transcribe!(tt, toneWav(), 'audio/wav', signal), check: () => null }, cfg, Date.now() + 40000)
    return 'áudio aceito (sem fala para conferir o texto)'
  })
  await step('codigo', async () => {
    const r = await chat([{ role: 'user', content: 'Escreva em JavaScript uma função dobrar(n) que retorna n*2. Responda só com o código.' }])
    const c = String(r.value.message.content || ''); must(/dobrar/.test(c) && /(=>|function|return)/.test(c), 'código inesperado'); return 'gerou código válido'
  })
  await step('pesquisa', async () => {
    const r = await chat([{ role: 'user', content: 'Em que ano estamos? Responda só com o ano.' }], { grounding: true })
    must(/20\d\d/.test(String(r.value.message.content || '')), 'resposta inesperada'); return 'pesquisa aceita'
  })
  const ms = Date.now() - t0, ok = checks.length > 0 && checks.every((c) => c.ok)
  const res: H.TestRes = { at: new Date().toISOString(), ok, ms, sig: t.sig, checks }
  await H.recordTest(p.id, res)
  const texto = checks.find((c) => c.cap === 'texto')
  if (texto?.ok) H.resetBreaker(p.id)
  else if (hs.err) await H.failure(t.id, t.sig, hs.err, 'teste', cfg.breaker)
  const bad = checks.filter((c) => !c.ok)
  const message = ok ? `Funcionando (${t.model}, ${(ms / 1000).toFixed(1)} s): ${checks.map((c) => `${c.label} ✔`).join(' · ')}` : bad.length === 1 && bad[0].cap === 'texto' ? bad[0].detail : `${bad.map((c) => `${c.label}: ${c.detail}`).join(' · ')}${checks.some((c) => c.ok) ? ` (ok: ${checks.filter((c) => c.ok).map((c) => c.label).join(', ')})` : ''}`
  return { ok, message, ms, checks }
}

/* ---------- monitor de saúde: recupera provedores sozinho ---------- */
const lastProbe = new Map<string, number>()
let monitor: NodeJS.Timeout | null = null
async function probeOnce() {
  const cfg = await routerCfg(); if (!cfg.monitor.ativo) return
  for (const p of await loadProviders()) {
    if (!p.ativo) continue
    const t = await targetFor(p); if (!t) continue
    const b = H.info(t.id, t.sig)
    if (b.state === 'closed') continue // saudável
    const due = b.hard ? Date.now() - (lastProbe.get(t.id) || 0) > 15 * 60_000 : Date.now() >= b.until
    if (!due) continue
    lastProbe.set(t.id, Date.now()); H.beginProbe(t.id, t.sig)
    const r = await testProvider(p, ['texto']).catch(() => null)
    if (r?.ok) console.log(`[ai] ${t.nome} recuperada pelo monitor de saúde`)
  }
}
export function startAiMonitor() {
  if (monitor) return
  monitor = setInterval(() => { void probeOnce().catch(() => {}) }, 60_000); monitor.unref?.()
}
export const _probeOnce = probeOnce
