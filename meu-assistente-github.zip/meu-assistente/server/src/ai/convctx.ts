// Memória contextual POR CONVERSA (persistida no banco, tabela conversation_context): o que já foi dito, o que falta
// perguntar, os registros criados nesta conversa e as ações executadas. Funciona sem IA; a IA (Ollama etc.) só recebe
// um resumo como apoio. A memória geral do usuário continua no Cérebro/memória do usuário — as duas não se misturam.
import { q, one, J, nowIso } from '../db/index.js'
import type { SessionUser } from '../lib/session.js'
import { settingsOf } from '../lib/account.js'
import { localDate } from '../lib/time.js'

export interface ConvCtx { topico?: string; pendente?: any; ultimos?: Record<string, number>; acoes?: { tipo: string; id: number; resumo: string; em: string }[]; atualizado?: string }
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[!?.,;]+/g, ' ').replace(/\s+/g, ' ').trim()

export async function getCtx(convId: string, userId: number): Promise<ConvCtx> {
  if (!convId) return {}
  const r = await one('SELECT user_id, estado FROM conversation_context WHERE conversation_id = $1', [convId]).catch(() => null)
  if (!r || Number(r.user_id) !== userId) return {} // nunca lê a conversa de outra pessoa
  return J<ConvCtx>(r.estado, {})
}
export async function saveCtx(convId: string, userId: number, c: ConvCtx) {
  if (!convId) return
  c.atualizado = nowIso(); c.acoes = (c.acoes || []).slice(-15)
  const ex = await one('SELECT user_id FROM conversation_context WHERE conversation_id = $1', [convId])
  if (ex && Number(ex.user_id) !== userId) return
  if (ex) await q('UPDATE conversation_context SET estado = $1, updated_at = $2 WHERE conversation_id = $3', [JSON.stringify(c), nowIso(), convId])
  else await q('INSERT INTO conversation_context (conversation_id, user_id, estado, updated_at) VALUES ($1,$2,$3,$4)', [convId, userId, JSON.stringify(c), nowIso()])
}
export async function lembrarAcao(convId: string, userId: number, tipo: string, id: number, resumo: string, topico?: string) {
  if (!convId || !id) return
  const c = await getCtx(convId, userId)
  c.ultimos = { ...(c.ultimos || {}), [tipo]: id }
  c.acoes = [...(c.acoes || []), { tipo, id, resumo, em: nowIso() }]
  if (topico) c.topico = topico
  if (c.pendente?.tipo === 'agendamento' && tipo === 'appointment') delete c.pendente
  await saveCtx(convId, userId, c)
}

/* ---------- leitura dos dados de um compromisso (data no fuso local do usuário) ---------- */
const WD = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado']
const addDays = (iso: string, n: number) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10) }
export function campos(text: string, tz: string) {
  const s = nrm(text), out: any = {}, today = localDate(tz)
  if (/depois de amanha/.test(s)) out.date = addDays(today, 2)
  else if (/\bamanha\b/.test(s)) out.date = addDays(today, 1)
  else if (/\bhoje\b/.test(s)) out.date = today
  else {
    const w = WD.findIndex((d) => new RegExp(`\\b${d}(-feira| feira)?\\b`).test(s))
    if (w >= 0) { const cur = new Date(today + 'T12:00:00Z').getUTCDay(); out.date = addDays(today, ((w - cur + 7) % 7) || 7) }
    const dm = s.match(/\bdia (\d{1,2})(?:\/(\d{1,2}))?\b/) || s.match(/\b(\d{1,2})\/(\d{1,2})\b/)
    if (dm) {
      const [y, m] = today.split('-').map(Number); let mes = dm[2] ? Number(dm[2]) : m, ano = y; const dd = Number(dm[1])
      if (!dm[2] && dd < Number(today.slice(8))) mes++
      if (dm[2] && `${y}-${String(mes).padStart(2, '0')}-${String(dd).padStart(2, '0')}` < today) ano++
      if (mes > 12) { mes = 1; ano++ }
      if (dd >= 1 && dd <= 31 && mes >= 1 && mes <= 12) out.date = `${ano}-${String(mes).padStart(2, '0')}-${String(dd).padStart(2, '0')}`
    }
  }
  const tm = s.match(/\b(?:as|a partir das|pelas|para as|pras)\s*(\d{1,2})(?:[:h](\d{2}))?\s*(?:h|horas?)?\b/) || s.match(/\b(\d{1,2})[:h](\d{2})\b/) || s.match(/\b(\d{1,2})\s*h(?:oras?)?\b/)
  if (/\bmeio[- ]dia\b/.test(s)) out.time = '12:00'
  else if (tm) { let hh = Number(tm[1]); const mm = Number(tm[2] || 0); if (/\b(da tarde|a tarde|da noite|a noite)\b/.test(s) && hh < 12) hh += 12; if (hh <= 23 && mm <= 59) out.time = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}` }
  const lm = text.match(/\b(?:no|na|em)\s+((?:escrit[oó]rio|consult[oó]rio|cl[ií]nica|est[uú]dio|loja|casa|empresa|sala|caf[eé]|restaurante|shopping|hospital|escola|academia)(?:\s+(?:d[oa]s?|de)\s+[\wÀ-ÿ]+){0,2})/i)
  if (lm) out.location = lm[1].trim()
  const pm = text.match(/\b(?:com|para|pra)\s+(?:o |a |os |as )?([A-ZÀ-Ý][\wÀ-ÿ'-]+(?:\s+[A-ZÀ-Ý][\wÀ-ÿ'-]+)?)/)
  if (pm && !/^(Amanh|Hoje|Dia|Segunda|Ter|Quarta|Quinta|Sexta|S[áa]bado|Domingo)/.test(pm[1])) out.person = pm[1]
  const km = s.match(/\b(reuniao|consulta|dentista|medico|exame|entrevista|aula|treino|encontro|visita|call|chamada|tatuagem|sessao|corte|manicure|almoco|jantar|evento)\b/)
  if (km) out.title = ({ reuniao: 'Reunião', consulta: 'Consulta', medico: 'Médico', sessao: 'Sessão', almoco: 'Almoço' } as any)[km[1]] || km[1].charAt(0).toUpperCase() + km[1].slice(1)
  return out
}
export const querAgendar = (text: string) => /\b(agend|marc|marque|reservar?)\w*\b/.test(nrm(text)) && !/\b(cancel|desmarc|remarc|lembr|tarefa|gastei|paguei)/.test(nrm(text))

/* ---------- apresentação ---------- */
const fmtData = (iso: string, tz: string) => { const hoje = localDate(tz); if (iso === hoje) return 'hoje'; if (iso === addDays(hoje, 1)) return 'amanhã'; const d = new Date(iso + 'T12:00:00Z'); return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: '2-digit', timeZone: 'UTC' }) }
export async function itemVivo(userId: number, tipo: string, id: number) { return one('SELECT id, type, status, day, data FROM items WHERE id = $1 AND user_id = $2 AND type = $3', [id, userId, tipo]) }
export function resumoAppt(r: any, tz: string) { const d = J<any>(r.data, {}); return `"${d.title}" ${fmtData(r.day, tz)}${d.time ? ' às ' + d.time : ''}${d.location ? ' em ' + d.location : ''}${d.person ? ' com ' + d.person : ''}` }
/** Resumo da memória desta conversa para a IA auxiliar (Ollama etc.) — só apoio; as ações não dependem dela. */
export async function ctxParaIA(convId: string, u: SessionUser) {
  const c = await getCtx(convId, u.id), tz = settingsOf(u).timezone, partes: string[] = []
  if (c.topico) partes.push(`Assunto atual desta conversa: ${c.topico}.`)
  if (c.pendente?.tipo === 'agendamento') partes.push(`Agendamento em andamento nesta conversa (dados já informados, NÃO pergunte de novo): ${JSON.stringify(c.pendente.campos)}. Falta: ${c.pendente.falta}.`)
  if (c.ultimos?.appointment) { const r = await itemVivo(u.id, 'appointment', c.ultimos.appointment); if (r) partes.push(`Compromisso citado nesta conversa: ${resumoAppt(r, tz)} (id ${r.id}).`) }
  return partes.join(' ')
}

/* ---------- motor de continuidade (sem IA) ---------- */
const PERG: Record<string, string> = { title: 'Qual é o compromisso? (ex.: reunião, consulta, dentista)', date: 'Para que dia?', time: 'Que horas?' }
const falta = (c: any) => (!c.title ? 'title' : !c.date ? 'date' : !c.time ? 'time' : '')
async function criarAppt(u: SessionUser, convId: string, c: any, tz: string) {
  // consulta antes de gravar: o mesmo compromisso no mesmo dia e horário não é duplicado
  for (const r of await q("SELECT id, day, data, status FROM items WHERE user_id = $1 AND type = 'appointment' AND day = $2", [u.id, c.date])) {
    const d = J<any>(r.data, {})
    if (r.status !== 'cancelled' && d.time === c.time && nrm(d.title) === nrm(c.title)) { await lembrarAcao(convId, u.id, 'appointment', Number(r.id), resumoAppt(r, tz), c.title); return { content: `Esse compromisso já está na sua agenda: ${resumoAppt(r, tz)}. Não criei outro. ⟦appt:${r.id}⟧`, cards: [] } }
  }
  const { itemAction } = await import('../routes/items.js'), { db } = await import('../db/index.js'), { useQuota } = await import('../lib/usage.js')
  await useQuota(u, 'appointment')
  const res: any = await db().tx((t: any) => itemAction(u, 'create', 'appointment', 0, { title: c.title, date: c.date, time: c.time, location: c.location || '', person: c.person || '', ...(c.person ? { cliente_nome: c.person } : {}) }, t))
  const id = Number(res.created?.[0]?.id), salvo = id ? await itemVivo(u.id, 'appointment', id) : null
  if (!salvo) return { content: 'Não consegui salvar o compromisso agora. Nada foi gravado — tente de novo.', cards: [] }
  await lembrarAcao(convId, u.id, 'appointment', id, resumoAppt(salvo, tz), c.title)
  return { content: `Pronto! Agendei ${resumoAppt(salvo, tz)}. Vou te avisar 1 dia e 1 hora antes. ⟦appt:${id}⟧`, cards: [] }
}
export async function contextReply(u: SessionUser, convId: string, text: string, hist: { role: string; content: string | null }[] = []): Promise<{ content: string; cards: any[] } | null> {
  if (!convId) return null
  const tz = settingsOf(u).timezone, s = nrm(text), c = await getCtx(convId, u.id)
  // 1) agendamento em andamento nesta conversa: junta o que chega em mensagens separadas
  if (c.pendente?.tipo === 'agendamento') {
    if (/^(deixa|esquece|cancela|cancelar|nao quero|desisto|para)\b/.test(s)) { delete c.pendente; await saveCtx(convId, u.id, c); return { content: 'Tudo bem, deixei esse agendamento de lado. Nada foi salvo.', cards: [] } }
    const novo = campos(text, tz)
    if (!novo.title && c.pendente.falta === 'title' && !Object.keys(novo).length && s.split(' ').length <= 5) novo.title = text.trim().replace(/^(um|uma|o|a)\s+/i, '').replace(/^./, (x) => x.toUpperCase()).slice(0, 80)
    if (Object.keys(novo).length) {
      c.pendente.campos = { ...c.pendente.campos, ...Object.fromEntries(Object.entries(novo).filter(([k]) => !(k === 'title' && c.pendente.campos.title))) }
      const f = falta(c.pendente.campos)
      if (!f) { const cp = c.pendente.campos; delete c.pendente; await saveCtx(convId, u.id, c); return criarAppt(u, convId, cp, tz) }
      c.pendente.falta = f; await saveCtx(convId, u.id, c); return { content: PERG[f], cards: [] }
    }
  }
  // 2) confirmação pendente para cancelar
  if (c.pendente?.tipo === 'cancelar') {
    const id = c.pendente.id
    if (/^(sim|pode|confirmo|isso|cancela|pode cancelar)\b/.test(s)) {
      delete c.pendente; await saveCtx(convId, u.id, c)
      await q("UPDATE items SET status = 'cancelled', due_at = NULL, updated_at = $1 WHERE id = $2 AND user_id = $3", [nowIso(), id, u.id])
      const r = await itemVivo(u.id, 'appointment', id)
      if (r?.status === 'cancelled') { await lembrarAcao(convId, u.id, 'appointment', id, 'cancelado: ' + resumoAppt(r, tz)); return { content: `Cancelei ${resumoAppt(r, tz)}.`, cards: [] } }
      return { content: 'Não consegui cancelar agora. Nada foi alterado.', cards: [] }
    }
    if (/^(nao|deixa|mantem|manter)\b/.test(s)) { delete c.pendente; await saveCtx(convId, u.id, c); return { content: 'Certo, mantive o compromisso.', cards: [] } }
  }
  // 3) referência a um compromisso desta conversa ("aquela reunião", "remarca para 11h", "cancela")
  const ref = /\b(aquel[ae]|ess[ae]|est[ae]|da|na|a|o)\s+(reuniao|compromisso|consulta|agendamento|evento|horario|entrevista|visita|aula|sessao|tatuagem|dentista|exame)\b/.test(s) || /^(remarca|remarque|muda|mude|passa|troca|adia|antecipa|cancela|desmarca)\b/.test(s)
  if (ref && c.ultimos?.appointment) {
    const r = await itemVivo(u.id, 'appointment', c.ultimos.appointment)
    if (r) {
      if (/\b(cancel|desmarc)/.test(s)) { c.pendente = { tipo: 'cancelar', id: Number(r.id) }; await saveCtx(convId, u.id, c); return { content: `Confirma cancelar ${resumoAppt(r, tz)}? (sim/não)`, cards: [] } }
      const mud = campos(text, tz); delete mud.title; delete mud.person
      if (/\b(remarc|mud|pass|troc|adi|antecip|para as|pras|para o dia|outro horario)/.test(s) && (mud.date || mud.time || mud.location)) {
        const { itemAction } = await import('../routes/items.js'), { db } = await import('../db/index.js'), d = J<any>(r.data, {})
        await db().tx((t: any) => itemAction(u, 'appointment_update', 'appointment', Number(r.id), { date: mud.date || r.day, time: mud.time || d.time, ...(mud.location ? { location: mud.location } : {}) }, t))
        const nr = await itemVivo(u.id, 'appointment', Number(r.id)), nd = J<any>(nr?.data, {})
        if (nr && (!mud.date || nr.day === mud.date) && (!mud.time || nd.time === mud.time)) { await lembrarAcao(convId, u.id, 'appointment', Number(r.id), 'remarcado: ' + resumoAppt(nr, tz)); return { content: `Remarquei: ${resumoAppt(nr, tz)}. ⟦appt:${r.id}⟧`, cards: [] } }
        return { content: 'Não consegui remarcar agora. Nada foi alterado.', cards: [] }
      }
      if (/\b(aquel[ae]|ess[ae]|est[ae])\s+(reuniao|compromisso|consulta|agendamento|evento|entrevista|visita|aula|sessao|tatuagem|dentista|exame)\b/.test(s) && /\b(que horas|horario|quando|que dia|onde|local|com quem|qual)\b/.test(s)) return { content: `É ${resumoAppt(r, tz)}.${r.status === 'cancelled' ? ' (está cancelado)' : ''} ⟦appt:${r.id}⟧`, cards: [] }
    }
  }
  // 4) retomar a conversa ("sobre o que conversamos", "quero continuar")
  if (/\b(sobre o que (a gente )?(conversamos|falamos)|onde (a gente )?paramos|quero continuar|vamos continuar|continuar de onde|retomar|continuando)\b/.test(s)) {
    const partes: string[] = []
    if (c.pendente?.tipo === 'agendamento') { const p = c.pendente.campos; partes.push(`Estávamos agendando ${p.title ? '"' + p.title + '"' : 'um compromisso'}${p.date ? ' para ' + fmtData(p.date, tz) : ''}${p.time ? ' às ' + p.time : ''}. ${PERG[c.pendente.falta] || ''}`.trim()) }
    const vivos: string[] = []
    for (const a of (c.acoes || []).slice(-3).reverse()) { const r = a.tipo === 'appointment' ? await itemVivo(u.id, 'appointment', a.id) : await one('SELECT id FROM items WHERE id = $1 AND user_id = $2', [a.id, u.id]); if (r) vivos.push(a.tipo === 'appointment' ? resumoAppt(r, tz) : a.resumo) }
    if (vivos.length) partes.push(`Por aqui já ficou registrado: ${vivos.join('; ')}.`)
    if (!partes.length) { const ult = [...hist].reverse().find((m) => m.role === 'user' && m.content); partes.push(ult ? `A última coisa que você me pediu aqui foi: "${String(ult.content).slice(0, 120)}". Quer seguir com isso?` : 'Ainda não temos nada pendente nesta conversa. Como posso ajudar?') }
    return { content: partes.join(' '), cards: [] }
  }
  // 5) "conseguiu resolver?" — confere no banco antes de afirmar
  if (/\b(conseguiu( resolver| salvar| agendar| registrar)?|deu certo|ficou salvo|salvou|foi feito|esta salvo|agendou)\b/.test(s) && s.split(' ').length <= 6) {
    const a = (c.acoes || []).slice(-1)[0]; if (!a) return { content: 'Nesta conversa ainda não executei nenhuma ação.', cards: [] }
    const r = await one('SELECT id, type, status, day, data FROM items WHERE id = $1 AND user_id = $2', [a.id, u.id])
    return r ? { content: `Sim, conferi no banco: ${r.type === 'appointment' ? resumoAppt(r, tz) + (r.status === 'cancelled' ? ' (cancelado)' : '') : a.resumo} está salvo.${r.type === 'appointment' ? ` ⟦appt:${r.id}⟧` : r.type === 'expense' ? ` ⟦fin:${r.id}⟧` : ''}`, cards: [] }
      : { content: `Não encontrei mais o registro "${a.resumo}" — ele pode ter sido excluído.`, cards: [] }
  }
  // 6) começo de agendamento sem todos os dados: guarda o que veio e pergunta só o que falta
  const pergunta = /\?\s*$/.test(text) || /^(qual|quais|que|tenho|o que|quando|onde|como|quantos?)\b/.test(s)
  if (!pergunta && (querAgendar(text) || (/\b(reuniao|consulta|dentista|compromisso|entrevista)\b/.test(s) && /\b(amanha|hoje|dia \d|segunda|terca|quarta|quinta|sexta|sabado|domingo)\b/.test(s)))) {
    const cp = campos(text, tz), f = falta(cp)
    if (f) { c.pendente = { tipo: 'agendamento', campos: cp, falta: f }; c.topico = cp.title || 'agendamento'; await saveCtx(convId, u.id, c); return { content: PERG[f], cards: [] } }
  }
  return null
}
