// Recuperação de conhecimento por CLÁUSULAS, com avaliação de condições (sem IA).
// Um conhecimento como
//   "Compras acima de R$ 150: entrega gratuita. Compras abaixo de R$ 150: taxa de R$ 10.
//    Prazo de entrega: até 2 dias úteis. Retirada no estabelecimento: gratuita."
// é quebrado em cláusulas. A pergunta é comparada com cada cláusula (palavras, radicais e sinônimos comerciais), e
// cláusulas com condição numérica ("acima de", "abaixo de", "até", "a partir de"...) são AVALIADAS contra o valor da
// pergunta: "compra de R$ 100" só recebe a cláusula cuja condição é verdadeira para 100. A resposta usa o texto
// cadastrado (nada é inventado). Os conhecimentos ativos ficam em cache e o cache é invalidado quando o Cérebro muda.
import { q, one } from '../db/index.js'

const norm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const STOP = new Set('a o os as um uma uns umas de da do das dos e ou em no na nos nas para pra por com sem que se ao aos como mais muito pouco sobre isso este esta esse essa ele ela eles elas voce voces seu sua seus suas ser estar ter tem foi sao ja nao eu meu minha me qual quais quanto quanta quantos quantas fica ficar vou posso pode podem fazer faco fizer fiz caso entao tambem algum alguma vcs vc gostaria queria quero saber'.split(' '))
const stem = (w: string) => (w.length <= 4 ? w : w.replace(/(oes|aes)$/, 'ao').replace(/ais$/, 'al').replace(/eis$/, 'el').replace(/ns$/, 'm').replace(/(es|s)$/, ''))
const casa = (a: string, b: string) => a === b || (a.length >= 5 && b.length >= 5 && a.slice(0, 5) === b.slice(0, 5))
/** Grupos de sinônimos do vocabulário comercial: aproximam a pergunta do texto cadastrado, sem criar conteúdo. */
const SIN: string[][] = [
  ['entrega', 'entregar', 'entregam', 'frete', 'delivery', 'envio', 'enviar', 'enviam', 'mandam', 'chega', 'chegar'],
  ['retirada', 'retirar', 'retiro', 'buscar', 'busco', 'pegar', 'pego', 'pessoalmente', 'balcao', 'estabelecimento', 'presencial'],
  ['gratuita', 'gratuito', 'gratis', 'free', 'cobram', 'cobra', 'custo', 'paga', 'pagar', 'taxa', 'valor', 'preco', 'quanto'],
  ['prazo', 'demora', 'demorar', 'tempo', 'dias', 'quando', 'rapido', 'leva', 'levar'],
  ['compra', 'compras', 'pedido', 'pedidos', 'comprar', 'comprei', 'compro', 'encomenda'],
  ['horario', 'abre', 'abrem', 'fecha', 'fecham', 'funciona', 'funcionamento', 'atende', 'atendem', 'atendimento', 'aberto'],
  ['pagamento', 'pagar', 'pix', 'cartao', 'dinheiro', 'aceita', 'aceitam', 'forma'],
  ['troca', 'trocar', 'devolucao', 'devolver', 'reembolso', 'garantia'],
]
const SIN_IDX = new Map<string, number>(); SIN.forEach((g, i) => g.forEach((w) => SIN_IDX.set(stem(w), i)))
const grupo = (w: string) => { if (SIN_IDX.has(w)) return SIN_IDX.get(w)!; for (const [k, i] of SIN_IDX) if (casa(k, w)) return i; return -1 }
/** Expressões de várias palavras viram o termo canônico antes da comparação ("buscar na loja" → retirada). */
const EXPR: [RegExp, string][] = [
  [/\b(buscar|pegar|retirar|retiro|busco|pego)\s+(na|no|em|la na|la no)\s+(loja|local|estabelecimento|balcao|endereco|sede)\b/g, ' retirada '],
  [/\b(ir|vou|posso|da pra|da para)\s+(buscar|pegar|retirar)\b/g, ' retirada '], [/\b(retirada|retirar|buscar|pegar)\s+pessoal(mente)?\b/g, ' retirada '],
  [/\bde graca\b|\bsem custo\b|\bsem taxa\b|\bfree\b/g, ' gratuita '], [/\bquanto (fica|custa|sai|e|eh)\b/g, ' valor '],
  [/\bque horas?\b/g, ' horario '], [/\bquantos dias\b|\bem quanto tempo\b/g, ' prazo '],
]
const canon = (t: string) => { let s = norm(t); for (const [re, w] of EXPR) s = s.replace(re, w); return s }
const termos = (t: string) => [...new Set(canon(t).replace(/r\$\s*[\d.,]+/g, ' ').replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w) && !/^\d+$/.test(w)).map(stem))]

/* ---------- valores e condições ---------- */
const num = (raw: string) => { const s = raw.trim(); if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(s)) return Number(s.replace(/\./g, '').replace(',', '.')); return Number(s.replace(',', '.')) }
const VAL = /(?:r\$\s*)?(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:reais|real|conto|contos)?/
/** Valor da pergunta ("compra de R$ 100", "pedido de 200 reais"). Ignora horas, datas e quantidades de dias. */
export function valorDaPergunta(text: string): number | null {
  const s = norm(text)
  const m = s.match(/r\$\s*(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)/) || s.match(/(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:reais|real|conto|contos)\b/)
    || s.match(/\b(?:compra|pedido|valor|gasto|total|conta|encomenda)s?\s+(?:de|no valor de|com valor de|for de|for)?\s*(\d+(?:[.,]\d{1,2})?)\b(?!\s*(?:dias?|horas?|h\b|min|%|\/|:))/)
  return m ? num(m[1]) : null
}
type Cond = { op: '>' | '>=' | '<' | '<='; v: number }
/** Condições numéricas de uma cláusula: "acima de R$ 150" → v > 150; "até R$ 100" → v <= 100; "entre 50 e 100" → duas. */
export function condicoes(clausula: string): Cond[] {
  const s = norm(clausula), out: Cond[] = []
  const v = String(VAL.source)
  const add = (re: RegExp, op: Cond['op']) => { for (const m of s.matchAll(re)) { const n = num(m[1]); if (isFinite(n)) out.push({ op, v: n }) } }
  add(new RegExp(`(?:acima de|mais de|maior(?:es)? (?:que|do que)|superior(?:es)? a|superando|passar de|ultrapass\\w* )\\s*${v}`, 'g'), '>')
  add(new RegExp(`(?:a partir de|no minimo|minimo de|pelo menos|igual ou (?:acima|maior)(?: de| que| a)?)\\s*${v}`, 'g'), '>=')
  add(new RegExp(`(?:abaixo de|menos de|menor(?:es)? (?:que|do que)|inferior(?:es)? a)\\s*${v}`, 'g'), '<')
  add(new RegExp(`(?:ate|no maximo|maximo de|igual ou (?:abaixo|menor)(?: de| que| a)?)\\s*${v}(?!\\s*(?:dias?|horas?|h\\b|min|semanas?|meses|uteis))`, 'g'), '<=')
  const e = s.match(new RegExp(`entre\\s*${v}\\s*e\\s*${v}`)); if (e) { out.push({ op: '>=', v: num(e[1]) }, { op: '<=', v: num(e[2]) }) }
  return out
}
const vale = (c: Cond[], x: number) => c.every((k) => (k.op === '>' ? x > k.v : k.op === '>=' ? x >= k.v : k.op === '<' ? x < k.v : x <= k.v))

/* ---------- cache dos conhecimentos ativos (invalidado quando o Cérebro muda) ---------- */
type Item = { id: number; user_id: number | null; titulo: string; conteudo: string; kind: string; origin: string; reviewed: boolean; qn: string; clausulas: { texto: string; termos: string[]; cond: Cond[] }[]; tTit: string[] }
type Ref = { it: Item; c: { texto: string; termos: string[]; cond: Cond[] } }
/** índice invertido: palavra, prefixo de 5 letras e grupo de sinônimos → cláusulas que os contêm */
let cache: { sig: string; itens: Item[]; at: number; refs: Ref[]; idx: Map<string, number[]> } | null = null
export const kstats = { hits: 0, misses: 0, ultimaCarga: 0, ultimaCargaMs: 0 }
export function invalidateKnowledge() { cache = null }
function quebra(conteudo: string) {
  // cláusulas: linhas e frases; "Título: texto" mantém o título junto da sua regra
  const partes = String(conteudo || '').split(/\n+/).flatMap((l) => l.split(/(?<=[.!?;])\s+(?=[A-ZÀ-Ý*•\-])/)).map((x) => x.replace(/^[\s*•\-–]+/, '').trim()).filter((x) => x.length >= 3)
  return partes.slice(0, 60).map((texto) => ({ texto, termos: termos(texto), cond: condicoes(texto) }))
}
export async function activeKnowledge(): Promise<Item[]> {
  const s = await one('SELECT COUNT(*) AS n, MAX(updated_at) AS m, MAX(id) AS i FROM brain_answers')
  const sig = `${s?.n}|${s?.m}|${s?.i}`
  if (cache && cache.sig === sig) { kstats.hits++; return cache.itens }
  kstats.misses++; const t0 = Date.now()
  const rows = await q("SELECT id, user_id, question, answer, question_norm, kind, origin, reviewed FROM brain_answers WHERE status = 'ativo' LIMIT 20000")
  const itens: Item[] = rows.map((r: any) => ({ id: Number(r.id), user_id: r.user_id == null ? null : Number(r.user_id), titulo: String(r.question || ''), conteudo: String(r.answer || ''), kind: r.kind || 'resposta', origin: r.origin || '', reviewed: r.reviewed === true || r.reviewed === 1, qn: String(r.question_norm || ''), clausulas: quebra(String(r.answer || '')), tTit: termos(String(r.question || '')) }))
  const refs: Ref[] = [], idx = new Map<string, number[]>()
  const put = (k: string, i: number) => { let a = idx.get(k); if (!a) idx.set(k, (a = [])); if (a[a.length - 1] !== i) a.push(i) }
  for (const it of itens) {
    const cl = it.clausulas.length ? it.clausulas : [{ texto: it.conteudo, termos: termos(it.conteudo), cond: condicoes(it.conteudo) }]
    const ini = refs.length
    for (const c of cl) { const i = refs.push({ it, c }) - 1; for (const w of c.termos) { put('w:' + w, i); if (w.length >= 5) put('p:' + w.slice(0, 5), i); const g = grupo(w); if (g >= 0) put('g:' + g, i) } }
    for (const w of it.tTit) for (let i = ini; i < refs.length; i++) { put('w:' + w, i); if (w.length >= 5) put('p:' + w.slice(0, 5), i) } // título vale para todas as cláusulas do item
  }
  cache = { sig, itens, at: Date.now(), refs, idx }; kstats.ultimaCarga = Date.now(); kstats.ultimaCargaMs = Date.now() - t0
  return itens
}
/** Só as cláusulas que compartilham palavra, prefixo ou grupo de sinônimos com a pergunta (em vez de todas). */
async function candidatas(qt: string[]) {
  await activeKnowledge(); const c = cache!, set = new Set<number>()
  for (const w of qt) { for (const k of ['w:' + w, w.length >= 5 ? 'p:' + w.slice(0, 5) : '', grupo(w) >= 0 ? 'g:' + grupo(w) : '']) if (k) for (const i of c.idx.get(k) || []) set.add(i) }
  return [...set].map((i) => c.refs[i])
}

/* ---------- pergunta hipotética × consulta de um pedido real ---------- */
/** "Onde está meu pedido #123?", "minha compra chegou?" pedem o banco de pedidos; "se eu comprar R$ 100..." é regra. */
export function ehConsultaDePedidoReal(text: string) {
  const s = norm(text)
  if (/\b(se eu|caso eu|se a compra|se o pedido|uma compra|um pedido|compras? (acima|abaixo|de)|quanto fica|quanto custa|como funciona)\b/.test(s)) return false
  return /\b(meu|minha|meus|minhas)\s+(pedido|compra|encomenda|entrega)s?\b/.test(s) && /\b(chegou|chega|esta|status|onde|cade|saiu|rastreio|rastrear|codigo|numero|#\d+|atrasad|cancel)/.test(s)
}

/* ---------- resposta ---------- */
export interface KAnswer { resposta: string; ids: number[]; score: number; titulo: string; clausulas: string[]; tipo: string }
const brl = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
function pontuaClausula(qt: string[], qg: Set<number>, c: { termos: string[] }, tTit: string[]) {
  if (!qt.length) return 0
  let hit = 0
  for (const w of qt) {
    if (c.termos.some((x) => casa(w, x))) { hit += 1; continue }
    const g = grupo(w); if (g >= 0 && c.termos.some((x) => grupo(x) === g)) { hit += 0.75; continue }
    if (tTit.some((x) => casa(w, x) || (grupo(w) >= 0 && grupo(x) === grupo(w)))) hit += 0.35
  }
  const cob = hit / qt.length
  const temas = [...qg].filter((g) => c.termos.some((x) => grupo(x) === g)).length
  return cob + 0.15 * temas
}
/**
 * Responde pelo conhecimento aprovado, avaliando condições. Devolve null quando não há conhecimento relevante.
 * 1) acha o TEMA pela semelhança do texto (sem olhar condições); 2) dentro do tema, aplica as condições ao valor da
 * pergunta; 3) responde com o texto cadastrado. Valor no limite sem regra definida → diz isso, sem inventar.
 */
export async function answerKnowledge(text: string, userId: number | null = null, minScore = 0.55): Promise<KAnswer | null> {
  const qt = termos(text); if (!qt.length) return null
  const qg = new Set(qt.map(grupo).filter((g) => g >= 0))
  const valor = valorDaPergunta(text)
  const permitido = (it: Item) => (it.user_id == null || it.user_id === userId) && !(it.kind === 'resposta' && !(it.origin === 'admin' || it.reviewed))
  type Cand = { it: Item; texto: string; base: number; cond: Cond[]; ok: boolean | null }
  const cands: Cand[] = []
  for (const { it, c } of await candidatas(qt)) {
    if (!permitido(it)) continue
    const base = pontuaClausula(qt, qg, c, it.tTit); if (base > 0) cands.push({ it, texto: c.texto, base, cond: c.cond, ok: c.cond.length && valor !== null ? vale(c.cond, valor) : null })
  }
  if (!cands.length) return null
  cands.sort((a, b) => b.base - a.base)
  const topo = cands[0]; if (topo.base < minScore) return null
  // o tema: cláusulas tão relevantes quanto a melhor (margem pequena), do mesmo conhecimento ou de outros
  const tema = cands.filter((c) => c.base >= topo.base - 0.25)
  const comCond = tema.filter((c) => c.cond.length)
  let escolhidas: Cand[] = [], prefixo = '', aviso = ''
  if (comCond.length && valor !== null) {
    // regras com faixa de valor: só vale a(s) que a condição aceita para esse valor — no mesmo conhecimento da melhor, se houver
    // todas as faixas do conhecimento mais relevante (não só as que têm mais palavras em comum com a pergunta)
    const alvo = comCond[0].it, todas = (alvo.clausulas.length ? alvo.clausulas : []).filter((c) => c.cond.length).map((c) => ({ it: alvo, texto: c.texto, base: 0, cond: c.cond, ok: vale(c.cond, valor) as boolean | null }))
    const doTopo = todas.length ? todas : cands.filter((c) => c.it.id === alvo.id && c.cond.length)
    const ok = (doTopo.some((c) => c.ok) ? doTopo : comCond).filter((c) => c.ok === true)
    if (ok.length) { escolhidas = [ok[0]]; prefixo = `Para ${/compra|pedido|encomenda/.test(norm(text)) ? 'uma compra' : 'o valor'} de ${brl(valor)}: ` }
    else { escolhidas = doTopo.slice(0, 4); aviso = `O conhecimento cadastrado não define o caso de exatamente ${brl(valor)}. As regras são:` }
  } else if (comCond.length && comCond[0].base >= topo.base - 0.05 && valor === null) {
    // pergunta sem valor sobre um tema com faixas: mostra todas as faixas do conhecimento, para não omitir condição
    const alvo = comCond[0].it
    escolhidas = (alvo.clausulas.length ? alvo.clausulas.filter((c) => c.cond.length).map((c) => ({ it: alvo, texto: c.texto, base: 0, cond: c.cond, ok: null })) : cands.filter((c) => c.it.id === alvo.id && c.cond.length)).slice(0, 4)
  } else {
    escolhidas = tema.filter((c) => !c.cond.length || c.ok !== false).slice(0, 1)
  }
  if (!escolhidas.length) return null
  const textos = [...new Set(escolhidas.map((c) => c.texto))]
  const corpo = textos.length === 1 && !aviso ? textos[0] : textos.map((t) => '• ' + t).join('\n')
  return { resposta: [aviso, prefixo + corpo].filter(Boolean).join('\n').trim(), ids: [...new Set(escolhidas.map((c) => c.it.id))], score: Math.round(topo.base * 100) / 100, titulo: escolhidas[0].it.titulo, clausulas: textos, tipo: escolhidas[0].it.kind }
}
