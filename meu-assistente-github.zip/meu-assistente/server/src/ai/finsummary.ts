// "Me mostre os resultados das finanças", "como estão minhas finanças", "meu saldo do mês"…
// Responde com os números reais do módulo financeiro (sem IA) e o cartão do módulo.
import type { SessionUser } from '../lib/session.js'
import { q, J } from '../db/index.js'
import { settingsOf } from '../lib/account.js'
import { localDate } from '../lib/time.js'
const nrm = (t: string) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[!?.,;:]+/g, ' ').replace(/\s+/g, ' ').trim()
const CAT: Record<string, string> = { alimentacao: 'Alimentação', combustivel: 'Combustível', casa: 'Casa', trabalho: 'Trabalho', compras: 'Compras', saude: 'Saúde', transporte: 'Transporte', lazer: 'Lazer', outros: 'Outros', salario: 'Salário', servicos: 'Serviços', vendas: 'Vendas' }
const brl = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
export function isFinanceSummary(text: string) {
  const s = nrm(text)
  if (s.split(' ').length > 14) return false
  return /\b(resultado|resultados|resumo|balanco|relatorio|situacao|como (estao|esta|vao|anda|andam)|mostr\w*|ver|quero ver|meu|minha|minhas|meus)\b.*\b(financas|financeiro|financeira|gastos|despesas|receitas|saldo|dinheiro|contas do mes)\b|\b(quanto (eu )?(gastei|recebi|ganhei|entrou|saiu))\b|\bmeu saldo\b|\bsaldo do mes\b/.test(s)
}
export async function financeSummary(u: SessionUser, text: string) {
  if (!isFinanceSummary(text)) return null
  const s = nrm(text), today = localDate(settingsOf(u).timezone)
  const semana = /\bsemana\b/.test(s), passado = /\bmes passado\b/.test(s)
  let from: string, to: string, label: string
  if (semana) { const d = new Date(today + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - 6); from = d.toISOString().slice(0, 10); to = today; label = 'nos últimos 7 dias' }
  else if (passado) { const d = new Date(today.slice(0, 7) + '-01T12:00:00Z'); d.setUTCMonth(d.getUTCMonth() - 1); from = d.toISOString().slice(0, 10); to = from.slice(0, 7) + '-31'; label = 'no mês passado' }
  else { from = today.slice(0, 7) + '-01'; to = today; label = 'neste mês' }
  const rows = await q("SELECT data, day FROM items WHERE user_id = $1 AND type = 'expense' AND day >= $2 AND day <= $3", [u.id, from, to])
  let inc = 0, out = 0; const cats = new Map<string, number>()
  for (const r of rows) { const d = J<any>(r.data, {}), v = Number(d.amount) || 0; if (d.kind === 'income') inc += v; else { out += v; cats.set(d.category || 'outros', (cats.get(d.category || 'outros') || 0) + v) } }
  if (!rows.length) return { content: `Ainda não há lançamentos ${label}. Para registrar, é só escrever, por exemplo: "gastei 30 no mercado" ou "recebi 500 de um cliente". ⟦mod:financas⟧`, cards: [] }
  const top = [...cats.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([c, v]) => `${CAT[c] || c} ${brl(v)}`).join(', ')
  const saldo = inc - out
  return { content: `Suas finanças ${label}: entradas ${brl(inc)}, saídas ${brl(out)} e saldo ${saldo >= 0 ? 'positivo' : 'negativo'} de ${brl(Math.abs(saldo))}.${top ? ` Maiores gastos: ${top}.` : ''} (${rows.length} lançamento${rows.length === 1 ? '' : 's'}) ⟦mod:financas⟧`, cards: [] }
}
