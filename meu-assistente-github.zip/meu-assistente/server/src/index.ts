import { config } from './config.js'
import { connectFromEnv } from './db/connect.js'
import { migrate } from './db/migrate.js'
import { createApp, indexHtmlPresent } from './app.js'
import { startScheduler } from './scheduler.js'
import { ensureSetupCode } from './routes/auth.js'

const d = await connectFromEnv()
if (process.env.AUTO_MIGRATE !== 'false') await migrate(d, config.migrationsDir)
await (await import('./lib/usermod.js')).modules().catch(() => {})
await (await import('./routes/kb.js')).seedKb().catch((e) => console.error('[kb] seed:', e?.message)) // materiais iniciais da Biblioteca de Sobrevivência // carrega os módulos ligados/desligados pelo administrador
if (!indexHtmlPresent()) console.warn(`[app] ATENÇÃO: frontend não encontrado em ${config.staticDir}`)
const code = await ensureSetupCode()
if (code) console.log(`[setup] Já existem contas e nenhum Administrador Principal. Código de configuração: ${code} (use em /configuracao-inicial)`)
void import('./lib/account.js').then((m) => m.refreshVoiceGlobal()).catch(() => {})
void import('./lib/publicurl.js').then((m) => m.refreshPublicUrl()).catch(() => {})
if (config.schedulerEnabled) startScheduler()
;(await import('./ai/provider.js')).startAiMonitor() // monitor de saúde: recupera IAs em pausa sozinho
const server = createApp()
server.listen(config.port, config.host, () => console.log(`[app] Meu Assistente ouvindo em http://${config.host}:${config.port} (público: ${config.publicUrl})`))
const stop = async () => { await (await import('./ai/health.js')).flushStats().catch(() => {}); server.close(); await d.close().catch(() => {}); process.exit(0) }
process.on('SIGTERM', stop)
process.on('SIGINT', stop)
