// Agendador interno (substitui as "Scheduled Functions" da Netlify): dispara lembretes,
// avisos de compromissos e de contas vencendo, gravando na central de notificações.
import { q, J } from './db/index.js'
import { notify } from './lib/notify.js'
import { nextOccurrence, zonedToUtc, localDate, localTime, validTz } from './lib/time.js'

let running = false
export async function tick(now = new Date()) {
  if (running) return
  running = true
  try {
    const iso = now.toISOString()
    // Lembretes vencidos
    const due = await q(`SELECT i.*, u.settings FROM items i JOIN users u ON u.id = i.user_id
      WHERE i.type = 'reminder' AND i.status = 'pending' AND i.due_at IS NOT NULL AND i.due_at <= $1 LIMIT 500`, [iso])
    for (const r of due) {
      const d = J<any>(r.data, {})
      const uid = Number(r.user_id)
      await notify(uid, { type: 'reminder', title: d.message, body: d.leadMinutes && !d.snoozedUntil ? `Em ${d.leadMinutes} min` : undefined, link: `/agenda?tab=lembretes&lembrete=${r.id}`, ref: `reminder:${r.id}:${r.due_at}` })
      const next = !d.snoozedUntil && d.recurrence && d.recurrence !== 'none' ? nextOccurrence(d.date, d.recurrence) : null
      if (next) {
        const tz = validTz(J<any>(r.settings, {}).timezone)
        const remindAt = zonedToUtc(next, d.time, tz)
        const dueAt = new Date(new Date(remindAt).getTime() - (d.leadMinutes || 0) * 60_000).toISOString()
        await q('UPDATE items SET day = $1, due_at = $2, data = $3, updated_at = $4 WHERE id = $5', [next, dueAt, JSON.stringify({ ...d, date: next, remindAt, snoozedUntil: null }), iso, r.id])
      } else {
        await q("UPDATE items SET status = 'sent', due_at = NULL, data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify({ ...d, snoozedUntil: null }), iso, r.id])
      }
    }
    // Avisos antecipados de compromissos
    const appts = await q(`SELECT * FROM items WHERE type = 'appointment' AND due_at IS NOT NULL AND due_at <= $1 LIMIT 500`, [iso])
    for (const a of appts) {
      const d = J<any>(a.data, {})
      await notify(Number(a.user_id), { type: 'appointment', title: d.title, body: `Às ${d.time}${d.location ? ` · ${d.location}` : ''}`, link: '/agenda?tab=compromissos', ref: `appointment:${a.id}:${a.due_at}` })
      await q('UPDATE items SET due_at = NULL WHERE id = $1', [a.id])
    }
    // Contas que vencem hoje (aviso a partir das 09:00 no fuso do usuário)
    const yesterday = new Date(now.getTime() - 86400_000).toISOString().slice(0, 10)
    const tomorrow = new Date(now.getTime() + 86400_000).toISOString().slice(0, 10)
    const bills = await q(`SELECT i.*, u.settings FROM items i JOIN users u ON u.id = i.user_id
      WHERE i.type = 'bill' AND i.status = 'pending' AND i.day >= $1 AND i.day <= $2`, [yesterday, tomorrow])
    for (const b of bills) {
      const tz = validTz(J<any>(b.settings, {}).timezone)
      if (b.day !== localDate(tz, now) || localTime(tz, now) < '09:00') continue
      const d = J<any>(b.data, {})
      await notify(Number(b.user_id), { type: 'bill', title: `${d.name} vence hoje`, body: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(d.amount), link: '/financeiro?tab=contas', ref: `bill:${b.id}:${b.day}` })
    }
  } catch (e: any) {
    console.error('[scheduler] erro:', e?.message)
  } finally { running = false }
}
export function startScheduler() {
  const t = setInterval(() => void tick(), 30_000)
  t.unref()
  void tick()
}
