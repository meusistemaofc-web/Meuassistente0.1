// Agendador interno (substitui as "Scheduled Functions" da Netlify): dispara lembretes,
// avisos de compromissos e de contas vencendo, gravando na central de notificações.
import { q, J } from './db/index.js'
import { notify } from './lib/notify.js'
import { checkModules } from './modules-scheduler.js'
import { nextOccurrence, zonedToUtc, localDate, localTime, validTz } from './lib/time.js'

let running = false
export async function tick(now = new Date()) {
  if (running) return
  running = true
  try {
    const iso = now.toISOString()
    // Lembretes vencidos
    const due = await q(`SELECT i.*, u.settings FROM items i JOIN users u ON u.id = i.user_id
      WHERE i.type = 'reminder' AND i.status = 'pending' AND i.due_at IS NOT NULL AND i.due_at <= $1 LIMIT 500`, [iso])
    for (const r of due) {
      const d = J<any>(r.data, {})
      const uid = Number(r.user_id)
      await notify(uid, { type: 'reminder', title: d.message, body: d.leadMinutes && !d.snoozedUntil ? `Em ${d.leadMinutes} min` : undefined, link: `/agenda?tab=lembretes&lembrete=${r.id}`, ref: `reminder:${r.id}:${r.due_at}` })
      const next = !d.snoozedUntil && d.recurrence && d.recurrence !== 'none' ? nextOccurrence(d.date, d.recurrence) : null
      if (next) {
        const tz = validTz(J<any>(r.settings, {}).timezone)
        const remindAt = zonedToUtc(next, d.time, tz)
        const dueAt = new Date(new Date(remindAt).getTime() - (d.leadMinutes || 0) * 60_000).toISOString()
        await q('UPDATE items SET day = $1, due_at = $2, data = $3, updated_at = $4 WHERE id = $5', [next, dueAt, JSON.stringify({ ...d, date: next, remindAt, snoozedUntil: null }), iso, r.id])
      } else {
        await q("UPDATE items SET status = 'sent', due_at = NULL, data = $1, updated_at = $2 WHERE id = $3", [JSON.stringify({ ...d, snoozedUntil: null }), iso, r.id])
      }
    }
    // Avisos antecipados de compromissos
    const appts = await q(`SELECT * FROM items WHERE type = 'appointment' AND due_at IS NOT NULL AND due_at <= $1 LIMIT 500`, [iso])
    for (const a of appts) {
      const d = J<any>(a.data, {})
      const tz = validTz(J<any>((await q('SELECT settings FROM users WHERE id = $1', [a.user_id]))[0]?.settings, {}).timezone)
      const start = d.time ? new Date(zonedToUtc(a.day, d.time, tz)).getTime() : null
      const reminders: number[] = Array.isArray(d.reminders) ? d.reminders : d.reminderMinutes > 0 ? [d.reminderMinutes] : []
      const sent: number[] = Array.isArray(d.remindersSent) ? d.remindersSent : []
      // qual aviso venceu agora: o de maior antecedência ainda não enviado cujo horário já chegou
      const dueNow = start ? reminders.filter((m) => !sent.includes(m) && start - m * 60_000 <= now.getTime() + 30_000).sort((x, y) => x - y)[0] : undefined
      const quando = dueNow === undefined ? `Às ${d.time}` : dueNow >= 1440 ? `Amanhã às ${d.time}` : dueNow >= 60 ? `Em ${Math.round(dueNow / 60)} hora${dueNow >= 120 ? 's' : ''} · às ${d.time}` : `Em ${dueNow} min · às ${d.time}`
      if (start === null || start > now.getTime() - 5 * 60_000) await notify(Number(a.user_id), { type: 'appointment', title: d.title, body: `${quando}${d.location ? ` · ${d.location}` : ''}`, link: '/agenda?tab=compromissos', ref: `appointment:${a.id}:${a.due_at}` })
      const nowSent = [...new Set([...sent, ...reminders.filter((m) => start !== null && start - m * 60_000 <= now.getTime() + 30_000)])]
      const pend = start ? reminders.filter((m) => !nowSent.includes(m)).map((m) => start - m * 60_000).filter((t) => t > now.getTime()).sort((x, y) => x - y) : []
      await q('UPDATE items SET due_at = $1, data = $2 WHERE id = $3', [pend.length ? new Date(pend[0]).toISOString() : null, JSON.stringify({ ...d, remindersSent: nowSent }), a.id])
    }
    // Contas que vencem hoje (aviso a partir das 09:00 no fuso do usuário)
    const yesterday = new Date(now.getTime() - 86400_000).toISOString().slice(0, 10)
    const tomorrow = new Date(now.getTime() + 86400_000).toISOString().slice(0, 10)
    const bills = await q(`SELECT i.*, u.settings FROM items i JOIN users u ON u.id = i.user_id
      WHERE i.type = 'bill' AND i.status = 'pending' AND i.day >= $1 AND i.day <= $2`, [yesterday, tomorrow])
    for (const b of bills) {
      const tz = validTz(J<any>(b.settings, {}).timezone)
      if (b.day !== localDate(tz, now) || localTime(tz, now) < '09:00') continue
      const d = J<any>(b.data, {})
      await notify(Number(b.user_id), { type: 'bill', title: `${d.name} vence hoje`, body: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(d.amount), link: '/financeiro?tab=contas', ref: `bill:${b.id}:${b.day}` })
    }
  } catch (e: any) {
    console.error('[scheduler] erro:', e?.message)
    await checkModules(now).catch((e) => console.error('[scheduler] módulos:', e?.message))
  } finally { running = false }
}
export function startScheduler() {
  void fixOldReminders()
  const t = setInterval(() => void tick(), 30_000)
  t.unref()
  void tick()
}

/** Corrige avisos já gerados pela lógica antiga: compromissos futuros com o padrão de 30 min passam a 24 h + 1 h;
 *  lembretes simples pendentes com 10 min de antecedência automática passam a avisar no horário exato. Roda uma vez. */
export async function fixOldReminders() {
  try {
    const { getConfig, setConfig } = await import('./lib/settings.js')
    if ((await getConfig<any>('fix_reminders_v1', null))?.done) return
    let ap = 0, rm = 0
    for (const r of await q("SELECT i.*, u.settings FROM items i JOIN users u ON u.id = i.user_id WHERE i.type = 'appointment' AND i.status = 'scheduled'")) {
      const d = J<any>(r.data, {}), st = J<any>(r.settings, {})
      if (Array.isArray(d.reminders) || !d.time) continue
      if (st.reminderLeadCustom === true) continue
      if (d.reminderMinutes !== undefined && Number(d.reminderMinutes) !== 30) continue
      const start = new Date(zonedToUtc(r.day, d.time, validTz(st.timezone))).getTime(); if (start < Date.now()) continue
      const reminders = [1440, 60], pend = reminders.map((m) => start - m * 60_000).filter((t) => t > Date.now()).sort((a, b) => a - b)
      await q('UPDATE items SET due_at = $1, data = $2 WHERE id = $3', [pend.length ? new Date(pend[0]).toISOString() : null, JSON.stringify({ ...d, reminders, reminderMinutes: 60, remindersSent: [] }), r.id]); ap++
    }
    for (const r of await q("SELECT * FROM items WHERE type = 'reminder' AND status = 'pending'")) {
      const d = J<any>(r.data, {})
      if (Number(d.leadMinutes) !== 10 || !d.remindAt) continue
      await q('UPDATE items SET due_at = $1, data = $2 WHERE id = $3', [d.remindAt, JSON.stringify({ ...d, leadMinutes: 0 }), r.id]); rm++
    }
    await setConfig('fix_reminders_v1', { done: true, ap, rm, at: new Date().toISOString() })
    if (ap || rm) console.log(`[lembretes] corrigidos: ${ap} compromissos (24 h + 1 h) e ${rm} lembretes (sem antecedência)`)
  } catch (e: any) { console.error('[lembretes] correção:', e?.message) }
}
