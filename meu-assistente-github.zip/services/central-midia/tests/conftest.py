"""Sobe a central de verdade (processo uvicorn separado) para os testes de integração."""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

import pytest

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOKEN = "teste-" + "x" * 30


def _porta_livre() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Central:
    def __init__(self, env: dict):
        self.porta = _porta_livre()
        self.dir = tempfile.mkdtemp(prefix="central-teste-")
        e = {**os.environ, "MIDIA_TOKEN": TOKEN, "DIR_TEMP": os.path.join(self.dir, "tmp"), "ARQUIVO_REGISTRO": os.path.join(self.dir, "registro.jsonl"), **env}
        self.proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(self.porta), "--log-level", "warning"],
                                     cwd=RAIZ, env=e, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for _ in range(100):
            try:
                urllib.request.urlopen(self.url("/saude"), timeout=1)
                return
            except Exception:
                time.sleep(0.1)
        raise RuntimeError("a central não subiu")

    def url(self, p: str) -> str:
        return f"http://127.0.0.1:{self.porta}{p}"

    def get(self, p: str, token: str | None = TOKEN):
        req = urllib.request.Request(self.url(p), headers={"Authorization": f"Bearer {token}"} if token else {})
        return self._abrir(req)

    def enviar(self, dados: bytes, nome: str = "", token: str | None = TOKEN, **params):
        q = urllib.parse.urlencode(params)
        cab = {"X-Arquivo-Nome": urllib.parse.quote(nome), "Content-Type": "application/octet-stream", "X-Cliente": "teste"}
        if token:
            cab["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(self.url("/v1/processar" + (f"?{q}" if q else "")), data=dados, headers=cab, method="POST")
        return self._abrir(req)

    @staticmethod
    def _abrir(req):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def registro(self) -> list[dict]:
        try:
            with open(os.path.join(self.dir, "registro.jsonl"), encoding="utf-8") as f:
                return [json.loads(l) for l in f if l.strip()]
        except FileNotFoundError:
            return []

    def parar(self):
        self.proc.terminate()
        try:
            self.proc.wait(10)
        except subprocess.TimeoutExpired:
            self.proc.kill()


@pytest.fixture(scope="session")
def central():
    c = Central({})
    yield c
    c.parar()


@pytest.fixture(scope="session")
def central_restrita():
    """Limites pequenos para testar tamanho, tempo e fila."""
    c = Central({"MAX_BYTES": "300000", "MAX_BYTES_TXT": "1000", "TEMPO_LIMITE_S": "2", "PDF_BLOQUEAR_ATIVO": "true", "MAX_CONCORRENCIA": "1", "MAX_FILA": "0"})
    yield c
    c.parar()
