"""Cardápios de TESTE gerados na hora (nada de cardápios reais de clientes): imagem limpa, "foto" de celular
(perspectiva, inclinação, sombra, desfoque, ruído, JPEG), foto de lado, PDF digital (1 ou 2 colunas, várias páginas)
e PDF escaneado. Cada modelo traz o resultado ESPERADO para conferir a extração."""
from __future__ import annotations

import io

from PIL import Image, ImageDraw, ImageFont

from .gerar import FONTE
from .fotos import fotografar  # noqa: F401  (reexporta para os testes)

NEGRITO = FONTE.replace("DejaVuSans.ttf", "DejaVuSans-Bold.ttf") if FONTE else None

# Linha: "texto" | "#TÍTULO" (negrito) | "nome || preço" (preço alinhado à direita) | "nome .... preço" (pontilhado escrito)
MODELOS: dict[str, dict] = {
    "lanchonete": {
        "colunas": [[
            "#LANCHONETE DO ZÉ", "",
            "#HAMBÚRGUERES",
            "X-Burguer || R$ 22,90", "Pão, hambúrguer 120g, queijo e molho da casa",
            "X-Salada || R$ 25,50", "Pão, hambúrguer, queijo, alface e tomate",
            "X-Bacon || R$ 29,90", "",
            "#ADICIONAIS",
            "Bacon || R$ 5,00", "Ovo || R$ 2,50", "Cheddar || R$ 4,00", "",
            "#BEBIDAS",
            "Refrigerante lata || R$ 6,00",
            "Suco natural   300ml R$ 8,00   500ml R$ 12,00",
            "Água mineral || R$ 3,50", "",
            "Taxa de entrega R$ 5,00",
        ]],
        "esperado": [
            {"nome": "X-Burguer", "categoria": "Hambúrgueres", "preco": 22.90, "descricao": "molho da casa", "adicionais": ["Bacon", "Ovo", "Cheddar"]},
            {"nome": "X-Salada", "categoria": "Hambúrgueres", "preco": 25.50, "descricao": "alface e tomate", "adicionais": ["Bacon", "Ovo", "Cheddar"]},
            {"nome": "X-Bacon", "categoria": "Hambúrgueres", "preco": 29.90, "adicionais": ["Bacon", "Ovo", "Cheddar"]},
            {"nome": "Refrigerante lata", "categoria": "Bebidas", "preco": 6.00, "adicionais": []},
            {"nome": "Suco natural", "categoria": "Bebidas", "variacoes": {"300ml": 8.00, "500ml": 12.00}},
            {"nome": "Água mineral", "categoria": "Bebidas", "preco": 3.50},
        ],
        "adicionais_precos": {"Bacon": 5.00, "Ovo": 2.50, "Cheddar": 4.00},
    },
    "pizzaria": {
        "colunas": [[
            "#PIZZARIA BELLA NAPOLI", "",
            "#PIZZAS SALGADAS          Broto     Média     Grande",
            "Calabresa                 28,00     42,00     55,00", "Calabresa, cebola e azeitona",
            "Marguerita                30,00     45,00     58,00", "Muçarela, tomate e manjericão",
            "Frango com catupiry       32,00     48,00     62,00", "",
            "#PIZZAS DOCES             Broto     Grande",
            "Chocolate                 32,00     60,00",
            "Romeu e Julieta           30,00     58,00",
            "+ Borda de catupiry 8,00",
        ]],
        "esperado": [
            {"nome": "Calabresa", "categoria": "Pizzas salgadas", "variacoes": {"Broto": 28.00, "Média": 42.00, "Grande": 55.00}, "descricao": "cebola e azeitona"},
            {"nome": "Marguerita", "categoria": "Pizzas salgadas", "variacoes": {"Broto": 30.00, "Média": 45.00, "Grande": 58.00}, "descricao": "manjericão"},
            {"nome": "Frango com catupiry", "categoria": "Pizzas salgadas", "variacoes": {"Broto": 32.00, "Média": 48.00, "Grande": 62.00}},
            {"nome": "Chocolate", "categoria": "Pizzas doces", "variacoes": {"Broto": 32.00, "Grande": 60.00}},
            {"nome": "Romeu e Julieta", "categoria": "Pizzas doces", "variacoes": {"Broto": 30.00, "Grande": 58.00}, "adicionais": ["Borda de catupiry"]},
        ],
        "adicionais_precos": {"Borda de catupiry": 8.00},
    },
    "cafeteria_2col": {
        "colunas": [
            ["#CAFÉS", "Expresso || 6,00", "Cappuccino || 9,50", "Café, leite vaporizado e canela", "Latte || 10,00", "Chocolate quente || 11,00"],
            ["#SALGADOS", "Coxinha || 7,50", "Pão de queijo || 5,00", "Empada de frango || 8,00", "Croissant misto || 12,90"],
        ],
        "esperado": [
            {"nome": "Expresso", "categoria": "Cafés", "preco": 6.00},
            {"nome": "Cappuccino", "categoria": "Cafés", "preco": 9.50, "descricao": "leite vaporizado"},
            {"nome": "Latte", "categoria": "Cafés", "preco": 10.00},
            {"nome": "Chocolate quente", "categoria": "Cafés", "preco": 11.00},
            {"nome": "Coxinha", "categoria": "Salgados", "preco": 7.50},
            {"nome": "Pão de queijo", "categoria": "Salgados", "preco": 5.00},
            {"nome": "Empada de frango", "categoria": "Salgados", "preco": 8.00},
            {"nome": "Croissant misto", "categoria": "Salgados", "preco": 12.90},
        ],
    },
    "executivo": {
        "colunas": [[
            "#PRATOS EXECUTIVOS",
            "Frango grelhado", "Arroz, feijão, salada e batata frita", "R$ 32,90", "",
            "Parmegiana de carne", "Arroz, purê de batata e salada", "R$ 39,90", "Obs: serve 1 pessoa", "",
            "#SOBREMESAS",
            "Pudim de leite || 12,00",
            "Mousse de maracujá (esgotado) || 10,00",
        ]],
        "esperado": [
            {"nome": "Frango grelhado", "categoria": "Pratos executivos", "preco": 32.90, "descricao": "batata frita"},
            {"nome": "Parmegiana de carne", "categoria": "Pratos executivos", "preco": 39.90, "descricao": "purê", "observacoes": "serve 1 pessoa"},
            {"nome": "Pudim de leite", "categoria": "Sobremesas", "preco": 12.00},
            {"nome": "Mousse de maracujá", "categoria": "Sobremesas", "preco": 10.00, "disponivel": False},
        ],
    },
    "acai": {
        "colunas": [[
            "#AÇAÍ",
            "Açaí tradicional",
            "300 ml || 14,00", "500 ml || 19,00", "700 ml || 24,00", "",
            "#COMPLEMENTOS",
            "Granola 2,00     Leite em pó 2,50     Paçoca 2,00",
        ]],
        "esperado": [
            {"nome": "Açaí tradicional", "categoria": "Açaí", "variacoes": {"300 ml": 14.00, "500 ml": 19.00, "700 ml": 24.00}, "adicionais": ["Granola", "Leite em pó", "Paçoca"]},
        ],
        "adicionais_precos": {"Granola": 2.00, "Leite em pó": 2.50, "Paçoca": 2.00},
    },
}

TODOS_PRECOS = {round(v, 2) for m in MODELOS.values() for e in m["esperado"] for v in ([e["preco"]] if "preco" in e else list(e.get("variacoes", {}).values()))}
TODOS_PRECOS |= {round(v, 2) for m in MODELOS.values() for v in m.get("adicionais_precos", {}).values()}


def _linha(d: ImageDraw.ImageDraw, x0: int, x1: int, y: int, l: str, f, fb, tinta):
    if l.startswith("#"):
        t = l[1:]
        partes = [p for p in t.split("   ") if p.strip()]
        if len(partes) > 1 and "   " in t:  # título + cabeçalho de tamanhos em colunas
            _colunado(d, x0, y, t, fb, tinta)
        else:
            d.text((x0, y), t, font=fb, fill=tinta)
        return
    if " || " in l:
        nome, preco = l.split(" || ")
        d.text((x0, y), nome, font=f, fill=tinta)
        w = d.textlength(preco, font=f)
        d.text((x1 - w, y), preco, font=f, fill=tinta)
        return
    if "   " in l.strip() and l.count("   ") >= 2:
        _colunado(d, x0, y, l, f, tinta)
        return
    d.text((x0, y), l, font=f, fill=tinta)


def _colunado(d, x0, y, l, f, tinta):
    """Mantém o alinhamento de colunas escrito com espaços (cada caractere ≈ largura média)."""
    cw = d.textlength("0", font=f)
    i = 0
    for parte in [p for p in __import__("re").split(r"(\s{2,})", l)]:
        if not parte.strip():
            i += len(parte)
            continue
        d.text((x0 + i * cw, y), parte, font=f, fill=tinta)
        i += len(parte)


def renderizar(nome: str, largura: int = 1250, escuro: bool = False) -> Image.Image:
    m = MODELOS[nome]
    cols = m["colunas"]
    f = ImageFont.truetype(FONTE, 28)
    fb = ImageFont.truetype(NEGRITO or FONTE, 30)
    fundo, tinta = ((20, 20, 22), (240, 238, 230)) if escuro else ((252, 250, 244), (24, 22, 20))
    if len(cols) > 1:
        largura = max(largura, 1500)
    alt = 90 + 50 * max(len(c) for c in cols)
    im = Image.new("RGB", (largura, alt), fundo)
    d = ImageDraw.Draw(im)
    larg_col = (largura - 60 * (len(cols) + 1)) // len(cols)
    for ci, col in enumerate(cols):
        x0 = 60 + ci * (larg_col + 60)
        y = 50
        for l in col:
            if l:
                _linha(d, x0, x0 + larg_col, y, l, f, fb, tinta)
            y += 50
    return im


def png(nome: str, **kw) -> bytes:
    b = io.BytesIO()
    renderizar(nome, **kw).save(b, "PNG")
    return b.getvalue()


def pdf_digital(nomes: list[str]) -> bytes:
    """PDF com TEXTO (como o exportado por um editor), uma página por modelo; colunas e preços à direita."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas
    pdfmetrics.registerFont(TTFont("DV", FONTE))
    pdfmetrics.registerFont(TTFont("DVB", NEGRITO or FONTE))
    b = io.BytesIO()
    c = canvas.Canvas(b, pagesize=(595, 842))
    for nome in nomes:
        cols = MODELOS[nome]["colunas"]
        larg = (595 - 40 * (len(cols) + 1)) / len(cols)
        for ci, col in enumerate(cols):
            x0, y = 40 + ci * (larg + 40), 800
            for l in col:
                if l.startswith("#"):
                    t = l[1:]
                    if "   " in t:
                        _pdf_colunado(c, x0, y, t, "DVB", 11)
                    else:
                        c.setFont("DVB", 13)
                        c.drawString(x0, y, t)
                elif " || " in l:
                    n, p = l.split(" || ")
                    c.setFont("DV", 11)
                    c.drawString(x0, y, n)
                    c.drawRightString(x0 + larg, y, p)
                elif l.count("   ") >= 2:
                    _pdf_colunado(c, x0, y, l, "DV", 11)
                elif l:
                    c.setFont("DV", 11)
                    c.drawString(x0, y, l)
                y -= 20
        c.showPage()
    c.save()
    return b.getvalue()


def _pdf_colunado(c, x0, y, l, fonte, tam):
    import re
    c.setFont(fonte, tam)
    cw = c.stringWidth("0", fonte, tam)
    i = 0
    for parte in re.split(r"(\s{2,})", l):
        if parte.strip():
            c.drawString(x0 + i * cw, y, parte)
        i += len(parte)


def pdf_escaneado(nomes: list[str], semente: int = 3) -> bytes:
    """PDF só com imagens (cardápio escaneado/fotografado), uma página por modelo."""
    paginas = [Image.open(io.BytesIO(fotografar(renderizar(n), semente=semente + i))).convert("RGB") for i, n in enumerate(nomes)]
    b = io.BytesIO()
    paginas[0].save(b, "PDF", resolution=150, save_all=True, append_images=paginas[1:])
    return b.getvalue()


def foto_borrada(nome: str, semente: int = 5) -> bytes:
    """Foto com uma parte ILEGÍVEL (mancha sobre a metade direita de uma linha de preço): o que não dá para ler
    não pode virar preço inventado."""
    im = renderizar(nome)
    d = ImageDraw.Draw(im)
    w = im.width
    d.rectangle([int(w * 0.80), 50 + 50 * 3 - 4, w - 20, 50 + 50 * 3 + 38], fill=(120, 110, 100))  # preço do X-Burguer coberto
    d.rectangle([60, 50 + 50 * 5 - 4, 230, 50 + 50 * 5 + 38], fill=(150, 140, 130))  # nome do X-Salada coberto
    return fotografar(im, semente=semente)


def _sem(s: str) -> str:
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", (s or "").lower()) if unicodedata.category(c) != "Mn").replace(" ", "")


def conferir(nome: str, itens: list[dict], categoria_continua: str = "") -> list[str]:
    """Compara a extração com o esperado do modelo. Devolve a lista de problemas (vazia = tudo certo)."""
    m = MODELOS[nome]
    erros = []
    por_nome = {_sem(i["nome"]): i for i in itens}
    for e in m["esperado"]:
        it = por_nome.get(_sem(e["nome"]))
        if not it:
            erros.append(f"{nome}: não achou {e['nome']!r} (lidos: {[i['nome'] for i in itens]})")
            continue
        if _sem(it["categoria"]) != _sem(e["categoria"]):
            erros.append(f"{nome}/{e['nome']}: categoria {it['categoria']!r} ≠ {e['categoria']!r}")
        # valor diferente do real só é aceito quando o item veio MARCADO para revisão (leitura duvidosa)
        if "preco" in e and it["preco"] != e["preco"] and not it.get("duvida"):
            erros.append(f"{nome}/{e['nome']}: preço {it['preco']} ≠ {e['preco']}")
        if "variacoes" in e:
            ops = {_sem(o["nome"]): o["preco"] for v in it["variacoes"] for o in v["opcoes"]}
            esp = {_sem(k): v for k, v in e["variacoes"].items()}
            if ops != esp and not (it.get("duvida") and set(ops) == set(esp)):
                erros.append(f"{nome}/{e['nome']}: variações {it['variacoes']} ≠ {e['variacoes']}")
        if "descricao" in e and _sem(e["descricao"]) not in _sem(it["descricao"]):
            erros.append(f"{nome}/{e['nome']}: descrição {it['descricao']!r} sem {e['descricao']!r}")
        if "adicionais" in e:
            ad = {_sem(a["nome"]): a["preco"] for a in it["adicionais"]}
            esp = {_sem(a): m.get("adicionais_precos", {}).get(a) for a in e["adicionais"]}
            if ad != esp:
                erros.append(f"{nome}/{e['nome']}: adicionais {it['adicionais']} ≠ {esp}")
        if "observacoes" in e and _sem(e["observacoes"]) not in _sem(it["observacoes"]):
            erros.append(f"{nome}/{e['nome']}: observações {it['observacoes']!r}")
        if "disponivel" in e and it["disponivel"] != e["disponivel"]:
            erros.append(f"{nome}/{e['nome']}: disponível {it['disponivel']}")
    esperados = {_sem(e["nome"]) for e in m["esperado"]}
    extras = [i["nome"] for i in itens if _sem(i["nome"]) not in esperados]
    if extras:
        erros.append(f"{nome}: itens a mais {extras}")
    return erros
