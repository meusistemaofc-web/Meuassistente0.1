"""Comprovantes "fotografados" para testes: layouts no estilo dos apps de banco (claro e escuro, duas colunas
rótulo/valor, cupom fiscal, boleto) e simulação de câmera de celular (perspectiva, inclinação, sombra, desfoque,
ruído, compressão JPEG, foto de lado). Nenhum dado real: nomes, CNPJs e chaves são fictícios (CNPJ de teste válido)."""
from __future__ import annotations

import io
import random

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .gerar import FONTE

NEGRITO = FONTE.replace("DejaVuSans.ttf", "DejaVuSans-Bold.ttf") if FONTE else None


def _chave_nfce() -> str:
    base = "23261111222333000181650010000123451000123456"[:43]
    soma = sum(int(x) * p for x, p in zip(reversed(base), [2, 3, 4, 5, 6, 7, 8, 9] * 6))
    r = soma % 11
    return base + str(0 if r < 2 else 11 - r)


# cada modelo: linhas (rótulo, valor) ou texto livre; tema; e o que a leitura deve encontrar
MODELOS = {
    "nubank_escuro": {
        "tema": "escuro", "titulo": "Comprovante de transferência",
        "linhas": [("", "Pix enviado"), ("Valor", "R$ 152,30"), ("Data", "14 NOV 2026 - 09:41:23"), ("", ""), ("", "Destino"),
                   ("Nome", "Padaria Pão Quente LTDA"), ("CNPJ", "11.222.333/0001-81"), ("Instituição", "BANCO INTER"), ("", ""),
                   ("", "Origem"), ("Nome", "Ana Clara Souza"), ("Instituição", "NU PAGAMENTOS"), ("", ""), ("ID da transação", "E18236120202611140941s01234567")],
        "esperado": {"valor": 152.30, "data": "2026-11-14", "hora": "09:41", "tipo": "pix", "direcao": "saida", "recebedor": "Padaria Pão Quente LTDA", "pagador": "Ana Clara Souza", "categoria": "alimentacao", "forma": "Pix"},
    },
    "itau_claro": {
        "tema": "claro", "titulo": "Comprovante de pagamento Pix",
        "linhas": [("valor", "R$ 89,90"), ("data da transferência", "03/11/2026"), ("horário", "18:22"), ("recebedor", "Posto Ipiranga Centro"),
                   ("CNPJ", "11.444.777/0001-61"), ("pagador", "Ana Clara Souza"), ("autenticação", "A1B2C3D4E5")],
        "esperado": {"valor": 89.90, "data": "2026-11-03", "hora": "18:22", "tipo": "pix", "direcao": "saida", "recebedor": "Posto Ipiranga Centro", "categoria": "combustivel", "forma": "Pix"},
    },
    "pix_recebido": {
        "tema": "claro", "titulo": "Pix recebido",
        "linhas": [("", "Você recebeu"), ("", "R$ 250,00"), ("De", "João Pereira Lima"), ("Em", "10/11/2026 às 14:05"), ("Para", "Ana Clara Souza")],
        "esperado": {"valor": 250.00, "data": "2026-11-10", "hora": "14:05", "tipo": "pix", "direcao": "entrada", "pagador": "João Pereira Lima", "forma": "Pix"},
    },
    "boleto_pago": {
        "tema": "claro", "titulo": "Comprovante de pagamento de boleto",
        "linhas": [("Beneficiário", "Enel Distribuição Ceará"), ("Valor pago", "R$ 179,55"), ("Data do pagamento", "12/11/2026"),
                   ("", "34191.79001 01043.510047 91020.150008 9 96610000017955")],
        "esperado": {"valor": 179.55, "data": "2026-11-12", "tipo": "boleto", "direcao": "saida", "recebedor": "Enel Distribuição Ceará", "categoria": "casa", "forma": "Boleto"},
    },
    "cupom_nfce": {
        "tema": "cupom", "titulo": "SUPERMERCADO BOM PRECO LTDA",
        "linhas": [("", "CNPJ 11.222.333/0001-81"), ("", "DOCUMENTO AUXILIAR DA NFC-e"), ("ARROZ 5KG", "24,90"), ("FEIJAO 1KG", "8,49"), ("CAFE 500G", "17,90"),
                   ("LEITE 1L x2", "12,18"), ("TOTAL R$", "63,47"), ("Cartão de débito", "63,47"), ("", "Emissão: 15/11/2026 10:12:44"),
                   ("", "Chave de acesso:"), ("", " ".join(_chave_nfce()[i:i + 4] for i in range(0, 44, 4)))],
        "esperado": {"valor": 63.47, "data": "2026-11-15", "hora": "10:12", "tipo": "nota_fiscal", "direcao": "saida", "estabelecimento": "SUPERMERCADO BOM PRECO LTDA", "categoria": "alimentacao", "forma": "Cartão de débito"},
    },
    "sem_data": {
        "tema": "claro", "titulo": "Comprovante",
        "linhas": [("", "Pix enviado"), ("Valor", "R$ 40,00"), ("Para", "Bruno Lima")],
        "esperado": {"valor": 40.00, "data": None, "tipo": "pix", "direcao": "saida", "recebedor": "Bruno Lima", "categoria": None},
    },
    "ambiguo": {
        "tema": "claro", "titulo": "Comprovante",
        "linhas": [("Valor", "R$ 75,00"), ("Data", "08/11/2026"), ("Nome", "Bruno Lima")],
        "esperado": {"valor": 75.00, "data": "2026-11-08", "direcao": "incerta", "categoria": None},
    },
}


def renderizar(nome: str, largura: int = 900) -> Image.Image:
    m = MODELOS[nome]
    tema = m["tema"]
    fundo, tinta, suave = {"escuro": ((17, 17, 20), (240, 240, 245), (150, 150, 160)), "claro": ((255, 255, 255), (25, 25, 30), (110, 110, 120)),
                           "cupom": ((250, 248, 240), (20, 20, 20), (60, 60, 60))}[tema]
    f = ImageFont.truetype(FONTE, 30 if tema != "cupom" else 26)
    fb = ImageFont.truetype(NEGRITO or FONTE, 36 if tema != "cupom" else 28)
    alt = 170 + 52 * len(m["linhas"])
    im = Image.new("RGB", (largura, alt), fundo)
    d = ImageDraw.Draw(im)
    if tema == "escuro":
        d.rectangle([0, 0, largura, 110], fill=(130, 10, 209))
    d.text((48, 36), m["titulo"], font=fb, fill=(255, 255, 255) if tema == "escuro" else tinta)
    y = 140
    for rot, val in m["linhas"]:
        if rot:
            d.text((48, y), rot, font=f, fill=suave)
            w = d.textlength(val, font=f)
            d.text((largura - 48 - w, y), val, font=f, fill=tinta)  # duas colunas: rótulo à esquerda, valor à direita
        elif val:
            d.text((48, y), val, font=fb if val in ("Destino", "Origem") else f, fill=tinta)
        y += 52
    return im


def fotografar(im: Image.Image, semente: int = 1, de_lado: bool = False) -> bytes:
    """Simula uma foto de celular: papel/tela sobre a mesa, perspectiva, inclinação, sombra, desfoque, ruído, JPEG."""
    rnd = random.Random(semente)
    a = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
    h, w = a.shape[:2]
    margem = 120
    tela = np.full((h + 2 * margem, w + 2 * margem, 3), (rnd.randint(90, 140), rnd.randint(80, 120), rnd.randint(60, 100)), np.uint8)  # mesa
    tela[margem:margem + h, margem:margem + w] = a
    H, W = tela.shape[:2]
    j = lambda: rnd.uniform(-0.035, 0.035)
    src = np.float32([[margem, margem], [margem + w, margem], [margem + w, margem + h], [margem, margem + h]])
    dst = np.float32([[margem + j() * w, margem + j() * h], [margem + w + j() * w, margem + j() * h], [margem + w + j() * w, margem + h + j() * h], [margem + j() * w, margem + h + j() * h]])
    tela = cv2.warpPerspective(tela, cv2.getPerspectiveTransform(src, dst), (W, H), borderMode=cv2.BORDER_REPLICATE)
    ang = rnd.uniform(-4, 4)
    tela = cv2.warpAffine(tela, cv2.getRotationMatrix2D((W / 2, H / 2), ang, 1.0), (W, H), borderMode=cv2.BORDER_REPLICATE)
    grad = np.tile(np.linspace(rnd.uniform(0.7, 0.85), 1.05, W, dtype=np.float32), (H, 1))[..., None]  # sombra lateral
    tela = np.clip(tela.astype(np.float32) * grad, 0, 255)
    tela = cv2.GaussianBlur(tela, (0, 0), rnd.uniform(0.6, 1.1))
    tela = np.clip(tela + np.random.default_rng(semente).normal(0, 6, tela.shape), 0, 255).astype(np.uint8)
    if de_lado:
        tela = cv2.rotate(tela, cv2.ROTATE_90_CLOCKWISE)
    ok, buf = cv2.imencode(".jpg", tela, [cv2.IMWRITE_JPEG_QUALITY, 72])
    return buf.tobytes()


def print_tela(nome: str) -> bytes:
    """Captura de tela do celular (sem câmera), em PNG."""
    b = io.BytesIO()
    renderizar(nome, 1080).save(b, "PNG")
    return b.getvalue()
