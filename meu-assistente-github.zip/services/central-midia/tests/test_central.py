"""Testes da Central de Processamento de Arquivos e Mídias (nível 1, sem IA)."""
from __future__ import annotations

import os
import tempfile
import threading

import pytest

from . import gerar as g
from .conftest import TOKEN, Central


# ---------- documentos ----------
def test_pdf_digital_extrai_texto_metadados_e_comprovante(central):
    st, r = central.enviar(g.pdf_texto(g.COMPROVANTE), "comprovante.pdf")
    assert st == 200 and r["ok"] and r["nivel"] == 1
    assert r["arquivo"]["familia"] == "pdf" and len(r["arquivo"]["sha256"]) == 64
    assert "Pix enviado" in r["texto"] and "152,30" in r["texto"]
    assert r["metadados"]["paginas"] == 1 and r["ocr"]["usado"] is False
    c = r["comprovante"]
    assert c["tipo"] == "pix" and c["direcao"] == "saida" and c["valor"] == 152.30 and c["data"] == "2026-11-14" and c["hora"] == "09:41"
    assert c["pix"]["id_transacao"].startswith("E18236120") and {"tipo": "cnpj", "numero": "11.222.333/0001-81"} in c["documentos"]
    assert "Nubank" in c["instituicoes"]


def test_pdf_escaneado_usa_ocr(central):
    st, r = central.enviar(g.pdf_escaneado(["Recibo de pagamento", "Valor total R$ 89,90", "Data 03/11/2026"]), "scan.pdf")
    assert st == 200 and r["ocr"]["usado"] is True and r["paginas"][0]["ocr"] is True
    assert "89,90" in r["texto"] and r["comprovante"]["valor"] == 89.90
    assert any("ocr_aplicado" in a for a in r["avisos"])


def test_pdf_sem_ocr_quando_pedido(central):
    st, r = central.enviar(g.pdf_escaneado(["Texto so na imagem"]), "scan.pdf", ocr="nunca")
    assert st == 200 and r["ocr"]["usado"] is False and r["texto"] == ""


def test_docx_texto_titulos_tabelas_e_propriedades(central):
    st, r = central.enviar(g.docx(), "proposta.docx")
    assert st == 200 and r["arquivo"]["familia"] == "docx"
    assert r["texto"].startswith("# Proposta comercial") and "R$ 1.250,00" in r["texto"]
    assert r["tabelas"][0]["linhas"] == [["Item", "Preço"], ["Plano Loja", "99,00"]]
    assert r["metadados"]["titulo"] == "Contrato de teste" and r["metadados"]["autor"] == "Central"


def test_xlsx_abas_valores_e_datas(central):
    st, r = central.enviar(g.xlsx(), "vendas.xlsx")
    assert st == 200 and r["arquivo"]["familia"] == "xlsx"
    vendas = r["tabelas"][0]
    assert vendas["nome"] == "Vendas" and vendas["linhas"][1] == ["Brigadeiro", "12", "2.5", "2026-11-14T00:00:00"]
    assert r["metadados"]["abas"] == ["Vendas", "Resumo"] and "Bolo de pote" in r["texto"]


def test_csv_latin1_com_ponto_e_virgula(central):
    dados = "nome;cidade;valor\nJoão;Fortaleza;10,50\nMárcia;São Luís;7,00\n".encode("cp1252")
    st, r = central.enviar(dados, "clientes.csv")
    assert st == 200 and r["arquivo"]["familia"] == "csv"
    assert r["metadados"]["separador"] == "ponto e vírgula" and r["metadados"]["codificacao"] == "windows-1252"
    assert r["tabelas"][0]["linhas"][2] == ["Márcia", "São Luís", "7,00"]


def test_txt_utf8(central):
    st, r = central.enviar("Lista de compras\n- açúcar\n- café\n".encode(), "lista.txt")
    assert st == 200 and r["arquivo"]["familia"] == "txt" and "açúcar" in r["texto"] and r["metadados"]["codificacao"] == "utf-8"


# ---------- imagens ----------
def test_ocr_de_comprovante_fotografado(central):
    st, r = central.enviar(g.imagem_texto(g.COMPROVANTE[:5]), "foto.jpg")
    assert st == 200 and r["arquivo"]["formato"] == "jpeg" and r["ocr"]["usado"] and r["ocr"]["confianca"] > 0.6
    assert "Pix enviado" in r["texto"]
    c = r["comprovante"]
    assert c["valor"] == 152.30 and c["data"] == "2026-11-14" and c["tipo"] == "pix" and c["direcao"] == "saida"


@pytest.mark.parametrize("fmt,ext", [("PNG", "png"), ("WEBP", "webp")])
def test_png_e_webp(central, fmt, ext):
    st, r = central.enviar(g.imagem_texto(["Total R$ 45,00"], fmt), "img." + ext)
    assert st == 200 and r["arquivo"]["formato"] == ext and "45,00" in r["texto"]
    assert r["metadados"]["largura"] == 1100


def test_qrcode_pix_interpretado_e_crc_conferido(central):
    pix = g.pix_copia_e_cola()
    st, r = central.enviar(g.qrcode_png(pix), "qr.png", ocr="nunca")
    assert st == 200
    qr = [c for c in r["codigos"] if c["tipo"] == "qrcode"]
    assert qr and qr[0]["conteudo"] == pix and qr[0]["uso"] == "pix_copia_e_cola"
    p = qr[0]["pix"]
    assert p["crc_valido"] and p["chave"] == "contato@padariapao.com.br" and p["valor"] == 152.30 and p["recebedor"] == "PADARIA PAO QUENTE" and p["txid"] == "PEDIDO123"
    assert r["comprovante"]["valor"] == 152.30 and r["comprovante"]["tipo"] == "pix"


def test_qrcode_pix_adulterado_crc_invalido(central):
    pix = g.pix_copia_e_cola()
    adulterado = pix.replace("152.30", "952.30")  # CRC antigo
    st, r = central.enviar(g.qrcode_png(adulterado), "qr.png", ocr="nunca")
    assert st == 200 and r["codigos"][0]["pix"]["crc_valido"] is False


def test_qrcode_link(central):
    st, r = central.enviar(g.qrcode_png("https://meuassistente.chat/doceria-da-lu"), "qr.png", ocr="nunca")
    assert st == 200 and r["codigos"][0]["conteudo"] == "https://meuassistente.chat/doceria-da-lu" and r["codigos"][0]["uso"] == "link"


def test_codigo_de_barras_ean13(central):
    png, cod = g.ean13_png("789100031550")
    st, r = central.enviar(png, "barras.png", ocr="nunca")
    assert st == 200
    barras = [c for c in r["codigos"] if c["tipo"] == "codigo_de_barras"]
    assert barras and barras[0]["conteudo"] == cod and barras[0]["uso"] == "produto_ean"


def test_boleto_linha_digitavel_validada(central):
    from app import comprovante as c
    livre = "1790001043510049102015000"
    sem = "3419" + "9661" + "0000017955" + livre
    barras = sem[:4] + str(c._mod11_boleto(sem)) + sem[4:]
    f1, f2, f3 = barras[0:4] + barras[19:24], barras[24:34], barras[34:44]
    linha = f"{f1[:5]}.{f1[5:]}{c._mod10(f1)} {f2[:5]}.{f2[5:]}{c._mod10(f2)} {f3[:5]}.{f3[5:]}{c._mod10(f3)} {barras[4]} {barras[5:19]}"
    st, r = central.enviar(g.pdf_texto(["Boleto bancario - Banco Itau", "Linha digitavel:", linha, "Pagador: Teste"]), "boleto.pdf")
    b = r["comprovante"]["boleto"]
    assert st == 200 and r["comprovante"]["tipo"] == "boleto" and b["valido"] and b["valor"] == 179.55 and b["banco"] == "Itaú" and b["vencimento"] == "2024-03-20"
    errado = linha[:-1] + ("6" if linha[-1] != "6" else "7")
    st, r = central.enviar(g.pdf_texto(["Boleto", "Linha digitavel:", errado]), "boleto.pdf")
    assert r["comprovante"]["boleto"]["valido"] is False


# ---------- áudio e vídeo ----------
def test_audio_metadados(central):
    with tempfile.TemporaryDirectory() as d:
        dados = g.ffmpeg(["-f", "lavfi", "-i", "sine=frequency=440:duration=2", "-metadata", "title=Recado"], os.path.join(d, "a.mp3"))
    st, r = central.enviar(dados, "recado.mp3")
    assert st == 200 and r["arquivo"]["familia"] == "audio" and 1.8 < r["metadados"]["duracao_s"] < 2.3
    assert r["metadados"]["titulo"] == "Recado" and r["metadados"]["audio"]["codec"] == "mp3"


def test_audio_transcricao_sem_whisper_avisa_sem_quebrar(central):
    with tempfile.TemporaryDirectory() as d:
        dados = g.ffmpeg(["-f", "lavfi", "-i", "sine=duration=1"], os.path.join(d, "a.ogg"))
    st, r = central.enviar(dados, "voz.ogg", transcrever="1")
    assert st == 200 and any("transcricao_indisponivel" in a for a in r["avisos"])


def test_video_metadados(central):
    with tempfile.TemporaryDirectory() as d:
        dados = g.ffmpeg(["-f", "lavfi", "-i", "testsrc=duration=2:size=320x240:rate=15", "-f", "lavfi", "-i", "sine=duration=2", "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac"], os.path.join(d, "v.mp4"))
    st, r = central.enviar(dados, "video.mp4")
    v = r["metadados"]
    assert st == 200 and r["arquivo"]["familia"] == "video" and v["video"]["largura"] == 320 and v["video"]["codec"] == "h264" and v["trilhas_audio"] == 1


# ---------- inválidos e segurança ----------
@pytest.mark.parametrize("dados,nome,codigo,status", [
    (b"MZ\x90\x00" + b"\x00" * 200, "nota.pdf", "executavel", 415),
    (b"\x7fELF\x02\x01\x01" + b"\x00" * 200, "foto.jpg", "executavel", 415),
    (b"#!/bin/sh\nrm -rf /\n", "lista.txt", "executavel", 415),
    (b"", "vazio.pdf", "vazio", 400),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 600, "antigo.doc", "formato_antigo_nao_suportado", 415),
    (b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>', "img.svg", "formato_nao_suportado", 415),
    (b"PK\x03\x04" + b"\x00" * 100, "doc.docx", "arquivo_corrompido", 415),
])
def test_arquivos_invalidos_recusados(central, dados, nome, codigo, status):
    st, r = central.enviar(dados, nome)
    assert st == status and r["ok"] is False and r["erro"]["codigo"] == codigo


def test_pdf_corrompido(central):
    st, r = central.enviar(b"%PDF-1.4\n1 0 obj << /Type /Catalog >> lixo sem xref", "quebrado.pdf")
    assert st == 422 and r["erro"]["codigo"] == "arquivo_corrompido"


def test_imagem_corrompida(central):
    st, r = central.enviar(b"\x89PNG\r\n\x1a\n" + b"\x00" * 300, "foto.png")
    assert st == 422 and r["erro"]["codigo"] == "arquivo_corrompido"


def test_extensao_mentirosa_processa_pelo_conteudo_e_avisa(central):
    st, r = central.enviar(g.pdf_texto(["Ola"]), "foto.jpg")
    assert st == 200 and r["arquivo"]["familia"] == "pdf" and any("extensao_divergente" in a for a in r["avisos"])


def test_docx_xxe_nao_vaza_arquivos_do_servidor(central):
    st, r = central.enviar(g.docx_xxe(), "xxe.docx")
    assert "root:" not in str(r)
    assert st in (200, 422)


def test_zip_bomba_recusado(central):
    st, r = central.enviar(g.docx_bomba(), "bomba.docx")
    assert st == 413 and r["erro"]["codigo"] in ("zip_bomba", "zip_grande_demais")


def test_imagem_bomba_recusada(central):
    st, r = central.enviar(g.png_bomba(), "bomba.png")
    assert st == 413 and r["erro"]["codigo"] == "imagem_grande_demais"


def test_pdf_com_javascript_avisado_e_nunca_executado(central):
    st, r = central.enviar(g.pdf_com_javascript(), "acao.pdf")
    assert st == 200 and any("pdf_conteudo_ativo" in a and "javascript" in a for a in r["avisos"])


def test_pdf_com_javascript_bloqueado_pela_politica(central_restrita):
    st, r = central_restrita.enviar(g.pdf_com_javascript(), "acao.pdf")
    assert st == 415 and r["erro"]["codigo"] == "pdf_conteudo_ativo"


def test_nome_com_caminho_nao_vira_caminho(central):
    st, r = central.enviar(b"conteudo simples", "../../etc/passwd.txt")
    assert st == 200 and r["arquivo"]["nome"] == "passwd.txt"


def test_nada_fica_no_disco(central):
    central.enviar(g.pdf_texto(["temporario"]), "t.pdf")
    tmp = os.path.join(central.dir, "tmp")
    assert os.listdir(tmp) == []


# ---------- limites ----------
def test_limite_de_tamanho_geral(central_restrita):
    st, r = central_restrita.enviar(b"a" * 400000, "grande.txt")
    assert st == 413 and r["erro"]["codigo"] == "arquivo_grande_demais"


def test_limite_de_tamanho_por_tipo(central_restrita):
    st, r = central_restrita.enviar(b"a" * 2000, "medio.txt")
    assert st == 413 and "txt" in r["erro"]["mensagem"]


def test_limite_de_tempo():
    c = Central({"TEMPO_LIMITE_S": "1"})
    try:
        linhas = ["Linha de texto numero %d para o OCR demorar" % i for i in range(60)]
        st, r = c.enviar(g.imagem_texto(linhas, "JPEG", 2400), "longo.jpg")
        assert st == 504 and r["erro"]["codigo"] == "tempo_excedido"
        assert os.listdir(os.path.join(c.dir, "tmp")) == []  # nada sobra mesmo quando o processo é interrompido
        st, r = c.enviar(b"ainda responde", "a.txt")  # a API continua viva depois de matar o trabalho
        assert st == 200
    finally:
        c.parar()


def test_fila_cheia_responde_429(central_restrita):
    linhas = ["Linha %d" % i for i in range(40)]
    img = g.imagem_texto(linhas, "JPEG", 1200)
    resultados = []
    ts = [threading.Thread(target=lambda: resultados.append(central_restrita.enviar(img, "x.png")[0])) for _ in range(4)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert 429 in resultados


# ---------- acesso, registro e independência ----------
def test_sem_token_ou_token_errado(central):
    assert central.enviar(b"oi", "a.txt", token=None)[0] == 401
    assert central.enviar(b"oi", "a.txt", token="errado")[0] == 401
    assert central.get("/v1/capacidades", token="errado")[0] == 401


def test_saude_sem_autenticacao_e_sem_detalhes(central):
    st, r = central.get("/saude", token=None)
    assert st == 200 and r == {"ok": True, "servico": "central-midia", "versao": r["versao"], "ativa": True}


def test_capacidades_lista_ferramentas_reais(central):
    st, r = central.get("/v1/capacidades")
    assert st == 200 and set(r["formatos"]) == {"pdf", "docx", "xlsx", "csv", "txt", "imagem", "audio", "video"}
    f = r["ferramentas"]
    assert f["tesseract"].startswith("tesseract") and f["opencv"] and f["pdftotext"] and f["ffprobe"]
    assert r["nivel2"]["ativo"] is False and r["nivel2"]["motivo"] == "nivel2_desligado"


def test_registro_sem_conteudo(central):
    central.enviar(g.pdf_texto(["SEGREDO-DO-CLIENTE-123"]), "privado.pdf")
    regs = central.registro()
    assert regs and all("SEGREDO" not in str(x) and "privado" not in str(x) for x in regs)
    ult = regs[-1]
    assert ult["status"] == "ok" and ult["familia"] == "pdf" and len(ult["sha256"]) == 64 and ult["cliente"] == "teste"
    st, est = central.get("/v1/estatisticas")
    assert st == 200 and est["total"] >= 1


def test_nivel2_so_quando_pedido_e_sem_ia_configurada_nao_quebra(central):
    st, r = central.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf", interpretar="1")
    assert st == 200 and r["nivel"] == 1 and r["nivel2"] == {"usado": False, "motivo": "nivel2_desligado"}
    st, r = central.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf")
    assert "nivel2" not in r


def test_central_desativada_responde_503():
    c = Central({"CENTRAL_ATIVA": "false"})
    try:
        assert c.enviar(b"oi", "a.txt")[0] == 503
        assert c.get("/saude", token=None)[1]["ativa"] is False
    finally:
        c.parar()


def test_token_curto_ou_ausente_recusa_tudo():
    c = Central({"MIDIA_TOKEN": "curto"})
    try:
        st, r = c.enviar(b"oi", "a.txt", token="curto")
        assert st == 503 and r["erro"]["codigo"] == "token_nao_configurado"
    finally:
        c.parar()


# ---------- nível 2 (IA opcional) com um Ollama de teste ----------
def _ollama_falso(resposta: dict | None):
    import http.server
    import json as js
    chamadas = []

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            corpo = js.loads(self.rfile.read(int(self.headers["Content-Length"])))
            chamadas.append(corpo)
            if resposta is None:
                self.send_response(500)
                self.end_headers()
                return
            b = js.dumps({"response": js.dumps(resposta)}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, chamadas


def test_nivel2_ollama_usado_so_quando_pedido_e_recebe_so_texto():
    srv, chamadas = _ollama_falso({"resumo": "Pix de R$ 152,30 para a padaria.", "tipo_documento": "comprovante_pix", "campos": {"valor": 152.3}, "pendencias": []})
    c = Central({"NIVEL2_ATIVO": "true", "NIVEL2_PROVEDOR": "ollama", "OLLAMA_URL": f"http://127.0.0.1:{srv.server_port}", "OLLAMA_MODELO": "llama3.2:3b"})
    try:
        st, r = c.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf")  # sem pedir: nada de IA
        assert st == 200 and r["nivel"] == 1 and "nivel2" not in r and chamadas == []
        st, r = c.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf", interpretar="auto")  # nível 1 já achou tudo: IA não é chamada
        assert "nivel2" not in r and chamadas == []
        st, r = c.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf", interpretar="1")
        assert st == 200 and r["nivel"] == 2 and r["nivel2"]["usado"] and r["nivel2"]["provedor"] == "ollama"
        assert r["nivel2"]["resultado"]["tipo_documento"] == "comprovante_pix" and r["comprovante"]["valor"] == 152.30
        assert len(chamadas) == 1 and chamadas[0]["model"] == "llama3.2:3b" and "Pix enviado" in chamadas[0]["prompt"] and "base64" not in chamadas[0]["prompt"]
        st, r = c.enviar(g.pdf_texto(["Comprovante de pagamento", "Pix", "sem valor legivel"]), "c.pdf", interpretar="auto")  # faltou o essencial
        assert r["nivel"] == 2 and len(chamadas) == 2
    finally:
        c.parar()
        srv.shutdown()


def test_nivel2_com_falha_da_ia_mantem_nivel1():
    srv, _ = _ollama_falso(None)
    c = Central({"NIVEL2_ATIVO": "true", "OLLAMA_URL": f"http://127.0.0.1:{srv.server_port}"})
    try:
        st, r = c.enviar(g.pdf_texto(g.COMPROVANTE), "c.pdf", interpretar="1")
        assert st == 200 and r["nivel"] == 1 and r["nivel2"]["usado"] is False and r["nivel2"]["motivo"] == "falha_ia" and r["comprovante"]["valor"] == 152.30
    finally:
        c.parar()
        srv.shutdown()
