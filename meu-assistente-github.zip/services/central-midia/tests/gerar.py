"""Gera os arquivos de teste na hora (nada de amostras reais de clientes no repositório)."""
from __future__ import annotations

import io
import os
import subprocess
import zipfile

FONTE = next((f for f in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans.ttf") if os.path.exists(f)), None)

COMPROVANTE = ["Comprovante de transferência", "Pix enviado", "Valor: R$ 152,30", "Data: 14/11/2026 às 09:41",
               "Para: Padaria Pão Quente LTDA", "CNPJ: 11.222.333/0001-81", "Instituição: Nubank",
               "ID da transação: E18236120202611140941s0123456789"]


def pdf_texto(linhas: list[str]) -> bytes:
    """PDF digital mínimo (texto embutido, fonte Helvetica, WinAnsi)."""
    def esc(s: str) -> str:
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    conteudo = "BT /F1 14 Tf 60 780 Td 18 TL " + " ".join(f"({esc(l)}) Tj T*" for l in linhas) + " ET"
    stream = conteudo.encode("cp1252")
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream"]
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    pos = []
    for i, o in enumerate(objs, 1):
        pos.append(out.tell())
        out.write(f"{i} 0 obj\n".encode() + o + b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode() + b"".join(f"{p:010d} 00000 n \n".encode() for p in pos))
    out.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    return out.getvalue()


def pdf_com_javascript() -> bytes:
    base = pdf_texto(["Documento com acao"])
    return base.replace(b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Catalog /Pages 2 0 R /OpenAction << /S /JavaScript /JS (app.alert(1)) >> >>")


def imagem_texto(linhas: list[str], formato: str = "JPEG", largura: int = 1100) -> bytes:
    from PIL import Image, ImageDraw, ImageFont
    fonte = ImageFont.truetype(FONTE, 34) if FONTE else ImageFont.load_default()
    im = Image.new("RGB", (largura, 70 + 56 * len(linhas)), "white")
    d = ImageDraw.Draw(im)
    for i, l in enumerate(linhas):
        d.text((40, 30 + i * 56), l, fill="black", font=fonte)
    b = io.BytesIO()
    im.save(b, formato, **({"quality": 92} if formato == "JPEG" else {}))
    return b.getvalue()


def pdf_escaneado(linhas: list[str]) -> bytes:
    from PIL import Image
    im = Image.open(io.BytesIO(imagem_texto(linhas, "PNG"))).convert("RGB")
    b = io.BytesIO()
    im.save(b, "PDF", resolution=150)
    return b.getvalue()


def _crc16(s: str) -> str:
    crc = 0xFFFF
    for b in s.encode():
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else crc << 1
            crc &= 0xFFFF
    return f"{crc:04X}"


def pix_copia_e_cola(chave="contato@padariapao.com.br", valor="152.30", nome="PADARIA PAO QUENTE", cidade="FORTALEZA", txid="PEDIDO123") -> str:
    def f(tag, v):
        return f"{tag}{len(v):02d}{v}"
    conta = f("00", "br.gov.bcb.pix") + f("01", chave)
    s = f("00", "01") + f("26", conta) + f("52", "0000") + f("53", "986") + f("54", valor) + f("58", "BR") + f("59", nome) + f("60", cidade) + f("62", f("05", txid)) + "6304"
    return s + _crc16(s)


def qrcode_png(conteudo: str, escala: int = 8) -> bytes:
    import cv2
    enc = cv2.QRCodeEncoder.create()
    m = enc.encode(conteudo)
    m = cv2.resize(m, None, fx=escala, fy=escala, interpolation=cv2.INTER_NEAREST)
    m = cv2.copyMakeBorder(m, 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=255)
    ok, buf = cv2.imencode(".png", m)
    return buf.tobytes()


_L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"]
_G = ["0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111"]
_R = ["1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100"]
_PAR = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"]


def ean13_png(doze: str) -> tuple[bytes, str]:
    from PIL import Image, ImageDraw
    soma = sum(int(d) * (3 if i % 2 else 1) for i, d in enumerate(doze))
    cod = doze + str((10 - soma % 10) % 10)
    bits = "101" + "".join((_L if p == "L" else _G)[int(d)] for p, d in zip(_PAR[int(cod[0])], cod[1:7])) + "01010" + "".join(_R[int(d)] for d in cod[7:]) + "101"
    m = 4
    im = Image.new("L", ((len(bits) + 22) * m, 240), 255)
    d = ImageDraw.Draw(im)
    for i, b in enumerate(bits):
        if b == "1":
            d.rectangle([(11 + i) * m, 20, (12 + i) * m - 1, 220], fill=0)
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue(), cod


def docx() -> bytes:
    import docx as pydocx
    d = pydocx.Document()
    d.core_properties.title = "Contrato de teste"
    d.core_properties.author = "Central"
    d.add_heading("Proposta comercial", level=1)
    d.add_paragraph("Valor mensal: R$ 1.250,00 com vencimento em 10/12/2026.")
    t = d.add_table(rows=2, cols=2)
    t.cell(0, 0).text, t.cell(0, 1).text = "Item", "Preço"
    t.cell(1, 0).text, t.cell(1, 1).text = "Plano Loja", "99,00"
    b = io.BytesIO()
    d.save(b)
    return b.getvalue()


def docx_xxe() -> bytes:
    """DOCX com entidade externa apontando para /etc/passwd (ataque XXE): o conteúdo do sistema NÃO pode vazar."""
    original = zipfile.ZipFile(io.BytesIO(docx()))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for item in original.infolist():
            dados = original.read(item.filename)
            if item.filename == "word/document.xml":
                dados = dados.replace(b"<?xml version='1.0' encoding='UTF-8' standalone='yes'?>", b"").replace(b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', b"")
                dados = b'<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE w [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>' + dados.replace(b"Proposta comercial", b"Proposta &xxe;")
            z.writestr(item, dados)
    return out.getvalue()


def docx_bomba() -> bytes:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml", "<w:document/>")
        z.writestr("word/media/bomba.bin", b"\x00" * (220 * 1024 * 1024))
    return out.getvalue()


def xlsx() -> bytes:
    import datetime as dt
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Vendas"
    ws.append(["Produto", "Qtd", "Preço", "Data"])
    ws.append(["Brigadeiro", 12, 2.5, dt.date(2026, 11, 14)])
    ws.append(["Bolo de pote", 3, 12.9, dt.date(2026, 11, 15)])
    ws2 = wb.create_sheet("Resumo")
    ws2.append(["Total", "=B2*C2+B3*C3"])
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def png_bomba() -> bytes:
    """PNG pequeno no disco que declara 30.000 x 30.000 pixels (900 milhões): precisa ser recusado sem decodificar."""
    from PIL import Image
    im = Image.new("1", (30000, 30000), 1)
    b = io.BytesIO()
    im.save(b, "PNG", optimize=True)
    return b.getvalue()


def ffmpeg(args: list[str], destino: str) -> bytes:
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", *args, destino], check=True, timeout=60)
    with open(destino, "rb") as f:
        return f.read()
