# Central de Processamento de Arquivos e Mídias

Serviço independente do Meu Assistente: PDF, DOCX, XLSX, CSV, TXT, imagens (OCR), QR Code/código de barras (Pix e
boletos), áudio e vídeo (metadados e transcrição pelo Whisper local) — sem IA obrigatória.

- Documentação completa (auditoria, API, segurança, instalação e rollback): `docs/CENTRAL_MIDIA.md`
- Testes: `python3 -m pytest -q tests` (aqui) ou `docker build --target teste .` (dentro da imagem)
- Operação na VPS: `sudo bash deploy/scripts/central-midia.sh verificar|testar|instalar|estado|desativar|remover`
