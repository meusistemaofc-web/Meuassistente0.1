"""Configuração por variáveis de ambiente. Tudo tem um padrão seguro; nada depende de serviço pago."""
import os


def _int(nome: str, padrao: int) -> int:
    try:
        return max(0, int(os.environ.get(nome, padrao)))
    except ValueError:
        return padrao


def _bool(nome: str, padrao: bool) -> bool:
    v = os.environ.get(nome)
    return padrao if v is None else v.strip().lower() in ("1", "true", "sim", "yes", "on")


MB = 1024 * 1024


class Config:
    def __init__(self) -> None:
        # liga/desliga geral: desligada, a API responde 503 e o Meu Assistente segue sem a central
        self.ativa = _bool("CENTRAL_ATIVA", True)
        # token obrigatório nas rotas /v1 (sem token configurado, a central recusa tudo: "fail closed")
        self.token = os.environ.get("MIDIA_TOKEN", "").strip()
        self.porta = _int("PORTA", 8095)
        self.dir_temp = os.environ.get("DIR_TEMP", "/tmp/central-midia")
        # limites de tamanho (bytes)
        self.max_bytes = _int("MAX_BYTES", 25 * MB)
        self.max_por_tipo = {
            "pdf": _int("MAX_BYTES_PDF", 20 * MB),
            "docx": _int("MAX_BYTES_DOCX", 15 * MB),
            "xlsx": _int("MAX_BYTES_XLSX", 15 * MB),
            "csv": _int("MAX_BYTES_CSV", 5 * MB),
            "txt": _int("MAX_BYTES_TXT", 5 * MB),
            "imagem": _int("MAX_BYTES_IMAGEM", 15 * MB),
            "audio": _int("MAX_BYTES_AUDIO", 25 * MB),
            "video": _int("MAX_BYTES_VIDEO", 25 * MB),
        }
        # limites de processamento
        self.tempo_limite_s = _int("TEMPO_LIMITE_S", 60)
        self.memoria_trabalho_mb = _int("MEMORIA_TRABALHO_MB", 768)
        self.max_concorrencia = max(1, _int("MAX_CONCORRENCIA", 2))
        self.max_fila = _int("MAX_FILA", 8)
        self.max_paginas_pdf = _int("MAX_PAGINAS_PDF", 100)
        self.max_paginas_ocr = _int("MAX_PAGINAS_OCR", 10)
        self.max_pixels = _int("MAX_PIXELS", 40_000_000)
        self.max_linhas_planilha = _int("MAX_LINHAS_PLANILHA", 20_000)
        self.max_duracao_midia_s = _int("MAX_DURACAO_MIDIA_S", 15 * 60)
        self.max_texto = _int("MAX_TEXTO", 2_000_000)
        # arquivos compactados por dentro (DOCX/XLSX): proteção contra "zip bomb"
        self.zip_max_entradas = _int("ZIP_MAX_ENTRADAS", 3000)
        self.zip_max_descompactado = _int("ZIP_MAX_DESCOMPACTADO", 150 * MB)
        self.zip_max_razao = _int("ZIP_MAX_RAZAO", 200)
        # política para PDF com conteúdo ativo (JavaScript, ações de abrir programas, anexos)
        self.pdf_bloquear_ativo = _bool("PDF_BLOQUEAR_ATIVO", False)
        self.idioma_ocr = os.environ.get("IDIOMA_OCR", "por+eng")
        # Nível 2 (opcional): interpretação com IA local (Ollama) ou API compatível com OpenAI
        self.nivel2_ativo = _bool("NIVEL2_ATIVO", False)
        self.nivel2_provedor = os.environ.get("NIVEL2_PROVEDOR", "ollama").strip().lower()
        self.ollama_url = os.environ.get("OLLAMA_URL", "").rstrip("/")
        self.ollama_modelo = os.environ.get("OLLAMA_MODELO", "llama3.2:3b")
        self.ia_url = os.environ.get("IA_URL", "").rstrip("/")
        self.ia_chave = os.environ.get("IA_CHAVE", "")
        self.ia_modelo = os.environ.get("IA_MODELO", "")
        self.nivel2_tempo_s = _int("NIVEL2_TEMPO_S", 45)
        # transcrição: reaproveita o Whisper local do Meu Assistente (não instala outro)
        self.whisper_url = os.environ.get("WHISPER_URL", "").rstrip("/")
        self.whisper_tempo_s = _int("WHISPER_TEMPO_S", 120)
        # registro de operações
        self.arquivo_registro = os.environ.get("ARQUIVO_REGISTRO", "")


def carregar() -> Config:
    return Config()
