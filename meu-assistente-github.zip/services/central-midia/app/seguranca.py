"""Proteções contra arquivos maliciosos ou abusivos, aplicadas antes de qualquer leitura do conteúdo."""
from __future__ import annotations

import re
import unicodedata
import zipfile

from .config import Config


class Recusa(Exception):
    """Arquivo recusado por segurança ou por limite. `codigo` é estável (usado pelo Meu Assistente)."""

    def __init__(self, codigo: str, mensagem: str, status: int = 400):
        super().__init__(mensagem)
        self.codigo = codigo
        self.mensagem = mensagem
        self.status = status


def nome_seguro(nome: str) -> str:
    """Só o nome (sem pastas), sem caracteres de controle, até 120 caracteres. Nunca é usado como caminho no disco."""
    nome = unicodedata.normalize("NFC", str(nome or ""))
    nome = nome.replace("\\", "/").split("/")[-1]
    nome = re.sub(r"[\x00-\x1f\x7f]", "", nome).strip().strip(".")
    return (nome or "arquivo")[:120]


def checar_zip(caminho: str, cfg: Config) -> list[str]:
    """DOCX/XLSX são ZIP: limita quantidade de entradas, tamanho descompactado e taxa de compressão (zip bomb)."""
    avisos: list[str] = []
    try:
        with zipfile.ZipFile(caminho) as z:
            infos = z.infolist()
    except zipfile.BadZipFile as e:
        raise Recusa("arquivo_corrompido", "O arquivo está corrompido (ZIP inválido).", 422) from e
    if len(infos) > cfg.zip_max_entradas:
        raise Recusa("zip_muitas_entradas", f"O documento tem partes internas demais ({len(infos)}).", 413)
    total = 0
    for i in infos:
        n = i.filename
        if n.startswith("/") or ".." in n.split("/") or "\\" in n:
            raise Recusa("zip_caminho_invalido", "O documento tem caminhos internos inválidos.", 400)
        if i.flag_bits & 0x1:
            raise Recusa("documento_protegido", "O documento está protegido por senha.", 422)
        total += i.file_size
        if i.compress_size > 0 and i.file_size / i.compress_size > cfg.zip_max_razao and i.file_size > 1024 * 1024:
            raise Recusa("zip_bomba", "O documento tem compressão suspeita (possível arquivo-bomba).", 413)
        if total > cfg.zip_max_descompactado:
            raise Recusa("zip_grande_demais", "O documento descompactado passa do limite permitido.", 413)
    return avisos


PDF_ATIVO = {
    b"/JavaScript": "javascript", b"/JS": "javascript", b"/Launch": "abre_programa", b"/EmbeddedFile": "anexo_embutido",
    b"/RichMedia": "midia_embutida", b"/XFA": "formulario_xfa", b"/OpenAction": "acao_ao_abrir", b"/SubmitForm": "envio_de_formulario",
}


def checar_pdf(dados: bytes, cfg: Config) -> list[str]:
    """Marca (ou recusa, conforme a política) PDFs com conteúdo ativo. O conteúdo ativo nunca é executado."""
    achados = sorted({rot for tok, rot in PDF_ATIVO.items() if re.search(re.escape(tok) + rb"(?![A-Za-z])", dados)})
    perigosos = {"javascript", "abre_programa"} & set(achados)
    if perigosos and cfg.pdf_bloquear_ativo:
        raise Recusa("pdf_conteudo_ativo", "O PDF tem conteúdo executável (JavaScript ou ação de abrir programa).", 415)
    return [f"pdf_conteudo_ativo: {', '.join(achados)} (ignorado, nunca executado)"] if achados else []


def limite_tamanho(tamanho: int, familia: str, cfg: Config) -> None:
    limite = min(cfg.max_bytes, cfg.max_por_tipo.get(familia, cfg.max_bytes))
    if tamanho > limite:
        raise Recusa("arquivo_grande_demais", f"O arquivo tem {tamanho / 1048576:.1f} MB; o limite para {familia} é {limite / 1048576:.0f} MB.", 413)
