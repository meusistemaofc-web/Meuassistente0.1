"""Registro de operações em JSON (uma linha por operação): quem chamou, o quê, quanto tempo, resultado.
Nunca registra o conteúdo do arquivo, o texto extraído nem o nome completo: só o hash e metadados técnicos."""
from __future__ import annotations

import json
import sys
import threading
import time
from collections import deque

_trava = threading.Lock()
_recentes: deque = deque(maxlen=200)
_contadores = {"total": 0, "ok": 0, "recusados": 0, "erros": 0}


def registrar(evento: dict, arquivo: str = "") -> None:
    evento = {"em": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **evento}
    linha = json.dumps(evento, ensure_ascii=False)
    with _trava:
        _recentes.append(evento)
        _contadores["total"] += 1
        st = evento.get("status")
        _contadores["ok" if st == "ok" else "recusados" if st == "recusado" else "erros"] += 1
        print(linha, file=sys.stdout, flush=True)
        if arquivo:
            try:
                with open(arquivo, "a", encoding="utf-8") as f:
                    f.write(linha + "\n")
            except OSError:
                pass


def resumo() -> dict:
    with _trava:
        return {**_contadores, "recentes": list(_recentes)[-20:]}
