"""Processo de trabalho: roda UM arquivo em processo separado (limites de memória/CPU do sistema operacional)
e escreve o resultado em JSON na saída padrão. Se travar ou estourar a memória, só ele morre; a API continua."""
from __future__ import annotations

import json
import os
import sys
import time

from .config import carregar
from .processadores.base import FalhaProcessamento
from .processadores import pdf, office, texto, imagem, midia
from . import comprovante, cardapio

PROCESSADORES = {
    "pdf": pdf.processar, "docx": office.docx, "xlsx": office.xlsx, "csv": texto.csv_, "txt": texto.txt,
    "imagem": imagem.processar, "audio": midia.processar, "video": midia.processar,
}


def executar(tarefa: dict) -> dict:
    cfg = carregar()
    fim = time.monotonic() + float(tarefa["tempo_s"])

    def prazo() -> float:
        resta = fim - time.monotonic()
        if resta <= 0.5:
            raise FalhaProcessamento("tempo_excedido", "O processamento passou do tempo limite.")
        return resta

    opc = dict(tarefa.get("opcoes") or {})
    opc["_dir"] = tarefa["dir"]
    familia = tarefa["familia"]
    try:
        r = PROCESSADORES[familia](tarefa["caminho"], opc, cfg, prazo)
    except FalhaProcessamento as e:
        return {"ok": False, "codigo": e.codigo, "mensagem": e.mensagem}
    if opc.get("cardapio"):
        # cardápio: separa as colunas (página a página) e interpreta por regras; o texto devolvido sai sem as marcas
        pags = r.get("paginas") or [{"texto": r.get("texto", "")}]
        base = "\n\n".join(cardapio.colunas(p.get("texto") or "") for p in pags)
        r["cardapio"] = cardapio.extrair(base)
        limpa = lambda t: (t or "").replace(cardapio.MARCA, "")
        r["texto"] = limpa(r.get("texto"))
        for p in r.get("paginas") or []:
            p["texto"] = limpa(p.get("texto"))
    if opc.get("comprovante", "auto") != "nunca" and (r.get("texto") or r.get("codigos")):
        c = comprovante.extrair(r.get("texto", ""), r.get("codigos"), ocr_confianca=r.get("ocr_confianca"))
        if c:
            r["comprovante"] = c
    return {"ok": True, "resultado": r}


def main() -> None:
    tarefa = json.loads(sys.stdin.read())
    try:
        saida = executar(tarefa)
    except MemoryError:
        saida = {"ok": False, "codigo": "memoria_excedida", "mensagem": "O arquivo exigiu memória acima do limite."}
    except Exception as e:  # erro inesperado: nunca vaza detalhes internos do arquivo
        saida = {"ok": False, "codigo": "erro_interno", "mensagem": f"Falha inesperada ({type(e).__name__})."}
    sys.stdout.write(json.dumps(saida, ensure_ascii=False, default=str))
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
