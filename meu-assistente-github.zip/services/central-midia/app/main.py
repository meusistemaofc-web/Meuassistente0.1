"""API interna da Central de Processamento de Arquivos e Mídias.

Rotas:
  GET  /saude              sem autenticação; só diz se está no ar (para o healthcheck do Docker)
  GET  /v1/capacidades     formatos, ferramentas instaladas, limites e nível 2
  POST /v1/processar       corpo = bytes do arquivo; cabeçalhos X-Arquivo-Nome e Content-Type (opcionais)
                           parâmetros: ocr=auto|sempre|nunca, codigos=1|0, comprovante=auto|nunca,
                           transcrever=0|1, interpretar=0|1|auto, idioma=por+eng, cardapio=0|1 (cardápio por regras, sem IA)
  GET  /v1/estatisticas    contadores e últimas operações (sem conteúdo)
Autenticação: cabeçalho "Authorization: Bearer <MIDIA_TOKEN>" (comparação em tempo constante).
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import os
import shutil
import tempfile
import time
import urllib.parse
import uuid

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from . import VERSAO, executor, ia, registro
from .config import carregar
from .identificar import SUPORTADOS, identificar
from .processadores.base import limpar_texto, versao
from .seguranca import Recusa, checar_pdf, checar_zip, limite_tamanho, nome_seguro

cfg = carregar()
_vagas = asyncio.Semaphore(cfg.max_concorrencia)
_esperando = 0  # pedidos em andamento (recebendo, na fila ou processando)


def erro(status: int, codigo: str, mensagem: str, **extra) -> JSONResponse:
    return JSONResponse({"ok": False, "erro": {"codigo": codigo, "mensagem": mensagem}, **extra}, status_code=status)


def autorizado(req: Request) -> JSONResponse | None:
    if not cfg.ativa:
        return erro(503, "central_desativada", "A central de processamento está desativada.")
    if not cfg.token or len(cfg.token) < 24:
        return erro(503, "token_nao_configurado", "Configure MIDIA_TOKEN (24+ caracteres) para usar a central.")
    rec = req.headers.get("authorization", "")
    tok = rec[7:] if rec.lower().startswith("bearer ") else ""
    if not hmac.compare_digest(tok.encode(), cfg.token.encode()):
        return erro(401, "nao_autorizado", "Token inválido.")
    return None


async def saude(req: Request) -> JSONResponse:
    return JSONResponse({"ok": True, "servico": "central-midia", "versao": VERSAO, "ativa": cfg.ativa})


def _ferramentas() -> dict:
    out = {"tesseract": versao(["tesseract", "--version"]), "pdftotext": versao(["pdftotext", "-v"]), "ffprobe": versao(["ffprobe", "-version"])}
    try:
        import cv2
        out["opencv"] = cv2.__version__
    except Exception:
        out["opencv"] = ""
    for mod in ("docx", "openpyxl", "PIL"):
        try:
            m = __import__(mod)
            out[{"docx": "python-docx", "PIL": "pillow"}.get(mod, mod)] = getattr(m, "__version__", "instalado")
        except Exception:
            out[mod] = ""
    return out


async def capacidades(req: Request) -> JSONResponse:
    if (r := autorizado(req)):
        return r
    n2, via = ia.disponivel(cfg)
    return JSONResponse({"ok": True, "versao": VERSAO, "formatos": list(SUPORTADOS), "ferramentas": _ferramentas(),
                         "limites": {"max_bytes": cfg.max_bytes, "por_tipo": cfg.max_por_tipo, "tempo_limite_s": cfg.tempo_limite_s,
                                     "max_paginas_pdf": cfg.max_paginas_pdf, "max_paginas_ocr": cfg.max_paginas_ocr, "max_pixels": cfg.max_pixels,
                                     "max_concorrencia": cfg.max_concorrencia, "max_fila": cfg.max_fila},
                         "nivel2": {"ativo": n2, "provedor": via if n2 else None, "motivo": None if n2 else via},
                         "transcricao": bool(cfg.whisper_url)})


async def estatisticas(req: Request) -> JSONResponse:
    if (r := autorizado(req)):
        return r
    return JSONResponse({"ok": True, **registro.resumo()})


def _opcoes(req: Request) -> dict:
    q = req.query_params
    ocr = q.get("ocr", "auto")
    idioma = q.get("idioma", "")
    return {"ocr": ocr if ocr in ("auto", "sempre", "nunca") else "auto", "codigos": q.get("codigos", "1") != "0",
            "comprovante": "nunca" if q.get("comprovante") == "nunca" else "auto", "transcrever": q.get("transcrever") == "1",
            "cardapio": q.get("cardapio") == "1",
            "interpretar": q.get("interpretar", "0") if q.get("interpretar") in ("0", "1", "auto") else "0",
            "idioma": idioma if idioma and all(p.isalpha() and len(p) == 3 for p in idioma.split("+")) else None}


async def processar(req: Request) -> JSONResponse:
    global _esperando
    if (r := autorizado(req)):
        return r
    t0 = time.monotonic()
    id_op = uuid.uuid4().hex[:16]
    cliente = (req.headers.get("x-cliente") or "")[:64]
    nome = nome_seguro(urllib.parse.unquote(req.headers.get("x-arquivo-nome", "")))
    declarado = int(req.headers.get("content-length") or 0)
    if declarado > cfg.max_bytes:
        registro.registrar({"op": id_op, "cliente": cliente, "status": "recusado", "codigo": "arquivo_grande_demais", "bytes": declarado}, cfg.arquivo_registro)
        return erro(413, "arquivo_grande_demais", f"O limite é {cfg.max_bytes // 1048576} MB.")
    if _esperando >= cfg.max_fila + cfg.max_concorrencia:
        return erro(429, "central_ocupada", "A central está ocupada. Tente de novo em instantes.")
    os.makedirs(cfg.dir_temp, mode=0o700, exist_ok=True)
    pasta = tempfile.mkdtemp(prefix="op-", dir=cfg.dir_temp)
    caminho = os.path.join(pasta, "entrada")  # nunca usa o nome enviado como caminho
    sha = hashlib.sha256()
    total = 0
    _esperando += 1
    try:
        # recebe em partes, cortando no limite (não confia no Content-Length)
        with open(caminho, "wb", opener=lambda p, f: os.open(p, f, 0o600)) as f:
            async for parte in req.stream():
                total += len(parte)
                if total > cfg.max_bytes:
                    raise Recusa("arquivo_grande_demais", f"O limite é {cfg.max_bytes // 1048576} MB.", 413)
                sha.update(parte)
                f.write(parte)
        ident = identificar(caminho, nome, req.headers.get("content-type", ""))
        if not ident.familia:
            msgs = {"vazio": "O arquivo está vazio.", "executavel": "Programas e scripts não são aceitos.",
                    "formato_nao_suportado": "Formato não suportado.", "formato_antigo_nao_suportado": "Formatos antigos do Office (.doc/.xls) não são suportados; salve como .docx/.xlsx.",
                    "arquivo_corrompido": "O arquivo está corrompido."}
            raise Recusa(ident.motivo, msgs.get(ident.motivo, "Arquivo recusado."), 415 if ident.motivo != "vazio" else 400)
        limite_tamanho(total, ident.familia, cfg)
        avisos = list(ident.avisos)
        if ident.familia in ("docx", "xlsx"):
            avisos += checar_zip(caminho, cfg)
        if ident.familia == "pdf":
            with open(caminho, "rb") as f:
                avisos += checar_pdf(f.read(), cfg)
        opc = _opcoes(req)
        async with _vagas:  # no máximo MAX_CONCORRENCIA arquivos processando; os demais esperam na fila
            res = await executor.rodar({"caminho": caminho, "dir": pasta, "familia": ident.familia, "opcoes": opc, "tempo_s": cfg.tempo_limite_s}, cfg)
        if not res.get("ok"):
            cod = res.get("codigo", "erro_interno")
            status = {"tempo_excedido": 504, "memoria_excedida": 413, "imagem_grande_demais": 413, "documento_protegido": 422, "arquivo_corrompido": 422}.get(cod, 500)
            registro.registrar({"op": id_op, "cliente": cliente, "status": "erro" if status >= 500 else "recusado", "codigo": cod, "familia": ident.familia,
                                "bytes": total, "sha256": sha.hexdigest(), "ms": int((time.monotonic() - t0) * 1000)}, cfg.arquivo_registro)
            return erro(status, cod, res.get("mensagem", "Falha ao processar."), id=id_op)
        r = res["resultado"]
        familia = r.pop("familia", ident.familia)
        avisos += r.pop("avisos", [])
        texto = limpar_texto(r.pop("texto", ""))
        if len(texto) > cfg.max_texto:
            texto = texto[: cfg.max_texto]
            avisos.append("texto_truncado")
        corpo = {"ok": True, "id": id_op, "versao": VERSAO, "nivel": 1,
                 "arquivo": {"nome": nome, "tamanho": total, "sha256": sha.hexdigest(), "familia": familia, "formato": ident.formato, "mime": ident.mime},
                 "texto": texto, "paginas": r.pop("paginas", None), "tabelas": r.pop("tabelas", None), "metadados": r.pop("metadados", {}),
                 "codigos": r.pop("codigos", []), "comprovante": r.pop("comprovante", None), **({"cardapio": r.pop("cardapio")} if "cardapio" in r else {}), "ocr": {"usado": r.pop("ocr_usado", False), "confianca": r.pop("ocr_confianca", None)},
                 **({"transcricao": r.pop("transcricao")} if "transcricao" in r else {}), "avisos": avisos}
        # nível 2: só quando pedido (1) ou, em "auto", quando o nível 1 não achou o essencial de um comprovante
        quer = opc["interpretar"] == "1" or (opc["interpretar"] == "auto" and corpo["comprovante"] and corpo["comprovante"].get("campos_essenciais_faltando"))
        if quer and texto:
            corpo["nivel2"] = await asyncio.get_running_loop().run_in_executor(None, ia.interpretar, texto, {"familia": familia, "comprovante": corpo["comprovante"]}, cfg)
            if corpo["nivel2"].get("usado"):
                corpo["nivel"] = 2
        corpo["tempo_ms"] = int((time.monotonic() - t0) * 1000)
        registro.registrar({"op": id_op, "cliente": cliente, "status": "ok", "familia": familia, "formato": ident.formato, "bytes": total, "sha256": sha.hexdigest(),
                            "ocr": corpo["ocr"]["usado"], "nivel": corpo["nivel"], "avisos": len(avisos), "ms": corpo["tempo_ms"]}, cfg.arquivo_registro)
        return JSONResponse(corpo)
    except Recusa as e:
        registro.registrar({"op": id_op, "cliente": cliente, "status": "recusado", "codigo": e.codigo, "bytes": total, "ms": int((time.monotonic() - t0) * 1000)}, cfg.arquivo_registro)
        return erro(e.status, e.codigo, e.mensagem, id=id_op)
    finally:
        _esperando = max(0, _esperando - 1)
        shutil.rmtree(pasta, ignore_errors=True)  # nada do arquivo fica no disco


app = Starlette(routes=[
    Route("/saude", saude), Route("/v1/capacidades", capacidades), Route("/v1/estatisticas", estatisticas),
    Route("/v1/processar", processar, methods=["POST"]),
])
