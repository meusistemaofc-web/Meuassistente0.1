"""DOCX (python-docx) e XLSX (openpyxl, somente leitura e valores calculados). Macros nunca são executadas."""
from __future__ import annotations

import datetime as dt

from .base import FalhaProcessamento, limpar_texto


def _props(p) -> dict:
    def iso(v):
        return v.isoformat() if isinstance(v, (dt.datetime, dt.date)) else (str(v) if v else "")
    out = {"titulo": getattr(p, "title", "") or "", "autor": getattr(p, "creator", None) or getattr(p, "author", None) or "", "ultimo_autor": getattr(p, "last_modified_by", "") or "",
           "criado_em": iso(p.created), "modificado_em": iso(p.modified), "assunto": getattr(p, "subject", "") or "", "palavras_chave": getattr(p, "keywords", "") or ""}
    return {k: v for k, v in out.items() if v}


def docx(caminho: str, opc: dict, cfg, prazo) -> dict:
    try:
        import docx as pydocx
        d = pydocx.Document(caminho)
    except Exception as e:  # documento malformado
        raise FalhaProcessamento("arquivo_corrompido", "O DOCX está corrompido ou não pôde ser lido.") from e
    partes: list[str] = []
    for p in d.paragraphs:
        t = p.text.strip()
        if not t:
            continue
        estilo = (p.style.name if p.style is not None else "") or ""
        if estilo.lower().startswith(("heading", "título", "titulo")):
            nivel = "".join(c for c in estilo if c.isdigit()) or "1"
            t = "#" * min(int(nivel), 6) + " " + t
        partes.append(t)
    tabelas = []
    for i, tb in enumerate(d.tables):
        linhas = []
        for row in tb.rows[: cfg.max_linhas_planilha]:
            linhas.append([c.text.strip() for c in row.cells])
        tabelas.append({"nome": f"Tabela {i + 1}", "linhas": linhas, "total_linhas": len(tb.rows)})
        partes.append("\n".join(" | ".join(l) for l in linhas))
    cab = []
    for s in d.sections:
        for bloco in (s.header, s.footer):
            t = "\n".join(p.text.strip() for p in bloco.paragraphs if p.text.strip())
            if t and t not in cab:
                cab.append(t)
    meta = _props(d.core_properties)
    meta.update({"paragrafos": len(d.paragraphs), "tabelas": len(d.tables), "imagens": len(d.inline_shapes)})
    if cab:
        meta["cabecalhos_rodapes"] = cab
    return {"texto": limpar_texto("\n\n".join(partes)), "tabelas": tabelas, "metadados": meta, "avisos": []}


def _celula(v):
    if v is None:
        return ""
    if isinstance(v, (dt.datetime, dt.date, dt.time)):
        return v.isoformat()
    if isinstance(v, float):
        return f"{v:.10g}"
    return str(v)


def xlsx(caminho: str, opc: dict, cfg, prazo) -> dict:
    try:
        import openpyxl
        arq = open(caminho, "rb")  # objeto de arquivo: o openpyxl não depende da extensão do nome
        wb = openpyxl.load_workbook(arq, read_only=True, data_only=True)
    except Exception as e:
        raise FalhaProcessamento("arquivo_corrompido", "A planilha está corrompida ou não pôde ser lida.") from e
    av: list[str] = []
    tabelas = []
    partes = []
    restante = cfg.max_linhas_planilha
    try:
        for ws in wb.worksheets:
            linhas = []
            total = 0
            for row in ws.iter_rows(values_only=True):
                total += 1
                if len(linhas) < restante:
                    vals = [_celula(v) for v in row]
                    while vals and vals[-1] == "":
                        vals.pop()
                    linhas.append(vals)
            while linhas and not any(linhas[-1]):
                linhas.pop()
            restante -= len(linhas)
            trunc = total > len(linhas)
            if trunc:
                av.append(f"planilha_limitada: aba {ws.title} com {total} linhas")
            tabelas.append({"nome": ws.title, "linhas": linhas, "total_linhas": total, "truncada": trunc})
            partes.append(f"## {ws.title}\n" + "\n".join("\t".join(l) for l in linhas if any(l)))
        props = _props(wb.properties)
        props.update({"abas": [ws.title for ws in wb.worksheets]})
    finally:
        wb.close()
        arq.close()
    return {"texto": limpar_texto("\n\n".join(partes)), "tabelas": tabelas, "metadados": props, "avisos": av}
