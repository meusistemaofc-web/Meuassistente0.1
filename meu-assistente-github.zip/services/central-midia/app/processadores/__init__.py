"""Processadores por família de arquivo. Cada um recebe o caminho do arquivo (já identificado e checado) e devolve
um dicionário parcial com: texto, paginas, tabelas, metadados, codigos, avisos. Nenhum executa conteúdo do arquivo."""
