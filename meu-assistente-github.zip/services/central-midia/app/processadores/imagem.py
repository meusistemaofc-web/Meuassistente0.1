"""Imagens (JPG, PNG, WEBP): validação com Pillow (proteção contra imagem-bomba), metadados EXIF,
pré-processamento e OCR local com Tesseract (sem internet). O GPS nunca é devolvido, só indicado."""
from __future__ import annotations

import csv
import io
import os

from .base import FalhaProcessamento, limpar_texto, rodar

_TAGS = {271: "fabricante", 272: "modelo", 305: "software", 306: "data", 274: "orientacao"}
_EXIF_IFD = {36867: "data_original", 37385: "flash"}


def abrir(caminho: str, cfg):
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = cfg.max_pixels
    try:
        with Image.open(caminho) as im:
            im.verify()
        im = Image.open(caminho)
        if im.width * im.height > cfg.max_pixels:
            raise FalhaProcessamento("imagem_grande_demais", "A imagem tem resolução acima do limite.")
        im.load()
    except Image.DecompressionBombError as e:
        raise FalhaProcessamento("imagem_grande_demais", "A imagem tem resolução acima do limite (possível imagem-bomba).") from e
    except FalhaProcessamento:
        raise
    except Exception as e:
        raise FalhaProcessamento("arquivo_corrompido", "A imagem está corrompida ou não pôde ser lida.") from e
    return im, ImageOps


def metadados(im) -> tuple[dict, list[str]]:
    meta = {"largura": im.width, "altura": im.height, "modo": im.mode, "formato": (im.format or "").lower()}
    av = []
    try:
        ex = im.getexif()
        for k, nome in _TAGS.items():
            if ex.get(k):
                meta[nome] = str(ex.get(k)).strip("\x00 ")[:80]
        sub = ex.get_ifd(0x8769)
        for k, nome in _EXIF_IFD.items():
            if sub.get(k) is not None:
                meta[nome] = str(sub.get(k)).strip("\x00 ")[:80]
        if ex.get_ifd(0x8825):
            meta["tem_localizacao_gps"] = True
            av.append("imagem_com_gps: a localização não é devolvida por privacidade")
    except Exception:
        pass
    return meta, av


def preparar_ocr(im, ImageOps, destino: str) -> str:
    from PIL import ImageFilter
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("L", "RGB"):
        im = im.convert("RGBA").convert("RGB") if "A" in im.mode or im.mode == "P" else im.convert("RGB")
    g = im.convert("L")
    menor = min(g.size)
    if menor < 1000:  # fotos pequenas: ampliar melhora muito o Tesseract
        f = min(3.0, 1400 / max(1, menor))
        g = g.resize((int(g.width * f), int(g.height * f)))
    g = ImageOps.autocontrast(g, cutoff=1).filter(ImageFilter.SHARPEN)
    g.save(destino, "PNG")
    return destino


def ocr_arquivo(caminho_png: str, cfg, prazo, idioma: str | None = None) -> tuple[str, float]:
    """Tesseract em TSV: texto por linha e confiança média (0 a 1)."""
    r = rodar(["tesseract", caminho_png, "stdout", "-l", idioma or cfg.idioma_ocr, "--psm", "3", "tsv"], prazo())
    linhas: dict = {}
    confs = []
    leitor = csv.DictReader(io.StringIO((r.stdout or b"").decode("utf-8", "replace")), delimiter="\t", quoting=csv.QUOTE_NONE)
    for row in leitor:
        txt = (row.get("text") or "").strip()
        try:
            conf = float(row.get("conf") or -1)
        except ValueError:
            conf = -1
        if not txt or conf < 0:
            continue
        chave = (int(row["block_num"]), int(row["par_num"]), int(row["line_num"]))
        linhas.setdefault(chave, []).append(txt)
        confs.append(conf)
    blocos: list[str] = []
    ultimo = None
    for chave in sorted(linhas):
        if ultimo and chave[:2] != ultimo[:2]:
            blocos.append("")
        blocos.append(" ".join(linhas[chave]))
        ultimo = chave
    return limpar_texto("\n".join(blocos)), (sum(confs) / len(confs) / 100 if confs else 0.0)


def processar(caminho: str, opc: dict, cfg, prazo) -> dict:
    im, ImageOps = abrir(caminho, cfg)
    meta, av = metadados(im)
    out = {"texto": "", "metadados": meta, "avisos": av, "ocr_usado": False}
    if opc.get("ocr", "auto") != "nunca":
        dest = preparar_ocr(im, ImageOps, os.path.join(opc["_dir"], "ocr.png"))
        texto, conf = ocr_arquivo(dest, cfg, prazo, opc.get("idioma"))
        out.update(texto=texto, ocr_usado=True, ocr_confianca=round(conf, 3))
        if texto and conf < 0.55:
            av.append("ocr_baixa_confianca: foto escura, tremida ou inclinada")
    if opc.get("codigos", True):
        from . import codigos
        out["codigos"] = codigos.ler_imagem(im)
    im.close()
    return out
