"""Imagens (JPG, PNG, WEBP): validação com Pillow (proteção contra imagem-bomba), metadados EXIF,
pré-processamento e OCR local com Tesseract (sem internet). O GPS nunca é devolvido, só indicado."""
from __future__ import annotations

import csv
import io
import os
import re

from .base import FalhaProcessamento, limpar_texto, rodar

_TAGS = {271: "fabricante", 272: "modelo", 305: "software", 306: "data", 274: "orientacao"}
_EXIF_IFD = {36867: "data_original", 37385: "flash"}


def abrir(caminho: str, cfg):
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = cfg.max_pixels
    try:
        with Image.open(caminho) as im:
            im.verify()
        im = Image.open(caminho)
        if im.width * im.height > cfg.max_pixels:
            raise FalhaProcessamento("imagem_grande_demais", "A imagem tem resolução acima do limite.")
        im.load()
    except Image.DecompressionBombError as e:
        raise FalhaProcessamento("imagem_grande_demais", "A imagem tem resolução acima do limite (possível imagem-bomba).") from e
    except FalhaProcessamento:
        raise
    except Exception as e:
        raise FalhaProcessamento("arquivo_corrompido", "A imagem está corrompida ou não pôde ser lida.") from e
    return im, ImageOps


def metadados(im) -> tuple[dict, list[str]]:
    meta = {"largura": im.width, "altura": im.height, "modo": im.mode, "formato": (im.format or "").lower()}
    av = []
    try:
        ex = im.getexif()
        for k, nome in _TAGS.items():
            if ex.get(k):
                meta[nome] = str(ex.get(k)).strip("\x00 ")[:80]
        sub = ex.get_ifd(0x8769)
        for k, nome in _EXIF_IFD.items():
            if sub.get(k) is not None:
                meta[nome] = str(sub.get(k)).strip("\x00 ")[:80]
        if ex.get_ifd(0x8825):
            meta["tem_localizacao_gps"] = True
            av.append("imagem_com_gps: a localização não é devolvida por privacidade")
    except Exception:
        pass
    return meta, av


def _documento(cv2, np, g):
    """Foto de papel/tela sobre a mesa: acha o maior quadrilátero e corrige a perspectiva (recorta o comprovante)."""
    h, w = g.shape[:2]
    esc = 800 / max(h, w)
    peq = cv2.resize(g, (int(w * esc), int(h * esc))) if esc < 1 else g.copy()
    esc = min(esc, 1.0)
    borda = cv2.Canny(cv2.GaussianBlur(peq, (5, 5), 0), 30, 90)
    borda = cv2.dilate(borda, np.ones((3, 3), np.uint8), iterations=2)
    conts, _ = cv2.findContours(borda, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    area_img = peq.shape[0] * peq.shape[1]
    for c in sorted(conts, key=cv2.contourArea, reverse=True)[:5]:
        ap = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        a = cv2.contourArea(ap)
        if len(ap) == 4 and 0.25 * area_img < a < 0.97 * area_img:
            pts = (ap.reshape(4, 2) / esc).astype(np.float32)
            soma, dif = pts.sum(1), np.diff(pts, axis=1).ravel()
            ordem = np.float32([pts[np.argmin(soma)], pts[np.argmin(dif)], pts[np.argmax(soma)], pts[np.argmax(dif)]])
            larg = int(max(np.linalg.norm(ordem[0] - ordem[1]), np.linalg.norm(ordem[3] - ordem[2])))
            alt = int(max(np.linalg.norm(ordem[0] - ordem[3]), np.linalg.norm(ordem[1] - ordem[2])))
            if larg < 200 or alt < 150:
                continue
            m = cv2.getPerspectiveTransform(ordem, np.float32([[0, 0], [larg, 0], [larg, alt], [0, alt]]))
            return cv2.warpPerspective(g, m, (larg, alt), borderMode=cv2.BORDER_REPLICATE), True
    return g, False


def _inclinacao(cv2, np, g) -> float:
    """Ângulo (graus) que deixa as linhas de texto na horizontal: maximiza o contraste das linhas (perfil de projeção)."""
    peq = cv2.resize(g, None, fx=min(1.0, 900 / max(g.shape)), fy=min(1.0, 900 / max(g.shape)))
    _, b = cv2.threshold(peq, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    if b.mean() > 127:
        b = 255 - b
    h, w = b.shape
    melhor, ang_m = -1.0, 0.0
    for ang in np.arange(-6, 6.01, 0.5):
        r = cv2.warpAffine(b, cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0), (w, h), flags=cv2.INTER_NEAREST)
        v = float(np.var(r.sum(1)))
        if v > melhor:
            melhor, ang_m = v, float(ang)
    return ang_m


def _texto_vertical(cv2, np, g) -> bool:
    """Linhas de texto em pé (foto de lado)? Compara o contraste do perfil por linhas e por colunas."""
    peq = cv2.resize(g, None, fx=min(1.0, 700 / max(g.shape)), fy=min(1.0, 700 / max(g.shape)))
    _, b = cv2.threshold(peq, 0, 1, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    vl, vc = float(np.var(b.sum(1)) / max(1, b.shape[1]) ** 2), float(np.var(b.sum(0)) / max(1, b.shape[0]) ** 2)
    return vc > vl * 1.3


def preparar_ocr(im, ImageOps, destino: str, girar: int = 0) -> str:
    """Endireita (perspectiva e inclinação), inverte tela escura, amplia foto pequena e realça o contraste."""
    import cv2
    import numpy as np
    from PIL import Image
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("L", "RGB"):
        im = im.convert("RGBA").convert("RGB") if "A" in im.mode or im.mode == "P" else im.convert("RGB")
    g = np.array(im.convert("L"))
    if girar:
        g = cv2.rotate(g, {90: cv2.ROTATE_90_COUNTERCLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_CLOCKWISE}[girar])
    g, _ = _documento(cv2, np, g)
    ang = _inclinacao(cv2, np, g)
    if abs(ang) >= 0.5:
        h, w = g.shape
        g = cv2.warpAffine(g, cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0), (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    if np.median(g) < 110:  # tela no modo escuro: texto claro em fundo escuro
        g = 255 - g
    preparar_ocr.vertical = _texto_vertical(cv2, np, g)
    menor = min(g.shape)
    if menor < 1000:  # fotos pequenas: ampliar melhora muito o Tesseract
        f = min(3.0, 1400 / max(1, menor))
        g = cv2.resize(g, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
    g = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(g)  # sombra e luz desigual
    Image.fromarray(g).save(destino, "PNG")
    return destino


def orientacao(caminho_png: str, prazo) -> int:
    """Rotação sugerida pelo Tesseract (OSD): 0, 90, 180 ou 270. Usada só quando a primeira leitura sai fraca."""
    try:
        r = rodar(["tesseract", caminho_png, "stdout", "--psm", "0"], prazo(), aceitar_erro=True)
        for linha in (r.stdout or b"").decode("utf-8", "replace").splitlines():
            if linha.startswith("Rotate:"):
                return int(linha.split(":")[1]) % 360
    except Exception:
        pass
    return 0


def ocr_arquivo(caminho_png: str, cfg, prazo, idioma: str | None = None, psm: str = "3") -> tuple[str, float]:
    """Tesseract em TSV. Reconstrói as LINHAS pela posição das palavras (layout de comprovante em duas colunas:
    "Valor ............ R$ 152,30" vira uma linha só) e calcula a confiança média (0 a 1)."""
    r = rodar(["tesseract", caminho_png, "stdout", "-l", idioma or cfg.idioma_ocr, "--psm", psm, "tsv"], prazo())
    palavras = []
    leitor = csv.DictReader(io.StringIO((r.stdout or b"").decode("utf-8", "replace")), delimiter="\t", quoting=csv.QUOTE_NONE)
    for row in leitor:
        txt = (row.get("text") or "").strip()
        try:
            conf = float(row.get("conf") or -1)
            x, y, w, h = (int(row[k]) for k in ("left", "top", "width", "height"))
        except (ValueError, KeyError, TypeError):
            continue
        if txt and conf >= 0:
            palavras.append((y + h / 2, x, w, h, txt, conf))
    if not palavras:
        ocr_arquivo.vertical = False
        return "", 0.0
    longas = [p for p in palavras if len(p[4]) >= 3]
    # palavras "em pé" (caixa mais alta que larga): o texto da foto está de lado
    ocr_arquivo.vertical = bool(longas) and sum(1 for p in longas if p[3] > p[2]) > len(longas) * 0.5
    alt = sorted(p[3] for p in palavras)[len(palavras) // 2] or 1
    linhas: list[list] = []
    for p in sorted(palavras):
        if linhas and abs(p[0] - linhas[-1][0]) <= alt * 0.6:
            linhas[-1][1].append(p)
            linhas[-1][0] = sum(q[0] for q in linhas[-1][1]) / len(linhas[-1][1])
        else:
            linhas.append([p[0], [p]])
    saida = []
    ultimo_y = None
    for cy, ps in linhas:
        ps.sort(key=lambda q: q[1])
        partes, fim = [], None
        for _cy, x, w, h, txt, _c in ps:
            if fim is not None:
                partes.append("   " if x - fim > alt * 1.5 else " ")  # espaço largo = outra coluna
            partes.append(txt)
            fim = x + w
        if ultimo_y is not None and cy - ultimo_y > alt * 2.6:
            saida.append("")  # parágrafo/seção
        saida.append("".join(partes))
        ultimo_y = cy
    confs = [p[5] for p in palavras]
    return limpar_texto("\n".join(saida)), sum(confs) / len(confs) / 100


def processar(caminho: str, opc: dict, cfg, prazo) -> dict:
    im, ImageOps = abrir(caminho, cfg)
    meta, av = metadados(im)
    out = {"texto": "", "metadados": meta, "avisos": av, "ocr_usado": False}
    if opc.get("ocr", "auto") != "nunca":
        dest = preparar_ocr(im, ImageOps, os.path.join(opc["_dir"], "ocr.png"))
        texto, conf = ocr_arquivo(dest, cfg, prazo, opc.get("idioma"))
        de_lado = getattr(preparar_ocr, "vertical", False) or getattr(ocr_arquivo, "vertical", False)
        if de_lado or conf < 0.6 or len(texto) < 40:
            # foto de lado: testa os dois sentidos (o OSD do Tesseract erra em textos curtos); senão segue o OSD
            giros = [90, 270] if de_lado else [r for r in [orientacao(dest, prazo)] if r]
            melhor = None
            for rot in giros:
                d2 = preparar_ocr(im, ImageOps, os.path.join(opc["_dir"], f"ocr{rot}.png"), girar=rot)
                t2, c2 = ocr_arquivo(d2, cfg, prazo, opc.get("idioma"))
                if len(t2) >= 20 and not getattr(ocr_arquivo, "vertical", False) and (melhor is None or c2 > melhor[1]):
                    melhor = (t2, c2, rot, d2)
            if melhor and (de_lado or melhor[1] > conf):
                texto, conf, dest = melhor[0], melhor[1], melhor[3]
                av.append(f"foto_girada: corrigida em {melhor[2]} graus")
        # números de uma coluna à direita às vezes somem na segmentação automática: 2ª leitura em bloco único
        dinheiro = lambda x: len(re.findall(r"\d,\d{2}\b", x))
        total_sem_valor = re.search(r"(?im)^\s*(valor|total)\b[^\d\n]*$", texto or "")
        if texto and (dinheiro(texto) == 0 or total_sem_valor):
            t6, c6 = ocr_arquivo(dest, cfg, prazo, opc.get("idioma"), psm="6")
            if dinheiro(t6) > 0:
                texto = texto + "\n\n" + t6
                av.append("ocr_segunda_leitura: valores recuperados em bloco único")
        out.update(texto=texto, ocr_usado=True, ocr_confianca=round(conf, 3))
        if texto and conf < 0.55:
            av.append("ocr_baixa_confianca: foto escura, tremida ou inclinada")
    if opc.get("codigos", True):
        from . import codigos
        out["codigos"] = codigos.ler_imagem(im)
    im.close()
    return out
