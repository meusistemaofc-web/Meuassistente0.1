"""Utilidades comuns: execução de ferramentas externas sem shell, com tempo limite, e limpeza de texto."""
from __future__ import annotations

import re
import shutil
import subprocess
import unicodedata


class FalhaProcessamento(Exception):
    def __init__(self, codigo: str, mensagem: str):
        super().__init__(mensagem)
        self.codigo = codigo
        self.mensagem = mensagem


def ferramenta(nome: str) -> str | None:
    return shutil.which(nome)


def rodar(args: list[str], tempo_s: float, entrada: bytes | None = None, aceitar_erro: bool = False) -> subprocess.CompletedProcess:
    """Executa uma ferramenta (lista de argumentos, sem shell). Estoura FalhaProcessamento em tempo excedido."""
    if not ferramenta(args[0]):
        raise FalhaProcessamento("ferramenta_ausente", f"A ferramenta {args[0]} não está instalada.")
    try:
        r = subprocess.run(args, input=entrada, capture_output=True, timeout=max(1.0, tempo_s), check=False)
    except subprocess.TimeoutExpired as e:
        raise FalhaProcessamento("tempo_excedido", f"{args[0]} passou do tempo limite.") from e
    if r.returncode != 0 and not aceitar_erro:
        msg = (r.stderr or b"").decode("utf-8", "replace").strip().splitlines()
        raise FalhaProcessamento("falha_ferramenta", f"{args[0]}: {msg[-1] if msg else 'erro ' + str(r.returncode)}"[:300])
    return r


def limpar_texto(s: str) -> str:
    s = unicodedata.normalize("NFC", s or "").replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "")
    s = re.sub(r"[ \t ]+\n", "\n", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def versao(args: list[str]) -> str:
    if not ferramenta(args[0]):
        return ""
    try:
        r = subprocess.run(args, capture_output=True, timeout=10, check=False)
        out = (r.stdout or r.stderr or b"").decode("utf-8", "replace").strip().splitlines()
        return out[0][:80] if out else ""
    except Exception:
        return ""
