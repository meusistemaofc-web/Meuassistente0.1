"""TXT e CSV: detecção de codificação (UTF-8, UTF-16, Windows-1252) e de separador, sem bibliotecas externas."""
from __future__ import annotations

import csv
import io

from .base import limpar_texto


def decodificar(dados: bytes) -> tuple[str, str]:
    if dados[:3] == b"\xef\xbb\xbf":
        return dados[3:].decode("utf-8", "replace"), "utf-8-sig"
    if dados[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return dados.decode("utf-16", "replace"), "utf-16"
    try:
        return dados.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return dados.decode("cp1252", "replace"), "windows-1252"


def txt(caminho: str, opc: dict, cfg, prazo) -> dict:
    with open(caminho, "rb") as f:
        s, enc = decodificar(f.read())
    t = limpar_texto(s)
    return {"texto": t, "metadados": {"codificacao": enc, "linhas": t.count("\n") + 1 if t else 0, "palavras": len(t.split())}, "avisos": []}


def csv_(caminho: str, opc: dict, cfg, prazo) -> dict:
    with open(caminho, "rb") as f:
        s, enc = decodificar(f.read())
    amostra = s[:20000]
    try:
        sep = csv.Sniffer().sniff(amostra, delimiters=";,\t|").delimiter
    except csv.Error:
        linhas = [l for l in amostra.splitlines()[:20] if l.strip()]
        sep = max(";,\t|", key=lambda d: sum(l.count(d) for l in linhas))
    leitor = csv.reader(io.StringIO(s), delimiter=sep)
    linhas, total = [], 0
    try:
        for row in leitor:
            total += 1
            if len(linhas) < cfg.max_linhas_planilha:
                linhas.append([c.strip() for c in row])
    except csv.Error as e:
        return {"texto": limpar_texto(s), "metadados": {"codificacao": enc}, "avisos": [f"csv_irregular: {e}"]}
    av = [f"planilha_limitada: {total} linhas"] if total > len(linhas) else []
    nome_sep = {";": "ponto e vírgula", ",": "vírgula", "\t": "tabulação", "|": "barra vertical"}[sep]
    return {"texto": limpar_texto(s), "tabelas": [{"nome": "CSV", "linhas": linhas, "total_linhas": total, "truncada": total > len(linhas)}],
            "metadados": {"codificacao": enc, "separador": nome_sep, "linhas": total, "colunas": max((len(r) for r in linhas), default=0)}, "avisos": av}
