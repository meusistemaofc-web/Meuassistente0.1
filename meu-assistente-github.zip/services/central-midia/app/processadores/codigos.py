"""QR Codes e códigos de barras com OpenCV (local). QR de Pix (BR Code/EMV) é interpretado e o CRC conferido."""
from __future__ import annotations


def _cv():
    import cv2
    import numpy as np
    cv2.setNumThreads(1)  # previsível em VPS pequena
    return cv2, np


def _matriz(im):
    cv2, np = _cv()
    g = im.convert("L")
    return np.array(g)


def _qr(cv2, mat) -> list[str]:
    out: list[str] = []
    for det in (cv2.QRCodeDetector(), getattr(cv2, "QRCodeDetectorAruco", lambda: None)()):
        if det is None:
            continue
        try:
            ok, textos, _pts, _ = det.detectAndDecodeMulti(mat)
            if ok:
                out += [t for t in textos if t]
        except Exception:
            pass
        if not out:
            try:
                t, _pts, _ = det.detectAndDecode(mat)
                if t:
                    out.append(t)
            except Exception:
                pass
        if out:
            break
    return list(dict.fromkeys(out))


def _barras(cv2, mat) -> list[tuple[str, str]]:
    if not hasattr(cv2, "barcode"):
        return []
    try:
        det = cv2.barcode.BarcodeDetector()
        r = det.detectAndDecodeWithType(mat)
        ok, textos, tipos = (r[0], r[1], r[2]) if len(r) >= 3 else (False, [], [])
        if isinstance(textos, str):
            textos, tipos = [textos], [tipos]
        return [(t, str(tp)) for t, tp in zip(textos, tipos) if t]
    except Exception:
        return []


def _variacoes(cv2, mat):
    """O detector do OpenCV é sensível à escala e à margem: tenta algumas combinações, da mais barata à mais cara."""
    h, w = mat.shape[:2]
    maior = max(h, w)
    for pad in (0, max(20, maior // 12)):
        base = cv2.copyMakeBorder(mat, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=255) if pad else mat
        for f in (1.0, 0.5, 2.0, 0.75, 1.5):
            if maior * f > 4000 or maior * f < 120:
                continue
            yield base if f == 1.0 else cv2.resize(base, None, fx=f, fy=f, interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_CUBIC)


def ler_matriz(mat) -> list[dict]:
    cv2, np = _cv()
    achados: list[dict] = []
    vistos = set()
    qr_ok = barras_ok = False
    for m in _variacoes(cv2, mat):
        if not qr_ok:
            for t in _qr(cv2, m):
                qr_ok = True
                if ("qrcode", t) not in vistos:
                    vistos.add(("qrcode", t))
                    achados.append(interpretar({"tipo": "qrcode", "conteudo": t}))
        if not barras_ok:
            for t, tp in _barras(cv2, m):
                barras_ok = True
                if ("barras", t) not in vistos:
                    vistos.add(("barras", t))
                    achados.append(interpretar({"tipo": "codigo_de_barras", "formato": tp.replace("_", "-"), "conteudo": t}))
        if qr_ok and barras_ok:
            break
    return achados


def ler_imagem(im) -> list[dict]:
    try:
        return ler_matriz(_matriz(im))
    except Exception:
        return []


def ler_arquivo(caminho: str) -> list[dict]:
    from PIL import Image
    with Image.open(caminho) as im:
        return ler_imagem(im)


# ---------- Pix (BR Code / EMV MPM) ----------
def _crc16(dados: str) -> str:
    crc = 0xFFFF
    for b in dados.encode("utf-8"):
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return f"{crc:04X}"


def _tlv(s: str) -> dict:
    out, i = {}, 0
    while i + 4 <= len(s):
        tag, n = s[i:i + 2], s[i + 2:i + 4]
        if not n.isdigit():
            break
        n = int(n)
        out[tag] = s[i + 4:i + 4 + n]
        i += 4 + n
    return out


def pix_brcode(s: str) -> dict | None:
    if not s.startswith("000201"):
        return None
    campos = _tlv(s)
    conta = None
    for tag in [f"{n:02d}" for n in range(26, 52)]:
        if tag in campos and "br.gov.bcb.pix" in campos[tag].lower():
            conta = _tlv(campos[tag])
            break
    if conta is None:
        return None
    crc_ok = len(s) > 4 and s[-8:-4] == "6304" and _crc16(s[:-4]) == s[-4:].upper()
    adic = _tlv(campos.get("62", ""))
    valor = campos.get("54")
    return {"chave": conta.get("01", ""), "url_cobranca": conta.get("25", ""), "descricao": conta.get("02", ""),
            "valor": float(valor) if valor and valor.replace(".", "", 1).isdigit() else None,
            "recebedor": campos.get("59", ""), "cidade": campos.get("60", ""), "txid": adic.get("05", ""),
            "dinamico": bool(conta.get("25")), "crc_valido": crc_ok}


def interpretar(c: dict) -> dict:
    t = c["conteudo"]
    if c["tipo"] == "qrcode":
        p = pix_brcode(t)
        if p:
            c["pix"] = p
            c["uso"] = "pix_copia_e_cola"
        elif t.lower().startswith(("http://", "https://")):
            c["uso"] = "link"
            if "fazenda" in t.lower() or "nfce" in t.lower():
                c["uso"] = "nfce_consulta"
    elif c["tipo"] == "codigo_de_barras":
        d = "".join(ch for ch in t if ch.isdigit())
        if len(d) == 44:
            c["uso"] = "boleto_ou_arrecadacao"
        elif len(d) in (8, 12, 13):
            c["uso"] = "produto_ean"
    return c
