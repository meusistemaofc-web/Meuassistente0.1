"""Áudio e vídeo: metadados com FFprobe e, se pedido, transcrição pelo Whisper local já usado pelo Meu Assistente."""
from __future__ import annotations

import json
import os
import urllib.request
import uuid

from .base import FalhaProcessamento, rodar


def _f(v):
    try:
        return round(float(v), 3)
    except (TypeError, ValueError):
        return None


def sondar(caminho: str, prazo) -> dict:
    r = rodar(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", caminho], prazo(), aceitar_erro=True)
    if r.returncode != 0:
        raise FalhaProcessamento("arquivo_corrompido", "O arquivo de áudio/vídeo está corrompido ou não pôde ser lido.")
    return json.loads(r.stdout or b"{}")


def processar(caminho: str, opc: dict, cfg, prazo) -> dict:
    p = sondar(caminho, prazo)
    fmt = p.get("format", {})
    streams = p.get("streams", [])
    videos = [s for s in streams if s.get("codec_type") == "video" and not (s.get("disposition") or {}).get("attached_pic")]
    audios = [s for s in streams if s.get("codec_type") == "audio"]
    if not videos and not audios:
        raise FalhaProcessamento("arquivo_corrompido", "Nenhuma trilha de áudio ou vídeo encontrada.")
    familia = "video" if videos else "audio"
    av: list[str] = []
    dur = _f(fmt.get("duration")) or 0.0
    tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}
    meta: dict = {"duracao_s": dur, "formato_conteiner": fmt.get("format_name", ""), "taxa_bits": int(fmt.get("bit_rate") or 0) or None,
                  "trilhas_audio": len(audios), "trilhas_video": len(videos)}
    for k in ("title", "artist", "album", "date", "creation_time", "encoder", "comment"):
        if tags.get(k):
            meta[{"title": "titulo", "artist": "artista", "album": "album", "date": "data", "creation_time": "criado_em", "encoder": "codificador", "comment": "comentario"}[k]] = str(tags[k])[:120]
    if any(k for k in tags if "location" in k):
        meta["tem_localizacao_gps"] = True
        av.append("midia_com_gps: a localização não é devolvida por privacidade")
    if audios:
        a = audios[0]
        meta["audio"] = {"codec": a.get("codec_name"), "taxa_amostragem": int(a.get("sample_rate") or 0) or None, "canais": a.get("channels")}
    if videos:
        v = videos[0]
        fr = str(v.get("avg_frame_rate") or "0/1").split("/")
        fps = (float(fr[0]) / float(fr[1])) if len(fr) == 2 and float(fr[1] or 0) else None
        meta["video"] = {"codec": v.get("codec_name"), "largura": v.get("width"), "altura": v.get("height"), "fps": round(fps, 2) if fps else None}
    out = {"familia": familia, "texto": "", "metadados": meta, "avisos": av}
    if dur > cfg.max_duracao_midia_s:
        av.append(f"duracao_acima_do_limite: {int(dur)} s (limite {cfg.max_duracao_midia_s} s); sem transcrição")
        return out
    if opc.get("transcrever") and audios:
        if not cfg.whisper_url:
            av.append("transcricao_indisponivel: WHISPER_URL não configurado")
        else:
            wav = os.path.join(opc["_dir"], "audio.wav")
            rodar(["ffmpeg", "-nostdin", "-v", "error", "-i", caminho, "-vn", "-ac", "1", "-ar", "16000", "-t", str(cfg.max_duracao_midia_s), "-f", "wav", wav], prazo())
            try:
                out["texto"] = transcrever(wav, cfg)
                out["transcricao"] = {"via": "whisper_local"}
            except Exception as e:
                av.append(f"transcricao_falhou: {str(e)[:120]}")
    return out


def transcrever(wav: str, cfg) -> str:
    """Mesmo contrato do Whisper do docker-compose (onerahmet/openai-whisper-asr-webservice, rota /asr)."""
    fronteira = uuid.uuid4().hex
    with open(wav, "rb") as f:
        dados = f.read()
    corpo = (f"--{fronteira}\r\nContent-Disposition: form-data; name=\"audio_file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n").encode() + dados + f"\r\n--{fronteira}--\r\n".encode()
    req = urllib.request.Request(cfg.whisper_url + "/asr?task=transcribe&language=pt&output=json&encode=true", data=corpo, method="POST",
                                 headers={"Content-Type": f"multipart/form-data; boundary={fronteira}"})
    with urllib.request.urlopen(req, timeout=cfg.whisper_tempo_s) as r:
        raw = r.read().decode("utf-8", "replace")
    try:
        j = json.loads(raw)
        return str(j.get("text") or " ".join(s.get("text", "") for s in j.get("segments", []))).strip()
    except json.JSONDecodeError:
        return raw.strip()
