"""PDF: texto digital pelo Poppler (pdftotext); páginas escaneadas passam pelo OCR (Tesseract) quando necessário."""
from __future__ import annotations

import os
import re

from .base import FalhaProcessamento, limpar_texto, rodar
from . import imagem as img


def _info(caminho: str, tempo: float) -> dict:
    r = rodar(["pdfinfo", "-isodates", caminho], tempo, aceitar_erro=True)
    err = (r.stderr or b"").decode("utf-8", "replace")
    if r.returncode != 0:
        if re.search(r"Incorrect password|encrypted", err, re.I):
            raise FalhaProcessamento("documento_protegido", "O PDF está protegido por senha.")
        raise FalhaProcessamento("arquivo_corrompido", "O PDF está corrompido ou não pôde ser lido.")
    meta: dict = {}
    for linha in (r.stdout or b"").decode("utf-8", "replace").splitlines():
        if ":" in linha:
            k, v = linha.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta


def processar(caminho: str, opc: dict, cfg, prazo) -> dict:
    av: list[str] = []
    info = _info(caminho, prazo())
    total = int(re.sub(r"\D", "", info.get("Pages", "0")) or 0)
    if total == 0:
        raise FalhaProcessamento("arquivo_corrompido", "O PDF não tem páginas legíveis.")
    n = min(total, cfg.max_paginas_pdf)
    if n < total:
        av.append(f"paginas_limitadas: lidas {n} de {total}")
    r = rodar(["pdftotext", "-layout", "-enc", "UTF-8", "-f", "1", "-l", str(n), caminho, "-"], prazo())
    paginas = [limpar_texto(p) for p in (r.stdout or b"").decode("utf-8", "replace").split("\f")][:n]
    while len(paginas) < n:
        paginas.append("")
    ocr = opc.get("ocr", "auto")
    ocr_paginas: list[int] = []
    if ocr != "nunca":
        alvo = [i for i, p in enumerate(paginas) if ocr == "sempre" or len(re.sub(r"\s", "", p)) < 25]
        if len(alvo) > cfg.max_paginas_ocr:
            av.append(f"ocr_limitado: {cfg.max_paginas_ocr} de {len(alvo)} páginas escaneadas")
            alvo = alvo[: cfg.max_paginas_ocr]
        confs = []
        for i in alvo:
            base = os.path.join(opc["_dir"], f"pg{i + 1}")
            rodar(["pdftoppm", "-r", "200", "-gray", "-png", "-singlefile", "-f", str(i + 1), "-l", str(i + 1), caminho, base], prazo())
            if opc.get("cardapio"):  # cardápio escaneado: endireita e lê mantendo as colunas
                im, ImageOps = img.abrir(base + ".png", cfg)
                img.preparar_ocr(im, ImageOps, base + "p.png")
                im.close()
                t, conf = img.ocr_cardapio(base + "p.png", cfg, prazo, opc.get("idioma"))
                os.remove(base + "p.png")
            else:
                t, conf = img.ocr_arquivo(base + ".png", cfg, prazo, opc.get("idioma"))
            if t:
                paginas[i] = t
                ocr_paginas.append(i + 1)
                confs.append(conf)
            os.remove(base + ".png")
        if ocr_paginas:
            av.append(f"ocr_aplicado: páginas {', '.join(map(str, ocr_paginas))}")
    meta = {
        "paginas": total,
        "titulo": info.get("Title", ""), "autor": info.get("Author", ""), "criador": info.get("Creator", ""),
        "produtor": info.get("Producer", ""), "criado_em": info.get("CreationDate", ""), "modificado_em": info.get("ModDate", ""),
        "versao_pdf": info.get("PDF version", ""), "criptografado": info.get("Encrypted", "no").startswith("yes"),
        "tamanho_pagina": info.get("Page size", ""),
    }
    out = {"texto": "\n\n".join(p for p in paginas if p), "paginas": [{"numero": i + 1, "texto": p, "ocr": (i + 1) in ocr_paginas} for i, p in enumerate(paginas)],
           "metadados": {k: v for k, v in meta.items() if v not in ("", None)}, "avisos": av, "ocr_usado": bool(ocr_paginas)}
    if opc.get("codigos") and n:
        # boletos e QR Codes impressos: procura nas primeiras páginas renderizadas
        from . import codigos
        achados = []
        for i in range(min(n, 2)):
            base = os.path.join(opc["_dir"], f"cod{i + 1}")
            rodar(["pdftoppm", "-r", "200", "-gray", "-png", "-singlefile", "-f", str(i + 1), "-l", str(i + 1), caminho, base], prazo())
            achados += [dict(c, pagina=i + 1) for c in codigos.ler_arquivo(base + ".png")]
            os.remove(base + ".png")
        out["codigos"] = achados
    return out
