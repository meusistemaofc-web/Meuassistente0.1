"""Identificação do arquivo pelo conteúdo (assinatura binária), nunca só pelo nome ou pelo tipo informado.

Devolve uma "família" interna (pdf, docx, xlsx, csv, txt, imagem, audio, video) ou um motivo de recusa.
"""
from __future__ import annotations

import os
import zipfile
from dataclasses import dataclass, field

SUPORTADOS = ("pdf", "docx", "xlsx", "csv", "txt", "imagem", "audio", "video")

EXT_FAMILIA = {
    ".pdf": "pdf", ".docx": "docx", ".docm": "docx", ".xlsx": "xlsx", ".xlsm": "xlsx", ".csv": "csv", ".txt": "txt",
    ".jpg": "imagem", ".jpeg": "imagem", ".png": "imagem", ".webp": "imagem",
    ".mp3": "audio", ".wav": "audio", ".ogg": "audio", ".oga": "audio", ".opus": "audio", ".m4a": "audio", ".aac": "audio",
    ".flac": "audio", ".amr": "audio", ".weba": "audio",
    ".mp4": "video", ".mov": "video", ".webm": "video", ".mkv": "video", ".3gp": "video", ".avi": "video",
}
MIME_FAMILIA = {
    "pdf": "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "csv": "text/csv", "txt": "text/plain",
}


@dataclass
class Identificacao:
    familia: str | None              # None = recusado
    formato: str                     # formato exato (jpeg, png, webp, mp3, wav, ogg, mp4…)
    mime: str
    motivo: str = ""                 # código da recusa (executavel, formato_nao_suportado, vazio…)
    avisos: list[str] = field(default_factory=list)


def _texto_puro(amostra: bytes) -> bool:
    if not amostra:
        return False
    if b"\x00" in amostra:
        # UTF-16 com BOM ainda é texto
        return amostra[:2] in (b"\xff\xfe", b"\xfe\xff")
    try:
        s = amostra.decode("utf-8")
    except UnicodeDecodeError:
        s = amostra.decode("latin-1")
    controles = sum(1 for c in s if ord(c) < 32 and c not in "\r\n\t\f")
    return controles <= max(2, len(s) // 200)


def _parece_csv(amostra: bytes) -> bool:
    try:
        s = amostra.decode("utf-8-sig", errors="replace")
    except Exception:  # pragma: no cover
        return False
    linhas = [l for l in s.splitlines()[:20] if l.strip()]
    if len(linhas) < 2:
        return False
    for sep in (";", ",", "\t", "|"):
        n = [l.count(sep) for l in linhas]
        if n[0] >= 1 and all(x == n[0] for x in n[: min(len(n), 10)]):
            return True
    return False


def identificar(caminho: str, nome: str = "", mime_declarado: str = "") -> Identificacao:
    tamanho = os.path.getsize(caminho)
    if tamanho == 0:
        return Identificacao(None, "", "", "vazio")
    with open(caminho, "rb") as f:
        cab = f.read(8192)
    ext = os.path.splitext(nome.lower())[1]
    declarado = EXT_FAMILIA.get(ext)
    ident = _por_assinatura(caminho, cab, ext)
    if ident.familia and declarado and declarado != ident.familia and not (
        {declarado, ident.familia} <= {"csv", "txt"} or {declarado, ident.familia} <= {"audio", "video"}
    ):
        ident.avisos.append(f"extensao_divergente: o nome diz {declarado}, o conteúdo é {ident.familia}")
    return ident


def _por_assinatura(caminho: str, cab: bytes, ext: str) -> Identificacao:
    # executáveis e scripts: sempre recusados, qualquer que seja o nome
    if cab[:2] == b"MZ" or cab[:4] == b"\x7fELF" or cab[:4] in (b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe", b"\xca\xfe\xba\xbe"):
        return Identificacao(None, "executavel", "application/octet-stream", "executavel")
    if cab[:2] == b"#!":
        return Identificacao(None, "script", "text/x-script", "executavel")
    idx_pdf = cab[:1024].find(b"%PDF-")
    if idx_pdf >= 0:
        id_ = Identificacao("pdf", "pdf", MIME_FAMILIA["pdf"])
        if idx_pdf > 0:
            id_.avisos.append("pdf_com_dados_antes_do_cabecalho")
        return id_
    if cab[:3] == b"\xff\xd8\xff":
        return Identificacao("imagem", "jpeg", "image/jpeg")
    if cab[:8] == b"\x89PNG\r\n\x1a\n":
        return Identificacao("imagem", "png", "image/png")
    if cab[:4] == b"RIFF" and cab[8:12] == b"WEBP":
        return Identificacao("imagem", "webp", "image/webp")
    if cab[:4] == b"RIFF" and cab[8:12] == b"WAVE":
        return Identificacao("audio", "wav", "audio/wav")
    if cab[:4] == b"RIFF" and cab[8:12] == b"AVI ":
        return Identificacao("video", "avi", "video/x-msvideo")
    if cab[:3] == b"ID3":
        return Identificacao("audio", "mp3", "audio/mpeg")
    if len(cab) > 1 and cab[0] == 0xFF and (cab[1] & 0xE0) == 0xE0 and cab[1] not in (0xFF, 0xFE):
        return Identificacao("audio", "mpeg_audio", "audio/mpeg")  # MP3/AAC sem etiqueta ID3
    if cab[:4] == b"OggS":
        return Identificacao("audio", "ogg", "audio/ogg")
    if cab[:4] == b"fLaC":
        return Identificacao("audio", "flac", "audio/flac")
    if cab[:6] == b"#!AMR\n":
        return Identificacao("audio", "amr", "audio/amr")
    if cab[4:8] == b"ftyp":
        marca = cab[8:12]
        if marca in (b"M4A ", b"M4B ", b"F4A "):
            return Identificacao("audio", "m4a", "audio/mp4")
        if marca[:3] == b"3gp":
            return Identificacao("video", "3gp", "video/3gpp")
        if marca in (b"qt  ",):
            return Identificacao("video", "mov", "video/quicktime")
        if marca in (b"heic", b"heix", b"mif1", b"msf1", b"avif"):
            return Identificacao(None, "heic", "image/heic", "formato_nao_suportado")
        return Identificacao("video", "mp4", "video/mp4")
    if cab[:4] == b"\x1aE\xdf\xa3":
        # Matroska/WebM: áudio ou vídeo; o processador confirma pelas trilhas
        return Identificacao("audio" if ext in (".weba", ".opus") else "video", "webm", "video/webm")
    if cab[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        # .doc/.xls antigos (OLE2): podem trazer macros e não são suportados nesta etapa
        return Identificacao(None, "ole2", "application/x-ole-storage", "formato_antigo_nao_suportado")
    if cab[:4] == b"PK\x03\x04":
        return _zip_office(caminho)
    if cab[:4] in (b"GIF8",) or cab[:2] in (b"BM",) or cab[:4] in (b"II*\x00", b"MM\x00*"):
        return Identificacao(None, "imagem_outra", "image/*", "formato_nao_suportado")
    if cab[:4] in (b"Rar!", b"7z\xbc\xaf") or cab[:2] == b"\x1f\x8b":
        return Identificacao(None, "compactado", "application/octet-stream", "formato_nao_suportado")
    if _texto_puro(cab):
        low = cab[:2048].lstrip().lower()
        avisos = []
        if low.startswith(b"<svg") or b"<svg" in low[:400]:
            return Identificacao(None, "svg", "image/svg+xml", "formato_nao_suportado")
        if low.startswith((b"<!doctype html", b"<html")) or b"<script" in low or low.startswith(b"<?php"):
            avisos.append("conteudo_de_codigo_tratado_como_texto")
        if ext == ".csv" or (ext != ".txt" and _parece_csv(cab)):
            return Identificacao("csv", "csv", "text/csv", avisos=avisos)
        return Identificacao("txt", "txt", "text/plain", avisos=avisos)
    return Identificacao(None, "desconhecido", "application/octet-stream", "formato_nao_suportado")


def _zip_office(caminho: str) -> Identificacao:
    try:
        with zipfile.ZipFile(caminho) as z:
            nomes = set(z.namelist()[:5000])
    except zipfile.BadZipFile:
        return Identificacao(None, "zip", "application/zip", "arquivo_corrompido")
    avisos = []
    if any(n.lower().endswith("vbaproject.bin") for n in nomes):
        avisos.append("contem_macros: as macros não são executadas, só o texto é lido")
    if "word/document.xml" in nomes:
        return Identificacao("docx", "docx", MIME_FAMILIA["docx"], avisos=avisos)
    if "xl/workbook.xml" in nomes:
        return Identificacao("xlsx", "xlsx", MIME_FAMILIA["xlsx"], avisos=avisos)
    return Identificacao(None, "zip", "application/zip", "formato_nao_suportado")
