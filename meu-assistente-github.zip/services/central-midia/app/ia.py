"""Nível 2 (opcional): interpretação com IA SÓ quando pedida e configurada. Recebe o texto já extraído
(o arquivo nunca sai da VPS) e devolve um resumo/estrutura. Falha da IA nunca derruba o nível 1."""
from __future__ import annotations

import json
import re
import urllib.request

PROMPT = """Você recebe o TEXTO já extraído de um arquivo (documento, comprovante, planilha ou transcrição).
Responda SOMENTE com JSON: {"resumo": "até 3 frases", "tipo_documento": "", "campos": {"chave": "valor"}, "pendencias": []}.
Não invente: use apenas o que está no texto. Valores em número, datas AAAA-MM-DD."""


def disponivel(cfg) -> tuple[bool, str]:
    if not cfg.nivel2_ativo:
        return False, "nivel2_desligado"
    if cfg.nivel2_provedor == "ollama" and not cfg.ollama_url:
        return False, "ollama_nao_configurado"
    if cfg.nivel2_provedor == "api" and not (cfg.ia_url and cfg.ia_modelo):
        return False, "api_nao_configurada"
    return True, cfg.nivel2_provedor


def _post(url: str, corpo: dict, cab: dict, tempo: int) -> dict:
    req = urllib.request.Request(url, data=json.dumps(corpo).encode(), method="POST", headers={"Content-Type": "application/json", **cab})
    with urllib.request.urlopen(req, timeout=tempo) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def interpretar(texto: str, contexto: dict, cfg) -> dict:
    ok, via = disponivel(cfg)
    if not ok:
        return {"usado": False, "motivo": via}
    entrada = f"{PROMPT}\n\nContexto (nível 1): {json.dumps(contexto, ensure_ascii=False)[:1500]}\n\nTEXTO:\n{texto[:8000]}"
    try:
        if via == "ollama":
            j = _post(cfg.ollama_url + "/api/generate", {"model": cfg.ollama_modelo, "prompt": entrada, "stream": False, "format": "json", "options": {"temperature": 0}}, {}, cfg.nivel2_tempo_s)
            bruto = j.get("response", "")
            modelo = cfg.ollama_modelo
        else:
            j = _post(cfg.ia_url + "/chat/completions", {"model": cfg.ia_modelo, "temperature": 0, "messages": [{"role": "user", "content": entrada}]},
                      {"Authorization": f"Bearer {cfg.ia_chave}"} if cfg.ia_chave else {}, cfg.nivel2_tempo_s)
            bruto = j["choices"][0]["message"]["content"]
            modelo = cfg.ia_modelo
        m = re.search(r"\{.*\}", bruto, re.S)
        dados = json.loads(m.group(0)) if m else {}
        return {"usado": True, "provedor": via, "modelo": modelo, "resultado": dados}
    except Exception as e:  # rede, tempo, JSON inválido: o nível 1 continua valendo
        return {"usado": False, "motivo": "falha_ia", "detalhe": str(e)[:160]}
