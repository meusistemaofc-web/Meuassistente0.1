"""Extração de informações de comprovantes, boletos e notas SEM IA (nível 1): regras, validação de dígitos
verificadores (boleto, chave de NFC-e, CPF/CNPJ) e interpretação do Pix. Documentos de pessoas saem mascarados."""
from __future__ import annotations

import datetime as dt
import re
import unicodedata

MESES = {"jan": 1, "fev": 2, "mar": 3, "abr": 4, "mai": 5, "jun": 6, "jul": 7, "ago": 8, "set": 9, "out": 10, "nov": 11, "dez": 12}
BANCOS = {"001": "Banco do Brasil", "033": "Santander", "104": "Caixa", "237": "Bradesco", "341": "Itaú", "260": "Nubank", "077": "Inter",
          "336": "C6 Bank", "290": "PagBank", "323": "Mercado Pago", "380": "PicPay", "748": "Sicredi", "756": "Sicoob", "212": "Banco Original",
          "655": "Votorantim", "041": "Banrisul", "070": "BRB", "422": "Safra", "208": "BTG Pactual"}
INSTITUICOES = ["Nubank", "Itaú", "Itau", "Bradesco", "Santander", "Caixa", "Banco do Brasil", "Inter", "C6 Bank", "PicPay", "Mercado Pago", "PagBank",
                "PagSeguro", "Sicredi", "Sicoob", "Neon", "Next", "BTG", "Original", "Banrisul", "Stone", "Cielo", "Rede", "Getnet"]


def _sem_acento(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn").lower()


def valor_br(s: str) -> float | None:
    s = s.strip().replace(" ", "")
    if re.fullmatch(r"\d{1,3}(\.\d{3})*,\d{2}", s) or re.fullmatch(r"\d+,\d{2}", s):
        return float(s.replace(".", "").replace(",", "."))
    if re.fullmatch(r"\d{1,3}(,\d{3})*\.\d{2}", s):
        return float(s.replace(",", ""))
    return None


# ---------- validações de dígitos ----------
def _mod10(num: str) -> int:
    soma, peso = 0, 2
    for d in reversed(num):
        p = int(d) * peso
        soma += p // 10 + p % 10
        peso = 1 if peso == 2 else 2
    r = soma % 10
    return 0 if r == 0 else 10 - r


def _mod11_boleto(num: str) -> int:
    soma, peso = 0, 2
    for d in reversed(num):
        soma += int(d) * peso
        peso = 2 if peso == 9 else peso + 1
    r = 11 - soma % 11
    return 1 if r in (0, 10, 11) else r


def _vencimento(fator: int, hoje: dt.date) -> dt.date | None:
    if fator == 0:
        return None
    c1 = dt.date(1997, 10, 7) + dt.timedelta(days=fator)
    c2 = dt.date(2025, 2, 22) + dt.timedelta(days=fator - 1000) if fator >= 1000 else None  # reinício do fator (fev/2025)
    cand = [c for c in (c1, c2) if c]
    return min(cand, key=lambda c: abs((c - hoje).days))


def boleto(linha: str, hoje: dt.date | None = None) -> dict | None:
    d = re.sub(r"\D", "", linha)
    hoje = hoje or dt.date.today()
    if len(d) == 47:  # boleto bancário (linha digitável)
        campos = [(d[0:9], d[9]), (d[10:20], d[20]), (d[21:31], d[31])]
        dv_ok = all(_mod10(c) == int(v) for c, v in campos)
        barras = d[0:4] + d[32] + d[33:47] + d[4:9] + d[10:20] + d[21:31]
        geral_ok = _mod11_boleto(barras[:4] + barras[5:]) == int(barras[4])
        fator, valor = int(d[33:37]), int(d[37:47]) / 100
        venc = _vencimento(fator, hoje)
        return {"tipo": "bancario", "linha_digitavel": d, "codigo_barras": barras, "valido": dv_ok and geral_ok,
                "banco": BANCOS.get(d[0:3], d[0:3]), "valor": valor or None, "vencimento": venc.isoformat() if venc else None}
    if len(d) == 48 and d[0] == "8":  # arrecadação (contas de consumo, tributos)
        blocos = [d[i * 12:(i + 1) * 12] for i in range(4)]
        ref = d[2]
        def dv(b):
            return _mod10(b) if ref in "67" else (lambda s: 0 if s in (0, 1) else 11 - s)(sum(int(x) * p for x, p in zip(reversed(b), [2, 3, 4, 5, 6, 7, 8, 9] * 3)) % 11)
        ok = all(dv(b[:11]) == int(b[11]) for b in blocos)
        barras = "".join(b[:11] for b in blocos)
        return {"tipo": "arrecadacao", "linha_digitavel": d, "codigo_barras": barras, "valido": ok, "valor": int(barras[4:15]) / 100 or None}
    return None


def chave_nfe(d: str) -> bool:
    if len(d) != 44:
        return False
    soma = sum(int(x) * p for x, p in zip(reversed(d[:43]), [2, 3, 4, 5, 6, 7, 8, 9] * 6))
    r = soma % 11
    return int(d[43]) == (0 if r < 2 else 11 - r)


def _cpf_ok(d: str) -> bool:
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        if (s * 10 % 11) % 10 != int(d[n]):
            return False
    return True


def _cnpj_ok(d: str) -> bool:
    if len(d) != 14 or d == d[0] * 14:
        return False
    for n, pesos in ((12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]), (13, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])):
        s = sum(int(d[i]) * pesos[i] for i in range(n))
        r = s % 11
        if (0 if r < 2 else 11 - r) != int(d[n]):
            return False
    return True


def _mascara(d: str) -> str:
    if len(d) == 11:
        return f"***.{d[3:6]}.{d[6:9]}-**"
    return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"  # CNPJ é de empresa: público


# ---------- extração ----------
def _datas(t: str) -> list[str]:
    out = []
    for d, m, a in re.findall(r"\b(\d{2})[/.-](\d{2})[/.-](\d{4}|\d{2})\b", t):
        a = int(a) + (2000 if len(a) == 2 else 0)
        try:
            out.append(dt.date(a, int(m), int(d)).isoformat())
        except ValueError:
            pass
    for d, m, a in re.findall(r"\b(\d{1,2})\s*(?:de\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-zç]*\.?\s*(?:de\s+)?(\d{4})\b", _sem_acento(t)):
        try:
            out.append(dt.date(int(a), MESES[m], int(d)).isoformat())
        except ValueError:
            pass
    return list(dict.fromkeys(out))


def extrair(texto: str, codigos: list[dict] | None = None, hoje: dt.date | None = None) -> dict | None:
    t = texto or ""
    low = _sem_acento(t)
    pix_qr = next((c["pix"] for c in (codigos or []) if c.get("pix")), None)
    sinais = re.findall(r"comprovante|pix|transferencia|pagamento|boleto|recibo|nota fiscal|nfc-?e|cupom fiscal|valor|total|ted\b|doc\b|debito|credito|autenticacao", low)
    linhas_bol = re.findall(r"(?<!\d)(\d{5}[.\s]?\d{5}\s?\d{5}[.\s]?\d{6}\s?\d{5}[.\s]?\d{6}\s?\d\s?\d{14})(?!\d)|(?<!\d)(8\d{10}[-\s]?\d\s?\d{11}[-\s]?\d\s?\d{11}[-\s]?\d\s?\d{11}[-\s]?\d)(?!\d)", t)
    bol = None
    for a, b in linhas_bol:
        bol = boleto(a or b, hoje)
        if bol:
            break
    if len(sinais) < 2 and not bol and not pix_qr:
        return None
    r: dict = {}
    # valores: prioriza o que vem depois de "valor"/"total"; senão o maior com R$
    rotulados = [valor_br(v) for v in re.findall(r"(?:valor(?: total| pago| da transfer[eê]ncia| do pagamento)?|total(?: a pagar| pago)?)\s*[:\-]?\s*(?:R\$)?\s*([\d.,]+\d)", t, re.I)]
    com_rs = [valor_br(v) for v in re.findall(r"R\$\s*([\d.,]+\d)", t)]
    valores = [v for v in rotulados + com_rs if v]
    if valores:
        r["valores"] = list(dict.fromkeys(valores))[:10]
        r["valor"] = next((v for v in rotulados if v), max(com_rs) if [v for v in com_rs if v] else valores[0])
    datas = _datas(t)
    if datas:
        r["datas"] = datas[:6]
        r["data"] = datas[0]
    hora = re.search(r"\b([01]\d|2[0-3])[:h]([0-5]\d)(?::([0-5]\d))?\b", t)
    if hora:
        r["hora"] = f"{hora.group(1)}:{hora.group(2)}"
    # tipo e direção (perspectiva de quem enviou o arquivo)
    if bol:
        r["tipo"] = "boleto"
        r["boleto"] = bol
        r.setdefault("valor", bol.get("valor"))
    elif "pix" in low or pix_qr:
        r["tipo"] = "pix"
    elif re.search(r"\bted\b|\bdoc\b|transferencia", low):
        r["tipo"] = "transferencia"
    elif re.search(r"nfc-?e|nota fiscal|cupom fiscal|danfe", low):
        r["tipo"] = "nota_fiscal"
    elif re.search(r"cartao|credito|debito", low):
        r["tipo"] = "cartao"
    elif "recibo" in low:
        r["tipo"] = "recibo"
    if re.search(r"pix enviado|transferencia enviada|voce (pagou|enviou|transferiu)|pagamento (efetuado|realizado)|comprovante de pagamento", low):
        r["direcao"] = "saida"
    elif re.search(r"pix recebido|transferencia recebida|voce recebeu|recebimento|credito em conta", low):
        r["direcao"] = "entrada"
    else:
        r["direcao"] = "incerta"
    e2e = re.search(r"\b(E\d{8}\d{12}[A-Za-z0-9]{11})\b", t)
    if e2e:
        r.setdefault("pix", {})["id_transacao"] = e2e.group(1)
    if pix_qr:
        r.setdefault("pix", {}).update({k: v for k, v in pix_qr.items() if v not in ("", None)})
        if pix_qr.get("valor") and "valor" not in r:
            r["valor"] = pix_qr["valor"]
    chave_txt = re.search(r"chave(?: pix)?\s*:?\s*([\w.+-]+@[\w-]+\.[\w.]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\+?55\s?\(?\d{2}\)?\s?9?\d{4}-?\d{4})", t, re.I)
    if chave_txt:
        r.setdefault("pix", {})["chave"] = chave_txt.group(1)
    nfe = next((d for d in (re.sub(r"\D", "", x) for x in re.findall(r"(?:\d{4}\s?){11}", t)) if chave_nfe(d)), None)
    if nfe:
        r["nfce"] = {"chave_acesso": nfe, "valida": True, "uf": nfe[:2], "cnpj_emitente": _mascara(nfe[6:20]), "modelo": nfe[20:22]}
    docs = []
    for m in re.findall(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b|\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b", t):
        d = re.sub(r"\D", "", m)
        if (len(d) == 14 and _cnpj_ok(d)) or (len(d) == 11 and _cpf_ok(d)):
            docs.append({"tipo": "cnpj" if len(d) == 14 else "cpf", "numero": _mascara(d)})
    if docs:
        r["documentos"] = list({x["numero"]: x for x in docs}.values())[:6]
    inst = [i for i in INSTITUICOES if re.search(r"\b" + re.escape(_sem_acento(i)) + r"\b", low)]
    if inst:
        r["instituicoes"] = list(dict.fromkeys(i.replace("Itau", "Itaú") for i in inst))[:4]
    pontos = sum(1 for k in ("valor", "data", "tipo") if r.get(k)) + (1 if bol and bol.get("valido") else 0) + (1 if r.get("pix", {}).get("id_transacao") or (pix_qr and pix_qr.get("crc_valido")) else 0)
    r["confianca"] = round(min(1.0, pontos / 4), 2)
    r["campos_essenciais_faltando"] = [k for k in ("valor", "data", "tipo") if not r.get(k)]
    return r
