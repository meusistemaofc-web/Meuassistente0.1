"""Extração de informações de comprovantes, boletos e notas SEM IA (nível 1): regras, validação de dígitos
verificadores (boleto, chave de NFC-e, CPF/CNPJ) e interpretação do Pix. Documentos de pessoas saem mascarados."""
from __future__ import annotations

import datetime as dt
import re
import unicodedata

MESES = {"jan": 1, "fev": 2, "mar": 3, "abr": 4, "mai": 5, "jun": 6, "jul": 7, "ago": 8, "set": 9, "out": 10, "nov": 11, "dez": 12}
BANCOS = {"001": "Banco do Brasil", "033": "Santander", "104": "Caixa", "237": "Bradesco", "341": "Itaú", "260": "Nubank", "077": "Inter",
          "336": "C6 Bank", "290": "PagBank", "323": "Mercado Pago", "380": "PicPay", "748": "Sicredi", "756": "Sicoob", "212": "Banco Original",
          "655": "Votorantim", "041": "Banrisul", "070": "BRB", "422": "Safra", "208": "BTG Pactual"}
INSTITUICOES = ["Nubank", "Itaú", "Itau", "Bradesco", "Santander", "Caixa", "Banco do Brasil", "Inter", "C6 Bank", "PicPay", "Mercado Pago", "PagBank",
                "PagSeguro", "Sicredi", "Sicoob", "Neon", "Next", "BTG", "Original", "Banrisul", "Stone", "Cielo", "Rede", "Getnet"]


def _sem_acento(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn").lower()


def valor_br(s: str) -> float | None:
    s = s.strip().replace(" ", "")
    if re.fullmatch(r"\d{1,3}(\.\d{3})*,\d{2}", s) or re.fullmatch(r"\d+,\d{2}", s):
        return float(s.replace(".", "").replace(",", "."))
    if re.fullmatch(r"\d{1,3}(,\d{3})*\.\d{2}", s):
        return float(s.replace(",", ""))
    return None


# ---------- validações de dígitos ----------
def _mod10(num: str) -> int:
    soma, peso = 0, 2
    for d in reversed(num):
        p = int(d) * peso
        soma += p // 10 + p % 10
        peso = 1 if peso == 2 else 2
    r = soma % 10
    return 0 if r == 0 else 10 - r


def _mod11_boleto(num: str) -> int:
    soma, peso = 0, 2
    for d in reversed(num):
        soma += int(d) * peso
        peso = 2 if peso == 9 else peso + 1
    r = 11 - soma % 11
    return 1 if r in (0, 10, 11) else r


def _vencimento(fator: int, hoje: dt.date) -> dt.date | None:
    if fator == 0:
        return None
    c1 = dt.date(1997, 10, 7) + dt.timedelta(days=fator)
    c2 = dt.date(2025, 2, 22) + dt.timedelta(days=fator - 1000) if fator >= 1000 else None  # reinício do fator (fev/2025)
    cand = [c for c in (c1, c2) if c]
    return min(cand, key=lambda c: abs((c - hoje).days))


def boleto(linha: str, hoje: dt.date | None = None) -> dict | None:
    d = re.sub(r"\D", "", linha)
    hoje = hoje or dt.date.today()
    if len(d) == 47:  # boleto bancário (linha digitável)
        campos = [(d[0:9], d[9]), (d[10:20], d[20]), (d[21:31], d[31])]
        dv_ok = all(_mod10(c) == int(v) for c, v in campos)
        barras = d[0:4] + d[32] + d[33:47] + d[4:9] + d[10:20] + d[21:31]
        geral_ok = _mod11_boleto(barras[:4] + barras[5:]) == int(barras[4])
        fator, valor = int(d[33:37]), int(d[37:47]) / 100
        venc = _vencimento(fator, hoje)
        return {"tipo": "bancario", "linha_digitavel": d, "codigo_barras": barras, "valido": dv_ok and geral_ok,
                "banco": BANCOS.get(d[0:3], d[0:3]), "valor": valor or None, "vencimento": venc.isoformat() if venc else None}
    if len(d) == 48 and d[0] == "8":  # arrecadação (contas de consumo, tributos)
        blocos = [d[i * 12:(i + 1) * 12] for i in range(4)]
        ref = d[2]
        def dv(b):
            return _mod10(b) if ref in "67" else (lambda s: 0 if s in (0, 1) else 11 - s)(sum(int(x) * p for x, p in zip(reversed(b), [2, 3, 4, 5, 6, 7, 8, 9] * 3)) % 11)
        ok = all(dv(b[:11]) == int(b[11]) for b in blocos)
        barras = "".join(b[:11] for b in blocos)
        return {"tipo": "arrecadacao", "linha_digitavel": d, "codigo_barras": barras, "valido": ok, "valor": int(barras[4:15]) / 100 or None}
    return None


def chave_nfe(d: str) -> bool:
    if len(d) != 44:
        return False
    soma = sum(int(x) * p for x, p in zip(reversed(d[:43]), [2, 3, 4, 5, 6, 7, 8, 9] * 6))
    r = soma % 11
    return int(d[43]) == (0 if r < 2 else 11 - r)


def _cpf_ok(d: str) -> bool:
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        if (s * 10 % 11) % 10 != int(d[n]):
            return False
    return True


def _cnpj_ok(d: str) -> bool:
    if len(d) != 14 or d == d[0] * 14:
        return False
    for n, pesos in ((12, [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]), (13, [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2])):
        s = sum(int(d[i]) * pesos[i] for i in range(n))
        r = s % 11
        if (0 if r < 2 else 11 - r) != int(d[n]):
            return False
    return True


def _mascara(d: str) -> str:
    if len(d) == 11:
        return f"***.{d[3:6]}.{d[6:9]}-**"
    return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"  # CNPJ é de empresa: público


# ---------- extração ----------
ROT_RECEBEDOR = r"para|destino|destinat[aá]rio|recebedor|favorecido|benefici[aá]rio|nome do recebedor|nome do favorecido|quem recebeu|enviado para|transferido para|pago a|pagamento para"
ROT_PAGADOR = r"de|origem|pagador|nome do pagador|quem pagou|enviado por|remetente|pago por"
ROT_VALOR = r"valor(?: total| pago| da transfer[eê]ncia| do pagamento| do pix| enviado| recebido| a pagar)?|total(?: a pagar| pago| r\$)?|total r\$|voc[eê] (?:recebeu|pagou|enviou|transferiu)|quantia"
ROT_DATA = r"data(?: da transfer[eê]ncia| do pagamento| da opera[cç][aã]o| e hora|/hora| de emiss[aã]o| do pix)?|em|realizad[oa] em|efetuad[oa] em|emiss[aã]o|pago em|data da transa[cç][aã]o"
ROT_HORA = r"hor[aá]rio|hora"
CATEGORIAS = [  # (categoria, palavras): só sugestão, sempre apresentada para revisão
    ("combustivel", r"posto|combust[ií]vel|gasolina|etanol|diesel|ipiranga|shell|petrobras|br distribuidora|ale combust"),
    ("alimentacao", r"padaria|supermercado|mercado|mercadinho|restaurante|lanchonete|pizzaria|hamburgueria|a[cç]ougue|hortifruti|ifood|sorveteria|cafeteria|atacad[aã]o|assa[ií]|carrefour|p[aã]o de a[cç][uú]car"),
    ("saude", r"farm[aá]cia|drogaria|drogasil|pague menos|hospital|cl[ií]nica|laborat[oó]rio|odonto|m[eé]dic"),
    ("transporte", r"\buber\b|\b99\b|99 ?app|[oô]nibus|metr[oô]|estacionamento|ped[aá]gio|sem parar|taxi|t[aá]xi"),
    ("casa", r"energia|enel|coelce|cemig|light s|copel|celpe|coelba|[aá]gua|cagece|sabesp|compesa|internet|vivo|claro|tim\b|oi fibra|aluguel|condom[ií]nio|g[aá]s\b|ultragaz|liquig[aá]s"),
    ("lazer", r"cinema|netflix|spotify|disney|show|ingresso|teatro|parque"),
    ("compras", r"loja|magazine|shopping|americanas|shopee|mercado livre|amazon|renner|riachuelo|c&a"),
]


def _datas(t: str) -> list[str]:
    out = []
    for d, m, a in re.findall(r"\b(\d{2})[/.-](\d{2})[/.-](\d{4}|\d{2})\b", t):
        a = int(a) + (2000 if len(a) == 2 else 0)
        try:
            out.append(dt.date(a, int(m), int(d)).isoformat())
        except ValueError:
            pass
    for d, m, a in re.findall(r"\b(\d{1,2})\s*(?:de\s+)?(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)[a-zç]*\.?\s*(?:de\s+)?(\d{4})\b", _sem_acento(t)):
        try:
            out.append(dt.date(int(a), MESES[m], int(d)).isoformat())
        except ValueError:
            pass
    return list(dict.fromkeys(out))


def _ocr_fix(t: str) -> str:
    """Correções típicas de OCR em valores e datas: 'RS 10,00'/'R5' → 'R$', letras no meio de números."""
    t = re.sub(r"\bR\s?[S5\$]\s?(?=\d)", "R$ ", t)
    t = re.sub(r"\bR\$(?=\d)", "R$ ", t)
    def nums(m):
        x = m.group(0)
        return x.replace("O", "0").replace("o", "0").replace("l", "1").replace("I", "1") if sum(c.isdigit() for c in x) >= 2 else x
    return re.sub(r"(?<![A-Za-z])[\dOolI]{1,3}(?:[.,][\dOolI]{3})*[.,][\dOolI]{2}(?![A-Za-z\d])", nums, t)


def _linhas(t: str) -> list[str]:
    return [l.strip() for l in t.splitlines()]


def _campo(linhas: list[str], rotulos: str, precisa: str | None = None) -> tuple[str, int] | None:
    """Valor de um rótulo: na mesma linha ("Valor: R$ 10", "Valor   R$ 10") ou na linha seguinte (rótulo sozinho).
    `precisa`: o valor tem que conter esse padrão (ex.: um número); se não tiver, procura na linha seguinte."""
    rx_mesma = re.compile(r"^(?:" + rotulos + r")\s*(?::|-|–|\s{2,}|\s)\s*(\S.*)$", re.I)
    rx_so = re.compile(r"^(?:" + rotulos + r")\s*:?$", re.I)
    ok = (lambda v: bool(re.search(precisa, v))) if precisa else (lambda v: True)
    for i, l in enumerate(linhas):
        m = rx_mesma.match(l)
        if m and ok(m.group(1)):
            return m.group(1).strip(), i
        if rx_so.match(l) or (m and not ok(m.group(1))):
            for j in range(i + 1, min(i + 3, len(linhas))):
                if linhas[j]:
                    if ok(linhas[j]):
                        return linhas[j], j
                    break
    return None


def _nome(v: str | None) -> str | None:
    if not v:
        return None
    v = re.split(r"\s{3,}|\s+(?:CPF|CNPJ|CNP\)|Ag[eê]ncia|Conta|Chave|Institui[cç][aã]o)\b", v, maxsplit=1, flags=re.I)[0]
    v = re.sub(r"[\*•·]+", " ", v).strip(" :-–,.")
    letras = sum(c.isalpha() for c in v)
    if len(v) < 3 or len(v) > 80 or letras < 3 or letras < len(v.replace(" ", "")) * 0.6:
        return None
    if re.fullmatch(r"(?i)(pix|r\$.*|valor|data|nome|cpf|cnpj|conta|ag[eê]ncia|institui[cç][aã]o|destino|origem|transfer[eê]ncia|comprovante)", v):
        return None
    return v


def _secoes(linhas: list[str]) -> dict:
    """Layout em seções ("Destino" / "Origem" seguidos de "Nome   Fulano")."""
    out, sec = {}, None
    for l in linhas:
        b = _sem_acento(l).strip(" :")
        if re.fullmatch(r"(destino|para|recebedor|favorecido|beneficiario|quem recebeu)", b):
            sec = "recebedor"
            continue
        if re.fullmatch(r"(origem|de|pagador|quem pagou|remetente)", b):
            sec = "pagador"
            continue
        m = re.match(r"^nome(?: completo)?\s*(?::|\s{2,}|\s)\s*(\S.*)$", l, re.I)
        if sec and m and sec not in out:
            n = _nome(m.group(1))
            if n:
                out[sec] = n
    return out


def _direcao(low: str) -> tuple[str, str, list[str]]:
    sinais_s = [(r"pix enviado|transferencia enviada|voce (pagou|enviou|transferiu)|pagamento (efetuado|realizado|concluido|aprovado)|valor pago|boleto pago|comprovante de pagamento", 2, "texto indica pagamento/envio"),
                (r"nfc-?e|nota fiscal|cupom fiscal|danfe|documento auxiliar", 2, "nota/cupom fiscal de compra"),
                (r"comprovante de transferencia|transferencia realizada|pix realizado", 1, "comprovante de transferência")]
    sinais_e = [(r"pix recebido|transferencia recebida|voce recebeu|recebimento|credito em conta|deposito recebido|valor recebido", 2, "texto indica recebimento")]
    s = sum(p for rx, p, _ in sinais_s if re.search(rx, low))
    e = sum(p for rx, p, _ in sinais_e if re.search(rx, low))
    motivos = [m for rx, _, m in sinais_s + sinais_e if re.search(rx, low)]
    if s and e:
        return "incerta", "baixa", motivos + ["sinais de entrada e saída ao mesmo tempo"]
    if s:
        return "saida", "alta" if s >= 2 else "media", motivos
    if e:
        return "entrada", "alta" if e >= 2 else "media", motivos
    return "incerta", "baixa", ["nenhum sinal de direção no texto"]


def extrair(texto: str, codigos: list[dict] | None = None, hoje: dt.date | None = None, ocr_confianca: float | None = None) -> dict | None:
    t = _ocr_fix(texto or "")
    low = _sem_acento(t)
    linhas = _linhas(t)
    pix_qr = next((c["pix"] for c in (codigos or []) if c.get("pix")), None)
    sinais = re.findall(r"comprovante|pix|transferencia|pagamento|boleto|recibo|nota fiscal|nfc-?e|cupom fiscal|valor|total|ted\b|doc\b|debito|credito|autenticacao|recebeu|recebido|enviado|r\$", low)
    linhas_bol = re.findall(r"(?<!\d)(\d{5}[.\s]?\d{5}\s?\d{5}[.\s]?\d{6}\s?\d{5}[.\s]?\d{6}\s?\d\s?\d{14})(?!\d)|(?<!\d)(8\d{10}[-\s]?\d\s?\d{11}[-\s]?\d\s?\d{11}[-\s]?\d\s?\d{11}[-\s]?\d)(?!\d)", t)
    bol = None
    for a, b in linhas_bol:
        bol = boleto(a or b, hoje)
        if bol:
            break
    if len(sinais) < 2 and not bol and not pix_qr:
        return None
    r: dict = {}
    conf: dict = {}
    # ---- valor ----
    rot = _campo(linhas, ROT_VALOR, r"\d,\d{2}|\d\.\d{2}\b")
    v_rot = None
    if rot:
        m = re.search(r"(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2}|\d{1,3}(?:,\d{3})*\.\d{2})", rot[0])
        v_rot = valor_br(m.group(1)) if m else None
    totais = [valor_br(v) for v in re.findall(r"(?:^|\n)\s*TOTAL(?: R\$)?\s*(?::|\s)\s*(?:R\$\s*)?([\d.,]+\d)", t, re.I)]
    totais = [v for v in totais if v]
    com_rs = [v for v in (valor_br(x) for x in re.findall(r"R\$\s*([\d.,]+\d)", t)) if v]
    if totais:
        r["valor"], conf["valor"] = totais[-1], "alta"
    elif v_rot:
        r["valor"], conf["valor"] = v_rot, "alta"
    elif bol and bol.get("valido") and bol.get("valor"):
        r["valor"], conf["valor"] = bol["valor"], "alta"
    elif pix_qr and pix_qr.get("valor") and pix_qr.get("crc_valido"):
        r["valor"], conf["valor"] = pix_qr["valor"], "alta"
    elif com_rs:
        unicos = sorted(set(com_rs))
        r["valor"], conf["valor"] = max(unicos), ("media" if len(unicos) == 1 else "baixa")
    valores = [x for x in [v_rot] + totais + com_rs if x]
    if valores:
        r["valores"] = list(dict.fromkeys(valores))[:10]
    # ---- data e hora ----
    datas = _datas(t)
    rot_d = _campo(linhas, ROT_DATA, r"\d")
    d_rot = _datas(rot_d[0]) if rot_d else []
    if d_rot:
        r["data"], conf["data"] = d_rot[0], "alta"
    elif datas:
        r["data"], conf["data"] = datas[0], ("media" if len(set(datas)) == 1 else "baixa")
    if datas:
        r["datas"] = datas[:6]
    rx_h = r"\b([01]\d|2[0-3])[:h]([0-5]\d)(?::([0-5]\d))?\b"
    rot_h = _campo(linhas, ROT_HORA, r"\d")
    h = re.search(rx_h, rot_h[0]) if rot_h else None
    if not h and rot_d:
        h = re.search(rx_h, rot_d[0])
    if h:
        r["hora"], conf["hora"] = f"{h.group(1)}:{h.group(2)}", "alta"
    else:
        h = re.search(rx_h, t)
        if h:
            r["hora"], conf["hora"] = f"{h.group(1)}:{h.group(2)}", "media"
    # ---- tipo e forma de pagamento ----
    if bol:
        r["tipo"] = "boleto"
        r["boleto"] = bol
    elif re.search(r"nfc-?e|nota fiscal|cupom fiscal|danfe|documento auxiliar", low):
        r["tipo"] = "nota_fiscal"
    elif re.search(r"\bboleto\b", low):
        r["tipo"] = "boleto"  # comprovante de boleto sem linha digitável legível
    elif "pix" in low or pix_qr:
        r["tipo"] = "pix"
    elif re.search(r"\bted\b|\bdoc\b|transferencia", low):
        r["tipo"] = "transferencia"
    elif re.search(r"cartao|credito|debito", low):
        r["tipo"] = "cartao"
    elif "recibo" in low:
        r["tipo"] = "recibo"
    if r.get("tipo"):
        conf["tipo"] = "alta"
    if re.search(r"cartao de debito|\bdebito\b", low):
        r["forma_pagamento"] = "Cartão de débito"
    elif re.search(r"cartao de credito|\bcredito\b(?! em conta)", low):
        r["forma_pagamento"] = "Cartão de crédito"
    elif r.get("tipo") == "pix":
        r["forma_pagamento"] = "Pix"
    elif r.get("tipo") == "boleto":
        r["forma_pagamento"] = "Boleto"
    elif re.search(r"\bted\b|\bdoc\b", low):
        r["forma_pagamento"] = "TED/DOC"
    elif r.get("tipo") == "transferencia":
        r["forma_pagamento"] = "Transferência"
    elif re.search(r"\bdinheiro\b", low):
        r["forma_pagamento"] = "Dinheiro"
    # ---- direção (só pelo texto; o app soma o sinal do titular, que nunca decide sozinho) ----
    r["direcao"], conf["direcao"], r["direcao_motivos"] = _direcao(low)
    # ---- quem recebeu / quem pagou / estabelecimento (só o que está escrito; nada é inventado) ----
    sec = _secoes(linhas)
    rec = sec.get("recebedor") or _nome((_campo(linhas, ROT_RECEBEDOR) or ("", 0))[0])
    pag = sec.get("pagador") or _nome((_campo(linhas, ROT_PAGADOR) or ("", 0))[0])
    if pix_qr and pix_qr.get("recebedor") and not rec:
        rec = pix_qr["recebedor"]
    if rec:
        r["recebedor"] = rec
    if pag:
        r["pagador"] = pag
    est = None
    if r.get("tipo") == "nota_fiscal":
        for l in linhas[:6]:
            if re.search(r"\b(LTDA|ME|EIRELI|S/?A|EPP|COMERCIO|SUPERMERCADO|MERCADO|FARMACIA|DROGARIA|POSTO|RESTAURANTE|PADARIA)\b", _sem_acento(l).upper()) and not re.search(r"\d{2}\.\d{3}", l):
                est = l.strip()
                break
    if est:
        r["estabelecimento"], conf["estabelecimento"] = est, "media"
    elif r["direcao"] == "saida" and rec:
        r["estabelecimento"], conf["estabelecimento"] = rec, "alta"
    elif r["direcao"] == "entrada" and pag:
        r["estabelecimento"], conf["estabelecimento"] = pag, "alta"
    # ---- categoria: só sugestão por palavra-chave, sempre para revisão ----
    alvo = _sem_acento(" ".join(x for x in (r.get("estabelecimento"), rec, " ".join(linhas[:3])) if x))
    if r["direcao"] != "entrada":
        for cat, rx in CATEGORIAS:
            if re.search(rx, alvo):
                r["categoria"], conf["categoria"] = cat, "media"
                break
    # ---- identificadores ----
    e2e = re.search(r"\b(E\d{8}\d{12}[A-Za-z0-9]{11})\b", t.replace(" ", ""))
    if e2e:
        r.setdefault("pix", {})["id_transacao"] = e2e.group(1)
    if pix_qr:
        r.setdefault("pix", {}).update({k: v for k, v in pix_qr.items() if v not in ("", None)})
    chave_txt = re.search(r"chave(?: pix)?\s*:?\s*([\w.+-]+@[\w-]+\.[\w.]+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\+?55\s?\(?\d{2}\)?\s?9?\d{4}-?\d{4})", t, re.I)
    if chave_txt:
        r.setdefault("pix", {})["chave"] = chave_txt.group(1)
    nfe = next((d for d in (re.sub(r"\D", "", x) for x in re.findall(r"(?:\d{4}\s?){11}", t)) if chave_nfe(d)), None)
    if nfe:
        r["nfce"] = {"chave_acesso": nfe, "valida": True, "uf": nfe[:2], "cnpj_emitente": _mascara(nfe[6:20]), "modelo": nfe[20:22]}
    docs = []
    for m in re.findall(r"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b|\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b", t):
        d = re.sub(r"\D", "", m)
        if (len(d) == 14 and _cnpj_ok(d)) or (len(d) == 11 and _cpf_ok(d)):
            docs.append({"tipo": "cnpj" if len(d) == 14 else "cpf", "numero": _mascara(d)})
    if docs:
        r["documentos"] = list({x["numero"]: x for x in docs}.values())[:6]
    inst = [i for i in INSTITUICOES if re.search(r"\b" + re.escape(_sem_acento(i)) + r"\b", low)]
    if inst:
        r["instituicoes"] = list(dict.fromkeys(i.replace("Itau", "Itaú") for i in inst))[:4]
    # ---- confiança: OCR fraco rebaixa tudo que veio dele ----
    if ocr_confianca is not None and ocr_confianca < 0.75:
        conf = {k: ("media" if v == "alta" else "baixa") for k, v in conf.items()}
    r["confianca_campos"] = conf
    r["faltando"] = [k for k in ("valor", "data") if not r.get(k)] + (["direcao"] if r["direcao"] == "incerta" else [])
    r["revisar"] = [k for k in ("valor", "data", "hora", "estabelecimento", "categoria", "direcao") if conf.get(k) in ("media", "baixa")]
    pontos = sum(1 for k in ("valor", "data", "tipo") if conf.get(k) == "alta") + (1 if conf.get("direcao") == "alta" else 0)
    r["confianca"] = round(min(1.0, pontos / 4), 2)
    r["campos_essenciais_faltando"] = r["faltando"]
    return r
