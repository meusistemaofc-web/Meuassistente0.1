"""Interpretação de CARDÁPIOS por regras (nível 1, sem IA): categorias, produtos, descrições, preços, tamanhos,
adicionais e observações, na ordem em que aparecem.

Princípios:
- nada é inventado: o que não foi lido fica vazio; dúvida vira "duvida" (o app marca o item para revisão);
- preço é sempre um número lido no texto (com as correções típicas de OCR registradas como dúvida);
- tamanhos/variações só com rótulo lido (P/M/G, 300 ml, Broto…); vários preços sem rótulo = dúvida;
- adicionais (seção "Adicionais", linhas "+ Bacon 4,00") são separados dos produtos.

Entrada: texto (PDF digital com -layout, OCR reconstruído por posição ou texto de DOCX). Palavras com baixa confiança
no OCR chegam marcadas com "⁇" no início.
"""
from __future__ import annotations

import re
import unicodedata

MARCA = "⁇"  # palavra lida com baixa confiança pelo OCR

# ---------------------------------------------------------------- colunas
_PRECO_SO = re.compile(r"^\s*(?:R\s?\$|RS|R5)?\s*\d{1,4}(?:[.,]\d{2})?\s*$", re.I)


def _so_valores(d: str) -> bool:
    """Trecho só com preços e/ou rótulos de tamanho ("28,00  42,00", "Broto  Média  Grande", "R$ 5,00")."""
    resto = _TOK_PRECO.sub(" ", d)
    resto = " ".join(p for p in resto.split() if not _TAM_RE.match(_sem(p)) and _sem(p) not in ("r$", "rs"))
    return _letras(resto) < 3


def _divisao(linhas: list[str]) -> tuple[int, int] | None:
    """Acha uma "calha" vertical (colunas de caracteres quase sempre vazias) no meio da página."""
    cheias = [l for l in linhas if l.strip()]
    if len(cheias) < 6:
        return None
    w = max(len(l) for l in cheias)
    if w < 40:
        return None
    vazia = []
    for c in range(w):
        n = sum(1 for l in cheias if c < len(l) and l[c] != " ")
        vazia.append(n <= max(1, len(cheias) * 0.08))
    melhor = None
    c = int(w * 0.22)
    while c < int(w * 0.78):
        if vazia[c]:
            ini = c
            while c < w and vazia[c]:
                c += 1
            if c - ini >= 2 and (melhor is None or abs((ini + c) / 2 - w / 2) < abs(sum(melhor) / 2 - w / 2)):
                melhor = (ini, c)
        c += 1
    if not melhor:
        return None
    meio = (melhor[0] + melhor[1]) // 2
    esq = [l[:meio].strip() for l in cheias]
    dir_ = [l[meio:].strip() for l in cheias if len(l) > meio]
    dir_ = [d for d in dir_ if d]
    if len([e for e in esq if e]) < len(cheias) * 0.3 or len(dir_) < len(cheias) * 0.3:
        return None
    # coluna de PREÇOS/TAMANHOS (nome à esquerda, valores à direita) não é outra coluna do cardápio
    if sum(1 for d in dir_ if _so_valores(d)) >= len(dir_) * 0.5:
        return None
    return melhor


def colunas(texto: str, nivel: int = 0) -> str:
    """Cardápio em 2 ou 3 colunas lado a lado (PDF com -layout ou OCR por posição): devolve as colunas uma depois da
    outra, respeitando faixas horizontais (títulos que atravessam a página ficam no lugar)."""
    linhas = texto.split("\n")
    d = _divisao(linhas) if nivel < 2 else None
    if not d:
        return texto
    ini, fim = d
    meio = (ini + fim) // 2
    blocos: list[str] = []
    esq: list[str] = []
    dir_: list[str] = []

    def fecha():
        if esq or dir_:
            blocos.append(colunas("\n".join(esq), nivel + 1).strip("\n"))
            blocos.append(colunas("\n".join(dir_), nivel + 1).strip("\n"))
        esq.clear()
        dir_.clear()

    for l in linhas:
        # corta cada linha num espaço dentro da calha (o mais perto do meio); sem espaço ali, a linha atravessa a página
        cortes = [c for c in range(ini, fim) if c >= len(l) or l[c] == " "]
        if not cortes:
            fecha()
            blocos.append(l.strip())
        else:
            c = min(cortes, key=lambda x: abs(x - meio))
            esq.append(l[:c].rstrip())
            dir_.append(l[c:].rstrip() if len(l) > c else "")
    fecha()
    return "\n\n".join(b for b in blocos if b.strip())


# ---------------------------------------------------------------- utilidades
def _sem(s: str) -> str:
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


_VALOR = r"\d{1,3}(?:\.\d{3})+,\d{2}|\d{1,4},\d{2}|\d{1,4}\.\d{2}(?!\d)|\d{1,4},-"
_TOK_PRECO = re.compile(r"(?P<rs>R\s?\$|R[S5](?=\s?\d))?\s*(?P<v>" + _VALOR + r")(?![\d%])|(?P<rs2>R\s?\$)\s*(?P<vi>\d{1,4})(?![\d.,])", re.I)
_LIDER = re.compile(r"[.·…_]{3,}|(?:\s[.·]){3,}|-{4,}")
_NUM_ITEM = re.compile(r"^\s*(?:n[ºo°]\s*)?\d{1,3}\s*[-.)–]\s+(?=\D)")

_TAM = (r"(?:pp|p|m|g|gg|xg|pequen[oa]|m[eé]di[oa]|grande|gigante|fam[ií]lia|broto|individual|meia|inteira|simples|dupl[oa]|tripl[oa]|"
        r"\d{2,4}\s?ml|\d(?:[.,]\d{1,2})?\s?(?:l|litros?)|\d{2,4}\s?g|\d(?:[.,]\d)?\s?kg|\d{1,2}\s?(?:fatias|peda[cç]os|un|unid|unidades|p[cç]s|pe[cç]as|sabores))")
_TAM_RE = re.compile(r"^" + _TAM + r"$", re.I)
_TAM_FIM = re.compile(r"(?:^|\s)(" + _TAM + r")\s*[:\-–]?\s*$", re.I)

_CAT_VOC = {
    "lanches", "lanche", "hamburgueres", "hamburguer", "burgers", "sanduiches", "pizzas", "pizza", "pizzas doces", "pizzas salgadas", "bebidas", "sucos",
    "refrigerantes", "cervejas", "drinks", "drinques", "vinhos", "doses", "cafes", "cafeteria", "porcoes", "petiscos", "entradas", "saladas", "massas",
    "pratos", "pratos executivos", "executivos", "pratos principais", "grelhados", "carnes", "frango", "peixes", "frutos do mar", "sobremesas", "doces",
    "acai", "sorvetes", "milkshakes", "combos", "promocoes", "kids", "infantil", "japonesa", "sushis", "temakis", "esfihas", "salgados", "pasteis",
    "tapiocas", "crepes", "omeletes", "caldos", "sopas", "marmitas", "marmitex", "self service", "churrasco", "espetinhos", "batatas", "hot dogs",
    "cachorro quente", "vitaminas", "smoothies", "chas", "bolos", "tortas", "paes", "acompanhamentos", "guarnicoes", "servicos", "cortes", "barba",
    "cabelo", "estetica", "unhas", "manicure", "depilacao", "tratamentos", "pacotes",
}
_ADIC = re.compile(r"^(?:adicionais|adicional|extras?|acr[eé]scimos?|complementos?|turbine(?:\s+seu\s+\w+)?|incremente|opcionais|coberturas?|toppings?)\b", re.I)
_OBS = re.compile(r"^(?:\*+|obs\b\.?:?|observa[cç][aã]o|aten[cç][aã]o|serve\s+\d|acompanha\b|cont[eé]m\b|n[aã]o\s+cont[eé]m|sem\s+gl[uú]ten|vegano|vegetariano|\(.*\)$)", re.I)
_INDISP = re.compile(r"\b(esgotad[oa]|indispon[ií]vel|em\s+falta)\b", re.I)
_IGNORAR = re.compile(r"(taxa\s+de\s+entrega|pedido\s+m[ií]nimo|whats\s?app|instagram|@\w|telefone|fone\b|\(\d{2}\)\s?\d|cnpj|endere[cç]o|rua\s|av\.|avenida|"
                      r"hor[aá]rio|funcionamento|aceitamos|formas?\s+de\s+pagamento|delivery|card[aá]pio\s+sujeito|pre[cç]os?\s+sujeitos?|www\.|\.com)", re.I)


def _limpa(l: str) -> str:
    l = l.replace("\t", "   ")
    l = _LIDER.sub("   ", l)
    return l.rstrip()


def _ocr_fix(l: str) -> tuple[str, bool]:
    """Correções clássicas do OCR nos valores (O→0, l/I→1, S→5 dentro de números, RS/R5→R$)."""
    orig = l
    l = re.sub(r"(?<=\d[.,])[Oo](?=\d)|(?<=\d[.,]\d)[Oo]\b|(?<=\d)[Oo](?=[.,]\d\d)", "0", l)
    l = re.sub(r"(?<![A-Za-z])[lI|](?=\d{0,3}[.,]\d{2}\b)", "1", l)
    l = re.sub(r"(?<=\d)[lI](?=[.,]\d{2}\b)", "1", l)
    l = re.sub(r"\b(R)[S5]\s?(?=\d)", r"R$ ", l)
    l = re.sub(r"(?<=\d),\s(?=\d{2}\b)", ",", l)  # "12, 90"
    l = re.sub(r"(?<=\d)(\s?)m[i!|1l](?![a-zà-ú])", r"\1ml", l)  # "300 mi" / "300m!" → ml
    # troca clássica do OCR "rn" → "m" em palavras comuns de cardápio (só palavras que não existem em português)
    l = re.sub(r"\b([Cc])ame(s?)\b", r"\1arne\2", l)
    l = re.sub(r"\b([Tt])ostame\b", r"\1ostarne", l)
    return l, l != orig


def _valor(v: str | None, vi: str | None) -> float:
    if vi:
        return float(vi)
    v = v.replace(",-", ",00")
    if "," in v:
        return float(v.replace(".", "").replace(",", "."))
    return float(v)


def _precos(l: str) -> list[tuple[int, int, float]]:
    out = []
    for m in _TOK_PRECO.finditer(l):
        try:
            val = _valor(m.group("v"), m.group("vi"))
        except ValueError:
            continue
        if 0 < val < 100000:
            out.append((m.start(), m.end(), round(val, 2)))
    return out


def _letras(s: str) -> int:
    return sum(1 for c in s if c.isalpha())


def _maiusculas(s: str) -> bool:
    let = [c for c in s if c.isalpha()]
    return len(let) >= 3 and sum(1 for c in let if c.isupper()) >= len(let) * 0.75


def _descritiva(s: str) -> bool:
    t = s.strip()
    if not t:
        return False
    pal = t.split()
    return ("," in t or t[0].islower() or len(pal) > 7 or t.endswith(".") or (len(pal) >= 4 and re.search(r"\s(com|e|de)\s", t) is not None and not _maiusculas(t)))


def _titulo(s: str) -> bool:
    """Linha que parece título de categoria."""
    t = s.strip().rstrip(":").strip()
    if not t or len(t) > 40 or _letras(t) < 3 or _precos(t) or _descritiva(t) or MARCA in t:
        return False
    pal = t.split()
    if len(pal) > 5:
        return False
    k = re.sub(r"[^a-z ]", "", _sem(t)).strip()
    return k in _CAT_VOC or any(w in _CAT_VOC for w in k.split()) or _maiusculas(t) or s.strip().endswith(":")


def _nome_limpo(s: str) -> str:
    s = _NUM_ITEM.sub("", s)
    s = re.sub(r"(?:R\s?\$|RS)\s*$", "", s.strip(), flags=re.I)
    s = re.sub(r"^[\s\-–•·*:|]+|[\s\-–•·*:|/]+$", "", s)
    return re.sub(r"\s{2,}", " ", s).strip()


def _duvida_nome(nome: str) -> str:
    if MARCA in nome:
        return "trecho pouco legível na foto"
    if len(nome) < 3 or _letras(nome) < max(2, len(nome.replace(" ", "")) * 0.6):
        return "nome com caracteres estranhos"
    if re.search(r"[{}\[\]<>~^|\\]", nome):
        return "nome com caracteres estranhos"
    return ""


def _sem_marca(s: str) -> str:
    return re.sub(r"\s{2,}", " ", s.replace(MARCA, "")).strip()


def _grupo_nome(rotulos: list[str]) -> str:
    k = " ".join(_sem(r) for r in rotulos)
    if re.search(r"\bmeia\b|\binteira\b", k):
        return "Porção"
    if re.search(r"simples|dupl|tripl", k):
        return "Tipo"
    return "Tamanho"


def _rotulo(r: str) -> str:
    r = re.sub(r"\s+", " ", r.strip(" :-–|/")).strip()
    return r.upper() if len(r) <= 2 else r[:1].upper() + r[1:]


# ---------------------------------------------------------------- interpretação
def extrair(texto: str) -> dict:
    """Devolve {"itens": [...], "categorias": [...], "adicionais_soltos": [...], "linhas_ignoradas": n, "avisos": [...]}.
    Cada item já vem no formato do importador do app (nome, descricao, preco, categoria, variacoes, adicionais,
    disponivel, observacoes, confianca, duvida, tipo)."""
    linhas = [_limpa(l) for l in (texto or "").replace("\r", "").split("\n")]
    itens: list[dict] = []
    categorias: list[str] = []
    cat = ""
    cat_sem_titulo = True
    tamanhos: list[str] | None = None  # cabeçalho "P  M  G" valendo para a categoria
    modo_adic: dict | None = None  # seção de adicionais: {"alvo": categoria, "lista": [...]}
    pend: list[str] = []
    ignoradas = 0
    secoes_adic: list[dict] = []
    ultimo: dict | None = None
    estado = {"duv": False}

    def novo_item(nome: str, desc: list[str], corrigido: bool) -> dict:
        nonlocal ultimo
        indisp, obs = False, []
        for par in re.findall(r"\(([^)]{2,60})\)", nome):
            if _INDISP.search(par):
                indisp = True
                nome = nome.replace(f"({par})", " ")
            elif re.match(r"(?:serve|cont[eé]m|sem\s|obs)", par, re.I):
                obs.append(par)
                nome = nome.replace(f"({par})", " ")
        if _INDISP.search(nome):
            indisp = True
            nome = _INDISP.sub(" ", nome)
        nome = _nome_limpo(nome)
        d = _duvida_nome(nome)
        it = {"nome": _sem_marca(nome)[:80], "descricao": "", "descricao_sugerida": "", "preco": None, "categoria": cat, "ingredientes": [], "variacoes": [],
              "adicionais": [], "disponivel": None, "observacoes": "", "confianca": 0.9, "duvida": d, "tipo": "produto", "_cat_lida": not cat_sem_titulo}
        if estado["duv"]:
            it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + "valor pouco legível na foto"
        if indisp:
            it["disponivel"] = False
        if obs:
            it["observacoes"] = "; ".join(obs)[:200]
        if corrigido:
            it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + "preço com correção de leitura"
        for l in desc:
            anexa_desc(it, l)
        itens.append(it)
        ultimo = it
        return it

    def anexa_desc(it: dict, l: str):
        t = l.strip()
        if not t:
            return
        if _INDISP.search(t):
            it["disponivel"] = False
        if _OBS.match(t):
            obs = re.sub(r"^(?:\*+\s*|obs\b\.?\s*:?\s*|observa[cç][aã]o\s*:?\s*)", "", t, flags=re.I).strip()
            it["observacoes"] = ((it["observacoes"] + "; ") if it["observacoes"] else "") + _sem_marca(obs)
            it["observacoes"] = it["observacoes"][:200]
            return
        if MARCA in t and not it["duvida"]:
            it["duvida"] = "descrição pouco legível"
        it["descricao"] = (it["descricao"] + " " + _sem_marca(t)).strip()[:600]

    def descarrega(antes_de_produto: bool) -> tuple[str | None, list[str]]:
        """Resolve as linhas pendentes: títulos viram categoria; descrição vai para o item anterior;
        devolve (nome, descrição) quando o próximo preço vier sozinho numa linha."""
        nonlocal cat, tamanhos, modo_adic, cat_sem_titulo, ignoradas
        linhas_p = [p for p in pend if p.strip()]
        pend.clear()
        nome_idx = None
        if antes_de_produto is False:  # preço sozinho: o nome é a última linha "não descritiva"
            for i in range(len(linhas_p) - 1, -1, -1):
                if not _descritiva(linhas_p[i]) and not _OBS.match(linhas_p[i].strip()):
                    nome_idx = i
                    break
        for i, l in enumerate(linhas_p[: nome_idx if nome_idx is not None else len(linhas_p)]):
            trata_sem_preco(l)
        if nome_idx is None:
            return None, []
        return linhas_p[nome_idx], linhas_p[nome_idx + 1:]

    def trata_sem_preco(l: str):
        nonlocal cat, tamanhos, modo_adic, cat_sem_titulo, ignoradas, ultimo
        t = l.strip()
        cab = _cabecalho_tamanhos(t)
        if cab:
            titulo_cab, rot = cab
            if titulo_cab:
                abre_categoria(titulo_cab)
            tamanhos = rot
            return
        if _ADIC.match(_sem(t)) and len(t) <= 50:
            alvo = _alvo_adicionais(t)
            modo_adic = {"alvo": alvo, "lista": [], "titulo": t}
            secoes_adic.append(modo_adic)
            return
        if _titulo(t):
            abre_categoria(t)
            return
        if ultimo is not None and modo_adic is None:
            anexa_desc(ultimo, t)
            return
        ignoradas += 1

    def abre_categoria(t: str):
        nonlocal cat, tamanhos, modo_adic, cat_sem_titulo, ultimo
        nome = _sem_marca(t.strip().rstrip(":").strip())
        nome = nome[:1].upper() + nome[1:].lower() if _maiusculas(nome) else nome
        cat = nome[:40]
        cat_sem_titulo = False
        tamanhos = None
        modo_adic = None
        ultimo = None
        if cat not in categorias:
            categorias.append(cat)

    def _alvo_adicionais(t: str) -> str:
        k = _sem(t)
        for c in categorias:
            if any(w in k for w in _sem(c).split() if len(w) > 3):
                return c
        return cat

    for bruta in linhas + [""]:
        if not bruta.strip():
            continue
        if _IGNORAR.search(bruta) and not (_precos(bruta) and not re.search(r"taxa|pedido\s+m[ií]nimo|entrega", bruta, re.I)):
            ignoradas += 1
            continue
        l, corrigido = _ocr_fix(bruta)
        # valor marcado como duvidoso pelo OCR (as duas leituras discordaram): lê o número, mas o item vai para revisão
        duv = MARCA in l and bool(_precos(l.replace(MARCA, "")))
        estado["duv"] = duv
        if duv:
            l = l.replace(MARCA, "")
        ps = _precos(l)
        t = l.strip()
        # adicional na linha: "+ Bacon 4,00" / "Adicional: ovo 2,00"
        inline_adic = re.match(r"^\s*(?:\+|adicional\s*:?|add\s*:?|extra\s*:)\s*(.+)$", t, re.I)
        if inline_adic and ps:
            pares = _pares(inline_adic.group(1))
            destino = ultimo
            if destino is None and modo_adic is None:
                ignoradas += 1
                continue
            for nome_a, v in pares:
                (destino["adicionais"] if modo_adic is None else modo_adic["lista"]).append({"nome": _sem_marca(nome_a)[:40], "preco": v, **({"duvida": True} if duv or MARCA in nome_a else {})})
            continue
        if not ps:
            # "X-Burguer           EIS": nome à esquerda e, no lugar do preço, um borrão que o OCR não leu como número
            m_il = re.match(r"^(\S.*?\S)\s{6,}(\S{1,8})$", t)
            if (m_il and modo_adic is None and not _titulo(m_il.group(1)) and not _descritiva(m_il.group(1)) and _letras(m_il.group(1)) >= 3
                    and not _TAM_RE.match(_sem(m_il.group(2))) and not _cabecalho_tamanhos(t) and (descarrega(True) or True) and cat):
                it = novo_item(_nome_limpo(m_il.group(1)), [], False)
                it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + "preço ilegível na foto"
                continue
            pend.append(t)
            continue
        nome_txt = _nome_limpo(t[: ps[0][0]])
        if modo_adic is not None:
            # dentro da seção de adicionais: cada linha com preço é um adicional (pode ter vários na mesma linha)
            for x in pend:
                if _titulo(x) and not _ADIC.match(_sem(x)):
                    break
            if pend and any(_titulo(x) and not _ADIC.match(_sem(x)) for x in pend):
                descarrega(True)
            else:
                pend.clear()
            if modo_adic is not None:
                for nome_a, v in _pares(t):
                    modo_adic["lista"].append({"nome": _sem_marca(nome_a)[:40], "preco": v, **({"duvida": True} if duv or MARCA in nome_a else {})})
                continue
        # preço sozinho na linha: o nome está acima
        if not _letras(nome_txt.replace(MARCA, "")) and len(ps) >= 1 and not _letras(t[ps[-1][1]:]):
            nome, desc = descarrega(False)
            if nome is None:
                # preço sem nome acima: nome ilegível ou fora da foto; não se adivinha a quem pertence
                ignoradas += 1
                ultimo = None
                continue
            it = novo_item(_nome_limpo(nome), desc, corrigido)
            _aplica_precos(it, ps, t, tamanhos, rotulo_inicial="")
            continue
        # linha "Tamanho  preço" logo abaixo de um produto: vira opção do produto anterior
        if _TAM_RE.match(_sem(nome_txt)) and len(ps) == 1 and ultimo is not None and not pend:
            g = next((v for v in ultimo["variacoes"] if v["nome"] in ("Tamanho", "Porção", "Tipo")), None)
            if g is None:
                g = {"nome": _grupo_nome([nome_txt]), "opcoes": []}
                if ultimo["preco"] is not None:
                    ultimo["duvida"] = (ultimo["duvida"] + "; " if ultimo["duvida"] else "") + "preço base e tamanhos — confira"
                ultimo["variacoes"].append(g)
            g["opcoes"].append({"nome": _rotulo(nome_txt), "preco": ps[0][2]})
            if duv:
                ultimo["duvida"] = (ultimo["duvida"] + "; " if ultimo["duvida"] else "") + "valor pouco legível na foto"
            continue
        # nome + preço na mesma linha: o que estava pendente é título, descrição do anterior ou nome sem preço
        if pend:
            # nome de produto sem preço seguido de linhas de tamanho? ("Açaí" / "300 ml 12,00")
            if _TAM_RE.match(_sem(nome_txt)) and len(ps) == 1:
                nome, desc = descarrega(False)
                if nome:
                    it = novo_item(_nome_limpo(nome), desc, corrigido)
                    it["variacoes"].append({"nome": _grupo_nome([nome_txt]), "opcoes": [{"nome": _rotulo(nome_txt), "preco": ps[0][2]}]})
                    continue
            descarrega(True)
            if modo_adic is not None:
                for nome_a, v in _pares(t):
                    modo_adic["lista"].append({"nome": _sem_marca(nome_a)[:40], "preco": v, **({"duvida": True} if duv or MARCA in nome_a else {})})
                continue
        if not nome_txt or _letras(nome_txt) < 2:
            ignoradas += 1
            ultimo = None
            continue
        # "Nome: descrição ..... 25,00" / "Nome - descrição 25,00"
        desc_mesma = ""
        m = re.match(r"^(.{3,40}?)\s*(?::|\s[-–]\s)\s*(.{6,})$", nome_txt)
        if m and _descritiva(m.group(2)):
            nome_txt, desc_mesma = m.group(1), m.group(2)
        else:
            gap = re.split(r"\s{3,}", nome_txt)
            if len(gap) > 1 and _descritiva(" ".join(gap[1:])):
                nome_txt, desc_mesma = gap[0], " ".join(gap[1:])
        rot_ini = ""
        nome_orig = nome_txt
        mt = _TAM_FIM.search(nome_txt)
        if mt and len(ps) >= 2 and _letras(nome_txt[: mt.start()]) >= 3:
            rot_ini = mt.group(1)
            nome_txt = nome_txt[: mt.start()].strip()
        it = novo_item(_nome_limpo(nome_txt), [desc_mesma] if desc_mesma else [], corrigido)
        if not _aplica_precos(it, ps, t, tamanhos, rotulo_inicial=rot_ini) and rot_ini:
            it["nome"] = _sem_marca(_nome_limpo(nome_orig))[:80]  # o "tamanho" no fim do nome não era rótulo: o nome fica inteiro
        resto = t[ps[-1][1]:].strip(" -–|")
        if resto and _letras(resto) >= 3 and not _TAM_RE.match(_sem(resto)):
            anexa_desc(it, resto)
    if pend:
        descarrega(True)

    # adicionais de seção: valem para os produtos da categoria a que se referem
    soltos: list[dict] = []
    for s in secoes_adic:
        if not s["lista"]:
            continue
        alvo = [it for it in itens if it["categoria"] == s["alvo"]] if s["alvo"] else []
        if not alvo:
            soltos.extend(s["lista"])
            continue
        for it in alvo:
            nomes = {a["nome"].lower() for a in it["adicionais"]}
            it["adicionais"].extend(dict(a) for a in s["lista"] if a["nome"].lower() not in nomes)
    # validação final por item
    for it in itens:
        if any(a.pop("duvida", False) for a in it["adicionais"]):
            it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + "adicional pouco legível"
        it["adicionais"] = [{"nome": a["nome"], "preco": a["preco"]} for a in it["adicionais"]]
        if it["preco"] is not None and (it["preco"] < 0.5 or it["preco"] > 5000):
            it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + "valor fora do comum"
        if it["duvida"]:
            it["confianca"] = 0.6
        it["duvida"] = it["duvida"][:160]
        if not it["categoria"]:
            it["categoria"] = ""
    itens = [it for it in itens if len(it["nome"]) >= 2]
    avisos = []
    if soltos:
        avisos.append(f"adicionais_sem_categoria: {len(soltos)}")
    return {"itens": [{k: v for k, v in it.items()} for it in itens], "categorias": categorias, "adicionais_soltos": soltos,
            "linhas_ignoradas": ignoradas, "avisos": avisos}


def _pares(s: str) -> list[tuple[str, float]]:
    """"Bacon 4,00  Ovo 2,00" / "Bacon R$ 4,00, Cheddar R$ 3,50" → [("Bacon", 4.0), ("Ovo", 2.0), ...]."""
    out = []
    ini = 0
    for a, b, v in _precos(s):
        nome = _nome_limpo(re.sub(r"^[\s,;/|+]+", "", s[ini:a]))
        nome = re.sub(r"^(?:adicional|add|extra)\s*:?\s*", "", nome, flags=re.I)
        if _letras(nome) >= 2:
            out.append((nome, v))
        ini = b
    return out


def _cabecalho_tamanhos(t: str) -> tuple[str, list[str]] | None:
    """"P   M   G" / "Broto  Média  Grande" / "PIZZAS   P   M   G" → (título opcional, rótulos)."""
    partes = [p for p in re.split(r"\s{2,}|\s*[|/]\s*", t.strip()) if p]
    if len(partes) < 2:
        partes = t.split()
    rot = []
    for p in reversed(partes):
        if _TAM_RE.match(_sem(p.strip())):
            rot.insert(0, p.strip())
        else:
            break
    if len(rot) < 2:
        return None
    resto = " ".join(partes[: len(partes) - len(rot)]).strip()
    if resto and not _titulo(resto):
        return None
    return resto, [_rotulo(r) for r in rot]


def _aplica_precos(it: dict, ps: list, linha: str, tamanhos: list[str] | None, rotulo_inicial: str):
    if len(ps) == 1:
        it["preco"] = ps[0][2]
        return False
    # rótulo antes de cada preço ("P 30,00 M 40,00" / "300ml R$ 8,00 | 500ml R$ 12,00")
    rot = []
    ini = None
    for i, (a, b, v) in enumerate(ps):
        trecho = linha[(ps[i - 1][1] if i else 0):a]
        r = re.sub(r"(?:R\s?\$|RS)\s*$", "", trecho.strip(), flags=re.I).strip(" :-–|/")
        r = r.split("   ")[-1].strip() if i else ""
        rot.append(r)
    if rotulo_inicial:
        rot[0] = rotulo_inicial
    if all(r and _TAM_RE.match(_sem(r)) for r in rot):
        it["variacoes"].append({"nome": _grupo_nome(rot), "opcoes": [{"nome": _rotulo(r), "preco": p[2]} for r, p in zip(rot, ps)]})
        return True
    if tamanhos and len(tamanhos) == len(ps):
        it["variacoes"].append({"nome": _grupo_nome(tamanhos), "opcoes": [{"nome": r, "preco": p[2]} for r, p in zip(tamanhos, ps)]})
        return False
    # vários preços sem tamanho identificado: não inventa rótulo; mostra para revisão
    it["preco"] = ps[0][2]
    it["duvida"] = (it["duvida"] + "; " if it["duvida"] else "") + f"{len(ps)} preços na linha sem tamanho identificado ({', '.join(f'{p[2]:.2f}'.replace('.', ',') for p in ps)})"
