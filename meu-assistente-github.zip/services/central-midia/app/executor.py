"""Executa o trabalhador em processo isolado: limite de memória (RLIMIT_AS), CPU, tamanho de arquivos gravados
e de processos; tempo limite de relógio com encerramento do grupo inteiro (inclui Tesseract/FFmpeg filhos)."""
from __future__ import annotations

import asyncio
import json
import os
import signal
import sys

from .config import Config


def _limites(cfg: Config):
    def aplicar():  # roda no filho, antes do exec
        import resource
        mem = cfg.memoria_trabalho_mb * 1024 * 1024
        for rec, val in ((resource.RLIMIT_AS, mem), (resource.RLIMIT_CPU, cfg.tempo_limite_s + 5),
                         (resource.RLIMIT_FSIZE, 512 * 1024 * 1024), (resource.RLIMIT_CORE, 0)):
            try:
                resource.setrlimit(rec, (val, val))
            except (ValueError, OSError):
                pass
        os.setsid()
    return aplicar


async def rodar(tarefa: dict, cfg: Config) -> dict:
    env = {k: v for k, v in os.environ.items() if k not in ("MIDIA_TOKEN", "IA_CHAVE")}  # o filho não precisa dos segredos
    env["OMP_THREAD_LIMIT"] = "1"  # Tesseract com 1 thread: previsível em VPS pequena
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "app.trabalhador", stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE, cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))), env=env,
        preexec_fn=_limites(cfg))
    try:
        out, err = await asyncio.wait_for(proc.communicate(json.dumps(tarefa).encode()), timeout=float(tarefa["tempo_s"]) + 3)
    except asyncio.TimeoutError:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        await proc.wait()
        return {"ok": False, "codigo": "tempo_excedido", "mensagem": "O processamento passou do tempo limite."}
    finally:
        try:
            os.killpg(proc.pid, signal.SIGKILL)  # garante que nenhum filho (tesseract, ffmpeg) sobreviva
        except (ProcessLookupError, PermissionError):
            pass
    if proc.returncode and proc.returncode < 0:
        sinal = -proc.returncode
        cod = "memoria_excedida" if sinal in (signal.SIGKILL, signal.SIGSEGV) else "tempo_excedido" if sinal == signal.SIGXCPU else "erro_interno"
        return {"ok": False, "codigo": cod, "mensagem": "O processamento foi interrompido pelos limites de segurança."}
    try:
        return json.loads(out.decode("utf-8", "replace") or "{}") or {"ok": False, "codigo": "erro_interno", "mensagem": "Sem resposta do processamento."}
    except json.JSONDecodeError:
        msg = "memoria_excedida" if b"MemoryError" in (err or b"") else "erro_interno"
        return {"ok": False, "codigo": msg, "mensagem": "O processamento terminou sem resultado válido."}
