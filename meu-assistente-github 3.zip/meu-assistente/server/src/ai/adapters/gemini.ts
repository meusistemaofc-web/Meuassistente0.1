// Adaptador NATIVO do Google Gemini (generateContent). Substitui o uso do endereço de compatibilidade
// com a OpenAI, que fazia o Gemini aparecer como "pronto" no teste de texto simples e falhar no chat real
// (ferramentas com esquema inválido, respostas vazias por bloqueio, chave inválida devolvida como 400).
import { AiError, httpError, netError, rid, type Adapter, type ChatMsg, type Target } from '../types.js'

export const geminiBase = (t: { url: string }) => (process.env.GEMINI_API_BASE || (t.url || 'https://generativelanguage.googleapis.com')).replace(/\/+$/, '').replace(/\/v1beta(\/openai)?$/, '').replace(/\/openai$/, '')
const SKIP_SIG = 'skip_thought_signature_validator' // aceito pelo Gemini quando a chamada de ferramenta veio de outra IA

/** O Gemini recusa campos como additionalProperties e objetos sem propriedades: limpa o esquema recursivamente. */
export function cleanSchema(s: any): any {
  if (Array.isArray(s)) return s.map(cleanSchema)
  if (!s || typeof s !== 'object') return s
  const o: any = {}
  for (const [k, v] of Object.entries(s)) {
    if (['additionalProperties', '$schema', 'default', 'examples', 'title', 'strict'].includes(k)) continue
    if (k === 'required' && Array.isArray(v) && !v.length) continue
    o[k] = k === 'properties' && v && typeof v === 'object' ? Object.fromEntries(Object.entries(v as any).map(([n, x]) => [n, cleanSchema(x)])) : cleanSchema(v)
  }
  if (o.type === 'object' && (!o.properties || !Object.keys(o.properties).length)) return undefined
  return o
}
export function toolDecls(tools: any[]) {
  return tools.map((t) => { const p = cleanSchema(t.function.parameters); return { name: t.function.name, description: String(t.function.description || t.function.name).slice(0, 1000), ...(p ? { parameters: p } : {}) } })
}
function toolResult(content: string | null) { try { const j = JSON.parse(content || ''); return j && typeof j === 'object' && !Array.isArray(j) ? j : { result: j } } catch { return { result: content || '' } } }

export function toContents(messages: ChatMsg[]) {
  const names = new Map<string, string>()
  const system: string[] = []
  const out: { role: 'user' | 'model'; parts: any[] }[] = []
  const push = (role: 'user' | 'model', parts: any[]) => { if (!parts.length) return; const l = out[out.length - 1]; if (l && l.role === role) l.parts.push(...parts); else out.push({ role, parts }) }
  for (const m of messages) {
    if (m.role === 'system') { if (m.content) system.push(m.content); continue }
    if (m.role === 'assistant') {
      const parts: any[] = []
      if (m.content) parts.push({ text: m.content })
      for (const c of m.tool_calls || []) {
        names.set(c.id, c.function.name)
        let args: any = {}; try { args = JSON.parse(c.function.arguments || '{}') } catch { /* argumentos inválidos viram objeto vazio */ }
        parts.push({ functionCall: { name: c.function.name, args }, thoughtSignature: c.extra_content?.google?.thought_signature || SKIP_SIG })
      }
      push('model', parts); continue
    }
    if (m.role === 'tool') { push('user', [{ functionResponse: { name: names.get(m.tool_call_id || '') || 'ferramenta', response: toolResult(m.content) } }]); continue }
    const parts: any[] = []
    if (m.content) parts.push({ text: m.content })
    for (const f of m.files || []) parts.push({ inline_data: { mime_type: f.mime, data: f.data } })
    push('user', parts.length ? parts : [{ text: ' ' }])
  }
  if (!out.length || out[0].role === 'model') out.unshift({ role: 'user', parts: [{ text: 'Continue a conversa.' }] })
  return { system: system.join('\n\n'), contents: out }
}

async function call(t: Target, body: any, signal: AbortSignal) {
  let res: Response
  try {
    res = await fetch(`${geminiBase(t)}/v1beta/models/${encodeURIComponent(t.model.replace(/^models\//, ''))}:generateContent`, { method: 'POST', signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': t.key }, body: JSON.stringify(body) })
  } catch (e) { throw netError(e) }
  const j: any = await res.json().catch(() => null)
  if (!res.ok) throw httpError(res.status, j, res.headers)
  return j
}
const BLOCKED = ['SAFETY', 'RECITATION', 'BLOCKLIST', 'PROHIBITED_CONTENT', 'SPII', 'IMAGE_SAFETY']

function parse(j: any) {
  const cand = j?.candidates?.[0]
  if (!cand) { const br = j?.promptFeedback?.blockReason; throw new AiError(br ? 'blocked' : 'invalid_response', br ? `Pedido bloqueado (${br})` : 'Resposta sem candidatos', 200, 0, JSON.stringify(j)?.slice(0, 300)) }
  const fr = String(cand.finishReason || '')
  if (BLOCKED.includes(fr)) throw new AiError('blocked', `Resposta bloqueada (${fr})`)
  if (fr === 'MALFORMED_FUNCTION_CALL') throw new AiError('invalid_response', 'Chamada de ferramenta malformada')
  const parts: any[] = cand.content?.parts || []
  let text = parts.filter((p) => typeof p.text === 'string' && !p.thought).map((p) => p.text).join('')
  const calls = parts.filter((p) => p.functionCall).map((p) => ({ id: `call_${rid()}`, type: 'function' as const, function: { name: String(p.functionCall.name), arguments: JSON.stringify(p.functionCall.args || {}) }, ...((p.thoughtSignature || p.thought_signature) ? { extra_content: { google: { thought_signature: p.thoughtSignature || p.thought_signature } } } : {}) }))
  const chunks: any[] = cand.groundingMetadata?.groundingChunks || []
  const grounded = chunks.length > 0
  if (grounded && text) { const src = chunks.map((c) => c.web).filter((w) => w?.uri).slice(0, 3).map((w) => `• ${w.title || w.uri}: ${w.uri}`); if (src.length) text += `\n\nFontes:\n${src.join('\n')}` }
  const u = j.usageMetadata
  return { message: { role: 'assistant', content: text || null, ...(calls.length ? { tool_calls: calls } : {}) } as ChatMsg, finish: fr, grounded, usage: u ? { in: Number(u.promptTokenCount) || 0, out: (Number(u.candidatesTokenCount) || 0) + (Number(u.thoughtsTokenCount) || 0) } : undefined }
}

export const geminiAdapter: Adapter = {
  kind: 'gemini',
  async chat(t, r) {
    const { system, contents } = toContents(r.messages)
    const decls = r.tools?.length ? toolDecls(r.tools) : []
    const body: any = { contents, generationConfig: { ...(/gemini-3/.test(t.model) ? {} : { temperature: r.temperature }), ...(r.json ? { responseMimeType: 'application/json' } : {}) } }
    if (system) body.systemInstruction = { parts: [{ text: system }] }
    if (decls.length) body.tools = [{ functionDeclarations: decls }]
    else if (r.grounding) body.tools = [{ google_search: {} }] // pesquisa na web só quando não há ferramentas
    return parse(await call(t, body, r.signal))
  },
  async transcribe(t, data, mime, signal) {
    const j = await call(t, { contents: [{ role: 'user', parts: [{ text: 'Transcreva fielmente este áudio em português do Brasil. Responda só com o texto falado, sem comentários.' }, { inline_data: { mime_type: mime.split(';')[0] || 'audio/webm', data: data.toString('base64') } }] }], generationConfig: { temperature: 0 } }, signal)
    const p = parse(j); return { text: String(p.message.content || '').trim(), usage: p.usage }
  },
}
